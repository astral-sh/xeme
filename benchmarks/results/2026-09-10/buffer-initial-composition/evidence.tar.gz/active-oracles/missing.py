"""Bounded missing-parameter-entity lifecycle and callback oracle."""
import ctypes as c
import hashlib,json,itertools,sys
from pathlib import Path
assert not any(line.rsplit('/',1)[-1].startswith('libexpat.') for line in Path('/proc/self/maps').read_text().splitlines())
START=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.POINTER(c.c_char_p));END=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p);TEXT=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_int);SKIP=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_int);NS=c.CFUNCTYPE(c.c_int,c.c_void_p);EXT=c.CFUNCTYPE(c.c_int,c.c_void_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p)
ENTITY=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_int,c.c_char_p,c.c_int,c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p)
ATT=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_int)
NOTATION=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p)
def setup(path):
 lib=c.CDLL(path)
 for name,args,result in [('XML_ParserCreate',[c.c_char_p],c.c_void_p),('XML_ExternalEntityParserCreate',[c.c_void_p,c.c_char_p,c.c_char_p],c.c_void_p),('XML_ParserReset',[c.c_void_p,c.c_char_p],c.c_ubyte),('XML_Parse',[c.c_void_p,c.c_char_p,c.c_int,c.c_int],c.c_int),('XML_GetErrorCode',[c.c_void_p],c.c_int),('XML_SetParamEntityParsing',[c.c_void_p,c.c_int],c.c_int),('XML_ParserFree',[c.c_void_p],None),('XML_SetElementHandler',[c.c_void_p,START,END],None),('XML_SetCharacterDataHandler',[c.c_void_p,TEXT],None),('XML_SetDefaultHandler',[c.c_void_p,TEXT],None),('XML_SetSkippedEntityHandler',[c.c_void_p,SKIP],None),('XML_SetNotStandaloneHandler',[c.c_void_p,NS],None),('XML_SetExternalEntityRefHandler',[c.c_void_p,EXT],None),('XML_SetEntityDeclHandler',[c.c_void_p,ENTITY],None),('XML_SetAttlistDeclHandler',[c.c_void_p,ATT],None),('XML_SetNotationDeclHandler',[c.c_void_p,NOTATION],None)]:
  fn=getattr(lib,name);fn.argtypes=args;fn.restype=result
 return lib

def run(lib,xml,external,mode,profile,chunk):
 p=lib.XML_ParserCreate(None);assert p
 events=[];children=[]
 def string(x):return None if x is None else x.decode()
 def append(event):
  if event[0] in ('text','default') and events and events[-1][0]==event[0]:events[-1][1]+=event[1]
  else:events.append(event)
 @START
 def start(_,name,attrs):
  a=[];i=0
  while attrs[i]:a.append([attrs[i].decode(),attrs[i+1].decode()]);i+=2
  append(['start',name.decode(),a])
 @END
 def end(_,name):append(['end',name.decode()])
 @TEXT
 def text(_,data,n):append(['text',c.string_at(data,n).decode()])
 @TEXT
 def default(_,data,n):append(['default',c.string_at(data,n).decode()])
 @SKIP
 def skipped(_,name,parameter):append(['skipped',name.decode(),parameter])
 @NS
 def standalone(_):append(['not-standalone']);return int(profile!='reject')
 @ENTITY
 def entity(_,name,param,value,n,base,system,public,notation):append(['entity',name.decode(),param,None if value is None else c.string_at(value,n).decode(),string(system),string(public),string(notation)])
 @ATT
 def att(_,element,name,kind,value,required):append(['attlist',element.decode(),name.decode(),kind.decode(),string(value),required])
 @NOTATION
 def notation(_,name,base,system,public):append(['notation',name.decode(),string(system),string(public)])
 def parse(parser,raw):
  raw=raw.encode();width=chunk or len(raw);status=1
  for offset in range(0,len(raw),width):
   piece=raw[offset:offset+width];status=lib.XML_Parse(parser,piece,len(piece),int(offset+width>=len(raw)))
   if status!=1:break
  return [status,lib.XML_GetErrorCode(parser)]
 @EXT
 def child(parent,context,base,system,public):
  key=system.decode();append(['external',key])
  sub=lib.XML_ExternalEntityParserCreate(parent,context,None);assert sub
  result=parse(sub,external[key]);children.append([key,*result]);lib.XML_ParserFree(sub);return int(result[0]==1)
 lib.XML_SetParamEntityParsing(p,mode);lib.XML_SetExternalEntityRefHandler(p,child);lib.XML_SetElementHandler(p,start,end);lib.XML_SetCharacterDataHandler(p,text)
 if profile in ('all','reject','declarations'):
  lib.XML_SetEntityDeclHandler(p,entity);lib.XML_SetAttlistDeclHandler(p,att);lib.XML_SetNotationDeclHandler(p,notation)
 if profile in ('all','reject','default'):lib.XML_SetDefaultHandler(p,default)
 if profile in ('all','reject','skipped'):lib.XML_SetSkippedEntityHandler(p,skipped)
 if profile in ('all','reject','skipped'):lib.XML_SetNotStandaloneHandler(p,standalone)
 result=parse(p,xml);lib.XML_ParserFree(p)
 return {'result':result,'children':children,'events':events}

def cases():
 definitions="<!ENTITY before 'B'>"
 after="<!ENTITY after 'A'><!ATTLIST r a CDATA 'default'><!NOTATION n SYSTEM 'n'>"
 for standalone in ['absent','yes','no']:
  decl='' if standalone=='absent' else f"<?xml version='1.0' standalone='{standalone}'?>"
  for name,subset,body in [
   ('missing','%missing;','<r/>'),
   ('missing-repeated','%missing;%missing;','<r/>'),
   ('later-declarations',definitions+'%missing;'+after,'<r>&before;&after;&unknown;</r>'),
   ('previous-parameter','<!ENTITY % p "<!ENTITY before \'B\'>">%p;%missing;'+after,'<r>&before;&after;</r>'),
   ('nested-internal',"<!ENTITY % p '&#37;missing;'>%p;"+after,'<r>&after;</r>'),
   ('nested-internal-two',"<!ENTITY % p '&#37;missing;'><!ENTITY % q '&#37;p;'>%q;"+after,'<r>&after;</r>'),
   ('later-malformed','%missing;<!ELEMENT r (bad@name)>','<r/>'),
   ('invalid-name','%bad@name;','<r/>'),
   ('old-invalid-name','%\U00010000;','<r/>'),
  ]:
   yield f'{standalone}/{name}',decl+f'<!DOCTYPE r [{subset}]>{body}',{}
  yield f'{standalone}/external-subset',decl+"<!DOCTYPE r SYSTEM 'd'><r>&before;&after;</r>",{'d':definitions+'%missing;'+after}
  yield f'{standalone}/external-parameter',decl+"<!DOCTYPE r [<!ENTITY % p SYSTEM 'p'>%p;"+after+"]><r>&after;</r>",{'p':'%missing;'}
  yield f'{standalone}/internal-from-external',decl+"<!DOCTYPE r SYSTEM 'd'><r>&after;</r>",{'d':"<!ENTITY % p '&#37;missing;'>%p;"+after}

if __name__=='__main__':
 paths={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','candidate':sys.argv[1]};libs={k:setup(v) for k,v in paths.items()};rows=[];counts={'conditions':0,'acceptance':0,'errors':0,'events':0}
 for (name,xml,external),mode,profile,chunk in itertools.product(cases(),[0,1,2],['all','reject','default','skipped','declarations','none'],[0,1,7]):
  r={label:run(lib,xml,external,mode,profile,chunk) for label,lib in libs.items()};a,b=r.values();counts['conditions']+=1
  if a!=b:
   counts['acceptance']+=a['result'][0]!=b['result'][0];counts['errors']+=a['result']!=b['result'] or a['children']!=b['children'];counts['events']+=a['events']!=b['events']
   rows.append({'case':name,'mode':mode,'profile':profile,'chunk':chunk,'results':r})
 report={'counts':counts,'libraries':{label:{'path':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()} for label,path in paths.items()},'differences':rows}
 Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n');print(counts)
