# Lazy first input-buffer reservations

This candidate reduces repeated growth for small streamed feeds. It fixes 210 original upstream configurations and introduces 12 failures of an implementation-specific reallocation expectation, for a net gain of 198. All original outcomes remain in the compatibility count: **4,311 pass / 429 fail**, out of 4,740.

The combined real-project native throughput screen is close to parity: **1.00505× geomean speedup, 14 of 24 condition medians positive**. This is an allocation/compatibility tradeoff, not evidence of a substantial real-project speed gain. The tiny UTF-8 `<r/>` case retains 2,032 additional selected bytes. Recommend considering the combined patch for its bounded growth behavior and compatibility improvement, with both the memory cost and mixed throughput results explicit.

## Change and source identity

The baseline is the reviewed output-slot source `/tmp/oriole-event-output/final-source.tar.gz`, based on commit `353dc3f19ebe6554b8c224a400c588bdf49e901a`, with frozen control library `fef31ffc`. No rejected whole-event or local-slot dispatch experiment is included.

- `decoded-minimum.patch`: first nonempty native UTF-8 output into a capacity-zero decoded buffer reserves at least `min(1024, max_token_bytes)`. Complete UTF-8 and an already validated prefix follow the same operation. UTF-16, ASCII, Latin-1 and custom decoding are unchanged.
- `context-minimum.patch`: first nonempty raw input into capacity-zero FFI context reserves at least `min(1024, max_total_bytes)`.
- Both reserve at least the current append length, use the selected allocator, and propagate allocation failure. Existing capacity follows ordinary geometric growth.
- `combined.patch` is the exact measured runtime diff. `combined-with-tests.patch` adds two focused tests; `final-source.json` explains that test-only difference from the frozen combined library.

| Variant | Library SHA-256 |
| --- | --- |
| Control | `fef31ffcaa4988ce470bf81fb86356ed3f25ec8278b9dff5a54e107e919c88c3` |
| Decoded only | `5a4caa488342cd129246646b0d2f179c4d855efc7fcbc1bf137ddb043e64c054` |
| Context only | `7d6db46bb89cad8ba617f9c98e7025666be334ea42c7e1050fe274efa8c9f3cd` |
| Combined | `9f0339982de57740402ba75a249c7359eae32f3e6d88aae421663aa860c9747d` |

Each variant has a frozen source archive and hash map. `identity-notes.json` distinguishes the original noncompiling decoded draft hash in `baseline.json` from the final reviewed patch. Initial compile and Clippy diagnostics are retained. Final strict Clippy and formatting pass.

## Why these API configurations fail or improve

`upstream-comparison.json` preserves every changed result. Twenty-one tests each gain ten small-feed configurations. Examples include long namespace contexts, many attributes, long default values and nested DTD groups. The original tests cap allocation or reallocation retry counts; repeated decoded/raw input buffer growth consumed those counts before useful semantic work completed.

The twelve new failures are all `test_nsalloc_realloc_binding_uri`. That test expects a reallocation while parsing a longer namespace URI after reset. Expat grows its retained BINDING URI storage. Oriole constructs fresh semantic owners. The previous Oriole pass was incidental: a whole feed grew retained raw-context storage; the first failed reallocation with one-byte feeds grew decoded source storage. The combined buffers fit both short documents, so parsing succeeds without calling realloc.

The independent reviewer reproduced all twelve original results and ran 360 native processes with different allocators, chunk sizes, deferral settings, failure budgets and metadata handlers. Successful namespace/element/text results are exact and selected live bytes return to zero. No failed allocator call is ignored. No artificial reallocation or upstream assertion change was introduced.

`remaining-api-failures.json` retains all original assertions and names for the remaining 429 configurations:

| Family | Configurations |
| --- | ---: |
| Remaining allocation retry ceilings | 322 |
| Existing expectations of specific reallocations | 32 |
| New binding-reallocation expectation after reset | 12 |
| ParseBuffer before input-buffer initialization | 12 |
| Library version identity | 12 |
| Error positions | 12 |
| Absolute resource ceilings | 14 |
| Reparse deferral timing | 12 |
| Allocation byte heuristic | 1 |

These categories explain results; none are waived as passes.

## Allocation and memory evidence

`allocation-variants.json` records 170 conditions: 17 fixtures × five libraries × whole/one-byte feeds. The selected suite tracks requested live bytes including implementation metadata. This is not RSS or native allocator usable size. All cases return to zero selected live bytes after free. External children use the same chunk size as the parent, matching the original upstream helper; the earlier full-child-feed cohort is preserved separately in `allocation-investigation/child-full-profile/`.

| Fixture / feed | Control reallocations | Decoded | Context | Combined |
| --- | ---: | ---: | ---: | ---: |
| Original long namespace context / one byte | 23 | 14 | 14 | 5 |
| Original many attributes / one byte | 18 | 12 | 12 | 6 |
| Original long namespace context / whole | 3 | 3 | 3 | 3 |
| Original many attributes / whole | 6 | 6 | 6 | 6 |

For tiny UTF-8 `<r/>`, constructor selected live bytes remain 5,074 in every Oriole variant. Parsing uses the same eight malloc calls and no reallocs. Selected retained/peak bytes rise from 7,150 to 9,182 combined: **+2,032 bytes**. Empty final input allocates nothing beyond construction. BOM-only and invalid-zero-prefix input do not allocate decoded storage; only the context component adds capacity. UTF-16 is affected only by the raw-context component.

For the independent reset fixture, peak selected bytes rise from 11,361 to 13,295 with whole feeds, and from 11,326 to 13,246 with one-byte feeds. Nineteen semantic mallocs remain on the second parse; combined reallocations fall from one/five to zero.

The speculative decoded minimum follows `max_token_bytes`; a low `max_total_bytes` alone does not reduce it. The raw-context minimum follows `max_total_bytes`. These are minimum reservation requests, not exact capacity guarantees: the pinned byte-vector allocator also has an eight-byte minimum nonzero capacity. Existing actual allocation tracking and parser limits remain effective. A larger initial request can fail under a tight caller allocator where the previous smaller request succeeded.

## Throughput

`screening.json` retains all 560 native processes and exact commands. Five randomized four-variant blocks cover all six pinned projects, namespaces off/on, 4 KiB/64 KiB feeds, plus two generated adverse fixtures at both feeds. Each process performs one warmup and a fixed measured parse count derived from the root reference-throughput protocol: Vulkan 7, Wayland 64, Maven 128, Batik 512, GTK/DocBook 256, generated fixtures 32. This avoids the earlier tiny-batch screen limitation. CPU0 is pinned on a shared host; no outlier filtering was applied. Every callback hash, element count and text-byte count matches. All input, library and driver hashes match before and after.

| Variant | Project geomean speedup | Positive / 24 |
| --- | ---: | ---: |
| Decoded only | 0.99716× | 10 |
| Context only | 1.02032× | 19 |
| Combined | 1.00505× | 14 |

Combined project geomeans: Vulkan 1.02472×, Wayland 1.01416×, Maven 0.98610×, Batik 0.99022×, GTK 0.99890×, DocBook 1.01683×. Generated declaration results are 0.99087× / 1.00678× for 4 KiB / 64 KiB; generated entities are 1.01709× / 1.00678×. Component adverse results and every block are retained in `screening-summary.json`.

This screen compares native consumers of four Oriole builds. It does not benchmark actual CPython consumers or establish performance relative to Expat. Expat is included in the allocation attribution, not this timing cohort. No overall throughput win is inferred from the improved allocation counts.

## Validation

- 328 affected-package Rust tests pass, including selected-suite allocation-failure, global-allocation, callback reentry and owner-lifetime coverage. New tests cover empty/first/reused buffer reservations and low input/token limits for UTF-8 and UTF-16. Final strict Clippy and formatting pass.
- 1,518 exact differential cases versus the frozen control: no changes in acceptance, error, position or callbacks.
- 36,456 custom-encoding comparisons: no differences, including 28,812 full-event and 7,644 external-semantic conditions.
- 64 streaming/lifecycle conditions: stop/resume, default-current, callback switches and raw context across UTF-8/UTF-16 feeds agree.
- Six native C sanitizer runs, dynamic/static linkage, integration/adversarial/allocation tests: pass. Each linkage runs 336 allocation-failure scenarios. Release Rust libraries are not sanitizer-instrumented; LeakSanitizer is disabled because ptrace is unavailable. No whole-runtime sanitizer claim is made.
- Independent binding-reset review adds 40 C-driver ASan/UBSan processes, with the same instrumentation scope; initial LSan finalization failures are preserved and not counted as coverage.
- Original 4,740-configuration API matrix is complete and library-origin verified: 4,311 pass / 429 fail, 210 improvements / 12 regressions.

`independent-review/source-review.json` is read-only source review, with no source blocker found. `independent-review/binding-regression-review.json` records the separate independent execution and precise limitations. Their full artifacts are included.

## Reproduction

All local Cargo checks use Ohm, the existing isolated source directory `/tmp/oriole-utf8-feed`, and the stable target `/home/dev-user/.cache/oriole/utf8-feed-target`. Environment: `CARGO_HOME=/home/dev-user/.cache/toucan/cargo`, `CARGO_BUILD_BUILD_DIR=/home/dev-user/.cache/ohm/build`, both Ohm trust variables `all`, `CARGO_BUILD_JOBS=1`. Builds/checks use CPU1; probes CPU2; timing CPU0.

Commands used:

```sh
cargo +ohm test --release -p oriole -p oriole_expat
cargo +ohm clippy --release -p oriole -p oriole_expat --all-targets -- -D warnings
cargo +ohm fmt --all --check
python3 profile_variants.py
python3 alias_probes.py
python3 streaming_probe.py
python3 native_probe.py
taskset -c 0 python3 screening.py
python3 summarize_screen.py
```

Scripts and raw reports preserve exact frozen paths, commands and hashes. The baseline source archive is referenced by hash; candidate source archives are included. Build logs, original assertions and earlier failed prototype diagnostics remain available for audit.
