#define _GNU_SOURCE
#include <dlfcn.h>
#include <execinfo.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "expat.h"
static __typeof__(&XML_ParserCreate_MM) create_parser;
static __typeof__(&XML_ExternalEntityParserCreate) create_child;
static __typeof__(&XML_ParserFree) free_parser;
static __typeof__(&XML_Parse) parse;
static __typeof__(&XML_SetExternalEntityRefHandler) set_external;
static __typeof__(&XML_SetParamEntityParsing) set_parameters;
static __typeof__(&XML_GetErrorCode) get_error;
static int phase, feed_index, parse_depth;
static long malloc_budget=-1,realloc_budget=-1;
static size_t allocations,reallocations,frees;
static const char *external_text;
struct record {char op;size_t size;uintptr_t old,result;int phase,feed,depth,n;void *frames[24];};
static struct record records[32768];static size_t record_count;
static void record(char op,size_t size,uintptr_t old,void *result){
 if(record_count==32768)abort();struct record *r=&records[record_count++];
 r->op=op;r->size=size;r->old=old;r->result=(uintptr_t)result;r->phase=phase;r->feed=feed_index;r->depth=parse_depth;r->n=backtrace(r->frames,24);
}
static void *allocate(size_t size){void *p=NULL;if(phase!=1||malloc_budget!=0){p=malloc(size);if(phase==1&&malloc_budget>0)--malloc_budget;}if(phase==1)allocations++;record('m',size,0,p);return p;}
static void *reallocate(void *p,size_t size){uintptr_t old=(uintptr_t)p;void *q=NULL;if(phase!=1||realloc_budget!=0){q=realloc(p,size);if(phase==1&&realloc_budget>0)--realloc_budget;}if(phase==1)reallocations++;record('r',size,old,q);return q;}
static void release(void *p){if(phase==1)frees++;free(p);}
static int external(XML_Parser parent,const char *context,const char *base,const char *system_id,const char *public_id){
 (void)base;(void)public_id;parse_depth++;XML_Parser child=create_child(parent,context,NULL);if(!child){parse_depth--;return 0;}
 const char *text=external_text?external_text:((system_id&&strcmp(system_id,"foo")==0)?"<!ELEMENT e EMPTY>":"<e/>");
 int ok=parse(child,text,(int)strlen(text),1);free_parser(child);parse_depth--;return ok==XML_STATUS_OK;
}
static char *read_file(const char *path){FILE *f=fopen(path,"rb");if(!f)abort();fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);char *s=malloc((size_t)n+1);if(fread(s,1,(size_t)n,f)!=(size_t)n)abort();s[n]=0;fclose(f);return s;}
#define LOAD(field,name) do {*(void **)(&field)=dlsym(lib,#name);if(!field)abort();}while(0)
int main(int argc,char **argv){
 if(argc<5)return 2;void *lib=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL);if(!lib){fputs(dlerror(),stderr);return 3;}
 LOAD(create_parser,XML_ParserCreate_MM);LOAD(create_child,XML_ExternalEntityParserCreate);LOAD(free_parser,XML_ParserFree);LOAD(parse,XML_Parse);LOAD(set_external,XML_SetExternalEntityRefHandler);LOAD(set_parameters,XML_SetParamEntityParsing);LOAD(get_error,XML_GetErrorCode);
 char *text=read_file(argv[2]);if(argc>7)external_text=read_file(argv[7]);int chunk=atoi(argv[3]);size_t len=strlen(text);if(!chunk)chunk=(int)len;int namespaces=atoi(argv[4]);
 if(argc>5)malloc_budget=atol(argv[5]);if(argc>6)realloc_budget=atol(argv[6]);void *warmup[24];backtrace(warmup,24);
 XML_Memory_Handling_Suite suite={allocate,reallocate,release};XML_Parser parser=create_parser(NULL,&suite,namespaces?" ":NULL);if(!parser)abort();
 set_external(parser,external);set_parameters(parser,XML_PARAM_ENTITY_PARSING_ALWAYS);phase=1;int status=1;
 for(size_t offset=0;offset<len;offset+=(size_t)chunk){size_t n=len-offset;if(n>(size_t)chunk)n=(size_t)chunk;feed_index=(int)offset;status=parse(parser,text+offset,(int)n,offset+n==len);if(status!=XML_STATUS_OK)break;}
 int error=get_error(parser);phase=2;free_parser(parser);
 printf("{\"summary\":true,\"status\":%d,\"error\":%d,\"malloc\":%zu,\"realloc\":%zu,\"free_during_parse\":%zu,\"input_bytes\":%zu}\n",status,error,allocations,reallocations,frees,len);
 for(size_t i=0;i<record_count;i++){struct record *r=&records[i];printf("{\"op\":\"%c\",\"size\":%zu,\"old\":%zu,\"result\":%zu,\"phase\":%d,\"feed\":%d,\"depth\":%d,\"frames\":[",r->op,r->size,(size_t)r->old,(size_t)r->result,r->phase,r->feed,r->depth);
 for(int j=0;j<r->n;j++){Dl_info info;int found=dladdr(r->frames[j],&info);if(j)putchar(',');printf("{\"object\":\"%s\",\"offset\":%zu}",found?info.dli_fname:"?",found?(size_t)((uintptr_t)r->frames[j]-(uintptr_t)info.dli_fbase):0);}puts("]}");}
 free((void *)external_text);free(text);dlclose(lib);return 0;
}
