from pathlib import Path
import subprocess,json,hashlib,bisect,collections
r=Path('/tmp/oriole-allocation-followup');fixtures=json.loads((r/'fixtures.json').read_text());libraries={'oriole':Path('/tmp/oriole-event-output/control.so'),'expat':Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4')};summaries=[]
for label,lib in libraries.items():
 symbols=[]
 for line in subprocess.check_output(['nm','-S','-C','--defined-only',str(lib)],text=True).splitlines():
  f=line.split(maxsplit=3)
  if len(f)==4:
   try:a,size=int(f[0],16),int(f[1],16)
   except ValueError:continue
   symbols.append((a,size,f[3]))
 symbols.sort();addresses=[x[0] for x in symbols]
 for name,fixture in fixtures.items():
  for chunk in [0,1]:
   command=['taskset','-c','2',str(r/'profile'),str(lib),fixture['input'],str(chunk),str(int(fixture['namespaces']))];p=subprocess.run(command,capture_output=True,text=True);assert p.returncode==0,(command,p.stderr)
   output=r/(label+'-'+name+'-'+str(chunk)+'.jsonl');output.write_text(p.stdout);rows=[json.loads(x) for x in p.stdout.splitlines()];assert rows[0]['status']==1,(name,rows[0]);summary=rows[0];summary.update(library=label,fixture=name,chunk=chunk,command=command,library_sha256=hashlib.sha256(lib.read_bytes()).hexdigest(),profile=str(output))
   groups=collections.Counter();realloc_rows=[]
   for row in rows[1:]:
    functions=[]
    for frame in row['frames']:
     if frame['object']!=str(lib):continue
     i=bisect.bisect_right(addresses,frame['offset'])-1
     if i>=0 and frame['offset']<symbols[i][0]+symbols[i][1]:functions.append(symbols[i][2])
    row['functions']=functions
    if row['phase']==1 and row['op']=='r':
     groups[tuple(functions)]+=1;realloc_rows.append({k:v for k,v in row.items() if k!='frames'})
   summary['reallocation_stacks']=[{'count':n,'functions':list(k)} for k,n in groups.most_common()];summary['reallocation_rows']=realloc_rows;summaries.append(summary);print(label,name,chunk,summary['malloc'],summary['realloc'],flush=True)
(r/'profile-summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
