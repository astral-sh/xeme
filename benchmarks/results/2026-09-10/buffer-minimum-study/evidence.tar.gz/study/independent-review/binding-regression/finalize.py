from pathlib import Path
import json,gzip,hashlib,re
R=Path('/tmp/oriole-buffer-regression-review');U=Path('/home/dev-user/.cache/oriole/upstream/expat-2.8.4/expat/tests/nsalloc_tests.c')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def identify(p):return {'path':str(p),'sha256':sha(p)}
results=json.loads((R/'results.json').read_text());asan=json.loads((R/'asan-summary.json').read_text())
assert results['processes']==360 and asan['processes']==40 and not asan['failures']
for p,h in results['hashes'].items():assert sha(p)==h
assert sha(R/'probe-asan')==asan['binary_sha256']
original=U.read_text();a=original.index('/* Test the effects of reallocation failure when reassigning a');b=original.index('\nEND_TEST',a)+len('\nEND_TEST');excerpt=original[a:b];(R/'upstream-original-test.c').write_text(excerpt+'\n')
upstream={}
for label,log,want in [('control','upstream-baseline.log','pass'),('combined','upstream-reproduction.log','fail')]:
 content=(R/log).read_text();origin=re.search(r'^ORIOLE_LIBRARY\t(.+)$',content,re.M).group(1)
 rows=re.findall(r'^ORIOLE_RESULT\t([^\t]+)\ttest_nsalloc_realloc_binding_uri\t([^\t]+)\t(\d+)$',content,re.M)
 assert len(rows)==12 and all(x[1]==want for x in rows)
 if want=='fail':assert content.count('Parsing worked despite failing reallocation')==12
 upstream[label]={'log':identify(R/log),'library':identify(origin),'results':rows,'returncode':0 if want=='pass' else 1,'bounds':{'per_test_seconds':15,'address_space_bytes':4294967296,'rss_bytes':3221225472},'selected_tests':['test_nsalloc_realloc_binding_uri'],'chunk_sizes':list(range(6)),'deferral_modes':[0,1]}
assert upstream['control']['library']['sha256']==results['hashes']['/tmp/oriole-buffer-minimum/control.so']
assert upstream['combined']['library']['sha256']==results['hashes']['/tmp/oriole-buffer-minimum/combined/liboriole_expat.so']
combined0=[r['value'] for r in results['rows'] if r['library']=='combined' and r['value']['realloc_budget']==0]
assert len(combined0)==24 and all(x['status']==1 and x['error']==x['second_realloc']==x['failed_reallocations']==0 for x in combined0)
original0=[r for r in results['rows'] if not r['value']['metadata_handlers'] and r['value']['realloc_budget']==0]
assert all(r['value']['status']==0 and r['value']['error']==1 for r in original0 if r['library'] in ['expat','control','decoded'])
initial=json.loads(gzip.decompress((R/'initial-asan.json.gz').read_bytes()))
assert len(initial)==40
for x in initial:
 assert 'LeakSanitizer does not work under ptrace' in x['stderr']
 assert '"live_after_free":0' in x['stdout']
 # LSan abort may interrupt stdio flushing of the final call-array JSON.
peak=[]
for chunk in [0,1]:
 row={'chunk':chunk,'deferral':0,'metadata_handlers':False,'realloc_budget':-1}
 for name in ['expat','control','decoded','context','combined']:
  v=next(x['value'] for x in results['rows'] if x['library']==name and x['value']['chunk']==chunk and x['value']['deferral']==0 and x['value']['realloc_budget']==-1 and x['value']['metadata_handlers']==0)
  assert v['status']==1
  row[name]={k:v[k] for k in ['second_malloc','second_realloc','peak_selected_bytes']}
 peak.append(row)
report={
 'status':'classified_no_xml_or_ownership_blocker_found','reviewer':'/root/ffi/conditional_review',
 'classification':'Implementation-specific reallocation schedule assertion; original 12 upstream failures remain failures in the compatibility count.',
 'candidate':identify('/tmp/oriole-buffer-minimum/combined/liboriole_expat.so'),'candidate_source':identify('/tmp/oriole-buffer-minimum/combined/source.json'),
 'upstream_source':identify(U),'upstream_excerpt':identify(R/'upstream-original-test.c'),'upstream_lines':{'test_start':515,'first_attempt_must_fail_assertion':540,'upper_attempt_limit':524},
 'original_assertion':'The test parses a short namespace URI, resets, then parses a longer URI with malloc allowed and a reallocator that returns NULL at budget zero. It fails if the second parse succeeds at i==0, and also if none of i=0..9 succeeds. It assumes retained Expat BINDING URI storage must reallocate after reset. It does not independently assert XML metadata.',
 'unchanged_upstream_reproduction':upstream,
 'native_proof':{'processes':360,'libraries':5,'chunks':list(range(6)),'deferral_modes':[0,1],'realloc_budgets':[0,1,-1],'metadata_handler_modes':[False,True],'original_handler_configuration_processes':180,'metadata_instrumented_processes':180,'combined_budget0_successes':24,'combined_budget0_realloc_calls':0,'combined_budget0_failed_realloc_callbacks':0,'all_selected_blocks_and_bytes_zero_after_free':True,'all_successful_instrumented_namespace_element_and_text_payloads_exact':True,'results':identify(R/'results.json'),'raw_calls_and_frames':identify(R/'observations.jsonl.gz'),'selected_stacks':identify(R/'selected-stacks.json')},
 'causal_findings':[
 'Pinned Expat budget-zero failure originates in addBinding: a retained URI allocation grows from a 52-byte to an 82-byte selected request. Both whole-document and one-byte feeds return ERROR/NO_MEMORY and actually call the failed realloc once.',
 'The Oriole control also passes the original assertion, but for unrelated growth. With a whole second feed, its first rejected realloc is the retained raw-context buffer (selected request 104 to 161 bytes; before any second-parse malloc). With one-byte feeds, the first rejected realloc is a newly populated decoded Source buffer after reset (55 to 63 selected bytes at feed offset8; Decoder::feed in the recorded stack).',
 'Decoded-only reserve still encounters raw-context growth and fails at budget0. Context-only reserve succeeds for whole feeds but still encounters decoded buffer growth for small feeds. The combined candidate completes every configuration without any second-parse realloc, while continuing to use selected malloc for new semantic storage.',
 'With metadata handlers independently installed after reset, every successful result exactly reports the longer namespace-expanded doc name, empty namespace on e, matching namespace/end callbacks and expected character data. Combined budget0 does not hide an allocator failure, lose XML data, or skip a callback: there was no realloc request to reject.',
 'All360 native cases, including expected parser errors under injected realloc failure, release every tracked selected allocation. This is selected-suite lifetime accounting, not a proof of absence of arbitrary global leaks.',
 'The implementation should not add a purposeless allocation/reallocation to emulate Expat\'s BINDING cache. The original full matrix must retain 4311 passes/429 failures (210 improvements and12 regressions from4113/627); this classification does not waive or rewrite that count.'
 ],
 'memory_tradeoff':{'measurement':'Peak sum of live sizes requested through the selected C suite, including implementation allocation headers but excluding unrelated process/native allocator overhead; whole first-parse/reset/second-parse/free lifetime. Separate comparable successful/unlimited runs, no metadata handlers.', 'samples':peak,'conclusion':'For this specific fixture, combined peak rises from11361 to13295 bytes with whole feeds, and from11326 to13246 bytes with one-byte feeds. Fewer reallocations trade retained capacity for growth work; exact peak parity is not claimed.'},
 'driver_validation':{'source':identify(R/'probe.c'),'plain_binary':identify(R/'probe'),'plain_build_log':identify(R/'build.log'),'sanitized_binary':identify(R/'probe-asan'),'asan_build_log':identify(R/'build-asan.log'),'asan_summary':identify(R/'asan-summary.json'),'asan_raw':identify(R/'asan.json.gz'),'scope':'40 C-driver ASan/UBSan processes pass with detect_leaks=0; release Rust/Expat libraries are not sanitizer-instrumented. No whole-runtime sanitizer claim. Initial40 LSan-finalization failures under ptrace retained, and no LSan coverage claimed. Initial strict compiler warning for C indentation was corrected; original source/log retained.'},
 'limitations':['Only this one regression family was independently reproduced; the full4740 matrix is retained owner evidence, not rerun here.', 'Callback instrumentation is a separate variant because the original test has no handlers. The disabled-handler rows retain the original callback configuration.', 'C driver checks its own native metadata, allocation pointer ownership, failed realloc preservation and final zero-live counts; all exact observations and commands are retained.', 'No runtime source or original upstream assertion was changed. This report does not establish broad production readiness or universal allocator schedule compatibility.']
}
(R/'review.json').write_text(json.dumps(report,indent=2)+'\n')
files={str(p.relative_to(R)):sha(p) for p in sorted(R.iterdir()) if p.is_file() and p.name not in ['artifact-manifest.json','probe','probe-asan']}
(R/'artifact-manifest.json').write_text(json.dumps({'files':files,'binaries_not_copied':{str(R/name):sha(R/name) for name in ['probe','probe-asan']}},indent=2)+'\n')
print('review',sha(R/'review.json'));print('manifest',sha(R/'artifact-manifest.json'))
