from pathlib import Path
import subprocess,json,itertools,hashlib,os,gzip
R=Path('/tmp/oriole-buffer-regression-review')
r=json.loads((R/'results.json').read_text());paths={x['library']:x['command'][4] for x in r['rows']}
env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=1:abort_on_error=1';env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
rows=[]
for (name,path),chunk,budget,handlers in itertools.product(paths.items(),[0,1],[0,-1],[0,1]):
 command=['taskset','-c','5',str(R/'probe-asan'),path,str(chunk),'1',str(budget),str(handlers)]
 p=subprocess.run(command,text=True,capture_output=True,env=env,timeout=10)
 rows.append({'library':name,'command':command,'returncode':p.returncode,'stderr':p.stderr,'stdout':p.stdout})
(R/'asan.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0))
failures=[x for x in rows if x['returncode'] or x['stderr']]
report={'scope':'C diagnostic driver only compiled with ASan/UBSan; Rust/Expat shared libraries are ordinary unsanitized release artifacts. No full-runtime sanitizer claim.','processes':len(rows),'failures':len(failures),'binary_sha256':hashlib.sha256((R/'probe-asan').read_bytes()).hexdigest(),'environment':{k:env[k] for k in ['ASAN_OPTIONS','UBSAN_OPTIONS']}}
(R/'asan-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(report);assert not failures,[(x['library'],x['returncode'],x['stderr'][:100]) for x in failures]
