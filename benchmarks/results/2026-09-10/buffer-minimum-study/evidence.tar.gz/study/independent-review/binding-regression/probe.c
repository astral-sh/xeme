#define _GNU_SOURCE
#include <assert.h>
#include <dlfcn.h>
#include <execinfo.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "expat.h"
#define CAP 4096
struct block { void *p; size_t size; };
struct call { char op; size_t size; uintptr_t old, result; int phase, feed, count; void *frames[16]; };
static struct block blocks[CAP]; static struct call calls[CAP];
static size_t ncalls, live, live_bytes, peak;
static int phase, feed, budget=-1, failed, instrumentation;
static char metadata[8192], text[1024]; static size_t metadata_len, text_len;
static __typeof__(&XML_ParserCreate_MM) create_parser;
static __typeof__(&XML_ParserReset) reset_parser;
static __typeof__(&XML_ParserFree) free_parser;
static __typeof__(&XML_Parse) parse_xml;
static __typeof__(&XML_GetErrorCode) get_error;
static __typeof__(&XML_SetElementHandler) set_elements;
static __typeof__(&XML_SetNamespaceDeclHandler) set_namespaces;
static __typeof__(&XML_SetCharacterDataHandler) set_text;
static __typeof__(&XML_SetReparseDeferralEnabled) set_deferral;
static void remember(void *p, size_t size) {
  assert(p); for (size_t i=0;i<CAP;i++) if(!blocks[i].p){blocks[i]=(struct block){p,size};live++;live_bytes+=size;if(live_bytes>peak)peak=live_bytes;return;} abort();
}
static void forget(void *p) {
  if (!p) return;
  for (size_t i=0; i<CAP; i++) {
    if (blocks[i].p == p) {
      live--; live_bytes -= blocks[i].size;
      blocks[i] = (struct block){0};
      return;
    }
  }
  abort();
}
static void record(char op,size_t size,uintptr_t old,void *result){
  assert(ncalls<CAP);struct call *r=&calls[ncalls++];*r=(struct call){.op=op,.size=size,.old=old,.result=(uintptr_t)result,.phase=phase,.feed=feed};
  if(op=='r')r->count=backtrace(r->frames,16);
}
static void *allocate(size_t size){void *p=malloc(size);if(p)remember(p,size);record('m',size,0,p);return p;}
static void *reallocate(void *p,size_t size){
  assert(size);uintptr_t old=(uintptr_t)p;void *result=NULL;
  if(phase==3 && budget==0){failed++;record('r',size,old,NULL);return NULL;}
  if(phase==3 && budget>0)budget--;
  // Save the slot before realloc so no expired pointer is compared afterward.
  size_t slot=CAP,old_size=0;if(p){for(size_t i=0;i<CAP;i++)if(blocks[i].p==p){slot=i;old_size=blocks[i].size;break;}assert(slot<CAP);}
  result=realloc(p,size);
  if(result){if(slot<CAP){blocks[slot]=(struct block){result,size};live_bytes=live_bytes-old_size+size;if(live_bytes>peak)peak=live_bytes;}else remember(result,size);}
  record('r',size,old,result);return result;
}
static void release(void *p){uintptr_t old=(uintptr_t)p;forget(p);free(p);record('f',0,old,NULL);}
static void append(const char *kind,const char *value){int n=snprintf(metadata+metadata_len,sizeof(metadata)-metadata_len,"%s:%s|",kind,value?value:"(null)");assert(n>=0&&(size_t)n<sizeof(metadata)-metadata_len);metadata_len+=(size_t)n;}
static void start(void *p,const XML_Char *name,const XML_Char **attrs){(void)p;assert(!attrs[0]);append("start",name);}
static void end(void *p,const XML_Char *name){(void)p;append("end",name);}
static void ns_start(void *p,const XML_Char *prefix,const XML_Char *uri){(void)p;assert(!prefix);append("ns",uri);}
static void ns_end(void *p,const XML_Char *prefix){(void)p;assert(!prefix);append("ns-end",prefix);}
static void content(void *p,const XML_Char *s,int n){(void)p;assert(n>=0&&(size_t)n<sizeof(text)-text_len);memcpy(text+text_len,s,(size_t)n);text_len+=(size_t)n;text[text_len]=0;}
static int parse_document(XML_Parser p,const char *xml,int chunk){
 int remaining=(int)strlen(xml);feed=0;
 if(chunk>0)while(remaining>chunk){int result=parse_xml(p,xml,chunk,0);if(result!=XML_STATUS_OK)return result;xml+=chunk;remaining-=chunk;feed+=chunk;}
 return parse_xml(p,xml,remaining,1);
}
static void string_json(const char *s){putchar('"');for(;*s;s++){unsigned char v=(unsigned char)*s;if(v=='"'||v=='\\')printf("\\%c",v);else if(v<32)printf("\\u%04x",v);else putchar(v);}putchar('"');}
#define LOAD(field,name) do{*(void**)(&field)=dlsym(lib,#name);assert(field);}while(0)
int main(int argc,char **argv){
 assert(argc==6);int chunk=atoi(argv[2]),deferral=atoi(argv[3]);int requested=atoi(argv[4]);instrumentation=atoi(argv[5]);
 void *lib=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL);if(!lib){fputs(dlerror(),stderr);return 2;}
 LOAD(create_parser,XML_ParserCreate_MM);LOAD(reset_parser,XML_ParserReset);LOAD(free_parser,XML_ParserFree);LOAD(parse_xml,XML_Parse);LOAD(get_error,XML_GetErrorCode);LOAD(set_elements,XML_SetElementHandler);LOAD(set_namespaces,XML_SetNamespaceDeclHandler);LOAD(set_text,XML_SetCharacterDataHandler);LOAD(set_deferral,XML_SetReparseDeferralEnabled);
 void *warm[16];backtrace(warm,16);
 const char *first="<doc xmlns='http://example.org/'>\n  <e xmlns='' />\n</doc>";
 const char *second="<doc xmlns='http://example.org/long/enough/URI/to/reallocate/'>\n  <e xmlns='' />\n</doc>";
 XML_Memory_Handling_Suite suite={allocate,reallocate,release};XML_Parser p=create_parser(NULL,&suite," ");assert(p);assert(set_deferral(p,deferral));
 phase=1;int initial=parse_document(p,first,chunk);assert(initial==XML_STATUS_OK);
 phase=2;assert(reset_parser(p,NULL));assert(set_deferral(p,deferral));
 if(instrumentation){set_elements(p,start,end);set_namespaces(p,ns_start,ns_end);set_text(p,content);}
 phase=3;budget=requested;int status=parse_document(p,second,chunk);int error=get_error(p);size_t second_malloc=0,second_realloc=0;
 for(size_t i=0;i<ncalls;i++)if(calls[i].phase==3){second_malloc+=calls[i].op=='m';second_realloc+=calls[i].op=='r';}
 phase=4;free_parser(p);assert(live==0&&live_bytes==0);
 printf("{\"chunk\":%d,\"deferral\":%d,\"realloc_budget\":%d,\"metadata_handlers\":%d,\"status\":%d,\"error\":%d,\"failed_reallocations\":%d,\"second_malloc\":%zu,\"second_realloc\":%zu,\"live_after_free\":%zu,\"live_bytes_after_free\":%zu,\"peak_selected_bytes\":%zu,\"metadata\":",chunk,deferral,requested,instrumentation,status,error,failed,second_malloc,second_realloc,live,live_bytes,peak);string_json(metadata);printf(",\"text\":");string_json(text);printf(",\"calls\":[");
 for(size_t i=0;i<ncalls;i++){struct call *r=&calls[i];if(i)putchar(',');printf("{\"op\":\"%c\",\"size\":%zu,\"old\":%zu,\"result\":%zu,\"phase\":%d,\"feed\":%d,\"frames\":[",r->op,r->size,(size_t)r->old,(size_t)r->result,r->phase,r->feed);for(int j=0;j<r->count;j++){Dl_info info;int found=dladdr(r->frames[j],&info);if(j)putchar(',');printf("{\"object\":");string_json(found?info.dli_fname:"?");printf(",\"offset\":%zu}",found?(size_t)((uintptr_t)r->frames[j]-(uintptr_t)info.dli_fbase):0);}printf("]}");}puts("]}");dlclose(lib);return 0;
}
