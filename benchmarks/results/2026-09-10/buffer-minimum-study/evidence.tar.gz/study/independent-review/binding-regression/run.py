from pathlib import Path
import gzip,hashlib,itertools,json,subprocess,time
R=Path('/tmp/oriole-buffer-regression-review')
libs={'expat':'/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','control':'/tmp/oriole-buffer-minimum/control.so','decoded':'/tmp/oriole-buffer-minimum/decoded/liboriole_expat.so','context':'/tmp/oriole-buffer-minimum/context/liboriole_expat.so','combined':'/tmp/oriole-buffer-minimum/combined/liboriole_expat.so'}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
hashes={p:sha(p) for p in libs.values()};hashes[str(R/'probe')]=sha(R/'probe');hashes[str(R/'probe.c')]=sha(R/'probe.c')
rows=[];failures=[]
with gzip.open(R/'observations.jsonl.gz','wt') as stream:
 for (name,path),chunk,deferral,budget,handlers in itertools.product(libs.items(),range(6),[0,1],[0,1,-1],[0,1]):
  cmd=['taskset','-c','5',str(R/'probe'),path,str(chunk),str(deferral),str(budget),str(handlers)]
  p=subprocess.run(cmd,text=True,capture_output=True,timeout=10)
  row={'library':name,'command':cmd,'returncode':p.returncode,'stderr':p.stderr}
  if p.returncode==0:
   row['value']=json.loads(p.stdout)
   v=row['value'];assert v['live_after_free']==v['live_bytes_after_free']==0
   if handlers and v['status']==1:
    uri='http://example.org/long/enough/URI/to/reallocate/'
    expect=f'ns:{uri}|start:{uri} doc|ns:(null)|start:e|end:e|ns-end:(null)|end:{uri} doc|ns-end:(null)|'
    assert v['metadata']==expect,(name,chunk,deferral,budget,v)
    assert v['text']=='\n  \n',v
  else:row['stdout']=p.stdout;failures.append(row)
  stream.write(json.dumps(row)+'\n');rows.append({**row,'value':{k:v for k,v in row.get('value',{}).items() if k!='calls'}})
assert all(sha(p)==h for p,h in hashes.items())
assert not failures,failures
summary={'status':'passed','scope':'Independent selected-allocation C fixture reproducing the first parse/reset/second parse of original test. Budget0 rejects every realloc only during second parse; malloc remains allowed. Handler-disabled runs match original callback configuration; handler-enabled runs independently verify exact expanded names, namespace callbacks and concatenated character data. Budgets1/unlimited are controls. Every parser free must leave zero selected live blocks/bytes; original upstream assertions are separately rerun unchanged.','hashes':hashes,'processes':len(rows),'failures':failures,'rows':rows}
(R/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
for name in libs:
 zero=[r['value'] for r in rows if r['library']==name and r['value']['realloc_budget']==0 and not r['value']['metadata_handlers']]
 print(name,'budget0 statuses/errors/realloc/failures',sorted(set((r['status'],r['error'],r['second_realloc'],r['failed_reallocations']) for r in zero)))
print('all',len(rows),'processes passed; every successful instrumented result exact; every free zero live')
