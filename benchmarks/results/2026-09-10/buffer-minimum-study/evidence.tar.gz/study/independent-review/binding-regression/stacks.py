import gzip,json,subprocess,bisect,hashlib
from pathlib import Path
R=Path('/tmp/oriole-buffer-regression-review');cache={}
def function(frame):
 p=frame['object']
 if p not in cache:
  symbols=[]
  for line in subprocess.check_output(['nm','-S','-C','--defined-only',p],text=True,stderr=subprocess.DEVNULL).splitlines():
   f=line.split(maxsplit=3)
   if len(f)==4:
    try:a,n=int(f[0],16),int(f[1],16)
    except ValueError:continue
    symbols.append((a,n,f[3]))
  symbols.sort();cache[p]=(symbols,[s[0] for s in symbols])
 sy,ad=cache[p];i=bisect.bisect_right(ad,frame['offset'])-1
 return sy[i][2] if i>=0 and frame['offset']<sy[i][0]+sy[i][1] else '?'
rows=[]
for line in gzip.open(R/'observations.jsonl.gz','rt'):
 row=json.loads(line);v=row['value'];library=row['command'][4]
 if v['chunk'] in [0,1] and v['deferral']==0 and v['realloc_budget']==0 and v['metadata_handlers']==0:
  reallocations=[]
  for index,call in enumerate(v['calls']):
   if call['op']=='r' and call['phase']==3:
    prior=[x for x in v['calls'][:index] if x['result'] and x['result']==call['old']]
    frames=[function(f) for f in call['frames'] if f['object']==library]
    reallocations.append({'size':call['size'],'feed':call['feed'],'old_size':prior[-1]['size'] if prior else None,'old_phase':prior[-1]['phase'] if prior else None,'functions':frames})
  rows.append({'library':row['library'],**{k:v[k] for k in ['chunk','status','error','failed_reallocations','second_malloc','second_realloc','peak_selected_bytes']},'reallocations':reallocations})
(R/'selected-stacks.json').write_text(json.dumps(rows,indent=2)+'\n')
