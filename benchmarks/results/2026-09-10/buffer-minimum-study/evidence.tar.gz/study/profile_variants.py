from pathlib import Path
import json,subprocess,hashlib
r=Path('/tmp/oriole-buffer-minimum');probe=Path('/tmp/oriole-allocation-followup/profile');out=r/'allocation-profiles';out.mkdir(exist_ok=True)
fixtures=json.loads(Path('/tmp/oriole-allocation-followup/fixtures.json').read_text())
for name,data in [('tiny',b'<r/>'),('empty',b''),('bom-only',b'\xef\xbb\xbf'),('invalid-prefix',b'\xff<r/>'),('tiny-utf16',b'\xff\xfe'+ '<r/>'.encode('utf-16-le'))]:
 path=out/(name+'.xml');path.write_bytes(data);fixtures[name]={'input':str(path),'namespaces':False}
libraries={'control':r/'control.so','decoded':r/'decoded/liboriole_expat.so','context':r/'context/liboriole_expat.so','combined':r/'combined/liboriole_expat.so','expat':Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4')}
rows=[]
for label,library in libraries.items():
 for name,fixture in fixtures.items():
  for chunk in [0,1]:
   command=['taskset','-c','2',str(probe),str(library),fixture['input'],str(chunk),str(int(fixture['namespaces']))];p=subprocess.run(command,capture_output=True,text=True,timeout=20);assert p.returncode==0,(command,p.stderr)
   path=out/(label+'-'+name+'-'+str(chunk)+'.jsonl');path.write_text(p.stdout);summary=json.loads(p.stdout.splitlines()[0]);summary.update(label=label,fixture=name,chunk=chunk,command=command,raw_profile=str(path),library_sha256=hashlib.sha256(library.read_bytes()).hexdigest());rows.append(summary)
(r/'allocation-variants.json').write_text(json.dumps({'scope':'Selected suite allocation counts and requested live/peak bytes, with backtraces. Process/library timing is not measured. External children use the same chunk size as the root, as in original upstream helper. Core/FFI floor reservations remain charged to the selected allocator.','driver_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path('/tmp/oriole-allocation-followup/profile.c').read_bytes()).hexdigest(),'rows':rows},indent=2)+'\n')
for name in ['tiny','empty','bom-only','invalid-prefix','tiny-utf16','test_nsalloc_realloc_long_context','test_alloc_realloc_many_attributes']:
 print(name,[(x['label'],x['chunk'],x['status'],x['malloc'],x['realloc'],x['create_live'],x['retained_live'],x['peak_live']) for x in rows if x['fixture']==name],flush=True)
