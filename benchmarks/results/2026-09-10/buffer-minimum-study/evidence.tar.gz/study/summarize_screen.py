from pathlib import Path
from collections import defaultdict
import json,statistics,hashlib
root=Path(__file__).parent
raw=json.loads((root/'screening.json').read_text())
assert raw.get('status')=='passed'
assert raw['hashes_before']==raw['hashes_after']
groups=defaultdict(list)
for row in raw['rows']:
 groups[(row['workload'],row['chunk'],row['namespaces'])].append(row)
conditions=[]
for (workload,chunk,ns),rows in groups.items():
 assert len(rows)==5
 condition={'workload':workload,'chunk':chunk,'namespaces':ns,'variants':{}}
 for label in ['decoded','context','combined']:
  samples=[r['speedups'][label] for r in rows]
  condition['variants'][label]={'median_speedup':statistics.median(samples),'min_block_speedup':min(samples),'max_block_speedup':max(samples),'block_speedups':samples}
 conditions.append(condition)
assert len(conditions)==28 and len(raw['rows'])==140
report={'scope':raw['scope'],'raw_sha256':hashlib.sha256((root/'screening.json').read_bytes()).hexdigest(),'status':'passed','processes':sum(len(r['processes']) for r in raw['rows']),'conditions':conditions,'variants':{}}
for label in ['decoded','context','combined']:
 projects=[c['variants'][label]['median_speedup'] for c in conditions if not c['workload'].startswith('generated-')]
 report['variants'][label]={'real_project_geomean_speedup':statistics.geometric_mean(projects),'positive_project_conditions':sum(x>1 for x in projects),'total_project_conditions':len(projects),'project_geomeans':{name:statistics.geometric_mean(c['variants'][label]['median_speedup'] for c in conditions if c['workload']==name) for name in sorted({c['workload'] for c in conditions if not c['workload'].startswith('generated-')})},'generated_conditions':[{'workload':c['workload'],'chunk':c['chunk'],**c['variants'][label]} for c in conditions if c['workload'].startswith('generated-')]}
(root/'screening-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['variants'],indent=2))
