from pathlib import Path
import hashlib,json,random,statistics,subprocess,time
root=Path('/tmp/oriole-capi-profile')
lib=Path('/tmp/oriole-final-encoding-checkpoint/liboriole_expat.so')
reference=Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so')
rows=[]
rng=random.Random(20260910)
for pair in range(3):
 for workload in ['elements','entities','empty-elements']:
  for chunk in [4096,1048576]:
   modes=['safe-system','safe-tracked','c-api','expat'];rng.shuffle(modes)
   for mode in modes:
    if mode.startswith('safe'):
     command=[str(root/'safe-driver'),'tracked' if mode=='safe-tracked' else 'system',str(root/(workload+'.xml')),str(chunk),'10']
    else:
     command=[str(root/'native-driver'),str(lib if mode=='c-api' else reference),str(root/(workload+'.xml')),str(chunk),'10']
    command=['taskset','-c','3',*command]
    completed=subprocess.run(command,text=True,capture_output=True,timeout=60,check=True)
    data=json.loads(completed.stdout);samples=[x for x in data['samples'] if not x['warmup']]
    (root/f'{pair}-{workload}-{chunk}-{mode}.json').write_text(completed.stdout)
    rows.append({'pair':pair,'workload':workload,'chunk':chunk,'mode':mode,'command':command,'median_seconds':statistics.median(x['seconds'] for x in samples),'hash':samples[0]['hash']})
summary={}
for workload in ['elements','entities','empty-elements']:
 for chunk in [4096,1048576]:
  group=[x for x in rows if x['workload']==workload and x['chunk']==chunk]
  assert len({x['hash'] for x in group})==1,(workload,chunk)
  result={mode:statistics.median(x['median_seconds'] for x in group if x['mode']==mode) for mode in ['safe-system','safe-tracked','c-api','expat']}
  summary[f'{workload}/{chunk}']=result
  print(workload,chunk,{k:round(v*1000,3) for k,v in result.items()},flush=True)
counts=[]
for workload in ['elements','entities','empty-elements']:
 for mode in ['safe-system','safe-tracked','c-api','expat']:
  if mode.startswith('safe'):
   command=[str(root/'safe-counts'),'tracked' if mode=='safe-tracked' else 'system',str(root/(workload+'.xml')),'1048576','1']
  else:
   command=[str(root/'native-counts'),str(lib if mode=='c-api' else reference),str(root/(workload+'.xml')),'1048576','1']
  completed=subprocess.run(['taskset','-c','3',*command],text=True,capture_output=True,timeout=60,check=True)
  counts.append({'workload':workload,'mode':mode,'stdout':json.loads(completed.stdout),'stderr':completed.stderr})
report={'rows':rows,'summary_seconds':summary,'counts':counts,'limitations':['Shared host; CPU frequency and other workload activity uncontrolled.','perf_event_paranoid=4 prohibits sampling; this is differential timing/allocation attribution.','C uses real tracking. Safe tracked variant adds all known direct input bytes before parsing; C charges each chunk when fed.','Instrumented allocation runs are separate from timings.'],'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [lib,reference,root/'safe-driver',root/'native-driver',root/'safe-counts',root/'native-counts',root/'src/main.rs',root/'Cargo.toml',root/'native_driver.c',root/'native_counts.c']}}
(root/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print('completed',flush=True)
