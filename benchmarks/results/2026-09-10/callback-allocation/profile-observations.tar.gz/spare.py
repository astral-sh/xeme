from pathlib import Path
import hashlib,json,random,statistics,subprocess
root=Path('/tmp/oriole-capi-profile')
libraries={'baseline':Path('/tmp/oriole-final-encoding-checkpoint/liboriole_expat.so'),'spare':root/'liboriole_expat-spare.so'}
rows=[];rng=random.Random(20260910)
for pair in range(3):
 for workload in ['elements','entities','empty-elements']:
  for chunk in [4096,1048576]:
   order=list(libraries);rng.shuffle(order)
   for variant in order:
    cmd=['taskset','-c','3',str(root/'native-driver'),str(libraries[variant]),str(root/(workload+'.xml')),str(chunk),'10']
    result=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=60)
    data=json.loads(result.stdout);samples=[x for x in data['samples'] if not x['warmup']]
    (root/f'spare-{pair}-{workload}-{chunk}-{variant}.json').write_text(result.stdout)
    rows.append({'pair':pair,'workload':workload,'chunk':chunk,'variant':variant,'command':cmd,'seconds':statistics.median(x['seconds'] for x in samples),'hash':samples[0]['hash']})
summary={}
for workload in ['elements','entities','empty-elements']:
 for chunk in [4096,1048576]:
  subset=[x for x in rows if x['workload']==workload and x['chunk']==chunk]
  assert len({x['hash'] for x in subset})==1
  pairs=[next(x['seconds'] for x in subset if x['pair']==p and x['variant']=='baseline')/next(x['seconds'] for x in subset if x['pair']==p and x['variant']=='spare') for p in range(3)]
  summary[f'{workload}/{chunk}']={'speedup':statistics.median(pairs),'baseline_ms':statistics.median(x['seconds'] for x in subset if x['variant']=='baseline')*1000,'spare_ms':statistics.median(x['seconds'] for x in subset if x['variant']=='spare')*1000}
counts=[]
for workload in ['elements','entities','empty-elements']:
 r=subprocess.run(['taskset','-c','3',str(root/'native-counts'),str(libraries['spare']),str(root/(workload+'.xml')),'1048576','1'],text=True,capture_output=True,check=True,timeout=60)
 counts.append({'workload':workload,'stdout':json.loads(r.stdout),'stderr':r.stderr})
report={'summary':summary,'rows':rows,'counts':counts,'library_sha256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in libraries.items()}}
(root/'spare-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(summary,indent=2));print(counts)
