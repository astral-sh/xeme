"""Replay the original threshold probe without overwriting its evidence."""
from pathlib import Path
import hashlib
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from xml_abi import Expat

root = Path(__file__).resolve().parent
base = Expat('/tmp/oriole-final-encoding-checkpoint/liboriole_expat.so')
candidate = Expat(str(root / 'liboriole_expat-spare.so'))
rows = []
inputs = []
for count in [0, 1, 2, 7, 8, 9, 16, 17, 32, 100]:
    for empty in [False, True]:
        attrs = ' '.join(f'a{i}="' + ('' if empty else f'välue{i}') + '"' for i in range(count))
        xml = f'<élément {attrs}/>'.encode()
        inputs.append({'attributes': count, 'empty_values': empty, 'xml_hex': xml.hex()})
        for chunk in [1, 7, 4096]:
            a = base.parse(xml, chunk)
            b = candidate.parse(xml, chunk)
            assert a == b, (count, empty, chunk)
            rows.append({'attributes': count, 'empty_values': empty, 'chunk': chunk,
                         'status': b['status'],
                         'hash': hashlib.sha256(json.dumps(b).encode()).hexdigest()})
# The original one-off shell script wrote a literal trailing backslash-n.
original = json.loads((root / 'spare-threshold-checks.json').read_text().removesuffix('\\n'))
assert rows == original, 'Replayed outputs differ from preserved original evidence'
(root / 'spare-threshold-replay.json').write_text(json.dumps({'rows': rows, 'inputs': inputs}, indent=2) + '\n')
print(f'{len(rows)} exact original threshold results reproduced')
