#!/home/dev-user/.virtualenvs/openai/bin/python3
import sys
print("partial output")
print("fixture failure",file=sys.stderr)
raise SystemExit(7)
