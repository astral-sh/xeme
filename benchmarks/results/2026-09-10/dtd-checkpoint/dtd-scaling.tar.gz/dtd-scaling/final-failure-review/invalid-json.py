#!/home/dev-user/.virtualenvs/openai/bin/python3
print("{not valid json")
