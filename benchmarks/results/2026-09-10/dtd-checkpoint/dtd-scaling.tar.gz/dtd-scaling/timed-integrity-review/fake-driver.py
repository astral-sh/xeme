#!/home/dev-user/.virtualenvs/openai/bin/python3
from pathlib import Path
import json,sys
meta=json.loads((Path(sys.argv[2]).parent/'manifest.json').read_text())[Path(sys.argv[2]).name]
sample={'trace':'fixed-trace','hash':'same-preflight' if '--trace' in sys.argv else 'changed-timed','declarations':meta['expected_declarations'],'external_calls':meta['expected_external_calls'],'seconds':1.0}
print(json.dumps({'version':'fixture','samples':[sample|{'warmup':True},sample|{'warmup':False}]}))
