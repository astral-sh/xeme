from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,time
root=Path('/tmp/oriole-consume-accounted');repo=Path('/home/dev-user/code/oss/oriole');driver=Path('/tmp/oriole-shared-dtd-implementation/benchmark/driver');profiler_root=Path('/home/dev-user/.cache/oriole/profilers/local/usr');profiler=profiler_root/'bin/valgrind';annotator=profiler_root/'bin/callgrind_annotate';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
libs={'control':root/'control.so','candidate':root/'liboriole_expat.so'};fixtures={'wayland':repo/'benchmarks/projects/corpus/wayland/wayland.xml','maven':repo/'benchmarks/projects/corpus/maven/pom.xml'};env={**os.environ,'VALGRIND_LIB':str(profiler_root/'libexec/valgrind')};files=[Path(__file__),driver,profiler,annotator,*libs.values(),*fixtures.values(),root/'source.json'];hashes={str(p):sha(p) for p in files};report={'status':'incomplete','scope':'Callgrind XML_Parse instructions including callbacks, with one warmup and one measured parse both collected. Constructor/free/IO/dlopen excluded by toggle; no wall-time throughput claim. Same root profiler command/configuration, CPU7.','hashes':hashes,'rows':[]}
try:
 for name,ns in [('wayland',False),('maven',True)]:
  observations={}
  for label,lib in libs.items():
   stem=f'{name}-{label}';output=root/(stem+'.out');cmd=['taskset','-c','7',str(profiler),'--tool=callgrind','--toggle-collect=XML_Parse','--callgrind-out-file='+str(output),str(driver),str(lib),str(fixtures[name]),'4096','1']+(['namespaces'] if ns else []);started=time.time();r=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=180);(root/(stem+'.stdout')).write_text(r.stdout);(root/(stem+'.stderr')).write_text(r.stderr)
   row={'workload':name,'namespaces':ns,'library':label,'command':cmd,'returncode':r.returncode,'wall_seconds':time.time()-started};report['rows'].append(row);assert r.returncode==0
   data=json.loads(r.stdout);observations[label]=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in data['samples']});row['observations']=observations[label];row['instructions']=int(re.search(r'^summary: (\d+)',output.read_text(),re.M)[1]);assert row['instructions']>0
   a=subprocess.run([str(annotator),'--auto=no','--threshold=100','--show-percs=no',str(output)],capture_output=True,text=True,env=env,timeout=60);assert a.returncode==0;(root/(stem+'.txt')).write_text(a.stdout)
  assert observations['control']==observations['candidate']
 report['ratios']={name:next(r['instructions'] for r in report['rows'] if r['workload']==name and r['library']=='candidate')/next(r['instructions'] for r in report['rows'] if r['workload']==name and r['library']=='control') for name in fixtures}
 assert all(sha(Path(p))==h for p,h in hashes.items());report['status']='passed'
finally:(root/'profile.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report.get('ratios'),indent=2))
