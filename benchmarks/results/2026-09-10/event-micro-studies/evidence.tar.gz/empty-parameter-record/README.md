# Avoid moving an empty parameter-entity record

This isolated candidate adds a presence check before taking `active_parameter_reference`. The ordinary None path no longer copies its 88-byte record or writes another None. Some handling and name-buffer destruction stay in the original scope. No new field, allocation, work limit, or input-position change is introduced.

Base: Git `353dc3f19ebe6554b8c224a400c588bdf49e901a` / library `e6849aa2`. Candidate library: `5eab71c7`. `candidate.patch` is the complete change. Source/archive/library hashes are retained; no binaries are bundled.

## Validation

- All 323 release core/FFI tests, including existing selected-allocator sweeps, passed. Formatting and strict release Clippy passed.
- 432 parameter-child publication cases are unchanged, retaining nine prior reference callback differences.
- 4,104 DOCTYPE handler-mutation/suspension cases match Expat; 15,288 custom-provenance and 2,392 malformed cases are unchanged; 32 raw-input/DefaultCurrent/suspension checks passed.
- Exact x86_64 assembly places the discriminant branch before all record loads on None. The stack frame remains `0x588`; there is no stack-size claim.

## Performance scope

Four Callgrind processes compare exact frozen libraries on Wayland and Maven with namespaces. Each collects one warmup and one measured parse inside `XML_Parse`, including callbacks, while excluding constructor/free/IO. Candidate/control instruction ratios are 0.998081 and 0.996429. Metadata matches. These are instruction counts, not throughput measurements.

The first local 240-second compilation wrapper expired before tests ran; its incomplete log is retained. The unchanged test command completed with a longer build deadline. No test assertion or upstream retry ceiling changed.

Runtime acceptance remains deferred to a combined-base comparison. No CPU0 timing, new full upstream matrix, or sanitizer campaign is claimed here. Some paths gain one predicate, so this small saving must not be described as a broad speedup.
