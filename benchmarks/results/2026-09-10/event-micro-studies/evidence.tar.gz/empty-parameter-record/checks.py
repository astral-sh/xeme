from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/tmp/oriole-parameter-none-evidence');src=Path('/tmp/oriole-parameter-none')
env={**os.environ,'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/parameter-none-target','CARGO_INCREMENTAL':'0'}
rows=[]
for label,tail in [('fmt',['fmt','--all','--','--check']),('clippy',['clippy','--release','-p','oriole','-p','oriole_expat','--all-targets','--','-D','warnings']),('tests',['test','--release','-p','oriole','-p','oriole_expat'])]:
 cmd=['taskset','-c','6','cargo','+ohm',*tail];start=time.time()
 with (root/(label+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
 rows.append({'label':label,'command':cmd,'cwd':str(src),'environment':{k:env[k] for k in ['CARGO_HOME','CARGO_BUILD_BUILD_DIR','CARGO_TARGET_DIR','CARGO_INCREMENTAL']},'returncode':r.returncode,'seconds':time.time()-start,'log_sha256':hashlib.sha256((root/(label+'.log')).read_bytes()).hexdigest()});(root/'check-commands.json').write_text(json.dumps(rows,indent=2)+'\n');assert r.returncode==0,(label,r.returncode)
print('fmt, strict release clippy and all core/FFI release tests passed')
