from pathlib import Path
import gzip,hashlib,json,re,shutil,tarfile
root=Path('/tmp/oriole-parameter-none-evidence');dst=Path('/tmp/oriole-parameter-none-handoff');source=Path('/tmp/oriole-parameter-none');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((root/'check-commands.json').read_text());assert len(checks)==3 and all(c['returncode']==0 for c in checks)
manifest=json.loads((root/'source.json').read_text());assert all(sha(source/p)==h for p,h in manifest['files'].items())
assert sha(root/'liboriole_expat.so')=='5eab71c7b3d0a5529d778946dd6b0a752065e60a1b4f002198de519860d433fb'
assert sha(root/'control.so')=='e6849aa2cc0d75c74b42370ecd568c6dd7581dfadbc892244176a6a03acf576d'
tests=(root/'tests.log').read_text();test_rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',tests);assert test_rows and all(int(f)==0 for p,f,i in test_rows)
validation=json.loads((root/'validation-summary.json').read_text());profile=json.loads((root/'profile.json').read_text());assert profile['status']=='passed'
dst.mkdir(exist_ok=True)
for p in root.iterdir():
    if not p.is_file() or p.suffix in ['.so','.a'] or p.name=='baseline-source.tar':continue
    data=p.read_bytes()
    if len(data)>100_000 and p.suffix in ['.json','.log','.out','.asm','.txt']:
        (dst/(p.name+'.gz')).write_bytes(gzip.compress(data,mtime=0))
    else:shutil.copy2(p,dst/p.name)
(dst/'baseline-source.tar.gz').write_bytes(gzip.compress((root/'baseline-source.tar').read_bytes(),mtime=0))
with tarfile.open(dst/'source.tar.gz','w:gz') as tar:
    for name in manifest['files']:tar.add(source/name,arcname=name)
helpers=dst/'helpers';helpers.mkdir(exist_ok=True)
for p in [Path('/tmp/oriole-shared-dtd-implementation/doctype.py'),Path('/tmp/oriole-shared-dtd-implementation/run_clean.py'),Path('/tmp/oriole-missing-parameter/oracle.py'),Path('/tmp/oriole-custom-final/probes/external-compare.py'),Path('/tmp/oriole-custom-alias-external-source.py'),Path('/home/dev-user/code/oss/oriole/tools/xml_abi.py'),Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')]:
    shutil.copy2(p,helpers/p.name)
summary={'status':'source-validated candidate; runtime acceptance deferred to combined-base measurement',
'base_commit':manifest['base'],'base_library_sha256':sha(root/'control.so'),'candidate_library_sha256':sha(root/'liboriole_expat.so'),'source_manifest_sha256':sha(root/'source.json'),'patch_sha256':sha(root/'candidate.patch'),
'change':'Test whether active_parameter_reference is populated before taking the owned tuple. Some processing, work/positions, and drop scope are unchanged; None avoids the full record move.',
'assembly':{'none_copy_bytes_avoided':88,'none_write_avoided':True,'same_stack_frame_bytes':1416,'scope':'Exact x86_64 optimized library pair; no claimed stack-size reduction or result for other compiler/targets.'},
'checks':{'fmt':True,'strict_release_clippy_core_ffi_all_targets':True,'release_core_ffi_tests':sum(int(p) for p,f,i in test_rows),'test_summary_rows':len(test_rows),'selected_allocator_failure_and_global_routing_sweeps':'Included in unmodified core allocation integration suite',**validation},
'profile':{'candidate_over_control_Ir':profile['ratios'],'scope':profile['scope'],'processes':4},
'limits':['The initial240-second local compilation wrapper expired before tests ran; its incomplete log is retained. The unchanged command passed with a longer build deadline onCPU5. No test assertions or upstream retry ceilings changed.','No CPU0 timings or throughput claim for this isolated candidate.','No new upstream4740 replay or sanitizer campaign in this layer; full release core/FFI plus named targeted oracles are the reported checks.','Some paths gain a discriminant predicate and retain their existing copy; the measured instruction saving is small.','The nine existing reference differences in legal parameter-child publication are retained explicitly.','No root checkout edits; root owns independent review, composition and runtime acceptance.']}
(dst/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(dst/'README.md').write_text(f'''# Avoid moving an empty parameter-entity record

This isolated candidate adds a presence check before taking `active_parameter_reference`. The ordinary None path no longer copies its 88-byte record or writes another None. Some handling and name-buffer destruction stay in the original scope. No new field, allocation, work limit, or input-position change is introduced.

Base: Git `{manifest['base']}` / library `e6849aa2`. Candidate library: `5eab71c7`. `candidate.patch` is the complete change. Source/archive/library hashes are retained; no binaries are bundled.

## Validation

- All {summary['checks']['release_core_ffi_tests']} release core/FFI tests, including existing selected-allocator sweeps, passed. Formatting and strict release Clippy passed.
- 432 parameter-child publication cases are unchanged, retaining nine prior reference callback differences.
- 4,104 DOCTYPE handler-mutation/suspension cases match Expat; 15,288 custom-provenance and 2,392 malformed cases are unchanged; 32 raw-input/DefaultCurrent/suspension checks passed.
- Exact x86_64 assembly places the discriminant branch before all record loads on None. The stack frame remains `0x588`; there is no stack-size claim.

## Performance scope

Four Callgrind processes compare exact frozen libraries on Wayland and Maven with namespaces. Each collects one warmup and one measured parse inside `XML_Parse`, including callbacks, while excluding constructor/free/IO. Candidate/control instruction ratios are {profile['ratios']['wayland']:.6f} and {profile['ratios']['maven']:.6f}. Metadata matches. These are instruction counts, not throughput measurements.

The first local 240-second compilation wrapper expired before tests ran; its incomplete log is retained. The unchanged test command completed with a longer build deadline. No test assertion or upstream retry ceiling changed.

Runtime acceptance remains deferred to a combined-base comparison. No CPU0 timing, new full upstream matrix, or sanitizer campaign is claimed here. Some paths gain one predicate, so this small saving must not be described as a broad speedup.
''')
artifacts={str(p.relative_to(dst)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(dst.rglob('*')) if p.is_file() and p.name!='artifact-manifest.json'}
for p in dst.rglob('*'):
    if p.is_file():assert p.open('rb').read(4)!=b'\x7fELF'
(dst/'artifact-manifest.json').write_text(json.dumps({'artifacts':artifacts},indent=2)+'\n')
print(json.dumps({'path':str(dst),'artifacts':len(artifacts),'summary_sha256':sha(dst/'summary.json'),'artifact_manifest_sha256':sha(dst/'artifact-manifest.json')},indent=2))
