from pathlib import Path
import os,signal,subprocess,time,json,hashlib,shutil
root=Path('/tmp/oriole-parameter-none-evidence');src=Path('/tmp/oriole-parameter-none');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copy2(root/'tests.log',root/'tests-initial-compile-timeout.log')
initial={'label':'tests-initial-incomplete','command':['taskset','-c','6','cargo','+ohm','test','--release','-p','oriole','-p','oriole_expat'],'timeout_seconds':240,'status':'wrapper_timeout_during_compilation','test_assertion_failure':False,'log_sha256':sha(root/'tests-initial-compile-timeout.log'),'scope':'Local full-suite compilation wrapper expired before test execution. No upstream or runtime/test assertion limits were changed.'};(root/'initial-compile-timeout.json').write_text(json.dumps(initial,indent=2)+'\n')
env={**os.environ,'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/parameter-none-target','CARGO_INCREMENTAL':'0'};cmd=['taskset','-c','5','cargo','+ohm','test','--release','-p','oriole','-p','oriole_expat'];start=time.time();timedout=False
with (root/'tests.log').open('w') as f:
 p=subprocess.Popen(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 try:status=p.wait(timeout=1800)
 except subprocess.TimeoutExpired:timedout=True;os.killpg(p.pid,signal.SIGKILL);status=p.wait()
entry={'label':'tests','command':cmd,'cwd':str(src),'environment':{k:env[k] for k in ['CARGO_HOME','CARGO_BUILD_BUILD_DIR','CARGO_TARGET_DIR','CARGO_INCREMENTAL']},'returncode':status,'timeout_seconds':1800,'timed_out':timedout,'seconds':time.time()-start,'log_sha256':sha(root/'tests.log'),'previous_incomplete_attempt':'initial-compile-timeout.json'}
rows=json.loads((root/'check-commands.json').read_text());rows.append(entry);(root/'check-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(entry,indent=2));assert status==0 and not timedout
