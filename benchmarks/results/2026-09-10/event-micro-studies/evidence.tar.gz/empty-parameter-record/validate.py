from pathlib import Path
import gzip,hashlib,json,subprocess,time
root=Path('/tmp/oriole-parameter-none-evidence');py='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12';clean='/tmp/oriole-shared-dtd-implementation/run_clean.py';commands=[]
# Keep the original fixtures and only select frozen engines/output paths.
for name in ['malformed_probe.py','streaming_probe.py']:
 source=Path('/tmp/oriole-forbidden-marker-evidence/final')/name
 (root/name).write_text(source.read_text().replace("root=Path('/tmp/oriole-forbidden-marker-evidence/final')",f"root=Path('{root}')"))
p=Path('/tmp/oriole-shared-dtd-tiny-profile/validation/custom-provenance.py');s=p.read_text().replace("out=Path('/tmp/oriole-shared-dtd-tiny-profile/validation')",f"out=Path('{root}')").replace("'/tmp/oriole-shared-dtd-implementation/liboriole_expat.so'",f"'{root/'control.so'}'").replace("'/tmp/oriole-shared-dtd-tiny-profile/split.so'",f"'{root/'liboriole_expat.so'}'");(root/'custom-provenance.py').write_text(s)
p=Path('/tmp/oriole-shared-dtd-tiny-profile/validation/publication.py');s=p.read_text().replace("LIBRARIES={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','baseline':'/tmp/oriole-shared-dtd-tiny-profile/split.so'}",f"LIBRARIES={{'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','baseline':'{root/'control.so'}','candidate':'{root/'liboriole_expat.so'}'}}").replace("out=Path('/tmp/oriole-shared-dtd-tiny-profile/validation')",f"out=Path('{root}')");(root/'publication.py').write_text(s)
for name,args in [('publication',[str(root/'publication.py')]),('doctype',['/tmp/oriole-shared-dtd-implementation/doctype.py',str(root/'liboriole_expat.so'),str(root/'doctype.json.gz')]),('custom-provenance',[str(root/'custom-provenance.py')]),('malformed_probe',[str(root/'malformed_probe.py')]),('streaming_probe',[str(root/'streaming_probe.py')])]:
 cmd=['taskset','-c','5',py,'-I','-S',clean,*args];start=time.time()
 with (root/(name+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 commands.append({'label':name,'command':cmd,'returncode':r.returncode,'seconds':time.time()-start,'log_sha256':hashlib.sha256((root/(name+'.log')).read_bytes()).hexdigest()});(root/'validation-commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert r.returncode==0,name
p=json.loads((root/'observations.json').read_text());assert p['cases']==432;change=sum(r['baseline']!=r['candidate'] for r in p['observations']);assert change==0
with gzip.open(root/'doctype.json.gz','rt') as f:d=json.load(f)
assert d['cases']==4104 and d['differences']==0
with gzip.open(root/'custom-provenance.json.gz','rt') as f:c=json.load(f)
assert c['changed_from_baseline']==0
summary={'publication_cases':432,'publication_changes':change,'publication_retained_reference_differences':p['differences'],'doctype_cases':4104,'doctype_differences':d['differences'],'custom_provenance_cases':c['cases'],'custom_changes':c['changed_from_baseline'],'malformed_cases':json.loads((root/'malformed-probe.json').read_text())['cases'],'streaming_cases':len(json.loads((root/'streaming-probe.json').read_text())['rows'])}
(root/'validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
