from pathlib import Path
import ctypes as C
import gzip,hashlib,itertools,json
ROOT=Path('/tmp/oriole-performance-falsification');P=C.c_void_p;S=C.c_char_p;I=C.c_int
START=C.CFUNCTYPE(None,P,S,C.POINTER(S));TEXT=C.CFUNCTYPE(None,P,P,I);CONVERT=C.CFUNCTYPE(I,P,P);RELEASE=C.CFUNCTYPE(None,P)
class Encoding(C.Structure):_fields_=[('map',I*256),('data',P),('convert',CONVERT),('release',RELEASE)]
UNKNOWN=C.CFUNCTYPE(I,P,S,C.POINTER(Encoding))
PATHS={'current':'/tmp/oriole-attribute-markers/control.so','attribute-marker':'/tmp/oriole-attribute-markers/liboriole_expat.so','output-slot':'/tmp/oriole-event-output/liboriole_expat.so','accounting-control':'/tmp/oriole-consume-accounted/control.so','accounting':'/tmp/oriole-consume-accounted/liboriole_expat.so'}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def setup(path):
 lib=C.CDLL(path)
 for n,args,ret in [('XML_ParserCreateNS',[S,C.c_char],P),('XML_ParserCreate',[S],P),('XML_ParserFree',[P],None),('XML_Parse',[P,S,I,I],I),('XML_GetErrorCode',[P],I),('XML_GetCurrentByteIndex',[P],C.c_long),('XML_SetParamEntityParsing',[P,I],I),('XML_SetUnknownEncodingHandler',[P,UNKNOWN,P],None),('XML_SetStartElementHandler',[P,START],None),('XML_SetDefaultHandlerExpand',[P,TEXT],None)]:
  fn=getattr(lib,n);fn.argtypes=args;fn.restype=ret
 return lib

def run(lib,data,width,ns,default):
 p=lib.XML_ParserCreateNS(None,b'|') if ns else lib.XML_ParserCreate(None);assert p
 events=[];errors=[];counts={'unknown':0,'convert':0,'release':0}
 @CONVERT
 def convert(_,ptr):counts['convert']+=1;return C.string_at(ptr,2)[1]
 @RELEASE
 def release(_):counts['release']+=1
 @UNKNOWN
 def unknown(_,name,info):
  counts['unknown']+=1
  for i in range(256):info.contents.map[i]=i if i<128 else -1
  info.contents.map[128]=-2;info.contents.map[195]=-2
  # UTF8 é below uses a dedicated second lead rather than converting its trail byte.
  info.contents.convert=dispatch_convert;info.contents.release=release;info.contents.data=None;return 1
 @CONVERT
 def dispatch_convert(_,ptr):
  pair=C.string_at(ptr,2)
  if pair[0]==195:counts['convert']+=1;return 0xe9 if pair[1]==169 else -1
  return convert(None,ptr)
 @START
 def start(_,name,attrs):
  try:
   values=[];i=0
   while attrs[i]:values.append([attrs[i].decode(),attrs[i+1].decode()]);i+=2
   events.append(['start',name.decode(),values,lib.XML_GetCurrentByteIndex(p)])
  except BaseException as e:errors.append(repr(e))
 @TEXT
 def fallback(_,ptr,n):
  try:
   value=C.string_at(ptr,n).decode()
   if events and events[-1][0]=='default':events[-1][1]+=value
   else:events.append(['default',value])
  except BaseException as e:errors.append(repr(e))
 lib.XML_SetUnknownEncodingHandler(p,unknown,None);lib.XML_SetStartElementHandler(p,start);lib.XML_SetParamEntityParsing(p,2)
 if default:lib.XML_SetDefaultHandlerExpand(p,fallback)
 try:
  step=width or len(data);status=1
  for offset in range(0,len(data),step):
   part=data[offset:offset+step];status=lib.XML_Parse(p,part,len(part),offset+step>=len(data))
   if status!=1:break
  result={'status':status,'error':lib.XML_GetErrorCode(p),'byte_index':lib.XML_GetCurrentByteIndex(p),'events':events,'callback_errors':errors}
 finally:lib.XML_ParserFree(p)
 assert counts['unknown']==counts['release']==1,(counts,result)
 assert not errors,errors
 result['callbacks']=counts;return result

engines={k:setup(p) for k,p in PATHS.items()};hashes={p:sha(p) for p in PATHS.values()};prefix=b"<?xml version='1.0' encoding='x-independent'?>"
templates={
 'direct':b"<r a='L@@\xc3\xa9R'/>",
 'alias-and-reference':b"<r a='L@@&amp;\xc3\xa9R'/>",
 'alias-and-invalid-less-than':b"<r a='L@@<R'/>",
 'default':b'<!DOCTYPE r [<!ATTLIST r a CDATA "L@@R">]><r/>',
 'tokenized':b'<!DOCTYPE r [<!ATTLIST r a NMTOKENS #IMPLIED>]><r a=" L@@R "/>',
 'replacement':b'<!DOCTYPE r [<!ENTITY e "L@@R">]><r a="&e;"/>',
 'replacement-default':b'<!DOCTYPE r [<!ENTITY e "L@@R"><!ATTLIST r a CDATA "&e;">]><r/>',
 'raw-then-alias':b"<r a='L&amp;@@\r\nR'/>",
}
rows=[];changes=[]
for (name,template),scalar,width,ns,default in itertools.product(templates.items(),[0,9,10,13,32,34,38,39,60,62,65],[0,1,7],[False,True],[False,True]):
 data=prefix+template.replace(b'@@',bytes([128,scalar]));values={k:run(lib,data,width,ns,default) for k,lib in engines.items()}
 changed=[k for k,base in [('attribute-marker','current'),('output-slot','current'),('accounting','accounting-control')] if values[k]!=values[base]]
 row={'template':name,'scalar':scalar,'width':width,'namespaces':ns,'default':default,'input_hex':data.hex(),'changes':changed,'values':values};rows.append(row)
 if changed:changes.append(row)
assert all(sha(p)==h for p,h in hashes.items())
report={'status':'passed' if not changes else 'differences','scope':'New bounded custom-encoding falsification fixtures; raw ASCII marker versus multibyte ASCII aliases and a real decoded nonASCII scalar, direct/default/tokenized/general-replacement attributes, invalid alias NUL, handler absence/default presence, byte chunks. Every initialized encoding releases exactly once. Each candidate compared to its frozen control; no claim all prior behavior matches Expat.','libraries':hashes,'templates':{k:v.hex() for k,v in templates.items()},'cases':len(rows),'parser_invocations':len(rows)*len(engines),'changed_cases':len(changes),'observations':rows}
(ROOT/'custom.json.gz').write_bytes(gzip.compress(json.dumps(report,indent=2).encode(),mtime=0));print(json.dumps({k:report[k] for k in ['status','cases','parser_invocations','changed_cases']},indent=2));assert not changes
