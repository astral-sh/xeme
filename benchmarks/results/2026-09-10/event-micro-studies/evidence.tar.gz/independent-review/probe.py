from pathlib import Path
import ctypes as C
import gzip,hashlib,itertools,json,runpy

ROOT=Path('/tmp/oriole-performance-falsification')
helpers=runpy.run_path('/tmp/oriole-consume-accounted/oracle.py')
PATHS={
 'current':'/tmp/oriole-attribute-markers/control.so',
 'attribute-marker':'/tmp/oriole-attribute-markers/liboriole_expat.so',
 'output-slot':'/tmp/oriole-event-output/liboriole_expat.so',
 'accounting-control':'/tmp/oriole-consume-accounted/control.so',
 'accounting':'/tmp/oriole-consume-accounted/liboriole_expat.so',
}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
hashes={p:sha(p) for p in PATHS.values()};engines={k:helpers['setup'](p) for k,p in PATHS.items()}
CASES=[
 ('ascii-markers',"<r a='&amp;é&lt;🙂&gt;'/>",{}),
 ('literal-less-than',"<r a='é🙂<x'/>",{}),
 ('incomplete-after-unicode',"<r a='À·\ue000🙂&bad'/>",{}),
 ('zero-reference',"<r a='é&#0;🙂'/>",{}),
 ('prefix-events-on-error',"<r xmlns:p='u' q:a='é&am;'/>",{}),
 ('prefix-events-undefined',"<r xmlns:p='u' q:a='é&amp;'/>",{}),
 ('tokenized-frame-boundary',"<!DOCTYPE r [<!ENTITY a 'é&#13;'><!ENTITY b '&#10;🙂'><!ATTLIST r a NMTOKENS #IMPLIED>]><r a=' \t&a;&b;&a; '/>",{}),
 ('default-frame-boundary',"<!DOCTYPE r [<!ENTITY a 'é&#13;'><!ENTITY b '&#10;🙂'><!ATTLIST r a CDATA '&a;&b;'>]><r/>",{}),
 ('predefined-accounting',"<r a='&amp;&amp;&amp;'/>"+' '*4096,{}),
 ('character-accounting',"<r a='&#38;&#38;&#38;'/>"+' '*4096,{}),
 ('replacement-accounting',"<!DOCTYPE r [<!ENTITY a '"+'é'*70+"'><!ENTITY b '&a;&a;&a;'>]><r a='&b;&b;'/>",{}),
 ('external-dtd-attribute',"<!DOCTYPE r SYSTEM 'd'><r a='é&e;🙂'/>",{'d':"<!--é--><?p x?><!ENTITY e 'A&#13;&#10;B'><!ATTLIST r a NMTOKENS #IMPLIED>"}),
 ('external-parameter-dtd',"<!DOCTYPE r SYSTEM 'd'><r/>",{'d':"<!ENTITY % p SYSTEM 'p'>%p;",'p':"<!ENTITY e 'é&#13;🙂'><!ATTLIST r a CDATA '&e;'>"}),
]
rows=[];changes=[]
for (name,xml,external),chunk,encoding,namespace,(factor,threshold) in itertools.product(CASES,[0,1,2,7,31],['utf-8','utf-16','utf-16-be'],[False,True],[(1,0),(1.01,0),(2,0),(100,0),(1.01,4096)]):
 values={k:helpers['run'](e,xml,external,chunk,encoding,namespace,factor,threshold) for k,e in engines.items()}
 changed=[k for k,control in [('attribute-marker','current'),('output-slot','current'),('accounting','accounting-control')] if values[k]!=values[control]]
 row={'case':name,'chunk':chunk,'encoding':encoding,'namespace':namespace,'factor':factor,'threshold':threshold,'changes':changed,'values':values};rows.append(row)
 if changed:changes.append(row)
assert all(sha(p)==h for p,h in hashes.items())
report={'status':'passed' if not changes else 'differences','scope':'Independent new bounded falsification fixtures: UTF8/UTF16 LE BOM/BE signature, literal versus entity marker boundaries, tokenized/default/internal/external DTD attributes, pending namespace-prefix errors, low relative amplification settings. Compare each candidate with its exact frozen control. No reference compatibility pass claim for pre-existing behavior.','hashes':hashes,'inputs':{name:{'xml':xml,'external':external,'encoded_hex':{e:xml.encode(e).hex() for e in ['utf-8','utf-16','utf-16-be']}} for name,xml,external in CASES},'cases':len(rows),'parser_invocations':len(rows)*len(engines),'changed_cases':len(changes),'observations':rows}
(ROOT/'boundary-limits.json.gz').write_bytes(gzip.compress(json.dumps(report,indent=2).encode(),mtime=0));print(json.dumps({k:report[k] for k in ['status','cases','parser_invocations','changed_cases']},indent=2));assert not changes
