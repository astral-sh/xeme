from pathlib import Path
import hashlib,json,gzip,tarfile,shutil
R=Path('/tmp/oriole-performance-falsification')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,data):Path(p).write_text(json.dumps(data,indent=2)+'\n')
def identify(p):return {'path':str(p),'sha256':digest(p)}
def loadz(p):return json.loads(gzip.decompress(Path(p).read_bytes()))
boundary=loadz(R/'boundary-limits.json.gz');custom=loadz(R/'custom.json.gz');stream=json.loads((R/'streaming-probe.json').read_text())
assert boundary['cases']==1950 and custom['cases']==1056 and len(stream['rows'])==32
assert boundary['changed_cases']==custom['changed_cases']==0
for p,h in boundary['hashes'].items():assert digest(p)==h
for p,h in custom['libraries'].items():assert digest(p)==h
for p,h in stream['hashes'].items():assert digest(p)==h
for a,b in zip(stream['rows'][:16],stream['rows'][16:]):assert {k:v for k,v in a.items() if k!='library'}=={k:v for k,v in b.items() if k!='library'}
base=Path('/tmp/oriole-attribute-markers');account=Path('/tmp/oriole-consume-accounted');out=Path('/tmp/oriole-event-output')
probes={
 'boundary_and_relative_limits': {'cases':1950,'parser_invocations':9750,'candidate_control_changes':0,'scope':'13 new UTF8/UTF16LE-BOM/UTF16BE-signature fixtures; five chunk widths; namespaces on/off; five relative amplification/activation settings. Compares parse status, error code, final byte/line/column, Start/End/Attlist callbacks and child status/error. Exact fixture strings and encoded root bytes retained. This probe does not install every callback.','observations':identify(R/'boundary-limits.json.gz'),'generator':identify(R/'probe.py')},
 'custom_aliases': {'cases':1056,'parser_invocations':5280,'candidate_control_changes':0,'scope':'Eight direct/default/tokenized/general-entity attribute templates; 11 multibyte scalar aliases including NUL, whitespace, quotes, ampersand and less-than; a decoded nonASCII scalar; whole/one/seven-byte feeds; namespaces and Default handler presence. Compares Start payload/index, concatenated adjacent Default payload, status/error/index, converter counts and exactly-once encoding initialization/release. Exact input bytes retained.','observations':identify(R/'custom.json.gz'),'generator':identify(R/'custom.py')},
}
limits=['Independent review does not certify whole-parser safety or broad Expat conformance. Each candidate is compared with its own frozen Oriole control; existing compatibility differences are not counted as passes against Expat.', 'Boundary probe checks selected callbacks; custom probe concatenates adjacent Default fragments and therefore proves payload content/order relative to other events, not unchanged fragment boundaries.', 'No new builds, Rust suites, upstream suites, sanitizer campaigns, selected-allocation sweeps or timings were run for this review. Existing suite/test source was inspected; its execution remains separately reported by the implementation owner.', 'Absolute/token/depth work limits are covered by source invariants here; dynamic falsification explicitly varies relative amplification and activation thresholds.']
attribute={
 'status':'no_blocker_found','reviewer':'/root/ffi/conditional_review','scope':'Read-only source review and new bounded falsification of the one-line attribute marker search.',
 'patch':identify(base/'candidate.patch'),'source_manifest':identify(base/'source.json'),
 'control':identify(base/'control.so'),'candidate':identify(base/'liboriole_expat.so'),
 'reviewed_sources':{str(base/'source'/p):digest(base/'source'/p) for p in ['crates/oriole/src/lib.rs','crates/oriole/src/lexical.rs','crates/oriole/src/encoding.rs','crates/oriole/src/accounting.rs']},
 'invariants':[
 {'location':'crates/oriole/src/lib.rs:3264','conclusion':'Both operations return the first byte index of literal ASCII ampersand (0x26) or less-than (0x3c) in the same lexical Slice. An ASCII byte cannot be a UTF8 leading or continuation byte for another scalar, so every returned boundary and no-match length are identical.'},
 {'location':'crates/oriole/src/lexical.rs:24,33,235','conclusion':'Slice dereferences to lexical UTF8 text. Multibyte ASCII aliases retain nonASCII lexical representatives (NameStart U+00C0, NameChar U+00B7, other ASCII U+E000) plus sparse conversion metadata. memchr2 sees the same representatives as str::find, so aliases do not become lexical delimiters; genuine representative characters remain distinguished by metadata offsets.'},
 {'location':'crates/oriole/src/lib.rs:3264 and append_lexical_attribute:3541','conclusion':'The identical end controls source frame advancement, indirect byte accounting and for_slice ranges. Converted scalar restoration, attribute whitespace normalization, literal less-than rejection, entity recursion/depth checks and all existing limits are unchanged.'},
 {'location':'crates/oriole/src/lib.rs:3264','conclusion':'The replacement does not allocate or retain pointers. No callback delivery, event ownership or selected allocator path changes.'}],
 'new_probes':probes,'findings':[],'limitations':limits,
}
write(R/'attribute-marker-review.json',attribute)
prior=json.loads((account/'independent-source-review.json').read_text())
for p,h in prior['hashes'].items():assert digest(p)==h
accounting={
 'status':'no_blocker_found','reviewer':'/root/ffi/conditional_review','scope':'Independent falsification addendum to prior source review; frozen accounting candidate compared only against its own 9362 control, not newer e684 control.',
 'prior_source_review':identify(account/'independent-source-review.json'),'patch':identify(account/'candidate.patch'),'source_manifest':identify(account/'source.json'),'control':identify(account/'control.so'),'candidate':identify(account/'liboriole_expat.so'),
 'rechecked_invariants':[
 'account_source(end) remains before complete-token copy and semantic processing. All inspected successful semantic paths preserve active Source/cursor/raw mapping before the final consume; XML callbacks are queued and cannot run in this interval.',
 'Source::accounting_bytes(end) is zero after this prefix was marked. EntityBudget::account returns true immediately for zero bytes, before reading counters/limits, so removing that second zero account does not remove a later amplification check after attribute expansion.',
 'The identical Source::consume(end) still advances raw positions, newline state, cursor, deferred scanner and compaction. First charge, token copy, decoded raw swap, parsed? error propagation and all nonzero expansion charges remain in their original order.',
 'Custom conversion representatives/raw width metadata and allocation/error prefix behavior are not modified. The debug assertion documents an invariant rather than providing a release-time safety check; future source-changing semantic operations would require revisiting this substitution.'
 ],'new_probes':probes,'findings':[],'limitations':limits,
}
write(R/'accounting-falsification-review.json',accounting)
final=json.loads((out/'final-source.json').read_text())
with tarfile.open(out/'final-source.tar.gz') as archive:fs={m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
with tarfile.open(out/'source.tar.gz') as archive:ms={m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
assert len(fs)==len(final['files'])==64
for p,h in final['files'].items():assert hashlib.sha256(fs[p]).hexdigest()==h
changes=[p for p in fs if fs[p]!=ms.get(p)]
assert set(changes)=={'crates/oriole/src/dtd_tables.rs','crates/oriole/src/recycling.rs','crates/oriole/tests/allocation.rs','crates/oriole/tests/event_output.rs','crates/oriole_expat/src/lib.rs'}
ffi='crates/oriole_expat/src/lib.rs'
assert ms[ffi].replace(b'        // SAFETY: No references to parser fields escape this scope or cross\n        // dispatch. The busy guard prevents freeing or reparsing the core.\n        let mut event = None;\n',b'        let mut event = None;\n        // SAFETY: No references to parser fields escape this scope or cross\n        // dispatch. The busy guard prevents freeing or reparsing the core.\n')==fs[ffi]
output={
 'status':'no_blocker_found','reviewer':'/root/ffi/conditional_review','scope':'Read-only independent audit of the complete f7876ae patch, owned output slot and FFI dispatch/error paths, plus targeted dynamic falsification on the frozen measured runtime.',
 'full_patch':identify(out/'event-output-with-tests.patch'),'runtime_patch':identify(out/'event-output.patch'),'measured_source_manifest':identify(out/'source.json'),'final_source_manifest':identify(out/'final-source.json'),'final_source_archive':identify(out/'final-source.tar.gz'),'verified_final_archive_files':64,
 'control':identify(base/'control.so'),'candidate':identify(out/'liboriole_expat.so'),
 'source_lineage':{'runtime_core_unchanged_between_measured_and_final':True,'changed_files':changes,'ffi_difference':'Only moves the existing SAFETY comment immediately before its unsafe block; exact text replacement verified. Other changed/new files contain tests only, reviewed in full patch.'},
 'reviewed_sources':{p:final['files'][p] for p in ['crates/oriole/src/lib.rs',ffi,'crates/oriole/src/dtd_tables.rs','crates/oriole/src/recycling.rs','crates/oriole/tests/allocation.rs','crates/oriole/tests/event_output.rs']},
 'ownership_and_control_flow':[
 {'location':'crates/oriole/src/lib.rs:1349','conclusion':'The adapter API clears a previously owned slot before entering parser work. The existing next_event API uses a fresh local None. These are the only entrances to private next_event_into, establishing an empty output on every iteration.'},
 {'location':'crates/oriole/src/lib.rs:1396-1512,1769','conclusion':'Every event write in next_event_scoped/inner immediately returns success. NeedMore/finished/custom-conversion paths leave None. Err paths never populate a stale slot. NoMemory and cleanup allocation failure clear pending state and leave None; queued namespace prefix/cleanup events are still delivered in original order before the retained terminal error.'},
 {'location':'crates/oriole/src/dtd_tables.rs:77,121','conclusion':'Shared-table publication remains confined to with_dtd_tables. Its Scope owns table headers and drops before return; publication cannot allocate or fail after an event was written. No table guard or parser borrow crosses C callbacks.'},
 {'location':'crates/oriole_expat/src/lib.rs:1140-1206','conclusion':'FFI keeps an owned local Option<Event>, obtains the recycling token while the core is exclusively borrowed, ends that borrow, extracts the owned event, updates the same position before dispatch and invokes callbacks under the existing busy guard. Abort/suspend/default-fragment/unknown-encoding retry checks remain in order. The expect follows the API invariant that a token exists iff the slot contains an event.'},
 {'location':'crates/oriole/src/lib.rs:1349,1368; crates/oriole/src/recycling.rs','conclusion':'Recycling identity and selected-allocation ownership are unchanged. Clearing the slot drops its existing event before parsing, as documented. Event strings and attributes own their storage; retaining an event does not retain references into a parser or shared-table guard.'}
 ],
 'test_source_review':['Owned event traces against old API across UTF8/UTF16/chunks; malformed namespace prefix event ordering.', 'Prefilled slot clearing on NeedMore, terminal errors and retries, shared-table contention and recoverable UnknownEncoding.', 'Selected allocator failure sweep asserts output None and no allocations on terminal retry; existing allocator routing harness reused.', 'Wrong-parser/reset recycling token checks and retained event surviving original parser destruction.'],
 'new_probes':{**probes,'suspension_raw_context_and_handler_changes':{'parser_invocations':32,'status':'passed','paired_control_candidate_differences':0,'scope':'UTF8/UTF16, eight feed widths; every text callback suspends, calls DefaultCurrent and checks current raw byte index/count against GetInputContext and original input. Character handler changes after first event. Resumed concatenation and callback/raw hashes match control.','generator':identify(R/'streaming.py'),'observations':identify(R/'streaming-probe.json')}},
 'findings':[],'limitations':limits+['Final library was built before test-only and SAFETY-comment-placement additions. Final archive matches measured runtime behavior by reviewed exact diff; this review does not claim a new build of those final tests. No throughput or assembly result was independently audited here.'],
}
write(R/'output-slot-review.json',output)
# Retain exact dependencies while preserving the generators actually executed.
for original,name in [('/tmp/oriole-consume-accounted/oracle.py','dependency-accounting-oracle.py'),('/tmp/oriole-shared-dtd-implementation/run_clean.py','dependency-run-clean.py'),('/home/dev-user/code/oss/oriole/tools/xml_abi.py','dependency-xml-abi.py')]:
 shutil.copyfile(original,R/name)
write(R/'executions.json',{'status':'passed','cpu':5,'environment':'Managed CPython 3.12.13 -I -S through retained run_clean wrapper; shared libraries checked before and after; no local Rust builds.', 'commands':[{'command':['taskset','-c','5','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S','/tmp/oriole-shared-dtd-implementation/run_clean.py',str(R/p)],'exit_code':0,'log':identify(R/log)} for p,log in [('probe.py','probe.log'),('custom.py','custom.log'),('streaming.py','streaming.log')]],'note':'Exit codes observed from completed execution sessions; streams and exact generators retained. Generators reference their original helper paths; exact helper copies are retained for reproduction.'})
files={str(p.relative_to(R)):digest(p) for p in sorted(R.iterdir()) if p.is_file() and p.name!='artifact-manifest.json'}
write(R/'artifact-manifest.json',{'files':files,'status':'complete','scope':'Independent review plus bounded dynamic falsification; no binaries or source changes.'})
for p in ['attribute-marker-review.json','accounting-falsification-review.json','output-slot-review.json','artifact-manifest.json']:print(p,digest(R/p))
