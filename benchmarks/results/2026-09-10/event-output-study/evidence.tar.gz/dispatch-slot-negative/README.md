# Local dispatch-slot experiment

Rejected at the initial code-generation gate. Dispatch receives a mutable reference only to the caller’s stack-local owned Option<Event>, takes ownership before any callback, then uses every original match branch. The caller copy disappears, but dispatch makes the same 112-byte payload copy into its own stack frame. Maven XML_Parse instructions are effectively unchanged: 23,220,272→23,231,630 (+0.049%).

The exact source, overlay, assembly, library, build log, and instruction profile are retained. No broader tests or throughput measurements are claimed. The positive core output-slot experiment is independent and unchanged.
