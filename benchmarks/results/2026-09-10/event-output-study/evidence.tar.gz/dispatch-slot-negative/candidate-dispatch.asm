
/tmp/oriole-dispatch-slot/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000033e80 <oriole_expat::dispatch>:
   33e80:	55                   	push   %rbp
   33e81:	41 57                	push   %r15
   33e83:	41 56                	push   %r14
   33e85:	41 55                	push   %r13
   33e87:	41 54                	push   %r12
   33e89:	53                   	push   %rbx
   33e8a:	48 81 ec 88 06 00 00 	sub    $0x688,%rsp
   33e91:	48 8b 06             	mov    (%rsi),%rax
   33e94:	48 c7 06 ff ff ff ff 	movq   $0xffffffffffffffff,(%rsi)
   33e9b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   33e9f:	0f 84 e2 55 00 00    	je     39487 <oriole_expat::dispatch+0x5607>
   33ea5:	49 89 fe             	mov    %rdi,%r14
   33ea8:	0f 10 46 68          	movups 0x68(%rsi),%xmm0
   33eac:	0f 11 84 24 90 01 00 	movups %xmm0,0x190(%rsp)
   33eb3:	00 
   33eb4:	0f 10 46 58          	movups 0x58(%rsi),%xmm0
   33eb8:	0f 11 84 24 80 01 00 	movups %xmm0,0x180(%rsp)
   33ebf:	00 
   33ec0:	0f 10 46 48          	movups 0x48(%rsi),%xmm0
   33ec4:	0f 11 84 24 70 01 00 	movups %xmm0,0x170(%rsp)
   33ecb:	00 
   33ecc:	0f 10 46 08          	movups 0x8(%rsi),%xmm0
   33ed0:	0f 10 4e 18          	movups 0x18(%rsi),%xmm1
   33ed4:	0f 10 56 28          	movups 0x28(%rsi),%xmm2
   33ed8:	0f 10 5e 38          	movups 0x38(%rsi),%xmm3
   33edc:	0f 11 9c 24 60 01 00 	movups %xmm3,0x160(%rsp)
   33ee3:	00 
   33ee4:	0f 11 94 24 50 01 00 	movups %xmm2,0x150(%rsp)
   33eeb:	00 
   33eec:	0f 11 8c 24 40 01 00 	movups %xmm1,0x140(%rsp)
   33ef3:	00 
   33ef4:	0f 11 84 24 30 01 00 	movups %xmm0,0x130(%rsp)
   33efb:	00 
   33efc:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
   33f03:	00 
   33f04:	0f 10 46 78          	movups 0x78(%rsi),%xmm0
   33f08:	0f 10 8e 88 00 00 00 	movups 0x88(%rsi),%xmm1
   33f0f:	0f 11 8f 30 0a 00 00 	movups %xmm1,0xa30(%rdi)
   33f16:	48 83 e8 03          	sub    $0x3,%rax
   33f1a:	b9 0d 00 00 00       	mov    $0xd,%ecx
   33f1f:	48 0f 43 c8          	cmovae %rax,%rcx
   33f23:	0f 11 87 20 0a 00 00 	movups %xmm0,0xa20(%rdi)
   33f2a:	48 83 f9 19          	cmp    $0x19,%rcx
   33f2e:	0f 92 c0             	setb   %al
   33f31:	41 bf 00 80 40 01    	mov    $0x1408000,%r15d
   33f37:	41 d3 ef             	shr    %cl,%r15d
   33f3a:	41 20 c7             	and    %al,%r15b
   33f3d:	80 bf 08 0a 00 00 00 	cmpb   $0x0,0xa08(%rdi)
   33f44:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
   33f49:	75 08                	jne    33f53 <oriole_expat::dispatch+0xd3>
   33f4b:	49 8b 06             	mov    (%r14),%rax
   33f4e:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   33f53:	45 84 ff             	test   %r15b,%r15b
   33f56:	74 16                	je     33f6e <oriole_expat::dispatch+0xee>
   33f58:	41 83 be 48 0a 00 00 	cmpl   $0xffffffff,0xa48(%r14)
   33f5f:	ff 
   33f60:	74 0c                	je     33f6e <oriole_expat::dispatch+0xee>
   33f62:	4d 8b ae 78 0a 00 00 	mov    0xa78(%r14),%r13
   33f69:	49 ff cd             	dec    %r13
   33f6c:	eb 03                	jmp    33f71 <oriole_expat::dispatch+0xf1>
   33f6e:	45 31 ed             	xor    %r13d,%r13d
   33f71:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
   33f78:	00 
   33f79:	48 89 84 24 70 04 00 	mov    %rax,0x470(%rsp)
   33f80:	00 
   33f81:	49 8b be 50 09 00 00 	mov    0x950(%r14),%rdi
   33f88:	49 8b 86 58 09 00 00 	mov    0x958(%r14),%rax
   33f8f:	48 89 84 24 d0 05 00 	mov    %rax,0x5d0(%rsp)
   33f96:	00 
   33f97:	49 8b 86 60 09 00 00 	mov    0x960(%r14),%rax
   33f9e:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
   33fa5:	00 
   33fa6:	4d 8b 86 68 09 00 00 	mov    0x968(%r14),%r8
   33fad:	4d 8b 9e 70 09 00 00 	mov    0x970(%r14),%r11
   33fb4:	49 8b 86 78 09 00 00 	mov    0x978(%r14),%rax
   33fbb:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
   33fc2:	00 
   33fc3:	49 8b 86 80 09 00 00 	mov    0x980(%r14),%rax
   33fca:	48 89 84 24 a0 05 00 	mov    %rax,0x5a0(%rsp)
   33fd1:	00 
   33fd2:	49 8b 86 88 09 00 00 	mov    0x988(%r14),%rax
   33fd9:	48 89 84 24 b0 05 00 	mov    %rax,0x5b0(%rsp)
   33fe0:	00 
   33fe1:	49 8b 86 90 09 00 00 	mov    0x990(%r14),%rax
   33fe8:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
   33fef:	00 
   33ff0:	49 8b 86 98 09 00 00 	mov    0x998(%r14),%rax
   33ff7:	48 89 84 24 c0 05 00 	mov    %rax,0x5c0(%rsp)
   33ffe:	00 
   33fff:	49 8b 86 a0 09 00 00 	mov    0x9a0(%r14),%rax
   34006:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
   3400d:	00 
   3400e:	4d 8b a6 a8 09 00 00 	mov    0x9a8(%r14),%r12
   34015:	48 8d 05 94 5c fd ff 	lea    -0x2a36c(%rip),%rax        # 9cb0 <std::thread::current::id::ID+0x9c40>
   3401c:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
   34020:	48 01 c1             	add    %rax,%rcx
   34023:	4d 8b 8e b0 09 00 00 	mov    0x9b0(%r14),%r9
   3402a:	4d 8b 96 b8 09 00 00 	mov    0x9b8(%r14),%r10
   34031:	49 8b 9e c8 09 00 00 	mov    0x9c8(%r14),%rbx
   34038:	49 8b 86 d0 09 00 00 	mov    0x9d0(%r14),%rax
   3403f:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
   34046:	00 
   34047:	49 8b 86 d8 09 00 00 	mov    0x9d8(%r14),%rax
   3404e:	48 89 84 24 90 04 00 	mov    %rax,0x490(%rsp)
   34055:	00 
   34056:	49 8b 86 e0 09 00 00 	mov    0x9e0(%r14),%rax
   3405d:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
   34064:	00 
   34065:	49 8b 86 e8 09 00 00 	mov    0x9e8(%r14),%rax
   3406c:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
   34073:	00 
   34074:	49 8b ae f0 09 00 00 	mov    0x9f0(%r14),%rbp
   3407b:	48 89 94 24 90 05 00 	mov    %rdx,0x590(%rsp)
   34082:	00 
   34083:	ff e1                	jmp    *%rcx
   34085:	49 8b 96 50 05 00 00 	mov    0x550(%r14),%rdx
   3408c:	e9 97 03 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   34091:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   34098:	00 
   34099:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3409d:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   340a1:	0f 84 b2 02 00 00    	je     34359 <oriole_expat::dispatch+0x4d9>
   340a7:	48 8b 50 68          	mov    0x68(%rax),%rdx
   340ab:	48 01 ca             	add    %rcx,%rdx
   340ae:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   340b2:	0f 85 ac 02 00 00    	jne    34364 <oriole_expat::dispatch+0x4e4>
   340b8:	e9 b6 02 00 00       	jmp    34373 <oriole_expat::dispatch+0x4f3>
   340bd:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   340c4:	00 
   340c5:	48 8b 50 68          	mov    0x68(%rax),%rdx
   340c9:	48 03 50 30          	add    0x30(%rax),%rdx
   340cd:	48 03 90 a0 00 00 00 	add    0xa0(%rax),%rdx
   340d4:	83 b8 a8 00 00 00 ff 	cmpl   $0xffffffff,0xa8(%rax)
   340db:	0f 84 92 02 00 00    	je     34373 <oriole_expat::dispatch+0x4f3>
   340e1:	48 8b 80 d8 00 00 00 	mov    0xd8(%rax),%rax
   340e8:	48 01 c2             	add    %rax,%rdx
   340eb:	e9 38 03 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   340f0:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   340f7:	00 
   340f8:	48 8b 48 30          	mov    0x30(%rax),%rcx
   340fc:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   34100:	0f 84 ff 01 00 00    	je     34305 <oriole_expat::dispatch+0x485>
   34106:	48 8b 50 68          	mov    0x68(%rax),%rdx
   3410a:	e9 f8 01 00 00       	jmp    34307 <oriole_expat::dispatch+0x487>
   3410f:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   34116:	00 
   34117:	83 38 ff             	cmpl   $0xffffffff,(%rax)
   3411a:	0f 84 2d 02 00 00    	je     3434d <oriole_expat::dispatch+0x4cd>
   34120:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34124:	e9 26 02 00 00       	jmp    3434f <oriole_expat::dispatch+0x4cf>
   34129:	83 bc 24 60 01 00 00 	cmpl   $0xffffffff,0x160(%rsp)
   34130:	ff 
   34131:	0f 84 b8 01 00 00    	je     342ef <oriole_expat::dispatch+0x46f>
   34137:	48 8b 94 24 90 01 00 	mov    0x190(%rsp),%rdx
   3413e:	00 
   3413f:	48 03 94 24 58 01 00 	add    0x158(%rsp),%rdx
   34146:	00 
   34147:	e9 dc 02 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   3414c:	4c 89 9c 24 38 03 00 	mov    %r11,0x338(%rsp)
   34153:	00 
   34154:	48 89 bc 24 60 04 00 	mov    %rdi,0x460(%rsp)
   3415b:	00 
   3415c:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
   34163:	00 
   34164:	48 8b bc 24 98 01 00 	mov    0x198(%rsp),%rdi
   3416b:	00 
   3416c:	4d 89 c3             	mov    %r8,%r11
   3416f:	48 85 ff             	test   %rdi,%rdi
   34172:	0f 84 05 02 00 00    	je     3437d <oriole_expat::dispatch+0x4fd>
   34178:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   3417f:	00 
   34180:	89 fe                	mov    %edi,%esi
   34182:	83 e6 03             	and    $0x3,%esi
   34185:	48 83 ff 04          	cmp    $0x4,%rdi
   34189:	0f 83 f5 01 00 00    	jae    34384 <oriole_expat::dispatch+0x504>
   3418f:	45 31 c0             	xor    %r8d,%r8d
   34192:	31 d2                	xor    %edx,%edx
   34194:	e9 4f 02 00 00       	jmp    343e8 <oriole_expat::dispatch+0x568>
   34199:	8b 8c 24 68 01 00 00 	mov    0x168(%rsp),%ecx
   341a0:	31 d2                	xor    %edx,%edx
   341a2:	83 bc 24 30 01 00 00 	cmpl   $0xffffffff,0x130(%rsp)
   341a9:	ff 
   341aa:	b8 00 00 00 00       	mov    $0x0,%eax
   341af:	74 08                	je     341b9 <oriole_expat::dispatch+0x339>
   341b1:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
   341b8:	00 
   341b9:	83 f9 ff             	cmp    $0xffffffff,%ecx
   341bc:	74 08                	je     341c6 <oriole_expat::dispatch+0x346>
   341be:	48 8b 94 24 98 01 00 	mov    0x198(%rsp),%rdx
   341c5:	00 
   341c6:	48 01 c2             	add    %rax,%rdx
   341c9:	e9 5a 02 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   341ce:	83 bc 24 68 01 00 00 	cmpl   $0xffffffff,0x168(%rsp)
   341d5:	ff 
   341d6:	0f 84 22 01 00 00    	je     342fe <oriole_expat::dispatch+0x47e>
   341dc:	48 8b 94 24 98 01 00 	mov    0x198(%rsp),%rdx
   341e3:	00 
   341e4:	48 03 94 24 60 01 00 	add    0x160(%rsp),%rdx
   341eb:	00 
   341ec:	e9 37 02 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   341f1:	83 bc 24 30 01 00 00 	cmpl   $0xffffffff,0x130(%rsp)
   341f8:	ff 
   341f9:	74 0d                	je     34208 <oriole_expat::dispatch+0x388>
   341fb:	48 8b 94 24 60 01 00 	mov    0x160(%rsp),%rdx
   34202:	00 
   34203:	e9 20 02 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   34208:	31 d2                	xor    %edx,%edx
   3420a:	e9 19 02 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   3420f:	48 89 ac 24 80 04 00 	mov    %rbp,0x480(%rsp)
   34216:	00 
   34217:	4c 89 9c 24 38 03 00 	mov    %r11,0x338(%rsp)
   3421e:	00 
   3421f:	4c 89 a4 24 68 04 00 	mov    %r12,0x468(%rsp)
   34226:	00 
   34227:	4c 89 84 24 88 04 00 	mov    %r8,0x488(%rsp)
   3422e:	00 
   3422f:	48 89 dd             	mov    %rbx,%rbp
   34232:	4c 89 cb             	mov    %r9,%rbx
   34235:	48 89 bc 24 60 04 00 	mov    %rdi,0x460(%rsp)
   3423c:	00 
   3423d:	4c 89 94 24 78 04 00 	mov    %r10,0x478(%rsp)
   34244:	00 
   34245:	b0 01                	mov    $0x1,%al
   34247:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3424b:	b0 01                	mov    $0x1,%al
   3424d:	89 44 24 28          	mov    %eax,0x28(%rsp)
   34251:	b0 01                	mov    $0x1,%al
   34253:	89 44 24 30          	mov    %eax,0x30(%rsp)
   34257:	b0 01                	mov    $0x1,%al
   34259:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3425d:	b0 01                	mov    $0x1,%al
   3425f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   34263:	b0 01                	mov    $0x1,%al
   34265:	89 44 24 10          	mov    %eax,0x10(%rsp)
   34269:	b0 01                	mov    $0x1,%al
   3426b:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3426f:	b0 01                	mov    $0x1,%al
   34271:	89 44 24 08          	mov    %eax,0x8(%rsp)
   34275:	b0 01                	mov    $0x1,%al
   34277:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3427b:	b0 01                	mov    $0x1,%al
   3427d:	89 44 24 24          	mov    %eax,0x24(%rsp)
   34281:	b0 01                	mov    $0x1,%al
   34283:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   34288:	b0 01                	mov    $0x1,%al
   3428a:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3428e:	b0 01                	mov    $0x1,%al
   34290:	89 44 24 20          	mov    %eax,0x20(%rsp)
   34294:	b0 01                	mov    $0x1,%al
   34296:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3429a:	b0 01                	mov    $0x1,%al
   3429c:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   342a0:	b0 01                	mov    $0x1,%al
   342a2:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   342a6:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   342ad:	00 
   342ae:	ff 15 cc 28 0b 00    	call   *0xb28cc(%rip)        # e6b80 <_GLOBAL_OFFSET_TABLE_+0x240>
   342b4:	4c 8b 94 24 78 04 00 	mov    0x478(%rsp),%r10
   342bb:	00 
   342bc:	48 8b bc 24 60 04 00 	mov    0x460(%rsp),%rdi
   342c3:	00 
   342c4:	49 89 d9             	mov    %rbx,%r9
   342c7:	48 89 eb             	mov    %rbp,%rbx
   342ca:	4c 8b 84 24 88 04 00 	mov    0x488(%rsp),%r8
   342d1:	00 
   342d2:	4c 8b a4 24 68 04 00 	mov    0x468(%rsp),%r12
   342d9:	00 
   342da:	4c 8b 9c 24 38 03 00 	mov    0x338(%rsp),%r11
   342e1:	00 
   342e2:	48 8b ac 24 80 04 00 	mov    0x480(%rsp),%rbp
   342e9:	00 
   342ea:	e9 39 01 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   342ef:	31 d2                	xor    %edx,%edx
   342f1:	48 03 94 24 58 01 00 	add    0x158(%rsp),%rdx
   342f8:	00 
   342f9:	e9 2a 01 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   342fe:	31 d2                	xor    %edx,%edx
   34300:	e9 df fe ff ff       	jmp    341e4 <oriole_expat::dispatch+0x364>
   34305:	31 d2                	xor    %edx,%edx
   34307:	48 01 ca             	add    %rcx,%rdx
   3430a:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   3430e:	74 09                	je     34319 <oriole_expat::dispatch+0x499>
   34310:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
   34317:	eb 02                	jmp    3431b <oriole_expat::dispatch+0x49b>
   34319:	31 c9                	xor    %ecx,%ecx
   3431b:	48 01 ca             	add    %rcx,%rdx
   3431e:	83 b8 a8 00 00 00 ff 	cmpl   $0xffffffff,0xa8(%rax)
   34325:	74 09                	je     34330 <oriole_expat::dispatch+0x4b0>
   34327:	48 8b 88 d8 00 00 00 	mov    0xd8(%rax),%rcx
   3432e:	eb 02                	jmp    34332 <oriole_expat::dispatch+0x4b2>
   34330:	31 c9                	xor    %ecx,%ecx
   34332:	48 01 ca             	add    %rcx,%rdx
   34335:	83 b8 e0 00 00 00 ff 	cmpl   $0xffffffff,0xe0(%rax)
   3433c:	74 35                	je     34373 <oriole_expat::dispatch+0x4f3>
   3433e:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
   34345:	48 01 c2             	add    %rax,%rdx
   34348:	e9 db 00 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   3434d:	31 c9                	xor    %ecx,%ecx
   3434f:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   34353:	0f 85 4e fd ff ff    	jne    340a7 <oriole_expat::dispatch+0x227>
   34359:	31 d2                	xor    %edx,%edx
   3435b:	48 01 ca             	add    %rcx,%rdx
   3435e:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   34362:	74 0f                	je     34373 <oriole_expat::dispatch+0x4f3>
   34364:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
   3436b:	48 01 c2             	add    %rax,%rdx
   3436e:	e9 b5 00 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   34373:	31 c0                	xor    %eax,%eax
   34375:	48 01 c2             	add    %rax,%rdx
   34378:	e9 ab 00 00 00       	jmp    34428 <oriole_expat::dispatch+0x5a8>
   3437d:	31 d2                	xor    %edx,%edx
   3437f:	e9 8e 00 00 00       	jmp    34412 <oriole_expat::dispatch+0x592>
   34384:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
   34389:	48 83 e7 fc          	and    $0xfffffffffffffffc,%rdi
   3438d:	4c 8d 89 d0 01 00 00 	lea    0x1d0(%rcx),%r9
   34394:	45 31 c0             	xor    %r8d,%r8d
   34397:	31 d2                	xor    %edx,%edx
   34399:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   343a0:	49 03 91 60 fe ff ff 	add    -0x1a0(%r9),%rdx
   343a7:	49 03 91 98 fe ff ff 	add    -0x168(%r9),%rdx
   343ae:	49 03 91 d8 fe ff ff 	add    -0x128(%r9),%rdx
   343b5:	49 03 91 10 ff ff ff 	add    -0xf0(%r9),%rdx
   343bc:	49 03 91 50 ff ff ff 	add    -0xb0(%r9),%rdx
   343c3:	49 03 51 88          	add    -0x78(%r9),%rdx
   343c7:	49 03 51 c8          	add    -0x38(%r9),%rdx
   343cb:	49 03 11             	add    (%r9),%rdx
   343ce:	49 83 c0 04          	add    $0x4,%r8
   343d2:	49 81 c1 e0 01 00 00 	add    $0x1e0,%r9
   343d9:	4c 39 c7             	cmp    %r8,%rdi
   343dc:	75 c2                	jne    343a0 <oriole_expat::dispatch+0x520>
   343de:	48 85 f6             	test   %rsi,%rsi
   343e1:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
   343e6:	74 2a                	je     34412 <oriole_expat::dispatch+0x592>
   343e8:	49 6b f8 78          	imul   $0x78,%r8,%rdi
   343ec:	48 01 f9             	add    %rdi,%rcx
   343ef:	48 83 c1 68          	add    $0x68,%rcx
   343f3:	48 6b f6 78          	imul   $0x78,%rsi,%rsi
   343f7:	31 ff                	xor    %edi,%edi
   343f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   34400:	48 03 54 39 c8       	add    -0x38(%rcx,%rdi,1),%rdx
   34405:	48 03 14 39          	add    (%rcx,%rdi,1),%rdx
   34409:	48 83 c7 78          	add    $0x78,%rdi
   3440d:	48 39 fe             	cmp    %rdi,%rsi
   34410:	75 ee                	jne    34400 <oriole_expat::dispatch+0x580>
   34412:	48 01 c2             	add    %rax,%rdx
   34415:	48 8b bc 24 60 04 00 	mov    0x460(%rsp),%rdi
   3441c:	00 
   3441d:	4d 89 d8             	mov    %r11,%r8
   34420:	4c 8b 9c 24 38 03 00 	mov    0x338(%rsp),%r11
   34427:	00 
   34428:	4c 01 ea             	add    %r13,%rdx
   3442b:	49 8b 8e 68 0b 00 00 	mov    0xb68(%r14),%rcx
   34432:	48 8b 41 30          	mov    0x30(%rcx),%rax
   34436:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3443d:	00 00 00 
   34440:	48 8d 34 02          	lea    (%rdx,%rax,1),%rsi
   34444:	48 39 c6             	cmp    %rax,%rsi
   34447:	0f 82 6c 01 00 00    	jb     345b9 <oriole_expat::dispatch+0x739>
   3444d:	48 81 fe 00 00 00 04 	cmp    $0x4000000,%rsi
   34454:	0f 87 5f 01 00 00    	ja     345b9 <oriole_expat::dispatch+0x739>
   3445a:	f0 48 0f b1 71 30    	lock cmpxchg %rsi,0x30(%rcx)
   34460:	75 de                	jne    34440 <oriole_expat::dispatch+0x5c0>
   34462:	45 84 ff             	test   %r15b,%r15b
   34465:	0f 84 a8 01 00 00    	je     34613 <oriole_expat::dispatch+0x793>
   3446b:	41 83 be 48 0a 00 00 	cmpl   $0xffffffff,0xa48(%r14)
   34472:	ff 
   34473:	0f 84 a8 01 00 00    	je     34621 <oriole_expat::dispatch+0x7a1>
   34479:	48 89 ac 24 80 04 00 	mov    %rbp,0x480(%rsp)
   34480:	00 
   34481:	4c 89 dd             	mov    %r11,%rbp
   34484:	4c 89 a4 24 68 04 00 	mov    %r12,0x468(%rsp)
   3448b:	00 
   3448c:	4d 89 c4             	mov    %r8,%r12
   3448f:	48 89 9c 24 38 03 00 	mov    %rbx,0x338(%rsp)
   34496:	00 
   34497:	4c 89 cb             	mov    %r9,%rbx
   3449a:	49 89 ff             	mov    %rdi,%r15
   3449d:	4d 89 d5             	mov    %r10,%r13
   344a0:	49 8d b6 48 0a 00 00 	lea    0xa48(%r14),%rsi
   344a7:	b0 01                	mov    $0x1,%al
   344a9:	89 44 24 48          	mov    %eax,0x48(%rsp)
   344ad:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   344b4:	00 
   344b5:	b0 01                	mov    $0x1,%al
   344b7:	89 44 24 28          	mov    %eax,0x28(%rsp)
   344bb:	b0 01                	mov    $0x1,%al
   344bd:	89 44 24 30          	mov    %eax,0x30(%rsp)
   344c1:	b0 01                	mov    $0x1,%al
   344c3:	89 44 24 38          	mov    %eax,0x38(%rsp)
   344c7:	b0 01                	mov    $0x1,%al
   344c9:	89 44 24 14          	mov    %eax,0x14(%rsp)
   344cd:	b0 01                	mov    $0x1,%al
   344cf:	89 44 24 10          	mov    %eax,0x10(%rsp)
   344d3:	b0 01                	mov    $0x1,%al
   344d5:	89 44 24 40          	mov    %eax,0x40(%rsp)
   344d9:	b0 01                	mov    $0x1,%al
   344db:	89 44 24 08          	mov    %eax,0x8(%rsp)
   344df:	b0 01                	mov    $0x1,%al
   344e1:	89 44 24 04          	mov    %eax,0x4(%rsp)
   344e5:	b0 01                	mov    $0x1,%al
   344e7:	89 44 24 24          	mov    %eax,0x24(%rsp)
   344eb:	b0 01                	mov    $0x1,%al
   344ed:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   344f2:	b0 01                	mov    $0x1,%al
   344f4:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   344f8:	b0 01                	mov    $0x1,%al
   344fa:	89 44 24 20          	mov    %eax,0x20(%rsp)
   344fe:	b0 01                	mov    $0x1,%al
   34500:	89 44 24 18          	mov    %eax,0x18(%rsp)
   34504:	b0 01                	mov    $0x1,%al
   34506:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3450a:	b0 01                	mov    $0x1,%al
   3450c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   34510:	ff 15 42 26 0b 00    	call   *0xb2642(%rip)        # e6b58 <_GLOBAL_OFFSET_TABLE_+0x218>
   34516:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   3451d:	00 
   3451e:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   34525:	00 
   34526:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   3452d:	00 
   3452e:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   34535:	00 
   34536:	0f 10 84 24 59 03 00 	movups 0x359(%rsp),%xmm0
   3453d:	00 
   3453e:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
   34545:	00 
   34546:	0f 10 84 24 68 03 00 	movups 0x368(%rsp),%xmm0
   3454d:	00 
   3454e:	0f 11 84 24 3f 02 00 	movups %xmm0,0x23f(%rsp)
   34555:	00 
   34556:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3455a:	0f 84 d6 01 00 00    	je     34736 <oriole_expat::dispatch+0x8b6>
   34560:	4d 89 ea             	mov    %r13,%r10
   34563:	49 89 d9             	mov    %rbx,%r9
   34566:	4d 89 e0             	mov    %r12,%r8
   34569:	49 89 eb             	mov    %rbp,%r11
   3456c:	0f 10 84 24 3f 02 00 	movups 0x23f(%rsp),%xmm0
   34573:	00 
   34574:	0f 11 84 24 bf 00 00 	movups %xmm0,0xbf(%rsp)
   3457b:	00 
   3457c:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
   34583:	00 
   34584:	0f 28 8c 24 30 02 00 	movaps 0x230(%rsp),%xmm1
   3458b:	00 
   3458c:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   34593:	00 
   34594:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   3459b:	00 
   3459c:	4c 89 ff             	mov    %r15,%rdi
   3459f:	48 8b 9c 24 38 03 00 	mov    0x338(%rsp),%rbx
   345a6:	00 
   345a7:	4c 8b a4 24 68 04 00 	mov    0x468(%rsp),%r12
   345ae:	00 
   345af:	48 8b ac 24 80 04 00 	mov    0x480(%rsp),%rbp
   345b6:	00 
   345b7:	eb 6f                	jmp    34628 <oriole_expat::dispatch+0x7a8>
   345b9:	48 b8 2b 00 00 00 2b 	movabs $0x2b0000002b,%rax
   345c0:	00 00 00 
   345c3:	49 89 86 10 0a 00 00 	mov    %rax,0xa10(%r14)
   345ca:	41 b7 ff             	mov    $0xff,%r15b
   345cd:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
   345d4:	00 
   345d5:	48 83 e9 03          	sub    $0x3,%rcx
   345d9:	b8 0d 00 00 00       	mov    $0xd,%eax
   345de:	48 0f 43 c1          	cmovae %rcx,%rax
   345e2:	48 83 c0 fa          	add    $0xfffffffffffffffa,%rax
   345e6:	48 83 f8 14          	cmp    $0x14,%rax
   345ea:	0f 87 4c 47 00 00    	ja     38d3c <oriole_expat::dispatch+0x4ebc>
   345f0:	48 8d 0d 25 57 fd ff 	lea    -0x2a8db(%rip),%rcx        # 9d1c <std::thread::current::id::ID+0x9cac>
   345f7:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   345fb:	48 01 c8             	add    %rcx,%rax
   345fe:	ff e0                	jmp    *%rax
   34600:	83 bc 24 30 01 00 00 	cmpl   $0xffffffff,0x130(%rsp)
   34607:	ff 
   34608:	0f 85 31 46 00 00    	jne    38c3f <oriole_expat::dispatch+0x4dbf>
   3460e:	e9 29 47 00 00       	jmp    38d3c <oriole_expat::dispatch+0x4ebc>
   34613:	48 c7 84 24 18 05 00 	movq   $0xffffffffffffffff,0x518(%rsp)
   3461a:	00 ff ff ff ff 
   3461f:	eb 46                	jmp    34667 <oriole_expat::dispatch+0x7e7>
   34621:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   34628:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
   3462f:	00 
   34630:	0f 28 8c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm1
   34637:	00 
   34638:	0f 11 84 24 21 05 00 	movups %xmm0,0x521(%rsp)
   3463f:	00 
   34640:	0f 11 8c 24 31 05 00 	movups %xmm1,0x531(%rsp)
   34647:	00 
   34648:	0f 10 84 24 bf 00 00 	movups 0xbf(%rsp),%xmm0
   3464f:	00 
   34650:	0f 11 84 24 40 05 00 	movups %xmm0,0x540(%rsp)
   34657:	00 
   34658:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
   3465f:	00 
   34660:	88 8c 24 20 05 00 00 	mov    %cl,0x520(%rsp)
   34667:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
   3466e:	00 
   3466f:	48 89 c2             	mov    %rax,%rdx
   34672:	48 83 ea 03          	sub    $0x3,%rdx
   34676:	b9 0d 00 00 00       	mov    $0xd,%ecx
   3467b:	48 0f 43 ca          	cmovae %rdx,%rcx
   3467f:	48 83 f9 1a          	cmp    $0x1a,%rcx
   34683:	0f 92 84 24 80 04 00 	setb   0x480(%rsp)
   3468a:	00 
   3468b:	ba 3e 00 c7 03       	mov    $0x3c7003e,%edx
   34690:	d3 ea                	shr    %cl,%edx
   34692:	89 94 24 38 03 00 00 	mov    %edx,0x338(%rsp)
   34699:	48 83 f8 08          	cmp    $0x8,%rax
   3469d:	0f 95 84 24 26 01 00 	setne  0x126(%rsp)
   346a4:	00 
   346a5:	4d 85 c9             	test   %r9,%r9
   346a8:	0f 94 84 24 68 04 00 	sete   0x468(%rsp)
   346af:	00 
   346b0:	0f b6 84 24 30 01 00 	movzbl 0x130(%rsp),%eax
   346b7:	00 
   346b8:	88 84 24 88 04 00 00 	mov    %al,0x488(%rsp)
   346bf:	0f b6 84 24 31 01 00 	movzbl 0x131(%rsp),%eax
   346c6:	00 
   346c7:	88 84 24 27 01 00 00 	mov    %al,0x127(%rsp)
   346ce:	48 8d 05 9b 56 fd ff 	lea    -0x2a965(%rip),%rax        # 9d70 <std::thread::current::id::ID+0x9d00>
   346d5:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
   346d9:	48 01 c1             	add    %rax,%rcx
   346dc:	b0 01                	mov    $0x1,%al
   346de:	89 44 24 28          	mov    %eax,0x28(%rsp)
   346e2:	b0 01                	mov    $0x1,%al
   346e4:	89 44 24 30          	mov    %eax,0x30(%rsp)
   346e8:	b0 01                	mov    $0x1,%al
   346ea:	89 44 24 48          	mov    %eax,0x48(%rsp)
   346ee:	b0 01                	mov    $0x1,%al
   346f0:	89 44 24 38          	mov    %eax,0x38(%rsp)
   346f4:	b0 01                	mov    $0x1,%al
   346f6:	89 44 24 14          	mov    %eax,0x14(%rsp)
   346fa:	b0 01                	mov    $0x1,%al
   346fc:	89 44 24 10          	mov    %eax,0x10(%rsp)
   34700:	b0 01                	mov    $0x1,%al
   34702:	89 44 24 40          	mov    %eax,0x40(%rsp)
   34706:	b0 01                	mov    $0x1,%al
   34708:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3470c:	b0 01                	mov    $0x1,%al
   3470e:	89 44 24 04          	mov    %eax,0x4(%rsp)
   34712:	b0 01                	mov    $0x1,%al
   34714:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   34718:	b0 01                	mov    $0x1,%al
   3471a:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3471e:	b0 01                	mov    $0x1,%al
   34720:	89 44 24 18          	mov    %eax,0x18(%rsp)
   34724:	b0 01                	mov    $0x1,%al
   34726:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3472a:	b2 01                	mov    $0x1,%dl
   3472c:	ff e1                	jmp    *%rcx
   3472e:	4d 85 c9             	test   %r9,%r9
   34731:	e9 8f 10 00 00       	jmp    357c5 <oriole_expat::dispatch+0x1945>
   34736:	41 89 cf             	mov    %ecx,%r15d
   34739:	e9 8f fe ff ff       	jmp    345cd <oriole_expat::dispatch+0x74d>
   3473e:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
   34745:	00 
   34746:	48 8b 41 30          	mov    0x30(%rcx),%rax
   3474a:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   34751:	00 
   34752:	0f 10 01             	movups (%rcx),%xmm0
   34755:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   34759:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   3475d:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   34764:	00 
   34765:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   3476a:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   3476f:	4d 85 db             	test   %r11,%r11
   34772:	0f 84 3d 22 00 00    	je     369b5 <oriole_expat::dispatch+0x2b35>
   34778:	4c 89 db             	mov    %r11,%rbx
   3477b:	48 8b 41 30          	mov    0x30(%rcx),%rax
   3477f:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   34786:	00 
   34787:	0f 10 01             	movups (%rcx),%xmm0
   3478a:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   3478e:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   34792:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   34799:	00 
   3479a:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   347a1:	00 
   347a2:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   347a9:	00 
   347aa:	b0 01                	mov    $0x1,%al
   347ac:	89 44 24 28          	mov    %eax,0x28(%rsp)
   347b0:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   347b7:	00 
   347b8:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   347bf:	00 
   347c0:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   347c7:	00 
   347c8:	b0 01                	mov    $0x1,%al
   347ca:	89 44 24 30          	mov    %eax,0x30(%rsp)
   347ce:	b0 01                	mov    $0x1,%al
   347d0:	89 44 24 48          	mov    %eax,0x48(%rsp)
   347d4:	b0 01                	mov    $0x1,%al
   347d6:	89 44 24 14          	mov    %eax,0x14(%rsp)
   347da:	b0 01                	mov    $0x1,%al
   347dc:	89 44 24 10          	mov    %eax,0x10(%rsp)
   347e0:	b0 01                	mov    $0x1,%al
   347e2:	89 44 24 40          	mov    %eax,0x40(%rsp)
   347e6:	b0 01                	mov    $0x1,%al
   347e8:	89 44 24 08          	mov    %eax,0x8(%rsp)
   347ec:	b0 01                	mov    $0x1,%al
   347ee:	89 44 24 04          	mov    %eax,0x4(%rsp)
   347f2:	b0 01                	mov    $0x1,%al
   347f4:	89 44 24 24          	mov    %eax,0x24(%rsp)
   347f8:	b0 01                	mov    $0x1,%al
   347fa:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   347ff:	b0 01                	mov    $0x1,%al
   34801:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   34805:	40 b5 01             	mov    $0x1,%bpl
   34808:	41 b7 01             	mov    $0x1,%r15b
   3480b:	41 b4 01             	mov    $0x1,%r12b
   3480e:	41 b5 01             	mov    $0x1,%r13b
   34811:	ff 15 31 23 0b 00    	call   *0xb2331(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   34817:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   3481e:	00 
   3481f:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   34826:	00 00 
   34828:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3482c:	0f 84 de 31 00 00    	je     37a10 <oriole_expat::dispatch+0x3b90>
   34832:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   34839:	00 
   3483a:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   34841:	00 
   34842:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   34849:	00 
   3484a:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   34851:	00 
   34852:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   34859:	00 
   3485a:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   34861:	00 
   34862:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   34869:	00 
   3486a:	44 88 bc 24 a8 00 00 	mov    %r15b,0xa8(%rsp)
   34871:	00 
   34872:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   34879:	00 
   3487a:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   3487f:	ff d3                	call   *%rbx
   34881:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   34888:	00 
   34889:	48 85 c9             	test   %rcx,%rcx
   3488c:	74 6c                	je     348fa <oriole_expat::dispatch+0xa7a>
   3488e:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   34895:	00 
   34896:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   3489d:	00 
   3489e:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   348a5:	00 
   348a6:	ba 01 00 00 00       	mov    $0x1,%edx
   348ab:	b0 01                	mov    $0x1,%al
   348ad:	89 44 24 30          	mov    %eax,0x30(%rsp)
   348b1:	b0 01                	mov    $0x1,%al
   348b3:	89 44 24 48          	mov    %eax,0x48(%rsp)
   348b7:	b0 01                	mov    $0x1,%al
   348b9:	89 44 24 14          	mov    %eax,0x14(%rsp)
   348bd:	b0 01                	mov    $0x1,%al
   348bf:	89 44 24 10          	mov    %eax,0x10(%rsp)
   348c3:	b0 01                	mov    $0x1,%al
   348c5:	89 44 24 40          	mov    %eax,0x40(%rsp)
   348c9:	b0 01                	mov    $0x1,%al
   348cb:	89 44 24 08          	mov    %eax,0x8(%rsp)
   348cf:	b0 01                	mov    $0x1,%al
   348d1:	89 44 24 04          	mov    %eax,0x4(%rsp)
   348d5:	b0 01                	mov    $0x1,%al
   348d7:	89 44 24 24          	mov    %eax,0x24(%rsp)
   348db:	b0 01                	mov    $0x1,%al
   348dd:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   348e2:	b0 01                	mov    $0x1,%al
   348e4:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   348e8:	40 b5 01             	mov    $0x1,%bpl
   348eb:	41 b7 01             	mov    $0x1,%r15b
   348ee:	41 b4 01             	mov    $0x1,%r12b
   348f1:	41 b5 01             	mov    $0x1,%r13b
   348f4:	ff 15 7e 21 0b 00    	call   *0xb217e(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   348fa:	b3 01                	mov    $0x1,%bl
   348fc:	e9 e5 38 00 00       	jmp    381e6 <oriole_expat::dispatch+0x4366>
   34901:	b0 01                	mov    $0x1,%al
   34903:	89 44 24 28          	mov    %eax,0x28(%rsp)
   34907:	b0 01                	mov    $0x1,%al
   34909:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3490d:	b0 01                	mov    $0x1,%al
   3490f:	89 44 24 48          	mov    %eax,0x48(%rsp)
   34913:	b0 01                	mov    $0x1,%al
   34915:	89 44 24 38          	mov    %eax,0x38(%rsp)
   34919:	b0 01                	mov    $0x1,%al
   3491b:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3491f:	b0 01                	mov    $0x1,%al
   34921:	89 44 24 10          	mov    %eax,0x10(%rsp)
   34925:	b0 01                	mov    $0x1,%al
   34927:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3492b:	b0 01                	mov    $0x1,%al
   3492d:	89 44 24 08          	mov    %eax,0x8(%rsp)
   34931:	b0 01                	mov    $0x1,%al
   34933:	89 44 24 04          	mov    %eax,0x4(%rsp)
   34937:	b0 01                	mov    $0x1,%al
   34939:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3493d:	b0 01                	mov    $0x1,%al
   3493f:	89 44 24 20          	mov    %eax,0x20(%rsp)
   34943:	b0 01                	mov    $0x1,%al
   34945:	89 44 24 18          	mov    %eax,0x18(%rsp)
   34949:	b0 01                	mov    $0x1,%al
   3494b:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3494f:	b2 01                	mov    $0x1,%dl
   34951:	48 83 bc 24 a0 05 00 	cmpq   $0x0,0x5a0(%rsp)
   34958:	00 00 
   3495a:	0f 84 c5 0e 00 00    	je     35825 <oriole_expat::dispatch+0x19a5>
   34960:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   34965:	ff 94 24 a0 05 00 00 	call   *0x5a0(%rsp)
   3496c:	e9 ea 10 00 00       	jmp    35a5b <oriole_expat::dispatch+0x1bdb>
   34971:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
   34978:	00 
   34979:	48 8b 41 30          	mov    0x30(%rcx),%rax
   3497d:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
   34984:	00 
   34985:	0f 10 01             	movups (%rcx),%xmm0
   34988:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   3498c:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   34990:	0f 29 94 24 40 02 00 	movaps %xmm2,0x240(%rsp)
   34997:	00 
   34998:	0f 29 8c 24 30 02 00 	movaps %xmm1,0x230(%rsp)
   3499f:	00 
   349a0:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   349a7:	00 
   349a8:	48 8b 9c 24 d0 05 00 	mov    0x5d0(%rsp),%rbx
   349af:	00 
   349b0:	48 85 db             	test   %rbx,%rbx
   349b3:	0f 84 83 20 00 00    	je     36a3c <oriole_expat::dispatch+0x2bbc>
   349b9:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
   349c0:	00 
   349c1:	48 8b 94 24 50 02 00 	mov    0x250(%rsp),%rdx
   349c8:	00 
   349c9:	31 ff                	xor    %edi,%edi
   349cb:	e8 c0 80 00 00       	call   3ca90 <core::slice::memchr::memchr>
   349d0:	b1 03                	mov    $0x3,%cl
   349d2:	48 83 f8 01          	cmp    $0x1,%rax
   349d6:	74 1a                	je     349f2 <oriole_expat::dispatch+0xb72>
   349d8:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   349df:	00 
   349e0:	31 f6                	xor    %esi,%esi
   349e2:	ff 15 e0 20 0b 00    	call   *0xb20e0(%rip)        # e6ac8 <_GLOBAL_OFFSET_TABLE_+0x188>
   349e8:	89 c1                	mov    %eax,%ecx
   349ea:	3c ff                	cmp    $0xff,%al
   349ec:	0f 84 dc 38 00 00    	je     382ce <oriole_expat::dispatch+0x444e>
   349f2:	89 cb                	mov    %ecx,%ebx
   349f4:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   349fb:	00 
   349fc:	48 85 c9             	test   %rcx,%rcx
   349ff:	74 72                	je     34a73 <oriole_expat::dispatch+0xbf3>
   34a01:	b0 01                	mov    $0x1,%al
   34a03:	89 44 24 48          	mov    %eax,0x48(%rsp)
   34a07:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
   34a0e:	00 
   34a0f:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34a16:	00 
   34a17:	ba 01 00 00 00       	mov    $0x1,%edx
   34a1c:	b0 01                	mov    $0x1,%al
   34a1e:	89 44 24 28          	mov    %eax,0x28(%rsp)
   34a22:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   34a29:	00 
   34a2a:	b0 01                	mov    $0x1,%al
   34a2c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   34a30:	b0 01                	mov    $0x1,%al
   34a32:	89 44 24 14          	mov    %eax,0x14(%rsp)
   34a36:	b0 01                	mov    $0x1,%al
   34a38:	89 44 24 10          	mov    %eax,0x10(%rsp)
   34a3c:	b0 01                	mov    $0x1,%al
   34a3e:	89 44 24 40          	mov    %eax,0x40(%rsp)
   34a42:	b0 01                	mov    $0x1,%al
   34a44:	89 44 24 08          	mov    %eax,0x8(%rsp)
   34a48:	b0 01                	mov    $0x1,%al
   34a4a:	89 44 24 04          	mov    %eax,0x4(%rsp)
   34a4e:	b0 01                	mov    $0x1,%al
   34a50:	89 44 24 24          	mov    %eax,0x24(%rsp)
   34a54:	b0 01                	mov    $0x1,%al
   34a56:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   34a5b:	b0 01                	mov    $0x1,%al
   34a5d:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   34a61:	40 b5 01             	mov    $0x1,%bpl
   34a64:	41 b7 01             	mov    $0x1,%r15b
   34a67:	41 b4 01             	mov    $0x1,%r12b
   34a6a:	41 b5 01             	mov    $0x1,%r13b
   34a6d:	ff 15 05 20 0b 00    	call   *0xb2005(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   34a73:	b0 01                	mov    $0x1,%al
   34a75:	89 44 24 48          	mov    %eax,0x48(%rsp)
   34a79:	b0 01                	mov    $0x1,%al
   34a7b:	89 44 24 28          	mov    %eax,0x28(%rsp)
   34a7f:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   34a86:	00 
   34a87:	e9 1e 4e 00 00       	jmp    398aa <oriole_expat::dispatch+0x5a2a>
   34a8c:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
   34a93:	00 
   34a94:	48 8b 41 30          	mov    0x30(%rcx),%rax
   34a98:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   34a9f:	00 
   34aa0:	0f 10 01             	movups (%rcx),%xmm0
   34aa3:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   34aa7:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   34aab:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   34ab2:	00 
   34ab3:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   34aba:	00 
   34abb:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   34ac2:	00 
   34ac3:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
   34aca:	00 
   34acb:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   34ad2:	00 
   34ad3:	0f 10 84 24 68 01 00 	movups 0x168(%rsp),%xmm0
   34ada:	00 
   34adb:	0f 10 8c 24 78 01 00 	movups 0x178(%rsp),%xmm1
   34ae2:	00 
   34ae3:	0f 10 94 24 88 01 00 	movups 0x188(%rsp),%xmm2
   34aea:	00 
   34aeb:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   34af2:	00 
   34af3:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   34af8:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   34afd:	48 85 ed             	test   %rbp,%rbp
   34b00:	0f 84 3d 1f 00 00    	je     36a43 <oriole_expat::dispatch+0x2bc3>
   34b06:	48 8b 41 30          	mov    0x30(%rcx),%rax
   34b0a:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   34b11:	00 
   34b12:	0f 10 01             	movups (%rcx),%xmm0
   34b15:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   34b19:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   34b1d:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   34b24:	00 
   34b25:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   34b2c:	00 
   34b2d:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   34b34:	00 
   34b35:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34b3c:	00 
   34b3d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   34b44:	00 
   34b45:	ff 15 fd 1f 0b 00    	call   *0xb1ffd(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   34b4b:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   34b52:	00 
   34b53:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   34b5a:	00 00 
   34b5c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   34b60:	0f 84 cf 2e 00 00    	je     37a35 <oriole_expat::dispatch+0x3bb5>
   34b66:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   34b6d:	00 
   34b6e:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   34b75:	00 
   34b76:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   34b7d:	00 
   34b7e:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   34b85:	00 
   34b86:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   34b8d:	00 
   34b8e:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   34b95:	00 
   34b96:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   34b9d:	00 
   34b9e:	44 88 bc 24 a8 00 00 	mov    %r15b,0xa8(%rsp)
   34ba5:	00 
   34ba6:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   34bad:	00 
   34bae:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   34bb5:	00 
   34bb6:	41 0f 10 46 08       	movups 0x8(%r14),%xmm0
   34bbb:	41 0f 10 4e 18       	movups 0x18(%r14),%xmm1
   34bc0:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   34bc7:	00 
   34bc8:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   34bcf:	00 
   34bd0:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34bd7:	00 
   34bd8:	48 8d 8c 24 40 03 00 	lea    0x340(%rsp),%rcx
   34bdf:	00 
   34be0:	e8 0b 78 00 00       	call   3c3f0 <oriole_expat::content_model::allocate>
   34be5:	83 bc 24 20 02 00 00 	cmpl   $0x1,0x220(%rsp)
   34bec:	01 
   34bed:	0f 85 f2 2f 00 00    	jne    37be5 <oriole_expat::dispatch+0x3d65>
   34bf3:	8b 84 24 24 02 00 00 	mov    0x224(%rsp),%eax
   34bfa:	41 89 86 14 0a 00 00 	mov    %eax,0xa14(%r14)
   34c01:	41 89 86 10 0a 00 00 	mov    %eax,0xa10(%r14)
   34c08:	e9 ef 2f 00 00       	jmp    37bfc <oriole_expat::dispatch+0x3d7c>
   34c0d:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
   34c14:	00 
   34c15:	0f 10 00             	movups (%rax),%xmm0
   34c18:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34c1c:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   34c23:	00 
   34c24:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   34c2b:	00 
   34c2c:	48 8b 9c 24 50 01 00 	mov    0x150(%rsp),%rbx
   34c33:	00 
   34c34:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   34c3b:	00 
   34c3c:	ba a8 00 00 00       	mov    $0xa8,%edx
   34c41:	48 89 de             	mov    %rbx,%rsi
   34c44:	ff 15 16 27 0b 00    	call   *0xb2716(%rip)        # e7360 <memcpy@GLIBC_2.14>
   34c4a:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   34c51:	00 
   34c52:	ba 08 00 00 00       	mov    $0x8,%edx
   34c57:	b9 a8 00 00 00       	mov    $0xa8,%ecx
   34c5c:	48 89 de             	mov    %rbx,%rsi
   34c5f:	ff 15 13 1e 0b 00    	call   *0xb1e13(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   34c65:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34c6c:	00 
   34c6d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   34c74:	00 
   34c75:	ba a8 00 00 00       	mov    $0xa8,%edx
   34c7a:	ff 15 e0 26 0b 00    	call   *0xb26e0(%rip)        # e7360 <memcpy@GLIBC_2.14>
   34c80:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   34c87:	00 
   34c88:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   34c8f:	00 
   34c90:	0f 10 84 24 20 02 00 	movups 0x220(%rsp),%xmm0
   34c97:	00 
   34c98:	0f 10 8c 24 30 02 00 	movups 0x230(%rsp),%xmm1
   34c9f:	00 
   34ca0:	0f 10 94 24 40 02 00 	movups 0x240(%rsp),%xmm2
   34ca7:	00 
   34ca8:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   34caf:	00 
   34cb0:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   34cb7:	00 
   34cb8:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   34cbf:	00 
   34cc0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
   34cc7:	00 
   34cc8:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   34ccf:	00 
   34cd0:	0f 10 84 24 78 02 00 	movups 0x278(%rsp),%xmm0
   34cd7:	00 
   34cd8:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   34cdf:	00 
   34ce0:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   34ce7:	00 
   34ce8:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
   34cef:	00 
   34cf0:	0f 10 84 24 58 02 00 	movups 0x258(%rsp),%xmm0
   34cf7:	00 
   34cf8:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   34cff:	00 
   34d00:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
   34d07:	00 
   34d08:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   34d0f:	00 
   34d10:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   34d17:	00 
   34d18:	0f 10 8c 24 a0 02 00 	movups 0x2a0(%rsp),%xmm1
   34d1f:	00 
   34d20:	0f 10 94 24 b0 02 00 	movups 0x2b0(%rsp),%xmm2
   34d27:	00 
   34d28:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   34d2f:	00 
   34d30:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   34d37:	00 
   34d38:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   34d3f:	00 
   34d40:	48 83 bc 24 90 04 00 	cmpq   $0x0,0x490(%rsp)
   34d47:	00 00 
   34d49:	0f 84 05 22 00 00    	je     36f54 <oriole_expat::dispatch+0x30d4>
   34d4f:	4d 8b ae 08 0b 00 00 	mov    0xb08(%r14),%r13
   34d56:	4d 85 ed             	test   %r13,%r13
   34d59:	4d 0f 44 ee          	cmove  %r14,%r13
   34d5d:	b3 01                	mov    $0x1,%bl
   34d5f:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   34d66:	00 
   34d67:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
   34d6e:	00 
   34d6f:	e8 bc e0 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   34d74:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   34d7b:	00 
   34d7c:	44 0f b6 bc 24 48 03 	movzbl 0x348(%rsp),%r15d
   34d83:	00 00 
   34d85:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   34d89:	0f 85 d4 2b 00 00    	jne    37963 <oriole_expat::dispatch+0x3ae3>
   34d8f:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   34d96:	00 
   34d97:	e8 f4 a5 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   34d9c:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   34da3:	00 
   34da4:	e8 e7 a5 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   34da9:	e9 b5 3b 00 00       	jmp    38963 <oriole_expat::dispatch+0x4ae3>
   34dae:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
   34db5:	00 
   34db6:	0f 10 00             	movups (%rax),%xmm0
   34db9:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34dbd:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   34dc4:	00 
   34dc5:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   34dcc:	00 
   34dcd:	48 8b 9c 24 50 01 00 	mov    0x150(%rsp),%rbx
   34dd4:	00 
   34dd5:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   34ddc:	00 
   34ddd:	ba a8 00 00 00       	mov    $0xa8,%edx
   34de2:	48 89 de             	mov    %rbx,%rsi
   34de5:	ff 15 75 25 0b 00    	call   *0xb2575(%rip)        # e7360 <memcpy@GLIBC_2.14>
   34deb:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   34df2:	00 
   34df3:	ba 08 00 00 00       	mov    $0x8,%edx
   34df8:	b9 a8 00 00 00       	mov    $0xa8,%ecx
   34dfd:	48 89 de             	mov    %rbx,%rsi
   34e00:	ff 15 72 1c 0b 00    	call   *0xb1c72(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   34e06:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34e0d:	00 
   34e0e:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   34e15:	00 
   34e16:	ba a8 00 00 00       	mov    $0xa8,%edx
   34e1b:	ff 15 3f 25 0b 00    	call   *0xb253f(%rip)        # e7360 <memcpy@GLIBC_2.14>
   34e21:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   34e28:	00 
   34e29:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   34e30:	00 
   34e31:	0f 10 84 24 20 02 00 	movups 0x220(%rsp),%xmm0
   34e38:	00 
   34e39:	0f 10 8c 24 30 02 00 	movups 0x230(%rsp),%xmm1
   34e40:	00 
   34e41:	0f 10 94 24 40 02 00 	movups 0x240(%rsp),%xmm2
   34e48:	00 
   34e49:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   34e50:	00 
   34e51:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   34e58:	00 
   34e59:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   34e60:	00 
   34e61:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
   34e68:	00 
   34e69:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   34e70:	00 
   34e71:	0f 10 84 24 78 02 00 	movups 0x278(%rsp),%xmm0
   34e78:	00 
   34e79:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   34e80:	00 
   34e81:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   34e88:	00 
   34e89:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
   34e90:	00 
   34e91:	0f 10 84 24 58 02 00 	movups 0x258(%rsp),%xmm0
   34e98:	00 
   34e99:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   34ea0:	00 
   34ea1:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
   34ea8:	00 
   34ea9:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   34eb0:	00 
   34eb1:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   34eb8:	00 
   34eb9:	0f 10 8c 24 a0 02 00 	movups 0x2a0(%rsp),%xmm1
   34ec0:	00 
   34ec1:	0f 10 94 24 b0 02 00 	movups 0x2b0(%rsp),%xmm2
   34ec8:	00 
   34ec9:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   34ed0:	00 
   34ed1:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   34ed8:	00 
   34ed9:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   34ee0:	00 
   34ee1:	4c 8b a4 24 98 04 00 	mov    0x498(%rsp),%r12
   34ee8:	00 
   34ee9:	4d 85 e4             	test   %r12,%r12
   34eec:	0f 84 21 21 00 00    	je     37013 <oriole_expat::dispatch+0x3193>
   34ef2:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
   34ef9:	00 
   34efa:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   34f01:	00 
   34f02:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
   34f09:	00 
   34f0a:	0f 28 8c 24 b0 01 00 	movaps 0x1b0(%rsp),%xmm1
   34f11:	00 
   34f12:	0f 28 94 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm2
   34f19:	00 
   34f1a:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   34f21:	00 
   34f22:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   34f29:	00 
   34f2a:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   34f31:	00 
   34f32:	b3 01                	mov    $0x1,%bl
   34f34:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34f3b:	00 
   34f3c:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   34f43:	00 
   34f44:	ff 15 fe 1b 0b 00    	call   *0xb1bfe(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   34f4a:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   34f51:	00 
   34f52:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   34f59:	00 00 
   34f5b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   34f5f:	0f 84 25 2c 00 00    	je     37b8a <oriole_expat::dispatch+0x3d0a>
   34f65:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   34f6c:	00 
   34f6d:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   34f74:	00 
   34f75:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   34f7c:	00 
   34f7d:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   34f84:	00 
   34f85:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   34f8a:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   34f8f:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   34f94:	44 88 7c 24 68       	mov    %r15b,0x68(%rsp)
   34f99:	83 bc 24 18 05 00 00 	cmpl   $0xffffffff,0x518(%rsp)
   34fa0:	ff 
   34fa1:	0f 84 a9 2c 00 00    	je     37c50 <oriole_expat::dispatch+0x3dd0>
   34fa7:	4c 8b bc 24 38 05 00 	mov    0x538(%rsp),%r15
   34fae:	00 
   34faf:	e9 9f 2c 00 00       	jmp    37c53 <oriole_expat::dispatch+0x3dd3>
   34fb4:	48 83 bc 24 98 04 00 	cmpq   $0x0,0x498(%rsp)
   34fbb:	00 00 
   34fbd:	e9 03 08 00 00       	jmp    357c5 <oriole_expat::dispatch+0x1945>
   34fc2:	48 89 bc 24 60 04 00 	mov    %rdi,0x460(%rsp)
   34fc9:	00 
   34fca:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
   34fd1:	00 
   34fd2:	48 8b 41 30          	mov    0x30(%rcx),%rax
   34fd6:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   34fdd:	00 
   34fde:	0f 10 01             	movups (%rcx),%xmm0
   34fe1:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   34fe5:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   34fe9:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   34ff0:	00 
   34ff1:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   34ff6:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   34ffb:	0f 10 84 24 68 01 00 	movups 0x168(%rsp),%xmm0
   35002:	00 
   35003:	0f 10 8c 24 78 01 00 	movups 0x178(%rsp),%xmm1
   3500a:	00 
   3500b:	0f 10 94 24 88 01 00 	movups 0x188(%rsp),%xmm2
   35012:	00 
   35013:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
   3501a:	00 
   3501b:	4c 8b bc 24 98 01 00 	mov    0x198(%rsp),%r15
   35022:	00 
   35023:	4c 89 bc 24 d0 00 00 	mov    %r15,0xd0(%rsp)
   3502a:	00 
   3502b:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   35032:	00 
   35033:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   3503a:	00 
   3503b:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
   35042:	00 
   35043:	4d 85 ff             	test   %r15,%r15
   35046:	0f 84 a4 1a 00 00    	je     36af0 <oriole_expat::dispatch+0x2c70>
   3504c:	44 89 f9             	mov    %r15d,%ecx
   3504f:	83 e1 03             	and    $0x3,%ecx
   35052:	49 83 ff 04          	cmp    $0x4,%r15
   35056:	0f 83 cd 25 00 00    	jae    37629 <oriole_expat::dispatch+0x37a9>
   3505c:	31 d2                	xor    %edx,%edx
   3505e:	31 c0                	xor    %eax,%eax
   35060:	e9 0e 26 00 00       	jmp    37673 <oriole_expat::dispatch+0x37f3>
   35065:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
   3506c:	00 
   3506d:	48 8b 41 30          	mov    0x30(%rcx),%rax
   35071:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   35078:	00 
   35079:	0f 10 01             	movups (%rcx),%xmm0
   3507c:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   35080:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   35084:	0f 29 94 24 00 02 00 	movaps %xmm2,0x200(%rsp)
   3508b:	00 
   3508c:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   35093:	00 
   35094:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   3509b:	00 
   3509c:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
   350a3:	00 
   350a4:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   350ab:	00 
   350ac:	0f 10 84 24 68 01 00 	movups 0x168(%rsp),%xmm0
   350b3:	00 
   350b4:	0f 10 8c 24 78 01 00 	movups 0x178(%rsp),%xmm1
   350bb:	00 
   350bc:	0f 10 94 24 88 01 00 	movups 0x188(%rsp),%xmm2
   350c3:	00 
   350c4:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   350cb:	00 
   350cc:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   350d3:	00 
   350d4:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   350db:	00 
   350dc:	4d 85 c0             	test   %r8,%r8
   350df:	0f 84 12 1a 00 00    	je     36af7 <oriole_expat::dispatch+0x2c77>
   350e5:	4d 89 c4             	mov    %r8,%r12
   350e8:	48 8b 41 30          	mov    0x30(%rcx),%rax
   350ec:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   350f3:	00 
   350f4:	0f 10 01             	movups (%rcx),%xmm0
   350f7:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   350fb:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   350ff:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   35106:	00 
   35107:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   3510e:	00 
   3510f:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   35116:	00 
   35117:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3511e:	00 
   3511f:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   35126:	00 
   35127:	ff 15 1b 1a 0b 00    	call   *0xb1a1b(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   3512d:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   35134:	00 
   35135:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   3513c:	00 00 
   3513e:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   35142:	0f 84 74 29 00 00    	je     37abc <oriole_expat::dispatch+0x3c3c>
   35148:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   3514f:	00 
   35150:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   35157:	00 
   35158:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   3515f:	00 
   35160:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   35167:	00 
   35168:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   3516d:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   35172:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   35177:	44 88 7c 24 68       	mov    %r15b,0x68(%rsp)
   3517c:	48 8b 9c 24 80 00 00 	mov    0x80(%rsp),%rbx
   35183:	00 
   35184:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   3518b:	00 
   3518c:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   35193:	00 
   35194:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   3519b:	00 
   3519c:	0f 28 8c 24 f0 00 00 	movaps 0xf0(%rsp),%xmm1
   351a3:	00 
   351a4:	0f 28 94 24 00 01 00 	movaps 0x100(%rsp),%xmm2
   351ab:	00 
   351ac:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   351b3:	00 
   351b4:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   351bb:	00 
   351bc:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   351c3:	00 
   351c4:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   351cb:	00 
   351cc:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   351d3:	00 
   351d4:	ff 15 6e 19 0b 00    	call   *0xb196e(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   351da:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   351e1:	00 
   351e2:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   351e9:	00 00 
   351eb:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   351ef:	0f 84 68 2f 00 00    	je     3815d <oriole_expat::dispatch+0x42dd>
   351f5:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   351fc:	00 
   351fd:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   35204:	00 
   35205:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   3520c:	00 
   3520d:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   35214:	00 
   35215:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   3521c:	00 
   3521d:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   35224:	00 
   35225:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   3522c:	00 
   3522d:	44 88 bc 24 a8 00 00 	mov    %r15b,0xa8(%rsp)
   35234:	00 
   35235:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
   3523c:	00 
   3523d:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   35242:	48 89 de             	mov    %rbx,%rsi
   35245:	41 ff d4             	call   *%r12
   35248:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   3524f:	00 
   35250:	48 85 c9             	test   %rcx,%rcx
   35253:	74 1b                	je     35270 <oriole_expat::dispatch+0x13f0>
   35255:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   3525c:	00 
   3525d:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   35264:	00 
   35265:	ba 01 00 00 00       	mov    $0x1,%edx
   3526a:	ff 15 08 18 0b 00    	call   *0xb1808(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   35270:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   35277:	00 
   35278:	48 85 c9             	test   %rcx,%rcx
   3527b:	74 18                	je     35295 <oriole_expat::dispatch+0x1415>
   3527d:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   35284:	00 
   35285:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3528a:	ba 01 00 00 00       	mov    $0x1,%edx
   3528f:	ff 15 e3 17 0b 00    	call   *0xb17e3(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   35295:	b3 01                	mov    $0x1,%bl
   35297:	e9 fb 2f 00 00       	jmp    38297 <oriole_expat::dispatch+0x4417>
   3529c:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
   352a3:	00 
   352a4:	48 8b 41 30          	mov    0x30(%rcx),%rax
   352a8:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   352af:	00 
   352b0:	0f 10 01             	movups (%rcx),%xmm0
   352b3:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   352b7:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   352bb:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   352c2:	00 
   352c3:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   352ca:	00 
   352cb:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   352d2:	00 
   352d3:	4c 8b bc 24 c8 05 00 	mov    0x5c8(%rsp),%r15
   352da:	00 
   352db:	4d 85 ff             	test   %r15,%r15
   352de:	0f 84 c5 18 00 00    	je     36ba9 <oriole_expat::dispatch+0x2d29>
   352e4:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   352eb:	00 
   352ec:	ff 15 8e 18 0b 00    	call   *0xb188e(%rip)        # e6b80 <_GLOBAL_OFFSET_TABLE_+0x240>
   352f2:	48 89 c3             	mov    %rax,%rbx
   352f5:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   352fc:	00 
   352fd:	ff 15 7d 18 0b 00    	call   *0xb187d(%rip)        # e6b80 <_GLOBAL_OFFSET_TABLE_+0x240>
   35303:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   35308:	48 89 de             	mov    %rbx,%rsi
   3530b:	41 ff d7             	call   *%r15
   3530e:	b0 01                	mov    $0x1,%al
   35310:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35314:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   3531b:	00 
   3531c:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   35323:	00 
   35324:	b0 01                	mov    $0x1,%al
   35326:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3532a:	b0 01                	mov    $0x1,%al
   3532c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   35330:	b0 01                	mov    $0x1,%al
   35332:	89 44 24 14          	mov    %eax,0x14(%rsp)
   35336:	b0 01                	mov    $0x1,%al
   35338:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3533c:	b0 01                	mov    $0x1,%al
   3533e:	89 44 24 40          	mov    %eax,0x40(%rsp)
   35342:	b0 01                	mov    $0x1,%al
   35344:	89 44 24 08          	mov    %eax,0x8(%rsp)
   35348:	b0 01                	mov    $0x1,%al
   3534a:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3534e:	b0 01                	mov    $0x1,%al
   35350:	89 44 24 24          	mov    %eax,0x24(%rsp)
   35354:	b0 01                	mov    $0x1,%al
   35356:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3535b:	b0 01                	mov    $0x1,%al
   3535d:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   35361:	40 b5 01             	mov    $0x1,%bpl
   35364:	41 b7 01             	mov    $0x1,%r15b
   35367:	41 b4 01             	mov    $0x1,%r12b
   3536a:	41 b5 01             	mov    $0x1,%r13b
   3536d:	e8 6e cf ff ff       	call   322e0 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   35372:	b0 01                	mov    $0x1,%al
   35374:	89 44 24 14          	mov    %eax,0x14(%rsp)
   35378:	b0 01                	mov    $0x1,%al
   3537a:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3537e:	b0 01                	mov    $0x1,%al
   35380:	89 44 24 30          	mov    %eax,0x30(%rsp)
   35384:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   3538b:	00 
   3538c:	e9 e2 06 00 00       	jmp    35a73 <oriole_expat::dispatch+0x1bf3>
   35391:	48 85 ed             	test   %rbp,%rbp
   35394:	e9 2c 04 00 00       	jmp    357c5 <oriole_expat::dispatch+0x1945>
   35399:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
   353a0:	00 
   353a1:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   353a8:	00 
   353a9:	0f 10 84 24 28 01 00 	movups 0x128(%rsp),%xmm0
   353b0:	00 
   353b1:	0f 10 8c 24 38 01 00 	movups 0x138(%rsp),%xmm1
   353b8:	00 
   353b9:	0f 10 94 24 48 01 00 	movups 0x148(%rsp),%xmm2
   353c0:	00 
   353c1:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   353c8:	00 
   353c9:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   353d0:	00 
   353d1:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   353d8:	00 
   353d9:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
   353e0:	00 
   353e1:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   353e8:	00 
   353e9:	0f 10 84 24 80 01 00 	movups 0x180(%rsp),%xmm0
   353f0:	00 
   353f1:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   353f8:	00 
   353f9:	0f 10 84 24 70 01 00 	movups 0x170(%rsp),%xmm0
   35400:	00 
   35401:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   35406:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
   3540d:	00 
   3540e:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   35413:	4c 8b a4 24 b0 05 00 	mov    0x5b0(%rsp),%r12
   3541a:	00 
   3541b:	4d 85 e4             	test   %r12,%r12
   3541e:	0f 84 40 18 00 00    	je     36c64 <oriole_expat::dispatch+0x2de4>
   35424:	0f b6 ac 24 98 01 00 	movzbl 0x198(%rsp),%ebp
   3542b:	00 
   3542c:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
   35433:	00 
   35434:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   3543b:	00 
   3543c:	0f 10 84 24 28 01 00 	movups 0x128(%rsp),%xmm0
   35443:	00 
   35444:	0f 10 8c 24 38 01 00 	movups 0x138(%rsp),%xmm1
   3544b:	00 
   3544c:	0f 10 94 24 48 01 00 	movups 0x148(%rsp),%xmm2
   35453:	00 
   35454:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   3545b:	00 
   3545c:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   35463:	00 
   35464:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   3546b:	00 
   3546c:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35473:	00 
   35474:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3547b:	00 
   3547c:	ff 15 c6 16 0b 00    	call   *0xb16c6(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   35482:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   35489:	00 
   3548a:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   35491:	00 00 
   35493:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   35497:	0f 84 50 26 00 00    	je     37aed <oriole_expat::dispatch+0x3c6d>
   3549d:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   354a4:	00 
   354a5:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   354ac:	00 
   354ad:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   354b4:	00 
   354b5:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   354bc:	00 
   354bd:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   354c4:	00 
   354c5:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   354cc:	00 
   354cd:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   354d4:	00 
   354d5:	44 88 bc 24 a8 00 00 	mov    %r15b,0xa8(%rsp)
   354dc:	00 
   354dd:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
   354e4:	00 
   354e5:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   354ec:	00 
   354ed:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
   354f2:	e8 39 d9 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   354f7:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   354fe:	00 
   354ff:	44 0f b6 bc 24 48 03 	movzbl 0x348(%rsp),%r15d
   35506:	00 00 
   35508:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   3550c:	0f 85 b1 27 00 00    	jne    37cc3 <oriole_expat::dispatch+0x3e43>
   35512:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   35519:	00 
   3551a:	48 85 c9             	test   %rcx,%rcx
   3551d:	0f 84 d4 25 00 00    	je     37af7 <oriole_expat::dispatch+0x3c77>
   35523:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3552a:	00 
   3552b:	ba 01 00 00 00       	mov    $0x1,%edx
   35530:	48 89 de             	mov    %rbx,%rsi
   35533:	ff 15 3f 15 0b 00    	call   *0xb153f(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   35539:	e9 b9 25 00 00       	jmp    37af7 <oriole_expat::dispatch+0x3c77>
   3553e:	48 83 bc 24 18 02 00 	cmpq   $0x0,0x218(%rsp)
   35545:	00 00 
   35547:	e9 79 02 00 00       	jmp    357c5 <oriole_expat::dispatch+0x1945>
   3554c:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
   35553:	00 
   35554:	48 8b 41 30          	mov    0x30(%rcx),%rax
   35558:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   3555f:	00 
   35560:	0f 10 01             	movups (%rcx),%xmm0
   35563:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   35567:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   3556b:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   35572:	00 
   35573:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   3557a:	00 
   3557b:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   35582:	00 
   35583:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
   3558a:	00 
   3558b:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   35592:	00 
   35593:	0f 10 84 24 68 01 00 	movups 0x168(%rsp),%xmm0
   3559a:	00 
   3559b:	0f 10 8c 24 78 01 00 	movups 0x178(%rsp),%xmm1
   355a2:	00 
   355a3:	0f 10 94 24 88 01 00 	movups 0x188(%rsp),%xmm2
   355aa:	00 
   355ab:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   355b2:	00 
   355b3:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   355b8:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   355bd:	48 8b 9c 24 d8 05 00 	mov    0x5d8(%rsp),%rbx
   355c4:	00 
   355c5:	48 85 db             	test   %rbx,%rbx
   355c8:	0f 84 2a 17 00 00    	je     36cf8 <oriole_expat::dispatch+0x2e78>
   355ce:	48 8b 41 30          	mov    0x30(%rcx),%rax
   355d2:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   355d9:	00 
   355da:	0f 10 01             	movups (%rcx),%xmm0
   355dd:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   355e1:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   355e5:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   355ec:	00 
   355ed:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   355f4:	00 
   355f5:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   355fc:	00 
   355fd:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35604:	00 
   35605:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3560c:	00 
   3560d:	e8 1e d8 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   35612:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   35619:	00 
   3561a:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   35621:	00 00 
   35623:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   35627:	0f 85 3d 22 00 00    	jne    3786a <oriole_expat::dispatch+0x39ea>
   3562d:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   35632:	e8 59 9d ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   35637:	e9 5c 28 00 00       	jmp    37e98 <oriole_expat::dispatch+0x4018>
   3563c:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
   35643:	00 
   35644:	48 8b 41 30          	mov    0x30(%rcx),%rax
   35648:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   3564f:	00 
   35650:	0f 10 01             	movups (%rcx),%xmm0
   35653:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   35657:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   3565b:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   35662:	00 
   35663:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   35668:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   3566d:	4d 85 e4             	test   %r12,%r12
   35670:	0f 84 f5 16 00 00    	je     36d6b <oriole_expat::dispatch+0x2eeb>
   35676:	4c 89 e3             	mov    %r12,%rbx
   35679:	48 8b 41 30          	mov    0x30(%rcx),%rax
   3567d:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   35684:	00 
   35685:	0f 10 01             	movups (%rcx),%xmm0
   35688:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   3568c:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   35690:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   35697:	00 
   35698:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   3569f:	00 
   356a0:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   356a7:	00 
   356a8:	b0 01                	mov    $0x1,%al
   356aa:	89 44 24 28          	mov    %eax,0x28(%rsp)
   356ae:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   356b5:	00 00 
   356b7:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   356be:	00 
   356bf:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   356c6:	00 
   356c7:	b0 01                	mov    $0x1,%al
   356c9:	89 44 24 30          	mov    %eax,0x30(%rsp)
   356cd:	b0 01                	mov    $0x1,%al
   356cf:	89 44 24 48          	mov    %eax,0x48(%rsp)
   356d3:	b0 01                	mov    $0x1,%al
   356d5:	89 44 24 38          	mov    %eax,0x38(%rsp)
   356d9:	b0 01                	mov    $0x1,%al
   356db:	89 44 24 14          	mov    %eax,0x14(%rsp)
   356df:	b0 01                	mov    $0x1,%al
   356e1:	89 44 24 10          	mov    %eax,0x10(%rsp)
   356e5:	b0 01                	mov    $0x1,%al
   356e7:	89 44 24 40          	mov    %eax,0x40(%rsp)
   356eb:	b0 01                	mov    $0x1,%al
   356ed:	89 44 24 08          	mov    %eax,0x8(%rsp)
   356f1:	b0 01                	mov    $0x1,%al
   356f3:	89 44 24 04          	mov    %eax,0x4(%rsp)
   356f7:	b0 01                	mov    $0x1,%al
   356f9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   356fd:	b0 01                	mov    $0x1,%al
   356ff:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   35703:	40 b5 01             	mov    $0x1,%bpl
   35706:	41 b7 01             	mov    $0x1,%r15b
   35709:	41 b4 01             	mov    $0x1,%r12b
   3570c:	41 b5 01             	mov    $0x1,%r13b
   3570f:	e8 1c d7 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   35714:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   3571b:	00 
   3571c:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   35723:	00 00 
   35725:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   35729:	0f 85 92 21 00 00    	jne    378c1 <oriole_expat::dispatch+0x3a41>
   3572f:	b0 01                	mov    $0x1,%al
   35731:	89 44 24 10          	mov    %eax,0x10(%rsp)
   35735:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   3573c:	00 00 
   3573e:	b0 01                	mov    $0x1,%al
   35740:	89 44 24 28          	mov    %eax,0x28(%rsp)
   35744:	b0 01                	mov    $0x1,%al
   35746:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3574a:	b0 01                	mov    $0x1,%al
   3574c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   35750:	b0 01                	mov    $0x1,%al
   35752:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35756:	b0 01                	mov    $0x1,%al
   35758:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3575c:	b0 01                	mov    $0x1,%al
   3575e:	89 44 24 40          	mov    %eax,0x40(%rsp)
   35762:	b0 01                	mov    $0x1,%al
   35764:	89 44 24 08          	mov    %eax,0x8(%rsp)
   35768:	b0 01                	mov    $0x1,%al
   3576a:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3576e:	b0 01                	mov    $0x1,%al
   35770:	89 44 24 24          	mov    %eax,0x24(%rsp)
   35774:	e9 2f 32 00 00       	jmp    389a8 <oriole_expat::dispatch+0x4b28>
   35779:	48 8b 84 24 c0 05 00 	mov    0x5c0(%rsp),%rax
   35780:	00 
   35781:	48 85 c0             	test   %rax,%rax
   35784:	0f 84 47 16 00 00    	je     36dd1 <oriole_expat::dispatch+0x2f51>
   3578a:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   3578f:	ff d0                	call   *%rax
   35791:	41 c6 86 60 0b 00 00 	movb   $0x0,0xb60(%r14)
   35798:	00 
   35799:	b0 01                	mov    $0x1,%al
   3579b:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3579f:	b0 01                	mov    $0x1,%al
   357a1:	89 44 24 28          	mov    %eax,0x28(%rsp)
   357a5:	b0 01                	mov    $0x1,%al
   357a7:	89 44 24 30          	mov    %eax,0x30(%rsp)
   357ab:	b0 01                	mov    $0x1,%al
   357ad:	89 44 24 48          	mov    %eax,0x48(%rsp)
   357b1:	b0 01                	mov    $0x1,%al
   357b3:	89 44 24 38          	mov    %eax,0x38(%rsp)
   357b7:	b0 01                	mov    $0x1,%al
   357b9:	89 44 24 14          	mov    %eax,0x14(%rsp)
   357bd:	e9 d7 16 00 00       	jmp    36e99 <oriole_expat::dispatch+0x3019>
   357c2:	4d 85 d2             	test   %r10,%r10
   357c5:	0f 95 c3             	setne  %bl
   357c8:	b0 01                	mov    $0x1,%al
   357ca:	b1 01                	mov    $0x1,%cl
   357cc:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   357d0:	b1 01                	mov    $0x1,%cl
   357d2:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   357d6:	b1 01                	mov    $0x1,%cl
   357d8:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   357dc:	b1 01                	mov    $0x1,%cl
   357de:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   357e2:	b1 01                	mov    $0x1,%cl
   357e4:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   357e8:	b1 01                	mov    $0x1,%cl
   357ea:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   357ee:	b1 01                	mov    $0x1,%cl
   357f0:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   357f4:	b1 01                	mov    $0x1,%cl
   357f6:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   357fa:	b1 01                	mov    $0x1,%cl
   357fc:	89 4c 24 20          	mov    %ecx,0x20(%rsp)
   35800:	b1 01                	mov    $0x1,%cl
   35802:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
   35806:	b1 01                	mov    $0x1,%cl
   35808:	89 4c 24 1c          	mov    %ecx,0x1c(%rsp)
   3580c:	b2 01                	mov    $0x1,%dl
   3580e:	b1 01                	mov    $0x1,%cl
   35810:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   35814:	89 44 24 28          	mov    %eax,0x28(%rsp)
   35818:	b1 01                	mov    $0x1,%cl
   3581a:	40 b6 01             	mov    $0x1,%sil
   3581d:	84 db                	test   %bl,%bl
   3581f:	0f 85 bd 1d 00 00    	jne    375e2 <oriole_expat::dispatch+0x3762>
   35825:	41 80 be 0a 0a 00 00 	cmpb   $0x0,0xa0a(%r14)
   3582c:	00 
   3582d:	0f 85 ed 00 00 00    	jne    35920 <oriole_expat::dispatch+0x1aa0>
   35833:	49 83 be c0 09 00 00 	cmpq   $0x0,0x9c0(%r14)
   3583a:	00 
   3583b:	0f 84 df 00 00 00    	je     35920 <oriole_expat::dispatch+0x1aa0>
   35841:	89 54 24 2c          	mov    %edx,0x2c(%rsp)
   35845:	49 8b 96 50 05 00 00 	mov    0x550(%r14),%rdx
   3584c:	48 85 d2             	test   %rdx,%rdx
   3584f:	0f 84 d5 00 00 00    	je     3592a <oriole_expat::dispatch+0x1aaa>
   35855:	49 8b b6 40 05 00 00 	mov    0x540(%r14),%rsi
   3585c:	41 0f 10 46 08       	movups 0x8(%r14),%xmm0
   35861:	41 0f 10 4e 18       	movups 0x18(%r14),%xmm1
   35866:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   3586b:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   35870:	b0 01                	mov    $0x1,%al
   35872:	89 44 24 24          	mov    %eax,0x24(%rsp)
   35876:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3587d:	00 
   3587e:	48 8d 4c 24 60       	lea    0x60(%rsp),%rcx
   35883:	b0 01                	mov    $0x1,%al
   35885:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3588a:	8b 6c 24 20          	mov    0x20(%rsp),%ebp
   3588e:	44 8b 7c 24 18       	mov    0x18(%rsp),%r15d
   35893:	44 8b 64 24 1c       	mov    0x1c(%rsp),%r12d
   35898:	44 8b 6c 24 2c       	mov    0x2c(%rsp),%r13d
   3589d:	ff 15 fd 11 0b 00    	call   *0xb11fd(%rip)        # e6aa0 <_GLOBAL_OFFSET_TABLE_+0x160>
   358a3:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   358aa:	00 
   358ab:	44 0f b6 bc 24 48 03 	movzbl 0x348(%rsp),%r15d
   358b2:	00 00 
   358b4:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   358bb:	00 
   358bc:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   358c3:	00 
   358c4:	0f 10 84 24 59 03 00 	movups 0x359(%rsp),%xmm0
   358cb:	00 
   358cc:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
   358d3:	00 
   358d4:	0f 10 84 24 68 03 00 	movups 0x368(%rsp),%xmm0
   358db:	00 
   358dc:	0f 11 84 24 3f 02 00 	movups %xmm0,0x23f(%rsp)
   358e3:	00 
   358e4:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   358e8:	0f 84 5b 25 00 00    	je     37e49 <oriole_expat::dispatch+0x3fc9>
   358ee:	0f 10 84 24 3f 02 00 	movups 0x23f(%rsp),%xmm0
   358f5:	00 
   358f6:	0f 11 84 24 bf 00 00 	movups %xmm0,0xbf(%rsp)
   358fd:	00 
   358fe:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
   35905:	00 
   35906:	0f 28 8c 24 30 02 00 	movaps 0x230(%rsp),%xmm1
   3590d:	00 
   3590e:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   35915:	00 
   35916:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   3591d:	00 
   3591e:	eb 11                	jmp    35931 <oriole_expat::dispatch+0x1ab1>
   35920:	b1 01                	mov    $0x1,%cl
   35922:	40 b6 01             	mov    $0x1,%sil
   35925:	e9 b8 1c 00 00       	jmp    375e2 <oriole_expat::dispatch+0x3762>
   3592a:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   35931:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
   35938:	00 
   35939:	0f 28 8c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm1
   35940:	00 
   35941:	0f 29 84 24 20 06 00 	movaps %xmm0,0x620(%rsp)
   35948:	00 
   35949:	0f 29 8c 24 30 06 00 	movaps %xmm1,0x630(%rsp)
   35950:	00 
   35951:	0f 10 84 24 bf 00 00 	movups 0xbf(%rsp),%xmm0
   35958:	00 
   35959:	0f 11 84 24 3f 06 00 	movups %xmm0,0x63f(%rsp)
   35960:	00 
   35961:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   35965:	0f 84 6e 1c 00 00    	je     375d9 <oriole_expat::dispatch+0x3759>
   3596b:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   35972:	00 
   35973:	44 88 bc 24 28 02 00 	mov    %r15b,0x228(%rsp)
   3597a:	00 
   3597b:	0f 28 84 24 20 06 00 	movaps 0x620(%rsp),%xmm0
   35982:	00 
   35983:	0f 28 8c 24 30 06 00 	movaps 0x630(%rsp),%xmm1
   3598a:	00 
   3598b:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   35992:	00 
   35993:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   3599a:	00 
   3599b:	0f 10 84 24 3f 06 00 	movups 0x63f(%rsp),%xmm0
   359a2:	00 
   359a3:	0f 11 84 24 48 02 00 	movups %xmm0,0x248(%rsp)
   359aa:	00 
   359ab:	8b 84 24 38 03 00 00 	mov    0x338(%rsp),%eax
   359b2:	20 84 24 80 04 00 00 	and    %al,0x480(%rsp)
   359b9:	0f 84 d9 0d 00 00    	je     36798 <oriole_expat::dispatch+0x2918>
   359bf:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
   359c6:	00 
   359c7:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   359ce:	00 
   359cf:	48 b9 3c 21 45 4e 54 	movabs $0x595449544e45213c,%rcx
   359d6:	49 54 59 
   359d9:	48 83 f8 08          	cmp    $0x8,%rax
   359dd:	0f 83 63 18 00 00    	jae    37246 <oriole_expat::dispatch+0x33c6>
   359e3:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   359ea:	00 
   359eb:	e9 60 18 00 00       	jmp    37250 <oriole_expat::dispatch+0x33d0>
   359f0:	b0 01                	mov    $0x1,%al
   359f2:	89 44 24 28          	mov    %eax,0x28(%rsp)
   359f6:	b0 01                	mov    $0x1,%al
   359f8:	89 44 24 30          	mov    %eax,0x30(%rsp)
   359fc:	b0 01                	mov    $0x1,%al
   359fe:	89 44 24 48          	mov    %eax,0x48(%rsp)
   35a02:	b0 01                	mov    $0x1,%al
   35a04:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35a08:	b0 01                	mov    $0x1,%al
   35a0a:	89 44 24 14          	mov    %eax,0x14(%rsp)
   35a0e:	b0 01                	mov    $0x1,%al
   35a10:	89 44 24 10          	mov    %eax,0x10(%rsp)
   35a14:	b0 01                	mov    $0x1,%al
   35a16:	89 44 24 40          	mov    %eax,0x40(%rsp)
   35a1a:	b0 01                	mov    $0x1,%al
   35a1c:	89 44 24 08          	mov    %eax,0x8(%rsp)
   35a20:	b0 01                	mov    $0x1,%al
   35a22:	89 44 24 04          	mov    %eax,0x4(%rsp)
   35a26:	b0 01                	mov    $0x1,%al
   35a28:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   35a2c:	b0 01                	mov    $0x1,%al
   35a2e:	89 44 24 20          	mov    %eax,0x20(%rsp)
   35a32:	b0 01                	mov    $0x1,%al
   35a34:	89 44 24 18          	mov    %eax,0x18(%rsp)
   35a38:	b0 01                	mov    $0x1,%al
   35a3a:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   35a3e:	b2 01                	mov    $0x1,%dl
   35a40:	48 83 bc 24 a8 05 00 	cmpq   $0x0,0x5a8(%rsp)
   35a47:	00 00 
   35a49:	0f 84 d6 fd ff ff    	je     35825 <oriole_expat::dispatch+0x19a5>
   35a4f:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   35a54:	ff 94 24 a8 05 00 00 	call   *0x5a8(%rsp)
   35a5b:	b0 01                	mov    $0x1,%al
   35a5d:	89 44 24 14          	mov    %eax,0x14(%rsp)
   35a61:	b0 01                	mov    $0x1,%al
   35a63:	89 44 24 28          	mov    %eax,0x28(%rsp)
   35a67:	b0 01                	mov    $0x1,%al
   35a69:	89 44 24 30          	mov    %eax,0x30(%rsp)
   35a6d:	b0 01                	mov    $0x1,%al
   35a6f:	89 44 24 48          	mov    %eax,0x48(%rsp)
   35a73:	b0 01                	mov    $0x1,%al
   35a75:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35a79:	e9 15 14 00 00       	jmp    36e93 <oriole_expat::dispatch+0x3013>
   35a7e:	49 89 dd             	mov    %rbx,%r13
   35a81:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
   35a86:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
   35a8d:	00 
   35a8e:	0f 10 00             	movups (%rax),%xmm0
   35a91:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   35a95:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   35a9c:	00 
   35a9d:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   35aa4:	00 
   35aa5:	48 8b 9c 24 50 01 00 	mov    0x150(%rsp),%rbx
   35aac:	00 
   35aad:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   35ab4:	00 
   35ab5:	ba 20 01 00 00       	mov    $0x120,%edx
   35aba:	48 89 de             	mov    %rbx,%rsi
   35abd:	ff 15 9d 18 0b 00    	call   *0xb189d(%rip)        # e7360 <memcpy@GLIBC_2.14>
   35ac3:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   35aca:	00 
   35acb:	ba 08 00 00 00       	mov    $0x8,%edx
   35ad0:	b9 20 01 00 00       	mov    $0x120,%ecx
   35ad5:	48 89 de             	mov    %rbx,%rsi
   35ad8:	ff 15 9a 0f 0b 00    	call   *0xb0f9a(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   35ade:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35ae5:	00 
   35ae6:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   35aed:	00 
   35aee:	ba 18 01 00 00       	mov    $0x118,%edx
   35af3:	ff 15 67 18 0b 00    	call   *0xb1867(%rip)        # e7360 <memcpy@GLIBC_2.14>
   35af9:	0f b6 94 24 58 04 00 	movzbl 0x458(%rsp),%edx
   35b00:	00 
   35b01:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   35b08:	00 
   35b09:	48 89 84 24 80 05 00 	mov    %rax,0x580(%rsp)
   35b10:	00 
   35b11:	0f 10 84 24 20 02 00 	movups 0x220(%rsp),%xmm0
   35b18:	00 
   35b19:	0f 10 8c 24 30 02 00 	movups 0x230(%rsp),%xmm1
   35b20:	00 
   35b21:	0f 10 94 24 40 02 00 	movups 0x240(%rsp),%xmm2
   35b28:	00 
   35b29:	0f 29 94 24 70 05 00 	movaps %xmm2,0x570(%rsp)
   35b30:	00 
   35b31:	0f 29 8c 24 60 05 00 	movaps %xmm1,0x560(%rsp)
   35b38:	00 
   35b39:	0f 29 84 24 50 05 00 	movaps %xmm0,0x550(%rsp)
   35b40:	00 
   35b41:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
   35b48:	00 
   35b49:	48 89 84 24 10 06 00 	mov    %rax,0x610(%rsp)
   35b50:	00 
   35b51:	0f 10 84 24 78 02 00 	movups 0x278(%rsp),%xmm0
   35b58:	00 
   35b59:	0f 29 84 24 00 06 00 	movaps %xmm0,0x600(%rsp)
   35b60:	00 
   35b61:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   35b68:	00 
   35b69:	0f 29 84 24 f0 05 00 	movaps %xmm0,0x5f0(%rsp)
   35b70:	00 
   35b71:	0f 10 84 24 58 02 00 	movups 0x258(%rsp),%xmm0
   35b78:	00 
   35b79:	0f 29 84 24 e0 05 00 	movaps %xmm0,0x5e0(%rsp)
   35b80:	00 
   35b81:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
   35b88:	00 
   35b89:	48 89 84 24 10 05 00 	mov    %rax,0x510(%rsp)
   35b90:	00 
   35b91:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   35b98:	00 
   35b99:	0f 10 8c 24 a0 02 00 	movups 0x2a0(%rsp),%xmm1
   35ba0:	00 
   35ba1:	0f 10 94 24 b0 02 00 	movups 0x2b0(%rsp),%xmm2
   35ba8:	00 
   35ba9:	0f 29 94 24 00 05 00 	movaps %xmm2,0x500(%rsp)
   35bb0:	00 
   35bb1:	0f 29 8c 24 f0 04 00 	movaps %xmm1,0x4f0(%rsp)
   35bb8:	00 
   35bb9:	0f 29 84 24 e0 04 00 	movaps %xmm0,0x4e0(%rsp)
   35bc0:	00 
   35bc1:	48 8b 84 24 f8 02 00 	mov    0x2f8(%rsp),%rax
   35bc8:	00 
   35bc9:	48 89 84 24 d0 04 00 	mov    %rax,0x4d0(%rsp)
   35bd0:	00 
   35bd1:	0f 10 84 24 c8 02 00 	movups 0x2c8(%rsp),%xmm0
   35bd8:	00 
   35bd9:	0f 10 8c 24 d8 02 00 	movups 0x2d8(%rsp),%xmm1
   35be0:	00 
   35be1:	0f 10 94 24 e8 02 00 	movups 0x2e8(%rsp),%xmm2
   35be8:	00 
   35be9:	0f 29 94 24 c0 04 00 	movaps %xmm2,0x4c0(%rsp)
   35bf0:	00 
   35bf1:	0f 29 8c 24 b0 04 00 	movaps %xmm1,0x4b0(%rsp)
   35bf8:	00 
   35bf9:	0f 29 84 24 a0 04 00 	movaps %xmm0,0x4a0(%rsp)
   35c00:	00 
   35c01:	48 8b 84 24 30 03 00 	mov    0x330(%rsp),%rax
   35c08:	00 
   35c09:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   35c10:	00 
   35c11:	0f 10 84 24 00 03 00 	movups 0x300(%rsp),%xmm0
   35c18:	00 
   35c19:	0f 10 8c 24 10 03 00 	movups 0x310(%rsp),%xmm1
   35c20:	00 
   35c21:	0f 10 94 24 20 03 00 	movups 0x320(%rsp),%xmm2
   35c28:	00 
   35c29:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   35c30:	00 
   35c31:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   35c38:	00 
   35c39:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   35c40:	00 
   35c41:	48 83 bc 24 a0 01 00 	cmpq   $0xffffffffffffffff,0x1a0(%rsp)
   35c48:	00 ff 
   35c4a:	0f 94 c0             	sete   %al
   35c4d:	4d 85 ed             	test   %r13,%r13
   35c50:	40 0f 94 c5          	sete   %bpl
   35c54:	40 08 c5             	or     %al,%bpl
   35c57:	40 80 fd 01          	cmp    $0x1,%bpl
   35c5b:	0f 85 e1 0b 00 00    	jne    36842 <oriole_expat::dispatch+0x29c2>
   35c61:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
   35c67:	0f 84 5a 21 00 00    	je     37dc7 <oriole_expat::dispatch+0x3f47>
   35c6d:	41 89 d5             	mov    %edx,%r13d
   35c70:	45 31 ff             	xor    %r15d,%r15d
   35c73:	48 83 bc 24 e0 05 00 	cmpq   $0xffffffffffffffff,0x5e0(%rsp)
   35c7a:	00 ff 
   35c7c:	bd 00 00 00 00       	mov    $0x0,%ebp
   35c81:	74 07                	je     35c8a <oriole_expat::dispatch+0x1e0a>
   35c83:	8b ac 24 10 06 00 00 	mov    0x610(%rsp),%ebp
   35c8a:	48 8b 84 24 80 05 00 	mov    0x580(%rsp),%rax
   35c91:	00 
   35c92:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   35c99:	00 
   35c9a:	0f 28 84 24 50 05 00 	movaps 0x550(%rsp),%xmm0
   35ca1:	00 
   35ca2:	0f 28 8c 24 60 05 00 	movaps 0x560(%rsp),%xmm1
   35ca9:	00 
   35caa:	0f 28 94 24 70 05 00 	movaps 0x570(%rsp),%xmm2
   35cb1:	00 
   35cb2:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   35cb9:	00 
   35cba:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   35cc1:	00 
   35cc2:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   35cc9:	00 
   35cca:	b0 01                	mov    $0x1,%al
   35ccc:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35cd0:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35cd7:	00 
   35cd8:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   35cdf:	00 
   35ce0:	b0 01                	mov    $0x1,%al
   35ce2:	89 44 24 30          	mov    %eax,0x30(%rsp)
   35ce6:	b3 01                	mov    $0x1,%bl
   35ce8:	41 b4 01             	mov    $0x1,%r12b
   35ceb:	ff 15 57 0e 0b 00    	call   *0xb0e57(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   35cf1:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   35cf8:	00 
   35cf9:	0f b6 8c 24 28 02 00 	movzbl 0x228(%rsp),%ecx
   35d00:	00 
   35d01:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   35d05:	0f 84 3d 26 00 00    	je     38348 <oriole_expat::dispatch+0x44c8>
   35d0b:	89 6c 24 30          	mov    %ebp,0x30(%rsp)
   35d0f:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   35d16:	00 
   35d17:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   35d1e:	00 
   35d1f:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   35d26:	00 
   35d27:	0f 11 94 24 08 02 00 	movups %xmm2,0x208(%rsp)
   35d2e:	00 
   35d2f:	0f 11 8c 24 f9 01 00 	movups %xmm1,0x1f9(%rsp)
   35d36:	00 
   35d37:	0f 11 84 24 e9 01 00 	movups %xmm0,0x1e9(%rsp)
   35d3e:	00 
   35d3f:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
   35d46:	00 
   35d47:	88 8c 24 e8 01 00 00 	mov    %cl,0x1e8(%rsp)
   35d4e:	48 8b ac 24 00 02 00 	mov    0x200(%rsp),%rbp
   35d55:	00 
   35d56:	41 b4 01             	mov    $0x1,%r12b
   35d59:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   35d60:	00 
   35d61:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
   35d68:	00 
   35d69:	41 b7 01             	mov    $0x1,%r15b
   35d6c:	b3 01                	mov    $0x1,%bl
   35d6e:	e8 bd d0 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   35d73:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   35d7a:	00 
   35d7b:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   35d82:	00 
   35d83:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   35d87:	0f 85 60 27 00 00    	jne    384ed <oriole_expat::dispatch+0x466d>
   35d8d:	41 89 ce             	mov    %ecx,%r14d
   35d90:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   35d97:	00 
   35d98:	48 85 c9             	test   %rcx,%rcx
   35d9b:	74 2a                	je     35dc7 <oriole_expat::dispatch+0x1f47>
   35d9d:	b0 01                	mov    $0x1,%al
   35d9f:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35da3:	45 31 e4             	xor    %r12d,%r12d
   35da6:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   35dad:	00 
   35dae:	ba 01 00 00 00       	mov    $0x1,%edx
   35db3:	b0 01                	mov    $0x1,%al
   35db5:	89 44 24 30          	mov    %eax,0x30(%rsp)
   35db9:	b3 01                	mov    $0x1,%bl
   35dbb:	45 31 ff             	xor    %r15d,%r15d
   35dbe:	48 89 ee             	mov    %rbp,%rsi
   35dc1:	ff 15 b1 0c 0b 00    	call   *0xb0cb1(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   35dc7:	41 b5 01             	mov    $0x1,%r13b
   35dca:	45 31 e4             	xor    %r12d,%r12d
   35dcd:	b3 01                	mov    $0x1,%bl
   35dcf:	e9 33 33 00 00       	jmp    39107 <oriole_expat::dispatch+0x5287>
   35dd4:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
   35ddb:	00 
   35ddc:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   35de3:	00 
   35de4:	0f 10 84 24 68 01 00 	movups 0x168(%rsp),%xmm0
   35deb:	00 
   35dec:	0f 10 8c 24 78 01 00 	movups 0x178(%rsp),%xmm1
   35df3:	00 
   35df4:	0f 10 94 24 88 01 00 	movups 0x188(%rsp),%xmm2
   35dfb:	00 
   35dfc:	0f 29 94 24 00 02 00 	movaps %xmm2,0x200(%rsp)
   35e03:	00 
   35e04:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   35e0b:	00 
   35e0c:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   35e13:	00 
   35e14:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
   35e1b:	00 
   35e1c:	48 8b 41 30          	mov    0x30(%rcx),%rax
   35e20:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   35e27:	00 
   35e28:	0f 10 01             	movups (%rcx),%xmm0
   35e2b:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   35e2f:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   35e33:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   35e3a:	00 
   35e3b:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   35e42:	00 
   35e43:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   35e4a:	00 
   35e4b:	4c 8b a4 24 b0 05 00 	mov    0x5b0(%rsp),%r12
   35e52:	00 
   35e53:	4d 85 e4             	test   %r12,%r12
   35e56:	0f 84 8a 0f 00 00    	je     36de6 <oriole_expat::dispatch+0x2f66>
   35e5c:	48 8d 84 24 68 01 00 	lea    0x168(%rsp),%rax
   35e63:	00 
   35e64:	48 8b 48 30          	mov    0x30(%rax),%rcx
   35e68:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
   35e6f:	00 
   35e70:	0f 10 00             	movups (%rax),%xmm0
   35e73:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   35e77:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   35e7b:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   35e82:	00 
   35e83:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   35e8a:	00 
   35e8b:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   35e92:	00 
   35e93:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35e9a:	00 
   35e9b:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   35ea2:	00 
   35ea3:	e8 88 cf ff ff       	call   32e30 <oriole_expat::optional_cstring>
   35ea8:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   35eaf:	00 
   35eb0:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   35eb7:	00 00 
   35eb9:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   35ebd:	0f 85 55 1a 00 00    	jne    37918 <oriole_expat::dispatch+0x3a98>
   35ec3:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   35eca:	00 
   35ecb:	48 85 c9             	test   %rcx,%rcx
   35ece:	0f 84 a3 24 00 00    	je     38377 <oriole_expat::dispatch+0x44f7>
   35ed4:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   35edb:	00 
   35edc:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   35ee3:	00 
   35ee4:	ba 01 00 00 00       	mov    $0x1,%edx
   35ee9:	ff 15 89 0b 0b 00    	call   *0xb0b89(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   35eef:	e9 83 24 00 00       	jmp    38377 <oriole_expat::dispatch+0x44f7>
   35ef4:	48 8b 8c 24 b8 05 00 	mov    0x5b8(%rsp),%rcx
   35efb:	00 
   35efc:	b0 01                	mov    $0x1,%al
   35efe:	48 85 c9             	test   %rcx,%rcx
   35f01:	0f 84 70 0f 00 00    	je     36e77 <oriole_expat::dispatch+0x2ff7>
   35f07:	89 44 24 28          	mov    %eax,0x28(%rsp)
   35f0b:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   35f10:	ff d1                	call   *%rcx
   35f12:	85 c0                	test   %eax,%eax
   35f14:	0f 85 61 0f 00 00    	jne    36e7b <oriole_expat::dispatch+0x2ffb>
   35f1a:	48 b8 16 00 00 00 16 	movabs $0x1600000016,%rax
   35f21:	00 00 00 
   35f24:	49 89 86 10 0a 00 00 	mov    %rax,0xa10(%r14)
   35f2b:	e9 4b 0f 00 00       	jmp    36e7b <oriole_expat::dispatch+0x2ffb>
   35f30:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
   35f37:	00 
   35f38:	0f 10 00             	movups (%rax),%xmm0
   35f3b:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   35f3f:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   35f46:	00 
   35f47:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   35f4e:	00 
   35f4f:	48 8b 9c 24 50 01 00 	mov    0x150(%rsp),%rbx
   35f56:	00 
   35f57:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   35f5e:	00 
   35f5f:	ba b0 00 00 00       	mov    $0xb0,%edx
   35f64:	48 89 de             	mov    %rbx,%rsi
   35f67:	ff 15 f3 13 0b 00    	call   *0xb13f3(%rip)        # e7360 <memcpy@GLIBC_2.14>
   35f6d:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   35f74:	00 
   35f75:	ba 08 00 00 00       	mov    $0x8,%edx
   35f7a:	b9 b0 00 00 00       	mov    $0xb0,%ecx
   35f7f:	48 89 de             	mov    %rbx,%rsi
   35f82:	ff 15 f0 0a 0b 00    	call   *0xb0af0(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   35f88:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35f8f:	00 
   35f90:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   35f97:	00 
   35f98:	ba a8 00 00 00       	mov    $0xa8,%edx
   35f9d:	ff 15 bd 13 0b 00    	call   *0xb13bd(%rip)        # e7360 <memcpy@GLIBC_2.14>
   35fa3:	0f b6 9c 24 e8 03 00 	movzbl 0x3e8(%rsp),%ebx
   35faa:	00 
   35fab:	48 8b 94 24 18 02 00 	mov    0x218(%rsp),%rdx
   35fb2:	00 
   35fb3:	48 85 d2             	test   %rdx,%rdx
   35fb6:	0f 95 c0             	setne  %al
   35fb9:	89 d9                	mov    %ebx,%ecx
   35fbb:	80 f1 01             	xor    $0x1,%cl
   35fbe:	20 c1                	and    %al,%cl
   35fc0:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   35fc7:	00 
   35fc8:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   35fcf:	00 
   35fd0:	0f 10 84 24 20 02 00 	movups 0x220(%rsp),%xmm0
   35fd7:	00 
   35fd8:	0f 10 8c 24 30 02 00 	movups 0x230(%rsp),%xmm1
   35fdf:	00 
   35fe0:	0f 10 94 24 40 02 00 	movups 0x240(%rsp),%xmm2
   35fe7:	00 
   35fe8:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   35fef:	00 
   35ff0:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   35ff7:	00 
   35ff8:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   35fff:	00 
   36000:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
   36007:	00 
   36008:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   3600f:	00 
   36010:	0f 10 84 24 78 02 00 	movups 0x278(%rsp),%xmm0
   36017:	00 
   36018:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   3601f:	00 
   36020:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   36027:	00 
   36028:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
   3602f:	00 
   36030:	0f 10 84 24 58 02 00 	movups 0x258(%rsp),%xmm0
   36037:	00 
   36038:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   3603f:	00 
   36040:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
   36047:	00 
   36048:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   3604f:	00 
   36050:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   36057:	00 
   36058:	0f 10 8c 24 a0 02 00 	movups 0x2a0(%rsp),%xmm1
   3605f:	00 
   36060:	0f 10 94 24 b0 02 00 	movups 0x2b0(%rsp),%xmm2
   36067:	00 
   36068:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   3606f:	00 
   36070:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   36077:	00 
   36078:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   3607f:	00 
   36080:	41 88 8e 60 0b 00 00 	mov    %cl,0xb60(%r14)
   36087:	48 85 d2             	test   %rdx,%rdx
   3608a:	0f 84 25 10 00 00    	je     370b5 <oriole_expat::dispatch+0x3235>
   36090:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
   36097:	00 
   36098:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   3609f:	00 
   360a0:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
   360a7:	00 
   360a8:	0f 28 8c 24 b0 01 00 	movaps 0x1b0(%rsp),%xmm1
   360af:	00 
   360b0:	0f 28 94 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm2
   360b7:	00 
   360b8:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   360bf:	00 
   360c0:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   360c7:	00 
   360c8:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   360cf:	00 
   360d0:	40 b5 01             	mov    $0x1,%bpl
   360d3:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   360da:	00 
   360db:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   360e2:	00 
   360e3:	ff 15 5f 0a 0b 00    	call   *0xb0a5f(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   360e9:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   360f0:	00 
   360f1:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   360f8:	00 00 
   360fa:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   360fe:	0f 84 a5 1a 00 00    	je     37ba9 <oriole_expat::dispatch+0x3d29>
   36104:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   3610b:	00 
   3610c:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   36113:	00 
   36114:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   3611b:	00 
   3611c:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   36123:	00 
   36124:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   36129:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   3612e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   36133:	44 88 7c 24 68       	mov    %r15b,0x68(%rsp)
   36138:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
   3613f:	00 
   36140:	40 b5 01             	mov    $0x1,%bpl
   36143:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3614a:	00 
   3614b:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
   36152:	00 
   36153:	e8 d8 cc ff ff       	call   32e30 <oriole_expat::optional_cstring>
   36158:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   3615f:	00 
   36160:	44 0f b6 bc 24 48 03 	movzbl 0x348(%rsp),%r15d
   36167:	00 00 
   36169:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   3616d:	0f 85 fd 1b 00 00    	jne    37d70 <oriole_expat::dispatch+0x3ef0>
   36173:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   3617a:	00 
   3617b:	48 85 c9             	test   %rcx,%rcx
   3617e:	74 15                	je     36195 <oriole_expat::dispatch+0x2315>
   36180:	31 ed                	xor    %ebp,%ebp
   36182:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   36187:	ba 01 00 00 00       	mov    $0x1,%edx
   3618c:	4c 89 e6             	mov    %r12,%rsi
   3618f:	ff 15 e3 08 0b 00    	call   *0xb08e3(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   36195:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3619c:	00 
   3619d:	e8 ee 91 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   361a2:	e9 a0 24 00 00       	jmp    38647 <oriole_expat::dispatch+0x47c7>
   361a7:	4c 89 94 24 78 04 00 	mov    %r10,0x478(%rsp)
   361ae:	00 
   361af:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
   361b6:	00 
   361b7:	0f 10 00             	movups (%rax),%xmm0
   361ba:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   361be:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   361c5:	00 
   361c6:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   361cd:	00 
   361ce:	48 8b 9c 24 50 01 00 	mov    0x150(%rsp),%rbx
   361d5:	00 
   361d6:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   361dd:	00 
   361de:	ba e8 00 00 00       	mov    $0xe8,%edx
   361e3:	48 89 de             	mov    %rbx,%rsi
   361e6:	ff 15 74 11 0b 00    	call   *0xb1174(%rip)        # e7360 <memcpy@GLIBC_2.14>
   361ec:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   361f3:	00 
   361f4:	ba 08 00 00 00       	mov    $0x8,%edx
   361f9:	b9 e8 00 00 00       	mov    $0xe8,%ecx
   361fe:	48 89 de             	mov    %rbx,%rsi
   36201:	ff 15 71 08 0b 00    	call   *0xb0871(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   36207:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3620e:	00 
   3620f:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   36216:	00 
   36217:	ba e0 00 00 00       	mov    $0xe0,%edx
   3621c:	ff 15 3e 11 0b 00    	call   *0xb113e(%rip)        # e7360 <memcpy@GLIBC_2.14>
   36222:	0f b6 9c 24 20 04 00 	movzbl 0x420(%rsp),%ebx
   36229:	00 
   3622a:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   36231:	00 
   36232:	48 89 84 24 10 05 00 	mov    %rax,0x510(%rsp)
   36239:	00 
   3623a:	0f 10 84 24 20 02 00 	movups 0x220(%rsp),%xmm0
   36241:	00 
   36242:	0f 10 8c 24 30 02 00 	movups 0x230(%rsp),%xmm1
   36249:	00 
   3624a:	0f 10 94 24 40 02 00 	movups 0x240(%rsp),%xmm2
   36251:	00 
   36252:	0f 29 94 24 00 05 00 	movaps %xmm2,0x500(%rsp)
   36259:	00 
   3625a:	0f 29 8c 24 f0 04 00 	movaps %xmm1,0x4f0(%rsp)
   36261:	00 
   36262:	0f 29 84 24 e0 04 00 	movaps %xmm0,0x4e0(%rsp)
   36269:	00 
   3626a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
   36271:	00 
   36272:	48 89 84 24 d0 04 00 	mov    %rax,0x4d0(%rsp)
   36279:	00 
   3627a:	0f 10 84 24 78 02 00 	movups 0x278(%rsp),%xmm0
   36281:	00 
   36282:	0f 29 84 24 c0 04 00 	movaps %xmm0,0x4c0(%rsp)
   36289:	00 
   3628a:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   36291:	00 
   36292:	0f 29 84 24 b0 04 00 	movaps %xmm0,0x4b0(%rsp)
   36299:	00 
   3629a:	0f 10 84 24 58 02 00 	movups 0x258(%rsp),%xmm0
   362a1:	00 
   362a2:	0f 29 84 24 a0 04 00 	movaps %xmm0,0x4a0(%rsp)
   362a9:	00 
   362aa:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
   362b1:	00 
   362b2:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   362b9:	00 
   362ba:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   362c1:	00 
   362c2:	0f 10 8c 24 a0 02 00 	movups 0x2a0(%rsp),%xmm1
   362c9:	00 
   362ca:	0f 10 94 24 b0 02 00 	movups 0x2b0(%rsp),%xmm2
   362d1:	00 
   362d2:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   362d9:	00 
   362da:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   362e1:	00 
   362e2:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   362e9:	00 
   362ea:	48 8b 84 24 f8 02 00 	mov    0x2f8(%rsp),%rax
   362f1:	00 
   362f2:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   362f9:	00 
   362fa:	0f 10 84 24 c8 02 00 	movups 0x2c8(%rsp),%xmm0
   36301:	00 
   36302:	0f 10 8c 24 d8 02 00 	movups 0x2d8(%rsp),%xmm1
   36309:	00 
   3630a:	0f 10 94 24 e8 02 00 	movups 0x2e8(%rsp),%xmm2
   36311:	00 
   36312:	0f 29 94 24 00 02 00 	movaps %xmm2,0x200(%rsp)
   36319:	00 
   3631a:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   36321:	00 
   36322:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   36329:	00 
   3632a:	48 83 bc 24 78 04 00 	cmpq   $0x0,0x478(%rsp)
   36331:	00 00 
   36333:	0f 84 20 0e 00 00    	je     37159 <oriole_expat::dispatch+0x32d9>
   36339:	48 8b 84 24 10 05 00 	mov    0x510(%rsp),%rax
   36340:	00 
   36341:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   36348:	00 
   36349:	0f 28 84 24 e0 04 00 	movaps 0x4e0(%rsp),%xmm0
   36350:	00 
   36351:	0f 28 8c 24 f0 04 00 	movaps 0x4f0(%rsp),%xmm1
   36358:	00 
   36359:	0f 28 94 24 00 05 00 	movaps 0x500(%rsp),%xmm2
   36360:	00 
   36361:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   36368:	00 
   36369:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   36370:	00 
   36371:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   36378:	00 
   36379:	40 b5 01             	mov    $0x1,%bpl
   3637c:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   36383:	00 
   36384:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3638b:	00 
   3638c:	41 b7 01             	mov    $0x1,%r15b
   3638f:	41 b5 01             	mov    $0x1,%r13b
   36392:	ff 15 b0 07 0b 00    	call   *0xb07b0(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   36398:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   3639f:	00 
   363a0:	0f b6 8c 24 28 02 00 	movzbl 0x228(%rsp),%ecx
   363a7:	00 
   363a8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   363ac:	0f 84 16 18 00 00    	je     37bc8 <oriole_expat::dispatch+0x3d48>
   363b2:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   363b9:	00 
   363ba:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   363c1:	00 
   363c2:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   363c9:	00 
   363ca:	0f 11 94 24 08 01 00 	movups %xmm2,0x108(%rsp)
   363d1:	00 
   363d2:	0f 11 8c 24 f9 00 00 	movups %xmm1,0xf9(%rsp)
   363d9:	00 
   363da:	0f 11 84 24 e9 00 00 	movups %xmm0,0xe9(%rsp)
   363e1:	00 
   363e2:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
   363e9:	00 
   363ea:	88 8c 24 e8 00 00 00 	mov    %cl,0xe8(%rsp)
   363f1:	4c 8b a4 24 00 01 00 	mov    0x100(%rsp),%r12
   363f8:	00 
   363f9:	48 8b 84 24 d0 04 00 	mov    0x4d0(%rsp),%rax
   36400:	00 
   36401:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   36408:	00 
   36409:	0f 28 84 24 a0 04 00 	movaps 0x4a0(%rsp),%xmm0
   36410:	00 
   36411:	0f 28 8c 24 b0 04 00 	movaps 0x4b0(%rsp),%xmm1
   36418:	00 
   36419:	0f 28 94 24 c0 04 00 	movaps 0x4c0(%rsp),%xmm2
   36420:	00 
   36421:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   36428:	00 
   36429:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   36430:	00 
   36431:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   36438:	00 
   36439:	40 b5 01             	mov    $0x1,%bpl
   3643c:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   36443:	00 
   36444:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3644b:	00 
   3644c:	41 b7 01             	mov    $0x1,%r15b
   3644f:	ff 15 f3 06 0b 00    	call   *0xb06f3(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   36455:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   3645c:	00 
   3645d:	0f b6 8c 24 28 02 00 	movzbl 0x228(%rsp),%ecx
   36464:	00 
   36465:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   36469:	0f 84 3f 1d 00 00    	je     381ae <oriole_expat::dispatch+0x432e>
   3646f:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   36476:	00 
   36477:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   3647e:	00 
   3647f:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   36486:	00 
   36487:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   3648e:	00 
   3648f:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   36494:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   36499:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   3649e:	88 4c 24 68          	mov    %cl,0x68(%rsp)
   364a2:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
   364a9:	00 
   364aa:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
   364b1:	00 
   364b2:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   364b9:	00 
   364ba:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
   364c1:	00 
   364c2:	0f 28 8c 24 b0 01 00 	movaps 0x1b0(%rsp),%xmm1
   364c9:	00 
   364ca:	0f 28 94 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm2
   364d1:	00 
   364d2:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   364d9:	00 
   364da:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   364e1:	00 
   364e2:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   364e9:	00 
   364ea:	40 b5 01             	mov    $0x1,%bpl
   364ed:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   364f4:	00 
   364f5:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   364fc:	00 
   364fd:	ff 15 45 06 0b 00    	call   *0xb0645(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   36503:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   3650a:	00 
   3650b:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   36512:	00 00 
   36514:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   36518:	0f 84 68 22 00 00    	je     38786 <oriole_expat::dispatch+0x4906>
   3651e:	4c 89 ed             	mov    %r13,%rbp
   36521:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   36528:	00 
   36529:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   36530:	00 
   36531:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   36538:	00 
   36539:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   36540:	00 
   36541:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   36548:	00 
   36549:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   36550:	00 
   36551:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   36558:	00 
   36559:	44 88 bc 24 a8 00 00 	mov    %r15b,0xa8(%rsp)
   36560:	00 
   36561:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
   36568:	00 
   36569:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   36570:	00 
   36571:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
   36578:	00 
   36579:	e8 b2 c8 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   3657e:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   36585:	00 
   36586:	44 0f b6 bc 24 48 03 	movzbl 0x348(%rsp),%r15d
   3658d:	00 00 
   3658f:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   36593:	0f 85 0f 28 00 00    	jne    38da8 <oriole_expat::dispatch+0x4f28>
   36599:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   365a0:	00 
   365a1:	31 ed                	xor    %ebp,%ebp
   365a3:	48 85 c9             	test   %rcx,%rcx
   365a6:	0f 84 dd 21 00 00    	je     38789 <oriole_expat::dispatch+0x4909>
   365ac:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   365b3:	00 
   365b4:	ba 01 00 00 00       	mov    $0x1,%edx
   365b9:	4c 89 ee             	mov    %r13,%rsi
   365bc:	ff 15 b6 04 0b 00    	call   *0xb04b6(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   365c2:	e9 c2 21 00 00       	jmp    38789 <oriole_expat::dispatch+0x4909>
   365c7:	48 8d 8c 24 30 01 00 	lea    0x130(%rsp),%rcx
   365ce:	00 
   365cf:	48 8b 41 30          	mov    0x30(%rcx),%rax
   365d3:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   365da:	00 
   365db:	0f 10 01             	movups (%rcx),%xmm0
   365de:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   365e2:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   365e6:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   365ed:	00 
   365ee:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   365f3:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   365f8:	48 83 bc 24 98 05 00 	cmpq   $0x0,0x598(%rsp)
   365ff:	00 00 
   36601:	0f 84 c8 08 00 00    	je     36ecf <oriole_expat::dispatch+0x304f>
   36607:	0f b6 9c 24 68 01 00 	movzbl 0x168(%rsp),%ebx
   3660e:	00 
   3660f:	48 8b 41 30          	mov    0x30(%rcx),%rax
   36613:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   3661a:	00 
   3661b:	0f 10 01             	movups (%rcx),%xmm0
   3661e:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   36622:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   36626:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   3662d:	00 
   3662e:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   36635:	00 
   36636:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   3663d:	00 
   3663e:	b0 01                	mov    $0x1,%al
   36640:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36644:	45 31 ed             	xor    %r13d,%r13d
   36647:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3664e:	00 
   3664f:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   36656:	00 
   36657:	b0 01                	mov    $0x1,%al
   36659:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3665d:	b0 01                	mov    $0x1,%al
   3665f:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36663:	b0 01                	mov    $0x1,%al
   36665:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36669:	b0 01                	mov    $0x1,%al
   3666b:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3666f:	b0 01                	mov    $0x1,%al
   36671:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36675:	b0 01                	mov    $0x1,%al
   36677:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3667b:	b0 01                	mov    $0x1,%al
   3667d:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36681:	b0 01                	mov    $0x1,%al
   36683:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36687:	b0 01                	mov    $0x1,%al
   36689:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3668d:	b0 01                	mov    $0x1,%al
   3668f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36694:	b0 01                	mov    $0x1,%al
   36696:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3669a:	40 b5 01             	mov    $0x1,%bpl
   3669d:	41 b7 01             	mov    $0x1,%r15b
   366a0:	41 b4 01             	mov    $0x1,%r12b
   366a3:	ff 15 9f 04 0b 00    	call   *0xb049f(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   366a9:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   366b0:	00 
   366b1:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   366b8:	00 00 
   366ba:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   366be:	0f 84 5e 14 00 00    	je     37b22 <oriole_expat::dispatch+0x3ca2>
   366c4:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   366cb:	00 
   366cc:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   366d3:	00 
   366d4:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   366db:	00 
   366dc:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   366e3:	00 
   366e4:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   366eb:	00 
   366ec:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   366f3:	00 
   366f4:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   366fb:	00 
   366fc:	44 88 bc 24 a8 00 00 	mov    %r15b,0xa8(%rsp)
   36703:	00 
   36704:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   3670b:	00 
   3670c:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   36711:	89 da                	mov    %ebx,%edx
   36713:	ff 94 24 98 05 00 00 	call   *0x598(%rsp)
   3671a:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   36721:	00 
   36722:	48 85 c9             	test   %rcx,%rcx
   36725:	74 6a                	je     36791 <oriole_expat::dispatch+0x2911>
   36727:	45 31 ed             	xor    %r13d,%r13d
   3672a:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   36731:	00 
   36732:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   36739:	00 
   3673a:	ba 01 00 00 00       	mov    $0x1,%edx
   3673f:	b0 01                	mov    $0x1,%al
   36741:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36745:	b0 01                	mov    $0x1,%al
   36747:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3674b:	b0 01                	mov    $0x1,%al
   3674d:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36751:	b0 01                	mov    $0x1,%al
   36753:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36757:	b0 01                	mov    $0x1,%al
   36759:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3675d:	b0 01                	mov    $0x1,%al
   3675f:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36763:	b0 01                	mov    $0x1,%al
   36765:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36769:	b0 01                	mov    $0x1,%al
   3676b:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3676f:	b0 01                	mov    $0x1,%al
   36771:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36775:	b0 01                	mov    $0x1,%al
   36777:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3677c:	b0 01                	mov    $0x1,%al
   3677e:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36782:	40 b5 01             	mov    $0x1,%bpl
   36785:	41 b7 01             	mov    $0x1,%r15b
   36788:	41 b4 01             	mov    $0x1,%r12b
   3678b:	ff 15 e7 02 0b 00    	call   *0xb02e7(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   36791:	b3 01                	mov    $0x1,%bl
   36793:	e9 65 1a 00 00       	jmp    381fd <oriole_expat::dispatch+0x437d>
   36798:	49 8d be 20 0b 00 00 	lea    0xb20(%r14),%rdi
   3679f:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   367a6:	00 
   367a7:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   367ae:	00 
   367af:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   367b6:	00 
   367b7:	0f b6 8c 24 28 02 00 	movzbl 0x228(%rsp),%ecx
   367be:	00 
   367bf:	8b 94 24 29 02 00 00 	mov    0x229(%rsp),%edx
   367c6:	0f b7 b4 24 2d 02 00 	movzwl 0x22d(%rsp),%esi
   367cd:	00 
   367ce:	44 0f b6 84 24 2f 02 	movzbl 0x22f(%rsp),%r8d
   367d5:	00 00 
   367d7:	0f 10 84 24 30 02 00 	movups 0x230(%rsp),%xmm0
   367de:	00 
   367df:	0f 10 8c 24 40 02 00 	movups 0x240(%rsp),%xmm1
   367e6:	00 
   367e7:	0f 29 8c 24 60 03 00 	movaps %xmm1,0x360(%rsp)
   367ee:	00 
   367ef:	0f 29 84 24 50 03 00 	movaps %xmm0,0x350(%rsp)
   367f6:	00 
   367f7:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
   367fe:	00 
   367ff:	88 8c 24 48 03 00 00 	mov    %cl,0x348(%rsp)
   36806:	89 94 24 49 03 00 00 	mov    %edx,0x349(%rsp)
   3680d:	66 89 b4 24 4d 03 00 	mov    %si,0x34d(%rsp)
   36814:	00 
   36815:	44 88 84 24 4f 03 00 	mov    %r8b,0x34f(%rsp)
   3681c:	00 
   3681d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   36824:	00 
   36825:	e8 16 56 00 00       	call   3be40 <<oriole_storage::queue::Queue<oriole_storage::string::String>>::try_push_back>
   3682a:	41 89 c7             	mov    %eax,%r15d
   3682d:	3c ff                	cmp    $0xff,%al
   3682f:	0f 85 14 16 00 00    	jne    37e49 <oriole_expat::dispatch+0x3fc9>
   36835:	4c 89 f7             	mov    %r14,%rdi
   36838:	e8 33 c9 ff ff       	call   33170 <oriole_expat::drain_default_fragments>
   3683d:	e9 97 0d 00 00       	jmp    375d9 <oriole_expat::dispatch+0x3759>
   36842:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   36849:	00 
   3684a:	48 8b 94 24 d0 01 00 	mov    0x1d0(%rsp),%rdx
   36851:	00 
   36852:	41 0f 10 46 08       	movups 0x8(%r14),%xmm0
   36857:	41 0f 10 4e 18       	movups 0x18(%r14),%xmm1
   3685c:	0f 29 8c 24 30 02 00 	movaps %xmm1,0x230(%rsp)
   36863:	00 
   36864:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   3686b:	00 
   3686c:	b0 01                	mov    $0x1,%al
   3686e:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36872:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   36879:	00 
   3687a:	48 8d 8c 24 20 02 00 	lea    0x220(%rsp),%rcx
   36881:	00 
   36882:	b0 01                	mov    $0x1,%al
   36884:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36888:	b3 01                	mov    $0x1,%bl
   3688a:	41 b4 01             	mov    $0x1,%r12b
   3688d:	41 b7 01             	mov    $0x1,%r15b
   36890:	ff 15 aa 02 0b 00    	call   *0xb02aa(%rip)        # e6b40 <_GLOBAL_OFFSET_TABLE_+0x200>
   36896:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   3689d:	00 
   3689e:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   368a5:	00 
   368a6:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   368aa:	0f 84 5e 15 00 00    	je     37e0e <oriole_expat::dispatch+0x3f8e>
   368b0:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   368b7:	00 
   368b8:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   368bf:	00 
   368c0:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   368c7:	00 
   368c8:	0f 11 94 24 08 01 00 	movups %xmm2,0x108(%rsp)
   368cf:	00 
   368d0:	0f 11 8c 24 f9 00 00 	movups %xmm1,0xf9(%rsp)
   368d7:	00 
   368d8:	0f 11 84 24 e9 00 00 	movups %xmm0,0xe9(%rsp)
   368df:	00 
   368e0:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
   368e7:	00 
   368e8:	88 8c 24 e8 00 00 00 	mov    %cl,0xe8(%rsp)
   368ef:	48 8b 84 24 80 05 00 	mov    0x580(%rsp),%rax
   368f6:	00 
   368f7:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   368fe:	00 
   368ff:	0f 28 84 24 50 05 00 	movaps 0x550(%rsp),%xmm0
   36906:	00 
   36907:	0f 28 8c 24 60 05 00 	movaps 0x560(%rsp),%xmm1
   3690e:	00 
   3690f:	0f 28 94 24 70 05 00 	movaps 0x570(%rsp),%xmm2
   36916:	00 
   36917:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   3691e:	00 
   3691f:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   36926:	00 
   36927:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   3692e:	00 
   3692f:	b0 01                	mov    $0x1,%al
   36931:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36935:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3693c:	00 
   3693d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   36944:	00 
   36945:	b3 01                	mov    $0x1,%bl
   36947:	ff 15 fb 01 0b 00    	call   *0xb01fb(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   3694d:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   36954:	00 
   36955:	0f b6 8c 24 28 02 00 	movzbl 0x228(%rsp),%ecx
   3695c:	00 
   3695d:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   36961:	0f 84 47 1a 00 00    	je     383ae <oriole_expat::dispatch+0x452e>
   36967:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   3696e:	00 
   3696f:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   36976:	00 
   36977:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   3697e:	00 
   3697f:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   36986:	00 
   36987:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   3698c:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   36991:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   36996:	88 4c 24 68          	mov    %cl,0x68(%rsp)
   3699a:	83 bc 24 18 05 00 00 	cmpl   $0xffffffff,0x518(%rsp)
   369a1:	ff 
   369a2:	0f 84 f5 1b 00 00    	je     3859d <oriole_expat::dispatch+0x471d>
   369a8:	4c 8b a4 24 38 05 00 	mov    0x538(%rsp),%r12
   369af:	00 
   369b0:	e9 eb 1b 00 00       	jmp    385a0 <oriole_expat::dispatch+0x4720>
   369b5:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   369bc:	00 
   369bd:	48 85 c9             	test   %rcx,%rcx
   369c0:	0f 84 1e 18 00 00    	je     381e4 <oriole_expat::dispatch+0x4364>
   369c6:	b0 01                	mov    $0x1,%al
   369c8:	89 44 24 48          	mov    %eax,0x48(%rsp)
   369cc:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   369d3:	00 
   369d4:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   369db:	00 
   369dc:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   369e1:	ba 01 00 00 00       	mov    $0x1,%edx
   369e6:	b0 01                	mov    $0x1,%al
   369e8:	89 44 24 28          	mov    %eax,0x28(%rsp)
   369ec:	b0 01                	mov    $0x1,%al
   369ee:	89 44 24 30          	mov    %eax,0x30(%rsp)
   369f2:	b0 01                	mov    $0x1,%al
   369f4:	89 44 24 14          	mov    %eax,0x14(%rsp)
   369f8:	b0 01                	mov    $0x1,%al
   369fa:	89 44 24 10          	mov    %eax,0x10(%rsp)
   369fe:	b0 01                	mov    $0x1,%al
   36a00:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36a04:	b0 01                	mov    $0x1,%al
   36a06:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36a0a:	b0 01                	mov    $0x1,%al
   36a0c:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36a10:	b0 01                	mov    $0x1,%al
   36a12:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36a16:	b0 01                	mov    $0x1,%al
   36a18:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36a1d:	b0 01                	mov    $0x1,%al
   36a1f:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36a23:	40 b5 01             	mov    $0x1,%bpl
   36a26:	41 b7 01             	mov    $0x1,%r15b
   36a29:	41 b4 01             	mov    $0x1,%r12b
   36a2c:	41 b5 01             	mov    $0x1,%r13b
   36a2f:	ff 15 43 00 0b 00    	call   *0xb0043(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   36a35:	31 db                	xor    %ebx,%ebx
   36a37:	e9 aa 17 00 00       	jmp    381e6 <oriole_expat::dispatch+0x4366>
   36a3c:	31 db                	xor    %ebx,%ebx
   36a3e:	e9 9c 18 00 00       	jmp    382df <oriole_expat::dispatch+0x445f>
   36a43:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   36a4a:	00 
   36a4b:	48 85 c9             	test   %rcx,%rcx
   36a4e:	74 18                	je     36a68 <oriole_expat::dispatch+0x2be8>
   36a50:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   36a57:	00 
   36a58:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   36a5d:	ba 01 00 00 00       	mov    $0x1,%edx
   36a62:	ff 15 10 00 0b 00    	call   *0xb0010(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   36a68:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   36a6f:	00 
   36a70:	48 85 c9             	test   %rcx,%rcx
   36a73:	0f 84 cf 17 00 00    	je     38248 <oriole_expat::dispatch+0x43c8>
   36a79:	b0 01                	mov    $0x1,%al
   36a7b:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36a7f:	45 31 e4             	xor    %r12d,%r12d
   36a82:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   36a89:	00 
   36a8a:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36a91:	00 
   36a92:	ba 01 00 00 00       	mov    $0x1,%edx
   36a97:	b0 01                	mov    $0x1,%al
   36a99:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36a9d:	b0 01                	mov    $0x1,%al
   36a9f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36aa3:	b0 01                	mov    $0x1,%al
   36aa5:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36aa9:	b0 01                	mov    $0x1,%al
   36aab:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36aaf:	b0 01                	mov    $0x1,%al
   36ab1:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36ab5:	b0 01                	mov    $0x1,%al
   36ab7:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36abb:	b0 01                	mov    $0x1,%al
   36abd:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36ac1:	b0 01                	mov    $0x1,%al
   36ac3:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36ac7:	b0 01                	mov    $0x1,%al
   36ac9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36acd:	b0 01                	mov    $0x1,%al
   36acf:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36ad4:	b0 01                	mov    $0x1,%al
   36ad6:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36ada:	40 b5 01             	mov    $0x1,%bpl
   36add:	41 b7 01             	mov    $0x1,%r15b
   36ae0:	41 b5 01             	mov    $0x1,%r13b
   36ae3:	ff 15 8f ff 0a 00    	call   *0xaff8f(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   36ae9:	31 db                	xor    %ebx,%ebx
   36aeb:	e9 5a 17 00 00       	jmp    3824a <oriole_expat::dispatch+0x43ca>
   36af0:	31 c0                	xor    %eax,%eax
   36af2:	e9 a9 0b 00 00       	jmp    376a0 <oriole_expat::dispatch+0x3820>
   36af7:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   36afe:	00 
   36aff:	48 85 c9             	test   %rcx,%rcx
   36b02:	74 1b                	je     36b1f <oriole_expat::dispatch+0x2c9f>
   36b04:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   36b0b:	00 
   36b0c:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36b13:	00 
   36b14:	ba 01 00 00 00       	mov    $0x1,%edx
   36b19:	ff 15 59 ff 0a 00    	call   *0xaff59(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   36b1f:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   36b26:	00 
   36b27:	48 85 c9             	test   %rcx,%rcx
   36b2a:	0f 84 65 17 00 00    	je     38295 <oriole_expat::dispatch+0x4415>
   36b30:	b0 01                	mov    $0x1,%al
   36b32:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36b36:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   36b3d:	00 
   36b3e:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   36b45:	00 
   36b46:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   36b4d:	00 
   36b4e:	ba 01 00 00 00       	mov    $0x1,%edx
   36b53:	b0 01                	mov    $0x1,%al
   36b55:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36b59:	b0 01                	mov    $0x1,%al
   36b5b:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36b5f:	b0 01                	mov    $0x1,%al
   36b61:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36b65:	b0 01                	mov    $0x1,%al
   36b67:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36b6b:	b0 01                	mov    $0x1,%al
   36b6d:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36b71:	b0 01                	mov    $0x1,%al
   36b73:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36b77:	b0 01                	mov    $0x1,%al
   36b79:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36b7d:	b0 01                	mov    $0x1,%al
   36b7f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36b83:	b0 01                	mov    $0x1,%al
   36b85:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36b8a:	b0 01                	mov    $0x1,%al
   36b8c:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36b90:	40 b5 01             	mov    $0x1,%bpl
   36b93:	41 b7 01             	mov    $0x1,%r15b
   36b96:	41 b4 01             	mov    $0x1,%r12b
   36b99:	41 b5 01             	mov    $0x1,%r13b
   36b9c:	ff 15 d6 fe 0a 00    	call   *0xafed6(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   36ba2:	31 db                	xor    %ebx,%ebx
   36ba4:	e9 ee 16 00 00       	jmp    38297 <oriole_expat::dispatch+0x4417>
   36ba9:	b0 01                	mov    $0x1,%al
   36bab:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36baf:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   36bb6:	00 
   36bb7:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   36bbe:	00 
   36bbf:	b0 01                	mov    $0x1,%al
   36bc1:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36bc5:	b0 01                	mov    $0x1,%al
   36bc7:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36bcb:	b0 01                	mov    $0x1,%al
   36bcd:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36bd1:	b0 01                	mov    $0x1,%al
   36bd3:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36bd7:	b0 01                	mov    $0x1,%al
   36bd9:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36bdd:	b0 01                	mov    $0x1,%al
   36bdf:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36be3:	b0 01                	mov    $0x1,%al
   36be5:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36be9:	b0 01                	mov    $0x1,%al
   36beb:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36bef:	b0 01                	mov    $0x1,%al
   36bf1:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36bf6:	b0 01                	mov    $0x1,%al
   36bf8:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36bfc:	40 b5 01             	mov    $0x1,%bpl
   36bff:	41 b7 01             	mov    $0x1,%r15b
   36c02:	41 b4 01             	mov    $0x1,%r12b
   36c05:	41 b5 01             	mov    $0x1,%r13b
   36c08:	e8 d3 b6 ff ff       	call   322e0 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   36c0d:	b0 01                	mov    $0x1,%al
   36c0f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36c13:	b0 01                	mov    $0x1,%al
   36c15:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36c19:	b0 01                	mov    $0x1,%al
   36c1b:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36c1f:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   36c26:	00 
   36c27:	b0 01                	mov    $0x1,%al
   36c29:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36c2d:	b0 01                	mov    $0x1,%al
   36c2f:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36c33:	b0 01                	mov    $0x1,%al
   36c35:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36c39:	b0 01                	mov    $0x1,%al
   36c3b:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36c3f:	b0 01                	mov    $0x1,%al
   36c41:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36c45:	b0 01                	mov    $0x1,%al
   36c47:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36c4b:	b0 01                	mov    $0x1,%al
   36c4d:	89 44 24 20          	mov    %eax,0x20(%rsp)
   36c51:	b0 01                	mov    $0x1,%al
   36c53:	89 44 24 18          	mov    %eax,0x18(%rsp)
   36c57:	b0 01                	mov    $0x1,%al
   36c59:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   36c5d:	b2 01                	mov    $0x1,%dl
   36c5f:	e9 c1 eb ff ff       	jmp    35825 <oriole_expat::dispatch+0x19a5>
   36c64:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   36c69:	e8 22 87 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36c6e:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   36c75:	00 
   36c76:	48 85 c9             	test   %rcx,%rcx
   36c79:	0f 84 33 16 00 00    	je     382b2 <oriole_expat::dispatch+0x4432>
   36c7f:	b0 01                	mov    $0x1,%al
   36c81:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36c85:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   36c8c:	00 
   36c8d:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   36c94:	00 
   36c95:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36c9c:	00 
   36c9d:	ba 01 00 00 00       	mov    $0x1,%edx
   36ca2:	b0 01                	mov    $0x1,%al
   36ca4:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36ca8:	b0 01                	mov    $0x1,%al
   36caa:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36cae:	b0 01                	mov    $0x1,%al
   36cb0:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36cb4:	b0 01                	mov    $0x1,%al
   36cb6:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36cba:	b0 01                	mov    $0x1,%al
   36cbc:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36cc0:	b0 01                	mov    $0x1,%al
   36cc2:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36cc6:	b0 01                	mov    $0x1,%al
   36cc8:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36ccc:	b0 01                	mov    $0x1,%al
   36cce:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36cd2:	b0 01                	mov    $0x1,%al
   36cd4:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36cd9:	b0 01                	mov    $0x1,%al
   36cdb:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36cdf:	40 b5 01             	mov    $0x1,%bpl
   36ce2:	41 b7 01             	mov    $0x1,%r15b
   36ce5:	41 b4 01             	mov    $0x1,%r12b
   36ce8:	41 b5 01             	mov    $0x1,%r13b
   36ceb:	ff 15 87 fd 0a 00    	call   *0xafd87(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   36cf1:	31 db                	xor    %ebx,%ebx
   36cf3:	e9 15 17 00 00       	jmp    3840d <oriole_expat::dispatch+0x458d>
   36cf8:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   36cfd:	e8 8e 86 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36d02:	b0 01                	mov    $0x1,%al
   36d04:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36d08:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   36d0f:	00 
   36d10:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36d17:	00 
   36d18:	b0 01                	mov    $0x1,%al
   36d1a:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36d1e:	b0 01                	mov    $0x1,%al
   36d20:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36d24:	b0 01                	mov    $0x1,%al
   36d26:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36d2a:	b0 01                	mov    $0x1,%al
   36d2c:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36d30:	b0 01                	mov    $0x1,%al
   36d32:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36d36:	b0 01                	mov    $0x1,%al
   36d38:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36d3c:	b0 01                	mov    $0x1,%al
   36d3e:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36d42:	b0 01                	mov    $0x1,%al
   36d44:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36d48:	b0 01                	mov    $0x1,%al
   36d4a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36d4f:	b0 01                	mov    $0x1,%al
   36d51:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36d55:	40 b5 01             	mov    $0x1,%bpl
   36d58:	41 b7 01             	mov    $0x1,%r15b
   36d5b:	41 b4 01             	mov    $0x1,%r12b
   36d5e:	41 b5 01             	mov    $0x1,%r13b
   36d61:	e8 2a 86 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36d66:	e9 70 1b 00 00       	jmp    388db <oriole_expat::dispatch+0x4a5b>
   36d6b:	b0 01                	mov    $0x1,%al
   36d6d:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36d71:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   36d78:	00 00 
   36d7a:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   36d7f:	b0 01                	mov    $0x1,%al
   36d81:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36d85:	b0 01                	mov    $0x1,%al
   36d87:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36d8b:	b0 01                	mov    $0x1,%al
   36d8d:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36d91:	b0 01                	mov    $0x1,%al
   36d93:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36d97:	b0 01                	mov    $0x1,%al
   36d99:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36d9d:	b0 01                	mov    $0x1,%al
   36d9f:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36da3:	b0 01                	mov    $0x1,%al
   36da5:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36da9:	b0 01                	mov    $0x1,%al
   36dab:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36daf:	b0 01                	mov    $0x1,%al
   36db1:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36db5:	b0 01                	mov    $0x1,%al
   36db7:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36dbb:	40 b5 01             	mov    $0x1,%bpl
   36dbe:	41 b7 01             	mov    $0x1,%r15b
   36dc1:	41 b4 01             	mov    $0x1,%r12b
   36dc4:	41 b5 01             	mov    $0x1,%r13b
   36dc7:	e8 c4 85 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36dcc:	e9 71 11 00 00       	jmp    37f42 <oriole_expat::dispatch+0x40c2>
   36dd1:	41 0f b6 9e 60 0b 00 	movzbl 0xb60(%r14),%ebx
   36dd8:	00 
   36dd9:	41 c6 86 60 0b 00 00 	movb   $0x0,0xb60(%r14)
   36de0:	00 
   36de1:	e9 e2 e9 ff ff       	jmp    357c8 <oriole_expat::dispatch+0x1948>
   36de6:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   36ded:	00 
   36dee:	48 85 c9             	test   %rcx,%rcx
   36df1:	74 1b                	je     36e0e <oriole_expat::dispatch+0x2f8e>
   36df3:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   36dfa:	00 
   36dfb:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36e02:	00 
   36e03:	ba 01 00 00 00       	mov    $0x1,%edx
   36e08:	ff 15 6a fc 0a 00    	call   *0xafc6a(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   36e0e:	b0 01                	mov    $0x1,%al
   36e10:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36e14:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   36e1b:	00 
   36e1c:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   36e23:	00 
   36e24:	b0 01                	mov    $0x1,%al
   36e26:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36e2a:	b0 01                	mov    $0x1,%al
   36e2c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36e30:	b0 01                	mov    $0x1,%al
   36e32:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36e36:	b0 01                	mov    $0x1,%al
   36e38:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36e3c:	b0 01                	mov    $0x1,%al
   36e3e:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36e42:	b0 01                	mov    $0x1,%al
   36e44:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36e48:	b0 01                	mov    $0x1,%al
   36e4a:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36e4e:	b0 01                	mov    $0x1,%al
   36e50:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36e54:	b0 01                	mov    $0x1,%al
   36e56:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36e5b:	b0 01                	mov    $0x1,%al
   36e5d:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36e61:	40 b5 01             	mov    $0x1,%bpl
   36e64:	41 b7 01             	mov    $0x1,%r15b
   36e67:	41 b4 01             	mov    $0x1,%r12b
   36e6a:	41 b5 01             	mov    $0x1,%r13b
   36e6d:	e8 1e 85 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36e72:	e9 0d 12 00 00       	jmp    38084 <oriole_expat::dispatch+0x4204>
   36e77:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36e7b:	b0 01                	mov    $0x1,%al
   36e7d:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36e81:	b0 01                	mov    $0x1,%al
   36e83:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36e87:	b0 01                	mov    $0x1,%al
   36e89:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36e8d:	b0 01                	mov    $0x1,%al
   36e8f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36e93:	b0 01                	mov    $0x1,%al
   36e95:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36e99:	b0 01                	mov    $0x1,%al
   36e9b:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36e9f:	b0 01                	mov    $0x1,%al
   36ea1:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36ea5:	b0 01                	mov    $0x1,%al
   36ea7:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36eab:	b1 01                	mov    $0x1,%cl
   36ead:	40 b6 01             	mov    $0x1,%sil
   36eb0:	b0 01                	mov    $0x1,%al
   36eb2:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36eb6:	b0 01                	mov    $0x1,%al
   36eb8:	89 44 24 20          	mov    %eax,0x20(%rsp)
   36ebc:	b0 01                	mov    $0x1,%al
   36ebe:	89 44 24 18          	mov    %eax,0x18(%rsp)
   36ec2:	b0 01                	mov    $0x1,%al
   36ec4:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   36ec8:	b2 01                	mov    $0x1,%dl
   36eca:	e9 13 07 00 00       	jmp    375e2 <oriole_expat::dispatch+0x3762>
   36ecf:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   36ed6:	00 
   36ed7:	48 85 c9             	test   %rcx,%rcx
   36eda:	0f 84 1b 13 00 00    	je     381fb <oriole_expat::dispatch+0x437b>
   36ee0:	b0 01                	mov    $0x1,%al
   36ee2:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36ee6:	45 31 ed             	xor    %r13d,%r13d
   36ee9:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   36ef0:	00 
   36ef1:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   36ef6:	ba 01 00 00 00       	mov    $0x1,%edx
   36efb:	b0 01                	mov    $0x1,%al
   36efd:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36f01:	b0 01                	mov    $0x1,%al
   36f03:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36f07:	b0 01                	mov    $0x1,%al
   36f09:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36f0d:	b0 01                	mov    $0x1,%al
   36f0f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36f13:	b0 01                	mov    $0x1,%al
   36f15:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36f19:	b0 01                	mov    $0x1,%al
   36f1b:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36f1f:	b0 01                	mov    $0x1,%al
   36f21:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36f25:	b0 01                	mov    $0x1,%al
   36f27:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36f2b:	b0 01                	mov    $0x1,%al
   36f2d:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36f31:	b0 01                	mov    $0x1,%al
   36f33:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36f38:	b0 01                	mov    $0x1,%al
   36f3a:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36f3e:	40 b5 01             	mov    $0x1,%bpl
   36f41:	41 b7 01             	mov    $0x1,%r15b
   36f44:	41 b4 01             	mov    $0x1,%r12b
   36f47:	ff 15 2b fb 0a 00    	call   *0xafb2b(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   36f4d:	31 db                	xor    %ebx,%ebx
   36f4f:	e9 a9 12 00 00       	jmp    381fd <oriole_expat::dispatch+0x437d>
   36f54:	41 80 be 21 08 00 00 	cmpb   $0x1,0x821(%r14)
   36f5b:	01 
   36f5c:	75 08                	jne    36f66 <oriole_expat::dispatch+0x30e6>
   36f5e:	41 c6 86 21 08 00 00 	movb   $0x2,0x821(%r14)
   36f65:	02 
   36f66:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36f6d:	00 
   36f6e:	e8 1d 84 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36f73:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   36f7a:	00 
   36f7b:	e8 10 84 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36f80:	b0 01                	mov    $0x1,%al
   36f82:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36f86:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   36f8d:	00 
   36f8e:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   36f95:	00 
   36f96:	b0 01                	mov    $0x1,%al
   36f98:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36f9c:	b0 01                	mov    $0x1,%al
   36f9e:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36fa2:	b0 01                	mov    $0x1,%al
   36fa4:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36fa8:	b0 01                	mov    $0x1,%al
   36faa:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36fae:	b0 01                	mov    $0x1,%al
   36fb0:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36fb4:	b0 01                	mov    $0x1,%al
   36fb6:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36fba:	b0 01                	mov    $0x1,%al
   36fbc:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36fc0:	b0 01                	mov    $0x1,%al
   36fc2:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36fc6:	b0 01                	mov    $0x1,%al
   36fc8:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36fcd:	b0 01                	mov    $0x1,%al
   36fcf:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36fd3:	40 b5 01             	mov    $0x1,%bpl
   36fd6:	41 b7 01             	mov    $0x1,%r15b
   36fd9:	41 b4 01             	mov    $0x1,%r12b
   36fdc:	41 b5 01             	mov    $0x1,%r13b
   36fdf:	e8 ac 83 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36fe4:	31 db                	xor    %ebx,%ebx
   36fe6:	b0 01                	mov    $0x1,%al
   36fe8:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   36fef:	00 
   36ff0:	b1 01                	mov    $0x1,%cl
   36ff2:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   36ff6:	b1 01                	mov    $0x1,%cl
   36ff8:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   36ffc:	b1 01                	mov    $0x1,%cl
   36ffe:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   37002:	b1 01                	mov    $0x1,%cl
   37004:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   37008:	b1 01                	mov    $0x1,%cl
   3700a:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   3700e:	e9 db e7 ff ff       	jmp    357ee <oriole_expat::dispatch+0x196e>
   37013:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3701a:	00 
   3701b:	e8 70 83 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37020:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   37027:	00 
   37028:	e8 63 83 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3702d:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   37034:	00 
   37035:	48 85 c9             	test   %rcx,%rcx
   37038:	0f 84 7b 12 00 00    	je     382b9 <oriole_expat::dispatch+0x4439>
   3703e:	b0 01                	mov    $0x1,%al
   37040:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37044:	45 31 ff             	xor    %r15d,%r15d
   37047:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   3704e:	00 
   3704f:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   37056:	00 
   37057:	ba 01 00 00 00       	mov    $0x1,%edx
   3705c:	b0 01                	mov    $0x1,%al
   3705e:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37062:	b0 01                	mov    $0x1,%al
   37064:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37068:	b0 01                	mov    $0x1,%al
   3706a:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3706e:	b0 01                	mov    $0x1,%al
   37070:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37074:	b0 01                	mov    $0x1,%al
   37076:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3707a:	b0 01                	mov    $0x1,%al
   3707c:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37080:	b0 01                	mov    $0x1,%al
   37082:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37086:	b0 01                	mov    $0x1,%al
   37088:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3708c:	b0 01                	mov    $0x1,%al
   3708e:	89 44 24 24          	mov    %eax,0x24(%rsp)
   37092:	b0 01                	mov    $0x1,%al
   37094:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   37099:	b0 01                	mov    $0x1,%al
   3709b:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3709f:	40 b5 01             	mov    $0x1,%bpl
   370a2:	41 b4 01             	mov    $0x1,%r12b
   370a5:	41 b5 01             	mov    $0x1,%r13b
   370a8:	ff 15 ca f9 0a 00    	call   *0xaf9ca(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   370ae:	31 db                	xor    %ebx,%ebx
   370b0:	e9 1a 1f 00 00       	jmp    38fcf <oriole_expat::dispatch+0x514f>
   370b5:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   370bc:	00 
   370bd:	e8 ce 82 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   370c2:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   370c9:	00 
   370ca:	e8 c1 82 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   370cf:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   370d6:	00 
   370d7:	48 85 c9             	test   %rcx,%rcx
   370da:	0f 84 e0 11 00 00    	je     382c0 <oriole_expat::dispatch+0x4440>
   370e0:	b0 01                	mov    $0x1,%al
   370e2:	89 44 24 48          	mov    %eax,0x48(%rsp)
   370e6:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   370ed:	00 
   370ee:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   370f5:	00 
   370f6:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   370fd:	00 
   370fe:	ba 01 00 00 00       	mov    $0x1,%edx
   37103:	b0 01                	mov    $0x1,%al
   37105:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37109:	b0 01                	mov    $0x1,%al
   3710b:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3710f:	b0 01                	mov    $0x1,%al
   37111:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37115:	b0 01                	mov    $0x1,%al
   37117:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3711b:	b0 01                	mov    $0x1,%al
   3711d:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37121:	b0 01                	mov    $0x1,%al
   37123:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37127:	b0 01                	mov    $0x1,%al
   37129:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3712d:	b0 01                	mov    $0x1,%al
   3712f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   37133:	b0 01                	mov    $0x1,%al
   37135:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3713a:	b0 01                	mov    $0x1,%al
   3713c:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37140:	40 b5 01             	mov    $0x1,%bpl
   37143:	41 b7 01             	mov    $0x1,%r15b
   37146:	41 b4 01             	mov    $0x1,%r12b
   37149:	41 b5 01             	mov    $0x1,%r13b
   3714c:	ff 15 26 f9 0a 00    	call   *0xaf926(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   37152:	31 db                	xor    %ebx,%ebx
   37154:	e9 3f 21 00 00       	jmp    39298 <oriole_expat::dispatch+0x5418>
   37159:	41 b7 01             	mov    $0x1,%r15b
   3715c:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   37163:	00 
   37164:	41 b5 01             	mov    $0x1,%r13b
   37167:	e8 24 82 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3716c:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   37173:	00 
   37174:	48 85 c9             	test   %rcx,%rcx
   37177:	74 1e                	je     37197 <oriole_expat::dispatch+0x3317>
   37179:	41 b5 01             	mov    $0x1,%r13b
   3717c:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   37183:	00 
   37184:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   3718b:	00 
   3718c:	ba 01 00 00 00       	mov    $0x1,%edx
   37191:	ff 15 e1 f8 0a 00    	call   *0xaf8e1(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   37197:	48 8b 8c 24 c8 04 00 	mov    0x4c8(%rsp),%rcx
   3719e:	00 
   3719f:	48 85 c9             	test   %rcx,%rcx
   371a2:	74 1b                	je     371bf <oriole_expat::dispatch+0x333f>
   371a4:	48 8b b4 24 c0 04 00 	mov    0x4c0(%rsp),%rsi
   371ab:	00 
   371ac:	48 8d bc 24 a0 04 00 	lea    0x4a0(%rsp),%rdi
   371b3:	00 
   371b4:	ba 01 00 00 00       	mov    $0x1,%edx
   371b9:	ff 15 b9 f8 0a 00    	call   *0xaf8b9(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   371bf:	48 8b 8c 24 08 05 00 	mov    0x508(%rsp),%rcx
   371c6:	00 
   371c7:	48 85 c9             	test   %rcx,%rcx
   371ca:	0f 84 f7 10 00 00    	je     382c7 <oriole_expat::dispatch+0x4447>
   371d0:	b0 01                	mov    $0x1,%al
   371d2:	89 44 24 38          	mov    %eax,0x38(%rsp)
   371d6:	31 ed                	xor    %ebp,%ebp
   371d8:	48 8b b4 24 00 05 00 	mov    0x500(%rsp),%rsi
   371df:	00 
   371e0:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
   371e7:	00 
   371e8:	ba 01 00 00 00       	mov    $0x1,%edx
   371ed:	b0 01                	mov    $0x1,%al
   371ef:	89 44 24 28          	mov    %eax,0x28(%rsp)
   371f3:	b0 01                	mov    $0x1,%al
   371f5:	89 44 24 30          	mov    %eax,0x30(%rsp)
   371f9:	b0 01                	mov    $0x1,%al
   371fb:	89 44 24 48          	mov    %eax,0x48(%rsp)
   371ff:	b0 01                	mov    $0x1,%al
   37201:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37205:	b0 01                	mov    $0x1,%al
   37207:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3720b:	b0 01                	mov    $0x1,%al
   3720d:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37211:	b0 01                	mov    $0x1,%al
   37213:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37217:	b0 01                	mov    $0x1,%al
   37219:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3721d:	b0 01                	mov    $0x1,%al
   3721f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   37223:	b0 01                	mov    $0x1,%al
   37225:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3722a:	b0 01                	mov    $0x1,%al
   3722c:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37230:	41 b7 01             	mov    $0x1,%r15b
   37233:	41 b4 01             	mov    $0x1,%r12b
   37236:	41 b5 01             	mov    $0x1,%r13b
   37239:	ff 15 39 f8 0a 00    	call   *0xaf839(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3723f:	31 db                	xor    %ebx,%ebx
   37241:	e9 cf 21 00 00       	jmp    39415 <oriole_expat::dispatch+0x5595>
   37246:	48 39 0a             	cmp    %rcx,(%rdx)
   37249:	0f 94 c1             	sete   %cl
   3724c:	89 4c 24 58          	mov    %ecx,0x58(%rsp)
   37250:	0f b6 8c 24 26 01 00 	movzbl 0x126(%rsp),%ecx
   37257:	00 
   37258:	08 8c 24 68 04 00 00 	or     %cl,0x468(%rsp)
   3725f:	48 89 94 24 18 02 00 	mov    %rdx,0x218(%rsp)
   37266:	00 
   37267:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   3726c:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   37271:	0f b6 84 24 27 01 00 	movzbl 0x127(%rsp),%eax
   37278:	00 
   37279:	34 01                	xor    $0x1,%al
   3727b:	20 84 24 88 04 00 00 	and    %al,0x488(%rsp)
   37282:	4d 8d 6e 08          	lea    0x8(%r14),%r13
   37286:	48 8d ac 24 49 03 00 	lea    0x349(%rsp),%rbp
   3728d:	00 
   3728e:	48 8d 9c 24 59 06 00 	lea    0x659(%rsp),%rbx
   37295:	00 
   37296:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
   3729b:	4c 8d 25 2e 58 00 00 	lea    0x582e(%rip),%r12        # 3cad0 <<oriole_expat::DtdFragments as core::iter::traits::iterator::Iterator>::next>
   372a2:	4c 89 ff             	mov    %r15,%rdi
   372a5:	41 ff d4             	call   *%r12
   372a8:	48 85 c0             	test   %rax,%rax
   372ab:	0f 84 f8 02 00 00    	je     375a9 <oriole_expat::dispatch+0x3729>
   372b1:	80 bc 24 68 04 00 00 	cmpb   $0x0,0x468(%rsp)
   372b8:	00 
   372b9:	0f 84 94 00 00 00    	je     37353 <oriole_expat::dispatch+0x34d3>
   372bf:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
   372c4:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
   372c9:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   372d0:	00 
   372d1:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   372d8:	00 
   372d9:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   372e0:	00 
   372e1:	48 89 c6             	mov    %rax,%rsi
   372e4:	48 8d 8c 24 a0 00 00 	lea    0xa0(%rsp),%rcx
   372eb:	00 
   372ec:	ff 15 ae f7 0a 00    	call   *0xaf7ae(%rip)        # e6aa0 <_GLOBAL_OFFSET_TABLE_+0x160>
   372f2:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   372f9:	00 
   372fa:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   37301:	00 
   37302:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37306:	0f 84 0d 0b 00 00    	je     37e19 <oriole_expat::dispatch+0x3f99>
   3730c:	0f 10 45 00          	movups 0x0(%rbp),%xmm0
   37310:	0f 10 4d 10          	movups 0x10(%rbp),%xmm1
   37314:	0f 10 55 1f          	movups 0x1f(%rbp),%xmm2
   37318:	0f 11 53 1f          	movups %xmm2,0x1f(%rbx)
   3731c:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
   37320:	0f 11 03             	movups %xmm0,(%rbx)
   37323:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
   3732a:	00 
   3732b:	88 8c 24 58 06 00 00 	mov    %cl,0x658(%rsp)
   37332:	49 8d be 20 0b 00 00 	lea    0xb20(%r14),%rdi
   37339:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
   37340:	00 
   37341:	e8 fa 4a 00 00       	call   3be40 <<oriole_storage::queue::Queue<oriole_storage::string::String>>::try_push_back>
   37346:	3c ff                	cmp    $0xff,%al
   37348:	0f 84 54 ff ff ff    	je     372a2 <oriole_expat::dispatch+0x3422>
   3734e:	e9 cb 0a 00 00       	jmp    37e1e <oriole_expat::dispatch+0x3f9e>
   37353:	48 85 d2             	test   %rdx,%rdx
   37356:	0f 84 46 ff ff ff    	je     372a2 <oriole_expat::dispatch+0x3422>
   3735c:	48 8d 0c 10          	lea    (%rax,%rdx,1),%rcx
   37360:	48 89 c6             	mov    %rax,%rsi
   37363:	eb 34                	jmp    37399 <oriole_expat::dispatch+0x3519>
   37365:	40 0f b6 ff          	movzbl %dil,%edi
   37369:	4c 8d 05 a6 cf fd ff 	lea    -0x2305a(%rip),%r8        # 14316 <core::unicode::unicode_data::white_space::WHITESPACE_MAP>
   37370:	41 0f b6 3c 38       	movzbl (%r8,%rdi,1),%edi
   37375:	40 d0 ef             	shr    $1,%dil
   37378:	40 f6 c7 01          	test   $0x1,%dil
   3737c:	0f 84 4a 01 00 00    	je     374cc <oriole_expat::dispatch+0x364c>
   37382:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   37389:	1f 84 00 00 00 00 00 
   37390:	48 39 ce             	cmp    %rcx,%rsi
   37393:	0f 84 09 ff ff ff    	je     372a2 <oriole_expat::dispatch+0x3422>
   37399:	0f b6 3e             	movzbl (%rsi),%edi
   3739c:	40 84 ff             	test   %dil,%dil
   3739f:	78 1f                	js     373c0 <oriole_expat::dispatch+0x3540>
   373a1:	48 ff c6             	inc    %rsi
   373a4:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   373a8:	41 83 f8 05          	cmp    $0x5,%r8d
   373ac:	72 e2                	jb     37390 <oriole_expat::dispatch+0x3510>
   373ae:	e9 ad 00 00 00       	jmp    37460 <oriole_expat::dispatch+0x35e0>
   373b3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   373ba:	84 00 00 00 00 00 
   373c0:	41 89 f8             	mov    %edi,%r8d
   373c3:	41 83 e0 1f          	and    $0x1f,%r8d
   373c7:	44 0f b6 56 01       	movzbl 0x1(%rsi),%r10d
   373cc:	41 83 e2 3f          	and    $0x3f,%r10d
   373d0:	40 80 ff df          	cmp    $0xdf,%dil
   373d4:	76 43                	jbe    37419 <oriole_expat::dispatch+0x3599>
   373d6:	44 0f b6 4e 02       	movzbl 0x2(%rsi),%r9d
   373db:	41 c1 e2 06          	shl    $0x6,%r10d
   373df:	41 83 e1 3f          	and    $0x3f,%r9d
   373e3:	45 09 d1             	or     %r10d,%r9d
   373e6:	40 80 ff f0          	cmp    $0xf0,%dil
   373ea:	72 4b                	jb     37437 <oriole_expat::dispatch+0x35b7>
   373ec:	0f b6 7e 03          	movzbl 0x3(%rsi),%edi
   373f0:	48 83 c6 04          	add    $0x4,%rsi
   373f4:	41 83 e0 07          	and    $0x7,%r8d
   373f8:	41 c1 e0 12          	shl    $0x12,%r8d
   373fc:	41 c1 e1 06          	shl    $0x6,%r9d
   37400:	83 e7 3f             	and    $0x3f,%edi
   37403:	44 09 cf             	or     %r9d,%edi
   37406:	44 09 c7             	or     %r8d,%edi
   37409:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   3740d:	41 83 f8 05          	cmp    $0x5,%r8d
   37411:	0f 82 79 ff ff ff    	jb     37390 <oriole_expat::dispatch+0x3510>
   37417:	eb 47                	jmp    37460 <oriole_expat::dispatch+0x35e0>
   37419:	48 83 c6 02          	add    $0x2,%rsi
   3741d:	41 c1 e0 06          	shl    $0x6,%r8d
   37421:	45 09 d0             	or     %r10d,%r8d
   37424:	44 89 c7             	mov    %r8d,%edi
   37427:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   3742b:	41 83 f8 05          	cmp    $0x5,%r8d
   3742f:	0f 82 5b ff ff ff    	jb     37390 <oriole_expat::dispatch+0x3510>
   37435:	eb 29                	jmp    37460 <oriole_expat::dispatch+0x35e0>
   37437:	48 83 c6 03          	add    $0x3,%rsi
   3743b:	41 c1 e0 0c          	shl    $0xc,%r8d
   3743f:	45 09 c1             	or     %r8d,%r9d
   37442:	44 89 cf             	mov    %r9d,%edi
   37445:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   37449:	41 83 f8 05          	cmp    $0x5,%r8d
   3744d:	0f 82 3d ff ff ff    	jb     37390 <oriole_expat::dispatch+0x3510>
   37453:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   3745a:	84 00 00 00 00 00 
   37460:	83 ff 20             	cmp    $0x20,%edi
   37463:	0f 84 27 ff ff ff    	je     37390 <oriole_expat::dispatch+0x3510>
   37469:	81 ff 85 00 00 00    	cmp    $0x85,%edi
   3746f:	72 5b                	jb     374cc <oriole_expat::dispatch+0x364c>
   37471:	41 89 f8             	mov    %edi,%r8d
   37474:	41 c1 e8 08          	shr    $0x8,%r8d
   37478:	41 83 f8 1f          	cmp    $0x1f,%r8d
   3747c:	7f 1a                	jg     37498 <oriole_expat::dispatch+0x3618>
   3747e:	45 85 c0             	test   %r8d,%r8d
   37481:	74 34                	je     374b7 <oriole_expat::dispatch+0x3637>
   37483:	41 83 f8 16          	cmp    $0x16,%r8d
   37487:	75 43                	jne    374cc <oriole_expat::dispatch+0x364c>
   37489:	81 ff 80 16 00 00    	cmp    $0x1680,%edi
   3748f:	40 0f 94 c7          	sete   %dil
   37493:	e9 e0 fe ff ff       	jmp    37378 <oriole_expat::dispatch+0x34f8>
   37498:	41 83 f8 20          	cmp    $0x20,%r8d
   3749c:	0f 84 c3 fe ff ff    	je     37365 <oriole_expat::dispatch+0x34e5>
   374a2:	41 83 f8 30          	cmp    $0x30,%r8d
   374a6:	75 24                	jne    374cc <oriole_expat::dispatch+0x364c>
   374a8:	81 ff 00 30 00 00    	cmp    $0x3000,%edi
   374ae:	40 0f 94 c7          	sete   %dil
   374b2:	e9 c1 fe ff ff       	jmp    37378 <oriole_expat::dispatch+0x34f8>
   374b7:	40 0f b6 ff          	movzbl %dil,%edi
   374bb:	4c 8d 05 54 ce fd ff 	lea    -0x231ac(%rip),%r8        # 14316 <core::unicode::unicode_data::white_space::WHITESPACE_MAP>
   374c2:	41 0f b6 3c 38       	movzbl (%r8,%rdi,1),%edi
   374c7:	e9 ac fe ff ff       	jmp    37378 <oriole_expat::dispatch+0x34f8>
   374cc:	48 83 fa 01          	cmp    $0x1,%rdx
   374d0:	74 1a                	je     374ec <oriole_expat::dispatch+0x366c>
   374d2:	48 83 fa 08          	cmp    $0x8,%rdx
   374d6:	75 1d                	jne    374f5 <oriole_expat::dispatch+0x3675>
   374d8:	48 b9 3c 21 45 4e 54 	movabs $0x595449544e45213c,%rcx
   374df:	49 54 59 
   374e2:	48 39 08             	cmp    %rcx,(%rax)
   374e5:	75 0e                	jne    374f5 <oriole_expat::dispatch+0x3675>
   374e7:	e9 b6 fd ff ff       	jmp    372a2 <oriole_expat::dispatch+0x3422>
   374ec:	80 38 25             	cmpb   $0x25,(%rax)
   374ef:	0f 84 ad fd ff ff    	je     372a2 <oriole_expat::dispatch+0x3422>
   374f5:	f6 44 24 58 01       	testb  $0x1,0x58(%rsp)
   374fa:	74 0d                	je     37509 <oriole_expat::dispatch+0x3689>
   374fc:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   37503:	00 
   37504:	e9 b6 fd ff ff       	jmp    372bf <oriole_expat::dispatch+0x343f>
   37509:	48 83 fa 01          	cmp    $0x1,%rdx
   3750d:	74 77                	je     37586 <oriole_expat::dispatch+0x3706>
   3750f:	48 83 fa 06          	cmp    $0x6,%rdx
   37513:	74 26                	je     3753b <oriole_expat::dispatch+0x36bb>
   37515:	48 83 fa 05          	cmp    $0x5,%rdx
   37519:	75 e1                	jne    374fc <oriole_expat::dispatch+0x367c>
   3751b:	8b 08                	mov    (%rax),%ecx
   3751d:	be 4e 44 41 54       	mov    $0x5441444e,%esi
   37522:	31 f1                	xor    %esi,%ecx
   37524:	0f b6 70 04          	movzbl 0x4(%rax),%esi
   37528:	83 f6 41             	xor    $0x41,%esi
   3752b:	40 b7 01             	mov    $0x1,%dil
   3752e:	89 7c 24 58          	mov    %edi,0x58(%rsp)
   37532:	09 ce                	or     %ecx,%esi
   37534:	75 c6                	jne    374fc <oriole_expat::dispatch+0x367c>
   37536:	e9 67 fd ff ff       	jmp    372a2 <oriole_expat::dispatch+0x3422>
   3753b:	8b 08                	mov    (%rax),%ecx
   3753d:	be 53 59 53 54       	mov    $0x54535953,%esi
   37542:	31 f1                	xor    %esi,%ecx
   37544:	0f b7 70 04          	movzwl 0x4(%rax),%esi
   37548:	81 f6 45 4d 00 00    	xor    $0x4d45,%esi
   3754e:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   37555:	00 
   37556:	09 ce                	or     %ecx,%esi
   37558:	0f 84 44 fd ff ff    	je     372a2 <oriole_expat::dispatch+0x3422>
   3755e:	8b 08                	mov    (%rax),%ecx
   37560:	be 50 55 42 4c       	mov    $0x4c425550,%esi
   37565:	31 f1                	xor    %esi,%ecx
   37567:	0f b7 70 04          	movzwl 0x4(%rax),%esi
   3756b:	81 f6 49 43 00 00    	xor    $0x4349,%esi
   37571:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   37578:	00 
   37579:	09 ce                	or     %ecx,%esi
   3757b:	0f 85 3e fd ff ff    	jne    372bf <oriole_expat::dispatch+0x343f>
   37581:	e9 1c fd ff ff       	jmp    372a2 <oriole_expat::dispatch+0x3422>
   37586:	80 38 3e             	cmpb   $0x3e,(%rax)
   37589:	0f 95 c1             	setne  %cl
   3758c:	0a 8c 24 88 04 00 00 	or     0x488(%rsp),%cl
   37593:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   3759a:	00 
   3759b:	f6 c1 01             	test   $0x1,%cl
   3759e:	0f 84 fe fc ff ff    	je     372a2 <oriole_expat::dispatch+0x3422>
   375a4:	e9 16 fd ff ff       	jmp    372bf <oriole_expat::dispatch+0x343f>
   375a9:	4c 89 f7             	mov    %r14,%rdi
   375ac:	e8 bf bb ff ff       	call   33170 <oriole_expat::drain_default_fragments>
   375b1:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   375b8:	00 
   375b9:	48 85 c9             	test   %rcx,%rcx
   375bc:	48 8b b4 24 18 02 00 	mov    0x218(%rsp),%rsi
   375c3:	00 
   375c4:	74 13                	je     375d9 <oriole_expat::dispatch+0x3759>
   375c6:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   375cd:	00 
   375ce:	ba 01 00 00 00       	mov    $0x1,%edx
   375d3:	ff 15 9f f4 0a 00    	call   *0xaf49f(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   375d9:	b1 01                	mov    $0x1,%cl
   375db:	40 b6 01             	mov    $0x1,%sil
   375de:	8b 54 24 2c          	mov    0x2c(%rsp),%edx
   375e2:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
   375e7:	89 54 24 2c          	mov    %edx,0x2c(%rsp)
   375eb:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   375ef:	83 bc 24 18 05 00 00 	cmpl   $0xffffffff,0x518(%rsp)
   375f6:	ff 
   375f7:	74 28                	je     37621 <oriole_expat::dispatch+0x37a1>
   375f9:	48 8b 8c 24 40 05 00 	mov    0x540(%rsp),%rcx
   37600:	00 
   37601:	48 85 c9             	test   %rcx,%rcx
   37604:	74 1b                	je     37621 <oriole_expat::dispatch+0x37a1>
   37606:	48 8b b4 24 38 05 00 	mov    0x538(%rsp),%rsi
   3760d:	00 
   3760e:	48 8d bc 24 18 05 00 	lea    0x518(%rsp),%rdi
   37615:	00 
   37616:	ba 01 00 00 00       	mov    $0x1,%edx
   3761b:	ff 15 57 f4 0a 00    	call   *0xaf457(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   37621:	41 b7 ff             	mov    $0xff,%r15b
   37624:	e9 13 17 00 00       	jmp    38d3c <oriole_expat::dispatch+0x4ebc>
   37629:	4c 89 fe             	mov    %r15,%rsi
   3762c:	48 83 e6 fc          	and    $0xfffffffffffffffc,%rsi
   37630:	49 8d bd d8 01 00 00 	lea    0x1d8(%r13),%rdi
   37637:	31 d2                	xor    %edx,%edx
   37639:	31 c0                	xor    %eax,%eax
   3763b:	44 0f b6 87 98 fe ff 	movzbl -0x168(%rdi),%r8d
   37642:	ff 
   37643:	49 01 c0             	add    %rax,%r8
   37646:	0f b6 87 10 ff ff ff 	movzbl -0xf0(%rdi),%eax
   3764d:	44 0f b6 4f 88       	movzbl -0x78(%rdi),%r9d
   37652:	49 01 c1             	add    %rax,%r9
   37655:	4d 01 c1             	add    %r8,%r9
   37658:	0f b6 07             	movzbl (%rdi),%eax
   3765b:	4c 01 c8             	add    %r9,%rax
   3765e:	48 83 c2 04          	add    $0x4,%rdx
   37662:	48 81 c7 e0 01 00 00 	add    $0x1e0,%rdi
   37669:	48 39 d6             	cmp    %rdx,%rsi
   3766c:	75 cd                	jne    3763b <oriole_expat::dispatch+0x37bb>
   3766e:	48 85 c9             	test   %rcx,%rcx
   37671:	74 2d                	je     376a0 <oriole_expat::dispatch+0x3820>
   37673:	48 6b d2 78          	imul   $0x78,%rdx,%rdx
   37677:	4c 01 ea             	add    %r13,%rdx
   3767a:	48 83 c2 70          	add    $0x70,%rdx
   3767e:	48 6b c9 78          	imul   $0x78,%rcx,%rcx
   37682:	31 f6                	xor    %esi,%esi
   37684:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   3768b:	00 00 00 00 00 
   37690:	0f b6 3c 32          	movzbl (%rdx,%rsi,1),%edi
   37694:	48 01 f8             	add    %rdi,%rax
   37697:	48 83 c6 78          	add    $0x78,%rsi
   3769b:	48 39 f1             	cmp    %rsi,%rcx
   3769e:	75 f0                	jne    37690 <oriole_expat::dispatch+0x3810>
   376a0:	48 01 c0             	add    %rax,%rax
   376a3:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
   376a9:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
   376ae:	48 0f 42 c8          	cmovb  %rax,%rcx
   376b2:	41 89 8e 40 0a 00 00 	mov    %ecx,0xa40(%r14)
   376b9:	48 83 bc 24 60 04 00 	cmpq   $0x0,0x460(%rsp)
   376c0:	00 00 
   376c2:	0f 84 f7 00 00 00    	je     377bf <oriole_expat::dispatch+0x393f>
   376c8:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   376cf:	00 
   376d0:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   376d7:	00 
   376d8:	31 ff                	xor    %edi,%edi
   376da:	e8 b1 53 00 00       	call   3ca90 <core::slice::memchr::memchr>
   376df:	b3 03                	mov    $0x3,%bl
   376e1:	48 83 f8 01          	cmp    $0x1,%rax
   376e5:	0f 84 22 21 00 00    	je     3980d <oriole_expat::dispatch+0x598d>
   376eb:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   376f0:	31 f6                	xor    %esi,%esi
   376f2:	ff 15 d0 f3 0a 00    	call   *0xaf3d0(%rip)        # e6ac8 <_GLOBAL_OFFSET_TABLE_+0x188>
   376f8:	89 c3                	mov    %eax,%ebx
   376fa:	3c ff                	cmp    $0xff,%al
   376fc:	0f 85 0b 21 00 00    	jne    3980d <oriole_expat::dispatch+0x598d>
   37702:	41 0f 10 46 08       	movups 0x8(%r14),%xmm0
   37707:	41 0f 10 4e 18       	movups 0x18(%r14),%xmm1
   3770c:	0f 29 8c 24 30 02 00 	movaps %xmm1,0x230(%rsp)
   37713:	00 
   37714:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   3771b:	00 
   3771c:	0f 57 c0             	xorps  %xmm0,%xmm0
   3771f:	0f 29 84 24 b0 03 00 	movaps %xmm0,0x3b0(%rsp)
   37726:	00 
   37727:	0f 29 84 24 a0 03 00 	movaps %xmm0,0x3a0(%rsp)
   3772e:	00 
   3772f:	0f 29 84 24 90 03 00 	movaps %xmm0,0x390(%rsp)
   37736:	00 
   37737:	0f 29 84 24 80 03 00 	movaps %xmm0,0x380(%rsp)
   3773e:	00 
   3773f:	0f 29 84 24 70 03 00 	movaps %xmm0,0x370(%rsp)
   37746:	00 
   37747:	0f 29 84 24 60 03 00 	movaps %xmm0,0x360(%rsp)
   3774e:	00 
   3774f:	0f 29 84 24 50 03 00 	movaps %xmm0,0x350(%rsp)
   37756:	00 
   37757:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   3775e:	00 
   3775f:	48 c7 84 24 c0 03 00 	movq   $0x0,0x3c0(%rsp)
   37766:	00 00 00 00 00 
   3776b:	48 c7 84 24 40 02 00 	movq   $0x8,0x240(%rsp)
   37772:	00 08 00 00 00 
   37777:	0f 11 84 24 48 02 00 	movups %xmm0,0x248(%rsp)
   3777e:	00 
   3777f:	4b 8d 1c 3f          	lea    (%r15,%r15,1),%rbx
   37783:	4a 8d 04 7d 01 00 00 	lea    0x1(,%r15,2),%rax
   3778a:	00 
   3778b:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   37790:	48 83 fb 12          	cmp    $0x12,%rbx
   37794:	0f 83 6d 16 00 00    	jae    38e07 <oriole_expat::dispatch+0x4f87>
   3779a:	48 8d 84 24 40 03 00 	lea    0x340(%rsp),%rax
   377a1:	00 
   377a2:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   377a7:	b8 08 00 00 00       	mov    $0x8,%eax
   377ac:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   377b1:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   377b8:	00 00 
   377ba:	e9 f2 16 00 00       	jmp    38eb1 <oriole_expat::dispatch+0x5031>
   377bf:	31 db                	xor    %ebx,%ebx
   377c1:	49 8d 7e 30          	lea    0x30(%r14),%rdi
   377c5:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   377cc:	00 
   377cd:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
   377d4:	00 
   377d5:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
   377da:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
   377df:	0f 28 94 24 80 00 00 	movaps 0x80(%rsp),%xmm2
   377e6:	00 
   377e7:	0f 29 94 24 40 02 00 	movaps %xmm2,0x240(%rsp)
   377ee:	00 
   377ef:	0f 29 8c 24 30 02 00 	movaps %xmm1,0x230(%rsp)
   377f6:	00 
   377f7:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   377fe:	00 
   377ff:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   37806:	00 
   37807:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   3780e:	00 
   3780f:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
   37816:	00 
   37817:	0f 28 8c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm1
   3781e:	00 
   3781f:	0f 28 94 24 c0 00 00 	movaps 0xc0(%rsp),%xmm2
   37826:	00 
   37827:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   3782e:	00 
   3782f:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   37836:	00 
   37837:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   3783e:	00 
   3783f:	48 8d 94 24 20 02 00 	lea    0x220(%rsp),%rdx
   37846:	00 
   37847:	48 8d 8c 24 40 03 00 	lea    0x340(%rsp),%rcx
   3784e:	00 
   3784f:	48 8b b4 24 90 05 00 	mov    0x590(%rsp),%rsi
   37856:	00 
   37857:	ff 15 cb f1 0a 00    	call   *0xaf1cb(%rip)        # e6a28 <_GLOBAL_OFFSET_TABLE_+0xe8>
   3785d:	b0 01                	mov    $0x1,%al
   3785f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37863:	31 c0                	xor    %eax,%eax
   37865:	e9 37 0a 00 00       	jmp    382a1 <oriole_expat::dispatch+0x4421>
   3786a:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   37871:	00 
   37872:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   37879:	00 
   3787a:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   37881:	00 
   37882:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   37889:	00 
   3788a:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   37891:	00 
   37892:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   37899:	00 
   3789a:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   378a1:	00 
   378a2:	44 88 bc 24 a8 00 00 	mov    %r15b,0xa8(%rsp)
   378a9:	00 
   378aa:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   378ae:	0f 84 a7 05 00 00    	je     37e5b <oriole_expat::dispatch+0x3fdb>
   378b4:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
   378bb:	00 
   378bc:	e9 9d 05 00 00       	jmp    37e5e <oriole_expat::dispatch+0x3fde>
   378c1:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   378c8:	00 
   378c9:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   378d0:	00 
   378d1:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   378d8:	00 
   378d9:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   378e0:	00 
   378e1:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   378e8:	00 
   378e9:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   378f0:	00 
   378f1:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   378f8:	00 
   378f9:	44 88 bc 24 a8 00 00 	mov    %r15b,0xa8(%rsp)
   37900:	00 
   37901:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37905:	0f 84 d0 05 00 00    	je     37edb <oriole_expat::dispatch+0x405b>
   3790b:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   37912:	00 
   37913:	e9 c5 05 00 00       	jmp    37edd <oriole_expat::dispatch+0x405d>
   37918:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   3791f:	00 
   37920:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   37927:	00 
   37928:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   3792f:	00 
   37930:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   37937:	00 
   37938:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   3793d:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   37942:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   37947:	44 88 7c 24 68       	mov    %r15b,0x68(%rsp)
   3794c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37950:	0f 84 2b 06 00 00    	je     37f81 <oriole_expat::dispatch+0x4101>
   37956:	48 8b 9c 24 80 00 00 	mov    0x80(%rsp),%rbx
   3795d:	00 
   3795e:	e9 20 06 00 00       	jmp    37f83 <oriole_expat::dispatch+0x4103>
   37963:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   3796a:	00 
   3796b:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   37972:	00 
   37973:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   3797a:	00 
   3797b:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   37982:	00 
   37983:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   37988:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   3798d:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   37992:	44 88 7c 24 68       	mov    %r15b,0x68(%rsp)
   37997:	31 db                	xor    %ebx,%ebx
   37999:	41 bc 00 00 00 00    	mov    $0x0,%r12d
   3799f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   379a3:	74 08                	je     379ad <oriole_expat::dispatch+0x3b2d>
   379a5:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
   379ac:	00 
   379ad:	83 bc 24 18 05 00 00 	cmpl   $0xffffffff,0x518(%rsp)
   379b4:	ff 
   379b5:	74 08                	je     379bf <oriole_expat::dispatch+0x3b3f>
   379b7:	48 8b 9c 24 38 05 00 	mov    0x538(%rsp),%rbx
   379be:	00 
   379bf:	40 b5 01             	mov    $0x1,%bpl
   379c2:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   379c9:	00 
   379ca:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
   379d1:	00 
   379d2:	e8 59 b4 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   379d7:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   379de:	00 
   379df:	44 0f b6 bc 24 48 03 	movzbl 0x348(%rsp),%r15d
   379e6:	00 00 
   379e8:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   379ec:	0f 85 14 07 00 00    	jne    38106 <oriole_expat::dispatch+0x4286>
   379f2:	31 db                	xor    %ebx,%ebx
   379f4:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   379f9:	e8 92 79 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   379fe:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   37a05:	00 
   37a06:	e8 85 79 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37a0b:	e9 53 0f 00 00       	jmp    38963 <oriole_expat::dispatch+0x4ae3>
   37a10:	b0 01                	mov    $0x1,%al
   37a12:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37a16:	b0 01                	mov    $0x1,%al
   37a18:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37a1c:	b0 01                	mov    $0x1,%al
   37a1e:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37a22:	b0 01                	mov    $0x1,%al
   37a24:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37a28:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   37a2f:	00 
   37a30:	e9 68 07 00 00       	jmp    3819d <oriole_expat::dispatch+0x431d>
   37a35:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   37a3c:	00 
   37a3d:	48 85 c9             	test   %rcx,%rcx
   37a40:	74 18                	je     37a5a <oriole_expat::dispatch+0x3bda>
   37a42:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   37a49:	00 
   37a4a:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   37a4f:	ba 01 00 00 00       	mov    $0x1,%edx
   37a54:	ff 15 1e f0 0a 00    	call   *0xaf01e(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   37a5a:	b0 01                	mov    $0x1,%al
   37a5c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37a60:	c7 44 24 1c 00 00 00 	movl   $0x0,0x1c(%rsp)
   37a67:	00 
   37a68:	b0 01                	mov    $0x1,%al
   37a6a:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37a6e:	b0 01                	mov    $0x1,%al
   37a70:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37a74:	b0 01                	mov    $0x1,%al
   37a76:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37a7a:	b0 01                	mov    $0x1,%al
   37a7c:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37a80:	b0 01                	mov    $0x1,%al
   37a82:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37a86:	b0 01                	mov    $0x1,%al
   37a88:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37a8c:	b0 01                	mov    $0x1,%al
   37a8e:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37a92:	b0 01                	mov    $0x1,%al
   37a94:	89 44 24 04          	mov    %eax,0x4(%rsp)
   37a98:	b0 01                	mov    $0x1,%al
   37a9a:	89 44 24 24          	mov    %eax,0x24(%rsp)
   37a9e:	b0 01                	mov    $0x1,%al
   37aa0:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   37aa5:	b0 01                	mov    $0x1,%al
   37aa7:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37aab:	b0 01                	mov    $0x1,%al
   37aad:	89 44 24 20          	mov    %eax,0x20(%rsp)
   37ab1:	b0 01                	mov    $0x1,%al
   37ab3:	89 44 24 18          	mov    %eax,0x18(%rsp)
   37ab7:	e9 04 0f 00 00       	jmp    389c0 <oriole_expat::dispatch+0x4b40>
   37abc:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   37ac3:	00 
   37ac4:	48 85 c9             	test   %rcx,%rcx
   37ac7:	0f 84 b0 06 00 00    	je     3817d <oriole_expat::dispatch+0x42fd>
   37acd:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   37ad4:	00 
   37ad5:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   37adc:	00 
   37add:	ba 01 00 00 00       	mov    $0x1,%edx
   37ae2:	ff 15 90 ef 0a 00    	call   *0xaef90(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   37ae8:	e9 90 06 00 00       	jmp    3817d <oriole_expat::dispatch+0x42fd>
   37aed:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   37af2:	e8 99 78 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37af7:	b0 01                	mov    $0x1,%al
   37af9:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37afd:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   37b04:	00 
   37b05:	b0 01                	mov    $0x1,%al
   37b07:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37b0b:	b0 01                	mov    $0x1,%al
   37b0d:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37b11:	b0 01                	mov    $0x1,%al
   37b13:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37b17:	b0 01                	mov    $0x1,%al
   37b19:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37b1d:	e9 81 06 00 00       	jmp    381a3 <oriole_expat::dispatch+0x4323>
   37b22:	b0 01                	mov    $0x1,%al
   37b24:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37b28:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
   37b2f:	00 
   37b30:	b0 01                	mov    $0x1,%al
   37b32:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37b36:	b0 01                	mov    $0x1,%al
   37b38:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37b3c:	b0 01                	mov    $0x1,%al
   37b3e:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37b42:	b0 01                	mov    $0x1,%al
   37b44:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37b48:	b0 01                	mov    $0x1,%al
   37b4a:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37b4e:	b0 01                	mov    $0x1,%al
   37b50:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37b54:	b0 01                	mov    $0x1,%al
   37b56:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37b5a:	b0 01                	mov    $0x1,%al
   37b5c:	89 44 24 04          	mov    %eax,0x4(%rsp)
   37b60:	b0 01                	mov    $0x1,%al
   37b62:	89 44 24 24          	mov    %eax,0x24(%rsp)
   37b66:	b0 01                	mov    $0x1,%al
   37b68:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   37b6d:	b0 01                	mov    $0x1,%al
   37b6f:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37b73:	b0 01                	mov    $0x1,%al
   37b75:	89 44 24 20          	mov    %eax,0x20(%rsp)
   37b79:	b0 01                	mov    $0x1,%al
   37b7b:	89 44 24 18          	mov    %eax,0x18(%rsp)
   37b7f:	b0 01                	mov    $0x1,%al
   37b81:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   37b85:	e9 3c 0e 00 00       	jmp    389c6 <oriole_expat::dispatch+0x4b46>
   37b8a:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   37b91:	00 
   37b92:	e8 f9 77 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37b97:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   37b9e:	00 
   37b9f:	e8 ec 77 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37ba4:	e9 e8 08 00 00       	jmp    38491 <oriole_expat::dispatch+0x4611>
   37ba9:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   37bb0:	00 
   37bb1:	e8 da 77 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37bb6:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   37bbd:	00 
   37bbe:	e8 cd 77 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37bc3:	e9 7f 0a 00 00       	jmp    38647 <oriole_expat::dispatch+0x47c7>
   37bc8:	89 cb                	mov    %ecx,%ebx
   37bca:	41 b7 01             	mov    $0x1,%r15b
   37bcd:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   37bd4:	00 
   37bd5:	41 b5 01             	mov    $0x1,%r13b
   37bd8:	e8 b3 77 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37bdd:	41 b5 01             	mov    $0x1,%r13b
   37be0:	e9 1d 0c 00 00       	jmp    38802 <oriole_expat::dispatch+0x4982>
   37be5:	48 8b 94 24 28 02 00 	mov    0x228(%rsp),%rdx
   37bec:	00 
   37bed:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   37bf4:	00 
   37bf5:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   37bfa:	ff d5                	call   *%rbp
   37bfc:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   37c03:	00 
   37c04:	48 85 c9             	test   %rcx,%rcx
   37c07:	74 1b                	je     37c24 <oriole_expat::dispatch+0x3da4>
   37c09:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   37c10:	00 
   37c11:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   37c18:	00 
   37c19:	ba 01 00 00 00       	mov    $0x1,%edx
   37c1e:	ff 15 54 ee 0a 00    	call   *0xaee54(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   37c24:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   37c2b:	00 
   37c2c:	48 85 c9             	test   %rcx,%rcx
   37c2f:	74 18                	je     37c49 <oriole_expat::dispatch+0x3dc9>
   37c31:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   37c38:	00 
   37c39:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   37c3e:	ba 01 00 00 00       	mov    $0x1,%edx
   37c43:	ff 15 2f ee 0a 00    	call   *0xaee2f(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   37c49:	b3 01                	mov    $0x1,%bl
   37c4b:	e9 fa 05 00 00       	jmp    3824a <oriole_expat::dispatch+0x43ca>
   37c50:	45 31 ff             	xor    %r15d,%r15d
   37c53:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
   37c5a:	00 
   37c5b:	b3 01                	mov    $0x1,%bl
   37c5d:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   37c64:	00 
   37c65:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
   37c6c:	00 
   37c6d:	e8 be b1 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   37c72:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   37c79:	00 
   37c7a:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   37c81:	00 
   37c82:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   37c86:	0f 85 8e 00 00 00    	jne    37d1a <oriole_expat::dispatch+0x3e9a>
   37c8c:	41 89 cf             	mov    %ecx,%r15d
   37c8f:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   37c96:	00 
   37c97:	48 85 c9             	test   %rcx,%rcx
   37c9a:	74 15                	je     37cb1 <oriole_expat::dispatch+0x3e31>
   37c9c:	31 db                	xor    %ebx,%ebx
   37c9e:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   37ca3:	ba 01 00 00 00       	mov    $0x1,%edx
   37ca8:	4c 89 ee             	mov    %r13,%rsi
   37cab:	ff 15 c7 ed 0a 00    	call   *0xaedc7(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   37cb1:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   37cb8:	00 
   37cb9:	e8 d2 76 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37cbe:	e9 ce 07 00 00       	jmp    38491 <oriole_expat::dispatch+0x4611>
   37cc3:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   37cca:	00 
   37ccb:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   37cd2:	00 
   37cd3:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   37cda:	00 
   37cdb:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   37ce2:	00 
   37ce3:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   37cea:	00 
   37ceb:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   37cf2:	00 
   37cf3:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   37cfa:	00 
   37cfb:	44 88 bc 24 28 02 00 	mov    %r15b,0x228(%rsp)
   37d02:	00 
   37d03:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37d07:	0f 84 b1 06 00 00    	je     383be <oriole_expat::dispatch+0x453e>
   37d0d:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
   37d14:	00 
   37d15:	e9 a6 06 00 00       	jmp    383c0 <oriole_expat::dispatch+0x4540>
   37d1a:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   37d21:	00 
   37d22:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   37d29:	00 
   37d2a:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   37d31:	00 
   37d32:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   37d39:	00 
   37d3a:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   37d41:	00 
   37d42:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   37d49:	00 
   37d4a:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   37d51:	00 
   37d52:	88 8c 24 a8 00 00 00 	mov    %cl,0xa8(%rsp)
   37d59:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37d5d:	0f 84 cb 06 00 00    	je     3842e <oriole_expat::dispatch+0x45ae>
   37d63:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
   37d6a:	00 
   37d6b:	e9 c0 06 00 00       	jmp    38430 <oriole_expat::dispatch+0x45b0>
   37d70:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   37d77:	00 
   37d78:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   37d7f:	00 
   37d80:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   37d87:	00 
   37d88:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   37d8f:	00 
   37d90:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   37d97:	00 
   37d98:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   37d9f:	00 
   37da0:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   37da7:	00 
   37da8:	44 88 bc 24 a8 00 00 	mov    %r15b,0xa8(%rsp)
   37daf:	00 
   37db0:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37db4:	0f 84 29 08 00 00    	je     385e3 <oriole_expat::dispatch+0x4763>
   37dba:	4c 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%r15
   37dc1:	00 
   37dc2:	e9 1f 08 00 00       	jmp    385e6 <oriole_expat::dispatch+0x4766>
   37dc7:	41 b5 01             	mov    $0x1,%r13b
   37dca:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   37dd1:	00 
   37dd2:	b3 01                	mov    $0x1,%bl
   37dd4:	41 b4 01             	mov    $0x1,%r12b
   37dd7:	41 b7 01             	mov    $0x1,%r15b
   37dda:	e8 b1 75 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37ddf:	b3 01                	mov    $0x1,%bl
   37de1:	48 8d bc 24 a0 04 00 	lea    0x4a0(%rsp),%rdi
   37de8:	00 
   37de9:	41 b4 01             	mov    $0x1,%r12b
   37dec:	41 b7 01             	mov    $0x1,%r15b
   37def:	e8 9c 75 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37df4:	41 b4 01             	mov    $0x1,%r12b
   37df7:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
   37dfe:	00 
   37dff:	41 b7 01             	mov    $0x1,%r15b
   37e02:	e8 89 75 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37e07:	31 db                	xor    %ebx,%ebx
   37e09:	e9 ce 17 00 00       	jmp    395dc <oriole_expat::dispatch+0x575c>
   37e0e:	41 89 ce             	mov    %ecx,%r14d
   37e11:	41 b7 01             	mov    $0x1,%r15b
   37e14:	e9 35 05 00 00       	jmp    3834e <oriole_expat::dispatch+0x44ce>
   37e19:	41 89 cf             	mov    %ecx,%r15d
   37e1c:	eb 03                	jmp    37e21 <oriole_expat::dispatch+0x3fa1>
   37e1e:	41 89 c7             	mov    %eax,%r15d
   37e21:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   37e28:	00 
   37e29:	48 85 c9             	test   %rcx,%rcx
   37e2c:	74 1b                	je     37e49 <oriole_expat::dispatch+0x3fc9>
   37e2e:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   37e35:	00 
   37e36:	ba 01 00 00 00       	mov    $0x1,%edx
   37e3b:	48 8b b4 24 18 02 00 	mov    0x218(%rsp),%rsi
   37e42:	00 
   37e43:	ff 15 2f ec 0a 00    	call   *0xaec2f(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   37e49:	b0 01                	mov    $0x1,%al
   37e4b:	89 44 24 24          	mov    %eax,0x24(%rsp)
   37e4f:	b0 01                	mov    $0x1,%al
   37e51:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   37e56:	e9 6b 0b 00 00       	jmp    389c6 <oriole_expat::dispatch+0x4b46>
   37e5b:	45 31 f6             	xor    %r14d,%r14d
   37e5e:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   37e65:	00 
   37e66:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
   37e6b:	e8 c0 af ff ff       	call   32e30 <oriole_expat::optional_cstring>
   37e70:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   37e77:	00 
   37e78:	44 0f b6 bc 24 48 03 	movzbl 0x348(%rsp),%r15d
   37e7f:	00 00 
   37e81:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   37e85:	0f 85 24 02 00 00    	jne    380af <oriole_expat::dispatch+0x422f>
   37e8b:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   37e92:	00 
   37e93:	e8 f8 74 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37e98:	b0 01                	mov    $0x1,%al
   37e9a:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37e9e:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   37ea5:	00 
   37ea6:	b0 01                	mov    $0x1,%al
   37ea8:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37eac:	b0 01                	mov    $0x1,%al
   37eae:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37eb2:	b0 01                	mov    $0x1,%al
   37eb4:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37eb8:	b0 01                	mov    $0x1,%al
   37eba:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37ebe:	b0 01                	mov    $0x1,%al
   37ec0:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37ec4:	b0 01                	mov    $0x1,%al
   37ec6:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37eca:	b0 01                	mov    $0x1,%al
   37ecc:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37ed0:	b0 01                	mov    $0x1,%al
   37ed2:	89 44 24 04          	mov    %eax,0x4(%rsp)
   37ed6:	e9 c6 0a 00 00       	jmp    389a1 <oriole_expat::dispatch+0x4b21>
   37edb:	31 f6                	xor    %esi,%esi
   37edd:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   37ee2:	ff d3                	call   *%rbx
   37ee4:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   37eeb:	00 
   37eec:	b0 01                	mov    $0x1,%al
   37eee:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37ef2:	b0 01                	mov    $0x1,%al
   37ef4:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37ef8:	b0 01                	mov    $0x1,%al
   37efa:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37efe:	b0 01                	mov    $0x1,%al
   37f00:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37f04:	b0 01                	mov    $0x1,%al
   37f06:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37f0a:	b0 01                	mov    $0x1,%al
   37f0c:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37f10:	b0 01                	mov    $0x1,%al
   37f12:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37f16:	b0 01                	mov    $0x1,%al
   37f18:	89 44 24 04          	mov    %eax,0x4(%rsp)
   37f1c:	b0 01                	mov    $0x1,%al
   37f1e:	89 44 24 24          	mov    %eax,0x24(%rsp)
   37f22:	b0 01                	mov    $0x1,%al
   37f24:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37f28:	40 b5 01             	mov    $0x1,%bpl
   37f2b:	41 b7 01             	mov    $0x1,%r15b
   37f2e:	41 b4 01             	mov    $0x1,%r12b
   37f31:	41 b5 01             	mov    $0x1,%r13b
   37f34:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   37f3b:	00 00 
   37f3d:	e8 4e 74 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37f42:	b0 01                	mov    $0x1,%al
   37f44:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37f48:	31 f6                	xor    %esi,%esi
   37f4a:	b0 01                	mov    $0x1,%al
   37f4c:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37f50:	b0 01                	mov    $0x1,%al
   37f52:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37f56:	b0 01                	mov    $0x1,%al
   37f58:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37f5c:	b0 01                	mov    $0x1,%al
   37f5e:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37f62:	b0 01                	mov    $0x1,%al
   37f64:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37f68:	b0 01                	mov    $0x1,%al
   37f6a:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37f6e:	b0 01                	mov    $0x1,%al
   37f70:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37f74:	b0 01                	mov    $0x1,%al
   37f76:	89 44 24 04          	mov    %eax,0x4(%rsp)
   37f7a:	b1 01                	mov    $0x1,%cl
   37f7c:	e9 2f ef ff ff       	jmp    36eb0 <oriole_expat::dispatch+0x3030>
   37f81:	31 db                	xor    %ebx,%ebx
   37f83:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   37f8a:	00 
   37f8b:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   37f92:	00 
   37f93:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   37f9a:	00 
   37f9b:	0f 28 8c 24 f0 00 00 	movaps 0xf0(%rsp),%xmm1
   37fa2:	00 
   37fa3:	0f 28 94 24 00 01 00 	movaps 0x100(%rsp),%xmm2
   37faa:	00 
   37fab:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   37fb2:	00 
   37fb3:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   37fba:	00 
   37fbb:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   37fc2:	00 
   37fc3:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   37fca:	00 
   37fcb:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   37fd2:	00 
   37fd3:	ff 15 6f eb 0a 00    	call   *0xaeb6f(%rip)        # e6b48 <_GLOBAL_OFFSET_TABLE_+0x208>
   37fd9:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   37fe0:	00 
   37fe1:	44 0f b6 bc 24 28 02 	movzbl 0x228(%rsp),%r15d
   37fe8:	00 00 
   37fea:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37fee:	0f 84 79 03 00 00    	je     3836d <oriole_expat::dispatch+0x44ed>
   37ff4:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   37ffb:	00 
   37ffc:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   38003:	00 
   38004:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   3800b:	00 
   3800c:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   38013:	00 
   38014:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   3801b:	00 
   3801c:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   38023:	00 
   38024:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   3802b:	00 
   3802c:	44 88 bc 24 a8 00 00 	mov    %r15b,0xa8(%rsp)
   38033:	00 
   38034:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
   3803b:	00 
   3803c:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   38041:	48 89 de             	mov    %rbx,%rsi
   38044:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
   38049:	41 ff d4             	call   *%r12
   3804c:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   38053:	00 
   38054:	48 85 c9             	test   %rcx,%rcx
   38057:	74 1b                	je     38074 <oriole_expat::dispatch+0x41f4>
   38059:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   38060:	00 
   38061:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   38068:	00 
   38069:	ba 01 00 00 00       	mov    $0x1,%edx
   3806e:	ff 15 04 ea 0a 00    	call   *0xaea04(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38074:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   38079:	e8 12 73 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3807e:	b0 01                	mov    $0x1,%al
   38080:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38084:	b0 01                	mov    $0x1,%al
   38086:	8b 5c 24 40          	mov    0x40(%rsp),%ebx
   3808a:	b1 01                	mov    $0x1,%cl
   3808c:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   38090:	b1 01                	mov    $0x1,%cl
   38092:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   38096:	b1 01                	mov    $0x1,%cl
   38098:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   3809c:	b1 01                	mov    $0x1,%cl
   3809e:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   380a2:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   380a9:	00 
   380aa:	e9 39 d7 ff ff       	jmp    357e8 <oriole_expat::dispatch+0x1968>
   380af:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   380b6:	00 
   380b7:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   380be:	00 
   380bf:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   380c6:	00 
   380c7:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   380ce:	00 
   380cf:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   380d6:	00 
   380d7:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   380de:	00 
   380df:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   380e6:	00 
   380e7:	44 88 bc 24 28 02 00 	mov    %r15b,0x228(%rsp)
   380ee:	00 
   380ef:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   380f3:	0f 84 bc 07 00 00    	je     388b5 <oriole_expat::dispatch+0x4a35>
   380f9:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
   38100:	00 
   38101:	e9 b1 07 00 00       	jmp    388b7 <oriole_expat::dispatch+0x4a37>
   38106:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   3810d:	00 
   3810e:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   38115:	00 
   38116:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   3811d:	00 
   3811e:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   38125:	00 
   38126:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   3812d:	00 
   3812e:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   38135:	00 
   38136:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   3813d:	00 
   3813e:	44 88 bc 24 a8 00 00 	mov    %r15b,0xa8(%rsp)
   38145:	00 
   38146:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3814a:	0f 84 c8 07 00 00    	je     38918 <oriole_expat::dispatch+0x4a98>
   38150:	48 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%rbp
   38157:	00 
   38158:	e9 bd 07 00 00       	jmp    3891a <oriole_expat::dispatch+0x4a9a>
   3815d:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   38164:	00 
   38165:	48 85 c9             	test   %rcx,%rcx
   38168:	74 13                	je     3817d <oriole_expat::dispatch+0x42fd>
   3816a:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3816f:	ba 01 00 00 00       	mov    $0x1,%edx
   38174:	48 89 de             	mov    %rbx,%rsi
   38177:	ff 15 fb e8 0a 00    	call   *0xae8fb(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3817d:	b0 01                	mov    $0x1,%al
   3817f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   38183:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   3818a:	00 
   3818b:	b0 01                	mov    $0x1,%al
   3818d:	89 44 24 28          	mov    %eax,0x28(%rsp)
   38191:	b0 01                	mov    $0x1,%al
   38193:	89 44 24 48          	mov    %eax,0x48(%rsp)
   38197:	b0 01                	mov    $0x1,%al
   38199:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3819d:	b0 01                	mov    $0x1,%al
   3819f:	89 44 24 10          	mov    %eax,0x10(%rsp)
   381a3:	b0 01                	mov    $0x1,%al
   381a5:	89 44 24 40          	mov    %eax,0x40(%rsp)
   381a9:	e9 f5 01 00 00       	jmp    383a3 <oriole_expat::dispatch+0x4523>
   381ae:	89 cb                	mov    %ecx,%ebx
   381b0:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   381b7:	00 
   381b8:	48 85 c9             	test   %rcx,%rcx
   381bb:	74 1f                	je     381dc <oriole_expat::dispatch+0x435c>
   381bd:	40 b5 01             	mov    $0x1,%bpl
   381c0:	45 31 ed             	xor    %r13d,%r13d
   381c3:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   381ca:	00 
   381cb:	ba 01 00 00 00       	mov    $0x1,%edx
   381d0:	41 b7 01             	mov    $0x1,%r15b
   381d3:	4c 89 e6             	mov    %r12,%rsi
   381d6:	ff 15 9c e8 0a 00    	call   *0xae89c(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   381dc:	41 b7 01             	mov    $0x1,%r15b
   381df:	e9 06 06 00 00       	jmp    387ea <oriole_expat::dispatch+0x496a>
   381e4:	31 db                	xor    %ebx,%ebx
   381e6:	b0 01                	mov    $0x1,%al
   381e8:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   381ef:	00 
   381f0:	b1 01                	mov    $0x1,%cl
   381f2:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   381f6:	e9 db d5 ff ff       	jmp    357d6 <oriole_expat::dispatch+0x1956>
   381fb:	31 db                	xor    %ebx,%ebx
   381fd:	b0 01                	mov    $0x1,%al
   381ff:	31 d2                	xor    %edx,%edx
   38201:	b1 01                	mov    $0x1,%cl
   38203:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   38207:	b1 01                	mov    $0x1,%cl
   38209:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   3820d:	b1 01                	mov    $0x1,%cl
   3820f:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   38213:	b1 01                	mov    $0x1,%cl
   38215:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   38219:	b1 01                	mov    $0x1,%cl
   3821b:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   3821f:	b1 01                	mov    $0x1,%cl
   38221:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   38225:	b1 01                	mov    $0x1,%cl
   38227:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   3822b:	b1 01                	mov    $0x1,%cl
   3822d:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   38231:	b1 01                	mov    $0x1,%cl
   38233:	89 4c 24 20          	mov    %ecx,0x20(%rsp)
   38237:	b1 01                	mov    $0x1,%cl
   38239:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
   3823d:	b1 01                	mov    $0x1,%cl
   3823f:	89 4c 24 1c          	mov    %ecx,0x1c(%rsp)
   38243:	e9 c6 d5 ff ff       	jmp    3580e <oriole_expat::dispatch+0x198e>
   38248:	31 db                	xor    %ebx,%ebx
   3824a:	b0 01                	mov    $0x1,%al
   3824c:	c7 44 24 1c 00 00 00 	movl   $0x0,0x1c(%rsp)
   38253:	00 
   38254:	b1 01                	mov    $0x1,%cl
   38256:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   3825a:	b1 01                	mov    $0x1,%cl
   3825c:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   38260:	b1 01                	mov    $0x1,%cl
   38262:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   38266:	b1 01                	mov    $0x1,%cl
   38268:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   3826c:	b1 01                	mov    $0x1,%cl
   3826e:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   38272:	b1 01                	mov    $0x1,%cl
   38274:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   38278:	b1 01                	mov    $0x1,%cl
   3827a:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   3827e:	b1 01                	mov    $0x1,%cl
   38280:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   38284:	b1 01                	mov    $0x1,%cl
   38286:	89 4c 24 20          	mov    %ecx,0x20(%rsp)
   3828a:	b1 01                	mov    $0x1,%cl
   3828c:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
   38290:	e9 77 d5 ff ff       	jmp    3580c <oriole_expat::dispatch+0x198c>
   38295:	31 db                	xor    %ebx,%ebx
   38297:	b0 01                	mov    $0x1,%al
   38299:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   382a0:	00 
   382a1:	b1 01                	mov    $0x1,%cl
   382a3:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   382a7:	b1 01                	mov    $0x1,%cl
   382a9:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   382ad:	e9 2a d5 ff ff       	jmp    357dc <oriole_expat::dispatch+0x195c>
   382b2:	31 db                	xor    %ebx,%ebx
   382b4:	e9 54 01 00 00       	jmp    3840d <oriole_expat::dispatch+0x458d>
   382b9:	31 db                	xor    %ebx,%ebx
   382bb:	e9 0f 0d 00 00       	jmp    38fcf <oriole_expat::dispatch+0x514f>
   382c0:	31 db                	xor    %ebx,%ebx
   382c2:	e9 d1 0f 00 00       	jmp    39298 <oriole_expat::dispatch+0x5418>
   382c7:	31 db                	xor    %ebx,%ebx
   382c9:	e9 47 11 00 00       	jmp    39415 <oriole_expat::dispatch+0x5595>
   382ce:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
   382d5:	00 
   382d6:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   382db:	ff d3                	call   *%rbx
   382dd:	b3 01                	mov    $0x1,%bl
   382df:	49 8d 7e 30          	lea    0x30(%r14),%rdi
   382e3:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   382ea:	00 
   382eb:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   382f2:	00 
   382f3:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
   382fa:	00 
   382fb:	0f 28 8c 24 30 02 00 	movaps 0x230(%rsp),%xmm1
   38302:	00 
   38303:	0f 28 94 24 40 02 00 	movaps 0x240(%rsp),%xmm2
   3830a:	00 
   3830b:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   38312:	00 
   38313:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   3831a:	00 
   3831b:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   38322:	00 
   38323:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
   3832a:	00 
   3832b:	48 8b b4 24 90 05 00 	mov    0x590(%rsp),%rsi
   38332:	00 
   38333:	ff 15 df e6 0a 00    	call   *0xae6df(%rip)        # e6a18 <_GLOBAL_OFFSET_TABLE_+0xd8>
   38339:	b0 01                	mov    $0x1,%al
   3833b:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   38342:	00 
   38343:	e9 88 d4 ff ff       	jmp    357d0 <oriole_expat::dispatch+0x1950>
   38348:	41 89 ce             	mov    %ecx,%r14d
   3834b:	45 31 ff             	xor    %r15d,%r15d
   3834e:	41 b5 01             	mov    $0x1,%r13b
   38351:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   38358:	00 
   38359:	b3 01                	mov    $0x1,%bl
   3835b:	41 b4 01             	mov    $0x1,%r12b
   3835e:	e8 2d 70 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38363:	b3 01                	mov    $0x1,%bl
   38365:	41 b4 01             	mov    $0x1,%r12b
   38368:	e9 b2 0d 00 00       	jmp    3911f <oriole_expat::dispatch+0x529f>
   3836d:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   38372:	e8 19 70 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38377:	b0 01                	mov    $0x1,%al
   38379:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3837d:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   38384:	00 
   38385:	b0 01                	mov    $0x1,%al
   38387:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3838b:	b0 01                	mov    $0x1,%al
   3838d:	89 44 24 48          	mov    %eax,0x48(%rsp)
   38391:	b0 01                	mov    $0x1,%al
   38393:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38397:	b0 01                	mov    $0x1,%al
   38399:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3839d:	b0 01                	mov    $0x1,%al
   3839f:	89 44 24 10          	mov    %eax,0x10(%rsp)
   383a3:	b0 01                	mov    $0x1,%al
   383a5:	89 44 24 08          	mov    %eax,0x8(%rsp)
   383a9:	e9 e7 05 00 00       	jmp    38995 <oriole_expat::dispatch+0x4b15>
   383ae:	41 89 ce             	mov    %ecx,%r14d
   383b1:	b0 01                	mov    $0x1,%al
   383b3:	89 44 24 30          	mov    %eax,0x30(%rsp)
   383b7:	b3 01                	mov    $0x1,%bl
   383b9:	e9 0d 0d 00 00       	jmp    390cb <oriole_expat::dispatch+0x524b>
   383be:	31 d2                	xor    %edx,%edx
   383c0:	83 fd 02             	cmp    $0x2,%ebp
   383c3:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
   383c8:	0f 45 cd             	cmovne %ebp,%ecx
   383cb:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   383d0:	48 89 de             	mov    %rbx,%rsi
   383d3:	41 ff d4             	call   *%r12
   383d6:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   383dd:	00 
   383de:	e8 ad 6f ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   383e3:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   383ea:	00 
   383eb:	48 85 c9             	test   %rcx,%rcx
   383ee:	74 1b                	je     3840b <oriole_expat::dispatch+0x458b>
   383f0:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   383f7:	00 
   383f8:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   383ff:	00 
   38400:	ba 01 00 00 00       	mov    $0x1,%edx
   38405:	ff 15 6d e6 0a 00    	call   *0xae66d(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3840b:	b3 01                	mov    $0x1,%bl
   3840d:	b0 01                	mov    $0x1,%al
   3840f:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   38416:	00 
   38417:	b1 01                	mov    $0x1,%cl
   38419:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   3841d:	b1 01                	mov    $0x1,%cl
   3841f:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   38423:	b1 01                	mov    $0x1,%cl
   38425:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   38429:	e9 b4 d3 ff ff       	jmp    357e2 <oriole_expat::dispatch+0x1962>
   3842e:	31 db                	xor    %ebx,%ebx
   38430:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   38437:	00 
   38438:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   3843f:	00 
   38440:	e8 eb a9 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   38445:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   3844c:	00 
   3844d:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   38454:	00 
   38455:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   38459:	0f 85 25 02 00 00    	jne    38684 <oriole_expat::dispatch+0x4804>
   3845f:	41 89 cf             	mov    %ecx,%r15d
   38462:	31 db                	xor    %ebx,%ebx
   38464:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3846b:	00 
   3846c:	e8 1f 6f ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38471:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   38478:	00 
   38479:	48 85 c9             	test   %rcx,%rcx
   3847c:	74 13                	je     38491 <oriole_expat::dispatch+0x4611>
   3847e:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   38483:	ba 01 00 00 00       	mov    $0x1,%edx
   38488:	4c 89 ee             	mov    %r13,%rsi
   3848b:	ff 15 e7 e5 0a 00    	call   *0xae5e7(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38491:	b0 01                	mov    $0x1,%al
   38493:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38497:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3849e:	00 
   3849f:	b0 01                	mov    $0x1,%al
   384a1:	89 44 24 28          	mov    %eax,0x28(%rsp)
   384a5:	b0 01                	mov    $0x1,%al
   384a7:	89 44 24 30          	mov    %eax,0x30(%rsp)
   384ab:	b0 01                	mov    $0x1,%al
   384ad:	89 44 24 48          	mov    %eax,0x48(%rsp)
   384b1:	b0 01                	mov    $0x1,%al
   384b3:	89 44 24 14          	mov    %eax,0x14(%rsp)
   384b7:	b0 01                	mov    $0x1,%al
   384b9:	89 44 24 10          	mov    %eax,0x10(%rsp)
   384bd:	b0 01                	mov    $0x1,%al
   384bf:	89 44 24 40          	mov    %eax,0x40(%rsp)
   384c3:	b0 01                	mov    $0x1,%al
   384c5:	89 44 24 08          	mov    %eax,0x8(%rsp)
   384c9:	b0 01                	mov    $0x1,%al
   384cb:	89 44 24 04          	mov    %eax,0x4(%rsp)
   384cf:	b0 01                	mov    $0x1,%al
   384d1:	89 44 24 24          	mov    %eax,0x24(%rsp)
   384d5:	b0 01                	mov    $0x1,%al
   384d7:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   384dc:	b0 01                	mov    $0x1,%al
   384de:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   384e2:	b0 01                	mov    $0x1,%al
   384e4:	89 44 24 20          	mov    %eax,0x20(%rsp)
   384e8:	e9 cd 04 00 00       	jmp    389ba <oriole_expat::dispatch+0x4b3a>
   384ed:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   384f4:	00 
   384f5:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   384fc:	00 
   384fd:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   38504:	00 
   38505:	0f 11 94 24 08 01 00 	movups %xmm2,0x108(%rsp)
   3850c:	00 
   3850d:	0f 11 8c 24 f9 00 00 	movups %xmm1,0xf9(%rsp)
   38514:	00 
   38515:	0f 11 84 24 e9 00 00 	movups %xmm0,0xe9(%rsp)
   3851c:	00 
   3851d:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
   38524:	00 
   38525:	88 8c 24 e8 00 00 00 	mov    %cl,0xe8(%rsp)
   3852c:	31 db                	xor    %ebx,%ebx
   3852e:	b9 00 00 00 00       	mov    $0x0,%ecx
   38533:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38537:	74 08                	je     38541 <oriole_expat::dispatch+0x46c1>
   38539:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
   38540:	00 
   38541:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
   38546:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   3854b:	83 bc 24 18 05 00 00 	cmpl   $0xffffffff,0x518(%rsp)
   38552:	ff 
   38553:	74 08                	je     3855d <oriole_expat::dispatch+0x46dd>
   38555:	48 8b 9c 24 38 05 00 	mov    0x538(%rsp),%rbx
   3855c:	00 
   3855d:	41 b4 01             	mov    $0x1,%r12b
   38560:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   38567:	00 
   38568:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
   3856f:	00 
   38570:	41 b7 01             	mov    $0x1,%r15b
   38573:	e8 b8 a8 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   38578:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   3857f:	00 
   38580:	0f b6 ac 24 48 03 00 	movzbl 0x348(%rsp),%ebp
   38587:	00 
   38588:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   3858c:	0f 85 82 0a 00 00    	jne    39014 <oriole_expat::dispatch+0x5194>
   38592:	41 b4 01             	mov    $0x1,%r12b
   38595:	41 b7 01             	mov    $0x1,%r15b
   38598:	e9 ab 11 00 00       	jmp    39748 <oriole_expat::dispatch+0x58c8>
   3859d:	45 31 e4             	xor    %r12d,%r12d
   385a0:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
   385a7:	00 
   385a8:	b3 01                	mov    $0x1,%bl
   385aa:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   385b1:	00 
   385b2:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
   385b9:	00 
   385ba:	e8 71 a8 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   385bf:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   385c6:	00 
   385c7:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   385ce:	00 
   385cf:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   385d3:	0f 85 01 01 00 00    	jne    386da <oriole_expat::dispatch+0x485a>
   385d9:	41 89 ce             	mov    %ecx,%r14d
   385dc:	b3 01                	mov    $0x1,%bl
   385de:	e9 c2 0a 00 00       	jmp    390a5 <oriole_expat::dispatch+0x5225>
   385e3:	45 31 ff             	xor    %r15d,%r15d
   385e6:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   385ed:	00 
   385ee:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   385f5:	00 
   385f6:	e8 35 a8 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   385fb:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   38602:	00 
   38603:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   3860a:	00 
   3860b:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   3860f:	0f 85 1b 01 00 00    	jne    38730 <oriole_expat::dispatch+0x48b0>
   38615:	41 89 cf             	mov    %ecx,%r15d
   38618:	31 ed                	xor    %ebp,%ebp
   3861a:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   38621:	00 
   38622:	e8 69 6d ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38627:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   3862e:	00 
   3862f:	48 85 c9             	test   %rcx,%rcx
   38632:	74 13                	je     38647 <oriole_expat::dispatch+0x47c7>
   38634:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   38639:	ba 01 00 00 00       	mov    $0x1,%edx
   3863e:	4c 89 e6             	mov    %r12,%rsi
   38641:	ff 15 31 e4 0a 00    	call   *0xae431(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38647:	b0 01                	mov    $0x1,%al
   38649:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3864d:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   38654:	00 
   38655:	b0 01                	mov    $0x1,%al
   38657:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3865b:	b0 01                	mov    $0x1,%al
   3865d:	89 44 24 30          	mov    %eax,0x30(%rsp)
   38661:	b0 01                	mov    $0x1,%al
   38663:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38667:	b0 01                	mov    $0x1,%al
   38669:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3866d:	b0 01                	mov    $0x1,%al
   3866f:	89 44 24 10          	mov    %eax,0x10(%rsp)
   38673:	b0 01                	mov    $0x1,%al
   38675:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38679:	b0 01                	mov    $0x1,%al
   3867b:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3867f:	e9 17 03 00 00       	jmp    3899b <oriole_expat::dispatch+0x4b1b>
   38684:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   3868b:	00 
   3868c:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   38693:	00 
   38694:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   3869b:	00 
   3869c:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   386a3:	00 
   386a4:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   386ab:	00 
   386ac:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   386b3:	00 
   386b4:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   386bb:	00 
   386bc:	88 8c 24 28 02 00 00 	mov    %cl,0x228(%rsp)
   386c3:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   386c7:	0f 84 ab 08 00 00    	je     38f78 <oriole_expat::dispatch+0x50f8>
   386cd:	4c 8b 84 24 40 02 00 	mov    0x240(%rsp),%r8
   386d4:	00 
   386d5:	e9 a1 08 00 00       	jmp    38f7b <oriole_expat::dispatch+0x50fb>
   386da:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   386e1:	00 
   386e2:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   386e9:	00 
   386ea:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   386f1:	00 
   386f2:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   386f9:	00 
   386fa:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   38701:	00 
   38702:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   38709:	00 
   3870a:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   38711:	00 
   38712:	88 8c 24 a8 00 00 00 	mov    %cl,0xa8(%rsp)
   38719:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3871d:	0f 84 3f 09 00 00    	je     39062 <oriole_expat::dispatch+0x51e2>
   38723:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
   3872a:	00 
   3872b:	e9 34 09 00 00       	jmp    39064 <oriole_expat::dispatch+0x51e4>
   38730:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   38737:	00 
   38738:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   3873f:	00 
   38740:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   38747:	00 
   38748:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   3874f:	00 
   38750:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   38757:	00 
   38758:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   3875f:	00 
   38760:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   38767:	00 
   38768:	88 8c 24 28 02 00 00 	mov    %cl,0x228(%rsp)
   3876f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38773:	0f 84 c5 0a 00 00    	je     3923e <oriole_expat::dispatch+0x53be>
   38779:	48 8b 8c 24 40 02 00 	mov    0x240(%rsp),%rcx
   38780:	00 
   38781:	e9 ba 0a 00 00       	jmp    39240 <oriole_expat::dispatch+0x53c0>
   38786:	40 b5 01             	mov    $0x1,%bpl
   38789:	44 89 fb             	mov    %r15d,%ebx
   3878c:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   38793:	00 
   38794:	48 85 c9             	test   %rcx,%rcx
   38797:	74 1b                	je     387b4 <oriole_expat::dispatch+0x4934>
   38799:	45 31 ff             	xor    %r15d,%r15d
   3879c:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   387a3:	00 
   387a4:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   387a9:	ba 01 00 00 00       	mov    $0x1,%edx
   387ae:	ff 15 c4 e2 0a 00    	call   *0xae2c4(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   387b4:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   387bb:	00 
   387bc:	48 85 c9             	test   %rcx,%rcx
   387bf:	74 21                	je     387e2 <oriole_expat::dispatch+0x4962>
   387c1:	45 31 ff             	xor    %r15d,%r15d
   387c4:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   387cb:	00 
   387cc:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   387d3:	00 
   387d4:	ba 01 00 00 00       	mov    $0x1,%edx
   387d9:	45 31 ed             	xor    %r13d,%r13d
   387dc:	ff 15 96 e2 0a 00    	call   *0xae296(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   387e2:	40 84 ed             	test   %bpl,%bpl
   387e5:	74 75                	je     3885c <oriole_expat::dispatch+0x49dc>
   387e7:	45 31 ff             	xor    %r15d,%r15d
   387ea:	45 31 ed             	xor    %r13d,%r13d
   387ed:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   387f4:	00 
   387f5:	e8 96 6b ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   387fa:	45 84 ff             	test   %r15b,%r15b
   387fd:	74 5d                	je     3885c <oriole_expat::dispatch+0x49dc>
   387ff:	45 31 ed             	xor    %r13d,%r13d
   38802:	41 89 df             	mov    %ebx,%r15d
   38805:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   3880c:	00 
   3880d:	48 85 c9             	test   %rcx,%rcx
   38810:	74 1b                	je     3882d <oriole_expat::dispatch+0x49ad>
   38812:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   38819:	00 
   3881a:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   38821:	00 
   38822:	ba 01 00 00 00       	mov    $0x1,%edx
   38827:	ff 15 4b e2 0a 00    	call   *0xae24b(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3882d:	45 84 ed             	test   %r13b,%r13b
   38830:	74 2d                	je     3885f <oriole_expat::dispatch+0x49df>
   38832:	48 8b 8c 24 c8 04 00 	mov    0x4c8(%rsp),%rcx
   38839:	00 
   3883a:	48 85 c9             	test   %rcx,%rcx
   3883d:	74 20                	je     3885f <oriole_expat::dispatch+0x49df>
   3883f:	48 8b b4 24 c0 04 00 	mov    0x4c0(%rsp),%rsi
   38846:	00 
   38847:	48 8d bc 24 a0 04 00 	lea    0x4a0(%rsp),%rdi
   3884e:	00 
   3884f:	ba 01 00 00 00       	mov    $0x1,%edx
   38854:	ff 15 1e e2 0a 00    	call   *0xae21e(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3885a:	eb 03                	jmp    3885f <oriole_expat::dispatch+0x49df>
   3885c:	41 89 df             	mov    %ebx,%r15d
   3885f:	b0 01                	mov    $0x1,%al
   38861:	89 44 24 30          	mov    %eax,0x30(%rsp)
   38865:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   3886c:	00 
   3886d:	b0 01                	mov    $0x1,%al
   3886f:	89 44 24 28          	mov    %eax,0x28(%rsp)
   38873:	b0 01                	mov    $0x1,%al
   38875:	89 44 24 48          	mov    %eax,0x48(%rsp)
   38879:	b0 01                	mov    $0x1,%al
   3887b:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3887f:	b0 01                	mov    $0x1,%al
   38881:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38885:	b0 01                	mov    $0x1,%al
   38887:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3888b:	b0 01                	mov    $0x1,%al
   3888d:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38891:	b0 01                	mov    $0x1,%al
   38893:	89 44 24 08          	mov    %eax,0x8(%rsp)
   38897:	b0 01                	mov    $0x1,%al
   38899:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3889d:	b0 01                	mov    $0x1,%al
   3889f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   388a3:	b0 01                	mov    $0x1,%al
   388a5:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   388aa:	b0 01                	mov    $0x1,%al
   388ac:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   388b0:	e9 ff 00 00 00       	jmp    389b4 <oriole_expat::dispatch+0x4b34>
   388b5:	31 d2                	xor    %edx,%edx
   388b7:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   388bc:	4c 89 f6             	mov    %r14,%rsi
   388bf:	ff d3                	call   *%rbx
   388c1:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   388c8:	00 
   388c9:	e8 c2 6a ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   388ce:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   388d5:	00 
   388d6:	e8 b5 6a ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   388db:	b0 01                	mov    $0x1,%al
   388dd:	89 44 24 48          	mov    %eax,0x48(%rsp)
   388e1:	31 c9                	xor    %ecx,%ecx
   388e3:	b0 01                	mov    $0x1,%al
   388e5:	89 44 24 28          	mov    %eax,0x28(%rsp)
   388e9:	b0 01                	mov    $0x1,%al
   388eb:	89 44 24 30          	mov    %eax,0x30(%rsp)
   388ef:	b0 01                	mov    $0x1,%al
   388f1:	89 44 24 38          	mov    %eax,0x38(%rsp)
   388f5:	b0 01                	mov    $0x1,%al
   388f7:	89 44 24 14          	mov    %eax,0x14(%rsp)
   388fb:	b0 01                	mov    $0x1,%al
   388fd:	89 44 24 10          	mov    %eax,0x10(%rsp)
   38901:	b0 01                	mov    $0x1,%al
   38903:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38907:	b0 01                	mov    $0x1,%al
   38909:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3890d:	b0 01                	mov    $0x1,%al
   3890f:	89 44 24 04          	mov    %eax,0x4(%rsp)
   38913:	e9 95 e5 ff ff       	jmp    36ead <oriole_expat::dispatch+0x302d>
   38918:	31 ed                	xor    %ebp,%ebp
   3891a:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   38921:	00 
   38922:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   38929:	00 
   3892a:	e8 01 a5 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   3892f:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   38936:	00 
   38937:	44 0f b6 bc 24 48 03 	movzbl 0x348(%rsp),%r15d
   3893e:	00 00 
   38940:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   38944:	0f 85 07 04 00 00    	jne    38d51 <oriole_expat::dispatch+0x4ed1>
   3894a:	31 ed                	xor    %ebp,%ebp
   3894c:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   38953:	00 
   38954:	e8 37 6a ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38959:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3895e:	e8 2d 6a ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38963:	b0 01                	mov    $0x1,%al
   38965:	89 44 24 48          	mov    %eax,0x48(%rsp)
   38969:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   38970:	00 
   38971:	b0 01                	mov    $0x1,%al
   38973:	89 44 24 28          	mov    %eax,0x28(%rsp)
   38977:	b0 01                	mov    $0x1,%al
   38979:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3897d:	b0 01                	mov    $0x1,%al
   3897f:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38983:	b0 01                	mov    $0x1,%al
   38985:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38989:	b0 01                	mov    $0x1,%al
   3898b:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3898f:	b0 01                	mov    $0x1,%al
   38991:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38995:	b0 01                	mov    $0x1,%al
   38997:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3899b:	b0 01                	mov    $0x1,%al
   3899d:	89 44 24 24          	mov    %eax,0x24(%rsp)
   389a1:	b0 01                	mov    $0x1,%al
   389a3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   389a8:	b0 01                	mov    $0x1,%al
   389aa:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   389ae:	b0 01                	mov    $0x1,%al
   389b0:	89 44 24 20          	mov    %eax,0x20(%rsp)
   389b4:	b0 01                	mov    $0x1,%al
   389b6:	89 44 24 18          	mov    %eax,0x18(%rsp)
   389ba:	b0 01                	mov    $0x1,%al
   389bc:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   389c0:	b0 01                	mov    $0x1,%al
   389c2:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   389c6:	83 bc 24 18 05 00 00 	cmpl   $0xffffffff,0x518(%rsp)
   389cd:	ff 
   389ce:	74 28                	je     389f8 <oriole_expat::dispatch+0x4b78>
   389d0:	48 8b 8c 24 40 05 00 	mov    0x540(%rsp),%rcx
   389d7:	00 
   389d8:	48 85 c9             	test   %rcx,%rcx
   389db:	74 1b                	je     389f8 <oriole_expat::dispatch+0x4b78>
   389dd:	48 8b b4 24 38 05 00 	mov    0x538(%rsp),%rsi
   389e4:	00 
   389e5:	48 8d bc 24 18 05 00 	lea    0x518(%rsp),%rdi
   389ec:	00 
   389ed:	ba 01 00 00 00       	mov    $0x1,%edx
   389f2:	ff 15 80 e0 0a 00    	call   *0xae080(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   389f8:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
   389ff:	00 
   38a00:	48 83 e9 03          	sub    $0x3,%rcx
   38a04:	b8 0d 00 00 00       	mov    $0xd,%eax
   38a09:	48 0f 43 c1          	cmovae %rcx,%rax
   38a0d:	48 83 c0 fa          	add    $0xfffffffffffffffa,%rax
   38a11:	48 83 f8 14          	cmp    $0x14,%rax
   38a15:	0f 87 21 03 00 00    	ja     38d3c <oriole_expat::dispatch+0x4ebc>
   38a1b:	48 8d 0d ba 13 fd ff 	lea    -0x2ec46(%rip),%rcx        # 9ddc <std::thread::current::id::ID+0x9d6c>
   38a22:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   38a26:	48 01 c8             	add    %rcx,%rax
   38a29:	ff e0                	jmp    *%rax
   38a2b:	80 7c 24 28 00       	cmpb   $0x0,0x28(%rsp)
   38a30:	0f 84 06 03 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38a36:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   38a3d:	00 
   38a3e:	48 85 c9             	test   %rcx,%rcx
   38a41:	74 1b                	je     38a5e <oriole_expat::dispatch+0x4bde>
   38a43:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   38a4a:	00 
   38a4b:	ba 01 00 00 00       	mov    $0x1,%edx
   38a50:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   38a57:	00 
   38a58:	ff 15 1a e0 0a 00    	call   *0xae01a(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38a5e:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   38a65:	00 
   38a66:	e8 45 76 ff ff       	call   300b0 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   38a6b:	e9 cc 02 00 00       	jmp    38d3c <oriole_expat::dispatch+0x4ebc>
   38a70:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
   38a75:	0f 84 c1 02 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38a7b:	48 8b 9c 24 50 01 00 	mov    0x150(%rsp),%rbx
   38a82:	00 
   38a83:	48 89 df             	mov    %rbx,%rdi
   38a86:	e8 25 81 ff ff       	call   30bb0 <core::ptr::drop_glue::<oriole::NotationDeclaration>>
   38a8b:	e9 4d 01 00 00       	jmp    38bdd <oriole_expat::dispatch+0x4d5d>
   38a90:	80 7c 24 50 00       	cmpb   $0x0,0x50(%rsp)
   38a95:	0f 85 65 bb ff ff    	jne    34600 <oriole_expat::dispatch+0x780>
   38a9b:	e9 9c 02 00 00       	jmp    38d3c <oriole_expat::dispatch+0x4ebc>
   38aa0:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
   38aa5:	0f 84 91 02 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38aab:	48 8b 9c 24 50 01 00 	mov    0x150(%rsp),%rbx
   38ab2:	00 
   38ab3:	48 89 df             	mov    %rbx,%rdi
   38ab6:	e8 a5 81 ff ff       	call   30c60 <core::ptr::drop_glue::<oriole::AttributeDeclaration>>
   38abb:	ba 08 00 00 00       	mov    $0x8,%edx
   38ac0:	b9 e8 00 00 00       	mov    $0xe8,%ecx
   38ac5:	e9 61 02 00 00       	jmp    38d2b <oriole_expat::dispatch+0x4eab>
   38aca:	80 7c 24 48 00       	cmpb   $0x0,0x48(%rsp)
   38acf:	0f 84 67 02 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38ad5:	e9 26 bb ff ff       	jmp    34600 <oriole_expat::dispatch+0x780>
   38ada:	80 7c 24 10 00       	cmpb   $0x0,0x10(%rsp)
   38adf:	0f 84 57 02 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38ae5:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   38aec:	00 
   38aed:	48 85 c9             	test   %rcx,%rcx
   38af0:	74 1b                	je     38b0d <oriole_expat::dispatch+0x4c8d>
   38af2:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   38af9:	00 
   38afa:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   38b01:	00 
   38b02:	ba 01 00 00 00       	mov    $0x1,%edx
   38b07:	ff 15 6b df 0a 00    	call   *0xadf6b(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38b0d:	83 bc 24 60 01 00 00 	cmpl   $0xffffffff,0x160(%rsp)
   38b14:	ff 
   38b15:	0f 84 21 02 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38b1b:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   38b22:	00 
   38b23:	48 85 c9             	test   %rcx,%rcx
   38b26:	0f 84 10 02 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38b2c:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   38b33:	00 
   38b34:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
   38b3b:	00 
   38b3c:	e9 c2 01 00 00       	jmp    38d03 <oriole_expat::dispatch+0x4e83>
   38b41:	80 7c 24 0c 00       	cmpb   $0x0,0xc(%rsp)
   38b46:	0f 84 f0 01 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38b4c:	48 8b 9c 24 50 01 00 	mov    0x150(%rsp),%rbx
   38b53:	00 
   38b54:	48 89 df             	mov    %rbx,%rdi
   38b57:	e8 74 7e ff ff       	call   309d0 <core::ptr::drop_glue::<oriole::EntityDeclaration>>
   38b5c:	ba 08 00 00 00       	mov    $0x8,%edx
   38b61:	b9 20 01 00 00       	mov    $0x120,%ecx
   38b66:	e9 c0 01 00 00       	jmp    38d2b <oriole_expat::dispatch+0x4eab>
   38b6b:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
   38b70:	0f 85 c9 00 00 00    	jne    38c3f <oriole_expat::dispatch+0x4dbf>
   38b76:	e9 c1 01 00 00       	jmp    38d3c <oriole_expat::dispatch+0x4ebc>
   38b7b:	80 7c 24 40 00       	cmpb   $0x0,0x40(%rsp)
   38b80:	0f 84 b6 01 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38b86:	83 bc 24 68 01 00 00 	cmpl   $0xffffffff,0x168(%rsp)
   38b8d:	ff 
   38b8e:	0f 84 ab 00 00 00    	je     38c3f <oriole_expat::dispatch+0x4dbf>
   38b94:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
   38b9b:	00 
   38b9c:	48 85 c9             	test   %rcx,%rcx
   38b9f:	0f 84 9a 00 00 00    	je     38c3f <oriole_expat::dispatch+0x4dbf>
   38ba5:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   38bac:	00 
   38bad:	48 8b b4 24 88 01 00 	mov    0x188(%rsp),%rsi
   38bb4:	00 
   38bb5:	ba 01 00 00 00       	mov    $0x1,%edx
   38bba:	ff 15 b8 de 0a 00    	call   *0xadeb8(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38bc0:	eb 7d                	jmp    38c3f <oriole_expat::dispatch+0x4dbf>
   38bc2:	80 7c 24 08 00       	cmpb   $0x0,0x8(%rsp)
   38bc7:	0f 84 6f 01 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38bcd:	48 8b 9c 24 50 01 00 	mov    0x150(%rsp),%rbx
   38bd4:	00 
   38bd5:	48 89 df             	mov    %rbx,%rdi
   38bd8:	e8 93 81 ff ff       	call   30d70 <core::ptr::drop_glue::<oriole::ExternalEntityReference>>
   38bdd:	ba 08 00 00 00       	mov    $0x8,%edx
   38be2:	b9 a8 00 00 00       	mov    $0xa8,%ecx
   38be7:	e9 3f 01 00 00       	jmp    38d2b <oriole_expat::dispatch+0x4eab>
   38bec:	80 7c 24 1c 00       	cmpb   $0x0,0x1c(%rsp)
   38bf1:	0f 84 45 01 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38bf7:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   38bfe:	00 
   38bff:	48 85 c9             	test   %rcx,%rcx
   38c02:	0f 84 de 00 00 00    	je     38ce6 <oriole_expat::dispatch+0x4e66>
   38c08:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   38c0f:	00 
   38c10:	ba 01 00 00 00       	mov    $0x1,%edx
   38c15:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   38c1c:	00 
   38c1d:	ff 15 55 de 0a 00    	call   *0xade55(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38c23:	e9 be 00 00 00       	jmp    38ce6 <oriole_expat::dispatch+0x4e66>
   38c28:	80 7c 24 2c 00       	cmpb   $0x0,0x2c(%rsp)
   38c2d:	75 10                	jne    38c3f <oriole_expat::dispatch+0x4dbf>
   38c2f:	e9 08 01 00 00       	jmp    38d3c <oriole_expat::dispatch+0x4ebc>
   38c34:	80 7c 24 38 00       	cmpb   $0x0,0x38(%rsp)
   38c39:	0f 84 fd 00 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38c3f:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   38c46:	00 
   38c47:	48 85 c9             	test   %rcx,%rcx
   38c4a:	0f 84 ec 00 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38c50:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   38c57:	00 
   38c58:	ba 01 00 00 00       	mov    $0x1,%edx
   38c5d:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   38c64:	00 
   38c65:	e9 cc 00 00 00       	jmp    38d36 <oriole_expat::dispatch+0x4eb6>
   38c6a:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
   38c6f:	0f 84 c7 00 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38c75:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   38c7c:	00 
   38c7d:	48 85 c9             	test   %rcx,%rcx
   38c80:	74 64                	je     38ce6 <oriole_expat::dispatch+0x4e66>
   38c82:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   38c89:	00 
   38c8a:	ba 01 00 00 00       	mov    $0x1,%edx
   38c8f:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   38c96:	00 
   38c97:	ff 15 db dd 0a 00    	call   *0xadddb(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38c9d:	eb 47                	jmp    38ce6 <oriole_expat::dispatch+0x4e66>
   38c9f:	80 7c 24 24 00       	cmpb   $0x0,0x24(%rsp)
   38ca4:	0f 84 92 00 00 00    	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38caa:	83 bc 24 30 01 00 00 	cmpl   $0xffffffff,0x130(%rsp)
   38cb1:	ff 
   38cb2:	74 28                	je     38cdc <oriole_expat::dispatch+0x4e5c>
   38cb4:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   38cbb:	00 
   38cbc:	48 85 c9             	test   %rcx,%rcx
   38cbf:	74 1b                	je     38cdc <oriole_expat::dispatch+0x4e5c>
   38cc1:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   38cc8:	00 
   38cc9:	ba 01 00 00 00       	mov    $0x1,%edx
   38cce:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   38cd5:	00 
   38cd6:	ff 15 9c dd 0a 00    	call   *0xadd9c(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38cdc:	83 bc 24 68 01 00 00 	cmpl   $0xffffffff,0x168(%rsp)
   38ce3:	ff 
   38ce4:	74 56                	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38ce6:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
   38ced:	00 
   38cee:	48 85 c9             	test   %rcx,%rcx
   38cf1:	74 49                	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38cf3:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   38cfa:	00 
   38cfb:	48 8b b4 24 88 01 00 	mov    0x188(%rsp),%rsi
   38d02:	00 
   38d03:	ba 01 00 00 00       	mov    $0x1,%edx
   38d08:	eb 2c                	jmp    38d36 <oriole_expat::dispatch+0x4eb6>
   38d0a:	80 7c 24 04 00       	cmpb   $0x0,0x4(%rsp)
   38d0f:	74 2b                	je     38d3c <oriole_expat::dispatch+0x4ebc>
   38d11:	48 8b 9c 24 50 01 00 	mov    0x150(%rsp),%rbx
   38d18:	00 
   38d19:	48 89 df             	mov    %rbx,%rdi
   38d1c:	e8 df 7d ff ff       	call   30b00 <core::ptr::drop_glue::<oriole::DoctypeDeclaration>>
   38d21:	ba 08 00 00 00       	mov    $0x8,%edx
   38d26:	b9 b0 00 00 00       	mov    $0xb0,%ecx
   38d2b:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   38d32:	00 
   38d33:	48 89 de             	mov    %rbx,%rsi
   38d36:	ff 15 3c dd 0a 00    	call   *0xadd3c(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38d3c:	44 89 f8             	mov    %r15d,%eax
   38d3f:	48 81 c4 88 06 00 00 	add    $0x688,%rsp
   38d46:	5b                   	pop    %rbx
   38d47:	41 5c                	pop    %r12
   38d49:	41 5d                	pop    %r13
   38d4b:	41 5e                	pop    %r14
   38d4d:	41 5f                	pop    %r15
   38d4f:	5d                   	pop    %rbp
   38d50:	c3                   	ret
   38d51:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   38d58:	00 
   38d59:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   38d60:	00 
   38d61:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   38d68:	00 
   38d69:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   38d70:	00 
   38d71:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   38d78:	00 
   38d79:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   38d80:	00 
   38d81:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   38d88:	00 
   38d89:	44 88 bc 24 28 02 00 	mov    %r15b,0x228(%rsp)
   38d90:	00 
   38d91:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38d95:	0f 84 86 05 00 00    	je     39321 <oriole_expat::dispatch+0x54a1>
   38d9b:	4c 8b 84 24 40 02 00 	mov    0x240(%rsp),%r8
   38da2:	00 
   38da3:	e9 7c 05 00 00       	jmp    39324 <oriole_expat::dispatch+0x54a4>
   38da8:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   38daf:	00 
   38db0:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   38db7:	00 
   38db8:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   38dbf:	00 
   38dc0:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   38dc7:	00 
   38dc8:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   38dcf:	00 
   38dd0:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   38dd7:	00 
   38dd8:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   38ddf:	00 
   38de0:	44 88 bc 24 28 02 00 	mov    %r15b,0x228(%rsp)
   38de7:	00 
   38de8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38dec:	48 8b 84 24 78 04 00 	mov    0x478(%rsp),%rax
   38df3:	00 
   38df4:	0f 84 72 05 00 00    	je     3936c <oriole_expat::dispatch+0x54ec>
   38dfa:	4c 8b 84 24 40 02 00 	mov    0x240(%rsp),%r8
   38e01:	00 
   38e02:	e9 68 05 00 00       	jmp    3936f <oriole_expat::dispatch+0x54ef>
   38e07:	48 89 d8             	mov    %rbx,%rax
   38e0a:	48 c1 e8 3c          	shr    $0x3c,%rax
   38e0e:	b0 01                	mov    $0x1,%al
   38e10:	0f 85 f5 09 00 00    	jne    3980b <oriole_expat::dispatch+0x598b>
   38e16:	4a 8d 04 7d 01 00 00 	lea    0x1(,%r15,2),%rax
   38e1d:	00 
   38e1e:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
   38e25:	00 
   38e26:	41 bd 08 00 00 00    	mov    $0x8,%r13d
   38e2c:	45 31 e4             	xor    %r12d,%r12d
   38e2f:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   38e36:	00 
   38e37:	be 08 00 00 00       	mov    $0x8,%esi
   38e3c:	ff 15 56 dc 0a 00    	call   *0xadc56(%rip)        # e6a98 <_GLOBAL_OFFSET_TABLE_+0x158>
   38e42:	48 85 c0             	test   %rax,%rax
   38e45:	0f 84 be 09 00 00    	je     39809 <oriole_expat::dispatch+0x5989>
   38e4b:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
   38e52:	00 
   38e53:	48 89 c5             	mov    %rax,%rbp
   38e56:	4e 8d 24 7d 01 00 00 	lea    0x1(,%r15,2),%r12
   38e5d:	00 
   38e5e:	4c 89 a4 24 48 02 00 	mov    %r12,0x248(%rsp)
   38e65:	00 
   38e66:	49 c1 e7 04          	shl    $0x4,%r15
   38e6a:	48 89 c7             	mov    %rax,%rdi
   38e6d:	31 f6                	xor    %esi,%esi
   38e6f:	4c 89 fa             	mov    %r15,%rdx
   38e72:	ff 15 d0 e4 0a 00    	call   *0xae4d0(%rip)        # e7348 <memset@GLIBC_2.2.5>
   38e78:	4a c7 44 3d 00 00 00 	movq   $0x0,0x0(%rbp,%r15,1)
   38e7f:	00 00 
   38e81:	48 83 cb 01          	or     $0x1,%rbx
   38e85:	48 89 9c 24 50 02 00 	mov    %rbx,0x250(%rsp)
   38e8c:	00 
   38e8d:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
   38e94:	00 
   38e95:	4c 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%r15
   38e9c:	00 
   38e9d:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
   38ea2:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
   38ea7:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   38eac:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
   38eb1:	4d 85 ff             	test   %r15,%r15
   38eb4:	74 7c                	je     38f32 <oriole_expat::dispatch+0x50b2>
   38eb6:	49 6b df 78          	imul   $0x78,%r15,%rbx
   38eba:	4c 01 eb             	add    %r13,%rbx
   38ebd:	41 bc 01 00 00 00    	mov    $0x1,%r12d
   38ec3:	48 8d 2d 46 cc 06 00 	lea    0x6cc46(%rip),%rbp        # a5b10 <<oriole_storage::string::String>::try_push>
   38eca:	4c 8d 3d e7 9f 0a 00 	lea    0xa9fe7(%rip),%r15        # e2eb8 <oriole_expat::FEATURES+0x120>
   38ed1:	4c 89 ef             	mov    %r13,%rdi
   38ed4:	31 f6                	xor    %esi,%esi
   38ed6:	ff d5                	call   *%rbp
   38ed8:	3c ff                	cmp    $0xff,%al
   38eda:	0f 85 74 05 00 00    	jne    39454 <oriole_expat::dispatch+0x55d4>
   38ee0:	49 83 c5 38          	add    $0x38,%r13
   38ee4:	4c 89 ef             	mov    %r13,%rdi
   38ee7:	31 f6                	xor    %esi,%esi
   38ee9:	ff d5                	call   *%rbp
   38eeb:	3c ff                	cmp    $0xff,%al
   38eed:	0f 85 61 05 00 00    	jne    39454 <oriole_expat::dispatch+0x55d4>
   38ef3:	49 8d 7c 24 ff       	lea    -0x1(%r12),%rdi
   38ef8:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   38efd:	48 39 cf             	cmp    %rcx,%rdi
   38f00:	0f 83 b0 0a 00 00    	jae    399b6 <oriole_expat::dispatch+0x5b36>
   38f06:	49 8b 45 e8          	mov    -0x18(%r13),%rax
   38f0a:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   38f0f:	4a 89 44 e2 f8       	mov    %rax,-0x8(%rdx,%r12,8)
   38f14:	49 39 cc             	cmp    %rcx,%r12
   38f17:	0f 83 a2 0a 00 00    	jae    399bf <oriole_expat::dispatch+0x5b3f>
   38f1d:	49 8b 45 20          	mov    0x20(%r13),%rax
   38f21:	4a 89 04 e2          	mov    %rax,(%rdx,%r12,8)
   38f25:	49 83 c4 02          	add    $0x2,%r12
   38f29:	49 83 c5 40          	add    $0x40,%r13
   38f2d:	49 39 dd             	cmp    %rbx,%r13
   38f30:	75 9f                	jne    38ed1 <oriole_expat::dispatch+0x5051>
   38f32:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   38f39:	00 
   38f3a:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   38f3f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   38f44:	ff 94 24 60 04 00 00 	call   *0x460(%rsp)
   38f4b:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   38f50:	48 85 c9             	test   %rcx,%rcx
   38f53:	74 1c                	je     38f71 <oriole_expat::dispatch+0x50f1>
   38f55:	48 c1 e1 03          	shl    $0x3,%rcx
   38f59:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   38f60:	00 
   38f61:	ba 08 00 00 00       	mov    $0x8,%edx
   38f66:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   38f6b:	ff 15 07 db 0a 00    	call   *0xadb07(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38f71:	b3 01                	mov    $0x1,%bl
   38f73:	e9 49 e8 ff ff       	jmp    377c1 <oriole_expat::dispatch+0x3941>
   38f78:	45 31 c0             	xor    %r8d,%r8d
   38f7b:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   38f80:	4c 89 ee             	mov    %r13,%rsi
   38f83:	4c 89 fa             	mov    %r15,%rdx
   38f86:	48 89 d9             	mov    %rbx,%rcx
   38f89:	41 ff d4             	call   *%r12
   38f8c:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   38f93:	00 
   38f94:	e8 f7 63 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38f99:	31 db                	xor    %ebx,%ebx
   38f9b:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   38fa2:	00 
   38fa3:	e8 e8 63 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38fa8:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   38faf:	00 
   38fb0:	48 85 c9             	test   %rcx,%rcx
   38fb3:	74 18                	je     38fcd <oriole_expat::dispatch+0x514d>
   38fb5:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   38fbc:	00 
   38fbd:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   38fc2:	ba 01 00 00 00       	mov    $0x1,%edx
   38fc7:	ff 15 ab da 0a 00    	call   *0xadaab(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   38fcd:	b3 01                	mov    $0x1,%bl
   38fcf:	b0 01                	mov    $0x1,%al
   38fd1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   38fd8:	00 
   38fd9:	b1 01                	mov    $0x1,%cl
   38fdb:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   38fdf:	b1 01                	mov    $0x1,%cl
   38fe1:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   38fe5:	b1 01                	mov    $0x1,%cl
   38fe7:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   38feb:	b1 01                	mov    $0x1,%cl
   38fed:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   38ff1:	b1 01                	mov    $0x1,%cl
   38ff3:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   38ff7:	b1 01                	mov    $0x1,%cl
   38ff9:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   38ffd:	b1 01                	mov    $0x1,%cl
   38fff:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   39003:	b1 01                	mov    $0x1,%cl
   39005:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   39009:	b1 01                	mov    $0x1,%cl
   3900b:	89 4c 24 20          	mov    %ecx,0x20(%rsp)
   3900f:	e9 f2 c7 ff ff       	jmp    35806 <oriole_expat::dispatch+0x1986>
   39014:	49 89 df             	mov    %rbx,%r15
   39017:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   3901e:	00 
   3901f:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   39026:	00 
   39027:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   3902e:	00 
   3902f:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   39036:	00 
   39037:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   3903c:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   39041:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   39046:	40 88 6c 24 68       	mov    %bpl,0x68(%rsp)
   3904b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3904f:	0f 84 89 04 00 00    	je     394de <oriole_expat::dispatch+0x565e>
   39055:	48 8b 9c 24 80 00 00 	mov    0x80(%rsp),%rbx
   3905c:	00 
   3905d:	e9 7e 04 00 00       	jmp    394e0 <oriole_expat::dispatch+0x5660>
   39062:	31 db                	xor    %ebx,%ebx
   39064:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3906b:	00 
   3906c:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
   39073:	00 
   39074:	e8 b7 9d ff ff       	call   32e30 <oriole_expat::optional_cstring>
   39079:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   39080:	00 
   39081:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   39088:	00 
   39089:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   3908d:	0f 85 38 02 00 00    	jne    392cb <oriole_expat::dispatch+0x544b>
   39093:	41 89 ce             	mov    %ecx,%r14d
   39096:	31 db                	xor    %ebx,%ebx
   39098:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3909f:	00 
   390a0:	e8 eb 62 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   390a5:	89 5c 24 30          	mov    %ebx,0x30(%rsp)
   390a9:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   390b0:	00 
   390b1:	31 db                	xor    %ebx,%ebx
   390b3:	48 85 c9             	test   %rcx,%rcx
   390b6:	74 13                	je     390cb <oriole_expat::dispatch+0x524b>
   390b8:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   390bd:	ba 01 00 00 00       	mov    $0x1,%edx
   390c2:	4c 89 fe             	mov    %r15,%rsi
   390c5:	ff 15 ad d9 0a 00    	call   *0xad9ad(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   390cb:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   390d2:	00 
   390d3:	48 85 c9             	test   %rcx,%rcx
   390d6:	74 27                	je     390ff <oriole_expat::dispatch+0x527f>
   390d8:	b0 01                	mov    $0x1,%al
   390da:	89 44 24 38          	mov    %eax,0x38(%rsp)
   390de:	45 31 ff             	xor    %r15d,%r15d
   390e1:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   390e8:	00 
   390e9:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   390f0:	00 
   390f1:	ba 01 00 00 00       	mov    $0x1,%edx
   390f6:	41 b4 01             	mov    $0x1,%r12b
   390f9:	ff 15 79 d9 0a 00    	call   *0xad979(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   390ff:	41 b4 01             	mov    $0x1,%r12b
   39102:	44 8b 6c 24 30       	mov    0x30(%rsp),%r13d
   39107:	45 31 ff             	xor    %r15d,%r15d
   3910a:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   39111:	00 
   39112:	e8 79 62 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39117:	45 31 ff             	xor    %r15d,%r15d
   3911a:	45 84 ed             	test   %r13b,%r13b
   3911d:	74 0d                	je     3912c <oriole_expat::dispatch+0x52ac>
   3911f:	48 8d bc 24 a0 04 00 	lea    0x4a0(%rsp),%rdi
   39126:	00 
   39127:	e8 64 62 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3912c:	84 db                	test   %bl,%bl
   3912e:	74 0d                	je     3913d <oriole_expat::dispatch+0x52bd>
   39130:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
   39137:	00 
   39138:	e8 53 62 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3913d:	45 84 e4             	test   %r12b,%r12b
   39140:	74 0d                	je     3914f <oriole_expat::dispatch+0x52cf>
   39142:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
   39149:	00 
   3914a:	e8 41 62 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3914f:	45 84 ff             	test   %r15b,%r15b
   39152:	74 7f                	je     391d3 <oriole_expat::dispatch+0x5353>
   39154:	48 8b 8c 24 78 05 00 	mov    0x578(%rsp),%rcx
   3915b:	00 
   3915c:	48 85 c9             	test   %rcx,%rcx
   3915f:	74 72                	je     391d3 <oriole_expat::dispatch+0x5353>
   39161:	b0 01                	mov    $0x1,%al
   39163:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39167:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   3916e:	00 
   3916f:	48 8b b4 24 70 05 00 	mov    0x570(%rsp),%rsi
   39176:	00 
   39177:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
   3917e:	00 
   3917f:	ba 01 00 00 00       	mov    $0x1,%edx
   39184:	b0 01                	mov    $0x1,%al
   39186:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3918a:	b0 01                	mov    $0x1,%al
   3918c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39190:	b0 01                	mov    $0x1,%al
   39192:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39196:	b0 01                	mov    $0x1,%al
   39198:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3919c:	b0 01                	mov    $0x1,%al
   3919e:	89 44 24 10          	mov    %eax,0x10(%rsp)
   391a2:	b0 01                	mov    $0x1,%al
   391a4:	89 44 24 40          	mov    %eax,0x40(%rsp)
   391a8:	b0 01                	mov    $0x1,%al
   391aa:	89 44 24 08          	mov    %eax,0x8(%rsp)
   391ae:	b0 01                	mov    $0x1,%al
   391b0:	89 44 24 04          	mov    %eax,0x4(%rsp)
   391b4:	b0 01                	mov    $0x1,%al
   391b6:	89 44 24 24          	mov    %eax,0x24(%rsp)
   391ba:	b0 01                	mov    $0x1,%al
   391bc:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   391c1:	40 b5 01             	mov    $0x1,%bpl
   391c4:	41 b7 01             	mov    $0x1,%r15b
   391c7:	41 b4 01             	mov    $0x1,%r12b
   391ca:	41 b5 01             	mov    $0x1,%r13b
   391cd:	ff 15 a5 d8 0a 00    	call   *0xad8a5(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   391d3:	b0 01                	mov    $0x1,%al
   391d5:	89 44 24 48          	mov    %eax,0x48(%rsp)
   391d9:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   391e0:	00 
   391e1:	b0 01                	mov    $0x1,%al
   391e3:	89 44 24 28          	mov    %eax,0x28(%rsp)
   391e7:	b0 01                	mov    $0x1,%al
   391e9:	89 44 24 30          	mov    %eax,0x30(%rsp)
   391ed:	b0 01                	mov    $0x1,%al
   391ef:	89 44 24 38          	mov    %eax,0x38(%rsp)
   391f3:	b0 01                	mov    $0x1,%al
   391f5:	89 44 24 14          	mov    %eax,0x14(%rsp)
   391f9:	b0 01                	mov    $0x1,%al
   391fb:	89 44 24 10          	mov    %eax,0x10(%rsp)
   391ff:	b0 01                	mov    $0x1,%al
   39201:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39205:	b0 01                	mov    $0x1,%al
   39207:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3920b:	b0 01                	mov    $0x1,%al
   3920d:	89 44 24 04          	mov    %eax,0x4(%rsp)
   39211:	b0 01                	mov    $0x1,%al
   39213:	89 44 24 24          	mov    %eax,0x24(%rsp)
   39217:	b0 01                	mov    $0x1,%al
   39219:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3921e:	b0 01                	mov    $0x1,%al
   39220:	89 44 24 20          	mov    %eax,0x20(%rsp)
   39224:	b0 01                	mov    $0x1,%al
   39226:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3922a:	b0 01                	mov    $0x1,%al
   3922c:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   39230:	b0 01                	mov    $0x1,%al
   39232:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39236:	45 89 f7             	mov    %r14d,%r15d
   39239:	e9 88 f7 ff ff       	jmp    389c6 <oriole_expat::dispatch+0x4b46>
   3923e:	31 c9                	xor    %ecx,%ecx
   39240:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   39245:	4c 89 e6             	mov    %r12,%rsi
   39248:	4c 89 fa             	mov    %r15,%rdx
   3924b:	41 89 d8             	mov    %ebx,%r8d
   3924e:	ff 94 24 18 02 00 00 	call   *0x218(%rsp)
   39255:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3925c:	00 
   3925d:	e8 2e 61 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39262:	31 ed                	xor    %ebp,%ebp
   39264:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3926b:	00 
   3926c:	e8 1f 61 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39271:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   39278:	00 
   39279:	48 85 c9             	test   %rcx,%rcx
   3927c:	74 18                	je     39296 <oriole_expat::dispatch+0x5416>
   3927e:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   39285:	00 
   39286:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3928b:	ba 01 00 00 00       	mov    $0x1,%edx
   39290:	ff 15 e2 d7 0a 00    	call   *0xad7e2(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39296:	b3 01                	mov    $0x1,%bl
   39298:	b0 01                	mov    $0x1,%al
   3929a:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   392a1:	00 
   392a2:	b1 01                	mov    $0x1,%cl
   392a4:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   392a8:	b1 01                	mov    $0x1,%cl
   392aa:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   392ae:	b1 01                	mov    $0x1,%cl
   392b0:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   392b4:	b1 01                	mov    $0x1,%cl
   392b6:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   392ba:	b1 01                	mov    $0x1,%cl
   392bc:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   392c0:	b1 01                	mov    $0x1,%cl
   392c2:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   392c6:	e9 29 c5 ff ff       	jmp    357f4 <oriole_expat::dispatch+0x1974>
   392cb:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   392d2:	00 
   392d3:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   392da:	00 
   392db:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   392e2:	00 
   392e3:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   392ea:	00 
   392eb:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   392f2:	00 
   392f3:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   392fa:	00 
   392fb:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   39302:	00 
   39303:	88 8c 24 28 02 00 00 	mov    %cl,0x228(%rsp)
   3930a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3930e:	0f 84 06 02 00 00    	je     3951a <oriole_expat::dispatch+0x569a>
   39314:	4c 8b 84 24 40 02 00 	mov    0x240(%rsp),%r8
   3931b:	00 
   3931c:	e9 fc 01 00 00       	jmp    3951d <oriole_expat::dispatch+0x569d>
   39321:	45 31 c0             	xor    %r8d,%r8d
   39324:	4c 89 ef             	mov    %r13,%rdi
   39327:	4c 89 e6             	mov    %r12,%rsi
   3932a:	48 89 da             	mov    %rbx,%rdx
   3932d:	48 89 e9             	mov    %rbp,%rcx
   39330:	ff 94 24 90 04 00 00 	call   *0x490(%rsp)
   39337:	85 c0                	test   %eax,%eax
   39339:	0f 84 61 01 00 00    	je     394a0 <oriole_expat::dispatch+0x5620>
   3933f:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   39346:	00 
   39347:	e8 44 60 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3934c:	31 ed                	xor    %ebp,%ebp
   3934e:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39355:	00 
   39356:	e8 35 60 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3935b:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39360:	e8 2b 60 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39365:	b3 01                	mov    $0x1,%bl
   39367:	e9 7a dc ff ff       	jmp    36fe6 <oriole_expat::dispatch+0x3166>
   3936c:	45 31 c0             	xor    %r8d,%r8d
   3936f:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   39374:	4c 89 e6             	mov    %r12,%rsi
   39377:	48 89 ea             	mov    %rbp,%rdx
   3937a:	4c 89 e9             	mov    %r13,%rcx
   3937d:	41 89 d9             	mov    %ebx,%r9d
   39380:	ff d0                	call   *%rax
   39382:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   39389:	00 
   3938a:	e8 01 60 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3938f:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   39396:	00 
   39397:	48 85 c9             	test   %rcx,%rcx
   3939a:	74 1d                	je     393b9 <oriole_expat::dispatch+0x5539>
   3939c:	31 ed                	xor    %ebp,%ebp
   3939e:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   393a5:	00 
   393a6:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   393ad:	00 
   393ae:	ba 01 00 00 00       	mov    $0x1,%edx
   393b3:	ff 15 bf d6 0a 00    	call   *0xad6bf(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   393b9:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   393c0:	00 
   393c1:	48 85 c9             	test   %rcx,%rcx
   393c4:	74 1d                	je     393e3 <oriole_expat::dispatch+0x5563>
   393c6:	31 ed                	xor    %ebp,%ebp
   393c8:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   393cf:	00 
   393d0:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   393d5:	ba 01 00 00 00       	mov    $0x1,%edx
   393da:	45 31 ff             	xor    %r15d,%r15d
   393dd:	ff 15 95 d6 0a 00    	call   *0xad695(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   393e3:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   393ea:	00 
   393eb:	48 85 c9             	test   %rcx,%rcx
   393ee:	74 23                	je     39413 <oriole_expat::dispatch+0x5593>
   393f0:	31 ed                	xor    %ebp,%ebp
   393f2:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   393f9:	00 
   393fa:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39401:	00 
   39402:	ba 01 00 00 00       	mov    $0x1,%edx
   39407:	45 31 ff             	xor    %r15d,%r15d
   3940a:	45 31 ed             	xor    %r13d,%r13d
   3940d:	ff 15 65 d6 0a 00    	call   *0xad665(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39413:	b3 01                	mov    $0x1,%bl
   39415:	b0 01                	mov    $0x1,%al
   39417:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   3941e:	00 
   3941f:	b1 01                	mov    $0x1,%cl
   39421:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   39425:	b1 01                	mov    $0x1,%cl
   39427:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   3942b:	b1 01                	mov    $0x1,%cl
   3942d:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   39431:	b1 01                	mov    $0x1,%cl
   39433:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   39437:	b1 01                	mov    $0x1,%cl
   39439:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   3943d:	b1 01                	mov    $0x1,%cl
   3943f:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   39443:	b1 01                	mov    $0x1,%cl
   39445:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   39449:	b1 01                	mov    $0x1,%cl
   3944b:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   3944f:	e9 ac c3 ff ff       	jmp    35800 <oriole_expat::dispatch+0x1980>
   39454:	89 c3                	mov    %eax,%ebx
   39456:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   3945b:	48 85 c9             	test   %rcx,%rcx
   3945e:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   39463:	0f 84 9c 03 00 00    	je     39805 <oriole_expat::dispatch+0x5985>
   39469:	48 c1 e1 03          	shl    $0x3,%rcx
   3946d:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   39474:	00 
   39475:	ba 08 00 00 00       	mov    $0x8,%edx
   3947a:	ff 15 f8 d5 0a 00    	call   *0xad5f8(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39480:	89 d8                	mov    %ebx,%eax
   39482:	e9 84 03 00 00       	jmp    3980b <oriole_expat::dispatch+0x598b>
   39487:	48 8d 3d 9d 7d fd ff 	lea    -0x28263(%rip),%rdi        # 1122b <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x486f>
   3948e:	48 8d 15 f3 99 0a 00 	lea    0xa99f3(%rip),%rdx        # e2e88 <oriole_expat::FEATURES+0xf0>
   39495:	be 2a 00 00 00       	mov    $0x2a,%esi
   3949a:	ff 15 00 dc 0a 00    	call   *0xadc00(%rip)        # e70a0 <_GLOBAL_OFFSET_TABLE_+0x760>
   394a0:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   394a7:	00 
   394a8:	e8 e3 5e ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   394ad:	31 ed                	xor    %ebp,%ebp
   394af:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   394b6:	00 
   394b7:	e8 d4 5e ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   394bc:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   394c1:	e8 ca 5e ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   394c6:	48 b8 15 00 00 00 15 	movabs $0x1500000015,%rax
   394cd:	00 00 00 
   394d0:	49 89 86 10 0a 00 00 	mov    %rax,0xa10(%r14)
   394d7:	b3 01                	mov    $0x1,%bl
   394d9:	e9 08 db ff ff       	jmp    36fe6 <oriole_expat::dispatch+0x3166>
   394de:	31 db                	xor    %ebx,%ebx
   394e0:	41 b4 01             	mov    $0x1,%r12b
   394e3:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   394ea:	00 
   394eb:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
   394f2:	00 
   394f3:	e8 38 99 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   394f8:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   394ff:	00 
   39500:	0f b6 ac 24 48 03 00 	movzbl 0x348(%rsp),%ebp
   39507:	00 
   39508:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   3950c:	0f 85 97 01 00 00    	jne    396a9 <oriole_expat::dispatch+0x5829>
   39512:	41 b4 01             	mov    $0x1,%r12b
   39515:	e9 21 02 00 00       	jmp    3973b <oriole_expat::dispatch+0x58bb>
   3951a:	45 31 c0             	xor    %r8d,%r8d
   3951d:	4c 8b 8c 24 00 01 00 	mov    0x100(%rsp),%r9
   39524:	00 
   39525:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   3952a:	4c 89 fe             	mov    %r15,%rsi
   3952d:	4c 89 e2             	mov    %r12,%rdx
   39530:	48 89 d9             	mov    %rbx,%rcx
   39533:	41 ff d5             	call   *%r13
   39536:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3953d:	00 
   3953e:	e8 4d 5e ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39543:	31 db                	xor    %ebx,%ebx
   39545:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3954c:	00 
   3954d:	e8 3e 5e ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39552:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   39559:	00 
   3955a:	48 85 c9             	test   %rcx,%rcx
   3955d:	74 22                	je     39581 <oriole_expat::dispatch+0x5701>
   3955f:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   39566:	00 
   39567:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   3956e:	00 
   3956f:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39574:	ba 01 00 00 00       	mov    $0x1,%edx
   39579:	31 db                	xor    %ebx,%ebx
   3957b:	ff 15 f7 d4 0a 00    	call   *0xad4f7(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39581:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   39588:	00 
   39589:	48 85 c9             	test   %rcx,%rcx
   3958c:	74 31                	je     395bf <oriole_expat::dispatch+0x573f>
   3958e:	b0 01                	mov    $0x1,%al
   39590:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39594:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   3959b:	00 
   3959c:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   395a3:	00 
   395a4:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   395ab:	00 
   395ac:	ba 01 00 00 00       	mov    $0x1,%edx
   395b1:	31 db                	xor    %ebx,%ebx
   395b3:	41 b4 01             	mov    $0x1,%r12b
   395b6:	45 31 ff             	xor    %r15d,%r15d
   395b9:	ff 15 b9 d4 0a 00    	call   *0xad4b9(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   395bf:	41 b4 01             	mov    $0x1,%r12b
   395c2:	45 31 ed             	xor    %r13d,%r13d
   395c5:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   395cc:	00 
   395cd:	31 db                	xor    %ebx,%ebx
   395cf:	45 31 ff             	xor    %r15d,%r15d
   395d2:	e8 b9 5d ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   395d7:	b3 01                	mov    $0x1,%bl
   395d9:	45 31 e4             	xor    %r12d,%r12d
   395dc:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
   395e3:	00 
   395e4:	45 89 e7             	mov    %r12d,%r15d
   395e7:	e8 a4 5d ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   395ec:	40 84 ed             	test   %bpl,%bpl
   395ef:	74 7f                	je     39670 <oriole_expat::dispatch+0x57f0>
   395f1:	48 8b 8c 24 78 05 00 	mov    0x578(%rsp),%rcx
   395f8:	00 
   395f9:	48 85 c9             	test   %rcx,%rcx
   395fc:	74 72                	je     39670 <oriole_expat::dispatch+0x57f0>
   395fe:	b0 01                	mov    $0x1,%al
   39600:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39604:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   3960b:	00 
   3960c:	48 8b b4 24 70 05 00 	mov    0x570(%rsp),%rsi
   39613:	00 
   39614:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
   3961b:	00 
   3961c:	ba 01 00 00 00       	mov    $0x1,%edx
   39621:	b0 01                	mov    $0x1,%al
   39623:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39627:	b0 01                	mov    $0x1,%al
   39629:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3962d:	b0 01                	mov    $0x1,%al
   3962f:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39633:	b0 01                	mov    $0x1,%al
   39635:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39639:	b0 01                	mov    $0x1,%al
   3963b:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3963f:	b0 01                	mov    $0x1,%al
   39641:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39645:	b0 01                	mov    $0x1,%al
   39647:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3964b:	b0 01                	mov    $0x1,%al
   3964d:	89 44 24 04          	mov    %eax,0x4(%rsp)
   39651:	b0 01                	mov    $0x1,%al
   39653:	89 44 24 24          	mov    %eax,0x24(%rsp)
   39657:	b0 01                	mov    $0x1,%al
   39659:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3965e:	40 b5 01             	mov    $0x1,%bpl
   39661:	41 b7 01             	mov    $0x1,%r15b
   39664:	41 b4 01             	mov    $0x1,%r12b
   39667:	41 b5 01             	mov    $0x1,%r13b
   3966a:	ff 15 08 d4 0a 00    	call   *0xad408(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39670:	b0 01                	mov    $0x1,%al
   39672:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   39679:	00 
   3967a:	b1 01                	mov    $0x1,%cl
   3967c:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   39680:	b1 01                	mov    $0x1,%cl
   39682:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   39686:	b1 01                	mov    $0x1,%cl
   39688:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   3968c:	b1 01                	mov    $0x1,%cl
   3968e:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   39692:	b1 01                	mov    $0x1,%cl
   39694:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   39698:	b1 01                	mov    $0x1,%cl
   3969a:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   3969e:	b1 01                	mov    $0x1,%cl
   396a0:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   396a4:	e9 51 c1 ff ff       	jmp    357fa <oriole_expat::dispatch+0x197a>
   396a9:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   396b0:	00 
   396b1:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   396b8:	00 
   396b9:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   396c0:	00 
   396c1:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   396c8:	00 
   396c9:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   396d0:	00 
   396d1:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   396d8:	00 
   396d9:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   396e0:	00 
   396e1:	40 88 ac 24 a8 00 00 	mov    %bpl,0xa8(%rsp)
   396e8:	00 
   396e9:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   396ed:	74 0a                	je     396f9 <oriole_expat::dispatch+0x5879>
   396ef:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
   396f6:	00 
   396f7:	eb 03                	jmp    396fc <oriole_expat::dispatch+0x587c>
   396f9:	45 31 e4             	xor    %r12d,%r12d
   396fc:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   39703:	00 
   39704:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
   3970b:	00 
   3970c:	e8 1f 97 ff ff       	call   32e30 <oriole_expat::optional_cstring>
   39711:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   39718:	00 
   39719:	0f b6 ac 24 48 03 00 	movzbl 0x348(%rsp),%ebp
   39720:	00 
   39721:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   39725:	0f 85 83 00 00 00    	jne    397ae <oriole_expat::dispatch+0x592e>
   3972b:	45 31 e4             	xor    %r12d,%r12d
   3972e:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39735:	00 
   39736:	e8 55 5c ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3973b:	45 31 ff             	xor    %r15d,%r15d
   3973e:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39743:	e8 48 5c ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39748:	41 89 ee             	mov    %ebp,%r14d
   3974b:	31 db                	xor    %ebx,%ebx
   3974d:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39754:	00 
   39755:	e8 36 5c ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3975a:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   3975f:	44 89 7c 24 30       	mov    %r15d,0x30(%rsp)
   39764:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   3976b:	00 
   3976c:	48 85 c9             	test   %rcx,%rcx
   3976f:	44 89 64 24 38       	mov    %r12d,0x38(%rsp)
   39774:	74 1b                	je     39791 <oriole_expat::dispatch+0x5911>
   39776:	31 db                	xor    %ebx,%ebx
   39778:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   3977f:	00 
   39780:	ba 01 00 00 00       	mov    $0x1,%edx
   39785:	45 31 e4             	xor    %r12d,%r12d
   39788:	45 31 ff             	xor    %r15d,%r15d
   3978b:	ff 15 e7 d2 0a 00    	call   *0xad2e7(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39791:	31 db                	xor    %ebx,%ebx
   39793:	41 bc 00 00 00 00    	mov    $0x0,%r12d
   39799:	80 7c 24 38 00       	cmpb   $0x0,0x38(%rsp)
   3979e:	44 8b 6c 24 30       	mov    0x30(%rsp),%r13d
   397a3:	0f 85 5e f9 ff ff    	jne    39107 <oriole_expat::dispatch+0x5287>
   397a9:	e9 69 f9 ff ff       	jmp    39117 <oriole_expat::dispatch+0x5297>
   397ae:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   397b5:	00 
   397b6:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   397bd:	00 
   397be:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   397c5:	00 
   397c6:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   397cd:	00 
   397ce:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   397d5:	00 
   397d6:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   397dd:	00 
   397de:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   397e5:	00 
   397e6:	40 88 ac 24 28 02 00 	mov    %bpl,0x228(%rsp)
   397ed:	00 
   397ee:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   397f2:	0f 84 09 01 00 00    	je     39901 <oriole_expat::dispatch+0x5a81>
   397f8:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
   397ff:	00 
   39800:	e9 fe 00 00 00       	jmp    39903 <oriole_expat::dispatch+0x5a83>
   39805:	89 d8                	mov    %ebx,%eax
   39807:	eb 02                	jmp    3980b <oriole_expat::dispatch+0x598b>
   39809:	31 c0                	xor    %eax,%eax
   3980b:	89 c3                	mov    %eax,%ebx
   3980d:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39814:	00 
   39815:	e8 96 68 ff ff       	call   300b0 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3981a:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   39821:	00 
   39822:	48 85 c9             	test   %rcx,%rcx
   39825:	74 6f                	je     39896 <oriole_expat::dispatch+0x5a16>
   39827:	b0 01                	mov    $0x1,%al
   39829:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3982d:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   39834:	00 
   39835:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3983a:	ba 01 00 00 00       	mov    $0x1,%edx
   3983f:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   39846:	00 
   39847:	b0 01                	mov    $0x1,%al
   39849:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3984d:	b0 01                	mov    $0x1,%al
   3984f:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39853:	b0 01                	mov    $0x1,%al
   39855:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39859:	b0 01                	mov    $0x1,%al
   3985b:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3985f:	b0 01                	mov    $0x1,%al
   39861:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39865:	b0 01                	mov    $0x1,%al
   39867:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3986b:	b0 01                	mov    $0x1,%al
   3986d:	89 44 24 04          	mov    %eax,0x4(%rsp)
   39871:	b0 01                	mov    $0x1,%al
   39873:	89 44 24 24          	mov    %eax,0x24(%rsp)
   39877:	b0 01                	mov    $0x1,%al
   39879:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3987e:	b0 01                	mov    $0x1,%al
   39880:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   39884:	40 b5 01             	mov    $0x1,%bpl
   39887:	41 b7 01             	mov    $0x1,%r15b
   3988a:	41 b4 01             	mov    $0x1,%r12b
   3988d:	41 b5 01             	mov    $0x1,%r13b
   39890:	ff 15 e2 d1 0a 00    	call   *0xad1e2(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39896:	b0 01                	mov    $0x1,%al
   39898:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3989c:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   398a3:	00 
   398a4:	b0 01                	mov    $0x1,%al
   398a6:	89 44 24 30          	mov    %eax,0x30(%rsp)
   398aa:	b0 01                	mov    $0x1,%al
   398ac:	89 44 24 38          	mov    %eax,0x38(%rsp)
   398b0:	b0 01                	mov    $0x1,%al
   398b2:	89 44 24 14          	mov    %eax,0x14(%rsp)
   398b6:	b0 01                	mov    $0x1,%al
   398b8:	89 44 24 10          	mov    %eax,0x10(%rsp)
   398bc:	b0 01                	mov    $0x1,%al
   398be:	89 44 24 40          	mov    %eax,0x40(%rsp)
   398c2:	b0 01                	mov    $0x1,%al
   398c4:	89 44 24 08          	mov    %eax,0x8(%rsp)
   398c8:	b0 01                	mov    $0x1,%al
   398ca:	89 44 24 04          	mov    %eax,0x4(%rsp)
   398ce:	b0 01                	mov    $0x1,%al
   398d0:	89 44 24 24          	mov    %eax,0x24(%rsp)
   398d4:	b0 01                	mov    $0x1,%al
   398d6:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   398db:	b0 01                	mov    $0x1,%al
   398dd:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   398e1:	b0 01                	mov    $0x1,%al
   398e3:	89 44 24 20          	mov    %eax,0x20(%rsp)
   398e7:	b0 01                	mov    $0x1,%al
   398e9:	89 44 24 18          	mov    %eax,0x18(%rsp)
   398ed:	b0 01                	mov    $0x1,%al
   398ef:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   398f3:	b0 01                	mov    $0x1,%al
   398f5:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   398f9:	41 89 df             	mov    %ebx,%r15d
   398fc:	e9 c5 f0 ff ff       	jmp    389c6 <oriole_expat::dispatch+0x4b46>
   39901:	31 c0                	xor    %eax,%eax
   39903:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   39908:	44 8b 44 24 30       	mov    0x30(%rsp),%r8d
   3990d:	48 83 ec 08          	sub    $0x8,%rsp
   39911:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   39916:	44 89 ea             	mov    %r13d,%edx
   39919:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   3991e:	4d 89 f9             	mov    %r15,%r9
   39921:	50                   	push   %rax
   39922:	41 54                	push   %r12
   39924:	53                   	push   %rbx
   39925:	ff 54 24 60          	call   *0x60(%rsp)
   39929:	48 83 c4 20          	add    $0x20,%rsp
   3992d:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   39934:	00 
   39935:	e8 56 5a ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3993a:	45 31 e4             	xor    %r12d,%r12d
   3993d:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39944:	00 
   39945:	e8 46 5a ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3994a:	45 31 e4             	xor    %r12d,%r12d
   3994d:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39952:	45 31 ff             	xor    %r15d,%r15d
   39955:	e8 36 5a ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3995a:	45 31 e4             	xor    %r12d,%r12d
   3995d:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39964:	00 
   39965:	45 31 ff             	xor    %r15d,%r15d
   39968:	31 db                	xor    %ebx,%ebx
   3996a:	e8 21 5a ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3996f:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   39976:	00 
   39977:	48 85 c9             	test   %rcx,%rcx
   3997a:	74 33                	je     399af <oriole_expat::dispatch+0x5b2f>
   3997c:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   39983:	00 
   39984:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   3998b:	00 
   3998c:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   39993:	00 
   39994:	ba 01 00 00 00       	mov    $0x1,%edx
   39999:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   399a0:	00 
   399a1:	31 db                	xor    %ebx,%ebx
   399a3:	45 31 e4             	xor    %r12d,%r12d
   399a6:	45 31 ff             	xor    %r15d,%r15d
   399a9:	ff 15 c9 d0 0a 00    	call   *0xad0c9(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   399af:	b3 01                	mov    $0x1,%bl
   399b1:	e9 ba fc ff ff       	jmp    39670 <oriole_expat::dispatch+0x57f0>
   399b6:	4c 8d 3d e3 94 0a 00 	lea    0xa94e3(%rip),%r15        # e2ea0 <oriole_expat::FEATURES+0x108>
   399bd:	eb 03                	jmp    399c2 <oriole_expat::dispatch+0x5b42>
   399bf:	4c 89 e7             	mov    %r12,%rdi
   399c2:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
   399c7:	4c 89 fa             	mov    %r15,%rdx
   399ca:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
   399cf:	4c 8b 6c 24 48       	mov    0x48(%rsp),%r13
   399d4:	ff 15 16 d6 0a 00    	call   *0xad616(%rip)        # e6ff0 <_GLOBAL_OFFSET_TABLE_+0x6b0>
   399da:	0f 0b                	ud2
   399dc:	49 89 c6             	mov    %rax,%r14
   399df:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   399e6:	00 
   399e7:	e8 a4 59 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   399ec:	31 ed                	xor    %ebp,%ebp
   399ee:	eb 06                	jmp    399f6 <oriole_expat::dispatch+0x5b76>
   399f0:	44 89 e5             	mov    %r12d,%ebp
   399f3:	49 89 c6             	mov    %rax,%r14
   399f6:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   399fb:	e8 90 59 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39a00:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   39a07:	00 
   39a08:	eb 3d                	jmp    39a47 <oriole_expat::dispatch+0x5bc7>
   39a0a:	49 89 c6             	mov    %rax,%r14
   39a0d:	e9 8d 0b 00 00       	jmp    3a59f <oriole_expat::dispatch+0x671f>
   39a12:	49 89 c6             	mov    %rax,%r14
   39a15:	b0 01                	mov    $0x1,%al
   39a17:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39a1b:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   39a22:	00 
   39a23:	b0 01                	mov    $0x1,%al
   39a25:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39a29:	b0 01                	mov    $0x1,%al
   39a2b:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39a2f:	e9 c7 09 00 00       	jmp    3a3fb <oriole_expat::dispatch+0x657b>
   39a34:	49 89 c6             	mov    %rax,%r14
   39a37:	e9 d2 0d 00 00       	jmp    3a80e <oriole_expat::dispatch+0x698e>
   39a3c:	44 89 e5             	mov    %r12d,%ebp
   39a3f:	44 89 7c 24 30       	mov    %r15d,0x30(%rsp)
   39a44:	49 89 c6             	mov    %rax,%r14
   39a47:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39a4e:	00 
   39a4f:	e8 3c 59 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39a54:	31 db                	xor    %ebx,%ebx
   39a56:	e9 46 02 00 00       	jmp    39ca1 <oriole_expat::dispatch+0x5e21>
   39a5b:	49 89 c6             	mov    %rax,%r14
   39a5e:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39a65:	00 
   39a66:	e8 25 59 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39a6b:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   39a72:	00 
   39a73:	e9 c4 01 00 00       	jmp    39c3c <oriole_expat::dispatch+0x5dbc>
   39a78:	49 89 c6             	mov    %rax,%r14
   39a7b:	b0 01                	mov    $0x1,%al
   39a7d:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39a81:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   39a88:	00 
   39a89:	e9 d0 07 00 00       	jmp    3a25e <oriole_expat::dispatch+0x63de>
   39a8e:	49 89 c6             	mov    %rax,%r14
   39a91:	b0 01                	mov    $0x1,%al
   39a93:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39a97:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   39a9e:	00 
   39a9f:	b0 01                	mov    $0x1,%al
   39aa1:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39aa5:	b0 01                	mov    $0x1,%al
   39aa7:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39aab:	b0 01                	mov    $0x1,%al
   39aad:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39ab1:	e9 ea 0d 00 00       	jmp    3a8a0 <oriole_expat::dispatch+0x6a20>
   39ab6:	e9 19 02 00 00       	jmp    39cd4 <oriole_expat::dispatch+0x5e54>
   39abb:	49 89 c6             	mov    %rax,%r14
   39abe:	e9 92 08 00 00       	jmp    3a355 <oriole_expat::dispatch+0x64d5>
   39ac3:	eb 51                	jmp    39b16 <oriole_expat::dispatch+0x5c96>
   39ac5:	49 89 c6             	mov    %rax,%r14
   39ac8:	e9 ca 03 00 00       	jmp    39e97 <oriole_expat::dispatch+0x6017>
   39acd:	49 89 c6             	mov    %rax,%r14
   39ad0:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   39ad7:	00 
   39ad8:	48 85 c9             	test   %rcx,%rcx
   39adb:	74 1b                	je     39af8 <oriole_expat::dispatch+0x5c78>
   39add:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   39ae4:	00 
   39ae5:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39aec:	00 
   39aed:	ba 01 00 00 00       	mov    $0x1,%edx
   39af2:	ff 15 80 cf 0a 00    	call   *0xacf80(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39af8:	31 ed                	xor    %ebp,%ebp
   39afa:	e9 3e 02 00 00       	jmp    39d3d <oriole_expat::dispatch+0x5ebd>
   39aff:	49 89 c6             	mov    %rax,%r14
   39b02:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39b09:	00 
   39b0a:	e8 81 58 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39b0f:	31 ed                	xor    %ebp,%ebp
   39b11:	e9 bc 03 00 00       	jmp    39ed2 <oriole_expat::dispatch+0x6052>
   39b16:	49 89 c6             	mov    %rax,%r14
   39b19:	e9 e8 08 00 00       	jmp    3a406 <oriole_expat::dispatch+0x6586>
   39b1e:	49 89 c6             	mov    %rax,%r14
   39b21:	b0 01                	mov    $0x1,%al
   39b23:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39b27:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   39b2e:	00 
   39b2f:	b0 01                	mov    $0x1,%al
   39b31:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39b35:	b0 01                	mov    $0x1,%al
   39b37:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39b3b:	b0 01                	mov    $0x1,%al
   39b3d:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39b41:	b0 01                	mov    $0x1,%al
   39b43:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39b47:	b0 01                	mov    $0x1,%al
   39b49:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39b4d:	b0 01                	mov    $0x1,%al
   39b4f:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39b53:	e9 e8 0c 00 00       	jmp    3a840 <oriole_expat::dispatch+0x69c0>
   39b58:	49 89 c6             	mov    %rax,%r14
   39b5b:	e9 f2 09 00 00       	jmp    3a552 <oriole_expat::dispatch+0x66d2>
   39b60:	49 89 c6             	mov    %rax,%r14
   39b63:	e9 e8 06 00 00       	jmp    3a250 <oriole_expat::dispatch+0x63d0>
   39b68:	49 89 c6             	mov    %rax,%r14
   39b6b:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   39b72:	00 
   39b73:	e8 18 58 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39b78:	e9 1a 03 00 00       	jmp    39e97 <oriole_expat::dispatch+0x6017>
   39b7d:	49 89 c6             	mov    %rax,%r14
   39b80:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   39b87:	00 
   39b88:	b0 01                	mov    $0x1,%al
   39b8a:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39b8e:	48 85 c9             	test   %rcx,%rcx
   39b91:	0f 84 15 07 00 00    	je     3a2ac <oriole_expat::dispatch+0x642c>
   39b97:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   39b9e:	00 
   39b9f:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   39ba6:	00 
   39ba7:	ba 01 00 00 00       	mov    $0x1,%edx
   39bac:	ff 15 c6 ce 0a 00    	call   *0xacec6(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39bb2:	e9 f5 06 00 00       	jmp    3a2ac <oriole_expat::dispatch+0x642c>
   39bb7:	49 89 c6             	mov    %rax,%r14
   39bba:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   39bc1:	00 
   39bc2:	b0 01                	mov    $0x1,%al
   39bc4:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39bc8:	48 85 c9             	test   %rcx,%rcx
   39bcb:	0f 84 2d 0a 00 00    	je     3a5fe <oriole_expat::dispatch+0x677e>
   39bd1:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   39bd8:	00 
   39bd9:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39be0:	00 
   39be1:	ba 01 00 00 00       	mov    $0x1,%edx
   39be6:	ff 15 8c ce 0a 00    	call   *0xace8c(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39bec:	e9 0d 0a 00 00       	jmp    3a5fe <oriole_expat::dispatch+0x677e>
   39bf1:	49 89 c6             	mov    %rax,%r14
   39bf4:	b0 01                	mov    $0x1,%al
   39bf6:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39bfa:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   39c01:	00 
   39c02:	b0 01                	mov    $0x1,%al
   39c04:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39c08:	b0 01                	mov    $0x1,%al
   39c0a:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39c0e:	e9 5b 05 00 00       	jmp    3a16e <oriole_expat::dispatch+0x62ee>
   39c13:	49 89 c6             	mov    %rax,%r14
   39c16:	b0 01                	mov    $0x1,%al
   39c18:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39c1c:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   39c23:	00 
   39c24:	b0 01                	mov    $0x1,%al
   39c26:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39c2a:	b0 01                	mov    $0x1,%al
   39c2c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39c30:	e9 0b 0e 00 00       	jmp    3aa40 <oriole_expat::dispatch+0x6bc0>
   39c35:	89 5c 24 30          	mov    %ebx,0x30(%rsp)
   39c39:	49 89 c6             	mov    %rax,%r14
   39c3c:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   39c43:	00 
   39c44:	48 85 c9             	test   %rcx,%rcx
   39c47:	74 18                	je     39c61 <oriole_expat::dispatch+0x5de1>
   39c49:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   39c50:	00 
   39c51:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39c56:	ba 01 00 00 00       	mov    $0x1,%edx
   39c5b:	ff 15 17 ce 0a 00    	call   *0xace17(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39c61:	31 db                	xor    %ebx,%ebx
   39c63:	e9 ef 01 00 00       	jmp    39e57 <oriole_expat::dispatch+0x5fd7>
   39c68:	49 89 c6             	mov    %rax,%r14
   39c6b:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39c72:	00 
   39c73:	e8 18 57 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39c78:	31 ed                	xor    %ebp,%ebp
   39c7a:	e9 7c 03 00 00       	jmp    39ffb <oriole_expat::dispatch+0x617b>
   39c7f:	49 89 c6             	mov    %rax,%r14
   39c82:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39c89:	00 
   39c8a:	e8 01 57 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39c8f:	31 db                	xor    %ebx,%ebx
   39c91:	e9 fe 03 00 00       	jmp    3a094 <oriole_expat::dispatch+0x6214>
   39c96:	44 89 e5             	mov    %r12d,%ebp
   39c99:	44 89 7c 24 30       	mov    %r15d,0x30(%rsp)
   39c9e:	49 89 c6             	mov    %rax,%r14
   39ca1:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   39ca8:	00 
   39ca9:	48 85 c9             	test   %rcx,%rcx
   39cac:	74 1b                	je     39cc9 <oriole_expat::dispatch+0x5e49>
   39cae:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   39cb5:	00 
   39cb6:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   39cbd:	00 
   39cbe:	ba 01 00 00 00       	mov    $0x1,%edx
   39cc3:	ff 15 af cd 0a 00    	call   *0xacdaf(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39cc9:	45 31 e4             	xor    %r12d,%r12d
   39ccc:	45 31 ff             	xor    %r15d,%r15d
   39ccf:	e9 7f 0c 00 00       	jmp    3a953 <oriole_expat::dispatch+0x6ad3>
   39cd4:	49 89 c6             	mov    %rax,%r14
   39cd7:	e9 cc 07 00 00       	jmp    3a4a8 <oriole_expat::dispatch+0x6628>
   39cdc:	49 89 c6             	mov    %rax,%r14
   39cdf:	b0 01                	mov    $0x1,%al
   39ce1:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39ce5:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   39cec:	00 
   39ced:	b0 01                	mov    $0x1,%al
   39cef:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39cf3:	b0 01                	mov    $0x1,%al
   39cf5:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39cf9:	b0 01                	mov    $0x1,%al
   39cfb:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39cff:	b0 01                	mov    $0x1,%al
   39d01:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39d05:	b0 01                	mov    $0x1,%al
   39d07:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39d0b:	e9 1c 05 00 00       	jmp    3a22c <oriole_expat::dispatch+0x63ac>
   39d10:	49 89 c6             	mov    %rax,%r14
   39d13:	b0 01                	mov    $0x1,%al
   39d15:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39d19:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   39d20:	00 
   39d21:	b0 01                	mov    $0x1,%al
   39d23:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39d27:	b0 01                	mov    $0x1,%al
   39d29:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39d2d:	e9 aa 04 00 00       	jmp    3a1dc <oriole_expat::dispatch+0x635c>
   39d32:	49 89 c6             	mov    %rax,%r14
   39d35:	e9 c6 04 00 00       	jmp    3a200 <oriole_expat::dispatch+0x6380>
   39d3a:	49 89 c6             	mov    %rax,%r14
   39d3d:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   39d44:	00 
   39d45:	48 85 c9             	test   %rcx,%rcx
   39d48:	74 18                	je     39d62 <oriole_expat::dispatch+0x5ee2>
   39d4a:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   39d51:	00 
   39d52:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39d57:	ba 01 00 00 00       	mov    $0x1,%edx
   39d5c:	ff 15 16 cd 0a 00    	call   *0xacd16(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39d62:	45 31 ff             	xor    %r15d,%r15d
   39d65:	e9 17 02 00 00       	jmp    39f81 <oriole_expat::dispatch+0x6101>
   39d6a:	e9 c9 0d 00 00       	jmp    3ab38 <oriole_expat::dispatch+0x6cb8>
   39d6f:	49 89 c6             	mov    %rax,%r14
   39d72:	e9 42 06 00 00       	jmp    3a3b9 <oriole_expat::dispatch+0x6539>
   39d77:	49 89 c6             	mov    %rax,%r14
   39d7a:	e9 89 05 00 00       	jmp    3a308 <oriole_expat::dispatch+0x6488>
   39d7f:	49 89 c6             	mov    %rax,%r14
   39d82:	e9 e3 06 00 00       	jmp    3a46a <oriole_expat::dispatch+0x65ea>
   39d87:	49 89 c6             	mov    %rax,%r14
   39d8a:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39d91:	00 
   39d92:	e8 f9 55 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39d97:	e9 64 04 00 00       	jmp    3a200 <oriole_expat::dispatch+0x6380>
   39d9c:	49 89 c6             	mov    %rax,%r14
   39d9f:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   39da6:	00 
   39da7:	b0 01                	mov    $0x1,%al
   39da9:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39dad:	48 85 c9             	test   %rcx,%rcx
   39db0:	0f 84 a4 03 00 00    	je     3a15a <oriole_expat::dispatch+0x62da>
   39db6:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   39dbd:	00 
   39dbe:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39dc5:	00 
   39dc6:	ba 01 00 00 00       	mov    $0x1,%edx
   39dcb:	ff 15 a7 cc 0a 00    	call   *0xacca7(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39dd1:	e9 84 03 00 00       	jmp    3a15a <oriole_expat::dispatch+0x62da>
   39dd6:	49 89 c6             	mov    %rax,%r14
   39dd9:	b0 01                	mov    $0x1,%al
   39ddb:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39ddf:	c7 44 24 1c 00 00 00 	movl   $0x0,0x1c(%rsp)
   39de6:	00 
   39de7:	b0 01                	mov    $0x1,%al
   39de9:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39ded:	b0 01                	mov    $0x1,%al
   39def:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39df3:	b0 01                	mov    $0x1,%al
   39df5:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39df9:	e9 1a 08 00 00       	jmp    3a618 <oriole_expat::dispatch+0x6798>
   39dfe:	49 89 c6             	mov    %rax,%r14
   39e01:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   39e08:	00 
   39e09:	48 85 c9             	test   %rcx,%rcx
   39e0c:	0f 84 c1 07 00 00    	je     3a5d3 <oriole_expat::dispatch+0x6753>
   39e12:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   39e19:	00 
   39e1a:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39e21:	00 
   39e22:	ba 01 00 00 00       	mov    $0x1,%edx
   39e27:	ff 15 4b cc 0a 00    	call   *0xacc4b(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39e2d:	e9 a1 07 00 00       	jmp    3a5d3 <oriole_expat::dispatch+0x6753>
   39e32:	49 89 c6             	mov    %rax,%r14
   39e35:	b0 01                	mov    $0x1,%al
   39e37:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39e3b:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   39e42:	00 
   39e43:	b0 01                	mov    $0x1,%al
   39e45:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39e49:	b0 01                	mov    $0x1,%al
   39e4b:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39e4f:	e9 ed 0a 00 00       	jmp    3a941 <oriole_expat::dispatch+0x6ac1>
   39e54:	49 89 c6             	mov    %rax,%r14
   39e57:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   39e5e:	00 
   39e5f:	41 b4 01             	mov    $0x1,%r12b
   39e62:	48 85 c9             	test   %rcx,%rcx
   39e65:	74 1b                	je     39e82 <oriole_expat::dispatch+0x6002>
   39e67:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   39e6e:	00 
   39e6f:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39e76:	00 
   39e77:	ba 01 00 00 00       	mov    $0x1,%edx
   39e7c:	ff 15 f6 cb 0a 00    	call   *0xacbf6(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39e82:	45 31 ff             	xor    %r15d,%r15d
   39e85:	e9 ce 0a 00 00       	jmp    3a958 <oriole_expat::dispatch+0x6ad8>
   39e8a:	49 89 c6             	mov    %rax,%r14
   39e8d:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39e92:	e8 f9 54 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39e97:	b0 01                	mov    $0x1,%al
   39e99:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39e9d:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   39ea4:	00 
   39ea5:	b0 01                	mov    $0x1,%al
   39ea7:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39eab:	b0 01                	mov    $0x1,%al
   39ead:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39eb1:	b0 01                	mov    $0x1,%al
   39eb3:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39eb7:	b0 01                	mov    $0x1,%al
   39eb9:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39ebd:	e9 26 03 00 00       	jmp    3a1e8 <oriole_expat::dispatch+0x6368>
   39ec2:	e9 27 08 00 00       	jmp    3a6ee <oriole_expat::dispatch+0x686e>
   39ec7:	49 89 c6             	mov    %rax,%r14
   39eca:	e9 4b 06 00 00       	jmp    3a51a <oriole_expat::dispatch+0x669a>
   39ecf:	49 89 c6             	mov    %rax,%r14
   39ed2:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39ed7:	e8 b4 54 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39edc:	b0 01                	mov    $0x1,%al
   39ede:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39ee2:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   39ee9:	00 
   39eea:	b0 01                	mov    $0x1,%al
   39eec:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39ef0:	b0 01                	mov    $0x1,%al
   39ef2:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39ef6:	b0 01                	mov    $0x1,%al
   39ef8:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39efc:	b0 01                	mov    $0x1,%al
   39efe:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39f02:	b0 01                	mov    $0x1,%al
   39f04:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39f08:	b0 01                	mov    $0x1,%al
   39f0a:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39f0e:	b0 01                	mov    $0x1,%al
   39f10:	89 44 24 04          	mov    %eax,0x4(%rsp)
   39f14:	b0 01                	mov    $0x1,%al
   39f16:	89 44 24 24          	mov    %eax,0x24(%rsp)
   39f1a:	b0 01                	mov    $0x1,%al
   39f1c:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   39f21:	b0 01                	mov    $0x1,%al
   39f23:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   39f27:	b0 01                	mov    $0x1,%al
   39f29:	89 44 24 20          	mov    %eax,0x20(%rsp)
   39f2d:	b0 01                	mov    $0x1,%al
   39f2f:	89 44 24 18          	mov    %eax,0x18(%rsp)
   39f33:	b0 01                	mov    $0x1,%al
   39f35:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   39f39:	b0 01                	mov    $0x1,%al
   39f3b:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39f3f:	40 84 ed             	test   %bpl,%bpl
   39f42:	0f 85 f6 04 00 00    	jne    3a43e <oriole_expat::dispatch+0x65be>
   39f48:	e9 2c 0c 00 00       	jmp    3ab79 <oriole_expat::dispatch+0x6cf9>
   39f4d:	49 89 c6             	mov    %rax,%r14
   39f50:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39f57:	00 
   39f58:	e8 33 54 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39f5d:	e9 9e 02 00 00       	jmp    3a200 <oriole_expat::dispatch+0x6380>
   39f62:	49 89 c6             	mov    %rax,%r14
   39f65:	b0 01                	mov    $0x1,%al
   39f67:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39f6b:	b0 01                	mov    $0x1,%al
   39f6d:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39f71:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   39f78:	00 
   39f79:	e9 3c 03 00 00       	jmp    3a2ba <oriole_expat::dispatch+0x643a>
   39f7e:	49 89 c6             	mov    %rax,%r14
   39f81:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   39f88:	00 
   39f89:	48 85 c9             	test   %rcx,%rcx
   39f8c:	74 1b                	je     39fa9 <oriole_expat::dispatch+0x6129>
   39f8e:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   39f95:	00 
   39f96:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39f9d:	00 
   39f9e:	ba 01 00 00 00       	mov    $0x1,%edx
   39fa3:	ff 15 cf ca 0a 00    	call   *0xacacf(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39fa9:	45 31 ed             	xor    %r13d,%r13d
   39fac:	e9 2a 05 00 00       	jmp    3a4db <oriole_expat::dispatch+0x665b>
   39fb1:	49 89 c6             	mov    %rax,%r14
   39fb4:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   39fbb:	00 
   39fbc:	b0 01                	mov    $0x1,%al
   39fbe:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39fc2:	48 85 c9             	test   %rcx,%rcx
   39fc5:	0f 84 e1 02 00 00    	je     3a2ac <oriole_expat::dispatch+0x642c>
   39fcb:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   39fd2:	00 
   39fd3:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39fd8:	ba 01 00 00 00       	mov    $0x1,%edx
   39fdd:	ff 15 95 ca 0a 00    	call   *0xaca95(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   39fe3:	e9 c4 02 00 00       	jmp    3a2ac <oriole_expat::dispatch+0x642c>
   39fe8:	49 89 c6             	mov    %rax,%r14
   39feb:	e9 9a 09 00 00       	jmp    3a98a <oriole_expat::dispatch+0x6b0a>
   39ff0:	49 89 c6             	mov    %rax,%r14
   39ff3:	e9 0a 09 00 00       	jmp    3a902 <oriole_expat::dispatch+0x6a82>
   39ff8:	49 89 c6             	mov    %rax,%r14
   39ffb:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   3a002:	00 
   3a003:	48 85 c9             	test   %rcx,%rcx
   3a006:	74 18                	je     3a020 <oriole_expat::dispatch+0x61a0>
   3a008:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   3a00f:	00 
   3a010:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3a015:	ba 01 00 00 00       	mov    $0x1,%edx
   3a01a:	ff 15 58 ca 0a 00    	call   *0xaca58(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a020:	b0 01                	mov    $0x1,%al
   3a022:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a026:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   3a02d:	00 
   3a02e:	b0 01                	mov    $0x1,%al
   3a030:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a034:	b0 01                	mov    $0x1,%al
   3a036:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a03a:	b0 01                	mov    $0x1,%al
   3a03c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a040:	b0 01                	mov    $0x1,%al
   3a042:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a046:	b0 01                	mov    $0x1,%al
   3a048:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a04c:	b0 01                	mov    $0x1,%al
   3a04e:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a052:	b0 01                	mov    $0x1,%al
   3a054:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a058:	b0 01                	mov    $0x1,%al
   3a05a:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a05e:	b0 01                	mov    $0x1,%al
   3a060:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3a065:	b0 01                	mov    $0x1,%al
   3a067:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a06b:	b0 01                	mov    $0x1,%al
   3a06d:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3a071:	b0 01                	mov    $0x1,%al
   3a073:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3a077:	b0 01                	mov    $0x1,%al
   3a079:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3a07d:	b0 01                	mov    $0x1,%al
   3a07f:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a083:	40 84 ed             	test   %bpl,%bpl
   3a086:	0f 85 01 03 00 00    	jne    3a38d <oriole_expat::dispatch+0x650d>
   3a08c:	e9 e8 0a 00 00       	jmp    3ab79 <oriole_expat::dispatch+0x6cf9>
   3a091:	49 89 c6             	mov    %rax,%r14
   3a094:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   3a09b:	00 
   3a09c:	48 85 c9             	test   %rcx,%rcx
   3a09f:	74 18                	je     3a0b9 <oriole_expat::dispatch+0x6239>
   3a0a1:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   3a0a8:	00 
   3a0a9:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3a0ae:	ba 01 00 00 00       	mov    $0x1,%edx
   3a0b3:	ff 15 bf c9 0a 00    	call   *0xac9bf(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a0b9:	b0 01                	mov    $0x1,%al
   3a0bb:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a0bf:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3a0c6:	00 
   3a0c7:	b0 01                	mov    $0x1,%al
   3a0c9:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a0cd:	b0 01                	mov    $0x1,%al
   3a0cf:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a0d3:	b0 01                	mov    $0x1,%al
   3a0d5:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a0d9:	b0 01                	mov    $0x1,%al
   3a0db:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a0df:	b0 01                	mov    $0x1,%al
   3a0e1:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a0e5:	b0 01                	mov    $0x1,%al
   3a0e7:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a0eb:	b0 01                	mov    $0x1,%al
   3a0ed:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a0f1:	b0 01                	mov    $0x1,%al
   3a0f3:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a0f7:	b0 01                	mov    $0x1,%al
   3a0f9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a0fd:	b0 01                	mov    $0x1,%al
   3a0ff:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3a104:	b0 01                	mov    $0x1,%al
   3a106:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a10a:	b0 01                	mov    $0x1,%al
   3a10c:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3a110:	b0 01                	mov    $0x1,%al
   3a112:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3a116:	b0 01                	mov    $0x1,%al
   3a118:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a11c:	84 db                	test   %bl,%bl
   3a11e:	0f 85 b8 01 00 00    	jne    3a2dc <oriole_expat::dispatch+0x645c>
   3a124:	e9 50 0a 00 00       	jmp    3ab79 <oriole_expat::dispatch+0x6cf9>
   3a129:	49 89 c6             	mov    %rax,%r14
   3a12c:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   3a133:	00 
   3a134:	b0 01                	mov    $0x1,%al
   3a136:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a13a:	48 85 c9             	test   %rcx,%rcx
   3a13d:	74 1b                	je     3a15a <oriole_expat::dispatch+0x62da>
   3a13f:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   3a146:	00 
   3a147:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3a14e:	00 
   3a14f:	ba 01 00 00 00       	mov    $0x1,%edx
   3a154:	ff 15 1e c9 0a 00    	call   *0xac91e(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a15a:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   3a161:	00 
   3a162:	b0 01                	mov    $0x1,%al
   3a164:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a168:	b0 01                	mov    $0x1,%al
   3a16a:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a16e:	b0 01                	mov    $0x1,%al
   3a170:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a174:	b0 01                	mov    $0x1,%al
   3a176:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a17a:	e9 cd 08 00 00       	jmp    3aa4c <oriole_expat::dispatch+0x6bcc>
   3a17f:	49 89 c6             	mov    %rax,%r14
   3a182:	e9 1a 02 00 00       	jmp    3a3a1 <oriole_expat::dispatch+0x6521>
   3a187:	49 89 c6             	mov    %rax,%r14
   3a18a:	e9 61 01 00 00       	jmp    3a2f0 <oriole_expat::dispatch+0x6470>
   3a18f:	49 89 c6             	mov    %rax,%r14
   3a192:	e9 05 08 00 00       	jmp    3a99c <oriole_expat::dispatch+0x6b1c>
   3a197:	49 89 c6             	mov    %rax,%r14
   3a19a:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   3a1a1:	00 
   3a1a2:	b0 01                	mov    $0x1,%al
   3a1a4:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a1a8:	48 85 c9             	test   %rcx,%rcx
   3a1ab:	74 1b                	je     3a1c8 <oriole_expat::dispatch+0x6348>
   3a1ad:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   3a1b4:	00 
   3a1b5:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3a1bc:	00 
   3a1bd:	ba 01 00 00 00       	mov    $0x1,%edx
   3a1c2:	ff 15 b0 c8 0a 00    	call   *0xac8b0(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a1c8:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   3a1cf:	00 
   3a1d0:	b0 01                	mov    $0x1,%al
   3a1d2:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a1d6:	b0 01                	mov    $0x1,%al
   3a1d8:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a1dc:	b0 01                	mov    $0x1,%al
   3a1de:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a1e2:	b0 01                	mov    $0x1,%al
   3a1e4:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a1e8:	b0 01                	mov    $0x1,%al
   3a1ea:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a1ee:	e9 5f 08 00 00       	jmp    3aa52 <oriole_expat::dispatch+0x6bd2>
   3a1f3:	49 89 c6             	mov    %rax,%r14
   3a1f6:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3a1fb:	e8 90 51 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a200:	b0 01                	mov    $0x1,%al
   3a202:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a206:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   3a20d:	00 
   3a20e:	b0 01                	mov    $0x1,%al
   3a210:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a214:	b0 01                	mov    $0x1,%al
   3a216:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a21a:	b0 01                	mov    $0x1,%al
   3a21c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a220:	b0 01                	mov    $0x1,%al
   3a222:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a226:	b0 01                	mov    $0x1,%al
   3a228:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a22c:	b0 01                	mov    $0x1,%al
   3a22e:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a232:	b0 01                	mov    $0x1,%al
   3a234:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a238:	b0 01                	mov    $0x1,%al
   3a23a:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a23e:	e9 21 08 00 00       	jmp    3aa64 <oriole_expat::dispatch+0x6be4>
   3a243:	49 89 c6             	mov    %rax,%r14
   3a246:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3a24b:	e8 40 51 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a250:	b0 01                	mov    $0x1,%al
   3a252:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a256:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   3a25d:	00 
   3a25e:	b0 01                	mov    $0x1,%al
   3a260:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a264:	b0 01                	mov    $0x1,%al
   3a266:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a26a:	b0 01                	mov    $0x1,%al
   3a26c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a270:	b0 01                	mov    $0x1,%al
   3a272:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a276:	e9 d1 07 00 00       	jmp    3aa4c <oriole_expat::dispatch+0x6bcc>
   3a27b:	49 89 c6             	mov    %rax,%r14
   3a27e:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   3a285:	00 
   3a286:	b0 01                	mov    $0x1,%al
   3a288:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a28c:	48 85 c9             	test   %rcx,%rcx
   3a28f:	74 1b                	je     3a2ac <oriole_expat::dispatch+0x642c>
   3a291:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   3a298:	00 
   3a299:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3a2a0:	00 
   3a2a1:	ba 01 00 00 00       	mov    $0x1,%edx
   3a2a6:	ff 15 cc c7 0a 00    	call   *0xac7cc(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a2ac:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   3a2b3:	00 
   3a2b4:	b0 01                	mov    $0x1,%al
   3a2b6:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a2ba:	b0 01                	mov    $0x1,%al
   3a2bc:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a2c0:	e9 7b 07 00 00       	jmp    3aa40 <oriole_expat::dispatch+0x6bc0>
   3a2c5:	49 89 c6             	mov    %rax,%r14
   3a2c8:	e9 85 01 00 00       	jmp    3a452 <oriole_expat::dispatch+0x65d2>
   3a2cd:	49 89 c6             	mov    %rax,%r14
   3a2d0:	e9 a4 06 00 00       	jmp    3a979 <oriole_expat::dispatch+0x6af9>
   3a2d5:	89 5c 24 18          	mov    %ebx,0x18(%rsp)
   3a2d9:	49 89 c6             	mov    %rax,%r14
   3a2dc:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3a2e3:	00 
   3a2e4:	e8 a7 50 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a2e9:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
   3a2ee:	74 65                	je     3a355 <oriole_expat::dispatch+0x64d5>
   3a2f0:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   3a2f7:	00 
   3a2f8:	e8 93 50 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a2fd:	48 83 bc 24 98 04 00 	cmpq   $0x0,0x498(%rsp)
   3a304:	00 00 
   3a306:	75 4d                	jne    3a355 <oriole_expat::dispatch+0x64d5>
   3a308:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   3a30f:	00 
   3a310:	b0 01                	mov    $0x1,%al
   3a312:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a316:	48 85 c9             	test   %rcx,%rcx
   3a319:	74 1b                	je     3a336 <oriole_expat::dispatch+0x64b6>
   3a31b:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   3a322:	00 
   3a323:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   3a32a:	00 
   3a32b:	ba 01 00 00 00       	mov    $0x1,%edx
   3a330:	ff 15 42 c7 0a 00    	call   *0xac742(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a336:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3a33d:	00 
   3a33e:	b0 01                	mov    $0x1,%al
   3a340:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a344:	b0 01                	mov    $0x1,%al
   3a346:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a34a:	b0 01                	mov    $0x1,%al
   3a34c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a350:	e9 d9 04 00 00       	jmp    3a82e <oriole_expat::dispatch+0x69ae>
   3a355:	b0 01                	mov    $0x1,%al
   3a357:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a35b:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3a362:	00 
   3a363:	b0 01                	mov    $0x1,%al
   3a365:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a369:	b0 01                	mov    $0x1,%al
   3a36b:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a36f:	b0 01                	mov    $0x1,%al
   3a371:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a375:	b0 01                	mov    $0x1,%al
   3a377:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a37b:	b0 01                	mov    $0x1,%al
   3a37d:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a381:	e9 b4 04 00 00       	jmp    3a83a <oriole_expat::dispatch+0x69ba>
   3a386:	89 6c 24 04          	mov    %ebp,0x4(%rsp)
   3a38a:	49 89 c6             	mov    %rax,%r14
   3a38d:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3a394:	00 
   3a395:	e8 f6 4f ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a39a:	80 7c 24 04 00       	cmpb   $0x0,0x4(%rsp)
   3a39f:	74 65                	je     3a406 <oriole_expat::dispatch+0x6586>
   3a3a1:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   3a3a8:	00 
   3a3a9:	e8 e2 4f ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a3ae:	48 83 bc 24 18 02 00 	cmpq   $0x0,0x218(%rsp)
   3a3b5:	00 00 
   3a3b7:	75 4d                	jne    3a406 <oriole_expat::dispatch+0x6586>
   3a3b9:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   3a3c0:	00 
   3a3c1:	b0 01                	mov    $0x1,%al
   3a3c3:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a3c7:	48 85 c9             	test   %rcx,%rcx
   3a3ca:	74 1b                	je     3a3e7 <oriole_expat::dispatch+0x6567>
   3a3cc:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   3a3d3:	00 
   3a3d4:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   3a3db:	00 
   3a3dc:	ba 01 00 00 00       	mov    $0x1,%edx
   3a3e1:	ff 15 91 c6 0a 00    	call   *0xac691(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a3e7:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   3a3ee:	00 
   3a3ef:	b0 01                	mov    $0x1,%al
   3a3f1:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a3f5:	b0 01                	mov    $0x1,%al
   3a3f7:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a3fb:	b0 01                	mov    $0x1,%al
   3a3fd:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a401:	e9 9a 03 00 00       	jmp    3a7a0 <oriole_expat::dispatch+0x6920>
   3a406:	b0 01                	mov    $0x1,%al
   3a408:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a40c:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   3a413:	00 
   3a414:	b0 01                	mov    $0x1,%al
   3a416:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a41a:	b0 01                	mov    $0x1,%al
   3a41c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a420:	b0 01                	mov    $0x1,%al
   3a422:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a426:	b0 01                	mov    $0x1,%al
   3a428:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a42c:	b0 01                	mov    $0x1,%al
   3a42e:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a432:	e9 75 03 00 00       	jmp    3a7ac <oriole_expat::dispatch+0x692c>
   3a437:	89 5c 24 08          	mov    %ebx,0x8(%rsp)
   3a43b:	49 89 c6             	mov    %rax,%r14
   3a43e:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3a445:	00 
   3a446:	e8 45 4f ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a44b:	80 7c 24 08 00       	cmpb   $0x0,0x8(%rsp)
   3a450:	74 56                	je     3a4a8 <oriole_expat::dispatch+0x6628>
   3a452:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   3a459:	00 
   3a45a:	e8 31 4f ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a45f:	48 83 bc 24 90 04 00 	cmpq   $0x0,0x490(%rsp)
   3a466:	00 00 
   3a468:	75 3e                	jne    3a4a8 <oriole_expat::dispatch+0x6628>
   3a46a:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   3a471:	00 
   3a472:	e8 19 4f ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a477:	b0 01                	mov    $0x1,%al
   3a479:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a47d:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   3a484:	00 
   3a485:	b0 01                	mov    $0x1,%al
   3a487:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a48b:	b0 01                	mov    $0x1,%al
   3a48d:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a491:	b0 01                	mov    $0x1,%al
   3a493:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a497:	b0 01                	mov    $0x1,%al
   3a499:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a49d:	b0 01                	mov    $0x1,%al
   3a49f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a4a3:	e9 04 04 00 00       	jmp    3a8ac <oriole_expat::dispatch+0x6a2c>
   3a4a8:	b0 01                	mov    $0x1,%al
   3a4aa:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a4ae:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   3a4b5:	00 
   3a4b6:	b0 01                	mov    $0x1,%al
   3a4b8:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a4bc:	b0 01                	mov    $0x1,%al
   3a4be:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a4c2:	b0 01                	mov    $0x1,%al
   3a4c4:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a4c8:	b0 01                	mov    $0x1,%al
   3a4ca:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a4ce:	e9 d3 03 00 00       	jmp    3a8a6 <oriole_expat::dispatch+0x6a26>
   3a4d3:	49 89 c6             	mov    %rax,%r14
   3a4d6:	eb 15                	jmp    3a4ed <oriole_expat::dispatch+0x666d>
   3a4d8:	49 89 c6             	mov    %rax,%r14
   3a4db:	40 84 ed             	test   %bpl,%bpl
   3a4de:	74 0d                	je     3a4ed <oriole_expat::dispatch+0x666d>
   3a4e0:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   3a4e7:	00 
   3a4e8:	e8 a3 4e ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a4ed:	45 84 ff             	test   %r15b,%r15b
   3a4f0:	74 28                	je     3a51a <oriole_expat::dispatch+0x669a>
   3a4f2:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   3a4f9:	00 
   3a4fa:	48 85 c9             	test   %rcx,%rcx
   3a4fd:	74 1b                	je     3a51a <oriole_expat::dispatch+0x669a>
   3a4ff:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   3a506:	00 
   3a507:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   3a50e:	00 
   3a50f:	ba 01 00 00 00       	mov    $0x1,%edx
   3a514:	ff 15 5e c5 0a 00    	call   *0xac55e(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a51a:	45 84 ed             	test   %r13b,%r13b
   3a51d:	74 28                	je     3a547 <oriole_expat::dispatch+0x66c7>
   3a51f:	48 8b 8c 24 c8 04 00 	mov    0x4c8(%rsp),%rcx
   3a526:	00 
   3a527:	48 85 c9             	test   %rcx,%rcx
   3a52a:	74 1b                	je     3a547 <oriole_expat::dispatch+0x66c7>
   3a52c:	48 8b b4 24 c0 04 00 	mov    0x4c0(%rsp),%rsi
   3a533:	00 
   3a534:	48 8d bc 24 a0 04 00 	lea    0x4a0(%rsp),%rdi
   3a53b:	00 
   3a53c:	ba 01 00 00 00       	mov    $0x1,%edx
   3a541:	ff 15 31 c5 0a 00    	call   *0xac531(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a547:	48 83 bc 24 78 04 00 	cmpq   $0x0,0x478(%rsp)
   3a54e:	00 00 
   3a550:	75 4d                	jne    3a59f <oriole_expat::dispatch+0x671f>
   3a552:	48 8b 8c 24 08 05 00 	mov    0x508(%rsp),%rcx
   3a559:	00 
   3a55a:	b0 01                	mov    $0x1,%al
   3a55c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a560:	48 85 c9             	test   %rcx,%rcx
   3a563:	74 1b                	je     3a580 <oriole_expat::dispatch+0x6700>
   3a565:	48 8b b4 24 00 05 00 	mov    0x500(%rsp),%rsi
   3a56c:	00 
   3a56d:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
   3a574:	00 
   3a575:	ba 01 00 00 00       	mov    $0x1,%edx
   3a57a:	ff 15 f8 c4 0a 00    	call   *0xac4f8(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a580:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   3a587:	00 
   3a588:	b0 01                	mov    $0x1,%al
   3a58a:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a58e:	b0 01                	mov    $0x1,%al
   3a590:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a594:	b0 01                	mov    $0x1,%al
   3a596:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a59a:	e9 95 01 00 00       	jmp    3a734 <oriole_expat::dispatch+0x68b4>
   3a59f:	b0 01                	mov    $0x1,%al
   3a5a1:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a5a5:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   3a5ac:	00 
   3a5ad:	b0 01                	mov    $0x1,%al
   3a5af:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a5b3:	b0 01                	mov    $0x1,%al
   3a5b5:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a5b9:	b0 01                	mov    $0x1,%al
   3a5bb:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a5bf:	b0 01                	mov    $0x1,%al
   3a5c1:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a5c5:	b0 01                	mov    $0x1,%al
   3a5c7:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a5cb:	e9 70 01 00 00       	jmp    3a740 <oriole_expat::dispatch+0x68c0>
   3a5d0:	49 89 c6             	mov    %rax,%r14
   3a5d3:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   3a5da:	00 
   3a5db:	b0 01                	mov    $0x1,%al
   3a5dd:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a5e1:	48 85 c9             	test   %rcx,%rcx
   3a5e4:	74 18                	je     3a5fe <oriole_expat::dispatch+0x677e>
   3a5e6:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   3a5ed:	00 
   3a5ee:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3a5f3:	ba 01 00 00 00       	mov    $0x1,%edx
   3a5f8:	ff 15 7a c4 0a 00    	call   *0xac47a(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a5fe:	c7 44 24 1c 00 00 00 	movl   $0x0,0x1c(%rsp)
   3a605:	00 
   3a606:	b0 01                	mov    $0x1,%al
   3a608:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a60c:	b0 01                	mov    $0x1,%al
   3a60e:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a612:	b0 01                	mov    $0x1,%al
   3a614:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a618:	b0 01                	mov    $0x1,%al
   3a61a:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a61e:	b0 01                	mov    $0x1,%al
   3a620:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a624:	b0 01                	mov    $0x1,%al
   3a626:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a62a:	b0 01                	mov    $0x1,%al
   3a62c:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a630:	b0 01                	mov    $0x1,%al
   3a632:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a636:	b0 01                	mov    $0x1,%al
   3a638:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a63c:	b0 01                	mov    $0x1,%al
   3a63e:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3a643:	b0 01                	mov    $0x1,%al
   3a645:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a649:	b0 01                	mov    $0x1,%al
   3a64b:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3a64f:	b0 01                	mov    $0x1,%al
   3a651:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3a655:	e9 29 04 00 00       	jmp    3aa83 <oriole_expat::dispatch+0x6c03>
   3a65a:	49 89 c6             	mov    %rax,%r14
   3a65d:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   3a664:	00 
   3a665:	e8 26 4d ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a66a:	e9 06 08 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3a66f:	49 89 c6             	mov    %rax,%r14
   3a672:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3a679:	00 
   3a67a:	48 85 c9             	test   %rcx,%rcx
   3a67d:	0f 84 f2 07 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3a683:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   3a68a:	00 
   3a68b:	ba 01 00 00 00       	mov    $0x1,%edx
   3a690:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3a697:	00 
   3a698:	ff 15 da c3 0a 00    	call   *0xac3da(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a69e:	e9 d2 07 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3a6a3:	49 89 c6             	mov    %rax,%r14
   3a6a6:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   3a6ad:	00 
   3a6ae:	b0 01                	mov    $0x1,%al
   3a6b0:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a6b4:	48 85 c9             	test   %rcx,%rcx
   3a6b7:	74 1b                	je     3a6d4 <oriole_expat::dispatch+0x6854>
   3a6b9:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
   3a6c0:	00 
   3a6c1:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3a6c8:	00 
   3a6c9:	ba 01 00 00 00       	mov    $0x1,%edx
   3a6ce:	ff 15 a4 c3 0a 00    	call   *0xac3a4(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a6d4:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   3a6db:	00 
   3a6dc:	e9 54 02 00 00       	jmp    3a935 <oriole_expat::dispatch+0x6ab5>
   3a6e1:	44 89 6c 24 30       	mov    %r13d,0x30(%rsp)
   3a6e6:	49 89 c6             	mov    %rax,%r14
   3a6e9:	e9 77 02 00 00       	jmp    3a965 <oriole_expat::dispatch+0x6ae5>
   3a6ee:	49 89 c6             	mov    %rax,%r14
   3a6f1:	b0 01                	mov    $0x1,%al
   3a6f3:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a6f7:	e9 52 04 00 00       	jmp    3ab4e <oriole_expat::dispatch+0x6cce>
   3a6fc:	49 89 c6             	mov    %rax,%r14
   3a6ff:	e9 f1 01 00 00       	jmp    3a8f5 <oriole_expat::dispatch+0x6a75>
   3a704:	49 89 c6             	mov    %rax,%r14
   3a707:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3a70e:	00 
   3a70f:	e8 4c 65 ff ff       	call   30c60 <core::ptr::drop_glue::<oriole::AttributeDeclaration>>
   3a714:	b0 01                	mov    $0x1,%al
   3a716:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a71a:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   3a721:	00 
   3a722:	b0 01                	mov    $0x1,%al
   3a724:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a728:	b0 01                	mov    $0x1,%al
   3a72a:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a72e:	b0 01                	mov    $0x1,%al
   3a730:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a734:	b0 01                	mov    $0x1,%al
   3a736:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a73a:	b0 01                	mov    $0x1,%al
   3a73c:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a740:	b0 01                	mov    $0x1,%al
   3a742:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a746:	b0 01                	mov    $0x1,%al
   3a748:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a74c:	b0 01                	mov    $0x1,%al
   3a74e:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a752:	b0 01                	mov    $0x1,%al
   3a754:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a758:	b0 01                	mov    $0x1,%al
   3a75a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3a75f:	b0 01                	mov    $0x1,%al
   3a761:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a765:	e9 0d 03 00 00       	jmp    3aa77 <oriole_expat::dispatch+0x6bf7>
   3a76a:	ff 15 50 c9 0a 00    	call   *0xac950(%rip)        # e70c0 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a770:	49 89 c6             	mov    %rax,%r14
   3a773:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3a77a:	00 
   3a77b:	e8 80 63 ff ff       	call   30b00 <core::ptr::drop_glue::<oriole::DoctypeDeclaration>>
   3a780:	b0 01                	mov    $0x1,%al
   3a782:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a786:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   3a78d:	00 
   3a78e:	b0 01                	mov    $0x1,%al
   3a790:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a794:	b0 01                	mov    $0x1,%al
   3a796:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a79a:	b0 01                	mov    $0x1,%al
   3a79c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a7a0:	b0 01                	mov    $0x1,%al
   3a7a2:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a7a6:	b0 01                	mov    $0x1,%al
   3a7a8:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a7ac:	b0 01                	mov    $0x1,%al
   3a7ae:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a7b2:	b0 01                	mov    $0x1,%al
   3a7b4:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a7b8:	e9 a1 02 00 00       	jmp    3aa5e <oriole_expat::dispatch+0x6bde>
   3a7bd:	ff 15 fd c8 0a 00    	call   *0xac8fd(%rip)        # e70c0 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a7c3:	49 89 c6             	mov    %rax,%r14
   3a7c6:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3a7cd:	00 
   3a7ce:	e8 fd 61 ff ff       	call   309d0 <core::ptr::drop_glue::<oriole::EntityDeclaration>>
   3a7d3:	b0 01                	mov    $0x1,%al
   3a7d5:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a7d9:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   3a7e0:	00 
   3a7e1:	b0 01                	mov    $0x1,%al
   3a7e3:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a7e7:	b0 01                	mov    $0x1,%al
   3a7e9:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a7ed:	b0 01                	mov    $0x1,%al
   3a7ef:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a7f3:	e9 f1 01 00 00       	jmp    3a9e9 <oriole_expat::dispatch+0x6b69>
   3a7f8:	ff 15 c2 c8 0a 00    	call   *0xac8c2(%rip)        # e70c0 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a7fe:	49 89 c6             	mov    %rax,%r14
   3a801:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3a808:	00 
   3a809:	e8 a2 63 ff ff       	call   30bb0 <core::ptr::drop_glue::<oriole::NotationDeclaration>>
   3a80e:	b0 01                	mov    $0x1,%al
   3a810:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a814:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3a81b:	00 
   3a81c:	b0 01                	mov    $0x1,%al
   3a81e:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a822:	b0 01                	mov    $0x1,%al
   3a824:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a828:	b0 01                	mov    $0x1,%al
   3a82a:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a82e:	b0 01                	mov    $0x1,%al
   3a830:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a834:	b0 01                	mov    $0x1,%al
   3a836:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a83a:	b0 01                	mov    $0x1,%al
   3a83c:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a840:	b0 01                	mov    $0x1,%al
   3a842:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a846:	b0 01                	mov    $0x1,%al
   3a848:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a84c:	b0 01                	mov    $0x1,%al
   3a84e:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a852:	b0 01                	mov    $0x1,%al
   3a854:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3a859:	b0 01                	mov    $0x1,%al
   3a85b:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a85f:	b0 01                	mov    $0x1,%al
   3a861:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3a865:	e9 13 02 00 00       	jmp    3aa7d <oriole_expat::dispatch+0x6bfd>
   3a86a:	ff 15 50 c8 0a 00    	call   *0xac850(%rip)        # e70c0 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a870:	49 89 c6             	mov    %rax,%r14
   3a873:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3a87a:	00 
   3a87b:	e8 f0 64 ff ff       	call   30d70 <core::ptr::drop_glue::<oriole::ExternalEntityReference>>
   3a880:	b0 01                	mov    $0x1,%al
   3a882:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a886:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   3a88d:	00 
   3a88e:	b0 01                	mov    $0x1,%al
   3a890:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a894:	b0 01                	mov    $0x1,%al
   3a896:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a89a:	b0 01                	mov    $0x1,%al
   3a89c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a8a0:	b0 01                	mov    $0x1,%al
   3a8a2:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a8a6:	b0 01                	mov    $0x1,%al
   3a8a8:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a8ac:	b0 01                	mov    $0x1,%al
   3a8ae:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a8b2:	e9 a1 01 00 00       	jmp    3aa58 <oriole_expat::dispatch+0x6bd8>
   3a8b7:	ff 15 03 c8 0a 00    	call   *0xac803(%rip)        # e70c0 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a8bd:	4c 89 6c 24 48       	mov    %r13,0x48(%rsp)
   3a8c2:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
   3a8c7:	eb 00                	jmp    3a8c9 <oriole_expat::dispatch+0x6a49>
   3a8c9:	49 89 c6             	mov    %rax,%r14
   3a8cc:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
   3a8d2:	74 21                	je     3a8f5 <oriole_expat::dispatch+0x6a75>
   3a8d4:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   3a8d9:	48 c1 e1 03          	shl    $0x3,%rcx
   3a8dd:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3a8e4:	00 
   3a8e5:	ba 08 00 00 00       	mov    $0x8,%edx
   3a8ea:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   3a8ef:	ff 15 83 c1 0a 00    	call   *0xac183(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a8f5:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3a8fc:	00 
   3a8fd:	e8 ae 57 ff ff       	call   300b0 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3a902:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   3a909:	00 
   3a90a:	b0 01                	mov    $0x1,%al
   3a90c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a910:	48 85 c9             	test   %rcx,%rcx
   3a913:	74 18                	je     3a92d <oriole_expat::dispatch+0x6aad>
   3a915:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   3a91c:	00 
   3a91d:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3a922:	ba 01 00 00 00       	mov    $0x1,%edx
   3a927:	ff 15 4b c1 0a 00    	call   *0xac14b(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a92d:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   3a934:	00 
   3a935:	b0 01                	mov    $0x1,%al
   3a937:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a93b:	b0 01                	mov    $0x1,%al
   3a93d:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a941:	b0 01                	mov    $0x1,%al
   3a943:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a947:	e9 fa 00 00 00       	jmp    3aa46 <oriole_expat::dispatch+0x6bc6>
   3a94c:	8b 6c 24 38          	mov    0x38(%rsp),%ebp
   3a950:	49 89 c6             	mov    %rax,%r14
   3a953:	40 84 ed             	test   %bpl,%bpl
   3a956:	74 0d                	je     3a965 <oriole_expat::dispatch+0x6ae5>
   3a958:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   3a95f:	00 
   3a960:	e8 2b 4a ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a965:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
   3a96a:	74 0d                	je     3a979 <oriole_expat::dispatch+0x6af9>
   3a96c:	48 8d bc 24 a0 04 00 	lea    0x4a0(%rsp),%rdi
   3a973:	00 
   3a974:	e8 17 4a ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a979:	84 db                	test   %bl,%bl
   3a97b:	74 0d                	je     3a98a <oriole_expat::dispatch+0x6b0a>
   3a97d:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
   3a984:	00 
   3a985:	e8 06 4a ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a98a:	45 84 e4             	test   %r12b,%r12b
   3a98d:	74 0d                	je     3a99c <oriole_expat::dispatch+0x6b1c>
   3a98f:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
   3a996:	00 
   3a997:	e8 f4 49 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a99c:	b0 01                	mov    $0x1,%al
   3a99e:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a9a2:	45 84 ff             	test   %r15b,%r15b
   3a9a5:	74 28                	je     3a9cf <oriole_expat::dispatch+0x6b4f>
   3a9a7:	48 8b 8c 24 78 05 00 	mov    0x578(%rsp),%rcx
   3a9ae:	00 
   3a9af:	48 85 c9             	test   %rcx,%rcx
   3a9b2:	74 1b                	je     3a9cf <oriole_expat::dispatch+0x6b4f>
   3a9b4:	48 8b b4 24 70 05 00 	mov    0x570(%rsp),%rsi
   3a9bb:	00 
   3a9bc:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
   3a9c3:	00 
   3a9c4:	ba 01 00 00 00       	mov    $0x1,%edx
   3a9c9:	ff 15 a9 c0 0a 00    	call   *0xac0a9(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a9cf:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   3a9d6:	00 
   3a9d7:	b0 01                	mov    $0x1,%al
   3a9d9:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a9dd:	b0 01                	mov    $0x1,%al
   3a9df:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a9e3:	b0 01                	mov    $0x1,%al
   3a9e5:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a9e9:	b0 01                	mov    $0x1,%al
   3a9eb:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a9ef:	b0 01                	mov    $0x1,%al
   3a9f1:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a9f5:	b0 01                	mov    $0x1,%al
   3a9f7:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a9fb:	b0 01                	mov    $0x1,%al
   3a9fd:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3aa01:	b0 01                	mov    $0x1,%al
   3aa03:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3aa07:	b0 01                	mov    $0x1,%al
   3aa09:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3aa0d:	b0 01                	mov    $0x1,%al
   3aa0f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3aa14:	eb 5b                	jmp    3aa71 <oriole_expat::dispatch+0x6bf1>
   3aa16:	49 89 c6             	mov    %rax,%r14
   3aa19:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3aa20:	00 
   3aa21:	e8 ba 78 ff ff       	call   322e0 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   3aa26:	b0 01                	mov    $0x1,%al
   3aa28:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3aa2c:	b0 01                	mov    $0x1,%al
   3aa2e:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3aa32:	b0 01                	mov    $0x1,%al
   3aa34:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3aa38:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   3aa3f:	00 
   3aa40:	b0 01                	mov    $0x1,%al
   3aa42:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3aa46:	b0 01                	mov    $0x1,%al
   3aa48:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3aa4c:	b0 01                	mov    $0x1,%al
   3aa4e:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3aa52:	b0 01                	mov    $0x1,%al
   3aa54:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3aa58:	b0 01                	mov    $0x1,%al
   3aa5a:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3aa5e:	b0 01                	mov    $0x1,%al
   3aa60:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3aa64:	b0 01                	mov    $0x1,%al
   3aa66:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3aa6b:	b0 01                	mov    $0x1,%al
   3aa6d:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3aa71:	b0 01                	mov    $0x1,%al
   3aa73:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3aa77:	b0 01                	mov    $0x1,%al
   3aa79:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3aa7d:	b0 01                	mov    $0x1,%al
   3aa7f:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3aa83:	b0 01                	mov    $0x1,%al
   3aa85:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3aa89:	e9 eb 00 00 00       	jmp    3ab79 <oriole_expat::dispatch+0x6cf9>
   3aa8e:	49 89 c6             	mov    %rax,%r14
   3aa91:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
   3aa98:	00 
   3aa99:	48 85 c9             	test   %rcx,%rcx
   3aa9c:	0f 84 d3 03 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3aaa2:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   3aaa9:	00 
   3aaaa:	48 8b b4 24 88 01 00 	mov    0x188(%rsp),%rsi
   3aab1:	00 
   3aab2:	ba 01 00 00 00       	mov    $0x1,%edx
   3aab7:	ff 15 bb bf 0a 00    	call   *0xabfbb(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3aabd:	e9 b3 03 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3aac2:	49 89 c6             	mov    %rax,%r14
   3aac5:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
   3aacc:	00 
   3aacd:	48 85 c9             	test   %rcx,%rcx
   3aad0:	0f 84 9f 03 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3aad6:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   3aadd:	00 
   3aade:	48 8b b4 24 88 01 00 	mov    0x188(%rsp),%rsi
   3aae5:	00 
   3aae6:	ba 01 00 00 00       	mov    $0x1,%edx
   3aaeb:	ff 15 87 bf 0a 00    	call   *0xabf87(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3aaf1:	e9 7f 03 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3aaf6:	49 89 c6             	mov    %rax,%r14
   3aaf9:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   3ab00:	00 
   3ab01:	e8 8a 48 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3ab06:	e9 6a 03 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3ab0b:	49 89 c6             	mov    %rax,%r14
   3ab0e:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   3ab15:	00 
   3ab16:	e8 95 55 ff ff       	call   300b0 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3ab1b:	e9 55 03 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3ab20:	44 89 6c 24 2c       	mov    %r13d,0x2c(%rsp)
   3ab25:	44 89 64 24 1c       	mov    %r12d,0x1c(%rsp)
   3ab2a:	44 89 7c 24 18       	mov    %r15d,0x18(%rsp)
   3ab2f:	89 6c 24 20          	mov    %ebp,0x20(%rsp)
   3ab33:	49 89 c6             	mov    %rax,%r14
   3ab36:	eb 41                	jmp    3ab79 <oriole_expat::dispatch+0x6cf9>
   3ab38:	49 89 c6             	mov    %rax,%r14
   3ab3b:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   3ab42:	00 
   3ab43:	b0 01                	mov    $0x1,%al
   3ab45:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3ab49:	48 85 c9             	test   %rcx,%rcx
   3ab4c:	75 09                	jne    3ab57 <oriole_expat::dispatch+0x6cd7>
   3ab4e:	b0 01                	mov    $0x1,%al
   3ab50:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3ab55:	eb 22                	jmp    3ab79 <oriole_expat::dispatch+0x6cf9>
   3ab57:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3ab5e:	00 
   3ab5f:	ba 01 00 00 00       	mov    $0x1,%edx
   3ab64:	48 8b b4 24 18 02 00 	mov    0x218(%rsp),%rsi
   3ab6b:	00 
   3ab6c:	ff 15 06 bf 0a 00    	call   *0xabf06(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3ab72:	b0 01                	mov    $0x1,%al
   3ab74:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3ab79:	8b 44 24 28          	mov    0x28(%rsp),%eax
   3ab7d:	89 c3                	mov    %eax,%ebx
   3ab7f:	48 8d bc 24 18 05 00 	lea    0x518(%rsp),%rdi
   3ab86:	00 
   3ab87:	e8 04 48 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3ab8c:	eb 09                	jmp    3ab97 <oriole_expat::dispatch+0x6d17>
   3ab8e:	49 89 c6             	mov    %rax,%r14
   3ab91:	8b 44 24 28          	mov    0x28(%rsp),%eax
   3ab95:	89 c3                	mov    %eax,%ebx
   3ab97:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
   3ab9e:	00 
   3ab9f:	48 83 e9 03          	sub    $0x3,%rcx
   3aba3:	b8 0d 00 00 00       	mov    $0xd,%eax
   3aba8:	48 0f 43 c1          	cmovae %rcx,%rax
   3abac:	48 83 c0 fa          	add    $0xfffffffffffffffa,%rax
   3abb0:	48 83 f8 14          	cmp    $0x14,%rax
   3abb4:	0f 87 bb 02 00 00    	ja     3ae75 <oriole_expat::dispatch+0x6ff5>
   3abba:	4c 8d bc 24 50 01 00 	lea    0x150(%rsp),%r15
   3abc1:	00 
   3abc2:	4c 8d a4 24 88 01 00 	lea    0x188(%rsp),%r12
   3abc9:	00 
   3abca:	48 8d 0d 5f f2 fc ff 	lea    -0x30da1(%rip),%rcx        # 9e30 <std::thread::current::id::ID+0x9dc0>
   3abd1:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   3abd5:	48 01 c8             	add    %rcx,%rax
   3abd8:	ff e0                	jmp    *%rax
   3abda:	84 db                	test   %bl,%bl
   3abdc:	0f 84 93 02 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3abe2:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3abe9:	00 
   3abea:	48 85 c9             	test   %rcx,%rcx
   3abed:	74 1b                	je     3ac0a <oriole_expat::dispatch+0x6d8a>
   3abef:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   3abf6:	00 
   3abf7:	ba 01 00 00 00       	mov    $0x1,%edx
   3abfc:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3ac03:	00 
   3ac04:	ff 15 6e be 0a 00    	call   *0xabe6e(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3ac0a:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   3ac11:	00 
   3ac12:	e8 99 54 ff ff       	call   300b0 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3ac17:	e9 59 02 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3ac1c:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3ac23:	00 
   3ac24:	48 85 c9             	test   %rcx,%rcx
   3ac27:	0f 95 c0             	setne  %al
   3ac2a:	84 44 24 30          	test   %al,0x30(%rsp)
   3ac2e:	0f 85 2b 02 00 00    	jne    3ae5f <oriole_expat::dispatch+0x6fdf>
   3ac34:	e9 3c 02 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3ac39:	80 7c 24 48 00       	cmpb   $0x0,0x48(%rsp)
   3ac3e:	0f 84 31 02 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3ac44:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3ac4b:	00 
   3ac4c:	e8 8f 76 ff ff       	call   322e0 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   3ac51:	e9 1f 02 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3ac56:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3ac5d:	00 
   3ac5e:	48 85 c9             	test   %rcx,%rcx
   3ac61:	0f 95 c0             	setne  %al
   3ac64:	84 44 24 38          	test   %al,0x38(%rsp)
   3ac68:	0f 85 f1 01 00 00    	jne    3ae5f <oriole_expat::dispatch+0x6fdf>
   3ac6e:	e9 02 02 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3ac73:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
   3ac78:	0f 84 f7 01 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3ac7e:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3ac85:	00 
   3ac86:	48 85 c9             	test   %rcx,%rcx
   3ac89:	0f 84 9a 01 00 00    	je     3ae29 <oriole_expat::dispatch+0x6fa9>
   3ac8f:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   3ac96:	00 
   3ac97:	ba 01 00 00 00       	mov    $0x1,%edx
   3ac9c:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3aca3:	00 
   3aca4:	ff 15 ce bd 0a 00    	call   *0xabdce(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3acaa:	e9 7a 01 00 00       	jmp    3ae29 <oriole_expat::dispatch+0x6fa9>
   3acaf:	80 7c 24 10 00       	cmpb   $0x0,0x10(%rsp)
   3acb4:	0f 84 bb 01 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3acba:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   3acc1:	00 
   3acc2:	48 85 c9             	test   %rcx,%rcx
   3acc5:	74 1b                	je     3ace2 <oriole_expat::dispatch+0x6e62>
   3acc7:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   3acce:	00 
   3accf:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3acd6:	00 
   3acd7:	ba 01 00 00 00       	mov    $0x1,%edx
   3acdc:	ff 15 96 bd 0a 00    	call   *0xabd96(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3ace2:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   3ace9:	00 
   3acea:	48 89 84 24 70 04 00 	mov    %rax,0x470(%rsp)
   3acf1:	00 
   3acf2:	e9 9d 00 00 00       	jmp    3ad94 <oriole_expat::dispatch+0x6f14>
   3acf7:	80 7c 24 40 00       	cmpb   $0x0,0x40(%rsp)
   3acfc:	0f 84 73 01 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3ad02:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   3ad09:	00 
   3ad0a:	e8 81 46 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3ad0f:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3ad16:	00 
   3ad17:	48 85 c9             	test   %rcx,%rcx
   3ad1a:	0f 85 3f 01 00 00    	jne    3ae5f <oriole_expat::dispatch+0x6fdf>
   3ad20:	e9 50 01 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3ad25:	80 7c 24 08 00       	cmpb   $0x0,0x8(%rsp)
   3ad2a:	0f 84 45 01 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3ad30:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3ad37:	00 
   3ad38:	e8 c3 59 ff ff       	call   30700 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::ExternalEntityReference, oriole_storage::allocator::Allocator>>>
   3ad3d:	e9 33 01 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3ad42:	80 7c 24 04 00       	cmpb   $0x0,0x4(%rsp)
   3ad47:	0f 84 28 01 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3ad4d:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3ad54:	00 
   3ad55:	e8 16 59 ff ff       	call   30670 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::DoctypeDeclaration, oriole_storage::allocator::Allocator>>>
   3ad5a:	e9 16 01 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3ad5f:	80 7c 24 24 00       	cmpb   $0x0,0x24(%rsp)
   3ad64:	0f 84 0b 01 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3ad6a:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3ad71:	00 
   3ad72:	e8 19 46 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3ad77:	48 8d 84 24 68 01 00 	lea    0x168(%rsp),%rax
   3ad7e:	00 
   3ad7f:	48 89 84 24 70 04 00 	mov    %rax,0x470(%rsp)
   3ad86:	00 
   3ad87:	eb 0b                	jmp    3ad94 <oriole_expat::dispatch+0x6f14>
   3ad89:	80 7c 24 50 00       	cmpb   $0x0,0x50(%rsp)
   3ad8e:	0f 84 e1 00 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3ad94:	48 8b bc 24 70 04 00 	mov    0x470(%rsp),%rdi
   3ad9b:	00 
   3ad9c:	e8 ef 45 ff ff       	call   2f390 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3ada1:	e9 cf 00 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3ada6:	80 7c 24 0c 00       	cmpb   $0x0,0xc(%rsp)
   3adab:	0f 84 c4 00 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3adb1:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3adb8:	00 
   3adb9:	e8 82 58 ff ff       	call   30640 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::EntityDeclaration, oriole_storage::allocator::Allocator>>>
   3adbe:	e9 b2 00 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3adc3:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
   3adc8:	0f 84 a7 00 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3adce:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3add5:	00 
   3add6:	e8 f5 58 ff ff       	call   306d0 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::AttributeDeclaration, oriole_storage::allocator::Allocator>>>
   3addb:	e9 95 00 00 00       	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3ade0:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
   3ade5:	0f 84 8a 00 00 00    	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3adeb:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3adf2:	00 
   3adf3:	e8 a8 58 ff ff       	call   306a0 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::NotationDeclaration, oriole_storage::allocator::Allocator>>>
   3adf8:	eb 7b                	jmp    3ae75 <oriole_expat::dispatch+0x6ff5>
   3adfa:	80 7c 24 1c 00       	cmpb   $0x0,0x1c(%rsp)
   3adff:	74 74                	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3ae01:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3ae08:	00 
   3ae09:	48 85 c9             	test   %rcx,%rcx
   3ae0c:	74 1b                	je     3ae29 <oriole_expat::dispatch+0x6fa9>
   3ae0e:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   3ae15:	00 
   3ae16:	ba 01 00 00 00       	mov    $0x1,%edx
   3ae1b:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3ae22:	00 
   3ae23:	ff 15 4f bc 0a 00    	call   *0xabc4f(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3ae29:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
   3ae30:	00 
   3ae31:	48 85 c9             	test   %rcx,%rcx
   3ae34:	74 3f                	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3ae36:	48 8d 84 24 68 01 00 	lea    0x168(%rsp),%rax
   3ae3d:	00 
   3ae3e:	48 89 84 24 70 04 00 	mov    %rax,0x470(%rsp)
   3ae45:	00 
   3ae46:	4d 89 e7             	mov    %r12,%r15
   3ae49:	eb 14                	jmp    3ae5f <oriole_expat::dispatch+0x6fdf>
   3ae4b:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3ae52:	00 
   3ae53:	48 85 c9             	test   %rcx,%rcx
   3ae56:	0f 95 c0             	setne  %al
   3ae59:	84 44 24 2c          	test   %al,0x2c(%rsp)
   3ae5d:	74 16                	je     3ae75 <oriole_expat::dispatch+0x6ff5>
   3ae5f:	49 8b 37             	mov    (%r15),%rsi
   3ae62:	ba 01 00 00 00       	mov    $0x1,%edx
   3ae67:	48 8b bc 24 70 04 00 	mov    0x470(%rsp),%rdi
   3ae6e:	00 
   3ae6f:	ff 15 03 bc 0a 00    	call   *0xabc03(%rip)        # e6a78 <_GLOBAL_OFFSET_TABLE_+0x138>
   3ae75:	4c 89 f7             	mov    %r14,%rdi
   3ae78:	e8 73 1d ff ff       	call   2cbf0 <_Unwind_Resume@plt>
   3ae7d:	ff 15 3d c2 0a 00    	call   *0xac23d(%rip)        # e70c0 <_GLOBAL_OFFSET_TABLE_+0x780>
