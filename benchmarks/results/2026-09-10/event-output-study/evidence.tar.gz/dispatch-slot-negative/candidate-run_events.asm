
/tmp/oriole-dispatch-slot/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000032660 <oriole_expat::run_events>:
   32660:	55                   	push   %rbp
   32661:	41 57                	push   %r15
   32663:	41 56                	push   %r14
   32665:	41 55                	push   %r13
   32667:	41 54                	push   %r12
   32669:	53                   	push   %rbx
   3266a:	48 81 ec 38 01 00 00 	sub    $0x138,%rsp
   32671:	48 89 fb             	mov    %rdi,%rbx
   32674:	e8 f7 0a 00 00       	call   33170 <oriole_expat::drain_default_fragments>
   32679:	48 c7 84 24 a0 00 00 	movq   $0xffffffffffffffff,0xa0(%rsp)
   32680:	00 ff ff ff ff 
   32685:	31 c0                	xor    %eax,%eax
   32687:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   3268e:	0f 85 16 04 00 00    	jne    32aaa <oriole_expat::run_events+0x44a>
   32694:	4c 8d 73 30          	lea    0x30(%rbx),%r14
   32698:	4c 8d 7c 24 78       	lea    0x78(%rsp),%r15
   3269d:	48 8d 83 20 0a 00 00 	lea    0xa20(%rbx),%rax
   326a4:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   326a9:	4c 8d 64 24 68       	lea    0x68(%rsp),%r12
   326ae:	4c 8d ac 24 a0 00 00 	lea    0xa0(%rsp),%r13
   326b5:	00 
   326b6:	eb 29                	jmp    326e1 <oriole_expat::run_events+0x81>
   326b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   326bf:	00 
   326c0:	48 89 df             	mov    %rbx,%rdi
   326c3:	e8 a8 0a 00 00       	call   33170 <oriole_expat::drain_default_fragments>
   326c8:	48 c7 84 24 a0 00 00 	movq   $0xffffffffffffffff,0xa0(%rsp)
   326cf:	00 ff ff ff ff 
   326d4:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   326db:	0f 85 e5 01 00 00    	jne    328c6 <oriole_expat::run_events+0x266>
   326e1:	8b 83 14 0a 00 00    	mov    0xa14(%rbx),%eax
   326e7:	85 c0                	test   %eax,%eax
   326e9:	0f 85 b6 01 00 00    	jne    328a5 <oriole_expat::run_events+0x245>
   326ef:	83 bb 0c 0a 00 00 03 	cmpl   $0x3,0xa0c(%rbx)
   326f6:	0f 84 b6 01 00 00    	je     328b2 <oriole_expat::run_events+0x252>
   326fc:	48 c7 84 24 a0 00 00 	movq   $0xffffffffffffffff,0xa0(%rsp)
   32703:	00 ff ff ff ff 
   32708:	4c 89 e7             	mov    %r12,%rdi
   3270b:	4c 89 f6             	mov    %r14,%rsi
   3270e:	4c 89 ea             	mov    %r13,%rdx
   32711:	ff 15 c9 42 0b 00    	call   *0xb42c9(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0xa0>
   32717:	0f b6 ac 24 98 00 00 	movzbl 0x98(%rsp),%ebp
   3271e:	00 
   3271f:	48 81 fd ff 00 00 00 	cmp    $0xff,%rbp
   32726:	74 38                	je     32760 <oriole_expat::run_events+0x100>
   32728:	41 0f 10 07          	movups (%r15),%xmm0
   3272c:	41 0f 10 4f 10       	movups 0x10(%r15),%xmm1
   32731:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
   32736:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   3273b:	83 fd 11             	cmp    $0x11,%ebp
   3273e:	0f 85 17 01 00 00    	jne    3285b <oriole_expat::run_events+0x1fb>
   32744:	48 89 df             	mov    %rbx,%rdi
   32747:	e8 f4 0b 00 00       	call   33340 <oriole_expat::resolve_unknown_encoding>
   3274c:	84 c0                	test   %al,%al
   3274e:	0f 85 ec 00 00 00    	jne    32840 <oriole_expat::run_events+0x1e0>
   32754:	e9 02 01 00 00       	jmp    3285b <oriole_expat::run_events+0x1fb>
   32759:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   32760:	83 bc 24 a0 00 00 00 	cmpl   $0xffffffff,0xa0(%rsp)
   32767:	ff 
   32768:	74 1f                	je     32789 <oriole_expat::run_events+0x129>
   3276a:	48 8b 93 a8 06 00 00 	mov    0x6a8(%rbx),%rdx
   32771:	48 89 df             	mov    %rbx,%rdi
   32774:	4c 89 ee             	mov    %r13,%rsi
   32777:	e8 04 17 00 00       	call   33e80 <oriole_expat::dispatch>
   3277c:	3c ff                	cmp    $0xff,%al
   3277e:	0f 84 bc 00 00 00    	je     32840 <oriole_expat::run_events+0x1e0>
   32784:	e9 44 01 00 00       	jmp    328cd <oriole_expat::run_events+0x26d>
   32789:	4c 89 e7             	mov    %r12,%rdi
   3278c:	4c 89 f6             	mov    %r14,%rsi
   3278f:	ff 15 7b 42 0b 00    	call   *0xb427b(%rip)        # e6a10 <_GLOBAL_OFFSET_TABLE_+0xd0>
   32795:	83 7c 24 68 01       	cmpl   $0x1,0x68(%rsp)
   3279a:	0f 85 40 01 00 00    	jne    328e0 <oriole_expat::run_events+0x280>
   327a0:	49 8b 47 18          	mov    0x18(%r15),%rax
   327a4:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   327a9:	41 0f 10 47 f8       	movups -0x8(%r15),%xmm0
   327ae:	41 0f 10 4f 08       	movups 0x8(%r15),%xmm1
   327b3:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   327b8:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   327bd:	48 8b 83 80 0b 00 00 	mov    0xb80(%rbx),%rax
   327c4:	48 85 c0             	test   %rax,%rax
   327c7:	0f 84 1e 01 00 00    	je     328eb <oriole_expat::run_events+0x28b>
   327cd:	48 8b bb 88 0b 00 00 	mov    0xb88(%rbx),%rdi
   327d4:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   327d9:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
   327de:	48 8d 8b 20 0a 00 00 	lea    0xa20(%rbx),%rcx
   327e5:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
   327e9:	0f 11 01             	movups %xmm0,(%rcx)
   327ec:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   327f1:	ff d0                	call   *%rax
   327f3:	8b 8b 14 0a 00 00    	mov    0xa14(%rbx),%ecx
   327f9:	85 c9                	test   %ecx,%ecx
   327fb:	0f 85 38 02 00 00    	jne    32a39 <oriole_expat::run_events+0x3d9>
   32801:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   32808:	0f 85 f8 00 00 00    	jne    32906 <oriole_expat::run_events+0x2a6>
   3280e:	4c 89 e7             	mov    %r12,%rdi
   32811:	4c 89 f6             	mov    %r14,%rsi
   32814:	89 c2                	mov    %eax,%edx
   32816:	ff 15 2c 42 0b 00    	call   *0xb422c(%rip)        # e6a48 <_GLOBAL_OFFSET_TABLE_+0x108>
   3281c:	0f b6 84 24 98 00 00 	movzbl 0x98(%rsp),%eax
   32823:	00 
   32824:	48 8d 0d 85 6c fd ff 	lea    -0x2937b(%rip),%rcx        # 94b0 <std::thread::current::id::ID+0x9440>
   3282b:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   3282f:	48 01 c8             	add    %rcx,%rax
   32832:	ff e0                	jmp    *%rax
   32834:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   3283b:	00 00 00 00 00 
   32840:	83 bc 24 a0 00 00 00 	cmpl   $0xffffffff,0xa0(%rsp)
   32847:	ff 
   32848:	0f 84 72 fe ff ff    	je     326c0 <oriole_expat::run_events+0x60>
   3284e:	4c 89 ef             	mov    %r13,%rdi
   32851:	e8 ca e5 ff ff       	call   30e20 <core::ptr::drop_glue::<oriole::Event>>
   32856:	e9 65 fe ff ff       	jmp    326c0 <oriole_expat::run_events+0x60>
   3285b:	31 c0                	xor    %eax,%eax
   3285d:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   32864:	0f 85 24 02 00 00    	jne    32a8e <oriole_expat::run_events+0x42e>
   3286a:	83 bb 14 0a 00 00 00 	cmpl   $0x0,0xa14(%rbx)
   32871:	0f 85 17 02 00 00    	jne    32a8e <oriole_expat::run_events+0x42e>
   32877:	48 8d 05 86 78 fd ff 	lea    -0x2877a(%rip),%rax        # a104 <std::thread::current::id::ID+0xa094>
   3287e:	8b 04 a8             	mov    (%rax,%rbp,4),%eax
   32881:	89 83 14 0a 00 00    	mov    %eax,0xa14(%rbx)
   32887:	89 83 10 0a 00 00    	mov    %eax,0xa10(%rbx)
   3288d:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   32892:	0f 28 4c 24 50       	movaps 0x50(%rsp),%xmm1
   32897:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   3289c:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   328a0:	0f 11 00             	movups %xmm0,(%rax)
   328a3:	eb 06                	jmp    328ab <oriole_expat::run_events+0x24b>
   328a5:	89 83 10 0a 00 00    	mov    %eax,0xa10(%rbx)
   328ab:	31 c0                	xor    %eax,%eax
   328ad:	e9 dc 01 00 00       	jmp    32a8e <oriole_expat::run_events+0x42e>
   328b2:	c7 83 10 0a 00 00 00 	movl   $0x0,0xa10(%rbx)
   328b9:	00 00 00 
   328bc:	b8 02 00 00 00       	mov    $0x2,%eax
   328c1:	e9 c8 01 00 00       	jmp    32a8e <oriole_expat::run_events+0x42e>
   328c6:	31 c0                	xor    %eax,%eax
   328c8:	e9 dd 01 00 00       	jmp    32aaa <oriole_expat::run_events+0x44a>
   328cd:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
   328d4:	00 00 00 
   328d7:	48 89 83 10 0a 00 00 	mov    %rax,0xa10(%rbx)
   328de:	eb cb                	jmp    328ab <oriole_expat::run_events+0x24b>
   328e0:	8b 8b 14 0a 00 00    	mov    0xa14(%rbx),%ecx
   328e6:	e9 4e 01 00 00       	jmp    32a39 <oriole_expat::run_events+0x3d9>
   328eb:	48 b8 12 00 00 00 12 	movabs $0x1200000012,%rax
   328f2:	00 00 00 
   328f5:	48 89 83 10 0a 00 00 	mov    %rax,0xa10(%rbx)
   328fc:	b9 12 00 00 00       	mov    $0x12,%ecx
   32901:	e9 33 01 00 00       	jmp    32a39 <oriole_expat::run_events+0x3d9>
   32906:	31 c9                	xor    %ecx,%ecx
   32908:	e9 2c 01 00 00       	jmp    32a39 <oriole_expat::run_events+0x3d9>
   3290d:	b9 28 00 00 00       	mov    $0x28,%ecx
   32912:	e9 fb 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   32917:	b9 26 00 00 00       	mov    $0x26,%ecx
   3291c:	e9 f1 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   32921:	b9 2b 00 00 00       	mov    $0x2b,%ecx
   32926:	e9 e7 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   3292b:	b9 27 00 00 00       	mov    $0x27,%ecx
   32930:	e9 dd 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   32935:	b9 10 00 00 00       	mov    $0x10,%ecx
   3293a:	e9 d3 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   3293f:	b9 0b 00 00 00       	mov    $0xb,%ecx
   32944:	e9 c9 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   32949:	b9 20 00 00 00       	mov    $0x20,%ecx
   3294e:	e9 bf 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   32953:	b9 11 00 00 00       	mov    $0x11,%ecx
   32958:	e9 b5 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   3295d:	b9 13 00 00 00       	mov    $0x13,%ecx
   32962:	e9 ab 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   32967:	b9 18 00 00 00       	mov    $0x18,%ecx
   3296c:	e9 a1 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   32971:	b9 09 00 00 00       	mov    $0x9,%ecx
   32976:	e9 97 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   3297b:	b9 0a 00 00 00       	mov    $0xa,%ecx
   32980:	e9 8d 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   32985:	b9 0d 00 00 00       	mov    $0xd,%ecx
   3298a:	e9 83 00 00 00       	jmp    32a12 <oriole_expat::run_events+0x3b2>
   3298f:	b9 08 00 00 00       	mov    $0x8,%ecx
   32994:	eb 7c                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   32996:	b9 1e 00 00 00       	mov    $0x1e,%ecx
   3299b:	eb 75                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   3299d:	b9 15 00 00 00       	mov    $0x15,%ecx
   329a2:	eb 6e                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329a4:	b9 05 00 00 00       	mov    $0x5,%ecx
   329a9:	eb 67                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329ab:	b9 0c 00 00 00       	mov    $0xc,%ecx
   329b0:	eb 60                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329b2:	b9 04 00 00 00       	mov    $0x4,%ecx
   329b7:	eb 59                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329b9:	b9 02 00 00 00       	mov    $0x2,%ecx
   329be:	eb 52                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329c0:	b9 12 00 00 00       	mov    $0x12,%ecx
   329c5:	eb 4b                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329c7:	b9 03 00 00 00       	mov    $0x3,%ecx
   329cc:	eb 44                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329ce:	b9 01 00 00 00       	mov    $0x1,%ecx
   329d3:	eb 3d                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329d5:	b9 1c 00 00 00       	mov    $0x1c,%ecx
   329da:	eb 36                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329dc:	b9 07 00 00 00       	mov    $0x7,%ecx
   329e1:	eb 2f                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329e3:	b9 1d 00 00 00       	mov    $0x1d,%ecx
   329e8:	eb 28                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329ea:	b9 14 00 00 00       	mov    $0x14,%ecx
   329ef:	eb 21                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329f1:	b9 1b 00 00 00       	mov    $0x1b,%ecx
   329f6:	eb 1a                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329f8:	b9 06 00 00 00       	mov    $0x6,%ecx
   329fd:	eb 13                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   329ff:	b9 0e 00 00 00       	mov    $0xe,%ecx
   32a04:	eb 0c                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   32a06:	b9 0f 00 00 00       	mov    $0xf,%ecx
   32a0b:	eb 05                	jmp    32a12 <oriole_expat::run_events+0x3b2>
   32a0d:	b9 24 00 00 00       	mov    $0x24,%ecx
   32a12:	89 8b 14 0a 00 00    	mov    %ecx,0xa14(%rbx)
   32a18:	89 8b 10 0a 00 00    	mov    %ecx,0xa10(%rbx)
   32a1e:	0f 10 44 24 78       	movups 0x78(%rsp),%xmm0
   32a23:	0f 10 8c 24 88 00 00 	movups 0x88(%rsp),%xmm1
   32a2a:	00 
   32a2b:	48 8d 83 20 0a 00 00 	lea    0xa20(%rbx),%rax
   32a32:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   32a36:	0f 11 00             	movups %xmm0,(%rax)
   32a39:	31 c0                	xor    %eax,%eax
   32a3b:	85 c9                	test   %ecx,%ecx
   32a3d:	75 4f                	jne    32a8e <oriole_expat::run_events+0x42e>
   32a3f:	0f 10 83 c0 08 00 00 	movups 0x8c0(%rbx),%xmm0
   32a46:	0f 10 8b d0 08 00 00 	movups 0x8d0(%rbx),%xmm1
   32a4d:	48 8d 83 20 0a 00 00 	lea    0xa20(%rbx),%rax
   32a54:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   32a58:	0f 11 00             	movups %xmm0,(%rax)
   32a5b:	80 bb e9 08 00 00 00 	cmpb   $0x0,0x8e9(%rbx)
   32a62:	74 1b                	je     32a7f <oriole_expat::run_events+0x41f>
   32a64:	48 89 df             	mov    %rbx,%rdi
   32a67:	e8 94 04 00 00       	call   32f00 <oriole_expat::merge_external_subset>
   32a6c:	84 c0                	test   %al,%al
   32a6e:	b8 00 00 00 00       	mov    $0x0,%eax
   32a73:	74 19                	je     32a8e <oriole_expat::run_events+0x42e>
   32a75:	c7 83 0c 0a 00 00 02 	movl   $0x2,0xa0c(%rbx)
   32a7c:	00 00 00 
   32a7f:	c7 83 10 0a 00 00 00 	movl   $0x0,0xa10(%rbx)
   32a86:	00 00 00 
   32a89:	b8 01 00 00 00       	mov    $0x1,%eax
   32a8e:	48 83 bc 24 a0 00 00 	cmpq   $0xffffffffffffffff,0xa0(%rsp)
   32a95:	00 ff 
   32a97:	74 11                	je     32aaa <oriole_expat::run_events+0x44a>
   32a99:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32aa0:	00 
   32aa1:	89 c3                	mov    %eax,%ebx
   32aa3:	e8 78 e3 ff ff       	call   30e20 <core::ptr::drop_glue::<oriole::Event>>
   32aa8:	89 d8                	mov    %ebx,%eax
   32aaa:	48 81 c4 38 01 00 00 	add    $0x138,%rsp
   32ab1:	5b                   	pop    %rbx
   32ab2:	41 5c                	pop    %r12
   32ab4:	41 5d                	pop    %r13
   32ab6:	41 5e                	pop    %r14
   32ab8:	41 5f                	pop    %r15
   32aba:	5d                   	pop    %rbp
   32abb:	c3                   	ret
   32abc:	0f 0b                	ud2
   32abe:	eb 00                	jmp    32ac0 <oriole_expat::run_events+0x460>
   32ac0:	48 89 c3             	mov    %rax,%rbx
   32ac3:	83 bc 24 a0 00 00 00 	cmpl   $0xffffffff,0xa0(%rsp)
   32aca:	ff 
   32acb:	74 0d                	je     32ada <oriole_expat::run_events+0x47a>
   32acd:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32ad4:	00 
   32ad5:	e8 46 e3 ff ff       	call   30e20 <core::ptr::drop_glue::<oriole::Event>>
   32ada:	48 89 df             	mov    %rbx,%rdi
   32add:	e8 0e a1 ff ff       	call   2cbf0 <_Unwind_Resume@plt>
   32ae2:	ff 15 d8 45 0b 00    	call   *0xb45d8(%rip)        # e70c0 <_GLOBAL_OFFSET_TABLE_+0x780>
