# Event output-slot experiment

The event-producing core wrappers now write into a caller-owned `Option<Event>` slot instead of returning a large `Result<Option<Event>, Error>` through each layer. The public owned `next_event` and existing recycling API stay available. The C adapter uses an additive hidden slot method; the slot owns all payloads and no parser reference crosses a C callback.

## Recommendation

Recommend composed validation. The exact-parent native screen improved every one of the 24 project conditions, with a 1.05784 geometric-mean speedup. These are six pinned XML inputs, namespaces on/off, and 4/64KiB feeds, five randomized process pairs per condition, seven measured parses plus warmup per process. All callback observations and frozen hashes agree. This is native callback-driver timing on a shared host, not a claim about actual CPython throughput or beating Expat. Raw outliers are retained without filtering.

The generated declaration control improved 1.01168x at 4 KiB but regressed to 0.96722x at 64 KiB; generated entities improved 1.02453–1.03002x. These adverse results are retained. Integration must confirm gains on the current parent.

## Attribution

XML_Parse-only Callgrind reduces Maven instructions 1.996%, Wayland 1.047%, and generated declarations 0.474%. These are instruction counts, not hardware cycles or wall-clock timing. Maven libc-copy calls fall 86,694→79,208; copy instructions 2,318,128→2,093,546. The scoped event return removes approximately 7,486 copies. The larger next_event_inner and queue insertion copy counts remain unchanged. Assembly snapshots and raw Callgrind files preserve the exact measured code.

## Validation

- 142 Rust checks: 59 core/unit/allocation/encoding/recycling/output-slot and 83 FFI/unit/memory; strict Clippy and formatting pass.
- 1,518 exact candidate/control differential cases and 36,456 custom-encoding comparisons: no change.
- All 4,740 original upstream API configurations retain identical outcomes: 4,113 pass, 627 fail. Inherited failures are not waived or counted as passing.
- 64 streaming conditions verify DefaultCurrent, raw input context, UTF8/UTF16, per-text suspension/resumption, and callback replacement.
- Six native C ASan/UBSan runs pass for dynamic/static integration, adversarial lifecycle, and 336 allocation-failure scenarios per linkage. Rust release code is not sanitizer-instrumented; LeakSanitizer is disabled because sandbox ptrace is unsupported. Selected-suite checks independently verify zero live allocations and global-allocation escapes.

New regressions cover prefilled slots cleared on pending input, terminal/repeated error, DTD-table contention, unknown-encoding retry, and every selected allocation failure; pending namespace error-prefix callbacks; retained owned events; and foreign/reset generation tokens. No new allocation or unsafe code was added to the core.

## Frozen identities

Parent: 353dc3f19ebe6554b8c224a400c588bdf49e901a.
Control: e6849aa2cc0d75c74b42370ecd568c6dd7581dfadbc892244176a6a03acf576d.
Candidate: fef31ffcaa4988ce470bf81fb86356ed3f25ec8278b9dff5a54e107e919c88c3.

`source.tar.gz` and `event-output.patch` retain the exact measured runtime. `final-source.tar.gz` and `event-output-with-tests.patch` add only tests and move the existing SAFETY comment immediately before its unsafe block to satisfy Clippy. `final-source.json` verifies the exact comment-only text replacement and all source hashes. Original failed Clippy output is retained. Root's independent review covers the original measured runtime patch and reports no blocker; final changes are explicitly scoped above.

The baseline archive and both libraries are retained. No rejected namespace/validated-name/text-slot/surplus/queue-inline experiment is carried.
