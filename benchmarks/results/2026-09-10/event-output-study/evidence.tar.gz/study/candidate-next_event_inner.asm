
/tmp/oriole-event-output/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000081590 <<oriole::Parser>::next_event_inner>:
   81590:	55                   	push   %rbp
   81591:	41 57                	push   %r15
   81593:	41 56                	push   %r14
   81595:	41 55                	push   %r13
   81597:	41 54                	push   %r12
   81599:	53                   	push   %rbx
   8159a:	48 81 ec 78 05 00 00 	sub    $0x578,%rsp
   815a1:	48 89 d3             	mov    %rdx,%rbx
   815a4:	49 89 f6             	mov    %rsi,%r14
   815a7:	49 89 ff             	mov    %rdi,%r15
   815aa:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   815b1:	00 
   815b2:	31 d2                	xor    %edx,%edx
   815b4:	e8 77 b7 ff ff       	call   7cd30 <<oriole::Parser>::account_source>
   815b9:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   815c0:	ff 
   815c1:	74 3d                	je     81600 <<oriole::Parser>::next_event_inner+0x70>
   815c3:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   815ca:	00 
   815cb:	49 89 47 30          	mov    %rax,0x30(%r15)
   815cf:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   815d6:	00 00 
   815d8:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   815df:	00 00 
   815e1:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   815e8:	00 00 
   815ea:	f3 41 0f 7f 57 20    	movdqu %xmm2,0x20(%r15)
   815f0:	f3 41 0f 7f 4f 10    	movdqu %xmm1,0x10(%r15)
   815f6:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
   815fb:	e9 10 35 00 00       	jmp    84b10 <<oriole::Parser>::next_event_inner+0x3580>
   81600:	48 89 9c 24 30 05 00 	mov    %rbx,0x530(%rsp)
   81607:	00 
   81608:	49 8b 86 00 07 00 00 	mov    0x700(%r14),%rax
   8160f:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
   81616:	00 
   81617:	41 0f 10 86 f0 06 00 	movups 0x6f0(%r14),%xmm0
   8161e:	00 
   8161f:	0f 29 84 24 90 02 00 	movaps %xmm0,0x290(%rsp)
   81626:	00 
   81627:	f3 41 0f 6f 86 b0 06 	movdqu 0x6b0(%r14),%xmm0
   8162e:	00 00 
   81630:	f3 41 0f 6f 8e c0 06 	movdqu 0x6c0(%r14),%xmm1
   81637:	00 00 
   81639:	f3 41 0f 6f 96 d0 06 	movdqu 0x6d0(%r14),%xmm2
   81640:	00 00 
   81642:	41 0f 10 9e e0 06 00 	movups 0x6e0(%r14),%xmm3
   81649:	00 
   8164a:	0f 29 9c 24 80 02 00 	movaps %xmm3,0x280(%rsp)
   81651:	00 
   81652:	66 0f 7f 94 24 70 02 	movdqa %xmm2,0x270(%rsp)
   81659:	00 00 
   8165b:	66 0f 7f 8c 24 60 02 	movdqa %xmm1,0x260(%rsp)
   81662:	00 00 
   81664:	66 0f 7f 84 24 50 02 	movdqa %xmm0,0x250(%rsp)
   8166b:	00 00 
   8166d:	49 c7 86 b0 06 00 00 	movq   $0xffffffffffffffff,0x6b0(%r14)
   81674:	ff ff ff ff 
   81678:	48 83 bc 24 50 02 00 	cmpq   $0xffffffffffffffff,0x250(%rsp)
   8167f:	00 ff 
   81681:	0f 84 6d 01 00 00    	je     817f4 <<oriole::Parser>::next_event_inner+0x264>
   81687:	f3 41 0f 6f 86 e8 06 	movdqu 0x6e8(%r14),%xmm0
   8168e:	00 00 
   81690:	f3 41 0f 6f 8e f8 06 	movdqu 0x6f8(%r14),%xmm1
   81697:	00 00 
   81699:	66 0f 7f 8c 24 20 04 	movdqa %xmm1,0x420(%rsp)
   816a0:	00 00 
   816a2:	66 0f 7f 84 24 10 04 	movdqa %xmm0,0x410(%rsp)
   816a9:	00 00 
   816ab:	41 8b 86 80 08 00 00 	mov    0x880(%r14),%eax
   816b2:	85 c0                	test   %eax,%eax
   816b4:	74 1c                	je     816d2 <<oriole::Parser>::next_event_inner+0x142>
   816b6:	41 8b 86 80 08 00 00 	mov    0x880(%r14),%eax
   816bd:	85 c0                	test   %eax,%eax
   816bf:	0f 84 b8 00 00 00    	je     8177d <<oriole::Parser>::next_event_inner+0x1ed>
   816c5:	41 0f b6 86 b2 08 00 	movzbl 0x8b2(%r14),%eax
   816cc:	00 
   816cd:	e9 bb 00 00 00       	jmp    8178d <<oriole::Parser>::next_event_inner+0x1fd>
   816d2:	49 8b 86 78 08 00 00 	mov    0x878(%r14),%rax
   816d9:	0f b6 40 28          	movzbl 0x28(%rax),%eax
   816dd:	84 c0                	test   %al,%al
   816df:	74 d5                	je     816b6 <<oriole::Parser>::next_event_inner+0x126>
   816e1:	41 80 be be 08 00 00 	cmpb   $0x0,0x8be(%r14)
   816e8:	00 
   816e9:	0f 85 d2 00 00 00    	jne    817c1 <<oriole::Parser>::next_event_inner+0x231>
   816ef:	49 8d be 98 01 00 00 	lea    0x198(%r14),%rdi
   816f6:	66 0f 6f 84 24 10 04 	movdqa 0x410(%rsp),%xmm0
   816fd:	00 00 
   816ff:	66 0f 6f 8c 24 20 04 	movdqa 0x420(%rsp),%xmm1
   81706:	00 00 
   81708:	f3 0f 7f 8c 24 40 01 	movdqu %xmm1,0x140(%rsp)
   8170f:	00 00 
   81711:	f3 0f 7f 84 24 30 01 	movdqu %xmm0,0x130(%rsp)
   81718:	00 00 
   8171a:	48 c7 84 24 b8 00 00 	movq   $0x16,0xb8(%rsp)
   81721:	00 16 00 00 00 
   81726:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   8172d:	00 ff ff ff ff 
   81732:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
   81739:	00 
   8173a:	e8 61 5d fd ff       	call   574a0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   8173f:	3c ff                	cmp    $0xff,%al
   81741:	0f 84 db 33 00 00    	je     84b22 <<oriole::Parser>::next_event_inner+0x3592>
   81747:	48 8d 05 5e fd f8 ff 	lea    -0x702a2(%rip),%rax        # 114ac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   8174e:	49 89 07             	mov    %rax,(%r15)
   81751:	49 c7 47 08 0d 00 00 	movq   $0xd,0x8(%r15)
   81758:	00 
   81759:	49 c7 47 10 00 00 00 	movq   $0x0,0x10(%r15)
   81760:	00 
   81761:	49 c7 47 18 01 00 00 	movq   $0x1,0x18(%r15)
   81768:	00 
   81769:	66 0f ef c0          	pxor   %xmm0,%xmm0
   8176d:	f3 41 0f 7f 47 20    	movdqu %xmm0,0x20(%r15)
   81773:	41 c6 47 30 00       	movb   $0x0,0x30(%r15)
   81778:	e9 02 34 00 00       	jmp    84b7f <<oriole::Parser>::next_event_inner+0x35ef>
   8177d:	49 8b 86 78 08 00 00 	mov    0x878(%r14),%rax
   81784:	0f b6 40 29          	movzbl 0x29(%rax),%eax
   81788:	84 c0                	test   %al,%al
   8178a:	0f 95 c0             	setne  %al
   8178d:	41 0f b6 8e be 08 00 	movzbl 0x8be(%r14),%ecx
   81794:	00 
   81795:	80 f1 01             	xor    $0x1,%cl
   81798:	0f b6 c9             	movzbl %cl,%ecx
   8179b:	84 c0                	test   %al,%al
   8179d:	b8 01 00 00 00       	mov    $0x1,%eax
   817a2:	0f 44 c1             	cmove  %ecx,%eax
   817a5:	41 88 86 b2 08 00 00 	mov    %al,0x8b2(%r14)
   817ac:	41 8b 8e 80 08 00 00 	mov    0x880(%r14),%ecx
   817b3:	85 c9                	test   %ecx,%ecx
   817b5:	75 0a                	jne    817c1 <<oriole::Parser>::next_event_inner+0x231>
   817b7:	49 8b 8e 78 08 00 00 	mov    0x878(%r14),%rcx
   817be:	88 41 29             	mov    %al,0x29(%rcx)
   817c1:	48 83 bc 24 50 02 00 	cmpq   $0xffffffffffffffff,0x250(%rsp)
   817c8:	00 ff 
   817ca:	74 28                	je     817f4 <<oriole::Parser>::next_event_inner+0x264>
   817cc:	48 8b 8c 24 78 02 00 	mov    0x278(%rsp),%rcx
   817d3:	00 
   817d4:	48 85 c9             	test   %rcx,%rcx
   817d7:	74 1b                	je     817f4 <<oriole::Parser>::next_event_inner+0x264>
   817d9:	48 8b b4 24 70 02 00 	mov    0x270(%rsp),%rsi
   817e0:	00 
   817e1:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   817e8:	00 
   817e9:	ba 01 00 00 00       	mov    $0x1,%edx
   817ee:	ff 15 bc 50 06 00    	call   *0x650bc(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   817f4:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   817f9:	49 8d 86 98 01 00 00 	lea    0x198(%r14),%rax
   81800:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
   81807:	00 
   81808:	49 8d ae f0 04 00 00 	lea    0x4f0(%r14),%rbp
   8180f:	49 8d 86 40 01 00 00 	lea    0x140(%r14),%rax
   81816:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
   8181d:	00 
   8181e:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   81825:	49 8d 86 50 05 00 00 	lea    0x550(%r14),%rax
   8182c:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
   81833:	00 
   81834:	49 8d 86 60 05 00 00 	lea    0x560(%r14),%rax
   8183b:	48 89 84 24 20 05 00 	mov    %rax,0x520(%rsp)
   81842:	00 
   81843:	49 8d 86 88 05 00 00 	lea    0x588(%r14),%rax
   8184a:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
   81851:	00 
   81852:	66 0f 6f 05 36 6f f8 	movdqa -0x790ca(%rip),%xmm0        # 8790 <std::thread::current::id::ID+0x8720>
   81859:	ff 
   8185a:	66 0f 7f 84 24 e0 04 	movdqa %xmm0,0x4e0(%rsp)
   81861:	00 00 
   81863:	49 8d 86 49 01 00 00 	lea    0x149(%r14),%rax
   8186a:	48 89 84 24 10 05 00 	mov    %rax,0x510(%rsp)
   81871:	00 
   81872:	49 8d 86 f9 03 00 00 	lea    0x3f9(%r14),%rax
   81879:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
   81880:	00 
   81881:	48 8d 05 80 1e 06 00 	lea    0x61e80(%rip),%rax        # e3708 <oriole_expat::FEATURES+0xb20>
   81888:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
   8188f:	00 
   81890:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   81895:	48 89 ac 24 38 05 00 	mov    %rbp,0x538(%rsp)
   8189c:	00 
   8189d:	0f 1f 00             	nopl   (%rax)
   818a0:	49 8b 9e c8 01 00 00 	mov    0x1c8(%r14),%rbx
   818a7:	4d 8b a6 d0 01 00 00 	mov    0x1d0(%r14),%r12
   818ae:	49 39 dc             	cmp    %rbx,%r12
   818b1:	0f 83 36 02 00 00    	jae    81aed <<oriole::Parser>::next_event_inner+0x55d>
   818b7:	4c 89 ed             	mov    %r13,%rbp
   818ba:	4d 8b be b8 01 00 00 	mov    0x1b8(%r14),%r15
   818c1:	4d 69 ec d0 00 00 00 	imul   $0xd0,%r12,%r13
   818c8:	4b 8d 34 2f          	lea    (%r15,%r13,1),%rsi
   818cc:	ba d0 00 00 00       	mov    $0xd0,%edx
   818d1:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   818d8:	00 
   818d9:	ff 15 b9 58 06 00    	call   *0x658b9(%rip)        # e7198 <memcpy@GLIBC_2.14>
   818df:	4b c7 04 2f fe ff ff 	movq   $0xfffffffffffffffe,(%r15,%r13,1)
   818e6:	ff 
   818e7:	49 ff c4             	inc    %r12
   818ea:	4d 89 a6 d0 01 00 00 	mov    %r12,0x1d0(%r14)
   818f1:	49 39 dc             	cmp    %rbx,%r12
   818f4:	75 28                	jne    8191e <<oriole::Parser>::next_event_inner+0x38e>
   818f6:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   818fb:	49 c7 84 24 c8 01 00 	movq   $0x0,0x1c8(%r12)
   81902:	00 00 00 00 00 
   81907:	4c 89 ff             	mov    %r15,%rdi
   8190a:	48 89 de             	mov    %rbx,%rsi
   8190d:	e8 7e 87 fc ff       	call   4a090 <core::ptr::drop_glue::<[core::option::Option<oriole::PendingEvent>]>>
   81912:	49 c7 84 24 d0 01 00 	movq   $0x0,0x1d0(%r12)
   81919:	00 00 00 00 00 
   8191e:	48 8b 9c 24 80 00 00 	mov    0x80(%rsp),%rbx
   81925:	00 
   81926:	ba c8 00 00 00       	mov    $0xc8,%edx
   8192b:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
   81932:	00 
   81933:	48 8d b4 24 88 00 00 	lea    0x88(%rsp),%rsi
   8193a:	00 
   8193b:	ff 15 57 58 06 00    	call   *0x65857(%rip)        # e7198 <memcpy@GLIBC_2.14>
   81941:	48 83 fb fe          	cmp    $0xfffffffffffffffe,%rbx
   81945:	49 89 ed             	mov    %rbp,%r13
   81948:	48 8b ac 24 38 05 00 	mov    0x538(%rsp),%rbp
   8194f:	00 
   81950:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   81955:	0f 84 92 01 00 00    	je     81aed <<oriole::Parser>::next_event_inner+0x55d>
   8195b:	ba c8 00 00 00       	mov    $0xc8,%edx
   81960:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
   81967:	00 
   81968:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
   8196f:	00 
   81970:	ff 15 22 58 06 00    	call   *0x65822(%rip)        # e7198 <memcpy@GLIBC_2.14>
   81976:	48 89 9c 24 50 02 00 	mov    %rbx,0x250(%rsp)
   8197d:	00 
   8197e:	83 bc 24 88 02 00 00 	cmpl   $0x12,0x288(%rsp)
   81985:	12 
   81986:	75 48                	jne    819d0 <<oriole::Parser>::next_event_inner+0x440>
   81988:	48 8b 84 24 b0 02 00 	mov    0x2b0(%rsp),%rax
   8198f:	00 
   81990:	83 38 ff             	cmpl   $0xffffffff,(%rax)
   81993:	75 3b                	jne    819d0 <<oriole::Parser>::next_event_inner+0x440>
   81995:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   81999:	75 35                	jne    819d0 <<oriole::Parser>::next_event_inner+0x440>
   8199b:	41 80 be f1 07 00 00 	cmpb   $0x2,0x7f1(%r14)
   819a2:	02 
   819a3:	74 2b                	je     819d0 <<oriole::Parser>::next_event_inner+0x440>
   819a5:	41 c6 86 f1 07 00 00 	movb   $0x1,0x7f1(%r14)
   819ac:	01 
   819ad:	41 8b 86 80 08 00 00 	mov    0x880(%r14),%eax
   819b4:	85 c0                	test   %eax,%eax
   819b6:	0f 85 22 3a 00 00    	jne    853de <<oriole::Parser>::next_event_inner+0x3e4e>
   819bc:	49 8b 86 78 08 00 00 	mov    0x878(%r14),%rax
   819c3:	c6 40 28 00          	movb   $0x0,0x28(%rax)
   819c7:	48 8b 9c 24 50 02 00 	mov    0x250(%rsp),%rbx
   819ce:	00 
   819cf:	90                   	nop
   819d0:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
   819d4:	0f 84 e6 00 00 00    	je     81ac0 <<oriole::Parser>::next_event_inner+0x530>
   819da:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
   819e1:	00 
   819e2:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   819e9:	00 
   819ea:	f3 0f 6f 84 24 50 02 	movdqu 0x250(%rsp),%xmm0
   819f1:	00 00 
   819f3:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   819fa:	00 00 
   819fc:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   81a03:	00 00 
   81a05:	66 0f 7f 94 24 a0 00 	movdqa %xmm2,0xa0(%rsp)
   81a0c:	00 00 
   81a0e:	66 0f 7f 8c 24 90 00 	movdqa %xmm1,0x90(%rsp)
   81a15:	00 00 
   81a17:	66 0f 7f 84 24 80 00 	movdqa %xmm0,0x80(%rsp)
   81a1e:	00 00 
   81a20:	48 85 c0             	test   %rax,%rax
   81a23:	74 59                	je     81a7e <<oriole::Parser>::next_event_inner+0x4ee>
   81a25:	49 8b 8e 18 05 00 00 	mov    0x518(%r14),%rcx
   81a2c:	48 85 c9             	test   %rcx,%rcx
   81a2f:	74 15                	je     81a46 <<oriole::Parser>::next_event_inner+0x4b6>
   81a31:	49 8b b6 10 05 00 00 	mov    0x510(%r14),%rsi
   81a38:	ba 01 00 00 00       	mov    $0x1,%edx
   81a3d:	48 89 ef             	mov    %rbp,%rdi
   81a40:	ff 15 6a 4e 06 00    	call   *0x64e6a(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   81a46:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
   81a4d:	00 
   81a4e:	48 89 45 30          	mov    %rax,0x30(%rbp)
   81a52:	f3 0f 6f 84 24 50 02 	movdqu 0x250(%rsp),%xmm0
   81a59:	00 00 
   81a5b:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   81a62:	00 00 
   81a64:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   81a6b:	00 00 
   81a6d:	f3 0f 7f 55 20       	movdqu %xmm2,0x20(%rbp)
   81a72:	f3 0f 7f 4d 10       	movdqu %xmm1,0x10(%rbp)
   81a77:	f3 0f 7f 45 00       	movdqu %xmm0,0x0(%rbp)
   81a7c:	eb 42                	jmp    81ac0 <<oriole::Parser>::next_event_inner+0x530>
   81a7e:	49 c7 86 20 05 00 00 	movq   $0x0,0x520(%r14)
   81a85:	00 00 00 00 
   81a89:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
   81a90:	00 
   81a91:	48 85 c9             	test   %rcx,%rcx
   81a94:	74 2a                	je     81ac0 <<oriole::Parser>::next_event_inner+0x530>
   81a96:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
   81a9d:	00 
   81a9e:	ba 01 00 00 00       	mov    $0x1,%edx
   81aa3:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   81aaa:	00 
   81aab:	ff 15 ff 4d 06 00    	call   *0x64dff(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   81ab1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   81ab8:	0f 1f 84 00 00 00 00 
   81abf:	00 
   81ac0:	4c 8b bc 24 88 02 00 	mov    0x288(%rsp),%r15
   81ac7:	00 
   81ac8:	ba 90 00 00 00       	mov    $0x90,%edx
   81acd:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
   81ad4:	00 
   81ad5:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
   81adc:	00 
   81add:	ff 15 b5 56 06 00    	call   *0x656b5(%rip)        # e7198 <memcpy@GLIBC_2.14>
   81ae3:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
   81ae7:	0f 85 e7 2f 00 00    	jne    84ad4 <<oriole::Parser>::next_event_inner+0x3544>
   81aed:	41 80 be b9 08 00 00 	cmpb   $0x0,0x8b9(%r14)
   81af4:	00 
   81af5:	0f 85 0c 30 00 00    	jne    84b07 <<oriole::Parser>::next_event_inner+0x3577>
   81afb:	41 83 be 88 06 00 00 	cmpl   $0xffffffff,0x688(%r14)
   81b02:	ff 
   81b03:	74 1b                	je     81b20 <<oriole::Parser>::next_event_inner+0x590>
   81b05:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   81b0c:	00 
   81b0d:	4c 89 f6             	mov    %r14,%rsi
   81b10:	e8 db 28 01 00       	call   943f0 <<oriole::Parser>::continue_value>
   81b15:	eb 49                	jmp    81b60 <<oriole::Parser>::next_event_inner+0x5d0>
   81b17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   81b1e:	00 00 
   81b20:	41 83 be f0 03 00 00 	cmpl   $0xffffffff,0x3f0(%r14)
   81b27:	ff 
   81b28:	74 12                	je     81b3c <<oriole::Parser>::next_event_inner+0x5ac>
   81b2a:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   81b31:	00 
   81b32:	4c 89 f6             	mov    %r14,%rsi
   81b35:	e8 06 66 fd ff       	call   58140 <<oriole::Parser>::continue_header_composition>
   81b3a:	eb 24                	jmp    81b60 <<oriole::Parser>::next_event_inner+0x5d0>
   81b3c:	41 83 be 18 04 00 00 	cmpl   $0xffffffff,0x418(%r14)
   81b43:	ff 
   81b44:	74 40                	je     81b86 <<oriole::Parser>::next_event_inner+0x5f6>
   81b46:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   81b4d:	00 
   81b4e:	4c 89 f6             	mov    %r14,%rsi
   81b51:	e8 aa 99 fd ff       	call   5b500 <<oriole::Parser>::continue_declaration_composition>
   81b56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   81b5d:	00 00 00 
   81b60:	0f b6 84 24 80 00 00 	movzbl 0x80(%rsp),%eax
   81b67:	00 
   81b68:	0f b6 8c 24 b0 00 00 	movzbl 0xb0(%rsp),%ecx
   81b6f:	00 
   81b70:	80 f9 ff             	cmp    $0xff,%cl
   81b73:	0f 85 17 2f 00 00    	jne    84a90 <<oriole::Parser>::next_event_inner+0x3500>
   81b79:	a8 01                	test   $0x1,%al
   81b7b:	0f 85 1f fd ff ff    	jne    818a0 <<oriole::Parser>::next_event_inner+0x310>
   81b81:	e9 81 2f 00 00       	jmp    84b07 <<oriole::Parser>::next_event_inner+0x3577>
   81b86:	4d 8b 96 90 01 00 00 	mov    0x190(%r14),%r10
   81b8d:	4d 85 d2             	test   %r10,%r10
   81b90:	0f 84 9b 35 00 00    	je     85131 <<oriole::Parser>::next_event_inner+0x3ba1>
   81b96:	49 8b 86 80 01 00 00 	mov    0x180(%r14),%rax
   81b9d:	4b 8d 0c 52          	lea    (%r10,%r10,2),%rcx
   81ba1:	48 c1 e1 07          	shl    $0x7,%rcx
   81ba5:	48 8b ac 08 c8 fe ff 	mov    -0x138(%rax,%rcx,1),%rbp
   81bac:	ff 
   81bad:	4c 8b ac 08 d8 fe ff 	mov    -0x128(%rax,%rcx,1),%r13
   81bb4:	ff 
   81bb5:	48 8b 54 08 a0       	mov    -0x60(%rax,%rcx,1),%rdx
   81bba:	48 85 d2             	test   %rdx,%rdx
   81bbd:	74 17                	je     81bd6 <<oriole::Parser>::next_event_inner+0x646>
   81bbf:	49 39 d5             	cmp    %rdx,%r13
   81bc2:	76 0c                	jbe    81bd0 <<oriole::Parser>::next_event_inner+0x640>
   81bc4:	80 7c 15 00 bf       	cmpb   $0xbf,0x0(%rbp,%rdx,1)
   81bc9:	7f 0b                	jg     81bd6 <<oriole::Parser>::next_event_inner+0x646>
   81bcb:	e9 71 3a 00 00       	jmp    85641 <<oriole::Parser>::next_event_inner+0x40b1>
   81bd0:	0f 85 6b 3a 00 00    	jne    85641 <<oriole::Parser>::next_event_inner+0x40b1>
   81bd6:	4d 89 e8             	mov    %r13,%r8
   81bd9:	49 29 d0             	sub    %rdx,%r8
   81bdc:	75 72                	jne    81c50 <<oriole::Parser>::next_event_inner+0x6c0>
   81bde:	49 83 fa 01          	cmp    $0x1,%r10
   81be2:	0f 84 a6 2f 00 00    	je     84b8e <<oriole::Parser>::next_event_inner+0x35fe>
   81be8:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
   81bef:	00 
   81bf0:	48 89 df             	mov    %rbx,%rdi
   81bf3:	4c 89 f6             	mov    %r14,%rsi
   81bf6:	e8 f5 1b 01 00       	call   937f0 <<oriole::Parser>::finish_conditional_source>
   81bfb:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   81c02:	ff 
   81c03:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   81c08:	0f 85 b5 f9 ff ff    	jne    815c3 <<oriole::Parser>::next_event_inner+0x33>
   81c0e:	48 89 df             	mov    %rbx,%rdi
   81c11:	4c 89 f6             	mov    %r14,%rsi
   81c14:	e8 07 4e 00 00       	call   86a20 <<oriole::Parser>::pop_entity_source>
   81c19:	49 8b 86 08 02 00 00 	mov    0x208(%r14),%rax
   81c20:	48 3b 84 24 e8 01 00 	cmp    0x1e8(%rsp),%rax
   81c27:	00 
   81c28:	0f 85 ef 2f 00 00    	jne    84c1d <<oriole::Parser>::next_event_inner+0x368d>
   81c2e:	41 80 be b7 08 00 00 	cmpb   $0x0,0x8b7(%r14)
   81c35:	00 
   81c36:	0f 85 e1 2f 00 00    	jne    84c1d <<oriole::Parser>::next_event_inner+0x368d>
   81c3c:	48 89 df             	mov    %rbx,%rdi
   81c3f:	e8 fc 7d fc ff       	call   49a40 <core::ptr::drop_glue::<oriole::encoding::Source>>
   81c44:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   81c4b:	e9 50 fc ff ff       	jmp    818a0 <<oriole::Parser>::next_event_inner+0x310>
   81c50:	48 8d 1c 08          	lea    (%rax,%rcx,1),%rbx
   81c54:	48 01 c8             	add    %rcx,%rax
   81c57:	48 05 80 fe ff ff    	add    $0xfffffffffffffe80,%rax
   81c5d:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   81c62:	4c 8d 5c 15 00       	lea    0x0(%rbp,%rdx,1),%r11
   81c67:	45 0f b6 be b1 08 00 	movzbl 0x8b1(%r14),%r15d
   81c6e:	00 
   81c6f:	41 0f b6 86 bb 08 00 	movzbl 0x8bb(%r14),%eax
   81c76:	00 
   81c77:	44 89 f9             	mov    %r15d,%ecx
   81c7a:	08 c1                	or     %al,%cl
   81c7c:	f6 c1 01             	test   $0x1,%cl
   81c7f:	4c 89 94 24 40 02 00 	mov    %r10,0x240(%rsp)
   81c86:	00 
   81c87:	0f 84 00 03 00 00    	je     81f8d <<oriole::Parser>::next_event_inner+0x9fd>
   81c8d:	49 8b be 40 04 00 00 	mov    0x440(%r14),%rdi
   81c94:	48 85 ff             	test   %rdi,%rdi
   81c97:	4c 89 9c 24 38 02 00 	mov    %r11,0x238(%rsp)
   81c9e:	00 
   81c9f:	4c 89 84 24 10 02 00 	mov    %r8,0x210(%rsp)
   81ca6:	00 
   81ca7:	0f 84 56 03 00 00    	je     82003 <<oriole::Parser>::next_event_inner+0xa73>
   81cad:	48 85 d2             	test   %rdx,%rdx
   81cb0:	74 13                	je     81cc5 <<oriole::Parser>::next_event_inner+0x735>
   81cb2:	49 39 d5             	cmp    %rdx,%r13
   81cb5:	0f 86 86 39 00 00    	jbe    85641 <<oriole::Parser>::next_event_inner+0x40b1>
   81cbb:	41 80 3b bf          	cmpb   $0xbf,(%r11)
   81cbf:	0f 8e 7c 39 00 00    	jle    85641 <<oriole::Parser>::next_event_inner+0x40b1>
   81cc5:	48 89 94 24 00 05 00 	mov    %rdx,0x500(%rsp)
   81ccc:	00 
   81ccd:	49 81 f8 00 00 01 00 	cmp    $0x10000,%r8
   81cd4:	b8 00 00 01 00       	mov    $0x10000,%eax
   81cd9:	49 0f 42 c0          	cmovb  %r8,%rax
   81cdd:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
   81ce4:	00 
   81ce5:	49 8b 86 e8 03 00 00 	mov    0x3e8(%r14),%rax
   81cec:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
   81cf3:	00 
   81cf4:	49 8b 86 90 07 00 00 	mov    0x790(%r14),%rax
   81cfb:	48 89 84 24 f0 04 00 	mov    %rax,0x4f0(%rsp)
   81d02:	00 
   81d03:	41 0f b6 86 b8 08 00 	movzbl 0x8b8(%r14),%eax
   81d0a:	00 
   81d0b:	88 44 24 6f          	mov    %al,0x6f(%rsp)
   81d0f:	41 0f b6 86 f8 07 00 	movzbl 0x7f8(%r14),%eax
   81d16:	00 
   81d17:	88 44 24 6e          	mov    %al,0x6e(%rsp)
   81d1b:	3c ff                	cmp    $0xff,%al
   81d1d:	0f 95 c0             	setne  %al
   81d20:	41 0f b6 8e 28 01 00 	movzbl 0x128(%r14),%ecx
   81d27:	00 
   81d28:	80 f1 01             	xor    $0x1,%cl
   81d2b:	08 c1                	or     %al,%cl
   81d2d:	88 4c 24 6d          	mov    %cl,0x6d(%rsp)
   81d31:	49 8b 86 50 04 00 00 	mov    0x450(%r14),%rax
   81d38:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   81d3d:	49 8b 86 98 07 00 00 	mov    0x798(%r14),%rax
   81d44:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   81d4b:	00 
   81d4c:	31 ed                	xor    %ebp,%ebp
   81d4e:	66 90                	xchg   %ax,%ax
   81d50:	48 85 ed             	test   %rbp,%rbp
   81d53:	74 17                	je     81d6c <<oriole::Parser>::next_event_inner+0x7dc>
   81d55:	49 39 e8             	cmp    %rbp,%r8
   81d58:	76 0c                	jbe    81d66 <<oriole::Parser>::next_event_inner+0x7d6>
   81d5a:	41 80 3c 2b bf       	cmpb   $0xbf,(%r11,%rbp,1)
   81d5f:	7f 0b                	jg     81d6c <<oriole::Parser>::next_event_inner+0x7dc>
   81d61:	e9 0a 39 00 00       	jmp    85670 <<oriole::Parser>::next_event_inner+0x40e0>
   81d66:	0f 85 04 39 00 00    	jne    85670 <<oriole::Parser>::next_event_inner+0x40e0>
   81d6c:	4d 89 c7             	mov    %r8,%r15
   81d6f:	49 29 ef             	sub    %rbp,%r15
   81d72:	49 8d 1c 2b          	lea    (%r11,%rbp,1),%rbx
   81d76:	49 83 ff 03          	cmp    $0x3,%r15
   81d7a:	72 2c                	jb     81da8 <<oriole::Parser>::next_event_inner+0x818>
   81d7c:	0f b7 03             	movzwl (%rbx),%eax
   81d7f:	35 3c 21 00 00       	xor    $0x213c,%eax
   81d84:	0f b6 4b 02          	movzbl 0x2(%rbx),%ecx
   81d88:	83 f1 5b             	xor    $0x5b,%ecx
   81d8b:	66 09 c1             	or     %ax,%cx
   81d8e:	74 3d                	je     81dcd <<oriole::Parser>::next_event_inner+0x83d>
   81d90:	0f b7 03             	movzwl (%rbx),%eax
   81d93:	35 5d 5d 00 00       	xor    $0x5d5d,%eax
   81d98:	0f b6 4b 02          	movzbl 0x2(%rbx),%ecx
   81d9c:	83 f1 3e             	xor    $0x3e,%ecx
   81d9f:	66 09 c1             	or     %ax,%cx
   81da2:	0f 84 6c 01 00 00    	je     81f14 <<oriole::Parser>::next_event_inner+0x984>
   81da8:	49 83 fa 01          	cmp    $0x1,%r10
   81dac:	0f 85 a5 00 00 00    	jne    81e57 <<oriole::Parser>::next_event_inner+0x8c7>
   81db2:	80 7c 24 6f 00       	cmpb   $0x0,0x6f(%rsp)
   81db7:	74 3a                	je     81df3 <<oriole::Parser>::next_event_inner+0x863>
   81db9:	49 83 ff 04          	cmp    $0x4,%r15
   81dbd:	0f 93 c0             	setae  %al
   81dc0:	0a 44 24 6d          	or     0x6d(%rsp),%al
   81dc4:	a8 01                	test   $0x1,%al
   81dc6:	74 38                	je     81e00 <<oriole::Parser>::next_event_inner+0x870>
   81dc8:	e9 8a 00 00 00       	jmp    81e57 <<oriole::Parser>::next_event_inner+0x8c7>
   81dcd:	48 8b 84 24 f8 04 00 	mov    0x4f8(%rsp),%rax
   81dd4:	00 
   81dd5:	48 01 f8             	add    %rdi,%rax
   81dd8:	48 3b 84 24 f0 04 00 	cmp    0x4f0(%rsp),%rax
   81ddf:	00 
   81de0:	0f 83 1c 0a 00 00    	jae    82802 <<oriole::Parser>::next_event_inner+0x1272>
   81de6:	48 ff c7             	inc    %rdi
   81de9:	ba 03 00 00 00       	mov    $0x3,%edx
   81dee:	e9 de 00 00 00       	jmp    81ed1 <<oriole::Parser>::next_event_inner+0x941>
   81df3:	80 7c 24 6e ff       	cmpb   $0xff,0x6e(%rsp)
   81df8:	75 5d                	jne    81e57 <<oriole::Parser>::next_event_inner+0x8c7>
   81dfa:	49 83 ff 03          	cmp    $0x3,%r15
   81dfe:	77 57                	ja     81e57 <<oriole::Parser>::next_event_inner+0x8c7>
   81e00:	49 89 fc             	mov    %rdi,%r12
   81e03:	48 89 df             	mov    %rbx,%rdi
   81e06:	48 8d 35 50 f8 f8 ff 	lea    -0x707b0(%rip),%rsi        # 1165d <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4cc1>
   81e0d:	4c 89 fa             	mov    %r15,%rdx
   81e10:	ff 15 42 53 06 00    	call   *0x65342(%rip)        # e7158 <bcmp@GLIBC_2.2.5>
   81e16:	4c 89 e7             	mov    %r12,%rdi
   81e19:	85 c0                	test   %eax,%eax
   81e1b:	0f 84 98 08 00 00    	je     826b9 <<oriole::Parser>::next_event_inner+0x1129>
   81e21:	48 89 df             	mov    %rbx,%rdi
   81e24:	48 8d 35 cf f5 f8 ff 	lea    -0x70a31(%rip),%rsi        # 113fa <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4a5e>
   81e2b:	4c 89 fa             	mov    %r15,%rdx
   81e2e:	ff 15 24 53 06 00    	call   *0x65324(%rip)        # e7158 <bcmp@GLIBC_2.2.5>
   81e34:	4c 89 e7             	mov    %r12,%rdi
   81e37:	4c 8b 84 24 10 02 00 	mov    0x210(%rsp),%r8
   81e3e:	00 
   81e3f:	4c 8b 9c 24 38 02 00 	mov    0x238(%rsp),%r11
   81e46:	00 
   81e47:	4c 8b 94 24 40 02 00 	mov    0x240(%rsp),%r10
   81e4e:	00 
   81e4f:	85 c0                	test   %eax,%eax
   81e51:	0f 84 62 08 00 00    	je     826b9 <<oriole::Parser>::next_event_inner+0x1129>
   81e57:	48 8b 84 24 00 05 00 	mov    0x500(%rsp),%rax
   81e5e:	00 
   81e5f:	48 01 e8             	add    %rbp,%rax
   81e62:	4c 39 e8             	cmp    %r13,%rax
   81e65:	0f 84 ec 37 00 00    	je     85657 <<oriole::Parser>::next_event_inner+0x40c7>
   81e6b:	0f b6 03             	movzbl (%rbx),%eax
   81e6e:	84 c0                	test   %al,%al
   81e70:	79 4b                	jns    81ebd <<oriole::Parser>::next_event_inner+0x92d>
   81e72:	89 c1                	mov    %eax,%ecx
   81e74:	83 e1 1f             	and    $0x1f,%ecx
   81e77:	0f b6 73 01          	movzbl 0x1(%rbx),%esi
   81e7b:	83 e6 3f             	and    $0x3f,%esi
   81e7e:	3c df                	cmp    $0xdf,%al
   81e80:	76 34                	jbe    81eb6 <<oriole::Parser>::next_event_inner+0x926>
   81e82:	0f b6 53 02          	movzbl 0x2(%rbx),%edx
   81e86:	c1 e6 06             	shl    $0x6,%esi
   81e89:	83 e2 3f             	and    $0x3f,%edx
   81e8c:	09 f2                	or     %esi,%edx
   81e8e:	3c f0                	cmp    $0xf0,%al
   81e90:	0f 82 88 00 00 00    	jb     81f1e <<oriole::Parser>::next_event_inner+0x98e>
   81e96:	0f b6 43 03          	movzbl 0x3(%rbx),%eax
   81e9a:	83 e1 07             	and    $0x7,%ecx
   81e9d:	c1 e1 12             	shl    $0x12,%ecx
   81ea0:	c1 e2 06             	shl    $0x6,%edx
   81ea3:	83 e0 3f             	and    $0x3f,%eax
   81ea6:	09 d0                	or     %edx,%eax
   81ea8:	09 c8                	or     %ecx,%eax
   81eaa:	ba 01 00 00 00       	mov    $0x1,%edx
   81eaf:	83 f8 0d             	cmp    $0xd,%eax
   81eb2:	76 13                	jbe    81ec7 <<oriole::Parser>::next_event_inner+0x937>
   81eb4:	eb 79                	jmp    81f2f <<oriole::Parser>::next_event_inner+0x99f>
   81eb6:	c1 e1 06             	shl    $0x6,%ecx
   81eb9:	09 f1                	or     %esi,%ecx
   81ebb:	89 c8                	mov    %ecx,%eax
   81ebd:	ba 01 00 00 00       	mov    $0x1,%edx
   81ec2:	83 f8 0d             	cmp    $0xd,%eax
   81ec5:	77 68                	ja     81f2f <<oriole::Parser>::next_event_inner+0x99f>
   81ec7:	b9 00 26 00 00       	mov    $0x2600,%ecx
   81ecc:	0f a3 c1             	bt     %eax,%ecx
   81ecf:	73 5e                	jae    81f2f <<oriole::Parser>::next_event_inner+0x99f>
   81ed1:	48 01 ea             	add    %rbp,%rdx
   81ed4:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   81ed9:	48 01 d0             	add    %rdx,%rax
   81edc:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   81ee3:	48 0f 42 c1          	cmovb  %rcx,%rax
   81ee7:	48 3b 84 24 20 02 00 	cmp    0x220(%rsp),%rax
   81eee:	00 
   81eef:	0f 87 c5 02 00 00    	ja     821ba <<oriole::Parser>::next_event_inner+0xc2a>
   81ef5:	48 85 ff             	test   %rdi,%rdi
   81ef8:	0f 84 54 03 00 00    	je     82252 <<oriole::Parser>::next_event_inner+0xcc2>
   81efe:	48 89 d5             	mov    %rdx,%rbp
   81f01:	48 3b 94 24 50 03 00 	cmp    0x350(%rsp),%rdx
   81f08:	00 
   81f09:	0f 82 41 fe ff ff    	jb     81d50 <<oriole::Parser>::next_event_inner+0x7c0>
   81f0f:	e9 40 03 00 00       	jmp    82254 <<oriole::Parser>::next_event_inner+0xcc4>
   81f14:	48 ff cf             	dec    %rdi
   81f17:	ba 03 00 00 00       	mov    $0x3,%edx
   81f1c:	eb b3                	jmp    81ed1 <<oriole::Parser>::next_event_inner+0x941>
   81f1e:	c1 e1 0c             	shl    $0xc,%ecx
   81f21:	09 ca                	or     %ecx,%edx
   81f23:	89 d0                	mov    %edx,%eax
   81f25:	ba 01 00 00 00       	mov    $0x1,%edx
   81f2a:	83 f8 0d             	cmp    $0xd,%eax
   81f2d:	76 98                	jbe    81ec7 <<oriole::Parser>::next_event_inner+0x937>
   81f2f:	8d 48 e0             	lea    -0x20(%rax),%ecx
   81f32:	81 f9 e0 d7 00 00    	cmp    $0xd7e0,%ecx
   81f38:	0f 92 c1             	setb   %cl
   81f3b:	8d b0 00 20 ff ff    	lea    -0xe000(%rax),%esi
   81f41:	81 fe fe 1f 00 00    	cmp    $0x1ffe,%esi
   81f47:	40 0f 92 c6          	setb   %sil
   81f4b:	40 08 ce             	or     %cl,%sil
   81f4e:	3d 00 00 01 00       	cmp    $0x10000,%eax
   81f53:	0f 93 c1             	setae  %cl
   81f56:	40 08 f1             	or     %sil,%cl
   81f59:	0f 84 ce 08 00 00    	je     8282d <<oriole::Parser>::next_event_inner+0x129d>
   81f5f:	3d 80 00 00 00       	cmp    $0x80,%eax
   81f64:	0f 82 67 ff ff ff    	jb     81ed1 <<oriole::Parser>::next_event_inner+0x941>
   81f6a:	ba 02 00 00 00       	mov    $0x2,%edx
   81f6f:	3d 00 08 00 00       	cmp    $0x800,%eax
   81f74:	0f 82 57 ff ff ff    	jb     81ed1 <<oriole::Parser>::next_event_inner+0x941>
   81f7a:	3d 00 00 01 00       	cmp    $0x10000,%eax
   81f7f:	ba 04 00 00 00       	mov    $0x4,%edx
   81f84:	48 83 da 00          	sbb    $0x0,%rdx
   81f88:	e9 44 ff ff ff       	jmp    81ed1 <<oriole::Parser>::next_event_inner+0x941>
   81f8d:	41 80 be b7 08 00 00 	cmpb   $0x0,0x8b7(%r14)
   81f94:	00 
   81f95:	74 49                	je     81fe0 <<oriole::Parser>::next_event_inner+0xa50>
   81f97:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   81f9c:	e8 1f d4 fe ff       	call   6f3c0 <<oriole::encoding::Source>::converted_text_limit>
   81fa1:	48 8b bc 24 40 02 00 	mov    0x240(%rsp),%rdi
   81fa8:	00 
   81fa9:	48 89 c5             	mov    %rax,%rbp
   81fac:	4c 8b 8b c8 fe ff ff 	mov    -0x138(%rbx),%r9
   81fb3:	48 8b 8b d8 fe ff ff 	mov    -0x128(%rbx),%rcx
   81fba:	4c 8b 6b a0          	mov    -0x60(%rbx),%r13
   81fbe:	4d 85 ed             	test   %r13,%r13
   81fc1:	0f 84 6d 03 00 00    	je     82334 <<oriole::Parser>::next_event_inner+0xda4>
   81fc7:	4c 39 e9             	cmp    %r13,%rcx
   81fca:	0f 86 5e 03 00 00    	jbe    8232e <<oriole::Parser>::next_event_inner+0xd9e>
   81fd0:	43 80 3c 29 bf       	cmpb   $0xbf,(%r9,%r13,1)
   81fd5:	0f 8f 59 03 00 00    	jg     82334 <<oriole::Parser>::next_event_inner+0xda4>
   81fdb:	e9 dd 36 00 00       	jmp    856bd <<oriole::Parser>::next_event_inner+0x412d>
   81fe0:	48 85 d2             	test   %rdx,%rdx
   81fe3:	0f 84 85 01 00 00    	je     8216e <<oriole::Parser>::next_event_inner+0xbde>
   81fe9:	49 39 d5             	cmp    %rdx,%r13
   81fec:	0f 86 4f 36 00 00    	jbe    85641 <<oriole::Parser>::next_event_inner+0x40b1>
   81ff2:	41 0f b6 03          	movzbl (%r11),%eax
   81ff6:	3c bf                	cmp    $0xbf,%al
   81ff8:	0f 8f 74 01 00 00    	jg     82172 <<oriole::Parser>::next_event_inner+0xbe2>
   81ffe:	e9 3e 36 00 00       	jmp    85641 <<oriole::Parser>::next_event_inner+0x40b1>
   82003:	48 85 d2             	test   %rdx,%rdx
   82006:	74 13                	je     8201b <<oriole::Parser>::next_event_inner+0xa8b>
   82008:	49 39 d5             	cmp    %rdx,%r13
   8200b:	0f 86 30 36 00 00    	jbe    85641 <<oriole::Parser>::next_event_inner+0x40b1>
   82011:	41 80 3b bf          	cmpb   $0xbf,(%r11)
   82015:	0f 8e 26 36 00 00    	jle    85641 <<oriole::Parser>::next_event_inner+0x40b1>
   8201b:	4c 01 ed             	add    %r13,%rbp
   8201e:	45 31 e4             	xor    %r12d,%r12d
   82021:	4c 89 d9             	mov    %r11,%rcx
   82024:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   8202b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   82030:	0f b6 31             	movzbl (%rcx),%esi
   82033:	40 84 f6             	test   %sil,%sil
   82036:	78 06                	js     8203e <<oriole::Parser>::next_event_inner+0xaae>
   82038:	48 8d 51 01          	lea    0x1(%rcx),%rdx
   8203c:	eb 72                	jmp    820b0 <<oriole::Parser>::next_event_inner+0xb20>
   8203e:	89 f7                	mov    %esi,%edi
   82040:	83 e7 1f             	and    $0x1f,%edi
   82043:	44 0f b6 49 01       	movzbl 0x1(%rcx),%r9d
   82048:	41 83 e1 3f          	and    $0x3f,%r9d
   8204c:	40 80 fe df          	cmp    $0xdf,%sil
   82050:	76 32                	jbe    82084 <<oriole::Parser>::next_event_inner+0xaf4>
   82052:	44 0f b6 41 02       	movzbl 0x2(%rcx),%r8d
   82057:	41 c1 e1 06          	shl    $0x6,%r9d
   8205b:	41 83 e0 3f          	and    $0x3f,%r8d
   8205f:	45 09 c8             	or     %r9d,%r8d
   82062:	40 80 fe f0          	cmp    $0xf0,%sil
   82066:	72 2a                	jb     82092 <<oriole::Parser>::next_event_inner+0xb02>
   82068:	48 8d 51 04          	lea    0x4(%rcx),%rdx
   8206c:	0f b6 71 03          	movzbl 0x3(%rcx),%esi
   82070:	83 e7 07             	and    $0x7,%edi
   82073:	c1 e7 12             	shl    $0x12,%edi
   82076:	41 c1 e0 06          	shl    $0x6,%r8d
   8207a:	83 e6 3f             	and    $0x3f,%esi
   8207d:	44 09 c6             	or     %r8d,%esi
   82080:	09 fe                	or     %edi,%esi
   82082:	eb 1b                	jmp    8209f <<oriole::Parser>::next_event_inner+0xb0f>
   82084:	48 8d 51 02          	lea    0x2(%rcx),%rdx
   82088:	c1 e7 06             	shl    $0x6,%edi
   8208b:	44 09 cf             	or     %r9d,%edi
   8208e:	89 fe                	mov    %edi,%esi
   82090:	eb 1e                	jmp    820b0 <<oriole::Parser>::next_event_inner+0xb20>
   82092:	48 8d 51 03          	lea    0x3(%rcx),%rdx
   82096:	c1 e7 0c             	shl    $0xc,%edi
   82099:	41 09 f8             	or     %edi,%r8d
   8209c:	44 89 c6             	mov    %r8d,%esi
   8209f:	4c 8b 84 24 10 02 00 	mov    0x210(%rsp),%r8
   820a6:	00 
   820a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   820ae:	00 00 
   820b0:	83 fe 20             	cmp    $0x20,%esi
   820b3:	77 27                	ja     820dc <<oriole::Parser>::next_event_inner+0xb4c>
   820b5:	89 f6                	mov    %esi,%esi
   820b7:	48 bf 00 26 00 00 01 	movabs $0x100002600,%rdi
   820be:	00 00 00 
   820c1:	48 0f a3 f7          	bt     %rsi,%rdi
   820c5:	73 15                	jae    820dc <<oriole::Parser>::next_event_inner+0xb4c>
   820c7:	49 29 cc             	sub    %rcx,%r12
   820ca:	49 01 d4             	add    %rdx,%r12
   820cd:	48 89 d1             	mov    %rdx,%rcx
   820d0:	48 39 ea             	cmp    %rbp,%rdx
   820d3:	0f 85 57 ff ff ff    	jne    82030 <<oriole::Parser>::next_event_inner+0xaa0>
   820d9:	4d 89 c4             	mov    %r8,%r12
   820dc:	4d 85 e4             	test   %r12,%r12
   820df:	0f 84 ea 02 00 00    	je     823cf <<oriole::Parser>::next_event_inner+0xe3f>
   820e5:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   820ec:	00 
   820ed:	4c 89 f6             	mov    %r14,%rsi
   820f0:	4c 89 e2             	mov    %r12,%rdx
   820f3:	e8 38 ac ff ff       	call   7cd30 <<oriole::Parser>::account_source>
   820f8:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   820ff:	ff 
   82100:	0f 85 1e 14 00 00    	jne    83524 <<oriole::Parser>::next_event_inner+0x1f94>
   82106:	41 80 be c1 08 00 00 	cmpb   $0x0,0x8c1(%r14)
   8210d:	00 
   8210e:	0f 84 56 0b 00 00    	je     82c6a <<oriole::Parser>::next_event_inner+0x16da>
   82114:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   8211b:	48 85 c0             	test   %rax,%rax
   8211e:	0f 84 0d 30 00 00    	je     85131 <<oriole::Parser>::next_event_inner+0x3ba1>
   82124:	49 8b 8e 80 01 00 00 	mov    0x180(%r14),%rcx
   8212b:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   8212f:	48 c1 e2 07          	shl    $0x7,%rdx
   82133:	48 8d 04 11          	lea    (%rcx,%rdx,1),%rax
   82137:	83 bc 11 80 fe ff ff 	cmpl   $0x1,-0x180(%rcx,%rdx,1)
   8213e:	01 
   8213f:	0f 85 7b 0a 00 00    	jne    82bc0 <<oriole::Parser>::next_event_inner+0x1630>
   82145:	48 8b 88 88 fe ff ff 	mov    -0x178(%rax),%rcx
   8214c:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   82151:	f3 0f 6f 80 90 fe ff 	movdqu -0x170(%rax),%xmm0
   82158:	ff 
   82159:	66 0f 7f 84 24 20 02 	movdqa %xmm0,0x220(%rsp)
   82160:	00 00 
   82162:	48 8b 98 a0 fe ff ff 	mov    -0x160(%rax),%rbx
   82169:	e9 81 0a 00 00       	jmp    82bef <<oriole::Parser>::next_event_inner+0x165f>
   8216e:	41 0f b6 03          	movzbl (%r11),%eax
   82172:	3c 3c                	cmp    $0x3c,%al
   82174:	0f 84 61 01 00 00    	je     822db <<oriole::Parser>::next_event_inner+0xd4b>
   8217a:	0f b6 c0             	movzbl %al,%eax
   8217d:	83 f8 26             	cmp    $0x26,%eax
   82180:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   82187:	0f 85 8c 01 00 00    	jne    82319 <<oriole::Parser>::next_event_inner+0xd89>
   8218d:	49 83 be 08 02 00 00 	cmpq   $0x0,0x208(%r14)
   82194:	00 
   82195:	75 0e                	jne    821a5 <<oriole::Parser>::next_event_inner+0xc15>
   82197:	41 80 be ba 08 00 00 	cmpb   $0x0,0x8ba(%r14)
   8219e:	00 
   8219f:	0f 84 8a 2d 00 00    	je     84f2f <<oriole::Parser>::next_event_inner+0x399f>
   821a5:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   821ac:	00 
   821ad:	4c 89 f6             	mov    %r14,%rsi
   821b0:	e8 bb b4 ff ff       	call   7d670 <<oriole::Parser>::parse_reference>
   821b5:	e9 a6 f9 ff ff       	jmp    81b60 <<oriole::Parser>::next_event_inner+0x5d0>
   821ba:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   821c1:	00 
   821c2:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   821c7:	48 89 ea             	mov    %rbp,%rdx
   821ca:	31 c9                	xor    %ecx,%ecx
   821cc:	e8 2f c4 fe ff       	call   6e600 <<oriole::encoding::Source>::position_at>
   821d1:	c6 84 24 b0 00 00 00 	movb   $0x1e,0xb0(%rsp)
   821d8:	1e 
   821d9:	48 8d 05 4f 0b f9 ff 	lea    -0x6f4b1(%rip),%rax        # 12d2f <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x6393>
   821e0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   821e7:	00 
   821e8:	48 c7 84 24 88 00 00 	movq   $0x2a,0x88(%rsp)
   821ef:	00 2a 00 00 00 
   821f4:	f3 0f 6f 84 24 90 00 	movdqu 0x90(%rsp),%xmm0
   821fb:	00 00 
   821fd:	f3 0f 6f 8c 24 a0 00 	movdqu 0xa0(%rsp),%xmm1
   82204:	00 00 
   82206:	66 0f 7f 44 24 30    	movdqa %xmm0,0x30(%rsp)
   8220c:	66 0f 7f 4c 24 40    	movdqa %xmm1,0x40(%rsp)
   82212:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   82219:	00 
   8221a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   8221f:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
   82226:	00 
   82227:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   8222c:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   82233:	00 
   82234:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   82239:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   82240:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   82245:	3c ff                	cmp    $0xff,%al
   82247:	0f 84 1e 13 00 00    	je     8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   8224d:	e9 62 2b 00 00       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   82252:	31 ff                	xor    %edi,%edi
   82254:	49 89 be 40 04 00 00 	mov    %rdi,0x440(%r14)
   8225b:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   82260:	48 01 d0             	add    %rdx,%rax
   82263:	49 89 86 50 04 00 00 	mov    %rax,0x450(%r14)
   8226a:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   82271:	00 
   82272:	4c 89 f6             	mov    %r14,%rsi
   82275:	e8 c6 13 01 00       	call   93640 <<oriole::Parser>::conditional_raw>
   8227a:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   82281:	ff 
   82282:	0f 84 a0 01 00 00    	je     82428 <<oriole::Parser>::next_event_inner+0xe98>
   82288:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   8228f:	00 
   82290:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   82295:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   8229c:	00 00 
   8229e:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   822a5:	00 00 
   822a7:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   822ae:	00 00 
   822b0:	66 0f 7f 54 24 40    	movdqa %xmm2,0x40(%rsp)
   822b6:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   822bc:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   822c2:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   822c9:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   822ce:	3c ff                	cmp    $0xff,%al
   822d0:	0f 84 95 12 00 00    	je     8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   822d6:	e9 d9 2a 00 00       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   822db:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   822e0:	e8 fb d7 fe ff       	call   6fae0 <<oriole::encoding::Source>::remaining>
   822e5:	48 89 d1             	mov    %rdx,%rcx
   822e8:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   822ed:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
   822f2:	48 83 fa 03          	cmp    $0x3,%rdx
   822f6:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   822fd:	49 8d ae f0 04 00 00 	lea    0x4f0(%r14),%rbp
   82304:	0f 83 11 02 00 00    	jae    8251b <<oriole::Parser>::next_event_inner+0xf8b>
   8230a:	48 83 f9 02          	cmp    $0x2,%rcx
   8230e:	0f 84 60 02 00 00    	je     82574 <<oriole::Parser>::next_event_inner+0xfe4>
   82314:	e9 87 2d 00 00       	jmp    850a0 <<oriole::Parser>::next_event_inner+0x3b10>
   82319:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   82320:	00 
   82321:	4c 89 f6             	mov    %r14,%rsi
   82324:	e8 57 6f ff ff       	call   79280 <<oriole::Parser>::parse_text>
   82329:	e9 32 f8 ff ff       	jmp    81b60 <<oriole::Parser>::next_event_inner+0x5d0>
   8232e:	0f 85 89 33 00 00    	jne    856bd <<oriole::Parser>::next_event_inner+0x412d>
   82334:	48 89 ce             	mov    %rcx,%rsi
   82337:	4c 29 ee             	sub    %r13,%rsi
   8233a:	4f 8d 24 29          	lea    (%r9,%r13,1),%r12
   8233e:	48 85 ed             	test   %rbp,%rbp
   82341:	74 17                	je     8235a <<oriole::Parser>::next_event_inner+0xdca>
   82343:	48 39 f5             	cmp    %rsi,%rbp
   82346:	73 0c                	jae    82354 <<oriole::Parser>::next_event_inner+0xdc4>
   82348:	41 80 3c 2c c0       	cmpb   $0xc0,(%r12,%rbp,1)
   8234d:	7d 0b                	jge    8235a <<oriole::Parser>::next_event_inner+0xdca>
   8234f:	e9 7f 33 00 00       	jmp    856d3 <<oriole::Parser>::next_event_inner+0x4143>
   82354:	0f 85 79 33 00 00    	jne    856d3 <<oriole::Parser>::next_event_inner+0x4143>
   8235a:	48 83 ff 01          	cmp    $0x1,%rdi
   8235e:	75 55                	jne    823b5 <<oriole::Parser>::next_event_inner+0xe25>
   82360:	41 80 be b8 08 00 00 	cmpb   $0x0,0x8b8(%r14)
   82367:	00 
   82368:	74 0a                	je     82374 <<oriole::Parser>::next_event_inner+0xde4>
   8236a:	41 80 be 28 01 00 00 	cmpb   $0x1,0x128(%r14)
   82371:	01 
   82372:	75 41                	jne    823b5 <<oriole::Parser>::next_event_inner+0xe25>
   82374:	41 80 be f8 07 00 00 	cmpb   $0xff,0x7f8(%r14)
   8237b:	ff 
   8237c:	75 37                	jne    823b5 <<oriole::Parser>::next_event_inner+0xe25>
   8237e:	45 31 c0             	xor    %r8d,%r8d
   82381:	48 83 fd 03          	cmp    $0x3,%rbp
   82385:	0f 82 c6 00 00 00    	jb     82451 <<oriole::Parser>::next_event_inner+0xec1>
   8238b:	41 0f b7 04 24       	movzwl (%r12),%eax
   82390:	35 5d 5d 00 00       	xor    $0x5d5d,%eax
   82395:	41 0f b6 4c 24 02    	movzbl 0x2(%r12),%ecx
   8239b:	83 f1 3e             	xor    $0x3e,%ecx
   8239e:	66 09 c1             	or     %ax,%cx
   823a1:	0f 84 47 01 00 00    	je     824ee <<oriole::Parser>::next_event_inner+0xf5e>
   823a7:	48 89 5c 24 70       	mov    %rbx,0x70(%rsp)
   823ac:	4d 8d 14 2c          	lea    (%r12,%rbp,1),%r10
   823b0:	e9 aa 00 00 00       	jmp    8245f <<oriole::Parser>::next_event_inner+0xecf>
   823b5:	4d 85 ed             	test   %r13,%r13
   823b8:	0f 84 82 00 00 00    	je     82440 <<oriole::Parser>::next_event_inner+0xeb0>
   823be:	4c 39 e9             	cmp    %r13,%rcx
   823c1:	76 77                	jbe    8243a <<oriole::Parser>::next_event_inner+0xeaa>
   823c3:	41 80 3c 24 bf       	cmpb   $0xbf,(%r12)
   823c8:	7f 76                	jg     82440 <<oriole::Parser>::next_event_inner+0xeb0>
   823ca:	e9 ee 32 00 00       	jmp    856bd <<oriole::Parser>::next_event_inner+0x412d>
   823cf:	48 89 df             	mov    %rbx,%rdi
   823d2:	41 0f b6 1b          	movzbl (%r11),%ebx
   823d6:	89 d9                	mov    %ebx,%ecx
   823d8:	84 db                	test   %bl,%bl
   823da:	0f 89 ec 0d 00 00    	jns    831cc <<oriole::Parser>::next_event_inner+0x1c3c>
   823e0:	89 d9                	mov    %ebx,%ecx
   823e2:	83 e1 1f             	and    $0x1f,%ecx
   823e5:	41 0f b6 73 01       	movzbl 0x1(%r11),%esi
   823ea:	83 e6 3f             	and    $0x3f,%esi
   823ed:	80 fb df             	cmp    $0xdf,%bl
   823f0:	0f 86 c0 07 00 00    	jbe    82bb6 <<oriole::Parser>::next_event_inner+0x1626>
   823f6:	41 0f b6 53 02       	movzbl 0x2(%r11),%edx
   823fb:	c1 e6 06             	shl    $0x6,%esi
   823fe:	83 e2 3f             	and    $0x3f,%edx
   82401:	09 f2                	or     %esi,%edx
   82403:	80 fb f0             	cmp    $0xf0,%bl
   82406:	0f 82 b9 0d 00 00    	jb     831c5 <<oriole::Parser>::next_event_inner+0x1c35>
   8240c:	41 0f b6 73 03       	movzbl 0x3(%r11),%esi
   82411:	83 e1 07             	and    $0x7,%ecx
   82414:	c1 e1 12             	shl    $0x12,%ecx
   82417:	c1 e2 06             	shl    $0x6,%edx
   8241a:	83 e6 3f             	and    $0x3f,%esi
   8241d:	09 d6                	or     %edx,%esi
   8241f:	09 ce                	or     %ecx,%esi
   82421:	89 f1                	mov    %esi,%ecx
   82423:	e9 a4 0d 00 00       	jmp    831cc <<oriole::Parser>::next_event_inner+0x1c3c>
   82428:	b0 01                	mov    $0x1,%al
   8242a:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   82431:	88 44 24 20          	mov    %al,0x20(%rsp)
   82435:	e9 31 11 00 00       	jmp    8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   8243a:	0f 85 7d 32 00 00    	jne    856bd <<oriole::Parser>::next_event_inner+0x412d>
   82440:	48 39 f5             	cmp    %rsi,%rbp
   82443:	41 0f 94 c0          	sete   %r8b
   82447:	48 83 fd 03          	cmp    $0x3,%rbp
   8244b:	0f 83 3a ff ff ff    	jae    8238b <<oriole::Parser>::next_event_inner+0xdfb>
   82451:	48 89 5c 24 70       	mov    %rbx,0x70(%rsp)
   82456:	4d 8d 14 2c          	lea    (%r12,%rbp,1),%r10
   8245a:	48 85 ed             	test   %rbp,%rbp
   8245d:	74 37                	je     82496 <<oriole::Parser>::next_event_inner+0xf06>
   8245f:	48 83 ff 01          	cmp    $0x1,%rdi
   82463:	0f 95 c1             	setne  %cl
   82466:	41 0f b6 04 24       	movzbl (%r12),%eax
   8246b:	3c 0d                	cmp    $0xd,%al
   8246d:	0f 95 c2             	setne  %dl
   82470:	3c 0a                	cmp    $0xa,%al
   82472:	74 49                	je     824bd <<oriole::Parser>::next_event_inner+0xf2d>
   82474:	08 d1                	or     %dl,%cl
   82476:	74 45                	je     824bd <<oriole::Parser>::next_event_inner+0xf2d>
   82478:	48 83 fd 03          	cmp    $0x3,%rbp
   8247c:	0f 92 c1             	setb   %cl
   8247f:	3c 5d                	cmp    $0x5d,%al
   82481:	0f 95 c0             	setne  %al
   82484:	08 c8                	or     %cl,%al
   82486:	0f 84 9c 01 00 00    	je     82628 <<oriole::Parser>::next_event_inner+0x1098>
   8248c:	48 83 fd 01          	cmp    $0x1,%rbp
   82490:	0f 85 ae 01 00 00    	jne    82644 <<oriole::Parser>::next_event_inner+0x10b4>
   82496:	4c 89 94 24 20 02 00 	mov    %r10,0x220(%rsp)
   8249d:	00 
   8249e:	4d 89 cf             	mov    %r9,%r15
   824a1:	4c 89 e3             	mov    %r12,%rbx
   824a4:	45 89 c4             	mov    %r8d,%r12d
   824a7:	e8 54 f2 01 00       	call   a1700 <<core::ops::control_flow::ControlFlow<&[u8]> as core::ops::try_trait::Try>::from_output>
   824ac:	45 89 e0             	mov    %r12d,%r8d
   824af:	49 89 dc             	mov    %rbx,%r12
   824b2:	4d 89 f9             	mov    %r15,%r9
   824b5:	49 89 d7             	mov    %rdx,%r15
   824b8:	e9 bb 03 00 00       	jmp    82878 <<oriole::Parser>::next_event_inner+0x12e8>
   824bd:	4c 89 94 24 20 02 00 	mov    %r10,0x220(%rsp)
   824c4:	00 
   824c5:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   824cb:	48 83 fd 01          	cmp    $0x1,%rbp
   824cf:	0f 84 9e 03 00 00    	je     82873 <<oriole::Parser>::next_event_inner+0x12e3>
   824d5:	41 0f b7 04 24       	movzwl (%r12),%eax
   824da:	45 31 ff             	xor    %r15d,%r15d
   824dd:	3d 0d 0a 00 00       	cmp    $0xa0d,%eax
   824e2:	41 0f 94 c7          	sete   %r15b
   824e6:	49 ff c7             	inc    %r15
   824e9:	e9 85 03 00 00       	jmp    82873 <<oriole::Parser>::next_event_inner+0x12e3>
   824ee:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   824f3:	83 3f 01             	cmpl   $0x1,(%rdi)
   824f6:	0f 85 30 02 00 00    	jne    8272c <<oriole::Parser>::next_event_inner+0x119c>
   824fc:	4c 8b bb 88 fe ff ff 	mov    -0x178(%rbx),%r15
   82503:	0f 10 83 90 fe ff ff 	movups -0x170(%rbx),%xmm0
   8250a:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   8250f:	48 8b 9b a0 fe ff ff 	mov    -0x160(%rbx),%rbx
   82516:	e9 2d 02 00 00       	jmp    82748 <<oriole::Parser>::next_event_inner+0x11b8>
   8251b:	0f b7 10             	movzwl (%rax),%edx
   8251e:	81 f2 3c 21 00 00    	xor    $0x213c,%edx
   82524:	0f b6 70 02          	movzbl 0x2(%rax),%esi
   82528:	83 f6 5b             	xor    $0x5b,%esi
   8252b:	66 09 d6             	or     %dx,%si
   8252e:	40 0f 95 c7          	setne  %dil
   82532:	49 8b 96 08 02 00 00 	mov    0x208(%r14),%rdx
   82539:	48 85 d2             	test   %rdx,%rdx
   8253c:	41 0f 95 c0          	setne  %r8b
   82540:	41 0f b6 b6 ba 08 00 	movzbl 0x8ba(%r14),%esi
   82547:	00 
   82548:	41 08 f0             	or     %sil,%r8b
   8254b:	41 08 f8             	or     %dil,%r8b
   8254e:	41 f6 c0 01          	test   $0x1,%r8b
   82552:	0f 84 72 2b 00 00    	je     850ca <<oriole::Parser>::next_event_inner+0x3b3a>
   82558:	48 83 f9 03          	cmp    $0x3,%rcx
   8255c:	74 16                	je     82574 <<oriole::Parser>::next_event_inner+0xfe4>
   8255e:	81 38 3c 21 2d 2d    	cmpl   $0x2d2d213c,(%rax)
   82564:	0f 84 2e 07 00 00    	je     82c98 <<oriole::Parser>::next_event_inner+0x1708>
   8256a:	48 83 f9 09          	cmp    $0x9,%rcx
   8256e:	0f 83 07 10 00 00    	jae    8357b <<oriole::Parser>::next_event_inner+0x1feb>
   82574:	66 81 38 3c 3f       	cmpw   $0x3f3c,(%rax)
   82579:	0f 84 4d 01 00 00    	je     826cc <<oriole::Parser>::next_event_inner+0x113c>
   8257f:	66 81 38 3c 2f       	cmpw   $0x2f3c,(%rax)
   82584:	74 2a                	je     825b0 <<oriole::Parser>::next_event_inner+0x1020>
   82586:	48 83 f9 03          	cmp    $0x3,%rcx
   8258a:	72 19                	jb     825a5 <<oriole::Parser>::next_event_inner+0x1015>
   8258c:	0f b7 10             	movzwl (%rax),%edx
   8258f:	81 f2 3c 21 00 00    	xor    $0x213c,%edx
   82595:	0f b6 70 02          	movzbl 0x2(%rax),%esi
   82599:	83 f6 5b             	xor    $0x5b,%esi
   8259c:	66 09 d6             	or     %dx,%si
   8259f:	0f 84 dd 2b 00 00    	je     85182 <<oriole::Parser>::next_event_inner+0x3bf2>
   825a5:	66 81 38 3c 21       	cmpw   $0x213c,(%rax)
   825aa:	0f 84 9a 2b 00 00    	je     8514a <<oriole::Parser>::next_event_inner+0x3bba>
   825b0:	c6 84 24 30 03 00 00 	movb   $0x0,0x330(%rsp)
   825b7:	00 
   825b8:	0f b7 30             	movzwl (%rax),%esi
   825bb:	31 d2                	xor    %edx,%edx
   825bd:	81 fe 3c 2f 00 00    	cmp    $0x2f3c,%esi
   825c3:	0f 94 c2             	sete   %dl
   825c6:	48 ff c2             	inc    %rdx
   825c9:	bb 02 00 00 00       	mov    $0x2,%ebx
   825ce:	48 39 ca             	cmp    %rcx,%rdx
   825d1:	73 0d                	jae    825e0 <<oriole::Parser>::next_event_inner+0x1050>
   825d3:	80 3c 10 bf          	cmpb   $0xbf,(%rax,%rdx,1)
   825d7:	48 89 d3             	mov    %rdx,%rbx
   825da:	0f 8e d7 2a 00 00    	jle    850b7 <<oriole::Parser>::next_event_inner+0x3b27>
   825e0:	48 8d 14 18          	lea    (%rax,%rbx,1),%rdx
   825e4:	48 01 c1             	add    %rax,%rcx
   825e7:	48 89 94 24 50 02 00 	mov    %rdx,0x250(%rsp)
   825ee:	00 
   825ef:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
   825f6:	00 
   825f7:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   825fe:	00 
   825ff:	e8 1c 82 fc ff       	call   4a820 <core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>>
   82604:	a8 01                	test   $0x1,%al
   82606:	0f 84 94 06 00 00    	je     82ca0 <<oriole::Parser>::next_event_inner+0x1710>
   8260c:	41 0f b6 be cc 07 00 	movzbl 0x7cc(%r14),%edi
   82613:	00 
   82614:	89 d6                	mov    %edx,%esi
   82616:	e8 05 37 fd ff       	call   55d20 <<oriole::names::NameRules>::is_name_start>
   8261b:	84 c0                	test   %al,%al
   8261d:	0f 85 7d 06 00 00    	jne    82ca0 <<oriole::Parser>::next_event_inner+0x1710>
   82623:	e9 72 2c 00 00       	jmp    8529a <<oriole::Parser>::next_event_inner+0x3d0a>
   82628:	41 0f b7 04 24       	movzwl (%r12),%eax
   8262d:	35 5d 5d 00 00       	xor    $0x5d5d,%eax
   82632:	41 0f b6 4c 24 02    	movzbl 0x2(%r12),%ecx
   82638:	83 f1 3e             	xor    $0x3e,%ecx
   8263b:	66 09 c1             	or     %ax,%cx
   8263e:	0f 84 24 02 00 00    	je     82868 <<oriole::Parser>::next_event_inner+0x12d8>
   82644:	49 8d 44 24 01       	lea    0x1(%r12),%rax
   82649:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
   82650:	eb 0f                	jmp    82661 <<oriole::Parser>::next_event_inner+0x10d1>
   82652:	48 ff c0             	inc    %rax
   82655:	49 ff cf             	dec    %r15
   82658:	4c 39 d0             	cmp    %r10,%rax
   8265b:	0f 84 35 fe ff ff    	je     82496 <<oriole::Parser>::next_event_inner+0xf06>
   82661:	48 83 ff 01          	cmp    $0x1,%rdi
   82665:	0f 95 c2             	setne  %dl
   82668:	0f b6 08             	movzbl (%rax),%ecx
   8266b:	80 f9 0d             	cmp    $0xd,%cl
   8266e:	40 0f 95 c6          	setne  %sil
   82672:	80 f9 0a             	cmp    $0xa,%cl
   82675:	74 32                	je     826a9 <<oriole::Parser>::next_event_inner+0x1119>
   82677:	40 08 f2             	or     %sil,%dl
   8267a:	74 2d                	je     826a9 <<oriole::Parser>::next_event_inner+0x1119>
   8267c:	80 f9 5d             	cmp    $0x5d,%cl
   8267f:	75 d1                	jne    82652 <<oriole::Parser>::next_event_inner+0x10c2>
   82681:	80 38 c0             	cmpb   $0xc0,(%rax)
   82684:	0f 8c 17 30 00 00    	jl     856a1 <<oriole::Parser>::next_event_inner+0x4111>
   8268a:	49 8d 0c 2f          	lea    (%r15,%rbp,1),%rcx
   8268e:	48 83 f9 03          	cmp    $0x3,%rcx
   82692:	72 be                	jb     82652 <<oriole::Parser>::next_event_inner+0x10c2>
   82694:	0f b7 08             	movzwl (%rax),%ecx
   82697:	81 f1 5d 5d 00 00    	xor    $0x5d5d,%ecx
   8269d:	0f b6 50 02          	movzbl 0x2(%rax),%edx
   826a1:	83 f2 3e             	xor    $0x3e,%edx
   826a4:	66 09 ca             	or     %cx,%dx
   826a7:	75 a9                	jne    82652 <<oriole::Parser>::next_event_inner+0x10c2>
   826a9:	4c 89 94 24 20 02 00 	mov    %r10,0x220(%rsp)
   826b0:	00 
   826b1:	49 f7 df             	neg    %r15
   826b4:	e9 ba 01 00 00       	jmp    82873 <<oriole::Parser>::next_event_inner+0x12e3>
   826b9:	48 89 ea             	mov    %rbp,%rdx
   826bc:	48 85 ed             	test   %rbp,%rbp
   826bf:	0f 85 8f fb ff ff    	jne    82254 <<oriole::Parser>::next_event_inner+0xcc4>
   826c5:	31 c0                	xor    %eax,%eax
   826c7:	e9 5e fd ff ff       	jmp    8242a <<oriole::Parser>::next_event_inner+0xe9a>
   826cc:	c6 84 24 30 03 00 00 	movb   $0x2,0x330(%rsp)
   826d3:	02 
   826d4:	48 83 f9 03          	cmp    $0x3,%rcx
   826d8:	72 0a                	jb     826e4 <<oriole::Parser>::next_event_inner+0x1154>
   826da:	80 78 02 c0          	cmpb   $0xc0,0x2(%rax)
   826de:	0f 8c 53 30 00 00    	jl     85737 <<oriole::Parser>::next_event_inner+0x41a7>
   826e4:	48 8d 50 02          	lea    0x2(%rax),%rdx
   826e8:	48 01 c1             	add    %rax,%rcx
   826eb:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
   826f2:	00 
   826f3:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
   826fa:	00 
   826fb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   82702:	00 
   82703:	e8 18 81 fc ff       	call   4a820 <core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>>
   82708:	a8 01                	test   $0x1,%al
   8270a:	0f 84 90 05 00 00    	je     82ca0 <<oriole::Parser>::next_event_inner+0x1710>
   82710:	41 0f b6 be cc 07 00 	movzbl 0x7cc(%r14),%edi
   82717:	00 
   82718:	89 d6                	mov    %edx,%esi
   8271a:	e8 01 36 fd ff       	call   55d20 <<oriole::names::NameRules>::is_name_start>
   8271f:	84 c0                	test   %al,%al
   82721:	0f 85 79 05 00 00    	jne    82ca0 <<oriole::Parser>::next_event_inner+0x1710>
   82727:	e9 ea 2c 00 00       	jmp    85416 <<oriole::Parser>::next_event_inner+0x3e86>
   8272c:	4c 8b 7b a8          	mov    -0x58(%rbx),%r15
   82730:	0f 10 43 d8          	movups -0x28(%rbx),%xmm0
   82734:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   82739:	ba 03 00 00 00       	mov    $0x3,%edx
   8273e:	31 f6                	xor    %esi,%esi
   82740:	e8 eb d0 fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   82745:	48 89 c3             	mov    %rax,%rbx
   82748:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
   8274f:	00 
   82750:	ba 03 00 00 00       	mov    $0x3,%edx
   82755:	4c 89 e7             	mov    %r12,%rdi
   82758:	4c 89 f6             	mov    %r14,%rsi
   8275b:	e8 10 33 00 00       	call   85a70 <<oriole::Parser>::save_current_raw>
   82760:	0f b6 ac 24 b0 00 00 	movzbl 0xb0(%rsp),%ebp
   82767:	00 
   82768:	40 80 fd ff          	cmp    $0xff,%bpl
   8276c:	0f 85 7a 27 00 00    	jne    84eec <<oriole::Parser>::next_event_inner+0x395c>
   82772:	ba 03 00 00 00       	mov    $0x3,%edx
   82777:	4c 89 e7             	mov    %r12,%rdi
   8277a:	4c 89 f6             	mov    %r14,%rsi
   8277d:	e8 0e e8 00 00       	call   90f90 <<oriole::Parser>::consume>
   82782:	0f b6 ac 24 b0 00 00 	movzbl 0xb0(%rsp),%ebp
   82789:	00 
   8278a:	40 80 fd ff          	cmp    $0xff,%bpl
   8278e:	0f 85 58 27 00 00    	jne    84eec <<oriole::Parser>::next_event_inner+0x395c>
   82794:	41 c6 86 b7 08 00 00 	movb   $0x0,0x8b7(%r14)
   8279b:	00 
   8279c:	48 c7 84 24 b8 00 00 	movq   $0xf,0xb8(%rsp)
   827a3:	00 0f 00 00 00 
   827a8:	4c 89 bc 24 30 01 00 	mov    %r15,0x130(%rsp)
   827af:	00 
   827b0:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   827b6:	f3 0f 7f 84 24 38 01 	movdqu %xmm0,0x138(%rsp)
   827bd:	00 00 
   827bf:	48 89 9c 24 48 01 00 	mov    %rbx,0x148(%rsp)
   827c6:	00 
   827c7:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   827ce:	00 ff ff ff ff 
   827d3:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   827da:	00 
   827db:	4c 89 e6             	mov    %r12,%rsi
   827de:	e8 bd 4c fd ff       	call   574a0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   827e3:	3c ff                	cmp    $0xff,%al
   827e5:	0f 85 95 28 00 00    	jne    85080 <<oriole::Parser>::next_event_inner+0x3af0>
   827eb:	4c 8b ac 24 28 03 00 	mov    0x328(%rsp),%r13
   827f2:	00 
   827f3:	49 81 e5 00 ff ff ff 	and    $0xffffffffffffff00,%r13
   827fa:	49 ff c5             	inc    %r13
   827fd:	e9 96 03 00 00       	jmp    82b98 <<oriole::Parser>::next_event_inner+0x1608>
   82802:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   82809:	00 
   8280a:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   8280f:	48 89 ea             	mov    %rbp,%rdx
   82812:	31 c9                	xor    %ecx,%ecx
   82814:	e8 e7 bd fe ff       	call   6e600 <<oriole::encoding::Source>::position_at>
   82819:	c6 84 24 b0 00 00 00 	movb   $0x1e,0xb0(%rsp)
   82820:	1e 
   82821:	48 8d 05 d2 ef f8 ff 	lea    -0x7102e(%rip),%rax        # 117fa <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4e5e>
   82828:	e9 b3 f9 ff ff       	jmp    821e0 <<oriole::Parser>::next_event_inner+0xc50>
   8282d:	41 b8 28 00 00 00    	mov    $0x28,%r8d
   82833:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   82838:	4c 89 f6             	mov    %r14,%rsi
   8283b:	ba 03 00 00 00       	mov    $0x3,%edx
   82840:	48 8d 0d c0 04 f9 ff 	lea    -0x6fb40(%rip),%rcx        # 12d07 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x636b>
   82847:	49 89 e9             	mov    %rbp,%r9
   8284a:	e8 c1 e6 00 00       	call   90f10 <<oriole::Parser>::err_at>
   8284f:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   82856:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   8285b:	3c ff                	cmp    $0xff,%al
   8285d:	0f 84 08 0d 00 00    	je     8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   82863:	e9 4c 25 00 00       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   82868:	4c 89 94 24 20 02 00 	mov    %r10,0x220(%rsp)
   8286f:	00 
   82870:	45 31 ff             	xor    %r15d,%r15d
   82873:	b8 01 00 00 00       	mov    $0x1,%eax
   82878:	a8 01                	test   $0x1,%al
   8287a:	4c 0f 44 fd          	cmove  %rbp,%r15
   8287e:	49 39 ef             	cmp    %rbp,%r15
   82881:	0f 95 c0             	setne  %al
   82884:	44 08 c0             	or     %r8b,%al
   82887:	a8 01                	test   $0x1,%al
   82889:	74 0a                	je     82895 <<oriole::Parser>::next_event_inner+0x1305>
   8288b:	4d 85 ff             	test   %r15,%r15
   8288e:	75 74                	jne    82904 <<oriole::Parser>::next_event_inner+0x1374>
   82890:	e9 8d 00 00 00       	jmp    82922 <<oriole::Parser>::next_event_inner+0x1392>
   82895:	48 85 ed             	test   %rbp,%rbp
   82898:	0f 84 84 00 00 00    	je     82922 <<oriole::Parser>::next_event_inner+0x1392>
   8289e:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   828a5:	00 
   828a6:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
   828aa:	31 c9                	xor    %ecx,%ecx
   828ac:	3c 0d                	cmp    $0xd,%al
   828ae:	0f 94 c1             	sete   %cl
   828b1:	49 89 ef             	mov    %rbp,%r15
   828b4:	49 29 cf             	sub    %rcx,%r15
   828b7:	48 f7 d9             	neg    %rcx
   828ba:	48 8d 3c 29          	lea    (%rcx,%rbp,1),%rdi
   828be:	48 ff cf             	dec    %rdi
   828c1:	48 39 ef             	cmp    %rbp,%rdi
   828c4:	73 25                	jae    828eb <<oriole::Parser>::next_event_inner+0x135b>
   828c6:	4b 8d 04 29          	lea    (%r9,%r13,1),%rax
   828ca:	48 ff c8             	dec    %rax
   828cd:	4c 89 f9             	mov    %r15,%rcx
   828d0:	49 89 cf             	mov    %rcx,%r15
   828d3:	48 83 e9 01          	sub    $0x1,%rcx
   828d7:	72 49                	jb     82922 <<oriole::Parser>::next_event_inner+0x1392>
   828d9:	49 8d 57 02          	lea    0x2(%r15),%rdx
   828dd:	48 39 ea             	cmp    %rbp,%rdx
   828e0:	72 22                	jb     82904 <<oriole::Parser>::next_event_inner+0x1374>
   828e2:	42 80 3c 38 5d       	cmpb   $0x5d,(%rax,%r15,1)
   828e7:	74 e7                	je     828d0 <<oriole::Parser>::next_event_inner+0x1340>
   828e9:	eb 19                	jmp    82904 <<oriole::Parser>::next_event_inner+0x1374>
   828eb:	4d 85 ff             	test   %r15,%r15
   828ee:	74 32                	je     82922 <<oriole::Parser>::next_event_inner+0x1392>
   828f0:	31 c9                	xor    %ecx,%ecx
   828f2:	3c 0d                	cmp    $0xd,%al
   828f4:	0f 94 c1             	sete   %cl
   828f7:	48 83 c1 fd          	add    $0xfffffffffffffffd,%rcx
   828fb:	48 39 e9             	cmp    %rbp,%rcx
   828fe:	0f 83 23 2e 00 00    	jae    85727 <<oriole::Parser>::next_event_inner+0x4197>
   82904:	49 39 ef             	cmp    %rbp,%r15
   82907:	73 2d                	jae    82936 <<oriole::Parser>::next_event_inner+0x13a6>
   82909:	43 80 3c 3c c0       	cmpb   $0xc0,(%r12,%r15,1)
   8290e:	4c 8d ac 24 80 00 00 	lea    0x80(%rsp),%r13
   82915:	00 
   82916:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
   8291b:	7d 2c                	jge    82949 <<oriole::Parser>::next_event_inner+0x13b9>
   8291d:	e9 cf 2d 00 00       	jmp    856f1 <<oriole::Parser>::next_event_inner+0x4161>
   82922:	4c 8b ac 24 28 03 00 	mov    0x328(%rsp),%r13
   82929:	00 
   8292a:	49 81 e5 00 ff ff ff 	and    $0xffffffffffffff00,%r13
   82931:	e9 62 02 00 00       	jmp    82b98 <<oriole::Parser>::next_event_inner+0x1608>
   82936:	4c 8d ac 24 80 00 00 	lea    0x80(%rsp),%r13
   8293d:	00 
   8293e:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
   82943:	0f 85 a8 2d 00 00    	jne    856f1 <<oriole::Parser>::next_event_inner+0x4161>
   82949:	4c 89 e7             	mov    %r12,%rdi
   8294c:	4c 89 fe             	mov    %r15,%rsi
   8294f:	e8 ec e3 01 00       	call   a0d40 <oriole::names::invalid_xml_char>
   82954:	a8 01                	test   $0x1,%al
   82956:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   8295b:	74 0c                	je     82969 <<oriole::Parser>::next_event_inner+0x13d9>
   8295d:	48 85 d2             	test   %rdx,%rdx
   82960:	0f 84 88 26 00 00    	je     84fee <<oriole::Parser>::next_event_inner+0x3a5e>
   82966:	49 89 d7             	mov    %rdx,%r15
   82969:	49 39 ef             	cmp    %rbp,%r15
   8296c:	73 0c                	jae    8297a <<oriole::Parser>::next_event_inner+0x13ea>
   8296e:	43 80 3c 3c c0       	cmpb   $0xc0,(%r12,%r15,1)
   82973:	7d 0b                	jge    82980 <<oriole::Parser>::next_event_inner+0x13f0>
   82975:	e9 6e 2d 00 00       	jmp    856e8 <<oriole::Parser>::next_event_inner+0x4158>
   8297a:	0f 85 68 2d 00 00    	jne    856e8 <<oriole::Parser>::next_event_inner+0x4158>
   82980:	83 3f 01             	cmpl   $0x1,(%rdi)
   82983:	75 24                	jne    829a9 <<oriole::Parser>::next_event_inner+0x1419>
   82985:	48 8b 83 88 fe ff ff 	mov    -0x178(%rbx),%rax
   8298c:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   82991:	0f 10 83 90 fe ff ff 	movups -0x170(%rbx),%xmm0
   82998:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   8299f:	00 
   829a0:	48 8b 9b a0 fe ff ff 	mov    -0x160(%rbx),%rbx
   829a7:	eb 22                	jmp    829cb <<oriole::Parser>::next_event_inner+0x143b>
   829a9:	48 8b 43 a8          	mov    -0x58(%rbx),%rax
   829ad:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   829b2:	0f 10 43 d8          	movups -0x28(%rbx),%xmm0
   829b6:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   829bd:	00 
   829be:	31 f6                	xor    %esi,%esi
   829c0:	4c 89 fa             	mov    %r15,%rdx
   829c3:	e8 68 ce fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   829c8:	48 89 c3             	mov    %rax,%rbx
   829cb:	4c 89 ef             	mov    %r13,%rdi
   829ce:	4c 89 f6             	mov    %r14,%rsi
   829d1:	4c 89 e2             	mov    %r12,%rdx
   829d4:	4c 89 f9             	mov    %r15,%rcx
   829d7:	e8 74 a5 ff ff       	call   7cf50 <<oriole::Parser>::character_data>
   829dc:	4c 89 ef             	mov    %r13,%rdi
   829df:	4c 8b ac 24 88 00 00 	mov    0x88(%rsp),%r13
   829e6:	00 
   829e7:	4c 8b a4 24 90 00 00 	mov    0x90(%rsp),%r12
   829ee:	00 
   829ef:	f3 0f 6f 8c 24 98 00 	movdqu 0x98(%rsp),%xmm1
   829f6:	00 00 
   829f8:	f3 0f 6f 84 24 a8 00 	movdqu 0xa8(%rsp),%xmm0
   829ff:	00 00 
   82a01:	0f b6 ac 24 b8 00 00 	movzbl 0xb8(%rsp),%ebp
   82a08:	00 
   82a09:	48 8d 8c 24 88 00 00 	lea    0x88(%rsp),%rcx
   82a10:	00 
   82a11:	8b 41 31             	mov    0x31(%rcx),%eax
   82a14:	8b 49 34             	mov    0x34(%rcx),%ecx
   82a17:	89 84 24 10 04 00 00 	mov    %eax,0x410(%rsp)
   82a1e:	89 8c 24 13 04 00 00 	mov    %ecx,0x413(%rsp)
   82a25:	80 bc 24 80 00 00 00 	cmpb   $0x0,0x80(%rsp)
   82a2c:	00 
   82a2d:	74 2b                	je     82a5a <<oriole::Parser>::next_event_inner+0x14ca>
   82a2f:	8b 84 24 10 04 00 00 	mov    0x410(%rsp),%eax
   82a36:	8b 8c 24 13 04 00 00 	mov    0x413(%rsp),%ecx
   82a3d:	89 8c 24 63 03 00 00 	mov    %ecx,0x363(%rsp)
   82a44:	89 84 24 60 03 00 00 	mov    %eax,0x360(%rsp)
   82a4b:	40 80 fd ff          	cmp    $0xff,%bpl
   82a4f:	0f 84 43 01 00 00    	je     82b98 <<oriole::Parser>::next_event_inner+0x1608>
   82a55:	e9 0d 28 00 00       	jmp    85267 <<oriole::Parser>::next_event_inner+0x3cd7>
   82a5a:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
   82a61:	00 
   82a62:	4c 89 a4 24 58 02 00 	mov    %r12,0x258(%rsp)
   82a69:	00 
   82a6a:	f3 0f 7f 8c 24 60 02 	movdqu %xmm1,0x260(%rsp)
   82a71:	00 00 
   82a73:	66 0f 7f 84 24 50 03 	movdqa %xmm0,0x350(%rsp)
   82a7a:	00 00 
   82a7c:	f3 0f 7f 84 24 70 02 	movdqu %xmm0,0x270(%rsp)
   82a83:	00 00 
   82a85:	40 88 ac 24 80 02 00 	mov    %bpl,0x280(%rsp)
   82a8c:	00 
   82a8d:	8b 84 24 10 04 00 00 	mov    0x410(%rsp),%eax
   82a94:	8b 8c 24 13 04 00 00 	mov    0x413(%rsp),%ecx
   82a9b:	48 8d 94 24 58 02 00 	lea    0x258(%rsp),%rdx
   82aa2:	00 
   82aa3:	89 4a 2c             	mov    %ecx,0x2c(%rdx)
   82aa6:	89 42 29             	mov    %eax,0x29(%rdx)
   82aa9:	4c 89 f6             	mov    %r14,%rsi
   82aac:	4c 89 fa             	mov    %r15,%rdx
   82aaf:	e8 bc 2f 00 00       	call   85a70 <<oriole::Parser>::save_current_raw>
   82ab4:	4c 8b a4 24 28 03 00 	mov    0x328(%rsp),%r12
   82abb:	00 
   82abc:	0f b6 ac 24 b0 00 00 	movzbl 0xb0(%rsp),%ebp
   82ac3:	00 
   82ac4:	40 80 fd ff          	cmp    $0xff,%bpl
   82ac8:	0f 85 4f 23 00 00    	jne    84e1d <<oriole::Parser>::next_event_inner+0x388d>
   82ace:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   82ad5:	00 
   82ad6:	4c 89 f6             	mov    %r14,%rsi
   82ad9:	4c 89 fa             	mov    %r15,%rdx
   82adc:	e8 af e4 00 00       	call   90f90 <<oriole::Parser>::consume>
   82ae1:	0f b6 ac 24 b0 00 00 	movzbl 0xb0(%rsp),%ebp
   82ae8:	00 
   82ae9:	40 80 fd ff          	cmp    $0xff,%bpl
   82aed:	0f 85 2a 23 00 00    	jne    84e1d <<oriole::Parser>::next_event_inner+0x388d>
   82af3:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
   82afa:	00 
   82afb:	48 8d 8c 24 88 00 00 	lea    0x88(%rsp),%rcx
   82b02:	00 
   82b03:	48 89 41 68          	mov    %rax,0x68(%rcx)
   82b07:	0f 10 84 24 50 02 00 	movups 0x250(%rsp),%xmm0
   82b0e:	00 
   82b0f:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   82b16:	00 00 
   82b18:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   82b1f:	00 00 
   82b21:	f3 0f 7f 51 58       	movdqu %xmm2,0x58(%rcx)
   82b26:	f3 0f 7f 49 48       	movdqu %xmm1,0x48(%rcx)
   82b2b:	0f 11 41 38          	movups %xmm0,0x38(%rcx)
   82b2f:	48 c7 84 24 b8 00 00 	movq   $0xb,0xb8(%rsp)
   82b36:	00 0b 00 00 00 
   82b3b:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   82b40:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   82b47:	00 
   82b48:	66 0f 6f 84 24 20 02 	movdqa 0x220(%rsp),%xmm0
   82b4f:	00 00 
   82b51:	f3 0f 7f 84 24 38 01 	movdqu %xmm0,0x138(%rsp)
   82b58:	00 00 
   82b5a:	48 89 9c 24 48 01 00 	mov    %rbx,0x148(%rsp)
   82b61:	00 
   82b62:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   82b69:	00 ff ff ff ff 
   82b6e:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   82b75:	00 
   82b76:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
   82b7d:	00 
   82b7e:	e8 1d 49 fd ff       	call   574a0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   82b83:	3c ff                	cmp    $0xff,%al
   82b85:	0f 85 81 24 00 00    	jne    8500c <<oriole::Parser>::next_event_inner+0x3a7c>
   82b8b:	49 81 e4 00 ff ff ff 	and    $0xffffffffffffff00,%r12
   82b92:	49 ff c4             	inc    %r12
   82b95:	4d 89 e5             	mov    %r12,%r13
   82b98:	4c 89 ac 24 28 03 00 	mov    %r13,0x328(%rsp)
   82b9f:	00 
   82ba0:	41 f6 c5 01          	test   $0x1,%r13b
   82ba4:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   82bab:	0f 85 ef ec ff ff    	jne    818a0 <<oriole::Parser>::next_event_inner+0x310>
   82bb1:	e9 51 1f 00 00       	jmp    84b07 <<oriole::Parser>::next_event_inner+0x3577>
   82bb6:	c1 e1 06             	shl    $0x6,%ecx
   82bb9:	09 f1                	or     %esi,%ecx
   82bbb:	e9 0c 06 00 00       	jmp    831cc <<oriole::Parser>::next_event_inner+0x1c3c>
   82bc0:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
   82bc4:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   82bcb:	48 8b 48 a8          	mov    -0x58(%rax),%rcx
   82bcf:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
   82bd4:	f3 0f 6f 40 d8       	movdqu -0x28(%rax),%xmm0
   82bd9:	66 0f 7f 84 24 20 02 	movdqa %xmm0,0x220(%rsp)
   82be0:	00 00 
   82be2:	31 f6                	xor    %esi,%esi
   82be4:	4c 89 e2             	mov    %r12,%rdx
   82be7:	e8 44 cc fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   82bec:	48 89 c3             	mov    %rax,%rbx
   82bef:	4c 8d bc 24 80 00 00 	lea    0x80(%rsp),%r15
   82bf6:	00 
   82bf7:	4c 89 ff             	mov    %r15,%rdi
   82bfa:	4c 89 f6             	mov    %r14,%rsi
   82bfd:	4c 89 e2             	mov    %r12,%rdx
   82c00:	e8 6b 2e 00 00       	call   85a70 <<oriole::Parser>::save_current_raw>
   82c05:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   82c0c:	ff 
   82c0d:	0f 85 11 09 00 00    	jne    83524 <<oriole::Parser>::next_event_inner+0x1f94>
   82c13:	48 c7 84 24 b8 00 00 	movq   $0x3,0xb8(%rsp)
   82c1a:	00 03 00 00 00 
   82c1f:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   82c24:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   82c2b:	00 
   82c2c:	66 0f 6f 84 24 20 02 	movdqa 0x220(%rsp),%xmm0
   82c33:	00 00 
   82c35:	f3 0f 7f 84 24 38 01 	movdqu %xmm0,0x138(%rsp)
   82c3c:	00 00 
   82c3e:	48 89 9c 24 48 01 00 	mov    %rbx,0x148(%rsp)
   82c45:	00 
   82c46:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   82c4d:	00 ff ff ff ff 
   82c52:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   82c59:	00 
   82c5a:	4c 89 fe             	mov    %r15,%rsi
   82c5d:	e8 3e 48 fd ff       	call   574a0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   82c62:	3c ff                	cmp    $0xff,%al
   82c64:	0f 85 77 28 00 00    	jne    854e1 <<oriole::Parser>::next_event_inner+0x3f51>
   82c6a:	41 c6 86 b6 08 00 00 	movb   $0x0,0x8b6(%r14)
   82c71:	00 
   82c72:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   82c79:	00 
   82c7a:	4c 89 f6             	mov    %r14,%rsi
   82c7d:	4c 89 e2             	mov    %r12,%rdx
   82c80:	e8 0b e3 00 00       	call   90f90 <<oriole::Parser>::consume>
   82c85:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   82c8c:	ff 
   82c8d:	0f 85 91 08 00 00    	jne    83524 <<oriole::Parser>::next_event_inner+0x1f94>
   82c93:	e9 05 06 00 00       	jmp    8329d <<oriole::Parser>::next_event_inner+0x1d0d>
   82c98:	c6 84 24 30 03 00 00 	movb   $0x1,0x330(%rsp)
   82c9f:	01 
   82ca0:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   82ca7:	48 83 f8 01          	cmp    $0x1,%rax
   82cab:	77 1c                	ja     82cc9 <<oriole::Parser>::next_event_inner+0x1739>
   82cad:	41 80 be b8 08 00 00 	cmpb   $0x1,0x8b8(%r14)
   82cb4:	01 
   82cb5:	0f 85 f3 02 00 00    	jne    82fae <<oriole::Parser>::next_event_inner+0x1a1e>
   82cbb:	41 f6 86 28 01 00 00 	testb  $0x1,0x128(%r14)
   82cc2:	01 
   82cc3:	0f 85 e5 02 00 00    	jne    82fae <<oriole::Parser>::next_event_inner+0x1a1e>
   82cc9:	49 8b 8e 98 07 00 00 	mov    0x798(%r14),%rcx
   82cd0:	b3 01                	mov    $0x1,%bl
   82cd2:	48 85 c0             	test   %rax,%rax
   82cd5:	0f 84 35 29 00 00    	je     85610 <<oriole::Parser>::next_event_inner+0x4080>
   82cdb:	49 8b 96 80 01 00 00 	mov    0x180(%r14),%rdx
   82ce2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   82ce6:	48 c1 e0 07          	shl    $0x7,%rax
   82cea:	48 8d 34 02          	lea    (%rdx,%rax,1),%rsi
   82cee:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
   82cf5:	0f b6 94 24 30 03 00 	movzbl 0x330(%rsp),%edx
   82cfc:	00 
   82cfd:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   82d04:	00 
   82d05:	e8 c6 b1 fe ff       	call   6ded0 <<oriole::encoding::Source>::scan_token>
   82d0a:	4c 8b bc 24 60 02 00 	mov    0x260(%rsp),%r15
   82d11:	00 
   82d12:	80 bc 24 50 02 00 00 	cmpb   $0x0,0x250(%rsp)
   82d19:	00 
   82d1a:	0f 85 31 22 00 00    	jne    84f51 <<oriole::Parser>::next_event_inner+0x39c1>
   82d20:	83 bc 24 58 02 00 00 	cmpl   $0x1,0x258(%rsp)
   82d27:	01 
   82d28:	0f 85 94 22 00 00    	jne    84fc2 <<oriole::Parser>::next_event_inner+0x3a32>
   82d2e:	41 80 be b3 08 00 00 	cmpb   $0x0,0x8b3(%r14)
   82d35:	00 
   82d36:	74 77                	je     82daf <<oriole::Parser>::next_event_inner+0x181f>
   82d38:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   82d3f:	00 
   82d40:	4c 89 f6             	mov    %r14,%rsi
   82d43:	4c 89 fa             	mov    %r15,%rdx
   82d46:	e8 e5 9f ff ff       	call   7cd30 <<oriole::Parser>::account_source>
   82d4b:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   82d52:	ff 
   82d53:	0f 85 55 24 00 00    	jne    851ae <<oriole::Parser>::next_event_inner+0x3c1e>
   82d59:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   82d60:	48 85 c0             	test   %rax,%rax
   82d63:	0f 84 c8 23 00 00    	je     85131 <<oriole::Parser>::next_event_inner+0x3ba1>
   82d69:	49 8b 96 80 01 00 00 	mov    0x180(%r14),%rdx
   82d70:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   82d74:	48 c1 e6 07          	shl    $0x7,%rsi
   82d78:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
   82d7c:	83 bc 32 80 fe ff ff 	cmpl   $0x1,-0x180(%rdx,%rsi,1)
   82d83:	01 
   82d84:	0f 85 90 00 00 00    	jne    82e1a <<oriole::Parser>::next_event_inner+0x188a>
   82d8a:	0f 10 81 88 fe ff ff 	movups -0x178(%rcx),%xmm0
   82d91:	f3 0f 6f 89 98 fe ff 	movdqu -0x168(%rcx),%xmm1
   82d98:	ff 
   82d99:	66 0f 7f 8c 24 70 03 	movdqa %xmm1,0x370(%rsp)
   82da0:	00 00 
   82da2:	0f 29 84 24 60 03 00 	movaps %xmm0,0x360(%rsp)
   82da9:	00 
   82daa:	e9 b1 00 00 00       	jmp    82e60 <<oriole::Parser>::next_event_inner+0x18d0>
   82daf:	80 bc 24 30 03 00 00 	cmpb   $0x0,0x330(%rsp)
   82db6:	00 
   82db7:	0f 85 7b ff ff ff    	jne    82d38 <<oriole::Parser>::next_event_inner+0x17a8>
   82dbd:	41 80 be b0 08 00 00 	cmpb   $0x0,0x8b0(%r14)
   82dc4:	00 
   82dc5:	0f 84 6d ff ff ff    	je     82d38 <<oriole::Parser>::next_event_inner+0x17a8>
   82dcb:	41 c6 86 b0 08 00 00 	movb   $0x0,0x8b0(%r14)
   82dd2:	00 
   82dd3:	48 8d 9c 24 50 02 00 	lea    0x250(%rsp),%rbx
   82dda:	00 
   82ddb:	48 89 df             	mov    %rbx,%rdi
   82dde:	4c 89 f6             	mov    %r14,%rsi
   82de1:	e8 8a e0 00 00       	call   90e70 <<oriole::Parser>::here>
   82de6:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   82ded:	00 
   82dee:	4c 89 f6             	mov    %r14,%rsi
   82df1:	48 89 da             	mov    %rbx,%rdx
   82df4:	e8 77 0d fe ff       	call   63b70 <<oriole::Parser>::start_foreign_dtd>
   82df9:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   82e00:	ff 
   82e01:	0f 85 a7 23 00 00    	jne    851ae <<oriole::Parser>::next_event_inner+0x3c1e>
   82e07:	41 80 be c4 08 00 00 	cmpb   $0x0,0x8c4(%r14)
   82e0e:	00 
   82e0f:	0f 85 8b ea ff ff    	jne    818a0 <<oriole::Parser>::next_event_inner+0x310>
   82e15:	e9 1e ff ff ff       	jmp    82d38 <<oriole::Parser>::next_event_inner+0x17a8>
   82e1a:	48 8d 3c 32          	lea    (%rdx,%rsi,1),%rdi
   82e1e:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   82e25:	48 8b 59 a8          	mov    -0x58(%rcx),%rbx
   82e29:	0f 10 41 d8          	movups -0x28(%rcx),%xmm0
   82e2d:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   82e32:	31 f6                	xor    %esi,%esi
   82e34:	4c 89 fa             	mov    %r15,%rdx
   82e37:	e8 f4 c9 fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   82e3c:	48 89 9c 24 60 03 00 	mov    %rbx,0x360(%rsp)
   82e43:	00 
   82e44:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   82e49:	0f 11 84 24 68 03 00 	movups %xmm0,0x368(%rsp)
   82e50:	00 
   82e51:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
   82e58:	00 
   82e59:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   82e60:	49 8b 4d 60          	mov    0x60(%r13),%rcx
   82e64:	48 89 8c 24 b0 02 00 	mov    %rcx,0x2b0(%rsp)
   82e6b:	00 
   82e6c:	41 0f 10 45 50       	movups 0x50(%r13),%xmm0
   82e71:	0f 29 84 24 a0 02 00 	movaps %xmm0,0x2a0(%rsp)
   82e78:	00 
   82e79:	41 0f 10 45 40       	movups 0x40(%r13),%xmm0
   82e7e:	0f 29 84 24 90 02 00 	movaps %xmm0,0x290(%rsp)
   82e85:	00 
   82e86:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
   82e8b:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
   82e90:	f3 41 0f 6f 55 20    	movdqu 0x20(%r13),%xmm2
   82e96:	41 0f 10 5d 30       	movups 0x30(%r13),%xmm3
   82e9b:	0f 29 9c 24 80 02 00 	movaps %xmm3,0x280(%rsp)
   82ea2:	00 
   82ea3:	66 0f 7f 94 24 70 02 	movdqa %xmm2,0x270(%rsp)
   82eaa:	00 00 
   82eac:	0f 29 8c 24 60 02 00 	movaps %xmm1,0x260(%rsp)
   82eb3:	00 
   82eb4:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
   82ebb:	00 
   82ebc:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   82ec3:	00 
   82ec4:	0f 10 01             	movups (%rcx),%xmm0
   82ec7:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   82ecb:	41 0f 11 45 00       	movups %xmm0,0x0(%r13)
   82ed0:	41 0f 11 4d 10       	movups %xmm1,0x10(%r13)
   82ed5:	49 c7 86 48 05 00 00 	movq   $0x1,0x548(%r14)
   82edc:	01 00 00 00 
   82ee0:	48 8b 94 24 28 05 00 	mov    0x528(%rsp),%rdx
   82ee7:	00 
   82ee8:	66 0f ef d2          	pxor   %xmm2,%xmm2
   82eec:	f3 0f 7f 12          	movdqu %xmm2,(%rdx)
   82ef0:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   82ef4:	f3 0f 6f 49 10       	movdqu 0x10(%rcx),%xmm1
   82ef9:	48 8b 8c 24 20 05 00 	mov    0x520(%rsp),%rcx
   82f00:	00 
   82f01:	f3 0f 7f 49 10       	movdqu %xmm1,0x10(%rcx)
   82f06:	f3 0f 7f 01          	movdqu %xmm0,(%rcx)
   82f0a:	49 c7 86 80 05 00 00 	movq   $0x8,0x580(%r14)
   82f11:	08 00 00 00 
   82f15:	48 8b 8c 24 18 05 00 	mov    0x518(%rsp),%rcx
   82f1c:	00 
   82f1d:	f3 0f 7f 11          	movdqu %xmm2,(%rcx)
   82f21:	48 c7 84 24 80 02 00 	movq   $0x0,0x280(%rsp)
   82f28:	00 00 00 00 00 
   82f2d:	48 c7 84 24 b8 02 00 	movq   $0x0,0x2b8(%rsp)
   82f34:	00 00 00 00 00 
   82f39:	48 85 c0             	test   %rax,%rax
   82f3c:	0f 84 b0 26 00 00    	je     855f2 <<oriole::Parser>::next_event_inner+0x4062>
   82f42:	49 8b 8e 80 01 00 00 	mov    0x180(%r14),%rcx
   82f49:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   82f4d:	48 c1 e0 07          	shl    $0x7,%rax
   82f51:	48 8d 34 01          	lea    (%rcx,%rax,1),%rsi
   82f55:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
   82f5c:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   82f63:	00 
   82f64:	e8 a7 c3 fe ff       	call   6f310 <<oriole::encoding::Source>::lexical_remaining>
   82f69:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   82f70:	48 85 c0             	test   %rax,%rax
   82f73:	0f 84 79 26 00 00    	je     855f2 <<oriole::Parser>::next_event_inner+0x4062>
   82f79:	49 8b 8e 80 01 00 00 	mov    0x180(%r14),%rcx
   82f80:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   82f84:	48 c1 e0 07          	shl    $0x7,%rax
   82f88:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
   82f8c:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   82f93:	e8 48 cb fe ff       	call   6fae0 <<oriole::encoding::Source>::remaining>
   82f98:	4d 85 ff             	test   %r15,%r15
   82f9b:	74 7e                	je     8301b <<oriole::Parser>::next_event_inner+0x1a8b>
   82f9d:	49 39 d7             	cmp    %rdx,%r15
   82fa0:	73 66                	jae    83008 <<oriole::Parser>::next_event_inner+0x1a78>
   82fa2:	42 80 3c 38 c0       	cmpb   $0xc0,(%rax,%r15,1)
   82fa7:	7d 72                	jge    8301b <<oriole::Parser>::next_event_inner+0x1a8b>
   82fa9:	e9 7e 1d 00 00       	jmp    84d2c <<oriole::Parser>::next_event_inner+0x379c>
   82fae:	41 80 be f8 07 00 00 	cmpb   $0xff,0x7f8(%r14)
   82fb5:	ff 
   82fb6:	0f 95 c3             	setne  %bl
   82fb9:	49 8b 8e 98 07 00 00 	mov    0x798(%r14),%rcx
   82fc0:	0f 85 0c fd ff ff    	jne    82cd2 <<oriole::Parser>::next_event_inner+0x1742>
   82fc6:	41 80 be bf 08 00 00 	cmpb   $0x0,0x8bf(%r14)
   82fcd:	00 
   82fce:	0f 84 fe fc ff ff    	je     82cd2 <<oriole::Parser>::next_event_inner+0x1742>
   82fd4:	48 85 c0             	test   %rax,%rax
   82fd7:	0f 84 54 21 00 00    	je     85131 <<oriole::Parser>::next_event_inner+0x3ba1>
   82fdd:	49 8b be 80 01 00 00 	mov    0x180(%r14),%rdi
   82fe4:	49 89 cf             	mov    %rcx,%r15
   82fe7:	48 89 ce             	mov    %rcx,%rsi
   82fea:	e8 91 bd fe ff       	call   6ed80 <<oriole::encoding::Source>::should_defer>
   82fef:	84 c0                	test   %al,%al
   82ff1:	0f 85 10 1b 00 00    	jne    84b07 <<oriole::Parser>::next_event_inner+0x3577>
   82ff7:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   82ffe:	31 db                	xor    %ebx,%ebx
   83000:	4c 89 f9             	mov    %r15,%rcx
   83003:	e9 ca fc ff ff       	jmp    82cd2 <<oriole::Parser>::next_event_inner+0x1742>
   83008:	0f 95 c1             	setne  %cl
   8300b:	48 85 c0             	test   %rax,%rax
   8300e:	40 0f 94 c6          	sete   %sil
   83012:	40 08 ce             	or     %cl,%sil
   83015:	0f 85 11 1d 00 00    	jne    84d2c <<oriole::Parser>::next_event_inner+0x379c>
   8301b:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
   83022:	00 
   83023:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
   8302a:	00 
   8302b:	48 89 c2             	mov    %rax,%rdx
   8302e:	4c 89 f9             	mov    %r15,%rcx
   83031:	e8 9a a0 01 00       	call   9d0d0 <<oriole::lexical::Slice>::for_slice>
   83036:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   8303d:	00 
   8303e:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
   83045:	00 
   83046:	e8 f5 58 ff ff       	call   78940 <<oriole::lexical::Buffer>::append>
   8304b:	3c ff                	cmp    $0xff,%al
   8304d:	0f 85 60 1e 00 00    	jne    84eb3 <<oriole::Parser>::next_event_inner+0x3923>
   83053:	48 8d 84 24 50 02 00 	lea    0x250(%rsp),%rax
   8305a:	00 
   8305b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   83062:	00 
   83063:	4c 89 b4 24 88 00 00 	mov    %r14,0x88(%rsp)
   8306a:	00 
   8306b:	48 8d 84 24 30 03 00 	lea    0x330(%rsp),%rax
   83072:	00 
   83073:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   8307a:	00 
   8307b:	48 8d 84 24 60 03 00 	lea    0x360(%rsp),%rax
   83082:	00 
   83083:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
   8308a:	00 
   8308b:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
   83092:	00 
   83093:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
   8309a:	00 
   8309b:	e8 10 a1 fc ff       	call   4d1b0 <<oriole::Parser>::next_event_inner::{closure#4}>
   830a0:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   830a7:	00 
   830a8:	48 89 ee             	mov    %rbp,%rsi
   830ab:	e8 d0 53 ff ff       	call   78480 <<oriole::lexical::Buffer>::swap_decoded>
   830b0:	3c ff                	cmp    $0xff,%al
   830b2:	0f 85 fb 1d 00 00    	jne    84eb3 <<oriole::Parser>::next_event_inner+0x3923>
   830b8:	80 bc 24 40 04 00 00 	cmpb   $0xff,0x440(%rsp)
   830bf:	ff 
   830c0:	0f 85 6e 1f 00 00    	jne    85034 <<oriole::Parser>::next_event_inner+0x3aa4>
   830c6:	0f 28 84 24 b0 02 00 	movaps 0x2b0(%rsp),%xmm0
   830cd:	00 
   830ce:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   830d5:	00 
   830d6:	0f 28 84 24 a0 02 00 	movaps 0x2a0(%rsp),%xmm0
   830dd:	00 
   830de:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   830e5:	00 
   830e6:	0f 28 84 24 90 02 00 	movaps 0x290(%rsp),%xmm0
   830ed:	00 
   830ee:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   830f5:	00 
   830f6:	0f 28 84 24 50 02 00 	movaps 0x250(%rsp),%xmm0
   830fd:	00 
   830fe:	0f 28 8c 24 60 02 00 	movaps 0x260(%rsp),%xmm1
   83105:	00 
   83106:	0f 28 94 24 70 02 00 	movaps 0x270(%rsp),%xmm2
   8310d:	00 
   8310e:	0f 28 9c 24 80 02 00 	movaps 0x280(%rsp),%xmm3
   83115:	00 
   83116:	0f 29 9c 24 b0 00 00 	movaps %xmm3,0xb0(%rsp)
   8311d:	00 
   8311e:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
   83125:	00 
   83126:	0f 29 8c 24 90 00 00 	movaps %xmm1,0x90(%rsp)
   8312d:	00 
   8312e:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   83135:	00 
   83136:	4c 89 ef             	mov    %r13,%rdi
   83139:	e8 72 68 fc ff       	call   499b0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   8313e:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   83145:	00 
   83146:	41 0f 11 45 60       	movups %xmm0,0x60(%r13)
   8314b:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   83152:	00 
   83153:	41 0f 11 45 50       	movups %xmm0,0x50(%r13)
   83158:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
   8315f:	00 
   83160:	41 0f 11 45 40       	movups %xmm0,0x40(%r13)
   83165:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
   8316c:	00 00 
   8316e:	66 0f 6f 8c 24 90 00 	movdqa 0x90(%rsp),%xmm1
   83175:	00 00 
   83177:	66 0f 6f 94 24 a0 00 	movdqa 0xa0(%rsp),%xmm2
   8317e:	00 00 
   83180:	0f 28 9c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm3
   83187:	00 
   83188:	41 0f 11 5d 30       	movups %xmm3,0x30(%r13)
   8318d:	f3 41 0f 7f 55 20    	movdqu %xmm2,0x20(%r13)
   83193:	f3 41 0f 7f 4d 10    	movdqu %xmm1,0x10(%r13)
   83199:	f3 41 0f 7f 45 00    	movdqu %xmm0,0x0(%r13)
   8319f:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   831a6:	00 
   831a7:	4c 89 f6             	mov    %r14,%rsi
   831aa:	4c 89 fa             	mov    %r15,%rdx
   831ad:	e8 de dd 00 00       	call   90f90 <<oriole::Parser>::consume>
   831b2:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   831b9:	ff 
   831ba:	0f 84 e0 e6 ff ff    	je     818a0 <<oriole::Parser>::next_event_inner+0x310>
   831c0:	e9 e9 1f 00 00       	jmp    851ae <<oriole::Parser>::next_event_inner+0x3c1e>
   831c5:	c1 e1 0c             	shl    $0xc,%ecx
   831c8:	09 ca                	or     %ecx,%edx
   831ca:	89 d1                	mov    %edx,%ecx
   831cc:	83 f9 0d             	cmp    $0xd,%ecx
   831cf:	77 0a                	ja     831db <<oriole::Parser>::next_event_inner+0x1c4b>
   831d1:	ba 00 26 00 00       	mov    $0x2600,%edx
   831d6:	0f a3 ca             	bt     %ecx,%edx
   831d9:	72 34                	jb     8320f <<oriole::Parser>::next_event_inner+0x1c7f>
   831db:	8d 91 00 28 ff ff    	lea    -0xd800(%rcx),%edx
   831e1:	81 fa 20 28 ff ff    	cmp    $0xffff2820,%edx
   831e7:	0f 92 c2             	setb   %dl
   831ea:	8d b1 02 00 ff ff    	lea    -0xfffe(%rcx),%esi
   831f0:	81 fe 02 e0 ff ff    	cmp    $0xffffe002,%esi
   831f6:	40 0f 92 c6          	setb   %sil
   831fa:	40 20 d6             	and    %dl,%sil
   831fd:	81 f9 00 00 01 00    	cmp    $0x10000,%ecx
   83203:	0f 92 c1             	setb   %cl
   83206:	40 84 ce             	test   %cl,%sil
   83209:	0f 85 a2 21 00 00    	jne    853b1 <<oriole::Parser>::next_event_inner+0x3e21>
   8320f:	49 83 f8 03          	cmp    $0x3,%r8
   83213:	72 1b                	jb     83230 <<oriole::Parser>::next_event_inner+0x1ca0>
   83215:	41 0f b7 0b          	movzwl (%r11),%ecx
   83219:	81 f1 3c 21 00 00    	xor    $0x213c,%ecx
   8321f:	41 0f b6 53 02       	movzbl 0x2(%r11),%edx
   83224:	83 f2 5b             	xor    $0x5b,%edx
   83227:	66 09 ca             	or     %cx,%dx
   8322a:	0f 84 0b 01 00 00    	je     8333b <<oriole::Parser>::next_event_inner+0x1dab>
   83230:	83 fb 5d             	cmp    $0x5d,%ebx
   83233:	0f 94 c1             	sete   %cl
   83236:	84 c1                	test   %al,%cl
   83238:	74 6a                	je     832a4 <<oriole::Parser>::next_event_inner+0x1d14>
   8323a:	49 83 f8 03          	cmp    $0x3,%r8
   8323e:	0f 86 91 00 00 00    	jbe    832d5 <<oriole::Parser>::next_event_inner+0x1d45>
   83244:	41 0f b7 03          	movzwl (%r11),%eax
   83248:	35 5d 5d 00 00       	xor    $0x5d5d,%eax
   8324d:	41 0f b6 4b 02       	movzbl 0x2(%r11),%ecx
   83252:	83 f1 3e             	xor    $0x3e,%ecx
   83255:	66 09 c1             	or     %ax,%cx
   83258:	0f 94 c1             	sete   %cl
   8325b:	49 8b 86 e8 03 00 00 	mov    0x3e8(%r14),%rax
   83262:	48 85 c0             	test   %rax,%rax
   83265:	0f 95 c2             	setne  %dl
   83268:	84 d1                	test   %dl,%cl
   8326a:	0f 84 92 02 00 00    	je     83502 <<oriole::Parser>::next_event_inner+0x1f72>
   83270:	48 ff c8             	dec    %rax
   83273:	49 89 86 e8 03 00 00 	mov    %rax,0x3e8(%r14)
   8327a:	ba 03 00 00 00       	mov    $0x3,%edx
   8327f:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83286:	00 
   83287:	4c 89 f6             	mov    %r14,%rsi
   8328a:	e8 b1 03 01 00       	call   93640 <<oriole::Parser>::conditional_raw>
   8328f:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   83296:	ff 
   83297:	0f 85 87 02 00 00    	jne    83524 <<oriole::Parser>::next_event_inner+0x1f94>
   8329d:	b0 01                	mov    $0x1,%al
   8329f:	e9 8d f1 ff ff       	jmp    82431 <<oriole::Parser>::next_event_inner+0xea1>
   832a4:	49 83 f8 02          	cmp    $0x2,%r8
   832a8:	0f 82 a0 03 00 00    	jb     8364e <<oriole::Parser>::next_event_inner+0x20be>
   832ae:	66 41 81 3b 3c 21    	cmpw   $0x213c,(%r11)
   832b4:	0f 85 94 03 00 00    	jne    8364e <<oriole::Parser>::next_event_inner+0x20be>
   832ba:	49 83 f8 02          	cmp    $0x2,%r8
   832be:	0f 85 15 03 00 00    	jne    835d9 <<oriole::Parser>::next_event_inner+0x2049>
   832c4:	66 41 81 3b 3c 21    	cmpw   $0x213c,(%r11)
   832ca:	0f 85 2a 03 00 00    	jne    835fa <<oriole::Parser>::next_event_inner+0x206a>
   832d0:	e9 79 03 00 00       	jmp    8364e <<oriole::Parser>::next_event_inner+0x20be>
   832d5:	4c 89 df             	mov    %r11,%rdi
   832d8:	48 8d 35 1b e1 f8 ff 	lea    -0x71ee5(%rip),%rsi        # 113fa <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4a5e>
   832df:	4c 89 c2             	mov    %r8,%rdx
   832e2:	ff 15 70 3e 06 00    	call   *0x63e70(%rip)        # e7158 <bcmp@GLIBC_2.2.5>
   832e8:	48 8b 8c 24 10 02 00 	mov    0x210(%rsp),%rcx
   832ef:	00 
   832f0:	48 83 f9 02          	cmp    $0x2,%rcx
   832f4:	0f 87 f6 01 00 00    	ja     834f0 <<oriole::Parser>::next_event_inner+0x1f60>
   832fa:	85 c0                	test   %eax,%eax
   832fc:	0f 85 ee 01 00 00    	jne    834f0 <<oriole::Parser>::next_event_inner+0x1f60>
   83302:	48 83 bc 24 40 02 00 	cmpq   $0x1,0x240(%rsp)
   83309:	00 01 
   8330b:	0f 85 f1 01 00 00    	jne    83502 <<oriole::Parser>::next_event_inner+0x1f72>
   83311:	41 0f b6 86 28 01 00 	movzbl 0x128(%r14),%eax
   83318:	00 
   83319:	34 01                	xor    $0x1,%al
   8331b:	41 84 86 b8 08 00 00 	test   %al,0x8b8(%r14)
   83322:	0f 85 da 01 00 00    	jne    83502 <<oriole::Parser>::next_event_inner+0x1f72>
   83328:	41 80 be f8 07 00 00 	cmpb   $0xff,0x7f8(%r14)
   8332f:	ff 
   83330:	0f 84 92 04 00 00    	je     837c8 <<oriole::Parser>::next_event_inner+0x2238>
   83336:	e9 c7 01 00 00       	jmp    83502 <<oriole::Parser>::next_event_inner+0x1f72>
   8333b:	a8 01                	test   $0x1,%al
   8333d:	0f 84 00 21 00 00    	je     85443 <<oriole::Parser>::next_event_inner+0x3eb3>
   83343:	49 8b 8e 48 08 00 00 	mov    0x848(%r14),%rcx
   8334a:	48 8b 41 28          	mov    0x28(%rcx),%rax
   8334e:	49 8b 96 a8 07 00 00 	mov    0x7a8(%r14),%rdx
   83355:	48 89 fb             	mov    %rdi,%rbx
   83358:	48 3d ef fe ff ff    	cmp    $0xfffffffffffffeef,%rax
   8335e:	0f 87 e5 19 00 00    	ja     84d49 <<oriole::Parser>::next_event_inner+0x37b9>
   83364:	48 8d b0 10 01 00 00 	lea    0x110(%rax),%rsi
   8336b:	48 39 d6             	cmp    %rdx,%rsi
   8336e:	0f 87 d5 19 00 00    	ja     84d49 <<oriole::Parser>::next_event_inner+0x37b9>
   83374:	f0 48 0f b1 71 28    	lock cmpxchg %rsi,0x28(%rcx)
   8337a:	75 dc                	jne    83358 <<oriole::Parser>::next_event_inner+0x1dc8>
   8337c:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
   83383:	00 
   83384:	0f 10 00             	movups (%rax),%xmm0
   83387:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   8338b:	48 8d 8c 24 48 04 00 	lea    0x448(%rsp),%rcx
   83392:	00 
   83393:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
   83397:	0f 11 01             	movups %xmm0,(%rcx)
   8339a:	0f 10 00             	movups (%rax),%xmm0
   8339d:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   833a1:	0f 29 8c 24 20 04 00 	movaps %xmm1,0x420(%rsp)
   833a8:	00 
   833a9:	0f 29 84 24 10 04 00 	movaps %xmm0,0x410(%rsp)
   833b0:	00 
   833b1:	48 c7 84 24 30 04 00 	movq   $0x1,0x430(%rsp)
   833b8:	00 01 00 00 00 
   833bd:	0f 57 c0             	xorps  %xmm0,%xmm0
   833c0:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   833c4:	48 c7 84 24 68 04 00 	movq   $0x8,0x468(%rsp)
   833cb:	00 08 00 00 00 
   833d0:	0f 11 41 28          	movups %xmm0,0x28(%rcx)
   833d4:	f3 0f 6f 00          	movdqu (%rax),%xmm0
   833d8:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
   833dd:	66 0f 7f 8c 24 40 03 	movdqa %xmm1,0x340(%rsp)
   833e4:	00 00 
   833e6:	66 0f 7f 84 24 30 03 	movdqa %xmm0,0x330(%rsp)
   833ed:	00 00 
   833ef:	ba 03 00 00 00       	mov    $0x3,%edx
   833f4:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
   833fb:	00 
   833fc:	48 8d 35 5a e2 f8 ff 	lea    -0x71da6(%rip),%rsi        # 1165d <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4cc1>
   83403:	48 8d 8c 24 30 03 00 	lea    0x330(%rsp),%rcx
   8340a:	00 
   8340b:	ff 15 c7 34 06 00    	call   *0x634c7(%rip)        # e68d8 <_GLOBAL_OFFSET_TABLE_+0x160>
   83411:	48 8b 84 24 60 03 00 	mov    0x360(%rsp),%rax
   83418:	00 
   83419:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   8341d:	0f 84 d7 04 00 00    	je     838fa <<oriole::Parser>::next_event_inner+0x236a>
   83423:	48 8b 8c 24 68 03 00 	mov    0x368(%rsp),%rcx
   8342a:	00 
   8342b:	48 8b 94 24 70 03 00 	mov    0x370(%rsp),%rdx
   83432:	00 
   83433:	48 8b b4 24 78 03 00 	mov    0x378(%rsp),%rsi
   8343a:	00 
   8343b:	4c 8d 94 24 80 03 00 	lea    0x380(%rsp),%r10
   83442:	00 
   83443:	41 0f b6 7a 10       	movzbl 0x10(%r10),%edi
   83448:	4c 8d 8c 24 58 02 00 	lea    0x258(%rsp),%r9
   8344f:	00 
   83450:	41 88 79 28          	mov    %dil,0x28(%r9)
   83454:	f3 41 0f 6f 02       	movdqu (%r10),%xmm0
   83459:	f3 41 0f 7f 41 18    	movdqu %xmm0,0x18(%r9)
   8345f:	41 8b 7a 11          	mov    0x11(%r10),%edi
   83463:	45 8b 42 14          	mov    0x14(%r10),%r8d
   83467:	45 89 41 2c          	mov    %r8d,0x2c(%r9)
   8346b:	41 89 79 29          	mov    %edi,0x29(%r9)
   8346f:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
   83476:	00 
   83477:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
   8347e:	00 
   8347f:	48 89 94 24 60 02 00 	mov    %rdx,0x260(%rsp)
   83486:	00 
   83487:	48 89 b4 24 68 02 00 	mov    %rsi,0x268(%rsp)
   8348e:	00 
   8348f:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
   83496:	00 
   83497:	48 89 8c 24 90 02 00 	mov    %rcx,0x290(%rsp)
   8349e:	00 
   8349f:	48 89 94 24 98 02 00 	mov    %rdx,0x298(%rsp)
   834a6:	00 
   834a7:	48 89 b4 24 a0 02 00 	mov    %rsi,0x2a0(%rsp)
   834ae:	00 
   834af:	48 c7 84 24 a8 02 00 	movq   $0x8,0x2a8(%rsp)
   834b6:	00 08 00 00 00 
   834bb:	66 0f ef c0          	pxor   %xmm0,%xmm0
   834bf:	f3 41 0f 7f 41 58    	movdqu %xmm0,0x58(%r9)
   834c5:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   834ca:	83 3f 01             	cmpl   $0x1,(%rdi)
   834cd:	0f 85 72 04 00 00    	jne    83945 <<oriole::Parser>::next_event_inner+0x23b5>
   834d3:	48 89 d8             	mov    %rbx,%rax
   834d6:	48 8b 9b 88 fe ff ff 	mov    -0x178(%rbx),%rbx
   834dd:	0f 10 a0 90 fe ff ff 	movups -0x170(%rax),%xmm4
   834e4:	48 8b 80 a0 fe ff ff 	mov    -0x160(%rax),%rax
   834eb:	e9 75 04 00 00       	jmp    83965 <<oriole::Parser>::next_event_inner+0x23d5>
   834f0:	48 83 f9 03          	cmp    $0x3,%rcx
   834f4:	4c 8b 9c 24 38 02 00 	mov    0x238(%rsp),%r11
   834fb:	00 
   834fc:	0f 83 42 fd ff ff    	jae    83244 <<oriole::Parser>::next_event_inner+0x1cb4>
   83502:	41 b8 30 00 00 00    	mov    $0x30,%r8d
   83508:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8350f:	00 
   83510:	4c 89 f6             	mov    %r14,%rsi
   83513:	ba 01 00 00 00       	mov    $0x1,%edx
   83518:	48 8d 0d a1 e8 f8 ff 	lea    -0x7175f(%rip),%rcx        # 11dc0 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5424>
   8351f:	e8 8c cf 00 00       	call   904b0 <<oriole::Parser>::err>
   83524:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   8352b:	00 
   8352c:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   83531:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   83538:	00 00 
   8353a:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   83541:	00 00 
   83543:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   8354a:	00 00 
   8354c:	66 0f 7f 54 24 40    	movdqa %xmm2,0x40(%rsp)
   83552:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   83558:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   8355e:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   83563:	3c ff                	cmp    $0xff,%al
   83565:	0f 85 49 18 00 00    	jne    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   8356b:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
   83570:	0f 85 2a e3 ff ff    	jne    818a0 <<oriole::Parser>::next_event_inner+0x310>
   83576:	e9 8c 15 00 00       	jmp    84b07 <<oriole::Parser>::next_event_inner+0x3577>
   8357b:	48 8b 38             	mov    (%rax),%rdi
   8357e:	49 b8 3c 21 5b 43 44 	movabs $0x41544144435b213c,%r8
   83585:	41 54 41 
   83588:	4c 31 c7             	xor    %r8,%rdi
   8358b:	44 0f b6 40 08       	movzbl 0x8(%rax),%r8d
   83590:	49 83 f0 5b          	xor    $0x5b,%r8
   83594:	49 09 f8             	or     %rdi,%r8
   83597:	0f 84 fc 02 00 00    	je     83899 <<oriole::Parser>::next_event_inner+0x2309>
   8359d:	66 81 38 3c 3f       	cmpw   $0x3f3c,(%rax)
   835a2:	0f 84 2a 06 00 00    	je     83bd2 <<oriole::Parser>::next_event_inner+0x2642>
   835a8:	48 8b 10             	mov    (%rax),%rdx
   835ab:	48 be 3c 21 44 4f 43 	movabs $0x505954434f44213c,%rsi
   835b2:	54 59 50 
   835b5:	48 31 f2             	xor    %rsi,%rdx
   835b8:	0f b6 70 08          	movzbl 0x8(%rax),%esi
   835bc:	48 83 f6 45          	xor    $0x45,%rsi
   835c0:	48 09 d6             	or     %rdx,%rsi
   835c3:	0f 84 9f 07 00 00    	je     83d68 <<oriole::Parser>::next_event_inner+0x27d8>
   835c9:	66 81 38 3c 2f       	cmpw   $0x2f3c,(%rax)
   835ce:	0f 85 d1 ef ff ff    	jne    825a5 <<oriole::Parser>::next_event_inner+0x1015>
   835d4:	e9 d7 ef ff ff       	jmp    825b0 <<oriole::Parser>::next_event_inner+0x1020>
   835d9:	41 0f b7 03          	movzwl (%r11),%eax
   835dd:	35 3c 21 00 00       	xor    $0x213c,%eax
   835e2:	41 0f b6 4b 02       	movzbl 0x2(%r11),%ecx
   835e7:	83 f1 2d             	xor    $0x2d,%ecx
   835ea:	66 09 c1             	or     %ax,%cx
   835ed:	74 5f                	je     8364e <<oriole::Parser>::next_event_inner+0x20be>
   835ef:	41 80 7b 02 c0       	cmpb   $0xc0,0x2(%r11)
   835f4:	0f 8c d0 21 00 00    	jl     857ca <<oriole::Parser>::next_event_inner+0x423a>
   835fa:	49 8d 43 02          	lea    0x2(%r11),%rax
   835fe:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   83605:	00 
   83606:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
   8360d:	00 
   8360e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83615:	00 
   83616:	e8 05 72 fc ff       	call   4a820 <core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>>
   8361b:	a8 01                	test   $0x1,%al
   8361d:	74 17                	je     83636 <<oriole::Parser>::next_event_inner+0x20a6>
   8361f:	41 0f b6 be cc 07 00 	movzbl 0x7cc(%r14),%edi
   83626:	00 
   83627:	89 d6                	mov    %edx,%esi
   83629:	e8 f2 26 fd ff       	call   55d20 <<oriole::names::NameRules>::is_name_start>
   8362e:	84 c0                	test   %al,%al
   83630:	0f 84 7c 07 00 00    	je     83db2 <<oriole::Parser>::next_event_inner+0x2822>
   83636:	4c 8b 94 24 40 02 00 	mov    0x240(%rsp),%r10
   8363d:	00 
   8363e:	4c 8b 9c 24 38 02 00 	mov    0x238(%rsp),%r11
   83645:	00 
   83646:	4c 8b 84 24 10 02 00 	mov    0x210(%rsp),%r8
   8364d:	00 
   8364e:	83 fb 25             	cmp    $0x25,%ebx
   83651:	75 1f                	jne    83672 <<oriole::Parser>::next_event_inner+0x20e2>
   83653:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   83658:	4c 89 f6             	mov    %r14,%rsi
   8365b:	e8 10 7e fe ff       	call   6b470 <<oriole::Parser>::parse_parameter_reference>
   83660:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   83665:	3c ff                	cmp    $0xff,%al
   83667:	0f 84 fe fe ff ff    	je     8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   8366d:	e9 42 17 00 00       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   83672:	83 fb 5d             	cmp    $0x5d,%ebx
   83675:	0f 94 c0             	sete   %al
   83678:	44 84 f8             	test   %r15b,%al
   8367b:	0f 84 0d 01 00 00    	je     8378e <<oriole::Parser>::next_event_inner+0x21fe>
   83681:	49 83 fa 01          	cmp    $0x1,%r10
   83685:	0f 85 90 01 00 00    	jne    8381b <<oriole::Parser>::next_event_inner+0x228b>
   8368b:	49 8b 8e 98 07 00 00 	mov    0x798(%r14),%rcx
   83692:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   83699:	00 
   8369a:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   8369f:	31 d2                	xor    %edx,%edx
   836a1:	e8 2a a8 fe ff       	call   6ded0 <<oriole::encoding::Source>::scan_token>
   836a6:	4c 8b bc 24 60 02 00 	mov    0x260(%rsp),%r15
   836ad:	00 
   836ae:	80 bc 24 50 02 00 00 	cmpb   $0x0,0x250(%rsp)
   836b5:	00 
   836b6:	0f 85 58 07 00 00    	jne    83e14 <<oriole::Parser>::next_event_inner+0x2884>
   836bc:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   836c3:	83 bc 24 58 02 00 00 	cmpl   $0x1,0x258(%rsp)
   836ca:	01 
   836cb:	0f 85 b5 06 00 00    	jne    83d86 <<oriole::Parser>::next_event_inner+0x27f6>
   836d1:	48 85 c0             	test   %rax,%rax
   836d4:	0f 84 57 1a 00 00    	je     85131 <<oriole::Parser>::next_event_inner+0x3ba1>
   836da:	49 8b 8e 80 01 00 00 	mov    0x180(%r14),%rcx
   836e1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   836e5:	48 c1 e0 07          	shl    $0x7,%rax
   836e9:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
   836ed:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   836f4:	e8 e7 c3 fe ff       	call   6fae0 <<oriole::encoding::Source>::remaining>
   836f9:	49 89 c5             	mov    %rax,%r13
   836fc:	48 89 d5             	mov    %rdx,%rbp
   836ff:	49 8d 4f ff          	lea    -0x1(%r15),%rcx
   83703:	4d 8d 67 fe          	lea    -0x2(%r15),%r12
   83707:	49 39 d4             	cmp    %rdx,%r12
   8370a:	0f 83 79 1f 00 00    	jae    85689 <<oriole::Parser>::next_event_inner+0x40f9>
   83710:	48 83 fd 01          	cmp    $0x1,%rbp
   83714:	74 1c                	je     83732 <<oriole::Parser>::next_event_inner+0x21a2>
   83716:	41 80 7d 01 c0       	cmpb   $0xc0,0x1(%r13)
   8371b:	0f 8c 68 1f 00 00    	jl     85689 <<oriole::Parser>::next_event_inner+0x40f9>
   83721:	48 39 e9             	cmp    %rbp,%rcx
   83724:	74 0c                	je     83732 <<oriole::Parser>::next_event_inner+0x21a2>
   83726:	41 80 7c 0d 00 bf    	cmpb   $0xbf,0x0(%r13,%rcx,1)
   8372c:	0f 8e 57 1f 00 00    	jle    85689 <<oriole::Parser>::next_event_inner+0x40f9>
   83732:	49 8d 45 01          	lea    0x1(%r13),%rax
   83736:	4b 8d 0c 2f          	lea    (%r15,%r13,1),%rcx
   8373a:	48 ff c9             	dec    %rcx
   8373d:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   83744:	00 
   83745:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
   8374c:	00 
   8374d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83754:	00 
   83755:	e8 a6 8e fc ff       	call   4c600 <<core::str::iter::Chars as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::all::check<char, oriole::names::whitespace>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
   8375a:	84 c0                	test   %al,%al
   8375c:	0f 84 c7 08 00 00    	je     84029 <<oriole::Parser>::next_event_inner+0x2a99>
   83762:	41 b8 29 00 00 00    	mov    $0x29,%r8d
   83768:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8376f:	00 
   83770:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   83775:	4c 89 f6             	mov    %r14,%rsi
   83778:	ba 01 00 00 00       	mov    $0x1,%edx
   8377d:	48 8d 0d c4 e5 f8 ff 	lea    -0x71a3c(%rip),%rcx        # 11d48 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x53ac>
   83784:	e8 27 cd 00 00       	call   904b0 <<oriole::Parser>::err>
   83789:	e9 fa ea ff ff       	jmp    82288 <<oriole::Parser>::next_event_inner+0xcf8>
   8378e:	4c 89 df             	mov    %r11,%rdi
   83791:	4c 89 c6             	mov    %r8,%rsi
   83794:	e8 67 f2 01 00       	call   a2a00 <<&str as core::slice::cmp::SliceContains>::slice_contains>
   83799:	48 8b 8c 24 40 02 00 	mov    0x240(%rsp),%rcx
   837a0:	00 
   837a1:	48 83 f9 01          	cmp    $0x1,%rcx
   837a5:	75 28                	jne    837cf <<oriole::Parser>::next_event_inner+0x223f>
   837a7:	84 c0                	test   %al,%al
   837a9:	74 24                	je     837cf <<oriole::Parser>::next_event_inner+0x223f>
   837ab:	41 0f b6 86 28 01 00 	movzbl 0x128(%r14),%eax
   837b2:	00 
   837b3:	34 01                	xor    $0x1,%al
   837b5:	41 84 86 b8 08 00 00 	test   %al,0x8b8(%r14)
   837bc:	75 11                	jne    837cf <<oriole::Parser>::next_event_inner+0x223f>
   837be:	41 80 be f8 07 00 00 	cmpb   $0xff,0x7f8(%r14)
   837c5:	ff 
   837c6:	75 07                	jne    837cf <<oriole::Parser>::next_event_inner+0x223f>
   837c8:	31 c0                	xor    %eax,%eax
   837ca:	e9 62 ec ff ff       	jmp    82431 <<oriole::Parser>::next_event_inner+0xea1>
   837cf:	4c 8b bc 24 10 02 00 	mov    0x210(%rsp),%r15
   837d6:	00 
   837d7:	49 83 ff 04          	cmp    $0x4,%r15
   837db:	73 60                	jae    8383d <<oriole::Parser>::next_event_inner+0x22ad>
   837dd:	49 83 ff 02          	cmp    $0x2,%r15
   837e1:	48 8b bc 24 38 02 00 	mov    0x238(%rsp),%rdi
   837e8:	00 
   837e9:	73 66                	jae    83851 <<oriole::Parser>::next_event_inner+0x22c1>
   837eb:	49 83 ff 01          	cmp    $0x1,%r15
   837ef:	75 76                	jne    83867 <<oriole::Parser>::next_event_inner+0x22d7>
   837f1:	48 83 f9 01          	cmp    $0x1,%rcx
   837f5:	75 70                	jne    83867 <<oriole::Parser>::next_event_inner+0x22d7>
   837f7:	80 3f 3c             	cmpb   $0x3c,(%rdi)
   837fa:	75 6b                	jne    83867 <<oriole::Parser>::next_event_inner+0x22d7>
   837fc:	41 0f b6 86 28 01 00 	movzbl 0x128(%r14),%eax
   83803:	00 
   83804:	34 01                	xor    $0x1,%al
   83806:	41 84 86 b8 08 00 00 	test   %al,0x8b8(%r14)
   8380d:	75 58                	jne    83867 <<oriole::Parser>::next_event_inner+0x22d7>
   8380f:	41 80 be f8 07 00 00 	cmpb   $0xff,0x7f8(%r14)
   83816:	ff 
   83817:	74 af                	je     837c8 <<oriole::Parser>::next_event_inner+0x2238>
   83819:	eb 4c                	jmp    83867 <<oriole::Parser>::next_event_inner+0x22d7>
   8381b:	41 b8 2d 00 00 00    	mov    $0x2d,%r8d
   83821:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83828:	00 
   83829:	4c 89 f6             	mov    %r14,%rsi
   8382c:	ba 03 00 00 00       	mov    $0x3,%edx
   83831:	48 8d 0d 5b e5 f8 ff 	lea    -0x71aa5(%rip),%rcx        # 11d93 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x53f7>
   83838:	e9 e2 fc ff ff       	jmp    8351f <<oriole::Parser>::next_event_inner+0x1f8f>
   8383d:	48 8b bc 24 38 02 00 	mov    0x238(%rsp),%rdi
   83844:	00 
   83845:	81 3f 3c 21 2d 2d    	cmpl   $0x2d2d213c,(%rdi)
   8384b:	0f 84 12 05 00 00    	je     83d63 <<oriole::Parser>::next_event_inner+0x27d3>
   83851:	66 81 3f 3c 3f       	cmpw   $0x3f3c,(%rdi)
   83856:	0f 84 a0 04 00 00    	je     83cfc <<oriole::Parser>::next_event_inner+0x276c>
   8385c:	66 81 3f 3c 21       	cmpw   $0x213c,(%rdi)
   83861:	0f 84 78 05 00 00    	je     83ddf <<oriole::Parser>::next_event_inner+0x284f>
   83867:	4c 89 fe             	mov    %r15,%rsi
   8386a:	48 89 fb             	mov    %rdi,%rbx
   8386d:	e8 5e fb 01 00       	call   a33d0 <<core::str::pattern::MultiCharEqPattern<[char; 2]> as core::str::pattern::Pattern>::is_prefix_of>
   83872:	84 c0                	test   %al,%al
   83874:	0f 84 36 04 00 00    	je     83cb0 <<oriole::Parser>::next_event_inner+0x2720>
   8387a:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   8387f:	4c 89 f6             	mov    %r14,%rsi
   83882:	e8 19 61 00 00       	call   899a0 <<oriole::Parser>::parse_prolog_literal>
   83887:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   8388c:	3c ff                	cmp    $0xff,%al
   8388e:	0f 84 d7 fc ff ff    	je     8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   83894:	e9 1b 15 00 00       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   83899:	48 85 d2             	test   %rdx,%rdx
   8389c:	0f 95 c0             	setne  %al
   8389f:	40 08 f0             	or     %sil,%al
   838a2:	a8 01                	test   $0x1,%al
   838a4:	0f 84 d5 1c 00 00    	je     8557f <<oriole::Parser>::next_event_inner+0x3fef>
   838aa:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   838b1:	48 85 c0             	test   %rax,%rax
   838b4:	0f 84 77 18 00 00    	je     85131 <<oriole::Parser>::next_event_inner+0x3ba1>
   838ba:	49 8b 8e 80 01 00 00 	mov    0x180(%r14),%rcx
   838c1:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   838c5:	48 c1 e2 07          	shl    $0x7,%rdx
   838c9:	48 8d 04 11          	lea    (%rcx,%rdx,1),%rax
   838cd:	83 bc 11 80 fe ff ff 	cmpl   $0x1,-0x180(%rcx,%rdx,1)
   838d4:	01 
   838d5:	0f 85 0e 03 00 00    	jne    83be9 <<oriole::Parser>::next_event_inner+0x2659>
   838db:	4c 8b b8 88 fe ff ff 	mov    -0x178(%rax),%r15
   838e2:	0f 10 80 90 fe ff ff 	movups -0x170(%rax),%xmm0
   838e9:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   838ee:	48 8b 98 a0 fe ff ff 	mov    -0x160(%rax),%rbx
   838f5:	e9 16 03 00 00       	jmp    83c10 <<oriole::Parser>::next_event_inner+0x2680>
   838fa:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   838ff:	66 0f ef c0          	pxor   %xmm0,%xmm0
   83903:	66 0f 7f 40 10       	movdqa %xmm0,0x10(%rax)
   83908:	c6 40 20 00          	movb   $0x0,0x20(%rax)
   8390c:	48 8d 05 99 db f8 ff 	lea    -0x72467(%rip),%rax        # 114ac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   83913:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   83918:	48 c7 44 24 28 0d 00 	movq   $0xd,0x28(%rsp)
   8391f:	00 00 
   83921:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   83928:	00 00 
   8392a:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
   83931:	00 00 
   83933:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   83938:	3c ff                	cmp    $0xff,%al
   8393a:	0f 84 2b fc ff ff    	je     8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   83940:	e9 6f 14 00 00       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   83945:	48 89 d8             	mov    %rbx,%rax
   83948:	48 8b 5b a8          	mov    -0x58(%rbx),%rbx
   8394c:	f3 0f 6f 40 d8       	movdqu -0x28(%rax),%xmm0
   83951:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
   83957:	31 f6                	xor    %esi,%esi
   83959:	31 d2                	xor    %edx,%edx
   8395b:	e8 d0 be fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   83960:	0f 28 64 24 70       	movaps 0x70(%rsp),%xmm4
   83965:	c6 84 24 88 01 00 00 	movb   $0x2,0x188(%rsp)
   8396c:	02 
   8396d:	0f 28 84 24 10 04 00 	movaps 0x410(%rsp),%xmm0
   83974:	00 
   83975:	0f 28 8c 24 20 04 00 	movaps 0x420(%rsp),%xmm1
   8397c:	00 
   8397d:	0f 28 94 24 30 04 00 	movaps 0x430(%rsp),%xmm2
   83984:	00 
   83985:	0f 28 9c 24 40 04 00 	movaps 0x440(%rsp),%xmm3
   8398c:	00 
   8398d:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   83994:	00 
   83995:	0f 29 8c 24 90 00 00 	movaps %xmm1,0x90(%rsp)
   8399c:	00 
   8399d:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
   839a4:	00 
   839a5:	0f 29 9c 24 b0 00 00 	movaps %xmm3,0xb0(%rsp)
   839ac:	00 
   839ad:	0f 28 84 24 50 04 00 	movaps 0x450(%rsp),%xmm0
   839b4:	00 
   839b5:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   839bc:	00 
   839bd:	0f 28 84 24 60 04 00 	movaps 0x460(%rsp),%xmm0
   839c4:	00 
   839c5:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   839cc:	00 
   839cd:	0f 28 84 24 70 04 00 	movaps 0x470(%rsp),%xmm0
   839d4:	00 
   839d5:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   839dc:	00 
   839dd:	0f 10 84 24 b0 02 00 	movups 0x2b0(%rsp),%xmm0
   839e4:	00 
   839e5:	48 8d 8c 24 88 00 00 	lea    0x88(%rsp),%rcx
   839ec:	00 
   839ed:	0f 11 81 c8 00 00 00 	movups %xmm0,0xc8(%rcx)
   839f4:	0f 10 84 24 a0 02 00 	movups 0x2a0(%rsp),%xmm0
   839fb:	00 
   839fc:	0f 11 81 b8 00 00 00 	movups %xmm0,0xb8(%rcx)
   83a03:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   83a0a:	00 
   83a0b:	0f 11 81 a8 00 00 00 	movups %xmm0,0xa8(%rcx)
   83a12:	0f 10 84 24 50 02 00 	movups 0x250(%rsp),%xmm0
   83a19:	00 
   83a1a:	0f 10 8c 24 60 02 00 	movups 0x260(%rsp),%xmm1
   83a21:	00 
   83a22:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   83a29:	00 00 
   83a2b:	0f 10 9c 24 80 02 00 	movups 0x280(%rsp),%xmm3
   83a32:	00 
   83a33:	0f 11 99 98 00 00 00 	movups %xmm3,0x98(%rcx)
   83a3a:	f3 0f 7f 91 88 00 00 	movdqu %xmm2,0x88(%rcx)
   83a41:	00 
   83a42:	0f 11 49 78          	movups %xmm1,0x78(%rcx)
   83a46:	0f 11 41 68          	movups %xmm0,0x68(%rcx)
   83a4a:	48 89 9c 24 60 01 00 	mov    %rbx,0x160(%rsp)
   83a51:	00 
   83a52:	0f 11 a4 24 68 01 00 	movups %xmm4,0x168(%rsp)
   83a59:	00 
   83a5a:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
   83a61:	00 
   83a62:	48 c7 84 24 80 01 00 	movq   $0x3,0x180(%rsp)
   83a69:	00 03 00 00 00 
   83a6e:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
   83a75:	00 
   83a76:	f3 0f 6f 00          	movdqu (%rax),%xmm0
   83a7a:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
   83a7f:	66 0f 7f 8c 24 60 02 	movdqa %xmm1,0x260(%rsp)
   83a86:	00 00 
   83a88:	66 0f 7f 84 24 50 02 	movdqa %xmm0,0x250(%rsp)
   83a8f:	00 00 
   83a91:	be 08 00 00 00       	mov    $0x8,%esi
   83a96:	ba 10 01 00 00       	mov    $0x110,%edx
   83a9b:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   83aa2:	00 
   83aa3:	ff 15 27 2e 06 00    	call   *0x62e27(%rip)        # e68d0 <_GLOBAL_OFFSET_TABLE_+0x158>
   83aa9:	48 85 c0             	test   %rax,%rax
   83aac:	0f 84 c8 00 00 00    	je     83b7a <<oriole::Parser>::next_event_inner+0x25ea>
   83ab2:	48 8b 9c 24 50 02 00 	mov    0x250(%rsp),%rbx
   83ab9:	00 
   83aba:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
   83abe:	0f 84 b6 00 00 00    	je     83b7a <<oriole::Parser>::next_event_inner+0x25ea>
   83ac4:	0f b6 ac 24 58 02 00 	movzbl 0x258(%rsp),%ebp
   83acb:	00 
   83acc:	48 8b 8c 24 10 05 00 	mov    0x510(%rsp),%rcx
   83ad3:	00 
   83ad4:	0f 10 01             	movups (%rcx),%xmm0
   83ad7:	0f 29 84 24 f0 03 00 	movaps %xmm0,0x3f0(%rsp)
   83ade:	00 
   83adf:	48 8b 49 0f          	mov    0xf(%rcx),%rcx
   83ae3:	48 89 8c 24 ff 03 00 	mov    %rcx,0x3ff(%rsp)
   83aea:	00 
   83aeb:	ba 10 01 00 00       	mov    $0x110,%edx
   83af0:	48 89 c7             	mov    %rax,%rdi
   83af3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
   83afa:	00 
   83afb:	4c 89 e6             	mov    %r12,%rsi
   83afe:	49 89 c7             	mov    %rax,%r15
   83b01:	ff 15 e1 35 06 00    	call   *0x635e1(%rip)        # e70e8 <memmove@GLIBC_2.2.5>
   83b07:	49 89 9e f0 03 00 00 	mov    %rbx,0x3f0(%r14)
   83b0e:	41 88 ae f8 03 00 00 	mov    %bpl,0x3f8(%r14)
   83b15:	48 8b 84 24 ff 03 00 	mov    0x3ff(%rsp),%rax
   83b1c:	00 
   83b1d:	48 8b 8c 24 08 05 00 	mov    0x508(%rsp),%rcx
   83b24:	00 
   83b25:	48 89 41 0f          	mov    %rax,0xf(%rcx)
   83b29:	66 0f 6f 84 24 f0 03 	movdqa 0x3f0(%rsp),%xmm0
   83b30:	00 00 
   83b32:	f3 0f 7f 01          	movdqu %xmm0,(%rcx)
   83b36:	4d 89 be 10 04 00 00 	mov    %r15,0x410(%r14)
   83b3d:	ba 03 00 00 00       	mov    $0x3,%edx
   83b42:	4c 89 e7             	mov    %r12,%rdi
   83b45:	4c 89 f6             	mov    %r14,%rsi
   83b48:	e8 43 d4 00 00       	call   90f90 <<oriole::Parser>::consume>
   83b4d:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   83b54:	ff 
   83b55:	0f 85 c9 f9 ff ff    	jne    83524 <<oriole::Parser>::next_event_inner+0x1f94>
   83b5b:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   83b60:	4c 89 f6             	mov    %r14,%rsi
   83b63:	e8 d8 45 fd ff       	call   58140 <<oriole::Parser>::continue_header_composition>
   83b68:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   83b6d:	3c ff                	cmp    $0xff,%al
   83b6f:	0f 84 f6 f9 ff ff    	je     8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   83b75:	e9 3a 12 00 00       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   83b7a:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83b81:	00 
   83b82:	e8 c9 62 fc ff       	call   49e50 <core::ptr::drop_glue::<oriole::dtd::composition::Header>>
   83b87:	48 8d 05 1e d9 f8 ff 	lea    -0x726e2(%rip),%rax        # 114ac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   83b8e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   83b93:	48 c7 44 24 28 0d 00 	movq   $0xd,0x28(%rsp)
   83b9a:	00 00 
   83b9c:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   83ba3:	00 00 
   83ba5:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
   83bac:	00 00 
   83bae:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   83bb3:	66 0f ef c0          	pxor   %xmm0,%xmm0
   83bb7:	66 0f 7f 40 10       	movdqa %xmm0,0x10(%rax)
   83bbc:	c6 40 20 00          	movb   $0x0,0x20(%rax)
   83bc0:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   83bc5:	3c ff                	cmp    $0xff,%al
   83bc7:	0f 84 9e f9 ff ff    	je     8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   83bcd:	e9 e2 11 00 00       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   83bd2:	c6 84 24 30 03 00 00 	movb   $0x2,0x330(%rsp)
   83bd9:	02 
   83bda:	80 78 02 c0          	cmpb   $0xc0,0x2(%rax)
   83bde:	0f 8d 00 eb ff ff    	jge    826e4 <<oriole::Parser>::next_event_inner+0x1154>
   83be4:	e9 4e 1b 00 00       	jmp    85737 <<oriole::Parser>::next_event_inner+0x41a7>
   83be9:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
   83bed:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   83bf4:	4c 8b 78 a8          	mov    -0x58(%rax),%r15
   83bf8:	0f 10 40 d8          	movups -0x28(%rax),%xmm0
   83bfc:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   83c01:	ba 09 00 00 00       	mov    $0x9,%edx
   83c06:	31 f6                	xor    %esi,%esi
   83c08:	e8 23 bc fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   83c0d:	48 89 c3             	mov    %rax,%rbx
   83c10:	ba 09 00 00 00       	mov    $0x9,%edx
   83c15:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
   83c1c:	00 
   83c1d:	4c 89 e7             	mov    %r12,%rdi
   83c20:	4c 89 f6             	mov    %r14,%rsi
   83c23:	e8 48 1e 00 00       	call   85a70 <<oriole::Parser>::save_current_raw>
   83c28:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   83c2f:	ff 
   83c30:	0f 85 78 15 00 00    	jne    851ae <<oriole::Parser>::next_event_inner+0x3c1e>
   83c36:	ba 09 00 00 00       	mov    $0x9,%edx
   83c3b:	4c 89 e7             	mov    %r12,%rdi
   83c3e:	4c 89 f6             	mov    %r14,%rsi
   83c41:	e8 4a d3 00 00       	call   90f90 <<oriole::Parser>::consume>
   83c46:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   83c4d:	ff 
   83c4e:	0f 85 5a 15 00 00    	jne    851ae <<oriole::Parser>::next_event_inner+0x3c1e>
   83c54:	41 c6 86 b7 08 00 00 	movb   $0x1,0x8b7(%r14)
   83c5b:	01 
   83c5c:	48 c7 84 24 b8 00 00 	movq   $0xe,0xb8(%rsp)
   83c63:	00 0e 00 00 00 
   83c68:	4c 89 bc 24 30 01 00 	mov    %r15,0x130(%rsp)
   83c6f:	00 
   83c70:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   83c76:	f3 0f 7f 84 24 38 01 	movdqu %xmm0,0x138(%rsp)
   83c7d:	00 00 
   83c7f:	48 89 9c 24 48 01 00 	mov    %rbx,0x148(%rsp)
   83c86:	00 
   83c87:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   83c8e:	00 ff ff ff ff 
   83c93:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   83c9a:	00 
   83c9b:	4c 89 e6             	mov    %r12,%rsi
   83c9e:	e8 fd 37 fd ff       	call   574a0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   83ca3:	3c ff                	cmp    $0xff,%al
   83ca5:	0f 84 f5 db ff ff    	je     818a0 <<oriole::Parser>::next_event_inner+0x310>
   83cab:	e9 f1 18 00 00       	jmp    855a1 <<oriole::Parser>::next_event_inner+0x4011>
   83cb0:	31 d2                	xor    %edx,%edx
   83cb2:	41 83 be c8 07 00 00 	cmpl   $0xffffffff,0x7c8(%r14)
   83cb9:	ff 
   83cba:	0f 95 c2             	setne  %dl
   83cbd:	41 0f b6 8e cc 07 00 	movzbl 0x7cc(%r14),%ecx
   83cc4:	00 
   83cc5:	48 89 df             	mov    %rbx,%rdi
   83cc8:	4c 89 fe             	mov    %r15,%rsi
   83ccb:	e8 a0 c1 01 00       	call   9fe70 <oriole::dtd::invalid_dtd_token>
   83cd0:	48 83 f8 01          	cmp    $0x1,%rax
   83cd4:	0f 85 a3 02 00 00    	jne    83f7d <<oriole::Parser>::next_event_inner+0x29ed>
   83cda:	41 b8 14 00 00 00    	mov    $0x14,%r8d
   83ce0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83ce7:	00 
   83ce8:	4c 89 f6             	mov    %r14,%rsi
   83ceb:	ba 03 00 00 00       	mov    $0x3,%edx
   83cf0:	48 8d 0d 9b df f8 ff 	lea    -0x72065(%rip),%rcx        # 11c92 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x52f6>
   83cf7:	e9 23 f8 ff ff       	jmp    8351f <<oriole::Parser>::next_event_inner+0x1f8f>
   83cfc:	49 8b 9e 98 07 00 00 	mov    0x798(%r14),%rbx
   83d03:	49 83 ff 02          	cmp    $0x2,%r15
   83d07:	74 0a                	je     83d13 <<oriole::Parser>::next_event_inner+0x2783>
   83d09:	80 7f 02 bf          	cmpb   $0xbf,0x2(%rdi)
   83d0d:	0f 8e 9a 1a 00 00    	jle    857ad <<oriole::Parser>::next_event_inner+0x421d>
   83d13:	48 83 c7 02          	add    $0x2,%rdi
   83d17:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
   83d1e:	00 
   83d1f:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
   83d26:	00 
   83d27:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83d2e:	00 
   83d2f:	e8 ec 6a fc ff       	call   4a820 <core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>>
   83d34:	a8 01                	test   $0x1,%al
   83d36:	74 17                	je     83d4f <<oriole::Parser>::next_event_inner+0x27bf>
   83d38:	41 0f b6 be cc 07 00 	movzbl 0x7cc(%r14),%edi
   83d3f:	00 
   83d40:	89 d6                	mov    %edx,%esi
   83d42:	e8 d9 1f fd ff       	call   55d20 <<oriole::names::NameRules>::is_name_start>
   83d47:	84 c0                	test   %al,%al
   83d49:	0f 84 70 03 00 00    	je     840bf <<oriole::Parser>::next_event_inner+0x2b2f>
   83d4f:	40 b5 02             	mov    $0x2,%bpl
   83d52:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   83d59:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   83d5e:	e9 8b 00 00 00       	jmp    83dee <<oriole::Parser>::next_event_inner+0x285e>
   83d63:	40 b5 01             	mov    $0x1,%bpl
   83d66:	eb 7a                	jmp    83de2 <<oriole::Parser>::next_event_inner+0x2852>
   83d68:	c6 84 24 30 03 00 00 	movb   $0x3,0x330(%rsp)
   83d6f:	03 
   83d70:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   83d77:	48 83 f8 01          	cmp    $0x1,%rax
   83d7b:	0f 86 2c ef ff ff    	jbe    82cad <<oriole::Parser>::next_event_inner+0x171d>
   83d81:	e9 43 ef ff ff       	jmp    82cc9 <<oriole::Parser>::next_event_inner+0x1739>
   83d86:	48 83 f8 01          	cmp    $0x1,%rax
   83d8a:	0f 86 6f 02 00 00    	jbe    83fff <<oriole::Parser>::next_event_inner+0x2a6f>
   83d90:	41 b8 22 00 00 00    	mov    $0x22,%r8d
   83d96:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83d9d:	00 
   83d9e:	4c 89 f6             	mov    %r14,%rsi
   83da1:	ba 04 00 00 00       	mov    $0x4,%edx
   83da6:	48 8d 0d c4 df f8 ff 	lea    -0x7203c(%rip),%rcx        # 11d71 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x53d5>
   83dad:	e9 6d f7 ff ff       	jmp    8351f <<oriole::Parser>::next_event_inner+0x1f8f>
   83db2:	41 b8 1c 00 00 00    	mov    $0x1c,%r8d
   83db8:	41 b9 02 00 00 00    	mov    $0x2,%r9d
   83dbe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83dc5:	00 
   83dc6:	4c 89 f6             	mov    %r14,%rsi
   83dc9:	ba 03 00 00 00       	mov    $0x3,%edx
   83dce:	48 8d 0d a1 de f8 ff 	lea    -0x7215f(%rip),%rcx        # 11c76 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x52da>
   83dd5:	e8 36 d1 00 00       	call   90f10 <<oriole::Parser>::err_at>
   83dda:	e9 45 f7 ff ff       	jmp    83524 <<oriole::Parser>::next_event_inner+0x1f94>
   83ddf:	40 b5 04             	mov    $0x4,%bpl
   83de2:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   83de7:	49 8b 9e 98 07 00 00 	mov    0x798(%r14),%rbx
   83dee:	40 0f b6 d5          	movzbl %bpl,%edx
   83df2:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   83df9:	00 
   83dfa:	48 89 d9             	mov    %rbx,%rcx
   83dfd:	e8 ce a0 fe ff       	call   6ded0 <<oriole::encoding::Source>::scan_token>
   83e02:	4c 8b bc 24 60 02 00 	mov    0x260(%rsp),%r15
   83e09:	00 
   83e0a:	80 bc 24 50 02 00 00 	cmpb   $0x0,0x250(%rsp)
   83e11:	00 
   83e12:	74 7a                	je     83e8e <<oriole::Parser>::next_event_inner+0x28fe>
   83e14:	8b 8c 24 58 02 00 00 	mov    0x258(%rsp),%ecx
   83e1b:	49 8b b6 80 01 00 00 	mov    0x180(%r14),%rsi
   83e22:	49 8b 96 90 01 00 00 	mov    0x190(%r14),%rdx
   83e29:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83e30:	00 
   83e31:	4d 89 f8             	mov    %r15,%r8
   83e34:	e8 d7 8a fc ff       	call   4c910 <<oriole::Parser>::parse_dtd_step::{closure#4}>
   83e39:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
   83e40:	00 
   83e41:	0f 28 00             	movaps (%rax),%xmm0
   83e44:	66 0f 6f 48 10       	movdqa 0x10(%rax),%xmm1
   83e49:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   83e4e:	66 0f 7f 4e 10       	movdqa %xmm1,0x10(%rsi)
   83e53:	0f 29 06             	movaps %xmm0,(%rsi)
   83e56:	0f b6 84 24 b0 00 00 	movzbl 0xb0(%rsp),%eax
   83e5d:	00 
   83e5e:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   83e65:	00 
   83e66:	8b 4a 29             	mov    0x29(%rdx),%ecx
   83e69:	8b 52 2c             	mov    0x2c(%rdx),%edx
   83e6c:	89 56 24             	mov    %edx,0x24(%rsi)
   83e6f:	89 4e 21             	mov    %ecx,0x21(%rsi)
   83e72:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
   83e79:	00 00 
   83e7b:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   83e81:	3c ff                	cmp    $0xff,%al
   83e83:	0f 84 e2 f6 ff ff    	je     8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   83e89:	e9 26 0f 00 00       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   83e8e:	83 bc 24 58 02 00 00 	cmpl   $0x1,0x258(%rsp)
   83e95:	01 
   83e96:	75 64                	jne    83efc <<oriole::Parser>::next_event_inner+0x296c>
   83e98:	40 80 fd 04          	cmp    $0x4,%bpl
   83e9c:	0f 85 fd 00 00 00    	jne    83f9f <<oriole::Parser>::next_event_inner+0x2a0f>
   83ea2:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   83ea9:	48 85 c0             	test   %rax,%rax
   83eac:	0f 84 7f 12 00 00    	je     85131 <<oriole::Parser>::next_event_inner+0x3ba1>
   83eb2:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   83eb7:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   83ebe:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   83ec2:	48 c1 e0 07          	shl    $0x7,%rax
   83ec6:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
   83eca:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   83ed1:	e8 0a bc fe ff       	call   6fae0 <<oriole::encoding::Source>::remaining>
   83ed6:	49 8d 7f ff          	lea    -0x1(%r15),%rdi
   83eda:	48 39 d7             	cmp    %rdx,%rdi
   83edd:	0f 83 7f 18 00 00    	jae    85762 <<oriole::Parser>::next_event_inner+0x41d2>
   83ee3:	80 3c 38 25          	cmpb   $0x25,(%rax,%rdi,1)
   83ee7:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   83eec:	0f 85 ad 00 00 00    	jne    83f9f <<oriole::Parser>::next_event_inner+0x2a0f>
   83ef2:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   83ef7:	e9 34 03 00 00       	jmp    84230 <<oriole::Parser>::next_event_inner+0x2ca0>
   83efc:	40 80 fd 04          	cmp    $0x4,%bpl
   83f00:	0f 94 c1             	sete   %cl
   83f03:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   83f0a:	48 83 f8 02          	cmp    $0x2,%rax
   83f0e:	0f 93 c2             	setae  %dl
   83f11:	84 d1                	test   %dl,%cl
   83f13:	0f 84 70 01 00 00    	je     84089 <<oriole::Parser>::next_event_inner+0x2af9>
   83f19:	48 8d 05 78 f7 05 00 	lea    0x5f778(%rip),%rax        # e3698 <oriole_expat::FEATURES+0xab0>
   83f20:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   83f27:	00 
   83f28:	48 8d 05 a9 f7 05 00 	lea    0x5f7a9(%rip),%rax        # e36d8 <oriole_expat::FEATURES+0xaf0>
   83f2f:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   83f36:	00 
   83f37:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83f3e:	00 
   83f3f:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   83f44:	e8 07 80 fc ff       	call   4bf50 <<core::slice::iter::Iter<&str> as core::iter::traits::iterator::Iterator>::any::<<oriole::Parser>::parse_dtd_step::{closure#7}>>
   83f49:	84 c0                	test   %al,%al
   83f4b:	0f 84 d5 02 00 00    	je     84226 <<oriole::Parser>::next_event_inner+0x2c96>
   83f51:	41 b8 2f 00 00 00    	mov    $0x2f,%r8d
   83f57:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83f5e:	00 
   83f5f:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   83f64:	4c 89 f6             	mov    %r14,%rsi
   83f67:	ba 04 00 00 00       	mov    $0x4,%edx
   83f6c:	48 8d 0d 81 dd f8 ff 	lea    -0x7227f(%rip),%rcx        # 11cf4 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5358>
   83f73:	e8 38 c5 00 00       	call   904b0 <<oriole::Parser>::err>
   83f78:	e9 0b e3 ff ff       	jmp    82288 <<oriole::Parser>::next_event_inner+0xcf8>
   83f7d:	41 b8 16 00 00 00    	mov    $0x16,%r8d
   83f83:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83f8a:	00 
   83f8b:	4c 89 f6             	mov    %r14,%rsi
   83f8e:	ba 01 00 00 00       	mov    $0x1,%edx
   83f93:	48 8d 0d 0c dd f8 ff 	lea    -0x722f4(%rip),%rcx        # 11ca6 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x530a>
   83f9a:	e9 80 f5 ff ff       	jmp    8351f <<oriole::Parser>::next_event_inner+0x1f8f>
   83f9f:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   83fa6:	00 
   83fa7:	4c 89 f6             	mov    %r14,%rsi
   83faa:	4c 89 fa             	mov    %r15,%rdx
   83fad:	e8 7e 8d ff ff       	call   7cd30 <<oriole::Parser>::account_source>
   83fb2:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   83fb9:	ff 
   83fba:	0f 84 cf 01 00 00    	je     8418f <<oriole::Parser>::next_event_inner+0x2bff>
   83fc0:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   83fc7:	00 
   83fc8:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   83fcd:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   83fd4:	00 00 
   83fd6:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   83fdd:	00 00 
   83fdf:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   83fe6:	00 00 
   83fe8:	66 0f 7f 54 24 40    	movdqa %xmm2,0x40(%rsp)
   83fee:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   83ff4:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   83ffa:	e9 39 07 00 00       	jmp    84738 <<oriole::Parser>::next_event_inner+0x31a8>
   83fff:	41 0f b6 86 28 01 00 	movzbl 0x128(%r14),%eax
   84006:	00 
   84007:	34 01                	xor    $0x1,%al
   84009:	41 84 86 b8 08 00 00 	test   %al,0x8b8(%r14)
   84010:	0f 85 7a fd ff ff    	jne    83d90 <<oriole::Parser>::next_event_inner+0x2800>
   84016:	41 80 be f8 07 00 00 	cmpb   $0xff,0x7f8(%r14)
   8401d:	ff 
   8401e:	0f 84 a4 f7 ff ff    	je     837c8 <<oriole::Parser>::next_event_inner+0x2238>
   84024:	e9 67 fd ff ff       	jmp    83d90 <<oriole::Parser>::next_event_inner+0x2800>
   84029:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   8402e:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   84035:	48 85 c0             	test   %rax,%rax
   84038:	0f 84 f3 10 00 00    	je     85131 <<oriole::Parser>::next_event_inner+0x3ba1>
   8403e:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   84043:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   8404a:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   8404e:	48 c1 e6 07          	shl    $0x7,%rsi
   84052:	48 8d 14 31          	lea    (%rcx,%rsi,1),%rdx
   84056:	83 bc 31 80 fe ff ff 	cmpl   $0x1,-0x180(%rcx,%rsi,1)
   8405d:	01 
   8405e:	0f 85 88 00 00 00    	jne    840ec <<oriole::Parser>::next_event_inner+0x2b5c>
   84064:	0f 10 82 88 fe ff ff 	movups -0x178(%rdx),%xmm0
   8406b:	f3 0f 6f 8a 98 fe ff 	movdqu -0x168(%rdx),%xmm1
   84072:	ff 
   84073:	66 0f 7f 8c 24 00 04 	movdqa %xmm1,0x400(%rsp)
   8407a:	00 00 
   8407c:	0f 29 84 24 f0 03 00 	movaps %xmm0,0x3f0(%rsp)
   84083:	00 
   84084:	e9 c3 00 00 00       	jmp    8414c <<oriole::Parser>::next_event_inner+0x2bbc>
   84089:	48 83 f8 01          	cmp    $0x1,%rax
   8408d:	0f 86 be 01 00 00    	jbe    84251 <<oriole::Parser>::next_event_inner+0x2cc1>
   84093:	41 b8 18 00 00 00    	mov    $0x18,%r8d
   84099:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   840a0:	00 
   840a1:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   840a6:	4c 89 f6             	mov    %r14,%rsi
   840a9:	ba 04 00 00 00       	mov    $0x4,%edx
   840ae:	48 8d 0d ed d2 f8 ff 	lea    -0x72d13(%rip),%rcx        # 113a2 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4a06>
   840b5:	e8 f6 c3 00 00       	call   904b0 <<oriole::Parser>::err>
   840ba:	e9 c9 e1 ff ff       	jmp    82288 <<oriole::Parser>::next_event_inner+0xcf8>
   840bf:	41 b8 25 00 00 00    	mov    $0x25,%r8d
   840c5:	41 b9 02 00 00 00    	mov    $0x2,%r9d
   840cb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   840d2:	00 
   840d3:	4c 89 f6             	mov    %r14,%rsi
   840d6:	ba 03 00 00 00       	mov    $0x3,%edx
   840db:	48 8d 0d 41 dc f8 ff 	lea    -0x723bf(%rip),%rcx        # 11d23 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5387>
   840e2:	e8 29 ce 00 00       	call   90f10 <<oriole::Parser>::err_at>
   840e7:	e9 9c e1 ff ff       	jmp    82288 <<oriole::Parser>::next_event_inner+0xcf8>
   840ec:	48 8d 3c 31          	lea    (%rcx,%rsi,1),%rdi
   840f0:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   840f7:	48 8b 5a a8          	mov    -0x58(%rdx),%rbx
   840fb:	0f 10 42 d8          	movups -0x28(%rdx),%xmm0
   840ff:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   84104:	31 f6                	xor    %esi,%esi
   84106:	4c 89 fa             	mov    %r15,%rdx
   84109:	e8 22 b7 fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   8410e:	48 89 9c 24 f0 03 00 	mov    %rbx,0x3f0(%rsp)
   84115:	00 
   84116:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   8411b:	0f 11 84 24 f8 03 00 	movups %xmm0,0x3f8(%rsp)
   84122:	00 
   84123:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
   8412a:	00 
   8412b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   84130:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   84137:	48 85 c0             	test   %rax,%rax
   8413a:	0f 84 f1 0f 00 00    	je     85131 <<oriole::Parser>::next_event_inner+0x3ba1>
   84140:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   84145:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   8414c:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   84150:	48 c1 e0 07          	shl    $0x7,%rax
   84154:	48 8d 34 01          	lea    (%rcx,%rax,1),%rsi
   84158:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
   8415f:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   84166:	00 
   84167:	e8 a4 b1 fe ff       	call   6f310 <<oriole::encoding::Source>::lexical_remaining>
   8416c:	4d 85 ff             	test   %r15,%r15
   8416f:	0f 84 25 01 00 00    	je     8429a <<oriole::Parser>::next_event_inner+0x2d0a>
   84175:	49 39 ef             	cmp    %rbp,%r15
   84178:	0f 83 0b 01 00 00    	jae    84289 <<oriole::Parser>::next_event_inner+0x2cf9>
   8417e:	43 80 7c 3d 00 c0    	cmpb   $0xc0,0x0(%r13,%r15,1)
   84184:	0f 8d 10 01 00 00    	jge    8429a <<oriole::Parser>::next_event_inner+0x2d0a>
   8418a:	e9 4b 14 00 00       	jmp    855da <<oriole::Parser>::next_event_inner+0x404a>
   8418f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   84194:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   8419b:	48 85 c0             	test   %rax,%rax
   8419e:	0f 84 8d 0f 00 00    	je     85131 <<oriole::Parser>::next_event_inner+0x3ba1>
   841a4:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
   841a9:	48 8b 8b 80 01 00 00 	mov    0x180(%rbx),%rcx
   841b0:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   841b4:	48 c1 e0 07          	shl    $0x7,%rax
   841b8:	48 8d 34 01          	lea    (%rcx,%rax,1),%rsi
   841bc:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
   841c3:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
   841ca:	00 
   841cb:	e8 40 b1 fe ff       	call   6f310 <<oriole::encoding::Source>::lexical_remaining>
   841d0:	48 8b 83 90 01 00 00 	mov    0x190(%rbx),%rax
   841d7:	48 85 c0             	test   %rax,%rax
   841da:	0f 84 51 0f 00 00    	je     85131 <<oriole::Parser>::next_event_inner+0x3ba1>
   841e0:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   841e5:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   841ec:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   841f0:	48 c1 e0 07          	shl    $0x7,%rax
   841f4:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
   841f8:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   841ff:	e8 dc b8 fe ff       	call   6fae0 <<oriole::encoding::Source>::remaining>
   84204:	4d 85 ff             	test   %r15,%r15
   84207:	0f 84 25 02 00 00    	je     84432 <<oriole::Parser>::next_event_inner+0x2ea2>
   8420d:	49 39 d7             	cmp    %rdx,%r15
   84210:	0f 83 09 02 00 00    	jae    8441f <<oriole::Parser>::next_event_inner+0x2e8f>
   84216:	42 80 3c 38 c0       	cmpb   $0xc0,(%rax,%r15,1)
   8421b:	0f 8d 11 02 00 00    	jge    84432 <<oriole::Parser>::next_event_inner+0x2ea2>
   84221:	e9 03 14 00 00       	jmp    85629 <<oriole::Parser>::next_event_inner+0x4099>
   84226:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   8422b:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   84230:	4c 89 f6             	mov    %r14,%rsi
   84233:	e8 48 65 fd ff       	call   5a780 <<oriole::Parser>::start_declaration_composition>
   84238:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   8423f:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   84244:	3c ff                	cmp    $0xff,%al
   84246:	0f 84 1f f3 ff ff    	je     8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   8424c:	e9 63 0b 00 00       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   84251:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   84256:	0f b6 81 28 01 00 00 	movzbl 0x128(%rcx),%eax
   8425d:	34 01                	xor    $0x1,%al
   8425f:	84 81 b8 08 00 00    	test   %al,0x8b8(%rcx)
   84265:	0f 85 28 fe ff ff    	jne    84093 <<oriole::Parser>::next_event_inner+0x2b03>
   8426b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   84270:	80 b8 f8 07 00 00 ff 	cmpb   $0xff,0x7f8(%rax)
   84277:	0f 85 16 fe ff ff    	jne    84093 <<oriole::Parser>::next_event_inner+0x2b03>
   8427d:	31 c0                	xor    %eax,%eax
   8427f:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   84284:	e9 a1 e1 ff ff       	jmp    8242a <<oriole::Parser>::next_event_inner+0xe9a>
   84289:	0f 95 c0             	setne  %al
   8428c:	4d 85 ed             	test   %r13,%r13
   8428f:	0f 94 c1             	sete   %cl
   84292:	08 c1                	or     %al,%cl
   84294:	0f 85 40 13 00 00    	jne    855da <<oriole::Parser>::next_event_inner+0x404a>
   8429a:	48 8d 9c 24 10 04 00 	lea    0x410(%rsp),%rbx
   842a1:	00 
   842a2:	48 89 df             	mov    %rbx,%rdi
   842a5:	4c 8d b4 24 50 02 00 	lea    0x250(%rsp),%r14
   842ac:	00 
   842ad:	4c 89 f6             	mov    %r14,%rsi
   842b0:	4c 89 ea             	mov    %r13,%rdx
   842b3:	4c 89 f9             	mov    %r15,%rcx
   842b6:	e8 15 8e 01 00       	call   9d0d0 <<oriole::lexical::Slice>::for_slice>
   842bb:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
   842c2:	00 
   842c3:	f3 0f 6f 00          	movdqu (%rax),%xmm0
   842c7:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
   842cc:	66 0f 7f 8c 24 60 02 	movdqa %xmm1,0x260(%rsp)
   842d3:	00 00 
   842d5:	66 0f 7f 84 24 50 02 	movdqa %xmm0,0x250(%rsp)
   842dc:	00 00 
   842de:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   842e5:	00 
   842e6:	48 89 de             	mov    %rbx,%rsi
   842e9:	4c 89 f2             	mov    %r14,%rdx
   842ec:	e8 ff 85 01 00       	call   9c8f0 <<oriole::lexical::Slice>::decode>
   842f1:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   842f8:	00 
   842f9:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   842fd:	0f 84 47 02 00 00    	je     8454a <<oriole::Parser>::next_event_inner+0x2fba>
   84303:	0f b6 8c 24 88 00 00 	movzbl 0x88(%rsp),%ecx
   8430a:	00 
   8430b:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   84312:	00 
   84313:	f3 0f 6f 42 01       	movdqu 0x1(%rdx),%xmm0
   84318:	f3 0f 6f 4a 11       	movdqu 0x11(%rdx),%xmm1
   8431d:	f3 0f 6f 52 20       	movdqu 0x20(%rdx),%xmm2
   84322:	48 8d 94 24 80 03 00 	lea    0x380(%rsp),%rdx
   84329:	00 
   8432a:	f3 0f 7f 52 08       	movdqu %xmm2,0x8(%rdx)
   8432f:	f3 0f 7f 4a f9       	movdqu %xmm1,-0x7(%rdx)
   84334:	f3 0f 7f 42 e9       	movdqu %xmm0,-0x17(%rdx)
   84339:	48 89 84 24 60 03 00 	mov    %rax,0x360(%rsp)
   84340:	00 
   84341:	88 8c 24 68 03 00 00 	mov    %cl,0x368(%rsp)
   84348:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8434f:	00 
   84350:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   84355:	4c 89 fa             	mov    %r15,%rdx
   84358:	e8 d3 89 ff ff       	call   7cd30 <<oriole::Parser>::account_source>
   8435d:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84364:	ff 
   84365:	74 50                	je     843b7 <<oriole::Parser>::next_event_inner+0x2e27>
   84367:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   8436e:	00 
   8436f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   84374:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   8437b:	00 00 
   8437d:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   84384:	00 00 
   84386:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   8438d:	00 00 
   8438f:	66 0f 7f 54 24 40    	movdqa %xmm2,0x40(%rsp)
   84395:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   8439b:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   843a1:	48 8b 8c 24 88 03 00 	mov    0x388(%rsp),%rcx
   843a8:	00 
   843a9:	48 85 c9             	test   %rcx,%rcx
   843ac:	0f 85 6b 03 00 00    	jne    8471d <<oriole::Parser>::next_event_inner+0x318d>
   843b2:	e9 81 03 00 00       	jmp    84738 <<oriole::Parser>::next_event_inner+0x31a8>
   843b7:	48 c7 84 24 50 02 00 	movq   $0x14,0x250(%rsp)
   843be:	00 14 00 00 00 
   843c3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   843c8:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   843cf:	48 85 c0             	test   %rax,%rax
   843d2:	0f 84 31 13 00 00    	je     85709 <<oriole::Parser>::next_event_inner+0x4179>
   843d8:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   843dd:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   843e4:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   843e8:	48 c1 e2 07          	shl    $0x7,%rdx
   843ec:	48 8d 04 11          	lea    (%rcx,%rdx,1),%rax
   843f0:	83 bc 11 80 fe ff ff 	cmpl   $0x1,-0x180(%rcx,%rdx,1)
   843f7:	01 
   843f8:	0f 85 fa 01 00 00    	jne    845f8 <<oriole::Parser>::next_event_inner+0x3068>
   843fe:	48 8b 98 88 fe ff ff 	mov    -0x178(%rax),%rbx
   84405:	f3 0f 6f 80 90 fe ff 	movdqu -0x170(%rax),%xmm0
   8440c:	ff 
   8440d:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
   84413:	48 8b 80 a0 fe ff ff 	mov    -0x160(%rax),%rax
   8441a:	e9 ff 01 00 00       	jmp    8461e <<oriole::Parser>::next_event_inner+0x308e>
   8441f:	0f 95 c1             	setne  %cl
   84422:	48 85 c0             	test   %rax,%rax
   84425:	40 0f 94 c6          	sete   %sil
   84429:	40 08 ce             	or     %cl,%sil
   8442c:	0f 85 f7 11 00 00    	jne    85629 <<oriole::Parser>::next_event_inner+0x4099>
   84432:	4c 8d b4 24 60 03 00 	lea    0x360(%rsp),%r14
   84439:	00 
   8443a:	4c 89 f7             	mov    %r14,%rdi
   8443d:	48 8d 9c 24 10 04 00 	lea    0x410(%rsp),%rbx
   84444:	00 
   84445:	48 89 de             	mov    %rbx,%rsi
   84448:	48 89 c2             	mov    %rax,%rdx
   8444b:	4c 89 f9             	mov    %r15,%rcx
   8444e:	e8 7d 8c 01 00       	call   9d0d0 <<oriole::lexical::Slice>::for_slice>
   84453:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
   8445a:	00 
   8445b:	f3 0f 6f 00          	movdqu (%rax),%xmm0
   8445f:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
   84464:	66 0f 7f 8c 24 20 04 	movdqa %xmm1,0x420(%rsp)
   8446b:	00 00 
   8446d:	66 0f 7f 84 24 10 04 	movdqa %xmm0,0x410(%rsp)
   84474:	00 00 
   84476:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8447d:	00 
   8447e:	4c 89 f6             	mov    %r14,%rsi
   84481:	48 89 da             	mov    %rbx,%rdx
   84484:	e8 47 88 01 00       	call   9ccd0 <<oriole::lexical::Slice>::to_owned>
   84489:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   84490:	00 
   84491:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   84495:	0f 84 af 00 00 00    	je     8454a <<oriole::Parser>::next_event_inner+0x2fba>
   8449b:	0f b6 8c 24 88 00 00 	movzbl 0x88(%rsp),%ecx
   844a2:	00 
   844a3:	48 8d b4 24 88 00 00 	lea    0x88(%rsp),%rsi
   844aa:	00 
   844ab:	48 8b 56 60          	mov    0x60(%rsi),%rdx
   844af:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
   844b6:	00 
   844b7:	48 89 57 60          	mov    %rdx,0x60(%rdi)
   844bb:	0f 10 46 51          	movups 0x51(%rsi),%xmm0
   844bf:	0f 11 47 51          	movups %xmm0,0x51(%rdi)
   844c3:	0f 10 46 41          	movups 0x41(%rsi),%xmm0
   844c7:	0f 11 47 41          	movups %xmm0,0x41(%rdi)
   844cb:	f3 0f 6f 46 01       	movdqu 0x1(%rsi),%xmm0
   844d0:	f3 0f 6f 4e 11       	movdqu 0x11(%rsi),%xmm1
   844d5:	f3 0f 6f 56 21       	movdqu 0x21(%rsi),%xmm2
   844da:	0f 10 5e 31          	movups 0x31(%rsi),%xmm3
   844de:	0f 11 5f 31          	movups %xmm3,0x31(%rdi)
   844e2:	f3 0f 7f 57 21       	movdqu %xmm2,0x21(%rdi)
   844e7:	f3 0f 7f 4f 11       	movdqu %xmm1,0x11(%rdi)
   844ec:	f3 0f 7f 47 01       	movdqu %xmm0,0x1(%rdi)
   844f1:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
   844f8:	00 
   844f9:	88 8c 24 58 02 00 00 	mov    %cl,0x258(%rsp)
   84500:	48 8b 9c 24 70 02 00 	mov    0x270(%rsp),%rbx
   84507:	00 
   84508:	4c 8b a4 24 80 02 00 	mov    0x280(%rsp),%r12
   8450f:	00 
   84510:	48 89 df             	mov    %rbx,%rdi
   84513:	4c 89 e6             	mov    %r12,%rsi
   84516:	e8 25 c8 01 00       	call   a0d40 <oriole::names::invalid_xml_char>
   8451b:	48 83 f8 01          	cmp    $0x1,%rax
   8451f:	75 68                	jne    84589 <<oriole::Parser>::next_event_inner+0x2ff9>
   84521:	49 89 d1             	mov    %rdx,%r9
   84524:	41 b8 1c 00 00 00    	mov    $0x1c,%r8d
   8452a:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84531:	00 
   84532:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   84537:	ba 03 00 00 00       	mov    $0x3,%edx
   8453c:	48 8d 0d 79 d7 f8 ff 	lea    -0x72887(%rip),%rcx        # 11cbc <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5320>
   84543:	e8 c8 c9 00 00       	call   90f10 <<oriole::Parser>::err_at>
   84548:	eb 62                	jmp    845ac <<oriole::Parser>::next_event_inner+0x301c>
   8454a:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   8454f:	66 0f ef c0          	pxor   %xmm0,%xmm0
   84553:	66 0f 7f 40 10       	movdqa %xmm0,0x10(%rax)
   84558:	48 8d 05 4d cf f8 ff 	lea    -0x730b3(%rip),%rax        # 114ac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   8455f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   84564:	48 c7 44 24 28 0d 00 	movq   $0xd,0x28(%rsp)
   8456b:	00 00 
   8456d:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   84574:	00 00 
   84576:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
   8457d:	00 00 
   8457f:	c6 44 24 50 00       	movb   $0x0,0x50(%rsp)
   84584:	e9 af 01 00 00       	jmp    84738 <<oriole::Parser>::next_event_inner+0x31a8>
   84589:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84590:	00 
   84591:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   84596:	4c 89 fa             	mov    %r15,%rdx
   84599:	e8 d2 14 00 00       	call   85a70 <<oriole::Parser>::save_current_raw>
   8459e:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   845a5:	ff 
   845a6:	0f 84 d3 01 00 00    	je     8477f <<oriole::Parser>::next_event_inner+0x31ef>
   845ac:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   845b3:	00 
   845b4:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   845b9:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   845c0:	00 00 
   845c2:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   845c9:	00 00 
   845cb:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   845d2:	00 00 
   845d4:	66 0f 7f 54 24 40    	movdqa %xmm2,0x40(%rsp)
   845da:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   845e0:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   845e6:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   845ed:	00 
   845ee:	e8 bd 53 fc ff       	call   499b0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   845f3:	e9 40 01 00 00       	jmp    84738 <<oriole::Parser>::next_event_inner+0x31a8>
   845f8:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
   845fc:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   84603:	48 8b 58 a8          	mov    -0x58(%rax),%rbx
   84607:	f3 0f 6f 40 d8       	movdqu -0x28(%rax),%xmm0
   8460c:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
   84612:	ba 01 00 00 00       	mov    $0x1,%edx
   84617:	31 f6                	xor    %esi,%esi
   84619:	e8 12 b2 fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   8461e:	48 8b 8c 24 c0 02 00 	mov    0x2c0(%rsp),%rcx
   84625:	00 
   84626:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   8462d:	00 
   8462e:	48 89 8a a0 00 00 00 	mov    %rcx,0xa0(%rdx)
   84635:	0f 10 84 24 b0 02 00 	movups 0x2b0(%rsp),%xmm0
   8463c:	00 
   8463d:	0f 11 82 90 00 00 00 	movups %xmm0,0x90(%rdx)
   84644:	0f 10 84 24 a0 02 00 	movups 0x2a0(%rsp),%xmm0
   8464b:	00 
   8464c:	0f 11 82 80 00 00 00 	movups %xmm0,0x80(%rdx)
   84653:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   8465a:	00 
   8465b:	0f 11 42 70          	movups %xmm0,0x70(%rdx)
   8465f:	0f 10 84 24 50 02 00 	movups 0x250(%rsp),%xmm0
   84666:	00 
   84667:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   8466e:	00 00 
   84670:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   84677:	00 00 
   84679:	0f 10 9c 24 80 02 00 	movups 0x280(%rsp),%xmm3
   84680:	00 
   84681:	0f 11 5a 60          	movups %xmm3,0x60(%rdx)
   84685:	f3 0f 7f 52 50       	movdqu %xmm2,0x50(%rdx)
   8468a:	f3 0f 7f 4a 40       	movdqu %xmm1,0x40(%rdx)
   8468f:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
   84693:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
   8469a:	00 
   8469b:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   846a1:	f3 0f 7f 84 24 38 01 	movdqu %xmm0,0x138(%rsp)
   846a8:	00 00 
   846aa:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
   846b1:	00 
   846b2:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   846b9:	00 ff ff ff ff 
   846be:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   846c5:	00 
   846c6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
   846cd:	00 
   846ce:	e8 cd 2d fd ff       	call   574a0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   846d3:	3c ff                	cmp    $0xff,%al
   846d5:	74 7f                	je     84756 <<oriole::Parser>::next_event_inner+0x31c6>
   846d7:	48 8d 05 ce cd f8 ff 	lea    -0x73232(%rip),%rax        # 114ac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   846de:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   846e3:	48 c7 44 24 28 0d 00 	movq   $0xd,0x28(%rsp)
   846ea:	00 00 
   846ec:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   846f3:	00 00 
   846f5:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
   846fc:	00 00 
   846fe:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   84703:	66 0f ef c0          	pxor   %xmm0,%xmm0
   84707:	66 0f 7f 40 10       	movdqa %xmm0,0x10(%rax)
   8470c:	c6 40 20 00          	movb   $0x0,0x20(%rax)
   84710:	48 8b 8c 24 88 03 00 	mov    0x388(%rsp),%rcx
   84717:	00 
   84718:	48 85 c9             	test   %rcx,%rcx
   8471b:	74 1b                	je     84738 <<oriole::Parser>::next_event_inner+0x31a8>
   8471d:	48 8b b4 24 80 03 00 	mov    0x380(%rsp),%rsi
   84724:	00 
   84725:	ba 01 00 00 00       	mov    $0x1,%edx
   8472a:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
   84731:	00 
   84732:	ff 15 78 21 06 00    	call   *0x62178(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   84738:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   8473d:	4d 8d ae 28 05 00 00 	lea    0x528(%r14),%r13
   84744:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   84749:	3c ff                	cmp    $0xff,%al
   8474b:	0f 84 1a ee ff ff    	je     8356b <<oriole::Parser>::next_event_inner+0x1fdb>
   84751:	e9 5e 06 00 00       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   84756:	48 8b ac 24 80 03 00 	mov    0x380(%rsp),%rbp
   8475d:	00 
   8475e:	4c 8b ac 24 90 03 00 	mov    0x390(%rsp),%r13
   84765:	00 
   84766:	49 83 fd 01          	cmp    $0x1,%r13
   8476a:	0f 86 b4 00 00 00    	jbe    84824 <<oriole::Parser>::next_event_inner+0x3294>
   84770:	80 7d 01 c0          	cmpb   $0xc0,0x1(%rbp)
   84774:	0f 8d b0 00 00 00    	jge    8482a <<oriole::Parser>::next_event_inner+0x329a>
   8477a:	e9 f6 0f 00 00       	jmp    85775 <<oriole::Parser>::next_event_inner+0x41e5>
   8477f:	48 8b 84 24 a8 02 00 	mov    0x2a8(%rsp),%rax
   84786:	00 
   84787:	48 8b 8c 24 b8 02 00 	mov    0x2b8(%rsp),%rcx
   8478e:	00 
   8478f:	48 89 9c 24 60 03 00 	mov    %rbx,0x360(%rsp)
   84796:	00 
   84797:	4c 89 a4 24 68 03 00 	mov    %r12,0x368(%rsp)
   8479e:	00 
   8479f:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   847a6:	00 
   847a7:	48 89 8c 24 78 03 00 	mov    %rcx,0x378(%rsp)
   847ae:	00 
   847af:	48 c7 84 24 80 03 00 	movq   $0x0,0x380(%rsp)
   847b6:	00 00 00 00 00 
   847bb:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   847c2:	00 ff ff ff ff 
   847c7:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
   847ce:	00 
   847cf:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   847d4:	48 8d 94 24 60 03 00 	lea    0x360(%rsp),%rdx
   847db:	00 
   847dc:	48 8d 8c 24 80 00 00 	lea    0x80(%rsp),%rcx
   847e3:	00 
   847e4:	e8 97 35 fe ff       	call   67d80 <<oriole::Parser>::parse_subset_expanded>
   847e9:	80 bc 24 40 04 00 00 	cmpb   $0xff,0x440(%rsp)
   847f0:	ff 
   847f1:	0f 84 67 02 00 00    	je     84a5e <<oriole::Parser>::next_event_inner+0x34ce>
   847f7:	48 8b 84 24 40 04 00 	mov    0x440(%rsp),%rax
   847fe:	00 
   847ff:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   84804:	f3 0f 6f 84 24 10 04 	movdqu 0x410(%rsp),%xmm0
   8480b:	00 00 
   8480d:	f3 0f 6f 8c 24 20 04 	movdqu 0x420(%rsp),%xmm1
   84814:	00 00 
   84816:	f3 0f 6f 94 24 30 04 	movdqu 0x430(%rsp),%xmm2
   8481d:	00 00 
   8481f:	e9 b0 fd ff ff       	jmp    845d4 <<oriole::Parser>::next_event_inner+0x3044>
   84824:	0f 85 4b 0f 00 00    	jne    85775 <<oriole::Parser>::next_event_inner+0x41e5>
   8482a:	b9 01 00 00 00       	mov    $0x1,%ecx
   8482f:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84836:	00 
   84837:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   8483c:	48 89 ea             	mov    %rbp,%rdx
   8483f:	e8 0c eb 00 00       	call   93350 <<oriole::Parser>::event_raw>
   84844:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   8484b:	ff 
   8484c:	0f 85 15 fb ff ff    	jne    84367 <<oriole::Parser>::next_event_inner+0x2dd7>
   84852:	49 83 ff 02          	cmp    $0x2,%r15
   84856:	0f 86 97 01 00 00    	jbe    849f3 <<oriole::Parser>::next_event_inner+0x3463>
   8485c:	48 c7 84 24 10 04 00 	movq   $0x14,0x410(%rsp)
   84863:	00 14 00 00 00 
   84868:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   8486d:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   84874:	48 85 c0             	test   %rax,%rax
   84877:	0f 84 15 0f 00 00    	je     85792 <<oriole::Parser>::next_event_inner+0x4202>
   8487d:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   84882:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   84889:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   8488d:	48 c1 e0 07          	shl    $0x7,%rax
   84891:	48 8d 34 01          	lea    (%rcx,%rax,1),%rsi
   84895:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
   8489c:	ba 01 00 00 00       	mov    $0x1,%edx
   848a1:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
   848a8:	00 
   848a9:	4c 89 e1             	mov    %r12,%rcx
   848ac:	e8 4f 9d fe ff       	call   6e600 <<oriole::encoding::Source>::position_at>
   848b1:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
   848b8:	00 
   848b9:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
   848c0:	00 
   848c1:	0f 10 84 24 70 04 00 	movups 0x470(%rsp),%xmm0
   848c8:	00 
   848c9:	0f 29 84 24 b0 02 00 	movaps %xmm0,0x2b0(%rsp)
   848d0:	00 
   848d1:	0f 10 84 24 60 04 00 	movups 0x460(%rsp),%xmm0
   848d8:	00 
   848d9:	0f 29 84 24 a0 02 00 	movaps %xmm0,0x2a0(%rsp)
   848e0:	00 
   848e1:	0f 10 84 24 50 04 00 	movups 0x450(%rsp),%xmm0
   848e8:	00 
   848e9:	0f 29 84 24 90 02 00 	movaps %xmm0,0x290(%rsp)
   848f0:	00 
   848f1:	0f 10 84 24 10 04 00 	movups 0x410(%rsp),%xmm0
   848f8:	00 
   848f9:	0f 10 8c 24 20 04 00 	movups 0x420(%rsp),%xmm1
   84900:	00 
   84901:	f3 0f 6f 94 24 30 04 	movdqu 0x430(%rsp),%xmm2
   84908:	00 00 
   8490a:	0f 10 9c 24 40 04 00 	movups 0x440(%rsp),%xmm3
   84911:	00 
   84912:	0f 29 9c 24 80 02 00 	movaps %xmm3,0x280(%rsp)
   84919:	00 
   8491a:	66 0f 7f 94 24 70 02 	movdqa %xmm2,0x270(%rsp)
   84921:	00 00 
   84923:	0f 29 8c 24 60 02 00 	movaps %xmm1,0x260(%rsp)
   8492a:	00 
   8492b:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
   84932:	00 
   84933:	f3 0f 6f 84 24 30 03 	movdqu 0x330(%rsp),%xmm0
   8493a:	00 00 
   8493c:	f3 0f 6f 8c 24 40 03 	movdqu 0x340(%rsp),%xmm1
   84943:	00 00 
   84945:	48 8d 84 24 58 02 00 	lea    0x258(%rsp),%rax
   8494c:	00 
   8494d:	f3 0f 7f 88 80 00 00 	movdqu %xmm1,0x80(%rax)
   84954:	00 
   84955:	f3 0f 7f 40 70       	movdqu %xmm0,0x70(%rax)
   8495a:	ba 98 00 00 00       	mov    $0x98,%edx
   8495f:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   84966:	00 
   84967:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
   8496e:	00 
   8496f:	ff 15 23 28 06 00    	call   *0x62823(%rip)        # e7198 <memcpy@GLIBC_2.14>
   84975:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   8497c:	00 ff ff ff ff 
   84981:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   84988:	00 
   84989:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
   84990:	00 
   84991:	e8 0a 2b fd ff       	call   574a0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   84996:	3c ff                	cmp    $0xff,%al
   84998:	0f 85 39 fd ff ff    	jne    846d7 <<oriole::Parser>::next_event_inner+0x3147>
   8499e:	ba 01 00 00 00       	mov    $0x1,%edx
   849a3:	49 83 fd 02          	cmp    $0x2,%r13
   849a7:	0f 82 a2 0d 00 00    	jb     8574f <<oriole::Parser>::next_event_inner+0x41bf>
   849ad:	49 8d 4d ff          	lea    -0x1(%r13),%rcx
   849b1:	80 7d 01 c0          	cmpb   $0xc0,0x1(%rbp)
   849b5:	0f 8c 96 0d 00 00    	jl     85751 <<oriole::Parser>::next_event_inner+0x41c1>
   849bb:	80 7c 0d 00 bf       	cmpb   $0xbf,0x0(%rbp,%rcx,1)
   849c0:	0f 8e 8b 0d 00 00    	jle    85751 <<oriole::Parser>::next_event_inner+0x41c1>
   849c6:	48 ff c5             	inc    %rbp
   849c9:	49 83 c5 fe          	add    $0xfffffffffffffffe,%r13
   849cd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   849d4:	00 
   849d5:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   849da:	48 89 ea             	mov    %rbp,%rdx
   849dd:	4c 89 e9             	mov    %r13,%rcx
   849e0:	e8 6b e9 00 00       	call   93350 <<oriole::Parser>::event_raw>
   849e5:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   849ec:	ff 
   849ed:	0f 85 74 f9 ff ff    	jne    84367 <<oriole::Parser>::next_event_inner+0x2dd7>
   849f3:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   849fa:	00 
   849fb:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   84a00:	48 8d 94 24 f0 03 00 	lea    0x3f0(%rsp),%rdx
   84a07:	00 
   84a08:	e8 73 cc fd ff       	call   61680 <<oriole::Parser>::finish_doctype>
   84a0d:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84a14:	ff 
   84a15:	0f 85 4c f9 ff ff    	jne    84367 <<oriole::Parser>::next_event_inner+0x2dd7>
   84a1b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84a22:	00 
   84a23:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   84a28:	4c 89 fa             	mov    %r15,%rdx
   84a2b:	e8 60 c5 00 00       	call   90f90 <<oriole::Parser>::consume>
   84a30:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84a37:	ff 
   84a38:	0f 85 29 f9 ff ff    	jne    84367 <<oriole::Parser>::next_event_inner+0x2dd7>
   84a3e:	c6 44 24 20 01       	movb   $0x1,0x20(%rsp)
   84a43:	c6 44 24 50 ff       	movb   $0xff,0x50(%rsp)
   84a48:	48 8b 8c 24 88 03 00 	mov    0x388(%rsp),%rcx
   84a4f:	00 
   84a50:	48 85 c9             	test   %rcx,%rcx
   84a53:	0f 85 c4 fc ff ff    	jne    8471d <<oriole::Parser>::next_event_inner+0x318d>
   84a59:	e9 da fc ff ff       	jmp    84738 <<oriole::Parser>::next_event_inner+0x31a8>
   84a5e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84a65:	00 
   84a66:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   84a6b:	4c 89 fa             	mov    %r15,%rdx
   84a6e:	e8 1d c5 00 00       	call   90f90 <<oriole::Parser>::consume>
   84a73:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84a7a:	ff 
   84a7b:	0f 85 2b fb ff ff    	jne    845ac <<oriole::Parser>::next_event_inner+0x301c>
   84a81:	c6 44 24 20 01       	movb   $0x1,0x20(%rsp)
   84a86:	c6 44 24 50 ff       	movb   $0xff,0x50(%rsp)
   84a8b:	e9 56 fb ff ff       	jmp    845e6 <<oriole::Parser>::next_event_inner+0x3056>
   84a90:	0f 10 84 24 81 00 00 	movups 0x81(%rsp),%xmm0
   84a97:	00 
   84a98:	0f 10 8c 24 91 00 00 	movups 0x91(%rsp),%xmm1
   84a9f:	00 
   84aa0:	0f 10 94 24 a0 00 00 	movups 0xa0(%rsp),%xmm2
   84aa7:	00 
   84aa8:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   84aad:	0f 11 57 20          	movups %xmm2,0x20(%rdi)
   84ab1:	0f 11 4f 11          	movups %xmm1,0x11(%rdi)
   84ab5:	0f 11 47 01          	movups %xmm0,0x1(%rdi)
   84ab9:	8b 94 24 b1 00 00 00 	mov    0xb1(%rsp),%edx
   84ac0:	8b b4 24 b4 00 00 00 	mov    0xb4(%rsp),%esi
   84ac7:	89 57 31             	mov    %edx,0x31(%rdi)
   84aca:	89 77 34             	mov    %esi,0x34(%rdi)
   84acd:	88 07                	mov    %al,(%rdi)
   84acf:	88 4f 30             	mov    %cl,0x30(%rdi)
   84ad2:	eb 3c                	jmp    84b10 <<oriole::Parser>::next_event_inner+0x3580>
   84ad4:	4c 8b b4 24 30 05 00 	mov    0x530(%rsp),%r14
   84adb:	00 
   84adc:	41 83 3e ff          	cmpl   $0xffffffff,(%r14)
   84ae0:	74 08                	je     84aea <<oriole::Parser>::next_event_inner+0x355a>
   84ae2:	4c 89 f7             	mov    %r14,%rdi
   84ae5:	e8 66 43 fc ff       	call   48e50 <core::ptr::drop_glue::<oriole::EventKind>>
   84aea:	4d 89 3e             	mov    %r15,(%r14)
   84aed:	49 83 c6 08          	add    $0x8,%r14
   84af1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
   84af8:	00 
   84af9:	ba 90 00 00 00       	mov    $0x90,%edx
   84afe:	4c 89 f7             	mov    %r14,%rdi
   84b01:	ff 15 91 26 06 00    	call   *0x62691(%rip)        # e7198 <memcpy@GLIBC_2.14>
   84b07:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   84b0c:	c6 40 30 ff          	movb   $0xff,0x30(%rax)
   84b10:	48 81 c4 78 05 00 00 	add    $0x578,%rsp
   84b17:	5b                   	pop    %rbx
   84b18:	41 5c                	pop    %r12
   84b1a:	41 5d                	pop    %r13
   84b1c:	41 5e                	pop    %r14
   84b1e:	41 5f                	pop    %r15
   84b20:	5d                   	pop    %rbp
   84b21:	c3                   	ret
   84b22:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84b29:	00 
   84b2a:	ba 01 00 00 00       	mov    $0x1,%edx
   84b2f:	4c 89 f6             	mov    %r14,%rsi
   84b32:	31 c9                	xor    %ecx,%ecx
   84b34:	e8 17 e8 00 00       	call   93350 <<oriole::Parser>::event_raw>
   84b39:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84b40:	ff 
   84b41:	0f 84 7a cc ff ff    	je     817c1 <<oriole::Parser>::next_event_inner+0x231>
   84b47:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   84b4e:	00 
   84b4f:	49 89 47 30          	mov    %rax,0x30(%r15)
   84b53:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   84b5a:	00 00 
   84b5c:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   84b63:	00 00 
   84b65:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   84b6c:	00 00 
   84b6e:	f3 41 0f 7f 57 20    	movdqu %xmm2,0x20(%r15)
   84b74:	f3 41 0f 7f 4f 10    	movdqu %xmm1,0x10(%r15)
   84b7a:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
   84b7f:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   84b86:	00 
   84b87:	e8 54 16 fc ff       	call   461e0 <core::ptr::drop_glue::<core::option::Option<(oriole_storage::string::String, oriole::Position)>>>
   84b8c:	eb 82                	jmp    84b10 <<oriole::Parser>::next_event_inner+0x3580>
   84b8e:	41 0f b6 9e f8 07 00 	movzbl 0x7f8(%r14),%ebx
   84b95:	00 
   84b96:	80 fb ff             	cmp    $0xff,%bl
   84b99:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   84b9e:	0f 84 e5 00 00 00    	je     84c89 <<oriole::Parser>::next_event_inner+0x36f9>
   84ba4:	49 8b 8e 00 08 00 00 	mov    0x800(%r14),%rcx
   84bab:	4d 8b 86 08 08 00 00 	mov    0x808(%r14),%r8
   84bb2:	0f b6 d3             	movzbl %bl,%edx
   84bb5:	48 8d bc 24 40 05 00 	lea    0x540(%rsp),%rdi
   84bbc:	00 
   84bbd:	4c 89 f6             	mov    %r14,%rsi
   84bc0:	e8 eb b8 00 00       	call   904b0 <<oriole::Parser>::err>
   84bc5:	80 c3 ef             	add    $0xef,%bl
   84bc8:	80 fb 01             	cmp    $0x1,%bl
   84bcb:	77 24                	ja     84bf1 <<oriole::Parser>::next_event_inner+0x3661>
   84bcd:	41 f6 06 01          	testb  $0x1,(%r14)
   84bd1:	74 1e                	je     84bf1 <<oriole::Parser>::next_event_inner+0x3661>
   84bd3:	f3 41 0f 6f 46 08    	movdqu 0x8(%r14),%xmm0
   84bd9:	f3 41 0f 6f 4e 18    	movdqu 0x18(%r14),%xmm1
   84bdf:	f3 0f 7f 8c 24 60 05 	movdqu %xmm1,0x560(%rsp)
   84be6:	00 00 
   84be8:	f3 0f 7f 84 24 50 05 	movdqu %xmm0,0x550(%rsp)
   84bef:	00 00 
   84bf1:	48 8b 84 24 70 05 00 	mov    0x570(%rsp),%rax
   84bf8:	00 
   84bf9:	49 89 47 30          	mov    %rax,0x30(%r15)
   84bfd:	f3 0f 6f 84 24 40 05 	movdqu 0x540(%rsp),%xmm0
   84c04:	00 00 
   84c06:	f3 0f 6f 8c 24 50 05 	movdqu 0x550(%rsp),%xmm1
   84c0d:	00 00 
   84c0f:	f3 0f 6f 94 24 60 05 	movdqu 0x560(%rsp),%xmm2
   84c16:	00 00 
   84c18:	e9 cd c9 ff ff       	jmp    815ea <<oriole::Parser>::next_event_inner+0x5a>
   84c1d:	48 8d 0d 59 dc f8 ff 	lea    -0x723a7(%rip),%rcx        # 1287d <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5ee1>
   84c24:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   84c2b:	00 
   84c2c:	41 b8 22 00 00 00    	mov    $0x22,%r8d
   84c32:	4c 89 f6             	mov    %r14,%rsi
   84c35:	ba 0c 00 00 00       	mov    $0xc,%edx
   84c3a:	e8 71 b8 00 00       	call   904b0 <<oriole::Parser>::err>
   84c3f:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
   84c46:	00 
   84c47:	49 89 47 30          	mov    %rax,0x30(%r15)
   84c4b:	f3 0f 6f 84 24 50 02 	movdqu 0x250(%rsp),%xmm0
   84c52:	00 00 
   84c54:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   84c5b:	00 00 
   84c5d:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   84c64:	00 00 
   84c66:	f3 41 0f 7f 57 20    	movdqu %xmm2,0x20(%r15)
   84c6c:	f3 41 0f 7f 4f 10    	movdqu %xmm1,0x10(%r15)
   84c72:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
   84c77:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84c7e:	00 
   84c7f:	e8 bc 4d fc ff       	call   49a40 <core::ptr::drop_glue::<oriole::encoding::Source>>
   84c84:	e9 87 fe ff ff       	jmp    84b10 <<oriole::Parser>::next_event_inner+0x3580>
   84c89:	41 80 be b8 08 00 00 	cmpb   $0x1,0x8b8(%r14)
   84c90:	01 
   84c91:	0f 85 b4 06 00 00    	jne    8534b <<oriole::Parser>::next_event_inner+0x3dbb>
   84c97:	41 f6 86 28 01 00 00 	testb  $0x1,0x128(%r14)
   84c9e:	01 
   84c9f:	0f 85 a6 06 00 00    	jne    8534b <<oriole::Parser>::next_event_inner+0x3dbb>
   84ca5:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84cac:	00 
   84cad:	4c 89 f6             	mov    %r14,%rsi
   84cb0:	e8 3b eb 00 00       	call   937f0 <<oriole::Parser>::finish_conditional_source>
   84cb5:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84cbc:	ff 
   84cbd:	0f 85 00 c9 ff ff    	jne    815c3 <<oriole::Parser>::next_event_inner+0x33>
   84cc3:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84cca:	00 
   84ccb:	4c 89 f6             	mov    %r14,%rsi
   84cce:	e8 9d c1 00 00       	call   90e70 <<oriole::Parser>::here>
   84cd3:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   84cda:	00 00 
   84cdc:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   84ce3:	00 00 
   84ce5:	f3 41 0f 7f 8e a0 08 	movdqu %xmm1,0x8a0(%r14)
   84cec:	00 00 
   84cee:	f3 41 0f 7f 86 90 08 	movdqu %xmm0,0x890(%r14)
   84cf5:	00 00 
   84cf7:	41 80 be b1 08 00 00 	cmpb   $0x0,0x8b1(%r14)
   84cfe:	00 
   84cff:	0f 84 f7 03 00 00    	je     850fc <<oriole::Parser>::next_event_inner+0x3b6c>
   84d05:	48 8d 0d 65 d0 f8 ff 	lea    -0x72f9b(%rip),%rcx        # 11d71 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x53d5>
   84d0c:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84d13:	00 
   84d14:	41 b8 22 00 00 00    	mov    $0x22,%r8d
   84d1a:	4c 89 f6             	mov    %r14,%rsi
   84d1d:	ba 02 00 00 00       	mov    $0x2,%edx
   84d22:	e8 89 b7 00 00       	call   904b0 <<oriole::Parser>::err>
   84d27:	e9 97 c8 ff ff       	jmp    815c3 <<oriole::Parser>::next_event_inner+0x33>
   84d2c:	4c 8d 05 95 f3 05 00 	lea    0x5f395(%rip),%r8        # e40c8 <oriole_expat::FEATURES+0x14e0>
   84d33:	48 89 c7             	mov    %rax,%rdi
   84d36:	48 89 d6             	mov    %rdx,%rsi
   84d39:	31 d2                	xor    %edx,%edx
   84d3b:	4c 89 f9             	mov    %r15,%rcx
   84d3e:	ff 15 74 21 06 00    	call   *0x62174(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   84d44:	e9 62 0a 00 00       	jmp    857ab <<oriole::Parser>::next_event_inner+0x421b>
   84d49:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   84d4e:	83 3f 01             	cmpl   $0x1,(%rdi)
   84d51:	75 1b                	jne    84d6e <<oriole::Parser>::next_event_inner+0x37de>
   84d53:	48 89 d8             	mov    %rbx,%rax
   84d56:	48 8b 9b 88 fe ff ff 	mov    -0x178(%rbx),%rbx
   84d5d:	f3 0f 6f 80 90 fe ff 	movdqu -0x170(%rax),%xmm0
   84d64:	ff 
   84d65:	48 8b 80 a0 fe ff ff 	mov    -0x160(%rax),%rax
   84d6c:	eb 1f                	jmp    84d8d <<oriole::Parser>::next_event_inner+0x37fd>
   84d6e:	48 89 d8             	mov    %rbx,%rax
   84d71:	48 8b 5b a8          	mov    -0x58(%rbx),%rbx
   84d75:	0f 10 40 d8          	movups -0x28(%rax),%xmm0
   84d79:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   84d7e:	31 f6                	xor    %esi,%esi
   84d80:	31 d2                	xor    %edx,%edx
   84d82:	e8 a9 aa fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   84d87:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
   84d8d:	48 8d 0d 93 da f8 ff 	lea    -0x7256d(%rip),%rcx        # 12827 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5e8b>
   84d94:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   84d99:	48 c7 44 24 28 24 00 	movq   $0x24,0x28(%rsp)
   84da0:	00 00 
   84da2:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   84da7:	f3 0f 7f 44 24 38    	movdqu %xmm0,0x38(%rsp)
   84dad:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   84db2:	b0 1e                	mov    $0x1e,%al
   84db4:	0f b6 4c 24 20       	movzbl 0x20(%rsp),%ecx
   84db9:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   84dbe:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   84dc3:	48 89 57 20          	mov    %rdx,0x20(%rdi)
   84dc7:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   84dcc:	48 89 57 28          	mov    %rdx,0x28(%rdi)
   84dd0:	8b 54 24 31          	mov    0x31(%rsp),%edx
   84dd4:	89 57 11             	mov    %edx,0x11(%rdi)
   84dd7:	0f b7 54 24 35       	movzwl 0x35(%rsp),%edx
   84ddc:	66 89 57 15          	mov    %dx,0x15(%rdi)
   84de0:	0f b6 54 24 37       	movzbl 0x37(%rsp),%edx
   84de5:	88 57 17             	mov    %dl,0x17(%rdi)
   84de8:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   84ded:	48 89 57 18          	mov    %rdx,0x18(%rdi)
   84df1:	0f b6 54 24 40       	movzbl 0x40(%rsp),%edx
   84df6:	88 57 20             	mov    %dl,0x20(%rdi)
   84df9:	0f 10 44 24 21       	movups 0x21(%rsp),%xmm0
   84dfe:	0f 11 47 01          	movups %xmm0,0x1(%rdi)
   84e02:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   84e07:	8b 56 21             	mov    0x21(%rsi),%edx
   84e0a:	8b 76 24             	mov    0x24(%rsi),%esi
   84e0d:	89 57 31             	mov    %edx,0x31(%rdi)
   84e10:	89 77 34             	mov    %esi,0x34(%rdi)
   84e13:	88 0f                	mov    %cl,(%rdi)
   84e15:	88 47 30             	mov    %al,0x30(%rdi)
   84e18:	e9 f3 fc ff ff       	jmp    84b10 <<oriole::Parser>::next_event_inner+0x3580>
   84e1d:	48 8b 9c 24 80 00 00 	mov    0x80(%rsp),%rbx
   84e24:	00 
   84e25:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
   84e2c:	00 
   84e2d:	f3 0f 6f 84 24 90 00 	movdqu 0x90(%rsp),%xmm0
   84e34:	00 00 
   84e36:	66 0f 7f 84 24 e0 04 	movdqa %xmm0,0x4e0(%rsp)
   84e3d:	00 00 
   84e3f:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   84e46:	00 00 
   84e48:	8b 84 24 b1 00 00 00 	mov    0xb1(%rsp),%eax
   84e4f:	89 84 24 60 03 00 00 	mov    %eax,0x360(%rsp)
   84e56:	8b 84 24 b4 00 00 00 	mov    0xb4(%rsp),%eax
   84e5d:	89 84 24 63 03 00 00 	mov    %eax,0x363(%rsp)
   84e64:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
   84e68:	66 0f 6f 8c 24 50 03 	movdqa 0x350(%rsp),%xmm1
   84e6f:	00 00 
   84e71:	0f 84 a8 01 00 00    	je     8501f <<oriole::Parser>::next_event_inner+0x3a8f>
   84e77:	66 0f 70 c1 ee       	pshufd $0xee,%xmm1,%xmm0
   84e7c:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   84e81:	48 85 c9             	test   %rcx,%rcx
   84e84:	0f 84 95 01 00 00    	je     8501f <<oriole::Parser>::next_event_inner+0x3a8f>
   84e8a:	66 48 0f 7e ce       	movq   %xmm1,%rsi
   84e8f:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   84e96:	00 
   84e97:	ba 01 00 00 00       	mov    $0x1,%edx
   84e9c:	66 0f 7f 54 24 10    	movdqa %xmm2,0x10(%rsp)
   84ea2:	ff 15 08 1a 06 00    	call   *0x61a08(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   84ea8:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
   84eae:	e9 6c 01 00 00       	jmp    8501f <<oriole::Parser>::next_event_inner+0x3a8f>
   84eb3:	66 0f ef c0          	pxor   %xmm0,%xmm0
   84eb7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   84ebc:	f3 0f 7f 41 20       	movdqu %xmm0,0x20(%rcx)
   84ec1:	48 8d 05 e4 c5 f8 ff 	lea    -0x73a1c(%rip),%rax        # 114ac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   84ec8:	48 89 01             	mov    %rax,(%rcx)
   84ecb:	48 c7 41 08 0d 00 00 	movq   $0xd,0x8(%rcx)
   84ed2:	00 
   84ed3:	48 c7 41 10 00 00 00 	movq   $0x0,0x10(%rcx)
   84eda:	00 
   84edb:	48 c7 41 18 01 00 00 	movq   $0x1,0x18(%rcx)
   84ee2:	00 
   84ee3:	c6 41 30 00          	movb   $0x0,0x30(%rcx)
   84ee7:	e9 82 01 00 00       	jmp    8506e <<oriole::Parser>::next_event_inner+0x3ade>
   84eec:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
   84ef3:	00 
   84ef4:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
   84efb:	00 
   84efc:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   84f03:	00 00 
   84f05:	f3 0f 6f 84 24 a0 00 	movdqu 0xa0(%rsp),%xmm0
   84f0c:	00 00 
   84f0e:	8b 84 24 b1 00 00 00 	mov    0xb1(%rsp),%eax
   84f15:	89 84 24 60 03 00 00 	mov    %eax,0x360(%rsp)
   84f1c:	8b 84 24 b4 00 00 00 	mov    0xb4(%rsp),%eax
   84f23:	89 84 24 63 03 00 00 	mov    %eax,0x363(%rsp)
   84f2a:	e9 38 03 00 00       	jmp    85267 <<oriole::Parser>::next_event_inner+0x3cd7>
   84f2f:	48 8d 0d 69 d9 f8 ff 	lea    -0x72697(%rip),%rcx        # 1289f <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f03>
   84f36:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84f3d:	00 
   84f3e:	41 b8 2d 00 00 00    	mov    $0x2d,%r8d
   84f44:	4c 89 f6             	mov    %r14,%rsi
   84f47:	ba 03 00 00 00       	mov    $0x3,%edx
   84f4c:	e9 58 02 00 00       	jmp    851a9 <<oriole::Parser>::next_event_inner+0x3c19>
   84f51:	8b 8c 24 58 02 00 00 	mov    0x258(%rsp),%ecx
   84f58:	49 8b b6 80 01 00 00 	mov    0x180(%r14),%rsi
   84f5f:	49 8b 96 90 01 00 00 	mov    0x190(%r14),%rdx
   84f66:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84f6d:	00 
   84f6e:	4d 89 f8             	mov    %r15,%r8
   84f71:	e8 ca 81 fc ff       	call   4d140 <<oriole::Parser>::next_event_inner::{closure#3}>
   84f76:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
   84f7d:	00 
   84f7e:	0f 28 8c 24 a0 00 00 	movaps 0xa0(%rsp),%xmm1
   84f85:	00 
   84f86:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   84f8b:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
   84f8f:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
   84f93:	0f b6 84 24 b0 00 00 	movzbl 0xb0(%rsp),%eax
   84f9a:	00 
   84f9b:	8b 8c 24 b1 00 00 00 	mov    0xb1(%rsp),%ecx
   84fa2:	89 4a 31             	mov    %ecx,0x31(%rdx)
   84fa5:	8b 8c 24 b4 00 00 00 	mov    0xb4(%rsp),%ecx
   84fac:	89 4a 34             	mov    %ecx,0x34(%rdx)
   84faf:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
   84fb6:	00 
   84fb7:	0f 11 02             	movups %xmm0,(%rdx)
   84fba:	88 42 30             	mov    %al,0x30(%rdx)
   84fbd:	e9 4e fb ff ff       	jmp    84b10 <<oriole::Parser>::next_event_inner+0x3580>
   84fc2:	49 83 be 90 01 00 00 	cmpq   $0x1,0x190(%r14)
   84fc9:	01 
   84fca:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   84fcf:	0f 85 4b 03 00 00    	jne    85320 <<oriole::Parser>::next_event_inner+0x3d90>
   84fd5:	49 8b be 80 01 00 00 	mov    0x180(%r14),%rdi
   84fdc:	83 3f 01             	cmpl   $0x1,(%rdi)
   84fdf:	0f 85 df 02 00 00    	jne    852c4 <<oriole::Parser>::next_event_inner+0x3d34>
   84fe5:	4c 8b 7f 08          	mov    0x8(%rdi),%r15
   84fe9:	e9 e6 02 00 00       	jmp    852d4 <<oriole::Parser>::next_event_inner+0x3d44>
   84fee:	83 3f 01             	cmpl   $0x1,(%rdi)
   84ff1:	0f 85 1c 02 00 00    	jne    85213 <<oriole::Parser>::next_event_inner+0x3c83>
   84ff7:	f3 0f 6f 8b 88 fe ff 	movdqu -0x178(%rbx),%xmm1
   84ffe:	ff 
   84fff:	f3 0f 6f 83 98 fe ff 	movdqu -0x168(%rbx),%xmm0
   85006:	ff 
   85007:	e9 4b 02 00 00       	jmp    85257 <<oriole::Parser>::next_event_inner+0x3cc7>
   8500c:	66 0f ef d2          	pxor   %xmm2,%xmm2
   85010:	41 bc 0d 00 00 00    	mov    $0xd,%r12d
   85016:	31 ed                	xor    %ebp,%ebp
   85018:	48 8d 1d 8d c4 f8 ff 	lea    -0x73b73(%rip),%rbx        # 114ac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   8501f:	49 89 dd             	mov    %rbx,%r13
   85022:	66 0f 6f 8c 24 e0 04 	movdqa 0x4e0(%rsp),%xmm1
   85029:	00 00 
   8502b:	66 0f 6f c2          	movdqa %xmm2,%xmm0
   8502f:	e9 33 02 00 00       	jmp    85267 <<oriole::Parser>::next_event_inner+0x3cd7>
   85034:	48 8b 84 24 40 04 00 	mov    0x440(%rsp),%rax
   8503b:	00 
   8503c:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   85041:	48 89 41 30          	mov    %rax,0x30(%rcx)
   85045:	f3 0f 6f 84 24 10 04 	movdqu 0x410(%rsp),%xmm0
   8504c:	00 00 
   8504e:	f3 0f 6f 8c 24 20 04 	movdqu 0x420(%rsp),%xmm1
   85055:	00 00 
   85057:	f3 0f 6f 94 24 30 04 	movdqu 0x430(%rsp),%xmm2
   8505e:	00 00 
   85060:	f3 0f 7f 51 20       	movdqu %xmm2,0x20(%rcx)
   85065:	f3 0f 7f 49 10       	movdqu %xmm1,0x10(%rcx)
   8506a:	f3 0f 7f 01          	movdqu %xmm0,(%rcx)
   8506e:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   85075:	00 
   85076:	e8 35 49 fc ff       	call   499b0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   8507b:	e9 90 fa ff ff       	jmp    84b10 <<oriole::Parser>::next_event_inner+0x3580>
   85080:	41 bc 0d 00 00 00    	mov    $0xd,%r12d
   85086:	31 ed                	xor    %ebp,%ebp
   85088:	4c 8d 2d 1d c4 f8 ff 	lea    -0x73be3(%rip),%r13        # 114ac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   8508f:	66 0f 6f 0d f9 36 f8 	movdqa -0x7c907(%rip),%xmm1        # 8790 <std::thread::current::id::ID+0x8720>
   85096:	ff 
   85097:	66 0f ef c0          	pxor   %xmm0,%xmm0
   8509b:	e9 c7 01 00 00       	jmp    85267 <<oriole::Parser>::next_event_inner+0x3cd7>
   850a0:	48 83 f9 01          	cmp    $0x1,%rcx
   850a4:	0f 84 d8 00 00 00    	je     85182 <<oriole::Parser>::next_event_inner+0x3bf2>
   850aa:	c6 84 24 30 03 00 00 	movb   $0x0,0x330(%rsp)
   850b1:	00 
   850b2:	ba 01 00 00 00       	mov    $0x1,%edx
   850b7:	4c 8d 05 f2 ef 05 00 	lea    0x5eff2(%rip),%r8        # e40b0 <oriole_expat::FEATURES+0x14c8>
   850be:	48 89 c7             	mov    %rax,%rdi
   850c1:	48 89 ce             	mov    %rcx,%rsi
   850c4:	ff 15 ee 1d 06 00    	call   *0x61dee(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   850ca:	41 80 be b4 08 00 00 	cmpb   $0x0,0x8b4(%r14)
   850d1:	00 
   850d2:	b8 08 00 00 00       	mov    $0x8,%eax
   850d7:	ba 01 00 00 00       	mov    $0x1,%edx
   850dc:	0f 45 d0             	cmovne %eax,%edx
   850df:	48 8d 0d e6 d7 f8 ff 	lea    -0x7281a(%rip),%rcx        # 128cc <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f30>
   850e6:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   850ed:	00 
   850ee:	41 b8 22 00 00 00    	mov    $0x22,%r8d
   850f4:	4c 89 f6             	mov    %r14,%rsi
   850f7:	e9 ad 00 00 00       	jmp    851a9 <<oriole::Parser>::next_event_inner+0x3c19>
   850fc:	41 80 be b7 08 00 00 	cmpb   $0x0,0x8b7(%r14)
   85103:	00 
   85104:	0f 84 4b 02 00 00    	je     85355 <<oriole::Parser>::next_event_inner+0x3dc5>
   8510a:	48 8d 0d 56 d7 f8 ff 	lea    -0x728aa(%rip),%rcx        # 12867 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5ecb>
   85111:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   85118:	00 
   85119:	41 b8 16 00 00 00    	mov    $0x16,%r8d
   8511f:	4c 89 f6             	mov    %r14,%rsi
   85122:	ba 13 00 00 00       	mov    $0x13,%edx
   85127:	e8 84 b3 00 00       	call   904b0 <<oriole::Parser>::err>
   8512c:	e9 92 c4 ff ff       	jmp    815c3 <<oriole::Parser>::next_event_inner+0x33>
   85131:	48 8d 3d a2 d2 f8 ff 	lea    -0x72d5e(%rip),%rdi        # 123da <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   85138:	48 8d 15 69 f1 05 00 	lea    0x5f169(%rip),%rdx        # e42a8 <oriole_expat::FEATURES+0x16c0>
   8513f:	be 21 00 00 00       	mov    $0x21,%esi
   85144:	ff 15 8e 1d 06 00    	call   *0x61d8e(%rip)        # e6ed8 <_GLOBAL_OFFSET_TABLE_+0x760>
   8514a:	48 8d 05 17 ef 05 00 	lea    0x5ef17(%rip),%rax        # e4068 <oriole_expat::FEATURES+0x1480>
   85151:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   85158:	00 
   85159:	48 8d 05 38 ef 05 00 	lea    0x5ef38(%rip),%rax        # e4098 <oriole_expat::FEATURES+0x14b0>
   85160:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   85167:	00 
   85168:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8516f:	00 
   85170:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
   85175:	e8 76 6f fc ff       	call   4c0f0 <<core::slice::iter::Iter<&str> as core::iter::traits::iterator::Iterator>::any::<<oriole::Parser>::next_event_inner::{closure#1}>>
   8517a:	84 c0                	test   %al,%al
   8517c:	0f 84 7a 02 00 00    	je     853fc <<oriole::Parser>::next_event_inner+0x3e6c>
   85182:	49 83 be 90 01 00 00 	cmpq   $0x1,0x190(%r14)
   85189:	01 
   8518a:	76 61                	jbe    851ed <<oriole::Parser>::next_event_inner+0x3c5d>
   8518c:	48 8d 0d 87 d7 f8 ff 	lea    -0x72879(%rip),%rcx        # 1291a <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f7e>
   85193:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8519a:	00 
   8519b:	41 b8 11 00 00 00    	mov    $0x11,%r8d
   851a1:	4c 89 f6             	mov    %r14,%rsi
   851a4:	ba 04 00 00 00       	mov    $0x4,%edx
   851a9:	e8 02 b3 00 00       	call   904b0 <<oriole::Parser>::err>
   851ae:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   851b5:	00 
   851b6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   851bb:	48 89 41 30          	mov    %rax,0x30(%rcx)
   851bf:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   851c6:	00 00 
   851c8:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   851cf:	00 00 
   851d1:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   851d8:	00 00 
   851da:	f3 0f 7f 51 20       	movdqu %xmm2,0x20(%rcx)
   851df:	f3 0f 7f 49 10       	movdqu %xmm1,0x10(%rcx)
   851e4:	f3 0f 7f 01          	movdqu %xmm0,(%rcx)
   851e8:	e9 23 f9 ff ff       	jmp    84b10 <<oriole::Parser>::next_event_inner+0x3580>
   851ed:	41 0f b6 86 28 01 00 	movzbl 0x128(%r14),%eax
   851f4:	00 
   851f5:	34 01                	xor    $0x1,%al
   851f7:	41 84 86 b8 08 00 00 	test   %al,0x8b8(%r14)
   851fe:	75 8c                	jne    8518c <<oriole::Parser>::next_event_inner+0x3bfc>
   85200:	41 80 be f8 07 00 00 	cmpb   $0xff,0x7f8(%r14)
   85207:	ff 
   85208:	0f 84 f9 f8 ff ff    	je     84b07 <<oriole::Parser>::next_event_inner+0x3577>
   8520e:	e9 79 ff ff ff       	jmp    8518c <<oriole::Parser>::next_event_inner+0x3bfc>
   85213:	f2 0f 10 43 d8       	movsd  -0x28(%rbx),%xmm0
   85218:	f2 0f 10 4b a8       	movsd  -0x58(%rbx),%xmm1
   8521d:	0f 16 c8             	movlhps %xmm0,%xmm1
   85220:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   85225:	f2 0f 10 43 e0       	movsd  -0x20(%rbx),%xmm0
   8522a:	0f 29 84 24 50 03 00 	movaps %xmm0,0x350(%rsp)
   85231:	00 
   85232:	31 f6                	xor    %esi,%esi
   85234:	31 d2                	xor    %edx,%edx
   85236:	e8 f5 a5 fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   8523b:	66 0f 6f 4c 24 10    	movdqa 0x10(%rsp),%xmm1
   85241:	66 48 0f 6e c0       	movq   %rax,%xmm0
   85246:	66 0f 6f 94 24 50 03 	movdqa 0x350(%rsp),%xmm2
   8524d:	00 00 
   8524f:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   85253:	66 0f 6f c2          	movdqa %xmm2,%xmm0
   85257:	4c 8d 2d d1 c1 f8 ff 	lea    -0x73e2f(%rip),%r13        # 1142f <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4a93>
   8525e:	40 b5 03             	mov    $0x3,%bpl
   85261:	41 bc 15 00 00 00    	mov    $0x15,%r12d
   85267:	8b 84 24 60 03 00 00 	mov    0x360(%rsp),%eax
   8526e:	8b 8c 24 63 03 00 00 	mov    0x363(%rsp),%ecx
   85275:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   8527a:	89 4a 34             	mov    %ecx,0x34(%rdx)
   8527d:	89 42 31             	mov    %eax,0x31(%rdx)
   85280:	4c 89 2a             	mov    %r13,(%rdx)
   85283:	4c 89 62 08          	mov    %r12,0x8(%rdx)
   85287:	f3 0f 7f 4a 10       	movdqu %xmm1,0x10(%rdx)
   8528c:	f3 0f 7f 42 20       	movdqu %xmm0,0x20(%rdx)
   85291:	40 88 6a 30          	mov    %bpl,0x30(%rdx)
   85295:	e9 76 f8 ff ff       	jmp    84b10 <<oriole::Parser>::next_event_inner+0x3580>
   8529a:	48 8d 0d 5c c1 f8 ff 	lea    -0x73ea4(%rip),%rcx        # 113fd <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4a61>
   852a1:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   852a8:	00 
   852a9:	41 b8 14 00 00 00    	mov    $0x14,%r8d
   852af:	4c 89 f6             	mov    %r14,%rsi
   852b2:	ba 03 00 00 00       	mov    $0x3,%edx
   852b7:	49 89 d9             	mov    %rbx,%r9
   852ba:	e8 51 bc 00 00       	call   90f10 <<oriole::Parser>::err_at>
   852bf:	e9 ea fe ff ff       	jmp    851ae <<oriole::Parser>::next_event_inner+0x3c1e>
   852c4:	4c 8b bf 28 01 00 00 	mov    0x128(%rdi),%r15
   852cb:	31 f6                	xor    %esi,%esi
   852cd:	31 d2                	xor    %edx,%edx
   852cf:	e8 5c a5 fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   852d4:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   852d9:	4d 3b be 68 08 00 00 	cmp    0x868(%r14),%r15
   852e0:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   852e5:	75 39                	jne    85320 <<oriole::Parser>::next_event_inner+0x3d90>
   852e7:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   852ee:	48 85 c0             	test   %rax,%rax
   852f1:	0f 84 19 03 00 00    	je     85610 <<oriole::Parser>::next_event_inner+0x4080>
   852f7:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
   852fc:	49 8b 8e 80 01 00 00 	mov    0x180(%r14),%rcx
   85303:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   85307:	48 c1 e0 07          	shl    $0x7,%rax
   8530b:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
   8530f:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   85316:	e8 e5 9a fe ff       	call   6ee00 <<oriole::encoding::Source>::mark_deferred>
   8531b:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   85320:	84 db                	test   %bl,%bl
   85322:	74 27                	je     8534b <<oriole::Parser>::next_event_inner+0x3dbb>
   85324:	48 8d 0d 00 d6 f8 ff 	lea    -0x72a00(%rip),%rcx        # 1292b <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f8f>
   8532b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   85332:	00 
   85333:	41 b8 12 00 00 00    	mov    $0x12,%r8d
   85339:	4c 89 f6             	mov    %r14,%rsi
   8533c:	ba 04 00 00 00       	mov    $0x4,%edx
   85341:	e8 6a b1 00 00       	call   904b0 <<oriole::Parser>::err>
   85346:	e9 78 c2 ff ff       	jmp    815c3 <<oriole::Parser>::next_event_inner+0x33>
   8534b:	41 c6 47 30 ff       	movb   $0xff,0x30(%r15)
   85350:	e9 bb f7 ff ff       	jmp    84b10 <<oriole::Parser>::next_event_inner+0x3580>
   85355:	41 0f b6 86 ba 08 00 	movzbl 0x8ba(%r14),%eax
   8535c:	00 
   8535d:	41 0f b6 8e b3 08 00 	movzbl 0x8b3(%r14),%ecx
   85364:	00 
   85365:	08 c1                	or     %al,%cl
   85367:	f6 c1 01             	test   $0x1,%cl
   8536a:	0f 84 00 01 00 00    	je     85470 <<oriole::Parser>::next_event_inner+0x3ee0>
   85370:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   85375:	48 83 b9 08 02 00 00 	cmpq   $0x0,0x208(%rcx)
   8537c:	00 
   8537d:	0f 84 eb 01 00 00    	je     8556e <<oriole::Parser>::next_event_inner+0x3fde>
   85383:	a8 01                	test   $0x1,%al
   85385:	b8 0c 00 00 00       	mov    $0xc,%eax
   8538a:	ba 02 00 00 00       	mov    $0x2,%edx
   8538f:	0f 45 d0             	cmovne %eax,%edx
   85392:	48 8d 0d 57 34 f8 ff 	lea    -0x7cba9(%rip),%rcx        # 87f0 <std::thread::current::id::ID+0x8780>
   85399:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   853a0:	00 
   853a1:	41 b8 10 00 00 00    	mov    $0x10,%r8d
   853a7:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   853ac:	e9 f8 fd ff ff       	jmp    851a9 <<oriole::Parser>::next_event_inner+0x3c19>
   853b1:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   853b6:	83 38 01             	cmpl   $0x1,(%rax)
   853b9:	0f 85 d5 00 00 00    	jne    85494 <<oriole::Parser>::next_event_inner+0x3f04>
   853bf:	48 8b 9f 88 fe ff ff 	mov    -0x178(%rdi),%rbx
   853c6:	0f 10 87 90 fe ff ff 	movups -0x170(%rdi),%xmm0
   853cd:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   853d2:	48 8b 87 a0 fe ff ff 	mov    -0x160(%rdi),%rax
   853d9:	e9 d1 00 00 00       	jmp    854af <<oriole::Parser>::next_event_inner+0x3f1f>
   853de:	48 8d 3d f5 d8 f8 ff 	lea    -0x7270b(%rip),%rdi        # 12cda <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x633e>
   853e5:	48 8d 15 ec ee 05 00 	lea    0x5eeec(%rip),%rdx        # e42d8 <oriole_expat::FEATURES+0x16f0>
   853ec:	be 17 00 00 00       	mov    $0x17,%esi
   853f1:	ff 15 e1 1a 06 00    	call   *0x61ae1(%rip)        # e6ed8 <_GLOBAL_OFFSET_TABLE_+0x760>
   853f7:	e9 af 03 00 00       	jmp    857ab <<oriole::Parser>::next_event_inner+0x421b>
   853fc:	48 8d 0d fd d4 f8 ff 	lea    -0x72b03(%rip),%rcx        # 12900 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f64>
   85403:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8540a:	00 
   8540b:	41 b8 1a 00 00 00    	mov    $0x1a,%r8d
   85411:	e9 2e fb ff ff       	jmp    84f44 <<oriole::Parser>::next_event_inner+0x39b4>
   85416:	48 8d 0d 06 c9 f8 ff 	lea    -0x736fa(%rip),%rcx        # 11d23 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5387>
   8541d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   85424:	00 
   85425:	41 b8 25 00 00 00    	mov    $0x25,%r8d
   8542b:	41 b9 02 00 00 00    	mov    $0x2,%r9d
   85431:	4c 89 f6             	mov    %r14,%rsi
   85434:	ba 03 00 00 00       	mov    $0x3,%edx
   85439:	e8 d2 ba 00 00       	call   90f10 <<oriole::Parser>::err_at>
   8543e:	e9 6b fd ff ff       	jmp    851ae <<oriole::Parser>::next_event_inner+0x3c1e>
   85443:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   85448:	83 38 01             	cmpl   $0x1,(%rax)
   8544b:	0f 85 d0 00 00 00    	jne    85521 <<oriole::Parser>::next_event_inner+0x3f91>
   85451:	48 8b 9f 88 fe ff ff 	mov    -0x178(%rdi),%rbx
   85458:	0f 10 87 90 fe ff ff 	movups -0x170(%rdi),%xmm0
   8545f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   85464:	48 8b 87 a0 fe ff ff 	mov    -0x160(%rdi),%rax
   8546b:	e9 cc 00 00 00       	jmp    8553c <<oriole::Parser>::next_event_inner+0x3fac>
   85470:	48 8d 0d d4 d3 f8 ff 	lea    -0x72c2c(%rip),%rcx        # 1284b <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5eaf>
   85477:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8547e:	00 
   8547f:	41 b8 1c 00 00 00    	mov    $0x1c,%r8d
   85485:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   8548a:	ba 02 00 00 00       	mov    $0x2,%edx
   8548f:	e9 15 fd ff ff       	jmp    851a9 <<oriole::Parser>::next_event_inner+0x3c19>
   85494:	48 8b 5f a8          	mov    -0x58(%rdi),%rbx
   85498:	0f 10 47 d8          	movups -0x28(%rdi),%xmm0
   8549c:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   854a1:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   854a6:	31 f6                	xor    %esi,%esi
   854a8:	31 d2                	xor    %edx,%edx
   854aa:	e8 81 a3 fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   854af:	48 8d 0d 06 c8 f8 ff 	lea    -0x737fa(%rip),%rcx        # 11cbc <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5320>
   854b6:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   854bb:	48 c7 44 24 28 1c 00 	movq   $0x1c,0x28(%rsp)
   854c2:	00 00 
   854c4:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   854c9:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
   854cf:	f3 0f 7f 44 24 38    	movdqu %xmm0,0x38(%rsp)
   854d5:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   854da:	b0 03                	mov    $0x3,%al
   854dc:	e9 d3 f8 ff ff       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   854e1:	48 8d 05 c4 bf f8 ff 	lea    -0x7403c(%rip),%rax        # 114ac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   854e8:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   854ed:	48 c7 44 24 28 0d 00 	movq   $0xd,0x28(%rsp)
   854f4:	00 00 
   854f6:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   854fd:	00 00 
   854ff:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
   85506:	00 00 
   85508:	66 0f ef c0          	pxor   %xmm0,%xmm0
   8550c:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   85511:	66 0f 7f 40 10       	movdqa %xmm0,0x10(%rax)
   85516:	c6 40 20 00          	movb   $0x0,0x20(%rax)
   8551a:	31 c0                	xor    %eax,%eax
   8551c:	e9 93 f8 ff ff       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   85521:	48 8b 5f a8          	mov    -0x58(%rdi),%rbx
   85525:	0f 10 47 d8          	movups -0x28(%rdi),%xmm0
   85529:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   8552e:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   85533:	31 f6                	xor    %esi,%esi
   85535:	31 d2                	xor    %edx,%edx
   85537:	e8 f4 a2 fe ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   8553c:	48 8d 0d f0 c0 f8 ff 	lea    -0x73f10(%rip),%rcx        # 11633 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4c97>
   85543:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   85548:	48 c7 44 24 28 2a 00 	movq   $0x2a,0x28(%rsp)
   8554f:	00 00 
   85551:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   85556:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
   8555c:	f3 0f 7f 44 24 38    	movdqu %xmm0,0x38(%rsp)
   85562:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   85567:	b0 01                	mov    $0x1,%al
   85569:	e9 46 f8 ff ff       	jmp    84db4 <<oriole::Parser>::next_event_inner+0x3824>
   8556e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   85573:	c6 80 b9 08 00 00 01 	movb   $0x1,0x8b9(%rax)
   8557a:	e9 88 f5 ff ff       	jmp    84b07 <<oriole::Parser>::next_event_inner+0x3577>
   8557f:	48 8d 0d 46 d3 f8 ff 	lea    -0x72cba(%rip),%rcx        # 128cc <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f30>
   85586:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8558d:	00 
   8558e:	41 b8 22 00 00 00    	mov    $0x22,%r8d
   85594:	4c 89 f6             	mov    %r14,%rsi
   85597:	ba 01 00 00 00       	mov    $0x1,%edx
   8559c:	e9 08 fc ff ff       	jmp    851a9 <<oriole::Parser>::next_event_inner+0x3c19>
   855a1:	48 8d 05 04 bf f8 ff 	lea    -0x740fc(%rip),%rax        # 114ac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   855a8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   855ad:	48 89 01             	mov    %rax,(%rcx)
   855b0:	48 c7 41 08 0d 00 00 	movq   $0xd,0x8(%rcx)
   855b7:	00 
   855b8:	48 c7 41 10 00 00 00 	movq   $0x0,0x10(%rcx)
   855bf:	00 
   855c0:	48 c7 41 18 01 00 00 	movq   $0x1,0x18(%rcx)
   855c7:	00 
   855c8:	66 0f ef c0          	pxor   %xmm0,%xmm0
   855cc:	f3 0f 7f 41 20       	movdqu %xmm0,0x20(%rcx)
   855d1:	c6 41 30 00          	movb   $0x0,0x30(%rcx)
   855d5:	e9 36 f5 ff ff       	jmp    84b10 <<oriole::Parser>::next_event_inner+0x3580>
   855da:	4c 8d 05 0f e1 05 00 	lea    0x5e10f(%rip),%r8        # e36f0 <oriole_expat::FEATURES+0xb08>
   855e1:	4c 89 ef             	mov    %r13,%rdi
   855e4:	48 89 ee             	mov    %rbp,%rsi
   855e7:	31 d2                	xor    %edx,%edx
   855e9:	4c 89 f9             	mov    %r15,%rcx
   855ec:	ff 15 c6 18 06 00    	call   *0x618c6(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   855f2:	48 8d 3d e1 cd f8 ff 	lea    -0x7321f(%rip),%rdi        # 123da <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   855f9:	48 8d 15 a8 ec 05 00 	lea    0x5eca8(%rip),%rdx        # e42a8 <oriole_expat::FEATURES+0x16c0>
   85600:	be 21 00 00 00       	mov    $0x21,%esi
   85605:	ff 15 cd 18 06 00    	call   *0x618cd(%rip)        # e6ed8 <_GLOBAL_OFFSET_TABLE_+0x760>
   8560b:	e9 9b 01 00 00       	jmp    857ab <<oriole::Parser>::next_event_inner+0x421b>
   85610:	48 8d 3d c3 cd f8 ff 	lea    -0x7323d(%rip),%rdi        # 123da <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   85617:	48 8d 15 82 e8 05 00 	lea    0x5e882(%rip),%rdx        # e3ea0 <oriole_expat::FEATURES+0x12b8>
   8561e:	be 21 00 00 00       	mov    $0x21,%esi
   85623:	ff 15 af 18 06 00    	call   *0x618af(%rip)        # e6ed8 <_GLOBAL_OFFSET_TABLE_+0x760>
   85629:	4c 8d 05 50 e0 05 00 	lea    0x5e050(%rip),%r8        # e3680 <oriole_expat::FEATURES+0xa98>
   85630:	48 89 c7             	mov    %rax,%rdi
   85633:	48 89 d6             	mov    %rdx,%rsi
   85636:	31 d2                	xor    %edx,%edx
   85638:	4c 89 f9             	mov    %r15,%rcx
   8563b:	ff 15 77 18 06 00    	call   *0x61877(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   85641:	4c 8d 05 10 e5 05 00 	lea    0x5e510(%rip),%r8        # e3b58 <oriole_expat::FEATURES+0xf70>
   85648:	48 89 ef             	mov    %rbp,%rdi
   8564b:	4c 89 ee             	mov    %r13,%rsi
   8564e:	4c 89 e9             	mov    %r13,%rcx
   85651:	ff 15 61 18 06 00    	call   *0x61861(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   85657:	48 8d 3d 93 d6 f8 ff 	lea    -0x7296d(%rip),%rdi        # 12cf1 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x6355>
   8565e:	48 8d 15 d3 ec 05 00 	lea    0x5ecd3(%rip),%rdx        # e4338 <oriole_expat::FEATURES+0x1750>
   85665:	be 16 00 00 00       	mov    $0x16,%esi
   8566a:	ff 15 68 18 06 00    	call   *0x61868(%rip)        # e6ed8 <_GLOBAL_OFFSET_TABLE_+0x760>
   85670:	4c 89 c1             	mov    %r8,%rcx
   85673:	4c 8d 05 a6 ec 05 00 	lea    0x5eca6(%rip),%r8        # e4320 <oriole_expat::FEATURES+0x1738>
   8567a:	4c 89 df             	mov    %r11,%rdi
   8567d:	48 89 ce             	mov    %rcx,%rsi
   85680:	48 89 ea             	mov    %rbp,%rdx
   85683:	ff 15 2f 18 06 00    	call   *0x6182f(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   85689:	4c 8d 05 48 e0 05 00 	lea    0x5e048(%rip),%r8        # e36d8 <oriole_expat::FEATURES+0xaf0>
   85690:	ba 01 00 00 00       	mov    $0x1,%edx
   85695:	4c 89 ef             	mov    %r13,%rdi
   85698:	48 89 ee             	mov    %rbp,%rsi
   8569b:	ff 15 17 18 06 00    	call   *0x61817(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   856a1:	49 f7 df             	neg    %r15
   856a4:	4c 8d 05 a5 d8 05 00 	lea    0x5d8a5(%rip),%r8        # e2f50 <oriole_expat::FEATURES+0x368>
   856ab:	4c 89 e7             	mov    %r12,%rdi
   856ae:	48 89 ee             	mov    %rbp,%rsi
   856b1:	4c 89 fa             	mov    %r15,%rdx
   856b4:	48 89 e9             	mov    %rbp,%rcx
   856b7:	ff 15 fb 17 06 00    	call   *0x617fb(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   856bd:	4c 8d 05 94 e4 05 00 	lea    0x5e494(%rip),%r8        # e3b58 <oriole_expat::FEATURES+0xf70>
   856c4:	4c 89 cf             	mov    %r9,%rdi
   856c7:	48 89 ce             	mov    %rcx,%rsi
   856ca:	4c 89 ea             	mov    %r13,%rdx
   856cd:	ff 15 e5 17 06 00    	call   *0x617e5(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   856d3:	4c 8d 05 de e7 05 00 	lea    0x5e7de(%rip),%r8        # e3eb8 <oriole_expat::FEATURES+0x12d0>
   856da:	4c 89 e7             	mov    %r12,%rdi
   856dd:	31 d2                	xor    %edx,%edx
   856df:	48 89 e9             	mov    %rbp,%rcx
   856e2:	ff 15 d0 17 06 00    	call   *0x617d0(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   856e8:	4c 8d 05 11 e8 05 00 	lea    0x5e811(%rip),%r8        # e3f00 <oriole_expat::FEATURES+0x1318>
   856ef:	eb 07                	jmp    856f8 <<oriole::Parser>::next_event_inner+0x4168>
   856f1:	4c 8d 05 f0 e7 05 00 	lea    0x5e7f0(%rip),%r8        # e3ee8 <oriole_expat::FEATURES+0x1300>
   856f8:	4c 89 e7             	mov    %r12,%rdi
   856fb:	48 89 ee             	mov    %rbp,%rsi
   856fe:	31 d2                	xor    %edx,%edx
   85700:	4c 89 f9             	mov    %r15,%rcx
   85703:	ff 15 af 17 06 00    	call   *0x617af(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   85709:	48 8d 3d ca cc f8 ff 	lea    -0x73336(%rip),%rdi        # 123da <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   85710:	48 8d 15 91 eb 05 00 	lea    0x5eb91(%rip),%rdx        # e42a8 <oriole_expat::FEATURES+0x16c0>
   85717:	be 21 00 00 00       	mov    $0x21,%esi
   8571c:	ff 15 b6 17 06 00    	call   *0x617b6(%rip)        # e6ed8 <_GLOBAL_OFFSET_TABLE_+0x760>
   85722:	e9 84 00 00 00       	jmp    857ab <<oriole::Parser>::next_event_inner+0x421b>
   85727:	48 8d 15 a2 e7 05 00 	lea    0x5e7a2(%rip),%rdx        # e3ed0 <oriole_expat::FEATURES+0x12e8>
   8572e:	48 89 ee             	mov    %rbp,%rsi
   85731:	ff 15 f1 16 06 00    	call   *0x616f1(%rip)        # e6e28 <_GLOBAL_OFFSET_TABLE_+0x6b0>
   85737:	4c 8d 05 5a e9 05 00 	lea    0x5e95a(%rip),%r8        # e4098 <oriole_expat::FEATURES+0x14b0>
   8573e:	ba 02 00 00 00       	mov    $0x2,%edx
   85743:	48 89 c7             	mov    %rax,%rdi
   85746:	48 89 ce             	mov    %rcx,%rsi
   85749:	ff 15 69 17 06 00    	call   *0x61769(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   8574f:	31 c9                	xor    %ecx,%ecx
   85751:	48 8d 05 c8 df 05 00 	lea    0x5dfc8(%rip),%rax        # e3720 <oriole_expat::FEATURES+0xb38>
   85758:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
   8575f:	00 
   85760:	eb 1a                	jmp    8577c <<oriole::Parser>::next_event_inner+0x41ec>
   85762:	48 8d 05 ff de 05 00 	lea    0x5deff(%rip),%rax        # e3668 <oriole_expat::FEATURES+0xa80>
   85769:	48 89 d6             	mov    %rdx,%rsi
   8576c:	48 89 c2             	mov    %rax,%rdx
   8576f:	ff 15 b3 16 06 00    	call   *0x616b3(%rip)        # e6e28 <_GLOBAL_OFFSET_TABLE_+0x6b0>
   85775:	b9 01 00 00 00       	mov    $0x1,%ecx
   8577a:	31 d2                	xor    %edx,%edx
   8577c:	48 89 ef             	mov    %rbp,%rdi
   8577f:	4c 89 ee             	mov    %r13,%rsi
   85782:	4c 8b 84 24 20 03 00 	mov    0x320(%rsp),%r8
   85789:	00 
   8578a:	ff 15 28 17 06 00    	call   *0x61728(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   85790:	eb 19                	jmp    857ab <<oriole::Parser>::next_event_inner+0x421b>
   85792:	48 8d 3d 41 cc f8 ff 	lea    -0x733bf(%rip),%rdi        # 123da <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   85799:	48 8d 15 08 eb 05 00 	lea    0x5eb08(%rip),%rdx        # e42a8 <oriole_expat::FEATURES+0x16c0>
   857a0:	be 21 00 00 00       	mov    $0x21,%esi
   857a5:	ff 15 2d 17 06 00    	call   *0x6172d(%rip)        # e6ed8 <_GLOBAL_OFFSET_TABLE_+0x760>
   857ab:	0f 0b                	ud2
   857ad:	4c 8d 05 9c de 05 00 	lea    0x5de9c(%rip),%r8        # e3650 <oriole_expat::FEATURES+0xa68>
   857b4:	ba 02 00 00 00       	mov    $0x2,%edx
   857b9:	48 8b 8c 24 10 02 00 	mov    0x210(%rsp),%rcx
   857c0:	00 
   857c1:	48 89 ce             	mov    %rcx,%rsi
   857c4:	ff 15 ee 16 06 00    	call   *0x616ee(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   857ca:	4c 8d 05 67 de 05 00 	lea    0x5de67(%rip),%r8        # e3638 <oriole_expat::FEATURES+0xa50>
   857d1:	ba 02 00 00 00       	mov    $0x2,%edx
   857d6:	4c 89 df             	mov    %r11,%rdi
   857d9:	48 8b 8c 24 10 02 00 	mov    0x210(%rsp),%rcx
   857e0:	00 
   857e1:	48 89 ce             	mov    %rcx,%rsi
   857e4:	ff 15 ce 16 06 00    	call   *0x616ce(%rip)        # e6eb8 <_GLOBAL_OFFSET_TABLE_+0x740>
   857ea:	48 89 c3             	mov    %rax,%rbx
   857ed:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   857f4:	00 
   857f5:	e8 b6 41 fc ff       	call   499b0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   857fa:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
   85801:	00 
   85802:	e8 a9 41 fc ff       	call   499b0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   85807:	e9 54 02 00 00       	jmp    85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   8580c:	eb 50                	jmp    8585e <<oriole::Parser>::next_event_inner+0x42ce>
   8580e:	eb 00                	jmp    85810 <<oriole::Parser>::next_event_inner+0x4280>
   85810:	48 89 c3             	mov    %rax,%rbx
   85813:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
   8581a:	00 
   8581b:	e8 30 36 fc ff       	call   48e50 <core::ptr::drop_glue::<oriole::EventKind>>
   85820:	e9 e4 00 00 00       	jmp    85909 <<oriole::Parser>::next_event_inner+0x4379>
   85825:	48 89 c3             	mov    %rax,%rbx
   85828:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   8582f:	00 
   85830:	e8 7b 41 fc ff       	call   499b0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   85835:	e9 26 02 00 00       	jmp    85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   8583a:	eb 22                	jmp    8585e <<oriole::Parser>::next_event_inner+0x42ce>
   8583c:	e9 b8 00 00 00       	jmp    858f9 <<oriole::Parser>::next_event_inner+0x4369>
   85841:	eb 1b                	jmp    8585e <<oriole::Parser>::next_event_inner+0x42ce>
   85843:	48 89 c3             	mov    %rax,%rbx
   85846:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8584d:	00 
   8584e:	e8 fd 45 fc ff       	call   49e50 <core::ptr::drop_glue::<oriole::dtd::composition::Header>>
   85853:	e9 08 02 00 00       	jmp    85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   85858:	ff 15 9a 16 06 00    	call   *0x6169a(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   8585e:	48 89 c3             	mov    %rax,%rbx
   85861:	e9 a3 00 00 00       	jmp    85909 <<oriole::Parser>::next_event_inner+0x4379>
   85866:	48 89 c3             	mov    %rax,%rbx
   85869:	48 8d bc 24 10 04 00 	lea    0x410(%rsp),%rdi
   85870:	00 
   85871:	e8 3a 41 fc ff       	call   499b0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   85876:	e9 e5 01 00 00       	jmp    85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   8587b:	ff 15 77 16 06 00    	call   *0x61677(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   85881:	48 89 c3             	mov    %rax,%rbx
   85884:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8588b:	00 
   8588c:	e8 af 41 fc ff       	call   49a40 <core::ptr::drop_glue::<oriole::encoding::Source>>
   85891:	e9 ca 01 00 00       	jmp    85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   85896:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   8589d:	00 
   8589e:	41 0f 11 45 60       	movups %xmm0,0x60(%r13)
   858a3:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   858aa:	00 
   858ab:	41 0f 11 45 50       	movups %xmm0,0x50(%r13)
   858b0:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
   858b7:	00 
   858b8:	41 0f 11 45 40       	movups %xmm0,0x40(%r13)
   858bd:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
   858c4:	00 
   858c5:	0f 28 8c 24 90 00 00 	movaps 0x90(%rsp),%xmm1
   858cc:	00 
   858cd:	0f 28 94 24 a0 00 00 	movaps 0xa0(%rsp),%xmm2
   858d4:	00 
   858d5:	0f 28 9c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm3
   858dc:	00 
   858dd:	41 0f 11 5d 30       	movups %xmm3,0x30(%r13)
   858e2:	41 0f 11 55 20       	movups %xmm2,0x20(%r13)
   858e7:	41 0f 11 4d 10       	movups %xmm1,0x10(%r13)
   858ec:	41 0f 11 45 00       	movups %xmm0,0x0(%r13)
   858f1:	48 89 c7             	mov    %rax,%rdi
   858f4:	e8 a7 72 fa ff       	call   2cba0 <_Unwind_Resume@plt>
   858f9:	48 89 c3             	mov    %rax,%rbx
   858fc:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   85903:	00 
   85904:	e8 47 35 fc ff       	call   48e50 <core::ptr::drop_glue::<oriole::EventKind>>
   85909:	48 8b 8c 24 88 03 00 	mov    0x388(%rsp),%rcx
   85910:	00 
   85911:	48 85 c9             	test   %rcx,%rcx
   85914:	0f 84 46 01 00 00    	je     85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   8591a:	48 8b b4 24 80 03 00 	mov    0x380(%rsp),%rsi
   85921:	00 
   85922:	48 8d bc 24 60 03 00 	lea    0x360(%rsp),%rdi
   85929:	00 
   8592a:	ba 01 00 00 00       	mov    $0x1,%edx
   8592f:	ff 15 7b 0f 06 00    	call   *0x60f7b(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   85935:	e9 26 01 00 00       	jmp    85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   8593a:	ff 15 b8 15 06 00    	call   *0x615b8(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   85940:	48 89 c3             	mov    %rax,%rbx
   85943:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   8594a:	00 
   8594b:	e8 60 44 fc ff       	call   49db0 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   85950:	e9 0b 01 00 00       	jmp    85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   85955:	ff 15 9d 15 06 00    	call   *0x6159d(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   8595b:	48 89 c3             	mov    %rax,%rbx
   8595e:	4d 89 3e             	mov    %r15,(%r14)
   85961:	49 83 c6 08          	add    $0x8,%r14
   85965:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
   8596c:	00 
   8596d:	ba 90 00 00 00       	mov    $0x90,%edx
   85972:	4c 89 f7             	mov    %r14,%rdi
   85975:	ff 15 1d 18 06 00    	call   *0x6181d(%rip)        # e7198 <memcpy@GLIBC_2.14>
   8597b:	48 89 df             	mov    %rbx,%rdi
   8597e:	e8 1d 72 fa ff       	call   2cba0 <_Unwind_Resume@plt>
   85983:	e9 c8 00 00 00       	jmp    85a50 <<oriole::Parser>::next_event_inner+0x44c0>
   85988:	48 89 c3             	mov    %rax,%rbx
   8598b:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   85992:	00 
   85993:	e8 48 08 fc ff       	call   461e0 <core::ptr::drop_glue::<core::option::Option<(oriole_storage::string::String, oriole::Position)>>>
   85998:	e9 c3 00 00 00       	jmp    85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   8599d:	48 89 c3             	mov    %rax,%rbx
   859a0:	31 ed                	xor    %ebp,%ebp
   859a2:	eb 5b                	jmp    859ff <<oriole::Parser>::next_event_inner+0x446f>
   859a4:	48 89 c3             	mov    %rax,%rbx
   859a7:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
   859ae:	00 
   859af:	48 89 45 30          	mov    %rax,0x30(%rbp)
   859b3:	f3 0f 6f 84 24 50 02 	movdqu 0x250(%rsp),%xmm0
   859ba:	00 00 
   859bc:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   859c3:	00 00 
   859c5:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   859cc:	00 00 
   859ce:	f3 0f 7f 55 20       	movdqu %xmm2,0x20(%rbp)
   859d3:	f3 0f 7f 4d 10       	movdqu %xmm1,0x10(%rbp)
   859d8:	f3 0f 7f 45 00       	movdqu %xmm0,0x0(%rbp)
   859dd:	31 ed                	xor    %ebp,%ebp
   859df:	eb 1e                	jmp    859ff <<oriole::Parser>::next_event_inner+0x446f>
   859e1:	48 89 c3             	mov    %rax,%rbx
   859e4:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   859eb:	00 
   859ec:	e8 df 04 fc ff       	call   45ed0 <core::ptr::drop_glue::<core::option::Option<oriole::PendingEvent>>>
   859f1:	eb 6d                	jmp    85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   859f3:	ff 15 ff 14 06 00    	call   *0x614ff(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   859f9:	48 89 c3             	mov    %rax,%rbx
   859fc:	40 b5 01             	mov    $0x1,%bpl
   859ff:	48 8d bc 24 88 02 00 	lea    0x288(%rsp),%rdi
   85a06:	00 
   85a07:	e8 44 34 fc ff       	call   48e50 <core::ptr::drop_glue::<oriole::EventKind>>
   85a0c:	83 bc 24 50 02 00 00 	cmpl   $0xffffffff,0x250(%rsp)
   85a13:	ff 
   85a14:	0f 94 c0             	sete   %al
   85a17:	40 80 f5 01          	xor    $0x1,%bpl
   85a1b:	40 08 c5             	or     %al,%bpl
   85a1e:	75 40                	jne    85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   85a20:	48 8b 8c 24 78 02 00 	mov    0x278(%rsp),%rcx
   85a27:	00 
   85a28:	48 85 c9             	test   %rcx,%rcx
   85a2b:	74 33                	je     85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   85a2d:	48 8b b4 24 70 02 00 	mov    0x270(%rsp),%rsi
   85a34:	00 
   85a35:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   85a3c:	00 
   85a3d:	ba 01 00 00 00       	mov    $0x1,%edx
   85a42:	ff 15 68 0e 06 00    	call   *0x60e68(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   85a48:	eb 16                	jmp    85a60 <<oriole::Parser>::next_event_inner+0x44d0>
   85a4a:	ff 15 a8 14 06 00    	call   *0x614a8(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   85a50:	48 89 c3             	mov    %rax,%rbx
   85a53:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   85a5a:	00 
   85a5b:	e8 50 3f fc ff       	call   499b0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   85a60:	48 89 df             	mov    %rbx,%rdi
   85a63:	e8 38 71 fa ff       	call   2cba0 <_Unwind_Resume@plt>
   85a68:	ff 15 8a 14 06 00    	call   *0x6148a(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
