
/tmp/oriole-event-output/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .text:

000000000007d3e0 <<oriole::Parser>::next_event_into>:
   7d3e0:	55                   	push   %rbp
   7d3e1:	41 57                	push   %r15
   7d3e3:	41 56                	push   %r14
   7d3e5:	41 55                	push   %r13
   7d3e7:	41 54                	push   %r12
   7d3e9:	53                   	push   %rbx
   7d3ea:	48 83 ec 58          	sub    $0x58,%rsp
   7d3ee:	48 89 fb             	mov    %rdi,%rbx
   7d3f1:	8b 86 58 08 00 00    	mov    0x858(%rsi),%eax
   7d3f7:	85 c0                	test   %eax,%eax
   7d3f9:	0f 94 c1             	sete   %cl
   7d3fc:	0f b6 86 b1 08 00 00 	movzbl 0x8b1(%rsi),%eax
   7d403:	08 c1                	or     %al,%cl
   7d405:	f6 c1 01             	test   $0x1,%cl
   7d408:	0f 84 c5 00 00 00    	je     7d4d3 <<oriole::Parser>::next_event_into+0xf3>
   7d40e:	80 be 40 08 00 00 ff 	cmpb   $0xff,0x840(%rsi)
   7d415:	0f 94 c1             	sete   %cl
   7d418:	84 c1                	test   %al,%cl
   7d41a:	0f 84 a9 00 00 00    	je     7d4c9 <<oriole::Parser>::next_event_into+0xe9>
   7d420:	8b 86 58 08 00 00    	mov    0x858(%rsi),%eax
   7d426:	85 c0                	test   %eax,%eax
   7d428:	0f 84 9b 00 00 00    	je     7d4c9 <<oriole::Parser>::next_event_into+0xe9>
   7d42e:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   7d433:	49 89 f6             	mov    %rsi,%r14
   7d436:	49 89 d7             	mov    %rdx,%r15
   7d439:	e8 c2 8a ff ff       	call   75f00 <<oriole::Parser>::ensure_shared_tables>
   7d43e:	4c 89 fa             	mov    %r15,%rdx
   7d441:	4c 89 f6             	mov    %r14,%rsi
   7d444:	80 7c 24 38 ff       	cmpb   $0xff,0x38(%rsp)
   7d449:	74 7e                	je     7d4c9 <<oriole::Parser>::next_event_into+0xe9>
   7d44b:	48 8d 86 10 08 00 00 	lea    0x810(%rsi),%rax
   7d452:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   7d457:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
   7d45b:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
   7d460:	0f 10 4c 24 18       	movups 0x18(%rsp),%xmm1
   7d465:	0f 10 54 24 28       	movups 0x28(%rsp),%xmm2
   7d46a:	0f 11 53 20          	movups %xmm2,0x20(%rbx)
   7d46e:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
   7d472:	0f 11 03             	movups %xmm0,(%rbx)
   7d475:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   7d47a:	48 89 48 30          	mov    %rcx,0x30(%rax)
   7d47e:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
   7d483:	0f 10 4c 24 18       	movups 0x18(%rsp),%xmm1
   7d488:	0f 10 54 24 28       	movups 0x28(%rsp),%xmm2
   7d48d:	0f 11 50 20          	movups %xmm2,0x20(%rax)
   7d491:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   7d495:	0f 11 00             	movups %xmm0,(%rax)
   7d498:	48 8b be b8 01 00 00 	mov    0x1b8(%rsi),%rdi
   7d49f:	48 8b 86 c8 01 00 00 	mov    0x1c8(%rsi),%rax
   7d4a6:	48 c7 86 c8 01 00 00 	movq   $0x0,0x1c8(%rsi)
   7d4ad:	00 00 00 00 
   7d4b1:	49 89 f6             	mov    %rsi,%r14
   7d4b4:	48 89 c6             	mov    %rax,%rsi
   7d4b7:	e8 d4 cb fc ff       	call   4a090 <core::ptr::drop_glue::<[core::option::Option<oriole::PendingEvent>]>>
   7d4bc:	49 c7 86 d0 01 00 00 	movq   $0x0,0x1d0(%r14)
   7d4c3:	00 00 00 00 
   7d4c7:	eb 12                	jmp    7d4db <<oriole::Parser>::next_event_into+0xfb>
   7d4c9:	8b 86 58 08 00 00    	mov    0x858(%rsi),%eax
   7d4cf:	85 c0                	test   %eax,%eax
   7d4d1:	74 1a                	je     7d4ed <<oriole::Parser>::next_event_into+0x10d>
   7d4d3:	48 89 df             	mov    %rbx,%rdi
   7d4d6:	e8 f5 89 00 00       	call   85ed0 <<oriole::Parser>::next_event_scoped>
   7d4db:	48 89 d8             	mov    %rbx,%rax
   7d4de:	48 83 c4 58          	add    $0x58,%rsp
   7d4e2:	5b                   	pop    %rbx
   7d4e3:	41 5c                	pop    %r12
   7d4e5:	41 5d                	pop    %r13
   7d4e7:	41 5e                	pop    %r14
   7d4e9:	41 5f                	pop    %r15
   7d4eb:	5d                   	pop    %rbp
   7d4ec:	c3                   	ret
   7d4ed:	4c 8b b6 50 08 00 00 	mov    0x850(%rsi),%r14
   7d4f4:	49 8b 46 20          	mov    0x20(%r14),%rax
   7d4f8:	48 b9 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rcx
   7d4ff:	ff ff 7f 
   7d502:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   7d509:	1f 84 00 00 00 00 00 
   7d510:	48 39 c8             	cmp    %rcx,%rax
   7d513:	0f 87 11 01 00 00    	ja     7d62a <<oriole::Parser>::next_event_into+0x24a>
   7d519:	48 8d 78 01          	lea    0x1(%rax),%rdi
   7d51d:	f0 49 0f b1 7e 20    	lock cmpxchg %rdi,0x20(%r14)
   7d523:	75 eb                	jne    7d510 <<oriole::Parser>::next_event_into+0x130>
   7d525:	b1 01                	mov    $0x1,%cl
   7d527:	31 c0                	xor    %eax,%eax
   7d529:	f0 41 0f b0 8e 70 01 	lock cmpxchg %cl,0x170(%r14)
   7d530:	00 00 
   7d532:	75 42                	jne    7d576 <<oriole::Parser>::next_event_into+0x196>
   7d534:	4d 8d 7e 28          	lea    0x28(%r14),%r15
   7d538:	4c 8d a6 70 02 00 00 	lea    0x270(%rsi),%r12
   7d53f:	4c 89 e7             	mov    %r12,%rdi
   7d542:	49 89 f5             	mov    %rsi,%r13
   7d545:	4c 89 fe             	mov    %r15,%rsi
   7d548:	48 89 d5             	mov    %rdx,%rbp
   7d54b:	e8 b0 82 fc ff       	call   45800 <core::intrinsics::typed_swap_nonoverlapping::<oriole::dtd_tables::DtdTables>>
   7d550:	48 89 df             	mov    %rbx,%rdi
   7d553:	4c 89 ee             	mov    %r13,%rsi
   7d556:	48 89 ea             	mov    %rbp,%rdx
   7d559:	e8 72 89 00 00       	call   85ed0 <<oriole::Parser>::next_event_scoped>
   7d55e:	4c 89 e7             	mov    %r12,%rdi
   7d561:	4c 89 fe             	mov    %r15,%rsi
   7d564:	e8 97 82 fc ff       	call   45800 <core::intrinsics::typed_swap_nonoverlapping::<oriole::dtd_tables::DtdTables>>
   7d569:	41 c6 86 70 01 00 00 	movb   $0x0,0x170(%r14)
   7d570:	00 
   7d571:	e9 8c 00 00 00       	jmp    7d602 <<oriole::Parser>::next_event_into+0x222>
   7d576:	48 8b 86 90 01 00 00 	mov    0x190(%rsi),%rax
   7d57d:	48 85 c0             	test   %rax,%rax
   7d580:	0f 84 89 00 00 00    	je     7d60f <<oriole::Parser>::next_event_into+0x22f>
   7d586:	48 8b 8e 80 01 00 00 	mov    0x180(%rsi),%rcx
   7d58d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   7d591:	48 c1 e2 07          	shl    $0x7,%rdx
   7d595:	48 8d 04 11          	lea    (%rcx,%rdx,1),%rax
   7d599:	83 bc 11 80 fe ff ff 	cmpl   $0x1,-0x180(%rcx,%rdx,1)
   7d5a0:	01 
   7d5a1:	75 17                	jne    7d5ba <<oriole::Parser>::next_event_into+0x1da>
   7d5a3:	4c 8b b8 88 fe ff ff 	mov    -0x178(%rax),%r15
   7d5aa:	0f 10 80 90 fe ff ff 	movups -0x170(%rax),%xmm0
   7d5b1:	48 8b 80 a0 fe ff ff 	mov    -0x160(%rax),%rax
   7d5b8:	eb 26                	jmp    7d5e0 <<oriole::Parser>::next_event_into+0x200>
   7d5ba:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
   7d5be:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   7d5c5:	4c 8b 78 a8          	mov    -0x58(%rax),%r15
   7d5c9:	0f 10 40 d8          	movups -0x28(%rax),%xmm0
   7d5cd:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   7d5d2:	31 f6                	xor    %esi,%esi
   7d5d4:	31 d2                	xor    %edx,%edx
   7d5d6:	e8 55 22 ff ff       	call   6f830 <<oriole::encoding::Source>::raw_len>
   7d5db:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   7d5e0:	48 8d 0d 5a 4c f9 ff 	lea    -0x6b3a6(%rip),%rcx        # 12241 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x58a5>
   7d5e7:	48 89 0b             	mov    %rcx,(%rbx)
   7d5ea:	48 c7 43 08 1c 00 00 	movq   $0x1c,0x8(%rbx)
   7d5f1:	00 
   7d5f2:	4c 89 7b 10          	mov    %r15,0x10(%rbx)
   7d5f6:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
   7d5fa:	48 89 43 28          	mov    %rax,0x28(%rbx)
   7d5fe:	c6 43 30 10          	movb   $0x10,0x30(%rbx)
   7d602:	4c 89 f7             	mov    %r14,%rdi
   7d605:	e8 46 99 fc ff       	call   46f50 <core::ptr::drop_glue::<oriole_storage::shared::Shared<oriole_storage::try_lock::TryLock<oriole::dtd_tables::DtdTables>>>>
   7d60a:	e9 cc fe ff ff       	jmp    7d4db <<oriole::Parser>::next_event_into+0xfb>
   7d60f:	48 8d 3d c4 4d f9 ff 	lea    -0x6b23c(%rip),%rdi        # 123da <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   7d616:	48 8d 15 8b 6c 06 00 	lea    0x66c8b(%rip),%rdx        # e42a8 <oriole_expat::FEATURES+0x16c0>
   7d61d:	be 21 00 00 00       	mov    $0x21,%esi
   7d622:	ff 15 b0 98 06 00    	call   *0x698b0(%rip)        # e6ed8 <_GLOBAL_OFFSET_TABLE_+0x760>
   7d628:	0f 0b                	ud2
   7d62a:	ff 15 30 94 06 00    	call   *0x69430(%rip)        # e6a60 <_GLOBAL_OFFSET_TABLE_+0x2e8>
   7d630:	48 89 c3             	mov    %rax,%rbx
   7d633:	4c 89 e7             	mov    %r12,%rdi
   7d636:	4c 89 fe             	mov    %r15,%rsi
   7d639:	e8 c2 81 fc ff       	call   45800 <core::intrinsics::typed_swap_nonoverlapping::<oriole::dtd_tables::DtdTables>>
   7d63e:	41 c6 86 70 01 00 00 	movb   $0x0,0x170(%r14)
   7d645:	00 
   7d646:	eb 03                	jmp    7d64b <<oriole::Parser>::next_event_into+0x26b>
   7d648:	48 89 c3             	mov    %rax,%rbx
   7d64b:	4c 89 f7             	mov    %r14,%rdi
   7d64e:	e8 fd 98 fc ff       	call   46f50 <core::ptr::drop_glue::<oriole_storage::shared::Shared<oriole_storage::try_lock::TryLock<oriole::dtd_tables::DtdTables>>>>
   7d653:	48 89 df             	mov    %rbx,%rdi
   7d656:	e8 45 f5 fa ff       	call   2cba0 <_Unwind_Resume@plt>
   7d65b:	ff 15 97 98 06 00    	call   *0x69897(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
