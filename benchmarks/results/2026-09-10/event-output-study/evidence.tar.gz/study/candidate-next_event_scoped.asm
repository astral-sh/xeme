
/tmp/oriole-event-output/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000085ed0 <<oriole::Parser>::next_event_scoped>:
   85ed0:	55                   	push   %rbp
   85ed1:	41 57                	push   %r15
   85ed3:	41 56                	push   %r14
   85ed5:	41 55                	push   %r13
   85ed7:	41 54                	push   %r12
   85ed9:	53                   	push   %rbx
   85eda:	48 81 ec e8 03 00 00 	sub    $0x3e8,%rsp
   85ee1:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   85ee6:	49 89 f7             	mov    %rsi,%r15
   85ee9:	48 89 fd             	mov    %rdi,%rbp
   85eec:	80 be f1 07 00 00 01 	cmpb   $0x1,0x7f1(%rsi)
   85ef3:	75 4a                	jne    85f3f <<oriole::Parser>::next_event_scoped+0x6f>
   85ef5:	f3 41 0f 6f 87 d0 07 	movdqu 0x7d0(%r15),%xmm0
   85efc:	00 00 
   85efe:	41 0f 10 8f e0 07 00 	movups 0x7e0(%r15),%xmm1
   85f05:	00 
   85f06:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
   85f0d:	00 
   85f0e:	66 0f 7f 84 24 30 01 	movdqa %xmm0,0x130(%rsp)
   85f15:	00 00 
   85f17:	41 0f b6 87 f0 07 00 	movzbl 0x7f0(%r15),%eax
   85f1e:	00 
   85f1f:	41 c6 87 f1 07 00 00 	movb   $0x2,0x7f1(%r15)
   85f26:	02 
   85f27:	41 8b 8f 80 08 00 00 	mov    0x880(%r15),%ecx
   85f2e:	85 c9                	test   %ecx,%ecx
   85f30:	0f 84 c7 01 00 00    	je     860fd <<oriole::Parser>::next_event_scoped+0x22d>
   85f36:	24 01                	and    $0x1,%al
   85f38:	41 88 87 bd 08 00 00 	mov    %al,0x8bd(%r15)
   85f3f:	4d 8b a7 c8 01 00 00 	mov    0x1c8(%r15),%r12
   85f46:	49 8b 9f d0 01 00 00 	mov    0x1d0(%r15),%rbx
   85f4d:	4c 39 e3             	cmp    %r12,%rbx
   85f50:	0f 83 f0 02 00 00    	jae    86246 <<oriole::Parser>::next_event_scoped+0x376>
   85f56:	4d 8b af b8 01 00 00 	mov    0x1b8(%r15),%r13
   85f5d:	4c 69 f3 d0 00 00 00 	imul   $0xd0,%rbx,%r14
   85f64:	4b 8d 34 2e          	lea    (%r14,%r13,1),%rsi
   85f68:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   85f6f:	00 
   85f70:	ba d0 00 00 00       	mov    $0xd0,%edx
   85f75:	ff 15 1d 12 06 00    	call   *0x6121d(%rip)        # e7198 <memcpy@GLIBC_2.14>
   85f7b:	4b c7 44 35 00 fe ff 	movq   $0xfffffffffffffffe,0x0(%r13,%r14,1)
   85f82:	ff ff 
   85f84:	48 ff c3             	inc    %rbx
   85f87:	49 89 9f d0 01 00 00 	mov    %rbx,0x1d0(%r15)
   85f8e:	4c 39 e3             	cmp    %r12,%rbx
   85f91:	75 21                	jne    85fb4 <<oriole::Parser>::next_event_scoped+0xe4>
   85f93:	49 c7 87 c8 01 00 00 	movq   $0x0,0x1c8(%r15)
   85f9a:	00 00 00 00 
   85f9e:	4c 89 ef             	mov    %r13,%rdi
   85fa1:	4c 89 e6             	mov    %r12,%rsi
   85fa4:	e8 e7 40 fc ff       	call   4a090 <core::ptr::drop_glue::<[core::option::Option<oriole::PendingEvent>]>>
   85fa9:	49 c7 87 d0 01 00 00 	movq   $0x0,0x1d0(%r15)
   85fb0:	00 00 00 00 
   85fb4:	48 8b 9c 24 30 01 00 	mov    0x130(%rsp),%rbx
   85fbb:	00 
   85fbc:	48 8d b4 24 38 01 00 	lea    0x138(%rsp),%rsi
   85fc3:	00 
   85fc4:	48 8d bc 24 20 03 00 	lea    0x320(%rsp),%rdi
   85fcb:	00 
   85fcc:	ba c8 00 00 00       	mov    $0xc8,%edx
   85fd1:	ff 15 c1 11 06 00    	call   *0x611c1(%rip)        # e7198 <memcpy@GLIBC_2.14>
   85fd7:	48 83 fb fe          	cmp    $0xfffffffffffffffe,%rbx
   85fdb:	0f 84 65 02 00 00    	je     86246 <<oriole::Parser>::next_event_scoped+0x376>
   85fe1:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   85fe6:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
   85fed:	00 
   85fee:	ba c8 00 00 00       	mov    $0xc8,%edx
   85ff3:	ff 15 9f 11 06 00    	call   *0x6119f(%rip)        # e7198 <memcpy@GLIBC_2.14>
   85ff9:	48 89 5c 24 60       	mov    %rbx,0x60(%rsp)
   85ffe:	83 bc 24 98 00 00 00 	cmpl   $0x12,0x98(%rsp)
   86005:	12 
   86006:	75 44                	jne    8604c <<oriole::Parser>::next_event_scoped+0x17c>
   86008:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
   8600f:	00 
   86010:	83 38 ff             	cmpl   $0xffffffff,(%rax)
   86013:	75 37                	jne    8604c <<oriole::Parser>::next_event_scoped+0x17c>
   86015:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   86019:	75 31                	jne    8604c <<oriole::Parser>::next_event_scoped+0x17c>
   8601b:	41 80 bf f1 07 00 00 	cmpb   $0x2,0x7f1(%r15)
   86022:	02 
   86023:	74 27                	je     8604c <<oriole::Parser>::next_event_scoped+0x17c>
   86025:	41 c6 87 f1 07 00 00 	movb   $0x1,0x7f1(%r15)
   8602c:	01 
   8602d:	41 8b 87 80 08 00 00 	mov    0x880(%r15),%eax
   86034:	85 c0                	test   %eax,%eax
   86036:	0f 85 71 07 00 00    	jne    867ad <<oriole::Parser>::next_event_scoped+0x8dd>
   8603c:	49 8b 87 78 08 00 00 	mov    0x878(%r15),%rax
   86043:	c6 40 28 00          	movb   $0x0,0x28(%rax)
   86047:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   8604c:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
   86050:	0f 84 6e 01 00 00    	je     861c4 <<oriole::Parser>::next_event_scoped+0x2f4>
   86056:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   8605d:	00 
   8605e:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   86065:	00 
   86066:	f3 0f 6f 44 24 60    	movdqu 0x60(%rsp),%xmm0
   8606c:	0f 10 4c 24 70       	movups 0x70(%rsp),%xmm1
   86071:	0f 10 94 24 80 00 00 	movups 0x80(%rsp),%xmm2
   86078:	00 
   86079:	0f 29 94 24 50 01 00 	movaps %xmm2,0x150(%rsp)
   86080:	00 
   86081:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
   86088:	00 
   86089:	66 0f 7f 84 24 30 01 	movdqa %xmm0,0x130(%rsp)
   86090:	00 00 
   86092:	48 89 eb             	mov    %rbp,%rbx
   86095:	48 85 c0             	test   %rax,%rax
   86098:	0f 84 ee 00 00 00    	je     8618c <<oriole::Parser>::next_event_scoped+0x2bc>
   8609e:	4d 8d a7 f0 04 00 00 	lea    0x4f0(%r15),%r12
   860a5:	49 8b 8f 18 05 00 00 	mov    0x518(%r15),%rcx
   860ac:	48 85 c9             	test   %rcx,%rcx
   860af:	74 15                	je     860c6 <<oriole::Parser>::next_event_scoped+0x1f6>
   860b1:	49 8b b7 10 05 00 00 	mov    0x510(%r15),%rsi
   860b8:	ba 01 00 00 00       	mov    $0x1,%edx
   860bd:	4c 89 e7             	mov    %r12,%rdi
   860c0:	ff 15 ea 07 06 00    	call   *0x607ea(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   860c6:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   860cd:	00 
   860ce:	49 89 44 24 30       	mov    %rax,0x30(%r12)
   860d3:	f3 0f 6f 44 24 60    	movdqu 0x60(%rsp),%xmm0
   860d9:	0f 10 4c 24 70       	movups 0x70(%rsp),%xmm1
   860de:	0f 10 94 24 80 00 00 	movups 0x80(%rsp),%xmm2
   860e5:	00 
   860e6:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
   860ec:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
   860f2:	f3 41 0f 7f 04 24    	movdqu %xmm0,(%r12)
   860f8:	e9 c4 00 00 00       	jmp    861c1 <<oriole::Parser>::next_event_scoped+0x2f1>
   860fd:	49 8b 8f 78 08 00 00 	mov    0x878(%r15),%rcx
   86104:	0f b6 49 28          	movzbl 0x28(%rcx),%ecx
   86108:	84 c9                	test   %cl,%cl
   8610a:	0f 84 26 fe ff ff    	je     85f36 <<oriole::Parser>::next_event_scoped+0x66>
   86110:	41 80 bf be 08 00 00 	cmpb   $0x1,0x8be(%r15)
   86117:	01 
   86118:	0f 84 21 fe ff ff    	je     85f3f <<oriole::Parser>::next_event_scoped+0x6f>
   8611e:	49 c7 87 20 05 00 00 	movq   $0x0,0x520(%r15)
   86125:	00 00 00 00 
   86129:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
   86130:	00 
   86131:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
   86138:	00 
   86139:	0f 11 8c 24 10 03 00 	movups %xmm1,0x310(%rsp)
   86140:	00 
   86141:	0f 11 84 24 00 03 00 	movups %xmm0,0x300(%rsp)
   86148:	00 
   86149:	41 0f 11 8f a0 08 00 	movups %xmm1,0x8a0(%r15)
   86150:	00 
   86151:	41 0f 11 87 90 08 00 	movups %xmm0,0x890(%r15)
   86158:	00 
   86159:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
   8615e:	41 83 3e ff          	cmpl   $0xffffffff,(%r14)
   86162:	74 08                	je     8616c <<oriole::Parser>::next_event_scoped+0x29c>
   86164:	4c 89 f7             	mov    %r14,%rdi
   86167:	e8 e4 2c fc ff       	call   48e50 <core::ptr::drop_glue::<oriole::EventKind>>
   8616c:	49 c7 06 16 00 00 00 	movq   $0x16,(%r14)
   86173:	49 83 c6 08          	add    $0x8,%r14
   86177:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
   8617e:	00 
   8617f:	ba 90 00 00 00       	mov    $0x90,%edx
   86184:	4c 89 f7             	mov    %r14,%rdi
   86187:	e9 ab 00 00 00       	jmp    86237 <<oriole::Parser>::next_event_scoped+0x367>
   8618c:	49 c7 87 20 05 00 00 	movq   $0x0,0x520(%r15)
   86193:	00 00 00 00 
   86197:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   8619e:	00 
   8619f:	48 85 c9             	test   %rcx,%rcx
   861a2:	74 1d                	je     861c1 <<oriole::Parser>::next_event_scoped+0x2f1>
   861a4:	31 ed                	xor    %ebp,%ebp
   861a6:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   861ad:	00 
   861ae:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   861b5:	00 
   861b6:	ba 01 00 00 00       	mov    $0x1,%edx
   861bb:	ff 15 ef 06 06 00    	call   *0x606ef(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   861c1:	48 89 dd             	mov    %rbx,%rbp
   861c4:	4c 8b b4 24 98 00 00 	mov    0x98(%rsp),%r14
   861cb:	00 
   861cc:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   861d3:	00 
   861d4:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
   861db:	00 
   861dc:	ba 90 00 00 00       	mov    $0x90,%edx
   861e1:	ff 15 b1 0f 06 00    	call   *0x60fb1(%rip)        # e7198 <memcpy@GLIBC_2.14>
   861e7:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
   861eb:	74 59                	je     86246 <<oriole::Parser>::next_event_scoped+0x376>
   861ed:	0f 10 84 24 70 02 00 	movups 0x270(%rsp),%xmm0
   861f4:	00 
   861f5:	0f 10 8c 24 80 02 00 	movups 0x280(%rsp),%xmm1
   861fc:	00 
   861fd:	41 0f 11 8f a0 08 00 	movups %xmm1,0x8a0(%r15)
   86204:	00 
   86205:	41 0f 11 87 90 08 00 	movups %xmm0,0x890(%r15)
   8620c:	00 
   8620d:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   86212:	41 83 3f ff          	cmpl   $0xffffffff,(%r15)
   86216:	74 08                	je     86220 <<oriole::Parser>::next_event_scoped+0x350>
   86218:	4c 89 ff             	mov    %r15,%rdi
   8621b:	e8 30 2c fc ff       	call   48e50 <core::ptr::drop_glue::<oriole::EventKind>>
   86220:	4d 89 37             	mov    %r14,(%r15)
   86223:	49 83 c7 08          	add    $0x8,%r15
   86227:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
   8622e:	00 
   8622f:	ba 90 00 00 00       	mov    $0x90,%edx
   86234:	4c 89 ff             	mov    %r15,%rdi
   86237:	ff 15 5b 0f 06 00    	call   *0x60f5b(%rip)        # e7198 <memcpy@GLIBC_2.14>
   8623d:	c6 45 30 ff          	movb   $0xff,0x30(%rbp)
   86241:	e9 47 05 00 00       	jmp    8678d <<oriole::Parser>::next_event_scoped+0x8bd>
   86246:	4d 8d af 10 08 00 00 	lea    0x810(%r15),%r13
   8624d:	41 80 bf 40 08 00 00 	cmpb   $0xff,0x840(%r15)
   86254:	ff 
   86255:	74 1c                	je     86273 <<oriole::Parser>::next_event_scoped+0x3a3>
   86257:	49 8b 45 30          	mov    0x30(%r13),%rax
   8625b:	48 89 45 30          	mov    %rax,0x30(%rbp)
   8625f:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
   86264:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
   86269:	41 0f 10 55 20       	movups 0x20(%r13),%xmm2
   8626e:	e9 0e 05 00 00       	jmp    86781 <<oriole::Parser>::next_event_scoped+0x8b1>
   86273:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   86278:	4c 89 fe             	mov    %r15,%rsi
   8627b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   86280:	e8 0b b3 ff ff       	call   81590 <<oriole::Parser>::next_event_inner>
   86285:	0f b6 4c 24 48       	movzbl 0x48(%rsp),%ecx
   8628a:	81 f9 ff 00 00 00    	cmp    $0xff,%ecx
   86290:	0f 84 d8 00 00 00    	je     8636e <<oriole::Parser>::next_event_scoped+0x49e>
   86296:	45 0f b6 b7 f8 07 00 	movzbl 0x7f8(%r15),%r14d
   8629d:	00 
   8629e:	41 80 fe ff          	cmp    $0xff,%r14b
   862a2:	0f 84 c6 00 00 00    	je     8636e <<oriole::Parser>::next_event_scoped+0x49e>
   862a8:	83 f9 13             	cmp    $0x13,%ecx
   862ab:	0f 87 c6 00 00 00    	ja     86377 <<oriole::Parser>::next_event_scoped+0x4a7>
   862b1:	b8 14 20 08 00       	mov    $0x82014,%eax
   862b6:	0f a3 c8             	bt     %ecx,%eax
   862b9:	0f 83 b8 00 00 00    	jae    86377 <<oriole::Parser>::next_event_scoped+0x4a7>
   862bf:	49 83 bf 90 01 00 00 	cmpq   $0x0,0x190(%r15)
   862c6:	00 
   862c7:	0f 84 1c 05 00 00    	je     867e9 <<oriole::Parser>::next_event_scoped+0x919>
   862cd:	49 8b b7 80 01 00 00 	mov    0x180(%r15),%rsi
   862d4:	41 80 fe 04          	cmp    $0x4,%r14b
   862d8:	0f 94 c0             	sete   %al
   862db:	41 84 87 b7 08 00 00 	test   %al,0x8b7(%r15)
   862e2:	74 11                	je     862f5 <<oriole::Parser>::next_event_scoped+0x425>
   862e4:	bb 16 00 00 00       	mov    $0x16,%ebx
   862e9:	4c 8d 25 77 c5 f8 ff 	lea    -0x73a89(%rip),%r12        # 12867 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5ecb>
   862f0:	41 b6 13             	mov    $0x13,%r14b
   862f3:	eb 3e                	jmp    86333 <<oriole::Parser>::next_event_scoped+0x463>
   862f5:	4d 8b a7 00 08 00 00 	mov    0x800(%r15),%r12
   862fc:	49 8b 9f 08 08 00 00 	mov    0x808(%r15),%rbx
   86303:	41 8d 46 ef          	lea    -0x11(%r14),%eax
   86307:	3c 02                	cmp    $0x2,%al
   86309:	73 28                	jae    86333 <<oriole::Parser>::next_event_scoped+0x463>
   8630b:	49 83 3f 01          	cmpq   $0x1,(%r15)
   8630f:	0f 85 73 03 00 00    	jne    86688 <<oriole::Parser>::next_event_scoped+0x7b8>
   86315:	f3 41 0f 6f 47 08    	movdqu 0x8(%r15),%xmm0
   8631b:	41 0f 10 4f 18       	movups 0x18(%r15),%xmm1
   86320:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
   86327:	00 
   86328:	66 0f 7f 84 24 30 01 	movdqa %xmm0,0x130(%rsp)
   8632f:	00 00 
   86331:	eb 0d                	jmp    86340 <<oriole::Parser>::next_event_scoped+0x470>
   86333:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   8633a:	00 
   8633b:	e8 d0 89 fe ff       	call   6ed10 <<oriole::encoding::Source>::end_position>
   86340:	66 0f 6f 84 24 30 01 	movdqa 0x130(%rsp),%xmm0
   86347:	00 00 
   86349:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
   86350:	00 
   86351:	0f 11 4c 24 38       	movups %xmm1,0x38(%rsp)
   86356:	f3 0f 7f 44 24 28    	movdqu %xmm0,0x28(%rsp)
   8635c:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   86361:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   86366:	44 88 74 24 48       	mov    %r14b,0x48(%rsp)
   8636b:	44 89 f1             	mov    %r14d,%ecx
   8636e:	80 f9 ff             	cmp    $0xff,%cl
   86371:	0f 84 bd 03 00 00    	je     86734 <<oriole::Parser>::next_event_scoped+0x864>
   86377:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   8637c:	49 89 45 30          	mov    %rax,0x30(%r13)
   86380:	f3 0f 6f 44 24 18    	movdqu 0x18(%rsp),%xmm0
   86386:	0f 10 4c 24 28       	movups 0x28(%rsp),%xmm1
   8638b:	0f 10 54 24 38       	movups 0x38(%rsp),%xmm2
   86390:	41 0f 11 55 20       	movups %xmm2,0x20(%r13)
   86395:	41 0f 11 4d 10       	movups %xmm1,0x10(%r13)
   8639a:	f3 41 0f 7f 45 00    	movdqu %xmm0,0x0(%r13)
   863a0:	84 c9                	test   %cl,%cl
   863a2:	74 0e                	je     863b2 <<oriole::Parser>::next_event_scoped+0x4e2>
   863a4:	41 80 bf f8 07 00 00 	cmpb   $0x11,0x7f8(%r15)
   863ab:	11 
   863ac:	0f 84 08 01 00 00    	je     864ba <<oriole::Parser>::next_event_scoped+0x5ea>
   863b2:	4d 8b a7 c8 04 00 00 	mov    0x4c8(%r15),%r12
   863b9:	4d 85 e4             	test   %r12,%r12
   863bc:	0f 84 f0 00 00 00    	je     864b2 <<oriole::Parser>::next_event_scoped+0x5e2>
   863c2:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   863c6:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
   863cb:	49 8b 9f b0 04 00 00 	mov    0x4b0(%r15),%rbx
   863d2:	66 0f 6f 03          	movdqa (%rbx),%xmm0
   863d6:	4c 8d 73 10          	lea    0x10(%rbx),%r14
   863da:	66 0f d7 e8          	pmovmskb %xmm0,%ebp
   863de:	f7 d5                	not    %ebp
   863e0:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   863e5:	eb 15                	jmp    863fc <<oriole::Parser>::next_event_scoped+0x52c>
   863e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   863ee:	00 00 
   863f0:	8d 45 ff             	lea    -0x1(%rbp),%eax
   863f3:	21 e8                	and    %ebp,%eax
   863f5:	89 c5                	mov    %eax,%ebp
   863f7:	49 ff cc             	dec    %r12
   863fa:	74 5d                	je     86459 <<oriole::Parser>::next_event_scoped+0x589>
   863fc:	66 85 ed             	test   %bp,%bp
   863ff:	75 2b                	jne    8642c <<oriole::Parser>::next_event_scoped+0x55c>
   86401:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   86408:	0f 1f 84 00 00 00 00 
   8640f:	00 
   86410:	66 41 0f 6f 06       	movdqa (%r14),%xmm0
   86415:	48 81 c3 80 fa ff ff 	add    $0xfffffffffffffa80,%rbx
   8641c:	49 83 c6 10          	add    $0x10,%r14
   86420:	66 0f d7 e8          	pmovmskb %xmm0,%ebp
   86424:	81 f5 ff ff 00 00    	xor    $0xffff,%ebp
   8642a:	74 e4                	je     86410 <<oriole::Parser>::next_event_scoped+0x540>
   8642c:	f3 0f bc c5          	tzcnt  %ebp,%eax
   86430:	48 f7 d8             	neg    %rax
   86433:	48 6b f8 58          	imul   $0x58,%rax,%rdi
   86437:	48 8b 4c 3b d0       	mov    -0x30(%rbx,%rdi,1),%rcx
   8643c:	48 85 c9             	test   %rcx,%rcx
   8643f:	74 af                	je     863f0 <<oriole::Parser>::next_event_scoped+0x520>
   86441:	48 01 df             	add    %rbx,%rdi
   86444:	48 8b 77 c8          	mov    -0x38(%rdi),%rsi
   86448:	48 83 c7 a8          	add    $0xffffffffffffffa8,%rdi
   8644c:	ba 01 00 00 00       	mov    $0x1,%edx
   86451:	ff 15 59 04 06 00    	call   *0x60459(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   86457:	eb 97                	jmp    863f0 <<oriole::Parser>::next_event_scoped+0x520>
   86459:	49 8b 9f b8 04 00 00 	mov    0x4b8(%r15),%rbx
   86460:	48 85 db             	test   %rbx,%rbx
   86463:	74 30                	je     86495 <<oriole::Parser>::next_event_scoped+0x5c5>
   86465:	48 8d 53 11          	lea    0x11(%rbx),%rdx
   86469:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
   8646e:	be ff 00 00 00       	mov    $0xff,%esi
   86473:	ff 15 07 0d 06 00    	call   *0x60d07(%rip)        # e7180 <memset@GLIBC_2.2.5>
   86479:	48 8d 43 01          	lea    0x1(%rbx),%rax
   8647d:	48 89 c1             	mov    %rax,%rcx
   86480:	48 c1 e9 03          	shr    $0x3,%rcx
   86484:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
   86488:	48 29 c8             	sub    %rcx,%rax
   8648b:	48 83 fb 08          	cmp    $0x8,%rbx
   8648f:	48 0f 42 c3          	cmovb  %rbx,%rax
   86493:	eb 02                	jmp    86497 <<oriole::Parser>::next_event_scoped+0x5c7>
   86495:	31 c0                	xor    %eax,%eax
   86497:	48 8b 6c 24 58       	mov    0x58(%rsp),%rbp
   8649c:	8b 4c 24 14          	mov    0x14(%rsp),%ecx
   864a0:	49 c7 87 c8 04 00 00 	movq   $0x0,0x4c8(%r15)
   864a7:	00 00 00 00 
   864ab:	49 89 87 c0 04 00 00 	mov    %rax,0x4c0(%r15)
   864b2:	84 c9                	test   %cl,%cl
   864b4:	0f 84 94 00 00 00    	je     8654e <<oriole::Parser>::next_event_scoped+0x67e>
   864ba:	48 8d 54 24 18       	lea    0x18(%rsp),%rdx
   864bf:	48 89 ef             	mov    %rbp,%rdi
   864c2:	4c 89 fe             	mov    %r15,%rsi
   864c5:	e8 c6 c3 fc ff       	call   52890 <<oriole::Parser>::next_event_scoped::{closure#2}>
   864ca:	80 7d 30 ff          	cmpb   $0xff,0x30(%rbp)
   864ce:	74 51                	je     86521 <<oriole::Parser>::next_event_scoped+0x651>
   864d0:	48 8b 45 30          	mov    0x30(%rbp),%rax
   864d4:	49 89 45 30          	mov    %rax,0x30(%r13)
   864d8:	0f 10 45 00          	movups 0x0(%rbp),%xmm0
   864dc:	0f 10 4d 10          	movups 0x10(%rbp),%xmm1
   864e0:	0f 10 55 20          	movups 0x20(%rbp),%xmm2
   864e4:	41 0f 11 55 20       	movups %xmm2,0x20(%r13)
   864e9:	41 0f 11 4d 10       	movups %xmm1,0x10(%r13)
   864ee:	41 0f 11 45 00       	movups %xmm0,0x0(%r13)
   864f3:	49 8b bf b8 01 00 00 	mov    0x1b8(%r15),%rdi
   864fa:	49 8b b7 c8 01 00 00 	mov    0x1c8(%r15),%rsi
   86501:	49 c7 87 c8 01 00 00 	movq   $0x0,0x1c8(%r15)
   86508:	00 00 00 00 
   8650c:	e8 7f 3b fc ff       	call   4a090 <core::ptr::drop_glue::<[core::option::Option<oriole::PendingEvent>]>>
   86511:	49 c7 87 d0 01 00 00 	movq   $0x0,0x1d0(%r15)
   86518:	00 00 00 00 
   8651c:	e9 6c 02 00 00       	jmp    8678d <<oriole::Parser>::next_event_scoped+0x8bd>
   86521:	49 8d b7 98 01 00 00 	lea    0x198(%r15),%rsi
   86528:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   8652f:	00 
   86530:	e8 6b 13 fd ff       	call   578a0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::pop_front>
   86535:	83 bc 24 30 01 00 00 	cmpl   $0xfffffffe,0x130(%rsp)
   8653c:	fe 
   8653d:	75 3d                	jne    8657c <<oriole::Parser>::next_event_scoped+0x6ac>
   8653f:	b0 01                	mov    $0x1,%al
   86541:	84 c0                	test   %al,%al
   86543:	0f 84 f1 01 00 00    	je     8673a <<oriole::Parser>::next_event_scoped+0x86a>
   86549:	e9 1b 02 00 00       	jmp    86769 <<oriole::Parser>::next_event_scoped+0x899>
   8654e:	49 8b bf b8 01 00 00 	mov    0x1b8(%r15),%rdi
   86555:	49 8b b7 c8 01 00 00 	mov    0x1c8(%r15),%rsi
   8655c:	49 c7 87 c8 01 00 00 	movq   $0x0,0x1c8(%r15)
   86563:	00 00 00 00 
   86567:	e8 24 3b fc ff       	call   4a090 <core::ptr::drop_glue::<[core::option::Option<oriole::PendingEvent>]>>
   8656c:	49 c7 87 d0 01 00 00 	movq   $0x0,0x1d0(%r15)
   86573:	00 00 00 00 
   86577:	e9 ed 01 00 00       	jmp    86769 <<oriole::Parser>::next_event_scoped+0x899>
   8657c:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   86581:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
   86588:	00 
   86589:	ba d0 00 00 00       	mov    $0xd0,%edx
   8658e:	ff 15 04 0c 06 00    	call   *0x60c04(%rip)        # e7198 <memcpy@GLIBC_2.14>
   86594:	83 bc 24 98 00 00 00 	cmpl   $0x12,0x98(%rsp)
   8659b:	12 
   8659c:	75 3f                	jne    865dd <<oriole::Parser>::next_event_scoped+0x70d>
   8659e:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
   865a5:	00 
   865a6:	83 38 ff             	cmpl   $0xffffffff,(%rax)
   865a9:	75 32                	jne    865dd <<oriole::Parser>::next_event_scoped+0x70d>
   865ab:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   865af:	75 2c                	jne    865dd <<oriole::Parser>::next_event_scoped+0x70d>
   865b1:	41 80 bf f1 07 00 00 	cmpb   $0x2,0x7f1(%r15)
   865b8:	02 
   865b9:	74 22                	je     865dd <<oriole::Parser>::next_event_scoped+0x70d>
   865bb:	41 c6 87 f1 07 00 00 	movb   $0x1,0x7f1(%r15)
   865c2:	01 
   865c3:	41 8b 87 80 08 00 00 	mov    0x880(%r15),%eax
   865ca:	85 c0                	test   %eax,%eax
   865cc:	0f 85 f9 01 00 00    	jne    867cb <<oriole::Parser>::next_event_scoped+0x8fb>
   865d2:	49 8b 87 78 08 00 00 	mov    0x878(%r15),%rax
   865d9:	c6 40 28 00          	movb   $0x0,0x28(%rax)
   865dd:	83 7c 24 60 ff       	cmpl   $0xffffffff,0x60(%rsp)
   865e2:	0f 84 ea 00 00 00    	je     866d2 <<oriole::Parser>::next_event_scoped+0x802>
   865e8:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   865ef:	00 
   865f0:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   865f7:	00 
   865f8:	f3 0f 6f 44 24 60    	movdqu 0x60(%rsp),%xmm0
   865fe:	0f 10 4c 24 70       	movups 0x70(%rsp),%xmm1
   86603:	0f 10 94 24 80 00 00 	movups 0x80(%rsp),%xmm2
   8660a:	00 
   8660b:	0f 29 94 24 50 01 00 	movaps %xmm2,0x150(%rsp)
   86612:	00 
   86613:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
   8661a:	00 
   8661b:	66 0f 7f 84 24 30 01 	movdqa %xmm0,0x130(%rsp)
   86622:	00 00 
   86624:	48 89 eb             	mov    %rbp,%rbx
   86627:	48 85 c0             	test   %rax,%rax
   8662a:	74 6e                	je     8669a <<oriole::Parser>::next_event_scoped+0x7ca>
   8662c:	4d 8d a7 f0 04 00 00 	lea    0x4f0(%r15),%r12
   86633:	49 8b 8f 18 05 00 00 	mov    0x518(%r15),%rcx
   8663a:	48 85 c9             	test   %rcx,%rcx
   8663d:	74 15                	je     86654 <<oriole::Parser>::next_event_scoped+0x784>
   8663f:	49 8b b7 10 05 00 00 	mov    0x510(%r15),%rsi
   86646:	ba 01 00 00 00       	mov    $0x1,%edx
   8664b:	4c 89 e7             	mov    %r12,%rdi
   8664e:	ff 15 5c 02 06 00    	call   *0x6025c(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   86654:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   8665b:	00 
   8665c:	49 89 44 24 30       	mov    %rax,0x30(%r12)
   86661:	f3 0f 6f 44 24 60    	movdqu 0x60(%rsp),%xmm0
   86667:	0f 10 4c 24 70       	movups 0x70(%rsp),%xmm1
   8666c:	0f 10 94 24 80 00 00 	movups 0x80(%rsp),%xmm2
   86673:	00 
   86674:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
   8667a:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
   86680:	f3 41 0f 7f 04 24    	movdqu %xmm0,(%r12)
   86686:	eb 47                	jmp    866cf <<oriole::Parser>::next_event_scoped+0x7ff>
   86688:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   8668f:	00 
   86690:	e8 8b c1 fc ff       	call   52820 <<oriole::Parser>::next_event_scoped::{closure#0}>
   86695:	e9 a6 fc ff ff       	jmp    86340 <<oriole::Parser>::next_event_scoped+0x470>
   8669a:	49 c7 87 20 05 00 00 	movq   $0x0,0x520(%r15)
   866a1:	00 00 00 00 
   866a5:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   866ac:	00 
   866ad:	48 85 c9             	test   %rcx,%rcx
   866b0:	74 1d                	je     866cf <<oriole::Parser>::next_event_scoped+0x7ff>
   866b2:	31 ed                	xor    %ebp,%ebp
   866b4:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   866bb:	00 
   866bc:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   866c3:	00 
   866c4:	ba 01 00 00 00       	mov    $0x1,%edx
   866c9:	ff 15 e1 01 06 00    	call   *0x601e1(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   866cf:	48 89 dd             	mov    %rbx,%rbp
   866d2:	4c 8b b4 24 98 00 00 	mov    0x98(%rsp),%r14
   866d9:	00 
   866da:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   866e1:	00 
   866e2:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   866e9:	00 
   866ea:	ba 90 00 00 00       	mov    $0x90,%edx
   866ef:	ff 15 a3 0a 06 00    	call   *0x60aa3(%rip)        # e7198 <memcpy@GLIBC_2.14>
   866f5:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
   866f9:	0f 84 a0 00 00 00    	je     8679f <<oriole::Parser>::next_event_scoped+0x8cf>
   866ff:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
   86704:	41 83 3c 24 ff       	cmpl   $0xffffffff,(%r12)
   86709:	74 08                	je     86713 <<oriole::Parser>::next_event_scoped+0x843>
   8670b:	4c 89 e7             	mov    %r12,%rdi
   8670e:	e8 3d 27 fc ff       	call   48e50 <core::ptr::drop_glue::<oriole::EventKind>>
   86713:	4d 89 34 24          	mov    %r14,(%r12)
   86717:	49 8d 7c 24 08       	lea    0x8(%r12),%rdi
   8671c:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
   86723:	00 
   86724:	ba 90 00 00 00       	mov    $0x90,%edx
   86729:	ff 15 69 0a 06 00    	call   *0x60a69(%rip)        # e7198 <memcpy@GLIBC_2.14>
   8672f:	c6 44 24 48 ff       	movb   $0xff,0x48(%rsp)
   86734:	31 c0                	xor    %eax,%eax
   86736:	84 c0                	test   %al,%al
   86738:	75 2f                	jne    86769 <<oriole::Parser>::next_event_scoped+0x899>
   8673a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   8673f:	48 8b 00             	mov    (%rax),%rax
   86742:	83 f8 ff             	cmp    $0xffffffff,%eax
   86745:	74 22                	je     86769 <<oriole::Parser>::next_event_scoped+0x899>
   86747:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   8674c:	f3 0f 6f 40 78       	movdqu 0x78(%rax),%xmm0
   86751:	0f 10 88 88 00 00 00 	movups 0x88(%rax),%xmm1
   86758:	41 0f 11 8f a0 08 00 	movups %xmm1,0x8a0(%r15)
   8675f:	00 
   86760:	f3 41 0f 7f 87 90 08 	movdqu %xmm0,0x890(%r15)
   86767:	00 00 
   86769:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   8676e:	48 89 45 30          	mov    %rax,0x30(%rbp)
   86772:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
   86777:	0f 10 4c 24 28       	movups 0x28(%rsp),%xmm1
   8677c:	0f 10 54 24 38       	movups 0x38(%rsp),%xmm2
   86781:	0f 11 55 20          	movups %xmm2,0x20(%rbp)
   86785:	0f 11 4d 10          	movups %xmm1,0x10(%rbp)
   86789:	0f 11 45 00          	movups %xmm0,0x0(%rbp)
   8678d:	48 81 c4 e8 03 00 00 	add    $0x3e8,%rsp
   86794:	5b                   	pop    %rbx
   86795:	41 5c                	pop    %r12
   86797:	41 5d                	pop    %r13
   86799:	41 5e                	pop    %r14
   8679b:	41 5f                	pop    %r15
   8679d:	5d                   	pop    %rbp
   8679e:	c3                   	ret
   8679f:	80 7c 24 48 ff       	cmpb   $0xff,0x48(%rsp)
   867a4:	0f 95 c0             	setne  %al
   867a7:	84 c0                	test   %al,%al
   867a9:	74 8f                	je     8673a <<oriole::Parser>::next_event_scoped+0x86a>
   867ab:	eb bc                	jmp    86769 <<oriole::Parser>::next_event_scoped+0x899>
   867ad:	40 b5 01             	mov    $0x1,%bpl
   867b0:	48 8d 3d 23 c5 f8 ff 	lea    -0x73add(%rip),%rdi        # 12cda <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x633e>
   867b7:	48 8d 15 1a db 05 00 	lea    0x5db1a(%rip),%rdx        # e42d8 <oriole_expat::FEATURES+0x16f0>
   867be:	be 17 00 00 00       	mov    $0x17,%esi
   867c3:	ff 15 0f 07 06 00    	call   *0x6070f(%rip)        # e6ed8 <_GLOBAL_OFFSET_TABLE_+0x760>
   867c9:	eb 1c                	jmp    867e7 <<oriole::Parser>::next_event_scoped+0x917>
   867cb:	40 b5 01             	mov    $0x1,%bpl
   867ce:	48 8d 3d 05 c5 f8 ff 	lea    -0x73afb(%rip),%rdi        # 12cda <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x633e>
   867d5:	48 8d 15 fc da 05 00 	lea    0x5dafc(%rip),%rdx        # e42d8 <oriole_expat::FEATURES+0x16f0>
   867dc:	be 17 00 00 00       	mov    $0x17,%esi
   867e1:	ff 15 f1 06 06 00    	call   *0x606f1(%rip)        # e6ed8 <_GLOBAL_OFFSET_TABLE_+0x760>
   867e7:	0f 0b                	ud2
   867e9:	48 8d 15 50 d9 05 00 	lea    0x5d950(%rip),%rdx        # e4140 <oriole_expat::FEATURES+0x1558>
   867f0:	31 ff                	xor    %edi,%edi
   867f2:	31 f6                	xor    %esi,%esi
   867f4:	ff 15 2e 06 06 00    	call   *0x6062e(%rip)        # e6e28 <_GLOBAL_OFFSET_TABLE_+0x6b0>
   867fa:	48 89 c3             	mov    %rax,%rbx
   867fd:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   86804:	00 
   86805:	49 89 44 24 30       	mov    %rax,0x30(%r12)
   8680a:	f3 0f 6f 44 24 60    	movdqu 0x60(%rsp),%xmm0
   86810:	0f 10 4c 24 70       	movups 0x70(%rsp),%xmm1
   86815:	0f 10 94 24 80 00 00 	movups 0x80(%rsp),%xmm2
   8681c:	00 
   8681d:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
   86823:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
   86829:	f3 41 0f 7f 04 24    	movdqu %xmm0,(%r12)
   8682f:	31 ed                	xor    %ebp,%ebp
   86831:	e9 4a 01 00 00       	jmp    86980 <<oriole::Parser>::next_event_scoped+0xab0>
   86836:	48 89 c3             	mov    %rax,%rbx
   86839:	4d 89 34 24          	mov    %r14,(%r12)
   8683d:	49 83 c4 08          	add    $0x8,%r12
   86841:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
   86848:	00 
   86849:	ba 90 00 00 00       	mov    $0x90,%edx
   8684e:	4c 89 e7             	mov    %r12,%rdi
   86851:	ff 15 41 09 06 00    	call   *0x60941(%rip)        # e7198 <memcpy@GLIBC_2.14>
   86857:	48 89 df             	mov    %rbx,%rdi
   8685a:	e8 41 63 fa ff       	call   2cba0 <_Unwind_Resume@plt>
   8685f:	48 89 c3             	mov    %rax,%rbx
   86862:	49 c7 06 16 00 00 00 	movq   $0x16,(%r14)
   86869:	49 83 c6 08          	add    $0x8,%r14
   8686d:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
   86874:	00 
   86875:	ba 90 00 00 00       	mov    $0x90,%edx
   8687a:	4c 89 f7             	mov    %r14,%rdi
   8687d:	ff 15 15 09 06 00    	call   *0x60915(%rip)        # e7198 <memcpy@GLIBC_2.14>
   86883:	48 89 df             	mov    %rbx,%rdi
   86886:	e8 15 63 fa ff       	call   2cba0 <_Unwind_Resume@plt>
   8688b:	48 89 c3             	mov    %rax,%rbx
   8688e:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   86895:	00 
   86896:	49 89 44 24 30       	mov    %rax,0x30(%r12)
   8689b:	f3 0f 6f 44 24 60    	movdqu 0x60(%rsp),%xmm0
   868a1:	0f 10 4c 24 70       	movups 0x70(%rsp),%xmm1
   868a6:	0f 10 94 24 80 00 00 	movups 0x80(%rsp),%xmm2
   868ad:	00 
   868ae:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
   868b4:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
   868ba:	f3 41 0f 7f 04 24    	movdqu %xmm0,(%r12)
   868c0:	31 ed                	xor    %ebp,%ebp
   868c2:	e9 07 01 00 00       	jmp    869ce <<oriole::Parser>::next_event_scoped+0xafe>
   868c7:	48 89 c3             	mov    %rax,%rbx
   868ca:	4d 89 37             	mov    %r14,(%r15)
   868cd:	49 83 c7 08          	add    $0x8,%r15
   868d1:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
   868d8:	00 
   868d9:	ba 90 00 00 00       	mov    $0x90,%edx
   868de:	4c 89 ff             	mov    %r15,%rdi
   868e1:	ff 15 b1 08 06 00    	call   *0x608b1(%rip)        # e7198 <memcpy@GLIBC_2.14>
   868e7:	48 89 df             	mov    %rbx,%rdi
   868ea:	e8 b1 62 fa ff       	call   2cba0 <_Unwind_Resume@plt>
   868ef:	48 89 c3             	mov    %rax,%rbx
   868f2:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   868f9:	00 
   868fa:	e8 d1 f5 fb ff       	call   45ed0 <core::ptr::drop_glue::<core::option::Option<oriole::PendingEvent>>>
   868ff:	e9 0d 01 00 00       	jmp    86a11 <<oriole::Parser>::next_event_scoped+0xb41>
   86904:	ff 15 ee 05 06 00    	call   *0x605ee(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   8690a:	48 89 c3             	mov    %rax,%rbx
   8690d:	4d 8b b7 b8 04 00 00 	mov    0x4b8(%r15),%r14
   86914:	4d 85 f6             	test   %r14,%r14
   86917:	75 1c                	jne    86935 <<oriole::Parser>::next_event_scoped+0xa65>
   86919:	31 c0                	xor    %eax,%eax
   8691b:	49 c7 87 c8 04 00 00 	movq   $0x0,0x4c8(%r15)
   86922:	00 00 00 00 
   86926:	49 89 87 c0 04 00 00 	mov    %rax,0x4c0(%r15)
   8692d:	48 89 df             	mov    %rbx,%rdi
   86930:	e8 6b 62 fa ff       	call   2cba0 <_Unwind_Resume@plt>
   86935:	49 8d 56 11          	lea    0x11(%r14),%rdx
   86939:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
   8693e:	be ff 00 00 00       	mov    $0xff,%esi
   86943:	ff 15 37 08 06 00    	call   *0x60837(%rip)        # e7180 <memset@GLIBC_2.2.5>
   86949:	49 8d 46 01          	lea    0x1(%r14),%rax
   8694d:	48 89 c1             	mov    %rax,%rcx
   86950:	48 c1 e9 03          	shr    $0x3,%rcx
   86954:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
   86958:	48 29 c8             	sub    %rcx,%rax
   8695b:	49 83 fe 08          	cmp    $0x8,%r14
   8695f:	49 0f 42 c6          	cmovb  %r14,%rax
   86963:	49 c7 87 c8 04 00 00 	movq   $0x0,0x4c8(%r15)
   8696a:	00 00 00 00 
   8696e:	49 89 87 c0 04 00 00 	mov    %rax,0x4c0(%r15)
   86975:	48 89 df             	mov    %rbx,%rdi
   86978:	e8 23 62 fa ff       	call   2cba0 <_Unwind_Resume@plt>
   8697d:	48 89 c3             	mov    %rax,%rbx
   86980:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   86987:	00 
   86988:	e8 c3 24 fc ff       	call   48e50 <core::ptr::drop_glue::<oriole::EventKind>>
   8698d:	83 7c 24 60 ff       	cmpl   $0xffffffff,0x60(%rsp)
   86992:	0f 94 c0             	sete   %al
   86995:	40 80 f5 01          	xor    $0x1,%bpl
   86999:	40 08 c5             	or     %al,%bpl
   8699c:	75 73                	jne    86a11 <<oriole::Parser>::next_event_scoped+0xb41>
   8699e:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   869a5:	00 
   869a6:	48 85 c9             	test   %rcx,%rcx
   869a9:	74 66                	je     86a11 <<oriole::Parser>::next_event_scoped+0xb41>
   869ab:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   869b2:	00 
   869b3:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   869b8:	ba 01 00 00 00       	mov    $0x1,%edx
   869bd:	ff 15 ed fe 05 00    	call   *0x5feed(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   869c3:	eb 4c                	jmp    86a11 <<oriole::Parser>::next_event_scoped+0xb41>
   869c5:	ff 15 2d 05 06 00    	call   *0x6052d(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   869cb:	48 89 c3             	mov    %rax,%rbx
   869ce:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   869d5:	00 
   869d6:	e8 75 24 fc ff       	call   48e50 <core::ptr::drop_glue::<oriole::EventKind>>
   869db:	83 7c 24 60 ff       	cmpl   $0xffffffff,0x60(%rsp)
   869e0:	0f 94 c0             	sete   %al
   869e3:	40 80 f5 01          	xor    $0x1,%bpl
   869e7:	40 08 c5             	or     %al,%bpl
   869ea:	75 25                	jne    86a11 <<oriole::Parser>::next_event_scoped+0xb41>
   869ec:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   869f3:	00 
   869f4:	48 85 c9             	test   %rcx,%rcx
   869f7:	74 18                	je     86a11 <<oriole::Parser>::next_event_scoped+0xb41>
   869f9:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   86a00:	00 
   86a01:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   86a06:	ba 01 00 00 00       	mov    $0x1,%edx
   86a0b:	ff 15 9f fe 05 00    	call   *0x5fe9f(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   86a11:	48 89 df             	mov    %rbx,%rdi
   86a14:	e8 87 61 fa ff       	call   2cba0 <_Unwind_Resume@plt>
   86a19:	ff 15 d9 04 06 00    	call   *0x604d9(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
