
/tmp/oriole-event-output/control.so:     file format elf64-x86-64


Disassembly of section .text:

00000000000791a0 <<oriole::Parser>::next_event>:
   791a0:	41 57                	push   %r15
   791a2:	41 56                	push   %r14
   791a4:	41 55                	push   %r13
   791a6:	41 54                	push   %r12
   791a8:	53                   	push   %rbx
   791a9:	48 83 ec 50          	sub    $0x50,%rsp
   791ad:	48 89 fb             	mov    %rdi,%rbx
   791b0:	8b 86 58 08 00 00    	mov    0x858(%rsi),%eax
   791b6:	85 c0                	test   %eax,%eax
   791b8:	0f 94 c1             	sete   %cl
   791bb:	0f b6 86 b1 08 00 00 	movzbl 0x8b1(%rsi),%eax
   791c2:	08 c1                	or     %al,%cl
   791c4:	f6 c1 01             	test   $0x1,%cl
   791c7:	0f 84 cb 00 00 00    	je     79298 <<oriole::Parser>::next_event+0xf8>
   791cd:	80 be 40 08 00 00 ff 	cmpb   $0xff,0x840(%rsi)
   791d4:	0f 94 c1             	sete   %cl
   791d7:	84 c1                	test   %al,%cl
   791d9:	0f 84 af 00 00 00    	je     7928e <<oriole::Parser>::next_event+0xee>
   791df:	8b 86 58 08 00 00    	mov    0x858(%rsi),%eax
   791e5:	85 c0                	test   %eax,%eax
   791e7:	0f 84 a1 00 00 00    	je     7928e <<oriole::Parser>::next_event+0xee>
   791ed:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   791f2:	49 89 f6             	mov    %rsi,%r14
   791f5:	e8 26 cc ff ff       	call   75e20 <<oriole::Parser>::ensure_shared_tables>
   791fa:	4c 89 f6             	mov    %r14,%rsi
   791fd:	80 7c 24 38 ff       	cmpb   $0xff,0x38(%rsp)
   79202:	0f 84 86 00 00 00    	je     7928e <<oriole::Parser>::next_event+0xee>
   79208:	48 8d 86 10 08 00 00 	lea    0x810(%rsi),%rax
   7920f:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   79214:	48 89 4b 38          	mov    %rcx,0x38(%rbx)
   79218:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
   7921d:	0f 10 4c 24 18       	movups 0x18(%rsp),%xmm1
   79222:	0f 10 54 24 28       	movups 0x28(%rsp),%xmm2
   79227:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
   7922b:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
   7922f:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
   79233:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   79238:	48 89 48 30          	mov    %rcx,0x30(%rax)
   7923c:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
   79241:	0f 10 4c 24 18       	movups 0x18(%rsp),%xmm1
   79246:	0f 10 54 24 28       	movups 0x28(%rsp),%xmm2
   7924b:	0f 11 50 20          	movups %xmm2,0x20(%rax)
   7924f:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   79253:	0f 11 00             	movups %xmm0,(%rax)
   79256:	48 8b be b8 01 00 00 	mov    0x1b8(%rsi),%rdi
   7925d:	48 8b 86 c8 01 00 00 	mov    0x1c8(%rsi),%rax
   79264:	48 c7 86 c8 01 00 00 	movq   $0x0,0x1c8(%rsi)
   7926b:	00 00 00 00 
   7926f:	49 89 f6             	mov    %rsi,%r14
   79272:	48 89 c6             	mov    %rax,%rsi
   79275:	e8 36 0d fd ff       	call   49fb0 <core::ptr::drop_glue::<[core::option::Option<oriole::PendingEvent>]>>
   7927a:	49 c7 86 d0 01 00 00 	movq   $0x0,0x1d0(%r14)
   79281:	00 00 00 00 
   79285:	48 c7 03 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rbx)
   7928c:	eb 12                	jmp    792a0 <<oriole::Parser>::next_event+0x100>
   7928e:	8b 86 58 08 00 00    	mov    0x858(%rsi),%eax
   79294:	85 c0                	test   %eax,%eax
   79296:	74 19                	je     792b1 <<oriole::Parser>::next_event+0x111>
   79298:	48 89 df             	mov    %rbx,%rdi
   7929b:	e8 a0 cb 00 00       	call   85e40 <<oriole::Parser>::next_event_scoped>
   792a0:	48 89 d8             	mov    %rbx,%rax
   792a3:	48 83 c4 50          	add    $0x50,%rsp
   792a7:	5b                   	pop    %rbx
   792a8:	41 5c                	pop    %r12
   792aa:	41 5d                	pop    %r13
   792ac:	41 5e                	pop    %r14
   792ae:	41 5f                	pop    %r15
   792b0:	c3                   	ret
   792b1:	4c 8b b6 50 08 00 00 	mov    0x850(%rsi),%r14
   792b8:	49 8b 46 20          	mov    0x20(%r14),%rax
   792bc:	48 b9 fe ff ff ff ff 	movabs $0x7ffffffffffffffe,%rcx
   792c3:	ff ff 7f 
   792c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   792cd:	00 00 00 
   792d0:	48 39 c8             	cmp    %rcx,%rax
   792d3:	0f 87 13 01 00 00    	ja     793ec <<oriole::Parser>::next_event+0x24c>
   792d9:	48 8d 50 01          	lea    0x1(%rax),%rdx
   792dd:	f0 49 0f b1 56 20    	lock cmpxchg %rdx,0x20(%r14)
   792e3:	75 eb                	jne    792d0 <<oriole::Parser>::next_event+0x130>
   792e5:	b1 01                	mov    $0x1,%cl
   792e7:	31 c0                	xor    %eax,%eax
   792e9:	f0 41 0f b0 8e 70 01 	lock cmpxchg %cl,0x170(%r14)
   792f0:	00 00 
   792f2:	75 3c                	jne    79330 <<oriole::Parser>::next_event+0x190>
   792f4:	4d 8d 7e 28          	lea    0x28(%r14),%r15
   792f8:	4c 8d a6 70 02 00 00 	lea    0x270(%rsi),%r12
   792ff:	4c 89 e7             	mov    %r12,%rdi
   79302:	49 89 f5             	mov    %rsi,%r13
   79305:	4c 89 fe             	mov    %r15,%rsi
   79308:	e8 13 c4 fc ff       	call   45720 <core::intrinsics::typed_swap_nonoverlapping::<oriole::dtd_tables::DtdTables>>
   7930d:	48 89 df             	mov    %rbx,%rdi
   79310:	4c 89 ee             	mov    %r13,%rsi
   79313:	e8 28 cb 00 00       	call   85e40 <<oriole::Parser>::next_event_scoped>
   79318:	4c 89 e7             	mov    %r12,%rdi
   7931b:	4c 89 fe             	mov    %r15,%rsi
   7931e:	e8 fd c3 fc ff       	call   45720 <core::intrinsics::typed_swap_nonoverlapping::<oriole::dtd_tables::DtdTables>>
   79323:	41 c6 86 70 01 00 00 	movb   $0x0,0x170(%r14)
   7932a:	00 
   7932b:	e9 94 00 00 00       	jmp    793c4 <<oriole::Parser>::next_event+0x224>
   79330:	48 8b 86 90 01 00 00 	mov    0x190(%rsi),%rax
   79337:	48 85 c0             	test   %rax,%rax
   7933a:	0f 84 91 00 00 00    	je     793d1 <<oriole::Parser>::next_event+0x231>
   79340:	48 8b 8e 80 01 00 00 	mov    0x180(%rsi),%rcx
   79347:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   7934b:	48 c1 e2 07          	shl    $0x7,%rdx
   7934f:	48 8d 04 11          	lea    (%rcx,%rdx,1),%rax
   79353:	83 bc 11 80 fe ff ff 	cmpl   $0x1,-0x180(%rcx,%rdx,1)
   7935a:	01 
   7935b:	75 17                	jne    79374 <<oriole::Parser>::next_event+0x1d4>
   7935d:	4c 8b b8 88 fe ff ff 	mov    -0x178(%rax),%r15
   79364:	0f 10 80 90 fe ff ff 	movups -0x170(%rax),%xmm0
   7936b:	48 8b 80 a0 fe ff ff 	mov    -0x160(%rax),%rax
   79372:	eb 26                	jmp    7939a <<oriole::Parser>::next_event+0x1fa>
   79374:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
   79378:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   7937f:	4c 8b 78 a8          	mov    -0x58(%rax),%r15
   79383:	0f 10 40 d8          	movups -0x28(%rax),%xmm0
   79387:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   7938c:	31 f6                	xor    %esi,%esi
   7938e:	31 d2                	xor    %edx,%edx
   79390:	e8 bb 63 ff ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   79395:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   7939a:	48 8d 0d 90 8e f9 ff 	lea    -0x67170(%rip),%rcx        # 12231 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x58a5>
   793a1:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
   793a5:	48 c7 43 10 1c 00 00 	movq   $0x1c,0x10(%rbx)
   793ac:	00 
   793ad:	4c 89 7b 18          	mov    %r15,0x18(%rbx)
   793b1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
   793b5:	48 89 43 30          	mov    %rax,0x30(%rbx)
   793b9:	c6 43 38 10          	movb   $0x10,0x38(%rbx)
   793bd:	48 c7 03 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rbx)
   793c4:	4c 89 f7             	mov    %r14,%rdi
   793c7:	e8 a4 da fc ff       	call   46e70 <core::ptr::drop_glue::<oriole_storage::shared::Shared<oriole_storage::try_lock::TryLock<oriole::dtd_tables::DtdTables>>>>
   793cc:	e9 cf fe ff ff       	jmp    792a0 <<oriole::Parser>::next_event+0x100>
   793d1:	48 8d 3d f2 8f f9 ff 	lea    -0x6700e(%rip),%rdi        # 123ca <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   793d8:	48 8d 15 89 ae 06 00 	lea    0x6ae89(%rip),%rdx        # e4268 <oriole_expat::FEATURES+0x16c0>
   793df:	be 21 00 00 00       	mov    $0x21,%esi
   793e4:	ff 15 a6 da 06 00    	call   *0x6daa6(%rip)        # e6e90 <_GLOBAL_OFFSET_TABLE_+0x758>
   793ea:	0f 0b                	ud2
   793ec:	ff 15 26 d6 06 00    	call   *0x6d626(%rip)        # e6a18 <_GLOBAL_OFFSET_TABLE_+0x2e0>
   793f2:	48 89 c3             	mov    %rax,%rbx
   793f5:	4c 89 e7             	mov    %r12,%rdi
   793f8:	4c 89 fe             	mov    %r15,%rsi
   793fb:	e8 20 c3 fc ff       	call   45720 <core::intrinsics::typed_swap_nonoverlapping::<oriole::dtd_tables::DtdTables>>
   79400:	41 c6 86 70 01 00 00 	movb   $0x0,0x170(%r14)
   79407:	00 
   79408:	eb 03                	jmp    7940d <<oriole::Parser>::next_event+0x26d>
   7940a:	48 89 c3             	mov    %rax,%rbx
   7940d:	4c 89 f7             	mov    %r14,%rdi
   79410:	e8 5b da fc ff       	call   46e70 <core::ptr::drop_glue::<oriole_storage::shared::Shared<oriole_storage::try_lock::TryLock<oriole::dtd_tables::DtdTables>>>>
   79415:	48 89 df             	mov    %rbx,%rdi
   79418:	e8 b3 36 fb ff       	call   2cad0 <_Unwind_Resume@plt>
   7941d:	ff 15 8d da 06 00    	call   *0x6da8d(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
