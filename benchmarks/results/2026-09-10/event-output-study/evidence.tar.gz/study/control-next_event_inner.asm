
/tmp/oriole-event-output/control.so:     file format elf64-x86-64


Disassembly of section .text:

00000000000814b0 <<oriole::Parser>::next_event_inner>:
   814b0:	55                   	push   %rbp
   814b1:	41 57                	push   %r15
   814b3:	41 56                	push   %r14
   814b5:	41 55                	push   %r13
   814b7:	41 54                	push   %r12
   814b9:	53                   	push   %rbx
   814ba:	48 81 ec 88 05 00 00 	sub    $0x588,%rsp
   814c1:	49 89 f7             	mov    %rsi,%r15
   814c4:	48 89 fb             	mov    %rdi,%rbx
   814c7:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   814ce:	00 
   814cf:	31 d2                	xor    %edx,%edx
   814d1:	e8 0a ba ff ff       	call   7cee0 <<oriole::Parser>::account_source>
   814d6:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   814dd:	ff 
   814de:	74 42                	je     81522 <<oriole::Parser>::next_event_inner+0x72>
   814e0:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   814e7:	00 
   814e8:	48 89 43 38          	mov    %rax,0x38(%rbx)
   814ec:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   814f3:	00 00 
   814f5:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   814fc:	00 00 
   814fe:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   81505:	00 00 
   81507:	f3 0f 7f 53 28       	movdqu %xmm2,0x28(%rbx)
   8150c:	f3 0f 7f 4b 18       	movdqu %xmm1,0x18(%rbx)
   81511:	f3 0f 7f 43 08       	movdqu %xmm0,0x8(%rbx)
   81516:	48 c7 03 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rbx)
   8151d:	e9 2e 3c 00 00       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   81522:	49 8b 87 00 07 00 00 	mov    0x700(%r15),%rax
   81529:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
   81530:	00 
   81531:	41 0f 10 87 f0 06 00 	movups 0x6f0(%r15),%xmm0
   81538:	00 
   81539:	0f 29 84 24 90 02 00 	movaps %xmm0,0x290(%rsp)
   81540:	00 
   81541:	f3 41 0f 6f 87 b0 06 	movdqu 0x6b0(%r15),%xmm0
   81548:	00 00 
   8154a:	f3 41 0f 6f 8f c0 06 	movdqu 0x6c0(%r15),%xmm1
   81551:	00 00 
   81553:	f3 41 0f 6f 97 d0 06 	movdqu 0x6d0(%r15),%xmm2
   8155a:	00 00 
   8155c:	41 0f 10 9f e0 06 00 	movups 0x6e0(%r15),%xmm3
   81563:	00 
   81564:	0f 29 9c 24 80 02 00 	movaps %xmm3,0x280(%rsp)
   8156b:	00 
   8156c:	66 0f 7f 94 24 70 02 	movdqa %xmm2,0x270(%rsp)
   81573:	00 00 
   81575:	66 0f 7f 8c 24 60 02 	movdqa %xmm1,0x260(%rsp)
   8157c:	00 00 
   8157e:	66 0f 7f 84 24 50 02 	movdqa %xmm0,0x250(%rsp)
   81585:	00 00 
   81587:	49 c7 87 b0 06 00 00 	movq   $0xffffffffffffffff,0x6b0(%r15)
   8158e:	ff ff ff ff 
   81592:	48 83 bc 24 50 02 00 	cmpq   $0xffffffffffffffff,0x250(%rsp)
   81599:	00 ff 
   8159b:	0f 84 6c 01 00 00    	je     8170d <<oriole::Parser>::next_event_inner+0x25d>
   815a1:	f3 41 0f 6f 87 e8 06 	movdqu 0x6e8(%r15),%xmm0
   815a8:	00 00 
   815aa:	f3 41 0f 6f 8f f8 06 	movdqu 0x6f8(%r15),%xmm1
   815b1:	00 00 
   815b3:	66 0f 7f 8c 24 30 04 	movdqa %xmm1,0x430(%rsp)
   815ba:	00 00 
   815bc:	66 0f 7f 84 24 20 04 	movdqa %xmm0,0x420(%rsp)
   815c3:	00 00 
   815c5:	41 8b 87 80 08 00 00 	mov    0x880(%r15),%eax
   815cc:	85 c0                	test   %eax,%eax
   815ce:	74 1c                	je     815ec <<oriole::Parser>::next_event_inner+0x13c>
   815d0:	41 8b 87 80 08 00 00 	mov    0x880(%r15),%eax
   815d7:	85 c0                	test   %eax,%eax
   815d9:	0f 84 b7 00 00 00    	je     81696 <<oriole::Parser>::next_event_inner+0x1e6>
   815df:	41 0f b6 87 b2 08 00 	movzbl 0x8b2(%r15),%eax
   815e6:	00 
   815e7:	e9 ba 00 00 00       	jmp    816a6 <<oriole::Parser>::next_event_inner+0x1f6>
   815ec:	49 8b 87 78 08 00 00 	mov    0x878(%r15),%rax
   815f3:	0f b6 40 28          	movzbl 0x28(%rax),%eax
   815f7:	84 c0                	test   %al,%al
   815f9:	74 d5                	je     815d0 <<oriole::Parser>::next_event_inner+0x120>
   815fb:	41 80 bf be 08 00 00 	cmpb   $0x0,0x8be(%r15)
   81602:	00 
   81603:	0f 85 d1 00 00 00    	jne    816da <<oriole::Parser>::next_event_inner+0x22a>
   81609:	49 8d bf 98 01 00 00 	lea    0x198(%r15),%rdi
   81610:	66 0f 6f 84 24 20 04 	movdqa 0x420(%rsp),%xmm0
   81617:	00 00 
   81619:	66 0f 6f 8c 24 30 04 	movdqa 0x430(%rsp),%xmm1
   81620:	00 00 
   81622:	f3 0f 7f 8c 24 40 01 	movdqu %xmm1,0x140(%rsp)
   81629:	00 00 
   8162b:	f3 0f 7f 84 24 30 01 	movdqu %xmm0,0x130(%rsp)
   81632:	00 00 
   81634:	48 c7 84 24 b8 00 00 	movq   $0x16,0xb8(%rsp)
   8163b:	00 16 00 00 00 
   81640:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   81647:	00 ff ff ff ff 
   8164c:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
   81653:	00 
   81654:	e8 67 5d fd ff       	call   573c0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   81659:	3c ff                	cmp    $0xff,%al
   8165b:	0f 84 89 33 00 00    	je     849ea <<oriole::Parser>::next_event_inner+0x353a>
   81661:	48 8d 05 34 fe f8 ff 	lea    -0x701cc(%rip),%rax        # 1149c <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   81668:	48 89 43 08          	mov    %rax,0x8(%rbx)
   8166c:	48 c7 43 10 0d 00 00 	movq   $0xd,0x10(%rbx)
   81673:	00 
   81674:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
   8167b:	00 
   8167c:	48 c7 43 20 01 00 00 	movq   $0x1,0x20(%rbx)
   81683:	00 
   81684:	66 0f ef c0          	pxor   %xmm0,%xmm0
   81688:	f3 0f 7f 43 28       	movdqu %xmm0,0x28(%rbx)
   8168d:	c6 43 38 00          	movb   $0x0,0x38(%rbx)
   81691:	e9 af 33 00 00       	jmp    84a45 <<oriole::Parser>::next_event_inner+0x3595>
   81696:	49 8b 87 78 08 00 00 	mov    0x878(%r15),%rax
   8169d:	0f b6 40 29          	movzbl 0x29(%rax),%eax
   816a1:	84 c0                	test   %al,%al
   816a3:	0f 95 c0             	setne  %al
   816a6:	41 0f b6 8f be 08 00 	movzbl 0x8be(%r15),%ecx
   816ad:	00 
   816ae:	80 f1 01             	xor    $0x1,%cl
   816b1:	0f b6 c9             	movzbl %cl,%ecx
   816b4:	84 c0                	test   %al,%al
   816b6:	b8 01 00 00 00       	mov    $0x1,%eax
   816bb:	0f 44 c1             	cmove  %ecx,%eax
   816be:	41 88 87 b2 08 00 00 	mov    %al,0x8b2(%r15)
   816c5:	41 8b 8f 80 08 00 00 	mov    0x880(%r15),%ecx
   816cc:	85 c9                	test   %ecx,%ecx
   816ce:	75 0a                	jne    816da <<oriole::Parser>::next_event_inner+0x22a>
   816d0:	49 8b 8f 78 08 00 00 	mov    0x878(%r15),%rcx
   816d7:	88 41 29             	mov    %al,0x29(%rcx)
   816da:	48 83 bc 24 50 02 00 	cmpq   $0xffffffffffffffff,0x250(%rsp)
   816e1:	00 ff 
   816e3:	74 28                	je     8170d <<oriole::Parser>::next_event_inner+0x25d>
   816e5:	48 8b 8c 24 78 02 00 	mov    0x278(%rsp),%rcx
   816ec:	00 
   816ed:	48 85 c9             	test   %rcx,%rcx
   816f0:	74 1b                	je     8170d <<oriole::Parser>::next_event_inner+0x25d>
   816f2:	48 8b b4 24 70 02 00 	mov    0x270(%rsp),%rsi
   816f9:	00 
   816fa:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   81701:	00 
   81702:	ba 01 00 00 00       	mov    $0x1,%edx
   81707:	ff 15 5b 51 06 00    	call   *0x6515b(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   8170d:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   81712:	49 8d 87 98 01 00 00 	lea    0x198(%r15),%rax
   81719:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
   81720:	00 
   81721:	4d 8d b7 f0 04 00 00 	lea    0x4f0(%r15),%r14
   81728:	49 8d 87 40 01 00 00 	lea    0x140(%r15),%rax
   8172f:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
   81736:	00 
   81737:	4d 8d af 28 05 00 00 	lea    0x528(%r15),%r13
   8173e:	49 8d 87 50 05 00 00 	lea    0x550(%r15),%rax
   81745:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
   8174c:	00 
   8174d:	49 8d 87 60 05 00 00 	lea    0x560(%r15),%rax
   81754:	48 89 84 24 30 05 00 	mov    %rax,0x530(%rsp)
   8175b:	00 
   8175c:	49 8d 87 88 05 00 00 	lea    0x588(%r15),%rax
   81763:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
   8176a:	00 
   8176b:	66 0f 6f 05 0d 70 f8 	movdqa -0x78ff3(%rip),%xmm0        # 8780 <std::thread::current::id::ID+0x8710>
   81772:	ff 
   81773:	66 0f 7f 84 24 f0 04 	movdqa %xmm0,0x4f0(%rsp)
   8177a:	00 00 
   8177c:	49 8d 87 49 01 00 00 	lea    0x149(%r15),%rax
   81783:	48 89 84 24 20 05 00 	mov    %rax,0x520(%rsp)
   8178a:	00 
   8178b:	49 8d 87 f9 03 00 00 	lea    0x3f9(%r15),%rax
   81792:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
   81799:	00 
   8179a:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   817a1:	00 
   817a2:	48 8d 05 f3 fc f8 ff 	lea    -0x7030d(%rip),%rax        # 1149c <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   817a9:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
   817b0:	00 
   817b1:	48 8d 05 10 1f 06 00 	lea    0x61f10(%rip),%rax        # e36c8 <oriole_expat::FEATURES+0xb20>
   817b8:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
   817bf:	00 
   817c0:	4c 89 3c 24          	mov    %r15,(%rsp)
   817c4:	4c 89 b4 24 40 05 00 	mov    %r14,0x540(%rsp)
   817cb:	00 
   817cc:	4c 89 ac 24 48 05 00 	mov    %r13,0x548(%rsp)
   817d3:	00 
   817d4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   817db:	00 00 00 00 00 
   817e0:	49 8b 9f c8 01 00 00 	mov    0x1c8(%r15),%rbx
   817e7:	4d 8b a7 d0 01 00 00 	mov    0x1d0(%r15),%r12
   817ee:	49 39 dc             	cmp    %rbx,%r12
   817f1:	0f 83 26 02 00 00    	jae    81a1d <<oriole::Parser>::next_event_inner+0x56d>
   817f7:	48 89 ef             	mov    %rbp,%rdi
   817fa:	4d 8b b7 b8 01 00 00 	mov    0x1b8(%r15),%r14
   81801:	4d 69 ec d0 00 00 00 	imul   $0xd0,%r12,%r13
   81808:	4b 8d 34 2e          	lea    (%r14,%r13,1),%rsi
   8180c:	ba d0 00 00 00       	mov    $0xd0,%edx
   81811:	ff 15 39 59 06 00    	call   *0x65939(%rip)        # e7150 <memcpy@GLIBC_2.14>
   81817:	4b c7 04 2e fe ff ff 	movq   $0xfffffffffffffffe,(%r14,%r13,1)
   8181e:	ff 
   8181f:	49 ff c4             	inc    %r12
   81822:	4d 89 a7 d0 01 00 00 	mov    %r12,0x1d0(%r15)
   81829:	49 39 dc             	cmp    %rbx,%r12
   8182c:	75 27                	jne    81855 <<oriole::Parser>::next_event_inner+0x3a5>
   8182e:	4c 8b 24 24          	mov    (%rsp),%r12
   81832:	49 c7 84 24 c8 01 00 	movq   $0x0,0x1c8(%r12)
   81839:	00 00 00 00 00 
   8183e:	4c 89 f7             	mov    %r14,%rdi
   81841:	48 89 de             	mov    %rbx,%rsi
   81844:	e8 67 87 fc ff       	call   49fb0 <core::ptr::drop_glue::<[core::option::Option<oriole::PendingEvent>]>>
   81849:	49 c7 84 24 d0 01 00 	movq   $0x0,0x1d0(%r12)
   81850:	00 00 00 00 00 
   81855:	48 8b 9c 24 80 00 00 	mov    0x80(%rsp),%rbx
   8185c:	00 
   8185d:	ba c8 00 00 00       	mov    $0xc8,%edx
   81862:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   81869:	00 
   8186a:	48 8d b4 24 88 00 00 	lea    0x88(%rsp),%rsi
   81871:	00 
   81872:	ff 15 d8 58 06 00    	call   *0x658d8(%rip)        # e7150 <memcpy@GLIBC_2.14>
   81878:	48 83 fb fe          	cmp    $0xfffffffffffffffe,%rbx
   8187c:	4c 8b b4 24 40 05 00 	mov    0x540(%rsp),%r14
   81883:	00 
   81884:	4c 8b 3c 24          	mov    (%rsp),%r15
   81888:	0f 84 8f 01 00 00    	je     81a1d <<oriole::Parser>::next_event_inner+0x56d>
   8188e:	ba c8 00 00 00       	mov    $0xc8,%edx
   81893:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
   8189a:	00 
   8189b:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
   818a2:	00 
   818a3:	ff 15 a7 58 06 00    	call   *0x658a7(%rip)        # e7150 <memcpy@GLIBC_2.14>
   818a9:	48 89 9c 24 50 02 00 	mov    %rbx,0x250(%rsp)
   818b0:	00 
   818b1:	83 bc 24 88 02 00 00 	cmpl   $0x12,0x288(%rsp)
   818b8:	12 
   818b9:	75 55                	jne    81910 <<oriole::Parser>::next_event_inner+0x460>
   818bb:	48 8b 84 24 b0 02 00 	mov    0x2b0(%rsp),%rax
   818c2:	00 
   818c3:	83 38 ff             	cmpl   $0xffffffff,(%rax)
   818c6:	75 48                	jne    81910 <<oriole::Parser>::next_event_inner+0x460>
   818c8:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   818cc:	75 42                	jne    81910 <<oriole::Parser>::next_event_inner+0x460>
   818ce:	41 80 bf f1 07 00 00 	cmpb   $0x2,0x7f1(%r15)
   818d5:	02 
   818d6:	74 38                	je     81910 <<oriole::Parser>::next_event_inner+0x460>
   818d8:	41 c6 87 f1 07 00 00 	movb   $0x1,0x7f1(%r15)
   818df:	01 
   818e0:	41 8b 87 80 08 00 00 	mov    0x880(%r15),%eax
   818e7:	85 c0                	test   %eax,%eax
   818e9:	0f 85 80 3a 00 00    	jne    8536f <<oriole::Parser>::next_event_inner+0x3ebf>
   818ef:	49 8b 87 78 08 00 00 	mov    0x878(%r15),%rax
   818f6:	c6 40 28 00          	movb   $0x0,0x28(%rax)
   818fa:	48 8b 9c 24 50 02 00 	mov    0x250(%rsp),%rbx
   81901:	00 
   81902:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   81909:	1f 84 00 00 00 00 00 
   81910:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
   81914:	0f 84 d6 00 00 00    	je     819f0 <<oriole::Parser>::next_event_inner+0x540>
   8191a:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
   81921:	00 
   81922:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   81929:	00 
   8192a:	f3 0f 6f 84 24 50 02 	movdqu 0x250(%rsp),%xmm0
   81931:	00 00 
   81933:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   8193a:	00 00 
   8193c:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   81943:	00 00 
   81945:	66 0f 7f 94 24 a0 00 	movdqa %xmm2,0xa0(%rsp)
   8194c:	00 00 
   8194e:	66 0f 7f 8c 24 90 00 	movdqa %xmm1,0x90(%rsp)
   81955:	00 00 
   81957:	66 0f 7f 84 24 80 00 	movdqa %xmm0,0x80(%rsp)
   8195e:	00 00 
   81960:	48 85 c0             	test   %rax,%rax
   81963:	74 5b                	je     819c0 <<oriole::Parser>::next_event_inner+0x510>
   81965:	49 8b 8f 18 05 00 00 	mov    0x518(%r15),%rcx
   8196c:	48 85 c9             	test   %rcx,%rcx
   8196f:	74 15                	je     81986 <<oriole::Parser>::next_event_inner+0x4d6>
   81971:	49 8b b7 10 05 00 00 	mov    0x510(%r15),%rsi
   81978:	ba 01 00 00 00       	mov    $0x1,%edx
   8197d:	4c 89 f7             	mov    %r14,%rdi
   81980:	ff 15 e2 4e 06 00    	call   *0x64ee2(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   81986:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
   8198d:	00 
   8198e:	49 89 46 30          	mov    %rax,0x30(%r14)
   81992:	f3 0f 6f 84 24 50 02 	movdqu 0x250(%rsp),%xmm0
   81999:	00 00 
   8199b:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   819a2:	00 00 
   819a4:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   819ab:	00 00 
   819ad:	f3 41 0f 7f 56 20    	movdqu %xmm2,0x20(%r14)
   819b3:	f3 41 0f 7f 4e 10    	movdqu %xmm1,0x10(%r14)
   819b9:	f3 41 0f 7f 06       	movdqu %xmm0,(%r14)
   819be:	eb 30                	jmp    819f0 <<oriole::Parser>::next_event_inner+0x540>
   819c0:	49 c7 87 20 05 00 00 	movq   $0x0,0x520(%r15)
   819c7:	00 00 00 00 
   819cb:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
   819d2:	00 
   819d3:	48 85 c9             	test   %rcx,%rcx
   819d6:	74 18                	je     819f0 <<oriole::Parser>::next_event_inner+0x540>
   819d8:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
   819df:	00 
   819e0:	ba 01 00 00 00       	mov    $0x1,%edx
   819e5:	48 89 ef             	mov    %rbp,%rdi
   819e8:	ff 15 7a 4e 06 00    	call   *0x64e7a(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   819ee:	66 90                	xchg   %ax,%ax
   819f0:	48 8b 9c 24 88 02 00 	mov    0x288(%rsp),%rbx
   819f7:	00 
   819f8:	ba 90 00 00 00       	mov    $0x90,%edx
   819fd:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
   81a04:	00 
   81a05:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
   81a0c:	00 
   81a0d:	ff 15 3d 57 06 00    	call   *0x6573d(%rip)        # e7150 <memcpy@GLIBC_2.14>
   81a13:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
   81a17:	0f 85 a9 2f 00 00    	jne    849c6 <<oriole::Parser>::next_event_inner+0x3516>
   81a1d:	41 80 bf b9 08 00 00 	cmpb   $0x0,0x8b9(%r15)
   81a24:	00 
   81a25:	0f 85 19 37 00 00    	jne    85144 <<oriole::Parser>::next_event_inner+0x3c94>
   81a2b:	41 83 bf 88 06 00 00 	cmpl   $0xffffffff,0x688(%r15)
   81a32:	ff 
   81a33:	74 1b                	je     81a50 <<oriole::Parser>::next_event_inner+0x5a0>
   81a35:	48 89 ef             	mov    %rbp,%rdi
   81a38:	4c 89 fe             	mov    %r15,%rsi
   81a3b:	e8 70 29 01 00       	call   943b0 <<oriole::Parser>::continue_value>
   81a40:	eb 3e                	jmp    81a80 <<oriole::Parser>::next_event_inner+0x5d0>
   81a42:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   81a49:	1f 84 00 00 00 00 00 
   81a50:	41 83 bf f0 03 00 00 	cmpl   $0xffffffff,0x3f0(%r15)
   81a57:	ff 
   81a58:	74 0d                	je     81a67 <<oriole::Parser>::next_event_inner+0x5b7>
   81a5a:	48 89 ef             	mov    %rbp,%rdi
   81a5d:	4c 89 fe             	mov    %r15,%rsi
   81a60:	e8 fb 65 fd ff       	call   58060 <<oriole::Parser>::continue_header_composition>
   81a65:	eb 19                	jmp    81a80 <<oriole::Parser>::next_event_inner+0x5d0>
   81a67:	41 83 bf 18 04 00 00 	cmpl   $0xffffffff,0x418(%r15)
   81a6e:	ff 
   81a6f:	74 35                	je     81aa6 <<oriole::Parser>::next_event_inner+0x5f6>
   81a71:	48 89 ef             	mov    %rbp,%rdi
   81a74:	4c 89 fe             	mov    %r15,%rsi
   81a77:	e8 a4 99 fd ff       	call   5b420 <<oriole::Parser>::continue_declaration_composition>
   81a7c:	0f 1f 40 00          	nopl   0x0(%rax)
   81a80:	0f b6 84 24 80 00 00 	movzbl 0x80(%rsp),%eax
   81a87:	00 
   81a88:	0f b6 8c 24 b0 00 00 	movzbl 0xb0(%rsp),%ecx
   81a8f:	00 
   81a90:	80 f9 ff             	cmp    $0xff,%cl
   81a93:	0f 85 de 2e 00 00    	jne    84977 <<oriole::Parser>::next_event_inner+0x34c7>
   81a99:	a8 01                	test   $0x1,%al
   81a9b:	0f 85 3f fd ff ff    	jne    817e0 <<oriole::Parser>::next_event_inner+0x330>
   81aa1:	e9 9e 36 00 00       	jmp    85144 <<oriole::Parser>::next_event_inner+0x3c94>
   81aa6:	4d 8b 97 90 01 00 00 	mov    0x190(%r15),%r10
   81aad:	4d 85 d2             	test   %r10,%r10
   81ab0:	0f 84 ac 35 00 00    	je     85062 <<oriole::Parser>::next_event_inner+0x3bb2>
   81ab6:	49 8b 87 80 01 00 00 	mov    0x180(%r15),%rax
   81abd:	4b 8d 0c 52          	lea    (%r10,%r10,2),%rcx
   81ac1:	48 c1 e1 07          	shl    $0x7,%rcx
   81ac5:	4c 8b ac 08 c8 fe ff 	mov    -0x138(%rax,%rcx,1),%r13
   81acc:	ff 
   81acd:	48 8b b4 08 d8 fe ff 	mov    -0x128(%rax,%rcx,1),%rsi
   81ad4:	ff 
   81ad5:	4c 8b 64 08 a0       	mov    -0x60(%rax,%rcx,1),%r12
   81ada:	4d 85 e4             	test   %r12,%r12
   81add:	74 18                	je     81af7 <<oriole::Parser>::next_event_inner+0x647>
   81adf:	4c 39 e6             	cmp    %r12,%rsi
   81ae2:	76 0d                	jbe    81af1 <<oriole::Parser>::next_event_inner+0x641>
   81ae4:	43 80 7c 25 00 bf    	cmpb   $0xbf,0x0(%r13,%r12,1)
   81aea:	7f 0b                	jg     81af7 <<oriole::Parser>::next_event_inner+0x647>
   81aec:	e9 e2 3a 00 00       	jmp    855d3 <<oriole::Parser>::next_event_inner+0x4123>
   81af1:	0f 85 dc 3a 00 00    	jne    855d3 <<oriole::Parser>::next_event_inner+0x4123>
   81af7:	49 89 f0             	mov    %rsi,%r8
   81afa:	4d 29 e0             	sub    %r12,%r8
   81afd:	75 73                	jne    81b72 <<oriole::Parser>::next_event_inner+0x6c2>
   81aff:	49 83 fa 01          	cmp    $0x1,%r10
   81b03:	0f 84 55 2f 00 00    	je     84a5e <<oriole::Parser>::next_event_inner+0x35ae>
   81b09:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
   81b10:	00 
   81b11:	48 89 df             	mov    %rbx,%rdi
   81b14:	4c 89 fe             	mov    %r15,%rsi
   81b17:	e8 94 1c 01 00       	call   937b0 <<oriole::Parser>::finish_conditional_source>
   81b1c:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   81b23:	ff 
   81b24:	4c 8b 74 24 18       	mov    0x18(%rsp),%r14
   81b29:	0f 85 c1 2f 00 00    	jne    84af0 <<oriole::Parser>::next_event_inner+0x3640>
   81b2f:	48 89 df             	mov    %rbx,%rdi
   81b32:	4c 89 fe             	mov    %r15,%rsi
   81b35:	e8 a6 4e 00 00       	call   869e0 <<oriole::Parser>::pop_entity_source>
   81b3a:	49 8b 87 08 02 00 00 	mov    0x208(%r15),%rax
   81b41:	48 3b 84 24 e8 01 00 	cmp    0x1e8(%rsp),%rax
   81b48:	00 
   81b49:	0f 85 e0 2f 00 00    	jne    84b2f <<oriole::Parser>::next_event_inner+0x367f>
   81b4f:	41 80 bf b7 08 00 00 	cmpb   $0x0,0x8b7(%r15)
   81b56:	00 
   81b57:	0f 85 d2 2f 00 00    	jne    84b2f <<oriole::Parser>::next_event_inner+0x367f>
   81b5d:	48 89 df             	mov    %rbx,%rdi
   81b60:	e8 fb 7d fc ff       	call   49960 <core::ptr::drop_glue::<oriole::encoding::Source>>
   81b65:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   81b6c:	00 
   81b6d:	e9 6e fc ff ff       	jmp    817e0 <<oriole::Parser>::next_event_inner+0x330>
   81b72:	48 8d 1c 08          	lea    (%rax,%rcx,1),%rbx
   81b76:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
   81b7a:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   81b81:	4f 8d 5c 25 00       	lea    0x0(%r13,%r12,1),%r11
   81b86:	4c 89 fa             	mov    %r15,%rdx
   81b89:	45 0f b6 bf b1 08 00 	movzbl 0x8b1(%r15),%r15d
   81b90:	00 
   81b91:	0f b6 82 bb 08 00 00 	movzbl 0x8bb(%rdx),%eax
   81b98:	44 89 f9             	mov    %r15d,%ecx
   81b9b:	08 c1                	or     %al,%cl
   81b9d:	f6 c1 01             	test   $0x1,%cl
   81ba0:	4c 89 94 24 40 02 00 	mov    %r10,0x240(%rsp)
   81ba7:	00 
   81ba8:	0f 84 11 03 00 00    	je     81ebf <<oriole::Parser>::next_event_inner+0xa0f>
   81bae:	48 89 7c 24 60       	mov    %rdi,0x60(%rsp)
   81bb3:	48 8b ba 40 04 00 00 	mov    0x440(%rdx),%rdi
   81bba:	48 85 ff             	test   %rdi,%rdi
   81bbd:	4c 89 9c 24 38 02 00 	mov    %r11,0x238(%rsp)
   81bc4:	00 
   81bc5:	4c 89 84 24 20 02 00 	mov    %r8,0x220(%rsp)
   81bcc:	00 
   81bcd:	0f 84 64 03 00 00    	je     81f37 <<oriole::Parser>::next_event_inner+0xa87>
   81bd3:	4d 85 e4             	test   %r12,%r12
   81bd6:	74 13                	je     81beb <<oriole::Parser>::next_event_inner+0x73b>
   81bd8:	4c 39 e6             	cmp    %r12,%rsi
   81bdb:	0f 86 f2 39 00 00    	jbe    855d3 <<oriole::Parser>::next_event_inner+0x4123>
   81be1:	41 80 3b bf          	cmpb   $0xbf,(%r11)
   81be5:	0f 8e e8 39 00 00    	jle    855d3 <<oriole::Parser>::next_event_inner+0x4123>
   81beb:	48 89 b4 24 20 03 00 	mov    %rsi,0x320(%rsp)
   81bf2:	00 
   81bf3:	49 81 f8 00 00 01 00 	cmp    $0x10000,%r8
   81bfa:	b8 00 00 01 00       	mov    $0x10000,%eax
   81bff:	49 0f 42 c0          	cmovb  %r8,%rax
   81c03:	48 89 84 24 60 03 00 	mov    %rax,0x360(%rsp)
   81c0a:	00 
   81c0b:	48 8b 0c 24          	mov    (%rsp),%rcx
   81c0f:	48 8b 81 e8 03 00 00 	mov    0x3e8(%rcx),%rax
   81c16:	48 89 84 24 10 05 00 	mov    %rax,0x510(%rsp)
   81c1d:	00 
   81c1e:	48 8b 81 90 07 00 00 	mov    0x790(%rcx),%rax
   81c25:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
   81c2c:	00 
   81c2d:	0f b6 81 b8 08 00 00 	movzbl 0x8b8(%rcx),%eax
   81c34:	88 44 24 6f          	mov    %al,0x6f(%rsp)
   81c38:	0f b6 81 f8 07 00 00 	movzbl 0x7f8(%rcx),%eax
   81c3f:	88 44 24 6e          	mov    %al,0x6e(%rsp)
   81c43:	3c ff                	cmp    $0xff,%al
   81c45:	0f 95 c0             	setne  %al
   81c48:	0f b6 91 28 01 00 00 	movzbl 0x128(%rcx),%edx
   81c4f:	80 f2 01             	xor    $0x1,%dl
   81c52:	08 c2                	or     %al,%dl
   81c54:	88 54 24 6d          	mov    %dl,0x6d(%rsp)
   81c58:	4c 8b 89 50 04 00 00 	mov    0x450(%rcx),%r9
   81c5f:	48 8b 81 98 07 00 00 	mov    0x798(%rcx),%rax
   81c66:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   81c6b:	45 31 ed             	xor    %r13d,%r13d
   81c6e:	66 90                	xchg   %ax,%ax
   81c70:	4d 85 ed             	test   %r13,%r13
   81c73:	74 17                	je     81c8c <<oriole::Parser>::next_event_inner+0x7dc>
   81c75:	4d 39 e8             	cmp    %r13,%r8
   81c78:	76 0c                	jbe    81c86 <<oriole::Parser>::next_event_inner+0x7d6>
   81c7a:	43 80 3c 2b bf       	cmpb   $0xbf,(%r11,%r13,1)
   81c7f:	7f 0b                	jg     81c8c <<oriole::Parser>::next_event_inner+0x7dc>
   81c81:	e9 7c 39 00 00       	jmp    85602 <<oriole::Parser>::next_event_inner+0x4152>
   81c86:	0f 85 76 39 00 00    	jne    85602 <<oriole::Parser>::next_event_inner+0x4152>
   81c8c:	4d 89 c7             	mov    %r8,%r15
   81c8f:	4d 29 ef             	sub    %r13,%r15
   81c92:	4b 8d 1c 2b          	lea    (%r11,%r13,1),%rbx
   81c96:	49 83 ff 03          	cmp    $0x3,%r15
   81c9a:	72 2c                	jb     81cc8 <<oriole::Parser>::next_event_inner+0x818>
   81c9c:	0f b7 03             	movzwl (%rbx),%eax
   81c9f:	35 3c 21 00 00       	xor    $0x213c,%eax
   81ca4:	0f b6 4b 02          	movzbl 0x2(%rbx),%ecx
   81ca8:	83 f1 5b             	xor    $0x5b,%ecx
   81cab:	66 09 c1             	or     %ax,%cx
   81cae:	74 3d                	je     81ced <<oriole::Parser>::next_event_inner+0x83d>
   81cb0:	0f b7 03             	movzwl (%rbx),%eax
   81cb3:	35 5d 5d 00 00       	xor    $0x5d5d,%eax
   81cb8:	0f b6 4b 02          	movzbl 0x2(%rbx),%ecx
   81cbc:	83 f1 3e             	xor    $0x3e,%ecx
   81cbf:	66 09 c1             	or     %ax,%cx
   81cc2:	0f 84 36 01 00 00    	je     81dfe <<oriole::Parser>::next_event_inner+0x94e>
   81cc8:	49 83 fa 01          	cmp    $0x1,%r10
   81ccc:	0f 85 a9 00 00 00    	jne    81d7b <<oriole::Parser>::next_event_inner+0x8cb>
   81cd2:	80 7c 24 6f 00       	cmpb   $0x0,0x6f(%rsp)
   81cd7:	74 35                	je     81d0e <<oriole::Parser>::next_event_inner+0x85e>
   81cd9:	49 83 ff 04          	cmp    $0x4,%r15
   81cdd:	0f 93 c0             	setae  %al
   81ce0:	0a 44 24 6d          	or     0x6d(%rsp),%al
   81ce4:	a8 01                	test   $0x1,%al
   81ce6:	74 33                	je     81d1b <<oriole::Parser>::next_event_inner+0x86b>
   81ce8:	e9 8e 00 00 00       	jmp    81d7b <<oriole::Parser>::next_event_inner+0x8cb>
   81ced:	48 8b 84 24 10 05 00 	mov    0x510(%rsp),%rax
   81cf4:	00 
   81cf5:	48 01 f8             	add    %rdi,%rax
   81cf8:	48 3b 84 24 08 05 00 	cmp    0x508(%rsp),%rax
   81cff:	00 
   81d00:	0f 83 e5 09 00 00    	jae    826eb <<oriole::Parser>::next_event_inner+0x123b>
   81d06:	48 ff c7             	inc    %rdi
   81d09:	e9 f3 00 00 00       	jmp    81e01 <<oriole::Parser>::next_event_inner+0x951>
   81d0e:	80 7c 24 6e ff       	cmpb   $0xff,0x6e(%rsp)
   81d13:	75 66                	jne    81d7b <<oriole::Parser>::next_event_inner+0x8cb>
   81d15:	49 83 ff 03          	cmp    $0x3,%r15
   81d19:	77 60                	ja     81d7b <<oriole::Parser>::next_event_inner+0x8cb>
   81d1b:	49 89 fe             	mov    %rdi,%r14
   81d1e:	48 89 df             	mov    %rbx,%rdi
   81d21:	48 8d 35 25 f9 f8 ff 	lea    -0x706db(%rip),%rsi        # 1164d <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4cc1>
   81d28:	4c 89 fa             	mov    %r15,%rdx
   81d2b:	4c 89 cd             	mov    %r9,%rbp
   81d2e:	ff 15 dc 53 06 00    	call   *0x653dc(%rip)        # e7110 <bcmp@GLIBC_2.2.5>
   81d34:	49 89 e9             	mov    %rbp,%r9
   81d37:	4c 89 f7             	mov    %r14,%rdi
   81d3a:	85 c0                	test   %eax,%eax
   81d3c:	0f 84 5d 08 00 00    	je     8259f <<oriole::Parser>::next_event_inner+0x10ef>
   81d42:	48 89 df             	mov    %rbx,%rdi
   81d45:	48 8d 35 9e f6 f8 ff 	lea    -0x70962(%rip),%rsi        # 113ea <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4a5e>
   81d4c:	4c 89 fa             	mov    %r15,%rdx
   81d4f:	ff 15 bb 53 06 00    	call   *0x653bb(%rip)        # e7110 <bcmp@GLIBC_2.2.5>
   81d55:	49 89 e9             	mov    %rbp,%r9
   81d58:	4c 89 f7             	mov    %r14,%rdi
   81d5b:	4c 8b 84 24 20 02 00 	mov    0x220(%rsp),%r8
   81d62:	00 
   81d63:	4c 8b 9c 24 38 02 00 	mov    0x238(%rsp),%r11
   81d6a:	00 
   81d6b:	4c 8b 94 24 40 02 00 	mov    0x240(%rsp),%r10
   81d72:	00 
   81d73:	85 c0                	test   %eax,%eax
   81d75:	0f 84 24 08 00 00    	je     8259f <<oriole::Parser>::next_event_inner+0x10ef>
   81d7b:	4b 8d 04 2c          	lea    (%r12,%r13,1),%rax
   81d7f:	48 3b 84 24 20 03 00 	cmp    0x320(%rsp),%rax
   81d86:	00 
   81d87:	0f 84 5c 38 00 00    	je     855e9 <<oriole::Parser>::next_event_inner+0x4139>
   81d8d:	0f b6 03             	movzbl (%rbx),%eax
   81d90:	84 c0                	test   %al,%al
   81d92:	78 13                	js     81da7 <<oriole::Parser>::next_event_inner+0x8f7>
   81d94:	4c 8b 3c 24          	mov    (%rsp),%r15
   81d98:	ba 01 00 00 00       	mov    $0x1,%edx
   81d9d:	83 f8 0d             	cmp    $0xd,%eax
   81da0:	76 7b                	jbe    81e1d <<oriole::Parser>::next_event_inner+0x96d>
   81da2:	e9 be 00 00 00       	jmp    81e65 <<oriole::Parser>::next_event_inner+0x9b5>
   81da7:	89 c1                	mov    %eax,%ecx
   81da9:	83 e1 1f             	and    $0x1f,%ecx
   81dac:	0f b6 73 01          	movzbl 0x1(%rbx),%esi
   81db0:	83 e6 3f             	and    $0x3f,%esi
   81db3:	3c df                	cmp    $0xdf,%al
   81db5:	4c 8b 3c 24          	mov    (%rsp),%r15
   81db9:	76 30                	jbe    81deb <<oriole::Parser>::next_event_inner+0x93b>
   81dbb:	0f b6 53 02          	movzbl 0x2(%rbx),%edx
   81dbf:	c1 e6 06             	shl    $0x6,%esi
   81dc2:	83 e2 3f             	and    $0x3f,%edx
   81dc5:	09 f2                	or     %esi,%edx
   81dc7:	3c f0                	cmp    $0xf0,%al
   81dc9:	72 41                	jb     81e0c <<oriole::Parser>::next_event_inner+0x95c>
   81dcb:	0f b6 43 03          	movzbl 0x3(%rbx),%eax
   81dcf:	83 e1 07             	and    $0x7,%ecx
   81dd2:	c1 e1 12             	shl    $0x12,%ecx
   81dd5:	c1 e2 06             	shl    $0x6,%edx
   81dd8:	83 e0 3f             	and    $0x3f,%eax
   81ddb:	09 d0                	or     %edx,%eax
   81ddd:	09 c8                	or     %ecx,%eax
   81ddf:	ba 01 00 00 00       	mov    $0x1,%edx
   81de4:	83 f8 0d             	cmp    $0xd,%eax
   81de7:	76 34                	jbe    81e1d <<oriole::Parser>::next_event_inner+0x96d>
   81de9:	eb 7a                	jmp    81e65 <<oriole::Parser>::next_event_inner+0x9b5>
   81deb:	c1 e1 06             	shl    $0x6,%ecx
   81dee:	09 f1                	or     %esi,%ecx
   81df0:	89 c8                	mov    %ecx,%eax
   81df2:	ba 01 00 00 00       	mov    $0x1,%edx
   81df7:	83 f8 0d             	cmp    $0xd,%eax
   81dfa:	76 21                	jbe    81e1d <<oriole::Parser>::next_event_inner+0x96d>
   81dfc:	eb 67                	jmp    81e65 <<oriole::Parser>::next_event_inner+0x9b5>
   81dfe:	48 ff cf             	dec    %rdi
   81e01:	ba 03 00 00 00       	mov    $0x3,%edx
   81e06:	4c 8b 3c 24          	mov    (%rsp),%r15
   81e0a:	eb 1b                	jmp    81e27 <<oriole::Parser>::next_event_inner+0x977>
   81e0c:	c1 e1 0c             	shl    $0xc,%ecx
   81e0f:	09 ca                	or     %ecx,%edx
   81e11:	89 d0                	mov    %edx,%eax
   81e13:	ba 01 00 00 00       	mov    $0x1,%edx
   81e18:	83 f8 0d             	cmp    $0xd,%eax
   81e1b:	77 48                	ja     81e65 <<oriole::Parser>::next_event_inner+0x9b5>
   81e1d:	b9 00 26 00 00       	mov    $0x2600,%ecx
   81e22:	0f a3 c1             	bt     %eax,%ecx
   81e25:	73 3e                	jae    81e65 <<oriole::Parser>::next_event_inner+0x9b5>
   81e27:	4c 01 ea             	add    %r13,%rdx
   81e2a:	4c 89 c8             	mov    %r9,%rax
   81e2d:	48 01 d0             	add    %rdx,%rax
   81e30:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
   81e37:	48 0f 42 c1          	cmovb  %rcx,%rax
   81e3b:	48 3b 44 24 70       	cmp    0x70(%rsp),%rax
   81e40:	0f 87 95 02 00 00    	ja     820db <<oriole::Parser>::next_event_inner+0xc2b>
   81e46:	48 85 ff             	test   %rdi,%rdi
   81e49:	0f 84 0d 03 00 00    	je     8215c <<oriole::Parser>::next_event_inner+0xcac>
   81e4f:	49 89 d5             	mov    %rdx,%r13
   81e52:	48 3b 94 24 60 03 00 	cmp    0x360(%rsp),%rdx
   81e59:	00 
   81e5a:	0f 82 10 fe ff ff    	jb     81c70 <<oriole::Parser>::next_event_inner+0x7c0>
   81e60:	e9 f9 02 00 00       	jmp    8215e <<oriole::Parser>::next_event_inner+0xcae>
   81e65:	8d 48 e0             	lea    -0x20(%rax),%ecx
   81e68:	81 f9 e0 d7 00 00    	cmp    $0xd7e0,%ecx
   81e6e:	0f 92 c1             	setb   %cl
   81e71:	8d b0 00 20 ff ff    	lea    -0xe000(%rax),%esi
   81e77:	81 fe fe 1f 00 00    	cmp    $0x1ffe,%esi
   81e7d:	40 0f 92 c6          	setb   %sil
   81e81:	40 08 ce             	or     %cl,%sil
   81e84:	3d 00 00 01 00       	cmp    $0x10000,%eax
   81e89:	0f 93 c1             	setae  %cl
   81e8c:	40 08 f1             	or     %sil,%cl
   81e8f:	0f 84 de 08 00 00    	je     82773 <<oriole::Parser>::next_event_inner+0x12c3>
   81e95:	3d 80 00 00 00       	cmp    $0x80,%eax
   81e9a:	72 8b                	jb     81e27 <<oriole::Parser>::next_event_inner+0x977>
   81e9c:	ba 02 00 00 00       	mov    $0x2,%edx
   81ea1:	3d 00 08 00 00       	cmp    $0x800,%eax
   81ea6:	0f 82 7b ff ff ff    	jb     81e27 <<oriole::Parser>::next_event_inner+0x977>
   81eac:	3d 00 00 01 00       	cmp    $0x10000,%eax
   81eb1:	ba 04 00 00 00       	mov    $0x4,%edx
   81eb6:	48 83 da 00          	sbb    $0x0,%rdx
   81eba:	e9 68 ff ff ff       	jmp    81e27 <<oriole::Parser>::next_event_inner+0x977>
   81ebf:	80 ba b7 08 00 00 00 	cmpb   $0x0,0x8b7(%rdx)
   81ec6:	49 89 d7             	mov    %rdx,%r15
   81ec9:	74 49                	je     81f14 <<oriole::Parser>::next_event_inner+0xa64>
   81ecb:	48 89 7c 24 60       	mov    %rdi,0x60(%rsp)
   81ed0:	e8 0b d4 fe ff       	call   6f2e0 <<oriole::encoding::Source>::converted_text_limit>
   81ed5:	48 8b bc 24 40 02 00 	mov    0x240(%rsp),%rdi
   81edc:	00 
   81edd:	48 89 c5             	mov    %rax,%rbp
   81ee0:	4c 8b 8b c8 fe ff ff 	mov    -0x138(%rbx),%r9
   81ee7:	48 8b 8b d8 fe ff ff 	mov    -0x128(%rbx),%rcx
   81eee:	4c 8b 63 a0          	mov    -0x60(%rbx),%r12
   81ef2:	4d 85 e4             	test   %r12,%r12
   81ef5:	0f 84 38 03 00 00    	je     82233 <<oriole::Parser>::next_event_inner+0xd83>
   81efb:	4c 39 e1             	cmp    %r12,%rcx
   81efe:	0f 86 29 03 00 00    	jbe    8222d <<oriole::Parser>::next_event_inner+0xd7d>
   81f04:	43 80 3c 21 bf       	cmpb   $0xbf,(%r9,%r12,1)
   81f09:	0f 8f 24 03 00 00    	jg     82233 <<oriole::Parser>::next_event_inner+0xd83>
   81f0f:	e9 3b 37 00 00       	jmp    8564f <<oriole::Parser>::next_event_inner+0x419f>
   81f14:	4d 85 e4             	test   %r12,%r12
   81f17:	0f 84 76 01 00 00    	je     82093 <<oriole::Parser>::next_event_inner+0xbe3>
   81f1d:	4c 39 e6             	cmp    %r12,%rsi
   81f20:	0f 86 ad 36 00 00    	jbe    855d3 <<oriole::Parser>::next_event_inner+0x4123>
   81f26:	41 0f b6 03          	movzbl (%r11),%eax
   81f2a:	3c bf                	cmp    $0xbf,%al
   81f2c:	0f 8f 65 01 00 00    	jg     82097 <<oriole::Parser>::next_event_inner+0xbe7>
   81f32:	e9 9c 36 00 00       	jmp    855d3 <<oriole::Parser>::next_event_inner+0x4123>
   81f37:	4d 85 e4             	test   %r12,%r12
   81f3a:	74 13                	je     81f4f <<oriole::Parser>::next_event_inner+0xa9f>
   81f3c:	4c 39 e6             	cmp    %r12,%rsi
   81f3f:	0f 86 8e 36 00 00    	jbe    855d3 <<oriole::Parser>::next_event_inner+0x4123>
   81f45:	41 80 3b bf          	cmpb   $0xbf,(%r11)
   81f49:	0f 8e 84 36 00 00    	jle    855d3 <<oriole::Parser>::next_event_inner+0x4123>
   81f4f:	49 01 f5             	add    %rsi,%r13
   81f52:	45 31 e4             	xor    %r12d,%r12d
   81f55:	4c 89 d9             	mov    %r11,%rcx
   81f58:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   81f5f:	00 
   81f60:	0f b6 31             	movzbl (%rcx),%esi
   81f63:	40 84 f6             	test   %sil,%sil
   81f66:	78 06                	js     81f6e <<oriole::Parser>::next_event_inner+0xabe>
   81f68:	48 8d 51 01          	lea    0x1(%rcx),%rdx
   81f6c:	eb 72                	jmp    81fe0 <<oriole::Parser>::next_event_inner+0xb30>
   81f6e:	89 f7                	mov    %esi,%edi
   81f70:	83 e7 1f             	and    $0x1f,%edi
   81f73:	44 0f b6 49 01       	movzbl 0x1(%rcx),%r9d
   81f78:	41 83 e1 3f          	and    $0x3f,%r9d
   81f7c:	40 80 fe df          	cmp    $0xdf,%sil
   81f80:	76 32                	jbe    81fb4 <<oriole::Parser>::next_event_inner+0xb04>
   81f82:	44 0f b6 41 02       	movzbl 0x2(%rcx),%r8d
   81f87:	41 c1 e1 06          	shl    $0x6,%r9d
   81f8b:	41 83 e0 3f          	and    $0x3f,%r8d
   81f8f:	45 09 c8             	or     %r9d,%r8d
   81f92:	40 80 fe f0          	cmp    $0xf0,%sil
   81f96:	72 2a                	jb     81fc2 <<oriole::Parser>::next_event_inner+0xb12>
   81f98:	48 8d 51 04          	lea    0x4(%rcx),%rdx
   81f9c:	0f b6 71 03          	movzbl 0x3(%rcx),%esi
   81fa0:	83 e7 07             	and    $0x7,%edi
   81fa3:	c1 e7 12             	shl    $0x12,%edi
   81fa6:	41 c1 e0 06          	shl    $0x6,%r8d
   81faa:	83 e6 3f             	and    $0x3f,%esi
   81fad:	44 09 c6             	or     %r8d,%esi
   81fb0:	09 fe                	or     %edi,%esi
   81fb2:	eb 1b                	jmp    81fcf <<oriole::Parser>::next_event_inner+0xb1f>
   81fb4:	48 8d 51 02          	lea    0x2(%rcx),%rdx
   81fb8:	c1 e7 06             	shl    $0x6,%edi
   81fbb:	44 09 cf             	or     %r9d,%edi
   81fbe:	89 fe                	mov    %edi,%esi
   81fc0:	eb 1e                	jmp    81fe0 <<oriole::Parser>::next_event_inner+0xb30>
   81fc2:	48 8d 51 03          	lea    0x3(%rcx),%rdx
   81fc6:	c1 e7 0c             	shl    $0xc,%edi
   81fc9:	41 09 f8             	or     %edi,%r8d
   81fcc:	44 89 c6             	mov    %r8d,%esi
   81fcf:	4c 8b 84 24 20 02 00 	mov    0x220(%rsp),%r8
   81fd6:	00 
   81fd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   81fde:	00 00 
   81fe0:	83 fe 20             	cmp    $0x20,%esi
   81fe3:	77 27                	ja     8200c <<oriole::Parser>::next_event_inner+0xb5c>
   81fe5:	89 f6                	mov    %esi,%esi
   81fe7:	48 bf 00 26 00 00 01 	movabs $0x100002600,%rdi
   81fee:	00 00 00 
   81ff1:	48 0f a3 f7          	bt     %rsi,%rdi
   81ff5:	73 15                	jae    8200c <<oriole::Parser>::next_event_inner+0xb5c>
   81ff7:	49 29 cc             	sub    %rcx,%r12
   81ffa:	49 01 d4             	add    %rdx,%r12
   81ffd:	48 89 d1             	mov    %rdx,%rcx
   82000:	4c 39 ea             	cmp    %r13,%rdx
   82003:	0f 85 57 ff ff ff    	jne    81f60 <<oriole::Parser>::next_event_inner+0xab0>
   82009:	4d 89 c4             	mov    %r8,%r12
   8200c:	4d 85 e4             	test   %r12,%r12
   8200f:	0f 84 bb 02 00 00    	je     822d0 <<oriole::Parser>::next_event_inner+0xe20>
   82015:	48 89 ef             	mov    %rbp,%rdi
   82018:	4c 8b 3c 24          	mov    (%rsp),%r15
   8201c:	4c 89 fe             	mov    %r15,%rsi
   8201f:	4c 89 e2             	mov    %r12,%rdx
   82022:	e8 b9 ae ff ff       	call   7cee0 <<oriole::Parser>::account_source>
   82027:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   8202e:	ff 
   8202f:	0f 85 39 14 00 00    	jne    8346e <<oriole::Parser>::next_event_inner+0x1fbe>
   82035:	41 80 bf c1 08 00 00 	cmpb   $0x0,0x8c1(%r15)
   8203c:	00 
   8203d:	0f 84 76 0b 00 00    	je     82bb9 <<oriole::Parser>::next_event_inner+0x1709>
   82043:	49 8b 87 90 01 00 00 	mov    0x190(%r15),%rax
   8204a:	48 85 c0             	test   %rax,%rax
   8204d:	0f 84 0f 30 00 00    	je     85062 <<oriole::Parser>::next_event_inner+0x3bb2>
   82053:	49 8b 8f 80 01 00 00 	mov    0x180(%r15),%rcx
   8205a:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   8205e:	48 c1 e2 07          	shl    $0x7,%rdx
   82062:	48 8d 04 11          	lea    (%rcx,%rdx,1),%rax
   82066:	83 bc 11 80 fe ff ff 	cmpl   $0x1,-0x180(%rcx,%rdx,1)
   8206d:	01 
   8206e:	0f 85 71 0a 00 00    	jne    82ae5 <<oriole::Parser>::next_event_inner+0x1635>
   82074:	4c 8b b8 88 fe ff ff 	mov    -0x178(%rax),%r15
   8207b:	0f 10 80 90 fe ff ff 	movups -0x170(%rax),%xmm0
   82082:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   82087:	48 8b 98 a0 fe ff ff 	mov    -0x160(%rax),%rbx
   8208e:	e9 77 0a 00 00       	jmp    82b0a <<oriole::Parser>::next_event_inner+0x165a>
   82093:	41 0f b6 03          	movzbl (%r11),%eax
   82097:	3c 3c                	cmp    $0x3c,%al
   82099:	0f 84 35 01 00 00    	je     821d4 <<oriole::Parser>::next_event_inner+0xd24>
   8209f:	0f b6 c0             	movzbl %al,%eax
   820a2:	83 f8 26             	cmp    $0x26,%eax
   820a5:	0f 85 6a 01 00 00    	jne    82215 <<oriole::Parser>::next_event_inner+0xd65>
   820ab:	49 83 bf 08 02 00 00 	cmpq   $0x0,0x208(%r15)
   820b2:	00 
   820b3:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   820ba:	00 
   820bb:	75 0e                	jne    820cb <<oriole::Parser>::next_event_inner+0xc1b>
   820bd:	41 80 bf ba 08 00 00 	cmpb   $0x0,0x8ba(%r15)
   820c4:	00 
   820c5:	0f 84 86 2d 00 00    	je     84e51 <<oriole::Parser>::next_event_inner+0x39a1>
   820cb:	48 89 ef             	mov    %rbp,%rdi
   820ce:	4c 89 fe             	mov    %r15,%rsi
   820d1:	e8 ba b4 ff ff       	call   7d590 <<oriole::Parser>::parse_reference>
   820d6:	e9 a5 f9 ff ff       	jmp    81a80 <<oriole::Parser>::next_event_inner+0x5d0>
   820db:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   820e2:	00 
   820e3:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   820e8:	4c 89 ea             	mov    %r13,%rdx
   820eb:	31 c9                	xor    %ecx,%ecx
   820ed:	e8 2e c4 fe ff       	call   6e520 <<oriole::encoding::Source>::position_at>
   820f2:	c6 84 24 b0 00 00 00 	movb   $0x1e,0xb0(%rsp)
   820f9:	1e 
   820fa:	48 8d 05 1e 0c f9 ff 	lea    -0x6f3e2(%rip),%rax        # 12d1f <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x6393>
   82101:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   82108:	00 
   82109:	48 c7 84 24 88 00 00 	movq   $0x2a,0x88(%rsp)
   82110:	00 2a 00 00 00 
   82115:	f3 0f 6f 84 24 90 00 	movdqu 0x90(%rsp),%xmm0
   8211c:	00 00 
   8211e:	f3 0f 6f 8c 24 a0 00 	movdqu 0xa0(%rsp),%xmm1
   82125:	00 00 
   82127:	66 0f 7f 44 24 30    	movdqa %xmm0,0x30(%rsp)
   8212d:	66 0f 7f 4c 24 40    	movdqa %xmm1,0x40(%rsp)
   82133:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   8213a:	00 
   8213b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   82140:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
   82147:	00 
   82148:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   8214d:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   82154:	00 
   82155:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   8215a:	eb 6b                	jmp    821c7 <<oriole::Parser>::next_event_inner+0xd17>
   8215c:	31 ff                	xor    %edi,%edi
   8215e:	49 89 bf 40 04 00 00 	mov    %rdi,0x440(%r15)
   82165:	49 01 d1             	add    %rdx,%r9
   82168:	4d 89 8f 50 04 00 00 	mov    %r9,0x450(%r15)
   8216f:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   82176:	00 
   82177:	4c 89 fe             	mov    %r15,%rsi
   8217a:	e8 81 14 01 00       	call   93600 <<oriole::Parser>::conditional_raw>
   8217f:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   82186:	ff 
   82187:	0f 84 9c 01 00 00    	je     82329 <<oriole::Parser>::next_event_inner+0xe79>
   8218d:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   82194:	00 
   82195:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   8219a:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   821a1:	00 00 
   821a3:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   821aa:	00 00 
   821ac:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   821b3:	00 00 
   821b5:	66 0f 7f 54 24 40    	movdqa %xmm2,0x40(%rsp)
   821bb:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   821c1:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   821c7:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   821ce:	00 
   821cf:	e9 d4 12 00 00       	jmp    834a8 <<oriole::Parser>::next_event_inner+0x1ff8>
   821d4:	e8 27 d8 fe ff       	call   6fa00 <<oriole::encoding::Source>::remaining>
   821d9:	48 89 d1             	mov    %rdx,%rcx
   821dc:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   821e1:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
   821e6:	48 83 fa 03          	cmp    $0x3,%rdx
   821ea:	4d 8d af 28 05 00 00 	lea    0x528(%r15),%r13
   821f1:	4d 8d b7 f0 04 00 00 	lea    0x4f0(%r15),%r14
   821f8:	0f 83 05 02 00 00    	jae    82403 <<oriole::Parser>::next_event_inner+0xf53>
   821fe:	48 83 f9 02          	cmp    $0x2,%rcx
   82202:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   82209:	00 
   8220a:	0f 84 54 02 00 00    	je     82464 <<oriole::Parser>::next_event_inner+0xfb4>
   82210:	e9 c1 2d 00 00       	jmp    84fd6 <<oriole::Parser>::next_event_inner+0x3b26>
   82215:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   8221c:	00 
   8221d:	48 89 ef             	mov    %rbp,%rdi
   82220:	4c 89 fe             	mov    %r15,%rsi
   82223:	e8 08 72 ff ff       	call   79430 <<oriole::Parser>::parse_text>
   82228:	e9 53 f8 ff ff       	jmp    81a80 <<oriole::Parser>::next_event_inner+0x5d0>
   8222d:	0f 85 1c 34 00 00    	jne    8564f <<oriole::Parser>::next_event_inner+0x419f>
   82233:	48 89 ce             	mov    %rcx,%rsi
   82236:	4c 29 e6             	sub    %r12,%rsi
   82239:	4f 8d 2c 21          	lea    (%r9,%r12,1),%r13
   8223d:	48 85 ed             	test   %rbp,%rbp
   82240:	74 18                	je     8225a <<oriole::Parser>::next_event_inner+0xdaa>
   82242:	48 39 f5             	cmp    %rsi,%rbp
   82245:	73 0d                	jae    82254 <<oriole::Parser>::next_event_inner+0xda4>
   82247:	41 80 7c 2d 00 c0    	cmpb   $0xc0,0x0(%r13,%rbp,1)
   8224d:	7d 0b                	jge    8225a <<oriole::Parser>::next_event_inner+0xdaa>
   8224f:	e9 11 34 00 00       	jmp    85665 <<oriole::Parser>::next_event_inner+0x41b5>
   82254:	0f 85 0b 34 00 00    	jne    85665 <<oriole::Parser>::next_event_inner+0x41b5>
   8225a:	48 83 ff 01          	cmp    $0x1,%rdi
   8225e:	75 56                	jne    822b6 <<oriole::Parser>::next_event_inner+0xe06>
   82260:	41 80 bf b8 08 00 00 	cmpb   $0x0,0x8b8(%r15)
   82267:	00 
   82268:	74 0a                	je     82274 <<oriole::Parser>::next_event_inner+0xdc4>
   8226a:	41 80 bf 28 01 00 00 	cmpb   $0x1,0x128(%r15)
   82271:	01 
   82272:	75 42                	jne    822b6 <<oriole::Parser>::next_event_inner+0xe06>
   82274:	41 80 bf f8 07 00 00 	cmpb   $0xff,0x7f8(%r15)
   8227b:	ff 
   8227c:	75 38                	jne    822b6 <<oriole::Parser>::next_event_inner+0xe06>
   8227e:	45 31 f6             	xor    %r14d,%r14d
   82281:	48 83 fd 03          	cmp    $0x3,%rbp
   82285:	0f 82 c8 00 00 00    	jb     82353 <<oriole::Parser>::next_event_inner+0xea3>
   8228b:	41 0f b7 45 00       	movzwl 0x0(%r13),%eax
   82290:	35 5d 5d 00 00       	xor    $0x5d5d,%eax
   82295:	41 0f b6 4d 02       	movzbl 0x2(%r13),%ecx
   8229a:	83 f1 3e             	xor    $0x3e,%ecx
   8229d:	66 09 c1             	or     %ax,%cx
   822a0:	0f 84 30 01 00 00    	je     823d6 <<oriole::Parser>::next_event_inner+0xf26>
   822a6:	48 89 5c 24 70       	mov    %rbx,0x70(%rsp)
   822ab:	4c 89 eb             	mov    %r13,%rbx
   822ae:	48 01 eb             	add    %rbp,%rbx
   822b1:	e9 ad 00 00 00       	jmp    82363 <<oriole::Parser>::next_event_inner+0xeb3>
   822b6:	4d 85 e4             	test   %r12,%r12
   822b9:	0f 84 83 00 00 00    	je     82342 <<oriole::Parser>::next_event_inner+0xe92>
   822bf:	4c 39 e1             	cmp    %r12,%rcx
   822c2:	76 78                	jbe    8233c <<oriole::Parser>::next_event_inner+0xe8c>
   822c4:	41 80 7d 00 bf       	cmpb   $0xbf,0x0(%r13)
   822c9:	7f 77                	jg     82342 <<oriole::Parser>::next_event_inner+0xe92>
   822cb:	e9 7f 33 00 00       	jmp    8564f <<oriole::Parser>::next_event_inner+0x419f>
   822d0:	48 89 df             	mov    %rbx,%rdi
   822d3:	41 0f b6 1b          	movzbl (%r11),%ebx
   822d7:	89 d9                	mov    %ebx,%ecx
   822d9:	84 db                	test   %bl,%bl
   822db:	0f 89 37 0e 00 00    	jns    83118 <<oriole::Parser>::next_event_inner+0x1c68>
   822e1:	89 d9                	mov    %ebx,%ecx
   822e3:	83 e1 1f             	and    $0x1f,%ecx
   822e6:	41 0f b6 73 01       	movzbl 0x1(%r11),%esi
   822eb:	83 e6 3f             	and    $0x3f,%esi
   822ee:	80 fb df             	cmp    $0xdf,%bl
   822f1:	0f 86 e4 07 00 00    	jbe    82adb <<oriole::Parser>::next_event_inner+0x162b>
   822f7:	41 0f b6 53 02       	movzbl 0x2(%r11),%edx
   822fc:	c1 e6 06             	shl    $0x6,%esi
   822ff:	83 e2 3f             	and    $0x3f,%edx
   82302:	09 f2                	or     %esi,%edx
   82304:	80 fb f0             	cmp    $0xf0,%bl
   82307:	0f 82 04 0e 00 00    	jb     83111 <<oriole::Parser>::next_event_inner+0x1c61>
   8230d:	41 0f b6 73 03       	movzbl 0x3(%r11),%esi
   82312:	83 e1 07             	and    $0x7,%ecx
   82315:	c1 e1 12             	shl    $0x12,%ecx
   82318:	c1 e2 06             	shl    $0x6,%edx
   8231b:	83 e6 3f             	and    $0x3f,%esi
   8231e:	09 d6                	or     %edx,%esi
   82320:	09 ce                	or     %ecx,%esi
   82322:	89 f1                	mov    %esi,%ecx
   82324:	e9 ef 0d 00 00       	jmp    83118 <<oriole::Parser>::next_event_inner+0x1c68>
   82329:	b0 01                	mov    $0x1,%al
   8232b:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   82332:	00 
   82333:	88 44 24 20          	mov    %al,0x20(%rsp)
   82337:	e9 79 11 00 00       	jmp    834b5 <<oriole::Parser>::next_event_inner+0x2005>
   8233c:	0f 85 0d 33 00 00    	jne    8564f <<oriole::Parser>::next_event_inner+0x419f>
   82342:	48 39 f5             	cmp    %rsi,%rbp
   82345:	41 0f 94 c6          	sete   %r14b
   82349:	48 83 fd 03          	cmp    $0x3,%rbp
   8234d:	0f 83 38 ff ff ff    	jae    8228b <<oriole::Parser>::next_event_inner+0xddb>
   82353:	48 89 5c 24 70       	mov    %rbx,0x70(%rsp)
   82358:	4c 89 eb             	mov    %r13,%rbx
   8235b:	48 01 eb             	add    %rbp,%rbx
   8235e:	48 85 ed             	test   %rbp,%rbp
   82361:	74 37                	je     8239a <<oriole::Parser>::next_event_inner+0xeea>
   82363:	48 83 ff 01          	cmp    $0x1,%rdi
   82367:	0f 95 c1             	setne  %cl
   8236a:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
   8236f:	3c 0d                	cmp    $0xd,%al
   82371:	0f 95 c2             	setne  %dl
   82374:	3c 0a                	cmp    $0xa,%al
   82376:	74 35                	je     823ad <<oriole::Parser>::next_event_inner+0xefd>
   82378:	08 d1                	or     %dl,%cl
   8237a:	74 31                	je     823ad <<oriole::Parser>::next_event_inner+0xefd>
   8237c:	48 83 fd 03          	cmp    $0x3,%rbp
   82380:	0f 92 c1             	setb   %cl
   82383:	3c 5d                	cmp    $0x5d,%al
   82385:	0f 95 c0             	setne  %al
   82388:	08 c8                	or     %cl,%al
   8238a:	0f 84 88 01 00 00    	je     82518 <<oriole::Parser>::next_event_inner+0x1068>
   82390:	48 83 fd 01          	cmp    $0x1,%rbp
   82394:	0f 85 99 01 00 00    	jne    82533 <<oriole::Parser>::next_event_inner+0x1083>
   8239a:	4d 89 cf             	mov    %r9,%r15
   8239d:	e8 1e f3 01 00       	call   a16c0 <<core::ops::control_flow::ControlFlow<&[u8]> as core::ops::try_trait::Try>::from_output>
   823a2:	4d 89 f9             	mov    %r15,%r9
   823a5:	49 89 d7             	mov    %rdx,%r15
   823a8:	e9 f5 03 00 00       	jmp    827a2 <<oriole::Parser>::next_event_inner+0x12f2>
   823ad:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   823b3:	48 83 fd 01          	cmp    $0x1,%rbp
   823b7:	0f 84 e0 03 00 00    	je     8279d <<oriole::Parser>::next_event_inner+0x12ed>
   823bd:	41 0f b7 45 00       	movzwl 0x0(%r13),%eax
   823c2:	45 31 ff             	xor    %r15d,%r15d
   823c5:	3d 0d 0a 00 00       	cmp    $0xa0d,%eax
   823ca:	41 0f 94 c7          	sete   %r15b
   823ce:	49 ff c7             	inc    %r15
   823d1:	e9 c7 03 00 00       	jmp    8279d <<oriole::Parser>::next_event_inner+0x12ed>
   823d6:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   823db:	83 3f 01             	cmpl   $0x1,(%rdi)
   823de:	0f 85 2d 02 00 00    	jne    82611 <<oriole::Parser>::next_event_inner+0x1161>
   823e4:	4c 8b bb 88 fe ff ff 	mov    -0x178(%rbx),%r15
   823eb:	0f 10 83 90 fe ff ff 	movups -0x170(%rbx),%xmm0
   823f2:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   823f7:	48 8b 9b a0 fe ff ff 	mov    -0x160(%rbx),%rbx
   823fe:	e9 2a 02 00 00       	jmp    8262d <<oriole::Parser>::next_event_inner+0x117d>
   82403:	0f b7 10             	movzwl (%rax),%edx
   82406:	81 f2 3c 21 00 00    	xor    $0x213c,%edx
   8240c:	0f b6 70 02          	movzbl 0x2(%rax),%esi
   82410:	83 f6 5b             	xor    $0x5b,%esi
   82413:	66 09 d6             	or     %dx,%si
   82416:	40 0f 95 c7          	setne  %dil
   8241a:	49 8b 97 08 02 00 00 	mov    0x208(%r15),%rdx
   82421:	48 85 d2             	test   %rdx,%rdx
   82424:	41 0f 95 c0          	setne  %r8b
   82428:	41 0f b6 b7 ba 08 00 	movzbl 0x8ba(%r15),%esi
   8242f:	00 
   82430:	41 08 f0             	or     %sil,%r8b
   82433:	41 08 f8             	or     %dil,%r8b
   82436:	41 f6 c0 01          	test   $0x1,%r8b
   8243a:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   82441:	00 
   82442:	0f 84 b8 2b 00 00    	je     85000 <<oriole::Parser>::next_event_inner+0x3b50>
   82448:	48 83 f9 03          	cmp    $0x3,%rcx
   8244c:	74 16                	je     82464 <<oriole::Parser>::next_event_inner+0xfb4>
   8244e:	81 38 3c 21 2d 2d    	cmpl   $0x2d2d213c,(%rax)
   82454:	0f 84 88 07 00 00    	je     82be2 <<oriole::Parser>::next_event_inner+0x1732>
   8245a:	48 83 f9 09          	cmp    $0x9,%rcx
   8245e:	0f 83 61 10 00 00    	jae    834c5 <<oriole::Parser>::next_event_inner+0x2015>
   82464:	66 81 38 3c 3f       	cmpw   $0x3f3c,(%rax)
   82469:	0f 84 47 01 00 00    	je     825b6 <<oriole::Parser>::next_event_inner+0x1106>
   8246f:	66 81 38 3c 2f       	cmpw   $0x2f3c,(%rax)
   82474:	74 2a                	je     824a0 <<oriole::Parser>::next_event_inner+0xff0>
   82476:	48 83 f9 03          	cmp    $0x3,%rcx
   8247a:	72 19                	jb     82495 <<oriole::Parser>::next_event_inner+0xfe5>
   8247c:	0f b7 10             	movzwl (%rax),%edx
   8247f:	81 f2 3c 21 00 00    	xor    $0x213c,%edx
   82485:	0f b6 70 02          	movzbl 0x2(%rax),%esi
   82489:	83 f6 5b             	xor    $0x5b,%esi
   8248c:	66 09 d6             	or     %dx,%si
   8248f:	0f 84 1e 2c 00 00    	je     850b3 <<oriole::Parser>::next_event_inner+0x3c03>
   82495:	66 81 38 3c 21       	cmpw   $0x213c,(%rax)
   8249a:	0f 84 db 2b 00 00    	je     8507b <<oriole::Parser>::next_event_inner+0x3bcb>
   824a0:	c6 84 24 40 03 00 00 	movb   $0x0,0x340(%rsp)
   824a7:	00 
   824a8:	0f b7 30             	movzwl (%rax),%esi
   824ab:	31 d2                	xor    %edx,%edx
   824ad:	81 fe 3c 2f 00 00    	cmp    $0x2f3c,%esi
   824b3:	0f 94 c2             	sete   %dl
   824b6:	48 ff c2             	inc    %rdx
   824b9:	bb 02 00 00 00       	mov    $0x2,%ebx
   824be:	48 39 ca             	cmp    %rcx,%rdx
   824c1:	73 0d                	jae    824d0 <<oriole::Parser>::next_event_inner+0x1020>
   824c3:	80 3c 10 bf          	cmpb   $0xbf,(%rax,%rdx,1)
   824c7:	48 89 d3             	mov    %rdx,%rbx
   824ca:	0f 8e 1d 2b 00 00    	jle    84fed <<oriole::Parser>::next_event_inner+0x3b3d>
   824d0:	48 8d 14 18          	lea    (%rax,%rbx,1),%rdx
   824d4:	48 01 c1             	add    %rax,%rcx
   824d7:	48 89 94 24 50 02 00 	mov    %rdx,0x250(%rsp)
   824de:	00 
   824df:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
   824e6:	00 
   824e7:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   824ee:	00 
   824ef:	e8 4c 82 fc ff       	call   4a740 <core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>>
   824f4:	a8 01                	test   $0x1,%al
   824f6:	0f 84 ee 06 00 00    	je     82bea <<oriole::Parser>::next_event_inner+0x173a>
   824fc:	41 0f b6 bf cc 07 00 	movzbl 0x7cc(%r15),%edi
   82503:	00 
   82504:	89 d6                	mov    %edx,%esi
   82506:	e8 35 37 fd ff       	call   55c40 <<oriole::names::NameRules>::is_name_start>
   8250b:	84 c0                	test   %al,%al
   8250d:	0f 85 d7 06 00 00    	jne    82bea <<oriole::Parser>::next_event_inner+0x173a>
   82513:	e9 d6 2c 00 00       	jmp    851ee <<oriole::Parser>::next_event_inner+0x3d3e>
   82518:	41 0f b7 45 00       	movzwl 0x0(%r13),%eax
   8251d:	35 5d 5d 00 00       	xor    $0x5d5d,%eax
   82522:	41 0f b6 4d 02       	movzbl 0x2(%r13),%ecx
   82527:	83 f1 3e             	xor    $0x3e,%ecx
   8252a:	66 09 c1             	or     %ax,%cx
   8252d:	0f 84 67 02 00 00    	je     8279a <<oriole::Parser>::next_event_inner+0x12ea>
   82533:	49 8d 45 01          	lea    0x1(%r13),%rax
   82537:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
   8253e:	eb 0f                	jmp    8254f <<oriole::Parser>::next_event_inner+0x109f>
   82540:	48 ff c0             	inc    %rax
   82543:	49 ff cf             	dec    %r15
   82546:	48 39 d8             	cmp    %rbx,%rax
   82549:	0f 84 4b fe ff ff    	je     8239a <<oriole::Parser>::next_event_inner+0xeea>
   8254f:	48 83 ff 01          	cmp    $0x1,%rdi
   82553:	0f 95 c2             	setne  %dl
   82556:	0f b6 08             	movzbl (%rax),%ecx
   82559:	80 f9 0d             	cmp    $0xd,%cl
   8255c:	40 0f 95 c6          	setne  %sil
   82560:	80 f9 0a             	cmp    $0xa,%cl
   82563:	74 32                	je     82597 <<oriole::Parser>::next_event_inner+0x10e7>
   82565:	40 08 f2             	or     %sil,%dl
   82568:	74 2d                	je     82597 <<oriole::Parser>::next_event_inner+0x10e7>
   8256a:	80 f9 5d             	cmp    $0x5d,%cl
   8256d:	75 d1                	jne    82540 <<oriole::Parser>::next_event_inner+0x1090>
   8256f:	80 38 c0             	cmpb   $0xc0,(%rax)
   82572:	0f 8c bb 30 00 00    	jl     85633 <<oriole::Parser>::next_event_inner+0x4183>
   82578:	49 8d 0c 2f          	lea    (%r15,%rbp,1),%rcx
   8257c:	48 83 f9 03          	cmp    $0x3,%rcx
   82580:	72 be                	jb     82540 <<oriole::Parser>::next_event_inner+0x1090>
   82582:	0f b7 08             	movzwl (%rax),%ecx
   82585:	81 f1 5d 5d 00 00    	xor    $0x5d5d,%ecx
   8258b:	0f b6 50 02          	movzbl 0x2(%rax),%edx
   8258f:	83 f2 3e             	xor    $0x3e,%edx
   82592:	66 09 ca             	or     %cx,%dx
   82595:	75 a9                	jne    82540 <<oriole::Parser>::next_event_inner+0x1090>
   82597:	49 f7 df             	neg    %r15
   8259a:	e9 fe 01 00 00       	jmp    8279d <<oriole::Parser>::next_event_inner+0x12ed>
   8259f:	4c 89 ea             	mov    %r13,%rdx
   825a2:	4d 85 ed             	test   %r13,%r13
   825a5:	4c 8b 3c 24          	mov    (%rsp),%r15
   825a9:	0f 85 af fb ff ff    	jne    8215e <<oriole::Parser>::next_event_inner+0xcae>
   825af:	31 c0                	xor    %eax,%eax
   825b1:	e9 75 fd ff ff       	jmp    8232b <<oriole::Parser>::next_event_inner+0xe7b>
   825b6:	c6 84 24 40 03 00 00 	movb   $0x2,0x340(%rsp)
   825bd:	02 
   825be:	48 83 f9 03          	cmp    $0x3,%rcx
   825c2:	72 0a                	jb     825ce <<oriole::Parser>::next_event_inner+0x111e>
   825c4:	80 78 02 c0          	cmpb   $0xc0,0x2(%rax)
   825c8:	0f 8c f2 30 00 00    	jl     856c0 <<oriole::Parser>::next_event_inner+0x4210>
   825ce:	48 8d 50 02          	lea    0x2(%rax),%rdx
   825d2:	48 01 c1             	add    %rax,%rcx
   825d5:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
   825dc:	00 
   825dd:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
   825e4:	00 
   825e5:	48 89 ef             	mov    %rbp,%rdi
   825e8:	e8 53 81 fc ff       	call   4a740 <core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>>
   825ed:	a8 01                	test   $0x1,%al
   825ef:	0f 84 f5 05 00 00    	je     82bea <<oriole::Parser>::next_event_inner+0x173a>
   825f5:	41 0f b6 bf cc 07 00 	movzbl 0x7cc(%r15),%edi
   825fc:	00 
   825fd:	89 d6                	mov    %edx,%esi
   825ff:	e8 3c 36 fd ff       	call   55c40 <<oriole::names::NameRules>::is_name_start>
   82604:	84 c0                	test   %al,%al
   82606:	0f 85 de 05 00 00    	jne    82bea <<oriole::Parser>::next_event_inner+0x173a>
   8260c:	e9 96 2d 00 00       	jmp    853a7 <<oriole::Parser>::next_event_inner+0x3ef7>
   82611:	4c 8b 7b a8          	mov    -0x58(%rbx),%r15
   82615:	0f 10 43 d8          	movups -0x28(%rbx),%xmm0
   82619:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   8261e:	ba 03 00 00 00       	mov    $0x3,%edx
   82623:	31 f6                	xor    %esi,%esi
   82625:	e8 26 d1 fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   8262a:	48 89 c3             	mov    %rax,%rbx
   8262d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   82634:	00 
   82635:	ba 03 00 00 00       	mov    $0x3,%edx
   8263a:	49 89 fc             	mov    %rdi,%r12
   8263d:	4c 8b 34 24          	mov    (%rsp),%r14
   82641:	4c 89 f6             	mov    %r14,%rsi
   82644:	e8 97 33 00 00       	call   859e0 <<oriole::Parser>::save_current_raw>
   82649:	0f b6 ac 24 b0 00 00 	movzbl 0xb0(%rsp),%ebp
   82650:	00 
   82651:	40 80 fd ff          	cmp    $0xff,%bpl
   82655:	0f 85 b3 27 00 00    	jne    84e0e <<oriole::Parser>::next_event_inner+0x395e>
   8265b:	ba 03 00 00 00       	mov    $0x3,%edx
   82660:	4c 89 e7             	mov    %r12,%rdi
   82663:	4c 89 f6             	mov    %r14,%rsi
   82666:	e8 e5 e8 00 00       	call   90f50 <<oriole::Parser>::consume>
   8266b:	0f b6 ac 24 b0 00 00 	movzbl 0xb0(%rsp),%ebp
   82672:	00 
   82673:	40 80 fd ff          	cmp    $0xff,%bpl
   82677:	0f 85 91 27 00 00    	jne    84e0e <<oriole::Parser>::next_event_inner+0x395e>
   8267d:	41 c6 86 b7 08 00 00 	movb   $0x0,0x8b7(%r14)
   82684:	00 
   82685:	48 c7 84 24 b8 00 00 	movq   $0xf,0xb8(%rsp)
   8268c:	00 0f 00 00 00 
   82691:	4c 89 bc 24 30 01 00 	mov    %r15,0x130(%rsp)
   82698:	00 
   82699:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   8269f:	f3 0f 7f 84 24 38 01 	movdqu %xmm0,0x138(%rsp)
   826a6:	00 00 
   826a8:	48 89 9c 24 48 01 00 	mov    %rbx,0x148(%rsp)
   826af:	00 
   826b0:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   826b7:	00 ff ff ff ff 
   826bc:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   826c3:	00 
   826c4:	4c 89 e6             	mov    %r12,%rsi
   826c7:	e8 f4 4c fd ff       	call   573c0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   826cc:	3c ff                	cmp    $0xff,%al
   826ce:	0f 85 e3 28 00 00    	jne    84fb7 <<oriole::Parser>::next_event_inner+0x3b07>
   826d4:	4c 8b ac 24 30 03 00 	mov    0x330(%rsp),%r13
   826db:	00 
   826dc:	49 81 e5 00 ff ff ff 	and    $0xffffffffffffff00,%r13
   826e3:	49 ff c5             	inc    %r13
   826e6:	e9 cd 03 00 00       	jmp    82ab8 <<oriole::Parser>::next_event_inner+0x1608>
   826eb:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
   826f2:	00 
   826f3:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   826f8:	4c 89 ea             	mov    %r13,%rdx
   826fb:	31 c9                	xor    %ecx,%ecx
   826fd:	e8 1e be fe ff       	call   6e520 <<oriole::encoding::Source>::position_at>
   82702:	c6 84 24 b0 00 00 00 	movb   $0x1e,0xb0(%rsp)
   82709:	1e 
   8270a:	48 8d 05 d9 f0 f8 ff 	lea    -0x70f27(%rip),%rax        # 117ea <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4e5e>
   82711:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   82718:	00 
   82719:	48 c7 84 24 88 00 00 	movq   $0x2a,0x88(%rsp)
   82720:	00 2a 00 00 00 
   82725:	f3 0f 6f 84 24 90 00 	movdqu 0x90(%rsp),%xmm0
   8272c:	00 00 
   8272e:	f3 0f 6f 8c 24 a0 00 	movdqu 0xa0(%rsp),%xmm1
   82735:	00 00 
   82737:	66 0f 7f 44 24 30    	movdqa %xmm0,0x30(%rsp)
   8273d:	66 0f 7f 4c 24 40    	movdqa %xmm1,0x40(%rsp)
   82743:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   8274a:	00 
   8274b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   82750:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
   82757:	00 
   82758:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   8275d:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   82764:	00 
   82765:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   8276a:	4c 8b 3c 24          	mov    (%rsp),%r15
   8276e:	e9 54 fa ff ff       	jmp    821c7 <<oriole::Parser>::next_event_inner+0xd17>
   82773:	41 b8 28 00 00 00    	mov    $0x28,%r8d
   82779:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   8277e:	4c 89 fe             	mov    %r15,%rsi
   82781:	ba 03 00 00 00       	mov    $0x3,%edx
   82786:	48 8d 0d 6a 05 f9 ff 	lea    -0x6fa96(%rip),%rcx        # 12cf7 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x636b>
   8278d:	4d 89 e9             	mov    %r13,%r9
   82790:	e8 3b e7 00 00       	call   90ed0 <<oriole::Parser>::err_at>
   82795:	e9 2d fa ff ff       	jmp    821c7 <<oriole::Parser>::next_event_inner+0xd17>
   8279a:	45 31 ff             	xor    %r15d,%r15d
   8279d:	b8 01 00 00 00       	mov    $0x1,%eax
   827a2:	a8 01                	test   $0x1,%al
   827a4:	4c 0f 44 fd          	cmove  %rbp,%r15
   827a8:	49 39 ef             	cmp    %rbp,%r15
   827ab:	0f 95 c0             	setne  %al
   827ae:	44 08 f0             	or     %r14b,%al
   827b1:	a8 01                	test   $0x1,%al
   827b3:	74 07                	je     827bc <<oriole::Parser>::next_event_inner+0x130c>
   827b5:	4d 85 ff             	test   %r15,%r15
   827b8:	75 65                	jne    8281f <<oriole::Parser>::next_event_inner+0x136f>
   827ba:	eb 7a                	jmp    82836 <<oriole::Parser>::next_event_inner+0x1386>
   827bc:	48 85 ed             	test   %rbp,%rbp
   827bf:	74 75                	je     82836 <<oriole::Parser>::next_event_inner+0x1386>
   827c1:	0f b6 43 ff          	movzbl -0x1(%rbx),%eax
   827c5:	31 c9                	xor    %ecx,%ecx
   827c7:	3c 0d                	cmp    $0xd,%al
   827c9:	0f 94 c1             	sete   %cl
   827cc:	49 89 ef             	mov    %rbp,%r15
   827cf:	49 29 cf             	sub    %rcx,%r15
   827d2:	48 f7 d9             	neg    %rcx
   827d5:	48 8d 3c 29          	lea    (%rcx,%rbp,1),%rdi
   827d9:	48 ff cf             	dec    %rdi
   827dc:	48 39 ef             	cmp    %rbp,%rdi
   827df:	73 25                	jae    82806 <<oriole::Parser>::next_event_inner+0x1356>
   827e1:	4b 8d 04 21          	lea    (%r9,%r12,1),%rax
   827e5:	48 ff c8             	dec    %rax
   827e8:	4c 89 f9             	mov    %r15,%rcx
   827eb:	49 89 cf             	mov    %rcx,%r15
   827ee:	48 83 e9 01          	sub    $0x1,%rcx
   827f2:	72 42                	jb     82836 <<oriole::Parser>::next_event_inner+0x1386>
   827f4:	49 8d 57 02          	lea    0x2(%r15),%rdx
   827f8:	48 39 ea             	cmp    %rbp,%rdx
   827fb:	72 22                	jb     8281f <<oriole::Parser>::next_event_inner+0x136f>
   827fd:	42 80 3c 38 5d       	cmpb   $0x5d,(%rax,%r15,1)
   82802:	74 e7                	je     827eb <<oriole::Parser>::next_event_inner+0x133b>
   82804:	eb 19                	jmp    8281f <<oriole::Parser>::next_event_inner+0x136f>
   82806:	4d 85 ff             	test   %r15,%r15
   82809:	74 2b                	je     82836 <<oriole::Parser>::next_event_inner+0x1386>
   8280b:	31 c9                	xor    %ecx,%ecx
   8280d:	3c 0d                	cmp    $0xd,%al
   8280f:	0f 94 c1             	sete   %cl
   82812:	48 83 c1 fd          	add    $0xfffffffffffffffd,%rcx
   82816:	48 39 e9             	cmp    %rbp,%rcx
   82819:	0f 83 91 2e 00 00    	jae    856b0 <<oriole::Parser>::next_event_inner+0x4200>
   8281f:	49 39 ef             	cmp    %rbp,%r15
   82822:	73 26                	jae    8284a <<oriole::Parser>::next_event_inner+0x139a>
   82824:	43 80 7c 3d 00 c0    	cmpb   $0xc0,0x0(%r13,%r15,1)
   8282a:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
   8282f:	7d 24                	jge    82855 <<oriole::Parser>::next_event_inner+0x13a5>
   82831:	e9 44 2e 00 00       	jmp    8567a <<oriole::Parser>::next_event_inner+0x41ca>
   82836:	4c 8b ac 24 30 03 00 	mov    0x330(%rsp),%r13
   8283d:	00 
   8283e:	49 81 e5 00 ff ff ff 	and    $0xffffffffffffff00,%r13
   82845:	e9 6e 02 00 00       	jmp    82ab8 <<oriole::Parser>::next_event_inner+0x1608>
   8284a:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
   8284f:	0f 85 25 2e 00 00    	jne    8567a <<oriole::Parser>::next_event_inner+0x41ca>
   82855:	4c 89 ef             	mov    %r13,%rdi
   82858:	4c 89 fe             	mov    %r15,%rsi
   8285b:	e8 a0 e4 01 00       	call   a0d00 <oriole::names::invalid_xml_char>
   82860:	a8 01                	test   $0x1,%al
   82862:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   82867:	74 0c                	je     82875 <<oriole::Parser>::next_event_inner+0x13c5>
   82869:	48 85 d2             	test   %rdx,%rdx
   8286c:	0f 84 ae 26 00 00    	je     84f20 <<oriole::Parser>::next_event_inner+0x3a70>
   82872:	49 89 d7             	mov    %rdx,%r15
   82875:	49 39 ef             	cmp    %rbp,%r15
   82878:	73 0d                	jae    82887 <<oriole::Parser>::next_event_inner+0x13d7>
   8287a:	43 80 7c 3d 00 c0    	cmpb   $0xc0,0x0(%r13,%r15,1)
   82880:	7d 0b                	jge    8288d <<oriole::Parser>::next_event_inner+0x13dd>
   82882:	e9 ff 2d 00 00       	jmp    85686 <<oriole::Parser>::next_event_inner+0x41d6>
   82887:	0f 85 f9 2d 00 00    	jne    85686 <<oriole::Parser>::next_event_inner+0x41d6>
   8288d:	83 3f 01             	cmpl   $0x1,(%rdi)
   82890:	75 24                	jne    828b6 <<oriole::Parser>::next_event_inner+0x1406>
   82892:	48 8b 83 88 fe ff ff 	mov    -0x178(%rbx),%rax
   82899:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   8289e:	0f 10 83 90 fe ff ff 	movups -0x170(%rbx),%xmm0
   828a5:	0f 29 84 24 60 03 00 	movaps %xmm0,0x360(%rsp)
   828ac:	00 
   828ad:	48 8b 83 a0 fe ff ff 	mov    -0x160(%rbx),%rax
   828b4:	eb 1f                	jmp    828d5 <<oriole::Parser>::next_event_inner+0x1425>
   828b6:	48 8b 43 a8          	mov    -0x58(%rbx),%rax
   828ba:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   828bf:	0f 10 43 d8          	movups -0x28(%rbx),%xmm0
   828c3:	0f 29 84 24 60 03 00 	movaps %xmm0,0x360(%rsp)
   828ca:	00 
   828cb:	31 f6                	xor    %esi,%esi
   828cd:	4c 89 fa             	mov    %r15,%rdx
   828d0:	e8 7b ce fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   828d5:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
   828dc:	00 
   828dd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   828e4:	00 
   828e5:	49 89 fc             	mov    %rdi,%r12
   828e8:	4c 8b 34 24          	mov    (%rsp),%r14
   828ec:	4c 89 f6             	mov    %r14,%rsi
   828ef:	4c 89 ea             	mov    %r13,%rdx
   828f2:	4c 89 f9             	mov    %r15,%rcx
   828f5:	e8 06 a8 ff ff       	call   7d100 <<oriole::Parser>::character_data>
   828fa:	4c 8b ac 24 88 00 00 	mov    0x88(%rsp),%r13
   82901:	00 
   82902:	48 8b 9c 24 90 00 00 	mov    0x90(%rsp),%rbx
   82909:	00 
   8290a:	f3 0f 6f 8c 24 98 00 	movdqu 0x98(%rsp),%xmm1
   82911:	00 00 
   82913:	f3 0f 6f 84 24 a8 00 	movdqu 0xa8(%rsp),%xmm0
   8291a:	00 00 
   8291c:	0f b6 ac 24 b8 00 00 	movzbl 0xb8(%rsp),%ebp
   82923:	00 
   82924:	48 8d 8c 24 88 00 00 	lea    0x88(%rsp),%rcx
   8292b:	00 
   8292c:	8b 41 31             	mov    0x31(%rcx),%eax
   8292f:	8b 49 34             	mov    0x34(%rcx),%ecx
   82932:	89 84 24 20 04 00 00 	mov    %eax,0x420(%rsp)
   82939:	89 8c 24 23 04 00 00 	mov    %ecx,0x423(%rsp)
   82940:	80 bc 24 80 00 00 00 	cmpb   $0x0,0x80(%rsp)
   82947:	00 
   82948:	74 2b                	je     82975 <<oriole::Parser>::next_event_inner+0x14c5>
   8294a:	8b 84 24 20 04 00 00 	mov    0x420(%rsp),%eax
   82951:	8b 8c 24 23 04 00 00 	mov    0x423(%rsp),%ecx
   82958:	89 8c 24 93 03 00 00 	mov    %ecx,0x393(%rsp)
   8295f:	89 84 24 90 03 00 00 	mov    %eax,0x390(%rsp)
   82966:	40 80 fd ff          	cmp    $0xff,%bpl
   8296a:	0f 84 48 01 00 00    	je     82ab8 <<oriole::Parser>::next_event_inner+0x1608>
   82970:	e9 3e 28 00 00       	jmp    851b3 <<oriole::Parser>::next_event_inner+0x3d03>
   82975:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
   8297c:	00 
   8297d:	48 89 9c 24 58 02 00 	mov    %rbx,0x258(%rsp)
   82984:	00 
   82985:	f3 0f 7f 8c 24 60 02 	movdqu %xmm1,0x260(%rsp)
   8298c:	00 00 
   8298e:	66 0f 7f 84 24 20 02 	movdqa %xmm0,0x220(%rsp)
   82995:	00 00 
   82997:	f3 0f 7f 84 24 70 02 	movdqu %xmm0,0x270(%rsp)
   8299e:	00 00 
   829a0:	40 88 ac 24 80 02 00 	mov    %bpl,0x280(%rsp)
   829a7:	00 
   829a8:	8b 84 24 20 04 00 00 	mov    0x420(%rsp),%eax
   829af:	8b 8c 24 23 04 00 00 	mov    0x423(%rsp),%ecx
   829b6:	48 8d 94 24 58 02 00 	lea    0x258(%rsp),%rdx
   829bd:	00 
   829be:	89 4a 2c             	mov    %ecx,0x2c(%rdx)
   829c1:	89 42 29             	mov    %eax,0x29(%rdx)
   829c4:	4c 89 e3             	mov    %r12,%rbx
   829c7:	4c 89 e7             	mov    %r12,%rdi
   829ca:	4c 89 f6             	mov    %r14,%rsi
   829cd:	4c 89 fa             	mov    %r15,%rdx
   829d0:	e8 0b 30 00 00       	call   859e0 <<oriole::Parser>::save_current_raw>
   829d5:	4c 8b b4 24 30 03 00 	mov    0x330(%rsp),%r14
   829dc:	00 
   829dd:	0f b6 ac 24 b0 00 00 	movzbl 0xb0(%rsp),%ebp
   829e4:	00 
   829e5:	40 80 fd ff          	cmp    $0xff,%bpl
   829e9:	0f 85 49 23 00 00    	jne    84d38 <<oriole::Parser>::next_event_inner+0x3888>
   829ef:	48 89 df             	mov    %rbx,%rdi
   829f2:	48 8b 34 24          	mov    (%rsp),%rsi
   829f6:	4c 89 fa             	mov    %r15,%rdx
   829f9:	e8 52 e5 00 00       	call   90f50 <<oriole::Parser>::consume>
   829fe:	0f b6 ac 24 b0 00 00 	movzbl 0xb0(%rsp),%ebp
   82a05:	00 
   82a06:	40 80 fd ff          	cmp    $0xff,%bpl
   82a0a:	0f 85 28 23 00 00    	jne    84d38 <<oriole::Parser>::next_event_inner+0x3888>
   82a10:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
   82a17:	00 
   82a18:	48 8d 8c 24 88 00 00 	lea    0x88(%rsp),%rcx
   82a1f:	00 
   82a20:	48 89 41 68          	mov    %rax,0x68(%rcx)
   82a24:	0f 10 84 24 50 02 00 	movups 0x250(%rsp),%xmm0
   82a2b:	00 
   82a2c:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   82a33:	00 00 
   82a35:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   82a3c:	00 00 
   82a3e:	f3 0f 7f 51 58       	movdqu %xmm2,0x58(%rcx)
   82a43:	f3 0f 7f 49 48       	movdqu %xmm1,0x48(%rcx)
   82a48:	0f 11 41 38          	movups %xmm0,0x38(%rcx)
   82a4c:	48 c7 84 24 b8 00 00 	movq   $0xb,0xb8(%rsp)
   82a53:	00 0b 00 00 00 
   82a58:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   82a5d:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   82a64:	00 
   82a65:	66 0f 6f 84 24 60 03 	movdqa 0x360(%rsp),%xmm0
   82a6c:	00 00 
   82a6e:	f3 0f 7f 84 24 38 01 	movdqu %xmm0,0x138(%rsp)
   82a75:	00 00 
   82a77:	48 8b 84 24 20 03 00 	mov    0x320(%rsp),%rax
   82a7e:	00 
   82a7f:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
   82a86:	00 
   82a87:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   82a8e:	00 ff ff ff ff 
   82a93:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   82a9a:	00 
   82a9b:	48 89 de             	mov    %rbx,%rsi
   82a9e:	e8 1d 49 fd ff       	call   573c0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   82aa3:	3c ff                	cmp    $0xff,%al
   82aa5:	0f 85 93 24 00 00    	jne    84f3e <<oriole::Parser>::next_event_inner+0x3a8e>
   82aab:	49 81 e6 00 ff ff ff 	and    $0xffffffffffffff00,%r14
   82ab2:	49 ff c6             	inc    %r14
   82ab5:	4d 89 f5             	mov    %r14,%r13
   82ab8:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
   82abf:	00 
   82ac0:	41 f6 c5 01          	test   $0x1,%r13b
   82ac4:	4c 8b 3c 24          	mov    (%rsp),%r15
   82ac8:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   82acf:	00 
   82ad0:	0f 85 0a ed ff ff    	jne    817e0 <<oriole::Parser>::next_event_inner+0x330>
   82ad6:	e9 69 26 00 00       	jmp    85144 <<oriole::Parser>::next_event_inner+0x3c94>
   82adb:	c1 e1 06             	shl    $0x6,%ecx
   82ade:	09 f1                	or     %esi,%ecx
   82ae0:	e9 33 06 00 00       	jmp    83118 <<oriole::Parser>::next_event_inner+0x1c68>
   82ae5:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
   82ae9:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   82af0:	4c 8b 78 a8          	mov    -0x58(%rax),%r15
   82af4:	0f 10 40 d8          	movups -0x28(%rax),%xmm0
   82af8:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   82afd:	31 f6                	xor    %esi,%esi
   82aff:	4c 89 e2             	mov    %r12,%rdx
   82b02:	e8 49 cc fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   82b07:	48 89 c3             	mov    %rax,%rbx
   82b0a:	48 89 ef             	mov    %rbp,%rdi
   82b0d:	48 8b 34 24          	mov    (%rsp),%rsi
   82b11:	4c 89 e2             	mov    %r12,%rdx
   82b14:	e8 c7 2e 00 00       	call   859e0 <<oriole::Parser>::save_current_raw>
   82b19:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   82b20:	ff 
   82b21:	74 43                	je     82b66 <<oriole::Parser>::next_event_inner+0x16b6>
   82b23:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   82b2a:	00 
   82b2b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   82b30:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   82b37:	00 00 
   82b39:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   82b40:	00 00 
   82b42:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   82b49:	00 00 
   82b4b:	66 0f 7f 54 24 40    	movdqa %xmm2,0x40(%rsp)
   82b51:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   82b57:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   82b5d:	4c 8b 3c 24          	mov    (%rsp),%r15
   82b61:	e9 42 09 00 00       	jmp    834a8 <<oriole::Parser>::next_event_inner+0x1ff8>
   82b66:	48 c7 84 24 b8 00 00 	movq   $0x3,0xb8(%rsp)
   82b6d:	00 03 00 00 00 
   82b72:	4c 89 bc 24 30 01 00 	mov    %r15,0x130(%rsp)
   82b79:	00 
   82b7a:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   82b80:	f3 0f 7f 84 24 38 01 	movdqu %xmm0,0x138(%rsp)
   82b87:	00 00 
   82b89:	48 89 9c 24 48 01 00 	mov    %rbx,0x148(%rsp)
   82b90:	00 
   82b91:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   82b98:	00 ff ff ff ff 
   82b9d:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   82ba4:	00 
   82ba5:	48 89 ee             	mov    %rbp,%rsi
   82ba8:	e8 13 48 fd ff       	call   573c0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   82bad:	3c ff                	cmp    $0xff,%al
   82baf:	4c 8b 3c 24          	mov    (%rsp),%r15
   82bb3:	0f 85 b5 28 00 00    	jne    8546e <<oriole::Parser>::next_event_inner+0x3fbe>
   82bb9:	41 c6 87 b6 08 00 00 	movb   $0x0,0x8b6(%r15)
   82bc0:	00 
   82bc1:	48 89 ef             	mov    %rbp,%rdi
   82bc4:	4c 89 fe             	mov    %r15,%rsi
   82bc7:	4c 89 e2             	mov    %r12,%rdx
   82bca:	e8 81 e3 00 00       	call   90f50 <<oriole::Parser>::consume>
   82bcf:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   82bd6:	ff 
   82bd7:	0f 85 91 08 00 00    	jne    8346e <<oriole::Parser>::next_event_inner+0x1fbe>
   82bdd:	e9 06 06 00 00       	jmp    831e8 <<oriole::Parser>::next_event_inner+0x1d38>
   82be2:	c6 84 24 40 03 00 00 	movb   $0x1,0x340(%rsp)
   82be9:	01 
   82bea:	49 8b 87 90 01 00 00 	mov    0x190(%r15),%rax
   82bf1:	48 83 f8 01          	cmp    $0x1,%rax
   82bf5:	77 1c                	ja     82c13 <<oriole::Parser>::next_event_inner+0x1763>
   82bf7:	41 80 bf b8 08 00 00 	cmpb   $0x1,0x8b8(%r15)
   82bfe:	01 
   82bff:	0f 85 f4 02 00 00    	jne    82ef9 <<oriole::Parser>::next_event_inner+0x1a49>
   82c05:	41 f6 87 28 01 00 00 	testb  $0x1,0x128(%r15)
   82c0c:	01 
   82c0d:	0f 85 e6 02 00 00    	jne    82ef9 <<oriole::Parser>::next_event_inner+0x1a49>
   82c13:	49 8b 8f 98 07 00 00 	mov    0x798(%r15),%rcx
   82c1a:	b3 01                	mov    $0x1,%bl
   82c1c:	48 85 c0             	test   %rax,%rax
   82c1f:	0f 84 7d 29 00 00    	je     855a2 <<oriole::Parser>::next_event_inner+0x40f2>
   82c25:	49 8b 97 80 01 00 00 	mov    0x180(%r15),%rdx
   82c2c:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   82c30:	48 c1 e0 07          	shl    $0x7,%rax
   82c34:	48 8d 34 02          	lea    (%rdx,%rax,1),%rsi
   82c38:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
   82c3f:	0f b6 94 24 40 03 00 	movzbl 0x340(%rsp),%edx
   82c46:	00 
   82c47:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   82c4e:	00 
   82c4f:	e8 9c b1 fe ff       	call   6ddf0 <<oriole::encoding::Source>::scan_token>
   82c54:	4c 8b bc 24 60 02 00 	mov    0x260(%rsp),%r15
   82c5b:	00 
   82c5c:	80 bc 24 50 02 00 00 	cmpb   $0x0,0x250(%rsp)
   82c63:	00 
   82c64:	0f 85 09 22 00 00    	jne    84e73 <<oriole::Parser>::next_event_inner+0x39c3>
   82c6a:	83 bc 24 58 02 00 00 	cmpl   $0x1,0x258(%rsp)
   82c71:	01 
   82c72:	0f 85 78 22 00 00    	jne    84ef0 <<oriole::Parser>::next_event_inner+0x3a40>
   82c78:	49 89 ec             	mov    %rbp,%r12
   82c7b:	48 8b 2c 24          	mov    (%rsp),%rbp
   82c7f:	80 bd b3 08 00 00 00 	cmpb   $0x0,0x8b3(%rbp)
   82c86:	74 72                	je     82cfa <<oriole::Parser>::next_event_inner+0x184a>
   82c88:	4c 89 e7             	mov    %r12,%rdi
   82c8b:	48 89 ee             	mov    %rbp,%rsi
   82c8e:	4c 89 fa             	mov    %r15,%rdx
   82c91:	e8 4a a2 ff ff       	call   7cee0 <<oriole::Parser>::account_source>
   82c96:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   82c9d:	ff 
   82c9e:	0f 85 3b 24 00 00    	jne    850df <<oriole::Parser>::next_event_inner+0x3c2f>
   82ca4:	48 8b 85 90 01 00 00 	mov    0x190(%rbp),%rax
   82cab:	48 85 c0             	test   %rax,%rax
   82cae:	0f 84 ae 23 00 00    	je     85062 <<oriole::Parser>::next_event_inner+0x3bb2>
   82cb4:	48 8b 95 80 01 00 00 	mov    0x180(%rbp),%rdx
   82cbb:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   82cbf:	48 c1 e6 07          	shl    $0x7,%rsi
   82cc3:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
   82cc7:	83 bc 32 80 fe ff ff 	cmpl   $0x1,-0x180(%rdx,%rsi,1)
   82cce:	01 
   82ccf:	0f 85 8a 00 00 00    	jne    82d5f <<oriole::Parser>::next_event_inner+0x18af>
   82cd5:	0f 10 81 88 fe ff ff 	movups -0x178(%rcx),%xmm0
   82cdc:	f3 0f 6f 89 98 fe ff 	movdqu -0x168(%rcx),%xmm1
   82ce3:	ff 
   82ce4:	66 0f 7f 8c 24 a0 03 	movdqa %xmm1,0x3a0(%rsp)
   82ceb:	00 00 
   82ced:	0f 29 84 24 90 03 00 	movaps %xmm0,0x390(%rsp)
   82cf4:	00 
   82cf5:	e9 ab 00 00 00       	jmp    82da5 <<oriole::Parser>::next_event_inner+0x18f5>
   82cfa:	80 bc 24 40 03 00 00 	cmpb   $0x0,0x340(%rsp)
   82d01:	00 
   82d02:	75 84                	jne    82c88 <<oriole::Parser>::next_event_inner+0x17d8>
   82d04:	80 bd b0 08 00 00 00 	cmpb   $0x0,0x8b0(%rbp)
   82d0b:	0f 84 77 ff ff ff    	je     82c88 <<oriole::Parser>::next_event_inner+0x17d8>
   82d11:	c6 85 b0 08 00 00 00 	movb   $0x0,0x8b0(%rbp)
   82d18:	48 8d 9c 24 50 02 00 	lea    0x250(%rsp),%rbx
   82d1f:	00 
   82d20:	48 89 df             	mov    %rbx,%rdi
   82d23:	48 89 ee             	mov    %rbp,%rsi
   82d26:	e8 05 e1 00 00       	call   90e30 <<oriole::Parser>::here>
   82d2b:	4c 89 e7             	mov    %r12,%rdi
   82d2e:	48 89 ee             	mov    %rbp,%rsi
   82d31:	48 89 da             	mov    %rbx,%rdx
   82d34:	e8 57 0d fe ff       	call   63a90 <<oriole::Parser>::start_foreign_dtd>
   82d39:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   82d40:	ff 
   82d41:	0f 85 98 23 00 00    	jne    850df <<oriole::Parser>::next_event_inner+0x3c2f>
   82d47:	80 bd c4 08 00 00 00 	cmpb   $0x0,0x8c4(%rbp)
   82d4e:	0f 84 34 ff ff ff    	je     82c88 <<oriole::Parser>::next_event_inner+0x17d8>
   82d54:	49 89 ef             	mov    %rbp,%r15
   82d57:	4c 89 e5             	mov    %r12,%rbp
   82d5a:	e9 81 ea ff ff       	jmp    817e0 <<oriole::Parser>::next_event_inner+0x330>
   82d5f:	48 8d 3c 32          	lea    (%rdx,%rsi,1),%rdi
   82d63:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   82d6a:	48 8b 59 a8          	mov    -0x58(%rcx),%rbx
   82d6e:	0f 10 41 d8          	movups -0x28(%rcx),%xmm0
   82d72:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   82d77:	31 f6                	xor    %esi,%esi
   82d79:	4c 89 fa             	mov    %r15,%rdx
   82d7c:	e8 cf c9 fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   82d81:	48 89 9c 24 90 03 00 	mov    %rbx,0x390(%rsp)
   82d88:	00 
   82d89:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   82d8e:	0f 11 84 24 98 03 00 	movups %xmm0,0x398(%rsp)
   82d95:	00 
   82d96:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
   82d9d:	00 
   82d9e:	48 8b 85 90 01 00 00 	mov    0x190(%rbp),%rax
   82da5:	49 8b 4d 60          	mov    0x60(%r13),%rcx
   82da9:	48 89 8c 24 b0 02 00 	mov    %rcx,0x2b0(%rsp)
   82db0:	00 
   82db1:	41 0f 10 45 50       	movups 0x50(%r13),%xmm0
   82db6:	0f 29 84 24 a0 02 00 	movaps %xmm0,0x2a0(%rsp)
   82dbd:	00 
   82dbe:	41 0f 10 45 40       	movups 0x40(%r13),%xmm0
   82dc3:	0f 29 84 24 90 02 00 	movaps %xmm0,0x290(%rsp)
   82dca:	00 
   82dcb:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
   82dd0:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
   82dd5:	f3 41 0f 6f 55 20    	movdqu 0x20(%r13),%xmm2
   82ddb:	41 0f 10 5d 30       	movups 0x30(%r13),%xmm3
   82de0:	0f 29 9c 24 80 02 00 	movaps %xmm3,0x280(%rsp)
   82de7:	00 
   82de8:	66 0f 7f 94 24 70 02 	movdqa %xmm2,0x270(%rsp)
   82def:	00 00 
   82df1:	0f 29 8c 24 60 02 00 	movaps %xmm1,0x260(%rsp)
   82df8:	00 
   82df9:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
   82e00:	00 
   82e01:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   82e08:	00 
   82e09:	0f 10 01             	movups (%rcx),%xmm0
   82e0c:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   82e10:	41 0f 11 45 00       	movups %xmm0,0x0(%r13)
   82e15:	41 0f 11 4d 10       	movups %xmm1,0x10(%r13)
   82e1a:	48 c7 85 48 05 00 00 	movq   $0x1,0x548(%rbp)
   82e21:	01 00 00 00 
   82e25:	48 8b 94 24 38 05 00 	mov    0x538(%rsp),%rdx
   82e2c:	00 
   82e2d:	66 0f ef d2          	pxor   %xmm2,%xmm2
   82e31:	f3 0f 7f 12          	movdqu %xmm2,(%rdx)
   82e35:	f3 0f 6f 01          	movdqu (%rcx),%xmm0
   82e39:	f3 0f 6f 49 10       	movdqu 0x10(%rcx),%xmm1
   82e3e:	48 8b 8c 24 30 05 00 	mov    0x530(%rsp),%rcx
   82e45:	00 
   82e46:	f3 0f 7f 49 10       	movdqu %xmm1,0x10(%rcx)
   82e4b:	f3 0f 7f 01          	movdqu %xmm0,(%rcx)
   82e4f:	48 c7 85 80 05 00 00 	movq   $0x8,0x580(%rbp)
   82e56:	08 00 00 00 
   82e5a:	48 8b 8c 24 28 05 00 	mov    0x528(%rsp),%rcx
   82e61:	00 
   82e62:	f3 0f 7f 11          	movdqu %xmm2,(%rcx)
   82e66:	48 c7 84 24 80 02 00 	movq   $0x0,0x280(%rsp)
   82e6d:	00 00 00 00 00 
   82e72:	48 c7 84 24 b8 02 00 	movq   $0x0,0x2b8(%rsp)
   82e79:	00 00 00 00 00 
   82e7e:	48 85 c0             	test   %rax,%rax
   82e81:	0f 84 fd 26 00 00    	je     85584 <<oriole::Parser>::next_event_inner+0x40d4>
   82e87:	48 8b 8d 80 01 00 00 	mov    0x180(%rbp),%rcx
   82e8e:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   82e92:	48 c1 e0 07          	shl    $0x7,%rax
   82e96:	48 8d 34 01          	lea    (%rcx,%rax,1),%rsi
   82e9a:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
   82ea1:	4c 89 e7             	mov    %r12,%rdi
   82ea4:	e8 87 c3 fe ff       	call   6f230 <<oriole::encoding::Source>::lexical_remaining>
   82ea9:	48 8b 0c 24          	mov    (%rsp),%rcx
   82ead:	48 8b 81 90 01 00 00 	mov    0x190(%rcx),%rax
   82eb4:	48 85 c0             	test   %rax,%rax
   82eb7:	0f 84 c7 26 00 00    	je     85584 <<oriole::Parser>::next_event_inner+0x40d4>
   82ebd:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   82ec4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   82ec8:	48 c1 e0 07          	shl    $0x7,%rax
   82ecc:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
   82ed0:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   82ed7:	e8 24 cb fe ff       	call   6fa00 <<oriole::encoding::Source>::remaining>
   82edc:	4c 89 e5             	mov    %r12,%rbp
   82edf:	4d 85 ff             	test   %r15,%r15
   82ee2:	0f 84 85 00 00 00    	je     82f6d <<oriole::Parser>::next_event_inner+0x1abd>
   82ee8:	49 39 d7             	cmp    %rdx,%r15
   82eeb:	73 6d                	jae    82f5a <<oriole::Parser>::next_event_inner+0x1aaa>
   82eed:	42 80 3c 38 c0       	cmpb   $0xc0,(%rax,%r15,1)
   82ef2:	7d 79                	jge    82f6d <<oriole::Parser>::next_event_inner+0x1abd>
   82ef4:	e9 48 1d 00 00       	jmp    84c41 <<oriole::Parser>::next_event_inner+0x3791>
   82ef9:	41 80 bf f8 07 00 00 	cmpb   $0xff,0x7f8(%r15)
   82f00:	ff 
   82f01:	0f 95 c3             	setne  %bl
   82f04:	49 8b 8f 98 07 00 00 	mov    0x798(%r15),%rcx
   82f0b:	0f 85 0b fd ff ff    	jne    82c1c <<oriole::Parser>::next_event_inner+0x176c>
   82f11:	41 80 bf bf 08 00 00 	cmpb   $0x0,0x8bf(%r15)
   82f18:	00 
   82f19:	0f 84 fd fc ff ff    	je     82c1c <<oriole::Parser>::next_event_inner+0x176c>
   82f1f:	48 85 c0             	test   %rax,%rax
   82f22:	0f 84 3a 21 00 00    	je     85062 <<oriole::Parser>::next_event_inner+0x3bb2>
   82f28:	49 8b bf 80 01 00 00 	mov    0x180(%r15),%rdi
   82f2f:	4d 89 fc             	mov    %r15,%r12
   82f32:	49 89 cf             	mov    %rcx,%r15
   82f35:	48 89 ce             	mov    %rcx,%rsi
   82f38:	e8 63 bd fe ff       	call   6eca0 <<oriole::encoding::Source>::should_defer>
   82f3d:	84 c0                	test   %al,%al
   82f3f:	0f 85 ff 21 00 00    	jne    85144 <<oriole::Parser>::next_event_inner+0x3c94>
   82f45:	49 8b 84 24 90 01 00 	mov    0x190(%r12),%rax
   82f4c:	00 
   82f4d:	31 db                	xor    %ebx,%ebx
   82f4f:	4c 89 f9             	mov    %r15,%rcx
   82f52:	4d 89 e7             	mov    %r12,%r15
   82f55:	e9 c2 fc ff ff       	jmp    82c1c <<oriole::Parser>::next_event_inner+0x176c>
   82f5a:	0f 95 c1             	setne  %cl
   82f5d:	48 85 c0             	test   %rax,%rax
   82f60:	40 0f 94 c6          	sete   %sil
   82f64:	40 08 ce             	or     %cl,%sil
   82f67:	0f 85 d4 1c 00 00    	jne    84c41 <<oriole::Parser>::next_event_inner+0x3791>
   82f6d:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   82f74:	00 
   82f75:	48 89 ee             	mov    %rbp,%rsi
   82f78:	48 89 c2             	mov    %rax,%rdx
   82f7b:	4c 89 f9             	mov    %r15,%rcx
   82f7e:	e8 0d a1 01 00       	call   9d090 <<oriole::lexical::Slice>::for_slice>
   82f83:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   82f8a:	00 
   82f8b:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
   82f92:	00 
   82f93:	e8 c8 58 ff ff       	call   78860 <<oriole::lexical::Buffer>::append>
   82f98:	3c ff                	cmp    $0xff,%al
   82f9a:	0f 85 34 1e 00 00    	jne    84dd4 <<oriole::Parser>::next_event_inner+0x3924>
   82fa0:	48 8d 84 24 50 02 00 	lea    0x250(%rsp),%rax
   82fa7:	00 
   82fa8:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   82faf:	00 
   82fb0:	48 8b 04 24          	mov    (%rsp),%rax
   82fb4:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   82fbb:	00 
   82fbc:	48 8d 84 24 40 03 00 	lea    0x340(%rsp),%rax
   82fc3:	00 
   82fc4:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   82fcb:	00 
   82fcc:	48 8d 84 24 90 03 00 	lea    0x390(%rsp),%rax
   82fd3:	00 
   82fd4:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
   82fdb:	00 
   82fdc:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   82fe3:	00 
   82fe4:	48 89 ee             	mov    %rbp,%rsi
   82fe7:	e8 e4 a0 fc ff       	call   4d0d0 <<oriole::Parser>::next_event_inner::{closure#4}>
   82fec:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   82ff3:	00 
   82ff4:	4c 89 f6             	mov    %r14,%rsi
   82ff7:	e8 a4 53 ff ff       	call   783a0 <<oriole::lexical::Buffer>::swap_decoded>
   82ffc:	3c ff                	cmp    $0xff,%al
   82ffe:	0f 85 d0 1d 00 00    	jne    84dd4 <<oriole::Parser>::next_event_inner+0x3924>
   83004:	80 bc 24 50 04 00 00 	cmpb   $0xff,0x450(%rsp)
   8300b:	ff 
   8300c:	0f 85 51 1f 00 00    	jne    84f63 <<oriole::Parser>::next_event_inner+0x3ab3>
   83012:	0f 28 84 24 b0 02 00 	movaps 0x2b0(%rsp),%xmm0
   83019:	00 
   8301a:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   83021:	00 
   83022:	0f 28 84 24 a0 02 00 	movaps 0x2a0(%rsp),%xmm0
   83029:	00 
   8302a:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   83031:	00 
   83032:	0f 28 84 24 90 02 00 	movaps 0x290(%rsp),%xmm0
   83039:	00 
   8303a:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   83041:	00 
   83042:	0f 28 84 24 50 02 00 	movaps 0x250(%rsp),%xmm0
   83049:	00 
   8304a:	0f 28 8c 24 60 02 00 	movaps 0x260(%rsp),%xmm1
   83051:	00 
   83052:	0f 28 94 24 70 02 00 	movaps 0x270(%rsp),%xmm2
   83059:	00 
   8305a:	0f 28 9c 24 80 02 00 	movaps 0x280(%rsp),%xmm3
   83061:	00 
   83062:	0f 29 9c 24 b0 00 00 	movaps %xmm3,0xb0(%rsp)
   83069:	00 
   8306a:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
   83071:	00 
   83072:	0f 29 8c 24 90 00 00 	movaps %xmm1,0x90(%rsp)
   83079:	00 
   8307a:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   83081:	00 
   83082:	4c 89 ef             	mov    %r13,%rdi
   83085:	e8 46 68 fc ff       	call   498d0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   8308a:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   83091:	00 
   83092:	41 0f 11 45 60       	movups %xmm0,0x60(%r13)
   83097:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   8309e:	00 
   8309f:	41 0f 11 45 50       	movups %xmm0,0x50(%r13)
   830a4:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
   830ab:	00 
   830ac:	41 0f 11 45 40       	movups %xmm0,0x40(%r13)
   830b1:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
   830b8:	00 00 
   830ba:	66 0f 6f 8c 24 90 00 	movdqa 0x90(%rsp),%xmm1
   830c1:	00 00 
   830c3:	66 0f 6f 94 24 a0 00 	movdqa 0xa0(%rsp),%xmm2
   830ca:	00 00 
   830cc:	0f 28 9c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm3
   830d3:	00 
   830d4:	41 0f 11 5d 30       	movups %xmm3,0x30(%r13)
   830d9:	f3 41 0f 7f 55 20    	movdqu %xmm2,0x20(%r13)
   830df:	f3 41 0f 7f 4d 10    	movdqu %xmm1,0x10(%r13)
   830e5:	f3 41 0f 7f 45 00    	movdqu %xmm0,0x0(%r13)
   830eb:	48 89 ef             	mov    %rbp,%rdi
   830ee:	48 8b 34 24          	mov    (%rsp),%rsi
   830f2:	4c 89 fa             	mov    %r15,%rdx
   830f5:	e8 56 de 00 00       	call   90f50 <<oriole::Parser>::consume>
   830fa:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   83101:	ff 
   83102:	0f 85 d7 1f 00 00    	jne    850df <<oriole::Parser>::next_event_inner+0x3c2f>
   83108:	4c 8b 3c 24          	mov    (%rsp),%r15
   8310c:	e9 cf e6 ff ff       	jmp    817e0 <<oriole::Parser>::next_event_inner+0x330>
   83111:	c1 e1 0c             	shl    $0xc,%ecx
   83114:	09 ca                	or     %ecx,%edx
   83116:	89 d1                	mov    %edx,%ecx
   83118:	83 f9 0d             	cmp    $0xd,%ecx
   8311b:	77 0a                	ja     83127 <<oriole::Parser>::next_event_inner+0x1c77>
   8311d:	ba 00 26 00 00       	mov    $0x2600,%edx
   83122:	0f a3 ca             	bt     %ecx,%edx
   83125:	72 34                	jb     8315b <<oriole::Parser>::next_event_inner+0x1cab>
   83127:	8d 91 00 28 ff ff    	lea    -0xd800(%rcx),%edx
   8312d:	81 fa 20 28 ff ff    	cmp    $0xffff2820,%edx
   83133:	0f 92 c2             	setb   %dl
   83136:	8d b1 02 00 ff ff    	lea    -0xfffe(%rcx),%esi
   8313c:	81 fe 02 e0 ff ff    	cmp    $0xffffe002,%esi
   83142:	40 0f 92 c6          	setb   %sil
   83146:	40 20 d6             	and    %dl,%sil
   83149:	81 f9 00 00 01 00    	cmp    $0x10000,%ecx
   8314f:	0f 92 c1             	setb   %cl
   83152:	40 84 ce             	test   %cl,%sil
   83155:	0f 85 e8 21 00 00    	jne    85343 <<oriole::Parser>::next_event_inner+0x3e93>
   8315b:	49 83 f8 03          	cmp    $0x3,%r8
   8315f:	72 1b                	jb     8317c <<oriole::Parser>::next_event_inner+0x1ccc>
   83161:	41 0f b7 0b          	movzwl (%r11),%ecx
   83165:	81 f1 3c 21 00 00    	xor    $0x213c,%ecx
   8316b:	41 0f b6 53 02       	movzbl 0x2(%r11),%edx
   83170:	83 f2 5b             	xor    $0x5b,%edx
   83173:	66 09 ca             	or     %cx,%dx
   83176:	0f 84 0a 01 00 00    	je     83286 <<oriole::Parser>::next_event_inner+0x1dd6>
   8317c:	83 fb 5d             	cmp    $0x5d,%ebx
   8317f:	0f 94 c1             	sete   %cl
   83182:	84 c1                	test   %al,%cl
   83184:	74 69                	je     831ef <<oriole::Parser>::next_event_inner+0x1d3f>
   83186:	49 83 f8 03          	cmp    $0x3,%r8
   8318a:	4c 8b 3c 24          	mov    (%rsp),%r15
   8318e:	0f 86 8c 00 00 00    	jbe    83220 <<oriole::Parser>::next_event_inner+0x1d70>
   83194:	41 0f b7 03          	movzwl (%r11),%eax
   83198:	35 5d 5d 00 00       	xor    $0x5d5d,%eax
   8319d:	41 0f b6 4b 02       	movzbl 0x2(%r11),%ecx
   831a2:	83 f1 3e             	xor    $0x3e,%ecx
   831a5:	66 09 c1             	or     %ax,%cx
   831a8:	0f 94 c1             	sete   %cl
   831ab:	49 8b 87 e8 03 00 00 	mov    0x3e8(%r15),%rax
   831b2:	48 85 c0             	test   %rax,%rax
   831b5:	0f 95 c2             	setne  %dl
   831b8:	84 d1                	test   %dl,%cl
   831ba:	0f 84 91 02 00 00    	je     83451 <<oriole::Parser>::next_event_inner+0x1fa1>
   831c0:	48 ff c8             	dec    %rax
   831c3:	49 89 87 e8 03 00 00 	mov    %rax,0x3e8(%r15)
   831ca:	ba 03 00 00 00       	mov    $0x3,%edx
   831cf:	48 89 ef             	mov    %rbp,%rdi
   831d2:	4c 89 fe             	mov    %r15,%rsi
   831d5:	e8 26 04 01 00       	call   93600 <<oriole::Parser>::conditional_raw>
   831da:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   831e1:	ff 
   831e2:	0f 85 86 02 00 00    	jne    8346e <<oriole::Parser>::next_event_inner+0x1fbe>
   831e8:	b0 01                	mov    $0x1,%al
   831ea:	e9 44 f1 ff ff       	jmp    82333 <<oriole::Parser>::next_event_inner+0xe83>
   831ef:	49 83 f8 02          	cmp    $0x2,%r8
   831f3:	0f 82 9d 03 00 00    	jb     83596 <<oriole::Parser>::next_event_inner+0x20e6>
   831f9:	66 41 81 3b 3c 21    	cmpw   $0x213c,(%r11)
   831ff:	0f 85 91 03 00 00    	jne    83596 <<oriole::Parser>::next_event_inner+0x20e6>
   83205:	49 83 f8 02          	cmp    $0x2,%r8
   83209:	0f 85 14 03 00 00    	jne    83523 <<oriole::Parser>::next_event_inner+0x2073>
   8320f:	66 41 81 3b 3c 21    	cmpw   $0x213c,(%r11)
   83215:	0f 85 29 03 00 00    	jne    83544 <<oriole::Parser>::next_event_inner+0x2094>
   8321b:	e9 76 03 00 00       	jmp    83596 <<oriole::Parser>::next_event_inner+0x20e6>
   83220:	4c 89 df             	mov    %r11,%rdi
   83223:	48 8d 35 c0 e1 f8 ff 	lea    -0x71e40(%rip),%rsi        # 113ea <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4a5e>
   8322a:	4c 89 c2             	mov    %r8,%rdx
   8322d:	ff 15 dd 3e 06 00    	call   *0x63edd(%rip)        # e7110 <bcmp@GLIBC_2.2.5>
   83233:	48 8b 8c 24 20 02 00 	mov    0x220(%rsp),%rcx
   8323a:	00 
   8323b:	48 83 f9 02          	cmp    $0x2,%rcx
   8323f:	0f 87 fa 01 00 00    	ja     8343f <<oriole::Parser>::next_event_inner+0x1f8f>
   83245:	85 c0                	test   %eax,%eax
   83247:	0f 85 f2 01 00 00    	jne    8343f <<oriole::Parser>::next_event_inner+0x1f8f>
   8324d:	48 83 bc 24 40 02 00 	cmpq   $0x1,0x240(%rsp)
   83254:	00 01 
   83256:	0f 85 f5 01 00 00    	jne    83451 <<oriole::Parser>::next_event_inner+0x1fa1>
   8325c:	41 0f b6 87 28 01 00 	movzbl 0x128(%r15),%eax
   83263:	00 
   83264:	34 01                	xor    $0x1,%al
   83266:	41 84 87 b8 08 00 00 	test   %al,0x8b8(%r15)
   8326d:	0f 85 de 01 00 00    	jne    83451 <<oriole::Parser>::next_event_inner+0x1fa1>
   83273:	41 80 bf f8 07 00 00 	cmpb   $0xff,0x7f8(%r15)
   8327a:	ff 
   8327b:	0f 84 2f 04 00 00    	je     836b0 <<oriole::Parser>::next_event_inner+0x2200>
   83281:	e9 cb 01 00 00       	jmp    83451 <<oriole::Parser>::next_event_inner+0x1fa1>
   83286:	a8 01                	test   $0x1,%al
   83288:	0f 84 46 21 00 00    	je     853d4 <<oriole::Parser>::next_event_inner+0x3f24>
   8328e:	4c 8b 3c 24          	mov    (%rsp),%r15
   83292:	49 8b 8f 48 08 00 00 	mov    0x848(%r15),%rcx
   83299:	48 8b 41 28          	mov    0x28(%rcx),%rax
   8329d:	49 8b 97 a8 07 00 00 	mov    0x7a8(%r15),%rdx
   832a4:	48 89 fb             	mov    %rdi,%rbx
   832a7:	48 3d ef fe ff ff    	cmp    $0xfffffffffffffeef,%rax
   832ad:	0f 87 ab 19 00 00    	ja     84c5e <<oriole::Parser>::next_event_inner+0x37ae>
   832b3:	48 8d b0 10 01 00 00 	lea    0x110(%rax),%rsi
   832ba:	48 39 d6             	cmp    %rdx,%rsi
   832bd:	0f 87 9b 19 00 00    	ja     84c5e <<oriole::Parser>::next_event_inner+0x37ae>
   832c3:	f0 48 0f b1 71 28    	lock cmpxchg %rsi,0x28(%rcx)
   832c9:	75 dc                	jne    832a7 <<oriole::Parser>::next_event_inner+0x1df7>
   832cb:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
   832d2:	00 
   832d3:	0f 10 00             	movups (%rax),%xmm0
   832d6:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   832da:	48 8d 8c 24 58 04 00 	lea    0x458(%rsp),%rcx
   832e1:	00 
   832e2:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
   832e6:	0f 11 01             	movups %xmm0,(%rcx)
   832e9:	0f 10 00             	movups (%rax),%xmm0
   832ec:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   832f0:	0f 29 8c 24 30 04 00 	movaps %xmm1,0x430(%rsp)
   832f7:	00 
   832f8:	0f 29 84 24 20 04 00 	movaps %xmm0,0x420(%rsp)
   832ff:	00 
   83300:	48 c7 84 24 40 04 00 	movq   $0x1,0x440(%rsp)
   83307:	00 01 00 00 00 
   8330c:	0f 57 c0             	xorps  %xmm0,%xmm0
   8330f:	0f 11 41 f0          	movups %xmm0,-0x10(%rcx)
   83313:	48 c7 84 24 78 04 00 	movq   $0x8,0x478(%rsp)
   8331a:	00 08 00 00 00 
   8331f:	0f 11 41 28          	movups %xmm0,0x28(%rcx)
   83323:	f3 0f 6f 00          	movdqu (%rax),%xmm0
   83327:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
   8332c:	66 0f 7f 8c 24 50 03 	movdqa %xmm1,0x350(%rsp)
   83333:	00 00 
   83335:	66 0f 7f 84 24 40 03 	movdqa %xmm0,0x340(%rsp)
   8333c:	00 00 
   8333e:	ba 03 00 00 00       	mov    $0x3,%edx
   83343:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
   8334a:	00 
   8334b:	48 8d 35 fb e2 f8 ff 	lea    -0x71d05(%rip),%rsi        # 1164d <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4cc1>
   83352:	48 8d 8c 24 40 03 00 	lea    0x340(%rsp),%rcx
   83359:	00 
   8335a:	ff 15 30 35 06 00    	call   *0x63530(%rip)        # e6890 <_GLOBAL_OFFSET_TABLE_+0x158>
   83360:	48 8b 84 24 90 03 00 	mov    0x390(%rsp),%rax
   83367:	00 
   83368:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   8336c:	0f 84 5e 04 00 00    	je     837d0 <<oriole::Parser>::next_event_inner+0x2320>
   83372:	48 8b 8c 24 98 03 00 	mov    0x398(%rsp),%rcx
   83379:	00 
   8337a:	48 8b 94 24 a0 03 00 	mov    0x3a0(%rsp),%rdx
   83381:	00 
   83382:	48 8b b4 24 a8 03 00 	mov    0x3a8(%rsp),%rsi
   83389:	00 
   8338a:	4c 8d 94 24 b0 03 00 	lea    0x3b0(%rsp),%r10
   83391:	00 
   83392:	41 0f b6 7a 10       	movzbl 0x10(%r10),%edi
   83397:	4c 8d 8c 24 58 02 00 	lea    0x258(%rsp),%r9
   8339e:	00 
   8339f:	41 88 79 28          	mov    %dil,0x28(%r9)
   833a3:	f3 41 0f 6f 02       	movdqu (%r10),%xmm0
   833a8:	f3 41 0f 7f 41 18    	movdqu %xmm0,0x18(%r9)
   833ae:	41 8b 7a 11          	mov    0x11(%r10),%edi
   833b2:	45 8b 42 14          	mov    0x14(%r10),%r8d
   833b6:	45 89 41 2c          	mov    %r8d,0x2c(%r9)
   833ba:	41 89 79 29          	mov    %edi,0x29(%r9)
   833be:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
   833c5:	00 
   833c6:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
   833cd:	00 
   833ce:	48 89 94 24 60 02 00 	mov    %rdx,0x260(%rsp)
   833d5:	00 
   833d6:	48 89 b4 24 68 02 00 	mov    %rsi,0x268(%rsp)
   833dd:	00 
   833de:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
   833e5:	00 
   833e6:	48 89 8c 24 90 02 00 	mov    %rcx,0x290(%rsp)
   833ed:	00 
   833ee:	48 89 94 24 98 02 00 	mov    %rdx,0x298(%rsp)
   833f5:	00 
   833f6:	48 89 b4 24 a0 02 00 	mov    %rsi,0x2a0(%rsp)
   833fd:	00 
   833fe:	48 c7 84 24 a8 02 00 	movq   $0x8,0x2a8(%rsp)
   83405:	00 08 00 00 00 
   8340a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   8340e:	f3 41 0f 7f 41 58    	movdqu %xmm0,0x58(%r9)
   83414:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   83419:	83 3f 01             	cmpl   $0x1,(%rdi)
   8341c:	0f 85 ec 03 00 00    	jne    8380e <<oriole::Parser>::next_event_inner+0x235e>
   83422:	48 89 d8             	mov    %rbx,%rax
   83425:	48 8b 9b 88 fe ff ff 	mov    -0x178(%rbx),%rbx
   8342c:	0f 10 a0 90 fe ff ff 	movups -0x170(%rax),%xmm4
   83433:	48 8b 80 a0 fe ff ff 	mov    -0x160(%rax),%rax
   8343a:	e9 ef 03 00 00       	jmp    8382e <<oriole::Parser>::next_event_inner+0x237e>
   8343f:	48 83 f9 03          	cmp    $0x3,%rcx
   83443:	4c 8b 9c 24 38 02 00 	mov    0x238(%rsp),%r11
   8344a:	00 
   8344b:	0f 83 43 fd ff ff    	jae    83194 <<oriole::Parser>::next_event_inner+0x1ce4>
   83451:	41 b8 30 00 00 00    	mov    $0x30,%r8d
   83457:	48 89 ef             	mov    %rbp,%rdi
   8345a:	4c 89 fe             	mov    %r15,%rsi
   8345d:	ba 01 00 00 00       	mov    $0x1,%edx
   83462:	48 8d 0d 47 e9 f8 ff 	lea    -0x716b9(%rip),%rcx        # 11db0 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5424>
   83469:	e8 02 d0 00 00       	call   90470 <<oriole::Parser>::err>
   8346e:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   83475:	00 
   83476:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   8347b:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   83482:	00 00 
   83484:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   8348b:	00 00 
   8348d:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   83494:	00 00 
   83496:	66 0f 7f 54 24 40    	movdqa %xmm2,0x40(%rsp)
   8349c:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   834a2:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   834a8:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
   834ad:	3c ff                	cmp    $0xff,%al
   834af:	0f 85 12 18 00 00    	jne    84cc7 <<oriole::Parser>::next_event_inner+0x3817>
   834b5:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
   834ba:	0f 85 20 e3 ff ff    	jne    817e0 <<oriole::Parser>::next_event_inner+0x330>
   834c0:	e9 7f 1c 00 00       	jmp    85144 <<oriole::Parser>::next_event_inner+0x3c94>
   834c5:	48 8b 38             	mov    (%rax),%rdi
   834c8:	49 b8 3c 21 5b 43 44 	movabs $0x41544144435b213c,%r8
   834cf:	41 54 41 
   834d2:	4c 31 c7             	xor    %r8,%rdi
   834d5:	44 0f b6 40 08       	movzbl 0x8(%rax),%r8d
   834da:	49 83 f0 5b          	xor    $0x5b,%r8
   834de:	49 09 f8             	or     %rdi,%r8
   834e1:	0f 84 88 02 00 00    	je     8376f <<oriole::Parser>::next_event_inner+0x22bf>
   834e7:	66 81 38 3c 3f       	cmpw   $0x3f3c,(%rax)
   834ec:	0f 84 61 06 00 00    	je     83b53 <<oriole::Parser>::next_event_inner+0x26a3>
   834f2:	48 8b 10             	mov    (%rax),%rdx
   834f5:	48 be 3c 21 44 4f 43 	movabs $0x505954434f44213c,%rsi
   834fc:	54 59 50 
   834ff:	48 31 f2             	xor    %rsi,%rdx
   83502:	0f b6 70 08          	movzbl 0x8(%rax),%esi
   83506:	48 83 f6 45          	xor    $0x45,%rsi
   8350a:	48 09 d6             	or     %rdx,%rsi
   8350d:	0f 84 c9 07 00 00    	je     83cdc <<oriole::Parser>::next_event_inner+0x282c>
   83513:	66 81 38 3c 2f       	cmpw   $0x2f3c,(%rax)
   83518:	0f 85 77 ef ff ff    	jne    82495 <<oriole::Parser>::next_event_inner+0xfe5>
   8351e:	e9 7d ef ff ff       	jmp    824a0 <<oriole::Parser>::next_event_inner+0xff0>
   83523:	41 0f b7 03          	movzwl (%r11),%eax
   83527:	35 3c 21 00 00       	xor    $0x213c,%eax
   8352c:	41 0f b6 4b 02       	movzbl 0x2(%r11),%ecx
   83531:	83 f1 2d             	xor    $0x2d,%ecx
   83534:	66 09 c1             	or     %ax,%cx
   83537:	74 5d                	je     83596 <<oriole::Parser>::next_event_inner+0x20e6>
   83539:	41 80 7b 02 c0       	cmpb   $0xc0,0x2(%r11)
   8353e:	0f 8c 0f 22 00 00    	jl     85753 <<oriole::Parser>::next_event_inner+0x42a3>
   83544:	49 8d 43 02          	lea    0x2(%r11),%rax
   83548:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   8354f:	00 
   83550:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
   83557:	00 
   83558:	48 89 ef             	mov    %rbp,%rdi
   8355b:	e8 e0 71 fc ff       	call   4a740 <core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>>
   83560:	a8 01                	test   $0x1,%al
   83562:	74 1a                	je     8357e <<oriole::Parser>::next_event_inner+0x20ce>
   83564:	48 8b 04 24          	mov    (%rsp),%rax
   83568:	0f b6 b8 cc 07 00 00 	movzbl 0x7cc(%rax),%edi
   8356f:	89 d6                	mov    %edx,%esi
   83571:	e8 ca 26 fd ff       	call   55c40 <<oriole::names::NameRules>::is_name_start>
   83576:	84 c0                	test   %al,%al
   83578:	0f 84 a7 07 00 00    	je     83d25 <<oriole::Parser>::next_event_inner+0x2875>
   8357e:	4c 8b 94 24 40 02 00 	mov    0x240(%rsp),%r10
   83585:	00 
   83586:	4c 8b 9c 24 38 02 00 	mov    0x238(%rsp),%r11
   8358d:	00 
   8358e:	4c 8b 84 24 20 02 00 	mov    0x220(%rsp),%r8
   83595:	00 
   83596:	83 fb 25             	cmp    $0x25,%ebx
   83599:	75 16                	jne    835b1 <<oriole::Parser>::next_event_inner+0x2101>
   8359b:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   835a0:	4c 8b 3c 24          	mov    (%rsp),%r15
   835a4:	4c 89 fe             	mov    %r15,%rsi
   835a7:	e8 e4 7d fe ff       	call   6b390 <<oriole::Parser>::parse_parameter_reference>
   835ac:	e9 f7 fe ff ff       	jmp    834a8 <<oriole::Parser>::next_event_inner+0x1ff8>
   835b1:	83 fb 5d             	cmp    $0x5d,%ebx
   835b4:	0f 94 c0             	sete   %al
   835b7:	44 84 f8             	test   %r15b,%al
   835ba:	0f 84 b2 00 00 00    	je     83672 <<oriole::Parser>::next_event_inner+0x21c2>
   835c0:	49 83 fa 01          	cmp    $0x1,%r10
   835c4:	4c 8b 3c 24          	mov    (%rsp),%r15
   835c8:	0f 85 35 01 00 00    	jne    83703 <<oriole::Parser>::next_event_inner+0x2253>
   835ce:	49 8b 8f 98 07 00 00 	mov    0x798(%r15),%rcx
   835d5:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   835dc:	00 
   835dd:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   835e2:	31 d2                	xor    %edx,%edx
   835e4:	e8 07 a8 fe ff       	call   6ddf0 <<oriole::encoding::Source>::scan_token>
   835e9:	4c 89 fb             	mov    %r15,%rbx
   835ec:	4c 8b bc 24 60 02 00 	mov    0x260(%rsp),%r15
   835f3:	00 
   835f4:	80 bc 24 50 02 00 00 	cmpb   $0x0,0x250(%rsp)
   835fb:	00 
   835fc:	0f 84 85 04 00 00    	je     83a87 <<oriole::Parser>::next_event_inner+0x25d7>
   83602:	8b 8c 24 58 02 00 00 	mov    0x258(%rsp),%ecx
   83609:	48 8b b3 80 01 00 00 	mov    0x180(%rbx),%rsi
   83610:	48 8b 93 90 01 00 00 	mov    0x190(%rbx),%rdx
   83617:	48 89 ef             	mov    %rbp,%rdi
   8361a:	4d 89 f8             	mov    %r15,%r8
   8361d:	e8 0e 92 fc ff       	call   4c830 <<oriole::Parser>::parse_dtd_step::{closure#4}>
   83622:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
   83629:	00 
   8362a:	0f 28 00             	movaps (%rax),%xmm0
   8362d:	66 0f 6f 48 10       	movdqa 0x10(%rax),%xmm1
   83632:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   83637:	66 0f 7f 4e 10       	movdqa %xmm1,0x10(%rsi)
   8363c:	0f 29 06             	movaps %xmm0,(%rsi)
   8363f:	0f b6 84 24 b0 00 00 	movzbl 0xb0(%rsp),%eax
   83646:	00 
   83647:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   8364e:	00 
   8364f:	8b 4a 29             	mov    0x29(%rdx),%ecx
   83652:	8b 52 2c             	mov    0x2c(%rdx),%edx
   83655:	89 56 24             	mov    %edx,0x24(%rsi)
   83658:	89 4e 21             	mov    %ecx,0x21(%rsi)
   8365b:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
   83662:	00 00 
   83664:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   8366a:	49 89 df             	mov    %rbx,%r15
   8366d:	e9 3b fe ff ff       	jmp    834ad <<oriole::Parser>::next_event_inner+0x1ffd>
   83672:	4c 89 df             	mov    %r11,%rdi
   83675:	4c 89 c6             	mov    %r8,%rsi
   83678:	e8 43 f3 01 00       	call   a29c0 <<&str as core::slice::cmp::SliceContains>::slice_contains>
   8367d:	48 8b 8c 24 40 02 00 	mov    0x240(%rsp),%rcx
   83684:	00 
   83685:	48 83 f9 01          	cmp    $0x1,%rcx
   83689:	4c 8b 3c 24          	mov    (%rsp),%r15
   8368d:	75 28                	jne    836b7 <<oriole::Parser>::next_event_inner+0x2207>
   8368f:	84 c0                	test   %al,%al
   83691:	74 24                	je     836b7 <<oriole::Parser>::next_event_inner+0x2207>
   83693:	41 0f b6 87 28 01 00 	movzbl 0x128(%r15),%eax
   8369a:	00 
   8369b:	34 01                	xor    $0x1,%al
   8369d:	41 84 87 b8 08 00 00 	test   %al,0x8b8(%r15)
   836a4:	75 11                	jne    836b7 <<oriole::Parser>::next_event_inner+0x2207>
   836a6:	41 80 bf f8 07 00 00 	cmpb   $0xff,0x7f8(%r15)
   836ad:	ff 
   836ae:	75 07                	jne    836b7 <<oriole::Parser>::next_event_inner+0x2207>
   836b0:	31 c0                	xor    %eax,%eax
   836b2:	e9 7c ec ff ff       	jmp    82333 <<oriole::Parser>::next_event_inner+0xe83>
   836b7:	4c 8b a4 24 20 02 00 	mov    0x220(%rsp),%r12
   836be:	00 
   836bf:	49 83 fc 04          	cmp    $0x4,%r12
   836c3:	73 5b                	jae    83720 <<oriole::Parser>::next_event_inner+0x2270>
   836c5:	49 83 fc 02          	cmp    $0x2,%r12
   836c9:	48 8b bc 24 38 02 00 	mov    0x238(%rsp),%rdi
   836d0:	00 
   836d1:	73 61                	jae    83734 <<oriole::Parser>::next_event_inner+0x2284>
   836d3:	49 83 fc 01          	cmp    $0x1,%r12
   836d7:	75 71                	jne    8374a <<oriole::Parser>::next_event_inner+0x229a>
   836d9:	48 83 f9 01          	cmp    $0x1,%rcx
   836dd:	75 6b                	jne    8374a <<oriole::Parser>::next_event_inner+0x229a>
   836df:	80 3f 3c             	cmpb   $0x3c,(%rdi)
   836e2:	75 66                	jne    8374a <<oriole::Parser>::next_event_inner+0x229a>
   836e4:	41 0f b6 87 28 01 00 	movzbl 0x128(%r15),%eax
   836eb:	00 
   836ec:	34 01                	xor    $0x1,%al
   836ee:	41 84 87 b8 08 00 00 	test   %al,0x8b8(%r15)
   836f5:	75 53                	jne    8374a <<oriole::Parser>::next_event_inner+0x229a>
   836f7:	41 80 bf f8 07 00 00 	cmpb   $0xff,0x7f8(%r15)
   836fe:	ff 
   836ff:	74 af                	je     836b0 <<oriole::Parser>::next_event_inner+0x2200>
   83701:	eb 47                	jmp    8374a <<oriole::Parser>::next_event_inner+0x229a>
   83703:	41 b8 2d 00 00 00    	mov    $0x2d,%r8d
   83709:	48 89 ef             	mov    %rbp,%rdi
   8370c:	4c 89 fe             	mov    %r15,%rsi
   8370f:	ba 03 00 00 00       	mov    $0x3,%edx
   83714:	48 8d 0d 68 e6 f8 ff 	lea    -0x71998(%rip),%rcx        # 11d83 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x53f7>
   8371b:	e9 49 fd ff ff       	jmp    83469 <<oriole::Parser>::next_event_inner+0x1fb9>
   83720:	48 8b bc 24 38 02 00 	mov    0x238(%rsp),%rdi
   83727:	00 
   83728:	81 3f 3c 21 2d 2d    	cmpl   $0x2d2d213c,(%rdi)
   8372e:	0f 84 a3 05 00 00    	je     83cd7 <<oriole::Parser>::next_event_inner+0x2827>
   83734:	66 81 3f 3c 3f       	cmpw   $0x3f3c,(%rdi)
   83739:	0f 84 3a 05 00 00    	je     83c79 <<oriole::Parser>::next_event_inner+0x27c9>
   8373f:	66 81 3f 3c 21       	cmpw   $0x213c,(%rdi)
   83744:	0f 84 07 06 00 00    	je     83d51 <<oriole::Parser>::next_event_inner+0x28a1>
   8374a:	4c 89 e6             	mov    %r12,%rsi
   8374d:	48 89 fb             	mov    %rdi,%rbx
   83750:	e8 3b fc 01 00       	call   a3390 <<core::str::pattern::MultiCharEqPattern<[char; 2]> as core::str::pattern::Pattern>::is_prefix_of>
   83755:	84 c0                	test   %al,%al
   83757:	0f 84 d5 04 00 00    	je     83c32 <<oriole::Parser>::next_event_inner+0x2782>
   8375d:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   83762:	4c 89 fe             	mov    %r15,%rsi
   83765:	e8 f6 61 00 00       	call   89960 <<oriole::Parser>::parse_prolog_literal>
   8376a:	e9 39 fd ff ff       	jmp    834a8 <<oriole::Parser>::next_event_inner+0x1ff8>
   8376f:	48 85 d2             	test   %rdx,%rdx
   83772:	0f 95 c0             	setne  %al
   83775:	40 08 f0             	or     %sil,%al
   83778:	a8 01                	test   $0x1,%al
   8377a:	0f 84 89 1d 00 00    	je     85509 <<oriole::Parser>::next_event_inner+0x4059>
   83780:	49 8b 87 90 01 00 00 	mov    0x190(%r15),%rax
   83787:	48 85 c0             	test   %rax,%rax
   8378a:	0f 84 d2 18 00 00    	je     85062 <<oriole::Parser>::next_event_inner+0x3bb2>
   83790:	49 8b 8f 80 01 00 00 	mov    0x180(%r15),%rcx
   83797:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   8379b:	48 c1 e2 07          	shl    $0x7,%rdx
   8379f:	48 8d 04 11          	lea    (%rcx,%rdx,1),%rax
   837a3:	83 bc 11 80 fe ff ff 	cmpl   $0x1,-0x180(%rcx,%rdx,1)
   837aa:	01 
   837ab:	0f 85 b9 03 00 00    	jne    83b6a <<oriole::Parser>::next_event_inner+0x26ba>
   837b1:	4c 8b a0 88 fe ff ff 	mov    -0x178(%rax),%r12
   837b8:	0f 10 80 90 fe ff ff 	movups -0x170(%rax),%xmm0
   837bf:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   837c4:	48 8b 98 a0 fe ff ff 	mov    -0x160(%rax),%rbx
   837cb:	e9 c1 03 00 00       	jmp    83b91 <<oriole::Parser>::next_event_inner+0x26e1>
   837d0:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   837d5:	66 0f ef c0          	pxor   %xmm0,%xmm0
   837d9:	66 0f 7f 40 10       	movdqa %xmm0,0x10(%rax)
   837de:	c6 40 20 00          	movb   $0x0,0x20(%rax)
   837e2:	48 8d 05 b3 dc f8 ff 	lea    -0x7234d(%rip),%rax        # 1149c <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   837e9:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   837ee:	48 c7 44 24 28 0d 00 	movq   $0xd,0x28(%rsp)
   837f5:	00 00 
   837f7:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   837fe:	00 00 
   83800:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
   83807:	00 00 
   83809:	e9 9a fc ff ff       	jmp    834a8 <<oriole::Parser>::next_event_inner+0x1ff8>
   8380e:	48 89 d8             	mov    %rbx,%rax
   83811:	48 8b 5b a8          	mov    -0x58(%rbx),%rbx
   83815:	f3 0f 6f 40 d8       	movdqu -0x28(%rax),%xmm0
   8381a:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
   83820:	31 f6                	xor    %esi,%esi
   83822:	31 d2                	xor    %edx,%edx
   83824:	e8 27 bf fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   83829:	0f 28 64 24 70       	movaps 0x70(%rsp),%xmm4
   8382e:	c6 84 24 88 01 00 00 	movb   $0x2,0x188(%rsp)
   83835:	02 
   83836:	0f 28 84 24 20 04 00 	movaps 0x420(%rsp),%xmm0
   8383d:	00 
   8383e:	0f 28 8c 24 30 04 00 	movaps 0x430(%rsp),%xmm1
   83845:	00 
   83846:	0f 28 94 24 40 04 00 	movaps 0x440(%rsp),%xmm2
   8384d:	00 
   8384e:	0f 28 9c 24 50 04 00 	movaps 0x450(%rsp),%xmm3
   83855:	00 
   83856:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   8385d:	00 
   8385e:	0f 29 8c 24 90 00 00 	movaps %xmm1,0x90(%rsp)
   83865:	00 
   83866:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
   8386d:	00 
   8386e:	0f 29 9c 24 b0 00 00 	movaps %xmm3,0xb0(%rsp)
   83875:	00 
   83876:	0f 28 84 24 60 04 00 	movaps 0x460(%rsp),%xmm0
   8387d:	00 
   8387e:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   83885:	00 
   83886:	0f 28 84 24 70 04 00 	movaps 0x470(%rsp),%xmm0
   8388d:	00 
   8388e:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   83895:	00 
   83896:	0f 28 84 24 80 04 00 	movaps 0x480(%rsp),%xmm0
   8389d:	00 
   8389e:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   838a5:	00 
   838a6:	0f 10 84 24 b0 02 00 	movups 0x2b0(%rsp),%xmm0
   838ad:	00 
   838ae:	48 8d 8c 24 88 00 00 	lea    0x88(%rsp),%rcx
   838b5:	00 
   838b6:	0f 11 81 c8 00 00 00 	movups %xmm0,0xc8(%rcx)
   838bd:	0f 10 84 24 a0 02 00 	movups 0x2a0(%rsp),%xmm0
   838c4:	00 
   838c5:	0f 11 81 b8 00 00 00 	movups %xmm0,0xb8(%rcx)
   838cc:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   838d3:	00 
   838d4:	0f 11 81 a8 00 00 00 	movups %xmm0,0xa8(%rcx)
   838db:	0f 10 84 24 50 02 00 	movups 0x250(%rsp),%xmm0
   838e2:	00 
   838e3:	0f 10 8c 24 60 02 00 	movups 0x260(%rsp),%xmm1
   838ea:	00 
   838eb:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   838f2:	00 00 
   838f4:	0f 10 9c 24 80 02 00 	movups 0x280(%rsp),%xmm3
   838fb:	00 
   838fc:	0f 11 99 98 00 00 00 	movups %xmm3,0x98(%rcx)
   83903:	f3 0f 7f 91 88 00 00 	movdqu %xmm2,0x88(%rcx)
   8390a:	00 
   8390b:	0f 11 49 78          	movups %xmm1,0x78(%rcx)
   8390f:	0f 11 41 68          	movups %xmm0,0x68(%rcx)
   83913:	48 89 9c 24 60 01 00 	mov    %rbx,0x160(%rsp)
   8391a:	00 
   8391b:	0f 11 a4 24 68 01 00 	movups %xmm4,0x168(%rsp)
   83922:	00 
   83923:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
   8392a:	00 
   8392b:	48 c7 84 24 80 01 00 	movq   $0x3,0x180(%rsp)
   83932:	00 03 00 00 00 
   83937:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
   8393e:	00 
   8393f:	f3 0f 6f 00          	movdqu (%rax),%xmm0
   83943:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
   83948:	66 0f 7f 8c 24 60 02 	movdqa %xmm1,0x260(%rsp)
   8394f:	00 00 
   83951:	66 0f 7f 84 24 50 02 	movdqa %xmm0,0x250(%rsp)
   83958:	00 00 
   8395a:	be 08 00 00 00       	mov    $0x8,%esi
   8395f:	ba 10 01 00 00       	mov    $0x110,%edx
   83964:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   8396b:	00 
   8396c:	ff 15 16 2f 06 00    	call   *0x62f16(%rip)        # e6888 <_GLOBAL_OFFSET_TABLE_+0x150>
   83972:	48 85 c0             	test   %rax,%rax
   83975:	0f 84 c6 00 00 00    	je     83a41 <<oriole::Parser>::next_event_inner+0x2591>
   8397b:	48 8b 9c 24 50 02 00 	mov    0x250(%rsp),%rbx
   83982:	00 
   83983:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
   83987:	0f 84 b4 00 00 00    	je     83a41 <<oriole::Parser>::next_event_inner+0x2591>
   8398d:	49 89 ee             	mov    %rbp,%r14
   83990:	0f b6 ac 24 58 02 00 	movzbl 0x258(%rsp),%ebp
   83997:	00 
   83998:	48 8b 8c 24 20 05 00 	mov    0x520(%rsp),%rcx
   8399f:	00 
   839a0:	0f 10 01             	movups (%rcx),%xmm0
   839a3:	0f 29 84 24 70 03 00 	movaps %xmm0,0x370(%rsp)
   839aa:	00 
   839ab:	48 8b 49 0f          	mov    0xf(%rcx),%rcx
   839af:	48 89 8c 24 7f 03 00 	mov    %rcx,0x37f(%rsp)
   839b6:	00 
   839b7:	ba 10 01 00 00       	mov    $0x110,%edx
   839bc:	48 89 c7             	mov    %rax,%rdi
   839bf:	4c 89 f6             	mov    %r14,%rsi
   839c2:	49 89 c7             	mov    %rax,%r15
   839c5:	ff 15 d5 36 06 00    	call   *0x636d5(%rip)        # e70a0 <memmove@GLIBC_2.2.5>
   839cb:	48 8b 04 24          	mov    (%rsp),%rax
   839cf:	48 89 98 f0 03 00 00 	mov    %rbx,0x3f0(%rax)
   839d6:	48 8b 04 24          	mov    (%rsp),%rax
   839da:	40 88 a8 f8 03 00 00 	mov    %bpl,0x3f8(%rax)
   839e1:	48 8b 84 24 7f 03 00 	mov    0x37f(%rsp),%rax
   839e8:	00 
   839e9:	48 8b 8c 24 18 05 00 	mov    0x518(%rsp),%rcx
   839f0:	00 
   839f1:	48 89 41 0f          	mov    %rax,0xf(%rcx)
   839f5:	66 0f 6f 84 24 70 03 	movdqa 0x370(%rsp),%xmm0
   839fc:	00 00 
   839fe:	f3 0f 7f 01          	movdqu %xmm0,(%rcx)
   83a02:	48 8b 04 24          	mov    (%rsp),%rax
   83a06:	4c 89 b8 10 04 00 00 	mov    %r15,0x410(%rax)
   83a0d:	4c 8b 3c 24          	mov    (%rsp),%r15
   83a11:	ba 03 00 00 00       	mov    $0x3,%edx
   83a16:	4c 89 f7             	mov    %r14,%rdi
   83a19:	4c 89 fe             	mov    %r15,%rsi
   83a1c:	e8 2f d5 00 00       	call   90f50 <<oriole::Parser>::consume>
   83a21:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   83a28:	ff 
   83a29:	0f 85 5e e7 ff ff    	jne    8218d <<oriole::Parser>::next_event_inner+0xcdd>
   83a2f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   83a34:	4c 89 fe             	mov    %r15,%rsi
   83a37:	e8 24 46 fd ff       	call   58060 <<oriole::Parser>::continue_header_composition>
   83a3c:	e9 86 e7 ff ff       	jmp    821c7 <<oriole::Parser>::next_event_inner+0xd17>
   83a41:	48 89 ef             	mov    %rbp,%rdi
   83a44:	e8 27 63 fc ff       	call   49d70 <core::ptr::drop_glue::<oriole::dtd::composition::Header>>
   83a49:	48 8d 05 4c da f8 ff 	lea    -0x725b4(%rip),%rax        # 1149c <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   83a50:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   83a55:	48 c7 44 24 28 0d 00 	movq   $0xd,0x28(%rsp)
   83a5c:	00 00 
   83a5e:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   83a65:	00 00 
   83a67:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
   83a6e:	00 00 
   83a70:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   83a75:	66 0f ef c0          	pxor   %xmm0,%xmm0
   83a79:	66 0f 7f 40 10       	movdqa %xmm0,0x10(%rax)
   83a7e:	c6 40 20 00          	movb   $0x0,0x20(%rax)
   83a82:	e9 21 fa ff ff       	jmp    834a8 <<oriole::Parser>::next_event_inner+0x1ff8>
   83a87:	48 8b 83 90 01 00 00 	mov    0x190(%rbx),%rax
   83a8e:	83 bc 24 58 02 00 00 	cmpl   $0x1,0x258(%rsp)
   83a95:	01 
   83a96:	0f 85 5e 02 00 00    	jne    83cfa <<oriole::Parser>::next_event_inner+0x284a>
   83a9c:	48 85 c0             	test   %rax,%rax
   83a9f:	0f 84 bd 15 00 00    	je     85062 <<oriole::Parser>::next_event_inner+0x3bb2>
   83aa5:	49 89 ec             	mov    %rbp,%r12
   83aa8:	48 8b 0c 24          	mov    (%rsp),%rcx
   83aac:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   83ab3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   83ab7:	48 c1 e0 07          	shl    $0x7,%rax
   83abb:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
   83abf:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   83ac6:	e8 35 bf fe ff       	call   6fa00 <<oriole::encoding::Source>::remaining>
   83acb:	49 89 c5             	mov    %rax,%r13
   83ace:	48 89 d5             	mov    %rdx,%rbp
   83ad1:	49 8d 4f ff          	lea    -0x1(%r15),%rcx
   83ad5:	4d 8d 77 fe          	lea    -0x2(%r15),%r14
   83ad9:	49 39 d6             	cmp    %rdx,%r14
   83adc:	0f 83 39 1b 00 00    	jae    8561b <<oriole::Parser>::next_event_inner+0x416b>
   83ae2:	48 83 fd 01          	cmp    $0x1,%rbp
   83ae6:	74 1c                	je     83b04 <<oriole::Parser>::next_event_inner+0x2654>
   83ae8:	41 80 7d 01 c0       	cmpb   $0xc0,0x1(%r13)
   83aed:	0f 8c 28 1b 00 00    	jl     8561b <<oriole::Parser>::next_event_inner+0x416b>
   83af3:	48 39 e9             	cmp    %rbp,%rcx
   83af6:	74 0c                	je     83b04 <<oriole::Parser>::next_event_inner+0x2654>
   83af8:	41 80 7c 0d 00 bf    	cmpb   $0xbf,0x0(%r13,%rcx,1)
   83afe:	0f 8e 17 1b 00 00    	jle    8561b <<oriole::Parser>::next_event_inner+0x416b>
   83b04:	49 8d 45 01          	lea    0x1(%r13),%rax
   83b08:	4b 8d 0c 2f          	lea    (%r15,%r13,1),%rcx
   83b0c:	48 ff c9             	dec    %rcx
   83b0f:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   83b16:	00 
   83b17:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
   83b1e:	00 
   83b1f:	4c 89 e7             	mov    %r12,%rdi
   83b22:	e8 f9 89 fc ff       	call   4c520 <<core::str::iter::Chars as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::all::check<char, oriole::names::whitespace>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
   83b27:	84 c0                	test   %al,%al
   83b29:	0f 84 57 04 00 00    	je     83f86 <<oriole::Parser>::next_event_inner+0x2ad6>
   83b2f:	41 b8 29 00 00 00    	mov    $0x29,%r8d
   83b35:	4c 89 e5             	mov    %r12,%rbp
   83b38:	4c 89 e7             	mov    %r12,%rdi
   83b3b:	4c 8b 3c 24          	mov    (%rsp),%r15
   83b3f:	4c 89 fe             	mov    %r15,%rsi
   83b42:	ba 01 00 00 00       	mov    $0x1,%edx
   83b47:	48 8d 0d ea e1 f8 ff 	lea    -0x71e16(%rip),%rcx        # 11d38 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x53ac>
   83b4e:	e9 16 f9 ff ff       	jmp    83469 <<oriole::Parser>::next_event_inner+0x1fb9>
   83b53:	c6 84 24 40 03 00 00 	movb   $0x2,0x340(%rsp)
   83b5a:	02 
   83b5b:	80 78 02 c0          	cmpb   $0xc0,0x2(%rax)
   83b5f:	0f 8d 69 ea ff ff    	jge    825ce <<oriole::Parser>::next_event_inner+0x111e>
   83b65:	e9 56 1b 00 00       	jmp    856c0 <<oriole::Parser>::next_event_inner+0x4210>
   83b6a:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
   83b6e:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   83b75:	4c 8b 60 a8          	mov    -0x58(%rax),%r12
   83b79:	0f 10 40 d8          	movups -0x28(%rax),%xmm0
   83b7d:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   83b82:	ba 09 00 00 00       	mov    $0x9,%edx
   83b87:	31 f6                	xor    %esi,%esi
   83b89:	e8 c2 bb fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   83b8e:	48 89 c3             	mov    %rax,%rbx
   83b91:	ba 09 00 00 00       	mov    $0x9,%edx
   83b96:	48 89 ef             	mov    %rbp,%rdi
   83b99:	49 89 ef             	mov    %rbp,%r15
   83b9c:	48 8b 2c 24          	mov    (%rsp),%rbp
   83ba0:	48 89 ee             	mov    %rbp,%rsi
   83ba3:	e8 38 1e 00 00       	call   859e0 <<oriole::Parser>::save_current_raw>
   83ba8:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   83baf:	ff 
   83bb0:	0f 85 29 15 00 00    	jne    850df <<oriole::Parser>::next_event_inner+0x3c2f>
   83bb6:	ba 09 00 00 00       	mov    $0x9,%edx
   83bbb:	4c 89 ff             	mov    %r15,%rdi
   83bbe:	48 89 ee             	mov    %rbp,%rsi
   83bc1:	e8 8a d3 00 00       	call   90f50 <<oriole::Parser>::consume>
   83bc6:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   83bcd:	ff 
   83bce:	0f 85 0b 15 00 00    	jne    850df <<oriole::Parser>::next_event_inner+0x3c2f>
   83bd4:	c6 85 b7 08 00 00 01 	movb   $0x1,0x8b7(%rbp)
   83bdb:	48 c7 84 24 b8 00 00 	movq   $0xe,0xb8(%rsp)
   83be2:	00 0e 00 00 00 
   83be7:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
   83bee:	00 
   83bef:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   83bf5:	f3 0f 7f 84 24 38 01 	movdqu %xmm0,0x138(%rsp)
   83bfc:	00 00 
   83bfe:	48 89 9c 24 48 01 00 	mov    %rbx,0x148(%rsp)
   83c05:	00 
   83c06:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   83c0d:	00 ff ff ff ff 
   83c12:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   83c19:	00 
   83c1a:	4d 89 fc             	mov    %r15,%r12
   83c1d:	4c 89 fe             	mov    %r15,%rsi
   83c20:	e8 9b 37 fd ff       	call   573c0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   83c25:	3c ff                	cmp    $0xff,%al
   83c27:	0f 84 27 f1 ff ff    	je     82d54 <<oriole::Parser>::next_event_inner+0x18a4>
   83c2d:	e9 f9 18 00 00       	jmp    8552b <<oriole::Parser>::next_event_inner+0x407b>
   83c32:	31 d2                	xor    %edx,%edx
   83c34:	41 83 bf c8 07 00 00 	cmpl   $0xffffffff,0x7c8(%r15)
   83c3b:	ff 
   83c3c:	0f 95 c2             	setne  %dl
   83c3f:	41 0f b6 8f cc 07 00 	movzbl 0x7cc(%r15),%ecx
   83c46:	00 
   83c47:	48 89 df             	mov    %rbx,%rdi
   83c4a:	4c 89 e6             	mov    %r12,%rsi
   83c4d:	e8 de c1 01 00       	call   9fe30 <oriole::dtd::invalid_dtd_token>
   83c52:	48 83 f8 01          	cmp    $0x1,%rax
   83c56:	0f 85 e3 02 00 00    	jne    83f3f <<oriole::Parser>::next_event_inner+0x2a8f>
   83c5c:	41 b8 14 00 00 00    	mov    $0x14,%r8d
   83c62:	48 89 ef             	mov    %rbp,%rdi
   83c65:	4c 89 fe             	mov    %r15,%rsi
   83c68:	ba 03 00 00 00       	mov    $0x3,%edx
   83c6d:	48 8d 0d 0e e0 f8 ff 	lea    -0x71ff2(%rip),%rcx        # 11c82 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x52f6>
   83c74:	e9 f0 f7 ff ff       	jmp    83469 <<oriole::Parser>::next_event_inner+0x1fb9>
   83c79:	49 8b 9f 98 07 00 00 	mov    0x798(%r15),%rbx
   83c80:	49 83 fc 02          	cmp    $0x2,%r12
   83c84:	74 0a                	je     83c90 <<oriole::Parser>::next_event_inner+0x27e0>
   83c86:	80 7f 02 bf          	cmpb   $0xbf,0x2(%rdi)
   83c8a:	0f 8e a6 1a 00 00    	jle    85736 <<oriole::Parser>::next_event_inner+0x4286>
   83c90:	48 83 c7 02          	add    $0x2,%rdi
   83c94:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
   83c9b:	00 
   83c9c:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
   83ca3:	00 
   83ca4:	48 89 ef             	mov    %rbp,%rdi
   83ca7:	e8 94 6a fc ff       	call   4a740 <core::str::validations::next_code_point::<core::slice::iter::Iter<u8>>>
   83cac:	a8 01                	test   $0x1,%al
   83cae:	74 1a                	je     83cca <<oriole::Parser>::next_event_inner+0x281a>
   83cb0:	48 8b 04 24          	mov    (%rsp),%rax
   83cb4:	0f b6 b8 cc 07 00 00 	movzbl 0x7cc(%rax),%edi
   83cbb:	89 d6                	mov    %edx,%esi
   83cbd:	e8 7e 1f fd ff       	call   55c40 <<oriole::names::NameRules>::is_name_start>
   83cc2:	84 c0                	test   %al,%al
   83cc4:	0f 84 63 03 00 00    	je     8402d <<oriole::Parser>::next_event_inner+0x2b7d>
   83cca:	40 b5 02             	mov    $0x2,%bpl
   83ccd:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   83cd2:	e9 89 00 00 00       	jmp    83d60 <<oriole::Parser>::next_event_inner+0x28b0>
   83cd7:	40 b5 01             	mov    $0x1,%bpl
   83cda:	eb 78                	jmp    83d54 <<oriole::Parser>::next_event_inner+0x28a4>
   83cdc:	c6 84 24 40 03 00 00 	movb   $0x3,0x340(%rsp)
   83ce3:	03 
   83ce4:	49 8b 87 90 01 00 00 	mov    0x190(%r15),%rax
   83ceb:	48 83 f8 01          	cmp    $0x1,%rax
   83cef:	0f 86 02 ef ff ff    	jbe    82bf7 <<oriole::Parser>::next_event_inner+0x1747>
   83cf5:	e9 19 ef ff ff       	jmp    82c13 <<oriole::Parser>::next_event_inner+0x1763>
   83cfa:	48 83 f8 01          	cmp    $0x1,%rax
   83cfe:	4c 8b 3c 24          	mov    (%rsp),%r15
   83d02:	0f 86 54 02 00 00    	jbe    83f5c <<oriole::Parser>::next_event_inner+0x2aac>
   83d08:	41 b8 22 00 00 00    	mov    $0x22,%r8d
   83d0e:	48 89 ef             	mov    %rbp,%rdi
   83d11:	4c 89 fe             	mov    %r15,%rsi
   83d14:	ba 04 00 00 00       	mov    $0x4,%edx
   83d19:	48 8d 0d 41 e0 f8 ff 	lea    -0x71fbf(%rip),%rcx        # 11d61 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x53d5>
   83d20:	e9 44 f7 ff ff       	jmp    83469 <<oriole::Parser>::next_event_inner+0x1fb9>
   83d25:	41 b8 1c 00 00 00    	mov    $0x1c,%r8d
   83d2b:	41 b9 02 00 00 00    	mov    $0x2,%r9d
   83d31:	48 89 ef             	mov    %rbp,%rdi
   83d34:	4c 8b 3c 24          	mov    (%rsp),%r15
   83d38:	4c 89 fe             	mov    %r15,%rsi
   83d3b:	ba 03 00 00 00       	mov    $0x3,%edx
   83d40:	48 8d 0d 1f df f8 ff 	lea    -0x720e1(%rip),%rcx        # 11c66 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x52da>
   83d47:	e8 84 d1 00 00       	call   90ed0 <<oriole::Parser>::err_at>
   83d4c:	e9 1d f7 ff ff       	jmp    8346e <<oriole::Parser>::next_event_inner+0x1fbe>
   83d51:	40 b5 04             	mov    $0x4,%bpl
   83d54:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   83d59:	49 8b 9f 98 07 00 00 	mov    0x798(%r15),%rbx
   83d60:	40 0f b6 d5          	movzbl %bpl,%edx
   83d64:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   83d6b:	00 
   83d6c:	48 89 d9             	mov    %rbx,%rcx
   83d6f:	e8 7c a0 fe ff       	call   6ddf0 <<oriole::encoding::Source>::scan_token>
   83d74:	4c 8b bc 24 60 02 00 	mov    0x260(%rsp),%r15
   83d7b:	00 
   83d7c:	80 bc 24 50 02 00 00 	cmpb   $0x0,0x250(%rsp)
   83d83:	00 
   83d84:	74 7c                	je     83e02 <<oriole::Parser>::next_event_inner+0x2952>
   83d86:	8b 8c 24 58 02 00 00 	mov    0x258(%rsp),%ecx
   83d8d:	48 8b 04 24          	mov    (%rsp),%rax
   83d91:	48 8b b0 80 01 00 00 	mov    0x180(%rax),%rsi
   83d98:	48 8b 90 90 01 00 00 	mov    0x190(%rax),%rdx
   83d9f:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   83da6:	00 
   83da7:	48 89 ef             	mov    %rbp,%rdi
   83daa:	4d 89 f8             	mov    %r15,%r8
   83dad:	49 89 c7             	mov    %rax,%r15
   83db0:	e8 7b 8a fc ff       	call   4c830 <<oriole::Parser>::parse_dtd_step::{closure#4}>
   83db5:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
   83dbc:	00 
   83dbd:	0f 28 00             	movaps (%rax),%xmm0
   83dc0:	66 0f 6f 48 10       	movdqa 0x10(%rax),%xmm1
   83dc5:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   83dca:	66 0f 7f 4e 10       	movdqa %xmm1,0x10(%rsi)
   83dcf:	0f 29 06             	movaps %xmm0,(%rsi)
   83dd2:	0f b6 84 24 b0 00 00 	movzbl 0xb0(%rsp),%eax
   83dd9:	00 
   83dda:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   83de1:	00 
   83de2:	8b 4a 29             	mov    0x29(%rdx),%ecx
   83de5:	8b 52 2c             	mov    0x2c(%rdx),%edx
   83de8:	89 56 24             	mov    %edx,0x24(%rsi)
   83deb:	89 4e 21             	mov    %ecx,0x21(%rsi)
   83dee:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
   83df5:	00 00 
   83df7:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   83dfd:	e9 ab f6 ff ff       	jmp    834ad <<oriole::Parser>::next_event_inner+0x1ffd>
   83e02:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
   83e09:	00 
   83e0a:	83 bc 24 58 02 00 00 	cmpl   $0x1,0x258(%rsp)
   83e11:	01 
   83e12:	0f 85 b0 00 00 00    	jne    83ec8 <<oriole::Parser>::next_event_inner+0x2a18>
   83e18:	40 80 fd 04          	cmp    $0x4,%bpl
   83e1c:	75 4e                	jne    83e6c <<oriole::Parser>::next_event_inner+0x29bc>
   83e1e:	48 8b 04 24          	mov    (%rsp),%rax
   83e22:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   83e29:	48 85 c0             	test   %rax,%rax
   83e2c:	0f 84 30 12 00 00    	je     85062 <<oriole::Parser>::next_event_inner+0x3bb2>
   83e32:	48 8b 0c 24          	mov    (%rsp),%rcx
   83e36:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   83e3d:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   83e41:	48 c1 e0 07          	shl    $0x7,%rax
   83e45:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
   83e49:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   83e50:	e8 ab bb fe ff       	call   6fa00 <<oriole::encoding::Source>::remaining>
   83e55:	49 8d 7f ff          	lea    -0x1(%r15),%rdi
   83e59:	48 39 d7             	cmp    %rdx,%rdi
   83e5c:	0f 83 89 18 00 00    	jae    856eb <<oriole::Parser>::next_event_inner+0x423b>
   83e62:	80 3c 38 25          	cmpb   $0x25,(%rax,%rdi,1)
   83e66:	0f 84 a8 01 00 00    	je     84014 <<oriole::Parser>::next_event_inner+0x2b64>
   83e6c:	4c 89 e7             	mov    %r12,%rdi
   83e6f:	48 8b 34 24          	mov    (%rsp),%rsi
   83e73:	4c 89 fa             	mov    %r15,%rdx
   83e76:	e8 65 90 ff ff       	call   7cee0 <<oriole::Parser>::account_source>
   83e7b:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   83e82:	ff 
   83e83:	0f 84 7b 02 00 00    	je     84104 <<oriole::Parser>::next_event_inner+0x2c54>
   83e89:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   83e90:	00 
   83e91:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   83e96:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   83e9d:	00 00 
   83e9f:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   83ea6:	00 00 
   83ea8:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   83eaf:	00 00 
   83eb1:	66 0f 7f 54 24 40    	movdqa %xmm2,0x40(%rsp)
   83eb7:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   83ebd:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   83ec3:	e9 94 07 00 00       	jmp    8465c <<oriole::Parser>::next_event_inner+0x31ac>
   83ec8:	40 80 fd 04          	cmp    $0x4,%bpl
   83ecc:	0f 94 c1             	sete   %cl
   83ecf:	48 8b 04 24          	mov    (%rsp),%rax
   83ed3:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   83eda:	48 83 f8 02          	cmp    $0x2,%rax
   83ede:	0f 93 c2             	setae  %dl
   83ee1:	84 d1                	test   %dl,%cl
   83ee3:	0f 84 fd 00 00 00    	je     83fe6 <<oriole::Parser>::next_event_inner+0x2b36>
   83ee9:	48 8d 05 68 f7 05 00 	lea    0x5f768(%rip),%rax        # e3658 <oriole_expat::FEATURES+0xab0>
   83ef0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   83ef7:	00 
   83ef8:	48 8d 05 99 f7 05 00 	lea    0x5f799(%rip),%rax        # e3698 <oriole_expat::FEATURES+0xaf0>
   83eff:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   83f06:	00 
   83f07:	4c 89 e7             	mov    %r12,%rdi
   83f0a:	48 8b 34 24          	mov    (%rsp),%rsi
   83f0e:	e8 5d 7f fc ff       	call   4be70 <<core::slice::iter::Iter<&str> as core::iter::traits::iterator::Iterator>::any::<<oriole::Parser>::parse_dtd_step::{closure#7}>>
   83f13:	84 c0                	test   %al,%al
   83f15:	0f 84 f9 00 00 00    	je     84014 <<oriole::Parser>::next_event_inner+0x2b64>
   83f1b:	41 b8 2f 00 00 00    	mov    $0x2f,%r8d
   83f21:	4c 89 e5             	mov    %r12,%rbp
   83f24:	4c 89 e7             	mov    %r12,%rdi
   83f27:	4c 8b 3c 24          	mov    (%rsp),%r15
   83f2b:	4c 89 fe             	mov    %r15,%rsi
   83f2e:	ba 04 00 00 00       	mov    $0x4,%edx
   83f33:	48 8d 0d aa dd f8 ff 	lea    -0x72256(%rip),%rcx        # 11ce4 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5358>
   83f3a:	e9 2a f5 ff ff       	jmp    83469 <<oriole::Parser>::next_event_inner+0x1fb9>
   83f3f:	41 b8 16 00 00 00    	mov    $0x16,%r8d
   83f45:	48 89 ef             	mov    %rbp,%rdi
   83f48:	4c 89 fe             	mov    %r15,%rsi
   83f4b:	ba 01 00 00 00       	mov    $0x1,%edx
   83f50:	48 8d 0d 3f dd f8 ff 	lea    -0x722c1(%rip),%rcx        # 11c96 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x530a>
   83f57:	e9 0d f5 ff ff       	jmp    83469 <<oriole::Parser>::next_event_inner+0x1fb9>
   83f5c:	41 0f b6 87 28 01 00 	movzbl 0x128(%r15),%eax
   83f63:	00 
   83f64:	34 01                	xor    $0x1,%al
   83f66:	41 84 87 b8 08 00 00 	test   %al,0x8b8(%r15)
   83f6d:	0f 85 95 fd ff ff    	jne    83d08 <<oriole::Parser>::next_event_inner+0x2858>
   83f73:	41 80 bf f8 07 00 00 	cmpb   $0xff,0x7f8(%r15)
   83f7a:	ff 
   83f7b:	0f 84 2f f7 ff ff    	je     836b0 <<oriole::Parser>::next_event_inner+0x2200>
   83f81:	e9 82 fd ff ff       	jmp    83d08 <<oriole::Parser>::next_event_inner+0x2858>
   83f86:	48 8b 04 24          	mov    (%rsp),%rax
   83f8a:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   83f91:	48 85 c0             	test   %rax,%rax
   83f94:	0f 84 c8 10 00 00    	je     85062 <<oriole::Parser>::next_event_inner+0x3bb2>
   83f9a:	48 8b 0c 24          	mov    (%rsp),%rcx
   83f9e:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   83fa5:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
   83fa9:	48 c1 e6 07          	shl    $0x7,%rsi
   83fad:	48 8d 14 31          	lea    (%rcx,%rsi,1),%rdx
   83fb1:	83 bc 31 80 fe ff ff 	cmpl   $0x1,-0x180(%rcx,%rsi,1)
   83fb8:	01 
   83fb9:	0f 85 a2 00 00 00    	jne    84061 <<oriole::Parser>::next_event_inner+0x2bb1>
   83fbf:	f3 0f 6f 82 88 fe ff 	movdqu -0x178(%rdx),%xmm0
   83fc6:	ff 
   83fc7:	f3 0f 6f 8a 98 fe ff 	movdqu -0x168(%rdx),%xmm1
   83fce:	ff 
   83fcf:	66 0f 7f 8c 24 80 03 	movdqa %xmm1,0x380(%rsp)
   83fd6:	00 00 
   83fd8:	66 0f 7f 84 24 70 03 	movdqa %xmm0,0x370(%rsp)
   83fdf:	00 00 
   83fe1:	e9 db 00 00 00       	jmp    840c1 <<oriole::Parser>::next_event_inner+0x2c11>
   83fe6:	48 83 f8 01          	cmp    $0x1,%rax
   83fea:	0f 86 a8 01 00 00    	jbe    84198 <<oriole::Parser>::next_event_inner+0x2ce8>
   83ff0:	41 b8 18 00 00 00    	mov    $0x18,%r8d
   83ff6:	4c 89 e5             	mov    %r12,%rbp
   83ff9:	4c 89 e7             	mov    %r12,%rdi
   83ffc:	4c 8b 3c 24          	mov    (%rsp),%r15
   84000:	4c 89 fe             	mov    %r15,%rsi
   84003:	ba 04 00 00 00       	mov    $0x4,%edx
   84008:	48 8d 0d 83 d3 f8 ff 	lea    -0x72c7d(%rip),%rcx        # 11392 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4a06>
   8400f:	e9 55 f4 ff ff       	jmp    83469 <<oriole::Parser>::next_event_inner+0x1fb9>
   84014:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   84019:	4c 8b 3c 24          	mov    (%rsp),%r15
   8401d:	4c 89 fe             	mov    %r15,%rsi
   84020:	e8 7b 66 fd ff       	call   5a6a0 <<oriole::Parser>::start_declaration_composition>
   84025:	4c 89 e5             	mov    %r12,%rbp
   84028:	e9 7b f4 ff ff       	jmp    834a8 <<oriole::Parser>::next_event_inner+0x1ff8>
   8402d:	41 b8 25 00 00 00    	mov    $0x25,%r8d
   84033:	41 b9 02 00 00 00    	mov    $0x2,%r9d
   84039:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
   84040:	00 
   84041:	48 89 ef             	mov    %rbp,%rdi
   84044:	4c 8b 3c 24          	mov    (%rsp),%r15
   84048:	4c 89 fe             	mov    %r15,%rsi
   8404b:	ba 03 00 00 00       	mov    $0x3,%edx
   84050:	48 8d 0d bc dc f8 ff 	lea    -0x72344(%rip),%rcx        # 11d13 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5387>
   84057:	e8 74 ce 00 00       	call   90ed0 <<oriole::Parser>::err_at>
   8405c:	e9 0d f4 ff ff       	jmp    8346e <<oriole::Parser>::next_event_inner+0x1fbe>
   84061:	48 8d 3c 31          	lea    (%rcx,%rsi,1),%rdi
   84065:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   8406c:	48 8b 5a a8          	mov    -0x58(%rdx),%rbx
   84070:	0f 10 42 d8          	movups -0x28(%rdx),%xmm0
   84074:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   84079:	31 f6                	xor    %esi,%esi
   8407b:	4c 89 fa             	mov    %r15,%rdx
   8407e:	e8 cd b6 fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   84083:	48 89 9c 24 70 03 00 	mov    %rbx,0x370(%rsp)
   8408a:	00 
   8408b:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   84091:	f3 0f 7f 84 24 78 03 	movdqu %xmm0,0x378(%rsp)
   84098:	00 00 
   8409a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
   840a1:	00 
   840a2:	48 8b 04 24          	mov    (%rsp),%rax
   840a6:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   840ad:	48 85 c0             	test   %rax,%rax
   840b0:	0f 84 ac 0f 00 00    	je     85062 <<oriole::Parser>::next_event_inner+0x3bb2>
   840b6:	48 8b 0c 24          	mov    (%rsp),%rcx
   840ba:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   840c1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   840c5:	48 c1 e0 07          	shl    $0x7,%rax
   840c9:	48 8d 34 01          	lea    (%rcx,%rax,1),%rsi
   840cd:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
   840d4:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   840db:	00 
   840dc:	e8 4f b1 fe ff       	call   6f230 <<oriole::encoding::Source>::lexical_remaining>
   840e1:	4d 85 ff             	test   %r15,%r15
   840e4:	0f 84 f7 00 00 00    	je     841e1 <<oriole::Parser>::next_event_inner+0x2d31>
   840ea:	49 39 ef             	cmp    %rbp,%r15
   840ed:	0f 83 dd 00 00 00    	jae    841d0 <<oriole::Parser>::next_event_inner+0x2d20>
   840f3:	43 80 7c 3d 00 c0    	cmpb   $0xc0,0x0(%r13,%r15,1)
   840f9:	0f 8d e2 00 00 00    	jge    841e1 <<oriole::Parser>::next_event_inner+0x2d31>
   840ff:	e9 68 14 00 00       	jmp    8556c <<oriole::Parser>::next_event_inner+0x40bc>
   84104:	48 8b 04 24          	mov    (%rsp),%rax
   84108:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   8410f:	48 85 c0             	test   %rax,%rax
   84112:	0f 84 4a 0f 00 00    	je     85062 <<oriole::Parser>::next_event_inner+0x3bb2>
   84118:	48 8b 1c 24          	mov    (%rsp),%rbx
   8411c:	48 8b 8b 80 01 00 00 	mov    0x180(%rbx),%rcx
   84123:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   84127:	48 c1 e0 07          	shl    $0x7,%rax
   8412b:	48 8d 34 01          	lea    (%rcx,%rax,1),%rsi
   8412f:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
   84136:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   8413d:	00 
   8413e:	e8 ed b0 fe ff       	call   6f230 <<oriole::encoding::Source>::lexical_remaining>
   84143:	48 8b 83 90 01 00 00 	mov    0x190(%rbx),%rax
   8414a:	48 85 c0             	test   %rax,%rax
   8414d:	0f 84 0f 0f 00 00    	je     85062 <<oriole::Parser>::next_event_inner+0x3bb2>
   84153:	48 8b 0c 24          	mov    (%rsp),%rcx
   84157:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   8415e:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   84162:	48 c1 e0 07          	shl    $0x7,%rax
   84166:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
   8416a:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   84171:	e8 8a b8 fe ff       	call   6fa00 <<oriole::encoding::Source>::remaining>
   84176:	4d 85 ff             	test   %r15,%r15
   84179:	0f 84 ed 01 00 00    	je     8436c <<oriole::Parser>::next_event_inner+0x2ebc>
   8417f:	49 39 d7             	cmp    %rdx,%r15
   84182:	0f 83 d1 01 00 00    	jae    84359 <<oriole::Parser>::next_event_inner+0x2ea9>
   84188:	42 80 3c 38 c0       	cmpb   $0xc0,(%rax,%r15,1)
   8418d:	0f 8d d9 01 00 00    	jge    8436c <<oriole::Parser>::next_event_inner+0x2ebc>
   84193:	e9 23 14 00 00       	jmp    855bb <<oriole::Parser>::next_event_inner+0x410b>
   84198:	48 8b 0c 24          	mov    (%rsp),%rcx
   8419c:	0f b6 81 28 01 00 00 	movzbl 0x128(%rcx),%eax
   841a3:	34 01                	xor    $0x1,%al
   841a5:	84 81 b8 08 00 00    	test   %al,0x8b8(%rcx)
   841ab:	0f 85 3f fe ff ff    	jne    83ff0 <<oriole::Parser>::next_event_inner+0x2b40>
   841b1:	48 8b 04 24          	mov    (%rsp),%rax
   841b5:	80 b8 f8 07 00 00 ff 	cmpb   $0xff,0x7f8(%rax)
   841bc:	0f 85 2e fe ff ff    	jne    83ff0 <<oriole::Parser>::next_event_inner+0x2b40>
   841c2:	31 c0                	xor    %eax,%eax
   841c4:	4c 8b 3c 24          	mov    (%rsp),%r15
   841c8:	4c 89 e5             	mov    %r12,%rbp
   841cb:	e9 63 e1 ff ff       	jmp    82333 <<oriole::Parser>::next_event_inner+0xe83>
   841d0:	0f 95 c0             	setne  %al
   841d3:	4d 85 ed             	test   %r13,%r13
   841d6:	0f 94 c1             	sete   %cl
   841d9:	08 c1                	or     %al,%cl
   841db:	0f 85 8b 13 00 00    	jne    8556c <<oriole::Parser>::next_event_inner+0x40bc>
   841e1:	48 8d 9c 24 20 04 00 	lea    0x420(%rsp),%rbx
   841e8:	00 
   841e9:	48 89 df             	mov    %rbx,%rdi
   841ec:	48 8d ac 24 50 02 00 	lea    0x250(%rsp),%rbp
   841f3:	00 
   841f4:	48 89 ee             	mov    %rbp,%rsi
   841f7:	4c 89 ea             	mov    %r13,%rdx
   841fa:	4c 89 f9             	mov    %r15,%rcx
   841fd:	e8 8e 8e 01 00       	call   9d090 <<oriole::lexical::Slice>::for_slice>
   84202:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
   84209:	00 
   8420a:	f3 0f 6f 00          	movdqu (%rax),%xmm0
   8420e:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
   84213:	66 0f 7f 8c 24 60 02 	movdqa %xmm1,0x260(%rsp)
   8421a:	00 00 
   8421c:	66 0f 7f 84 24 50 02 	movdqa %xmm0,0x250(%rsp)
   84223:	00 00 
   84225:	4c 89 e7             	mov    %r12,%rdi
   84228:	48 89 de             	mov    %rbx,%rsi
   8422b:	48 89 ea             	mov    %rbp,%rdx
   8422e:	e8 7d 86 01 00       	call   9c8b0 <<oriole::lexical::Slice>::decode>
   84233:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   8423a:	00 
   8423b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   8423f:	0f 84 34 02 00 00    	je     84479 <<oriole::Parser>::next_event_inner+0x2fc9>
   84245:	0f b6 8c 24 88 00 00 	movzbl 0x88(%rsp),%ecx
   8424c:	00 
   8424d:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   84254:	00 
   84255:	f3 0f 6f 42 01       	movdqu 0x1(%rdx),%xmm0
   8425a:	f3 0f 6f 4a 11       	movdqu 0x11(%rdx),%xmm1
   8425f:	f3 0f 6f 52 20       	movdqu 0x20(%rdx),%xmm2
   84264:	48 8d 94 24 b0 03 00 	lea    0x3b0(%rsp),%rdx
   8426b:	00 
   8426c:	f3 0f 7f 52 08       	movdqu %xmm2,0x8(%rdx)
   84271:	f3 0f 7f 4a f9       	movdqu %xmm1,-0x7(%rdx)
   84276:	f3 0f 7f 42 e9       	movdqu %xmm0,-0x17(%rdx)
   8427b:	48 89 84 24 90 03 00 	mov    %rax,0x390(%rsp)
   84282:	00 
   84283:	88 8c 24 98 03 00 00 	mov    %cl,0x398(%rsp)
   8428a:	4c 89 e7             	mov    %r12,%rdi
   8428d:	48 8b 34 24          	mov    (%rsp),%rsi
   84291:	4c 89 fa             	mov    %r15,%rdx
   84294:	e8 47 8c ff ff       	call   7cee0 <<oriole::Parser>::account_source>
   84299:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   842a0:	ff 
   842a1:	74 50                	je     842f3 <<oriole::Parser>::next_event_inner+0x2e43>
   842a3:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   842aa:	00 
   842ab:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   842b0:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   842b7:	00 00 
   842b9:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   842c0:	00 00 
   842c2:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   842c9:	00 00 
   842cb:	66 0f 7f 54 24 40    	movdqa %xmm2,0x40(%rsp)
   842d1:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   842d7:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   842dd:	48 8b 8c 24 b8 03 00 	mov    0x3b8(%rsp),%rcx
   842e4:	00 
   842e5:	48 85 c9             	test   %rcx,%rcx
   842e8:	0f 85 53 03 00 00    	jne    84641 <<oriole::Parser>::next_event_inner+0x3191>
   842ee:	e9 69 03 00 00       	jmp    8465c <<oriole::Parser>::next_event_inner+0x31ac>
   842f3:	48 c7 84 24 50 02 00 	movq   $0x14,0x250(%rsp)
   842fa:	00 14 00 00 00 
   842ff:	48 8b 04 24          	mov    (%rsp),%rax
   84303:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   8430a:	48 85 c0             	test   %rax,%rax
   8430d:	0f 84 7f 13 00 00    	je     85692 <<oriole::Parser>::next_event_inner+0x41e2>
   84313:	48 8b 0c 24          	mov    (%rsp),%rcx
   84317:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   8431e:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   84322:	48 c1 e2 07          	shl    $0x7,%rdx
   84326:	48 8d 04 11          	lea    (%rcx,%rdx,1),%rax
   8432a:	83 bc 11 80 fe ff ff 	cmpl   $0x1,-0x180(%rcx,%rdx,1)
   84331:	01 
   84332:	0f 85 e9 01 00 00    	jne    84521 <<oriole::Parser>::next_event_inner+0x3071>
   84338:	48 8b 98 88 fe ff ff 	mov    -0x178(%rax),%rbx
   8433f:	f3 0f 6f 80 90 fe ff 	movdqu -0x170(%rax),%xmm0
   84346:	ff 
   84347:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
   8434d:	48 8b 80 a0 fe ff ff 	mov    -0x160(%rax),%rax
   84354:	e9 ee 01 00 00       	jmp    84547 <<oriole::Parser>::next_event_inner+0x3097>
   84359:	0f 95 c1             	setne  %cl
   8435c:	48 85 c0             	test   %rax,%rax
   8435f:	40 0f 94 c6          	sete   %sil
   84363:	40 08 ce             	or     %cl,%sil
   84366:	0f 85 4f 12 00 00    	jne    855bb <<oriole::Parser>::next_event_inner+0x410b>
   8436c:	4c 8d b4 24 90 03 00 	lea    0x390(%rsp),%r14
   84373:	00 
   84374:	4c 89 f7             	mov    %r14,%rdi
   84377:	48 8d 9c 24 20 04 00 	lea    0x420(%rsp),%rbx
   8437e:	00 
   8437f:	48 89 de             	mov    %rbx,%rsi
   84382:	48 89 c2             	mov    %rax,%rdx
   84385:	4c 89 f9             	mov    %r15,%rcx
   84388:	e8 03 8d 01 00       	call   9d090 <<oriole::lexical::Slice>::for_slice>
   8438d:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
   84394:	00 
   84395:	f3 0f 6f 00          	movdqu (%rax),%xmm0
   84399:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
   8439e:	66 0f 7f 8c 24 30 04 	movdqa %xmm1,0x430(%rsp)
   843a5:	00 00 
   843a7:	66 0f 7f 84 24 20 04 	movdqa %xmm0,0x420(%rsp)
   843ae:	00 00 
   843b0:	4c 89 e7             	mov    %r12,%rdi
   843b3:	4c 89 f6             	mov    %r14,%rsi
   843b6:	48 89 da             	mov    %rbx,%rdx
   843b9:	e8 d2 88 01 00       	call   9cc90 <<oriole::lexical::Slice>::to_owned>
   843be:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   843c5:	00 
   843c6:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   843ca:	0f 84 a9 00 00 00    	je     84479 <<oriole::Parser>::next_event_inner+0x2fc9>
   843d0:	0f b6 8c 24 88 00 00 	movzbl 0x88(%rsp),%ecx
   843d7:	00 
   843d8:	48 8d b4 24 88 00 00 	lea    0x88(%rsp),%rsi
   843df:	00 
   843e0:	48 8b 56 60          	mov    0x60(%rsi),%rdx
   843e4:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
   843eb:	00 
   843ec:	48 89 57 60          	mov    %rdx,0x60(%rdi)
   843f0:	0f 10 46 51          	movups 0x51(%rsi),%xmm0
   843f4:	0f 11 47 51          	movups %xmm0,0x51(%rdi)
   843f8:	0f 10 46 41          	movups 0x41(%rsi),%xmm0
   843fc:	0f 11 47 41          	movups %xmm0,0x41(%rdi)
   84400:	f3 0f 6f 46 01       	movdqu 0x1(%rsi),%xmm0
   84405:	f3 0f 6f 4e 11       	movdqu 0x11(%rsi),%xmm1
   8440a:	f3 0f 6f 56 21       	movdqu 0x21(%rsi),%xmm2
   8440f:	0f 10 5e 31          	movups 0x31(%rsi),%xmm3
   84413:	0f 11 5f 31          	movups %xmm3,0x31(%rdi)
   84417:	f3 0f 7f 57 21       	movdqu %xmm2,0x21(%rdi)
   8441c:	f3 0f 7f 4f 11       	movdqu %xmm1,0x11(%rdi)
   84421:	f3 0f 7f 47 01       	movdqu %xmm0,0x1(%rdi)
   84426:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
   8442d:	00 
   8442e:	88 8c 24 58 02 00 00 	mov    %cl,0x258(%rsp)
   84435:	48 8b 9c 24 70 02 00 	mov    0x270(%rsp),%rbx
   8443c:	00 
   8443d:	4c 8b b4 24 80 02 00 	mov    0x280(%rsp),%r14
   84444:	00 
   84445:	48 89 df             	mov    %rbx,%rdi
   84448:	4c 89 f6             	mov    %r14,%rsi
   8444b:	e8 b0 c8 01 00       	call   a0d00 <oriole::names::invalid_xml_char>
   84450:	48 83 f8 01          	cmp    $0x1,%rax
   84454:	75 62                	jne    844b8 <<oriole::Parser>::next_event_inner+0x3008>
   84456:	49 89 d1             	mov    %rdx,%r9
   84459:	41 b8 1c 00 00 00    	mov    $0x1c,%r8d
   8445f:	4c 89 e7             	mov    %r12,%rdi
   84462:	48 8b 34 24          	mov    (%rsp),%rsi
   84466:	ba 03 00 00 00       	mov    $0x3,%edx
   8446b:	48 8d 0d 3a d8 f8 ff 	lea    -0x727c6(%rip),%rcx        # 11cac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5320>
   84472:	e8 59 ca 00 00       	call   90ed0 <<oriole::Parser>::err_at>
   84477:	eb 5c                	jmp    844d5 <<oriole::Parser>::next_event_inner+0x3025>
   84479:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   8447e:	66 0f ef c0          	pxor   %xmm0,%xmm0
   84482:	66 0f 7f 40 10       	movdqa %xmm0,0x10(%rax)
   84487:	48 8d 05 0e d0 f8 ff 	lea    -0x72ff2(%rip),%rax        # 1149c <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   8448e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   84493:	48 c7 44 24 28 0d 00 	movq   $0xd,0x28(%rsp)
   8449a:	00 00 
   8449c:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   844a3:	00 00 
   844a5:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
   844ac:	00 00 
   844ae:	c6 44 24 50 00       	movb   $0x0,0x50(%rsp)
   844b3:	e9 a4 01 00 00       	jmp    8465c <<oriole::Parser>::next_event_inner+0x31ac>
   844b8:	4c 89 e7             	mov    %r12,%rdi
   844bb:	48 8b 34 24          	mov    (%rsp),%rsi
   844bf:	4c 89 fa             	mov    %r15,%rdx
   844c2:	e8 19 15 00 00       	call   859e0 <<oriole::Parser>::save_current_raw>
   844c7:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   844ce:	ff 
   844cf:	0f 84 bc 01 00 00    	je     84691 <<oriole::Parser>::next_event_inner+0x31e1>
   844d5:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   844dc:	00 
   844dd:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   844e2:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   844e9:	00 00 
   844eb:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   844f2:	00 00 
   844f4:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   844fb:	00 00 
   844fd:	66 0f 7f 54 24 40    	movdqa %xmm2,0x40(%rsp)
   84503:	66 0f 7f 4c 24 30    	movdqa %xmm1,0x30(%rsp)
   84509:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   8450f:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   84516:	00 
   84517:	e8 b4 53 fc ff       	call   498d0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   8451c:	e9 3b 01 00 00       	jmp    8465c <<oriole::Parser>::next_event_inner+0x31ac>
   84521:	48 8d 3c 11          	lea    (%rcx,%rdx,1),%rdi
   84525:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   8452c:	48 8b 58 a8          	mov    -0x58(%rax),%rbx
   84530:	f3 0f 6f 40 d8       	movdqu -0x28(%rax),%xmm0
   84535:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
   8453b:	ba 01 00 00 00       	mov    $0x1,%edx
   84540:	31 f6                	xor    %esi,%esi
   84542:	e8 09 b2 fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   84547:	48 8b 8c 24 c0 02 00 	mov    0x2c0(%rsp),%rcx
   8454e:	00 
   8454f:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   84556:	00 
   84557:	48 89 8a a0 00 00 00 	mov    %rcx,0xa0(%rdx)
   8455e:	0f 10 84 24 b0 02 00 	movups 0x2b0(%rsp),%xmm0
   84565:	00 
   84566:	0f 11 82 90 00 00 00 	movups %xmm0,0x90(%rdx)
   8456d:	0f 10 84 24 a0 02 00 	movups 0x2a0(%rsp),%xmm0
   84574:	00 
   84575:	0f 11 82 80 00 00 00 	movups %xmm0,0x80(%rdx)
   8457c:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   84583:	00 
   84584:	0f 11 42 70          	movups %xmm0,0x70(%rdx)
   84588:	0f 10 84 24 50 02 00 	movups 0x250(%rsp),%xmm0
   8458f:	00 
   84590:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   84597:	00 00 
   84599:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   845a0:	00 00 
   845a2:	0f 10 9c 24 80 02 00 	movups 0x280(%rsp),%xmm3
   845a9:	00 
   845aa:	0f 11 5a 60          	movups %xmm3,0x60(%rdx)
   845ae:	f3 0f 7f 52 50       	movdqu %xmm2,0x50(%rdx)
   845b3:	f3 0f 7f 4a 40       	movdqu %xmm1,0x40(%rdx)
   845b8:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
   845bc:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
   845c3:	00 
   845c4:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   845ca:	f3 0f 7f 84 24 38 01 	movdqu %xmm0,0x138(%rsp)
   845d1:	00 00 
   845d3:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
   845da:	00 
   845db:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   845e2:	00 ff ff ff ff 
   845e7:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   845ee:	00 
   845ef:	4c 89 e6             	mov    %r12,%rsi
   845f2:	e8 c9 2d fd ff       	call   573c0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   845f7:	3c ff                	cmp    $0xff,%al
   845f9:	74 6d                	je     84668 <<oriole::Parser>::next_event_inner+0x31b8>
   845fb:	48 8d 05 9a ce f8 ff 	lea    -0x73166(%rip),%rax        # 1149c <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   84602:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   84607:	48 c7 44 24 28 0d 00 	movq   $0xd,0x28(%rsp)
   8460e:	00 00 
   84610:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   84617:	00 00 
   84619:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
   84620:	00 00 
   84622:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   84627:	66 0f ef c0          	pxor   %xmm0,%xmm0
   8462b:	66 0f 7f 40 10       	movdqa %xmm0,0x10(%rax)
   84630:	c6 40 20 00          	movb   $0x0,0x20(%rax)
   84634:	48 8b 8c 24 b8 03 00 	mov    0x3b8(%rsp),%rcx
   8463b:	00 
   8463c:	48 85 c9             	test   %rcx,%rcx
   8463f:	74 1b                	je     8465c <<oriole::Parser>::next_event_inner+0x31ac>
   84641:	48 8b b4 24 b0 03 00 	mov    0x3b0(%rsp),%rsi
   84648:	00 
   84649:	ba 01 00 00 00       	mov    $0x1,%edx
   8464e:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
   84655:	00 
   84656:	ff 15 0c 22 06 00    	call   *0x6220c(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   8465c:	4c 8b 3c 24          	mov    (%rsp),%r15
   84660:	4c 89 e5             	mov    %r12,%rbp
   84663:	e9 40 ee ff ff       	jmp    834a8 <<oriole::Parser>::next_event_inner+0x1ff8>
   84668:	48 8b ac 24 b0 03 00 	mov    0x3b0(%rsp),%rbp
   8466f:	00 
   84670:	4c 8b ac 24 c0 03 00 	mov    0x3c0(%rsp),%r13
   84677:	00 
   84678:	49 83 fd 01          	cmp    $0x1,%r13
   8467c:	0f 86 ae 00 00 00    	jbe    84730 <<oriole::Parser>::next_event_inner+0x3280>
   84682:	80 7d 01 c0          	cmpb   $0xc0,0x1(%rbp)
   84686:	0f 8d aa 00 00 00    	jge    84736 <<oriole::Parser>::next_event_inner+0x3286>
   8468c:	e9 6d 10 00 00       	jmp    856fe <<oriole::Parser>::next_event_inner+0x424e>
   84691:	48 8b 84 24 a8 02 00 	mov    0x2a8(%rsp),%rax
   84698:	00 
   84699:	48 8b 8c 24 b8 02 00 	mov    0x2b8(%rsp),%rcx
   846a0:	00 
   846a1:	48 89 9c 24 90 03 00 	mov    %rbx,0x390(%rsp)
   846a8:	00 
   846a9:	4c 89 b4 24 98 03 00 	mov    %r14,0x398(%rsp)
   846b0:	00 
   846b1:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
   846b8:	00 
   846b9:	48 89 8c 24 a8 03 00 	mov    %rcx,0x3a8(%rsp)
   846c0:	00 
   846c1:	48 c7 84 24 b0 03 00 	movq   $0x0,0x3b0(%rsp)
   846c8:	00 00 00 00 00 
   846cd:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   846d4:	00 ff ff ff ff 
   846d9:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   846e0:	00 
   846e1:	48 8b 34 24          	mov    (%rsp),%rsi
   846e5:	48 8d 94 24 90 03 00 	lea    0x390(%rsp),%rdx
   846ec:	00 
   846ed:	4c 89 e1             	mov    %r12,%rcx
   846f0:	e8 ab 35 fe ff       	call   67ca0 <<oriole::Parser>::parse_subset_expanded>
   846f5:	80 bc 24 50 04 00 00 	cmpb   $0xff,0x450(%rsp)
   846fc:	ff 
   846fd:	0f 84 48 02 00 00    	je     8494b <<oriole::Parser>::next_event_inner+0x349b>
   84703:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
   8470a:	00 
   8470b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   84710:	f3 0f 6f 84 24 20 04 	movdqu 0x420(%rsp),%xmm0
   84717:	00 00 
   84719:	f3 0f 6f 8c 24 30 04 	movdqu 0x430(%rsp),%xmm1
   84720:	00 00 
   84722:	f3 0f 6f 94 24 40 04 	movdqu 0x440(%rsp),%xmm2
   84729:	00 00 
   8472b:	e9 cd fd ff ff       	jmp    844fd <<oriole::Parser>::next_event_inner+0x304d>
   84730:	0f 85 c8 0f 00 00    	jne    856fe <<oriole::Parser>::next_event_inner+0x424e>
   84736:	b9 01 00 00 00       	mov    $0x1,%ecx
   8473b:	4c 89 e7             	mov    %r12,%rdi
   8473e:	48 8b 34 24          	mov    (%rsp),%rsi
   84742:	48 89 ea             	mov    %rbp,%rdx
   84745:	e8 c6 eb 00 00       	call   93310 <<oriole::Parser>::event_raw>
   8474a:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84751:	ff 
   84752:	0f 85 4b fb ff ff    	jne    842a3 <<oriole::Parser>::next_event_inner+0x2df3>
   84758:	49 83 ff 02          	cmp    $0x2,%r15
   8475c:	0f 86 8a 01 00 00    	jbe    848ec <<oriole::Parser>::next_event_inner+0x343c>
   84762:	48 c7 84 24 20 04 00 	movq   $0x14,0x420(%rsp)
   84769:	00 14 00 00 00 
   8476e:	48 8b 04 24          	mov    (%rsp),%rax
   84772:	48 8b 80 90 01 00 00 	mov    0x190(%rax),%rax
   84779:	48 85 c0             	test   %rax,%rax
   8477c:	0f 84 99 0f 00 00    	je     8571b <<oriole::Parser>::next_event_inner+0x426b>
   84782:	48 8b 0c 24          	mov    (%rsp),%rcx
   84786:	48 8b 89 80 01 00 00 	mov    0x180(%rcx),%rcx
   8478d:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   84791:	48 c1 e0 07          	shl    $0x7,%rax
   84795:	48 8d 34 01          	lea    (%rcx,%rax,1),%rsi
   84799:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
   847a0:	ba 01 00 00 00       	mov    $0x1,%edx
   847a5:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   847ac:	00 
   847ad:	4c 89 f1             	mov    %r14,%rcx
   847b0:	e8 6b 9d fe ff       	call   6e520 <<oriole::encoding::Source>::position_at>
   847b5:	48 8b 84 24 90 04 00 	mov    0x490(%rsp),%rax
   847bc:	00 
   847bd:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
   847c4:	00 
   847c5:	0f 10 84 24 80 04 00 	movups 0x480(%rsp),%xmm0
   847cc:	00 
   847cd:	0f 29 84 24 b0 02 00 	movaps %xmm0,0x2b0(%rsp)
   847d4:	00 
   847d5:	0f 10 84 24 70 04 00 	movups 0x470(%rsp),%xmm0
   847dc:	00 
   847dd:	0f 29 84 24 a0 02 00 	movaps %xmm0,0x2a0(%rsp)
   847e4:	00 
   847e5:	0f 10 84 24 60 04 00 	movups 0x460(%rsp),%xmm0
   847ec:	00 
   847ed:	0f 29 84 24 90 02 00 	movaps %xmm0,0x290(%rsp)
   847f4:	00 
   847f5:	0f 10 84 24 20 04 00 	movups 0x420(%rsp),%xmm0
   847fc:	00 
   847fd:	0f 10 8c 24 30 04 00 	movups 0x430(%rsp),%xmm1
   84804:	00 
   84805:	f3 0f 6f 94 24 40 04 	movdqu 0x440(%rsp),%xmm2
   8480c:	00 00 
   8480e:	0f 10 9c 24 50 04 00 	movups 0x450(%rsp),%xmm3
   84815:	00 
   84816:	0f 29 9c 24 80 02 00 	movaps %xmm3,0x280(%rsp)
   8481d:	00 
   8481e:	66 0f 7f 94 24 70 02 	movdqa %xmm2,0x270(%rsp)
   84825:	00 00 
   84827:	0f 29 8c 24 60 02 00 	movaps %xmm1,0x260(%rsp)
   8482e:	00 
   8482f:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
   84836:	00 
   84837:	f3 0f 6f 84 24 40 03 	movdqu 0x340(%rsp),%xmm0
   8483e:	00 00 
   84840:	f3 0f 6f 8c 24 50 03 	movdqu 0x350(%rsp),%xmm1
   84847:	00 00 
   84849:	48 8d 84 24 58 02 00 	lea    0x258(%rsp),%rax
   84850:	00 
   84851:	f3 0f 7f 88 80 00 00 	movdqu %xmm1,0x80(%rax)
   84858:	00 
   84859:	f3 0f 7f 40 70       	movdqu %xmm0,0x70(%rax)
   8485e:	ba 98 00 00 00       	mov    $0x98,%edx
   84863:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   8486a:	00 
   8486b:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
   84872:	00 
   84873:	ff 15 d7 28 06 00    	call   *0x628d7(%rip)        # e7150 <memcpy@GLIBC_2.14>
   84879:	48 c7 84 24 80 00 00 	movq   $0xffffffffffffffff,0x80(%rsp)
   84880:	00 ff ff ff ff 
   84885:	48 8b bc 24 18 02 00 	mov    0x218(%rsp),%rdi
   8488c:	00 
   8488d:	4c 89 e6             	mov    %r12,%rsi
   84890:	e8 2b 2b fd ff       	call   573c0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
   84895:	3c ff                	cmp    $0xff,%al
   84897:	0f 85 5e fd ff ff    	jne    845fb <<oriole::Parser>::next_event_inner+0x314b>
   8489d:	ba 01 00 00 00       	mov    $0x1,%edx
   848a2:	49 83 fd 02          	cmp    $0x2,%r13
   848a6:	0f 82 2c 0e 00 00    	jb     856d8 <<oriole::Parser>::next_event_inner+0x4228>
   848ac:	49 8d 4d ff          	lea    -0x1(%r13),%rcx
   848b0:	80 7d 01 c0          	cmpb   $0xc0,0x1(%rbp)
   848b4:	0f 8c 20 0e 00 00    	jl     856da <<oriole::Parser>::next_event_inner+0x422a>
   848ba:	80 7c 0d 00 bf       	cmpb   $0xbf,0x0(%rbp,%rcx,1)
   848bf:	0f 8e 15 0e 00 00    	jle    856da <<oriole::Parser>::next_event_inner+0x422a>
   848c5:	48 ff c5             	inc    %rbp
   848c8:	49 83 c5 fe          	add    $0xfffffffffffffffe,%r13
   848cc:	4c 89 e7             	mov    %r12,%rdi
   848cf:	48 8b 34 24          	mov    (%rsp),%rsi
   848d3:	48 89 ea             	mov    %rbp,%rdx
   848d6:	4c 89 e9             	mov    %r13,%rcx
   848d9:	e8 32 ea 00 00       	call   93310 <<oriole::Parser>::event_raw>
   848de:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   848e5:	ff 
   848e6:	0f 85 b7 f9 ff ff    	jne    842a3 <<oriole::Parser>::next_event_inner+0x2df3>
   848ec:	4c 89 e7             	mov    %r12,%rdi
   848ef:	48 8b 34 24          	mov    (%rsp),%rsi
   848f3:	48 8d 94 24 70 03 00 	lea    0x370(%rsp),%rdx
   848fa:	00 
   848fb:	e8 a0 cc fd ff       	call   615a0 <<oriole::Parser>::finish_doctype>
   84900:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84907:	ff 
   84908:	0f 85 95 f9 ff ff    	jne    842a3 <<oriole::Parser>::next_event_inner+0x2df3>
   8490e:	4c 89 e7             	mov    %r12,%rdi
   84911:	48 8b 34 24          	mov    (%rsp),%rsi
   84915:	4c 89 fa             	mov    %r15,%rdx
   84918:	e8 33 c6 00 00       	call   90f50 <<oriole::Parser>::consume>
   8491d:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84924:	ff 
   84925:	0f 85 78 f9 ff ff    	jne    842a3 <<oriole::Parser>::next_event_inner+0x2df3>
   8492b:	c6 44 24 20 01       	movb   $0x1,0x20(%rsp)
   84930:	c6 44 24 50 ff       	movb   $0xff,0x50(%rsp)
   84935:	48 8b 8c 24 b8 03 00 	mov    0x3b8(%rsp),%rcx
   8493c:	00 
   8493d:	48 85 c9             	test   %rcx,%rcx
   84940:	0f 85 fb fc ff ff    	jne    84641 <<oriole::Parser>::next_event_inner+0x3191>
   84946:	e9 11 fd ff ff       	jmp    8465c <<oriole::Parser>::next_event_inner+0x31ac>
   8494b:	4c 89 e7             	mov    %r12,%rdi
   8494e:	48 8b 34 24          	mov    (%rsp),%rsi
   84952:	4c 89 fa             	mov    %r15,%rdx
   84955:	e8 f6 c5 00 00       	call   90f50 <<oriole::Parser>::consume>
   8495a:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84961:	ff 
   84962:	0f 85 6d fb ff ff    	jne    844d5 <<oriole::Parser>::next_event_inner+0x3025>
   84968:	c6 44 24 20 01       	movb   $0x1,0x20(%rsp)
   8496d:	c6 44 24 50 ff       	movb   $0xff,0x50(%rsp)
   84972:	e9 98 fb ff ff       	jmp    8450f <<oriole::Parser>::next_event_inner+0x305f>
   84977:	0f 10 84 24 81 00 00 	movups 0x81(%rsp),%xmm0
   8497e:	00 
   8497f:	0f 10 8c 24 91 00 00 	movups 0x91(%rsp),%xmm1
   84986:	00 
   84987:	0f 10 94 24 a0 00 00 	movups 0xa0(%rsp),%xmm2
   8498e:	00 
   8498f:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   84994:	0f 11 57 28          	movups %xmm2,0x28(%rdi)
   84998:	0f 11 4f 19          	movups %xmm1,0x19(%rdi)
   8499c:	0f 11 47 09          	movups %xmm0,0x9(%rdi)
   849a0:	8b 94 24 b1 00 00 00 	mov    0xb1(%rsp),%edx
   849a7:	8b b4 24 b4 00 00 00 	mov    0xb4(%rsp),%esi
   849ae:	89 57 39             	mov    %edx,0x39(%rdi)
   849b1:	89 77 3c             	mov    %esi,0x3c(%rdi)
   849b4:	88 47 08             	mov    %al,0x8(%rdi)
   849b7:	88 4f 38             	mov    %cl,0x38(%rdi)
   849ba:	48 c7 07 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rdi)
   849c1:	e9 8a 07 00 00       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   849c6:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   849cb:	48 89 1f             	mov    %rbx,(%rdi)
   849ce:	48 83 c7 08          	add    $0x8,%rdi
   849d2:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
   849d9:	00 
   849da:	ba 90 00 00 00       	mov    $0x90,%edx
   849df:	ff 15 6b 27 06 00    	call   *0x6276b(%rip)        # e7150 <memcpy@GLIBC_2.14>
   849e5:	e9 66 07 00 00       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   849ea:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   849f1:	00 
   849f2:	ba 01 00 00 00       	mov    $0x1,%edx
   849f7:	4c 89 fe             	mov    %r15,%rsi
   849fa:	31 c9                	xor    %ecx,%ecx
   849fc:	e8 0f e9 00 00       	call   93310 <<oriole::Parser>::event_raw>
   84a01:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84a08:	ff 
   84a09:	0f 84 cb cc ff ff    	je     816da <<oriole::Parser>::next_event_inner+0x22a>
   84a0f:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   84a16:	00 
   84a17:	48 89 43 38          	mov    %rax,0x38(%rbx)
   84a1b:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   84a22:	00 00 
   84a24:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   84a2b:	00 00 
   84a2d:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   84a34:	00 00 
   84a36:	f3 0f 7f 53 28       	movdqu %xmm2,0x28(%rbx)
   84a3b:	f3 0f 7f 4b 18       	movdqu %xmm1,0x18(%rbx)
   84a40:	f3 0f 7f 43 08       	movdqu %xmm0,0x8(%rbx)
   84a45:	48 c7 03 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rbx)
   84a4c:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   84a53:	00 
   84a54:	e8 a7 16 fc ff       	call   46100 <core::ptr::drop_glue::<core::option::Option<(oriole_storage::string::String, oriole::Position)>>>
   84a59:	e9 f2 06 00 00       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   84a5e:	41 0f b6 9f f8 07 00 	movzbl 0x7f8(%r15),%ebx
   84a65:	00 
   84a66:	80 fb ff             	cmp    $0xff,%bl
   84a69:	4d 89 fe             	mov    %r15,%r14
   84a6c:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
   84a71:	0f 84 2c 01 00 00    	je     84ba3 <<oriole::Parser>::next_event_inner+0x36f3>
   84a77:	49 8b 8e 00 08 00 00 	mov    0x800(%r14),%rcx
   84a7e:	4d 8b 86 08 08 00 00 	mov    0x808(%r14),%r8
   84a85:	0f b6 d3             	movzbl %bl,%edx
   84a88:	48 8d bc 24 50 05 00 	lea    0x550(%rsp),%rdi
   84a8f:	00 
   84a90:	4c 89 f6             	mov    %r14,%rsi
   84a93:	e8 d8 b9 00 00       	call   90470 <<oriole::Parser>::err>
   84a98:	80 c3 ef             	add    $0xef,%bl
   84a9b:	80 fb 01             	cmp    $0x1,%bl
   84a9e:	77 24                	ja     84ac4 <<oriole::Parser>::next_event_inner+0x3614>
   84aa0:	41 f6 06 01          	testb  $0x1,(%r14)
   84aa4:	74 1e                	je     84ac4 <<oriole::Parser>::next_event_inner+0x3614>
   84aa6:	f3 41 0f 6f 46 08    	movdqu 0x8(%r14),%xmm0
   84aac:	f3 41 0f 6f 4e 18    	movdqu 0x18(%r14),%xmm1
   84ab2:	f3 0f 7f 8c 24 70 05 	movdqu %xmm1,0x570(%rsp)
   84ab9:	00 00 
   84abb:	f3 0f 7f 84 24 60 05 	movdqu %xmm0,0x560(%rsp)
   84ac2:	00 00 
   84ac4:	48 8b 84 24 80 05 00 	mov    0x580(%rsp),%rax
   84acb:	00 
   84acc:	49 89 47 38          	mov    %rax,0x38(%r15)
   84ad0:	f3 0f 6f 84 24 50 05 	movdqu 0x550(%rsp),%xmm0
   84ad7:	00 00 
   84ad9:	f3 0f 6f 8c 24 60 05 	movdqu 0x560(%rsp),%xmm1
   84ae0:	00 00 
   84ae2:	f3 0f 6f 94 24 70 05 	movdqu 0x570(%rsp),%xmm2
   84ae9:	00 00 
   84aeb:	e9 cf 07 00 00       	jmp    852bf <<oriole::Parser>::next_event_inner+0x3e0f>
   84af0:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   84af7:	00 
   84af8:	49 89 46 38          	mov    %rax,0x38(%r14)
   84afc:	0f 10 84 24 80 00 00 	movups 0x80(%rsp),%xmm0
   84b03:	00 
   84b04:	0f 10 8c 24 90 00 00 	movups 0x90(%rsp),%xmm1
   84b0b:	00 
   84b0c:	0f 10 94 24 a0 00 00 	movups 0xa0(%rsp),%xmm2
   84b13:	00 
   84b14:	41 0f 11 56 28       	movups %xmm2,0x28(%r14)
   84b19:	41 0f 11 4e 18       	movups %xmm1,0x18(%r14)
   84b1e:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
   84b23:	49 c7 06 fe ff ff ff 	movq   $0xfffffffffffffffe,(%r14)
   84b2a:	e9 21 06 00 00       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   84b2f:	48 8d 0d 37 dd f8 ff 	lea    -0x722c9(%rip),%rcx        # 1286d <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5ee1>
   84b36:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   84b3d:	00 
   84b3e:	41 b8 22 00 00 00    	mov    $0x22,%r8d
   84b44:	4c 89 fe             	mov    %r15,%rsi
   84b47:	ba 0c 00 00 00       	mov    $0xc,%edx
   84b4c:	e8 1f b9 00 00       	call   90470 <<oriole::Parser>::err>
   84b51:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
   84b58:	00 
   84b59:	49 89 46 38          	mov    %rax,0x38(%r14)
   84b5d:	f3 0f 6f 84 24 50 02 	movdqu 0x250(%rsp),%xmm0
   84b64:	00 00 
   84b66:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   84b6d:	00 00 
   84b6f:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   84b76:	00 00 
   84b78:	f3 41 0f 7f 56 28    	movdqu %xmm2,0x28(%r14)
   84b7e:	f3 41 0f 7f 4e 18    	movdqu %xmm1,0x18(%r14)
   84b84:	f3 41 0f 7f 46 08    	movdqu %xmm0,0x8(%r14)
   84b8a:	49 c7 06 fe ff ff ff 	movq   $0xfffffffffffffffe,(%r14)
   84b91:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84b98:	00 
   84b99:	e8 c2 4d fc ff       	call   49960 <core::ptr::drop_glue::<oriole::encoding::Source>>
   84b9e:	e9 ad 05 00 00       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   84ba3:	41 80 be b8 08 00 00 	cmpb   $0x1,0x8b8(%r14)
   84baa:	01 
   84bab:	0f 85 2c 07 00 00    	jne    852dd <<oriole::Parser>::next_event_inner+0x3e2d>
   84bb1:	41 f6 86 28 01 00 00 	testb  $0x1,0x128(%r14)
   84bb8:	01 
   84bb9:	0f 85 1e 07 00 00    	jne    852dd <<oriole::Parser>::next_event_inner+0x3e2d>
   84bbf:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84bc6:	00 
   84bc7:	4c 89 f6             	mov    %r14,%rsi
   84bca:	e8 e1 eb 00 00       	call   937b0 <<oriole::Parser>::finish_conditional_source>
   84bcf:	80 bc 24 b0 00 00 00 	cmpb   $0xff,0xb0(%rsp)
   84bd6:	ff 
   84bd7:	0f 85 bb 06 00 00    	jne    85298 <<oriole::Parser>::next_event_inner+0x3de8>
   84bdd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84be4:	00 
   84be5:	4c 89 f6             	mov    %r14,%rsi
   84be8:	e8 43 c2 00 00       	call   90e30 <<oriole::Parser>::here>
   84bed:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   84bf4:	00 00 
   84bf6:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   84bfd:	00 00 
   84bff:	f3 41 0f 7f 8e a0 08 	movdqu %xmm1,0x8a0(%r14)
   84c06:	00 00 
   84c08:	f3 41 0f 7f 86 90 08 	movdqu %xmm0,0x890(%r14)
   84c0f:	00 00 
   84c11:	41 80 be b1 08 00 00 	cmpb   $0x0,0x8b1(%r14)
   84c18:	00 
   84c19:	0f 84 13 04 00 00    	je     85032 <<oriole::Parser>::next_event_inner+0x3b82>
   84c1f:	48 8d 0d 3b d1 f8 ff 	lea    -0x72ec5(%rip),%rcx        # 11d61 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x53d5>
   84c26:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84c2d:	00 
   84c2e:	41 b8 22 00 00 00    	mov    $0x22,%r8d
   84c34:	4c 89 f6             	mov    %r14,%rsi
   84c37:	ba 02 00 00 00       	mov    $0x2,%edx
   84c3c:	e9 52 06 00 00       	jmp    85293 <<oriole::Parser>::next_event_inner+0x3de3>
   84c41:	4c 8d 05 40 f4 05 00 	lea    0x5f440(%rip),%r8        # e4088 <oriole_expat::FEATURES+0x14e0>
   84c48:	48 89 c7             	mov    %rax,%rdi
   84c4b:	48 89 d6             	mov    %rdx,%rsi
   84c4e:	31 d2                	xor    %edx,%edx
   84c50:	4c 89 f9             	mov    %r15,%rcx
   84c53:	ff 15 17 22 06 00    	call   *0x62217(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   84c59:	e9 d6 0a 00 00       	jmp    85734 <<oriole::Parser>::next_event_inner+0x4284>
   84c5e:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   84c63:	83 3f 01             	cmpl   $0x1,(%rdi)
   84c66:	75 1b                	jne    84c83 <<oriole::Parser>::next_event_inner+0x37d3>
   84c68:	48 89 d8             	mov    %rbx,%rax
   84c6b:	48 8b 9b 88 fe ff ff 	mov    -0x178(%rbx),%rbx
   84c72:	f3 0f 6f 80 90 fe ff 	movdqu -0x170(%rax),%xmm0
   84c79:	ff 
   84c7a:	48 8b 80 a0 fe ff ff 	mov    -0x160(%rax),%rax
   84c81:	eb 1d                	jmp    84ca0 <<oriole::Parser>::next_event_inner+0x37f0>
   84c83:	48 89 d8             	mov    %rbx,%rax
   84c86:	48 8b 5b a8          	mov    -0x58(%rbx),%rbx
   84c8a:	0f 10 40 d8          	movups -0x28(%rax),%xmm0
   84c8e:	0f 29 04 24          	movaps %xmm0,(%rsp)
   84c92:	31 f6                	xor    %esi,%esi
   84c94:	31 d2                	xor    %edx,%edx
   84c96:	e8 b5 aa fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   84c9b:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
   84ca0:	48 8d 0d 70 db f8 ff 	lea    -0x72490(%rip),%rcx        # 12817 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5e8b>
   84ca7:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   84cac:	48 c7 44 24 28 24 00 	movq   $0x24,0x28(%rsp)
   84cb3:	00 00 
   84cb5:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   84cba:	f3 0f 7f 44 24 38    	movdqu %xmm0,0x38(%rsp)
   84cc0:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   84cc5:	b0 1e                	mov    $0x1e,%al
   84cc7:	0f b6 4c 24 20       	movzbl 0x20(%rsp),%ecx
   84ccc:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   84cd1:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   84cd6:	48 89 57 28          	mov    %rdx,0x28(%rdi)
   84cda:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   84cdf:	48 89 57 30          	mov    %rdx,0x30(%rdi)
   84ce3:	8b 54 24 31          	mov    0x31(%rsp),%edx
   84ce7:	89 57 19             	mov    %edx,0x19(%rdi)
   84cea:	0f b7 54 24 35       	movzwl 0x35(%rsp),%edx
   84cef:	66 89 57 1d          	mov    %dx,0x1d(%rdi)
   84cf3:	0f b6 54 24 37       	movzbl 0x37(%rsp),%edx
   84cf8:	88 57 1f             	mov    %dl,0x1f(%rdi)
   84cfb:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
   84d00:	48 89 57 20          	mov    %rdx,0x20(%rdi)
   84d04:	0f b6 54 24 40       	movzbl 0x40(%rsp),%edx
   84d09:	88 57 28             	mov    %dl,0x28(%rdi)
   84d0c:	0f 10 44 24 21       	movups 0x21(%rsp),%xmm0
   84d11:	0f 11 47 09          	movups %xmm0,0x9(%rdi)
   84d15:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   84d1a:	8b 56 21             	mov    0x21(%rsi),%edx
   84d1d:	8b 76 24             	mov    0x24(%rsi),%esi
   84d20:	89 57 39             	mov    %edx,0x39(%rdi)
   84d23:	89 77 3c             	mov    %esi,0x3c(%rdi)
   84d26:	88 4f 08             	mov    %cl,0x8(%rdi)
   84d29:	88 47 38             	mov    %al,0x38(%rdi)
   84d2c:	48 c7 07 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rdi)
   84d33:	e9 18 04 00 00       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   84d38:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
   84d3f:	00 
   84d40:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
   84d47:	00 
   84d48:	48 8b 9c 24 88 00 00 	mov    0x88(%rsp),%rbx
   84d4f:	00 
   84d50:	f3 0f 6f 84 24 90 00 	movdqu 0x90(%rsp),%xmm0
   84d57:	00 00 
   84d59:	66 0f 7f 84 24 f0 04 	movdqa %xmm0,0x4f0(%rsp)
   84d60:	00 00 
   84d62:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   84d69:	00 00 
   84d6b:	8b 84 24 b1 00 00 00 	mov    0xb1(%rsp),%eax
   84d72:	89 84 24 90 03 00 00 	mov    %eax,0x390(%rsp)
   84d79:	8b 84 24 b4 00 00 00 	mov    0xb4(%rsp),%eax
   84d80:	89 84 24 93 03 00 00 	mov    %eax,0x393(%rsp)
   84d87:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
   84d8b:	66 0f 6f 8c 24 20 02 	movdqa 0x220(%rsp),%xmm1
   84d92:	00 00 
   84d94:	0f 84 af 01 00 00    	je     84f49 <<oriole::Parser>::next_event_inner+0x3a99>
   84d9a:	66 0f 70 c1 ee       	pshufd $0xee,%xmm1,%xmm0
   84d9f:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   84da4:	48 85 c9             	test   %rcx,%rcx
   84da7:	0f 84 9c 01 00 00    	je     84f49 <<oriole::Parser>::next_event_inner+0x3a99>
   84dad:	66 48 0f 7e ce       	movq   %xmm1,%rsi
   84db2:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   84db9:	00 
   84dba:	ba 01 00 00 00       	mov    $0x1,%edx
   84dbf:	66 0f 7f 14 24       	movdqa %xmm2,(%rsp)
   84dc4:	ff 15 9e 1a 06 00    	call   *0x61a9e(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   84dca:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
   84dcf:	e9 75 01 00 00       	jmp    84f49 <<oriole::Parser>::next_event_inner+0x3a99>
   84dd4:	66 0f ef c0          	pxor   %xmm0,%xmm0
   84dd8:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   84ddd:	f3 0f 7f 41 28       	movdqu %xmm0,0x28(%rcx)
   84de2:	48 8d 05 b3 c6 f8 ff 	lea    -0x7394d(%rip),%rax        # 1149c <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   84de9:	48 89 41 08          	mov    %rax,0x8(%rcx)
   84ded:	48 c7 41 10 0d 00 00 	movq   $0xd,0x10(%rcx)
   84df4:	00 
   84df5:	48 c7 41 18 00 00 00 	movq   $0x0,0x18(%rcx)
   84dfc:	00 
   84dfd:	48 c7 41 20 01 00 00 	movq   $0x1,0x20(%rcx)
   84e04:	00 
   84e05:	c6 41 38 00          	movb   $0x0,0x38(%rcx)
   84e09:	e9 90 01 00 00       	jmp    84f9e <<oriole::Parser>::next_event_inner+0x3aee>
   84e0e:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
   84e15:	00 
   84e16:	48 8b 9c 24 88 00 00 	mov    0x88(%rsp),%rbx
   84e1d:	00 
   84e1e:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   84e25:	00 00 
   84e27:	f3 0f 6f 84 24 a0 00 	movdqu 0xa0(%rsp),%xmm0
   84e2e:	00 00 
   84e30:	8b 84 24 b1 00 00 00 	mov    0xb1(%rsp),%eax
   84e37:	89 84 24 90 03 00 00 	mov    %eax,0x390(%rsp)
   84e3e:	8b 84 24 b4 00 00 00 	mov    0xb4(%rsp),%eax
   84e45:	89 84 24 93 03 00 00 	mov    %eax,0x393(%rsp)
   84e4c:	e9 62 03 00 00       	jmp    851b3 <<oriole::Parser>::next_event_inner+0x3d03>
   84e51:	48 8d 0d 37 da f8 ff 	lea    -0x725c9(%rip),%rcx        # 1288f <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f03>
   84e58:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84e5f:	00 
   84e60:	41 b8 2d 00 00 00    	mov    $0x2d,%r8d
   84e66:	4c 89 fe             	mov    %r15,%rsi
   84e69:	ba 03 00 00 00       	mov    $0x3,%edx
   84e6e:	e9 67 02 00 00       	jmp    850da <<oriole::Parser>::next_event_inner+0x3c2a>
   84e73:	8b 8c 24 58 02 00 00 	mov    0x258(%rsp),%ecx
   84e7a:	48 8b 04 24          	mov    (%rsp),%rax
   84e7e:	48 8b b0 80 01 00 00 	mov    0x180(%rax),%rsi
   84e85:	48 8b 90 90 01 00 00 	mov    0x190(%rax),%rdx
   84e8c:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   84e93:	00 
   84e94:	4d 89 f8             	mov    %r15,%r8
   84e97:	e8 c4 81 fc ff       	call   4d060 <<oriole::Parser>::next_event_inner::{closure#3}>
   84e9c:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
   84ea3:	00 
   84ea4:	0f 28 8c 24 a0 00 00 	movaps 0xa0(%rsp),%xmm1
   84eab:	00 
   84eac:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   84eb1:	0f 11 4a 28          	movups %xmm1,0x28(%rdx)
   84eb5:	0f 11 42 18          	movups %xmm0,0x18(%rdx)
   84eb9:	0f b6 84 24 b0 00 00 	movzbl 0xb0(%rsp),%eax
   84ec0:	00 
   84ec1:	8b 8c 24 b1 00 00 00 	mov    0xb1(%rsp),%ecx
   84ec8:	89 4a 39             	mov    %ecx,0x39(%rdx)
   84ecb:	8b 8c 24 b4 00 00 00 	mov    0xb4(%rsp),%ecx
   84ed2:	89 4a 3c             	mov    %ecx,0x3c(%rdx)
   84ed5:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
   84edc:	00 
   84edd:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
   84ee1:	88 42 38             	mov    %al,0x38(%rdx)
   84ee4:	48 c7 02 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rdx)
   84eeb:	e9 60 02 00 00       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   84ef0:	4c 8b 34 24          	mov    (%rsp),%r14
   84ef4:	49 83 be 90 01 00 00 	cmpq   $0x1,0x190(%r14)
   84efb:	01 
   84efc:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
   84f01:	0f 85 6b 03 00 00    	jne    85272 <<oriole::Parser>::next_event_inner+0x3dc2>
   84f07:	49 8b be 80 01 00 00 	mov    0x180(%r14),%rdi
   84f0e:	83 3f 01             	cmpl   $0x1,(%rdi)
   84f11:	0f 85 01 03 00 00    	jne    85218 <<oriole::Parser>::next_event_inner+0x3d68>
   84f17:	4c 8b 7f 08          	mov    0x8(%rdi),%r15
   84f1b:	e9 08 03 00 00       	jmp    85228 <<oriole::Parser>::next_event_inner+0x3d78>
   84f20:	83 3f 01             	cmpl   $0x1,(%rdi)
   84f23:	0f 85 39 02 00 00    	jne    85162 <<oriole::Parser>::next_event_inner+0x3cb2>
   84f29:	f3 0f 6f 8b 88 fe ff 	movdqu -0x178(%rbx),%xmm1
   84f30:	ff 
   84f31:	f3 0f 6f 83 98 fe ff 	movdqu -0x168(%rbx),%xmm0
   84f38:	ff 
   84f39:	e9 66 02 00 00       	jmp    851a4 <<oriole::Parser>::next_event_inner+0x3cf4>
   84f3e:	66 0f ef d2          	pxor   %xmm2,%xmm2
   84f42:	bb 0d 00 00 00       	mov    $0xd,%ebx
   84f47:	31 ed                	xor    %ebp,%ebp
   84f49:	4c 8b ac 24 38 03 00 	mov    0x338(%rsp),%r13
   84f50:	00 
   84f51:	66 0f 6f 8c 24 f0 04 	movdqa 0x4f0(%rsp),%xmm1
   84f58:	00 00 
   84f5a:	66 0f 6f c2          	movdqa %xmm2,%xmm0
   84f5e:	e9 50 02 00 00       	jmp    851b3 <<oriole::Parser>::next_event_inner+0x3d03>
   84f63:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
   84f6a:	00 
   84f6b:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   84f70:	48 89 41 38          	mov    %rax,0x38(%rcx)
   84f74:	f3 0f 6f 84 24 20 04 	movdqu 0x420(%rsp),%xmm0
   84f7b:	00 00 
   84f7d:	f3 0f 6f 8c 24 30 04 	movdqu 0x430(%rsp),%xmm1
   84f84:	00 00 
   84f86:	f3 0f 6f 94 24 40 04 	movdqu 0x440(%rsp),%xmm2
   84f8d:	00 00 
   84f8f:	f3 0f 7f 51 28       	movdqu %xmm2,0x28(%rcx)
   84f94:	f3 0f 7f 49 18       	movdqu %xmm1,0x18(%rcx)
   84f99:	f3 0f 7f 41 08       	movdqu %xmm0,0x8(%rcx)
   84f9e:	48 c7 01 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rcx)
   84fa5:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   84fac:	00 
   84fad:	e8 1e 49 fc ff       	call   498d0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   84fb2:	e9 99 01 00 00       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   84fb7:	bb 0d 00 00 00       	mov    $0xd,%ebx
   84fbc:	31 ed                	xor    %ebp,%ebp
   84fbe:	4c 8d 2d d7 c4 f8 ff 	lea    -0x73b29(%rip),%r13        # 1149c <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   84fc5:	66 0f 6f 0d b3 37 f8 	movdqa -0x7c84d(%rip),%xmm1        # 8780 <std::thread::current::id::ID+0x8710>
   84fcc:	ff 
   84fcd:	66 0f ef c0          	pxor   %xmm0,%xmm0
   84fd1:	e9 dd 01 00 00       	jmp    851b3 <<oriole::Parser>::next_event_inner+0x3d03>
   84fd6:	48 83 f9 01          	cmp    $0x1,%rcx
   84fda:	0f 84 d3 00 00 00    	je     850b3 <<oriole::Parser>::next_event_inner+0x3c03>
   84fe0:	c6 84 24 40 03 00 00 	movb   $0x0,0x340(%rsp)
   84fe7:	00 
   84fe8:	ba 01 00 00 00       	mov    $0x1,%edx
   84fed:	4c 8d 05 7c f0 05 00 	lea    0x5f07c(%rip),%r8        # e4070 <oriole_expat::FEATURES+0x14c8>
   84ff4:	48 89 c7             	mov    %rax,%rdi
   84ff7:	48 89 ce             	mov    %rcx,%rsi
   84ffa:	ff 15 70 1e 06 00    	call   *0x61e70(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   85000:	41 80 bf b4 08 00 00 	cmpb   $0x0,0x8b4(%r15)
   85007:	00 
   85008:	b8 08 00 00 00       	mov    $0x8,%eax
   8500d:	ba 01 00 00 00       	mov    $0x1,%edx
   85012:	0f 45 d0             	cmovne %eax,%edx
   85015:	48 8d 0d a0 d8 f8 ff 	lea    -0x72760(%rip),%rcx        # 128bc <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f30>
   8501c:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   85023:	00 
   85024:	41 b8 22 00 00 00    	mov    $0x22,%r8d
   8502a:	4c 89 fe             	mov    %r15,%rsi
   8502d:	e9 a8 00 00 00       	jmp    850da <<oriole::Parser>::next_event_inner+0x3c2a>
   85032:	41 80 be b7 08 00 00 	cmpb   $0x0,0x8b7(%r14)
   85039:	00 
   8503a:	0f 84 a9 02 00 00    	je     852e9 <<oriole::Parser>::next_event_inner+0x3e39>
   85040:	48 8d 0d 10 d8 f8 ff 	lea    -0x727f0(%rip),%rcx        # 12857 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5ecb>
   85047:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8504e:	00 
   8504f:	41 b8 16 00 00 00    	mov    $0x16,%r8d
   85055:	4c 89 f6             	mov    %r14,%rsi
   85058:	ba 13 00 00 00       	mov    $0x13,%edx
   8505d:	e9 31 02 00 00       	jmp    85293 <<oriole::Parser>::next_event_inner+0x3de3>
   85062:	48 8d 3d 61 d3 f8 ff 	lea    -0x72c9f(%rip),%rdi        # 123ca <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   85069:	48 8d 15 f8 f1 05 00 	lea    0x5f1f8(%rip),%rdx        # e4268 <oriole_expat::FEATURES+0x16c0>
   85070:	be 21 00 00 00       	mov    $0x21,%esi
   85075:	ff 15 15 1e 06 00    	call   *0x61e15(%rip)        # e6e90 <_GLOBAL_OFFSET_TABLE_+0x758>
   8507b:	48 8d 05 a6 ef 05 00 	lea    0x5efa6(%rip),%rax        # e4028 <oriole_expat::FEATURES+0x1480>
   85082:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   85089:	00 
   8508a:	48 8d 05 c7 ef 05 00 	lea    0x5efc7(%rip),%rax        # e4058 <oriole_expat::FEATURES+0x14b0>
   85091:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   85098:	00 
   85099:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   850a0:	00 
   850a1:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
   850a6:	e8 65 6f fc ff       	call   4c010 <<core::slice::iter::Iter<&str> as core::iter::traits::iterator::Iterator>::any::<<oriole::Parser>::next_event_inner::{closure#1}>>
   850ab:	84 c0                	test   %al,%al
   850ad:	0f 84 da 02 00 00    	je     8538d <<oriole::Parser>::next_event_inner+0x3edd>
   850b3:	49 83 bf 90 01 00 00 	cmpq   $0x1,0x190(%r15)
   850ba:	01 
   850bb:	76 66                	jbe    85123 <<oriole::Parser>::next_event_inner+0x3c73>
   850bd:	48 8d 0d 46 d8 f8 ff 	lea    -0x727ba(%rip),%rcx        # 1290a <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f7e>
   850c4:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   850cb:	00 
   850cc:	41 b8 11 00 00 00    	mov    $0x11,%r8d
   850d2:	4c 89 fe             	mov    %r15,%rsi
   850d5:	ba 04 00 00 00       	mov    $0x4,%edx
   850da:	e8 91 b3 00 00       	call   90470 <<oriole::Parser>::err>
   850df:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   850e6:	00 
   850e7:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   850ec:	48 89 41 38          	mov    %rax,0x38(%rcx)
   850f0:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   850f7:	00 00 
   850f9:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   85100:	00 00 
   85102:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   85109:	00 00 
   8510b:	f3 0f 7f 51 28       	movdqu %xmm2,0x28(%rcx)
   85110:	f3 0f 7f 49 18       	movdqu %xmm1,0x18(%rcx)
   85115:	f3 0f 7f 41 08       	movdqu %xmm0,0x8(%rcx)
   8511a:	48 c7 01 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rcx)
   85121:	eb 2d                	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   85123:	41 0f b6 87 28 01 00 	movzbl 0x128(%r15),%eax
   8512a:	00 
   8512b:	34 01                	xor    $0x1,%al
   8512d:	41 84 87 b8 08 00 00 	test   %al,0x8b8(%r15)
   85134:	75 87                	jne    850bd <<oriole::Parser>::next_event_inner+0x3c0d>
   85136:	41 80 bf f8 07 00 00 	cmpb   $0xff,0x7f8(%r15)
   8513d:	ff 
   8513e:	0f 85 79 ff ff ff    	jne    850bd <<oriole::Parser>::next_event_inner+0x3c0d>
   85144:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   85149:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
   85150:	48 81 c4 88 05 00 00 	add    $0x588,%rsp
   85157:	5b                   	pop    %rbx
   85158:	41 5c                	pop    %r12
   8515a:	41 5d                	pop    %r13
   8515c:	41 5e                	pop    %r14
   8515e:	41 5f                	pop    %r15
   85160:	5d                   	pop    %rbp
   85161:	c3                   	ret
   85162:	f2 0f 10 43 d8       	movsd  -0x28(%rbx),%xmm0
   85167:	f2 0f 10 4b a8       	movsd  -0x58(%rbx),%xmm1
   8516c:	0f 16 c8             	movlhps %xmm0,%xmm1
   8516f:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   85173:	f2 0f 10 43 e0       	movsd  -0x20(%rbx),%xmm0
   85178:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   8517f:	00 
   85180:	31 f6                	xor    %esi,%esi
   85182:	31 d2                	xor    %edx,%edx
   85184:	e8 c7 a5 fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   85189:	66 0f 6f 0c 24       	movdqa (%rsp),%xmm1
   8518e:	66 48 0f 6e c0       	movq   %rax,%xmm0
   85193:	66 0f 6f 94 24 20 02 	movdqa 0x220(%rsp),%xmm2
   8519a:	00 00 
   8519c:	66 0f 6c d0          	punpcklqdq %xmm0,%xmm2
   851a0:	66 0f 6f c2          	movdqa %xmm2,%xmm0
   851a4:	4c 8d 2d 74 c2 f8 ff 	lea    -0x73d8c(%rip),%r13        # 1141f <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4a93>
   851ab:	40 b5 03             	mov    $0x3,%bpl
   851ae:	bb 15 00 00 00       	mov    $0x15,%ebx
   851b3:	8b 84 24 90 03 00 00 	mov    0x390(%rsp),%eax
   851ba:	8b 8c 24 93 03 00 00 	mov    0x393(%rsp),%ecx
   851c1:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   851c6:	89 4a 3c             	mov    %ecx,0x3c(%rdx)
   851c9:	89 42 39             	mov    %eax,0x39(%rdx)
   851cc:	4c 89 6a 08          	mov    %r13,0x8(%rdx)
   851d0:	48 89 5a 10          	mov    %rbx,0x10(%rdx)
   851d4:	f3 0f 7f 4a 18       	movdqu %xmm1,0x18(%rdx)
   851d9:	f3 0f 7f 42 28       	movdqu %xmm0,0x28(%rdx)
   851de:	40 88 6a 38          	mov    %bpl,0x38(%rdx)
   851e2:	48 c7 02 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rdx)
   851e9:	e9 62 ff ff ff       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   851ee:	48 8d 0d f8 c1 f8 ff 	lea    -0x73e08(%rip),%rcx        # 113ed <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4a61>
   851f5:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   851fc:	00 
   851fd:	41 b8 14 00 00 00    	mov    $0x14,%r8d
   85203:	4c 89 fe             	mov    %r15,%rsi
   85206:	ba 03 00 00 00       	mov    $0x3,%edx
   8520b:	49 89 d9             	mov    %rbx,%r9
   8520e:	e8 bd bc 00 00       	call   90ed0 <<oriole::Parser>::err_at>
   85213:	e9 c7 fe ff ff       	jmp    850df <<oriole::Parser>::next_event_inner+0x3c2f>
   85218:	4c 8b bf 28 01 00 00 	mov    0x128(%rdi),%r15
   8521f:	31 f6                	xor    %esi,%esi
   85221:	31 d2                	xor    %edx,%edx
   85223:	e8 28 a5 fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   85228:	4c 8b 34 24          	mov    (%rsp),%r14
   8522c:	4d 3b be 68 08 00 00 	cmp    0x868(%r14),%r15
   85233:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
   85238:	75 38                	jne    85272 <<oriole::Parser>::next_event_inner+0x3dc2>
   8523a:	49 8b 86 90 01 00 00 	mov    0x190(%r14),%rax
   85241:	48 85 c0             	test   %rax,%rax
   85244:	0f 84 58 03 00 00    	je     855a2 <<oriole::Parser>::next_event_inner+0x40f2>
   8524a:	4c 8b 34 24          	mov    (%rsp),%r14
   8524e:	49 8b 8e 80 01 00 00 	mov    0x180(%r14),%rcx
   85255:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   85259:	48 c1 e0 07          	shl    $0x7,%rax
   8525d:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
   85261:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
   85268:	e8 b3 9a fe ff       	call   6ed20 <<oriole::encoding::Source>::mark_deferred>
   8526d:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
   85272:	84 db                	test   %bl,%bl
   85274:	74 67                	je     852dd <<oriole::Parser>::next_event_inner+0x3e2d>
   85276:	48 8d 0d 9e d6 f8 ff 	lea    -0x72962(%rip),%rcx        # 1291b <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f8f>
   8527d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   85284:	00 
   85285:	41 b8 12 00 00 00    	mov    $0x12,%r8d
   8528b:	4c 89 f6             	mov    %r14,%rsi
   8528e:	ba 04 00 00 00       	mov    $0x4,%edx
   85293:	e8 d8 b1 00 00       	call   90470 <<oriole::Parser>::err>
   85298:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   8529f:	00 
   852a0:	49 89 47 38          	mov    %rax,0x38(%r15)
   852a4:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
   852ab:	00 00 
   852ad:	f3 0f 6f 8c 24 90 00 	movdqu 0x90(%rsp),%xmm1
   852b4:	00 00 
   852b6:	f3 0f 6f 94 24 a0 00 	movdqu 0xa0(%rsp),%xmm2
   852bd:	00 00 
   852bf:	f3 41 0f 7f 57 28    	movdqu %xmm2,0x28(%r15)
   852c5:	f3 41 0f 7f 4f 18    	movdqu %xmm1,0x18(%r15)
   852cb:	f3 41 0f 7f 47 08    	movdqu %xmm0,0x8(%r15)
   852d1:	49 c7 07 fe ff ff ff 	movq   $0xfffffffffffffffe,(%r15)
   852d8:	e9 73 fe ff ff       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   852dd:	49 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%r15)
   852e4:	e9 67 fe ff ff       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   852e9:	41 0f b6 86 ba 08 00 	movzbl 0x8ba(%r14),%eax
   852f0:	00 
   852f1:	41 0f b6 8e b3 08 00 	movzbl 0x8b3(%r14),%ecx
   852f8:	00 
   852f9:	08 c1                	or     %al,%cl
   852fb:	f6 c1 01             	test   $0x1,%cl
   852fe:	0f 84 fc 00 00 00    	je     85400 <<oriole::Parser>::next_event_inner+0x3f50>
   85304:	48 8b 0c 24          	mov    (%rsp),%rcx
   85308:	48 83 b9 08 02 00 00 	cmpq   $0x0,0x208(%rcx)
   8530f:	00 
   85310:	0f 84 e3 01 00 00    	je     854f9 <<oriole::Parser>::next_event_inner+0x4049>
   85316:	a8 01                	test   $0x1,%al
   85318:	b8 0c 00 00 00       	mov    $0xc,%eax
   8531d:	ba 02 00 00 00       	mov    $0x2,%edx
   85322:	0f 45 d0             	cmovne %eax,%edx
   85325:	48 8d 0d b4 34 f8 ff 	lea    -0x7cb4c(%rip),%rcx        # 87e0 <std::thread::current::id::ID+0x8770>
   8532c:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   85333:	00 
   85334:	41 b8 10 00 00 00    	mov    $0x10,%r8d
   8533a:	48 8b 34 24          	mov    (%rsp),%rsi
   8533e:	e9 97 fd ff ff       	jmp    850da <<oriole::Parser>::next_event_inner+0x3c2a>
   85343:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   85348:	83 38 01             	cmpl   $0x1,(%rax)
   8534b:	0f 85 d2 00 00 00    	jne    85423 <<oriole::Parser>::next_event_inner+0x3f73>
   85351:	48 8b 9f 88 fe ff ff 	mov    -0x178(%rdi),%rbx
   85358:	0f 10 87 90 fe ff ff 	movups -0x170(%rdi),%xmm0
   8535f:	0f 29 04 24          	movaps %xmm0,(%rsp)
   85363:	48 8b 87 a0 fe ff ff 	mov    -0x160(%rdi),%rax
   8536a:	e9 ce 00 00 00       	jmp    8543d <<oriole::Parser>::next_event_inner+0x3f8d>
   8536f:	48 8d 3d 54 d9 f8 ff 	lea    -0x726ac(%rip),%rdi        # 12cca <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x633e>
   85376:	48 8d 15 1b ef 05 00 	lea    0x5ef1b(%rip),%rdx        # e4298 <oriole_expat::FEATURES+0x16f0>
   8537d:	be 17 00 00 00       	mov    $0x17,%esi
   85382:	ff 15 08 1b 06 00    	call   *0x61b08(%rip)        # e6e90 <_GLOBAL_OFFSET_TABLE_+0x758>
   85388:	e9 a7 03 00 00       	jmp    85734 <<oriole::Parser>::next_event_inner+0x4284>
   8538d:	48 8d 0d 5c d5 f8 ff 	lea    -0x72aa4(%rip),%rcx        # 128f0 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f64>
   85394:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8539b:	00 
   8539c:	41 b8 1a 00 00 00    	mov    $0x1a,%r8d
   853a2:	e9 bf fa ff ff       	jmp    84e66 <<oriole::Parser>::next_event_inner+0x39b6>
   853a7:	48 8d 0d 65 c9 f8 ff 	lea    -0x7369b(%rip),%rcx        # 11d13 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5387>
   853ae:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   853b5:	00 
   853b6:	41 b8 25 00 00 00    	mov    $0x25,%r8d
   853bc:	41 b9 02 00 00 00    	mov    $0x2,%r9d
   853c2:	4c 89 fe             	mov    %r15,%rsi
   853c5:	ba 03 00 00 00       	mov    $0x3,%edx
   853ca:	e8 01 bb 00 00       	call   90ed0 <<oriole::Parser>::err_at>
   853cf:	e9 0b fd ff ff       	jmp    850df <<oriole::Parser>::next_event_inner+0x3c2f>
   853d4:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   853d9:	83 38 01             	cmpl   $0x1,(%rax)
   853dc:	0f 85 cc 00 00 00    	jne    854ae <<oriole::Parser>::next_event_inner+0x3ffe>
   853e2:	48 8b 9f 88 fe ff ff 	mov    -0x178(%rdi),%rbx
   853e9:	0f 10 87 90 fe ff ff 	movups -0x170(%rdi),%xmm0
   853f0:	0f 29 04 24          	movaps %xmm0,(%rsp)
   853f4:	48 8b 87 a0 fe ff ff 	mov    -0x160(%rdi),%rax
   853fb:	e9 c8 00 00 00       	jmp    854c8 <<oriole::Parser>::next_event_inner+0x4018>
   85400:	48 8d 0d 34 d4 f8 ff 	lea    -0x72bcc(%rip),%rcx        # 1283b <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5eaf>
   85407:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8540e:	00 
   8540f:	41 b8 1c 00 00 00    	mov    $0x1c,%r8d
   85415:	48 8b 34 24          	mov    (%rsp),%rsi
   85419:	ba 02 00 00 00       	mov    $0x2,%edx
   8541e:	e9 b7 fc ff ff       	jmp    850da <<oriole::Parser>::next_event_inner+0x3c2a>
   85423:	48 8b 5f a8          	mov    -0x58(%rdi),%rbx
   85427:	0f 10 47 d8          	movups -0x28(%rdi),%xmm0
   8542b:	0f 29 04 24          	movaps %xmm0,(%rsp)
   8542f:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   85434:	31 f6                	xor    %esi,%esi
   85436:	31 d2                	xor    %edx,%edx
   85438:	e8 13 a3 fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   8543d:	48 8d 0d 68 c8 f8 ff 	lea    -0x73798(%rip),%rcx        # 11cac <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5320>
   85444:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   85449:	48 c7 44 24 28 1c 00 	movq   $0x1c,0x28(%rsp)
   85450:	00 00 
   85452:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   85457:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
   8545c:	f3 0f 7f 44 24 38    	movdqu %xmm0,0x38(%rsp)
   85462:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   85467:	b0 03                	mov    $0x3,%al
   85469:	e9 59 f8 ff ff       	jmp    84cc7 <<oriole::Parser>::next_event_inner+0x3817>
   8546e:	48 8d 05 27 c0 f8 ff 	lea    -0x73fd9(%rip),%rax        # 1149c <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   85475:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   8547a:	48 c7 44 24 28 0d 00 	movq   $0xd,0x28(%rsp)
   85481:	00 00 
   85483:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   8548a:	00 00 
   8548c:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
   85493:	00 00 
   85495:	66 0f ef c0          	pxor   %xmm0,%xmm0
   85499:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   8549e:	66 0f 7f 40 10       	movdqa %xmm0,0x10(%rax)
   854a3:	c6 40 20 00          	movb   $0x0,0x20(%rax)
   854a7:	31 c0                	xor    %eax,%eax
   854a9:	e9 19 f8 ff ff       	jmp    84cc7 <<oriole::Parser>::next_event_inner+0x3817>
   854ae:	48 8b 5f a8          	mov    -0x58(%rdi),%rbx
   854b2:	0f 10 47 d8          	movups -0x28(%rdi),%xmm0
   854b6:	0f 29 04 24          	movaps %xmm0,(%rsp)
   854ba:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   854bf:	31 f6                	xor    %esi,%esi
   854c1:	31 d2                	xor    %edx,%edx
   854c3:	e8 88 a2 fe ff       	call   6f750 <<oriole::encoding::Source>::raw_len>
   854c8:	48 8d 0d 54 c1 f8 ff 	lea    -0x73eac(%rip),%rcx        # 11623 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4c97>
   854cf:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   854d4:	48 c7 44 24 28 2a 00 	movq   $0x2a,0x28(%rsp)
   854db:	00 00 
   854dd:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   854e2:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
   854e7:	f3 0f 7f 44 24 38    	movdqu %xmm0,0x38(%rsp)
   854ed:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   854f2:	b0 01                	mov    $0x1,%al
   854f4:	e9 ce f7 ff ff       	jmp    84cc7 <<oriole::Parser>::next_event_inner+0x3817>
   854f9:	48 8b 04 24          	mov    (%rsp),%rax
   854fd:	c6 80 b9 08 00 00 01 	movb   $0x1,0x8b9(%rax)
   85504:	e9 3b fc ff ff       	jmp    85144 <<oriole::Parser>::next_event_inner+0x3c94>
   85509:	48 8d 0d ac d3 f8 ff 	lea    -0x72c54(%rip),%rcx        # 128bc <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5f30>
   85510:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   85517:	00 
   85518:	41 b8 22 00 00 00    	mov    $0x22,%r8d
   8551e:	4c 89 fe             	mov    %r15,%rsi
   85521:	ba 01 00 00 00       	mov    $0x1,%edx
   85526:	e9 af fb ff ff       	jmp    850da <<oriole::Parser>::next_event_inner+0x3c2a>
   8552b:	48 8d 05 6a bf f8 ff 	lea    -0x74096(%rip),%rax        # 1149c <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x4b10>
   85532:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   85537:	48 89 41 08          	mov    %rax,0x8(%rcx)
   8553b:	48 c7 41 10 0d 00 00 	movq   $0xd,0x10(%rcx)
   85542:	00 
   85543:	48 c7 41 18 00 00 00 	movq   $0x0,0x18(%rcx)
   8554a:	00 
   8554b:	48 c7 41 20 01 00 00 	movq   $0x1,0x20(%rcx)
   85552:	00 
   85553:	66 0f ef c0          	pxor   %xmm0,%xmm0
   85557:	f3 0f 7f 41 28       	movdqu %xmm0,0x28(%rcx)
   8555c:	c6 41 38 00          	movb   $0x0,0x38(%rcx)
   85560:	48 c7 01 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rcx)
   85567:	e9 e4 fb ff ff       	jmp    85150 <<oriole::Parser>::next_event_inner+0x3ca0>
   8556c:	4c 8d 05 3d e1 05 00 	lea    0x5e13d(%rip),%r8        # e36b0 <oriole_expat::FEATURES+0xb08>
   85573:	4c 89 ef             	mov    %r13,%rdi
   85576:	48 89 ee             	mov    %rbp,%rsi
   85579:	31 d2                	xor    %edx,%edx
   8557b:	4c 89 f9             	mov    %r15,%rcx
   8557e:	ff 15 ec 18 06 00    	call   *0x618ec(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   85584:	48 8d 3d 3f ce f8 ff 	lea    -0x731c1(%rip),%rdi        # 123ca <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   8558b:	48 8d 15 d6 ec 05 00 	lea    0x5ecd6(%rip),%rdx        # e4268 <oriole_expat::FEATURES+0x16c0>
   85592:	be 21 00 00 00       	mov    $0x21,%esi
   85597:	ff 15 f3 18 06 00    	call   *0x618f3(%rip)        # e6e90 <_GLOBAL_OFFSET_TABLE_+0x758>
   8559d:	e9 92 01 00 00       	jmp    85734 <<oriole::Parser>::next_event_inner+0x4284>
   855a2:	48 8d 3d 21 ce f8 ff 	lea    -0x731df(%rip),%rdi        # 123ca <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   855a9:	48 8d 15 b0 e8 05 00 	lea    0x5e8b0(%rip),%rdx        # e3e60 <oriole_expat::FEATURES+0x12b8>
   855b0:	be 21 00 00 00       	mov    $0x21,%esi
   855b5:	ff 15 d5 18 06 00    	call   *0x618d5(%rip)        # e6e90 <_GLOBAL_OFFSET_TABLE_+0x758>
   855bb:	4c 8d 05 7e e0 05 00 	lea    0x5e07e(%rip),%r8        # e3640 <oriole_expat::FEATURES+0xa98>
   855c2:	48 89 c7             	mov    %rax,%rdi
   855c5:	48 89 d6             	mov    %rdx,%rsi
   855c8:	31 d2                	xor    %edx,%edx
   855ca:	4c 89 f9             	mov    %r15,%rcx
   855cd:	ff 15 9d 18 06 00    	call   *0x6189d(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   855d3:	4c 8d 05 3e e5 05 00 	lea    0x5e53e(%rip),%r8        # e3b18 <oriole_expat::FEATURES+0xf70>
   855da:	4c 89 ef             	mov    %r13,%rdi
   855dd:	4c 89 e2             	mov    %r12,%rdx
   855e0:	48 89 f1             	mov    %rsi,%rcx
   855e3:	ff 15 87 18 06 00    	call   *0x61887(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   855e9:	48 8d 3d f1 d6 f8 ff 	lea    -0x7290f(%rip),%rdi        # 12ce1 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x6355>
   855f0:	48 8d 15 01 ed 05 00 	lea    0x5ed01(%rip),%rdx        # e42f8 <oriole_expat::FEATURES+0x1750>
   855f7:	be 16 00 00 00       	mov    $0x16,%esi
   855fc:	ff 15 8e 18 06 00    	call   *0x6188e(%rip)        # e6e90 <_GLOBAL_OFFSET_TABLE_+0x758>
   85602:	4c 89 c1             	mov    %r8,%rcx
   85605:	4c 8d 05 d4 ec 05 00 	lea    0x5ecd4(%rip),%r8        # e42e0 <oriole_expat::FEATURES+0x1738>
   8560c:	4c 89 df             	mov    %r11,%rdi
   8560f:	48 89 ce             	mov    %rcx,%rsi
   85612:	4c 89 ea             	mov    %r13,%rdx
   85615:	ff 15 55 18 06 00    	call   *0x61855(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   8561b:	4c 8d 05 76 e0 05 00 	lea    0x5e076(%rip),%r8        # e3698 <oriole_expat::FEATURES+0xaf0>
   85622:	ba 01 00 00 00       	mov    $0x1,%edx
   85627:	4c 89 ef             	mov    %r13,%rdi
   8562a:	48 89 ee             	mov    %rbp,%rsi
   8562d:	ff 15 3d 18 06 00    	call   *0x6183d(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   85633:	49 f7 df             	neg    %r15
   85636:	4c 8d 05 d3 d8 05 00 	lea    0x5d8d3(%rip),%r8        # e2f10 <oriole_expat::FEATURES+0x368>
   8563d:	4c 89 ef             	mov    %r13,%rdi
   85640:	48 89 ee             	mov    %rbp,%rsi
   85643:	4c 89 fa             	mov    %r15,%rdx
   85646:	48 89 e9             	mov    %rbp,%rcx
   85649:	ff 15 21 18 06 00    	call   *0x61821(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   8564f:	4c 8d 05 c2 e4 05 00 	lea    0x5e4c2(%rip),%r8        # e3b18 <oriole_expat::FEATURES+0xf70>
   85656:	4c 89 cf             	mov    %r9,%rdi
   85659:	48 89 ce             	mov    %rcx,%rsi
   8565c:	4c 89 e2             	mov    %r12,%rdx
   8565f:	ff 15 0b 18 06 00    	call   *0x6180b(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   85665:	4c 8d 05 0c e8 05 00 	lea    0x5e80c(%rip),%r8        # e3e78 <oriole_expat::FEATURES+0x12d0>
   8566c:	4c 89 ef             	mov    %r13,%rdi
   8566f:	31 d2                	xor    %edx,%edx
   85671:	48 89 e9             	mov    %rbp,%rcx
   85674:	ff 15 f6 17 06 00    	call   *0x617f6(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   8567a:	4c 8d 05 27 e8 05 00 	lea    0x5e827(%rip),%r8        # e3ea8 <oriole_expat::FEATURES+0x1300>
   85681:	e9 ed fe ff ff       	jmp    85573 <<oriole::Parser>::next_event_inner+0x40c3>
   85686:	4c 8d 05 33 e8 05 00 	lea    0x5e833(%rip),%r8        # e3ec0 <oriole_expat::FEATURES+0x1318>
   8568d:	e9 e1 fe ff ff       	jmp    85573 <<oriole::Parser>::next_event_inner+0x40c3>
   85692:	48 8d 3d 31 cd f8 ff 	lea    -0x732cf(%rip),%rdi        # 123ca <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   85699:	48 8d 15 c8 eb 05 00 	lea    0x5ebc8(%rip),%rdx        # e4268 <oriole_expat::FEATURES+0x16c0>
   856a0:	be 21 00 00 00       	mov    $0x21,%esi
   856a5:	ff 15 e5 17 06 00    	call   *0x617e5(%rip)        # e6e90 <_GLOBAL_OFFSET_TABLE_+0x758>
   856ab:	e9 84 00 00 00       	jmp    85734 <<oriole::Parser>::next_event_inner+0x4284>
   856b0:	48 8d 15 d9 e7 05 00 	lea    0x5e7d9(%rip),%rdx        # e3e90 <oriole_expat::FEATURES+0x12e8>
   856b7:	48 89 ee             	mov    %rbp,%rsi
   856ba:	ff 15 20 17 06 00    	call   *0x61720(%rip)        # e6de0 <_GLOBAL_OFFSET_TABLE_+0x6a8>
   856c0:	4c 8d 05 91 e9 05 00 	lea    0x5e991(%rip),%r8        # e4058 <oriole_expat::FEATURES+0x14b0>
   856c7:	ba 02 00 00 00       	mov    $0x2,%edx
   856cc:	48 89 c7             	mov    %rax,%rdi
   856cf:	48 89 ce             	mov    %rcx,%rsi
   856d2:	ff 15 98 17 06 00    	call   *0x61798(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   856d8:	31 c9                	xor    %ecx,%ecx
   856da:	48 8d 05 ff df 05 00 	lea    0x5dfff(%rip),%rax        # e36e0 <oriole_expat::FEATURES+0xb38>
   856e1:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
   856e8:	00 
   856e9:	eb 1a                	jmp    85705 <<oriole::Parser>::next_event_inner+0x4255>
   856eb:	48 8d 05 36 df 05 00 	lea    0x5df36(%rip),%rax        # e3628 <oriole_expat::FEATURES+0xa80>
   856f2:	48 89 d6             	mov    %rdx,%rsi
   856f5:	48 89 c2             	mov    %rax,%rdx
   856f8:	ff 15 e2 16 06 00    	call   *0x616e2(%rip)        # e6de0 <_GLOBAL_OFFSET_TABLE_+0x6a8>
   856fe:	b9 01 00 00 00       	mov    $0x1,%ecx
   85703:	31 d2                	xor    %edx,%edx
   85705:	48 89 ef             	mov    %rbp,%rdi
   85708:	4c 89 ee             	mov    %r13,%rsi
   8570b:	4c 8b 84 24 28 03 00 	mov    0x328(%rsp),%r8
   85712:	00 
   85713:	ff 15 57 17 06 00    	call   *0x61757(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   85719:	eb 19                	jmp    85734 <<oriole::Parser>::next_event_inner+0x4284>
   8571b:	48 8d 3d a8 cc f8 ff 	lea    -0x73358(%rip),%rdi        # 123ca <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5a3e>
   85722:	48 8d 15 3f eb 05 00 	lea    0x5eb3f(%rip),%rdx        # e4268 <oriole_expat::FEATURES+0x16c0>
   85729:	be 21 00 00 00       	mov    $0x21,%esi
   8572e:	ff 15 5c 17 06 00    	call   *0x6175c(%rip)        # e6e90 <_GLOBAL_OFFSET_TABLE_+0x758>
   85734:	0f 0b                	ud2
   85736:	4c 8d 05 d3 de 05 00 	lea    0x5ded3(%rip),%r8        # e3610 <oriole_expat::FEATURES+0xa68>
   8573d:	ba 02 00 00 00       	mov    $0x2,%edx
   85742:	48 8b 8c 24 20 02 00 	mov    0x220(%rsp),%rcx
   85749:	00 
   8574a:	48 89 ce             	mov    %rcx,%rsi
   8574d:	ff 15 1d 17 06 00    	call   *0x6171d(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   85753:	4c 8d 05 9e de 05 00 	lea    0x5de9e(%rip),%r8        # e35f8 <oriole_expat::FEATURES+0xa50>
   8575a:	ba 02 00 00 00       	mov    $0x2,%edx
   8575f:	4c 89 df             	mov    %r11,%rdi
   85762:	48 8b 8c 24 20 02 00 	mov    0x220(%rsp),%rcx
   85769:	00 
   8576a:	48 89 ce             	mov    %rcx,%rsi
   8576d:	ff 15 fd 16 06 00    	call   *0x616fd(%rip)        # e6e70 <_GLOBAL_OFFSET_TABLE_+0x738>
   85773:	48 89 c3             	mov    %rax,%rbx
   85776:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   8577d:	00 
   8577e:	e8 4d 41 fc ff       	call   498d0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   85783:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   8578a:	00 
   8578b:	e8 40 41 fc ff       	call   498d0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   85790:	e9 2e 02 00 00       	jmp    859c3 <<oriole::Parser>::next_event_inner+0x4513>
   85795:	eb 50                	jmp    857e7 <<oriole::Parser>::next_event_inner+0x4337>
   85797:	eb 00                	jmp    85799 <<oriole::Parser>::next_event_inner+0x42e9>
   85799:	48 89 c3             	mov    %rax,%rbx
   8579c:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   857a3:	00 
   857a4:	e8 c7 35 fc ff       	call   48d70 <core::ptr::drop_glue::<oriole::EventKind>>
   857a9:	e9 e4 00 00 00       	jmp    85892 <<oriole::Parser>::next_event_inner+0x43e2>
   857ae:	48 89 c3             	mov    %rax,%rbx
   857b1:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   857b8:	00 
   857b9:	e8 12 41 fc ff       	call   498d0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   857be:	e9 00 02 00 00       	jmp    859c3 <<oriole::Parser>::next_event_inner+0x4513>
   857c3:	eb 22                	jmp    857e7 <<oriole::Parser>::next_event_inner+0x4337>
   857c5:	e9 b8 00 00 00       	jmp    85882 <<oriole::Parser>::next_event_inner+0x43d2>
   857ca:	eb 1b                	jmp    857e7 <<oriole::Parser>::next_event_inner+0x4337>
   857cc:	48 89 c3             	mov    %rax,%rbx
   857cf:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   857d6:	00 
   857d7:	e8 94 45 fc ff       	call   49d70 <core::ptr::drop_glue::<oriole::dtd::composition::Header>>
   857dc:	e9 e2 01 00 00       	jmp    859c3 <<oriole::Parser>::next_event_inner+0x4513>
   857e1:	ff 15 c9 16 06 00    	call   *0x616c9(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
   857e7:	48 89 c3             	mov    %rax,%rbx
   857ea:	e9 a3 00 00 00       	jmp    85892 <<oriole::Parser>::next_event_inner+0x43e2>
   857ef:	48 89 c3             	mov    %rax,%rbx
   857f2:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   857f9:	00 
   857fa:	e8 d1 40 fc ff       	call   498d0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   857ff:	e9 bf 01 00 00       	jmp    859c3 <<oriole::Parser>::next_event_inner+0x4513>
   85804:	ff 15 a6 16 06 00    	call   *0x616a6(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
   8580a:	48 89 c3             	mov    %rax,%rbx
   8580d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   85814:	00 
   85815:	e8 46 41 fc ff       	call   49960 <core::ptr::drop_glue::<oriole::encoding::Source>>
   8581a:	e9 a4 01 00 00       	jmp    859c3 <<oriole::Parser>::next_event_inner+0x4513>
   8581f:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   85826:	00 
   85827:	41 0f 11 45 60       	movups %xmm0,0x60(%r13)
   8582c:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   85833:	00 
   85834:	41 0f 11 45 50       	movups %xmm0,0x50(%r13)
   85839:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
   85840:	00 
   85841:	41 0f 11 45 40       	movups %xmm0,0x40(%r13)
   85846:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
   8584d:	00 
   8584e:	0f 28 8c 24 90 00 00 	movaps 0x90(%rsp),%xmm1
   85855:	00 
   85856:	0f 28 94 24 a0 00 00 	movaps 0xa0(%rsp),%xmm2
   8585d:	00 
   8585e:	0f 28 9c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm3
   85865:	00 
   85866:	41 0f 11 5d 30       	movups %xmm3,0x30(%r13)
   8586b:	41 0f 11 55 20       	movups %xmm2,0x20(%r13)
   85870:	41 0f 11 4d 10       	movups %xmm1,0x10(%r13)
   85875:	41 0f 11 45 00       	movups %xmm0,0x0(%r13)
   8587a:	48 89 c7             	mov    %rax,%rdi
   8587d:	e8 4e 72 fa ff       	call   2cad0 <_Unwind_Resume@plt>
   85882:	48 89 c3             	mov    %rax,%rbx
   85885:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   8588c:	00 
   8588d:	e8 de 34 fc ff       	call   48d70 <core::ptr::drop_glue::<oriole::EventKind>>
   85892:	48 8b 8c 24 b8 03 00 	mov    0x3b8(%rsp),%rcx
   85899:	00 
   8589a:	48 85 c9             	test   %rcx,%rcx
   8589d:	0f 84 20 01 00 00    	je     859c3 <<oriole::Parser>::next_event_inner+0x4513>
   858a3:	48 8b b4 24 b0 03 00 	mov    0x3b0(%rsp),%rsi
   858aa:	00 
   858ab:	48 8d bc 24 90 03 00 	lea    0x390(%rsp),%rdi
   858b2:	00 
   858b3:	ba 01 00 00 00       	mov    $0x1,%edx
   858b8:	ff 15 aa 0f 06 00    	call   *0x60faa(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   858be:	e9 00 01 00 00       	jmp    859c3 <<oriole::Parser>::next_event_inner+0x4513>
   858c3:	ff 15 e7 15 06 00    	call   *0x615e7(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
   858c9:	48 89 c3             	mov    %rax,%rbx
   858cc:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   858d3:	00 
   858d4:	e8 f7 43 fc ff       	call   49cd0 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   858d9:	e9 e5 00 00 00       	jmp    859c3 <<oriole::Parser>::next_event_inner+0x4513>
   858de:	ff 15 cc 15 06 00    	call   *0x615cc(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
   858e4:	e9 ca 00 00 00       	jmp    859b3 <<oriole::Parser>::next_event_inner+0x4503>
   858e9:	48 89 c3             	mov    %rax,%rbx
   858ec:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   858f3:	00 
   858f4:	e8 07 08 fc ff       	call   46100 <core::ptr::drop_glue::<core::option::Option<(oriole_storage::string::String, oriole::Position)>>>
   858f9:	e9 c5 00 00 00       	jmp    859c3 <<oriole::Parser>::next_event_inner+0x4513>
   858fe:	48 89 c3             	mov    %rax,%rbx
   85901:	31 ed                	xor    %ebp,%ebp
   85903:	eb 5d                	jmp    85962 <<oriole::Parser>::next_event_inner+0x44b2>
   85905:	48 89 c3             	mov    %rax,%rbx
   85908:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
   8590f:	00 
   85910:	49 89 46 30          	mov    %rax,0x30(%r14)
   85914:	f3 0f 6f 84 24 50 02 	movdqu 0x250(%rsp),%xmm0
   8591b:	00 00 
   8591d:	f3 0f 6f 8c 24 60 02 	movdqu 0x260(%rsp),%xmm1
   85924:	00 00 
   85926:	f3 0f 6f 94 24 70 02 	movdqu 0x270(%rsp),%xmm2
   8592d:	00 00 
   8592f:	f3 41 0f 7f 56 20    	movdqu %xmm2,0x20(%r14)
   85935:	f3 41 0f 7f 4e 10    	movdqu %xmm1,0x10(%r14)
   8593b:	f3 41 0f 7f 06       	movdqu %xmm0,(%r14)
   85940:	31 ed                	xor    %ebp,%ebp
   85942:	eb 1e                	jmp    85962 <<oriole::Parser>::next_event_inner+0x44b2>
   85944:	48 89 c3             	mov    %rax,%rbx
   85947:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
   8594e:	00 
   8594f:	e8 9c 04 fc ff       	call   45df0 <core::ptr::drop_glue::<core::option::Option<oriole::PendingEvent>>>
   85954:	eb 6d                	jmp    859c3 <<oriole::Parser>::next_event_inner+0x4513>
   85956:	ff 15 54 15 06 00    	call   *0x61554(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
   8595c:	48 89 c3             	mov    %rax,%rbx
   8595f:	40 b5 01             	mov    $0x1,%bpl
   85962:	48 8d bc 24 88 02 00 	lea    0x288(%rsp),%rdi
   85969:	00 
   8596a:	e8 01 34 fc ff       	call   48d70 <core::ptr::drop_glue::<oriole::EventKind>>
   8596f:	83 bc 24 50 02 00 00 	cmpl   $0xffffffff,0x250(%rsp)
   85976:	ff 
   85977:	0f 94 c0             	sete   %al
   8597a:	40 80 f5 01          	xor    $0x1,%bpl
   8597e:	40 08 c5             	or     %al,%bpl
   85981:	75 40                	jne    859c3 <<oriole::Parser>::next_event_inner+0x4513>
   85983:	48 8b 8c 24 78 02 00 	mov    0x278(%rsp),%rcx
   8598a:	00 
   8598b:	48 85 c9             	test   %rcx,%rcx
   8598e:	74 33                	je     859c3 <<oriole::Parser>::next_event_inner+0x4513>
   85990:	48 8b b4 24 70 02 00 	mov    0x270(%rsp),%rsi
   85997:	00 
   85998:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   8599f:	00 
   859a0:	ba 01 00 00 00       	mov    $0x1,%edx
   859a5:	ff 15 bd 0e 06 00    	call   *0x60ebd(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   859ab:	eb 16                	jmp    859c3 <<oriole::Parser>::next_event_inner+0x4513>
   859ad:	ff 15 fd 14 06 00    	call   *0x614fd(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
   859b3:	48 89 c3             	mov    %rax,%rbx
   859b6:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
   859bd:	00 
   859be:	e8 0d 3f fc ff       	call   498d0 <core::ptr::drop_glue::<oriole::lexical::Buffer>>
   859c3:	48 89 df             	mov    %rbx,%rdi
   859c6:	e8 05 71 fa ff       	call   2cad0 <_Unwind_Resume@plt>
   859cb:	ff 15 df 14 06 00    	call   *0x614df(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
