
/tmp/oriole-event-output/control.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000085e40 <<oriole::Parser>::next_event_scoped>:
   85e40:	55                   	push   %rbp
   85e41:	41 57                	push   %r15
   85e43:	41 56                	push   %r14
   85e45:	41 55                	push   %r13
   85e47:	41 54                	push   %r12
   85e49:	53                   	push   %rbx
   85e4a:	48 81 ec 68 04 00 00 	sub    $0x468,%rsp
   85e51:	49 89 f6             	mov    %rsi,%r14
   85e54:	48 89 3c 24          	mov    %rdi,(%rsp)
   85e58:	80 be f1 07 00 00 01 	cmpb   $0x1,0x7f1(%rsi)
   85e5f:	75 4a                	jne    85eab <<oriole::Parser>::next_event_scoped+0x6b>
   85e61:	f3 41 0f 6f 86 d0 07 	movdqu 0x7d0(%r14),%xmm0
   85e68:	00 00 
   85e6a:	41 0f 10 8e e0 07 00 	movups 0x7e0(%r14),%xmm1
   85e71:	00 
   85e72:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   85e79:	00 
   85e7a:	66 0f 7f 84 24 e0 01 	movdqa %xmm0,0x1e0(%rsp)
   85e81:	00 00 
   85e83:	41 0f b6 86 f0 07 00 	movzbl 0x7f0(%r14),%eax
   85e8a:	00 
   85e8b:	41 c6 86 f1 07 00 00 	movb   $0x2,0x7f1(%r14)
   85e92:	02 
   85e93:	41 8b 8e 80 08 00 00 	mov    0x880(%r14),%ecx
   85e9a:	85 c9                	test   %ecx,%ecx
   85e9c:	0f 84 ad 01 00 00    	je     8604f <<oriole::Parser>::next_event_scoped+0x20f>
   85ea2:	24 01                	and    $0x1,%al
   85ea4:	41 88 86 bd 08 00 00 	mov    %al,0x8bd(%r14)
   85eab:	4d 8b be c8 01 00 00 	mov    0x1c8(%r14),%r15
   85eb2:	49 8b 9e d0 01 00 00 	mov    0x1d0(%r14),%rbx
   85eb9:	4c 39 fb             	cmp    %r15,%rbx
   85ebc:	0f 83 9f 02 00 00    	jae    86161 <<oriole::Parser>::next_event_scoped+0x321>
   85ec2:	4d 8b a6 b8 01 00 00 	mov    0x1b8(%r14),%r12
   85ec9:	4c 69 eb d0 00 00 00 	imul   $0xd0,%rbx,%r13
   85ed0:	4b 8d 34 2c          	lea    (%r12,%r13,1),%rsi
   85ed4:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   85edb:	00 
   85edc:	ba d0 00 00 00       	mov    $0xd0,%edx
   85ee1:	ff 15 69 12 06 00    	call   *0x61269(%rip)        # e7150 <memcpy@GLIBC_2.14>
   85ee7:	4b c7 04 2c fe ff ff 	movq   $0xfffffffffffffffe,(%r12,%r13,1)
   85eee:	ff 
   85eef:	48 ff c3             	inc    %rbx
   85ef2:	49 89 9e d0 01 00 00 	mov    %rbx,0x1d0(%r14)
   85ef9:	4c 39 fb             	cmp    %r15,%rbx
   85efc:	75 21                	jne    85f1f <<oriole::Parser>::next_event_scoped+0xdf>
   85efe:	49 c7 86 c8 01 00 00 	movq   $0x0,0x1c8(%r14)
   85f05:	00 00 00 00 
   85f09:	4c 89 e7             	mov    %r12,%rdi
   85f0c:	4c 89 fe             	mov    %r15,%rsi
   85f0f:	e8 9c 40 fc ff       	call   49fb0 <core::ptr::drop_glue::<[core::option::Option<oriole::PendingEvent>]>>
   85f14:	49 c7 86 d0 01 00 00 	movq   $0x0,0x1d0(%r14)
   85f1b:	00 00 00 00 
   85f1f:	48 8b 9c 24 e0 01 00 	mov    0x1e0(%rsp),%rbx
   85f26:	00 
   85f27:	48 8d b4 24 e8 01 00 	lea    0x1e8(%rsp),%rsi
   85f2e:	00 
   85f2f:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   85f36:	00 
   85f37:	ba c8 00 00 00       	mov    $0xc8,%edx
   85f3c:	ff 15 0e 12 06 00    	call   *0x6120e(%rip)        # e7150 <memcpy@GLIBC_2.14>
   85f42:	48 83 fb fe          	cmp    $0xfffffffffffffffe,%rbx
   85f46:	0f 84 15 02 00 00    	je     86161 <<oriole::Parser>::next_event_scoped+0x321>
   85f4c:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   85f51:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   85f58:	00 
   85f59:	ba c8 00 00 00       	mov    $0xc8,%edx
   85f5e:	ff 15 ec 11 06 00    	call   *0x611ec(%rip)        # e7150 <memcpy@GLIBC_2.14>
   85f64:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   85f69:	83 7c 24 48 12       	cmpl   $0x12,0x48(%rsp)
   85f6e:	75 41                	jne    85fb1 <<oriole::Parser>::next_event_scoped+0x171>
   85f70:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   85f75:	83 38 ff             	cmpl   $0xffffffff,(%rax)
   85f78:	75 37                	jne    85fb1 <<oriole::Parser>::next_event_scoped+0x171>
   85f7a:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   85f7e:	75 31                	jne    85fb1 <<oriole::Parser>::next_event_scoped+0x171>
   85f80:	41 80 be f1 07 00 00 	cmpb   $0x2,0x7f1(%r14)
   85f87:	02 
   85f88:	74 27                	je     85fb1 <<oriole::Parser>::next_event_scoped+0x171>
   85f8a:	41 c6 86 f1 07 00 00 	movb   $0x1,0x7f1(%r14)
   85f91:	01 
   85f92:	41 8b 86 80 08 00 00 	mov    0x880(%r14),%eax
   85f99:	85 c0                	test   %eax,%eax
   85f9b:	0f 85 e7 07 00 00    	jne    86788 <<oriole::Parser>::next_event_scoped+0x948>
   85fa1:	49 8b 86 78 08 00 00 	mov    0x878(%r14),%rax
   85fa8:	c6 40 28 00          	movb   $0x0,0x28(%rax)
   85fac:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
   85fb1:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
   85fb5:	0f 84 44 01 00 00    	je     860ff <<oriole::Parser>::next_event_scoped+0x2bf>
   85fbb:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   85fc0:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   85fc7:	00 
   85fc8:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
   85fce:	0f 10 4c 24 20       	movups 0x20(%rsp),%xmm1
   85fd3:	0f 10 54 24 30       	movups 0x30(%rsp),%xmm2
   85fd8:	0f 29 94 24 00 02 00 	movaps %xmm2,0x200(%rsp)
   85fdf:	00 
   85fe0:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   85fe7:	00 
   85fe8:	66 0f 7f 84 24 e0 01 	movdqa %xmm0,0x1e0(%rsp)
   85fef:	00 00 
   85ff1:	48 85 c0             	test   %rax,%rax
   85ff4:	0f 84 d0 00 00 00    	je     860ca <<oriole::Parser>::next_event_scoped+0x28a>
   85ffa:	4d 8d be f0 04 00 00 	lea    0x4f0(%r14),%r15
   86001:	49 8b 8e 18 05 00 00 	mov    0x518(%r14),%rcx
   86008:	48 85 c9             	test   %rcx,%rcx
   8600b:	74 15                	je     86022 <<oriole::Parser>::next_event_scoped+0x1e2>
   8600d:	49 8b b6 10 05 00 00 	mov    0x510(%r14),%rsi
   86014:	ba 01 00 00 00       	mov    $0x1,%edx
   86019:	4c 89 ff             	mov    %r15,%rdi
   8601c:	ff 15 46 08 06 00    	call   *0x60846(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   86022:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   86027:	49 89 47 30          	mov    %rax,0x30(%r15)
   8602b:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
   86031:	0f 10 4c 24 20       	movups 0x20(%rsp),%xmm1
   86036:	0f 10 54 24 30       	movups 0x30(%rsp),%xmm2
   8603b:	41 0f 11 57 20       	movups %xmm2,0x20(%r15)
   86040:	41 0f 11 4f 10       	movups %xmm1,0x10(%r15)
   86045:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
   8604a:	e9 b0 00 00 00       	jmp    860ff <<oriole::Parser>::next_event_scoped+0x2bf>
   8604f:	49 8b 8e 78 08 00 00 	mov    0x878(%r14),%rcx
   86056:	0f b6 49 28          	movzbl 0x28(%rcx),%ecx
   8605a:	84 c9                	test   %cl,%cl
   8605c:	0f 84 40 fe ff ff    	je     85ea2 <<oriole::Parser>::next_event_scoped+0x62>
   86062:	41 80 be be 08 00 00 	cmpb   $0x1,0x8be(%r14)
   86069:	01 
   8606a:	0f 84 3b fe ff ff    	je     85eab <<oriole::Parser>::next_event_scoped+0x6b>
   86070:	49 c7 86 20 05 00 00 	movq   $0x0,0x520(%r14)
   86077:	00 00 00 00 
   8607b:	66 0f 6f 84 24 e0 01 	movdqa 0x1e0(%rsp),%xmm0
   86082:	00 00 
   86084:	0f 28 8c 24 f0 01 00 	movaps 0x1f0(%rsp),%xmm1
   8608b:	00 
   8608c:	0f 11 8c 24 c8 03 00 	movups %xmm1,0x3c8(%rsp)
   86093:	00 
   86094:	f3 0f 7f 84 24 b8 03 	movdqu %xmm0,0x3b8(%rsp)
   8609b:	00 00 
   8609d:	41 0f 11 8e a0 08 00 	movups %xmm1,0x8a0(%r14)
   860a4:	00 
   860a5:	f3 41 0f 7f 86 90 08 	movdqu %xmm0,0x890(%r14)
   860ac:	00 00 
   860ae:	48 8b 3c 24          	mov    (%rsp),%rdi
   860b2:	48 c7 07 16 00 00 00 	movq   $0x16,(%rdi)
   860b9:	48 83 c7 08          	add    $0x8,%rdi
   860bd:	48 8d b4 24 48 03 00 	lea    0x348(%rsp),%rsi
   860c4:	00 
   860c5:	e9 8d 00 00 00       	jmp    86157 <<oriole::Parser>::next_event_scoped+0x317>
   860ca:	49 c7 86 20 05 00 00 	movq   $0x0,0x520(%r14)
   860d1:	00 00 00 00 
   860d5:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   860dc:	00 
   860dd:	48 85 c9             	test   %rcx,%rcx
   860e0:	74 1d                	je     860ff <<oriole::Parser>::next_event_scoped+0x2bf>
   860e2:	31 ed                	xor    %ebp,%ebp
   860e4:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   860eb:	00 
   860ec:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   860f3:	00 
   860f4:	ba 01 00 00 00       	mov    $0x1,%edx
   860f9:	ff 15 69 07 06 00    	call   *0x60769(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   860ff:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
   86104:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   86109:	48 8d bc 24 b8 02 00 	lea    0x2b8(%rsp),%rdi
   86110:	00 
   86111:	ba 90 00 00 00       	mov    $0x90,%edx
   86116:	ff 15 34 10 06 00    	call   *0x61034(%rip)        # e7150 <memcpy@GLIBC_2.14>
   8611c:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
   86120:	74 3f                	je     86161 <<oriole::Parser>::next_event_scoped+0x321>
   86122:	f3 0f 6f 84 24 28 03 	movdqu 0x328(%rsp),%xmm0
   86129:	00 00 
   8612b:	0f 10 8c 24 38 03 00 	movups 0x338(%rsp),%xmm1
   86132:	00 
   86133:	41 0f 11 8e a0 08 00 	movups %xmm1,0x8a0(%r14)
   8613a:	00 
   8613b:	f3 41 0f 7f 86 90 08 	movdqu %xmm0,0x890(%r14)
   86142:	00 00 
   86144:	48 8b 3c 24          	mov    (%rsp),%rdi
   86148:	48 89 1f             	mov    %rbx,(%rdi)
   8614b:	48 83 c7 08          	add    $0x8,%rdi
   8614f:	48 8d b4 24 b8 02 00 	lea    0x2b8(%rsp),%rsi
   86156:	00 
   86157:	ba 90 00 00 00       	mov    $0x90,%edx
   8615c:	e9 0f 06 00 00       	jmp    86770 <<oriole::Parser>::next_event_scoped+0x930>
   86161:	4d 8d a6 10 08 00 00 	lea    0x810(%r14),%r12
   86168:	41 80 be 40 08 00 00 	cmpb   $0xff,0x840(%r14)
   8616f:	ff 
   86170:	74 38                	je     861aa <<oriole::Parser>::next_event_scoped+0x36a>
   86172:	49 8b 44 24 30       	mov    0x30(%r12),%rax
   86177:	48 8b 0c 24          	mov    (%rsp),%rcx
   8617b:	48 89 41 38          	mov    %rax,0x38(%rcx)
   8617f:	f3 41 0f 6f 04 24    	movdqu (%r12),%xmm0
   86185:	41 0f 10 4c 24 10    	movups 0x10(%r12),%xmm1
   8618b:	41 0f 10 54 24 20    	movups 0x20(%r12),%xmm2
   86191:	0f 11 51 28          	movups %xmm2,0x28(%rcx)
   86195:	0f 11 49 18          	movups %xmm1,0x18(%rcx)
   86199:	f3 0f 7f 41 08       	movdqu %xmm0,0x8(%rcx)
   8619e:	48 c7 01 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rcx)
   861a5:	e9 cc 05 00 00       	jmp    86776 <<oriole::Parser>::next_event_scoped+0x936>
   861aa:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   861b1:	00 
   861b2:	4c 89 f6             	mov    %r14,%rsi
   861b5:	e8 f6 b2 ff ff       	call   814b0 <<oriole::Parser>::next_event_inner>
   861ba:	41 0f b6 ae f8 07 00 	movzbl 0x7f8(%r14),%ebp
   861c1:	00 
   861c2:	4c 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%r13
   861c9:	00 
   861ca:	49 83 fd fe          	cmp    $0xfffffffffffffffe,%r13
   861ce:	0f 95 c0             	setne  %al
   861d1:	40 80 fd ff          	cmp    $0xff,%bpl
   861d5:	0f 94 c1             	sete   %cl
   861d8:	08 c1                	or     %al,%cl
   861da:	80 f9 01             	cmp    $0x1,%cl
   861dd:	75 0f                	jne    861ee <<oriole::Parser>::next_event_scoped+0x3ae>
   861df:	41 83 fd fe          	cmp    $0xfffffffe,%r13d
   861e3:	0f 84 17 01 00 00    	je     86300 <<oriole::Parser>::next_event_scoped+0x4c0>
   861e9:	e9 49 05 00 00       	jmp    86737 <<oriole::Parser>::next_event_scoped+0x8f7>
   861ee:	0f b6 84 24 18 01 00 	movzbl 0x118(%rsp),%eax
   861f5:	00 
   861f6:	83 f8 13             	cmp    $0x13,%eax
   861f9:	0f 87 01 01 00 00    	ja     86300 <<oriole::Parser>::next_event_scoped+0x4c0>
   861ff:	b9 14 20 08 00       	mov    $0x82014,%ecx
   86204:	0f a3 c1             	bt     %eax,%ecx
   86207:	0f 83 f3 00 00 00    	jae    86300 <<oriole::Parser>::next_event_scoped+0x4c0>
   8620d:	49 83 be 90 01 00 00 	cmpq   $0x0,0x190(%r14)
   86214:	00 
   86215:	0f 84 a9 05 00 00    	je     867c4 <<oriole::Parser>::next_event_scoped+0x984>
   8621b:	49 8b b6 80 01 00 00 	mov    0x180(%r14),%rsi
   86222:	40 80 fd 04          	cmp    $0x4,%bpl
   86226:	0f 94 c0             	sete   %al
   86229:	41 84 86 b7 08 00 00 	test   %al,0x8b7(%r14)
   86230:	74 12                	je     86244 <<oriole::Parser>::next_event_scoped+0x404>
   86232:	41 bf 16 00 00 00    	mov    $0x16,%r15d
   86238:	4c 8d 2d 18 c6 f8 ff 	lea    -0x739e8(%rip),%r13        # 12857 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x5ecb>
   8623f:	40 b5 13             	mov    $0x13,%bpl
   86242:	eb 3e                	jmp    86282 <<oriole::Parser>::next_event_scoped+0x442>
   86244:	4d 8b ae 00 08 00 00 	mov    0x800(%r14),%r13
   8624b:	4d 8b be 08 08 00 00 	mov    0x808(%r14),%r15
   86252:	89 e8                	mov    %ebp,%eax
   86254:	04 ef                	add    $0xef,%al
   86256:	3c 02                	cmp    $0x2,%al
   86258:	73 28                	jae    86282 <<oriole::Parser>::next_event_scoped+0x442>
   8625a:	49 83 3e 01          	cmpq   $0x1,(%r14)
   8625e:	0f 85 2a 04 00 00    	jne    8668e <<oriole::Parser>::next_event_scoped+0x84e>
   86264:	f3 41 0f 6f 46 08    	movdqu 0x8(%r14),%xmm0
   8626a:	41 0f 10 4e 18       	movups 0x18(%r14),%xmm1
   8626f:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   86276:	00 
   86277:	66 0f 7f 84 24 e0 01 	movdqa %xmm0,0x1e0(%rsp)
   8627e:	00 00 
   86280:	eb 0d                	jmp    8628f <<oriole::Parser>::next_event_scoped+0x44f>
   86282:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   86289:	00 
   8628a:	e8 a1 89 fe ff       	call   6ec30 <<oriole::encoding::Source>::end_position>
   8628f:	0f 28 84 24 e0 01 00 	movaps 0x1e0(%rsp),%xmm0
   86296:	00 
   86297:	0f 28 8c 24 f0 01 00 	movaps 0x1f0(%rsp),%xmm1
   8629e:	00 
   8629f:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   862a4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   862a9:	83 bc 24 e0 00 00 00 	cmpl   $0xfffffffd,0xe0(%rsp)
   862b0:	fd 
   862b1:	77 0d                	ja     862c0 <<oriole::Parser>::next_event_scoped+0x480>
   862b3:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   862ba:	00 
   862bb:	e8 b0 2a fc ff       	call   48d70 <core::ptr::drop_glue::<oriole::EventKind>>
   862c0:	48 c7 84 24 e0 00 00 	movq   $0xfffffffffffffffe,0xe0(%rsp)
   862c7:	00 fe ff ff ff 
   862cc:	4c 89 ac 24 e8 00 00 	mov    %r13,0xe8(%rsp)
   862d3:	00 
   862d4:	4c 89 bc 24 f0 00 00 	mov    %r15,0xf0(%rsp)
   862db:	00 
   862dc:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
   862e2:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
   862e7:	f3 0f 7f 84 24 f8 00 	movdqu %xmm0,0xf8(%rsp)
   862ee:	00 00 
   862f0:	0f 11 8c 24 08 01 00 	movups %xmm1,0x108(%rsp)
   862f7:	00 
   862f8:	40 88 ac 24 18 01 00 	mov    %bpl,0x118(%rsp)
   862ff:	00 
   86300:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
   86307:	00 
   86308:	49 89 44 24 30       	mov    %rax,0x30(%r12)
   8630d:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   86314:	00 
   86315:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
   8631c:	00 
   8631d:	f3 0f 6f 84 24 f8 00 	movdqu 0xf8(%rsp),%xmm0
   86324:	00 00 
   86326:	0f 10 8c 24 08 01 00 	movups 0x108(%rsp),%xmm1
   8632d:	00 
   8632e:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
   86334:	f3 41 0f 7f 44 24 10 	movdqu %xmm0,0x10(%r12)
   8633b:	49 89 04 24          	mov    %rax,(%r12)
   8633f:	49 89 4c 24 08       	mov    %rcx,0x8(%r12)
   86344:	0f b6 84 24 18 01 00 	movzbl 0x118(%rsp),%eax
   8634b:	00 
   8634c:	84 c0                	test   %al,%al
   8634e:	74 0e                	je     8635e <<oriole::Parser>::next_event_scoped+0x51e>
   86350:	41 80 be f8 07 00 00 	cmpb   $0x11,0x7f8(%r14)
   86357:	11 
   86358:	0f 84 fe 00 00 00    	je     8645c <<oriole::Parser>::next_event_scoped+0x61c>
   8635e:	4d 8b ae c8 04 00 00 	mov    0x4c8(%r14),%r13
   86365:	4d 85 ed             	test   %r13,%r13
   86368:	0f 84 e6 00 00 00    	je     86454 <<oriole::Parser>::next_event_scoped+0x614>
   8636e:	49 8b 9e b0 04 00 00 	mov    0x4b0(%r14),%rbx
   86375:	66 0f 6f 03          	movdqa (%rbx),%xmm0
   86379:	48 8d 6b 10          	lea    0x10(%rbx),%rbp
   8637d:	66 44 0f d7 f8       	pmovmskb %xmm0,%r15d
   86382:	41 f7 d7             	not    %r15d
   86385:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   8638a:	eb 13                	jmp    8639f <<oriole::Parser>::next_event_scoped+0x55f>
   8638c:	0f 1f 40 00          	nopl   0x0(%rax)
   86390:	41 8d 47 ff          	lea    -0x1(%r15),%eax
   86394:	44 21 f8             	and    %r15d,%eax
   86397:	41 89 c7             	mov    %eax,%r15d
   8639a:	49 ff cd             	dec    %r13
   8639d:	74 5d                	je     863fc <<oriole::Parser>::next_event_scoped+0x5bc>
   8639f:	66 45 85 ff          	test   %r15w,%r15w
   863a3:	75 29                	jne    863ce <<oriole::Parser>::next_event_scoped+0x58e>
   863a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   863ac:	00 00 00 00 
   863b0:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   863b5:	48 81 c3 80 fa ff ff 	add    $0xfffffffffffffa80,%rbx
   863bc:	48 83 c5 10          	add    $0x10,%rbp
   863c0:	66 44 0f d7 f8       	pmovmskb %xmm0,%r15d
   863c5:	41 81 f7 ff ff 00 00 	xor    $0xffff,%r15d
   863cc:	74 e2                	je     863b0 <<oriole::Parser>::next_event_scoped+0x570>
   863ce:	f3 41 0f bc c7       	tzcnt  %r15d,%eax
   863d3:	48 f7 d8             	neg    %rax
   863d6:	48 6b f8 58          	imul   $0x58,%rax,%rdi
   863da:	48 8b 4c 3b d0       	mov    -0x30(%rbx,%rdi,1),%rcx
   863df:	48 85 c9             	test   %rcx,%rcx
   863e2:	74 ac                	je     86390 <<oriole::Parser>::next_event_scoped+0x550>
   863e4:	48 01 df             	add    %rbx,%rdi
   863e7:	48 8b 77 c8          	mov    -0x38(%rdi),%rsi
   863eb:	48 83 c7 a8          	add    $0xffffffffffffffa8,%rdi
   863ef:	ba 01 00 00 00       	mov    $0x1,%edx
   863f4:	ff 15 6e 04 06 00    	call   *0x6046e(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   863fa:	eb 94                	jmp    86390 <<oriole::Parser>::next_event_scoped+0x550>
   863fc:	49 8b 9e b8 04 00 00 	mov    0x4b8(%r14),%rbx
   86403:	48 85 db             	test   %rbx,%rbx
   86406:	74 30                	je     86438 <<oriole::Parser>::next_event_scoped+0x5f8>
   86408:	48 8d 53 11          	lea    0x11(%rbx),%rdx
   8640c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   86411:	be ff 00 00 00       	mov    $0xff,%esi
   86416:	ff 15 1c 0d 06 00    	call   *0x60d1c(%rip)        # e7138 <memset@GLIBC_2.2.5>
   8641c:	48 8d 43 01          	lea    0x1(%rbx),%rax
   86420:	48 89 c1             	mov    %rax,%rcx
   86423:	48 c1 e9 03          	shr    $0x3,%rcx
   86427:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
   8642b:	48 29 c8             	sub    %rcx,%rax
   8642e:	48 83 fb 08          	cmp    $0x8,%rbx
   86432:	48 0f 42 c3          	cmovb  %rbx,%rax
   86436:	eb 02                	jmp    8643a <<oriole::Parser>::next_event_scoped+0x5fa>
   86438:	31 c0                	xor    %eax,%eax
   8643a:	49 c7 86 c8 04 00 00 	movq   $0x0,0x4c8(%r14)
   86441:	00 00 00 00 
   86445:	49 89 86 c0 04 00 00 	mov    %rax,0x4c0(%r14)
   8644c:	0f b6 84 24 18 01 00 	movzbl 0x118(%rsp),%eax
   86453:	00 
   86454:	84 c0                	test   %al,%al
   86456:	0f 84 04 02 00 00    	je     86660 <<oriole::Parser>::next_event_scoped+0x820>
   8645c:	4c 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%r15
   86463:	00 
   86464:	48 8d bc 24 a8 01 00 	lea    0x1a8(%rsp),%rdi
   8646b:	00 
   8646c:	4c 89 f6             	mov    %r14,%rsi
   8646f:	4c 89 fa             	mov    %r15,%rdx
   86472:	e8 39 c3 fc ff       	call   527b0 <<oriole::Parser>::next_event_scoped::{closure#2}>
   86477:	80 bc 24 d8 01 00 00 	cmpb   $0xff,0x1d8(%rsp)
   8647e:	ff 
   8647f:	0f 84 be 00 00 00    	je     86543 <<oriole::Parser>::next_event_scoped+0x703>
   86485:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
   8648c:	00 
   8648d:	49 89 44 24 30       	mov    %rax,0x30(%r12)
   86492:	f3 0f 6f 84 24 a8 01 	movdqu 0x1a8(%rsp),%xmm0
   86499:	00 00 
   8649b:	0f 10 8c 24 b8 01 00 	movups 0x1b8(%rsp),%xmm1
   864a2:	00 
   864a3:	0f 10 94 24 c8 01 00 	movups 0x1c8(%rsp),%xmm2
   864aa:	00 
   864ab:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
   864b1:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
   864b7:	f3 41 0f 7f 04 24    	movdqu %xmm0,(%r12)
   864bd:	49 8b be b8 01 00 00 	mov    0x1b8(%r14),%rdi
   864c4:	49 8b b6 c8 01 00 00 	mov    0x1c8(%r14),%rsi
   864cb:	49 c7 86 c8 01 00 00 	movq   $0x0,0x1c8(%r14)
   864d2:	00 00 00 00 
   864d6:	e8 d5 3a fc ff       	call   49fb0 <core::ptr::drop_glue::<[core::option::Option<oriole::PendingEvent>]>>
   864db:	49 c7 86 d0 01 00 00 	movq   $0x0,0x1d0(%r14)
   864e2:	00 00 00 00 
   864e6:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
   864ed:	00 
   864ee:	48 8b 0c 24          	mov    (%rsp),%rcx
   864f2:	48 89 41 38          	mov    %rax,0x38(%rcx)
   864f6:	f3 0f 6f 84 24 a8 01 	movdqu 0x1a8(%rsp),%xmm0
   864fd:	00 00 
   864ff:	0f 10 8c 24 b8 01 00 	movups 0x1b8(%rsp),%xmm1
   86506:	00 
   86507:	0f 10 94 24 c8 01 00 	movups 0x1c8(%rsp),%xmm2
   8650e:	00 
   8650f:	0f 11 51 28          	movups %xmm2,0x28(%rcx)
   86513:	0f 11 49 18          	movups %xmm1,0x18(%rcx)
   86517:	f3 0f 7f 41 08       	movdqu %xmm0,0x8(%rcx)
   8651c:	48 c7 01 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rcx)
   86523:	83 bc 24 e0 00 00 00 	cmpl   $0xfffffffd,0xe0(%rsp)
   8652a:	fd 
   8652b:	0f 87 45 02 00 00    	ja     86776 <<oriole::Parser>::next_event_scoped+0x936>
   86531:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   86538:	00 
   86539:	e8 32 28 fc ff       	call   48d70 <core::ptr::drop_glue::<oriole::EventKind>>
   8653e:	e9 33 02 00 00       	jmp    86776 <<oriole::Parser>::next_event_scoped+0x936>
   86543:	49 8d b6 98 01 00 00 	lea    0x198(%r14),%rsi
   8654a:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   86551:	00 
   86552:	e8 69 12 fd ff       	call   577c0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::pop_front>
   86557:	83 bc 24 e0 01 00 00 	cmpl   $0xfffffffe,0x1e0(%rsp)
   8655e:	fe 
   8655f:	0f 84 ca 01 00 00    	je     8672f <<oriole::Parser>::next_event_scoped+0x8ef>
   86565:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   8656a:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
   86571:	00 
   86572:	ba d0 00 00 00       	mov    $0xd0,%edx
   86577:	ff 15 d3 0b 06 00    	call   *0x60bd3(%rip)        # e7150 <memcpy@GLIBC_2.14>
   8657d:	83 7c 24 48 12       	cmpl   $0x12,0x48(%rsp)
   86582:	75 3c                	jne    865c0 <<oriole::Parser>::next_event_scoped+0x780>
   86584:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   86589:	83 38 ff             	cmpl   $0xffffffff,(%rax)
   8658c:	75 32                	jne    865c0 <<oriole::Parser>::next_event_scoped+0x780>
   8658e:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   86592:	75 2c                	jne    865c0 <<oriole::Parser>::next_event_scoped+0x780>
   86594:	41 80 be f1 07 00 00 	cmpb   $0x2,0x7f1(%r14)
   8659b:	02 
   8659c:	74 22                	je     865c0 <<oriole::Parser>::next_event_scoped+0x780>
   8659e:	41 c6 86 f1 07 00 00 	movb   $0x1,0x7f1(%r14)
   865a5:	01 
   865a6:	41 8b 86 80 08 00 00 	mov    0x880(%r14),%eax
   865ad:	85 c0                	test   %eax,%eax
   865af:	0f 85 f1 01 00 00    	jne    867a6 <<oriole::Parser>::next_event_scoped+0x966>
   865b5:	49 8b 86 78 08 00 00 	mov    0x878(%r14),%rax
   865bc:	c6 40 28 00          	movb   $0x0,0x28(%rax)
   865c0:	83 7c 24 10 ff       	cmpl   $0xffffffff,0x10(%rsp)
   865c5:	0f 84 0a 01 00 00    	je     866d5 <<oriole::Parser>::next_event_scoped+0x895>
   865cb:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   865d0:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   865d7:	00 
   865d8:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
   865de:	0f 10 4c 24 20       	movups 0x20(%rsp),%xmm1
   865e3:	0f 10 54 24 30       	movups 0x30(%rsp),%xmm2
   865e8:	0f 29 94 24 00 02 00 	movaps %xmm2,0x200(%rsp)
   865ef:	00 
   865f0:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   865f7:	00 
   865f8:	66 0f 7f 84 24 e0 01 	movdqa %xmm0,0x1e0(%rsp)
   865ff:	00 00 
   86601:	48 85 c0             	test   %rax,%rax
   86604:	0f 84 96 00 00 00    	je     866a0 <<oriole::Parser>::next_event_scoped+0x860>
   8660a:	4d 8d a6 f0 04 00 00 	lea    0x4f0(%r14),%r12
   86611:	49 8b 8e 18 05 00 00 	mov    0x518(%r14),%rcx
   86618:	48 85 c9             	test   %rcx,%rcx
   8661b:	74 15                	je     86632 <<oriole::Parser>::next_event_scoped+0x7f2>
   8661d:	49 8b b6 10 05 00 00 	mov    0x510(%r14),%rsi
   86624:	ba 01 00 00 00       	mov    $0x1,%edx
   86629:	4c 89 e7             	mov    %r12,%rdi
   8662c:	ff 15 36 02 06 00    	call   *0x60236(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   86632:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   86637:	49 89 44 24 30       	mov    %rax,0x30(%r12)
   8663c:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
   86642:	0f 10 4c 24 20       	movups 0x20(%rsp),%xmm1
   86647:	0f 10 54 24 30       	movups 0x30(%rsp),%xmm2
   8664c:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
   86652:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
   86658:	f3 41 0f 7f 04 24    	movdqu %xmm0,(%r12)
   8665e:	eb 75                	jmp    866d5 <<oriole::Parser>::next_event_scoped+0x895>
   86660:	49 8b be b8 01 00 00 	mov    0x1b8(%r14),%rdi
   86667:	49 8b b6 c8 01 00 00 	mov    0x1c8(%r14),%rsi
   8666e:	49 c7 86 c8 01 00 00 	movq   $0x0,0x1c8(%r14)
   86675:	00 00 00 00 
   86679:	e8 32 39 fc ff       	call   49fb0 <core::ptr::drop_glue::<[core::option::Option<oriole::PendingEvent>]>>
   8667e:	49 c7 86 d0 01 00 00 	movq   $0x0,0x1d0(%r14)
   86685:	00 00 00 00 
   86689:	e9 d1 00 00 00       	jmp    8675f <<oriole::Parser>::next_event_scoped+0x91f>
   8668e:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   86695:	00 
   86696:	e8 a5 c0 fc ff       	call   52740 <<oriole::Parser>::next_event_scoped::{closure#0}>
   8669b:	e9 ef fb ff ff       	jmp    8628f <<oriole::Parser>::next_event_scoped+0x44f>
   866a0:	49 c7 86 20 05 00 00 	movq   $0x0,0x520(%r14)
   866a7:	00 00 00 00 
   866ab:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   866b2:	00 
   866b3:	48 85 c9             	test   %rcx,%rcx
   866b6:	74 1d                	je     866d5 <<oriole::Parser>::next_event_scoped+0x895>
   866b8:	31 ed                	xor    %ebp,%ebp
   866ba:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   866c1:	00 
   866c2:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   866c9:	00 
   866ca:	ba 01 00 00 00       	mov    $0x1,%edx
   866cf:	ff 15 93 01 06 00    	call   *0x60193(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   866d5:	4c 8b 6c 24 48       	mov    0x48(%rsp),%r13
   866da:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   866df:	48 8d bc 24 d8 03 00 	lea    0x3d8(%rsp),%rdi
   866e6:	00 
   866e7:	ba 90 00 00 00       	mov    $0x90,%edx
   866ec:	ff 15 5e 0a 06 00    	call   *0x60a5e(%rip)        # e7150 <memcpy@GLIBC_2.14>
   866f2:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
   866f6:	74 37                	je     8672f <<oriole::Parser>::next_event_scoped+0x8ef>
   866f8:	83 bc 24 e0 00 00 00 	cmpl   $0xfffffffd,0xe0(%rsp)
   866ff:	fd 
   86700:	77 0d                	ja     8670f <<oriole::Parser>::next_event_scoped+0x8cf>
   86702:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   86709:	00 
   8670a:	e8 61 26 fc ff       	call   48d70 <core::ptr::drop_glue::<oriole::EventKind>>
   8670f:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
   86716:	00 
   86717:	48 8d b4 24 d8 03 00 	lea    0x3d8(%rsp),%rsi
   8671e:	00 
   8671f:	ba 90 00 00 00       	mov    $0x90,%edx
   86724:	4c 89 ff             	mov    %r15,%rdi
   86727:	ff 15 23 0a 06 00    	call   *0x60a23(%rip)        # e7150 <memcpy@GLIBC_2.14>
   8672d:	eb 08                	jmp    86737 <<oriole::Parser>::next_event_scoped+0x8f7>
   8672f:	4c 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%r13
   86736:	00 
   86737:	49 83 fd fd          	cmp    $0xfffffffffffffffd,%r13
   8673b:	77 22                	ja     8675f <<oriole::Parser>::next_event_scoped+0x91f>
   8673d:	f3 0f 6f 84 24 58 01 	movdqu 0x158(%rsp),%xmm0
   86744:	00 00 
   86746:	0f 10 8c 24 68 01 00 	movups 0x168(%rsp),%xmm1
   8674d:	00 
   8674e:	41 0f 11 8e a0 08 00 	movups %xmm1,0x8a0(%r14)
   86755:	00 
   86756:	f3 41 0f 7f 86 90 08 	movdqu %xmm0,0x890(%r14)
   8675d:	00 00 
   8675f:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   86766:	00 
   86767:	ba 98 00 00 00       	mov    $0x98,%edx
   8676c:	48 8b 3c 24          	mov    (%rsp),%rdi
   86770:	ff 15 da 09 06 00    	call   *0x609da(%rip)        # e7150 <memcpy@GLIBC_2.14>
   86776:	48 81 c4 68 04 00 00 	add    $0x468,%rsp
   8677d:	5b                   	pop    %rbx
   8677e:	41 5c                	pop    %r12
   86780:	41 5d                	pop    %r13
   86782:	41 5e                	pop    %r14
   86784:	41 5f                	pop    %r15
   86786:	5d                   	pop    %rbp
   86787:	c3                   	ret
   86788:	40 b5 01             	mov    $0x1,%bpl
   8678b:	48 8d 3d 38 c5 f8 ff 	lea    -0x73ac8(%rip),%rdi        # 12cca <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x633e>
   86792:	48 8d 15 ff da 05 00 	lea    0x5daff(%rip),%rdx        # e4298 <oriole_expat::FEATURES+0x16f0>
   86799:	be 17 00 00 00       	mov    $0x17,%esi
   8679e:	ff 15 ec 06 06 00    	call   *0x606ec(%rip)        # e6e90 <_GLOBAL_OFFSET_TABLE_+0x758>
   867a4:	eb 2f                	jmp    867d5 <<oriole::Parser>::next_event_scoped+0x995>
   867a6:	40 b5 01             	mov    $0x1,%bpl
   867a9:	48 8d 3d 1a c5 f8 ff 	lea    -0x73ae6(%rip),%rdi        # 12cca <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x633e>
   867b0:	48 8d 15 e1 da 05 00 	lea    0x5dae1(%rip),%rdx        # e4298 <oriole_expat::FEATURES+0x16f0>
   867b7:	be 17 00 00 00       	mov    $0x17,%esi
   867bc:	ff 15 ce 06 06 00    	call   *0x606ce(%rip)        # e6e90 <_GLOBAL_OFFSET_TABLE_+0x758>
   867c2:	eb 11                	jmp    867d5 <<oriole::Parser>::next_event_scoped+0x995>
   867c4:	48 8d 15 35 d9 05 00 	lea    0x5d935(%rip),%rdx        # e4100 <oriole_expat::FEATURES+0x1558>
   867cb:	31 ff                	xor    %edi,%edi
   867cd:	31 f6                	xor    %esi,%esi
   867cf:	ff 15 0b 06 06 00    	call   *0x6060b(%rip)        # e6de0 <_GLOBAL_OFFSET_TABLE_+0x6a8>
   867d5:	0f 0b                	ud2
   867d7:	48 89 c3             	mov    %rax,%rbx
   867da:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   867df:	49 89 44 24 30       	mov    %rax,0x30(%r12)
   867e4:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
   867ea:	0f 10 4c 24 20       	movups 0x20(%rsp),%xmm1
   867ef:	0f 10 54 24 30       	movups 0x30(%rsp),%xmm2
   867f4:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
   867fa:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
   86800:	f3 41 0f 7f 04 24    	movdqu %xmm0,(%r12)
   86806:	31 ed                	xor    %ebp,%ebp
   86808:	e9 1b 01 00 00       	jmp    86928 <<oriole::Parser>::next_event_scoped+0xae8>
   8680d:	48 89 c3             	mov    %rax,%rbx
   86810:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
   86817:	00 
   86818:	48 8d b4 24 d8 03 00 	lea    0x3d8(%rsp),%rsi
   8681f:	00 
   86820:	ba 90 00 00 00       	mov    $0x90,%edx
   86825:	4c 89 ff             	mov    %r15,%rdi
   86828:	ff 15 22 09 06 00    	call   *0x60922(%rip)        # e7150 <memcpy@GLIBC_2.14>
   8682e:	e9 37 01 00 00       	jmp    8696a <<oriole::Parser>::next_event_scoped+0xb2a>
   86833:	48 89 c3             	mov    %rax,%rbx
   86836:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   8683b:	49 89 47 30          	mov    %rax,0x30(%r15)
   8683f:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
   86845:	0f 10 4c 24 20       	movups 0x20(%rsp),%xmm1
   8684a:	0f 10 54 24 30       	movups 0x30(%rsp),%xmm2
   8684f:	41 0f 11 57 20       	movups %xmm2,0x20(%r15)
   86854:	41 0f 11 4f 10       	movups %xmm1,0x10(%r15)
   86859:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
   8685e:	31 ed                	xor    %ebp,%ebp
   86860:	e9 29 01 00 00       	jmp    8698e <<oriole::Parser>::next_event_scoped+0xb4e>
   86865:	48 89 c3             	mov    %rax,%rbx
   86868:	48 c7 84 24 e0 00 00 	movq   $0xfffffffffffffffe,0xe0(%rsp)
   8686f:	00 fe ff ff ff 
   86874:	4c 89 ac 24 e8 00 00 	mov    %r13,0xe8(%rsp)
   8687b:	00 
   8687c:	4c 89 bc 24 f0 00 00 	mov    %r15,0xf0(%rsp)
   86883:	00 
   86884:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
   8688a:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
   8688f:	f3 0f 7f 84 24 f8 00 	movdqu %xmm0,0xf8(%rsp)
   86896:	00 00 
   86898:	0f 11 8c 24 08 01 00 	movups %xmm1,0x108(%rsp)
   8689f:	00 
   868a0:	40 88 ac 24 18 01 00 	mov    %bpl,0x118(%rsp)
   868a7:	00 
   868a8:	e9 b5 00 00 00       	jmp    86962 <<oriole::Parser>::next_event_scoped+0xb22>
   868ad:	48 89 c3             	mov    %rax,%rbx
   868b0:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   868b7:	00 
   868b8:	e8 33 f5 fb ff       	call   45df0 <core::ptr::drop_glue::<core::option::Option<oriole::PendingEvent>>>
   868bd:	e9 06 01 00 00       	jmp    869c8 <<oriole::Parser>::next_event_scoped+0xb88>
   868c2:	ff 15 e8 05 06 00    	call   *0x605e8(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
   868c8:	48 89 c3             	mov    %rax,%rbx
   868cb:	e9 92 00 00 00       	jmp    86962 <<oriole::Parser>::next_event_scoped+0xb22>
   868d0:	48 89 c3             	mov    %rax,%rbx
   868d3:	4d 8b be b8 04 00 00 	mov    0x4b8(%r14),%r15
   868da:	4d 85 ff             	test   %r15,%r15
   868dd:	75 04                	jne    868e3 <<oriole::Parser>::next_event_scoped+0xaa3>
   868df:	31 c0                	xor    %eax,%eax
   868e1:	eb 2e                	jmp    86911 <<oriole::Parser>::next_event_scoped+0xad1>
   868e3:	49 8d 57 11          	lea    0x11(%r15),%rdx
   868e7:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   868ec:	be ff 00 00 00       	mov    $0xff,%esi
   868f1:	ff 15 41 08 06 00    	call   *0x60841(%rip)        # e7138 <memset@GLIBC_2.2.5>
   868f7:	49 8d 47 01          	lea    0x1(%r15),%rax
   868fb:	48 89 c1             	mov    %rax,%rcx
   868fe:	48 c1 e9 03          	shr    $0x3,%rcx
   86902:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
   86906:	48 29 c8             	sub    %rcx,%rax
   86909:	49 83 ff 08          	cmp    $0x8,%r15
   8690d:	49 0f 42 c7          	cmovb  %r15,%rax
   86911:	49 c7 86 c8 04 00 00 	movq   $0x0,0x4c8(%r14)
   86918:	00 00 00 00 
   8691c:	49 89 86 c0 04 00 00 	mov    %rax,0x4c0(%r14)
   86923:	eb 3d                	jmp    86962 <<oriole::Parser>::next_event_scoped+0xb22>
   86925:	48 89 c3             	mov    %rax,%rbx
   86928:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   8692d:	e8 3e 24 fc ff       	call   48d70 <core::ptr::drop_glue::<oriole::EventKind>>
   86932:	83 7c 24 10 ff       	cmpl   $0xffffffff,0x10(%rsp)
   86937:	0f 94 c0             	sete   %al
   8693a:	40 80 f5 01          	xor    $0x1,%bpl
   8693e:	40 08 c5             	or     %al,%bpl
   86941:	75 1f                	jne    86962 <<oriole::Parser>::next_event_scoped+0xb22>
   86943:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   86948:	48 85 c9             	test   %rcx,%rcx
   8694b:	74 15                	je     86962 <<oriole::Parser>::next_event_scoped+0xb22>
   8694d:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   86952:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   86957:	ba 01 00 00 00       	mov    $0x1,%edx
   8695c:	ff 15 06 ff 05 00    	call   *0x5ff06(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   86962:	4c 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%r13
   86969:	00 
   8696a:	49 83 fd fd          	cmp    $0xfffffffffffffffd,%r13
   8696e:	77 58                	ja     869c8 <<oriole::Parser>::next_event_scoped+0xb88>
   86970:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   86977:	00 
   86978:	e8 f3 23 fc ff       	call   48d70 <core::ptr::drop_glue::<oriole::EventKind>>
   8697d:	eb 49                	jmp    869c8 <<oriole::Parser>::next_event_scoped+0xb88>
   8697f:	ff 15 2b 05 06 00    	call   *0x6052b(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
   86985:	ff 15 25 05 06 00    	call   *0x60525(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
   8698b:	48 89 c3             	mov    %rax,%rbx
   8698e:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   86993:	e8 d8 23 fc ff       	call   48d70 <core::ptr::drop_glue::<oriole::EventKind>>
   86998:	83 7c 24 10 ff       	cmpl   $0xffffffff,0x10(%rsp)
   8699d:	0f 94 c0             	sete   %al
   869a0:	40 80 f5 01          	xor    $0x1,%bpl
   869a4:	40 08 c5             	or     %al,%bpl
   869a7:	75 1f                	jne    869c8 <<oriole::Parser>::next_event_scoped+0xb88>
   869a9:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   869ae:	48 85 c9             	test   %rcx,%rcx
   869b1:	74 15                	je     869c8 <<oriole::Parser>::next_event_scoped+0xb88>
   869b3:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   869b8:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   869bd:	ba 01 00 00 00       	mov    $0x1,%edx
   869c2:	ff 15 a0 fe 05 00    	call   *0x5fea0(%rip)        # e6868 <_GLOBAL_OFFSET_TABLE_+0x130>
   869c8:	48 89 df             	mov    %rbx,%rdi
   869cb:	e8 00 61 fa ff       	call   2cad0 <_Unwind_Resume@plt>
   869d0:	ff 15 da 04 06 00    	call   *0x604da(%rip)        # e6eb0 <_GLOBAL_OFFSET_TABLE_+0x778>
