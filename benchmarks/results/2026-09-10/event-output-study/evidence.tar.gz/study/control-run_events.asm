
/tmp/oriole-event-output/control.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000032490 <oriole_expat::run_events>:
   32490:	55                   	push   %rbp
   32491:	41 57                	push   %r15
   32493:	41 56                	push   %r14
   32495:	41 55                	push   %r13
   32497:	41 54                	push   %r12
   32499:	53                   	push   %rbx
   3249a:	48 81 ec 98 01 00 00 	sub    $0x198,%rsp
   324a1:	49 89 fe             	mov    %rdi,%r14
   324a4:	e8 d7 0b 00 00       	call   33080 <oriole_expat::drain_default_fragments>
   324a9:	31 c0                	xor    %eax,%eax
   324ab:	41 80 be 0a 0a 00 00 	cmpb   $0x0,0xa0a(%r14)
   324b2:	00 
   324b3:	0f 85 d7 04 00 00    	jne    32990 <oriole_expat::run_events+0x500>
   324b9:	49 8d 76 30          	lea    0x30(%r14),%rsi
   324bd:	4c 8d a4 24 08 01 00 	lea    0x108(%rsp),%r12
   324c4:	00 
   324c5:	49 8d 86 20 0a 00 00 	lea    0xa20(%r14),%rax
   324cc:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   324d1:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
   324d8:	00 
   324d9:	48 8d 2d b0 a8 05 00 	lea    0x5a8b0(%rip),%rbp        # 8cd90 <<oriole::Parser>::resolve_encoding_conversion>
   324e0:	4c 8d 3d 99 6f fd ff 	lea    -0x29067(%rip),%r15        # 9480 <std::thread::current::id::ID+0x9410>
   324e7:	e9 70 01 00 00       	jmp    3265c <oriole_expat::run_events+0x1cc>
   324ec:	0f 1f 40 00          	nopl   0x0(%rax)
   324f0:	49 8b 8c 24 88 00 00 	mov    0x88(%r12),%rcx
   324f7:	00 
   324f8:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   324fd:	41 0f 10 44 24 78    	movups 0x78(%r12),%xmm0
   32503:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   32508:	41 0f 10 44 24 38    	movups 0x38(%r12),%xmm0
   3250e:	41 0f 10 4c 24 48    	movups 0x48(%r12),%xmm1
   32514:	41 0f 10 54 24 58    	movups 0x58(%r12),%xmm2
   3251a:	41 0f 10 5c 24 68    	movups 0x68(%r12),%xmm3
   32520:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
   32525:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
   3252a:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   3252f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   32534:	83 f8 ff             	cmp    $0xffffffff,%eax
   32537:	0f 84 b4 01 00 00    	je     326f1 <oriole_expat::run_events+0x261>
   3253d:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   32542:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
   32549:	00 
   3254a:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
   3254f:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   32556:	00 
   32557:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   3255c:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
   32561:	0f 28 54 24 30       	movaps 0x30(%rsp),%xmm2
   32566:	0f 28 5c 24 40       	movaps 0x40(%rsp),%xmm3
   3256b:	0f 29 9c 24 d0 00 00 	movaps %xmm3,0xd0(%rsp)
   32572:	00 
   32573:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
   3257a:	00 
   3257b:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   32582:	00 
   32583:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   3258a:	00 
   3258b:	49 8b 96 a8 06 00 00 	mov    0x6a8(%r14),%rdx
   32592:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   32597:	0f 28 8c 24 80 00 00 	movaps 0x80(%rsp),%xmm1
   3259e:	00 
   3259f:	0f 28 94 24 90 00 00 	movaps 0x90(%rsp),%xmm2
   325a6:	00 
   325a7:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
   325ad:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
   325b3:	41 0f 11 04 24       	movups %xmm0,(%r12)
   325b8:	8b 0c 24             	mov    (%rsp),%ecx
   325bb:	8b 74 24 03          	mov    0x3(%rsp),%esi
   325bf:	41 89 74 24 34       	mov    %esi,0x34(%r12)
   325c4:	41 89 4c 24 31       	mov    %ecx,0x31(%r12)
   325c9:	48 8d 8c 24 d8 00 00 	lea    0xd8(%rsp),%rcx
   325d0:	00 
   325d1:	0f 10 01             	movups (%rcx),%xmm0
   325d4:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   325d8:	49 8d 8e 20 0a 00 00 	lea    0xa20(%r14),%rcx
   325df:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
   325e3:	0f 11 01             	movups %xmm0,(%rcx)
   325e6:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   325ed:	00 
   325ee:	88 9c 24 38 01 00 00 	mov    %bl,0x138(%rsp)
   325f5:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   325fc:	00 
   325fd:	49 89 44 24 68       	mov    %rax,0x68(%r12)
   32602:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
   32609:	00 
   3260a:	0f 28 8c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm1
   32611:	00 
   32612:	0f 28 94 24 c0 00 00 	movaps 0xc0(%rsp),%xmm2
   32619:	00 
   3261a:	41 0f 11 54 24 58    	movups %xmm2,0x58(%r12)
   32620:	41 0f 11 4c 24 48    	movups %xmm1,0x48(%r12)
   32626:	41 0f 11 44 24 38    	movups %xmm0,0x38(%r12)
   3262c:	4c 89 f7             	mov    %r14,%rdi
   3262f:	4c 89 ee             	mov    %r13,%rsi
   32632:	e8 59 17 00 00       	call   33d90 <oriole_expat::dispatch>
   32637:	3c ff                	cmp    $0xff,%al
   32639:	0f 85 e0 01 00 00    	jne    3281f <oriole_expat::run_events+0x38f>
   3263f:	4c 89 f7             	mov    %r14,%rdi
   32642:	e8 39 0a 00 00       	call   33080 <oriole_expat::drain_default_fragments>
   32647:	41 80 be 0a 0a 00 00 	cmpb   $0x0,0xa0a(%r14)
   3264e:	00 
   3264f:	49 8d 76 30          	lea    0x30(%r14),%rsi
   32653:	4c 89 ef             	mov    %r13,%rdi
   32656:	0f 85 32 03 00 00    	jne    3298e <oriole_expat::run_events+0x4fe>
   3265c:	41 8b 86 14 0a 00 00 	mov    0xa14(%r14),%eax
   32663:	85 c0                	test   %eax,%eax
   32665:	0f 85 3b 01 00 00    	jne    327a6 <oriole_expat::run_events+0x316>
   3266b:	41 83 be 0c 0a 00 00 	cmpl   $0x3,0xa0c(%r14)
   32672:	03 
   32673:	0f 84 39 01 00 00    	je     327b2 <oriole_expat::run_events+0x322>
   32679:	49 89 fd             	mov    %rdi,%r13
   3267c:	ff 15 56 41 0b 00    	call   *0xb4156(%rip)        # e67d8 <_GLOBAL_OFFSET_TABLE_+0xa0>
   32682:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
   32689:	00 
   3268a:	41 0f 10 04 24       	movups (%r12),%xmm0
   3268f:	41 0f 10 4c 24 10    	movups 0x10(%r12),%xmm1
   32695:	41 0f 10 54 24 20    	movups 0x20(%r12),%xmm2
   3269b:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   326a0:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   326a7:	00 
   326a8:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   326af:	00 
   326b0:	0f b6 9c 24 38 01 00 	movzbl 0x138(%rsp),%ebx
   326b7:	00 
   326b8:	41 8b 4c 24 31       	mov    0x31(%r12),%ecx
   326bd:	41 8b 54 24 34       	mov    0x34(%r12),%edx
   326c2:	89 0c 24             	mov    %ecx,(%rsp)
   326c5:	89 54 24 03          	mov    %edx,0x3(%rsp)
   326c9:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   326cd:	0f 85 1d fe ff ff    	jne    324f0 <oriole_expat::run_events+0x60>
   326d3:	80 fb 11             	cmp    $0x11,%bl
   326d6:	0f 85 eb 00 00 00    	jne    327c7 <oriole_expat::run_events+0x337>
   326dc:	4c 89 f7             	mov    %r14,%rdi
   326df:	e8 6c 0b 00 00       	call   33250 <oriole_expat::resolve_unknown_encoding>
   326e4:	84 c0                	test   %al,%al
   326e6:	0f 85 53 ff ff ff    	jne    3263f <oriole_expat::run_events+0x1af>
   326ec:	e9 d6 00 00 00       	jmp    327c7 <oriole_expat::run_events+0x337>
   326f1:	4c 89 ef             	mov    %r13,%rdi
   326f4:	49 8d 5e 30          	lea    0x30(%r14),%rbx
   326f8:	48 89 de             	mov    %rbx,%rsi
   326fb:	ff 15 07 41 0b 00    	call   *0xb4107(%rip)        # e6808 <_GLOBAL_OFFSET_TABLE_+0xd0>
   32701:	80 bc 24 00 01 00 00 	cmpb   $0x0,0x100(%rsp)
   32708:	00 
   32709:	0f 84 26 01 00 00    	je     32835 <oriole_expat::run_events+0x3a5>
   3270f:	49 8b 44 24 20       	mov    0x20(%r12),%rax
   32714:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   32719:	41 0f 10 04 24       	movups (%r12),%xmm0
   3271e:	41 0f 10 4c 24 10    	movups 0x10(%r12),%xmm1
   32724:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   32729:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   3272e:	49 8b 86 80 0b 00 00 	mov    0xb80(%r14),%rax
   32735:	48 85 c0             	test   %rax,%rax
   32738:	0f 84 03 01 00 00    	je     32841 <oriole_expat::run_events+0x3b1>
   3273e:	49 8b be 88 0b 00 00 	mov    0xb88(%r14),%rdi
   32745:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   3274a:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
   3274f:	49 8d 8e 20 0a 00 00 	lea    0xa20(%r14),%rcx
   32756:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
   3275a:	0f 11 01             	movups %xmm0,(%rcx)
   3275d:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   32762:	ff d0                	call   *%rax
   32764:	41 8b 8e 14 0a 00 00 	mov    0xa14(%r14),%ecx
   3276b:	85 c9                	test   %ecx,%ecx
   3276d:	0f 85 17 02 00 00    	jne    3298a <oriole_expat::run_events+0x4fa>
   32773:	41 80 be 0a 0a 00 00 	cmpb   $0x0,0xa0a(%r14)
   3277a:	00 
   3277b:	0f 85 db 00 00 00    	jne    3285c <oriole_expat::run_events+0x3cc>
   32781:	4c 89 ef             	mov    %r13,%rdi
   32784:	48 89 de             	mov    %rbx,%rsi
   32787:	89 c2                	mov    %eax,%edx
   32789:	ff d5                	call   *%rbp
   3278b:	0f b6 84 24 30 01 00 	movzbl 0x130(%rsp),%eax
   32792:	00 
   32793:	49 63 04 87          	movslq (%r15,%rax,4),%rax
   32797:	4c 01 f8             	add    %r15,%rax
   3279a:	ff e0                	jmp    *%rax
   3279c:	b9 01 00 00 00       	mov    $0x1,%ecx
   327a1:	e9 b8 01 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   327a6:	41 89 86 10 0a 00 00 	mov    %eax,0xa10(%r14)
   327ad:	e9 dc 01 00 00       	jmp    3298e <oriole_expat::run_events+0x4fe>
   327b2:	41 c7 86 10 0a 00 00 	movl   $0x0,0xa10(%r14)
   327b9:	00 00 00 00 
   327bd:	b8 02 00 00 00       	mov    $0x2,%eax
   327c2:	e9 c9 01 00 00       	jmp    32990 <oriole_expat::run_events+0x500>
   327c7:	41 80 be 0a 0a 00 00 	cmpb   $0x0,0xa0a(%r14)
   327ce:	00 
   327cf:	0f 85 b9 01 00 00    	jne    3298e <oriole_expat::run_events+0x4fe>
   327d5:	41 83 be 14 0a 00 00 	cmpl   $0x0,0xa14(%r14)
   327dc:	00 
   327dd:	0f 85 ab 01 00 00    	jne    3298e <oriole_expat::run_events+0x4fe>
   327e3:	0f b6 c3             	movzbl %bl,%eax
   327e6:	48 8d 0d e7 78 fd ff 	lea    -0x28719(%rip),%rcx        # a0d4 <std::thread::current::id::ID+0xa064>
   327ed:	8b 04 81             	mov    (%rcx,%rax,4),%eax
   327f0:	41 89 86 14 0a 00 00 	mov    %eax,0xa14(%r14)
   327f7:	41 89 86 10 0a 00 00 	mov    %eax,0xa10(%r14)
   327fe:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
   32805:	00 
   32806:	0f 28 8c 24 90 00 00 	movaps 0x90(%rsp),%xmm1
   3280d:	00 
   3280e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   32813:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   32817:	0f 11 00             	movups %xmm0,(%rax)
   3281a:	e9 6f 01 00 00       	jmp    3298e <oriole_expat::run_events+0x4fe>
   3281f:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
   32826:	00 00 00 
   32829:	49 89 86 10 0a 00 00 	mov    %rax,0xa10(%r14)
   32830:	e9 59 01 00 00       	jmp    3298e <oriole_expat::run_events+0x4fe>
   32835:	41 8b 8e 14 0a 00 00 	mov    0xa14(%r14),%ecx
   3283c:	e9 49 01 00 00       	jmp    3298a <oriole_expat::run_events+0x4fa>
   32841:	48 b8 12 00 00 00 12 	movabs $0x1200000012,%rax
   32848:	00 00 00 
   3284b:	49 89 86 10 0a 00 00 	mov    %rax,0xa10(%r14)
   32852:	b9 12 00 00 00       	mov    $0x12,%ecx
   32857:	e9 2e 01 00 00       	jmp    3298a <oriole_expat::run_events+0x4fa>
   3285c:	31 c9                	xor    %ecx,%ecx
   3285e:	e9 27 01 00 00       	jmp    3298a <oriole_expat::run_events+0x4fa>
   32863:	b9 1b 00 00 00       	mov    $0x1b,%ecx
   32868:	e9 f1 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   3286d:	b9 1e 00 00 00       	mov    $0x1e,%ecx
   32872:	e9 e7 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   32877:	b9 0d 00 00 00       	mov    $0xd,%ecx
   3287c:	e9 dd 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   32881:	b9 1d 00 00 00       	mov    $0x1d,%ecx
   32886:	e9 d3 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   3288b:	b9 0e 00 00 00       	mov    $0xe,%ecx
   32890:	e9 c9 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   32895:	b9 03 00 00 00       	mov    $0x3,%ecx
   3289a:	e9 bf 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   3289f:	b9 27 00 00 00       	mov    $0x27,%ecx
   328a4:	e9 b5 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   328a9:	b9 04 00 00 00       	mov    $0x4,%ecx
   328ae:	e9 ab 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   328b3:	b9 24 00 00 00       	mov    $0x24,%ecx
   328b8:	e9 a1 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   328bd:	b9 20 00 00 00       	mov    $0x20,%ecx
   328c2:	e9 97 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   328c7:	b9 26 00 00 00       	mov    $0x26,%ecx
   328cc:	e9 8d 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   328d1:	b9 1c 00 00 00       	mov    $0x1c,%ecx
   328d6:	e9 83 00 00 00       	jmp    3295e <oriole_expat::run_events+0x4ce>
   328db:	b9 08 00 00 00       	mov    $0x8,%ecx
   328e0:	eb 7c                	jmp    3295e <oriole_expat::run_events+0x4ce>
   328e2:	b9 10 00 00 00       	mov    $0x10,%ecx
   328e7:	eb 75                	jmp    3295e <oriole_expat::run_events+0x4ce>
   328e9:	b9 13 00 00 00       	mov    $0x13,%ecx
   328ee:	eb 6e                	jmp    3295e <oriole_expat::run_events+0x4ce>
   328f0:	b9 28 00 00 00       	mov    $0x28,%ecx
   328f5:	eb 67                	jmp    3295e <oriole_expat::run_events+0x4ce>
   328f7:	b9 11 00 00 00       	mov    $0x11,%ecx
   328fc:	eb 60                	jmp    3295e <oriole_expat::run_events+0x4ce>
   328fe:	b9 0c 00 00 00       	mov    $0xc,%ecx
   32903:	eb 59                	jmp    3295e <oriole_expat::run_events+0x4ce>
   32905:	b9 06 00 00 00       	mov    $0x6,%ecx
   3290a:	eb 52                	jmp    3295e <oriole_expat::run_events+0x4ce>
   3290c:	b9 2b 00 00 00       	mov    $0x2b,%ecx
   32911:	eb 4b                	jmp    3295e <oriole_expat::run_events+0x4ce>
   32913:	b9 0a 00 00 00       	mov    $0xa,%ecx
   32918:	eb 44                	jmp    3295e <oriole_expat::run_events+0x4ce>
   3291a:	b9 09 00 00 00       	mov    $0x9,%ecx
   3291f:	eb 3d                	jmp    3295e <oriole_expat::run_events+0x4ce>
   32921:	b9 18 00 00 00       	mov    $0x18,%ecx
   32926:	eb 36                	jmp    3295e <oriole_expat::run_events+0x4ce>
   32928:	b9 02 00 00 00       	mov    $0x2,%ecx
   3292d:	eb 2f                	jmp    3295e <oriole_expat::run_events+0x4ce>
   3292f:	b9 05 00 00 00       	mov    $0x5,%ecx
   32934:	eb 28                	jmp    3295e <oriole_expat::run_events+0x4ce>
   32936:	b9 12 00 00 00       	mov    $0x12,%ecx
   3293b:	eb 21                	jmp    3295e <oriole_expat::run_events+0x4ce>
   3293d:	b9 0f 00 00 00       	mov    $0xf,%ecx
   32942:	eb 1a                	jmp    3295e <oriole_expat::run_events+0x4ce>
   32944:	b9 07 00 00 00       	mov    $0x7,%ecx
   32949:	eb 13                	jmp    3295e <oriole_expat::run_events+0x4ce>
   3294b:	b9 14 00 00 00       	mov    $0x14,%ecx
   32950:	eb 0c                	jmp    3295e <oriole_expat::run_events+0x4ce>
   32952:	b9 0b 00 00 00       	mov    $0xb,%ecx
   32957:	eb 05                	jmp    3295e <oriole_expat::run_events+0x4ce>
   32959:	b9 15 00 00 00       	mov    $0x15,%ecx
   3295e:	41 89 8e 14 0a 00 00 	mov    %ecx,0xa14(%r14)
   32965:	41 89 8e 10 0a 00 00 	mov    %ecx,0xa10(%r14)
   3296c:	0f 10 84 24 10 01 00 	movups 0x110(%rsp),%xmm0
   32973:	00 
   32974:	0f 10 8c 24 20 01 00 	movups 0x120(%rsp),%xmm1
   3297b:	00 
   3297c:	49 8d 86 20 0a 00 00 	lea    0xa20(%r14),%rax
   32983:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   32987:	0f 11 00             	movups %xmm0,(%rax)
   3298a:	85 c9                	test   %ecx,%ecx
   3298c:	74 14                	je     329a2 <oriole_expat::run_events+0x512>
   3298e:	31 c0                	xor    %eax,%eax
   32990:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   32997:	5b                   	pop    %rbx
   32998:	41 5c                	pop    %r12
   3299a:	41 5d                	pop    %r13
   3299c:	41 5e                	pop    %r14
   3299e:	41 5f                	pop    %r15
   329a0:	5d                   	pop    %rbp
   329a1:	c3                   	ret
   329a2:	41 0f 10 86 c0 08 00 	movups 0x8c0(%r14),%xmm0
   329a9:	00 
   329aa:	41 0f 10 8e d0 08 00 	movups 0x8d0(%r14),%xmm1
   329b1:	00 
   329b2:	49 8d 86 20 0a 00 00 	lea    0xa20(%r14),%rax
   329b9:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   329bd:	0f 11 00             	movups %xmm0,(%rax)
   329c0:	41 80 be e9 08 00 00 	cmpb   $0x0,0x8e9(%r14)
   329c7:	00 
   329c8:	74 1c                	je     329e6 <oriole_expat::run_events+0x556>
   329ca:	4c 89 f7             	mov    %r14,%rdi
   329cd:	e8 3e 04 00 00       	call   32e10 <oriole_expat::merge_external_subset>
   329d2:	84 c0                	test   %al,%al
   329d4:	b8 00 00 00 00       	mov    $0x0,%eax
   329d9:	74 b5                	je     32990 <oriole_expat::run_events+0x500>
   329db:	41 c7 86 0c 0a 00 00 	movl   $0x2,0xa0c(%r14)
   329e2:	02 00 00 00 
   329e6:	41 c7 86 10 0a 00 00 	movl   $0x0,0xa10(%r14)
   329ed:	00 00 00 00 
   329f1:	b8 01 00 00 00       	mov    $0x1,%eax
   329f6:	eb 98                	jmp    32990 <oriole_expat::run_events+0x500>
   329f8:	0f 0b                	ud2
