# Whole-owned-Event dispatch experiment

Rejected at the code-generation gate. Passing the whole owned Event into dispatch moves the position assignment into that function, while preserving existing per-variant ownership. The compiler still copies the event between call frames: a 144-byte memcpy plus a discriminant store replaces the 112-byte inline EventKind copy. Maven XML_Parse instructions rise from 23,220,272 to 23,459,410 (+1.030%).

The frozen source, exact narrow overlay, assembly, build log, and instruction profile are retained. No throughput test, sanitizer run, or full compatibility campaign is claimed. The positive output-slot study remains unchanged.
