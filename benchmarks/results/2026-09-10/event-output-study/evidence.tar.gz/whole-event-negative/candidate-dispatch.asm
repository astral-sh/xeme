
/tmp/oriole-event-dispatch/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000033e10 <oriole_expat::dispatch>:
   33e10:	55                   	push   %rbp
   33e11:	41 57                	push   %r15
   33e13:	41 56                	push   %r14
   33e15:	41 55                	push   %r13
   33e17:	41 54                	push   %r12
   33e19:	53                   	push   %rbx
   33e1a:	48 81 ec 78 06 00 00 	sub    $0x678,%rsp
   33e21:	48 89 fb             	mov    %rdi,%rbx
   33e24:	0f 10 46 78          	movups 0x78(%rsi),%xmm0
   33e28:	0f 10 8e 88 00 00 00 	movups 0x88(%rsi),%xmm1
   33e2f:	0f 11 8f 30 0a 00 00 	movups %xmm1,0xa30(%rdi)
   33e36:	0f 11 87 20 0a 00 00 	movups %xmm0,0xa20(%rdi)
   33e3d:	0f 10 06             	movups (%rsi),%xmm0
   33e40:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
   33e44:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
   33e48:	0f 10 5e 30          	movups 0x30(%rsi),%xmm3
   33e4c:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
   33e53:	00 
   33e54:	48 8b 46 70          	mov    0x70(%rsi),%rax
   33e58:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
   33e5f:	00 
   33e60:	0f 10 46 60          	movups 0x60(%rsi),%xmm0
   33e64:	0f 29 84 24 80 01 00 	movaps %xmm0,0x180(%rsp)
   33e6b:	00 
   33e6c:	0f 10 46 50          	movups 0x50(%rsi),%xmm0
   33e70:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
   33e77:	00 
   33e78:	0f 10 46 40          	movups 0x40(%rsi),%xmm0
   33e7c:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
   33e83:	00 
   33e84:	0f 29 9c 24 50 01 00 	movaps %xmm3,0x150(%rsp)
   33e8b:	00 
   33e8c:	0f 29 94 24 40 01 00 	movaps %xmm2,0x140(%rsp)
   33e93:	00 
   33e94:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
   33e9b:	00 
   33e9c:	48 83 e8 03          	sub    $0x3,%rax
   33ea0:	b9 0d 00 00 00       	mov    $0xd,%ecx
   33ea5:	48 0f 43 c8          	cmovae %rax,%rcx
   33ea9:	0f 29 8c 24 30 01 00 	movaps %xmm1,0x130(%rsp)
   33eb0:	00 
   33eb1:	48 83 f9 19          	cmp    $0x19,%rcx
   33eb5:	0f 92 c0             	setb   %al
   33eb8:	41 be 00 80 40 01    	mov    $0x1408000,%r14d
   33ebe:	41 d3 ee             	shr    %cl,%r14d
   33ec1:	41 20 c6             	and    %al,%r14b
   33ec4:	80 bf 08 0a 00 00 00 	cmpb   $0x0,0xa08(%rdi)
   33ecb:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
   33ed0:	75 08                	jne    33eda <oriole_expat::dispatch+0xca>
   33ed2:	48 8b 03             	mov    (%rbx),%rax
   33ed5:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   33eda:	45 84 f6             	test   %r14b,%r14b
   33edd:	74 15                	je     33ef4 <oriole_expat::dispatch+0xe4>
   33edf:	83 bb 48 0a 00 00 ff 	cmpl   $0xffffffff,0xa48(%rbx)
   33ee6:	74 0c                	je     33ef4 <oriole_expat::dispatch+0xe4>
   33ee8:	4c 8b ab 78 0a 00 00 	mov    0xa78(%rbx),%r13
   33eef:	49 ff cd             	dec    %r13
   33ef2:	eb 03                	jmp    33ef7 <oriole_expat::dispatch+0xe7>
   33ef4:	45 31 ed             	xor    %r13d,%r13d
   33ef7:	48 8b bb 50 09 00 00 	mov    0x950(%rbx),%rdi
   33efe:	48 8b 83 58 09 00 00 	mov    0x958(%rbx),%rax
   33f05:	48 89 84 24 c0 05 00 	mov    %rax,0x5c0(%rsp)
   33f0c:	00 
   33f0d:	48 8b 83 60 09 00 00 	mov    0x960(%rbx),%rax
   33f14:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
   33f1b:	00 
   33f1c:	4c 8b 83 68 09 00 00 	mov    0x968(%rbx),%r8
   33f23:	4c 8b 9b 70 09 00 00 	mov    0x970(%rbx),%r11
   33f2a:	48 8b 83 78 09 00 00 	mov    0x978(%rbx),%rax
   33f31:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
   33f38:	00 
   33f39:	48 8b 83 80 09 00 00 	mov    0x980(%rbx),%rax
   33f40:	48 89 84 24 90 05 00 	mov    %rax,0x590(%rsp)
   33f47:	00 
   33f48:	48 8b 83 88 09 00 00 	mov    0x988(%rbx),%rax
   33f4f:	48 89 84 24 a0 05 00 	mov    %rax,0x5a0(%rsp)
   33f56:	00 
   33f57:	48 8b 83 90 09 00 00 	mov    0x990(%rbx),%rax
   33f5e:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
   33f65:	00 
   33f66:	48 8b 83 98 09 00 00 	mov    0x998(%rbx),%rax
   33f6d:	48 89 84 24 b0 05 00 	mov    %rax,0x5b0(%rsp)
   33f74:	00 
   33f75:	48 8b 83 a0 09 00 00 	mov    0x9a0(%rbx),%rax
   33f7c:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
   33f83:	00 
   33f84:	4c 8b a3 a8 09 00 00 	mov    0x9a8(%rbx),%r12
   33f8b:	4c 8b 8b b0 09 00 00 	mov    0x9b0(%rbx),%r9
   33f92:	48 8d 05 f7 5c fd ff 	lea    -0x2a309(%rip),%rax        # 9c90 <std::thread::current::id::ID+0x9c20>
   33f99:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
   33f9d:	48 01 c1             	add    %rax,%rcx
   33fa0:	4c 8b 93 b8 09 00 00 	mov    0x9b8(%rbx),%r10
   33fa7:	4c 8b bb c8 09 00 00 	mov    0x9c8(%rbx),%r15
   33fae:	48 8b 83 d0 09 00 00 	mov    0x9d0(%rbx),%rax
   33fb5:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
   33fbc:	00 
   33fbd:	48 8b 83 d8 09 00 00 	mov    0x9d8(%rbx),%rax
   33fc4:	48 89 84 24 80 05 00 	mov    %rax,0x580(%rsp)
   33fcb:	00 
   33fcc:	48 8b 83 e0 09 00 00 	mov    0x9e0(%rbx),%rax
   33fd3:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
   33fda:	00 
   33fdb:	48 8b 83 e8 09 00 00 	mov    0x9e8(%rbx),%rax
   33fe2:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
   33fe9:	00 
   33fea:	48 8b ab f0 09 00 00 	mov    0x9f0(%rbx),%rbp
   33ff1:	48 89 94 24 78 05 00 	mov    %rdx,0x578(%rsp)
   33ff8:	00 
   33ff9:	ff e1                	jmp    *%rcx
   33ffb:	48 8b 93 50 05 00 00 	mov    0x550(%rbx),%rdx
   34002:	e9 91 03 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   34007:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
   3400e:	00 
   3400f:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34013:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   34017:	0f 84 b2 02 00 00    	je     342cf <oriole_expat::dispatch+0x4bf>
   3401d:	48 8b 50 68          	mov    0x68(%rax),%rdx
   34021:	48 01 ca             	add    %rcx,%rdx
   34024:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   34028:	0f 85 ac 02 00 00    	jne    342da <oriole_expat::dispatch+0x4ca>
   3402e:	e9 b6 02 00 00       	jmp    342e9 <oriole_expat::dispatch+0x4d9>
   34033:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
   3403a:	00 
   3403b:	48 8b 50 68          	mov    0x68(%rax),%rdx
   3403f:	48 03 50 30          	add    0x30(%rax),%rdx
   34043:	48 03 90 a0 00 00 00 	add    0xa0(%rax),%rdx
   3404a:	83 b8 a8 00 00 00 ff 	cmpl   $0xffffffff,0xa8(%rax)
   34051:	0f 84 92 02 00 00    	je     342e9 <oriole_expat::dispatch+0x4d9>
   34057:	48 8b 80 d8 00 00 00 	mov    0xd8(%rax),%rax
   3405e:	48 01 c2             	add    %rax,%rdx
   34061:	e9 32 03 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   34066:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
   3406d:	00 
   3406e:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34072:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   34076:	0f 84 ff 01 00 00    	je     3427b <oriole_expat::dispatch+0x46b>
   3407c:	48 8b 50 68          	mov    0x68(%rax),%rdx
   34080:	e9 f8 01 00 00       	jmp    3427d <oriole_expat::dispatch+0x46d>
   34085:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
   3408c:	00 
   3408d:	83 38 ff             	cmpl   $0xffffffff,(%rax)
   34090:	0f 84 2d 02 00 00    	je     342c3 <oriole_expat::dispatch+0x4b3>
   34096:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3409a:	e9 26 02 00 00       	jmp    342c5 <oriole_expat::dispatch+0x4b5>
   3409f:	83 bc 24 58 01 00 00 	cmpl   $0xffffffff,0x158(%rsp)
   340a6:	ff 
   340a7:	0f 84 b8 01 00 00    	je     34265 <oriole_expat::dispatch+0x455>
   340ad:	48 8b 94 24 88 01 00 	mov    0x188(%rsp),%rdx
   340b4:	00 
   340b5:	48 03 94 24 50 01 00 	add    0x150(%rsp),%rdx
   340bc:	00 
   340bd:	e9 d6 02 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   340c2:	4c 89 9c 24 38 03 00 	mov    %r11,0x338(%rsp)
   340c9:	00 
   340ca:	48 89 bc 24 60 04 00 	mov    %rdi,0x460(%rsp)
   340d1:	00 
   340d2:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
   340d9:	00 
   340da:	48 8b bc 24 90 01 00 	mov    0x190(%rsp),%rdi
   340e1:	00 
   340e2:	4d 89 c3             	mov    %r8,%r11
   340e5:	48 85 ff             	test   %rdi,%rdi
   340e8:	0f 84 05 02 00 00    	je     342f3 <oriole_expat::dispatch+0x4e3>
   340ee:	48 8b 8c 24 80 01 00 	mov    0x180(%rsp),%rcx
   340f5:	00 
   340f6:	89 fe                	mov    %edi,%esi
   340f8:	83 e6 03             	and    $0x3,%esi
   340fb:	48 83 ff 04          	cmp    $0x4,%rdi
   340ff:	0f 83 f5 01 00 00    	jae    342fa <oriole_expat::dispatch+0x4ea>
   34105:	45 31 c0             	xor    %r8d,%r8d
   34108:	31 d2                	xor    %edx,%edx
   3410a:	e9 49 02 00 00       	jmp    34358 <oriole_expat::dispatch+0x548>
   3410f:	31 d2                	xor    %edx,%edx
   34111:	83 bc 24 28 01 00 00 	cmpl   $0xffffffff,0x128(%rsp)
   34118:	ff 
   34119:	b8 00 00 00 00       	mov    $0x0,%eax
   3411e:	74 08                	je     34128 <oriole_expat::dispatch+0x318>
   34120:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
   34127:	00 
   34128:	48 83 bc 24 60 01 00 	cmpq   $0xffffffffffffffff,0x160(%rsp)
   3412f:	00 ff 
   34131:	74 08                	je     3413b <oriole_expat::dispatch+0x32b>
   34133:	48 8b 94 24 90 01 00 	mov    0x190(%rsp),%rdx
   3413a:	00 
   3413b:	48 01 c2             	add    %rax,%rdx
   3413e:	e9 55 02 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   34143:	48 83 bc 24 60 01 00 	cmpq   $0xffffffffffffffff,0x160(%rsp)
   3414a:	00 ff 
   3414c:	0f 84 22 01 00 00    	je     34274 <oriole_expat::dispatch+0x464>
   34152:	48 8b 94 24 90 01 00 	mov    0x190(%rsp),%rdx
   34159:	00 
   3415a:	48 03 94 24 58 01 00 	add    0x158(%rsp),%rdx
   34161:	00 
   34162:	e9 31 02 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   34167:	83 bc 24 28 01 00 00 	cmpl   $0xffffffff,0x128(%rsp)
   3416e:	ff 
   3416f:	74 0d                	je     3417e <oriole_expat::dispatch+0x36e>
   34171:	48 8b 94 24 58 01 00 	mov    0x158(%rsp),%rdx
   34178:	00 
   34179:	e9 1a 02 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   3417e:	31 d2                	xor    %edx,%edx
   34180:	e9 13 02 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   34185:	48 89 ac 24 78 04 00 	mov    %rbp,0x478(%rsp)
   3418c:	00 
   3418d:	4c 89 9c 24 38 03 00 	mov    %r11,0x338(%rsp)
   34194:	00 
   34195:	4c 89 a4 24 68 04 00 	mov    %r12,0x468(%rsp)
   3419c:	00 
   3419d:	4c 89 84 24 80 04 00 	mov    %r8,0x480(%rsp)
   341a4:	00 
   341a5:	4c 89 fd             	mov    %r15,%rbp
   341a8:	4d 89 cf             	mov    %r9,%r15
   341ab:	48 89 bc 24 60 04 00 	mov    %rdi,0x460(%rsp)
   341b2:	00 
   341b3:	4c 89 94 24 70 04 00 	mov    %r10,0x470(%rsp)
   341ba:	00 
   341bb:	b0 01                	mov    $0x1,%al
   341bd:	89 44 24 48          	mov    %eax,0x48(%rsp)
   341c1:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   341c8:	00 
   341c9:	b0 01                	mov    $0x1,%al
   341cb:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   341cf:	b0 01                	mov    $0x1,%al
   341d1:	89 44 24 30          	mov    %eax,0x30(%rsp)
   341d5:	b0 01                	mov    $0x1,%al
   341d7:	89 44 24 38          	mov    %eax,0x38(%rsp)
   341db:	b0 01                	mov    $0x1,%al
   341dd:	89 44 24 14          	mov    %eax,0x14(%rsp)
   341e1:	b0 01                	mov    $0x1,%al
   341e3:	89 44 24 10          	mov    %eax,0x10(%rsp)
   341e7:	b0 01                	mov    $0x1,%al
   341e9:	89 44 24 40          	mov    %eax,0x40(%rsp)
   341ed:	b0 01                	mov    $0x1,%al
   341ef:	89 44 24 08          	mov    %eax,0x8(%rsp)
   341f3:	b0 01                	mov    $0x1,%al
   341f5:	89 44 24 04          	mov    %eax,0x4(%rsp)
   341f9:	b0 01                	mov    $0x1,%al
   341fb:	89 44 24 28          	mov    %eax,0x28(%rsp)
   341ff:	b0 01                	mov    $0x1,%al
   34201:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   34206:	b0 01                	mov    $0x1,%al
   34208:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3420c:	b0 01                	mov    $0x1,%al
   3420e:	89 44 24 24          	mov    %eax,0x24(%rsp)
   34212:	b0 01                	mov    $0x1,%al
   34214:	89 44 24 18          	mov    %eax,0x18(%rsp)
   34218:	b0 01                	mov    $0x1,%al
   3421a:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3421e:	b0 01                	mov    $0x1,%al
   34220:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   34224:	ff 15 be 28 0b 00    	call   *0xb28be(%rip)        # e6ae8 <_GLOBAL_OFFSET_TABLE_+0x240>
   3422a:	4c 8b 94 24 70 04 00 	mov    0x470(%rsp),%r10
   34231:	00 
   34232:	48 8b bc 24 60 04 00 	mov    0x460(%rsp),%rdi
   34239:	00 
   3423a:	4d 89 f9             	mov    %r15,%r9
   3423d:	49 89 ef             	mov    %rbp,%r15
   34240:	4c 8b 84 24 80 04 00 	mov    0x480(%rsp),%r8
   34247:	00 
   34248:	4c 8b a4 24 68 04 00 	mov    0x468(%rsp),%r12
   3424f:	00 
   34250:	4c 8b 9c 24 38 03 00 	mov    0x338(%rsp),%r11
   34257:	00 
   34258:	48 8b ac 24 78 04 00 	mov    0x478(%rsp),%rbp
   3425f:	00 
   34260:	e9 33 01 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   34265:	31 d2                	xor    %edx,%edx
   34267:	48 03 94 24 50 01 00 	add    0x150(%rsp),%rdx
   3426e:	00 
   3426f:	e9 24 01 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   34274:	31 d2                	xor    %edx,%edx
   34276:	e9 df fe ff ff       	jmp    3415a <oriole_expat::dispatch+0x34a>
   3427b:	31 d2                	xor    %edx,%edx
   3427d:	48 01 ca             	add    %rcx,%rdx
   34280:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   34284:	74 09                	je     3428f <oriole_expat::dispatch+0x47f>
   34286:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
   3428d:	eb 02                	jmp    34291 <oriole_expat::dispatch+0x481>
   3428f:	31 c9                	xor    %ecx,%ecx
   34291:	48 01 ca             	add    %rcx,%rdx
   34294:	83 b8 a8 00 00 00 ff 	cmpl   $0xffffffff,0xa8(%rax)
   3429b:	74 09                	je     342a6 <oriole_expat::dispatch+0x496>
   3429d:	48 8b 88 d8 00 00 00 	mov    0xd8(%rax),%rcx
   342a4:	eb 02                	jmp    342a8 <oriole_expat::dispatch+0x498>
   342a6:	31 c9                	xor    %ecx,%ecx
   342a8:	48 01 ca             	add    %rcx,%rdx
   342ab:	83 b8 e0 00 00 00 ff 	cmpl   $0xffffffff,0xe0(%rax)
   342b2:	74 35                	je     342e9 <oriole_expat::dispatch+0x4d9>
   342b4:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
   342bb:	48 01 c2             	add    %rax,%rdx
   342be:	e9 d5 00 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   342c3:	31 c9                	xor    %ecx,%ecx
   342c5:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   342c9:	0f 85 4e fd ff ff    	jne    3401d <oriole_expat::dispatch+0x20d>
   342cf:	31 d2                	xor    %edx,%edx
   342d1:	48 01 ca             	add    %rcx,%rdx
   342d4:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   342d8:	74 0f                	je     342e9 <oriole_expat::dispatch+0x4d9>
   342da:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
   342e1:	48 01 c2             	add    %rax,%rdx
   342e4:	e9 af 00 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   342e9:	31 c0                	xor    %eax,%eax
   342eb:	48 01 c2             	add    %rax,%rdx
   342ee:	e9 a5 00 00 00       	jmp    34398 <oriole_expat::dispatch+0x588>
   342f3:	31 d2                	xor    %edx,%edx
   342f5:	e9 88 00 00 00       	jmp    34382 <oriole_expat::dispatch+0x572>
   342fa:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
   342ff:	48 83 e7 fc          	and    $0xfffffffffffffffc,%rdi
   34303:	4c 8d 89 d0 01 00 00 	lea    0x1d0(%rcx),%r9
   3430a:	45 31 c0             	xor    %r8d,%r8d
   3430d:	31 d2                	xor    %edx,%edx
   3430f:	90                   	nop
   34310:	49 03 91 60 fe ff ff 	add    -0x1a0(%r9),%rdx
   34317:	49 03 91 98 fe ff ff 	add    -0x168(%r9),%rdx
   3431e:	49 03 91 d8 fe ff ff 	add    -0x128(%r9),%rdx
   34325:	49 03 91 10 ff ff ff 	add    -0xf0(%r9),%rdx
   3432c:	49 03 91 50 ff ff ff 	add    -0xb0(%r9),%rdx
   34333:	49 03 51 88          	add    -0x78(%r9),%rdx
   34337:	49 03 51 c8          	add    -0x38(%r9),%rdx
   3433b:	49 03 11             	add    (%r9),%rdx
   3433e:	49 83 c0 04          	add    $0x4,%r8
   34342:	49 81 c1 e0 01 00 00 	add    $0x1e0,%r9
   34349:	4c 39 c7             	cmp    %r8,%rdi
   3434c:	75 c2                	jne    34310 <oriole_expat::dispatch+0x500>
   3434e:	48 85 f6             	test   %rsi,%rsi
   34351:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
   34356:	74 2a                	je     34382 <oriole_expat::dispatch+0x572>
   34358:	49 6b f8 78          	imul   $0x78,%r8,%rdi
   3435c:	48 01 f9             	add    %rdi,%rcx
   3435f:	48 83 c1 68          	add    $0x68,%rcx
   34363:	48 6b f6 78          	imul   $0x78,%rsi,%rsi
   34367:	31 ff                	xor    %edi,%edi
   34369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   34370:	48 03 54 39 c8       	add    -0x38(%rcx,%rdi,1),%rdx
   34375:	48 03 14 39          	add    (%rcx,%rdi,1),%rdx
   34379:	48 83 c7 78          	add    $0x78,%rdi
   3437d:	48 39 fe             	cmp    %rdi,%rsi
   34380:	75 ee                	jne    34370 <oriole_expat::dispatch+0x560>
   34382:	48 01 c2             	add    %rax,%rdx
   34385:	48 8b bc 24 60 04 00 	mov    0x460(%rsp),%rdi
   3438c:	00 
   3438d:	4d 89 d8             	mov    %r11,%r8
   34390:	4c 8b 9c 24 38 03 00 	mov    0x338(%rsp),%r11
   34397:	00 
   34398:	4c 01 ea             	add    %r13,%rdx
   3439b:	48 8b 8b 68 0b 00 00 	mov    0xb68(%rbx),%rcx
   343a2:	48 8b 41 30          	mov    0x30(%rcx),%rax
   343a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   343ad:	00 00 00 
   343b0:	48 8d 34 02          	lea    (%rdx,%rax,1),%rsi
   343b4:	48 39 c6             	cmp    %rax,%rsi
   343b7:	0f 82 6b 01 00 00    	jb     34528 <oriole_expat::dispatch+0x718>
   343bd:	48 81 fe 00 00 00 04 	cmp    $0x4000000,%rsi
   343c4:	0f 87 5e 01 00 00    	ja     34528 <oriole_expat::dispatch+0x718>
   343ca:	f0 48 0f b1 71 30    	lock cmpxchg %rsi,0x30(%rcx)
   343d0:	75 de                	jne    343b0 <oriole_expat::dispatch+0x5a0>
   343d2:	45 84 f6             	test   %r14b,%r14b
   343d5:	0f 84 a7 01 00 00    	je     34582 <oriole_expat::dispatch+0x772>
   343db:	83 bb 48 0a 00 00 ff 	cmpl   $0xffffffff,0xa48(%rbx)
   343e2:	0f 84 a8 01 00 00    	je     34590 <oriole_expat::dispatch+0x780>
   343e8:	48 89 ac 24 78 04 00 	mov    %rbp,0x478(%rsp)
   343ef:	00 
   343f0:	4c 89 dd             	mov    %r11,%rbp
   343f3:	4c 89 a4 24 68 04 00 	mov    %r12,0x468(%rsp)
   343fa:	00 
   343fb:	4d 89 c4             	mov    %r8,%r12
   343fe:	4c 89 bc 24 38 03 00 	mov    %r15,0x338(%rsp)
   34405:	00 
   34406:	4d 89 cf             	mov    %r9,%r15
   34409:	49 89 fd             	mov    %rdi,%r13
   3440c:	4d 89 d6             	mov    %r10,%r14
   3440f:	48 8d b3 48 0a 00 00 	lea    0xa48(%rbx),%rsi
   34416:	b0 01                	mov    $0x1,%al
   34418:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3441c:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   34423:	00 
   34424:	b0 01                	mov    $0x1,%al
   34426:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3442a:	b0 01                	mov    $0x1,%al
   3442c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   34430:	b0 01                	mov    $0x1,%al
   34432:	89 44 24 38          	mov    %eax,0x38(%rsp)
   34436:	b0 01                	mov    $0x1,%al
   34438:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3443c:	b0 01                	mov    $0x1,%al
   3443e:	89 44 24 10          	mov    %eax,0x10(%rsp)
   34442:	b0 01                	mov    $0x1,%al
   34444:	89 44 24 40          	mov    %eax,0x40(%rsp)
   34448:	b0 01                	mov    $0x1,%al
   3444a:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3444e:	b0 01                	mov    $0x1,%al
   34450:	89 44 24 04          	mov    %eax,0x4(%rsp)
   34454:	b0 01                	mov    $0x1,%al
   34456:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3445a:	b0 01                	mov    $0x1,%al
   3445c:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   34461:	b0 01                	mov    $0x1,%al
   34463:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   34467:	b0 01                	mov    $0x1,%al
   34469:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3446d:	b0 01                	mov    $0x1,%al
   3446f:	89 44 24 18          	mov    %eax,0x18(%rsp)
   34473:	b0 01                	mov    $0x1,%al
   34475:	89 44 24 20          	mov    %eax,0x20(%rsp)
   34479:	b0 01                	mov    $0x1,%al
   3447b:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3447f:	ff 15 3b 26 0b 00    	call   *0xb263b(%rip)        # e6ac0 <_GLOBAL_OFFSET_TABLE_+0x218>
   34485:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   3448c:	00 
   3448d:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   34494:	00 
   34495:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   3449c:	00 
   3449d:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   344a4:	00 
   344a5:	0f 10 84 24 59 03 00 	movups 0x359(%rsp),%xmm0
   344ac:	00 
   344ad:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
   344b4:	00 
   344b5:	0f 10 84 24 68 03 00 	movups 0x368(%rsp),%xmm0
   344bc:	00 
   344bd:	0f 11 84 24 3f 02 00 	movups %xmm0,0x23f(%rsp)
   344c4:	00 
   344c5:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   344c9:	0f 84 e2 01 00 00    	je     346b1 <oriole_expat::dispatch+0x8a1>
   344cf:	4d 89 f2             	mov    %r14,%r10
   344d2:	4d 89 f9             	mov    %r15,%r9
   344d5:	4d 89 e0             	mov    %r12,%r8
   344d8:	49 89 eb             	mov    %rbp,%r11
   344db:	0f 10 84 24 3f 02 00 	movups 0x23f(%rsp),%xmm0
   344e2:	00 
   344e3:	0f 11 84 24 bf 00 00 	movups %xmm0,0xbf(%rsp)
   344ea:	00 
   344eb:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
   344f2:	00 
   344f3:	0f 28 8c 24 30 02 00 	movaps 0x230(%rsp),%xmm1
   344fa:	00 
   344fb:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   34502:	00 
   34503:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   3450a:	00 
   3450b:	4c 89 ef             	mov    %r13,%rdi
   3450e:	4c 8b bc 24 38 03 00 	mov    0x338(%rsp),%r15
   34515:	00 
   34516:	4c 8b a4 24 68 04 00 	mov    0x468(%rsp),%r12
   3451d:	00 
   3451e:	48 8b ac 24 78 04 00 	mov    0x478(%rsp),%rbp
   34525:	00 
   34526:	eb 6f                	jmp    34597 <oriole_expat::dispatch+0x787>
   34528:	48 b8 2b 00 00 00 2b 	movabs $0x2b0000002b,%rax
   3452f:	00 00 00 
   34532:	48 89 83 10 0a 00 00 	mov    %rax,0xa10(%rbx)
   34539:	41 b5 ff             	mov    $0xff,%r13b
   3453c:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
   34543:	00 
   34544:	48 83 e9 03          	sub    $0x3,%rcx
   34548:	b8 0d 00 00 00       	mov    $0xd,%eax
   3454d:	48 0f 43 c1          	cmovae %rcx,%rax
   34551:	48 83 c0 fa          	add    $0xfffffffffffffffa,%rax
   34555:	48 83 f8 14          	cmp    $0x14,%rax
   34559:	0f 87 49 4c 00 00    	ja     391a8 <oriole_expat::dispatch+0x5398>
   3455f:	48 8d 0d 96 57 fd ff 	lea    -0x2a86a(%rip),%rcx        # 9cfc <std::thread::current::id::ID+0x9c8c>
   34566:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   3456a:	48 01 c8             	add    %rcx,%rax
   3456d:	ff e0                	jmp    *%rax
   3456f:	83 bc 24 28 01 00 00 	cmpl   $0xffffffff,0x128(%rsp)
   34576:	ff 
   34577:	0f 85 2f 4b 00 00    	jne    390ac <oriole_expat::dispatch+0x529c>
   3457d:	e9 26 4c 00 00       	jmp    391a8 <oriole_expat::dispatch+0x5398>
   34582:	48 c7 84 24 08 05 00 	movq   $0xffffffffffffffff,0x508(%rsp)
   34589:	00 ff ff ff ff 
   3458e:	eb 46                	jmp    345d6 <oriole_expat::dispatch+0x7c6>
   34590:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   34597:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
   3459e:	00 
   3459f:	0f 28 8c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm1
   345a6:	00 
   345a7:	0f 11 84 24 11 05 00 	movups %xmm0,0x511(%rsp)
   345ae:	00 
   345af:	0f 11 8c 24 21 05 00 	movups %xmm1,0x521(%rsp)
   345b6:	00 
   345b7:	0f 10 84 24 bf 00 00 	movups 0xbf(%rsp),%xmm0
   345be:	00 
   345bf:	0f 11 84 24 30 05 00 	movups %xmm0,0x530(%rsp)
   345c6:	00 
   345c7:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
   345ce:	00 
   345cf:	88 8c 24 10 05 00 00 	mov    %cl,0x510(%rsp)
   345d6:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
   345dd:	00 
   345de:	48 89 c2             	mov    %rax,%rdx
   345e1:	48 83 ea 03          	sub    $0x3,%rdx
   345e5:	b9 0d 00 00 00       	mov    $0xd,%ecx
   345ea:	48 0f 43 ca          	cmovae %rdx,%rcx
   345ee:	48 83 f9 1a          	cmp    $0x1a,%rcx
   345f2:	0f 92 84 24 78 04 00 	setb   0x478(%rsp)
   345f9:	00 
   345fa:	ba 3e 00 c7 03       	mov    $0x3c7003e,%edx
   345ff:	d3 ea                	shr    %cl,%edx
   34601:	89 94 24 38 03 00 00 	mov    %edx,0x338(%rsp)
   34608:	48 83 f8 08          	cmp    $0x8,%rax
   3460c:	0f 95 84 24 1e 01 00 	setne  0x11e(%rsp)
   34613:	00 
   34614:	4d 85 c9             	test   %r9,%r9
   34617:	0f 94 84 24 68 04 00 	sete   0x468(%rsp)
   3461e:	00 
   3461f:	48 8d 84 24 28 01 00 	lea    0x128(%rsp),%rax
   34626:	00 
   34627:	0f b6 94 24 28 01 00 	movzbl 0x128(%rsp),%edx
   3462e:	00 
   3462f:	88 94 24 80 04 00 00 	mov    %dl,0x480(%rsp)
   34636:	0f b6 94 24 29 01 00 	movzbl 0x129(%rsp),%edx
   3463d:	00 
   3463e:	88 94 24 1f 01 00 00 	mov    %dl,0x11f(%rsp)
   34645:	48 8d 15 04 57 fd ff 	lea    -0x2a8fc(%rip),%rdx        # 9d50 <std::thread::current::id::ID+0x9ce0>
   3464c:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   34650:	48 01 d1             	add    %rdx,%rcx
   34653:	b2 01                	mov    $0x1,%dl
   34655:	89 54 24 2c          	mov    %edx,0x2c(%rsp)
   34659:	b2 01                	mov    $0x1,%dl
   3465b:	89 54 24 30          	mov    %edx,0x30(%rsp)
   3465f:	b2 01                	mov    $0x1,%dl
   34661:	89 54 24 48          	mov    %edx,0x48(%rsp)
   34665:	b2 01                	mov    $0x1,%dl
   34667:	89 54 24 38          	mov    %edx,0x38(%rsp)
   3466b:	b2 01                	mov    $0x1,%dl
   3466d:	89 54 24 14          	mov    %edx,0x14(%rsp)
   34671:	b2 01                	mov    $0x1,%dl
   34673:	89 54 24 10          	mov    %edx,0x10(%rsp)
   34677:	b2 01                	mov    $0x1,%dl
   34679:	89 54 24 40          	mov    %edx,0x40(%rsp)
   3467d:	b2 01                	mov    $0x1,%dl
   3467f:	89 54 24 08          	mov    %edx,0x8(%rsp)
   34683:	b2 01                	mov    $0x1,%dl
   34685:	89 54 24 04          	mov    %edx,0x4(%rsp)
   34689:	b2 01                	mov    $0x1,%dl
   3468b:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   3468f:	b2 01                	mov    $0x1,%dl
   34691:	89 54 24 24          	mov    %edx,0x24(%rsp)
   34695:	b2 01                	mov    $0x1,%dl
   34697:	89 54 24 18          	mov    %edx,0x18(%rsp)
   3469b:	b2 01                	mov    $0x1,%dl
   3469d:	89 54 24 20          	mov    %edx,0x20(%rsp)
   346a1:	b2 01                	mov    $0x1,%dl
   346a3:	89 54 24 1c          	mov    %edx,0x1c(%rsp)
   346a7:	ff e1                	jmp    *%rcx
   346a9:	4d 85 c9             	test   %r9,%r9
   346ac:	e9 79 10 00 00       	jmp    3572a <oriole_expat::dispatch+0x191a>
   346b1:	41 89 cd             	mov    %ecx,%r13d
   346b4:	e9 83 fe ff ff       	jmp    3453c <oriole_expat::dispatch+0x72c>
   346b9:	48 8b 48 30          	mov    0x30(%rax),%rcx
   346bd:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   346c4:	00 
   346c5:	0f 10 00             	movups (%rax),%xmm0
   346c8:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   346cc:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   346d0:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   346d7:	00 
   346d8:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   346dd:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   346e2:	4d 85 db             	test   %r11,%r11
   346e5:	0f 84 04 22 00 00    	je     368ef <oriole_expat::dispatch+0x2adf>
   346eb:	4c 89 dd             	mov    %r11,%rbp
   346ee:	48 8b 48 30          	mov    0x30(%rax),%rcx
   346f2:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
   346f9:	00 
   346fa:	0f 10 00             	movups (%rax),%xmm0
   346fd:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34701:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   34705:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   3470c:	00 
   3470d:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   34714:	00 
   34715:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   3471c:	00 
   3471d:	b0 01                	mov    $0x1,%al
   3471f:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   34723:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   3472a:	00 
   3472b:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34732:	00 
   34733:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3473a:	00 
   3473b:	b0 01                	mov    $0x1,%al
   3473d:	89 44 24 30          	mov    %eax,0x30(%rsp)
   34741:	b0 01                	mov    $0x1,%al
   34743:	89 44 24 48          	mov    %eax,0x48(%rsp)
   34747:	b0 01                	mov    $0x1,%al
   34749:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3474d:	b0 01                	mov    $0x1,%al
   3474f:	89 44 24 10          	mov    %eax,0x10(%rsp)
   34753:	b0 01                	mov    $0x1,%al
   34755:	89 44 24 40          	mov    %eax,0x40(%rsp)
   34759:	b0 01                	mov    $0x1,%al
   3475b:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3475f:	b0 01                	mov    $0x1,%al
   34761:	89 44 24 04          	mov    %eax,0x4(%rsp)
   34765:	b0 01                	mov    $0x1,%al
   34767:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3476b:	b0 01                	mov    $0x1,%al
   3476d:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   34772:	b0 01                	mov    $0x1,%al
   34774:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   34778:	41 b6 01             	mov    $0x1,%r14b
   3477b:	41 b4 01             	mov    $0x1,%r12b
   3477e:	41 b7 01             	mov    $0x1,%r15b
   34781:	41 b5 01             	mov    $0x1,%r13b
   34784:	ff 15 26 23 0b 00    	call   *0xb2326(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   3478a:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   34791:	00 
   34792:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   34799:	00 00 
   3479b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3479f:	0f 84 ef 31 00 00    	je     37994 <oriole_expat::dispatch+0x3b84>
   347a5:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   347ac:	00 
   347ad:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   347b4:	00 
   347b5:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   347bc:	00 
   347bd:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   347c4:	00 
   347c5:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   347cc:	00 
   347cd:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   347d4:	00 
   347d5:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   347dc:	00 
   347dd:	44 88 ac 24 a8 00 00 	mov    %r13b,0xa8(%rsp)
   347e4:	00 
   347e5:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   347ec:	00 
   347ed:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   347f2:	ff d5                	call   *%rbp
   347f4:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   347fb:	00 
   347fc:	48 85 c9             	test   %rcx,%rcx
   347ff:	74 6c                	je     3486d <oriole_expat::dispatch+0xa5d>
   34801:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   34808:	00 
   34809:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   34810:	00 
   34811:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   34818:	00 
   34819:	ba 01 00 00 00       	mov    $0x1,%edx
   3481e:	b0 01                	mov    $0x1,%al
   34820:	89 44 24 30          	mov    %eax,0x30(%rsp)
   34824:	b0 01                	mov    $0x1,%al
   34826:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3482a:	b0 01                	mov    $0x1,%al
   3482c:	89 44 24 14          	mov    %eax,0x14(%rsp)
   34830:	b0 01                	mov    $0x1,%al
   34832:	89 44 24 10          	mov    %eax,0x10(%rsp)
   34836:	b0 01                	mov    $0x1,%al
   34838:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3483c:	b0 01                	mov    $0x1,%al
   3483e:	89 44 24 08          	mov    %eax,0x8(%rsp)
   34842:	b0 01                	mov    $0x1,%al
   34844:	89 44 24 04          	mov    %eax,0x4(%rsp)
   34848:	b0 01                	mov    $0x1,%al
   3484a:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3484e:	b0 01                	mov    $0x1,%al
   34850:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   34855:	b0 01                	mov    $0x1,%al
   34857:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3485b:	41 b6 01             	mov    $0x1,%r14b
   3485e:	41 b4 01             	mov    $0x1,%r12b
   34861:	41 b7 01             	mov    $0x1,%r15b
   34864:	41 b5 01             	mov    $0x1,%r13b
   34867:	ff 15 73 21 0b 00    	call   *0xb2173(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3486d:	40 b5 01             	mov    $0x1,%bpl
   34870:	e9 12 39 00 00       	jmp    38187 <oriole_expat::dispatch+0x4377>
   34875:	b0 01                	mov    $0x1,%al
   34877:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3487b:	b0 01                	mov    $0x1,%al
   3487d:	89 44 24 30          	mov    %eax,0x30(%rsp)
   34881:	b0 01                	mov    $0x1,%al
   34883:	89 44 24 48          	mov    %eax,0x48(%rsp)
   34887:	b0 01                	mov    $0x1,%al
   34889:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3488d:	b0 01                	mov    $0x1,%al
   3488f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   34893:	b0 01                	mov    $0x1,%al
   34895:	89 44 24 10          	mov    %eax,0x10(%rsp)
   34899:	b0 01                	mov    $0x1,%al
   3489b:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3489f:	b0 01                	mov    $0x1,%al
   348a1:	89 44 24 08          	mov    %eax,0x8(%rsp)
   348a5:	b0 01                	mov    $0x1,%al
   348a7:	89 44 24 04          	mov    %eax,0x4(%rsp)
   348ab:	b0 01                	mov    $0x1,%al
   348ad:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   348b1:	b0 01                	mov    $0x1,%al
   348b3:	89 44 24 24          	mov    %eax,0x24(%rsp)
   348b7:	b0 01                	mov    $0x1,%al
   348b9:	89 44 24 18          	mov    %eax,0x18(%rsp)
   348bd:	b0 01                	mov    $0x1,%al
   348bf:	89 44 24 20          	mov    %eax,0x20(%rsp)
   348c3:	b0 01                	mov    $0x1,%al
   348c5:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   348c9:	48 83 bc 24 90 05 00 	cmpq   $0x0,0x590(%rsp)
   348d0:	00 00 
   348d2:	0f 84 b7 0e 00 00    	je     3578f <oriole_expat::dispatch+0x197f>
   348d8:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   348dd:	ff 94 24 90 05 00 00 	call   *0x590(%rsp)
   348e4:	e9 d0 10 00 00       	jmp    359b9 <oriole_expat::dispatch+0x1ba9>
   348e9:	48 8b 48 30          	mov    0x30(%rax),%rcx
   348ed:	48 89 8c 24 50 02 00 	mov    %rcx,0x250(%rsp)
   348f4:	00 
   348f5:	0f 10 00             	movups (%rax),%xmm0
   348f8:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   348fc:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   34900:	0f 29 94 24 40 02 00 	movaps %xmm2,0x240(%rsp)
   34907:	00 
   34908:	0f 29 8c 24 30 02 00 	movaps %xmm1,0x230(%rsp)
   3490f:	00 
   34910:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   34917:	00 
   34918:	4c 8b b4 24 c0 05 00 	mov    0x5c0(%rsp),%r14
   3491f:	00 
   34920:	4d 85 f6             	test   %r14,%r14
   34923:	0f 84 4d 20 00 00    	je     36976 <oriole_expat::dispatch+0x2b66>
   34929:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
   34930:	00 
   34931:	48 8b 94 24 50 02 00 	mov    0x250(%rsp),%rdx
   34938:	00 
   34939:	31 ff                	xor    %edi,%edi
   3493b:	e8 d0 80 00 00       	call   3ca10 <core::slice::memchr::memchr>
   34940:	b1 03                	mov    $0x3,%cl
   34942:	48 83 f8 01          	cmp    $0x1,%rax
   34946:	74 1a                	je     34962 <oriole_expat::dispatch+0xb52>
   34948:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3494f:	00 
   34950:	31 f6                	xor    %esi,%esi
   34952:	ff 15 d8 20 0b 00    	call   *0xb20d8(%rip)        # e6a30 <_GLOBAL_OFFSET_TABLE_+0x188>
   34958:	89 c1                	mov    %eax,%ecx
   3495a:	3c ff                	cmp    $0xff,%al
   3495c:	0f 84 13 39 00 00    	je     38275 <oriole_expat::dispatch+0x4465>
   34962:	89 cb                	mov    %ecx,%ebx
   34964:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   3496b:	00 
   3496c:	48 85 c9             	test   %rcx,%rcx
   3496f:	74 72                	je     349e3 <oriole_expat::dispatch+0xbd3>
   34971:	b0 01                	mov    $0x1,%al
   34973:	89 44 24 48          	mov    %eax,0x48(%rsp)
   34977:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
   3497e:	00 
   3497f:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34986:	00 
   34987:	ba 01 00 00 00       	mov    $0x1,%edx
   3498c:	b0 01                	mov    $0x1,%al
   3498e:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   34992:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   34999:	00 
   3499a:	b0 01                	mov    $0x1,%al
   3499c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   349a0:	b0 01                	mov    $0x1,%al
   349a2:	89 44 24 14          	mov    %eax,0x14(%rsp)
   349a6:	b0 01                	mov    $0x1,%al
   349a8:	89 44 24 10          	mov    %eax,0x10(%rsp)
   349ac:	b0 01                	mov    $0x1,%al
   349ae:	89 44 24 40          	mov    %eax,0x40(%rsp)
   349b2:	b0 01                	mov    $0x1,%al
   349b4:	89 44 24 08          	mov    %eax,0x8(%rsp)
   349b8:	b0 01                	mov    $0x1,%al
   349ba:	89 44 24 04          	mov    %eax,0x4(%rsp)
   349be:	b0 01                	mov    $0x1,%al
   349c0:	89 44 24 28          	mov    %eax,0x28(%rsp)
   349c4:	b0 01                	mov    $0x1,%al
   349c6:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   349cb:	b0 01                	mov    $0x1,%al
   349cd:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   349d1:	41 b6 01             	mov    $0x1,%r14b
   349d4:	41 b4 01             	mov    $0x1,%r12b
   349d7:	41 b7 01             	mov    $0x1,%r15b
   349da:	41 b5 01             	mov    $0x1,%r13b
   349dd:	ff 15 fd 1f 0b 00    	call   *0xb1ffd(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   349e3:	b0 01                	mov    $0x1,%al
   349e5:	89 44 24 48          	mov    %eax,0x48(%rsp)
   349e9:	b0 01                	mov    $0x1,%al
   349eb:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   349ef:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   349f6:	00 
   349f7:	b0 01                	mov    $0x1,%al
   349f9:	89 44 24 38          	mov    %eax,0x38(%rsp)
   349fd:	b0 01                	mov    $0x1,%al
   349ff:	89 44 24 14          	mov    %eax,0x14(%rsp)
   34a03:	b0 01                	mov    $0x1,%al
   34a05:	89 44 24 10          	mov    %eax,0x10(%rsp)
   34a09:	b0 01                	mov    $0x1,%al
   34a0b:	89 44 24 40          	mov    %eax,0x40(%rsp)
   34a0f:	b0 01                	mov    $0x1,%al
   34a11:	89 44 24 08          	mov    %eax,0x8(%rsp)
   34a15:	b0 01                	mov    $0x1,%al
   34a17:	89 44 24 04          	mov    %eax,0x4(%rsp)
   34a1b:	b0 01                	mov    $0x1,%al
   34a1d:	89 44 24 28          	mov    %eax,0x28(%rsp)
   34a21:	b0 01                	mov    $0x1,%al
   34a23:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   34a28:	b0 01                	mov    $0x1,%al
   34a2a:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   34a2e:	e9 c1 43 00 00       	jmp    38df4 <oriole_expat::dispatch+0x4fe4>
   34a33:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34a37:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
   34a3e:	00 
   34a3f:	0f 10 00             	movups (%rax),%xmm0
   34a42:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34a46:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   34a4a:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   34a51:	00 
   34a52:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   34a59:	00 
   34a5a:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   34a61:	00 
   34a62:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
   34a69:	00 
   34a6a:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   34a71:	00 
   34a72:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
   34a79:	00 
   34a7a:	0f 28 8c 24 70 01 00 	movaps 0x170(%rsp),%xmm1
   34a81:	00 
   34a82:	0f 28 94 24 80 01 00 	movaps 0x180(%rsp),%xmm2
   34a89:	00 
   34a8a:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   34a91:	00 
   34a92:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   34a97:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   34a9c:	48 85 ed             	test   %rbp,%rbp
   34a9f:	0f 84 d8 1e 00 00    	je     3697d <oriole_expat::dispatch+0x2b6d>
   34aa5:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34aa9:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
   34ab0:	00 
   34ab1:	0f 10 00             	movups (%rax),%xmm0
   34ab4:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34ab8:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   34abc:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   34ac3:	00 
   34ac4:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   34acb:	00 
   34acc:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   34ad3:	00 
   34ad4:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34adb:	00 
   34adc:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   34ae3:	00 
   34ae4:	ff 15 c6 1f 0b 00    	call   *0xb1fc6(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   34aea:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   34af1:	00 
   34af2:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   34af9:	00 00 
   34afb:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   34aff:	0f 84 b4 2e 00 00    	je     379b9 <oriole_expat::dispatch+0x3ba9>
   34b05:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   34b0c:	00 
   34b0d:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   34b14:	00 
   34b15:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   34b1c:	00 
   34b1d:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   34b24:	00 
   34b25:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   34b2c:	00 
   34b2d:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   34b34:	00 
   34b35:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   34b3c:	00 
   34b3d:	44 88 ac 24 a8 00 00 	mov    %r13b,0xa8(%rsp)
   34b44:	00 
   34b45:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   34b4c:	00 
   34b4d:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   34b54:	00 
   34b55:	0f 10 43 08          	movups 0x8(%rbx),%xmm0
   34b59:	0f 10 4b 18          	movups 0x18(%rbx),%xmm1
   34b5d:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   34b64:	00 
   34b65:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   34b6c:	00 
   34b6d:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34b74:	00 
   34b75:	48 8d 8c 24 40 03 00 	lea    0x340(%rsp),%rcx
   34b7c:	00 
   34b7d:	e8 ee 77 00 00       	call   3c370 <oriole_expat::content_model::allocate>
   34b82:	83 bc 24 20 02 00 00 	cmpl   $0x1,0x220(%rsp)
   34b89:	01 
   34b8a:	0f 85 e7 2f 00 00    	jne    37b77 <oriole_expat::dispatch+0x3d67>
   34b90:	8b 84 24 24 02 00 00 	mov    0x224(%rsp),%eax
   34b97:	89 83 14 0a 00 00    	mov    %eax,0xa14(%rbx)
   34b9d:	89 83 10 0a 00 00    	mov    %eax,0xa10(%rbx)
   34ba3:	e9 e6 2f 00 00       	jmp    37b8e <oriole_expat::dispatch+0x3d7e>
   34ba8:	0f 10 00             	movups (%rax),%xmm0
   34bab:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34baf:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   34bb6:	00 
   34bb7:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   34bbe:	00 
   34bbf:	4c 8b b4 24 48 01 00 	mov    0x148(%rsp),%r14
   34bc6:	00 
   34bc7:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   34bce:	00 
   34bcf:	ba a8 00 00 00       	mov    $0xa8,%edx
   34bd4:	4c 89 f6             	mov    %r14,%rsi
   34bd7:	ff 15 eb 26 0b 00    	call   *0xb26eb(%rip)        # e72c8 <memcpy@GLIBC_2.14>
   34bdd:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   34be4:	00 
   34be5:	ba 08 00 00 00       	mov    $0x8,%edx
   34bea:	b9 a8 00 00 00       	mov    $0xa8,%ecx
   34bef:	4c 89 f6             	mov    %r14,%rsi
   34bf2:	ff 15 e8 1d 0b 00    	call   *0xb1de8(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   34bf8:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34bff:	00 
   34c00:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   34c07:	00 
   34c08:	ba a8 00 00 00       	mov    $0xa8,%edx
   34c0d:	ff 15 b5 26 0b 00    	call   *0xb26b5(%rip)        # e72c8 <memcpy@GLIBC_2.14>
   34c13:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   34c1a:	00 
   34c1b:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   34c22:	00 
   34c23:	0f 10 84 24 20 02 00 	movups 0x220(%rsp),%xmm0
   34c2a:	00 
   34c2b:	0f 10 8c 24 30 02 00 	movups 0x230(%rsp),%xmm1
   34c32:	00 
   34c33:	0f 10 94 24 40 02 00 	movups 0x240(%rsp),%xmm2
   34c3a:	00 
   34c3b:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   34c42:	00 
   34c43:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   34c4a:	00 
   34c4b:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   34c52:	00 
   34c53:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
   34c5a:	00 
   34c5b:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   34c62:	00 
   34c63:	0f 10 84 24 78 02 00 	movups 0x278(%rsp),%xmm0
   34c6a:	00 
   34c6b:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   34c72:	00 
   34c73:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   34c7a:	00 
   34c7b:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
   34c82:	00 
   34c83:	0f 10 84 24 58 02 00 	movups 0x258(%rsp),%xmm0
   34c8a:	00 
   34c8b:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   34c92:	00 
   34c93:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
   34c9a:	00 
   34c9b:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   34ca2:	00 
   34ca3:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   34caa:	00 
   34cab:	0f 10 8c 24 a0 02 00 	movups 0x2a0(%rsp),%xmm1
   34cb2:	00 
   34cb3:	0f 10 94 24 b0 02 00 	movups 0x2b0(%rsp),%xmm2
   34cba:	00 
   34cbb:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   34cc2:	00 
   34cc3:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   34cca:	00 
   34ccb:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   34cd2:	00 
   34cd3:	4c 8b a4 24 80 05 00 	mov    0x580(%rsp),%r12
   34cda:	00 
   34cdb:	4d 85 e4             	test   %r12,%r12
   34cde:	0f 84 c6 21 00 00    	je     36eaa <oriole_expat::dispatch+0x309a>
   34ce4:	4c 8b b3 08 0b 00 00 	mov    0xb08(%rbx),%r14
   34ceb:	4d 85 f6             	test   %r14,%r14
   34cee:	4c 0f 44 f3          	cmove  %rbx,%r14
   34cf2:	40 b5 01             	mov    $0x1,%bpl
   34cf5:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   34cfc:	00 
   34cfd:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
   34d04:	00 
   34d05:	e8 b6 e0 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   34d0a:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   34d11:	00 
   34d12:	44 0f b6 ac 24 48 03 	movzbl 0x348(%rsp),%r13d
   34d19:	00 00 
   34d1b:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   34d1f:	0f 85 bf 2b 00 00    	jne    378e4 <oriole_expat::dispatch+0x3ad4>
   34d25:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   34d2c:	00 
   34d2d:	e8 fe a5 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   34d32:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   34d39:	00 
   34d3a:	e8 f1 a5 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   34d3f:	e9 67 3b 00 00       	jmp    388ab <oriole_expat::dispatch+0x4a9b>
   34d44:	0f 10 00             	movups (%rax),%xmm0
   34d47:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34d4b:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   34d52:	00 
   34d53:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   34d5a:	00 
   34d5b:	4c 8b bc 24 48 01 00 	mov    0x148(%rsp),%r15
   34d62:	00 
   34d63:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   34d6a:	00 
   34d6b:	ba a8 00 00 00       	mov    $0xa8,%edx
   34d70:	4c 89 fe             	mov    %r15,%rsi
   34d73:	ff 15 4f 25 0b 00    	call   *0xb254f(%rip)        # e72c8 <memcpy@GLIBC_2.14>
   34d79:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   34d80:	00 
   34d81:	ba 08 00 00 00       	mov    $0x8,%edx
   34d86:	b9 a8 00 00 00       	mov    $0xa8,%ecx
   34d8b:	4c 89 fe             	mov    %r15,%rsi
   34d8e:	ff 15 4c 1c 0b 00    	call   *0xb1c4c(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   34d94:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34d9b:	00 
   34d9c:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   34da3:	00 
   34da4:	ba a8 00 00 00       	mov    $0xa8,%edx
   34da9:	ff 15 19 25 0b 00    	call   *0xb2519(%rip)        # e72c8 <memcpy@GLIBC_2.14>
   34daf:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   34db6:	00 
   34db7:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   34dbe:	00 
   34dbf:	0f 10 84 24 20 02 00 	movups 0x220(%rsp),%xmm0
   34dc6:	00 
   34dc7:	0f 10 8c 24 30 02 00 	movups 0x230(%rsp),%xmm1
   34dce:	00 
   34dcf:	0f 10 94 24 40 02 00 	movups 0x240(%rsp),%xmm2
   34dd6:	00 
   34dd7:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   34dde:	00 
   34ddf:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   34de6:	00 
   34de7:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   34dee:	00 
   34def:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
   34df6:	00 
   34df7:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   34dfe:	00 
   34dff:	0f 10 84 24 78 02 00 	movups 0x278(%rsp),%xmm0
   34e06:	00 
   34e07:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   34e0e:	00 
   34e0f:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   34e16:	00 
   34e17:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
   34e1e:	00 
   34e1f:	0f 10 84 24 58 02 00 	movups 0x258(%rsp),%xmm0
   34e26:	00 
   34e27:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   34e2e:	00 
   34e2f:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
   34e36:	00 
   34e37:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   34e3e:	00 
   34e3f:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   34e46:	00 
   34e47:	0f 10 8c 24 a0 02 00 	movups 0x2a0(%rsp),%xmm1
   34e4e:	00 
   34e4f:	0f 10 94 24 b0 02 00 	movups 0x2b0(%rsp),%xmm2
   34e56:	00 
   34e57:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   34e5e:	00 
   34e5f:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   34e66:	00 
   34e67:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   34e6e:	00 
   34e6f:	48 83 bc 24 88 04 00 	cmpq   $0x0,0x488(%rsp)
   34e76:	00 00 
   34e78:	0f 84 e9 20 00 00    	je     36f67 <oriole_expat::dispatch+0x3157>
   34e7e:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
   34e85:	00 
   34e86:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   34e8d:	00 
   34e8e:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
   34e95:	00 
   34e96:	0f 28 8c 24 b0 01 00 	movaps 0x1b0(%rsp),%xmm1
   34e9d:	00 
   34e9e:	0f 28 94 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm2
   34ea5:	00 
   34ea6:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   34ead:	00 
   34eae:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   34eb5:	00 
   34eb6:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   34ebd:	00 
   34ebe:	40 b5 01             	mov    $0x1,%bpl
   34ec1:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   34ec8:	00 
   34ec9:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   34ed0:	00 
   34ed1:	ff 15 d9 1b 0b 00    	call   *0xb1bd9(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   34ed7:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   34ede:	00 
   34edf:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   34ee6:	00 00 
   34ee8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   34eec:	0f 84 2a 2c 00 00    	je     37b1c <oriole_expat::dispatch+0x3d0c>
   34ef2:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   34ef9:	00 
   34efa:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   34f01:	00 
   34f02:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   34f09:	00 
   34f0a:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   34f11:	00 
   34f12:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   34f17:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   34f1c:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   34f21:	44 88 6c 24 68       	mov    %r13b,0x68(%rsp)
   34f26:	83 bc 24 08 05 00 00 	cmpl   $0xffffffff,0x508(%rsp)
   34f2d:	ff 
   34f2e:	0f 84 af 2c 00 00    	je     37be3 <oriole_expat::dispatch+0x3dd3>
   34f34:	4c 8b a4 24 28 05 00 	mov    0x528(%rsp),%r12
   34f3b:	00 
   34f3c:	e9 a5 2c 00 00       	jmp    37be6 <oriole_expat::dispatch+0x3dd6>
   34f41:	48 83 bc 24 88 04 00 	cmpq   $0x0,0x488(%rsp)
   34f48:	00 00 
   34f4a:	e9 db 07 00 00       	jmp    3572a <oriole_expat::dispatch+0x191a>
   34f4f:	48 89 bc 24 60 04 00 	mov    %rdi,0x460(%rsp)
   34f56:	00 
   34f57:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34f5b:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   34f62:	00 
   34f63:	0f 10 00             	movups (%rax),%xmm0
   34f66:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34f6a:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   34f6e:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   34f75:	00 
   34f76:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   34f7b:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   34f80:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
   34f87:	00 
   34f88:	0f 28 8c 24 70 01 00 	movaps 0x170(%rsp),%xmm1
   34f8f:	00 
   34f90:	0f 28 94 24 80 01 00 	movaps 0x180(%rsp),%xmm2
   34f97:	00 
   34f98:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
   34f9f:	00 
   34fa0:	4c 8b ac 24 90 01 00 	mov    0x190(%rsp),%r13
   34fa7:	00 
   34fa8:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
   34faf:	00 
   34fb0:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   34fb7:	00 
   34fb8:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   34fbf:	00 
   34fc0:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
   34fc7:	00 
   34fc8:	4d 85 ed             	test   %r13,%r13
   34fcb:	0f 84 59 1a 00 00    	je     36a2a <oriole_expat::dispatch+0x2c1a>
   34fd1:	44 89 e9             	mov    %r13d,%ecx
   34fd4:	83 e1 03             	and    $0x3,%ecx
   34fd7:	49 83 fd 04          	cmp    $0x4,%r13
   34fdb:	0f 83 8f 25 00 00    	jae    37570 <oriole_expat::dispatch+0x3760>
   34fe1:	31 d2                	xor    %edx,%edx
   34fe3:	31 c0                	xor    %eax,%eax
   34fe5:	e9 d1 25 00 00       	jmp    375bb <oriole_expat::dispatch+0x37ab>
   34fea:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34fee:	48 89 8c 24 10 02 00 	mov    %rcx,0x210(%rsp)
   34ff5:	00 
   34ff6:	0f 10 00             	movups (%rax),%xmm0
   34ff9:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34ffd:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   35001:	0f 29 94 24 00 02 00 	movaps %xmm2,0x200(%rsp)
   35008:	00 
   35009:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   35010:	00 
   35011:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   35018:	00 
   35019:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
   35020:	00 
   35021:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
   35028:	00 
   35029:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
   35030:	00 
   35031:	0f 28 8c 24 70 01 00 	movaps 0x170(%rsp),%xmm1
   35038:	00 
   35039:	0f 28 94 24 80 01 00 	movaps 0x180(%rsp),%xmm2
   35040:	00 
   35041:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   35048:	00 
   35049:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   35050:	00 
   35051:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   35058:	00 
   35059:	4d 85 c0             	test   %r8,%r8
   3505c:	0f 84 cf 19 00 00    	je     36a31 <oriole_expat::dispatch+0x2c21>
   35062:	4d 89 c6             	mov    %r8,%r14
   35065:	48 8b 48 30          	mov    0x30(%rax),%rcx
   35069:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
   35070:	00 
   35071:	0f 10 00             	movups (%rax),%xmm0
   35074:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   35078:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   3507c:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   35083:	00 
   35084:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   3508b:	00 
   3508c:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   35093:	00 
   35094:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3509b:	00 
   3509c:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   350a3:	00 
   350a4:	ff 15 06 1a 0b 00    	call   *0xb1a06(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   350aa:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   350b1:	00 
   350b2:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   350b9:	00 00 
   350bb:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   350bf:	0f 84 7b 29 00 00    	je     37a40 <oriole_expat::dispatch+0x3c30>
   350c5:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   350cc:	00 
   350cd:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   350d4:	00 
   350d5:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   350dc:	00 
   350dd:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   350e4:	00 
   350e5:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   350ea:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   350ef:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   350f4:	44 88 6c 24 68       	mov    %r13b,0x68(%rsp)
   350f9:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
   35100:	00 
   35101:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   35108:	00 
   35109:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   35110:	00 
   35111:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   35118:	00 
   35119:	0f 28 8c 24 f0 00 00 	movaps 0xf0(%rsp),%xmm1
   35120:	00 
   35121:	0f 28 94 24 00 01 00 	movaps 0x100(%rsp),%xmm2
   35128:	00 
   35129:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   35130:	00 
   35131:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   35138:	00 
   35139:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   35140:	00 
   35141:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35148:	00 
   35149:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   35150:	00 
   35151:	ff 15 59 19 0b 00    	call   *0xb1959(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   35157:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   3515e:	00 
   3515f:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   35166:	00 00 
   35168:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3516c:	0f 84 8c 2f 00 00    	je     380fe <oriole_expat::dispatch+0x42ee>
   35172:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   35179:	00 
   3517a:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   35181:	00 
   35182:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   35189:	00 
   3518a:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   35191:	00 
   35192:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   35199:	00 
   3519a:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   351a1:	00 
   351a2:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   351a9:	00 
   351aa:	44 88 ac 24 a8 00 00 	mov    %r13b,0xa8(%rsp)
   351b1:	00 
   351b2:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
   351b9:	00 
   351ba:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   351bf:	4c 89 fe             	mov    %r15,%rsi
   351c2:	41 ff d6             	call   *%r14
   351c5:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   351cc:	00 
   351cd:	48 85 c9             	test   %rcx,%rcx
   351d0:	74 1b                	je     351ed <oriole_expat::dispatch+0x13dd>
   351d2:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   351d9:	00 
   351da:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   351e1:	00 
   351e2:	ba 01 00 00 00       	mov    $0x1,%edx
   351e7:	ff 15 f3 17 0b 00    	call   *0xb17f3(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   351ed:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   351f4:	00 
   351f5:	48 85 c9             	test   %rcx,%rcx
   351f8:	74 18                	je     35212 <oriole_expat::dispatch+0x1402>
   351fa:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   35201:	00 
   35202:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   35207:	ba 01 00 00 00       	mov    $0x1,%edx
   3520c:	ff 15 ce 17 0b 00    	call   *0xb17ce(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   35212:	40 b5 01             	mov    $0x1,%bpl
   35215:	e9 24 30 00 00       	jmp    3823e <oriole_expat::dispatch+0x442e>
   3521a:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3521e:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
   35225:	00 
   35226:	0f 10 00             	movups (%rax),%xmm0
   35229:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   3522d:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   35231:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   35238:	00 
   35239:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   35240:	00 
   35241:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   35248:	00 
   35249:	4c 8b b4 24 b8 05 00 	mov    0x5b8(%rsp),%r14
   35250:	00 
   35251:	4d 85 f6             	test   %r14,%r14
   35254:	0f 84 89 18 00 00    	je     36ae3 <oriole_expat::dispatch+0x2cd3>
   3525a:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   35261:	00 
   35262:	ff 15 80 18 0b 00    	call   *0xb1880(%rip)        # e6ae8 <_GLOBAL_OFFSET_TABLE_+0x240>
   35268:	48 89 c3             	mov    %rax,%rbx
   3526b:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   35272:	00 
   35273:	ff 15 6f 18 0b 00    	call   *0xb186f(%rip)        # e6ae8 <_GLOBAL_OFFSET_TABLE_+0x240>
   35279:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   3527e:	48 89 de             	mov    %rbx,%rsi
   35281:	41 ff d6             	call   *%r14
   35284:	b0 01                	mov    $0x1,%al
   35286:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3528a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   35291:	00 
   35292:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   35299:	00 
   3529a:	b0 01                	mov    $0x1,%al
   3529c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   352a0:	b0 01                	mov    $0x1,%al
   352a2:	89 44 24 30          	mov    %eax,0x30(%rsp)
   352a6:	b0 01                	mov    $0x1,%al
   352a8:	89 44 24 14          	mov    %eax,0x14(%rsp)
   352ac:	b0 01                	mov    $0x1,%al
   352ae:	89 44 24 10          	mov    %eax,0x10(%rsp)
   352b2:	b0 01                	mov    $0x1,%al
   352b4:	89 44 24 40          	mov    %eax,0x40(%rsp)
   352b8:	b0 01                	mov    $0x1,%al
   352ba:	89 44 24 08          	mov    %eax,0x8(%rsp)
   352be:	b0 01                	mov    $0x1,%al
   352c0:	89 44 24 04          	mov    %eax,0x4(%rsp)
   352c4:	b0 01                	mov    $0x1,%al
   352c6:	89 44 24 28          	mov    %eax,0x28(%rsp)
   352ca:	b0 01                	mov    $0x1,%al
   352cc:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   352d1:	b0 01                	mov    $0x1,%al
   352d3:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   352d7:	41 b6 01             	mov    $0x1,%r14b
   352da:	41 b4 01             	mov    $0x1,%r12b
   352dd:	41 b7 01             	mov    $0x1,%r15b
   352e0:	41 b5 01             	mov    $0x1,%r13b
   352e3:	e8 98 cf ff ff       	call   32280 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   352e8:	b0 01                	mov    $0x1,%al
   352ea:	89 44 24 14          	mov    %eax,0x14(%rsp)
   352ee:	b0 01                	mov    $0x1,%al
   352f0:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   352f4:	b0 01                	mov    $0x1,%al
   352f6:	89 44 24 30          	mov    %eax,0x30(%rsp)
   352fa:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   35301:	00 
   35302:	e9 ca 06 00 00       	jmp    359d1 <oriole_expat::dispatch+0x1bc1>
   35307:	48 85 ed             	test   %rbp,%rbp
   3530a:	e9 1b 04 00 00       	jmp    3572a <oriole_expat::dispatch+0x191a>
   3530f:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   35316:	00 
   35317:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   3531e:	00 
   3531f:	0f 28 84 24 20 01 00 	movaps 0x120(%rsp),%xmm0
   35326:	00 
   35327:	0f 28 8c 24 30 01 00 	movaps 0x130(%rsp),%xmm1
   3532e:	00 
   3532f:	0f 28 94 24 40 01 00 	movaps 0x140(%rsp),%xmm2
   35336:	00 
   35337:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   3533e:	00 
   3533f:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   35346:	00 
   35347:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   3534e:	00 
   3534f:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
   35356:	00 
   35357:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   3535e:	00 
   3535f:	0f 10 84 24 78 01 00 	movups 0x178(%rsp),%xmm0
   35366:	00 
   35367:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   3536e:	00 
   3536f:	0f 10 84 24 68 01 00 	movups 0x168(%rsp),%xmm0
   35376:	00 
   35377:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   3537c:	0f 10 84 24 58 01 00 	movups 0x158(%rsp),%xmm0
   35383:	00 
   35384:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   35389:	4c 8b b4 24 a0 05 00 	mov    0x5a0(%rsp),%r14
   35390:	00 
   35391:	4d 85 f6             	test   %r14,%r14
   35394:	0f 84 08 18 00 00    	je     36ba2 <oriole_expat::dispatch+0x2d92>
   3539a:	0f b6 ac 24 90 01 00 	movzbl 0x190(%rsp),%ebp
   353a1:	00 
   353a2:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
   353a9:	00 
   353aa:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   353b1:	00 
   353b2:	0f 28 84 24 20 01 00 	movaps 0x120(%rsp),%xmm0
   353b9:	00 
   353ba:	0f 28 8c 24 30 01 00 	movaps 0x130(%rsp),%xmm1
   353c1:	00 
   353c2:	0f 28 94 24 40 01 00 	movaps 0x140(%rsp),%xmm2
   353c9:	00 
   353ca:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   353d1:	00 
   353d2:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   353d9:	00 
   353da:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   353e1:	00 
   353e2:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   353e9:	00 
   353ea:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   353f1:	00 
   353f2:	ff 15 b8 16 0b 00    	call   *0xb16b8(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   353f8:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   353ff:	00 
   35400:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   35407:	00 00 
   35409:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3540d:	0f 84 5e 26 00 00    	je     37a71 <oriole_expat::dispatch+0x3c61>
   35413:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   3541a:	00 
   3541b:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   35422:	00 
   35423:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   3542a:	00 
   3542b:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   35432:	00 
   35433:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   3543a:	00 
   3543b:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   35442:	00 
   35443:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   3544a:	00 
   3544b:	44 88 ac 24 a8 00 00 	mov    %r13b,0xa8(%rsp)
   35452:	00 
   35453:	4c 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%r15
   3545a:	00 
   3545b:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   35462:	00 
   35463:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
   35468:	e8 53 d9 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   3546d:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   35474:	00 
   35475:	44 0f b6 ac 24 48 03 	movzbl 0x348(%rsp),%r13d
   3547c:	00 00 
   3547e:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   35482:	0f 85 cd 27 00 00    	jne    37c55 <oriole_expat::dispatch+0x3e45>
   35488:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   3548f:	00 
   35490:	48 85 c9             	test   %rcx,%rcx
   35493:	0f 84 e2 25 00 00    	je     37a7b <oriole_expat::dispatch+0x3c6b>
   35499:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   354a0:	00 
   354a1:	ba 01 00 00 00       	mov    $0x1,%edx
   354a6:	4c 89 fe             	mov    %r15,%rsi
   354a9:	ff 15 31 15 0b 00    	call   *0xb1531(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   354af:	e9 c7 25 00 00       	jmp    37a7b <oriole_expat::dispatch+0x3c6b>
   354b4:	48 83 bc 24 18 02 00 	cmpq   $0x0,0x218(%rsp)
   354bb:	00 00 
   354bd:	e9 68 02 00 00       	jmp    3572a <oriole_expat::dispatch+0x191a>
   354c2:	48 8b 48 30          	mov    0x30(%rax),%rcx
   354c6:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
   354cd:	00 
   354ce:	0f 10 00             	movups (%rax),%xmm0
   354d1:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   354d5:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   354d9:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   354e0:	00 
   354e1:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   354e8:	00 
   354e9:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   354f0:	00 
   354f1:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
   354f8:	00 
   354f9:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   35500:	00 
   35501:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
   35508:	00 
   35509:	0f 28 8c 24 70 01 00 	movaps 0x170(%rsp),%xmm1
   35510:	00 
   35511:	0f 28 94 24 80 01 00 	movaps 0x180(%rsp),%xmm2
   35518:	00 
   35519:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   35520:	00 
   35521:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   35526:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   3552b:	4c 8b b4 24 c8 05 00 	mov    0x5c8(%rsp),%r14
   35532:	00 
   35533:	4d 85 f6             	test   %r14,%r14
   35536:	0f 84 fa 16 00 00    	je     36c36 <oriole_expat::dispatch+0x2e26>
   3553c:	48 8b 48 30          	mov    0x30(%rax),%rcx
   35540:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
   35547:	00 
   35548:	0f 10 00             	movups (%rax),%xmm0
   3554b:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   3554f:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   35553:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   3555a:	00 
   3555b:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   35562:	00 
   35563:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   3556a:	00 
   3556b:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35572:	00 
   35573:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3557a:	00 
   3557b:	e8 40 d8 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   35580:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   35587:	00 
   35588:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   3558f:	00 00 
   35591:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   35595:	0f 85 50 22 00 00    	jne    377eb <oriole_expat::dispatch+0x39db>
   3559b:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   355a0:	e8 8b 9d ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   355a5:	e9 8f 28 00 00       	jmp    37e39 <oriole_expat::dispatch+0x4029>
   355aa:	48 8b 48 30          	mov    0x30(%rax),%rcx
   355ae:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   355b5:	00 
   355b6:	0f 10 00             	movups (%rax),%xmm0
   355b9:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   355bd:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   355c1:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   355c8:	00 
   355c9:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   355ce:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   355d3:	4d 85 e4             	test   %r12,%r12
   355d6:	0f 84 cd 16 00 00    	je     36ca9 <oriole_expat::dispatch+0x2e99>
   355dc:	4c 89 e3             	mov    %r12,%rbx
   355df:	48 8b 48 30          	mov    0x30(%rax),%rcx
   355e3:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
   355ea:	00 
   355eb:	0f 10 00             	movups (%rax),%xmm0
   355ee:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   355f2:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   355f6:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   355fd:	00 
   355fe:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   35605:	00 
   35606:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   3560d:	00 
   3560e:	b0 01                	mov    $0x1,%al
   35610:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   35614:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   3561b:	00 00 
   3561d:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35624:	00 
   35625:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3562c:	00 
   3562d:	b0 01                	mov    $0x1,%al
   3562f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   35633:	b0 01                	mov    $0x1,%al
   35635:	89 44 24 48          	mov    %eax,0x48(%rsp)
   35639:	b0 01                	mov    $0x1,%al
   3563b:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3563f:	b0 01                	mov    $0x1,%al
   35641:	89 44 24 14          	mov    %eax,0x14(%rsp)
   35645:	b0 01                	mov    $0x1,%al
   35647:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3564b:	b0 01                	mov    $0x1,%al
   3564d:	89 44 24 40          	mov    %eax,0x40(%rsp)
   35651:	b0 01                	mov    $0x1,%al
   35653:	89 44 24 08          	mov    %eax,0x8(%rsp)
   35657:	b0 01                	mov    $0x1,%al
   35659:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3565d:	b0 01                	mov    $0x1,%al
   3565f:	89 44 24 28          	mov    %eax,0x28(%rsp)
   35663:	b0 01                	mov    $0x1,%al
   35665:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   35669:	41 b6 01             	mov    $0x1,%r14b
   3566c:	41 b4 01             	mov    $0x1,%r12b
   3566f:	41 b7 01             	mov    $0x1,%r15b
   35672:	41 b5 01             	mov    $0x1,%r13b
   35675:	e8 46 d7 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   3567a:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   35681:	00 
   35682:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   35689:	00 00 
   3568b:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   3568f:	0f 85 ad 21 00 00    	jne    37842 <oriole_expat::dispatch+0x3a32>
   35695:	b0 01                	mov    $0x1,%al
   35697:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3569b:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   356a2:	00 00 
   356a4:	b0 01                	mov    $0x1,%al
   356a6:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   356aa:	b0 01                	mov    $0x1,%al
   356ac:	89 44 24 30          	mov    %eax,0x30(%rsp)
   356b0:	b0 01                	mov    $0x1,%al
   356b2:	89 44 24 48          	mov    %eax,0x48(%rsp)
   356b6:	b0 01                	mov    $0x1,%al
   356b8:	89 44 24 38          	mov    %eax,0x38(%rsp)
   356bc:	b0 01                	mov    $0x1,%al
   356be:	89 44 24 14          	mov    %eax,0x14(%rsp)
   356c2:	b0 01                	mov    $0x1,%al
   356c4:	89 44 24 40          	mov    %eax,0x40(%rsp)
   356c8:	b0 01                	mov    $0x1,%al
   356ca:	89 44 24 08          	mov    %eax,0x8(%rsp)
   356ce:	b0 01                	mov    $0x1,%al
   356d0:	89 44 24 04          	mov    %eax,0x4(%rsp)
   356d4:	b0 01                	mov    $0x1,%al
   356d6:	89 44 24 28          	mov    %eax,0x28(%rsp)
   356da:	e9 11 32 00 00       	jmp    388f0 <oriole_expat::dispatch+0x4ae0>
   356df:	48 8b 84 24 b0 05 00 	mov    0x5b0(%rsp),%rax
   356e6:	00 
   356e7:	48 85 c0             	test   %rax,%rax
   356ea:	0f 84 1f 16 00 00    	je     36d0f <oriole_expat::dispatch+0x2eff>
   356f0:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   356f5:	ff d0                	call   *%rax
   356f7:	c6 83 60 0b 00 00 00 	movb   $0x0,0xb60(%rbx)
   356fe:	b0 01                	mov    $0x1,%al
   35700:	89 44 24 10          	mov    %eax,0x10(%rsp)
   35704:	b0 01                	mov    $0x1,%al
   35706:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3570a:	b0 01                	mov    $0x1,%al
   3570c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   35710:	b0 01                	mov    $0x1,%al
   35712:	89 44 24 48          	mov    %eax,0x48(%rsp)
   35716:	b0 01                	mov    $0x1,%al
   35718:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3571c:	b0 01                	mov    $0x1,%al
   3571e:	89 44 24 14          	mov    %eax,0x14(%rsp)
   35722:	e9 ae 16 00 00       	jmp    36dd5 <oriole_expat::dispatch+0x2fc5>
   35727:	4d 85 d2             	test   %r10,%r10
   3572a:	40 0f 95 c5          	setne  %bpl
   3572e:	b0 01                	mov    $0x1,%al
   35730:	b1 01                	mov    $0x1,%cl
   35732:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   35736:	b1 01                	mov    $0x1,%cl
   35738:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   3573c:	b1 01                	mov    $0x1,%cl
   3573e:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   35742:	b1 01                	mov    $0x1,%cl
   35744:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   35748:	b1 01                	mov    $0x1,%cl
   3574a:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   3574e:	b1 01                	mov    $0x1,%cl
   35750:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   35754:	b1 01                	mov    $0x1,%cl
   35756:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   3575a:	b1 01                	mov    $0x1,%cl
   3575c:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   35760:	b1 01                	mov    $0x1,%cl
   35762:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   35766:	b1 01                	mov    $0x1,%cl
   35768:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
   3576c:	b1 01                	mov    $0x1,%cl
   3576e:	89 4c 24 20          	mov    %ecx,0x20(%rsp)
   35772:	b1 01                	mov    $0x1,%cl
   35774:	89 4c 24 1c          	mov    %ecx,0x1c(%rsp)
   35778:	b1 01                	mov    $0x1,%cl
   3577a:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   3577e:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   35782:	b1 01                	mov    $0x1,%cl
   35784:	b2 01                	mov    $0x1,%dl
   35786:	40 84 ed             	test   %bpl,%bpl
   35789:	0f 85 7a 16 00 00    	jne    36e09 <oriole_expat::dispatch+0x2ff9>
   3578f:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   35796:	0f 85 8d 1d 00 00    	jne    37529 <oriole_expat::dispatch+0x3719>
   3579c:	48 83 bb c0 09 00 00 	cmpq   $0x0,0x9c0(%rbx)
   357a3:	00 
   357a4:	0f 84 7f 1d 00 00    	je     37529 <oriole_expat::dispatch+0x3719>
   357aa:	48 8b 93 50 05 00 00 	mov    0x550(%rbx),%rdx
   357b1:	48 85 d2             	test   %rdx,%rdx
   357b4:	0f 84 ca 00 00 00    	je     35884 <oriole_expat::dispatch+0x1a74>
   357ba:	48 8b b3 40 05 00 00 	mov    0x540(%rbx),%rsi
   357c1:	0f 10 43 08          	movups 0x8(%rbx),%xmm0
   357c5:	0f 10 4b 18          	movups 0x18(%rbx),%xmm1
   357c9:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   357ce:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   357d3:	b0 01                	mov    $0x1,%al
   357d5:	89 44 24 28          	mov    %eax,0x28(%rsp)
   357d9:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   357e0:	00 
   357e1:	48 8d 4c 24 60       	lea    0x60(%rsp),%rcx
   357e6:	b0 01                	mov    $0x1,%al
   357e8:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   357ed:	44 8b 74 24 24       	mov    0x24(%rsp),%r14d
   357f2:	44 8b 64 24 18       	mov    0x18(%rsp),%r12d
   357f7:	44 8b 7c 24 20       	mov    0x20(%rsp),%r15d
   357fc:	44 8b 6c 24 1c       	mov    0x1c(%rsp),%r13d
   35801:	ff 15 01 12 0b 00    	call   *0xb1201(%rip)        # e6a08 <_GLOBAL_OFFSET_TABLE_+0x160>
   35807:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   3580e:	00 
   3580f:	44 0f b6 ac 24 48 03 	movzbl 0x348(%rsp),%r13d
   35816:	00 00 
   35818:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   3581f:	00 
   35820:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   35827:	00 
   35828:	0f 10 84 24 59 03 00 	movups 0x359(%rsp),%xmm0
   3582f:	00 
   35830:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
   35837:	00 
   35838:	0f 10 84 24 68 03 00 	movups 0x368(%rsp),%xmm0
   3583f:	00 
   35840:	0f 11 84 24 3f 02 00 	movups %xmm0,0x23f(%rsp)
   35847:	00 
   35848:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3584c:	0f 84 8b 25 00 00    	je     37ddd <oriole_expat::dispatch+0x3fcd>
   35852:	0f 10 84 24 3f 02 00 	movups 0x23f(%rsp),%xmm0
   35859:	00 
   3585a:	0f 11 84 24 bf 00 00 	movups %xmm0,0xbf(%rsp)
   35861:	00 
   35862:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
   35869:	00 
   3586a:	0f 28 8c 24 30 02 00 	movaps 0x230(%rsp),%xmm1
   35871:	00 
   35872:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   35879:	00 
   3587a:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   35881:	00 
   35882:	eb 07                	jmp    3588b <oriole_expat::dispatch+0x1a7b>
   35884:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   3588b:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
   35892:	00 
   35893:	0f 28 8c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm1
   3589a:	00 
   3589b:	0f 29 84 24 10 06 00 	movaps %xmm0,0x610(%rsp)
   358a2:	00 
   358a3:	0f 29 8c 24 20 06 00 	movaps %xmm1,0x620(%rsp)
   358aa:	00 
   358ab:	0f 10 84 24 bf 00 00 	movups 0xbf(%rsp),%xmm0
   358b2:	00 
   358b3:	0f 11 84 24 2f 06 00 	movups %xmm0,0x62f(%rsp)
   358ba:	00 
   358bb:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   358bf:	0f 84 64 1c 00 00    	je     37529 <oriole_expat::dispatch+0x3719>
   358c5:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   358cc:	00 
   358cd:	44 88 ac 24 28 02 00 	mov    %r13b,0x228(%rsp)
   358d4:	00 
   358d5:	0f 28 84 24 10 06 00 	movaps 0x610(%rsp),%xmm0
   358dc:	00 
   358dd:	0f 28 8c 24 20 06 00 	movaps 0x620(%rsp),%xmm1
   358e4:	00 
   358e5:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   358ec:	00 
   358ed:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   358f4:	00 
   358f5:	0f 10 84 24 2f 06 00 	movups 0x62f(%rsp),%xmm0
   358fc:	00 
   358fd:	0f 11 84 24 48 02 00 	movups %xmm0,0x248(%rsp)
   35904:	00 
   35905:	8b 84 24 38 03 00 00 	mov    0x338(%rsp),%eax
   3590c:	20 84 24 78 04 00 00 	and    %al,0x478(%rsp)
   35913:	0f 84 b9 0d 00 00    	je     366d2 <oriole_expat::dispatch+0x28c2>
   35919:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
   35920:	00 
   35921:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   35928:	00 
   35929:	48 b9 3c 21 45 4e 54 	movabs $0x595449544e45213c,%rcx
   35930:	49 54 59 
   35933:	48 83 f8 08          	cmp    $0x8,%rax
   35937:	0f 83 5e 18 00 00    	jae    3719b <oriole_expat::dispatch+0x338b>
   3593d:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   35944:	00 
   35945:	e9 5b 18 00 00       	jmp    371a5 <oriole_expat::dispatch+0x3395>
   3594a:	b0 01                	mov    $0x1,%al
   3594c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   35950:	b0 01                	mov    $0x1,%al
   35952:	89 44 24 30          	mov    %eax,0x30(%rsp)
   35956:	b0 01                	mov    $0x1,%al
   35958:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3595c:	b0 01                	mov    $0x1,%al
   3595e:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35962:	b0 01                	mov    $0x1,%al
   35964:	89 44 24 14          	mov    %eax,0x14(%rsp)
   35968:	b0 01                	mov    $0x1,%al
   3596a:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3596e:	b0 01                	mov    $0x1,%al
   35970:	89 44 24 40          	mov    %eax,0x40(%rsp)
   35974:	b0 01                	mov    $0x1,%al
   35976:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3597a:	b0 01                	mov    $0x1,%al
   3597c:	89 44 24 04          	mov    %eax,0x4(%rsp)
   35980:	b0 01                	mov    $0x1,%al
   35982:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   35986:	b0 01                	mov    $0x1,%al
   35988:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3598c:	b0 01                	mov    $0x1,%al
   3598e:	89 44 24 18          	mov    %eax,0x18(%rsp)
   35992:	b0 01                	mov    $0x1,%al
   35994:	89 44 24 20          	mov    %eax,0x20(%rsp)
   35998:	b0 01                	mov    $0x1,%al
   3599a:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3599e:	48 83 bc 24 98 05 00 	cmpq   $0x0,0x598(%rsp)
   359a5:	00 00 
   359a7:	0f 84 e2 fd ff ff    	je     3578f <oriole_expat::dispatch+0x197f>
   359ad:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   359b2:	ff 94 24 98 05 00 00 	call   *0x598(%rsp)
   359b9:	b0 01                	mov    $0x1,%al
   359bb:	89 44 24 14          	mov    %eax,0x14(%rsp)
   359bf:	b0 01                	mov    $0x1,%al
   359c1:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   359c5:	b0 01                	mov    $0x1,%al
   359c7:	89 44 24 30          	mov    %eax,0x30(%rsp)
   359cb:	b0 01                	mov    $0x1,%al
   359cd:	89 44 24 48          	mov    %eax,0x48(%rsp)
   359d1:	b0 01                	mov    $0x1,%al
   359d3:	89 44 24 38          	mov    %eax,0x38(%rsp)
   359d7:	e9 f3 13 00 00       	jmp    36dcf <oriole_expat::dispatch+0x2fbf>
   359dc:	4c 89 fd             	mov    %r15,%rbp
   359df:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
   359e4:	0f 10 00             	movups (%rax),%xmm0
   359e7:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   359eb:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   359f2:	00 
   359f3:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   359fa:	00 
   359fb:	4c 8b bc 24 48 01 00 	mov    0x148(%rsp),%r15
   35a02:	00 
   35a03:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   35a0a:	00 
   35a0b:	ba 20 01 00 00       	mov    $0x120,%edx
   35a10:	4c 89 fe             	mov    %r15,%rsi
   35a13:	ff 15 af 18 0b 00    	call   *0xb18af(%rip)        # e72c8 <memcpy@GLIBC_2.14>
   35a19:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   35a20:	00 
   35a21:	ba 08 00 00 00       	mov    $0x8,%edx
   35a26:	b9 20 01 00 00       	mov    $0x120,%ecx
   35a2b:	4c 89 fe             	mov    %r15,%rsi
   35a2e:	ff 15 ac 0f 0b 00    	call   *0xb0fac(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   35a34:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35a3b:	00 
   35a3c:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   35a43:	00 
   35a44:	ba 18 01 00 00       	mov    $0x118,%edx
   35a49:	ff 15 79 18 0b 00    	call   *0xb1879(%rip)        # e72c8 <memcpy@GLIBC_2.14>
   35a4f:	0f b6 8c 24 58 04 00 	movzbl 0x458(%rsp),%ecx
   35a56:	00 
   35a57:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   35a5e:	00 
   35a5f:	48 89 84 24 70 05 00 	mov    %rax,0x570(%rsp)
   35a66:	00 
   35a67:	0f 10 84 24 20 02 00 	movups 0x220(%rsp),%xmm0
   35a6e:	00 
   35a6f:	0f 10 8c 24 30 02 00 	movups 0x230(%rsp),%xmm1
   35a76:	00 
   35a77:	0f 10 94 24 40 02 00 	movups 0x240(%rsp),%xmm2
   35a7e:	00 
   35a7f:	0f 29 94 24 60 05 00 	movaps %xmm2,0x560(%rsp)
   35a86:	00 
   35a87:	0f 29 8c 24 50 05 00 	movaps %xmm1,0x550(%rsp)
   35a8e:	00 
   35a8f:	0f 29 84 24 40 05 00 	movaps %xmm0,0x540(%rsp)
   35a96:	00 
   35a97:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
   35a9e:	00 
   35a9f:	48 89 84 24 00 06 00 	mov    %rax,0x600(%rsp)
   35aa6:	00 
   35aa7:	0f 10 84 24 78 02 00 	movups 0x278(%rsp),%xmm0
   35aae:	00 
   35aaf:	0f 29 84 24 f0 05 00 	movaps %xmm0,0x5f0(%rsp)
   35ab6:	00 
   35ab7:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   35abe:	00 
   35abf:	0f 29 84 24 e0 05 00 	movaps %xmm0,0x5e0(%rsp)
   35ac6:	00 
   35ac7:	0f 10 84 24 58 02 00 	movups 0x258(%rsp),%xmm0
   35ace:	00 
   35acf:	0f 29 84 24 d0 05 00 	movaps %xmm0,0x5d0(%rsp)
   35ad6:	00 
   35ad7:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
   35ade:	00 
   35adf:	48 89 84 24 00 05 00 	mov    %rax,0x500(%rsp)
   35ae6:	00 
   35ae7:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   35aee:	00 
   35aef:	0f 10 8c 24 a0 02 00 	movups 0x2a0(%rsp),%xmm1
   35af6:	00 
   35af7:	0f 10 94 24 b0 02 00 	movups 0x2b0(%rsp),%xmm2
   35afe:	00 
   35aff:	0f 29 94 24 f0 04 00 	movaps %xmm2,0x4f0(%rsp)
   35b06:	00 
   35b07:	0f 29 8c 24 e0 04 00 	movaps %xmm1,0x4e0(%rsp)
   35b0e:	00 
   35b0f:	0f 29 84 24 d0 04 00 	movaps %xmm0,0x4d0(%rsp)
   35b16:	00 
   35b17:	48 8b 84 24 f8 02 00 	mov    0x2f8(%rsp),%rax
   35b1e:	00 
   35b1f:	48 89 84 24 c0 04 00 	mov    %rax,0x4c0(%rsp)
   35b26:	00 
   35b27:	0f 10 84 24 c8 02 00 	movups 0x2c8(%rsp),%xmm0
   35b2e:	00 
   35b2f:	0f 10 8c 24 d8 02 00 	movups 0x2d8(%rsp),%xmm1
   35b36:	00 
   35b37:	0f 10 94 24 e8 02 00 	movups 0x2e8(%rsp),%xmm2
   35b3e:	00 
   35b3f:	0f 29 94 24 b0 04 00 	movaps %xmm2,0x4b0(%rsp)
   35b46:	00 
   35b47:	0f 29 8c 24 a0 04 00 	movaps %xmm1,0x4a0(%rsp)
   35b4e:	00 
   35b4f:	0f 29 84 24 90 04 00 	movaps %xmm0,0x490(%rsp)
   35b56:	00 
   35b57:	48 8b 84 24 30 03 00 	mov    0x330(%rsp),%rax
   35b5e:	00 
   35b5f:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   35b66:	00 
   35b67:	0f 10 84 24 00 03 00 	movups 0x300(%rsp),%xmm0
   35b6e:	00 
   35b6f:	0f 10 8c 24 10 03 00 	movups 0x310(%rsp),%xmm1
   35b76:	00 
   35b77:	0f 10 94 24 20 03 00 	movups 0x320(%rsp),%xmm2
   35b7e:	00 
   35b7f:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   35b86:	00 
   35b87:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   35b8e:	00 
   35b8f:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   35b96:	00 
   35b97:	48 83 bc 24 a0 01 00 	cmpq   $0xffffffffffffffff,0x1a0(%rsp)
   35b9e:	00 ff 
   35ba0:	0f 94 c0             	sete   %al
   35ba3:	48 85 ed             	test   %rbp,%rbp
   35ba6:	41 0f 94 c7          	sete   %r15b
   35baa:	41 08 c7             	or     %al,%r15b
   35bad:	41 80 ff 01          	cmp    $0x1,%r15b
   35bb1:	0f 85 c5 0b 00 00    	jne    3677c <oriole_expat::dispatch+0x296c>
   35bb7:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
   35bbd:	0f 84 97 21 00 00    	je     37d5a <oriole_expat::dispatch+0x3f4a>
   35bc3:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   35bc7:	45 31 f6             	xor    %r14d,%r14d
   35bca:	48 83 bc 24 d0 05 00 	cmpq   $0xffffffffffffffff,0x5d0(%rsp)
   35bd1:	00 ff 
   35bd3:	bd 00 00 00 00       	mov    $0x0,%ebp
   35bd8:	74 07                	je     35be1 <oriole_expat::dispatch+0x1dd1>
   35bda:	8b ac 24 00 06 00 00 	mov    0x600(%rsp),%ebp
   35be1:	48 8b 84 24 70 05 00 	mov    0x570(%rsp),%rax
   35be8:	00 
   35be9:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   35bf0:	00 
   35bf1:	0f 28 84 24 40 05 00 	movaps 0x540(%rsp),%xmm0
   35bf8:	00 
   35bf9:	0f 28 8c 24 50 05 00 	movaps 0x550(%rsp),%xmm1
   35c00:	00 
   35c01:	0f 28 94 24 60 05 00 	movaps 0x560(%rsp),%xmm2
   35c08:	00 
   35c09:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   35c10:	00 
   35c11:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   35c18:	00 
   35c19:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   35c20:	00 
   35c21:	b0 01                	mov    $0x1,%al
   35c23:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35c27:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35c2e:	00 
   35c2f:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   35c36:	00 
   35c37:	b0 01                	mov    $0x1,%al
   35c39:	89 44 24 30          	mov    %eax,0x30(%rsp)
   35c3d:	41 b4 01             	mov    $0x1,%r12b
   35c40:	41 b5 01             	mov    $0x1,%r13b
   35c43:	ff 15 67 0e 0b 00    	call   *0xb0e67(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   35c49:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   35c50:	00 
   35c51:	0f b6 8c 24 28 02 00 	movzbl 0x228(%rsp),%ecx
   35c58:	00 
   35c59:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   35c5d:	0f 84 4d 27 00 00    	je     383b0 <oriole_expat::dispatch+0x45a0>
   35c63:	41 89 ee             	mov    %ebp,%r14d
   35c66:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   35c6d:	00 
   35c6e:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   35c75:	00 
   35c76:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   35c7d:	00 
   35c7e:	0f 11 94 24 08 02 00 	movups %xmm2,0x208(%rsp)
   35c85:	00 
   35c86:	0f 11 8c 24 f9 01 00 	movups %xmm1,0x1f9(%rsp)
   35c8d:	00 
   35c8e:	0f 11 84 24 e9 01 00 	movups %xmm0,0x1e9(%rsp)
   35c95:	00 
   35c96:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
   35c9d:	00 
   35c9e:	88 8c 24 e8 01 00 00 	mov    %cl,0x1e8(%rsp)
   35ca5:	4c 8b ac 24 00 02 00 	mov    0x200(%rsp),%r13
   35cac:	00 
   35cad:	41 b7 01             	mov    $0x1,%r15b
   35cb0:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   35cb7:	00 
   35cb8:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
   35cbf:	00 
   35cc0:	40 b5 01             	mov    $0x1,%bpl
   35cc3:	41 b4 01             	mov    $0x1,%r12b
   35cc6:	e8 f5 d0 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   35ccb:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   35cd2:	00 
   35cd3:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   35cda:	00 
   35cdb:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   35cdf:	0f 85 73 28 00 00    	jne    38558 <oriole_expat::dispatch+0x4748>
   35ce5:	89 cb                	mov    %ecx,%ebx
   35ce7:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   35cee:	00 
   35cef:	48 85 c9             	test   %rcx,%rcx
   35cf2:	74 2b                	je     35d1f <oriole_expat::dispatch+0x1f0f>
   35cf4:	b0 01                	mov    $0x1,%al
   35cf6:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35cfa:	4c 89 ee             	mov    %r13,%rsi
   35cfd:	45 31 ed             	xor    %r13d,%r13d
   35d00:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   35d07:	00 
   35d08:	ba 01 00 00 00       	mov    $0x1,%edx
   35d0d:	b0 01                	mov    $0x1,%al
   35d0f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   35d13:	41 b4 01             	mov    $0x1,%r12b
   35d16:	45 31 f6             	xor    %r14d,%r14d
   35d19:	ff 15 c1 0c 0b 00    	call   *0xb0cc1(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   35d1f:	40 b5 01             	mov    $0x1,%bpl
   35d22:	45 31 ed             	xor    %r13d,%r13d
   35d25:	41 b4 01             	mov    $0x1,%r12b
   35d28:	e9 af 2f 00 00       	jmp    38cdc <oriole_expat::dispatch+0x4ecc>
   35d2d:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
   35d34:	00 
   35d35:	48 89 8c 24 10 02 00 	mov    %rcx,0x210(%rsp)
   35d3c:	00 
   35d3d:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
   35d44:	00 
   35d45:	0f 28 8c 24 70 01 00 	movaps 0x170(%rsp),%xmm1
   35d4c:	00 
   35d4d:	0f 28 94 24 80 01 00 	movaps 0x180(%rsp),%xmm2
   35d54:	00 
   35d55:	0f 29 94 24 00 02 00 	movaps %xmm2,0x200(%rsp)
   35d5c:	00 
   35d5d:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   35d64:	00 
   35d65:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   35d6c:	00 
   35d6d:	48 8b 48 30          	mov    0x30(%rax),%rcx
   35d71:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
   35d78:	00 
   35d79:	0f 10 00             	movups (%rax),%xmm0
   35d7c:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   35d80:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   35d84:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   35d8b:	00 
   35d8c:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   35d93:	00 
   35d94:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   35d9b:	00 
   35d9c:	4c 8b b4 24 a0 05 00 	mov    0x5a0(%rsp),%r14
   35da3:	00 
   35da4:	4d 85 f6             	test   %r14,%r14
   35da7:	0f 84 75 0f 00 00    	je     36d22 <oriole_expat::dispatch+0x2f12>
   35dad:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
   35db4:	00 
   35db5:	48 8b 48 30          	mov    0x30(%rax),%rcx
   35db9:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
   35dc0:	00 
   35dc1:	0f 10 00             	movups (%rax),%xmm0
   35dc4:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   35dc8:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   35dcc:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   35dd3:	00 
   35dd4:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   35ddb:	00 
   35ddc:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   35de3:	00 
   35de4:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35deb:	00 
   35dec:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   35df3:	00 
   35df4:	e8 c7 cf ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   35df9:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   35e00:	00 
   35e01:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   35e08:	00 00 
   35e0a:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   35e0e:	0f 85 85 1a 00 00    	jne    37899 <oriole_expat::dispatch+0x3a89>
   35e14:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   35e1b:	00 
   35e1c:	48 85 c9             	test   %rcx,%rcx
   35e1f:	0f 84 bb 25 00 00    	je     383e0 <oriole_expat::dispatch+0x45d0>
   35e25:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   35e2c:	00 
   35e2d:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   35e34:	00 
   35e35:	ba 01 00 00 00       	mov    $0x1,%edx
   35e3a:	ff 15 a0 0b 0b 00    	call   *0xb0ba0(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   35e40:	e9 9b 25 00 00       	jmp    383e0 <oriole_expat::dispatch+0x45d0>
   35e45:	48 8b 8c 24 a8 05 00 	mov    0x5a8(%rsp),%rcx
   35e4c:	00 
   35e4d:	b0 01                	mov    $0x1,%al
   35e4f:	48 85 c9             	test   %rcx,%rcx
   35e52:	0f 84 5b 0f 00 00    	je     36db3 <oriole_expat::dispatch+0x2fa3>
   35e58:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   35e5c:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   35e61:	ff d1                	call   *%rcx
   35e63:	85 c0                	test   %eax,%eax
   35e65:	0f 85 4c 0f 00 00    	jne    36db7 <oriole_expat::dispatch+0x2fa7>
   35e6b:	48 b8 16 00 00 00 16 	movabs $0x1600000016,%rax
   35e72:	00 00 00 
   35e75:	48 89 83 10 0a 00 00 	mov    %rax,0xa10(%rbx)
   35e7c:	e9 36 0f 00 00       	jmp    36db7 <oriole_expat::dispatch+0x2fa7>
   35e81:	0f 10 00             	movups (%rax),%xmm0
   35e84:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   35e88:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   35e8f:	00 
   35e90:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   35e97:	00 
   35e98:	4c 8b bc 24 48 01 00 	mov    0x148(%rsp),%r15
   35e9f:	00 
   35ea0:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   35ea7:	00 
   35ea8:	ba b0 00 00 00       	mov    $0xb0,%edx
   35ead:	4c 89 fe             	mov    %r15,%rsi
   35eb0:	ff 15 12 14 0b 00    	call   *0xb1412(%rip)        # e72c8 <memcpy@GLIBC_2.14>
   35eb6:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   35ebd:	00 
   35ebe:	ba 08 00 00 00       	mov    $0x8,%edx
   35ec3:	b9 b0 00 00 00       	mov    $0xb0,%ecx
   35ec8:	4c 89 fe             	mov    %r15,%rsi
   35ecb:	ff 15 0f 0b 0b 00    	call   *0xb0b0f(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   35ed1:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   35ed8:	00 
   35ed9:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   35ee0:	00 
   35ee1:	ba a8 00 00 00       	mov    $0xa8,%edx
   35ee6:	ff 15 dc 13 0b 00    	call   *0xb13dc(%rip)        # e72c8 <memcpy@GLIBC_2.14>
   35eec:	44 0f b6 bc 24 e8 03 	movzbl 0x3e8(%rsp),%r15d
   35ef3:	00 00 
   35ef5:	48 8b 94 24 18 02 00 	mov    0x218(%rsp),%rdx
   35efc:	00 
   35efd:	48 85 d2             	test   %rdx,%rdx
   35f00:	0f 95 c0             	setne  %al
   35f03:	44 89 f9             	mov    %r15d,%ecx
   35f06:	80 f1 01             	xor    $0x1,%cl
   35f09:	20 c1                	and    %al,%cl
   35f0b:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   35f12:	00 
   35f13:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   35f1a:	00 
   35f1b:	0f 10 84 24 20 02 00 	movups 0x220(%rsp),%xmm0
   35f22:	00 
   35f23:	0f 10 8c 24 30 02 00 	movups 0x230(%rsp),%xmm1
   35f2a:	00 
   35f2b:	0f 10 94 24 40 02 00 	movups 0x240(%rsp),%xmm2
   35f32:	00 
   35f33:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   35f3a:	00 
   35f3b:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   35f42:	00 
   35f43:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   35f4a:	00 
   35f4b:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
   35f52:	00 
   35f53:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   35f5a:	00 
   35f5b:	0f 10 84 24 78 02 00 	movups 0x278(%rsp),%xmm0
   35f62:	00 
   35f63:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   35f6a:	00 
   35f6b:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   35f72:	00 
   35f73:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
   35f7a:	00 
   35f7b:	0f 10 84 24 58 02 00 	movups 0x258(%rsp),%xmm0
   35f82:	00 
   35f83:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   35f8a:	00 
   35f8b:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
   35f92:	00 
   35f93:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   35f9a:	00 
   35f9b:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   35fa2:	00 
   35fa3:	0f 10 8c 24 a0 02 00 	movups 0x2a0(%rsp),%xmm1
   35faa:	00 
   35fab:	0f 10 94 24 b0 02 00 	movups 0x2b0(%rsp),%xmm2
   35fb2:	00 
   35fb3:	0f 29 94 24 00 01 00 	movaps %xmm2,0x100(%rsp)
   35fba:	00 
   35fbb:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   35fc2:	00 
   35fc3:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   35fca:	00 
   35fcb:	88 8b 60 0b 00 00    	mov    %cl,0xb60(%rbx)
   35fd1:	48 85 d2             	test   %rdx,%rdx
   35fd4:	0f 84 2f 10 00 00    	je     37009 <oriole_expat::dispatch+0x31f9>
   35fda:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
   35fe1:	00 
   35fe2:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   35fe9:	00 
   35fea:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
   35ff1:	00 
   35ff2:	0f 28 8c 24 b0 01 00 	movaps 0x1b0(%rsp),%xmm1
   35ff9:	00 
   35ffa:	0f 28 94 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm2
   36001:	00 
   36002:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   36009:	00 
   3600a:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   36011:	00 
   36012:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   36019:	00 
   3601a:	40 b5 01             	mov    $0x1,%bpl
   3601d:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   36024:	00 
   36025:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3602c:	00 
   3602d:	ff 15 7d 0a 0b 00    	call   *0xb0a7d(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   36033:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   3603a:	00 
   3603b:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   36042:	00 00 
   36044:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   36048:	0f 84 ed 1a 00 00    	je     37b3b <oriole_expat::dispatch+0x3d2b>
   3604e:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   36055:	00 
   36056:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   3605d:	00 
   3605e:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   36065:	00 
   36066:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   3606d:	00 
   3606e:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   36073:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   36078:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   3607d:	44 88 6c 24 68       	mov    %r13b,0x68(%rsp)
   36082:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
   36089:	00 
   3608a:	40 b5 01             	mov    $0x1,%bpl
   3608d:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   36094:	00 
   36095:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
   3609c:	00 
   3609d:	e8 1e cd ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   360a2:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   360a9:	00 
   360aa:	44 0f b6 ac 24 48 03 	movzbl 0x348(%rsp),%r13d
   360b1:	00 00 
   360b3:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   360b7:	0f 85 46 1c 00 00    	jne    37d03 <oriole_expat::dispatch+0x3ef3>
   360bd:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   360c4:	00 
   360c5:	48 85 c9             	test   %rcx,%rcx
   360c8:	74 15                	je     360df <oriole_expat::dispatch+0x22cf>
   360ca:	31 ed                	xor    %ebp,%ebp
   360cc:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   360d1:	ba 01 00 00 00       	mov    $0x1,%edx
   360d6:	4c 89 e6             	mov    %r12,%rsi
   360d9:	ff 15 01 09 0b 00    	call   *0xb0901(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   360df:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   360e6:	00 
   360e7:	e8 44 92 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   360ec:	e9 c1 25 00 00       	jmp    386b2 <oriole_expat::dispatch+0x48a2>
   360f1:	4c 89 94 24 70 04 00 	mov    %r10,0x470(%rsp)
   360f8:	00 
   360f9:	0f 10 00             	movups (%rax),%xmm0
   360fc:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   36100:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   36107:	00 
   36108:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   3610f:	00 
   36110:	4c 8b bc 24 48 01 00 	mov    0x148(%rsp),%r15
   36117:	00 
   36118:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3611f:	00 
   36120:	ba e8 00 00 00       	mov    $0xe8,%edx
   36125:	4c 89 fe             	mov    %r15,%rsi
   36128:	ff 15 9a 11 0b 00    	call   *0xb119a(%rip)        # e72c8 <memcpy@GLIBC_2.14>
   3612e:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   36135:	00 
   36136:	ba 08 00 00 00       	mov    $0x8,%edx
   3613b:	b9 e8 00 00 00       	mov    $0xe8,%ecx
   36140:	4c 89 fe             	mov    %r15,%rsi
   36143:	ff 15 97 08 0b 00    	call   *0xb0897(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36149:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   36150:	00 
   36151:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   36158:	00 
   36159:	ba e0 00 00 00       	mov    $0xe0,%edx
   3615e:	ff 15 64 11 0b 00    	call   *0xb1164(%rip)        # e72c8 <memcpy@GLIBC_2.14>
   36164:	44 0f b6 bc 24 20 04 	movzbl 0x420(%rsp),%r15d
   3616b:	00 00 
   3616d:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   36174:	00 
   36175:	48 89 84 24 00 05 00 	mov    %rax,0x500(%rsp)
   3617c:	00 
   3617d:	0f 10 84 24 20 02 00 	movups 0x220(%rsp),%xmm0
   36184:	00 
   36185:	0f 10 8c 24 30 02 00 	movups 0x230(%rsp),%xmm1
   3618c:	00 
   3618d:	0f 10 94 24 40 02 00 	movups 0x240(%rsp),%xmm2
   36194:	00 
   36195:	0f 29 94 24 f0 04 00 	movaps %xmm2,0x4f0(%rsp)
   3619c:	00 
   3619d:	0f 29 8c 24 e0 04 00 	movaps %xmm1,0x4e0(%rsp)
   361a4:	00 
   361a5:	0f 29 84 24 d0 04 00 	movaps %xmm0,0x4d0(%rsp)
   361ac:	00 
   361ad:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
   361b4:	00 
   361b5:	48 89 84 24 c0 04 00 	mov    %rax,0x4c0(%rsp)
   361bc:	00 
   361bd:	0f 10 84 24 78 02 00 	movups 0x278(%rsp),%xmm0
   361c4:	00 
   361c5:	0f 29 84 24 b0 04 00 	movaps %xmm0,0x4b0(%rsp)
   361cc:	00 
   361cd:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   361d4:	00 
   361d5:	0f 29 84 24 a0 04 00 	movaps %xmm0,0x4a0(%rsp)
   361dc:	00 
   361dd:	0f 10 84 24 58 02 00 	movups 0x258(%rsp),%xmm0
   361e4:	00 
   361e5:	0f 29 84 24 90 04 00 	movaps %xmm0,0x490(%rsp)
   361ec:	00 
   361ed:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
   361f4:	00 
   361f5:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   361fc:	00 
   361fd:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
   36204:	00 
   36205:	0f 10 8c 24 a0 02 00 	movups 0x2a0(%rsp),%xmm1
   3620c:	00 
   3620d:	0f 10 94 24 b0 02 00 	movups 0x2b0(%rsp),%xmm2
   36214:	00 
   36215:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
   3621c:	00 
   3621d:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
   36224:	00 
   36225:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   3622c:	00 
   3622d:	48 8b 84 24 f8 02 00 	mov    0x2f8(%rsp),%rax
   36234:	00 
   36235:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   3623c:	00 
   3623d:	0f 10 84 24 c8 02 00 	movups 0x2c8(%rsp),%xmm0
   36244:	00 
   36245:	0f 10 8c 24 d8 02 00 	movups 0x2d8(%rsp),%xmm1
   3624c:	00 
   3624d:	0f 10 94 24 e8 02 00 	movups 0x2e8(%rsp),%xmm2
   36254:	00 
   36255:	0f 29 94 24 00 02 00 	movaps %xmm2,0x200(%rsp)
   3625c:	00 
   3625d:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   36264:	00 
   36265:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   3626c:	00 
   3626d:	48 83 bc 24 70 04 00 	cmpq   $0x0,0x470(%rsp)
   36274:	00 00 
   36276:	0f 84 31 0e 00 00    	je     370ad <oriole_expat::dispatch+0x329d>
   3627c:	48 8b 84 24 00 05 00 	mov    0x500(%rsp),%rax
   36283:	00 
   36284:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   3628b:	00 
   3628c:	0f 28 84 24 d0 04 00 	movaps 0x4d0(%rsp),%xmm0
   36293:	00 
   36294:	0f 28 8c 24 e0 04 00 	movaps 0x4e0(%rsp),%xmm1
   3629b:	00 
   3629c:	0f 28 94 24 f0 04 00 	movaps 0x4f0(%rsp),%xmm2
   362a3:	00 
   362a4:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   362ab:	00 
   362ac:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   362b3:	00 
   362b4:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   362bb:	00 
   362bc:	40 b5 01             	mov    $0x1,%bpl
   362bf:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   362c6:	00 
   362c7:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   362ce:	00 
   362cf:	41 b6 01             	mov    $0x1,%r14b
   362d2:	41 b5 01             	mov    $0x1,%r13b
   362d5:	ff 15 d5 07 0b 00    	call   *0xb07d5(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   362db:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   362e2:	00 
   362e3:	0f b6 8c 24 28 02 00 	movzbl 0x228(%rsp),%ecx
   362ea:	00 
   362eb:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   362ef:	0f 84 65 18 00 00    	je     37b5a <oriole_expat::dispatch+0x3d4a>
   362f5:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   362fc:	00 
   362fd:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   36304:	00 
   36305:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   3630c:	00 
   3630d:	0f 11 94 24 08 01 00 	movups %xmm2,0x108(%rsp)
   36314:	00 
   36315:	0f 11 8c 24 f9 00 00 	movups %xmm1,0xf9(%rsp)
   3631c:	00 
   3631d:	0f 11 84 24 e9 00 00 	movups %xmm0,0xe9(%rsp)
   36324:	00 
   36325:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
   3632c:	00 
   3632d:	88 8c 24 e8 00 00 00 	mov    %cl,0xe8(%rsp)
   36334:	4c 8b a4 24 00 01 00 	mov    0x100(%rsp),%r12
   3633b:	00 
   3633c:	48 8b 84 24 c0 04 00 	mov    0x4c0(%rsp),%rax
   36343:	00 
   36344:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   3634b:	00 
   3634c:	0f 28 84 24 90 04 00 	movaps 0x490(%rsp),%xmm0
   36353:	00 
   36354:	0f 28 8c 24 a0 04 00 	movaps 0x4a0(%rsp),%xmm1
   3635b:	00 
   3635c:	0f 28 94 24 b0 04 00 	movaps 0x4b0(%rsp),%xmm2
   36363:	00 
   36364:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   3636b:	00 
   3636c:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   36373:	00 
   36374:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   3637b:	00 
   3637c:	40 b5 01             	mov    $0x1,%bpl
   3637f:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   36386:	00 
   36387:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3638e:	00 
   3638f:	41 b6 01             	mov    $0x1,%r14b
   36392:	ff 15 18 07 0b 00    	call   *0xb0718(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   36398:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   3639f:	00 
   363a0:	0f b6 8c 24 28 02 00 	movzbl 0x228(%rsp),%ecx
   363a7:	00 
   363a8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   363ac:	0f 84 9d 1d 00 00    	je     3814f <oriole_expat::dispatch+0x433f>
   363b2:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   363b9:	00 
   363ba:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   363c1:	00 
   363c2:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   363c9:	00 
   363ca:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   363d1:	00 
   363d2:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   363d7:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   363dc:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   363e1:	88 4c 24 68          	mov    %cl,0x68(%rsp)
   363e5:	4c 8b b4 24 80 00 00 	mov    0x80(%rsp),%r14
   363ec:	00 
   363ed:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
   363f4:	00 
   363f5:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   363fc:	00 
   363fd:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
   36404:	00 
   36405:	0f 28 8c 24 b0 01 00 	movaps 0x1b0(%rsp),%xmm1
   3640c:	00 
   3640d:	0f 28 94 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm2
   36414:	00 
   36415:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   3641c:	00 
   3641d:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   36424:	00 
   36425:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   3642c:	00 
   3642d:	40 b5 01             	mov    $0x1,%bpl
   36430:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   36437:	00 
   36438:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3643f:	00 
   36440:	ff 15 6a 06 0b 00    	call   *0xb066a(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   36446:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   3644d:	00 
   3644e:	0f b6 8c 24 28 02 00 	movzbl 0x228(%rsp),%ecx
   36455:	00 
   36456:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3645a:	0f 84 92 23 00 00    	je     387f2 <oriole_expat::dispatch+0x49e2>
   36460:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   36467:	00 
   36468:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   3646f:	00 
   36470:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   36477:	00 
   36478:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   3647f:	00 
   36480:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   36487:	00 
   36488:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   3648f:	00 
   36490:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   36497:	00 
   36498:	88 8c 24 a8 00 00 00 	mov    %cl,0xa8(%rsp)
   3649f:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
   364a6:	00 
   364a7:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   364ae:	00 
   364af:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
   364b6:	00 
   364b7:	e8 04 c9 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   364bc:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   364c3:	00 
   364c4:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   364cb:	00 
   364cc:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   364d0:	0f 85 a1 24 00 00    	jne    38977 <oriole_expat::dispatch+0x4b67>
   364d6:	89 cb                	mov    %ecx,%ebx
   364d8:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   364df:	00 
   364e0:	31 ed                	xor    %ebp,%ebp
   364e2:	48 85 c9             	test   %rcx,%rcx
   364e5:	0f 84 59 2f 00 00    	je     39444 <oriole_expat::dispatch+0x5634>
   364eb:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   364f2:	00 
   364f3:	ba 01 00 00 00       	mov    $0x1,%edx
   364f8:	4c 89 ee             	mov    %r13,%rsi
   364fb:	ff 15 df 04 0b 00    	call   *0xb04df(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36501:	89 d9                	mov    %ebx,%ecx
   36503:	e9 3e 2f 00 00       	jmp    39446 <oriole_expat::dispatch+0x5636>
   36508:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3650c:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
   36513:	00 
   36514:	0f 10 00             	movups (%rax),%xmm0
   36517:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   3651b:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   3651f:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
   36526:	00 
   36527:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
   3652c:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   36531:	48 83 bc 24 88 05 00 	cmpq   $0x0,0x588(%rsp)
   36538:	00 00 
   3653a:	0f 84 e5 08 00 00    	je     36e25 <oriole_expat::dispatch+0x3015>
   36540:	0f b6 ac 24 60 01 00 	movzbl 0x160(%rsp),%ebp
   36547:	00 
   36548:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3654c:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
   36553:	00 
   36554:	0f 10 00             	movups (%rax),%xmm0
   36557:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   3655b:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   3655f:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   36566:	00 
   36567:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   3656e:	00 
   3656f:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   36576:	00 
   36577:	b0 01                	mov    $0x1,%al
   36579:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3657d:	45 31 ed             	xor    %r13d,%r13d
   36580:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   36587:	00 
   36588:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3658f:	00 
   36590:	b0 01                	mov    $0x1,%al
   36592:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36596:	b0 01                	mov    $0x1,%al
   36598:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3659c:	b0 01                	mov    $0x1,%al
   3659e:	89 44 24 38          	mov    %eax,0x38(%rsp)
   365a2:	b0 01                	mov    $0x1,%al
   365a4:	89 44 24 14          	mov    %eax,0x14(%rsp)
   365a8:	b0 01                	mov    $0x1,%al
   365aa:	89 44 24 10          	mov    %eax,0x10(%rsp)
   365ae:	b0 01                	mov    $0x1,%al
   365b0:	89 44 24 40          	mov    %eax,0x40(%rsp)
   365b4:	b0 01                	mov    $0x1,%al
   365b6:	89 44 24 08          	mov    %eax,0x8(%rsp)
   365ba:	b0 01                	mov    $0x1,%al
   365bc:	89 44 24 04          	mov    %eax,0x4(%rsp)
   365c0:	b0 01                	mov    $0x1,%al
   365c2:	89 44 24 28          	mov    %eax,0x28(%rsp)
   365c6:	b0 01                	mov    $0x1,%al
   365c8:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   365cd:	b0 01                	mov    $0x1,%al
   365cf:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   365d3:	41 b6 01             	mov    $0x1,%r14b
   365d6:	41 b4 01             	mov    $0x1,%r12b
   365d9:	41 b7 01             	mov    $0x1,%r15b
   365dc:	ff 15 ce 04 0b 00    	call   *0xb04ce(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   365e2:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   365e9:	00 
   365ea:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   365f1:	00 00 
   365f3:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   365f7:	0f 84 a9 14 00 00    	je     37aa6 <oriole_expat::dispatch+0x3c96>
   365fd:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   36604:	00 
   36605:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   3660c:	00 
   3660d:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   36614:	00 
   36615:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   3661c:	00 
   3661d:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   36624:	00 
   36625:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   3662c:	00 
   3662d:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   36634:	00 
   36635:	44 88 ac 24 a8 00 00 	mov    %r13b,0xa8(%rsp)
   3663c:	00 
   3663d:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   36644:	00 
   36645:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   3664a:	89 ea                	mov    %ebp,%edx
   3664c:	ff 94 24 88 05 00 00 	call   *0x588(%rsp)
   36653:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   3665a:	00 
   3665b:	48 85 c9             	test   %rcx,%rcx
   3665e:	74 6a                	je     366ca <oriole_expat::dispatch+0x28ba>
   36660:	45 31 ed             	xor    %r13d,%r13d
   36663:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   3666a:	00 
   3666b:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   36672:	00 
   36673:	ba 01 00 00 00       	mov    $0x1,%edx
   36678:	b0 01                	mov    $0x1,%al
   3667a:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3667e:	b0 01                	mov    $0x1,%al
   36680:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36684:	b0 01                	mov    $0x1,%al
   36686:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3668a:	b0 01                	mov    $0x1,%al
   3668c:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36690:	b0 01                	mov    $0x1,%al
   36692:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36696:	b0 01                	mov    $0x1,%al
   36698:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3669c:	b0 01                	mov    $0x1,%al
   3669e:	89 44 24 08          	mov    %eax,0x8(%rsp)
   366a2:	b0 01                	mov    $0x1,%al
   366a4:	89 44 24 04          	mov    %eax,0x4(%rsp)
   366a8:	b0 01                	mov    $0x1,%al
   366aa:	89 44 24 28          	mov    %eax,0x28(%rsp)
   366ae:	b0 01                	mov    $0x1,%al
   366b0:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   366b5:	b0 01                	mov    $0x1,%al
   366b7:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   366bb:	41 b6 01             	mov    $0x1,%r14b
   366be:	41 b4 01             	mov    $0x1,%r12b
   366c1:	41 b7 01             	mov    $0x1,%r15b
   366c4:	ff 15 16 03 0b 00    	call   *0xb0316(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   366ca:	40 b5 01             	mov    $0x1,%bpl
   366cd:	e9 cc 1a 00 00       	jmp    3819e <oriole_expat::dispatch+0x438e>
   366d2:	48 8d bb 20 0b 00 00 	lea    0xb20(%rbx),%rdi
   366d9:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   366e0:	00 
   366e1:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   366e8:	00 
   366e9:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   366f0:	00 
   366f1:	0f b6 8c 24 28 02 00 	movzbl 0x228(%rsp),%ecx
   366f8:	00 
   366f9:	8b 94 24 29 02 00 00 	mov    0x229(%rsp),%edx
   36700:	0f b7 b4 24 2d 02 00 	movzwl 0x22d(%rsp),%esi
   36707:	00 
   36708:	44 0f b6 84 24 2f 02 	movzbl 0x22f(%rsp),%r8d
   3670f:	00 00 
   36711:	0f 10 84 24 30 02 00 	movups 0x230(%rsp),%xmm0
   36718:	00 
   36719:	0f 10 8c 24 40 02 00 	movups 0x240(%rsp),%xmm1
   36720:	00 
   36721:	0f 29 8c 24 60 03 00 	movaps %xmm1,0x360(%rsp)
   36728:	00 
   36729:	0f 29 84 24 50 03 00 	movaps %xmm0,0x350(%rsp)
   36730:	00 
   36731:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
   36738:	00 
   36739:	88 8c 24 48 03 00 00 	mov    %cl,0x348(%rsp)
   36740:	89 94 24 49 03 00 00 	mov    %edx,0x349(%rsp)
   36747:	66 89 b4 24 4d 03 00 	mov    %si,0x34d(%rsp)
   3674e:	00 
   3674f:	44 88 84 24 4f 03 00 	mov    %r8b,0x34f(%rsp)
   36756:	00 
   36757:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3675e:	00 
   3675f:	e8 5c 56 00 00       	call   3bdc0 <<oriole_storage::queue::Queue<oriole_storage::string::String>>::try_push_back>
   36764:	41 89 c5             	mov    %eax,%r13d
   36767:	3c ff                	cmp    $0xff,%al
   36769:	0f 85 6e 16 00 00    	jne    37ddd <oriole_expat::dispatch+0x3fcd>
   3676f:	48 89 df             	mov    %rbx,%rdi
   36772:	e8 89 c9 ff ff       	call   33100 <oriole_expat::drain_default_fragments>
   36777:	e9 ad 0d 00 00       	jmp    37529 <oriole_expat::dispatch+0x3719>
   3677c:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   36783:	00 
   36784:	48 8b 94 24 d0 01 00 	mov    0x1d0(%rsp),%rdx
   3678b:	00 
   3678c:	0f 10 43 08          	movups 0x8(%rbx),%xmm0
   36790:	0f 10 4b 18          	movups 0x18(%rbx),%xmm1
   36794:	0f 29 8c 24 30 02 00 	movaps %xmm1,0x230(%rsp)
   3679b:	00 
   3679c:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   367a3:	00 
   367a4:	b0 01                	mov    $0x1,%al
   367a6:	89 44 24 38          	mov    %eax,0x38(%rsp)
   367aa:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   367b1:	00 
   367b2:	48 8d 8c 24 20 02 00 	lea    0x220(%rsp),%rcx
   367b9:	00 
   367ba:	b0 01                	mov    $0x1,%al
   367bc:	89 44 24 30          	mov    %eax,0x30(%rsp)
   367c0:	41 b4 01             	mov    $0x1,%r12b
   367c3:	41 b5 01             	mov    $0x1,%r13b
   367c6:	41 b6 01             	mov    $0x1,%r14b
   367c9:	ff 15 d9 02 0b 00    	call   *0xb02d9(%rip)        # e6aa8 <_GLOBAL_OFFSET_TABLE_+0x200>
   367cf:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   367d6:	00 
   367d7:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   367de:	00 
   367df:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   367e3:	0f 84 ba 15 00 00    	je     37da3 <oriole_expat::dispatch+0x3f93>
   367e9:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   367f0:	00 
   367f1:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   367f8:	00 
   367f9:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   36800:	00 
   36801:	0f 11 94 24 08 01 00 	movups %xmm2,0x108(%rsp)
   36808:	00 
   36809:	0f 11 8c 24 f9 00 00 	movups %xmm1,0xf9(%rsp)
   36810:	00 
   36811:	0f 11 84 24 e9 00 00 	movups %xmm0,0xe9(%rsp)
   36818:	00 
   36819:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
   36820:	00 
   36821:	88 8c 24 e8 00 00 00 	mov    %cl,0xe8(%rsp)
   36828:	48 8b 84 24 70 05 00 	mov    0x570(%rsp),%rax
   3682f:	00 
   36830:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   36837:	00 
   36838:	0f 28 84 24 40 05 00 	movaps 0x540(%rsp),%xmm0
   3683f:	00 
   36840:	0f 28 8c 24 50 05 00 	movaps 0x550(%rsp),%xmm1
   36847:	00 
   36848:	0f 28 94 24 60 05 00 	movaps 0x560(%rsp),%xmm2
   3684f:	00 
   36850:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   36857:	00 
   36858:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   3685f:	00 
   36860:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   36867:	00 
   36868:	b0 01                	mov    $0x1,%al
   3686a:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3686e:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   36875:	00 
   36876:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   3687d:	00 
   3687e:	41 b4 01             	mov    $0x1,%r12b
   36881:	ff 15 29 02 0b 00    	call   *0xb0229(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   36887:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   3688e:	00 
   3688f:	0f b6 8c 24 28 02 00 	movzbl 0x228(%rsp),%ecx
   36896:	00 
   36897:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3689b:	0f 84 76 1b 00 00    	je     38417 <oriole_expat::dispatch+0x4607>
   368a1:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   368a8:	00 
   368a9:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   368b0:	00 
   368b1:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   368b8:	00 
   368b9:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   368c0:	00 
   368c1:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   368c6:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   368cb:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   368d0:	88 4c 24 68          	mov    %cl,0x68(%rsp)
   368d4:	83 bc 24 08 05 00 00 	cmpl   $0xffffffff,0x508(%rsp)
   368db:	ff 
   368dc:	0f 84 27 1d 00 00    	je     38609 <oriole_expat::dispatch+0x47f9>
   368e2:	4c 8b a4 24 28 05 00 	mov    0x528(%rsp),%r12
   368e9:	00 
   368ea:	e9 1d 1d 00 00       	jmp    3860c <oriole_expat::dispatch+0x47fc>
   368ef:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   368f6:	00 
   368f7:	48 85 c9             	test   %rcx,%rcx
   368fa:	0f 84 85 18 00 00    	je     38185 <oriole_expat::dispatch+0x4375>
   36900:	b0 01                	mov    $0x1,%al
   36902:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36906:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   3690d:	00 
   3690e:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   36915:	00 
   36916:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3691b:	ba 01 00 00 00       	mov    $0x1,%edx
   36920:	b0 01                	mov    $0x1,%al
   36922:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36926:	b0 01                	mov    $0x1,%al
   36928:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3692c:	b0 01                	mov    $0x1,%al
   3692e:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36932:	b0 01                	mov    $0x1,%al
   36934:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36938:	b0 01                	mov    $0x1,%al
   3693a:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3693e:	b0 01                	mov    $0x1,%al
   36940:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36944:	b0 01                	mov    $0x1,%al
   36946:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3694a:	b0 01                	mov    $0x1,%al
   3694c:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36950:	b0 01                	mov    $0x1,%al
   36952:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36957:	b0 01                	mov    $0x1,%al
   36959:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3695d:	41 b6 01             	mov    $0x1,%r14b
   36960:	41 b4 01             	mov    $0x1,%r12b
   36963:	41 b7 01             	mov    $0x1,%r15b
   36966:	41 b5 01             	mov    $0x1,%r13b
   36969:	ff 15 71 00 0b 00    	call   *0xb0071(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3696f:	31 ed                	xor    %ebp,%ebp
   36971:	e9 11 18 00 00       	jmp    38187 <oriole_expat::dispatch+0x4377>
   36976:	31 ed                	xor    %ebp,%ebp
   36978:	e9 0b 19 00 00       	jmp    38288 <oriole_expat::dispatch+0x4478>
   3697d:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   36984:	00 
   36985:	48 85 c9             	test   %rcx,%rcx
   36988:	74 18                	je     369a2 <oriole_expat::dispatch+0x2b92>
   3698a:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   36991:	00 
   36992:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   36997:	ba 01 00 00 00       	mov    $0x1,%edx
   3699c:	ff 15 3e 00 0b 00    	call   *0xb003e(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   369a2:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   369a9:	00 
   369aa:	48 85 c9             	test   %rcx,%rcx
   369ad:	0f 84 3c 18 00 00    	je     381ef <oriole_expat::dispatch+0x43df>
   369b3:	b0 01                	mov    $0x1,%al
   369b5:	89 44 24 38          	mov    %eax,0x38(%rsp)
   369b9:	45 31 ff             	xor    %r15d,%r15d
   369bc:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   369c3:	00 
   369c4:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   369cb:	00 
   369cc:	ba 01 00 00 00       	mov    $0x1,%edx
   369d1:	b0 01                	mov    $0x1,%al
   369d3:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   369d7:	b0 01                	mov    $0x1,%al
   369d9:	89 44 24 30          	mov    %eax,0x30(%rsp)
   369dd:	b0 01                	mov    $0x1,%al
   369df:	89 44 24 48          	mov    %eax,0x48(%rsp)
   369e3:	b0 01                	mov    $0x1,%al
   369e5:	89 44 24 14          	mov    %eax,0x14(%rsp)
   369e9:	b0 01                	mov    $0x1,%al
   369eb:	89 44 24 10          	mov    %eax,0x10(%rsp)
   369ef:	b0 01                	mov    $0x1,%al
   369f1:	89 44 24 40          	mov    %eax,0x40(%rsp)
   369f5:	b0 01                	mov    $0x1,%al
   369f7:	89 44 24 08          	mov    %eax,0x8(%rsp)
   369fb:	b0 01                	mov    $0x1,%al
   369fd:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36a01:	b0 01                	mov    $0x1,%al
   36a03:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36a07:	b0 01                	mov    $0x1,%al
   36a09:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36a0e:	b0 01                	mov    $0x1,%al
   36a10:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36a14:	41 b6 01             	mov    $0x1,%r14b
   36a17:	41 b4 01             	mov    $0x1,%r12b
   36a1a:	41 b5 01             	mov    $0x1,%r13b
   36a1d:	ff 15 bd ff 0a 00    	call   *0xaffbd(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36a23:	31 ed                	xor    %ebp,%ebp
   36a25:	e9 c7 17 00 00       	jmp    381f1 <oriole_expat::dispatch+0x43e1>
   36a2a:	31 c0                	xor    %eax,%eax
   36a2c:	e9 af 0b 00 00       	jmp    375e0 <oriole_expat::dispatch+0x37d0>
   36a31:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   36a38:	00 
   36a39:	48 85 c9             	test   %rcx,%rcx
   36a3c:	74 1b                	je     36a59 <oriole_expat::dispatch+0x2c49>
   36a3e:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   36a45:	00 
   36a46:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36a4d:	00 
   36a4e:	ba 01 00 00 00       	mov    $0x1,%edx
   36a53:	ff 15 87 ff 0a 00    	call   *0xaff87(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36a59:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   36a60:	00 
   36a61:	48 85 c9             	test   %rcx,%rcx
   36a64:	0f 84 d2 17 00 00    	je     3823c <oriole_expat::dispatch+0x442c>
   36a6a:	b0 01                	mov    $0x1,%al
   36a6c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36a70:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   36a77:	00 
   36a78:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   36a7f:	00 
   36a80:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   36a87:	00 
   36a88:	ba 01 00 00 00       	mov    $0x1,%edx
   36a8d:	b0 01                	mov    $0x1,%al
   36a8f:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36a93:	b0 01                	mov    $0x1,%al
   36a95:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36a99:	b0 01                	mov    $0x1,%al
   36a9b:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36a9f:	b0 01                	mov    $0x1,%al
   36aa1:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36aa5:	b0 01                	mov    $0x1,%al
   36aa7:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36aab:	b0 01                	mov    $0x1,%al
   36aad:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36ab1:	b0 01                	mov    $0x1,%al
   36ab3:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36ab7:	b0 01                	mov    $0x1,%al
   36ab9:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36abd:	b0 01                	mov    $0x1,%al
   36abf:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36ac4:	b0 01                	mov    $0x1,%al
   36ac6:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36aca:	41 b6 01             	mov    $0x1,%r14b
   36acd:	41 b4 01             	mov    $0x1,%r12b
   36ad0:	41 b7 01             	mov    $0x1,%r15b
   36ad3:	41 b5 01             	mov    $0x1,%r13b
   36ad6:	ff 15 04 ff 0a 00    	call   *0xaff04(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36adc:	31 ed                	xor    %ebp,%ebp
   36ade:	e9 5b 17 00 00       	jmp    3823e <oriole_expat::dispatch+0x442e>
   36ae3:	b0 01                	mov    $0x1,%al
   36ae5:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36ae9:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   36af0:	00 
   36af1:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   36af8:	00 
   36af9:	b0 01                	mov    $0x1,%al
   36afb:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36aff:	b0 01                	mov    $0x1,%al
   36b01:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36b05:	b0 01                	mov    $0x1,%al
   36b07:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36b0b:	b0 01                	mov    $0x1,%al
   36b0d:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36b11:	b0 01                	mov    $0x1,%al
   36b13:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36b17:	b0 01                	mov    $0x1,%al
   36b19:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36b1d:	b0 01                	mov    $0x1,%al
   36b1f:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36b23:	b0 01                	mov    $0x1,%al
   36b25:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36b29:	b0 01                	mov    $0x1,%al
   36b2b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36b30:	b0 01                	mov    $0x1,%al
   36b32:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36b36:	41 b6 01             	mov    $0x1,%r14b
   36b39:	41 b4 01             	mov    $0x1,%r12b
   36b3c:	41 b7 01             	mov    $0x1,%r15b
   36b3f:	41 b5 01             	mov    $0x1,%r13b
   36b42:	e8 39 b7 ff ff       	call   32280 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   36b47:	b0 01                	mov    $0x1,%al
   36b49:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36b4d:	b0 01                	mov    $0x1,%al
   36b4f:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36b53:	b0 01                	mov    $0x1,%al
   36b55:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36b59:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   36b60:	00 
   36b61:	b0 01                	mov    $0x1,%al
   36b63:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36b67:	b0 01                	mov    $0x1,%al
   36b69:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36b6d:	b0 01                	mov    $0x1,%al
   36b6f:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36b73:	b0 01                	mov    $0x1,%al
   36b75:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36b79:	b0 01                	mov    $0x1,%al
   36b7b:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36b7f:	b0 01                	mov    $0x1,%al
   36b81:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36b85:	b0 01                	mov    $0x1,%al
   36b87:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36b8b:	b0 01                	mov    $0x1,%al
   36b8d:	89 44 24 18          	mov    %eax,0x18(%rsp)
   36b91:	b0 01                	mov    $0x1,%al
   36b93:	89 44 24 20          	mov    %eax,0x20(%rsp)
   36b97:	b0 01                	mov    $0x1,%al
   36b99:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   36b9d:	e9 ed eb ff ff       	jmp    3578f <oriole_expat::dispatch+0x197f>
   36ba2:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   36ba7:	e8 84 87 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36bac:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   36bb3:	00 
   36bb4:	48 85 c9             	test   %rcx,%rcx
   36bb7:	0f 84 9c 16 00 00    	je     38259 <oriole_expat::dispatch+0x4449>
   36bbd:	b0 01                	mov    $0x1,%al
   36bbf:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36bc3:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   36bca:	00 
   36bcb:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   36bd2:	00 
   36bd3:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36bda:	00 
   36bdb:	ba 01 00 00 00       	mov    $0x1,%edx
   36be0:	b0 01                	mov    $0x1,%al
   36be2:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36be6:	b0 01                	mov    $0x1,%al
   36be8:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36bec:	b0 01                	mov    $0x1,%al
   36bee:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36bf2:	b0 01                	mov    $0x1,%al
   36bf4:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36bf8:	b0 01                	mov    $0x1,%al
   36bfa:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36bfe:	b0 01                	mov    $0x1,%al
   36c00:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36c04:	b0 01                	mov    $0x1,%al
   36c06:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36c0a:	b0 01                	mov    $0x1,%al
   36c0c:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36c10:	b0 01                	mov    $0x1,%al
   36c12:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36c17:	b0 01                	mov    $0x1,%al
   36c19:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36c1d:	41 b6 01             	mov    $0x1,%r14b
   36c20:	41 b4 01             	mov    $0x1,%r12b
   36c23:	41 b7 01             	mov    $0x1,%r15b
   36c26:	41 b5 01             	mov    $0x1,%r13b
   36c29:	ff 15 b1 fd 0a 00    	call   *0xafdb1(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36c2f:	31 ed                	xor    %ebp,%ebp
   36c31:	e9 41 18 00 00       	jmp    38477 <oriole_expat::dispatch+0x4667>
   36c36:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   36c3b:	e8 f0 86 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36c40:	b0 01                	mov    $0x1,%al
   36c42:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36c46:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   36c4d:	00 
   36c4e:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36c55:	00 
   36c56:	b0 01                	mov    $0x1,%al
   36c58:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36c5c:	b0 01                	mov    $0x1,%al
   36c5e:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36c62:	b0 01                	mov    $0x1,%al
   36c64:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36c68:	b0 01                	mov    $0x1,%al
   36c6a:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36c6e:	b0 01                	mov    $0x1,%al
   36c70:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36c74:	b0 01                	mov    $0x1,%al
   36c76:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36c7a:	b0 01                	mov    $0x1,%al
   36c7c:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36c80:	b0 01                	mov    $0x1,%al
   36c82:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36c86:	b0 01                	mov    $0x1,%al
   36c88:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36c8d:	b0 01                	mov    $0x1,%al
   36c8f:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36c93:	41 b6 01             	mov    $0x1,%r14b
   36c96:	41 b4 01             	mov    $0x1,%r12b
   36c99:	41 b7 01             	mov    $0x1,%r15b
   36c9c:	41 b5 01             	mov    $0x1,%r13b
   36c9f:	e8 8c 86 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36ca4:	e9 78 1b 00 00       	jmp    38821 <oriole_expat::dispatch+0x4a11>
   36ca9:	b0 01                	mov    $0x1,%al
   36cab:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36caf:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   36cb6:	00 00 
   36cb8:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   36cbd:	b0 01                	mov    $0x1,%al
   36cbf:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36cc3:	b0 01                	mov    $0x1,%al
   36cc5:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36cc9:	b0 01                	mov    $0x1,%al
   36ccb:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36ccf:	b0 01                	mov    $0x1,%al
   36cd1:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36cd5:	b0 01                	mov    $0x1,%al
   36cd7:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36cdb:	b0 01                	mov    $0x1,%al
   36cdd:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36ce1:	b0 01                	mov    $0x1,%al
   36ce3:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36ce7:	b0 01                	mov    $0x1,%al
   36ce9:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36ced:	b0 01                	mov    $0x1,%al
   36cef:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36cf3:	b0 01                	mov    $0x1,%al
   36cf5:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36cf9:	41 b6 01             	mov    $0x1,%r14b
   36cfc:	41 b4 01             	mov    $0x1,%r12b
   36cff:	41 b7 01             	mov    $0x1,%r15b
   36d02:	41 b5 01             	mov    $0x1,%r13b
   36d05:	e8 26 86 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36d0a:	e9 d4 11 00 00       	jmp    37ee3 <oriole_expat::dispatch+0x40d3>
   36d0f:	0f b6 ab 60 0b 00 00 	movzbl 0xb60(%rbx),%ebp
   36d16:	c6 83 60 0b 00 00 00 	movb   $0x0,0xb60(%rbx)
   36d1d:	e9 0c ea ff ff       	jmp    3572e <oriole_expat::dispatch+0x191e>
   36d22:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   36d29:	00 
   36d2a:	48 85 c9             	test   %rcx,%rcx
   36d2d:	74 1b                	je     36d4a <oriole_expat::dispatch+0x2f3a>
   36d2f:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   36d36:	00 
   36d37:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36d3e:	00 
   36d3f:	ba 01 00 00 00       	mov    $0x1,%edx
   36d44:	ff 15 96 fc 0a 00    	call   *0xafc96(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36d4a:	b0 01                	mov    $0x1,%al
   36d4c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36d50:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   36d57:	00 
   36d58:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   36d5f:	00 
   36d60:	b0 01                	mov    $0x1,%al
   36d62:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36d66:	b0 01                	mov    $0x1,%al
   36d68:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36d6c:	b0 01                	mov    $0x1,%al
   36d6e:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36d72:	b0 01                	mov    $0x1,%al
   36d74:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36d78:	b0 01                	mov    $0x1,%al
   36d7a:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36d7e:	b0 01                	mov    $0x1,%al
   36d80:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36d84:	b0 01                	mov    $0x1,%al
   36d86:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36d8a:	b0 01                	mov    $0x1,%al
   36d8c:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36d90:	b0 01                	mov    $0x1,%al
   36d92:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36d97:	b0 01                	mov    $0x1,%al
   36d99:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36d9d:	41 b6 01             	mov    $0x1,%r14b
   36da0:	41 b4 01             	mov    $0x1,%r12b
   36da3:	41 b7 01             	mov    $0x1,%r15b
   36da6:	41 b5 01             	mov    $0x1,%r13b
   36da9:	e8 82 85 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36dae:	e9 73 12 00 00       	jmp    38026 <oriole_expat::dispatch+0x4216>
   36db3:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36db7:	b0 01                	mov    $0x1,%al
   36db9:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36dbd:	b0 01                	mov    $0x1,%al
   36dbf:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36dc3:	b0 01                	mov    $0x1,%al
   36dc5:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36dc9:	b0 01                	mov    $0x1,%al
   36dcb:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36dcf:	b0 01                	mov    $0x1,%al
   36dd1:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36dd5:	b0 01                	mov    $0x1,%al
   36dd7:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36ddb:	b0 01                	mov    $0x1,%al
   36ddd:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36de1:	b0 01                	mov    $0x1,%al
   36de3:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36de7:	b1 01                	mov    $0x1,%cl
   36de9:	b2 01                	mov    $0x1,%dl
   36deb:	b0 01                	mov    $0x1,%al
   36ded:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36df1:	b0 01                	mov    $0x1,%al
   36df3:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36df7:	b0 01                	mov    $0x1,%al
   36df9:	89 44 24 18          	mov    %eax,0x18(%rsp)
   36dfd:	b0 01                	mov    $0x1,%al
   36dff:	89 44 24 20          	mov    %eax,0x20(%rsp)
   36e03:	b0 01                	mov    $0x1,%al
   36e05:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   36e09:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   36e0e:	89 4c 24 28          	mov    %ecx,0x28(%rsp)
   36e12:	83 bc 24 08 05 00 00 	cmpl   $0xffffffff,0x508(%rsp)
   36e19:	ff 
   36e1a:	0f 85 20 07 00 00    	jne    37540 <oriole_expat::dispatch+0x3730>
   36e20:	e9 43 07 00 00       	jmp    37568 <oriole_expat::dispatch+0x3758>
   36e25:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   36e2c:	00 
   36e2d:	48 85 c9             	test   %rcx,%rcx
   36e30:	0f 84 66 13 00 00    	je     3819c <oriole_expat::dispatch+0x438c>
   36e36:	b0 01                	mov    $0x1,%al
   36e38:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36e3c:	45 31 ed             	xor    %r13d,%r13d
   36e3f:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   36e46:	00 
   36e47:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   36e4c:	ba 01 00 00 00       	mov    $0x1,%edx
   36e51:	b0 01                	mov    $0x1,%al
   36e53:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36e57:	b0 01                	mov    $0x1,%al
   36e59:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36e5d:	b0 01                	mov    $0x1,%al
   36e5f:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36e63:	b0 01                	mov    $0x1,%al
   36e65:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36e69:	b0 01                	mov    $0x1,%al
   36e6b:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36e6f:	b0 01                	mov    $0x1,%al
   36e71:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36e75:	b0 01                	mov    $0x1,%al
   36e77:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36e7b:	b0 01                	mov    $0x1,%al
   36e7d:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36e81:	b0 01                	mov    $0x1,%al
   36e83:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36e87:	b0 01                	mov    $0x1,%al
   36e89:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36e8e:	b0 01                	mov    $0x1,%al
   36e90:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36e94:	41 b6 01             	mov    $0x1,%r14b
   36e97:	41 b4 01             	mov    $0x1,%r12b
   36e9a:	41 b7 01             	mov    $0x1,%r15b
   36e9d:	ff 15 3d fb 0a 00    	call   *0xafb3d(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36ea3:	31 ed                	xor    %ebp,%ebp
   36ea5:	e9 f4 12 00 00       	jmp    3819e <oriole_expat::dispatch+0x438e>
   36eaa:	80 bb 21 08 00 00 01 	cmpb   $0x1,0x821(%rbx)
   36eb1:	75 07                	jne    36eba <oriole_expat::dispatch+0x30aa>
   36eb3:	c6 83 21 08 00 00 02 	movb   $0x2,0x821(%rbx)
   36eba:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36ec1:	00 
   36ec2:	e8 69 84 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36ec7:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   36ece:	00 
   36ecf:	e8 5c 84 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36ed4:	b0 01                	mov    $0x1,%al
   36ed6:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36eda:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   36ee1:	00 
   36ee2:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   36ee9:	00 
   36eea:	b0 01                	mov    $0x1,%al
   36eec:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36ef0:	b0 01                	mov    $0x1,%al
   36ef2:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36ef6:	b0 01                	mov    $0x1,%al
   36ef8:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36efc:	b0 01                	mov    $0x1,%al
   36efe:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36f02:	b0 01                	mov    $0x1,%al
   36f04:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36f08:	b0 01                	mov    $0x1,%al
   36f0a:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36f0e:	b0 01                	mov    $0x1,%al
   36f10:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36f14:	b0 01                	mov    $0x1,%al
   36f16:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36f1a:	b0 01                	mov    $0x1,%al
   36f1c:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36f21:	b0 01                	mov    $0x1,%al
   36f23:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36f27:	41 b6 01             	mov    $0x1,%r14b
   36f2a:	41 b4 01             	mov    $0x1,%r12b
   36f2d:	41 b7 01             	mov    $0x1,%r15b
   36f30:	41 b5 01             	mov    $0x1,%r13b
   36f33:	e8 f8 83 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36f38:	31 ed                	xor    %ebp,%ebp
   36f3a:	b0 01                	mov    $0x1,%al
   36f3c:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   36f43:	00 
   36f44:	b1 01                	mov    $0x1,%cl
   36f46:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   36f4a:	b1 01                	mov    $0x1,%cl
   36f4c:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   36f50:	b1 01                	mov    $0x1,%cl
   36f52:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   36f56:	b1 01                	mov    $0x1,%cl
   36f58:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   36f5c:	b1 01                	mov    $0x1,%cl
   36f5e:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   36f62:	e9 ed e7 ff ff       	jmp    35754 <oriole_expat::dispatch+0x1944>
   36f67:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   36f6e:	00 
   36f6f:	e8 bc 83 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36f74:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   36f7b:	00 
   36f7c:	e8 af 83 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36f81:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   36f88:	00 
   36f89:	48 85 c9             	test   %rcx,%rcx
   36f8c:	0f 84 ce 12 00 00    	je     38260 <oriole_expat::dispatch+0x4450>
   36f92:	b0 01                	mov    $0x1,%al
   36f94:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36f98:	45 31 e4             	xor    %r12d,%r12d
   36f9b:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   36fa2:	00 
   36fa3:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   36faa:	00 
   36fab:	ba 01 00 00 00       	mov    $0x1,%edx
   36fb0:	b0 01                	mov    $0x1,%al
   36fb2:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36fb6:	b0 01                	mov    $0x1,%al
   36fb8:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36fbc:	b0 01                	mov    $0x1,%al
   36fbe:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36fc2:	b0 01                	mov    $0x1,%al
   36fc4:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36fc8:	b0 01                	mov    $0x1,%al
   36fca:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36fce:	b0 01                	mov    $0x1,%al
   36fd0:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36fd4:	b0 01                	mov    $0x1,%al
   36fd6:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36fda:	b0 01                	mov    $0x1,%al
   36fdc:	89 44 24 04          	mov    %eax,0x4(%rsp)
   36fe0:	b0 01                	mov    $0x1,%al
   36fe2:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36fe6:	b0 01                	mov    $0x1,%al
   36fe8:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   36fed:	b0 01                	mov    $0x1,%al
   36fef:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36ff3:	41 b6 01             	mov    $0x1,%r14b
   36ff6:	41 b7 01             	mov    $0x1,%r15b
   36ff9:	41 b5 01             	mov    $0x1,%r13b
   36ffc:	ff 15 de f9 0a 00    	call   *0xaf9de(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37002:	31 ed                	xor    %ebp,%ebp
   37004:	e9 9c 1b 00 00       	jmp    38ba5 <oriole_expat::dispatch+0x4d95>
   37009:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   37010:	00 
   37011:	e8 1a 83 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37016:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   3701d:	00 
   3701e:	e8 0d 83 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37023:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   3702a:	00 
   3702b:	48 85 c9             	test   %rcx,%rcx
   3702e:	0f 84 33 12 00 00    	je     38267 <oriole_expat::dispatch+0x4457>
   37034:	b0 01                	mov    $0x1,%al
   37036:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3703a:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   37041:	00 
   37042:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   37049:	00 
   3704a:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   37051:	00 
   37052:	ba 01 00 00 00       	mov    $0x1,%edx
   37057:	b0 01                	mov    $0x1,%al
   37059:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3705d:	b0 01                	mov    $0x1,%al
   3705f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37063:	b0 01                	mov    $0x1,%al
   37065:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37069:	b0 01                	mov    $0x1,%al
   3706b:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3706f:	b0 01                	mov    $0x1,%al
   37071:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37075:	b0 01                	mov    $0x1,%al
   37077:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3707b:	b0 01                	mov    $0x1,%al
   3707d:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37081:	b0 01                	mov    $0x1,%al
   37083:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37087:	b0 01                	mov    $0x1,%al
   37089:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3708e:	b0 01                	mov    $0x1,%al
   37090:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37094:	41 b6 01             	mov    $0x1,%r14b
   37097:	41 b4 01             	mov    $0x1,%r12b
   3709a:	41 b7 01             	mov    $0x1,%r15b
   3709d:	41 b5 01             	mov    $0x1,%r13b
   370a0:	ff 15 3a f9 0a 00    	call   *0xaf93a(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   370a6:	31 ed                	xor    %ebp,%ebp
   370a8:	e9 6b 21 00 00       	jmp    39218 <oriole_expat::dispatch+0x5408>
   370ad:	41 b6 01             	mov    $0x1,%r14b
   370b0:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   370b7:	00 
   370b8:	41 b5 01             	mov    $0x1,%r13b
   370bb:	e8 70 82 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   370c0:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   370c7:	00 
   370c8:	48 85 c9             	test   %rcx,%rcx
   370cb:	74 1e                	je     370eb <oriole_expat::dispatch+0x32db>
   370cd:	41 b5 01             	mov    $0x1,%r13b
   370d0:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   370d7:	00 
   370d8:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   370df:	00 
   370e0:	ba 01 00 00 00       	mov    $0x1,%edx
   370e5:	ff 15 f5 f8 0a 00    	call   *0xaf8f5(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   370eb:	48 8b 8c 24 b8 04 00 	mov    0x4b8(%rsp),%rcx
   370f2:	00 
   370f3:	48 85 c9             	test   %rcx,%rcx
   370f6:	74 1b                	je     37113 <oriole_expat::dispatch+0x3303>
   370f8:	48 8b b4 24 b0 04 00 	mov    0x4b0(%rsp),%rsi
   370ff:	00 
   37100:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
   37107:	00 
   37108:	ba 01 00 00 00       	mov    $0x1,%edx
   3710d:	ff 15 cd f8 0a 00    	call   *0xaf8cd(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37113:	48 8b 8c 24 f8 04 00 	mov    0x4f8(%rsp),%rcx
   3711a:	00 
   3711b:	48 85 c9             	test   %rcx,%rcx
   3711e:	0f 84 4a 11 00 00    	je     3826e <oriole_expat::dispatch+0x445e>
   37124:	b0 01                	mov    $0x1,%al
   37126:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3712a:	45 31 f6             	xor    %r14d,%r14d
   3712d:	48 8b b4 24 f0 04 00 	mov    0x4f0(%rsp),%rsi
   37134:	00 
   37135:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
   3713c:	00 
   3713d:	ba 01 00 00 00       	mov    $0x1,%edx
   37142:	b0 01                	mov    $0x1,%al
   37144:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   37148:	b0 01                	mov    $0x1,%al
   3714a:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3714e:	b0 01                	mov    $0x1,%al
   37150:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37154:	b0 01                	mov    $0x1,%al
   37156:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3715a:	b0 01                	mov    $0x1,%al
   3715c:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37160:	b0 01                	mov    $0x1,%al
   37162:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37166:	b0 01                	mov    $0x1,%al
   37168:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3716c:	b0 01                	mov    $0x1,%al
   3716e:	89 44 24 04          	mov    %eax,0x4(%rsp)
   37172:	b0 01                	mov    $0x1,%al
   37174:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37178:	b0 01                	mov    $0x1,%al
   3717a:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3717f:	b0 01                	mov    $0x1,%al
   37181:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37185:	41 b4 01             	mov    $0x1,%r12b
   37188:	41 b7 01             	mov    $0x1,%r15b
   3718b:	41 b5 01             	mov    $0x1,%r13b
   3718e:	ff 15 4c f8 0a 00    	call   *0xaf84c(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37194:	31 ed                	xor    %ebp,%ebp
   37196:	e9 f8 21 00 00       	jmp    39393 <oriole_expat::dispatch+0x5583>
   3719b:	48 39 0a             	cmp    %rcx,(%rdx)
   3719e:	0f 94 c1             	sete   %cl
   371a1:	89 4c 24 58          	mov    %ecx,0x58(%rsp)
   371a5:	0f b6 8c 24 1e 01 00 	movzbl 0x11e(%rsp),%ecx
   371ac:	00 
   371ad:	08 8c 24 68 04 00 00 	or     %cl,0x468(%rsp)
   371b4:	48 89 94 24 18 02 00 	mov    %rdx,0x218(%rsp)
   371bb:	00 
   371bc:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   371c1:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   371c6:	0f b6 84 24 1f 01 00 	movzbl 0x11f(%rsp),%eax
   371cd:	00 
   371ce:	34 01                	xor    $0x1,%al
   371d0:	20 84 24 80 04 00 00 	and    %al,0x480(%rsp)
   371d7:	4c 8d 6b 08          	lea    0x8(%rbx),%r13
   371db:	48 8d ac 24 49 03 00 	lea    0x349(%rsp),%rbp
   371e2:	00 
   371e3:	4c 8d a4 24 49 06 00 	lea    0x649(%rsp),%r12
   371ea:	00 
   371eb:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
   371f0:	4c 8d 35 59 58 00 00 	lea    0x5859(%rip),%r14        # 3ca50 <<oriole_expat::DtdFragments as core::iter::traits::iterator::Iterator>::next>
   371f7:	4c 89 ff             	mov    %r15,%rdi
   371fa:	41 ff d6             	call   *%r14
   371fd:	48 85 c0             	test   %rax,%rax
   37200:	0f 84 f3 02 00 00    	je     374f9 <oriole_expat::dispatch+0x36e9>
   37206:	80 bc 24 68 04 00 00 	cmpb   $0x0,0x468(%rsp)
   3720d:	00 
   3720e:	0f 84 9a 00 00 00    	je     372ae <oriole_expat::dispatch+0x349e>
   37214:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
   37219:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
   3721e:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
   37225:	00 
   37226:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   3722d:	00 
   3722e:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   37235:	00 
   37236:	48 89 c6             	mov    %rax,%rsi
   37239:	48 8d 8c 24 a0 00 00 	lea    0xa0(%rsp),%rcx
   37240:	00 
   37241:	ff 15 c1 f7 0a 00    	call   *0xaf7c1(%rip)        # e6a08 <_GLOBAL_OFFSET_TABLE_+0x160>
   37247:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   3724e:	00 
   3724f:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   37256:	00 
   37257:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3725b:	0f 84 4c 0b 00 00    	je     37dad <oriole_expat::dispatch+0x3f9d>
   37261:	0f 10 45 00          	movups 0x0(%rbp),%xmm0
   37265:	0f 10 4d 10          	movups 0x10(%rbp),%xmm1
   37269:	0f 10 55 1f          	movups 0x1f(%rbp),%xmm2
   3726d:	41 0f 11 54 24 1f    	movups %xmm2,0x1f(%r12)
   37273:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
   37279:	41 0f 11 04 24       	movups %xmm0,(%r12)
   3727e:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
   37285:	00 
   37286:	88 8c 24 48 06 00 00 	mov    %cl,0x648(%rsp)
   3728d:	48 8d bb 20 0b 00 00 	lea    0xb20(%rbx),%rdi
   37294:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
   3729b:	00 
   3729c:	e8 1f 4b 00 00       	call   3bdc0 <<oriole_storage::queue::Queue<oriole_storage::string::String>>::try_push_back>
   372a1:	3c ff                	cmp    $0xff,%al
   372a3:	0f 84 4e ff ff ff    	je     371f7 <oriole_expat::dispatch+0x33e7>
   372a9:	e9 04 0b 00 00       	jmp    37db2 <oriole_expat::dispatch+0x3fa2>
   372ae:	48 85 d2             	test   %rdx,%rdx
   372b1:	0f 84 40 ff ff ff    	je     371f7 <oriole_expat::dispatch+0x33e7>
   372b7:	48 8d 0c 10          	lea    (%rax,%rdx,1),%rcx
   372bb:	48 89 c6             	mov    %rax,%rsi
   372be:	eb 29                	jmp    372e9 <oriole_expat::dispatch+0x34d9>
   372c0:	40 0f b6 ff          	movzbl %dil,%edi
   372c4:	4c 8d 05 01 d0 fd ff 	lea    -0x22fff(%rip),%r8        # 142cc <core::unicode::unicode_data::white_space::WHITESPACE_MAP>
   372cb:	41 0f b6 3c 38       	movzbl (%r8,%rdi,1),%edi
   372d0:	40 d0 ef             	shr    $1,%dil
   372d3:	40 f6 c7 01          	test   $0x1,%dil
   372d7:	0f 84 3f 01 00 00    	je     3741c <oriole_expat::dispatch+0x360c>
   372dd:	0f 1f 00             	nopl   (%rax)
   372e0:	48 39 ce             	cmp    %rcx,%rsi
   372e3:	0f 84 0e ff ff ff    	je     371f7 <oriole_expat::dispatch+0x33e7>
   372e9:	0f b6 3e             	movzbl (%rsi),%edi
   372ec:	40 84 ff             	test   %dil,%dil
   372ef:	78 1f                	js     37310 <oriole_expat::dispatch+0x3500>
   372f1:	48 ff c6             	inc    %rsi
   372f4:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   372f8:	41 83 f8 05          	cmp    $0x5,%r8d
   372fc:	72 e2                	jb     372e0 <oriole_expat::dispatch+0x34d0>
   372fe:	e9 ad 00 00 00       	jmp    373b0 <oriole_expat::dispatch+0x35a0>
   37303:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   3730a:	84 00 00 00 00 00 
   37310:	41 89 f8             	mov    %edi,%r8d
   37313:	41 83 e0 1f          	and    $0x1f,%r8d
   37317:	44 0f b6 56 01       	movzbl 0x1(%rsi),%r10d
   3731c:	41 83 e2 3f          	and    $0x3f,%r10d
   37320:	40 80 ff df          	cmp    $0xdf,%dil
   37324:	76 43                	jbe    37369 <oriole_expat::dispatch+0x3559>
   37326:	44 0f b6 4e 02       	movzbl 0x2(%rsi),%r9d
   3732b:	41 c1 e2 06          	shl    $0x6,%r10d
   3732f:	41 83 e1 3f          	and    $0x3f,%r9d
   37333:	45 09 d1             	or     %r10d,%r9d
   37336:	40 80 ff f0          	cmp    $0xf0,%dil
   3733a:	72 4b                	jb     37387 <oriole_expat::dispatch+0x3577>
   3733c:	0f b6 7e 03          	movzbl 0x3(%rsi),%edi
   37340:	48 83 c6 04          	add    $0x4,%rsi
   37344:	41 83 e0 07          	and    $0x7,%r8d
   37348:	41 c1 e0 12          	shl    $0x12,%r8d
   3734c:	41 c1 e1 06          	shl    $0x6,%r9d
   37350:	83 e7 3f             	and    $0x3f,%edi
   37353:	44 09 cf             	or     %r9d,%edi
   37356:	44 09 c7             	or     %r8d,%edi
   37359:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   3735d:	41 83 f8 05          	cmp    $0x5,%r8d
   37361:	0f 82 79 ff ff ff    	jb     372e0 <oriole_expat::dispatch+0x34d0>
   37367:	eb 47                	jmp    373b0 <oriole_expat::dispatch+0x35a0>
   37369:	48 83 c6 02          	add    $0x2,%rsi
   3736d:	41 c1 e0 06          	shl    $0x6,%r8d
   37371:	45 09 d0             	or     %r10d,%r8d
   37374:	44 89 c7             	mov    %r8d,%edi
   37377:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   3737b:	41 83 f8 05          	cmp    $0x5,%r8d
   3737f:	0f 82 5b ff ff ff    	jb     372e0 <oriole_expat::dispatch+0x34d0>
   37385:	eb 29                	jmp    373b0 <oriole_expat::dispatch+0x35a0>
   37387:	48 83 c6 03          	add    $0x3,%rsi
   3738b:	41 c1 e0 0c          	shl    $0xc,%r8d
   3738f:	45 09 c1             	or     %r8d,%r9d
   37392:	44 89 cf             	mov    %r9d,%edi
   37395:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   37399:	41 83 f8 05          	cmp    $0x5,%r8d
   3739d:	0f 82 3d ff ff ff    	jb     372e0 <oriole_expat::dispatch+0x34d0>
   373a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   373aa:	84 00 00 00 00 00 
   373b0:	83 ff 20             	cmp    $0x20,%edi
   373b3:	0f 84 27 ff ff ff    	je     372e0 <oriole_expat::dispatch+0x34d0>
   373b9:	81 ff 85 00 00 00    	cmp    $0x85,%edi
   373bf:	72 5b                	jb     3741c <oriole_expat::dispatch+0x360c>
   373c1:	41 89 f8             	mov    %edi,%r8d
   373c4:	41 c1 e8 08          	shr    $0x8,%r8d
   373c8:	41 83 f8 1f          	cmp    $0x1f,%r8d
   373cc:	7f 1a                	jg     373e8 <oriole_expat::dispatch+0x35d8>
   373ce:	45 85 c0             	test   %r8d,%r8d
   373d1:	74 34                	je     37407 <oriole_expat::dispatch+0x35f7>
   373d3:	41 83 f8 16          	cmp    $0x16,%r8d
   373d7:	75 43                	jne    3741c <oriole_expat::dispatch+0x360c>
   373d9:	81 ff 80 16 00 00    	cmp    $0x1680,%edi
   373df:	40 0f 94 c7          	sete   %dil
   373e3:	e9 eb fe ff ff       	jmp    372d3 <oriole_expat::dispatch+0x34c3>
   373e8:	41 83 f8 20          	cmp    $0x20,%r8d
   373ec:	0f 84 ce fe ff ff    	je     372c0 <oriole_expat::dispatch+0x34b0>
   373f2:	41 83 f8 30          	cmp    $0x30,%r8d
   373f6:	75 24                	jne    3741c <oriole_expat::dispatch+0x360c>
   373f8:	81 ff 00 30 00 00    	cmp    $0x3000,%edi
   373fe:	40 0f 94 c7          	sete   %dil
   37402:	e9 cc fe ff ff       	jmp    372d3 <oriole_expat::dispatch+0x34c3>
   37407:	40 0f b6 ff          	movzbl %dil,%edi
   3740b:	4c 8d 05 ba ce fd ff 	lea    -0x23146(%rip),%r8        # 142cc <core::unicode::unicode_data::white_space::WHITESPACE_MAP>
   37412:	41 0f b6 3c 38       	movzbl (%r8,%rdi,1),%edi
   37417:	e9 b7 fe ff ff       	jmp    372d3 <oriole_expat::dispatch+0x34c3>
   3741c:	48 83 fa 01          	cmp    $0x1,%rdx
   37420:	74 1a                	je     3743c <oriole_expat::dispatch+0x362c>
   37422:	48 83 fa 08          	cmp    $0x8,%rdx
   37426:	75 1d                	jne    37445 <oriole_expat::dispatch+0x3635>
   37428:	48 b9 3c 21 45 4e 54 	movabs $0x595449544e45213c,%rcx
   3742f:	49 54 59 
   37432:	48 39 08             	cmp    %rcx,(%rax)
   37435:	75 0e                	jne    37445 <oriole_expat::dispatch+0x3635>
   37437:	e9 bb fd ff ff       	jmp    371f7 <oriole_expat::dispatch+0x33e7>
   3743c:	80 38 25             	cmpb   $0x25,(%rax)
   3743f:	0f 84 b2 fd ff ff    	je     371f7 <oriole_expat::dispatch+0x33e7>
   37445:	f6 44 24 58 01       	testb  $0x1,0x58(%rsp)
   3744a:	74 0d                	je     37459 <oriole_expat::dispatch+0x3649>
   3744c:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   37453:	00 
   37454:	e9 bb fd ff ff       	jmp    37214 <oriole_expat::dispatch+0x3404>
   37459:	48 83 fa 01          	cmp    $0x1,%rdx
   3745d:	74 77                	je     374d6 <oriole_expat::dispatch+0x36c6>
   3745f:	48 83 fa 06          	cmp    $0x6,%rdx
   37463:	74 26                	je     3748b <oriole_expat::dispatch+0x367b>
   37465:	48 83 fa 05          	cmp    $0x5,%rdx
   37469:	75 e1                	jne    3744c <oriole_expat::dispatch+0x363c>
   3746b:	8b 08                	mov    (%rax),%ecx
   3746d:	be 4e 44 41 54       	mov    $0x5441444e,%esi
   37472:	31 f1                	xor    %esi,%ecx
   37474:	0f b6 70 04          	movzbl 0x4(%rax),%esi
   37478:	83 f6 41             	xor    $0x41,%esi
   3747b:	40 b7 01             	mov    $0x1,%dil
   3747e:	89 7c 24 58          	mov    %edi,0x58(%rsp)
   37482:	09 ce                	or     %ecx,%esi
   37484:	75 c6                	jne    3744c <oriole_expat::dispatch+0x363c>
   37486:	e9 6c fd ff ff       	jmp    371f7 <oriole_expat::dispatch+0x33e7>
   3748b:	8b 08                	mov    (%rax),%ecx
   3748d:	be 53 59 53 54       	mov    $0x54535953,%esi
   37492:	31 f1                	xor    %esi,%ecx
   37494:	0f b7 70 04          	movzwl 0x4(%rax),%esi
   37498:	81 f6 45 4d 00 00    	xor    $0x4d45,%esi
   3749e:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   374a5:	00 
   374a6:	09 ce                	or     %ecx,%esi
   374a8:	0f 84 49 fd ff ff    	je     371f7 <oriole_expat::dispatch+0x33e7>
   374ae:	8b 08                	mov    (%rax),%ecx
   374b0:	be 50 55 42 4c       	mov    $0x4c425550,%esi
   374b5:	31 f1                	xor    %esi,%ecx
   374b7:	0f b7 70 04          	movzwl 0x4(%rax),%esi
   374bb:	81 f6 49 43 00 00    	xor    $0x4349,%esi
   374c1:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   374c8:	00 
   374c9:	09 ce                	or     %ecx,%esi
   374cb:	0f 85 43 fd ff ff    	jne    37214 <oriole_expat::dispatch+0x3404>
   374d1:	e9 21 fd ff ff       	jmp    371f7 <oriole_expat::dispatch+0x33e7>
   374d6:	80 38 3e             	cmpb   $0x3e,(%rax)
   374d9:	0f 95 c1             	setne  %cl
   374dc:	0a 8c 24 80 04 00 00 	or     0x480(%rsp),%cl
   374e3:	c7 44 24 58 00 00 00 	movl   $0x0,0x58(%rsp)
   374ea:	00 
   374eb:	f6 c1 01             	test   $0x1,%cl
   374ee:	0f 84 03 fd ff ff    	je     371f7 <oriole_expat::dispatch+0x33e7>
   374f4:	e9 1b fd ff ff       	jmp    37214 <oriole_expat::dispatch+0x3404>
   374f9:	48 89 df             	mov    %rbx,%rdi
   374fc:	e8 ff bb ff ff       	call   33100 <oriole_expat::drain_default_fragments>
   37501:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   37508:	00 
   37509:	48 85 c9             	test   %rcx,%rcx
   3750c:	48 8b b4 24 18 02 00 	mov    0x218(%rsp),%rsi
   37513:	00 
   37514:	74 13                	je     37529 <oriole_expat::dispatch+0x3719>
   37516:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3751d:	00 
   3751e:	ba 01 00 00 00       	mov    $0x1,%edx
   37523:	ff 15 b7 f4 0a 00    	call   *0xaf4b7(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37529:	b1 01                	mov    $0x1,%cl
   3752b:	b2 01                	mov    $0x1,%dl
   3752d:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   37532:	89 4c 24 28          	mov    %ecx,0x28(%rsp)
   37536:	83 bc 24 08 05 00 00 	cmpl   $0xffffffff,0x508(%rsp)
   3753d:	ff 
   3753e:	74 28                	je     37568 <oriole_expat::dispatch+0x3758>
   37540:	48 8b 8c 24 30 05 00 	mov    0x530(%rsp),%rcx
   37547:	00 
   37548:	48 85 c9             	test   %rcx,%rcx
   3754b:	74 1b                	je     37568 <oriole_expat::dispatch+0x3758>
   3754d:	48 8b b4 24 28 05 00 	mov    0x528(%rsp),%rsi
   37554:	00 
   37555:	48 8d bc 24 08 05 00 	lea    0x508(%rsp),%rdi
   3755c:	00 
   3755d:	ba 01 00 00 00       	mov    $0x1,%edx
   37562:	ff 15 78 f4 0a 00    	call   *0xaf478(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37568:	41 b5 ff             	mov    $0xff,%r13b
   3756b:	e9 38 1c 00 00       	jmp    391a8 <oriole_expat::dispatch+0x5398>
   37570:	4c 89 ee             	mov    %r13,%rsi
   37573:	48 83 e6 fc          	and    $0xfffffffffffffffc,%rsi
   37577:	49 8d bc 24 d8 01 00 	lea    0x1d8(%r12),%rdi
   3757e:	00 
   3757f:	31 d2                	xor    %edx,%edx
   37581:	31 c0                	xor    %eax,%eax
   37583:	44 0f b6 87 98 fe ff 	movzbl -0x168(%rdi),%r8d
   3758a:	ff 
   3758b:	49 01 c0             	add    %rax,%r8
   3758e:	0f b6 87 10 ff ff ff 	movzbl -0xf0(%rdi),%eax
   37595:	44 0f b6 4f 88       	movzbl -0x78(%rdi),%r9d
   3759a:	49 01 c1             	add    %rax,%r9
   3759d:	4d 01 c1             	add    %r8,%r9
   375a0:	0f b6 07             	movzbl (%rdi),%eax
   375a3:	4c 01 c8             	add    %r9,%rax
   375a6:	48 83 c2 04          	add    $0x4,%rdx
   375aa:	48 81 c7 e0 01 00 00 	add    $0x1e0,%rdi
   375b1:	48 39 d6             	cmp    %rdx,%rsi
   375b4:	75 cd                	jne    37583 <oriole_expat::dispatch+0x3773>
   375b6:	48 85 c9             	test   %rcx,%rcx
   375b9:	74 25                	je     375e0 <oriole_expat::dispatch+0x37d0>
   375bb:	48 6b d2 78          	imul   $0x78,%rdx,%rdx
   375bf:	4c 01 e2             	add    %r12,%rdx
   375c2:	48 83 c2 70          	add    $0x70,%rdx
   375c6:	48 6b c9 78          	imul   $0x78,%rcx,%rcx
   375ca:	31 f6                	xor    %esi,%esi
   375cc:	0f 1f 40 00          	nopl   0x0(%rax)
   375d0:	0f b6 3c 32          	movzbl (%rdx,%rsi,1),%edi
   375d4:	48 01 f8             	add    %rdi,%rax
   375d7:	48 83 c6 78          	add    $0x78,%rsi
   375db:	48 39 f1             	cmp    %rsi,%rcx
   375de:	75 f0                	jne    375d0 <oriole_expat::dispatch+0x37c0>
   375e0:	48 01 c0             	add    %rax,%rax
   375e3:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
   375e9:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
   375ee:	48 0f 42 c8          	cmovb  %rax,%rcx
   375f2:	89 8b 40 0a 00 00    	mov    %ecx,0xa40(%rbx)
   375f8:	48 83 bc 24 60 04 00 	cmpq   $0x0,0x460(%rsp)
   375ff:	00 00 
   37601:	0f 84 39 01 00 00    	je     37740 <oriole_expat::dispatch+0x3930>
   37607:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   3760e:	00 
   3760f:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   37616:	00 
   37617:	31 ff                	xor    %edi,%edi
   37619:	e8 f2 53 00 00       	call   3ca10 <core::slice::memchr::memchr>
   3761e:	40 b5 03             	mov    $0x3,%bpl
   37621:	48 83 f8 01          	cmp    $0x1,%rax
   37625:	74 17                	je     3763e <oriole_expat::dispatch+0x382e>
   37627:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3762c:	31 f6                	xor    %esi,%esi
   3762e:	ff 15 fc f3 0a 00    	call   *0xaf3fc(%rip)        # e6a30 <_GLOBAL_OFFSET_TABLE_+0x188>
   37634:	89 c5                	mov    %eax,%ebp
   37636:	3c ff                	cmp    $0xff,%al
   37638:	0f 84 b3 0c 00 00    	je     382f1 <oriole_expat::dispatch+0x44e1>
   3763e:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   37645:	00 
   37646:	e8 05 8a ff ff       	call   30050 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3764b:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   37652:	00 
   37653:	48 85 c9             	test   %rcx,%rcx
   37656:	74 6f                	je     376c7 <oriole_expat::dispatch+0x38b7>
   37658:	b0 01                	mov    $0x1,%al
   3765a:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3765e:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   37665:	00 
   37666:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3766b:	ba 01 00 00 00       	mov    $0x1,%edx
   37670:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
   37677:	00 
   37678:	b0 01                	mov    $0x1,%al
   3767a:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3767e:	b0 01                	mov    $0x1,%al
   37680:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37684:	b0 01                	mov    $0x1,%al
   37686:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3768a:	b0 01                	mov    $0x1,%al
   3768c:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37690:	b0 01                	mov    $0x1,%al
   37692:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37696:	b0 01                	mov    $0x1,%al
   37698:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3769c:	b0 01                	mov    $0x1,%al
   3769e:	89 44 24 04          	mov    %eax,0x4(%rsp)
   376a2:	b0 01                	mov    $0x1,%al
   376a4:	89 44 24 28          	mov    %eax,0x28(%rsp)
   376a8:	b0 01                	mov    $0x1,%al
   376aa:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   376af:	b0 01                	mov    $0x1,%al
   376b1:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   376b5:	41 b6 01             	mov    $0x1,%r14b
   376b8:	41 b4 01             	mov    $0x1,%r12b
   376bb:	41 b7 01             	mov    $0x1,%r15b
   376be:	41 b5 01             	mov    $0x1,%r13b
   376c1:	ff 15 19 f3 0a 00    	call   *0xaf319(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   376c7:	b0 01                	mov    $0x1,%al
   376c9:	89 44 24 48          	mov    %eax,0x48(%rsp)
   376cd:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
   376d4:	00 
   376d5:	b0 01                	mov    $0x1,%al
   376d7:	89 44 24 30          	mov    %eax,0x30(%rsp)
   376db:	b0 01                	mov    $0x1,%al
   376dd:	89 44 24 38          	mov    %eax,0x38(%rsp)
   376e1:	b0 01                	mov    $0x1,%al
   376e3:	89 44 24 14          	mov    %eax,0x14(%rsp)
   376e7:	b0 01                	mov    $0x1,%al
   376e9:	89 44 24 10          	mov    %eax,0x10(%rsp)
   376ed:	b0 01                	mov    $0x1,%al
   376ef:	89 44 24 40          	mov    %eax,0x40(%rsp)
   376f3:	b0 01                	mov    $0x1,%al
   376f5:	89 44 24 08          	mov    %eax,0x8(%rsp)
   376f9:	b0 01                	mov    $0x1,%al
   376fb:	89 44 24 04          	mov    %eax,0x4(%rsp)
   376ff:	b0 01                	mov    $0x1,%al
   37701:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37705:	b0 01                	mov    $0x1,%al
   37707:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3770c:	b0 01                	mov    $0x1,%al
   3770e:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37712:	b0 01                	mov    $0x1,%al
   37714:	89 44 24 24          	mov    %eax,0x24(%rsp)
   37718:	b0 01                	mov    $0x1,%al
   3771a:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3771e:	b0 01                	mov    $0x1,%al
   37720:	89 44 24 20          	mov    %eax,0x20(%rsp)
   37724:	b0 01                	mov    $0x1,%al
   37726:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3772a:	41 89 ed             	mov    %ebp,%r13d
   3772d:	83 bc 24 08 05 00 00 	cmpl   $0xffffffff,0x508(%rsp)
   37734:	ff 
   37735:	0f 85 de 16 00 00    	jne    38e19 <oriole_expat::dispatch+0x5009>
   3773b:	e9 01 17 00 00       	jmp    38e41 <oriole_expat::dispatch+0x5031>
   37740:	31 ed                	xor    %ebp,%ebp
   37742:	48 8d 7b 30          	lea    0x30(%rbx),%rdi
   37746:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   3774d:	00 
   3774e:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
   37755:	00 
   37756:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
   3775b:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
   37760:	0f 28 94 24 80 00 00 	movaps 0x80(%rsp),%xmm2
   37767:	00 
   37768:	0f 29 94 24 40 02 00 	movaps %xmm2,0x240(%rsp)
   3776f:	00 
   37770:	0f 29 8c 24 30 02 00 	movaps %xmm1,0x230(%rsp)
   37777:	00 
   37778:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   3777f:	00 
   37780:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   37787:	00 
   37788:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   3778f:	00 
   37790:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
   37797:	00 
   37798:	0f 28 8c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm1
   3779f:	00 
   377a0:	0f 28 94 24 c0 00 00 	movaps 0xc0(%rsp),%xmm2
   377a7:	00 
   377a8:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   377af:	00 
   377b0:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   377b7:	00 
   377b8:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   377bf:	00 
   377c0:	48 8d 94 24 20 02 00 	lea    0x220(%rsp),%rdx
   377c7:	00 
   377c8:	48 8d 8c 24 40 03 00 	lea    0x340(%rsp),%rcx
   377cf:	00 
   377d0:	48 8b b4 24 78 05 00 	mov    0x578(%rsp),%rsi
   377d7:	00 
   377d8:	ff 15 b2 f1 0a 00    	call   *0xaf1b2(%rip)        # e6990 <_GLOBAL_OFFSET_TABLE_+0xe8>
   377de:	b0 01                	mov    $0x1,%al
   377e0:	89 44 24 14          	mov    %eax,0x14(%rsp)
   377e4:	31 c0                	xor    %eax,%eax
   377e6:	e9 5d 0a 00 00       	jmp    38248 <oriole_expat::dispatch+0x4438>
   377eb:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   377f2:	00 
   377f3:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   377fa:	00 
   377fb:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   37802:	00 
   37803:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   3780a:	00 
   3780b:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   37812:	00 
   37813:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   3781a:	00 
   3781b:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   37822:	00 
   37823:	44 88 ac 24 a8 00 00 	mov    %r13b,0xa8(%rsp)
   3782a:	00 
   3782b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3782f:	0f 84 c8 05 00 00    	je     37dfd <oriole_expat::dispatch+0x3fed>
   37835:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
   3783c:	00 
   3783d:	e9 bd 05 00 00       	jmp    37dff <oriole_expat::dispatch+0x3fef>
   37842:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   37849:	00 
   3784a:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   37851:	00 
   37852:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   37859:	00 
   3785a:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   37861:	00 
   37862:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   37869:	00 
   3786a:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   37871:	00 
   37872:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   37879:	00 
   3787a:	44 88 ac 24 a8 00 00 	mov    %r13b,0xa8(%rsp)
   37881:	00 
   37882:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37886:	0f 84 f0 05 00 00    	je     37e7c <oriole_expat::dispatch+0x406c>
   3788c:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   37893:	00 
   37894:	e9 e5 05 00 00       	jmp    37e7e <oriole_expat::dispatch+0x406e>
   37899:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   378a0:	00 
   378a1:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   378a8:	00 
   378a9:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   378b0:	00 
   378b1:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   378b8:	00 
   378b9:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   378be:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   378c3:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   378c8:	44 88 6c 24 68       	mov    %r13b,0x68(%rsp)
   378cd:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   378d1:	0f 84 4b 06 00 00    	je     37f22 <oriole_expat::dispatch+0x4112>
   378d7:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
   378de:	00 
   378df:	e9 41 06 00 00       	jmp    37f25 <oriole_expat::dispatch+0x4115>
   378e4:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   378eb:	00 
   378ec:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   378f3:	00 
   378f4:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   378fb:	00 
   378fc:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   37903:	00 
   37904:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   37909:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   3790e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   37913:	44 88 6c 24 68       	mov    %r13b,0x68(%rsp)
   37918:	45 31 ff             	xor    %r15d,%r15d
   3791b:	41 bd 00 00 00 00    	mov    $0x0,%r13d
   37921:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37925:	74 08                	je     3792f <oriole_expat::dispatch+0x3b1f>
   37927:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
   3792e:	00 
   3792f:	83 bc 24 08 05 00 00 	cmpl   $0xffffffff,0x508(%rsp)
   37936:	ff 
   37937:	74 08                	je     37941 <oriole_expat::dispatch+0x3b31>
   37939:	4c 8b bc 24 28 05 00 	mov    0x528(%rsp),%r15
   37940:	00 
   37941:	40 b5 01             	mov    $0x1,%bpl
   37944:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3794b:	00 
   3794c:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
   37953:	00 
   37954:	e8 67 b4 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   37959:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   37960:	00 
   37961:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   37968:	00 
   37969:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   3796d:	0f 85 35 07 00 00    	jne    380a8 <oriole_expat::dispatch+0x4298>
   37973:	41 89 cd             	mov    %ecx,%r13d
   37976:	31 ed                	xor    %ebp,%ebp
   37978:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3797d:	e8 ae 79 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37982:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   37989:	00 
   3798a:	e8 a1 79 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3798f:	e9 17 0f 00 00       	jmp    388ab <oriole_expat::dispatch+0x4a9b>
   37994:	b0 01                	mov    $0x1,%al
   37996:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3799a:	b0 01                	mov    $0x1,%al
   3799c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   379a0:	b0 01                	mov    $0x1,%al
   379a2:	89 44 24 30          	mov    %eax,0x30(%rsp)
   379a6:	b0 01                	mov    $0x1,%al
   379a8:	89 44 24 48          	mov    %eax,0x48(%rsp)
   379ac:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   379b3:	00 
   379b4:	e9 85 07 00 00       	jmp    3813e <oriole_expat::dispatch+0x432e>
   379b9:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   379c0:	00 
   379c1:	48 85 c9             	test   %rcx,%rcx
   379c4:	74 18                	je     379de <oriole_expat::dispatch+0x3bce>
   379c6:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   379cd:	00 
   379ce:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   379d3:	ba 01 00 00 00       	mov    $0x1,%edx
   379d8:	ff 15 02 f0 0a 00    	call   *0xaf002(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   379de:	b0 01                	mov    $0x1,%al
   379e0:	89 44 24 38          	mov    %eax,0x38(%rsp)
   379e4:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   379eb:	00 
   379ec:	b0 01                	mov    $0x1,%al
   379ee:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   379f2:	b0 01                	mov    $0x1,%al
   379f4:	89 44 24 30          	mov    %eax,0x30(%rsp)
   379f8:	b0 01                	mov    $0x1,%al
   379fa:	89 44 24 48          	mov    %eax,0x48(%rsp)
   379fe:	b0 01                	mov    $0x1,%al
   37a00:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37a04:	b0 01                	mov    $0x1,%al
   37a06:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37a0a:	b0 01                	mov    $0x1,%al
   37a0c:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37a10:	b0 01                	mov    $0x1,%al
   37a12:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37a16:	b0 01                	mov    $0x1,%al
   37a18:	89 44 24 04          	mov    %eax,0x4(%rsp)
   37a1c:	b0 01                	mov    $0x1,%al
   37a1e:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37a22:	b0 01                	mov    $0x1,%al
   37a24:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   37a29:	b0 01                	mov    $0x1,%al
   37a2b:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37a2f:	b0 01                	mov    $0x1,%al
   37a31:	89 44 24 24          	mov    %eax,0x24(%rsp)
   37a35:	b0 01                	mov    $0x1,%al
   37a37:	89 44 24 18          	mov    %eax,0x18(%rsp)
   37a3b:	e9 c8 0e 00 00       	jmp    38908 <oriole_expat::dispatch+0x4af8>
   37a40:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   37a47:	00 
   37a48:	48 85 c9             	test   %rcx,%rcx
   37a4b:	0f 84 cd 06 00 00    	je     3811e <oriole_expat::dispatch+0x430e>
   37a51:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   37a58:	00 
   37a59:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   37a60:	00 
   37a61:	ba 01 00 00 00       	mov    $0x1,%edx
   37a66:	ff 15 74 ef 0a 00    	call   *0xaef74(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37a6c:	e9 ad 06 00 00       	jmp    3811e <oriole_expat::dispatch+0x430e>
   37a71:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   37a76:	e8 b5 78 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37a7b:	b0 01                	mov    $0x1,%al
   37a7d:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37a81:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   37a88:	00 
   37a89:	b0 01                	mov    $0x1,%al
   37a8b:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   37a8f:	b0 01                	mov    $0x1,%al
   37a91:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37a95:	b0 01                	mov    $0x1,%al
   37a97:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37a9b:	b0 01                	mov    $0x1,%al
   37a9d:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37aa1:	e9 9e 06 00 00       	jmp    38144 <oriole_expat::dispatch+0x4334>
   37aa6:	b0 01                	mov    $0x1,%al
   37aa8:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37aac:	c7 44 24 1c 00 00 00 	movl   $0x0,0x1c(%rsp)
   37ab3:	00 
   37ab4:	b0 01                	mov    $0x1,%al
   37ab6:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   37aba:	b0 01                	mov    $0x1,%al
   37abc:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37ac0:	b0 01                	mov    $0x1,%al
   37ac2:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37ac6:	b0 01                	mov    $0x1,%al
   37ac8:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37acc:	b0 01                	mov    $0x1,%al
   37ace:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37ad2:	b0 01                	mov    $0x1,%al
   37ad4:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37ad8:	b0 01                	mov    $0x1,%al
   37ada:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37ade:	b0 01                	mov    $0x1,%al
   37ae0:	89 44 24 04          	mov    %eax,0x4(%rsp)
   37ae4:	b0 01                	mov    $0x1,%al
   37ae6:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37aea:	b0 01                	mov    $0x1,%al
   37aec:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   37af1:	b0 01                	mov    $0x1,%al
   37af3:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37af7:	b0 01                	mov    $0x1,%al
   37af9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   37afd:	b0 01                	mov    $0x1,%al
   37aff:	89 44 24 18          	mov    %eax,0x18(%rsp)
   37b03:	b0 01                	mov    $0x1,%al
   37b05:	89 44 24 20          	mov    %eax,0x20(%rsp)
   37b09:	83 bc 24 08 05 00 00 	cmpl   $0xffffffff,0x508(%rsp)
   37b10:	ff 
   37b11:	0f 85 02 13 00 00    	jne    38e19 <oriole_expat::dispatch+0x5009>
   37b17:	e9 25 13 00 00       	jmp    38e41 <oriole_expat::dispatch+0x5031>
   37b1c:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   37b23:	00 
   37b24:	e8 07 78 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37b29:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   37b30:	00 
   37b31:	e8 fa 77 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37b36:	e9 c1 09 00 00       	jmp    384fc <oriole_expat::dispatch+0x46ec>
   37b3b:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   37b42:	00 
   37b43:	e8 e8 77 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37b48:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   37b4f:	00 
   37b50:	e8 db 77 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37b55:	e9 58 0b 00 00       	jmp    386b2 <oriole_expat::dispatch+0x48a2>
   37b5a:	89 cb                	mov    %ecx,%ebx
   37b5c:	41 b6 01             	mov    $0x1,%r14b
   37b5f:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   37b66:	00 
   37b67:	41 b5 01             	mov    $0x1,%r13b
   37b6a:	e8 c1 77 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37b6f:	41 b5 01             	mov    $0x1,%r13b
   37b72:	e9 47 19 00 00       	jmp    394be <oriole_expat::dispatch+0x56ae>
   37b77:	48 8b 94 24 28 02 00 	mov    0x228(%rsp),%rdx
   37b7e:	00 
   37b7f:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   37b86:	00 
   37b87:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   37b8c:	ff d5                	call   *%rbp
   37b8e:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   37b95:	00 
   37b96:	48 85 c9             	test   %rcx,%rcx
   37b99:	74 1b                	je     37bb6 <oriole_expat::dispatch+0x3da6>
   37b9b:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   37ba2:	00 
   37ba3:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   37baa:	00 
   37bab:	ba 01 00 00 00       	mov    $0x1,%edx
   37bb0:	ff 15 2a ee 0a 00    	call   *0xaee2a(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37bb6:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   37bbd:	00 
   37bbe:	48 85 c9             	test   %rcx,%rcx
   37bc1:	74 18                	je     37bdb <oriole_expat::dispatch+0x3dcb>
   37bc3:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   37bca:	00 
   37bcb:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   37bd0:	ba 01 00 00 00       	mov    $0x1,%edx
   37bd5:	ff 15 05 ee 0a 00    	call   *0xaee05(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37bdb:	40 b5 01             	mov    $0x1,%bpl
   37bde:	e9 0e 06 00 00       	jmp    381f1 <oriole_expat::dispatch+0x43e1>
   37be3:	45 31 e4             	xor    %r12d,%r12d
   37be6:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
   37bed:	00 
   37bee:	40 b5 01             	mov    $0x1,%bpl
   37bf1:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   37bf8:	00 
   37bf9:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
   37c00:	00 
   37c01:	e8 ba b1 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   37c06:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   37c0d:	00 
   37c0e:	44 0f b6 ac 24 48 03 	movzbl 0x348(%rsp),%r13d
   37c15:	00 00 
   37c17:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   37c1b:	0f 85 8b 00 00 00    	jne    37cac <oriole_expat::dispatch+0x3e9c>
   37c21:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   37c28:	00 
   37c29:	48 85 c9             	test   %rcx,%rcx
   37c2c:	74 15                	je     37c43 <oriole_expat::dispatch+0x3e33>
   37c2e:	31 ed                	xor    %ebp,%ebp
   37c30:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   37c35:	ba 01 00 00 00       	mov    $0x1,%edx
   37c3a:	4c 89 fe             	mov    %r15,%rsi
   37c3d:	ff 15 9d ed 0a 00    	call   *0xaed9d(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37c43:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   37c4a:	00 
   37c4b:	e8 e0 76 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37c50:	e9 a7 08 00 00       	jmp    384fc <oriole_expat::dispatch+0x46ec>
   37c55:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   37c5c:	00 
   37c5d:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   37c64:	00 
   37c65:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   37c6c:	00 
   37c6d:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   37c74:	00 
   37c75:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   37c7c:	00 
   37c7d:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   37c84:	00 
   37c85:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   37c8c:	00 
   37c8d:	44 88 ac 24 28 02 00 	mov    %r13b,0x228(%rsp)
   37c94:	00 
   37c95:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37c99:	0f 84 88 07 00 00    	je     38427 <oriole_expat::dispatch+0x4617>
   37c9f:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
   37ca6:	00 
   37ca7:	e9 7d 07 00 00       	jmp    38429 <oriole_expat::dispatch+0x4619>
   37cac:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   37cb3:	00 
   37cb4:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   37cbb:	00 
   37cbc:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   37cc3:	00 
   37cc4:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   37ccb:	00 
   37ccc:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   37cd3:	00 
   37cd4:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   37cdb:	00 
   37cdc:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   37ce3:	00 
   37ce4:	44 88 ac 24 a8 00 00 	mov    %r13b,0xa8(%rsp)
   37ceb:	00 
   37cec:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37cf0:	0f 84 a2 07 00 00    	je     38498 <oriole_expat::dispatch+0x4688>
   37cf6:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
   37cfd:	00 
   37cfe:	e9 98 07 00 00       	jmp    3849b <oriole_expat::dispatch+0x468b>
   37d03:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   37d0a:	00 
   37d0b:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   37d12:	00 
   37d13:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   37d1a:	00 
   37d1b:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   37d22:	00 
   37d23:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   37d2a:	00 
   37d2b:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   37d32:	00 
   37d33:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   37d3a:	00 
   37d3b:	44 88 ac 24 a8 00 00 	mov    %r13b,0xa8(%rsp)
   37d42:	00 
   37d43:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37d47:	0f 84 03 09 00 00    	je     38650 <oriole_expat::dispatch+0x4840>
   37d4d:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
   37d54:	00 
   37d55:	e9 f9 08 00 00       	jmp    38653 <oriole_expat::dispatch+0x4843>
   37d5a:	40 b5 01             	mov    $0x1,%bpl
   37d5d:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   37d64:	00 
   37d65:	41 b4 01             	mov    $0x1,%r12b
   37d68:	41 b5 01             	mov    $0x1,%r13b
   37d6b:	41 b6 01             	mov    $0x1,%r14b
   37d6e:	e8 bd 75 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37d73:	41 b4 01             	mov    $0x1,%r12b
   37d76:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
   37d7d:	00 
   37d7e:	41 b5 01             	mov    $0x1,%r13b
   37d81:	41 b6 01             	mov    $0x1,%r14b
   37d84:	e8 a7 75 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37d89:	41 b5 01             	mov    $0x1,%r13b
   37d8c:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
   37d93:	00 
   37d94:	41 b6 01             	mov    $0x1,%r14b
   37d97:	e8 94 75 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37d9c:	31 ed                	xor    %ebp,%ebp
   37d9e:	e9 d0 18 00 00       	jmp    39673 <oriole_expat::dispatch+0x5863>
   37da3:	89 cb                	mov    %ecx,%ebx
   37da5:	41 b6 01             	mov    $0x1,%r14b
   37da8:	e9 08 06 00 00       	jmp    383b5 <oriole_expat::dispatch+0x45a5>
   37dad:	41 89 cd             	mov    %ecx,%r13d
   37db0:	eb 03                	jmp    37db5 <oriole_expat::dispatch+0x3fa5>
   37db2:	41 89 c5             	mov    %eax,%r13d
   37db5:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   37dbc:	00 
   37dbd:	48 85 c9             	test   %rcx,%rcx
   37dc0:	74 1b                	je     37ddd <oriole_expat::dispatch+0x3fcd>
   37dc2:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   37dc9:	00 
   37dca:	ba 01 00 00 00       	mov    $0x1,%edx
   37dcf:	48 8b b4 24 18 02 00 	mov    0x218(%rsp),%rsi
   37dd6:	00 
   37dd7:	ff 15 03 ec 0a 00    	call   *0xaec03(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37ddd:	b0 01                	mov    $0x1,%al
   37ddf:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37de3:	b0 01                	mov    $0x1,%al
   37de5:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   37dea:	83 bc 24 08 05 00 00 	cmpl   $0xffffffff,0x508(%rsp)
   37df1:	ff 
   37df2:	0f 85 21 10 00 00    	jne    38e19 <oriole_expat::dispatch+0x5009>
   37df8:	e9 44 10 00 00       	jmp    38e41 <oriole_expat::dispatch+0x5031>
   37dfd:	31 db                	xor    %ebx,%ebx
   37dff:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   37e06:	00 
   37e07:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
   37e0c:	e8 af af ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   37e11:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   37e18:	00 
   37e19:	44 0f b6 ac 24 48 03 	movzbl 0x348(%rsp),%r13d
   37e20:	00 00 
   37e22:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   37e26:	0f 85 25 02 00 00    	jne    38051 <oriole_expat::dispatch+0x4241>
   37e2c:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   37e33:	00 
   37e34:	e8 f7 74 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37e39:	b0 01                	mov    $0x1,%al
   37e3b:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37e3f:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   37e46:	00 
   37e47:	b0 01                	mov    $0x1,%al
   37e49:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   37e4d:	b0 01                	mov    $0x1,%al
   37e4f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37e53:	b0 01                	mov    $0x1,%al
   37e55:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37e59:	b0 01                	mov    $0x1,%al
   37e5b:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37e5f:	b0 01                	mov    $0x1,%al
   37e61:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37e65:	b0 01                	mov    $0x1,%al
   37e67:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37e6b:	b0 01                	mov    $0x1,%al
   37e6d:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37e71:	b0 01                	mov    $0x1,%al
   37e73:	89 44 24 04          	mov    %eax,0x4(%rsp)
   37e77:	e9 6d 0a 00 00       	jmp    388e9 <oriole_expat::dispatch+0x4ad9>
   37e7c:	31 f6                	xor    %esi,%esi
   37e7e:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   37e83:	ff d3                	call   *%rbx
   37e85:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   37e8c:	00 
   37e8d:	b0 01                	mov    $0x1,%al
   37e8f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37e93:	b0 01                	mov    $0x1,%al
   37e95:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37e99:	b0 01                	mov    $0x1,%al
   37e9b:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37e9f:	b0 01                	mov    $0x1,%al
   37ea1:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37ea5:	b0 01                	mov    $0x1,%al
   37ea7:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37eab:	b0 01                	mov    $0x1,%al
   37ead:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37eb1:	b0 01                	mov    $0x1,%al
   37eb3:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37eb7:	b0 01                	mov    $0x1,%al
   37eb9:	89 44 24 04          	mov    %eax,0x4(%rsp)
   37ebd:	b0 01                	mov    $0x1,%al
   37ebf:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37ec3:	b0 01                	mov    $0x1,%al
   37ec5:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37ec9:	41 b6 01             	mov    $0x1,%r14b
   37ecc:	41 b4 01             	mov    $0x1,%r12b
   37ecf:	41 b7 01             	mov    $0x1,%r15b
   37ed2:	41 b5 01             	mov    $0x1,%r13b
   37ed5:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   37edc:	00 00 
   37ede:	e8 4d 74 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37ee3:	b0 01                	mov    $0x1,%al
   37ee5:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37ee9:	31 d2                	xor    %edx,%edx
   37eeb:	b0 01                	mov    $0x1,%al
   37eed:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   37ef1:	b0 01                	mov    $0x1,%al
   37ef3:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37ef7:	b0 01                	mov    $0x1,%al
   37ef9:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37efd:	b0 01                	mov    $0x1,%al
   37eff:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37f03:	b0 01                	mov    $0x1,%al
   37f05:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37f09:	b0 01                	mov    $0x1,%al
   37f0b:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37f0f:	b0 01                	mov    $0x1,%al
   37f11:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37f15:	b0 01                	mov    $0x1,%al
   37f17:	89 44 24 04          	mov    %eax,0x4(%rsp)
   37f1b:	b1 01                	mov    $0x1,%cl
   37f1d:	e9 c9 ee ff ff       	jmp    36deb <oriole_expat::dispatch+0x2fdb>
   37f22:	45 31 ff             	xor    %r15d,%r15d
   37f25:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
   37f2c:	00 
   37f2d:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   37f34:	00 
   37f35:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   37f3c:	00 
   37f3d:	0f 28 8c 24 f0 00 00 	movaps 0xf0(%rsp),%xmm1
   37f44:	00 
   37f45:	0f 28 94 24 00 01 00 	movaps 0x100(%rsp),%xmm2
   37f4c:	00 
   37f4d:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   37f54:	00 
   37f55:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   37f5c:	00 
   37f5d:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   37f64:	00 
   37f65:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   37f6c:	00 
   37f6d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
   37f74:	00 
   37f75:	ff 15 35 eb 0a 00    	call   *0xaeb35(%rip)        # e6ab0 <_GLOBAL_OFFSET_TABLE_+0x208>
   37f7b:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   37f82:	00 
   37f83:	44 0f b6 ac 24 28 02 	movzbl 0x228(%rsp),%r13d
   37f8a:	00 00 
   37f8c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37f90:	0f 84 40 04 00 00    	je     383d6 <oriole_expat::dispatch+0x45c6>
   37f96:	0f 10 84 24 29 02 00 	movups 0x229(%rsp),%xmm0
   37f9d:	00 
   37f9e:	0f 10 8c 24 39 02 00 	movups 0x239(%rsp),%xmm1
   37fa5:	00 
   37fa6:	0f 10 94 24 48 02 00 	movups 0x248(%rsp),%xmm2
   37fad:	00 
   37fae:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   37fb5:	00 
   37fb6:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   37fbd:	00 
   37fbe:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   37fc5:	00 
   37fc6:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   37fcd:	00 
   37fce:	44 88 ac 24 a8 00 00 	mov    %r13b,0xa8(%rsp)
   37fd5:	00 
   37fd6:	48 8b 94 24 c0 00 00 	mov    0xc0(%rsp),%rdx
   37fdd:	00 
   37fde:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   37fe3:	4c 89 fe             	mov    %r15,%rsi
   37fe6:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
   37feb:	41 ff d6             	call   *%r14
   37fee:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   37ff5:	00 
   37ff6:	48 85 c9             	test   %rcx,%rcx
   37ff9:	74 1b                	je     38016 <oriole_expat::dispatch+0x4206>
   37ffb:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   38002:	00 
   38003:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3800a:	00 
   3800b:	ba 01 00 00 00       	mov    $0x1,%edx
   38010:	ff 15 ca e9 0a 00    	call   *0xae9ca(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38016:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3801b:	e8 10 73 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38020:	b0 01                	mov    $0x1,%al
   38022:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38026:	b0 01                	mov    $0x1,%al
   38028:	8b 6c 24 40          	mov    0x40(%rsp),%ebp
   3802c:	b1 01                	mov    $0x1,%cl
   3802e:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   38032:	b1 01                	mov    $0x1,%cl
   38034:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   38038:	b1 01                	mov    $0x1,%cl
   3803a:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   3803e:	b1 01                	mov    $0x1,%cl
   38040:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   38044:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   3804b:	00 
   3804c:	e9 fd d6 ff ff       	jmp    3574e <oriole_expat::dispatch+0x193e>
   38051:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   38058:	00 
   38059:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   38060:	00 
   38061:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   38068:	00 
   38069:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   38070:	00 
   38071:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   38078:	00 
   38079:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   38080:	00 
   38081:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   38088:	00 
   38089:	44 88 ac 24 28 02 00 	mov    %r13b,0x228(%rsp)
   38090:	00 
   38091:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38095:	0f 84 5f 07 00 00    	je     387fa <oriole_expat::dispatch+0x49ea>
   3809b:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
   380a2:	00 
   380a3:	e9 54 07 00 00       	jmp    387fc <oriole_expat::dispatch+0x49ec>
   380a8:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   380af:	00 
   380b0:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   380b7:	00 
   380b8:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   380bf:	00 
   380c0:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   380c7:	00 
   380c8:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   380cf:	00 
   380d0:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   380d7:	00 
   380d8:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   380df:	00 
   380e0:	88 8c 24 a8 00 00 00 	mov    %cl,0xa8(%rsp)
   380e7:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   380eb:	0f 84 6d 07 00 00    	je     3885e <oriole_expat::dispatch+0x4a4e>
   380f1:	48 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%rbp
   380f8:	00 
   380f9:	e9 62 07 00 00       	jmp    38860 <oriole_expat::dispatch+0x4a50>
   380fe:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   38105:	00 
   38106:	48 85 c9             	test   %rcx,%rcx
   38109:	74 13                	je     3811e <oriole_expat::dispatch+0x430e>
   3810b:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   38110:	ba 01 00 00 00       	mov    $0x1,%edx
   38115:	4c 89 fe             	mov    %r15,%rsi
   38118:	ff 15 c2 e8 0a 00    	call   *0xae8c2(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3811e:	b0 01                	mov    $0x1,%al
   38120:	89 44 24 30          	mov    %eax,0x30(%rsp)
   38124:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   3812b:	00 
   3812c:	b0 01                	mov    $0x1,%al
   3812e:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   38132:	b0 01                	mov    $0x1,%al
   38134:	89 44 24 48          	mov    %eax,0x48(%rsp)
   38138:	b0 01                	mov    $0x1,%al
   3813a:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3813e:	b0 01                	mov    $0x1,%al
   38140:	89 44 24 10          	mov    %eax,0x10(%rsp)
   38144:	b0 01                	mov    $0x1,%al
   38146:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3814a:	e9 bd 02 00 00       	jmp    3840c <oriole_expat::dispatch+0x45fc>
   3814f:	89 cb                	mov    %ecx,%ebx
   38151:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   38158:	00 
   38159:	48 85 c9             	test   %rcx,%rcx
   3815c:	74 1f                	je     3817d <oriole_expat::dispatch+0x436d>
   3815e:	40 b5 01             	mov    $0x1,%bpl
   38161:	45 31 ed             	xor    %r13d,%r13d
   38164:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3816b:	00 
   3816c:	ba 01 00 00 00       	mov    $0x1,%edx
   38171:	41 b6 01             	mov    $0x1,%r14b
   38174:	4c 89 e6             	mov    %r12,%rsi
   38177:	ff 15 63 e8 0a 00    	call   *0xae863(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3817d:	41 b6 01             	mov    $0x1,%r14b
   38180:	e9 21 13 00 00       	jmp    394a6 <oriole_expat::dispatch+0x5696>
   38185:	31 ed                	xor    %ebp,%ebp
   38187:	b0 01                	mov    $0x1,%al
   38189:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   38190:	00 
   38191:	b1 01                	mov    $0x1,%cl
   38193:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   38197:	e9 a0 d5 ff ff       	jmp    3573c <oriole_expat::dispatch+0x192c>
   3819c:	31 ed                	xor    %ebp,%ebp
   3819e:	b0 01                	mov    $0x1,%al
   381a0:	c7 44 24 1c 00 00 00 	movl   $0x0,0x1c(%rsp)
   381a7:	00 
   381a8:	b1 01                	mov    $0x1,%cl
   381aa:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   381ae:	b1 01                	mov    $0x1,%cl
   381b0:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   381b4:	b1 01                	mov    $0x1,%cl
   381b6:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   381ba:	b1 01                	mov    $0x1,%cl
   381bc:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   381c0:	b1 01                	mov    $0x1,%cl
   381c2:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   381c6:	b1 01                	mov    $0x1,%cl
   381c8:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   381cc:	b1 01                	mov    $0x1,%cl
   381ce:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   381d2:	b1 01                	mov    $0x1,%cl
   381d4:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   381d8:	b1 01                	mov    $0x1,%cl
   381da:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   381de:	b1 01                	mov    $0x1,%cl
   381e0:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
   381e4:	b1 01                	mov    $0x1,%cl
   381e6:	89 4c 24 20          	mov    %ecx,0x20(%rsp)
   381ea:	e9 89 d5 ff ff       	jmp    35778 <oriole_expat::dispatch+0x1968>
   381ef:	31 ed                	xor    %ebp,%ebp
   381f1:	b0 01                	mov    $0x1,%al
   381f3:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   381fa:	00 
   381fb:	b1 01                	mov    $0x1,%cl
   381fd:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   38201:	b1 01                	mov    $0x1,%cl
   38203:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   38207:	b1 01                	mov    $0x1,%cl
   38209:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   3820d:	b1 01                	mov    $0x1,%cl
   3820f:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   38213:	b1 01                	mov    $0x1,%cl
   38215:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   38219:	b1 01                	mov    $0x1,%cl
   3821b:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   3821f:	b1 01                	mov    $0x1,%cl
   38221:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   38225:	b1 01                	mov    $0x1,%cl
   38227:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   3822b:	b1 01                	mov    $0x1,%cl
   3822d:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   38231:	b1 01                	mov    $0x1,%cl
   38233:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
   38237:	e9 36 d5 ff ff       	jmp    35772 <oriole_expat::dispatch+0x1962>
   3823c:	31 ed                	xor    %ebp,%ebp
   3823e:	b0 01                	mov    $0x1,%al
   38240:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   38247:	00 
   38248:	b1 01                	mov    $0x1,%cl
   3824a:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   3824e:	b1 01                	mov    $0x1,%cl
   38250:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   38254:	e9 e9 d4 ff ff       	jmp    35742 <oriole_expat::dispatch+0x1932>
   38259:	31 ed                	xor    %ebp,%ebp
   3825b:	e9 17 02 00 00       	jmp    38477 <oriole_expat::dispatch+0x4667>
   38260:	31 ed                	xor    %ebp,%ebp
   38262:	e9 3e 09 00 00       	jmp    38ba5 <oriole_expat::dispatch+0x4d95>
   38267:	31 ed                	xor    %ebp,%ebp
   38269:	e9 aa 0f 00 00       	jmp    39218 <oriole_expat::dispatch+0x5408>
   3826e:	31 ed                	xor    %ebp,%ebp
   38270:	e9 1e 11 00 00       	jmp    39393 <oriole_expat::dispatch+0x5583>
   38275:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
   3827c:	00 
   3827d:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   38282:	41 ff d6             	call   *%r14
   38285:	40 b5 01             	mov    $0x1,%bpl
   38288:	48 8d 7b 30          	lea    0x30(%rbx),%rdi
   3828c:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   38293:	00 
   38294:	48 89 84 24 70 03 00 	mov    %rax,0x370(%rsp)
   3829b:	00 
   3829c:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
   382a3:	00 
   382a4:	0f 28 8c 24 30 02 00 	movaps 0x230(%rsp),%xmm1
   382ab:	00 
   382ac:	0f 28 94 24 40 02 00 	movaps 0x240(%rsp),%xmm2
   382b3:	00 
   382b4:	0f 29 94 24 60 03 00 	movaps %xmm2,0x360(%rsp)
   382bb:	00 
   382bc:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
   382c3:	00 
   382c4:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   382cb:	00 
   382cc:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
   382d3:	00 
   382d4:	48 8b b4 24 78 05 00 	mov    0x578(%rsp),%rsi
   382db:	00 
   382dc:	ff 15 9e e6 0a 00    	call   *0xae69e(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0xd8>
   382e2:	b0 01                	mov    $0x1,%al
   382e4:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   382eb:	00 
   382ec:	e9 45 d4 ff ff       	jmp    35736 <oriole_expat::dispatch+0x1926>
   382f1:	0f 10 43 08          	movups 0x8(%rbx),%xmm0
   382f5:	0f 10 4b 18          	movups 0x18(%rbx),%xmm1
   382f9:	0f 29 8c 24 30 02 00 	movaps %xmm1,0x230(%rsp)
   38300:	00 
   38301:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   38308:	00 
   38309:	0f 57 c0             	xorps  %xmm0,%xmm0
   3830c:	0f 29 84 24 b0 03 00 	movaps %xmm0,0x3b0(%rsp)
   38313:	00 
   38314:	0f 29 84 24 a0 03 00 	movaps %xmm0,0x3a0(%rsp)
   3831b:	00 
   3831c:	0f 29 84 24 90 03 00 	movaps %xmm0,0x390(%rsp)
   38323:	00 
   38324:	0f 29 84 24 80 03 00 	movaps %xmm0,0x380(%rsp)
   3832b:	00 
   3832c:	0f 29 84 24 70 03 00 	movaps %xmm0,0x370(%rsp)
   38333:	00 
   38334:	0f 29 84 24 60 03 00 	movaps %xmm0,0x360(%rsp)
   3833b:	00 
   3833c:	0f 29 84 24 50 03 00 	movaps %xmm0,0x350(%rsp)
   38343:	00 
   38344:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   3834b:	00 
   3834c:	48 c7 84 24 c0 03 00 	movq   $0x0,0x3c0(%rsp)
   38353:	00 00 00 00 00 
   38358:	48 c7 84 24 40 02 00 	movq   $0x8,0x240(%rsp)
   3835f:	00 08 00 00 00 
   38364:	0f 11 84 24 48 02 00 	movups %xmm0,0x248(%rsp)
   3836b:	00 
   3836c:	4e 8d 34 6d 00 00 00 	lea    0x0(,%r13,2),%r14
   38373:	00 
   38374:	4a 8d 04 6d 01 00 00 	lea    0x1(,%r13,2),%rax
   3837b:	00 
   3837c:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   38381:	49 83 fe 12          	cmp    $0x12,%r14
   38385:	0f 83 4a 06 00 00    	jae    389d5 <oriole_expat::dispatch+0x4bc5>
   3838b:	48 8d 84 24 40 03 00 	lea    0x340(%rsp),%rax
   38392:	00 
   38393:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   38398:	b8 08 00 00 00       	mov    $0x8,%eax
   3839d:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   383a2:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   383a9:	00 00 
   383ab:	e9 d0 06 00 00       	jmp    38a80 <oriole_expat::dispatch+0x4c70>
   383b0:	89 cb                	mov    %ecx,%ebx
   383b2:	45 31 f6             	xor    %r14d,%r14d
   383b5:	40 b5 01             	mov    $0x1,%bpl
   383b8:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   383bf:	00 
   383c0:	41 b4 01             	mov    $0x1,%r12b
   383c3:	41 b5 01             	mov    $0x1,%r13b
   383c6:	e8 65 6f ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   383cb:	41 b4 01             	mov    $0x1,%r12b
   383ce:	41 b5 01             	mov    $0x1,%r13b
   383d1:	e9 1e 09 00 00       	jmp    38cf4 <oriole_expat::dispatch+0x4ee4>
   383d6:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   383db:	e8 50 6f ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   383e0:	b0 01                	mov    $0x1,%al
   383e2:	89 44 24 30          	mov    %eax,0x30(%rsp)
   383e6:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   383ed:	00 
   383ee:	b0 01                	mov    $0x1,%al
   383f0:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   383f4:	b0 01                	mov    $0x1,%al
   383f6:	89 44 24 48          	mov    %eax,0x48(%rsp)
   383fa:	b0 01                	mov    $0x1,%al
   383fc:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38400:	b0 01                	mov    $0x1,%al
   38402:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38406:	b0 01                	mov    $0x1,%al
   38408:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3840c:	b0 01                	mov    $0x1,%al
   3840e:	89 44 24 08          	mov    %eax,0x8(%rsp)
   38412:	e9 c6 04 00 00       	jmp    388dd <oriole_expat::dispatch+0x4acd>
   38417:	89 cb                	mov    %ecx,%ebx
   38419:	b0 01                	mov    $0x1,%al
   3841b:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3841f:	41 b4 01             	mov    $0x1,%r12b
   38422:	e9 7a 08 00 00       	jmp    38ca1 <oriole_expat::dispatch+0x4e91>
   38427:	31 d2                	xor    %edx,%edx
   38429:	83 fd 02             	cmp    $0x2,%ebp
   3842c:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
   38431:	0f 45 cd             	cmovne %ebp,%ecx
   38434:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   38439:	4c 89 fe             	mov    %r15,%rsi
   3843c:	41 ff d6             	call   *%r14
   3843f:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   38446:	00 
   38447:	e8 e4 6e ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3844c:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   38453:	00 
   38454:	48 85 c9             	test   %rcx,%rcx
   38457:	74 1b                	je     38474 <oriole_expat::dispatch+0x4664>
   38459:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   38460:	00 
   38461:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   38468:	00 
   38469:	ba 01 00 00 00       	mov    $0x1,%edx
   3846e:	ff 15 6c e5 0a 00    	call   *0xae56c(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38474:	40 b5 01             	mov    $0x1,%bpl
   38477:	b0 01                	mov    $0x1,%al
   38479:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   38480:	00 
   38481:	b1 01                	mov    $0x1,%cl
   38483:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   38487:	b1 01                	mov    $0x1,%cl
   38489:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   3848d:	b1 01                	mov    $0x1,%cl
   3848f:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   38493:	e9 b0 d2 ff ff       	jmp    35748 <oriole_expat::dispatch+0x1938>
   38498:	45 31 ed             	xor    %r13d,%r13d
   3849b:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   384a2:	00 
   384a3:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   384aa:	00 
   384ab:	e8 10 a9 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   384b0:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   384b7:	00 
   384b8:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   384bf:	00 
   384c0:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   384c4:	0f 85 25 02 00 00    	jne    386ef <oriole_expat::dispatch+0x48df>
   384ca:	41 89 cd             	mov    %ecx,%r13d
   384cd:	31 ed                	xor    %ebp,%ebp
   384cf:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   384d6:	00 
   384d7:	e8 54 6e ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   384dc:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   384e3:	00 
   384e4:	48 85 c9             	test   %rcx,%rcx
   384e7:	74 13                	je     384fc <oriole_expat::dispatch+0x46ec>
   384e9:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   384ee:	ba 01 00 00 00       	mov    $0x1,%edx
   384f3:	4c 89 fe             	mov    %r15,%rsi
   384f6:	ff 15 e4 e4 0a 00    	call   *0xae4e4(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   384fc:	b0 01                	mov    $0x1,%al
   384fe:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38502:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   38509:	00 
   3850a:	b0 01                	mov    $0x1,%al
   3850c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   38510:	b0 01                	mov    $0x1,%al
   38512:	89 44 24 30          	mov    %eax,0x30(%rsp)
   38516:	b0 01                	mov    $0x1,%al
   38518:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3851c:	b0 01                	mov    $0x1,%al
   3851e:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38522:	b0 01                	mov    $0x1,%al
   38524:	89 44 24 10          	mov    %eax,0x10(%rsp)
   38528:	b0 01                	mov    $0x1,%al
   3852a:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3852e:	b0 01                	mov    $0x1,%al
   38530:	89 44 24 08          	mov    %eax,0x8(%rsp)
   38534:	b0 01                	mov    $0x1,%al
   38536:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3853a:	b0 01                	mov    $0x1,%al
   3853c:	89 44 24 28          	mov    %eax,0x28(%rsp)
   38540:	b0 01                	mov    $0x1,%al
   38542:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   38547:	b0 01                	mov    $0x1,%al
   38549:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3854d:	b0 01                	mov    $0x1,%al
   3854f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   38553:	e9 aa 03 00 00       	jmp    38902 <oriole_expat::dispatch+0x4af2>
   38558:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   3855f:	00 
   38560:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   38567:	00 
   38568:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   3856f:	00 
   38570:	0f 11 94 24 08 01 00 	movups %xmm2,0x108(%rsp)
   38577:	00 
   38578:	0f 11 8c 24 f9 00 00 	movups %xmm1,0xf9(%rsp)
   3857f:	00 
   38580:	0f 11 84 24 e9 00 00 	movups %xmm0,0xe9(%rsp)
   38587:	00 
   38588:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
   3858f:	00 
   38590:	88 8c 24 e8 00 00 00 	mov    %cl,0xe8(%rsp)
   38597:	31 c9                	xor    %ecx,%ecx
   38599:	ba 00 00 00 00       	mov    $0x0,%edx
   3859e:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   385a2:	74 08                	je     385ac <oriole_expat::dispatch+0x479c>
   385a4:	48 8b 94 24 00 01 00 	mov    0x100(%rsp),%rdx
   385ab:	00 
   385ac:	83 bc 24 08 05 00 00 	cmpl   $0xffffffff,0x508(%rsp)
   385b3:	ff 
   385b4:	74 08                	je     385be <oriole_expat::dispatch+0x47ae>
   385b6:	48 8b 8c 24 28 05 00 	mov    0x528(%rsp),%rcx
   385bd:	00 
   385be:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   385c3:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
   385c8:	41 b7 01             	mov    $0x1,%r15b
   385cb:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   385d2:	00 
   385d3:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
   385da:	00 
   385db:	40 b5 01             	mov    $0x1,%bpl
   385de:	e8 dd a7 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   385e3:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   385ea:	00 
   385eb:	44 0f b6 a4 24 48 03 	movzbl 0x348(%rsp),%r12d
   385f2:	00 00 
   385f4:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   385f8:	0f 85 ec 05 00 00    	jne    38bea <oriole_expat::dispatch+0x4dda>
   385fe:	41 b7 01             	mov    $0x1,%r15b
   38601:	40 b5 01             	mov    $0x1,%bpl
   38604:	e9 d6 11 00 00       	jmp    397df <oriole_expat::dispatch+0x59cf>
   38609:	45 31 e4             	xor    %r12d,%r12d
   3860c:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
   38613:	00 
   38614:	41 b6 01             	mov    $0x1,%r14b
   38617:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3861e:	00 
   3861f:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
   38626:	00 
   38627:	e8 94 a7 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   3862c:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   38633:	00 
   38634:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   3863b:	00 
   3863c:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   38640:	0f 85 ff 00 00 00    	jne    38745 <oriole_expat::dispatch+0x4935>
   38646:	89 cb                	mov    %ecx,%ebx
   38648:	41 b6 01             	mov    $0x1,%r14b
   3864b:	e9 29 06 00 00       	jmp    38c79 <oriole_expat::dispatch+0x4e69>
   38650:	45 31 f6             	xor    %r14d,%r14d
   38653:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3865a:	00 
   3865b:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   38662:	00 
   38663:	e8 58 a7 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   38668:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   3866f:	00 
   38670:	44 0f b6 ac 24 48 03 	movzbl 0x348(%rsp),%r13d
   38677:	00 00 
   38679:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   3867d:	0f 85 18 01 00 00    	jne    3879b <oriole_expat::dispatch+0x498b>
   38683:	31 ed                	xor    %ebp,%ebp
   38685:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3868c:	00 
   3868d:	e8 9e 6c ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38692:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   38699:	00 
   3869a:	48 85 c9             	test   %rcx,%rcx
   3869d:	74 13                	je     386b2 <oriole_expat::dispatch+0x48a2>
   3869f:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   386a4:	ba 01 00 00 00       	mov    $0x1,%edx
   386a9:	4c 89 e6             	mov    %r12,%rsi
   386ac:	ff 15 2e e3 0a 00    	call   *0xae32e(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   386b2:	b0 01                	mov    $0x1,%al
   386b4:	89 44 24 48          	mov    %eax,0x48(%rsp)
   386b8:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   386bf:	00 
   386c0:	b0 01                	mov    $0x1,%al
   386c2:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   386c6:	b0 01                	mov    $0x1,%al
   386c8:	89 44 24 30          	mov    %eax,0x30(%rsp)
   386cc:	b0 01                	mov    $0x1,%al
   386ce:	89 44 24 38          	mov    %eax,0x38(%rsp)
   386d2:	b0 01                	mov    $0x1,%al
   386d4:	89 44 24 14          	mov    %eax,0x14(%rsp)
   386d8:	b0 01                	mov    $0x1,%al
   386da:	89 44 24 10          	mov    %eax,0x10(%rsp)
   386de:	b0 01                	mov    $0x1,%al
   386e0:	89 44 24 40          	mov    %eax,0x40(%rsp)
   386e4:	b0 01                	mov    $0x1,%al
   386e6:	89 44 24 08          	mov    %eax,0x8(%rsp)
   386ea:	e9 f4 01 00 00       	jmp    388e3 <oriole_expat::dispatch+0x4ad3>
   386ef:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   386f6:	00 
   386f7:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   386fe:	00 
   386ff:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   38706:	00 
   38707:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   3870e:	00 
   3870f:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   38716:	00 
   38717:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   3871e:	00 
   3871f:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   38726:	00 
   38727:	88 8c 24 28 02 00 00 	mov    %cl,0x228(%rsp)
   3872e:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38732:	0f 84 11 04 00 00    	je     38b49 <oriole_expat::dispatch+0x4d39>
   38738:	4c 8b 84 24 40 02 00 	mov    0x240(%rsp),%r8
   3873f:	00 
   38740:	e9 07 04 00 00       	jmp    38b4c <oriole_expat::dispatch+0x4d3c>
   38745:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   3874c:	00 
   3874d:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   38754:	00 
   38755:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   3875c:	00 
   3875d:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   38764:	00 
   38765:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   3876c:	00 
   3876d:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   38774:	00 
   38775:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   3877c:	00 
   3877d:	88 8c 24 a8 00 00 00 	mov    %cl,0xa8(%rsp)
   38784:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38788:	0f 84 a7 04 00 00    	je     38c35 <oriole_expat::dispatch+0x4e25>
   3878e:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
   38795:	00 
   38796:	e9 9d 04 00 00       	jmp    38c38 <oriole_expat::dispatch+0x4e28>
   3879b:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   387a2:	00 
   387a3:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   387aa:	00 
   387ab:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   387b2:	00 
   387b3:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   387ba:	00 
   387bb:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   387c2:	00 
   387c3:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   387ca:	00 
   387cb:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   387d2:	00 
   387d3:	44 88 ac 24 28 02 00 	mov    %r13b,0x228(%rsp)
   387da:	00 
   387db:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   387df:	0f 84 d8 09 00 00    	je     391bd <oriole_expat::dispatch+0x53ad>
   387e5:	48 8b 8c 24 40 02 00 	mov    0x240(%rsp),%rcx
   387ec:	00 
   387ed:	e9 cd 09 00 00       	jmp    391bf <oriole_expat::dispatch+0x53af>
   387f2:	40 b5 01             	mov    $0x1,%bpl
   387f5:	e9 4c 0c 00 00       	jmp    39446 <oriole_expat::dispatch+0x5636>
   387fa:	31 d2                	xor    %edx,%edx
   387fc:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   38801:	48 89 de             	mov    %rbx,%rsi
   38804:	41 ff d6             	call   *%r14
   38807:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3880e:	00 
   3880f:	e8 1c 6b ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38814:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3881b:	00 
   3881c:	e8 0f 6b ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38821:	b0 01                	mov    $0x1,%al
   38823:	89 44 24 48          	mov    %eax,0x48(%rsp)
   38827:	31 c9                	xor    %ecx,%ecx
   38829:	b0 01                	mov    $0x1,%al
   3882b:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3882f:	b0 01                	mov    $0x1,%al
   38831:	89 44 24 30          	mov    %eax,0x30(%rsp)
   38835:	b0 01                	mov    $0x1,%al
   38837:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3883b:	b0 01                	mov    $0x1,%al
   3883d:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38841:	b0 01                	mov    $0x1,%al
   38843:	89 44 24 10          	mov    %eax,0x10(%rsp)
   38847:	b0 01                	mov    $0x1,%al
   38849:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3884d:	b0 01                	mov    $0x1,%al
   3884f:	89 44 24 08          	mov    %eax,0x8(%rsp)
   38853:	b0 01                	mov    $0x1,%al
   38855:	89 44 24 04          	mov    %eax,0x4(%rsp)
   38859:	e9 8b e5 ff ff       	jmp    36de9 <oriole_expat::dispatch+0x2fd9>
   3885e:	31 ed                	xor    %ebp,%ebp
   38860:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   38867:	00 
   38868:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   3886f:	00 
   38870:	e8 4b a5 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   38875:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   3887c:	00 
   3887d:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   38884:	00 
   38885:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   38889:	0f 85 92 00 00 00    	jne    38921 <oriole_expat::dispatch+0x4b11>
   3888f:	41 89 cd             	mov    %ecx,%r13d
   38892:	31 ed                	xor    %ebp,%ebp
   38894:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3889b:	00 
   3889c:	e8 8f 6a ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   388a1:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   388a6:	e8 85 6a ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   388ab:	b0 01                	mov    $0x1,%al
   388ad:	89 44 24 48          	mov    %eax,0x48(%rsp)
   388b1:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   388b8:	00 
   388b9:	b0 01                	mov    $0x1,%al
   388bb:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   388bf:	b0 01                	mov    $0x1,%al
   388c1:	89 44 24 30          	mov    %eax,0x30(%rsp)
   388c5:	b0 01                	mov    $0x1,%al
   388c7:	89 44 24 38          	mov    %eax,0x38(%rsp)
   388cb:	b0 01                	mov    $0x1,%al
   388cd:	89 44 24 14          	mov    %eax,0x14(%rsp)
   388d1:	b0 01                	mov    $0x1,%al
   388d3:	89 44 24 10          	mov    %eax,0x10(%rsp)
   388d7:	b0 01                	mov    $0x1,%al
   388d9:	89 44 24 40          	mov    %eax,0x40(%rsp)
   388dd:	b0 01                	mov    $0x1,%al
   388df:	89 44 24 04          	mov    %eax,0x4(%rsp)
   388e3:	b0 01                	mov    $0x1,%al
   388e5:	89 44 24 28          	mov    %eax,0x28(%rsp)
   388e9:	b0 01                	mov    $0x1,%al
   388eb:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   388f0:	b0 01                	mov    $0x1,%al
   388f2:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   388f6:	b0 01                	mov    $0x1,%al
   388f8:	89 44 24 24          	mov    %eax,0x24(%rsp)
   388fc:	b0 01                	mov    $0x1,%al
   388fe:	89 44 24 18          	mov    %eax,0x18(%rsp)
   38902:	b0 01                	mov    $0x1,%al
   38904:	89 44 24 20          	mov    %eax,0x20(%rsp)
   38908:	b0 01                	mov    $0x1,%al
   3890a:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3890e:	83 bc 24 08 05 00 00 	cmpl   $0xffffffff,0x508(%rsp)
   38915:	ff 
   38916:	0f 85 fd 04 00 00    	jne    38e19 <oriole_expat::dispatch+0x5009>
   3891c:	e9 20 05 00 00       	jmp    38e41 <oriole_expat::dispatch+0x5031>
   38921:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   38928:	00 
   38929:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   38930:	00 
   38931:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   38938:	00 
   38939:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   38940:	00 
   38941:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   38948:	00 
   38949:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   38950:	00 
   38951:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   38958:	00 
   38959:	88 8c 24 28 02 00 00 	mov    %cl,0x228(%rsp)
   38960:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38964:	0f 84 37 09 00 00    	je     392a1 <oriole_expat::dispatch+0x5491>
   3896a:	4c 8b 84 24 40 02 00 	mov    0x240(%rsp),%r8
   38971:	00 
   38972:	e9 2d 09 00 00       	jmp    392a4 <oriole_expat::dispatch+0x5494>
   38977:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   3897e:	00 
   3897f:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   38986:	00 
   38987:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   3898e:	00 
   3898f:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   38996:	00 
   38997:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   3899e:	00 
   3899f:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   389a6:	00 
   389a7:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   389ae:	00 
   389af:	88 8c 24 28 02 00 00 	mov    %cl,0x228(%rsp)
   389b6:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   389ba:	48 8b 84 24 70 04 00 	mov    0x470(%rsp),%rax
   389c1:	00 
   389c2:	0f 84 21 09 00 00    	je     392e9 <oriole_expat::dispatch+0x54d9>
   389c8:	4c 8b 84 24 40 02 00 	mov    0x240(%rsp),%r8
   389cf:	00 
   389d0:	e9 17 09 00 00       	jmp    392ec <oriole_expat::dispatch+0x54dc>
   389d5:	4c 89 f0             	mov    %r14,%rax
   389d8:	48 c1 e8 3c          	shr    $0x3c,%rax
   389dc:	40 b5 01             	mov    $0x1,%bpl
   389df:	0f 85 59 ec ff ff    	jne    3763e <oriole_expat::dispatch+0x382e>
   389e5:	4a 8d 04 6d 01 00 00 	lea    0x1(,%r13,2),%rax
   389ec:	00 
   389ed:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
   389f4:	00 
   389f5:	41 bc 08 00 00 00    	mov    $0x8,%r12d
   389fb:	45 31 ff             	xor    %r15d,%r15d
   389fe:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   38a05:	00 
   38a06:	be 08 00 00 00       	mov    $0x8,%esi
   38a0b:	ff 15 ef df 0a 00    	call   *0xadfef(%rip)        # e6a00 <_GLOBAL_OFFSET_TABLE_+0x158>
   38a11:	48 85 c0             	test   %rax,%rax
   38a14:	0f 84 81 0e 00 00    	je     3989b <oriole_expat::dispatch+0x5a8b>
   38a1a:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
   38a21:	00 
   38a22:	48 89 c5             	mov    %rax,%rbp
   38a25:	4e 8d 3c 6d 01 00 00 	lea    0x1(,%r13,2),%r15
   38a2c:	00 
   38a2d:	4c 89 bc 24 48 02 00 	mov    %r15,0x248(%rsp)
   38a34:	00 
   38a35:	49 c1 e5 04          	shl    $0x4,%r13
   38a39:	48 89 c7             	mov    %rax,%rdi
   38a3c:	31 f6                	xor    %esi,%esi
   38a3e:	4c 89 ea             	mov    %r13,%rdx
   38a41:	ff 15 69 e8 0a 00    	call   *0xae869(%rip)        # e72b0 <memset@GLIBC_2.2.5>
   38a47:	4a c7 44 2d 00 00 00 	movq   $0x0,0x0(%rbp,%r13,1)
   38a4e:	00 00 
   38a50:	49 83 ce 01          	or     $0x1,%r14
   38a54:	4c 89 b4 24 50 02 00 	mov    %r14,0x250(%rsp)
   38a5b:	00 
   38a5c:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
   38a63:	00 
   38a64:	4c 8b ac 24 d0 00 00 	mov    0xd0(%rsp),%r13
   38a6b:	00 
   38a6c:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
   38a71:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
   38a76:	48 89 6c 24 48       	mov    %rbp,0x48(%rsp)
   38a7b:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
   38a80:	4d 85 ed             	test   %r13,%r13
   38a83:	74 7d                	je     38b02 <oriole_expat::dispatch+0x4cf2>
   38a85:	4d 6b f5 78          	imul   $0x78,%r13,%r14
   38a89:	4d 01 e6             	add    %r12,%r14
   38a8c:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   38a92:	48 8d 2d f7 cf 06 00 	lea    0x6cff7(%rip),%rbp        # a5a90 <<oriole_storage::string::String>::try_push>
   38a99:	4c 8d 2d 80 a3 0a 00 	lea    0xaa380(%rip),%r13        # e2e20 <oriole_expat::FEATURES+0x108>
   38aa0:	4c 89 e7             	mov    %r12,%rdi
   38aa3:	31 f6                	xor    %esi,%esi
   38aa5:	ff d5                	call   *%rbp
   38aa7:	3c ff                	cmp    $0xff,%al
   38aa9:	0f 85 23 09 00 00    	jne    393d2 <oriole_expat::dispatch+0x55c2>
   38aaf:	49 83 c4 38          	add    $0x38,%r12
   38ab3:	4c 89 e7             	mov    %r12,%rdi
   38ab6:	31 f6                	xor    %esi,%esi
   38ab8:	ff d5                	call   *%rbp
   38aba:	3c ff                	cmp    $0xff,%al
   38abc:	0f 85 10 09 00 00    	jne    393d2 <oriole_expat::dispatch+0x55c2>
   38ac2:	49 8d 7f ff          	lea    -0x1(%r15),%rdi
   38ac6:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   38acb:	48 39 cf             	cmp    %rcx,%rdi
   38ace:	0f 83 83 0e 00 00    	jae    39957 <oriole_expat::dispatch+0x5b47>
   38ad4:	49 8b 44 24 e8       	mov    -0x18(%r12),%rax
   38ad9:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   38ade:	4a 89 44 fa f8       	mov    %rax,-0x8(%rdx,%r15,8)
   38ae3:	49 39 cf             	cmp    %rcx,%r15
   38ae6:	0f 83 74 0e 00 00    	jae    39960 <oriole_expat::dispatch+0x5b50>
   38aec:	49 8b 44 24 20       	mov    0x20(%r12),%rax
   38af1:	4a 89 04 fa          	mov    %rax,(%rdx,%r15,8)
   38af5:	49 83 c7 02          	add    $0x2,%r15
   38af9:	49 83 c4 40          	add    $0x40,%r12
   38afd:	4d 39 f4             	cmp    %r14,%r12
   38b00:	75 9e                	jne    38aa0 <oriole_expat::dispatch+0x4c90>
   38b02:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   38b09:	00 
   38b0a:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   38b0f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
   38b14:	ff 94 24 60 04 00 00 	call   *0x460(%rsp)
   38b1b:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   38b20:	48 85 c9             	test   %rcx,%rcx
   38b23:	74 1c                	je     38b41 <oriole_expat::dispatch+0x4d31>
   38b25:	48 c1 e1 03          	shl    $0x3,%rcx
   38b29:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   38b30:	00 
   38b31:	ba 08 00 00 00       	mov    $0x8,%edx
   38b36:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   38b3b:	ff 15 9f de 0a 00    	call   *0xade9f(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38b41:	40 b5 01             	mov    $0x1,%bpl
   38b44:	e9 f9 eb ff ff       	jmp    37742 <oriole_expat::dispatch+0x3932>
   38b49:	45 31 c0             	xor    %r8d,%r8d
   38b4c:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   38b51:	4c 89 fe             	mov    %r15,%rsi
   38b54:	4c 89 e2             	mov    %r12,%rdx
   38b57:	4c 89 e9             	mov    %r13,%rcx
   38b5a:	ff 94 24 88 04 00 00 	call   *0x488(%rsp)
   38b61:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   38b68:	00 
   38b69:	e8 c2 67 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38b6e:	31 ed                	xor    %ebp,%ebp
   38b70:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   38b77:	00 
   38b78:	e8 b3 67 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38b7d:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   38b84:	00 
   38b85:	48 85 c9             	test   %rcx,%rcx
   38b88:	74 18                	je     38ba2 <oriole_expat::dispatch+0x4d92>
   38b8a:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   38b91:	00 
   38b92:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   38b97:	ba 01 00 00 00       	mov    $0x1,%edx
   38b9c:	ff 15 3e de 0a 00    	call   *0xade3e(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38ba2:	40 b5 01             	mov    $0x1,%bpl
   38ba5:	b0 01                	mov    $0x1,%al
   38ba7:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   38bae:	00 
   38baf:	b1 01                	mov    $0x1,%cl
   38bb1:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   38bb5:	b1 01                	mov    $0x1,%cl
   38bb7:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   38bbb:	b1 01                	mov    $0x1,%cl
   38bbd:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   38bc1:	b1 01                	mov    $0x1,%cl
   38bc3:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   38bc7:	b1 01                	mov    $0x1,%cl
   38bc9:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   38bcd:	b1 01                	mov    $0x1,%cl
   38bcf:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   38bd3:	b1 01                	mov    $0x1,%cl
   38bd5:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   38bd9:	b1 01                	mov    $0x1,%cl
   38bdb:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   38bdf:	b1 01                	mov    $0x1,%cl
   38be1:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   38be5:	e9 82 cb ff ff       	jmp    3576c <oriole_expat::dispatch+0x195c>
   38bea:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   38bf1:	00 
   38bf2:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   38bf9:	00 
   38bfa:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   38c01:	00 
   38c02:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
   38c09:	00 
   38c0a:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
   38c0f:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
   38c14:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   38c19:	44 88 64 24 68       	mov    %r12b,0x68(%rsp)
   38c1e:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38c22:	0f 84 49 09 00 00    	je     39571 <oriole_expat::dispatch+0x5761>
   38c28:	48 8b ac 24 80 00 00 	mov    0x80(%rsp),%rbp
   38c2f:	00 
   38c30:	e9 3e 09 00 00       	jmp    39573 <oriole_expat::dispatch+0x5763>
   38c35:	45 31 f6             	xor    %r14d,%r14d
   38c38:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   38c3f:	00 
   38c40:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
   38c47:	00 
   38c48:	e8 73 a1 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   38c4d:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   38c54:	00 
   38c55:	0f b6 8c 24 48 03 00 	movzbl 0x348(%rsp),%ecx
   38c5c:	00 
   38c5d:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   38c61:	0f 85 e4 05 00 00    	jne    3924b <oriole_expat::dispatch+0x543b>
   38c67:	89 cb                	mov    %ecx,%ebx
   38c69:	45 31 f6             	xor    %r14d,%r14d
   38c6c:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   38c73:	00 
   38c74:	e8 b7 66 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38c79:	44 89 74 24 30       	mov    %r14d,0x30(%rsp)
   38c7e:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   38c85:	00 
   38c86:	45 31 e4             	xor    %r12d,%r12d
   38c89:	48 85 c9             	test   %rcx,%rcx
   38c8c:	74 13                	je     38ca1 <oriole_expat::dispatch+0x4e91>
   38c8e:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   38c93:	ba 01 00 00 00       	mov    $0x1,%edx
   38c98:	4c 89 ee             	mov    %r13,%rsi
   38c9b:	ff 15 3f dd 0a 00    	call   *0xadd3f(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38ca1:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   38ca8:	00 
   38ca9:	48 85 c9             	test   %rcx,%rcx
   38cac:	74 27                	je     38cd5 <oriole_expat::dispatch+0x4ec5>
   38cae:	b0 01                	mov    $0x1,%al
   38cb0:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38cb4:	45 31 f6             	xor    %r14d,%r14d
   38cb7:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   38cbe:	00 
   38cbf:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   38cc6:	00 
   38cc7:	ba 01 00 00 00       	mov    $0x1,%edx
   38ccc:	41 b5 01             	mov    $0x1,%r13b
   38ccf:	ff 15 0b dd 0a 00    	call   *0xadd0b(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38cd5:	41 b5 01             	mov    $0x1,%r13b
   38cd8:	8b 6c 24 30          	mov    0x30(%rsp),%ebp
   38cdc:	45 31 f6             	xor    %r14d,%r14d
   38cdf:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   38ce6:	00 
   38ce7:	e8 44 66 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38cec:	45 31 f6             	xor    %r14d,%r14d
   38cef:	40 84 ed             	test   %bpl,%bpl
   38cf2:	74 0d                	je     38d01 <oriole_expat::dispatch+0x4ef1>
   38cf4:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
   38cfb:	00 
   38cfc:	e8 2f 66 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38d01:	45 84 e4             	test   %r12b,%r12b
   38d04:	74 0d                	je     38d13 <oriole_expat::dispatch+0x4f03>
   38d06:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
   38d0d:	00 
   38d0e:	e8 1d 66 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38d13:	45 84 ed             	test   %r13b,%r13b
   38d16:	74 0d                	je     38d25 <oriole_expat::dispatch+0x4f15>
   38d18:	48 8d bc 24 d0 05 00 	lea    0x5d0(%rsp),%rdi
   38d1f:	00 
   38d20:	e8 0b 66 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38d25:	45 84 f6             	test   %r14b,%r14b
   38d28:	74 7f                	je     38da9 <oriole_expat::dispatch+0x4f99>
   38d2a:	48 8b 8c 24 68 05 00 	mov    0x568(%rsp),%rcx
   38d31:	00 
   38d32:	48 85 c9             	test   %rcx,%rcx
   38d35:	74 72                	je     38da9 <oriole_expat::dispatch+0x4f99>
   38d37:	b0 01                	mov    $0x1,%al
   38d39:	89 44 24 48          	mov    %eax,0x48(%rsp)
   38d3d:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   38d44:	00 
   38d45:	48 8b b4 24 60 05 00 	mov    0x560(%rsp),%rsi
   38d4c:	00 
   38d4d:	48 8d bc 24 40 05 00 	lea    0x540(%rsp),%rdi
   38d54:	00 
   38d55:	ba 01 00 00 00       	mov    $0x1,%edx
   38d5a:	b0 01                	mov    $0x1,%al
   38d5c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   38d60:	b0 01                	mov    $0x1,%al
   38d62:	89 44 24 30          	mov    %eax,0x30(%rsp)
   38d66:	b0 01                	mov    $0x1,%al
   38d68:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38d6c:	b0 01                	mov    $0x1,%al
   38d6e:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38d72:	b0 01                	mov    $0x1,%al
   38d74:	89 44 24 10          	mov    %eax,0x10(%rsp)
   38d78:	b0 01                	mov    $0x1,%al
   38d7a:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38d7e:	b0 01                	mov    $0x1,%al
   38d80:	89 44 24 08          	mov    %eax,0x8(%rsp)
   38d84:	b0 01                	mov    $0x1,%al
   38d86:	89 44 24 04          	mov    %eax,0x4(%rsp)
   38d8a:	b0 01                	mov    $0x1,%al
   38d8c:	89 44 24 28          	mov    %eax,0x28(%rsp)
   38d90:	b0 01                	mov    $0x1,%al
   38d92:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   38d97:	41 b6 01             	mov    $0x1,%r14b
   38d9a:	41 b4 01             	mov    $0x1,%r12b
   38d9d:	41 b7 01             	mov    $0x1,%r15b
   38da0:	41 b5 01             	mov    $0x1,%r13b
   38da3:	ff 15 37 dc 0a 00    	call   *0xadc37(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38da9:	b0 01                	mov    $0x1,%al
   38dab:	89 44 24 48          	mov    %eax,0x48(%rsp)
   38daf:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   38db6:	00 
   38db7:	b0 01                	mov    $0x1,%al
   38db9:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   38dbd:	b0 01                	mov    $0x1,%al
   38dbf:	89 44 24 30          	mov    %eax,0x30(%rsp)
   38dc3:	b0 01                	mov    $0x1,%al
   38dc5:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38dc9:	b0 01                	mov    $0x1,%al
   38dcb:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38dcf:	b0 01                	mov    $0x1,%al
   38dd1:	89 44 24 10          	mov    %eax,0x10(%rsp)
   38dd5:	b0 01                	mov    $0x1,%al
   38dd7:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38ddb:	b0 01                	mov    $0x1,%al
   38ddd:	89 44 24 08          	mov    %eax,0x8(%rsp)
   38de1:	b0 01                	mov    $0x1,%al
   38de3:	89 44 24 04          	mov    %eax,0x4(%rsp)
   38de7:	b0 01                	mov    $0x1,%al
   38de9:	89 44 24 28          	mov    %eax,0x28(%rsp)
   38ded:	b0 01                	mov    $0x1,%al
   38def:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   38df4:	b0 01                	mov    $0x1,%al
   38df6:	89 44 24 24          	mov    %eax,0x24(%rsp)
   38dfa:	b0 01                	mov    $0x1,%al
   38dfc:	89 44 24 18          	mov    %eax,0x18(%rsp)
   38e00:	b0 01                	mov    $0x1,%al
   38e02:	89 44 24 20          	mov    %eax,0x20(%rsp)
   38e06:	b0 01                	mov    $0x1,%al
   38e08:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   38e0c:	41 89 dd             	mov    %ebx,%r13d
   38e0f:	83 bc 24 08 05 00 00 	cmpl   $0xffffffff,0x508(%rsp)
   38e16:	ff 
   38e17:	74 28                	je     38e41 <oriole_expat::dispatch+0x5031>
   38e19:	48 8b 8c 24 30 05 00 	mov    0x530(%rsp),%rcx
   38e20:	00 
   38e21:	48 85 c9             	test   %rcx,%rcx
   38e24:	74 1b                	je     38e41 <oriole_expat::dispatch+0x5031>
   38e26:	48 8b b4 24 28 05 00 	mov    0x528(%rsp),%rsi
   38e2d:	00 
   38e2e:	48 8d bc 24 08 05 00 	lea    0x508(%rsp),%rdi
   38e35:	00 
   38e36:	ba 01 00 00 00       	mov    $0x1,%edx
   38e3b:	ff 15 9f db 0a 00    	call   *0xadb9f(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38e41:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
   38e48:	00 
   38e49:	48 83 e9 03          	sub    $0x3,%rcx
   38e4d:	b8 0d 00 00 00       	mov    $0xd,%eax
   38e52:	48 0f 43 c1          	cmovae %rcx,%rax
   38e56:	48 83 c0 fa          	add    $0xfffffffffffffffa,%rax
   38e5a:	48 83 f8 14          	cmp    $0x14,%rax
   38e5e:	0f 87 44 03 00 00    	ja     391a8 <oriole_expat::dispatch+0x5398>
   38e64:	48 8d 0d 51 0f fd ff 	lea    -0x2f0af(%rip),%rcx        # 9dbc <std::thread::current::id::ID+0x9d4c>
   38e6b:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   38e6f:	48 01 c8             	add    %rcx,%rax
   38e72:	ff e0                	jmp    *%rax
   38e74:	80 7c 24 2c 00       	cmpb   $0x0,0x2c(%rsp)
   38e79:	0f 84 29 03 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   38e7f:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   38e86:	00 
   38e87:	48 85 c9             	test   %rcx,%rcx
   38e8a:	74 1b                	je     38ea7 <oriole_expat::dispatch+0x5097>
   38e8c:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   38e93:	00 
   38e94:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   38e9b:	00 
   38e9c:	ba 01 00 00 00       	mov    $0x1,%edx
   38ea1:	ff 15 39 db 0a 00    	call   *0xadb39(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38ea7:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   38eae:	00 
   38eaf:	e8 9c 71 ff ff       	call   30050 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   38eb4:	e9 ef 02 00 00       	jmp    391a8 <oriole_expat::dispatch+0x5398>
   38eb9:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
   38ebe:	0f 84 e4 02 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   38ec4:	48 8d 9c 24 28 01 00 	lea    0x128(%rsp),%rbx
   38ecb:	00 
   38ecc:	4c 8b b4 24 48 01 00 	mov    0x148(%rsp),%r14
   38ed3:	00 
   38ed4:	4c 89 f7             	mov    %r14,%rdi
   38ed7:	e8 74 7c ff ff       	call   30b50 <core::ptr::drop_glue::<oriole::NotationDeclaration>>
   38edc:	e9 69 01 00 00       	jmp    3904a <oriole_expat::dispatch+0x523a>
   38ee1:	80 7c 24 50 00       	cmpb   $0x0,0x50(%rsp)
   38ee6:	0f 85 83 b6 ff ff    	jne    3456f <oriole_expat::dispatch+0x75f>
   38eec:	e9 b7 02 00 00       	jmp    391a8 <oriole_expat::dispatch+0x5398>
   38ef1:	80 7c 24 24 00       	cmpb   $0x0,0x24(%rsp)
   38ef6:	0f 84 ac 02 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   38efc:	48 8d 9c 24 28 01 00 	lea    0x128(%rsp),%rbx
   38f03:	00 
   38f04:	4c 8b b4 24 48 01 00 	mov    0x148(%rsp),%r14
   38f0b:	00 
   38f0c:	4c 89 f7             	mov    %r14,%rdi
   38f0f:	e8 ec 7c ff ff       	call   30c00 <core::ptr::drop_glue::<oriole::AttributeDeclaration>>
   38f14:	ba 08 00 00 00       	mov    $0x8,%edx
   38f19:	b9 e8 00 00 00       	mov    $0xe8,%ecx
   38f1e:	e9 79 02 00 00       	jmp    3919c <oriole_expat::dispatch+0x538c>
   38f23:	80 7c 24 48 00       	cmpb   $0x0,0x48(%rsp)
   38f28:	0f 84 7a 02 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   38f2e:	e9 3c b6 ff ff       	jmp    3456f <oriole_expat::dispatch+0x75f>
   38f33:	80 7c 24 10 00       	cmpb   $0x0,0x10(%rsp)
   38f38:	0f 84 6a 02 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   38f3e:	48 8b 8c 24 48 01 00 	mov    0x148(%rsp),%rcx
   38f45:	00 
   38f46:	48 85 c9             	test   %rcx,%rcx
   38f49:	74 1b                	je     38f66 <oriole_expat::dispatch+0x5156>
   38f4b:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
   38f52:	00 
   38f53:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   38f5a:	00 
   38f5b:	ba 01 00 00 00       	mov    $0x1,%edx
   38f60:	ff 15 7a da 0a 00    	call   *0xada7a(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38f66:	83 bc 24 58 01 00 00 	cmpl   $0xffffffff,0x158(%rsp)
   38f6d:	ff 
   38f6e:	0f 84 34 02 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   38f74:	48 8b 8c 24 80 01 00 	mov    0x180(%rsp),%rcx
   38f7b:	00 
   38f7c:	48 85 c9             	test   %rcx,%rcx
   38f7f:	0f 84 23 02 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   38f85:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
   38f8c:	00 
   38f8d:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
   38f94:	00 
   38f95:	e9 d2 01 00 00       	jmp    3916c <oriole_expat::dispatch+0x535c>
   38f9a:	80 7c 24 0c 00       	cmpb   $0x0,0xc(%rsp)
   38f9f:	0f 84 03 02 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   38fa5:	48 8d 9c 24 28 01 00 	lea    0x128(%rsp),%rbx
   38fac:	00 
   38fad:	4c 8b b4 24 48 01 00 	mov    0x148(%rsp),%r14
   38fb4:	00 
   38fb5:	4c 89 f7             	mov    %r14,%rdi
   38fb8:	e8 b3 79 ff ff       	call   30970 <core::ptr::drop_glue::<oriole::EntityDeclaration>>
   38fbd:	ba 08 00 00 00       	mov    $0x8,%edx
   38fc2:	b9 20 01 00 00       	mov    $0x120,%ecx
   38fc7:	e9 d0 01 00 00       	jmp    3919c <oriole_expat::dispatch+0x538c>
   38fcc:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
   38fd1:	0f 85 d5 00 00 00    	jne    390ac <oriole_expat::dispatch+0x529c>
   38fd7:	e9 cc 01 00 00       	jmp    391a8 <oriole_expat::dispatch+0x5398>
   38fdc:	80 7c 24 40 00       	cmpb   $0x0,0x40(%rsp)
   38fe1:	0f 84 c1 01 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   38fe7:	48 83 bc 24 60 01 00 	cmpq   $0xffffffffffffffff,0x160(%rsp)
   38fee:	00 ff 
   38ff0:	0f 84 b6 00 00 00    	je     390ac <oriole_expat::dispatch+0x529c>
   38ff6:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   38ffd:	00 
   38ffe:	48 85 c9             	test   %rcx,%rcx
   39001:	0f 84 a5 00 00 00    	je     390ac <oriole_expat::dispatch+0x529c>
   39007:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   3900e:	00 
   3900f:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
   39016:	00 
   39017:	ba 01 00 00 00       	mov    $0x1,%edx
   3901c:	ff 15 be d9 0a 00    	call   *0xad9be(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39022:	e9 85 00 00 00       	jmp    390ac <oriole_expat::dispatch+0x529c>
   39027:	80 7c 24 08 00       	cmpb   $0x0,0x8(%rsp)
   3902c:	0f 84 76 01 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   39032:	48 8d 9c 24 28 01 00 	lea    0x128(%rsp),%rbx
   39039:	00 
   3903a:	4c 8b b4 24 48 01 00 	mov    0x148(%rsp),%r14
   39041:	00 
   39042:	4c 89 f7             	mov    %r14,%rdi
   39045:	e8 c6 7c ff ff       	call   30d10 <core::ptr::drop_glue::<oriole::ExternalEntityReference>>
   3904a:	ba 08 00 00 00       	mov    $0x8,%edx
   3904f:	b9 a8 00 00 00       	mov    $0xa8,%ecx
   39054:	e9 43 01 00 00       	jmp    3919c <oriole_expat::dispatch+0x538c>
   39059:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
   3905e:	0f 84 44 01 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   39064:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   3906b:	00 
   3906c:	48 85 c9             	test   %rcx,%rcx
   3906f:	0f 84 da 00 00 00    	je     3914f <oriole_expat::dispatch+0x533f>
   39075:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3907c:	00 
   3907d:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   39084:	00 
   39085:	ba 01 00 00 00       	mov    $0x1,%edx
   3908a:	ff 15 50 d9 0a 00    	call   *0xad950(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39090:	e9 ba 00 00 00       	jmp    3914f <oriole_expat::dispatch+0x533f>
   39095:	80 7c 24 1c 00       	cmpb   $0x0,0x1c(%rsp)
   3909a:	75 10                	jne    390ac <oriole_expat::dispatch+0x529c>
   3909c:	e9 07 01 00 00       	jmp    391a8 <oriole_expat::dispatch+0x5398>
   390a1:	80 7c 24 38 00       	cmpb   $0x0,0x38(%rsp)
   390a6:	0f 84 fc 00 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   390ac:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   390b3:	00 
   390b4:	48 85 c9             	test   %rcx,%rcx
   390b7:	0f 84 eb 00 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   390bd:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   390c4:	00 
   390c5:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   390cc:	00 
   390cd:	e9 9a 00 00 00       	jmp    3916c <oriole_expat::dispatch+0x535c>
   390d2:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
   390d7:	0f 84 cb 00 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   390dd:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   390e4:	00 
   390e5:	48 85 c9             	test   %rcx,%rcx
   390e8:	74 65                	je     3914f <oriole_expat::dispatch+0x533f>
   390ea:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   390f1:	00 
   390f2:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   390f9:	00 
   390fa:	ba 01 00 00 00       	mov    $0x1,%edx
   390ff:	ff 15 db d8 0a 00    	call   *0xad8db(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39105:	eb 48                	jmp    3914f <oriole_expat::dispatch+0x533f>
   39107:	80 7c 24 28 00       	cmpb   $0x0,0x28(%rsp)
   3910c:	0f 84 96 00 00 00    	je     391a8 <oriole_expat::dispatch+0x5398>
   39112:	83 bc 24 28 01 00 00 	cmpl   $0xffffffff,0x128(%rsp)
   39119:	ff 
   3911a:	74 28                	je     39144 <oriole_expat::dispatch+0x5334>
   3911c:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   39123:	00 
   39124:	48 85 c9             	test   %rcx,%rcx
   39127:	74 1b                	je     39144 <oriole_expat::dispatch+0x5334>
   39129:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   39130:	00 
   39131:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   39138:	00 
   39139:	ba 01 00 00 00       	mov    $0x1,%edx
   3913e:	ff 15 9c d8 0a 00    	call   *0xad89c(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39144:	48 83 bc 24 60 01 00 	cmpq   $0xffffffffffffffff,0x160(%rsp)
   3914b:	00 ff 
   3914d:	74 59                	je     391a8 <oriole_expat::dispatch+0x5398>
   3914f:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   39156:	00 
   39157:	48 85 c9             	test   %rcx,%rcx
   3915a:	74 4c                	je     391a8 <oriole_expat::dispatch+0x5398>
   3915c:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   39163:	00 
   39164:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
   3916b:	00 
   3916c:	ba 01 00 00 00       	mov    $0x1,%edx
   39171:	eb 2f                	jmp    391a2 <oriole_expat::dispatch+0x5392>
   39173:	80 7c 24 04 00       	cmpb   $0x0,0x4(%rsp)
   39178:	74 2e                	je     391a8 <oriole_expat::dispatch+0x5398>
   3917a:	48 8d 9c 24 28 01 00 	lea    0x128(%rsp),%rbx
   39181:	00 
   39182:	4c 8b b4 24 48 01 00 	mov    0x148(%rsp),%r14
   39189:	00 
   3918a:	4c 89 f7             	mov    %r14,%rdi
   3918d:	e8 0e 79 ff ff       	call   30aa0 <core::ptr::drop_glue::<oriole::DoctypeDeclaration>>
   39192:	ba 08 00 00 00       	mov    $0x8,%edx
   39197:	b9 b0 00 00 00       	mov    $0xb0,%ecx
   3919c:	48 89 df             	mov    %rbx,%rdi
   3919f:	4c 89 f6             	mov    %r14,%rsi
   391a2:	ff 15 38 d8 0a 00    	call   *0xad838(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   391a8:	44 89 e8             	mov    %r13d,%eax
   391ab:	48 81 c4 78 06 00 00 	add    $0x678,%rsp
   391b2:	5b                   	pop    %rbx
   391b3:	41 5c                	pop    %r12
   391b5:	41 5d                	pop    %r13
   391b7:	41 5e                	pop    %r14
   391b9:	41 5f                	pop    %r15
   391bb:	5d                   	pop    %rbp
   391bc:	c3                   	ret
   391bd:	31 c9                	xor    %ecx,%ecx
   391bf:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   391c4:	4c 89 e6             	mov    %r12,%rsi
   391c7:	4c 89 f2             	mov    %r14,%rdx
   391ca:	45 89 f8             	mov    %r15d,%r8d
   391cd:	ff 94 24 18 02 00 00 	call   *0x218(%rsp)
   391d4:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   391db:	00 
   391dc:	e8 4f 61 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   391e1:	31 ed                	xor    %ebp,%ebp
   391e3:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   391ea:	00 
   391eb:	e8 40 61 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   391f0:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   391f7:	00 
   391f8:	48 85 c9             	test   %rcx,%rcx
   391fb:	74 18                	je     39215 <oriole_expat::dispatch+0x5405>
   391fd:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   39204:	00 
   39205:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3920a:	ba 01 00 00 00       	mov    $0x1,%edx
   3920f:	ff 15 cb d7 0a 00    	call   *0xad7cb(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39215:	40 b5 01             	mov    $0x1,%bpl
   39218:	b0 01                	mov    $0x1,%al
   3921a:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   39221:	00 
   39222:	b1 01                	mov    $0x1,%cl
   39224:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   39228:	b1 01                	mov    $0x1,%cl
   3922a:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   3922e:	b1 01                	mov    $0x1,%cl
   39230:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   39234:	b1 01                	mov    $0x1,%cl
   39236:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   3923a:	b1 01                	mov    $0x1,%cl
   3923c:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   39240:	b1 01                	mov    $0x1,%cl
   39242:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   39246:	e9 0f c5 ff ff       	jmp    3575a <oriole_expat::dispatch+0x194a>
   3924b:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   39252:	00 
   39253:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   3925a:	00 
   3925b:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   39262:	00 
   39263:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   3926a:	00 
   3926b:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   39272:	00 
   39273:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   3927a:	00 
   3927b:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   39282:	00 
   39283:	88 8c 24 28 02 00 00 	mov    %cl,0x228(%rsp)
   3928a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3928e:	0f 84 1a 03 00 00    	je     395ae <oriole_expat::dispatch+0x579e>
   39294:	4c 8b 84 24 40 02 00 	mov    0x240(%rsp),%r8
   3929b:	00 
   3929c:	e9 10 03 00 00       	jmp    395b1 <oriole_expat::dispatch+0x57a1>
   392a1:	45 31 c0             	xor    %r8d,%r8d
   392a4:	4c 89 f7             	mov    %r14,%rdi
   392a7:	4c 89 ee             	mov    %r13,%rsi
   392aa:	4c 89 fa             	mov    %r15,%rdx
   392ad:	48 89 e9             	mov    %rbp,%rcx
   392b0:	41 ff d4             	call   *%r12
   392b3:	85 c0                	test   %eax,%eax
   392b5:	0f 84 4a 01 00 00    	je     39405 <oriole_expat::dispatch+0x55f5>
   392bb:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   392c2:	00 
   392c3:	e8 68 60 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   392c8:	31 ed                	xor    %ebp,%ebp
   392ca:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   392d1:	00 
   392d2:	e8 59 60 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   392d7:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   392dc:	e8 4f 60 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   392e1:	40 b5 01             	mov    $0x1,%bpl
   392e4:	e9 51 dc ff ff       	jmp    36f3a <oriole_expat::dispatch+0x312a>
   392e9:	45 31 c0             	xor    %r8d,%r8d
   392ec:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   392f1:	4c 89 e6             	mov    %r12,%rsi
   392f4:	4c 89 f2             	mov    %r14,%rdx
   392f7:	4c 89 e9             	mov    %r13,%rcx
   392fa:	45 89 f9             	mov    %r15d,%r9d
   392fd:	ff d0                	call   *%rax
   392ff:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   39306:	00 
   39307:	e8 24 60 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3930c:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   39313:	00 
   39314:	48 85 c9             	test   %rcx,%rcx
   39317:	74 1d                	je     39336 <oriole_expat::dispatch+0x5526>
   39319:	31 ed                	xor    %ebp,%ebp
   3931b:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   39322:	00 
   39323:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3932a:	00 
   3932b:	ba 01 00 00 00       	mov    $0x1,%edx
   39330:	ff 15 aa d6 0a 00    	call   *0xad6aa(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39336:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   3933d:	00 
   3933e:	48 85 c9             	test   %rcx,%rcx
   39341:	74 1d                	je     39360 <oriole_expat::dispatch+0x5550>
   39343:	31 ed                	xor    %ebp,%ebp
   39345:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   3934c:	00 
   3934d:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39352:	ba 01 00 00 00       	mov    $0x1,%edx
   39357:	45 31 f6             	xor    %r14d,%r14d
   3935a:	ff 15 80 d6 0a 00    	call   *0xad680(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39360:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   39367:	00 
   39368:	48 85 c9             	test   %rcx,%rcx
   3936b:	74 23                	je     39390 <oriole_expat::dispatch+0x5580>
   3936d:	31 ed                	xor    %ebp,%ebp
   3936f:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   39376:	00 
   39377:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3937e:	00 
   3937f:	ba 01 00 00 00       	mov    $0x1,%edx
   39384:	45 31 f6             	xor    %r14d,%r14d
   39387:	45 31 ed             	xor    %r13d,%r13d
   3938a:	ff 15 50 d6 0a 00    	call   *0xad650(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39390:	40 b5 01             	mov    $0x1,%bpl
   39393:	b0 01                	mov    $0x1,%al
   39395:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   3939c:	00 
   3939d:	b1 01                	mov    $0x1,%cl
   3939f:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   393a3:	b1 01                	mov    $0x1,%cl
   393a5:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   393a9:	b1 01                	mov    $0x1,%cl
   393ab:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   393af:	b1 01                	mov    $0x1,%cl
   393b1:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   393b5:	b1 01                	mov    $0x1,%cl
   393b7:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   393bb:	b1 01                	mov    $0x1,%cl
   393bd:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   393c1:	b1 01                	mov    $0x1,%cl
   393c3:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   393c7:	b1 01                	mov    $0x1,%cl
   393c9:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   393cd:	e9 94 c3 ff ff       	jmp    35766 <oriole_expat::dispatch+0x1956>
   393d2:	89 c3                	mov    %eax,%ebx
   393d4:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   393d9:	48 85 c9             	test   %rcx,%rcx
   393dc:	0f 84 b2 04 00 00    	je     39894 <oriole_expat::dispatch+0x5a84>
   393e2:	48 c1 e1 03          	shl    $0x3,%rcx
   393e6:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   393ed:	00 
   393ee:	ba 08 00 00 00       	mov    $0x8,%edx
   393f3:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   393f8:	ff 15 e2 d5 0a 00    	call   *0xad5e2(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   393fe:	89 dd                	mov    %ebx,%ebp
   39400:	e9 39 e2 ff ff       	jmp    3763e <oriole_expat::dispatch+0x382e>
   39405:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3940c:	00 
   3940d:	e8 1e 5f ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39412:	31 ed                	xor    %ebp,%ebp
   39414:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3941b:	00 
   3941c:	e8 0f 5f ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39421:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39426:	e8 05 5f ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3942b:	48 b8 15 00 00 00 15 	movabs $0x1500000015,%rax
   39432:	00 00 00 
   39435:	48 89 83 10 0a 00 00 	mov    %rax,0xa10(%rbx)
   3943c:	40 b5 01             	mov    $0x1,%bpl
   3943f:	e9 f6 da ff ff       	jmp    36f3a <oriole_expat::dispatch+0x312a>
   39444:	89 d9                	mov    %ebx,%ecx
   39446:	89 cb                	mov    %ecx,%ebx
   39448:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   3944f:	00 
   39450:	48 85 c9             	test   %rcx,%rcx
   39453:	74 1b                	je     39470 <oriole_expat::dispatch+0x5660>
   39455:	45 31 f6             	xor    %r14d,%r14d
   39458:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   3945f:	00 
   39460:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39465:	ba 01 00 00 00       	mov    $0x1,%edx
   3946a:	ff 15 70 d5 0a 00    	call   *0xad570(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39470:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   39477:	00 
   39478:	48 85 c9             	test   %rcx,%rcx
   3947b:	74 21                	je     3949e <oriole_expat::dispatch+0x568e>
   3947d:	45 31 f6             	xor    %r14d,%r14d
   39480:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   39487:	00 
   39488:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3948f:	00 
   39490:	ba 01 00 00 00       	mov    $0x1,%edx
   39495:	45 31 ed             	xor    %r13d,%r13d
   39498:	ff 15 42 d5 0a 00    	call   *0xad542(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3949e:	40 84 ed             	test   %bpl,%bpl
   394a1:	74 75                	je     39518 <oriole_expat::dispatch+0x5708>
   394a3:	45 31 f6             	xor    %r14d,%r14d
   394a6:	45 31 ed             	xor    %r13d,%r13d
   394a9:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   394b0:	00 
   394b1:	e8 7a 5e ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   394b6:	45 84 f6             	test   %r14b,%r14b
   394b9:	74 5d                	je     39518 <oriole_expat::dispatch+0x5708>
   394bb:	45 31 ed             	xor    %r13d,%r13d
   394be:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   394c5:	00 
   394c6:	48 85 c9             	test   %rcx,%rcx
   394c9:	74 1b                	je     394e6 <oriole_expat::dispatch+0x56d6>
   394cb:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   394d2:	00 
   394d3:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   394da:	00 
   394db:	ba 01 00 00 00       	mov    $0x1,%edx
   394e0:	ff 15 fa d4 0a 00    	call   *0xad4fa(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   394e6:	45 84 ed             	test   %r13b,%r13b
   394e9:	74 2d                	je     39518 <oriole_expat::dispatch+0x5708>
   394eb:	48 8b 8c 24 b8 04 00 	mov    0x4b8(%rsp),%rcx
   394f2:	00 
   394f3:	48 85 c9             	test   %rcx,%rcx
   394f6:	41 89 dd             	mov    %ebx,%r13d
   394f9:	74 20                	je     3951b <oriole_expat::dispatch+0x570b>
   394fb:	48 8b b4 24 b0 04 00 	mov    0x4b0(%rsp),%rsi
   39502:	00 
   39503:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
   3950a:	00 
   3950b:	ba 01 00 00 00       	mov    $0x1,%edx
   39510:	ff 15 ca d4 0a 00    	call   *0xad4ca(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39516:	eb 03                	jmp    3951b <oriole_expat::dispatch+0x570b>
   39518:	41 89 dd             	mov    %ebx,%r13d
   3951b:	b0 01                	mov    $0x1,%al
   3951d:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39521:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   39528:	00 
   39529:	b0 01                	mov    $0x1,%al
   3952b:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3952f:	b0 01                	mov    $0x1,%al
   39531:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39535:	b0 01                	mov    $0x1,%al
   39537:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3953b:	b0 01                	mov    $0x1,%al
   3953d:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39541:	b0 01                	mov    $0x1,%al
   39543:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39547:	b0 01                	mov    $0x1,%al
   39549:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3954d:	b0 01                	mov    $0x1,%al
   3954f:	89 44 24 08          	mov    %eax,0x8(%rsp)
   39553:	b0 01                	mov    $0x1,%al
   39555:	89 44 24 04          	mov    %eax,0x4(%rsp)
   39559:	b0 01                	mov    $0x1,%al
   3955b:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3955f:	b0 01                	mov    $0x1,%al
   39561:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   39566:	b0 01                	mov    $0x1,%al
   39568:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3956c:	e9 8b f3 ff ff       	jmp    388fc <oriole_expat::dispatch+0x4aec>
   39571:	31 ed                	xor    %ebp,%ebp
   39573:	41 b7 01             	mov    $0x1,%r15b
   39576:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3957d:	00 
   3957e:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
   39585:	00 
   39586:	e8 35 98 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   3958b:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   39592:	00 
   39593:	44 0f b6 a4 24 48 03 	movzbl 0x348(%rsp),%r12d
   3959a:	00 00 
   3959c:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   395a0:	0f 85 9a 01 00 00    	jne    39740 <oriole_expat::dispatch+0x5930>
   395a6:	41 b7 01             	mov    $0x1,%r15b
   395a9:	e9 25 02 00 00       	jmp    397d3 <oriole_expat::dispatch+0x59c3>
   395ae:	45 31 c0             	xor    %r8d,%r8d
   395b1:	4c 8b 8c 24 00 01 00 	mov    0x100(%rsp),%r9
   395b8:	00 
   395b9:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   395be:	4c 89 ee             	mov    %r13,%rsi
   395c1:	4c 89 e2             	mov    %r12,%rdx
   395c4:	4c 89 f1             	mov    %r14,%rcx
   395c7:	ff d5                	call   *%rbp
   395c9:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   395d0:	00 
   395d1:	e8 5a 5d ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   395d6:	45 31 f6             	xor    %r14d,%r14d
   395d9:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   395e0:	00 
   395e1:	e8 4a 5d ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   395e6:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   395ed:	00 
   395ee:	48 85 c9             	test   %rcx,%rcx
   395f1:	74 23                	je     39616 <oriole_expat::dispatch+0x5806>
   395f3:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   395fa:	00 
   395fb:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   39602:	00 
   39603:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39608:	ba 01 00 00 00       	mov    $0x1,%edx
   3960d:	45 31 e4             	xor    %r12d,%r12d
   39610:	ff 15 ca d3 0a 00    	call   *0xad3ca(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39616:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   3961d:	00 
   3961e:	48 85 c9             	test   %rcx,%rcx
   39621:	74 32                	je     39655 <oriole_expat::dispatch+0x5845>
   39623:	b0 01                	mov    $0x1,%al
   39625:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39629:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   39630:	00 
   39631:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   39638:	00 
   39639:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39640:	00 
   39641:	ba 01 00 00 00       	mov    $0x1,%edx
   39646:	45 31 e4             	xor    %r12d,%r12d
   39649:	41 b5 01             	mov    $0x1,%r13b
   3964c:	45 31 f6             	xor    %r14d,%r14d
   3964f:	ff 15 8b d3 0a 00    	call   *0xad38b(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39655:	41 b5 01             	mov    $0x1,%r13b
   39658:	31 ed                	xor    %ebp,%ebp
   3965a:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   39661:	00 
   39662:	45 31 e4             	xor    %r12d,%r12d
   39665:	45 31 f6             	xor    %r14d,%r14d
   39668:	e8 c3 5c ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3966d:	40 b5 01             	mov    $0x1,%bpl
   39670:	45 31 ed             	xor    %r13d,%r13d
   39673:	48 8d bc 24 d0 05 00 	lea    0x5d0(%rsp),%rdi
   3967a:	00 
   3967b:	45 89 ee             	mov    %r13d,%r14d
   3967e:	e8 ad 5c ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39683:	45 84 ff             	test   %r15b,%r15b
   39686:	74 7f                	je     39707 <oriole_expat::dispatch+0x58f7>
   39688:	48 8b 8c 24 68 05 00 	mov    0x568(%rsp),%rcx
   3968f:	00 
   39690:	48 85 c9             	test   %rcx,%rcx
   39693:	74 72                	je     39707 <oriole_expat::dispatch+0x58f7>
   39695:	b0 01                	mov    $0x1,%al
   39697:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3969b:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   396a2:	00 
   396a3:	48 8b b4 24 60 05 00 	mov    0x560(%rsp),%rsi
   396aa:	00 
   396ab:	48 8d bc 24 40 05 00 	lea    0x540(%rsp),%rdi
   396b2:	00 
   396b3:	ba 01 00 00 00       	mov    $0x1,%edx
   396b8:	b0 01                	mov    $0x1,%al
   396ba:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   396be:	b0 01                	mov    $0x1,%al
   396c0:	89 44 24 30          	mov    %eax,0x30(%rsp)
   396c4:	b0 01                	mov    $0x1,%al
   396c6:	89 44 24 48          	mov    %eax,0x48(%rsp)
   396ca:	b0 01                	mov    $0x1,%al
   396cc:	89 44 24 14          	mov    %eax,0x14(%rsp)
   396d0:	b0 01                	mov    $0x1,%al
   396d2:	89 44 24 10          	mov    %eax,0x10(%rsp)
   396d6:	b0 01                	mov    $0x1,%al
   396d8:	89 44 24 40          	mov    %eax,0x40(%rsp)
   396dc:	b0 01                	mov    $0x1,%al
   396de:	89 44 24 08          	mov    %eax,0x8(%rsp)
   396e2:	b0 01                	mov    $0x1,%al
   396e4:	89 44 24 04          	mov    %eax,0x4(%rsp)
   396e8:	b0 01                	mov    $0x1,%al
   396ea:	89 44 24 28          	mov    %eax,0x28(%rsp)
   396ee:	b0 01                	mov    $0x1,%al
   396f0:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   396f5:	41 b6 01             	mov    $0x1,%r14b
   396f8:	41 b4 01             	mov    $0x1,%r12b
   396fb:	41 b7 01             	mov    $0x1,%r15b
   396fe:	41 b5 01             	mov    $0x1,%r13b
   39701:	ff 15 d9 d2 0a 00    	call   *0xad2d9(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39707:	b0 01                	mov    $0x1,%al
   39709:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   39710:	00 
   39711:	b1 01                	mov    $0x1,%cl
   39713:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   39717:	b1 01                	mov    $0x1,%cl
   39719:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   3971d:	b1 01                	mov    $0x1,%cl
   3971f:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   39723:	b1 01                	mov    $0x1,%cl
   39725:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   39729:	b1 01                	mov    $0x1,%cl
   3972b:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   3972f:	b1 01                	mov    $0x1,%cl
   39731:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   39735:	b1 01                	mov    $0x1,%cl
   39737:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   3973b:	e9 20 c0 ff ff       	jmp    35760 <oriole_expat::dispatch+0x1950>
   39740:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   39747:	00 
   39748:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   3974f:	00 
   39750:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   39757:	00 
   39758:	0f 11 94 24 c8 00 00 	movups %xmm2,0xc8(%rsp)
   3975f:	00 
   39760:	0f 11 8c 24 b9 00 00 	movups %xmm1,0xb9(%rsp)
   39767:	00 
   39768:	0f 11 84 24 a9 00 00 	movups %xmm0,0xa9(%rsp)
   3976f:	00 
   39770:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   39777:	00 
   39778:	44 88 a4 24 a8 00 00 	mov    %r12b,0xa8(%rsp)
   3977f:	00 
   39780:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   39784:	74 0a                	je     39790 <oriole_expat::dispatch+0x5980>
   39786:	4c 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%r15
   3978d:	00 
   3978e:	eb 03                	jmp    39793 <oriole_expat::dispatch+0x5983>
   39790:	45 31 ff             	xor    %r15d,%r15d
   39793:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3979a:	00 
   3979b:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
   397a2:	00 
   397a3:	e8 18 96 ff ff       	call   32dc0 <oriole_expat::optional_cstring>
   397a8:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
   397af:	00 
   397b0:	44 0f b6 a4 24 48 03 	movzbl 0x348(%rsp),%r12d
   397b7:	00 00 
   397b9:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   397bd:	0f 85 81 00 00 00    	jne    39844 <oriole_expat::dispatch+0x5a34>
   397c3:	45 31 ff             	xor    %r15d,%r15d
   397c6:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   397cd:	00 
   397ce:	e8 5d 5b ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   397d3:	31 ed                	xor    %ebp,%ebp
   397d5:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   397da:	e8 51 5b ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   397df:	44 89 e3             	mov    %r12d,%ebx
   397e2:	45 31 e4             	xor    %r12d,%r12d
   397e5:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   397ec:	00 
   397ed:	e8 3e 5b ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   397f2:	89 6c 24 30          	mov    %ebp,0x30(%rsp)
   397f6:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   397fd:	00 
   397fe:	48 85 c9             	test   %rcx,%rcx
   39801:	44 89 7c 24 38       	mov    %r15d,0x38(%rsp)
   39806:	74 1f                	je     39827 <oriole_expat::dispatch+0x5a17>
   39808:	45 31 e4             	xor    %r12d,%r12d
   3980b:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   39812:	00 
   39813:	ba 01 00 00 00       	mov    $0x1,%edx
   39818:	4c 89 ee             	mov    %r13,%rsi
   3981b:	45 31 ed             	xor    %r13d,%r13d
   3981e:	45 31 f6             	xor    %r14d,%r14d
   39821:	ff 15 b9 d1 0a 00    	call   *0xad1b9(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39827:	45 31 e4             	xor    %r12d,%r12d
   3982a:	41 bd 00 00 00 00    	mov    $0x0,%r13d
   39830:	80 7c 24 38 00       	cmpb   $0x0,0x38(%rsp)
   39835:	8b 6c 24 30          	mov    0x30(%rsp),%ebp
   39839:	0f 85 9d f4 ff ff    	jne    38cdc <oriole_expat::dispatch+0x4ecc>
   3983f:	e9 a8 f4 ff ff       	jmp    38cec <oriole_expat::dispatch+0x4edc>
   39844:	0f 10 84 24 49 03 00 	movups 0x349(%rsp),%xmm0
   3984b:	00 
   3984c:	0f 10 8c 24 59 03 00 	movups 0x359(%rsp),%xmm1
   39853:	00 
   39854:	0f 10 94 24 68 03 00 	movups 0x368(%rsp),%xmm2
   3985b:	00 
   3985c:	0f 11 94 24 48 02 00 	movups %xmm2,0x248(%rsp)
   39863:	00 
   39864:	0f 11 8c 24 39 02 00 	movups %xmm1,0x239(%rsp)
   3986b:	00 
   3986c:	0f 11 84 24 29 02 00 	movups %xmm0,0x229(%rsp)
   39873:	00 
   39874:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   3987b:	00 
   3987c:	44 88 a4 24 28 02 00 	mov    %r12b,0x228(%rsp)
   39883:	00 
   39884:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   39888:	74 18                	je     398a2 <oriole_expat::dispatch+0x5a92>
   3988a:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
   39891:	00 
   39892:	eb 10                	jmp    398a4 <oriole_expat::dispatch+0x5a94>
   39894:	89 dd                	mov    %ebx,%ebp
   39896:	e9 a3 dd ff ff       	jmp    3763e <oriole_expat::dispatch+0x382e>
   3989b:	31 ed                	xor    %ebp,%ebp
   3989d:	e9 9c dd ff ff       	jmp    3763e <oriole_expat::dispatch+0x382e>
   398a2:	31 c0                	xor    %eax,%eax
   398a4:	8b 54 24 48          	mov    0x48(%rsp),%edx
   398a8:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
   398ad:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   398b2:	48 83 ec 08          	sub    $0x8,%rsp
   398b6:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   398bb:	4c 89 ee             	mov    %r13,%rsi
   398be:	45 89 f0             	mov    %r14d,%r8d
   398c1:	50                   	push   %rax
   398c2:	41 57                	push   %r15
   398c4:	55                   	push   %rbp
   398c5:	ff 54 24 60          	call   *0x60(%rsp)
   398c9:	48 83 c4 20          	add    $0x20,%rsp
   398cd:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   398d4:	00 
   398d5:	e8 56 5a ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   398da:	45 31 ff             	xor    %r15d,%r15d
   398dd:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   398e4:	00 
   398e5:	e8 46 5a ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   398ea:	45 31 ff             	xor    %r15d,%r15d
   398ed:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   398f2:	31 ed                	xor    %ebp,%ebp
   398f4:	e8 37 5a ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   398f9:	45 31 ff             	xor    %r15d,%r15d
   398fc:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39903:	00 
   39904:	31 ed                	xor    %ebp,%ebp
   39906:	45 31 e4             	xor    %r12d,%r12d
   39909:	e8 22 5a ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3990e:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   39915:	00 
   39916:	48 85 c9             	test   %rcx,%rcx
   39919:	74 34                	je     3994f <oriole_expat::dispatch+0x5b3f>
   3991b:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   39922:	00 
   39923:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   3992a:	00 
   3992b:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   39932:	00 
   39933:	ba 01 00 00 00       	mov    $0x1,%edx
   39938:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   3993f:	00 
   39940:	45 31 e4             	xor    %r12d,%r12d
   39943:	45 31 ed             	xor    %r13d,%r13d
   39946:	45 31 f6             	xor    %r14d,%r14d
   39949:	ff 15 91 d0 0a 00    	call   *0xad091(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3994f:	40 b5 01             	mov    $0x1,%bpl
   39952:	e9 b0 fd ff ff       	jmp    39707 <oriole_expat::dispatch+0x58f7>
   39957:	4c 8d 2d aa 94 0a 00 	lea    0xa94aa(%rip),%r13        # e2e08 <oriole_expat::FEATURES+0xf0>
   3995e:	eb 03                	jmp    39963 <oriole_expat::dispatch+0x5b53>
   39960:	4c 89 ff             	mov    %r15,%rdi
   39963:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
   39968:	4c 89 ea             	mov    %r13,%rdx
   3996b:	4c 8b 7c 24 38       	mov    0x38(%rsp),%r15
   39970:	4c 8b 64 24 48       	mov    0x48(%rsp),%r12
   39975:	ff 15 dd d5 0a 00    	call   *0xad5dd(%rip)        # e6f58 <_GLOBAL_OFFSET_TABLE_+0x6b0>
   3997b:	0f 0b                	ud2
   3997d:	48 89 c3             	mov    %rax,%rbx
   39980:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39987:	00 
   39988:	e8 a3 59 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3998d:	45 31 ff             	xor    %r15d,%r15d
   39990:	eb 03                	jmp    39995 <oriole_expat::dispatch+0x5b85>
   39992:	48 89 c3             	mov    %rax,%rbx
   39995:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3999a:	e8 91 59 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3999f:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   399a6:	00 
   399a7:	eb 39                	jmp    399e2 <oriole_expat::dispatch+0x5bd2>
   399a9:	48 89 c3             	mov    %rax,%rbx
   399ac:	e9 89 0b 00 00       	jmp    3a53a <oriole_expat::dispatch+0x672a>
   399b1:	48 89 c3             	mov    %rax,%rbx
   399b4:	b0 01                	mov    $0x1,%al
   399b6:	89 44 24 48          	mov    %eax,0x48(%rsp)
   399ba:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   399c1:	00 
   399c2:	b0 01                	mov    $0x1,%al
   399c4:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   399c8:	b0 01                	mov    $0x1,%al
   399ca:	89 44 24 30          	mov    %eax,0x30(%rsp)
   399ce:	e9 c3 09 00 00       	jmp    3a396 <oriole_expat::dispatch+0x6586>
   399d3:	48 89 c3             	mov    %rax,%rbx
   399d6:	e9 cd 0d 00 00       	jmp    3a7a8 <oriole_expat::dispatch+0x6998>
   399db:	89 6c 24 30          	mov    %ebp,0x30(%rsp)
   399df:	48 89 c3             	mov    %rax,%rbx
   399e2:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   399e9:	00 
   399ea:	e8 41 59 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   399ef:	45 31 e4             	xor    %r12d,%r12d
   399f2:	e9 44 02 00 00       	jmp    39c3b <oriole_expat::dispatch+0x5e2b>
   399f7:	48 89 c3             	mov    %rax,%rbx
   399fa:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39a01:	00 
   39a02:	e8 29 59 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39a07:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   39a0e:	00 
   39a0f:	e9 c5 01 00 00       	jmp    39bd9 <oriole_expat::dispatch+0x5dc9>
   39a14:	48 89 c3             	mov    %rax,%rbx
   39a17:	b0 01                	mov    $0x1,%al
   39a19:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39a1d:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   39a24:	00 
   39a25:	e9 cf 07 00 00       	jmp    3a1f9 <oriole_expat::dispatch+0x63e9>
   39a2a:	48 89 c3             	mov    %rax,%rbx
   39a2d:	b0 01                	mov    $0x1,%al
   39a2f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39a33:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   39a3a:	00 
   39a3b:	b0 01                	mov    $0x1,%al
   39a3d:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39a41:	b0 01                	mov    $0x1,%al
   39a43:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39a47:	b0 01                	mov    $0x1,%al
   39a49:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39a4d:	e9 e8 0d 00 00       	jmp    3a83a <oriole_expat::dispatch+0x6a2a>
   39a52:	e9 17 02 00 00       	jmp    39c6e <oriole_expat::dispatch+0x5e5e>
   39a57:	48 89 c3             	mov    %rax,%rbx
   39a5a:	e9 91 08 00 00       	jmp    3a2f0 <oriole_expat::dispatch+0x64e0>
   39a5f:	eb 51                	jmp    39ab2 <oriole_expat::dispatch+0x5ca2>
   39a61:	48 89 c3             	mov    %rax,%rbx
   39a64:	e9 c8 03 00 00       	jmp    39e31 <oriole_expat::dispatch+0x6021>
   39a69:	48 89 c3             	mov    %rax,%rbx
   39a6c:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   39a73:	00 
   39a74:	48 85 c9             	test   %rcx,%rcx
   39a77:	74 1b                	je     39a94 <oriole_expat::dispatch+0x5c84>
   39a79:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   39a80:	00 
   39a81:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39a88:	00 
   39a89:	ba 01 00 00 00       	mov    $0x1,%edx
   39a8e:	ff 15 4c cf 0a 00    	call   *0xacf4c(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39a94:	31 ed                	xor    %ebp,%ebp
   39a96:	e9 3c 02 00 00       	jmp    39cd7 <oriole_expat::dispatch+0x5ec7>
   39a9b:	48 89 c3             	mov    %rax,%rbx
   39a9e:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39aa5:	00 
   39aa6:	e8 85 58 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39aab:	31 ed                	xor    %ebp,%ebp
   39aad:	e9 ba 03 00 00       	jmp    39e6c <oriole_expat::dispatch+0x605c>
   39ab2:	48 89 c3             	mov    %rax,%rbx
   39ab5:	e9 e7 08 00 00       	jmp    3a3a1 <oriole_expat::dispatch+0x6591>
   39aba:	48 89 c3             	mov    %rax,%rbx
   39abd:	b0 01                	mov    $0x1,%al
   39abf:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39ac3:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   39aca:	00 
   39acb:	b0 01                	mov    $0x1,%al
   39acd:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39ad1:	b0 01                	mov    $0x1,%al
   39ad3:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39ad7:	b0 01                	mov    $0x1,%al
   39ad9:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39add:	b0 01                	mov    $0x1,%al
   39adf:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39ae3:	b0 01                	mov    $0x1,%al
   39ae5:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39ae9:	b0 01                	mov    $0x1,%al
   39aeb:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39aef:	e9 e6 0c 00 00       	jmp    3a7da <oriole_expat::dispatch+0x69ca>
   39af4:	48 89 c3             	mov    %rax,%rbx
   39af7:	e9 f1 09 00 00       	jmp    3a4ed <oriole_expat::dispatch+0x66dd>
   39afc:	48 89 c3             	mov    %rax,%rbx
   39aff:	e9 e7 06 00 00       	jmp    3a1eb <oriole_expat::dispatch+0x63db>
   39b04:	48 89 c3             	mov    %rax,%rbx
   39b07:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   39b0e:	00 
   39b0f:	e8 1c 58 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39b14:	e9 18 03 00 00       	jmp    39e31 <oriole_expat::dispatch+0x6021>
   39b19:	48 89 c3             	mov    %rax,%rbx
   39b1c:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   39b23:	00 
   39b24:	b0 01                	mov    $0x1,%al
   39b26:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39b2a:	48 85 c9             	test   %rcx,%rcx
   39b2d:	0f 84 14 07 00 00    	je     3a247 <oriole_expat::dispatch+0x6437>
   39b33:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   39b3a:	00 
   39b3b:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   39b42:	00 
   39b43:	ba 01 00 00 00       	mov    $0x1,%edx
   39b48:	ff 15 92 ce 0a 00    	call   *0xace92(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39b4e:	e9 f4 06 00 00       	jmp    3a247 <oriole_expat::dispatch+0x6437>
   39b53:	48 89 c3             	mov    %rax,%rbx
   39b56:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   39b5d:	00 
   39b5e:	b0 01                	mov    $0x1,%al
   39b60:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39b64:	48 85 c9             	test   %rcx,%rcx
   39b67:	0f 84 2c 0a 00 00    	je     3a599 <oriole_expat::dispatch+0x6789>
   39b6d:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   39b74:	00 
   39b75:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39b7c:	00 
   39b7d:	ba 01 00 00 00       	mov    $0x1,%edx
   39b82:	ff 15 58 ce 0a 00    	call   *0xace58(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39b88:	e9 0c 0a 00 00       	jmp    3a599 <oriole_expat::dispatch+0x6789>
   39b8d:	48 89 c3             	mov    %rax,%rbx
   39b90:	b0 01                	mov    $0x1,%al
   39b92:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39b96:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   39b9d:	00 
   39b9e:	b0 01                	mov    $0x1,%al
   39ba0:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39ba4:	b0 01                	mov    $0x1,%al
   39ba6:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39baa:	e9 5a 05 00 00       	jmp    3a109 <oriole_expat::dispatch+0x62f9>
   39baf:	48 89 c3             	mov    %rax,%rbx
   39bb2:	b0 01                	mov    $0x1,%al
   39bb4:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39bb8:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   39bbf:	00 
   39bc0:	b0 01                	mov    $0x1,%al
   39bc2:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39bc6:	b0 01                	mov    $0x1,%al
   39bc8:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39bcc:	e9 0b 0e 00 00       	jmp    3a9dc <oriole_expat::dispatch+0x6bcc>
   39bd1:	44 89 74 24 30       	mov    %r14d,0x30(%rsp)
   39bd6:	48 89 c3             	mov    %rax,%rbx
   39bd9:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   39be0:	00 
   39be1:	48 85 c9             	test   %rcx,%rcx
   39be4:	74 18                	je     39bfe <oriole_expat::dispatch+0x5dee>
   39be6:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   39bed:	00 
   39bee:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39bf3:	ba 01 00 00 00       	mov    $0x1,%edx
   39bf8:	ff 15 e2 cd 0a 00    	call   *0xacde2(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39bfe:	45 31 e4             	xor    %r12d,%r12d
   39c01:	e9 eb 01 00 00       	jmp    39df1 <oriole_expat::dispatch+0x5fe1>
   39c06:	48 89 c3             	mov    %rax,%rbx
   39c09:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39c10:	00 
   39c11:	e8 1a 57 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39c16:	31 ed                	xor    %ebp,%ebp
   39c18:	e9 78 03 00 00       	jmp    39f95 <oriole_expat::dispatch+0x6185>
   39c1d:	48 89 c3             	mov    %rax,%rbx
   39c20:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39c27:	00 
   39c28:	e8 03 57 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39c2d:	31 ed                	xor    %ebp,%ebp
   39c2f:	e9 fa 03 00 00       	jmp    3a02e <oriole_expat::dispatch+0x621e>
   39c34:	89 6c 24 30          	mov    %ebp,0x30(%rsp)
   39c38:	48 89 c3             	mov    %rax,%rbx
   39c3b:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
   39c42:	00 
   39c43:	48 85 c9             	test   %rcx,%rcx
   39c46:	74 1b                	je     39c63 <oriole_expat::dispatch+0x5e53>
   39c48:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
   39c4f:	00 
   39c50:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   39c57:	00 
   39c58:	ba 01 00 00 00       	mov    $0x1,%edx
   39c5d:	ff 15 7d cd 0a 00    	call   *0xacd7d(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39c63:	45 31 ed             	xor    %r13d,%r13d
   39c66:	45 31 f6             	xor    %r14d,%r14d
   39c69:	e9 80 0c 00 00       	jmp    3a8ee <oriole_expat::dispatch+0x6ade>
   39c6e:	48 89 c3             	mov    %rax,%rbx
   39c71:	e9 cd 07 00 00       	jmp    3a443 <oriole_expat::dispatch+0x6633>
   39c76:	48 89 c3             	mov    %rax,%rbx
   39c79:	b0 01                	mov    $0x1,%al
   39c7b:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39c7f:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   39c86:	00 
   39c87:	b0 01                	mov    $0x1,%al
   39c89:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39c8d:	b0 01                	mov    $0x1,%al
   39c8f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39c93:	b0 01                	mov    $0x1,%al
   39c95:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39c99:	b0 01                	mov    $0x1,%al
   39c9b:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39c9f:	b0 01                	mov    $0x1,%al
   39ca1:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39ca5:	e9 1d 05 00 00       	jmp    3a1c7 <oriole_expat::dispatch+0x63b7>
   39caa:	48 89 c3             	mov    %rax,%rbx
   39cad:	b0 01                	mov    $0x1,%al
   39caf:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39cb3:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   39cba:	00 
   39cbb:	b0 01                	mov    $0x1,%al
   39cbd:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39cc1:	b0 01                	mov    $0x1,%al
   39cc3:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39cc7:	e9 ab 04 00 00       	jmp    3a177 <oriole_expat::dispatch+0x6367>
   39ccc:	48 89 c3             	mov    %rax,%rbx
   39ccf:	e9 c7 04 00 00       	jmp    3a19b <oriole_expat::dispatch+0x638b>
   39cd4:	48 89 c3             	mov    %rax,%rbx
   39cd7:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   39cde:	00 
   39cdf:	48 85 c9             	test   %rcx,%rcx
   39ce2:	74 18                	je     39cfc <oriole_expat::dispatch+0x5eec>
   39ce4:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   39ceb:	00 
   39cec:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39cf1:	ba 01 00 00 00       	mov    $0x1,%edx
   39cf6:	ff 15 e4 cc 0a 00    	call   *0xacce4(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39cfc:	45 31 f6             	xor    %r14d,%r14d
   39cff:	e9 17 02 00 00       	jmp    39f1b <oriole_expat::dispatch+0x610b>
   39d04:	e9 cc 0d 00 00       	jmp    3aad5 <oriole_expat::dispatch+0x6cc5>
   39d09:	48 89 c3             	mov    %rax,%rbx
   39d0c:	e9 43 06 00 00       	jmp    3a354 <oriole_expat::dispatch+0x6544>
   39d11:	48 89 c3             	mov    %rax,%rbx
   39d14:	e9 8a 05 00 00       	jmp    3a2a3 <oriole_expat::dispatch+0x6493>
   39d19:	48 89 c3             	mov    %rax,%rbx
   39d1c:	e9 e4 06 00 00       	jmp    3a405 <oriole_expat::dispatch+0x65f5>
   39d21:	48 89 c3             	mov    %rax,%rbx
   39d24:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39d2b:	00 
   39d2c:	e8 ff 55 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39d31:	e9 65 04 00 00       	jmp    3a19b <oriole_expat::dispatch+0x638b>
   39d36:	48 89 c3             	mov    %rax,%rbx
   39d39:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   39d40:	00 
   39d41:	b0 01                	mov    $0x1,%al
   39d43:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39d47:	48 85 c9             	test   %rcx,%rcx
   39d4a:	0f 84 a5 03 00 00    	je     3a0f5 <oriole_expat::dispatch+0x62e5>
   39d50:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   39d57:	00 
   39d58:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39d5f:	00 
   39d60:	ba 01 00 00 00       	mov    $0x1,%edx
   39d65:	ff 15 75 cc 0a 00    	call   *0xacc75(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39d6b:	e9 85 03 00 00       	jmp    3a0f5 <oriole_expat::dispatch+0x62e5>
   39d70:	48 89 c3             	mov    %rax,%rbx
   39d73:	b0 01                	mov    $0x1,%al
   39d75:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39d79:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   39d80:	00 
   39d81:	b0 01                	mov    $0x1,%al
   39d83:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39d87:	b0 01                	mov    $0x1,%al
   39d89:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39d8d:	b0 01                	mov    $0x1,%al
   39d8f:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39d93:	e9 1b 08 00 00       	jmp    3a5b3 <oriole_expat::dispatch+0x67a3>
   39d98:	48 89 c3             	mov    %rax,%rbx
   39d9b:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   39da2:	00 
   39da3:	48 85 c9             	test   %rcx,%rcx
   39da6:	0f 84 c2 07 00 00    	je     3a56e <oriole_expat::dispatch+0x675e>
   39dac:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   39db3:	00 
   39db4:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39dbb:	00 
   39dbc:	ba 01 00 00 00       	mov    $0x1,%edx
   39dc1:	ff 15 19 cc 0a 00    	call   *0xacc19(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39dc7:	e9 a2 07 00 00       	jmp    3a56e <oriole_expat::dispatch+0x675e>
   39dcc:	48 89 c3             	mov    %rax,%rbx
   39dcf:	b0 01                	mov    $0x1,%al
   39dd1:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39dd5:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
   39ddc:	00 
   39ddd:	b0 01                	mov    $0x1,%al
   39ddf:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39de3:	b0 01                	mov    $0x1,%al
   39de5:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39de9:	e9 ed 0a 00 00       	jmp    3a8db <oriole_expat::dispatch+0x6acb>
   39dee:	48 89 c3             	mov    %rax,%rbx
   39df1:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   39df8:	00 
   39df9:	41 b5 01             	mov    $0x1,%r13b
   39dfc:	48 85 c9             	test   %rcx,%rcx
   39dff:	74 1b                	je     39e1c <oriole_expat::dispatch+0x600c>
   39e01:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   39e08:	00 
   39e09:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39e10:	00 
   39e11:	ba 01 00 00 00       	mov    $0x1,%edx
   39e16:	ff 15 c4 cb 0a 00    	call   *0xacbc4(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39e1c:	45 31 f6             	xor    %r14d,%r14d
   39e1f:	e9 cf 0a 00 00       	jmp    3a8f3 <oriole_expat::dispatch+0x6ae3>
   39e24:	48 89 c3             	mov    %rax,%rbx
   39e27:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39e2c:	e8 ff 54 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39e31:	b0 01                	mov    $0x1,%al
   39e33:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39e37:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   39e3e:	00 
   39e3f:	b0 01                	mov    $0x1,%al
   39e41:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39e45:	b0 01                	mov    $0x1,%al
   39e47:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39e4b:	b0 01                	mov    $0x1,%al
   39e4d:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39e51:	b0 01                	mov    $0x1,%al
   39e53:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39e57:	e9 27 03 00 00       	jmp    3a183 <oriole_expat::dispatch+0x6373>
   39e5c:	e9 27 08 00 00       	jmp    3a688 <oriole_expat::dispatch+0x6878>
   39e61:	48 89 c3             	mov    %rax,%rbx
   39e64:	e9 4c 06 00 00       	jmp    3a4b5 <oriole_expat::dispatch+0x66a5>
   39e69:	48 89 c3             	mov    %rax,%rbx
   39e6c:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39e71:	e8 ba 54 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39e76:	b0 01                	mov    $0x1,%al
   39e78:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39e7c:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   39e83:	00 
   39e84:	b0 01                	mov    $0x1,%al
   39e86:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39e8a:	b0 01                	mov    $0x1,%al
   39e8c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39e90:	b0 01                	mov    $0x1,%al
   39e92:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39e96:	b0 01                	mov    $0x1,%al
   39e98:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39e9c:	b0 01                	mov    $0x1,%al
   39e9e:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39ea2:	b0 01                	mov    $0x1,%al
   39ea4:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39ea8:	b0 01                	mov    $0x1,%al
   39eaa:	89 44 24 04          	mov    %eax,0x4(%rsp)
   39eae:	b0 01                	mov    $0x1,%al
   39eb0:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39eb4:	b0 01                	mov    $0x1,%al
   39eb6:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   39ebb:	b0 01                	mov    $0x1,%al
   39ebd:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   39ec1:	b0 01                	mov    $0x1,%al
   39ec3:	89 44 24 24          	mov    %eax,0x24(%rsp)
   39ec7:	b0 01                	mov    $0x1,%al
   39ec9:	89 44 24 18          	mov    %eax,0x18(%rsp)
   39ecd:	b0 01                	mov    $0x1,%al
   39ecf:	89 44 24 20          	mov    %eax,0x20(%rsp)
   39ed3:	b0 01                	mov    $0x1,%al
   39ed5:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   39ed9:	40 84 ed             	test   %bpl,%bpl
   39edc:	0f 85 f7 04 00 00    	jne    3a3d9 <oriole_expat::dispatch+0x65c9>
   39ee2:	e9 2f 0c 00 00       	jmp    3ab16 <oriole_expat::dispatch+0x6d06>
   39ee7:	48 89 c3             	mov    %rax,%rbx
   39eea:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   39ef1:	00 
   39ef2:	e8 39 54 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39ef7:	e9 9f 02 00 00       	jmp    3a19b <oriole_expat::dispatch+0x638b>
   39efc:	48 89 c3             	mov    %rax,%rbx
   39eff:	b0 01                	mov    $0x1,%al
   39f01:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39f05:	b0 01                	mov    $0x1,%al
   39f07:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39f0b:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   39f12:	00 
   39f13:	e9 3d 03 00 00       	jmp    3a255 <oriole_expat::dispatch+0x6445>
   39f18:	48 89 c3             	mov    %rax,%rbx
   39f1b:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   39f22:	00 
   39f23:	48 85 c9             	test   %rcx,%rcx
   39f26:	74 1b                	je     39f43 <oriole_expat::dispatch+0x6133>
   39f28:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   39f2f:	00 
   39f30:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   39f37:	00 
   39f38:	ba 01 00 00 00       	mov    $0x1,%edx
   39f3d:	ff 15 9d ca 0a 00    	call   *0xaca9d(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39f43:	45 31 ed             	xor    %r13d,%r13d
   39f46:	e9 2b 05 00 00       	jmp    3a476 <oriole_expat::dispatch+0x6666>
   39f4b:	48 89 c3             	mov    %rax,%rbx
   39f4e:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   39f55:	00 
   39f56:	b0 01                	mov    $0x1,%al
   39f58:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39f5c:	48 85 c9             	test   %rcx,%rcx
   39f5f:	0f 84 e2 02 00 00    	je     3a247 <oriole_expat::dispatch+0x6437>
   39f65:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   39f6c:	00 
   39f6d:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39f72:	ba 01 00 00 00       	mov    $0x1,%edx
   39f77:	ff 15 63 ca 0a 00    	call   *0xaca63(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39f7d:	e9 c5 02 00 00       	jmp    3a247 <oriole_expat::dispatch+0x6437>
   39f82:	48 89 c3             	mov    %rax,%rbx
   39f85:	e9 9c 09 00 00       	jmp    3a926 <oriole_expat::dispatch+0x6b16>
   39f8a:	48 89 c3             	mov    %rax,%rbx
   39f8d:	e9 0a 09 00 00       	jmp    3a89c <oriole_expat::dispatch+0x6a8c>
   39f92:	48 89 c3             	mov    %rax,%rbx
   39f95:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   39f9c:	00 
   39f9d:	48 85 c9             	test   %rcx,%rcx
   39fa0:	74 18                	je     39fba <oriole_expat::dispatch+0x61aa>
   39fa2:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   39fa9:	00 
   39faa:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   39faf:	ba 01 00 00 00       	mov    $0x1,%edx
   39fb4:	ff 15 26 ca 0a 00    	call   *0xaca26(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39fba:	b0 01                	mov    $0x1,%al
   39fbc:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39fc0:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   39fc7:	00 
   39fc8:	b0 01                	mov    $0x1,%al
   39fca:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39fce:	b0 01                	mov    $0x1,%al
   39fd0:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39fd4:	b0 01                	mov    $0x1,%al
   39fd6:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39fda:	b0 01                	mov    $0x1,%al
   39fdc:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39fe0:	b0 01                	mov    $0x1,%al
   39fe2:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39fe6:	b0 01                	mov    $0x1,%al
   39fe8:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39fec:	b0 01                	mov    $0x1,%al
   39fee:	89 44 24 08          	mov    %eax,0x8(%rsp)
   39ff2:	b0 01                	mov    $0x1,%al
   39ff4:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39ff8:	b0 01                	mov    $0x1,%al
   39ffa:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   39fff:	b0 01                	mov    $0x1,%al
   3a001:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a005:	b0 01                	mov    $0x1,%al
   3a007:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a00b:	b0 01                	mov    $0x1,%al
   3a00d:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3a011:	b0 01                	mov    $0x1,%al
   3a013:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3a017:	b0 01                	mov    $0x1,%al
   3a019:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3a01d:	40 84 ed             	test   %bpl,%bpl
   3a020:	0f 85 02 03 00 00    	jne    3a328 <oriole_expat::dispatch+0x6518>
   3a026:	e9 eb 0a 00 00       	jmp    3ab16 <oriole_expat::dispatch+0x6d06>
   3a02b:	48 89 c3             	mov    %rax,%rbx
   3a02e:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   3a035:	00 
   3a036:	48 85 c9             	test   %rcx,%rcx
   3a039:	74 18                	je     3a053 <oriole_expat::dispatch+0x6243>
   3a03b:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   3a042:	00 
   3a043:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3a048:	ba 01 00 00 00       	mov    $0x1,%edx
   3a04d:	ff 15 8d c9 0a 00    	call   *0xac98d(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a053:	b0 01                	mov    $0x1,%al
   3a055:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a059:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3a060:	00 
   3a061:	b0 01                	mov    $0x1,%al
   3a063:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a067:	b0 01                	mov    $0x1,%al
   3a069:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a06d:	b0 01                	mov    $0x1,%al
   3a06f:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a073:	b0 01                	mov    $0x1,%al
   3a075:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a079:	b0 01                	mov    $0x1,%al
   3a07b:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a07f:	b0 01                	mov    $0x1,%al
   3a081:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a085:	b0 01                	mov    $0x1,%al
   3a087:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a08b:	b0 01                	mov    $0x1,%al
   3a08d:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a091:	b0 01                	mov    $0x1,%al
   3a093:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a097:	b0 01                	mov    $0x1,%al
   3a099:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3a09e:	b0 01                	mov    $0x1,%al
   3a0a0:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a0a4:	b0 01                	mov    $0x1,%al
   3a0a6:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a0aa:	b0 01                	mov    $0x1,%al
   3a0ac:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3a0b0:	b0 01                	mov    $0x1,%al
   3a0b2:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3a0b6:	40 84 ed             	test   %bpl,%bpl
   3a0b9:	0f 85 b8 01 00 00    	jne    3a277 <oriole_expat::dispatch+0x6467>
   3a0bf:	e9 52 0a 00 00       	jmp    3ab16 <oriole_expat::dispatch+0x6d06>
   3a0c4:	48 89 c3             	mov    %rax,%rbx
   3a0c7:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   3a0ce:	00 
   3a0cf:	b0 01                	mov    $0x1,%al
   3a0d1:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a0d5:	48 85 c9             	test   %rcx,%rcx
   3a0d8:	74 1b                	je     3a0f5 <oriole_expat::dispatch+0x62e5>
   3a0da:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   3a0e1:	00 
   3a0e2:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3a0e9:	00 
   3a0ea:	ba 01 00 00 00       	mov    $0x1,%edx
   3a0ef:	ff 15 eb c8 0a 00    	call   *0xac8eb(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a0f5:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   3a0fc:	00 
   3a0fd:	b0 01                	mov    $0x1,%al
   3a0ff:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a103:	b0 01                	mov    $0x1,%al
   3a105:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a109:	b0 01                	mov    $0x1,%al
   3a10b:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a10f:	b0 01                	mov    $0x1,%al
   3a111:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a115:	e9 ce 08 00 00       	jmp    3a9e8 <oriole_expat::dispatch+0x6bd8>
   3a11a:	48 89 c3             	mov    %rax,%rbx
   3a11d:	e9 1a 02 00 00       	jmp    3a33c <oriole_expat::dispatch+0x652c>
   3a122:	48 89 c3             	mov    %rax,%rbx
   3a125:	e9 61 01 00 00       	jmp    3a28b <oriole_expat::dispatch+0x647b>
   3a12a:	48 89 c3             	mov    %rax,%rbx
   3a12d:	e9 06 08 00 00       	jmp    3a938 <oriole_expat::dispatch+0x6b28>
   3a132:	48 89 c3             	mov    %rax,%rbx
   3a135:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   3a13c:	00 
   3a13d:	b0 01                	mov    $0x1,%al
   3a13f:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a143:	48 85 c9             	test   %rcx,%rcx
   3a146:	74 1b                	je     3a163 <oriole_expat::dispatch+0x6353>
   3a148:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   3a14f:	00 
   3a150:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3a157:	00 
   3a158:	ba 01 00 00 00       	mov    $0x1,%edx
   3a15d:	ff 15 7d c8 0a 00    	call   *0xac87d(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a163:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   3a16a:	00 
   3a16b:	b0 01                	mov    $0x1,%al
   3a16d:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a171:	b0 01                	mov    $0x1,%al
   3a173:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a177:	b0 01                	mov    $0x1,%al
   3a179:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a17d:	b0 01                	mov    $0x1,%al
   3a17f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a183:	b0 01                	mov    $0x1,%al
   3a185:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a189:	e9 60 08 00 00       	jmp    3a9ee <oriole_expat::dispatch+0x6bde>
   3a18e:	48 89 c3             	mov    %rax,%rbx
   3a191:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3a196:	e8 95 51 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a19b:	b0 01                	mov    $0x1,%al
   3a19d:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a1a1:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   3a1a8:	00 
   3a1a9:	b0 01                	mov    $0x1,%al
   3a1ab:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a1af:	b0 01                	mov    $0x1,%al
   3a1b1:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a1b5:	b0 01                	mov    $0x1,%al
   3a1b7:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a1bb:	b0 01                	mov    $0x1,%al
   3a1bd:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a1c1:	b0 01                	mov    $0x1,%al
   3a1c3:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a1c7:	b0 01                	mov    $0x1,%al
   3a1c9:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a1cd:	b0 01                	mov    $0x1,%al
   3a1cf:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a1d3:	b0 01                	mov    $0x1,%al
   3a1d5:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a1d9:	e9 22 08 00 00       	jmp    3aa00 <oriole_expat::dispatch+0x6bf0>
   3a1de:	48 89 c3             	mov    %rax,%rbx
   3a1e1:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3a1e6:	e8 45 51 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a1eb:	b0 01                	mov    $0x1,%al
   3a1ed:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a1f1:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   3a1f8:	00 
   3a1f9:	b0 01                	mov    $0x1,%al
   3a1fb:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a1ff:	b0 01                	mov    $0x1,%al
   3a201:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a205:	b0 01                	mov    $0x1,%al
   3a207:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a20b:	b0 01                	mov    $0x1,%al
   3a20d:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a211:	e9 d2 07 00 00       	jmp    3a9e8 <oriole_expat::dispatch+0x6bd8>
   3a216:	48 89 c3             	mov    %rax,%rbx
   3a219:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   3a220:	00 
   3a221:	b0 01                	mov    $0x1,%al
   3a223:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a227:	48 85 c9             	test   %rcx,%rcx
   3a22a:	74 1b                	je     3a247 <oriole_expat::dispatch+0x6437>
   3a22c:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
   3a233:	00 
   3a234:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3a23b:	00 
   3a23c:	ba 01 00 00 00       	mov    $0x1,%edx
   3a241:	ff 15 99 c7 0a 00    	call   *0xac799(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a247:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   3a24e:	00 
   3a24f:	b0 01                	mov    $0x1,%al
   3a251:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a255:	b0 01                	mov    $0x1,%al
   3a257:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a25b:	e9 7c 07 00 00       	jmp    3a9dc <oriole_expat::dispatch+0x6bcc>
   3a260:	48 89 c3             	mov    %rax,%rbx
   3a263:	e9 85 01 00 00       	jmp    3a3ed <oriole_expat::dispatch+0x65dd>
   3a268:	48 89 c3             	mov    %rax,%rbx
   3a26b:	e9 a4 06 00 00       	jmp    3a914 <oriole_expat::dispatch+0x6b04>
   3a270:	89 6c 24 18          	mov    %ebp,0x18(%rsp)
   3a274:	48 89 c3             	mov    %rax,%rbx
   3a277:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3a27e:	00 
   3a27f:	e8 ac 50 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a284:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
   3a289:	74 65                	je     3a2f0 <oriole_expat::dispatch+0x64e0>
   3a28b:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   3a292:	00 
   3a293:	e8 98 50 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a298:	48 83 bc 24 88 04 00 	cmpq   $0x0,0x488(%rsp)
   3a29f:	00 00 
   3a2a1:	75 4d                	jne    3a2f0 <oriole_expat::dispatch+0x64e0>
   3a2a3:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   3a2aa:	00 
   3a2ab:	b0 01                	mov    $0x1,%al
   3a2ad:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a2b1:	48 85 c9             	test   %rcx,%rcx
   3a2b4:	74 1b                	je     3a2d1 <oriole_expat::dispatch+0x64c1>
   3a2b6:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   3a2bd:	00 
   3a2be:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   3a2c5:	00 
   3a2c6:	ba 01 00 00 00       	mov    $0x1,%edx
   3a2cb:	ff 15 0f c7 0a 00    	call   *0xac70f(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a2d1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3a2d8:	00 
   3a2d9:	b0 01                	mov    $0x1,%al
   3a2db:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a2df:	b0 01                	mov    $0x1,%al
   3a2e1:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a2e5:	b0 01                	mov    $0x1,%al
   3a2e7:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a2eb:	e9 d8 04 00 00       	jmp    3a7c8 <oriole_expat::dispatch+0x69b8>
   3a2f0:	b0 01                	mov    $0x1,%al
   3a2f2:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a2f6:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3a2fd:	00 
   3a2fe:	b0 01                	mov    $0x1,%al
   3a300:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a304:	b0 01                	mov    $0x1,%al
   3a306:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a30a:	b0 01                	mov    $0x1,%al
   3a30c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a310:	b0 01                	mov    $0x1,%al
   3a312:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a316:	b0 01                	mov    $0x1,%al
   3a318:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a31c:	e9 b3 04 00 00       	jmp    3a7d4 <oriole_expat::dispatch+0x69c4>
   3a321:	89 6c 24 04          	mov    %ebp,0x4(%rsp)
   3a325:	48 89 c3             	mov    %rax,%rbx
   3a328:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3a32f:	00 
   3a330:	e8 fb 4f ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a335:	80 7c 24 04 00       	cmpb   $0x0,0x4(%rsp)
   3a33a:	74 65                	je     3a3a1 <oriole_expat::dispatch+0x6591>
   3a33c:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   3a343:	00 
   3a344:	e8 e7 4f ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a349:	48 83 bc 24 18 02 00 	cmpq   $0x0,0x218(%rsp)
   3a350:	00 00 
   3a352:	75 4d                	jne    3a3a1 <oriole_expat::dispatch+0x6591>
   3a354:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   3a35b:	00 
   3a35c:	b0 01                	mov    $0x1,%al
   3a35e:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a362:	48 85 c9             	test   %rcx,%rcx
   3a365:	74 1b                	je     3a382 <oriole_expat::dispatch+0x6572>
   3a367:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   3a36e:	00 
   3a36f:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   3a376:	00 
   3a377:	ba 01 00 00 00       	mov    $0x1,%edx
   3a37c:	ff 15 5e c6 0a 00    	call   *0xac65e(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a382:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   3a389:	00 
   3a38a:	b0 01                	mov    $0x1,%al
   3a38c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a390:	b0 01                	mov    $0x1,%al
   3a392:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a396:	b0 01                	mov    $0x1,%al
   3a398:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a39c:	e9 99 03 00 00       	jmp    3a73a <oriole_expat::dispatch+0x692a>
   3a3a1:	b0 01                	mov    $0x1,%al
   3a3a3:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a3a7:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   3a3ae:	00 
   3a3af:	b0 01                	mov    $0x1,%al
   3a3b1:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a3b5:	b0 01                	mov    $0x1,%al
   3a3b7:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a3bb:	b0 01                	mov    $0x1,%al
   3a3bd:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a3c1:	b0 01                	mov    $0x1,%al
   3a3c3:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a3c7:	b0 01                	mov    $0x1,%al
   3a3c9:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a3cd:	e9 74 03 00 00       	jmp    3a746 <oriole_expat::dispatch+0x6936>
   3a3d2:	89 6c 24 08          	mov    %ebp,0x8(%rsp)
   3a3d6:	48 89 c3             	mov    %rax,%rbx
   3a3d9:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   3a3e0:	00 
   3a3e1:	e8 4a 4f ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a3e6:	80 7c 24 08 00       	cmpb   $0x0,0x8(%rsp)
   3a3eb:	74 56                	je     3a443 <oriole_expat::dispatch+0x6633>
   3a3ed:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   3a3f4:	00 
   3a3f5:	e8 36 4f ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a3fa:	48 83 bc 24 80 05 00 	cmpq   $0x0,0x580(%rsp)
   3a401:	00 00 
   3a403:	75 3e                	jne    3a443 <oriole_expat::dispatch+0x6633>
   3a405:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   3a40c:	00 
   3a40d:	e8 1e 4f ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a412:	b0 01                	mov    $0x1,%al
   3a414:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a418:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   3a41f:	00 
   3a420:	b0 01                	mov    $0x1,%al
   3a422:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a426:	b0 01                	mov    $0x1,%al
   3a428:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a42c:	b0 01                	mov    $0x1,%al
   3a42e:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a432:	b0 01                	mov    $0x1,%al
   3a434:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a438:	b0 01                	mov    $0x1,%al
   3a43a:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a43e:	e9 03 04 00 00       	jmp    3a846 <oriole_expat::dispatch+0x6a36>
   3a443:	b0 01                	mov    $0x1,%al
   3a445:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a449:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   3a450:	00 
   3a451:	b0 01                	mov    $0x1,%al
   3a453:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a457:	b0 01                	mov    $0x1,%al
   3a459:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a45d:	b0 01                	mov    $0x1,%al
   3a45f:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a463:	b0 01                	mov    $0x1,%al
   3a465:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a469:	e9 d2 03 00 00       	jmp    3a840 <oriole_expat::dispatch+0x6a30>
   3a46e:	48 89 c3             	mov    %rax,%rbx
   3a471:	eb 15                	jmp    3a488 <oriole_expat::dispatch+0x6678>
   3a473:	48 89 c3             	mov    %rax,%rbx
   3a476:	40 84 ed             	test   %bpl,%bpl
   3a479:	74 0d                	je     3a488 <oriole_expat::dispatch+0x6678>
   3a47b:	48 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%rdi
   3a482:	00 
   3a483:	e8 a8 4e ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a488:	45 84 f6             	test   %r14b,%r14b
   3a48b:	74 28                	je     3a4b5 <oriole_expat::dispatch+0x66a5>
   3a48d:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   3a494:	00 
   3a495:	48 85 c9             	test   %rcx,%rcx
   3a498:	74 1b                	je     3a4b5 <oriole_expat::dispatch+0x66a5>
   3a49a:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
   3a4a1:	00 
   3a4a2:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   3a4a9:	00 
   3a4aa:	ba 01 00 00 00       	mov    $0x1,%edx
   3a4af:	ff 15 2b c5 0a 00    	call   *0xac52b(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a4b5:	45 84 ed             	test   %r13b,%r13b
   3a4b8:	74 28                	je     3a4e2 <oriole_expat::dispatch+0x66d2>
   3a4ba:	48 8b 8c 24 b8 04 00 	mov    0x4b8(%rsp),%rcx
   3a4c1:	00 
   3a4c2:	48 85 c9             	test   %rcx,%rcx
   3a4c5:	74 1b                	je     3a4e2 <oriole_expat::dispatch+0x66d2>
   3a4c7:	48 8b b4 24 b0 04 00 	mov    0x4b0(%rsp),%rsi
   3a4ce:	00 
   3a4cf:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
   3a4d6:	00 
   3a4d7:	ba 01 00 00 00       	mov    $0x1,%edx
   3a4dc:	ff 15 fe c4 0a 00    	call   *0xac4fe(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a4e2:	48 83 bc 24 70 04 00 	cmpq   $0x0,0x470(%rsp)
   3a4e9:	00 00 
   3a4eb:	75 4d                	jne    3a53a <oriole_expat::dispatch+0x672a>
   3a4ed:	48 8b 8c 24 f8 04 00 	mov    0x4f8(%rsp),%rcx
   3a4f4:	00 
   3a4f5:	b0 01                	mov    $0x1,%al
   3a4f7:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a4fb:	48 85 c9             	test   %rcx,%rcx
   3a4fe:	74 1b                	je     3a51b <oriole_expat::dispatch+0x670b>
   3a500:	48 8b b4 24 f0 04 00 	mov    0x4f0(%rsp),%rsi
   3a507:	00 
   3a508:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
   3a50f:	00 
   3a510:	ba 01 00 00 00       	mov    $0x1,%edx
   3a515:	ff 15 c5 c4 0a 00    	call   *0xac4c5(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a51b:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   3a522:	00 
   3a523:	b0 01                	mov    $0x1,%al
   3a525:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a529:	b0 01                	mov    $0x1,%al
   3a52b:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a52f:	b0 01                	mov    $0x1,%al
   3a531:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a535:	e9 94 01 00 00       	jmp    3a6ce <oriole_expat::dispatch+0x68be>
   3a53a:	b0 01                	mov    $0x1,%al
   3a53c:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a540:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   3a547:	00 
   3a548:	b0 01                	mov    $0x1,%al
   3a54a:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a54e:	b0 01                	mov    $0x1,%al
   3a550:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a554:	b0 01                	mov    $0x1,%al
   3a556:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a55a:	b0 01                	mov    $0x1,%al
   3a55c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a560:	b0 01                	mov    $0x1,%al
   3a562:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a566:	e9 6f 01 00 00       	jmp    3a6da <oriole_expat::dispatch+0x68ca>
   3a56b:	48 89 c3             	mov    %rax,%rbx
   3a56e:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   3a575:	00 
   3a576:	b0 01                	mov    $0x1,%al
   3a578:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a57c:	48 85 c9             	test   %rcx,%rcx
   3a57f:	74 18                	je     3a599 <oriole_expat::dispatch+0x6789>
   3a581:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   3a588:	00 
   3a589:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3a58e:	ba 01 00 00 00       	mov    $0x1,%edx
   3a593:	ff 15 47 c4 0a 00    	call   *0xac447(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a599:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   3a5a0:	00 
   3a5a1:	b0 01                	mov    $0x1,%al
   3a5a3:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a5a7:	b0 01                	mov    $0x1,%al
   3a5a9:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a5ad:	b0 01                	mov    $0x1,%al
   3a5af:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a5b3:	b0 01                	mov    $0x1,%al
   3a5b5:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a5b9:	b0 01                	mov    $0x1,%al
   3a5bb:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a5bf:	b0 01                	mov    $0x1,%al
   3a5c1:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a5c5:	b0 01                	mov    $0x1,%al
   3a5c7:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a5cb:	b0 01                	mov    $0x1,%al
   3a5cd:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a5d1:	b0 01                	mov    $0x1,%al
   3a5d3:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a5d7:	b0 01                	mov    $0x1,%al
   3a5d9:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3a5de:	b0 01                	mov    $0x1,%al
   3a5e0:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a5e4:	b0 01                	mov    $0x1,%al
   3a5e6:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a5ea:	b0 01                	mov    $0x1,%al
   3a5ec:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3a5f0:	e9 2a 04 00 00       	jmp    3aa1f <oriole_expat::dispatch+0x6c0f>
   3a5f5:	48 89 c3             	mov    %rax,%rbx
   3a5f8:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   3a5ff:	00 
   3a600:	e8 2b 4d ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a605:	e9 f0 07 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3a60a:	48 89 c3             	mov    %rax,%rbx
   3a60d:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   3a614:	00 
   3a615:	48 85 c9             	test   %rcx,%rcx
   3a618:	0f 84 dc 07 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3a61e:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3a625:	00 
   3a626:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   3a62d:	00 
   3a62e:	ba 01 00 00 00       	mov    $0x1,%edx
   3a633:	ff 15 a7 c3 0a 00    	call   *0xac3a7(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a639:	e9 bc 07 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3a63e:	48 89 c3             	mov    %rax,%rbx
   3a641:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   3a648:	00 
   3a649:	b0 01                	mov    $0x1,%al
   3a64b:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a64f:	48 85 c9             	test   %rcx,%rcx
   3a652:	74 1b                	je     3a66f <oriole_expat::dispatch+0x685f>
   3a654:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
   3a65b:	00 
   3a65c:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3a663:	00 
   3a664:	ba 01 00 00 00       	mov    $0x1,%edx
   3a669:	ff 15 71 c3 0a 00    	call   *0xac371(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a66f:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   3a676:	00 
   3a677:	e9 53 02 00 00       	jmp    3a8cf <oriole_expat::dispatch+0x6abf>
   3a67c:	89 6c 24 30          	mov    %ebp,0x30(%rsp)
   3a680:	48 89 c3             	mov    %rax,%rbx
   3a683:	e9 78 02 00 00       	jmp    3a900 <oriole_expat::dispatch+0x6af0>
   3a688:	48 89 c3             	mov    %rax,%rbx
   3a68b:	b0 01                	mov    $0x1,%al
   3a68d:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a691:	e9 55 04 00 00       	jmp    3aaeb <oriole_expat::dispatch+0x6cdb>
   3a696:	48 89 c3             	mov    %rax,%rbx
   3a699:	e9 f1 01 00 00       	jmp    3a88f <oriole_expat::dispatch+0x6a7f>
   3a69e:	48 89 c3             	mov    %rax,%rbx
   3a6a1:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3a6a8:	00 
   3a6a9:	e8 52 65 ff ff       	call   30c00 <core::ptr::drop_glue::<oriole::AttributeDeclaration>>
   3a6ae:	b0 01                	mov    $0x1,%al
   3a6b0:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a6b4:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   3a6bb:	00 
   3a6bc:	b0 01                	mov    $0x1,%al
   3a6be:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a6c2:	b0 01                	mov    $0x1,%al
   3a6c4:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a6c8:	b0 01                	mov    $0x1,%al
   3a6ca:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a6ce:	b0 01                	mov    $0x1,%al
   3a6d0:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a6d4:	b0 01                	mov    $0x1,%al
   3a6d6:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a6da:	b0 01                	mov    $0x1,%al
   3a6dc:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a6e0:	b0 01                	mov    $0x1,%al
   3a6e2:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a6e6:	b0 01                	mov    $0x1,%al
   3a6e8:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a6ec:	b0 01                	mov    $0x1,%al
   3a6ee:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a6f2:	b0 01                	mov    $0x1,%al
   3a6f4:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3a6f9:	b0 01                	mov    $0x1,%al
   3a6fb:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a6ff:	e9 0f 03 00 00       	jmp    3aa13 <oriole_expat::dispatch+0x6c03>
   3a704:	ff 15 1e c9 0a 00    	call   *0xac91e(%rip)        # e7028 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a70a:	48 89 c3             	mov    %rax,%rbx
   3a70d:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3a714:	00 
   3a715:	e8 86 63 ff ff       	call   30aa0 <core::ptr::drop_glue::<oriole::DoctypeDeclaration>>
   3a71a:	b0 01                	mov    $0x1,%al
   3a71c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a720:	c7 44 24 04 00 00 00 	movl   $0x0,0x4(%rsp)
   3a727:	00 
   3a728:	b0 01                	mov    $0x1,%al
   3a72a:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a72e:	b0 01                	mov    $0x1,%al
   3a730:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a734:	b0 01                	mov    $0x1,%al
   3a736:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a73a:	b0 01                	mov    $0x1,%al
   3a73c:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a740:	b0 01                	mov    $0x1,%al
   3a742:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a746:	b0 01                	mov    $0x1,%al
   3a748:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a74c:	b0 01                	mov    $0x1,%al
   3a74e:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a752:	e9 a3 02 00 00       	jmp    3a9fa <oriole_expat::dispatch+0x6bea>
   3a757:	ff 15 cb c8 0a 00    	call   *0xac8cb(%rip)        # e7028 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a75d:	48 89 c3             	mov    %rax,%rbx
   3a760:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3a767:	00 
   3a768:	e8 03 62 ff ff       	call   30970 <core::ptr::drop_glue::<oriole::EntityDeclaration>>
   3a76d:	b0 01                	mov    $0x1,%al
   3a76f:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a773:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   3a77a:	00 
   3a77b:	b0 01                	mov    $0x1,%al
   3a77d:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a781:	b0 01                	mov    $0x1,%al
   3a783:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a787:	b0 01                	mov    $0x1,%al
   3a789:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a78d:	e9 f3 01 00 00       	jmp    3a985 <oriole_expat::dispatch+0x6b75>
   3a792:	ff 15 90 c8 0a 00    	call   *0xac890(%rip)        # e7028 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a798:	48 89 c3             	mov    %rax,%rbx
   3a79b:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3a7a2:	00 
   3a7a3:	e8 a8 63 ff ff       	call   30b50 <core::ptr::drop_glue::<oriole::NotationDeclaration>>
   3a7a8:	b0 01                	mov    $0x1,%al
   3a7aa:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a7ae:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3a7b5:	00 
   3a7b6:	b0 01                	mov    $0x1,%al
   3a7b8:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a7bc:	b0 01                	mov    $0x1,%al
   3a7be:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a7c2:	b0 01                	mov    $0x1,%al
   3a7c4:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a7c8:	b0 01                	mov    $0x1,%al
   3a7ca:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a7ce:	b0 01                	mov    $0x1,%al
   3a7d0:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a7d4:	b0 01                	mov    $0x1,%al
   3a7d6:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a7da:	b0 01                	mov    $0x1,%al
   3a7dc:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a7e0:	b0 01                	mov    $0x1,%al
   3a7e2:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a7e6:	b0 01                	mov    $0x1,%al
   3a7e8:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a7ec:	b0 01                	mov    $0x1,%al
   3a7ee:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3a7f3:	b0 01                	mov    $0x1,%al
   3a7f5:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a7f9:	b0 01                	mov    $0x1,%al
   3a7fb:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a7ff:	e9 15 02 00 00       	jmp    3aa19 <oriole_expat::dispatch+0x6c09>
   3a804:	ff 15 1e c8 0a 00    	call   *0xac81e(%rip)        # e7028 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a80a:	48 89 c3             	mov    %rax,%rbx
   3a80d:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3a814:	00 
   3a815:	e8 f6 64 ff ff       	call   30d10 <core::ptr::drop_glue::<oriole::ExternalEntityReference>>
   3a81a:	b0 01                	mov    $0x1,%al
   3a81c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a820:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   3a827:	00 
   3a828:	b0 01                	mov    $0x1,%al
   3a82a:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a82e:	b0 01                	mov    $0x1,%al
   3a830:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a834:	b0 01                	mov    $0x1,%al
   3a836:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a83a:	b0 01                	mov    $0x1,%al
   3a83c:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a840:	b0 01                	mov    $0x1,%al
   3a842:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a846:	b0 01                	mov    $0x1,%al
   3a848:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a84c:	e9 a3 01 00 00       	jmp    3a9f4 <oriole_expat::dispatch+0x6be4>
   3a851:	ff 15 d1 c7 0a 00    	call   *0xac7d1(%rip)        # e7028 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a857:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
   3a85c:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
   3a861:	eb 00                	jmp    3a863 <oriole_expat::dispatch+0x6a53>
   3a863:	48 89 c3             	mov    %rax,%rbx
   3a866:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
   3a86c:	74 21                	je     3a88f <oriole_expat::dispatch+0x6a7f>
   3a86e:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   3a873:	48 c1 e1 03          	shl    $0x3,%rcx
   3a877:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3a87e:	00 
   3a87f:	ba 08 00 00 00       	mov    $0x8,%edx
   3a884:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   3a889:	ff 15 51 c1 0a 00    	call   *0xac151(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a88f:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3a896:	00 
   3a897:	e8 b4 57 ff ff       	call   30050 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3a89c:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
   3a8a3:	00 
   3a8a4:	b0 01                	mov    $0x1,%al
   3a8a6:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a8aa:	48 85 c9             	test   %rcx,%rcx
   3a8ad:	74 18                	je     3a8c7 <oriole_expat::dispatch+0x6ab7>
   3a8af:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
   3a8b6:	00 
   3a8b7:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3a8bc:	ba 01 00 00 00       	mov    $0x1,%edx
   3a8c1:	ff 15 19 c1 0a 00    	call   *0xac119(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a8c7:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
   3a8ce:	00 
   3a8cf:	b0 01                	mov    $0x1,%al
   3a8d1:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a8d5:	b0 01                	mov    $0x1,%al
   3a8d7:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a8db:	b0 01                	mov    $0x1,%al
   3a8dd:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a8e1:	e9 fc 00 00 00       	jmp    3a9e2 <oriole_expat::dispatch+0x6bd2>
   3a8e6:	44 8b 7c 24 38       	mov    0x38(%rsp),%r15d
   3a8eb:	48 89 c3             	mov    %rax,%rbx
   3a8ee:	45 84 ff             	test   %r15b,%r15b
   3a8f1:	74 0d                	je     3a900 <oriole_expat::dispatch+0x6af0>
   3a8f3:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   3a8fa:	00 
   3a8fb:	e8 30 4a ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a900:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
   3a905:	74 0d                	je     3a914 <oriole_expat::dispatch+0x6b04>
   3a907:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
   3a90e:	00 
   3a90f:	e8 1c 4a ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a914:	45 84 e4             	test   %r12b,%r12b
   3a917:	74 0d                	je     3a926 <oriole_expat::dispatch+0x6b16>
   3a919:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
   3a920:	00 
   3a921:	e8 0a 4a ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a926:	45 84 ed             	test   %r13b,%r13b
   3a929:	74 0d                	je     3a938 <oriole_expat::dispatch+0x6b28>
   3a92b:	48 8d bc 24 d0 05 00 	lea    0x5d0(%rsp),%rdi
   3a932:	00 
   3a933:	e8 f8 49 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a938:	b0 01                	mov    $0x1,%al
   3a93a:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a93e:	45 84 f6             	test   %r14b,%r14b
   3a941:	74 28                	je     3a96b <oriole_expat::dispatch+0x6b5b>
   3a943:	48 8b 8c 24 68 05 00 	mov    0x568(%rsp),%rcx
   3a94a:	00 
   3a94b:	48 85 c9             	test   %rcx,%rcx
   3a94e:	74 1b                	je     3a96b <oriole_expat::dispatch+0x6b5b>
   3a950:	48 8b b4 24 60 05 00 	mov    0x560(%rsp),%rsi
   3a957:	00 
   3a958:	48 8d bc 24 40 05 00 	lea    0x540(%rsp),%rdi
   3a95f:	00 
   3a960:	ba 01 00 00 00       	mov    $0x1,%edx
   3a965:	ff 15 75 c0 0a 00    	call   *0xac075(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a96b:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   3a972:	00 
   3a973:	b0 01                	mov    $0x1,%al
   3a975:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a979:	b0 01                	mov    $0x1,%al
   3a97b:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a97f:	b0 01                	mov    $0x1,%al
   3a981:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a985:	b0 01                	mov    $0x1,%al
   3a987:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a98b:	b0 01                	mov    $0x1,%al
   3a98d:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a991:	b0 01                	mov    $0x1,%al
   3a993:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a997:	b0 01                	mov    $0x1,%al
   3a999:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a99d:	b0 01                	mov    $0x1,%al
   3a99f:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a9a3:	b0 01                	mov    $0x1,%al
   3a9a5:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a9a9:	b0 01                	mov    $0x1,%al
   3a9ab:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3a9b0:	eb 5b                	jmp    3aa0d <oriole_expat::dispatch+0x6bfd>
   3a9b2:	48 89 c3             	mov    %rax,%rbx
   3a9b5:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
   3a9bc:	00 
   3a9bd:	e8 be 78 ff ff       	call   32280 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   3a9c2:	b0 01                	mov    $0x1,%al
   3a9c4:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a9c8:	b0 01                	mov    $0x1,%al
   3a9ca:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a9ce:	b0 01                	mov    $0x1,%al
   3a9d0:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a9d4:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   3a9db:	00 
   3a9dc:	b0 01                	mov    $0x1,%al
   3a9de:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a9e2:	b0 01                	mov    $0x1,%al
   3a9e4:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a9e8:	b0 01                	mov    $0x1,%al
   3a9ea:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a9ee:	b0 01                	mov    $0x1,%al
   3a9f0:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a9f4:	b0 01                	mov    $0x1,%al
   3a9f6:	89 44 24 04          	mov    %eax,0x4(%rsp)
   3a9fa:	b0 01                	mov    $0x1,%al
   3a9fc:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3aa00:	b0 01                	mov    $0x1,%al
   3aa02:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3aa07:	b0 01                	mov    $0x1,%al
   3aa09:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3aa0d:	b0 01                	mov    $0x1,%al
   3aa0f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3aa13:	b0 01                	mov    $0x1,%al
   3aa15:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3aa19:	b0 01                	mov    $0x1,%al
   3aa1b:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3aa1f:	b0 01                	mov    $0x1,%al
   3aa21:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3aa25:	e9 ec 00 00 00       	jmp    3ab16 <oriole_expat::dispatch+0x6d06>
   3aa2a:	48 89 c3             	mov    %rax,%rbx
   3aa2d:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   3aa34:	00 
   3aa35:	48 85 c9             	test   %rcx,%rcx
   3aa38:	0f 84 bc 03 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3aa3e:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   3aa45:	00 
   3aa46:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
   3aa4d:	00 
   3aa4e:	ba 01 00 00 00       	mov    $0x1,%edx
   3aa53:	ff 15 87 bf 0a 00    	call   *0xabf87(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3aa59:	e9 9c 03 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3aa5e:	48 89 c3             	mov    %rax,%rbx
   3aa61:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   3aa68:	00 
   3aa69:	48 85 c9             	test   %rcx,%rcx
   3aa6c:	0f 84 88 03 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3aa72:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   3aa79:	00 
   3aa7a:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
   3aa81:	00 
   3aa82:	ba 01 00 00 00       	mov    $0x1,%edx
   3aa87:	ff 15 53 bf 0a 00    	call   *0xabf53(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3aa8d:	e9 68 03 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3aa92:	48 89 c3             	mov    %rax,%rbx
   3aa95:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
   3aa9c:	00 
   3aa9d:	e8 8e 48 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3aaa2:	e9 53 03 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3aaa7:	48 89 c3             	mov    %rax,%rbx
   3aaaa:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   3aab1:	00 
   3aab2:	e8 99 55 ff ff       	call   30050 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3aab7:	e9 3e 03 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3aabc:	44 89 6c 24 1c       	mov    %r13d,0x1c(%rsp)
   3aac1:	44 89 7c 24 20       	mov    %r15d,0x20(%rsp)
   3aac6:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   3aacb:	44 89 74 24 24       	mov    %r14d,0x24(%rsp)
   3aad0:	48 89 c3             	mov    %rax,%rbx
   3aad3:	eb 41                	jmp    3ab16 <oriole_expat::dispatch+0x6d06>
   3aad5:	48 89 c3             	mov    %rax,%rbx
   3aad8:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
   3aadf:	00 
   3aae0:	b0 01                	mov    $0x1,%al
   3aae2:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3aae6:	48 85 c9             	test   %rcx,%rcx
   3aae9:	75 09                	jne    3aaf4 <oriole_expat::dispatch+0x6ce4>
   3aaeb:	b0 01                	mov    $0x1,%al
   3aaed:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3aaf2:	eb 22                	jmp    3ab16 <oriole_expat::dispatch+0x6d06>
   3aaf4:	48 8d bc 24 20 02 00 	lea    0x220(%rsp),%rdi
   3aafb:	00 
   3aafc:	ba 01 00 00 00       	mov    $0x1,%edx
   3ab01:	48 8b b4 24 18 02 00 	mov    0x218(%rsp),%rsi
   3ab08:	00 
   3ab09:	ff 15 d1 be 0a 00    	call   *0xabed1(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3ab0f:	b0 01                	mov    $0x1,%al
   3ab11:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3ab16:	8b 44 24 2c          	mov    0x2c(%rsp),%eax
   3ab1a:	41 89 c6             	mov    %eax,%r14d
   3ab1d:	48 8d bc 24 08 05 00 	lea    0x508(%rsp),%rdi
   3ab24:	00 
   3ab25:	e8 06 48 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3ab2a:	eb 0a                	jmp    3ab36 <oriole_expat::dispatch+0x6d26>
   3ab2c:	48 89 c3             	mov    %rax,%rbx
   3ab2f:	8b 44 24 2c          	mov    0x2c(%rsp),%eax
   3ab33:	41 89 c6             	mov    %eax,%r14d
   3ab36:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
   3ab3d:	00 
   3ab3e:	48 83 e9 03          	sub    $0x3,%rcx
   3ab42:	b8 0d 00 00 00       	mov    $0xd,%eax
   3ab47:	48 0f 43 c1          	cmovae %rcx,%rax
   3ab4b:	48 83 c0 fa          	add    $0xfffffffffffffffa,%rax
   3ab4f:	48 83 f8 14          	cmp    $0x14,%rax
   3ab53:	0f 87 a1 02 00 00    	ja     3adfa <oriole_expat::dispatch+0x6fea>
   3ab59:	48 8d ac 24 60 01 00 	lea    0x160(%rsp),%rbp
   3ab60:	00 
   3ab61:	4c 8d a4 24 80 01 00 	lea    0x180(%rsp),%r12
   3ab68:	00 
   3ab69:	4c 8d bc 24 28 01 00 	lea    0x128(%rsp),%r15
   3ab70:	00 
   3ab71:	4c 8d ac 24 48 01 00 	lea    0x148(%rsp),%r13
   3ab78:	00 
   3ab79:	48 8d 0d 90 f2 fc ff 	lea    -0x30d70(%rip),%rcx        # 9e10 <std::thread::current::id::ID+0x9da0>
   3ab80:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   3ab84:	48 01 c8             	add    %rcx,%rax
   3ab87:	ff e0                	jmp    *%rax
   3ab89:	45 84 f6             	test   %r14b,%r14b
   3ab8c:	0f 84 68 02 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3ab92:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   3ab99:	00 
   3ab9a:	48 85 c9             	test   %rcx,%rcx
   3ab9d:	74 1b                	je     3abba <oriole_expat::dispatch+0x6daa>
   3ab9f:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3aba6:	00 
   3aba7:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   3abae:	00 
   3abaf:	ba 01 00 00 00       	mov    $0x1,%edx
   3abb4:	ff 15 26 be 0a 00    	call   *0xabe26(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3abba:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   3abc1:	00 
   3abc2:	e8 89 54 ff ff       	call   30050 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3abc7:	e9 2e 02 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3abcc:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   3abd3:	00 
   3abd4:	48 85 c9             	test   %rcx,%rcx
   3abd7:	0f 95 c0             	setne  %al
   3abda:	84 44 24 30          	test   %al,0x30(%rsp)
   3abde:	0f 85 fe 01 00 00    	jne    3ade2 <oriole_expat::dispatch+0x6fd2>
   3abe4:	e9 11 02 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3abe9:	80 7c 24 48 00       	cmpb   $0x0,0x48(%rsp)
   3abee:	0f 84 06 02 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3abf4:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3abfb:	00 
   3abfc:	e8 7f 76 ff ff       	call   32280 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   3ac01:	e9 f4 01 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3ac06:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   3ac0d:	00 
   3ac0e:	48 85 c9             	test   %rcx,%rcx
   3ac11:	0f 95 c0             	setne  %al
   3ac14:	84 44 24 38          	test   %al,0x38(%rsp)
   3ac18:	0f 85 c4 01 00 00    	jne    3ade2 <oriole_expat::dispatch+0x6fd2>
   3ac1e:	e9 d7 01 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3ac23:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
   3ac28:	0f 84 cc 01 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3ac2e:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   3ac35:	00 
   3ac36:	48 85 c9             	test   %rcx,%rcx
   3ac39:	0f 84 80 01 00 00    	je     3adbf <oriole_expat::dispatch+0x6faf>
   3ac3f:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3ac46:	00 
   3ac47:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   3ac4e:	00 
   3ac4f:	ba 01 00 00 00       	mov    $0x1,%edx
   3ac54:	ff 15 86 bd 0a 00    	call   *0xabd86(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3ac5a:	e9 60 01 00 00       	jmp    3adbf <oriole_expat::dispatch+0x6faf>
   3ac5f:	80 7c 24 10 00       	cmpb   $0x0,0x10(%rsp)
   3ac64:	0f 84 90 01 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3ac6a:	4c 8d bc 24 58 01 00 	lea    0x158(%rsp),%r15
   3ac71:	00 
   3ac72:	48 8b 8c 24 48 01 00 	mov    0x148(%rsp),%rcx
   3ac79:	00 
   3ac7a:	48 85 c9             	test   %rcx,%rcx
   3ac7d:	0f 84 b0 00 00 00    	je     3ad33 <oriole_expat::dispatch+0x6f23>
   3ac83:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
   3ac8a:	00 
   3ac8b:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   3ac92:	00 
   3ac93:	ba 01 00 00 00       	mov    $0x1,%edx
   3ac98:	ff 15 42 bd 0a 00    	call   *0xabd42(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3ac9e:	e9 90 00 00 00       	jmp    3ad33 <oriole_expat::dispatch+0x6f23>
   3aca3:	80 7c 24 40 00       	cmpb   $0x0,0x40(%rsp)
   3aca8:	0f 84 4c 01 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3acae:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   3acb5:	00 
   3acb6:	e8 75 46 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3acbb:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   3acc2:	00 
   3acc3:	48 85 c9             	test   %rcx,%rcx
   3acc6:	0f 85 16 01 00 00    	jne    3ade2 <oriole_expat::dispatch+0x6fd2>
   3accc:	e9 29 01 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3acd1:	80 7c 24 08 00       	cmpb   $0x0,0x8(%rsp)
   3acd6:	0f 84 1e 01 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3acdc:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3ace3:	00 
   3ace4:	e8 b7 59 ff ff       	call   306a0 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::ExternalEntityReference, oriole_storage::allocator::Allocator>>>
   3ace9:	e9 0c 01 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3acee:	80 7c 24 04 00       	cmpb   $0x0,0x4(%rsp)
   3acf3:	0f 84 01 01 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3acf9:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3ad00:	00 
   3ad01:	e8 0a 59 ff ff       	call   30610 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::DoctypeDeclaration, oriole_storage::allocator::Allocator>>>
   3ad06:	e9 ef 00 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3ad0b:	80 7c 24 28 00       	cmpb   $0x0,0x28(%rsp)
   3ad10:	0f 84 e4 00 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3ad16:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3ad1d:	00 
   3ad1e:	e8 0d 46 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3ad23:	49 89 ef             	mov    %rbp,%r15
   3ad26:	eb 0b                	jmp    3ad33 <oriole_expat::dispatch+0x6f23>
   3ad28:	80 7c 24 50 00       	cmpb   $0x0,0x50(%rsp)
   3ad2d:	0f 84 c7 00 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3ad33:	4c 89 ff             	mov    %r15,%rdi
   3ad36:	e8 f5 45 ff ff       	call   2f330 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3ad3b:	e9 ba 00 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3ad40:	80 7c 24 0c 00       	cmpb   $0x0,0xc(%rsp)
   3ad45:	0f 84 af 00 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3ad4b:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3ad52:	00 
   3ad53:	e8 88 58 ff ff       	call   305e0 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::EntityDeclaration, oriole_storage::allocator::Allocator>>>
   3ad58:	e9 9d 00 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3ad5d:	80 7c 24 24 00       	cmpb   $0x0,0x24(%rsp)
   3ad62:	0f 84 92 00 00 00    	je     3adfa <oriole_expat::dispatch+0x6fea>
   3ad68:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3ad6f:	00 
   3ad70:	e8 fb 58 ff ff       	call   30670 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::AttributeDeclaration, oriole_storage::allocator::Allocator>>>
   3ad75:	e9 80 00 00 00       	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3ad7a:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
   3ad7f:	74 79                	je     3adfa <oriole_expat::dispatch+0x6fea>
   3ad81:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3ad88:	00 
   3ad89:	e8 b2 58 ff ff       	call   30640 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::NotationDeclaration, oriole_storage::allocator::Allocator>>>
   3ad8e:	eb 6a                	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3ad90:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
   3ad95:	74 63                	je     3adfa <oriole_expat::dispatch+0x6fea>
   3ad97:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   3ad9e:	00 
   3ad9f:	48 85 c9             	test   %rcx,%rcx
   3ada2:	74 1b                	je     3adbf <oriole_expat::dispatch+0x6faf>
   3ada4:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
   3adab:	00 
   3adac:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   3adb3:	00 
   3adb4:	ba 01 00 00 00       	mov    $0x1,%edx
   3adb9:	ff 15 21 bc 0a 00    	call   *0xabc21(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3adbf:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   3adc6:	00 
   3adc7:	48 85 c9             	test   %rcx,%rcx
   3adca:	75 1c                	jne    3ade8 <oriole_expat::dispatch+0x6fd8>
   3adcc:	eb 2c                	jmp    3adfa <oriole_expat::dispatch+0x6fea>
   3adce:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   3add5:	00 
   3add6:	48 85 c9             	test   %rcx,%rcx
   3add9:	0f 95 c0             	setne  %al
   3addc:	84 44 24 1c          	test   %al,0x1c(%rsp)
   3ade0:	74 18                	je     3adfa <oriole_expat::dispatch+0x6fea>
   3ade2:	4c 89 fd             	mov    %r15,%rbp
   3ade5:	4d 89 ec             	mov    %r13,%r12
   3ade8:	49 8b 34 24          	mov    (%r12),%rsi
   3adec:	ba 01 00 00 00       	mov    $0x1,%edx
   3adf1:	48 89 ef             	mov    %rbp,%rdi
   3adf4:	ff 15 e6 bb 0a 00    	call   *0xabbe6(%rip)        # e69e0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3adfa:	48 89 df             	mov    %rbx,%rdi
   3adfd:	e8 8e 1d ff ff       	call   2cb90 <_Unwind_Resume@plt>
   3ae02:	ff 15 20 c2 0a 00    	call   *0xac220(%rip)        # e7028 <_GLOBAL_OFFSET_TABLE_+0x780>
