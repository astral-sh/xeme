
/tmp/oriole-event-dispatch/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000032600 <oriole_expat::run_events>:
   32600:	55                   	push   %rbp
   32601:	41 57                	push   %r15
   32603:	41 56                	push   %r14
   32605:	41 55                	push   %r13
   32607:	41 54                	push   %r12
   32609:	53                   	push   %rbx
   3260a:	48 81 ec 98 01 00 00 	sub    $0x198,%rsp
   32611:	48 89 fb             	mov    %rdi,%rbx
   32614:	e8 e7 0a 00 00       	call   33100 <oriole_expat::drain_default_fragments>
   32619:	31 c0                	xor    %eax,%eax
   3261b:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   32622:	0f 85 19 04 00 00    	jne    32a41 <oriole_expat::run_events+0x441>
   32628:	4c 8d 73 30          	lea    0x30(%rbx),%r14
   3262c:	4c 8d bc 24 10 01 00 	lea    0x110(%rsp),%r15
   32633:	00 
   32634:	48 8d 83 20 0a 00 00 	lea    0xa20(%rbx),%rax
   3263b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   32640:	4c 8d ac 24 00 01 00 	lea    0x100(%rsp),%r13
   32647:	00 
   32648:	eb 67                	jmp    326b1 <oriole_expat::run_events+0xb1>
   3264a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   32650:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   32655:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
   32659:	0f 84 e4 00 00 00    	je     32743 <oriole_expat::run_events+0x143>
   3265f:	4c 8b a3 a8 06 00 00 	mov    0x6a8(%rbx),%r12
   32666:	ba 90 00 00 00       	mov    $0x90,%edx
   3266b:	48 8d bc 24 08 01 00 	lea    0x108(%rsp),%rdi
   32672:	00 
   32673:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
   32678:	ff 15 4a 4c 0b 00    	call   *0xb4c4a(%rip)        # e72c8 <memcpy@GLIBC_2.14>
   3267e:	48 89 ac 24 00 01 00 	mov    %rbp,0x100(%rsp)
   32685:	00 
   32686:	48 89 df             	mov    %rbx,%rdi
   32689:	4c 89 ee             	mov    %r13,%rsi
   3268c:	4c 89 e2             	mov    %r12,%rdx
   3268f:	e8 7c 17 00 00       	call   33e10 <oriole_expat::dispatch>
   32694:	3c ff                	cmp    $0xff,%al
   32696:	0f 85 d5 01 00 00    	jne    32871 <oriole_expat::run_events+0x271>
   3269c:	48 89 df             	mov    %rbx,%rdi
   3269f:	e8 5c 0a 00 00       	call   33100 <oriole_expat::drain_default_fragments>
   326a4:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   326ab:	0f 85 a5 01 00 00    	jne    32856 <oriole_expat::run_events+0x256>
   326b1:	8b 83 14 0a 00 00    	mov    0xa14(%rbx),%eax
   326b7:	85 c0                	test   %eax,%eax
   326b9:	0f 85 91 01 00 00    	jne    32850 <oriole_expat::run_events+0x250>
   326bf:	83 bb 0c 0a 00 00 03 	cmpl   $0x3,0xa0c(%rbx)
   326c6:	0f 84 91 01 00 00    	je     3285d <oriole_expat::run_events+0x25d>
   326cc:	48 c7 44 24 68 ff ff 	movq   $0xffffffffffffffff,0x68(%rsp)
   326d3:	ff ff 
   326d5:	4c 89 ef             	mov    %r13,%rdi
   326d8:	4c 89 f6             	mov    %r14,%rsi
   326db:	48 8d 54 24 68       	lea    0x68(%rsp),%rdx
   326e0:	ff 15 62 42 0b 00    	call   *0xb4262(%rip)        # e6948 <_GLOBAL_OFFSET_TABLE_+0xa0>
   326e6:	44 0f b6 a4 24 30 01 	movzbl 0x130(%rsp),%r12d
   326ed:	00 00 
   326ef:	49 81 fc ff 00 00 00 	cmp    $0xff,%r12
   326f6:	0f 84 54 ff ff ff    	je     32650 <oriole_expat::run_events+0x50>
   326fc:	41 0f 10 07          	movups (%r15),%xmm0
   32700:	41 0f 10 4f 10       	movups 0x10(%r15),%xmm1
   32705:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
   3270a:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   3270f:	41 83 fc 11          	cmp    $0x11,%r12d
   32713:	0f 85 e7 00 00 00    	jne    32800 <oriole_expat::run_events+0x200>
   32719:	48 89 df             	mov    %rbx,%rdi
   3271c:	e8 af 0b 00 00       	call   332d0 <oriole_expat::resolve_unknown_encoding>
   32721:	84 c0                	test   %al,%al
   32723:	0f 84 d7 00 00 00    	je     32800 <oriole_expat::run_events+0x200>
   32729:	83 7c 24 68 ff       	cmpl   $0xffffffff,0x68(%rsp)
   3272e:	0f 84 68 ff ff ff    	je     3269c <oriole_expat::run_events+0x9c>
   32734:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   32739:	e8 82 e6 ff ff       	call   30dc0 <core::ptr::drop_glue::<oriole::Event>>
   3273e:	e9 59 ff ff ff       	jmp    3269c <oriole_expat::run_events+0x9c>
   32743:	4c 89 ef             	mov    %r13,%rdi
   32746:	4c 89 f6             	mov    %r14,%rsi
   32749:	ff 15 29 42 0b 00    	call   *0xb4229(%rip)        # e6978 <_GLOBAL_OFFSET_TABLE_+0xd0>
   3274f:	83 bc 24 00 01 00 00 	cmpl   $0x1,0x100(%rsp)
   32756:	01 
   32757:	0f 85 27 01 00 00    	jne    32884 <oriole_expat::run_events+0x284>
   3275d:	48 8d 8c 24 08 01 00 	lea    0x108(%rsp),%rcx
   32764:	00 
   32765:	48 8b 41 20          	mov    0x20(%rcx),%rax
   32769:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   3276e:	0f 10 01             	movups (%rcx),%xmm0
   32771:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   32775:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   3277a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   3277f:	48 8b 83 80 0b 00 00 	mov    0xb80(%rbx),%rax
   32786:	48 85 c0             	test   %rax,%rax
   32789:	0f 84 00 01 00 00    	je     3288f <oriole_expat::run_events+0x28f>
   3278f:	48 8b bb 88 0b 00 00 	mov    0xb88(%rbx),%rdi
   32796:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   3279b:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
   327a0:	48 8d 8b 20 0a 00 00 	lea    0xa20(%rbx),%rcx
   327a7:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
   327ab:	0f 11 01             	movups %xmm0,(%rcx)
   327ae:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   327b3:	ff d0                	call   *%rax
   327b5:	8b 8b 14 0a 00 00    	mov    0xa14(%rbx),%ecx
   327bb:	85 c9                	test   %ecx,%ecx
   327bd:	0f 85 13 02 00 00    	jne    329d6 <oriole_expat::run_events+0x3d6>
   327c3:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   327ca:	0f 85 da 00 00 00    	jne    328aa <oriole_expat::run_events+0x2aa>
   327d0:	4c 89 ef             	mov    %r13,%rdi
   327d3:	4c 89 f6             	mov    %r14,%rsi
   327d6:	89 c2                	mov    %eax,%edx
   327d8:	ff 15 d2 41 0b 00    	call   *0xb41d2(%rip)        # e69b0 <_GLOBAL_OFFSET_TABLE_+0x108>
   327de:	0f b6 84 24 30 01 00 	movzbl 0x130(%rsp),%eax
   327e5:	00 
   327e6:	48 8d 0d a3 6c fd ff 	lea    -0x2935d(%rip),%rcx        # 9490 <std::thread::current::id::ID+0x9420>
   327ed:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   327f1:	48 01 c8             	add    %rcx,%rax
   327f4:	ff e0                	jmp    *%rax
   327f6:	b9 01 00 00 00       	mov    $0x1,%ecx
   327fb:	e9 ac 01 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   32800:	31 c0                	xor    %eax,%eax
   32802:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   32809:	0f 85 1c 02 00 00    	jne    32a2b <oriole_expat::run_events+0x42b>
   3280f:	83 bb 14 0a 00 00 00 	cmpl   $0x0,0xa14(%rbx)
   32816:	0f 85 0f 02 00 00    	jne    32a2b <oriole_expat::run_events+0x42b>
   3281c:	48 8d 05 c1 78 fd ff 	lea    -0x2873f(%rip),%rax        # a0e4 <std::thread::current::id::ID+0xa074>
   32823:	42 8b 04 a0          	mov    (%rax,%r12,4),%eax
   32827:	89 83 14 0a 00 00    	mov    %eax,0xa14(%rbx)
   3282d:	89 83 10 0a 00 00    	mov    %eax,0xa10(%rbx)
   32833:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   32838:	0f 28 4c 24 50       	movaps 0x50(%rsp),%xmm1
   3283d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   32842:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   32846:	0f 11 00             	movups %xmm0,(%rax)
   32849:	31 c0                	xor    %eax,%eax
   3284b:	e9 db 01 00 00       	jmp    32a2b <oriole_expat::run_events+0x42b>
   32850:	89 83 10 0a 00 00    	mov    %eax,0xa10(%rbx)
   32856:	31 c0                	xor    %eax,%eax
   32858:	e9 e4 01 00 00       	jmp    32a41 <oriole_expat::run_events+0x441>
   3285d:	c7 83 10 0a 00 00 00 	movl   $0x0,0xa10(%rbx)
   32864:	00 00 00 
   32867:	b8 02 00 00 00       	mov    $0x2,%eax
   3286c:	e9 d0 01 00 00       	jmp    32a41 <oriole_expat::run_events+0x441>
   32871:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
   32878:	00 00 00 
   3287b:	48 89 83 10 0a 00 00 	mov    %rax,0xa10(%rbx)
   32882:	eb d2                	jmp    32856 <oriole_expat::run_events+0x256>
   32884:	8b 8b 14 0a 00 00    	mov    0xa14(%rbx),%ecx
   3288a:	e9 47 01 00 00       	jmp    329d6 <oriole_expat::run_events+0x3d6>
   3288f:	48 b8 12 00 00 00 12 	movabs $0x1200000012,%rax
   32896:	00 00 00 
   32899:	48 89 83 10 0a 00 00 	mov    %rax,0xa10(%rbx)
   328a0:	b9 12 00 00 00       	mov    $0x12,%ecx
   328a5:	e9 2c 01 00 00       	jmp    329d6 <oriole_expat::run_events+0x3d6>
   328aa:	31 c9                	xor    %ecx,%ecx
   328ac:	e9 25 01 00 00       	jmp    329d6 <oriole_expat::run_events+0x3d6>
   328b1:	b9 28 00 00 00       	mov    $0x28,%ecx
   328b6:	e9 f1 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   328bb:	b9 26 00 00 00       	mov    $0x26,%ecx
   328c0:	e9 e7 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   328c5:	b9 2b 00 00 00       	mov    $0x2b,%ecx
   328ca:	e9 dd 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   328cf:	b9 27 00 00 00       	mov    $0x27,%ecx
   328d4:	e9 d3 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   328d9:	b9 10 00 00 00       	mov    $0x10,%ecx
   328de:	e9 c9 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   328e3:	b9 0b 00 00 00       	mov    $0xb,%ecx
   328e8:	e9 bf 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   328ed:	b9 20 00 00 00       	mov    $0x20,%ecx
   328f2:	e9 b5 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   328f7:	b9 11 00 00 00       	mov    $0x11,%ecx
   328fc:	e9 ab 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   32901:	b9 13 00 00 00       	mov    $0x13,%ecx
   32906:	e9 a1 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   3290b:	b9 18 00 00 00       	mov    $0x18,%ecx
   32910:	e9 97 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   32915:	b9 09 00 00 00       	mov    $0x9,%ecx
   3291a:	e9 8d 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   3291f:	b9 0a 00 00 00       	mov    $0xa,%ecx
   32924:	e9 83 00 00 00       	jmp    329ac <oriole_expat::run_events+0x3ac>
   32929:	b9 0d 00 00 00       	mov    $0xd,%ecx
   3292e:	eb 7c                	jmp    329ac <oriole_expat::run_events+0x3ac>
   32930:	b9 08 00 00 00       	mov    $0x8,%ecx
   32935:	eb 75                	jmp    329ac <oriole_expat::run_events+0x3ac>
   32937:	b9 1e 00 00 00       	mov    $0x1e,%ecx
   3293c:	eb 6e                	jmp    329ac <oriole_expat::run_events+0x3ac>
   3293e:	b9 15 00 00 00       	mov    $0x15,%ecx
   32943:	eb 67                	jmp    329ac <oriole_expat::run_events+0x3ac>
   32945:	b9 05 00 00 00       	mov    $0x5,%ecx
   3294a:	eb 60                	jmp    329ac <oriole_expat::run_events+0x3ac>
   3294c:	b9 0c 00 00 00       	mov    $0xc,%ecx
   32951:	eb 59                	jmp    329ac <oriole_expat::run_events+0x3ac>
   32953:	b9 04 00 00 00       	mov    $0x4,%ecx
   32958:	eb 52                	jmp    329ac <oriole_expat::run_events+0x3ac>
   3295a:	b9 02 00 00 00       	mov    $0x2,%ecx
   3295f:	eb 4b                	jmp    329ac <oriole_expat::run_events+0x3ac>
   32961:	b9 12 00 00 00       	mov    $0x12,%ecx
   32966:	eb 44                	jmp    329ac <oriole_expat::run_events+0x3ac>
   32968:	b9 03 00 00 00       	mov    $0x3,%ecx
   3296d:	eb 3d                	jmp    329ac <oriole_expat::run_events+0x3ac>
   3296f:	b9 1c 00 00 00       	mov    $0x1c,%ecx
   32974:	eb 36                	jmp    329ac <oriole_expat::run_events+0x3ac>
   32976:	b9 07 00 00 00       	mov    $0x7,%ecx
   3297b:	eb 2f                	jmp    329ac <oriole_expat::run_events+0x3ac>
   3297d:	b9 1d 00 00 00       	mov    $0x1d,%ecx
   32982:	eb 28                	jmp    329ac <oriole_expat::run_events+0x3ac>
   32984:	b9 14 00 00 00       	mov    $0x14,%ecx
   32989:	eb 21                	jmp    329ac <oriole_expat::run_events+0x3ac>
   3298b:	b9 1b 00 00 00       	mov    $0x1b,%ecx
   32990:	eb 1a                	jmp    329ac <oriole_expat::run_events+0x3ac>
   32992:	b9 06 00 00 00       	mov    $0x6,%ecx
   32997:	eb 13                	jmp    329ac <oriole_expat::run_events+0x3ac>
   32999:	b9 0e 00 00 00       	mov    $0xe,%ecx
   3299e:	eb 0c                	jmp    329ac <oriole_expat::run_events+0x3ac>
   329a0:	b9 0f 00 00 00       	mov    $0xf,%ecx
   329a5:	eb 05                	jmp    329ac <oriole_expat::run_events+0x3ac>
   329a7:	b9 24 00 00 00       	mov    $0x24,%ecx
   329ac:	89 8b 14 0a 00 00    	mov    %ecx,0xa14(%rbx)
   329b2:	89 8b 10 0a 00 00    	mov    %ecx,0xa10(%rbx)
   329b8:	0f 10 84 24 10 01 00 	movups 0x110(%rsp),%xmm0
   329bf:	00 
   329c0:	0f 10 8c 24 20 01 00 	movups 0x120(%rsp),%xmm1
   329c7:	00 
   329c8:	48 8d 83 20 0a 00 00 	lea    0xa20(%rbx),%rax
   329cf:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   329d3:	0f 11 00             	movups %xmm0,(%rax)
   329d6:	31 c0                	xor    %eax,%eax
   329d8:	85 c9                	test   %ecx,%ecx
   329da:	75 4f                	jne    32a2b <oriole_expat::run_events+0x42b>
   329dc:	0f 10 83 c0 08 00 00 	movups 0x8c0(%rbx),%xmm0
   329e3:	0f 10 8b d0 08 00 00 	movups 0x8d0(%rbx),%xmm1
   329ea:	48 8d 83 20 0a 00 00 	lea    0xa20(%rbx),%rax
   329f1:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   329f5:	0f 11 00             	movups %xmm0,(%rax)
   329f8:	80 bb e9 08 00 00 00 	cmpb   $0x0,0x8e9(%rbx)
   329ff:	74 1b                	je     32a1c <oriole_expat::run_events+0x41c>
   32a01:	48 89 df             	mov    %rbx,%rdi
   32a04:	e8 87 04 00 00       	call   32e90 <oriole_expat::merge_external_subset>
   32a09:	84 c0                	test   %al,%al
   32a0b:	b8 00 00 00 00       	mov    $0x0,%eax
   32a10:	74 19                	je     32a2b <oriole_expat::run_events+0x42b>
   32a12:	c7 83 0c 0a 00 00 02 	movl   $0x2,0xa0c(%rbx)
   32a19:	00 00 00 
   32a1c:	c7 83 10 0a 00 00 00 	movl   $0x0,0xa10(%rbx)
   32a23:	00 00 00 
   32a26:	b8 01 00 00 00       	mov    $0x1,%eax
   32a2b:	48 83 7c 24 68 ff    	cmpq   $0xffffffffffffffff,0x68(%rsp)
   32a31:	74 0e                	je     32a41 <oriole_expat::run_events+0x441>
   32a33:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   32a38:	89 c3                	mov    %eax,%ebx
   32a3a:	e8 81 e3 ff ff       	call   30dc0 <core::ptr::drop_glue::<oriole::Event>>
   32a3f:	89 d8                	mov    %ebx,%eax
   32a41:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
   32a48:	5b                   	pop    %rbx
   32a49:	41 5c                	pop    %r12
   32a4b:	41 5d                	pop    %r13
   32a4d:	41 5e                	pop    %r14
   32a4f:	41 5f                	pop    %r15
   32a51:	5d                   	pop    %rbp
   32a52:	c3                   	ret
   32a53:	0f 0b                	ud2
   32a55:	eb 00                	jmp    32a57 <oriole_expat::run_events+0x457>
   32a57:	48 89 c3             	mov    %rax,%rbx
   32a5a:	83 7c 24 68 ff       	cmpl   $0xffffffff,0x68(%rsp)
   32a5f:	74 0a                	je     32a6b <oriole_expat::run_events+0x46b>
   32a61:	48 8d 7c 24 68       	lea    0x68(%rsp),%rdi
   32a66:	e8 55 e3 ff ff       	call   30dc0 <core::ptr::drop_glue::<oriole::Event>>
   32a6b:	48 89 df             	mov    %rbx,%rdi
   32a6e:	e8 1d a1 ff ff       	call   2cb90 <_Unwind_Resume@plt>
   32a73:	ff 15 af 45 0b 00    	call   *0xb45af(%rip)        # e7028 <_GLOBAL_OFFSET_TABLE_+0x780>
