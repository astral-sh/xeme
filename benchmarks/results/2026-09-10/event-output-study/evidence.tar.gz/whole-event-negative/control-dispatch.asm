
/tmp/oriole-event-dispatch/control.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000033e70 <oriole_expat::dispatch>:
   33e70:	55                   	push   %rbp
   33e71:	41 57                	push   %r15
   33e73:	41 56                	push   %r14
   33e75:	41 55                	push   %r13
   33e77:	41 54                	push   %r12
   33e79:	53                   	push   %rbx
   33e7a:	48 81 ec 08 06 00 00 	sub    $0x608,%rsp
   33e81:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
   33e86:	48 8b 06             	mov    (%rsi),%rax
   33e89:	48 83 e8 03          	sub    $0x3,%rax
   33e8d:	b9 0d 00 00 00       	mov    $0xd,%ecx
   33e92:	48 0f 43 c8          	cmovae %rax,%rcx
   33e96:	49 89 fe             	mov    %rdi,%r14
   33e99:	48 83 f9 19          	cmp    $0x19,%rcx
   33e9d:	0f 92 c0             	setb   %al
   33ea0:	41 bd 00 80 40 01    	mov    $0x1408000,%r13d
   33ea6:	41 d3 ed             	shr    %cl,%r13d
   33ea9:	41 20 c5             	and    %al,%r13b
   33eac:	80 bf 08 0a 00 00 00 	cmpb   $0x0,0xa08(%rdi)
   33eb3:	48 89 f8             	mov    %rdi,%rax
   33eb6:	75 03                	jne    33ebb <oriole_expat::dispatch+0x4b>
   33eb8:	49 8b 06             	mov    (%r14),%rax
   33ebb:	45 84 ed             	test   %r13b,%r13b
   33ebe:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   33ec3:	74 16                	je     33edb <oriole_expat::dispatch+0x6b>
   33ec5:	41 83 be 48 0a 00 00 	cmpl   $0xffffffff,0xa48(%r14)
   33ecc:	ff 
   33ecd:	74 0c                	je     33edb <oriole_expat::dispatch+0x6b>
   33ecf:	4d 8b be 78 0a 00 00 	mov    0xa78(%r14),%r15
   33ed6:	49 ff cf             	dec    %r15
   33ed9:	eb 03                	jmp    33ede <oriole_expat::dispatch+0x6e>
   33edb:	45 31 ff             	xor    %r15d,%r15d
   33ede:	49 8b be 50 09 00 00 	mov    0x950(%r14),%rdi
   33ee5:	49 8b 86 58 09 00 00 	mov    0x958(%r14),%rax
   33eec:	48 89 84 24 50 05 00 	mov    %rax,0x550(%rsp)
   33ef3:	00 
   33ef4:	49 8b 86 60 09 00 00 	mov    0x960(%r14),%rax
   33efb:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
   33f02:	00 
   33f03:	4d 8b 86 68 09 00 00 	mov    0x968(%r14),%r8
   33f0a:	49 8b 86 70 09 00 00 	mov    0x970(%r14),%rax
   33f11:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
   33f18:	00 
   33f19:	49 8b 86 78 09 00 00 	mov    0x978(%r14),%rax
   33f20:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
   33f27:	00 
   33f28:	49 8b 86 80 09 00 00 	mov    0x980(%r14),%rax
   33f2f:	48 89 84 24 20 05 00 	mov    %rax,0x520(%rsp)
   33f36:	00 
   33f37:	4d 8b 9e 88 09 00 00 	mov    0x988(%r14),%r11
   33f3e:	49 8b 86 90 09 00 00 	mov    0x990(%r14),%rax
   33f45:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
   33f4c:	00 
   33f4d:	49 8b b6 98 09 00 00 	mov    0x998(%r14),%rsi
   33f54:	49 8b ae a0 09 00 00 	mov    0x9a0(%r14),%rbp
   33f5b:	49 8b 9e a8 09 00 00 	mov    0x9a8(%r14),%rbx
   33f62:	4d 8b 8e b0 09 00 00 	mov    0x9b0(%r14),%r9
   33f69:	48 8d 05 20 5d fd ff 	lea    -0x2a2e0(%rip),%rax        # 9c90 <std::thread::current::id::ID+0x9c20>
   33f70:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
   33f74:	48 01 c1             	add    %rax,%rcx
   33f77:	4d 8b 96 b8 09 00 00 	mov    0x9b8(%r14),%r10
   33f7e:	4d 8b a6 c8 09 00 00 	mov    0x9c8(%r14),%r12
   33f85:	49 8b 86 d0 09 00 00 	mov    0x9d0(%r14),%rax
   33f8c:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
   33f93:	00 
   33f94:	49 8b 86 d8 09 00 00 	mov    0x9d8(%r14),%rax
   33f9b:	48 89 84 24 10 05 00 	mov    %rax,0x510(%rsp)
   33fa2:	00 
   33fa3:	49 8b 86 e0 09 00 00 	mov    0x9e0(%r14),%rax
   33faa:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
   33fb1:	00 
   33fb2:	49 8b 86 e8 09 00 00 	mov    0x9e8(%r14),%rax
   33fb9:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
   33fc0:	00 
   33fc1:	49 8b 86 f0 09 00 00 	mov    0x9f0(%r14),%rax
   33fc8:	48 89 84 24 30 05 00 	mov    %rax,0x530(%rsp)
   33fcf:	00 
   33fd0:	48 89 94 24 08 05 00 	mov    %rdx,0x508(%rsp)
   33fd7:	00 
   33fd8:	48 89 b4 24 40 05 00 	mov    %rsi,0x540(%rsp)
   33fdf:	00 
   33fe0:	ff e1                	jmp    *%rcx
   33fe2:	49 8b 96 50 05 00 00 	mov    0x550(%r14),%rdx
   33fe9:	e9 8d 03 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   33fee:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   33ff3:	48 8b 50 38          	mov    0x38(%rax),%rdx
   33ff7:	e9 7f 03 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   33ffc:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   34001:	48 8b 40 28          	mov    0x28(%rax),%rax
   34005:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34009:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   3400d:	0f 84 8f 02 00 00    	je     342a2 <oriole_expat::dispatch+0x432>
   34013:	48 8b 50 68          	mov    0x68(%rax),%rdx
   34017:	48 01 ca             	add    %rcx,%rdx
   3401a:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   3401e:	0f 85 89 02 00 00    	jne    342ad <oriole_expat::dispatch+0x43d>
   34024:	e9 93 02 00 00       	jmp    342bc <oriole_expat::dispatch+0x44c>
   34029:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3402e:	48 8b 50 70          	mov    0x70(%rax),%rdx
   34032:	48 03 50 38          	add    0x38(%rax),%rdx
   34036:	e9 40 03 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   3403b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   34040:	48 8b 40 28          	mov    0x28(%rax),%rax
   34044:	48 8b 50 68          	mov    0x68(%rax),%rdx
   34048:	48 03 50 30          	add    0x30(%rax),%rdx
   3404c:	48 03 90 a0 00 00 00 	add    0xa0(%rax),%rdx
   34053:	83 b8 a8 00 00 00 ff 	cmpl   $0xffffffff,0xa8(%rax)
   3405a:	0f 84 5c 02 00 00    	je     342bc <oriole_expat::dispatch+0x44c>
   34060:	48 8b 80 d8 00 00 00 	mov    0xd8(%rax),%rax
   34067:	48 01 c2             	add    %rax,%rdx
   3406a:	e9 0c 03 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   3406f:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   34074:	48 8b 40 28          	mov    0x28(%rax),%rax
   34078:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3407c:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   34080:	0f 84 c8 01 00 00    	je     3424e <oriole_expat::dispatch+0x3de>
   34086:	48 8b 50 68          	mov    0x68(%rax),%rdx
   3408a:	e9 c1 01 00 00       	jmp    34250 <oriole_expat::dispatch+0x3e0>
   3408f:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   34094:	48 8b 40 28          	mov    0x28(%rax),%rax
   34098:	83 38 ff             	cmpl   $0xffffffff,(%rax)
   3409b:	0f 84 f5 01 00 00    	je     34296 <oriole_expat::dispatch+0x426>
   340a1:	48 8b 48 30          	mov    0x30(%rax),%rcx
   340a5:	e9 ee 01 00 00       	jmp    34298 <oriole_expat::dispatch+0x428>
   340aa:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   340af:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   340b3:	0f 84 8a 01 00 00    	je     34243 <oriole_expat::dispatch+0x3d3>
   340b9:	48 8b 50 68          	mov    0x68(%rax),%rdx
   340bd:	48 03 50 30          	add    0x30(%rax),%rdx
   340c1:	e9 b5 02 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   340c6:	48 89 9c 24 b0 01 00 	mov    %rbx,0x1b0(%rsp)
   340cd:	00 
   340ce:	4c 89 db             	mov    %r11,%rbx
   340d1:	48 89 bc 24 d8 02 00 	mov    %rdi,0x2d8(%rsp)
   340d8:	00 
   340d9:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   340de:	48 8b 41 38          	mov    0x38(%rcx),%rax
   340e2:	48 8b 79 70          	mov    0x70(%rcx),%rdi
   340e6:	4d 89 c3             	mov    %r8,%r11
   340e9:	48 85 ff             	test   %rdi,%rdi
   340ec:	0f 84 d4 01 00 00    	je     342c6 <oriole_expat::dispatch+0x456>
   340f2:	48 8b 49 60          	mov    0x60(%rcx),%rcx
   340f6:	89 fe                	mov    %edi,%esi
   340f8:	83 e6 03             	and    $0x3,%esi
   340fb:	48 83 ff 04          	cmp    $0x4,%rdi
   340ff:	0f 83 c8 01 00 00    	jae    342cd <oriole_expat::dispatch+0x45d>
   34105:	45 31 c0             	xor    %r8d,%r8d
   34108:	31 d2                	xor    %edx,%edx
   3410a:	e9 29 02 00 00       	jmp    34338 <oriole_expat::dispatch+0x4c8>
   3410f:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   34114:	8b 48 40             	mov    0x40(%rax),%ecx
   34117:	31 d2                	xor    %edx,%edx
   34119:	83 78 08 ff          	cmpl   $0xffffffff,0x8(%rax)
   3411d:	b8 00 00 00 00       	mov    $0x0,%eax
   34122:	74 09                	je     3412d <oriole_expat::dispatch+0x2bd>
   34124:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   34129:	48 8b 40 38          	mov    0x38(%rax),%rax
   3412d:	83 f9 ff             	cmp    $0xffffffff,%ecx
   34130:	74 09                	je     3413b <oriole_expat::dispatch+0x2cb>
   34132:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   34137:	48 8b 51 70          	mov    0x70(%rcx),%rdx
   3413b:	48 01 c2             	add    %rax,%rdx
   3413e:	e9 38 02 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   34143:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   34148:	83 78 40 ff          	cmpl   $0xffffffff,0x40(%rax)
   3414c:	0f 85 dc fe ff ff    	jne    3402e <oriole_expat::dispatch+0x1be>
   34152:	31 d2                	xor    %edx,%edx
   34154:	e9 d9 fe ff ff       	jmp    34032 <oriole_expat::dispatch+0x1c2>
   34159:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3415e:	83 78 08 ff          	cmpl   $0xffffffff,0x8(%rax)
   34162:	74 09                	je     3416d <oriole_expat::dispatch+0x2fd>
   34164:	48 8b 50 38          	mov    0x38(%rax),%rdx
   34168:	e9 0e 02 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   3416d:	31 d2                	xor    %edx,%edx
   3416f:	e9 07 02 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   34174:	48 89 9c 24 b0 01 00 	mov    %rbx,0x1b0(%rsp)
   3417b:	00 
   3417c:	4c 89 84 24 10 04 00 	mov    %r8,0x410(%rsp)
   34183:	00 
   34184:	48 89 ac 24 08 04 00 	mov    %rbp,0x408(%rsp)
   3418b:	00 
   3418c:	4c 89 db             	mov    %r11,%rbx
   3418f:	4c 89 e5             	mov    %r12,%rbp
   34192:	4d 89 cc             	mov    %r9,%r12
   34195:	48 89 bc 24 d8 02 00 	mov    %rdi,0x2d8(%rsp)
   3419c:	00 
   3419d:	4c 89 94 24 00 04 00 	mov    %r10,0x400(%rsp)
   341a4:	00 
   341a5:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   341aa:	48 8d 78 08          	lea    0x8(%rax),%rdi
   341ae:	b0 01                	mov    $0x1,%al
   341b0:	89 44 24 50          	mov    %eax,0x50(%rsp)
   341b4:	b0 01                	mov    $0x1,%al
   341b6:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   341ba:	b0 01                	mov    $0x1,%al
   341bc:	89 44 24 40          	mov    %eax,0x40(%rsp)
   341c0:	b0 01                	mov    $0x1,%al
   341c2:	89 44 24 38          	mov    %eax,0x38(%rsp)
   341c6:	b0 01                	mov    $0x1,%al
   341c8:	89 44 24 48          	mov    %eax,0x48(%rsp)
   341cc:	b0 01                	mov    $0x1,%al
   341ce:	89 44 24 14          	mov    %eax,0x14(%rsp)
   341d2:	b0 01                	mov    $0x1,%al
   341d4:	89 44 24 30          	mov    %eax,0x30(%rsp)
   341d8:	b0 01                	mov    $0x1,%al
   341da:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   341de:	b0 01                	mov    $0x1,%al
   341e0:	89 44 24 08          	mov    %eax,0x8(%rsp)
   341e4:	b0 01                	mov    $0x1,%al
   341e6:	89 44 24 28          	mov    %eax,0x28(%rsp)
   341ea:	b0 01                	mov    $0x1,%al
   341ec:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   341f1:	b0 01                	mov    $0x1,%al
   341f3:	89 44 24 10          	mov    %eax,0x10(%rsp)
   341f7:	b0 01                	mov    $0x1,%al
   341f9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   341fd:	b0 01                	mov    $0x1,%al
   341ff:	89 44 24 18          	mov    %eax,0x18(%rsp)
   34203:	b0 01                	mov    $0x1,%al
   34205:	89 44 24 20          	mov    %eax,0x20(%rsp)
   34209:	b0 01                	mov    $0x1,%al
   3420b:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3420f:	ff 15 a3 27 0b 00    	call   *0xb27a3(%rip)        # e69b8 <_GLOBAL_OFFSET_TABLE_+0x240>
   34215:	4c 8b 94 24 00 04 00 	mov    0x400(%rsp),%r10
   3421c:	00 
   3421d:	48 8b bc 24 d8 02 00 	mov    0x2d8(%rsp),%rdi
   34224:	00 
   34225:	4d 89 e1             	mov    %r12,%r9
   34228:	49 89 ec             	mov    %rbp,%r12
   3422b:	49 89 db             	mov    %rbx,%r11
   3422e:	48 8b ac 24 08 04 00 	mov    0x408(%rsp),%rbp
   34235:	00 
   34236:	4c 8b 84 24 10 04 00 	mov    0x410(%rsp),%r8
   3423d:	00 
   3423e:	e9 30 01 00 00       	jmp    34373 <oriole_expat::dispatch+0x503>
   34243:	31 d2                	xor    %edx,%edx
   34245:	48 03 50 30          	add    0x30(%rax),%rdx
   34249:	e9 2d 01 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   3424e:	31 d2                	xor    %edx,%edx
   34250:	48 01 ca             	add    %rcx,%rdx
   34253:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   34257:	74 09                	je     34262 <oriole_expat::dispatch+0x3f2>
   34259:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
   34260:	eb 02                	jmp    34264 <oriole_expat::dispatch+0x3f4>
   34262:	31 c9                	xor    %ecx,%ecx
   34264:	48 01 ca             	add    %rcx,%rdx
   34267:	83 b8 a8 00 00 00 ff 	cmpl   $0xffffffff,0xa8(%rax)
   3426e:	74 09                	je     34279 <oriole_expat::dispatch+0x409>
   34270:	48 8b 88 d8 00 00 00 	mov    0xd8(%rax),%rcx
   34277:	eb 02                	jmp    3427b <oriole_expat::dispatch+0x40b>
   34279:	31 c9                	xor    %ecx,%ecx
   3427b:	48 01 ca             	add    %rcx,%rdx
   3427e:	83 b8 e0 00 00 00 ff 	cmpl   $0xffffffff,0xe0(%rax)
   34285:	74 35                	je     342bc <oriole_expat::dispatch+0x44c>
   34287:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
   3428e:	48 01 c2             	add    %rax,%rdx
   34291:	e9 e5 00 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   34296:	31 c9                	xor    %ecx,%ecx
   34298:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   3429c:	0f 85 71 fd ff ff    	jne    34013 <oriole_expat::dispatch+0x1a3>
   342a2:	31 d2                	xor    %edx,%edx
   342a4:	48 01 ca             	add    %rcx,%rdx
   342a7:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   342ab:	74 0f                	je     342bc <oriole_expat::dispatch+0x44c>
   342ad:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
   342b4:	48 01 c2             	add    %rax,%rdx
   342b7:	e9 bf 00 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   342bc:	31 c0                	xor    %eax,%eax
   342be:	48 01 c2             	add    %rax,%rdx
   342c1:	e9 b5 00 00 00       	jmp    3437b <oriole_expat::dispatch+0x50b>
   342c6:	31 d2                	xor    %edx,%edx
   342c8:	e9 95 00 00 00       	jmp    34362 <oriole_expat::dispatch+0x4f2>
   342cd:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
   342d2:	48 83 e7 fc          	and    $0xfffffffffffffffc,%rdi
   342d6:	4c 8d 89 d0 01 00 00 	lea    0x1d0(%rcx),%r9
   342dd:	45 31 c0             	xor    %r8d,%r8d
   342e0:	31 d2                	xor    %edx,%edx
   342e2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   342e9:	1f 84 00 00 00 00 00 
   342f0:	49 03 91 60 fe ff ff 	add    -0x1a0(%r9),%rdx
   342f7:	49 03 91 98 fe ff ff 	add    -0x168(%r9),%rdx
   342fe:	49 03 91 d8 fe ff ff 	add    -0x128(%r9),%rdx
   34305:	49 03 91 10 ff ff ff 	add    -0xf0(%r9),%rdx
   3430c:	49 03 91 50 ff ff ff 	add    -0xb0(%r9),%rdx
   34313:	49 03 51 88          	add    -0x78(%r9),%rdx
   34317:	49 03 51 c8          	add    -0x38(%r9),%rdx
   3431b:	49 03 11             	add    (%r9),%rdx
   3431e:	49 83 c0 04          	add    $0x4,%r8
   34322:	49 81 c1 e0 01 00 00 	add    $0x1e0,%r9
   34329:	4c 39 c7             	cmp    %r8,%rdi
   3432c:	75 c2                	jne    342f0 <oriole_expat::dispatch+0x480>
   3432e:	48 85 f6             	test   %rsi,%rsi
   34331:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
   34336:	74 2a                	je     34362 <oriole_expat::dispatch+0x4f2>
   34338:	49 6b f8 78          	imul   $0x78,%r8,%rdi
   3433c:	48 01 f9             	add    %rdi,%rcx
   3433f:	48 83 c1 68          	add    $0x68,%rcx
   34343:	48 6b f6 78          	imul   $0x78,%rsi,%rsi
   34347:	31 ff                	xor    %edi,%edi
   34349:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   34350:	48 03 54 39 c8       	add    -0x38(%rcx,%rdi,1),%rdx
   34355:	48 03 14 39          	add    (%rcx,%rdi,1),%rdx
   34359:	48 83 c7 78          	add    $0x78,%rdi
   3435d:	48 39 fe             	cmp    %rdi,%rsi
   34360:	75 ee                	jne    34350 <oriole_expat::dispatch+0x4e0>
   34362:	48 01 c2             	add    %rax,%rdx
   34365:	48 8b bc 24 d8 02 00 	mov    0x2d8(%rsp),%rdi
   3436c:	00 
   3436d:	4d 89 d8             	mov    %r11,%r8
   34370:	49 89 db             	mov    %rbx,%r11
   34373:	48 8b 9c 24 b0 01 00 	mov    0x1b0(%rsp),%rbx
   3437a:	00 
   3437b:	4c 01 fa             	add    %r15,%rdx
   3437e:	49 8b 8e 68 0b 00 00 	mov    0xb68(%r14),%rcx
   34385:	48 8b 41 30          	mov    0x30(%rcx),%rax
   34389:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   34390:	48 8d 34 02          	lea    (%rdx,%rax,1),%rsi
   34394:	48 39 c6             	cmp    %rax,%rsi
   34397:	0f 82 6c 01 00 00    	jb     34509 <oriole_expat::dispatch+0x699>
   3439d:	48 81 fe 00 00 00 04 	cmp    $0x4000000,%rsi
   343a4:	0f 87 5f 01 00 00    	ja     34509 <oriole_expat::dispatch+0x699>
   343aa:	f0 48 0f b1 71 30    	lock cmpxchg %rsi,0x30(%rcx)
   343b0:	75 de                	jne    34390 <oriole_expat::dispatch+0x520>
   343b2:	45 84 ed             	test   %r13b,%r13b
   343b5:	0f 84 9f 01 00 00    	je     3455a <oriole_expat::dispatch+0x6ea>
   343bb:	41 83 be 48 0a 00 00 	cmpl   $0xffffffff,0xa48(%r14)
   343c2:	ff 
   343c3:	0f 84 9f 01 00 00    	je     34568 <oriole_expat::dispatch+0x6f8>
   343c9:	48 89 9c 24 b0 01 00 	mov    %rbx,0x1b0(%rsp)
   343d0:	00 
   343d1:	4c 89 c3             	mov    %r8,%rbx
   343d4:	48 89 ac 24 08 04 00 	mov    %rbp,0x408(%rsp)
   343db:	00 
   343dc:	4c 89 9c 24 d8 02 00 	mov    %r11,0x2d8(%rsp)
   343e3:	00 
   343e4:	4c 89 e5             	mov    %r12,%rbp
   343e7:	4d 89 cc             	mov    %r9,%r12
   343ea:	49 89 fd             	mov    %rdi,%r13
   343ed:	4d 89 d7             	mov    %r10,%r15
   343f0:	49 8d b6 48 0a 00 00 	lea    0xa48(%r14),%rsi
   343f7:	b0 01                	mov    $0x1,%al
   343f9:	89 44 24 50          	mov    %eax,0x50(%rsp)
   343fd:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   34404:	00 
   34405:	b0 01                	mov    $0x1,%al
   34407:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3440b:	b0 01                	mov    $0x1,%al
   3440d:	89 44 24 40          	mov    %eax,0x40(%rsp)
   34411:	b0 01                	mov    $0x1,%al
   34413:	89 44 24 38          	mov    %eax,0x38(%rsp)
   34417:	b0 01                	mov    $0x1,%al
   34419:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3441d:	b0 01                	mov    $0x1,%al
   3441f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   34423:	b0 01                	mov    $0x1,%al
   34425:	89 44 24 30          	mov    %eax,0x30(%rsp)
   34429:	b0 01                	mov    $0x1,%al
   3442b:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3442f:	b0 01                	mov    $0x1,%al
   34431:	89 44 24 08          	mov    %eax,0x8(%rsp)
   34435:	b0 01                	mov    $0x1,%al
   34437:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3443b:	b0 01                	mov    $0x1,%al
   3443d:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   34442:	b0 01                	mov    $0x1,%al
   34444:	89 44 24 10          	mov    %eax,0x10(%rsp)
   34448:	b0 01                	mov    $0x1,%al
   3444a:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3444e:	b0 01                	mov    $0x1,%al
   34450:	89 44 24 18          	mov    %eax,0x18(%rsp)
   34454:	b0 01                	mov    $0x1,%al
   34456:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3445a:	b0 01                	mov    $0x1,%al
   3445c:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   34460:	ff 15 2a 25 0b 00    	call   *0xb252a(%rip)        # e6990 <_GLOBAL_OFFSET_TABLE_+0x218>
   34466:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   3446d:	00 
   3446e:	0f b6 8c 24 e8 02 00 	movzbl 0x2e8(%rsp),%ecx
   34475:	00 
   34476:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   3447d:	00 
   3447e:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
   34485:	00 
   34486:	0f 10 84 24 f9 02 00 	movups 0x2f9(%rsp),%xmm0
   3448d:	00 
   3448e:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
   34495:	00 
   34496:	0f 10 84 24 08 03 00 	movups 0x308(%rsp),%xmm0
   3449d:	00 
   3449e:	0f 11 84 24 df 01 00 	movups %xmm0,0x1df(%rsp)
   344a5:	00 
   344a6:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   344aa:	0f 84 cd 01 00 00    	je     3467d <oriole_expat::dispatch+0x80d>
   344b0:	4d 89 fa             	mov    %r15,%r10
   344b3:	4d 89 e1             	mov    %r12,%r9
   344b6:	49 89 d8             	mov    %rbx,%r8
   344b9:	0f 10 84 24 df 01 00 	movups 0x1df(%rsp),%xmm0
   344c0:	00 
   344c1:	0f 11 84 24 cf 00 00 	movups %xmm0,0xcf(%rsp)
   344c8:	00 
   344c9:	0f 28 84 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm0
   344d0:	00 
   344d1:	0f 28 8c 24 d0 01 00 	movaps 0x1d0(%rsp),%xmm1
   344d8:	00 
   344d9:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
   344e0:	00 
   344e1:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   344e8:	00 
   344e9:	4c 89 ef             	mov    %r13,%rdi
   344ec:	49 89 ec             	mov    %rbp,%r12
   344ef:	4c 8b 9c 24 d8 02 00 	mov    0x2d8(%rsp),%r11
   344f6:	00 
   344f7:	48 8b ac 24 08 04 00 	mov    0x408(%rsp),%rbp
   344fe:	00 
   344ff:	48 8b 9c 24 b0 01 00 	mov    0x1b0(%rsp),%rbx
   34506:	00 
   34507:	eb 66                	jmp    3456f <oriole_expat::dispatch+0x6ff>
   34509:	48 b8 2b 00 00 00 2b 	movabs $0x2b0000002b,%rax
   34510:	00 00 00 
   34513:	49 89 86 10 0a 00 00 	mov    %rax,0xa10(%r14)
   3451a:	41 b5 ff             	mov    $0xff,%r13b
   3451d:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   34522:	48 8b 08             	mov    (%rax),%rcx
   34525:	48 83 e9 03          	sub    $0x3,%rcx
   34529:	b8 0d 00 00 00       	mov    $0xd,%eax
   3452e:	48 0f 43 c1          	cmovae %rcx,%rax
   34532:	48 83 c0 fa          	add    $0xfffffffffffffffa,%rax
   34536:	48 83 f8 14          	cmp    $0x14,%rax
   3453a:	0f 87 86 46 00 00    	ja     38bc6 <oriole_expat::dispatch+0x4d56>
   34540:	48 8d 0d b5 57 fd ff 	lea    -0x2a84b(%rip),%rcx        # 9cfc <std::thread::current::id::ID+0x9c8c>
   34547:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   3454b:	48 01 c8             	add    %rcx,%rax
   3454e:	ff e0                	jmp    *%rax
   34550:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   34555:	e9 40 44 00 00       	jmp    3899a <oriole_expat::dispatch+0x4b2a>
   3455a:	48 c7 84 24 98 04 00 	movq   $0xffffffffffffffff,0x498(%rsp)
   34561:	00 ff ff ff ff 
   34566:	eb 46                	jmp    345ae <oriole_expat::dispatch+0x73e>
   34568:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   3456f:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
   34576:	00 
   34577:	0f 28 8c 24 c0 00 00 	movaps 0xc0(%rsp),%xmm1
   3457e:	00 
   3457f:	0f 11 84 24 a1 04 00 	movups %xmm0,0x4a1(%rsp)
   34586:	00 
   34587:	0f 11 8c 24 b1 04 00 	movups %xmm1,0x4b1(%rsp)
   3458e:	00 
   3458f:	0f 10 84 24 cf 00 00 	movups 0xcf(%rsp),%xmm0
   34596:	00 
   34597:	0f 11 84 24 c0 04 00 	movups %xmm0,0x4c0(%rsp)
   3459e:	00 
   3459f:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
   345a6:	00 
   345a7:	88 8c 24 a0 04 00 00 	mov    %cl,0x4a0(%rsp)
   345ae:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   345b3:	48 8b 06             	mov    (%rsi),%rax
   345b6:	48 89 c2             	mov    %rax,%rdx
   345b9:	48 83 ea 03          	sub    $0x3,%rdx
   345bd:	b9 0d 00 00 00       	mov    $0xd,%ecx
   345c2:	48 0f 43 ca          	cmovae %rdx,%rcx
   345c6:	48 83 f9 1a          	cmp    $0x1a,%rcx
   345ca:	0f 92 84 24 08 04 00 	setb   0x408(%rsp)
   345d1:	00 
   345d2:	ba 3e 00 c7 03       	mov    $0x3c7003e,%edx
   345d7:	d3 ea                	shr    %cl,%edx
   345d9:	89 94 24 d8 02 00 00 	mov    %edx,0x2d8(%rsp)
   345e0:	48 83 f8 08          	cmp    $0x8,%rax
   345e4:	0f 95 84 24 2e 01 00 	setne  0x12e(%rsp)
   345eb:	00 
   345ec:	4d 85 c9             	test   %r9,%r9
   345ef:	0f 94 84 24 b0 01 00 	sete   0x1b0(%rsp)
   345f6:	00 
   345f7:	48 8d 46 08          	lea    0x8(%rsi),%rax
   345fb:	0f b6 56 08          	movzbl 0x8(%rsi),%edx
   345ff:	88 94 24 10 04 00 00 	mov    %dl,0x410(%rsp)
   34606:	0f b6 56 09          	movzbl 0x9(%rsi),%edx
   3460a:	88 94 24 2f 01 00 00 	mov    %dl,0x12f(%rsp)
   34611:	48 8d 15 38 57 fd ff 	lea    -0x2a8c8(%rip),%rdx        # 9d50 <std::thread::current::id::ID+0x9ce0>
   34618:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   3461c:	48 01 d1             	add    %rdx,%rcx
   3461f:	b2 01                	mov    $0x1,%dl
   34621:	89 54 24 2c          	mov    %edx,0x2c(%rsp)
   34625:	b2 01                	mov    $0x1,%dl
   34627:	89 54 24 40          	mov    %edx,0x40(%rsp)
   3462b:	b2 01                	mov    $0x1,%dl
   3462d:	89 54 24 50          	mov    %edx,0x50(%rsp)
   34631:	b2 01                	mov    $0x1,%dl
   34633:	89 54 24 38          	mov    %edx,0x38(%rsp)
   34637:	b2 01                	mov    $0x1,%dl
   34639:	89 54 24 48          	mov    %edx,0x48(%rsp)
   3463d:	b2 01                	mov    $0x1,%dl
   3463f:	89 54 24 14          	mov    %edx,0x14(%rsp)
   34643:	b2 01                	mov    $0x1,%dl
   34645:	89 54 24 30          	mov    %edx,0x30(%rsp)
   34649:	b2 01                	mov    $0x1,%dl
   3464b:	89 54 24 0c          	mov    %edx,0xc(%rsp)
   3464f:	b2 01                	mov    $0x1,%dl
   34651:	89 54 24 08          	mov    %edx,0x8(%rsp)
   34655:	b2 01                	mov    $0x1,%dl
   34657:	89 54 24 10          	mov    %edx,0x10(%rsp)
   3465b:	b2 01                	mov    $0x1,%dl
   3465d:	89 54 24 24          	mov    %edx,0x24(%rsp)
   34661:	b2 01                	mov    $0x1,%dl
   34663:	89 54 24 18          	mov    %edx,0x18(%rsp)
   34667:	b2 01                	mov    $0x1,%dl
   34669:	89 54 24 20          	mov    %edx,0x20(%rsp)
   3466d:	b2 01                	mov    $0x1,%dl
   3466f:	89 54 24 1c          	mov    %edx,0x1c(%rsp)
   34673:	ff e1                	jmp    *%rcx
   34675:	4d 85 c9             	test   %r9,%r9
   34678:	e9 0b 10 00 00       	jmp    35688 <oriole_expat::dispatch+0x1818>
   3467d:	41 89 cd             	mov    %ecx,%r13d
   34680:	e9 98 fe ff ff       	jmp    3451d <oriole_expat::dispatch+0x6ad>
   34685:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34689:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
   34690:	00 
   34691:	0f 10 00             	movups (%rax),%xmm0
   34694:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34698:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   3469c:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   346a3:	00 
   346a4:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   346ab:	00 
   346ac:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   346b1:	48 8b 9c 24 58 05 00 	mov    0x558(%rsp),%rbx
   346b8:	00 
   346b9:	48 85 db             	test   %rbx,%rbx
   346bc:	0f 84 9e 21 00 00    	je     36860 <oriole_expat::dispatch+0x29f0>
   346c2:	48 8b 48 30          	mov    0x30(%rax),%rcx
   346c6:	48 89 8c 24 10 03 00 	mov    %rcx,0x310(%rsp)
   346cd:	00 
   346ce:	0f 10 00             	movups (%rax),%xmm0
   346d1:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   346d5:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   346d9:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   346e0:	00 
   346e1:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   346e8:	00 
   346e9:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   346f0:	00 
   346f1:	b0 01                	mov    $0x1,%al
   346f3:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   346f7:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   346fe:	00 
   346ff:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   34706:	00 
   34707:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   3470e:	00 
   3470f:	b0 01                	mov    $0x1,%al
   34711:	89 44 24 40          	mov    %eax,0x40(%rsp)
   34715:	b0 01                	mov    $0x1,%al
   34717:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3471b:	b0 01                	mov    $0x1,%al
   3471d:	89 44 24 48          	mov    %eax,0x48(%rsp)
   34721:	b0 01                	mov    $0x1,%al
   34723:	89 44 24 14          	mov    %eax,0x14(%rsp)
   34727:	b0 01                	mov    $0x1,%al
   34729:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3472d:	b0 01                	mov    $0x1,%al
   3472f:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   34733:	b0 01                	mov    $0x1,%al
   34735:	89 44 24 08          	mov    %eax,0x8(%rsp)
   34739:	b0 01                	mov    $0x1,%al
   3473b:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3473f:	b0 01                	mov    $0x1,%al
   34741:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   34746:	b0 01                	mov    $0x1,%al
   34748:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3474c:	40 b5 01             	mov    $0x1,%bpl
   3474f:	41 b7 01             	mov    $0x1,%r15b
   34752:	41 b4 01             	mov    $0x1,%r12b
   34755:	41 b5 01             	mov    $0x1,%r13b
   34758:	ff 15 22 22 0b 00    	call   *0xb2222(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   3475e:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   34765:	00 
   34766:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   3476d:	00 00 
   3476f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   34773:	0f 84 51 31 00 00    	je     378ca <oriole_expat::dispatch+0x3a5a>
   34779:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   34780:	00 
   34781:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   34788:	00 
   34789:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   34790:	00 
   34791:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   34798:	00 
   34799:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   347a0:	00 
   347a1:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   347a8:	00 
   347a9:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   347b0:	00 
   347b1:	44 88 ac 24 b8 00 00 	mov    %r13b,0xb8(%rsp)
   347b8:	00 
   347b9:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   347c0:	00 
   347c1:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   347c6:	ff d3                	call   *%rbx
   347c8:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   347cf:	00 
   347d0:	48 85 c9             	test   %rcx,%rcx
   347d3:	74 6c                	je     34841 <oriole_expat::dispatch+0x9d1>
   347d5:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   347dc:	00 
   347dd:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   347e4:	00 
   347e5:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   347ec:	00 
   347ed:	ba 01 00 00 00       	mov    $0x1,%edx
   347f2:	b0 01                	mov    $0x1,%al
   347f4:	89 44 24 40          	mov    %eax,0x40(%rsp)
   347f8:	b0 01                	mov    $0x1,%al
   347fa:	89 44 24 50          	mov    %eax,0x50(%rsp)
   347fe:	b0 01                	mov    $0x1,%al
   34800:	89 44 24 48          	mov    %eax,0x48(%rsp)
   34804:	b0 01                	mov    $0x1,%al
   34806:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3480a:	b0 01                	mov    $0x1,%al
   3480c:	89 44 24 30          	mov    %eax,0x30(%rsp)
   34810:	b0 01                	mov    $0x1,%al
   34812:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   34816:	b0 01                	mov    $0x1,%al
   34818:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3481c:	b0 01                	mov    $0x1,%al
   3481e:	89 44 24 28          	mov    %eax,0x28(%rsp)
   34822:	b0 01                	mov    $0x1,%al
   34824:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   34829:	b0 01                	mov    $0x1,%al
   3482b:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3482f:	40 b5 01             	mov    $0x1,%bpl
   34832:	41 b7 01             	mov    $0x1,%r15b
   34835:	41 b4 01             	mov    $0x1,%r12b
   34838:	41 b5 01             	mov    $0x1,%r13b
   3483b:	ff 15 6f 20 0b 00    	call   *0xb206f(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   34841:	b3 01                	mov    $0x1,%bl
   34843:	e9 56 38 00 00       	jmp    3809e <oriole_expat::dispatch+0x422e>
   34848:	b0 01                	mov    $0x1,%al
   3484a:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3484e:	b0 01                	mov    $0x1,%al
   34850:	89 44 24 40          	mov    %eax,0x40(%rsp)
   34854:	b0 01                	mov    $0x1,%al
   34856:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3485a:	b0 01                	mov    $0x1,%al
   3485c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   34860:	b0 01                	mov    $0x1,%al
   34862:	89 44 24 48          	mov    %eax,0x48(%rsp)
   34866:	b0 01                	mov    $0x1,%al
   34868:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3486c:	b0 01                	mov    $0x1,%al
   3486e:	89 44 24 30          	mov    %eax,0x30(%rsp)
   34872:	b0 01                	mov    $0x1,%al
   34874:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   34878:	b0 01                	mov    $0x1,%al
   3487a:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3487e:	b0 01                	mov    $0x1,%al
   34880:	89 44 24 10          	mov    %eax,0x10(%rsp)
   34884:	b0 01                	mov    $0x1,%al
   34886:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3488a:	b0 01                	mov    $0x1,%al
   3488c:	89 44 24 18          	mov    %eax,0x18(%rsp)
   34890:	b0 01                	mov    $0x1,%al
   34892:	89 44 24 20          	mov    %eax,0x20(%rsp)
   34896:	b0 01                	mov    $0x1,%al
   34898:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3489c:	48 83 bc 24 20 05 00 	cmpq   $0x0,0x520(%rsp)
   348a3:	00 00 
   348a5:	0f 84 40 0e 00 00    	je     356eb <oriole_expat::dispatch+0x187b>
   348ab:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   348b0:	ff 94 24 20 05 00 00 	call   *0x520(%rsp)
   348b7:	e9 5e 10 00 00       	jmp    3591a <oriole_expat::dispatch+0x1aaa>
   348bc:	48 8b 48 30          	mov    0x30(%rax),%rcx
   348c0:	48 89 8c 24 f0 01 00 	mov    %rcx,0x1f0(%rsp)
   348c7:	00 
   348c8:	0f 10 00             	movups (%rax),%xmm0
   348cb:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   348cf:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   348d3:	0f 29 94 24 e0 01 00 	movaps %xmm2,0x1e0(%rsp)
   348da:	00 
   348db:	0f 29 8c 24 d0 01 00 	movaps %xmm1,0x1d0(%rsp)
   348e2:	00 
   348e3:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
   348ea:	00 
   348eb:	4c 8b bc 24 50 05 00 	mov    0x550(%rsp),%r15
   348f2:	00 
   348f3:	4d 85 ff             	test   %r15,%r15
   348f6:	0f 84 eb 1f 00 00    	je     368e7 <oriole_expat::dispatch+0x2a77>
   348fc:	48 8b b4 24 e0 01 00 	mov    0x1e0(%rsp),%rsi
   34903:	00 
   34904:	48 8b 94 24 f0 01 00 	mov    0x1f0(%rsp),%rdx
   3490b:	00 
   3490c:	31 ff                	xor    %edi,%edi
   3490e:	e8 cd 7f 00 00       	call   3c8e0 <core::slice::memchr::memchr>
   34913:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   34918:	b1 03                	mov    $0x3,%cl
   3491a:	48 83 f8 01          	cmp    $0x1,%rax
   3491e:	74 1a                	je     3493a <oriole_expat::dispatch+0xaca>
   34920:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   34927:	00 
   34928:	31 f6                	xor    %esi,%esi
   3492a:	ff 15 d0 1f 0b 00    	call   *0xb1fd0(%rip)        # e6900 <_GLOBAL_OFFSET_TABLE_+0x188>
   34930:	89 c1                	mov    %eax,%ecx
   34932:	3c ff                	cmp    $0xff,%al
   34934:	0f 84 52 38 00 00    	je     3818c <oriole_expat::dispatch+0x431c>
   3493a:	89 cb                	mov    %ecx,%ebx
   3493c:	48 8b 8c 24 e8 01 00 	mov    0x1e8(%rsp),%rcx
   34943:	00 
   34944:	48 85 c9             	test   %rcx,%rcx
   34947:	74 72                	je     349bb <oriole_expat::dispatch+0xb4b>
   34949:	b0 01                	mov    $0x1,%al
   3494b:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3494f:	48 8b b4 24 e0 01 00 	mov    0x1e0(%rsp),%rsi
   34956:	00 
   34957:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   3495e:	00 
   3495f:	ba 01 00 00 00       	mov    $0x1,%edx
   34964:	b0 01                	mov    $0x1,%al
   34966:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3496a:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   34971:	00 
   34972:	b0 01                	mov    $0x1,%al
   34974:	89 44 24 38          	mov    %eax,0x38(%rsp)
   34978:	b0 01                	mov    $0x1,%al
   3497a:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3497e:	b0 01                	mov    $0x1,%al
   34980:	89 44 24 14          	mov    %eax,0x14(%rsp)
   34984:	b0 01                	mov    $0x1,%al
   34986:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3498a:	b0 01                	mov    $0x1,%al
   3498c:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   34990:	b0 01                	mov    $0x1,%al
   34992:	89 44 24 08          	mov    %eax,0x8(%rsp)
   34996:	b0 01                	mov    $0x1,%al
   34998:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3499c:	b0 01                	mov    $0x1,%al
   3499e:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   349a3:	b0 01                	mov    $0x1,%al
   349a5:	89 44 24 10          	mov    %eax,0x10(%rsp)
   349a9:	40 b5 01             	mov    $0x1,%bpl
   349ac:	41 b7 01             	mov    $0x1,%r15b
   349af:	41 b4 01             	mov    $0x1,%r12b
   349b2:	41 b5 01             	mov    $0x1,%r13b
   349b5:	ff 15 f5 1e 0b 00    	call   *0xb1ef5(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   349bb:	b0 01                	mov    $0x1,%al
   349bd:	89 44 24 50          	mov    %eax,0x50(%rsp)
   349c1:	b0 01                	mov    $0x1,%al
   349c3:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   349c7:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   349ce:	00 
   349cf:	e9 56 4d 00 00       	jmp    3972a <oriole_expat::dispatch+0x58ba>
   349d4:	48 8b 48 30          	mov    0x30(%rax),%rcx
   349d8:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
   349df:	00 
   349e0:	0f 10 00             	movups (%rax),%xmm0
   349e3:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   349e7:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   349eb:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
   349f2:	00 
   349f3:	0f 29 8c 24 00 01 00 	movaps %xmm1,0x100(%rsp)
   349fa:	00 
   349fb:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   34a02:	00 
   34a03:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   34a08:	48 8b 4a 70          	mov    0x70(%rdx),%rcx
   34a0c:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
   34a13:	00 
   34a14:	0f 10 42 40          	movups 0x40(%rdx),%xmm0
   34a18:	0f 10 4a 50          	movups 0x50(%rdx),%xmm1
   34a1c:	0f 10 52 60          	movups 0x60(%rdx),%xmm2
   34a20:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   34a27:	00 
   34a28:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   34a2f:	00 
   34a30:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   34a35:	48 8b 9c 24 30 05 00 	mov    0x530(%rsp),%rbx
   34a3c:	00 
   34a3d:	48 85 db             	test   %rbx,%rbx
   34a40:	0f 84 a8 1e 00 00    	je     368ee <oriole_expat::dispatch+0x2a7e>
   34a46:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34a4a:	48 89 8c 24 10 03 00 	mov    %rcx,0x310(%rsp)
   34a51:	00 
   34a52:	0f 10 00             	movups (%rax),%xmm0
   34a55:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34a59:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   34a5d:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   34a64:	00 
   34a65:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   34a6c:	00 
   34a6d:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   34a74:	00 
   34a75:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   34a7c:	00 
   34a7d:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   34a84:	00 
   34a85:	ff 15 f5 1e 0b 00    	call   *0xb1ef5(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   34a8b:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   34a92:	00 
   34a93:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   34a9a:	00 00 
   34a9c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   34aa0:	0f 84 49 2e 00 00    	je     378ef <oriole_expat::dispatch+0x3a7f>
   34aa6:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   34aad:	00 
   34aae:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   34ab5:	00 
   34ab6:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   34abd:	00 
   34abe:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   34ac5:	00 
   34ac6:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   34acd:	00 
   34ace:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   34ad5:	00 
   34ad6:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   34add:	00 
   34ade:	44 88 ac 24 b8 00 00 	mov    %r13b,0xb8(%rsp)
   34ae5:	00 
   34ae6:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   34aed:	00 
   34aee:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
   34af5:	00 
   34af6:	41 0f 10 46 08       	movups 0x8(%r14),%xmm0
   34afb:	41 0f 10 4e 18       	movups 0x18(%r14),%xmm1
   34b00:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   34b07:	00 
   34b08:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   34b0f:	00 
   34b10:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   34b17:	00 
   34b18:	48 8d 8c 24 e0 02 00 	lea    0x2e0(%rsp),%rcx
   34b1f:	00 
   34b20:	e8 1b 77 00 00       	call   3c240 <oriole_expat::content_model::allocate>
   34b25:	83 bc 24 c0 01 00 00 	cmpl   $0x1,0x1c0(%rsp)
   34b2c:	01 
   34b2d:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   34b32:	0f 85 68 2f 00 00    	jne    37aa0 <oriole_expat::dispatch+0x3c30>
   34b38:	8b 84 24 c4 01 00 00 	mov    0x1c4(%rsp),%eax
   34b3f:	41 89 86 14 0a 00 00 	mov    %eax,0xa14(%r14)
   34b46:	41 89 86 10 0a 00 00 	mov    %eax,0xa10(%r14)
   34b4d:	e9 60 2f 00 00       	jmp    37ab2 <oriole_expat::dispatch+0x3c42>
   34b52:	0f 10 00             	movups (%rax),%xmm0
   34b55:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34b59:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
   34b60:	00 
   34b61:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   34b68:	00 
   34b69:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   34b6e:	4c 8b 78 28          	mov    0x28(%rax),%r15
   34b72:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   34b79:	00 
   34b7a:	ba a8 00 00 00       	mov    $0xa8,%edx
   34b7f:	4c 89 fe             	mov    %r15,%rsi
   34b82:	ff 15 10 26 0b 00    	call   *0xb2610(%rip)        # e7198 <memcpy@GLIBC_2.14>
   34b88:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   34b8f:	00 
   34b90:	ba 08 00 00 00       	mov    $0x8,%edx
   34b95:	b9 a8 00 00 00       	mov    $0xa8,%ecx
   34b9a:	4c 89 fe             	mov    %r15,%rsi
   34b9d:	ff 15 0d 1d 0b 00    	call   *0xb1d0d(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   34ba3:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   34baa:	00 
   34bab:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   34bb2:	00 
   34bb3:	ba a8 00 00 00       	mov    $0xa8,%edx
   34bb8:	ff 15 da 25 0b 00    	call   *0xb25da(%rip)        # e7198 <memcpy@GLIBC_2.14>
   34bbe:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
   34bc5:	00 
   34bc6:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   34bcd:	00 
   34bce:	0f 10 84 24 c0 01 00 	movups 0x1c0(%rsp),%xmm0
   34bd5:	00 
   34bd6:	0f 10 8c 24 d0 01 00 	movups 0x1d0(%rsp),%xmm1
   34bdd:	00 
   34bde:	0f 10 94 24 e0 01 00 	movups 0x1e0(%rsp),%xmm2
   34be5:	00 
   34be6:	0f 29 94 24 50 01 00 	movaps %xmm2,0x150(%rsp)
   34bed:	00 
   34bee:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
   34bf5:	00 
   34bf6:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
   34bfd:	00 
   34bfe:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
   34c05:	00 
   34c06:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
   34c0d:	00 
   34c0e:	0f 10 84 24 18 02 00 	movups 0x218(%rsp),%xmm0
   34c15:	00 
   34c16:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
   34c1d:	00 
   34c1e:	0f 10 84 24 08 02 00 	movups 0x208(%rsp),%xmm0
   34c25:	00 
   34c26:	0f 29 84 24 80 01 00 	movaps %xmm0,0x180(%rsp)
   34c2d:	00 
   34c2e:	0f 10 84 24 f8 01 00 	movups 0x1f8(%rsp),%xmm0
   34c35:	00 
   34c36:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
   34c3d:	00 
   34c3e:	48 8b 84 24 60 02 00 	mov    0x260(%rsp),%rax
   34c45:	00 
   34c46:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
   34c4d:	00 
   34c4e:	0f 10 84 24 30 02 00 	movups 0x230(%rsp),%xmm0
   34c55:	00 
   34c56:	0f 10 8c 24 40 02 00 	movups 0x240(%rsp),%xmm1
   34c5d:	00 
   34c5e:	0f 10 94 24 50 02 00 	movups 0x250(%rsp),%xmm2
   34c65:	00 
   34c66:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
   34c6d:	00 
   34c6e:	0f 29 8c 24 00 01 00 	movaps %xmm1,0x100(%rsp)
   34c75:	00 
   34c76:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   34c7d:	00 
   34c7e:	48 8b ac 24 10 05 00 	mov    0x510(%rsp),%rbp
   34c85:	00 
   34c86:	48 85 ed             	test   %rbp,%rbp
   34c89:	0f 84 8e 21 00 00    	je     36e1d <oriole_expat::dispatch+0x2fad>
   34c8f:	4d 8b be 08 0b 00 00 	mov    0xb08(%r14),%r15
   34c96:	4d 85 ff             	test   %r15,%r15
   34c99:	4d 0f 44 fe          	cmove  %r14,%r15
   34c9d:	b3 01                	mov    $0x1,%bl
   34c9f:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   34ca6:	00 
   34ca7:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
   34cae:	00 
   34caf:	e8 6c e1 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   34cb4:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   34cbb:	00 
   34cbc:	44 0f b6 ac 24 e8 02 	movzbl 0x2e8(%rsp),%r13d
   34cc3:	00 00 
   34cc5:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   34cc9:	0f 85 49 2b 00 00    	jne    37818 <oriole_expat::dispatch+0x39a8>
   34ccf:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   34cd6:	00 
   34cd7:	e8 64 a6 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   34cdc:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   34ce3:	00 
   34ce4:	e8 57 a6 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   34ce9:	e9 2d 3b 00 00       	jmp    3881b <oriole_expat::dispatch+0x49ab>
   34cee:	0f 10 00             	movups (%rax),%xmm0
   34cf1:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34cf5:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
   34cfc:	00 
   34cfd:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   34d04:	00 
   34d05:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   34d0a:	4c 8b 60 28          	mov    0x28(%rax),%r12
   34d0e:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   34d15:	00 
   34d16:	ba a8 00 00 00       	mov    $0xa8,%edx
   34d1b:	4c 89 e6             	mov    %r12,%rsi
   34d1e:	ff 15 74 24 0b 00    	call   *0xb2474(%rip)        # e7198 <memcpy@GLIBC_2.14>
   34d24:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   34d2b:	00 
   34d2c:	ba 08 00 00 00       	mov    $0x8,%edx
   34d31:	b9 a8 00 00 00       	mov    $0xa8,%ecx
   34d36:	4c 89 e6             	mov    %r12,%rsi
   34d39:	ff 15 71 1b 0b 00    	call   *0xb1b71(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   34d3f:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   34d46:	00 
   34d47:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   34d4e:	00 
   34d4f:	ba a8 00 00 00       	mov    $0xa8,%edx
   34d54:	ff 15 3e 24 0b 00    	call   *0xb243e(%rip)        # e7198 <memcpy@GLIBC_2.14>
   34d5a:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
   34d61:	00 
   34d62:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   34d69:	00 
   34d6a:	0f 10 84 24 c0 01 00 	movups 0x1c0(%rsp),%xmm0
   34d71:	00 
   34d72:	0f 10 8c 24 d0 01 00 	movups 0x1d0(%rsp),%xmm1
   34d79:	00 
   34d7a:	0f 10 94 24 e0 01 00 	movups 0x1e0(%rsp),%xmm2
   34d81:	00 
   34d82:	0f 29 94 24 50 01 00 	movaps %xmm2,0x150(%rsp)
   34d89:	00 
   34d8a:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
   34d91:	00 
   34d92:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
   34d99:	00 
   34d9a:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
   34da1:	00 
   34da2:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
   34da9:	00 
   34daa:	0f 10 84 24 18 02 00 	movups 0x218(%rsp),%xmm0
   34db1:	00 
   34db2:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
   34db9:	00 
   34dba:	0f 10 84 24 08 02 00 	movups 0x208(%rsp),%xmm0
   34dc1:	00 
   34dc2:	0f 29 84 24 80 01 00 	movaps %xmm0,0x180(%rsp)
   34dc9:	00 
   34dca:	0f 10 84 24 f8 01 00 	movups 0x1f8(%rsp),%xmm0
   34dd1:	00 
   34dd2:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
   34dd9:	00 
   34dda:	48 8b 84 24 60 02 00 	mov    0x260(%rsp),%rax
   34de1:	00 
   34de2:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
   34de9:	00 
   34dea:	0f 10 84 24 30 02 00 	movups 0x230(%rsp),%xmm0
   34df1:	00 
   34df2:	0f 10 8c 24 40 02 00 	movups 0x240(%rsp),%xmm1
   34df9:	00 
   34dfa:	0f 10 94 24 50 02 00 	movups 0x250(%rsp),%xmm2
   34e01:	00 
   34e02:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
   34e09:	00 
   34e0a:	0f 29 8c 24 00 01 00 	movaps %xmm1,0x100(%rsp)
   34e11:	00 
   34e12:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   34e19:	00 
   34e1a:	48 83 bc 24 b8 01 00 	cmpq   $0x0,0x1b8(%rsp)
   34e21:	00 00 
   34e23:	0f 84 b3 20 00 00    	je     36edc <oriole_expat::dispatch+0x306c>
   34e29:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
   34e30:	00 
   34e31:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   34e38:	00 
   34e39:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
   34e40:	00 
   34e41:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
   34e48:	00 
   34e49:	0f 28 94 24 50 01 00 	movaps 0x150(%rsp),%xmm2
   34e50:	00 
   34e51:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   34e58:	00 
   34e59:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   34e60:	00 
   34e61:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   34e68:	00 
   34e69:	b3 01                	mov    $0x1,%bl
   34e6b:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   34e72:	00 
   34e73:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   34e7a:	00 
   34e7b:	ff 15 ff 1a 0b 00    	call   *0xb1aff(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   34e81:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   34e88:	00 
   34e89:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   34e90:	00 00 
   34e92:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   34e96:	0f 84 a8 2b 00 00    	je     37a44 <oriole_expat::dispatch+0x3bd4>
   34e9c:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   34ea3:	00 
   34ea4:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   34eab:	00 
   34eac:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   34eb3:	00 
   34eb4:	0f 11 94 24 98 00 00 	movups %xmm2,0x98(%rsp)
   34ebb:	00 
   34ebc:	0f 11 8c 24 89 00 00 	movups %xmm1,0x89(%rsp)
   34ec3:	00 
   34ec4:	0f 11 44 24 79       	movups %xmm0,0x79(%rsp)
   34ec9:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   34ece:	44 88 6c 24 78       	mov    %r13b,0x78(%rsp)
   34ed3:	83 bc 24 98 04 00 00 	cmpl   $0xffffffff,0x498(%rsp)
   34eda:	ff 
   34edb:	0f 84 25 2c 00 00    	je     37b06 <oriole_expat::dispatch+0x3c96>
   34ee1:	48 8b 9c 24 b8 04 00 	mov    0x4b8(%rsp),%rbx
   34ee8:	00 
   34ee9:	e9 1a 2c 00 00       	jmp    37b08 <oriole_expat::dispatch+0x3c98>
   34eee:	48 83 bc 24 b8 01 00 	cmpq   $0x0,0x1b8(%rsp)
   34ef5:	00 00 
   34ef7:	e9 8c 07 00 00       	jmp    35688 <oriole_expat::dispatch+0x1818>
   34efc:	48 89 fd             	mov    %rdi,%rbp
   34eff:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34f03:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
   34f0a:	00 
   34f0b:	0f 10 00             	movups (%rax),%xmm0
   34f0e:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34f12:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   34f16:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   34f1d:	00 
   34f1e:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   34f25:	00 
   34f26:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   34f2b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   34f30:	0f 10 40 40          	movups 0x40(%rax),%xmm0
   34f34:	0f 10 48 50          	movups 0x50(%rax),%xmm1
   34f38:	0f 10 50 60          	movups 0x60(%rax),%xmm2
   34f3c:	0f 29 94 24 d0 00 00 	movaps %xmm2,0xd0(%rsp)
   34f43:	00 
   34f44:	4c 8b 78 70          	mov    0x70(%rax),%r15
   34f48:	4c 89 bc 24 e0 00 00 	mov    %r15,0xe0(%rsp)
   34f4f:	00 
   34f50:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
   34f57:	00 
   34f58:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   34f5f:	00 
   34f60:	4c 8b ac 24 d0 00 00 	mov    0xd0(%rsp),%r13
   34f67:	00 
   34f68:	4d 85 ff             	test   %r15,%r15
   34f6b:	0f 84 2a 1a 00 00    	je     3699b <oriole_expat::dispatch+0x2b2b>
   34f71:	44 89 f9             	mov    %r15d,%ecx
   34f74:	83 e1 03             	and    $0x3,%ecx
   34f77:	49 83 ff 04          	cmp    $0x4,%r15
   34f7b:	0f 83 5f 25 00 00    	jae    374e0 <oriole_expat::dispatch+0x3670>
   34f81:	31 d2                	xor    %edx,%edx
   34f83:	31 c0                	xor    %eax,%eax
   34f85:	e9 a0 25 00 00       	jmp    3752a <oriole_expat::dispatch+0x36ba>
   34f8a:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34f8e:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
   34f95:	00 
   34f96:	0f 10 00             	movups (%rax),%xmm0
   34f99:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   34f9d:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   34fa1:	0f 29 94 24 90 01 00 	movaps %xmm2,0x190(%rsp)
   34fa8:	00 
   34fa9:	0f 29 8c 24 80 01 00 	movaps %xmm1,0x180(%rsp)
   34fb0:	00 
   34fb1:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
   34fb8:	00 
   34fb9:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   34fbe:	48 8b 4a 70          	mov    0x70(%rdx),%rcx
   34fc2:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
   34fc9:	00 
   34fca:	0f 10 42 40          	movups 0x40(%rdx),%xmm0
   34fce:	0f 10 4a 50          	movups 0x50(%rdx),%xmm1
   34fd2:	0f 10 52 60          	movups 0x60(%rdx),%xmm2
   34fd6:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
   34fdd:	00 
   34fde:	0f 29 8c 24 00 01 00 	movaps %xmm1,0x100(%rsp)
   34fe5:	00 
   34fe6:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   34fed:	00 
   34fee:	4d 85 c0             	test   %r8,%r8
   34ff1:	0f 84 ab 19 00 00    	je     369a2 <oriole_expat::dispatch+0x2b32>
   34ff7:	4c 89 c3             	mov    %r8,%rbx
   34ffa:	48 8b 48 30          	mov    0x30(%rax),%rcx
   34ffe:	48 89 8c 24 10 03 00 	mov    %rcx,0x310(%rsp)
   35005:	00 
   35006:	0f 10 00             	movups (%rax),%xmm0
   35009:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   3500d:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   35011:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   35018:	00 
   35019:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   35020:	00 
   35021:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   35028:	00 
   35029:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   35030:	00 
   35031:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   35038:	00 
   35039:	ff 15 41 19 0b 00    	call   *0xb1941(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   3503f:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   35046:	00 
   35047:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   3504e:	00 00 
   35050:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   35054:	0f 84 1c 29 00 00    	je     37976 <oriole_expat::dispatch+0x3b06>
   3505a:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   35061:	00 
   35062:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   35069:	00 
   3506a:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   35071:	00 
   35072:	0f 11 94 24 98 00 00 	movups %xmm2,0x98(%rsp)
   35079:	00 
   3507a:	0f 11 8c 24 89 00 00 	movups %xmm1,0x89(%rsp)
   35081:	00 
   35082:	0f 11 44 24 79       	movups %xmm0,0x79(%rsp)
   35087:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   3508c:	44 88 6c 24 78       	mov    %r13b,0x78(%rsp)
   35091:	4c 8b a4 24 90 00 00 	mov    0x90(%rsp),%r12
   35098:	00 
   35099:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
   350a0:	00 
   350a1:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   350a8:	00 
   350a9:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
   350b0:	00 
   350b1:	0f 28 8c 24 00 01 00 	movaps 0x100(%rsp),%xmm1
   350b8:	00 
   350b9:	0f 28 94 24 10 01 00 	movaps 0x110(%rsp),%xmm2
   350c0:	00 
   350c1:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   350c8:	00 
   350c9:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   350d0:	00 
   350d1:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   350d8:	00 
   350d9:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   350e0:	00 
   350e1:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   350e8:	00 
   350e9:	ff 15 91 18 0b 00    	call   *0xb1891(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   350ef:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   350f6:	00 
   350f7:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   350fe:	00 00 
   35100:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   35104:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   35109:	0f 84 06 2f 00 00    	je     38015 <oriole_expat::dispatch+0x41a5>
   3510f:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   35116:	00 
   35117:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   3511e:	00 
   3511f:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   35126:	00 
   35127:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   3512e:	00 
   3512f:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   35136:	00 
   35137:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   3513e:	00 
   3513f:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   35146:	00 
   35147:	44 88 ac 24 b8 00 00 	mov    %r13b,0xb8(%rsp)
   3514e:	00 
   3514f:	48 8b 94 24 d0 00 00 	mov    0xd0(%rsp),%rdx
   35156:	00 
   35157:	4c 89 e6             	mov    %r12,%rsi
   3515a:	ff d3                	call   *%rbx
   3515c:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   35163:	00 
   35164:	48 85 c9             	test   %rcx,%rcx
   35167:	74 1b                	je     35184 <oriole_expat::dispatch+0x1314>
   35169:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   35170:	00 
   35171:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   35178:	00 
   35179:	ba 01 00 00 00       	mov    $0x1,%edx
   3517e:	ff 15 2c 17 0b 00    	call   *0xb172c(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   35184:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   3518b:	00 
   3518c:	48 85 c9             	test   %rcx,%rcx
   3518f:	74 18                	je     351a9 <oriole_expat::dispatch+0x1339>
   35191:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   35198:	00 
   35199:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   3519e:	ba 01 00 00 00       	mov    $0x1,%edx
   351a3:	ff 15 07 17 0b 00    	call   *0xb1707(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   351a9:	b3 01                	mov    $0x1,%bl
   351ab:	e9 a5 2f 00 00       	jmp    38155 <oriole_expat::dispatch+0x42e5>
   351b0:	48 8b 48 30          	mov    0x30(%rax),%rcx
   351b4:	48 89 8c 24 10 03 00 	mov    %rcx,0x310(%rsp)
   351bb:	00 
   351bc:	0f 10 00             	movups (%rax),%xmm0
   351bf:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   351c3:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   351c7:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   351ce:	00 
   351cf:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   351d6:	00 
   351d7:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   351de:	00 
   351df:	48 8b 9c 24 48 05 00 	mov    0x548(%rsp),%rbx
   351e6:	00 
   351e7:	48 85 db             	test   %rbx,%rbx
   351ea:	0f 84 64 18 00 00    	je     36a54 <oriole_expat::dispatch+0x2be4>
   351f0:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   351f7:	00 
   351f8:	ff 15 ba 17 0b 00    	call   *0xb17ba(%rip)        # e69b8 <_GLOBAL_OFFSET_TABLE_+0x240>
   351fe:	49 89 c6             	mov    %rax,%r14
   35201:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   35208:	00 
   35209:	ff 15 a9 17 0b 00    	call   *0xb17a9(%rip)        # e69b8 <_GLOBAL_OFFSET_TABLE_+0x240>
   3520f:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   35214:	4c 89 f6             	mov    %r14,%rsi
   35217:	ff d3                	call   *%rbx
   35219:	b0 01                	mov    $0x1,%al
   3521b:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3521f:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
   35226:	00 
   35227:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3522e:	00 
   3522f:	b0 01                	mov    $0x1,%al
   35231:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   35235:	b0 01                	mov    $0x1,%al
   35237:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3523b:	b0 01                	mov    $0x1,%al
   3523d:	89 44 24 48          	mov    %eax,0x48(%rsp)
   35241:	b0 01                	mov    $0x1,%al
   35243:	89 44 24 14          	mov    %eax,0x14(%rsp)
   35247:	b0 01                	mov    $0x1,%al
   35249:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3524d:	b0 01                	mov    $0x1,%al
   3524f:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   35253:	b0 01                	mov    $0x1,%al
   35255:	89 44 24 08          	mov    %eax,0x8(%rsp)
   35259:	b0 01                	mov    $0x1,%al
   3525b:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3525f:	b0 01                	mov    $0x1,%al
   35261:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   35266:	b0 01                	mov    $0x1,%al
   35268:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3526c:	40 b5 01             	mov    $0x1,%bpl
   3526f:	41 b7 01             	mov    $0x1,%r15b
   35272:	41 b4 01             	mov    $0x1,%r12b
   35275:	41 b5 01             	mov    $0x1,%r13b
   35278:	e8 13 d0 ff ff       	call   32290 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   3527d:	b0 01                	mov    $0x1,%al
   3527f:	89 44 24 48          	mov    %eax,0x48(%rsp)
   35283:	b0 01                	mov    $0x1,%al
   35285:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   35289:	b0 01                	mov    $0x1,%al
   3528b:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3528f:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
   35296:	00 
   35297:	e9 96 06 00 00       	jmp    35932 <oriole_expat::dispatch+0x1ac2>
   3529c:	48 83 bc 24 30 05 00 	cmpq   $0x0,0x530(%rsp)
   352a3:	00 00 
   352a5:	e9 de 03 00 00       	jmp    35688 <oriole_expat::dispatch+0x1818>
   352aa:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   352af:	48 8b 41 30          	mov    0x30(%rcx),%rax
   352b3:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
   352ba:	00 
   352bb:	0f 10 01             	movups (%rcx),%xmm0
   352be:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   352c2:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   352c6:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
   352cd:	00 
   352ce:	0f 29 8c 24 00 01 00 	movaps %xmm1,0x100(%rsp)
   352d5:	00 
   352d6:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   352dd:	00 
   352de:	48 8b 41 68          	mov    0x68(%rcx),%rax
   352e2:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   352e9:	00 
   352ea:	0f 10 41 38          	movups 0x38(%rcx),%xmm0
   352ee:	0f 10 49 48          	movups 0x48(%rcx),%xmm1
   352f2:	0f 10 51 58          	movups 0x58(%rcx),%xmm2
   352f6:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   352fd:	00 
   352fe:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   35305:	00 
   35306:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   3530b:	4d 85 db             	test   %r11,%r11
   3530e:	0f 84 ff 17 00 00    	je     36b13 <oriole_expat::dispatch+0x2ca3>
   35314:	4d 89 df             	mov    %r11,%r15
   35317:	0f b6 59 70          	movzbl 0x70(%rcx),%ebx
   3531b:	48 8b 41 30          	mov    0x30(%rcx),%rax
   3531f:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   35326:	00 
   35327:	0f 10 01             	movups (%rcx),%xmm0
   3532a:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
   3532e:	0f 10 51 20          	movups 0x20(%rcx),%xmm2
   35332:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   35339:	00 
   3533a:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   35341:	00 
   35342:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   35349:	00 
   3534a:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   35351:	00 
   35352:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   35359:	00 
   3535a:	ff 15 20 16 0b 00    	call   *0xb1620(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   35360:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   35367:	00 
   35368:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   3536f:	00 00 
   35371:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   35375:	0f 84 2c 26 00 00    	je     379a7 <oriole_expat::dispatch+0x3b37>
   3537b:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   35382:	00 
   35383:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   3538a:	00 
   3538b:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   35392:	00 
   35393:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   3539a:	00 
   3539b:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   353a2:	00 
   353a3:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   353aa:	00 
   353ab:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   353b2:	00 
   353b3:	44 88 ac 24 b8 00 00 	mov    %r13b,0xb8(%rsp)
   353ba:	00 
   353bb:	4c 8b a4 24 d0 00 00 	mov    0xd0(%rsp),%r12
   353c2:	00 
   353c3:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   353ca:	00 
   353cb:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
   353d0:	e8 4b da ff ff       	call   32e20 <oriole_expat::optional_cstring>
   353d5:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   353dc:	00 
   353dd:	44 0f b6 ac 24 e8 02 	movzbl 0x2e8(%rsp),%r13d
   353e4:	00 00 
   353e6:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   353ea:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   353ef:	0f 85 82 27 00 00    	jne    37b77 <oriole_expat::dispatch+0x3d07>
   353f5:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   353fc:	00 
   353fd:	48 85 c9             	test   %rcx,%rcx
   35400:	0f 84 ab 25 00 00    	je     379b1 <oriole_expat::dispatch+0x3b41>
   35406:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   3540d:	00 
   3540e:	ba 01 00 00 00       	mov    $0x1,%edx
   35413:	4c 89 e6             	mov    %r12,%rsi
   35416:	ff 15 94 14 0b 00    	call   *0xb1494(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3541c:	e9 90 25 00 00       	jmp    379b1 <oriole_expat::dispatch+0x3b41>
   35421:	48 83 bc 24 18 04 00 	cmpq   $0x0,0x418(%rsp)
   35428:	00 00 
   3542a:	e9 59 02 00 00       	jmp    35688 <oriole_expat::dispatch+0x1818>
   3542f:	48 8b 48 30          	mov    0x30(%rax),%rcx
   35433:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
   3543a:	00 
   3543b:	0f 10 00             	movups (%rax),%xmm0
   3543e:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   35442:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   35446:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
   3544d:	00 
   3544e:	0f 29 8c 24 00 01 00 	movaps %xmm1,0x100(%rsp)
   35455:	00 
   35456:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   3545d:	00 
   3545e:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   35463:	48 8b 4a 70          	mov    0x70(%rdx),%rcx
   35467:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
   3546e:	00 
   3546f:	0f 10 42 40          	movups 0x40(%rdx),%xmm0
   35473:	0f 10 4a 50          	movups 0x50(%rdx),%xmm1
   35477:	0f 10 52 60          	movups 0x60(%rdx),%xmm2
   3547b:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   35482:	00 
   35483:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   3548a:	00 
   3548b:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   35490:	48 85 ed             	test   %rbp,%rbp
   35493:	0f 84 0e 17 00 00    	je     36ba7 <oriole_expat::dispatch+0x2d37>
   35499:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3549d:	48 89 8c 24 10 03 00 	mov    %rcx,0x310(%rsp)
   354a4:	00 
   354a5:	0f 10 00             	movups (%rax),%xmm0
   354a8:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   354ac:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   354b0:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   354b7:	00 
   354b8:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   354bf:	00 
   354c0:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   354c7:	00 
   354c8:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   354cf:	00 
   354d0:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   354d7:	00 
   354d8:	e8 43 d9 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   354dd:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   354e4:	00 
   354e5:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   354ec:	00 00 
   354ee:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   354f2:	0f 85 1f 22 00 00    	jne    37717 <oriole_expat::dispatch+0x38a7>
   354f8:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   354fd:	e8 3e 9e ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   35502:	e9 4b 28 00 00       	jmp    37d52 <oriole_expat::dispatch+0x3ee2>
   35507:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3550b:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
   35512:	00 
   35513:	0f 10 00             	movups (%rax),%xmm0
   35516:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   3551a:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   3551e:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   35525:	00 
   35526:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   3552d:	00 
   3552e:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   35533:	48 85 db             	test   %rbx,%rbx
   35536:	0f 84 de 16 00 00    	je     36c1a <oriole_expat::dispatch+0x2daa>
   3553c:	48 8b 48 30          	mov    0x30(%rax),%rcx
   35540:	48 89 8c 24 10 03 00 	mov    %rcx,0x310(%rsp)
   35547:	00 
   35548:	0f 10 00             	movups (%rax),%xmm0
   3554b:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   3554f:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   35553:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   3555a:	00 
   3555b:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   35562:	00 
   35563:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   3556a:	00 
   3556b:	b0 01                	mov    $0x1,%al
   3556d:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   35571:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
   35578:	00 00 
   3557a:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   35581:	00 
   35582:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   35589:	00 
   3558a:	b0 01                	mov    $0x1,%al
   3558c:	89 44 24 40          	mov    %eax,0x40(%rsp)
   35590:	b0 01                	mov    $0x1,%al
   35592:	89 44 24 50          	mov    %eax,0x50(%rsp)
   35596:	b0 01                	mov    $0x1,%al
   35598:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3559c:	b0 01                	mov    $0x1,%al
   3559e:	89 44 24 48          	mov    %eax,0x48(%rsp)
   355a2:	b0 01                	mov    $0x1,%al
   355a4:	89 44 24 14          	mov    %eax,0x14(%rsp)
   355a8:	b0 01                	mov    $0x1,%al
   355aa:	89 44 24 30          	mov    %eax,0x30(%rsp)
   355ae:	b0 01                	mov    $0x1,%al
   355b0:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   355b4:	b0 01                	mov    $0x1,%al
   355b6:	89 44 24 08          	mov    %eax,0x8(%rsp)
   355ba:	b0 01                	mov    $0x1,%al
   355bc:	89 44 24 28          	mov    %eax,0x28(%rsp)
   355c0:	b0 01                	mov    $0x1,%al
   355c2:	89 44 24 10          	mov    %eax,0x10(%rsp)
   355c6:	40 b5 01             	mov    $0x1,%bpl
   355c9:	41 b7 01             	mov    $0x1,%r15b
   355cc:	41 b4 01             	mov    $0x1,%r12b
   355cf:	41 b5 01             	mov    $0x1,%r13b
   355d2:	e8 49 d8 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   355d7:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   355de:	00 
   355df:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   355e6:	00 00 
   355e8:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   355ec:	0f 85 7c 21 00 00    	jne    3776e <oriole_expat::dispatch+0x38fe>
   355f2:	b0 01                	mov    $0x1,%al
   355f4:	89 44 24 14          	mov    %eax,0x14(%rsp)
   355f8:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
   355ff:	00 00 
   35601:	b0 01                	mov    $0x1,%al
   35603:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   35607:	b0 01                	mov    $0x1,%al
   35609:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3560d:	b0 01                	mov    $0x1,%al
   3560f:	89 44 24 50          	mov    %eax,0x50(%rsp)
   35613:	b0 01                	mov    $0x1,%al
   35615:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35619:	b0 01                	mov    $0x1,%al
   3561b:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3561f:	b0 01                	mov    $0x1,%al
   35621:	89 44 24 30          	mov    %eax,0x30(%rsp)
   35625:	b0 01                	mov    $0x1,%al
   35627:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3562b:	b0 01                	mov    $0x1,%al
   3562d:	89 44 24 08          	mov    %eax,0x8(%rsp)
   35631:	b0 01                	mov    $0x1,%al
   35633:	89 44 24 28          	mov    %eax,0x28(%rsp)
   35637:	e9 24 32 00 00       	jmp    38860 <oriole_expat::dispatch+0x49f0>
   3563c:	48 8b 84 24 40 05 00 	mov    0x540(%rsp),%rax
   35643:	00 
   35644:	48 85 c0             	test   %rax,%rax
   35647:	0f 84 33 16 00 00    	je     36c80 <oriole_expat::dispatch+0x2e10>
   3564d:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   35652:	ff d0                	call   *%rax
   35654:	41 c6 86 60 0b 00 00 	movb   $0x0,0xb60(%r14)
   3565b:	00 
   3565c:	b0 01                	mov    $0x1,%al
   3565e:	89 44 24 14          	mov    %eax,0x14(%rsp)
   35662:	b0 01                	mov    $0x1,%al
   35664:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   35668:	b0 01                	mov    $0x1,%al
   3566a:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3566e:	b0 01                	mov    $0x1,%al
   35670:	89 44 24 50          	mov    %eax,0x50(%rsp)
   35674:	b0 01                	mov    $0x1,%al
   35676:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3567a:	b0 01                	mov    $0x1,%al
   3567c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   35680:	e9 c3 16 00 00       	jmp    36d48 <oriole_expat::dispatch+0x2ed8>
   35685:	4d 85 d2             	test   %r10,%r10
   35688:	0f 95 c3             	setne  %bl
   3568b:	b0 01                	mov    $0x1,%al
   3568d:	b1 01                	mov    $0x1,%cl
   3568f:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   35693:	b1 01                	mov    $0x1,%cl
   35695:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   35699:	b1 01                	mov    $0x1,%cl
   3569b:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   3569f:	b1 01                	mov    $0x1,%cl
   356a1:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   356a5:	b1 01                	mov    $0x1,%cl
   356a7:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   356ab:	b1 01                	mov    $0x1,%cl
   356ad:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   356b1:	b1 01                	mov    $0x1,%cl
   356b3:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   356b7:	b1 01                	mov    $0x1,%cl
   356b9:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   356bd:	b1 01                	mov    $0x1,%cl
   356bf:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   356c3:	b1 01                	mov    $0x1,%cl
   356c5:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
   356c9:	b1 01                	mov    $0x1,%cl
   356cb:	89 4c 24 20          	mov    %ecx,0x20(%rsp)
   356cf:	b1 01                	mov    $0x1,%cl
   356d1:	89 4c 24 1c          	mov    %ecx,0x1c(%rsp)
   356d5:	b1 01                	mov    $0x1,%cl
   356d7:	89 4c 24 50          	mov    %ecx,0x50(%rsp)
   356db:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   356df:	b1 01                	mov    $0x1,%cl
   356e1:	b2 01                	mov    $0x1,%dl
   356e3:	84 db                	test   %bl,%bl
   356e5:	0f 85 91 16 00 00    	jne    36d7c <oriole_expat::dispatch+0x2f0c>
   356eb:	41 80 be 0a 0a 00 00 	cmpb   $0x0,0xa0a(%r14)
   356f2:	00 
   356f3:	0f 85 a0 1d 00 00    	jne    37499 <oriole_expat::dispatch+0x3629>
   356f9:	49 83 be c0 09 00 00 	cmpq   $0x0,0x9c0(%r14)
   35700:	00 
   35701:	0f 84 92 1d 00 00    	je     37499 <oriole_expat::dispatch+0x3629>
   35707:	49 8b 96 50 05 00 00 	mov    0x550(%r14),%rdx
   3570e:	48 85 d2             	test   %rdx,%rdx
   35711:	0f 84 ce 00 00 00    	je     357e5 <oriole_expat::dispatch+0x1975>
   35717:	49 8b b6 40 05 00 00 	mov    0x540(%r14),%rsi
   3571e:	41 0f 10 46 08       	movups 0x8(%r14),%xmm0
   35723:	41 0f 10 4e 18       	movups 0x18(%r14),%xmm1
   35728:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   3572f:	00 
   35730:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   35735:	b0 01                	mov    $0x1,%al
   35737:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3573b:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   35742:	00 
   35743:	48 8d 4c 24 70       	lea    0x70(%rsp),%rcx
   35748:	b0 01                	mov    $0x1,%al
   3574a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3574f:	8b 6c 24 24          	mov    0x24(%rsp),%ebp
   35753:	44 8b 7c 24 18       	mov    0x18(%rsp),%r15d
   35758:	44 8b 64 24 20       	mov    0x20(%rsp),%r12d
   3575d:	44 8b 6c 24 1c       	mov    0x1c(%rsp),%r13d
   35762:	ff 15 70 11 0b 00    	call   *0xb1170(%rip)        # e68d8 <_GLOBAL_OFFSET_TABLE_+0x160>
   35768:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   3576f:	00 
   35770:	44 0f b6 ac 24 e8 02 	movzbl 0x2e8(%rsp),%r13d
   35777:	00 00 
   35779:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   35780:	00 
   35781:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
   35788:	00 
   35789:	0f 10 84 24 f9 02 00 	movups 0x2f9(%rsp),%xmm0
   35790:	00 
   35791:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
   35798:	00 
   35799:	0f 10 84 24 08 03 00 	movups 0x308(%rsp),%xmm0
   357a0:	00 
   357a1:	0f 11 84 24 df 01 00 	movups %xmm0,0x1df(%rsp)
   357a8:	00 
   357a9:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   357ad:	0f 84 4b 25 00 00    	je     37cfe <oriole_expat::dispatch+0x3e8e>
   357b3:	0f 10 84 24 df 01 00 	movups 0x1df(%rsp),%xmm0
   357ba:	00 
   357bb:	0f 11 84 24 cf 00 00 	movups %xmm0,0xcf(%rsp)
   357c2:	00 
   357c3:	0f 28 84 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm0
   357ca:	00 
   357cb:	0f 28 8c 24 d0 01 00 	movaps 0x1d0(%rsp),%xmm1
   357d2:	00 
   357d3:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
   357da:	00 
   357db:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   357e2:	00 
   357e3:	eb 07                	jmp    357ec <oriole_expat::dispatch+0x197c>
   357e5:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   357ec:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
   357f3:	00 
   357f4:	0f 28 8c 24 c0 00 00 	movaps 0xc0(%rsp),%xmm1
   357fb:	00 
   357fc:	0f 29 84 24 a0 05 00 	movaps %xmm0,0x5a0(%rsp)
   35803:	00 
   35804:	0f 29 8c 24 b0 05 00 	movaps %xmm1,0x5b0(%rsp)
   3580b:	00 
   3580c:	0f 10 84 24 cf 00 00 	movups 0xcf(%rsp),%xmm0
   35813:	00 
   35814:	0f 11 84 24 bf 05 00 	movups %xmm0,0x5bf(%rsp)
   3581b:	00 
   3581c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   35820:	0f 84 73 1c 00 00    	je     37499 <oriole_expat::dispatch+0x3629>
   35826:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
   3582d:	00 
   3582e:	44 88 ac 24 c8 01 00 	mov    %r13b,0x1c8(%rsp)
   35835:	00 
   35836:	0f 28 84 24 a0 05 00 	movaps 0x5a0(%rsp),%xmm0
   3583d:	00 
   3583e:	0f 28 8c 24 b0 05 00 	movaps 0x5b0(%rsp),%xmm1
   35845:	00 
   35846:	0f 11 84 24 c9 01 00 	movups %xmm0,0x1c9(%rsp)
   3584d:	00 
   3584e:	0f 11 8c 24 d9 01 00 	movups %xmm1,0x1d9(%rsp)
   35855:	00 
   35856:	0f 10 84 24 bf 05 00 	movups 0x5bf(%rsp),%xmm0
   3585d:	00 
   3585e:	0f 11 84 24 e8 01 00 	movups %xmm0,0x1e8(%rsp)
   35865:	00 
   35866:	8b 84 24 d8 02 00 00 	mov    0x2d8(%rsp),%eax
   3586d:	20 84 24 08 04 00 00 	and    %al,0x408(%rsp)
   35874:	0f 84 c6 0d 00 00    	je     36640 <oriole_expat::dispatch+0x27d0>
   3587a:	48 8b 94 24 e0 01 00 	mov    0x1e0(%rsp),%rdx
   35881:	00 
   35882:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
   35889:	00 
   3588a:	48 b9 3c 21 45 4e 54 	movabs $0x595449544e45213c,%rcx
   35891:	49 54 59 
   35894:	48 83 f8 08          	cmp    $0x8,%rax
   35898:	0f 83 71 18 00 00    	jae    3710f <oriole_expat::dispatch+0x329f>
   3589e:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
   358a5:	00 
   358a6:	e9 6e 18 00 00       	jmp    37119 <oriole_expat::dispatch+0x32a9>
   358ab:	b0 01                	mov    $0x1,%al
   358ad:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   358b1:	b0 01                	mov    $0x1,%al
   358b3:	89 44 24 40          	mov    %eax,0x40(%rsp)
   358b7:	b0 01                	mov    $0x1,%al
   358b9:	89 44 24 50          	mov    %eax,0x50(%rsp)
   358bd:	b0 01                	mov    $0x1,%al
   358bf:	89 44 24 38          	mov    %eax,0x38(%rsp)
   358c3:	b0 01                	mov    $0x1,%al
   358c5:	89 44 24 48          	mov    %eax,0x48(%rsp)
   358c9:	b0 01                	mov    $0x1,%al
   358cb:	89 44 24 14          	mov    %eax,0x14(%rsp)
   358cf:	b0 01                	mov    $0x1,%al
   358d1:	89 44 24 30          	mov    %eax,0x30(%rsp)
   358d5:	b0 01                	mov    $0x1,%al
   358d7:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   358db:	b0 01                	mov    $0x1,%al
   358dd:	89 44 24 08          	mov    %eax,0x8(%rsp)
   358e1:	b0 01                	mov    $0x1,%al
   358e3:	89 44 24 10          	mov    %eax,0x10(%rsp)
   358e7:	b0 01                	mov    $0x1,%al
   358e9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   358ed:	b0 01                	mov    $0x1,%al
   358ef:	89 44 24 18          	mov    %eax,0x18(%rsp)
   358f3:	b0 01                	mov    $0x1,%al
   358f5:	89 44 24 20          	mov    %eax,0x20(%rsp)
   358f9:	b0 01                	mov    $0x1,%al
   358fb:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   358ff:	48 83 bc 24 28 05 00 	cmpq   $0x0,0x528(%rsp)
   35906:	00 00 
   35908:	0f 84 dd fd ff ff    	je     356eb <oriole_expat::dispatch+0x187b>
   3590e:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   35913:	ff 94 24 28 05 00 00 	call   *0x528(%rsp)
   3591a:	b0 01                	mov    $0x1,%al
   3591c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   35920:	b0 01                	mov    $0x1,%al
   35922:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   35926:	b0 01                	mov    $0x1,%al
   35928:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3592c:	b0 01                	mov    $0x1,%al
   3592e:	89 44 24 50          	mov    %eax,0x50(%rsp)
   35932:	b0 01                	mov    $0x1,%al
   35934:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35938:	e9 05 14 00 00       	jmp    36d42 <oriole_expat::dispatch+0x2ed2>
   3593d:	4c 89 e5             	mov    %r12,%rbp
   35940:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
   35945:	0f 10 00             	movups (%rax),%xmm0
   35948:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   3594c:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
   35953:	00 
   35954:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   3595b:	00 
   3595c:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   35961:	4c 8b 60 28          	mov    0x28(%rax),%r12
   35965:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3596c:	00 
   3596d:	ba 20 01 00 00       	mov    $0x120,%edx
   35972:	4c 89 e6             	mov    %r12,%rsi
   35975:	ff 15 1d 18 0b 00    	call   *0xb181d(%rip)        # e7198 <memcpy@GLIBC_2.14>
   3597b:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   35982:	00 
   35983:	ba 08 00 00 00       	mov    $0x8,%edx
   35988:	b9 20 01 00 00       	mov    $0x120,%ecx
   3598d:	4c 89 e6             	mov    %r12,%rsi
   35990:	ff 15 1a 0f 0b 00    	call   *0xb0f1a(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   35996:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   3599d:	00 
   3599e:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   359a5:	00 
   359a6:	ba 18 01 00 00       	mov    $0x118,%edx
   359ab:	ff 15 e7 17 0b 00    	call   *0xb17e7(%rip)        # e7198 <memcpy@GLIBC_2.14>
   359b1:	0f b6 8c 24 f8 03 00 	movzbl 0x3f8(%rsp),%ecx
   359b8:	00 
   359b9:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
   359c0:	00 
   359c1:	48 89 84 24 00 05 00 	mov    %rax,0x500(%rsp)
   359c8:	00 
   359c9:	0f 10 84 24 c0 01 00 	movups 0x1c0(%rsp),%xmm0
   359d0:	00 
   359d1:	0f 10 8c 24 d0 01 00 	movups 0x1d0(%rsp),%xmm1
   359d8:	00 
   359d9:	0f 10 94 24 e0 01 00 	movups 0x1e0(%rsp),%xmm2
   359e0:	00 
   359e1:	0f 29 94 24 f0 04 00 	movaps %xmm2,0x4f0(%rsp)
   359e8:	00 
   359e9:	0f 29 8c 24 e0 04 00 	movaps %xmm1,0x4e0(%rsp)
   359f0:	00 
   359f1:	0f 29 84 24 d0 04 00 	movaps %xmm0,0x4d0(%rsp)
   359f8:	00 
   359f9:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
   35a00:	00 
   35a01:	48 89 84 24 90 05 00 	mov    %rax,0x590(%rsp)
   35a08:	00 
   35a09:	0f 10 84 24 18 02 00 	movups 0x218(%rsp),%xmm0
   35a10:	00 
   35a11:	0f 29 84 24 80 05 00 	movaps %xmm0,0x580(%rsp)
   35a18:	00 
   35a19:	0f 10 84 24 08 02 00 	movups 0x208(%rsp),%xmm0
   35a20:	00 
   35a21:	0f 29 84 24 70 05 00 	movaps %xmm0,0x570(%rsp)
   35a28:	00 
   35a29:	0f 10 84 24 f8 01 00 	movups 0x1f8(%rsp),%xmm0
   35a30:	00 
   35a31:	0f 29 84 24 60 05 00 	movaps %xmm0,0x560(%rsp)
   35a38:	00 
   35a39:	48 8b 84 24 60 02 00 	mov    0x260(%rsp),%rax
   35a40:	00 
   35a41:	48 89 84 24 90 04 00 	mov    %rax,0x490(%rsp)
   35a48:	00 
   35a49:	0f 10 84 24 30 02 00 	movups 0x230(%rsp),%xmm0
   35a50:	00 
   35a51:	0f 10 8c 24 40 02 00 	movups 0x240(%rsp),%xmm1
   35a58:	00 
   35a59:	0f 10 94 24 50 02 00 	movups 0x250(%rsp),%xmm2
   35a60:	00 
   35a61:	0f 29 94 24 80 04 00 	movaps %xmm2,0x480(%rsp)
   35a68:	00 
   35a69:	0f 29 8c 24 70 04 00 	movaps %xmm1,0x470(%rsp)
   35a70:	00 
   35a71:	0f 29 84 24 60 04 00 	movaps %xmm0,0x460(%rsp)
   35a78:	00 
   35a79:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
   35a80:	00 
   35a81:	48 89 84 24 50 04 00 	mov    %rax,0x450(%rsp)
   35a88:	00 
   35a89:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   35a90:	00 
   35a91:	0f 10 8c 24 78 02 00 	movups 0x278(%rsp),%xmm1
   35a98:	00 
   35a99:	0f 10 94 24 88 02 00 	movups 0x288(%rsp),%xmm2
   35aa0:	00 
   35aa1:	0f 29 94 24 40 04 00 	movaps %xmm2,0x440(%rsp)
   35aa8:	00 
   35aa9:	0f 29 8c 24 30 04 00 	movaps %xmm1,0x430(%rsp)
   35ab0:	00 
   35ab1:	0f 29 84 24 20 04 00 	movaps %xmm0,0x420(%rsp)
   35ab8:	00 
   35ab9:	48 8b 84 24 d0 02 00 	mov    0x2d0(%rsp),%rax
   35ac0:	00 
   35ac1:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   35ac8:	00 
   35ac9:	0f 10 84 24 a0 02 00 	movups 0x2a0(%rsp),%xmm0
   35ad0:	00 
   35ad1:	0f 10 8c 24 b0 02 00 	movups 0x2b0(%rsp),%xmm1
   35ad8:	00 
   35ad9:	0f 10 94 24 c0 02 00 	movups 0x2c0(%rsp),%xmm2
   35ae0:	00 
   35ae1:	0f 29 94 24 50 01 00 	movaps %xmm2,0x150(%rsp)
   35ae8:	00 
   35ae9:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
   35af0:	00 
   35af1:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
   35af8:	00 
   35af9:	48 83 bc 24 30 01 00 	cmpq   $0xffffffffffffffff,0x130(%rsp)
   35b00:	00 ff 
   35b02:	0f 94 c0             	sete   %al
   35b05:	48 85 ed             	test   %rbp,%rbp
   35b08:	41 0f 94 c4          	sete   %r12b
   35b0c:	41 08 c4             	or     %al,%r12b
   35b0f:	41 80 fc 01          	cmp    $0x1,%r12b
   35b13:	0f 85 d1 0b 00 00    	jne    366ea <oriole_expat::dispatch+0x287a>
   35b19:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
   35b1f:	0f 84 57 21 00 00    	je     37c7c <oriole_expat::dispatch+0x3e0c>
   35b25:	41 89 cc             	mov    %ecx,%r12d
   35b28:	45 31 ff             	xor    %r15d,%r15d
   35b2b:	48 83 bc 24 60 05 00 	cmpq   $0xffffffffffffffff,0x560(%rsp)
   35b32:	00 ff 
   35b34:	bd 00 00 00 00       	mov    $0x0,%ebp
   35b39:	74 07                	je     35b42 <oriole_expat::dispatch+0x1cd2>
   35b3b:	8b ac 24 90 05 00 00 	mov    0x590(%rsp),%ebp
   35b42:	48 8b 84 24 00 05 00 	mov    0x500(%rsp),%rax
   35b49:	00 
   35b4a:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   35b51:	00 
   35b52:	0f 28 84 24 d0 04 00 	movaps 0x4d0(%rsp),%xmm0
   35b59:	00 
   35b5a:	0f 28 8c 24 e0 04 00 	movaps 0x4e0(%rsp),%xmm1
   35b61:	00 
   35b62:	0f 28 94 24 f0 04 00 	movaps 0x4f0(%rsp),%xmm2
   35b69:	00 
   35b6a:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   35b71:	00 
   35b72:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   35b79:	00 
   35b7a:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   35b81:	00 
   35b82:	b0 01                	mov    $0x1,%al
   35b84:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35b88:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   35b8f:	00 
   35b90:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   35b97:	00 
   35b98:	b0 01                	mov    $0x1,%al
   35b9a:	89 44 24 40          	mov    %eax,0x40(%rsp)
   35b9e:	b3 01                	mov    $0x1,%bl
   35ba0:	41 b5 01             	mov    $0x1,%r13b
   35ba3:	ff 15 d7 0d 0b 00    	call   *0xb0dd7(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   35ba9:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   35bb0:	00 
   35bb1:	0f b6 8c 24 c8 01 00 	movzbl 0x1c8(%rsp),%ecx
   35bb8:	00 
   35bb9:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   35bbd:	0f 84 42 26 00 00    	je     38205 <oriole_expat::dispatch+0x4395>
   35bc3:	89 6c 24 40          	mov    %ebp,0x40(%rsp)
   35bc7:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   35bce:	00 
   35bcf:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   35bd6:	00 
   35bd7:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   35bde:	00 
   35bdf:	0f 11 94 24 98 01 00 	movups %xmm2,0x198(%rsp)
   35be6:	00 
   35be7:	0f 11 8c 24 89 01 00 	movups %xmm1,0x189(%rsp)
   35bee:	00 
   35bef:	0f 11 84 24 79 01 00 	movups %xmm0,0x179(%rsp)
   35bf6:	00 
   35bf7:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
   35bfe:	00 
   35bff:	88 8c 24 78 01 00 00 	mov    %cl,0x178(%rsp)
   35c06:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
   35c0d:	00 
   35c0e:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   35c13:	41 b7 01             	mov    $0x1,%r15b
   35c16:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   35c1d:	00 
   35c1e:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
   35c25:	00 
   35c26:	40 b5 01             	mov    $0x1,%bpl
   35c29:	b3 01                	mov    $0x1,%bl
   35c2b:	e8 f0 d1 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   35c30:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   35c37:	00 
   35c38:	0f b6 8c 24 e8 02 00 	movzbl 0x2e8(%rsp),%ecx
   35c3f:	00 
   35c40:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   35c44:	0f 85 5e 27 00 00    	jne    383a8 <oriole_expat::dispatch+0x4538>
   35c4a:	41 89 ce             	mov    %ecx,%r14d
   35c4d:	48 8b 8c 24 98 01 00 	mov    0x198(%rsp),%rcx
   35c54:	00 
   35c55:	48 85 c9             	test   %rcx,%rcx
   35c58:	74 2c                	je     35c86 <oriole_expat::dispatch+0x1e16>
   35c5a:	b0 01                	mov    $0x1,%al
   35c5c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   35c60:	45 31 ed             	xor    %r13d,%r13d
   35c63:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   35c6a:	00 
   35c6b:	ba 01 00 00 00       	mov    $0x1,%edx
   35c70:	b0 01                	mov    $0x1,%al
   35c72:	89 44 24 40          	mov    %eax,0x40(%rsp)
   35c76:	b3 01                	mov    $0x1,%bl
   35c78:	45 31 ff             	xor    %r15d,%r15d
   35c7b:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   35c80:	ff 15 2a 0c 0b 00    	call   *0xb0c2a(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   35c86:	40 b5 01             	mov    $0x1,%bpl
   35c89:	45 31 ed             	xor    %r13d,%r13d
   35c8c:	b3 01                	mov    $0x1,%bl
   35c8e:	e9 17 33 00 00       	jmp    38faa <oriole_expat::dispatch+0x513a>
   35c93:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   35c98:	48 8b 4a 70          	mov    0x70(%rdx),%rcx
   35c9c:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
   35ca3:	00 
   35ca4:	0f 10 42 40          	movups 0x40(%rdx),%xmm0
   35ca8:	0f 10 4a 50          	movups 0x50(%rdx),%xmm1
   35cac:	0f 10 52 60          	movups 0x60(%rdx),%xmm2
   35cb0:	0f 29 94 24 90 01 00 	movaps %xmm2,0x190(%rsp)
   35cb7:	00 
   35cb8:	0f 29 8c 24 80 01 00 	movaps %xmm1,0x180(%rsp)
   35cbf:	00 
   35cc0:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
   35cc7:	00 
   35cc8:	48 8b 48 30          	mov    0x30(%rax),%rcx
   35ccc:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
   35cd3:	00 
   35cd4:	0f 10 00             	movups (%rax),%xmm0
   35cd7:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   35cdb:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   35cdf:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
   35ce6:	00 
   35ce7:	0f 29 8c 24 00 01 00 	movaps %xmm1,0x100(%rsp)
   35cee:	00 
   35cef:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   35cf6:	00 
   35cf7:	4d 85 db             	test   %r11,%r11
   35cfa:	0f 84 95 0f 00 00    	je     36c95 <oriole_expat::dispatch+0x2e25>
   35d00:	4d 89 df             	mov    %r11,%r15
   35d03:	48 8d 42 40          	lea    0x40(%rdx),%rax
   35d07:	48 8b 48 30          	mov    0x30(%rax),%rcx
   35d0b:	48 89 8c 24 10 03 00 	mov    %rcx,0x310(%rsp)
   35d12:	00 
   35d13:	0f 10 00             	movups (%rax),%xmm0
   35d16:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   35d1a:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   35d1e:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   35d25:	00 
   35d26:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   35d2d:	00 
   35d2e:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   35d35:	00 
   35d36:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   35d3d:	00 
   35d3e:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   35d45:	00 
   35d46:	e8 d5 d0 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   35d4b:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   35d52:	00 
   35d53:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   35d5a:	00 00 
   35d5c:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   35d60:	0f 85 64 1a 00 00    	jne    377ca <oriole_expat::dispatch+0x395a>
   35d66:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   35d6d:	00 
   35d6e:	48 85 c9             	test   %rcx,%rcx
   35d71:	0f 84 bd 24 00 00    	je     38234 <oriole_expat::dispatch+0x43c4>
   35d77:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   35d7e:	00 
   35d7f:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   35d86:	00 
   35d87:	ba 01 00 00 00       	mov    $0x1,%edx
   35d8c:	ff 15 1e 0b 0b 00    	call   *0xb0b1e(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   35d92:	e9 9d 24 00 00       	jmp    38234 <oriole_expat::dispatch+0x43c4>
   35d97:	48 8b 8c 24 38 05 00 	mov    0x538(%rsp),%rcx
   35d9e:	00 
   35d9f:	b0 01                	mov    $0x1,%al
   35da1:	48 85 c9             	test   %rcx,%rcx
   35da4:	0f 84 7c 0f 00 00    	je     36d26 <oriole_expat::dispatch+0x2eb6>
   35daa:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   35dae:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   35db3:	ff d1                	call   *%rcx
   35db5:	85 c0                	test   %eax,%eax
   35db7:	0f 85 6d 0f 00 00    	jne    36d2a <oriole_expat::dispatch+0x2eba>
   35dbd:	48 b8 16 00 00 00 16 	movabs $0x1600000016,%rax
   35dc4:	00 00 00 
   35dc7:	49 89 86 10 0a 00 00 	mov    %rax,0xa10(%r14)
   35dce:	e9 57 0f 00 00       	jmp    36d2a <oriole_expat::dispatch+0x2eba>
   35dd3:	0f 10 00             	movups (%rax),%xmm0
   35dd6:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   35dda:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
   35de1:	00 
   35de2:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   35de9:	00 
   35dea:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   35def:	4c 8b 60 28          	mov    0x28(%rax),%r12
   35df3:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   35dfa:	00 
   35dfb:	ba b0 00 00 00       	mov    $0xb0,%edx
   35e00:	4c 89 e6             	mov    %r12,%rsi
   35e03:	ff 15 8f 13 0b 00    	call   *0xb138f(%rip)        # e7198 <memcpy@GLIBC_2.14>
   35e09:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   35e10:	00 
   35e11:	ba 08 00 00 00       	mov    $0x8,%edx
   35e16:	b9 b0 00 00 00       	mov    $0xb0,%ecx
   35e1b:	4c 89 e6             	mov    %r12,%rsi
   35e1e:	ff 15 8c 0a 0b 00    	call   *0xb0a8c(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   35e24:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   35e2b:	00 
   35e2c:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   35e33:	00 
   35e34:	ba a8 00 00 00       	mov    $0xa8,%edx
   35e39:	ff 15 59 13 0b 00    	call   *0xb1359(%rip)        # e7198 <memcpy@GLIBC_2.14>
   35e3f:	44 0f b6 a4 24 88 03 	movzbl 0x388(%rsp),%r12d
   35e46:	00 00 
   35e48:	48 8b ac 24 18 04 00 	mov    0x418(%rsp),%rbp
   35e4f:	00 
   35e50:	48 85 ed             	test   %rbp,%rbp
   35e53:	0f 95 c0             	setne  %al
   35e56:	44 89 e1             	mov    %r12d,%ecx
   35e59:	80 f1 01             	xor    $0x1,%cl
   35e5c:	20 c1                	and    %al,%cl
   35e5e:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
   35e65:	00 
   35e66:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   35e6d:	00 
   35e6e:	0f 10 84 24 c0 01 00 	movups 0x1c0(%rsp),%xmm0
   35e75:	00 
   35e76:	0f 10 8c 24 d0 01 00 	movups 0x1d0(%rsp),%xmm1
   35e7d:	00 
   35e7e:	0f 10 94 24 e0 01 00 	movups 0x1e0(%rsp),%xmm2
   35e85:	00 
   35e86:	0f 29 94 24 50 01 00 	movaps %xmm2,0x150(%rsp)
   35e8d:	00 
   35e8e:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
   35e95:	00 
   35e96:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
   35e9d:	00 
   35e9e:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
   35ea5:	00 
   35ea6:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
   35ead:	00 
   35eae:	0f 10 84 24 18 02 00 	movups 0x218(%rsp),%xmm0
   35eb5:	00 
   35eb6:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
   35ebd:	00 
   35ebe:	0f 10 84 24 08 02 00 	movups 0x208(%rsp),%xmm0
   35ec5:	00 
   35ec6:	0f 29 84 24 80 01 00 	movaps %xmm0,0x180(%rsp)
   35ecd:	00 
   35ece:	0f 10 84 24 f8 01 00 	movups 0x1f8(%rsp),%xmm0
   35ed5:	00 
   35ed6:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
   35edd:	00 
   35ede:	48 8b 84 24 60 02 00 	mov    0x260(%rsp),%rax
   35ee5:	00 
   35ee6:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
   35eed:	00 
   35eee:	0f 10 84 24 30 02 00 	movups 0x230(%rsp),%xmm0
   35ef5:	00 
   35ef6:	0f 10 8c 24 40 02 00 	movups 0x240(%rsp),%xmm1
   35efd:	00 
   35efe:	0f 10 94 24 50 02 00 	movups 0x250(%rsp),%xmm2
   35f05:	00 
   35f06:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
   35f0d:	00 
   35f0e:	0f 29 8c 24 00 01 00 	movaps %xmm1,0x100(%rsp)
   35f15:	00 
   35f16:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   35f1d:	00 
   35f1e:	41 88 8e 60 0b 00 00 	mov    %cl,0xb60(%r14)
   35f25:	48 85 ed             	test   %rbp,%rbp
   35f28:	0f 84 50 10 00 00    	je     36f7e <oriole_expat::dispatch+0x310e>
   35f2e:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
   35f35:	00 
   35f36:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   35f3d:	00 
   35f3e:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
   35f45:	00 
   35f46:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
   35f4d:	00 
   35f4e:	0f 28 94 24 50 01 00 	movaps 0x150(%rsp),%xmm2
   35f55:	00 
   35f56:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   35f5d:	00 
   35f5e:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   35f65:	00 
   35f66:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   35f6d:	00 
   35f6e:	b3 01                	mov    $0x1,%bl
   35f70:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   35f77:	00 
   35f78:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   35f7f:	00 
   35f80:	ff 15 fa 09 0b 00    	call   *0xb09fa(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   35f86:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   35f8d:	00 
   35f8e:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   35f95:	00 00 
   35f97:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   35f9b:	4c 8b 7c 24 68       	mov    0x68(%rsp),%r15
   35fa0:	0f 84 bd 1a 00 00    	je     37a63 <oriole_expat::dispatch+0x3bf3>
   35fa6:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   35fad:	00 
   35fae:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   35fb5:	00 
   35fb6:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   35fbd:	00 
   35fbe:	0f 11 94 24 98 00 00 	movups %xmm2,0x98(%rsp)
   35fc5:	00 
   35fc6:	0f 11 8c 24 89 00 00 	movups %xmm1,0x89(%rsp)
   35fcd:	00 
   35fce:	0f 11 44 24 79       	movups %xmm0,0x79(%rsp)
   35fd3:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   35fd8:	44 88 6c 24 78       	mov    %r13b,0x78(%rsp)
   35fdd:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   35fe4:	00 
   35fe5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   35fea:	b3 01                	mov    $0x1,%bl
   35fec:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   35ff3:	00 
   35ff4:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
   35ffb:	00 
   35ffc:	e8 1f ce ff ff       	call   32e20 <oriole_expat::optional_cstring>
   36001:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   36008:	00 
   36009:	44 0f b6 ac 24 e8 02 	movzbl 0x2e8(%rsp),%r13d
   36010:	00 00 
   36012:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   36016:	0f 85 09 1c 00 00    	jne    37c25 <oriole_expat::dispatch+0x3db5>
   3601c:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   36023:	00 
   36024:	48 85 c9             	test   %rcx,%rcx
   36027:	74 17                	je     36040 <oriole_expat::dispatch+0x21d0>
   36029:	31 db                	xor    %ebx,%ebx
   3602b:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   36030:	ba 01 00 00 00       	mov    $0x1,%edx
   36035:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   3603a:	ff 15 70 08 0b 00    	call   *0xb0870(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36040:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   36047:	00 
   36048:	e8 f3 92 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3604d:	e9 ab 24 00 00       	jmp    384fd <oriole_expat::dispatch+0x468d>
   36052:	4c 89 94 24 00 04 00 	mov    %r10,0x400(%rsp)
   36059:	00 
   3605a:	0f 10 00             	movups (%rax),%xmm0
   3605d:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   36061:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
   36068:	00 
   36069:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   36070:	00 
   36071:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   36076:	4c 8b 60 28          	mov    0x28(%rax),%r12
   3607a:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   36081:	00 
   36082:	ba e8 00 00 00       	mov    $0xe8,%edx
   36087:	4c 89 e6             	mov    %r12,%rsi
   3608a:	ff 15 08 11 0b 00    	call   *0xb1108(%rip)        # e7198 <memcpy@GLIBC_2.14>
   36090:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   36097:	00 
   36098:	ba 08 00 00 00       	mov    $0x8,%edx
   3609d:	b9 e8 00 00 00       	mov    $0xe8,%ecx
   360a2:	4c 89 e6             	mov    %r12,%rsi
   360a5:	ff 15 05 08 0b 00    	call   *0xb0805(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   360ab:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   360b2:	00 
   360b3:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   360ba:	00 
   360bb:	ba e0 00 00 00       	mov    $0xe0,%edx
   360c0:	ff 15 d2 10 0b 00    	call   *0xb10d2(%rip)        # e7198 <memcpy@GLIBC_2.14>
   360c6:	44 0f b6 a4 24 c0 03 	movzbl 0x3c0(%rsp),%r12d
   360cd:	00 00 
   360cf:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
   360d6:	00 
   360d7:	48 89 84 24 90 04 00 	mov    %rax,0x490(%rsp)
   360de:	00 
   360df:	0f 10 84 24 c0 01 00 	movups 0x1c0(%rsp),%xmm0
   360e6:	00 
   360e7:	0f 10 8c 24 d0 01 00 	movups 0x1d0(%rsp),%xmm1
   360ee:	00 
   360ef:	0f 10 94 24 e0 01 00 	movups 0x1e0(%rsp),%xmm2
   360f6:	00 
   360f7:	0f 29 94 24 80 04 00 	movaps %xmm2,0x480(%rsp)
   360fe:	00 
   360ff:	0f 29 8c 24 70 04 00 	movaps %xmm1,0x470(%rsp)
   36106:	00 
   36107:	0f 29 84 24 60 04 00 	movaps %xmm0,0x460(%rsp)
   3610e:	00 
   3610f:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
   36116:	00 
   36117:	48 89 84 24 50 04 00 	mov    %rax,0x450(%rsp)
   3611e:	00 
   3611f:	0f 10 84 24 18 02 00 	movups 0x218(%rsp),%xmm0
   36126:	00 
   36127:	0f 29 84 24 40 04 00 	movaps %xmm0,0x440(%rsp)
   3612e:	00 
   3612f:	0f 10 84 24 08 02 00 	movups 0x208(%rsp),%xmm0
   36136:	00 
   36137:	0f 29 84 24 30 04 00 	movaps %xmm0,0x430(%rsp)
   3613e:	00 
   3613f:	0f 10 84 24 f8 01 00 	movups 0x1f8(%rsp),%xmm0
   36146:	00 
   36147:	0f 29 84 24 20 04 00 	movaps %xmm0,0x420(%rsp)
   3614e:	00 
   3614f:	48 8b 84 24 60 02 00 	mov    0x260(%rsp),%rax
   36156:	00 
   36157:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   3615e:	00 
   3615f:	0f 10 84 24 30 02 00 	movups 0x230(%rsp),%xmm0
   36166:	00 
   36167:	0f 10 8c 24 40 02 00 	movups 0x240(%rsp),%xmm1
   3616e:	00 
   3616f:	0f 10 94 24 50 02 00 	movups 0x250(%rsp),%xmm2
   36176:	00 
   36177:	0f 29 94 24 50 01 00 	movaps %xmm2,0x150(%rsp)
   3617e:	00 
   3617f:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
   36186:	00 
   36187:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
   3618e:	00 
   3618f:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
   36196:	00 
   36197:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
   3619e:	00 
   3619f:	0f 10 84 24 68 02 00 	movups 0x268(%rsp),%xmm0
   361a6:	00 
   361a7:	0f 10 8c 24 78 02 00 	movups 0x278(%rsp),%xmm1
   361ae:	00 
   361af:	0f 10 94 24 88 02 00 	movups 0x288(%rsp),%xmm2
   361b6:	00 
   361b7:	0f 29 94 24 90 01 00 	movaps %xmm2,0x190(%rsp)
   361be:	00 
   361bf:	0f 29 8c 24 80 01 00 	movaps %xmm1,0x180(%rsp)
   361c6:	00 
   361c7:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
   361ce:	00 
   361cf:	48 83 bc 24 00 04 00 	cmpq   $0x0,0x400(%rsp)
   361d6:	00 00 
   361d8:	0f 84 44 0e 00 00    	je     37022 <oriole_expat::dispatch+0x31b2>
   361de:	48 8b 84 24 90 04 00 	mov    0x490(%rsp),%rax
   361e5:	00 
   361e6:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   361ed:	00 
   361ee:	0f 28 84 24 60 04 00 	movaps 0x460(%rsp),%xmm0
   361f5:	00 
   361f6:	0f 28 8c 24 70 04 00 	movaps 0x470(%rsp),%xmm1
   361fd:	00 
   361fe:	0f 28 94 24 80 04 00 	movaps 0x480(%rsp),%xmm2
   36205:	00 
   36206:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   3620d:	00 
   3620e:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   36215:	00 
   36216:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   3621d:	00 
   3621e:	b3 01                	mov    $0x1,%bl
   36220:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   36227:	00 
   36228:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   3622f:	00 
   36230:	40 b5 01             	mov    $0x1,%bpl
   36233:	41 b5 01             	mov    $0x1,%r13b
   36236:	ff 15 44 07 0b 00    	call   *0xb0744(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   3623c:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   36243:	00 
   36244:	0f b6 8c 24 c8 01 00 	movzbl 0x1c8(%rsp),%ecx
   3624b:	00 
   3624c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   36250:	0f 84 2c 18 00 00    	je     37a82 <oriole_expat::dispatch+0x3c12>
   36256:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   3625d:	00 
   3625e:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   36265:	00 
   36266:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   3626d:	00 
   3626e:	0f 11 94 24 18 01 00 	movups %xmm2,0x118(%rsp)
   36275:	00 
   36276:	0f 11 8c 24 09 01 00 	movups %xmm1,0x109(%rsp)
   3627d:	00 
   3627e:	0f 11 84 24 f9 00 00 	movups %xmm0,0xf9(%rsp)
   36285:	00 
   36286:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
   3628d:	00 
   3628e:	88 8c 24 f8 00 00 00 	mov    %cl,0xf8(%rsp)
   36295:	4c 8b bc 24 10 01 00 	mov    0x110(%rsp),%r15
   3629c:	00 
   3629d:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
   362a4:	00 
   362a5:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   362ac:	00 
   362ad:	0f 28 84 24 20 04 00 	movaps 0x420(%rsp),%xmm0
   362b4:	00 
   362b5:	0f 28 8c 24 30 04 00 	movaps 0x430(%rsp),%xmm1
   362bc:	00 
   362bd:	0f 28 94 24 40 04 00 	movaps 0x440(%rsp),%xmm2
   362c4:	00 
   362c5:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   362cc:	00 
   362cd:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   362d4:	00 
   362d5:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   362dc:	00 
   362dd:	b3 01                	mov    $0x1,%bl
   362df:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   362e6:	00 
   362e7:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   362ee:	00 
   362ef:	40 b5 01             	mov    $0x1,%bpl
   362f2:	ff 15 88 06 0b 00    	call   *0xb0688(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   362f8:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   362ff:	00 
   36300:	0f b6 8c 24 c8 01 00 	movzbl 0x1c8(%rsp),%ecx
   36307:	00 
   36308:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3630c:	0f 84 54 1d 00 00    	je     38066 <oriole_expat::dispatch+0x41f6>
   36312:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   36319:	00 
   3631a:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   36321:	00 
   36322:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   36329:	00 
   3632a:	0f 11 94 24 98 00 00 	movups %xmm2,0x98(%rsp)
   36331:	00 
   36332:	0f 11 8c 24 89 00 00 	movups %xmm1,0x89(%rsp)
   36339:	00 
   3633a:	0f 11 44 24 79       	movups %xmm0,0x79(%rsp)
   3633f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   36344:	88 4c 24 78          	mov    %cl,0x78(%rsp)
   36348:	4c 8b ac 24 90 00 00 	mov    0x90(%rsp),%r13
   3634f:	00 
   36350:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
   36357:	00 
   36358:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   3635f:	00 
   36360:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
   36367:	00 
   36368:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
   3636f:	00 
   36370:	0f 28 94 24 50 01 00 	movaps 0x150(%rsp),%xmm2
   36377:	00 
   36378:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   3637f:	00 
   36380:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   36387:	00 
   36388:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   3638f:	00 
   36390:	b3 01                	mov    $0x1,%bl
   36392:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   36399:	00 
   3639a:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   363a1:	00 
   363a2:	ff 15 d8 05 0b 00    	call   *0xb05d8(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   363a8:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   363af:	00 
   363b0:	0f b6 ac 24 c8 01 00 	movzbl 0x1c8(%rsp),%ebp
   363b7:	00 
   363b8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   363bc:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   363c1:	0f 84 7c 22 00 00    	je     38643 <oriole_expat::dispatch+0x47d3>
   363c7:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   363ce:	00 
   363cf:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   363d6:	00 
   363d7:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   363de:	00 
   363df:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   363e6:	00 
   363e7:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   363ee:	00 
   363ef:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   363f6:	00 
   363f7:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   363fe:	00 
   363ff:	40 88 ac 24 b8 00 00 	mov    %bpl,0xb8(%rsp)
   36406:	00 
   36407:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   3640e:	00 
   3640f:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   36414:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3641b:	00 
   3641c:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
   36423:	00 
   36424:	e8 f7 c9 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   36429:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   36430:	00 
   36431:	0f b6 ac 24 e8 02 00 	movzbl 0x2e8(%rsp),%ebp
   36438:	00 
   36439:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   3643d:	0f 85 ee 27 00 00    	jne    38c31 <oriole_expat::dispatch+0x4dc1>
   36443:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   3644a:	00 
   3644b:	31 db                	xor    %ebx,%ebx
   3644d:	48 85 c9             	test   %rcx,%rcx
   36450:	0f 84 ef 21 00 00    	je     38645 <oriole_expat::dispatch+0x47d5>
   36456:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   3645d:	00 
   3645e:	ba 01 00 00 00       	mov    $0x1,%edx
   36463:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   36468:	ff 15 42 04 0b 00    	call   *0xb0442(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3646e:	e9 d2 21 00 00       	jmp    38645 <oriole_expat::dispatch+0x47d5>
   36473:	48 8b 48 30          	mov    0x30(%rax),%rcx
   36477:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
   3647e:	00 
   3647f:	0f 10 00             	movups (%rax),%xmm0
   36482:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   36486:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   3648a:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
   36491:	00 
   36492:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   36499:	00 
   3649a:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   3649f:	48 83 bc 24 18 05 00 	cmpq   $0x0,0x518(%rsp)
   364a6:	00 00 
   364a8:	0f 84 ea 08 00 00    	je     36d98 <oriole_expat::dispatch+0x2f28>
   364ae:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   364b3:	0f b6 59 40          	movzbl 0x40(%rcx),%ebx
   364b7:	48 8b 48 30          	mov    0x30(%rax),%rcx
   364bb:	48 89 8c 24 10 03 00 	mov    %rcx,0x310(%rsp)
   364c2:	00 
   364c3:	0f 10 00             	movups (%rax),%xmm0
   364c6:	0f 10 48 10          	movups 0x10(%rax),%xmm1
   364ca:	0f 10 50 20          	movups 0x20(%rax),%xmm2
   364ce:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   364d5:	00 
   364d6:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   364dd:	00 
   364de:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   364e5:	00 
   364e6:	b0 01                	mov    $0x1,%al
   364e8:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   364ec:	45 31 ed             	xor    %r13d,%r13d
   364ef:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   364f6:	00 
   364f7:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   364fe:	00 
   364ff:	b0 01                	mov    $0x1,%al
   36501:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36505:	b0 01                	mov    $0x1,%al
   36507:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3650b:	b0 01                	mov    $0x1,%al
   3650d:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36511:	b0 01                	mov    $0x1,%al
   36513:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36517:	b0 01                	mov    $0x1,%al
   36519:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3651d:	b0 01                	mov    $0x1,%al
   3651f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36523:	b0 01                	mov    $0x1,%al
   36525:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36529:	b0 01                	mov    $0x1,%al
   3652b:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3652f:	b0 01                	mov    $0x1,%al
   36531:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36535:	b0 01                	mov    $0x1,%al
   36537:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3653c:	b0 01                	mov    $0x1,%al
   3653e:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36542:	40 b5 01             	mov    $0x1,%bpl
   36545:	41 b7 01             	mov    $0x1,%r15b
   36548:	41 b4 01             	mov    $0x1,%r12b
   3654b:	ff 15 2f 04 0b 00    	call   *0xb042f(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   36551:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   36558:	00 
   36559:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   36560:	00 00 
   36562:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   36566:	0f 84 70 14 00 00    	je     379dc <oriole_expat::dispatch+0x3b6c>
   3656c:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   36573:	00 
   36574:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   3657b:	00 
   3657c:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   36583:	00 
   36584:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   3658b:	00 
   3658c:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   36593:	00 
   36594:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   3659b:	00 
   3659c:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   365a3:	00 
   365a4:	44 88 ac 24 b8 00 00 	mov    %r13b,0xb8(%rsp)
   365ab:	00 
   365ac:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   365b3:	00 
   365b4:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   365b9:	89 da                	mov    %ebx,%edx
   365bb:	ff 94 24 18 05 00 00 	call   *0x518(%rsp)
   365c2:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   365c9:	00 
   365ca:	48 85 c9             	test   %rcx,%rcx
   365cd:	74 6a                	je     36639 <oriole_expat::dispatch+0x27c9>
   365cf:	45 31 ed             	xor    %r13d,%r13d
   365d2:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   365d9:	00 
   365da:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   365e1:	00 
   365e2:	ba 01 00 00 00       	mov    $0x1,%edx
   365e7:	b0 01                	mov    $0x1,%al
   365e9:	89 44 24 40          	mov    %eax,0x40(%rsp)
   365ed:	b0 01                	mov    $0x1,%al
   365ef:	89 44 24 50          	mov    %eax,0x50(%rsp)
   365f3:	b0 01                	mov    $0x1,%al
   365f5:	89 44 24 38          	mov    %eax,0x38(%rsp)
   365f9:	b0 01                	mov    $0x1,%al
   365fb:	89 44 24 48          	mov    %eax,0x48(%rsp)
   365ff:	b0 01                	mov    $0x1,%al
   36601:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36605:	b0 01                	mov    $0x1,%al
   36607:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3660b:	b0 01                	mov    $0x1,%al
   3660d:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36611:	b0 01                	mov    $0x1,%al
   36613:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36617:	b0 01                	mov    $0x1,%al
   36619:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3661d:	b0 01                	mov    $0x1,%al
   3661f:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   36624:	b0 01                	mov    $0x1,%al
   36626:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3662a:	40 b5 01             	mov    $0x1,%bpl
   3662d:	41 b7 01             	mov    $0x1,%r15b
   36630:	41 b4 01             	mov    $0x1,%r12b
   36633:	ff 15 77 02 0b 00    	call   *0xb0277(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36639:	b3 01                	mov    $0x1,%bl
   3663b:	e9 75 1a 00 00       	jmp    380b5 <oriole_expat::dispatch+0x4245>
   36640:	49 8d be 20 0b 00 00 	lea    0xb20(%r14),%rdi
   36647:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
   3664e:	00 
   3664f:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   36656:	00 
   36657:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   3665e:	00 
   3665f:	0f b6 8c 24 c8 01 00 	movzbl 0x1c8(%rsp),%ecx
   36666:	00 
   36667:	8b 94 24 c9 01 00 00 	mov    0x1c9(%rsp),%edx
   3666e:	0f b7 b4 24 cd 01 00 	movzwl 0x1cd(%rsp),%esi
   36675:	00 
   36676:	44 0f b6 84 24 cf 01 	movzbl 0x1cf(%rsp),%r8d
   3667d:	00 00 
   3667f:	0f 10 84 24 d0 01 00 	movups 0x1d0(%rsp),%xmm0
   36686:	00 
   36687:	0f 10 8c 24 e0 01 00 	movups 0x1e0(%rsp),%xmm1
   3668e:	00 
   3668f:	0f 29 8c 24 00 03 00 	movaps %xmm1,0x300(%rsp)
   36696:	00 
   36697:	0f 29 84 24 f0 02 00 	movaps %xmm0,0x2f0(%rsp)
   3669e:	00 
   3669f:	48 89 84 24 e0 02 00 	mov    %rax,0x2e0(%rsp)
   366a6:	00 
   366a7:	88 8c 24 e8 02 00 00 	mov    %cl,0x2e8(%rsp)
   366ae:	89 94 24 e9 02 00 00 	mov    %edx,0x2e9(%rsp)
   366b5:	66 89 b4 24 ed 02 00 	mov    %si,0x2ed(%rsp)
   366bc:	00 
   366bd:	44 88 84 24 ef 02 00 	mov    %r8b,0x2ef(%rsp)
   366c4:	00 
   366c5:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   366cc:	00 
   366cd:	e8 be 55 00 00       	call   3bc90 <<oriole_storage::queue::Queue<oriole_storage::string::String>>::try_push_back>
   366d2:	41 89 c5             	mov    %eax,%r13d
   366d5:	3c ff                	cmp    $0xff,%al
   366d7:	0f 85 21 16 00 00    	jne    37cfe <oriole_expat::dispatch+0x3e8e>
   366dd:	4c 89 f7             	mov    %r14,%rdi
   366e0:	e8 7b ca ff ff       	call   33160 <oriole_expat::drain_default_fragments>
   366e5:	e9 af 0d 00 00       	jmp    37499 <oriole_expat::dispatch+0x3629>
   366ea:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   366f1:	00 
   366f2:	48 8b 94 24 60 01 00 	mov    0x160(%rsp),%rdx
   366f9:	00 
   366fa:	41 0f 10 46 08       	movups 0x8(%r14),%xmm0
   366ff:	41 0f 10 4e 18       	movups 0x18(%r14),%xmm1
   36704:	0f 29 8c 24 d0 01 00 	movaps %xmm1,0x1d0(%rsp)
   3670b:	00 
   3670c:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
   36713:	00 
   36714:	b0 01                	mov    $0x1,%al
   36716:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3671a:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   36721:	00 
   36722:	48 8d 8c 24 c0 01 00 	lea    0x1c0(%rsp),%rcx
   36729:	00 
   3672a:	b0 01                	mov    $0x1,%al
   3672c:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36730:	b3 01                	mov    $0x1,%bl
   36732:	41 b5 01             	mov    $0x1,%r13b
   36735:	41 b7 01             	mov    $0x1,%r15b
   36738:	ff 15 3a 02 0b 00    	call   *0xb023a(%rip)        # e6978 <_GLOBAL_OFFSET_TABLE_+0x200>
   3673e:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   36745:	00 
   36746:	0f b6 8c 24 e8 02 00 	movzbl 0x2e8(%rsp),%ecx
   3674d:	00 
   3674e:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   36752:	0f 84 6b 15 00 00    	je     37cc3 <oriole_expat::dispatch+0x3e53>
   36758:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   3675f:	00 
   36760:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   36767:	00 
   36768:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   3676f:	00 
   36770:	0f 11 94 24 18 01 00 	movups %xmm2,0x118(%rsp)
   36777:	00 
   36778:	0f 11 8c 24 09 01 00 	movups %xmm1,0x109(%rsp)
   3677f:	00 
   36780:	0f 11 84 24 f9 00 00 	movups %xmm0,0xf9(%rsp)
   36787:	00 
   36788:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
   3678f:	00 
   36790:	88 8c 24 f8 00 00 00 	mov    %cl,0xf8(%rsp)
   36797:	48 8b 84 24 00 05 00 	mov    0x500(%rsp),%rax
   3679e:	00 
   3679f:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   367a6:	00 
   367a7:	0f 28 84 24 d0 04 00 	movaps 0x4d0(%rsp),%xmm0
   367ae:	00 
   367af:	0f 28 8c 24 e0 04 00 	movaps 0x4e0(%rsp),%xmm1
   367b6:	00 
   367b7:	0f 28 94 24 f0 04 00 	movaps 0x4f0(%rsp),%xmm2
   367be:	00 
   367bf:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   367c6:	00 
   367c7:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   367ce:	00 
   367cf:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   367d6:	00 
   367d7:	b0 01                	mov    $0x1,%al
   367d9:	89 44 24 40          	mov    %eax,0x40(%rsp)
   367dd:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   367e4:	00 
   367e5:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   367ec:	00 
   367ed:	b3 01                	mov    $0x1,%bl
   367ef:	ff 15 8b 01 0b 00    	call   *0xb018b(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   367f5:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   367fc:	00 
   367fd:	0f b6 8c 24 c8 01 00 	movzbl 0x1c8(%rsp),%ecx
   36804:	00 
   36805:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   36809:	0f 84 5c 1a 00 00    	je     3826b <oriole_expat::dispatch+0x43fb>
   3680f:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   36816:	00 
   36817:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   3681e:	00 
   3681f:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   36826:	00 
   36827:	0f 11 94 24 98 00 00 	movups %xmm2,0x98(%rsp)
   3682e:	00 
   3682f:	0f 11 8c 24 89 00 00 	movups %xmm1,0x89(%rsp)
   36836:	00 
   36837:	0f 11 44 24 79       	movups %xmm0,0x79(%rsp)
   3683c:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   36841:	88 4c 24 78          	mov    %cl,0x78(%rsp)
   36845:	83 bc 24 98 04 00 00 	cmpl   $0xffffffff,0x498(%rsp)
   3684c:	ff 
   3684d:	0f 84 01 1c 00 00    	je     38454 <oriole_expat::dispatch+0x45e4>
   36853:	4c 8b ac 24 b8 04 00 	mov    0x4b8(%rsp),%r13
   3685a:	00 
   3685b:	e9 f7 1b 00 00       	jmp    38457 <oriole_expat::dispatch+0x45e7>
   36860:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   36867:	00 
   36868:	48 85 c9             	test   %rcx,%rcx
   3686b:	0f 84 2b 18 00 00    	je     3809c <oriole_expat::dispatch+0x422c>
   36871:	b0 01                	mov    $0x1,%al
   36873:	89 44 24 50          	mov    %eax,0x50(%rsp)
   36877:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   3687e:	00 
   3687f:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   36886:	00 
   36887:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   3688c:	ba 01 00 00 00       	mov    $0x1,%edx
   36891:	b0 01                	mov    $0x1,%al
   36893:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36897:	b0 01                	mov    $0x1,%al
   36899:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3689d:	b0 01                	mov    $0x1,%al
   3689f:	89 44 24 48          	mov    %eax,0x48(%rsp)
   368a3:	b0 01                	mov    $0x1,%al
   368a5:	89 44 24 14          	mov    %eax,0x14(%rsp)
   368a9:	b0 01                	mov    $0x1,%al
   368ab:	89 44 24 30          	mov    %eax,0x30(%rsp)
   368af:	b0 01                	mov    $0x1,%al
   368b1:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   368b5:	b0 01                	mov    $0x1,%al
   368b7:	89 44 24 08          	mov    %eax,0x8(%rsp)
   368bb:	b0 01                	mov    $0x1,%al
   368bd:	89 44 24 28          	mov    %eax,0x28(%rsp)
   368c1:	b0 01                	mov    $0x1,%al
   368c3:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   368c8:	b0 01                	mov    $0x1,%al
   368ca:	89 44 24 10          	mov    %eax,0x10(%rsp)
   368ce:	40 b5 01             	mov    $0x1,%bpl
   368d1:	41 b7 01             	mov    $0x1,%r15b
   368d4:	41 b4 01             	mov    $0x1,%r12b
   368d7:	41 b5 01             	mov    $0x1,%r13b
   368da:	ff 15 d0 ff 0a 00    	call   *0xaffd0(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   368e0:	31 db                	xor    %ebx,%ebx
   368e2:	e9 b7 17 00 00       	jmp    3809e <oriole_expat::dispatch+0x422e>
   368e7:	31 db                	xor    %ebx,%ebx
   368e9:	e9 ae 18 00 00       	jmp    3819c <oriole_expat::dispatch+0x432c>
   368ee:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   368f5:	00 
   368f6:	48 85 c9             	test   %rcx,%rcx
   368f9:	74 18                	je     36913 <oriole_expat::dispatch+0x2aa3>
   368fb:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   36902:	00 
   36903:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   36908:	ba 01 00 00 00       	mov    $0x1,%edx
   3690d:	ff 15 9d ff 0a 00    	call   *0xaff9d(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36913:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   3691a:	00 
   3691b:	48 85 c9             	test   %rcx,%rcx
   3691e:	0f 84 e2 17 00 00    	je     38106 <oriole_expat::dispatch+0x4296>
   36924:	b0 01                	mov    $0x1,%al
   36926:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3692a:	45 31 e4             	xor    %r12d,%r12d
   3692d:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   36934:	00 
   36935:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   3693c:	00 
   3693d:	ba 01 00 00 00       	mov    $0x1,%edx
   36942:	b0 01                	mov    $0x1,%al
   36944:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36948:	b0 01                	mov    $0x1,%al
   3694a:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3694e:	b0 01                	mov    $0x1,%al
   36950:	89 44 24 50          	mov    %eax,0x50(%rsp)
   36954:	b0 01                	mov    $0x1,%al
   36956:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3695a:	b0 01                	mov    $0x1,%al
   3695c:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36960:	b0 01                	mov    $0x1,%al
   36962:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36966:	b0 01                	mov    $0x1,%al
   36968:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3696c:	b0 01                	mov    $0x1,%al
   3696e:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36972:	b0 01                	mov    $0x1,%al
   36974:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36978:	b0 01                	mov    $0x1,%al
   3697a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3697f:	b0 01                	mov    $0x1,%al
   36981:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36985:	40 b5 01             	mov    $0x1,%bpl
   36988:	41 b7 01             	mov    $0x1,%r15b
   3698b:	41 b5 01             	mov    $0x1,%r13b
   3698e:	ff 15 1c ff 0a 00    	call   *0xaff1c(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36994:	31 db                	xor    %ebx,%ebx
   36996:	e9 6d 17 00 00       	jmp    38108 <oriole_expat::dispatch+0x4298>
   3699b:	31 c0                	xor    %eax,%eax
   3699d:	e9 ae 0b 00 00       	jmp    37550 <oriole_expat::dispatch+0x36e0>
   369a2:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   369a9:	00 
   369aa:	48 85 c9             	test   %rcx,%rcx
   369ad:	74 1b                	je     369ca <oriole_expat::dispatch+0x2b5a>
   369af:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   369b6:	00 
   369b7:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   369be:	00 
   369bf:	ba 01 00 00 00       	mov    $0x1,%edx
   369c4:	ff 15 e6 fe 0a 00    	call   *0xafee6(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   369ca:	48 8b 8c 24 98 01 00 	mov    0x198(%rsp),%rcx
   369d1:	00 
   369d2:	48 85 c9             	test   %rcx,%rcx
   369d5:	0f 84 78 17 00 00    	je     38153 <oriole_expat::dispatch+0x42e3>
   369db:	b0 01                	mov    $0x1,%al
   369dd:	89 44 24 50          	mov    %eax,0x50(%rsp)
   369e1:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   369e8:	00 
   369e9:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
   369f0:	00 
   369f1:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   369f8:	00 
   369f9:	ba 01 00 00 00       	mov    $0x1,%edx
   369fe:	b0 01                	mov    $0x1,%al
   36a00:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36a04:	b0 01                	mov    $0x1,%al
   36a06:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36a0a:	b0 01                	mov    $0x1,%al
   36a0c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36a10:	b0 01                	mov    $0x1,%al
   36a12:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36a16:	b0 01                	mov    $0x1,%al
   36a18:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36a1c:	b0 01                	mov    $0x1,%al
   36a1e:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36a22:	b0 01                	mov    $0x1,%al
   36a24:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36a28:	b0 01                	mov    $0x1,%al
   36a2a:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36a2e:	b0 01                	mov    $0x1,%al
   36a30:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   36a35:	b0 01                	mov    $0x1,%al
   36a37:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36a3b:	40 b5 01             	mov    $0x1,%bpl
   36a3e:	41 b7 01             	mov    $0x1,%r15b
   36a41:	41 b4 01             	mov    $0x1,%r12b
   36a44:	41 b5 01             	mov    $0x1,%r13b
   36a47:	ff 15 63 fe 0a 00    	call   *0xafe63(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36a4d:	31 db                	xor    %ebx,%ebx
   36a4f:	e9 01 17 00 00       	jmp    38155 <oriole_expat::dispatch+0x42e5>
   36a54:	b0 01                	mov    $0x1,%al
   36a56:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36a5a:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
   36a61:	00 
   36a62:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   36a69:	00 
   36a6a:	b0 01                	mov    $0x1,%al
   36a6c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36a70:	b0 01                	mov    $0x1,%al
   36a72:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36a76:	b0 01                	mov    $0x1,%al
   36a78:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36a7c:	b0 01                	mov    $0x1,%al
   36a7e:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36a82:	b0 01                	mov    $0x1,%al
   36a84:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36a88:	b0 01                	mov    $0x1,%al
   36a8a:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36a8e:	b0 01                	mov    $0x1,%al
   36a90:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36a94:	b0 01                	mov    $0x1,%al
   36a96:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36a9a:	b0 01                	mov    $0x1,%al
   36a9c:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   36aa1:	b0 01                	mov    $0x1,%al
   36aa3:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36aa7:	40 b5 01             	mov    $0x1,%bpl
   36aaa:	41 b7 01             	mov    $0x1,%r15b
   36aad:	41 b4 01             	mov    $0x1,%r12b
   36ab0:	41 b5 01             	mov    $0x1,%r13b
   36ab3:	e8 d8 b7 ff ff       	call   32290 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   36ab8:	b0 01                	mov    $0x1,%al
   36aba:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36abe:	b0 01                	mov    $0x1,%al
   36ac0:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36ac4:	b0 01                	mov    $0x1,%al
   36ac6:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36aca:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
   36ad1:	00 
   36ad2:	b0 01                	mov    $0x1,%al
   36ad4:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36ad8:	b0 01                	mov    $0x1,%al
   36ada:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36ade:	b0 01                	mov    $0x1,%al
   36ae0:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36ae4:	b0 01                	mov    $0x1,%al
   36ae6:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36aea:	b0 01                	mov    $0x1,%al
   36aec:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36af0:	b0 01                	mov    $0x1,%al
   36af2:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36af6:	b0 01                	mov    $0x1,%al
   36af8:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36afc:	b0 01                	mov    $0x1,%al
   36afe:	89 44 24 18          	mov    %eax,0x18(%rsp)
   36b02:	b0 01                	mov    $0x1,%al
   36b04:	89 44 24 20          	mov    %eax,0x20(%rsp)
   36b08:	b0 01                	mov    $0x1,%al
   36b0a:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   36b0e:	e9 d8 eb ff ff       	jmp    356eb <oriole_expat::dispatch+0x187b>
   36b13:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   36b18:	e8 23 88 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36b1d:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   36b24:	00 
   36b25:	48 85 c9             	test   %rcx,%rcx
   36b28:	0f 84 42 16 00 00    	je     38170 <oriole_expat::dispatch+0x4300>
   36b2e:	b0 01                	mov    $0x1,%al
   36b30:	89 44 24 50          	mov    %eax,0x50(%rsp)
   36b34:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   36b3b:	00 
   36b3c:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   36b43:	00 
   36b44:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   36b4b:	00 
   36b4c:	ba 01 00 00 00       	mov    $0x1,%edx
   36b51:	b0 01                	mov    $0x1,%al
   36b53:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36b57:	b0 01                	mov    $0x1,%al
   36b59:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36b5d:	b0 01                	mov    $0x1,%al
   36b5f:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36b63:	b0 01                	mov    $0x1,%al
   36b65:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36b69:	b0 01                	mov    $0x1,%al
   36b6b:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36b6f:	b0 01                	mov    $0x1,%al
   36b71:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36b75:	b0 01                	mov    $0x1,%al
   36b77:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36b7b:	b0 01                	mov    $0x1,%al
   36b7d:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36b81:	b0 01                	mov    $0x1,%al
   36b83:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   36b88:	b0 01                	mov    $0x1,%al
   36b8a:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36b8e:	40 b5 01             	mov    $0x1,%bpl
   36b91:	41 b7 01             	mov    $0x1,%r15b
   36b94:	41 b4 01             	mov    $0x1,%r12b
   36b97:	41 b5 01             	mov    $0x1,%r13b
   36b9a:	ff 15 10 fd 0a 00    	call   *0xafd10(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36ba0:	31 db                	xor    %ebx,%ebx
   36ba2:	e9 1e 17 00 00       	jmp    382c5 <oriole_expat::dispatch+0x4455>
   36ba7:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   36bac:	e8 8f 87 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36bb1:	b0 01                	mov    $0x1,%al
   36bb3:	89 44 24 50          	mov    %eax,0x50(%rsp)
   36bb7:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   36bbe:	00 
   36bbf:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   36bc6:	00 
   36bc7:	b0 01                	mov    $0x1,%al
   36bc9:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36bcd:	b0 01                	mov    $0x1,%al
   36bcf:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36bd3:	b0 01                	mov    $0x1,%al
   36bd5:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36bd9:	b0 01                	mov    $0x1,%al
   36bdb:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36bdf:	b0 01                	mov    $0x1,%al
   36be1:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36be5:	b0 01                	mov    $0x1,%al
   36be7:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36beb:	b0 01                	mov    $0x1,%al
   36bed:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36bf1:	b0 01                	mov    $0x1,%al
   36bf3:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36bf7:	b0 01                	mov    $0x1,%al
   36bf9:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   36bfe:	b0 01                	mov    $0x1,%al
   36c00:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36c04:	40 b5 01             	mov    $0x1,%bpl
   36c07:	41 b7 01             	mov    $0x1,%r15b
   36c0a:	41 b4 01             	mov    $0x1,%r12b
   36c0d:	41 b5 01             	mov    $0x1,%r13b
   36c10:	e8 2b 87 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36c15:	e9 77 1b 00 00       	jmp    38791 <oriole_expat::dispatch+0x4921>
   36c1a:	b0 01                	mov    $0x1,%al
   36c1c:	89 44 24 50          	mov    %eax,0x50(%rsp)
   36c20:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
   36c27:	00 00 
   36c29:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   36c2e:	b0 01                	mov    $0x1,%al
   36c30:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36c34:	b0 01                	mov    $0x1,%al
   36c36:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36c3a:	b0 01                	mov    $0x1,%al
   36c3c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36c40:	b0 01                	mov    $0x1,%al
   36c42:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36c46:	b0 01                	mov    $0x1,%al
   36c48:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36c4c:	b0 01                	mov    $0x1,%al
   36c4e:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36c52:	b0 01                	mov    $0x1,%al
   36c54:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36c58:	b0 01                	mov    $0x1,%al
   36c5a:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36c5e:	b0 01                	mov    $0x1,%al
   36c60:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36c64:	b0 01                	mov    $0x1,%al
   36c66:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36c6a:	40 b5 01             	mov    $0x1,%bpl
   36c6d:	41 b7 01             	mov    $0x1,%r15b
   36c70:	41 b4 01             	mov    $0x1,%r12b
   36c73:	41 b5 01             	mov    $0x1,%r13b
   36c76:	e8 c5 86 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36c7b:	e9 77 11 00 00       	jmp    37df7 <oriole_expat::dispatch+0x3f87>
   36c80:	41 0f b6 9e 60 0b 00 	movzbl 0xb60(%r14),%ebx
   36c87:	00 
   36c88:	41 c6 86 60 0b 00 00 	movb   $0x0,0xb60(%r14)
   36c8f:	00 
   36c90:	e9 f6 e9 ff ff       	jmp    3568b <oriole_expat::dispatch+0x181b>
   36c95:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   36c9c:	00 
   36c9d:	48 85 c9             	test   %rcx,%rcx
   36ca0:	74 1b                	je     36cbd <oriole_expat::dispatch+0x2e4d>
   36ca2:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   36ca9:	00 
   36caa:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   36cb1:	00 
   36cb2:	ba 01 00 00 00       	mov    $0x1,%edx
   36cb7:	ff 15 f3 fb 0a 00    	call   *0xafbf3(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36cbd:	b0 01                	mov    $0x1,%al
   36cbf:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36cc3:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   36cca:	00 
   36ccb:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   36cd2:	00 
   36cd3:	b0 01                	mov    $0x1,%al
   36cd5:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36cd9:	b0 01                	mov    $0x1,%al
   36cdb:	89 44 24 50          	mov    %eax,0x50(%rsp)
   36cdf:	b0 01                	mov    $0x1,%al
   36ce1:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36ce5:	b0 01                	mov    $0x1,%al
   36ce7:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36ceb:	b0 01                	mov    $0x1,%al
   36ced:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36cf1:	b0 01                	mov    $0x1,%al
   36cf3:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36cf7:	b0 01                	mov    $0x1,%al
   36cf9:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36cfd:	b0 01                	mov    $0x1,%al
   36cff:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36d03:	b0 01                	mov    $0x1,%al
   36d05:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   36d0a:	b0 01                	mov    $0x1,%al
   36d0c:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36d10:	40 b5 01             	mov    $0x1,%bpl
   36d13:	41 b7 01             	mov    $0x1,%r15b
   36d16:	41 b4 01             	mov    $0x1,%r12b
   36d19:	41 b5 01             	mov    $0x1,%r13b
   36d1c:	e8 1f 86 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36d21:	e9 17 12 00 00       	jmp    37f3d <oriole_expat::dispatch+0x40cd>
   36d26:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36d2a:	b0 01                	mov    $0x1,%al
   36d2c:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36d30:	b0 01                	mov    $0x1,%al
   36d32:	89 44 24 50          	mov    %eax,0x50(%rsp)
   36d36:	b0 01                	mov    $0x1,%al
   36d38:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36d3c:	b0 01                	mov    $0x1,%al
   36d3e:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36d42:	b0 01                	mov    $0x1,%al
   36d44:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36d48:	b0 01                	mov    $0x1,%al
   36d4a:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36d4e:	b0 01                	mov    $0x1,%al
   36d50:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36d54:	b0 01                	mov    $0x1,%al
   36d56:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36d5a:	b1 01                	mov    $0x1,%cl
   36d5c:	b2 01                	mov    $0x1,%dl
   36d5e:	b0 01                	mov    $0x1,%al
   36d60:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36d64:	b0 01                	mov    $0x1,%al
   36d66:	89 44 24 24          	mov    %eax,0x24(%rsp)
   36d6a:	b0 01                	mov    $0x1,%al
   36d6c:	89 44 24 18          	mov    %eax,0x18(%rsp)
   36d70:	b0 01                	mov    $0x1,%al
   36d72:	89 44 24 20          	mov    %eax,0x20(%rsp)
   36d76:	b0 01                	mov    $0x1,%al
   36d78:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   36d7c:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
   36d81:	89 4c 24 28          	mov    %ecx,0x28(%rsp)
   36d85:	83 bc 24 98 04 00 00 	cmpl   $0xffffffff,0x498(%rsp)
   36d8c:	ff 
   36d8d:	0f 85 1d 07 00 00    	jne    374b0 <oriole_expat::dispatch+0x3640>
   36d93:	e9 40 07 00 00       	jmp    374d8 <oriole_expat::dispatch+0x3668>
   36d98:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   36d9f:	00 
   36da0:	48 85 c9             	test   %rcx,%rcx
   36da3:	0f 84 0a 13 00 00    	je     380b3 <oriole_expat::dispatch+0x4243>
   36da9:	b0 01                	mov    $0x1,%al
   36dab:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36daf:	45 31 ed             	xor    %r13d,%r13d
   36db2:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   36db9:	00 
   36dba:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   36dbf:	ba 01 00 00 00       	mov    $0x1,%edx
   36dc4:	b0 01                	mov    $0x1,%al
   36dc6:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36dca:	b0 01                	mov    $0x1,%al
   36dcc:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36dd0:	b0 01                	mov    $0x1,%al
   36dd2:	89 44 24 50          	mov    %eax,0x50(%rsp)
   36dd6:	b0 01                	mov    $0x1,%al
   36dd8:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36ddc:	b0 01                	mov    $0x1,%al
   36dde:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36de2:	b0 01                	mov    $0x1,%al
   36de4:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36de8:	b0 01                	mov    $0x1,%al
   36dea:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36dee:	b0 01                	mov    $0x1,%al
   36df0:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36df4:	b0 01                	mov    $0x1,%al
   36df6:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36dfa:	b0 01                	mov    $0x1,%al
   36dfc:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   36e01:	b0 01                	mov    $0x1,%al
   36e03:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36e07:	40 b5 01             	mov    $0x1,%bpl
   36e0a:	41 b7 01             	mov    $0x1,%r15b
   36e0d:	41 b4 01             	mov    $0x1,%r12b
   36e10:	ff 15 9a fa 0a 00    	call   *0xafa9a(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36e16:	31 db                	xor    %ebx,%ebx
   36e18:	e9 98 12 00 00       	jmp    380b5 <oriole_expat::dispatch+0x4245>
   36e1d:	41 80 be 21 08 00 00 	cmpb   $0x1,0x821(%r14)
   36e24:	01 
   36e25:	75 08                	jne    36e2f <oriole_expat::dispatch+0x2fbf>
   36e27:	41 c6 86 21 08 00 00 	movb   $0x2,0x821(%r14)
   36e2e:	02 
   36e2f:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   36e36:	00 
   36e37:	e8 04 85 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36e3c:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   36e43:	00 
   36e44:	e8 f7 84 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36e49:	b0 01                	mov    $0x1,%al
   36e4b:	89 44 24 50          	mov    %eax,0x50(%rsp)
   36e4f:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   36e56:	00 
   36e57:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   36e5e:	00 
   36e5f:	b0 01                	mov    $0x1,%al
   36e61:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36e65:	b0 01                	mov    $0x1,%al
   36e67:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36e6b:	b0 01                	mov    $0x1,%al
   36e6d:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36e71:	b0 01                	mov    $0x1,%al
   36e73:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36e77:	b0 01                	mov    $0x1,%al
   36e79:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36e7d:	b0 01                	mov    $0x1,%al
   36e7f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36e83:	b0 01                	mov    $0x1,%al
   36e85:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36e89:	b0 01                	mov    $0x1,%al
   36e8b:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36e8f:	b0 01                	mov    $0x1,%al
   36e91:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   36e96:	b0 01                	mov    $0x1,%al
   36e98:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36e9c:	40 b5 01             	mov    $0x1,%bpl
   36e9f:	41 b7 01             	mov    $0x1,%r15b
   36ea2:	41 b4 01             	mov    $0x1,%r12b
   36ea5:	41 b5 01             	mov    $0x1,%r13b
   36ea8:	e8 93 84 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36ead:	31 db                	xor    %ebx,%ebx
   36eaf:	b0 01                	mov    $0x1,%al
   36eb1:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   36eb8:	00 
   36eb9:	b1 01                	mov    $0x1,%cl
   36ebb:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   36ebf:	b1 01                	mov    $0x1,%cl
   36ec1:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   36ec5:	b1 01                	mov    $0x1,%cl
   36ec7:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   36ecb:	b1 01                	mov    $0x1,%cl
   36ecd:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   36ed1:	b1 01                	mov    $0x1,%cl
   36ed3:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   36ed7:	e9 d5 e7 ff ff       	jmp    356b1 <oriole_expat::dispatch+0x1841>
   36edc:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   36ee3:	00 
   36ee4:	e8 57 84 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36ee9:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   36ef0:	00 
   36ef1:	e8 4a 84 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36ef6:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   36efd:	00 
   36efe:	48 85 c9             	test   %rcx,%rcx
   36f01:	0f 84 70 12 00 00    	je     38177 <oriole_expat::dispatch+0x4307>
   36f07:	b0 01                	mov    $0x1,%al
   36f09:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36f0d:	45 31 ff             	xor    %r15d,%r15d
   36f10:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   36f17:	00 
   36f18:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   36f1f:	00 
   36f20:	ba 01 00 00 00       	mov    $0x1,%edx
   36f25:	b0 01                	mov    $0x1,%al
   36f27:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36f2b:	b0 01                	mov    $0x1,%al
   36f2d:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36f31:	b0 01                	mov    $0x1,%al
   36f33:	89 44 24 50          	mov    %eax,0x50(%rsp)
   36f37:	b0 01                	mov    $0x1,%al
   36f39:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36f3d:	b0 01                	mov    $0x1,%al
   36f3f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36f43:	b0 01                	mov    $0x1,%al
   36f45:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36f49:	b0 01                	mov    $0x1,%al
   36f4b:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36f4f:	b0 01                	mov    $0x1,%al
   36f51:	89 44 24 08          	mov    %eax,0x8(%rsp)
   36f55:	b0 01                	mov    $0x1,%al
   36f57:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36f5b:	b0 01                	mov    $0x1,%al
   36f5d:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   36f62:	b0 01                	mov    $0x1,%al
   36f64:	89 44 24 10          	mov    %eax,0x10(%rsp)
   36f68:	40 b5 01             	mov    $0x1,%bpl
   36f6b:	41 b4 01             	mov    $0x1,%r12b
   36f6e:	41 b5 01             	mov    $0x1,%r13b
   36f71:	ff 15 39 f9 0a 00    	call   *0xaf939(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   36f77:	31 db                	xor    %ebx,%ebx
   36f79:	e9 e4 1e 00 00       	jmp    38e62 <oriole_expat::dispatch+0x4ff2>
   36f7e:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   36f85:	00 
   36f86:	e8 b5 83 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36f8b:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   36f92:	00 
   36f93:	e8 a8 83 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   36f98:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   36f9f:	00 
   36fa0:	48 85 c9             	test   %rcx,%rcx
   36fa3:	0f 84 d5 11 00 00    	je     3817e <oriole_expat::dispatch+0x430e>
   36fa9:	b0 01                	mov    $0x1,%al
   36fab:	89 44 24 50          	mov    %eax,0x50(%rsp)
   36faf:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   36fb6:	00 
   36fb7:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   36fbe:	00 
   36fbf:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   36fc6:	00 
   36fc7:	ba 01 00 00 00       	mov    $0x1,%edx
   36fcc:	b0 01                	mov    $0x1,%al
   36fce:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   36fd2:	b0 01                	mov    $0x1,%al
   36fd4:	89 44 24 40          	mov    %eax,0x40(%rsp)
   36fd8:	b0 01                	mov    $0x1,%al
   36fda:	89 44 24 38          	mov    %eax,0x38(%rsp)
   36fde:	b0 01                	mov    $0x1,%al
   36fe0:	89 44 24 48          	mov    %eax,0x48(%rsp)
   36fe4:	b0 01                	mov    $0x1,%al
   36fe6:	89 44 24 14          	mov    %eax,0x14(%rsp)
   36fea:	b0 01                	mov    $0x1,%al
   36fec:	89 44 24 30          	mov    %eax,0x30(%rsp)
   36ff0:	b0 01                	mov    $0x1,%al
   36ff2:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   36ff6:	b0 01                	mov    $0x1,%al
   36ff8:	89 44 24 28          	mov    %eax,0x28(%rsp)
   36ffc:	b0 01                	mov    $0x1,%al
   36ffe:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   37003:	b0 01                	mov    $0x1,%al
   37005:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37009:	40 b5 01             	mov    $0x1,%bpl
   3700c:	41 b7 01             	mov    $0x1,%r15b
   3700f:	41 b4 01             	mov    $0x1,%r12b
   37012:	41 b5 01             	mov    $0x1,%r13b
   37015:	ff 15 95 f8 0a 00    	call   *0xaf895(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3701b:	31 db                	xor    %ebx,%ebx
   3701d:	e9 14 21 00 00       	jmp    39136 <oriole_expat::dispatch+0x52c6>
   37022:	40 b5 01             	mov    $0x1,%bpl
   37025:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   3702c:	00 
   3702d:	41 b5 01             	mov    $0x1,%r13b
   37030:	e8 0b 83 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37035:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3703c:	00 
   3703d:	48 85 c9             	test   %rcx,%rcx
   37040:	74 1e                	je     37060 <oriole_expat::dispatch+0x31f0>
   37042:	41 b5 01             	mov    $0x1,%r13b
   37045:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   3704c:	00 
   3704d:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   37054:	00 
   37055:	ba 01 00 00 00       	mov    $0x1,%edx
   3705a:	ff 15 50 f8 0a 00    	call   *0xaf850(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37060:	48 8b 8c 24 48 04 00 	mov    0x448(%rsp),%rcx
   37067:	00 
   37068:	48 85 c9             	test   %rcx,%rcx
   3706b:	74 1b                	je     37088 <oriole_expat::dispatch+0x3218>
   3706d:	48 8b b4 24 40 04 00 	mov    0x440(%rsp),%rsi
   37074:	00 
   37075:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   3707c:	00 
   3707d:	ba 01 00 00 00       	mov    $0x1,%edx
   37082:	ff 15 28 f8 0a 00    	call   *0xaf828(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37088:	48 8b 8c 24 88 04 00 	mov    0x488(%rsp),%rcx
   3708f:	00 
   37090:	48 85 c9             	test   %rcx,%rcx
   37093:	0f 84 ec 10 00 00    	je     38185 <oriole_expat::dispatch+0x4315>
   37099:	b0 01                	mov    $0x1,%al
   3709b:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3709f:	31 ed                	xor    %ebp,%ebp
   370a1:	48 8b b4 24 80 04 00 	mov    0x480(%rsp),%rsi
   370a8:	00 
   370a9:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
   370b0:	00 
   370b1:	ba 01 00 00 00       	mov    $0x1,%edx
   370b6:	b0 01                	mov    $0x1,%al
   370b8:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   370bc:	b0 01                	mov    $0x1,%al
   370be:	89 44 24 40          	mov    %eax,0x40(%rsp)
   370c2:	b0 01                	mov    $0x1,%al
   370c4:	89 44 24 50          	mov    %eax,0x50(%rsp)
   370c8:	b0 01                	mov    $0x1,%al
   370ca:	89 44 24 48          	mov    %eax,0x48(%rsp)
   370ce:	b0 01                	mov    $0x1,%al
   370d0:	89 44 24 14          	mov    %eax,0x14(%rsp)
   370d4:	b0 01                	mov    $0x1,%al
   370d6:	89 44 24 30          	mov    %eax,0x30(%rsp)
   370da:	b0 01                	mov    $0x1,%al
   370dc:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   370e0:	b0 01                	mov    $0x1,%al
   370e2:	89 44 24 08          	mov    %eax,0x8(%rsp)
   370e6:	b0 01                	mov    $0x1,%al
   370e8:	89 44 24 28          	mov    %eax,0x28(%rsp)
   370ec:	b0 01                	mov    $0x1,%al
   370ee:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   370f3:	b0 01                	mov    $0x1,%al
   370f5:	89 44 24 10          	mov    %eax,0x10(%rsp)
   370f9:	41 b7 01             	mov    $0x1,%r15b
   370fc:	41 b4 01             	mov    $0x1,%r12b
   370ff:	41 b5 01             	mov    $0x1,%r13b
   37102:	ff 15 a8 f7 0a 00    	call   *0xaf7a8(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37108:	31 db                	xor    %ebx,%ebx
   3710a:	e9 9d 21 00 00       	jmp    392ac <oriole_expat::dispatch+0x543c>
   3710f:	48 39 0a             	cmp    %rcx,(%rdx)
   37112:	0f 94 c1             	sete   %cl
   37115:	89 4c 24 68          	mov    %ecx,0x68(%rsp)
   37119:	0f b6 8c 24 2e 01 00 	movzbl 0x12e(%rsp),%ecx
   37120:	00 
   37121:	08 8c 24 b0 01 00 00 	or     %cl,0x1b0(%rsp)
   37128:	48 89 94 24 b8 01 00 	mov    %rdx,0x1b8(%rsp)
   3712f:	00 
   37130:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
   37135:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   3713a:	0f b6 84 24 2f 01 00 	movzbl 0x12f(%rsp),%eax
   37141:	00 
   37142:	34 01                	xor    $0x1,%al
   37144:	20 84 24 10 04 00 00 	and    %al,0x410(%rsp)
   3714b:	4d 8d 7e 08          	lea    0x8(%r14),%r15
   3714f:	4c 8d ac 24 e9 02 00 	lea    0x2e9(%rsp),%r13
   37156:	00 
   37157:	48 8d ac 24 d9 05 00 	lea    0x5d9(%rsp),%rbp
   3715e:	00 
   3715f:	4c 8d 64 24 70       	lea    0x70(%rsp),%r12
   37164:	48 8d 1d b5 57 00 00 	lea    0x57b5(%rip),%rbx        # 3c920 <<oriole_expat::DtdFragments as core::iter::traits::iterator::Iterator>::next>
   3716b:	4c 89 e7             	mov    %r12,%rdi
   3716e:	ff d3                	call   *%rbx
   37170:	48 85 c0             	test   %rax,%rax
   37173:	0f 84 f0 02 00 00    	je     37469 <oriole_expat::dispatch+0x35f9>
   37179:	80 bc 24 b0 01 00 00 	cmpb   $0x0,0x1b0(%rsp)
   37180:	00 
   37181:	0f 84 97 00 00 00    	je     3721e <oriole_expat::dispatch+0x33ae>
   37187:	41 0f 10 07          	movups (%r15),%xmm0
   3718b:	41 0f 10 4f 10       	movups 0x10(%r15),%xmm1
   37190:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
   37197:	00 
   37198:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   3719f:	00 
   371a0:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   371a7:	00 
   371a8:	48 89 c6             	mov    %rax,%rsi
   371ab:	48 8d 8c 24 b0 00 00 	lea    0xb0(%rsp),%rcx
   371b2:	00 
   371b3:	ff 15 1f f7 0a 00    	call   *0xaf71f(%rip)        # e68d8 <_GLOBAL_OFFSET_TABLE_+0x160>
   371b9:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   371c0:	00 
   371c1:	0f b6 8c 24 e8 02 00 	movzbl 0x2e8(%rsp),%ecx
   371c8:	00 
   371c9:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   371cd:	0f 84 fb 0a 00 00    	je     37cce <oriole_expat::dispatch+0x3e5e>
   371d3:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
   371d8:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
   371dd:	41 0f 10 55 1f       	movups 0x1f(%r13),%xmm2
   371e2:	0f 11 55 1f          	movups %xmm2,0x1f(%rbp)
   371e6:	0f 11 4d 10          	movups %xmm1,0x10(%rbp)
   371ea:	0f 11 45 00          	movups %xmm0,0x0(%rbp)
   371ee:	48 89 84 24 d0 05 00 	mov    %rax,0x5d0(%rsp)
   371f5:	00 
   371f6:	88 8c 24 d8 05 00 00 	mov    %cl,0x5d8(%rsp)
   371fd:	49 8d be 20 0b 00 00 	lea    0xb20(%r14),%rdi
   37204:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
   3720b:	00 
   3720c:	e8 7f 4a 00 00       	call   3bc90 <<oriole_storage::queue::Queue<oriole_storage::string::String>>::try_push_back>
   37211:	3c ff                	cmp    $0xff,%al
   37213:	0f 84 52 ff ff ff    	je     3716b <oriole_expat::dispatch+0x32fb>
   37219:	e9 b5 0a 00 00       	jmp    37cd3 <oriole_expat::dispatch+0x3e63>
   3721e:	48 85 d2             	test   %rdx,%rdx
   37221:	0f 84 44 ff ff ff    	je     3716b <oriole_expat::dispatch+0x32fb>
   37227:	48 8d 0c 10          	lea    (%rax,%rdx,1),%rcx
   3722b:	48 89 c6             	mov    %rax,%rsi
   3722e:	eb 29                	jmp    37259 <oriole_expat::dispatch+0x33e9>
   37230:	40 0f b6 ff          	movzbl %dil,%edi
   37234:	4c 8d 05 91 d0 fd ff 	lea    -0x22f6f(%rip),%r8        # 142cc <core::unicode::unicode_data::white_space::WHITESPACE_MAP>
   3723b:	41 0f b6 3c 38       	movzbl (%r8,%rdi,1),%edi
   37240:	40 d0 ef             	shr    $1,%dil
   37243:	40 f6 c7 01          	test   $0x1,%dil
   37247:	0f 84 3f 01 00 00    	je     3738c <oriole_expat::dispatch+0x351c>
   3724d:	0f 1f 00             	nopl   (%rax)
   37250:	48 39 ce             	cmp    %rcx,%rsi
   37253:	0f 84 12 ff ff ff    	je     3716b <oriole_expat::dispatch+0x32fb>
   37259:	0f b6 3e             	movzbl (%rsi),%edi
   3725c:	40 84 ff             	test   %dil,%dil
   3725f:	78 1f                	js     37280 <oriole_expat::dispatch+0x3410>
   37261:	48 ff c6             	inc    %rsi
   37264:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   37268:	41 83 f8 05          	cmp    $0x5,%r8d
   3726c:	72 e2                	jb     37250 <oriole_expat::dispatch+0x33e0>
   3726e:	e9 ad 00 00 00       	jmp    37320 <oriole_expat::dispatch+0x34b0>
   37273:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   3727a:	84 00 00 00 00 00 
   37280:	41 89 f8             	mov    %edi,%r8d
   37283:	41 83 e0 1f          	and    $0x1f,%r8d
   37287:	44 0f b6 56 01       	movzbl 0x1(%rsi),%r10d
   3728c:	41 83 e2 3f          	and    $0x3f,%r10d
   37290:	40 80 ff df          	cmp    $0xdf,%dil
   37294:	76 43                	jbe    372d9 <oriole_expat::dispatch+0x3469>
   37296:	44 0f b6 4e 02       	movzbl 0x2(%rsi),%r9d
   3729b:	41 c1 e2 06          	shl    $0x6,%r10d
   3729f:	41 83 e1 3f          	and    $0x3f,%r9d
   372a3:	45 09 d1             	or     %r10d,%r9d
   372a6:	40 80 ff f0          	cmp    $0xf0,%dil
   372aa:	72 4b                	jb     372f7 <oriole_expat::dispatch+0x3487>
   372ac:	0f b6 7e 03          	movzbl 0x3(%rsi),%edi
   372b0:	48 83 c6 04          	add    $0x4,%rsi
   372b4:	41 83 e0 07          	and    $0x7,%r8d
   372b8:	41 c1 e0 12          	shl    $0x12,%r8d
   372bc:	41 c1 e1 06          	shl    $0x6,%r9d
   372c0:	83 e7 3f             	and    $0x3f,%edi
   372c3:	44 09 cf             	or     %r9d,%edi
   372c6:	44 09 c7             	or     %r8d,%edi
   372c9:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   372cd:	41 83 f8 05          	cmp    $0x5,%r8d
   372d1:	0f 82 79 ff ff ff    	jb     37250 <oriole_expat::dispatch+0x33e0>
   372d7:	eb 47                	jmp    37320 <oriole_expat::dispatch+0x34b0>
   372d9:	48 83 c6 02          	add    $0x2,%rsi
   372dd:	41 c1 e0 06          	shl    $0x6,%r8d
   372e1:	45 09 d0             	or     %r10d,%r8d
   372e4:	44 89 c7             	mov    %r8d,%edi
   372e7:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   372eb:	41 83 f8 05          	cmp    $0x5,%r8d
   372ef:	0f 82 5b ff ff ff    	jb     37250 <oriole_expat::dispatch+0x33e0>
   372f5:	eb 29                	jmp    37320 <oriole_expat::dispatch+0x34b0>
   372f7:	48 83 c6 03          	add    $0x3,%rsi
   372fb:	41 c1 e0 0c          	shl    $0xc,%r8d
   372ff:	45 09 c1             	or     %r8d,%r9d
   37302:	44 89 cf             	mov    %r9d,%edi
   37305:	44 8d 47 f7          	lea    -0x9(%rdi),%r8d
   37309:	41 83 f8 05          	cmp    $0x5,%r8d
   3730d:	0f 82 3d ff ff ff    	jb     37250 <oriole_expat::dispatch+0x33e0>
   37313:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   3731a:	84 00 00 00 00 00 
   37320:	83 ff 20             	cmp    $0x20,%edi
   37323:	0f 84 27 ff ff ff    	je     37250 <oriole_expat::dispatch+0x33e0>
   37329:	81 ff 85 00 00 00    	cmp    $0x85,%edi
   3732f:	72 5b                	jb     3738c <oriole_expat::dispatch+0x351c>
   37331:	41 89 f8             	mov    %edi,%r8d
   37334:	41 c1 e8 08          	shr    $0x8,%r8d
   37338:	41 83 f8 1f          	cmp    $0x1f,%r8d
   3733c:	7f 1a                	jg     37358 <oriole_expat::dispatch+0x34e8>
   3733e:	45 85 c0             	test   %r8d,%r8d
   37341:	74 34                	je     37377 <oriole_expat::dispatch+0x3507>
   37343:	41 83 f8 16          	cmp    $0x16,%r8d
   37347:	75 43                	jne    3738c <oriole_expat::dispatch+0x351c>
   37349:	81 ff 80 16 00 00    	cmp    $0x1680,%edi
   3734f:	40 0f 94 c7          	sete   %dil
   37353:	e9 eb fe ff ff       	jmp    37243 <oriole_expat::dispatch+0x33d3>
   37358:	41 83 f8 20          	cmp    $0x20,%r8d
   3735c:	0f 84 ce fe ff ff    	je     37230 <oriole_expat::dispatch+0x33c0>
   37362:	41 83 f8 30          	cmp    $0x30,%r8d
   37366:	75 24                	jne    3738c <oriole_expat::dispatch+0x351c>
   37368:	81 ff 00 30 00 00    	cmp    $0x3000,%edi
   3736e:	40 0f 94 c7          	sete   %dil
   37372:	e9 cc fe ff ff       	jmp    37243 <oriole_expat::dispatch+0x33d3>
   37377:	40 0f b6 ff          	movzbl %dil,%edi
   3737b:	4c 8d 05 4a cf fd ff 	lea    -0x230b6(%rip),%r8        # 142cc <core::unicode::unicode_data::white_space::WHITESPACE_MAP>
   37382:	41 0f b6 3c 38       	movzbl (%r8,%rdi,1),%edi
   37387:	e9 b7 fe ff ff       	jmp    37243 <oriole_expat::dispatch+0x33d3>
   3738c:	48 83 fa 01          	cmp    $0x1,%rdx
   37390:	74 1a                	je     373ac <oriole_expat::dispatch+0x353c>
   37392:	48 83 fa 08          	cmp    $0x8,%rdx
   37396:	75 1d                	jne    373b5 <oriole_expat::dispatch+0x3545>
   37398:	48 b9 3c 21 45 4e 54 	movabs $0x595449544e45213c,%rcx
   3739f:	49 54 59 
   373a2:	48 39 08             	cmp    %rcx,(%rax)
   373a5:	75 0e                	jne    373b5 <oriole_expat::dispatch+0x3545>
   373a7:	e9 bf fd ff ff       	jmp    3716b <oriole_expat::dispatch+0x32fb>
   373ac:	80 38 25             	cmpb   $0x25,(%rax)
   373af:	0f 84 b6 fd ff ff    	je     3716b <oriole_expat::dispatch+0x32fb>
   373b5:	f6 44 24 68 01       	testb  $0x1,0x68(%rsp)
   373ba:	74 0d                	je     373c9 <oriole_expat::dispatch+0x3559>
   373bc:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
   373c3:	00 
   373c4:	e9 be fd ff ff       	jmp    37187 <oriole_expat::dispatch+0x3317>
   373c9:	48 83 fa 01          	cmp    $0x1,%rdx
   373cd:	74 77                	je     37446 <oriole_expat::dispatch+0x35d6>
   373cf:	48 83 fa 06          	cmp    $0x6,%rdx
   373d3:	74 26                	je     373fb <oriole_expat::dispatch+0x358b>
   373d5:	48 83 fa 05          	cmp    $0x5,%rdx
   373d9:	75 e1                	jne    373bc <oriole_expat::dispatch+0x354c>
   373db:	8b 08                	mov    (%rax),%ecx
   373dd:	be 4e 44 41 54       	mov    $0x5441444e,%esi
   373e2:	31 f1                	xor    %esi,%ecx
   373e4:	0f b6 70 04          	movzbl 0x4(%rax),%esi
   373e8:	83 f6 41             	xor    $0x41,%esi
   373eb:	40 b7 01             	mov    $0x1,%dil
   373ee:	89 7c 24 68          	mov    %edi,0x68(%rsp)
   373f2:	09 ce                	or     %ecx,%esi
   373f4:	75 c6                	jne    373bc <oriole_expat::dispatch+0x354c>
   373f6:	e9 70 fd ff ff       	jmp    3716b <oriole_expat::dispatch+0x32fb>
   373fb:	8b 08                	mov    (%rax),%ecx
   373fd:	be 53 59 53 54       	mov    $0x54535953,%esi
   37402:	31 f1                	xor    %esi,%ecx
   37404:	0f b7 70 04          	movzwl 0x4(%rax),%esi
   37408:	81 f6 45 4d 00 00    	xor    $0x4d45,%esi
   3740e:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
   37415:	00 
   37416:	09 ce                	or     %ecx,%esi
   37418:	0f 84 4d fd ff ff    	je     3716b <oriole_expat::dispatch+0x32fb>
   3741e:	8b 08                	mov    (%rax),%ecx
   37420:	be 50 55 42 4c       	mov    $0x4c425550,%esi
   37425:	31 f1                	xor    %esi,%ecx
   37427:	0f b7 70 04          	movzwl 0x4(%rax),%esi
   3742b:	81 f6 49 43 00 00    	xor    $0x4349,%esi
   37431:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
   37438:	00 
   37439:	09 ce                	or     %ecx,%esi
   3743b:	0f 85 46 fd ff ff    	jne    37187 <oriole_expat::dispatch+0x3317>
   37441:	e9 25 fd ff ff       	jmp    3716b <oriole_expat::dispatch+0x32fb>
   37446:	80 38 3e             	cmpb   $0x3e,(%rax)
   37449:	0f 95 c1             	setne  %cl
   3744c:	0a 8c 24 10 04 00 00 	or     0x410(%rsp),%cl
   37453:	c7 44 24 68 00 00 00 	movl   $0x0,0x68(%rsp)
   3745a:	00 
   3745b:	f6 c1 01             	test   $0x1,%cl
   3745e:	0f 84 07 fd ff ff    	je     3716b <oriole_expat::dispatch+0x32fb>
   37464:	e9 1e fd ff ff       	jmp    37187 <oriole_expat::dispatch+0x3317>
   37469:	4c 89 f7             	mov    %r14,%rdi
   3746c:	e8 ef bc ff ff       	call   33160 <oriole_expat::drain_default_fragments>
   37471:	48 8b 8c 24 e8 01 00 	mov    0x1e8(%rsp),%rcx
   37478:	00 
   37479:	48 85 c9             	test   %rcx,%rcx
   3747c:	48 8b b4 24 b8 01 00 	mov    0x1b8(%rsp),%rsi
   37483:	00 
   37484:	74 13                	je     37499 <oriole_expat::dispatch+0x3629>
   37486:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   3748d:	00 
   3748e:	ba 01 00 00 00       	mov    $0x1,%edx
   37493:	ff 15 17 f4 0a 00    	call   *0xaf417(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37499:	b1 01                	mov    $0x1,%cl
   3749b:	b2 01                	mov    $0x1,%dl
   3749d:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
   374a2:	89 4c 24 28          	mov    %ecx,0x28(%rsp)
   374a6:	83 bc 24 98 04 00 00 	cmpl   $0xffffffff,0x498(%rsp)
   374ad:	ff 
   374ae:	74 28                	je     374d8 <oriole_expat::dispatch+0x3668>
   374b0:	48 8b 8c 24 c0 04 00 	mov    0x4c0(%rsp),%rcx
   374b7:	00 
   374b8:	48 85 c9             	test   %rcx,%rcx
   374bb:	74 1b                	je     374d8 <oriole_expat::dispatch+0x3668>
   374bd:	48 8b b4 24 b8 04 00 	mov    0x4b8(%rsp),%rsi
   374c4:	00 
   374c5:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
   374cc:	00 
   374cd:	ba 01 00 00 00       	mov    $0x1,%edx
   374d2:	ff 15 d8 f3 0a 00    	call   *0xaf3d8(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   374d8:	41 b5 ff             	mov    $0xff,%r13b
   374db:	e9 e6 16 00 00       	jmp    38bc6 <oriole_expat::dispatch+0x4d56>
   374e0:	4c 89 fe             	mov    %r15,%rsi
   374e3:	48 83 e6 fc          	and    $0xfffffffffffffffc,%rsi
   374e7:	49 8d bd d8 01 00 00 	lea    0x1d8(%r13),%rdi
   374ee:	31 d2                	xor    %edx,%edx
   374f0:	31 c0                	xor    %eax,%eax
   374f2:	44 0f b6 87 98 fe ff 	movzbl -0x168(%rdi),%r8d
   374f9:	ff 
   374fa:	49 01 c0             	add    %rax,%r8
   374fd:	0f b6 87 10 ff ff ff 	movzbl -0xf0(%rdi),%eax
   37504:	44 0f b6 4f 88       	movzbl -0x78(%rdi),%r9d
   37509:	49 01 c1             	add    %rax,%r9
   3750c:	4d 01 c1             	add    %r8,%r9
   3750f:	0f b6 07             	movzbl (%rdi),%eax
   37512:	4c 01 c8             	add    %r9,%rax
   37515:	48 83 c2 04          	add    $0x4,%rdx
   37519:	48 81 c7 e0 01 00 00 	add    $0x1e0,%rdi
   37520:	48 39 d6             	cmp    %rdx,%rsi
   37523:	75 cd                	jne    374f2 <oriole_expat::dispatch+0x3682>
   37525:	48 85 c9             	test   %rcx,%rcx
   37528:	74 26                	je     37550 <oriole_expat::dispatch+0x36e0>
   3752a:	48 6b d2 78          	imul   $0x78,%rdx,%rdx
   3752e:	4c 01 ea             	add    %r13,%rdx
   37531:	48 83 c2 70          	add    $0x70,%rdx
   37535:	48 6b c9 78          	imul   $0x78,%rcx,%rcx
   37539:	31 f6                	xor    %esi,%esi
   3753b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   37540:	0f b6 3c 32          	movzbl (%rdx,%rsi,1),%edi
   37544:	48 01 f8             	add    %rdi,%rax
   37547:	48 83 c6 78          	add    $0x78,%rsi
   3754b:	48 39 f1             	cmp    %rsi,%rcx
   3754e:	75 f0                	jne    37540 <oriole_expat::dispatch+0x36d0>
   37550:	48 01 c0             	add    %rax,%rax
   37553:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
   37559:	b9 ff ff ff 7f       	mov    $0x7fffffff,%ecx
   3755e:	48 0f 42 c8          	cmovb  %rax,%rcx
   37562:	41 89 8e 40 0a 00 00 	mov    %ecx,0xa40(%r14)
   37569:	48 85 ed             	test   %rbp,%rbp
   3756c:	0f 84 f7 00 00 00    	je     37669 <oriole_expat::dispatch+0x37f9>
   37572:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   37579:	00 
   3757a:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
   37581:	00 
   37582:	31 ff                	xor    %edi,%edi
   37584:	e8 57 53 00 00       	call   3c8e0 <core::slice::memchr::memchr>
   37589:	b3 03                	mov    $0x3,%bl
   3758b:	48 83 f8 01          	cmp    $0x1,%rax
   3758f:	0f 84 f8 20 00 00    	je     3968d <oriole_expat::dispatch+0x581d>
   37595:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   3759a:	31 f6                	xor    %esi,%esi
   3759c:	ff 15 5e f3 0a 00    	call   *0xaf35e(%rip)        # e6900 <_GLOBAL_OFFSET_TABLE_+0x188>
   375a2:	89 c3                	mov    %eax,%ebx
   375a4:	3c ff                	cmp    $0xff,%al
   375a6:	0f 85 e1 20 00 00    	jne    3968d <oriole_expat::dispatch+0x581d>
   375ac:	41 0f 10 46 08       	movups 0x8(%r14),%xmm0
   375b1:	41 0f 10 4e 18       	movups 0x18(%r14),%xmm1
   375b6:	0f 29 8c 24 d0 01 00 	movaps %xmm1,0x1d0(%rsp)
   375bd:	00 
   375be:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
   375c5:	00 
   375c6:	0f 57 c0             	xorps  %xmm0,%xmm0
   375c9:	0f 29 84 24 50 03 00 	movaps %xmm0,0x350(%rsp)
   375d0:	00 
   375d1:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   375d8:	00 
   375d9:	0f 29 84 24 30 03 00 	movaps %xmm0,0x330(%rsp)
   375e0:	00 
   375e1:	0f 29 84 24 20 03 00 	movaps %xmm0,0x320(%rsp)
   375e8:	00 
   375e9:	0f 29 84 24 10 03 00 	movaps %xmm0,0x310(%rsp)
   375f0:	00 
   375f1:	0f 29 84 24 00 03 00 	movaps %xmm0,0x300(%rsp)
   375f8:	00 
   375f9:	0f 29 84 24 f0 02 00 	movaps %xmm0,0x2f0(%rsp)
   37600:	00 
   37601:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   37608:	00 
   37609:	48 c7 84 24 60 03 00 	movq   $0x0,0x360(%rsp)
   37610:	00 00 00 00 00 
   37615:	48 c7 84 24 e0 01 00 	movq   $0x8,0x1e0(%rsp)
   3761c:	00 08 00 00 00 
   37621:	0f 11 84 24 e8 01 00 	movups %xmm0,0x1e8(%rsp)
   37628:	00 
   37629:	4b 8d 1c 3f          	lea    (%r15,%r15,1),%rbx
   3762d:	4a 8d 04 7d 01 00 00 	lea    0x1(,%r15,2),%rax
   37634:	00 
   37635:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   3763a:	48 83 fb 12          	cmp    $0x12,%rbx
   3763e:	0f 83 4c 16 00 00    	jae    38c90 <oriole_expat::dispatch+0x4e20>
   37644:	48 8d 84 24 e0 02 00 	lea    0x2e0(%rsp),%rax
   3764b:	00 
   3764c:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   37651:	b8 08 00 00 00       	mov    $0x8,%eax
   37656:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   3765b:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   37662:	00 00 
   37664:	e9 d4 16 00 00       	jmp    38d3d <oriole_expat::dispatch+0x4ecd>
   37669:	31 db                	xor    %ebx,%ebx
   3766b:	49 8d 7e 30          	lea    0x30(%r14),%rdi
   3766f:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   37676:	00 
   37677:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
   3767e:	00 
   3767f:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   37684:	0f 28 8c 24 80 00 00 	movaps 0x80(%rsp),%xmm1
   3768b:	00 
   3768c:	0f 28 94 24 90 00 00 	movaps 0x90(%rsp),%xmm2
   37693:	00 
   37694:	0f 29 94 24 e0 01 00 	movaps %xmm2,0x1e0(%rsp)
   3769b:	00 
   3769c:	0f 29 8c 24 d0 01 00 	movaps %xmm1,0x1d0(%rsp)
   376a3:	00 
   376a4:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
   376ab:	00 
   376ac:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
   376b3:	00 
   376b4:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   376bb:	00 
   376bc:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
   376c3:	00 
   376c4:	0f 28 8c 24 c0 00 00 	movaps 0xc0(%rsp),%xmm1
   376cb:	00 
   376cc:	0f 28 94 24 d0 00 00 	movaps 0xd0(%rsp),%xmm2
   376d3:	00 
   376d4:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   376db:	00 
   376dc:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   376e3:	00 
   376e4:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   376eb:	00 
   376ec:	48 8d 94 24 c0 01 00 	lea    0x1c0(%rsp),%rdx
   376f3:	00 
   376f4:	48 8d 8c 24 e0 02 00 	lea    0x2e0(%rsp),%rcx
   376fb:	00 
   376fc:	48 8b b4 24 08 05 00 	mov    0x508(%rsp),%rsi
   37703:	00 
   37704:	ff 15 56 f1 0a 00    	call   *0xaf156(%rip)        # e6860 <_GLOBAL_OFFSET_TABLE_+0xe8>
   3770a:	b0 01                	mov    $0x1,%al
   3770c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37710:	31 c0                	xor    %eax,%eax
   37712:	e9 48 0a 00 00       	jmp    3815f <oriole_expat::dispatch+0x42ef>
   37717:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   3771e:	00 
   3771f:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   37726:	00 
   37727:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   3772e:	00 
   3772f:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   37736:	00 
   37737:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   3773e:	00 
   3773f:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   37746:	00 
   37747:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   3774e:	00 
   3774f:	44 88 ac 24 b8 00 00 	mov    %r13b,0xb8(%rsp)
   37756:	00 
   37757:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3775b:	0f 84 af 05 00 00    	je     37d10 <oriole_expat::dispatch+0x3ea0>
   37761:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
   37768:	00 
   37769:	e9 a5 05 00 00       	jmp    37d13 <oriole_expat::dispatch+0x3ea3>
   3776e:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   37775:	00 
   37776:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   3777d:	00 
   3777e:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   37785:	00 
   37786:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   3778d:	00 
   3778e:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   37795:	00 
   37796:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   3779d:	00 
   3779e:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   377a5:	00 
   377a6:	44 88 ac 24 b8 00 00 	mov    %r13b,0xb8(%rsp)
   377ad:	00 
   377ae:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   377b2:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   377b7:	0f 84 d8 05 00 00    	je     37d95 <oriole_expat::dispatch+0x3f25>
   377bd:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   377c4:	00 
   377c5:	e9 cd 05 00 00       	jmp    37d97 <oriole_expat::dispatch+0x3f27>
   377ca:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   377d1:	00 
   377d2:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   377d9:	00 
   377da:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   377e1:	00 
   377e2:	0f 11 94 24 98 00 00 	movups %xmm2,0x98(%rsp)
   377e9:	00 
   377ea:	0f 11 8c 24 89 00 00 	movups %xmm1,0x89(%rsp)
   377f1:	00 
   377f2:	0f 11 44 24 79       	movups %xmm0,0x79(%rsp)
   377f7:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   377fc:	44 88 6c 24 78       	mov    %r13b,0x78(%rsp)
   37801:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37805:	0f 84 2b 06 00 00    	je     37e36 <oriole_expat::dispatch+0x3fc6>
   3780b:	4c 8b a4 24 90 00 00 	mov    0x90(%rsp),%r12
   37812:	00 
   37813:	e9 21 06 00 00       	jmp    37e39 <oriole_expat::dispatch+0x3fc9>
   37818:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   3781f:	00 
   37820:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   37827:	00 
   37828:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   3782f:	00 
   37830:	0f 11 94 24 98 00 00 	movups %xmm2,0x98(%rsp)
   37837:	00 
   37838:	0f 11 8c 24 89 00 00 	movups %xmm1,0x89(%rsp)
   3783f:	00 
   37840:	0f 11 44 24 79       	movups %xmm0,0x79(%rsp)
   37845:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   3784a:	44 88 6c 24 78       	mov    %r13b,0x78(%rsp)
   3784f:	45 31 e4             	xor    %r12d,%r12d
   37852:	41 bd 00 00 00 00    	mov    $0x0,%r13d
   37858:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3785c:	74 08                	je     37866 <oriole_expat::dispatch+0x39f6>
   3785e:	4c 8b ac 24 90 00 00 	mov    0x90(%rsp),%r13
   37865:	00 
   37866:	83 bc 24 98 04 00 00 	cmpl   $0xffffffff,0x498(%rsp)
   3786d:	ff 
   3786e:	74 08                	je     37878 <oriole_expat::dispatch+0x3a08>
   37870:	4c 8b a4 24 b8 04 00 	mov    0x4b8(%rsp),%r12
   37877:	00 
   37878:	b3 01                	mov    $0x1,%bl
   3787a:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   37881:	00 
   37882:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
   37889:	00 
   3788a:	e8 91 b5 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   3788f:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   37896:	00 
   37897:	0f b6 8c 24 e8 02 00 	movzbl 0x2e8(%rsp),%ecx
   3789e:	00 
   3789f:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   378a3:	0f 85 16 07 00 00    	jne    37fbf <oriole_expat::dispatch+0x414f>
   378a9:	41 89 cd             	mov    %ecx,%r13d
   378ac:	31 db                	xor    %ebx,%ebx
   378ae:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   378b3:	e8 88 7a ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   378b8:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   378bf:	00 
   378c0:	e8 7b 7a ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   378c5:	e9 51 0f 00 00       	jmp    3881b <oriole_expat::dispatch+0x49ab>
   378ca:	b0 01                	mov    $0x1,%al
   378cc:	89 44 24 48          	mov    %eax,0x48(%rsp)
   378d0:	b0 01                	mov    $0x1,%al
   378d2:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   378d6:	b0 01                	mov    $0x1,%al
   378d8:	89 44 24 40          	mov    %eax,0x40(%rsp)
   378dc:	b0 01                	mov    $0x1,%al
   378de:	89 44 24 50          	mov    %eax,0x50(%rsp)
   378e2:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   378e9:	00 
   378ea:	e9 66 07 00 00       	jmp    38055 <oriole_expat::dispatch+0x41e5>
   378ef:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   378f6:	00 
   378f7:	48 85 c9             	test   %rcx,%rcx
   378fa:	74 18                	je     37914 <oriole_expat::dispatch+0x3aa4>
   378fc:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   37903:	00 
   37904:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   37909:	ba 01 00 00 00       	mov    $0x1,%edx
   3790e:	ff 15 9c ef 0a 00    	call   *0xaef9c(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37914:	b0 01                	mov    $0x1,%al
   37916:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3791a:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   37921:	00 
   37922:	b0 01                	mov    $0x1,%al
   37924:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   37928:	b0 01                	mov    $0x1,%al
   3792a:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3792e:	b0 01                	mov    $0x1,%al
   37930:	89 44 24 50          	mov    %eax,0x50(%rsp)
   37934:	b0 01                	mov    $0x1,%al
   37936:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3793a:	b0 01                	mov    $0x1,%al
   3793c:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37940:	b0 01                	mov    $0x1,%al
   37942:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37946:	b0 01                	mov    $0x1,%al
   37948:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3794c:	b0 01                	mov    $0x1,%al
   3794e:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37952:	b0 01                	mov    $0x1,%al
   37954:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37958:	b0 01                	mov    $0x1,%al
   3795a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3795f:	b0 01                	mov    $0x1,%al
   37961:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37965:	b0 01                	mov    $0x1,%al
   37967:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3796b:	b0 01                	mov    $0x1,%al
   3796d:	89 44 24 18          	mov    %eax,0x18(%rsp)
   37971:	e9 02 0f 00 00       	jmp    38878 <oriole_expat::dispatch+0x4a08>
   37976:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   3797d:	00 
   3797e:	48 85 c9             	test   %rcx,%rcx
   37981:	0f 84 ae 06 00 00    	je     38035 <oriole_expat::dispatch+0x41c5>
   37987:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   3798e:	00 
   3798f:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   37996:	00 
   37997:	ba 01 00 00 00       	mov    $0x1,%edx
   3799c:	ff 15 0e ef 0a 00    	call   *0xaef0e(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   379a2:	e9 8e 06 00 00       	jmp    38035 <oriole_expat::dispatch+0x41c5>
   379a7:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   379ac:	e8 8f 79 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   379b1:	b0 01                	mov    $0x1,%al
   379b3:	89 44 24 50          	mov    %eax,0x50(%rsp)
   379b7:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   379be:	00 
   379bf:	b0 01                	mov    $0x1,%al
   379c1:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   379c5:	b0 01                	mov    $0x1,%al
   379c7:	89 44 24 40          	mov    %eax,0x40(%rsp)
   379cb:	b0 01                	mov    $0x1,%al
   379cd:	89 44 24 38          	mov    %eax,0x38(%rsp)
   379d1:	b0 01                	mov    $0x1,%al
   379d3:	89 44 24 48          	mov    %eax,0x48(%rsp)
   379d7:	e9 7f 06 00 00       	jmp    3805b <oriole_expat::dispatch+0x41eb>
   379dc:	b0 01                	mov    $0x1,%al
   379de:	89 44 24 30          	mov    %eax,0x30(%rsp)
   379e2:	c7 44 24 1c 00 00 00 	movl   $0x0,0x1c(%rsp)
   379e9:	00 
   379ea:	b0 01                	mov    $0x1,%al
   379ec:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   379f0:	b0 01                	mov    $0x1,%al
   379f2:	89 44 24 40          	mov    %eax,0x40(%rsp)
   379f6:	b0 01                	mov    $0x1,%al
   379f8:	89 44 24 50          	mov    %eax,0x50(%rsp)
   379fc:	b0 01                	mov    $0x1,%al
   379fe:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37a02:	b0 01                	mov    $0x1,%al
   37a04:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37a08:	b0 01                	mov    $0x1,%al
   37a0a:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37a0e:	b0 01                	mov    $0x1,%al
   37a10:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37a14:	b0 01                	mov    $0x1,%al
   37a16:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37a1a:	b0 01                	mov    $0x1,%al
   37a1c:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37a20:	b0 01                	mov    $0x1,%al
   37a22:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   37a27:	b0 01                	mov    $0x1,%al
   37a29:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37a2d:	b0 01                	mov    $0x1,%al
   37a2f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   37a33:	b0 01                	mov    $0x1,%al
   37a35:	89 44 24 18          	mov    %eax,0x18(%rsp)
   37a39:	b0 01                	mov    $0x1,%al
   37a3b:	89 44 24 20          	mov    %eax,0x20(%rsp)
   37a3f:	e9 3a 0e 00 00       	jmp    3887e <oriole_expat::dispatch+0x4a0e>
   37a44:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   37a4b:	00 
   37a4c:	e8 ef 78 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37a51:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   37a58:	00 
   37a59:	e8 e2 78 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37a5e:	e9 e9 08 00 00       	jmp    3834c <oriole_expat::dispatch+0x44dc>
   37a63:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   37a6a:	00 
   37a6b:	e8 d0 78 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37a70:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   37a77:	00 
   37a78:	e8 c3 78 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37a7d:	e9 7b 0a 00 00       	jmp    384fd <oriole_expat::dispatch+0x468d>
   37a82:	41 89 ce             	mov    %ecx,%r14d
   37a85:	40 b5 01             	mov    $0x1,%bpl
   37a88:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   37a8f:	00 
   37a90:	41 b5 01             	mov    $0x1,%r13b
   37a93:	e8 a8 78 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37a98:	41 b5 01             	mov    $0x1,%r13b
   37a9b:	e9 1a 0c 00 00       	jmp    386ba <oriole_expat::dispatch+0x484a>
   37aa0:	48 8b 94 24 c8 01 00 	mov    0x1c8(%rsp),%rdx
   37aa7:	00 
   37aa8:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   37aaf:	00 
   37ab0:	ff d3                	call   *%rbx
   37ab2:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   37ab9:	00 
   37aba:	48 85 c9             	test   %rcx,%rcx
   37abd:	74 1b                	je     37ada <oriole_expat::dispatch+0x3c6a>
   37abf:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   37ac6:	00 
   37ac7:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   37ace:	00 
   37acf:	ba 01 00 00 00       	mov    $0x1,%edx
   37ad4:	ff 15 d6 ed 0a 00    	call   *0xaedd6(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37ada:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   37ae1:	00 
   37ae2:	48 85 c9             	test   %rcx,%rcx
   37ae5:	74 18                	je     37aff <oriole_expat::dispatch+0x3c8f>
   37ae7:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   37aee:	00 
   37aef:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   37af4:	ba 01 00 00 00       	mov    $0x1,%edx
   37af9:	ff 15 b1 ed 0a 00    	call   *0xaedb1(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37aff:	b3 01                	mov    $0x1,%bl
   37b01:	e9 02 06 00 00       	jmp    38108 <oriole_expat::dispatch+0x4298>
   37b06:	31 db                	xor    %ebx,%ebx
   37b08:	4c 8b a4 24 90 00 00 	mov    0x90(%rsp),%r12
   37b0f:	00 
   37b10:	40 b5 01             	mov    $0x1,%bpl
   37b13:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   37b1a:	00 
   37b1b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
   37b22:	00 
   37b23:	e8 f8 b2 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   37b28:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   37b2f:	00 
   37b30:	44 0f b6 ac 24 e8 02 	movzbl 0x2e8(%rsp),%r13d
   37b37:	00 00 
   37b39:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   37b3d:	0f 85 8b 00 00 00    	jne    37bce <oriole_expat::dispatch+0x3d5e>
   37b43:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   37b4a:	00 
   37b4b:	48 85 c9             	test   %rcx,%rcx
   37b4e:	74 15                	je     37b65 <oriole_expat::dispatch+0x3cf5>
   37b50:	31 db                	xor    %ebx,%ebx
   37b52:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   37b57:	ba 01 00 00 00       	mov    $0x1,%edx
   37b5c:	4c 89 e6             	mov    %r12,%rsi
   37b5f:	ff 15 4b ed 0a 00    	call   *0xaed4b(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37b65:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   37b6c:	00 
   37b6d:	e8 ce 77 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37b72:	e9 d5 07 00 00       	jmp    3834c <oriole_expat::dispatch+0x44dc>
   37b77:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   37b7e:	00 
   37b7f:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   37b86:	00 
   37b87:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   37b8e:	00 
   37b8f:	0f 11 94 24 e8 01 00 	movups %xmm2,0x1e8(%rsp)
   37b96:	00 
   37b97:	0f 11 8c 24 d9 01 00 	movups %xmm1,0x1d9(%rsp)
   37b9e:	00 
   37b9f:	0f 11 84 24 c9 01 00 	movups %xmm0,0x1c9(%rsp)
   37ba6:	00 
   37ba7:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
   37bae:	00 
   37baf:	44 88 ac 24 c8 01 00 	mov    %r13b,0x1c8(%rsp)
   37bb6:	00 
   37bb7:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37bbb:	0f 84 ba 06 00 00    	je     3827b <oriole_expat::dispatch+0x440b>
   37bc1:	48 8b 94 24 e0 01 00 	mov    0x1e0(%rsp),%rdx
   37bc8:	00 
   37bc9:	e9 af 06 00 00       	jmp    3827d <oriole_expat::dispatch+0x440d>
   37bce:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   37bd5:	00 
   37bd6:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   37bdd:	00 
   37bde:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   37be5:	00 
   37be6:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   37bed:	00 
   37bee:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   37bf5:	00 
   37bf6:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   37bfd:	00 
   37bfe:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   37c05:	00 
   37c06:	44 88 ac 24 b8 00 00 	mov    %r13b,0xb8(%rsp)
   37c0d:	00 
   37c0e:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37c12:	0f 84 ce 06 00 00    	je     382e6 <oriole_expat::dispatch+0x4476>
   37c18:	48 8b ac 24 d0 00 00 	mov    0xd0(%rsp),%rbp
   37c1f:	00 
   37c20:	e9 c3 06 00 00       	jmp    382e8 <oriole_expat::dispatch+0x4478>
   37c25:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   37c2c:	00 
   37c2d:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   37c34:	00 
   37c35:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   37c3c:	00 
   37c3d:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   37c44:	00 
   37c45:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   37c4c:	00 
   37c4d:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   37c54:	00 
   37c55:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   37c5c:	00 
   37c5d:	44 88 ac 24 b8 00 00 	mov    %r13b,0xb8(%rsp)
   37c64:	00 
   37c65:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37c69:	0f 84 2b 08 00 00    	je     3849a <oriole_expat::dispatch+0x462a>
   37c6f:	48 8b 9c 24 d0 00 00 	mov    0xd0(%rsp),%rbx
   37c76:	00 
   37c77:	e9 20 08 00 00       	jmp    3849c <oriole_expat::dispatch+0x462c>
   37c7c:	40 b5 01             	mov    $0x1,%bpl
   37c7f:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   37c86:	00 
   37c87:	b3 01                	mov    $0x1,%bl
   37c89:	41 b5 01             	mov    $0x1,%r13b
   37c8c:	41 b7 01             	mov    $0x1,%r15b
   37c8f:	e8 ac 76 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37c94:	b3 01                	mov    $0x1,%bl
   37c96:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   37c9d:	00 
   37c9e:	41 b5 01             	mov    $0x1,%r13b
   37ca1:	41 b7 01             	mov    $0x1,%r15b
   37ca4:	e8 97 76 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37ca9:	41 b5 01             	mov    $0x1,%r13b
   37cac:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
   37cb3:	00 
   37cb4:	41 b7 01             	mov    $0x1,%r15b
   37cb7:	e8 84 76 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37cbc:	31 db                	xor    %ebx,%ebx
   37cbe:	e9 9b 17 00 00       	jmp    3945e <oriole_expat::dispatch+0x55ee>
   37cc3:	41 89 ce             	mov    %ecx,%r14d
   37cc6:	41 b7 01             	mov    $0x1,%r15b
   37cc9:	e9 3d 05 00 00       	jmp    3820b <oriole_expat::dispatch+0x439b>
   37cce:	41 89 cd             	mov    %ecx,%r13d
   37cd1:	eb 03                	jmp    37cd6 <oriole_expat::dispatch+0x3e66>
   37cd3:	41 89 c5             	mov    %eax,%r13d
   37cd6:	48 8b 8c 24 e8 01 00 	mov    0x1e8(%rsp),%rcx
   37cdd:	00 
   37cde:	48 85 c9             	test   %rcx,%rcx
   37ce1:	74 1b                	je     37cfe <oriole_expat::dispatch+0x3e8e>
   37ce3:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   37cea:	00 
   37ceb:	ba 01 00 00 00       	mov    $0x1,%edx
   37cf0:	48 8b b4 24 b8 01 00 	mov    0x1b8(%rsp),%rsi
   37cf7:	00 
   37cf8:	ff 15 b2 eb 0a 00    	call   *0xaebb2(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37cfe:	b0 01                	mov    $0x1,%al
   37d00:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37d04:	b0 01                	mov    $0x1,%al
   37d06:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   37d0b:	e9 6e 0b 00 00       	jmp    3887e <oriole_expat::dispatch+0x4a0e>
   37d10:	45 31 f6             	xor    %r14d,%r14d
   37d13:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   37d18:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   37d1f:	00 
   37d20:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
   37d25:	e8 f6 b0 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   37d2a:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   37d31:	00 
   37d32:	44 0f b6 ac 24 e8 02 	movzbl 0x2e8(%rsp),%r13d
   37d39:	00 00 
   37d3b:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   37d3f:	0f 85 23 02 00 00    	jne    37f68 <oriole_expat::dispatch+0x40f8>
   37d45:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   37d4c:	00 
   37d4d:	e8 ee 75 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37d52:	b0 01                	mov    $0x1,%al
   37d54:	89 44 24 50          	mov    %eax,0x50(%rsp)
   37d58:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   37d5f:	00 
   37d60:	b0 01                	mov    $0x1,%al
   37d62:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   37d66:	b0 01                	mov    $0x1,%al
   37d68:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37d6c:	b0 01                	mov    $0x1,%al
   37d6e:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37d72:	b0 01                	mov    $0x1,%al
   37d74:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37d78:	b0 01                	mov    $0x1,%al
   37d7a:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37d7e:	b0 01                	mov    $0x1,%al
   37d80:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37d84:	b0 01                	mov    $0x1,%al
   37d86:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37d8a:	b0 01                	mov    $0x1,%al
   37d8c:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37d90:	e9 c4 0a 00 00       	jmp    38859 <oriole_expat::dispatch+0x49e9>
   37d95:	31 f6                	xor    %esi,%esi
   37d97:	ff d3                	call   *%rbx
   37d99:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   37da0:	00 
   37da1:	b0 01                	mov    $0x1,%al
   37da3:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37da7:	b0 01                	mov    $0x1,%al
   37da9:	89 44 24 50          	mov    %eax,0x50(%rsp)
   37dad:	b0 01                	mov    $0x1,%al
   37daf:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37db3:	b0 01                	mov    $0x1,%al
   37db5:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37db9:	b0 01                	mov    $0x1,%al
   37dbb:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37dbf:	b0 01                	mov    $0x1,%al
   37dc1:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37dc5:	b0 01                	mov    $0x1,%al
   37dc7:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37dcb:	b0 01                	mov    $0x1,%al
   37dcd:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37dd1:	b0 01                	mov    $0x1,%al
   37dd3:	89 44 24 28          	mov    %eax,0x28(%rsp)
   37dd7:	b0 01                	mov    $0x1,%al
   37dd9:	89 44 24 10          	mov    %eax,0x10(%rsp)
   37ddd:	40 b5 01             	mov    $0x1,%bpl
   37de0:	41 b7 01             	mov    $0x1,%r15b
   37de3:	41 b4 01             	mov    $0x1,%r12b
   37de6:	41 b5 01             	mov    $0x1,%r13b
   37de9:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
   37df0:	00 00 
   37df2:	e8 49 75 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37df7:	b0 01                	mov    $0x1,%al
   37df9:	89 44 24 50          	mov    %eax,0x50(%rsp)
   37dfd:	31 d2                	xor    %edx,%edx
   37dff:	b0 01                	mov    $0x1,%al
   37e01:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   37e05:	b0 01                	mov    $0x1,%al
   37e07:	89 44 24 40          	mov    %eax,0x40(%rsp)
   37e0b:	b0 01                	mov    $0x1,%al
   37e0d:	89 44 24 38          	mov    %eax,0x38(%rsp)
   37e11:	b0 01                	mov    $0x1,%al
   37e13:	89 44 24 48          	mov    %eax,0x48(%rsp)
   37e17:	b0 01                	mov    $0x1,%al
   37e19:	89 44 24 14          	mov    %eax,0x14(%rsp)
   37e1d:	b0 01                	mov    $0x1,%al
   37e1f:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37e23:	b0 01                	mov    $0x1,%al
   37e25:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   37e29:	b0 01                	mov    $0x1,%al
   37e2b:	89 44 24 08          	mov    %eax,0x8(%rsp)
   37e2f:	b1 01                	mov    $0x1,%cl
   37e31:	e9 28 ef ff ff       	jmp    36d5e <oriole_expat::dispatch+0x2eee>
   37e36:	45 31 e4             	xor    %r12d,%r12d
   37e39:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   37e3e:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
   37e45:	00 
   37e46:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   37e4d:	00 
   37e4e:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
   37e55:	00 
   37e56:	0f 28 8c 24 00 01 00 	movaps 0x100(%rsp),%xmm1
   37e5d:	00 
   37e5e:	0f 28 94 24 10 01 00 	movaps 0x110(%rsp),%xmm2
   37e65:	00 
   37e66:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   37e6d:	00 
   37e6e:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   37e75:	00 
   37e76:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   37e7d:	00 
   37e7e:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   37e85:	00 
   37e86:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
   37e8d:	00 
   37e8e:	ff 15 ec ea 0a 00    	call   *0xaeaec(%rip)        # e6980 <_GLOBAL_OFFSET_TABLE_+0x208>
   37e94:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   37e9b:	00 
   37e9c:	44 0f b6 ac 24 c8 01 	movzbl 0x1c8(%rsp),%r13d
   37ea3:	00 00 
   37ea5:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37ea9:	0f 84 7b 03 00 00    	je     3822a <oriole_expat::dispatch+0x43ba>
   37eaf:	0f 10 84 24 c9 01 00 	movups 0x1c9(%rsp),%xmm0
   37eb6:	00 
   37eb7:	0f 10 8c 24 d9 01 00 	movups 0x1d9(%rsp),%xmm1
   37ebe:	00 
   37ebf:	0f 10 94 24 e8 01 00 	movups 0x1e8(%rsp),%xmm2
   37ec6:	00 
   37ec7:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   37ece:	00 
   37ecf:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   37ed6:	00 
   37ed7:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   37ede:	00 
   37edf:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   37ee6:	00 
   37ee7:	44 88 ac 24 b8 00 00 	mov    %r13b,0xb8(%rsp)
   37eee:	00 
   37eef:	48 8b 94 24 d0 00 00 	mov    0xd0(%rsp),%rdx
   37ef6:	00 
   37ef7:	48 89 df             	mov    %rbx,%rdi
   37efa:	4c 89 e6             	mov    %r12,%rsi
   37efd:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
   37f02:	41 ff d7             	call   *%r15
   37f05:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   37f0c:	00 
   37f0d:	48 85 c9             	test   %rcx,%rcx
   37f10:	74 1b                	je     37f2d <oriole_expat::dispatch+0x40bd>
   37f12:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   37f19:	00 
   37f1a:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   37f21:	00 
   37f22:	ba 01 00 00 00       	mov    $0x1,%edx
   37f27:	ff 15 83 e9 0a 00    	call   *0xae983(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   37f2d:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   37f32:	e8 09 74 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   37f37:	b0 01                	mov    $0x1,%al
   37f39:	89 44 24 30          	mov    %eax,0x30(%rsp)
   37f3d:	b0 01                	mov    $0x1,%al
   37f3f:	8b 5c 24 30          	mov    0x30(%rsp),%ebx
   37f43:	b1 01                	mov    $0x1,%cl
   37f45:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   37f49:	b1 01                	mov    $0x1,%cl
   37f4b:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   37f4f:	b1 01                	mov    $0x1,%cl
   37f51:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   37f55:	b1 01                	mov    $0x1,%cl
   37f57:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   37f5b:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   37f62:	00 
   37f63:	e9 43 d7 ff ff       	jmp    356ab <oriole_expat::dispatch+0x183b>
   37f68:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   37f6f:	00 
   37f70:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   37f77:	00 
   37f78:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   37f7f:	00 
   37f80:	0f 11 94 24 e8 01 00 	movups %xmm2,0x1e8(%rsp)
   37f87:	00 
   37f88:	0f 11 8c 24 d9 01 00 	movups %xmm1,0x1d9(%rsp)
   37f8f:	00 
   37f90:	0f 11 84 24 c9 01 00 	movups %xmm0,0x1c9(%rsp)
   37f97:	00 
   37f98:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
   37f9f:	00 
   37fa0:	44 88 ac 24 c8 01 00 	mov    %r13b,0x1c8(%rsp)
   37fa7:	00 
   37fa8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   37fac:	0f 84 bb 07 00 00    	je     3876d <oriole_expat::dispatch+0x48fd>
   37fb2:	48 8b 94 24 e0 01 00 	mov    0x1e0(%rsp),%rdx
   37fb9:	00 
   37fba:	e9 b0 07 00 00       	jmp    3876f <oriole_expat::dispatch+0x48ff>
   37fbf:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   37fc6:	00 
   37fc7:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   37fce:	00 
   37fcf:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   37fd6:	00 
   37fd7:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   37fde:	00 
   37fdf:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   37fe6:	00 
   37fe7:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   37fee:	00 
   37fef:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   37ff6:	00 
   37ff7:	88 8c 24 b8 00 00 00 	mov    %cl,0xb8(%rsp)
   37ffe:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38002:	0f 84 c6 07 00 00    	je     387ce <oriole_expat::dispatch+0x495e>
   38008:	48 8b 9c 24 d0 00 00 	mov    0xd0(%rsp),%rbx
   3800f:	00 
   38010:	e9 bb 07 00 00       	jmp    387d0 <oriole_expat::dispatch+0x4960>
   38015:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   3801c:	00 
   3801d:	48 85 c9             	test   %rcx,%rcx
   38020:	74 13                	je     38035 <oriole_expat::dispatch+0x41c5>
   38022:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   38027:	ba 01 00 00 00       	mov    $0x1,%edx
   3802c:	4c 89 e6             	mov    %r12,%rsi
   3802f:	ff 15 7b e8 0a 00    	call   *0xae87b(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38035:	b0 01                	mov    $0x1,%al
   38037:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3803b:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   38042:	00 
   38043:	b0 01                	mov    $0x1,%al
   38045:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   38049:	b0 01                	mov    $0x1,%al
   3804b:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3804f:	b0 01                	mov    $0x1,%al
   38051:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38055:	b0 01                	mov    $0x1,%al
   38057:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3805b:	b0 01                	mov    $0x1,%al
   3805d:	89 44 24 30          	mov    %eax,0x30(%rsp)
   38061:	e9 fa 01 00 00       	jmp    38260 <oriole_expat::dispatch+0x43f0>
   38066:	41 89 ce             	mov    %ecx,%r14d
   38069:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   38070:	00 
   38071:	48 85 c9             	test   %rcx,%rcx
   38074:	74 1e                	je     38094 <oriole_expat::dispatch+0x4224>
   38076:	b3 01                	mov    $0x1,%bl
   38078:	45 31 ed             	xor    %r13d,%r13d
   3807b:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   38082:	00 
   38083:	ba 01 00 00 00       	mov    $0x1,%edx
   38088:	40 b5 01             	mov    $0x1,%bpl
   3808b:	4c 89 fe             	mov    %r15,%rsi
   3808e:	ff 15 1c e8 0a 00    	call   *0xae81c(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38094:	40 b5 01             	mov    $0x1,%bpl
   38097:	e9 06 06 00 00       	jmp    386a2 <oriole_expat::dispatch+0x4832>
   3809c:	31 db                	xor    %ebx,%ebx
   3809e:	b0 01                	mov    $0x1,%al
   380a0:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   380a7:	00 
   380a8:	b1 01                	mov    $0x1,%cl
   380aa:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   380ae:	e9 e6 d5 ff ff       	jmp    35699 <oriole_expat::dispatch+0x1829>
   380b3:	31 db                	xor    %ebx,%ebx
   380b5:	b0 01                	mov    $0x1,%al
   380b7:	c7 44 24 1c 00 00 00 	movl   $0x0,0x1c(%rsp)
   380be:	00 
   380bf:	b1 01                	mov    $0x1,%cl
   380c1:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   380c5:	b1 01                	mov    $0x1,%cl
   380c7:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   380cb:	b1 01                	mov    $0x1,%cl
   380cd:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   380d1:	b1 01                	mov    $0x1,%cl
   380d3:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   380d7:	b1 01                	mov    $0x1,%cl
   380d9:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   380dd:	b1 01                	mov    $0x1,%cl
   380df:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   380e3:	b1 01                	mov    $0x1,%cl
   380e5:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   380e9:	b1 01                	mov    $0x1,%cl
   380eb:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   380ef:	b1 01                	mov    $0x1,%cl
   380f1:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   380f5:	b1 01                	mov    $0x1,%cl
   380f7:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
   380fb:	b1 01                	mov    $0x1,%cl
   380fd:	89 4c 24 20          	mov    %ecx,0x20(%rsp)
   38101:	e9 cf d5 ff ff       	jmp    356d5 <oriole_expat::dispatch+0x1865>
   38106:	31 db                	xor    %ebx,%ebx
   38108:	b0 01                	mov    $0x1,%al
   3810a:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   38111:	00 
   38112:	b1 01                	mov    $0x1,%cl
   38114:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   38118:	b1 01                	mov    $0x1,%cl
   3811a:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   3811e:	b1 01                	mov    $0x1,%cl
   38120:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   38124:	b1 01                	mov    $0x1,%cl
   38126:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   3812a:	b1 01                	mov    $0x1,%cl
   3812c:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   38130:	b1 01                	mov    $0x1,%cl
   38132:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   38136:	b1 01                	mov    $0x1,%cl
   38138:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   3813c:	b1 01                	mov    $0x1,%cl
   3813e:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   38142:	b1 01                	mov    $0x1,%cl
   38144:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   38148:	b1 01                	mov    $0x1,%cl
   3814a:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
   3814e:	e9 7c d5 ff ff       	jmp    356cf <oriole_expat::dispatch+0x185f>
   38153:	31 db                	xor    %ebx,%ebx
   38155:	b0 01                	mov    $0x1,%al
   38157:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   3815e:	00 
   3815f:	b1 01                	mov    $0x1,%cl
   38161:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   38165:	b1 01                	mov    $0x1,%cl
   38167:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   3816b:	e9 2f d5 ff ff       	jmp    3569f <oriole_expat::dispatch+0x182f>
   38170:	31 db                	xor    %ebx,%ebx
   38172:	e9 4e 01 00 00       	jmp    382c5 <oriole_expat::dispatch+0x4455>
   38177:	31 db                	xor    %ebx,%ebx
   38179:	e9 e4 0c 00 00       	jmp    38e62 <oriole_expat::dispatch+0x4ff2>
   3817e:	31 db                	xor    %ebx,%ebx
   38180:	e9 b1 0f 00 00       	jmp    39136 <oriole_expat::dispatch+0x52c6>
   38185:	31 db                	xor    %ebx,%ebx
   38187:	e9 20 11 00 00       	jmp    392ac <oriole_expat::dispatch+0x543c>
   3818c:	48 8b b4 24 e0 01 00 	mov    0x1e0(%rsp),%rsi
   38193:	00 
   38194:	48 89 df             	mov    %rbx,%rdi
   38197:	41 ff d7             	call   *%r15
   3819a:	b3 01                	mov    $0x1,%bl
   3819c:	49 8d 7e 30          	lea    0x30(%r14),%rdi
   381a0:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
   381a7:	00 
   381a8:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
   381af:	00 
   381b0:	0f 28 84 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm0
   381b7:	00 
   381b8:	0f 28 8c 24 d0 01 00 	movaps 0x1d0(%rsp),%xmm1
   381bf:	00 
   381c0:	0f 28 94 24 e0 01 00 	movaps 0x1e0(%rsp),%xmm2
   381c7:	00 
   381c8:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   381cf:	00 
   381d0:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   381d7:	00 
   381d8:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   381df:	00 
   381e0:	48 8d 94 24 e0 02 00 	lea    0x2e0(%rsp),%rdx
   381e7:	00 
   381e8:	48 8b b4 24 08 05 00 	mov    0x508(%rsp),%rsi
   381ef:	00 
   381f0:	ff 15 5a e6 0a 00    	call   *0xae65a(%rip)        # e6850 <_GLOBAL_OFFSET_TABLE_+0xd8>
   381f6:	b0 01                	mov    $0x1,%al
   381f8:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   381ff:	00 
   38200:	e9 8e d4 ff ff       	jmp    35693 <oriole_expat::dispatch+0x1823>
   38205:	41 89 ce             	mov    %ecx,%r14d
   38208:	45 31 ff             	xor    %r15d,%r15d
   3820b:	40 b5 01             	mov    $0x1,%bpl
   3820e:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   38215:	00 
   38216:	b3 01                	mov    $0x1,%bl
   38218:	41 b5 01             	mov    $0x1,%r13b
   3821b:	e8 20 71 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38220:	b3 01                	mov    $0x1,%bl
   38222:	41 b5 01             	mov    $0x1,%r13b
   38225:	e9 98 0d 00 00       	jmp    38fc2 <oriole_expat::dispatch+0x5152>
   3822a:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   3822f:	e8 0c 71 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38234:	b0 01                	mov    $0x1,%al
   38236:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3823a:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   38241:	00 
   38242:	b0 01                	mov    $0x1,%al
   38244:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   38248:	b0 01                	mov    $0x1,%al
   3824a:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3824e:	b0 01                	mov    $0x1,%al
   38250:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38254:	b0 01                	mov    $0x1,%al
   38256:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3825a:	b0 01                	mov    $0x1,%al
   3825c:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38260:	b0 01                	mov    $0x1,%al
   38262:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   38266:	e9 e2 05 00 00       	jmp    3884d <oriole_expat::dispatch+0x49dd>
   3826b:	41 89 ce             	mov    %ecx,%r14d
   3826e:	b0 01                	mov    $0x1,%al
   38270:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38274:	b3 01                	mov    $0x1,%bl
   38276:	e9 f4 0c 00 00       	jmp    38f6f <oriole_expat::dispatch+0x50ff>
   3827b:	31 d2                	xor    %edx,%edx
   3827d:	83 fb 02             	cmp    $0x2,%ebx
   38280:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
   38285:	0f 45 cb             	cmovne %ebx,%ecx
   38288:	4c 89 e6             	mov    %r12,%rsi
   3828b:	41 ff d7             	call   *%r15
   3828e:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   38295:	00 
   38296:	e8 a5 70 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3829b:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   382a2:	00 
   382a3:	48 85 c9             	test   %rcx,%rcx
   382a6:	74 1b                	je     382c3 <oriole_expat::dispatch+0x4453>
   382a8:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   382af:	00 
   382b0:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   382b7:	00 
   382b8:	ba 01 00 00 00       	mov    $0x1,%edx
   382bd:	ff 15 ed e5 0a 00    	call   *0xae5ed(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   382c3:	b3 01                	mov    $0x1,%bl
   382c5:	b0 01                	mov    $0x1,%al
   382c7:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   382ce:	00 
   382cf:	b1 01                	mov    $0x1,%cl
   382d1:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   382d5:	b1 01                	mov    $0x1,%cl
   382d7:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   382db:	b1 01                	mov    $0x1,%cl
   382dd:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   382e1:	e9 bf d3 ff ff       	jmp    356a5 <oriole_expat::dispatch+0x1835>
   382e6:	31 ed                	xor    %ebp,%ebp
   382e8:	4c 8b 7c 24 68       	mov    0x68(%rsp),%r15
   382ed:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   382f4:	00 
   382f5:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
   382fc:	00 
   382fd:	e8 1e ab ff ff       	call   32e20 <oriole_expat::optional_cstring>
   38302:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   38309:	00 
   3830a:	44 0f b6 ac 24 e8 02 	movzbl 0x2e8(%rsp),%r13d
   38311:	00 00 
   38313:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   38317:	0f 85 1d 02 00 00    	jne    3853a <oriole_expat::dispatch+0x46ca>
   3831d:	31 ed                	xor    %ebp,%ebp
   3831f:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   38326:	00 
   38327:	e8 14 70 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3832c:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   38333:	00 
   38334:	48 85 c9             	test   %rcx,%rcx
   38337:	74 13                	je     3834c <oriole_expat::dispatch+0x44dc>
   38339:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   3833e:	ba 01 00 00 00       	mov    $0x1,%edx
   38343:	4c 89 e6             	mov    %r12,%rsi
   38346:	ff 15 64 e5 0a 00    	call   *0xae564(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3834c:	b0 01                	mov    $0x1,%al
   3834e:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38352:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   38359:	00 
   3835a:	b0 01                	mov    $0x1,%al
   3835c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   38360:	b0 01                	mov    $0x1,%al
   38362:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38366:	b0 01                	mov    $0x1,%al
   38368:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3836c:	b0 01                	mov    $0x1,%al
   3836e:	89 44 24 48          	mov    %eax,0x48(%rsp)
   38372:	b0 01                	mov    $0x1,%al
   38374:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38378:	b0 01                	mov    $0x1,%al
   3837a:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3837e:	b0 01                	mov    $0x1,%al
   38380:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   38384:	b0 01                	mov    $0x1,%al
   38386:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3838a:	b0 01                	mov    $0x1,%al
   3838c:	89 44 24 28          	mov    %eax,0x28(%rsp)
   38390:	b0 01                	mov    $0x1,%al
   38392:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   38397:	b0 01                	mov    $0x1,%al
   38399:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3839d:	b0 01                	mov    $0x1,%al
   3839f:	89 44 24 24          	mov    %eax,0x24(%rsp)
   383a3:	e9 ca 04 00 00       	jmp    38872 <oriole_expat::dispatch+0x4a02>
   383a8:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   383af:	00 
   383b0:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   383b7:	00 
   383b8:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   383bf:	00 
   383c0:	0f 11 94 24 18 01 00 	movups %xmm2,0x118(%rsp)
   383c7:	00 
   383c8:	0f 11 8c 24 09 01 00 	movups %xmm1,0x109(%rsp)
   383cf:	00 
   383d0:	0f 11 84 24 f9 00 00 	movups %xmm0,0xf9(%rsp)
   383d7:	00 
   383d8:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
   383df:	00 
   383e0:	88 8c 24 f8 00 00 00 	mov    %cl,0xf8(%rsp)
   383e7:	31 db                	xor    %ebx,%ebx
   383e9:	b9 00 00 00 00       	mov    $0x0,%ecx
   383ee:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   383f2:	74 08                	je     383fc <oriole_expat::dispatch+0x458c>
   383f4:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
   383fb:	00 
   383fc:	83 bc 24 98 04 00 00 	cmpl   $0xffffffff,0x498(%rsp)
   38403:	ff 
   38404:	74 08                	je     3840e <oriole_expat::dispatch+0x459e>
   38406:	48 8b 9c 24 b8 04 00 	mov    0x4b8(%rsp),%rbx
   3840d:	00 
   3840e:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
   38413:	41 b7 01             	mov    $0x1,%r15b
   38416:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3841d:	00 
   3841e:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
   38425:	00 
   38426:	40 b5 01             	mov    $0x1,%bpl
   38429:	e8 f2 a9 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   3842e:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   38435:	00 
   38436:	44 0f b6 ac 24 e8 02 	movzbl 0x2e8(%rsp),%r13d
   3843d:	00 00 
   3843f:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   38443:	0f 85 5e 0a 00 00    	jne    38ea7 <oriole_expat::dispatch+0x5037>
   38449:	41 b7 01             	mov    $0x1,%r15b
   3844c:	40 b5 01             	mov    $0x1,%bpl
   3844f:	e9 76 11 00 00       	jmp    395ca <oriole_expat::dispatch+0x575a>
   38454:	45 31 ed             	xor    %r13d,%r13d
   38457:	4c 8b bc 24 90 00 00 	mov    0x90(%rsp),%r15
   3845e:	00 
   3845f:	b3 01                	mov    $0x1,%bl
   38461:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   38468:	00 
   38469:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
   38470:	00 
   38471:	e8 aa a9 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   38476:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   3847d:	00 
   3847e:	0f b6 8c 24 e8 02 00 	movzbl 0x2e8(%rsp),%ecx
   38485:	00 
   38486:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   3848a:	0f 85 01 01 00 00    	jne    38591 <oriole_expat::dispatch+0x4721>
   38490:	41 89 ce             	mov    %ecx,%r14d
   38493:	b3 01                	mov    $0x1,%bl
   38495:	e9 af 0a 00 00       	jmp    38f49 <oriole_expat::dispatch+0x50d9>
   3849a:	31 db                	xor    %ebx,%ebx
   3849c:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   384a3:	00 
   384a4:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
   384ab:	00 
   384ac:	e8 6f a9 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   384b1:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   384b8:	00 
   384b9:	44 0f b6 ac 24 e8 02 	movzbl 0x2e8(%rsp),%r13d
   384c0:	00 00 
   384c2:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   384c6:	0f 85 20 01 00 00    	jne    385ec <oriole_expat::dispatch+0x477c>
   384cc:	31 db                	xor    %ebx,%ebx
   384ce:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   384d5:	00 
   384d6:	e8 65 6e ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   384db:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   384e2:	00 
   384e3:	48 85 c9             	test   %rcx,%rcx
   384e6:	74 15                	je     384fd <oriole_expat::dispatch+0x468d>
   384e8:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   384ed:	ba 01 00 00 00       	mov    $0x1,%edx
   384f2:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   384f7:	ff 15 b3 e3 0a 00    	call   *0xae3b3(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   384fd:	b0 01                	mov    $0x1,%al
   384ff:	89 44 24 50          	mov    %eax,0x50(%rsp)
   38503:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   3850a:	00 
   3850b:	b0 01                	mov    $0x1,%al
   3850d:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   38511:	b0 01                	mov    $0x1,%al
   38513:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38517:	b0 01                	mov    $0x1,%al
   38519:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3851d:	b0 01                	mov    $0x1,%al
   3851f:	89 44 24 48          	mov    %eax,0x48(%rsp)
   38523:	b0 01                	mov    $0x1,%al
   38525:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38529:	b0 01                	mov    $0x1,%al
   3852b:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3852f:	b0 01                	mov    $0x1,%al
   38531:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   38535:	e9 19 03 00 00       	jmp    38853 <oriole_expat::dispatch+0x49e3>
   3853a:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   38541:	00 
   38542:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   38549:	00 
   3854a:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   38551:	00 
   38552:	0f 11 94 24 e8 01 00 	movups %xmm2,0x1e8(%rsp)
   38559:	00 
   3855a:	0f 11 8c 24 d9 01 00 	movups %xmm1,0x1d9(%rsp)
   38561:	00 
   38562:	0f 11 84 24 c9 01 00 	movups %xmm0,0x1c9(%rsp)
   38569:	00 
   3856a:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
   38571:	00 
   38572:	44 88 ac 24 c8 01 00 	mov    %r13b,0x1c8(%rsp)
   38579:	00 
   3857a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3857e:	0f 84 85 08 00 00    	je     38e09 <oriole_expat::dispatch+0x4f99>
   38584:	4c 8b 84 24 e0 01 00 	mov    0x1e0(%rsp),%r8
   3858b:	00 
   3858c:	e9 7b 08 00 00       	jmp    38e0c <oriole_expat::dispatch+0x4f9c>
   38591:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   38598:	00 
   38599:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   385a0:	00 
   385a1:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   385a8:	00 
   385a9:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   385b0:	00 
   385b1:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   385b8:	00 
   385b9:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   385c0:	00 
   385c1:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   385c8:	00 
   385c9:	88 8c 24 b8 00 00 00 	mov    %cl,0xb8(%rsp)
   385d0:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   385d4:	0f 84 20 09 00 00    	je     38efa <oriole_expat::dispatch+0x508a>
   385da:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   385e1:	00 
   385e2:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   385e7:	e9 17 09 00 00       	jmp    38f03 <oriole_expat::dispatch+0x5093>
   385ec:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   385f3:	00 
   385f4:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   385fb:	00 
   385fc:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   38603:	00 
   38604:	0f 11 94 24 e8 01 00 	movups %xmm2,0x1e8(%rsp)
   3860b:	00 
   3860c:	0f 11 8c 24 d9 01 00 	movups %xmm1,0x1d9(%rsp)
   38613:	00 
   38614:	0f 11 84 24 c9 01 00 	movups %xmm0,0x1c9(%rsp)
   3861b:	00 
   3861c:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
   38623:	00 
   38624:	44 88 ac 24 c8 01 00 	mov    %r13b,0x1c8(%rsp)
   3862b:	00 
   3862c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38630:	0f 84 ab 0a 00 00    	je     390e1 <oriole_expat::dispatch+0x5271>
   38636:	48 8b 8c 24 e0 01 00 	mov    0x1e0(%rsp),%rcx
   3863d:	00 
   3863e:	e9 a0 0a 00 00       	jmp    390e3 <oriole_expat::dispatch+0x5273>
   38643:	b3 01                	mov    $0x1,%bl
   38645:	41 89 ee             	mov    %ebp,%r14d
   38648:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   3864f:	00 
   38650:	48 85 c9             	test   %rcx,%rcx
   38653:	74 1a                	je     3866f <oriole_expat::dispatch+0x47ff>
   38655:	31 ed                	xor    %ebp,%ebp
   38657:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   3865e:	00 
   3865f:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   38664:	ba 01 00 00 00       	mov    $0x1,%edx
   38669:	ff 15 41 e2 0a 00    	call   *0xae241(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3866f:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   38676:	00 
   38677:	48 85 c9             	test   %rcx,%rcx
   3867a:	74 20                	je     3869c <oriole_expat::dispatch+0x482c>
   3867c:	31 ed                	xor    %ebp,%ebp
   3867e:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   38685:	00 
   38686:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   3868d:	00 
   3868e:	ba 01 00 00 00       	mov    $0x1,%edx
   38693:	45 31 ed             	xor    %r13d,%r13d
   38696:	ff 15 14 e2 0a 00    	call   *0xae214(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3869c:	84 db                	test   %bl,%bl
   3869e:	74 74                	je     38714 <oriole_expat::dispatch+0x48a4>
   386a0:	31 ed                	xor    %ebp,%ebp
   386a2:	45 31 ed             	xor    %r13d,%r13d
   386a5:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   386ac:	00 
   386ad:	e8 8e 6c ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   386b2:	40 84 ed             	test   %bpl,%bpl
   386b5:	74 5d                	je     38714 <oriole_expat::dispatch+0x48a4>
   386b7:	45 31 ed             	xor    %r13d,%r13d
   386ba:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   386c1:	00 
   386c2:	48 85 c9             	test   %rcx,%rcx
   386c5:	74 1b                	je     386e2 <oriole_expat::dispatch+0x4872>
   386c7:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   386ce:	00 
   386cf:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   386d6:	00 
   386d7:	ba 01 00 00 00       	mov    $0x1,%edx
   386dc:	ff 15 ce e1 0a 00    	call   *0xae1ce(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   386e2:	45 84 ed             	test   %r13b,%r13b
   386e5:	74 2d                	je     38714 <oriole_expat::dispatch+0x48a4>
   386e7:	48 8b 8c 24 48 04 00 	mov    0x448(%rsp),%rcx
   386ee:	00 
   386ef:	48 85 c9             	test   %rcx,%rcx
   386f2:	45 89 f5             	mov    %r14d,%r13d
   386f5:	74 20                	je     38717 <oriole_expat::dispatch+0x48a7>
   386f7:	48 8b b4 24 40 04 00 	mov    0x440(%rsp),%rsi
   386fe:	00 
   386ff:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   38706:	00 
   38707:	ba 01 00 00 00       	mov    $0x1,%edx
   3870c:	ff 15 9e e1 0a 00    	call   *0xae19e(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38712:	eb 03                	jmp    38717 <oriole_expat::dispatch+0x48a7>
   38714:	45 89 f5             	mov    %r14d,%r13d
   38717:	b0 01                	mov    $0x1,%al
   38719:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3871d:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   38724:	00 
   38725:	b0 01                	mov    $0x1,%al
   38727:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3872b:	b0 01                	mov    $0x1,%al
   3872d:	89 44 24 50          	mov    %eax,0x50(%rsp)
   38731:	b0 01                	mov    $0x1,%al
   38733:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38737:	b0 01                	mov    $0x1,%al
   38739:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3873d:	b0 01                	mov    $0x1,%al
   3873f:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38743:	b0 01                	mov    $0x1,%al
   38745:	89 44 24 30          	mov    %eax,0x30(%rsp)
   38749:	b0 01                	mov    $0x1,%al
   3874b:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3874f:	b0 01                	mov    $0x1,%al
   38751:	89 44 24 08          	mov    %eax,0x8(%rsp)
   38755:	b0 01                	mov    $0x1,%al
   38757:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3875b:	b0 01                	mov    $0x1,%al
   3875d:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   38762:	b0 01                	mov    $0x1,%al
   38764:	89 44 24 10          	mov    %eax,0x10(%rsp)
   38768:	e9 ff 00 00 00       	jmp    3886c <oriole_expat::dispatch+0x49fc>
   3876d:	31 d2                	xor    %edx,%edx
   3876f:	48 89 df             	mov    %rbx,%rdi
   38772:	4c 89 f6             	mov    %r14,%rsi
   38775:	ff d5                	call   *%rbp
   38777:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   3877e:	00 
   3877f:	e8 bc 6b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38784:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   3878b:	00 
   3878c:	e8 af 6b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38791:	b0 01                	mov    $0x1,%al
   38793:	89 44 24 50          	mov    %eax,0x50(%rsp)
   38797:	31 c9                	xor    %ecx,%ecx
   38799:	b0 01                	mov    $0x1,%al
   3879b:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3879f:	b0 01                	mov    $0x1,%al
   387a1:	89 44 24 40          	mov    %eax,0x40(%rsp)
   387a5:	b0 01                	mov    $0x1,%al
   387a7:	89 44 24 38          	mov    %eax,0x38(%rsp)
   387ab:	b0 01                	mov    $0x1,%al
   387ad:	89 44 24 48          	mov    %eax,0x48(%rsp)
   387b1:	b0 01                	mov    $0x1,%al
   387b3:	89 44 24 14          	mov    %eax,0x14(%rsp)
   387b7:	b0 01                	mov    $0x1,%al
   387b9:	89 44 24 30          	mov    %eax,0x30(%rsp)
   387bd:	b0 01                	mov    $0x1,%al
   387bf:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   387c3:	b0 01                	mov    $0x1,%al
   387c5:	89 44 24 08          	mov    %eax,0x8(%rsp)
   387c9:	e9 8e e5 ff ff       	jmp    36d5c <oriole_expat::dispatch+0x2eec>
   387ce:	31 db                	xor    %ebx,%ebx
   387d0:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   387d7:	00 
   387d8:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
   387df:	00 
   387e0:	e8 3b a6 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   387e5:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   387ec:	00 
   387ed:	0f b6 8c 24 e8 02 00 	movzbl 0x2e8(%rsp),%ecx
   387f4:	00 
   387f5:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   387f9:	0f 85 dc 03 00 00    	jne    38bdb <oriole_expat::dispatch+0x4d6b>
   387ff:	41 89 cd             	mov    %ecx,%r13d
   38802:	31 db                	xor    %ebx,%ebx
   38804:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   3880b:	00 
   3880c:	e8 2f 6b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38811:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   38816:	e8 25 6b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3881b:	b0 01                	mov    $0x1,%al
   3881d:	89 44 24 50          	mov    %eax,0x50(%rsp)
   38821:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   38828:	00 
   38829:	b0 01                	mov    $0x1,%al
   3882b:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3882f:	b0 01                	mov    $0x1,%al
   38831:	89 44 24 40          	mov    %eax,0x40(%rsp)
   38835:	b0 01                	mov    $0x1,%al
   38837:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3883b:	b0 01                	mov    $0x1,%al
   3883d:	89 44 24 48          	mov    %eax,0x48(%rsp)
   38841:	b0 01                	mov    $0x1,%al
   38843:	89 44 24 14          	mov    %eax,0x14(%rsp)
   38847:	b0 01                	mov    $0x1,%al
   38849:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3884d:	b0 01                	mov    $0x1,%al
   3884f:	89 44 24 08          	mov    %eax,0x8(%rsp)
   38853:	b0 01                	mov    $0x1,%al
   38855:	89 44 24 28          	mov    %eax,0x28(%rsp)
   38859:	b0 01                	mov    $0x1,%al
   3885b:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   38860:	b0 01                	mov    $0x1,%al
   38862:	89 44 24 10          	mov    %eax,0x10(%rsp)
   38866:	b0 01                	mov    $0x1,%al
   38868:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3886c:	b0 01                	mov    $0x1,%al
   3886e:	89 44 24 18          	mov    %eax,0x18(%rsp)
   38872:	b0 01                	mov    $0x1,%al
   38874:	89 44 24 20          	mov    %eax,0x20(%rsp)
   38878:	b0 01                	mov    $0x1,%al
   3887a:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3887e:	83 bc 24 98 04 00 00 	cmpl   $0xffffffff,0x498(%rsp)
   38885:	ff 
   38886:	74 28                	je     388b0 <oriole_expat::dispatch+0x4a40>
   38888:	48 8b 8c 24 c0 04 00 	mov    0x4c0(%rsp),%rcx
   3888f:	00 
   38890:	48 85 c9             	test   %rcx,%rcx
   38893:	74 1b                	je     388b0 <oriole_expat::dispatch+0x4a40>
   38895:	48 8b b4 24 b8 04 00 	mov    0x4b8(%rsp),%rsi
   3889c:	00 
   3889d:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
   388a4:	00 
   388a5:	ba 01 00 00 00       	mov    $0x1,%edx
   388aa:	ff 15 00 e0 0a 00    	call   *0xae000(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   388b0:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   388b5:	48 8b 08             	mov    (%rax),%rcx
   388b8:	48 83 e9 03          	sub    $0x3,%rcx
   388bc:	b8 0d 00 00 00       	mov    $0xd,%eax
   388c1:	48 0f 43 c1          	cmovae %rcx,%rax
   388c5:	48 83 c0 fa          	add    $0xfffffffffffffffa,%rax
   388c9:	48 83 f8 14          	cmp    $0x14,%rax
   388cd:	0f 87 f3 02 00 00    	ja     38bc6 <oriole_expat::dispatch+0x4d56>
   388d3:	48 8d 0d e2 14 fd ff 	lea    -0x2eb1e(%rip),%rcx        # 9dbc <std::thread::current::id::ID+0x9d4c>
   388da:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   388de:	48 01 c8             	add    %rcx,%rax
   388e1:	ff e0                	jmp    *%rax
   388e3:	80 7c 24 2c 00       	cmpb   $0x0,0x2c(%rsp)
   388e8:	0f 84 d8 02 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   388ee:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   388f3:	48 8b 4b 30          	mov    0x30(%rbx),%rcx
   388f7:	48 85 c9             	test   %rcx,%rcx
   388fa:	74 13                	je     3890f <oriole_expat::dispatch+0x4a9f>
   388fc:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   38900:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   38904:	ba 01 00 00 00       	mov    $0x1,%edx
   38909:	ff 15 a1 df 0a 00    	call   *0xadfa1(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3890f:	48 83 c3 40          	add    $0x40,%rbx
   38913:	48 89 df             	mov    %rbx,%rdi
   38916:	e8 45 77 ff ff       	call   30060 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3891b:	e9 a6 02 00 00       	jmp    38bc6 <oriole_expat::dispatch+0x4d56>
   38920:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
   38925:	0f 84 9b 02 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   3892b:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   38930:	4c 8b 73 28          	mov    0x28(%rbx),%r14
   38934:	48 83 c3 08          	add    $0x8,%rbx
   38938:	4c 89 f7             	mov    %r14,%rdi
   3893b:	e8 20 82 ff ff       	call   30b60 <core::ptr::drop_glue::<oriole::NotationDeclaration>>
   38940:	e9 6e 01 00 00       	jmp    38ab3 <oriole_expat::dispatch+0x4c43>
   38945:	80 7c 24 58 00       	cmpb   $0x0,0x58(%rsp)
   3894a:	75 3f                	jne    3898b <oriole_expat::dispatch+0x4b1b>
   3894c:	e9 75 02 00 00       	jmp    38bc6 <oriole_expat::dispatch+0x4d56>
   38951:	80 7c 24 24 00       	cmpb   $0x0,0x24(%rsp)
   38956:	0f 84 6a 02 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   3895c:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   38961:	4c 8b 73 28          	mov    0x28(%rbx),%r14
   38965:	48 83 c3 08          	add    $0x8,%rbx
   38969:	4c 89 f7             	mov    %r14,%rdi
   3896c:	e8 9f 82 ff ff       	call   30c10 <core::ptr::drop_glue::<oriole::AttributeDeclaration>>
   38971:	ba 08 00 00 00       	mov    $0x8,%edx
   38976:	b9 e8 00 00 00       	mov    $0xe8,%ecx
   3897b:	e9 3a 02 00 00       	jmp    38bba <oriole_expat::dispatch+0x4d4a>
   38980:	80 7c 24 50 00       	cmpb   $0x0,0x50(%rsp)
   38985:	0f 84 3b 02 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   3898b:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   38990:	83 7f 08 ff          	cmpl   $0xffffffff,0x8(%rdi)
   38994:	0f 84 2c 02 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   3899a:	48 8b 4f 30          	mov    0x30(%rdi),%rcx
   3899e:	48 85 c9             	test   %rcx,%rcx
   389a1:	0f 84 1f 02 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   389a7:	48 8b 77 28          	mov    0x28(%rdi),%rsi
   389ab:	48 83 c7 08          	add    $0x8,%rdi
   389af:	ba 01 00 00 00       	mov    $0x1,%edx
   389b4:	e9 07 02 00 00       	jmp    38bc0 <oriole_expat::dispatch+0x4d50>
   389b9:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
   389be:	0f 84 02 02 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   389c4:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   389c9:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
   389cd:	48 85 c9             	test   %rcx,%rcx
   389d0:	74 12                	je     389e4 <oriole_expat::dispatch+0x4b74>
   389d2:	48 8b 73 20          	mov    0x20(%rbx),%rsi
   389d6:	ba 01 00 00 00       	mov    $0x1,%edx
   389db:	48 89 df             	mov    %rbx,%rdi
   389de:	ff 15 cc de 0a 00    	call   *0xadecc(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   389e4:	83 7b 38 ff          	cmpl   $0xffffffff,0x38(%rbx)
   389e8:	0f 84 d8 01 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   389ee:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
   389f2:	48 85 c9             	test   %rcx,%rcx
   389f5:	0f 84 cb 01 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   389fb:	48 8b 73 58          	mov    0x58(%rbx),%rsi
   389ff:	48 83 c3 38          	add    $0x38,%rbx
   38a03:	e9 82 01 00 00       	jmp    38b8a <oriole_expat::dispatch+0x4d1a>
   38a08:	80 7c 24 10 00       	cmpb   $0x0,0x10(%rsp)
   38a0d:	0f 84 b3 01 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   38a13:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   38a18:	4c 8b 73 28          	mov    0x28(%rbx),%r14
   38a1c:	48 83 c3 08          	add    $0x8,%rbx
   38a20:	4c 89 f7             	mov    %r14,%rdi
   38a23:	e8 58 7f ff ff       	call   30980 <core::ptr::drop_glue::<oriole::EntityDeclaration>>
   38a28:	ba 08 00 00 00       	mov    $0x8,%edx
   38a2d:	b9 20 01 00 00       	mov    $0x120,%ecx
   38a32:	e9 83 01 00 00       	jmp    38bba <oriole_expat::dispatch+0x4d4a>
   38a37:	80 7c 24 40 00       	cmpb   $0x0,0x40(%rsp)
   38a3c:	0f 84 84 01 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   38a42:	e9 09 bb ff ff       	jmp    34550 <oriole_expat::dispatch+0x6e0>
   38a47:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
   38a4c:	0f 84 74 01 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   38a52:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   38a57:	83 7b 40 ff          	cmpl   $0xffffffff,0x40(%rbx)
   38a5b:	74 1c                	je     38a79 <oriole_expat::dispatch+0x4c09>
   38a5d:	48 8b 4b 68          	mov    0x68(%rbx),%rcx
   38a61:	48 85 c9             	test   %rcx,%rcx
   38a64:	74 13                	je     38a79 <oriole_expat::dispatch+0x4c09>
   38a66:	48 8d 7b 40          	lea    0x40(%rbx),%rdi
   38a6a:	48 8b 73 60          	mov    0x60(%rbx),%rsi
   38a6e:	ba 01 00 00 00       	mov    $0x1,%edx
   38a73:	ff 15 37 de 0a 00    	call   *0xade37(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38a79:	48 8b 4b 30          	mov    0x30(%rbx),%rcx
   38a7d:	48 85 c9             	test   %rcx,%rcx
   38a80:	0f 84 40 01 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   38a86:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   38a8a:	48 83 c3 08          	add    $0x8,%rbx
   38a8e:	e9 f7 00 00 00       	jmp    38b8a <oriole_expat::dispatch+0x4d1a>
   38a93:	80 7c 24 0c 00       	cmpb   $0x0,0xc(%rsp)
   38a98:	0f 84 28 01 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   38a9e:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   38aa3:	4c 8b 73 28          	mov    0x28(%rbx),%r14
   38aa7:	48 83 c3 08          	add    $0x8,%rbx
   38aab:	4c 89 f7             	mov    %r14,%rdi
   38aae:	e8 6d 82 ff ff       	call   30d20 <core::ptr::drop_glue::<oriole::ExternalEntityReference>>
   38ab3:	ba 08 00 00 00       	mov    $0x8,%edx
   38ab8:	b9 a8 00 00 00       	mov    $0xa8,%ecx
   38abd:	e9 f8 00 00 00       	jmp    38bba <oriole_expat::dispatch+0x4d4a>
   38ac2:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
   38ac7:	0f 84 f9 00 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   38acd:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   38ad2:	48 8b 4b 30          	mov    0x30(%rbx),%rcx
   38ad6:	48 85 c9             	test   %rcx,%rcx
   38ad9:	0f 84 9a 00 00 00    	je     38b79 <oriole_expat::dispatch+0x4d09>
   38adf:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   38ae3:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   38ae7:	ba 01 00 00 00       	mov    $0x1,%edx
   38aec:	ff 15 be dd 0a 00    	call   *0xaddbe(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38af2:	e9 82 00 00 00       	jmp    38b79 <oriole_expat::dispatch+0x4d09>
   38af7:	80 7c 24 1c 00       	cmpb   $0x0,0x1c(%rsp)
   38afc:	0f 85 4e ba ff ff    	jne    34550 <oriole_expat::dispatch+0x6e0>
   38b02:	e9 bf 00 00 00       	jmp    38bc6 <oriole_expat::dispatch+0x4d56>
   38b07:	80 7c 24 38 00       	cmpb   $0x0,0x38(%rsp)
   38b0c:	0f 85 3e ba ff ff    	jne    34550 <oriole_expat::dispatch+0x6e0>
   38b12:	e9 af 00 00 00       	jmp    38bc6 <oriole_expat::dispatch+0x4d56>
   38b17:	80 7c 24 48 00       	cmpb   $0x0,0x48(%rsp)
   38b1c:	0f 84 a4 00 00 00    	je     38bc6 <oriole_expat::dispatch+0x4d56>
   38b22:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   38b27:	48 8b 4b 30          	mov    0x30(%rbx),%rcx
   38b2b:	48 85 c9             	test   %rcx,%rcx
   38b2e:	74 49                	je     38b79 <oriole_expat::dispatch+0x4d09>
   38b30:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   38b34:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   38b38:	ba 01 00 00 00       	mov    $0x1,%edx
   38b3d:	ff 15 6d dd 0a 00    	call   *0xadd6d(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38b43:	eb 34                	jmp    38b79 <oriole_expat::dispatch+0x4d09>
   38b45:	80 7c 24 28 00       	cmpb   $0x0,0x28(%rsp)
   38b4a:	74 7a                	je     38bc6 <oriole_expat::dispatch+0x4d56>
   38b4c:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   38b51:	83 7b 08 ff          	cmpl   $0xffffffff,0x8(%rbx)
   38b55:	74 1c                	je     38b73 <oriole_expat::dispatch+0x4d03>
   38b57:	48 8b 4b 30          	mov    0x30(%rbx),%rcx
   38b5b:	48 85 c9             	test   %rcx,%rcx
   38b5e:	74 13                	je     38b73 <oriole_expat::dispatch+0x4d03>
   38b60:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   38b64:	48 8b 73 28          	mov    0x28(%rbx),%rsi
   38b68:	ba 01 00 00 00       	mov    $0x1,%edx
   38b6d:	ff 15 3d dd 0a 00    	call   *0xadd3d(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38b73:	83 7b 40 ff          	cmpl   $0xffffffff,0x40(%rbx)
   38b77:	74 4d                	je     38bc6 <oriole_expat::dispatch+0x4d56>
   38b79:	48 8b 4b 68          	mov    0x68(%rbx),%rcx
   38b7d:	48 85 c9             	test   %rcx,%rcx
   38b80:	74 44                	je     38bc6 <oriole_expat::dispatch+0x4d56>
   38b82:	48 8b 73 60          	mov    0x60(%rbx),%rsi
   38b86:	48 83 c3 40          	add    $0x40,%rbx
   38b8a:	ba 01 00 00 00       	mov    $0x1,%edx
   38b8f:	48 89 df             	mov    %rbx,%rdi
   38b92:	eb 2c                	jmp    38bc0 <oriole_expat::dispatch+0x4d50>
   38b94:	80 7c 24 08 00       	cmpb   $0x0,0x8(%rsp)
   38b99:	74 2b                	je     38bc6 <oriole_expat::dispatch+0x4d56>
   38b9b:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
   38ba0:	4c 8b 73 28          	mov    0x28(%rbx),%r14
   38ba4:	48 83 c3 08          	add    $0x8,%rbx
   38ba8:	4c 89 f7             	mov    %r14,%rdi
   38bab:	e8 00 7f ff ff       	call   30ab0 <core::ptr::drop_glue::<oriole::DoctypeDeclaration>>
   38bb0:	ba 08 00 00 00       	mov    $0x8,%edx
   38bb5:	b9 b0 00 00 00       	mov    $0xb0,%ecx
   38bba:	48 89 df             	mov    %rbx,%rdi
   38bbd:	4c 89 f6             	mov    %r14,%rsi
   38bc0:	ff 15 ea dc 0a 00    	call   *0xadcea(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38bc6:	44 89 e8             	mov    %r13d,%eax
   38bc9:	48 81 c4 08 06 00 00 	add    $0x608,%rsp
   38bd0:	5b                   	pop    %rbx
   38bd1:	41 5c                	pop    %r12
   38bd3:	41 5d                	pop    %r13
   38bd5:	41 5e                	pop    %r14
   38bd7:	41 5f                	pop    %r15
   38bd9:	5d                   	pop    %rbp
   38bda:	c3                   	ret
   38bdb:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   38be2:	00 
   38be3:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   38bea:	00 
   38beb:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   38bf2:	00 
   38bf3:	0f 11 94 24 e8 01 00 	movups %xmm2,0x1e8(%rsp)
   38bfa:	00 
   38bfb:	0f 11 8c 24 d9 01 00 	movups %xmm1,0x1d9(%rsp)
   38c02:	00 
   38c03:	0f 11 84 24 c9 01 00 	movups %xmm0,0x1c9(%rsp)
   38c0a:	00 
   38c0b:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
   38c12:	00 
   38c13:	88 8c 24 c8 01 00 00 	mov    %cl,0x1c8(%rsp)
   38c1a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38c1e:	0f 84 9b 05 00 00    	je     391bf <oriole_expat::dispatch+0x534f>
   38c24:	4c 8b 84 24 e0 01 00 	mov    0x1e0(%rsp),%r8
   38c2b:	00 
   38c2c:	e9 91 05 00 00       	jmp    391c2 <oriole_expat::dispatch+0x5352>
   38c31:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   38c38:	00 
   38c39:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   38c40:	00 
   38c41:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   38c48:	00 
   38c49:	0f 11 94 24 e8 01 00 	movups %xmm2,0x1e8(%rsp)
   38c50:	00 
   38c51:	0f 11 8c 24 d9 01 00 	movups %xmm1,0x1d9(%rsp)
   38c58:	00 
   38c59:	0f 11 84 24 c9 01 00 	movups %xmm0,0x1c9(%rsp)
   38c60:	00 
   38c61:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
   38c68:	00 
   38c69:	40 88 ac 24 c8 01 00 	mov    %bpl,0x1c8(%rsp)
   38c70:	00 
   38c71:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38c75:	48 8b 84 24 00 04 00 	mov    0x400(%rsp),%rax
   38c7c:	00 
   38c7d:	0f 84 82 05 00 00    	je     39205 <oriole_expat::dispatch+0x5395>
   38c83:	4c 8b 84 24 e0 01 00 	mov    0x1e0(%rsp),%r8
   38c8a:	00 
   38c8b:	e9 78 05 00 00       	jmp    39208 <oriole_expat::dispatch+0x5398>
   38c90:	48 89 d8             	mov    %rbx,%rax
   38c93:	48 c1 e8 3c          	shr    $0x3c,%rax
   38c97:	b0 01                	mov    $0x1,%al
   38c99:	0f 85 ec 09 00 00    	jne    3968b <oriole_expat::dispatch+0x581b>
   38c9f:	4a 8d 04 7d 01 00 00 	lea    0x1(,%r15,2),%rax
   38ca6:	00 
   38ca7:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
   38cae:	00 
   38caf:	41 bd 08 00 00 00    	mov    $0x8,%r13d
   38cb5:	45 31 e4             	xor    %r12d,%r12d
   38cb8:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   38cbf:	00 
   38cc0:	be 08 00 00 00       	mov    $0x8,%esi
   38cc5:	ff 15 05 dc 0a 00    	call   *0xadc05(%rip)        # e68d0 <_GLOBAL_OFFSET_TABLE_+0x158>
   38ccb:	48 85 c0             	test   %rax,%rax
   38cce:	0f 84 b5 09 00 00    	je     39689 <oriole_expat::dispatch+0x5819>
   38cd4:	49 89 c5             	mov    %rax,%r13
   38cd7:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
   38cde:	00 
   38cdf:	4e 8d 24 7d 01 00 00 	lea    0x1(,%r15,2),%r12
   38ce6:	00 
   38ce7:	4c 89 a4 24 e8 01 00 	mov    %r12,0x1e8(%rsp)
   38cee:	00 
   38cef:	49 c1 e7 04          	shl    $0x4,%r15
   38cf3:	48 89 c7             	mov    %rax,%rdi
   38cf6:	31 f6                	xor    %esi,%esi
   38cf8:	4c 89 fa             	mov    %r15,%rdx
   38cfb:	ff 15 7f e4 0a 00    	call   *0xae47f(%rip)        # e7180 <memset@GLIBC_2.2.5>
   38d01:	4b c7 44 3d 00 00 00 	movq   $0x0,0x0(%r13,%r15,1)
   38d08:	00 00 
   38d0a:	48 83 cb 01          	or     $0x1,%rbx
   38d0e:	48 89 9c 24 f0 01 00 	mov    %rbx,0x1f0(%rsp)
   38d15:	00 
   38d16:	4c 89 e8             	mov    %r13,%rax
   38d19:	4c 8b ac 24 d0 00 00 	mov    0xd0(%rsp),%r13
   38d20:	00 
   38d21:	4c 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%r15
   38d28:	00 
   38d29:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
   38d2e:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   38d33:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   38d38:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   38d3d:	4d 85 ff             	test   %r15,%r15
   38d40:	0f 84 82 00 00 00    	je     38dc8 <oriole_expat::dispatch+0x4f58>
   38d46:	49 6b df 78          	imul   $0x78,%r15,%rbx
   38d4a:	4c 01 eb             	add    %r13,%rbx
   38d4d:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   38d53:	4c 8d 25 06 cc 06 00 	lea    0x6cc06(%rip),%r12        # a5960 <<oriole_storage::string::String>::try_push>
   38d5a:	48 8d 05 8f 9f 0a 00 	lea    0xa9f8f(%rip),%rax        # e2cf0 <oriole_expat::FEATURES+0x108>
   38d61:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   38d66:	4c 89 ef             	mov    %r13,%rdi
   38d69:	31 f6                	xor    %esi,%esi
   38d6b:	41 ff d4             	call   *%r12
   38d6e:	3c ff                	cmp    $0xff,%al
   38d70:	0f 85 75 05 00 00    	jne    392eb <oriole_expat::dispatch+0x547b>
   38d76:	49 83 c5 38          	add    $0x38,%r13
   38d7a:	4c 89 ef             	mov    %r13,%rdi
   38d7d:	31 f6                	xor    %esi,%esi
   38d7f:	41 ff d4             	call   *%r12
   38d82:	3c ff                	cmp    $0xff,%al
   38d84:	0f 85 61 05 00 00    	jne    392eb <oriole_expat::dispatch+0x547b>
   38d8a:	49 8d 7f ff          	lea    -0x1(%r15),%rdi
   38d8e:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   38d93:	48 39 cf             	cmp    %rcx,%rdi
   38d96:	0f 83 98 0a 00 00    	jae    39834 <oriole_expat::dispatch+0x59c4>
   38d9c:	49 8b 45 e8          	mov    -0x18(%r13),%rax
   38da0:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   38da5:	4a 89 44 fa f8       	mov    %rax,-0x8(%rdx,%r15,8)
   38daa:	49 39 cf             	cmp    %rcx,%r15
   38dad:	0f 83 8f 0a 00 00    	jae    39842 <oriole_expat::dispatch+0x59d2>
   38db3:	49 8b 45 20          	mov    0x20(%r13),%rax
   38db7:	4a 89 04 fa          	mov    %rax,(%rdx,%r15,8)
   38dbb:	49 83 c7 02          	add    $0x2,%r15
   38dbf:	49 83 c5 40          	add    $0x40,%r13
   38dc3:	49 39 dd             	cmp    %rbx,%r13
   38dc6:	75 9e                	jne    38d66 <oriole_expat::dispatch+0x4ef6>
   38dc8:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   38dcf:	00 
   38dd0:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   38dd5:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
   38dda:	ff d5                	call   *%rbp
   38ddc:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   38de1:	48 85 c9             	test   %rcx,%rcx
   38de4:	74 1c                	je     38e02 <oriole_expat::dispatch+0x4f92>
   38de6:	48 c1 e1 03          	shl    $0x3,%rcx
   38dea:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   38df1:	00 
   38df2:	ba 08 00 00 00       	mov    $0x8,%edx
   38df7:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   38dfc:	ff 15 ae da 0a 00    	call   *0xadaae(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38e02:	b3 01                	mov    $0x1,%bl
   38e04:	e9 62 e8 ff ff       	jmp    3766b <oriole_expat::dispatch+0x37fb>
   38e09:	45 31 c0             	xor    %r8d,%r8d
   38e0c:	4c 89 ff             	mov    %r15,%rdi
   38e0f:	4c 89 e6             	mov    %r12,%rsi
   38e12:	48 89 da             	mov    %rbx,%rdx
   38e15:	48 89 e9             	mov    %rbp,%rcx
   38e18:	ff 94 24 b8 01 00 00 	call   *0x1b8(%rsp)
   38e1f:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   38e26:	00 
   38e27:	e8 14 65 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38e2c:	31 ed                	xor    %ebp,%ebp
   38e2e:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   38e35:	00 
   38e36:	e8 05 65 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38e3b:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   38e42:	00 
   38e43:	48 85 c9             	test   %rcx,%rcx
   38e46:	74 18                	je     38e60 <oriole_expat::dispatch+0x4ff0>
   38e48:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   38e4f:	00 
   38e50:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   38e55:	ba 01 00 00 00       	mov    $0x1,%edx
   38e5a:	ff 15 50 da 0a 00    	call   *0xada50(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38e60:	b3 01                	mov    $0x1,%bl
   38e62:	b0 01                	mov    $0x1,%al
   38e64:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   38e6b:	00 
   38e6c:	b1 01                	mov    $0x1,%cl
   38e6e:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   38e72:	b1 01                	mov    $0x1,%cl
   38e74:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   38e78:	b1 01                	mov    $0x1,%cl
   38e7a:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   38e7e:	b1 01                	mov    $0x1,%cl
   38e80:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   38e84:	b1 01                	mov    $0x1,%cl
   38e86:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   38e8a:	b1 01                	mov    $0x1,%cl
   38e8c:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   38e90:	b1 01                	mov    $0x1,%cl
   38e92:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   38e96:	b1 01                	mov    $0x1,%cl
   38e98:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   38e9c:	b1 01                	mov    $0x1,%cl
   38e9e:	89 4c 24 24          	mov    %ecx,0x24(%rsp)
   38ea2:	e9 22 c8 ff ff       	jmp    356c9 <oriole_expat::dispatch+0x1859>
   38ea7:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
   38eac:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   38eb3:	00 
   38eb4:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   38ebb:	00 
   38ebc:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   38ec3:	00 
   38ec4:	0f 11 94 24 98 00 00 	movups %xmm2,0x98(%rsp)
   38ecb:	00 
   38ecc:	0f 11 8c 24 89 00 00 	movups %xmm1,0x89(%rsp)
   38ed3:	00 
   38ed4:	0f 11 44 24 79       	movups %xmm0,0x79(%rsp)
   38ed9:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   38ede:	44 88 6c 24 78       	mov    %r13b,0x78(%rsp)
   38ee3:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   38ee7:	0f 84 6f 04 00 00    	je     3935c <oriole_expat::dispatch+0x54ec>
   38eed:	48 8b 9c 24 90 00 00 	mov    0x90(%rsp),%rbx
   38ef4:	00 
   38ef5:	e9 64 04 00 00       	jmp    3935e <oriole_expat::dispatch+0x54ee>
   38efa:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   38f01:	00 00 
   38f03:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
   38f08:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   38f0f:	00 
   38f10:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
   38f17:	00 
   38f18:	e8 03 9f ff ff       	call   32e20 <oriole_expat::optional_cstring>
   38f1d:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   38f24:	00 
   38f25:	0f b6 8c 24 e8 02 00 	movzbl 0x2e8(%rsp),%ecx
   38f2c:	00 
   38f2d:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   38f31:	0f 85 32 02 00 00    	jne    39169 <oriole_expat::dispatch+0x52f9>
   38f37:	41 89 ce             	mov    %ecx,%r14d
   38f3a:	31 db                	xor    %ebx,%ebx
   38f3c:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   38f43:	00 
   38f44:	e8 f7 63 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38f49:	89 5c 24 40          	mov    %ebx,0x40(%rsp)
   38f4d:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   38f54:	00 
   38f55:	31 db                	xor    %ebx,%ebx
   38f57:	48 85 c9             	test   %rcx,%rcx
   38f5a:	74 13                	je     38f6f <oriole_expat::dispatch+0x50ff>
   38f5c:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   38f61:	ba 01 00 00 00       	mov    $0x1,%edx
   38f66:	4c 89 fe             	mov    %r15,%rsi
   38f69:	ff 15 41 d9 0a 00    	call   *0xad941(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38f6f:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   38f76:	00 
   38f77:	48 85 c9             	test   %rcx,%rcx
   38f7a:	74 27                	je     38fa3 <oriole_expat::dispatch+0x5133>
   38f7c:	b0 01                	mov    $0x1,%al
   38f7e:	89 44 24 38          	mov    %eax,0x38(%rsp)
   38f82:	45 31 ff             	xor    %r15d,%r15d
   38f85:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   38f8c:	00 
   38f8d:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   38f94:	00 
   38f95:	ba 01 00 00 00       	mov    $0x1,%edx
   38f9a:	41 b5 01             	mov    $0x1,%r13b
   38f9d:	ff 15 0d d9 0a 00    	call   *0xad90d(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   38fa3:	41 b5 01             	mov    $0x1,%r13b
   38fa6:	8b 6c 24 40          	mov    0x40(%rsp),%ebp
   38faa:	45 31 ff             	xor    %r15d,%r15d
   38fad:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   38fb4:	00 
   38fb5:	e8 86 63 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38fba:	45 31 ff             	xor    %r15d,%r15d
   38fbd:	40 84 ed             	test   %bpl,%bpl
   38fc0:	74 0d                	je     38fcf <oriole_expat::dispatch+0x515f>
   38fc2:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   38fc9:	00 
   38fca:	e8 71 63 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38fcf:	84 db                	test   %bl,%bl
   38fd1:	74 0d                	je     38fe0 <oriole_expat::dispatch+0x5170>
   38fd3:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
   38fda:	00 
   38fdb:	e8 60 63 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38fe0:	45 84 ed             	test   %r13b,%r13b
   38fe3:	74 0d                	je     38ff2 <oriole_expat::dispatch+0x5182>
   38fe5:	48 8d bc 24 60 05 00 	lea    0x560(%rsp),%rdi
   38fec:	00 
   38fed:	e8 4e 63 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   38ff2:	45 84 ff             	test   %r15b,%r15b
   38ff5:	74 7f                	je     39076 <oriole_expat::dispatch+0x5206>
   38ff7:	48 8b 8c 24 f8 04 00 	mov    0x4f8(%rsp),%rcx
   38ffe:	00 
   38fff:	48 85 c9             	test   %rcx,%rcx
   39002:	74 72                	je     39076 <oriole_expat::dispatch+0x5206>
   39004:	b0 01                	mov    $0x1,%al
   39006:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3900a:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   39011:	00 
   39012:	48 8b b4 24 f0 04 00 	mov    0x4f0(%rsp),%rsi
   39019:	00 
   3901a:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
   39021:	00 
   39022:	ba 01 00 00 00       	mov    $0x1,%edx
   39027:	b0 01                	mov    $0x1,%al
   39029:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3902d:	b0 01                	mov    $0x1,%al
   3902f:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39033:	b0 01                	mov    $0x1,%al
   39035:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39039:	b0 01                	mov    $0x1,%al
   3903b:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3903f:	b0 01                	mov    $0x1,%al
   39041:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39045:	b0 01                	mov    $0x1,%al
   39047:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3904b:	b0 01                	mov    $0x1,%al
   3904d:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   39051:	b0 01                	mov    $0x1,%al
   39053:	89 44 24 08          	mov    %eax,0x8(%rsp)
   39057:	b0 01                	mov    $0x1,%al
   39059:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3905d:	b0 01                	mov    $0x1,%al
   3905f:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   39064:	40 b5 01             	mov    $0x1,%bpl
   39067:	41 b7 01             	mov    $0x1,%r15b
   3906a:	41 b4 01             	mov    $0x1,%r12b
   3906d:	41 b5 01             	mov    $0x1,%r13b
   39070:	ff 15 3a d8 0a 00    	call   *0xad83a(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39076:	b0 01                	mov    $0x1,%al
   39078:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3907c:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   39083:	00 
   39084:	b0 01                	mov    $0x1,%al
   39086:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3908a:	b0 01                	mov    $0x1,%al
   3908c:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39090:	b0 01                	mov    $0x1,%al
   39092:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39096:	b0 01                	mov    $0x1,%al
   39098:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3909c:	b0 01                	mov    $0x1,%al
   3909e:	89 44 24 14          	mov    %eax,0x14(%rsp)
   390a2:	b0 01                	mov    $0x1,%al
   390a4:	89 44 24 30          	mov    %eax,0x30(%rsp)
   390a8:	b0 01                	mov    $0x1,%al
   390aa:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   390ae:	b0 01                	mov    $0x1,%al
   390b0:	89 44 24 08          	mov    %eax,0x8(%rsp)
   390b4:	b0 01                	mov    $0x1,%al
   390b6:	89 44 24 28          	mov    %eax,0x28(%rsp)
   390ba:	b0 01                	mov    $0x1,%al
   390bc:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   390c1:	b0 01                	mov    $0x1,%al
   390c3:	89 44 24 24          	mov    %eax,0x24(%rsp)
   390c7:	b0 01                	mov    $0x1,%al
   390c9:	89 44 24 18          	mov    %eax,0x18(%rsp)
   390cd:	b0 01                	mov    $0x1,%al
   390cf:	89 44 24 20          	mov    %eax,0x20(%rsp)
   390d3:	b0 01                	mov    $0x1,%al
   390d5:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   390d9:	45 89 f5             	mov    %r14d,%r13d
   390dc:	e9 9d f7 ff ff       	jmp    3887e <oriole_expat::dispatch+0x4a0e>
   390e1:	31 c9                	xor    %ecx,%ecx
   390e3:	4c 89 ff             	mov    %r15,%rdi
   390e6:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   390eb:	48 89 da             	mov    %rbx,%rdx
   390ee:	45 89 e0             	mov    %r12d,%r8d
   390f1:	ff d5                	call   *%rbp
   390f3:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   390fa:	00 
   390fb:	e8 40 62 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39100:	31 db                	xor    %ebx,%ebx
   39102:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   39109:	00 
   3910a:	e8 31 62 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3910f:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   39116:	00 
   39117:	48 85 c9             	test   %rcx,%rcx
   3911a:	74 18                	je     39134 <oriole_expat::dispatch+0x52c4>
   3911c:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   39123:	00 
   39124:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   39129:	ba 01 00 00 00       	mov    $0x1,%edx
   3912e:	ff 15 7c d7 0a 00    	call   *0xad77c(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39134:	b3 01                	mov    $0x1,%bl
   39136:	b0 01                	mov    $0x1,%al
   39138:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   3913f:	00 
   39140:	b1 01                	mov    $0x1,%cl
   39142:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   39146:	b1 01                	mov    $0x1,%cl
   39148:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   3914c:	b1 01                	mov    $0x1,%cl
   3914e:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   39152:	b1 01                	mov    $0x1,%cl
   39154:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   39158:	b1 01                	mov    $0x1,%cl
   3915a:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   3915e:	b1 01                	mov    $0x1,%cl
   39160:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   39164:	e9 4e c5 ff ff       	jmp    356b7 <oriole_expat::dispatch+0x1847>
   39169:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   39170:	00 
   39171:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   39178:	00 
   39179:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   39180:	00 
   39181:	0f 11 94 24 e8 01 00 	movups %xmm2,0x1e8(%rsp)
   39188:	00 
   39189:	0f 11 8c 24 d9 01 00 	movups %xmm1,0x1d9(%rsp)
   39190:	00 
   39191:	0f 11 84 24 c9 01 00 	movups %xmm0,0x1c9(%rsp)
   39198:	00 
   39199:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
   391a0:	00 
   391a1:	88 8c 24 c8 01 00 00 	mov    %cl,0x1c8(%rsp)
   391a8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   391ac:	0f 84 ec 01 00 00    	je     3939e <oriole_expat::dispatch+0x552e>
   391b2:	4c 8b 84 24 e0 01 00 	mov    0x1e0(%rsp),%r8
   391b9:	00 
   391ba:	e9 e2 01 00 00       	jmp    393a1 <oriole_expat::dispatch+0x5531>
   391bf:	45 31 c0             	xor    %r8d,%r8d
   391c2:	4c 89 ff             	mov    %r15,%rdi
   391c5:	4c 89 ee             	mov    %r13,%rsi
   391c8:	4c 89 e2             	mov    %r12,%rdx
   391cb:	48 89 d9             	mov    %rbx,%rcx
   391ce:	ff d5                	call   *%rbp
   391d0:	85 c0                	test   %eax,%eax
   391d2:	0f 84 46 01 00 00    	je     3931e <oriole_expat::dispatch+0x54ae>
   391d8:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   391df:	00 
   391e0:	e8 5b 61 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   391e5:	31 db                	xor    %ebx,%ebx
   391e7:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   391ee:	00 
   391ef:	e8 4c 61 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   391f4:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   391f9:	e8 42 61 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   391fe:	b3 01                	mov    $0x1,%bl
   39200:	e9 aa dc ff ff       	jmp    36eaf <oriole_expat::dispatch+0x303f>
   39205:	45 31 c0             	xor    %r8d,%r8d
   39208:	48 89 df             	mov    %rbx,%rdi
   3920b:	4c 89 fe             	mov    %r15,%rsi
   3920e:	4c 89 ea             	mov    %r13,%rdx
   39211:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   39216:	45 89 e1             	mov    %r12d,%r9d
   39219:	ff d0                	call   *%rax
   3921b:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   39222:	00 
   39223:	e8 18 61 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39228:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   3922f:	00 
   39230:	48 85 c9             	test   %rcx,%rcx
   39233:	74 1d                	je     39252 <oriole_expat::dispatch+0x53e2>
   39235:	31 db                	xor    %ebx,%ebx
   39237:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   3923e:	00 
   3923f:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   39246:	00 
   39247:	ba 01 00 00 00       	mov    $0x1,%edx
   3924c:	ff 15 5e d6 0a 00    	call   *0xad65e(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39252:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   39259:	00 
   3925a:	48 85 c9             	test   %rcx,%rcx
   3925d:	74 1c                	je     3927b <oriole_expat::dispatch+0x540b>
   3925f:	31 db                	xor    %ebx,%ebx
   39261:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   39268:	00 
   39269:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   3926e:	ba 01 00 00 00       	mov    $0x1,%edx
   39273:	31 ed                	xor    %ebp,%ebp
   39275:	ff 15 35 d6 0a 00    	call   *0xad635(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3927b:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   39282:	00 
   39283:	48 85 c9             	test   %rcx,%rcx
   39286:	74 22                	je     392aa <oriole_expat::dispatch+0x543a>
   39288:	31 db                	xor    %ebx,%ebx
   3928a:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   39291:	00 
   39292:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   39299:	00 
   3929a:	ba 01 00 00 00       	mov    $0x1,%edx
   3929f:	31 ed                	xor    %ebp,%ebp
   392a1:	45 31 ed             	xor    %r13d,%r13d
   392a4:	ff 15 06 d6 0a 00    	call   *0xad606(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   392aa:	b3 01                	mov    $0x1,%bl
   392ac:	b0 01                	mov    $0x1,%al
   392ae:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   392b5:	00 
   392b6:	b1 01                	mov    $0x1,%cl
   392b8:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   392bc:	b1 01                	mov    $0x1,%cl
   392be:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   392c2:	b1 01                	mov    $0x1,%cl
   392c4:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   392c8:	b1 01                	mov    $0x1,%cl
   392ca:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   392ce:	b1 01                	mov    $0x1,%cl
   392d0:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   392d4:	b1 01                	mov    $0x1,%cl
   392d6:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   392da:	b1 01                	mov    $0x1,%cl
   392dc:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   392e0:	b1 01                	mov    $0x1,%cl
   392e2:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
   392e6:	e9 d8 c3 ff ff       	jmp    356c3 <oriole_expat::dispatch+0x1853>
   392eb:	89 c3                	mov    %eax,%ebx
   392ed:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   392f2:	48 85 c9             	test   %rcx,%rcx
   392f5:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   392fa:	0f 84 85 03 00 00    	je     39685 <oriole_expat::dispatch+0x5815>
   39300:	48 c1 e1 03          	shl    $0x3,%rcx
   39304:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   3930b:	00 
   3930c:	ba 08 00 00 00       	mov    $0x8,%edx
   39311:	ff 15 99 d5 0a 00    	call   *0xad599(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39317:	89 d8                	mov    %ebx,%eax
   39319:	e9 6d 03 00 00       	jmp    3968b <oriole_expat::dispatch+0x581b>
   3931e:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   39325:	00 
   39326:	e8 15 60 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3932b:	31 db                	xor    %ebx,%ebx
   3932d:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   39334:	00 
   39335:	e8 06 60 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3933a:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   3933f:	e8 fc 5f ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39344:	48 b8 15 00 00 00 15 	movabs $0x1500000015,%rax
   3934b:	00 00 00 
   3934e:	49 89 86 10 0a 00 00 	mov    %rax,0xa10(%r14)
   39355:	b3 01                	mov    $0x1,%bl
   39357:	e9 53 db ff ff       	jmp    36eaf <oriole_expat::dispatch+0x303f>
   3935c:	31 db                	xor    %ebx,%ebx
   3935e:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
   39363:	41 b7 01             	mov    $0x1,%r15b
   39366:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3936d:	00 
   3936e:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
   39375:	00 
   39376:	e8 a5 9a ff ff       	call   32e20 <oriole_expat::optional_cstring>
   3937b:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   39382:	00 
   39383:	44 0f b6 ac 24 e8 02 	movzbl 0x2e8(%rsp),%r13d
   3938a:	00 00 
   3938c:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   39390:	0f 85 95 01 00 00    	jne    3952b <oriole_expat::dispatch+0x56bb>
   39396:	41 b7 01             	mov    $0x1,%r15b
   39399:	e9 20 02 00 00       	jmp    395be <oriole_expat::dispatch+0x574e>
   3939e:	45 31 c0             	xor    %r8d,%r8d
   393a1:	4c 8b 8c 24 10 01 00 	mov    0x110(%rsp),%r9
   393a8:	00 
   393a9:	48 89 df             	mov    %rbx,%rdi
   393ac:	4c 89 fe             	mov    %r15,%rsi
   393af:	4c 89 ea             	mov    %r13,%rdx
   393b2:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   393b7:	ff d5                	call   *%rbp
   393b9:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   393c0:	00 
   393c1:	e8 7a 5f ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   393c6:	31 db                	xor    %ebx,%ebx
   393c8:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   393cf:	00 
   393d0:	e8 6b 5f ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   393d5:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   393dc:	00 
   393dd:	48 85 c9             	test   %rcx,%rcx
   393e0:	74 22                	je     39404 <oriole_expat::dispatch+0x5594>
   393e2:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   393e9:	00 
   393ea:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   393f1:	00 
   393f2:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   393f7:	ba 01 00 00 00       	mov    $0x1,%edx
   393fc:	31 db                	xor    %ebx,%ebx
   393fe:	ff 15 ac d4 0a 00    	call   *0xad4ac(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39404:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   3940b:	00 
   3940c:	48 85 c9             	test   %rcx,%rcx
   3940f:	74 31                	je     39442 <oriole_expat::dispatch+0x55d2>
   39411:	b0 01                	mov    $0x1,%al
   39413:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39417:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   3941e:	00 
   3941f:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   39426:	00 
   39427:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   3942e:	00 
   3942f:	ba 01 00 00 00       	mov    $0x1,%edx
   39434:	31 db                	xor    %ebx,%ebx
   39436:	41 b5 01             	mov    $0x1,%r13b
   39439:	45 31 ff             	xor    %r15d,%r15d
   3943c:	ff 15 6e d4 0a 00    	call   *0xad46e(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39442:	41 b5 01             	mov    $0x1,%r13b
   39445:	31 ed                	xor    %ebp,%ebp
   39447:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3944e:	00 
   3944f:	31 db                	xor    %ebx,%ebx
   39451:	45 31 ff             	xor    %r15d,%r15d
   39454:	e8 e7 5e ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39459:	b3 01                	mov    $0x1,%bl
   3945b:	45 31 ed             	xor    %r13d,%r13d
   3945e:	48 8d bc 24 60 05 00 	lea    0x560(%rsp),%rdi
   39465:	00 
   39466:	45 89 ef             	mov    %r13d,%r15d
   39469:	e8 d2 5e ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3946e:	45 84 e4             	test   %r12b,%r12b
   39471:	74 7f                	je     394f2 <oriole_expat::dispatch+0x5682>
   39473:	48 8b 8c 24 f8 04 00 	mov    0x4f8(%rsp),%rcx
   3947a:	00 
   3947b:	48 85 c9             	test   %rcx,%rcx
   3947e:	74 72                	je     394f2 <oriole_expat::dispatch+0x5682>
   39480:	b0 01                	mov    $0x1,%al
   39482:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39486:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   3948d:	00 
   3948e:	48 8b b4 24 f0 04 00 	mov    0x4f0(%rsp),%rsi
   39495:	00 
   39496:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
   3949d:	00 
   3949e:	ba 01 00 00 00       	mov    $0x1,%edx
   394a3:	b0 01                	mov    $0x1,%al
   394a5:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   394a9:	b0 01                	mov    $0x1,%al
   394ab:	89 44 24 40          	mov    %eax,0x40(%rsp)
   394af:	b0 01                	mov    $0x1,%al
   394b1:	89 44 24 50          	mov    %eax,0x50(%rsp)
   394b5:	b0 01                	mov    $0x1,%al
   394b7:	89 44 24 48          	mov    %eax,0x48(%rsp)
   394bb:	b0 01                	mov    $0x1,%al
   394bd:	89 44 24 14          	mov    %eax,0x14(%rsp)
   394c1:	b0 01                	mov    $0x1,%al
   394c3:	89 44 24 30          	mov    %eax,0x30(%rsp)
   394c7:	b0 01                	mov    $0x1,%al
   394c9:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   394cd:	b0 01                	mov    $0x1,%al
   394cf:	89 44 24 08          	mov    %eax,0x8(%rsp)
   394d3:	b0 01                	mov    $0x1,%al
   394d5:	89 44 24 28          	mov    %eax,0x28(%rsp)
   394d9:	b0 01                	mov    $0x1,%al
   394db:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   394e0:	40 b5 01             	mov    $0x1,%bpl
   394e3:	41 b7 01             	mov    $0x1,%r15b
   394e6:	41 b4 01             	mov    $0x1,%r12b
   394e9:	41 b5 01             	mov    $0x1,%r13b
   394ec:	ff 15 be d3 0a 00    	call   *0xad3be(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   394f2:	b0 01                	mov    $0x1,%al
   394f4:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   394fb:	00 
   394fc:	b1 01                	mov    $0x1,%cl
   394fe:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
   39502:	b1 01                	mov    $0x1,%cl
   39504:	89 4c 24 38          	mov    %ecx,0x38(%rsp)
   39508:	b1 01                	mov    $0x1,%cl
   3950a:	89 4c 24 48          	mov    %ecx,0x48(%rsp)
   3950e:	b1 01                	mov    $0x1,%cl
   39510:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
   39514:	b1 01                	mov    $0x1,%cl
   39516:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   3951a:	b1 01                	mov    $0x1,%cl
   3951c:	89 4c 24 0c          	mov    %ecx,0xc(%rsp)
   39520:	b1 01                	mov    $0x1,%cl
   39522:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
   39526:	e9 92 c1 ff ff       	jmp    356bd <oriole_expat::dispatch+0x184d>
   3952b:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   39532:	00 
   39533:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   3953a:	00 
   3953b:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   39542:	00 
   39543:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
   3954a:	00 
   3954b:	0f 11 8c 24 c9 00 00 	movups %xmm1,0xc9(%rsp)
   39552:	00 
   39553:	0f 11 84 24 b9 00 00 	movups %xmm0,0xb9(%rsp)
   3955a:	00 
   3955b:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   39562:	00 
   39563:	44 88 ac 24 b8 00 00 	mov    %r13b,0xb8(%rsp)
   3956a:	00 
   3956b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3956f:	74 0a                	je     3957b <oriole_expat::dispatch+0x570b>
   39571:	4c 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%r15
   39578:	00 
   39579:	eb 03                	jmp    3957e <oriole_expat::dispatch+0x570e>
   3957b:	45 31 ff             	xor    %r15d,%r15d
   3957e:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   39585:	00 
   39586:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
   3958d:	00 
   3958e:	e8 8d 98 ff ff       	call   32e20 <oriole_expat::optional_cstring>
   39593:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
   3959a:	00 
   3959b:	44 0f b6 ac 24 e8 02 	movzbl 0x2e8(%rsp),%r13d
   395a2:	00 00 
   395a4:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
   395a8:	0f 85 80 00 00 00    	jne    3962e <oriole_expat::dispatch+0x57be>
   395ae:	45 31 ff             	xor    %r15d,%r15d
   395b1:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   395b8:	00 
   395b9:	e8 82 5d ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   395be:	31 ed                	xor    %ebp,%ebp
   395c0:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   395c5:	e8 76 5d ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   395ca:	45 89 ee             	mov    %r13d,%r14d
   395cd:	31 db                	xor    %ebx,%ebx
   395cf:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   395d6:	00 
   395d7:	e8 64 5d ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   395dc:	89 6c 24 40          	mov    %ebp,0x40(%rsp)
   395e0:	48 8b 8c 24 98 01 00 	mov    0x198(%rsp),%rcx
   395e7:	00 
   395e8:	48 85 c9             	test   %rcx,%rcx
   395eb:	44 89 7c 24 38       	mov    %r15d,0x38(%rsp)
   395f0:	74 20                	je     39612 <oriole_expat::dispatch+0x57a2>
   395f2:	31 db                	xor    %ebx,%ebx
   395f4:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   395fb:	00 
   395fc:	ba 01 00 00 00       	mov    $0x1,%edx
   39601:	45 31 ed             	xor    %r13d,%r13d
   39604:	45 31 ff             	xor    %r15d,%r15d
   39607:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   3960c:	ff 15 9e d2 0a 00    	call   *0xad29e(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39612:	31 db                	xor    %ebx,%ebx
   39614:	41 bd 00 00 00 00    	mov    $0x0,%r13d
   3961a:	80 7c 24 38 00       	cmpb   $0x0,0x38(%rsp)
   3961f:	8b 6c 24 40          	mov    0x40(%rsp),%ebp
   39623:	0f 85 81 f9 ff ff    	jne    38faa <oriole_expat::dispatch+0x513a>
   39629:	e9 8c f9 ff ff       	jmp    38fba <oriole_expat::dispatch+0x514a>
   3962e:	0f 10 84 24 e9 02 00 	movups 0x2e9(%rsp),%xmm0
   39635:	00 
   39636:	0f 10 8c 24 f9 02 00 	movups 0x2f9(%rsp),%xmm1
   3963d:	00 
   3963e:	0f 10 94 24 08 03 00 	movups 0x308(%rsp),%xmm2
   39645:	00 
   39646:	0f 11 94 24 e8 01 00 	movups %xmm2,0x1e8(%rsp)
   3964d:	00 
   3964e:	0f 11 8c 24 d9 01 00 	movups %xmm1,0x1d9(%rsp)
   39655:	00 
   39656:	0f 11 84 24 c9 01 00 	movups %xmm0,0x1c9(%rsp)
   3965d:	00 
   3965e:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
   39665:	00 
   39666:	44 88 ac 24 c8 01 00 	mov    %r13b,0x1c8(%rsp)
   3966d:	00 
   3966e:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   39672:	0f 84 09 01 00 00    	je     39781 <oriole_expat::dispatch+0x5911>
   39678:	48 8b 84 24 e0 01 00 	mov    0x1e0(%rsp),%rax
   3967f:	00 
   39680:	e9 fe 00 00 00       	jmp    39783 <oriole_expat::dispatch+0x5913>
   39685:	89 d8                	mov    %ebx,%eax
   39687:	eb 02                	jmp    3968b <oriole_expat::dispatch+0x581b>
   39689:	31 c0                	xor    %eax,%eax
   3968b:	89 c3                	mov    %eax,%ebx
   3968d:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   39694:	00 
   39695:	e8 c6 69 ff ff       	call   30060 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3969a:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   396a1:	00 
   396a2:	48 85 c9             	test   %rcx,%rcx
   396a5:	74 6f                	je     39716 <oriole_expat::dispatch+0x58a6>
   396a7:	b0 01                	mov    $0x1,%al
   396a9:	89 44 24 50          	mov    %eax,0x50(%rsp)
   396ad:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   396b4:	00 
   396b5:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   396ba:	ba 01 00 00 00       	mov    $0x1,%edx
   396bf:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
   396c6:	00 
   396c7:	b0 01                	mov    $0x1,%al
   396c9:	89 44 24 40          	mov    %eax,0x40(%rsp)
   396cd:	b0 01                	mov    $0x1,%al
   396cf:	89 44 24 38          	mov    %eax,0x38(%rsp)
   396d3:	b0 01                	mov    $0x1,%al
   396d5:	89 44 24 48          	mov    %eax,0x48(%rsp)
   396d9:	b0 01                	mov    $0x1,%al
   396db:	89 44 24 14          	mov    %eax,0x14(%rsp)
   396df:	b0 01                	mov    $0x1,%al
   396e1:	89 44 24 30          	mov    %eax,0x30(%rsp)
   396e5:	b0 01                	mov    $0x1,%al
   396e7:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   396eb:	b0 01                	mov    $0x1,%al
   396ed:	89 44 24 08          	mov    %eax,0x8(%rsp)
   396f1:	b0 01                	mov    $0x1,%al
   396f3:	89 44 24 28          	mov    %eax,0x28(%rsp)
   396f7:	b0 01                	mov    $0x1,%al
   396f9:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   396fe:	b0 01                	mov    $0x1,%al
   39700:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39704:	40 b5 01             	mov    $0x1,%bpl
   39707:	41 b7 01             	mov    $0x1,%r15b
   3970a:	41 b4 01             	mov    $0x1,%r12b
   3970d:	41 b5 01             	mov    $0x1,%r13b
   39710:	ff 15 9a d1 0a 00    	call   *0xad19a(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39716:	b0 01                	mov    $0x1,%al
   39718:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3971c:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
   39723:	00 
   39724:	b0 01                	mov    $0x1,%al
   39726:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3972a:	b0 01                	mov    $0x1,%al
   3972c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39730:	b0 01                	mov    $0x1,%al
   39732:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39736:	b0 01                	mov    $0x1,%al
   39738:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3973c:	b0 01                	mov    $0x1,%al
   3973e:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39742:	b0 01                	mov    $0x1,%al
   39744:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   39748:	b0 01                	mov    $0x1,%al
   3974a:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3974e:	b0 01                	mov    $0x1,%al
   39750:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39754:	b0 01                	mov    $0x1,%al
   39756:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3975b:	b0 01                	mov    $0x1,%al
   3975d:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39761:	b0 01                	mov    $0x1,%al
   39763:	89 44 24 24          	mov    %eax,0x24(%rsp)
   39767:	b0 01                	mov    $0x1,%al
   39769:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3976d:	b0 01                	mov    $0x1,%al
   3976f:	89 44 24 20          	mov    %eax,0x20(%rsp)
   39773:	b0 01                	mov    $0x1,%al
   39775:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   39779:	41 89 dd             	mov    %ebx,%r13d
   3977c:	e9 fd f0 ff ff       	jmp    3887e <oriole_expat::dispatch+0x4a0e>
   39781:	31 c0                	xor    %eax,%eax
   39783:	44 89 e2             	mov    %r12d,%edx
   39786:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   3978b:	48 83 ec 08          	sub    $0x8,%rsp
   3978f:	48 89 ef             	mov    %rbp,%rdi
   39792:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
   39797:	44 8b 44 24 48       	mov    0x48(%rsp),%r8d
   3979c:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
   397a1:	50                   	push   %rax
   397a2:	41 57                	push   %r15
   397a4:	53                   	push   %rbx
   397a5:	ff 54 24 50          	call   *0x50(%rsp)
   397a9:	48 83 c4 20          	add    $0x20,%rsp
   397ad:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   397b4:	00 
   397b5:	e8 86 5b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   397ba:	45 31 ff             	xor    %r15d,%r15d
   397bd:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   397c4:	00 
   397c5:	e8 76 5b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   397ca:	45 31 ff             	xor    %r15d,%r15d
   397cd:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   397d2:	31 ed                	xor    %ebp,%ebp
   397d4:	e8 67 5b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   397d9:	45 31 ff             	xor    %r15d,%r15d
   397dc:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   397e3:	00 
   397e4:	31 ed                	xor    %ebp,%ebp
   397e6:	31 db                	xor    %ebx,%ebx
   397e8:	e8 53 5b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   397ed:	48 8b 8c 24 98 01 00 	mov    0x198(%rsp),%rcx
   397f4:	00 
   397f5:	48 85 c9             	test   %rcx,%rcx
   397f8:	74 33                	je     3982d <oriole_expat::dispatch+0x59bd>
   397fa:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
   39801:	00 
   39802:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
   39809:	00 
   3980a:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   39811:	00 
   39812:	ba 01 00 00 00       	mov    $0x1,%edx
   39817:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   3981e:	00 
   3981f:	31 db                	xor    %ebx,%ebx
   39821:	45 31 ed             	xor    %r13d,%r13d
   39824:	45 31 ff             	xor    %r15d,%r15d
   39827:	ff 15 83 d0 0a 00    	call   *0xad083(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3982d:	b3 01                	mov    $0x1,%bl
   3982f:	e9 be fc ff ff       	jmp    394f2 <oriole_expat::dispatch+0x5682>
   39834:	48 8d 05 9d 94 0a 00 	lea    0xa949d(%rip),%rax        # e2cd8 <oriole_expat::FEATURES+0xf0>
   3983b:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   39840:	eb 03                	jmp    39845 <oriole_expat::dispatch+0x59d5>
   39842:	4c 89 ff             	mov    %r15,%rdi
   39845:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
   3984a:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   3984f:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
   39854:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
   39859:	ff 15 c9 d5 0a 00    	call   *0xad5c9(%rip)        # e6e28 <_GLOBAL_OFFSET_TABLE_+0x6b0>
   3985f:	0f 0b                	ud2
   39861:	49 89 c6             	mov    %rax,%r14
   39864:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   3986b:	00 
   3986c:	e8 cf 5a ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39871:	45 31 e4             	xor    %r12d,%r12d
   39874:	eb 06                	jmp    3987c <oriole_expat::dispatch+0x5a0c>
   39876:	45 89 fc             	mov    %r15d,%r12d
   39879:	49 89 c6             	mov    %rax,%r14
   3987c:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   39881:	e8 ba 5a ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39886:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   3988d:	00 
   3988e:	eb 3c                	jmp    398cc <oriole_expat::dispatch+0x5a5c>
   39890:	49 89 c6             	mov    %rax,%r14
   39893:	e9 88 0b 00 00       	jmp    3a420 <oriole_expat::dispatch+0x65b0>
   39898:	49 89 c6             	mov    %rax,%r14
   3989b:	b0 01                	mov    $0x1,%al
   3989d:	89 44 24 50          	mov    %eax,0x50(%rsp)
   398a1:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   398a8:	00 
   398a9:	b0 01                	mov    $0x1,%al
   398ab:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   398af:	b0 01                	mov    $0x1,%al
   398b1:	89 44 24 40          	mov    %eax,0x40(%rsp)
   398b5:	e9 c3 09 00 00       	jmp    3a27d <oriole_expat::dispatch+0x640d>
   398ba:	49 89 c6             	mov    %rax,%r14
   398bd:	e9 c4 0d 00 00       	jmp    3a686 <oriole_expat::dispatch+0x6816>
   398c2:	45 89 fc             	mov    %r15d,%r12d
   398c5:	89 6c 24 40          	mov    %ebp,0x40(%rsp)
   398c9:	49 89 c6             	mov    %rax,%r14
   398cc:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   398d3:	00 
   398d4:	e8 67 5a ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   398d9:	31 db                	xor    %ebx,%ebx
   398db:	e9 45 02 00 00       	jmp    39b25 <oriole_expat::dispatch+0x5cb5>
   398e0:	49 89 c6             	mov    %rax,%r14
   398e3:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   398ea:	00 
   398eb:	e8 50 5a ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   398f0:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   398f7:	00 
   398f8:	e9 c4 01 00 00       	jmp    39ac1 <oriole_expat::dispatch+0x5c51>
   398fd:	49 89 c6             	mov    %rax,%r14
   39900:	b0 01                	mov    $0x1,%al
   39902:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39906:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   3990d:	00 
   3990e:	e9 cd 07 00 00       	jmp    3a0e0 <oriole_expat::dispatch+0x6270>
   39913:	49 89 c6             	mov    %rax,%r14
   39916:	b0 01                	mov    $0x1,%al
   39918:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3991c:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   39923:	00 
   39924:	b0 01                	mov    $0x1,%al
   39926:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3992a:	b0 01                	mov    $0x1,%al
   3992c:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39930:	b0 01                	mov    $0x1,%al
   39932:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39936:	e9 dd 0d 00 00       	jmp    3a718 <oriole_expat::dispatch+0x68a8>
   3993b:	e9 18 02 00 00       	jmp    39b58 <oriole_expat::dispatch+0x5ce8>
   39940:	49 89 c6             	mov    %rax,%r14
   39943:	e9 8f 08 00 00       	jmp    3a1d7 <oriole_expat::dispatch+0x6367>
   39948:	eb 51                	jmp    3999b <oriole_expat::dispatch+0x5b2b>
   3994a:	49 89 c6             	mov    %rax,%r14
   3994d:	e9 c8 03 00 00       	jmp    39d1a <oriole_expat::dispatch+0x5eaa>
   39952:	49 89 c6             	mov    %rax,%r14
   39955:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   3995c:	00 
   3995d:	48 85 c9             	test   %rcx,%rcx
   39960:	74 1b                	je     3997d <oriole_expat::dispatch+0x5b0d>
   39962:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   39969:	00 
   3996a:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   39971:	00 
   39972:	ba 01 00 00 00       	mov    $0x1,%edx
   39977:	ff 15 33 cf 0a 00    	call   *0xacf33(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3997d:	31 db                	xor    %ebx,%ebx
   3997f:	e9 3d 02 00 00       	jmp    39bc1 <oriole_expat::dispatch+0x5d51>
   39984:	49 89 c6             	mov    %rax,%r14
   39987:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   3998e:	00 
   3998f:	e8 ac 59 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39994:	31 db                	xor    %ebx,%ebx
   39996:	e9 ba 03 00 00       	jmp    39d55 <oriole_expat::dispatch+0x5ee5>
   3999b:	49 89 c6             	mov    %rax,%r14
   3999e:	e9 e5 08 00 00       	jmp    3a288 <oriole_expat::dispatch+0x6418>
   399a3:	49 89 c6             	mov    %rax,%r14
   399a6:	b0 01                	mov    $0x1,%al
   399a8:	89 44 24 30          	mov    %eax,0x30(%rsp)
   399ac:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   399b3:	00 
   399b4:	b0 01                	mov    $0x1,%al
   399b6:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   399ba:	b0 01                	mov    $0x1,%al
   399bc:	89 44 24 40          	mov    %eax,0x40(%rsp)
   399c0:	b0 01                	mov    $0x1,%al
   399c2:	89 44 24 50          	mov    %eax,0x50(%rsp)
   399c6:	b0 01                	mov    $0x1,%al
   399c8:	89 44 24 38          	mov    %eax,0x38(%rsp)
   399cc:	b0 01                	mov    $0x1,%al
   399ce:	89 44 24 48          	mov    %eax,0x48(%rsp)
   399d2:	b0 01                	mov    $0x1,%al
   399d4:	89 44 24 14          	mov    %eax,0x14(%rsp)
   399d8:	e9 db 0c 00 00       	jmp    3a6b8 <oriole_expat::dispatch+0x6848>
   399dd:	49 89 c6             	mov    %rax,%r14
   399e0:	e9 ee 09 00 00       	jmp    3a3d3 <oriole_expat::dispatch+0x6563>
   399e5:	49 89 c6             	mov    %rax,%r14
   399e8:	e9 e5 06 00 00       	jmp    3a0d2 <oriole_expat::dispatch+0x6262>
   399ed:	49 89 c6             	mov    %rax,%r14
   399f0:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   399f7:	00 
   399f8:	e8 43 59 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   399fd:	e9 18 03 00 00       	jmp    39d1a <oriole_expat::dispatch+0x5eaa>
   39a02:	49 89 c6             	mov    %rax,%r14
   39a05:	48 8b 8c 24 98 01 00 	mov    0x198(%rsp),%rcx
   39a0c:	00 
   39a0d:	b0 01                	mov    $0x1,%al
   39a0f:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39a13:	48 85 c9             	test   %rcx,%rcx
   39a16:	0f 84 12 07 00 00    	je     3a12e <oriole_expat::dispatch+0x62be>
   39a1c:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
   39a23:	00 
   39a24:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   39a2b:	00 
   39a2c:	ba 01 00 00 00       	mov    $0x1,%edx
   39a31:	ff 15 79 ce 0a 00    	call   *0xace79(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39a37:	e9 f2 06 00 00       	jmp    3a12e <oriole_expat::dispatch+0x62be>
   39a3c:	49 89 c6             	mov    %rax,%r14
   39a3f:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   39a46:	00 
   39a47:	b0 01                	mov    $0x1,%al
   39a49:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39a4d:	48 85 c9             	test   %rcx,%rcx
   39a50:	0f 84 29 0a 00 00    	je     3a47f <oriole_expat::dispatch+0x660f>
   39a56:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   39a5d:	00 
   39a5e:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   39a65:	00 
   39a66:	ba 01 00 00 00       	mov    $0x1,%edx
   39a6b:	ff 15 3f ce 0a 00    	call   *0xace3f(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39a71:	e9 09 0a 00 00       	jmp    3a47f <oriole_expat::dispatch+0x660f>
   39a76:	49 89 c6             	mov    %rax,%r14
   39a79:	b0 01                	mov    $0x1,%al
   39a7b:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39a7f:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   39a86:	00 
   39a87:	b0 01                	mov    $0x1,%al
   39a89:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39a8d:	b0 01                	mov    $0x1,%al
   39a8f:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39a93:	e9 58 05 00 00       	jmp    39ff0 <oriole_expat::dispatch+0x6180>
   39a98:	49 89 c6             	mov    %rax,%r14
   39a9b:	b0 01                	mov    $0x1,%al
   39a9d:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39aa1:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   39aa8:	00 
   39aa9:	b0 01                	mov    $0x1,%al
   39aab:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39aaf:	b0 01                	mov    $0x1,%al
   39ab1:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39ab5:	e9 ff 0d 00 00       	jmp    3a8b9 <oriole_expat::dispatch+0x6a49>
   39aba:	89 5c 24 40          	mov    %ebx,0x40(%rsp)
   39abe:	49 89 c6             	mov    %rax,%r14
   39ac1:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   39ac8:	00 
   39ac9:	48 85 c9             	test   %rcx,%rcx
   39acc:	74 18                	je     39ae6 <oriole_expat::dispatch+0x5c76>
   39ace:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   39ad5:	00 
   39ad6:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   39adb:	ba 01 00 00 00       	mov    $0x1,%edx
   39ae0:	ff 15 ca cd 0a 00    	call   *0xacdca(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39ae6:	31 db                	xor    %ebx,%ebx
   39ae8:	e9 ed 01 00 00       	jmp    39cda <oriole_expat::dispatch+0x5e6a>
   39aed:	49 89 c6             	mov    %rax,%r14
   39af0:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   39af7:	00 
   39af8:	e8 43 58 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39afd:	31 db                	xor    %ebx,%ebx
   39aff:	e9 79 03 00 00       	jmp    39e7d <oriole_expat::dispatch+0x600d>
   39b04:	49 89 c6             	mov    %rax,%r14
   39b07:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   39b0e:	00 
   39b0f:	e8 2c 58 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39b14:	31 ed                	xor    %ebp,%ebp
   39b16:	e9 fa 03 00 00       	jmp    39f15 <oriole_expat::dispatch+0x60a5>
   39b1b:	45 89 fc             	mov    %r15d,%r12d
   39b1e:	89 6c 24 40          	mov    %ebp,0x40(%rsp)
   39b22:	49 89 c6             	mov    %rax,%r14
   39b25:	48 8b 8c 24 98 01 00 	mov    0x198(%rsp),%rcx
   39b2c:	00 
   39b2d:	48 85 c9             	test   %rcx,%rcx
   39b30:	74 1b                	je     39b4d <oriole_expat::dispatch+0x5cdd>
   39b32:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
   39b39:	00 
   39b3a:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   39b41:	00 
   39b42:	ba 01 00 00 00       	mov    $0x1,%edx
   39b47:	ff 15 63 cd 0a 00    	call   *0xacd63(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39b4d:	45 31 ed             	xor    %r13d,%r13d
   39b50:	45 31 ff             	xor    %r15d,%r15d
   39b53:	e9 74 0c 00 00       	jmp    3a7cc <oriole_expat::dispatch+0x695c>
   39b58:	49 89 c6             	mov    %rax,%r14
   39b5b:	e9 ca 07 00 00       	jmp    3a32a <oriole_expat::dispatch+0x64ba>
   39b60:	49 89 c6             	mov    %rax,%r14
   39b63:	b0 01                	mov    $0x1,%al
   39b65:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39b69:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   39b70:	00 
   39b71:	b0 01                	mov    $0x1,%al
   39b73:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39b77:	b0 01                	mov    $0x1,%al
   39b79:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39b7d:	b0 01                	mov    $0x1,%al
   39b7f:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39b83:	b0 01                	mov    $0x1,%al
   39b85:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39b89:	b0 01                	mov    $0x1,%al
   39b8b:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39b8f:	e9 1a 05 00 00       	jmp    3a0ae <oriole_expat::dispatch+0x623e>
   39b94:	49 89 c6             	mov    %rax,%r14
   39b97:	b0 01                	mov    $0x1,%al
   39b99:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39b9d:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   39ba4:	00 
   39ba5:	b0 01                	mov    $0x1,%al
   39ba7:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39bab:	b0 01                	mov    $0x1,%al
   39bad:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39bb1:	e9 a8 04 00 00       	jmp    3a05e <oriole_expat::dispatch+0x61ee>
   39bb6:	49 89 c6             	mov    %rax,%r14
   39bb9:	e9 c4 04 00 00       	jmp    3a082 <oriole_expat::dispatch+0x6212>
   39bbe:	49 89 c6             	mov    %rax,%r14
   39bc1:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   39bc8:	00 
   39bc9:	48 85 c9             	test   %rcx,%rcx
   39bcc:	74 18                	je     39be6 <oriole_expat::dispatch+0x5d76>
   39bce:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   39bd5:	00 
   39bd6:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   39bdb:	ba 01 00 00 00       	mov    $0x1,%edx
   39be0:	ff 15 ca cc 0a 00    	call   *0xaccca(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39be6:	31 ed                	xor    %ebp,%ebp
   39be8:	e9 16 02 00 00       	jmp    39e03 <oriole_expat::dispatch+0x5f93>
   39bed:	e9 af 0d 00 00       	jmp    3a9a1 <oriole_expat::dispatch+0x6b31>
   39bf2:	49 89 c6             	mov    %rax,%r14
   39bf5:	e9 41 06 00 00       	jmp    3a23b <oriole_expat::dispatch+0x63cb>
   39bfa:	49 89 c6             	mov    %rax,%r14
   39bfd:	e9 88 05 00 00       	jmp    3a18a <oriole_expat::dispatch+0x631a>
   39c02:	49 89 c6             	mov    %rax,%r14
   39c05:	e9 e2 06 00 00       	jmp    3a2ec <oriole_expat::dispatch+0x647c>
   39c0a:	49 89 c6             	mov    %rax,%r14
   39c0d:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   39c14:	00 
   39c15:	e8 26 57 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39c1a:	e9 63 04 00 00       	jmp    3a082 <oriole_expat::dispatch+0x6212>
   39c1f:	49 89 c6             	mov    %rax,%r14
   39c22:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   39c29:	00 
   39c2a:	b0 01                	mov    $0x1,%al
   39c2c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39c30:	48 85 c9             	test   %rcx,%rcx
   39c33:	0f 84 a3 03 00 00    	je     39fdc <oriole_expat::dispatch+0x616c>
   39c39:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   39c40:	00 
   39c41:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   39c48:	00 
   39c49:	ba 01 00 00 00       	mov    $0x1,%edx
   39c4e:	ff 15 5c cc 0a 00    	call   *0xacc5c(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39c54:	e9 83 03 00 00       	jmp    39fdc <oriole_expat::dispatch+0x616c>
   39c59:	49 89 c6             	mov    %rax,%r14
   39c5c:	b0 01                	mov    $0x1,%al
   39c5e:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39c62:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   39c69:	00 
   39c6a:	b0 01                	mov    $0x1,%al
   39c6c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39c70:	b0 01                	mov    $0x1,%al
   39c72:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39c76:	b0 01                	mov    $0x1,%al
   39c78:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39c7c:	e9 18 08 00 00       	jmp    3a499 <oriole_expat::dispatch+0x6629>
   39c81:	49 89 c6             	mov    %rax,%r14
   39c84:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   39c8b:	00 
   39c8c:	48 85 c9             	test   %rcx,%rcx
   39c8f:	0f 84 bf 07 00 00    	je     3a454 <oriole_expat::dispatch+0x65e4>
   39c95:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   39c9c:	00 
   39c9d:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   39ca4:	00 
   39ca5:	ba 01 00 00 00       	mov    $0x1,%edx
   39caa:	ff 15 00 cc 0a 00    	call   *0xacc00(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39cb0:	e9 9f 07 00 00       	jmp    3a454 <oriole_expat::dispatch+0x65e4>
   39cb5:	49 89 c6             	mov    %rax,%r14
   39cb8:	b0 01                	mov    $0x1,%al
   39cba:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39cbe:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
   39cc5:	00 
   39cc6:	b0 01                	mov    $0x1,%al
   39cc8:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39ccc:	b0 01                	mov    $0x1,%al
   39cce:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39cd2:	e9 e2 0a 00 00       	jmp    3a7b9 <oriole_expat::dispatch+0x6949>
   39cd7:	49 89 c6             	mov    %rax,%r14
   39cda:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   39ce1:	00 
   39ce2:	41 b5 01             	mov    $0x1,%r13b
   39ce5:	48 85 c9             	test   %rcx,%rcx
   39ce8:	74 1b                	je     39d05 <oriole_expat::dispatch+0x5e95>
   39cea:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   39cf1:	00 
   39cf2:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   39cf9:	00 
   39cfa:	ba 01 00 00 00       	mov    $0x1,%edx
   39cff:	ff 15 ab cb 0a 00    	call   *0xacbab(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39d05:	45 31 ff             	xor    %r15d,%r15d
   39d08:	e9 c4 0a 00 00       	jmp    3a7d1 <oriole_expat::dispatch+0x6961>
   39d0d:	49 89 c6             	mov    %rax,%r14
   39d10:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   39d15:	e8 26 56 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39d1a:	b0 01                	mov    $0x1,%al
   39d1c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39d20:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   39d27:	00 
   39d28:	b0 01                	mov    $0x1,%al
   39d2a:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39d2e:	b0 01                	mov    $0x1,%al
   39d30:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39d34:	b0 01                	mov    $0x1,%al
   39d36:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39d3a:	b0 01                	mov    $0x1,%al
   39d3c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39d40:	e9 25 03 00 00       	jmp    3a06a <oriole_expat::dispatch+0x61fa>
   39d45:	e9 1c 08 00 00       	jmp    3a566 <oriole_expat::dispatch+0x66f6>
   39d4a:	49 89 c6             	mov    %rax,%r14
   39d4d:	e9 49 06 00 00       	jmp    3a39b <oriole_expat::dispatch+0x652b>
   39d52:	49 89 c6             	mov    %rax,%r14
   39d55:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   39d5a:	e8 e1 55 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39d5f:	b0 01                	mov    $0x1,%al
   39d61:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39d65:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   39d6c:	00 
   39d6d:	b0 01                	mov    $0x1,%al
   39d6f:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39d73:	b0 01                	mov    $0x1,%al
   39d75:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39d79:	b0 01                	mov    $0x1,%al
   39d7b:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39d7f:	b0 01                	mov    $0x1,%al
   39d81:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39d85:	b0 01                	mov    $0x1,%al
   39d87:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39d8b:	b0 01                	mov    $0x1,%al
   39d8d:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39d91:	b0 01                	mov    $0x1,%al
   39d93:	89 44 24 08          	mov    %eax,0x8(%rsp)
   39d97:	b0 01                	mov    $0x1,%al
   39d99:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39d9d:	b0 01                	mov    $0x1,%al
   39d9f:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   39da4:	b0 01                	mov    $0x1,%al
   39da6:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39daa:	b0 01                	mov    $0x1,%al
   39dac:	89 44 24 24          	mov    %eax,0x24(%rsp)
   39db0:	b0 01                	mov    $0x1,%al
   39db2:	89 44 24 18          	mov    %eax,0x18(%rsp)
   39db6:	b0 01                	mov    $0x1,%al
   39db8:	89 44 24 20          	mov    %eax,0x20(%rsp)
   39dbc:	b0 01                	mov    $0x1,%al
   39dbe:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   39dc2:	84 db                	test   %bl,%bl
   39dc4:	0f 85 f6 04 00 00    	jne    3a2c0 <oriole_expat::dispatch+0x6450>
   39dca:	e9 13 0c 00 00       	jmp    3a9e2 <oriole_expat::dispatch+0x6b72>
   39dcf:	49 89 c6             	mov    %rax,%r14
   39dd2:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   39dd9:	00 
   39dda:	e8 61 55 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   39ddf:	e9 9e 02 00 00       	jmp    3a082 <oriole_expat::dispatch+0x6212>
   39de4:	49 89 c6             	mov    %rax,%r14
   39de7:	b0 01                	mov    $0x1,%al
   39de9:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39ded:	b0 01                	mov    $0x1,%al
   39def:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39df3:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   39dfa:	00 
   39dfb:	e9 3c 03 00 00       	jmp    3a13c <oriole_expat::dispatch+0x62cc>
   39e00:	49 89 c6             	mov    %rax,%r14
   39e03:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   39e0a:	00 
   39e0b:	48 85 c9             	test   %rcx,%rcx
   39e0e:	74 1b                	je     39e2b <oriole_expat::dispatch+0x5fbb>
   39e10:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   39e17:	00 
   39e18:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   39e1f:	00 
   39e20:	ba 01 00 00 00       	mov    $0x1,%edx
   39e25:	ff 15 85 ca 0a 00    	call   *0xaca85(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39e2b:	45 31 ed             	xor    %r13d,%r13d
   39e2e:	e9 2a 05 00 00       	jmp    3a35d <oriole_expat::dispatch+0x64ed>
   39e33:	49 89 c6             	mov    %rax,%r14
   39e36:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   39e3d:	00 
   39e3e:	b0 01                	mov    $0x1,%al
   39e40:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39e44:	48 85 c9             	test   %rcx,%rcx
   39e47:	0f 84 e1 02 00 00    	je     3a12e <oriole_expat::dispatch+0x62be>
   39e4d:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   39e54:	00 
   39e55:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   39e5a:	ba 01 00 00 00       	mov    $0x1,%edx
   39e5f:	ff 15 4b ca 0a 00    	call   *0xaca4b(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39e65:	e9 c4 02 00 00       	jmp    3a12e <oriole_expat::dispatch+0x62be>
   39e6a:	49 89 c6             	mov    %rax,%r14
   39e6d:	e9 91 09 00 00       	jmp    3a803 <oriole_expat::dispatch+0x6993>
   39e72:	49 89 c6             	mov    %rax,%r14
   39e75:	e9 00 09 00 00       	jmp    3a77a <oriole_expat::dispatch+0x690a>
   39e7a:	49 89 c6             	mov    %rax,%r14
   39e7d:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   39e84:	00 
   39e85:	48 85 c9             	test   %rcx,%rcx
   39e88:	74 18                	je     39ea2 <oriole_expat::dispatch+0x6032>
   39e8a:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   39e91:	00 
   39e92:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   39e97:	ba 01 00 00 00       	mov    $0x1,%edx
   39e9c:	ff 15 0e ca 0a 00    	call   *0xaca0e(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39ea2:	b0 01                	mov    $0x1,%al
   39ea4:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39ea8:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   39eaf:	00 
   39eb0:	b0 01                	mov    $0x1,%al
   39eb2:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39eb6:	b0 01                	mov    $0x1,%al
   39eb8:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39ebc:	b0 01                	mov    $0x1,%al
   39ebe:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39ec2:	b0 01                	mov    $0x1,%al
   39ec4:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39ec8:	b0 01                	mov    $0x1,%al
   39eca:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39ece:	b0 01                	mov    $0x1,%al
   39ed0:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39ed4:	b0 01                	mov    $0x1,%al
   39ed6:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   39eda:	b0 01                	mov    $0x1,%al
   39edc:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39ee0:	b0 01                	mov    $0x1,%al
   39ee2:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   39ee7:	b0 01                	mov    $0x1,%al
   39ee9:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39eed:	b0 01                	mov    $0x1,%al
   39eef:	89 44 24 24          	mov    %eax,0x24(%rsp)
   39ef3:	b0 01                	mov    $0x1,%al
   39ef5:	89 44 24 18          	mov    %eax,0x18(%rsp)
   39ef9:	b0 01                	mov    $0x1,%al
   39efb:	89 44 24 20          	mov    %eax,0x20(%rsp)
   39eff:	b0 01                	mov    $0x1,%al
   39f01:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   39f05:	84 db                	test   %bl,%bl
   39f07:	0f 85 02 03 00 00    	jne    3a20f <oriole_expat::dispatch+0x639f>
   39f0d:	e9 d0 0a 00 00       	jmp    3a9e2 <oriole_expat::dispatch+0x6b72>
   39f12:	49 89 c6             	mov    %rax,%r14
   39f15:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   39f1c:	00 
   39f1d:	48 85 c9             	test   %rcx,%rcx
   39f20:	74 18                	je     39f3a <oriole_expat::dispatch+0x60ca>
   39f22:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   39f29:	00 
   39f2a:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   39f2f:	ba 01 00 00 00       	mov    $0x1,%edx
   39f34:	ff 15 76 c9 0a 00    	call   *0xac976(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39f3a:	b0 01                	mov    $0x1,%al
   39f3c:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39f40:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   39f47:	00 
   39f48:	b0 01                	mov    $0x1,%al
   39f4a:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39f4e:	b0 01                	mov    $0x1,%al
   39f50:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39f54:	b0 01                	mov    $0x1,%al
   39f56:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39f5a:	b0 01                	mov    $0x1,%al
   39f5c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39f60:	b0 01                	mov    $0x1,%al
   39f62:	89 44 24 14          	mov    %eax,0x14(%rsp)
   39f66:	b0 01                	mov    $0x1,%al
   39f68:	89 44 24 30          	mov    %eax,0x30(%rsp)
   39f6c:	b0 01                	mov    $0x1,%al
   39f6e:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   39f72:	b0 01                	mov    $0x1,%al
   39f74:	89 44 24 08          	mov    %eax,0x8(%rsp)
   39f78:	b0 01                	mov    $0x1,%al
   39f7a:	89 44 24 28          	mov    %eax,0x28(%rsp)
   39f7e:	b0 01                	mov    $0x1,%al
   39f80:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   39f85:	b0 01                	mov    $0x1,%al
   39f87:	89 44 24 10          	mov    %eax,0x10(%rsp)
   39f8b:	b0 01                	mov    $0x1,%al
   39f8d:	89 44 24 24          	mov    %eax,0x24(%rsp)
   39f91:	b0 01                	mov    $0x1,%al
   39f93:	89 44 24 20          	mov    %eax,0x20(%rsp)
   39f97:	b0 01                	mov    $0x1,%al
   39f99:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   39f9d:	40 84 ed             	test   %bpl,%bpl
   39fa0:	0f 85 b8 01 00 00    	jne    3a15e <oriole_expat::dispatch+0x62ee>
   39fa6:	e9 37 0a 00 00       	jmp    3a9e2 <oriole_expat::dispatch+0x6b72>
   39fab:	49 89 c6             	mov    %rax,%r14
   39fae:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   39fb5:	00 
   39fb6:	b0 01                	mov    $0x1,%al
   39fb8:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   39fbc:	48 85 c9             	test   %rcx,%rcx
   39fbf:	74 1b                	je     39fdc <oriole_expat::dispatch+0x616c>
   39fc1:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
   39fc8:	00 
   39fc9:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   39fd0:	00 
   39fd1:	ba 01 00 00 00       	mov    $0x1,%edx
   39fd6:	ff 15 d4 c8 0a 00    	call   *0xac8d4(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   39fdc:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   39fe3:	00 
   39fe4:	b0 01                	mov    $0x1,%al
   39fe6:	89 44 24 40          	mov    %eax,0x40(%rsp)
   39fea:	b0 01                	mov    $0x1,%al
   39fec:	89 44 24 50          	mov    %eax,0x50(%rsp)
   39ff0:	b0 01                	mov    $0x1,%al
   39ff2:	89 44 24 38          	mov    %eax,0x38(%rsp)
   39ff6:	b0 01                	mov    $0x1,%al
   39ff8:	89 44 24 48          	mov    %eax,0x48(%rsp)
   39ffc:	e9 c4 08 00 00       	jmp    3a8c5 <oriole_expat::dispatch+0x6a55>
   3a001:	49 89 c6             	mov    %rax,%r14
   3a004:	e9 1a 02 00 00       	jmp    3a223 <oriole_expat::dispatch+0x63b3>
   3a009:	49 89 c6             	mov    %rax,%r14
   3a00c:	e9 61 01 00 00       	jmp    3a172 <oriole_expat::dispatch+0x6302>
   3a011:	49 89 c6             	mov    %rax,%r14
   3a014:	e9 fc 07 00 00       	jmp    3a815 <oriole_expat::dispatch+0x69a5>
   3a019:	49 89 c6             	mov    %rax,%r14
   3a01c:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   3a023:	00 
   3a024:	b0 01                	mov    $0x1,%al
   3a026:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a02a:	48 85 c9             	test   %rcx,%rcx
   3a02d:	74 1b                	je     3a04a <oriole_expat::dispatch+0x61da>
   3a02f:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   3a036:	00 
   3a037:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   3a03e:	00 
   3a03f:	ba 01 00 00 00       	mov    $0x1,%edx
   3a044:	ff 15 66 c8 0a 00    	call   *0xac866(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a04a:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
   3a051:	00 
   3a052:	b0 01                	mov    $0x1,%al
   3a054:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a058:	b0 01                	mov    $0x1,%al
   3a05a:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a05e:	b0 01                	mov    $0x1,%al
   3a060:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a064:	b0 01                	mov    $0x1,%al
   3a066:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a06a:	b0 01                	mov    $0x1,%al
   3a06c:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a070:	e9 56 08 00 00       	jmp    3a8cb <oriole_expat::dispatch+0x6a5b>
   3a075:	49 89 c6             	mov    %rax,%r14
   3a078:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   3a07d:	e8 be 52 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a082:	b0 01                	mov    $0x1,%al
   3a084:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a088:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
   3a08f:	00 
   3a090:	b0 01                	mov    $0x1,%al
   3a092:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a096:	b0 01                	mov    $0x1,%al
   3a098:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a09c:	b0 01                	mov    $0x1,%al
   3a09e:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a0a2:	b0 01                	mov    $0x1,%al
   3a0a4:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a0a8:	b0 01                	mov    $0x1,%al
   3a0aa:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a0ae:	b0 01                	mov    $0x1,%al
   3a0b0:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a0b4:	b0 01                	mov    $0x1,%al
   3a0b6:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a0ba:	b0 01                	mov    $0x1,%al
   3a0bc:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a0c0:	e9 18 08 00 00       	jmp    3a8dd <oriole_expat::dispatch+0x6a6d>
   3a0c5:	49 89 c6             	mov    %rax,%r14
   3a0c8:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   3a0cd:	e8 6e 52 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a0d2:	b0 01                	mov    $0x1,%al
   3a0d4:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a0d8:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
   3a0df:	00 
   3a0e0:	b0 01                	mov    $0x1,%al
   3a0e2:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a0e6:	b0 01                	mov    $0x1,%al
   3a0e8:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a0ec:	b0 01                	mov    $0x1,%al
   3a0ee:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a0f2:	b0 01                	mov    $0x1,%al
   3a0f4:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a0f8:	e9 c8 07 00 00       	jmp    3a8c5 <oriole_expat::dispatch+0x6a55>
   3a0fd:	49 89 c6             	mov    %rax,%r14
   3a100:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   3a107:	00 
   3a108:	b0 01                	mov    $0x1,%al
   3a10a:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a10e:	48 85 c9             	test   %rcx,%rcx
   3a111:	74 1b                	je     3a12e <oriole_expat::dispatch+0x62be>
   3a113:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
   3a11a:	00 
   3a11b:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   3a122:	00 
   3a123:	ba 01 00 00 00       	mov    $0x1,%edx
   3a128:	ff 15 82 c7 0a 00    	call   *0xac782(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a12e:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   3a135:	00 
   3a136:	b0 01                	mov    $0x1,%al
   3a138:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a13c:	b0 01                	mov    $0x1,%al
   3a13e:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a142:	e9 72 07 00 00       	jmp    3a8b9 <oriole_expat::dispatch+0x6a49>
   3a147:	49 89 c6             	mov    %rax,%r14
   3a14a:	e9 85 01 00 00       	jmp    3a2d4 <oriole_expat::dispatch+0x6464>
   3a14f:	49 89 c6             	mov    %rax,%r14
   3a152:	e9 9b 06 00 00       	jmp    3a7f2 <oriole_expat::dispatch+0x6982>
   3a157:	89 5c 24 18          	mov    %ebx,0x18(%rsp)
   3a15b:	49 89 c6             	mov    %rax,%r14
   3a15e:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   3a165:	00 
   3a166:	e8 d5 51 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a16b:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
   3a170:	74 65                	je     3a1d7 <oriole_expat::dispatch+0x6367>
   3a172:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   3a179:	00 
   3a17a:	e8 c1 51 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a17f:	48 83 bc 24 b8 01 00 	cmpq   $0x0,0x1b8(%rsp)
   3a186:	00 00 
   3a188:	75 4d                	jne    3a1d7 <oriole_expat::dispatch+0x6367>
   3a18a:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3a191:	00 
   3a192:	b0 01                	mov    $0x1,%al
   3a194:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a198:	48 85 c9             	test   %rcx,%rcx
   3a19b:	74 1b                	je     3a1b8 <oriole_expat::dispatch+0x6348>
   3a19d:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   3a1a4:	00 
   3a1a5:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3a1ac:	00 
   3a1ad:	ba 01 00 00 00       	mov    $0x1,%edx
   3a1b2:	ff 15 f8 c6 0a 00    	call   *0xac6f8(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a1b8:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3a1bf:	00 
   3a1c0:	b0 01                	mov    $0x1,%al
   3a1c2:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a1c6:	b0 01                	mov    $0x1,%al
   3a1c8:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a1cc:	b0 01                	mov    $0x1,%al
   3a1ce:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a1d2:	e9 cf 04 00 00       	jmp    3a6a6 <oriole_expat::dispatch+0x6836>
   3a1d7:	b0 01                	mov    $0x1,%al
   3a1d9:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a1dd:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3a1e4:	00 
   3a1e5:	b0 01                	mov    $0x1,%al
   3a1e7:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a1eb:	b0 01                	mov    $0x1,%al
   3a1ed:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a1f1:	b0 01                	mov    $0x1,%al
   3a1f3:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a1f7:	b0 01                	mov    $0x1,%al
   3a1f9:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a1fd:	b0 01                	mov    $0x1,%al
   3a1ff:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a203:	e9 aa 04 00 00       	jmp    3a6b2 <oriole_expat::dispatch+0x6842>
   3a208:	89 5c 24 08          	mov    %ebx,0x8(%rsp)
   3a20c:	49 89 c6             	mov    %rax,%r14
   3a20f:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   3a216:	00 
   3a217:	e8 24 51 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a21c:	80 7c 24 08 00       	cmpb   $0x0,0x8(%rsp)
   3a221:	74 65                	je     3a288 <oriole_expat::dispatch+0x6418>
   3a223:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   3a22a:	00 
   3a22b:	e8 10 51 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a230:	48 83 bc 24 18 04 00 	cmpq   $0x0,0x418(%rsp)
   3a237:	00 00 
   3a239:	75 4d                	jne    3a288 <oriole_expat::dispatch+0x6418>
   3a23b:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3a242:	00 
   3a243:	b0 01                	mov    $0x1,%al
   3a245:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a249:	48 85 c9             	test   %rcx,%rcx
   3a24c:	74 1b                	je     3a269 <oriole_expat::dispatch+0x63f9>
   3a24e:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   3a255:	00 
   3a256:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3a25d:	00 
   3a25e:	ba 01 00 00 00       	mov    $0x1,%edx
   3a263:	ff 15 47 c6 0a 00    	call   *0xac647(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a269:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   3a270:	00 
   3a271:	b0 01                	mov    $0x1,%al
   3a273:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a277:	b0 01                	mov    $0x1,%al
   3a279:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a27d:	b0 01                	mov    $0x1,%al
   3a27f:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a283:	e9 90 03 00 00       	jmp    3a618 <oriole_expat::dispatch+0x67a8>
   3a288:	b0 01                	mov    $0x1,%al
   3a28a:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a28e:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   3a295:	00 
   3a296:	b0 01                	mov    $0x1,%al
   3a298:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a29c:	b0 01                	mov    $0x1,%al
   3a29e:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a2a2:	b0 01                	mov    $0x1,%al
   3a2a4:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a2a8:	b0 01                	mov    $0x1,%al
   3a2aa:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a2ae:	b0 01                	mov    $0x1,%al
   3a2b0:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a2b4:	e9 6b 03 00 00       	jmp    3a624 <oriole_expat::dispatch+0x67b4>
   3a2b9:	89 5c 24 0c          	mov    %ebx,0xc(%rsp)
   3a2bd:	49 89 c6             	mov    %rax,%r14
   3a2c0:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
   3a2c7:	00 
   3a2c8:	e8 73 50 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a2cd:	80 7c 24 0c 00       	cmpb   $0x0,0xc(%rsp)
   3a2d2:	74 56                	je     3a32a <oriole_expat::dispatch+0x64ba>
   3a2d4:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   3a2db:	00 
   3a2dc:	e8 5f 50 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a2e1:	48 83 bc 24 10 05 00 	cmpq   $0x0,0x510(%rsp)
   3a2e8:	00 00 
   3a2ea:	75 3e                	jne    3a32a <oriole_expat::dispatch+0x64ba>
   3a2ec:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3a2f3:	00 
   3a2f4:	e8 47 50 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a2f9:	b0 01                	mov    $0x1,%al
   3a2fb:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a2ff:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   3a306:	00 
   3a307:	b0 01                	mov    $0x1,%al
   3a309:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a30d:	b0 01                	mov    $0x1,%al
   3a30f:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a313:	b0 01                	mov    $0x1,%al
   3a315:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a319:	b0 01                	mov    $0x1,%al
   3a31b:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a31f:	b0 01                	mov    $0x1,%al
   3a321:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a325:	e9 fa 03 00 00       	jmp    3a724 <oriole_expat::dispatch+0x68b4>
   3a32a:	b0 01                	mov    $0x1,%al
   3a32c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a330:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   3a337:	00 
   3a338:	b0 01                	mov    $0x1,%al
   3a33a:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a33e:	b0 01                	mov    $0x1,%al
   3a340:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a344:	b0 01                	mov    $0x1,%al
   3a346:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a34a:	b0 01                	mov    $0x1,%al
   3a34c:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a350:	e9 c9 03 00 00       	jmp    3a71e <oriole_expat::dispatch+0x68ae>
   3a355:	49 89 c6             	mov    %rax,%r14
   3a358:	eb 14                	jmp    3a36e <oriole_expat::dispatch+0x64fe>
   3a35a:	49 89 c6             	mov    %rax,%r14
   3a35d:	84 db                	test   %bl,%bl
   3a35f:	74 0d                	je     3a36e <oriole_expat::dispatch+0x64fe>
   3a361:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   3a368:	00 
   3a369:	e8 d2 4f ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a36e:	40 84 ed             	test   %bpl,%bpl
   3a371:	74 28                	je     3a39b <oriole_expat::dispatch+0x652b>
   3a373:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
   3a37a:	00 
   3a37b:	48 85 c9             	test   %rcx,%rcx
   3a37e:	74 1b                	je     3a39b <oriole_expat::dispatch+0x652b>
   3a380:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
   3a387:	00 
   3a388:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3a38f:	00 
   3a390:	ba 01 00 00 00       	mov    $0x1,%edx
   3a395:	ff 15 15 c5 0a 00    	call   *0xac515(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a39b:	45 84 ed             	test   %r13b,%r13b
   3a39e:	74 28                	je     3a3c8 <oriole_expat::dispatch+0x6558>
   3a3a0:	48 8b 8c 24 48 04 00 	mov    0x448(%rsp),%rcx
   3a3a7:	00 
   3a3a8:	48 85 c9             	test   %rcx,%rcx
   3a3ab:	74 1b                	je     3a3c8 <oriole_expat::dispatch+0x6558>
   3a3ad:	48 8b b4 24 40 04 00 	mov    0x440(%rsp),%rsi
   3a3b4:	00 
   3a3b5:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   3a3bc:	00 
   3a3bd:	ba 01 00 00 00       	mov    $0x1,%edx
   3a3c2:	ff 15 e8 c4 0a 00    	call   *0xac4e8(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a3c8:	48 83 bc 24 00 04 00 	cmpq   $0x0,0x400(%rsp)
   3a3cf:	00 00 
   3a3d1:	75 4d                	jne    3a420 <oriole_expat::dispatch+0x65b0>
   3a3d3:	48 8b 8c 24 88 04 00 	mov    0x488(%rsp),%rcx
   3a3da:	00 
   3a3db:	b0 01                	mov    $0x1,%al
   3a3dd:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a3e1:	48 85 c9             	test   %rcx,%rcx
   3a3e4:	74 1b                	je     3a401 <oriole_expat::dispatch+0x6591>
   3a3e6:	48 8b b4 24 80 04 00 	mov    0x480(%rsp),%rsi
   3a3ed:	00 
   3a3ee:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
   3a3f5:	00 
   3a3f6:	ba 01 00 00 00       	mov    $0x1,%edx
   3a3fb:	ff 15 af c4 0a 00    	call   *0xac4af(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a401:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   3a408:	00 
   3a409:	b0 01                	mov    $0x1,%al
   3a40b:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a40f:	b0 01                	mov    $0x1,%al
   3a411:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a415:	b0 01                	mov    $0x1,%al
   3a417:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a41b:	e9 8c 01 00 00       	jmp    3a5ac <oriole_expat::dispatch+0x673c>
   3a420:	b0 01                	mov    $0x1,%al
   3a422:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a426:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   3a42d:	00 
   3a42e:	b0 01                	mov    $0x1,%al
   3a430:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a434:	b0 01                	mov    $0x1,%al
   3a436:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a43a:	b0 01                	mov    $0x1,%al
   3a43c:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a440:	b0 01                	mov    $0x1,%al
   3a442:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a446:	b0 01                	mov    $0x1,%al
   3a448:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a44c:	e9 67 01 00 00       	jmp    3a5b8 <oriole_expat::dispatch+0x6748>
   3a451:	49 89 c6             	mov    %rax,%r14
   3a454:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   3a45b:	00 
   3a45c:	b0 01                	mov    $0x1,%al
   3a45e:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a462:	48 85 c9             	test   %rcx,%rcx
   3a465:	74 18                	je     3a47f <oriole_expat::dispatch+0x660f>
   3a467:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   3a46e:	00 
   3a46f:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   3a474:	ba 01 00 00 00       	mov    $0x1,%edx
   3a479:	ff 15 31 c4 0a 00    	call   *0xac431(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a47f:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
   3a486:	00 
   3a487:	b0 01                	mov    $0x1,%al
   3a489:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a48d:	b0 01                	mov    $0x1,%al
   3a48f:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a493:	b0 01                	mov    $0x1,%al
   3a495:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a499:	b0 01                	mov    $0x1,%al
   3a49b:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a49f:	b0 01                	mov    $0x1,%al
   3a4a1:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a4a5:	b0 01                	mov    $0x1,%al
   3a4a7:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a4ab:	b0 01                	mov    $0x1,%al
   3a4ad:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a4b1:	b0 01                	mov    $0x1,%al
   3a4b3:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a4b7:	b0 01                	mov    $0x1,%al
   3a4b9:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a4bd:	b0 01                	mov    $0x1,%al
   3a4bf:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3a4c4:	b0 01                	mov    $0x1,%al
   3a4c6:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a4ca:	b0 01                	mov    $0x1,%al
   3a4cc:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a4d0:	b0 01                	mov    $0x1,%al
   3a4d2:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3a4d6:	e9 21 04 00 00       	jmp    3a8fc <oriole_expat::dispatch+0x6a8c>
   3a4db:	49 89 c6             	mov    %rax,%r14
   3a4de:	48 83 c3 40          	add    $0x40,%rbx
   3a4e2:	48 89 df             	mov    %rbx,%rdi
   3a4e5:	e8 56 4e ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a4ea:	e9 d6 07 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3a4ef:	49 89 c6             	mov    %rax,%r14
   3a4f2:	48 8b 4b 30          	mov    0x30(%rbx),%rcx
   3a4f6:	48 85 c9             	test   %rcx,%rcx
   3a4f9:	0f 84 c6 07 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3a4ff:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3a504:	48 8b 77 28          	mov    0x28(%rdi),%rsi
   3a508:	48 83 c7 08          	add    $0x8,%rdi
   3a50c:	ba 01 00 00 00       	mov    $0x1,%edx
   3a511:	ff 15 99 c3 0a 00    	call   *0xac399(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a517:	e9 a9 07 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3a51c:	49 89 c6             	mov    %rax,%r14
   3a51f:	48 8b 8c 24 e8 01 00 	mov    0x1e8(%rsp),%rcx
   3a526:	00 
   3a527:	b0 01                	mov    $0x1,%al
   3a529:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a52d:	48 85 c9             	test   %rcx,%rcx
   3a530:	74 1b                	je     3a54d <oriole_expat::dispatch+0x66dd>
   3a532:	48 8b b4 24 e0 01 00 	mov    0x1e0(%rsp),%rsi
   3a539:	00 
   3a53a:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   3a541:	00 
   3a542:	ba 01 00 00 00       	mov    $0x1,%edx
   3a547:	ff 15 63 c3 0a 00    	call   *0xac363(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a54d:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
   3a554:	00 
   3a555:	e9 53 02 00 00       	jmp    3a7ad <oriole_expat::dispatch+0x693d>
   3a55a:	89 6c 24 40          	mov    %ebp,0x40(%rsp)
   3a55e:	49 89 c6             	mov    %rax,%r14
   3a561:	e9 78 02 00 00       	jmp    3a7de <oriole_expat::dispatch+0x696e>
   3a566:	49 89 c6             	mov    %rax,%r14
   3a569:	b0 01                	mov    $0x1,%al
   3a56b:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a56f:	e9 43 04 00 00       	jmp    3a9b7 <oriole_expat::dispatch+0x6b47>
   3a574:	49 89 c6             	mov    %rax,%r14
   3a577:	e9 f1 01 00 00       	jmp    3a76d <oriole_expat::dispatch+0x68fd>
   3a57c:	49 89 c6             	mov    %rax,%r14
   3a57f:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3a586:	00 
   3a587:	e8 84 66 ff ff       	call   30c10 <core::ptr::drop_glue::<oriole::AttributeDeclaration>>
   3a58c:	b0 01                	mov    $0x1,%al
   3a58e:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a592:	c7 44 24 24 00 00 00 	movl   $0x0,0x24(%rsp)
   3a599:	00 
   3a59a:	b0 01                	mov    $0x1,%al
   3a59c:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a5a0:	b0 01                	mov    $0x1,%al
   3a5a2:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a5a6:	b0 01                	mov    $0x1,%al
   3a5a8:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a5ac:	b0 01                	mov    $0x1,%al
   3a5ae:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a5b2:	b0 01                	mov    $0x1,%al
   3a5b4:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a5b8:	b0 01                	mov    $0x1,%al
   3a5ba:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a5be:	b0 01                	mov    $0x1,%al
   3a5c0:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a5c4:	b0 01                	mov    $0x1,%al
   3a5c6:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a5ca:	b0 01                	mov    $0x1,%al
   3a5cc:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a5d0:	b0 01                	mov    $0x1,%al
   3a5d2:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3a5d7:	b0 01                	mov    $0x1,%al
   3a5d9:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a5dd:	e9 0e 03 00 00       	jmp    3a8f0 <oriole_expat::dispatch+0x6a80>
   3a5e2:	ff 15 10 c9 0a 00    	call   *0xac910(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a5e8:	49 89 c6             	mov    %rax,%r14
   3a5eb:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3a5f2:	00 
   3a5f3:	e8 b8 64 ff ff       	call   30ab0 <core::ptr::drop_glue::<oriole::DoctypeDeclaration>>
   3a5f8:	b0 01                	mov    $0x1,%al
   3a5fa:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a5fe:	c7 44 24 08 00 00 00 	movl   $0x0,0x8(%rsp)
   3a605:	00 
   3a606:	b0 01                	mov    $0x1,%al
   3a608:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a60c:	b0 01                	mov    $0x1,%al
   3a60e:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a612:	b0 01                	mov    $0x1,%al
   3a614:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a618:	b0 01                	mov    $0x1,%al
   3a61a:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a61e:	b0 01                	mov    $0x1,%al
   3a620:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a624:	b0 01                	mov    $0x1,%al
   3a626:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a62a:	b0 01                	mov    $0x1,%al
   3a62c:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a630:	e9 a2 02 00 00       	jmp    3a8d7 <oriole_expat::dispatch+0x6a67>
   3a635:	ff 15 bd c8 0a 00    	call   *0xac8bd(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a63b:	49 89 c6             	mov    %rax,%r14
   3a63e:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3a645:	00 
   3a646:	e8 35 63 ff ff       	call   30980 <core::ptr::drop_glue::<oriole::EntityDeclaration>>
   3a64b:	b0 01                	mov    $0x1,%al
   3a64d:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a651:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   3a658:	00 
   3a659:	b0 01                	mov    $0x1,%al
   3a65b:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a65f:	b0 01                	mov    $0x1,%al
   3a661:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a665:	b0 01                	mov    $0x1,%al
   3a667:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a66b:	e9 f2 01 00 00       	jmp    3a862 <oriole_expat::dispatch+0x69f2>
   3a670:	ff 15 82 c8 0a 00    	call   *0xac882(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a676:	49 89 c6             	mov    %rax,%r14
   3a679:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3a680:	00 
   3a681:	e8 da 64 ff ff       	call   30b60 <core::ptr::drop_glue::<oriole::NotationDeclaration>>
   3a686:	b0 01                	mov    $0x1,%al
   3a688:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a68c:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
   3a693:	00 
   3a694:	b0 01                	mov    $0x1,%al
   3a696:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a69a:	b0 01                	mov    $0x1,%al
   3a69c:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a6a0:	b0 01                	mov    $0x1,%al
   3a6a2:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a6a6:	b0 01                	mov    $0x1,%al
   3a6a8:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a6ac:	b0 01                	mov    $0x1,%al
   3a6ae:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a6b2:	b0 01                	mov    $0x1,%al
   3a6b4:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a6b8:	b0 01                	mov    $0x1,%al
   3a6ba:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a6be:	b0 01                	mov    $0x1,%al
   3a6c0:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a6c4:	b0 01                	mov    $0x1,%al
   3a6c6:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a6ca:	b0 01                	mov    $0x1,%al
   3a6cc:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3a6d1:	b0 01                	mov    $0x1,%al
   3a6d3:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a6d7:	b0 01                	mov    $0x1,%al
   3a6d9:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a6dd:	e9 14 02 00 00       	jmp    3a8f6 <oriole_expat::dispatch+0x6a86>
   3a6e2:	ff 15 10 c8 0a 00    	call   *0xac810(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a6e8:	49 89 c6             	mov    %rax,%r14
   3a6eb:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3a6f2:	00 
   3a6f3:	e8 28 66 ff ff       	call   30d20 <core::ptr::drop_glue::<oriole::ExternalEntityReference>>
   3a6f8:	b0 01                	mov    $0x1,%al
   3a6fa:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a6fe:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
   3a705:	00 
   3a706:	b0 01                	mov    $0x1,%al
   3a708:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a70c:	b0 01                	mov    $0x1,%al
   3a70e:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a712:	b0 01                	mov    $0x1,%al
   3a714:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a718:	b0 01                	mov    $0x1,%al
   3a71a:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a71e:	b0 01                	mov    $0x1,%al
   3a720:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a724:	b0 01                	mov    $0x1,%al
   3a726:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a72a:	e9 a2 01 00 00       	jmp    3a8d1 <oriole_expat::dispatch+0x6a61>
   3a72f:	ff 15 c3 c7 0a 00    	call   *0xac7c3(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
   3a735:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
   3a73a:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
   3a73f:	eb 00                	jmp    3a741 <oriole_expat::dispatch+0x68d1>
   3a741:	49 89 c6             	mov    %rax,%r14
   3a744:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
   3a74a:	74 21                	je     3a76d <oriole_expat::dispatch+0x68fd>
   3a74c:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
   3a751:	48 c1 e1 03          	shl    $0x3,%rcx
   3a755:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   3a75c:	00 
   3a75d:	ba 08 00 00 00       	mov    $0x8,%edx
   3a762:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   3a767:	ff 15 43 c1 0a 00    	call   *0xac143(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a76d:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
   3a774:	00 
   3a775:	e8 e6 58 ff ff       	call   30060 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3a77a:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   3a781:	00 
   3a782:	b0 01                	mov    $0x1,%al
   3a784:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a788:	48 85 c9             	test   %rcx,%rcx
   3a78b:	74 18                	je     3a7a5 <oriole_expat::dispatch+0x6935>
   3a78d:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
   3a794:	00 
   3a795:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   3a79a:	ba 01 00 00 00       	mov    $0x1,%edx
   3a79f:	ff 15 0b c1 0a 00    	call   *0xac10b(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a7a5:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
   3a7ac:	00 
   3a7ad:	b0 01                	mov    $0x1,%al
   3a7af:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a7b3:	b0 01                	mov    $0x1,%al
   3a7b5:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a7b9:	b0 01                	mov    $0x1,%al
   3a7bb:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a7bf:	e9 fb 00 00 00       	jmp    3a8bf <oriole_expat::dispatch+0x6a4f>
   3a7c4:	44 8b 64 24 38       	mov    0x38(%rsp),%r12d
   3a7c9:	49 89 c6             	mov    %rax,%r14
   3a7cc:	45 84 e4             	test   %r12b,%r12b
   3a7cf:	74 0d                	je     3a7de <oriole_expat::dispatch+0x696e>
   3a7d1:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   3a7d8:	00 
   3a7d9:	e8 62 4b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a7de:	80 7c 24 40 00       	cmpb   $0x0,0x40(%rsp)
   3a7e3:	74 0d                	je     3a7f2 <oriole_expat::dispatch+0x6982>
   3a7e5:	48 8d bc 24 20 04 00 	lea    0x420(%rsp),%rdi
   3a7ec:	00 
   3a7ed:	e8 4e 4b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a7f2:	84 db                	test   %bl,%bl
   3a7f4:	74 0d                	je     3a803 <oriole_expat::dispatch+0x6993>
   3a7f6:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
   3a7fd:	00 
   3a7fe:	e8 3d 4b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a803:	45 84 ed             	test   %r13b,%r13b
   3a806:	74 0d                	je     3a815 <oriole_expat::dispatch+0x69a5>
   3a808:	48 8d bc 24 60 05 00 	lea    0x560(%rsp),%rdi
   3a80f:	00 
   3a810:	e8 2b 4b ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a815:	b0 01                	mov    $0x1,%al
   3a817:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a81b:	45 84 ff             	test   %r15b,%r15b
   3a81e:	74 28                	je     3a848 <oriole_expat::dispatch+0x69d8>
   3a820:	48 8b 8c 24 f8 04 00 	mov    0x4f8(%rsp),%rcx
   3a827:	00 
   3a828:	48 85 c9             	test   %rcx,%rcx
   3a82b:	74 1b                	je     3a848 <oriole_expat::dispatch+0x69d8>
   3a82d:	48 8b b4 24 f0 04 00 	mov    0x4f0(%rsp),%rsi
   3a834:	00 
   3a835:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
   3a83c:	00 
   3a83d:	ba 01 00 00 00       	mov    $0x1,%edx
   3a842:	ff 15 68 c0 0a 00    	call   *0xac068(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a848:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
   3a84f:	00 
   3a850:	b0 01                	mov    $0x1,%al
   3a852:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a856:	b0 01                	mov    $0x1,%al
   3a858:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3a85c:	b0 01                	mov    $0x1,%al
   3a85e:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a862:	b0 01                	mov    $0x1,%al
   3a864:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a868:	b0 01                	mov    $0x1,%al
   3a86a:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a86e:	b0 01                	mov    $0x1,%al
   3a870:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a874:	b0 01                	mov    $0x1,%al
   3a876:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a87a:	b0 01                	mov    $0x1,%al
   3a87c:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a880:	b0 01                	mov    $0x1,%al
   3a882:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a886:	b0 01                	mov    $0x1,%al
   3a888:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3a88d:	eb 5b                	jmp    3a8ea <oriole_expat::dispatch+0x6a7a>
   3a88f:	49 89 c6             	mov    %rax,%r14
   3a892:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
   3a899:	00 
   3a89a:	e8 f1 79 ff ff       	call   32290 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   3a89f:	b0 01                	mov    $0x1,%al
   3a8a1:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3a8a5:	b0 01                	mov    $0x1,%al
   3a8a7:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3a8ab:	b0 01                	mov    $0x1,%al
   3a8ad:	89 44 24 40          	mov    %eax,0x40(%rsp)
   3a8b1:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
   3a8b8:	00 
   3a8b9:	b0 01                	mov    $0x1,%al
   3a8bb:	89 44 24 38          	mov    %eax,0x38(%rsp)
   3a8bf:	b0 01                	mov    $0x1,%al
   3a8c1:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3a8c5:	b0 01                	mov    $0x1,%al
   3a8c7:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3a8cb:	b0 01                	mov    $0x1,%al
   3a8cd:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   3a8d1:	b0 01                	mov    $0x1,%al
   3a8d3:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3a8d7:	b0 01                	mov    $0x1,%al
   3a8d9:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a8dd:	b0 01                	mov    $0x1,%al
   3a8df:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3a8e4:	b0 01                	mov    $0x1,%al
   3a8e6:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3a8ea:	b0 01                	mov    $0x1,%al
   3a8ec:	89 44 24 24          	mov    %eax,0x24(%rsp)
   3a8f0:	b0 01                	mov    $0x1,%al
   3a8f2:	89 44 24 18          	mov    %eax,0x18(%rsp)
   3a8f6:	b0 01                	mov    $0x1,%al
   3a8f8:	89 44 24 20          	mov    %eax,0x20(%rsp)
   3a8fc:	b0 01                	mov    $0x1,%al
   3a8fe:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   3a902:	e9 db 00 00 00       	jmp    3a9e2 <oriole_expat::dispatch+0x6b72>
   3a907:	49 89 c6             	mov    %rax,%r14
   3a90a:	48 8b 4b 68          	mov    0x68(%rbx),%rcx
   3a90e:	48 85 c9             	test   %rcx,%rcx
   3a911:	0f 84 ae 03 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3a917:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3a91c:	48 8b 77 60          	mov    0x60(%rdi),%rsi
   3a920:	48 83 c7 40          	add    $0x40,%rdi
   3a924:	ba 01 00 00 00       	mov    $0x1,%edx
   3a929:	ff 15 81 bf 0a 00    	call   *0xabf81(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a92f:	e9 91 03 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3a934:	49 89 c6             	mov    %rax,%r14
   3a937:	48 8b 4b 68          	mov    0x68(%rbx),%rcx
   3a93b:	48 85 c9             	test   %rcx,%rcx
   3a93e:	0f 84 81 03 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3a944:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3a949:	48 8b 77 60          	mov    0x60(%rdi),%rsi
   3a94d:	48 83 c7 40          	add    $0x40,%rdi
   3a951:	ba 01 00 00 00       	mov    $0x1,%edx
   3a956:	ff 15 54 bf 0a 00    	call   *0xabf54(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a95c:	e9 64 03 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3a961:	49 89 c6             	mov    %rax,%r14
   3a964:	48 83 c3 38          	add    $0x38,%rbx
   3a968:	48 89 df             	mov    %rbx,%rdi
   3a96b:	e8 d0 49 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a970:	e9 50 03 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3a975:	49 89 c6             	mov    %rax,%r14
   3a978:	48 83 c3 40          	add    $0x40,%rbx
   3a97c:	48 89 df             	mov    %rbx,%rdi
   3a97f:	e8 dc 56 ff ff       	call   30060 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3a984:	e9 3c 03 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3a989:	44 89 6c 24 1c       	mov    %r13d,0x1c(%rsp)
   3a98e:	44 89 64 24 20       	mov    %r12d,0x20(%rsp)
   3a993:	44 89 7c 24 18       	mov    %r15d,0x18(%rsp)
   3a998:	89 6c 24 24          	mov    %ebp,0x24(%rsp)
   3a99c:	49 89 c6             	mov    %rax,%r14
   3a99f:	eb 41                	jmp    3a9e2 <oriole_expat::dispatch+0x6b72>
   3a9a1:	49 89 c6             	mov    %rax,%r14
   3a9a4:	48 8b 8c 24 e8 01 00 	mov    0x1e8(%rsp),%rcx
   3a9ab:	00 
   3a9ac:	b0 01                	mov    $0x1,%al
   3a9ae:	89 44 24 28          	mov    %eax,0x28(%rsp)
   3a9b2:	48 85 c9             	test   %rcx,%rcx
   3a9b5:	75 09                	jne    3a9c0 <oriole_expat::dispatch+0x6b50>
   3a9b7:	b0 01                	mov    $0x1,%al
   3a9b9:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3a9be:	eb 22                	jmp    3a9e2 <oriole_expat::dispatch+0x6b72>
   3a9c0:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   3a9c7:	00 
   3a9c8:	ba 01 00 00 00       	mov    $0x1,%edx
   3a9cd:	48 8b b4 24 b8 01 00 	mov    0x1b8(%rsp),%rsi
   3a9d4:	00 
   3a9d5:	ff 15 d5 be 0a 00    	call   *0xabed5(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3a9db:	b0 01                	mov    $0x1,%al
   3a9dd:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3a9e2:	8b 44 24 2c          	mov    0x2c(%rsp),%eax
   3a9e6:	89 c3                	mov    %eax,%ebx
   3a9e8:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
   3a9ef:	00 
   3a9f0:	e8 4b 49 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3a9f5:	eb 09                	jmp    3aa00 <oriole_expat::dispatch+0x6b90>
   3a9f7:	49 89 c6             	mov    %rax,%r14
   3a9fa:	8b 44 24 2c          	mov    0x2c(%rsp),%eax
   3a9fe:	89 c3                	mov    %eax,%ebx
   3aa00:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3aa05:	48 8b 08             	mov    (%rax),%rcx
   3aa08:	48 83 e9 03          	sub    $0x3,%rcx
   3aa0c:	b8 0d 00 00 00       	mov    $0xd,%eax
   3aa11:	48 0f 43 c1          	cmovae %rcx,%rax
   3aa15:	48 83 c0 fa          	add    $0xfffffffffffffffa,%rax
   3aa19:	48 83 f8 14          	cmp    $0x14,%rax
   3aa1d:	0f 87 a2 02 00 00    	ja     3acc5 <oriole_expat::dispatch+0x6e55>
   3aa23:	48 8d 0d e6 f3 fc ff 	lea    -0x30c1a(%rip),%rcx        # 9e10 <std::thread::current::id::ID+0x9da0>
   3aa2a:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   3aa2e:	48 01 c8             	add    %rcx,%rax
   3aa31:	ff e0                	jmp    *%rax
   3aa33:	84 db                	test   %bl,%bl
   3aa35:	0f 84 8a 02 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3aa3b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3aa40:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3aa44:	48 85 c9             	test   %rcx,%rcx
   3aa47:	74 18                	je     3aa61 <oriole_expat::dispatch+0x6bf1>
   3aa49:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3aa4e:	48 8d 78 08          	lea    0x8(%rax),%rdi
   3aa52:	48 8b 70 28          	mov    0x28(%rax),%rsi
   3aa56:	ba 01 00 00 00       	mov    $0x1,%edx
   3aa5b:	ff 15 4f be 0a 00    	call   *0xabe4f(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3aa61:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3aa66:	48 83 c7 40          	add    $0x40,%rdi
   3aa6a:	e8 f1 55 ff ff       	call   30060 <core::ptr::drop_glue::<allocator_api2::stable::vec::Vec<oriole::Attribute, oriole_storage::allocator::Allocator>>>
   3aa6f:	e9 51 02 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3aa74:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3aa79:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3aa7d:	48 85 c9             	test   %rcx,%rcx
   3aa80:	0f 95 c0             	setne  %al
   3aa83:	84 44 24 40          	test   %al,0x40(%rsp)
   3aa87:	0f 85 17 02 00 00    	jne    3aca4 <oriole_expat::dispatch+0x6e34>
   3aa8d:	e9 33 02 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3aa92:	80 7c 24 50 00       	cmpb   $0x0,0x50(%rsp)
   3aa97:	0f 84 28 02 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3aa9d:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3aaa2:	48 83 c7 08          	add    $0x8,%rdi
   3aaa6:	e8 e5 77 ff ff       	call   32290 <core::ptr::drop_glue::<oriole_storage::string::Text>>
   3aaab:	e9 15 02 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3aab0:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3aab5:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3aab9:	48 85 c9             	test   %rcx,%rcx
   3aabc:	0f 95 c0             	setne  %al
   3aabf:	84 44 24 38          	test   %al,0x38(%rsp)
   3aac3:	0f 85 db 01 00 00    	jne    3aca4 <oriole_expat::dispatch+0x6e34>
   3aac9:	e9 f7 01 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3aace:	80 7c 24 48 00       	cmpb   $0x0,0x48(%rsp)
   3aad3:	0f 84 ec 01 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3aad9:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3aade:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3aae2:	48 85 c9             	test   %rcx,%rcx
   3aae5:	0f 84 8a 01 00 00    	je     3ac75 <oriole_expat::dispatch+0x6e05>
   3aaeb:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3aaf0:	48 8d 78 08          	lea    0x8(%rax),%rdi
   3aaf4:	48 8b 70 28          	mov    0x28(%rax),%rsi
   3aaf8:	ba 01 00 00 00       	mov    $0x1,%edx
   3aafd:	ff 15 ad bd 0a 00    	call   *0xabdad(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3ab03:	e9 6d 01 00 00       	jmp    3ac75 <oriole_expat::dispatch+0x6e05>
   3ab08:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
   3ab0d:	0f 84 b2 01 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3ab13:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3ab18:	48 8b 48 28          	mov    0x28(%rax),%rcx
   3ab1c:	bb 38 00 00 00       	mov    $0x38,%ebx
   3ab21:	48 85 c9             	test   %rcx,%rcx
   3ab24:	0f 84 b5 00 00 00    	je     3abdf <oriole_expat::dispatch+0x6d6f>
   3ab2a:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3ab2f:	48 8b 77 20          	mov    0x20(%rdi),%rsi
   3ab33:	ba 01 00 00 00       	mov    $0x1,%edx
   3ab38:	ff 15 72 bd 0a 00    	call   *0xabd72(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3ab3e:	e9 9c 00 00 00       	jmp    3abdf <oriole_expat::dispatch+0x6d6f>
   3ab43:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
   3ab48:	0f 84 77 01 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3ab4e:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3ab53:	48 8d 78 40          	lea    0x40(%rax),%rdi
   3ab57:	e8 e4 47 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3ab5c:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3ab61:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3ab65:	48 85 c9             	test   %rcx,%rcx
   3ab68:	0f 85 36 01 00 00    	jne    3aca4 <oriole_expat::dispatch+0x6e34>
   3ab6e:	e9 52 01 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3ab73:	80 7c 24 0c 00       	cmpb   $0x0,0xc(%rsp)
   3ab78:	0f 84 47 01 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3ab7e:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3ab83:	48 83 c7 08          	add    $0x8,%rdi
   3ab87:	e8 24 5b ff ff       	call   306b0 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::ExternalEntityReference, oriole_storage::allocator::Allocator>>>
   3ab8c:	e9 34 01 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3ab91:	80 7c 24 08 00       	cmpb   $0x0,0x8(%rsp)
   3ab96:	0f 84 29 01 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3ab9c:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3aba1:	48 83 c7 08          	add    $0x8,%rdi
   3aba5:	e8 76 5a ff ff       	call   30620 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::DoctypeDeclaration, oriole_storage::allocator::Allocator>>>
   3abaa:	e9 16 01 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3abaf:	80 7c 24 28 00       	cmpb   $0x0,0x28(%rsp)
   3abb4:	0f 84 0b 01 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3abba:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3abbf:	48 8d 78 08          	lea    0x8(%rax),%rdi
   3abc3:	bb 40 00 00 00       	mov    $0x40,%ebx
   3abc8:	e8 73 47 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3abcd:	eb 10                	jmp    3abdf <oriole_expat::dispatch+0x6d6f>
   3abcf:	bb 08 00 00 00       	mov    $0x8,%ebx
   3abd4:	80 7c 24 58 00       	cmpb   $0x0,0x58(%rsp)
   3abd9:	0f 84 e6 00 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3abdf:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3abe4:	48 01 df             	add    %rbx,%rdi
   3abe7:	e8 54 47 ff ff       	call   2f340 <core::ptr::drop_glue::<core::option::Option<oriole_storage::string::String>>>
   3abec:	e9 d4 00 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3abf1:	80 7c 24 10 00       	cmpb   $0x0,0x10(%rsp)
   3abf6:	0f 84 c9 00 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3abfc:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3ac01:	48 83 c7 08          	add    $0x8,%rdi
   3ac05:	e8 e6 59 ff ff       	call   305f0 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::EntityDeclaration, oriole_storage::allocator::Allocator>>>
   3ac0a:	e9 b6 00 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3ac0f:	80 7c 24 24 00       	cmpb   $0x0,0x24(%rsp)
   3ac14:	0f 84 ab 00 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3ac1a:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3ac1f:	48 83 c7 08          	add    $0x8,%rdi
   3ac23:	e8 58 5a ff ff       	call   30680 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::AttributeDeclaration, oriole_storage::allocator::Allocator>>>
   3ac28:	e9 98 00 00 00       	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3ac2d:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
   3ac32:	0f 84 8d 00 00 00    	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3ac38:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
   3ac3d:	48 83 c7 08          	add    $0x8,%rdi
   3ac41:	e8 0a 5a ff ff       	call   30650 <core::ptr::drop_glue::<allocator_api2::stable::boxed::Box<oriole::NotationDeclaration, oriole_storage::allocator::Allocator>>>
   3ac46:	eb 7d                	jmp    3acc5 <oriole_expat::dispatch+0x6e55>
   3ac48:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
   3ac4d:	74 76                	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3ac4f:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3ac54:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3ac58:	48 85 c9             	test   %rcx,%rcx
   3ac5b:	74 18                	je     3ac75 <oriole_expat::dispatch+0x6e05>
   3ac5d:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3ac62:	48 8d 78 08          	lea    0x8(%rax),%rdi
   3ac66:	48 8b 70 28          	mov    0x28(%rax),%rsi
   3ac6a:	ba 01 00 00 00       	mov    $0x1,%edx
   3ac6f:	ff 15 3b bc 0a 00    	call   *0xabc3b(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3ac75:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3ac7a:	48 8b 48 68          	mov    0x68(%rax),%rcx
   3ac7e:	48 85 c9             	test   %rcx,%rcx
   3ac81:	74 42                	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3ac83:	b8 60 00 00 00       	mov    $0x60,%eax
   3ac88:	bf 40 00 00 00       	mov    $0x40,%edi
   3ac8d:	eb 1f                	jmp    3acae <oriole_expat::dispatch+0x6e3e>
   3ac8f:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   3ac94:	48 8b 48 30          	mov    0x30(%rax),%rcx
   3ac98:	48 85 c9             	test   %rcx,%rcx
   3ac9b:	0f 95 c0             	setne  %al
   3ac9e:	84 44 24 1c          	test   %al,0x1c(%rsp)
   3aca2:	74 21                	je     3acc5 <oriole_expat::dispatch+0x6e55>
   3aca4:	b8 28 00 00 00       	mov    $0x28,%eax
   3aca9:	bf 08 00 00 00       	mov    $0x8,%edi
   3acae:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   3acb3:	48 01 d7             	add    %rdx,%rdi
   3acb6:	48 8b 34 02          	mov    (%rdx,%rax,1),%rsi
   3acba:	ba 01 00 00 00       	mov    $0x1,%edx
   3acbf:	ff 15 eb bb 0a 00    	call   *0xabbeb(%rip)        # e68b0 <_GLOBAL_OFFSET_TABLE_+0x138>
   3acc5:	4c 89 f7             	mov    %r14,%rdi
   3acc8:	e8 d3 1e ff ff       	call   2cba0 <_Unwind_Resume@plt>
   3accd:	ff 15 25 c2 0a 00    	call   *0xac225(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
