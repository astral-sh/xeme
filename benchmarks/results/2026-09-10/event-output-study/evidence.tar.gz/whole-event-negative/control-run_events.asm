
/tmp/oriole-event-dispatch/control.so:     file format elf64-x86-64


Disassembly of section .text:

0000000000032610 <oriole_expat::run_events>:
   32610:	55                   	push   %rbp
   32611:	41 57                	push   %r15
   32613:	41 56                	push   %r14
   32615:	41 55                	push   %r13
   32617:	41 54                	push   %r12
   32619:	53                   	push   %rbx
   3261a:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
   32621:	48 89 fb             	mov    %rdi,%rbx
   32624:	e8 37 0b 00 00       	call   33160 <oriole_expat::drain_default_fragments>
   32629:	31 c0                	xor    %eax,%eax
   3262b:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   32632:	0f 85 66 04 00 00    	jne    32a9e <oriole_expat::run_events+0x48e>
   32638:	4c 8d 7c 24 78       	lea    0x78(%rsp),%r15
   3263d:	48 8d ac 24 e8 00 00 	lea    0xe8(%rsp),%rbp
   32644:	00 
   32645:	48 8d 83 20 0a 00 00 	lea    0xa20(%rbx),%rax
   3264c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   32651:	4c 8d 64 24 68       	lea    0x68(%rsp),%r12
   32656:	4c 8d ac 24 e0 00 00 	lea    0xe0(%rsp),%r13
   3265d:	00 
   3265e:	e9 ab 00 00 00       	jmp    3270e <oriole_expat::run_events+0xfe>
   32663:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   3266a:	84 00 00 00 00 00 
   32670:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
   32677:	00 
   32678:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
   3267c:	0f 84 21 01 00 00    	je     327a3 <oriole_expat::run_events+0x193>
   32682:	48 8b 93 a8 06 00 00 	mov    0x6a8(%rbx),%rdx
   32689:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   3268e:	0f 10 45 60          	movups 0x60(%rbp),%xmm0
   32692:	41 0f 11 47 58       	movups %xmm0,0x58(%r15)
   32697:	0f 10 45 50          	movups 0x50(%rbp),%xmm0
   3269b:	41 0f 11 47 48       	movups %xmm0,0x48(%r15)
   326a0:	0f 10 45 40          	movups 0x40(%rbp),%xmm0
   326a4:	41 0f 11 47 38       	movups %xmm0,0x38(%r15)
   326a9:	0f 10 45 00          	movups 0x0(%rbp),%xmm0
   326ad:	0f 10 4d 10          	movups 0x10(%rbp),%xmm1
   326b1:	0f 10 55 20          	movups 0x20(%rbp),%xmm2
   326b5:	0f 10 5d 30          	movups 0x30(%rbp),%xmm3
   326b9:	41 0f 11 5f 28       	movups %xmm3,0x28(%r15)
   326be:	41 0f 11 57 18       	movups %xmm2,0x18(%r15)
   326c3:	41 0f 11 4f 08       	movups %xmm1,0x8(%r15)
   326c8:	41 0f 11 47 f8       	movups %xmm0,-0x8(%r15)
   326cd:	0f 10 45 70          	movups 0x70(%rbp),%xmm0
   326d1:	0f 10 8d 80 00 00 00 	movups 0x80(%rbp),%xmm1
   326d8:	48 8d 83 20 0a 00 00 	lea    0xa20(%rbx),%rax
   326df:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   326e3:	0f 11 00             	movups %xmm0,(%rax)
   326e6:	48 89 df             	mov    %rbx,%rdi
   326e9:	4c 89 e6             	mov    %r12,%rsi
   326ec:	e8 7f 17 00 00       	call   33e70 <oriole_expat::dispatch>
   326f1:	3c ff                	cmp    $0xff,%al
   326f3:	0f 85 d2 01 00 00    	jne    328cb <oriole_expat::run_events+0x2bb>
   326f9:	48 89 df             	mov    %rbx,%rdi
   326fc:	e8 5f 0a 00 00       	call   33160 <oriole_expat::drain_default_fragments>
   32701:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   32708:	0f 85 a2 01 00 00    	jne    328b0 <oriole_expat::run_events+0x2a0>
   3270e:	8b 83 14 0a 00 00    	mov    0xa14(%rbx),%eax
   32714:	85 c0                	test   %eax,%eax
   32716:	0f 85 8e 01 00 00    	jne    328aa <oriole_expat::run_events+0x29a>
   3271c:	83 bb 0c 0a 00 00 03 	cmpl   $0x3,0xa0c(%rbx)
   32723:	0f 84 8e 01 00 00    	je     328b7 <oriole_expat::run_events+0x2a7>
   32729:	48 c7 84 24 e0 00 00 	movq   $0xffffffffffffffff,0xe0(%rsp)
   32730:	00 ff ff ff ff 
   32735:	4c 89 e7             	mov    %r12,%rdi
   32738:	48 8d 73 30          	lea    0x30(%rbx),%rsi
   3273c:	4c 89 ea             	mov    %r13,%rdx
   3273f:	ff 15 d3 40 0b 00    	call   *0xb40d3(%rip)        # e6818 <_GLOBAL_OFFSET_TABLE_+0xa0>
   32745:	44 0f b6 b4 24 98 00 	movzbl 0x98(%rsp),%r14d
   3274c:	00 00 
   3274e:	49 81 fe ff 00 00 00 	cmp    $0xff,%r14
   32755:	0f 84 15 ff ff ff    	je     32670 <oriole_expat::run_events+0x60>
   3275b:	41 0f 10 07          	movups (%r15),%xmm0
   3275f:	41 0f 10 4f 10       	movups 0x10(%r15),%xmm1
   32764:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
   32769:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   3276e:	41 83 fe 11          	cmp    $0x11,%r14d
   32772:	0f 85 e2 00 00 00    	jne    3285a <oriole_expat::run_events+0x24a>
   32778:	48 89 df             	mov    %rbx,%rdi
   3277b:	e8 b0 0b 00 00       	call   33330 <oriole_expat::resolve_unknown_encoding>
   32780:	84 c0                	test   %al,%al
   32782:	0f 84 d2 00 00 00    	je     3285a <oriole_expat::run_events+0x24a>
   32788:	83 bc 24 e0 00 00 00 	cmpl   $0xffffffff,0xe0(%rsp)
   3278f:	ff 
   32790:	0f 84 63 ff ff ff    	je     326f9 <oriole_expat::run_events+0xe9>
   32796:	4c 89 ef             	mov    %r13,%rdi
   32799:	e8 32 e6 ff ff       	call   30dd0 <core::ptr::drop_glue::<oriole::Event>>
   3279e:	e9 56 ff ff ff       	jmp    326f9 <oriole_expat::run_events+0xe9>
   327a3:	4c 89 e7             	mov    %r12,%rdi
   327a6:	48 8d 73 30          	lea    0x30(%rbx),%rsi
   327aa:	ff 15 98 40 0b 00    	call   *0xb4098(%rip)        # e6848 <_GLOBAL_OFFSET_TABLE_+0xd0>
   327b0:	83 7c 24 68 01       	cmpl   $0x1,0x68(%rsp)
   327b5:	0f 85 23 01 00 00    	jne    328de <oriole_expat::run_events+0x2ce>
   327bb:	49 8b 47 18          	mov    0x18(%r15),%rax
   327bf:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   327c4:	41 0f 10 47 f8       	movups -0x8(%r15),%xmm0
   327c9:	41 0f 10 4f 08       	movups 0x8(%r15),%xmm1
   327ce:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   327d3:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   327d8:	48 8b 83 80 0b 00 00 	mov    0xb80(%rbx),%rax
   327df:	48 85 c0             	test   %rax,%rax
   327e2:	0f 84 01 01 00 00    	je     328e9 <oriole_expat::run_events+0x2d9>
   327e8:	48 8b bb 88 0b 00 00 	mov    0xb88(%rbx),%rdi
   327ef:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
   327f4:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
   327f9:	48 8d 8b 20 0a 00 00 	lea    0xa20(%rbx),%rcx
   32800:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
   32804:	0f 11 01             	movups %xmm0,(%rcx)
   32807:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   3280c:	ff d0                	call   *%rax
   3280e:	8b 8b 14 0a 00 00    	mov    0xa14(%rbx),%ecx
   32814:	85 c9                	test   %ecx,%ecx
   32816:	0f 85 11 02 00 00    	jne    32a2d <oriole_expat::run_events+0x41d>
   3281c:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   32823:	0f 85 db 00 00 00    	jne    32904 <oriole_expat::run_events+0x2f4>
   32829:	4c 89 e7             	mov    %r12,%rdi
   3282c:	48 8d 73 30          	lea    0x30(%rbx),%rsi
   32830:	89 c2                	mov    %eax,%edx
   32832:	ff 15 48 40 0b 00    	call   *0xb4048(%rip)        # e6880 <_GLOBAL_OFFSET_TABLE_+0x108>
   32838:	0f b6 84 24 98 00 00 	movzbl 0x98(%rsp),%eax
   3283f:	00 
   32840:	48 8d 0d 49 6c fd ff 	lea    -0x293b7(%rip),%rcx        # 9490 <std::thread::current::id::ID+0x9420>
   32847:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
   3284b:	48 01 c8             	add    %rcx,%rax
   3284e:	ff e0                	jmp    *%rax
   32850:	b9 01 00 00 00       	mov    $0x1,%ecx
   32855:	e9 ac 01 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   3285a:	31 c0                	xor    %eax,%eax
   3285c:	80 bb 0a 0a 00 00 00 	cmpb   $0x0,0xa0a(%rbx)
   32863:	0f 85 19 02 00 00    	jne    32a82 <oriole_expat::run_events+0x472>
   32869:	83 bb 14 0a 00 00 00 	cmpl   $0x0,0xa14(%rbx)
   32870:	0f 85 0c 02 00 00    	jne    32a82 <oriole_expat::run_events+0x472>
   32876:	48 8d 05 67 78 fd ff 	lea    -0x28799(%rip),%rax        # a0e4 <std::thread::current::id::ID+0xa074>
   3287d:	42 8b 04 b0          	mov    (%rax,%r14,4),%eax
   32881:	89 83 14 0a 00 00    	mov    %eax,0xa14(%rbx)
   32887:	89 83 10 0a 00 00    	mov    %eax,0xa10(%rbx)
   3288d:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   32892:	0f 28 4c 24 50       	movaps 0x50(%rsp),%xmm1
   32897:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   3289c:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   328a0:	0f 11 00             	movups %xmm0,(%rax)
   328a3:	31 c0                	xor    %eax,%eax
   328a5:	e9 d8 01 00 00       	jmp    32a82 <oriole_expat::run_events+0x472>
   328aa:	89 83 10 0a 00 00    	mov    %eax,0xa10(%rbx)
   328b0:	31 c0                	xor    %eax,%eax
   328b2:	e9 e7 01 00 00       	jmp    32a9e <oriole_expat::run_events+0x48e>
   328b7:	c7 83 10 0a 00 00 00 	movl   $0x0,0xa10(%rbx)
   328be:	00 00 00 
   328c1:	b8 02 00 00 00       	mov    $0x2,%eax
   328c6:	e9 d3 01 00 00       	jmp    32a9e <oriole_expat::run_events+0x48e>
   328cb:	48 b8 01 00 00 00 01 	movabs $0x100000001,%rax
   328d2:	00 00 00 
   328d5:	48 89 83 10 0a 00 00 	mov    %rax,0xa10(%rbx)
   328dc:	eb d2                	jmp    328b0 <oriole_expat::run_events+0x2a0>
   328de:	8b 8b 14 0a 00 00    	mov    0xa14(%rbx),%ecx
   328e4:	e9 44 01 00 00       	jmp    32a2d <oriole_expat::run_events+0x41d>
   328e9:	48 b8 12 00 00 00 12 	movabs $0x1200000012,%rax
   328f0:	00 00 00 
   328f3:	48 89 83 10 0a 00 00 	mov    %rax,0xa10(%rbx)
   328fa:	b9 12 00 00 00       	mov    $0x12,%ecx
   328ff:	e9 29 01 00 00       	jmp    32a2d <oriole_expat::run_events+0x41d>
   32904:	31 c9                	xor    %ecx,%ecx
   32906:	e9 22 01 00 00       	jmp    32a2d <oriole_expat::run_events+0x41d>
   3290b:	b9 28 00 00 00       	mov    $0x28,%ecx
   32910:	e9 f1 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   32915:	b9 26 00 00 00       	mov    $0x26,%ecx
   3291a:	e9 e7 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   3291f:	b9 2b 00 00 00       	mov    $0x2b,%ecx
   32924:	e9 dd 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   32929:	b9 27 00 00 00       	mov    $0x27,%ecx
   3292e:	e9 d3 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   32933:	b9 10 00 00 00       	mov    $0x10,%ecx
   32938:	e9 c9 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   3293d:	b9 0b 00 00 00       	mov    $0xb,%ecx
   32942:	e9 bf 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   32947:	b9 20 00 00 00       	mov    $0x20,%ecx
   3294c:	e9 b5 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   32951:	b9 11 00 00 00       	mov    $0x11,%ecx
   32956:	e9 ab 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   3295b:	b9 13 00 00 00       	mov    $0x13,%ecx
   32960:	e9 a1 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   32965:	b9 18 00 00 00       	mov    $0x18,%ecx
   3296a:	e9 97 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   3296f:	b9 09 00 00 00       	mov    $0x9,%ecx
   32974:	e9 8d 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   32979:	b9 0a 00 00 00       	mov    $0xa,%ecx
   3297e:	e9 83 00 00 00       	jmp    32a06 <oriole_expat::run_events+0x3f6>
   32983:	b9 0d 00 00 00       	mov    $0xd,%ecx
   32988:	eb 7c                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   3298a:	b9 08 00 00 00       	mov    $0x8,%ecx
   3298f:	eb 75                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   32991:	b9 1e 00 00 00       	mov    $0x1e,%ecx
   32996:	eb 6e                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   32998:	b9 15 00 00 00       	mov    $0x15,%ecx
   3299d:	eb 67                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   3299f:	b9 05 00 00 00       	mov    $0x5,%ecx
   329a4:	eb 60                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329a6:	b9 0c 00 00 00       	mov    $0xc,%ecx
   329ab:	eb 59                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329ad:	b9 04 00 00 00       	mov    $0x4,%ecx
   329b2:	eb 52                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329b4:	b9 02 00 00 00       	mov    $0x2,%ecx
   329b9:	eb 4b                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329bb:	b9 12 00 00 00       	mov    $0x12,%ecx
   329c0:	eb 44                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329c2:	b9 03 00 00 00       	mov    $0x3,%ecx
   329c7:	eb 3d                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329c9:	b9 1c 00 00 00       	mov    $0x1c,%ecx
   329ce:	eb 36                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329d0:	b9 07 00 00 00       	mov    $0x7,%ecx
   329d5:	eb 2f                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329d7:	b9 1d 00 00 00       	mov    $0x1d,%ecx
   329dc:	eb 28                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329de:	b9 14 00 00 00       	mov    $0x14,%ecx
   329e3:	eb 21                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329e5:	b9 1b 00 00 00       	mov    $0x1b,%ecx
   329ea:	eb 1a                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329ec:	b9 06 00 00 00       	mov    $0x6,%ecx
   329f1:	eb 13                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329f3:	b9 0e 00 00 00       	mov    $0xe,%ecx
   329f8:	eb 0c                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   329fa:	b9 0f 00 00 00       	mov    $0xf,%ecx
   329ff:	eb 05                	jmp    32a06 <oriole_expat::run_events+0x3f6>
   32a01:	b9 24 00 00 00       	mov    $0x24,%ecx
   32a06:	89 8b 14 0a 00 00    	mov    %ecx,0xa14(%rbx)
   32a0c:	89 8b 10 0a 00 00    	mov    %ecx,0xa10(%rbx)
   32a12:	0f 10 44 24 78       	movups 0x78(%rsp),%xmm0
   32a17:	0f 10 8c 24 88 00 00 	movups 0x88(%rsp),%xmm1
   32a1e:	00 
   32a1f:	48 8d 83 20 0a 00 00 	lea    0xa20(%rbx),%rax
   32a26:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   32a2a:	0f 11 00             	movups %xmm0,(%rax)
   32a2d:	31 c0                	xor    %eax,%eax
   32a2f:	85 c9                	test   %ecx,%ecx
   32a31:	75 4f                	jne    32a82 <oriole_expat::run_events+0x472>
   32a33:	0f 10 83 c0 08 00 00 	movups 0x8c0(%rbx),%xmm0
   32a3a:	0f 10 8b d0 08 00 00 	movups 0x8d0(%rbx),%xmm1
   32a41:	48 8d 83 20 0a 00 00 	lea    0xa20(%rbx),%rax
   32a48:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   32a4c:	0f 11 00             	movups %xmm0,(%rax)
   32a4f:	80 bb e9 08 00 00 00 	cmpb   $0x0,0x8e9(%rbx)
   32a56:	74 1b                	je     32a73 <oriole_expat::run_events+0x463>
   32a58:	48 89 df             	mov    %rbx,%rdi
   32a5b:	e8 90 04 00 00       	call   32ef0 <oriole_expat::merge_external_subset>
   32a60:	84 c0                	test   %al,%al
   32a62:	b8 00 00 00 00       	mov    $0x0,%eax
   32a67:	74 19                	je     32a82 <oriole_expat::run_events+0x472>
   32a69:	c7 83 0c 0a 00 00 02 	movl   $0x2,0xa0c(%rbx)
   32a70:	00 00 00 
   32a73:	c7 83 10 0a 00 00 00 	movl   $0x0,0xa10(%rbx)
   32a7a:	00 00 00 
   32a7d:	b8 01 00 00 00       	mov    $0x1,%eax
   32a82:	48 83 bc 24 e0 00 00 	cmpq   $0xffffffffffffffff,0xe0(%rsp)
   32a89:	00 ff 
   32a8b:	74 11                	je     32a9e <oriole_expat::run_events+0x48e>
   32a8d:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   32a94:	00 
   32a95:	89 c3                	mov    %eax,%ebx
   32a97:	e8 34 e3 ff ff       	call   30dd0 <core::ptr::drop_glue::<oriole::Event>>
   32a9c:	89 d8                	mov    %ebx,%eax
   32a9e:	48 81 c4 78 01 00 00 	add    $0x178,%rsp
   32aa5:	5b                   	pop    %rbx
   32aa6:	41 5c                	pop    %r12
   32aa8:	41 5d                	pop    %r13
   32aaa:	41 5e                	pop    %r14
   32aac:	41 5f                	pop    %r15
   32aae:	5d                   	pop    %rbp
   32aaf:	c3                   	ret
   32ab0:	0f 0b                	ud2
   32ab2:	eb 00                	jmp    32ab4 <oriole_expat::run_events+0x4a4>
   32ab4:	48 89 c3             	mov    %rax,%rbx
   32ab7:	83 bc 24 e0 00 00 00 	cmpl   $0xffffffff,0xe0(%rsp)
   32abe:	ff 
   32abf:	74 0d                	je     32ace <oriole_expat::run_events+0x4be>
   32ac1:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   32ac8:	00 
   32ac9:	e8 02 e3 ff ff       	call   30dd0 <core::ptr::drop_glue::<oriole::Event>>
   32ace:	48 89 df             	mov    %rbx,%rdi
   32ad1:	e8 ca a0 ff ff       	call   2cba0 <_Unwind_Resume@plt>
   32ad6:	ff 15 1c 44 0b 00    	call   *0xb441c(%rip)        # e6ef8 <_GLOBAL_OFFSET_TABLE_+0x780>
