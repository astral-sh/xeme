"""Recompute reported benchmark statistics and metadata from retained observations."""
from pathlib import Path
import collections,datetime,hashlib,json,math,statistics
BASE=Path('/tmp');REPO=Path('/home/dev-user/code/oss/oriole');issues=[];reports={}
def read(path):return json.loads(Path(path).read_text())
def digest(path):
 with Path(path).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def check(condition,message):
 if not condition:issues.append(message)
def same(a,b):
 if isinstance(a,float)or isinstance(b,float):return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-15)
 if isinstance(a,list)and isinstance(b,list):return len(a)==len(b)and all(same(x,y)for x,y in zip(a,b))
 if isinstance(a,dict)and isinstance(b,dict):return a.keys()==b.keys()and all(same(a[k],b[k])for k in a)
 return a==b
def hashes(r,label):
 check(r['sha256_before']==r['sha256_after'],label+' before/after hash mismatch')
 for path,expected in r['sha256_after'].items():check(digest(path)==expected,label+' current hash mismatch: '+path)
def med(samples,iterations,label):
 check(len(samples)==iterations+1 and sum(s['warmup']for s in samples)==1 and samples[0]['warmup'],label+' sample/warmup count')
 check(all(s['seconds']>0 for s in samples),label+' nonpositive time')
 return statistics.median(s['seconds']for s in samples if not s['warmup'])
def consistency(samples,fields,label):
 key=lambda s:tuple(s[f]for f in fields)
 check(len({key(s)for s in samples})==1,label+' sample metadata changed');return key(samples[0])
for mode in ['plain','namespaces']:
 path=BASE/('oriole-grammar-bench-'+mode);r=read(path/'summary.json');hashes(r,mode);check(r['status']=='passed'and r['affinity']==[0]and r['pairs']==7 and r['iterations']==10 and len(r['rows'])==168,mode+' configuration/count mismatch')
 groups=collections.defaultdict(dict);metadata={};versions={}
 for row in r['rows']:
  key=row['workload']+'/'+str(row['chunk_size']);slot=(row['engine'],row['pair']);check(slot not in groups[key],mode+' duplicate process row');groups[key][slot]=med(row['samples'],10,mode+'/'+key);meta=consistency(row['samples'],['hash','elements','text_bytes'],mode+'/'+key)
  check(key not in metadata or metadata[key]==meta,mode+' cross-engine callback hash mismatch: '+key);metadata[key]=meta;versions[row['engine']]=row['version']
  check((len(row['command'])==6 and row['command'][-1]=='namespaces')==r['namespaces'],mode+' namespace invocation mismatch')
 for key,values in groups.items():
  v=r['summary'][key];process={engine:[values[(engine,pair)]for pair in range(7)]for engine in ['oriole','expat']};ratios=[process['expat'][i]/process['oriole'][i]for i in range(7)]
  computed={'process_medians_seconds':process,'median_seconds':{k:statistics.median(x)for k,x in process.items()},'paired_expat_over_oriole':ratios,'median_expat_over_oriole':statistics.median(ratios),'range_expat_over_oriole':[min(ratios),max(ratios)]}
  for k,value in computed.items():check(same(value,v[k]),mode+' arithmetic mismatch: '+key+'/'+k)
  check(v['input_bytes']==(path/(key.split('/')[0]+'.xml')).stat().st_size,mode+' input length mismatch')
 preflight=read(path/'preflight-results.json');check(len(preflight)==12 and {x['workload']+'/'+str(x['chunk'])for x in preflight}==set(groups),mode+' preflight coverage');check((path/'preflight.log').read_text()=='',mode+' preflight errors')
 reports[mode]={'configurations':len(groups),'processes':len(r['rows']),'timed_samples':len(r['rows'])*10,'preflight_configurations':len(preflight),'versions':versions,'ratios':{k:v['median_expat_over_oriole']for k,v in r['summary'].items()},'limitations':r['limitations']}
p=BASE/'oriole-grammar-allocator-bench';r=read(p/'summary.json');hashes(r,'allocators');groups=collections.defaultdict(dict);metadata={}
check(r['status']=='passed'and r['affinity']==[0]and len(r['rows'])==252,'allocator configuration/count mismatch')
for row in r['rows']:
 key=row['workload']+'/'+str(row['chunk']);slot=(row['label'],row['pair']);check(not row['instrumented'],'instrumented row entered timings');check(slot not in groups[key],'duplicate allocator process');groups[key][slot]=med(row['samples'],10,'allocators/'+key);meta=consistency(row['samples'],['hash','elements','text_bytes'],'allocators/'+key);check(key not in metadata or metadata[key]==meta,'allocator metadata mismatch');metadata[key]=meta
for key,values in groups.items():
 v=r['summary'][key];process={label:[values[(label,pair)]for pair in range(7)]for label in ['system','jemalloc','mimalloc']};ratios={label:[process['system'][i]/samples[i]for i in range(7)]for label,samples in process.items()};computed={'process_medians_seconds':process,'median_seconds':{k:statistics.median(x)for k,x in process.items()},'paired_baseline_over_candidate':ratios}
 for k,value in computed.items():check(same(value,v[k]),'allocator arithmetic mismatch: '+key+'/'+k)
 check(v['input_bytes']==(Path('/tmp/oriole-dtd-bench-plain')/(key.split('/')[0]+'.xml')).stat().st_size,'allocator input length mismatch')
counts={}
for row in r['allocation_counts']:
 key=row['workload']+'/'+str(row['chunk']);check(row['instrumented']and row['label']=='counts','counting row provenance');med(row['samples'],10,'counts/'+key);meta=consistency(row['samples'],['hash','elements','text_bytes'],'counts/'+key);check(meta==metadata[key],'instrumented metadata differs from timings');allocation=consistency(row['samples'],['allocation_calls','requested_bytes'],'counts/'+key);counts[key]=dict(zip(['allocation_calls','requested_bytes'],allocation))
check(set(counts)==set(groups)and len(counts)==12,'allocation counter coverage')
reports['allocators']={'processes':len(r['rows']),'timed_samples':len(r['rows'])*10,'counting_processes':len(counts),'instrumented_timing_rows':0,'counts':counts,'limitations':r['limitations']}
p=BASE/'oriole-grammar-dtd-bench';r=read(p/'results.json');hashes(r,'DTD');check(r['status']=='passed'and r['affinity']==[0]and len(r['rows'])==630 and len(r['preflight'])==90,'DTD configuration/count mismatch')
groups=collections.defaultdict(dict);metadata={}
for row in r['rows']:
 key=row['file']+'/'+str(row['chunk']);slot=(row['engine'],row['pair']);check(row['exit_code']==0 and row['stderr']=='','DTD process failed');check(slot not in groups[key],'DTD duplicate process row');samples=row['result']['samples'];groups[key][slot]=med(samples,5,'DTD/'+key);meta=consistency(samples,['hash','declarations','external_calls'],'DTD/'+key);check(key not in metadata or metadata[key]==meta,'DTD timed metadata differs');metadata[key]=meta
for key,values in groups.items():
 v=r['summary'][key];process={engine:[values[(engine,pair)]for pair in range(7)]for engine in ['oriole','expat']};ratio=statistics.median(process['expat'][i]/process['oriole'][i]for i in range(7));computed={'process_medians_seconds':process,'median_seconds':{k:statistics.median(x)for k,x in process.items()},'median_expat_over_oriole':ratio}
 for k,value in computed.items():check(same(value,v[k]),'DTD arithmetic mismatch: '+key+'/'+k)
preflight=collections.defaultdict(dict)
for row in r['preflight']:
 key=row['file']+'/'+str(row['chunk']);check(row['exit_code']==0 and row['stderr']=='','DTD preflight failed');samples=row['result']['samples'];med(samples,1,'DTD preflight/'+key);meta=consistency(samples,['trace','hash','declarations','external_calls'],'DTD preflight/'+key);preflight[key][row['engine']]=meta;check(meta[1:]==metadata[key],'DTD trace/timing metadata differs')
check(set(preflight)==set(groups),'DTD preflight configuration coverage');check(all(v['oriole']==v['expat']for v in preflight.values()),'DTD full trace mismatch')
reports['dtd']={'configurations':len(groups),'timed_processes':len(r['rows']),'timed_samples':len(r['rows'])*5,'preflight_processes':len(r['preflight']),'exact_trace_pairs':len(preflight),'limitations':r['limitations']}
build_root=BASE/'oriole-grammar-bench-build';build=read(build_root/'build.json');check(build['status']=='passed'and build['source_before']==build['source_after'],'allocator build mutation/failure')
for name,expected in build['source_after'].items():check(digest(REPO/name)==expected,'allocator build source hash mismatch: '+name)
for row in build['builds']:check(row['exit_code']==0 and digest(build_root/('bench-'+row['label']))==row['binary_sha256'],'allocator binary build/hash mismatch: '+row['label'])
dtd=read(build_root/'dtd-build.json')
for name,expected in dtd['files'].items():check(digest(name)==expected,'DTD driver source hash mismatch: '+name)
parser=read(BASE/'oriole-grammar-combined-source/source.json');check(dtd['parser_source']==parser,'DTD parser source manifest mismatch')
for name,expected in parser['sources'].items():
 if name in build['source_after']:check(build['source_after'][name]==expected,'safe-core parser differs from ff5d source: '+name)
measurements=read(build_root/'measurements.json');check(measurements['status']=='passed'and len(measurements['runs'])==4 and all(row['returncode']==0 and row['command'][:3]==['taskset','-c','0']for row in measurements['runs']),'timing controller failure/affinity')
parse_time=datetime.datetime.fromisoformat;prior_end=None
for row in measurements['runs']:
 if prior_end:check(parse_time(row['started'])>=prior_end,'timing processes overlap')
 prior_end=parse_time(row['finished'])
fuzz=read(BASE/'oriole-final-grammar-campaign-handoff/summary.json')
for row in fuzz['campaigns'].values():
 end=parse_time(row['started_at_utc'].replace('Z','+00:00'))+datetime.timedelta(seconds=row['campaign_elapsed_seconds']);check(parse_time(measurements['started'])>end,'timings overlap final fuzzer')
reports['provenance']={'runtime_commit':build['runtime_commit'],'shared_library_sha256':parser['libraries']['liboriole_expat.so'],'allocator_builds':4,'driver_reuse':'Reviewed C driver binary is unchanged; it dynamically loads the final ff5d library supplied in each command. Earlier driver build-context parser hashes are not the timing target.','timing_affinity':[0],'timing_processes_sequential':True,'timings_after_final_fuzzers':True}
output=BASE/'oriole-final-benchmark-independent-review.json';output.write_text(json.dumps({'reviewer':'/root/ffi/multibyte_fuzz','method':'Independent read-only recomputation from every retained sample; no process rerun.','issues':issues,'reports':reports,'driver_sanitizer_independent_review':{'path':str(BASE/'oriole-driver-asan-independent-review.json'),'sha256':digest(BASE/'oriole-driver-asan-independent-review.json'),'scope':'C driver ASan/UBSan; Rust release library uninstrumented. 60processes/30pairs, both samples compared; initial full-JSON comparison mistake preserved separately.','issues':read(BASE/'oriole-driver-asan-independent-review.json')['issues']}},indent=2)+'\n');print(json.dumps({'issues':issues,'artifact':str(output),'sha256':digest(output)}))
if issues:raise SystemExit(1)
