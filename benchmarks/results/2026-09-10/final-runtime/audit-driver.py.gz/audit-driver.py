"""Read-only audit of the frozen C DTD benchmark-driver sanitizer evidence."""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import math
import subprocess

root = Path('/tmp/oriole-grammar-driver-asan')
report = json.loads((root / 'report.json').read_text())
initial = json.loads((root / 'initial-report-including-timing.json').read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert report['sha256_before'] == report['sha256_after']
for path, value in report['sha256_before'].items():
    assert digest(Path(path)) == value, path
assert initial['rows'] == report['rows']
assert len(report['rows']) == 60
fields = ['trace', 'hash', 'declarations', 'external_calls']
groups = defaultdict(dict)
sample_count = 0
verified_logs = {}
commands = set()
for row in report['rows']:
    command = row['command']
    assert tuple(command) not in commands
    commands.add(tuple(command))
    assert row['returncode'] == 0
    assert command[4:] == ['1', '--trace']
    for channel in ['stdout', 'stderr']:
        path = root / row[channel]
        assert digest(path) == row[channel + '_sha256']
        verified_logs[row[channel]] = digest(path)
    assert not (root / row['stderr']).read_bytes()
    output = json.loads((root / row['stdout']).read_text())
    samples = output['samples']
    assert len(samples) == 2
    assert [sample['warmup'] for sample in samples] == [True, False]
    selected = []
    for sample in samples:
        assert math.isfinite(sample['seconds']) and sample['seconds'] > 0
        value = 14695981039346656037
        for byte in bytes.fromhex(sample['trace']):
            value = ((value ^ byte) * 1099511628211) & ((1 << 64) - 1)
        assert f'{value:016x}' == sample['hash']
        selected.append({key: sample[key] for key in fields})
        sample_count += 1
    assert selected[0] == selected[1]
    groups[(Path(command[2]).name, int(command[3]))][command[1]] = selected

assert len(groups) == 30
assert len({name for name, _ in groups}) == 15
assert {chunk for _, chunk in groups} == {1, 4096}
comparisons = []
for (name, chunk), libraries in sorted(groups.items()):
    assert len(libraries) == 2
    first, second = libraries.values()
    assert first == second
    comparisons.append({'input': name, 'chunk': chunk, 'equal': True, 'samples': 2, 'fields': fields})
assert sorted(report['trace_comparisons'], key=lambda row: (row['input'], row['chunk'])) == comparisons
driver = Path(report['rows'][0]['command'][0])
symbols = subprocess.check_output(['nm', '-D', str(driver)], text=True)
assert '__asan_init' in symbols and '__ubsan_handle_' in symbols
candidate = Path('/tmp/oriole-grammar-combined-source/liboriole_expat.so')
assert '__asan_init' not in subprocess.check_output(['nm', '-D', str(candidate)], text=True)
result = {
    'status': 'passed', 'reviewer': '/root/ffi/conditional_review',
    'method': 'Independent read-only artifact audit; no driver or parser executions were rerun.',
    'report_sha256': digest(root / 'report.json'),
    'initial_report_sha256': digest(root / 'initial-report-including-timing.json'),
    'initial_runner_sha256': digest(root / 'initial-runner.py'),
    'generator_sha256': digest(Path(__file__)),
    'verified_before_after_current_hashes': len(report['sha256_before']),
    'unique_processes_returned_zero': len(commands),
    'stdout_stderr_hashes_verified': len(verified_logs),
    'stderr_nonempty': 0,
    'retained_samples_fnv1a_recomputed': sample_count,
    'matching_pairs': comparisons,
    'source_library_driver_hashes': report['sha256_before'],
    'conclusions': ['All 60 processes succeeded, every stdout/stderr hash verifies, and all 20 recorded input/source/library/driver hashes remain unchanged.',
                    'All 120 retained sample traces independently reproduce the reported FNV-1a hashes. Warmup and measured samples agree on trace/hash/declarations/external_calls.',
                    'All 30 input/chunk pairs match exactly between libraries for both retained samples.',
                    'The initial complete-JSON comparison mistake is preserved. Process rows and their exact outputs are identical in the initial and corrected reports; only metadata postprocessing changed.'],
    'scope': ['C benchmark driver has AddressSanitizer and UndefinedBehaviorSanitizer symbols and the recorded build flags. The linked Rust release library is uninstrumented in this check.',
              'LeakSanitizer is disabled. This is separate from the three instrumented Rust fuzz campaigns.',
              'Timing and engine version are intentionally excluded from cross-library metadata equality; they are retained in raw outputs.',
              'No benchmark speed or full parser compatibility claim follows from this driver artifact audit.'],
    'issues': [],
}
Path('/tmp/oriole-driver-asan-independent-review.json').write_text(json.dumps(result, indent=2) + '\n')
print({key: value for key, value in result.items() if key not in ['matching_pairs', 'source_library_driver_hashes', 'conclusions', 'scope']})
