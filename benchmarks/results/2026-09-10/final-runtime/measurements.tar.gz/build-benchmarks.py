from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path('/home/dev-user/code/oss/oriole');out=Path('/tmp/oriole-grammar-bench-build');out.mkdir(exist_ok=False)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=sorted(root.glob('crates/*/src/**/*.rs'))+sorted(root.glob('crates/*/Cargo.toml'))+sorted((root/'benchmarks/inprocess').rglob('*.rs'))+[root/'benchmarks/inprocess/Cargo.toml',root/'benchmarks/inprocess/Cargo.lock',root/'Cargo.toml',root/'Cargo.lock']
observed={str(p.relative_to(root)):digest(p) for p in paths}
env={**os.environ,'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST':'all','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all'}
report={'status':'incomplete','runtime_commit':'1262888','root_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_before':observed,'toolchain':subprocess.check_output(['rustc','+ohm','-Vv'],text=True),'environment':{k:env[k] for k in ['CARGO_HOME','CARGO_BUILD_BUILD_DIR','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST']},'builds':[]}
try:
 for label,feature in [('system',None),('jemalloc','jemalloc'),('mimalloc','mimalloc'),('counts','allocation-counts')]:
  target=Path('/home/dev-user/.cache/oriole')/('grammar-bench-'+label+'-target')
  command=['cargo','+ohm','build','--release','--locked','--offline','--manifest-path','benchmarks/inprocess/Cargo.toml']
  if feature:command+=['--features',feature]
  record={'label':label,'feature':feature,'command':command,'CARGO_TARGET_DIR':str(target)};report['builds'].append(record)
  with (out/(label+'.log')).open('w') as log:
   result=subprocess.run(command,cwd=root,env={**env,'CARGO_TARGET_DIR':str(target)},stdout=log,stderr=subprocess.STDOUT,timeout=900)
  record['exit_code']=result.returncode
  if result.returncode:raise RuntimeError('build failed: '+label)
  binary=out/('bench-'+label);shutil.copy2(target/'release/oriole-inprocess-benchmark',binary)
  record['binary_sha256']=digest(binary)
  (out/'build.json').write_text(json.dumps(report,indent=2)+'\n')
  print(label,'built',record['binary_sha256'],flush=True)
 report['source_after']={str(p.relative_to(root)):digest(p) for p in paths}
 assert report['source_after']==observed
 report['status']='passed'
finally:
 (out/'build.json').write_text(json.dumps(report,indent=2)+'\n')
