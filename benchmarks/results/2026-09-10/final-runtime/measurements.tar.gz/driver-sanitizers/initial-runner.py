import hashlib,json,os,subprocess
from pathlib import Path
out=Path('/tmp/oriole-grammar-driver-asan'); out.mkdir()
prior=json.load(open('/tmp/oriole-dtd-scaling/final-driver-sanitizer-review.json'))
driver=Path('/tmp/oriole-dtd-scaling/final-native-driver-asan')
libs=[Path('/tmp/oriole-grammar-combined-source/liboriole_expat.so'),Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4')]
inputs=sorted(Path('/tmp/oriole-grammar-dtd-inputs').glob('*.dtd'))
files=[driver,*libs,*inputs,Path('/home/dev-user/code/oss/oriole/benchmarks/native_dtd_driver.c'),Path('/home/dev-user/code/oss/oriole/include/expat.h')]
def hashes(): return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
report={'scope':'C native DTD driver ASan/UBSan; linked Rust release library is uninstrumented. Leak sanitizer disabled. 15 generated DTD fixtures, two libraries, chunks1/4096, exact metadata trace comparison.', 'prior_build':prior['build_command'],'environment':{'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},'sha256_before':hashes(),'rows':[]}
traces={}
for li,lib in enumerate(libs):
 for path in inputs:
  for chunk in (1,4096):
   command=[str(driver),str(lib),str(path),str(chunk),'1','--trace']
   p=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,**report['environment']},timeout=30)
   name=f'{li}-{path.stem}-{chunk}'
   (out/f'{name}.stdout').write_bytes(p.stdout);(out/f'{name}.stderr').write_bytes(p.stderr)
   row={'command':command,'returncode':p.returncode,'stdout':name+'.stdout','stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':name+'.stderr','stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
   report['rows'].append(row)
   if p.returncode: raise RuntimeError(row)
   traces[(li,path.name,chunk)]=p.stdout.splitlines()[0]
report['trace_comparisons']=[{'input':p.name,'chunk':c,'equal':traces[(0,p.name,c)]==traces[(1,p.name,c)]} for p in inputs for c in (1,4096)]
report['sha256_after']=hashes()
report['status']='passed' if all(r['equal'] for r in report['trace_comparisons']) and report['sha256_before']==report['sha256_after'] else 'failed'
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['status'],len(report['rows']),len(report['trace_comparisons']))
assert report['status']=='passed'
