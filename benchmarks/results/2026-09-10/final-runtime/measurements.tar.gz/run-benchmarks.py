import datetime, json, subprocess
from pathlib import Path
root=Path('/home/dev-user/code/oss/oriole')
out=Path('/tmp/oriole-grammar-bench-build')
lib='/tmp/oriole-grammar-combined-source/liboriole_expat.so'
ref='/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4'
source='/tmp/oriole-grammar-combined-source/source.json'
commands=[
 ['python3','benchmarks/run.py','--library',lib,'--reference',ref,'--output','/tmp/oriole-grammar-bench-plain','--build-manifest',source,'--build-manifest',str(out/'host.json')],
 ['python3','benchmarks/run.py','--library',lib,'--reference',ref,'--output','/tmp/oriole-grammar-bench-namespaces','--namespaces','--build-manifest',source,'--build-manifest',str(out/'host.json')],
 ['python3','benchmarks/allocators.py','--binary',f'system={out}/bench-system','--binary',f'jemalloc={out}/bench-jemalloc','--binary',f'mimalloc={out}/bench-mimalloc','--counts',str(out/'bench-counts'),'--inputs','/tmp/oriole-dtd-bench-plain','--output','/tmp/oriole-grammar-allocator-bench','--build-manifest',str(out/'build.json'),'--build-manifest',str(out/'host.json')],
 ['python3','benchmarks/dtd_scaling.py','--library',lib,'--reference',ref,'--inputs','/tmp/oriole-grammar-dtd-inputs','--driver',str(out/'native-dtd-driver'),'--build-manifest',str(out/'dtd-build.json'),'--output','/tmp/oriole-grammar-dtd-bench'],
]
report={'started':datetime.datetime.now(datetime.UTC).isoformat(),'method':'Sequential timings pinned to CPU0 after all final ASan campaigns/stress processes exited; shared host frequency and load uncontrolled.','runs':[]}
for i,args in enumerate(commands):
 command=['taskset','-c','0',*args]
 log=out/f'measurement-{i}.log'
 row={'command':command,'started':datetime.datetime.now(datetime.UTC).isoformat(),'log':str(log)}
 report['runs'].append(row)
 (out/'measurements.json').write_text(json.dumps(report,indent=2)+'\n')
 print('START',i,flush=True)
 with log.open('w') as f:
  proc=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=1200)
 row.update(returncode=proc.returncode,finished=datetime.datetime.now(datetime.UTC).isoformat())
 (out/'measurements.json').write_text(json.dumps(report,indent=2)+'\n')
 print('END',i,proc.returncode,flush=True)
 if proc.returncode:raise SystemExit(proc.returncode)
report['status']='passed'
report['finished']=datetime.datetime.now(datetime.UTC).isoformat()
(out/'measurements.json').write_text(json.dumps(report,indent=2)+'\n')
