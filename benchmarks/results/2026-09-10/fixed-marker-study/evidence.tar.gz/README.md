# Constant forbidden-marker search candidate

The one-line patch replaces `str::find("]]>" )` with `memchr::memmem::find` on the same bytes and ASCII needle. The existing invalid-character check still precedes it; the first byte offset, malformed-prefix handling, raw/custom provenance, limits and callbacks are unchanged. `memchr` was already a pinned dependency. Root will assess this candidate on the selected combined baseline before accepting it.

## Validation

Final library `9233b675` passes all seven selected-allocation/OOM/lifetime tests, strict release core/FFI Clippy, formatting, 2,392 malformed comparisons, 32 suspension/DefaultCurrent/raw-context cases, and 15,288 custom-provenance comparisons. All 4,740 public upstream observations are exactly unchanged: 4,077 pass and 663 fail, with library origin verified and no timeout. Failed assertions remain in the evidence. No full core/FFI test suite or new sanitizer campaign is claimed here.

The initial form (`72738f45`) triggered the Clippy lint for slicing a string before `as_bytes`. Its source, patch, lint result and successful initial probes/profile remain separately identified. The final form uses `&text.as_bytes()[..end]`; final profile and validation were rerun after rebuilding.

## Profile and timing

Exact final Callgrind comparisons against `a9bb484b` reduce XML_Parse instruction counts by 2.61% on Wayland and 2.09% on Maven namespace mode. Constructor/free/IO are excluded; one warmup and one measured parse, including callbacks, are both collected. These are instruction counts, not elapsed-time results.

Native timing retains 32 conditions: six pinned projects plus long-line control in both namespace modes and 4 KiB/64 KiB chunks, followed by generated entities and rare declarations with no namespaces in both chunk sizes. Seven randomized paired process cohorts yield 448 native processes and 96 complete reference preflight streams. Every measured sample matches independent callback hash and element/text counts.

Ratios are candidate seconds divided by scalar seconds; below 1 is faster. Maven namespace cases are about 5% faster, GTK and DocBook mostly improve, long lines improve 5–7%, and generated entities improve 4–6%. Wayland is near neutral in elapsed time despite the instruction reduction. All tradeoffs remain: Vulkan reaches 1.009, Batik namespace/4 KiB reaches 1.029, and rare declarations/4 KiB reaches 1.025. There is no blanket speedup claim. The shared host does not hold frequency/cache/bandwidth fixed; this parses XML rather than running whole project applications.

## Artifacts

`final/marker.patch`, `final/source.json`, and `final/source.tar.gz` identify the candidate. `phase-map.json` maps original and canonical forms. Full profiles, native observations, generators, validation logs and selected upstream assertions are retained. Local binary paths/hashes are recorded; binaries are excluded. Scripts retain their exact execution paths. Integration, broader combined-base validation and acceptance are root-owned followups.
