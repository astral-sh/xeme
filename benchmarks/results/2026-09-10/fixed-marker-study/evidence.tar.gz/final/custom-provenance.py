from pathlib import Path
import gzip,hashlib,itertools,json,sys
out=Path('/tmp/oriole-forbidden-marker-evidence/final')
# Reuse the frozen custom converter and complete declaration/value fixtures.
original=Path('/tmp/oriole-custom-final/probes/external-compare.py').read_text()
setup=original[:original.index('rows=[];count=0')].replace("Path('/tmp/oriole-custom-alias-external-source.py').write_text(source)","(out/'custom-external-source.py').write_text(source)")
exec(compile(setup,'frozen-custom-fixtures','exec'))
paths={'reference':reference,'baseline':'/tmp/oriole-forbidden-marker-evidence/final/control.so','candidate':'/tmp/oriole-forbidden-marker-evidence/final/liboriole_expat.so'}
rows=[];count=0;changed=0;outcomes=0;successful=0
for lead in [128,36]:
 code=source.replace('map[128]=-2',f'map[{lead}]=-2');engines={}
 for name,path in paths.items():
  env={};exec(compile(code.replace(reference,path),name,'exec'),env);engines[name]=env
 for (case,(document,resources)),scalar,width,default in itertools.product(cases.items(),[9,10,13,*range(32,127)],[0,1,7],[False,True]):
  data=document.replace(b'@@',bytes([lead,scalar]));loaded={n:v.replace(b'@@',bytes([lead,scalar])) for n,v in resources.items()}
  values={name:e['parse'](data,width,default,loaded) for name,e in engines.items()};a,b,d=values.values();count+=1
  different=b!=d;changed+=different;outcome=(a['status'],a['error'])!=(d['status'],d['error']);outcomes+=outcome;event=a['status']==d['status']==1 and a['events']!=d['events'];successful+=event
  if a!=d or different:rows.append({'case':case,'scalar':scalar,'lead':lead,'width':width,'default':default,'results':values})
report={'cases':count,'changed_from_baseline':changed,'reference_outcome_differences':outcomes,'reference_successful_event_differences':successful,'libraries':{n:{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for n,p in paths.items()},'templates':{key:{'document':doc.hex(),'resources':{n:v.hex() for n,v in res.items()}} for key,(doc,res) in cases.items()},'differences':rows}
(out/'custom-provenance.json.gz').write_bytes(gzip.compress(json.dumps(report,indent=2).encode(),mtime=0));print({k:v for k,v in report.items() if k not in ['templates','differences']});assert changed==0
