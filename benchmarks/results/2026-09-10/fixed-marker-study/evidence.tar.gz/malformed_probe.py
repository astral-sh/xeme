import sys,json,hashlib,itertools
from pathlib import Path
sys.path.insert(0,'/home/dev-user/code/oss/oriole/tools')
from xml_abi import Expat
root=Path('/tmp/oriole-forbidden-marker-evidence');a=Expat(str(root/'control.so'));b=Expat(str(root/'liboriole_expat.so'));rows=[];differences=[]
cases=[]
for prefix,tail in itertools.product(['','a','a\n','a\r','a\r\n','\n\n','\r\r','\ré\n'],['bad]]>','bad]]>\x01','\x01]]>',']\n]>','a\x01',']]','a\r\nb',']]><n/>']):
 for internal in [False,True]:
  xml=f"<!DOCTYPE r [<!ENTITY e '{prefix}{tail}'>]><r>&e;</r>" if internal else f'<r>{prefix}{tail}</r>'
  cases.append((xml,[1,2,3,7,64,4096,len(xml.encode())]))
for size,newline,tail in itertools.product([65532,65535,65536,65537,70000],['\n','\r','\r\n'],[']]>','\x01]]>','bad]]>\x01','ok']):
 cases.append((f'<r>a\n'+('x'*(size-2))+newline+tail+'</r>',[65533,65535,65536,65537,200000]))
for xml,chunks in cases:
 for encoding in ['utf-8','utf-16']:
  data=xml.encode(encoding)
  for chunk in sorted(set(chunks)):
   x=a.parse(data,chunk);y=b.parse(data,chunk)
   fields=[f for f in ['status','error','position','normalized_events','callback_errors'] if x[f]!=y[f]]
   if fields: differences.append({'sha256':hashlib.sha256(data).hexdigest(),'encoding':encoding,'chunk':chunk,'fields':fields,'control':x,'candidate':y})
   rows.append({'sha256':hashlib.sha256(data).hexdigest(),'encoding':encoding,'chunk':chunk,'control_status':x['status'],'error':x['error'],'fields':fields})
report={'cases':len(rows),'differences':differences,'rows':rows};(root/'malformed-probe.json').write_text(json.dumps(report,indent=2)+'\n');print(len(rows),'comparisons;',len(differences),'differences');assert not differences
