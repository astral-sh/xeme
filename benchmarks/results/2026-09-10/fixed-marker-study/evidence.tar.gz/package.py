from pathlib import Path
import gzip,hashlib,json,shutil,tarfile
root=Path('/tmp/oriole-forbidden-marker-evidence');final=root/'final';out=Path('/tmp/oriole-forbidden-marker-handoff');out.mkdir(exist_ok=True);source=Path('/tmp/oriole-forbidden-marker');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,name):
 dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
def packed(p,name):
 dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in root.rglob('*'):
 if not p.is_file() or p.suffix in ['.so','.a','.pyc'] or p.name=='runtests':continue
 name=str(p.relative_to(root))
 if p.suffix in ['.out','.log','.txt','.stdout','.json'] and p.stat().st_size>50000:packed(p,name+'.gz')
 else:copy(p,name)
m=json.loads((final/'source.json').read_text());assert all(sha(source/name)==h for name,h in m['files'].items())
with tarfile.open(out/'final/source.tar.gz','w:gz') as archive:
 for name in m['files']:archive.add(source/name,arcname=name)
copy(Path('/tmp/oriole-shared-dtd-tiny-profile/source.json'),'parent-source.json')
for name in ['results.json','manifest.json']:packed(Path('/tmp/oriole-shared-dtd-implementation/upstream-api')/name,'parent-upstream-'+name+'.gz')
for p in [Path('/home/dev-user/code/oss/oriole/tools/xml_abi.py'),Path('/home/dev-user/code/oss/oriole/benchmarks/projects.py'),Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c'),Path('/tmp/oriole-shared-dtd-implementation/run_clean.py'),Path('/tmp/oriole-custom-final/probes/external-compare.py'),Path('/tmp/oriole-custom-alias-external-source.py')]:copy(p,'helpers/'+p.name)
for p in Path('/tmp/oriole-shared-dtd-implementation/upstream-runner').iterdir():
 if p.is_file():copy(p,'upstream-runner/'+p.name)
for phase in [root,final]:
 report=json.loads((phase/'profile.json').read_text());assert report['status']=='passed'
for study in ['screen','controls-screen']:
 d=json.loads((final/study/'report.json').read_text());assert d['status']=='passed'
 for p,h in d['hashes'].items():assert sha(Path(p))==h
 for p in d['hashes']:
  src=Path(p)
  if src.suffix in ['.xml','.svg','.ui','.xsl']:copy(src,'inputs/'+src.name)
upstream=json.loads((final/'upstream-api/results.json').read_text());parent=json.loads(Path('/tmp/oriole-shared-dtd-implementation/upstream-api/results.json').read_text());assert upstream['results']==parent['results'] and len(upstream['results'])==4740
profile=json.loads((final/'profile.json').read_text());screens=[json.loads((final/study/'report.json').read_text()) for study in ['screen','controls-screen']]
summary={'status':'candidate handed off for combined-base acceptance','change':'Replace the general UTF8 string marker search with memchr::memmem::find on the same byte slice and constant ASCII needle. First marker byte offset and all parser validation/callback state remain unchanged.','final_library_sha256':sha(final/'liboriole_expat.so'),'initial_library_sha256':sha(root/'liboriole_expat.so'),'parent_library_sha256':sha(final/'control.so'),'source_manifest_sha256':sha(final/'source.json'),'patch_sha256':sha(final/'marker.patch'),'validation':{'allocation_tests':7,'clippy':'passed release core/FFI all-targets -D warnings','fmt':'passed','upstream_cases':4740,'upstream_passed':4077,'upstream_failed':663,'upstream_changed':0,'upstream_origin_verified':upstream['library_origin_verified'],'upstream_timed_out':upstream['timed_out'],'malformed_comparisons':2392,'malformed_changed':0,'suspension_raw_cases':32,'custom_provenance_cases':15288,'custom_provenance_changed':0},'profiles':{'collection':'XML_Parse instructions only, including callbacks; one warmup and one measured parse both collected. No native timing inference.','instruction_ratios':profile['ratios'],'rows':profile['rows']},'timing':{'ratio_definition':'candidate_seconds/scalar_seconds; below1 is faster','conditions':sum(len(d['preflights']) for d in screens),'complete_reference_preflight_streams':sum(len(d['preflights'])*3 for d in screens),'processes':sum(len(d['rows']) for d in screens),'paired_cohorts':7,'ratios':[r for d in screens for r in d['ratios']]},'limitations':['The initial expression triggered Clippy sliced_string_as_bytes. Initial source/patch/profile/probes remain separately attributed to72738f45; final canonical9233b675 was rebuilt and all named gates rerun.','No full core/FFI test suite or new sanitizer campaign is claimed for this one-expression optimization. The7 selected-allocation tests, full upstream public-API matrix and stated malformed/streaming/custom probes are the runtime gates.','All32 timing conditions are retained. Median regressions include BatikNS4KiB1.029 and rare declarations4KiB1.025; paired raw values are retained, with no blanket speedup claim. Root plans combined-base acceptance separately.','Shared-host frequency/cache/bandwidth are uncontrolled. Native timings include create, handler registration, parse, callback hashes and free; exclude IO/dlopen/startup/output. Pinned project XML parsing is not whole-project application execution. Batik external DTD loading is absent for all engines.']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'README.md').write_text('''# Constant forbidden-marker search candidate

The one-line patch replaces `str::find("]]>" )` with `memchr::memmem::find` on the same bytes and ASCII needle. The existing invalid-character check still precedes it; the first byte offset, malformed-prefix handling, raw/custom provenance, limits and callbacks are unchanged. `memchr` was already a pinned dependency. Root will assess this candidate on the selected combined baseline before accepting it.

## Validation

Final library `9233b675` passes all seven selected-allocation/OOM/lifetime tests, strict release core/FFI Clippy, formatting, 2,392 malformed comparisons, 32 suspension/DefaultCurrent/raw-context cases, and 15,288 custom-provenance comparisons. All 4,740 public upstream observations are exactly unchanged: 4,077 pass and 663 fail, with library origin verified and no timeout. Failed assertions remain in the evidence. No full core/FFI test suite or new sanitizer campaign is claimed here.

The initial form (`72738f45`) triggered the Clippy lint for slicing a string before `as_bytes`. Its source, patch, lint result and successful initial probes/profile remain separately identified. The final form uses `&text.as_bytes()[..end]`; final profile and validation were rerun after rebuilding.

## Profile and timing

Exact final Callgrind comparisons against `a9bb484b` reduce XML_Parse instruction counts by 2.61% on Wayland and 2.09% on Maven namespace mode. Constructor/free/IO are excluded; one warmup and one measured parse, including callbacks, are both collected. These are instruction counts, not elapsed-time results.

Native timing retains 32 conditions: six pinned projects plus long-line control in both namespace modes and 4 KiB/64 KiB chunks, followed by generated entities and rare declarations with no namespaces in both chunk sizes. Seven randomized paired process cohorts yield 448 native processes and 96 complete reference preflight streams. Every measured sample matches independent callback hash and element/text counts.

Ratios are candidate seconds divided by scalar seconds; below 1 is faster. Maven namespace cases are about 5% faster, GTK and DocBook mostly improve, long lines improve 5–7%, and generated entities improve 4–6%. Wayland is near neutral in elapsed time despite the instruction reduction. All tradeoffs remain: Vulkan reaches 1.009, Batik namespace/4 KiB reaches 1.029, and rare declarations/4 KiB reaches 1.025. There is no blanket speedup claim. The shared host does not hold frequency/cache/bandwidth fixed; this parses XML rather than running whole project applications.

## Artifacts

`final/marker.patch`, `final/source.json`, and `final/source.tar.gz` identify the candidate. `phase-map.json` maps original and canonical forms. Full profiles, native observations, generators, validation logs and selected upstream assertions are retained. Local binary paths/hashes are recorded; binaries are excluded. Scripts retain their exact execution paths. Integration, broader combined-base validation and acceptance are root-owned followups.
''')
artifacts={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-manifest.json'};assert not any((out/p).read_bytes().startswith((b'\x7fELF',b'!<arch>')) for p in artifacts)
(out/'artifact-manifest.json').write_text(json.dumps({'artifacts':artifacts},indent=2)+'\n');print(json.dumps({'path':str(out),'artifacts':len(artifacts),'bytes':sum(x['bytes'] for x in artifacts.values()),'summary_sha256':sha(out/'summary.json'),'manifest_sha256':sha(out/'artifact-manifest.json')},indent=2))
