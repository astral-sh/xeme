from pathlib import Path
import gzip,hashlib,json,os,random,statistics,subprocess,sys,time
root=Path('/tmp/oriole-forbidden-marker-evidence');out=root/'screen';out.mkdir();repo=Path('/home/dev-user/code/oss/oriole')
sys.path[:0]=[str(repo/'tools'),str(repo/'benchmarks')]
from xml_abi import Expat
from projects import native_output
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=repo/'benchmarks/projects/corpus-manifest.json';fixtures={p['name']:(manifest.parent/next(f['path'] for f in p['files'] if f['role']=='input')).resolve() for p in json.loads(manifest.read_text())['projects']}
for name in ['empty','attributes','text']:fixtures[name]=Path('/tmp/oriole-shared-dtd-implementation/benchmark/inputs')/(name+'.xml')
fixtures['long-lines']=root/'long-lines.xml';fixtures['long-lines'].write_text('<r>'+('x'*65535+'\r\n')*3+'</r>')
fixtures['declarations']=Path('/tmp/oriole-text-scanner/rare-declarations.xml')
libs={'scalar':root/'control.so','memmem':root/'liboriole_expat.so'};reference=Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so');driver=Path('/tmp/oriole-shared-dtd-implementation/benchmark/driver')
files=[Path(__file__),manifest,driver,reference,*fixtures.values(),*libs.values(),repo/'tools/xml_abi.py',repo/'benchmarks/projects.py',root/'source.json']
hashes={str(p):sha(p) for p in files};engines={name:Expat(str(lib)) for name,lib in {**libs,'reference':reference}.items()}
report={'status':'incomplete','cpu_affinity':sorted(os.sched_getaffinity(0)),'hashes':hashes,'method':'Seven randomized paired process cohorts; all normalized callbacks preflight against Expat and every timed sample matches independent hash/counts. Native create/handlers/parse/callback hash/free timings; file load/library load/startup/output excluded. Seven parses plus warmup per project/control process, 2000 plus warmup per tiny process. Shared host, no fixed frequency/cache/bandwidth.','preflights':[],'rows':[]};gold={}
conditions=[(name,chunk,ns) for name in fixtures for chunk in ([65536] if name in ['empty','attributes','text'] else [4096,65536]) for ns in [False,True]]
try:
 for name,chunk,ns in conditions:
  values={e:x.parse(fixtures[name].read_bytes(),chunk,ns) for e,x in engines.items()};ref=values['reference'];assert ref['status']==1 and ref['error']==0
  assert all(v['status']==1 and v['error']==0 and not v['callback_errors'] and v['normalized_events']==ref['normalized_events'] for v in values.values()),(name,chunk,ns)
  preflight=out/f'preflight-{name}-{chunk}-{ns}.json.gz';preflight.write_bytes(gzip.compress(json.dumps(values).encode(),mtime=0));gold[name,chunk,ns]=tuple(native_output(ref['normalized_events']));report['preflights'].append({'input':name,'chunk':chunk,'namespaces':ns,'expected':gold[name,chunk,ns],'output':preflight.name})
 rng=random.Random(20260911);jobs=[(*condition,pair) for condition in conditions for pair in range(7)];rng.shuffle(jobs)
 for name,chunk,ns,pair in jobs:
  order=list(libs);rng.shuffle(order)
  for label in order:
   cmd=[str(driver),str(libs[label]),str(fixtures[name]),str(chunk),str(2000 if name in ['empty','attributes','text'] else 7)]+(['namespaces'] if ns else [])
   filename=f'{name}-{chunk}-{ns}-{pair}-{label}.json.gz';started=time.monotonic()
   try:
    r=subprocess.run(cmd,capture_output=True,text=True,timeout=45)
    (out/filename).write_bytes(gzip.compress(r.stdout.encode(),mtime=0));(out/(filename+'.stderr')).write_text(r.stderr)
    row={'input':name,'chunk':chunk,'namespaces':ns,'pair':pair,'engine':label,'command':cmd,'returncode':r.returncode,'wall_seconds':time.monotonic()-started,'output':filename};report['rows'].append(row)
    assert r.returncode==0,(cmd,r.returncode,r.stderr);data=json.loads(r.stdout)
    assert all(tuple(s[k] for k in ['hash','elements','text_bytes'])==gold[name,chunk,ns] for s in data['samples'])
    row['seconds']=statistics.median(s['seconds'] for s in data['samples'] if not s['warmup'])
   except BaseException as e:
    report['failure']={'command':cmd,'exception':repr(e)};raise
 report['ratios']=[]
 for name,chunk,ns in conditions:
  pairs=[{r['engine']:r['seconds'] for r in report['rows'] if (r['input'],r['chunk'],r['namespaces'],r['pair'])==(name,chunk,ns,i)} for i in range(7)]
  row={'input':name,'chunk':chunk,'namespaces':ns,'candidate_over_scalar':statistics.median(p['memmem']/p['scalar'] for p in pairs)};report['ratios'].append(row);print(row,flush=True)
 assert all(sha(Path(p))==h for p,h in hashes.items());report['status']='passed'
finally:(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
