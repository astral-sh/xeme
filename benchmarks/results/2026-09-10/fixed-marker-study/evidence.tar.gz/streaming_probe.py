import ctypes as c, hashlib, json, sys
from pathlib import Path
sys.path.insert(0,'/home/dev-user/code/oss/oriole/tools')
from xml_abi import Expat,P,I,TEXT
root=Path('/tmp/oriole-forbidden-marker-evidence')
rows=[]
for label in ['control','liboriole_expat']:
 path=root/(label+'.so');lib=Expat(str(path)).lib
 for name,restype,args in [('XML_StopParser',I,[P,c.c_ubyte]),('XML_ResumeParser',I,[P]),('XML_DefaultCurrent',None,[P]),('XML_SetDefaultHandler',None,[P,TEXT]),('XML_GetCurrentByteCount',I,[P]),('XML_GetInputContext',P,[P,c.POINTER(I),c.POINTER(I)])]:
  fn=getattr(lib,name);fn.restype=restype;fn.argtypes=args
 for utf16 in [False,True]:
  for chunk in [1,2,3,7,1024,4096,65536,200000]:
   xml='<r>'+'a\r\nb\nc\rdé😀'*1200+'&amp;z\r\n</r>'
   data=xml.encode('utf-16') if utf16 else xml.encode()
   parser=lib.XML_ParserCreate(None);values=[];raw_values=[];errors=[];suspends=0;in_text=False;callback_labels=[]
   def default(_,value,length):
    if in_text: raw_values.append(c.string_at(value,length).decode())
   def text(_,value,length):
    global suspends,in_text
    try:
     value=c.string_at(value,length).decode();values.append(value)
     index=lib.XML_GetCurrentByteIndex(parser);count=lib.XML_GetCurrentByteCount(parser)
     offset=I();size=I();context=lib.XML_GetInputContext(parser,c.byref(offset),c.byref(size))
     assert context and 0<=offset.value<=size.value and count<=size.value-offset.value
     assert c.string_at(context+offset.value,count)==data[index:index+count]
     before=len(raw_values);in_text=True;lib.XML_DefaultCurrent(parser);in_text=False
     assert len(raw_values)==before+1
     raw=raw_values[-1];assert value==('&' if raw=='&amp;' else raw.replace('\r\n','\n').replace('\r','\n'))
     # Interrupt after every text event, exercising both single callbacks and
     # merged spans with retained input. The resume must not repeat any text.
     assert lib.XML_StopParser(parser,1)==1;suspends+=1
    except BaseException as e: errors.append(repr(e))
   def switched(_,value,length):
    callback_labels.append('switched');text(_,value,length)
   def initial(_,value,length):
    callback_labels.append('initial');lib.XML_SetCharacterDataHandler(parser,handlers[2]);text(_,value,length)
   handlers=[TEXT(default),TEXT(initial),TEXT(switched)];lib.XML_SetDefaultHandler(parser,handlers[0]);lib.XML_SetCharacterDataHandler(parser,handlers[1])
   try:
    for start in range(0,len(data),chunk):
     segment=data[start:start+chunk];status=lib.XML_Parse(parser,segment,len(segment),int(start+chunk>=len(data)))
     while status==2: status=lib.XML_ResumeParser(parser)
     assert status==1,(status,lib.XML_GetErrorCode(parser),errors)
    assert not errors,errors
    assert callback_labels==['initial']+['switched']*(len(values)-1)
    assert ''.join(values)==('a\nb\nc\ndé😀'*1200+'&z\n')
    rows.append({'library':label,'utf16':utf16,'chunk':chunk,'suspends':suspends,'handler_switched_after_first_event':True,'text_bytes':len(''.join(values).encode()),'raw_sha256':hashlib.sha256(''.join(raw_values).encode()).hexdigest()})
   finally: lib.XML_ParserFree(parser)
report={'status':'passed','scope':'Every text callback suspends and calls DefaultCurrent; current raw input byte ranges are checked in callback; resumed concatenation must equal expected normalized data. UTF8/UTF16, eight chunk sizes.','rows':rows}
(root/'streaming-probe.json').write_text(json.dumps(report,indent=2)+'\n');print('passed',len(rows))
