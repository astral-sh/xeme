from pathlib import Path
import gzip,hashlib,json,subprocess,time
root=Path('/tmp/oriole-forbidden-marker-evidence');py='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12';commands=[]
for name in ['malformed_probe.py','streaming_probe.py']:
 source=Path('/tmp/oriole-text-scanner')/name
 (root/name).write_text(source.read_text().replace("root=Path('/tmp/oriole-text-scanner')",f"root=Path('{root}')"))
p=Path('/tmp/oriole-shared-dtd-tiny-profile/validation/custom-provenance.py');s=p.read_text().replace("out=Path('/tmp/oriole-shared-dtd-tiny-profile/validation')",f"out=Path('{root}')").replace("'/tmp/oriole-shared-dtd-implementation/liboriole_expat.so'",f"'{root/'control.so'}'").replace("'/tmp/oriole-shared-dtd-tiny-profile/split.so'",f"'{root/'liboriole_expat.so'}'");(root/'custom-provenance.py').write_text(s)
for name in ['malformed_probe','streaming_probe','custom-provenance']:
 cmd=['taskset','-c','5',py,'-I','-S','/tmp/oriole-shared-dtd-implementation/run_clean.py',str(root/(name+'.py'))];start=time.time()
 with (root/(name+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 commands.append({'command':cmd,'returncode':r.returncode,'seconds':time.time()-start});(root/'validation-commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert r.returncode==0
print('all bounded malformed, suspension/raw, and custom provenance probes passed')
