from pathlib import Path
import json,hashlib
from collections import Counter
source=Path('/tmp/oriole-perf-composed/aliases/probe.py').read_text().split("if __name__=='__main__':")[0]
extra_types='''
COMMENT=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p)
DOCTYPE=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_int)
NOTATION=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p)
ATTLIST=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_int)
DECL=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_char_p,c.c_int)
for name,kind in [('XML_SetCommentHandler',COMMENT),('XML_SetStartDoctypeDeclHandler',DOCTYPE),('XML_SetNotationDeclHandler',NOTATION),('XML_SetAttlistDeclHandler',ATTLIST),('XML_SetXmlDeclHandler',DECL)]:
 getattr(lib,name).argtypes=[c.c_void_p,kind]
def decoded(value):return value.decode() if value is not None else None
'''
source=source.replace('def parse(data, chunk=0, default=False):',extra_types+'\ndef parse(data, chunk=0, default=False):')
extra_callbacks='''
    @COMMENT
    def comment(_,text):events.append(['comment',decoded(text)])
    @DOCTYPE
    def doctype(_,name,system,public,subset):events.append(['doctype',decoded(name),decoded(system),decoded(public),subset])
    @NOTATION
    def notation(_,name,base,system,public):events.append(['notation',decoded(name),decoded(system),decoded(public)])
    @ATTLIST
    def attlist(_,element,name,kind,value,required):events.append(['attlist',decoded(element),decoded(name),decoded(kind),decoded(value),required])
    @DECL
    def declaration(_,version,encoding,standalone):events.append(['declaration',decoded(version),decoded(encoding),standalone])
'''
source=source.replace("    p=lib.XML_ParserCreate(b'alias');assert p", extra_callbacks+"\n    p=lib.XML_ParserCreate(b'alias');assert p")
source=source.replace('    lib.XML_SetElementHandler(p,start,end)', '''    lib.XML_SetCommentHandler(p,comment)
    lib.XML_SetStartDoctypeDeclHandler(p,doctype)
    lib.XML_SetNotationDeclHandler(p,notation)
    lib.XML_SetAttlistDeclHandler(p,attlist)
    lib.XML_SetXmlDeclHandler(p,declaration)
    lib.XML_SetElementHandler(p,start,end)''')
source=source.replace("events.append(['entity',name.decode(),parameter,c.string_at(value,length).decode() if value else None])", "events.append(['entity',name.decode(),parameter,c.string_at(value,length).decode() if value else None,decoded(system),decoded(public),decoded(notation)])")
Path('/tmp/oriole-perf-composed/aliases/full-events-source.py').write_text(source)
reference='/tmp/oriole-perf-composed/control.so';path='/tmp/oriole-perf-composed/liboriole_expat.so'
extra={
 'notation-name':b'<!DOCTYPE r [<!NOTATION a@@b SYSTEM "s">]><r/>',
 'notation-system':b'<!DOCTYPE r [<!NOTATION n SYSTEM "A@@B">]><r/>',
 'notation-public':b'<!DOCTYPE r [<!NOTATION n PUBLIC "A@@B">]><r/>',
 'entity-system':b'<!DOCTYPE r [<!ENTITY e SYSTEM "A@@B">]><r/>',
 'entity-public':b'<!DOCTYPE r [<!ENTITY e PUBLIC "A@@B" "s">]><r/>',
 'attlist-element':b'<!DOCTYPE r [<!ATTLIST a@@b a CDATA "v">]><r/>',
 'attlist-name':b'<!DOCTYPE r [<!ATTLIST r a@@b CDATA "v">]><r/>',
 'attlist-enumeration':b'<!DOCTYPE r [<!ATTLIST r a (a@@b|c) "v">]><r/>',
 'attlist-notation':b'<!DOCTYPE r [<!ATTLIST r a NOTATION (a@@b|c) "v">]><r/>',
 'typed-space-prefix':b'<!DOCTYPE r [<!ATTLIST r a NMTOKENS #IMPLIED>]><r a=" @@A"/>',
 'typed-space-suffix':b'<!DOCTYPE r [<!ATTLIST r a NMTOKENS #IMPLIED>]><r a="A@@ "/>',
 'typed-space-middle':b'<!DOCTYPE r [<!ATTLIST r a NMTOKENS #IMPLIED>]><r a=" A@@ B "/>',
 'typed-alias-middle':b'<!DOCTYPE r [<!ATTLIST r a NMTOKENS #IMPLIED>]><r a=" A @@B "/>',
 'typed-alias-only':b'<!DOCTYPE r [<!ATTLIST r a NMTOKENS #IMPLIED>]><r a="@@@@"/>',
 'typed-default-spaces':b'<!DOCTYPE r [<!ATTLIST r a NMTOKENS "A @@B">]><r/>',
 'xml-version-middle':b'<?xml version="1.@@0"?><r/>',
 'xml-encoding-value':b'<?xml version="1.0" encoding="@@lias"?><r/>',
 'xml-standalone-value':b'<?xml version="1.0" standalone="@@es"?><r/>',
}
rows=[];count=0
for lead in [128,36,64]:
 code=source.replace('map[128]=-2',f'map[{lead}]=-2')
 old={};exec(compile(code,'reference','exec'),old)
 new={};exec(compile(code.replace(reference,path),'candidate','exec'),new)
 for case,template in (old['CASES']|extra).items():
  for scalar in [9,10,13,*range(32,127)]:
   data=template.replace(b'@@',bytes([lead,scalar]))
   for chunk in [0,1]:
    count+=1;a=old['parse'](data,chunk,False);b=new['parse'](data,chunk,False)
    if a!=b:rows.append({'case':case,'scalar':scalar,'lead':lead,'chunk':chunk,'reference':a,'candidate':b})
report={'library':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'cases':count,'differences':rows}
Path('/tmp/oriole-perf-composed/aliases/full-events-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print('cases',count)
print('acceptance',Counter((x['case'],x['scalar']) for x in rows if x['reference']['status']!=x['candidate']['status']))
print('accepted callbacks',Counter((x['case'],x['scalar']) for x in rows if x['reference']['status']==x['candidate']['status']==1 and x['reference']['events']!=x['candidate']['events']))
print('all',len(rows))
