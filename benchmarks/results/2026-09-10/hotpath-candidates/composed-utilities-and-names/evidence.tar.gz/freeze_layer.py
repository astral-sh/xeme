import pathlib,tarfile,difflib,sys,hashlib,json
r=pathlib.Path('/tmp/oriole-utf8-feed');p=pathlib.Path('/tmp/oriole-perf-composed');layer=sys.argv[1];prev=sys.argv[2]
with tarfile.open(p/prev) as t: before={x.name:t.extractfile(x).read() for x in t.getmembers() if x.isfile()}
after={str(f.relative_to(r)):f.read_bytes() for prefix in ['crates','include','tests'] for f in (r/prefix).rglob('*') if f.is_file()}
for name in ['Cargo.toml','Cargo.lock']:after[name]=(r/name).read_bytes()
patch=[]
for name in sorted(before.keys()|after.keys()):
 if before.get(name)!=after.get(name):
  patch.extend(difflib.unified_diff(before.get(name,b'').decode().splitlines(True),after.get(name,b'').decode().splitlines(True),fromfile='a/'+name if name in before else '/dev/null',tofile='b/'+name if name in after else '/dev/null'))
(p/f'{layer}.patch').write_text(''.join(patch))
with tarfile.open(p/f'{layer}-source.tar.gz','w:gz') as t:
 for name in ['Cargo.toml','Cargo.lock','crates','include','tests']:t.add(r/name,arcname=name)
print(layer,hashlib.sha256((p/f'{layer}.patch').read_bytes()).hexdigest())
