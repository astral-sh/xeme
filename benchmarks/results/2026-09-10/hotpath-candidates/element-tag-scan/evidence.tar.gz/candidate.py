import pathlib,tarfile,sys,difflib
p=pathlib.Path(__file__).parent;r=pathlib.Path('/tmp/oriole-utf8-feed');cutoff=int(sys.argv[1]);name='crates/oriole/src/encoding.rs'
with tarfile.open(p/'original-scanner-source.tar.gz') as t:s=t.extractfile(name).read().decode()
start=s.index('fn scan_element_tag(');i=s.index('    while index < bytes.len() {',start)
prefix='''    // Short tags avoid setting up a byte search. Resume the bulk scan only
    // after this fixed prefix, including when a tag spans input chunks.
    while index < bytes.len().min(CUTOFF) {
        let byte = bytes[index];
        if byte == b'<' {
            return Err((ErrorKind::InvalidToken, index));
        }
        if index >= limit {
            return Err((ErrorKind::LimitExceeded, limit));
        }
        if scan.quote != 0 {
            if byte == scan.quote {
                scan.quote = 0;
            }
        } else if byte == b'>' {
            return Ok(Some(index + 1));
        } else if matches!(byte, b'\\\'' | b'"') {
            scan.quote = byte;
        }
        index += 1;
    }
'''.replace('CUTOFF',str(cutoff))
s=s[:i]+prefix+s[i:];(r/name).write_text(s)
# Archive the actual candidate helper and independent reference loop together.
end=s.index('\n///',start)
probe='use oriole::ErrorKind;\n#[derive(Default,Debug,PartialEq)] struct Scan { checked: usize, quote: u8 }\n'+s[start:end]+'\n'+pathlib.Path('/tmp/oriole-element-scanner/probe_tail.rs').read_text().replace('[31,32,127,128,4095,4096,65535]','[31,32,33,63,64,65,127,128,4095,4096,65535]')
examples=r/'crates/oriole/examples';examples.mkdir(exist_ok=True);(examples/'scan_element_probe.rs').write_text(probe);(p/f'prefix{cutoff}-probe.rs').write_text(probe)
