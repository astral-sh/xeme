import pathlib,tarfile,difflib,sys,hashlib,json
p=pathlib.Path(__file__).parent;r=pathlib.Path('/tmp/oriole-utf8-feed');label=sys.argv[1];name='crates/oriole/src/encoding.rs'
(p/f'{label}.so').write_bytes(pathlib.Path('/home/dev-user/.cache/oriole/utf8-feed-target/release/liboriole_expat.so').read_bytes())
with tarfile.open(p/'baseline-source.tar.gz') as t:b=t.extractfile(name).read().decode()
with tarfile.open(p/'original-scanner-source.tar.gz') as t:o=t.extractfile(name).read().decode()
a=(r/name).read_text()
for suffix,before in [('',b),('-versus-original',o)]:
 (p/f'{label}{suffix}.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),a.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
with tarfile.open(p/f'{label}-source.tar.gz','w:gz') as t:
 for name in ['Cargo.toml','Cargo.lock','crates','include','tests']:t.add(r/name,arcname=name)
print(label,hashlib.sha256((p/f'{label}.so').read_bytes()).hexdigest())
