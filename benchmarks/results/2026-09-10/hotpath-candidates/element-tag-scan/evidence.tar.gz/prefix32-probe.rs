use oriole::ErrorKind;
#[derive(Default,Debug,PartialEq)] struct Scan { checked: usize, quote: u8 }
fn scan_element_tag(
    bytes: &[u8],
    scan: &mut Scan,
    limit: usize,
) -> Result<Option<usize>, (ErrorKind, usize)> {
    let mut index = scan.checked;
    if index == 0 {
        if limit == 0 {
            return Err((ErrorKind::LimitExceeded, 0));
        }
        // The opening '<' is the only one permitted in an element tag.
        index = 1;
    }
    // Short tags avoid setting up a byte search. Resume the bulk scan only
    // after this fixed prefix, including when a tag spans input chunks.
    while index < bytes.len().min(32) {
        let byte = bytes[index];
        if byte == b'<' {
            return Err((ErrorKind::InvalidToken, index));
        }
        if index >= limit {
            return Err((ErrorKind::LimitExceeded, limit));
        }
        if scan.quote != 0 {
            if byte == scan.quote {
                scan.quote = 0;
            }
        } else if byte == b'>' {
            return Ok(Some(index + 1));
        } else if matches!(byte, b'\'' | b'"') {
            scan.quote = byte;
        }
        index += 1;
    }
    while index < bytes.len() {
        if bytes[index] == b'<' {
            return Err((ErrorKind::InvalidToken, index));
        }
        if index >= limit {
            return Err((ErrorKind::LimitExceeded, limit));
        }
        // Inspect the byte at the limit: a literal '<' there takes precedence
        // over the limit error. No search needs to read farther than that byte.
        let end = bytes.len().min(limit.saturating_add(1));
        let text = &bytes[index..end];
        let next = if scan.quote != 0 {
            memchr::memchr2(scan.quote, b'<', text)
        } else {
            let syntax = memchr::memchr3(b'>', b'\'', b'"', text);
            memchr::memchr(b'<', &text[..syntax.unwrap_or(text.len())]).or(syntax)
        };
        let Some(next) = next else {
            if end > limit {
                return Err((ErrorKind::LimitExceeded, limit));
            }
            index = end;
            break;
        };
        index += next;
        if bytes[index] == b'<' {
            return Err((ErrorKind::InvalidToken, index));
        }
        if index >= limit {
            return Err((ErrorKind::LimitExceeded, limit));
        }
        if scan.quote != 0 {
            scan.quote = 0;
        } else if bytes[index] == b'>' {
            return Ok(Some(index + 1));
        } else {
            scan.quote = bytes[index];
        }
        index += 1;
    }
    scan.checked = index;
    if bytes.len() > limit {
        Err((ErrorKind::LimitExceeded, limit))
    } else {
        Ok(None)
    }
}

fn original(bytes: &[u8], scan: &mut Scan, limit: usize) -> Result<Option<usize>,(ErrorKind,usize)> {
 let mut index=scan.checked;
 while index<bytes.len() {
  if index!=0 && bytes[index]==b'<' {return Err((ErrorKind::InvalidToken,index));}
  if index>=limit {return Err((ErrorKind::LimitExceeded,limit));}
  if scan.quote!=0 {
   if bytes[index]==scan.quote {scan.quote=0;}
  } else {match bytes[index] {
   b'\''|b'"'=>scan.quote=bytes[index],
   b'>'=>return Ok(Some(index+1)),
   _=>{}
  }}
  index+=1;
 }
 scan.checked=index;
 if bytes.len()>limit {Err((ErrorKind::LimitExceeded,limit))} else {Ok(None)}
}
fn compare(input: &[u8],width: usize,limit:usize,count:&mut usize) {
 let mut old=Scan::default();let mut new=Scan::default();
 for end in (width..input.len()+width).step_by(width) {
  let bytes=&input[..end.min(input.len())];
  let a=original(bytes,&mut old,limit);let b=scan_element_tag(bytes,&mut new,limit);
  assert_eq!((a,&old),(b,&new),"input {input:?} width {width} limit {limit} prefix {}",bytes.len());
  *count+=1;
  if !matches!(a,Ok(None)){break;}
 }
}
fn main() {
 let alphabet=[b'<',b'>',b'\'',b'"',b'a',b'/',b'!',128];let mut count=0;
 for length in 0..=6 {
  for number in 0usize..8usize.pow(length) {
   let mut input=vec![b'<'];let mut number=number;
   for _ in 0..length {input.push(alphabet[number%8]);number/=8;}
   if matches!(input.get(1),Some(b'/'|b'!')) {continue;}
   for limit in 0..=input.len()+1 {for width in [1,2,3,input.len()] {compare(&input,width,limit,&mut count);}}
  }
 }
 for size in [31,32,33,63,64,65,127,128,4095,4096,65535] {
  for quoted in [false,true] {for tail in ["\"/>","<",">", "' end", "é😀\" >"] {
   let text=format!("<r {}{}{tail}",if quoted {"a=\""} else {""},"x".repeat(size));
   for limit in [0,1,2,3,size-1,size,size+1,text.len()-1,text.len(),usize::MAX] {
    for width in [1,3,4096,text.len()] {compare(text.as_bytes(),width,limit,&mut count);}
   }
  }}
 }
 println!("{count} exact incremental state/result comparisons passed");
}
