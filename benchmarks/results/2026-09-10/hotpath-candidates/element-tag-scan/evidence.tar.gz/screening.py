import hashlib,json,random,statistics,subprocess
from pathlib import Path
root=Path('/tmp/oriole-element-prefix');repo=Path('/home/dev-user/code/oss/oriole');manifest=repo/'benchmarks/projects/corpus-manifest.json'
fixtures={p['name']:(manifest.parent/next(f['path'] for f in p['files'] if f['role']=='input')).resolve() for p in json.loads(manifest.read_text())['projects']}
rare=root/'rare-declarations.xml';rare.write_text('<!DOCTYPE r [\n'+''.join(f'<!ENTITY e{i} "v"><!ATTLIST r a{i} CDATA #IMPLIED><!NOTATION n{i} SYSTEM "x">\n' for i in range(2000))+']><r/>');fixtures['generated-rare-declarations']=rare;fixtures['generated-entities']=Path('/tmp/oriole-grammar-bench-plain/entities.xml')
libraries={label:root/f'{label}.so' for label in ['control','original-scanner','prefix32','prefix64']};driver=Path('/tmp/oriole-grammar-bench-plain/native-driver');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'scope':'Four-way screening versus utility/name/raw-length parent over all six pinned projects, both namespace modes and two generated adverse fixtures. CPU0 shared host; five randomized pairs, seven measured parses plus warmup per subprocess. Native callback-driver throughput, not application wall time.','pairs':5,'iterations':7,'rows':[],'hashes_before':{str(p):sha(p) for p in [manifest,driver,*fixtures.values(),*libraries.values()]}};rng=random.Random(20260910)
for chunk in [4096,65536]:
 for name,fixture,ns in [(n,p,False) for n,p in fixtures.items()]+[(n,p,True) for n,p in fixtures.items() if not n.startswith('generated-')]:
  ratios={label:[] for label in libraries if label!='control'}
  for pair in range(report['pairs']):
   order=list(libraries);rng.shuffle(order);row={'workload':name,'chunk':chunk,'namespaces':ns,'pair':pair,'order':order,'processes':{}}
   for label in order:
    cmd=['taskset','-c','0',str(driver),str(libraries[label]),str(fixture),str(chunk),str(report['iterations'])]+(['namespaces'] if ns else [])
    r=subprocess.run(cmd,capture_output=True,text=True,timeout=45);process={'command':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr};row['processes'][label]=process;assert r.returncode==0,process;samples=json.loads(r.stdout)['samples'];process['median_seconds']=statistics.median(s['seconds'] for s in samples if not s['warmup']);process['observations']=list({(s['hash'],s['elements'],s['text_bytes']) for s in samples})
   ref=row['processes']['control'];row['speedups']={}
   for label in ratios:
    candidate=row['processes'][label];assert ref['observations']==candidate['observations'],row;ratio=ref['median_seconds']/candidate['median_seconds'];row['speedups'][label]=ratio;ratios[label].append(ratio)
   report['rows'].append(row);(root/'screening.json').write_text(json.dumps(report,indent=2)+'\n')
  print(chunk,name,ns,{label:statistics.median(values) for label,values in ratios.items()},flush=True)
report['hashes_after']={p:sha(Path(p)) for p in report['hashes_before']};assert report['hashes_before']==report['hashes_after'];report['status']='passed';(root/'screening.json').write_text(json.dumps(report,indent=2)+'\n')
