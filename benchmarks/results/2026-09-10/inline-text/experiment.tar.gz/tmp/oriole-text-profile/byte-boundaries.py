from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,'/tmp/oriole-capi-profile')
from xml_abi import Expat

root=Path('/tmp/oriole-text-profile')
old=Expat('/tmp/oriole-capi-profile/liboriole_expat-spare.so')
new=Expat(str(root/'liboriole_expat.so'))
rows=[]
for length in [0,1,21,22,23,24,25,46,47,48,127]:
 for unit in ['x','é','中','😀','\r\n','\r']:
  text=unit*length
  for wrapper in ['literal','cdata','references']:
   if wrapper=='cdata': body='<![CDATA['+text+']]>'
   elif wrapper=='references': body=''.join(f'&#x{ord(c):x};' for c in text)
   else: body=text
   xml=('<r>'+body+'</r>').encode()
   for chunk in [1,7,4096]:
    before=old.parse(xml,chunk);after=new.parse(xml,chunk)
    assert before==after,(length,unit,wrapper,chunk,before,after)
    rows.append({'length':length,'unit':unit,'wrapper':wrapper,'chunk':chunk,'xml_hex':xml.hex(),'result':after})
report={'cases':len(rows),'exact_results_match':True,'rows':rows,'libraries':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path('/tmp/oriole-capi-profile/liboriole_expat-spare.so'),root/'liboriole_expat.so']}}
(root/'byte-boundaries.json').write_text(json.dumps(report,ensure_ascii=True,indent=2)+'\n')
print(len(rows),'exact status/error/callback/location matches')
