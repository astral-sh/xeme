"""Seven paired canonical workload runs with full normalized-callback preflight."""
from pathlib import Path
import hashlib,json,random,statistics,subprocess,sys,time
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
from corpus import workloads
from xml_abi import Expat
libraries={
 'original':Path('/tmp/oriole-final-encoding-checkpoint/liboriole_expat.so'),
 'spare':Path('/tmp/oriole-capi-profile/liboriole_expat-spare.so'),
 'text':Path('/tmp/oriole-text-profile/liboriole_expat.so'),
 'expat':Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so'),
}
engines={k:Expat(str(p)) for k,p in libraries.items()}
inputs=workloads(10000)
# The canonical text workload has newline callback boundaries. Add a single
# uninterrupted text token to measure the long heap-backed payload directly.
inputs['long-text']=b'<root>'+b'the quick brown fox jumps over the lazy dog '*10000+b'</root>'
chunks=[64,4096,1048576];rows=[];checks=[];rng=random.Random(20260910)
for name,data in inputs.items():
 (root/(name+'.xml')).write_bytes(data)
 namespaces=name=='namespaces'
 for chunk in chunks:
  expected=engines['expat'].parse(data,chunk,namespaces)
  assert expected['status']==1 and not expected['callback_errors']
  for variant,engine in engines.items():
   actual=engine.parse(data,chunk,namespaces)
   assert actual['status']==1 and not actual['callback_errors']
   assert actual['normalized_events']==expected['normalized_events'],(name,chunk,variant)
   checks.append({'workload':name,'chunk':chunk,'variant':variant,'normalized_events_sha256':hashlib.sha256(json.dumps(actual['normalized_events']).encode()).hexdigest()})
(root/'preflight.json').write_text(json.dumps(checks,indent=2)+'\n')
print('normalized preflight passed',len(checks),flush=True)
for pair in range(7):
 for workload in inputs:
  for chunk in chunks:
   variants=list(libraries);rng.shuffle(variants)
   for variant in variants:
    command=['taskset','-c','3','/tmp/oriole-capi-profile/native-driver',str(libraries[variant]),str(root/(workload+'.xml')),str(chunk),'10']
    if workload=='namespaces':command.append('namespaces')
    process=subprocess.run(command,text=True,capture_output=True,check=True,timeout=120)
    parsed=json.loads(process.stdout);samples=[x for x in parsed['samples'] if not x['warmup']]
    (root/f'{pair}-{workload}-{chunk}-{variant}.json').write_text(process.stdout)
    assert len({(x['hash'],x['elements'],x['text_bytes']) for x in samples})==1
    rows.append({'pair':pair,'workload':workload,'chunk':chunk,'variant':variant,'command':command,'seconds':statistics.median(x['seconds'] for x in samples),'hash':samples[0]['hash']})
 print('pair complete',pair+1,flush=True)
summary={}
for workload in inputs:
 for chunk in chunks:
  group=[x for x in rows if x['workload']==workload and x['chunk']==chunk]
  assert len({x['hash'] for x in group})==1
  item={'median_ms':{v:statistics.median(x['seconds'] for x in group if x['variant']==v)*1000 for v in libraries}}
  for baseline in ['original','spare','expat']:
   ratios=[next(x['seconds'] for x in group if x['variant']==baseline and x['pair']==p)/next(x['seconds'] for x in group if x['variant']=='text' and x['pair']==p) for p in range(7)]
   item['text_speedup_over_'+baseline]={'median':statistics.median(ratios),'pairs':ratios}
  summary[f'{workload}/{chunk}']=item
report={'summary':summary,'rows':rows,'source_manifest_sha256':hashlib.sha256((root.parent/'source.json').read_bytes()).hexdigest(),'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*libraries.values(),Path('/tmp/oriole-capi-profile/native-driver'),root/'run.py',root/'corpus.py',root/'xml_abi.py',*(root/(n+'.xml') for n in inputs)]},'limitations':['Shared host load/frequency uncontrolled.','Seven paired process medians, each one warmup and ten measured iterations,CPU3,seed20260910.','Namespace expansion enabled only for prefixed-namespace workload.','Original/spare sources718+spare; isolated text change source997. Future adoption requires combined consumer and differential gates.']}
(root/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print('completed',flush=True)
