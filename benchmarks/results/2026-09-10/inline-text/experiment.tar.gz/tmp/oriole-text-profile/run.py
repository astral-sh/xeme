from pathlib import Path
import hashlib,json,random,statistics,subprocess
root=Path('/tmp/oriole-text-profile');base=Path('/tmp/oriole-capi-profile')
libraries={'original':Path('/tmp/oriole-final-encoding-checkpoint/liboriole_expat.so'),'spare':base/'liboriole_expat-spare.so','inline':root/'liboriole_expat.so'}
rows=[];rng=random.Random(20260910)
for pair in range(3):
 for workload in ['elements','entities','empty-elements']:
  for chunk in [4096,1048576]:
   order=['original','spare','inline','safe-original','safe-inline'];rng.shuffle(order)
   for variant in order:
    if variant.startswith('safe'):
     driver=root/'safe-driver' if variant=='safe-inline' else base/'safe-driver'
     cmd=[str(driver),'system',str(base/(workload+'.xml')),str(chunk),'10']
    else:
     cmd=[str(base/'native-driver'),str(libraries[variant]),str(base/(workload+'.xml')),str(chunk),'10']
    cmd=['taskset','-c','3',*cmd]
    result=subprocess.run(cmd,capture_output=True,text=True,check=True,timeout=60)
    data=json.loads(result.stdout);samples=[x for x in data['samples'] if not x['warmup']]
    (root/f'{pair}-{workload}-{chunk}-{variant}.json').write_text(result.stdout)
    rows.append({'pair':pair,'workload':workload,'chunk':chunk,'variant':variant,'command':cmd,'seconds':statistics.median(x['seconds'] for x in samples),'hash':samples[0]['hash']})
summary={}
for workload in ['elements','entities','empty-elements']:
 for chunk in [4096,1048576]:
  subset=[x for x in rows if x['workload']==workload and x['chunk']==chunk]
  assert len({x['hash'] for x in subset})==1
  result={v:statistics.median(x['seconds'] for x in subset if x['variant']==v)*1000 for v in ['original','spare','inline','safe-original','safe-inline']}
  for label,a,b in [('inline_over_spare','spare','inline'),('inline_over_original','original','inline'),('safe_inline_over_original','safe-original','safe-inline')]:
   result[label]=statistics.median(next(x['seconds'] for x in subset if x['pair']==p and x['variant']==a)/next(x['seconds'] for x in subset if x['pair']==p and x['variant']==b) for p in range(3))
  summary[f'{workload}/{chunk}']=result
counts=[]
report={'summary':summary,'rows':rows,'counts':counts,'library_sha256':{k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in libraries.items()},'layouts':{'original':json.loads((base/'layout.json').read_text()),'inline':json.loads((root/'layout.json').read_text())}}
(root/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(summary,indent=2));print(json.dumps(counts,indent=2))
