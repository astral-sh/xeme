import ctypes as c,sys,json,hashlib,collections
from pathlib import Path
sys.path.insert(0,'/home/dev-user/code/oss/oriole/tools')
from xml_abi import Expat,P,I,START,END,TEXT
root=Path('/tmp/oriole-namespace-name-reuse')
library=Path(sys.argv[1]); label=sys.argv[2] if len(sys.argv)>2 else 'control'
lib=Expat(str(library)).lib
libc=c.CDLL(None)
libc.malloc.argtypes=[c.c_size_t];libc.malloc.restype=P
libc.realloc.argtypes=[P,c.c_size_t];libc.realloc.restype=P
libc.free.argtypes=[P];libc.free.restype=None
M=c.CFUNCTYPE(P,c.c_size_t);R=c.CFUNCTYPE(P,P,c.c_size_t);F=c.CFUNCTYPE(None,P)
class Suite(c.Structure):_fields_=[('malloc',M),('realloc',R),('free',F)]
lib.XML_ParserCreate_MM.argtypes=[c.c_char_p,c.POINTER(Suite),c.c_char_p];lib.XML_ParserCreate_MM.restype=P
manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
fixtures={p['name']:(manifest.parent/next(f['path'] for f in p['files'] if f['role']=='input')).read_bytes() for p in json.loads(manifest.read_text())['projects']}
for count in [10,100,1000]:fixtures[f'flat-{count}']=('<r>'+('<interface/>'*count)+'</r>').encode()
rows=[]
for name,data in fixtures.items():
 for callbacks in [False,True]:
  live={};counts=collections.Counter();sizes=collections.Counter();phase='create';observed=collections.Counter()
  def allocate(size):
   ptr=libc.malloc(size)
   if ptr:live[ptr]=size
   counts[phase+'_malloc']+=1;sizes[(phase,'malloc',size)]+=1
   return ptr
  def reallocate(ptr,size):
   result=libc.realloc(ptr,size)
   if result:
    live.pop(ptr,None);live[result]=size
   counts[phase+'_realloc']+=1;sizes[(phase,'realloc',size)]+=1
   return result
  def free(ptr):
   if ptr:
    assert ptr in live,ptr
    del live[ptr]
   libc.free(ptr);counts[phase+'_free']+=1
  memory=[M(allocate),R(reallocate),F(free)];suite=Suite(*memory)
  parser=lib.XML_ParserCreate_MM(None,c.byref(suite),b'|');assert parser
  previous_attributes=[0]
  def start(_,name,attrs):
   observed['starts']+=1
   if b'|' in name:observed['expanded_element_names']+=1
   count=0
   while attrs[2*count] is not None:count+=1
   if count:
    observed['nonempty_attribute_events']+=1
    observed['attribute_records_dropped_on_shrink']+=max(0,previous_attributes[0]-count)
    previous_attributes[0]=count
  def end(_,name):observed['ends']+=1
  def text(_,text,size):
   observed['text_bytes']+=size
   observed['text_callbacks']+=1
   if size>23:
    observed['heap_sized_text_callbacks']+=1
    observed['heap_sized_text_bytes']+=size
    if size<=4096:observed['cacheable_text_callbacks']+=1
    else:observed['oversized_text_callbacks']+=1
  handlers=[START(start),END(end),TEXT(text)]
  if callbacks:
   lib.XML_SetElementHandler(parser,*handlers[:2]);lib.XML_SetCharacterDataHandler(parser,handlers[2])
  phase='parse'
  for index in range(0,len(data),4096):
   segment=data[index:index+4096]
   result=lib.XML_Parse(parser,segment,len(segment),int(index+4096>=len(data)))
   assert result==1,(name,lib.XML_GetErrorCode(parser))
  retained=sum(live.values());phase='free';lib.XML_ParserFree(parser);assert not live
  row={'workload':name,'input_sha256':hashlib.sha256(data).hexdigest(),'input_bytes':len(data),'callbacks':callbacks,'counts':dict(counts),'observations':dict(observed),'retained_before_free_bytes':retained,'allocation_sizes':[{'phase':p,'operation':op,'size':size,'count':number} for (p,op,size),number in sorted(sizes.items())]};rows.append(row)
  print(name,callbacks,dict(counts),dict(observed),flush=True)
report={'scope':'Allocation counts only, not timings. XML_ParserCreate_MM callbacks forward to libc and count all allocation/reallocation/free operations; each parser has zero live allocations after free.','library':str(library),'library_sha256':hashlib.sha256(library.read_bytes()).hexdigest(),'chunk_size':4096,'rows':rows}
(root/(label+'-allocations.json')).write_text(json.dumps(report,indent=2)+'\n')
