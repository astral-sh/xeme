# Profile-guided optimization study

This is an experimental build study on the frozen ATTLIST source (`0546fcf5` normal library), with no parser source changes or adoption claim. PGO learns branch frequencies from generated input, then rebuilds the same source.

## Result

All 24 held-out native conditions improved within each engine. Oriole PGO/normal condition ratios were 0.73584–0.83078; Expat ratios were 0.81181–0.96268. Lower means less elapsed time. These are seven-cohort condition medians, not a pooled application speedup or confidence interval. `screen-summary.json` (or its compressed copy) retains all four-way ratios; `summary.json` includes the final scope.

The screen covers six original project XML files, both namespace modes, and 4 KiB/64 KiB feeds: 96 full callback preflights, 168 randomized cohorts, 672 processes, 136,976 measured parses and 672 warmups. Each process uses one warmup and fixed measured counts: Vulkan 7, Wayland 64, Maven 128, Batik 512, GTK and DocBook 256. It times construction, registration, parsing, native callback hashing and destruction. File loading, dlopen and process startup are excluded. Shared-host frequency, cache and memory bandwidth are uncontrolled. Batik's external DTD is not loaded. This is parser/consumer-driver timing, not full project execution.

Expat PGO was faster in 23 of the 24 cells. Oriole's single faster cell was Batik without namespaces at 4 KiB (ratio 0.98137). The fair comparison below is **Oriole PGO elapsed time / Expat PGO elapsed time**; each project geometrically averages its four namespace/chunk cells with equal weight. This is not workload-weighted application throughput.

| Project | PGO / PGO ratio |
| --- | ---: |
| Vulkan | 2.92464 |
| Wayland | 1.78448 |
| Maven | 3.31975 |
| Batik | 1.08120 |
| GTK | 3.21466 |
| DocBook | 2.18365 |
| Equal-weight geometric mean, 24 cells | 2.25503 |

`fair-pgo-comparison.json` retains every cell. Independent timing and fair-comparison audits verified every saved sample, paired median and geometric mean.

## Training and build identity

Twelve newly generated heterogeneous XML inputs (1,325,736 bytes) cover text, attributes, namespaces, nesting, comments/PIs/CDATA, internal DTD defaults/entities, line endings, UTF-16 and Latin-1. Both engines receive exactly the same 144 chunk/namespace/minimal-or-full-handler configurations, parsed twice. All six real project files are held out and no training was changed after observing held-out results. Training uses **Python ctypes callbacks**; only parser libraries are instrumented. The frozen input manifest originally says “native callbacks”; `training-launch-provenance.json` preserves the explicit correction without changing hashes. Native C callbacks are used for the held-out screen.

Normal, instrumented and optimized generated replays total 1,728 records and match within each engine. Expat callback streams are not asserted identical to Oriole for this full training-handler surface.

Oriole uses Ohm rustc 1.98.1-dev / LLVM 22.1.8, the existing release ThinLTO and one codegen unit, with `-Cprofile-generate` or `-Cprofile-use` plus missing-function diagnostics. Matching LLVM 22.1.8 profdata comes from the checksum-verified official Rust 1.98.0 tools archive. An initial nightly-tool attempt supplied LLVM 23 and was rejected; its acquisition/loader failure is retained.

Expat keeps the exact pinned 2.8.4 source, original GCC 13.3 compiler, `-O3 -DNDEBUG`, shared/no-LTO build and all existing CMake feature options. Its new normal library is bit-identical to the established reference. GCC's native PGO profile uses relative build-path mapping and no coverage-mismatch override. LLVM/GCC contexts differ across engines; within-engine comparisons control the compiler. Both optimized builds have no missing/mismatched-profile warnings.

A fresh normal Oriole build in the PGO workspace differs in binary identity from the original frozen library; the initial three-way instruction screen retains this context check. Maven and Batik counts are identical; Wayland differs by 536 instructions (0.0018%).

## Reproduction and limits

Scripts, exact commands, profiles, sources, tool/archive checksums, logs and observations are retained. Scripts preserve exact local paths; parameterize those paths before use as a portable build workflow. Binaries and downloaded LLVM tool libraries are identified by path/hash, not duplicated in this package. The six held-out input files are already in the repository; their complete pinned corpus manifest is included.

`source.tar.gz` and `expat-source.tar.gz` contain build sources; `generated-training-inputs.tar.gz` contains all generated input bytes; `training-profiles.tar.gz` contains the LLVM/GCC profiles; `timing-evidence.tar.gz` contains every preflight and timed output including stderr. The source/provenance/instruction, timing arithmetic and fair-comparison audits are independent and included. All 137,648 native samples (136,976 measured plus 672 warmups) were checked.

This study does not run the full upstream API, allocator-failure, native security, CPython or sanitizer gates on the new optimized binaries. Those gates are required before selecting a production build. Profiles are tied to this source/toolchain context and must be regenerated after relevant changes.

Method references: [rustc PGO](https://doc.rust-lang.org/rustc/profile-guided-optimization.html), [LLVM profdata](https://llvm.org/docs/CommandGuide/llvm-profdata.html), [GCC 13 instrumentation](https://gcc.gnu.org/onlinedocs/gcc-13.3.0/gcc/Instrumentation-Options.html).

`consumer-plan.md` prepares final-source four-way CPython and actual Wayland measurements. No final-source rebuild or further timing has run; profiles must be regenerated after the pending runtime corrections.
