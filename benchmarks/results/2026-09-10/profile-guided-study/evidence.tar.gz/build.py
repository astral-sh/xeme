from pathlib import Path
import os,subprocess,json,time,hashlib,shutil,sys
w=Path('/tmp/oriole-pgo-study');s=w/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((w/'source.json').read_text());label=sys.argv[1]
assert label in ['control','generate','use']
flags={'control':'','generate':'-Cprofile-generate='+str(w/'raw-profiles'),'use':'-Cprofile-use='+str(w/'merged.profdata')+' -Cllvm-args=-pgo-warn-missing-function'}[label]
settings={'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/pgo-'+label+'-target','CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'1','RUSTFLAGS':flags}
env=dict(os.environ,**settings);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
cmd=['taskset','-c','5','cargo','+ohm','build','--release','--locked','--offline','--target','x86_64-unknown-linux-gnu','-p','oriole_expat']
r={'status':'incomplete','command':cmd,'cwd':str(s),'environment':settings,'source_manifest_sha256':sha(w/'source.json'),'generate_profile_path':str(w/'raw-profiles'),'profile_use_sha256':sha(w/'merged.profdata') if label=='use' else None}
try:
 t=time.monotonic()
 with (w/(label+'-build.log')).open('w') as f:p=subprocess.run(cmd,cwd=s,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
 r.update(returncode=p.returncode,wall_seconds=time.monotonic()-t,log_sha256=sha(w/(label+'-build.log')));assert p.returncode==0
 for name,h in m['files'].items():assert sha(s/name)==h,name
 for name in ['liboriole_expat.so','liboriole_expat.a']:shutil.copy2(Path(settings['CARGO_TARGET_DIR'])/'x86_64-unknown-linux-gnu/release'/name,w/(label+'-'+name))
 r['library_sha256']=sha(w/(label+'-liboriole_expat.so'));r['archive_sha256']=sha(w/(label+'-liboriole_expat.a'));r['status']='passed'
finally:(w/(label+'-build.json')).write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r),flush=True)
