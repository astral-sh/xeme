from pathlib import Path
import os,subprocess,json,hashlib,shutil,sys,time,re
w=Path('/tmp/oriole-pgo-study');upstream=Path('/home/dev-user/.cache/oriole/upstream/expat-2.8.4/expat');source=w/'expat-source';label=sys.argv[1];assert label in ['control','generate','use'];build=w/('expat-'+label+'-build');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();baseline=Path('/home/dev-user/.cache/oriole/expat-build')
if not source.exists():shutil.copytree(upstream,source,ignore=shutil.ignore_patterns('.git','__pycache__'))
files={str(p.relative_to(source)):sha(p) for p in sorted(source.rglob('*')) if p.is_file()};assert all(sha(upstream/p)==h for p,h in files.items())
manifest=w/'expat-source.json'
if manifest.exists():assert json.loads(manifest.read_text())['files']==files
else:manifest.write_text(json.dumps({'upstream':str(upstream),'version':'2.8.4','files':files,'normal_build_cache_sha256':sha(baseline/'CMakeCache.txt'),'normal_library_sha256':sha(baseline/'libexpat.so')},indent=2)+'\n')
raw=w/'expat-raw-profiles';raw.mkdir(exist_ok=True);flags={'control':'','generate':f'-fprofile-generate={raw} -fprofile-prefix-path={build}','use':f'-fprofile-use={raw} -fprofile-prefix-path={build}'}[label]
cache=(baseline/'CMakeCache.txt').read_text();features={m[0]:m[1] for m in re.findall(r'^(EXPAT_[A-Z0-9_]+):(?:BOOL|STRING|UNINITIALIZED)=(.*)$',cache,re.M)}
cmd=['taskset','-c','5','cmake','-S',str(source),'-B',str(build),'-G','Unix Makefiles','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER=/usr/bin/cc','-DCMAKE_C_FLAGS='+flags,'-DCMAKE_C_FLAGS_RELEASE=-O3 -DNDEBUG',*[f'-D{k}={v}' for k,v in features.items()]]
commands=[('configure',cmd),('compile',['taskset','-c','5','cmake','--build',str(build),'--target','expat','--parallel','1','--verbose'])]
config={'CC':'/usr/bin/cc','CXX':'/usr/bin/c++'};env=dict(os.environ,**config)
for name in ['CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','GCOV_PREFIX','GCOV_PREFIX_STRIP']:env.pop(name,None)
tools=['/usr/bin/cc','/usr/bin/gcov-tool','/usr/bin/gcov-dump','/usr/bin/ld','/usr/bin/cmake',subprocess.check_output(['/usr/bin/cc','-print-prog-name=cc1'],text=True).strip()]
r={'status':'incomplete','source_manifest_sha256':sha(manifest),'label':label,'compiler':subprocess.check_output(['/usr/bin/cc','--version'],text=True),'compiler_target':subprocess.check_output(['/usr/bin/cc','-dumpmachine'],text=True).strip(),'tools_sha256':{str(Path(p).resolve()):sha(Path(p)) for p in tools},'flags':flags,'features':features,'environment_overrides':config,'cleared_environment':['CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','GCOV_PREFIX','GCOV_PREFIX_STRIP'],'commands':[],'method':'Keep pinned Expat2.8.4 normal GCC13.3 -O3/NDEBUG/shared/no-LTO feature context; GCC13 native instrumentation data, not LLVM profdata. Profiles use relative build paths via -fprofile-prefix-path. Compare within engine before cross-engine normal/PGO comparison.'}
try:
 for step,cmd in commands:
  log=w/('expat-'+label+'-'+step+'.log');t=time.monotonic()
  with log.open('w') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
  r['commands'].append({'command':cmd,'returncode':p.returncode,'log':str(log),'log_sha256':sha(log),'seconds':time.monotonic()-t});assert p.returncode==0
 library=build/'libexpat.so';shutil.copy2(library,w/('expat-'+label+'-liboriole_expat.so'))
 r['library_sha256']=sha(library);r['generated_config_sha256']=sha(build/'expat_config.h');r['normal_config_sha256']=sha(baseline/'expat_config.h');assert r['generated_config_sha256']==r['normal_config_sha256']
 assert all(sha(source/p)==h for p,h in files.items());r['status']='passed'
finally:(w/('expat-'+label+'-build.json')).write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'label':label,'status':r['status'],'library_sha256':r.get('library_sha256')}),flush=True)
