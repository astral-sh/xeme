from pathlib import Path
import hashlib,tarfile,json,subprocess,os
w=Path('/tmp/oriole-pgo-study');p=w/'llvm-tools-1.98.0.tar.xz';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=sha(p);expected=(w/'llvm-tools-1.98.0.sha256').read_text().split()[0];assert h==expected,(h,expected)
with tarfile.open(p) as t:
 members=[m for m in t if m.isfile() and ('/bin/llvm-profdata' in m.name or '/lib/libLLVM' in m.name)]
 for m in members:
  q=w/'llvm-tools-1.98.0'/('bin' if '/bin/' in m.name else 'lib')/Path(m.name).name;q.parent.mkdir(exist_ok=True,parents=True);q.write_bytes(t.extractfile(m).read());q.chmod(m.mode)
tool=w/'llvm-tools-1.98.0/bin/llvm-profdata';r=subprocess.run([str(tool),'--version'],capture_output=True,text=True);print(r.stdout,r.stderr)
record={'url':'https://static.rust-lang.org/dist/llvm-tools-1.98.0-x86_64-unknown-linux-gnu.tar.xz','checksum_url':'https://static.rust-lang.org/dist/llvm-tools-1.98.0-x86_64-unknown-linux-gnu.tar.xz.sha256','archive_sha256':h,'profdata_sha256':sha(tool),'version':r.stdout,'stderr':r.stderr,'returncode':r.returncode,'extracted':{str(p.relative_to(w)):sha(p) for p in sorted((w/'llvm-tools-1.98.0').rglob('*')) if p.is_file()},'initial_tool_attempt':'2026-09-09 nightly package supplied LLVM23 libraries instead of matchingLLVM22; not used for profile merge. Its flattened extraction failed loader resolution, retained in llvm-tools.json.'}
(w/'llvm-tools-matching.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0;assert '22.1.8' in r.stdout,r.stdout
