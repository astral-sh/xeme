from pathlib import Path
import json,hashlib,random
w=Path('/tmp/oriole-pgo-study');r=random.Random(0x4F52494F4C45);out=w/'inputs';out.mkdir(exist_ok=True);docs={}
docs['small']='<root>'+''.join(f'<item id="{i}" kind="k{i%7}">value {i}</item>' for i in range(1500))+'</root>'
docs['attributes']='<root>'+''.join('<item '+ ' '.join(f'a{j}="token-{r.randrange(10000)} and &#xE9; &amp; end"' for j in range(24))+'/>' for i in range(300))+'</root>'
docs['text']='<root>'+''.join('<section>'+('abcdefghijklmnopqrstuvwxyz é中😀 '*120)+'\r\n'+('long-line-'*1000)+'</section>' for i in range(16))+'</root>'
docs['mixed']='<root>'+''.join(f'<!-- note {i} --><?worker step="{i}"?><entry>one &lt; two &amp; three <![CDATA[raw <x> & data]]>\r\n<empty/></entry>' for i in range(800))+'</root>'
docs['namespaces']='<root xmlns="urn:generated:root" xmlns:p="urn:generated:p">'+''.join(f'<p:item p:id="{i}" xmlns:q="urn:q:{i%17}"><q:child xml:lang="en">μ{i}</q:child></p:item>' for i in range(1000))+'</root>'
docs['deep']='<root>'+''.join('<node a="v">'*64+f'<leaf>{i}</leaf>'+'</node>'*64 for i in range(40))+'</root>'
attlist=' '.join(f'a{i} '+("(x|y|z) 'x'" if i%3==0 else "CDATA 'default &e;'" if i%3==1 else 'IDREF #IMPLIED') for i in range(128))
docs['dtd']='<!DOCTYPE root [<!ENTITY e "value"><!ENTITY joined "&e; &e;"><!ENTITY % extra "<!ATTLIST item extra NMTOKENS \' one   two \' >">%extra;<!ELEMENT root (item*)><!ELEMENT item (#PCDATA)><!ATTLIST item '+attlist+'>]><root>'+''.join(f'<item a1="explicit{i}">&joined;</item>' for i in range(300))+'</root>'
docs['line_endings']='<root>'+''.join(f'<item a="a\r\nb\rc\nd\te">L{i}\r\nX\rY\nZ</item>' for i in range(1200))+'</root>'
rows=[]
for name,doc in docs.items():
 p=out/(name+'.xml');p.write_bytes(doc.encode());rows.append({'name':name,'path':str(p),'encoding':'UTF-8','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'chunks':[17,4096,65536],'namespaces':[False,True]})
for name,encoding,bom in [('mixed','utf-16-le',b'\xff\xfe'),('namespaces','utf-16-be',b'\xfe\xff'),('line_endings','utf-16-le',b'\xff\xfe')]:
 p=out/(name+'-'+encoding+'.xml');p.write_bytes(bom+docs[name].encode(encoding));rows.append({'name':name+'-'+encoding,'path':str(p),'encoding':encoding,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'chunks':[17,4096,65536],'namespaces':[False,True]})
doc='<?xml version="1.0" encoding="ISO-8859-1"?><root>'+''.join(f'<item id="{i}">café à bientôt</item>' for i in range(900))+'</root>'
p=out/'latin1.xml';p.write_bytes(doc.encode('latin1'));rows.append({'name':'latin1','path':str(p),'encoding':'ISO-8859-1','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'chunks':[1,4096,65536],'namespaces':[False,True]})
(w/'training-inputs.json').write_text(json.dumps({'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'seed':0x4F52494F4C45,'method':'New deterministic generated XML only, built without reading any real project corpus. Equal two parses per document/chunk/namespace condition through native callbacks; no fixture selected or changed from held-out results.','iterations':1,'rows':rows},indent=2)+'\n')
print(json.dumps({'documents':len(rows),'bytes':sum(x['bytes'] for x in rows),'conditions':sum(len(x['chunks'])*len(x['namespaces']) for x in rows)}))
