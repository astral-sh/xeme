from pathlib import Path
import hashlib,json,re,tarfile,gzip,math
W=Path('/tmp/oriole-pgo-study'); seen={}
def sha(p):
 p=Path(p); h=hashlib.sha256(p.read_bytes()).hexdigest();seen[str(p)]=h;return h
def read(n):return json.loads((W/n).read_text())
def check(p,h):assert sha(p)==h,(str(p),h,sha(p))
source=read('source.json'); check(W/'source.json','f6219724dd1e6d5a946a02d7f3a0966ff3366cc31ce05ec2fd8d9877709e3989')
for p,h in source['files'].items():check(W/'source'/p,h)
assert read('preparation.json')['files']==source['files']
builds=[read(x+'-build.json') for x in ('control','generate','use')]
for label,d in zip(('control','generate','use'),builds):
 assert d['status']=='passed' and d['returncode']==0
 assert d['command']==builds[0]['command'] and d['cwd']==builds[0]['cwd']
 assert d['source_manifest_sha256']==sha(W/'source.json')
 check(W/(label+'-build.log'),d['log_sha256']);check(W/(label+'-liboriole_expat.so'),d['library_sha256']);check(W/(label+'-liboriole_expat.a'),d['archive_sha256'])
 assert {k:v for k,v in d['environment'].items() if k not in ('CARGO_TARGET_DIR','RUSTFLAGS')}=={k:v for k,v in builds[0]['environment'].items() if k not in ('CARGO_TARGET_DIR','RUSTFLAGS')}
assert builds[0]['environment']['RUSTFLAGS']==''
assert builds[2]['profile_use_sha256']==sha(W/'merged.profdata')
t=read('training-inputs.json');check(W/'generate_training.py',t['generator_sha256'])
for x in t['rows']:check(x['path'],x['sha256']);assert Path(x['path']).stat().st_size==x['bytes']
train=[read(x+'-training.json') for x in ('control','generate','use')]
assert all(d['rows']==train[0]['rows'] and len(d['rows'])==288 and d['status']=='passed' for d in train)
for d in train:
 check(W/'train.py',d['script_sha256']);check(W/'training-inputs.json',d['inputs_sha256']);check(W/'source.json',d['source_manifest_sha256'])
 assert all(r['status']==1 and r['error']==0 and not r['callback_exceptions'] for r in d['rows'])
lengths={x['name']:x['bytes'] for x in t['rows']};parse_count=sum(math.ceil(lengths[r['fixture']]/r['chunk']) for r in train[0]['rows']);assert parse_count==870312
counts=(W/'profile-counts.txt').read_text()
def counter(name):return [int(x) for x in re.search(r'^  '+name+r':\n.*?Block counts: \[([^]]+)\]',counts,re.M|re.S)[1].split(',')]
assert counter('XML_Parse')[0]==parse_count
assert counter('XML_ParserCreate')[0]==counter('XML_ParserCreateNS')[0]==144
merge=read('merge.json')
for p,h in merge['raw_profiles'].items():check(W/p,h)
assert sorted(merge['raw_profiles'])==sorted(str(p.relative_to(W)) for p in (W/'raw-profiles').iterdir())
check(W/'merged.profdata',merge['merged_sha256']);check(W/'profile-counts.txt',merge['commands'][1]['stdout_sha256'])
tools=read('llvm-tools-matching.json');check(W/'llvm-tools-1.98.0.tar.xz',tools['archive_sha256']);assert (W/'llvm-tools-1.98.0.sha256').read_text().split()[0]==tools['archive_sha256']
for p,h in tools['extracted'].items():check(W/p,h)
extracted=set()
with tarfile.open(W/'llvm-tools-1.98.0.tar.xz','r|xz') as tar:
 for m in tar:
  for p,h in tools['extracted'].items():
   if m.name.endswith('/'+p.split('/',1)[1]) and m.isfile():
    assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==h;extracted.add(p)
assert extracted==set(tools['extracted'])
assert '22.1.8' in tools['version'] and 'LLVM version: 22.1.8' in read('preparation.json')['rustc']
profiles={}
for name,prefix in [('profile.json',''),('expat-profile-screen.json','expat-')]:
 d=read(name); assert d['status']=='passed'
 for p,h in d['hashes'].items():check(p,h)
 for h in d['heldout_inputs']:check(h['path'],h['sha256'])
 assert len({h['name'] for h in d['heldout_inputs']})==6
 assert not {h['sha256'] for h in d['heldout_inputs']} & {x['sha256'] for x in t['rows']}
 groups={}
 for r in d['rows']:
  stem=prefix+r['workload']+'-'+r['library']; out=(W/(stem+'.out')).read_text();ir=int(re.search(r'^summary: (\d+)',out,re.M)[1]); assert r['instructions']==ir and r['returncode']==0
  stdout=json.loads((W/(stem+'.stdout')).read_text()); assert len(stdout['samples'])==2
  observations=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in stdout['samples']});assert list(map(list,observations))==r['observations']
  for suffix in ['.out','.stdout','.stderr','.annotation.txt']:sha(W/(stem+suffix))
  groups.setdefault(r['workload'],{})[r['library']]=(ir,observations)
 for workload,rows in groups.items():
  assert len({str(v[1]) for v in rows.values()})==1
  for key,ratio in d['ratios'][workload].items():
   a,b=key.split('_over_');assert ratio==rows[a][0]/rows[b][0]
 profiles[name]={'rows':len(d['rows']),'ratios':d['ratios'],'instructions':{k:{l:v[0] for l,v in vs.items()} for k,vs in groups.items()}}
# Expat uses its own GCC profiles, with a matching normal compiler/configuration.
es=read('expat-source.json')
for p,h in es['files'].items():check(W/'expat-source'/p,h)
eb=[read('expat-'+x+'-build.json') for x in ('control','generate','use')]
for label,d in zip(('control','generate','use'),eb):
 assert d['status']=='passed' and d['features']==eb[0]['features'] and d['compiler']==eb[0]['compiler'] and d['tools_sha256']==eb[0]['tools_sha256']
 assert d['source_manifest_sha256']==sha(W/'expat-source.json') and d['generated_config_sha256']==d['normal_config_sha256']
 check(W/('expat-'+label+'-liboriole_expat.so'),d['library_sha256']);check(W/('expat-'+label+'-build/expat_config.h'),d['generated_config_sha256'])
 for c in d['commands']:assert c['returncode']==0;check(c['log'],c['log_sha256'])
 for p,h in d['tools_sha256'].items():check(p,h)
assert eb[0]['library_sha256']==es['normal_library_sha256']
et=[read('expat-'+x+'-training.json') for x in ('control','generate','use')]
assert all(d['rows']==et[0]['rows'] and len(d['rows'])==288 and d['status']=='passed' for d in et)
assert [[(r['fixture'],r['namespaces'],r['chunk'],r['handlers'],r['iteration']) for r in d['rows']] for d in et]==[[(r['fixture'],r['namespaces'],r['chunk'],r['handlers'],r['iteration']) for r in train[0]['rows']]]*3
em=read('expat-profile.json')
for p,h in em['files'].items():check(W/p,h)
assert len(em['files'])==7
check(W/'expat-profile-counts.txt',em['counts_sha256']);assert em['returncode']==0
manual=Path('/home/dev-user/.cache/oriole/profilers/local/usr/share/man/man1/valgrind.1.gz');text=gzip.decompress(manual.read_bytes()).decode();assert 'implicitly sets' in text[text.index('toggle\\-collect'):text.index('toggle\\-collect')+3000];sha(manual)
launch=read('training-launch-provenance.json')
check(launch['python_executable'],launch['python_sha256']);check(launch['taskset_executable'],launch['taskset_sha256']);sha(W/'training-launch-provenance.json')
for r in launch['records']:check(W/r['result_report'],r['result_sha256'])
report={'status':'passed','scope':'Read-only source and artifact arithmetic/provenance review. No builds, parser reruns, training, timing, or network retrieval. Original stored download checksum verified locally; not independently fetched.','oriole_source_files':len(source['files']),'expat_source_files':len(es['files']),'training':{'inputs':len(t['rows']),'parses_per_engine_build':288,'record_sets':6,'expected_XML_Parse_calls_per_run':parse_count,'observed_Oriole_profile_XML_Parse_calls':counter('XML_Parse')[0],'ordinary_creates':144,'namespace_creates':144,'heldout_real_projects':6,'overlapping_hashes':0,'source_review':'Generator constructs all twelve documents from fixed constants and seeded loops, reads no project corpus. train.py uses Python ctypes callbacks retained until parser free; content models freed in callback. Training is not timing.'},'profiles':profiles,'build_review':['Oriole normal/instrumented/use commands, compiler context and settings match except intended profile flags and distinct build directories. Fresh normal492a is primary control; original0546 secondary.','Expat uses unchanged pinned2.8.4 GCC13.3 -O3/noLTO features/config, normal7a333 exactly equals pinned normal; separate seven GCC gcda files, no Rust profile reuse.','No missing-profile warning in retained Oriole use log. Expat compile logs retain exact commands and have no missing-profile warning.','Callgrind --toggle-collect implicitly disables initial collection, confirmed installed manual. Both parses collected; constructor/free/loader/input IO excluded; callback instructions included. No wall-time assertion audited.'],'limitations':['Training launch command/executable identity was not captured at launch; explicit retrospective command record now preserved and interpreter/taskset/result hashes verified. Counters independently match all870312 expected parser calls and144+144 constructor calls.','Training-inputs method says native callbacks inaccurately; Python ctypes callbacks train, native C callbacks measure held-out Ir. Original manifest and explicit correction artifact are preserved.','Tool download sidecar and archived bytes are mutually consistent, verified extracted profdata and libraries; audit does not independently authenticate earlier network retrieval.','Different compiler families are intentional Rust/C contexts; use within-engine normal-to-PGO ratios before cross-engine comparison. Only three held-out workloads and one4KiB/mode each have instruction results.','Training and source profiles belong to exact0546 source, exclude rejected anchor and later buffer changes. All-six/full-mode timing and broader compatibility are separate gates.'],'hashes':seen}
Path('/tmp/oriole-pgo-independent-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','hashes':len(seen),'report_sha256':sha('/tmp/oriole-pgo-independent-review.json'),'profiles':profiles},indent=2))
