from pathlib import Path
import sys,hashlib,json,platform,subprocess
w=Path('/tmp/oriole-pgo-study');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();labels=['control','generate','use','expat-control','expat-generate','expat-use'];py=Path(sys.executable).resolve();taskset=Path('/usr/bin/taskset').resolve();records=[]
for label in labels:
 r=json.loads((w/(label+'-training.json')).read_text());assert r['status']=='passed' and len(r['rows'])==288
 records.append({'label':label,'command':['taskset','-c','5','python3',str(w/'train.py'),label],'cwd':'/home/dev-user/code/oss/oriole','environment_overrides':{'LLVM_PROFILE_FILE':'/tmp/oriole-pgo-study/raw-profiles/training-%m-%p.profraw'} if label=='generate' else {},'result_report':label+'-training.json','result_sha256':sha(w/(label+'-training.json'))})
for prefix in ['', 'expat-']:
 reference=json.loads((w/(prefix+'control-training.json')).read_text())['rows']
 for label in ['generate','use']:assert json.loads((w/(prefix+label+'-training.json')).read_text())['rows']==reference
correction={'field':'training-inputs.json.method','original_wording':'through native callbacks','correction':'through Python ctypes callbacks. Only parser libraries are PGO-instrumented. The held-out instruction/timing drivers use native C callbacks.','handling':'Original frozen training-inputs.json and all consuming hashes preserved unchanged; this explicit correction applies to the study description.'}
report={'status':'passed','scope':'Retrospective launch provenance transcribed from the actual tool commands after training; executable paths/version/hashes read now. These identity fields were not captured at each launch. No interpreter/compiler installation or update occurred during the study. Result records and profiles themselves were captured by each run.','python_executable':str(py),'python_version':sys.version,'python_sha256':sha(py),'taskset_executable':str(taskset),'taskset_sha256':sha(taskset),'training_driver_sha256':sha(w/'train.py'),'records':records,'compared_records':1728,'within_engine_complete_record_differences':0,'description_correction':correction}
(w/'training-launch-provenance.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'python':str(py),'compared_records':1728,'differences':0}))
