from pathlib import Path
import hashlib,json,subprocess,time
w=Path('/tmp/oriole-pgo-study');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();tool=w/'llvm-tools-1.98.0/bin/llvm-profdata';raw=sorted((w/'raw-profiles').glob('*.profraw'));assert raw
control=json.loads((w/'control-training.json').read_text());generate=json.loads((w/'generate-training.json').read_text());assert control['status']==generate['status']=='passed';assert control['rows']==generate['rows'];assert len(control['rows'])==288
r={'status':'incomplete','tool_sha256':sha(tool),'raw_profiles':{str(p.relative_to(w)):sha(p) for p in raw},'training_parses':288,'training_comparison':'All288 complete status/error/callback hash/count/exception records exactly equal fresh normal control','commands':[]}
try:
 cmd=['taskset','-c','5',str(tool),'merge','--num-threads=1','-o',str(w/'merged.profdata'),*[str(p) for p in raw]];p=subprocess.run(cmd,capture_output=True,text=True,timeout=60);r['commands'].append({'command':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0
 cmd=[str(tool),'show','--all-functions','--counts',str(w/'merged.profdata')];p=subprocess.run(cmd,capture_output=True,text=True,timeout=60);(w/'profile-counts.txt').write_text(p.stdout);r['commands'].append({'command':cmd,'returncode':p.returncode,'stdout_file':'profile-counts.txt','stdout_sha256':sha(w/'profile-counts.txt'),'stderr':p.stderr});assert p.returncode==0
 r['merged_sha256']=sha(w/'merged.profdata');r['status']='passed'
finally:(w/'merge.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'raw_profiles':len(raw),'profile_sha256':r.get('merged_sha256')}))
