from pathlib import Path
import hashlib,json,shutil,subprocess,os,time
w=Path('/tmp/oriole-pgo-study');base=Path('/tmp/oriole-attlist-9074');s=w/'source';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((base/'source.json').read_text());assert sha(base/'liboriole_expat.so')=='0546fcf56b146126dacc440c740a610ba36df518d09890badee9a527482ab6c8'
for p,h in m['files'].items():
 assert sha(base/p)==h,p
 q=s/p;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/p,q)
shutil.copy2(base/'source.json',w/'source.json');shutil.copy2(base/'liboriole_expat.so',w/'original-control.so')
(w/'inputs').mkdir(exist_ok=True);(w/'raw-profiles').mkdir(exist_ok=True)
record={'source':str(s),'base_manifest':str(base/'source.json'),'base_manifest_sha256':sha(base/'source.json'),'files':m['files'],'original_control_sha256':sha(w/'original-control.so'),'rustc':subprocess.check_output(['rustc','+ohm','-vV'],text=True),'documentation':['https://doc.rust-lang.org/rustc/profile-guided-optimization.html','https://llvm.org/docs/CommandGuide/llvm-profdata.html'],'prior_studies':'No Oriole PGO study found in repo docs/benchmarks or /tmp pgo/profdata names; existing uv/Ruff scripts are unrelated. Search permission errors in system-private /tmp directories were not treated as Oriole search coverage.'}
(w/'preparation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'copied_source_files':len(m['files']),'source':str(s)}))
