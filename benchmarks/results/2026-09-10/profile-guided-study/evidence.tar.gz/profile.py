from pathlib import Path
import hashlib,json,os,re,subprocess,time,shutil
w=Path('/tmp/oriole-pgo-study');repo=Path('/home/dev-user/code/oss/oriole');driver=Path('/tmp/oriole-shared-dtd-implementation/benchmark/driver');profroot=Path('/home/dev-user/.cache/oriole/profilers/local/usr');profiler=profroot/'bin/valgrind';annotator=profroot/'bin/callgrind_annotate';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
libs={'original':w/'original-control.so','control':w/'control-liboriole_expat.so','pgo':w/'use-liboriole_expat.so'};fixtures={'wayland':repo/'benchmarks/projects/corpus/wayland/wayland.xml','maven':repo/'benchmarks/projects/corpus/maven/pom.xml','batik':repo/'benchmarks/projects/corpus/batik/batikLogo.svg'}
corpus=repo/'benchmarks/projects/corpus-manifest.json';projects=json.loads(corpus.read_text());heldout=[]
for project in projects['projects']:
 for f in project['files']:
  if f['role']=='input':
   p=corpus.parent/f['path'];assert sha(p)==f['sha256'];heldout.append({'name':project['name'],'path':str(p),'sha256':sha(p)})
training=json.loads((w/'training-inputs.json').read_text());assert not {x['sha256'] for x in training['rows']} & {x['sha256'] for x in heldout};assert len({x['name'] for x in heldout})==6
files=[Path(__file__),driver,profiler,annotator,*libs.values(),*fixtures.values(),w/'source.json',w/'merged.profdata',w/'training-inputs.json',w/'generate-training.json',w/'merge.json'];hashes={str(p):sha(p) for p in files};env={**os.environ,'VALGRIND_LIB':str(profroot/'libexec/valgrind')};report={'status':'incomplete','scope':'Callgrind instructions inside XML_Parse including native callbacks; one warmup and one measured parse are both collected. Constructor/free/input IO/library load excluded by collection toggle. No wall-time gain or reference Expat comparison claimed. Same unchanged native driver as earlier source studies. CPU5 only.','hashes':hashes,'heldout_inputs':heldout,'training_overlap_hashes':[],'rows':[]}
try:
 for name,ns in [('wayland',False),('maven',True),('batik',False)]:
  observations={}
  for label,lib in libs.items():
   stem=name+'-'+label;output=w/(stem+'.out');cmd=['taskset','-c','5',str(profiler),'--tool=callgrind','--toggle-collect=XML_Parse','--callgrind-out-file='+str(output),str(driver),str(lib),str(fixtures[name]),'4096','1']+(['namespaces'] if ns else []);t=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=180);(w/(stem+'.stdout')).write_text(p.stdout);(w/(stem+'.stderr')).write_text(p.stderr)
   row={'workload':name,'namespaces':ns,'library':label,'command':cmd,'returncode':p.returncode,'wall_seconds_not_benchmark':time.monotonic()-t};report['rows'].append(row);assert p.returncode==0
   data=json.loads(p.stdout);assert len(data['samples'])==2;observations[label]=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in data['samples']});assert len(observations[label])==1;row['observations']=observations[label];row['instructions']=int(re.search(r'^summary: (\d+)',output.read_text(),re.M)[1]);assert row['instructions']>0
   a=subprocess.run([str(annotator),'--auto=no','--threshold=100','--show-percs=no',str(output)],capture_output=True,text=True,env=env,timeout=60);(w/(stem+'.annotation.txt')).write_text(a.stdout);assert a.returncode==0
  assert observations['original']==observations['control']==observations['pgo'];print(name,[(r['library'],r['instructions']) for r in report['rows'] if r['workload']==name],flush=True)
 report['ratios']={name:{numerator+'_over_'+denominator:next(r['instructions'] for r in report['rows'] if r['workload']==name and r['library']==numerator)/next(r['instructions'] for r in report['rows'] if r['workload']==name and r['library']==denominator) for numerator,denominator in [('pgo','control'),('control','original'),('pgo','original')]} for name in fixtures}
 assert all(sha(Path(p))==h for p,h in hashes.items());report['status']='passed'
finally:(w/'profile.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report.get('ratios'),indent=2))
