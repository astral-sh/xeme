from pathlib import Path
import gzip,hashlib,json,os,platform,random,statistics,subprocess,sys,time,shutil
w=Path('/tmp/oriole-pgo-study');repo=Path('/home/dev-user/code/oss/oriole');out=w/'screen';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();mode=sys.argv[1];assert mode in ['prepare','time']
libs={'oriole-normal':w/'control-liboriole_expat.so','oriole-pgo':w/'use-liboriole_expat.so','expat-normal':w/'expat-control-liboriole_expat.so','expat-pgo':w/'expat-use-liboriole_expat.so'};driver=Path('/tmp/oriole-shared-dtd-implementation/benchmark/driver');corpus=repo/'benchmarks/projects/corpus-manifest.json';entries=json.loads(corpus.read_text());fixtures={p['name']:corpus.parent/next(f['path'] for f in p['files'] if f['role']=='input') for p in entries['projects']};assert len(fixtures)==6
if mode=='prepare':
 out.mkdir(exist_ok=False);support=out/'support';support.mkdir();shutil.copy2(repo/'tools/xml_abi.py',support/'xml_abi.py');shutil.copy2(repo/'benchmarks/projects.py',support/'projects.py');shutil.copy2(repo/'benchmarks/native_driver.c',support/'native_driver.c');sys.path.insert(0,str(support));from xml_abi import Expat;from projects import native_output
 profile_manifest=json.loads((w/'expat-profile.json').read_text());assert all(sha(w/p)==h for p,h in profile_manifest['files'].items())
 buildfiles=[w/(name+'-build.json') for name in ['control','generate','use','expat-control','expat-generate','expat-use']];files=[Path(__file__),driver,corpus,*fixtures.values(),*libs.values(),*support.iterdir(),*buildfiles,w/'merged.profdata',w/'source.json',w/'expat-source.json',w/'training-inputs.json',w/'train.py',w/'generate_training.py',w/'expat-profile.json',w/'merge.json'];hashes={str(p):sha(p) for p in files if p.is_file()};report={'status':'incomplete','scope':'Four-way native callback-driver screen on6held-out project XML inputs; not full project execution. Per-process creation/handler registration/parsing/callback hashing/destruction timed; file read/dlopen/process startup excluded. All PGO training used only12newgenerated fixtures and unchanged144configurations repeatedtwice. Original0546 contextual control remains in separate instruction report.','limitations':'Shared host CPU frequency/cache/memory bandwidth uncontrolled. Compiler contexts differ across engines: Oriole Ohm/rustc LLVM22 ThinLTO/cgu1; Expat originalGCC13.3 -O3/noLTO. Within-engine normal/PGO flags and source are controlled. Batik external DTD intentionally unloaded by all engines; no SVG rendering/projectsemantic work. These are screening results, no adoption claim.','pairs':7,'iterations':{'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256},'cpu':0,'random_seed':202609101757,'platform':platform.platform(),'hashes_before':hashes,'preflights':[],'rows':[]}
 try:
  engines={label:Expat(str(path)) for label,path in libs.items()}
  for name,fixture in fixtures.items():
   for ns in [False,True]:
    for chunk in [4096,65536]:
     observed={label:e.parse(fixture.read_bytes(),chunk,ns) for label,e in engines.items()};log=f'preflight-{name}-{ns}-{chunk}.json.gz'
     with gzip.open(out/log,'wt') as f:json.dump(observed,f,separators=(',',':'))
     assert all(r['status']==1 and r['error']==0 and not r['callback_errors'] for r in observed.values()),log
     gold=observed['expat-normal']['normalized_events'];assert all(r['normalized_events']==gold for r in observed.values()),log
     report['preflights'].append({'name':name,'namespaces':ns,'chunk':chunk,'expected':native_output(gold),'log':log,'log_sha256':sha(out/log)})
  assert all(sha(Path(p))==h for p,h in hashes.items());report['status']='preflight_passed'
 finally:(out/'preflight.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'status':report['status'],'conditions':len(report['preflights']),'engine_preflights':4*len(report['preflights'])}),flush=True)
else:
 assert os.sched_getaffinity(0)=={0},'Timings require explicit tasksetCPU0 after rootrelease'
 report=json.loads((out/'preflight.json').read_text());assert report['status']=='preflight_passed';assert all(sha(Path(p))==h for p,h in report['hashes_before'].items());report['status']='incomplete';report['preflight_sha256']=sha(out/'preflight.json');rng=random.Random(report['random_seed']);jobs=[(p,pair) for p in report['preflights'] for pair in range(report['pairs'])];rng.shuffle(jobs)
 try:
  for condition,pair in jobs:
   name=condition['name'];ns=condition['namespaces'];chunk=condition['chunk'];order=list(libs);rng.shuffle(order);row={'name':name,'namespaces':ns,'chunk':chunk,'pair':pair,'order':order,'processes':{}};report['rows'].append(row)
   for label in order:
    cmd=['taskset','-c','0',str(driver),str(libs[label]),str(fixtures[name]),str(chunk),str(report['iterations'][name])]+(['namespaces'] if ns else []);stem=f'{name}-{ns}-{chunk}-{pair}-{label}';proc={'command':cmd};row['processes'][label]=proc
    try:r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
    except subprocess.TimeoutExpired as e:
     proc.update(returncode=None,timeout_seconds=60,stdout=(e.stdout or b'').decode(errors='replace') if isinstance(e.stdout,bytes) else e.stdout,stderr=(e.stderr or b'').decode(errors='replace') if isinstance(e.stderr,bytes) else e.stderr);raise
    except OSError as e:proc.update(returncode=None,launch_error=repr(e));raise
    filename=stem+'.json.gz'
    with gzip.open(out/filename,'wt') as f:f.write(r.stdout)
    (out/(stem+'.stderr')).write_text(r.stderr);proc.update(returncode=r.returncode,stdout=filename,stdout_sha256=sha(out/filename),stderr=stem+'.stderr',stderr_sha256=sha(out/(stem+'.stderr')));assert r.returncode==0,proc
    data=json.loads(r.stdout);samples=data['samples'];assert len(samples)==report['iterations'][name]+1;assert all([s['hash'],s['elements'],s['text_bytes']]==condition['expected'] for s in samples);assert samples[0]['warmup'] and all(not s['warmup'] for s in samples[1:]);proc['median_seconds']=statistics.median(s['seconds'] for s in samples[1:]);assert proc['median_seconds']>0
   row['ratios']={a+'_over_'+b:row['processes'][a]['median_seconds']/row['processes'][b]['median_seconds'] for a,b in [('oriole-pgo','oriole-normal'),('expat-pgo','expat-normal'),('oriole-normal','expat-normal'),('oriole-pgo','expat-pgo')]}
   (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
  report['summary']=[{**{k:c[k] for k in ['name','namespaces','chunk']},'median_ratios':{key:statistics.median(r['ratios'][key] for r in report['rows'] if all(r[k]==c[k] for k in ['name','namespaces','chunk'])) for key in report['rows'][0]['ratios']}} for c in report['preflights']];assert all(sha(Path(p))==h for p,h in report['hashes_before'].items());assert sha(out/'preflight.json')==report['preflight_sha256'];report['status']='passed'
 finally:(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'status':report['status'],'cohorts':len(report['rows']),'processes':sum(len(r['processes']) for r in report['rows']),'summary':report.get('summary')},indent=2),flush=True)
