from pathlib import Path
import hashlib,json,statistics
w=Path('/tmp/oriole-pgo-study');r=json.loads((w/'screen/results.json').read_text());assert r['status']=='passed';assert len(r['rows'])==168;assert sum(len(x['processes']) for x in r['rows'])==672
summary={}
for engine in ['oriole','expat']:
 values=[x['median_ratios'][engine+'-pgo_over_'+engine+'-normal'] for x in r['summary']]
 summary[engine]={'conditions':len(values),'faster_conditions':sum(x<1 for x in values),'median_condition_ratio':statistics.median(values),'min_condition_ratio':min(values),'max_condition_ratio':max(values)}
report={'status':'passed','scope':'Initial held-out PGO study, no source changes and no adoption claim. Lower ratios mean less wall time. Condition medians are descriptive, not pooled workload weighted throughput or confidence bounds.','timing_results_sha256':hashlib.sha256((w/'screen/results.json').read_bytes()).hexdigest(),'conditions':24,'cohorts':168,'timed_processes':672,'measured_parses':sum(r['iterations'][x['name']]*4 for x in r['rows']),'warmup_parses':672,'summary':summary,'per_condition':r['summary']}
(w/'screen-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='per_condition'},indent=2))
