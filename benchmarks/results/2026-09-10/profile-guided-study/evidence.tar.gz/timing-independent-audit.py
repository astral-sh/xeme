from pathlib import Path
import collections,gzip,hashlib,json,math,random,statistics
root=Path('/tmp/oriole-pgo-study');out=root/'screen';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();loadgz=lambda f:json.loads(gzip.decompress(Path(f).read_bytes()))
p=json.loads((out/'preflight.json').read_text());r=json.loads((out/'results.json').read_text());s=json.loads((root/'screen-summary.json').read_text());assert p['status']=='preflight_passed' and r['status']==s['status']=='passed'
assert p['rows']==[] and r['preflight_sha256']==sha(out/'preflight.json') and s['timing_results_sha256']==sha(out/'results.json')
for k in p:
 if k not in ('status','rows'):assert r[k]==p[k]
for f,h in r['hashes_before'].items():assert sha(f)==h,f
libs={'oriole-normal':root/'control-liboriole_expat.so','oriole-pgo':root/'use-liboriole_expat.so','expat-normal':root/'expat-control-liboriole_expat.so','expat-pgo':root/'expat-use-liboriole_expat.so'}
corpus=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');fixtures={}
for project in json.loads(corpus.read_text())['projects']:
 f=next(f for f in project['files'] if f['role']=='input');fixtures[project['name']]=corpus.parent/f['path'];assert sha(fixtures[project['name']])==f['sha256']
conditions=[(name,ns,chunk) for name in fixtures for ns in (False,True) for chunk in (4096,65536)];assert len(conditions)==len(p['preflights'])==len(r['summary'])==24
key=lambda x:(x['name'],x['namespaces'],x['chunk']);recordhashes={}; counts=collections.Counter(); raw_variants=collections.Counter();positions_diff=0

def norm(events):
 result=[];texts=[]
 for event in events:
  if event[0]=='text':texts.append(event[1]);continue
  if texts:result.append(['text',''.join(texts)]);texts=[]
  result.append(event)
 if texts:result.append(['text',''.join(texts)])
 return result

def native(events):
 h=14695981039346656037;elements=textbytes=0
 for e in events:
  if e[0]=='start':
   data=b'\xffS'+e[1].encode()+b''.join(b'\0'+name.encode()+b'\0'+value.encode() for name,value in e[2])+b'\0';elements+=1
  elif e[0]=='end':data=b'\xffE'+e[1].encode()+b'\0'
  elif e[0]=='text':data=e[1].encode();textbytes+=len(data)
  else:continue
  for byte in data:h=((h^byte)*1099511628211)&((1<<64)-1)
 return [f'{h:016x}',elements,textbytes]
for condition,pre in zip(conditions,p['preflights']):
 assert key(pre)==condition;f=out/pre['log'];assert sha(f)==pre['log_sha256'];recordhashes[str(f)]=sha(f);data=loadgz(f);assert set(data)==set(libs)
 for label,x in data.items():
  assert x['status']==1 and x['error']==0 and not x['callback_errors'];assert norm(x['events'])==x['normalized_events'];assert x['normalized_events']==data['expat-normal']['normalized_events'];counts['preflight_engine_parses']+=1;counts['preflight_raw_events']+=len(x['events']);counts['preflight_normalized_events']+=len(x['normalized_events'])
 assert native(data['expat-normal']['normalized_events'])==pre['expected']
 for a,b in [('oriole-normal','oriole-pgo'),('expat-normal','expat-pgo'),('oriole-normal','expat-normal')]:raw_variants[a+'_vs_'+b]+=int(data[a]['events']!=data[b]['events'])
 positions_diff+=int(any(x['position']!=data['expat-normal']['position'] for x in data.values()))
jobs=[(c,pair) for c in p['preflights'] for pair in range(p['pairs'])];rng=random.Random(p['random_seed']);rng.shuffle(jobs);assert len(jobs)==len(r['rows'])==168
ratio_pairs=[('oriole-pgo','oriole-normal'),('expat-pgo','expat-normal'),('oriole-normal','expat-normal'),('oriole-pgo','expat-pgo')];ratios_by_condition=collections.defaultdict(lambda:collections.defaultdict(list));orders=collections.Counter();process_medians=[]
for (condition,pair),row in zip(jobs,r['rows']):
 assert key(row)==key(condition) and row['pair']==pair;order=list(libs);rng.shuffle(order);assert row['order']==list(row['processes'])==order;orders[order[0]]+=1
 for label in order:
  proc=row['processes'][label];count=p['iterations'][row['name']];cmd=['taskset','-c','0','/tmp/oriole-shared-dtd-implementation/benchmark/driver',str(libs[label]),str(fixtures[row['name']]),str(row['chunk']),str(count)]+(['namespaces'] if row['namespaces'] else [])
  assert proc['command']==cmd and proc['returncode']==0 and 'timeout_seconds' not in proc and 'launch_error' not in proc
  for filename,hashname in [('stdout','stdout_sha256'),('stderr','stderr_sha256')]:
   f=out/proc[filename];assert sha(f)==proc[hashname];recordhashes[str(f)]=sha(f)
  data=loadgz(out/proc['stdout']);assert data['version']==('oriole_0.0.1' if label.startswith('oriole') else 'expat_2.8.4');samples=data['samples'];assert len(samples)==count+1
  for i,x in enumerate(samples):
   assert x['iteration']==i and x['warmup']==(i==0) and math.isfinite(x['seconds']) and x['seconds']>0
   assert [x[k] for k in ('hash','elements','text_bytes')]==condition['expected']
  med=statistics.median(x['seconds'] for x in samples[1:]);assert med==proc['median_seconds'];process_medians.append(med);counts['timed_processes']+=1;counts['measured_parses']+=count;counts['warmup_parses']+=1;counts['timed_samples_including_warmup']+=len(samples)
 ratios={a+'_over_'+b:row['processes'][a]['median_seconds']/row['processes'][b]['median_seconds'] for a,b in ratio_pairs};assert ratios==row['ratios']
 for k,v in ratios.items():ratios_by_condition[key(row)][k].append(v)
summary=[]
for condition in p['preflights']:
 ratios=ratios_by_condition[key(condition)];assert all(len(v)==7 for v in ratios.values());summary.append({k:condition[k] for k in ('name','namespaces','chunk')}|{'median_ratios':{k:statistics.median(v) for k,v in ratios.items()}})
assert summary==r['summary']==s['per_condition']
engine_summaries={}
for engine in ('oriole','expat'):
 values=[x['median_ratios'][engine+'-pgo_over_'+engine+'-normal'] for x in summary]
 item={'conditions':len(values),'faster_conditions':sum(v<1 for v in values),'median_condition_ratio':statistics.median(values),'min_condition_ratio':min(values),'max_condition_ratio':max(values)};assert item==s['summary'][engine];engine_summaries[engine]=item
for k in ('timed_processes','measured_parses','warmup_parses'):assert counts[k]==s[k]
assert s['conditions']==24 and s['cohorts']==168 and counts['measured_parses']==136976 and counts['timed_samples_including_warmup']==137648
# Check all native/preflight result logs belong to the declared complete cohort.
assert set(recordhashes)=={str(f) for f in out.iterdir() if f.name.endswith(('.json.gz','.stderr'))}
files=[out/'preflight.json',out/'results.json',root/'screen-summary.json',root/'screen.py',Path('/tmp/oriole-pgo-independent-review.json'),out/'support/native_driver.c',out/'support/projects.py',out/'support/xml_abi.py',Path(__file__)]
report={
 'status':'passed','scope':'Independent read-only timing arithmetic, source-generator and saved-hash audit on CPU 2. No parser runs, PGO training, builds, native profiles, benchmark reruns or network retrieval. Source/build/training provenance remains in the separate parent review.',
 'counts':dict(counts),'conditions':24,'cohorts':168,'cohorts_per_condition':7,'record_files_verified':len(recordhashes),'frozen_files_current_hashes_verified':len(r['hashes_before']),'seed_reproduced':r['random_seed'],'first_engine_counts':dict(orders),
 'verification':['All 96 preflight engine parses accept with no callback errors; adjacent text normalization independently reconstructed from original event arrays and equal across four engines.', 'Expected native FNV, element count and text byte count independently reconstructed from each reference normalized transcript; every warmup/measured native sample matches.', 'All 672 process commands/library/input identities, exit codes, stdout/stderr hashes, iteration numbering, warmup flags and positive finite durations verified.', 'Every process median excludes exactly one warmup; all 672 cohort ratios (four per cohort), 24 condition summaries, and two engine summary groups recomputed exactly.', 'Randomized cohort order and engine order exactly reproduced from seed; all declared cohort stdout/stderr files accounted for, no omitted cohort or sample found.', 'All 30 captured input/source/tool/library/profile/build-file hashes still match the preflight freeze. Final script checks these same hashes after timing; no separate hashes_after map was emitted.'],
 'summary':engine_summaries,'per_condition':summary,
 'ratio_definition':'PGO/normal means candidate time divided by normal time; below 1 favors PGO. Each condition value is the median of seven same-cohort ratios of process medians. The reported engine value is the median of 24 condition ratios, not pooled throughput or a workload-weighted estimate.',
 'sample_count_clarification':'136,976 is measured parses only. Add 672 native warmup parses for 137,648 timed-process samples. The 96 ctypes preflight engine parses are separate and not native timed samples.',
 'reference_scope':{'preflight_rows_with_any_final_position_difference':positions_diff,'preflight_raw_event_rows_differing':dict(raw_variants),'meaning':'Normalized streams preserve registered callback order and values except adjacent text segmentation. These preflights do not record per-callback coordinates, raw input contexts, allocation failures, all DTD callbacks, or external DTD loading. Batik external DTD remains unloaded.'},
 'timing_scope':'CLOCK_MONOTONIC around native parser create, handler registration, parse, callback hashing and destroy; input file loading/dlopen/process startup excluded. Four-way cohort executes engines sequentially in randomized order on CPU 0; each process discards one warmup and uses 7/64/128/512/256/256 measured iterations for Vulkan/Wayland/Maven/Batik/GTK/DocBook.',
 'limitations':['Single shared-host campaign with uncontrolled frequency/cache/memory bandwidth; 24 lower condition medians for each engine are descriptive screening evidence, not confidence bounds or an adoption claim.', 'Within-engine normal/PGO controls use the audited same source/compiler settings except profile flags. Cross-engine times compare Rust LLVM22 ThinLTO/codegen-units1 and C GCC13.3 O3/noLTO contexts; this audit does not normalize these differences.', 'Oriole primary normal is 492a04fc, not the older 0546 library; source scope is the frozen 0546-era source and excludes later buffers/anchor changes.', 'Medians of different ratios must not be multiplied or divided to infer another median comparison.', 'Earlier instruction-count and training provenance are separate, independently recorded scopes; no causal speedup guarantee for production consumers.'],
 'file_hashes':{str(f):sha(f) for f in files},'verified_record_hash_map_sha256':hashlib.sha256(json.dumps(recordhashes,sort_keys=True,separators=(',',':')).encode()).hexdigest()
}
f=Path('/tmp/oriole-pgo-timing-independent-review.json');assert not f.exists();f.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(f),'sha256':sha(f),'counts':dict(counts),'summary':engine_summaries,'records':len(recordhashes)},indent=2))
