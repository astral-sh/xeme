from pathlib import Path
import ctypes as c,hashlib,json,sys,os,time
w=Path('/tmp/oriole-pgo-study');label=sys.argv[1];libpath=w/(label+'-liboriole_expat.so');lib=c.CDLL(str(libpath));P=c.c_void_p;S=c.c_char_p;I=c.c_int
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def api(name,ret,args):
 f=getattr(lib,name);f.restype=ret;f.argtypes=args;return f
create=api('XML_ParserCreate',P,[S]);create_ns=api('XML_ParserCreateNS',P,[S,c.c_char]);free=api('XML_ParserFree',None,[P]);parse=api('XML_Parse',I,[P,S,I,I]);error=api('XML_GetErrorCode',I,[P]);param=api('XML_SetParamEntityParsing',I,[P,I]);free_model=api('XML_FreeContentModel',None,[P,P])
start_t=c.CFUNCTYPE(None,P,S,c.POINTER(S));end_t=c.CFUNCTYPE(None,P,S);text_t=c.CFUNCTYPE(None,P,P,I);pair_t=c.CFUNCTYPE(None,P,S,S);void_t=c.CFUNCTYPE(None,P);doctype_t=c.CFUNCTYPE(None,P,S,S,S,I);decl_t=c.CFUNCTYPE(None,P,S,I,P,I,S,S,S,S);att_t=c.CFUNCTYPE(None,P,S,S,S,S,I);notation_t=c.CFUNCTYPE(None,P,S,S,S,S);model_t=c.CFUNCTYPE(None,P,S,P)
set_elements=api('XML_SetElementHandler',None,[P,start_t,end_t]);set_text=api('XML_SetCharacterDataHandler',None,[P,text_t]);set_default=api('XML_SetDefaultHandlerExpand',None,[P,text_t]);set_comment=api('XML_SetCommentHandler',None,[P,end_t]);set_pi=api('XML_SetProcessingInstructionHandler',None,[P,pair_t]);set_att=api('XML_SetAttlistDeclHandler',None,[P,att_t]);set_decl=api('XML_SetEntityDeclHandler',None,[P,decl_t]);set_model=api('XML_SetElementDeclHandler',None,[P,model_t]);set_notation=api('XML_SetNotationDeclHandler',None,[P,notation_t]);set_doctype=api('XML_SetDoctypeDeclHandler',None,[P,doctype_t,void_t]);set_ns=api('XML_SetNamespaceDeclHandler',None,[P,pair_t,end_t])
inputs=json.loads((w/'training-inputs.json').read_text());report={'status':'incomplete','label':label,'library_sha256':sha(libpath),'source_manifest_sha256':sha(w/'source.json'),'inputs_sha256':sha(w/'training-inputs.json'),'script_sha256':sha(Path(__file__)),'profile_file_environment':os.environ.get('LLVM_PROFILE_FILE'),'rows':[],'scope':'Generated training inputs only; minimal and full callback modes, both namespace modes, three chunk widths. Each input is parsed twice with fresh parsers. The Python driver is not instrumented; its runtime is not a benchmark.'}
try:
 for fixture in inputs['rows']:
  data=Path(fixture['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==fixture['sha256']
  for ns in fixture['namespaces']:
   for chunk in fixture['chunks']:
    for handlers in ['minimal','full']:
     expected=None
     for iteration in range(2):
      h=hashlib.sha256();counts={};faults=[];parser=create_ns(None,b'|') if ns else create(None);assert parser
      def add(tag,*values):
       counts[tag]=counts.get(tag,0)+1;h.update(tag.encode()+b':')
       for value in values:
        if value is None:h.update(b'N;')
        elif isinstance(value,int):h.update(str(value).encode()+b';')
        else:h.update(str(len(value)).encode()+b':'+value)
      def guarded(function):
       def call(*args):
        try:return function(*args)
        except BaseException as exc:faults.append(repr(exc))
       return call
      def start(_,name,attrs):
       values=[];index=0
       while attrs[index] is not None:values.append(attrs[index]);index+=1
       add('start',name,*values)
      callbacks=[start_t(guarded(start)),end_t(guarded(lambda _,name:add('end',name))),text_t(guarded(lambda _,text,n:add('text',c.string_at(text,n))))]
      set_elements(parser,*callbacks[:2]);set_text(parser,callbacks[2]);assert param(parser,2)
      if handlers=='full':
       default=text_t(guarded(lambda _,text,n:add('default',c.string_at(text,n))));comment=end_t(guarded(lambda _,text:add('comment',text)));pi=pair_t(guarded(lambda _,target,text:add('pi',target,text)));att=att_t(guarded(lambda _,el,name,kind,value,required:add('attlist',el,name,kind,value,required)));decl=decl_t(guarded(lambda _,name,parameter,value,n,base,system,public,notation:add('entity',name,parameter,c.string_at(value,n) if value else None,base,system,public,notation)))
       def element(_,name,model):
        add('element',name);free_model(parser,model)
       model=model_t(guarded(element));notation=notation_t(guarded(lambda _,name,base,system,public:add('notation',name,base,system,public)));doc=doctype_t(guarded(lambda _,name,system,public,internal:add('doctype',name,system,public,internal)));docend=void_t(guarded(lambda _:add('doctype-end')));nsstart=pair_t(guarded(lambda _,prefix,uri:add('ns-start',prefix,uri)));nsend=end_t(guarded(lambda _,prefix:add('ns-end',prefix)))
       callbacks += [default,comment,pi,att,decl,model,notation,doc,docend,nsstart,nsend]
       set_default(parser,default);set_comment(parser,comment);set_pi(parser,pi);set_att(parser,att);set_decl(parser,decl);set_model(parser,model);set_notation(parser,notation);set_doctype(parser,doc,docend);set_ns(parser,nsstart,nsend)
      try:
       status=1
       for start in range(0,len(data),chunk):
        part=data[start:start+chunk];status=parse(parser,part,len(part),int(start+chunk>=len(data)))
        if status!=1:break
       record={'fixture':fixture['name'],'namespaces':ns,'chunk':chunk,'handlers':handlers,'iteration':iteration,'status':status,'error':error(parser),'callback_sha256':h.hexdigest(),'counts':counts,'callback_exceptions':faults}
       report['rows'].append(record);assert status==1 and not faults,record
       normalized={k:v for k,v in record.items() if k!='iteration'}
       if expected is None:expected=normalized
       else:assert normalized==expected
      finally:free(parser)
 report['status']='passed'
finally:(w/(label+'-training.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'label':label,'status':report['status'],'parses':len(report['rows'])}))
