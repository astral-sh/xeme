from pathlib import Path
import difflib,gzip,hashlib,json,os,shutil,subprocess,sys,tarfile,time
root=Path('/tmp/oriole-pgo-tool');out=Path('/tmp/oriole-pgo-tool-final-handoff');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=root/'tools/pgo'
patch=[]
for p in sorted(source.glob('*')):
 if not p.is_file():continue
 name='tools/pgo/'+p.name
 patch+=['diff --git a/'+name+' b/'+name+'\n','new file mode 100644\n']
 patch+=list(difflib.unified_diff([],p.read_text().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+name))
(out/'pgo-tool.patch').write_text(''.join(patch))
with tarfile.open(out/'tool-source.tar.gz','w:gz') as archive:
 for p in sorted(source.glob('*')):
  if p.is_file():archive.add(p,arcname='tools/pgo/'+p.name)
for name in ['initial-tool-source.tar.gz','isolated-tool-source.tar.gz','spaces-tool-source.tar.gz']:
 shutil.copy2(root/name,out/name)
runs=[('initial-8d',Path('/tmp/oriole-pgo-tool-validation/runs/run-tu0eszq1')),('isolated-9cc',Path('/tmp/oriole-pgo-tool-validation/runs/run-vj8upotc')),('spaces-9cc',Path('/tmp/oriole-pgo-tool-validation with spaces/runs/run-vfkfk5f_')),('final-reviewed-9cc',Path('/tmp/oriole-pgo-tool-validation with spaces/runs/run-yldc34vh'))]
metadata=[]
for name,run in runs:
 manifest=json.loads((run/'manifest.json').read_text());assert manifest['status']=='passed'
 assert all(c['returncode']==0 and c['status']=='passed' for c in manifest['commands'])
 for artifact,h in manifest['libraries_sha256'].items():assert sha(run/artifact)==h
 with tarfile.open(out/(name+'-evidence.tar.gz'),'w:gz') as archive:
  for p in sorted(run.rglob('*')):
   if p.is_file() and p.suffix not in ('.so','.a','.dylib'):archive.add(p,arcname=str(p.relative_to(run)))
 metadata.append({'name':name,'run':str(run),'manifest_sha256':sha(run/'manifest.json'),'libraries_sha256':manifest['libraries_sha256'],'compared_parses':manifest['compared_parses'],'source_sha256':manifest['source_sha256'],'script_sha256':manifest['script_sha256']})
for path in ['/tmp/oriole-pgo-tool-validation-launch.log','/tmp/oriole-pgo-tool-validation-launch-2.log','/tmp/oriole-pgo-tool-validation-final-launch.log','/tmp/oriole-pgo-tool-validation-spaces-launch.log','/tmp/oriole-pgo-tool-validation-reviewed-launch.log']:
 shutil.copy2(path,out/Path(path).name)
commands=[['taskset','-c','5',sys.executable,'-m','unittest','discover','-s',str(source),'-p','test_*.py'],['taskset','-c','5','uv','tool','run','--offline','ruff','check',str(source)],['taskset','-c','5','uv','tool','run','--offline','ruff','format','--check',str(source)],['taskset','-c','5','uv','tool','run','--offline','ty','check','--extra-search-path',str(source),str(source)]]
checks=[]
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,capture_output=True,text=True,env=os.environ|{'UV_TOOL_DIR':'/home/dev-user/.cache/oriole/python-tools'});log=out/f'check-{i}.log';log.write_text(r.stdout+r.stderr);checks.append({'command':cmd,'returncode':r.returncode,'log':log.name,'sha256':sha(log)});assert r.returncode==0
inputs=json.loads((runs[-1][1]/'inputs/manifest.json').read_text())
prior=json.loads(Path('/tmp/oriole-pgo-study/training-inputs.json').read_text())
assert [(r['name'],r['sha256']) for r in inputs['rows']]==[(r['name'],r['sha256']) for r in prior['rows']]
final=metadata[-1];assert final['script_sha256']=={p.name:sha(p) for p in source.glob('*') if p.is_file()}
summary={'status':'passed','scope':'Optional offline PGO build tooling only; no runtime/allocator/limits/CI edits. Linux x86_64 actual validation; macOS source-level support only. Generated replay does not replace compatibility/security/consumer gates.','patch_sha256':sha(out/'pgo-tool.patch'),'files':{str(p.relative_to(root)):sha(p) for p in source.glob('*') if p.is_file()},'runs':metadata,'checks':checks,'training':'Exact12 original study input hashes,1325736bytes,144configurations repeatedtwice in each phase; 288 instrumented/288 optimized records per build. Python ctypes callbacks, element models freed but trees not hashed. No real project inputs.','isolation':'Last three runs use -I -S, explicit own-module import and dladdr(XML_Parse) origin verification. Initial8d run precedes this hardening and remains separate. Last9cc run exercises spaces in output/profile paths and empty encoded flags overriding deliberately stale RUSTFLAGS.','failed_attempts':'Initial direct script invocation failed before any build because safe-path Python omitted sibling module directory; raw traceback retained. Added explicit own-script directory import. Initial provenance tests exposed unrelated malloc symbol dladdr path being relative; origin helper now rejects mismatched paths before opening them. The negative test then proved malloc can belong to Python itself, so its unrelated expected path is now the test source file. An initial package-check failure is preserved separately. Tests pass without weakening requested-library verification.','source_lineage':'initial8d matches /tmp/oriole-buffers-composed/source.json; both9cc runs match64files /tmp/oriole-buffers-final/release-identity.json. Original PGO study handoff remains immutable. No timing/adoption claim for these new libraries.','source_revision_requires_retraining':True}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
shutil.copy2('/tmp/oriole-buffers-final/release-identity.json',out/'final-runtime-identity.json')
shutil.copy2(root/'package.py',out/'package.py')
(out/'README.md').write_text('''# Optional PGO tooling validation

`pgo-tool.patch` adds five files under `tools/pgo/`; it changes no parser runtime, allocator, limit, or CI configuration. The tool implements an offline generate/train/merge/use build with fresh profiles per invocation, LLVM version matching, input/tool/source hashes, raw command logs, an exclusive output lock, and generated replay verification.

Twelve tool tests, Ruff and ty pass. Four actual x86_64 Linux build runs are retained separately: the first on frozen8d, the isolated-training followup on final9cc, the path-with-spaces run on9cc, and the final reviewed tool on9cc after compiler-wrapper and failed-process-group cleanup corrections. The last run also proves that an explicitly empty CARGO_ENCODED_RUSTFLAGS overrides inherited RUSTFLAGS. Each run completed 288 instrumented and 288 optimized parses with identical selected callback records; final child interpreters use -I -S and verify XML_Parse's actual loaded library with dladdr.

The 12 generated fixture hashes exactly match the earlier study; no held-out project inputs enter training. Element model trees are freed but not serialized in these digests. This build check does not replace full consumer, compatibility or security validation, and no new performance/adoption claim is made here. macOS has not been executed.

Each compressed evidence archive preserves manifests, logs, input bytes, training records and raw/merged profiles. Binaries remain at the local paths in summary.json with hashes; they are intentionally not duplicated. The initial safe-path import failure is preserved as a raw launch log. The original `/tmp/oriole-pgo-study-handoff` remains unchanged.
''')
review=Path('/tmp/oriole-pgo-tool-independent-review')
for name in ['initial-source-review.json','final-source-review.json']:
 shutil.copy2(review/name,out/name)
shutil.copy2('/tmp/oriole-pgo-tool-handoff/check-0.log',out/'initial-package-test-failure.log')
(out/'README.md').write_text((out/'README.md').read_text()+'\nIndependent final source review is included and reports no outstanding source blockers. It does not claim to have rerun the tool. The final build uses empty wrapper environment overrides so configured Cargo wrappers cannot substitute a compiler, and a failed command terminates any remaining process group before releasing its lock.\n')
files={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()}
(out/'artifact-manifest.json').write_text(json.dumps({'status':'passed','files':files},indent=2)+'\n')
print(json.dumps({'path':str(out),'artifacts':len(files),'bytes':sum(x['bytes'] for x in files.values()),'manifest_sha256':sha(out/'artifact-manifest.json'),'patch_sha256':sha(out/'pgo-tool.patch'),'summary_sha256':sha(out/'summary.json')}))
