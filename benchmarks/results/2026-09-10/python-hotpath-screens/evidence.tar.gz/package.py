from pathlib import Path
import hashlib,tarfile,json,io,math
r=Path('/home/dev-user/code/oss/oriole');d=r/'docs/benchmarks/results/2026-09-10/python-hotpath-screens';d.mkdir(parents=True,exist_ok=True);entries={};summaries={};sha=lambda b:hashlib.sha256(b).hexdigest()
for name in ['name','recycled','prefix64']:
 for kind in ['real-consumers','python-projects']:
  w=Path(f'/tmp/oriole-{name}-{kind}')
  for p in sorted(w.rglob('*')):
   if not p.is_file() or p.is_symlink():continue
   data=p.read_bytes()
   if data.startswith(b'\x7fELF') or data.startswith(b'!<arch>\n'):continue
   entries[f'{name}/{kind}/{p.relative_to(w)}']=data
 for p in Path('/tmp').glob(f'oriole-{name}-*consumers*.log'):entries[f'{name}/logs/{p.name}']=p.read_bytes()
 for p in Path('/tmp').glob(f'oriole-{name}-python-projects*.log'):entries[f'{name}/logs/{p.name}']=p.read_bytes()
 report=json.loads(Path(f'/tmp/oriole-{name}-python-projects/summary.json').read_text());assert report['status']=='passed' and report['sha256_before']==report['sha256_after'];rows={k:1/v['median_expat_over_oriole'] for k,v in report['summary'].items()};geos={mode:math.exp(sum(math.log(v) for k,v in rows.items() if k.endswith('/'+mode))/6) for mode in ['elementtree','pyexpat-events']};summaries[name]={'geomean_slowdown':geos,'slowdown':rows,'source_build_manifest':f'{name}/real-consumers/build.json','pairs':report['pairs'],'iterations':report['iterations']}
for f in ['benchmarks/build_project_consumers.py','benchmarks/python_projects.py','benchmarks/projects/corpus-manifest.json']:
 entries['tools/'+f]=(r/f).read_bytes()
entries['package.py']=Path(__file__).read_bytes()
files={k:{'bytes':len(v),'sha256':sha(v)} for k,v in entries.items()}
with tarfile.open(d/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for name,data in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data))
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in t:assert sha(t.extractfile(m).read())==files[m.name]['sha256']
(d/'files.json').write_text(json.dumps({'archive_sha256':sha((d/'evidence.tar.gz').read_bytes()),'members':files},indent=2)+'\n');(d/'report.json').write_text(json.dumps(summaries,indent=2)+'\n')
(d/'README.md').write_text('''# Actual CPython consumers over pinned project XML

These three separate screens build unmodified CPython 3.12.13 `pyexpat.c` and `_elementtree.c` with identical settings against frozen Oriole and Expat libraries. Module/library origins, complete preflight trees/events and every measured output are verified. All six original project files are pinned by hash. Each screen uses five randomized pairs, five parses per process and 4 KiB chunks on CPU 0.

| Isolated checkpoint | ElementTree time / Expat | pyexpat time / Expat | Wayland pyexpat time / Expat |
| --- | ---: | ---: | ---: |
| Name-rule compatibility | 2.069× | 1.659× | 1.202× |
| Scanning utilities and name reuse | 1.870× | 1.541× | 1.063× |
| Utilities, names, byte count and tag scanner | 1.825× | 1.519× | 1.048× |

The first two columns use the geometric mean of per-project paired median time ratios. Lower is faster. Every measured condition remains slower than Expat. These are separate cohorts on a shared host with uncontrolled load/frequency, and their compatibility bases differ; they do not establish an exact causal speedup between rows. The measured work is real CPython XML parsing, not full application execution. The final row is the isolated performance candidate, not the later root composition with attribute fixes.

[report.json](report.json) gives every project ratio; [files.json](files.json) verifies all members of [evidence.tar.gz](evidence.tar.gz). Raw samples, build flags, compiler/source/library hashes, module origins, commands and the initial failed `taskset -c0` startup are retained. No readiness claim follows from these benchmarks.
''')
print(json.dumps({'members':len(files),'archive_bytes':(d/'evidence.tar.gz').stat().st_size,'sha256':sha((d/'evidence.tar.gz').read_bytes())}))
