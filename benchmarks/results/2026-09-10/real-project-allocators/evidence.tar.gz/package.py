from pathlib import Path
import hashlib,json,tarfile,shutil
w=Path('/tmp/oriole-real-allocator-screen');d=Path('benchmarks/results/2026-09-10/real-project-allocators');d.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copy2('/tmp/oriole-context-copy-integrated/source.json',w/'parser-source.json');shutil.copy2('benchmarks/native_driver.c',w/'native_driver.c')
r=json.loads((w/'results.json').read_text());assert r['status']=='passed';summary=json.loads((w/'summary.json').read_text());files={}
for p in sorted(w.iterdir()):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF'):continue
 files[p.name]={'sha256':sha(p),'bytes':p.stat().st_size}
with tarfile.open(d/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n in files:t.add(w/n,arcname=n,recursive=False)
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==files[m.name]['sha256']
manifest={'archive_sha256':sha(d/'evidence.tar.gz'),'members':files};(d/'files.json').write_text(json.dumps(manifest,indent=2)+'\n');shutil.copy2(w/'summary.json',d/'summary.json')
(d/'README.md').write_text('''# System allocator and jemalloc on real XML

We screened the six pinned project inputs on the frozen `ed7748a` runtime, comparing the system allocator with process-local `LD_PRELOAD` of Debian's jemalloc 5.3.0. Both Oriole and Expat receive the same allocator change; the C driver and parser/input bytes remain identical. This does not override an embedding application's custom Expat memory suite or measure CPython allocator behavior.

The protocol uses 4 KiB feeds, namespace processing off/on, five randomized process groups and five measured parses after a discarded warmup, pinned to CPU 0. Every sample has matching callback hashes, element counts and text bytes. A separate symbol-origin probe and loader binding logs verify malloc-family resolution for both libraries. No preload configuration is installed globally.

Median paired system/jemalloc ratios are generally near neutral to 1.05× for Oriole, with one DocBook namespace condition at 1.07×; Expat is also near neutral to 1.06×. A median-of-all-samples calculation showed a larger DocBook outlier, so all samples and per-process ratios remain available. These short shared-host screens show modest allocator effects and do not close Oriole's gap with Expat. They are not evidence of a full-application speedup or a reason to change the default allocator.

[summary.json](summary.json) contains every process median and paired ratio. [evidence.tar.gz](evidence.tar.gz) contains the exact script, input/parser/allocator hashes, frozen parser build metadata, native driver source, provider probe and raw loader/timing observations. [files.json](files.json) verifies every archive member. Reproduction uses the commands/paths in `run.py` with the supplied pinned corpus and frozen parser sources; the standard native driver build is documented in the benchmark README.
'''+f'\nArchive SHA256: `{manifest["archive_sha256"]}`.\n')
print(json.dumps({'members':len(files),'archive_bytes':(d/'evidence.tar.gz').stat().st_size,'archive_sha256':manifest['archive_sha256']}))
