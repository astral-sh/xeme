#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
int main(void) {
    void *symbol = dlsym(RTLD_DEFAULT, "malloc");
    Dl_info info;
    if (!symbol || !dladdr(symbol, &info)) return 1;
    puts(info.dli_fname);
    return 0;
}
