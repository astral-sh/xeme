from pathlib import Path
import hashlib,json,os,random,statistics,subprocess,time
w=Path('/tmp/oriole-real-allocator-screen');jemalloc=Path('/usr/lib/x86_64-linux-gnu/libjemalloc.so.2');oriole=Path('/tmp/oriole-context-copy-integrated/liboriole_expat.so');expat=Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4');driver=Path('/tmp/oriole-grammar-bench-plain/native-driver');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest_path=Path('benchmarks/projects/corpus-manifest.json');manifest=json.loads(manifest_path.read_text());inputs={p['name']:manifest_path.parent/next(f['path'] for f in p['files'] if f['role']=='input') for p in manifest['projects']}
report={'started':time.time(),'scope':'Shared-host native C callback screen. Process-local preload changes allocator for both implementations including driver allocations; same frozen parser/driver/input bytes. Not matched CPython allocator-suite or application evidence.','affinity':[0],'pairs':5,'iterations':5,'chunk':4096,'seed':20260913,'sha256':{str(p):sha(p) for p in [jemalloc,oriole,expat,driver,manifest_path,*(inputs.values()),w/'provider.c',w/'provider']},'providers':{},'samples':[]};envs={}
for allocator in ['system','jemalloc']:
 env=os.environ.copy();env.pop('LD_PRELOAD',None)
 if allocator=='jemalloc':env['LD_PRELOAD']=str(jemalloc)
 provider=subprocess.check_output([str(w/'provider')],env=env,text=True).strip();assert ('jemalloc' in provider)==(allocator=='jemalloc'),provider
 report['providers'][allocator]={'path':provider,'sha256':sha(Path(provider))};envs[allocator]=env
for label,lib in [('oriole',oriole),('expat',expat)]:
 env={**envs['jemalloc'],'LD_DEBUG':'bindings'}
 p=subprocess.run([str(driver),str(lib),str(inputs['batik']),'4096','1'],env=env,capture_output=True,text=True,check=True)
 (w/f'{label}-bindings.log').write_text(p.stderr)
 bindings=[line for line in p.stderr.splitlines() if str(lib) in line and 'jemalloc' in line and 'malloc' in line];assert bindings,(label,'no verified allocator bindings');report.setdefault('bindings',{})[label]=bindings
os.sched_setaffinity(0,{0});rng=random.Random(report['seed']);libs={'oriole':oriole,'expat':expat}
for ns in [False,True]:
 for name,xml in inputs.items():
  expected=None
  for pair in range(report['pairs']):
   order=[(label,allocator) for label in libs for allocator in envs];rng.shuffle(order)
   for label,allocator in order:
    command=[str(driver),str(libs[label]),str(xml),'4096',str(report['iterations']),*(['namespaces'] if ns else [])]
    p=subprocess.run(command,env=envs[allocator],text=True,capture_output=True,timeout=90,check=True);assert not p.stderr,p.stderr;out=json.loads(p.stdout)
    for sample in out['samples']:
     signature=tuple(sample[k] for k in ['hash','elements','text_bytes']);expected=signature if expected is None else expected;assert signature==expected
    report['samples'].append({'input':name,'namespaces':ns,'pair':pair,'label':label,'allocator':allocator,'command':command,'output':out})
  medians={f'{label}/{allocator}':statistics.median(s['seconds'] for r in report['samples'] if r['input']==name and r['namespaces']==ns and r['label']==label and r['allocator']==allocator for s in r['output']['samples'] if not s['warmup']) for label in libs for allocator in envs}
  print(name,ns,{k:round(v*1000,3) for k,v in medians.items()},flush=True)
  (w/'results.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(sha(Path(p))==digest for p,digest in report['sha256'].items());report['completed']=time.time();report['status']='passed';(w/'results.json').write_text(json.dumps(report,indent=2)+'\n')
