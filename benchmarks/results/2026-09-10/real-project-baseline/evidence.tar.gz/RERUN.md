# Rerun against a candidate

Coordinate CPU 0 ownership before measurements. Commands below assume this handoff remains at `/tmp/oriole-real-project-bench`, a candidate shared library is available at `/tmp/oriole-candidate/liboriole_expat.so`, and the candidate build/source manifest is `/tmp/oriole-candidate/source.json`. Use a new output directory for every attempt; failed reports must remain separate.

```sh
taskset -c 0 python3 /tmp/oriole-real-project-bench/benchmarks/projects.py \
  --library /tmp/oriole-candidate/liboriole_expat.so \
  --reference /home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4 \
  --corpus /tmp/oriole-real-project-bench/corpus-manifest.json \
  --output /tmp/oriole-candidate-native-projects \
  --pairs 7 --iterations 20 \
  --build-manifest /tmp/oriole-candidate/source.json

/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 \
  /tmp/oriole-real-project-bench/benchmarks/build_project_consumers.py \
  --library /tmp/oriole-candidate/liboriole_expat.so \
  --reference /home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4 \
  --source /home/dev-user/.cache/oriole/upstream/cpython-3.12.13 \
  --header /home/dev-user/code/oss/oriole/include \
  --output /tmp/oriole-candidate-project-consumers

taskset -c 0 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 \
  /tmp/oriole-real-project-bench/benchmarks/python_projects.py \
  --consumers /tmp/oriole-candidate-project-consumers/build.json \
  --corpus /tmp/oriole-real-project-bench/corpus-manifest.json \
  --output /tmp/oriole-candidate-python-projects \
  --pairs 7 --iterations 10

python3 /tmp/oriole-real-project-bench/benchmarks/build_wayland_project.py \
  --source /tmp/oriole-real-project-bench/wayland-scanner-source \
  --consumers /tmp/oriole-candidate-project-consumers/build.json \
  --header /home/dev-user/code/oss/oriole/include \
  --output /tmp/oriole-candidate-wayland-build

taskset -c 0 python3 /tmp/oriole-real-project-bench/benchmarks/wayland_project.py \
  --build-manifest /tmp/oriole-candidate-wayland-build/build.json \
  --input /tmp/oriole-real-project-bench/corpus/wayland/wayland.xml \
  --output /tmp/oriole-candidate-wayland-project \
  --pairs 7 --iterations 10
```

Native/Python harnesses default to both 4 KiB and 64 KiB feeds. Native independently measures namespaces off/on; both Python consumers enable namespace processing. `--preflight-only` runs the semantic gates without publishing benchmark timings. The copied `tools/xml_abi.py` is unchanged from the repository's existing helper; placing `projects.py` in the repository's `benchmarks/` directory uses that existing helper.

`build_wayland.py` records the original baseline build. `benchmarks/build_wayland_project.py` is its parameterized reusable counterpart; a separate build-only check verifies its CLI. The measured baseline remains the original binaries and manifest. Source filenames and generated headers are identical; only output/library paths differ for candidate builds.
