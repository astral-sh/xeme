import ctypes,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'benchmarks'))
from python_projects import load_consumers
consumer=Path(sys.argv[1]).resolve()
identity=load_consumers(consumer)
class Prefix(ctypes.Structure):
 _fields_=[('magic',ctypes.c_char_p),('size',ctypes.c_int),('major',ctypes.c_int),('minor',ctypes.c_int),('micro',ctypes.c_int),*[ (name,ctypes.c_void_p) for name in ['ErrorString','GetErrorCode','GetErrorColumnNumber','GetErrorLineNumber','Parse','ParserCreate_MM','ParserFree']]]
function=ctypes.pythonapi.PyCapsule_GetPointer
function.restype=ctypes.c_void_p
function.argtypes=[ctypes.py_object,ctypes.c_char_p]
import pyexpat
capsule=Prefix.from_address(function(pyexpat.expat_CAPI,b'pyexpat.expat_CAPI'))
assert capsule.magic==b'pyexpat.expat_CAPI 1.1'
assert capsule.size>=ctypes.sizeof(Prefix)
class Info(ctypes.Structure):
 _fields_=[('filename',ctypes.c_char_p),('base',ctypes.c_void_p),('symbol',ctypes.c_char_p),('address',ctypes.c_void_p)]
process=ctypes.CDLL(None)
process.dladdr.argtypes=[ctypes.c_void_p,ctypes.POINTER(Info)]
process.dladdr.restype=ctypes.c_int
origins={}
for name in ['Parse','ParserCreate_MM','ParserFree']:
 info=Info()
 assert process.dladdr(getattr(capsule,name),ctypes.byref(info))==1
 path=Path(info.filename.decode()).resolve()
 assert str(path)==identity['parser_library']['path']
 origins[name]=str(path)
import _elementtree
import xml.etree.ElementTree as ET
assert ET.XMLParser is _elementtree.XMLParser
assert ET.Element is _elementtree.Element
print(json.dumps({'identity':identity,'capsule_magic':capsule.magic.decode(),'capsule_size':capsule.size,'capsule_actual_function_origins':origins,'elementtree_uses_loaded_accelerator':True},indent=2))
