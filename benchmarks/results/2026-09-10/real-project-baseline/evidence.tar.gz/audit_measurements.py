from __future__ import annotations
import hashlib,json,math,statistics
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def digest(path: Path):return hashlib.sha256(path.read_bytes()).hexdigest()
results={}
for name in ['native-baseline','python-baseline']:
 path=ROOT/name/'summary.json'
 if not path.exists():continue
 report=json.loads(path.read_text())
 assert report['status']=='passed'
 assert report['affinity']==[0]
 assert report['sha256_before']==report['sha256_after']
 for p,h in report['sha256_before'].items(): assert digest(Path(p))==h,(p,'changed')
 rows=report['rows']
 assert len(rows)==6*2*2*2*7
 assert set(row['engine'] for row in rows)=={'oriole','expat'}
 assert len(report['preflights'])==(24 if name=='native-baseline' else 48)
 groups=defaultdict(list)
 for row in rows:groups[row['key']].append(row)
 audited={}
 aggregate=defaultdict(list)
 for key,items in groups.items():
  assert len(items)==14
  outputs=set()
  medians={engine:[] for engine in ['oriole','expat']}
  for pair in range(7):
   pair_rows=[r for r in items if r['pair']==pair]
   assert len(pair_rows)==2 and set(r['order'] for r in pair_rows)=={0,1}
   for row in pair_rows:
    assert len(row['samples'])==report['iterations']+1
    for index,sample in enumerate(row['samples']):
     assert sample['iteration']==index and sample['warmup']==(index==0)
     assert sample['seconds']>0 and math.isfinite(sample['seconds'])
     outputs.add((sample['hash'],sample['elements'],sample['text_bytes']) if name=='native-baseline' else (sample['output_sha256'],sample['output_rows']))
    medians[row['engine']].append(statistics.median(s['seconds'] for s in row['samples'] if not s['warmup']))
  assert len(outputs)==1
  ratios=[medians['expat'][i]/medians['oriole'][i] for i in range(7)]
  speedup=statistics.median(ratios)
  summary=report['summary'][key]
  assert all(math.isclose(a,b,rel_tol=1e-12) for a,b in zip(ratios,summary['paired_expat_over_oriole'],strict=True))
  assert math.isclose(speedup,summary['median_expat_over_oriole'],rel_tol=1e-12)
  audited[key]={'oriole_ms':statistics.median(medians['oriole'])*1000,'expat_ms':statistics.median(medians['expat'])*1000,'speedup_expat_over_oriole':speedup,'range_speedup':[min(ratios),max(ratios)]}
  aggregate['/'.join(key.split('/')[1:])].append(speedup)
 results[name]={'source':str(path),'source_sha256':digest(path),'status':'passed','timed_processes':len(rows),'measured_parses':sum(len(r['samples'])-1 for r in rows),'all_observed_hashes_unchanged':True,'all_paired_outputs_equal':True,'summary':audited,'equal_project_geometric_mean':{k:statistics.geometric_mean(v) for k,v in aggregate.items()},'aggregate_method':'Unweighted geometric mean of six per-project median paired Expat/Oriole ratios, separately for each chunk and namespace/consumer mode. It does not represent end-to-end project speedup.'}
(ROOT/'measurement-audit.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({name:{'status':r['status'],'processes':r['timed_processes'],'parses':r['measured_parses'],'aggregate':r['equal_project_geometric_mean']} for name,r in results.items()},indent=2))
