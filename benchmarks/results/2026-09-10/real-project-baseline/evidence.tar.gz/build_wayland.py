import hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
source=root/'wayland-scanner-source'
build=root/'wayland-scanner-build'
build.mkdir(exist_ok=False)
version=(source/'wayland-version.h.in').read_text()
for key,value in [('MAJOR','1'),('MINOR','23'),('MICRO','90')]: version=version.replace(f'@WAYLAND_VERSION_{key}@',value)
version=version.replace('@WAYLAND_VERSION@','1.23.90')
(build/'wayland-version.h').write_text(version)
consumers=json.loads((root/'consumers/build.json').read_text())
paths=[*source.iterdir(),build/'wayland-version.h',Path('/home/dev-user/code/oss/oriole/include/expat.h')]
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'configuration':'Pinned unmodified Wayland scanner.c and wayland-util.c. Linux POSIX configuration, HAVE_STRNDUP=1, optional libxml DTD validation disabled (HAVE_LIBXML=0) in both binaries. Version header generated from the pinned template with meson.build version 1.23.90. Same -O3 C compiler and Expat-compatible header for both engines; parser library/rpath differ.','compiler':subprocess.check_output(['cc','--version'],text=True),'source_sha256':{str(p):digest(p) for p in paths},'binaries':{},'commands':[]}
for engine,consumer in consumers['consumers'].items():
 library=Path(consumer['library'])
 binary=build/f'wayland-scanner-{engine}'
 command=['taskset','-c','2','cc','-std=c99','-O3','-D_POSIX_C_SOURCE=200809L','-DHAVE_STRNDUP=1','-DHAVE_LIBXML=0','-I/home/dev-user/code/oss/oriole/include',f'-I{build}',f'-I{source}',str(source/'scanner.c'),str(source/'wayland-util.c'),str(library),f'-Wl,-rpath,{library.parent}','-o',str(binary)]
 done=subprocess.run(command,capture_output=True,text=True,check=False)
 (build/f'{engine}-build.log').write_text(done.stdout+done.stderr)
 report['commands'].append({'command':command,'returncode':done.returncode})
 if done.returncode: raise RuntimeError(done.stderr)
 report['binaries'][engine]={'path':str(binary),'sha256':digest(binary),'library':str(library),'library_sha256':digest(library),'ldd':subprocess.check_output(['ldd',str(binary)],text=True)}
report['status']='passed'
(build/'build.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['status'])
