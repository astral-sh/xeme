import json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'corpus-manifest.json').read_text())
manifest['projects']=[p for p in manifest['projects'] if p['name']=='gtk']
(root/'negative-corpus.json').write_text(json.dumps(manifest,indent=2)+'\n')
results=[]
for kind in ['wrong-output','worker-failure']:
 compiler=root/f'inject-{kind}-cc'
 wrapper='''#!/usr/bin/env python3
import json,subprocess,sys
result=subprocess.run(['/tmp/oriole-real-project-bench/native-baseline/native-driver',*sys.argv[1:]],capture_output=True,text=True,check=False)
if result.returncode:
 sys.stderr.write(result.stderr);raise SystemExit(result.returncode)
'''
 if kind=='wrong-output':
  wrapper+="value=json.loads(result.stdout)\nfor sample in value['samples']: sample['hash']='0000000000000000'\nprint(json.dumps(value))\n"
 else:
  wrapper+="sys.stderr.write('injected worker failure\\n')\nraise SystemExit(7)\n"
 compiler.write_text("#!/usr/bin/env python3\nimport sys\nfrom pathlib import Path\nif '--version' in sys.argv: print('negative-test compiler wrapper');raise SystemExit(0)\nout=Path(sys.argv[sys.argv.index('-o')+1])\nout.write_text("+repr(wrapper)+")\nout.chmod(0o755)\n")
 compiler.chmod(0o755)
 command=['taskset','-c','0','python3',str(root/'benchmarks/projects.py'),'--library','/tmp/oriole-grammar-combined-source/liboriole_expat.so','--reference','/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','--corpus',str(root/'negative-corpus.json'),'--output',str(root/f'negative-{kind}'),'--cc',str(compiler),'--chunks','4096','--pairs','3','--iterations','3']
 run=subprocess.run(command,capture_output=True,text=True,check=False)
 report=json.loads((root/f'negative-{kind}'/'summary.json').read_text())
 expected='measured output mismatch' if kind=='wrong-output' else 'exited 7'
 assert run.returncode==1 and report['status']=='failed' and expected in report['failure']
 assert report['processes'][-1]['stdout'] or report['processes'][-1]['stderr']
 results.append({'case':kind,'command':command,'returncode':run.returncode,'failure':report['failure'],'processes_retained':len(report['processes']),'passed':True})
(root/'rejection-checks.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
