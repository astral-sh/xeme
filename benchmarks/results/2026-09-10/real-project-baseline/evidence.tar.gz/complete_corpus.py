import hashlib,json,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'corpus-manifest-initial.json').read_text())
changes={'vulkan':[('license','LICENSES/Apache-2.0.txt'),('license','LICENSES/MIT.txt')],'batik':[('license','batik-shared-resources/src/main/resources/LICENSE'),('notice','batik-shared-resources/src/main/resources/NOTICE')],'docbook':[('license','xsl/COPYING')],'gtk':[('input','gtk/ui/gtkfilechooserwidget.ui')],'maven':[('notice','NOTICE')]}
for project in manifest['projects']:
    project['files']=[f for f in project['files'] if 'failure' not in f]
    for role,remote in changes.get(project['name'],[]):
        url=f"https://raw.githubusercontent.com/{project['repository']}/{project['commit']}/{remote}"
        with urllib.request.urlopen(url,timeout=30) as response:
            data=response.read()
        dest=root/'corpus'/project['name']/Path(remote).name
        dest.write_bytes(data)
        if role=='input':
            for f in project['files']:
                if f['role']=='input': f['role']='related-small-input'
            project['selection_note']='The initially selected dialog is a 1245-byte template wrapper. The directly related file chooser widget is the main UI tree; it replaced the thin wrapper before any parser measurements. Original wrapper retained as evidence.'
        project['files'].append(dict(role=role,upstream_path=remote,path=str(dest.relative_to(root)),url=url,source_url=f"https://github.com/{project['repository']}/blob/{project['commit']}/{remote}",bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        print(project['name'],remote,len(data),flush=True)
manifest['licenses']={'vulkan':'Apache-2.0 OR MIT','wayland':'MIT','maven':'Apache-2.0','batik':'Apache-2.0','gtk':'LGPL-2.1-or-later','docbook':'DocBook project permissive license (see xsl/COPYING)'}
(root/'corpus-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
