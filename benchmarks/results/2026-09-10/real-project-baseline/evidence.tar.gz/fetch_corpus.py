from __future__ import annotations
import hashlib
import json
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROJECTS = [
    ('vulkan', 'KhronosGroup/Vulkan-Docs', 'f84d432d5b8912362f96f581f29bbc4f3c8c7843', 'xml/vk.xml', 'LICENSE.md', 'code-generation registry'),
    ('wayland', 'wayland-mirror/wayland', '1ab6b693b16e1d9734496fe60c8a6ed277e4dec3', 'protocol/wayland.xml', 'COPYING', 'protocol description'),
    ('maven', 'apache/maven', '40c59633cbb9c2bc4c915440f7198bad5cb60faf', 'pom.xml', 'LICENSE', 'project build metadata'),
    ('batik', 'apache/xmlgraphics-batik', '21a1ff1023186cc2694a6c210a64b28877eb36e3', 'samples/batikLogo.svg', 'LICENSE', 'SVG artwork'),
    ('gtk', 'GNOME/gtk', '51a0bf3627204325ccf0f8f24f587728a18c43df', 'gtk/ui/gtkfilechooserdialog.ui', 'COPYING', 'UI object tree'),
    ('docbook', 'docbook/xslt10-stylesheets', 'efd62655c11cc8773708df7a843613fa1e932bf8', 'xsl/fo/docbook.xsl', 'COPYING', 'XSLT stylesheet'),
]
rows = []
for name, repository, commit, path, license_path, purpose in PROJECTS:
    row = dict(name=name, repository=repository, commit=commit, purpose=purpose, files=[])
    for role, remote in [('input',path),('license',license_path)]:
        url = f'https://raw.githubusercontent.com/{repository}/{commit}/{remote}'
        dest = ROOT / 'corpus' / name / Path(remote).name
        dest.parent.mkdir(parents=True, exist_ok=True)
        try:
            request = urllib.request.Request(url, headers={'User-Agent':'oriole-bench-corpus/1.0'})
            with urllib.request.urlopen(request, timeout=30) as response:
                data = response.read(16 * 1024 * 1024 + 1)
            if len(data) > 16 * 1024 * 1024:
                raise ValueError('input exceeds 16 MiB limit')
            dest.write_bytes(data)
            entry = dict(role=role, upstream_path=remote, path=str(dest.relative_to(ROOT)), url=url, source_url=f'https://github.com/{repository}/blob/{commit}/{remote}', bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        except Exception as error:
            entry = dict(role=role, upstream_path=remote, url=url, failure=repr(error))
        row['files'].append(entry)
        print(name,role,entry.get('bytes'),entry.get('failure'),flush=True)
    rows.append(row)
(ROOT / 'corpus-manifest-initial.json').write_text(json.dumps({'selection':'Six projects selected by XML use case before any benchmark measurements. Inputs are original upstream bytes without concatenation, repetition or transformation. The Wayland GitHub repository is a mirror of upstream GitLab.', 'projects':rows},indent=2)+'\n')
