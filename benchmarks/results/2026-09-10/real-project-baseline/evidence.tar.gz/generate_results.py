import json,statistics
from pathlib import Path
root=Path(__file__).resolve().parent
n=json.loads((root/'native-baseline/summary.json').read_text())
p=json.loads((root/'python-baseline/summary.json').read_text())
w=json.loads((root/'wayland-baseline/summary.json').read_text())
lines=['# Frozen-runtime real-project baseline','','Runtime: `1262888`; Oriole shared-library SHA256 `ff5d86621114e464a0b20f108b6308fe155d9e8c87bd764bc00872cf124750f8`. Reference: pinned Expat 2.8.4, SHA256 `7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478`.','','All six projects are slower with this baseline. These measurements identify optimization targets; no input was removed after seeing its result.','','## Native C parser, 4 KiB feeds','','Times are medians of process medians. The ratio is the median of paired Expat/Oriole times, so below one means Oriole is slower. Namespace processing is disabled in this table.','','| Project | Oriole ms | Expat ms | Expat / Oriole |','| --- | ---: | ---: | ---: |']
for name in ['vulkan','wayland','maven','batik','gtk','docbook']:
 s=n['summary'][f'{name}/4096/namespaces-0'];lines.append(f"| {name} | {s['median_seconds']['oriole']*1000:.3f} | {s['median_seconds']['expat']*1000:.3f} | {s['median_expat_over_oriole']:.3f}× |")
lines+=['','## Matched CPython consumers, 4 KiB feeds','','These unmodified CPython extensions use the same Python interpreter, compiler flags and input bytes. All output, resolved parser-library and source checks pass.','','| Project | ElementTree Oriole ms | Expat ms | Expat / Oriole | pyexpat Oriole ms | Expat ms | Expat / Oriole |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for name in ['vulkan','wayland','maven','batik','gtk','docbook']:
 a=p['summary'][f'{name}/4096/elementtree'];b=p['summary'][f'{name}/4096/pyexpat-events']
 lines.append(f"| {name} | {a['median_seconds']['oriole']*1000:.3f} | {a['median_seconds']['expat']*1000:.3f} | {a['median_expat_over_oriole']:.3f}× | {b['median_seconds']['oriole']*1000:.3f} | {b['median_seconds']['expat']*1000:.3f} | {b['median_expat_over_oriole']:.3f}× |")
lines+=['','## Equal-project geometric means','','Every project has equal weight within each group. These aggregates do not describe whole-project build performance.','','| Consumer | 4 KiB Expat / Oriole | 64 KiB Expat / Oriole |','| --- | ---: | ---: |']
for label,report,mode in [('Native namespaces off',n,'namespaces-0'),('Native namespaces on',n,'namespaces-1'),('ElementTree',p,'elementtree'),('pyexpat events',p,'pyexpat-events')]:
 values=[statistics.geometric_mean(s['median_expat_over_oriole'] for k,s in report['summary'].items() if k.endswith(f'/{chunk}/{mode}')) for chunk in [4096,65536]]
 lines.append(f'| {label} | {values[0]:.3f}× | {values[1]:.3f}× |')
lines+=['','## Actual Wayland scanner commands','','Full-process wall times include startup, input I/O, parsing, code generation and output writes. Optional libxml DTD validation is disabled identically. Each command generates byte-identical output with both parsers.','','| Command | Oriole ms | Expat ms | Expat / Oriole |','| --- | ---: | ---: | ---: |']
for mode,s in w['summary'].items(): lines.append(f"| {mode} | {s['median_seconds']['oriole']*1000:.3f} | {s['median_seconds']['expat']*1000:.3f} | {s['median_expat_over_oriole']:.3f}× |")
lines+=['','## Evidence','','- Native: 24 full normalized preflights, 336 timed processes and 6,720 measured parses.','- Python: 48 consumer preflights, 336 timed processes and 3,360 measured parses.','- Wayland: four exact output preflights and 280 full code-generation processes.','- All source, corpus and binary hashes stay unchanged across each campaign; every recorded sample matches its paired output.','- Stable incorrect-output and worker-exit injections are rejected and preserved in separate negative reports.','- Raw per-pair ranges and all 64 KiB results are retained in the JSON reports.','- Linux shared host; CPU 0 reserved among agents for timing, with other-CPU setup/build/profiling allowed. CPU frequency, unrelated host load and shared memory bandwidth are uncontrolled.','']
(root/'RESULTS.md').write_text('\n'.join(lines))
