import datetime,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
commands=[
 ['taskset','-c','0','python3',str(root/'benchmarks/projects.py'),'--library','/tmp/oriole-grammar-combined-source/liboriole_expat.so','--reference','/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','--corpus',str(root/'corpus-manifest.json'),'--output',str(root/'native-baseline'),'--pairs','7','--iterations','20','--build-manifest','/tmp/oriole-grammar-combined-source/source.json'],
 ['taskset','-c','0','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12',str(root/'benchmarks/python_projects.py'),'--consumers',str(root/'consumers/build.json'),'--corpus',str(root/'corpus-manifest.json'),'--output',str(root/'python-baseline'),'--pairs','7','--iterations','10']]
report={'conditions':'CPU 0 exclusively reserved among our agents for timing. Root may build or perform setup/profiling on other CPUs; shared host frequency, scheduling and memory bandwidth remain uncontrolled. Native and Python campaigns execute sequentially.','runs':[]}
for index,command in enumerate(commands):
 entry={'command':command,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 report['runs'].append(entry)
 (root/'baseline-runs.json').write_text(json.dumps(report,indent=2)+'\n')
 with (root/f'baseline-{index}.log').open('w') as log:
  done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=False)
 entry.update(returncode=done.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (root/'baseline-runs.json').write_text(json.dumps(report,indent=2)+'\n')
 print(index,entry,flush=True)
 if done.returncode: raise SystemExit(done.returncode)
