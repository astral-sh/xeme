# Completed-tag validation/position fusion — rejected

## Result

Keep the frozen 9cc integrated runtime as the baseline. The candidate reduces instructions on all twelve project/namespace profile conditions (geomean **-2.73%**) but is slower in the paired throughput screen: **0.98985×** real-project geomean, **6/24** conditions positive. Generated declarations regress to **0.94725× / 0.94186×** at 4 KiB / 64 KiB. No runtime integration, text-span expansion or PGO retraining is recommended.

Project geomeans: Vulkan 0.98120×, Wayland 1.00428×, Maven 0.98281×, Batik 0.99782×, GTK 0.98387×, DocBook 0.98934×. These are candidate/control native callback-driver ratios, not comparisons with Expat or actual CPython performance. All unfavorable conditions and raw timing samples remain included. The cause of the instruction/time disagreement was not established; it should not be presented as a measured cache, branching or dependency effect.

## Change

After the unchanged incremental scanner completes a tag, and after token input accounting/copying, the candidate validates XML characters and computes the next line/column/CR state in one pass. Printable ASCII uses the existing word predicate; Unicode and XML line endings use scalar fallback. A private stack completion record is committed only after parse_start/parse_end succeeds. Source raw-width accounting, compaction, event publication and callbacks keep their existing ordering. Non-tag modes retain their existing validation path. No Source/Parser fields, allocator calls, C ABI changes or borrowed events were added.

The source is based on exact /tmp/oriole-attlist-capture-reserve (9cc87e9b). Existing scratch /tmp/oriole-utf8-feed and its stable Cargo target were reused; the previous rejected entity study remains archived separately. All 64 source hashes match source.json after validation. Frozen candidate a641e2e7, source.tar.gz and candidate.patch remain immutable. No root runtime was edited.

## Validation

- 340 affected-package Rust tests, strict Clippy and formatting pass with ordinary cargo +ohm.
- Five focused encoding tests include 111,111 exhaustive short strings under two initial coordinate/CR states, Unicode validity and long-span boundaries, plus UTF-8/UTF-16/custom raw widths, anchors and 64 KiB compaction.
- 1,518 exact differential cases and 36,456 custom-encoding comparisons have no differences.
- 95,548 per-feed tag fuzz conditions across 4,780 documents have no baseline differences. They include malformed start/end/attribute tokens, nonfinal input, decoder tails, UTF-16, namespace/Unicode name rules, exact callback prefixes and positions. Existing Expat position/error differences are recorded separately; final acceptance and successful final element events agree.
- All 4,740 original upstream API rows are byte-identical to the baseline report: 4,323 pass / 417 fail. No original assertion changed or was waived.
- Six dynamic/static C ASan/UBSan runs pass, with 327 selected allocation-failure scenarios per linkage and zero live selected blocks after free. Rust is an optimized release library, not sanitizer-instrumented. LSan is disabled for the sandbox; allocation ownership is checked by the selected allocator tracker.

## Measurement and review

The CPU0 paired screen first checks all 28 conditions with both libraries (56 preflight processes), then runs five randomized blocks (280 timing processes). Fixed per-process measured parse counts are Vulkan 7, Wayland 64, Maven 128, Batik 512, GTK 256, DocBook 256 and generated 32, plus one warmup. Input/library/driver hashes and callback hashes/counts agree before and after. Per-process medians feed paired block ratios. No outlier filtering is applied. Shared host noise remains possible.

Callgrind profiles collect XML_Parse instructions, including warmup and one measured parse with callbacks, on CPU2. Both engines in that candidate/control profile cohort are Oriole builds. Constructor/free/loader/input IO are excluded. Instruction counts are not cycles or throughput measurements.

Root early source review found no obvious ownership/accounting/coordinate blocker and requested an explicit source-stability audit. source-stability-audit.json records that tag semantic helpers do not change Source/encoding/cursors, inline entity expansion uses local borrowed frames with shared budget counters, and failed account_source leaves the same source origin and pending-error cleanup. This is author tracing; no independent final-code review or independent execution is claimed.

The full Rust build took several minutes producing test binaries. Process inspection was inconclusive, and no compiler-affinity change occurred. Tests, Clippy and fmt then completed successfully with the original command; no Ohm cache defect or workaround is claimed.

The larger read-only proposal and fresh integrated baseline profile are in /tmp/oriole-structural-profile. That proposal's broad opportunity estimate remains hypothetical. This specific fusion failed its throughput gate.
