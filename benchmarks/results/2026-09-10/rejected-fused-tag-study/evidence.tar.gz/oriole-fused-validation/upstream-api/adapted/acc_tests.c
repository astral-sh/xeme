/* Tests in the "accounting" test case for the Expat test suite
                            __  __            _
                         ___\ \/ /_ __   __ _| |_
                        / _ \\  /| '_ \ / _` | __|
                       |  __//  \| |_) | (_| | |_
                        \___/_/\_\ .__/ \__,_|\__|
                                 |_| XML parser

   Copyright (c) 2001-2006 Fred L. Drake, Jr. <fdrake@users.sourceforge.net>
   Copyright (c) 2003      Greg Stein <gstein@users.sourceforge.net>
   Copyright (c) 2005-2007 Steven Solie <steven@solie.ca>
   Copyright (c) 2005-2012 Karl Waclawek <karl@waclawek.net>
   Copyright (c) 2016-2026 Sebastian Pipping <sebastian@pipping.org>
   Copyright (c) 2017-2022 Rhodri James <rhodri@wildebeest.org.uk>
   Copyright (c) 2017      Joe Orton <jorton@redhat.com>
   Copyright (c) 2017      José Gutiérrez de la Concha <jose@zeroc.com>
   Copyright (c) 2018      Marco Maggi <marco.maggi-ipsu@poste.it>
   Copyright (c) 2019      David Loffredo <loffredo@steptools.com>
   Copyright (c) 2020      Tim Gates <tim.gates@iress.com>
   Copyright (c) 2021      Donghee Na <donghee.na@python.org>
   Copyright (c) 2023      Sony Corporation / Snild Dolkow <snild@sony.com>
   Licensed under the MIT license:

   Permission is  hereby granted,  free of charge,  to any  person obtaining
   a  copy  of  this  software   and  associated  documentation  files  (the
   "Software"),  to  deal in  the  Software  without restriction,  including
   without  limitation the  rights  to use,  copy,  modify, merge,  publish,
   distribute, sublicense, and/or sell copies of the Software, and to permit
   persons  to whom  the Software  is  furnished to  do so,  subject to  the
   following conditions:

   The above copyright  notice and this permission notice  shall be included
   in all copies or substantial portions of the Software.

   THE  SOFTWARE  IS  PROVIDED  "AS  IS",  WITHOUT  WARRANTY  OF  ANY  KIND,
   EXPRESS  OR IMPLIED,  INCLUDING  BUT  NOT LIMITED  TO  THE WARRANTIES  OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
   NO EVENT SHALL THE AUTHORS OR  COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
   DAMAGES OR  OTHER LIABILITY, WHETHER  IN AN  ACTION OF CONTRACT,  TORT OR
   OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
   USE OR OTHER DEALINGS IN THE SOFTWARE.

   SPDX-License-Identifier: MIT
*/

#include "expat_config.h"

#include <math.h> /* NAN, INFINITY */
#include <stdio.h>
#include <string.h>

#include "expat.h"
#include "internal.h"
#include "common.h"
#include "minicheck.h"
#include "chardata.h"
#include "handlers.h"
#include "acc_tests.h"
#include "bridge.h"

#if XML_GE == 1
/* Excluded internal-only test: test_accounting_precision. */

START_TEST(test_billion_laughs_attack_protection_api) {
  XML_Parser parserWithoutParent = XML_ParserCreate(NULL);
  XML_Parser parserWithParent = XML_ExternalEntityParserCreate(
      parserWithoutParent, XCS("entity123"), NULL);
  if (parserWithoutParent == NULL)
    fail("parserWithoutParent is NULL");
  if (parserWithParent == NULL)
    fail("parserWithParent is NULL");

  // XML_SetBillionLaughsAttackProtectionMaximumAmplification, error cases
  if (XML_SetBillionLaughsAttackProtectionMaximumAmplification(NULL, 123.0f)
      == XML_TRUE)
    fail("Call with NULL parser is NOT supposed to succeed");
  if (XML_SetBillionLaughsAttackProtectionMaximumAmplification(parserWithParent,
                                                               123.0f)
      == XML_TRUE)
    fail("Call with non-root parser is NOT supposed to succeed");
  if (XML_SetBillionLaughsAttackProtectionMaximumAmplification(
          parserWithoutParent, NAN)
      == XML_TRUE)
    fail("Call with NaN limit is NOT supposed to succeed");
  if (XML_SetBillionLaughsAttackProtectionMaximumAmplification(
          parserWithoutParent, -1.0f)
      == XML_TRUE)
    fail("Call with negative limit is NOT supposed to succeed");
  if (XML_SetBillionLaughsAttackProtectionMaximumAmplification(
          parserWithoutParent, 0.9f)
      == XML_TRUE)
    fail("Call with positive limit <1.0 is NOT supposed to succeed");

  // XML_SetBillionLaughsAttackProtectionMaximumAmplification, success cases
  if (XML_SetBillionLaughsAttackProtectionMaximumAmplification(
          parserWithoutParent, 1.0f)
      == XML_FALSE)
    fail("Call with positive limit >=1.0 is supposed to succeed");
  if (XML_SetBillionLaughsAttackProtectionMaximumAmplification(
          parserWithoutParent, 123456.789f)
      == XML_FALSE)
    fail("Call with positive limit >=1.0 is supposed to succeed");
  if (XML_SetBillionLaughsAttackProtectionMaximumAmplification(
          parserWithoutParent, INFINITY)
      == XML_FALSE)
    fail("Call with positive limit >=1.0 is supposed to succeed");

  // XML_SetBillionLaughsAttackProtectionActivationThreshold, error cases
  if (XML_SetBillionLaughsAttackProtectionActivationThreshold(NULL, 123)
      == XML_TRUE)
    fail("Call with NULL parser is NOT supposed to succeed");
  if (XML_SetBillionLaughsAttackProtectionActivationThreshold(parserWithParent,
                                                              123)
      == XML_TRUE)
    fail("Call with non-root parser is NOT supposed to succeed");

  // XML_SetBillionLaughsAttackProtectionActivationThreshold, success cases
  if (XML_SetBillionLaughsAttackProtectionActivationThreshold(
          parserWithoutParent, 123)
      == XML_FALSE)
    fail("Call with non-NULL parentless parser is supposed to succeed");

  XML_ParserFree(parserWithParent);
  XML_ParserFree(parserWithoutParent);
}
END_TEST

/* Excluded internal-only test: test_helper_unsigned_char_to_printable. */

START_TEST(test_amplification_isolated_external_parser) {
  // NOTE: Length 44 is precisely twice the length of "<!ENTITY a SYSTEM 'b'>"
  // (22) that is used in function accountingGetCurrentAmplification in
  // xmlparse.c.
  //                  1.........1.........1.........1.........1..4 => 44
  const char doc[] = "<!ENTITY % p1 '123456789_123456789_1234567'>";
  const int docLen = (int)sizeof(doc) - 1;
  const float maximumToleratedAmplification = 2.0f;

  struct TestCase {
    int offsetOfThreshold;
    enum XML_Status expectedStatus;
  };

  struct TestCase cases[] = {
      {-2, XML_STATUS_ERROR}, {-1, XML_STATUS_ERROR}, {0, XML_STATUS_ERROR},
      {+1, XML_STATUS_OK},    {+2, XML_STATUS_OK},
  };

  for (size_t i = 0; i < sizeof(cases) / sizeof(cases[0]); i++) {
    const int offsetOfThreshold = cases[i].offsetOfThreshold;
    const enum XML_Status expectedStatus = cases[i].expectedStatus;
    const unsigned long long activationThresholdBytes
        = docLen + offsetOfThreshold;

    set_subtest("offsetOfThreshold=%d, expectedStatus=%d", offsetOfThreshold,
                expectedStatus);

    XML_Parser parser = XML_ParserCreate(NULL);
    assert_true(parser != NULL);

    assert_true(XML_SetBillionLaughsAttackProtectionMaximumAmplification(
                    parser, maximumToleratedAmplification)
                == XML_TRUE);
    assert_true(XML_SetBillionLaughsAttackProtectionActivationThreshold(
                    parser, activationThresholdBytes)
                == XML_TRUE);

    XML_Parser ext_parser = XML_ExternalEntityParserCreate(parser, NULL, NULL);
    assert_true(ext_parser != NULL);

    const enum XML_Status actualStatus
        = _XML_Parse_SINGLE_BYTES(ext_parser, doc, docLen, XML_TRUE);

    assert_true(actualStatus == expectedStatus);
    if (actualStatus != XML_STATUS_OK) {
      assert_true(XML_GetErrorCode(ext_parser)
                  == XML_ERROR_AMPLIFICATION_LIMIT_BREACH);
    }

    XML_ParserFree(ext_parser);
    XML_ParserFree(parser);
  }
}
END_TEST

#endif // XML_GE == 1

void
make_accounting_test_case(Suite *s) {
#if XML_GE == 1
  TCase *tc_accounting = tcase_create("accounting tests");

  suite_add_tcase(s, tc_accounting);

  /* Excluded registration: test_accounting_precision. */
  oriole_register_test(test_billion_laughs_attack_protection_api, "test_billion_laughs_attack_protection_api");
  tcase_add_test(tc_accounting, test_billion_laughs_attack_protection_api);
  /* Excluded registration: test_helper_unsigned_char_to_printable. */
  oriole_register_test(test_amplification_isolated_external_parser, "test_amplification_isolated_external_parser");
  tcase_add_test__ifdef_xml_dtd(tc_accounting,
                                test_amplification_isolated_external_parser);
#else
  UNUSED_P(s);
#endif /* XML_GE == 1 */
}
