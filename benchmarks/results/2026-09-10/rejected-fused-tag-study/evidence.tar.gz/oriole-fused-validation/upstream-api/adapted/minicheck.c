#include <errno.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
/* Miniature re-implementation of the "check" library.

   This is intended to support just enough of check to run the Expat
   tests.  This interface is based entirely on the portion of the
   check library being used.
                            __  __            _
                         ___\ \/ /_ __   __ _| |_
                        / _ \\  /| '_ \ / _` | __|
                       |  __//  \| |_) | (_| | |_
                        \___/_/\_\ .__/ \__,_|\__|
                                 |_| XML parser

   Copyright (c) 2004-2006 Fred L. Drake, Jr. <fdrake@users.sourceforge.net>
   Copyright (c) 2016-2023 Sebastian Pipping <sebastian@pipping.org>
   Copyright (c) 2017      Rhodri James <rhodri@wildebeest.org.uk>
   Copyright (c) 2018      Marco Maggi <marco.maggi-ipsu@poste.it>
   Copyright (c) 2019      David Loffredo <loffredo@steptools.com>
   Copyright (c) 2023-2024 Sony Corporation / Snild Dolkow <snild@sony.com>
   Copyright (c) 2026      Matthew Fernandez <matthew.fernandez@gmail.com>
   Licensed under the MIT license:

   Permission is  hereby granted,  free of charge,  to any  person obtaining
   a  copy  of  this  software   and  associated  documentation  files  (the
   "Software"),  to  deal in  the  Software  without restriction,  including
   without  limitation the  rights  to use,  copy,  modify, merge,  publish,
   distribute, sublicense, and/or sell copies of the Software, and to permit
   persons  to whom  the Software  is  furnished to  do so,  subject to  the
   following conditions:

   The above copyright  notice and this permission notice  shall be included
   in all copies or substantial portions of the Software.

   THE  SOFTWARE  IS  PROVIDED  "AS  IS",  WITHOUT  WARRANTY  OF  ANY  KIND,
   EXPRESS  OR IMPLIED,  INCLUDING  BUT  NOT LIMITED  TO  THE WARRANTIES  OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
   NO EVENT SHALL THE AUTHORS OR  COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
   DAMAGES OR  OTHER LIABILITY, WHETHER  IN AN  ACTION OF CONTRACT,  TORT OR
   OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
   USE OR OTHER DEALINGS IN THE SOFTWARE.

   SPDX-License-Identifier: MIT
*/

#if defined(NDEBUG)
#  undef NDEBUG /* because test suite relies on assert(...) at the moment */
#endif

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <assert.h>
#include <string.h>

#include "internal.h" /* for UNUSED_P only */
#include "minicheck.h"
#include "bridge.h"

Suite *
suite_create(const char *name) {
  Suite *suite = calloc(1, sizeof(Suite));
  if (suite != NULL) {
    suite->name = name;
  }
  return suite;
}

TCase *
tcase_create(const char *name) {
  TCase *tc = calloc(1, sizeof(TCase));
  if (tc != NULL) {
    tc->name = name;
  }
  return tc;
}

void
suite_add_tcase(Suite *suite, TCase *tc) {
  assert(suite != NULL);
  assert(tc != NULL);
  assert(tc->next_tcase == NULL);

  tc->next_tcase = suite->tests;
  suite->tests = tc;
}

void
tcase_add_checked_fixture(TCase *tc, tcase_setup_function setup,
                          tcase_teardown_function teardown) {
  assert(tc != NULL);
  tc->setup = setup;
  tc->teardown = teardown;
}

void
tcase_add_test(TCase *tc, tcase_test_function test) {
  assert(tc != NULL);
  if (tc->allocated == tc->ntests) {
    int nalloc = tc->allocated + 100;
    size_t new_size = sizeof(tcase_test_function) * nalloc;
    tcase_test_function *const new_tests = realloc(tc->tests, new_size);
    assert(new_tests != NULL);
    tc->tests = new_tests;
    tc->allocated = nalloc;
  }
  tc->tests[tc->ntests] = test;
  tc->ntests++;
}

static void
tcase_free(TCase *tc) {
  if (! tc) {
    return;
  }

  free(tc->tests);
  free(tc);
}

static void
suite_free(Suite *suite) {
  if (! suite) {
    return;
  }

  while (suite->tests != NULL) {
    TCase *next = suite->tests->next_tcase;
    tcase_free(suite->tests);
    suite->tests = next;
  }
  free(suite);
}

SRunner *
srunner_create(Suite *suite) {
  SRunner *const runner = calloc(1, sizeof(SRunner));
  if (runner != NULL) {
    runner->suite = suite;
  }
  return runner;
}

static jmp_buf env;

#define SUBTEST_LEN (50) // informative, but not too long
static char const *_check_current_function = NULL;
static char _check_current_subtest[SUBTEST_LEN];
static int _check_current_lineno = -1;
static char const *_check_current_filename = NULL;

void
_check_set_test_info(char const *function, char const *filename, int lineno) {
  _check_current_function = function;
  set_subtest("%s", "");
  _check_current_lineno = lineno;
  _check_current_filename = filename;
}

void
set_subtest(char const *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(_check_current_subtest, SUBTEST_LEN, fmt, ap);
  va_end(ap);
  // replace line feeds with spaces, for nicer error logs
  for (size_t i = 0; i < SUBTEST_LEN; ++i) {
    if (_check_current_subtest[i] == '\n') {
      _check_current_subtest[i] = ' ';
    }
  }
  _check_current_subtest[SUBTEST_LEN - 1] = '\0'; // ensure termination
}

static void
handle_success(int verbosity) {
  if (verbosity >= CK_VERBOSE) {
    printf("PASS: %s\n", _check_current_function);
  }
}

static void
handle_failure(SRunner *runner, int verbosity, const char *context,
               const char *phase_info) {
  runner->nfailures++;
  if (verbosity != CK_SILENT) {
    if (strlen(_check_current_subtest) != 0) {
      phase_info = _check_current_subtest;
    }
    printf("FAIL [%s]: %s (%s at %s:%d)\n", context, _check_current_function,
           phase_info, _check_current_filename, _check_current_lineno);
  }
}

/* Replaces only minicheck's runner. Each test's setup/body/teardown execute in
 * one child; assertion failures terminate that child without a longjmp over
 * live Rust frames. The parent records failures, signals and timeouts. */
void
srunner_run_all(SRunner *runner, const char *context, int verbosity) {
  (void)verbosity;
  for (TCase *tc = runner->suite->tests; tc; tc = tc->next_tcase) {
    for (int i = 0; i < tc->ntests; ++i) {
      const char *name = oriole_test_name(tc->tests[i]);
      if (!oriole_test_enabled(name))
        continue;
      ++runner->nchecks;
      printf("ORIOLE_BEGIN\t%s\t%s\n", context, name);
      fflush(NULL);
      pid_t child = fork();
      if (child < 0) {
        perror("fork");
        exit(2);
      }
      if (child == 0) {
        const char *memory_text = getenv("ORIOLE_MEMORY_MIB");
        rlim_t bytes = (memory_text ? strtoull(memory_text, NULL, 10) : 1024)
                       * 1024ULL * 1024;
        struct rlimit memory = {bytes, bytes};
        struct rlimit core = {0, 0};
        if (setrlimit(RLIMIT_AS, &memory) || setrlimit(RLIMIT_CORE, &core))
          _Exit(101);
        const char *timeout = getenv("ORIOLE_TEST_TIMEOUT");
        alarm(timeout ? (unsigned)atoi(timeout) : 3);
        set_subtest("%s", "");
        if (tc->setup)
          tc->setup();
        tc->tests[i]();
        if (tc->teardown)
          tc->teardown();
        fflush(NULL);
        _Exit(0);
      }
      int status, rss_limited = 0;
      unsigned polls = 0;
      const char *rss_text = getenv("ORIOLE_RSS_MIB");
      unsigned long long rss_limit = (rss_text ? strtoull(rss_text, NULL, 10) : 768) * 1024;
      for (;;) {
        pid_t waited = waitpid(child, &status, WNOHANG);
        if (waited == child)
          break;
        if (waited < 0 && errno != EINTR) {
          perror("waitpid");
          exit(2);
        }
        if (polls++ % 10 == 0) {
          char path[80], line[256];
          snprintf(path, sizeof(path), "/proc/%ld/status", (long)child);
          FILE *usage = fopen(path, "r");
          if (usage) {
            while (fgets(line, sizeof(line), usage)) {
              unsigned long long rss;
              if (sscanf(line, "VmRSS: %llu kB", &rss) == 1 && rss > rss_limit) {
                rss_limited = 1;
                kill(child, SIGKILL);
                break;
              }
            }
            fclose(usage);
          }
        }
        usleep(1000);
      }
      int passed = WIFEXITED(status) && WEXITSTATUS(status) == 0;
      if (!passed)
        ++runner->nfailures;
      printf("ORIOLE_RESULT\t%s\t%s\t%s\t%d\n", context, name,
             passed ? "pass" : rss_limited ? "rss-limit"
             : WIFSIGNALED(status) && WTERMSIG(status) == SIGALRM ? "timeout"
             : WIFSIGNALED(status) ? "signal" : "fail",
             WIFSIGNALED(status) ? WTERMSIG(status) : WEXITSTATUS(status));
      fflush(NULL);
    }
  }
}

void
srunner_summarize(SRunner *runner, int verbosity) {
  if (verbosity != CK_SILENT) {
    int passed = runner->nchecks - runner->nfailures;
    double percentage = ((double)passed) / runner->nchecks;
    int display = (int)(percentage * 100);
    printf("%d%%: Checks: %d, Failed: %d\n", display, runner->nchecks,
           runner->nfailures);
  }
}

void
_fail(const char *file, int line, const char *msg) {
  /* Always print the error message so it isn't lost.  In this case,
     we have a failure, so there's no reason to be quiet about what
     it is.
  */
  _check_current_filename = file;
  _check_current_lineno = line;
  if (msg != NULL) {
    const int has_newline = (msg[strlen(msg) - 1] == '\n');
    fprintf(stderr, "ERROR: %s%s", msg, has_newline ? "" : "\n");
  }
  fprintf(stderr, "ASSERTION: %s at %s:%d\n", _check_current_function, file, line);
  fflush(NULL);
  _Exit(100);
}

int
srunner_ntests_failed(SRunner *runner) {
  assert(runner != NULL);
  return runner->nfailures;
}

void
srunner_free(SRunner *runner) {
  if (! runner) {
    return;
  }

  suite_free(runner->suite);
  free(runner);
}
