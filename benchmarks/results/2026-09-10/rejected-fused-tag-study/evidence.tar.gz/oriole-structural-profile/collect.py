import ctypes, hashlib, json, os, re, subprocess
from pathlib import Path

root = Path('/tmp/oriole-structural-profile')
repo = Path('/home/dev-user/code/oss/oriole')
manifest = repo / 'benchmarks/projects/corpus-manifest.json'
driver = Path('/tmp/oriole-grammar-bench-plain/native-driver')
profiler_root = Path('/home/dev-user/.cache/oriole/profilers/local/usr')
profiler = profiler_root / 'bin/valgrind'
annotator = profiler_root / 'bin/callgrind_annotate'
libraries = {
    'oriole': Path('/tmp/oriole-attlist-capture-reserve/liboriole_expat.so'),
    'expat': Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4'),
}
fixtures = {p['name']: (manifest.parent / next(f['path'] for f in p['files'] if f['role'] == 'input')).resolve() for p in json.loads(manifest.read_text())['projects']}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
environment = {**os.environ, 'VALGRIND_LIB': str(profiler_root / 'libexec/valgrind')}
report = {
    'scope': 'Callgrind instruction counts collected only inside XML_Parse, including its callbacks. Constructor, parser free, file IO and dynamic loader setup are excluded by --toggle-collect=XML_Parse. Each process performs one warmup and one measured parse, both collected; no timing claims from instrumented executions. CPU2, shared host. Native callback-driver functions are separately identifiable for subtraction.',
    'documentation': str(profiler_root / 'share/doc/valgrind/html/cl-manual.html'),
    'hashes_before': {str(p): sha(p) for p in [manifest, driver, profiler, annotator, *libraries.values(), *fixtures.values()]},
    'rows': [],
}
for name, fixture in fixtures.items():
    for namespaces in [False, True]:
        observations = {}
        for label, library in libraries.items():
            stem = f'{name}-ns{int(namespaces)}-{label}'
            output = root / (stem + '.out')
            command = ['taskset', '-c', '2', str(profiler), '--tool=callgrind', '--toggle-collect=XML_Parse', '--callgrind-out-file=' + str(output), str(driver), str(library), str(fixture), '4096', '1'] + (['namespaces'] if namespaces else [])
            result = subprocess.run(command, capture_output=True, text=True, env=environment, timeout=240)
            (root / (stem + '.stdout')).write_text(result.stdout)
            (root / (stem + '.stderr')).write_text(result.stderr)
            assert result.returncode == 0, (stem, result.stderr)
            samples = json.loads(result.stdout)['samples']
            observed = sorted({(s['hash'], s['elements'], s['text_bytes']) for s in samples})
            observations[label] = observed
            text = output.read_text()
            total = int(re.search(r'^summary: (\d+)', text, re.M).group(1))
            assert total > 0, (stem, 'XML_Parse collection did not activate')
            annotated = subprocess.run([str(annotator), '--auto=no', '--threshold=100', '--show-percs=no', str(output)], capture_output=True, text=True, env=environment)
            assert annotated.returncode == 0, annotated.stderr
            (root / (stem + '.txt')).write_text(annotated.stdout)
            functions = []
            for line in annotated.stdout.splitlines():
                match = re.match(r'^\s*([\d,]+)\s+(.+?) \[([^\]]+)\]$', line)
                if match:
                    functions.append({'Ir': int(match.group(1).replace(',', '')), 'function': match.group(2), 'object': match.group(3)})
            row = {'workload': name, 'namespaces': namespaces, 'library': label, 'command': command, 'Ir': total, 'callback_observations': observed, 'functions': functions, 'unparsed_Ir': total - sum(f['Ir'] for f in functions)}
            report['rows'].append(row)
            (root / 'profiles.json').write_text(json.dumps(report, indent=2) + '\n')
            print(stem, total, 'functions', len(functions), 'unparsed', row['unparsed_Ir'], flush=True)
        assert observations['oriole'] == observations['expat'], (name, namespaces, observations)
report['hashes_after'] = {p: sha(Path(p)) for p in report['hashes_before']}
assert report['hashes_before'] == report['hashes_after']
report['status'] = 'passed'
(root / 'profiles.json').write_text(json.dumps(report, indent=2) + '\n')
