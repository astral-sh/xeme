import collections, json, math, re, statistics
from pathlib import Path
root=Path('/tmp/oriole-structural-profile');d=json.loads((root/'profiles.json').read_text());assert d['status']=='passed'

def edges(path):
    names={}; result=[]; caller=None; callee=None; pending=None
    for line in path.read_text().splitlines():
        m=re.match(r'^(c?fn)=\((\d+)\)(?: (.*))?$',line)
        if m:
            ident=int(m.group(2))
            if m.group(3):names[ident]=m.group(3)
            if m.group(1)=='fn':caller=ident
            else:callee=ident
        elif line.startswith('calls='):
            pending=(caller,callee,int(line.split()[0].split('=')[1]))
        elif pending and re.match(r'^[+*\-\d]',line):
            result.append((*pending,int(line.split()[-1])));pending=None
    combined=collections.defaultdict(lambda:[0,0])
    for caller,callee,calls,ir in result:
        key=(names[caller],names[callee]);combined[key][0]+=calls;combined[key][1]+=ir
    return [{'caller':a,'callee':b,'calls':v[0],'inclusive_Ir':v[1]} for (a,b),v in combined.items()]

out=[]
for row in d['rows']:
    if row['library']!='oriole':continue
    stem=f"{row['workload']}-ns{int(row['namespaces'])}-oriole"
    e=edges(root/(stem+'.out'))
    calloc={'malloc','realloc','free','calloc','reallocarray','aligned_alloc','posix_memalign'}
    libc={f['function'].removeprefix('???:') for f in row['functions'] if 'libc.so.6' in f['object']}
    copy={'0x0000000000188c00','0x0000000000189600'}
    changed=True
    while changed:
        changed=False
        for edge in e:
            if edge['caller'] in calloc and edge['callee'] in libc and edge['callee'] not in calloc|copy:
                calloc.add(edge['callee']);changed=True
    groups=collections.defaultdict(int)
    for f in row['functions']:
        name=f['function'];simple=name.removeprefix('???:');obj=f['object']
        if 'native-driver' in obj:group='C callback driver'
        elif simple in copy and 'libc.so.6' in obj:group='libc memcpy/memmove/memset'
        elif '__tls_get_addr' in name:group='TLS resolver'
        elif 'oriole_storage::allocator' in name or 'oriole_storage::tracking' in name or (simple in calloc and 'libc.so.6' in obj):group='Allocator and tracked allocation helpers'
        elif any(x in name for x in ['::consume','::position_at','::position','advance_position','advance_long_position','::raw_len','::account_source','::accounting_bytes','::mark_accounted','::account_entity_bytes']):group='Consumption, positions and input accounting'
        elif 'next_event_inner' in name:group='Core state machine and inlined token parsing'
        elif any(x in name for x in ['oriole_expat::dispatch','oriole_expat::run_events']):group='C event dispatch and event loop'
        elif any(x in name for x in ['::parse_text','::parse_cdata']):group='Character-data scanning'
        elif any(x in name for x in ['append_attribute','expand_attribute','append_lexical_attribute','attribute_space']):group='Attribute expansion and normalization'
        elif 'oriole_storage::string' in name:group='String and Text storage methods'
        elif any(x in name for x in ['oriole::names::','oriole::take_name','scan_token','scan_element_tag','scan_reference','parse_raw_attributes']):group='Token/name scanning and XML character validation'
        elif 'oriole_storage::queue' in name or '::recycling::' in name:group='Event queues and recycling'
        elif '::encoding::' in name or '::lexical::' in name or 'from_utf8' in name:group='Decoding, source buffers and lexical metadata'
        elif 'memchr' in name or 'core::str::pattern' in name:group='Other string searches'
        else:group='Other runtime and grammar'
        groups[group]+=f['Ir']
    ref=next(x for x in d['rows'] if (x['workload'],x['namespaces'],x['library'])==(row['workload'],row['namespaces'],'expat'))
    callback=groups['C callback driver'];refcb=sum(f['Ir'] for f in ref['functions'] if 'native-driver' in f['object'])
    result={'workload':row['workload'],'namespaces':row['namespaces'],'oriole_Ir':row['Ir'],'expat_Ir':ref['Ir'],'total_instruction_ratio':row['Ir']/ref['Ir'],'parser_instruction_ratio_excluding_callback_driver':(row['Ir']-callback)/(ref['Ir']-refcb),'groups':[{'group':k,'Ir':v,'percent_of_XML_Parse':100*v/row['Ir']} for k,v in sorted(groups.items(),key=lambda x:-x[1])], 'copy_callers':sorted([x for x in e if x['callee']=='0x0000000000188c00'],key=lambda x:-x['inclusive_Ir']), 'TLS_callers':sorted([x for x in e if x['callee']=='__tls_get_addr'],key=lambda x:-x['inclusive_Ir']), 'edges':e}
    assert sum(groups.values())==row['Ir']
    out.append(result)
summary={'scope':d['scope'],'method':'Disjoint direct-instruction buckets from callgrind_annotate; inlined callees remain charged to their caller. Core state-machine bucket includes parse-start closure code and is not a pure event-overhead estimate. libc memcpy/memmove addresses resolved from exact pinned libc; allocator private helper names found by libc-only reachability from malloc/realloc/free, excluding copying. Call edges report inclusive instructions in the callee and must not be summed across nested callees. These are instruction counts, not measured cycles.', 'total_instruction_geomean':math.exp(statistics.mean(math.log(x['total_instruction_ratio']) for x in out)),'parser_instruction_geomean_excluding_callback_driver':math.exp(statistics.mean(math.log(x['parser_instruction_ratio_excluding_callback_driver']) for x in out)), 'rows':out}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for x in out:
 print(x['workload'],x['namespaces'],'parser ratio',round(x['parser_instruction_ratio_excluding_callback_driver'],2))
 print([(g['group'],round(g['percent_of_XML_Parse'],2)) for g in x['groups'][:7]])
 print('copy callers',[(c['caller'],round(100*c['inclusive_Ir']/x['oriole_Ir'],2)) for c in x['copy_callers'][:5]])
 print('alloc/TLS',[(g['group'],round(g['percent_of_XML_Parse'],2)) for g in x['groups'] if 'Allocator' in g['group'] or 'TLS' in g['group']])
