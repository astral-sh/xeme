"""Read existing immutable profiles; do not execute either parser."""

import hashlib
import json
from pathlib import Path

DEST = Path(__file__).parent
PROFILES = Path('/tmp/oriole-structural-profile/profiles.json')
SUMMARY = Path('/tmp/oriole-structural-profile/summary.json')
profiles = json.loads(PROFILES.read_text())
summary = json.loads(SUMMARY.read_text())
lookup = {(r['workload'], r['namespaces'], r['library']): r for r in profiles['rows']}


def count(row, names):
    return sum(f['Ir'] for f in row['functions'] if f['function'].removeprefix('???:') in names)


positions = {
    '<oriole::Parser>::consume',
    '<oriole::encoding::Source>::position_at',
    'oriole::encoding::advance_long_position',
}
frame_groups = {
    'C event dispatch and event loop',
    'Event queues and recycling',
    'String and Text storage methods',
    'libc memcpy/memmove/memset',
}
transfer_callers = {
    '<oriole::Parser>::next_event_inner',
    '<oriole::Parser>::next_event_scoped',
    '<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back',
}
rows = []
for sr in summary['rows']:
    key = sr['workload'], sr['namespaces']
    current = lookup[*key, 'oriole']
    reference = lookup[*key, 'expat']
    total = current['Ir']
    position = count(current, positions)
    reference_position = count(reference, {'normal_updatePosition'})
    lexical = next(g['Ir'] for g in sr['groups'] if g['group'] == 'Token/name scanning and XML character validation')
    frames = sum(g['Ir'] for g in sr['groups'] if g['group'] in frame_groups)
    transfers = sum(e['inclusive_Ir'] for e in sr['copy_callers'] if e['caller'] in transfer_callers)
    starts = next(e['calls'] for e in sr['edges'] if e['caller'] == 'oriole_expat::dispatch' and e['callee'] == 'start')
    dispatches = next(e['calls'] for e in sr['edges'] if e['caller'] == 'oriole_expat::run_events' and e['callee'] == 'oriole_expat::dispatch')
    rows.append({
        'workload': key[0], 'namespaces': key[1],
        'oriole_XML_Parse_Ir': total, 'expat_XML_Parse_Ir': reference['Ir'],
        'oriole_consume_and_position_direct_Ir_upper_bound': position,
        'oriole_consume_and_position_percent_upper_bound': position / total * 100,
        'expat_normal_updatePosition_direct_Ir': reference_position,
        'expat_normal_updatePosition_percent': reference_position / reference['Ir'] * 100,
        'oriole_position_bucket_to_expat_position_absolute_Ir_ratio': position / reference_position,
        'hypothetical_speedup_if_all_Oriole_position_bucket_deleted': 1 / (1 - position / total),
        'lexical_bucket_percent_upper_bound': lexical / total * 100,
        'hypothetical_speedup_if_all_lexical_bucket_deleted': 1 / (1 - lexical / total),
        'delivery_storage_copy_bucket_percent_upper_bound': frames / total * 100,
        'direct_event_transfer_copy_percent': transfers / total * 100,
        'start_callbacks': starts,
        'dispatch_calls': dispatches,
        'start_fraction_of_dispatches': starts / dispatches,
    })

result = {
    'method': 'Read-only reclassification of existing XML_Parse Callgrind profiles. Counts include one warmup and one measured parse. Percentages use all XML_Parse Ir including native callback work. No new measurements, instructions are not cycles, upper bounds are not speedup forecasts.',
    'positions_caveat': 'Oriole consume includes required cursor/raw-index/scan-reset/compaction work. Expat position counts are absolute normal_updatePosition self-cost, not an equivalent enclosing wrapper. The native driver never requests line/column. Removing all Oriole position work is impossible.',
    'lexical_caveat': 'The lexical bucket includes end tags, DTD and character-data XML validation and required grammar work. Only a subset belongs to duplicate start-tag passes. A shared lexer still performs necessary scanning.',
    'frame_caveat': 'The broad frame bucket includes all C dispatch, all queues/recycling, all String/Text helpers and all libc copies. Some belongs to source decoding, stack records, raw context or non-start events and remains necessary. Its sum is a disjoint opportunity envelope, not removable overhead. The smaller direct-transfer copy count uses immediate memcpy edges only, with no nested inclusive-edge double counting.',
    'inputs': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [PROFILES, SUMMARY]},
    'rows': rows,
}
(DEST / 'opportunity.json').write_text(json.dumps(result, indent=2) + '\n')
lines = ['| Project | NS | Oriole position upper bound | Expat position Ir | Oriole/Expat position Ir | Lexical upper bound | Delivery/storage/copy upper bound | Event-transfer copies |', '|---|---:|---:|---:|---:|---:|---:|---:|']
for r in rows:
    lines.append(f"| {r['workload']} | {int(r['namespaces'])} | {r['oriole_consume_and_position_percent_upper_bound']:.2f}% | {r['expat_normal_updatePosition_direct_Ir']:,} | {r['oriole_position_bucket_to_expat_position_absolute_Ir_ratio']:.2f}x | {r['lexical_bucket_percent_upper_bound']:.2f}% | {r['delivery_storage_copy_bucket_percent_upper_bound']:.2f}% | {r['direct_event_transfer_copy_percent']:.2f}% |")
(DEST / 'opportunity-table.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'rows': len(rows), 'position_max': max(r['oriole_consume_and_position_percent_upper_bound'] for r in rows), 'lexical_max': max(r['lexical_bucket_percent_upper_bound'] for r in rows), 'delivery_max': max(r['delivery_storage_copy_bucket_percent_upper_bound'] for r in rows)}))
