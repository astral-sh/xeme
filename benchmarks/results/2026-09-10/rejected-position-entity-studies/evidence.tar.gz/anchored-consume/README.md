# Anchored source position study — excluded

This isolated optimization was **excluded from the production candidate**. Skipping unused replacement-text line tracking reduced the target's `XML_Parse` instruction count, but its intended throughput benefit was not confirmed.

| Evidence | Result |
| --- | --- |
| Named internal-entity instructions | 440,756,672 → 425,636,756 (−3.4304%) |
| Vulkan instructions | +0.0708% |
| Named entities, 4 KiB feed | 0.991377× speedup; all five pairs below 1 |
| Named entities, 64 KiB feed | 0.995943× speedup |
| 24 project condition geomean | 1.020038× in one shared-host cohort |
| Scoped Rust/FFI checks | 336 passed |
| Original upstream API | 4,115 passed; 625 existing failures; 0 changes |
| Independent callback probes | 30 conditions × 3 libraries; candidate equals control on all 30 full records |

Speedup is control time divided by candidate time. Values below 1 favor the control. The project summary does not erase the target result. Instruction counts cover `XML_Parse`; native timings also include parser creation, callback setup and destruction. The timing campaign had no frequency or NUMA controls, and retains every sample and outlier.

## Contents

- `summary.json` records the exclusion, exact identities, counts, caveats and omitted binary hashes.
- `source-{control,prototype,tested}.tar.gz` contains each exact 66-file scoped source map. The tested phase adds a compaction regression; both candidate phases produced the same library hash.
- `prototype.patch`, `tested.patch` and `test-only-overlay.patch` preserve each change independently.
- `prototype-records.tar.gz` and `tested-records.tar.gz` preserve build scripts, commands, logs, identities and manifests.
- `profile.tar.gz` preserves native preflights, Callgrind outputs, driver source and the generated named-entity fixture.
- `screen.tar.gz` preserves all 90 preflight and 300 timed process records, their 51,140 timed samples including warmups, generated inputs and report.
- `focused-c-and-independent-reviews.tar.gz` preserves the C API probes via ctypes, all results, audit generators and the original incorrect 36/33 assertion script.
- `upstream-*.tar.gz` preserves API results, logs, source/adapters and the exact baseline comparison.
- `project-inputs.tar.gz` and `timing-driver-provenance.tar.gz` preserve the pinned timing inputs and driver source/build provenance.

The four top-level independent reviews explain the source proof, instruction profile, callback/compaction coverage and timing audit. `manifest.json` hashes every packaged file and archive member. Native binaries and build target directories are omitted.

## Limits and retained failures

The derived Rust `Parser` debug representation can reveal changed private anchored line/column/CR state. Existing Expat text fragmentation, nested position/context presentation, and error metadata gaps remain; exact Expat callback transcripts are not claimed. All 625 original API failures remain. The API runner consequently exits 1 even though its records exactly match the baseline.

The first callback attempt failed in the harness because it expected error 36 after feeding a suspended parser; the correct error is 33. The preserved original script documents that mistake. The corrected three-library matrix completed without callback exceptions. No result file was produced by the initial failed attempt.

Packaging performs file/hash/data checks only. It does not run parsers, rebuild code, repeat timing, or claim a production performance improvement.
