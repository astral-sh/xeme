from pathlib import Path
import collections,difflib,gzip,hashlib,io,json,re,tarfile
prototype=Path('/tmp/oriole-anchored-consume');tested=Path('/tmp/oriole-anchored-consume-tested');review=Path('/tmp/oriole-anchor-position-review');baseline=Path('/tmp/oriole-attlist-9074');out=Path('/tmp/oriole-anchored-consume-handoff');assert not out.exists();out.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); digest=lambda b:hashlib.sha256(b).hexdigest(); archive_members={}; omitted=[]
def regular(f):
 data=f.read_bytes()
 assert not data.startswith((b'\x7fELF',b'!<arch>')) and f.suffix not in ('.so','.a','.o'),f
 return data

def archive(name,files):
 members=[];content=io.BytesIO()
 with tarfile.open(fileobj=content,mode='w',format=tarfile.PAX_FORMAT) as tar:
  for arc,f in sorted(files.items()):
   data=regular(f);info=tarfile.TarInfo(arc);info.size=len(data);info.mtime=0;info.mode=0o644;info.uid=info.gid=0;tar.addfile(info,io.BytesIO(data));members.append({'path':arc,'bytes':len(data),'sha256':digest(data),'original_path':str(f)})
 (out/name).write_bytes(gzip.compress(content.getvalue(),compresslevel=9,mtime=0));archive_members[name]=members

def select_dir(root,exclude=()):return {str(f.relative_to(root)):f for f in root.rglob('*') if f.is_file() and str(f.relative_to(root)) not in exclude}

def source(root,name):
 m=json.loads((root/'source.json').read_text())
 for f,h in m['files'].items():assert sha(root/f)==h,(root,f)
 archive(name,{f:root/f for f in m['files']});return m
pm=source(prototype,'source-prototype.tar.gz');tm=source(tested,'source-tested.tar.gz');bm=source(baseline,'source-control.tar.gz')
assert len(pm['files'])==len(tm['files'])==len(bm['files'])==66
for root,label in [(prototype,'prototype'),(tested,'tested')]:
 files={f.name:f for f in root.iterdir() if f.is_file() and f.suffix in ('.json','.log','.py','.patch')}
 archive(label+'-records.tar.gz',files)
 for f in root.glob('*.so'):omitted.append({'path':str(f),'sha256':sha(f),'reason':'Native binary excluded; identity retained.'})
archive('profile.tar.gz',select_dir(prototype/'profile',('native-driver',)))
omitted.append({'path':str(prototype/'profile/native-driver'),'sha256':sha(prototype/'profile/native-driver'),'reason':'Compiled driver excluded; C source and build command retained.'})
archive('screen.tar.gz',select_dir(tested/'screen'))
archive('focused-c-and-independent-reviews.tar.gz',select_dir(review))
archive('upstream-api.tar.gz',select_dir(tested/'upstream-api',('runtests','liboriole_expat.so')))
for f in ['runtests','liboriole_expat.so']:omitted.append({'path':str(tested/'upstream-api'/f),'sha256':sha(tested/'upstream-api'/f),'reason':'Native binary excluded; API manifest retains its identity.'})
api=json.loads((tested/'upstream-api/results.json').read_text());prev=json.loads((baseline/'upstream-api/results.json').read_text());assert api==prev
assert len(api['results'])==4740 and api['selection_complete'] and api['library_origin_verified'] and not api['timed_out']
counts=dict(collections.Counter(x['outcome'] for x in api['results']));assert counts=={'pass':4115,'fail':625}
assert len({(x['test'],x['context']) for x in api['results']})==4740
api_manifest=json.loads((tested/'upstream-api/manifest.json').read_text())
for f,h in api_manifest['adapted_sources'].items():assert sha(tested/'upstream-api/adapted'/f)==h
for f,h in api_manifest['upstream_include_sources'].items():assert sha(tested/'upstream-api'/f)==h
api_toolroot=Path('/tmp/oriole-deep-profile-experiment/inherited/frozen-source/tools/upstream-expat')
for f,h in api_manifest['adapter_sources'].items():assert sha(api_toolroot/f)==h
archive('upstream-runner-sources.tar.gz',{**{f:api_toolroot/f for f in api_manifest['adapter_sources']},'run_clean.py':Path('/tmp/oriole-deep-profile-experiment/inherited/run_clean.py')})
archive('upstream-control-records.tar.gz',{'results.json':baseline/'upstream-api/results.json','manifest.json':baseline/'upstream-api/manifest.json','tests.log':baseline/'upstream-api/tests.log','source.json':baseline/'source.json','binary.json':baseline/'binary.json'})
corpus=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');projectfiles={'corpus-manifest.json':corpus}
for project in json.loads(corpus.read_text())['projects']:
 f=next(f for f in project['files'] if f['role']=='input');p=(corpus.parent/f['path']).resolve();assert sha(p)==f['sha256'];projectfiles[f['path']]=p
archive('project-inputs.tar.gz',projectfiles)
archive('timing-driver-provenance.tar.gz',{'native_driver.c':Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c'),'historical-summary.json':Path('/tmp/oriole-grammar-bench-plain/summary.json')})
omitted.append({'path':'/tmp/oriole-grammar-bench-plain/native-driver','sha256':sha('/tmp/oriole-grammar-bench-plain/native-driver'),'reason':'Compiled native timing driver excluded; historical source/build identity retained.'})
# Add uncompressed, small review entry points without changing the original records.
for name,src in [('prototype.patch',prototype/'candidate.patch'),('tested.patch',tested/'candidate.patch'),('source-prototype.json',prototype/'source.json'),('source-tested.json',tested/'source.json'),('source-control.json',baseline/'source.json'),('independent-proof.json',review/'independent-proof.json'),('independent-profile-review.json',review/'independent-profile-review.json'),('independent-callback-review.json',review/'independent-callback-review.json'),('independent-screen-review.json',review/'independent-screen-review.json')]: (out/name).write_bytes(src.read_bytes())
proto_source=(prototype/'crates/oriole/src/encoding.rs').read_text();tested_source=(tested/'crates/oriole/src/encoding.rs').read_text();assert proto_source.split('#[cfg(test)]')[0]==tested_source.split('#[cfg(test)]')[0]
(out/'test-only-overlay.patch').write_text(''.join(difflib.unified_diff(proto_source.splitlines(keepends=True),tested_source.splitlines(keepends=True),fromfile='a/crates/oriole/src/encoding.rs',tofile='b/crates/oriole/src/encoding.rs')))
checks=sum(map(int,re.findall(r'test result: ok\. (\d+) passed;', (tested/'test.log').read_text())));assert checks==336
for root,lognames in [(prototype,['fmt.log','build.log']),(tested,['fmt.log','test.log','clippy.log','build.log'])]:
 rows=json.loads((root/'build-commands.json').read_text())['rows'];assert len(rows)==len(lognames)
 for row,log in zip(rows,lognames):assert row['exit_code']==0 and sha(root/log)==row['log_sha256']
command=json.loads((tested/'upstream-api-command.json').read_text());assert command['exit_code']==1 and command['log_sha256']==sha(tested/'upstream-api.log')
for root in (prototype,tested):assert sha(root/'liboriole_expat.so')=='923821e4733c5671a9b3ae1e693415d396e60171fc861c475ee7f9a27183fa62'
summary={
 'decision':'EXCLUDED from the production candidate by root decision. Evidence is preserved as an isolated study; no recommendation to integrate this patch.',
 'reason':'The intended internal-entity throughput benefit was not confirmed: speedups control/candidate are 0.991377 at 4 KiB and 0.995943 at 64 KiB; all five 4 KiB pairs are below 1. The bounded XML_Parse instruction reduction does not establish a wall-clock benefit.',
 'source_phases':{'control':{'manifest_sha256':sha(baseline/'source.json'),'library_sha256':sha(baseline/'liboriole_expat.so'),'files':66},'prototype':{'manifest_sha256':sha(prototype/'source.json'),'patch_sha256':sha(prototype/'candidate.patch'),'library_sha256':sha(prototype/'liboriole_expat.so'),'files':66},'tested':{'manifest_sha256':sha(tested/'source.json'),'patch_sha256':sha(tested/'candidate.patch'),'library_sha256':sha(tested/'liboriole_expat.so'),'files':66,'runtime_identical_to_prototype':True,'only_additional_source_change':'Source-level anchored/unanchored compaction regression'}},
 'implementation':'Guard only advance_position and its text slice with anchor.is_none(); raw byte accounting, source cursor, deferred scanner state and compaction stay unchanged. Permanently anchored sources preserve full reference positions.',
 'instruction_profile':{'collection':'Ir inside XML_Parse, including parser callbacks, both warmup and measured parse iterations; constructor/free outside XML_Parse excluded. One profile per engine/workload.','named_internal_entities':{'control':440756672,'candidate':425636756,'change_percent':-3.430445177696595},'vulkan':{'control':1339775936,'candidate':1340724800,'change_percent':0.07082258865112045}},
 'timing':{'scope':'Single randomized shared-host CPU 0 cohort; native constructor/callback setup/parse/callback hashing/free timing. Input/library loading and process startup excluded. No frequency or NUMA controls.','conditions':30,'project_conditions':24,'generated_conditions':6,'pairs':150,'preflight_processes':90,'timed_processes':300,'timed_samples_including_warmup':51140,'project_condition_geomean_speedup':1.020038020639466,'named_internal_entities_4096_median_speedup':0.9913772105199169,'named_internal_entities_65536_median_speedup':0.9959425057043647,'definition':'speedup = control median time / candidate median time; above 1 favors candidate','no_outlier_exclusion':True},
 'correctness':{'parent_scoped_checks':checks,'fmt_clippy_release_logs_verified':True,'original_upstream_records':4740,'upstream_outcomes':counts,'upstream_timed_out':False,'upstream_exact_control_record_differences':0,'upstream_exit_code':1,'upstream_exit_explanation':'625 existing failed configurations remain; full suite is not passing.','upstream_scope':'395 public tests x 6 chunk sizes x 2 deferral values; private implementation tests excluded; 3 seconds/record and 1 GiB address-space limit. Requested 768 MiB RSS bound is not a reliable Linux enforcement mechanism.','independent_callback_engine_cases':90,'candidate_control_cases':30,'candidate_control_full_record_differences':0,'per_oriole_library_parse_control_calls':133647,'per_oriole_library_callback_context_records':411,'source_compaction_test_reviewed':True},
 'negative_and_retained_findings':['Target throughput unconfirmed and all five 4 KiB named-entity pairs regress.', 'Public Parser derived Debug can expose changed private anchored line/column/previous_cr state, despite parse position APIs retaining the anchor.', 'Actual Expat callback fragmentation, nested column/raw-context presentation, and six error metadata differences remain pre-existing in control and candidate. Full reference callback trace equivalence is not claimed.', 'Initial first control callback probe incorrectly expected XML_ERROR_FINISHED (36) after a suspended feed. Correct behavior was XML_ERROR_SUSPENDED (33); harness stopped before writing a result file. Original script retained; only this assertion changed before all three complete runs.', '625 original upstream configuration failures remain unchanged.', 'Native throughput screen has shared-host noise and a batik pair speedup of 1.78818; all data retained. Instruction-count and wall-clock scopes differ.'],
 'packaging':'File-only independent packaging on CPU 2; no new parser executions, native profiles, benchmarks, Cargo or Git writes. Compiled binaries and target directories excluded. Source phases, patches, generators, raw results/logs, inputs, API adapters and independent reviews retained. Absolute paths in historical reports identify original artifacts; archive member hashes map packaged copies.',
 'omitted_native_binaries':omitted
}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'README.md').write_text('''# Anchored source position study — excluded

This isolated optimization was **excluded from the production candidate**. Skipping unused replacement-text line tracking reduced the target's `XML_Parse` instruction count, but its intended throughput benefit was not confirmed.

| Evidence | Result |
| --- | --- |
| Named internal-entity instructions | 440,756,672 → 425,636,756 (−3.4304%) |
| Vulkan instructions | +0.0708% |
| Named entities, 4 KiB feed | 0.991377× speedup; all five pairs below 1 |
| Named entities, 64 KiB feed | 0.995943× speedup |
| 24 project condition geomean | 1.020038× in one shared-host cohort |
| Scoped Rust/FFI checks | 336 passed |
| Original upstream API | 4,115 passed; 625 existing failures; 0 changes |
| Independent callback probes | 30 conditions × 3 libraries; candidate equals control on all 30 full records |

Speedup is control time divided by candidate time. Values below 1 favor the control. The project summary does not erase the target result. Instruction counts cover `XML_Parse`; native timings also include parser creation, callback setup and destruction. The timing campaign had no frequency or NUMA controls, and retains every sample and outlier.

## Contents

- `summary.json` records the exclusion, exact identities, counts, caveats and omitted binary hashes.
- `source-{control,prototype,tested}.tar.gz` contains each exact 66-file scoped source map. The tested phase adds a compaction regression; both candidate phases produced the same library hash.
- `prototype.patch`, `tested.patch` and `test-only-overlay.patch` preserve each change independently.
- `prototype-records.tar.gz` and `tested-records.tar.gz` preserve build scripts, commands, logs, identities and manifests.
- `profile.tar.gz` preserves native preflights, Callgrind outputs, driver source and the generated named-entity fixture.
- `screen.tar.gz` preserves all 90 preflight and 300 timed process records, their 51,140 timed samples including warmups, generated inputs and report.
- `focused-c-and-independent-reviews.tar.gz` preserves the C API probes via ctypes, all results, audit generators and the original incorrect 36/33 assertion script.
- `upstream-*.tar.gz` preserves API results, logs, source/adapters and the exact baseline comparison.
- `project-inputs.tar.gz` and `timing-driver-provenance.tar.gz` preserve the pinned timing inputs and driver source/build provenance.

The four top-level independent reviews explain the source proof, instruction profile, callback/compaction coverage and timing audit. `manifest.json` hashes every packaged file and archive member. Native binaries and build target directories are omitted.

## Limits and retained failures

The derived Rust `Parser` debug representation can reveal changed private anchored line/column/CR state. Existing Expat text fragmentation, nested position/context presentation, and error metadata gaps remain; exact Expat callback transcripts are not claimed. All 625 original API failures remain. The API runner consequently exits 1 even though its records exactly match the baseline.

The first callback attempt failed in the harness because it expected error 36 after feeding a suspended parser; the correct error is 33. The preserved original script documents that mistake. The corrected three-library matrix completed without callback exceptions. No result file was produced by the initial failed attempt.

Packaging performs file/hash/data checks only. It does not run parsers, rebuild code, repeat timing, or claim a production performance improvement.
''')
(out/'package-excluded-study.py').write_bytes(Path(__file__).read_bytes())
entries=[]
for f in sorted(out.iterdir()):
 entry={'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f)}
 if f.name in archive_members:entry['archive_members']=archive_members[f.name]
 entries.append(entry)
manifest={'decision':'excluded','entry_count':len(entries),'archive_count':len(archive_members),'total_bytes_excluding_manifest':sum(x['bytes'] for x in entries),'entries':entries}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Final byte-level integrity, regular-file-only and no native binary content audit.
for entry in entries:
 f=out/entry['path'];assert f.stat().st_size==entry['bytes'] and sha(f)==entry['sha256']
 if 'archive_members' in entry:
  with tarfile.open(f,'r:gz') as tar:
   actual=tar.getmembers();assert len(actual)==len(entry['archive_members'])
   for info,expected in zip(actual,entry['archive_members']):
    assert info.isfile() and info.name==expected['path'] and not info.name.startswith('/') and '..' not in Path(info.name).parts
    data=tar.extractfile(info).read();assert len(data)==expected['bytes'] and digest(data)==expected['sha256'];assert not data.startswith((b'\x7fELF',b'!<arch>'))
print(json.dumps({'path':str(out),'manifest_sha256':sha(out/'manifest.json'),'entry_count':len(entries),'archive_count':len(archive_members),'archive_member_count':sum(map(len,archive_members.values())),'total_bytes_excluding_manifest':manifest['total_bytes_excluding_manifest'],'decision':'excluded'},indent=2))
