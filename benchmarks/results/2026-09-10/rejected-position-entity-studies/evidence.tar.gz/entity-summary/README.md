# Entity declaration payload study — rejected

## Decision

Keep the current runtime. Avoiding unused entity payloads reduced selected allocation calls and generated declaration work, but did not improve real-project throughput or any original API assertion. The added event variant and adapter handler state do not earn their complexity on this evidence.

The final paired project geomean was **0.99839×**, with **10/24** conditions faster. Individual project geomeans: Vulkan 0.99642×, Wayland 0.98975×, Maven 1.01346×, Batik 0.99307×, GTK 1.00694×, DocBook 0.99095×. Generated declarations improved 1.04193× at 4 KiB and 1.01609× at 64 KiB; generated entity expansion was 0.98952× and 1.00311×. These are candidate/control ratios, not comparisons with Expat.

## Candidate and source identity

The baseline is the frozen combined lazy-buffer source atop the output-slot/353dc3f layer. It excludes the newer root streaming ATTLIST layer. `baseline.json` records attribution; `control-source.tar.gz` and `control.so` are immutable.

The candidate suppresses semantic EntityDeclaration payload creation only when entity/unparsed/default handlers are absent and no earlier pending callback can enable one. A small summary event preserves the declaration boundary, raw snapshot, positions, input context and original callback/base work charges. The default Rust owned-event API retains full payloads. External child and reset handler state is propagated explicitly. Fields remain owned under the selected allocator. No core references cross C callbacks. EventKind remains 120 bytes and Event/Option<Event> remain 152 bytes.

The initial `85898dd2` library moved raw-spelling-sized value buffers into the semantic table. Numeric references exposed a retained-memory regression: 16 values of 1,025 decoded characters retained 347,526 selected bytes versus 281,942 in the baseline. That candidate was not timed. All original source, libraries, raw memory output and earlier gates remain in this directory.

The repaired `compact/44f1d441` library compares each field capacity with the previous exact clone's bound (empty zero, otherwise checked len+1). Oversized owners are cloned fallibly; compact owners are moved. All four numeric-reference cases now retain exactly baseline bytes, with lower measured peaks. No source files changed after the repaired freeze. `compact/documentation-only.patch` only restores the existing invalid_dtd_token comment to its proper function and is separate from the measured source.

## Validation

The repaired source passes 331 Rust tests, strict Clippy and formatting. All 4,740 original upstream API configuration result rows are exactly unchanged: 4,311 pass and 429 fail. Selection is complete and library origin verified; no original assertion was waived or changed.

Exact differential: 1,518 cases, no differences. Custom encodings: 36,456 comparisons, no differences. Handler/input-context probes cover 240 two-generation conditions per library, XML_Parse/ParseBuffer, UTF-8/UTF-16, five chunk sizes, handler switches, stop/resume, XML_DefaultCurrent and reset. Separate custom-conversion and child-handler probes cover enabling/disabling declarations before and after conversion, parent reset, child inheritance and rejected child reset.

Six dynamic/static C ASan/UBSan runs pass, including 324 selected allocation-failure scenarios per linkage. Rust is an optimized release build, not sanitizer-instrumented; LeakSanitizer is disabled for the sandbox. A separate numeric-reference C sweep fails every selected allocation for decoded widths 1, 13 and 1,025, exercising the new compact clone through XML_Parse, ParseBuffer, nested parser suites, reset, poison/free ownership and zero live blocks. All six control/candidate runs pass: 336/327, 336/327 and 342/333 cutoffs. Initial pre-compaction native C compilation briefly had an unpinned compiler parent; that oversight was recorded before this timing cohort. Every repaired native parent/compiler/runtime was pinned to CPU2.

Selected allocation attribution (minimal fixture handlers, not a claim of exact upstream retry-loop workload): long entity value 57→51 mallocs, long notation 65→58, long namespace fixture 89→86. Original upstream retry ceilings remain failed. All selected live bytes return to zero after parser free.

## Measurement

`compact/screening.py` runs all 28 conditions' semantic preflights before timing (56 processes), then five randomized two-engine blocks (280 processes). It uses all six pinned project inputs, 4 KiB and 64 KiB feeds, both namespace modes, plus generated declarations and entity expansion. CPU0 contains the parent and every child. Fixed measured parses per process are Vulkan 7, Wayland 64, Maven 128, Batik 512, GTK 256, DocBook 256, and generated 32, plus one warmup. Per-process medians feed paired block ratios; reported condition speedups are their medians. All raw samples are retained, without outlier filtering. Library/input/driver hashes and callback hash/counts agree before and after. Shared host noise remains possible. This is native callback-driver throughput, not actual application process timing.

Callgrind on repaired candidate/control: generated declarations 136,946,609→130,211,438 instructions (-4.92%); Vulkan 1,350,412,650→1,350,925,461 (+0.038%); Wayland 30,049,568→30,052,838 (+0.011%). Scope includes XML_Parse warmup and one measured parse with driver callbacks, excluding loader, construction, free and input IO. Instruction counts are not cycle or timing measurements. The declaration-only benefit agrees with throughput, while common parsing remains essentially unchanged.

## Evidence and review scope

`handoff.json` records exact source/library identities, counts and disposition. `compact/source.json` matches all 65 current source files. `compact/source.tar.gz`, `compact/candidate.patch`, all raw probe outputs, complete original API results, Callgrind files and raw benchmark samples remain available. Top-level artifacts retain the initial regression and its tests.

Root's preliminary source review of the initial patch found accounting/base charging and owned table insertion sound; requested callback-conversion, child/reset, raw-context and layout controls were added. Root approved the compact-on-move correction in principle and agreed to reject the runtime after timing. No independent formal final-code review or independent test execution is claimed. No candidate runtime was applied to the shared root checkout.
