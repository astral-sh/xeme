from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).parent;probe=Path('/tmp/oriole-allocation-followup/profile');fixtures=json.loads(Path('/tmp/oriole-allocation-followup/fixtures.json').read_text())
rows=[]
for label,library in [('control',r.parent/'control.so'),('candidate',r/'liboriole_expat.so')]:
 for name in ['test_alloc_long_entity_value','test_alloc_long_notation','test_nsalloc_realloc_long_context']:
  fixture=fixtures[name]
  for chunk in [0,1]:
   command=['taskset','-c','2',str(probe),str(library),fixture['input'],str(chunk),str(int(fixture['namespaces']))];p=subprocess.run(command,capture_output=True,text=True,timeout=30);assert p.returncode==0,(command,p.stderr)
   path=r/(name+'-'+label+'-'+str(chunk)+'.jsonl');path.write_text(p.stdout);x=json.loads(p.stdout.splitlines()[0]);assert x['after_free_live']==0,x;x.update(variant=label,fixture=name,chunk=chunk,command=command,library_sha256=hashlib.sha256(library.read_bytes()).hexdigest(),raw=str(path));rows.append(x)
for name in ['test_alloc_long_entity_value','test_alloc_long_notation','test_nsalloc_realloc_long_context']:
 for chunk in [0,1]:
  pair=[x for x in rows if x['fixture']==name and x['chunk']==chunk];assert (pair[0]['status'],pair[0]['error'])==(pair[1]['status'],pair[1]['error']);print(name,chunk,[(x['variant'],x['malloc'],x['realloc'],x['peak_live']) for x in pair])
(r/'allocations.json').write_text(json.dumps({'scope':'Selected-suite allocation count/peak attribution, not timing. Same minimal fixture handler setup and external child feeds as lazy-buffer investigation; all selected live blocks return to zero.','driver_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'rows':rows},indent=2)+'\n')
