from pathlib import Path
import ctypes as c,json,hashlib,sys,itertools
sys.path.insert(0,'/home/dev-user/code/oss/oriole/tools')
from xml_abi import Expat,P,S,I,TEXT
r=Path(__file__).parent;ENTITY=c.CFUNCTYPE(None,P,S,I,P,I,S,S,S,S);UNPARSED=c.CFUNCTYPE(None,P,S,S,S,S,S);CONVERT=c.CFUNCTYPE(I,P,P);RELEASE=c.CFUNCTYPE(None,P)
class Encoding(c.Structure):_fields_=[('map',I*256),('data',P),('convert',CONVERT),('release',RELEASE)]
UNKNOWN=c.CFUNCTYPE(I,P,S,c.POINTER(Encoding))
reports={}
for label,library in [('control',r.parent/'control.so'),('candidate',r/'liboriole_expat.so')]:
 lib=Expat(str(library)).lib
 for name,result,args in [('XML_SetUnknownEncodingHandler',None,[P,UNKNOWN,P]),('XML_SetEntityDeclHandler',None,[P,ENTITY]),('XML_SetUnparsedEntityDeclHandler',None,[P,UNPARSED]),('XML_SetDefaultHandlerExpand',None,[P,TEXT]),('XML_DefaultCurrent',None,[P]),('XML_GetInputContext',P,[P,c.POINTER(I),c.POINTER(I)]),('XML_GetCurrentByteCount',I,[P]),('XML_ParserReset',c.c_ubyte,[P,S]),('XML_ExternalEntityParserCreate',P,[P,S,S])]:
  f=getattr(lib,name);f.restype=result;f.argtypes=args
 rows=[]
 for after,action,chunk in itertools.product([False,True],range(3),[1,2,5,4096]):
  comment=b'<!--\x80x-->';first=b"<!ENTITY e 'one'>";body=(first+comment if after else comment+first)+b"<!ENTITY f 'two'>";data=b'<!DOCTYPE r ['+body+b']><r>&e;&f;</r>';parser=lib.XML_ParserCreate(b'custom');events=[];errors=[]
  def position():return [lib.XML_GetCurrentByteIndex(parser),lib.XML_GetCurrentByteCount(parser),lib.XML_GetCurrentLineNumber(parser),lib.XML_GetCurrentColumnNumber(parser)]
  def protect(fn,fallback=None):
   def guarded(*args):
    try:return fn(*args)
    except BaseException as error:errors.append(repr(error));return fallback
   return guarded
  def entity(_,name,parameter,value,length,base,system,public,notation):events.append(['entity',name.decode(),c.string_at(value,length).decode() if value else None,position()])
  def default(_,value,length):events.append(['default',c.string_at(value,length).decode(),position()])
  def convert(_,value):
   offset=I();size=I();context=lib.XML_GetInputContext(parser,c.byref(offset),c.byref(size));events.append(['convert',position(),c.string_at(context,size.value).hex() if context else None,offset.value])
   if action==0:lib.XML_SetEntityDeclHandler(parser,callbacks['entity'])
   elif action==1:lib.XML_SetEntityDeclHandler(parser,ENTITY())
   else:lib.XML_SetDefaultHandlerExpand(parser,callbacks['default']);lib.XML_DefaultCurrent(parser)
   return ord('X')
  def unknown(_,name,info):
   for i in range(256):info.contents.map[i]=i if i<128 else -1
   info.contents.map[128]=-2;info.contents.convert=callbacks['convert'];return 1
  callbacks={'entity':ENTITY(protect(entity)),'default':TEXT(protect(default)),'convert':CONVERT(protect(convert,-1)),'unknown':UNKNOWN(protect(unknown,0))}
  try:
   lib.XML_SetUnknownEncodingHandler(parser,callbacks['unknown'],None)
   if action==1:lib.XML_SetEntityDeclHandler(parser,callbacks['entity'])
   statuses=[]
   for start in range(0,len(data),chunk):
    piece=data[start:start+chunk];status=lib.XML_Parse(parser,piece,len(piece),int(start+chunk>=len(data)));statuses.append([status,lib.XML_GetErrorCode(parser),position()]);assert status==1,(label,after,action,chunk,errors,statuses)
   assert not errors,errors;rows.append({'after':after,'action':action,'chunk':chunk,'events':events,'statuses':statuses})
  finally:lib.XML_ParserFree(parser)
 child_rows=[]
 for entity_enabled,unparsed_enabled in itertools.product([False,True],repeat=2):
  parent=lib.XML_ParserCreate(None);events=[];active=parent
  entity=ENTITY(lambda _,name,*args:events.append(['entity',name.decode()]))
  unparsed=UNPARSED(lambda _,name,*args:events.append(['unparsed',name.decode()]))
  if entity_enabled:lib.XML_SetEntityDeclHandler(parent,entity)
  if unparsed_enabled:lib.XML_SetUnparsedEntityDeclHandler(parent,unparsed)
  old=lib.XML_ExternalEntityParserCreate(parent,None,None);assert old
  try:
   assert lib.XML_ParserReset(parent,None)==1
   fresh=lib.XML_ExternalEntityParserCreate(parent,None,None);assert fresh
   try:
    data=b"<!ENTITY e 'value'><!NOTATION n SYSTEM 'n'><!ENTITY u SYSTEM 'u' NDATA n>"
    observed=[]
    for parser in [old,fresh]:
     assert lib.XML_ParserReset(parser,None)==0
     events.clear();assert lib.XML_Parse(parser,data,len(data),1)==1;observed.append(list(events))
    expected=([['entity','e']] if entity_enabled else [])+([['unparsed','u']] if unparsed_enabled else ([['entity','u']] if entity_enabled else []))
    assert observed==[expected,[]],(entity_enabled,unparsed_enabled,observed,expected)
    child_rows.append({'entity':entity_enabled,'unparsed':unparsed_enabled,'events':observed})
   finally:lib.XML_ParserFree(fresh)
  finally:lib.XML_ParserFree(old);lib.XML_ParserFree(parent)
 reports[label]={'library_sha256':hashlib.sha256(library.read_bytes()).hexdigest(),'conversion_rows':rows,'child_rows':child_rows};print(label,len(rows),len(child_rows),flush=True)
assert reports['control']['conversion_rows']==reports['candidate']['conversion_rows']
assert reports['control']['child_rows']==reports['candidate']['child_rows']
(r/'conversion-probe.json').write_text(json.dumps({'status':'passed','scope':'24 custom conversion conditions per library: converter before/after first entity declaration enables/disables entity handler or enables default+DefaultCurrent. Four chunks, exact callbacks/context/positions. Four child handler combinations per library verify old-child inheritance, parent reset clearing flags, fresh-child defaults and rejected child Reset.','reports':reports},indent=2)+'\n')
print('all conversion and child cases exact')
