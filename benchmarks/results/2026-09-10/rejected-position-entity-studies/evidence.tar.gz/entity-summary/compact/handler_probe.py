from pathlib import Path
import ctypes as c,json,hashlib,sys,itertools
sys.path.insert(0,'/home/dev-user/code/oss/oriole/tools')
from xml_abi import Expat,P,S,I,START,END,TEXT
r=Path(__file__).parent
ENTITY=c.CFUNCTYPE(None,P,S,I,P,I,S,S,S,S)
UNPARSED=c.CFUNCTYPE(None,P,S,S,S,S,S)
xml="<!DOCTYPE r [<!--switch--><!ENTITY e 'hé&#10;llo'><!ENTITY ext SYSTEM 'x'><!NOTATION n SYSTEM 'n'><!ENTITY u SYSTEM 'u' NDATA n>]><r>&e;</r>"
results={}
for label,library in [('control',r.parent/'control.so'),('candidate',r/'liboriole_expat.so')]:
 lib=Expat(str(library)).lib
 for name,result,args in [('XML_SetEntityDeclHandler',None,[P,ENTITY]),('XML_SetUnparsedEntityDeclHandler',None,[P,UNPARSED]),('XML_SetDefaultHandlerExpand',None,[P,TEXT]),('XML_DefaultCurrent',None,[P]),('XML_StopParser',I,[P,c.c_ubyte]),('XML_ResumeParser',I,[P]),('XML_GetInputContext',P,[P,c.POINTER(I),c.POINTER(I)]),('XML_GetCurrentByteCount',I,[P]),('XML_ParserReset',c.c_ubyte,[P,S]),('XML_GetBuffer',P,[P,I]),('XML_ParseBuffer',I,[P,I,I])]:
  f=getattr(lib,name);f.restype=result;f.argtypes=args
 rows=[]
 for mode,utf16,chunk,buffered in itertools.product(range(12),[False,True],[1,2,5,17,4096],[False,True]):
  data=xml.encode('utf-16') if utf16 else xml.encode();parser=lib.XML_ParserCreate(None);events=[];errors=[];suspended=False;in_default=False
  def pos():return [lib.XML_GetCurrentByteIndex(parser),lib.XML_GetCurrentByteCount(parser),lib.XML_GetCurrentLineNumber(parser),lib.XML_GetCurrentColumnNumber(parser)]
  def record(kind,*values):
   offset=I(-1);size=I(-1);context=lib.XML_GetInputContext(parser,c.byref(offset),c.byref(size));position=pos()
   raw=None
   if context and position[0]>=0:
    raw=c.string_at(context+offset.value,position[1]).hex()
    assert raw==data[position[0]:position[0]+position[1]].hex(),(kind,position,raw)
   events.append([kind,*values,position,raw])
  def protect(fn):
   def guarded(*args):
    try:fn(*args)
    except BaseException as e:errors.append(repr(e))
   return guarded
  def on_entity(_,name,parameter,value,length,base,system,public,notation):
   record('entity',name.decode(),parameter,c.string_at(value,length).decode() if value else None,system.decode() if system else None,public.decode() if public else None,notation.decode() if notation else None)
   if mode==9:lib.XML_SetEntityDeclHandler(parser,ENTITY());lib.XML_SetUnparsedEntityDeclHandler(parser,callbacks['unparsed'])
  def on_unparsed(_,name,base,system,public,notation):record('unparsed',name.decode(),system.decode() if system else None,notation.decode())
  def on_default(_,value,length):record('default',c.string_at(value,length).decode())
  def on_comment(_,text):
   nonlocal_dummy=None
   global suspended
   record('comment',text.decode())
   if mode==4:lib.XML_SetEntityDeclHandler(parser,callbacks['entity'])
   elif mode==5:lib.XML_SetEntityDeclHandler(parser,ENTITY())
   elif mode==6:lib.XML_SetUnparsedEntityDeclHandler(parser,callbacks['unparsed'])
   elif mode==8:
    assert lib.XML_StopParser(parser,1)==1;suspended=True
   elif mode==10:lib.XML_SetEntityDeclHandler(parser,ENTITY())
   elif mode==11:lib.XML_SetUnparsedEntityDeclHandler(parser,UNPARSED())
  def on_text(_,value,length):
   record('text',c.string_at(value,length).decode())
   if mode==7:lib.XML_SetDefaultHandlerExpand(parser,callbacks['default']);lib.XML_DefaultCurrent(parser)
  callbacks={'entity':ENTITY(protect(on_entity)),'unparsed':UNPARSED(protect(on_unparsed)),'default':TEXT(protect(on_default)),'comment':END(protect(on_comment)),'text':TEXT(protect(on_text)),'start':START(protect(lambda _,name,attrs:record('start',name.decode()))),'end':END(protect(lambda _,name:record('end',name.decode())))}
  def configure(initial):
   lib.XML_SetElementHandler(parser,callbacks['start'],callbacks['end']);lib.XML_SetCharacterDataHandler(parser,callbacks['text']);lib.XML_SetCommentHandler(parser,callbacks['comment'])
   if initial and mode in [1,5,9,10,11]:lib.XML_SetEntityDeclHandler(parser,callbacks['entity'])
   if initial and mode in [2,10,11]:lib.XML_SetUnparsedEntityDeclHandler(parser,callbacks['unparsed'])
   if initial and mode==3:lib.XML_SetDefaultHandlerExpand(parser,callbacks['default'])
  try:
   generations=[]
   for generation in [0,1]:
    if generation:assert lib.XML_ParserReset(parser,None)==1
    configure(generation==0);events.clear();errors.clear();suspended=False;statuses=[]
    for offset in range(0,len(data),chunk):
     piece=data[offset:offset+chunk];final=int(offset+chunk>=len(data))
     if buffered:
      destination=lib.XML_GetBuffer(parser,len(piece));assert destination;c.memmove(destination,piece,len(piece));status=lib.XML_ParseBuffer(parser,len(piece),final)
     else:status=lib.XML_Parse(parser,piece,len(piece),final)
     outside_offset=I();outside_size=I();assert not lib.XML_GetInputContext(parser,c.byref(outside_offset),c.byref(outside_size));before=len(events);lib.XML_DefaultCurrent(parser);assert before==len(events)
     if status==2:
      assert suspended;lib.XML_SetEntityDeclHandler(parser,callbacks['entity']);status=lib.XML_ResumeParser(parser)
      assert not lib.XML_GetInputContext(parser,c.byref(outside_offset),c.byref(outside_size));before=len(events);lib.XML_DefaultCurrent(parser);assert before==len(events)
     statuses.append([offset,status,lib.XML_GetErrorCode(parser),pos()]);assert status==1,(mode,generation,status,errors)
    assert not errors,(mode,generation,errors)
    generations.append({'events':list(events),'statuses':statuses})
   rows.append({'mode':mode,'utf16':utf16,'chunk':chunk,'buffered':buffered,'generations':generations})
  finally:lib.XML_ParserFree(parser)
 results[label]={'library_sha256':hashlib.sha256(library.read_bytes()).hexdigest(),'rows':rows}
 print(label,len(rows),flush=True)
assert results['control']['rows']==results['candidate']['rows'],'candidate changed handler/context/position observations'
(r/'handler-probe.json').write_text(json.dumps({'status':'passed','scope':'240 conditions per library, each parsed then reset/reparsed (480 documents per library). Exact callbacks, raw byte context, positions, status, handler changes from preceding callbacks, OR setters, suspension/resume, ParseBuffer, UTF8/UTF16 and five chunks. DefaultCurrent and GetInputContext are inert outside active parse.','results':results},indent=2)+'\n')
print('all exact conditions passed')
