use oriole::{Config, EventKind, Parser};

#[test]
fn omitted_entity_payload_keeps_its_raw_boundary_and_semantic_definition() {
    for summarized in [false, true] {
        let mut parser = Parser::new(Config::default());
        parser.set_entity_handler_enabled(!summarized);
        parser
            .feed(b"<!DOCTYPE r [<!ENTITY e 'value'>]><r>&e;</r>", true)
            .unwrap();
        let mut definitions = 0;
        let mut text = String::new();
        while let Some(event) = parser.next_event().unwrap() {
            match event.kind {
                EventKind::EntityDeclarationSummary { callback_bytes } => {
                    assert!(summarized);
                    assert_eq!(callback_bytes, 6);
                    assert_eq!(parser.current_raw(), Some("<!ENTITY e 'value'>"));
                    definitions += 1;
                }
                EventKind::EntityDeclaration(entity) => {
                    assert!(!summarized);
                    assert_eq!(entity.name, "e");
                    assert_eq!(entity.value.as_deref(), Some("value"));
                    assert_eq!(parser.current_raw(), Some("<!ENTITY e 'value'>"));
                    definitions += 1;
                }
                EventKind::Text(value) => text.push_str(&value),
                _ => {}
            }
        }
        assert_eq!(definitions, 1);
        assert_eq!(text, "value");
    }
}
