from pathlib import Path
import shutil,subprocess,json,hashlib,os
root=Path('/tmp/oriole-entity-payload-study/compact');native=root/'native';native.mkdir(exist_ok=True);repo=Path('/tmp/oriole-utf8-feed')
a=root/'liboriole_expat.a'
if not a.exists():shutil.copy2('/home/dev-user/.cache/oriole/utf8-feed-target/release/liboriole_expat.a',a)
for filename in ['adversarial.c','allocations.c','integration.c']:shutil.copy2(repo/'tests/c'/filename,native/filename)
for filename in ['expat.h']:shutil.copy2(repo/'include'/filename,native/filename)
report={'scope':'C consumers compiled with ASan/UBSan against frozen dynamic and static Rust libraries. Rust is the optimized release build, not sanitizer-instrumented. LeakSanitizer disabled because sandbox ptrace is unsupported; separate allocation probes check zero live allocations.','rows':[],'input_hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [a,root/'liboriole_expat.so',*native.glob('*.c'),*native.glob('*.h')]}}
for linkage in ['dynamic','static']:
 for name in ['integration','adversarial','allocations']:
  executable=native/(name+'-'+linkage)
  command=['cc','-std=c11','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(native),str(native/(name+'.c'))]
  command += ['-L',str(root),'-loriole_expat','-Wl,-rpath,'+str(root)] if linkage=='dynamic' else [str(a),'-ldl','-lpthread','-lm']
  command += ['-o',str(executable)]
  compiled=subprocess.run(command,capture_output=True,text=True);assert compiled.returncode==0,compiled.stderr
  environment={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'}
  result=subprocess.run(['taskset','-c','2',str(executable)],capture_output=True,text=True,env=environment)
  row={'linkage':linkage,'case':name,'compile_command':command,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr};report['rows'].append(row)
  (native/'report.json').write_text(json.dumps(report,indent=2)+'\n')
  assert result.returncode==0,row
  print(name,linkage,result.stdout.strip(),flush=True)
report['status']='passed';(native/'report.json').write_text(json.dumps(report,indent=2)+'\n')
