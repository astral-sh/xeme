from pathlib import Path
import subprocess,json,hashlib,os,concurrent.futures
r=Path(__file__).parent;driver=Path('/tmp/oriole-grammar-bench-plain/native-driver');profiler=Path('/home/dev-user/.cache/oriole/profilers/local/usr/bin/valgrind')
libs={'control':r.parent/'control.so','candidate':r/'liboriole_expat.so'}
fixtures={'vulkan':Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus/vulkan/vk.xml'),'declarations':Path('/tmp/oriole-buffer-minimum/rare-declarations.xml')}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'scope':'XML_Parse Callgrind instruction attribution, including one warmup plus one measured parse and callback driver. Counts are not cycles or timing. Each pair runs on CPUs1/2; constructor/loader/free/file IO excluded.','hashes_before':{str(p):sha(p) for p in [driver,profiler,*libs.values(),*fixtures.values()]},'rows':[]}
def run(label,lib,name,fixture,cpu):
 prefix=r/(name+'-'+label)
 cmd=['taskset','-c',str(cpu),str(profiler),'--tool=callgrind','--toggle-collect=XML_Parse','--callgrind-out-file='+str(prefix)+'.out',str(driver),str(lib),str(fixture),'4096','1']
 p=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'VALGRIND_LIB':'/home/dev-user/.cache/oriole/profilers/local/usr/libexec/valgrind'},timeout=600)
 prefix.with_suffix('.stdout').write_text(p.stdout);prefix.with_suffix('.stderr').write_text(p.stderr)
 assert p.returncode==0,(cmd,p.stderr)
 instructions=int(next(line.split(':',1)[1] for line in Path(str(prefix)+'.out').read_text().splitlines() if line.startswith('summary:')))
 result=json.loads(p.stdout)
 return {'workload':name,'variant':label,'command':cmd,'returncode':p.returncode,'instructions':instructions,'observations':list({(s['hash'],s['elements'],s['text_bytes']) for s in result['samples']})}
for name,fixture in fixtures.items():
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  tasks=[pool.submit(run,label,lib,name,fixture,cpu) for cpu,(label,lib) in zip([1,2],libs.items())]
  rows=[task.result() for task in tasks]
 assert rows[0]['observations']==rows[1]['observations'],rows
 report['rows']+=rows;(r/'instructions.json').write_text(json.dumps(report,indent=2)+'\n');print(name,[(x['variant'],x['instructions']) for x in rows],flush=True)
report['hashes_after']={p:sha(Path(p)) for p in report['hashes_before']};assert report['hashes_before']==report['hashes_after'];report['status']='passed';(r/'instructions.json').write_text(json.dumps(report,indent=2)+'\n')
