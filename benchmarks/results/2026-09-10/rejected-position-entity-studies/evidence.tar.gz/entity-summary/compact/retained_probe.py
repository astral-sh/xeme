from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).parent;probe=Path('/tmp/oriole-allocation-followup/profile');library=r/'liboriole_expat.so';old=json.loads((r.parent/'retained-capacity.json').read_text());rows=[]
for prior in old['rows']:
 if prior['variant']!='control':continue
 command=prior['command'].copy();command[4]=str(library)
 p=subprocess.run(command,capture_output=True,text=True,timeout=30);assert p.returncode==0,p.stderr;raw=r/f"numeric-values-{prior['width']}-{prior['entities']}.jsonl";raw.write_text(p.stdout);x=json.loads(p.stdout.splitlines()[0]);assert x['status']==1 and x['after_free_live']==0;x.update(variant='compact',width=prior['width'],entities=prior['entities'],command=command,input_sha256=prior['input_sha256'],library_sha256=hashlib.sha256(library.read_bytes()).hexdigest(),raw=str(raw));rows.append({'control':prior,'compact':x});print(x['width'],x['entities'],prior['retained_live'],x['retained_live'],prior['peak_live'],x['peak_live']);assert x['retained_live']<=prior['retained_live'];assert x['peak_live']<=prior['peak_live']
(r/'retained-capacity.json').write_text(json.dumps({'scope':'Exact selected-suite live/peak byte comparison after bounded compaction. Reuses all four original numeric-reference fixtures. All selected bytes return to zero.','rows':rows},indent=2)+'\n')
