from pathlib import Path
import tarfile,subprocess,json,hashlib
r=Path(__file__).parent;cache=Path('/home/dev-user/.cache/ohm/build/release/build/workspaces/cd29af0d1116aa9b')
rlibs=list(cache.rglob('*.rmeta'));dependencies={name:max((p for p in rlibs if p.name.startswith('lib'+name+'-')),key=lambda p:p.stat().st_mtime) for name in ['oriole_storage','hashbrown','memchr']}
search=sorted({p.parent for p in rlibs});rows=[]
for label,archive in [('control',r/'control-source.tar.gz'),('candidate',r/'source.tar.gz')]:
 root=r/('layout-'+label);root.mkdir(exist_ok=True)
 with tarfile.open(archive) as t:
  for m in t.getmembers():
   if m.isfile():
    p=root/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(t.extractfile(m).read())
 source=root/'crates/oriole/src/lib.rs';source.write_text(source.read_text()+'\nconst _: () = { assert!(std::mem::size_of::<EventKind>() == 120); assert!(std::mem::size_of::<Event>() == 152); assert!(std::mem::size_of::<Option<Event>>() == 152); };\n')
 command=['taskset','-c','1','rustc','+ohm','--edition=2024','--crate-name','oriole_layout_'+label,'--crate-type','rlib','--emit=metadata','-Zprint-type-sizes',str(source),'-o',str(root/'layout.rmeta')]
 for name,path in dependencies.items():command+=['--extern',name+'='+str(path)]
 for path in search:command+=['-L','dependency='+str(path)]
 p=subprocess.run(command,capture_output=True,text=True);(r/('layout-'+label+'.log')).write_text(p.stdout+p.stderr);assert p.returncode==0,(label,p.stderr)
 rows.append({'variant':label,'source_archive':str(archive),'source_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'command':command,'returncode':p.returncode,'EventKind':120,'Event':152,'OptionEvent':152,'proof':'Compile-time size assertions against exact archived source; only appended assertions differ. Direct rustc emits metadata, no runtime execution.'})
(r/'layout.json').write_text(json.dumps({'rows':rows,'dependencies':{name:{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()} for name,path in dependencies.items()}},indent=2)+'\n')
print('control and candidate EventKind120 Event152 OptionEvent152')
