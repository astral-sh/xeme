# Rejected short-token position byte loop

The isolated byte-loop candidate preserves all 7,735,056 checked position states, but increases XML_Parse instruction counts by 0.162% on Wayland and 0.280% on Maven with namespaces. The requested instruction-count gate rejected it. No throughput study, broader parser suites or runtime integration followed.

`summary.json` records source lineage, exact counts and scope. `profile.json` retains commands and each process result; `.out.gz` files are the unchanged Callgrind outputs compressed for storage. `source.tar.gz` contains the exact candidate source. Native binaries are identified by local path/hash and excluded. Prior long-span/threshold studies are identified separately; neither the threshold nor long helper changed here.
