from pathlib import Path
import hashlib,json,os,subprocess,time,shutil,tarfile
R=Path('/tmp/oriole-position-bytes');E=R/'evidence';manifest=json.loads((E/'source.json').read_text())
assert json.loads((E/'oracle.json').read_text())['status']=='passed'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(R/p)==h for p,h in manifest['source_sha256'].items())
env={**os.environ,'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/position-bytes-target','CARGO_INCREMENTAL':'0'}
cmd=['taskset','-c','5','cargo','+ohm','build','--release','--locked','--offline','-p','oriole_expat'];start=time.time()
with (E/'build.log').open('w') as log:p=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
report={'command':cmd,'cwd':str(R),'environment':{k:env[k] for k in ['CARGO_HOME','CARGO_BUILD_BUILD_DIR','CARGO_TARGET_DIR','CARGO_INCREMENTAL']},'returncode':p.returncode,'wall_seconds':time.time()-start,'log_sha256':sha(E/'build.log')}
(E/'build.json').write_text(json.dumps(report,indent=2)+'\n');assert p.returncode==0
assert all(sha(R/p)==h for p,h in manifest['source_sha256'].items())
shutil.copyfile(Path(env['CARGO_TARGET_DIR'])/'release/liboriole_expat.so',E/'liboriole_expat.so')
shutil.copyfile('/tmp/oriole-event-slot-final/liboriole_expat.so',E/'control.so')
manifest['candidate_library_sha256']=sha(E/'liboriole_expat.so');manifest['build']=report
(E/'source.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(E/'source.tar.gz','w:gz') as t:
 for name in manifest['source_sha256']:t.add(R/name,arcname=name)
print(manifest['candidate_library_sha256'])
