fn advance_position(text: &str, line: &mut usize, column: &mut usize, previous_cr: &mut bool) {
    // Short tokens use one scalar pass instead of searching for line breaks and
    // separately counting characters in a second pass.
    if text.len() <= 128 {
        for byte in text.bytes() {
            match byte {
                b'\r' => {
                    *line += 1;
                    *column = 0;
                }
                b'\n' => {
                    if !*previous_cr {
                        *line += 1;
                    }
                    *column = 0;
                }
                _ => *column += usize::from(byte & 0xc0 != 0x80),
            }
            *previous_cr = byte == b'\r';
        }
        return;
    }
    advance_long_position(text, line, column, previous_cr);
}
