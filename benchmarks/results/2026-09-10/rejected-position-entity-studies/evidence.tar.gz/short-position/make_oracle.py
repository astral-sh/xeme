from pathlib import Path
E=Path('/tmp/oriole-position-bytes/evidence');base=Path('/tmp/oriole-event-slot-final/frozen-source/crates/oriole/src/encoding.rs').read_text();start=base.index('fn advance_long_position(');end=base.index('\n#[cfg(test)]',start)
head='''mod memchr { pub fn memchr2(a: u8, b: u8, bytes: &[u8]) -> Option<usize> { bytes.iter().position(|x| *x == a || *x == b) } }\n'''
head+=(E/'scalar-function.rs').read_text().replace('fn advance_position(', 'fn baseline(')
head+=(E/'candidate-function.rs').read_text().replace('fn advance_position(', 'fn candidate(')
head+=base[start:end]
body=r'''
fn scalar(text: &str, line: &mut usize, column: &mut usize, previous_cr: &mut bool) {
    for ch in text.chars() {
        match ch { '\r' => { *line += 1; *column = 0; }, '\n' => { if !*previous_cr { *line += 1; } *column = 0; }, _ => *column += 1 }
        *previous_cr = ch == '\r';
    }
}
type State = (usize, usize, bool);
fn apply(f: fn(&str,&mut usize,&mut usize,&mut bool), text: &str, initial: State) -> State {
    let (mut line,mut column,mut cr)=initial;f(text,&mut line,&mut column,&mut cr);(line,column,cr)
}
fn check(text: &str, split: bool, checks: &mut u64) {
    for initial in [(0,0,false),(0,0,true),(19,37,false),(19,37,true)] {
        let expected=apply(scalar,text,initial);
        assert_eq!(apply(baseline,text,initial),expected,"baseline {text:?}");
        assert_eq!(apply(candidate,text,initial),expected,"candidate {text:?}");*checks+=1;
        if split {
            for offset in (0..=text.len()).filter(|&n| text.is_char_boundary(n)) {
                let left=apply(candidate,&text[..offset],initial);
                let with_empty=apply(candidate,"",left);assert_eq!(left,with_empty);
                assert_eq!(apply(candidate,&text[offset..],with_empty),expected,"split {offset} {text:?}");*checks+=1;
            }
        }
    }
}
fn sequence(text:&mut String,depth:usize,checks:&mut u64) {
    check(text,true,checks);
    if depth==0 {return;}
    for ch in ['\r','\n','a','é','中','😀'] { let before=text.len();text.push(ch);sequence(text,depth-1,checks);text.truncate(before); }
}
fn main() {
    let mut checks=0; let mut scalars=0;
    for code in 0..=0x10ffff {
        if let Some(ch)=char::from_u32(code) {let mut buf=[0;4];check(ch.encode_utf8(&mut buf),false,&mut checks);scalars+=1;}
    }
    sequence(&mut String::new(),6,&mut checks);
    let structured=checks;
    let mut seed=0x7094128_u64;
    for length in [0,1,2,3,4,7,15,31,63,64,65,126,127,128,129,130,255,256] {
        for _ in 0..512 {
            let mut text=String::new();
            while text.len()<length {
                seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;
                let alphabet=['\r','\n','a','b','\0','\t','é','中','😀','\u{e000}','\u{10ffff}'];
                let mut ch=alphabet[seed as usize%alphabet.len()];if text.len()+ch.len_utf8()>length {ch='x';}text.push(ch);
            }
            check(&text,true,&mut checks);
        }
    }
    println!("{{\"status\":\"passed\",\"unicode_scalars\":{scalars},\"scalar_and_exhaustive_checks\":{structured},\"total_state_comparisons\":{checks},\"random_cases\":9216,\"short_threshold\":128}}");
}
'''
(E/'oracle.rs').write_text(head+body)
