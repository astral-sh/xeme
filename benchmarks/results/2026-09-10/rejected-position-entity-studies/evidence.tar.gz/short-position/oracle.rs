mod memchr { pub fn memchr2(a: u8, b: u8, bytes: &[u8]) -> Option<usize> { bytes.iter().position(|x| *x == a || *x == b) } }
fn baseline(text: &str, line: &mut usize, column: &mut usize, previous_cr: &mut bool) {
    // Short tokens use one scalar pass instead of searching for line breaks and
    // separately counting characters in a second pass.
    if text.len() <= 128 {
        for character in text.chars() {
            match character {
                '\r' => {
                    *line += 1;
                    *column = 0;
                }
                '\n' => {
                    if !*previous_cr {
                        *line += 1;
                    }
                    *column = 0;
                }
                _ => *column += 1,
            }
            *previous_cr = character == '\r';
        }
        return;
    }
    advance_long_position(text, line, column, previous_cr);
}
fn candidate(text: &str, line: &mut usize, column: &mut usize, previous_cr: &mut bool) {
    // Short tokens use one scalar pass instead of searching for line breaks and
    // separately counting characters in a second pass.
    if text.len() <= 128 {
        for byte in text.bytes() {
            match byte {
                b'\r' => {
                    *line += 1;
                    *column = 0;
                }
                b'\n' => {
                    if !*previous_cr {
                        *line += 1;
                    }
                    *column = 0;
                }
                _ => *column += usize::from(byte & 0xc0 != 0x80),
            }
            *previous_cr = byte == b'\r';
        }
        return;
    }
    advance_long_position(text, line, column, previous_cr);
}
fn advance_long_position(text: &str, line: &mut usize, column: &mut usize, previous_cr: &mut bool) {
    let mut rest = text;
    while let Some(index) = memchr::memchr2(b'\r', b'\n', rest.as_bytes()) {
        let cr = rest.as_bytes()[index] == b'\r';
        if cr || index != 0 || !*previous_cr {
            *line += 1;
        }
        *column = 0;
        *previous_cr = cr;
        rest = &rest[index + 1..];
    }
    if !rest.is_empty() {
        *column += rest.chars().count();
        *previous_cr = false;
    }
}

fn scalar(text: &str, line: &mut usize, column: &mut usize, previous_cr: &mut bool) {
    for ch in text.chars() {
        match ch { '\r' => { *line += 1; *column = 0; }, '\n' => { if !*previous_cr { *line += 1; } *column = 0; }, _ => *column += 1 }
        *previous_cr = ch == '\r';
    }
}
type State = (usize, usize, bool);
fn apply(f: fn(&str,&mut usize,&mut usize,&mut bool), text: &str, initial: State) -> State {
    let (mut line,mut column,mut cr)=initial;f(text,&mut line,&mut column,&mut cr);(line,column,cr)
}
fn check(text: &str, split: bool, checks: &mut u64) {
    for initial in [(0,0,false),(0,0,true),(19,37,false),(19,37,true)] {
        let expected=apply(scalar,text,initial);
        assert_eq!(apply(baseline,text,initial),expected,"baseline {text:?}");
        assert_eq!(apply(candidate,text,initial),expected,"candidate {text:?}");*checks+=1;
        if split {
            for offset in (0..=text.len()).filter(|&n| text.is_char_boundary(n)) {
                let left=apply(candidate,&text[..offset],initial);
                let with_empty=apply(candidate,"",left);assert_eq!(left,with_empty);
                assert_eq!(apply(candidate,&text[offset..],with_empty),expected,"split {offset} {text:?}");*checks+=1;
            }
        }
    }
}
fn sequence(text:&mut String,depth:usize,checks:&mut u64) {
    check(text,true,checks);
    if depth==0 {return;}
    for ch in ['\r','\n','a','é','中','😀'] { let before=text.len();text.push(ch);sequence(text,depth-1,checks);text.truncate(before); }
}
fn main() {
    let mut checks=0; let mut scalars=0;
    for code in 0..=0x10ffff {
        if let Some(ch)=char::from_u32(code) {let mut buf=[0;4];check(ch.encode_utf8(&mut buf),false,&mut checks);scalars+=1;}
    }
    sequence(&mut String::new(),6,&mut checks);
    let structured=checks;
    let mut seed=0x7094128_u64;
    for length in [0,1,2,3,4,7,15,31,63,64,65,126,127,128,129,130,255,256] {
        for _ in 0..512 {
            let mut text=String::new();
            while text.len()<length {
                seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;
                let alphabet=['\r','\n','a','b','\0','\t','é','中','😀','\u{e000}','\u{10ffff}'];
                let mut ch=alphabet[seed as usize%alphabet.len()];if text.len()+ch.len_utf8()>length {ch='x';}text.push(ch);
            }
            check(&text,true,&mut checks);
        }
    }
    println!("{{\"status\":\"passed\",\"unicode_scalars\":{scalars},\"scalar_and_exhaustive_checks\":{structured},\"total_state_comparisons\":{checks},\"random_cases\":9216,\"short_threshold\":128}}");
}
