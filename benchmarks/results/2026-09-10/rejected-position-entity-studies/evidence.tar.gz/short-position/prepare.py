from pathlib import Path
import tarfile,hashlib,json,difflib
R=Path('/tmp/oriole-position-bytes');E=R/'evidence';B=Path('/tmp/oriole-event-slot-final')
manifest=json.loads((B/'source.json').read_text())
author_files=json.loads(Path('/tmp/oriole-event-output/final-source.json').read_text())['files']
with tarfile.open(B/'source.tar.gz') as t:
 for m in t.getmembers():
  if not m.isfile():continue
  p=R/m.name;data=t.extractfile(m).read();assert hashlib.sha256(data).hexdigest()==author_files[m.name]
  p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
p=R/'crates/oriole/src/encoding.rs';old=p.read_text();start=old.index('fn advance_position(');end=old.index('\nfn advance_long_position',start);func=old[start:end]
assert 'if text.len() <= 128 {' in func
newfunc=func.replace('for character in text.chars() {','for byte in text.bytes() {').replace('match character {','match byte {').replace("'\\r' =>","b'\\r' =>").replace("'\\n' =>","b'\\n' =>").replace('_ => *column += 1,','_ => *column += usize::from(byte & 0xc0 != 0x80),').replace("*previous_cr = character == '\\r';","*previous_cr = byte == b'\\r';")
new=old[:start]+newfunc+old[end:];p.write_text(new)
(E/'candidate.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/crates/oriole/src/encoding.rs',tofile='b/crates/oriole/src/encoding.rs')))
(E/'scalar-function.rs').write_text(func);(E/'candidate-function.rs').write_text(newfunc)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'base_commit':manifest['commit'],'base_source_manifest_sha256':sha(B/'source.json'),'base_source_archive_sha256':sha(B/'source.tar.gz'),'control_library':{'path':str(B/'liboriole_expat.so'),'sha256':sha(B/'liboriole_expat.so')},'patch_sha256':sha(E/'candidate.patch'),'source_sha256':{p:sha(R/p) for p in author_files},'scope':'Only <=128 byte advance_position loop; threshold, long helper, raw-width accounting and XML scanning unchanged.','prior_studies':{str(p):sha(p) for p in [Path('/tmp/oriole-position-short/position.patch'),Path('/tmp/oriole-position-optimization/position.patch'),Path('/tmp/oriole-position-coalesced/position128.patch'),Path('/tmp/oriole-position-handoff/manifest.json')]},'prior_review':'Earlier studies use chars for short spans and memchr plus tail chars count for long spans; no non-continuation-byte counting candidate found.'}
(E/'source.json').write_text(json.dumps(report,indent=2)+'\n')
print(report['patch_sha256'])
