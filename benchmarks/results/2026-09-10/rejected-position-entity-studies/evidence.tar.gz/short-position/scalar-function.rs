fn advance_position(text: &str, line: &mut usize, column: &mut usize, previous_cr: &mut bool) {
    // Short tokens use one scalar pass instead of searching for line breaks and
    // separately counting characters in a second pass.
    if text.len() <= 128 {
        for character in text.chars() {
            match character {
                '\r' => {
                    *line += 1;
                    *column = 0;
                }
                '\n' => {
                    if !*previous_cr {
                        *line += 1;
                    }
                    *column = 0;
                }
                _ => *column += 1,
            }
            *previous_cr = character == '\r';
        }
        return;
    }
    advance_long_position(text, line, column, previous_cr);
}
