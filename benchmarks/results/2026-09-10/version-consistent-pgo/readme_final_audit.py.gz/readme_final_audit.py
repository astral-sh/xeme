"""Read-only documentation audit against frozen benchmark reconstructions."""
from pathlib import Path
import hashlib
import json
import re
import statistics

repo=Path('/home/dev-user/code/oss/oriole')
p=repo/'benchmarks/results/2026-09-10/version-consistent-pgo/README.md'
f=repo/'benchmarks/results/2026-09-10/rejected-fused-tag-study/README.md'
root=Path('/tmp/oriole-pgo-version-final-handoff')
load=lambda path:json.loads(path.read_text())
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
n=load(root/'native-reconstruction.json');c=load(root/'consumer-reconstruction.json')
text=p.read_text();fusion=f.read_text();rows=[]
for item in n['table_4k_no_namespaces']:
    names={'vulkan':'Vulkan','wayland':'Wayland','maven':'Maven','batik':'Batik','gtk':'GTK','docbook':'DocBook'}
    t=item['median_seconds'];r=item['paired_ratios']
    row=f"| {names[item['name']]} | {t['oriole-normal']*1000:.3f} ms | {t['expat-normal']*1000:.3f} ms | {r['oriole-normal_over_expat-normal']:.2f}× | {t['oriole-pgo']*1000:.3f} ms | {t['expat-pgo']*1000:.3f} ms | {r['oriole-pgo_over_expat-pgo']:.2f}× |"
    assert row in text,row
    rows.append(row)
for name,ratios in [('ElementTree',c['python']['by_mode']['elementtree']),('pyexpat event list',c['python']['by_mode']['pyexpat-events']),('Both interfaces',c['python']['geomeans'])]:
    row=f"| {name} | {ratios['oriole-normal_over_expat-normal']:.2f}× | {ratios['oriole-pgo_over_expat-pgo']:.2f}× | {ratios['oriole-pgo_over_oriole-normal']:.3f}× |"
    assert row in text,row
    rows.append(row)
for item in c['wayland']['cells']:
    name={'client-header':'Client header','private-code':'Private code'}[item['condition']['mode']]
    t=item['median_seconds'];r=item['paired_ratios']
    row=f"| {name} | {t['oriole-normal']*1000:.3f} ms | {t['expat-normal']*1000:.3f} ms | {t['oriole-pgo']*1000:.3f} ms | {t['expat-pgo']*1000:.3f} ms | {r['oriole-pgo_over_expat-pgo']:.2f}× |"
    assert row in text,row
    rows.append(row)
for ratio in (n['geomeans']['oriole-pgo_over_oriole-normal'],n['geomeans']['expat-pgo_over_expat-normal'],c['python']['geomeans']['oriole-pgo_over_oriole-normal']):
    assert f'{(1-ratio)*100:.1f}%' in text
for ratio in (n['geomeans']['oriole-normal_over_expat-normal'],n['geomeans']['oriole-pgo_over_expat-pgo'],c['wayland']['geomeans']['oriole-normal_over_expat-normal'],c['wayland']['geomeans']['oriole-pgo_over_expat-pgo']):
    assert f'{ratio:.4f}×' in text
links=[]
for doc in (p,f):
    for title,target in re.findall(r'\[([^]]+)\]\(([^)]+)\)',doc.read_text()):
        if '://' in target:continue
        actual=(doc.parent/target).resolve();assert actual.exists(),str(actual)
        links.append({'document':str(doc),'target':target})
fs=load(Path('/tmp/oriole-fused-validation/screening-summary.json'));fi=load(Path('/tmp/oriole-fused-validation/instructions-summary.json'));v=fs['variants']['candidate']
assert f"{v['real_project_geomean_speedup']:.5f}×" in fusion
assert f"{(1-fi['geomean_instruction_ratio'])*100:.2f}%" in fusion
assert '6 of 24' in fusion and fs['processes']==280
for x in v['generated_conditions']:
    if x['workload']=='generated-rare-declarations':assert f"{x['median_speedup']:.5f}×" in fusion
assert 'Aggregate ratios are equal-weight geometric means' in text
assert 'Oriole uses Rust/LLVM 22 with ThinLTO; Expat uses GCC 13.3' in text
assert 'Constructor calls, handler setup, parsing, callback hashing and destruction are' in text
assert 'Python workloads do not load external DTDs' in text
result={'status':'passed','scope':'Read-only root README review; no parser executions, builds, or new timing. Numeric tables reconstructed from frozen owner reports previously independently audited; rejected study conclusions checked against immutable instruction/screening summaries.','files':{str(x):sha(x) for x in (p,f,root/'native-reconstruction.json',root/'consumer-reconstruction.json',Path('/tmp/oriole-fused-validation/screening-summary.json'),Path('/tmp/oriole-fused-validation/instructions-summary.json'))},'verified_table_rows':len(rows),'links':links,'no_findings':['All eleven displayed timing/ratio rows match exact documented rounding.','Headlines and aggregate numbers match frozen paired geometric calculations.','Matched benchmark5974 vs correctness normalac6a/Pgo4584 is correctly separated.','Automatic GC enabled and explicit gc.collect outside timing are accurately distinguished.','Rejected overlap, loader-probe assumptions, superseded9cc and pending-label history are preserved.','Fusion slowdown and instruction gain are correctly separated; causal explanation remains unproven.'],'resolved_method_clarifications':['Explicitly identify aggregate ratios as equal-weight geometric means of per-condition median paired ratios.','State native measured/excluded phases: creation/setup/parse/callback hash/destruction included; process startup/dlopen/input file IO excluded.','State native/Python external DTD loading is disabled, notably Batik; disclose Rust/LLVM22 ThinLTO versus ExpatGCC13.3 -O3/noLTO context.']}
Path('/tmp/oriole-pgo-readme-final-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'rows':len(rows),'review_sha256':sha(Path('/tmp/oriole-pgo-readme-final-review.json'))}))
