import os,json,subprocess,time,hashlib,shutil
from pathlib import Path
source=Path('/tmp/oriole-raw-attribute-scratch');out=Path('/tmp/oriole-deep-profile-experiment/control')
env=dict(os.environ,CARGO_HOME='/home/dev-user/.cache/toucan/cargo',CARGO_TARGET_DIR='/home/dev-user/.cache/oriole/raw-attribute-scratch-target',CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/build',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST='all',CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST='all')
commands=[('check',['check','--offline','--locked','-p','oriole','-p','oriole_expat']),('tests',['test','--offline','--locked','-p','oriole','-p','oriole_expat','-p','oriole_storage']),('clippy',['clippy','--offline','--locked','-p','oriole','-p','oriole_expat','-p','oriole_storage','--all-targets','--','-D','warnings']),('build',['build','--release','--offline','--locked','-p','oriole_expat']),('fmt-check',['fmt','--all','--check'])]
rows=[]
try:
 for label,args in commands:
  command=['taskset','-c','3','cargo','+ohm',*args];start=time.time()
  with (out/(label+'.log')).open('w') as f:r=subprocess.run(command,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT)
  row={'label':label,'command':command,'exit_code':r.returncode,'seconds':time.time()-start};rows.append(row);print(row,flush=True)
  assert r.returncode==0,row
 for name in ['liboriole_expat.so','liboriole_expat.a']:shutil.copyfile(Path(env['CARGO_TARGET_DIR'])/'release'/name,out/name)
finally:
 (out/'build.json').write_text(json.dumps({'cwd':str(source),'environment':{k:env[k] for k in env if k.startswith('CARGO_')},'commands':rows},indent=2)+'\n')
