import hashlib,io,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/dev-user/code/oss/oriole');out=Path('/tmp/oriole-deep-profile-experiment');stage=out/'staged-source';stage.mkdir(exist_ok=True)
old='7c0d8b35c079c00da3012628ca56d7b35d2c5cd4';base='ebcd46dd0cd720d1f28de5fda0b87cf4b1b05756'
archive=subprocess.check_output(['git','-C',str(root),'archive',base,'Cargo.toml','Cargo.lock','rustfmt.toml','crates','include'])
with tarfile.open(fileobj=io.BytesIO(archive)) as tf:tf.extractall(stage,filter='data')
manifest=json.loads(Path('/tmp/oriole-entity-scaling-composed-handoff/source.json').read_text())
inputs=out/'merge-inputs';inputs.mkdir(exist_ok=True);rows=[]
with tarfile.open('/tmp/oriole-entity-scaling-composed-handoff/source.tar.gz') as tf:
 for path in manifest['changed_sources']:
  candidate=tf.extractfile(path).read()
  assert hashlib.sha256(candidate).hexdigest()==manifest['changed_sources'][path]
  before=subprocess.run(['git','-C',str(root),'show',old+':'+path],capture_output=True)
  original=before.stdout if before.returncode==0 else b''
  if before.returncode:
   assert not (stage/path).exists();(stage/path).parent.mkdir(exist_ok=True,parents=True);(stage/path).write_bytes(candidate)
   rows.append({'path':path,'status':'new_file','returncode':0});continue
  stem=path.replace('/','_')
  current_path=inputs/(stem+'.current');base_path=inputs/(stem+'.base');candidate_path=inputs/(stem+'.candidate')
  current_path.write_bytes((stage/path).read_bytes());base_path.write_bytes(original);candidate_path.write_bytes(candidate)
  command=['git','merge-file','-p','--diff3',str(current_path),str(base_path),str(candidate_path)]
  run=subprocess.run(command,capture_output=True)
  assert run.returncode in (0,1,2,3,4,5,6,7,8),run.stderr
  (stage/path).write_bytes(run.stdout)
  rows.append({'path':path,'status':'merged' if run.returncode==0 else 'conflicts','returncode':run.returncode,'stderr':run.stderr.decode()})
(out/'composition-first.json').write_text(json.dumps({'previous_base':old,'new_base':base,'original_patch_sha256':hashlib.sha256(Path('/tmp/oriole-entity-scaling-composed-handoff/candidate.patch').read_bytes()).hexdigest(),'rows':rows},indent=2)+'\n')
print(json.dumps(rows,indent=2))
