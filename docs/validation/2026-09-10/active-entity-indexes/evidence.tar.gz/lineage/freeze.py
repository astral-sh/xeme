import difflib,hashlib,json,subprocess,tarfile
from pathlib import Path
w=Path('/tmp/oriole-deep-profile-experiment');source=Path('/tmp/oriole-raw-attribute-scratch');out=w/'control';out.mkdir(exist_ok=True)
base='ebcd46dd0cd720d1f28de5fda0b87cf4b1b05756';root='/home/dev-user/code/oss/oriole';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=json.loads((w/'source-files.json').read_text());changes={};diff=[]
for p in files:
 old=subprocess.run(['git','-C',root,'show',base+':'+p],capture_output=True)
 new=(source/p).read_bytes()
 if old.returncode or old.stdout!=new:
  changes[p]={'base':hashlib.sha256(old.stdout).hexdigest() if old.returncode==0 else None,'candidate':sha(source/p)}
  diff.extend(difflib.unified_diff(old.stdout.decode().splitlines(True) if old.returncode==0 else [],new.decode().splitlines(True),fromfile='a/'+p if old.returncode==0 else '/dev/null',tofile='b/'+p))
(out/'candidate.patch').write_text(''.join(diff));(out/'source.json').write_text(json.dumps({'base_commit':base,'source_root':str(source),'sources':{p:sha(source/p) for p in files},'changes':changes},indent=2)+'\n')
with tarfile.open(out/'source.tar.gz','w:gz') as tf:
 for p in files:tf.add(source/p,arcname=p,recursive=False)
print(json.dumps({'files':len(files),'changes':list(changes),'source_sha256':sha(out/'source.json'),'patch_sha256':sha(out/'candidate.patch')}))
