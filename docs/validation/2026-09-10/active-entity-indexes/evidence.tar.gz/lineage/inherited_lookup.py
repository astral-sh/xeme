from pathlib import Path
p=Path('/tmp/oriole-raw-attribute-scratch/crates/oriole/src/active.rs');s=p.read_text();needle='    pub(crate) fn source_contains(&self, name: &str, parameter: bool) -> bool {';assert needle in s;s=s.replace(needle,'''    /// Attribute recursion includes inherited names, but not the current content
    /// source. Preserve that distinction without copying the chain per attribute.
    pub(crate) fn inherited_contains(&self, name: &str, parameter: bool) -> bool {
        self.names
            .get(name)
            .is_some_and(|counts| counts[usize::from(parameter) + 2] != 0)
    }

'''+needle);p.write_text(s)
p=Path('/tmp/oriole-raw-attribute-scratch/crates/oriole/src/lib.rs');s=p.read_text();assert s.count('        let mut seeded = false;')==1;s=s.replace('        let mut seeded = false;\n','');old='''            if !seeded {
                for name in &self.entity_chain {
                    try_set_insert(&mut active, name.as_str())?;
                }
                seeded = true;
            }
            if active.contains(name) {''';assert old in s;s=s.replace(old,'''            if active.contains(name) || self.active_entities.inherited_contains(name, false) {''');p.write_text(s)
