import hashlib,io,json,shutil,subprocess,tarfile,difflib
from pathlib import Path
w=Path('/tmp/oriole-deep-profile-experiment');stage=w/'staged-source';source=Path('/tmp/oriole-raw-attribute-scratch');base='ebcd46dd0cd720d1f28de5fda0b87cf4b1b05756';root='/home/dev-user/code/oss/oriole';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads(Path('/tmp/oriole-entity-scaling-composed-handoff/source.json').read_text());assert all(sha(source/p)==h for p,h in old['sources'].items())
for p in old['sources']:(source/p).unlink()
for p in stage.rglob('*'):
 if p.is_file():q=source/p.relative_to(stage);q.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(p,q)
extra=['tests/c','tools/upstream-expat/run.py','tools/upstream-expat/runner.c','tools/upstream-expat/bridge.c','tools/upstream-expat/bridge.h','tools/upstream-expat/memcheck.patch']
data=subprocess.check_output(['git','-C',root,'archive',base,*extra])
with tarfile.open(fileobj=io.BytesIO(data)) as tf:tf.extractall(source,filter='data')
files=subprocess.check_output(['git','-C',root,'ls-tree','-r','--name-only',base,'Cargo.toml','Cargo.lock','rustfmt.toml','crates','include',*extra],text=True).splitlines()+['crates/oriole/src/active.rs','crates/oriole/tests/entity_depth.rs']
(w/'source-files.json').write_text(json.dumps(sorted(files),indent=2)+'\n')
print('new f169 source installed',len(files))
