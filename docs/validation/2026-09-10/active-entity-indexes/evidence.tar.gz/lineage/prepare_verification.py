import hashlib,json,tarfile
from pathlib import Path
w=Path('/tmp/oriole-deep-profile-experiment');out=w/'inherited';frozen=out/'frozen-source';frozen.mkdir(exist_ok=True)
with tarfile.open(out/'source.tar.gz') as tf:tf.extractall(frozen,filter='data')
s=Path('/tmp/oriole-entity-scaling-composed/release/verify.py').read_text().replace('/tmp/oriole-entity-scaling-composed/release',str(out)).replace("source=Path('/tmp/oriole-raw-attribute-scratch')",f'source=Path({str(frozen)!r})')
s=s.replace(".replace(\"'baseline':'/tmp/oriole-custom-final/liboriole_expat.so'\",\"'baseline':'/tmp/oriole-shared-integrated/liboriole_expat.so'\")", ".replace(\"'baseline':'/tmp/oriole-custom-final/liboriole_expat.so'\",\"'baseline':'/tmp/oriole-deep-profile-experiment/control/liboriole_expat.so'\")")
(out/'verify.py').write_text(s)
s=Path('/tmp/oriole-entity-scaling-composed/release/native.py').read_text().replace('/tmp/oriole-entity-scaling-composed/release',str(out)).replace('/tmp/oriole-raw-attribute-scratch',str(frozen)).replace("'taskset','-c','4'","'taskset','-c','3'")
(out/'native.py').write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['control','inherited']:
 d=w/name;(d/'binary.json').write_text(json.dumps({p.name:sha(p) for p in d.glob('lib*')},indent=2)+'\n')
