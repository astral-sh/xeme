import hashlib,json,os,subprocess,time,shutil
from pathlib import Path
out=Path('/tmp/oriole-deep-profile-experiment/inherited');source=Path('/tmp/oriole-deep-profile-experiment/inherited/frozen-source');python='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
code=Path('/tmp/oriole-entity-scaling-handoff/oracle.py').read_text().replace("OUT=Path('/tmp/oriole-entity-scaling')","OUT=Path('/tmp/oriole-deep-profile-experiment/inherited')").replace("'baseline':'/tmp/oriole-custom-final/liboriole_expat.so'","'baseline':'/tmp/oriole-deep-profile-experiment/control/liboriole_expat.so'")
(out/'oracle.py').write_text(code)
for name in ('oracle.py','probe.py','siblings.py','general_snapshot.py'):
 dest={'oracle.py':'missing.py','probe.py':'doctype.py','siblings.py':'siblings.py','general_snapshot.py':'general.py'}[name]
 text=Path('/tmp/oriole-shared-integrated',name).read_text()
 if name in ('siblings.py','general_snapshot.py'):text=text.replace('/tmp/oriole-missing-parameter/oracle.py',str(out/'missing.py'))
 (out/dest).write_text(text)
(out/'run_clean.py').write_text('import runpy,sys\nfrom pathlib import Path\nassert not any(line.rsplit("/",1)[-1].startswith("libexpat.") for line in Path("/proc/self/maps").read_text().splitlines())\nerrors=[]\nsys.unraisablehook=lambda e:errors.append(str(e.exc_value))\nscript=sys.argv.pop(1)\nrunpy.run_path(script,run_name="__main__")\nassert not errors,errors\n')
commands=[]
for label,script,args in [('membership','oracle.py',[str(out/'liboriole_expat.so')]),('missing','missing.py',[str(out/'liboriole_expat.so'),str(out/'missing.json')]),('doctype','doctype.py',[str(out/'liboriole_expat.so'),str(out/'doctype.json.gz')]),('siblings','siblings.py',[str(out/'liboriole_expat.so'),str(out/'siblings.json')]),('general','general.py',[str(out/'liboriole_expat.so'),str(out/'general.json')]),('upstream',str(source/'tools/upstream-expat/run.py'),['--source','/home/dev-user/.cache/oriole/upstream/expat-2.8.4','--config','/home/dev-user/.cache/oriole/expat-build/expat_config.h','--library',str(out/'liboriole_expat.so'),'--output',str(out/'upstream-api')])]:
 script=Path(script);script=script if script.is_absolute() else out/script
 command=['taskset','-c','3',python,'-I','-S',str(out/'run_clean.py'),str(script),*args];start=time.time()
 with (out/(label+'.log')).open('w') as log:run=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=360)
 row={'label':label,'command':command,'exit_code':run.returncode,'seconds':time.time()-start,'log_sha256':sha(out/(label+'.log'))};commands.append(row)
 (out/'verification-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(row,flush=True)
 assert run.returncode in ([0,1] if label=='upstream' else [0]),row
