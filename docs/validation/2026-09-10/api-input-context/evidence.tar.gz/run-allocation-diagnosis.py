from pathlib import Path
import hashlib,json,gzip,shutil,subprocess,os,re,difflib
base=Path('/tmp/oriole-api-followup-upstream');out=Path('/tmp/oriole-api-followup-allocation-diagnosis');out.mkdir(exist_ok=False)
root=Path('/home/dev-user/code/oss/oriole-api-followup')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((base/'manifest.json').read_text());original=json.loads((base/'results.json').read_text())
selected=['test_alloc_parse_xdecl','test_nsalloc_realloc_long_prefix','test_nsalloc_realloc_longer_prefix','test_nsalloc_realloc_long_context_in_dtd','test_alloc_realloc_nested_groups']
shutil.copytree(base/'adapted',out/'adapted');shutil.copytree(base/'lib',out/'lib');shutil.copy2(base/'liboriole_expat.so',out/'liboriole_expat.so')
archive=root/'tools/upstream-expat/results/2026-09-10/allocation-audit/contracts-raised512-retry-ceilings.patch.gz'
patch=out/'retry-ceilings.patch';patch.write_bytes(gzip.decompress(archive.read_bytes()))
record={'scope':'Separate allocation diagnosis only. Apply the previously published retry-ceiling overlay with zero fuzz and preserve all original assertions. These diagnostic passes do not replace any unchanged upstream result.','original_matrix_sha256':sha(base/'results.json'),'library_sha256':sha(out/'liboriole_expat.so'),'overlay_archive_sha256':sha(archive),'overlay_sha256':sha(patch),'selected_tests':selected,'compile_command':[s.replace(str(base),str(out)) for s in old['compile_command']],'limits':{'test_seconds':15,'address_space_mib':4096,'rss_mib':3072,'total_seconds':300}}
try:
 result=subprocess.run(['patch','--batch','--fuzz=0','-p0','-i',str(patch)],cwd=out/'adapted',capture_output=True,text=True,timeout=30)
 (out/'patch.log').write_text(result.stdout+result.stderr);record['patch_exit_code']=result.returncode;assert result.returncode==0
 changes=[]
 for path in sorted((out/'adapted').glob('*.c')):
  before=(base/'adapted'/path.name).read_text();after=path.read_text()
  if before!=after:changes.append(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=path.name,tofile=path.name)))
 (out/'applied.patch').write_text(''.join(changes));record['adapted_sources']={p.name:sha(p) for p in (out/'adapted').iterdir() if p.is_file()}
 with (out/'build.log').open('w') as stream:
  result=subprocess.run(record['compile_command'],stdout=stream,stderr=subprocess.STDOUT,timeout=120)
 record['build_exit_code']=result.returncode;assert result.returncode==0
 record['binary_sha256']=sha(out/'runtests')
 environment={'ORIOLE_CHUNK_MASK':'63','ORIOLE_DEFERRAL_MASK':'3','ORIOLE_TEST_TIMEOUT':'15','ORIOLE_MEMORY_MIB':'4096','ORIOLE_RSS_MIB':'3072','ORIOLE_SELECTED_TESTS':','.join(selected)}
 record['environment']=environment
 with (out/'tests.log').open('w') as stream:
  result=subprocess.run(['taskset','-c','1,3',str(out/'runtests'),'--verbose'],stdout=stream,stderr=subprocess.STDOUT,env={**os.environ,**environment},timeout=300)
 record['run_exit_code']=result.returncode
 log=(out/'tests.log').read_text()
 records=[dict(context=context,test=test,outcome=outcome,code=int(code)) for context,test,outcome,code in re.findall(r'^ORIOLE_RESULT\t([^\t]+)\t([^\t]+)\t([^\t]+)\t(\d+)$',log,re.M)]
 origins=re.findall(r'^ORIOLE_LIBRARY\t(.+)$',log,re.M)
 record['library_origin_verified']=bool(origins) and all(Path(p).resolve()==out/'liboriole_expat.so' for p in origins)
 record['selection_complete']=len(records)==12*len(selected) and len({(r['test'],r['context']) for r in records})==len(records)
 record['passed']=sum(r['outcome']=='pass' for r in records);record['failed']=len(records)-record['passed'];record['results']=records
 record['library_unchanged']=sha(out/'liboriole_expat.so')==record['library_sha256']
 assert record['selection_complete'] and record['library_origin_verified'] and record['library_unchanged']
 print(json.dumps({k:record[k] for k in ['passed','failed','selection_complete','library_origin_verified','run_exit_code']}))
finally:
 (out/'report.json').write_text(json.dumps(record,indent=2)+'\n')
