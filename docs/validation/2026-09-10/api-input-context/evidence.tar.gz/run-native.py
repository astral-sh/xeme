from pathlib import Path
import hashlib,json,subprocess,os
root=Path('/tmp/oriole-api-followup-native-checked');root.mkdir(exist_ok=False)
source=Path('/home/dev-user/code/oss/oriole-api-followup');libs=Path('/tmp/oriole-api-followup-validation/final')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
observed=[source/'include/expat.h',*(source/'tests/c').glob('*.c'),libs/'liboriole_expat.so',libs/'liboriole_expat.a']
report={'scope':'C ASan/UBSan with uninstrumented release Rust; leak sanitizer disabled.','sha256_before':{str(p):sha(p) for p in observed},'rows':[]}
try:
 for prior in json.loads(Path('/tmp/oriole-dtd-native/report.json').read_text())['rows']:
  command=[s.replace('/home/dev-user/code/oss/oriole/', '/home/dev-user/code/oss/oriole-api-followup/').replace('/tmp/oriole-dtd-combined-source','/tmp/oriole-api-followup-validation/final').replace('/tmp/oriole-dtd-native','/tmp/oriole-api-followup-native-checked') for s in prior['command']]
  label=prior['case']+'-'+prior['linkage'];binary=root/label
  row={'case':prior['case'],'linkage':prior['linkage'],'command':command};report['rows'].append(row)
  with (root/(label+'-build.log')).open('w') as log:
   result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  row['build_exit_code']=result.returncode;assert result.returncode==0
  row['binary_sha256']=sha(binary);row['run_command']=['taskset','-c','1,3',str(binary)]
  with (root/(label+'.log')).open('w') as log:
   result=subprocess.run(row['run_command'],stdout=log,stderr=subprocess.STDOUT,timeout=120,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
  row['exit_code']=result.returncode;row['log_sha256']=sha(root/(label+'.log'));assert result.returncode==0
  print(label,result.returncode,flush=True)
 report['sha256_after']={str(p):sha(p) for p in observed};assert report['sha256_after']==report['sha256_before']
 report['status']='passed'
finally:
 (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
