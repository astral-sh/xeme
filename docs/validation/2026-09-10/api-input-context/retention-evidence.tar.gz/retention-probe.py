import ctypes as c
import hashlib
import json
from pathlib import Path

rows = []
for label, path in [
    ('initial', '/tmp/oriole-api-followup-validation/final/liboriole_expat.so'),
    ('corrected', '/tmp/oriole-api-followup-retention/liboriole_expat.so'),
    ('reference', '/home/dev-user/.cache/oriole/expat-build/libexpat.so'),
]:
    lib = c.CDLL(path)
    lib.XML_ParserCreate.argtypes = [c.c_char_p]
    lib.XML_ParserCreate.restype = c.c_void_p
    lib.XML_Parse.argtypes = [c.c_void_p, c.c_char_p, c.c_int, c.c_int]
    lib.XML_ParserFree.argtypes = [c.c_void_p]
    lib.XML_GetInputContext.argtypes = [c.c_void_p, c.POINTER(c.c_int), c.POINTER(c.c_int)]
    lib.XML_GetInputContext.restype = c.c_void_p
    callback = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.c_void_p)
    lib.XML_SetStartElementHandler.argtypes = [c.c_void_p, callback]
    parser = lib.XML_ParserCreate(None)
    observed = []

    @callback
    def on_start(*unused):
        offset = c.c_int(-1)
        size = c.c_int(-1)
        pointer = lib.XML_GetInputContext(parser, c.byref(offset), c.byref(size))
        observed.append({'offset': offset.value, 'size': size.value, 'nonnull': bool(pointer)})

    lib.XML_SetStartElementHandler(parser, on_start)
    for _ in range(1024):
        assert lib.XML_Parse(parser, b' ' * 1024, 1024, 0) == 1
    assert lib.XML_Parse(parser, b'<r/>', 4, 1) == 1
    lib.XML_ParserFree(parser)
    rows.append({'label': label, 'library': path, 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest(), 'observations': observed})
report = {'prefix_bytes': 1048576, 'chunk_size': 1024, 'suffix': '<r/>', 'results': rows}
assert rows[0]['observations'] == [{'offset': 1048576, 'size': 1048580, 'nonnull': True}]
assert rows[1]['observations'] == rows[2]['observations'] == [{'offset': 1024, 'size': 1028, 'nonnull': True}]
Path('/tmp/oriole-api-followup-retention/probe.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
