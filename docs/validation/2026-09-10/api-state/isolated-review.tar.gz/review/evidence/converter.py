import ctypes as c,hashlib,itertools,json,sys
from pathlib import Path
P,S,I=c.c_void_p,c.c_char_p,c.c_int
class Encoding(c.Structure):_fields_=[('map',I*256),('data',P),('convert',P),('release',P)]
UNK=c.CFUNCTYPE(I,P,S,c.POINTER(Encoding));REL=c.CFUNCTYPE(None,P);CONV=c.CFUNCTYPE(I,P,S)
REF='/home/dev-user/.cache/oriole/expat-build/libexpat.so';CAND=sys.argv[1]
def probe(path,name,data,width):
 l=c.CDLL(path)
 for n,r,a in [('XML_ParserCreate',P,[S]),('XML_ParserFree',None,[P]),('XML_Parse',I,[P,S,I,I]),('XML_SetEncoding',I,[P,S]),('XML_ParserReset',c.c_ubyte,[P,S]),('XML_GetErrorCode',I,[P]),('XML_StopParser',I,[P,c.c_ubyte]),('XML_SetUnknownEncodingHandler',None,[P,UNK,P])]:
  f=getattr(l,n);f.restype=r;f.argtypes=a
 events=[];p=l.XML_ParserCreate(b'multi')
 @REL
 def release(_):events.append(['release'])
 @CONV
 def convert(_,value):
  events.append(['convert',l.XML_StopParser(p,0),l.XML_SetEncoding(p,name)]);return 233
 @UNK
 def unknown(_,name,info):
  events.append(['unknown']);info.contents.map[:]=range(256);info.contents.map[128]=-2;info.contents.release=c.cast(release,P);info.contents.convert=c.cast(convert,P);return 1
 l.XML_SetUnknownEncodingHandler(p,unknown,None)
 width=width or len(data);status=1
 for i in range(0,len(data),width):
  part=data[i:i+width];status=l.XML_Parse(p,part,len(part),int(i+width>=len(data)))
  if status!=1:break
 result={'status':status,'error':l.XML_GetErrorCode(p),'set':l.XML_SetEncoding(p,None),'reset':l.XML_ParserReset(p,None),'resetparse':l.XML_Parse(p,b'<r/>',4,1)}
 l.XML_ParserFree(p);result['events']=events;return result
rows=[]
for name,data,width in itertools.product([None,b'UTF-8',b'unused'],[b'<r>\x80\0</r>',b'<\x80\0/>',b'<r a="\x80\0"/>'],[0,1,3]):
 rows.append({'name':name.decode() if name else None,'data':data.hex(),'width':width,'reference':probe(REF,name,data,width),'candidate':probe(CAND,name,data,width)})
out={'libraries':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in [REF,CAND]},'cases':len(rows),'differences':sum(r['reference']!=r['candidate']for r in rows),'rows':rows};Path(sys.argv[2]).write_text(json.dumps(out,indent=2)+'\n');print(out['cases'],out['differences'])
