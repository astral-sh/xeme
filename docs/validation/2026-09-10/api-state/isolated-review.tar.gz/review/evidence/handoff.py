from pathlib import Path
import difflib,gzip,hashlib,json,subprocess,shutil,re
root=Path('/tmp/oriole-api-state');out=root/'handoff';out.mkdir(exist_ok=True)
base=json.loads((root/'base.json').read_text());h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
changed=[];chunks=[]
for rel,old in base['sources'].items():
 p=root/rel
 if p.is_file() and h(p)!=old:
  changed.append(rel);before=subprocess.check_output(['git','-C','/home/dev-user/code/oss/oriole','show',base['git']+':'+rel],text=True)
  chunks.append(''.join(difflib.unified_diff(before.splitlines(keepends=True),p.read_text().splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel)))
(out/'api-state.patch').write_text(''.join(chunks))
lib=Path('/home/dev-user/.cache/oriole/api-state-target/debug/liboriole_expat.so')
manifest=dict(base_git=base['git'],changed=changed,sources={r:h(root/r) for r in changed},library=str(lib),library_sha256=h(lib),patch_sha256=h(out/'api-state.patch'))
(out/'source.json').write_text(json.dumps(manifest,indent=2)+'\n')
inputs=['base.json','probe.py','candidate-final.json','baseline.json','lifecycle.py','lifecycle-final.json','lifecycle-baseline.json','converter.py','converter-final.json','converter-baseline.json','upstream.py','upstream/results.json','upstream/reference.log','upstream/baseline.log','upstream/candidate.log','tests-final.log','tests.log','ffi-tests.log','converter-test.log','memory-final.log','clippy-final.log','build-frozen.log','handoff.py']
artifacts=[]
for rel in inputs:
 p=root/rel;target=out/'evidence'/rel;target.parent.mkdir(parents=True,exist_ok=True)
 raw=p.read_bytes()
 if target.suffix in ('.log','.json'):
  target=target.with_suffix(target.suffix+'.gz');target.write_bytes(gzip.compress(raw,mtime=0))
 else:target.write_bytes(raw)
 artifacts.append(dict(source=rel,file=str(target.relative_to(out)),source_sha256=hashlib.sha256(raw).hexdigest(),stored_sha256=h(target)))
a=json.loads((root/'candidate-final.json').read_text());b=json.loads((root/'baseline.json').read_text())
assert len(a['rows'])==len(b['rows'])
regressed=sum(x['reference']==x['candidate'] and y['reference']!=y['candidate']for x,y in zip(b['rows'],a['rows']))
for family in ['lifecycle','converter']:
 old=json.loads((root/(family+'-baseline.json')).read_text());new=json.loads((root/(family+'-final.json')).read_text())
 # All state outside setter results, and all underlying non-setter callback
 # behavior, must be unchanged from the preserved baseline.
 for x,y in zip(old['rows'],new['rows']):
  u=x['candidate'].copy();v=y['candidate'].copy();u.pop('set');v.pop('set')
  if family=='converter':
   u['events']=[e[:2]if e[0]=='convert'else e for e in u['events']];v['events']=[e[:2]if e[0]=='convert'else e for e in v['events']]
  assert u==v
up=json.loads((root/'upstream/results.json').read_text())
review=dict(conclusion='No remaining blocker for this bounded API state change.',source_manifest_sha256=h(out/'source.json'),runtime_library_sha256=h(lib),changes=['XML_SetEncoding accepts initialized and finished/nonresumably aborted adapter states. Completed state copies only requested protocol name using selected allocator before replacing old ownership. Active decoder, pending conversion, positions and release state stay intact.','XML_ParseBuffer with zero length after parsing begins uses XML_Parse on empty input; initialized zero calls and every positive length still require a valid reservation.'],checks=dict(api_cases=98,api_baseline_differences=46,api_final_differences=18,api_formerly_exact_regressions=regressed,lifecycle_cases=30,lifecycle_baseline_differences=30,lifecycle_final_differences=10,converter_abort_cases=27,converter_baseline_differences=27,converter_final_differences=18,lifecycle_and_converter_nonsetter_behavior_identical_to_baseline=True,upstream_reference_passed=108,upstream_baseline_passed=84,upstream_candidate_passed=108,upstream_cases=108,upstream_coverage='9 registered names × 6 chunk modes × 2 deferral modes; requested test_varying_buffer_fills was not registered by the pinned adapter and is excluded, not counted as passing.',tests_log='evidence/tests-final.log.gz',clippy='Strict core/FFI all-targets checks passed.'),retained_differences=['10 API rows expose existing StopParser errorCode timing: Oriole sets ABORTED immediately, Expat later.','8 API rows contain invalid prolog ! and retain existing 2-vs-4 error/deferral differences.','10 lifecycle rows expose existing single-byte custom-map inheritance: Oriole copies the map into an explicitly matching child, while Expat calls UnknownEncoding and release again. Setter changes do not alter the existing callback trace.','18 converter rows expose existing post-abort converter calls/error precedence in Expat name/attribute tokenization. Oriole stops after one conversion; 9 character-data converter rows match exactly.','The first new lifecycle test fixture forgot to restore user data after XML_ParserReset, then installed a text callback and aborted on a null pointer. The test setup was fixed; no runtime change was needed. Initial failed log and successful final checks are retained.'],artifacts=artifacts)
(out/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(manifest,indent=2));print('review',h(out/'review.json'))
