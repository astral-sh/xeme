import ctypes as c,json,hashlib,sys,itertools
from pathlib import Path
P,S,I=c.c_void_p,c.c_char_p,c.c_int
class Encoding(c.Structure):_fields_=[('map',I*256),('data',P),('convert',P),('release',P)]
UNK=c.CFUNCTYPE(I,P,S,c.POINTER(Encoding));REL=c.CFUNCTYPE(None,P);TEXT=c.CFUNCTYPE(None,P,P,I)
REF='/home/dev-user/.cache/oriole/expat-build/libexpat.so';CAND=sys.argv[1];OUT=sys.argv[2]
def probe(path,setting,childencoding,resetencoding):
 l=c.CDLL(path)
 for n,r,a in [('XML_ParserCreate',P,[S]),('XML_ParserFree',None,[P]),('XML_Parse',I,[P,S,I,I]),('XML_SetEncoding',I,[P,S]),('XML_ParserReset',c.c_ubyte,[P,S]),('XML_GetErrorCode',I,[P]),('XML_GetCurrentByteIndex',c.c_long,[P]),('XML_SetUnknownEncodingHandler',None,[P,UNK,P]),('XML_SetCharacterDataHandler',None,[P,TEXT]),('XML_ExternalEntityParserCreate',P,[P,S,S])]:
  f=getattr(l,n);f.restype=r;f.argtypes=a
 events=[]
 @REL
 def release(_):events.append(['release'])
 @UNK
 def unknown(_,name,info):
  events.append(['unknown',name.decode()]);info.contents.map[:]=range(256);info.contents.map[128]=8364;info.contents.release=c.cast(release,P);return 1
 @TEXT
 def text(_,value,n):events.append(['text',c.string_at(value,n).decode()])
 p=l.XML_ParserCreate(b'custom');l.XML_SetUnknownEncodingHandler(p,unknown,None);l.XML_SetCharacterDataHandler(p,text)
 def parse(p,data,final=1):return [l.XML_Parse(p,data,len(data),final),l.XML_GetErrorCode(p),l.XML_GetCurrentByteIndex(p)]
 result={'parse':parse(p,b'<r>\x80</r>')};events.append(['finished']);result['set']=[l.XML_SetEncoding(p,setting),l.XML_GetErrorCode(p),l.XML_GetCurrentByteIndex(p)]
 child=l.XML_ExternalEntityParserCreate(p,b'',childencoding);result['child']=parse(child,b'\x80') if child else None
 if child:l.XML_ParserFree(child)
 result['reset']=l.XML_ParserReset(p,resetencoding);result['resetparse']=parse(p,b'<r>\xc3\xa9</r>');l.XML_ParserFree(p);result['events']=events;return result
rows=[]
for setting,child,reset in itertools.product([None,b'',b'UTF-8',b'ISO-8859-1',b'changed'],[None,b'custom',b'ISO-8859-1'],[None,b'UTF-8']):
 r={'setting':setting.decode() if setting is not None else None,'child':child.decode() if child is not None else None,'reset':reset.decode() if reset is not None else None,'reference':probe(REF,setting,child,reset),'candidate':probe(CAND,setting,child,reset)};rows.append(r)
out={'libraries':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in [REF,CAND]},'cases':len(rows),'differences':sum(r['reference']!=r['candidate']for r in rows),'rows':rows};Path(OUT).write_text(json.dumps(out,indent=2)+'\n');print(out['cases'],out['differences'])
for r in rows:
 if r['reference']!=r['candidate'] and r['setting']=='changed' and r['reset'] is None:print(r)
