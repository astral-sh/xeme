import ctypes as c,json,itertools,hashlib,sys
from pathlib import Path
P=c.c_void_p;S=c.c_char_p;I=c.c_int;START=c.CFUNCTYPE(None,P,S,P)
REF='/home/dev-user/.cache/oriole/expat-build/libexpat.so';CAND=sys.argv[1] if len(sys.argv)>1 else '/tmp/oriole-values-final-source/liboriole_expat.so';OUT=Path(sys.argv[2] if len(sys.argv)>2 else '/tmp/oriole-api-state/baseline.json')
def setup(path):
 l=c.CDLL(path)
 for name,res,args in [('XML_ParserCreate',P,[S]),('XML_ParserFree',None,[P]),('XML_Parse',I,[P,S,I,I]),('XML_ParseBuffer',I,[P,I,I]),('XML_GetBuffer',P,[P,I]),('XML_SetEncoding',I,[P,S]),('XML_StopParser',I,[P,c.c_ubyte]),('XML_ResumeParser',I,[P]),('XML_GetErrorCode',I,[P]),('XML_SetStartElementHandler',None,[P,START]),('XML_SetUserData',None,[P,P]),('XML_ParserReset',c.c_ubyte,[P,S])]:
  f=getattr(l,name);f.restype=res;f.argtypes=args
 return l
libs=[setup(REF),setup(CAND)]
def encoding(l,stage,name):
 p=l.XML_ParserCreate(None); trace=[]
 @START
 def start(_,element,attrs):
  if stage in ('abort-callback','suspend-callback'):
   trace.append(['stop',l.XML_StopParser(p,int(stage=='suspend-callback')),l.XML_GetErrorCode(p)])
   trace.append(['set-inside',l.XML_SetEncoding(p,name),l.XML_GetErrorCode(p)])
 l.XML_SetStartElementHandler(p,start)
 if stage=='invalid-api':trace.append(['api',l.XML_ParseBuffer(p,0,0),l.XML_GetErrorCode(p)])
 if stage in ('empty','partial','nonfinal','finished','bad','abort-callback','suspend-callback','abort-outside'):
  data={'empty':b'','partial':b'<r>','nonfinal':b'<r/>','finished':b'<r/>','bad':b'<r>','abort-callback':b'<r/>','suspend-callback':b'<r/>','abort-outside':b'<r>'}[stage]
  trace.append(['parse',l.XML_Parse(p,data,len(data),int(stage in ('finished','bad','abort-callback','suspend-callback'))),l.XML_GetErrorCode(p)])
 if stage=='abort-outside':trace.append(['stop',l.XML_StopParser(p,0),l.XML_GetErrorCode(p)])
 trace.append(['set',l.XML_SetEncoding(p,name),l.XML_GetErrorCode(p)])
 if stage=='suspend-callback':trace.append(['resume',l.XML_ResumeParser(p),l.XML_GetErrorCode(p)]);trace.append(['set-resumed',l.XML_SetEncoding(p,name),l.XML_GetErrorCode(p)])
 trace.append(['reset',l.XML_ParserReset(p,None),l.XML_GetErrorCode(p)])
 doc=b'<r>\xc3\xa9</r>';trace.append(['parse-reset',l.XML_Parse(p,doc,len(doc),1),l.XML_GetErrorCode(p)])
 l.XML_ParserFree(p);return trace
rows=[]
for stage,name in itertools.product(['new','invalid-api','empty','partial','nonfinal','finished','bad','abort-callback','suspend-callback','abort-outside'],[None,b'',b'UTF-8',b'ISO-8859-1',b'custom']):
 results=[encoding(l,stage,name)for l in libs];rows.append({'stage':stage,'name':name.decode() if name is not None else None,'reference':results[0],'candidate':results[1]})
# A zero-length buffer parse consumes no new bytes and can finish pending decoder work.
for data,initial_final,reserve,final in itertools.product([b'',b'<r>',b'<r/>',b'<r></r>\xe2\x82',b'<r>&amp',b'!'],[0,1],[False,True],[0,1]):
 results=[]
 for l in libs:
  p=l.XML_ParserCreate(None);r=[]
  if reserve:r.append(['reserve',bool(l.XML_GetBuffer(p,0)),l.XML_GetErrorCode(p)])
  r.append(['parse',l.XML_Parse(p,data,len(data),initial_final),l.XML_GetErrorCode(p)])
  r.append(['buffer',l.XML_ParseBuffer(p,0,final),l.XML_GetErrorCode(p)])
  l.XML_ParserFree(p);results.append(r)
 rows.append({'data':data.hex(),'initial_final':initial_final,'reserve':reserve,'final':final,'reference':results[0],'candidate':results[1]})
report={'libraries':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in (REF,CAND)},'cases':len(rows),'differences':sum(r['reference']!=r['candidate']for r in rows),'rows':rows};OUT.write_text(json.dumps(report,indent=2)+'\n');print(report['cases'],report['differences'])
for r in rows:
 if r.get('name')=='UTF-8':print(r['stage'],r['reference'],r['candidate'])
