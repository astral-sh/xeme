import ctypes as c,hashlib,json,os,subprocess
from pathlib import Path
out=Path('/tmp/oriole-api-state/upstream');out.mkdir(exist_ok=True)
runner=Path('/tmp/oriole-upstream-final-values/runtests')
libs={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','baseline':'/tmp/oriole-values-final-source/liboriole_expat.so','candidate':'/home/dev-user/.cache/oriole/api-state-target/debug/liboriole_expat.so'}
names=['test_explicit_encoding','test_partial_char_in_epilog','test_ext_entity_set_encoding','test_negative_len_parse_buffer','test_get_buffer_1','test_get_buffer_2','test_getbuffer_allocates_on_zero_len','test_resume_invalid_parse','test_suspend_in_sole_empty_tag','test_varying_buffer_fills']
reports={}
for name,path in libs.items():
 env=os.environ.copy();env.update(LD_PRELOAD=path,ORIOLE_CHUNK_MASK='63',ORIOLE_DEFERRAL_MASK='3',ORIOLE_TEST_TIMEOUT='3',ORIOLE_MEMORY_MIB='1024',ORIOLE_RSS_MIB='768',ORIOLE_SELECTED_TESTS=','.join(names))
 # Verify process-global symbol resolution with the exact LD_PRELOAD selection.
 check='''import ctypes as c,json
class Dl(c.Structure):_fields_=[('file',c.c_char_p),('base',c.c_void_p),('name',c.c_char_p),('addr',c.c_void_p)]
l=c.CDLL(None); d=Dl(); l.dladdr.argtypes=[c.c_void_p,c.POINTER(Dl)]; assert l.dladdr(c.cast(l.XML_Parse,c.c_void_p),c.byref(d)); print(d.file.decode())'''
 resolved=subprocess.check_output(['python3','-c',check],env=env,text=True).strip();assert Path(resolved).resolve()==Path(path).resolve()
 with (out/f'{name}.log').open('w')as f:p=subprocess.run(['taskset','-c','4',str(runner),'--verbose'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=60)
 rows=[]
 for line in (out/f'{name}.log').read_text().splitlines():
  if line.startswith('ORIOLE_RESULT\t'):
   _,context,test,status,code=line.split('\t');rows.append(dict(context=context,test=test,status=status,code=int(code)))
 reports[name]=dict(library=path,library_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),resolved=resolved,returncode=p.returncode,count=len(rows),passed=sum(r['status']=='pass'for r in rows),rows=rows)
 print(name,len(rows),reports[name]['passed'],p.returncode)
(out/'results.json').write_text(json.dumps(dict(runner=str(runner),runner_sha256=hashlib.sha256(runner.read_bytes()).hexdigest(),runner_manifest='/tmp/oriole-upstream-final-values/manifest.json',tests=names,limits=dict(memory_mib=1024,rss_mib=768,per_test_seconds=3,overall_seconds=60),results=reports),indent=2)+'\n')
