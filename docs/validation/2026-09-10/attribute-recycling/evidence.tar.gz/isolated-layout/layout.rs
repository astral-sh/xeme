#![allow(dead_code)]
use oriole_storage::{String, Vec, Box, Text, Allocator};
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct Position {
    pub byte_index: usize,
    pub line: usize,
    pub column: usize,
    pub byte_count: usize,
}

mod original { use super::*;
#[derive(Debug, Eq, PartialEq)]
pub struct Attribute {
    pub name: String,
    pub value: String,
    pub specified: bool,
}

#[derive(Debug, Eq, PartialEq)]
pub struct Event {
    pub kind: EventKind,
    pub position: Position,
}

#[derive(Debug, Eq, PartialEq)]
pub enum EventKind {
    /// Opt-in whitespace callback outside element content. Read [`Parser::current_raw`]
    /// before advancing the parser; this event does not own the raw token.
    Default,
    /// Raw declaration bytes delivered only when no entity declaration handler
    /// is installed by a compatibility consumer.
    EntityDeclarationPrefix,
    /// Raw declaration bytes delivered only when no attribute declaration
    /// handler is installed by a compatibility consumer.
    AttlistDeclarationPrefix,
    /// Raw declaration bytes delivered only when no element declaration handler
    /// is installed by a compatibility consumer.
    ElementDeclarationPrefix,
    /// Raw declaration bytes delivered only when no notation declaration handler
    /// is installed by a compatibility consumer.
    NotationDeclarationPrefix,
    /// An ignored duplicate entity declaration, available with default events.
    EntityDeclarationDuplicate {
        external: bool,
        unparsed: bool,
    },
    StartElement {
        name: String,
        attributes: Vec<Attribute>,
    },
    EndElement {
        name: String,
    },
    /// Owned immutable character data. Short values are stored inline.
    Text(Text),
    Comment(String),
    ProcessingInstruction {
        target: String,
        data: String,
    },
    StartCdata,
    EndCdata,
    XmlDeclaration {
        version: String,
        encoding: Option<String>,
        standalone: Option<bool>,
    },
    TextDeclaration {
        version: Option<String>,
        encoding: String,
    },
    ExternalEntityReference {
        context: Option<String>,
        system_id: Option<String>,
        public_id: Option<String>,
    },
    StartDoctype {
        name: String,
        system_id: Option<String>,
        public_id: Option<String>,
        has_internal_subset: bool,
    },
    EndDoctype,
    NotStandalone,
    StartNamespace {
        prefix: Option<String>,
        uri: Option<String>,
    },
    EndNamespace {
        prefix: Option<String>,
    },
    EntityDeclaration {
        name: String,
        value: Option<String>,
        parameter: bool,
        system_id: Option<String>,
        public_id: Option<String>,
        notation: Option<String>,
    },
    AttlistDeclaration {
        element: String,
        name: String,
        attribute_type: String,
        default: Option<String>,
        required: bool,
    },
    NotationDeclaration {
        name: String,
        system_id: Option<String>,
        public_id: Option<String>,
    },
    ElementDeclaration {
        name: String,
        model: String,
    },
    SkippedEntity {
        name: String,
        parameter: bool,
    },
}


#[derive(Debug)] struct PendingEvent { event: Event, raw: Option<String> }
pub fn print() { println!("original EventKind={} Event={} OptionEvent={} ResultEvent={} PendingEvent={}", size_of::<EventKind>(), size_of::<Event>(), size_of::<Option<Event>>(), size_of::<Result<Option<Event>, [usize; 7]>>(), size_of::<PendingEvent>()); } }
mod entity { use super::*;
#[derive(Debug, Eq, PartialEq)]
pub struct EntityDeclaration {
        name: String,
        value: Option<String>,
        parameter: bool,
        system_id: Option<String>,
        public_id: Option<String>,
        notation: Option<String>,
}
#[derive(Debug, Eq, PartialEq)]
pub struct Attribute {
    pub name: String,
    pub value: String,
    pub specified: bool,
}

#[derive(Debug, Eq, PartialEq)]
pub struct Event {
    pub kind: EventKind,
    pub position: Position,
}

#[derive(Debug, Eq, PartialEq)]
pub enum EventKind {
    /// Opt-in whitespace callback outside element content. Read [`Parser::current_raw`]
    /// before advancing the parser; this event does not own the raw token.
    Default,
    /// Raw declaration bytes delivered only when no entity declaration handler
    /// is installed by a compatibility consumer.
    EntityDeclarationPrefix,
    /// Raw declaration bytes delivered only when no attribute declaration
    /// handler is installed by a compatibility consumer.
    AttlistDeclarationPrefix,
    /// Raw declaration bytes delivered only when no element declaration handler
    /// is installed by a compatibility consumer.
    ElementDeclarationPrefix,
    /// Raw declaration bytes delivered only when no notation declaration handler
    /// is installed by a compatibility consumer.
    NotationDeclarationPrefix,
    /// An ignored duplicate entity declaration, available with default events.
    EntityDeclarationDuplicate {
        external: bool,
        unparsed: bool,
    },
    StartElement {
        name: String,
        attributes: Vec<Attribute>,
    },
    EndElement {
        name: String,
    },
    /// Owned immutable character data. Short values are stored inline.
    Text(Text),
    Comment(String),
    ProcessingInstruction {
        target: String,
        data: String,
    },
    StartCdata,
    EndCdata,
    XmlDeclaration {
        version: String,
        encoding: Option<String>,
        standalone: Option<bool>,
    },
    TextDeclaration {
        version: Option<String>,
        encoding: String,
    },
    ExternalEntityReference {
        context: Option<String>,
        system_id: Option<String>,
        public_id: Option<String>,
    },
    StartDoctype {
        name: String,
        system_id: Option<String>,
        public_id: Option<String>,
        has_internal_subset: bool,
    },
    EndDoctype,
    NotStandalone,
    StartNamespace {
        prefix: Option<String>,
        uri: Option<String>,
    },
    EndNamespace {
        prefix: Option<String>,
    },
    EntityDeclaration(Box<EntityDeclaration>),
    AttlistDeclaration {
        element: String,
        name: String,
        attribute_type: String,
        default: Option<String>,
        required: bool,
    },
    NotationDeclaration {
        name: String,
        system_id: Option<String>,
        public_id: Option<String>,
    },
    ElementDeclaration {
        name: String,
        model: String,
    },
    SkippedEntity {
        name: String,
        parameter: bool,
    },
}


#[derive(Debug)] struct PendingEvent { event: Event, raw: Option<String> }
pub fn print() { println!("entity EventKind={} Event={} OptionEvent={} ResultEvent={} PendingEvent={}", size_of::<EventKind>(), size_of::<Event>(), size_of::<Option<Event>>(), size_of::<Result<Option<Event>, [usize; 7]>>(), size_of::<PendingEvent>()); } }
mod two { use super::*;
#[derive(Debug, Eq, PartialEq)]
pub struct EntityDeclaration {
        name: String,
        value: Option<String>,
        parameter: bool,
        system_id: Option<String>,
        public_id: Option<String>,
        notation: Option<String>,
}
#[derive(Debug, Eq, PartialEq)]
pub struct AttlistDeclaration {
        element: String,
        name: String,
        attribute_type: String,
        default: Option<String>,
        required: bool,
}
#[derive(Debug, Eq, PartialEq)]
pub struct Attribute {
    pub name: String,
    pub value: String,
    pub specified: bool,
}

#[derive(Debug, Eq, PartialEq)]
pub struct Event {
    pub kind: EventKind,
    pub position: Position,
}

#[derive(Debug, Eq, PartialEq)]
pub enum EventKind {
    /// Opt-in whitespace callback outside element content. Read [`Parser::current_raw`]
    /// before advancing the parser; this event does not own the raw token.
    Default,
    /// Raw declaration bytes delivered only when no entity declaration handler
    /// is installed by a compatibility consumer.
    EntityDeclarationPrefix,
    /// Raw declaration bytes delivered only when no attribute declaration
    /// handler is installed by a compatibility consumer.
    AttlistDeclarationPrefix,
    /// Raw declaration bytes delivered only when no element declaration handler
    /// is installed by a compatibility consumer.
    ElementDeclarationPrefix,
    /// Raw declaration bytes delivered only when no notation declaration handler
    /// is installed by a compatibility consumer.
    NotationDeclarationPrefix,
    /// An ignored duplicate entity declaration, available with default events.
    EntityDeclarationDuplicate {
        external: bool,
        unparsed: bool,
    },
    StartElement {
        name: String,
        attributes: Vec<Attribute>,
    },
    EndElement {
        name: String,
    },
    /// Owned immutable character data. Short values are stored inline.
    Text(Text),
    Comment(String),
    ProcessingInstruction {
        target: String,
        data: String,
    },
    StartCdata,
    EndCdata,
    XmlDeclaration {
        version: String,
        encoding: Option<String>,
        standalone: Option<bool>,
    },
    TextDeclaration {
        version: Option<String>,
        encoding: String,
    },
    ExternalEntityReference {
        context: Option<String>,
        system_id: Option<String>,
        public_id: Option<String>,
    },
    StartDoctype {
        name: String,
        system_id: Option<String>,
        public_id: Option<String>,
        has_internal_subset: bool,
    },
    EndDoctype,
    NotStandalone,
    StartNamespace {
        prefix: Option<String>,
        uri: Option<String>,
    },
    EndNamespace {
        prefix: Option<String>,
    },
    EntityDeclaration(Box<EntityDeclaration>),
    AttlistDeclaration(Box<AttlistDeclaration>),
    NotationDeclaration {
        name: String,
        system_id: Option<String>,
        public_id: Option<String>,
    },
    ElementDeclaration {
        name: String,
        model: String,
    },
    SkippedEntity {
        name: String,
        parameter: bool,
    },
}


#[derive(Debug)] struct PendingEvent { event: Event, raw: Option<String> }
pub fn print() { println!("two EventKind={} Event={} OptionEvent={} ResultEvent={} PendingEvent={}", size_of::<EventKind>(), size_of::<Event>(), size_of::<Option<Event>>(), size_of::<Result<Option<Event>, [usize; 7]>>(), size_of::<PendingEvent>()); } }
mod five { use super::*;
#[derive(Debug, Eq, PartialEq)]
pub struct EntityDeclaration {
        name: String,
        value: Option<String>,
        parameter: bool,
        system_id: Option<String>,
        public_id: Option<String>,
        notation: Option<String>,
}
#[derive(Debug, Eq, PartialEq)]
pub struct AttlistDeclaration {
        element: String,
        name: String,
        attribute_type: String,
        default: Option<String>,
        required: bool,
}
#[derive(Debug, Eq, PartialEq)]
pub struct StartDoctype {
        name: String,
        system_id: Option<String>,
        public_id: Option<String>,
        has_internal_subset: bool,
}
#[derive(Debug, Eq, PartialEq)]
pub struct NotationDeclaration {
        name: String,
        system_id: Option<String>,
        public_id: Option<String>,
}
#[derive(Debug, Eq, PartialEq)]
pub struct ExternalEntityReference {
        context: Option<String>,
        system_id: Option<String>,
        public_id: Option<String>,
}
#[derive(Debug, Eq, PartialEq)]
pub struct Attribute {
    pub name: String,
    pub value: String,
    pub specified: bool,
}

#[derive(Debug, Eq, PartialEq)]
pub struct Event {
    pub kind: EventKind,
    pub position: Position,
}

#[derive(Debug, Eq, PartialEq)]
pub enum EventKind {
    /// Opt-in whitespace callback outside element content. Read [`Parser::current_raw`]
    /// before advancing the parser; this event does not own the raw token.
    Default,
    /// Raw declaration bytes delivered only when no entity declaration handler
    /// is installed by a compatibility consumer.
    EntityDeclarationPrefix,
    /// Raw declaration bytes delivered only when no attribute declaration
    /// handler is installed by a compatibility consumer.
    AttlistDeclarationPrefix,
    /// Raw declaration bytes delivered only when no element declaration handler
    /// is installed by a compatibility consumer.
    ElementDeclarationPrefix,
    /// Raw declaration bytes delivered only when no notation declaration handler
    /// is installed by a compatibility consumer.
    NotationDeclarationPrefix,
    /// An ignored duplicate entity declaration, available with default events.
    EntityDeclarationDuplicate {
        external: bool,
        unparsed: bool,
    },
    StartElement {
        name: String,
        attributes: Vec<Attribute>,
    },
    EndElement {
        name: String,
    },
    /// Owned immutable character data. Short values are stored inline.
    Text(Text),
    Comment(String),
    ProcessingInstruction {
        target: String,
        data: String,
    },
    StartCdata,
    EndCdata,
    XmlDeclaration {
        version: String,
        encoding: Option<String>,
        standalone: Option<bool>,
    },
    TextDeclaration {
        version: Option<String>,
        encoding: String,
    },
    ExternalEntityReference(Box<ExternalEntityReference>),
    StartDoctype(Box<StartDoctype>),
    EndDoctype,
    NotStandalone,
    StartNamespace {
        prefix: Option<String>,
        uri: Option<String>,
    },
    EndNamespace {
        prefix: Option<String>,
    },
    EntityDeclaration(Box<EntityDeclaration>),
    AttlistDeclaration(Box<AttlistDeclaration>),
    NotationDeclaration(Box<NotationDeclaration>),
    ElementDeclaration {
        name: String,
        model: String,
    },
    SkippedEntity {
        name: String,
        parameter: bool,
    },
}


#[derive(Debug)] struct PendingEvent { event: Event, raw: Option<String> }
pub fn print() { println!("five EventKind={} Event={} OptionEvent={} ResultEvent={} PendingEvent={}", size_of::<EventKind>(), size_of::<Event>(), size_of::<Option<Event>>(), size_of::<Result<Option<Event>, [usize; 7]>>(), size_of::<PendingEvent>()); } }
fn main() { println!("String={} OptionString={} Allocator={} Box={} Vec={} Text={} Attribute={}", size_of::<String>(),size_of::<Option<String>>(),size_of::<Allocator>(),size_of::<Box<usize>>(),size_of::<Vec<original::Attribute>>(),size_of::<Text>(),size_of::<original::Attribute>()); original::print();entity::print();two::print();five::print(); }
