import hashlib,json,tarfile,shutil,statistics,math,re
from pathlib import Path
w=Path('/tmp/oriole-recycling-layout');d=Path('docs/validation/2026-09-10/attribute-recycling');d.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((w/'source.json').read_text());api=json.loads((w/'upstream-api/results.json').read_text());bench=json.loads((w/'native-projects/summary.json').read_text());native=json.loads((w/'native.json').read_text());comparison=json.loads((w/'api-comparison.json').read_text())
assert api['selection_complete'] and api['library_origin_verified'] and not api['timed_out'] and len(api['results'])==4740
assert bench['status']=='passed' and len(bench['summary'])==24 and all(x['returncode']==0 for x in native['runs']) and len(native['runs'])==6
assert len(comparison['fixed'])==12 and not comparison['regressed']
tests=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(w/'tests.log').read_text())));assert tests==279
groups={}
for key,value in bench['summary'].items():groups.setdefault(key.split('/',1)[1],[]).append(1/value['median_expat_over_oriole'])
geomeans={k:math.prod(v)**(1/len(v)) for k,v in groups.items()}
summary={'rust_tests':tests,'library_sha256':s['library_sha256'],'upstream_api':{k:api[k] for k in ['passed','failed','selection_complete','library_origin_verified','timed_out']},'fixed_configurations':len(comparison['fixed']),'regressed_configurations':len(comparison['regressed']),'native_safety_runs':6,'injected_allocations_per_linkage':341,'differential_exact_cases':1518,'native_project_conditions':24,'native_project_processes':336,'geometric_mean_slowdown_vs_expat':geomeans,'layout_bytes':{'before':320,'after':152},'performance_goal':'Unmet: every project/configuration remains slower than Expat.'};(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
# Keep build observations immutable after timing; test completion belongs here.
(w/'validation.json').write_text(json.dumps(summary,indent=2)+'\n')
for directory,label,names in [('/tmp/oriole-recycling-integrated','initial-recycling',['source.json','source.patch','tests.log','clippy.log','screen.py','screen.json','screen.log','review.json','callgrind-wayland.txt','callgrind-wayland.log']),('/tmp/oriole-recycling-inline','inline-wrapper',['source.json','source.patch','build.log','screen.py','screen.json','screen.log']),('/tmp/oriole-event-layout','isolated-layout',['manifest.json','event-layout.patch','independent-review.json','screening-summary.json','screening.json','final-clippy.log','core-tests.log','ffi-tests.log','actual-layout.txt','layout.rs'])]:
 target=w/label;target.mkdir(exist_ok=True)
 for name in names:
  source=Path(directory)/name
  assert source.is_file(),source
  shutil.copy2(source,target/name)
files={}
for p in sorted(w.rglob('*')):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 files[str(p.relative_to(w))]={'sha256':sha(p),'bytes':p.stat().st_size}
with tarfile.open(d/'evidence.tar.gz','w:gz',compresslevel=9) as tar:
 for n in files:tar.add(w/n,arcname=n,recursive=False)
with tarfile.open(d/'evidence.tar.gz') as tar:
 for m in tar:assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==files[m.name]['sha256']
manifest={'archive_sha256':sha(d/'evidence.tar.gz'),'members':files};(d/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
(d/'README.md').write_text(f'''# Attribute storage reuse and smaller events

The C adapter returns original attribute buffers to the parser after each callback. Reuse is opt-in for safe Rust consumers; ordinary events remain independently owned. A consumed generation token rejects accidental foreign-parser or stale-reset returns. Retention is capped at 128 vector slots, 4 KiB per string and 64 KiB total capacity; a separate raw-offset scratch vector is capped at 4 KiB. Recycling never allocates. Every buffer retains its original selected allocator.

Five rare DTD/external-entity payloads move into fallible allocator-aware boxes, reducing the measured 64-bit `Event` size from 320 to 152 bytes. Common events stay inline. This changes those safe Rust enum variants to typed boxed payloads; the C ABI is unchanged. The adapter wrapper is forced inline to avoid an additional large event copy.

The exact integrated release library is `{s['library_sha256']['liboriole_expat.so']}`. All **279 Rust checks**, strict affected-package Clippy and formatting pass; the CLI also checks with its system-allocator feature selection. Allocation probes cover every failure point, retained events, reset, suspension and callback reentry. Six C ASan/UBSan suites pass with 341 injected allocation scenarios per linkage. Rust is uninstrumented in those C runs; LSan is disabled and selected-allocation live counts are asserted separately.

The exact 1,518-case generated replay is unchanged. The unmodified 4,740-configuration API matrix improves from 3,991/749 to **4,003 passes and 737 failures**: all 12 `test_nsalloc_xmlns` configurations now fit their original retry ceiling, with zero regressions. No upstream assertion was waived. Independent reviews cover the bounded recycling design and boxed-payload ownership.

The complete six-project native benchmark checks full normalized callbacks before 336 randomized timed processes across namespace-off/on and 4/64 KiB feeds. Every timed output hash/count matches its independent preflight. Seven process pairs use 20 measured parses after one warmup. Equal-project geometric mean slowdowns versus Expat remain **3.44–3.78×**; every project/configuration is still slower. These are original project inputs parsed through the native ABI, not complete application timings. The performance goal remains unmet.

Earlier screens are retained: recycling alone was mixed and sometimes slower despite reducing allocations; inlining the wrapper recovered most of that overhead. Combining reuse with smaller events improves 11 of 12 short-screen conditions by about 2–15%; the final DocBook namespace condition had large timing variability affecting all three libraries. The longer full benchmark records all samples rather than discarding that earlier observation. The isolated rare-event study includes a declaration-heavy adverse fixture with a small slowdown. Shared-host frequency/load remain uncontrolled, so no universal speedup is claimed.

[evidence.tar.gz](evidence.tar.gz) includes immutable source/build metadata, exact raw observations, rejected/intermediate screens and scoped independent reviews. ELF binaries/static archives are excluded and identified by hash. [files.json](files.json) verifies all archive members; [summary.json](summary.json) gives compact results. Archive SHA256: `{manifest['archive_sha256']}`.
''')
print(json.dumps({'tests':tests,'api':[api['passed'],api['failed']],'geomeans':geomeans,'members':len(files),'archive_bytes':(d/'evidence.tar.gz').stat().st_size,'archive_sha256':manifest['archive_sha256']},indent=2))
