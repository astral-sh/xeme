# Preserve replacement whitespace and diagnose unparsed attribute entities

Apply `candidate.patch` after the iterative attribute patch. Exact prerequisites and file hashes are in `source.json`; apply-check against the frozen previous source passes. No shared root files were edited.

Patch SHA-256: `fe453cd14596247794223455c1da1cbbf02824d5bb01bd7dbe3d17d675651b2f`.
Frozen debug library SHA-256: `678021fffd50ad2b146d6ef51fea8203dfa14f3a4cb2a6d2bd6a9dcdd5a2eac3`.

## Behavior

- Physical CR/LF inside an attribute still becomes one space. CR and LF stored in an entity replacement are independent characters: they become two spaces. Direct numeric references in the current attribute still produce literal CR/LF. Root attribute callers pass whether their source is physical; nested entity frames always disable physical-line-ending folding.
- Default attribute literals use their recorded composition flag, falling back to `sources.len() == 1` when no override exists. This fixes whole ATTLIST declarations supplied by internal parameter entities. The existing false-flag prepass is retained.
- An NDATA/unparsed entity used in an attribute now reports `BinaryEntityReference` (Expat error15), before the ordinary external-value absence check. Earlier cycle/depth/declaration-origin checks retain their existing order.
- Absolute limits, relative accounting operations, selected allocator ownership, and frame lifetimes are unchanged.

## Validation

- 261 affected Rust checks pass, including seven attribute tests, the 60,000-level small-stack test, all amplification tests, exhaustive custom allocator failures, no-global-allocation checks, and C allocator reentry checks.
- The custom allocator workload now includes a whole-parameter-entity default with numeric CR/LF so the added normalization allocation can fail at every point.
- Strict Clippy and formatting pass. 96 selected upstream API configurations pass with verified library origin.
- All 6,468 standard oracle conditions match pinned Expat in acceptance, error codes, attribute/default callbacks and child outcomes. This corrects 1,200 configurations compared with the frozen iterative baseline. The remaining 2,580 reference position differences are pre-existing and are counted separately.
- Independent source review reports no blocker; exact reviewed lib.rs and dtd.rs hashes match the frozen files. See `independent-review.json`.
- Full API matrix, release benchmarks and sanitizers were not run on this isolated candidate.

## Custom provenance integration

The isolated source predates the custom lexical-Slice patch, so the final combined runtime must rerun the custom oracle. The API author confirmed neither correction was included in its final d89f839 source.

`alias_oracle.py CANDIDATE_SO OUTPUT_JSON` runs 132 conditions: CDATA/NMTOKENS, whole/1/2-byte chunks, namespace modes, direct converted CR/LF, mixed raw/converted line endings, entity values, internal-source attributes, and defaults supplied by parameter entities. It uses an application-defined two-byte conversion and performs no external I/O. Run with clean uv Python (`python3 -I -S` from the uv installation), since system Python may preload another Expat.

The exact final provenance baseline `/tmp/oriole-custom-final/liboriole_expat.so`, SHA-256 `beeab4e40f8cf11164f73ac5d50cfa169a3da5c8bfd0e984a10bca0f2912bd5a`, has 30 differences, all CDATA replacement CR/LF. The other 102 cases already match. `alias-provenance-baseline.json` records that evidence; `alias-experiment-baseline.json` is an older rejected-performance-experiment probe and is not the final baseline.

When merging:

1. Preserve `Slice::decoded_chars` and its `raw_ascii` flag. Direct converted CR/LF remains literal data; physical-line normalization must only recognize raw ASCII. Materialized replacement strings use `Slice::plain` and must disable CR/LF pairing.
2. Pass the physical-line-ending flag through both the fast CDATA normalization path and iterative append path. In the latter it applies only when the frame stack is empty. Tokenized normalization already coalesces raw whitespace across entity boundaries; keep the API author's logic intact.
3. Use the source-depth fallback for default literals with no composition override. Preserve explicit `Some(true)`/`Some(false)` origin metadata, the existing default prepass, and its lexical view restoration.
4. For the preceding iterative patch, carry parent lexical slices in frames and use stable entity map keys after decoded lookup, avoiding a borrow of a temporary decoded name. Keep root's recycled output ownership and sticky entity-state checks.

Runtime source evidence: pinned Expat xmlparse.c storeAttributeValue/appendAttributeValue around lines6602–6860. It preserves internal replacement whitespace and checks notation before ordinary external-entity rejection. No Expat implementation code was copied.
