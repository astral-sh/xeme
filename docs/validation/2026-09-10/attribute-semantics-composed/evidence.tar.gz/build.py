from pathlib import Path
import os,subprocess,json,hashlib,shutil,re,time
r=Path('/home/dev-user/code/oss/oriole');w=Path('/tmp/oriole-attribute-integrated');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env={**os.environ,'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/target','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST':'all','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all','CARGO_BUILD_JOBS':'2'}
files=[r/'Cargo.toml',r/'Cargo.lock',*(r/'crates').rglob('*.rs'),*(r/'crates').rglob('Cargo.toml'),*(r/'tests/c').glob('*.c'),r/'include/expat.h'];before={str(p.relative_to(r)):sha(p) for p in sorted(files)};commands=[]
try:
 for label,args in [('tests',['test','--release','-p','oriole','-p','oriole_expat']),('clippy',['clippy','--release','-p','oriole','-p','oriole_expat','--all-targets','--','-D','warnings']),('fmt',['fmt','--all','--','--check']),('build',['build','--release','-p','oriole_expat'])]:
  command=['cargo','+ohm',*args];start=time.time()
  with (w/(label+'.log')).open('w') as f:p=subprocess.run(command,cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
  row={'label':label,'command':command,'exit_code':p.returncode,'seconds':time.time()-start,'log_sha256':sha(w/(label+'.log'))};commands.append(row);print(json.dumps(row),flush=True);assert not p.returncode
 after={str(p.relative_to(r)):sha(p) for p in sorted(files)};assert before==after
 for f in ['liboriole_expat.so','liboriole_expat.a']:shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'release'/f,w/f)
 manifest={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'source_sha256':before,'library_sha256':{f:sha(w/f) for f in ['liboriole_expat.so','liboriole_expat.a']},'commands':commands,'profile':'release; repository defaults; Ohm local defaults','rustc':subprocess.check_output(['rustc','+ohm','-Vv'],env=env,text=True),'rust_checks':sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(w/'tests.log').read_text())))}
 (w/'source.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'library_sha256':manifest['library_sha256'],'rust_checks':manifest['rust_checks']}),flush=True)
finally:(w/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
