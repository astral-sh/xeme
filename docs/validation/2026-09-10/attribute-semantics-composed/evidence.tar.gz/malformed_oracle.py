"""Check diagnostic precedence when default normalization no longer pre-materializes text."""
import hashlib,importlib.util,itertools,json,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('support','/tmp/oriole-attribute-integrated/oracle.py');support=importlib.util.module_from_spec(spec);spec.loader.exec_module(support)
paths={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','baseline':'/tmp/oriole-iterative-integrated/liboriole_expat.so','candidate':sys.argv[1]};libs={k:support.setup(v) for k,v in paths.items()}
rows=[]
for tail,context,encoding,chunk,namespace in itertools.product(['&bad\r\nname;','&#1\r\n;','&#x\r\n;','&missing;','<bad','&#0;','&amp','&#x110000;'],['direct','default','parameter-default','internal-attribute'],['utf-8','utf-16'],[0,1,7],[False,True]):
 value='A&#13;&#10;'+tail
 if context=='direct':xml=f"<r a='{value}'/>"
 elif context=='default':xml=f"<!DOCTYPE r [<!ATTLIST r a CDATA '{value}'>]><r/>"
 elif context=='parameter-default':xml=f'''<!DOCTYPE r [<!ENTITY % p "<!ATTLIST r a CDATA '{value}'>">%p;]><r/>'''
 else:xml=f'''<!DOCTYPE r [<!ENTITY e "<r a='{value}'/>">]><outer>&e;</outer>'''
 results={k:support.run(lib,xml,{},chunk,encoding,namespace,100,8*1024*1024) for k,lib in libs.items()}
 rows.append({'tail':tail,'context':context,'xml':xml,'encoding':encoding,'chunk':chunk,'namespace':namespace,'results':results})
counts={'conditions':len(rows),'baseline_changes':sum(r['results']['baseline']!=r['results']['candidate'] for r in rows),'reference_result_differences':sum(r['results']['reference']['result']!=r['results']['candidate']['result'] for r in rows)}
report={'counts':counts,'rows':rows,'libraries':{k:{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for k,p in paths.items()}}
Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n');print(counts)
