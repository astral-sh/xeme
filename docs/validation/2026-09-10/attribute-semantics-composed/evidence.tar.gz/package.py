"""Archive a completed local checkpoint after its owner validates assertions."""
from pathlib import Path
import hashlib,json,tarfile,sys
w=Path(sys.argv[1]);d=Path(sys.argv[2]);d.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={}
for p in sorted(w.rglob('*')):
 if not p.is_file() or p.is_symlink() or '__pycache__' in p.parts:continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 files[str(p.relative_to(w))]={'sha256':sha(p),'bytes':p.stat().st_size}
with tarfile.open(d/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for f in files:t.add(w/f,arcname=f,recursive=False)
with tarfile.open(d/'evidence.tar.gz') as t:
 for f in t:assert hashlib.sha256(t.extractfile(f).read()).hexdigest()==files[f.name]['sha256']
m={'archive_sha256':sha(d/'evidence.tar.gz'),'members':files};(d/'files.json').write_text(json.dumps(m,indent=2)+'\n')
for n in ['README.md','report.json']:(d/n).write_bytes((w/n).read_bytes())
print(json.dumps({'members':len(files),'archive_bytes':(d/'evidence.tar.gz').stat().st_size,'archive_sha256':m['archive_sha256']}))
