"""Custom physical/aliased/replacement CRLF oracle for provenance integration."""
import ctypes as c
import hashlib,itertools,json,sys
from pathlib import Path
assert not any(line.rsplit('/',1)[-1].startswith('libexpat.') for line in Path('/proc/self/maps').read_text().splitlines())
START=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.POINTER(c.c_char_p))
CONVERT=c.CFUNCTYPE(c.c_int,c.c_void_p,c.c_void_p)
RELEASE=c.CFUNCTYPE(None,c.c_void_p)
class Encoding(c.Structure):
 _fields_=[('map',c.c_int*256),('data',c.c_void_p),('convert',CONVERT),('release',RELEASE)]
UNKNOWN=c.CFUNCTYPE(c.c_int,c.c_void_p,c.c_char_p,c.POINTER(Encoding))
def setup(path):
 lib=c.CDLL(path)
 for name,args,result in [('XML_ParserCreate',[c.c_char_p],c.c_void_p),('XML_ParserCreateNS',[c.c_char_p,c.c_char],c.c_void_p),('XML_SetParamEntityParsing',[c.c_void_p,c.c_int],c.c_int),('XML_SetUnknownEncodingHandler',[c.c_void_p,UNKNOWN,c.c_void_p],None),('XML_SetStartElementHandler',[c.c_void_p,START],None),('XML_Parse',[c.c_void_p,c.c_char_p,c.c_int,c.c_int],c.c_int),('XML_GetErrorCode',[c.c_void_p],c.c_int),('XML_ParserFree',[c.c_void_p],None)]:
  f=getattr(lib,name);f.argtypes=args;f.restype=result
 return lib

def run(lib,raw,chunk,namespace):
 parser=lib.XML_ParserCreateNS(None,b'|') if namespace else lib.XML_ParserCreate(None);assert parser
 values=[]
 @CONVERT
 def convert(_,pointer):return {ord('R'):13,ord('N'):10}[c.string_at(pointer,2)[1]]
 @UNKNOWN
 def unknown(_,name,info):
  for i in range(256):info.contents.map[i]=i if i<128 else -1
  info.contents.map[128]=-2;info.contents.data=None;info.contents.convert=convert;info.contents.release=RELEASE()
  return 1
 @START
 def start(_,name,attrs):
  i=0
  while attrs[i]:values.append([attrs[i].decode(),attrs[i+1].decode()]);i+=2
 lib.XML_SetUnknownEncodingHandler(parser,unknown,None);lib.XML_SetStartElementHandler(parser,start);lib.XML_SetParamEntityParsing(parser,2)
 raw=b"<?xml version='1.0' encoding='x-alias'?>"+raw;width=chunk or len(raw);status=1
 for offset in range(0,len(raw),width):
  piece=raw[offset:offset+width];status=lib.XML_Parse(parser,piece,len(piece),int(offset+width>=len(raw)))
  if status!=1:break
 result={'status':status,'error':lib.XML_GetErrorCode(parser),'attributes':values};lib.XML_ParserFree(parser);return result

def cases():
 alias=b'\x80R\x80N'
 for kind in [b'CDATA',b'NMTOKENS']:
  for name,value in [('direct-alias',alias),('direct-physical',b'\r\n'),('physical-cr-alias-lf',b'\r\x80N'),('alias-cr-physical-lf',b'\x80R\n')]:
   yield kind.decode()+'/'+name,b'<!DOCTYPE r [<!ATTLIST r a '+kind+b" #IMPLIED>]><r a='A"+value+b"B'/>"
  for name,value in [('entity-alias',alias),('entity-numeric',b'&#13;&#10;'),('entity-physical',b'\r\n'),('entity-numeric-alias',b'&#13;\x80N')]:
   yield kind.decode()+'/'+name,b"<!DOCTYPE r [<!ENTITY e 'A"+value+b"B'><!ATTLIST r a "+kind+b" #IMPLIED>]><r a='&e;'/>"
  yield kind.decode()+'/default-alias',b'<!DOCTYPE r [<!ATTLIST r a '+kind+b" 'A"+alias+b"B'>]><r/>"
  yield kind.decode()+'/internal-source-alias',b'<!DOCTYPE r [<!ATTLIST r a '+kind+b" #IMPLIED><!ENTITY e \"<r a='A"+alias+b"B'/>\">]><outer>&e;</outer>"
  yield kind.decode()+'/parameter-default-alias',b'<!DOCTYPE r [<!ENTITY % p "<!ATTLIST r a '+kind+b" 'A"+alias+b"B'>\">%p;]><r/>"
original_cases=cases
def cases():
 yield from original_cases()
 for kind in [b'CDATA',b'NMTOKENS']:
  for label,value in [('raw-then-alias',b'\r\n\x80R\x80N'),('alias-raw-alias',b'\x80R\r\n\x80N'),('raw-alias-raw',b'\r\x80N\r\n'),('alias-and-reference',b'\x80R\r\n&#13;&#10;\x80N')]:
   for context in ['direct','default','entity-default','parameter-default','internal-attribute']:
    decl=b'<!ATTLIST r a '+kind+b" 'A"+value+b"B'>"
    if context=='direct':raw=b'<!DOCTYPE r [<!ATTLIST r a '+kind+b" #IMPLIED>]><r a='A"+value+b"B'/>"
    elif context=='default':raw=b'<!DOCTYPE r ['+decl+b']><r/>'
    elif context=='entity-default':raw=b"<!DOCTYPE r [<!ENTITY e 'A"+value+b"B'><!ATTLIST r a "+kind+b" '&e;'>]><r/>"
    elif context=='parameter-default':raw=b'<!DOCTYPE r [<!ENTITY % p "'+decl+b'">%p;]><r/>'
    else:raw=b'<!DOCTYPE r [<!ATTLIST r a '+kind+b" #IMPLIED><!ENTITY e \"<r a='A"+value+b"B'/>\">]><outer>&e;</outer>"
    yield kind.decode()+'/'+context+'/'+label,raw
paths={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','candidate':sys.argv[1]};libs={k:setup(v) for k,v in paths.items()}
rows=[]
for (name,raw),chunk,namespace in itertools.product(cases(),[0,1,2],[False,True]):
 rows.append({'case':name,'raw_hex':raw.hex(),'chunk':chunk,'namespace':namespace,'results':{k:run(v,raw,chunk,namespace) for k,v in libs.items()}})
result={'conditions':len(rows),'differences':sum(r['results']['reference']!=r['results']['candidate'] for r in rows),'libraries':{k:{'path':v,'sha256':hashlib.sha256(Path(v).read_bytes()).hexdigest()} for k,v in paths.items()},'rows':rows}
Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+'\n');print({k:result[k] for k in ['conditions','differences']})
