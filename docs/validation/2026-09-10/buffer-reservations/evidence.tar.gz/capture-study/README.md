# Reserve ATTLIST callback type capacity

The ordinary ATTLIST parser already owns a complete declaration, but its callback type string grew a member at a time. This patch reserves a checked bound from the current enumeration once, reducing repeated reallocations while retaining handler changes, decoded-name provenance, raw fragments and accounting.

The candidate changes one file over the composed buffer/ATTLIST baseline. Its 64-file source manifest is `e66cc6a0`; the reviewed library is `9cc87e9b`. The patch includes a parser regression with 1 MiB of whitespace and a 1 MiB later default, checking both ordinary and late-installed handlers and bounded retained type capacity.

| Validation | Result |
| --- | --- |
| Scoped core/FFI checks | 338 passed |
| Original enum/default/implied configurations | 36 passed |
| Full original upstream API | 4,323 passed; 417 retained failures |
| Versus immediate composed 8d baseline | 20 improvements; 0 regressions |
| Versus buffers-only 9f | 12 improvements; 0 regressions |
| Versus historical ATTLIST 0546 | 220 improvements; 12 inherited buffer regressions |
| Independent callback comparison | 3,764 full records exactly match composed baseline |
| Extra actual-Expat probes | 108 exact final/non-Default records |
| Native C ASan/UBSan | Six programs; 327 allocation scenarios per linkage |
| Selected memory probes | 16 successful engine cases; all zero live bytes after free |

The candidate removes two allocation calls/reallocations in each paired memory fixture. Captured selected blocks are 56–62 bytes even with 1 MiB whitespace/default suffixes. Overall selected peak changes range from −1 to +1 byte in these fixtures; total parser memory still includes the large source and stored values. These are allocation results, not throughput benchmarks.

## Review limits

For valid enumerations, the bound excludes raw XML whitespace and later defaults. A malformed suffix without a closing delimiter may reserve before a later syntax error, changing which selected allocation fails first. Early reservation may also allocate before a handler is later disabled. Existing allocation limits and charges for actual payloads remain unchanged.

The 417 upstream failures remain; the runner exits 1. The twelve regressions relative to historical 0546 concern the namespace binding URI reallocation test and are inherited from earlier buffer changes. No new regression appears relative to either immediate comparison baseline.

The extra reference probes retain 62 Default-event and 64 per-call row differences already present in the control: raw DOCTYPE/whitespace fragments and complete-token timing. Full Expat transcript equality is not claimed. Native sanitizer instrumentation covers the C harness, while the Rust release library is uninstrumented and leak sanitizer is disabled.

## Evidence

`summary.json` and the independent reviews are the entry points. Source archives preserve the final and control scoped sources; a clearly labeled reconstructed pre-test archive is validated through the original patch hash. One intermediate source-file hash was recorded while tests were being formatted, without a separate byte snapshot; no exact archive of that intermediate state is claimed.

Archives retain candidate build/API logs and commands, original adapted tests and runner sources, all callback transcripts and scripts, selected memory fixtures/results, native reports, and diagnostic allocation traces. The trace script's first library path was wrong; its preserved original and corrected scripts show the change. The successful rerun overwrote the failed-build log, so no original saved failure log is claimed.

`manifest.json` binds every file and archive member. Compiled libraries, runners and build caches are omitted, with binary identities retained. Packaging performs only file/hash/evidence checks; it does not rebuild, rerun or integrate the candidate.
