from pathlib import Path
import collections,difflib,gzip,hashlib,io,json,re,tarfile
w=Path('/tmp/oriole-attlist-capture-reserve');br=Path('/tmp/oriole-buffers-composed');base=br/'frozen-source';oracle=Path('/tmp/oriole-attlist-capture-oracle');trace=Path('/tmp/oriole-attlist-buffer-allocation');out=Path('/tmp/oriole-attlist-capture-handoff');assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();dig=lambda b:hashlib.sha256(b).hexdigest();m=json.loads((w/'source.json').read_text());bm={'files':json.loads((br/'source.json').read_text())['source_sha256']}
assert sha(w/'source.json')=='e66cc6a001d18eff9c24e81420cf4c77d8b86f596db822030cbd977c43e2e51e';assert sha(w/'candidate.patch')=='059e5cf4556b4f114f0534cb405c8bca28220801f4a1cb6c3054a7639da3390a';assert m['base_source_manifest_sha256']==sha(br/'source.json')
for root,manifest in [(w,m),(base,bm)]:
 assert len(manifest['files'])==64
 for f,h in manifest['files'].items():assert sha(root/f)==h,(root,f)
changes=[f for f,h in m['files'].items() if h!=bm['files'][f]];assert changes==['crates/oriole/src/dtd/attlist.rs']
assert sha(w/'liboriole_expat.so')==m['library_sha256']=='9cc87e9bc5c22dfc33eba7bf074908421dd7b1c303920f9c8021eab887793213';assert sha(w/'liboriole_expat.a')==m['static_sha256'];assert sha(br/'liboriole_expat.so')==m['base_library_sha256']
checkcount=sum(map(int,re.findall(r'test result: ok\. (\d+) passed;', (w/'test.log').read_text())));assert checkcount==m['checks']==338
for row in json.loads((w/'commands.json').read_text())['commands']:assert row['returncode']==0 and sha(w/row['log'])==row['log_sha256']
api=json.loads((w/'upstream-api/results.json').read_text());comparison=json.loads((w/'api-comparison.json').read_text());assert sha(w/'upstream-api/results.json')==comparison['candidate_sha256'];assert api['selection_complete'] and api['library_origin_verified'] and not api['timed_out'];bykey=lambda r:{(x['context'],x['test']):x for x in r['results']};cur=bykey(api);assert len(cur)==4740
assert dict(collections.Counter(x['outcome'] for x in cur.values()))=={'pass':4323,'fail':417};api_summaries=[]
for row in comparison['comparisons']:
 f=Path(row['baseline_file']);assert sha(f)==row['baseline_sha256'];previous=json.loads(f.read_text());old=bykey(previous);assert len(old)==4740 and old.keys()==cur.keys()
 diff=[{'before':old[k],'after':cur[k]} for k in old if old[k]!=cur[k]];assert diff==row['changes'];improved=sum(x['before']['outcome']=='fail' and x['after']['outcome']=='pass' for x in diff);regressed=sum(x['before']['outcome']=='pass' and x['after']['outcome']=='fail' for x in diff);assert improved==row['improved'] and regressed==row['regressed'];api_summaries.append({k:v for k,v in row.items() if k!='changes'}|{'changed_records':len(diff),'regressed_test_counts':dict(collections.Counter(x['before']['test'] for x in diff if x['before']['outcome']=='pass' and x['after']['outcome']=='fail'))})
assert [(x['improved'],x['regressed']) for x in api_summaries]==[(20,0),(12,0),(220,12)]
original=json.loads((w/'original.json').read_text());assert original['returncode']==0 and original['library_sha256']==m['library_sha256'];assert len(original['tests'])==36 and all(x.endswith('\tpass\t0') for x in original['tests']);assert [x for x in (w/'original-tests.log').read_text().splitlines() if x.startswith('ORIOLE_RESULT')]==original['tests']
native=json.loads((w/'native/report.json').read_text());assert native['status']=='passed' and len(native['rows'])==6 and native['sha256_before']==native['sha256_after']
for f,h in native['sha256_before'].items():assert sha(f)==h
native_scenarios={}
for row in native['rows']:
 label=row['case']+'-'+row['linkage'];assert row['build_exit_code']==row['exit_code']==0 and sha(w/'native'/label)==row['binary_sha256'] and sha(w/'native'/(label+'.log'))==row['log_sha256']
 if row['case']=='allocations':native_scenarios[row['linkage']]=int(re.search(r'passed: (\d+) scenarios',(w/'native'/(label+'.log')).read_text())[1])
assert native_scenarios=={'shared':327,'static':327}
mem=json.loads((w/'memory.json').read_text());assert len(mem['rows'])==16
for f,h in mem['hashes'].items():assert sha(f)==h
memory_inputs={};memory_pairs=[];earlier={}
for row in mem['rows']:
 padding=1048576 if row['fixture'] in ('whitespace','both') else 0;later=1048576 if row['fixture'] in ('later-default','both') else 0;data=b"<!DOCTYPE r [<!ATTLIST r a (first|"+b' '*padding+b"second) 'first' b CDATA '"+b'v'*later+b"'>]><r/>";assert len(data)==row['input_bytes'];memory_inputs[row['fixture']+'.xml']=data
 assert row['status']==1 and row['error']==0 and row['selected_live_after_free']==0 and len(row['callbacks'])==1;assert row['callbacks'][0]['kind']==('(second)' if row['late_handler'] else '(first|second)')
 k=row['fixture'],row['late_handler']
 if row['library']=='baseline':earlier[k]=row
 else:
  old=earlier[k];delta={key:row[key]-old[key] for key in ['selected_peak_bytes','calls','reallocs','selected_retained_before_free']};assert abs(delta['selected_peak_bytes'])<=1 and delta['calls']==delta['reallocs']==-2;assert row['callbacks'][0]['containing_selected_block_bytes'] in (56,62);memory_pairs.append({'fixture':k[0],'late_handler':k[1],'candidate_type_block_bytes':row['callbacks'][0]['containing_selected_block_bytes'],'delta_candidate_minus_control':delta})
trace_manifest=json.loads((trace/'manifest.json').read_text());assert trace_manifest['source_script_sha256']==sha('/tmp/oriole-attlist-buffer-trace.py')
for label,build in trace_manifest['builds'].items():assert sha(build['library'])==build['sha256'] and sha(trace/('runtests-'+label))==build['binary_sha256']
for row in trace_manifest['runs']:
 stem=row['label']+'-'+row['test'];assert sha(trace/(stem+'.stdout'))==row['stdout_sha256'] and sha(trace/(stem+'.stderr.gz'))==row['stderr_sha256']
old_script=(trace/'trace-before-path-fix.py').read_text();new_script=Path('/tmp/oriole-attlist-buffer-trace.py').read_text();assert old_script.replace("Path('/tmp/oriole-buffer-minimum/liboriole_expat.so')","Path('/tmp/oriole-buffer-minimum/combined/liboriole_expat.so')")==new_script
src=(w/changes[0]).read_text();i=src.index('\n    #[test]\n    fn captured_types_do_not_retain_whitespace_or_later_default_capacity');j=src.index('\n    #[test]\n    fn uncaptured_enumerations_keep_ordinary_repeated_name_work',i);pre=src[:i]+src[j:];prepatch=''.join(difflib.unified_diff((base/changes[0]).read_text().splitlines(True),pre.splitlines(True),fromfile='a/'+changes[0],tofile='b/'+changes[0]));source_review_path=Path('/tmp/oriole-attlist-capture-reserve-independent-source-review.json');source_review=json.loads(source_review_path.read_text());assert dig(prepatch.encode())==source_review['hashes'][str(w/'candidate.patch')]
# Only the final regression is removed; runtime and all pre-existing tests remain identical.
assert pre.split('#[cfg(test)]')[0]==src.split('#[cfg(test)]')[0]
final_review={'status':'passed','scope':'Read-only final source, saved gate arithmetic/hash audit and file packaging; no new source edits, parser executions, builds, allocation probes or timing runs.','source_manifest_sha256':sha(w/'source.json'),'source_files_verified':64,'changed_files':changes,'patch_sha256':sha(w/'candidate.patch'),'library_sha256':m['library_sha256'],'static_sha256':m['static_sha256'],'source_review':'The final helper/callsite is unchanged from the reviewed logic. The single new parser-level test uses 1 MiB whitespace plus a 1 MiB later default and checks normal/late-installed callback types with a <=32-byte retained String capacity; it checks parser completion rather than only helper arithmetic. No state/data-layout/callback/charge/limit changes.','scoped_checks':338,'api_comparisons':api_summaries,'original_targeted_configurations_passed':36,'native_programs_passed':6,'native_allocation_failure_scenarios':native_scenarios,'native_limitations':'C harness ASan/UBSan; Rust release library uninstrumented, LSan disabled.','memory':{'engine_cases':16,'paired_conditions':8,'all_live_after_free_zero':True,'paired_results':memory_pairs,'scope':'Selected callback-requested allocation sizes include tracking headers. Python allocations excluded. Whole-input probes have no injected faults or timing; checks bound captured type size, not total parser memory. Large raw type/default storage remains necessary and peaks reach about 11.5 MB.'},'historical_source_note':'The reconstructed pre-test patch exactly matches original dd1f36d5. An early review recorded source-file hash f9f7d145 while test/format additions were in progress; those exact intermediate bytes were not separately archived. They are not presented as reconstructed evidence. Final review and all transferred runtime evidence bind to e66cc6 plus unchanged 9cc87.', 'history':'The diagnostic tracing script initially named /tmp/oriole-buffer-minimum/liboriole_expat.so; linker failure was reported in session. It was corrected to /tmp/oriole-buffer-minimum/combined/liboriole_expat.so. Original script preserved; successful rerun overwrote the failed build log, so no original failure log is claimed.', 'caveats':['For valid enums, capacity counts only current remaining enum without raw XML whitespace or later defaults; raw alias representatives conservatively bound decoded bytes.', 'A malformed no-close suffix can reserve before its later Syntax error; selected NoMemory may therefore occur earlier. Early reservation can also allocate for remaining members before a handler is later disabled. Existing selected allocation limits still apply.', 'Only actual emitted/stored payloads retain their prior logical work accounting; reservation adds no expansion charge and changes no configured caps.', '417 original API failures remain. Twelve historical regressions versus 0546 are inherited from buffer work (namespace binding URI reallocation schedule); no regression versus immediate 8d or buffers-only 9f.', 'No throughput claim or new benchmark belongs to this allocation change.']}
out.mkdir();members={};omitted=[]
def add_archive(name,files):
 buf=io.BytesIO();rows=[]
 with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT) as tar:
  for name_in,value in sorted(files.items()):
   if isinstance(value,bytes):data=value;origin='generated during packaging from verified source/evidence'
   else:data=value.read_bytes();origin=str(value)
   assert not data.startswith((b'\x7fELF',b'!<arch>'));assert not name_in.startswith('/') and '..' not in Path(name_in).parts
   info=tarfile.TarInfo(name_in);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));rows.append({'path':name_in,'bytes':len(data),'sha256':dig(data),'origin':origin})
 (out/name).write_bytes(gzip.compress(buf.getvalue(),compresslevel=9,mtime=0));members[name]=rows

def texttree(root):
 files={}
 for f in root.rglob('*'):
  if not f.is_file():continue
  with f.open('rb') as stream:magic=stream.read(8)
  if magic.startswith((b'\x7fELF',b'!<arch>')) or f.suffix in ('.so','.a','.o'):
   omitted.append({'path':str(f),'sha256':sha(f)});continue
  files[str(f.relative_to(root))]=f
 return files
add_archive('source-candidate.tar.gz',{f:w/f for f in m['files']});add_archive('source-control.tar.gz',{f:base/f for f in bm['files']});add_archive('source-prototype-reconstructed.tar.gz',{f:pre.encode() if f==changes[0] else w/f for f in m['files']})
add_archive('candidate-records.tar.gz',{f.name:f for f in w.iterdir() if f.is_file() and f.suffix in ('.json','.py','.log','.patch')});add_archive('upstream-api.tar.gz',texttree(w/'upstream-api'));add_archive('native.tar.gz',texttree(w/'native'));add_archive('allocation-attribution.tar.gz',texttree(trace)|{'trace.py':Path('/tmp/oriole-attlist-buffer-trace.py')});add_archive('callback-oracles.tar.gz',texttree(oracle));add_archive('memory-inputs.tar.gz',memory_inputs)
prior=Path('/tmp/oriole-attlist-streaming-oracle');add_archive('oracle-support.tar.gz',{f:prior/f for f in ['encoding-matrix.py','alias-matrix.py','child-matrix.py','child-parameter-matrix.py']})
api_records={'composed-source.json':br/'source.json'}
for row in comparison['comparisons']:
 f=Path(row['baseline_file']);api_records[row['baseline']+'/results.json']=f;api_records[row['baseline']+'/manifest.json']=f.parent/'manifest.json';api_records[row['baseline']+'/tests.log']=f.parent/'tests.log'
add_archive('baseline-api-records.tar.gz',api_records)
toolroot=Path('/home/dev-user/code/oss/oriole/tools/upstream-expat');apim=json.loads((w/'upstream-api/manifest.json').read_text())
for f,h in apim['adapter_sources'].items():assert sha(toolroot/f)==h
for f,h in apim['adapted_sources'].items():assert sha(w/'upstream-api/adapted'/f)==h
for f,h in apim['upstream_include_sources'].items():assert sha(w/'upstream-api'/f)==h
add_archive('upstream-runner-sources.tar.gz',{f:toolroot/f for f in apim['adapter_sources']}|{'run_clean.py':Path('/tmp/oriole-deep-profile-experiment/inherited/run_clean.py')})
add_archive('independent-review-generators.tar.gz',{'source-review.py':Path('/tmp/oriole-attlist-capture-reserve-source-review.py'),'source-review.json':source_review_path})
for name,p in [('candidate.patch',w/'candidate.patch'),('source.json',w/'source.json'),('baseline-source.json',br/'source.json'),('independent-source-review.json',source_review_path),('independent-callback-review.json',oracle/'independent-review.json')]: (out/name).write_bytes(p.read_bytes())
(out/'prototype-reconstructed.patch').write_text(prepatch);(out/'independent-final-evidence-review.json').write_text(json.dumps(final_review,indent=2)+'\n')
for f in w.iterdir():
 if f.is_file() and (f.suffix in ('.so','.a') or f.name=='runtests'):omitted.append({'path':str(f),'sha256':sha(f)})
summary={'decision':'Validated isolated candidate for root integration; this handoff does not perform integration.','problem':'Streaming ATTLIST type capture grew geometrically even though the complete enumeration was already available, consuming reallocation retries and causing 20 previously passing upstream configurations to fail when composed with buffer work.','change':'Reserve a checked bound once from the current valid enumeration suffix when its first member is captured. Keep handler-sensitive capture, lexical provenance, source positions, stored defaults and work charges unchanged.','source_files':64,'changed_files':changes,'source_sha256':sha(w/'source.json'),'patch_sha256':sha(w/'candidate.patch'),'library_sha256':m['library_sha256'],'static_sha256':m['static_sha256'],'scoped_checks':338,'original_targeted_configurations':36,'api':{'passed':4323,'failed':417,'timed_out':False,'comparisons':api_summaries},'independent_callbacks':{'candidate_vs_control_cases':3764,'full_record_differences':0,'additional_reference_cases':108,'full_final_and_nondefault_differences':0,'engine_cases':7636},'native_programs':6,'native_scenarios_per_linkage':327,'memory_cases':16,'memory_candidate_peak_delta_bytes':[-1,1],'captured_selected_block_bytes':[56,62],'allocator_calls_saved_per_memory_case':2,'reallocations_saved_per_memory_case':2,'omitted_binary_hashes':omitted,'limitations':final_review['caveats'],'source_history':final_review['historical_source_note'],'harness_history':final_review['history']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'README.md').write_text('''# Reserve ATTLIST callback type capacity

The ordinary ATTLIST parser already owns a complete declaration, but its callback type string grew a member at a time. This patch reserves a checked bound from the current enumeration once, reducing repeated reallocations while retaining handler changes, decoded-name provenance, raw fragments and accounting.

The candidate changes one file over the composed buffer/ATTLIST baseline. Its 64-file source manifest is `e66cc6a0`; the reviewed library is `9cc87e9b`. The patch includes a parser regression with 1 MiB of whitespace and a 1 MiB later default, checking both ordinary and late-installed handlers and bounded retained type capacity.

| Validation | Result |
| --- | --- |
| Scoped core/FFI checks | 338 passed |
| Original enum/default/implied configurations | 36 passed |
| Full original upstream API | 4,323 passed; 417 retained failures |
| Versus immediate composed 8d baseline | 20 improvements; 0 regressions |
| Versus buffers-only 9f | 12 improvements; 0 regressions |
| Versus historical ATTLIST 0546 | 220 improvements; 12 inherited buffer regressions |
| Independent callback comparison | 3,764 full records exactly match composed baseline |
| Extra actual-Expat probes | 108 exact final/non-Default records |
| Native C ASan/UBSan | Six programs; 327 allocation scenarios per linkage |
| Selected memory probes | 16 successful engine cases; all zero live bytes after free |

The candidate removes two allocation calls/reallocations in each paired memory fixture. Captured selected blocks are 56–62 bytes even with 1 MiB whitespace/default suffixes. Overall selected peak changes range from −1 to +1 byte in these fixtures; total parser memory still includes the large source and stored values. These are allocation results, not throughput benchmarks.

## Review limits

For valid enumerations, the bound excludes raw XML whitespace and later defaults. A malformed suffix without a closing delimiter may reserve before a later syntax error, changing which selected allocation fails first. Early reservation may also allocate before a handler is later disabled. Existing allocation limits and charges for actual payloads remain unchanged.

The 417 upstream failures remain; the runner exits 1. The twelve regressions relative to historical 0546 concern the namespace binding URI reallocation test and are inherited from earlier buffer changes. No new regression appears relative to either immediate comparison baseline.

The extra reference probes retain 62 Default-event and 64 per-call row differences already present in the control: raw DOCTYPE/whitespace fragments and complete-token timing. Full Expat transcript equality is not claimed. Native sanitizer instrumentation covers the C harness, while the Rust release library is uninstrumented and leak sanitizer is disabled.

## Evidence

`summary.json` and the independent reviews are the entry points. Source archives preserve the final and control scoped sources; a clearly labeled reconstructed pre-test archive is validated through the original patch hash. One intermediate source-file hash was recorded while tests were being formatted, without a separate byte snapshot; no exact archive of that intermediate state is claimed.

Archives retain candidate build/API logs and commands, original adapted tests and runner sources, all callback transcripts and scripts, selected memory fixtures/results, native reports, and diagnostic allocation traces. The trace script's first library path was wrong; its preserved original and corrected scripts show the change. The successful rerun overwrote the failed-build log, so no original saved failure log is claimed.

`manifest.json` binds every file and archive member. Compiled libraries, runners and build caches are omitted, with binary identities retained. Packaging performs only file/hash/evidence checks; it does not rebuild, rerun or integrate the candidate.
''')
(out/'package.py').write_bytes(Path(__file__).read_bytes());entries=[]
for f in sorted(out.iterdir()):
 entry={'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f)}
 if f.name in members:entry['archive_members']=members[f.name]
 entries.append(entry)
manifest={'entry_count':len(entries),'archive_count':len(members),'total_bytes_excluding_manifest':sum(x['bytes'] for x in entries),'entries':entries};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for entry in entries:
 f=out/entry['path'];assert sha(f)==entry['sha256'] and f.stat().st_size==entry['bytes']
 if 'archive_members' in entry:
  with tarfile.open(f,'r:gz') as tar:
   actual=tar.getmembers();assert len(actual)==len(entry['archive_members'])
   for info,expected in zip(actual,entry['archive_members']):
    assert info.isfile() and info.name==expected['path'];data=tar.extractfile(info).read();assert dig(data)==expected['sha256'] and len(data)==expected['bytes'];assert not data.startswith((b'\x7fELF',b'!<arch>'))
print(json.dumps({'path':str(out),'manifest_sha256':sha(out/'manifest.json'),'entry_count':len(entries),'archive_count':len(members),'archive_members':sum(map(len,members.values())),'bytes_excluding_manifest':manifest['total_bytes_excluding_manifest'],'final_review_sha256':sha(out/'independent-final-evidence-review.json')},indent=2))
