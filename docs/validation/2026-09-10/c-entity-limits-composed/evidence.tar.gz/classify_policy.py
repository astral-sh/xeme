from pathlib import Path
import json,gzip,collections
w=Path('/tmp/oriole-c-limits-integrated');d=json.loads(gzip.decompress((w/'active-oracles/oracle.json.gz').read_bytes()));counts=collections.Counter(x['case'] for x in d['differences']);assert counts=={'content-depth-33':144,'value-depth-33':72,'external-value-33-False':72,'external-value-33-True':72}
assert d['cases']==4680 and d['baseline_differences']==360 and d['reference_outcome_differences']==0 and d['reference_successful_event_differences']==0
for row in d['differences']:
 x=row['results'];assert x['baseline']['status']==0;assert (x['baseline']['error']==43 or (x['baseline']['error']==21 and ['child-error','dtd',43] in x['baseline']['events']));assert x['candidate']==x['reference'];assert x['candidate']['status']==1 and x['candidate']['error']==0
out={'status':'passed','scope':'Classify intentional C limit behavior changes after the unmodified conservative-baseline oracle flags them. Original trace and its exit1 assertion retained. No parser or original upstream test was changed.','cases':4680,'exact_reference_improvements':360,'case_counts':dict(counts),'baseline_limit_error_routes':{'direct43':216,'external_callback21_with_child43':144},'other_changes':0};(w/'policy-membership-comparison.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
