from pathlib import Path
import json,gzip,hashlib,shutil,subprocess,tarfile,collections
w=Path('/tmp/oriole-c-limits-integrated');old=Path('/tmp/oriole-dtd-fast-integrated');r=Path('/home/dev-user/code/oss/oriole');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
s=read(w/'source.json');assert s['rust_checks']==322
for n,h in s['source_sha256'].items():
 assert sha(r/n)==h,n
 p=w/'frozen-source'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/n,p)
a=read(old/'upstream-api/results.json');b=read(w/'upstream-api/results.json');assert b['selection_complete'] and b['library_origin_verified'] and not b['timed_out'];assert(b['passed'],b['failed'])==(4113,627)
changes=[{'before':x,'after':y} for x,y in zip(a['results'],b['results']) if x!=y];assert len(a['results'])==len(b['results'])==4740 and len(changes)==36
assert collections.Counter(x['after']['test'] for x in changes)=={name:12 for name in ['test_deep_nested_entity','test_deep_nested_attribute_entity','test_deep_nested_entity_delayed_interpretation']}
assert all(x['before']['outcome']=='fail' and x['after']['outcome']=='pass' for x in changes)
for n in ['oracle.json','malformed.json']:assert read(w/n)['counts']==read(old/n)['counts']
assert read(w/'alias.json')['differences']==0 and read(w/'differential/summary.json')['exact_pass']
assert read(w/'policy-membership-comparison.json')['exact_reference_improvements']==360
rows=read(w/'publication/observations.json')['observations'];assert len(rows)==432 and all(x['baseline']==x['candidate'] for x in rows)
m=read(w/'measurements/results.json');assert m['status']=='passed' and len(m['rows'])==36 and len(m['fault_rows'])==152
assert all(x['measurement']['semantic_ok'] and x['measurement']['selected_final_blocks']==0 and x['measurement']['selected_final_bytes']==0 for x in m['rows']+m['fault_rows'])
assert collections.Counter((x['measurement']['status'],x['measurement']['error']) for x in m['fault_rows'])=={(0,1):149,(1,0):3}
measure=[]
for kind in range(3):
 rows=[x['measurement'] for x in m['rows'] if x['measurement']['kind']==kind];measure.append({'kind':kind,'max_parse_seconds':max(x['parse_seconds'] for x in rows),'max_selected_peak_bytes':max(x['selected_peak_bytes'] for x in rows),'max_rss_kib':max(x['max_rss_kib'] for x in rows)})
for n in ['shared','static']:assert '336 scenarios' in(w/f'native/allocations-{n}.log').read_text()
d=read(old/'report.json');d.update(runtime_commit=s['commit'],library_sha256=s['library_sha256'],rust_checks=322,scope='C-only100000entity/count depth policy on composed shared-DTD fast runtime; safe Rust defaults unchanged.',upstream={'passed':4113,'failed':627,'changed_outcomes':36,'changes':changes},active_membership={'cases':4680,'exact_reference_improvements':360,'other_changes':0},deep_measurements=measure,selected_failure_measurements={'attempts':152,'NoMemory':149,'past_last_allocation_success':3,'live_after_free':0});(w/'report.json').write_text(json.dumps(d,indent=2)+'\n')
(w/'README.md').write_text('''# Deeper bounded C entity expansion

C constructors now allow100,000 declarations and100,000 internal entity levels. Reset and external children preserve that policy. Safe Rust defaults remain10,000 declarations and32 levels. Iterative algorithms and active-name indexes make these workloads practical;8MiB expansion-work,512MiB live allocation,256MiB input,external nesting and other limits remain unchanged.

The composed runtime passes322 core/adapter Rust checks, strict Clippy/formatting, and all36 original deep-entity configurations under the original bounds. The full4,740-case upstream matrix improves from4,077/663 to4,113 passing/627 failing, with exactly those36 improvements and no other row changes. Original assertions and retry ceilings remain unchanged.

The4,680-case membership oracle initially flags360 deliberate changes from conservative-depth rejection. Its original exit1 and raw results are retained; `classify_policy.py` verifies all360 are exact matches to Expat, including events and positions, in the four depth33 conditions. No other membership differences exist. Ordinary,attribute,custom,malformed,DOCTYPE and shared-DTD publication probes retain their results. Six native C sanitizer executions pass, with336 allocation scenarios per linkage; Rust is uninstrumented and leak sanitizer disabled.

Supplemental selected-allocator measurements run36 deep fixtures and152 fault locations:149 returnNoMemory andthree are beyond the last allocation and succeed. All blocks are released. Observed maximum parse times are below0.9seconds; peak selected requested bytes are about103MB for60,000-deep content,70MB for attributes and78MB for the70,000-deep delayed parameter fixture. These are fixture measurements, not universal resource bounds; the original API gate is separate from the supplemental harness. Work counters are unmeasured in this production binary; the separately instrumented author experiment is retained under `../c-entity-policy/`.

The14 large-buffer/stream failures are still reported. Same-bound reference Expat also fails12 one-gigabyte GetBuffer cases and times out on two active two-gigabyte stream cases, while Oriole additionally has its documented lower caps. `../large-input-controls/` retains those reference controls and bounded-prefix allocation measurements. No caps were changed to relabel those failures.
''')
subprocess.run(['python3','/tmp/oriole-package-checkpoint.py',str(w),str(r/'docs/validation/2026-09-10/c-entity-limits-composed')],check=True)
for source,name in [('/tmp/oriole-c-entity-defaults-handoff','c-entity-policy'),('/tmp/oriole-large-input-followup-handoff','large-input-controls')]:
 h=Path(source);dest=r/'docs/validation/2026-09-10'/name;dest.mkdir(parents=True,exist_ok=True);files={}
 for p in sorted(h.rglob('*')):
  if not p.is_file():continue
  b=p.read_bytes();assert not b.startswith((b'\x7fELF',b'!<arch>\n'))
  files[str(p.relative_to(h))]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 with tarfile.open(dest/'evidence.tar.gz','w:gz',compresslevel=9) as t:
  for n in files:t.add(h/n,arcname=n,recursive=False)
 with tarfile.open(dest/'evidence.tar.gz') as t:
  for p in t:assert hashlib.sha256(t.extractfile(p).read()).hexdigest()==files[p.name]['sha256']
 (dest/'files.json').write_text(json.dumps({'archive_sha256':sha(dest/'evidence.tar.gz'),'members':files},indent=2)+'\n');shutil.copy2(h/'README.md',dest/'README.md');print(name,len(files),sha(dest/'evidence.tar.gz'))
p=r/'README.md';text=p.read_text().replace('docs/validation/2026-09-10/shared-dtd-final/','docs/validation/2026-09-10/c-entity-limits-composed/').replace('records 319 Rust checks','records 322 Rust checks').replace('4,077 passing and 663 failing','4,113 passing and 627 failing');p.write_text(text)
