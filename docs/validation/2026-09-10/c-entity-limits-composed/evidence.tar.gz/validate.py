from pathlib import Path
import subprocess,json,concurrent.futures,time
w=Path('/tmp/oriole-c-limits-integrated');r=Path('/home/dev-user/code/oss/oriole');py='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3';commands=[]
jobs=[('oracle',[py,'-I','-S',str(w/'oracle.py'),str(w/'liboriole_expat.so'),str(w/'oracle.json')]),('alias',[py,'-I','-S',str(w/'alias_oracle.py'),str(w/'liboriole_expat.so'),str(w/'alias.json')]),('alias-baseline',[py,'-I','-S',str(w/'alias_oracle.py'),'/tmp/oriole-dtd-fast-integrated/liboriole_expat.so',str(w/'alias-baseline.json')]),('differential',[py,'tools/differential.py','--library',str(w/'liboriole_expat.so'),'--reference','/tmp/oriole-dtd-fast-integrated/liboriole_expat.so','--output',str(w/'differential'),'--generated','100','--chunks','1','2','3','7','64','4096','--strict']),('malformed',[py,'-I','-S',str(w/'malformed_oracle.py'),str(w/'liboriole_expat.so'),str(w/'malformed.json')]),('malformed-text',[py,'-I','-S',str(w/'malformed_probe.py')]),('streaming',[py,'-I','-S',str(w/'streaming_probe.py')]),('custom',[py,'-I','-S',str(w/'alias_probes.py')]),('native',[py,str(w/'native.py')]),('upstream',['taskset','-c','3',py,'tools/upstream-expat/run.py','--source','/home/dev-user/.cache/oriole/upstream/expat-2.8.4','--config','/tmp/oriole-security-controls-integrated/upstream-api/adapted/expat_config.h','--library',str(w/'liboriole_expat.so'),'--output',str(w/'upstream-api'),'--timeout','240'])]
def run(job):
 label,command=job;start=time.time()
 with (w/(label+'.log')).open('w') as log:p=subprocess.run(command,cwd=r,stdout=log,stderr=subprocess.STDOUT)
 row={'label':label,'command':command,'exit_code':p.returncode,'seconds':time.time()-start};print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:commands=list(pool.map(run,jobs))
(w/'validation-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
assert all(x['exit_code']==(1 if x['label']=='upstream' else 0) for x in commands)
