"""Supplemental read-only measurement export; never included in the proposed patch."""
from pathlib import Path
import difflib,hashlib,json,tarfile
w=Path('/tmp/oriole-deep-profile-experiment');source=Path('/tmp/oriole-raw-attribute-scratch');out=w/'instrumented';out.mkdir(exist_ok=True);base=w/'wide';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=json.loads((base/'source.json').read_text());assert all(sha(source/p)==h for p,h in old['sources'].items())
p=source/'crates/oriole/src/lib.rs';s=p.read_text();needle='    fn charge_expansion(&self, size: usize) -> Result<(), Error> {';assert s.count(needle)==1;s=s.replace(needle,'''    /// Temporary measurement export, omitted from all production patches.
    pub fn diagnostic_expansion_work(&self) -> usize {
        self.expanded.expanded.load(Ordering::Relaxed)
    }

'''+needle);p.write_text(s)
p=source/'crates/oriole_expat/src/lib.rs';s=p.read_text();s+='''
/// Temporary measurement export: caller retains a live, idle parser handle.
/// This function is omitted from every proposed production patch.
///
/// # Safety
/// `parser` must be a valid live parser and no callback or other operation may
/// concurrently mutate it. The standalone measurement caller satisfies this.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn XML_OrioleDiagnosticExpansionWork(parser: XML_Parser) -> usize {
    // SAFETY: The standalone measurement caller supplies a live, idle parser.
    unsafe { (*parser).core.diagnostic_expansion_work() }
}
''';p.write_text(s)
diff=[];changes={}
with tarfile.open(base/'source.tar.gz') as tf:
 for path in old['sources']:
  before=tf.extractfile(path).read();after=(source/path).read_bytes()
  if before!=after:
   changes[path]={'base':hashlib.sha256(before).hexdigest(),'candidate':sha(source/path)}
   diff.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(out/'measurement-only.patch').write_text(''.join(diff));(out/'source.json').write_text(json.dumps({'scope':'Supplemental instrumentation; not a production API or proposal. Atomic load after parse, no change to parser work.','base_manifest_sha256':sha(base/'source.json'),'sources':{p:sha(source/p) for p in old['sources']},'changes':changes},indent=2)+'\n')
with tarfile.open(out/'source.tar.gz','w:gz') as tf:
 for p in old['sources']:tf.add(source/p,arcname=p,recursive=False)
s=(w/'build_wide.py').read_text().replace("experiment/wide'","experiment/instrumented'")
s=s.replace(",('fmt-check',['fmt','--all','--check'])",'')
(w/'build_instrumented.py').write_text(s)
