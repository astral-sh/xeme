/* Supplemental exact-fixture measurements, distinct from the original API tests.
 * Suite accounting counts bytes requested from the selected allocator, including
 * Oriole's own tracking headers but excluding this harness's aligned header.
 * All pointers remain within one single-threaded parser family. */
#include "expat.h"
#include <assert.h>
#include <inttypes.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <time.h>

typedef union Header { max_align_t alignment; size_t size; } Header;
static size_t live_bytes, peak_bytes, live_blocks, calls, fail_at;
static int elements, declarations, bad_callback;
static char observed[32];
static size_t observed_length;
static int allocation_fails(void) { ++calls; return fail_at && calls >= fail_at; }
static void *suite_malloc(size_t size) {
  if (allocation_fails() || size > SIZE_MAX - sizeof(Header)) return NULL;
  Header *header = malloc(sizeof(Header) + size);
  if (!header) return NULL;
  header->size = size; live_bytes += size; ++live_blocks;
  if (live_bytes > peak_bytes) peak_bytes = live_bytes;
  return header + 1;
}
static void suite_free(void *pointer) {
  if (!pointer) return;
  Header *header = (Header *)pointer - 1;
  assert(live_blocks && live_bytes >= header->size);
  live_bytes -= header->size; --live_blocks; free(header);
}
static void *suite_realloc(void *pointer, size_t size) {
  if (!pointer) return suite_malloc(size);
  if (allocation_fails() || size > SIZE_MAX - sizeof(Header)) return NULL;
  Header *old = (Header *)pointer - 1;
  size_t old_size = old->size;
  Header *header = realloc(old, sizeof(Header) + size);
  if (!header) return NULL;
  header->size = size; live_bytes = live_bytes - old_size + size;
  if (live_bytes > peak_bytes) peak_bytes = live_bytes;
  return header + 1;
}
static void characters(void *unused, const XML_Char *value, int length) {
  (void)unused;
  if (length < 0 || (size_t)length > sizeof(observed) - observed_length - 1) { bad_callback = 1; return; }
  memcpy(observed + observed_length, value, (size_t)length);
  observed_length += (size_t)length; observed[observed_length] = 0;
}
static void start(void *unused, const XML_Char *name, const XML_Char **attrs) {
  (void)unused;
  ++elements;
  if (strcmp(name, "foo") || !attrs[0] || !attrs[1] || attrs[2]
      || strcmp(attrs[0], "name") || strcmp(attrs[1], "deepText")) bad_callback = 1;
}
static void entity(void *unused, const XML_Char *name, int parameter,
                   const XML_Char *value, int length, const XML_Char *base,
                   const XML_Char *system, const XML_Char *public_id,
                   const XML_Char *notation) {
  (void)unused; (void)base; (void)system; (void)public_id; (void)notation;
  if (!parameter && strcmp(name, "g") == 0) {
    ++declarations;
    if (!value || length != 8 || memcmp(value, "deepText", 8)) bad_callback = 1;
  }
}
#ifdef ORIOLE_MEASURE_WORK
extern size_t XML_OrioleDiagnosticExpansionWork(XML_Parser parser);
#endif
static double now(void) { struct timespec t; assert(clock_gettime(CLOCK_MONOTONIC, &t) == 0); return (double)t.tv_sec + (double)t.tv_nsec / 1e9; }
int main(int argc, char **argv) {
  if (argc != 4 && argc != 5) return 2;
  int kind = atoi(argv[1]), chunk = atoi(argv[2]), deferral = atoi(argv[3]);
  if (kind < 0 || kind > 2 || chunk < 0 || chunk > 5 || deferral < 0 || deferral > 1) return 2;
  if (argc == 5) fail_at = strtoull(argv[4], NULL, 10);
  size_t n = kind == 2 ? 70000 : 60000, per_line = kind == 0 ? 50 : 100;
  size_t input_allocation = (n + 4) * per_line;
  char *text = malloc(input_allocation), *p = text;
  if (!text) return 2;
  p += snprintf(p, per_line, kind == 2 ? "<!DOCTYPE foo [\n\t<!ENTITY %% s0 'deepText'>\n" : "<!DOCTYPE foo [\n\t<!ENTITY s0 'deepText'>\n");
  for (size_t i = 1; i < n; ++i)
    p += snprintf(p, per_line, kind == 2 ? "  <!ENTITY %% s%lu '&#37;s%lu;'>\n" : "  <!ENTITY s%lu '&s%lu;'>\n", (unsigned long)i, (unsigned long)i - 1);
  if (kind == 0) snprintf(p, per_line, "]> <foo>&s%lu;</foo>\n", (unsigned long)n - 1);
  else if (kind == 1) snprintf(p, per_line, "]> <foo name='&s%lu;'>mainText</foo>\n", (unsigned long)n - 1);
  else snprintf(p, per_line, "  <!ENTITY %% define_g \"<!ENTITY g '&#37;s%lu;'>\">\n  %%define_g;\n]>\n<foo/>\n", (unsigned long)n - 1);
  size_t length = strlen(text); assert(length < input_allocation);
  uint64_t fingerprint = UINT64_C(14695981039346656037);
  for (size_t i = 0; i < length; ++i) { fingerprint ^= (unsigned char)text[i]; fingerprint *= UINT64_C(1099511628211); }
  XML_Memory_Handling_Suite suite = {suite_malloc, suite_realloc, suite_free};
  double start_all = now();
  XML_Parser parser = XML_ParserCreate_MM(NULL, &suite, NULL);
  int status = XML_STATUS_ERROR, error = XML_ERROR_NO_MEMORY;
  double start_parse = now(), end_parse = start_parse;
  size_t work = 0;
  if (parser) {
    assert(XML_SetReparseDeferralEnabled(parser, (XML_Bool)deferral));
    if (kind == 0) XML_SetCharacterDataHandler(parser, characters);
    if (kind == 1) XML_SetStartElementHandler(parser, start);
    if (kind == 2) { assert(XML_SetParamEntityParsing(parser, XML_PARAM_ENTITY_PARSING_ALWAYS)); XML_SetEntityDeclHandler(parser, entity); }
    start_parse = now();
    const char *data = text; size_t remaining = length;
    status = XML_STATUS_OK;
    while (chunk && remaining > (size_t)chunk) {
      status = XML_Parse(parser, data, chunk, XML_FALSE);
      if (status != XML_STATUS_OK) break;
      data += chunk; remaining -= (size_t)chunk;
    }
    if (status == XML_STATUS_OK) status = XML_Parse(parser, data, (int)remaining, XML_TRUE);
    end_parse = now(); error = XML_GetErrorCode(parser);
#ifdef ORIOLE_MEASURE_WORK
    work = XML_OrioleDiagnosticExpansionWork(parser);
#endif
    XML_ParserFree(parser);
  }
  double end_all = now(); struct rusage usage; assert(getrusage(RUSAGE_SELF, &usage) == 0);
  int semantic_ok = !bad_callback && (kind == 0 ? strcmp(observed, "deepText") == 0 : kind == 1 ? elements == 1 : declarations == 1);
  printf("{\"kind\":%d,\"chunk\":%d,\"deferral\":%d,\"fail_at\":%zu,\"input_bytes\":%zu,\"input_fnv64\":\"%016" PRIx64 "\",\"host_input_allocation\":%zu,\"status\":%d,\"error\":%d,\"semantic_ok\":%s,\"selected_calls\":%zu,\"selected_peak_bytes\":%zu,\"selected_final_bytes\":%zu,\"selected_final_blocks\":%zu,\"expansion_work_bytes\":%zu,\"parse_seconds\":%.9f,\"constructor_parse_free_seconds\":%.9f,\"max_rss_kib\":%ld}\n", kind, chunk, deferral, fail_at, length, fingerprint, input_allocation, status, error, semantic_ok ? "true" : "false", calls, peak_bytes, live_bytes, live_blocks, work, end_parse-start_parse, end_all-start_all, usage.ru_maxrss);
  free(text);
  if (live_bytes || live_blocks) return 3;
  if (fail_at) return status == XML_STATUS_OK ? !semantic_ok : error != XML_ERROR_NO_MEMORY;
  return status != XML_STATUS_OK || !semantic_ok;
}
