import hashlib,json,os,resource,subprocess,time
from pathlib import Path
w=Path('/tmp/oriole-deep-profile-experiment');out=w/'measurements';out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
observed=[w/'measure.c',w/'inherited/frozen-source/include/expat.h',w/'wide/liboriole_expat.so',w/'instrumented/liboriole_expat.so',w/'wide/source.json',w/'instrumented/source.json'];report={'scope':'Supplemental custom selected-allocator fixture measurements. Original API36 gate is separate. Work hook is a separately hashed atomic-read-only instrumentation build. CPU3 affinity, shared host.','bounds':{'address_bytes':1<<30,'rss_bytes':768<<20,'wall_seconds':3},'sha256_before':{str(p):sha(p) for p in observed},'builds':[],'rows':[],'fault_rows':[]}
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_RSS,(768<<20,768<<20))
def invoke(label,kind,chunk,deferral,fail_at=None):
 args=[str(out/label),str(kind),str(chunk),str(deferral)]+([] if fail_at is None else [str(fail_at)])
 command=['taskset','-c','3',*args];start=time.monotonic()
 r=subprocess.run(command,capture_output=True,text=True,timeout=3,preexec_fn=limits)
 row={'label':label,'command':command,'exit_code':r.returncode,'subprocess_seconds':time.monotonic()-start,'stdout':r.stdout,'stderr':r.stderr}
 if r.stdout:row['measurement']=json.loads(r.stdout)
 return row
try:
 for label in ['wide','instrumented']:
  lib=w/label/'liboriole_expat.so';command=['clang','-std=c11','-D_POSIX_C_SOURCE=200809L','-Wall','-Wextra','-Werror','-O2','-I',str(w/'inherited/frozen-source/include'),str(w/'measure.c'),str(lib),'-Wl,-rpath,'+str(lib.parent),'-o',str(out/label)]
  if label=='instrumented':command.insert(1,'-DORIOLE_MEASURE_WORK')
  with (out/(label+'-build.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=60)
  row={'label':label,'command':command,'exit_code':r.returncode};report['builds'].append(row);assert r.returncode==0
  row['binary_sha256']=sha(out/label)
 for label in ['wide','instrumented']:
  for kind in range(3):
   for chunk in range(6):
    for deferral in range(2):
     row=invoke(label,kind,chunk,deferral);report['rows'].append(row);assert row['exit_code']==0 and not row['stderr'],row
     (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
  print(label,'36 completed',flush=True)
 normal={r['measurement']['kind']:r['measurement'] for r in report['rows'] if r['label']=='instrumented' and r['measurement']['chunk']==0 and r['measurement']['deferral']==1}
 for kind in range(3):
  calls=normal[kind]['selected_calls'];locations=set(range(1,33))|{1<<i for i in range(6,24) if (1<<i)<calls}|{calls//4,calls//2,calls-1,calls,calls+1}
  for fail_at in sorted(locations):
   row=invoke('instrumented',kind,0,1,fail_at);report['fault_rows'].append(row);assert row['exit_code']==0 and not row['stderr'],row
  print('fault kind',kind,len(locations),flush=True)
 report['sha256_after']={str(p):sha(p) for p in observed};assert report['sha256_after']==report['sha256_before'];report['status']='passed'
finally:(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
