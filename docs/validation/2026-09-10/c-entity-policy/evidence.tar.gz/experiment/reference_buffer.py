from pathlib import Path
import hashlib,json,subprocess,time
w=Path('/tmp/oriole-deep-profile-experiment');out=w/'reference-buffer';python='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12';library=Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
command=['taskset','-c','3',python,'-I','-S',str(w/'inherited/run_clean.py'),str(w/'inherited/frozen-source/tools/upstream-expat/run.py'),'--source','/home/dev-user/.cache/oriole/upstream/expat-2.8.4','--config','/home/dev-user/.cache/oriole/expat-build/expat_config.h','--library',str(library),'--output',str(out),'--tests','test_buffer_can_grow_to_max']
start=time.time();before=sha(library)
with (w/'reference-buffer.log').open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=300)
row={'command':command,'exit_code':r.returncode,'seconds':time.time()-start,'library_sha256_before':before,'library_sha256_after':sha(library),'log_sha256':sha(w/'reference-buffer.log')};(w/'reference-buffer-command.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True)
d=json.loads((out/'results.json').read_text());print(json.dumps({k:v for k,v in d.items() if k!='excluded_internal_tests'}),flush=True)
