"""Isolated experiment only. Rust defaults and all byte/live/family caps stay fixed."""
from pathlib import Path
import difflib,hashlib,json,tarfile
w=Path('/tmp/oriole-deep-profile-experiment');source=Path('/tmp/oriole-raw-attribute-scratch');out=w/'wide';out.mkdir(exist_ok=True)
old_manifest=json.loads((w/'inherited/source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert all(sha(source/p)==h for p,h in old_manifest['sources'].items())
p=source/'crates/oriole_expat/src/lib.rs';s=p.read_text();needle='''            let config = Config {
                namespace_separator: separator,
                name_rules: NameRules::FourthEdition,
                ..Config::default()
            };''';assert s.count(needle)==1
replacement=needle.replace('let config =','let mut config =')+'''
            // Isolated compatibility-default experiment, not a production change.
            config.limits.max_entities = 100_000;
            config.limits.max_entity_depth = 100_000;'''
s=s.replace(needle,replacement);p.write_text(s)
