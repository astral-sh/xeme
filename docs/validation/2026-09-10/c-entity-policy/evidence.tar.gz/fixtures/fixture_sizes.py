"""Reproduce original fixture byte counts; no parser execution or XML artifacts."""
import hashlib,json
from pathlib import Path
out=Path('/tmp/oriole-resource-profile-review');rows=[]
for kind,n in [('content',60000),('attribute',60000),('parameter_value',70000)]:
 parts=["<!DOCTYPE foo [\n\t<!ENTITY "+("% " if kind=='parameter_value' else '')+"s0 'deepText'>\n"]
 parts.extend(f"  <!ENTITY % s{i} '&#37;s{i-1};'>\n" if kind=='parameter_value' else f"  <!ENTITY s{i} '&s{i-1};'>\n" for i in range(1,n))
 if kind=='content':parts.append(f"]> <foo>&s{n-1};</foo>\n")
 elif kind=='attribute':parts.append(f"]> <foo name='&s{n-1};'>mainText</foo>\n")
 else:parts.append(f'''  <!ENTITY % define_g "<!ENTITY g '&#37;s{n-1};'>">\n  %define_g;\n]>\n<foo/>\n''')
 doc=''.join(parts).encode()
 rows.append({'kind':kind,'declarations':n+(2 if kind=='parameter_value' else 0),'input_bytes':len(doc),'input_sha256':hashlib.sha256(doc).hexdigest(),'upstream_host_buffer_bytes':(n+4)*(50 if kind=='content' else 100),'expected_leaf':'deepText','max_generated_line_bytes':max(map(len,doc.splitlines()))})
report={'scope':'Pure fixture reproduction/counting, not parser execution','rows':rows}
previous=out/'fixture-sizes.json'
if previous.exists():assert json.loads(previous.read_text())==report
previous.write_text(json.dumps(report,indent=2)+'\n')
