START_TEST(test_deep_nested_entity) {
  const size_t N_LINES = 60000;
  const size_t SIZE_PER_LINE = 50;

  char *const text = malloc((N_LINES + 4) * SIZE_PER_LINE);
  if (text == NULL) {
    fail("malloc failed");
  }

  char *textPtr = text;

  // Create the XML
  textPtr += snprintf(textPtr, SIZE_PER_LINE,
                      "<!DOCTYPE foo [\n"
                      "	<!ENTITY s0 'deepText'>\n");

  for (size_t i = 1; i < N_LINES; ++i) {
    textPtr += snprintf(textPtr, SIZE_PER_LINE, "  <!ENTITY s%lu '&s%lu;'>\n",
                        (long unsigned)i, (long unsigned)(i - 1));
  }

  snprintf(textPtr, SIZE_PER_LINE, "]> <foo>&s%lu;</foo>\n",
           (long unsigned)(N_LINES - 1));

  const XML_Char *const expected = XCS("deepText");

  CharData storage;
  CharData_Init(&storage);

  XML_Parser parser = XML_ParserCreate(NULL);

  XML_SetCharacterDataHandler(parser, accumulate_characters);
  XML_SetUserData(parser, &storage);

  if (_XML_Parse_SINGLE_BYTES(parser, text, (int)strlen(text), XML_TRUE)
      == XML_STATUS_ERROR)
    xml_failure(parser);

  CharData_CheckXMLChars(&storage, expected);
  XML_ParserFree(parser);
  free(text);
}
END_TEST
