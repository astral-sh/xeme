START_TEST(test_deep_nested_entity_delayed_interpretation) {
  const size_t N_LINES = 70000;
  const size_t SIZE_PER_LINE = 100;

  char *const text = malloc((N_LINES + 4) * SIZE_PER_LINE);
  if (text == NULL) {
    fail("malloc failed");
  }

  char *textPtr = text;

  // Create the XML
  textPtr += snprintf(textPtr, SIZE_PER_LINE,
                      "<!DOCTYPE foo [\n"
                      "	<!ENTITY %% s0 'deepText'>\n");

  for (size_t i = 1; i < N_LINES; ++i) {
    textPtr += snprintf(textPtr, SIZE_PER_LINE,
                        "  <!ENTITY %% s%lu '&#37;s%lu;'>\n", (long unsigned)i,
                        (long unsigned)(i - 1));
  }

  snprintf(textPtr, SIZE_PER_LINE,
           "  <!ENTITY %% define_g \"<!ENTITY g '&#37;s%lu;'>\">\n"
           "  %%define_g;\n"
           "]>\n"
           "<foo/>\n",
           (long unsigned)(N_LINES - 1));

  XML_Parser parser = XML_ParserCreate(NULL);

  XML_SetParamEntityParsing(parser, XML_PARAM_ENTITY_PARSING_ALWAYS);
  if (_XML_Parse_SINGLE_BYTES(parser, text, (int)strlen(text), XML_TRUE)
      == XML_STATUS_ERROR)
    xml_failure(parser);

  XML_ParserFree(parser);
  free(text);
}
END_TEST
