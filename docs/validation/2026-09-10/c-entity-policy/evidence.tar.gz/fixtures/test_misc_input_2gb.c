START_TEST(test_misc_input_2gb) {
  XML_Parser parser;
  const char *const doc = "<?xml version='1.0'?><doc/>";
  unsigned long long offset = 0;
  char buf[4096];

  if (g_chunkSize != 0) {
    return; // this test is slow, and doesn't use _XML_Parse_SINGLE_BYTES().
  }

  memset(buf, ' ', sizeof(buf));

  parser = XML_ParserCreate(NULL);

  assert_true(XML_Parse(parser, doc, (int)strlen(doc), XML_FALSE)
              == XML_STATUS_OK);
  offset += strlen(doc);

  while (offset < 2ULL * 1024 * 1024 * 1024) {
    assert_true(XML_Parse(parser, buf, sizeof(buf), XML_FALSE)
                == XML_STATUS_OK);
    offset += sizeof(buf);
  }

  assert_true(XML_Parse(parser, NULL, 0, XML_TRUE) == XML_STATUS_OK);

  XML_ParserFree(parser);
}
END_TEST
