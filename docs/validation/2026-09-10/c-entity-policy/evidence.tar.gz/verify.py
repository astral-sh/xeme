import hashlib,json,subprocess,time
from pathlib import Path
w=Path('/tmp/oriole-deep-profile-experiment');source=Path('/tmp/oriole-c-entity-defaults/frozen-source');out=Path('/tmp/oriole-c-entity-defaults');python='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tests=['test_deep_nested_entity','test_deep_nested_attribute_entity','test_deep_nested_entity_delayed_interpretation']
command=['taskset','-c','3',python,'-I','-S',str(w/'inherited/run_clean.py'),str(source/'tools/upstream-expat/run.py'),'--source','/home/dev-user/.cache/oriole/upstream/expat-2.8.4','--config','/home/dev-user/.cache/oriole/expat-build/expat_config.h','--library',str(out/'liboriole_expat.so'),'--output',str(out/'upstream-api')]
before=sha(out/'liboriole_expat.so');start=time.time()
with (out/'upstream.log').open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
row={'command':command,'exit_code':r.returncode,'seconds':time.time()-start,'library_sha256_before':before,'library_sha256_after':sha(out/'liboriole_expat.so'),'log_sha256':sha(out/'upstream.log')};(out/'upstream-full-command.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True)
