import runpy,sys
from pathlib import Path
assert not any(line.rsplit("/",1)[-1].startswith("libexpat.") for line in Path("/proc/self/maps").read_text().splitlines())
errors=[]
sys.unraisablehook=lambda e:errors.append(str(e.exc_value))
script=sys.argv.pop(1)
runpy.run_path(script,run_name="__main__")
assert not errors,errors
