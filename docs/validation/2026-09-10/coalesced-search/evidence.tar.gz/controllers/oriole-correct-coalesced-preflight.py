import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

out = Path('/tmp/oriole-coalesced-search-python-study')
initial = out / 'initial-affinity-error'
initial.mkdir(exist_ok=False)
for name in ['consumer_screen.py', 'controller.patch', 'preflight.log', 'preparation.json']:
    shutil.copy2(out / name, initial / name)
assert not (out / 'screen').exists()
script = out / 'consumer_screen.py'
before = script.read_text()
after = before.replace('os.sched_getaffinity(0) != {2}', 'os.sched_getaffinity(0) != {3}').replace('Preflights require CPU2', 'Preflights require CPU3')
assert before != after
script.write_text(after)
(out / 'affinity-correction.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='initial', tofile='corrected')))
python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
command = ['taskset', '-c', '3', python, '-I', '-S', str(script), '--kind', 'python', '--phase', 'prepare', '--build', str(out / 'consumers/build.json'), '--input', '/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json', '--output', str(out / 'screen')]
with (out / 'preflight-corrected.log').open('wb') as log:
    run = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
report = {'status': 'passed' if run.returncode == 0 else 'failed', 'command': command, 'exit': run.returncode,
          'controller_sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
          'note': 'Initial controller guard requiredCPU2 while scheduledCPU3 to avoid fuzzCPU2. It exited before loading a build, producing any worker or creating output. Corrected only preflight affinity guard toCPU3. Full original build passed, unchanged binaries. Original failure retained.'}
(out / 'preflight-correction.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copy2(__file__, out / Path(__file__).name)
print(json.dumps(report), flush=True)
raise SystemExit(run.returncode)
