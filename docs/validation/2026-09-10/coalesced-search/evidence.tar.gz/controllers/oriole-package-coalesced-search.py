import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

repo = Path('/home/dev-user/code/oss/oriole-coalesced-search')
out = repo / 'docs/validation/2026-09-10/coalesced-search'
out.mkdir(parents=True, exist_ok=False)
directories = {
    'source-gates-profiles': '/tmp/oriole-coalesced-search-study',
    'canonical-api': '/tmp/oriole-coalesced-search-canonical-api',
    'cpython': '/tmp/oriole-coalesced-search-cpython-gates',
    'native': '/tmp/oriole-coalesced-search-timing-study',
    'python': '/tmp/oriole-coalesced-search-python-study',
    'reviews/source': '/tmp/oriole-coalesced-search-source-independent-review',
    'reviews/native': '/tmp/oriole-coalesced-search-native-independent-review',
    'reviews/python': '/tmp/oriole-coalesced-search-python-independent-review',
    'reviews/compatibility': '/tmp/oriole-coalesced-search-compat-independent-review',
}
single_files = [
    '/tmp/oriole-prepare-coalesced-timing.py', '/tmp/oriole-time-coalesced-native.py',
    '/tmp/oriole-prepare-coalesced-python.py', '/tmp/oriole-correct-coalesced-preflight.py',
    '/tmp/oriole-time-coalesced-python.py', '/tmp/oriole-coalesced-cpython-gates.py',
    '/tmp/oriole-coalesced-source-assembly.json', '/tmp/oriole-package-coalesced-search.py',
]
def digest(data):
    return hashlib.sha256(data).hexdigest()
paths = {}
for prefix, dirname in directories.items():
    directory = Path(dirname)
    assert directory.is_dir(), directory
    for path in sorted(directory.rglob('*')):
        if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts:
            paths[prefix + '/' + str(path.relative_to(directory))] = path
for filename in single_files:
    path = Path(filename)
    assert path.is_file(), path
    paths['controllers/' + path.name] = path
members, excluded = [], []
with tarfile.open(out / 'evidence.tar.gz', 'w:gz', compresslevel=9) as archive:
    for name, path in sorted(paths.items()):
        data = path.read_bytes()
        entry = {'path': name, 'source': str(path), 'bytes': len(data), 'sha256': digest(data)}
        if data.startswith(b'\x7fELF') or data.startswith(b'!<arch>\n'):
            excluded.append(entry)
            continue
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
        members.append(entry)
with tarfile.open(out / 'evidence.tar.gz', 'r:gz') as archive:
    stored = archive.getmembers()
    assert len(stored) == len(members)
    for actual, entry in zip(stored, members):
        assert actual.isfile() and actual.name == entry['path'] and actual.size == entry['bytes']
        assert digest(archive.extractfile(actual).read()) == entry['sha256']
        assert digest(Path(entry['source']).read_bytes()) == entry['sha256']
(out / 'archive-members.json').write_text(json.dumps({'members': members, 'excluded_binaries': excluded}, indent=2) + '\n')
copies = {
    'source.json': '/tmp/oriole-coalesced-search-study/source.json',
    'assembly.json': '/tmp/oriole-coalesced-source-assembly.json',
    'source-review.json': '/tmp/oriole-coalesced-search-source-independent-review/review.json',
    'native-review.json': '/tmp/oriole-coalesced-search-native-independent-review/review.json',
    'python-review.json': '/tmp/oriole-coalesced-search-python-independent-review/review.json',
    'compatibility-review.json': '/tmp/oriole-coalesced-search-compat-independent-review/review.json',
    'canonical-api.json': '/tmp/oriole-coalesced-search-canonical-api/report.json',
    'native-summary.json': '/tmp/oriole-coalesced-search-timing-study/summary.json',
    'python-summary.json': '/tmp/oriole-coalesced-search-python-study/summary.json',
}
for name, path in copies.items():
    shutil.copy2(path, out / name)
summary = {'runtime_commit': '193e1278ae059bad3a7890b4e34b9a91be5296e8',
           'source_files': 69, 'source_manifest_sha256': digest((out / 'source.json').read_bytes()),
           'library_sha256': '5058093123b486f7b6163ca055eb8726a5441f120bb4e74fcf7b892398ceab79',
           'workspace_tests': 394, 'fmt_and_strict_clippy': 'passed',
           'api': {'passed': 4347, 'failed': 393, 'configurations': 4740, 'all_outcomes_unchanged': True, 'canonical_bounds_separately_verified': True},
           'cpython_per_linkage': {'tests': 802, 'failures': 2, 'skips': 14, 'expected_failures': 3},
           'native': json.loads((out / 'native-summary.json').read_text()),
           'python': json.loads((out / 'python-summary.json').read_text()),
           'archive': {'sha256': digest((out / 'evidence.tar.gz').read_bytes()), 'members': len(members), 'excluded_binaries': len(excluded), 'raw_bytes': sum(x['bytes'] for x in members), 'bytes': (out / 'evidence.tar.gz').stat().st_size, 'all_members_readback_verified': True}}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary['archive'], indent=2), flush=True)
