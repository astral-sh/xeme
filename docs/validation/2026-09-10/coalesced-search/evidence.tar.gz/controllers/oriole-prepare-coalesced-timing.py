import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

out = Path('/tmp/oriole-coalesced-search-timing-study')
out.mkdir(exist_ok=False)
gate = Path('/tmp/oriole-coalesced-search-study')
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifest = json.loads((gate / 'manifest.json').read_text())
assert digest(gate / 'manifest.json') == 'c8ac70cb6ac881dda7c1d3e2eab519f949d0e02ea163992a47ee90f99dc8a9f2'
for name, entry in manifest['files'].items():
    path = gate / name
    assert path.stat().st_size == entry['bytes'] and digest(path) == entry['sha256'], name
source = json.loads((gate / 'source.json').read_text())
for name, value in source['source_sha256'].items():
    assert digest(Path(source['worktree']) / name) == value, name
old = Path('/tmp/oriole-integrated-native-study/native_screen.py').read_text()
new = old
changes = [
    ('Frozen paired native screen for the coalesced namespace frame candidate.', 'Frozen paired native screen for the bounded coalesced text selector.'),
    ("root = Path('/tmp/oriole-integrated-native-study')", "root = Path('/tmp/oriole-coalesced-search-timing-study')"),
    ("Path('/tmp/oriole-verified-builds/published/liboriole_expat.so')", "Path('/tmp/oriole-text-frames-pr/release/liboriole_expat.so')"),
    ("Path('/tmp/oriole-frame-integrated-final/liboriole_expat.so')", "Path('/tmp/oriole-coalesced-search-study/liboriole_expat.so')"),
    ('fresh published4b11/6c645730, integrated coalesced frames/9277b71c candidate (db5 fixes retained; abandoned line-policy hook removed)', 'published5bc806e/5af2406b, bounded coalesced selector/50580931 candidate'),
]
for before, after in changes:
    assert new.count(before) == 1, before
    new = new.replace(before, after)
# Preserve each process immediately, including nonzero exits, before cohort assertions.
before = '    assert result.returncode == 0, record\n'
after = "    ordinal = len(list(output.glob('worker-*.json')))\n    save(f'worker-{ordinal:04d}.json', record)\n    assert result.returncode == 0, record\n"
assert new.count(before) == 1
new = new.replace(before, after)
(out / 'native_screen.py').write_text(new)
(out / 'controller.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='reviewed-final-controller', tofile='coalesced-selector-controller')))
libraries = {'published': (Path('/tmp/oriole-text-frames-pr/release/liboriole_expat.so'), '5af2406b17092dad35aa61c086cdfe39e24f51e653441fd9baf50cd12da3b2fe'),
             'candidate': (gate / 'liboriole_expat.so', '5058093123b486f7b6163ca055eb8726a5441f120bb4e74fcf7b892398ceab79'),
             'expat': (Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4'), '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478')}
for name, (path, expected) in libraries.items():
    assert digest(path) == expected, name
report = {'status': 'prepared', 'source_files_checked': len(source['source_sha256']),
          'gate_manifest_sha256': digest(gate / 'manifest.json'), 'gate_files_checked': len(manifest['files']),
          'controller_sha256': digest(out / 'native_screen.py'),
          'controller_patch_sha256': digest(out / 'controller.patch'),
          'baseline_build_report': '/tmp/oriole-text-frames-pr/release/report.json',
          'candidate_build_report': str(gate / 'validation.json'),
          'scope': 'Same full cohort, seven fixed shuffled orders, counts, seed and correctness checks as the independently reviewed final frame controller. Paths, identity prose and immediate per-worker retention are the only changes. Three concurrent fuzz lanes onCPU1/2/4; native timing exclusivelyCPU0. No samples yet.'}
shutil.copy2(__file__, out / Path(__file__).name)
(out / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')
with (out / 'preflight-controller.log').open('wb') as log:
    result = subprocess.run(['taskset', '-c', '3', 'python3', str(out / 'native_screen.py'), 'preflight'], stdout=log, stderr=subprocess.STDOUT, timeout=600)
assert result.returncode == 0
print(json.dumps({'status': 'passed', 'preflights': 84, 'libraries': {k:v[1] for k,v in libraries.items()}}), flush=True)
