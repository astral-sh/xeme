"""Frozen source/build and saved Callgrind audit. Never execute parser workloads."""
import collections,hashlib,json,math,re,shlex,tarfile
from pathlib import Path
r=Path('/tmp/oriole-coalesced-search-study');out=Path(__file__).parent
hashes={}
def read(p):
 p=Path(p);b=p.read_bytes();hashes[str(p)]=hashlib.sha256(b).hexdigest();return b
def sha(p):read(p);return hashes[str(Path(p))]
def load(p):return json.loads(read(p))
m=load(r/'manifest.json');assert sha(r/'manifest.json')=='c8ac70cb6ac881dda7c1d3e2eab519f949d0e02ea163992a47ee90f99dc8a9f2'
assert m['status']=='frozen' and len(m['files'])==421
for n,e in m['files'].items():
 b=read(r/n);assert len(b)==e['bytes'] and sha(r/n)==e['sha256']
def source(root):
 sm=load(root/'source.json')
 with tarfile.open(root/'source.tar.gz') as t:
  members=[a for a in t if a.isfile()];files={a.name:t.extractfile(a).read() for a in members}
 assert len(files)==len(members)==69 and set(files)==set(sm['source_sha256'])
 for name,b in files.items():assert hashlib.sha256(b).hexdigest()==sm['source_sha256'][name]
 return sm,files
sm,files=source(r);bm,old=source(r/'control')
assert sm['base_commit']=='5bc806e5fc2a545f22c75f2a1bcbef45cfa3632b'
for n,b in files.items():assert read(Path(sm['worktree'])/n)==b
assert [n for n in files if files[n]!=old[n]]==['crates/oriole/src/lib.rs']
assert sha(r/'candidate.patch')==sm['patch_sha256']
initial=load(r/'initial-test-style/source.json');initial_text=read(r/'initial-test-style/lib.rs') if (r/'initial-test-style/lib.rs').exists() else None
# Final review correspondence and exact initial/final test spellings are retained.
style=load(r/'test-style-correction.json');correspondence=load(r/'review-to-final.json')
assert correspondence['changes'].startswith('Exactly two test-only')
assert correspondence['final_source_sha256']==sha(r/'source.json')
assert correspondence['review_sha256']==sha(r/'root-independent-review.json')
validation=load(r/'validation.json');control=load(r/'control/report.json')
assert validation['status']==control['status']=='passed' and validation['source_unchanged'] and control['source_unchanged']
assert validation['workspace_compilations']==control['workspace_compilations']==3
assert validation['source_json_sha256']==sha(r/'source.json')
for row in validation['commands']:assert row['exit']==0 and row['log_sha256']==sha(r/(row['name']+'.log'))
for e in [validation['env_overrides'],control['env_overrides']]:
 assert e['CARGO_BUILD_BUILD_DIR']=='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}' and e['CARGO_INCREMENTAL']=='0'
 assert all(e[k]=='' for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'])
assert '-Zohm-defaults=no' in next(x['command'] for x in validation['commands'] if x['name']=='release')
def invocation(line):
 w=shlex.split(line.strip()[9:-1]);i=next(i for i,x in enumerate(w) if x.endswith('/bin/rustc'));return dict(x.split('=',1) for x in w[:i]),w[i],w[i+1:]
a=load(r/'workspace-compiler-invocations.json');b=load(r/'control/workspace-compiler-invocations.json');assert len(a)==len(b)==3
compiled=[]
for x,y in zip(a,b):
 env,compiler,args=invocation(x);oe,oc,oa=invocation(y)
 dep=args[args.index('--out-dir')+1];od=oa[oa.index('--out-dir')+1]
 assert dep!=od and '/verified-build/' in dep and '/verified-build/' in od and compiler==oc
 assert [v.replace(dep,'<DEPS>') for v in args]==[v.replace(od,'<DEPS>') for v in oa]
 norm=lambda e,w,d:{k:v.replace(w,'<WORKTREE>').replace(d,'<DEPS>') for k,v in e.items()}
 assert norm(env,sm['worktree'],dep)==norm(oe,bm['worktree'],od)
 assert x.strip() in read(r/'release.log').decode()
 assert y.strip() in read(r/'control/build.log').decode()
 compiled.append(env['CARGO_CRATE_NAME'])
assert compiled==['oriole_storage','oriole','oriole_expat']
for n,d in validation['libraries'].items():assert sha(r/n)==sha(Path(dep)/n)==sha(Path(validation['env_overrides']['CARGO_TARGET_DIR'])/'release'/n)==d
assert validation['libraries']['liboriole_expat.so']=='5058093123b486f7b6163ca055eb8726a5441f120bb4e74fcf7b892398ceab79'
assert control['libraries']['liboriole_expat.so']==sha('/tmp/oriole-text-frames-pr/release/liboriole_expat.so')=='5af2406b17092dad35aa61c086cdfe39e24f51e653441fd9baf50cd12da3b2fe'
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;',read(r/'tests.log').decode());assert len(counts)==33 and sum(int(p) for p,f in counts)==394 and all(int(f)==0 for p,f in counts)
# Reconstruct raw Callgrind self totals independently, skipping arc-cost records.
def callgrind(path):
 text=read(path).decode();assert '\npositions: line\n' in text and '\nevents: Ir\n' in text
 names={};current=None;arc=False;cost=collections.Counter()
 for line in text.splitlines():
  match=re.match(r'^(c?fn)=\((\d+)\)(?: (.*))?$',line)
  if match:
   kind,key,name=match.groups()
   if name is not None:
    assert key not in names or names[key]==name
    names[key]=name
   if kind=='fn':current=key;arc=False
   continue
  if line.startswith('calls='):arc=True;continue
  match=re.match(r'^(?:\*|[+-]?\d+)\s+(\d+)(?:\s|$)',line)
  if match:
   if arc:arc=False
   else:cost[current]+=int(match[1])
 total=int(re.search(r'^summary: (\d+)',text,re.M)[1]);assert sum(cost.values())==total
 functions=collections.Counter()
 for key,value in cost.items():functions[names[key]]+=value
 return total,functions
profile=r/'profile';protocol=load(profile/'protocol.json');pr=load(profile/'report.json');pre=load(profile/'preflights.json');origins=load(profile/'origins.json')
assert protocol['affinity']==[6] and protocol['profile_processes']==protocol['preflight_processes']==32
assert protocol['hashes_before']==pr['hashes_after']
for p,d in protocol['hashes_before'].items():assert sha(p)==d
assert pr['status']=='passed' and len(pr['rows'])==len(pre)==32 and len(protocol['conditions'])==16
assert all(sha(e['path'])==e['sha256'] for e in origins.values())
assert protocol['env_overrides']['LD_PRELOAD']==protocol['env_overrides']['LD_LIBRARY_PATH']==''
raw_profiles=[];programs={};parse_text_costs={};expected={}
def observations(path):
 d=load(path);ss=d['samples'];assert len(ss)==2 and [s['warmup'] for s in ss]==[True,False] and [s['iteration'] for s in ss]==[0,1]
 values=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in ss});assert len(values)==1
 return [list(x) for x in values]
for i,condition in enumerate(protocol['conditions']):
 for engine in ['control','candidate']:
  stem=f"{i:02}-{condition['workload']}-ns{int(condition['namespaces'])}-{condition['chunk']}-{engine}"
  q=next(q for q in pre if q['condition']==i and q['library']==engine)
  command=['/tmp/oriole-grammar-bench-plain/native-driver',protocol['libraries'][engine],condition['input'],str(condition['chunk']),'1']+(['namespaces'] if condition['namespaces'] else [])
  assert q['command']==command and q['observed']==observations(profile/(stem+'-preflight.stdout'))
  assert read(profile/(stem+'-preflight.stderr'))==b''
  row=next(x for x in pr['rows'] if x['condition']==i and x['library']==engine)
  assert row['observed']==q['observed']==observations(profile/(stem+'.stdout'))
  assert row['command'][1:4]==['--tool=callgrind','--collect-atstart=no','--toggle-collect=XML_Parse'] and row['command'][5:]==command
  total,fn=callgrind(profile/(stem+'.callgrind'));assert total==row['Ir'] and row['unparsed_Ir']==0
  stderr=read(profile/(stem+'.stderr')).decode();assert int(re.search(r'Collected : (\d+)',stderr)[1])==total
  annotation=read(profile/(stem+'-annotation.stdout')).decode();assert int(re.search(r'([\d,]+)\s+PROGRAM TOTALS',annotation)[1].replace(',',''))==total
  parsed=[]
  for line in annotation.splitlines():
   match=re.match(r'^\s*([\d,]+)\s+(.+?) \[([^\]]+)\]$',line)
   if match:parsed.append({'Ir':int(match[1].replace(',','')),'function':match[2],'object':match[3]})
  assert parsed==row['functions'] and sum(x['Ir'] for x in parsed)==total
  subset=sum(v for n,v in fn.items() if 'parse_text' in n or 'coalesced_text_end' in n)
  assert subset==sum(x['Ir'] for x in parsed if 'parse_text' in x['function'] or 'coalesced_text_end' in x['function'])
  programs[i,engine]=total;expected[i,engine]=q['observed'];parse_text_costs[i,engine]=subset
  raw_profiles.append({'condition':condition,'engine':engine,'total_Ir':total,'parse_text_helper_self_Ir':subset,'raw_self_cost_sum_verified':True})
 assert expected[i,'control']==expected[i,'candidate']
comparisons=[]
for i,c in enumerate(protocol['conditions']):
 d=c|{'control':programs[i,'control'],'candidate':programs[i,'candidate'],'candidate_over_control':programs[i,'candidate']/programs[i,'control']};comparisons.append(d)
assert comparisons==pr['comparisons']
geo=math.exp(sum(math.log(x['candidate_over_control']) for x in comparisons if x['kind']=='project')/12)
assert geo==pr['project_instruction_ratio_geomean']
summary=load(r/'summary.json');assert comparisons==summary['instruction_comparisons'] and geo==summary['project_instruction_ratio_geomean']
assert parse_text_costs[3,'control']==3839898 and parse_text_costs[3,'candidate']==748410
# Keep the resource-bound discrepancy explicit instead of inferring from equal rows.
api=load(r/'upstream-api/manifest.json');assert [api[k] for k in ['per_test_seconds','per_test_address_space_bytes','per_test_rss_limit_bytes','total_timeout_seconds']]==[15,4294967296,3221225472,900]
runner=read(r/'probe-tools/upstream-expat.py').decode()
for text in ['ORIOLE_TEST_TIMEOUT=str(args.test_timeout)','ORIOLE_MEMORY_MIB=str(args.memory_mib)','ORIOLE_RSS_MIB=str(args.rss_mib)','process.wait(timeout=args.timeout)']:assert text in runner
assert sha(r/'upstream-api/results.json')=='dcda1affc7cfa69d1e77dd60b7c76360e572e2a7767d6d4ded084ab1575647d5'
(out/'profile-details.json').write_text(json.dumps(raw_profiles,indent=2)+'\n')
review={
 'status':'source_build_profile_audit_complete','runtime_source_findings':[],
 'validation_findings':[{'id':'API_BOUNDS','severity':'needs_separate_canonical_run_before_adoption','detail':'Frozen API run actually uses15s/test,4GiB AS,3GiB RSS,900s total without clamping. Identical4740 outcome rows do not establish the canonical3s/1GiB/768MiB/240s gate. Original relaxed artifacts remain frozen; root was notified and owns a separate canonical rerun.'}],
 'scope':'Read-only source/archive/compiler and saved Callgrind reconstruction. No parser runs, builds or new timings. Native wall arithmetic is delegated to the separate a6b605 audit.',
 'manifest_files_rehashed':421,'source_files_each':69,'workspace_compilations_each':3,'effective_workspace_rustc_env_and_args_match_after_only_private_paths':True,
 'source_conclusion':[
  'The fast helper runs only in existing coalesce mode. Before index65536 the scalar loop cannot stop for a newline; a markup byte at65536 still wins because markup is tested before the bound. Therefore bounded memchr2 through index65536 or text-end at<=65536 returns the same selector endpoint.',
  'Longer spans with no early markup and all noncoalesced spans retain the exact scalar boundary logic, including internal CR distinction, CRLF crossing and long individual lines. The extra prefix scan is bounded65537 bytes; it introduces no allocation or superlinear retry path.',
  'The helper slices bytes, so a UTF8 scalar crossing the bounded prefix remains valid. Returned markup indexes are ASCII boundaries and returned full lengths are valid str ends. Converted-window fallback, malformed XML/forbidden-marker precedence, newline normalization/raw widths and frame/error publication remain unchanged.',
  'Source changes consist only of the selector wrapper/helper and two cfg(test) oracles. Existing allocator, resource accounting, handler/lifetime state and C dispatch are unchanged. Tests copy the original scalar selector, cover short alphabets and cutoff/UTF8/root/internal cases; initial Clippy byte-array spellings are retained separately.',
 ],
 'profile_counts':{'conditions':16,'project_conditions':12,'generated_conditions':4,'preflight_processes':32,'profile_processes':32,'collected_parses_including_warmups':64},
 'instruction_comparisons':comparisons,'project_Ir_geomean':geo,'all_project_conditions_lower':all(x['candidate_over_control']<1 for x in comparisons if x['kind']=='project'),
 'wayland_ns_self_Ir':{'control':3839898,'candidate':748410},
 'limits':[
  'Callgrind collects XML_Parse and callbacks for one warmup plus one measured parse; construction/free/file IO are excluded. These are instruction counts, not throughput.',
  'All32 raw self-cost totals, annotation totals/functions and stderr Collected Ir counts agree. Successful profile runner asserts zero exits but does not persist numeric exit codes per command; no reviewer executions were made.',
  'Real profile conditions use4KiB only; generated controls use4/64KiB. Rare64KiB instruction ratio1.00096356 is retained. Shared-host wall timings and actual consumers are separate evidence.',
  'Initial source/test/probe outcomes remain immutable. This review does not certify full canonical API bounds, CPython, C sanitizers or sustained Rust fuzz for this selector.',
 ],
 'artifacts_sha256':hashes,
}
(out/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'status':review['status'],'review_sha256':sha(out/'review.json'),'profile_geo':geo,'files':421,'API_bounds':'relaxed_recorded_not_canonical'}))
