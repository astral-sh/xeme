# Coalesced character-data markup search

This isolated candidate adds a bounded `memchr2` search before the existing scalar selector. A markup byte through index 65,536 takes precedence; otherwise a span of at most 65,536 bytes can finish without tracking unused newline boundaries. Longer spans and noncoalesced input use the original selector. The later converted-window, malformed-input, normalization, raw context, event publication and source accounting logic is unchanged.

Base: PR106 commit `5bc806e5fc2a545f22c75f2a1bcbef45cfa3632b`. Candidate shared library: `5058093123b486f7b6163ca055eb8726a5441f120bb4e74fcf7b892398ceab79`. The 69-source freeze, exact patch, both libraries, build commands and three actual workspace compiler invocations are preserved. Private worktree-hashed intermediates avoid the earlier ordinary-Cargo shared-cache artifact issue.

## Correctness

All 394 workspace tests, formatting and strict Clippy checks pass. The two added Rust oracle tests exercise the actual memchr2 helper across complete short alphabets, production cutoff pairs, UTF-8 crossings and root/internal CRLF rules. Source review found no blocker. Initial Clippy failures concerned only two test byte-array spellings; those sources and logs are retained, with the exact test-only correction and review correspondence recorded.

The candidate matches its parent in 1,518 strict traces, 2,392 malformed-text cases, and 36,456 custom-encoding cases. All 32 streaming/context/default/suspension conditions pass, with 16 exact parent/candidate callback-position-payload trace comparisons. All 4,740 original API outcomes remain unchanged: 4,347 pass and 393 fail; results are byte-identical to the canonical baseline. Existing coordinate differences against idealized raw-prefix calculations remain recorded separately.

## Instruction study

All 32 normal preflights and 32 Callgrind processes pass callback hash/count checks. Collection covers `XML_Parse` and its callbacks, excluding creation, destruction and file loading. Each profiler process contains one warmup and one measured parse, both collected. CPU6 only; no CPU0 wall-time benchmarking.

The geometric mean instruction ratio across all 12 real-project conditions is **0.96448**: 3.55% fewer instructions. Every real condition improves.

| Project | Namespaces off | Namespaces on |
|---|---:|---:|
| Vulkan | −1.95% | −1.79% |
| Wayland | −11.42% | −10.55% |
| Maven | −2.83% | −2.18% |
| Batik | −1.11% | −0.99% |
| GTK | −3.92% | −3.65% |
| DocBook | −0.81% | −0.61% |

These project profiles use 4 KiB input feeds. Generated entity controls improve by 1.41%/1.40% at 4 KiB/64 KiB. Rare declarations change by −0.018%/+0.096%; the small regression is retained.

For namespaced Wayland, parse_text/helper self instructions fall from 3,839,898 to 748,410, while whole collected instructions fall from 27,719,235 to 24,795,845. All function counts reconcile to their program totals. Raw profiles, annotations, protocol and every observation are preserved.

## Disposition

Ready for a coordinated wall-time gate; not selected or published. Instruction reductions do not establish throughput gains or faster-than-Expat performance. Full real-project feed-size timing, actual consumer impact and any final combined-source gates remain the parent's work. No CPython, C sanitizer or sustained fuzz rerun is claimed for this isolated experiment. No local commit or push was made.
