from pathlib import Path
w=Path('/home/dev-user/code/oss/oriole-coalesced-search')
p=w/'crates/oriole/src/lib.rs';s=p.read_text()
start=s.index('        let mut boundary = 0;',s.index('    fn parse_text'))
end=s.index('        if coalesce && end ==',start)
old=s[start:end]
body=old.replace('        let mut end = text','        text',1).rstrip()
assert body.endswith('});'); body=body[:-1]
new='''        let fast_end = coalesce.then(|| coalesced_text_end(text)).flatten();
        let mut end = fast_end.unwrap_or_else(|| {
'''+''.join('    '+line+'\n' for line in body.splitlines())+'''        });
'''
s=s[:start]+new+s[end:]
helper='''/// Resolve a coalesced span before newline boundaries can stop the scalar scan.
fn coalesced_text_end(text: &str) -> Option<usize> {
    // Markup takes precedence even at the complete-line cutoff. Search bytes so
    // the bounded prefix may end inside a UTF-8 character without slicing str.
    let bytes = text.as_bytes();
    if let Some(end) = memchr::memchr2(b'<', b'&', &bytes[..bytes.len().min(65_537)]) {
        return Some(end);
    }
    (bytes.len() <= 65_536).then_some(bytes.len())
}

'''
pos=s.index('fn string(text:');s=s[:pos]+helper+s[pos:]
reference=old.replace('        let mut end = text','        text',1).rstrip()[:-1]
tests='''
#[cfg(test)]
mod coalesced_text_search_tests {
    use super::coalesced_text_end;

    // The original complete-line selector, including its root/internal CR rule.
    fn scalar_end(text: &str, internal: bool) -> usize {
        let coalesce = true;
'''+reference+'''
    }

    fn compare(text: &str) {
        for internal in [false, true] {
            let expected = scalar_end(text, internal);
            let actual = coalesced_text_end(text).unwrap_or_else(|| scalar_end(text, internal));
            assert_eq!(actual, expected, "internal={internal}, text length={}", text.len());
            assert!(text.is_char_boundary(actual));
        }
    }

    #[test]
    fn bounded_search_matches_scalar_selector_for_all_short_sequences() {
        let alphabet = ['<', '&', '\\r', '\\n', 'x', ']', 'é', '\\0'];
        for length in 0..=6 {
            for mut number in 0..alphabet.len().pow(length) {
                let mut text = std::string::String::new();
                for _ in 0..length {
                    text.push(alphabet[number % alphabet.len()]);
                    number /= alphabet.len();
                }
                compare(&text);
            }
        }
    }

    #[test]
    fn markup_and_crlf_keep_precedence_at_the_complete_line_cutoff() {
        for length in [65_535, 65_536, 65_537, 65_538, 131_075] {
            for first in [0, 1, 65_534, 65_535, 65_536, 65_537] {
                for second in [0, 1, 65_534, 65_535, 65_536, 65_537] {
                    if first >= length || second >= length {
                        continue;
                    }
                    for left in [b'<', b'&', b'\\r', b'\\n'] {
                        for right in [b'<', b'&', b'\\r', b'\\n'] {
                            let mut text = vec![b'x'; length];
                            text[first] = left;
                            text[second] = right;
                            compare(std::str::from_utf8(&text).unwrap());
                        }
                    }
                }
            }
        }
        for prefix in ["é".repeat(32_768), "aé".repeat(21_845), "\\r".repeat(65_537)] {
            for tail in ["", "<", "&", "é<", "\\r\\n<", "]]>\\0"] {
                compare(&format!("{prefix}{tail}"));
            }
        }
        let crossing = format!("{}\\r\\n<", "x".repeat(65_535));
        assert_eq!(coalesced_text_end(&crossing), None);
        assert_eq!(scalar_end(&crossing, false), 65_537);
        assert_eq!(scalar_end(&crossing, true), 65_536);
        let cutoff = format!("\\n{}<", "x".repeat(65_535));
        assert_eq!(coalesced_text_end(&cutoff), Some(65_536));
    }
}
'''
s+=tests;p.write_text(s)
(Path(__file__).parent/'original-selector.txt').write_text(old)
