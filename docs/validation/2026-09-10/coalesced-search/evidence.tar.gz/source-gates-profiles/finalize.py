"""Verify frozen sources and summarize the bounded selector prototype gates."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess
root=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((root/'source.json').read_text());worktree=Path(source['worktree'])
assert all(sha(worktree/n)==h for n,h in source['source_sha256'].items())
validation=json.loads((root/'validation.json').read_text());assert validation['status']=='passed' and validation['workspace_compilations']==3
assert all(sha(root/n)==h for n,h in validation['libraries'].items())
counts=[int(x) for x in re.findall(r'test result: ok\. (\d+) passed',(root/'tests.log').read_text())];assert sum(counts)==394
probes=json.loads((root/'probes.json').read_text());assert probes['status']=='passed' and probes['inputs_unchanged'] and probes['library_unchanged']
strict=json.loads((root/'strict-traces/summary.json').read_text());assert strict['cases']==1518 and strict['exact_pass']
malformed=json.loads((root/'malformed-probe.json').read_text());assert malformed['cases']==2392 and not malformed['differences']
coordinates=json.loads((root/'coordinate-comparison.json').read_text());assert len(coordinates['rows'])==32
assert len(coordinates['control_comparisons'])==16 and all(r['exact_callback_positions_and_payloads'] for r in coordinates['control_comparisons'])
aliases=json.loads((root/'aliases/summary.json').read_text());assert sum(r['comparisons'] for r in aliases['rows'])==36456 and not any(r['all_differences'] for r in aliases['rows'])
api=json.loads((root/'api-comparison.json').read_text());assert api['configurations']==4740 and not api['changes']
baseline=Path('/tmp/oriole-frame-integrated-gates/upstream-api/results.json');assert sha(root/'upstream-api/results.json')==sha(baseline)
profiles=json.loads((root/'profile/report.json').read_text());assert profiles['status']=='passed' and len(profiles['rows'])==32
assert all(row['unparsed_Ir']==0 for row in profiles['rows'])
assert len(profiles['comparisons'])==16 and len(json.loads((root/'profile/preflights.json').read_text()))==32
control=Path('/tmp/oriole-text-frames-pr/release');(root/'control').mkdir(exist_ok=True)
for n in ['liboriole_expat.so','source.json','source.tar.gz','report.json','workspace-compiler-invocations.json','build.log']:
 shutil.copy2(control/n,root/'control'/n);assert sha(control/n)==sha(root/'control'/n)
summary={'status':'ready_for_coordinated_wall_time_gate_not_selected','base_commit':source['base_commit'],'worktree':str(worktree),'source_files':len(source['source_sha256']),'source_json_sha256':sha(root/'source.json'),'patch_sha256':sha(root/'candidate.patch'),'libraries':validation['libraries'],'control_library_sha256':sha(root/'control/liboriole_expat.so'),'workspace_tests_passed':sum(counts),'fmt_passed':True,'strict_clippy_passed':True,'source_unchanged':True,'strict_cases':1518,'strict_differences':0,'malformed_cases':2392,'malformed_differences':0,'streaming_conditions':32,'exact_coordinate_payload_comparisons':16,'custom_alias_cases':36456,'custom_alias_differences':0,'api':api,'api_results_sha256':sha(root/'upstream-api/results.json'),'instruction_profile_processes':32,'normal_preflight_processes':32,'project_instruction_ratio_geomean':profiles['project_instruction_ratio_geomean'],'instruction_comparisons':profiles['comparisons'],'independent_review_sha256':sha(root/'root-independent-review.json'),'review_to_final_sha256':sha(root/'review-to-final.json'),'limitations':['Instruction counts are not wall-time throughput and do not establish faster-than-Expat performance.','Real-project instruction profiles cover4KiB feeds; generated controls cover4KiB and64KiB. Larger spans have correctness coverage but no standalone throughput claim.','No CPython suite, C sanitizer or sustained fuzz rerun for this isolated prototype.','The only initial check failure was strict Clippy requesting two test-only byte-string spellings. Exact initial sources/logs/review are preserved.','Original393 API failures and known baseline Expat diagnostics/position differences remain.','No commit or push/publication; current runtime remains an isolated candidate.']}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':summary['status'],'project_instruction_ratio_geomean':summary['project_instruction_ratio_geomean']}))
