from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).parent
w=Path('/home/dev-user/code/oss/oriole-coalesced-search')
base=Path('/tmp/oriole-text-frames-pr/release')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((base/'source.json').read_text())['source_sha256']
changed=[n for n,h in original.items() if digest(w/n)!=h]
assert changed==['crates/oriole/src/lib.rs'],changed
source={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'worktree':str(w),'branch':'charlie/codex-oriole-coalesced-search','source_sha256':{n:digest(w/n) for n in original},'baseline':{'path':str(base/'liboriole_expat.so'),'sha256':digest(base/'liboriole_expat.so'),'source_json_sha256':digest(base/'source.json')},'scope':'Only the approved bounded memchr2 coalesced selector shortcut; scalar fallback, noncoalesced path and all later parse_text code unchanged. Two new unit oracles in the same source file.'}
patch=subprocess.check_output(['git','diff','--binary'],cwd=w)
(root/'candidate.patch').write_bytes(patch)
source['patch_sha256']=digest(root/'candidate.patch')
with tarfile.open(root/'source.tar.gz','w:gz') as archive:
 for name in original:archive.add(w/name,arcname=name)
source['source_archive_sha256']=digest(root/'source.tar.gz')
(root/'source.json').write_text(json.dumps(source,indent=2)+'\n')
print(json.dumps({'source_sha256':digest(root/'source.json'),'patch_sha256':source['patch_sha256'],'source_count':len(original)}))
