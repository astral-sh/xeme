import difflib,hashlib,json,shutil
from pathlib import Path
r=Path(__file__).parent;w=Path('/home/dev-user/code/oss/oriole-coalesced-search');tools=r/'probe-tools';tools.mkdir(exist_ok=True)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['differential.py','xml_abi.py','corpus.py']:shutil.copy2(w/'tools'/n,tools/n)
shutil.copy2(w/'tools/upstream-expat/run.py',tools/'upstream-expat.py')
for n in ['bridge.h','bridge.c','runner.c']:shutil.copy2(w/'tools/upstream-expat'/n,tools/n)
baseline='/tmp/oriole-text-frames-pr/release/liboriole_expat.so';candidate=str(r/'liboriole_expat.so')
patch=[]
for name in ['malformed_probe.py','coordinate_comparison.py']:
 src=Path('/tmp/oriole-ns-coalesced-fresh-validation')/name
 old=src.read_text();new=old.replace('/tmp/oriole-ns-coalesced-study/trace-tools',str(tools)).replace('/tmp/oriole-ns-coalesced-fresh-validation',str(r))
 if name=='malformed_probe.py':
  new=new.replace('/tmp/oriole-ns-coalesced-study/liboriole_expat.so',baseline).replace('/tmp/oriole-verified-builds/coalesced/liboriole_expat.so',candidate)
 else:
  start=new.index('for label, path in ');end=new.index('\n',start)
  new=new[:start]+f"for label, path in [('control',Path({baseline!r})),('candidate',Path({candidate!r}))]:"+new[end:]
  new=new.replace('old-coalesced','control').replace('fresh-coalesced','candidate').replace('old_coalesced','control')
 (r/name).write_text(new);patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(src),tofile=name))
# Keep the established custom converter oracle source immutable and local.
a=r/'alias-inputs';a.mkdir(exist_ok=True)
for name in ['probe','full-events','external-semantic-compare']:
 shutil.copy2(Path('/tmp')/('oriole-custom-alias-'+name+'.py'),a/('oriole-custom-alias-'+name+'.py'))
src=Path('/tmp/oriole-text-frame-prototype/text/alias_probes.py');old=src.read_text()
new=old.replace('/tmp/oriole-text-frame-prototype/text/aliases',str(r/'aliases')).replace('/tmp/oriole-text-frame-prototype/text/control.so',baseline).replace('/tmp/oriole-text-frame-prototype/text/liboriole_expat.so',candidate)
new=new.replace("Path('/tmp/oriole-custom-alias-probe.py').read_text()",f"Path({str(a/'oriole-custom-alias-probe.py')!r}).read_text()")
new=new.replace("Path('/tmp/oriole-custom-alias-'+name+'.py').read_text()",f"Path({str(a/'oriole-custom-alias-')!r}+name+'.py').read_text()")
(r/'alias_probes.py').write_text(new);patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(src),tofile='alias_probes.py'))
(r/'probe-harness.patch').write_text(''.join(patch))
files=[*tools.iterdir(),*a.iterdir(),*(r/n for n in ['malformed_probe.py','coordinate_comparison.py','alias_probes.py','probe-harness.patch']),Path(baseline),Path('/tmp/oriole-frame-integrated-gates/upstream-api/results.json')]
(r/'probe-inputs.json').write_text(json.dumps({str(p):digest(p) for p in files if p.is_file()},indent=2)+'\n')
# The root review is source-only; it did not execute these probes.
for src,dst in [('/tmp/oriole-coalesced-search-root-review.json','root-independent-review.json')]:shutil.copy2(src,r/dst)
