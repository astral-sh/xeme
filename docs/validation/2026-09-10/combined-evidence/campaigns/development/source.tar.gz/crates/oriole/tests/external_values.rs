use oriole::{Config, ErrorKind, EventKind, Limits, Parser};

#[derive(Clone, Copy)]
enum Load {
    Parse(&'static [u8]),
    Skip,
    EmptyNonfinal,
    IgnoreError(&'static [u8]),
}

fn drain(
    parser: &mut Parser,
    loads: &[(&str, Load)],
    chunk: usize,
    declarations: &mut Vec<(String, String)>,
    depth: usize,
) -> Result<(), ErrorKind> {
    assert!(
        depth < 8,
        "recursive references must fail before loading again"
    );
    while let Some(event) = parser.next_event().map_err(|error| error.kind)? {
        match event.kind {
            EventKind::ExternalEntityReference {
                context,
                system_id: Some(system),
                ..
            } => {
                assert!(context.is_none());
                let load = loads
                    .iter()
                    .find(|(name, _)| *name == system.as_str())
                    .unwrap()
                    .1;
                if matches!(load, Load::Skip) {
                    continue;
                }
                let mut child = parser
                    .external_child(None, None)
                    .map_err(|error| error.kind)?;
                let bytes = match load {
                    Load::Parse(bytes) | Load::IgnoreError(bytes) => bytes,
                    Load::EmptyNonfinal => b"",
                    Load::Skip => unreachable!(),
                };
                let mut result = Ok(());
                if bytes.is_empty() {
                    child
                        .feed(b"", !matches!(load, Load::EmptyNonfinal))
                        .map_err(|error| error.kind)?;
                    result = drain(&mut child, loads, chunk, declarations, depth + 1);
                }
                for (index, part) in bytes.chunks(chunk).enumerate() {
                    child
                        .feed(part, (index + 1) * chunk >= bytes.len())
                        .map_err(|error| error.kind)?;
                    result = drain(&mut child, loads, chunk, declarations, depth + 1);
                    if result.is_err() {
                        break;
                    }
                }
                if !matches!(load, Load::IgnoreError(_)) {
                    result?;
                }
                if child.is_finished() {
                    parser
                        .merge_external_subset(&child)
                        .map_err(|error| error.kind)?;
                }
            }
            EventKind::EntityDeclaration {
                name,
                value: Some(value),
                ..
            } => {
                declarations.push((name.to_string(), value.to_string()));
            }
            _ => {}
        }
    }
    Ok(())
}

fn parse(
    bytes: &[u8],
    chunk: usize,
    mode: u8,
    standalone: bool,
    loads: &[(&str, Load)],
    config: Config,
) -> Result<Vec<(String, String)>, ErrorKind> {
    let mut root = Parser::new(config);
    if standalone {
        root.feed(b"<?xml version='1.0' standalone='yes'?>", false)
            .unwrap();
        while root.next_event().unwrap().is_some() {}
    }
    let mut parser = root
        .external_child(None, None)
        .map_err(|error| error.kind)?;
    parser.set_default_events(true);
    assert!(parser.set_param_entity_parsing(mode));
    let mut declarations = Vec::new();
    for (index, part) in bytes.chunks(chunk).enumerate() {
        parser
            .feed(part, (index + 1) * chunk >= bytes.len())
            .map_err(|error| error.kind)?;
        drain(&mut parser, loads, chunk, &mut declarations, 0)?;
    }
    Ok(declarations)
}

#[test]
fn external_value_bytes_remain_data_at_every_chunk_width() {
    let dtd = "<!ENTITY % p SYSTEM 'p'><!ENTITY e 'L%p;R'><!ENTITY after 'A'>";
    let mut encodings = vec![dtd.as_bytes().to_vec()];
    for little in [true, false] {
        let mut bytes = if little {
            vec![0xff, 0xfe]
        } else {
            vec![0xfe, 0xff]
        };
        for unit in dtd.encode_utf16() {
            bytes.extend_from_slice(&if little {
                unit.to_le_bytes()
            } else {
                unit.to_be_bytes()
            });
        }
        encodings.push(bytes);
    }
    for bytes in encodings {
        for chunk in 1..=bytes.len() {
            for mode in 0..=2 {
                let declarations = parse(
                    &bytes,
                    chunk,
                    mode,
                    false,
                    &[("p", Load::Parse(b"\"&#x1F600;&#13;&#10;&amp;\""))],
                    Config::default(),
                )
                .unwrap();
                assert_eq!(
                    declarations,
                    [
                        ("e".into(), "L\"😀\r\n&amp;\"R".into()),
                        ("after".into(), "A".into())
                    ]
                );
            }
        }
    }
}

#[test]
fn initialized_unread_and_ignored_error_values_preserve_distinct_results() {
    let dtd = b"<!ENTITY % p SYSTEM 'p'><!ENTITY e 'L%p;R'><!ENTITY after 'A'>";
    for (load, expected, skip) in [
        (Load::Parse(b"X"), "LXR", false),
        (Load::Skip, "LR", true),
        (Load::EmptyNonfinal, "LR", false),
        (Load::IgnoreError(b"&amp;"), "LR", false),
        (Load::IgnoreError(b"\"a&#0;b\""), "L\"aR", false),
    ] {
        for standalone in [false, true] {
            for chunk in [1, 3, dtd.len()] {
                let values =
                    parse(dtd, chunk, 0, standalone, &[("p", load)], Config::default()).unwrap();
                assert_eq!(values[0], ("e".into(), expected.into()));
                assert_eq!(values.len(), if skip && !standalone { 1 } else { 2 });
            }
        }
    }
}

#[test]
fn nested_value_output_and_child_truncation_follow_source_boundaries() {
    let dtd = b"<!ENTITY % p SYSTEM 'p'><!ENTITY % q SYSTEM 'q'><!ENTITY % i 'I'><!ENTITY e 'L%p;R'><!ENTITY after 'A'>";
    for (p, q, expected, skip) in [
        (b"X%q;Y".as_slice(), Load::Parse(b"Q"), "LXQYR", false),
        (
            b"X%q;Y".as_slice(),
            Load::IgnoreError(b"\"Q&#0;Z\""),
            "LX\"QYR",
            false,
        ),
        (b"X%i;Y".as_slice(), Load::Parse(b""), "LXR", false),
        (b"X%missing;Y".as_slice(), Load::Parse(b""), "LXR", true),
    ] {
        let values = parse(
            dtd,
            1,
            2,
            false,
            &[("p", Load::Parse(p)), ("q", q)],
            Config::default(),
        )
        .unwrap();
        assert_eq!(values[1], ("e".into(), expected.into()));
        assert_eq!(values.len(), if skip { 2 } else { 3 });
    }
}

#[test]
fn value_children_inherit_active_parameter_names_and_depth() {
    let dtd = b"<!ENTITY % p SYSTEM 'p'><!ENTITY % q SYSTEM 'q'><!ENTITY % e 'L%p;R'>";
    for loads in [
        vec![("p", Load::Parse(b"%p;"))],
        vec![("p", Load::Parse(b"%e;"))],
        vec![("p", Load::Parse(b"%q;")), ("q", Load::Parse(b"%p;"))],
    ] {
        assert_eq!(
            parse(dtd, 1, 2, false, &loads, Config::default()),
            Err(ErrorKind::RecursiveEntityReference)
        );
    }
    let config = Config {
        limits: Limits {
            max_entity_depth: 2,
            ..Limits::default()
        },
        ..Config::default()
    };
    assert_eq!(
        parse(
            dtd,
            1,
            2,
            false,
            &[("p", Load::Parse(b"%q;")), ("q", Load::Parse(b"Q"))],
            config
        ),
        Err(ErrorKind::LimitExceeded)
    );
}

#[test]
fn value_channel_survives_custom_encoding_recovery_and_parent_drop() {
    fn assert_send<T: Send>() {}
    assert_send::<Parser>();
    let root = Parser::new(Config::default());
    let mut dtd = root.external_child(None, None).unwrap();
    dtd.feed(b"<!ENTITY % p SYSTEM 'p'><!ENTITY e '%p;'>", true)
        .unwrap();
    while !matches!(
        dtd.next_event().unwrap().unwrap().kind,
        EventKind::ExternalEntityReference { .. }
    ) {}
    let mut child = dtd
        .external_child_with_encoding(None, Some("custom"))
        .unwrap();
    child.feed(b"\"\x80&#13;\"", true).unwrap();
    assert_eq!(
        child.next_event().unwrap_err().kind,
        ErrorKind::UnknownEncoding
    );
    let mut map = std::array::from_fn(|index| index as i32);
    map[128] = 0x20ac;
    child.set_encoding_map("custom", map).unwrap();
    while child.next_event().unwrap().is_some() {}
    dtd.merge_external_subset(&child).unwrap();
    let value = dtd.next_event().unwrap().unwrap();
    assert!(
        matches!(value.kind, EventKind::EntityDeclaration { value: Some(ref value), .. } if value == "\"€\r\"")
    );
    drop(root);
    drop(dtd);
    assert!(child.is_finished());
    drop(child);
}

#[test]
fn external_value_output_and_family_work_have_independent_limits() {
    let dtd = b"<!ENTITY % p SYSTEM 'p'><!ENTITY e '%p;%p;%p;'>";
    let config = Config {
        limits: Limits {
            max_token_bytes: 40,
            ..Limits::default()
        },
        ..Config::default()
    };
    assert_eq!(
        parse(
            dtd,
            1,
            2,
            false,
            &[("p", Load::Parse(b"abcdefghijklmnopqrst"))],
            config
        ),
        Err(ErrorKind::LimitExceeded)
    );
    let config = Config {
        limits: Limits {
            max_entity_expansion_bytes: 512,
            ..Limits::default()
        },
        ..Config::default()
    };
    assert_eq!(
        parse(dtd, 1, 2, false, &[("p", Load::Parse(b"X"))], config),
        Err(ErrorKind::LimitExceeded)
    );
}

#[test]
fn child_xml_declaration_changes_standalone_without_disabling_ancestor_mode() {
    let dtd = b"<!ENTITY % p SYSTEM 'p'><!ENTITY % q SYSTEM 'q'><!ENTITY e 'L%p;R'>%q;<!ENTITY after 'A'>";
    let values = parse(
        dtd,
        1,
        1,
        false,
        &[
            (
                "p",
                Load::Parse(b"ignored <?xml version='1.0' standalone='yes'?>X%missing;Y"),
            ),
            ("q", Load::Parse(b"<!ENTITY loaded 'yes'>")),
        ],
        Config::default(),
    )
    .unwrap();
    assert_eq!(
        values,
        [
            ("e".into(), "LXR".into()),
            ("loaded".into(), "yes".into()),
            ("after".into(), "A".into())
        ]
    );
}
