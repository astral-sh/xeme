import ctypes as c, json, sys, hashlib
lib=c.CDLL(sys.argv[1]); p=c.c_void_p
for name,restype,args in [('XML_ParserCreate',p,[c.c_char_p]),('XML_ExternalEntityParserCreate',p,[p,c.c_char_p,c.c_char_p]),('XML_SetParamEntityParsing',c.c_int,[p,c.c_int]),('XML_Parse',c.c_int,[p,c.c_char_p,c.c_int,c.c_int]),('XML_GetErrorCode',c.c_int,[p]),('XML_GetCurrentByteIndex',c.c_long,[p]),('XML_ParserFree',None,[p])]:
 f=getattr(lib,name); f.restype=restype; f.argtypes=args
cases=[b'<![IGNORE[unfinished',b'<![INCLUDE[',b'<![IGNORE',b'<![OTHER[]]>',b']]>',b'<!ENTITY % p "]]>"><![INCLUDE[%p;]]>',b'<!ENTITY % p "<![INCLUDE[">%p;]]>',b'<![IGNORE[\x01]]>',b'<![IGNORE[\xe2\x82',b'<!ENTITY % mode "INCLUDE"><![%mode;[<!ENTITY e "ok">]]>']
handler=c.CFUNCTYPE(None,p,p,c.c_int)
lib.XML_SetDefaultHandler.argtypes=[p,handler]
rows=[]
for data in cases:
 for chunk in [1,7,4096]:
  parent=lib.XML_ParserCreate(None); lib.XML_SetParamEntityParsing(parent,2); child=lib.XML_ExternalEntityParserCreate(parent,None,None)
  default=[]
  callback=handler(lambda user, value, length: default.append(c.string_at(value,length).decode('utf8')))
  lib.XML_SetDefaultHandler(child,callback)
  for offset in range(0,len(data),chunk):
   part=data[offset:offset+chunk]; status=lib.XML_Parse(child,part,len(part),int(offset+chunk>=len(data)))
   if status!=1:break
  rows.append({'data':data.decode('latin1'),'chunk':chunk,'status':status,'error':lib.XML_GetErrorCode(child),'index':lib.XML_GetCurrentByteIndex(child),'default':''.join(default)})
  lib.XML_ParserFree(child);lib.XML_ParserFree(parent)
print(json.dumps({'library':sys.argv[1],'sha256':hashlib.sha256(open(sys.argv[1],'rb').read()).hexdigest(),'rows':rows},indent=2))
