from pathlib import Path
import hashlib
import json

ROOT = Path('/tmp/oriole-conditional-review')
LIB = Path('/home/dev-user/.cache/oriole/conditional-target/release/liboriole_expat.so')
EXPECTED = '470a5b172a656c675338f50fac8ce08cb6d32b382249aee9be05a4623081b5c4'
assert hashlib.sha256(LIB.read_bytes()).hexdigest() == EXPECTED
SOURCE = (ROOT / 'probe.py').read_text().split('\nbody = ')[0]
SOURCE = SOURCE.replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so', str(LIB))

def make_probe(*, declaration_only=False, child_rejection=False):
    source = SOURCE
    if declaration_only:
        source = source.replace('<r>&e;</r>', '<r/>')
    if child_rejection:
        source = source.replace('return not_result', 'return not_result if active[1] == "child" else 1')
    scope = {}
    exec(source, scope)
    return scope['probe']

def replay(cases, probe):
    return [probe(case['standalone'], case['mode'], case['data'].encode(),
                  case['expand'], case['not_result']) for case in cases]

def summary(case):
    return {
        'children': [{key: child[key] for key in ['status', 'error']} for child in case['children']],
        'default': case['child_default'],
        'not_standalone': [event[2] for event in case['events'] if event[:2] == ['child', 'not-standalone']],
        'declarations': [[event[1], *event[3:]] for event in case['events']
                         if event[0] == 'child' and event[1] in ['entity', 'attlist']],
        'skipped': [[event[1], *event[3:]] for event in case['events']
                    if event[0] == 'child' and event[1] == 'skipped'],
    }

def compare(reference, candidate):
    differences = []
    for index, (before, after) in enumerate(zip(reference, candidate, strict=True)):
        a, b = summary(before), summary(after)
        delta = {key: {'reference': a[key], 'candidate': b[key]} for key in a if a[key] != b[key]}
        if delta:
            differences.append({'index': index,
                                **{key: before[key] for key in ['standalone', 'mode', 'data', 'expand', 'not_result']},
                                **{key: before[key] for key in ['label', 'skipped'] if key in before},
                                'difference': delta})
    return differences

references = {
    'broad': json.loads((ROOT / 'results.json').read_text())['cases'],
    'skipped-values': json.loads((ROOT / 'skipped-values-results.json').read_text()),
    'child-reject': json.loads((ROOT / 'child-reject-results.json').read_text())['reference'],
}
probes = {
    'broad': make_probe(),
    'skipped-values': make_probe(declaration_only=True),
    'child-reject': make_probe(child_rejection=True),
}
for name, cases in references.items():
    candidate = replay(cases, probes[name])
    differences = compare(cases, candidate)
    output = {'library': str(LIB), 'sha256': EXPECTED,
              'cases': candidate, 'differences': differences}
    (ROOT / f'final-{name}.json').write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({'suite': name, 'cases': len(cases), 'differences': len(differences)}))
    for difference in differences:
        if name != 'broad':
            print(json.dumps(difference))
assert hashlib.sha256(LIB.read_bytes()).hexdigest() == EXPECTED
