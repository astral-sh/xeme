import ctypes as c
import hashlib
import json
from pathlib import Path

LIB = Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so')
l = c.CDLL(str(LIB))
P, S, I = c.c_void_p, c.c_char_p, c.c_int
DEFAULT = c.CFUNCTYPE(None, P, P, I)
NOT = c.CFUNCTYPE(I, P)
SKIP = c.CFUNCTYPE(None, P, S, I)
ENTITY = c.CFUNCTYPE(None, P, S, I, P, I, S, S, S, S)
ATTLIST = c.CFUNCTYPE(None, P, S, S, S, S, I)
EXTERNAL = c.CFUNCTYPE(I, P, S, S, S, S)
START = c.CFUNCTYPE(None, P, S, c.POINTER(S))
for name, result, arguments in [
    ('XML_ParserCreate', P, [S]),
    ('XML_SetParamEntityParsing', I, [P, I]),
    ('XML_ExternalEntityParserCreate', P, [P, S, S]),
    ('XML_Parse', I, [P, S, I, I]),
    ('XML_GetErrorCode', I, [P]),
    ('XML_GetCurrentByteIndex', c.c_long, [P]),
    ('XML_ParserFree', None, [P]),
    ('XML_SetDefaultHandler', None, [P, DEFAULT]),
    ('XML_SetDefaultHandlerExpand', None, [P, DEFAULT]),
    ('XML_SetNotStandaloneHandler', None, [P, NOT]),
    ('XML_SetSkippedEntityHandler', None, [P, SKIP]),
    ('XML_SetEntityDeclHandler', None, [P, ENTITY]),
    ('XML_SetAttlistDeclHandler', None, [P, ATTLIST]),
    ('XML_SetExternalEntityRefHandler', None, [P, EXTERNAL]),
    ('XML_SetStartElementHandler', None, [P, START]),
]:
    fn = getattr(l, name)
    fn.restype = result
    fn.argtypes = arguments

def decode(value):
    return value.decode() if value is not None else None

def probe(standalone, mode, data, expand, not_result):
    events = []
    children = []
    parent = l.XML_ParserCreate(None)
    active = [parent, 'parent']
    def event(kind, *values):
        events.append([active[1], kind, l.XML_GetCurrentByteIndex(active[0]), *values])
    def not_standalone(_):
        event('not-standalone')
        return not_result
    def entity(_, name, parameter, value, length, base, system, public, notation):
        event('entity', decode(name), parameter,
              c.string_at(value, length).decode() if value else None)
    def start(_, name, attributes):
        pairs = []
        index = 0
        while attributes[index]:
            pairs.append([decode(attributes[index]), decode(attributes[index+1])])
            index += 2
        event('start', decode(name), pairs)
    def external(parser, context, base, system, public):
        child = l.XML_ExternalEntityParserCreate(parser, context, None)
        active[:] = [child, 'child']
        l.XML_SetParamEntityParsing(child, mode)
        status = l.XML_Parse(child, data, len(data), 1)
        children.append({'status': status, 'error': l.XML_GetErrorCode(child),
                         'index': l.XML_GetCurrentByteIndex(child)})
        active[:] = [parent, 'parent']
        l.XML_ParserFree(child)
        return status
    callbacks = [
        DEFAULT(lambda _, value, length: event('default', c.string_at(value, length).decode())),
        NOT(not_standalone),
        SKIP(lambda _, name, parameter: event('skipped', decode(name), parameter)),
        ENTITY(entity),
        ATTLIST(lambda _, element, name, kind, value, required:
                event('attlist', decode(element), decode(name), decode(value))),
        EXTERNAL(external),
        START(start),
    ]
    l.XML_SetParamEntityParsing(parent, 2)
    getattr(l, 'XML_SetDefaultHandlerExpand' if expand else 'XML_SetDefaultHandler')(parent, callbacks[0])
    l.XML_SetNotStandaloneHandler(parent, callbacks[1])
    l.XML_SetSkippedEntityHandler(parent, callbacks[2])
    l.XML_SetEntityDeclHandler(parent, callbacks[3])
    l.XML_SetAttlistDeclHandler(parent, callbacks[4])
    l.XML_SetExternalEntityRefHandler(parent, callbacks[5])
    l.XML_SetStartElementHandler(parent, callbacks[6])
    declaration = b'' if standalone is None else f"<?xml version='1.0' standalone='{standalone}'?>".encode()
    document = declaration + b"<!DOCTYPE r SYSTEM 'd'><r>&e;</r>"
    status = l.XML_Parse(parent, document, len(document), 1)
    result = {'standalone': standalone, 'mode': mode, 'data': data.decode(),
              'expand': expand, 'not_result': not_result, 'children': children,
              'parent_status': status, 'parent_error': l.XML_GetErrorCode(parent),
              'events': events,
              'child_default': ''.join(event[3] for event in events if event[:2] == ['child', 'default'])}
    l.XML_ParserFree(parent)
    return result

body = b"<!ENTITY e 'value'><!ATTLIST r a CDATA 'yes'>"
inputs = [
    b'<![INCLUDE%missing;[' + body + b']]>',
    b"<!ENTITY % k 'IGNORE'><![INCLUDE%k;[" + body + b']]>',
    b"<!ENTITY % k 'INCLUDE'><![%k;[" + body + b']]>',
    b'<![INCLUDE[' + body + b']]>',
]
results = [probe(standalone, mode, data, expand, 1)
           for standalone in [None, 'no', 'yes']
           for mode in [0, 1, 2]
           for data in inputs
           for expand in [False, True]]
results.extend(probe(standalone, mode, inputs[0], False, 0)
               for standalone in [None, 'no', 'yes'] for mode in [0, 1, 2])
output = {'library': str(LIB), 'sha256': hashlib.sha256(LIB.read_bytes()).hexdigest(),
          'cases': results}
Path('/tmp/oriole-conditional-review/results.json').write_text(json.dumps(output, indent=2) + '\n')
for result in results:
    if result['expand']:
        continue
    print(json.dumps({key: value for key, value in result.items() if key != 'events'}))
    print('events:', json.dumps([event for event in result['events'] if event[1] != 'default']))
