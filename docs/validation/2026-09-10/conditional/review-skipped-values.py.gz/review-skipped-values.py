from pathlib import Path
import json

root = Path('/tmp/oriole-conditional-review')
source = (root / 'probe.py').read_text().split('\nbody = ')[0]
source = source.replace("<r>&e;</r>", "<r/>")
scope = {}
exec(source, scope)

values = [
    '', '<', '&', '&missing', '&missing;', '&;', '&#;', '&#0;', '&#x;', '&#x0;',
    '&#x110000;', '&#xD800;', '&#9999999999999999999999999999999999999999;',
    '&bad name;', '&a:b;', '&1bad;', '%missing;', '%', '%bad name;',
    '<![INCLUDE[', ']]>', '\x01', '\x00', '\r\n',
]
declarations = [(kind + ':' + repr(value),
                 (f'<!ENTITY e "{value}">' if kind == 'entity'
                  else f'<!ATTLIST r a CDATA "{value}">').encode())
                for kind in ['entity', 'attribute'] for value in values]
declarations += [
    (label, declaration.encode()) for label, declaration in [
        ('parameter-value', '<!ENTITY % p "%missing;">'),
        ('external-entity', '<!ENTITY e SYSTEM "x">'),
        ('public-invalid', '<!ENTITY e PUBLIC "invalid\tpublic" "x">'),
        ('external-no-id', '<!ENTITY e SYSTEM>'),
        ('external-missing-system', '<!ENTITY e PUBLIC "x">'),
        ('invalid-entity-name', '<!ENTITY 1bad "x">'),
        ('entity-extra', '<!ENTITY e "x" "extra">'),
        ('invalid-type', '<!ATTLIST r a FOO "x">'),
        ('type-notation', '<!ATTLIST r a NOTATION (x|y) "&missing;">'),
        ('type-token', '<!ATTLIST r a NMTOKENS "&missing;">'),
        ('type-id', '<!ATTLIST r a ID "&missing;">'),
        ('type-enum', '<!ATTLIST r a (x|y) "&missing;">'),
        ('type-empty-enum', '<!ATTLIST r a () "x">'),
        ('type-enum-missing-member', '<!ATTLIST r a (x|) "x">'),
        ('type-enum-number', '<!ATTLIST r a (1|2) "x">'),
        ('type-enum-duplicate', '<!ATTLIST r a (x|x) "x">'),
        ('default-required', '<!ATTLIST r a CDATA #REQUIRED>'),
        ('default-implied', '<!ATTLIST r a CDATA #IMPLIED>'),
        ('default-fixed', '<!ATTLIST r a CDATA #FIXED "&#0;">'),
        ('default-fixed-no-value', '<!ATTLIST r a CDATA #FIXED>'),
        ('default-bogus', '<!ATTLIST r a CDATA #BOGUS>'),
        ('default-unquoted', '<!ATTLIST r a CDATA unquoted>'),
        ('default-required-extra', '<!ATTLIST r a CDATA #REQUIRED "x">'),
        ('default-missing-space', '<!ATTLIST r a CDATA"x">'),
    ]
]
results = []
for label, declaration in declarations:
    for skipped in [False, True]:
        header = b'<![INCLUDE%missing;[' if skipped else b'<![INCLUDE['
        data = header + declaration + b']]>'
        result = scope['probe']('no', 2, data, False, 1)
        results.append({'label': label, 'skipped': skipped, **result})
(root / 'skipped-values-results.json').write_text(json.dumps(results, indent=2) + '\n')
for normal, skipped in zip(results[::2], results[1::2]):
    print(skipped['label'], 'normal', normal['children'], 'skipped', skipped['children'])
