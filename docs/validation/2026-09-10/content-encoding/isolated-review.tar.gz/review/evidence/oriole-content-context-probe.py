from pathlib import Path
import json,hashlib
code=Path('/tmp/oriole-namespace-version-review.py').read_text().split('namespace_rows=[]')[0]
code=code.replace("root=l.XML_ParserCreateNS(None,b'|') if ns else l.XML_ParserCreate(None)","root=l.XML_ParserCreateNS(protocol,b'|') if ns else l.XML_ParserCreate(protocol)")
code=code.replace('child=l.XML_ExternalEntityParserCreate(parent,context,None)',"child=l.XML_ExternalEntityParserCreate(parent,context,protocol if system==b'p' else None)")
code=code.replace("child=l.XML_ExternalEntityParserCreate(root,c.cast(c.c_char_p(b''),P)if kind=='general' else None,None)","child=l.XML_ExternalEntityParserCreate(root,c.cast(c.c_char_p(b''),P)if kind=='general' else None,protocol)")
scope={};exec(code,scope);rows=[]
for body in [b'\xff\xfeL ',b'\xfe\xff L',b'\xef\xbb\xbfX',b'X\0',b' \0X\0']:
 for protocol in [None,b'ISO-8859-1',b'UTF-16']:
  scope['protocol']=protocol
  for kind in ['general','dtd','value']:
   for width in [0,1,3]:
    document=b'<!DOCTYPE r SYSTEM "d"><r/>'if kind=='value'else body
    row={'input_hex':body.hex(),'protocol':protocol.decode()if protocol else None,'kind':kind,'width':width}
    for label,l in zip(['reference','candidate'],scope['libs']):row[label]=scope['parse'](l,document,width,False,kind,body)
    rows.append(row)
Path('/tmp/oriole-content-context-probe.json').write_text(json.dumps({'cases':len(rows),'rows':rows},indent=2)+'\n')
for r in rows:
 if r['width']==0:print(r['input_hex'],r['protocol'],r['kind'],[(r[k]['status'],r[k]['error'],r[k]['children'])for k in ['reference','candidate']])
