from pathlib import Path
import subprocess,os,json,hashlib,re
root=Path('/tmp/oriole-content-encoding');runner=Path('/tmp/oriole-upstream-final-values/runtests')
fixed=['test_ext_entity_latin1_utf16le_bom','test_ext_entity_latin1_utf16be_bom','test_ext_entity_latin1_utf16le_bom2','test_ext_entity_latin1_utf16be_bom2','test_ext_entity_utf16_unknown']
controls=['test_ext_entity_utf16_be','test_ext_entity_utf16_le','test_ext_entity_utf8_non_bom','test_unknown_encoding_long_name_2','test_unknown_encoding_success','test_unknown_encoding_long_name_1','test_long_utf8_character']
rows={}
for label,library in [('reference','/home/dev-user/.cache/oriole/expat-build/libexpat.so'),('baseline','/tmp/oriole-values-final-source/liboriole_expat.so'),('candidate','/home/dev-user/.cache/oriole/content-encoding-target/debug/liboriole_expat.so')]:
 env=dict(os.environ,LD_PRELOAD=library,ORIOLE_CHUNK_MASK='63',ORIOLE_DEFERRAL_MASK='3',ORIOLE_SELECTED_TESTS=','.join(fixed+controls),ORIOLE_TEST_TIMEOUT='3',ORIOLE_MEMORY_MIB='1024',ORIOLE_RSS_MIB='768')
 result=subprocess.run(['taskset','-c','4',str(runner)],env=env,capture_output=True,text=True,timeout=180)
 (root/('upstream-'+label+'.log')).write_text(result.stdout+result.stderr)
 origins=re.findall(r'^ORIOLE_LIBRARY\t(.+)$',result.stdout,re.M);assert origins==[library],origins
 parsed=re.findall(r'^ORIOLE_RESULT\t([^\t]+)\t([^\t]+)\t([^\t]+)\t(\d+)$',result.stdout,re.M)
 rows[label]={'library':library,'sha256':hashlib.sha256(Path(library).read_bytes()).hexdigest(),'origins':origins,'status':result.returncode,'results':parsed}
 print(label,len(parsed),{name:sum(r[1]==name and r[2]=='pass'for r in parsed)for name in fixed+controls},flush=True)
(root/'upstream.json').write_text(json.dumps({'runner':str(runner),'runner_sha256':hashlib.sha256(runner.read_bytes()).hexdigest(),'fixed_tests':fixed,'controls':controls,'runs':rows},indent=2)+'\n')
