from pathlib import Path
import hashlib,io,json,re,tarfile
ROOT=Path('/home/dev-user/code/oss/oriole')
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['README.md','docs/review.md','docs/validation/2026-09-10/version-consistent-runtime/README.md','tools/cpython/README.md','docs/validation/2026-09-10/version-consistent-pbs/README.md','docs/validation/2026-09-10/cpython-fresh-imports/README.md']
for name in paths:
 p=ROOT/name
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if target.startswith(('http:','https:','#','codex:')):continue
  q=(p.parent/target.split('#')[0]).resolve();assert q.exists(),(name,target)
archives={}
for name,count in [('version-consistent-pbs',12),('cpython-fresh-imports',13)]:
 d=ROOT/'docs/validation/2026-09-10'/name;files=json.loads((d/'files.json').read_text());raw=(d/'evidence.tar.gz').read_bytes()
 assert sha(raw)==files['archive_sha256'];members={}
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
  for m in tar:
   assert m.isfile() and m.name not in members
   b=tar.extractfile(m).read();members[m.name]=b
   assert len(b)==files['members'][m.name]['bytes'] and sha(b)==files['members'][m.name]['sha256']
 assert len(members)==count and set(members)==set(files['members'])
 assert sha(members['manifest.json'])==files['handoff_manifest_sha256']
 if name=='version-consistent-pbs':
  assert sha(members['report.json'])=='b9b5f710e5595d50f35cf0eda49749dc503e87f590f14c18ca55cf6a42cf2c74'
  nested_maps=json.loads(members['archive-members.json'])
 else:
  assert sha(members['oriole-cpython-fresh-import-independent-review.json'])=='52ff7f237ee4a2bb01e8b1e33d872ab91cf0fda2e7c2df63745d3297b858f109'
  nested_maps={'evidence.tar.gz':json.loads(members['evidence-members.json'])}
 inner_count=0
 for archive,expected in nested_maps.items():
  seen=set()
  with tarfile.open(fileobj=io.BytesIO(members[archive]),mode='r:gz') as tar:
   for m in tar:
    assert m.isfile() and m.name not in seen;seen.add(m.name);b=tar.extractfile(m).read()
    assert len(b)==expected[m.name]['bytes'] and sha(b)==expected[m.name]['sha256'];inner_count+=1
  assert seen==set(expected)
 assert inner_count==(114 if name=='version-consistent-pbs' else 25)
 archives[name]={'outer_members':len(members),'nested_regular_members':inner_count,'archive_sha256':sha(raw),'handoff_manifest_sha256':files['handoff_manifest_sha256']}
helpers={name:sha((ROOT/'tools/cpython'/name).read_bytes()) for name in ['run.py','extension_loader.py','check_extension_imports.py']}
assert helpers=={'run.py':'c682b96574c4cf34873899514873bf13947449a7adb35de404c8b73e96ec7fda','extension_loader.py':'2116f8972094890d54dbe5fd915ed7eb8619f716ce0dd4e7ff63acf15ef4c5f3','check_extension_imports.py':'473e00f55f8bc92a69645df109438da1cf8cdb3f7e1ce08c8fdf7d055b14c3d5'}
report={'status':'passed_no_corrections_requested','scope':'Independent review of six root-authored documents against immutable PBS/fresh-import reports; compressed artifact bytes and local links checked. No parser/test/build/container rerun or runtime approval claim.',
 'documents':{name:sha((ROOT/name).read_bytes()) for name in paths},'helpers':helpers,'archives':archives,
 'verified_claims':[
  'PBS workflow and local original glibc gate both remain failed; distribution/validator and1024 threaded parses are successful subchecks, not a passing overall gate.',
  'Each custom invocation reports22 tests with5skips/17successes. CI802 initial methods plus4 reruns gives806 executions and4 occurrences of the same2 failures.',
  'The53,609,802-byte archive504b hash is explicitly locally computed after the CI hash step was skipped. Source64 and libexpat.a CI/archive identities match the frozen report; no local/PBS compiler-binary equivalence is asserted.',
  'Earlier803/31 results remain unchanged and limited by19accelerator-specific skips. Corrected local802/14 and installedPBS802/13 counts explain fresh imports, NoAccelerator class setup, _testcapi and resource settings.',
  'Fresh-import tables preserve baseline2failures and Expat success;14skips are5methods+8subtests+1class-setup. Runtime prototype evidence is explicitly separate from the harness-only patch.',
  'The preflight routes only2modules, verifies initial/fresh origins, completes parses, preserves blocked imports and rejects optimized Python. Root3helper hashes equal reviewed final source.',
  'Both published evidence archives and every25outer/139nested member hash reproduce files.json and immutable handoff manifests; all cited local targets exist.'
 ],
 'limitations':'Documentation claims about canonical Ruff/ty and negative launches are supported by retained author evidence; this review does not rerun those commands. Both unchanged XML failures and pre-existing API gaps remain visible.',
 'audit_script_sha256':sha(Path(__file__).read_bytes())}
out=Path('/tmp/oriole-cpython-pbs-docs-review.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'review':str(out),'sha256':sha(out.read_bytes())}))
