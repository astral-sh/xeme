# Persistent CPython XML extension imports

This harness-only patch keeps initial and fresh `pyexpat`/`_elementtree` imports on the selected frozen extensions. It preserves deliberately blocked imports for pure-Python tests. Mandatory preflight verifies file/spec origins and hashes, the unmodified accelerator test module’s cET/cET_alias fresh imports, and pure/blocked behavior. Optimized Python is rejected because assertions enforce these checks.

With this corrected harness, unchanged 4b Oriole still fails precisely the two ordinary-text newline assertions: 802 tests, 14 reported skips, exit 2. Pinned Expat passes 802 with the same 14 skips. Those skips include subtests and one class setup; see summary and independent review. Previous initial-only-loader 803/31 results remain historical evidence with incomplete accelerator coverage. No old result is relabeled.

The runtime newline candidate is separate and is not part of this patch. Included controller metadata also names its separately stored runs. `evidence.tar.gz` contains full corrected baseline/reference logs, origins, source copies, commands and negative checks; binaries are omitted and retained by hash/path. Existing two gate-unit tests, Ruff and ty pass. The initial isolated unit-test launcher lacked its local module path and is retained beside the corrected invocation.
