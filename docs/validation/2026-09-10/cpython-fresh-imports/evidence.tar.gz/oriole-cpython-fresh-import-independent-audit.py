from pathlib import Path
import hashlib,json,re
ROOT=Path('/tmp/oriole-c-text-boundaries')
EVIDENCE=Path('/tmp/oriole-c-text-boundaries-evidence')
CONTROLLER=EVIDENCE/'cpython-frozen-controller.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def rows(path):
    result={};pending=None;extra=[]
    def add(item,status):
        name,identifier=item
        if name=='setUpClass':return
        assert name.startswith('test') and identifier not in result
        result[identifier]=status
    for line in path.read_text().splitlines():
        match=re.match(r'^(\w+) \((test\.[^)]+)\)(?: \.\.\. (.*))?$',line)
        if match:
            if pending is not None:
                assert any(f'{pending[0]} ({pending[1]}) ' in subtest for subtest in extra)
                add(pending,'subtest outcomes')
            pending=(match[1],match[2]);status=match[3]
            if status:add(pending,status);pending=None
        elif pending is not None:
            if re.match(r'^(ok|FAIL|ERROR|expected failure|skipped .+)$',line):
                add(pending,line);pending=None
            elif line.startswith('  ') and ' ... ' in line:extra.append(line)
            elif ' ... ' in line and line.rsplit(' ... ',1)[1]:
                add(pending,line.rsplit(' ... ',1)[1]);pending=None
    assert pending is None
    return result

control=json.loads(CONTROLLER.read_text())
assert control['status']=='completed' and len(control['rows'])==6 and control['sources_unchanged']
assert control['sources_before']==control['sources_after']
for path,digest in control['sources_after'].items():assert sha(Path(path))==digest
expected={
 'baseline-shared':('ac6a0a6adcabba65ef338d362f438c588ad4a01a9821989bae28f445ba7778ac',2),
 'reference-shared':('7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478',0),
 'candidate-shared':('c77d85810166b5755a58f9287968f6f398ee102a445adc239a9700db3cf1a9ec',0),
 'candidate-shared-consumer-fix':('c77d85810166b5755a58f9287968f6f398ee102a445adc239a9700db3cf1a9ec',0),
 'candidate-static':('4799412380d291c402e571ff6a841dd5cbb53159a60e7f6d4f974e50d499bc90',0),
 'candidate-static-consumer-fix':('4799412380d291c402e571ff6a841dd5cbb53159a60e7f6d4f974e50d499bc90',0),
}
reports={};method_rows={}
for row in control['rows']:
    label=row['label'];directory=EVIDENCE/'cpython-fresh-frozen'/label
    summary=json.loads((directory/'summary.json').read_text())
    assert summary==row['summary'] and sha(directory/'summary.json')==row['summary_sha256']
    assert (row['library_sha256'],row['exit_code'])==expected[label]
    assert summary['library_sha256']==expected[label][0]
    assert summary['tests_exit_code']==summary['gate_exit_code']==expected[label][1]
    assert summary['probe_exit_code']==summary['origin_exit_code']==0 and summary['text_fragmentation'] is None
    assert '--allow-text-fragmentation' not in row['command']
    assert ('--consumer-fix' in row['command'])==label.endswith('consumer-fix')
    assert summary['loader_sha256']==sha(ROOT/'tools/cpython/extension_loader.py')==sha(directory/'sitecustomize.py')
    assert summary['import_check_sha256']==sha(ROOT/'tools/cpython/check_extension_imports.py')
    assert sha(directory/'pyexpat.c')==summary['compiled_source_sha256']
    library_name=Path(row['command'][row['command'].index('--library')+1]).name
    assert sha(directory/library_name)==expected[label][0]
    origin=json.loads((directory/'origin.log').read_text())
    assert origin['status']=='passed' and origin['accelerator_imports']==['cET','cET_alias']
    assert origin['pure_python_and_blocked_imports']=='passed' and len(origin['origins'])==4
    for key,entry in origin['origins'].items():
        kind,name=key.split(':');assert kind in ['initial','fresh'] and name in ['pyexpat','_elementtree']
        path=Path(entry['path']);assert path.parent==directory and path.name.startswith(name+'.')
        assert sha(path)==entry['sha256']
    methods=rows(directory/'tests.log');method_rows[label]=methods
    assert len(methods)==802
    failures=sorted(k for k,v in methods.items() if v in ('FAIL','ERROR'))
    expected_failures=['test.test_pyexpat.BufferTextTest.test1','test.test_sax.CDATAHandlerTest.test_handlers'] if label=='baseline-shared' else []
    assert failures==expected_failures
    assert sum(s.startswith('skipped') for s in methods.values())==5
    skip_lines=[line for line in (directory/'tests.log').read_text().splitlines() if ' ... skipped ' in line]
    assert len(skip_lines)==14 and sum(line.startswith('  ') for line in skip_lines)==8
    class_skips=re.findall(r'^setUpClass .* \.\.\. skipped .+$',(directory/'tests.log').read_text(),re.MULTILINE)
    assert class_skips==["setUpClass (test.test_xml_etree_c.NoAcceleratorTest) ... skipped 'only for the Python version'"]
    assert sum(s=='expected failure' for s in methods.values())==3
    assert not any('requires _elementtree' in s for s in methods.values())
    for name in ['test_correct_import_cET','test_correct_import_cET_alias','test_parser_comes_from_C']:
        assert methods['test.test_xml_etree_c.TestAcceleratorImported.'+name]=='ok'
    reports[label]={'methods':len(methods),'reported_skips':14,'whole_method_skips':5,'subtest_skips':8,'class_setup_skips':1,'expected_failures':3,'unexpected_failures':failures,'suite_exit':expected[label][1],
                    'library_sha256':expected[label][0],'summary_sha256':sha(directory/'summary.json'),
                    'tests_log_sha256':sha(directory/'tests.log'),'origin_log_sha256':sha(directory/'origin.log'),'skip_lines':skip_lines}
ref=method_rows['reference-shared']
for row in reports.values(): assert row['skip_lines']==reports['reference-shared']['skip_lines']
for label,methods in method_rows.items():
    changed=[k for k in methods if methods[k]!=ref[k]]
    assert changed==(['test.test_pyexpat.BufferTextTest.test1','test.test_sax.CDATAHandlerTest.test_handlers'] if label=='baseline-shared' else [])
prior=rows(Path('/tmp/oriole-version-final-consumer-validation/cpython/static-consumer-fix/tests.log'))
base=method_rows['baseline-shared'];recover=[k for k in base if prior.get(k)=="skipped 'requires _elementtree'"]
assert len(recover)==19 and sum(base[k]=='ok' for k in recover)==18
assert set(prior)-set(base)=={'test.test_xml_etree_c.NoAcceleratorTest.test_correct_import_pyET'}
unchanged=json.loads(Path('/tmp/oriole-pbs-version-followup/report.json').read_text())['test_count_and_coverage']['upstream_six_module_hashes_exact']
for name,digest in unchanged.items():assert sha(Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Lib/test')/(name+'.py'))==digest
result={
 'status':'no_blocker_found',
 'scope':'Independent persistent-loader source review and saved-data/hash reconstruction. No compiler/parser/CPython test rerun; runtime compatibility candidate and performance selection are separate.',
 'source_sha256':control['sources_after'],
 'source_review':[
  'Finder matches only pyexpat and _elementtree and returns an explicit extension-file spec before BuiltinImporter. It does not alter other imports or upstream tests.',
  'Normal importlib machinery honors sys.modules caching and None block sentinels before invoking the finder; pure-Python accelerator blocking remains effective.',
  'The mandatory subprocess preflight verifies initial/fresh __file__ and spec origin, records both binary hashes, executes both unchanged accelerator import paths, checks a completed parse, and tests pure-Python and explicit blocked imports.',
  'The preflight now explicitly rejects optimized Python before assertions can be disabled. The preserved earlier runs lacked that guard; their controlled unoptimized results are historical evidence, not relabelled as final.',
  'run.py checks clean pinned CPython revision before building, retains separate explicit consumer-backport rows, and records helper hashes and raw origin output before running unchanged suites.'
 ],
 'saved_runs':reports,
 'coverage_repair':{'prior_local_methods':803,'prior_local_skips':31,'repaired_methods':802,'repaired_skips':14,
                    'prior_requires_accelerator_skips':19,'now_passed':18,'still_memory_skipped':1,
                    'removed_method':'NoAcceleratorTest.test_correct_import_pyET skips during setUpClass with the working accelerator',
                    'scope':'The managed local interpreter lacks _testcapi, unlike PBS; this contributes local14 versus PBS default-resource13. Historical local803/31 reports remain unchanged and limited.'},
 'all_candidate_and_reference_method_statuses_identical':True,
 'baseline_only_method_differences':['BufferTextTest.test1','CDATAHandlerTest.test_handlers'],
 'six_upstream_test_sources_unchanged':unchanged,
 'controller_sha256':sha(CONTROLLER),'audit_script_sha256':sha(Path(__file__))
}
out=Path('/tmp/oriole-cpython-fresh-import-independent-review.json');out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'review':str(out),'sha256':sha(out),'runs':len(reports)}))
