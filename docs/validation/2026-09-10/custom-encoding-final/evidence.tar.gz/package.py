from pathlib import Path
import gzip,hashlib,io,json,re,statistics,tarfile
source=Path('/tmp/oriole-custom-final');repo=Path('/home/dev-user/code/oss/oriole-api-followup');out=repo/'docs/validation/2026-09-10/custom-encoding-final';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();entries={}
for p in sorted(source.rglob('*')):
 if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log','.py','.patch','.gz','.c','.h']:
  entries[str(p.relative_to(source))]=p.read_bytes()
entries['review.json']=Path('/tmp/oriole-custom-coalescing-composition-review.json').read_bytes()
for name in ['probe.py','full-events-source.py','external-source.py']:entries['probe-support/'+name]=Path('/tmp/oriole-custom-alias-'+name).read_bytes()
freeze=json.loads((source/'sources.json').read_text())
for name,digest in freeze.items():
 data=(repo/name).read_bytes();assert sha(data)==digest,name;entries['frozen-source/'+name]=data
for name in ['tests/c/integration.c','tests/c/adversarial.c','tests/c/allocations.c','tools/differential.py','tools/upstream-expat/run.py']:entries['runners/'+name]=(repo/name).read_bytes()
review=json.loads(entries['review.json']);assert all(freeze[k]==v for k,v in review['reviewed_files'].items())
files=[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())]
(out/'files.json').write_text(json.dumps(files,indent=2)+'\n')
with (out/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
screen=json.loads((source/'screen/screening.json').read_text());assert screen['status']=='passed';screen_rows=[]
for chunk in [4096,65536]:
 for name in dict.fromkeys(r['workload'] for r in screen['rows']):
  rates=[r['speedup'] for r in screen['rows'] if r['workload']==name and r['chunk']==chunk];screen_rows.append({'chunk':chunk,'workload':name,'median_candidate_speedup':statistics.median(rates),'minimum':min(rates),'maximum':max(rates)})
native=json.loads((source/'native/report.json').read_text());assert native['status']=='passed'
checks=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(source/'tests.log').read_text())));assert checks==267
api=json.loads((source/'api-comparison.json').read_text());assert len(api['changes'])==48 and all(r['before']['outcome']=='fail' and r['after']['outcome']=='pass' for r in api['changes'])
differential=json.loads((source/'differential/summary.json').read_text());assert differential['exact_pass'] and differential['cases']==3918
report={'source_commit':'d89f8396bc5ceb325a8d61b39539293e0c77ffbe','base_commit':'ed7748a','shared_sha256':sha((source/'liboriole_expat.so').read_bytes()),'static_sha256':sha((source/'liboriole_expat.a').read_bytes()),'checks':{'rust_tests':checks,'strict_clippy':'passed','rustfmt':'passed','native_suites':6,'native_allocation_scenarios_per_linkage':333,'native_scope':native['scope'],'ordinary_differential_cases':3918,'ordinary_differential_exact':'passed'},'upstream':api,'converter_grids':json.loads((source/'probes/summary.json').read_text()),'additional_converter_grids':{'public_map_cases':7154,'name_identity_cases':64,'acceptance_differences':0,'successful_callback_differences':0},'screening_scope':screen['scope'],'screening':screen_rows,'independent_review':review,'known_limits':['693 configurations still fail in the unmodified full API assertion matrix. This layer fixes four custom-encoding tests across all 12 chunk/deferral contexts, with no other outcome or disposition changes.','The exact ed7748a baseline remains 3999/741, including the four token-ownership allocation-schedule failures previously classified in custom-encoding-profiled. The assertions and outcomes are retained.','Custom external-DTD default callback prefixes and malformed-input callback/error/position differences remain. Semantic grids combine adjacent text/default fragments; only the separate ordinary differential claims exact callbacks.','The six-project screen measures native callback-driver throughput on pinned project XML, not project process timing. Provenance retains a measured cost versus the immediately preceding Oriole base.','Stored entity replacement CRLF attribute normalization and NDATA attribute error classification are separate preexisting gaps and are not fixed by this layer.'],'integration_notes':['Root metadata-only layer 1b6d5c3 has identical Rust runtime to ed7748a; cherry-pick this provenance layer and final evidence onto it.','Keep NameRules on raw lexical predicates, including custom_public_byte and new raw QName validation. Do not restore removed semantic-name validation in expand_name.','Character-data coalescing scans lexical representatives; character_data(&str) restores aliases while Source metadata remains live.','Buffer.swap_decoded exchanges ordinary token owners but decodes aliases fallibly before publication; all lexical projections finish first.','Iterative attribute expansion must preserve raw_ascii distinctions, the existing default literal prepass, and physical-versus-replacement CRLF behavior.'],'artifacts':{'files':len(files),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes())}}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(len(files),'files;',len((out/'evidence.tar.gz').read_bytes()),'archive bytes')
