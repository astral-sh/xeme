from pathlib import Path
import json,gzip,hashlib
source=Path('/tmp/oriole-custom-alias-probe.py').read_text().split("if __name__=='__main__':")[0]
source=source.replace('return c.string_at(pointer,2)[1]','return 0xe9').replace('output.contents.map[128]=-2','output.contents.map[128]=-2;output.contents.map[129]=-3;output.contents.map[130]=0xe9;output.contents.map[131]=0xe9')
libs={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','candidate':'/tmp/oriole-custom-final/liboriole_expat.so'}
parsers={}
for name,path in libs.items():
 env={};exec(compile(source.replace(libs['reference'],path),name,'exec'),env);parsers[name]=env['parse']
rows=[]
for start in [b'\x80A',b'\x81AB',b'\x82',b'\x83']:
 for end in [b'\x80A',b'\x81AB',b'\x82',b'\x83']:
  for kind,data in [('element',b'<'+start+b'></'+end+b'>'),('attributes',b'<r '+start+b"='x' "+end+b"='y'/>")]:
   for chunk in [0,1]:
    rows.append({'kind':kind,'input':data.hex(),'chunk':chunk,**{name:parse(data,chunk) for name,parse in parsers.items()}})
report={'libraries':{name:{'path':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()} for name,path in libs.items()},'cases':len(rows),'acceptance_differences':sum(r['candidate']['status']!=r['reference']['status'] for r in rows),'error_differences':sum(r['candidate']['error']!=r['reference']['error'] for r in rows),'successful_callback_differences':sum(r['candidate']['status']==r['reference']['status']==1 and r['candidate']['events']!=r['reference']['events'] for r in rows),'rows':rows}
Path('/tmp/oriole-custom-final/probes/name-identity.json.gz').write_bytes(gzip.compress((json.dumps(report,indent=2)+'\n').encode(),mtime=0))
print({k:v for k,v in report.items() if k!='rows'})
assert not any(report[k] for k in ['acceptance_differences','error_differences','successful_callback_differences'])
