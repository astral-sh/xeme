from pathlib import Path
import gzip,hashlib,io,json,re,statistics,tarfile
source=Path('/tmp/oriole-custom-integrated');repo=Path('/home/dev-user/code/oss/oriole-api-followup');out=repo/'docs/validation/2026-09-10/custom-encoding-integrated';out.mkdir(parents=True,exist_ok=True)
entries={};sha=lambda b:hashlib.sha256(b).hexdigest()
for p in sorted(source.rglob('*')):
 if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log','.py','.patch','.gz','.c','.h']:
  entries[str(p.relative_to(source))]=p.read_bytes()
entries['independent-review.json']=Path('/tmp/oriole-custom-composition-independent-review.json').read_bytes()
freeze=json.loads((source/'sources.json').read_text())
for path,digest in freeze.items():
 data=(repo/path).read_bytes()
 if sha(data)==digest:entries['frozen-source/'+path]=data
 else:assert '/tests/' in path or path.endswith('/tests.rs'),path
for path in ['tools/differential.py','tools/upstream-expat/run.py','tests/c/integration.c','tests/c/adversarial.c','tests/c/allocations.c']:entries['runners/'+path]=(repo/path).read_bytes()
files=[{'path':name,'sha256':sha(data),'bytes':len(data)} for name,data in sorted(entries.items())]
(out/'files.json').write_text(json.dumps(files,indent=2)+'\n')
with (out/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
screen=json.loads((source/'screen/screening.json').read_text());screen_rows=[]
for chunk in [4096,65536]:
 for name in dict.fromkeys(r['workload'] for r in screen['rows']):
  rates=[r['speedup'] for r in screen['rows'] if r['workload']==name and r['chunk']==chunk];screen_rows.append({'chunk':chunk,'workload':name,'median_candidate_speedup':statistics.median(rates)})
report={'base_commit':'dc552f460cbdf4fdc8efcda87ce3f39fbf3a9e74','original_provenance_commit':'ad80aa0','shared_sha256':sha((source/'liboriole_expat.so').read_bytes()),'static_sha256':sha((source/'liboriole_expat.a').read_bytes()),'checks':{'rust_tests':262,'test_scope':'261 affected-package tests plus one added regression; final multibyte suite 12/12','clippy':'passed','native_suites':6,'native_allocation_scenarios_per_linkage':341,'ordinary_differential_cases':3918,'ordinary_differential_exact':'passed'},'api_comparison':json.loads((source/'api-comparison.json').read_text()),'converter_grids':json.loads((source/'probes/summary.json').read_text()),'additional_converter_grids':{'public_map_cases':7154,'name_identity_cases':64,'acceptance_differences':0,'successful_callback_differences':0},'performance_screen':screen_rows,'independent_review':'Bounded source review of composition only; no findings and no independent execution claimed.','artifacts':{'files':len(files),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes())}}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(len(files),'files;',len((out/'evidence.tar.gz').read_bytes()),'archive bytes')
