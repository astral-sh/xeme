from pathlib import Path
import subprocess, gzip, json, hashlib
root=Path('/tmp/oriole-custom-integrated/probes')
rows=[]
for name,output in [('compare','initial-comparison'),('expanded-compare','expanded-comparison'),('full-events','full-events-comparison'),('external-compare','external-comparison'),('external-semantic-compare','external-semantic-comparison')]:
 source=Path('/tmp/oriole-custom-alias-'+name+'.py').read_text().replace('/home/dev-user/.cache/oriole/api-followup-target/release/liboriole_expat.so','/tmp/oriole-custom-integrated/liboriole_expat.so').replace('/tmp/oriole-custom-alias-runtime/liboriole_expat.so','/tmp/oriole-custom-integrated/liboriole_expat.so')
 run=root/(name+'.py');run.write_text(source)
 result=subprocess.run(['taskset','-c','3','python3',str(run)],capture_output=True,text=True,timeout=300)
 (root/(name+'.log')).write_text(result.stdout+result.stderr)
 assert result.returncode==0, result.stderr
 p=Path('/tmp/oriole-custom-alias-'+output+'.json'); data=p.read_bytes();report=json.loads(data)
 target=root/(output+'.json.gz');target.write_bytes(gzip.compress(data,mtime=0));p.unlink()
 rows.append({'name':name,'cases':report['cases'],'library_sha256':report['sha256'],'all_differences':len(report['differences']),'acceptance_differences':sum(r['reference']['status']!=r['candidate']['status'] for r in report['differences']),'successful_callback_differences':sum(r['reference']['status']==r['candidate']['status']==1 and r['reference']['events']!=r['candidate']['events'] for r in report['differences']),'report':str(target),'report_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(run.read_bytes()).hexdigest()})
 print(rows[-1],flush=True)
 (root/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
