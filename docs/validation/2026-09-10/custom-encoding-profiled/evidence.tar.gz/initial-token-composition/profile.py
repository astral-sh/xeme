from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/tmp/oriole-custom-token');tool=Path('/home/dev-user/.cache/oriole/profilers/local/usr/bin')
libs={'baseline':'/tmp/oriole-token-integrated/liboriole_expat.so','candidate':str(root/'liboriole_expat.so')};rows=[]
for label,lib in libs.items():
 output=root/(label+'.callgrind');command=['taskset','-c','3',str(tool/'valgrind'),'--tool=callgrind','--callgrind-out-file='+str(output),'/tmp/oriole-grammar-bench-plain/native-driver',lib,'/home/dev-user/code/oss/oriole/benchmarks/projects/corpus/wayland/wayland.xml','4096','1']
 result=subprocess.run(command,capture_output=True,text=True,timeout=120,env={**os.environ,'VALGRIND_LIB':'/home/dev-user/.cache/oriole/profilers/local/usr/libexec/valgrind'});assert result.returncode==0,result.stderr
 (root/(label+'.profile.log')).write_text(result.stdout+result.stderr)
 annotated=subprocess.run([str(tool/'callgrind_annotate'),'--auto=no',str(output)],capture_output=True,text=True,check=True);(root/(label+'.annotated')).write_text(annotated.stdout)
 rows.append({'label':label,'command':command,'sha256':hashlib.sha256(Path(lib).read_bytes()).hexdigest(),'stdout':result.stdout,'stderr':result.stderr})
 print(label,result.stderr,flush=True)
(root/'profile.json').write_text(json.dumps(rows,indent=2)+'\n')
