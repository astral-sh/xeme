from pathlib import Path
import gzip,hashlib,io,json,statistics,tarfile
source=Path('/tmp/oriole-custom-fast-text');repo=Path('/home/dev-user/code/oss/oriole-api-followup');out=repo/'docs/validation/2026-09-10/custom-encoding-profiled';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();entries={}
def add_tree(prefix,root):
 for p in sorted(Path(root).rglob('*')):
  if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log','.py','.patch','.gz','.c','.h','.callgrind','.annotated']:
   entries[prefix+str(p.relative_to(root))]=p.read_bytes()
add_tree('',source)
add_tree('token-baseline/upstream/',Path('/tmp/oriole-custom-token/upstream-baseline'))
for name in ['upstream-token-delta.json','allocation-classification.json','sources.json','source.patch','profile.json','profile.py','baseline.annotated','candidate.annotated','baseline.callgrind','candidate.callgrind']:
 entries['initial-token-composition/'+name]=(Path('/tmp/oriole-custom-token')/name).read_bytes()
for name in ['sources.json','source.patch','profile.json','candidate.annotated','candidate.callgrind']:
 entries['first-fast-path/'+name]=(Path('/tmp/oriole-custom-fast')/name).read_bytes()
for name in ['sources.json','source.patch','profile.json','candidate.annotated','candidate.callgrind','rejected.json']:
 entries['rejected-attribute-helper/'+name]=(Path('/tmp/oriole-custom-fast-attributes')/name).read_bytes()
for name in ['profile.json','candidate.annotated','candidate.callgrind']:
 entries['rejected-attribute-helper/gtk/'+name]=(Path('/tmp/oriole-custom-fast-attributes/gtk-profile')/name).read_bytes()
entries['review.json']=Path('/tmp/oriole-custom-plain-path-independent-review.json').read_bytes()
for name in ['probe.py','full-events-source.py','external-source.py']:entries['probe-support/'+name]=Path('/tmp/oriole-custom-alias-'+name).read_bytes()
freeze=json.loads((source/'sources.json').read_text())
for name,digest in freeze.items():
 data=(repo/name).read_bytes();assert sha(data)==digest,name;entries['frozen-source/'+name]=data
for name in ['tests/c/integration.c','tests/c/adversarial.c','tests/c/allocations.c','tools/differential.py','tools/upstream-expat/run.py']:entries['runners/'+name]=(repo/name).read_bytes()
files=[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())]
(out/'files.json').write_text(json.dumps(files,indent=2)+'\n')
with (out/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
screen=json.loads((source/'screen/screening.json').read_text());screen_rows=[]
for chunk in [4096,65536]:
 for name in dict.fromkeys(r['workload'] for r in screen['rows']):
  rates=[r['speedup'] for r in screen['rows'] if r['workload']==name and r['chunk']==chunk];screen_rows.append({'chunk':chunk,'workload':name,'median_candidate_speedup':statistics.median(rates),'minimum':min(rates),'maximum':max(rates)})
report={'base_commit':'703a01a','shared_sha256':sha((source/'liboriole_expat.so').read_bytes()),'static_sha256':sha((source/'liboriole_expat.a').read_bytes()),'checks':{'rust_tests':263,'strict_clippy':'passed','native_suites':6,'native_allocation_scenarios_per_linkage':333,'native_scope':'C ASan/UBSan, uninstrumented release Rust, leak sanitizer disabled','ordinary_differential_cases':3918,'ordinary_differential_exact':'passed'},'upstream':json.loads((source/'api-comparison.json').read_text()),'upstream_baseline_token_delta':json.loads(Path('/tmp/oriole-custom-token/upstream-token-delta.json').read_text()),'upstream_baseline_classification':json.loads(Path('/tmp/oriole-custom-token/allocation-classification.json').read_text()),'converter_grids':json.loads((source/'probes/summary.json').read_text()),'additional_converter_grids':{'public_map_cases':7154,'name_identity_cases':64,'acceptance_differences':0,'successful_callback_differences':0},'instruction_counts':{'wayland':{'token_baseline':60594801,'initial_composition':66396916,'first_fast_paths':62807859,'final':62098050},'gtk':{'token_baseline':13571985,'final':14082618}},'screening_scope':screen['scope'],'screening':screen_rows,'rejected_experiment':json.loads(Path('/tmp/oriole-custom-fast-attributes/rejected.json').read_text()),'independent_review':'Bounded source review, no findings and no independent execution claimed.','integration_notes':['character_data accepts source &str again and checks Source.has_conversions internally. Coalescing may call character_data(text) unchanged.','Keep converted_text_limit and lexical scanner text for CR/LF decisions. Alias CR/LF remain distinct from physical line endings.','Selected historical NameRules must reach custom_public_byte and new raw QName predicates; do not restore semantic-name validation removed from expand_name.','Buffer.swap_decoded publishes aliased raw callbacks only after fallible decoding succeeds; plain text exchanges owners after all lexical projections finish.'],'artifacts':{'files':len(files),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes())}}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(len(files),'files;',len((out/'evidence.tar.gz').read_bytes()),'archive bytes')
