from pathlib import Path
import json,hashlib,gzip
from collections import Counter
source=Path('/tmp/oriole-custom-alias-full-events-source.py').read_text()
reference='/home/dev-user/.cache/oriole/expat-build/libexpat.so';candidate='/tmp/oriole-custom-fast-text/liboriole_expat.so'
rows=[];count=0
for mapped in [0x00e9,0x00b7,0xe000,36,64,94,126]:
 for byte in range(256):
  for multi in [False,True]:
   if multi and byte==36:continue
   code=source.replace('output.contents.map[128]=-2', f'output.contents.map[128]=-2\n    output.contents.map[{byte}]={mapped}'+('\n    output.contents.map[36]=-2' if multi else ''))
   old={};exec(compile(code,'reference','exec'),old)
   new={};exec(compile(code.replace(reference,candidate),'candidate','exec'),new)
   data=b'<!DOCTYPE r PUBLIC "'+(bytes([36,byte]) if multi else bytes([byte]))+b'" "s"><r/>'
   for chunk in [0,1]:
    count+=1;a=old['parse'](data,chunk,False);b=new['parse'](data,chunk,False)
    if a!=b:rows.append({'map_byte':byte,'mapped':mapped,'multibyte':multi,'hex':data.hex(),'chunk':chunk,'reference':a,'candidate':b})
report={'library':candidate,'sha256':hashlib.sha256(Path(candidate).read_bytes()).hexdigest(),'cases':count,'differences':rows}
Path('/tmp/oriole-custom-fast-text/probes/public-map.json.gz').write_bytes(gzip.compress(json.dumps(report,indent=2).encode()+b'\n',mtime=0))
print('cases',count,'acceptance differences',sum(x['reference']['status']!=x['candidate']['status'] for x in rows),'successful callback differences',sum(x['reference']['status']==x['candidate']['status']==1 and x['reference']['events']!=x['candidate']['events'] for x in rows),'all differences',len(rows))
for row in [row for row in rows if row['reference']['status']!=row['candidate']['status']][:20]:print(row)
