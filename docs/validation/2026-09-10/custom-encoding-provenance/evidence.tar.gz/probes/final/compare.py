from pathlib import Path
import json, hashlib
source=Path('/tmp/oriole-custom-alias-probe.py').read_text().split("if __name__=='__main__':")[0]
old={};exec(compile(source,'reference','exec'),old)
path='/tmp/oriole-custom-alias-reviewed/liboriole_expat.so'
new={};exec(compile(source.replace(old['LIBRARY'],path),'candidate','exec'),new)
rows=[]
for case,template in old['CASES'].items():
 for scalar in list(range(9,14))+list(range(32,127)):
  data=template.replace(b'@@',bytes([128,scalar]))
  for chunk in [0,1,7]:
   a=old['parse'](data,chunk,True);b=new['parse'](data,chunk,True)
   if a!=b: rows.append({'case':case,'scalar':scalar,'chunk':chunk,'reference':a,'candidate':b})
report={'library':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'cases':9300,'differences':rows}
Path('/tmp/oriole-custom-alias-initial-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
from collections import Counter
print('acceptance',Counter(x['case'] for x in rows if x['reference']['status']!=x['candidate']['status']))
print('callbacks',Counter(x['case'] for x in rows if x['reference']['status']==x['candidate']['status'] and x['reference']['events']!=x['candidate']['events']))
print('errors',Counter(x['case'] for x in rows if x['reference']['error']!=x['candidate']['error']))
print('all',len(rows))
