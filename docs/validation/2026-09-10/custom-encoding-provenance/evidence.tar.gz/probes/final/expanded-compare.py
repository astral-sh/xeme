from pathlib import Path
import json, hashlib
from collections import Counter
source=Path('/tmp/oriole-custom-alias-probe.py').read_text().split("if __name__=='__main__':")[0]
source=source.replace("('XML_ParserCreate',[c.c_char_p],c.c_void_p),", "('XML_ParserCreate',[c.c_char_p],c.c_void_p), ('XML_ParserCreateNS',[c.c_char_p,c.c_char],c.c_void_p),")
reference='/home/dev-user/.cache/oriole/expat-build/libexpat.so';path='/tmp/oriole-custom-alias-reviewed/liboriole_expat.so'
extra={
 'typed-attribute':b'<!DOCTYPE r [<!ATTLIST r a NMTOKENS #IMPLIED>]><r a="A@@ B"/>',
 'typed-default':b'<!DOCTYPE r [<!ATTLIST r a NMTOKENS "A@@ B">]><r/>',
 'attribute-leading-colon':b'<r @@a="v"/>',
 'attribute-middle-colon':b'<r a@@b="v" xmlns:a="u"/>',
 'attribute-trailing-colon':b'<r a@@="v" xmlns:a="u"/>',
 'namespace-declaration':b'<r @@mlns="u"/>',
 'namespace-declaration-colon':b'<a:r xmlns@@a="u"/>',
 'namespace-element-leading':b'<@@r/>',
 'namespace-element-middle':b'<a@@r xmlns:a="u"/>',
 'namespace-element-trailing':b'<a@@ xmlns:a="u"/>',
 'namespace-element-two-colons':b'<a@@b:c xmlns:a="u"/>',
 'namespace-element-two-aliases':b'<a@@b@@c xmlns:a="u"/>',
 'namespace-entity-leading':b'<!DOCTYPE r [<!ENTITY @@e "v">]><r>&@@e;</r>',
 'namespace-entity-middle':b'<!DOCTYPE r [<!ENTITY a@@b "v">]><r>&a@@b;</r>',
 'namespace-entity-attribute':b'<!DOCTYPE r [<!ENTITY a@@b "v">]><r a="&a@@b;"/>',
}
rows=[];count=0
for ns in [False,True]:
 for lead in [128,36,64]:
  code=source.replace('map[128]=-2',f'map[{lead}]=-2')
  if ns:code=code.replace("p=lib.XML_ParserCreate(b'alias');assert p", "p=lib.XML_ParserCreateNS(b'alias',b'|');assert p")
  old={};exec(compile(code,'reference','exec'),old)
  new={};exec(compile(code.replace(reference,path),'candidate','exec'),new)
  cases=old['CASES']|extra
  for case,template in cases.items():
   for scalar in [9,10,13,*range(32,127)]:
    data=template.replace(b'@@',bytes([lead,scalar]))
    for chunk in [0,1]:
     count+=1;a=old['parse'](data,chunk,False);b=new['parse'](data,chunk,False)
     if a!=b:rows.append({'case':case,'scalar':scalar,'chunk':chunk,'lead':lead,'namespaces':ns,'reference':a,'candidate':b})
report={'library':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'cases':count,'differences':rows}
Path('/tmp/oriole-custom-alias-expanded-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print('cases',count)
print('acceptance',Counter((x['case'],x['scalar'],x['namespaces']) for x in rows if x['reference']['status']!=x['candidate']['status']))
print('accepted callbacks',Counter((x['case'],x['scalar']) for x in rows if x['reference']['status']==x['candidate']['status']==1 and x['reference']['events']!=x['candidate']['events']))
print('all',len(rows))
