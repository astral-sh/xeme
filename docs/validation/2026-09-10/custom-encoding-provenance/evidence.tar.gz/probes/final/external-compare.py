from pathlib import Path
import json,hashlib
from collections import Counter
source=Path('/tmp/oriole-custom-alias-full-events-source.py').read_text()
types='''
EXTERNAL=c.CFUNCTYPE(c.c_int,c.c_void_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p)
lib.XML_SetExternalEntityRefHandler.argtypes=[c.c_void_p,EXTERNAL]
lib.XML_ExternalEntityParserCreate.argtypes=[c.c_void_p,c.c_char_p,c.c_char_p]
lib.XML_ExternalEntityParserCreate.restype=c.c_void_p
lib.XML_SetParamEntityParsing.argtypes=[c.c_void_p,c.c_int]
'''
source=source.replace('def parse(data, chunk=0, default=False):',types+'\ndef parse(data, chunk=0, default=False, resources=None):')
callback='''
    @EXTERNAL
    def external(parent,context,base,system,public):
        name=decoded(system)
        events.append(['external',name])
        if name not in resources:return 0
        child=lib.XML_ExternalEntityParserCreate(parent,context,b'alias')
        if not child:return 0
        document=resources[name];width=chunk or max(1,len(document));status=1
        if not document:status=lib.XML_Parse(child,b'',0,1)
        for offset in range(0,len(document),width):
            piece=document[offset:offset+width]
            status=lib.XML_Parse(child,piece,len(piece),int(offset+width>=len(document)))
            if status!=1:break
        if status!=1:events.append(['child-error',name,lib.XML_GetErrorCode(child)])
        lib.XML_ParserFree(child)
        return int(status==1)
'''
source=source.replace("    p=lib.XML_ParserCreate(b'alias');assert p",callback+"\n    p=lib.XML_ParserCreate(b'alias');assert p")
source=source.replace('    lib.XML_SetElementHandler(p,start,end)', '    lib.XML_SetExternalEntityRefHandler(p,external)\n    lib.XML_SetParamEntityParsing(p,2)\n    lib.XML_SetElementHandler(p,start,end)')
Path('/tmp/oriole-custom-alias-external-source.py').write_text(source)
reference='/home/dev-user/.cache/oriole/expat-build/libexpat.so';candidate='/tmp/oriole-custom-alias-reviewed/liboriole_expat.so'
root=b'<!DOCTYPE r SYSTEM "dtd"><r>&e;</r>'
cases={
 'entity-physical-value':(root,{'dtd':b'<!ENTITY e "A@@B">'}),
 'entity-physical-name':(b'<!DOCTYPE r SYSTEM "dtd"><r>&a@@b;</r>',{'dtd':b'<!ENTITY a@@b "value">'}),
 'parameter-physical-name':(root,{'dtd':b'<!ENTITY % a@@b "<!ENTITY e \'v\'>">%a@@b;'}),
 'header-keyword':(root,{'dtd':b'<!ENTITY % key SYSTEM "key"><![%key;[<!ENTITY e "v">]]>','key':b'@@NCLUDE'}),
 'header-child-declaration':(root,{'dtd':b'<!ENTITY % setup SYSTEM "setup"><![%setup;INCLUDE[<!ENTITY e "v">]]>','setup':b'<!ENTITY a@@b "value">'}),
 'composed-entity-name':(b'<!DOCTYPE r SYSTEM "dtd"><r>&a@@b;</r>',{'dtd':b'<!ENTITY % gap SYSTEM "gap"><!ENTITY a@@b %gap; "v">','gap':b''}),
 'composed-value':(root,{'dtd':b'<!ENTITY % gap SYSTEM "gap"><!ENTITY e %gap; "A@@B">','gap':b''}),
 'composed-attlist':(b'<!DOCTYPE r SYSTEM "dtd"><r/>',{'dtd':b'<!ENTITY % gap SYSTEM "gap"><!ATTLIST r a@@b CDATA %gap; "A@@B">','gap':b''}),
 'composed-enumeration':(b'<!DOCTYPE r SYSTEM "dtd"><r/>',{'dtd':b'<!ENTITY % gap SYSTEM "gap"><!ATTLIST r a (a@@b %gap; |c) "a@@b">','gap':b''}),
 'composed-notation':(b'<!DOCTYPE r SYSTEM "dtd"><r/>',{'dtd':b'<!ENTITY % gap SYSTEM "gap"><!NOTATION a@@b PUBLIC "pub" %gap; "A@@B">','gap':b''}),
 'external-value':(root,{'dtd':b'<!ENTITY % p SYSTEM "p"><!ENTITY e "A@@%p;Z@@">','p':b'P@@'}),
 'nested-external-value':(root,{'dtd':b'<!ENTITY % p SYSTEM "p"><!ENTITY % q SYSTEM "q"><!ENTITY e "A@@%p;Z@@">','p':b'P@@%q;T@@','q':b'Q@@'}),
 'external-content':(b'<!DOCTYPE r [<!ENTITY e SYSTEM "e">]><r>&e;</r>',{'e':b'<a@@b value="@@">@@</a@@b>'}),
}
rows=[];count=0
for lead in [128,36]:
 code=source.replace('map[128]=-2',f'map[{lead}]=-2')
 old={};exec(compile(code,'reference','exec'),old)
 new={};exec(compile(code.replace(reference,candidate),'candidate','exec'),new)
 for case,(document,resources) in cases.items():
  for scalar in [9,10,13,*range(32,127)]:
   data=document.replace(b'@@',bytes([lead,scalar]))
   loaded={name:value.replace(b'@@',bytes([lead,scalar])) for name,value in resources.items()}
   for chunk in [0,1,7]:
    count+=1;a=old['parse'](data,chunk,True,loaded);b=new['parse'](data,chunk,True,loaded)
    if a!=b:rows.append({'case':case,'scalar':scalar,'lead':lead,'chunk':chunk,'reference':a,'candidate':b})
report={'library':candidate,'sha256':hashlib.sha256(Path(candidate).read_bytes()).hexdigest(),'cases':count,'templates':{key:{'document':document.hex(),'resources':{name:value.hex() for name,value in resources.items()}} for key,(document,resources) in cases.items()},'differences':rows}
Path('/tmp/oriole-custom-alias-external-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print('cases',count)
print('acceptance',Counter((x['case'],x['scalar']) for x in rows if x['reference']['status']!=x['candidate']['status']))
print('accepted callbacks',Counter(x['case'] for x in rows if x['reference']['status']==x['candidate']['status']==1 and x['reference']['events']!=x['candidate']['events']))
print('all',len(rows))
