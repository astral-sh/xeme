from pathlib import Path
import json,gzip,hashlib
root=Path('/tmp/oriole-custom-alias-final-probes')
code=Path('/tmp/oriole-custom-alias-external-compare.py').read_text().split('rows=[];count=0')[0]
ns={};exec(compile(code,'external-source','exec'),ns)
reference=ns['reference']; libs={'reference':reference,'baseline':'/tmp/oriole-ordinary-payload-runtime/liboriole_expat.so','candidate':'/tmp/oriole-custom-alias-reviewed/liboriole_expat.so'}
parsers={}
for name,path in libs.items():
 env={};exec(compile(ns['source'].replace(reference,path),name,'exec'),env);parsers[name]=env['parse']
rows=[]
for case,(template,resources) in ns['cases'].items():
 for replacement in [b'A',b' ',b'<']:
  data=template.replace(b'@@',replacement);loaded={name:value.replace(b'@@',replacement) for name,value in resources.items()}
  for chunk in [0,1,7]:
   traces={name:parse(data,chunk,True,loaded) for name,parse in parsers.items()}
   rows.append({'case':case,'replacement':replacement.hex(),'chunk':chunk,'document':data.hex(),'resources':{name:value.hex() for name,value in loaded.items()},'traces':traces})
report={'libraries':{name:{'path':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()} for name,path in libs.items()},'cases':len(rows),'candidate_baseline_differences':sum(r['traces']['candidate']!=r['traces']['baseline'] for r in rows),'successful_default_differences':sum(r['traces']['candidate']['status']==r['traces']['reference']['status']==1 and r['traces']['candidate']['events']!=r['traces']['reference']['events'] for r in rows),'rows':rows}
(root/'external-default-baseline.json.gz').write_bytes(gzip.compress((json.dumps(report,indent=2)+'\n').encode(),mtime=0))
print({k:v for k,v in report.items() if k!='rows'})
assert report['candidate_baseline_differences']==0
