from pathlib import Path
import gzip
import hashlib
import json

scope={}
exec(Path('/tmp/oriole-default-declarations/compare.py').read_text().split('rows=[]')[0],scope)
BASE=scope['BASE'].replace("'data':data.decode()", "'data':data.hex()")
LIBRARIES=scope['LIBRARIES']
bodies=[
 '<!ENTITY e %missing;"X">',
 '<!ATTLIST r a CDATA "X" %missing; b CDATA "Y">',
 '<!ENTITY 名 "先"><!ENTITY 名 "後">',
 '<!ENTITY SYSTEM "X"><!ENTITY SYSTEM PUBLIC "pub" "sys">',
]
differences=[]
count=0
with gzip.open('/tmp/oriole-default-declarations/chunk-cases.json.gz','wt') as output:
    output.write('[')
    for entity in (False,True):
        for attlist in (False,True):
            scopes=[]
            for library in LIBRARIES:
                source=BASE.replace(LIBRARIES[0],library)
                if not entity:source=source.replace('l.XML_SetEntityDeclHandler(parent, callbacks[3])','pass')
                if not attlist:source=source.replace('l.XML_SetAttlistDeclHandler(parent, callbacks[4])','pass')
                ns={};exec(source,ns);scopes.append(ns)
            for body in bodies:
                for encoding,bom in [('utf-8',b''),('utf-16le',b'\xff\xfe'),('utf-16be',b'\xfe\xff')]:
                    data=bom+body.encode(encoding)
                    for standalone in (None,'yes'):
                        for mode in (0,2):
                            for chunk in range(1,len(data)+1):
                                a,b=[scope['norm'](s['probe'](standalone,mode,data,b'',chunk=chunk))for s in scopes]
                                row={'body':body,'encoding':encoding,'standalone':standalone,'mode':mode,'chunk':chunk,'entity':entity,'attlist':attlist,'reference':a,'candidate':b}
                                if a!=b:differences.append(row)
                                if count:output.write(',')
                                output.write(json.dumps(row,separators=(',',':')))
                                count+=1
    output.write(']\n')
report={'cases':count,'differences':len(differences),'mismatches':differences,'library_sha256':hashlib.sha256(Path(LIBRARIES[1]).read_bytes()).hexdigest()}
Path('/tmp/oriole-default-declarations/chunks.json').write_text(json.dumps(report,indent=2)+'\n')
print('cases',count,'differences',len(differences))
for row in differences[:5]:print(json.dumps(row))
