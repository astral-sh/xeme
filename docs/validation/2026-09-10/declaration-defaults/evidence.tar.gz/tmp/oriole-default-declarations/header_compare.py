from pathlib import Path
import json,hashlib
base=Path('/tmp/oriole-external-pe-review/probe.py').read_text().split("if __name__ == '__main__':")[0]
scopes=[]
for library in ['/home/dev-user/.cache/oriole/expat-build/libexpat.so','/home/dev-user/.cache/oriole/default-declarations-target/debug/liboriole_expat.so']:
 scope={'__name__':'imported'};exec(base.replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so',library),scope);scopes.append(scope)
def norm(r):
 events=[]
 for e in r['events']:
  if e[:2]==['parent','not-standalone']:continue
  e=e[:2]+e[3:]
  if e[1]=='default' and events and events[-1][:2]==e[:2]:events[-1][2]+=e[2]
  else:events.append(e)
 return {'status':r['status'],'error':r['error'],'children':[(x['name'],x['status'],x['error']) for x in r['children']],'events':events}
headers=['INCLUDE%missing;%p;','%missing;%p;INCLUDE','INCLUDE%p;%missing;','%empty;%p;%k;','%p; %k;','INCLUDE%p;%p;','%k;%p;','%p;%k;%missing;']
rows=[]
for header in headers:
 for external in [b'',b"<!ENTITY imported 'yes'>"]:
  for action in ['parse','skip']:
   for mode in [0,1,2]:
    for standalone in [None,'yes']:
     for chunk in [0,1,3]:
      data=b"<!ENTITY % p SYSTEM 'p'><!ENTITY % k 'INCLUDE'><!ENTITY % empty ''><!["+header.encode()+b"[<!ENTITY e 'E'>]]><!ENTITY after 'A'>"
      a,b=[norm(scope['probe'](standalone,mode,data,external,action,chunk)) for scope in scopes]
      rows.append({'header':header,'external':external.decode(),'action':action,'mode':mode,'standalone':standalone,'chunk':chunk,'match':a==b,'reference':a,'candidate':b})
result={'cases':len(rows),'differences':sum(not r['match'] for r in rows),'rows':rows}
Path('/tmp/oriole-default-declarations/header-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['cases'],result['differences'])
for r in rows:
 if not r['match'] and r['chunk']==0:print(json.dumps(r))
