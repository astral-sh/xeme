from pathlib import Path
import json,hashlib
scope={};exec(Path('/tmp/oriole-default-declarations/compare.py').read_text().split('rows=[]')[0],scope)
source=scope['BASE'].replace('START = c.CFUNCTYPE', 'UNPARSED=c.CFUNCTYPE(None,P,S,S,S,S,S)\nSTART = c.CFUNCTYPE')
source=source.replace("('XML_ParserCreate', P, [S]),", "('XML_SetUnparsedEntityDeclHandler', None, [P,UNPARSED]),\n    ('XML_ParserCreate', P, [S]),")
source=source.replace('l.XML_SetParamEntityParsing(parent, 2)', "unparsed=UNPARSED(lambda _,name,base,system,public,notation:event('unparsed',decode(name),decode(system),decode(public),decode(notation)))\n    l.XML_SetUnparsedEntityDeclHandler(parent,unparsed)\n    l.XML_SetParamEntityParsing(parent, 2)")
rows=[]
for handler in (False,True):
 ss=[]
 for lib in scope['LIBRARIES']:
  text=source.replace(scope['LIBRARIES'][0],lib)
  if not handler:text=text.replace('l.XML_SetEntityDeclHandler(parent, callbacks[3])','pass')
  s={};exec(text,s);ss.append(s)
 for original in ('<!ENTITY e "FIRST">','<!ENTITY e SYSTEM "first" NDATA n>'):
  for name in ('n','NDATA','PUBLIC','SYSTEM'):
   for kind in ('SYSTEM "sys"','PUBLIC "pub" "sys"'):
    body=original+f'<!ENTITY e {kind} NDATA {name}>'
    for chunk in (0,1,3):
     a,b=[scope['norm'](s['probe'](None,2,body.encode(),b'',chunk=chunk)) for s in ss]
     rows.append({'handler':handler,'body':body,'chunk':chunk,'reference':a,'candidate':b,'match':a==b})
report={'cases':len(rows),'differences':sum(not r['match'] for r in rows),'rows':rows}
Path('/tmp/oriole-default-declarations/unparsed-probe.json').write_text(json.dumps(report,separators=(',',':'))+'\n')
print(report['cases'],report['differences'])
for r in rows:
 if not r['match'] and r['chunk']==0:print(json.dumps(r))
