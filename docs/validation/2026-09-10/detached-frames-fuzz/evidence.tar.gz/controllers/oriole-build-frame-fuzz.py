import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path('/home/dev-user/code/oss/oriole-frame-fuzz')
out = Path('/tmp/oriole-frame-fuzz-study')
out.mkdir(exist_ok=False)
targets = ['parse', 'streaming', 'ffi', 'ffi_family', 'multibyte', 'value_family']
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == '5bc806e5fc2a545f22c75f2a1bcbef45cfa3632b'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
names = subprocess.check_output(['git', 'ls-files', '-z', 'crates', 'include', 'tests/c', 'fuzz', 'Cargo.toml', 'Cargo.lock'], cwd=root).decode().rstrip('\0').split('\0')
source = {name: digest(root / name) for name in names}
(out / 'source.json').write_text(json.dumps({'commit': '5bc806e5fc2a545f22c75f2a1bcbef45cfa3632b', 'worktree': str(root), 'source_sha256': source}, indent=2) + '\n')
with tarfile.open(out / 'source.tar.gz', 'w:gz') as archive:
    for name in source:
        archive.add(root / name, arcname=name, recursive=False)
for name in source:
    os.utime(root / name, None)
overrides = {
    'CARGO_HOME': '/home/dev-user/.cache/toucan/cargo',
    'CARGO_BUILD_BUILD_DIR': '/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}',
    'CARGO_TARGET_DIR': '/home/dev-user/.cache/oriole/frame-fuzz-target',
    'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST': 'all',
    'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST': 'all',
    'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0',
    'RUSTC_WRAPPER': '', 'RUSTC_WORKSPACE_WRAPPER': '',
    'RUSTFLAGS': '-Zexternal-clangrt -Clinker=clang -Clink-arg=-fsanitize=address',
}
env = os.environ | overrides
env['PATH'] = '/home/dev-user/.cache/oriole/fuzz-tools/bin:' + env['PATH']
env.pop('CARGO_ENCODED_RUSTFLAGS', None)
command = ['taskset', '-c', '2,3', 'cargo', '+ohm', '-Zohm-defaults=no', 'fuzz', 'build', '-Z', 'ohm-defaults=no', '--sanitizer', 'address', '--verbose', '--target-dir', overrides['CARGO_TARGET_DIR']]
report = {'status': 'incomplete', 'source_manifest_sha256': digest(out / 'source.json'), 'command': command, 'env_overrides': overrides, 'removed_env': ['CARGO_ENCODED_RUSTFLAGS'], 'path_prefix': '/home/dev-user/.cache/oriole/fuzz-tools/bin', 'cargo_fuzz_sha256': digest(Path('/home/dev-user/.cache/oriole/fuzz-tools/bin/cargo-fuzz')), 'note': 'An earlier read-only help invocation lacked the installed cargo-fuzz directory in PATH and executed no build. This build uses its explicit recorded binary directory.'}
try:
    report['rustc'] = subprocess.check_output(['rustc', '+ohm', '-vV'], cwd=root, env=env, text=True)
    report['cargo_fuzz_version'] = subprocess.check_output(['cargo', '+ohm', '-Zohm-defaults=no', 'fuzz', '--version'], cwd=root, env=env, text=True)
    report['clang'] = subprocess.check_output(['clang', '--version'], cwd=root, env=env, text=True)
    with (out / 'build.log').open('wb') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
    report['exit'] = result.returncode
    assert result.returncode == 0
    invocations = [line.strip() for line in (out / 'build.log').read_text().splitlines() if 'Running' in line and '/rustc ' in line]
    for crate in ['oriole_storage', 'oriole', 'oriole_expat']:
        matches = [line for line in invocations if '--crate-name ' + crate + ' ' in line]
        assert len(matches) == 1, (crate, len(matches))
        assert '-Zsanitizer=address' in matches[0], crate
    (out / 'compiler-invocations.json').write_text(json.dumps(invocations, indent=2) + '\n')
    binaries = out / 'binaries'
    binaries.mkdir()
    report['binaries'] = {}
    for target in targets:
        path = Path(overrides['CARGO_TARGET_DIR']) / 'x86_64-unknown-linux-gnu/release' / target
        assert path.is_file(), path
        shutil.copy2(path, binaries / target)
        report['binaries'][target] = digest(binaries / target)
    assert all(digest(root / name) == h for name, h in source.items())
    report['source_unchanged'] = True
    report['status'] = 'passed'
finally:
    (out / 'build.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in ['status', 'exit', 'binaries'] if key in report}, indent=2), flush=True)
