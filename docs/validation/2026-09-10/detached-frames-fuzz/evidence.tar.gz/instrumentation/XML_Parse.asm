
/tmp/oriole-frame-fuzz-study/binaries/ffi:     file format elf64-x86-64


Disassembly of section .text:

000000000026aaf0 <XML_Parse>:
  26aaf0:	55                   	push   %rbp
  26aaf1:	48 89 e5             	mov    %rsp,%rbp
  26aaf4:	41 57                	push   %r15
  26aaf6:	41 56                	push   %r14
  26aaf8:	41 55                	push   %r13
  26aafa:	41 54                	push   %r12
  26aafc:	53                   	push   %rbx
  26aafd:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
  26ab01:	48 81 ec a0 00 00 00 	sub    $0xa0,%rsp
  26ab08:	48 89 e3             	mov    %rsp,%rbx
  26ab0b:	89 4b 30             	mov    %ecx,0x30(%rbx)
  26ab0e:	41 89 d5             	mov    %edx,%r13d
  26ab11:	49 89 f6             	mov    %rsi,%r14
  26ab14:	fe 05 d7 6b 37 00    	incb   0x376bd7(%rip)        # 5e16f1 <__start___sancov_cntrs+0x2d1>
  26ab1a:	49 89 ff             	mov    %rdi,%r15
  26ab1d:	48 8b 05 b4 1e 35 00 	mov    0x351eb4(%rip),%rax        # 5bc9d8 <__sancov_lowest_stack@@Base+0x5bc928>
  26ab24:	64 48 3b 28          	cmp    %fs:(%rax),%rbp
  26ab28:	0f 82 12 05 00 00    	jb     26b040 <XML_Parse+0x550>
  26ab2e:	48 8d 05 ab cb 44 00 	lea    0x44cbab(%rip),%rax        # 6b76e0 <__asan_option_detect_stack_use_after_return>
  26ab35:	44 8b 20             	mov    (%rax),%r12d
  26ab38:	31 ff                	xor    %edi,%edi
  26ab3a:	44 89 e6             	mov    %r12d,%esi
  26ab3d:	e8 5e fb 24 00       	call   4ba6a0 <__sanitizer_cov_trace_const_cmp4>
  26ab42:	45 85 e4             	test   %r12d,%r12d
  26ab45:	74 15                	je     26ab5c <XML_Parse+0x6c>
  26ab47:	fe 05 a6 6b 37 00    	incb   0x376ba6(%rip)        # 5e16f3 <__start___sancov_cntrs+0x2d3>
  26ab4d:	bf 00 01 00 00       	mov    $0x100,%edi
  26ab52:	e8 c9 92 f3 ff       	call   1a3e20 <__asan_stack_malloc_2>
  26ab57:	49 89 c4             	mov    %rax,%r12
  26ab5a:	eb 09                	jmp    26ab65 <XML_Parse+0x75>
  26ab5c:	fe 05 90 6b 37 00    	incb   0x376b90(%rip)        # 5e16f2 <__start___sancov_cntrs+0x2d2>
  26ab62:	45 31 e4             	xor    %r12d,%r12d
  26ab65:	31 ff                	xor    %edi,%edi
  26ab67:	4c 89 e6             	mov    %r12,%rsi
  26ab6a:	e8 01 fa 24 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  26ab6f:	4d 85 e4             	test   %r12,%r12
  26ab72:	4c 89 63 70          	mov    %r12,0x70(%rbx)
  26ab76:	74 08                	je     26ab80 <XML_Parse+0x90>
  26ab78:	fe 05 76 6b 37 00    	incb   0x376b76(%rip)        # 5e16f4 <__start___sancov_cntrs+0x2d4>
  26ab7e:	eb 17                	jmp    26ab97 <XML_Parse+0xa7>
  26ab80:	fe 05 6f 6b 37 00    	incb   0x376b6f(%rip)        # 5e16f5 <__start___sancov_cntrs+0x2d5>
  26ab86:	49 89 e4             	mov    %rsp,%r12
  26ab89:	49 81 c4 00 ff ff ff 	add    $0xffffffffffffff00,%r12
  26ab90:	49 83 e4 e0          	and    $0xffffffffffffffe0,%r12
  26ab94:	4c 89 e4             	mov    %r12,%rsp
  26ab97:	4c 89 63 78          	mov    %r12,0x78(%rbx)
  26ab9b:	49 8d 84 24 e0 00 00 	lea    0xe0(%r12),%rax
  26aba2:	00 
  26aba3:	49 c7 04 24 b3 8a b5 	movq   $0x41b58ab3,(%r12)
  26abaa:	41 
  26abab:	48 8d 0d 16 10 2b 00 	lea    0x2b1016(%rip),%rcx        # 51bbc8 <__sanitizer::kExtraRegs+0x12a28>
  26abb2:	49 89 4c 24 08       	mov    %rcx,0x8(%r12)
  26abb7:	48 8d 0d 32 ff ff ff 	lea    -0xce(%rip),%rcx        # 26aaf0 <XML_Parse>
  26abbe:	49 89 4c 24 10       	mov    %rcx,0x10(%r12)
  26abc3:	4c 89 e2             	mov    %r12,%rdx
  26abc6:	48 c1 ea 03          	shr    $0x3,%rdx
  26abca:	48 b9 f1 f1 f1 f1 f8 	movabs $0xf8f8f8f8f1f1f1f1,%rcx
  26abd1:	f8 f8 f8 
  26abd4:	48 89 8a 00 80 ff 7f 	mov    %rcx,0x7fff8000(%rdx)
  26abdb:	48 b9 f2 f2 f2 f2 f8 	movabs $0xf2f2f2f8f2f2f2f2,%rcx
  26abe2:	f2 f2 f2 
  26abe5:	48 89 8a 08 80 ff 7f 	mov    %rcx,0x7fff8008(%rdx)
  26abec:	48 b9 f8 f2 f2 f2 04 	movabs $0xf204f204f2f2f2f8,%rcx
  26abf3:	f2 04 f2 
  26abf6:	48 89 8a 10 80 ff 7f 	mov    %rcx,0x7fff8010(%rdx)
  26abfd:	c7 82 19 80 ff 7f f2 	movl   $0xf2f2f2,0x7fff8019(%rdx)
  26ac04:	f2 f2 00 
  26ac07:	66 c7 82 1d 80 ff 7f 	movw   $0xf3f3,0x7fff801d(%rdx)
  26ac0e:	f3 f3 
  26ac10:	48 89 53 18          	mov    %rdx,0x18(%rbx)
  26ac14:	c6 82 1f 80 ff 7f f3 	movb   $0xf3,0x7fff801f(%rdx)
  26ac1b:	4d 89 bc 24 e0 00 00 	mov    %r15,0xe0(%r12)
  26ac22:	00 
  26ac23:	4d 89 b4 24 c0 00 00 	mov    %r14,0xc0(%r12)
  26ac2a:	00 
  26ac2b:	45 89 ac 24 b0 00 00 	mov    %r13d,0xb0(%r12)
  26ac32:	00 
  26ac33:	8b 4b 30             	mov    0x30(%rbx),%ecx
  26ac36:	41 89 8c 24 a0 00 00 	mov    %ecx,0xa0(%r12)
  26ac3d:	00 
  26ac3e:	48 89 43 38          	mov    %rax,0x38(%rbx)
  26ac42:	4c 8d 73 40          	lea    0x40(%rbx),%r14
  26ac46:	4c 89 f0             	mov    %r14,%rax
  26ac49:	48 c1 e8 03          	shr    $0x3,%rax
  26ac4d:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  26ac54:	7f 
  26ac55:	31 ff                	xor    %edi,%edi
  26ac57:	44 89 ee             	mov    %r13d,%esi
  26ac5a:	e8 81 fc 24 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  26ac5f:	45 85 ed             	test   %r13d,%r13d
  26ac62:	0f 85 11 04 00 00    	jne    26b079 <XML_Parse+0x589>
  26ac68:	49 8d 84 24 b0 00 00 	lea    0xb0(%r12),%rax
  26ac6f:	00 
  26ac70:	48 89 43 40          	mov    %rax,0x40(%rbx)
  26ac74:	4c 8d 73 48          	lea    0x48(%rbx),%r14
  26ac78:	4c 89 f0             	mov    %r14,%rax
  26ac7b:	48 c1 e8 03          	shr    $0x3,%rax
  26ac7f:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  26ac86:	7f 
  26ac87:	31 ff                	xor    %edi,%edi
  26ac89:	44 89 ee             	mov    %r13d,%esi
  26ac8c:	e8 4f fc 24 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  26ac91:	45 85 ed             	test   %r13d,%r13d
  26ac94:	0f 85 ef 03 00 00    	jne    26b089 <XML_Parse+0x599>
  26ac9a:	49 8d 84 24 c0 00 00 	lea    0xc0(%r12),%rax
  26aca1:	00 
  26aca2:	48 89 43 48          	mov    %rax,0x48(%rbx)
  26aca6:	4c 8d 73 50          	lea    0x50(%rbx),%r14
  26acaa:	4c 89 f0             	mov    %r14,%rax
  26acad:	48 c1 e8 03          	shr    $0x3,%rax
  26acb1:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  26acb8:	7f 
  26acb9:	31 ff                	xor    %edi,%edi
  26acbb:	44 89 ee             	mov    %r13d,%esi
  26acbe:	e8 1d fc 24 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  26acc3:	45 85 ed             	test   %r13d,%r13d
  26acc6:	0f 85 cd 03 00 00    	jne    26b099 <XML_Parse+0x5a9>
  26accc:	49 8d 84 24 a0 00 00 	lea    0xa0(%r12),%rax
  26acd3:	00 
  26acd4:	48 89 43 50          	mov    %rax,0x50(%rbx)
  26acd8:	4d 85 ff             	test   %r15,%r15
  26acdb:	4d 89 e6             	mov    %r12,%r14
  26acde:	74 1c                	je     26acfc <XML_Parse+0x20c>
  26ace0:	fe 05 15 6a 37 00    	incb   0x376a15(%rip)        # 5e16fb <__start___sancov_cntrs+0x2db>
  26ace6:	ff 15 7c 1c 35 00    	call   *0x351c7c(%rip)        # 5bc968 <_GLOBAL_OFFSET_TABLE_+0xbc0>
  26acec:	84 c0                	test   %al,%al
  26acee:	0f 84 c1 00 00 00    	je     26adb5 <XML_Parse+0x2c5>
  26acf4:	fe 05 02 6a 37 00    	incb   0x376a02(%rip)        # 5e16fc <__start___sancov_cntrs+0x2dc>
  26acfa:	eb 06                	jmp    26ad02 <XML_Parse+0x212>
  26acfc:	fe 05 f7 69 37 00    	incb   0x3769f7(%rip)        # 5e16f9 <__start___sancov_cntrs+0x2d9>
  26ad02:	48 8d 7b 38          	lea    0x38(%rbx),%rdi
  26ad06:	e8 25 2f 04 00       	call   2adc30 <<oriole_expat::XML_Parse::{closure#0} as core::ops::function::FnOnce<()>>::call_once>
  26ad0b:	41 89 c4             	mov    %eax,%r12d
  26ad0e:	fe 05 e6 69 37 00    	incb   0x3769e6(%rip)        # 5e16fa <__start___sancov_cntrs+0x2da>
  26ad14:	49 c7 06 0e 36 e0 45 	movq   $0x45e0360e,(%r14)
  26ad1b:	31 ff                	xor    %edi,%edi
  26ad1d:	4c 8b 73 70          	mov    0x70(%rbx),%r14
  26ad21:	4c 89 f6             	mov    %r14,%rsi
  26ad24:	e8 47 f8 24 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  26ad29:	4d 85 f6             	test   %r14,%r14
  26ad2c:	74 3c                	je     26ad6a <XML_Parse+0x27a>
  26ad2e:	fe 05 db 69 37 00    	incb   0x3769db(%rip)        # 5e170f <__start___sancov_cntrs+0x2ef>
  26ad34:	48 b8 f5 f5 f5 f5 f5 	movabs $0xf5f5f5f5f5f5f5f5,%rax
  26ad3b:	f5 f5 f5 
  26ad3e:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
  26ad42:	48 89 81 00 80 ff 7f 	mov    %rax,0x7fff8000(%rcx)
  26ad49:	48 89 81 08 80 ff 7f 	mov    %rax,0x7fff8008(%rcx)
  26ad50:	48 89 81 10 80 ff 7f 	mov    %rax,0x7fff8010(%rcx)
  26ad57:	48 89 81 18 80 ff 7f 	mov    %rax,0x7fff8018(%rcx)
  26ad5e:	49 8b 86 f8 00 00 00 	mov    0xf8(%r14),%rax
  26ad65:	c6 00 00             	movb   $0x0,(%rax)
  26ad68:	eb 39                	jmp    26ada3 <XML_Parse+0x2b3>
  26ad6a:	fe 05 a0 69 37 00    	incb   0x3769a0(%rip)        # 5e1710 <__start___sancov_cntrs+0x2f0>
  26ad70:	0f 57 c0             	xorps  %xmm0,%xmm0
  26ad73:	48 8b 43 18          	mov    0x18(%rbx),%rax
  26ad77:	0f 11 80 00 80 ff 7f 	movups %xmm0,0x7fff8000(%rax)
  26ad7e:	48 c7 80 10 80 ff 7f 	movq   $0x0,0x7fff8010(%rax)
  26ad85:	00 00 00 00 
  26ad89:	c7 80 19 80 ff 7f 00 	movl   $0x0,0x7fff8019(%rax)
  26ad90:	00 00 00 
  26ad93:	66 c7 80 1d 80 ff 7f 	movw   $0x0,0x7fff801d(%rax)
  26ad9a:	00 00 
  26ad9c:	c6 80 1f 80 ff 7f 00 	movb   $0x0,0x7fff801f(%rax)
  26ada3:	44 89 e0             	mov    %r12d,%eax
  26ada6:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
  26adaa:	5b                   	pop    %rbx
  26adab:	41 5c                	pop    %r12
  26adad:	41 5d                	pop    %r13
  26adaf:	41 5e                	pop    %r14
  26adb1:	41 5f                	pop    %r15
  26adb3:	5d                   	pop    %rbp
  26adb4:	c3                   	ret
  26adb5:	4c 89 73 28          	mov    %r14,0x28(%rbx)
  26adb9:	48 8b 43 18          	mov    0x18(%rbx),%rax
  26adbd:	c6 80 10 80 ff 7f 00 	movb   $0x0,0x7fff8010(%rax)
  26adc4:	4c 89 fe             	mov    %r15,%rsi
  26adc7:	48 83 e6 07          	and    $0x7,%rsi
  26adcb:	31 ff                	xor    %edi,%edi
  26adcd:	e8 9e f7 24 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  26add2:	4c 89 f8             	mov    %r15,%rax
  26add5:	48 83 e0 07          	and    $0x7,%rax
  26add9:	0f 85 6a 02 00 00    	jne    26b049 <XML_Parse+0x559>
  26addf:	49 83 c7 28          	add    $0x28,%r15
  26ade3:	4c 89 f8             	mov    %r15,%rax
  26ade6:	48 c1 e8 03          	shr    $0x3,%rax
  26adea:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  26adf1:	7f 
  26adf2:	31 ff                	xor    %edi,%edi
  26adf4:	44 89 f6             	mov    %r14d,%esi
  26adf7:	e8 e4 fa 24 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  26adfc:	45 85 f6             	test   %r14d,%r14d
  26adff:	0f 85 a4 02 00 00    	jne    26b0a9 <XML_Parse+0x5b9>
  26ae05:	49 8b 07             	mov    (%r15),%rax
  26ae08:	48 89 43 60          	mov    %rax,0x60(%rbx)
  26ae0c:	4c 8d 70 20          	lea    0x20(%rax),%r14
  26ae10:	4c 89 f0             	mov    %r14,%rax
  26ae13:	48 c1 e8 03          	shr    $0x3,%rax
  26ae17:	48 89 43 30          	mov    %rax,0x30(%rbx)
  26ae1b:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  26ae22:	7f 
  26ae23:	31 ff                	xor    %edi,%edi
  26ae25:	44 89 fe             	mov    %r15d,%esi
  26ae28:	e8 b3 fa 24 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  26ae2d:	45 85 ff             	test   %r15d,%r15d
  26ae30:	0f 85 83 02 00 00    	jne    26b0b9 <XML_Parse+0x5c9>
  26ae36:	48 8b 43 28          	mov    0x28(%rbx),%rax
  26ae3a:	48 8d 48 20          	lea    0x20(%rax),%rcx
  26ae3e:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
  26ae42:	48 8d 48 60          	lea    0x60(%rax),%rcx
  26ae46:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
  26ae4a:	48 05 80 00 00 00    	add    $0x80,%rax
  26ae50:	48 89 43 20          	mov    %rax,0x20(%rbx)
  26ae54:	49 bc ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r12
  26ae5b:	ff ff 7f 
  26ae5e:	4d 8b 3e             	mov    (%r14),%r15
  26ae61:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  26ae68:	0f 1f 84 00 00 00 00 
  26ae6f:	00 
  26ae70:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  26ae77:	4c 89 fe             	mov    %r15,%rsi
  26ae7a:	e8 f1 f6 24 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  26ae7f:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  26ae83:	0f 84 8a 01 00 00    	je     26b013 <XML_Parse+0x523>
  26ae89:	4c 89 e7             	mov    %r12,%rdi
  26ae8c:	4c 89 fe             	mov    %r15,%rsi
  26ae8f:	e8 dc f6 24 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  26ae94:	4d 39 e7             	cmp    %r12,%r15
  26ae97:	0f 83 90 01 00 00    	jae    26b02d <XML_Parse+0x53d>
  26ae9d:	48 8b 43 30          	mov    0x30(%rbx),%rax
  26aea1:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  26aea8:	7f 
  26aea9:	31 ff                	xor    %edi,%edi
  26aeab:	44 89 ee             	mov    %r13d,%esi
  26aeae:	e8 2d fa 24 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  26aeb3:	45 85 ed             	test   %r13d,%r13d
  26aeb6:	0f 85 ad 01 00 00    	jne    26b069 <XML_Parse+0x579>
  26aebc:	49 8d 4f 01          	lea    0x1(%r15),%rcx
  26aec0:	4c 89 f8             	mov    %r15,%rax
  26aec3:	f0 49 0f b1 0e       	lock cmpxchg %rcx,(%r14)
  26aec8:	74 0b                	je     26aed5 <XML_Parse+0x3e5>
  26aeca:	49 89 c7             	mov    %rax,%r15
  26aecd:	fe 05 2e 68 37 00    	incb   0x37682e(%rip)        # 5e1701 <__start___sancov_cntrs+0x2e1>
  26aed3:	eb 9b                	jmp    26ae70 <XML_Parse+0x380>
  26aed5:	4c 8b 63 20          	mov    0x20(%rbx),%r12
  26aed9:	48 8b 43 60          	mov    0x60(%rbx),%rax
  26aedd:	49 89 04 24          	mov    %rax,(%r12)
  26aee1:	64 48 8b 04 25 00 00 	mov    %fs:0x0,%rax
  26aee8:	00 00 
  26aeea:	48 8d 80 a8 ff ff ff 	lea    -0x58(%rax),%rax
  26aef1:	49 89 c6             	mov    %rax,%r14
  26aef4:	48 c1 e8 03          	shr    $0x3,%rax
  26aef8:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  26aeff:	7f 
  26af00:	31 ff                	xor    %edi,%edi
  26af02:	44 89 fe             	mov    %r15d,%esi
  26af05:	e8 d6 f9 24 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  26af0a:	45 85 ff             	test   %r15d,%r15d
  26af0d:	0f 85 b6 01 00 00    	jne    26b0c9 <XML_Parse+0x5d9>
  26af13:	49 8b 06             	mov    (%r14),%rax
  26af16:	4d 89 26             	mov    %r12,(%r14)
  26af19:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
  26af1d:	c6 81 0c 80 ff 7f 00 	movb   $0x0,0x7fff800c(%rcx)
  26af24:	4c 8b 73 68          	mov    0x68(%rbx),%r14
  26af28:	49 89 06             	mov    %rax,(%r14)
  26af2b:	48 8d 7b 38          	lea    0x38(%rbx),%rdi
  26af2f:	e8 fc 2c 04 00       	call   2adc30 <<oriole_expat::XML_Parse::{closure#0} as core::ops::function::FnOnce<()>>::call_once>
  26af34:	41 89 c4             	mov    %eax,%r12d
  26af37:	4c 89 f7             	mov    %r14,%rdi
  26af3a:	ff 15 10 18 35 00    	call   *0x351810(%rip)        # 5bc750 <_GLOBAL_OFFSET_TABLE_+0x9a8>
  26af40:	48 8b 43 18          	mov    0x18(%rbx),%rax
  26af44:	c6 80 0c 80 ff 7f f8 	movb   $0xf8,0x7fff800c(%rax)
  26af4b:	48 8b 43 20          	mov    0x20(%rbx),%rax
  26af4f:	4c 8b 30             	mov    (%rax),%r14
  26af52:	4d 8d 7e 20          	lea    0x20(%r14),%r15
  26af56:	4c 89 f8             	mov    %r15,%rax
  26af59:	48 c1 e8 03          	shr    $0x3,%rax
  26af5d:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  26af64:	7f 
  26af65:	31 ff                	xor    %edi,%edi
  26af67:	44 89 ee             	mov    %r13d,%esi
  26af6a:	e8 71 f9 24 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  26af6f:	45 85 ed             	test   %r13d,%r13d
  26af72:	0f 85 61 01 00 00    	jne    26b0d9 <XML_Parse+0x5e9>
  26af78:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
  26af7f:	f0 4d 0f c1 2f       	lock xadd %r13,(%r15)
  26af84:	bf 01 00 00 00       	mov    $0x1,%edi
  26af89:	4c 89 ee             	mov    %r13,%rsi
  26af8c:	e8 df f5 24 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  26af91:	49 83 fd 01          	cmp    $0x1,%r13
  26af95:	75 62                	jne    26aff9 <XML_Parse+0x509>
  26af97:	fe 05 6e 67 37 00    	incb   0x37676e(%rip)        # 5e170b <__start___sancov_cntrs+0x2eb>
  26af9d:	48 8b 43 18          	mov    0x18(%rbx),%rax
  26afa1:	c7 80 04 80 ff 7f 00 	movl   $0x0,0x7fff8004(%rax)
  26afa8:	00 00 00 
  26afab:	ba 20 00 00 00       	mov    $0x20,%edx
  26afb0:	4c 8b 7b 58          	mov    0x58(%rbx),%r15
  26afb4:	4c 89 ff             	mov    %r15,%rdi
  26afb7:	4c 89 f6             	mov    %r14,%rsi
  26afba:	e8 41 20 fc ff       	call   22d000 <__asan_memcpy>
  26afbf:	ba 08 00 00 00       	mov    $0x8,%edx
  26afc4:	b9 50 00 00 00       	mov    $0x50,%ecx
  26afc9:	4c 89 ff             	mov    %r15,%rdi
  26afcc:	4c 89 f6             	mov    %r14,%rsi
  26afcf:	ff 15 cb 14 35 00    	call   *0x3514cb(%rip)        # 5bc4a0 <_GLOBAL_OFFSET_TABLE_+0x6f8>
  26afd5:	4c 8b 73 28          	mov    0x28(%rbx),%r14
  26afd9:	fe 05 2d 67 37 00    	incb   0x37672d(%rip)        # 5e170c <__start___sancov_cntrs+0x2ec>
  26afdf:	48 8b 43 18          	mov    0x18(%rbx),%rax
  26afe3:	c7 80 04 80 ff 7f f8 	movl   $0xf8f8f8f8,0x7fff8004(%rax)
  26afea:	f8 f8 f8 
  26afed:	c6 80 10 80 ff 7f f8 	movb   $0xf8,0x7fff8010(%rax)
  26aff4:	e9 1b fd ff ff       	jmp    26ad14 <XML_Parse+0x224>
  26aff9:	fe 05 0b 67 37 00    	incb   0x37670b(%rip)        # 5e170a <__start___sancov_cntrs+0x2ea>
  26afff:	48 8b 43 18          	mov    0x18(%rbx),%rax
  26b003:	c6 80 10 80 ff 7f f8 	movb   $0xf8,0x7fff8010(%rax)
  26b00a:	4c 8b 73 28          	mov    0x28(%rbx),%r14
  26b00e:	e9 01 fd ff ff       	jmp    26ad14 <XML_Parse+0x224>
  26b013:	fe 05 e6 66 37 00    	incb   0x3766e6(%rip)        # 5e16ff <__start___sancov_cntrs+0x2df>
  26b019:	e8 32 e1 fc ff       	call   239150 <__asan_handle_no_return>
  26b01e:	48 8d 3d bb fb 33 00 	lea    0x33fbbb(%rip),%rdi        # 5aabe0 <alloc_1952e1d56afff04ffc5dac14dd83ad9e>
  26b025:	ff 15 cd 13 35 00    	call   *0x3513cd(%rip)        # 5bc3f8 <_GLOBAL_OFFSET_TABLE_+0x650>
  26b02b:	eb 11                	jmp    26b03e <XML_Parse+0x54e>
  26b02d:	fe 05 cf 66 37 00    	incb   0x3766cf(%rip)        # 5e1702 <__start___sancov_cntrs+0x2e2>
  26b033:	e8 18 e1 fc ff       	call   239150 <__asan_handle_no_return>
  26b038:	ff 15 b2 19 35 00    	call   *0x3519b2(%rip)        # 5bc9f0 <_GLOBAL_OFFSET_TABLE_+0xc48>
  26b03e:	0f 0b                	ud2
  26b040:	64 48 89 28          	mov    %rbp,%fs:(%rax)
  26b044:	e9 e5 fa ff ff       	jmp    26ab2e <XML_Parse+0x3e>
  26b049:	fe 05 b7 66 37 00    	incb   0x3766b7(%rip)        # 5e1706 <__start___sancov_cntrs+0x2e6>
  26b04f:	e8 fc e0 fc ff       	call   239150 <__asan_handle_no_return>
  26b054:	48 8d 15 c5 ec 33 00 	lea    0x33ecc5(%rip),%rdx        # 5a9d20 <alloc_f6d26a407f2f37238ae68e418ac80303>
  26b05b:	bf 08 00 00 00       	mov    $0x8,%edi
  26b060:	4c 89 fe             	mov    %r15,%rsi
  26b063:	ff 15 87 17 35 00    	call   *0x351787(%rip)        # 5bc7f0 <_GLOBAL_OFFSET_TABLE_+0xa48>
  26b069:	fe 05 91 66 37 00    	incb   0x376691(%rip)        # 5e1700 <__start___sancov_cntrs+0x2e0>
  26b06f:	4c 89 f7             	mov    %r14,%rdi
  26b072:	e8 f9 ce fc ff       	call   237f70 <__asan_report_store8>
  26b077:	0f 0b                	ud2
  26b079:	fe 05 77 66 37 00    	incb   0x376677(%rip)        # 5e16f6 <__start___sancov_cntrs+0x2d6>
  26b07f:	4c 89 f7             	mov    %r14,%rdi
  26b082:	e8 e9 ce fc ff       	call   237f70 <__asan_report_store8>
  26b087:	0f 0b                	ud2
  26b089:	fe 05 68 66 37 00    	incb   0x376668(%rip)        # 5e16f7 <__start___sancov_cntrs+0x2d7>
  26b08f:	4c 89 f7             	mov    %r14,%rdi
  26b092:	e8 d9 ce fc ff       	call   237f70 <__asan_report_store8>
  26b097:	0f 0b                	ud2
  26b099:	fe 05 59 66 37 00    	incb   0x376659(%rip)        # 5e16f8 <__start___sancov_cntrs+0x2d8>
  26b09f:	4c 89 f7             	mov    %r14,%rdi
  26b0a2:	e8 c9 ce fc ff       	call   237f70 <__asan_report_store8>
  26b0a7:	0f 0b                	ud2
  26b0a9:	fe 05 4e 66 37 00    	incb   0x37664e(%rip)        # 5e16fd <__start___sancov_cntrs+0x2dd>
  26b0af:	4c 89 ff             	mov    %r15,%rdi
  26b0b2:	e8 f9 ca fc ff       	call   237bb0 <__asan_report_load8>
  26b0b7:	0f 0b                	ud2
  26b0b9:	fe 05 3f 66 37 00    	incb   0x37663f(%rip)        # 5e16fe <__start___sancov_cntrs+0x2de>
  26b0bf:	4c 89 f7             	mov    %r14,%rdi
  26b0c2:	e8 e9 ca fc ff       	call   237bb0 <__asan_report_load8>
  26b0c7:	0f 0b                	ud2
  26b0c9:	fe 05 34 66 37 00    	incb   0x376634(%rip)        # 5e1703 <__start___sancov_cntrs+0x2e3>
  26b0cf:	4c 89 f7             	mov    %r14,%rdi
  26b0d2:	e8 d9 ca fc ff       	call   237bb0 <__asan_report_load8>
  26b0d7:	0f 0b                	ud2
  26b0d9:	fe 05 2a 66 37 00    	incb   0x37662a(%rip)        # 5e1709 <__start___sancov_cntrs+0x2e9>
  26b0df:	4c 89 ff             	mov    %r15,%rdi
  26b0e2:	e8 89 ce fc ff       	call   237f70 <__asan_report_store8>
  26b0e7:	0f 0b                	ud2
  26b0e9:	fe 05 18 66 37 00    	incb   0x376618(%rip)        # 5e1707 <__start___sancov_cntrs+0x2e7>
  26b0ef:	eb 0f                	jmp    26b100 <XML_Parse+0x610>
  26b0f1:	4c 89 f7             	mov    %r14,%rdi
  26b0f4:	ff 15 56 16 35 00    	call   *0x351656(%rip)        # 5bc750 <_GLOBAL_OFFSET_TABLE_+0x9a8>
  26b0fa:	fe 05 04 66 37 00    	incb   0x376604(%rip)        # 5e1704 <__start___sancov_cntrs+0x2e4>
  26b100:	48 8b 43 20          	mov    0x20(%rbx),%rax
  26b104:	48 8b 38             	mov    (%rax),%rdi
  26b107:	e8 e4 bc 00 00       	call   276df0 <core::ptr::drop_glue::<oriole_storage::shared::Shared<oriole_storage::tracking::AllocationTracker>>>
  26b10c:	fe 05 f6 65 37 00    	incb   0x3765f6(%rip)        # 5e1708 <__start___sancov_cntrs+0x2e8>
  26b112:	e8 39 e0 fc ff       	call   239150 <__asan_handle_no_return>
  26b117:	ff 15 63 1d 35 00    	call   *0x351d63(%rip)        # 5bce80 <_GLOBAL_OFFSET_TABLE_+0x10d8>
  26b11d:	fe 05 e2 65 37 00    	incb   0x3765e2(%rip)        # 5e1705 <__start___sancov_cntrs+0x2e5>
  26b123:	e8 28 e0 fc ff       	call   239150 <__asan_handle_no_return>
  26b128:	ff 15 6a 19 35 00    	call   *0x35196a(%rip)        # 5bca98 <_GLOBAL_OFFSET_TABLE_+0xcf0>
  26b12e:	fe 05 d9 65 37 00    	incb   0x3765d9(%rip)        # 5e170d <__start___sancov_cntrs+0x2ed>
  26b134:	e8 17 e0 fc ff       	call   239150 <__asan_handle_no_return>
  26b139:	ff 15 59 19 35 00    	call   *0x351959(%rip)        # 5bca98 <_GLOBAL_OFFSET_TABLE_+0xcf0>
  26b13f:	fe 05 c9 65 37 00    	incb   0x3765c9(%rip)        # 5e170e <__start___sancov_cntrs+0x2ee>
  26b145:	e8 06 e0 fc ff       	call   239150 <__asan_handle_no_return>
  26b14a:	ff 15 30 1d 35 00    	call   *0x351d30(%rip)        # 5bce80 <_GLOBAL_OFFSET_TABLE_+0x10d8>
