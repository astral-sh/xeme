
/tmp/oriole-frame-fuzz-study/binaries/ffi:     file format elf64-x86-64


Disassembly of section .text:

000000000039c630 <<oriole::Parser>::parse_text>:
  39c630:	55                   	push   %rbp
  39c631:	48 89 e5             	mov    %rsp,%rbp
  39c634:	41 57                	push   %r15
  39c636:	41 56                	push   %r14
  39c638:	41 55                	push   %r13
  39c63a:	41 54                	push   %r12
  39c63c:	53                   	push   %rbx
  39c63d:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
  39c641:	48 81 ec c0 02 00 00 	sub    $0x2c0,%rsp
  39c648:	48 89 e3             	mov    %rsp,%rbx
  39c64b:	49 89 d4             	mov    %rdx,%r12
  39c64e:	48 89 73 20          	mov    %rsi,0x20(%rbx)
  39c652:	fe 05 04 be 24 00    	incb   0x24be04(%rip)        # 5e845c <__start___sancov_cntrs+0x703c>
  39c658:	49 89 ff             	mov    %rdi,%r15
  39c65b:	48 8b 05 76 03 22 00 	mov    0x220376(%rip),%rax        # 5bc9d8 <__sancov_lowest_stack@@Base+0x5bc928>
  39c662:	64 48 3b 28          	cmp    %fs:(%rax),%rbp
  39c666:	0f 82 1b 02 00 00    	jb     39c887 <<oriole::Parser>::parse_text+0x257>
  39c66c:	48 8d 05 6d b0 31 00 	lea    0x31b06d(%rip),%rax        # 6b76e0 <__asan_option_detect_stack_use_after_return>
  39c673:	44 8b 30             	mov    (%rax),%r14d
  39c676:	31 ff                	xor    %edi,%edi
  39c678:	44 89 f6             	mov    %r14d,%esi
  39c67b:	e8 20 e0 11 00       	call   4ba6a0 <__sanitizer_cov_trace_const_cmp4>
  39c680:	45 85 f6             	test   %r14d,%r14d
  39c683:	74 15                	je     39c69a <<oriole::Parser>::parse_text+0x6a>
  39c685:	fe 05 d3 bd 24 00    	incb   0x24bdd3(%rip)        # 5e845e <__start___sancov_cntrs+0x703e>
  39c68b:	bf 60 04 00 00       	mov    $0x460,%edi
  39c690:	e8 fb 8a e0 ff       	call   1a5190 <__asan_stack_malloc_5>
  39c695:	49 89 c6             	mov    %rax,%r14
  39c698:	eb 09                	jmp    39c6a3 <<oriole::Parser>::parse_text+0x73>
  39c69a:	fe 05 bd bd 24 00    	incb   0x24bdbd(%rip)        # 5e845d <__start___sancov_cntrs+0x703d>
  39c6a0:	45 31 f6             	xor    %r14d,%r14d
  39c6a3:	4c 89 a3 c8 01 00 00 	mov    %r12,0x1c8(%rbx)
  39c6aa:	4c 89 7b 58          	mov    %r15,0x58(%rbx)
  39c6ae:	31 ff                	xor    %edi,%edi
  39c6b0:	4c 89 f6             	mov    %r14,%rsi
  39c6b3:	e8 b8 de 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39c6b8:	4d 85 f6             	test   %r14,%r14
  39c6bb:	4c 89 73 68          	mov    %r14,0x68(%rbx)
  39c6bf:	74 0b                	je     39c6cc <<oriole::Parser>::parse_text+0x9c>
  39c6c1:	fe 05 98 bd 24 00    	incb   0x24bd98(%rip)        # 5e845f <__start___sancov_cntrs+0x703f>
  39c6c7:	4c 89 f7             	mov    %r14,%rdi
  39c6ca:	eb 17                	jmp    39c6e3 <<oriole::Parser>::parse_text+0xb3>
  39c6cc:	fe 05 8e bd 24 00    	incb   0x24bd8e(%rip)        # 5e8460 <__start___sancov_cntrs+0x7040>
  39c6d2:	48 89 e7             	mov    %rsp,%rdi
  39c6d5:	48 81 c7 a0 fb ff ff 	add    $0xfffffffffffffba0,%rdi
  39c6dc:	48 83 e7 e0          	and    $0xffffffffffffffe0,%rdi
  39c6e0:	48 89 fc             	mov    %rdi,%rsp
  39c6e3:	48 be f8 f8 f8 f8 f8 	movabs $0xf8f8f8f8f8f8f8f8,%rsi
  39c6ea:	f8 f8 f8 
  39c6ed:	48 89 bb 08 02 00 00 	mov    %rdi,0x208(%rbx)
  39c6f4:	48 c7 07 b3 8a b5 41 	movq   $0x41b58ab3,(%rdi)
  39c6fb:	48 8d 05 59 61 18 00 	lea    0x186159(%rip),%rax        # 52285b <__sanitizer::kExtraRegs+0x196bb>
  39c702:	48 89 47 08          	mov    %rax,0x8(%rdi)
  39c706:	48 8d 05 23 ff ff ff 	lea    -0xdd(%rip),%rax        # 39c630 <<oriole::Parser>::parse_text>
  39c70d:	48 89 47 10          	mov    %rax,0x10(%rdi)
  39c711:	48 89 fa             	mov    %rdi,%rdx
  39c714:	48 c1 ea 03          	shr    $0x3,%rdx
  39c718:	48 8d 86 f9 f8 f8 f8 	lea    -0x7070707(%rsi),%rax
  39c71f:	48 89 82 00 80 ff 7f 	mov    %rax,0x7fff8000(%rdx)
  39c726:	48 89 b2 08 80 ff 7f 	mov    %rsi,0x7fff8008(%rdx)
  39c72d:	48 89 b2 10 80 ff 7f 	mov    %rsi,0x7fff8010(%rdx)
  39c734:	48 89 b2 18 80 ff 7f 	mov    %rsi,0x7fff8018(%rdx)
  39c73b:	48 89 b2 20 80 ff 7f 	mov    %rsi,0x7fff8020(%rdx)
  39c742:	48 b8 f2 f2 f2 f2 f2 	movabs $0xf2f2f2f2f2f2f2f2,%rax
  39c749:	f2 f2 f2 
  39c74c:	48 89 82 28 80 ff 7f 	mov    %rax,0x7fff8028(%rdx)
  39c753:	48 b9 f8 f2 f8 f2 f8 	movabs $0xf2f8f2f8f2f8f2f8,%rcx
  39c75a:	f2 f8 f2 
  39c75d:	48 89 8a 30 80 ff 7f 	mov    %rcx,0x7fff8030(%rdx)
  39c764:	48 8d 8e 00 fa f9 f9 	lea    -0x6060600(%rsi),%rcx
  39c76b:	48 89 8a 38 80 ff 7f 	mov    %rcx,0x7fff8038(%rdx)
  39c772:	48 89 b2 40 80 ff 7f 	mov    %rsi,0x7fff8040(%rdx)
  39c779:	48 89 b2 48 80 ff 7f 	mov    %rsi,0x7fff8048(%rdx)
  39c780:	48 b9 f8 f8 f8 f8 f8 	movabs $0xf2f2f8f8f8f8f8f8,%rcx
  39c787:	f8 f2 f2 
  39c78a:	48 89 8a 50 80 ff 7f 	mov    %rcx,0x7fff8050(%rdx)
  39c791:	48 b9 f2 f2 f2 f2 f2 	movabs $0xf8f8f2f2f2f2f2f2,%rcx
  39c798:	f2 f8 f8 
  39c79b:	48 89 8a 58 80 ff 7f 	mov    %rcx,0x7fff8058(%rdx)
  39c7a2:	48 89 b2 60 80 ff 7f 	mov    %rsi,0x7fff8060(%rdx)
  39c7a9:	48 89 b2 68 80 ff 7f 	mov    %rsi,0x7fff8068(%rdx)
  39c7b0:	48 89 b2 70 80 ff 7f 	mov    %rsi,0x7fff8070(%rdx)
  39c7b7:	48 89 82 78 80 ff 7f 	mov    %rax,0x7fff8078(%rdx)
  39c7be:	48 b8 f8 f8 f8 f8 f8 	movabs $0xf3f8f8f8f8f8f8f8,%rax
  39c7c5:	f8 f8 f3 
  39c7c8:	48 89 82 80 80 ff 7f 	mov    %rax,0x7fff8080(%rdx)
  39c7cf:	48 89 93 88 00 00 00 	mov    %rdx,0x88(%rbx)
  39c7d6:	c7 82 88 80 ff 7f f3 	movl   $0xf3f3f3f3,0x7fff8088(%rdx)
  39c7dd:	f3 f3 f3 
  39c7e0:	4c 8b 7b 20          	mov    0x20(%rbx),%r15
  39c7e4:	49 8d 87 f0 01 00 00 	lea    0x1f0(%r15),%rax
  39c7eb:	48 89 43 38          	mov    %rax,0x38(%rbx)
  39c7ef:	48 c1 e8 03          	shr    $0x3,%rax
  39c7f3:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
  39c7fa:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39c801:	7f 
  39c802:	49 89 fd             	mov    %rdi,%r13
  39c805:	31 ff                	xor    %edi,%edi
  39c807:	44 89 f6             	mov    %r14d,%esi
  39c80a:	e8 d1 e0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39c80f:	45 85 f6             	test   %r14d,%r14d
  39c812:	0f 85 e6 5c 00 00    	jne    3a24fe <<oriole::Parser>::parse_text+0x5ece>
  39c818:	49 8b b7 f0 01 00 00 	mov    0x1f0(%r15),%rsi
  39c81f:	bf 01 00 00 00       	mov    $0x1,%edi
  39c824:	48 89 b3 f8 00 00 00 	mov    %rsi,0xf8(%rbx)
  39c82b:	e8 40 dd 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39c830:	4d 8d a7 43 09 00 00 	lea    0x943(%r15),%r12
  39c837:	4c 89 e0             	mov    %r12,%rax
  39c83a:	48 c1 e8 03          	shr    $0x3,%rax
  39c83e:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
  39c845:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39c84c:	7f 
  39c84d:	31 ff                	xor    %edi,%edi
  39c84f:	44 89 f6             	mov    %r14d,%esi
  39c852:	e8 89 e0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39c857:	45 85 f6             	test   %r14d,%r14d
  39c85a:	4c 89 6b 30          	mov    %r13,0x30(%rbx)
  39c85e:	4c 89 63 60          	mov    %r12,0x60(%rbx)
  39c862:	75 2c                	jne    39c890 <<oriole::Parser>::parse_text+0x260>
  39c864:	fe 05 f8 bb 24 00    	incb   0x24bbf8(%rip)        # 5e8462 <__start___sancov_cntrs+0x7042>
  39c86a:	48 81 83 88 00 00 00 	addq   $0x7fff8000,0x88(%rbx)
  39c871:	00 80 ff 7f 
  39c875:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  39c87a:	75 4f                	jne    39c8cb <<oriole::Parser>::parse_text+0x29b>
  39c87c:	fe 05 e3 bb 24 00    	incb   0x24bbe3(%rip)        # 5e8465 <__start___sancov_cntrs+0x7045>
  39c882:	e9 70 03 00 00       	jmp    39cbf7 <<oriole::Parser>::parse_text+0x5c7>
  39c887:	64 48 89 28          	mov    %rbp,%fs:(%rax)
  39c88b:	e9 dc fd ff ff       	jmp    39c66c <<oriole::Parser>::parse_text+0x3c>
  39c890:	45 89 e7             	mov    %r12d,%r15d
  39c893:	41 83 e7 07          	and    $0x7,%r15d
  39c897:	45 0f b6 f6          	movzbl %r14b,%r14d
  39c89b:	44 89 ff             	mov    %r15d,%edi
  39c89e:	44 89 f6             	mov    %r14d,%esi
  39c8a1:	e8 aa df 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39c8a6:	45 38 f7             	cmp    %r14b,%r15b
  39c8a9:	0f 8d 53 64 00 00    	jge    3a2d02 <<oriole::Parser>::parse_text+0x66d2>
  39c8af:	fe 05 ae bb 24 00    	incb   0x24bbae(%rip)        # 5e8463 <__start___sancov_cntrs+0x7043>
  39c8b5:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  39c8b9:	48 81 83 88 00 00 00 	addq   $0x7fff8000,0x88(%rbx)
  39c8c0:	00 80 ff 7f 
  39c8c4:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  39c8c9:	74 b1                	je     39c87c <<oriole::Parser>::parse_text+0x24c>
  39c8cb:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39c8cf:	4c 8d b0 4a 09 00 00 	lea    0x94a(%rax),%r14
  39c8d6:	4c 89 f0             	mov    %r14,%rax
  39c8d9:	48 c1 e8 03          	shr    $0x3,%rax
  39c8dd:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39c8e4:	7f 
  39c8e5:	31 ff                	xor    %edi,%edi
  39c8e7:	44 89 fe             	mov    %r15d,%esi
  39c8ea:	e8 f1 df 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39c8ef:	45 85 ff             	test   %r15d,%r15d
  39c8f2:	0f 85 a0 00 00 00    	jne    39c998 <<oriole::Parser>::parse_text+0x368>
  39c8f8:	fe 05 68 bb 24 00    	incb   0x24bb68(%rip)        # 5e8466 <__start___sancov_cntrs+0x7046>
  39c8fe:	48 83 bb f8 00 00 00 	cmpq   $0x1,0xf8(%rbx)
  39c905:	01 
  39c906:	0f 87 c3 00 00 00    	ja     39c9cf <<oriole::Parser>::parse_text+0x39f>
  39c90c:	41 80 3e 00          	cmpb   $0x0,(%r14)
  39c910:	0f 85 b9 00 00 00    	jne    39c9cf <<oriole::Parser>::parse_text+0x39f>
  39c916:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39c91a:	4c 8d b0 48 09 00 00 	lea    0x948(%rax),%r14
  39c921:	4c 89 f0             	mov    %r14,%rax
  39c924:	48 c1 e8 03          	shr    $0x3,%rax
  39c928:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39c92f:	7f 
  39c930:	31 ff                	xor    %edi,%edi
  39c932:	44 89 fe             	mov    %r15d,%esi
  39c935:	e8 a6 df 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39c93a:	45 85 ff             	test   %r15d,%r15d
  39c93d:	0f 85 97 00 00 00    	jne    39c9da <<oriole::Parser>::parse_text+0x3aa>
  39c943:	fe 05 25 bb 24 00    	incb   0x24bb25(%rip)        # 5e846e <__start___sancov_cntrs+0x704e>
  39c949:	41 80 3e 00          	cmpb   $0x0,(%r14)
  39c94d:	0f 84 ba 00 00 00    	je     39ca0d <<oriole::Parser>::parse_text+0x3dd>
  39c953:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39c957:	4c 8d b0 28 01 00 00 	lea    0x128(%rax),%r14
  39c95e:	4c 89 f0             	mov    %r14,%rax
  39c961:	48 c1 e8 03          	shr    $0x3,%rax
  39c965:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39c96c:	7f 
  39c96d:	31 ff                	xor    %edi,%edi
  39c96f:	44 89 fe             	mov    %r15d,%esi
  39c972:	e8 69 df 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39c977:	45 85 ff             	test   %r15d,%r15d
  39c97a:	0f 85 3e 02 00 00    	jne    39cbbe <<oriole::Parser>::parse_text+0x58e>
  39c980:	fe 05 f0 ba 24 00    	incb   0x24baf0(%rip)        # 5e8476 <__start___sancov_cntrs+0x7056>
  39c986:	41 f6 06 01          	testb  $0x1,(%r14)
  39c98a:	0f 84 61 02 00 00    	je     39cbf1 <<oriole::Parser>::parse_text+0x5c1>
  39c990:	fe 05 e4 ba 24 00    	incb   0x24bae4(%rip)        # 5e847a <__start___sancov_cntrs+0x705a>
  39c996:	eb 7b                	jmp    39ca13 <<oriole::Parser>::parse_text+0x3e3>
  39c998:	45 89 f4             	mov    %r14d,%r12d
  39c99b:	41 83 e4 07          	and    $0x7,%r12d
  39c99f:	45 0f b6 ff          	movzbl %r15b,%r15d
  39c9a3:	44 89 e7             	mov    %r12d,%edi
  39c9a6:	44 89 fe             	mov    %r15d,%esi
  39c9a9:	e8 a2 de 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39c9ae:	45 38 fc             	cmp    %r15b,%r12b
  39c9b1:	0f 8d 5c 63 00 00    	jge    3a2d13 <<oriole::Parser>::parse_text+0x66e3>
  39c9b7:	fe 05 aa ba 24 00    	incb   0x24baaa(%rip)        # 5e8467 <__start___sancov_cntrs+0x7047>
  39c9bd:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  39c9c1:	48 83 bb f8 00 00 00 	cmpq   $0x1,0xf8(%rbx)
  39c9c8:	01 
  39c9c9:	0f 86 3d ff ff ff    	jbe    39c90c <<oriole::Parser>::parse_text+0x2dc>
  39c9cf:	fe 05 94 ba 24 00    	incb   0x24ba94(%rip)        # 5e8469 <__start___sancov_cntrs+0x7049>
  39c9d5:	e9 1d 02 00 00       	jmp    39cbf7 <<oriole::Parser>::parse_text+0x5c7>
  39c9da:	45 89 f4             	mov    %r14d,%r12d
  39c9dd:	41 83 e4 07          	and    $0x7,%r12d
  39c9e1:	45 0f b6 ff          	movzbl %r15b,%r15d
  39c9e5:	44 89 e7             	mov    %r12d,%edi
  39c9e8:	44 89 fe             	mov    %r15d,%esi
  39c9eb:	e8 60 de 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39c9f0:	45 38 fc             	cmp    %r15b,%r12b
  39c9f3:	0f 8d 2a 63 00 00    	jge    3a2d23 <<oriole::Parser>::parse_text+0x66f3>
  39c9f9:	fe 05 70 ba 24 00    	incb   0x24ba70(%rip)        # 5e846f <__start___sancov_cntrs+0x704f>
  39c9ff:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  39ca03:	41 80 3e 00          	cmpb   $0x0,(%r14)
  39ca07:	0f 85 46 ff ff ff    	jne    39c953 <<oriole::Parser>::parse_text+0x323>
  39ca0d:	fe 05 5e ba 24 00    	incb   0x24ba5e(%rip)        # 5e8471 <__start___sancov_cntrs+0x7051>
  39ca13:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39ca17:	4c 8d b0 88 08 00 00 	lea    0x888(%rax),%r14
  39ca1e:	4c 89 f0             	mov    %r14,%rax
  39ca21:	48 c1 e8 03          	shr    $0x3,%rax
  39ca25:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39ca2c:	7f 
  39ca2d:	31 ff                	xor    %edi,%edi
  39ca2f:	44 89 fe             	mov    %r15d,%esi
  39ca32:	e8 a9 de 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ca37:	45 85 ff             	test   %r15d,%r15d
  39ca3a:	0f 85 50 01 00 00    	jne    39cb90 <<oriole::Parser>::parse_text+0x560>
  39ca40:	fe 05 2c ba 24 00    	incb   0x24ba2c(%rip)        # 5e8472 <__start___sancov_cntrs+0x7052>
  39ca46:	45 0f b6 36          	movzbl (%r14),%r14d
  39ca4a:	bf ff 00 00 00       	mov    $0xff,%edi
  39ca4f:	44 89 f6             	mov    %r14d,%esi
  39ca52:	e8 89 de 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ca57:	41 81 fe ff 00 00 00 	cmp    $0xff,%r14d
  39ca5e:	74 0b                	je     39ca6b <<oriole::Parser>::parse_text+0x43b>
  39ca60:	fe 05 0f ba 24 00    	incb   0x24ba0f(%rip)        # 5e8475 <__start___sancov_cntrs+0x7055>
  39ca66:	e9 8c 01 00 00       	jmp    39cbf7 <<oriole::Parser>::parse_text+0x5c7>
  39ca6b:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39ca6f:	4c 8d b0 e0 01 00 00 	lea    0x1e0(%rax),%r14
  39ca76:	4c 89 f0             	mov    %r14,%rax
  39ca79:	48 c1 e8 03          	shr    $0x3,%rax
  39ca7d:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39ca84:	7f 
  39ca85:	31 ff                	xor    %edi,%edi
  39ca87:	44 89 fe             	mov    %r15d,%esi
  39ca8a:	e8 51 de 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ca8f:	45 85 ff             	test   %r15d,%r15d
  39ca92:	0f 85 76 5f 00 00    	jne    3a2a0e <<oriole::Parser>::parse_text+0x63de>
  39ca98:	4d 8b 36             	mov    (%r14),%r14
  39ca9b:	4c 89 f6             	mov    %r14,%rsi
  39ca9e:	48 83 e6 07          	and    $0x7,%rsi
  39caa2:	31 ff                	xor    %edi,%edi
  39caa4:	e8 c7 da 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39caa9:	4c 89 f0             	mov    %r14,%rax
  39caac:	48 83 e0 07          	and    $0x7,%rax
  39cab0:	0f 85 c4 00 00 00    	jne    39cb7a <<oriole::Parser>::parse_text+0x54a>
  39cab6:	31 ff                	xor    %edi,%edi
  39cab8:	4c 8b bb f8 00 00 00 	mov    0xf8(%rbx),%r15
  39cabf:	4c 89 fe             	mov    %r15,%rsi
  39cac2:	e8 a9 da 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39cac7:	4d 85 ff             	test   %r15,%r15
  39caca:	0f 84 b5 00 00 00    	je     39cb85 <<oriole::Parser>::parse_text+0x555>
  39cad0:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39cad4:	4c 8d b8 28 08 00 00 	lea    0x828(%rax),%r15
  39cadb:	4c 89 f8             	mov    %r15,%rax
  39cade:	48 c1 e8 03          	shr    $0x3,%rax
  39cae2:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  39cae9:	7f 
  39caea:	31 ff                	xor    %edi,%edi
  39caec:	44 89 e6             	mov    %r12d,%esi
  39caef:	e8 ec dd 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39caf4:	45 85 e4             	test   %r12d,%r12d
  39caf7:	0f 85 21 5f 00 00    	jne    3a2a1e <<oriole::Parser>::parse_text+0x63ee>
  39cafd:	49 8b 37             	mov    (%r15),%rsi
  39cb00:	4c 89 f7             	mov    %r14,%rdi
  39cb03:	e8 38 e2 fd ff       	call   37ad40 <<oriole::encoding::Source>::should_defer>
  39cb08:	84 c0                	test   %al,%al
  39cb0a:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  39cb0e:	74 62                	je     39cb72 <<oriole::Parser>::parse_text+0x542>
  39cb10:	48 8b 43 58          	mov    0x58(%rbx),%rax
  39cb14:	48 c1 e8 03          	shr    $0x3,%rax
  39cb18:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39cb1f:	7f 
  39cb20:	31 ff                	xor    %edi,%edi
  39cb22:	44 89 f6             	mov    %r14d,%esi
  39cb25:	e8 b6 dd 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39cb2a:	45 85 f6             	test   %r14d,%r14d
  39cb2d:	0f 85 bd 4b 00 00    	jne    3a16f0 <<oriole::Parser>::parse_text+0x50c0>
  39cb33:	fe 05 47 b9 24 00    	incb   0x24b947(%rip)        # 5e8480 <__start___sancov_cntrs+0x7060>
  39cb39:	4c 8b 7b 58          	mov    0x58(%rbx),%r15
  39cb3d:	41 c6 07 00          	movb   $0x0,(%r15)
  39cb41:	49 83 c7 30          	add    $0x30,%r15
  39cb45:	4c 89 f8             	mov    %r15,%rax
  39cb48:	48 c1 e8 03          	shr    $0x3,%rax
  39cb4c:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39cb53:	7f 
  39cb54:	31 ff                	xor    %edi,%edi
  39cb56:	44 89 f6             	mov    %r14d,%esi
  39cb59:	e8 82 dd 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39cb5e:	45 85 f6             	test   %r14d,%r14d
  39cb61:	0f 85 b4 4b 00 00    	jne    3a171b <<oriole::Parser>::parse_text+0x50eb>
  39cb67:	fe 05 16 b9 24 00    	incb   0x24b916(%rip)        # 5e8483 <__start___sancov_cntrs+0x7063>
  39cb6d:	e9 57 20 00 00       	jmp    39ebc9 <<oriole::Parser>::parse_text+0x2599>
  39cb72:	fe 05 07 b9 24 00    	incb   0x24b907(%rip)        # 5e847f <__start___sancov_cntrs+0x705f>
  39cb78:	eb 7d                	jmp    39cbf7 <<oriole::Parser>::parse_text+0x5c7>
  39cb7a:	fe 05 fc b8 24 00    	incb   0x24b8fc(%rip)        # 5e847c <__start___sancov_cntrs+0x705c>
  39cb80:	e9 74 44 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39cb85:	fe 05 f2 b8 24 00    	incb   0x24b8f2(%rip)        # 5e847d <__start___sancov_cntrs+0x705d>
  39cb8b:	e9 8f 44 00 00       	jmp    3a101f <<oriole::Parser>::parse_text+0x49ef>
  39cb90:	45 89 f4             	mov    %r14d,%r12d
  39cb93:	41 83 e4 07          	and    $0x7,%r12d
  39cb97:	45 0f b6 ff          	movzbl %r15b,%r15d
  39cb9b:	44 89 e7             	mov    %r12d,%edi
  39cb9e:	44 89 fe             	mov    %r15d,%esi
  39cba1:	e8 aa dc 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39cba6:	45 38 fc             	cmp    %r15b,%r12b
  39cba9:	0f 8d 84 61 00 00    	jge    3a2d33 <<oriole::Parser>::parse_text+0x6703>
  39cbaf:	fe 05 be b8 24 00    	incb   0x24b8be(%rip)        # 5e8473 <__start___sancov_cntrs+0x7053>
  39cbb5:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  39cbb9:	e9 88 fe ff ff       	jmp    39ca46 <<oriole::Parser>::parse_text+0x416>
  39cbbe:	45 89 f4             	mov    %r14d,%r12d
  39cbc1:	41 83 e4 07          	and    $0x7,%r12d
  39cbc5:	45 0f b6 ff          	movzbl %r15b,%r15d
  39cbc9:	44 89 e7             	mov    %r12d,%edi
  39cbcc:	44 89 fe             	mov    %r15d,%esi
  39cbcf:	e8 7c dc 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39cbd4:	45 38 fc             	cmp    %r15b,%r12b
  39cbd7:	0f 8d 66 61 00 00    	jge    3a2d43 <<oriole::Parser>::parse_text+0x6713>
  39cbdd:	fe 05 94 b8 24 00    	incb   0x24b894(%rip)        # 5e8477 <__start___sancov_cntrs+0x7057>
  39cbe3:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  39cbe7:	41 f6 06 01          	testb  $0x1,(%r14)
  39cbeb:	0f 85 9f fd ff ff    	jne    39c990 <<oriole::Parser>::parse_text+0x360>
  39cbf1:	fe 05 82 b8 24 00    	incb   0x24b882(%rip)        # 5e8479 <__start___sancov_cntrs+0x7059>
  39cbf7:	48 8b 83 f0 00 00 00 	mov    0xf0(%rbx),%rax
  39cbfe:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39cc05:	7f 
  39cc06:	31 ff                	xor    %edi,%edi
  39cc08:	44 89 f6             	mov    %r14d,%esi
  39cc0b:	e8 d0 dc 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39cc10:	45 85 f6             	test   %r14d,%r14d
  39cc13:	75 1c                	jne    39cc31 <<oriole::Parser>::parse_text+0x601>
  39cc15:	fe 05 4f b8 24 00    	incb   0x24b84f(%rip)        # 5e846a <__start___sancov_cntrs+0x704a>
  39cc1b:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39cc1f:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  39cc24:	75 3f                	jne    39cc65 <<oriole::Parser>::parse_text+0x635>
  39cc26:	fe 05 41 b8 24 00    	incb   0x24b841(%rip)        # 5e846d <__start___sancov_cntrs+0x704d>
  39cc2c:	e9 dc 02 00 00       	jmp    39cf0d <<oriole::Parser>::parse_text+0x8dd>
  39cc31:	45 89 e7             	mov    %r12d,%r15d
  39cc34:	41 83 e7 07          	and    $0x7,%r15d
  39cc38:	45 0f b6 f6          	movzbl %r14b,%r14d
  39cc3c:	44 89 ff             	mov    %r15d,%edi
  39cc3f:	44 89 f6             	mov    %r14d,%esi
  39cc42:	e8 09 dc 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39cc47:	45 38 f7             	cmp    %r14b,%r15b
  39cc4a:	0f 8d 03 61 00 00    	jge    3a2d53 <<oriole::Parser>::parse_text+0x6723>
  39cc50:	fe 05 15 b8 24 00    	incb   0x24b815(%rip)        # 5e846b <__start___sancov_cntrs+0x704b>
  39cc56:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39cc5a:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  39cc5e:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  39cc63:	74 c1                	je     39cc26 <<oriole::Parser>::parse_text+0x5f6>
  39cc65:	4c 8d b0 4a 09 00 00 	lea    0x94a(%rax),%r14
  39cc6c:	4c 89 f0             	mov    %r14,%rax
  39cc6f:	48 c1 e8 03          	shr    $0x3,%rax
  39cc73:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39cc7a:	7f 
  39cc7b:	31 ff                	xor    %edi,%edi
  39cc7d:	44 89 fe             	mov    %r15d,%esi
  39cc80:	e8 5b dc 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39cc85:	45 85 ff             	test   %r15d,%r15d
  39cc88:	75 17                	jne    39cca1 <<oriole::Parser>::parse_text+0x671>
  39cc8a:	fe 05 f6 b7 24 00    	incb   0x24b7f6(%rip)        # 5e8486 <__start___sancov_cntrs+0x7066>
  39cc90:	41 80 3e 01          	cmpb   $0x1,(%r14)
  39cc94:	75 3a                	jne    39ccd0 <<oriole::Parser>::parse_text+0x6a0>
  39cc96:	fe 05 ed b7 24 00    	incb   0x24b7ed(%rip)        # 5e8489 <__start___sancov_cntrs+0x7069>
  39cc9c:	e9 68 02 00 00       	jmp    39cf09 <<oriole::Parser>::parse_text+0x8d9>
  39cca1:	45 89 f4             	mov    %r14d,%r12d
  39cca4:	41 83 e4 07          	and    $0x7,%r12d
  39cca8:	45 0f b6 ff          	movzbl %r15b,%r15d
  39ccac:	44 89 e7             	mov    %r12d,%edi
  39ccaf:	44 89 fe             	mov    %r15d,%esi
  39ccb2:	e8 99 db 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39ccb7:	45 38 fc             	cmp    %r15b,%r12b
  39ccba:	0f 8d a4 60 00 00    	jge    3a2d64 <<oriole::Parser>::parse_text+0x6734>
  39ccc0:	fe 05 c1 b7 24 00    	incb   0x24b7c1(%rip)        # 5e8487 <__start___sancov_cntrs+0x7067>
  39ccc6:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  39ccca:	41 80 3e 01          	cmpb   $0x1,(%r14)
  39ccce:	74 c6                	je     39cc96 <<oriole::Parser>::parse_text+0x666>
  39ccd0:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39ccd4:	4c 8d b0 e0 01 00 00 	lea    0x1e0(%rax),%r14
  39ccdb:	4c 89 f0             	mov    %r14,%rax
  39ccde:	48 c1 e8 03          	shr    $0x3,%rax
  39cce2:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39cce9:	7f 
  39ccea:	31 ff                	xor    %edi,%edi
  39ccec:	44 89 fe             	mov    %r15d,%esi
  39ccef:	e8 ec db 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ccf4:	45 85 ff             	test   %r15d,%r15d
  39ccf7:	0f 85 5b 5b 00 00    	jne    3a2858 <<oriole::Parser>::parse_text+0x6228>
  39ccfd:	4d 8b 26             	mov    (%r14),%r12
  39cd00:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  39cd07:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39cd0e:	7f 
  39cd0f:	31 ff                	xor    %edi,%edi
  39cd11:	44 89 f6             	mov    %r14d,%esi
  39cd14:	e8 c7 db 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39cd19:	45 85 f6             	test   %r14d,%r14d
  39cd1c:	0f 85 46 5b 00 00    	jne    3a2868 <<oriole::Parser>::parse_text+0x6238>
  39cd22:	48 8b 43 38          	mov    0x38(%rbx),%rax
  39cd26:	4c 8b 30             	mov    (%rax),%r14
  39cd29:	4c 89 e6             	mov    %r12,%rsi
  39cd2c:	48 83 e6 07          	and    $0x7,%rsi
  39cd30:	31 ff                	xor    %edi,%edi
  39cd32:	e8 39 d8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39cd37:	4c 89 e0             	mov    %r12,%rax
  39cd3a:	48 83 e0 07          	and    $0x7,%rax
  39cd3e:	0f 85 e5 02 00 00    	jne    39d029 <<oriole::Parser>::parse_text+0x9f9>
  39cd44:	49 bf 55 55 55 55 55 	movabs $0x55555555555555,%r15
  39cd4b:	55 55 00 
  39cd4e:	4c 89 ff             	mov    %r15,%rdi
  39cd51:	4c 89 f6             	mov    %r14,%rsi
  39cd54:	e8 17 d8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39cd59:	4d 39 fe             	cmp    %r15,%r14
  39cd5c:	0f 87 d2 02 00 00    	ja     39d034 <<oriole::Parser>::parse_text+0xa04>
  39cd62:	31 ff                	xor    %edi,%edi
  39cd64:	4c 89 f6             	mov    %r14,%rsi
  39cd67:	e8 04 d8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39cd6c:	4d 85 f6             	test   %r14,%r14
  39cd6f:	0f 84 ca 02 00 00    	je     39d03f <<oriole::Parser>::parse_text+0xa0f>
  39cd75:	4f 8d 2c 76          	lea    (%r14,%r14,2),%r13
  39cd79:	49 c1 e5 07          	shl    $0x7,%r13
  39cd7d:	4b 8d 3c 2c          	lea    (%r12,%r13,1),%rdi
  39cd81:	48 81 c7 a8 fe ff ff 	add    $0xfffffffffffffea8,%rdi
  39cd88:	ff 15 9a f8 21 00    	call   *0x21f89a(%rip)        # 5bc628 <_GLOBAL_OFFSET_TABLE_+0x880>
  39cd8e:	49 89 c6             	mov    %rax,%r14
  39cd91:	49 89 d7             	mov    %rdx,%r15
  39cd94:	4d 01 ec             	add    %r13,%r12
  39cd97:	49 83 c4 a0          	add    $0xffffffffffffffa0,%r12
  39cd9b:	4c 89 e0             	mov    %r12,%rax
  39cd9e:	48 c1 e8 03          	shr    $0x3,%rax
  39cda2:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39cda9:	7f 
  39cdaa:	31 ff                	xor    %edi,%edi
  39cdac:	44 89 ee             	mov    %r13d,%esi
  39cdaf:	e8 2c db 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39cdb4:	45 85 ed             	test   %r13d,%r13d
  39cdb7:	0f 85 bc 5a 00 00    	jne    3a2879 <<oriole::Parser>::parse_text+0x6249>
  39cdbd:	4d 8b 24 24          	mov    (%r12),%r12
  39cdc1:	31 ff                	xor    %edi,%edi
  39cdc3:	4c 89 e6             	mov    %r12,%rsi
  39cdc6:	e8 a5 d7 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39cdcb:	4d 85 e4             	test   %r12,%r12
  39cdce:	74 64                	je     39ce34 <<oriole::Parser>::parse_text+0x804>
  39cdd0:	4c 89 e7             	mov    %r12,%rdi
  39cdd3:	4c 89 fe             	mov    %r15,%rsi
  39cdd6:	e8 f5 d6 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39cddb:	4d 39 fc             	cmp    %r15,%r12
  39cdde:	73 5c                	jae    39ce3c <<oriole::Parser>::parse_text+0x80c>
  39cde0:	4b 8d 04 26          	lea    (%r14,%r12,1),%rax
  39cde4:	48 89 43 08          	mov    %rax,0x8(%rbx)
  39cde8:	48 c1 e8 03          	shr    $0x3,%rax
  39cdec:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39cdf3:	7f 
  39cdf4:	31 ff                	xor    %edi,%edi
  39cdf6:	44 89 ee             	mov    %r13d,%esi
  39cdf9:	e8 e2 da 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39cdfe:	45 85 ed             	test   %r13d,%r13d
  39ce01:	0f 85 d4 43 00 00    	jne    3a11db <<oriole::Parser>::parse_text+0x4bab>
  39ce07:	fe 05 8f b6 24 00    	incb   0x24b68f(%rip)        # 5e849c <__start___sancov_cntrs+0x707c>
  39ce0d:	4b 8d 04 26          	lea    (%r14,%r12,1),%rax
  39ce11:	44 0f b6 28          	movzbl (%rax),%r13d
  39ce15:	bf bf 00 00 00       	mov    $0xbf,%edi
  39ce1a:	44 89 ee             	mov    %r13d,%esi
  39ce1d:	e8 be da 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ce22:	41 80 fd bf          	cmp    $0xbf,%r13b
  39ce26:	0f 8e dd 43 00 00    	jle    3a1209 <<oriole::Parser>::parse_text+0x4bd9>
  39ce2c:	fe 05 6e b6 24 00    	incb   0x24b66e(%rip)        # 5e84a0 <__start___sancov_cntrs+0x7080>
  39ce32:	eb 22                	jmp    39ce56 <<oriole::Parser>::parse_text+0x826>
  39ce34:	fe 05 5f b6 24 00    	incb   0x24b65f(%rip)        # 5e8499 <__start___sancov_cntrs+0x7079>
  39ce3a:	eb 34                	jmp    39ce70 <<oriole::Parser>::parse_text+0x840>
  39ce3c:	4c 89 e7             	mov    %r12,%rdi
  39ce3f:	4c 89 fe             	mov    %r15,%rsi
  39ce42:	e8 89 d6 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39ce47:	4d 39 fc             	cmp    %r15,%r12
  39ce4a:	0f 85 c1 43 00 00    	jne    3a1211 <<oriole::Parser>::parse_text+0x4be1>
  39ce50:	fe 05 45 b6 24 00    	incb   0x24b645(%rip)        # 5e849b <__start___sancov_cntrs+0x707b>
  39ce56:	4c 89 ff             	mov    %r15,%rdi
  39ce59:	4c 89 e6             	mov    %r12,%rsi
  39ce5c:	e8 6f d6 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39ce61:	4d 39 e7             	cmp    %r12,%r15
  39ce64:	0f 82 e0 01 00 00    	jb     39d04a <<oriole::Parser>::parse_text+0xa1a>
  39ce6a:	fe 05 31 b6 24 00    	incb   0x24b631(%rip)        # 5e84a1 <__start___sancov_cntrs+0x7081>
  39ce70:	4d 85 f6             	test   %r14,%r14
  39ce73:	0f 84 10 5a 00 00    	je     3a2889 <<oriole::Parser>::parse_text+0x6259>
  39ce79:	4c 89 ff             	mov    %r15,%rdi
  39ce7c:	4c 89 e6             	mov    %r12,%rsi
  39ce7f:	e8 4c d6 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39ce84:	4d 39 e7             	cmp    %r12,%r15
  39ce87:	0f 84 90 0a 00 00    	je     39d91d <<oriole::Parser>::parse_text+0x12ed>
  39ce8d:	4d 01 e6             	add    %r12,%r14
  39ce90:	4c 89 f0             	mov    %r14,%rax
  39ce93:	48 c1 e8 03          	shr    $0x3,%rax
  39ce97:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39ce9e:	7f 
  39ce9f:	31 ff                	xor    %edi,%edi
  39cea1:	44 89 fe             	mov    %r15d,%esi
  39cea4:	e8 37 da 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39cea9:	45 85 ff             	test   %r15d,%r15d
  39ceac:	0f 85 87 0a 00 00    	jne    39d939 <<oriole::Parser>::parse_text+0x1309>
  39ceb2:	fe 05 ec b5 24 00    	incb   0x24b5ec(%rip)        # 5e84a4 <__start___sancov_cntrs+0x7084>
  39ceb8:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  39cebc:	45 0f b6 36          	movzbl (%r14),%r14d
  39cec0:	48 8d 35 a9 54 22 00 	lea    0x2254a9(%rip),%rsi        # 5c2370 <__sancov_gen_cov_switch_values.2882>
  39cec7:	4c 89 f7             	mov    %r14,%rdi
  39ceca:	e8 a1 da 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  39cecf:	41 83 fe 27          	cmp    $0x27,%r14d
  39ced3:	74 0e                	je     39cee3 <<oriole::Parser>::parse_text+0x8b3>
  39ced5:	41 83 fe 22          	cmp    $0x22,%r14d
  39ced9:	75 28                	jne    39cf03 <<oriole::Parser>::parse_text+0x8d3>
  39cedb:	fe 05 c6 b5 24 00    	incb   0x24b5c6(%rip)        # 5e84a7 <__start___sancov_cntrs+0x7087>
  39cee1:	eb 06                	jmp    39cee9 <<oriole::Parser>::parse_text+0x8b9>
  39cee3:	fe 05 bf b5 24 00    	incb   0x24b5bf(%rip)        # 5e84a8 <__start___sancov_cntrs+0x7088>
  39cee9:	4c 8b 73 68          	mov    0x68(%rbx),%r14
  39ceed:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  39cef1:	48 8b 73 20          	mov    0x20(%rbx),%rsi
  39cef5:	e8 36 0a 04 00       	call   3dd930 <<oriole::Parser>::parse_prolog_literal>
  39cefa:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  39cefe:	e9 ab 4a 00 00       	jmp    3a19ae <<oriole::Parser>::parse_text+0x537e>
  39cf03:	fe 05 a0 b5 24 00    	incb   0x24b5a0(%rip)        # 5e84a9 <__start___sancov_cntrs+0x7089>
  39cf09:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39cf0d:	4c 8d b8 e0 01 00 00 	lea    0x1e0(%rax),%r15
  39cf14:	4c 89 f8             	mov    %r15,%rax
  39cf17:	48 c1 e8 03          	shr    $0x3,%rax
  39cf1b:	48 89 83 a0 00 00 00 	mov    %rax,0xa0(%rbx)
  39cf22:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39cf29:	7f 
  39cf2a:	31 ff                	xor    %edi,%edi
  39cf2c:	44 89 f6             	mov    %r14d,%esi
  39cf2f:	e8 ac d9 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39cf34:	45 85 f6             	test   %r14d,%r14d
  39cf37:	0f 85 d2 55 00 00    	jne    3a250f <<oriole::Parser>::parse_text+0x5edf>
  39cf3d:	4c 89 7b 48          	mov    %r15,0x48(%rbx)
  39cf41:	4d 8b 3f             	mov    (%r15),%r15
  39cf44:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  39cf4b:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39cf52:	7f 
  39cf53:	31 ff                	xor    %edi,%edi
  39cf55:	44 89 f6             	mov    %r14d,%esi
  39cf58:	e8 83 d9 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39cf5d:	45 85 f6             	test   %r14d,%r14d
  39cf60:	0f 85 b9 55 00 00    	jne    3a251f <<oriole::Parser>::parse_text+0x5eef>
  39cf66:	48 8b 43 38          	mov    0x38(%rbx),%rax
  39cf6a:	4c 8b 30             	mov    (%rax),%r14
  39cf6d:	4c 89 fe             	mov    %r15,%rsi
  39cf70:	48 83 e6 07          	and    $0x7,%rsi
  39cf74:	31 ff                	xor    %edi,%edi
  39cf76:	e8 f5 d5 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39cf7b:	4c 89 f8             	mov    %r15,%rax
  39cf7e:	48 83 e0 07          	and    $0x7,%rax
  39cf82:	0f 85 83 00 00 00    	jne    39d00b <<oriole::Parser>::parse_text+0x9db>
  39cf88:	49 bd 55 55 55 55 55 	movabs $0x55555555555555,%r13
  39cf8f:	55 55 00 
  39cf92:	4c 89 ef             	mov    %r13,%rdi
  39cf95:	4c 89 f6             	mov    %r14,%rsi
  39cf98:	e8 d3 d5 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39cf9d:	4d 39 ee             	cmp    %r13,%r14
  39cfa0:	77 71                	ja     39d013 <<oriole::Parser>::parse_text+0x9e3>
  39cfa2:	31 ff                	xor    %edi,%edi
  39cfa4:	4c 89 f6             	mov    %r14,%rsi
  39cfa7:	e8 c4 d5 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39cfac:	4d 85 f6             	test   %r14,%r14
  39cfaf:	74 6d                	je     39d01e <<oriole::Parser>::parse_text+0x9ee>
  39cfb1:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
  39cfb5:	48 c1 e0 07          	shl    $0x7,%rax
  39cfb9:	49 8d 3c 07          	lea    (%r15,%rax,1),%rdi
  39cfbd:	48 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%rdi
  39cfc4:	e8 97 f4 fd ff       	call   37c460 <<oriole::encoding::Source>::converted_text_limit>
  39cfc9:	48 89 43 18          	mov    %rax,0x18(%rbx)
  39cfcd:	48 8b 83 f0 00 00 00 	mov    0xf0(%rbx),%rax
  39cfd4:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39cfdb:	7f 
  39cfdc:	31 ff                	xor    %edi,%edi
  39cfde:	44 89 f6             	mov    %r14d,%esi
  39cfe1:	e8 fa d8 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39cfe6:	45 85 f6             	test   %r14d,%r14d
  39cfe9:	75 6a                	jne    39d055 <<oriole::Parser>::parse_text+0xa25>
  39cfeb:	fe 05 9e b4 24 00    	incb   0x24b49e(%rip)        # 5e848f <__start___sancov_cntrs+0x706f>
  39cff1:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  39cff6:	0f 85 8d 00 00 00    	jne    39d089 <<oriole::Parser>::parse_text+0xa59>
  39cffc:	fe 05 90 b4 24 00    	incb   0x24b490(%rip)        # 5e8492 <__start___sancov_cntrs+0x7072>
  39d002:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39d006:	e9 e5 03 00 00       	jmp    39d3f0 <<oriole::Parser>::parse_text+0xdc0>
  39d00b:	fe 05 7b b4 24 00    	incb   0x24b47b(%rip)        # 5e848c <__start___sancov_cntrs+0x706c>
  39d011:	eb 06                	jmp    39d019 <<oriole::Parser>::parse_text+0x9e9>
  39d013:	fe 05 74 b4 24 00    	incb   0x24b474(%rip)        # 5e848d <__start___sancov_cntrs+0x706d>
  39d019:	e9 db 3f 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39d01e:	fe 05 6a b4 24 00    	incb   0x24b46a(%rip)        # 5e848e <__start___sancov_cntrs+0x706e>
  39d024:	e9 f6 3f 00 00       	jmp    3a101f <<oriole::Parser>::parse_text+0x49ef>
  39d029:	fe 05 66 b4 24 00    	incb   0x24b466(%rip)        # 5e8495 <__start___sancov_cntrs+0x7075>
  39d02f:	e9 c5 3f 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39d034:	fe 05 5c b4 24 00    	incb   0x24b45c(%rip)        # 5e8496 <__start___sancov_cntrs+0x7076>
  39d03a:	e9 ba 3f 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39d03f:	fe 05 52 b4 24 00    	incb   0x24b452(%rip)        # 5e8497 <__start___sancov_cntrs+0x7077>
  39d045:	e9 d5 3f 00 00       	jmp    3a101f <<oriole::Parser>::parse_text+0x49ef>
  39d04a:	fe 05 52 b4 24 00    	incb   0x24b452(%rip)        # 5e84a2 <__start___sancov_cntrs+0x7082>
  39d050:	e9 7d 2f 00 00       	jmp    39ffd2 <<oriole::Parser>::parse_text+0x39a2>
  39d055:	45 89 e7             	mov    %r12d,%r15d
  39d058:	41 83 e7 07          	and    $0x7,%r15d
  39d05c:	45 0f b6 f6          	movzbl %r14b,%r14d
  39d060:	44 89 ff             	mov    %r15d,%edi
  39d063:	44 89 f6             	mov    %r14d,%esi
  39d066:	e8 e5 d7 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39d06b:	45 38 f7             	cmp    %r14b,%r15b
  39d06e:	0f 8d 00 5d 00 00    	jge    3a2d74 <<oriole::Parser>::parse_text+0x6744>
  39d074:	fe 05 16 b4 24 00    	incb   0x24b416(%rip)        # 5e8490 <__start___sancov_cntrs+0x7070>
  39d07a:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  39d07e:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  39d083:	0f 84 73 ff ff ff    	je     39cffc <<oriole::Parser>::parse_text+0x9cc>
  39d089:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39d08d:	4c 8d b0 4a 09 00 00 	lea    0x94a(%rax),%r14
  39d094:	4c 89 f0             	mov    %r14,%rax
  39d097:	48 c1 e8 03          	shr    $0x3,%rax
  39d09b:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39d0a2:	7f 
  39d0a3:	31 ff                	xor    %edi,%edi
  39d0a5:	44 89 fe             	mov    %r15d,%esi
  39d0a8:	e8 33 d8 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d0ad:	45 85 ff             	test   %r15d,%r15d
  39d0b0:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39d0b4:	75 17                	jne    39d0cd <<oriole::Parser>::parse_text+0xa9d>
  39d0b6:	fe 05 ef b3 24 00    	incb   0x24b3ef(%rip)        # 5e84ab <__start___sancov_cntrs+0x708b>
  39d0bc:	41 80 3e 01          	cmpb   $0x1,(%r14)
  39d0c0:	75 3a                	jne    39d0fc <<oriole::Parser>::parse_text+0xacc>
  39d0c2:	fe 05 e6 b3 24 00    	incb   0x24b3e6(%rip)        # 5e84ae <__start___sancov_cntrs+0x708e>
  39d0c8:	e9 23 03 00 00       	jmp    39d3f0 <<oriole::Parser>::parse_text+0xdc0>
  39d0cd:	45 89 f4             	mov    %r14d,%r12d
  39d0d0:	41 83 e4 07          	and    $0x7,%r12d
  39d0d4:	45 0f b6 ff          	movzbl %r15b,%r15d
  39d0d8:	44 89 e7             	mov    %r12d,%edi
  39d0db:	44 89 fe             	mov    %r15d,%esi
  39d0de:	e8 6d d7 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39d0e3:	45 38 fc             	cmp    %r15b,%r12b
  39d0e6:	0f 8d 99 5c 00 00    	jge    3a2d85 <<oriole::Parser>::parse_text+0x6755>
  39d0ec:	fe 05 ba b3 24 00    	incb   0x24b3ba(%rip)        # 5e84ac <__start___sancov_cntrs+0x708c>
  39d0f2:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39d0f6:	41 80 3e 01          	cmpb   $0x1,(%r14)
  39d0fa:	74 c6                	je     39d0c2 <<oriole::Parser>::parse_text+0xa92>
  39d0fc:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  39d103:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39d10a:	7f 
  39d10b:	31 ff                	xor    %edi,%edi
  39d10d:	44 89 f6             	mov    %r14d,%esi
  39d110:	e8 cb d7 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d115:	45 85 f6             	test   %r14d,%r14d
  39d118:	0f 85 af 57 00 00    	jne    3a28cd <<oriole::Parser>::parse_text+0x629d>
  39d11e:	48 8b 43 48          	mov    0x48(%rbx),%rax
  39d122:	4c 8b 20             	mov    (%rax),%r12
  39d125:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  39d12c:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39d133:	7f 
  39d134:	31 ff                	xor    %edi,%edi
  39d136:	44 89 f6             	mov    %r14d,%esi
  39d139:	e8 a2 d7 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d13e:	45 85 f6             	test   %r14d,%r14d
  39d141:	0f 85 97 57 00 00    	jne    3a28de <<oriole::Parser>::parse_text+0x62ae>
  39d147:	48 8b 43 38          	mov    0x38(%rbx),%rax
  39d14b:	4c 8b 30             	mov    (%rax),%r14
  39d14e:	4c 89 e6             	mov    %r12,%rsi
  39d151:	48 83 e6 07          	and    $0x7,%rsi
  39d155:	31 ff                	xor    %edi,%edi
  39d157:	e8 14 d4 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d15c:	4c 89 e0             	mov    %r12,%rax
  39d15f:	48 83 e0 07          	and    $0x7,%rax
  39d163:	0f 85 0d 06 00 00    	jne    39d776 <<oriole::Parser>::parse_text+0x1146>
  39d169:	49 bf 55 55 55 55 55 	movabs $0x55555555555555,%r15
  39d170:	55 55 00 
  39d173:	4c 89 ff             	mov    %r15,%rdi
  39d176:	4c 89 f6             	mov    %r14,%rsi
  39d179:	e8 f2 d3 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d17e:	4d 39 fe             	cmp    %r15,%r14
  39d181:	0f 87 fa 05 00 00    	ja     39d781 <<oriole::Parser>::parse_text+0x1151>
  39d187:	31 ff                	xor    %edi,%edi
  39d189:	4c 89 f6             	mov    %r14,%rsi
  39d18c:	e8 df d3 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d191:	4d 85 f6             	test   %r14,%r14
  39d194:	0f 84 f2 05 00 00    	je     39d78c <<oriole::Parser>::parse_text+0x115c>
  39d19a:	4f 8d 34 76          	lea    (%r14,%r14,2),%r14
  39d19e:	49 c1 e6 07          	shl    $0x7,%r14
  39d1a2:	4b 8d 3c 34          	lea    (%r12,%r14,1),%rdi
  39d1a6:	48 81 c7 a8 fe ff ff 	add    $0xfffffffffffffea8,%rdi
  39d1ad:	ff 15 75 f4 21 00    	call   *0x21f475(%rip)        # 5bc628 <_GLOBAL_OFFSET_TABLE_+0x880>
  39d1b3:	49 89 c7             	mov    %rax,%r15
  39d1b6:	49 89 d5             	mov    %rdx,%r13
  39d1b9:	4d 01 f4             	add    %r14,%r12
  39d1bc:	49 83 c4 a0          	add    $0xffffffffffffffa0,%r12
  39d1c0:	4c 89 e0             	mov    %r12,%rax
  39d1c3:	48 c1 e8 03          	shr    $0x3,%rax
  39d1c7:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39d1ce:	7f 
  39d1cf:	31 ff                	xor    %edi,%edi
  39d1d1:	44 89 f6             	mov    %r14d,%esi
  39d1d4:	e8 07 d7 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d1d9:	45 85 f6             	test   %r14d,%r14d
  39d1dc:	0f 85 0d 57 00 00    	jne    3a28ef <<oriole::Parser>::parse_text+0x62bf>
  39d1e2:	4d 8b 24 24          	mov    (%r12),%r12
  39d1e6:	31 ff                	xor    %edi,%edi
  39d1e8:	4c 89 e6             	mov    %r12,%rsi
  39d1eb:	e8 80 d3 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d1f0:	4d 85 e4             	test   %r12,%r12
  39d1f3:	74 67                	je     39d25c <<oriole::Parser>::parse_text+0xc2c>
  39d1f5:	4c 89 e7             	mov    %r12,%rdi
  39d1f8:	4c 89 ee             	mov    %r13,%rsi
  39d1fb:	e8 d0 d2 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39d200:	4d 39 e5             	cmp    %r12,%r13
  39d203:	76 5f                	jbe    39d264 <<oriole::Parser>::parse_text+0xc34>
  39d205:	4c 89 6b 08          	mov    %r13,0x8(%rbx)
  39d209:	4f 8d 34 27          	lea    (%r15,%r12,1),%r14
  39d20d:	4c 89 f0             	mov    %r14,%rax
  39d210:	48 c1 e8 03          	shr    $0x3,%rax
  39d214:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39d21b:	7f 
  39d21c:	31 ff                	xor    %edi,%edi
  39d21e:	44 89 ee             	mov    %r13d,%esi
  39d221:	e8 ba d6 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d226:	45 85 ed             	test   %r13d,%r13d
  39d229:	0f 85 bb 40 00 00    	jne    3a12ea <<oriole::Parser>::parse_text+0x4cba>
  39d22f:	fe 05 9e b2 24 00    	incb   0x24b29e(%rip)        # 5e84d3 <__start___sancov_cntrs+0x70b3>
  39d235:	45 0f b6 36          	movzbl (%r14),%r14d
  39d239:	bf bf 00 00 00       	mov    $0xbf,%edi
  39d23e:	44 89 f6             	mov    %r14d,%esi
  39d241:	e8 9a d6 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d246:	41 80 fe bf          	cmp    $0xbf,%r14b
  39d24a:	4c 8b 6b 08          	mov    0x8(%rbx),%r13
  39d24e:	0f 8e c5 40 00 00    	jle    3a1319 <<oriole::Parser>::parse_text+0x4ce9>
  39d254:	fe 05 7d b2 24 00    	incb   0x24b27d(%rip)        # 5e84d7 <__start___sancov_cntrs+0x70b7>
  39d25a:	eb 22                	jmp    39d27e <<oriole::Parser>::parse_text+0xc4e>
  39d25c:	fe 05 6e b2 24 00    	incb   0x24b26e(%rip)        # 5e84d0 <__start___sancov_cntrs+0x70b0>
  39d262:	eb 34                	jmp    39d298 <<oriole::Parser>::parse_text+0xc68>
  39d264:	4c 89 e7             	mov    %r12,%rdi
  39d267:	4c 89 ee             	mov    %r13,%rsi
  39d26a:	e8 61 d2 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39d26f:	4d 39 e5             	cmp    %r12,%r13
  39d272:	0f 85 a9 40 00 00    	jne    3a1321 <<oriole::Parser>::parse_text+0x4cf1>
  39d278:	fe 05 54 b2 24 00    	incb   0x24b254(%rip)        # 5e84d2 <__start___sancov_cntrs+0x70b2>
  39d27e:	4c 89 ef             	mov    %r13,%rdi
  39d281:	4c 89 e6             	mov    %r12,%rsi
  39d284:	e8 47 d2 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39d289:	4d 39 e5             	cmp    %r12,%r13
  39d28c:	0f 82 05 05 00 00    	jb     39d797 <<oriole::Parser>::parse_text+0x1167>
  39d292:	fe 05 40 b2 24 00    	incb   0x24b240(%rip)        # 5e84d8 <__start___sancov_cntrs+0x70b8>
  39d298:	4d 85 ff             	test   %r15,%r15
  39d29b:	0f 84 5e 56 00 00    	je     3a28ff <<oriole::Parser>::parse_text+0x62cf>
  39d2a1:	4b 8d 04 27          	lea    (%r15,%r12,1),%rax
  39d2a5:	4d 01 ef             	add    %r13,%r15
  39d2a8:	4d 29 e5             	sub    %r12,%r13
  39d2ab:	4c 89 6b 08          	mov    %r13,0x8(%rbx)
  39d2af:	48 c7 83 30 01 00 00 	movq   $0x0,0x130(%rbx)
  39d2b6:	00 00 00 00 
  39d2ba:	48 89 43 70          	mov    %rax,0x70(%rbx)
  39d2be:	48 89 83 20 01 00 00 	mov    %rax,0x120(%rbx)
  39d2c5:	4c 89 bb 28 01 00 00 	mov    %r15,0x128(%rbx)
  39d2cc:	4c 8d 2d bd 50 22 00 	lea    0x2250bd(%rip),%r13        # 5c2390 <__sancov_gen_cov_switch_values.2883>
  39d2d3:	4c 8d 25 1e f2 19 00 	lea    0x19f21e(%rip),%r12        # 53c4f8 <switch.table._RNvCs26TCrUj5Hdw_12oriole_expat10run_events+0x1058>
  39d2da:	eb 0a                	jmp    39d2e6 <<oriole::Parser>::parse_text+0xcb6>
  39d2dc:	0f 1f 40 00          	nopl   0x0(%rax)
  39d2e0:	fe 05 f6 b1 24 00    	incb   0x24b1f6(%rip)        # 5e84dc <__start___sancov_cntrs+0x70bc>
  39d2e6:	48 8d bb 20 01 00 00 	lea    0x120(%rbx),%rdi
  39d2ed:	e8 be 7a 0a 00       	call   444db0 <<core::str::iter::CharIndices as core::iter::traits::iterator::Iterator>::next>
  39d2f2:	49 89 c7             	mov    %rax,%r15
  39d2f5:	41 89 d6             	mov    %edx,%r14d
  39d2f8:	89 d7                	mov    %edx,%edi
  39d2fa:	4c 89 ee             	mov    %r13,%rsi
  39d2fd:	e8 6e d6 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  39d302:	41 ff c6             	inc    %r14d
  39d305:	41 83 fe 21          	cmp    $0x21,%r14d
  39d309:	77 2d                	ja     39d338 <<oriole::Parser>::parse_text+0xd08>
  39d30b:	4b 63 04 b4          	movslq (%r12,%r14,4),%rax
  39d30f:	4c 01 e0             	add    %r12,%rax
  39d312:	ff e0                	jmp    *%rax
  39d314:	fe 05 c3 b1 24 00    	incb   0x24b1c3(%rip)        # 5e84dd <__start___sancov_cntrs+0x70bd>
  39d31a:	eb ca                	jmp    39d2e6 <<oriole::Parser>::parse_text+0xcb6>
  39d31c:	0f 1f 40 00          	nopl   0x0(%rax)
  39d320:	fe 05 b5 b1 24 00    	incb   0x24b1b5(%rip)        # 5e84db <__start___sancov_cntrs+0x70bb>
  39d326:	eb be                	jmp    39d2e6 <<oriole::Parser>::parse_text+0xcb6>
  39d328:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  39d32f:	00 
  39d330:	fe 05 a8 b1 24 00    	incb   0x24b1a8(%rip)        # 5e84de <__start___sancov_cntrs+0x70be>
  39d336:	eb ae                	jmp    39d2e6 <<oriole::Parser>::parse_text+0xcb6>
  39d338:	fe 05 a2 b1 24 00    	incb   0x24b1a2(%rip)        # 5e84e0 <__start___sancov_cntrs+0x70c0>
  39d33e:	4c 8b 73 08          	mov    0x8(%rbx),%r14
  39d342:	eb 0d                	jmp    39d351 <<oriole::Parser>::parse_text+0xd21>
  39d344:	fe 05 95 b1 24 00    	incb   0x24b195(%rip)        # 5e84df <__start___sancov_cntrs+0x70bf>
  39d34a:	4c 8b 73 08          	mov    0x8(%rbx),%r14
  39d34e:	4d 89 f7             	mov    %r14,%r15
  39d351:	31 ff                	xor    %edi,%edi
  39d353:	4c 89 fe             	mov    %r15,%rsi
  39d356:	e8 15 d2 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d35b:	4d 85 ff             	test   %r15,%r15
  39d35e:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39d362:	74 67                	je     39d3cb <<oriole::Parser>::parse_text+0xd9b>
  39d364:	4c 89 ff             	mov    %r15,%rdi
  39d367:	4c 89 f6             	mov    %r14,%rsi
  39d36a:	e8 61 d1 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39d36f:	4d 39 f7             	cmp    %r14,%r15
  39d372:	73 5f                	jae    39d3d3 <<oriole::Parser>::parse_text+0xda3>
  39d374:	48 8b 43 70          	mov    0x70(%rbx),%rax
  39d378:	4c 01 f8             	add    %r15,%rax
  39d37b:	49 89 c5             	mov    %rax,%r13
  39d37e:	48 c1 e8 03          	shr    $0x3,%rax
  39d382:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39d389:	7f 
  39d38a:	31 ff                	xor    %edi,%edi
  39d38c:	44 89 f6             	mov    %r14d,%esi
  39d38f:	e8 4c d5 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d394:	45 85 f6             	test   %r14d,%r14d
  39d397:	0f 85 ad 3f 00 00    	jne    3a134a <<oriole::Parser>::parse_text+0x4d1a>
  39d39d:	fe 05 40 b1 24 00    	incb   0x24b140(%rip)        # 5e84e3 <__start___sancov_cntrs+0x70c3>
  39d3a3:	45 0f b6 75 00       	movzbl 0x0(%r13),%r14d
  39d3a8:	48 8d 35 21 50 22 00 	lea    0x225021(%rip),%rsi        # 5c23d0 <__sancov_gen_cov_switch_values.2884>
  39d3af:	4c 89 f7             	mov    %r14,%rdi
  39d3b2:	e8 b9 d5 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  39d3b7:	41 83 fe 27          	cmp    $0x27,%r14d
  39d3bb:	74 1e                	je     39d3db <<oriole::Parser>::parse_text+0xdab>
  39d3bd:	41 83 fe 22          	cmp    $0x22,%r14d
  39d3c1:	75 27                	jne    39d3ea <<oriole::Parser>::parse_text+0xdba>
  39d3c3:	fe 05 1d b1 24 00    	incb   0x24b11d(%rip)        # 5e84e6 <__start___sancov_cntrs+0x70c6>
  39d3c9:	eb 16                	jmp    39d3e1 <<oriole::Parser>::parse_text+0xdb1>
  39d3cb:	fe 05 10 b1 24 00    	incb   0x24b110(%rip)        # 5e84e1 <__start___sancov_cntrs+0x70c1>
  39d3d1:	eb 1d                	jmp    39d3f0 <<oriole::Parser>::parse_text+0xdc0>
  39d3d3:	fe 05 09 b1 24 00    	incb   0x24b109(%rip)        # 5e84e2 <__start___sancov_cntrs+0x70c2>
  39d3d9:	eb 15                	jmp    39d3f0 <<oriole::Parser>::parse_text+0xdc0>
  39d3db:	fe 05 06 b1 24 00    	incb   0x24b106(%rip)        # 5e84e7 <__start___sancov_cntrs+0x70c7>
  39d3e1:	4d 39 e7             	cmp    %r12,%r15
  39d3e4:	4d 0f 42 e7          	cmovb  %r15,%r12
  39d3e8:	eb 06                	jmp    39d3f0 <<oriole::Parser>::parse_text+0xdc0>
  39d3ea:	fe 05 f8 b0 24 00    	incb   0x24b0f8(%rip)        # 5e84e8 <__start___sancov_cntrs+0x70c8>
  39d3f0:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  39d3f7:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39d3fe:	7f 
  39d3ff:	31 ff                	xor    %edi,%edi
  39d401:	44 89 f6             	mov    %r14d,%esi
  39d404:	e8 d7 d4 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d409:	45 85 f6             	test   %r14d,%r14d
  39d40c:	0f 85 1e 51 00 00    	jne    3a2530 <<oriole::Parser>::parse_text+0x5f00>
  39d412:	48 8b 43 48          	mov    0x48(%rbx),%rax
  39d416:	4c 8b 38             	mov    (%rax),%r15
  39d419:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  39d420:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39d427:	7f 
  39d428:	31 ff                	xor    %edi,%edi
  39d42a:	44 89 f6             	mov    %r14d,%esi
  39d42d:	e8 ae d4 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d432:	45 85 f6             	test   %r14d,%r14d
  39d435:	0f 85 06 51 00 00    	jne    3a2541 <<oriole::Parser>::parse_text+0x5f11>
  39d43b:	48 8b 43 38          	mov    0x38(%rbx),%rax
  39d43f:	4c 8b 30             	mov    (%rax),%r14
  39d442:	4c 89 fe             	mov    %r15,%rsi
  39d445:	48 83 e6 07          	and    $0x7,%rsi
  39d449:	31 ff                	xor    %edi,%edi
  39d44b:	e8 20 d1 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d450:	4c 89 f8             	mov    %r15,%rax
  39d453:	48 83 e0 07          	and    $0x7,%rax
  39d457:	0f 85 e2 02 00 00    	jne    39d73f <<oriole::Parser>::parse_text+0x110f>
  39d45d:	4c 89 63 18          	mov    %r12,0x18(%rbx)
  39d461:	49 bc 55 55 55 55 55 	movabs $0x55555555555555,%r12
  39d468:	55 55 00 
  39d46b:	4c 89 e7             	mov    %r12,%rdi
  39d46e:	4c 89 f6             	mov    %r14,%rsi
  39d471:	e8 fa d0 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d476:	4d 39 e6             	cmp    %r12,%r14
  39d479:	0f 87 cb 02 00 00    	ja     39d74a <<oriole::Parser>::parse_text+0x111a>
  39d47f:	31 ff                	xor    %edi,%edi
  39d481:	4c 89 f6             	mov    %r14,%rsi
  39d484:	e8 e7 d0 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d489:	4d 85 f6             	test   %r14,%r14
  39d48c:	0f 84 c3 02 00 00    	je     39d755 <<oriole::Parser>::parse_text+0x1125>
  39d492:	4f 8d 24 76          	lea    (%r14,%r14,2),%r12
  39d496:	49 c1 e4 07          	shl    $0x7,%r12
  39d49a:	4b 8d 3c 27          	lea    (%r15,%r12,1),%rdi
  39d49e:	48 81 c7 a8 fe ff ff 	add    $0xfffffffffffffea8,%rdi
  39d4a5:	ff 15 7d f1 21 00    	call   *0x21f17d(%rip)        # 5bc628 <_GLOBAL_OFFSET_TABLE_+0x880>
  39d4ab:	48 89 43 50          	mov    %rax,0x50(%rbx)
  39d4af:	49 89 d6             	mov    %rdx,%r14
  39d4b2:	4d 01 e7             	add    %r12,%r15
  39d4b5:	49 83 c7 a0          	add    $0xffffffffffffffa0,%r15
  39d4b9:	4c 89 f8             	mov    %r15,%rax
  39d4bc:	48 c1 e8 03          	shr    $0x3,%rax
  39d4c0:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  39d4c7:	7f 
  39d4c8:	31 ff                	xor    %edi,%edi
  39d4ca:	44 89 e6             	mov    %r12d,%esi
  39d4cd:	e8 0e d4 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d4d2:	45 85 e4             	test   %r12d,%r12d
  39d4d5:	0f 85 77 50 00 00    	jne    3a2552 <<oriole::Parser>::parse_text+0x5f22>
  39d4db:	4d 8b 3f             	mov    (%r15),%r15
  39d4de:	31 ff                	xor    %edi,%edi
  39d4e0:	4c 89 fe             	mov    %r15,%rsi
  39d4e3:	e8 88 d0 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d4e8:	4c 89 f9             	mov    %r15,%rcx
  39d4eb:	4d 85 ff             	test   %r15,%r15
  39d4ee:	4c 8b 7b 18          	mov    0x18(%rbx),%r15
  39d4f2:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
  39d4f6:	74 6b                	je     39d563 <<oriole::Parser>::parse_text+0xf33>
  39d4f8:	48 89 cf             	mov    %rcx,%rdi
  39d4fb:	4c 89 f6             	mov    %r14,%rsi
  39d4fe:	e8 cd cf 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39d503:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
  39d507:	49 39 fe             	cmp    %rdi,%r14
  39d50a:	76 5f                	jbe    39d56b <<oriole::Parser>::parse_text+0xf3b>
  39d50c:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39d510:	4c 8d 3c 38          	lea    (%rax,%rdi,1),%r15
  39d514:	4c 89 f8             	mov    %r15,%rax
  39d517:	48 c1 e8 03          	shr    $0x3,%rax
  39d51b:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  39d522:	7f 
  39d523:	31 ff                	xor    %edi,%edi
  39d525:	44 89 e6             	mov    %r12d,%esi
  39d528:	e8 b3 d3 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d52d:	45 85 e4             	test   %r12d,%r12d
  39d530:	0f 85 35 03 00 00    	jne    39d86b <<oriole::Parser>::parse_text+0x123b>
  39d536:	fe 05 7c af 24 00    	incb   0x24af7c(%rip)        # 5e84b8 <__start___sancov_cntrs+0x7098>
  39d53c:	45 0f b6 3f          	movzbl (%r15),%r15d
  39d540:	bf bf 00 00 00       	mov    $0xbf,%edi
  39d545:	44 89 fe             	mov    %r15d,%esi
  39d548:	e8 93 d3 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d54d:	41 80 ff bf          	cmp    $0xbf,%r15b
  39d551:	4c 8b 7b 18          	mov    0x18(%rbx),%r15
  39d555:	0f 8e 3a 03 00 00    	jle    39d895 <<oriole::Parser>::parse_text+0x1265>
  39d55b:	fe 05 5b af 24 00    	incb   0x24af5b(%rip)        # 5e84bc <__start___sancov_cntrs+0x709c>
  39d561:	eb 20                	jmp    39d583 <<oriole::Parser>::parse_text+0xf53>
  39d563:	fe 05 4c af 24 00    	incb   0x24af4c(%rip)        # 5e84b5 <__start___sancov_cntrs+0x7095>
  39d569:	eb 37                	jmp    39d5a2 <<oriole::Parser>::parse_text+0xf72>
  39d56b:	4c 89 f6             	mov    %r14,%rsi
  39d56e:	e8 5d cf 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39d573:	4c 3b 73 40          	cmp    0x40(%rbx),%r14
  39d577:	0f 85 20 03 00 00    	jne    39d89d <<oriole::Parser>::parse_text+0x126d>
  39d57d:	fe 05 34 af 24 00    	incb   0x24af34(%rip)        # 5e84b7 <__start___sancov_cntrs+0x7097>
  39d583:	4c 89 f7             	mov    %r14,%rdi
  39d586:	48 8b 73 40          	mov    0x40(%rbx),%rsi
  39d58a:	e8 41 cf 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39d58f:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39d593:	49 39 ce             	cmp    %rcx,%r14
  39d596:	0f 82 c4 01 00 00    	jb     39d760 <<oriole::Parser>::parse_text+0x1130>
  39d59c:	fe 05 1b af 24 00    	incb   0x24af1b(%rip)        # 5e84bd <__start___sancov_cntrs+0x709d>
  39d5a2:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39d5a6:	48 85 c0             	test   %rax,%rax
  39d5a9:	0f 84 b3 4f 00 00    	je     3a2562 <<oriole::Parser>::parse_text+0x5f32>
  39d5af:	48 01 c8             	add    %rcx,%rax
  39d5b2:	48 89 83 80 00 00 00 	mov    %rax,0x80(%rbx)
  39d5b9:	31 ff                	xor    %edi,%edi
  39d5bb:	49 89 cc             	mov    %rcx,%r12
  39d5be:	4c 89 fe             	mov    %r15,%rsi
  39d5c1:	e8 aa cf 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d5c6:	4d 85 ff             	test   %r15,%r15
  39d5c9:	74 6c                	je     39d637 <<oriole::Parser>::parse_text+0x1007>
  39d5cb:	4d 29 e6             	sub    %r12,%r14
  39d5ce:	4c 89 ff             	mov    %r15,%rdi
  39d5d1:	4c 89 f6             	mov    %r14,%rsi
  39d5d4:	e8 f7 ce 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39d5d9:	4d 39 f7             	cmp    %r14,%r15
  39d5dc:	73 61                	jae    39d63f <<oriole::Parser>::parse_text+0x100f>
  39d5de:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39d5e2:	4c 01 e0             	add    %r12,%rax
  39d5e5:	49 01 c7             	add    %rax,%r15
  39d5e8:	4c 89 f8             	mov    %r15,%rax
  39d5eb:	48 c1 e8 03          	shr    $0x3,%rax
  39d5ef:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  39d5f6:	7f 
  39d5f7:	31 ff                	xor    %edi,%edi
  39d5f9:	44 89 e6             	mov    %r12d,%esi
  39d5fc:	e8 df d2 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d601:	45 85 e4             	test   %r12d,%r12d
  39d604:	0f 85 b9 02 00 00    	jne    39d8c3 <<oriole::Parser>::parse_text+0x1293>
  39d60a:	fe 05 b3 ae 24 00    	incb   0x24aeb3(%rip)        # 5e84c3 <__start___sancov_cntrs+0x70a3>
  39d610:	45 0f b6 3f          	movzbl (%r15),%r15d
  39d614:	bf bf 00 00 00       	mov    $0xbf,%edi
  39d619:	44 89 fe             	mov    %r15d,%esi
  39d61c:	e8 bf d2 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d621:	41 80 ff bf          	cmp    $0xbf,%r15b
  39d625:	4c 8b 7b 18          	mov    0x18(%rbx),%r15
  39d629:	0f 8e be 02 00 00    	jle    39d8ed <<oriole::Parser>::parse_text+0x12bd>
  39d62f:	fe 05 92 ae 24 00    	incb   0x24ae92(%rip)        # 5e84c7 <__start___sancov_cntrs+0x70a7>
  39d635:	eb 22                	jmp    39d659 <<oriole::Parser>::parse_text+0x1029>
  39d637:	fe 05 83 ae 24 00    	incb   0x24ae83(%rip)        # 5e84c0 <__start___sancov_cntrs+0x70a0>
  39d63d:	eb 34                	jmp    39d673 <<oriole::Parser>::parse_text+0x1043>
  39d63f:	4c 89 ff             	mov    %r15,%rdi
  39d642:	4c 89 f6             	mov    %r14,%rsi
  39d645:	e8 86 ce 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39d64a:	4d 39 f7             	cmp    %r14,%r15
  39d64d:	0f 85 a2 02 00 00    	jne    39d8f5 <<oriole::Parser>::parse_text+0x12c5>
  39d653:	fe 05 69 ae 24 00    	incb   0x24ae69(%rip)        # 5e84c2 <__start___sancov_cntrs+0x70a2>
  39d659:	4c 89 ff             	mov    %r15,%rdi
  39d65c:	4c 89 f6             	mov    %r14,%rsi
  39d65f:	e8 6c ce 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39d664:	4d 39 f7             	cmp    %r14,%r15
  39d667:	0f 87 fe 00 00 00    	ja     39d76b <<oriole::Parser>::parse_text+0x113b>
  39d66d:	fe 05 55 ae 24 00    	incb   0x24ae55(%rip)        # 5e84c8 <__start___sancov_cntrs+0x70a8>
  39d673:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  39d67a:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39d681:	7f 
  39d682:	31 ff                	xor    %edi,%edi
  39d684:	44 89 f6             	mov    %r14d,%esi
  39d687:	e8 54 d2 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d68c:	45 85 f6             	test   %r14d,%r14d
  39d68f:	0f 85 d8 4e 00 00    	jne    3a256d <<oriole::Parser>::parse_text+0x5f3d>
  39d695:	48 8b 43 38          	mov    0x38(%rbx),%rax
  39d699:	4c 8b 30             	mov    (%rax),%r14
  39d69c:	bf 01 00 00 00       	mov    $0x1,%edi
  39d6a1:	4c 89 f6             	mov    %r14,%rsi
  39d6a4:	e8 c7 ce 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d6a9:	49 83 fe 02          	cmp    $0x2,%r14
  39d6ad:	72 0b                	jb     39d6ba <<oriole::Parser>::parse_text+0x108a>
  39d6af:	fe 05 35 ae 24 00    	incb   0x24ae35(%rip)        # 5e84ea <__start___sancov_cntrs+0x70ca>
  39d6b5:	e9 de 02 00 00       	jmp    39d998 <<oriole::Parser>::parse_text+0x1368>
  39d6ba:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39d6be:	4c 8d b8 48 09 00 00 	lea    0x948(%rax),%r15
  39d6c5:	4c 89 f8             	mov    %r15,%rax
  39d6c8:	48 c1 e8 03          	shr    $0x3,%rax
  39d6cc:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  39d6d3:	7f 
  39d6d4:	31 ff                	xor    %edi,%edi
  39d6d6:	44 89 e6             	mov    %r12d,%esi
  39d6d9:	e8 02 d2 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d6de:	45 85 e4             	test   %r12d,%r12d
  39d6e1:	0f 85 bb 00 00 00    	jne    39d7a2 <<oriole::Parser>::parse_text+0x1172>
  39d6e7:	fe 05 fe ad 24 00    	incb   0x24adfe(%rip)        # 5e84eb <__start___sancov_cntrs+0x70cb>
  39d6ed:	41 80 3f 00          	cmpb   $0x0,(%r15)
  39d6f1:	0f 84 da 00 00 00    	je     39d7d1 <<oriole::Parser>::parse_text+0x11a1>
  39d6f7:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39d6fb:	4c 8d b8 28 01 00 00 	lea    0x128(%rax),%r15
  39d702:	4c 89 f8             	mov    %r15,%rax
  39d705:	48 c1 e8 03          	shr    $0x3,%rax
  39d709:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  39d710:	7f 
  39d711:	31 ff                	xor    %edi,%edi
  39d713:	44 89 e6             	mov    %r12d,%esi
  39d716:	e8 c5 d1 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d71b:	45 85 e4             	test   %r12d,%r12d
  39d71e:	0f 85 3f 02 00 00    	jne    39d963 <<oriole::Parser>::parse_text+0x1333>
  39d724:	fe 05 ca ad 24 00    	incb   0x24adca(%rip)        # 5e84f4 <__start___sancov_cntrs+0x70d4>
  39d72a:	41 f6 07 01          	testb  $0x1,(%r15)
  39d72e:	0f 84 5e 02 00 00    	je     39d992 <<oriole::Parser>::parse_text+0x1362>
  39d734:	fe 05 be ad 24 00    	incb   0x24adbe(%rip)        # 5e84f8 <__start___sancov_cntrs+0x70d8>
  39d73a:	e9 98 00 00 00       	jmp    39d7d7 <<oriole::Parser>::parse_text+0x11a7>
  39d73f:	fe 05 6c ad 24 00    	incb   0x24ad6c(%rip)        # 5e84b1 <__start___sancov_cntrs+0x7091>
  39d745:	e9 af 38 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39d74a:	fe 05 62 ad 24 00    	incb   0x24ad62(%rip)        # 5e84b2 <__start___sancov_cntrs+0x7092>
  39d750:	e9 a4 38 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39d755:	fe 05 58 ad 24 00    	incb   0x24ad58(%rip)        # 5e84b3 <__start___sancov_cntrs+0x7093>
  39d75b:	e9 bf 38 00 00       	jmp    3a101f <<oriole::Parser>::parse_text+0x49ef>
  39d760:	fe 05 58 ad 24 00    	incb   0x24ad58(%rip)        # 5e84be <__start___sancov_cntrs+0x709e>
  39d766:	e9 67 28 00 00       	jmp    39ffd2 <<oriole::Parser>::parse_text+0x39a2>
  39d76b:	fe 05 58 ad 24 00    	incb   0x24ad58(%rip)        # 5e84c9 <__start___sancov_cntrs+0x70a9>
  39d771:	e9 95 27 00 00       	jmp    39ff0b <<oriole::Parser>::parse_text+0x38db>
  39d776:	fe 05 50 ad 24 00    	incb   0x24ad50(%rip)        # 5e84cc <__start___sancov_cntrs+0x70ac>
  39d77c:	e9 78 38 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39d781:	fe 05 46 ad 24 00    	incb   0x24ad46(%rip)        # 5e84cd <__start___sancov_cntrs+0x70ad>
  39d787:	e9 6d 38 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39d78c:	fe 05 3c ad 24 00    	incb   0x24ad3c(%rip)        # 5e84ce <__start___sancov_cntrs+0x70ae>
  39d792:	e9 88 38 00 00       	jmp    3a101f <<oriole::Parser>::parse_text+0x49ef>
  39d797:	fe 05 3c ad 24 00    	incb   0x24ad3c(%rip)        # 5e84d9 <__start___sancov_cntrs+0x70b9>
  39d79d:	e9 30 28 00 00       	jmp    39ffd2 <<oriole::Parser>::parse_text+0x39a2>
  39d7a2:	45 89 fd             	mov    %r15d,%r13d
  39d7a5:	41 83 e5 07          	and    $0x7,%r13d
  39d7a9:	45 0f b6 e4          	movzbl %r12b,%r12d
  39d7ad:	44 89 ef             	mov    %r13d,%edi
  39d7b0:	44 89 e6             	mov    %r12d,%esi
  39d7b3:	e8 98 d0 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39d7b8:	45 38 e5             	cmp    %r12b,%r13b
  39d7bb:	0f 8d d4 55 00 00    	jge    3a2d95 <<oriole::Parser>::parse_text+0x6765>
  39d7c1:	fe 05 25 ad 24 00    	incb   0x24ad25(%rip)        # 5e84ec <__start___sancov_cntrs+0x70cc>
  39d7c7:	41 80 3f 00          	cmpb   $0x0,(%r15)
  39d7cb:	0f 85 26 ff ff ff    	jne    39d6f7 <<oriole::Parser>::parse_text+0x10c7>
  39d7d1:	fe 05 17 ad 24 00    	incb   0x24ad17(%rip)        # 5e84ee <__start___sancov_cntrs+0x70ce>
  39d7d7:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39d7db:	4c 8d b8 88 08 00 00 	lea    0x888(%rax),%r15
  39d7e2:	4c 89 f8             	mov    %r15,%rax
  39d7e5:	48 c1 e8 03          	shr    $0x3,%rax
  39d7e9:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  39d7f0:	7f 
  39d7f1:	31 ff                	xor    %edi,%edi
  39d7f3:	44 89 e6             	mov    %r12d,%esi
  39d7f6:	e8 e5 d0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d7fb:	45 85 e4             	test   %r12d,%r12d
  39d7fe:	75 44                	jne    39d844 <<oriole::Parser>::parse_text+0x1214>
  39d800:	fe 05 e9 ac 24 00    	incb   0x24ace9(%rip)        # 5e84ef <__start___sancov_cntrs+0x70cf>
  39d806:	45 0f b6 3f          	movzbl (%r15),%r15d
  39d80a:	bf ff 00 00 00       	mov    $0xff,%edi
  39d80f:	44 89 fe             	mov    %r15d,%esi
  39d812:	e8 c9 d0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d817:	41 81 ff ff 00 00 00 	cmp    $0xff,%r15d
  39d81e:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39d822:	74 0b                	je     39d82f <<oriole::Parser>::parse_text+0x11ff>
  39d824:	fe 05 c8 ac 24 00    	incb   0x24acc8(%rip)        # 5e84f2 <__start___sancov_cntrs+0x70d2>
  39d82a:	e9 69 01 00 00       	jmp    39d998 <<oriole::Parser>::parse_text+0x1368>
  39d82f:	fe 05 be ac 24 00    	incb   0x24acbe(%rip)        # 5e84f3 <__start___sancov_cntrs+0x70d3>
  39d835:	c7 83 9c 00 00 00 00 	movl   $0x0,0x9c(%rbx)
  39d83c:	00 00 00 
  39d83f:	e9 f1 02 00 00       	jmp    39db35 <<oriole::Parser>::parse_text+0x1505>
  39d844:	45 89 fd             	mov    %r15d,%r13d
  39d847:	41 83 e5 07          	and    $0x7,%r13d
  39d84b:	45 0f b6 e4          	movzbl %r12b,%r12d
  39d84f:	44 89 ef             	mov    %r13d,%edi
  39d852:	44 89 e6             	mov    %r12d,%esi
  39d855:	e8 f6 cf 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39d85a:	45 38 e5             	cmp    %r12b,%r13b
  39d85d:	0f 8d 42 55 00 00    	jge    3a2da5 <<oriole::Parser>::parse_text+0x6775>
  39d863:	fe 05 87 ac 24 00    	incb   0x24ac87(%rip)        # 5e84f0 <__start___sancov_cntrs+0x70d0>
  39d869:	eb 9b                	jmp    39d806 <<oriole::Parser>::parse_text+0x11d6>
  39d86b:	45 89 fd             	mov    %r15d,%r13d
  39d86e:	41 83 e5 07          	and    $0x7,%r13d
  39d872:	45 0f b6 e4          	movzbl %r12b,%r12d
  39d876:	44 89 ef             	mov    %r13d,%edi
  39d879:	44 89 e6             	mov    %r12d,%esi
  39d87c:	e8 cf cf 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39d881:	45 38 e5             	cmp    %r12b,%r13b
  39d884:	0f 8d 2b 55 00 00    	jge    3a2db5 <<oriole::Parser>::parse_text+0x6785>
  39d88a:	fe 05 29 ac 24 00    	incb   0x24ac29(%rip)        # 5e84b9 <__start___sancov_cntrs+0x7099>
  39d890:	e9 a7 fc ff ff       	jmp    39d53c <<oriole::Parser>::parse_text+0xf0c>
  39d895:	fe 05 20 ac 24 00    	incb   0x24ac20(%rip)        # 5e84bb <__start___sancov_cntrs+0x709b>
  39d89b:	eb 06                	jmp    39d8a3 <<oriole::Parser>::parse_text+0x1273>
  39d89d:	fe 05 13 ac 24 00    	incb   0x24ac13(%rip)        # 5e84b6 <__start___sancov_cntrs+0x7096>
  39d8a3:	e8 a8 b8 e9 ff       	call   239150 <__asan_handle_no_return>
  39d8a8:	4c 8d 05 f1 46 21 00 	lea    0x2146f1(%rip),%r8        # 5b1fa0 <alloc_0d86069ca8d9aba608a2c91e648a76f1>
  39d8af:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
  39d8b3:	4c 89 f6             	mov    %r14,%rsi
  39d8b6:	48 8b 53 40          	mov    0x40(%rbx),%rdx
  39d8ba:	4c 89 f1             	mov    %r14,%rcx
  39d8bd:	ff 15 f5 f0 21 00    	call   *0x21f0f5(%rip)        # 5bc9b8 <_GLOBAL_OFFSET_TABLE_+0xc10>
  39d8c3:	45 89 fd             	mov    %r15d,%r13d
  39d8c6:	41 83 e5 07          	and    $0x7,%r13d
  39d8ca:	45 0f b6 e4          	movzbl %r12b,%r12d
  39d8ce:	44 89 ef             	mov    %r13d,%edi
  39d8d1:	44 89 e6             	mov    %r12d,%esi
  39d8d4:	e8 77 cf 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39d8d9:	45 38 e5             	cmp    %r12b,%r13b
  39d8dc:	0f 8d e3 54 00 00    	jge    3a2dc5 <<oriole::Parser>::parse_text+0x6795>
  39d8e2:	fe 05 dc ab 24 00    	incb   0x24abdc(%rip)        # 5e84c4 <__start___sancov_cntrs+0x70a4>
  39d8e8:	e9 23 fd ff ff       	jmp    39d610 <<oriole::Parser>::parse_text+0xfe0>
  39d8ed:	fe 05 d3 ab 24 00    	incb   0x24abd3(%rip)        # 5e84c6 <__start___sancov_cntrs+0x70a6>
  39d8f3:	eb 06                	jmp    39d8fb <<oriole::Parser>::parse_text+0x12cb>
  39d8f5:	fe 05 c6 ab 24 00    	incb   0x24abc6(%rip)        # 5e84c1 <__start___sancov_cntrs+0x70a1>
  39d8fb:	e8 50 b8 e9 ff       	call   239150 <__asan_handle_no_return>
  39d900:	4c 8d 05 99 55 21 00 	lea    0x215599(%rip),%r8        # 5b2ea0 <alloc_96909f6643775a1f4b10043bb5022ab2>
  39d907:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  39d90e:	4c 89 f6             	mov    %r14,%rsi
  39d911:	31 d2                	xor    %edx,%edx
  39d913:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
  39d917:	ff 15 9b f0 21 00    	call   *0x21f09b(%rip)        # 5bc9b8 <_GLOBAL_OFFSET_TABLE_+0xc10>
  39d91d:	fe 05 87 ab 24 00    	incb   0x24ab87(%rip)        # 5e84aa <__start___sancov_cntrs+0x708a>
  39d923:	e8 28 b8 e9 ff       	call   239150 <__asan_handle_no_return>
  39d928:	48 8d 15 31 55 21 00 	lea    0x215531(%rip),%rdx        # 5b2e60 <alloc_e3376c4b2d3d2bac6e5bee7910cefca2>
  39d92f:	31 ff                	xor    %edi,%edi
  39d931:	31 f6                	xor    %esi,%esi
  39d933:	ff 15 af f6 21 00    	call   *0x21f6af(%rip)        # 5bcfe8 <_GLOBAL_OFFSET_TABLE_+0x1240>
  39d939:	45 89 f4             	mov    %r14d,%r12d
  39d93c:	41 83 e4 07          	and    $0x7,%r12d
  39d940:	45 0f b6 ff          	movzbl %r15b,%r15d
  39d944:	44 89 e7             	mov    %r12d,%edi
  39d947:	44 89 fe             	mov    %r15d,%esi
  39d94a:	e8 01 cf 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39d94f:	45 38 fc             	cmp    %r15b,%r12b
  39d952:	0f 8d 7d 54 00 00    	jge    3a2dd5 <<oriole::Parser>::parse_text+0x67a5>
  39d958:	fe 05 47 ab 24 00    	incb   0x24ab47(%rip)        # 5e84a5 <__start___sancov_cntrs+0x7085>
  39d95e:	e9 55 f5 ff ff       	jmp    39ceb8 <<oriole::Parser>::parse_text+0x888>
  39d963:	45 89 fd             	mov    %r15d,%r13d
  39d966:	41 83 e5 07          	and    $0x7,%r13d
  39d96a:	45 0f b6 e4          	movzbl %r12b,%r12d
  39d96e:	44 89 ef             	mov    %r13d,%edi
  39d971:	44 89 e6             	mov    %r12d,%esi
  39d974:	e8 d7 ce 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39d979:	45 38 e5             	cmp    %r12b,%r13b
  39d97c:	0f 8d 63 54 00 00    	jge    3a2de5 <<oriole::Parser>::parse_text+0x67b5>
  39d982:	fe 05 6d ab 24 00    	incb   0x24ab6d(%rip)        # 5e84f5 <__start___sancov_cntrs+0x70d5>
  39d988:	41 f6 07 01          	testb  $0x1,(%r15)
  39d98c:	0f 85 a2 fd ff ff    	jne    39d734 <<oriole::Parser>::parse_text+0x1104>
  39d992:	fe 05 5f ab 24 00    	incb   0x24ab5f(%rip)        # 5e84f7 <__start___sancov_cntrs+0x70d7>
  39d998:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  39d99f:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39d9a6:	7f 
  39d9a7:	31 ff                	xor    %edi,%edi
  39d9a9:	44 89 fe             	mov    %r15d,%esi
  39d9ac:	e8 2f cf 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39d9b1:	45 85 ff             	test   %r15d,%r15d
  39d9b4:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  39d9b8:	0f 85 e1 4b 00 00    	jne    3a259f <<oriole::Parser>::parse_text+0x5f6f>
  39d9be:	4c 8b 27             	mov    (%rdi),%r12
  39d9c1:	4c 89 e6             	mov    %r12,%rsi
  39d9c4:	48 83 e6 07          	and    $0x7,%rsi
  39d9c8:	31 ff                	xor    %edi,%edi
  39d9ca:	e8 a1 cb 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d9cf:	4c 89 e0             	mov    %r12,%rax
  39d9d2:	48 83 e0 07          	and    $0x7,%rax
  39d9d6:	0f 85 68 24 00 00    	jne    39fe44 <<oriole::Parser>::parse_text+0x3814>
  39d9dc:	49 bf 55 55 55 55 55 	movabs $0x55555555555555,%r15
  39d9e3:	55 55 00 
  39d9e6:	4c 89 ff             	mov    %r15,%rdi
  39d9e9:	4c 89 f6             	mov    %r14,%rsi
  39d9ec:	e8 7f cb 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39d9f1:	4d 39 fe             	cmp    %r15,%r14
  39d9f4:	0f 87 55 24 00 00    	ja     39fe4f <<oriole::Parser>::parse_text+0x381f>
  39d9fa:	31 ff                	xor    %edi,%edi
  39d9fc:	4c 89 f6             	mov    %r14,%rsi
  39d9ff:	e8 6c cb 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39da04:	4d 85 f6             	test   %r14,%r14
  39da07:	0f 84 4d 24 00 00    	je     39fe5a <<oriole::Parser>::parse_text+0x382a>
  39da0d:	4f 8d 2c 76          	lea    (%r14,%r14,2),%r13
  39da11:	49 c1 e5 07          	shl    $0x7,%r13
  39da15:	4b 8d 3c 2c          	lea    (%r12,%r13,1),%rdi
  39da19:	48 81 c7 a8 fe ff ff 	add    $0xfffffffffffffea8,%rdi
  39da20:	ff 15 02 ec 21 00    	call   *0x21ec02(%rip)        # 5bc628 <_GLOBAL_OFFSET_TABLE_+0x880>
  39da26:	49 89 c7             	mov    %rax,%r15
  39da29:	49 89 d6             	mov    %rdx,%r14
  39da2c:	4d 01 ec             	add    %r13,%r12
  39da2f:	49 83 c4 a0          	add    $0xffffffffffffffa0,%r12
  39da33:	4c 89 e0             	mov    %r12,%rax
  39da36:	48 c1 e8 03          	shr    $0x3,%rax
  39da3a:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39da41:	7f 
  39da42:	31 ff                	xor    %edi,%edi
  39da44:	44 89 ee             	mov    %r13d,%esi
  39da47:	e8 94 ce 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39da4c:	45 85 ed             	test   %r13d,%r13d
  39da4f:	0f 85 57 4b 00 00    	jne    3a25ac <<oriole::Parser>::parse_text+0x5f7c>
  39da55:	4d 8b 24 24          	mov    (%r12),%r12
  39da59:	31 ff                	xor    %edi,%edi
  39da5b:	4c 89 e6             	mov    %r12,%rsi
  39da5e:	e8 0d cb 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39da63:	4d 85 e4             	test   %r12,%r12
  39da66:	74 64                	je     39dacc <<oriole::Parser>::parse_text+0x149c>
  39da68:	4c 89 e7             	mov    %r12,%rdi
  39da6b:	4c 89 f6             	mov    %r14,%rsi
  39da6e:	e8 5d ca 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39da73:	4d 39 e6             	cmp    %r12,%r14
  39da76:	76 5c                	jbe    39dad4 <<oriole::Parser>::parse_text+0x14a4>
  39da78:	4b 8d 04 27          	lea    (%r15,%r12,1),%rax
  39da7c:	48 89 43 08          	mov    %rax,0x8(%rbx)
  39da80:	48 c1 e8 03          	shr    $0x3,%rax
  39da84:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39da8b:	7f 
  39da8c:	31 ff                	xor    %edi,%edi
  39da8e:	44 89 ee             	mov    %r13d,%esi
  39da91:	e8 4a ce 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39da96:	45 85 ed             	test   %r13d,%r13d
  39da99:	0f 85 de 27 00 00    	jne    3a027d <<oriole::Parser>::parse_text+0x3c4d>
  39da9f:	fe 05 5c aa 24 00    	incb   0x24aa5c(%rip)        # 5e8501 <__start___sancov_cntrs+0x70e1>
  39daa5:	4b 8d 04 27          	lea    (%r15,%r12,1),%rax
  39daa9:	44 0f b6 28          	movzbl (%rax),%r13d
  39daad:	bf bf 00 00 00       	mov    $0xbf,%edi
  39dab2:	44 89 ee             	mov    %r13d,%esi
  39dab5:	e8 26 ce 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39daba:	41 80 fd bf          	cmp    $0xbf,%r13b
  39dabe:	0f 8e e7 27 00 00    	jle    3a02ab <<oriole::Parser>::parse_text+0x3c7b>
  39dac4:	fe 05 3b aa 24 00    	incb   0x24aa3b(%rip)        # 5e8505 <__start___sancov_cntrs+0x70e5>
  39daca:	eb 22                	jmp    39daee <<oriole::Parser>::parse_text+0x14be>
  39dacc:	fe 05 2c aa 24 00    	incb   0x24aa2c(%rip)        # 5e84fe <__start___sancov_cntrs+0x70de>
  39dad2:	eb 34                	jmp    39db08 <<oriole::Parser>::parse_text+0x14d8>
  39dad4:	4c 89 e7             	mov    %r12,%rdi
  39dad7:	4c 89 f6             	mov    %r14,%rsi
  39dada:	e8 f1 c9 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39dadf:	4d 39 e6             	cmp    %r12,%r14
  39dae2:	0f 85 cb 27 00 00    	jne    3a02b3 <<oriole::Parser>::parse_text+0x3c83>
  39dae8:	fe 05 12 aa 24 00    	incb   0x24aa12(%rip)        # 5e8500 <__start___sancov_cntrs+0x70e0>
  39daee:	4c 89 f7             	mov    %r14,%rdi
  39daf1:	4c 89 e6             	mov    %r12,%rsi
  39daf4:	e8 d7 c9 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39daf9:	4d 39 e6             	cmp    %r12,%r14
  39dafc:	0f 82 f8 23 00 00    	jb     39fefa <<oriole::Parser>::parse_text+0x38ca>
  39db02:	fe 05 fe a9 24 00    	incb   0x24a9fe(%rip)        # 5e8506 <__start___sancov_cntrs+0x70e6>
  39db08:	4d 85 ff             	test   %r15,%r15
  39db0b:	0f 84 ab 4a 00 00    	je     3a25bc <<oriole::Parser>::parse_text+0x5f8c>
  39db11:	fe 05 f2 a9 24 00    	incb   0x24a9f2(%rip)        # 5e8509 <__start___sancov_cntrs+0x70e9>
  39db17:	4d 29 e6             	sub    %r12,%r14
  39db1a:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39db1e:	4c 89 e7             	mov    %r12,%rdi
  39db21:	4c 89 f6             	mov    %r14,%rsi
  39db24:	e8 a7 c9 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39db29:	4d 39 f4             	cmp    %r14,%r12
  39db2c:	0f 94 c0             	sete   %al
  39db2f:	89 83 9c 00 00 00    	mov    %eax,0x9c(%rbx)
  39db35:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39db39:	4c 8d b8 68 02 00 00 	lea    0x268(%rax),%r15
  39db40:	4c 89 f8             	mov    %r15,%rax
  39db43:	48 c1 e8 03          	shr    $0x3,%rax
  39db47:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
  39db4e:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39db55:	7f 
  39db56:	31 ff                	xor    %edi,%edi
  39db58:	44 89 f6             	mov    %r14d,%esi
  39db5b:	e8 80 cd 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39db60:	45 85 f6             	test   %r14d,%r14d
  39db63:	0f 85 15 4a 00 00    	jne    3a257e <<oriole::Parser>::parse_text+0x5f4e>
  39db69:	4c 89 bb d8 00 00 00 	mov    %r15,0xd8(%rbx)
  39db70:	4d 8b 37             	mov    (%r15),%r14
  39db73:	31 ff                	xor    %edi,%edi
  39db75:	4c 89 f6             	mov    %r14,%rsi
  39db78:	e8 f3 c9 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39db7d:	4d 85 f6             	test   %r14,%r14
  39db80:	74 1f                	je     39dba1 <<oriole::Parser>::parse_text+0x1571>
  39db82:	fe 05 83 a9 24 00    	incb   0x24a983(%rip)        # 5e850b <__start___sancov_cntrs+0x70eb>
  39db88:	c6 83 a8 00 00 00 01 	movb   $0x1,0xa8(%rbx)
  39db8f:	48 8b 53 50          	mov    0x50(%rbx),%rdx
  39db93:	48 8b 73 40          	mov    0x40(%rbx),%rsi
  39db97:	48 8d 04 32          	lea    (%rdx,%rsi,1),%rax
  39db9b:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
  39db9f:	eb 4d                	jmp    39dbee <<oriole::Parser>::parse_text+0x15be>
  39dba1:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39dba5:	4c 8d b0 4a 09 00 00 	lea    0x94a(%rax),%r14
  39dbac:	4c 89 f0             	mov    %r14,%rax
  39dbaf:	48 c1 e8 03          	shr    $0x3,%rax
  39dbb3:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39dbba:	7f 
  39dbbb:	31 ff                	xor    %edi,%edi
  39dbbd:	44 89 fe             	mov    %r15d,%esi
  39dbc0:	e8 1b cd 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39dbc5:	45 85 ff             	test   %r15d,%r15d
  39dbc8:	0f 85 86 25 00 00    	jne    3a0154 <<oriole::Parser>::parse_text+0x3b24>
  39dbce:	fe 05 38 a9 24 00    	incb   0x24a938(%rip)        # 5e850c <__start___sancov_cntrs+0x70ec>
  39dbd4:	48 8b 53 50          	mov    0x50(%rbx),%rdx
  39dbd8:	48 8b 73 40          	mov    0x40(%rbx),%rsi
  39dbdc:	48 8d 04 32          	lea    (%rdx,%rsi,1),%rax
  39dbe0:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
  39dbe4:	41 0f b6 0e          	movzbl (%r14),%ecx
  39dbe8:	88 8b a8 00 00 00    	mov    %cl,0xa8(%rbx)
  39dbee:	48 8d 4f 20          	lea    0x20(%rdi),%rcx
  39dbf2:	48 89 8b e8 00 00 00 	mov    %rcx,0xe8(%rbx)
  39dbf9:	48 8d 8f 80 01 00 00 	lea    0x180(%rdi),%rcx
  39dc00:	48 89 8b e0 00 00 00 	mov    %rcx,0xe0(%rbx)
  39dc07:	48 8d 8f 90 01 00 00 	lea    0x190(%rdi),%rcx
  39dc0e:	48 89 8b d0 01 00 00 	mov    %rcx,0x1d0(%rbx)
  39dc15:	48 8d 8f a0 01 00 00 	lea    0x1a0(%rdi),%rcx
  39dc1c:	48 89 8b 00 01 00 00 	mov    %rcx,0x100(%rbx)
  39dc23:	48 8d 8f b0 01 00 00 	lea    0x1b0(%rdi),%rcx
  39dc2a:	48 89 8b 18 01 00 00 	mov    %rcx,0x118(%rbx)
  39dc31:	48 8d 8f c0 01 00 00 	lea    0x1c0(%rdi),%rcx
  39dc38:	48 89 8b e8 01 00 00 	mov    %rcx,0x1e8(%rbx)
  39dc3f:	48 8d 8f e0 01 00 00 	lea    0x1e0(%rdi),%rcx
  39dc46:	48 89 8b d8 01 00 00 	mov    %rcx,0x1d8(%rbx)
  39dc4d:	48 8d 8f f0 02 00 00 	lea    0x2f0(%rdi),%rcx
  39dc54:	48 89 8b e0 01 00 00 	mov    %rcx,0x1e0(%rbx)
  39dc5b:	48 8d 8f 00 04 00 00 	lea    0x400(%rdi),%rcx
  39dc62:	48 89 8b c0 00 00 00 	mov    %rcx,0xc0(%rbx)
  39dc69:	4a 8d 0c 20          	lea    (%rax,%r12,1),%rcx
  39dc6d:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
  39dc74:	48 8d 0c 16          	lea    (%rsi,%rdx,1),%rcx
  39dc78:	48 ff c1             	inc    %rcx
  39dc7b:	48 89 8b d0 00 00 00 	mov    %rcx,0xd0(%rbx)
  39dc82:	45 31 ed             	xor    %r13d,%r13d
  39dc85:	45 31 ff             	xor    %r15d,%r15d
  39dc88:	49 89 c4             	mov    %rax,%r12
  39dc8b:	31 ff                	xor    %edi,%edi
  39dc8d:	4c 89 fe             	mov    %r15,%rsi
  39dc90:	e8 db c8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39dc95:	31 ff                	xor    %edi,%edi
  39dc97:	4c 89 fe             	mov    %r15,%rsi
  39dc9a:	e8 d1 c8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39dc9f:	4c 89 7b 28          	mov    %r15,0x28(%rbx)
  39dca3:	4d 85 ff             	test   %r15,%r15
  39dca6:	0f 95 43 17          	setne  0x17(%rbx)
  39dcaa:	48 83 bb f8 00 00 00 	cmpq   $0x2,0xf8(%rbx)
  39dcb1:	02 
  39dcb2:	0f 82 68 01 00 00    	jb     39de20 <<oriole::Parser>::parse_text+0x17f0>
  39dcb8:	4d 89 ee             	mov    %r13,%r14
  39dcbb:	4d 89 e7             	mov    %r12,%r15
  39dcbe:	4c 3b bb b0 00 00 00 	cmp    0xb0(%rbx),%r15
  39dcc5:	0f 84 8d 06 00 00    	je     39e358 <<oriole::Parser>::parse_text+0x1d28>
  39dccb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  39dcd0:	4c 89 e0             	mov    %r12,%rax
  39dcd3:	48 c1 e8 03          	shr    $0x3,%rax
  39dcd7:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39dcde:	7f 
  39dcdf:	31 ff                	xor    %edi,%edi
  39dce1:	44 89 ee             	mov    %r13d,%esi
  39dce4:	e8 f7 cb 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39dce9:	45 85 ed             	test   %r13d,%r13d
  39dcec:	4c 89 63 70          	mov    %r12,0x70(%rbx)
  39dcf0:	0f 85 03 01 00 00    	jne    39ddf9 <<oriole::Parser>::parse_text+0x17c9>
  39dcf6:	fe 05 14 a8 24 00    	incb   0x24a814(%rip)        # 5e8510 <__start___sancov_cntrs+0x70f0>
  39dcfc:	45 0f b6 2f          	movzbl (%r15),%r13d
  39dd00:	4c 89 ef             	mov    %r13,%rdi
  39dd03:	48 8d 35 e6 46 22 00 	lea    0x2246e6(%rip),%rsi        # 5c23f0 <__sancov_gen_cov_switch_values.2885>
  39dd0a:	e8 61 cc 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  39dd0f:	41 83 fd 0a          	cmp    $0xa,%r13d
  39dd13:	4c 89 7b 08          	mov    %r15,0x8(%rbx)
  39dd17:	74 27                	je     39dd40 <<oriole::Parser>::parse_text+0x1710>
  39dd19:	41 83 fd 3c          	cmp    $0x3c,%r13d
  39dd1d:	74 11                	je     39dd30 <<oriole::Parser>::parse_text+0x1700>
  39dd1f:	41 83 fd 26          	cmp    $0x26,%r13d
  39dd23:	75 4b                	jne    39dd70 <<oriole::Parser>::parse_text+0x1740>
  39dd25:	fe 05 e8 a7 24 00    	incb   0x24a7e8(%rip)        # 5e8513 <__start___sancov_cntrs+0x70f3>
  39dd2b:	eb 09                	jmp    39dd36 <<oriole::Parser>::parse_text+0x1706>
  39dd2d:	0f 1f 00             	nopl   (%rax)
  39dd30:	fe 05 de a7 24 00    	incb   0x24a7de(%rip)        # 5e8514 <__start___sancov_cntrs+0x70f4>
  39dd36:	41 b7 01             	mov    $0x1,%r15b
  39dd39:	4d 89 f4             	mov    %r14,%r12
  39dd3c:	eb 74                	jmp    39ddb2 <<oriole::Parser>::parse_text+0x1782>
  39dd3e:	66 90                	xchg   %ax,%ax
  39dd40:	80 bb a8 00 00 00 00 	cmpb   $0x0,0xa8(%rbx)
  39dd47:	74 55                	je     39dd9e <<oriole::Parser>::parse_text+0x176e>
  39dd49:	4d 89 fc             	mov    %r15,%r12
  39dd4c:	bf ff ff 00 00       	mov    $0xffff,%edi
  39dd51:	4c 89 f6             	mov    %r14,%rsi
  39dd54:	e8 17 c8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39dd59:	49 81 fe ff ff 00 00 	cmp    $0xffff,%r14
  39dd60:	0f 86 24 05 00 00    	jbe    39e28a <<oriole::Parser>::parse_text+0x1c5a>
  39dd66:	fe 05 ad a7 24 00    	incb   0x24a7ad(%rip)        # 5e8519 <__start___sancov_cntrs+0x70f9>
  39dd6c:	eb 36                	jmp    39dda4 <<oriole::Parser>::parse_text+0x1774>
  39dd6e:	66 90                	xchg   %ax,%ax
  39dd70:	4d 89 fc             	mov    %r15,%r12
  39dd73:	bf ff ff 00 00       	mov    $0xffff,%edi
  39dd78:	4c 89 f6             	mov    %r14,%rsi
  39dd7b:	e8 f0 c7 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39dd80:	49 81 fe ff ff 00 00 	cmp    $0xffff,%r14
  39dd87:	0f 86 4a 04 00 00    	jbe    39e1d7 <<oriole::Parser>::parse_text+0x1ba7>
  39dd8d:	fe 05 83 a7 24 00    	incb   0x24a783(%rip)        # 5e8516 <__start___sancov_cntrs+0x70f6>
  39dd93:	4c 8b 63 28          	mov    0x28(%rbx),%r12
  39dd97:	44 0f b6 7b 17       	movzbl 0x17(%rbx),%r15d
  39dd9c:	eb 14                	jmp    39ddb2 <<oriole::Parser>::parse_text+0x1782>
  39dd9e:	fe 05 73 a7 24 00    	incb   0x24a773(%rip)        # 5e8517 <__start___sancov_cntrs+0x70f7>
  39dda4:	4c 8b 63 28          	mov    0x28(%rbx),%r12
  39dda8:	4d 85 e4             	test   %r12,%r12
  39ddab:	4d 0f 44 e6          	cmove  %r14,%r12
  39ddaf:	41 b7 01             	mov    $0x1,%r15b
  39ddb2:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  39ddb9:	4c 89 f6             	mov    %r14,%rsi
  39ddbc:	e8 af c7 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39ddc1:	49 ff c6             	inc    %r14
  39ddc4:	0f 84 e7 22 00 00    	je     3a00b1 <<oriole::Parser>::parse_text+0x3a81>
  39ddca:	45 84 ff             	test   %r15b,%r15b
  39ddcd:	0f 85 8d 05 00 00    	jne    39e360 <<oriole::Parser>::parse_text+0x1d30>
  39ddd3:	4c 8b 7b 08          	mov    0x8(%rbx),%r15
  39ddd7:	49 ff c7             	inc    %r15
  39ddda:	fe 05 3b a7 24 00    	incb   0x24a73b(%rip)        # 5e851b <__start___sancov_cntrs+0x70fb>
  39dde0:	4c 8b 63 70          	mov    0x70(%rbx),%r12
  39dde4:	49 ff c4             	inc    %r12
  39dde7:	4c 3b bb b0 00 00 00 	cmp    0xb0(%rbx),%r15
  39ddee:	0f 85 dc fe ff ff    	jne    39dcd0 <<oriole::Parser>::parse_text+0x16a0>
  39ddf4:	e9 5f 05 00 00       	jmp    39e358 <<oriole::Parser>::parse_text+0x1d28>
  39ddf9:	41 83 e4 07          	and    $0x7,%r12d
  39ddfd:	45 0f b6 ed          	movzbl %r13b,%r13d
  39de01:	44 89 e7             	mov    %r12d,%edi
  39de04:	44 89 ee             	mov    %r13d,%esi
  39de07:	e8 44 ca 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39de0c:	45 38 ec             	cmp    %r13b,%r12b
  39de0f:	0f 8d c8 46 00 00    	jge    3a24dd <<oriole::Parser>::parse_text+0x5ead>
  39de15:	fe 05 f6 a6 24 00    	incb   0x24a6f6(%rip)        # 5e8511 <__start___sancov_cntrs+0x70f1>
  39de1b:	e9 dc fe ff ff       	jmp    39dcfc <<oriole::Parser>::parse_text+0x16cc>
  39de20:	80 bb a8 00 00 00 00 	cmpb   $0x0,0xa8(%rbx)
  39de27:	4d 89 e7             	mov    %r12,%r15
  39de2a:	0f 84 90 01 00 00    	je     39dfc0 <<oriole::Parser>::parse_text+0x1990>
  39de30:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
  39de34:	4c 89 7b 08          	mov    %r15,0x8(%rbx)
  39de38:	45 31 ff             	xor    %r15d,%r15d
  39de3b:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  39de3f:	4e 8d 34 39          	lea    (%rcx,%r15,1),%r14
  39de43:	4c 3b b3 b0 00 00 00 	cmp    0xb0(%rbx),%r14
  39de4a:	0f 84 1e 05 00 00    	je     39e36e <<oriole::Parser>::parse_text+0x1d3e>
  39de50:	4c 89 f0             	mov    %r14,%rax
  39de53:	48 c1 e8 03          	shr    $0x3,%rax
  39de57:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39de5e:	7f 
  39de5f:	31 ff                	xor    %edi,%edi
  39de61:	44 89 ee             	mov    %r13d,%esi
  39de64:	e8 77 ca 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39de69:	45 85 ed             	test   %r13d,%r13d
  39de6c:	0f 85 16 01 00 00    	jne    39df88 <<oriole::Parser>::parse_text+0x1958>
  39de72:	fe 05 a6 a6 24 00    	incb   0x24a6a6(%rip)        # 5e851e <__start___sancov_cntrs+0x70fe>
  39de78:	48 8b 43 70          	mov    0x70(%rbx),%rax
  39de7c:	4e 8d 2c 38          	lea    (%rax,%r15,1),%r13
  39de80:	4e 8d 24 38          	lea    (%rax,%r15,1),%r12
  39de84:	49 ff c4             	inc    %r12
  39de87:	41 0f b6 06          	movzbl (%r14),%eax
  39de8b:	44 0f b6 f0          	movzbl %al,%r14d
  39de8f:	4c 89 f7             	mov    %r14,%rdi
  39de92:	48 8d 35 87 45 22 00 	lea    0x224587(%rip),%rsi        # 5c2420 <__sancov_gen_cov_switch_values.2886>
  39de99:	e8 d2 ca 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  39de9e:	41 83 fe 25          	cmp    $0x25,%r14d
  39dea2:	7f 1c                	jg     39dec0 <<oriole::Parser>::parse_text+0x1890>
  39dea4:	41 83 fe 0a          	cmp    $0xa,%r14d
  39dea8:	74 58                	je     39df02 <<oriole::Parser>::parse_text+0x18d2>
  39deaa:	41 83 fe 0d          	cmp    $0xd,%r14d
  39deae:	75 24                	jne    39ded4 <<oriole::Parser>::parse_text+0x18a4>
  39deb0:	fe 05 6b a6 24 00    	incb   0x24a66b(%rip)        # 5e8521 <__start___sancov_cntrs+0x7101>
  39deb6:	eb 50                	jmp    39df08 <<oriole::Parser>::parse_text+0x18d8>
  39deb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  39debf:	00 
  39dec0:	41 83 fe 26          	cmp    $0x26,%r14d
  39dec4:	74 75                	je     39df3b <<oriole::Parser>::parse_text+0x190b>
  39dec6:	41 83 fe 3c          	cmp    $0x3c,%r14d
  39deca:	75 08                	jne    39ded4 <<oriole::Parser>::parse_text+0x18a4>
  39decc:	fe 05 52 a6 24 00    	incb   0x24a652(%rip)        # 5e8524 <__start___sancov_cntrs+0x7104>
  39ded2:	eb 6d                	jmp    39df41 <<oriole::Parser>::parse_text+0x1911>
  39ded4:	bf ff ff 00 00       	mov    $0xffff,%edi
  39ded9:	4c 89 ee             	mov    %r13,%rsi
  39dedc:	e8 8f c6 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39dee1:	49 81 fd ff ff 00 00 	cmp    $0xffff,%r13
  39dee8:	0f 86 b8 03 00 00    	jbe    39e2a6 <<oriole::Parser>::parse_text+0x1c76>
  39deee:	fe 05 33 a6 24 00    	incb   0x24a633(%rip)        # 5e8527 <__start___sancov_cntrs+0x7107>
  39def4:	4c 89 ee             	mov    %r13,%rsi
  39def7:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  39defb:	44 0f b6 73 17       	movzbl 0x17(%rbx),%r14d
  39df00:	eb 45                	jmp    39df47 <<oriole::Parser>::parse_text+0x1917>
  39df02:	fe 05 1a a6 24 00    	incb   0x24a61a(%rip)        # 5e8522 <__start___sancov_cntrs+0x7102>
  39df08:	bf ff ff 00 00       	mov    $0xffff,%edi
  39df0d:	4c 89 ee             	mov    %r13,%rsi
  39df10:	e8 5b c6 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39df15:	49 81 fd 00 00 01 00 	cmp    $0x10000,%r13
  39df1c:	0f 82 cd 02 00 00    	jb     39e1ef <<oriole::Parser>::parse_text+0x1bbf>
  39df22:	fe 05 fd a5 24 00    	incb   0x24a5fd(%rip)        # 5e8525 <__start___sancov_cntrs+0x7105>
  39df28:	4c 89 ee             	mov    %r13,%rsi
  39df2b:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  39df2f:	4d 85 ed             	test   %r13,%r13
  39df32:	4c 0f 44 ee          	cmove  %rsi,%r13
  39df36:	41 b6 01             	mov    $0x1,%r14b
  39df39:	eb 0c                	jmp    39df47 <<oriole::Parser>::parse_text+0x1917>
  39df3b:	fe 05 e2 a5 24 00    	incb   0x24a5e2(%rip)        # 5e8523 <__start___sancov_cntrs+0x7103>
  39df41:	41 b6 01             	mov    $0x1,%r14b
  39df44:	4c 89 ee             	mov    %r13,%rsi
  39df47:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  39df4e:	e8 1d c6 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39df53:	4d 85 e4             	test   %r12,%r12
  39df56:	0f 84 a7 21 00 00    	je     3a0103 <<oriole::Parser>::parse_text+0x3ad3>
  39df5c:	45 84 f6             	test   %r14b,%r14b
  39df5f:	0f 85 11 04 00 00    	jne    39e376 <<oriole::Parser>::parse_text+0x1d46>
  39df65:	fe 05 be a5 24 00    	incb   0x24a5be(%rip)        # 5e8529 <__start___sancov_cntrs+0x7109>
  39df6b:	49 ff c7             	inc    %r15
  39df6e:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  39df72:	4e 8d 34 39          	lea    (%rcx,%r15,1),%r14
  39df76:	4c 3b b3 b0 00 00 00 	cmp    0xb0(%rbx),%r14
  39df7d:	0f 85 cd fe ff ff    	jne    39de50 <<oriole::Parser>::parse_text+0x1820>
  39df83:	e9 e6 03 00 00       	jmp    39e36e <<oriole::Parser>::parse_text+0x1d3e>
  39df88:	45 89 f4             	mov    %r14d,%r12d
  39df8b:	41 83 e4 07          	and    $0x7,%r12d
  39df8f:	45 0f b6 ed          	movzbl %r13b,%r13d
  39df93:	44 89 e7             	mov    %r12d,%edi
  39df96:	44 89 ee             	mov    %r13d,%esi
  39df99:	e8 b2 c8 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39df9e:	45 38 ec             	cmp    %r13b,%r12b
  39dfa1:	0f 8d 47 45 00 00    	jge    3a24ee <<oriole::Parser>::parse_text+0x5ebe>
  39dfa7:	fe 05 72 a5 24 00    	incb   0x24a572(%rip)        # 5e851f <__start___sancov_cntrs+0x70ff>
  39dfad:	e9 c6 fe ff ff       	jmp    39de78 <<oriole::Parser>::parse_text+0x1848>
  39dfb2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  39dfb9:	1f 84 00 00 00 00 00 
  39dfc0:	48 83 7b 28 00       	cmpq   $0x0,0x28(%rbx)
  39dfc5:	74 6e                	je     39e035 <<oriole::Parser>::parse_text+0x1a05>
  39dfc7:	4c 3b bb b0 00 00 00 	cmp    0xb0(%rbx),%r15
  39dfce:	0f 84 c7 03 00 00    	je     39e39b <<oriole::Parser>::parse_text+0x1d6b>
  39dfd4:	4c 89 f8             	mov    %r15,%rax
  39dfd7:	48 c1 e8 03          	shr    $0x3,%rax
  39dfdb:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39dfe2:	7f 
  39dfe3:	31 ff                	xor    %edi,%edi
  39dfe5:	44 89 f6             	mov    %r14d,%esi
  39dfe8:	e8 f3 c8 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39dfed:	45 85 f6             	test   %r14d,%r14d
  39dff0:	0f 85 07 03 00 00    	jne    39e2fd <<oriole::Parser>::parse_text+0x1ccd>
  39dff6:	fe 05 3d a5 24 00    	incb   0x24a53d(%rip)        # 5e8539 <__start___sancov_cntrs+0x7119>
  39dffc:	4d 89 fc             	mov    %r15,%r12
  39dfff:	45 0f b6 3f          	movzbl (%r15),%r15d
  39e003:	4c 89 ff             	mov    %r15,%rdi
  39e006:	48 8d 35 73 44 22 00 	lea    0x224473(%rip),%rsi        # 5c2480 <__sancov_gen_cov_switch_values.2888>
  39e00d:	e8 5e c9 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  39e012:	41 83 ff 25          	cmp    $0x25,%r15d
  39e016:	0f 8f 82 01 00 00    	jg     39e19e <<oriole::Parser>::parse_text+0x1b6e>
  39e01c:	41 83 ff 0a          	cmp    $0xa,%r15d
  39e020:	0f 84 93 03 00 00    	je     39e3b9 <<oriole::Parser>::parse_text+0x1d89>
  39e026:	41 83 ff 0d          	cmp    $0xd,%r15d
  39e02a:	0f 85 82 01 00 00    	jne    39e1b2 <<oriole::Parser>::parse_text+0x1b82>
  39e030:	e9 71 03 00 00       	jmp    39e3a6 <<oriole::Parser>::parse_text+0x1d76>
  39e035:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
  39e039:	4d 89 fe             	mov    %r15,%r14
  39e03c:	4c 3b bb b0 00 00 00 	cmp    0xb0(%rbx),%r15
  39e043:	0f 84 35 03 00 00    	je     39e37e <<oriole::Parser>::parse_text+0x1d4e>
  39e049:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  39e050:	4c 89 f0             	mov    %r14,%rax
  39e053:	48 c1 e8 03          	shr    $0x3,%rax
  39e057:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39e05e:	7f 
  39e05f:	31 ff                	xor    %edi,%edi
  39e061:	44 89 ee             	mov    %r13d,%esi
  39e064:	e8 77 c8 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e069:	45 85 ed             	test   %r13d,%r13d
  39e06c:	0f 85 f3 00 00 00    	jne    39e165 <<oriole::Parser>::parse_text+0x1b35>
  39e072:	fe 05 b4 a4 24 00    	incb   0x24a4b4(%rip)        # 5e852c <__start___sancov_cntrs+0x710c>
  39e078:	45 0f b6 2f          	movzbl (%r15),%r13d
  39e07c:	4c 89 ef             	mov    %r13,%rdi
  39e07f:	48 8d 35 ca 43 22 00 	lea    0x2243ca(%rip),%rsi        # 5c2450 <__sancov_gen_cov_switch_values.2887>
  39e086:	e8 e5 c8 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  39e08b:	41 83 fd 25          	cmp    $0x25,%r13d
  39e08f:	4c 89 73 08          	mov    %r14,0x8(%rbx)
  39e093:	7f 1b                	jg     39e0b0 <<oriole::Parser>::parse_text+0x1a80>
  39e095:	41 83 fd 0a          	cmp    $0xa,%r13d
  39e099:	74 62                	je     39e0fd <<oriole::Parser>::parse_text+0x1acd>
  39e09b:	41 83 fd 0d          	cmp    $0xd,%r13d
  39e09f:	75 26                	jne    39e0c7 <<oriole::Parser>::parse_text+0x1a97>
  39e0a1:	4d 89 fe             	mov    %r15,%r14
  39e0a4:	fe 05 85 a4 24 00    	incb   0x24a485(%rip)        # 5e852f <__start___sancov_cntrs+0x710f>
  39e0aa:	eb 65                	jmp    39e111 <<oriole::Parser>::parse_text+0x1ae1>
  39e0ac:	0f 1f 40 00          	nopl   0x0(%rax)
  39e0b0:	41 83 fd 26          	cmp    $0x26,%r13d
  39e0b4:	74 52                	je     39e108 <<oriole::Parser>::parse_text+0x1ad8>
  39e0b6:	41 83 fd 3c          	cmp    $0x3c,%r13d
  39e0ba:	75 0b                	jne    39e0c7 <<oriole::Parser>::parse_text+0x1a97>
  39e0bc:	4d 89 fe             	mov    %r15,%r14
  39e0bf:	fe 05 6d a4 24 00    	incb   0x24a46d(%rip)        # 5e8532 <__start___sancov_cntrs+0x7112>
  39e0c5:	eb 4a                	jmp    39e111 <<oriole::Parser>::parse_text+0x1ae1>
  39e0c7:	4d 89 fc             	mov    %r15,%r12
  39e0ca:	bf ff ff 00 00       	mov    $0xffff,%edi
  39e0cf:	4c 8b 7b 70          	mov    0x70(%rbx),%r15
  39e0d3:	4c 89 fe             	mov    %r15,%rsi
  39e0d6:	e8 95 c4 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e0db:	49 81 ff ff ff 00 00 	cmp    $0xffff,%r15
  39e0e2:	0f 86 fd 01 00 00    	jbe    39e2e5 <<oriole::Parser>::parse_text+0x1cb5>
  39e0e8:	4d 89 e6             	mov    %r12,%r14
  39e0eb:	fe 05 43 a4 24 00    	incb   0x24a443(%rip)        # 5e8534 <__start___sancov_cntrs+0x7114>
  39e0f1:	45 31 e4             	xor    %r12d,%r12d
  39e0f4:	45 31 ff             	xor    %r15d,%r15d
  39e0f7:	4c 8b 6b 70          	mov    0x70(%rbx),%r13
  39e0fb:	eb 1e                	jmp    39e11b <<oriole::Parser>::parse_text+0x1aeb>
  39e0fd:	4d 89 fe             	mov    %r15,%r14
  39e100:	fe 05 2a a4 24 00    	incb   0x24a42a(%rip)        # 5e8530 <__start___sancov_cntrs+0x7110>
  39e106:	eb 09                	jmp    39e111 <<oriole::Parser>::parse_text+0x1ae1>
  39e108:	4d 89 fe             	mov    %r15,%r14
  39e10b:	fe 05 20 a4 24 00    	incb   0x24a420(%rip)        # 5e8531 <__start___sancov_cntrs+0x7111>
  39e111:	41 b7 01             	mov    $0x1,%r15b
  39e114:	4c 8b 6b 70          	mov    0x70(%rbx),%r13
  39e118:	4d 89 ec             	mov    %r13,%r12
  39e11b:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  39e122:	4c 89 ee             	mov    %r13,%rsi
  39e125:	e8 46 c4 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e12a:	49 ff c5             	inc    %r13
  39e12d:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
  39e131:	0f 84 05 20 00 00    	je     3a013c <<oriole::Parser>::parse_text+0x3b0c>
  39e137:	45 84 ff             	test   %r15b,%r15b
  39e13a:	0f 85 50 02 00 00    	jne    39e390 <<oriole::Parser>::parse_text+0x1d60>
  39e140:	4d 89 f7             	mov    %r14,%r15
  39e143:	49 ff c7             	inc    %r15
  39e146:	fe 05 ea a3 24 00    	incb   0x24a3ea(%rip)        # 5e8536 <__start___sancov_cntrs+0x7116>
  39e14c:	4c 8b 73 08          	mov    0x8(%rbx),%r14
  39e150:	49 ff c6             	inc    %r14
  39e153:	4c 3b bb b0 00 00 00 	cmp    0xb0(%rbx),%r15
  39e15a:	0f 85 f0 fe ff ff    	jne    39e050 <<oriole::Parser>::parse_text+0x1a20>
  39e160:	e9 19 02 00 00       	jmp    39e37e <<oriole::Parser>::parse_text+0x1d4e>
  39e165:	4c 89 f0             	mov    %r14,%rax
  39e168:	4d 89 fe             	mov    %r15,%r14
  39e16b:	49 89 c4             	mov    %rax,%r12
  39e16e:	41 89 c7             	mov    %eax,%r15d
  39e171:	41 83 e7 07          	and    $0x7,%r15d
  39e175:	45 0f b6 ed          	movzbl %r13b,%r13d
  39e179:	44 89 ff             	mov    %r15d,%edi
  39e17c:	44 89 ee             	mov    %r13d,%esi
  39e17f:	e8 cc c6 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39e184:	45 38 ef             	cmp    %r13b,%r15b
  39e187:	0f 8d 20 43 00 00    	jge    3a24ad <<oriole::Parser>::parse_text+0x5e7d>
  39e18d:	fe 05 9a a3 24 00    	incb   0x24a39a(%rip)        # 5e852d <__start___sancov_cntrs+0x710d>
  39e193:	4d 89 f7             	mov    %r14,%r15
  39e196:	4d 89 e6             	mov    %r12,%r14
  39e199:	e9 da fe ff ff       	jmp    39e078 <<oriole::Parser>::parse_text+0x1a48>
  39e19e:	41 83 ff 26          	cmp    $0x26,%r15d
  39e1a2:	0f 84 06 02 00 00    	je     39e3ae <<oriole::Parser>::parse_text+0x1d7e>
  39e1a8:	41 83 ff 3c          	cmp    $0x3c,%r15d
  39e1ac:	0f 84 0f 02 00 00    	je     39e3c1 <<oriole::Parser>::parse_text+0x1d91>
  39e1b2:	bf ff ff 00 00       	mov    $0xffff,%edi
  39e1b7:	4c 89 ee             	mov    %r13,%rsi
  39e1ba:	e8 b1 c3 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e1bf:	49 81 fd ff ff 00 00 	cmp    $0xffff,%r13
  39e1c6:	0f 87 00 02 00 00    	ja     39e3cc <<oriole::Parser>::parse_text+0x1d9c>
  39e1cc:	49 ff c4             	inc    %r12
  39e1cf:	fe 05 6b a3 24 00    	incb   0x24a36b(%rip)        # 5e8540 <__start___sancov_cntrs+0x7120>
  39e1d5:	eb 0c                	jmp    39e1e3 <<oriole::Parser>::parse_text+0x1bb3>
  39e1d7:	fe 05 38 a3 24 00    	incb   0x24a338(%rip)        # 5e8515 <__start___sancov_cntrs+0x70f5>
  39e1dd:	49 ff c4             	inc    %r12
  39e1e0:	4d 89 f5             	mov    %r14,%r13
  39e1e3:	49 ff c5             	inc    %r13
  39e1e6:	4c 8b 7b 28          	mov    0x28(%rbx),%r15
  39e1ea:	e9 9c fa ff ff       	jmp    39dc8b <<oriole::Parser>::parse_text+0x165b>
  39e1ef:	bf 0d 00 00 00       	mov    $0xd,%edi
  39e1f4:	44 89 f6             	mov    %r14d,%esi
  39e1f7:	e8 e4 c6 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e1fc:	48 8b 43 70          	mov    0x70(%rbx),%rax
  39e200:	4e 8d 2c 38          	lea    (%rax,%r15,1),%r13
  39e204:	48 8b 43 08          	mov    0x8(%rbx),%rax
  39e208:	4c 01 f8             	add    %r15,%rax
  39e20b:	48 ff c0             	inc    %rax
  39e20e:	48 89 43 08          	mov    %rax,0x8(%rbx)
  39e212:	41 80 fe 0d          	cmp    $0xd,%r14b
  39e216:	0f 85 82 00 00 00    	jne    39e29e <<oriole::Parser>::parse_text+0x1c6e>
  39e21c:	4c 89 e7             	mov    %r12,%rdi
  39e21f:	4c 8b 73 18          	mov    0x18(%rbx),%r14
  39e223:	4c 89 f6             	mov    %r14,%rsi
  39e226:	e8 a5 c2 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39e22b:	4d 39 f4             	cmp    %r14,%r12
  39e22e:	0f 83 96 00 00 00    	jae    39e2ca <<oriole::Parser>::parse_text+0x1c9a>
  39e234:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
  39e23b:	48 8b 4b 70          	mov    0x70(%rbx),%rcx
  39e23f:	4c 8d 24 08          	lea    (%rax,%rcx,1),%r12
  39e243:	4b 8d 04 3c          	lea    (%r12,%r15,1),%rax
  39e247:	48 c1 e8 03          	shr    $0x3,%rax
  39e24b:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39e252:	7f 
  39e253:	31 ff                	xor    %edi,%edi
  39e255:	44 89 f6             	mov    %r14d,%esi
  39e258:	e8 83 c6 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e25d:	45 85 f6             	test   %r14d,%r14d
  39e260:	0f 85 c6 00 00 00    	jne    39e32c <<oriole::Parser>::parse_text+0x1cfc>
  39e266:	fe 05 d8 a2 24 00    	incb   0x24a2d8(%rip)        # 5e8544 <__start___sancov_cntrs+0x7124>
  39e26c:	43 0f b6 34 3c       	movzbl (%r12,%r15,1),%esi
  39e271:	45 31 ff             	xor    %r15d,%r15d
  39e274:	83 fe 0a             	cmp    $0xa,%esi
  39e277:	41 0f 94 c7          	sete   %r15b
  39e27b:	bf 0a 00 00 00       	mov    $0xa,%edi
  39e280:	e8 5b c6 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e285:	49 ff c7             	inc    %r15
  39e288:	eb 4c                	jmp    39e2d6 <<oriole::Parser>::parse_text+0x1ca6>
  39e28a:	fe 05 88 a2 24 00    	incb   0x24a288(%rip)        # 5e8518 <__start___sancov_cntrs+0x70f8>
  39e290:	49 ff c4             	inc    %r12
  39e293:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  39e299:	4d 89 f5             	mov    %r14,%r13
  39e29c:	eb 3c                	jmp    39e2da <<oriole::Parser>::parse_text+0x1caa>
  39e29e:	fe 05 9e a2 24 00    	incb   0x24a29e(%rip)        # 5e8542 <__start___sancov_cntrs+0x7122>
  39e2a4:	eb 2a                	jmp    39e2d0 <<oriole::Parser>::parse_text+0x1ca0>
  39e2a6:	fe 05 7a a2 24 00    	incb   0x24a27a(%rip)        # 5e8526 <__start___sancov_cntrs+0x7106>
  39e2ac:	4c 8b 6b 70          	mov    0x70(%rbx),%r13
  39e2b0:	4d 01 fd             	add    %r15,%r13
  39e2b3:	4c 8b 73 08          	mov    0x8(%rbx),%r14
  39e2b7:	4f 8d 24 3e          	lea    (%r14,%r15,1),%r12
  39e2bb:	49 ff c4             	inc    %r12
  39e2be:	4c 8b 7b 28          	mov    0x28(%rbx),%r15
  39e2c2:	49 ff c5             	inc    %r13
  39e2c5:	e9 c1 f9 ff ff       	jmp    39dc8b <<oriole::Parser>::parse_text+0x165b>
  39e2ca:	fe 05 73 a2 24 00    	incb   0x24a273(%rip)        # 5e8543 <__start___sancov_cntrs+0x7123>
  39e2d0:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  39e2d6:	4c 8b 63 08          	mov    0x8(%rbx),%r12
  39e2da:	4d 01 ef             	add    %r13,%r15
  39e2dd:	49 ff c5             	inc    %r13
  39e2e0:	e9 a6 f9 ff ff       	jmp    39dc8b <<oriole::Parser>::parse_text+0x165b>
  39e2e5:	fe 05 48 a2 24 00    	incb   0x24a248(%rip)        # 5e8533 <__start___sancov_cntrs+0x7113>
  39e2eb:	49 ff c4             	inc    %r12
  39e2ee:	4c 8b 6b 70          	mov    0x70(%rbx),%r13
  39e2f2:	49 ff c5             	inc    %r13
  39e2f5:	45 31 ff             	xor    %r15d,%r15d
  39e2f8:	e9 8e f9 ff ff       	jmp    39dc8b <<oriole::Parser>::parse_text+0x165b>
  39e2fd:	4c 89 7b 08          	mov    %r15,0x8(%rbx)
  39e301:	41 83 e7 07          	and    $0x7,%r15d
  39e305:	45 0f b6 f6          	movzbl %r14b,%r14d
  39e309:	44 89 ff             	mov    %r15d,%edi
  39e30c:	44 89 f6             	mov    %r14d,%esi
  39e30f:	e8 3c c5 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39e314:	45 38 f7             	cmp    %r14b,%r15b
  39e317:	0f 8d 71 42 00 00    	jge    3a258e <<oriole::Parser>::parse_text+0x5f5e>
  39e31d:	fe 05 17 a2 24 00    	incb   0x24a217(%rip)        # 5e853a <__start___sancov_cntrs+0x711a>
  39e323:	4c 8b 7b 08          	mov    0x8(%rbx),%r15
  39e327:	e9 d0 fc ff ff       	jmp    39dffc <<oriole::Parser>::parse_text+0x19cc>
  39e32c:	4b 8d 3c 3c          	lea    (%r12,%r15,1),%rdi
  39e330:	83 e7 07             	and    $0x7,%edi
  39e333:	48 89 7b 28          	mov    %rdi,0x28(%rbx)
  39e337:	45 0f b6 f6          	movzbl %r14b,%r14d
  39e33b:	44 89 f6             	mov    %r14d,%esi
  39e33e:	e8 0d c5 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39e343:	44 38 73 28          	cmp    %r14b,0x28(%rbx)
  39e347:	0f 8d 70 41 00 00    	jge    3a24bd <<oriole::Parser>::parse_text+0x5e8d>
  39e34d:	fe 05 f2 a1 24 00    	incb   0x24a1f2(%rip)        # 5e8545 <__start___sancov_cntrs+0x7125>
  39e353:	e9 14 ff ff ff       	jmp    39e26c <<oriole::Parser>::parse_text+0x1c3c>
  39e358:	fe 05 b1 a1 24 00    	incb   0x24a1b1(%rip)        # 5e850f <__start___sancov_cntrs+0x70ef>
  39e35e:	eb 24                	jmp    39e384 <<oriole::Parser>::parse_text+0x1d54>
  39e360:	4d 89 e5             	mov    %r12,%r13
  39e363:	fe 05 b3 a1 24 00    	incb   0x24a1b3(%rip)        # 5e851c <__start___sancov_cntrs+0x70fc>
  39e369:	e9 8a 00 00 00       	jmp    39e3f8 <<oriole::Parser>::parse_text+0x1dc8>
  39e36e:	fe 05 a9 a1 24 00    	incb   0x24a1a9(%rip)        # 5e851d <__start___sancov_cntrs+0x70fd>
  39e374:	eb 0e                	jmp    39e384 <<oriole::Parser>::parse_text+0x1d54>
  39e376:	fe 05 ae a1 24 00    	incb   0x24a1ae(%rip)        # 5e852a <__start___sancov_cntrs+0x710a>
  39e37c:	eb 7a                	jmp    39e3f8 <<oriole::Parser>::parse_text+0x1dc8>
  39e37e:	fe 05 a7 a1 24 00    	incb   0x24a1a7(%rip)        # 5e852b <__start___sancov_cntrs+0x710b>
  39e384:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39e388:	4d 89 e5             	mov    %r12,%r13
  39e38b:	e9 85 00 00 00       	jmp    39e415 <<oriole::Parser>::parse_text+0x1de5>
  39e390:	4d 89 e5             	mov    %r12,%r13
  39e393:	fe 05 9e a1 24 00    	incb   0x24a19e(%rip)        # 5e8537 <__start___sancov_cntrs+0x7117>
  39e399:	eb 5d                	jmp    39e3f8 <<oriole::Parser>::parse_text+0x1dc8>
  39e39b:	fe 05 97 a1 24 00    	incb   0x24a197(%rip)        # 5e8538 <__start___sancov_cntrs+0x7118>
  39e3a1:	e9 b9 05 00 00       	jmp    39e95f <<oriole::Parser>::parse_text+0x232f>
  39e3a6:	fe 05 90 a1 24 00    	incb   0x24a190(%rip)        # 5e853c <__start___sancov_cntrs+0x711c>
  39e3ac:	eb 24                	jmp    39e3d2 <<oriole::Parser>::parse_text+0x1da2>
  39e3ae:	fe 05 8a a1 24 00    	incb   0x24a18a(%rip)        # 5e853e <__start___sancov_cntrs+0x711e>
  39e3b4:	4d 89 ee             	mov    %r13,%r14
  39e3b7:	eb 1d                	jmp    39e3d6 <<oriole::Parser>::parse_text+0x1da6>
  39e3b9:	fe 05 7e a1 24 00    	incb   0x24a17e(%rip)        # 5e853d <__start___sancov_cntrs+0x711d>
  39e3bf:	eb 11                	jmp    39e3d2 <<oriole::Parser>::parse_text+0x1da2>
  39e3c1:	fe 05 78 a1 24 00    	incb   0x24a178(%rip)        # 5e853f <__start___sancov_cntrs+0x711f>
  39e3c7:	4d 89 ee             	mov    %r13,%r14
  39e3ca:	eb 0a                	jmp    39e3d6 <<oriole::Parser>::parse_text+0x1da6>
  39e3cc:	fe 05 6f a1 24 00    	incb   0x24a16f(%rip)        # 5e8541 <__start___sancov_cntrs+0x7121>
  39e3d2:	4c 8b 73 28          	mov    0x28(%rbx),%r14
  39e3d6:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  39e3dd:	4c 89 ee             	mov    %r13,%rsi
  39e3e0:	e8 8b c1 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e3e5:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
  39e3e9:	0f 84 e8 33 00 00    	je     3a17d7 <<oriole::Parser>::parse_text+0x51a7>
  39e3ef:	fe 05 52 a1 24 00    	incb   0x24a152(%rip)        # 5e8547 <__start___sancov_cntrs+0x7127>
  39e3f5:	4d 89 f5             	mov    %r14,%r13
  39e3f8:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39e3fc:	31 ff                	xor    %edi,%edi
  39e3fe:	4c 89 ee             	mov    %r13,%rsi
  39e401:	e8 6a c1 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e406:	4d 85 ed             	test   %r13,%r13
  39e409:	0f 84 ab 01 00 00    	je     39e5ba <<oriole::Parser>::parse_text+0x1f8a>
  39e40f:	fe 05 34 a1 24 00    	incb   0x24a134(%rip)        # 5e8549 <__start___sancov_cntrs+0x7129>
  39e415:	80 bb a8 00 00 00 00 	cmpb   $0x0,0xa8(%rbx)
  39e41c:	0f 84 82 01 00 00    	je     39e5a4 <<oriole::Parser>::parse_text+0x1f74>
  39e422:	4c 89 ef             	mov    %r13,%rdi
  39e425:	4c 89 e6             	mov    %r12,%rsi
  39e428:	e8 a3 c0 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39e42d:	4d 39 e5             	cmp    %r12,%r13
  39e430:	0f 85 79 01 00 00    	jne    39e5af <<oriole::Parser>::parse_text+0x1f7f>
  39e436:	fe 05 1a a1 24 00    	incb   0x24a11a(%rip)        # 5e8556 <__start___sancov_cntrs+0x7136>
  39e43c:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  39e443:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39e44a:	7f 
  39e44b:	31 ff                	xor    %edi,%edi
  39e44d:	44 89 f6             	mov    %r14d,%esi
  39e450:	e8 8b c4 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e455:	45 85 f6             	test   %r14d,%r14d
  39e458:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  39e45c:	0f 85 32 44 00 00    	jne    3a2894 <<oriole::Parser>::parse_text+0x6264>
  39e462:	4c 8b 27             	mov    (%rdi),%r12
  39e465:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  39e46c:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39e473:	7f 
  39e474:	31 ff                	xor    %edi,%edi
  39e476:	44 89 f6             	mov    %r14d,%esi
  39e479:	e8 62 c4 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e47e:	45 85 f6             	test   %r14d,%r14d
  39e481:	0f 85 1a 44 00 00    	jne    3a28a1 <<oriole::Parser>::parse_text+0x6271>
  39e487:	48 8b 43 38          	mov    0x38(%rbx),%rax
  39e48b:	4c 8b 30             	mov    (%rax),%r14
  39e48e:	4c 89 e6             	mov    %r12,%rsi
  39e491:	48 83 e6 07          	and    $0x7,%rsi
  39e495:	31 ff                	xor    %edi,%edi
  39e497:	e8 d4 c0 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e49c:	4c 89 e0             	mov    %r12,%rax
  39e49f:	48 83 e0 07          	and    $0x7,%rax
  39e4a3:	0f 85 dc 1a 00 00    	jne    39ff85 <<oriole::Parser>::parse_text+0x3955>
  39e4a9:	49 bf 55 55 55 55 55 	movabs $0x55555555555555,%r15
  39e4b0:	55 55 00 
  39e4b3:	4c 89 ff             	mov    %r15,%rdi
  39e4b6:	4c 89 f6             	mov    %r14,%rsi
  39e4b9:	e8 b2 c0 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e4be:	4d 39 fe             	cmp    %r15,%r14
  39e4c1:	0f 87 c9 1a 00 00    	ja     39ff90 <<oriole::Parser>::parse_text+0x3960>
  39e4c7:	31 ff                	xor    %edi,%edi
  39e4c9:	4c 89 f6             	mov    %r14,%rsi
  39e4cc:	e8 9f c0 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e4d1:	4d 85 f6             	test   %r14,%r14
  39e4d4:	0f 84 c1 1a 00 00    	je     39ff9b <<oriole::Parser>::parse_text+0x396b>
  39e4da:	4f 8d 2c 76          	lea    (%r14,%r14,2),%r13
  39e4de:	49 c1 e5 07          	shl    $0x7,%r13
  39e4e2:	4b 8d 3c 2c          	lea    (%r12,%r13,1),%rdi
  39e4e6:	48 81 c7 a8 fe ff ff 	add    $0xfffffffffffffea8,%rdi
  39e4ed:	ff 15 35 e1 21 00    	call   *0x21e135(%rip)        # 5bc628 <_GLOBAL_OFFSET_TABLE_+0x880>
  39e4f3:	49 89 c7             	mov    %rax,%r15
  39e4f6:	49 89 d6             	mov    %rdx,%r14
  39e4f9:	4d 01 ec             	add    %r13,%r12
  39e4fc:	49 83 c4 a0          	add    $0xffffffffffffffa0,%r12
  39e500:	4c 89 e0             	mov    %r12,%rax
  39e503:	48 c1 e8 03          	shr    $0x3,%rax
  39e507:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39e50e:	7f 
  39e50f:	31 ff                	xor    %edi,%edi
  39e511:	44 89 ee             	mov    %r13d,%esi
  39e514:	e8 c7 c3 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e519:	45 85 ed             	test   %r13d,%r13d
  39e51c:	0f 85 90 43 00 00    	jne    3a28b2 <<oriole::Parser>::parse_text+0x6282>
  39e522:	4d 8b 24 24          	mov    (%r12),%r12
  39e526:	31 ff                	xor    %edi,%edi
  39e528:	4c 89 e6             	mov    %r12,%rsi
  39e52b:	e8 40 c0 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e530:	4d 85 e4             	test   %r12,%r12
  39e533:	0f 84 f7 00 00 00    	je     39e630 <<oriole::Parser>::parse_text+0x2000>
  39e539:	4c 89 e7             	mov    %r12,%rdi
  39e53c:	4c 89 f6             	mov    %r14,%rsi
  39e53f:	e8 8c bf 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39e544:	4d 39 e6             	cmp    %r12,%r14
  39e547:	0f 86 eb 00 00 00    	jbe    39e638 <<oriole::Parser>::parse_text+0x2008>
  39e54d:	4b 8d 04 27          	lea    (%r15,%r12,1),%rax
  39e551:	48 89 43 08          	mov    %rax,0x8(%rbx)
  39e555:	48 c1 e8 03          	shr    $0x3,%rax
  39e559:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39e560:	7f 
  39e561:	31 ff                	xor    %edi,%edi
  39e563:	44 89 ee             	mov    %r13d,%esi
  39e566:	e8 75 c3 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e56b:	45 85 ed             	test   %r13d,%r13d
  39e56e:	0f 85 ec 2c 00 00    	jne    3a1260 <<oriole::Parser>::parse_text+0x4c30>
  39e574:	fe 05 e6 9f 24 00    	incb   0x249fe6(%rip)        # 5e8560 <__start___sancov_cntrs+0x7140>
  39e57a:	4b 8d 04 27          	lea    (%r15,%r12,1),%rax
  39e57e:	44 0f b6 28          	movzbl (%rax),%r13d
  39e582:	bf bf 00 00 00       	mov    $0xbf,%edi
  39e587:	44 89 ee             	mov    %r13d,%esi
  39e58a:	e8 51 c3 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e58f:	41 80 fd bf          	cmp    $0xbf,%r13b
  39e593:	0f 8e f5 2c 00 00    	jle    3a128e <<oriole::Parser>::parse_text+0x4c5e>
  39e599:	fe 05 c5 9f 24 00    	incb   0x249fc5(%rip)        # 5e8564 <__start___sancov_cntrs+0x7144>
  39e59f:	e9 ae 00 00 00       	jmp    39e652 <<oriole::Parser>::parse_text+0x2022>
  39e5a4:	fe 05 a8 9f 24 00    	incb   0x249fa8(%rip)        # 5e8552 <__start___sancov_cntrs+0x7132>
  39e5aa:	e9 f0 03 00 00       	jmp    39e99f <<oriole::Parser>::parse_text+0x236f>
  39e5af:	fe 05 a0 9f 24 00    	incb   0x249fa0(%rip)        # 5e8555 <__start___sancov_cntrs+0x7135>
  39e5b5:	e9 e5 03 00 00       	jmp    39e99f <<oriole::Parser>::parse_text+0x236f>
  39e5ba:	4d 85 e4             	test   %r12,%r12
  39e5bd:	0f 84 72 1d 00 00    	je     3a0335 <<oriole::Parser>::parse_text+0x3d05>
  39e5c3:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39e5c7:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39e5cb:	48 01 c8             	add    %rcx,%rax
  39e5ce:	48 c1 e8 03          	shr    $0x3,%rax
  39e5d2:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39e5d9:	7f 
  39e5da:	31 ff                	xor    %edi,%edi
  39e5dc:	44 89 f6             	mov    %r14d,%esi
  39e5df:	e8 fc c2 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e5e4:	45 85 f6             	test   %r14d,%r14d
  39e5e7:	0f 85 64 1d 00 00    	jne    3a0351 <<oriole::Parser>::parse_text+0x3d21>
  39e5ed:	fe 05 57 9f 24 00    	incb   0x249f57(%rip)        # 5e854a <__start___sancov_cntrs+0x712a>
  39e5f3:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39e5f7:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39e5fb:	48 01 c8             	add    %rcx,%rax
  39e5fe:	44 0f b6 30          	movzbl (%rax),%r14d
  39e602:	48 8d 35 a7 3e 22 00 	lea    0x223ea7(%rip),%rsi        # 5c24b0 <__sancov_gen_cov_switch_values.2889>
  39e609:	4c 89 f7             	mov    %r14,%rdi
  39e60c:	e8 5f c3 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  39e611:	41 83 fe 0d          	cmp    $0xd,%r14d
  39e615:	0f 84 f2 00 00 00    	je     39e70d <<oriole::Parser>::parse_text+0x20dd>
  39e61b:	41 83 fe 0a          	cmp    $0xa,%r14d
  39e61f:	0f 85 59 01 00 00    	jne    39e77e <<oriole::Parser>::parse_text+0x214e>
  39e625:	fe 05 22 9f 24 00    	incb   0x249f22(%rip)        # 5e854d <__start___sancov_cntrs+0x712d>
  39e62b:	e9 e3 00 00 00       	jmp    39e713 <<oriole::Parser>::parse_text+0x20e3>
  39e630:	fe 05 27 9f 24 00    	incb   0x249f27(%rip)        # 5e855d <__start___sancov_cntrs+0x713d>
  39e636:	eb 34                	jmp    39e66c <<oriole::Parser>::parse_text+0x203c>
  39e638:	4c 89 e7             	mov    %r12,%rdi
  39e63b:	4c 89 f6             	mov    %r14,%rsi
  39e63e:	e8 8d be 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39e643:	4d 39 e6             	cmp    %r12,%r14
  39e646:	0f 85 4d 2c 00 00    	jne    3a1299 <<oriole::Parser>::parse_text+0x4c69>
  39e64c:	fe 05 0d 9f 24 00    	incb   0x249f0d(%rip)        # 5e855f <__start___sancov_cntrs+0x713f>
  39e652:	4c 89 f7             	mov    %r14,%rdi
  39e655:	4c 89 e6             	mov    %r12,%rsi
  39e658:	e8 73 be 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39e65d:	4d 39 e6             	cmp    %r12,%r14
  39e660:	0f 82 66 19 00 00    	jb     39ffcc <<oriole::Parser>::parse_text+0x399c>
  39e666:	fe 05 f9 9e 24 00    	incb   0x249ef9(%rip)        # 5e8565 <__start___sancov_cntrs+0x7145>
  39e66c:	4d 85 ff             	test   %r15,%r15
  39e66f:	0f 84 4d 42 00 00    	je     3a28c2 <<oriole::Parser>::parse_text+0x6292>
  39e675:	4d 29 e6             	sub    %r12,%r14
  39e678:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39e67c:	4c 89 e7             	mov    %r12,%rdi
  39e67f:	4c 89 f6             	mov    %r14,%rsi
  39e682:	e8 49 be 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39e687:	4d 39 f4             	cmp    %r14,%r12
  39e68a:	73 76                	jae    39e702 <<oriole::Parser>::parse_text+0x20d2>
  39e68c:	4d 85 e4             	test   %r12,%r12
  39e68f:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39e693:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39e697:	48 8d 04 08          	lea    (%rax,%rcx,1),%rax
  39e69b:	0f 84 eb 00 00 00    	je     39e78c <<oriole::Parser>::parse_text+0x215c>
  39e6a1:	4e 8d 34 20          	lea    (%rax,%r12,1),%r14
  39e6a5:	49 ff ce             	dec    %r14
  39e6a8:	4c 89 f0             	mov    %r14,%rax
  39e6ab:	48 c1 e8 03          	shr    $0x3,%rax
  39e6af:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39e6b6:	7f 
  39e6b7:	31 ff                	xor    %edi,%edi
  39e6b9:	44 89 fe             	mov    %r15d,%esi
  39e6bc:	e8 1f c2 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e6c1:	45 85 ff             	test   %r15d,%r15d
  39e6c4:	0f 85 da 2b 00 00    	jne    3a12a4 <<oriole::Parser>::parse_text+0x4c74>
  39e6ca:	fe 05 9a 9e 24 00    	incb   0x249e9a(%rip)        # 5e856a <__start___sancov_cntrs+0x714a>
  39e6d0:	4d 8d 7c 24 ff       	lea    -0x1(%r12),%r15
  39e6d5:	45 0f b6 36          	movzbl (%r14),%r14d
  39e6d9:	bf 0d 00 00 00       	mov    $0xd,%edi
  39e6de:	44 89 f6             	mov    %r14d,%esi
  39e6e1:	e8 fa c1 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e6e6:	45 31 ed             	xor    %r13d,%r13d
  39e6e9:	41 83 fe 0d          	cmp    $0xd,%r14d
  39e6ed:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39e6f1:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39e6f5:	48 8d 04 08          	lea    (%rax,%rcx,1),%rax
  39e6f9:	4c 0f 44 e8          	cmove  %rax,%r13
  39e6fd:	e9 93 00 00 00       	jmp    39e795 <<oriole::Parser>::parse_text+0x2165>
  39e702:	fe 05 60 9e 24 00    	incb   0x249e60(%rip)        # 5e8568 <__start___sancov_cntrs+0x7148>
  39e708:	e9 8f 02 00 00       	jmp    39e99c <<oriole::Parser>::parse_text+0x236c>
  39e70d:	fe 05 3b 9e 24 00    	incb   0x249e3b(%rip)        # 5e854e <__start___sancov_cntrs+0x712e>
  39e713:	bf 01 00 00 00       	mov    $0x1,%edi
  39e718:	4c 89 e6             	mov    %r12,%rsi
  39e71b:	e8 50 be 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e720:	49 83 fc 01          	cmp    $0x1,%r12
  39e724:	75 18                	jne    39e73e <<oriole::Parser>::parse_text+0x210e>
  39e726:	80 bb a8 00 00 00 00 	cmpb   $0x0,0xa8(%rbx)
  39e72d:	0f 84 e5 01 00 00    	je     39e918 <<oriole::Parser>::parse_text+0x22e8>
  39e733:	fe 05 1a 9e 24 00    	incb   0x249e1a(%rip)        # 5e8553 <__start___sancov_cntrs+0x7133>
  39e739:	e9 fe fc ff ff       	jmp    39e43c <<oriole::Parser>::parse_text+0x1e0c>
  39e73e:	fe 05 0d 9e 24 00    	incb   0x249e0d(%rip)        # 5e8551 <__start___sancov_cntrs+0x7131>
  39e744:	48 8d 3d b5 0b 1a 00 	lea    0x1a0bb5(%rip),%rdi        # 53f300 <alloc_980705bbcb4b81b075ee5637d0bc8d86>
  39e74b:	ba 02 00 00 00       	mov    $0x2,%edx
  39e750:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39e754:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39e758:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
  39e75c:	ff 15 b6 e3 21 00    	call   *0x21e3b6(%rip)        # 5bcb18 <_GLOBAL_OFFSET_TABLE_+0xd70>
  39e762:	41 89 c6             	mov    %eax,%r14d
  39e765:	45 31 ed             	xor    %r13d,%r13d
  39e768:	31 ff                	xor    %edi,%edi
  39e76a:	89 c6                	mov    %eax,%esi
  39e76c:	e8 2f bf 11 00       	call   4ba6a0 <__sanitizer_cov_trace_const_cmp4>
  39e771:	41 83 fe 01          	cmp    $0x1,%r14d
  39e775:	49 83 d5 01          	adc    $0x1,%r13
  39e779:	e9 97 fc ff ff       	jmp    39e415 <<oriole::Parser>::parse_text+0x1de5>
  39e77e:	fe 05 cb 9d 24 00    	incb   0x249dcb(%rip)        # 5e854f <__start___sancov_cntrs+0x712f>
  39e784:	45 31 ed             	xor    %r13d,%r13d
  39e787:	e9 89 fc ff ff       	jmp    39e415 <<oriole::Parser>::parse_text+0x1de5>
  39e78c:	fe 05 d7 9d 24 00    	incb   0x249dd7(%rip)        # 5e8569 <__start___sancov_cntrs+0x7149>
  39e792:	45 31 ed             	xor    %r13d,%r13d
  39e795:	4d 85 ed             	test   %r13,%r13
  39e798:	4d 0f 44 fc          	cmove  %r12,%r15
  39e79c:	4c 0f 44 e8          	cmove  %rax,%r13
  39e7a0:	31 ff                	xor    %edi,%edi
  39e7a2:	4c 89 fe             	mov    %r15,%rsi
  39e7a5:	e8 c6 bd 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e7aa:	4d 85 ff             	test   %r15,%r15
  39e7ad:	0f 84 b5 00 00 00    	je     39e868 <<oriole::Parser>::parse_text+0x2238>
  39e7b3:	4c 89 f8             	mov    %r15,%rax
  39e7b6:	48 83 bb f8 00 00 00 	cmpq   $0x1,0xf8(%rbx)
  39e7bd:	01 
  39e7be:	0f 86 af 00 00 00    	jbe    39e873 <<oriole::Parser>::parse_text+0x2243>
  39e7c4:	4d 89 ec             	mov    %r13,%r12
  39e7c7:	49 8d 4d ff          	lea    -0x1(%r13),%rcx
  39e7cb:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
  39e7cf:	49 89 c7             	mov    %rax,%r15
  39e7d2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  39e7d9:	1f 84 00 00 00 00 00 
  39e7e0:	4d 89 fd             	mov    %r15,%r13
  39e7e3:	48 8b 43 08          	mov    0x8(%rbx),%rax
  39e7e7:	4e 8d 34 38          	lea    (%rax,%r15,1),%r14
  39e7eb:	4c 89 f0             	mov    %r14,%rax
  39e7ee:	48 c1 e8 03          	shr    $0x3,%rax
  39e7f2:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39e7f9:	7f 
  39e7fa:	31 ff                	xor    %edi,%edi
  39e7fc:	44 89 fe             	mov    %r15d,%esi
  39e7ff:	e8 dc c0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e804:	45 85 ff             	test   %r15d,%r15d
  39e807:	75 3b                	jne    39e844 <<oriole::Parser>::parse_text+0x2214>
  39e809:	fe 05 5f 9d 24 00    	incb   0x249d5f(%rip)        # 5e856e <__start___sancov_cntrs+0x714e>
  39e80f:	4d 89 ef             	mov    %r13,%r15
  39e812:	47 0f b6 74 2c ff    	movzbl -0x1(%r12,%r13,1),%r14d
  39e818:	bf 0a 00 00 00       	mov    $0xa,%edi
  39e81d:	44 89 f6             	mov    %r14d,%esi
  39e820:	e8 bb c0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e825:	41 83 fe 0a          	cmp    $0xa,%r14d
  39e829:	0f 84 1e 01 00 00    	je     39e94d <<oriole::Parser>::parse_text+0x231d>
  39e82f:	49 83 ff 01          	cmp    $0x1,%r15
  39e833:	0f 84 20 01 00 00    	je     39e959 <<oriole::Parser>::parse_text+0x2329>
  39e839:	fe 05 33 9d 24 00    	incb   0x249d33(%rip)        # 5e8572 <__start___sancov_cntrs+0x7152>
  39e83f:	49 ff cf             	dec    %r15
  39e842:	eb 9c                	jmp    39e7e0 <<oriole::Parser>::parse_text+0x21b0>
  39e844:	41 83 e6 07          	and    $0x7,%r14d
  39e848:	45 0f b6 ff          	movzbl %r15b,%r15d
  39e84c:	44 89 f7             	mov    %r14d,%edi
  39e84f:	44 89 fe             	mov    %r15d,%esi
  39e852:	e8 f9 bf 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39e857:	45 38 fe             	cmp    %r15b,%r14b
  39e85a:	0f 8d 20 42 00 00    	jge    3a2a80 <<oriole::Parser>::parse_text+0x6450>
  39e860:	fe 05 09 9d 24 00    	incb   0x249d09(%rip)        # 5e856f <__start___sancov_cntrs+0x714f>
  39e866:	eb a7                	jmp    39e80f <<oriole::Parser>::parse_text+0x21df>
  39e868:	fe 05 ff 9c 24 00    	incb   0x249cff(%rip)        # 5e856d <__start___sancov_cntrs+0x714d>
  39e86e:	e9 29 01 00 00       	jmp    39e99c <<oriole::Parser>::parse_text+0x236c>
  39e873:	4d 89 ee             	mov    %r13,%r14
  39e876:	49 8d 4d ff          	lea    -0x1(%r13),%rcx
  39e87a:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
  39e87e:	66 90                	xchg   %ax,%ax
  39e880:	49 89 c5             	mov    %rax,%r13
  39e883:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  39e887:	4c 8d 3c 01          	lea    (%rcx,%rax,1),%r15
  39e88b:	4c 89 f8             	mov    %r15,%rax
  39e88e:	48 c1 e8 03          	shr    $0x3,%rax
  39e892:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  39e899:	7f 
  39e89a:	31 ff                	xor    %edi,%edi
  39e89c:	44 89 e6             	mov    %r12d,%esi
  39e89f:	e8 3c c0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39e8a4:	45 85 e4             	test   %r12d,%r12d
  39e8a7:	75 4b                	jne    39e8f4 <<oriole::Parser>::parse_text+0x22c4>
  39e8a9:	fe 05 c5 9c 24 00    	incb   0x249cc5(%rip)        # 5e8574 <__start___sancov_cntrs+0x7154>
  39e8af:	47 0f b6 7c 2e ff    	movzbl -0x1(%r14,%r13,1),%r15d
  39e8b5:	4c 89 ff             	mov    %r15,%rdi
  39e8b8:	48 8d 35 11 3c 22 00 	lea    0x223c11(%rip),%rsi        # 5c24d0 <__sancov_gen_cov_switch_values.2890>
  39e8bf:	e8 ac c0 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  39e8c4:	41 83 ff 0a          	cmp    $0xa,%r15d
  39e8c8:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39e8cc:	0f 84 9b 00 00 00    	je     39e96d <<oriole::Parser>::parse_text+0x233d>
  39e8d2:	41 83 ff 0d          	cmp    $0xd,%r15d
  39e8d6:	0f 84 99 00 00 00    	je     39e975 <<oriole::Parser>::parse_text+0x2345>
  39e8dc:	49 83 fd 01          	cmp    $0x1,%r13
  39e8e0:	0f 84 b0 00 00 00    	je     39e996 <<oriole::Parser>::parse_text+0x2366>
  39e8e6:	4c 89 e8             	mov    %r13,%rax
  39e8e9:	fe 05 8a 9c 24 00    	incb   0x249c8a(%rip)        # 5e8579 <__start___sancov_cntrs+0x7159>
  39e8ef:	48 ff c8             	dec    %rax
  39e8f2:	eb 8c                	jmp    39e880 <<oriole::Parser>::parse_text+0x2250>
  39e8f4:	41 83 e7 07          	and    $0x7,%r15d
  39e8f8:	45 0f b6 e4          	movzbl %r12b,%r12d
  39e8fc:	44 89 ff             	mov    %r15d,%edi
  39e8ff:	44 89 e6             	mov    %r12d,%esi
  39e902:	e8 49 bf 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39e907:	45 38 e7             	cmp    %r12b,%r15b
  39e90a:	0f 8d 40 41 00 00    	jge    3a2a50 <<oriole::Parser>::parse_text+0x6420>
  39e910:	fe 05 5f 9c 24 00    	incb   0x249c5f(%rip)        # 5e8575 <__start___sancov_cntrs+0x7155>
  39e916:	eb 97                	jmp    39e8af <<oriole::Parser>::parse_text+0x227f>
  39e918:	80 bb 9c 00 00 00 00 	cmpb   $0x0,0x9c(%rbx)
  39e91f:	74 44                	je     39e965 <<oriole::Parser>::parse_text+0x2335>
  39e921:	fe 05 73 9c 24 00    	incb   0x249c73(%rip)        # 5e859a <__start___sancov_cntrs+0x717a>
  39e927:	be 01 00 00 00       	mov    $0x1,%esi
  39e92c:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  39e933:	e8 48 1b 0a 00       	call   440480 <oriole::names::invalid_xml_char>
  39e938:	48 89 83 d0 00 00 00 	mov    %rax,0xd0(%rbx)
  39e93f:	48 89 d7             	mov    %rdx,%rdi
  39e942:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  39e948:	e9 63 11 00 00       	jmp    39fab0 <<oriole::Parser>::parse_text+0x3480>
  39e94d:	fe 05 1e 9c 24 00    	incb   0x249c1e(%rip)        # 5e8571 <__start___sancov_cntrs+0x7151>
  39e953:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39e957:	eb 22                	jmp    39e97b <<oriole::Parser>::parse_text+0x234b>
  39e959:	fe 05 14 9c 24 00    	incb   0x249c14(%rip)        # 5e8573 <__start___sancov_cntrs+0x7153>
  39e95f:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39e963:	eb 37                	jmp    39e99c <<oriole::Parser>::parse_text+0x236c>
  39e965:	fe 05 e9 9b 24 00    	incb   0x249be9(%rip)        # 5e8554 <__start___sancov_cntrs+0x7134>
  39e96b:	eb 72                	jmp    39e9df <<oriole::Parser>::parse_text+0x23af>
  39e96d:	fe 05 05 9c 24 00    	incb   0x249c05(%rip)        # 5e8578 <__start___sancov_cntrs+0x7158>
  39e973:	eb 06                	jmp    39e97b <<oriole::Parser>::parse_text+0x234b>
  39e975:	fe 05 fc 9b 24 00    	incb   0x249bfc(%rip)        # 5e8577 <__start___sancov_cntrs+0x7157>
  39e97b:	31 ff                	xor    %edi,%edi
  39e97d:	4c 89 ee             	mov    %r13,%rsi
  39e980:	e8 eb bb 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e985:	4d 85 ed             	test   %r13,%r13
  39e988:	0f 84 32 2d 00 00    	je     3a16c0 <<oriole::Parser>::parse_text+0x5090>
  39e98e:	fe 05 e7 9b 24 00    	incb   0x249be7(%rip)        # 5e857b <__start___sancov_cntrs+0x715b>
  39e994:	eb 09                	jmp    39e99f <<oriole::Parser>::parse_text+0x236f>
  39e996:	fe 05 de 9b 24 00    	incb   0x249bde(%rip)        # 5e857a <__start___sancov_cntrs+0x715a>
  39e99c:	4d 89 e5             	mov    %r12,%r13
  39e99f:	4c 89 ef             	mov    %r13,%rdi
  39e9a2:	4c 89 e6             	mov    %r12,%rsi
  39e9a5:	e8 26 bb 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39e9aa:	4d 39 e5             	cmp    %r12,%r13
  39e9ad:	0f 95 c0             	setne  %al
  39e9b0:	0a 83 9c 00 00 00    	or     0x9c(%rbx),%al
  39e9b6:	a8 01                	test   $0x1,%al
  39e9b8:	74 1a                	je     39e9d4 <<oriole::Parser>::parse_text+0x23a4>
  39e9ba:	31 ff                	xor    %edi,%edi
  39e9bc:	4c 89 ee             	mov    %r13,%rsi
  39e9bf:	e8 ac bb 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39e9c4:	4d 85 ed             	test   %r13,%r13
  39e9c7:	74 69                	je     39ea32 <<oriole::Parser>::parse_text+0x2402>
  39e9c9:	fe 05 ae 9b 24 00    	incb   0x249bae(%rip)        # 5e857d <__start___sancov_cntrs+0x715d>
  39e9cf:	e9 07 02 00 00       	jmp    39ebdb <<oriole::Parser>::parse_text+0x25ab>
  39e9d4:	4d 85 e4             	test   %r12,%r12
  39e9d7:	74 64                	je     39ea3d <<oriole::Parser>::parse_text+0x240d>
  39e9d9:	fe 05 a0 9b 24 00    	incb   0x249ba0(%rip)        # 5e857f <__start___sancov_cntrs+0x715f>
  39e9df:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
  39e9e6:	48 ff c8             	dec    %rax
  39e9e9:	49 89 c5             	mov    %rax,%r13
  39e9ec:	48 c1 e8 03          	shr    $0x3,%rax
  39e9f0:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39e9f7:	7f 
  39e9f8:	31 ff                	xor    %edi,%edi
  39e9fa:	44 89 f6             	mov    %r14d,%esi
  39e9fd:	e8 de be 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ea02:	45 85 f6             	test   %r14d,%r14d
  39ea05:	0f 85 e1 17 00 00    	jne    3a01ec <<oriole::Parser>::parse_text+0x3bbc>
  39ea0b:	fe 05 70 9b 24 00    	incb   0x249b70(%rip)        # 5e8581 <__start___sancov_cntrs+0x7161>
  39ea11:	41 0f b6 75 00       	movzbl 0x0(%r13),%esi
  39ea16:	45 31 ff             	xor    %r15d,%r15d
  39ea19:	83 fe 0d             	cmp    $0xd,%esi
  39ea1c:	41 0f 94 c7          	sete   %r15b
  39ea20:	bf 0d 00 00 00       	mov    $0xd,%edi
  39ea25:	e8 b6 be 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ea2a:	4d 89 e6             	mov    %r12,%r14
  39ea2d:	4d 29 fe             	sub    %r15,%r14
  39ea30:	eb 14                	jmp    39ea46 <<oriole::Parser>::parse_text+0x2416>
  39ea32:	fe 05 46 9b 24 00    	incb   0x249b46(%rip)        # 5e857e <__start___sancov_cntrs+0x715e>
  39ea38:	e9 2f 01 00 00       	jmp    39eb6c <<oriole::Parser>::parse_text+0x253c>
  39ea3d:	fe 05 3d 9b 24 00    	incb   0x249b3d(%rip)        # 5e8580 <__start___sancov_cntrs+0x7160>
  39ea43:	45 31 f6             	xor    %r14d,%r14d
  39ea46:	48 c7 c7 fd ff ff ff 	mov    $0xfffffffffffffffd,%rdi
  39ea4d:	4c 89 f6             	mov    %r14,%rsi
  39ea50:	e8 1b bb 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39ea55:	49 8d 7e ff          	lea    -0x1(%r14),%rdi
  39ea59:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
  39ea5d:	4c 89 e6             	mov    %r12,%rsi
  39ea60:	e8 6b ba 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39ea65:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39ea69:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39ea6d:	48 01 c8             	add    %rcx,%rax
  39ea70:	48 ff c8             	dec    %rax
  39ea73:	48 89 43 08          	mov    %rax,0x8(%rbx)
  39ea77:	4d 89 f4             	mov    %r14,%r12
  39ea7a:	4d 89 f7             	mov    %r14,%r15
  39ea7d:	4c 89 b3 b0 00 00 00 	mov    %r14,0xb0(%rbx)
  39ea84:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  39ea8b:	00 00 00 00 00 
  39ea90:	31 ff                	xor    %edi,%edi
  39ea92:	4c 89 e6             	mov    %r12,%rsi
  39ea95:	e8 d6 ba 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39ea9a:	49 83 ef 01          	sub    $0x1,%r15
  39ea9e:	0f 82 c2 00 00 00    	jb     39eb66 <<oriole::Parser>::parse_text+0x2536>
  39eaa4:	49 83 fe fd          	cmp    $0xfffffffffffffffd,%r14
  39eaa8:	0f 87 1b 16 00 00    	ja     3a00c9 <<oriole::Parser>::parse_text+0x3a99>
  39eaae:	4d 89 e6             	mov    %r12,%r14
  39eab1:	49 83 c4 02          	add    $0x2,%r12
  39eab5:	4c 89 e7             	mov    %r12,%rdi
  39eab8:	4c 8b 6b 18          	mov    0x18(%rbx),%r13
  39eabc:	4c 89 ee             	mov    %r13,%rsi
  39eabf:	e8 0c ba 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39eac4:	4d 39 ec             	cmp    %r13,%r12
  39eac7:	4d 89 ec             	mov    %r13,%r12
  39eaca:	0f 82 02 01 00 00    	jb     39ebd2 <<oriole::Parser>::parse_text+0x25a2>
  39ead0:	4c 39 63 70          	cmp    %r12,0x70(%rbx)
  39ead4:	0f 83 07 16 00 00    	jae    3a00e1 <<oriole::Parser>::parse_text+0x3ab1>
  39eada:	48 8b 43 08          	mov    0x8(%rbx),%rax
  39eade:	4e 8d 24 30          	lea    (%rax,%r14,1),%r12
  39eae2:	4c 89 e0             	mov    %r12,%rax
  39eae5:	48 c1 e8 03          	shr    $0x3,%rax
  39eae9:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39eaf0:	7f 
  39eaf1:	31 ff                	xor    %edi,%edi
  39eaf3:	44 89 ee             	mov    %r13d,%esi
  39eaf6:	e8 e5 bd 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39eafb:	45 85 ed             	test   %r13d,%r13d
  39eafe:	75 2a                	jne    39eb2a <<oriole::Parser>::parse_text+0x24fa>
  39eb00:	fe 05 81 9a 24 00    	incb   0x249a81(%rip)        # 5e8587 <__start___sancov_cntrs+0x7167>
  39eb06:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  39eb0a:	42 80 3c 31 5d       	cmpb   $0x5d,(%rcx,%r14,1)
  39eb0f:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39eb13:	75 46                	jne    39eb5b <<oriole::Parser>::parse_text+0x252b>
  39eb15:	fe 05 70 9a 24 00    	incb   0x249a70(%rip)        # 5e858b <__start___sancov_cntrs+0x716b>
  39eb1b:	4d 89 fc             	mov    %r15,%r12
  39eb1e:	4c 8b b3 b0 00 00 00 	mov    0xb0(%rbx),%r14
  39eb25:	e9 66 ff ff ff       	jmp    39ea90 <<oriole::Parser>::parse_text+0x2460>
  39eb2a:	41 83 e4 07          	and    $0x7,%r12d
  39eb2e:	45 0f b6 ed          	movzbl %r13b,%r13d
  39eb32:	44 89 e7             	mov    %r12d,%edi
  39eb35:	44 89 ee             	mov    %r13d,%esi
  39eb38:	e8 13 bd 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39eb3d:	45 38 ec             	cmp    %r13b,%r12b
  39eb40:	0f 8d 81 3a 00 00    	jge    3a25c7 <<oriole::Parser>::parse_text+0x5f97>
  39eb46:	fe 05 3c 9a 24 00    	incb   0x249a3c(%rip)        # 5e8588 <__start___sancov_cntrs+0x7168>
  39eb4c:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  39eb50:	42 80 3c 31 5d       	cmpb   $0x5d,(%rcx,%r14,1)
  39eb55:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39eb59:	74 ba                	je     39eb15 <<oriole::Parser>::parse_text+0x24e5>
  39eb5b:	4d 89 f5             	mov    %r14,%r13
  39eb5e:	fe 05 26 9a 24 00    	incb   0x249a26(%rip)        # 5e858a <__start___sancov_cntrs+0x716a>
  39eb64:	eb 75                	jmp    39ebdb <<oriole::Parser>::parse_text+0x25ab>
  39eb66:	fe 05 18 9a 24 00    	incb   0x249a18(%rip)        # 5e8584 <__start___sancov_cntrs+0x7164>
  39eb6c:	48 8b 43 58          	mov    0x58(%rbx),%rax
  39eb70:	48 c1 e8 03          	shr    $0x3,%rax
  39eb74:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39eb7b:	7f 
  39eb7c:	31 ff                	xor    %edi,%edi
  39eb7e:	44 89 f6             	mov    %r14d,%esi
  39eb81:	e8 5a bd 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39eb86:	45 85 f6             	test   %r14d,%r14d
  39eb89:	0f 85 03 16 00 00    	jne    3a0192 <<oriole::Parser>::parse_text+0x3b62>
  39eb8f:	fe 05 f8 99 24 00    	incb   0x2499f8(%rip)        # 5e858d <__start___sancov_cntrs+0x716d>
  39eb95:	4c 8b 7b 58          	mov    0x58(%rbx),%r15
  39eb99:	41 c6 07 00          	movb   $0x0,(%r15)
  39eb9d:	49 83 c7 30          	add    $0x30,%r15
  39eba1:	4c 89 f8             	mov    %r15,%rax
  39eba4:	48 c1 e8 03          	shr    $0x3,%rax
  39eba8:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39ebaf:	7f 
  39ebb0:	31 ff                	xor    %edi,%edi
  39ebb2:	44 89 f6             	mov    %r14d,%esi
  39ebb5:	e8 26 bd 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ebba:	45 85 f6             	test   %r14d,%r14d
  39ebbd:	0f 85 fa 15 00 00    	jne    3a01bd <<oriole::Parser>::parse_text+0x3b8d>
  39ebc3:	fe 05 c7 99 24 00    	incb   0x2499c7(%rip)        # 5e8590 <__start___sancov_cntrs+0x7170>
  39ebc9:	41 c6 07 ff          	movb   $0xff,(%r15)
  39ebcd:	e9 a7 2a 00 00       	jmp    3a1679 <<oriole::Parser>::parse_text+0x5049>
  39ebd2:	fe 05 ad 99 24 00    	incb   0x2499ad(%rip)        # 5e8585 <__start___sancov_cntrs+0x7165>
  39ebd8:	4d 89 f5             	mov    %r14,%r13
  39ebdb:	4c 89 ef             	mov    %r13,%rdi
  39ebde:	4c 89 e6             	mov    %r12,%rsi
  39ebe1:	e8 ea b8 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39ebe6:	4d 39 e5             	cmp    %r12,%r13
  39ebe9:	4c 89 6b 28          	mov    %r13,0x28(%rbx)
  39ebed:	73 5a                	jae    39ec49 <<oriole::Parser>::parse_text+0x2619>
  39ebef:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39ebf3:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39ebf7:	48 01 c8             	add    %rcx,%rax
  39ebfa:	4e 8d 34 28          	lea    (%rax,%r13,1),%r14
  39ebfe:	4c 89 f0             	mov    %r14,%rax
  39ec01:	48 c1 e8 03          	shr    $0x3,%rax
  39ec05:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39ec0c:	7f 
  39ec0d:	31 ff                	xor    %edi,%edi
  39ec0f:	44 89 fe             	mov    %r15d,%esi
  39ec12:	e8 c9 bc 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ec17:	45 85 ff             	test   %r15d,%r15d
  39ec1a:	0f 85 fa 15 00 00    	jne    3a021a <<oriole::Parser>::parse_text+0x3bea>
  39ec20:	fe 05 6f 99 24 00    	incb   0x24996f(%rip)        # 5e8595 <__start___sancov_cntrs+0x7175>
  39ec26:	45 0f b6 36          	movzbl (%r14),%r14d
  39ec2a:	bf bf 00 00 00       	mov    $0xbf,%edi
  39ec2f:	44 89 f6             	mov    %r14d,%esi
  39ec32:	e8 a9 bc 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ec37:	41 80 fe bf          	cmp    $0xbf,%r14b
  39ec3b:	0f 8e 0b 16 00 00    	jle    3a024c <<oriole::Parser>::parse_text+0x3c1c>
  39ec41:	fe 05 52 99 24 00    	incb   0x249952(%rip)        # 5e8599 <__start___sancov_cntrs+0x7179>
  39ec47:	eb 1a                	jmp    39ec63 <<oriole::Parser>::parse_text+0x2633>
  39ec49:	4c 89 ef             	mov    %r13,%rdi
  39ec4c:	4c 89 e6             	mov    %r12,%rsi
  39ec4f:	e8 7c b8 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39ec54:	4d 39 e5             	cmp    %r12,%r13
  39ec57:	0f 85 f7 15 00 00    	jne    3a0254 <<oriole::Parser>::parse_text+0x3c24>
  39ec5d:	fe 05 31 99 24 00    	incb   0x249931(%rip)        # 5e8594 <__start___sancov_cntrs+0x7174>
  39ec63:	4c 89 ef             	mov    %r13,%rdi
  39ec66:	4c 89 e6             	mov    %r12,%rsi
  39ec69:	e8 62 b8 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39ec6e:	4d 39 e5             	cmp    %r12,%r13
  39ec71:	0f 87 ee 11 00 00    	ja     39fe65 <<oriole::Parser>::parse_text+0x3835>
  39ec77:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39ec7b:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39ec7f:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
  39ec83:	4c 89 ee             	mov    %r13,%rsi
  39ec86:	e8 f5 17 0a 00       	call   440480 <oriole::names::invalid_xml_char>
  39ec8b:	48 89 83 d0 00 00 00 	mov    %rax,0xd0(%rbx)
  39ec92:	48 89 93 c8 00 00 00 	mov    %rdx,0xc8(%rbx)
  39ec99:	bf 40 00 00 00       	mov    $0x40,%edi
  39ec9e:	4c 89 ee             	mov    %r13,%rsi
  39eca1:	e8 ca b8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39eca6:	49 83 fd 3f          	cmp    $0x3f,%r13
  39ecaa:	77 22                	ja     39ecce <<oriole::Parser>::parse_text+0x269e>
  39ecac:	bf 03 00 00 00       	mov    $0x3,%edi
  39ecb1:	4c 89 ee             	mov    %r13,%rsi
  39ecb4:	e8 b7 b8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39ecb9:	49 83 fd 02          	cmp    $0x2,%r13
  39ecbd:	0f 87 53 04 00 00    	ja     39f116 <<oriole::Parser>::parse_text+0x2ae6>
  39ecc3:	fe 05 d3 98 24 00    	incb   0x2498d3(%rip)        # 5e859c <__start___sancov_cntrs+0x717c>
  39ecc9:	e9 db 0d 00 00       	jmp    39faa9 <<oriole::Parser>::parse_text+0x3479>
  39ecce:	0f 57 c0             	xorps  %xmm0,%xmm0
  39ecd1:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  39ecd8:	0f 11 40 04          	movups %xmm0,0x4(%rax)
  39ecdc:	0f 11 40 14          	movups %xmm0,0x14(%rax)
  39ece0:	c7 40 24 00 00 00 00 	movl   $0x0,0x24(%rax)
  39ece7:	48 c7 83 f0 01 00 00 	movq   $0x0,0x1f0(%rbx)
  39ecee:	00 00 00 00 
  39ecf2:	48 8d 15 87 06 1a 00 	lea    0x1a0687(%rip),%rdx        # 53f380 <alloc_7884d1a34c9c0a3985957c2080036e69>
  39ecf9:	48 89 93 f8 01 00 00 	mov    %rdx,0x1f8(%rbx)
  39ed00:	48 c7 83 00 02 00 00 	movq   $0x3,0x200(%rbx)
  39ed07:	03 00 00 00 
  39ed0b:	c6 40 36 01          	movb   $0x1,0x36(%rax)
  39ed0f:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
  39ed16:	c6 01 00             	movb   $0x0,(%rcx)
  39ed19:	c6 40 34 01          	movb   $0x1,0x34(%rax)
  39ed1d:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
  39ed24:	c6 00 01             	movb   $0x1,(%rax)
  39ed27:	48 89 93 20 01 00 00 	mov    %rdx,0x120(%rbx)
  39ed2e:	48 8d 05 4e 06 1a 00 	lea    0x1a064e(%rip),%rax        # 53f383 <alloc_7884d1a34c9c0a3985957c2080036e69+0x3>
  39ed35:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
  39ed3c:	48 c7 83 30 01 00 00 	movq   $0x0,0x130(%rbx)
  39ed43:	00 00 00 00 
  39ed47:	48 c7 83 38 01 00 00 	movq   $0xff,0x138(%rbx)
  39ed4e:	ff 00 00 00 
  39ed52:	48 c7 83 40 01 00 00 	movq   $0x2,0x140(%rbx)
  39ed59:	02 00 00 00 
  39ed5d:	c6 43 17 5d          	movb   $0x5d,0x17(%rbx)
  39ed61:	c6 83 9c 00 00 00 01 	movb   $0x1,0x9c(%rbx)
  39ed68:	41 bd 02 00 00 00    	mov    $0x2,%r13d
  39ed6e:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
  39ed75:	00 00 00 00 
  39ed79:	c6 43 08 5d          	movb   $0x5d,0x8(%rbx)
  39ed7d:	eb 0e                	jmp    39ed8d <<oriole::Parser>::parse_text+0x275d>
  39ed7f:	90                   	nop
  39ed80:	fe 05 27 98 24 00    	incb   0x249827(%rip)        # 5e85ad <__start___sancov_cntrs+0x718d>
  39ed86:	4c 8b ab 40 01 00 00 	mov    0x140(%rbx),%r13
  39ed8d:	31 ff                	xor    %edi,%edi
  39ed8f:	4c 89 ee             	mov    %r13,%rsi
  39ed92:	e8 d9 b7 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39ed97:	4d 85 ed             	test   %r13,%r13
  39ed9a:	0f 85 81 02 00 00    	jne    39f021 <<oriole::Parser>::parse_text+0x29f1>
  39eda0:	4c 8b b3 38 01 00 00 	mov    0x138(%rbx),%r14
  39eda7:	31 ff                	xor    %edi,%edi
  39eda9:	4c 89 f6             	mov    %r14,%rsi
  39edac:	e8 bf b7 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39edb1:	4d 85 f6             	test   %r14,%r14
  39edb4:	0f 84 51 03 00 00    	je     39f10b <<oriole::Parser>::parse_text+0x2adb>
  39edba:	49 ff ce             	dec    %r14
  39edbd:	4c 89 b3 38 01 00 00 	mov    %r14,0x138(%rbx)
  39edc4:	4c 8b ab 20 01 00 00 	mov    0x120(%rbx),%r13
  39edcb:	4c 3b ab 28 01 00 00 	cmp    0x128(%rbx),%r13
  39edd2:	74 4c                	je     39ee20 <<oriole::Parser>::parse_text+0x27f0>
  39edd4:	49 8d 45 01          	lea    0x1(%r13),%rax
  39edd8:	48 89 83 20 01 00 00 	mov    %rax,0x120(%rbx)
  39eddf:	4c 8b b3 30 01 00 00 	mov    0x130(%rbx),%r14
  39ede6:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  39eded:	4c 89 f6             	mov    %r14,%rsi
  39edf0:	e8 7b b7 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39edf5:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
  39edf9:	0f 84 1c 13 00 00    	je     3a011b <<oriole::Parser>::parse_text+0x3aeb>
  39edff:	fe 05 9b 97 24 00    	incb   0x24979b(%rip)        # 5e85a0 <__start___sancov_cntrs+0x7180>
  39ee05:	49 8d 46 01          	lea    0x1(%r14),%rax
  39ee09:	48 89 83 30 01 00 00 	mov    %rax,0x130(%rbx)
  39ee10:	4d 85 ed             	test   %r13,%r13
  39ee13:	75 1d                	jne    39ee32 <<oriole::Parser>::parse_text+0x2802>
  39ee15:	e9 54 05 00 00       	jmp    39f36e <<oriole::Parser>::parse_text+0x2d3e>
  39ee1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  39ee20:	fe 05 79 97 24 00    	incb   0x249779(%rip)        # 5e859f <__start___sancov_cntrs+0x717f>
  39ee26:	45 31 ed             	xor    %r13d,%r13d
  39ee29:	4d 85 ed             	test   %r13,%r13
  39ee2c:	0f 84 3c 05 00 00    	je     39f36e <<oriole::Parser>::parse_text+0x2d3e>
  39ee32:	4c 89 b3 b0 00 00 00 	mov    %r14,0xb0(%rbx)
  39ee39:	4c 89 e8             	mov    %r13,%rax
  39ee3c:	48 c1 e8 03          	shr    $0x3,%rax
  39ee40:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39ee47:	7f 
  39ee48:	31 ff                	xor    %edi,%edi
  39ee4a:	44 89 fe             	mov    %r15d,%esi
  39ee4d:	e8 8e ba 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ee52:	45 85 ff             	test   %r15d,%r15d
  39ee55:	0f 85 fa 01 00 00    	jne    39f055 <<oriole::Parser>::parse_text+0x2a25>
  39ee5b:	fe 05 42 97 24 00    	incb   0x249742(%rip)        # 5e85a3 <__start___sancov_cntrs+0x7183>
  39ee61:	45 0f b6 75 00       	movzbl 0x0(%r13),%r14d
  39ee66:	48 8d 05 33 8d 1a 00 	lea    0x1a8d33(%rip),%rax        # 547ba0 <___asan_gen_anon_global.2008>
  39ee6d:	4e 8d 3c 30          	lea    (%rax,%r14,1),%r15
  39ee71:	4c 89 f8             	mov    %r15,%rax
  39ee74:	48 c1 e8 03          	shr    $0x3,%rax
  39ee78:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  39ee7f:	7f 
  39ee80:	31 ff                	xor    %edi,%edi
  39ee82:	44 89 ee             	mov    %r13d,%esi
  39ee85:	e8 56 ba 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39ee8a:	45 85 ed             	test   %r13d,%r13d
  39ee8d:	4c 89 73 70          	mov    %r14,0x70(%rbx)
  39ee91:	0f 85 e8 01 00 00    	jne    39f07f <<oriole::Parser>::parse_text+0x2a4f>
  39ee97:	fe 05 09 97 24 00    	incb   0x249709(%rip)        # 5e85a6 <__start___sancov_cntrs+0x7186>
  39ee9d:	45 0f b6 27          	movzbl (%r15),%r12d
  39eea1:	44 0f b6 7b 08       	movzbl 0x8(%rbx),%r15d
  39eea6:	48 8d 05 f3 8c 1a 00 	lea    0x1a8cf3(%rip),%rax        # 547ba0 <___asan_gen_anon_global.2008>
  39eead:	4e 8d 2c 38          	lea    (%rax,%r15,1),%r13
  39eeb1:	4c 89 e8             	mov    %r13,%rax
  39eeb4:	48 c1 e8 03          	shr    $0x3,%rax
  39eeb8:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39eebf:	7f 
  39eec0:	31 ff                	xor    %edi,%edi
  39eec2:	44 89 f6             	mov    %r14d,%esi
  39eec5:	e8 16 ba 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39eeca:	45 85 f6             	test   %r14d,%r14d
  39eecd:	0f 85 d6 01 00 00    	jne    39f0a9 <<oriole::Parser>::parse_text+0x2a79>
  39eed3:	fe 05 d0 96 24 00    	incb   0x2496d0(%rip)        # 5e85a9 <__start___sancov_cntrs+0x7189>
  39eed9:	45 0f b6 75 00       	movzbl 0x0(%r13),%r14d
  39eede:	45 0f b6 ec          	movzbl %r12b,%r13d
  39eee2:	44 89 ef             	mov    %r13d,%edi
  39eee5:	44 89 f6             	mov    %r14d,%esi
  39eee8:	e8 63 b9 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39eeed:	45 38 f5             	cmp    %r14b,%r13b
  39eef0:	73 6e                	jae    39ef60 <<oriole::Parser>::parse_text+0x2930>
  39eef2:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
  39eef9:	4c 8b b3 a8 00 00 00 	mov    0xa8(%rbx),%r14
  39ef00:	44 88 30             	mov    %r14b,(%rax)
  39ef03:	bf ff 00 00 00       	mov    $0xff,%edi
  39ef08:	4c 8b bb b0 00 00 00 	mov    0xb0(%rbx),%r15
  39ef0f:	4c 89 fe             	mov    %r15,%rsi
  39ef12:	e8 59 b6 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39ef17:	49 81 ff 00 01 00 00 	cmp    $0x100,%r15
  39ef1e:	48 8b 4b 70          	mov    0x70(%rbx),%rcx
  39ef22:	0f 83 02 0f 00 00    	jae    39fe2a <<oriole::Parser>::parse_text+0x37fa>
  39ef28:	fe 05 84 96 24 00    	incb   0x249684(%rip)        # 5e85b2 <__start___sancov_cntrs+0x7192>
  39ef2e:	48 8b 83 18 01 00 00 	mov    0x118(%rbx),%rax
  39ef35:	44 88 38             	mov    %r15b,(%rax)
  39ef38:	4c 8b ab 40 01 00 00 	mov    0x140(%rbx),%r13
  39ef3f:	44 88 b3 9c 00 00 00 	mov    %r14b,0x9c(%rbx)
  39ef46:	4c 89 bb a8 00 00 00 	mov    %r15,0xa8(%rbx)
  39ef4d:	0f b6 43 08          	movzbl 0x8(%rbx),%eax
  39ef51:	88 43 17             	mov    %al,0x17(%rbx)
  39ef54:	88 4b 08             	mov    %cl,0x8(%rbx)
  39ef57:	e9 31 fe ff ff       	jmp    39ed8d <<oriole::Parser>::parse_text+0x275d>
  39ef5c:	0f 1f 40 00          	nopl   0x0(%rax)
  39ef60:	4c 8b 63 70          	mov    0x70(%rbx),%r12
  39ef64:	45 0f b6 f4          	movzbl %r12b,%r14d
  39ef68:	44 89 f7             	mov    %r14d,%edi
  39ef6b:	44 89 fe             	mov    %r15d,%esi
  39ef6e:	e8 dd b8 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39ef73:	45 38 fe             	cmp    %r15b,%r14b
  39ef76:	0f 84 04 fe ff ff    	je     39ed80 <<oriole::Parser>::parse_text+0x2750>
  39ef7c:	44 0f b6 7b 17       	movzbl 0x17(%rbx),%r15d
  39ef81:	48 8d 05 18 8c 1a 00 	lea    0x1a8c18(%rip),%rax        # 547ba0 <___asan_gen_anon_global.2008>
  39ef88:	49 01 c7             	add    %rax,%r15
  39ef8b:	4c 89 f8             	mov    %r15,%rax
  39ef8e:	48 c1 e8 03          	shr    $0x3,%rax
  39ef92:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39ef99:	7f 
  39ef9a:	31 ff                	xor    %edi,%edi
  39ef9c:	44 89 f6             	mov    %r14d,%esi
  39ef9f:	e8 3c b9 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39efa4:	45 85 f6             	test   %r14d,%r14d
  39efa7:	0f 85 2d 01 00 00    	jne    39f0da <<oriole::Parser>::parse_text+0x2aaa>
  39efad:	fe 05 00 96 24 00    	incb   0x249600(%rip)        # 5e85b3 <__start___sancov_cntrs+0x7193>
  39efb3:	45 0f b6 37          	movzbl (%r15),%r14d
  39efb7:	44 89 ef             	mov    %r13d,%edi
  39efba:	44 89 f6             	mov    %r14d,%esi
  39efbd:	e8 8e b8 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39efc2:	45 38 f5             	cmp    %r14b,%r13b
  39efc5:	73 48                	jae    39f00f <<oriole::Parser>::parse_text+0x29df>
  39efc7:	bf ff 00 00 00       	mov    $0xff,%edi
  39efcc:	4c 8b b3 b0 00 00 00 	mov    0xb0(%rbx),%r14
  39efd3:	4c 89 f6             	mov    %r14,%rsi
  39efd6:	e8 95 b5 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39efdb:	49 81 fe 00 01 00 00 	cmp    $0x100,%r14
  39efe2:	0f 83 88 0e 00 00    	jae    39fe70 <<oriole::Parser>::parse_text+0x3840>
  39efe8:	fe 05 ca 95 24 00    	incb   0x2495ca(%rip)        # 5e85b8 <__start___sancov_cntrs+0x7198>
  39efee:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
  39eff5:	44 88 30             	mov    %r14b,(%rax)
  39eff8:	4c 8b ab 40 01 00 00 	mov    0x140(%rbx),%r13
  39efff:	44 88 b3 9c 00 00 00 	mov    %r14b,0x9c(%rbx)
  39f006:	44 88 63 17          	mov    %r12b,0x17(%rbx)
  39f00a:	e9 7e fd ff ff       	jmp    39ed8d <<oriole::Parser>::parse_text+0x275d>
  39f00f:	fe 05 a1 95 24 00    	incb   0x2495a1(%rip)        # 5e85b6 <__start___sancov_cntrs+0x7196>
  39f015:	4c 8b ab 40 01 00 00 	mov    0x140(%rbx),%r13
  39f01c:	e9 6c fd ff ff       	jmp    39ed8d <<oriole::Parser>::parse_text+0x275d>
  39f021:	48 c7 83 40 01 00 00 	movq   $0x0,0x140(%rbx)
  39f028:	00 00 00 00 
  39f02c:	48 8d bb 20 01 00 00 	lea    0x120(%rbx),%rdi
  39f033:	4c 89 ee             	mov    %r13,%rsi
  39f036:	e8 95 b7 0a 00       	call   44a7d0 <<core::iter::adapters::take::Take<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<u8>>> as core::iter::traits::iterator::Iterator>::nth>
  39f03b:	49 89 c6             	mov    %rax,%r14
  39f03e:	49 89 d5             	mov    %rdx,%r13
  39f041:	fe 05 57 95 24 00    	incb   0x249557(%rip)        # 5e859e <__start___sancov_cntrs+0x717e>
  39f047:	4d 85 ed             	test   %r13,%r13
  39f04a:	0f 85 e2 fd ff ff    	jne    39ee32 <<oriole::Parser>::parse_text+0x2802>
  39f050:	e9 19 03 00 00       	jmp    39f36e <<oriole::Parser>::parse_text+0x2d3e>
  39f055:	45 89 ee             	mov    %r13d,%r14d
  39f058:	41 83 e6 07          	and    $0x7,%r14d
  39f05c:	45 0f b6 ff          	movzbl %r15b,%r15d
  39f060:	44 89 f7             	mov    %r14d,%edi
  39f063:	44 89 fe             	mov    %r15d,%esi
  39f066:	e8 e5 b7 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39f06b:	45 38 fe             	cmp    %r15b,%r14b
  39f06e:	0f 8d a0 37 00 00    	jge    3a2814 <<oriole::Parser>::parse_text+0x61e4>
  39f074:	fe 05 2a 95 24 00    	incb   0x24952a(%rip)        # 5e85a4 <__start___sancov_cntrs+0x7184>
  39f07a:	e9 e2 fd ff ff       	jmp    39ee61 <<oriole::Parser>::parse_text+0x2831>
  39f07f:	45 89 fe             	mov    %r15d,%r14d
  39f082:	41 83 e6 07          	and    $0x7,%r14d
  39f086:	45 0f b6 ed          	movzbl %r13b,%r13d
  39f08a:	44 89 f7             	mov    %r14d,%edi
  39f08d:	44 89 ee             	mov    %r13d,%esi
  39f090:	e8 bb b7 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39f095:	45 38 ee             	cmp    %r13b,%r14b
  39f098:	0f 8d 86 37 00 00    	jge    3a2824 <<oriole::Parser>::parse_text+0x61f4>
  39f09e:	fe 05 03 95 24 00    	incb   0x249503(%rip)        # 5e85a7 <__start___sancov_cntrs+0x7187>
  39f0a4:	e9 f4 fd ff ff       	jmp    39ee9d <<oriole::Parser>::parse_text+0x286d>
  39f0a9:	44 89 ef             	mov    %r13d,%edi
  39f0ac:	83 e7 07             	and    $0x7,%edi
  39f0af:	48 89 bb 08 01 00 00 	mov    %rdi,0x108(%rbx)
  39f0b6:	45 0f b6 f6          	movzbl %r14b,%r14d
  39f0ba:	44 89 f6             	mov    %r14d,%esi
  39f0bd:	e8 8e b7 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39f0c2:	44 38 b3 08 01 00 00 	cmp    %r14b,0x108(%rbx)
  39f0c9:	0f 8d 65 37 00 00    	jge    3a2834 <<oriole::Parser>::parse_text+0x6204>
  39f0cf:	fe 05 d5 94 24 00    	incb   0x2494d5(%rip)        # 5e85aa <__start___sancov_cntrs+0x718a>
  39f0d5:	e9 ff fd ff ff       	jmp    39eed9 <<oriole::Parser>::parse_text+0x28a9>
  39f0da:	44 89 ff             	mov    %r15d,%edi
  39f0dd:	83 e7 07             	and    $0x7,%edi
  39f0e0:	48 89 bb 08 01 00 00 	mov    %rdi,0x108(%rbx)
  39f0e7:	45 0f b6 f6          	movzbl %r14b,%r14d
  39f0eb:	44 89 f6             	mov    %r14d,%esi
  39f0ee:	e8 5d b7 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39f0f3:	44 38 b3 08 01 00 00 	cmp    %r14b,0x108(%rbx)
  39f0fa:	0f 8d 04 37 00 00    	jge    3a2804 <<oriole::Parser>::parse_text+0x61d4>
  39f100:	fe 05 ae 94 24 00    	incb   0x2494ae(%rip)        # 5e85b4 <__start___sancov_cntrs+0x7194>
  39f106:	e9 a8 fe ff ff       	jmp    39efb3 <<oriole::Parser>::parse_text+0x2983>
  39f10b:	fe 05 8c 94 24 00    	incb   0x24948c(%rip)        # 5e859d <__start___sancov_cntrs+0x717d>
  39f111:	e9 5e 02 00 00       	jmp    39f374 <<oriole::Parser>::parse_text+0x2d44>
  39f116:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39f11a:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39f11e:	48 01 c8             	add    %rcx,%rax
  39f121:	48 c1 e8 03          	shr    $0x3,%rax
  39f125:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39f12c:	7f 
  39f12d:	31 ff                	xor    %edi,%edi
  39f12f:	44 89 f6             	mov    %r14d,%esi
  39f132:	e8 a9 b7 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f137:	45 85 f6             	test   %r14d,%r14d
  39f13a:	0f 85 7f 1f 00 00    	jne    3a10bf <<oriole::Parser>::parse_text+0x4a8f>
  39f140:	fe 05 87 94 24 00    	incb   0x249487(%rip)        # 5e85cd <__start___sancov_cntrs+0x71ad>
  39f146:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39f14a:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39f14e:	48 01 c8             	add    %rcx,%rax
  39f151:	44 0f b6 28          	movzbl (%rax),%r13d
  39f155:	4c 8d 70 01          	lea    0x1(%rax),%r14
  39f159:	4c 89 f0             	mov    %r14,%rax
  39f15c:	48 c1 e8 03          	shr    $0x3,%rax
  39f160:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39f167:	7f 
  39f168:	31 ff                	xor    %edi,%edi
  39f16a:	44 89 fe             	mov    %r15d,%esi
  39f16d:	e8 6e b7 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f172:	45 85 ff             	test   %r15d,%r15d
  39f175:	0f 85 77 1f 00 00    	jne    3a10f2 <<oriole::Parser>::parse_text+0x4ac2>
  39f17b:	fe 05 4f 94 24 00    	incb   0x24944f(%rip)        # 5e85d0 <__start___sancov_cntrs+0x71b0>
  39f181:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39f185:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39f189:	48 01 c8             	add    %rcx,%rax
  39f18c:	44 0f b6 60 01       	movzbl 0x1(%rax),%r12d
  39f191:	4c 8d 70 02          	lea    0x2(%rax),%r14
  39f195:	4c 89 f0             	mov    %r14,%rax
  39f198:	48 c1 e8 03          	shr    $0x3,%rax
  39f19c:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39f1a3:	7f 
  39f1a4:	31 ff                	xor    %edi,%edi
  39f1a6:	44 89 fe             	mov    %r15d,%esi
  39f1a9:	e8 32 b7 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f1ae:	45 85 ff             	test   %r15d,%r15d
  39f1b1:	0f 85 65 1f 00 00    	jne    3a111c <<oriole::Parser>::parse_text+0x4aec>
  39f1b7:	fe 05 16 94 24 00    	incb   0x249416(%rip)        # 5e85d3 <__start___sancov_cntrs+0x71b3>
  39f1bd:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39f1c1:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39f1c5:	48 01 c1             	add    %rax,%rcx
  39f1c8:	48 8b 43 28          	mov    0x28(%rbx),%rax
  39f1cc:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
  39f1d0:	0f b6 41 02          	movzbl 0x2(%rcx),%eax
  39f1d4:	41 c1 e5 02          	shl    $0x2,%r13d
  39f1d8:	47 8d 74 65 00       	lea    0x0(%r13,%r12,2),%r14d
  39f1dd:	41 01 c6             	add    %eax,%r14d
  39f1e0:	48 83 c2 fd          	add    $0xfffffffffffffffd,%rdx
  39f1e4:	48 89 93 b0 00 00 00 	mov    %rdx,0xb0(%rbx)
  39f1eb:	31 d2                	xor    %edx,%edx
  39f1ed:	48 89 4b 70          	mov    %rcx,0x70(%rbx)
  39f1f1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  39f1f8:	0f 1f 84 00 00 00 00 
  39f1ff:	00 
  39f200:	48 89 53 08          	mov    %rdx,0x8(%rbx)
  39f204:	4c 8d 24 11          	lea    (%rcx,%rdx,1),%r12
  39f208:	bf 6c 02 00 00       	mov    $0x26c,%edi
  39f20d:	44 89 f6             	mov    %r14d,%esi
  39f210:	e8 8b b4 11 00       	call   4ba6a0 <__sanitizer_cov_trace_const_cmp4>
  39f215:	41 81 fe 6c 02 00 00 	cmp    $0x26c,%r14d
  39f21c:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  39f220:	0f 84 ab 00 00 00    	je     39f2d1 <<oriole::Parser>::parse_text+0x2ca1>
  39f226:	fe 05 aa 93 24 00    	incb   0x2493aa(%rip)        # 5e85d6 <__start___sancov_cntrs+0x71b6>
  39f22c:	4c 3b a3 b0 00 00 00 	cmp    0xb0(%rbx),%r12
  39f233:	0f 83 26 01 00 00    	jae    39f35f <<oriole::Parser>::parse_text+0x2d2f>
  39f239:	48 8b 43 70          	mov    0x70(%rbx),%rax
  39f23d:	48 c1 e8 03          	shr    $0x3,%rax
  39f241:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  39f248:	7f 
  39f249:	31 ff                	xor    %edi,%edi
  39f24b:	44 89 e6             	mov    %r12d,%esi
  39f24e:	e8 8d b6 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f253:	45 85 e4             	test   %r12d,%r12d
  39f256:	0f 85 a7 00 00 00    	jne    39f303 <<oriole::Parser>::parse_text+0x2cd3>
  39f25c:	fe 05 77 93 24 00    	incb   0x249377(%rip)        # 5e85d9 <__start___sancov_cntrs+0x71b9>
  39f262:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39f266:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39f26a:	48 01 c8             	add    %rcx,%rax
  39f26d:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  39f271:	44 0f b6 2c 08       	movzbl (%rax,%rcx,1),%r13d
  39f276:	48 8b 43 70          	mov    0x70(%rbx),%rax
  39f27a:	4c 8d 60 03          	lea    0x3(%rax),%r12
  39f27e:	4c 89 e0             	mov    %r12,%rax
  39f281:	48 c1 e8 03          	shr    $0x3,%rax
  39f285:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39f28c:	7f 
  39f28d:	31 ff                	xor    %edi,%edi
  39f28f:	44 89 fe             	mov    %r15d,%esi
  39f292:	e8 49 b6 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f297:	45 85 ff             	test   %r15d,%r15d
  39f29a:	0f 85 8e 00 00 00    	jne    39f32e <<oriole::Parser>::parse_text+0x2cfe>
  39f2a0:	fe 05 36 93 24 00    	incb   0x249336(%rip)        # 5e85dc <__start___sancov_cntrs+0x71bc>
  39f2a6:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39f2aa:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39f2ae:	48 01 c1             	add    %rax,%rcx
  39f2b1:	48 8b 53 08          	mov    0x8(%rbx),%rdx
  39f2b5:	0f b6 44 11 03       	movzbl 0x3(%rcx,%rdx,1),%eax
  39f2ba:	41 c1 e5 03          	shl    $0x3,%r13d
  39f2be:	46 8d 34 70          	lea    (%rax,%r14,2),%r14d
  39f2c2:	45 29 ee             	sub    %r13d,%r14d
  39f2c5:	48 ff 43 70          	incq   0x70(%rbx)
  39f2c9:	48 ff c2             	inc    %rdx
  39f2cc:	e9 2f ff ff ff       	jmp    39f200 <<oriole::Parser>::parse_text+0x2bd0>
  39f2d1:	ba 03 00 00 00       	mov    $0x3,%edx
  39f2d6:	4c 89 e7             	mov    %r12,%rdi
  39f2d9:	48 8d 35 a0 00 1a 00 	lea    0x1a00a0(%rip),%rsi        # 53f380 <alloc_7884d1a34c9c0a3985957c2080036e69>
  39f2e0:	ff 15 d2 da 21 00    	call   *0x21dad2(%rip)        # 5bcdb8 <_GLOBAL_OFFSET_TABLE_+0x1010>
  39f2e6:	84 c0                	test   %al,%al
  39f2e8:	0f 85 04 0d 00 00    	jne    39fff2 <<oriole::Parser>::parse_text+0x39c2>
  39f2ee:	fe 05 e4 92 24 00    	incb   0x2492e4(%rip)        # 5e85d8 <__start___sancov_cntrs+0x71b8>
  39f2f4:	4c 3b a3 b0 00 00 00 	cmp    0xb0(%rbx),%r12
  39f2fb:	0f 82 38 ff ff ff    	jb     39f239 <<oriole::Parser>::parse_text+0x2c09>
  39f301:	eb 5c                	jmp    39f35f <<oriole::Parser>::parse_text+0x2d2f>
  39f303:	4c 8b 7b 70          	mov    0x70(%rbx),%r15
  39f307:	41 83 e7 07          	and    $0x7,%r15d
  39f30b:	45 0f b6 e4          	movzbl %r12b,%r12d
  39f30f:	44 89 ff             	mov    %r15d,%edi
  39f312:	44 89 e6             	mov    %r12d,%esi
  39f315:	e8 36 b5 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39f31a:	45 38 e7             	cmp    %r12b,%r15b
  39f31d:	0f 8d c0 34 00 00    	jge    3a27e3 <<oriole::Parser>::parse_text+0x61b3>
  39f323:	fe 05 b1 92 24 00    	incb   0x2492b1(%rip)        # 5e85da <__start___sancov_cntrs+0x71ba>
  39f329:	e9 34 ff ff ff       	jmp    39f262 <<oriole::Parser>::parse_text+0x2c32>
  39f32e:	44 89 e7             	mov    %r12d,%edi
  39f331:	83 e7 07             	and    $0x7,%edi
  39f334:	48 89 bb a8 00 00 00 	mov    %rdi,0xa8(%rbx)
  39f33b:	45 0f b6 ff          	movzbl %r15b,%r15d
  39f33f:	44 89 fe             	mov    %r15d,%esi
  39f342:	e8 09 b5 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39f347:	44 38 bb a8 00 00 00 	cmp    %r15b,0xa8(%rbx)
  39f34e:	0f 8d a0 34 00 00    	jge    3a27f4 <<oriole::Parser>::parse_text+0x61c4>
  39f354:	fe 05 83 92 24 00    	incb   0x249283(%rip)        # 5e85dd <__start___sancov_cntrs+0x71bd>
  39f35a:	e9 47 ff ff ff       	jmp    39f2a6 <<oriole::Parser>::parse_text+0x2c76>
  39f35f:	fe 05 72 92 24 00    	incb   0x249272(%rip)        # 5e85d7 <__start___sancov_cntrs+0x71b7>
  39f365:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39f369:	e9 3b 07 00 00       	jmp    39faa9 <<oriole::Parser>::parse_text+0x3479>
  39f36e:	fe 05 2e 92 24 00    	incb   0x24922e(%rip)        # 5e85a2 <__start___sancov_cntrs+0x7182>
  39f374:	4c 8b b3 a8 00 00 00 	mov    0xa8(%rbx),%r14
  39f37b:	45 0f b6 fe          	movzbl %r14b,%r15d
  39f37f:	44 0f b6 a3 9c 00 00 	movzbl 0x9c(%rbx),%r12d
  39f386:	00 
  39f387:	44 89 ff             	mov    %r15d,%edi
  39f38a:	44 89 e6             	mov    %r12d,%esi
  39f38d:	e8 be b4 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39f392:	45 38 e6             	cmp    %r12b,%r14b
  39f395:	0f 84 90 0b 00 00    	je     39ff2b <<oriole::Parser>::parse_text+0x38fb>
  39f39b:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  39f3a2:	c6 40 34 f8          	movb   $0xf8,0x34(%rax)
  39f3a6:	c6 40 36 f8          	movb   $0xf8,0x36(%rax)
  39f3aa:	4c 8d 2d 3f eb 86 00 	lea    0x86eb3f(%rip),%r13        # c0def0 <std_detect::detect::cache::CACHE>
  39f3b1:	4c 89 e8             	mov    %r13,%rax
  39f3b4:	48 c1 e8 03          	shr    $0x3,%rax
  39f3b8:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39f3bf:	7f 
  39f3c0:	31 ff                	xor    %edi,%edi
  39f3c2:	44 89 f6             	mov    %r14d,%esi
  39f3c5:	e8 16 b5 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f3ca:	45 85 f6             	test   %r14d,%r14d
  39f3cd:	0f 85 71 34 00 00    	jne    3a2844 <<oriole::Parser>::parse_text+0x6214>
  39f3d3:	4d 8b 6d 00          	mov    0x0(%r13),%r13
  39f3d7:	31 ff                	xor    %edi,%edi
  39f3d9:	4c 89 ee             	mov    %r13,%rsi
  39f3dc:	e8 8f b1 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39f3e1:	4d 85 ed             	test   %r13,%r13
  39f3e4:	0f 84 77 0b 00 00    	je     39ff61 <<oriole::Parser>::parse_text+0x3931>
  39f3ea:	4c 89 ee             	mov    %r13,%rsi
  39f3ed:	48 81 e6 00 80 00 00 	and    $0x8000,%rsi
  39f3f4:	31 ff                	xor    %edi,%edi
  39f3f6:	e8 75 b1 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39f3fb:	49 81 e5 00 80 00 00 	and    $0x8000,%r13
  39f402:	0f 85 11 01 00 00    	jne    39f519 <<oriole::Parser>::parse_text+0x2ee9>
  39f408:	fe 05 b0 91 24 00    	incb   0x2491b0(%rip)        # 5e85be <__start___sancov_cntrs+0x719e>
  39f40e:	bf 03 00 00 00       	mov    $0x3,%edi
  39f413:	44 89 fe             	mov    %r15d,%esi
  39f416:	e8 c5 b4 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f41b:	80 bb a8 00 00 00 03 	cmpb   $0x3,0xa8(%rbx)
  39f422:	0f 83 1f 1d 00 00    	jae    3a1147 <<oriole::Parser>::parse_text+0x4b17>
  39f428:	bf 03 00 00 00       	mov    $0x3,%edi
  39f42d:	44 89 e6             	mov    %r12d,%esi
  39f430:	e8 ab b4 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f435:	41 80 fc 03          	cmp    $0x3,%r12b
  39f439:	0f 83 17 1d 00 00    	jae    3a1156 <<oriole::Parser>::parse_text+0x4b26>
  39f43f:	48 8d 05 3a ff 19 00 	lea    0x19ff3a(%rip),%rax        # 53f380 <alloc_7884d1a34c9c0a3985957c2080036e69>
  39f446:	4e 8d 2c 38          	lea    (%rax,%r15,1),%r13
  39f44a:	4c 89 e8             	mov    %r13,%rax
  39f44d:	48 c1 e8 03          	shr    $0x3,%rax
  39f451:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39f458:	7f 
  39f459:	31 ff                	xor    %edi,%edi
  39f45b:	44 89 f6             	mov    %r14d,%esi
  39f45e:	e8 7d b4 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f463:	45 85 f6             	test   %r14d,%r14d
  39f466:	0f 85 19 1d 00 00    	jne    3a1185 <<oriole::Parser>::parse_text+0x4b55>
  39f46c:	fe 05 4f 91 24 00    	incb   0x24914f(%rip)        # 5e85c1 <__start___sancov_cntrs+0x71a1>
  39f472:	45 0f b6 6d 00       	movzbl 0x0(%r13),%r13d
  39f477:	44 3a a3 a8 00 00 00 	cmp    0xa8(%rbx),%r12b
  39f47e:	45 0f 47 fc          	cmova  %r12d,%r15d
  39f482:	48 8d 05 f7 fe 19 00 	lea    0x19fef7(%rip),%rax        # 53f380 <alloc_7884d1a34c9c0a3985957c2080036e69>
  39f489:	4c 01 e0             	add    %r12,%rax
  39f48c:	49 89 c4             	mov    %rax,%r12
  39f48f:	48 c1 e8 03          	shr    $0x3,%rax
  39f493:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39f49a:	7f 
  39f49b:	31 ff                	xor    %edi,%edi
  39f49d:	44 89 f6             	mov    %r14d,%esi
  39f4a0:	e8 3b b4 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f4a5:	45 85 f6             	test   %r14d,%r14d
  39f4a8:	0f 85 02 1d 00 00    	jne    3a11b0 <<oriole::Parser>::parse_text+0x4b80>
  39f4ae:	fe 05 10 91 24 00    	incb   0x249110(%rip)        # 5e85c4 <__start___sancov_cntrs+0x71a4>
  39f4b4:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
  39f4bb:	66 41 0f 6e c5       	movd   %r13d,%xmm0
  39f4c0:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
  39f4c4:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
  39f4c9:	66 0f 70 c0 44       	pshufd $0x44,%xmm0,%xmm0
  39f4ce:	66 0f 7f 43 70       	movdqa %xmm0,0x70(%rbx)
  39f4d3:	41 80 cf 10          	or     $0x10,%r15b
  39f4d7:	45 0f b6 f7          	movzbl %r15b,%r14d
  39f4db:	41 0f b6 04 24       	movzbl (%r12),%eax
  39f4e0:	66 0f 6e c0          	movd   %eax,%xmm0
  39f4e4:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
  39f4e8:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
  39f4ed:	66 0f 70 c0 44       	pshufd $0x44,%xmm0,%xmm0
  39f4f2:	66 0f 7f 83 b0 00 00 	movdqa %xmm0,0xb0(%rbx)
  39f4f9:	00 
  39f4fa:	48 8d 05 1f fc 0b 00 	lea    0xbfc1f(%rip),%rax        # 45f120 <memchr::memmem::searcher::searcher_kind_sse2>
  39f501:	48 89 43 08          	mov    %rax,0x8(%rbx)
  39f505:	4c 8b ab a8 00 00 00 	mov    0xa8(%rbx),%r13
  39f50c:	44 0f b6 a3 9c 00 00 	movzbl 0x9c(%rbx),%r12d
  39f513:	00 
  39f514:	e9 a5 00 00 00       	jmp    39f5be <<oriole::Parser>::parse_text+0x2f8e>
  39f519:	fe 05 9e 90 24 00    	incb   0x24909e(%rip)        # 5e85bd <__start___sancov_cntrs+0x719d>
  39f51f:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  39f523:	48 8d bb 20 01 00 00 	lea    0x120(%rbx),%rdi
  39f52a:	be 03 00 00 00       	mov    $0x3,%esi
  39f52f:	44 89 fa             	mov    %r15d,%edx
  39f532:	44 89 e1             	mov    %r12d,%ecx
  39f535:	e8 f6 48 fa ff       	call   343e30 <<memchr::arch::x86_64::avx2::packedpair::Finder>::with_pair_impl>
  39f53a:	fe 05 87 90 24 00    	incb   0x249087(%rip)        # 5e85c7 <__start___sancov_cntrs+0x71a7>
  39f540:	0f 28 83 20 01 00 00 	movaps 0x120(%rbx),%xmm0
  39f547:	0f 29 43 70          	movaps %xmm0,0x70(%rbx)
  39f54b:	66 0f 6f 83 30 01 00 	movdqa 0x130(%rbx),%xmm0
  39f552:	00 
  39f553:	66 0f 7f 83 b0 00 00 	movdqa %xmm0,0xb0(%rbx)
  39f55a:	00 
  39f55b:	4c 8b b3 40 01 00 00 	mov    0x140(%rbx),%r14
  39f562:	44 0f b6 ab 48 01 00 	movzbl 0x148(%rbx),%r13d
  39f569:	00 
  39f56a:	44 0f b6 a3 49 01 00 	movzbl 0x149(%rbx),%r12d
  39f571:	00 
  39f572:	48 8d b3 4a 01 00 00 	lea    0x14a(%rbx),%rsi
  39f579:	48 8d bb 12 02 00 00 	lea    0x212(%rbx),%rdi
  39f580:	ba 1e 00 00 00       	mov    $0x1e,%edx
  39f585:	e8 76 da e8 ff       	call   22d000 <__asan_memcpy>
  39f58a:	0f b6 83 68 01 00 00 	movzbl 0x168(%rbx),%eax
  39f591:	88 43 17             	mov    %al,0x17(%rbx)
  39f594:	48 8d b3 69 01 00 00 	lea    0x169(%rbx),%rsi
  39f59b:	48 8d bb 48 02 00 00 	lea    0x248(%rbx),%rdi
  39f5a2:	ba 57 00 00 00       	mov    $0x57,%edx
  39f5a7:	e8 54 da e8 ff       	call   22d000 <__asan_memcpy>
  39f5ac:	48 8d 05 1d f7 0b 00 	lea    0xbf71d(%rip),%rax        # 45ecd0 <memchr::memmem::searcher::searcher_kind_avx2>
  39f5b3:	48 89 43 08          	mov    %rax,0x8(%rbx)
  39f5b7:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
  39f5be:	49 89 cf             	mov    %rcx,%r15
  39f5c1:	48 8d b9 00 01 00 00 	lea    0x100(%rcx),%rdi
  39f5c8:	48 8d b3 f0 01 00 00 	lea    0x1f0(%rbx),%rsi
  39f5cf:	ba 18 00 00 00       	mov    $0x18,%edx
  39f5d4:	e8 27 da e8 ff       	call   22d000 <__asan_memcpy>
  39f5d9:	0f 28 43 70          	movaps 0x70(%rbx),%xmm0
  39f5dd:	41 0f 29 07          	movaps %xmm0,(%r15)
  39f5e1:	0f 28 83 b0 00 00 00 	movaps 0xb0(%rbx),%xmm0
  39f5e8:	41 0f 29 47 10       	movaps %xmm0,0x10(%r15)
  39f5ed:	4d 89 77 20          	mov    %r14,0x20(%r15)
  39f5f1:	45 88 6f 28          	mov    %r13b,0x28(%r15)
  39f5f5:	45 88 67 29          	mov    %r12b,0x29(%r15)
  39f5f9:	49 8d 7f 2a          	lea    0x2a(%r15),%rdi
  39f5fd:	48 8d b3 12 02 00 00 	lea    0x212(%rbx),%rsi
  39f604:	ba 1e 00 00 00       	mov    $0x1e,%edx
  39f609:	e8 f2 d9 e8 ff       	call   22d000 <__asan_memcpy>
  39f60e:	0f b6 43 17          	movzbl 0x17(%rbx),%eax
  39f612:	41 88 47 48          	mov    %al,0x48(%r15)
  39f616:	49 8d 7f 49          	lea    0x49(%r15),%rdi
  39f61a:	48 8d b3 48 02 00 00 	lea    0x248(%rbx),%rsi
  39f621:	ba 57 00 00 00       	mov    $0x57,%edx
  39f626:	e8 d5 d9 e8 ff       	call   22d000 <__asan_memcpy>
  39f62b:	49 8d bf a0 00 00 00 	lea    0xa0(%r15),%rdi
  39f632:	48 8d b3 20 01 00 00 	lea    0x120(%rbx),%rsi
  39f639:	ba 40 00 00 00       	mov    $0x40,%edx
  39f63e:	e8 bd d9 e8 ff       	call   22d000 <__asan_memcpy>
  39f643:	48 b8 6c 02 00 00 04 	movabs $0x40000026c,%rax
  39f64a:	00 00 00 
  39f64d:	49 89 87 e0 00 00 00 	mov    %rax,0xe0(%r15)
  39f654:	48 8b 43 08          	mov    0x8(%rbx),%rax
  39f658:	49 89 87 e8 00 00 00 	mov    %rax,0xe8(%r15)
  39f65f:	49 8d bf f0 00 00 00 	lea    0xf0(%r15),%rdi
  39f666:	48 8d b3 30 02 00 00 	lea    0x230(%rbx),%rsi
  39f66d:	ba 10 00 00 00       	mov    $0x10,%edx
  39f672:	e8 89 d9 e8 ff       	call   22d000 <__asan_memcpy>
  39f677:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  39f67e:	c6 40 38 00          	movb   $0x0,0x38(%rax)
  39f682:	4c 8b ab e8 01 00 00 	mov    0x1e8(%rbx),%r13
  39f689:	49 c7 45 00 01 00 00 	movq   $0x1,0x0(%r13)
  39f690:	00 
  39f691:	49 8b 87 00 01 00 00 	mov    0x100(%r15),%rax
  39f698:	48 89 43 70          	mov    %rax,0x70(%rbx)
  39f69c:	4d 8b a7 10 01 00 00 	mov    0x110(%r15),%r12
  39f6a3:	4c 8b 73 28          	mov    0x28(%rbx),%r14
  39f6a7:	4c 89 f7             	mov    %r14,%rdi
  39f6aa:	4c 89 e6             	mov    %r12,%rsi
  39f6ad:	e8 1e ae 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39f6b2:	4d 39 e6             	cmp    %r12,%r14
  39f6b5:	73 0b                	jae    39f6c2 <<oriole::Parser>::parse_text+0x3092>
  39f6b7:	fe 05 0f 8f 24 00    	incb   0x248f0f(%rip)        # 5e85cc <__start___sancov_cntrs+0x71ac>
  39f6bd:	45 31 f6             	xor    %r14d,%r14d
  39f6c0:	eb 46                	jmp    39f708 <<oriole::Parser>::parse_text+0x30d8>
  39f6c2:	49 8b 87 08 01 00 00 	mov    0x108(%r15),%rax
  39f6c9:	48 89 83 b0 00 00 00 	mov    %rax,0xb0(%rbx)
  39f6d0:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  39f6d4:	e8 d7 ad 11 00       	call   4ba4b0 <__sanitizer_cov_trace_pc_indir>
  39f6d9:	4c 89 ff             	mov    %r15,%rdi
  39f6dc:	4c 89 ee             	mov    %r13,%rsi
  39f6df:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39f6e3:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39f6e7:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
  39f6eb:	4c 89 f1             	mov    %r14,%rcx
  39f6ee:	4c 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%r8
  39f6f5:	4d 89 e1             	mov    %r12,%r9
  39f6f8:	ff 53 08             	call   *0x8(%rbx)
  39f6fb:	48 89 53 08          	mov    %rdx,0x8(%rbx)
  39f6ff:	49 89 c6             	mov    %rax,%r14
  39f702:	fe 05 db 8e 24 00    	incb   0x248edb(%rip)        # 5e85e3 <__start___sancov_cntrs+0x71c3>
  39f708:	4c 8b 7b 70          	mov    0x70(%rbx),%r15
  39f70c:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  39f713:	c6 40 38 f8          	movb   $0xf8,0x38(%rax)
  39f717:	31 ff                	xor    %edi,%edi
  39f719:	4c 89 fe             	mov    %r15,%rsi
  39f71c:	e8 4f ae 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39f721:	4d 85 ff             	test   %r15,%r15
  39f724:	74 49                	je     39f76f <<oriole::Parser>::parse_text+0x313f>
  39f726:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
  39f72d:	4c 8b a8 08 01 00 00 	mov    0x108(%rax),%r13
  39f734:	31 ff                	xor    %edi,%edi
  39f736:	4c 89 e6             	mov    %r12,%rsi
  39f739:	e8 32 ae 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39f73e:	4d 85 e4             	test   %r12,%r12
  39f741:	0f 88 5f 08 00 00    	js     39ffa6 <<oriole::Parser>::parse_text+0x3976>
  39f747:	31 ff                	xor    %edi,%edi
  39f749:	4c 89 e6             	mov    %r12,%rsi
  39f74c:	e8 1f ae 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39f751:	4d 85 e4             	test   %r12,%r12
  39f754:	74 21                	je     39f777 <<oriole::Parser>::parse_text+0x3147>
  39f756:	fe 05 8b 8e 24 00    	incb   0x248e8b(%rip)        # 5e85e7 <__start___sancov_cntrs+0x71c7>
  39f75c:	ba 01 00 00 00       	mov    $0x1,%edx
  39f761:	4c 89 ef             	mov    %r13,%rdi
  39f764:	4c 89 e6             	mov    %r12,%rsi
  39f767:	ff 15 ab d6 21 00    	call   *0x21d6ab(%rip)        # 5bce18 <_GLOBAL_OFFSET_TABLE_+0x1070>
  39f76d:	eb 0e                	jmp    39f77d <<oriole::Parser>::parse_text+0x314d>
  39f76f:	fe 05 6f 8e 24 00    	incb   0x248e6f(%rip)        # 5e85e4 <__start___sancov_cntrs+0x71c4>
  39f775:	eb 06                	jmp    39f77d <<oriole::Parser>::parse_text+0x314d>
  39f777:	fe 05 69 8e 24 00    	incb   0x248e69(%rip)        # 5e85e6 <__start___sancov_cntrs+0x71c6>
  39f77d:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  39f784:	48 b9 f8 f8 f8 f8 f8 	movabs $0xf8f8f8f8f8f8f8f8,%rcx
  39f78b:	f8 f8 f8 
  39f78e:	48 89 48 04          	mov    %rcx,0x4(%rax)
  39f792:	48 89 48 0c          	mov    %rcx,0xc(%rax)
  39f796:	48 89 48 14          	mov    %rcx,0x14(%rax)
  39f79a:	48 89 48 1c          	mov    %rcx,0x1c(%rax)
  39f79e:	c7 40 24 f8 f8 f8 f8 	movl   $0xf8f8f8f8,0x24(%rax)
  39f7a5:	4c 8b bb c8 00 00 00 	mov    0xc8(%rbx),%r15
  39f7ac:	4c 89 ff             	mov    %r15,%rdi
  39f7af:	4c 8b 63 08          	mov    0x8(%rbx),%r12
  39f7b3:	4c 89 e6             	mov    %r12,%rsi
  39f7b6:	e8 15 ad 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39f7bb:	4d 39 e7             	cmp    %r12,%r15
  39f7be:	0f 97 c0             	seta   %al
  39f7c1:	48 8b 8b d0 00 00 00 	mov    0xd0(%rbx),%rcx
  39f7c8:	f6 d1                	not    %cl
  39f7ca:	08 c1                	or     %al,%cl
  39f7cc:	41 20 ce             	and    %cl,%r14b
  39f7cf:	41 f6 c6 01          	test   $0x1,%r14b
  39f7d3:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39f7d7:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  39f7db:	74 49                	je     39f826 <<oriole::Parser>::parse_text+0x31f6>
  39f7dd:	fe 05 06 8e 24 00    	incb   0x248e06(%rip)        # 5e85e9 <__start___sancov_cntrs+0x71c9>
  39f7e3:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
  39f7ea:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39f7f1:	7f 
  39f7f2:	31 ff                	xor    %edi,%edi
  39f7f4:	44 89 f6             	mov    %r14d,%esi
  39f7f7:	e8 e4 b0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f7fc:	45 85 f6             	test   %r14d,%r14d
  39f7ff:	0f 85 d3 31 00 00    	jne    3a29d8 <<oriole::Parser>::parse_text+0x63a8>
  39f805:	48 8b 83 d8 00 00 00 	mov    0xd8(%rbx),%rax
  39f80c:	4c 8b 30             	mov    (%rax),%r14
  39f80f:	31 ff                	xor    %edi,%edi
  39f811:	4c 89 f6             	mov    %r14,%rsi
  39f814:	e8 57 ad 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39f819:	4d 85 f6             	test   %r14,%r14
  39f81c:	74 13                	je     39f831 <<oriole::Parser>::parse_text+0x3201>
  39f81e:	fe 05 c7 8d 24 00    	incb   0x248dc7(%rip)        # 5e85eb <__start___sancov_cntrs+0x71cb>
  39f824:	eb 4e                	jmp    39f874 <<oriole::Parser>::parse_text+0x3244>
  39f826:	fe 05 bc 8d 24 00    	incb   0x248dbc(%rip)        # 5e85e8 <__start___sancov_cntrs+0x71c8>
  39f82c:	e9 78 02 00 00       	jmp    39faa9 <<oriole::Parser>::parse_text+0x3479>
  39f831:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39f835:	4c 8d b0 4a 09 00 00 	lea    0x94a(%rax),%r14
  39f83c:	4c 89 f0             	mov    %r14,%rax
  39f83f:	48 c1 e8 03          	shr    $0x3,%rax
  39f843:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39f84a:	7f 
  39f84b:	31 ff                	xor    %edi,%edi
  39f84d:	44 89 fe             	mov    %r15d,%esi
  39f850:	e8 8b b0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f855:	45 85 ff             	test   %r15d,%r15d
  39f858:	0f 85 1a 1b 00 00    	jne    3a1378 <<oriole::Parser>::parse_text+0x4d48>
  39f85e:	fe 05 88 8d 24 00    	incb   0x248d88(%rip)        # 5e85ec <__start___sancov_cntrs+0x71cc>
  39f864:	41 80 3e 01          	cmpb   $0x1,(%r14)
  39f868:	0f 85 3d 1b 00 00    	jne    3a13ab <<oriole::Parser>::parse_text+0x4d7b>
  39f86e:	fe 05 7b 8d 24 00    	incb   0x248d7b(%rip)        # 5e85ef <__start___sancov_cntrs+0x71cf>
  39f874:	31 ff                	xor    %edi,%edi
  39f876:	4c 8b 73 08          	mov    0x8(%rbx),%r14
  39f87a:	4c 89 f6             	mov    %r14,%rsi
  39f87d:	e8 ee ac 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39f882:	4d 85 f6             	test   %r14,%r14
  39f885:	74 69                	je     39f8f0 <<oriole::Parser>::parse_text+0x32c0>
  39f887:	4c 89 f7             	mov    %r14,%rdi
  39f88a:	4c 89 e6             	mov    %r12,%rsi
  39f88d:	e8 3e ac 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39f892:	4d 39 e6             	cmp    %r12,%r14
  39f895:	73 64                	jae    39f8fb <<oriole::Parser>::parse_text+0x32cb>
  39f897:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39f89b:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39f89f:	48 01 c8             	add    %rcx,%rax
  39f8a2:	49 01 c6             	add    %rax,%r14
  39f8a5:	4c 89 f0             	mov    %r14,%rax
  39f8a8:	48 c1 e8 03          	shr    $0x3,%rax
  39f8ac:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39f8b3:	7f 
  39f8b4:	31 ff                	xor    %edi,%edi
  39f8b6:	44 89 fe             	mov    %r15d,%esi
  39f8b9:	e8 22 b0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f8be:	45 85 ff             	test   %r15d,%r15d
  39f8c1:	0f 85 9a 1e 00 00    	jne    3a1761 <<oriole::Parser>::parse_text+0x5131>
  39f8c7:	fe 05 30 8d 24 00    	incb   0x248d30(%rip)        # 5e85fd <__start___sancov_cntrs+0x71dd>
  39f8cd:	45 0f b6 36          	movzbl (%r14),%r14d
  39f8d1:	bf bf 00 00 00       	mov    $0xbf,%edi
  39f8d6:	44 89 f6             	mov    %r14d,%esi
  39f8d9:	e8 02 b0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f8de:	41 80 fe bf          	cmp    $0xbf,%r14b
  39f8e2:	0f 8e a7 1e 00 00    	jle    3a178f <<oriole::Parser>::parse_text+0x515f>
  39f8e8:	fe 05 13 8d 24 00    	incb   0x248d13(%rip)        # 5e8601 <__start___sancov_cntrs+0x71e1>
  39f8ee:	eb 25                	jmp    39f915 <<oriole::Parser>::parse_text+0x32e5>
  39f8f0:	fe 05 04 8d 24 00    	incb   0x248d04(%rip)        # 5e85fa <__start___sancov_cntrs+0x71da>
  39f8f6:	e9 20 04 00 00       	jmp    39fd1b <<oriole::Parser>::parse_text+0x36eb>
  39f8fb:	4c 89 f7             	mov    %r14,%rdi
  39f8fe:	4c 89 e6             	mov    %r12,%rsi
  39f901:	e8 ca ab 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39f906:	4d 39 e6             	cmp    %r12,%r14
  39f909:	0f 85 88 1e 00 00    	jne    3a1797 <<oriole::Parser>::parse_text+0x5167>
  39f90f:	fe 05 e7 8c 24 00    	incb   0x248ce7(%rip)        # 5e85fc <__start___sancov_cntrs+0x71dc>
  39f915:	4c 8b 6b 08          	mov    0x8(%rbx),%r13
  39f919:	4c 89 ef             	mov    %r13,%rdi
  39f91c:	4c 89 e6             	mov    %r12,%rsi
  39f91f:	e8 ac ab 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39f924:	4d 39 e5             	cmp    %r12,%r13
  39f927:	0f 87 6a 07 00 00    	ja     3a0097 <<oriole::Parser>::parse_text+0x3a67>
  39f92d:	48 83 bb f8 00 00 00 	cmpq   $0x1,0xf8(%rbx)
  39f934:	01 
  39f935:	48 8b 43 50          	mov    0x50(%rbx),%rax
  39f939:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  39f93d:	0f 86 8a 00 00 00    	jbe    39f9cd <<oriole::Parser>::parse_text+0x339d>
  39f943:	4c 8d 24 01          	lea    (%rcx,%rax,1),%r12
  39f947:	49 ff cc             	dec    %r12
  39f94a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  39f950:	4f 8d 34 2c          	lea    (%r12,%r13,1),%r14
  39f954:	4c 89 f0             	mov    %r14,%rax
  39f957:	48 c1 e8 03          	shr    $0x3,%rax
  39f95b:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39f962:	7f 
  39f963:	31 ff                	xor    %edi,%edi
  39f965:	44 89 fe             	mov    %r15d,%esi
  39f968:	e8 73 af 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f96d:	45 85 ff             	test   %r15d,%r15d
  39f970:	75 37                	jne    39f9a9 <<oriole::Parser>::parse_text+0x3379>
  39f972:	fe 05 9c 8c 24 00    	incb   0x248c9c(%rip)        # 5e8614 <__start___sancov_cntrs+0x71f4>
  39f978:	47 0f b6 34 2c       	movzbl (%r12,%r13,1),%r14d
  39f97d:	bf 0a 00 00 00       	mov    $0xa,%edi
  39f982:	44 89 f6             	mov    %r14d,%esi
  39f985:	e8 56 af 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39f98a:	41 83 fe 0a          	cmp    $0xa,%r14d
  39f98e:	0f 84 d7 00 00 00    	je     39fa6b <<oriole::Parser>::parse_text+0x343b>
  39f994:	49 83 fd 01          	cmp    $0x1,%r13
  39f998:	0f 84 d9 00 00 00    	je     39fa77 <<oriole::Parser>::parse_text+0x3447>
  39f99e:	fe 05 74 8c 24 00    	incb   0x248c74(%rip)        # 5e8618 <__start___sancov_cntrs+0x71f8>
  39f9a4:	49 ff cd             	dec    %r13
  39f9a7:	eb a7                	jmp    39f950 <<oriole::Parser>::parse_text+0x3320>
  39f9a9:	41 83 e6 07          	and    $0x7,%r14d
  39f9ad:	45 0f b6 ff          	movzbl %r15b,%r15d
  39f9b1:	44 89 f7             	mov    %r14d,%edi
  39f9b4:	44 89 fe             	mov    %r15d,%esi
  39f9b7:	e8 94 ae 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39f9bc:	45 38 fe             	cmp    %r15b,%r14b
  39f9bf:	0f 8d cf 30 00 00    	jge    3a2a94 <<oriole::Parser>::parse_text+0x6464>
  39f9c5:	fe 05 4a 8c 24 00    	incb   0x248c4a(%rip)        # 5e8615 <__start___sancov_cntrs+0x71f5>
  39f9cb:	eb ab                	jmp    39f978 <<oriole::Parser>::parse_text+0x3348>
  39f9cd:	4c 8d 34 01          	lea    (%rcx,%rax,1),%r14
  39f9d1:	49 ff ce             	dec    %r14
  39f9d4:	4c 89 e8             	mov    %r13,%rax
  39f9d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  39f9de:	00 00 
  39f9e0:	49 89 c5             	mov    %rax,%r13
  39f9e3:	4d 8d 24 06          	lea    (%r14,%rax,1),%r12
  39f9e7:	4c 89 e0             	mov    %r12,%rax
  39f9ea:	48 c1 e8 03          	shr    $0x3,%rax
  39f9ee:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39f9f5:	7f 
  39f9f6:	31 ff                	xor    %edi,%edi
  39f9f8:	44 89 fe             	mov    %r15d,%esi
  39f9fb:	e8 e0 ae 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39fa00:	45 85 ff             	test   %r15d,%r15d
  39fa03:	75 42                	jne    39fa47 <<oriole::Parser>::parse_text+0x3417>
  39fa05:	fe 05 0f 8c 24 00    	incb   0x248c0f(%rip)        # 5e861a <__start___sancov_cntrs+0x71fa>
  39fa0b:	47 0f b6 3c 2e       	movzbl (%r14,%r13,1),%r15d
  39fa10:	4c 89 ff             	mov    %r15,%rdi
  39fa13:	48 8d 35 06 2b 22 00 	lea    0x222b06(%rip),%rsi        # 5c2520 <__sancov_gen_cov_switch_values.2892>
  39fa1a:	e8 51 af 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  39fa1f:	41 83 ff 0a          	cmp    $0xa,%r15d
  39fa23:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39fa27:	74 59                	je     39fa82 <<oriole::Parser>::parse_text+0x3452>
  39fa29:	41 83 ff 0d          	cmp    $0xd,%r15d
  39fa2d:	74 5b                	je     39fa8a <<oriole::Parser>::parse_text+0x345a>
  39fa2f:	49 83 fd 01          	cmp    $0x1,%r13
  39fa33:	0f 84 dc 02 00 00    	je     39fd15 <<oriole::Parser>::parse_text+0x36e5>
  39fa39:	4c 89 e8             	mov    %r13,%rax
  39fa3c:	fe 05 dd 8b 24 00    	incb   0x248bdd(%rip)        # 5e861f <__start___sancov_cntrs+0x71ff>
  39fa42:	48 ff c8             	dec    %rax
  39fa45:	eb 99                	jmp    39f9e0 <<oriole::Parser>::parse_text+0x33b0>
  39fa47:	41 83 e4 07          	and    $0x7,%r12d
  39fa4b:	45 0f b6 ff          	movzbl %r15b,%r15d
  39fa4f:	44 89 e7             	mov    %r12d,%edi
  39fa52:	44 89 fe             	mov    %r15d,%esi
  39fa55:	e8 f6 ad 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  39fa5a:	45 38 fc             	cmp    %r15b,%r12b
  39fa5d:	0f 8d 01 30 00 00    	jge    3a2a64 <<oriole::Parser>::parse_text+0x6434>
  39fa63:	fe 05 b2 8b 24 00    	incb   0x248bb2(%rip)        # 5e861b <__start___sancov_cntrs+0x71fb>
  39fa69:	eb a0                	jmp    39fa0b <<oriole::Parser>::parse_text+0x33db>
  39fa6b:	fe 05 a6 8b 24 00    	incb   0x248ba6(%rip)        # 5e8617 <__start___sancov_cntrs+0x71f7>
  39fa71:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  39fa75:	eb 19                	jmp    39fa90 <<oriole::Parser>::parse_text+0x3460>
  39fa77:	fe 05 9c 8b 24 00    	incb   0x248b9c(%rip)        # 5e8619 <__start___sancov_cntrs+0x71f9>
  39fa7d:	e9 99 02 00 00       	jmp    39fd1b <<oriole::Parser>::parse_text+0x36eb>
  39fa82:	fe 05 96 8b 24 00    	incb   0x248b96(%rip)        # 5e861e <__start___sancov_cntrs+0x71fe>
  39fa88:	eb 06                	jmp    39fa90 <<oriole::Parser>::parse_text+0x3460>
  39fa8a:	fe 05 8d 8b 24 00    	incb   0x248b8d(%rip)        # 5e861d <__start___sancov_cntrs+0x71fd>
  39fa90:	31 ff                	xor    %edi,%edi
  39fa92:	4c 89 ee             	mov    %r13,%rsi
  39fa95:	e8 d6 aa 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39fa9a:	4d 85 ed             	test   %r13,%r13
  39fa9d:	0f 84 35 1c 00 00    	je     3a16d8 <<oriole::Parser>::parse_text+0x50a8>
  39faa3:	fe 05 78 8b 24 00    	incb   0x248b78(%rip)        # 5e8621 <__start___sancov_cntrs+0x7201>
  39faa9:	48 8b bb c8 00 00 00 	mov    0xc8(%rbx),%rdi
  39fab0:	4c 89 ee             	mov    %r13,%rsi
  39fab3:	49 89 fe             	mov    %rdi,%r14
  39fab6:	e8 15 aa 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39fabb:	f6 83 d0 00 00 00 01 	testb  $0x1,0xd0(%rbx)
  39fac2:	74 23                	je     39fae7 <<oriole::Parser>::parse_text+0x34b7>
  39fac4:	4c 89 f6             	mov    %r14,%rsi
  39fac7:	4d 39 ee             	cmp    %r13,%r14
  39faca:	73 1b                	jae    39fae7 <<oriole::Parser>::parse_text+0x34b7>
  39facc:	31 ff                	xor    %edi,%edi
  39face:	e8 9d aa 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39fad3:	4d 85 f6             	test   %r14,%r14
  39fad6:	0f 84 4d 01 00 00    	je     39fc29 <<oriole::Parser>::parse_text+0x35f9>
  39fadc:	fe 05 48 8b 24 00    	incb   0x248b48(%rip)        # 5e862a <__start___sancov_cntrs+0x720a>
  39fae2:	4d 89 f5             	mov    %r14,%r13
  39fae5:	eb 06                	jmp    39faed <<oriole::Parser>::parse_text+0x34bd>
  39fae7:	fe 05 44 8b 24 00    	incb   0x248b44(%rip)        # 5e8631 <__start___sancov_cntrs+0x7211>
  39faed:	4c 89 ef             	mov    %r13,%rdi
  39faf0:	4c 89 e6             	mov    %r12,%rsi
  39faf3:	e8 d8 a9 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39faf8:	4d 39 e5             	cmp    %r12,%r13
  39fafb:	4d 89 e6             	mov    %r12,%r14
  39fafe:	4c 8b 63 48          	mov    0x48(%rbx),%r12
  39fb02:	73 56                	jae    39fb5a <<oriole::Parser>::parse_text+0x352a>
  39fb04:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
  39fb0b:	4e 8d 34 28          	lea    (%rax,%r13,1),%r14
  39fb0f:	4c 89 f0             	mov    %r14,%rax
  39fb12:	48 c1 e8 03          	shr    $0x3,%rax
  39fb16:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39fb1d:	7f 
  39fb1e:	31 ff                	xor    %edi,%edi
  39fb20:	44 89 fe             	mov    %r15d,%esi
  39fb23:	e8 b8 ad 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39fb28:	45 85 ff             	test   %r15d,%r15d
  39fb2b:	0f 85 a6 07 00 00    	jne    3a02d7 <<oriole::Parser>::parse_text+0x3ca7>
  39fb31:	fe 05 fd 8a 24 00    	incb   0x248afd(%rip)        # 5e8634 <__start___sancov_cntrs+0x7214>
  39fb37:	45 0f b6 36          	movzbl (%r14),%r14d
  39fb3b:	bf bf 00 00 00       	mov    $0xbf,%edi
  39fb40:	44 89 f6             	mov    %r14d,%esi
  39fb43:	e8 98 ad 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39fb48:	41 80 fe bf          	cmp    $0xbf,%r14b
  39fb4c:	0f 8e b3 07 00 00    	jle    3a0305 <<oriole::Parser>::parse_text+0x3cd5>
  39fb52:	fe 05 e0 8a 24 00    	incb   0x248ae0(%rip)        # 5e8638 <__start___sancov_cntrs+0x7218>
  39fb58:	eb 1a                	jmp    39fb74 <<oriole::Parser>::parse_text+0x3544>
  39fb5a:	4c 89 ef             	mov    %r13,%rdi
  39fb5d:	4c 89 f6             	mov    %r14,%rsi
  39fb60:	e8 6b a9 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39fb65:	4d 39 f5             	cmp    %r14,%r13
  39fb68:	0f 85 9f 07 00 00    	jne    3a030d <<oriole::Parser>::parse_text+0x3cdd>
  39fb6e:	fe 05 bf 8a 24 00    	incb   0x248abf(%rip)        # 5e8633 <__start___sancov_cntrs+0x7213>
  39fb74:	4c 89 ef             	mov    %r13,%rdi
  39fb77:	4c 8b 73 18          	mov    0x18(%rbx),%r14
  39fb7b:	4c 89 f6             	mov    %r14,%rsi
  39fb7e:	e8 4d a9 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  39fb83:	4d 39 f5             	cmp    %r14,%r13
  39fb86:	0f 87 79 03 00 00    	ja     39ff05 <<oriole::Parser>::parse_text+0x38d5>
  39fb8c:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
  39fb93:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39fb9a:	7f 
  39fb9b:	31 ff                	xor    %edi,%edi
  39fb9d:	44 89 f6             	mov    %r14d,%esi
  39fba0:	e8 3b ad 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39fba5:	45 85 f6             	test   %r14d,%r14d
  39fba8:	0f 85 8d 2b 00 00    	jne    3a273b <<oriole::Parser>::parse_text+0x610b>
  39fbae:	48 8b 83 d8 00 00 00 	mov    0xd8(%rbx),%rax
  39fbb5:	4c 8b 30             	mov    (%rax),%r14
  39fbb8:	31 ff                	xor    %edi,%edi
  39fbba:	4c 89 f6             	mov    %r14,%rsi
  39fbbd:	e8 ae a9 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39fbc2:	4d 85 f6             	test   %r14,%r14
  39fbc5:	4c 89 6b 28          	mov    %r13,0x28(%rbx)
  39fbc9:	74 0b                	je     39fbd6 <<oriole::Parser>::parse_text+0x35a6>
  39fbcb:	fe 05 6a 8a 24 00    	incb   0x248a6a(%rip)        # 5e863b <__start___sancov_cntrs+0x721b>
  39fbd1:	e9 ca 08 00 00       	jmp    3a04a0 <<oriole::Parser>::parse_text+0x3e70>
  39fbd6:	48 8b 43 20          	mov    0x20(%rbx),%rax
  39fbda:	4c 8d b8 4a 09 00 00 	lea    0x94a(%rax),%r15
  39fbe1:	4c 89 f8             	mov    %r15,%rax
  39fbe4:	48 c1 e8 03          	shr    $0x3,%rax
  39fbe8:	48 89 43 08          	mov    %rax,0x8(%rbx)
  39fbec:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39fbf3:	7f 
  39fbf4:	31 ff                	xor    %edi,%edi
  39fbf6:	44 89 f6             	mov    %r14d,%esi
  39fbf9:	e8 e2 ac 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39fbfe:	45 85 f6             	test   %r14d,%r14d
  39fc01:	0f 85 81 07 00 00    	jne    3a0388 <<oriole::Parser>::parse_text+0x3d58>
  39fc07:	fe 05 2f 8a 24 00    	incb   0x248a2f(%rip)        # 5e863c <__start___sancov_cntrs+0x721c>
  39fc0d:	48 8b 8b 80 00 00 00 	mov    0x80(%rbx),%rcx
  39fc14:	41 80 3f 01          	cmpb   $0x1,(%r15)
  39fc18:	0f 85 a9 07 00 00    	jne    3a03c7 <<oriole::Parser>::parse_text+0x3d97>
  39fc1e:	fe 05 1b 8a 24 00    	incb   0x248a1b(%rip)        # 5e863f <__start___sancov_cntrs+0x721f>
  39fc24:	e9 77 08 00 00       	jmp    3a04a0 <<oriole::Parser>::parse_text+0x3e70>
  39fc29:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  39fc30:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39fc37:	7f 
  39fc38:	31 ff                	xor    %edi,%edi
  39fc3a:	44 89 f6             	mov    %r14d,%esi
  39fc3d:	e8 9e ac 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39fc42:	45 85 f6             	test   %r14d,%r14d
  39fc45:	0f 85 a1 2d 00 00    	jne    3a29ec <<oriole::Parser>::parse_text+0x63bc>
  39fc4b:	48 8b 43 48          	mov    0x48(%rbx),%rax
  39fc4f:	4c 8b 38             	mov    (%rax),%r15
  39fc52:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  39fc59:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39fc60:	7f 
  39fc61:	31 ff                	xor    %edi,%edi
  39fc63:	44 89 f6             	mov    %r14d,%esi
  39fc66:	e8 75 ac 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39fc6b:	45 85 f6             	test   %r14d,%r14d
  39fc6e:	0f 85 89 2d 00 00    	jne    3a29fd <<oriole::Parser>::parse_text+0x63cd>
  39fc74:	48 8b 43 38          	mov    0x38(%rbx),%rax
  39fc78:	4c 8b 30             	mov    (%rax),%r14
  39fc7b:	4c 89 fe             	mov    %r15,%rsi
  39fc7e:	48 83 e6 07          	and    $0x7,%rsi
  39fc82:	31 ff                	xor    %edi,%edi
  39fc84:	e8 e7 a8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39fc89:	4c 89 f8             	mov    %r15,%rax
  39fc8c:	48 83 e0 07          	and    $0x7,%rax
  39fc90:	0f 85 bf 03 00 00    	jne    3a0055 <<oriole::Parser>::parse_text+0x3a25>
  39fc96:	49 bc 55 55 55 55 55 	movabs $0x55555555555555,%r12
  39fc9d:	55 55 00 
  39fca0:	4c 89 e7             	mov    %r12,%rdi
  39fca3:	4c 89 f6             	mov    %r14,%rsi
  39fca6:	e8 c5 a8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39fcab:	4d 39 e6             	cmp    %r12,%r14
  39fcae:	0f 87 ac 03 00 00    	ja     3a0060 <<oriole::Parser>::parse_text+0x3a30>
  39fcb4:	31 ff                	xor    %edi,%edi
  39fcb6:	4c 89 f6             	mov    %r14,%rsi
  39fcb9:	e8 b2 a8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39fcbe:	4d 85 f6             	test   %r14,%r14
  39fcc1:	0f 84 a4 03 00 00    	je     3a006b <<oriole::Parser>::parse_text+0x3a3b>
  39fcc7:	fe 05 63 89 24 00    	incb   0x248963(%rip)        # 5e8630 <__start___sancov_cntrs+0x7210>
  39fccd:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
  39fcd1:	48 c1 e0 07          	shl    $0x7,%rax
  39fcd5:	49 8d 34 07          	lea    (%r15,%rax,1),%rsi
  39fcd9:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
  39fce0:	48 8d bb 30 01 00 00 	lea    0x130(%rbx),%rdi
  39fce7:	31 d2                	xor    %edx,%edx
  39fce9:	31 c9                	xor    %ecx,%ecx
  39fceb:	e8 70 8a fd ff       	call   378760 <<oriole::encoding::Source>::position_at>
  39fcf0:	c6 83 50 01 00 00 03 	movb   $0x3,0x150(%rbx)
  39fcf7:	48 8d 05 a2 38 1a 00 	lea    0x1a38a2(%rip),%rax        # 5435a0 <alloc_b61ebd6e475464cfc44c43b69770dded>
  39fcfe:	48 89 83 20 01 00 00 	mov    %rax,0x120(%rbx)
  39fd05:	48 c7 83 28 01 00 00 	movq   $0x1a,0x128(%rbx)
  39fd0c:	1a 00 00 00 
  39fd10:	e9 4f 19 00 00       	jmp    3a1664 <<oriole::Parser>::parse_text+0x5034>
  39fd15:	fe 05 05 89 24 00    	incb   0x248905(%rip)        # 5e8620 <__start___sancov_cntrs+0x7200>
  39fd1b:	48 c7 c7 fd ff ff ff 	mov    $0xfffffffffffffffd,%rdi
  39fd22:	4c 8b 73 08          	mov    0x8(%rbx),%r14
  39fd26:	4c 89 f6             	mov    %r14,%rsi
  39fd29:	e8 42 a8 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39fd2e:	49 83 fe fd          	cmp    $0xfffffffffffffffd,%r14
  39fd32:	0f 87 9a 15 00 00    	ja     3a12d2 <<oriole::Parser>::parse_text+0x4ca2>
  39fd38:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  39fd3f:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39fd46:	7f 
  39fd47:	31 ff                	xor    %edi,%edi
  39fd49:	44 89 f6             	mov    %r14d,%esi
  39fd4c:	e8 8f ab 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39fd51:	45 85 f6             	test   %r14d,%r14d
  39fd54:	0f 85 d4 2c 00 00    	jne    3a2a2e <<oriole::Parser>::parse_text+0x63fe>
  39fd5a:	48 8b 43 48          	mov    0x48(%rbx),%rax
  39fd5e:	4c 8b 38             	mov    (%rax),%r15
  39fd61:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  39fd68:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  39fd6f:	7f 
  39fd70:	31 ff                	xor    %edi,%edi
  39fd72:	44 89 f6             	mov    %r14d,%esi
  39fd75:	e8 66 ab 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39fd7a:	45 85 f6             	test   %r14d,%r14d
  39fd7d:	0f 85 bc 2c 00 00    	jne    3a2a3f <<oriole::Parser>::parse_text+0x640f>
  39fd83:	48 8b 43 38          	mov    0x38(%rbx),%rax
  39fd87:	4c 8b 30             	mov    (%rax),%r14
  39fd8a:	4c 89 fe             	mov    %r15,%rsi
  39fd8d:	48 83 e6 07          	and    $0x7,%rsi
  39fd91:	31 ff                	xor    %edi,%edi
  39fd93:	e8 d8 a7 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39fd98:	4c 89 f8             	mov    %r15,%rax
  39fd9b:	48 83 e0 07          	and    $0x7,%rax
  39fd9f:	0f 85 d1 02 00 00    	jne    3a0076 <<oriole::Parser>::parse_text+0x3a46>
  39fda5:	49 bc 55 55 55 55 55 	movabs $0x55555555555555,%r12
  39fdac:	55 55 00 
  39fdaf:	4c 89 e7             	mov    %r12,%rdi
  39fdb2:	4c 89 f6             	mov    %r14,%rsi
  39fdb5:	e8 b6 a7 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39fdba:	4d 39 e6             	cmp    %r12,%r14
  39fdbd:	0f 87 be 02 00 00    	ja     3a0081 <<oriole::Parser>::parse_text+0x3a51>
  39fdc3:	31 ff                	xor    %edi,%edi
  39fdc5:	4c 89 f6             	mov    %r14,%rsi
  39fdc8:	e8 a3 a7 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  39fdcd:	4d 85 f6             	test   %r14,%r14
  39fdd0:	48 8b 53 08          	mov    0x8(%rbx),%rdx
  39fdd4:	0f 84 b2 02 00 00    	je     3a008c <<oriole::Parser>::parse_text+0x3a5c>
  39fdda:	48 83 c2 02          	add    $0x2,%rdx
  39fdde:	fe 05 44 88 24 00    	incb   0x248844(%rip)        # 5e8628 <__start___sancov_cntrs+0x7208>
  39fde4:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
  39fde8:	48 c1 e0 07          	shl    $0x7,%rax
  39fdec:	49 8d 34 07          	lea    (%r15,%rax,1),%rsi
  39fdf0:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
  39fdf7:	48 8d bb 30 01 00 00 	lea    0x130(%rbx),%rdi
  39fdfe:	31 c9                	xor    %ecx,%ecx
  39fe00:	e8 5b 89 fd ff       	call   378760 <<oriole::encoding::Source>::position_at>
  39fe05:	c6 83 50 01 00 00 03 	movb   $0x3,0x150(%rbx)
  39fe0c:	48 8d 05 2d 37 1a 00 	lea    0x1a372d(%rip),%rax        # 543540 <alloc_673b5e78b1c830da9c900e2d906b0a28>
  39fe13:	48 89 83 20 01 00 00 	mov    %rax,0x120(%rbx)
  39fe1a:	48 c7 83 28 01 00 00 	movq   $0x22,0x128(%rbx)
  39fe21:	22 00 00 00 
  39fe25:	e9 3a 18 00 00       	jmp    3a1664 <<oriole::Parser>::parse_text+0x5034>
  39fe2a:	fe 05 7e 87 24 00    	incb   0x24877e(%rip)        # 5e85ae <__start___sancov_cntrs+0x718e>
  39fe30:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  39fe37:	c6 40 30 01          	movb   $0x1,0x30(%rax)
  39fe3b:	4c 8d 35 de c5 20 00 	lea    0x20c5de(%rip),%r14        # 5ac420 <alloc_56ef5b2968a7d4509c7a1dec21f86083>
  39fe42:	eb 52                	jmp    39fe96 <<oriole::Parser>::parse_text+0x3866>
  39fe44:	fe 05 b0 86 24 00    	incb   0x2486b0(%rip)        # 5e84fa <__start___sancov_cntrs+0x70da>
  39fe4a:	e9 aa 11 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39fe4f:	fe 05 a6 86 24 00    	incb   0x2486a6(%rip)        # 5e84fb <__start___sancov_cntrs+0x70db>
  39fe55:	e9 9f 11 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39fe5a:	fe 05 9c 86 24 00    	incb   0x24869c(%rip)        # 5e84fc <__start___sancov_cntrs+0x70dc>
  39fe60:	e9 ba 11 00 00       	jmp    3a101f <<oriole::Parser>::parse_text+0x49ef>
  39fe65:	fe 05 30 87 24 00    	incb   0x248730(%rip)        # 5e859b <__start___sancov_cntrs+0x717b>
  39fe6b:	e9 9b 00 00 00       	jmp    39ff0b <<oriole::Parser>::parse_text+0x38db>
  39fe70:	fe 05 41 87 24 00    	incb   0x248741(%rip)        # 5e85b7 <__start___sancov_cntrs+0x7197>
  39fe76:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  39fe7d:	c6 40 32 01          	movb   $0x1,0x32(%rax)
  39fe81:	4c 8d 35 58 c5 20 00 	lea    0x20c558(%rip),%r14        # 5ac3e0 <alloc_f2fa7d1aeaccae79237bcfd5a8ee512c>
  39fe88:	48 8b 83 d0 01 00 00 	mov    0x1d0(%rbx),%rax
  39fe8f:	48 89 83 e0 00 00 00 	mov    %rax,0xe0(%rbx)
  39fe96:	48 8b 83 e0 00 00 00 	mov    0xe0(%rbx),%rax
  39fe9d:	48 c1 e8 03          	shr    $0x3,%rax
  39fea1:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  39fea8:	7f 
  39fea9:	31 ff                	xor    %edi,%edi
  39feab:	44 89 fe             	mov    %r15d,%esi
  39feae:	e8 2d aa 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  39feb3:	45 85 ff             	test   %r15d,%r15d
  39feb6:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  39feba:	0f 85 5f 25 00 00    	jne    3a241f <<oriole::Parser>::parse_text+0x5def>
  39fec0:	fe 05 e9 86 24 00    	incb   0x2486e9(%rip)        # 5e85af <__start___sancov_cntrs+0x718f>
  39fec6:	4c 8b bb e0 00 00 00 	mov    0xe0(%rbx),%r15
  39fecd:	41 c6 07 02          	movb   $0x2,(%r15)
  39fed1:	e8 7a 92 e9 ff       	call   239150 <__asan_handle_no_return>
  39fed6:	48 8d 3d e3 fb 19 00 	lea    0x19fbe3(%rip),%rdi        # 53fac0 <alloc_00ae4b301f7fab8ac9617c03fcbd7274>
  39fedd:	48 8d 0d 5c e0 20 00 	lea    0x20e05c(%rip),%rcx        # 5adf40 <vtable.u>
  39fee4:	be 2b 00 00 00       	mov    $0x2b,%esi
  39fee9:	4c 89 fa             	mov    %r15,%rdx
  39feec:	4d 89 f0             	mov    %r14,%r8
  39feef:	ff 15 b3 ca 21 00    	call   *0x21cab3(%rip)        # 5bc9a8 <_GLOBAL_OFFSET_TABLE_+0xc00>
  39fef5:	e9 3e 19 00 00       	jmp    3a1838 <<oriole::Parser>::parse_text+0x5208>
  39fefa:	fe 05 07 86 24 00    	incb   0x248607(%rip)        # 5e8507 <__start___sancov_cntrs+0x70e7>
  39ff00:	e9 cd 00 00 00       	jmp    39ffd2 <<oriole::Parser>::parse_text+0x39a2>
  39ff05:	fe 05 2e 87 24 00    	incb   0x24872e(%rip)        # 5e8639 <__start___sancov_cntrs+0x7219>
  39ff0b:	e8 40 92 e9 ff       	call   239150 <__asan_handle_no_return>
  39ff10:	48 8d 3d a9 79 1a 00 	lea    0x1a79a9(%rip),%rdi        # 5478c0 <alloc_91f2a00ff2cd9cdc4bb205a66832e2bb>
  39ff17:	48 8d 0d c2 c0 20 00 	lea    0x20c0c2(%rip),%rcx        # 5abfe0 <alloc_fb1026e91cd6cbad2ad26a5919167617>
  39ff1e:	be b7 01 00 00       	mov    $0x1b7,%esi
  39ff23:	31 d2                	xor    %edx,%edx
  39ff25:	ff 15 4d d0 21 00    	call   *0x21d04d(%rip)        # 5bcf78 <_GLOBAL_OFFSET_TABLE_+0x11d0>
  39ff2b:	fe 05 7b 86 24 00    	incb   0x24867b(%rip)        # 5e85ac <__start___sancov_cntrs+0x718c>
  39ff31:	e8 1a 92 e9 ff       	call   239150 <__asan_handle_no_return>
  39ff36:	4c 8d 0d 63 c4 20 00 	lea    0x20c463(%rip),%r9        # 5ac3a0 <alloc_c8c1c7222b71ddfdc0b54607ac64c70c>
  39ff3d:	bf 01 00 00 00       	mov    $0x1,%edi
  39ff42:	48 8b b3 18 01 00 00 	mov    0x118(%rbx),%rsi
  39ff49:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
  39ff50:	31 c9                	xor    %ecx,%ecx
  39ff52:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  39ff56:	ff 15 34 c5 21 00    	call   *0x21c534(%rip)        # 5bc490 <_GLOBAL_OFFSET_TABLE_+0x6e8>
  39ff5c:	e9 d7 18 00 00       	jmp    3a1838 <<oriole::Parser>::parse_text+0x5208>
  39ff61:	fe 05 53 86 24 00    	incb   0x248653(%rip)        # 5e85ba <__start___sancov_cntrs+0x719a>
  39ff67:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  39ff6b:	ff 15 17 cb 21 00    	call   *0x21cb17(%rip)        # 5bca88 <_GLOBAL_OFFSET_TABLE_+0xce0>
  39ff71:	66 85 c0             	test   %ax,%ax
  39ff74:	0f 88 d0 00 00 00    	js     3a004a <<oriole::Parser>::parse_text+0x3a1a>
  39ff7a:	fe 05 3c 86 24 00    	incb   0x24863c(%rip)        # 5e85bc <__start___sancov_cntrs+0x719c>
  39ff80:	e9 89 f4 ff ff       	jmp    39f40e <<oriole::Parser>::parse_text+0x2dde>
  39ff85:	fe 05 ce 85 24 00    	incb   0x2485ce(%rip)        # 5e8559 <__start___sancov_cntrs+0x7139>
  39ff8b:	e9 69 10 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39ff90:	fe 05 c4 85 24 00    	incb   0x2485c4(%rip)        # 5e855a <__start___sancov_cntrs+0x713a>
  39ff96:	e9 5e 10 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  39ff9b:	fe 05 ba 85 24 00    	incb   0x2485ba(%rip)        # 5e855b <__start___sancov_cntrs+0x713b>
  39ffa1:	e9 79 10 00 00       	jmp    3a101f <<oriole::Parser>::parse_text+0x49ef>
  39ffa6:	fe 05 39 86 24 00    	incb   0x248639(%rip)        # 5e85e5 <__start___sancov_cntrs+0x71c5>
  39ffac:	e8 9f 91 e9 ff       	call   239150 <__asan_handle_no_return>
  39ffb1:	48 8d 3d 68 69 1a 00 	lea    0x1a6968(%rip),%rdi        # 546920 <alloc_8cf3531fd3c828ab298b686071a40c17>
  39ffb8:	48 8d 0d 41 6e 21 00 	lea    0x216e41(%rip),%rcx        # 5b6e00 <alloc_8005c7b3895921f0a67e83b881ed1b47>
  39ffbf:	be 07 02 00 00       	mov    $0x207,%esi
  39ffc4:	31 d2                	xor    %edx,%edx
  39ffc6:	ff 15 ac cf 21 00    	call   *0x21cfac(%rip)        # 5bcf78 <_GLOBAL_OFFSET_TABLE_+0x11d0>
  39ffcc:	fe 05 94 85 24 00    	incb   0x248594(%rip)        # 5e8566 <__start___sancov_cntrs+0x7146>
  39ffd2:	e8 79 91 e9 ff       	call   239150 <__asan_handle_no_return>
  39ffd7:	48 8d 3d e2 78 1a 00 	lea    0x1a78e2(%rip),%rdi        # 5478c0 <alloc_91f2a00ff2cd9cdc4bb205a66832e2bb>
  39ffde:	48 8d 0d 3b c0 20 00 	lea    0x20c03b(%rip),%rcx        # 5ac020 <alloc_65a5bc88b9804a020b4477aee28ec4de>
  39ffe5:	be b7 01 00 00       	mov    $0x1b7,%esi
  39ffea:	31 d2                	xor    %edx,%edx
  39ffec:	ff 15 86 cf 21 00    	call   *0x21cf86(%rip)        # 5bcf78 <_GLOBAL_OFFSET_TABLE_+0x11d0>
  39fff2:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  39fff9:	4c 8b 7b 08          	mov    0x8(%rbx),%r15
  39fffd:	4c 89 fe             	mov    %r15,%rsi
  3a0000:	e8 6b a5 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a0005:	4d 85 ff             	test   %r15,%r15
  3a0008:	0f 88 3c 17 00 00    	js     3a174a <<oriole::Parser>::parse_text+0x511a>
  3a000e:	4c 8b b3 c8 00 00 00 	mov    0xc8(%rbx),%r14
  3a0015:	4c 89 f7             	mov    %r14,%rdi
  3a0018:	4c 89 fe             	mov    %r15,%rsi
  3a001b:	e8 b0 a4 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  3a0020:	4d 39 fe             	cmp    %r15,%r14
  3a0023:	0f 96 c0             	setbe  %al
  3a0026:	84 83 d0 00 00 00    	test   %al,0xd0(%rbx)
  3a002c:	74 74                	je     3a00a2 <<oriole::Parser>::parse_text+0x3a72>
  3a002e:	fe 05 ac 85 24 00    	incb   0x2485ac(%rip)        # 5e85e0 <__start___sancov_cntrs+0x71c0>
  3a0034:	b0 01                	mov    $0x1,%al
  3a0036:	48 89 83 d0 00 00 00 	mov    %rax,0xd0(%rbx)
  3a003d:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a0041:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a0045:	e9 5f fa ff ff       	jmp    39faa9 <<oriole::Parser>::parse_text+0x3479>
  3a004a:	fe 05 6b 85 24 00    	incb   0x24856b(%rip)        # 5e85bb <__start___sancov_cntrs+0x719b>
  3a0050:	e9 ce f4 ff ff       	jmp    39f523 <<oriole::Parser>::parse_text+0x2ef3>
  3a0055:	fe 05 d2 85 24 00    	incb   0x2485d2(%rip)        # 5e862d <__start___sancov_cntrs+0x720d>
  3a005b:	e9 99 0f 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  3a0060:	fe 05 c8 85 24 00    	incb   0x2485c8(%rip)        # 5e862e <__start___sancov_cntrs+0x720e>
  3a0066:	e9 8e 0f 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  3a006b:	fe 05 be 85 24 00    	incb   0x2485be(%rip)        # 5e862f <__start___sancov_cntrs+0x720f>
  3a0071:	e9 a9 0f 00 00       	jmp    3a101f <<oriole::Parser>::parse_text+0x49ef>
  3a0076:	fe 05 a9 85 24 00    	incb   0x2485a9(%rip)        # 5e8625 <__start___sancov_cntrs+0x7205>
  3a007c:	e9 78 0f 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  3a0081:	fe 05 9f 85 24 00    	incb   0x24859f(%rip)        # 5e8626 <__start___sancov_cntrs+0x7206>
  3a0087:	e9 6d 0f 00 00       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  3a008c:	fe 05 95 85 24 00    	incb   0x248595(%rip)        # 5e8627 <__start___sancov_cntrs+0x7207>
  3a0092:	e9 88 0f 00 00       	jmp    3a101f <<oriole::Parser>::parse_text+0x49ef>
  3a0097:	fe 05 65 85 24 00    	incb   0x248565(%rip)        # 5e8602 <__start___sancov_cntrs+0x71e2>
  3a009d:	e9 69 fe ff ff       	jmp    39ff0b <<oriole::Parser>::parse_text+0x38db>
  3a00a2:	fe 05 37 85 24 00    	incb   0x248537(%rip)        # 5e85df <__start___sancov_cntrs+0x71bf>
  3a00a8:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a00ac:	e9 32 f7 ff ff       	jmp    39f7e3 <<oriole::Parser>::parse_text+0x31b3>
  3a00b1:	fe 05 63 84 24 00    	incb   0x248463(%rip)        # 5e851a <__start___sancov_cntrs+0x70fa>
  3a00b7:	e8 94 90 e9 ff       	call   239150 <__asan_handle_no_return>
  3a00bc:	48 8d 3d 5d ce 20 00 	lea    0x20ce5d(%rip),%rdi        # 5acf20 <alloc_3386b34d4e9344c86cf8c1c13353b2c0>
  3a00c3:	ff 15 2f c3 21 00    	call   *0x21c32f(%rip)        # 5bc3f8 <_GLOBAL_OFFSET_TABLE_+0x650>
  3a00c9:	fe 05 b7 84 24 00    	incb   0x2484b7(%rip)        # 5e8586 <__start___sancov_cntrs+0x7166>
  3a00cf:	e8 7c 90 e9 ff       	call   239150 <__asan_handle_no_return>
  3a00d4:	48 8d 3d 45 2e 21 00 	lea    0x212e45(%rip),%rdi        # 5b2f20 <alloc_75836350e07a9adef1d3323fc8777083>
  3a00db:	ff 15 17 c3 21 00    	call   *0x21c317(%rip)        # 5bc3f8 <_GLOBAL_OFFSET_TABLE_+0x650>
  3a00e1:	fe 05 a5 84 24 00    	incb   0x2484a5(%rip)        # 5e858c <__start___sancov_cntrs+0x716c>
  3a00e7:	e8 64 90 e9 ff       	call   239150 <__asan_handle_no_return>
  3a00ec:	49 ff ce             	dec    %r14
  3a00ef:	48 8d 15 6a 2e 21 00 	lea    0x212e6a(%rip),%rdx        # 5b2f60 <alloc_56feefbca570047d08b20a505307707b>
  3a00f6:	4c 89 f7             	mov    %r14,%rdi
  3a00f9:	48 8b 73 18          	mov    0x18(%rbx),%rsi
  3a00fd:	ff 15 e5 ce 21 00    	call   *0x21cee5(%rip)        # 5bcfe8 <_GLOBAL_OFFSET_TABLE_+0x1240>
  3a0103:	fe 05 1f 84 24 00    	incb   0x24841f(%rip)        # 5e8528 <__start___sancov_cntrs+0x7108>
  3a0109:	e8 42 90 e9 ff       	call   239150 <__asan_handle_no_return>
  3a010e:	48 8d 3d 0b ce 20 00 	lea    0x20ce0b(%rip),%rdi        # 5acf20 <alloc_3386b34d4e9344c86cf8c1c13353b2c0>
  3a0115:	ff 15 dd c2 21 00    	call   *0x21c2dd(%rip)        # 5bc3f8 <_GLOBAL_OFFSET_TABLE_+0x650>
  3a011b:	fe 05 80 84 24 00    	incb   0x248480(%rip)        # 5e85a1 <__start___sancov_cntrs+0x7181>
  3a0121:	e8 2a 90 e9 ff       	call   239150 <__asan_handle_no_return>
  3a0126:	48 8d 3d 13 6e 21 00 	lea    0x216e13(%rip),%rdi        # 5b6f40 <alloc_62bb409431e23c12d37f5b4caf8235ce>
  3a012d:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a0131:	ff 15 c1 c2 21 00    	call   *0x21c2c1(%rip)        # 5bc3f8 <_GLOBAL_OFFSET_TABLE_+0x650>
  3a0137:	e9 fc 16 00 00       	jmp    3a1838 <<oriole::Parser>::parse_text+0x5208>
  3a013c:	fe 05 f3 83 24 00    	incb   0x2483f3(%rip)        # 5e8535 <__start___sancov_cntrs+0x7115>
  3a0142:	e8 09 90 e9 ff       	call   239150 <__asan_handle_no_return>
  3a0147:	48 8d 3d d2 cd 20 00 	lea    0x20cdd2(%rip),%rdi        # 5acf20 <alloc_3386b34d4e9344c86cf8c1c13353b2c0>
  3a014e:	ff 15 a4 c2 21 00    	call   *0x21c2a4(%rip)        # 5bc3f8 <_GLOBAL_OFFSET_TABLE_+0x650>
  3a0154:	45 89 f4             	mov    %r14d,%r12d
  3a0157:	41 83 e4 07          	and    $0x7,%r12d
  3a015b:	45 0f b6 ff          	movzbl %r15b,%r15d
  3a015f:	44 89 e7             	mov    %r12d,%edi
  3a0162:	44 89 fe             	mov    %r15d,%esi
  3a0165:	e8 e6 a6 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a016a:	45 38 fc             	cmp    %r15b,%r12b
  3a016d:	0f 8d 82 2c 00 00    	jge    3a2df5 <<oriole::Parser>::parse_text+0x67c5>
  3a0173:	fe 05 94 83 24 00    	incb   0x248394(%rip)        # 5e850d <__start___sancov_cntrs+0x70ed>
  3a0179:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
  3a017d:	48 8b 53 50          	mov    0x50(%rbx),%rdx
  3a0181:	48 8b 73 40          	mov    0x40(%rbx),%rsi
  3a0185:	48 8d 04 32          	lea    (%rdx,%rsi,1),%rax
  3a0189:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a018d:	e9 52 da ff ff       	jmp    39dbe4 <<oriole::Parser>::parse_text+0x15b4>
  3a0192:	4c 8b 7b 58          	mov    0x58(%rbx),%r15
  3a0196:	41 83 e7 07          	and    $0x7,%r15d
  3a019a:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a019e:	44 89 ff             	mov    %r15d,%edi
  3a01a1:	44 89 f6             	mov    %r14d,%esi
  3a01a4:	e8 a7 a6 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a01a9:	45 38 f7             	cmp    %r14b,%r15b
  3a01ac:	0f 8d 53 2c 00 00    	jge    3a2e05 <<oriole::Parser>::parse_text+0x67d5>
  3a01b2:	fe 05 d6 83 24 00    	incb   0x2483d6(%rip)        # 5e858e <__start___sancov_cntrs+0x716e>
  3a01b8:	e9 d8 e9 ff ff       	jmp    39eb95 <<oriole::Parser>::parse_text+0x2565>
  3a01bd:	4d 89 fc             	mov    %r15,%r12
  3a01c0:	41 83 e7 07          	and    $0x7,%r15d
  3a01c4:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a01c8:	44 89 ff             	mov    %r15d,%edi
  3a01cb:	44 89 f6             	mov    %r14d,%esi
  3a01ce:	e8 7d a6 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a01d3:	45 38 f7             	cmp    %r14b,%r15b
  3a01d6:	0f 8d 3a 2c 00 00    	jge    3a2e16 <<oriole::Parser>::parse_text+0x67e6>
  3a01dc:	fe 05 af 83 24 00    	incb   0x2483af(%rip)        # 5e8591 <__start___sancov_cntrs+0x7171>
  3a01e2:	41 c6 04 24 ff       	movb   $0xff,(%r12)
  3a01e7:	e9 8d 14 00 00       	jmp    3a1679 <<oriole::Parser>::parse_text+0x5049>
  3a01ec:	45 89 ef             	mov    %r13d,%r15d
  3a01ef:	41 83 e7 07          	and    $0x7,%r15d
  3a01f3:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a01f7:	44 89 ff             	mov    %r15d,%edi
  3a01fa:	44 89 f6             	mov    %r14d,%esi
  3a01fd:	e8 4e a6 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a0202:	45 38 f7             	cmp    %r14b,%r15b
  3a0205:	0f 8d 1b 2c 00 00    	jge    3a2e26 <<oriole::Parser>::parse_text+0x67f6>
  3a020b:	fe 05 71 83 24 00    	incb   0x248371(%rip)        # 5e8582 <__start___sancov_cntrs+0x7162>
  3a0211:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a0215:	e9 f7 e7 ff ff       	jmp    39ea11 <<oriole::Parser>::parse_text+0x23e1>
  3a021a:	45 89 f4             	mov    %r14d,%r12d
  3a021d:	41 83 e4 07          	and    $0x7,%r12d
  3a0221:	45 0f b6 ff          	movzbl %r15b,%r15d
  3a0225:	44 89 e7             	mov    %r12d,%edi
  3a0228:	44 89 fe             	mov    %r15d,%esi
  3a022b:	e8 20 a6 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a0230:	45 38 fc             	cmp    %r15b,%r12b
  3a0233:	0f 8d fd 2b 00 00    	jge    3a2e36 <<oriole::Parser>::parse_text+0x6806>
  3a0239:	fe 05 57 83 24 00    	incb   0x248357(%rip)        # 5e8596 <__start___sancov_cntrs+0x7176>
  3a023f:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a0243:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a0247:	e9 da e9 ff ff       	jmp    39ec26 <<oriole::Parser>::parse_text+0x25f6>
  3a024c:	fe 05 46 83 24 00    	incb   0x248346(%rip)        # 5e8598 <__start___sancov_cntrs+0x7178>
  3a0252:	eb 06                	jmp    3a025a <<oriole::Parser>::parse_text+0x3c2a>
  3a0254:	fe 05 39 83 24 00    	incb   0x248339(%rip)        # 5e8593 <__start___sancov_cntrs+0x7173>
  3a025a:	e8 f1 8e e9 ff       	call   239150 <__asan_handle_no_return>
  3a025f:	4c 8d 05 3a 2d 21 00 	lea    0x212d3a(%rip),%r8        # 5b2fa0 <alloc_fc833f4423acc2039a90ab0073d19768>
  3a0266:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  3a026d:	48 8b 73 18          	mov    0x18(%rbx),%rsi
  3a0271:	31 d2                	xor    %edx,%edx
  3a0273:	48 8b 4b 28          	mov    0x28(%rbx),%rcx
  3a0277:	ff 15 3b c7 21 00    	call   *0x21c73b(%rip)        # 5bc9b8 <_GLOBAL_OFFSET_TABLE_+0xc10>
  3a027d:	4b 8d 04 27          	lea    (%r15,%r12,1),%rax
  3a0281:	89 c7                	mov    %eax,%edi
  3a0283:	83 e7 07             	and    $0x7,%edi
  3a0286:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
  3a028a:	45 0f b6 ed          	movzbl %r13b,%r13d
  3a028e:	44 89 ee             	mov    %r13d,%esi
  3a0291:	e8 ba a5 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a0296:	44 38 6b 70          	cmp    %r13b,0x70(%rbx)
  3a029a:	0f 8d a6 2b 00 00    	jge    3a2e46 <<oriole::Parser>::parse_text+0x6816>
  3a02a0:	fe 05 5c 82 24 00    	incb   0x24825c(%rip)        # 5e8502 <__start___sancov_cntrs+0x70e2>
  3a02a6:	e9 fa d7 ff ff       	jmp    39daa5 <<oriole::Parser>::parse_text+0x1475>
  3a02ab:	fe 05 53 82 24 00    	incb   0x248253(%rip)        # 5e8504 <__start___sancov_cntrs+0x70e4>
  3a02b1:	eb 06                	jmp    3a02b9 <<oriole::Parser>::parse_text+0x3c89>
  3a02b3:	fe 05 46 82 24 00    	incb   0x248246(%rip)        # 5e84ff <__start___sancov_cntrs+0x70df>
  3a02b9:	e8 92 8e e9 ff       	call   239150 <__asan_handle_no_return>
  3a02be:	4c 8d 05 db 1c 21 00 	lea    0x211cdb(%rip),%r8        # 5b1fa0 <alloc_0d86069ca8d9aba608a2c91e648a76f1>
  3a02c5:	4c 89 ff             	mov    %r15,%rdi
  3a02c8:	4c 89 f6             	mov    %r14,%rsi
  3a02cb:	4c 89 e2             	mov    %r12,%rdx
  3a02ce:	4c 89 f1             	mov    %r14,%rcx
  3a02d1:	ff 15 e1 c6 21 00    	call   *0x21c6e1(%rip)        # 5bc9b8 <_GLOBAL_OFFSET_TABLE_+0xc10>
  3a02d7:	45 89 f4             	mov    %r14d,%r12d
  3a02da:	41 83 e4 07          	and    $0x7,%r12d
  3a02de:	45 0f b6 ff          	movzbl %r15b,%r15d
  3a02e2:	44 89 e7             	mov    %r12d,%edi
  3a02e5:	44 89 fe             	mov    %r15d,%esi
  3a02e8:	e8 63 a5 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a02ed:	45 38 fc             	cmp    %r15b,%r12b
  3a02f0:	0f 8d 61 2b 00 00    	jge    3a2e57 <<oriole::Parser>::parse_text+0x6827>
  3a02f6:	fe 05 39 83 24 00    	incb   0x248339(%rip)        # 5e8635 <__start___sancov_cntrs+0x7215>
  3a02fc:	4c 8b 63 48          	mov    0x48(%rbx),%r12
  3a0300:	e9 32 f8 ff ff       	jmp    39fb37 <<oriole::Parser>::parse_text+0x3507>
  3a0305:	fe 05 2c 83 24 00    	incb   0x24832c(%rip)        # 5e8637 <__start___sancov_cntrs+0x7217>
  3a030b:	eb 06                	jmp    3a0313 <<oriole::Parser>::parse_text+0x3ce3>
  3a030d:	fe 05 1f 83 24 00    	incb   0x24831f(%rip)        # 5e8632 <__start___sancov_cntrs+0x7212>
  3a0313:	e8 38 8e e9 ff       	call   239150 <__asan_handle_no_return>
  3a0318:	4c 8d 05 c1 2d 21 00 	lea    0x212dc1(%rip),%r8        # 5b30e0 <alloc_9068586cc61f4ebb7c992395a7fdf2b6>
  3a031f:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  3a0326:	48 8b 73 18          	mov    0x18(%rbx),%rsi
  3a032a:	31 d2                	xor    %edx,%edx
  3a032c:	4c 89 e9             	mov    %r13,%rcx
  3a032f:	ff 15 83 c6 21 00    	call   *0x21c683(%rip)        # 5bc9b8 <_GLOBAL_OFFSET_TABLE_+0xc10>
  3a0335:	fe 05 15 82 24 00    	incb   0x248215(%rip)        # 5e8550 <__start___sancov_cntrs+0x7130>
  3a033b:	e8 10 8e e9 ff       	call   239150 <__asan_handle_no_return>
  3a0340:	48 8d 15 79 cf 20 00 	lea    0x20cf79(%rip),%rdx        # 5ad2c0 <alloc_5b1255b905c37b116e6590995751f340>
  3a0347:	31 ff                	xor    %edi,%edi
  3a0349:	31 f6                	xor    %esi,%esi
  3a034b:	ff 15 97 cc 21 00    	call   *0x21cc97(%rip)        # 5bcfe8 <_GLOBAL_OFFSET_TABLE_+0x1240>
  3a0351:	48 8b 43 50          	mov    0x50(%rbx),%rax
  3a0355:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  3a0359:	4c 8d 3c 08          	lea    (%rax,%rcx,1),%r15
  3a035d:	41 83 e7 07          	and    $0x7,%r15d
  3a0361:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a0365:	44 89 ff             	mov    %r15d,%edi
  3a0368:	44 89 f6             	mov    %r14d,%esi
  3a036b:	e8 e0 a4 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a0370:	45 38 f7             	cmp    %r14b,%r15b
  3a0373:	0f 8d ee 2a 00 00    	jge    3a2e67 <<oriole::Parser>::parse_text+0x6837>
  3a0379:	fe 05 cc 81 24 00    	incb   0x2481cc(%rip)        # 5e854b <__start___sancov_cntrs+0x712b>
  3a037f:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a0383:	e9 6b e2 ff ff       	jmp    39e5f3 <<oriole::Parser>::parse_text+0x1fc3>
  3a0388:	4c 89 7b 18          	mov    %r15,0x18(%rbx)
  3a038c:	41 83 e7 07          	and    $0x7,%r15d
  3a0390:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a0394:	44 89 ff             	mov    %r15d,%edi
  3a0397:	44 89 f6             	mov    %r14d,%esi
  3a039a:	e8 b1 a4 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a039f:	45 38 f7             	cmp    %r14b,%r15b
  3a03a2:	0f 8d d3 2a 00 00    	jge    3a2e7b <<oriole::Parser>::parse_text+0x684b>
  3a03a8:	fe 05 8f 82 24 00    	incb   0x24828f(%rip)        # 5e863d <__start___sancov_cntrs+0x721d>
  3a03ae:	4c 8b 63 48          	mov    0x48(%rbx),%r12
  3a03b2:	48 8b 8b 80 00 00 00 	mov    0x80(%rbx),%rcx
  3a03b9:	4c 8b 7b 18          	mov    0x18(%rbx),%r15
  3a03bd:	41 80 3f 01          	cmpb   $0x1,(%r15)
  3a03c1:	0f 84 57 f8 ff ff    	je     39fc1e <<oriole::Parser>::parse_text+0x35ee>
  3a03c7:	4a 8d 04 29          	lea    (%rcx,%r13,1),%rax
  3a03cb:	48 89 8b 20 01 00 00 	mov    %rcx,0x120(%rbx)
  3a03d2:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
  3a03d9:	48 8d bb 20 01 00 00 	lea    0x120(%rbx),%rdi
  3a03e0:	e8 2b 31 0a 00       	call   443510 <<core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next>
  3a03e5:	41 89 c5             	mov    %eax,%r13d
  3a03e8:	bf ff ff ff ff       	mov    $0xffffffff,%edi
  3a03ed:	89 c6                	mov    %eax,%esi
  3a03ef:	e8 ac a2 11 00       	call   4ba6a0 <__sanitizer_cov_trace_const_cmp4>
  3a03f4:	41 83 fd ff          	cmp    $0xffffffff,%r13d
  3a03f8:	0f 84 98 00 00 00    	je     3a0496 <<oriole::Parser>::parse_text+0x3e66>
  3a03fe:	4c 89 7b 18          	mov    %r15,0x18(%rbx)
  3a0402:	4c 8d 35 37 21 22 00 	lea    0x222137(%rip),%r14        # 5c2540 <__sancov_gen_cov_switch_values.2893>
  3a0409:	4c 8d 3d d0 c1 19 00 	lea    0x19c1d0(%rip),%r15        # 53c5e0 <switch.table._RNvCs26TCrUj5Hdw_12oriole_expat10run_events+0x1140>
  3a0410:	4c 8d a3 20 01 00 00 	lea    0x120(%rbx),%r12
  3a0417:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  3a041e:	00 00 
  3a0420:	44 89 ef             	mov    %r13d,%edi
  3a0423:	4c 89 f6             	mov    %r14,%rsi
  3a0426:	e8 45 a5 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  3a042b:	41 83 c5 f7          	add    $0xfffffff7,%r13d
  3a042f:	41 83 fd 17          	cmp    $0x17,%r13d
  3a0433:	0f 87 55 0b 00 00    	ja     3a0f8e <<oriole::Parser>::parse_text+0x495e>
  3a0439:	4b 63 04 af          	movslq (%r15,%r13,4),%rax
  3a043d:	4c 01 f8             	add    %r15,%rax
  3a0440:	ff e0                	jmp    *%rax
  3a0442:	fe 05 fb 81 24 00    	incb   0x2481fb(%rip)        # 5e8643 <__start___sancov_cntrs+0x7223>
  3a0448:	eb 2c                	jmp    3a0476 <<oriole::Parser>::parse_text+0x3e46>
  3a044a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  3a0450:	fe 05 eb 81 24 00    	incb   0x2481eb(%rip)        # 5e8641 <__start___sancov_cntrs+0x7221>
  3a0456:	eb 1e                	jmp    3a0476 <<oriole::Parser>::parse_text+0x3e46>
  3a0458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  3a045f:	00 
  3a0460:	fe 05 de 81 24 00    	incb   0x2481de(%rip)        # 5e8644 <__start___sancov_cntrs+0x7224>
  3a0466:	eb 0e                	jmp    3a0476 <<oriole::Parser>::parse_text+0x3e46>
  3a0468:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  3a046f:	00 
  3a0470:	fe 05 cc 81 24 00    	incb   0x2481cc(%rip)        # 5e8642 <__start___sancov_cntrs+0x7222>
  3a0476:	4c 89 e7             	mov    %r12,%rdi
  3a0479:	e8 92 30 0a 00       	call   443510 <<core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next>
  3a047e:	83 f8 ff             	cmp    $0xffffffff,%eax
  3a0481:	74 0b                	je     3a048e <<oriole::Parser>::parse_text+0x3e5e>
  3a0483:	41 89 c5             	mov    %eax,%r13d
  3a0486:	fe 05 b9 81 24 00    	incb   0x2481b9(%rip)        # 5e8645 <__start___sancov_cntrs+0x7225>
  3a048c:	eb 92                	jmp    3a0420 <<oriole::Parser>::parse_text+0x3df0>
  3a048e:	fe 05 b2 81 24 00    	incb   0x2481b2(%rip)        # 5e8646 <__start___sancov_cntrs+0x7226>
  3a0494:	eb 06                	jmp    3a049c <<oriole::Parser>::parse_text+0x3e6c>
  3a0496:	fe 05 a4 81 24 00    	incb   0x2481a4(%rip)        # 5e8640 <__start___sancov_cntrs+0x7220>
  3a049c:	4c 8b 63 48          	mov    0x48(%rbx),%r12
  3a04a0:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  3a04a7:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a04ae:	7f 
  3a04af:	31 ff                	xor    %edi,%edi
  3a04b1:	44 89 f6             	mov    %r14d,%esi
  3a04b4:	e8 27 a4 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a04b9:	45 85 f6             	test   %r14d,%r14d
  3a04bc:	0f 85 8d 22 00 00    	jne    3a274f <<oriole::Parser>::parse_text+0x611f>
  3a04c2:	4d 8b 34 24          	mov    (%r12),%r14
  3a04c6:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  3a04cd:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a04d4:	7f 
  3a04d5:	31 ff                	xor    %edi,%edi
  3a04d7:	44 89 fe             	mov    %r15d,%esi
  3a04da:	e8 01 a4 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a04df:	45 85 ff             	test   %r15d,%r15d
  3a04e2:	0f 85 77 22 00 00    	jne    3a275f <<oriole::Parser>::parse_text+0x612f>
  3a04e8:	48 8b 43 38          	mov    0x38(%rbx),%rax
  3a04ec:	4c 8b 38             	mov    (%rax),%r15
  3a04ef:	4c 89 f6             	mov    %r14,%rsi
  3a04f2:	48 83 e6 07          	and    $0x7,%rsi
  3a04f6:	31 ff                	xor    %edi,%edi
  3a04f8:	e8 73 a0 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a04fd:	4c 89 f0             	mov    %r14,%rax
  3a0500:	48 83 e0 07          	and    $0x7,%rax
  3a0504:	0f 85 e1 0a 00 00    	jne    3a0feb <<oriole::Parser>::parse_text+0x49bb>
  3a050a:	49 bc 55 55 55 55 55 	movabs $0x55555555555555,%r12
  3a0511:	55 55 00 
  3a0514:	4c 89 e7             	mov    %r12,%rdi
  3a0517:	4c 89 fe             	mov    %r15,%rsi
  3a051a:	e8 51 a0 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a051f:	4d 39 e7             	cmp    %r12,%r15
  3a0522:	0f 87 cb 0a 00 00    	ja     3a0ff3 <<oriole::Parser>::parse_text+0x49c3>
  3a0528:	31 ff                	xor    %edi,%edi
  3a052a:	4c 89 fe             	mov    %r15,%rsi
  3a052d:	e8 3e a0 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a0532:	4d 85 ff             	test   %r15,%r15
  3a0535:	0f 84 de 0a 00 00    	je     3a1019 <<oriole::Parser>::parse_text+0x49e9>
  3a053b:	4f 8d 2c 7f          	lea    (%r15,%r15,2),%r13
  3a053f:	49 c1 e5 07          	shl    $0x7,%r13
  3a0543:	4f 8d 3c 2e          	lea    (%r14,%r13,1),%r15
  3a0547:	49 81 c7 80 fe ff ff 	add    $0xfffffffffffffe80,%r15
  3a054e:	4c 89 f8             	mov    %r15,%rax
  3a0551:	48 c1 e8 03          	shr    $0x3,%rax
  3a0555:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a055c:	7f 
  3a055d:	31 ff                	xor    %edi,%edi
  3a055f:	44 89 e6             	mov    %r12d,%esi
  3a0562:	e8 79 a3 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0567:	45 85 e4             	test   %r12d,%r12d
  3a056a:	0f 85 00 22 00 00    	jne    3a2770 <<oriole::Parser>::parse_text+0x6140>
  3a0570:	4d 01 ee             	add    %r13,%r14
  3a0573:	41 83 3f 01          	cmpl   $0x1,(%r15)
  3a0577:	0f 85 de 00 00 00    	jne    3a065b <<oriole::Parser>::parse_text+0x402b>
  3a057d:	4d 8d be 88 fe ff ff 	lea    -0x178(%r14),%r15
  3a0584:	4c 89 f8             	mov    %r15,%rax
  3a0587:	48 c1 e8 03          	shr    $0x3,%rax
  3a058b:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a0592:	7f 
  3a0593:	31 ff                	xor    %edi,%edi
  3a0595:	44 89 e6             	mov    %r12d,%esi
  3a0598:	e8 43 a3 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a059d:	45 85 e4             	test   %r12d,%r12d
  3a05a0:	0f 85 68 23 00 00    	jne    3a290e <<oriole::Parser>::parse_text+0x62de>
  3a05a6:	49 8b 86 88 fe ff ff 	mov    -0x178(%r14),%rax
  3a05ad:	48 89 43 08          	mov    %rax,0x8(%rbx)
  3a05b1:	4d 8d be 90 fe ff ff 	lea    -0x170(%r14),%r15
  3a05b8:	4c 89 f8             	mov    %r15,%rax
  3a05bb:	48 c1 e8 03          	shr    $0x3,%rax
  3a05bf:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a05c6:	7f 
  3a05c7:	31 ff                	xor    %edi,%edi
  3a05c9:	44 89 e6             	mov    %r12d,%esi
  3a05cc:	e8 0f a3 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a05d1:	45 85 e4             	test   %r12d,%r12d
  3a05d4:	4c 8b 6b 58          	mov    0x58(%rbx),%r13
  3a05d8:	0f 85 40 23 00 00    	jne    3a291e <<oriole::Parser>::parse_text+0x62ee>
  3a05de:	49 8b 86 90 fe ff ff 	mov    -0x170(%r14),%rax
  3a05e5:	48 89 43 18          	mov    %rax,0x18(%rbx)
  3a05e9:	4d 8d be 98 fe ff ff 	lea    -0x168(%r14),%r15
  3a05f0:	4c 89 f8             	mov    %r15,%rax
  3a05f3:	48 c1 e8 03          	shr    $0x3,%rax
  3a05f7:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a05fe:	7f 
  3a05ff:	31 ff                	xor    %edi,%edi
  3a0601:	44 89 e6             	mov    %r12d,%esi
  3a0604:	e8 d7 a2 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0609:	45 85 e4             	test   %r12d,%r12d
  3a060c:	0f 85 1c 23 00 00    	jne    3a292e <<oriole::Parser>::parse_text+0x62fe>
  3a0612:	49 8b 86 98 fe ff ff 	mov    -0x168(%r14),%rax
  3a0619:	48 89 43 70          	mov    %rax,0x70(%rbx)
  3a061d:	49 81 c6 a0 fe ff ff 	add    $0xfffffffffffffea0,%r14
  3a0624:	4c 89 f0             	mov    %r14,%rax
  3a0627:	48 c1 e8 03          	shr    $0x3,%rax
  3a062b:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0632:	7f 
  3a0633:	31 ff                	xor    %edi,%edi
  3a0635:	44 89 fe             	mov    %r15d,%esi
  3a0638:	e8 a3 a2 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a063d:	45 85 ff             	test   %r15d,%r15d
  3a0640:	4c 8b a3 d8 00 00 00 	mov    0xd8(%rbx),%r12
  3a0647:	0f 85 f1 22 00 00    	jne    3a293e <<oriole::Parser>::parse_text+0x630e>
  3a064d:	fe 05 fe 7f 24 00    	incb   0x247ffe(%rip)        # 5e8651 <__start___sancov_cntrs+0x7231>
  3a0653:	4d 8b 36             	mov    (%r14),%r14
  3a0656:	e9 ab 00 00 00       	jmp    3a0706 <<oriole::Parser>::parse_text+0x40d6>
  3a065b:	4d 8d 66 a8          	lea    -0x58(%r14),%r12
  3a065f:	4c 89 e0             	mov    %r12,%rax
  3a0662:	48 c1 e8 03          	shr    $0x3,%rax
  3a0666:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  3a066d:	7f 
  3a066e:	31 ff                	xor    %edi,%edi
  3a0670:	44 89 ee             	mov    %r13d,%esi
  3a0673:	e8 68 a2 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0678:	45 85 ed             	test   %r13d,%r13d
  3a067b:	0f 85 cd 22 00 00    	jne    3a294e <<oriole::Parser>::parse_text+0x631e>
  3a0681:	49 8b 46 a8          	mov    -0x58(%r14),%rax
  3a0685:	48 89 43 08          	mov    %rax,0x8(%rbx)
  3a0689:	4d 8d 66 d8          	lea    -0x28(%r14),%r12
  3a068d:	4c 89 e0             	mov    %r12,%rax
  3a0690:	48 c1 e8 03          	shr    $0x3,%rax
  3a0694:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  3a069b:	7f 
  3a069c:	31 ff                	xor    %edi,%edi
  3a069e:	44 89 ee             	mov    %r13d,%esi
  3a06a1:	e8 3a a2 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a06a6:	45 85 ed             	test   %r13d,%r13d
  3a06a9:	0f 85 af 22 00 00    	jne    3a295e <<oriole::Parser>::parse_text+0x632e>
  3a06af:	49 8b 46 d8          	mov    -0x28(%r14),%rax
  3a06b3:	48 89 43 18          	mov    %rax,0x18(%rbx)
  3a06b7:	49 83 c6 e0          	add    $0xffffffffffffffe0,%r14
  3a06bb:	4c 89 f0             	mov    %r14,%rax
  3a06be:	48 c1 e8 03          	shr    $0x3,%rax
  3a06c2:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a06c9:	7f 
  3a06ca:	31 ff                	xor    %edi,%edi
  3a06cc:	44 89 e6             	mov    %r12d,%esi
  3a06cf:	e8 0c a2 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a06d4:	45 85 e4             	test   %r12d,%r12d
  3a06d7:	4c 8b 6b 58          	mov    0x58(%rbx),%r13
  3a06db:	0f 85 8d 22 00 00    	jne    3a296e <<oriole::Parser>::parse_text+0x633e>
  3a06e1:	fe 05 6e 7f 24 00    	incb   0x247f6e(%rip)        # 5e8655 <__start___sancov_cntrs+0x7235>
  3a06e7:	49 8b 06             	mov    (%r14),%rax
  3a06ea:	48 89 43 70          	mov    %rax,0x70(%rbx)
  3a06ee:	4c 89 ff             	mov    %r15,%rdi
  3a06f1:	31 f6                	xor    %esi,%esi
  3a06f3:	48 8b 53 28          	mov    0x28(%rbx),%rdx
  3a06f7:	e8 a4 da fd ff       	call   37e1a0 <<oriole::encoding::Source>::raw_len>
  3a06fc:	49 89 c6             	mov    %rax,%r14
  3a06ff:	4c 8b a3 d8 00 00 00 	mov    0xd8(%rbx),%r12
  3a0706:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
  3a070d:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0714:	7f 
  3a0715:	31 ff                	xor    %edi,%edi
  3a0717:	44 89 fe             	mov    %r15d,%esi
  3a071a:	e8 c1 a1 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a071f:	45 85 ff             	test   %r15d,%r15d
  3a0722:	0f 85 58 20 00 00    	jne    3a2780 <<oriole::Parser>::parse_text+0x6150>
  3a0728:	4d 8b 3c 24          	mov    (%r12),%r15
  3a072c:	31 ff                	xor    %edi,%edi
  3a072e:	4c 89 fe             	mov    %r15,%rsi
  3a0731:	e8 3a 9e 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a0736:	4d 85 ff             	test   %r15,%r15
  3a0739:	74 29                	je     3a0764 <<oriole::Parser>::parse_text+0x4134>
  3a073b:	fe 05 16 7f 24 00    	incb   0x247f16(%rip)        # 5e8657 <__start___sancov_cntrs+0x7237>
  3a0741:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  3a0748:	c7 80 80 00 00 00 00 	movl   $0x0,0x80(%rax)
  3a074f:	00 00 00 
  3a0752:	66 c7 80 84 00 00 00 	movw   $0x0,0x84(%rax)
  3a0759:	00 00 
  3a075b:	c6 80 86 00 00 00 00 	movb   $0x0,0x86(%rax)
  3a0762:	eb 6d                	jmp    3a07d1 <<oriole::Parser>::parse_text+0x41a1>
  3a0764:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a0768:	4c 8d b8 4a 09 00 00 	lea    0x94a(%rax),%r15
  3a076f:	4c 89 f8             	mov    %r15,%rax
  3a0772:	48 c1 e8 03          	shr    $0x3,%rax
  3a0776:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a077d:	7f 
  3a077e:	31 ff                	xor    %edi,%edi
  3a0780:	44 89 e6             	mov    %r12d,%esi
  3a0783:	e8 58 a1 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0788:	45 85 e4             	test   %r12d,%r12d
  3a078b:	0f 85 00 09 00 00    	jne    3a1091 <<oriole::Parser>::parse_text+0x4a61>
  3a0791:	fe 05 16 7f 24 00    	incb   0x247f16(%rip)        # 5e86ad <__start___sancov_cntrs+0x728d>
  3a0797:	41 0f b6 07          	movzbl (%r15),%eax
  3a079b:	48 8b 8b 88 00 00 00 	mov    0x88(%rbx),%rcx
  3a07a2:	c7 81 80 00 00 00 00 	movl   $0x0,0x80(%rcx)
  3a07a9:	00 00 00 
  3a07ac:	66 c7 81 84 00 00 00 	movw   $0x0,0x84(%rcx)
  3a07b3:	00 00 
  3a07b5:	c6 81 86 00 00 00 00 	movb   $0x0,0x86(%rcx)
  3a07bc:	3c 01                	cmp    $0x1,%al
  3a07be:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  3a07c5:	0f 85 bc 00 00 00    	jne    3a0887 <<oriole::Parser>::parse_text+0x4257>
  3a07cb:	fe 05 df 7e 24 00    	incb   0x247edf(%rip)        # 5e86b0 <__start___sancov_cntrs+0x7290>
  3a07d1:	48 8b 83 c8 01 00 00 	mov    0x1c8(%rbx),%rax
  3a07d8:	4c 8d 78 08          	lea    0x8(%rax),%r15
  3a07dc:	4c 89 f8             	mov    %r15,%rax
  3a07df:	48 c1 e8 03          	shr    $0x3,%rax
  3a07e3:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a07ea:	7f 
  3a07eb:	31 ff                	xor    %edi,%edi
  3a07ed:	44 89 e6             	mov    %r12d,%esi
  3a07f0:	e8 eb a0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a07f5:	45 85 e4             	test   %r12d,%r12d
  3a07f8:	0f 85 92 1f 00 00    	jne    3a2790 <<oriole::Parser>::parse_text+0x6160>
  3a07fe:	49 8b 0f             	mov    (%r15),%rcx
  3a0801:	48 8d bb 20 01 00 00 	lea    0x120(%rbx),%rdi
  3a0808:	48 8b 73 20          	mov    0x20(%rbx),%rsi
  3a080c:	48 8b 53 28          	mov    0x28(%rbx),%rdx
  3a0810:	e8 6b 1e 04 00       	call   3e2680 <<oriole::Parser>::prepare_character_data>
  3a0815:	48 8d b3 28 01 00 00 	lea    0x128(%rbx),%rsi
  3a081c:	44 0f b6 bb 20 01 00 	movzbl 0x120(%rbx),%r15d
  3a0823:	00 
  3a0824:	48 8d bb 48 02 00 00 	lea    0x248(%rbx),%rdi
  3a082b:	ba 38 00 00 00       	mov    $0x38,%edx
  3a0830:	e8 cb c7 e8 ff       	call   22d000 <__asan_memcpy>
  3a0835:	45 84 ff             	test   %r15b,%r15b
  3a0838:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  3a083f:	74 27                	je     3a0868 <<oriole::Parser>::parse_text+0x4238>
  3a0841:	fe 05 6c 7e 24 00    	incb   0x247e6c(%rip)        # 5e86b3 <__start___sancov_cntrs+0x7293>
  3a0847:	48 8d b3 48 02 00 00 	lea    0x248(%rbx),%rsi
  3a084e:	ba 38 00 00 00       	mov    $0x38,%edx
  3a0853:	4c 89 ef             	mov    %r13,%rdi
  3a0856:	e8 a5 c7 e8 ff       	call   22d000 <__asan_memcpy>
  3a085b:	4c 8b 73 68          	mov    0x68(%rbx),%r14
  3a085f:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a0863:	e9 25 11 00 00       	jmp    3a198d <<oriole::Parser>::parse_text+0x535d>
  3a0868:	fe 05 46 7e 24 00    	incb   0x247e46(%rip)        # 5e86b4 <__start___sancov_cntrs+0x7294>
  3a086e:	48 8d b3 48 02 00 00 	lea    0x248(%rbx),%rsi
  3a0875:	ba 38 00 00 00       	mov    $0x38,%edx
  3a087a:	4c 89 e7             	mov    %r12,%rdi
  3a087d:	e8 7e c7 e8 ff       	call   22d000 <__asan_memcpy>
  3a0882:	41 b5 01             	mov    $0x1,%r13b
  3a0885:	eb 11                	jmp    3a0898 <<oriole::Parser>::parse_text+0x4268>
  3a0887:	fe 05 24 7e 24 00    	incb   0x247e24(%rip)        # 5e86b1 <__start___sancov_cntrs+0x7291>
  3a088d:	49 c7 04 24 fe ff ff 	movq   $0xfffffffffffffffe,(%r12)
  3a0894:	ff 
  3a0895:	45 31 ed             	xor    %r13d,%r13d
  3a0898:	b0 01                	mov    $0x1,%al
  3a089a:	89 83 b0 00 00 00    	mov    %eax,0xb0(%rbx)
  3a08a0:	48 8d bb 20 01 00 00 	lea    0x120(%rbx),%rdi
  3a08a7:	48 8b 73 20          	mov    0x20(%rbx),%rsi
  3a08ab:	48 8b 53 28          	mov    0x28(%rbx),%rdx
  3a08af:	e8 9c d1 02 00       	call   3cda50 <<oriole::Parser>::save_current_raw>
  3a08b4:	44 0f b6 bb 50 01 00 	movzbl 0x150(%rbx),%r15d
  3a08bb:	00 
  3a08bc:	bf ff 00 00 00       	mov    $0xff,%edi
  3a08c1:	44 89 fe             	mov    %r15d,%esi
  3a08c4:	e8 17 a0 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a08c9:	41 81 ff ff 00 00 00 	cmp    $0xff,%r15d
  3a08d0:	74 47                	je     3a0919 <<oriole::Parser>::parse_text+0x42e9>
  3a08d2:	fe 05 de 7d 24 00    	incb   0x247dde(%rip)        # 5e86b6 <__start___sancov_cntrs+0x7296>
  3a08d8:	48 8d b3 20 01 00 00 	lea    0x120(%rbx),%rsi
  3a08df:	ba 38 00 00 00       	mov    $0x38,%edx
  3a08e4:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  3a08e8:	e8 13 c7 e8 ff       	call   22d000 <__asan_memcpy>
  3a08ed:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a08f1:	4d 8b 34 24          	mov    (%r12),%r14
  3a08f5:	48 c7 c7 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdi
  3a08fc:	4c 89 f6             	mov    %r14,%rsi
  3a08ff:	e8 6c 9c 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a0904:	49 83 fe fe          	cmp    $0xfffffffffffffffe,%r14
  3a0908:	0f 85 5a 02 00 00    	jne    3a0b68 <<oriole::Parser>::parse_text+0x4538>
  3a090e:	fe 05 bb 7d 24 00    	incb   0x247dbb(%rip)        # 5e86cf <__start___sancov_cntrs+0x72af>
  3a0914:	e9 70 10 00 00       	jmp    3a1989 <<oriole::Parser>::parse_text+0x5359>
  3a0919:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a091d:	4c 8d b8 46 09 00 00 	lea    0x946(%rax),%r15
  3a0924:	4c 89 f8             	mov    %r15,%rax
  3a0927:	48 c1 e8 03          	shr    $0x3,%rax
  3a092b:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a0932:	7f 
  3a0933:	31 ff                	xor    %edi,%edi
  3a0935:	44 89 e6             	mov    %r12d,%esi
  3a0938:	e8 a3 9f 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a093d:	45 85 e4             	test   %r12d,%r12d
  3a0940:	0f 85 ef 08 00 00    	jne    3a1235 <<oriole::Parser>::parse_text+0x4c05>
  3a0946:	fe 05 6b 7d 24 00    	incb   0x247d6b(%rip)        # 5e86b7 <__start___sancov_cntrs+0x7297>
  3a094c:	41 c6 07 00          	movb   $0x0,(%r15)
  3a0950:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  3a0957:	4d 8b 3c 24          	mov    (%r12),%r15
  3a095b:	48 c7 c7 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdi
  3a0962:	4c 89 fe             	mov    %r15,%rsi
  3a0965:	e8 06 9c 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a096a:	4c 89 7b 40          	mov    %r15,0x40(%rbx)
  3a096e:	49 83 ff fe          	cmp    $0xfffffffffffffffe,%r15
  3a0972:	0f 85 5b 02 00 00    	jne    3a0bd3 <<oriole::Parser>::parse_text+0x45a3>
  3a0978:	45 84 ed             	test   %r13b,%r13b
  3a097b:	0f 84 0c 04 00 00    	je     3a0d8d <<oriole::Parser>::parse_text+0x475d>
  3a0981:	4c 8b 7b 20          	mov    0x20(%rbx),%r15
  3a0985:	4d 8d a7 28 02 00 00 	lea    0x228(%r15),%r12
  3a098c:	4c 89 e0             	mov    %r12,%rax
  3a098f:	48 c1 e8 03          	shr    $0x3,%rax
  3a0993:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  3a099a:	7f 
  3a099b:	31 ff                	xor    %edi,%edi
  3a099d:	44 89 ee             	mov    %r13d,%esi
  3a09a0:	e8 3b 9f 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a09a5:	45 85 ed             	test   %r13d,%r13d
  3a09a8:	0f 85 64 21 00 00    	jne    3a2b12 <<oriole::Parser>::parse_text+0x64e2>
  3a09ae:	4d 8b a7 28 02 00 00 	mov    0x228(%r15),%r12
  3a09b5:	4d 8d af 30 02 00 00 	lea    0x230(%r15),%r13
  3a09bc:	4c 89 e8             	mov    %r13,%rax
  3a09bf:	48 c1 e8 03          	shr    $0x3,%rax
  3a09c3:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a09ca:	7f 
  3a09cb:	31 ff                	xor    %edi,%edi
  3a09cd:	44 89 fe             	mov    %r15d,%esi
  3a09d0:	e8 0b 9f 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a09d5:	45 85 ff             	test   %r15d,%r15d
  3a09d8:	0f 85 44 21 00 00    	jne    3a2b22 <<oriole::Parser>::parse_text+0x64f2>
  3a09de:	4d 8b 6d 00          	mov    0x0(%r13),%r13
  3a09e2:	4c 89 e7             	mov    %r12,%rdi
  3a09e5:	4c 89 ee             	mov    %r13,%rsi
  3a09e8:	e8 e3 9a 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  3a09ed:	4d 39 ec             	cmp    %r13,%r12
  3a09f0:	0f 82 23 0e 00 00    	jb     3a1819 <<oriole::Parser>::parse_text+0x51e9>
  3a09f6:	4c 89 e7             	mov    %r12,%rdi
  3a09f9:	4c 89 ee             	mov    %r13,%rsi
  3a09fc:	e8 cf 9a 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  3a0a01:	4d 39 ec             	cmp    %r13,%r12
  3a0a04:	0f 85 33 06 00 00    	jne    3a103d <<oriole::Parser>::parse_text+0x4a0d>
  3a0a0a:	4c 8b a3 c8 01 00 00 	mov    0x1c8(%rbx),%r12
  3a0a11:	49 83 c4 08          	add    $0x8,%r12
  3a0a15:	4c 89 e0             	mov    %r12,%rax
  3a0a18:	48 c1 e8 03          	shr    $0x3,%rax
  3a0a1c:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0a23:	7f 
  3a0a24:	31 ff                	xor    %edi,%edi
  3a0a26:	44 89 fe             	mov    %r15d,%esi
  3a0a29:	e8 b2 9e 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0a2e:	45 85 ff             	test   %r15d,%r15d
  3a0a31:	0f 85 fb 20 00 00    	jne    3a2b32 <<oriole::Parser>::parse_text+0x6502>
  3a0a37:	4d 8b 24 24          	mov    (%r12),%r12
  3a0a3b:	4d 85 e4             	test   %r12,%r12
  3a0a3e:	0f 84 29 06 00 00    	je     3a106d <<oriole::Parser>::parse_text+0x4a3d>
  3a0a44:	4d 8d ac 24 88 00 00 	lea    0x88(%r12),%r13
  3a0a4b:	00 
  3a0a4c:	4c 89 e8             	mov    %r13,%rax
  3a0a4f:	48 c1 e8 03          	shr    $0x3,%rax
  3a0a53:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0a5a:	7f 
  3a0a5b:	31 ff                	xor    %edi,%edi
  3a0a5d:	44 89 fe             	mov    %r15d,%esi
  3a0a60:	e8 7b 9e 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0a65:	45 85 ff             	test   %r15d,%r15d
  3a0a68:	0f 85 d4 20 00 00    	jne    3a2b42 <<oriole::Parser>::parse_text+0x6512>
  3a0a6e:	48 8b 43 08          	mov    0x8(%rbx),%rax
  3a0a72:	49 89 84 24 88 00 00 	mov    %rax,0x88(%r12)
  3a0a79:	00 
  3a0a7a:	4d 8d ac 24 90 00 00 	lea    0x90(%r12),%r13
  3a0a81:	00 
  3a0a82:	4c 89 e8             	mov    %r13,%rax
  3a0a85:	48 c1 e8 03          	shr    $0x3,%rax
  3a0a89:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0a90:	7f 
  3a0a91:	31 ff                	xor    %edi,%edi
  3a0a93:	44 89 fe             	mov    %r15d,%esi
  3a0a96:	e8 45 9e 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0a9b:	45 85 ff             	test   %r15d,%r15d
  3a0a9e:	0f 85 ae 20 00 00    	jne    3a2b52 <<oriole::Parser>::parse_text+0x6522>
  3a0aa4:	48 8b 43 18          	mov    0x18(%rbx),%rax
  3a0aa8:	49 89 84 24 90 00 00 	mov    %rax,0x90(%r12)
  3a0aaf:	00 
  3a0ab0:	4d 8d ac 24 98 00 00 	lea    0x98(%r12),%r13
  3a0ab7:	00 
  3a0ab8:	4c 89 e8             	mov    %r13,%rax
  3a0abb:	48 c1 e8 03          	shr    $0x3,%rax
  3a0abf:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0ac6:	7f 
  3a0ac7:	31 ff                	xor    %edi,%edi
  3a0ac9:	44 89 fe             	mov    %r15d,%esi
  3a0acc:	e8 0f 9e 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0ad1:	45 85 ff             	test   %r15d,%r15d
  3a0ad4:	0f 85 88 20 00 00    	jne    3a2b62 <<oriole::Parser>::parse_text+0x6532>
  3a0ada:	48 8b 43 70          	mov    0x70(%rbx),%rax
  3a0ade:	49 89 84 24 98 00 00 	mov    %rax,0x98(%r12)
  3a0ae5:	00 
  3a0ae6:	4d 8d ac 24 a0 00 00 	lea    0xa0(%r12),%r13
  3a0aed:	00 
  3a0aee:	4c 89 e8             	mov    %r13,%rax
  3a0af1:	48 c1 e8 03          	shr    $0x3,%rax
  3a0af5:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0afc:	7f 
  3a0afd:	31 ff                	xor    %edi,%edi
  3a0aff:	44 89 fe             	mov    %r15d,%esi
  3a0b02:	e8 d9 9d 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0b07:	45 85 ff             	test   %r15d,%r15d
  3a0b0a:	0f 85 62 20 00 00    	jne    3a2b72 <<oriole::Parser>::parse_text+0x6542>
  3a0b10:	4d 89 b4 24 a0 00 00 	mov    %r14,0xa0(%r12)
  3a0b17:	00 
  3a0b18:	49 81 c4 b0 00 00 00 	add    $0xb0,%r12
  3a0b1f:	4c 89 e0             	mov    %r12,%rax
  3a0b22:	48 c1 e8 03          	shr    $0x3,%rax
  3a0b26:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a0b2d:	7f 
  3a0b2e:	31 ff                	xor    %edi,%edi
  3a0b30:	44 89 f6             	mov    %r14d,%esi
  3a0b33:	e8 a8 9d 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0b38:	45 85 f6             	test   %r14d,%r14d
  3a0b3b:	0f 85 bf 0e 00 00    	jne    3a1a00 <<oriole::Parser>::parse_text+0x53d0>
  3a0b41:	fe 05 90 7b 24 00    	incb   0x247b90(%rip)        # 5e86d7 <__start___sancov_cntrs+0x72b7>
  3a0b47:	48 8b 53 28          	mov    0x28(%rbx),%rdx
  3a0b4b:	41 c6 04 24 01       	movb   $0x1,(%r12)
  3a0b50:	b0 01                	mov    $0x1,%al
  3a0b52:	89 83 b0 00 00 00    	mov    %eax,0xb0(%rbx)
  3a0b58:	48 8b 73 20          	mov    0x20(%rbx),%rsi
  3a0b5c:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  3a0b63:	e9 1f 0d 00 00       	jmp    3a1887 <<oriole::Parser>::parse_text+0x5257>
  3a0b68:	fe 05 60 7b 24 00    	incb   0x247b60(%rip)        # 5e86ce <__start___sancov_cntrs+0x72ae>
  3a0b6e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
  3a0b75:	4c 89 f6             	mov    %r14,%rsi
  3a0b78:	e8 f3 99 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a0b7d:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
  3a0b81:	0f 84 fb 01 00 00    	je     3a0d82 <<oriole::Parser>::parse_text+0x4752>
  3a0b87:	4d 8b 74 24 28       	mov    0x28(%r12),%r14
  3a0b8c:	31 ff                	xor    %edi,%edi
  3a0b8e:	4c 89 f6             	mov    %r14,%rsi
  3a0b91:	e8 da 99 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a0b96:	4d 85 f6             	test   %r14,%r14
  3a0b99:	0f 84 cb 03 00 00    	je     3a0f6a <<oriole::Parser>::parse_text+0x493a>
  3a0b9f:	31 ff                	xor    %edi,%edi
  3a0ba1:	4c 89 f6             	mov    %r14,%rsi
  3a0ba4:	e8 c7 99 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a0ba9:	4d 85 f6             	test   %r14,%r14
  3a0bac:	0f 88 0e 0c 00 00    	js     3a17c0 <<oriole::Parser>::parse_text+0x5190>
  3a0bb2:	fe 05 31 7b 24 00    	incb   0x247b31(%rip)        # 5e86e9 <__start___sancov_cntrs+0x72c9>
  3a0bb8:	49 8b 74 24 20       	mov    0x20(%r12),%rsi
  3a0bbd:	ba 01 00 00 00       	mov    $0x1,%edx
  3a0bc2:	4c 89 e7             	mov    %r12,%rdi
  3a0bc5:	4c 89 f1             	mov    %r14,%rcx
  3a0bc8:	ff 15 d2 b8 21 00    	call   *0x21b8d2(%rip)        # 5bc4a0 <_GLOBAL_OFFSET_TABLE_+0x6f8>
  3a0bce:	e9 b6 0d 00 00       	jmp    3a1989 <<oriole::Parser>::parse_text+0x5359>
  3a0bd3:	fe 05 e1 7a 24 00    	incb   0x247ae1(%rip)        # 5e86ba <__start___sancov_cntrs+0x729a>
  3a0bd9:	4c 8b bb e0 01 00 00 	mov    0x1e0(%rbx),%r15
  3a0be0:	49 8d 7f 40          	lea    0x40(%r15),%rdi
  3a0be4:	0f 57 c0             	xorps  %xmm0,%xmm0
  3a0be7:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  3a0bee:	0f 11 40 5e          	movups %xmm0,0x5e(%rax)
  3a0bf2:	48 c7 40 6e 00 00 00 	movq   $0x0,0x6e(%rax)
  3a0bf9:	00 
  3a0bfa:	66 c7 40 76 00 00    	movw   $0x0,0x76(%rax)
  3a0c00:	ba 38 00 00 00       	mov    $0x38,%edx
  3a0c05:	4c 89 e6             	mov    %r12,%rsi
  3a0c08:	e8 f3 c3 e8 ff       	call   22d000 <__asan_memcpy>
  3a0c0d:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a0c11:	48 8d b8 f8 01 00 00 	lea    0x1f8(%rax),%rdi
  3a0c18:	49 c7 47 38 0b 00 00 	movq   $0xb,0x38(%r15)
  3a0c1f:	00 
  3a0c20:	48 8b 43 08          	mov    0x8(%rbx),%rax
  3a0c24:	49 89 87 b0 00 00 00 	mov    %rax,0xb0(%r15)
  3a0c2b:	48 8b 43 18          	mov    0x18(%rbx),%rax
  3a0c2f:	49 89 87 b8 00 00 00 	mov    %rax,0xb8(%r15)
  3a0c36:	48 8b 43 70          	mov    0x70(%rbx),%rax
  3a0c3a:	49 89 87 c0 00 00 00 	mov    %rax,0xc0(%r15)
  3a0c41:	4d 89 b7 c8 00 00 00 	mov    %r14,0xc8(%r15)
  3a0c48:	49 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%r15)
  3a0c4f:	c7 83 b0 00 00 00 00 	movl   $0x0,0xb0(%rbx)
  3a0c56:	00 00 00 
  3a0c59:	4c 89 fe             	mov    %r15,%rsi
  3a0c5c:	e8 6f 35 f6 ff       	call   3041d0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
  3a0c61:	48 8b 8b 88 00 00 00 	mov    0x88(%rbx),%rcx
  3a0c68:	48 ba f8 f8 f8 f8 f8 	movabs $0xf8f8f8f8f8f8f8f8,%rdx
  3a0c6f:	f8 f8 f8 
  3a0c72:	48 89 51 5e          	mov    %rdx,0x5e(%rcx)
  3a0c76:	48 89 51 66          	mov    %rdx,0x66(%rcx)
  3a0c7a:	48 89 51 6e          	mov    %rdx,0x6e(%rcx)
  3a0c7e:	66 c7 41 76 f8 f8    	movw   $0xf8f8,0x76(%rcx)
  3a0c84:	44 0f b6 f0          	movzbl %al,%r14d
  3a0c88:	bf ff 00 00 00       	mov    $0xff,%edi
  3a0c8d:	44 89 f6             	mov    %r14d,%esi
  3a0c90:	e8 4b 9c 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0c95:	41 80 fe ff          	cmp    $0xff,%r14b
  3a0c99:	0f 84 d6 02 00 00    	je     3a0f75 <<oriole::Parser>::parse_text+0x4945>
  3a0c9f:	4c 8b 63 58          	mov    0x58(%rbx),%r12
  3a0ca3:	4c 89 e0             	mov    %r12,%rax
  3a0ca6:	48 c1 e8 03          	shr    $0x3,%rax
  3a0caa:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a0cb1:	7f 
  3a0cb2:	31 ff                	xor    %edi,%edi
  3a0cb4:	44 89 f6             	mov    %r14d,%esi
  3a0cb7:	e8 24 9c 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0cbc:	45 85 f6             	test   %r14d,%r14d
  3a0cbf:	0f 85 eb 1d 00 00    	jne    3a2ab0 <<oriole::Parser>::parse_text+0x6480>
  3a0cc5:	48 8d 05 f4 e8 19 00 	lea    0x19e8f4(%rip),%rax        # 53f5c0 <alloc_14f29c2f4fda19457ee7d97a2c7e61f1>
  3a0ccc:	49 89 04 24          	mov    %rax,(%r12)
  3a0cd0:	4d 8d 74 24 08       	lea    0x8(%r12),%r14
  3a0cd5:	4c 89 f0             	mov    %r14,%rax
  3a0cd8:	48 c1 e8 03          	shr    $0x3,%rax
  3a0cdc:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0ce3:	7f 
  3a0ce4:	31 ff                	xor    %edi,%edi
  3a0ce6:	44 89 fe             	mov    %r15d,%esi
  3a0ce9:	e8 f2 9b 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0cee:	45 85 ff             	test   %r15d,%r15d
  3a0cf1:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a0cf5:	0f 85 c5 1d 00 00    	jne    3a2ac0 <<oriole::Parser>::parse_text+0x6490>
  3a0cfb:	49 c7 44 24 08 0d 00 	movq   $0xd,0x8(%r12)
  3a0d02:	00 00 
  3a0d04:	4d 8d 74 24 10       	lea    0x10(%r12),%r14
  3a0d09:	4c 89 f0             	mov    %r14,%rax
  3a0d0c:	48 c1 e8 03          	shr    $0x3,%rax
  3a0d10:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0d17:	7f 
  3a0d18:	31 ff                	xor    %edi,%edi
  3a0d1a:	44 89 fe             	mov    %r15d,%esi
  3a0d1d:	e8 be 9b 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0d22:	45 85 ff             	test   %r15d,%r15d
  3a0d25:	0f 85 a5 1d 00 00    	jne    3a2ad0 <<oriole::Parser>::parse_text+0x64a0>
  3a0d2b:	49 c7 44 24 10 00 00 	movq   $0x0,0x10(%r12)
  3a0d32:	00 00 
  3a0d34:	4d 8d 74 24 18       	lea    0x18(%r12),%r14
  3a0d39:	4c 89 f0             	mov    %r14,%rax
  3a0d3c:	48 c1 e8 03          	shr    $0x3,%rax
  3a0d40:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0d47:	7f 
  3a0d48:	31 ff                	xor    %edi,%edi
  3a0d4a:	44 89 fe             	mov    %r15d,%esi
  3a0d4d:	e8 8e 9b 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0d52:	45 85 ff             	test   %r15d,%r15d
  3a0d55:	0f 85 85 1d 00 00    	jne    3a2ae0 <<oriole::Parser>::parse_text+0x64b0>
  3a0d5b:	fe 05 5f 79 24 00    	incb   0x24795f(%rip)        # 5e86c0 <__start___sancov_cntrs+0x72a0>
  3a0d61:	49 c7 44 24 18 01 00 	movq   $0x1,0x18(%r12)
  3a0d68:	00 00 
  3a0d6a:	49 83 c4 20          	add    $0x20,%r12
  3a0d6e:	ba 11 00 00 00       	mov    $0x11,%edx
  3a0d73:	4c 89 e7             	mov    %r12,%rdi
  3a0d76:	31 f6                	xor    %esi,%esi
  3a0d78:	e8 c3 c6 e8 ff       	call   22d440 <__asan_memset>
  3a0d7d:	e9 07 0c 00 00       	jmp    3a1989 <<oriole::Parser>::parse_text+0x5359>
  3a0d82:	fe 05 5e 79 24 00    	incb   0x24795e(%rip)        # 5e86e6 <__start___sancov_cntrs+0x72c6>
  3a0d88:	e9 fc 0b 00 00       	jmp    3a1989 <<oriole::Parser>::parse_text+0x5359>
  3a0d8d:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a0d91:	4c 8d a0 51 09 00 00 	lea    0x951(%rax),%r12
  3a0d98:	4c 89 e0             	mov    %r12,%rax
  3a0d9b:	48 c1 e8 03          	shr    $0x3,%rax
  3a0d9f:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  3a0da6:	7f 
  3a0da7:	31 ff                	xor    %edi,%edi
  3a0da9:	44 89 ee             	mov    %r13d,%esi
  3a0dac:	e8 2f 9b 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0db1:	45 85 ed             	test   %r13d,%r13d
  3a0db4:	0f 85 80 0a 00 00    	jne    3a183a <<oriole::Parser>::parse_text+0x520a>
  3a0dba:	fe 05 01 79 24 00    	incb   0x247901(%rip)        # 5e86c1 <__start___sancov_cntrs+0x72a1>
  3a0dc0:	41 80 3c 24 00       	cmpb   $0x0,(%r12)
  3a0dc5:	0f 84 9f 0a 00 00    	je     3a186a <<oriole::Parser>::parse_text+0x523a>
  3a0dcb:	fe 05 f6 78 24 00    	incb   0x2478f6(%rip)        # 5e86c7 <__start___sancov_cntrs+0x72a7>
  3a0dd1:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a0dd5:	48 8d b8 f8 01 00 00 	lea    0x1f8(%rax),%rdi
  3a0ddc:	0f 57 c0             	xorps  %xmm0,%xmm0
  3a0ddf:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  3a0de6:	0f 11 40 3c          	movups %xmm0,0x3c(%rax)
  3a0dea:	48 c7 40 4c 00 00 00 	movq   $0x0,0x4c(%rax)
  3a0df1:	00 
  3a0df2:	66 c7 40 54 00 00    	movw   $0x0,0x54(%rax)
  3a0df8:	48 8b b3 d8 01 00 00 	mov    0x1d8(%rbx),%rsi
  3a0dff:	48 c7 46 38 03 00 00 	movq   $0x3,0x38(%rsi)
  3a0e06:	00 
  3a0e07:	48 8b 43 08          	mov    0x8(%rbx),%rax
  3a0e0b:	48 89 86 b0 00 00 00 	mov    %rax,0xb0(%rsi)
  3a0e12:	48 8b 43 18          	mov    0x18(%rbx),%rax
  3a0e16:	48 89 86 b8 00 00 00 	mov    %rax,0xb8(%rsi)
  3a0e1d:	48 8b 43 70          	mov    0x70(%rbx),%rax
  3a0e21:	48 89 86 c0 00 00 00 	mov    %rax,0xc0(%rsi)
  3a0e28:	4c 89 b6 c8 00 00 00 	mov    %r14,0xc8(%rsi)
  3a0e2f:	48 c7 06 ff ff ff ff 	movq   $0xffffffffffffffff,(%rsi)
  3a0e36:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  3a0e3d:	e8 8e 33 f6 ff       	call   3041d0 <<oriole_storage::queue::Queue<oriole::PendingEvent>>::try_push_back>
  3a0e42:	48 8b 8b 88 00 00 00 	mov    0x88(%rbx),%rcx
  3a0e49:	48 ba f8 f8 f8 f8 f8 	movabs $0xf8f8f8f8f8f8f8f8,%rdx
  3a0e50:	f8 f8 f8 
  3a0e53:	48 89 51 3c          	mov    %rdx,0x3c(%rcx)
  3a0e57:	48 89 51 44          	mov    %rdx,0x44(%rcx)
  3a0e5b:	48 89 51 4c          	mov    %rdx,0x4c(%rcx)
  3a0e5f:	66 c7 41 54 f8 f8    	movw   $0xf8f8,0x54(%rcx)
  3a0e65:	44 0f b6 f0          	movzbl %al,%r14d
  3a0e69:	bf ff 00 00 00       	mov    $0xff,%edi
  3a0e6e:	44 89 f6             	mov    %r14d,%esi
  3a0e71:	e8 6a 9a 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0e76:	41 80 fe ff          	cmp    $0xff,%r14b
  3a0e7a:	0f 84 54 01 00 00    	je     3a0fd4 <<oriole::Parser>::parse_text+0x49a4>
  3a0e80:	4c 8b 63 58          	mov    0x58(%rbx),%r12
  3a0e84:	4c 89 e0             	mov    %r12,%rax
  3a0e87:	48 c1 e8 03          	shr    $0x3,%rax
  3a0e8b:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a0e92:	7f 
  3a0e93:	31 ff                	xor    %edi,%edi
  3a0e95:	44 89 f6             	mov    %r14d,%esi
  3a0e98:	e8 43 9a 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0e9d:	45 85 f6             	test   %r14d,%r14d
  3a0ea0:	0f 85 fe 1c 00 00    	jne    3a2ba4 <<oriole::Parser>::parse_text+0x6574>
  3a0ea6:	48 8d 05 13 e7 19 00 	lea    0x19e713(%rip),%rax        # 53f5c0 <alloc_14f29c2f4fda19457ee7d97a2c7e61f1>
  3a0ead:	49 89 04 24          	mov    %rax,(%r12)
  3a0eb1:	4d 8d 74 24 08       	lea    0x8(%r12),%r14
  3a0eb6:	4c 89 f0             	mov    %r14,%rax
  3a0eb9:	48 c1 e8 03          	shr    $0x3,%rax
  3a0ebd:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0ec4:	7f 
  3a0ec5:	31 ff                	xor    %edi,%edi
  3a0ec7:	44 89 fe             	mov    %r15d,%esi
  3a0eca:	e8 11 9a 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0ecf:	45 85 ff             	test   %r15d,%r15d
  3a0ed2:	0f 85 dc 1c 00 00    	jne    3a2bb4 <<oriole::Parser>::parse_text+0x6584>
  3a0ed8:	49 c7 44 24 08 0d 00 	movq   $0xd,0x8(%r12)
  3a0edf:	00 00 
  3a0ee1:	4d 8d 74 24 10       	lea    0x10(%r12),%r14
  3a0ee6:	4c 89 f0             	mov    %r14,%rax
  3a0ee9:	48 c1 e8 03          	shr    $0x3,%rax
  3a0eed:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0ef4:	7f 
  3a0ef5:	31 ff                	xor    %edi,%edi
  3a0ef7:	44 89 fe             	mov    %r15d,%esi
  3a0efa:	e8 e1 99 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0eff:	45 85 ff             	test   %r15d,%r15d
  3a0f02:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a0f06:	0f 85 b8 1c 00 00    	jne    3a2bc4 <<oriole::Parser>::parse_text+0x6594>
  3a0f0c:	49 c7 44 24 10 00 00 	movq   $0x0,0x10(%r12)
  3a0f13:	00 00 
  3a0f15:	4d 8d 74 24 18       	lea    0x18(%r12),%r14
  3a0f1a:	4c 89 f0             	mov    %r14,%rax
  3a0f1d:	48 c1 e8 03          	shr    $0x3,%rax
  3a0f21:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a0f28:	7f 
  3a0f29:	31 ff                	xor    %edi,%edi
  3a0f2b:	44 89 fe             	mov    %r15d,%esi
  3a0f2e:	e8 ad 99 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0f33:	45 85 ff             	test   %r15d,%r15d
  3a0f36:	0f 85 98 1c 00 00    	jne    3a2bd4 <<oriole::Parser>::parse_text+0x65a4>
  3a0f3c:	fe 05 8b 77 24 00    	incb   0x24778b(%rip)        # 5e86cd <__start___sancov_cntrs+0x72ad>
  3a0f42:	49 c7 44 24 18 01 00 	movq   $0x1,0x18(%r12)
  3a0f49:	00 00 
  3a0f4b:	49 83 c4 20          	add    $0x20,%r12
  3a0f4f:	ba 11 00 00 00       	mov    $0x11,%edx
  3a0f54:	4c 89 e7             	mov    %r12,%rdi
  3a0f57:	31 f6                	xor    %esi,%esi
  3a0f59:	e8 e2 c4 e8 ff       	call   22d440 <__asan_memset>
  3a0f5e:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  3a0f65:	e9 87 f9 ff ff       	jmp    3a08f1 <<oriole::Parser>::parse_text+0x42c1>
  3a0f6a:	fe 05 77 77 24 00    	incb   0x247777(%rip)        # 5e86e7 <__start___sancov_cntrs+0x72c7>
  3a0f70:	e9 14 0a 00 00       	jmp    3a1989 <<oriole::Parser>::parse_text+0x5359>
  3a0f75:	fe 05 40 77 24 00    	incb   0x247740(%rip)        # 5e86bb <__start___sancov_cntrs+0x729b>
  3a0f7b:	c7 83 b0 00 00 00 00 	movl   $0x0,0xb0(%rbx)
  3a0f82:	00 00 00 
  3a0f85:	48 8b 73 20          	mov    0x20(%rbx),%rsi
  3a0f89:	e9 f5 08 00 00       	jmp    3a1883 <<oriole::Parser>::parse_text+0x5253>
  3a0f8e:	48 8b 83 f0 00 00 00 	mov    0xf0(%rbx),%rax
  3a0f95:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a0f9c:	7f 
  3a0f9d:	31 ff                	xor    %edi,%edi
  3a0f9f:	44 89 f6             	mov    %r14d,%esi
  3a0fa2:	e8 39 99 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a0fa7:	45 85 f6             	test   %r14d,%r14d
  3a0faa:	0f 85 d7 0a 00 00    	jne    3a1a87 <<oriole::Parser>::parse_text+0x5457>
  3a0fb0:	fe 05 a2 76 24 00    	incb   0x2476a2(%rip)        # 5e8658 <__start___sancov_cntrs+0x7238>
  3a0fb6:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  3a0fba:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a0fbe:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  3a0fc3:	0f 85 f7 0a 00 00    	jne    3a1ac0 <<oriole::Parser>::parse_text+0x5490>
  3a0fc9:	fe 05 8c 76 24 00    	incb   0x24768c(%rip)        # 5e865b <__start___sancov_cntrs+0x723b>
  3a0fcf:	e9 88 0c 00 00       	jmp    3a1c5c <<oriole::Parser>::parse_text+0x562c>
  3a0fd4:	fe 05 ee 76 24 00    	incb   0x2476ee(%rip)        # 5e86c8 <__start___sancov_cntrs+0x72a8>
  3a0fda:	b0 01                	mov    $0x1,%al
  3a0fdc:	89 83 b0 00 00 00    	mov    %eax,0xb0(%rbx)
  3a0fe2:	48 8b 73 20          	mov    0x20(%rbx),%rsi
  3a0fe6:	e9 98 08 00 00       	jmp    3a1883 <<oriole::Parser>::parse_text+0x5253>
  3a0feb:	fe 05 58 76 24 00    	incb   0x247658(%rip)        # 5e8649 <__start___sancov_cntrs+0x7229>
  3a0ff1:	eb 06                	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  3a0ff3:	fe 05 51 76 24 00    	incb   0x247651(%rip)        # 5e864a <__start___sancov_cntrs+0x722a>
  3a0ff9:	e8 52 81 e9 ff       	call   239150 <__asan_handle_no_return>
  3a0ffe:	48 8d 3d fb 63 1a 00 	lea    0x1a63fb(%rip),%rdi        # 547400 <alloc_a28e8c8fd5088943a8b5d44af697ff83>
  3a1005:	48 8d 0d 94 b2 20 00 	lea    0x20b294(%rip),%rcx        # 5ac2a0 <alloc_51809824481ce4f1af1dc7cc7def0f02>
  3a100c:	be 2f 02 00 00       	mov    $0x22f,%esi
  3a1011:	31 d2                	xor    %edx,%edx
  3a1013:	ff 15 5f bf 21 00    	call   *0x21bf5f(%rip)        # 5bcf78 <_GLOBAL_OFFSET_TABLE_+0x11d0>
  3a1019:	fe 05 2c 76 24 00    	incb   0x24762c(%rip)        # 5e864b <__start___sancov_cntrs+0x722b>
  3a101f:	e8 2c 81 e9 ff       	call   239150 <__asan_handle_no_return>
  3a1024:	48 8d 3d f5 26 1a 00 	lea    0x1a26f5(%rip),%rdi        # 543720 <alloc_70757e6e192be8af32d7bc10927d4867>
  3a102b:	48 8d 15 ce 33 21 00 	lea    0x2133ce(%rip),%rdx        # 5b4400 <alloc_d75f96c5e4808a656694f19735a1c5c4>
  3a1032:	be 21 00 00 00       	mov    $0x21,%esi
  3a1037:	ff 15 db b3 21 00    	call   *0x21b3db(%rip)        # 5bc418 <_GLOBAL_OFFSET_TABLE_+0x670>
  3a103d:	fe 05 8f 76 24 00    	incb   0x24768f(%rip)        # 5e86d2 <__start___sancov_cntrs+0x72b2>
  3a1043:	e8 08 81 e9 ff       	call   239150 <__asan_handle_no_return>
  3a1048:	48 8d 3d 31 04 1a 00 	lea    0x1a0431(%rip),%rdi        # 541480 <alloc_f48df30bbf8dd3dc81b6ddec7dbff6bc>
  3a104f:	48 8d 15 0a 21 21 00 	lea    0x21210a(%rip),%rdx        # 5b3160 <alloc_821042ff25e1788aa76ce4991a5bc533>
  3a1056:	be 29 00 00 00       	mov    $0x29,%esi
  3a105b:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  3a1062:	ff 15 10 bb 21 00    	call   *0x21bb10(%rip)        # 5bcb78 <_GLOBAL_OFFSET_TABLE_+0xdd0>
  3a1068:	e9 cb 07 00 00       	jmp    3a1838 <<oriole::Parser>::parse_text+0x5208>
  3a106d:	fe 05 67 76 24 00    	incb   0x247667(%rip)        # 5e86da <__start___sancov_cntrs+0x72ba>
  3a1073:	e8 d8 80 e9 ff       	call   239150 <__asan_handle_no_return>
  3a1078:	48 8d 3d a1 20 21 00 	lea    0x2120a1(%rip),%rdi        # 5b3120 <alloc_5b537ac2adcb5f106f0ab84a6f31b838>
  3a107f:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  3a1086:	ff 15 3c b9 21 00    	call   *0x21b93c(%rip)        # 5bc9c8 <_GLOBAL_OFFSET_TABLE_+0xc20>
  3a108c:	e9 a7 07 00 00       	jmp    3a1838 <<oriole::Parser>::parse_text+0x5208>
  3a1091:	45 89 fd             	mov    %r15d,%r13d
  3a1094:	41 83 e5 07          	and    $0x7,%r13d
  3a1098:	45 0f b6 e4          	movzbl %r12b,%r12d
  3a109c:	44 89 ef             	mov    %r13d,%edi
  3a109f:	44 89 e6             	mov    %r12d,%esi
  3a10a2:	e8 a9 97 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a10a7:	45 38 e5             	cmp    %r12b,%r13b
  3a10aa:	0f 8d dc 1d 00 00    	jge    3a2e8c <<oriole::Parser>::parse_text+0x685c>
  3a10b0:	fe 05 f8 75 24 00    	incb   0x2475f8(%rip)        # 5e86ae <__start___sancov_cntrs+0x728e>
  3a10b6:	4c 8b 6b 58          	mov    0x58(%rbx),%r13
  3a10ba:	e9 d8 f6 ff ff       	jmp    3a0797 <<oriole::Parser>::parse_text+0x4167>
  3a10bf:	48 8b 43 50          	mov    0x50(%rbx),%rax
  3a10c3:	48 8b 4b 40          	mov    0x40(%rbx),%rcx
  3a10c7:	4c 8d 3c 08          	lea    (%rax,%rcx,1),%r15
  3a10cb:	41 83 e7 07          	and    $0x7,%r15d
  3a10cf:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a10d3:	44 89 ff             	mov    %r15d,%edi
  3a10d6:	44 89 f6             	mov    %r14d,%esi
  3a10d9:	e8 72 97 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a10de:	45 38 f7             	cmp    %r14b,%r15b
  3a10e1:	0f 8d b5 1d 00 00    	jge    3a2e9c <<oriole::Parser>::parse_text+0x686c>
  3a10e7:	fe 05 e1 74 24 00    	incb   0x2474e1(%rip)        # 5e85ce <__start___sancov_cntrs+0x71ae>
  3a10ed:	e9 54 e0 ff ff       	jmp    39f146 <<oriole::Parser>::parse_text+0x2b16>
  3a10f2:	45 89 f4             	mov    %r14d,%r12d
  3a10f5:	41 83 e4 07          	and    $0x7,%r12d
  3a10f9:	45 0f b6 ff          	movzbl %r15b,%r15d
  3a10fd:	44 89 e7             	mov    %r12d,%edi
  3a1100:	44 89 fe             	mov    %r15d,%esi
  3a1103:	e8 48 97 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1108:	45 38 fc             	cmp    %r15b,%r12b
  3a110b:	0f 8d 9f 1d 00 00    	jge    3a2eb0 <<oriole::Parser>::parse_text+0x6880>
  3a1111:	fe 05 ba 74 24 00    	incb   0x2474ba(%rip)        # 5e85d1 <__start___sancov_cntrs+0x71b1>
  3a1117:	e9 65 e0 ff ff       	jmp    39f181 <<oriole::Parser>::parse_text+0x2b51>
  3a111c:	44 89 f7             	mov    %r14d,%edi
  3a111f:	83 e7 07             	and    $0x7,%edi
  3a1122:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
  3a1126:	45 0f b6 ff          	movzbl %r15b,%r15d
  3a112a:	44 89 fe             	mov    %r15d,%esi
  3a112d:	e8 1e 97 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1132:	44 38 7b 08          	cmp    %r15b,0x8(%rbx)
  3a1136:	0f 8d 84 1d 00 00    	jge    3a2ec0 <<oriole::Parser>::parse_text+0x6890>
  3a113c:	fe 05 92 74 24 00    	incb   0x247492(%rip)        # 5e85d4 <__start___sancov_cntrs+0x71b4>
  3a1142:	e9 76 e0 ff ff       	jmp    39f1bd <<oriole::Parser>::parse_text+0x2b8d>
  3a1147:	fe 05 72 74 24 00    	incb   0x247472(%rip)        # 5e85bf <__start___sancov_cntrs+0x719f>
  3a114d:	4c 8d 35 2c ee 20 00 	lea    0x20ee2c(%rip),%r14        # 5aff80 <alloc_a5febd05657ae250c643e16598a1adcf>
  3a1154:	eb 10                	jmp    3a1166 <<oriole::Parser>::parse_text+0x4b36>
  3a1156:	fe 05 64 74 24 00    	incb   0x247464(%rip)        # 5e85c0 <__start___sancov_cntrs+0x71a0>
  3a115c:	4c 8d 35 5d ee 20 00 	lea    0x20ee5d(%rip),%r14        # 5affc0 <alloc_43d04a9abca6911246fda7cd440bb1b7>
  3a1163:	4d 89 e7             	mov    %r12,%r15
  3a1166:	e8 e5 7f e9 ff       	call   239150 <__asan_handle_no_return>
  3a116b:	be 03 00 00 00       	mov    $0x3,%esi
  3a1170:	4c 89 ff             	mov    %r15,%rdi
  3a1173:	4c 89 f2             	mov    %r14,%rdx
  3a1176:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a117a:	ff 15 68 be 21 00    	call   *0x21be68(%rip)        # 5bcfe8 <_GLOBAL_OFFSET_TABLE_+0x1240>
  3a1180:	e9 b3 06 00 00       	jmp    3a1838 <<oriole::Parser>::parse_text+0x5208>
  3a1185:	44 89 ef             	mov    %r13d,%edi
  3a1188:	83 e7 07             	and    $0x7,%edi
  3a118b:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
  3a118f:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a1193:	44 89 f6             	mov    %r14d,%esi
  3a1196:	e8 b5 96 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a119b:	44 38 73 08          	cmp    %r14b,0x8(%rbx)
  3a119f:	0f 8d 2b 1d 00 00    	jge    3a2ed0 <<oriole::Parser>::parse_text+0x68a0>
  3a11a5:	fe 05 17 74 24 00    	incb   0x247417(%rip)        # 5e85c2 <__start___sancov_cntrs+0x71a2>
  3a11ab:	e9 c2 e2 ff ff       	jmp    39f472 <<oriole::Parser>::parse_text+0x2e42>
  3a11b0:	44 89 e7             	mov    %r12d,%edi
  3a11b3:	83 e7 07             	and    $0x7,%edi
  3a11b6:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
  3a11ba:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a11be:	44 89 f6             	mov    %r14d,%esi
  3a11c1:	e8 8a 96 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a11c6:	44 38 73 08          	cmp    %r14b,0x8(%rbx)
  3a11ca:	0f 8d 10 1d 00 00    	jge    3a2ee0 <<oriole::Parser>::parse_text+0x68b0>
  3a11d0:	fe 05 ef 73 24 00    	incb   0x2473ef(%rip)        # 5e85c5 <__start___sancov_cntrs+0x71a5>
  3a11d6:	e9 d9 e2 ff ff       	jmp    39f4b4 <<oriole::Parser>::parse_text+0x2e84>
  3a11db:	4b 8d 04 26          	lea    (%r14,%r12,1),%rax
  3a11df:	89 c7                	mov    %eax,%edi
  3a11e1:	83 e7 07             	and    $0x7,%edi
  3a11e4:	48 89 7b 18          	mov    %rdi,0x18(%rbx)
  3a11e8:	45 0f b6 ed          	movzbl %r13b,%r13d
  3a11ec:	44 89 ee             	mov    %r13d,%esi
  3a11ef:	e8 5c 96 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a11f4:	44 38 6b 18          	cmp    %r13b,0x18(%rbx)
  3a11f8:	0f 8d f2 1c 00 00    	jge    3a2ef0 <<oriole::Parser>::parse_text+0x68c0>
  3a11fe:	fe 05 99 72 24 00    	incb   0x247299(%rip)        # 5e849d <__start___sancov_cntrs+0x707d>
  3a1204:	e9 04 bc ff ff       	jmp    39ce0d <<oriole::Parser>::parse_text+0x7dd>
  3a1209:	fe 05 90 72 24 00    	incb   0x247290(%rip)        # 5e849f <__start___sancov_cntrs+0x707f>
  3a120f:	eb 06                	jmp    3a1217 <<oriole::Parser>::parse_text+0x4be7>
  3a1211:	fe 05 83 72 24 00    	incb   0x247283(%rip)        # 5e849a <__start___sancov_cntrs+0x707a>
  3a1217:	e8 34 7f e9 ff       	call   239150 <__asan_handle_no_return>
  3a121c:	4c 8d 05 7d 0d 21 00 	lea    0x210d7d(%rip),%r8        # 5b1fa0 <alloc_0d86069ca8d9aba608a2c91e648a76f1>
  3a1223:	4c 89 f7             	mov    %r14,%rdi
  3a1226:	4c 89 fe             	mov    %r15,%rsi
  3a1229:	4c 89 e2             	mov    %r12,%rdx
  3a122c:	4c 89 f9             	mov    %r15,%rcx
  3a122f:	ff 15 83 b7 21 00    	call   *0x21b783(%rip)        # 5bc9b8 <_GLOBAL_OFFSET_TABLE_+0xc10>
  3a1235:	44 89 ff             	mov    %r15d,%edi
  3a1238:	83 e7 07             	and    $0x7,%edi
  3a123b:	48 89 7b 40          	mov    %rdi,0x40(%rbx)
  3a123f:	45 0f b6 e4          	movzbl %r12b,%r12d
  3a1243:	44 89 e6             	mov    %r12d,%esi
  3a1246:	e8 05 96 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a124b:	44 38 63 40          	cmp    %r12b,0x40(%rbx)
  3a124f:	0f 8d ac 1c 00 00    	jge    3a2f01 <<oriole::Parser>::parse_text+0x68d1>
  3a1255:	fe 05 5d 74 24 00    	incb   0x24745d(%rip)        # 5e86b8 <__start___sancov_cntrs+0x7298>
  3a125b:	e9 ec f6 ff ff       	jmp    3a094c <<oriole::Parser>::parse_text+0x431c>
  3a1260:	4b 8d 04 27          	lea    (%r15,%r12,1),%rax
  3a1264:	89 c7                	mov    %eax,%edi
  3a1266:	83 e7 07             	and    $0x7,%edi
  3a1269:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
  3a126d:	45 0f b6 ed          	movzbl %r13b,%r13d
  3a1271:	44 89 ee             	mov    %r13d,%esi
  3a1274:	e8 d7 95 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1279:	44 38 6b 70          	cmp    %r13b,0x70(%rbx)
  3a127d:	0f 8d 8e 1c 00 00    	jge    3a2f11 <<oriole::Parser>::parse_text+0x68e1>
  3a1283:	fe 05 d8 72 24 00    	incb   0x2472d8(%rip)        # 5e8561 <__start___sancov_cntrs+0x7141>
  3a1289:	e9 ec d2 ff ff       	jmp    39e57a <<oriole::Parser>::parse_text+0x1f4a>
  3a128e:	fe 05 cf 72 24 00    	incb   0x2472cf(%rip)        # 5e8563 <__start___sancov_cntrs+0x7143>
  3a1294:	e9 20 f0 ff ff       	jmp    3a02b9 <<oriole::Parser>::parse_text+0x3c89>
  3a1299:	fe 05 bf 72 24 00    	incb   0x2472bf(%rip)        # 5e855e <__start___sancov_cntrs+0x713e>
  3a129f:	e9 15 f0 ff ff       	jmp    3a02b9 <<oriole::Parser>::parse_text+0x3c89>
  3a12a4:	45 89 f4             	mov    %r14d,%r12d
  3a12a7:	41 83 e4 07          	and    $0x7,%r12d
  3a12ab:	45 0f b6 ff          	movzbl %r15b,%r15d
  3a12af:	44 89 e7             	mov    %r12d,%edi
  3a12b2:	44 89 fe             	mov    %r15d,%esi
  3a12b5:	e8 96 95 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a12ba:	45 38 fc             	cmp    %r15b,%r12b
  3a12bd:	0f 8d 5f 1c 00 00    	jge    3a2f22 <<oriole::Parser>::parse_text+0x68f2>
  3a12c3:	fe 05 a2 72 24 00    	incb   0x2472a2(%rip)        # 5e856b <__start___sancov_cntrs+0x714b>
  3a12c9:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a12cd:	e9 fe d3 ff ff       	jmp    39e6d0 <<oriole::Parser>::parse_text+0x20a0>
  3a12d2:	fe 05 51 73 24 00    	incb   0x247351(%rip)        # 5e8629 <__start___sancov_cntrs+0x7209>
  3a12d8:	e8 73 7e e9 ff       	call   239150 <__asan_handle_no_return>
  3a12dd:	48 8d 3d bc 1d 21 00 	lea    0x211dbc(%rip),%rdi        # 5b30a0 <alloc_fdb1551ca556b497863368479417a5c2>
  3a12e4:	ff 15 0e b1 21 00    	call   *0x21b10e(%rip)        # 5bc3f8 <_GLOBAL_OFFSET_TABLE_+0x650>
  3a12ea:	4c 89 73 70          	mov    %r14,0x70(%rbx)
  3a12ee:	41 83 e6 07          	and    $0x7,%r14d
  3a12f2:	45 0f b6 ed          	movzbl %r13b,%r13d
  3a12f6:	44 89 f7             	mov    %r14d,%edi
  3a12f9:	44 89 ee             	mov    %r13d,%esi
  3a12fc:	e8 4f 95 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1301:	45 38 ee             	cmp    %r13b,%r14b
  3a1304:	0f 8d 28 1c 00 00    	jge    3a2f32 <<oriole::Parser>::parse_text+0x6902>
  3a130a:	fe 05 c4 71 24 00    	incb   0x2471c4(%rip)        # 5e84d4 <__start___sancov_cntrs+0x70b4>
  3a1310:	4f 8d 34 27          	lea    (%r15,%r12,1),%r14
  3a1314:	e9 1c bf ff ff       	jmp    39d235 <<oriole::Parser>::parse_text+0xc05>
  3a1319:	fe 05 b7 71 24 00    	incb   0x2471b7(%rip)        # 5e84d6 <__start___sancov_cntrs+0x70b6>
  3a131f:	eb 0a                	jmp    3a132b <<oriole::Parser>::parse_text+0x4cfb>
  3a1321:	4c 89 6b 08          	mov    %r13,0x8(%rbx)
  3a1325:	fe 05 a6 71 24 00    	incb   0x2471a6(%rip)        # 5e84d1 <__start___sancov_cntrs+0x70b1>
  3a132b:	e8 20 7e e9 ff       	call   239150 <__asan_handle_no_return>
  3a1330:	4c 8d 05 69 0c 21 00 	lea    0x210c69(%rip),%r8        # 5b1fa0 <alloc_0d86069ca8d9aba608a2c91e648a76f1>
  3a1337:	4c 89 ff             	mov    %r15,%rdi
  3a133a:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  3a133e:	48 89 ce             	mov    %rcx,%rsi
  3a1341:	4c 89 e2             	mov    %r12,%rdx
  3a1344:	ff 15 6e b6 21 00    	call   *0x21b66e(%rip)        # 5bc9b8 <_GLOBAL_OFFSET_TABLE_+0xc10>
  3a134a:	45 89 ec             	mov    %r13d,%r12d
  3a134d:	41 83 e4 07          	and    $0x7,%r12d
  3a1351:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a1355:	44 89 e7             	mov    %r12d,%edi
  3a1358:	44 89 f6             	mov    %r14d,%esi
  3a135b:	e8 f0 94 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1360:	45 38 f4             	cmp    %r14b,%r12b
  3a1363:	0f 8d da 1b 00 00    	jge    3a2f43 <<oriole::Parser>::parse_text+0x6913>
  3a1369:	fe 05 75 71 24 00    	incb   0x247175(%rip)        # 5e84e4 <__start___sancov_cntrs+0x70c4>
  3a136f:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a1373:	e9 2b c0 ff ff       	jmp    39d3a3 <<oriole::Parser>::parse_text+0xd73>
  3a1378:	45 89 f4             	mov    %r14d,%r12d
  3a137b:	41 83 e4 07          	and    $0x7,%r12d
  3a137f:	45 0f b6 ff          	movzbl %r15b,%r15d
  3a1383:	44 89 e7             	mov    %r12d,%edi
  3a1386:	44 89 fe             	mov    %r15d,%esi
  3a1389:	e8 c2 94 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a138e:	45 38 fc             	cmp    %r15b,%r12b
  3a1391:	0f 8d bc 1b 00 00    	jge    3a2f53 <<oriole::Parser>::parse_text+0x6923>
  3a1397:	fe 05 50 72 24 00    	incb   0x247250(%rip)        # 5e85ed <__start___sancov_cntrs+0x71cd>
  3a139d:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a13a1:	41 80 3e 01          	cmpb   $0x1,(%r14)
  3a13a5:	0f 84 c3 e4 ff ff    	je     39f86e <<oriole::Parser>::parse_text+0x323e>
  3a13ab:	31 ff                	xor    %edi,%edi
  3a13ad:	4c 8b 73 08          	mov    0x8(%rbx),%r14
  3a13b1:	4c 89 f6             	mov    %r14,%rsi
  3a13b4:	e8 b7 91 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a13b9:	4d 85 f6             	test   %r14,%r14
  3a13bc:	74 65                	je     3a1423 <<oriole::Parser>::parse_text+0x4df3>
  3a13be:	4c 89 f7             	mov    %r14,%rdi
  3a13c1:	4c 89 e6             	mov    %r12,%rsi
  3a13c4:	e8 07 91 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  3a13c9:	4d 39 e6             	cmp    %r12,%r14
  3a13cc:	73 5d                	jae    3a142b <<oriole::Parser>::parse_text+0x4dfb>
  3a13ce:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
  3a13d5:	49 01 c6             	add    %rax,%r14
  3a13d8:	4c 89 f0             	mov    %r14,%rax
  3a13db:	48 c1 e8 03          	shr    $0x3,%rax
  3a13df:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a13e6:	7f 
  3a13e7:	31 ff                	xor    %edi,%edi
  3a13e9:	44 89 fe             	mov    %r15d,%esi
  3a13ec:	e8 ef 94 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a13f1:	45 85 ff             	test   %r15d,%r15d
  3a13f4:	0f 85 fd 0b 00 00    	jne    3a1ff7 <<oriole::Parser>::parse_text+0x59c7>
  3a13fa:	fe 05 f3 71 24 00    	incb   0x2471f3(%rip)        # 5e85f3 <__start___sancov_cntrs+0x71d3>
  3a1400:	45 0f b6 36          	movzbl (%r14),%r14d
  3a1404:	bf bf 00 00 00       	mov    $0xbf,%edi
  3a1409:	44 89 f6             	mov    %r14d,%esi
  3a140c:	e8 cf 94 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1411:	41 80 fe bf          	cmp    $0xbf,%r14b
  3a1415:	0f 8e 0a 0c 00 00    	jle    3a2025 <<oriole::Parser>::parse_text+0x59f5>
  3a141b:	fe 05 d6 71 24 00    	incb   0x2471d6(%rip)        # 5e85f7 <__start___sancov_cntrs+0x71d7>
  3a1421:	eb 22                	jmp    3a1445 <<oriole::Parser>::parse_text+0x4e15>
  3a1423:	fe 05 c7 71 24 00    	incb   0x2471c7(%rip)        # 5e85f0 <__start___sancov_cntrs+0x71d0>
  3a1429:	eb 38                	jmp    3a1463 <<oriole::Parser>::parse_text+0x4e33>
  3a142b:	4c 89 f7             	mov    %r14,%rdi
  3a142e:	4c 89 e6             	mov    %r12,%rsi
  3a1431:	e8 9a 90 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  3a1436:	4d 39 e6             	cmp    %r12,%r14
  3a1439:	0f 85 ee 0b 00 00    	jne    3a202d <<oriole::Parser>::parse_text+0x59fd>
  3a143f:	fe 05 ad 71 24 00    	incb   0x2471ad(%rip)        # 5e85f2 <__start___sancov_cntrs+0x71d2>
  3a1445:	4c 8b 73 08          	mov    0x8(%rbx),%r14
  3a1449:	4c 89 f7             	mov    %r14,%rdi
  3a144c:	4c 89 e6             	mov    %r12,%rsi
  3a144f:	e8 7c 90 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  3a1454:	4d 39 e6             	cmp    %r12,%r14
  3a1457:	0f 87 58 02 00 00    	ja     3a16b5 <<oriole::Parser>::parse_text+0x5085>
  3a145d:	fe 05 95 71 24 00    	incb   0x247195(%rip)        # 5e85f8 <__start___sancov_cntrs+0x71d8>
  3a1463:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
  3a146a:	48 89 83 20 01 00 00 	mov    %rax,0x120(%rbx)
  3a1471:	4c 01 f0             	add    %r14,%rax
  3a1474:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
  3a147b:	48 8d bb 20 01 00 00 	lea    0x120(%rbx),%rdi
  3a1482:	e8 89 20 0a 00       	call   443510 <<core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next>
  3a1487:	41 89 c5             	mov    %eax,%r13d
  3a148a:	bf ff ff ff ff       	mov    $0xffffffff,%edi
  3a148f:	89 c6                	mov    %eax,%esi
  3a1491:	e8 0a 92 11 00       	call   4ba6a0 <__sanitizer_cov_trace_const_cmp4>
  3a1496:	41 83 fd ff          	cmp    $0xffffffff,%r13d
  3a149a:	0f 84 80 00 00 00    	je     3a1520 <<oriole::Parser>::parse_text+0x4ef0>
  3a14a0:	4c 8d 35 49 10 22 00 	lea    0x221049(%rip),%r14        # 5c24f0 <__sancov_gen_cov_switch_values.2891>
  3a14a7:	4c 8d 3d d2 b0 19 00 	lea    0x19b0d2(%rip),%r15        # 53c580 <switch.table._RNvCs26TCrUj5Hdw_12oriole_expat10run_events+0x10e0>
  3a14ae:	4c 8d a3 20 01 00 00 	lea    0x120(%rbx),%r12
  3a14b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  3a14bc:	00 00 00 00 
  3a14c0:	44 89 ef             	mov    %r13d,%edi
  3a14c3:	4c 89 f6             	mov    %r14,%rsi
  3a14c6:	e8 a5 94 11 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  3a14cb:	41 83 c5 f7          	add    $0xfffffff7,%r13d
  3a14cf:	41 83 fd 17          	cmp    $0x17,%r13d
  3a14d3:	0f 87 ad 01 00 00    	ja     3a1686 <<oriole::Parser>::parse_text+0x5056>
  3a14d9:	4b 63 04 af          	movslq (%r15,%r13,4),%rax
  3a14dd:	4c 01 f8             	add    %r15,%rax
  3a14e0:	ff e0                	jmp    *%rax
  3a14e2:	fe 05 1e 71 24 00    	incb   0x24711e(%rip)        # 5e8606 <__start___sancov_cntrs+0x71e6>
  3a14e8:	eb 16                	jmp    3a1500 <<oriole::Parser>::parse_text+0x4ed0>
  3a14ea:	fe 05 14 71 24 00    	incb   0x247114(%rip)        # 5e8604 <__start___sancov_cntrs+0x71e4>
  3a14f0:	eb 0e                	jmp    3a1500 <<oriole::Parser>::parse_text+0x4ed0>
  3a14f2:	fe 05 0f 71 24 00    	incb   0x24710f(%rip)        # 5e8607 <__start___sancov_cntrs+0x71e7>
  3a14f8:	eb 06                	jmp    3a1500 <<oriole::Parser>::parse_text+0x4ed0>
  3a14fa:	fe 05 05 71 24 00    	incb   0x247105(%rip)        # 5e8605 <__start___sancov_cntrs+0x71e5>
  3a1500:	4c 89 e7             	mov    %r12,%rdi
  3a1503:	e8 08 20 0a 00       	call   443510 <<core::str::iter::Chars as core::iter::traits::iterator::Iterator>::next>
  3a1508:	83 f8 ff             	cmp    $0xffffffff,%eax
  3a150b:	74 0b                	je     3a1518 <<oriole::Parser>::parse_text+0x4ee8>
  3a150d:	41 89 c5             	mov    %eax,%r13d
  3a1510:	fe 05 f3 70 24 00    	incb   0x2470f3(%rip)        # 5e8609 <__start___sancov_cntrs+0x71e9>
  3a1516:	eb a8                	jmp    3a14c0 <<oriole::Parser>::parse_text+0x4e90>
  3a1518:	fe 05 ec 70 24 00    	incb   0x2470ec(%rip)        # 5e860a <__start___sancov_cntrs+0x71ea>
  3a151e:	eb 06                	jmp    3a1526 <<oriole::Parser>::parse_text+0x4ef6>
  3a1520:	fe 05 dd 70 24 00    	incb   0x2470dd(%rip)        # 5e8603 <__start___sancov_cntrs+0x71e3>
  3a1526:	41 b4 01             	mov    $0x1,%r12b
  3a1529:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a152d:	48 05 44 09 00 00    	add    $0x944,%rax
  3a1533:	49 89 c7             	mov    %rax,%r15
  3a1536:	48 c1 e8 03          	shr    $0x3,%rax
  3a153a:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a1541:	7f 
  3a1542:	31 ff                	xor    %edi,%edi
  3a1544:	44 89 f6             	mov    %r14d,%esi
  3a1547:	e8 94 93 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a154c:	45 85 f6             	test   %r14d,%r14d
  3a154f:	0f 85 9a 02 00 00    	jne    3a17ef <<oriole::Parser>::parse_text+0x51bf>
  3a1555:	fe 05 b0 70 24 00    	incb   0x2470b0(%rip)        # 5e860b <__start___sancov_cntrs+0x71eb>
  3a155b:	31 c0                	xor    %eax,%eax
  3a155d:	41 80 3f 00          	cmpb   $0x0,(%r15)
  3a1561:	41 0f b6 cc          	movzbl %r12b,%ecx
  3a1565:	41 bf 08 00 00 00    	mov    $0x8,%r15d
  3a156b:	44 0f 44 f9          	cmove  %ecx,%r15d
  3a156f:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  3a1573:	48 0f 45 c8          	cmovne %rax,%rcx
  3a1577:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
  3a157b:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  3a1582:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a1589:	7f 
  3a158a:	31 ff                	xor    %edi,%edi
  3a158c:	44 89 f6             	mov    %r14d,%esi
  3a158f:	e8 4c 93 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1594:	45 85 f6             	test   %r14d,%r14d
  3a1597:	0f 85 53 15 00 00    	jne    3a2af0 <<oriole::Parser>::parse_text+0x64c0>
  3a159d:	48 8b 43 48          	mov    0x48(%rbx),%rax
  3a15a1:	4c 8b 20             	mov    (%rax),%r12
  3a15a4:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  3a15ab:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a15b2:	7f 
  3a15b3:	31 ff                	xor    %edi,%edi
  3a15b5:	44 89 f6             	mov    %r14d,%esi
  3a15b8:	e8 23 93 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a15bd:	45 85 f6             	test   %r14d,%r14d
  3a15c0:	0f 85 3b 15 00 00    	jne    3a2b01 <<oriole::Parser>::parse_text+0x64d1>
  3a15c6:	48 8b 43 38          	mov    0x38(%rbx),%rax
  3a15ca:	4c 8b 30             	mov    (%rax),%r14
  3a15cd:	4c 89 e6             	mov    %r12,%rsi
  3a15d0:	48 83 e6 07          	and    $0x7,%rsi
  3a15d4:	31 ff                	xor    %edi,%edi
  3a15d6:	e8 95 8f 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a15db:	4c 89 e0             	mov    %r12,%rax
  3a15de:	48 83 e0 07          	and    $0x7,%rax
  3a15e2:	0f 85 ac 00 00 00    	jne    3a1694 <<oriole::Parser>::parse_text+0x5064>
  3a15e8:	49 bd 55 55 55 55 55 	movabs $0x55555555555555,%r13
  3a15ef:	55 55 00 
  3a15f2:	4c 89 ef             	mov    %r13,%rdi
  3a15f5:	4c 89 f6             	mov    %r14,%rsi
  3a15f8:	e8 73 8f 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a15fd:	4d 39 ee             	cmp    %r13,%r14
  3a1600:	0f 87 99 00 00 00    	ja     3a169f <<oriole::Parser>::parse_text+0x506f>
  3a1606:	31 ff                	xor    %edi,%edi
  3a1608:	4c 89 f6             	mov    %r14,%rsi
  3a160b:	e8 60 8f 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a1610:	4d 85 f6             	test   %r14,%r14
  3a1613:	0f 84 91 00 00 00    	je     3a16aa <<oriole::Parser>::parse_text+0x507a>
  3a1619:	fe 05 f4 6f 24 00    	incb   0x246ff4(%rip)        # 5e8613 <__start___sancov_cntrs+0x71f3>
  3a161f:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
  3a1623:	48 c1 e0 07          	shl    $0x7,%rax
  3a1627:	49 8d 34 04          	lea    (%r12,%rax,1),%rsi
  3a162b:	48 81 c6 80 fe ff ff 	add    $0xfffffffffffffe80,%rsi
  3a1632:	48 8d bb 30 01 00 00 	lea    0x130(%rbx),%rdi
  3a1639:	48 8b 53 08          	mov    0x8(%rbx),%rdx
  3a163d:	31 c9                	xor    %ecx,%ecx
  3a163f:	e8 1c 71 fd ff       	call   378760 <<oriole::encoding::Source>::position_at>
  3a1644:	44 88 bb 50 01 00 00 	mov    %r15b,0x150(%rbx)
  3a164b:	48 8d 05 8e 1e 1a 00 	lea    0x1a1e8e(%rip),%rax        # 5434e0 <alloc_f0e2e53112f591ce009d0941ce55dc03>
  3a1652:	48 89 83 20 01 00 00 	mov    %rax,0x120(%rbx)
  3a1659:	48 c7 83 28 01 00 00 	movq   $0x2d,0x128(%rbx)
  3a1660:	2d 00 00 00 
  3a1664:	48 8d b3 20 01 00 00 	lea    0x120(%rbx),%rsi
  3a166b:	ba 38 00 00 00       	mov    $0x38,%edx
  3a1670:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  3a1674:	e8 87 b9 e8 ff       	call   22d000 <__asan_memcpy>
  3a1679:	4c 8b 73 68          	mov    0x68(%rbx),%r14
  3a167d:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a1681:	e9 28 03 00 00       	jmp    3a19ae <<oriole::Parser>::parse_text+0x537e>
  3a1686:	fe 05 7c 6f 24 00    	incb   0x246f7c(%rip)        # 5e8608 <__start___sancov_cntrs+0x71e8>
  3a168c:	41 b4 03             	mov    $0x3,%r12b
  3a168f:	e9 95 fe ff ff       	jmp    3a1529 <<oriole::Parser>::parse_text+0x4ef9>
  3a1694:	fe 05 76 6f 24 00    	incb   0x246f76(%rip)        # 5e8610 <__start___sancov_cntrs+0x71f0>
  3a169a:	e9 5a f9 ff ff       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  3a169f:	fe 05 6c 6f 24 00    	incb   0x246f6c(%rip)        # 5e8611 <__start___sancov_cntrs+0x71f1>
  3a16a5:	e9 4f f9 ff ff       	jmp    3a0ff9 <<oriole::Parser>::parse_text+0x49c9>
  3a16aa:	fe 05 62 6f 24 00    	incb   0x246f62(%rip)        # 5e8612 <__start___sancov_cntrs+0x71f2>
  3a16b0:	e9 6a f9 ff ff       	jmp    3a101f <<oriole::Parser>::parse_text+0x49ef>
  3a16b5:	fe 05 3e 6f 24 00    	incb   0x246f3e(%rip)        # 5e85f9 <__start___sancov_cntrs+0x71d9>
  3a16bb:	e9 4b e8 ff ff       	jmp    39ff0b <<oriole::Parser>::parse_text+0x38db>
  3a16c0:	fe 05 b6 6e 24 00    	incb   0x246eb6(%rip)        # 5e857c <__start___sancov_cntrs+0x715c>
  3a16c6:	e8 85 7a e9 ff       	call   239150 <__asan_handle_no_return>
  3a16cb:	48 8d 3d 0e 18 21 00 	lea    0x21180e(%rip),%rdi        # 5b2ee0 <alloc_491d3c69d7760a4b6092c1ab1fdbf8b8>
  3a16d2:	ff 15 20 ad 21 00    	call   *0x21ad20(%rip)        # 5bc3f8 <_GLOBAL_OFFSET_TABLE_+0x650>
  3a16d8:	fe 05 44 6f 24 00    	incb   0x246f44(%rip)        # 5e8622 <__start___sancov_cntrs+0x7202>
  3a16de:	e8 6d 7a e9 ff       	call   239150 <__asan_handle_no_return>
  3a16e3:	48 8d 3d 76 19 21 00 	lea    0x211976(%rip),%rdi        # 5b3060 <alloc_f8927beda4b39694f7ec55da9d849681>
  3a16ea:	ff 15 08 ad 21 00    	call   *0x21ad08(%rip)        # 5bc3f8 <_GLOBAL_OFFSET_TABLE_+0x650>
  3a16f0:	4c 8b 7b 58          	mov    0x58(%rbx),%r15
  3a16f4:	41 83 e7 07          	and    $0x7,%r15d
  3a16f8:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a16fc:	44 89 ff             	mov    %r15d,%edi
  3a16ff:	44 89 f6             	mov    %r14d,%esi
  3a1702:	e8 49 91 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1707:	45 38 f7             	cmp    %r14b,%r15b
  3a170a:	0f 8d 53 18 00 00    	jge    3a2f63 <<oriole::Parser>::parse_text+0x6933>
  3a1710:	fe 05 6b 6d 24 00    	incb   0x246d6b(%rip)        # 5e8481 <__start___sancov_cntrs+0x7061>
  3a1716:	e9 1e b4 ff ff       	jmp    39cb39 <<oriole::Parser>::parse_text+0x509>
  3a171b:	4d 89 fc             	mov    %r15,%r12
  3a171e:	41 83 e7 07          	and    $0x7,%r15d
  3a1722:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a1726:	44 89 ff             	mov    %r15d,%edi
  3a1729:	44 89 f6             	mov    %r14d,%esi
  3a172c:	e8 1f 91 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1731:	45 38 f7             	cmp    %r14b,%r15b
  3a1734:	0f 8d 3a 18 00 00    	jge    3a2f74 <<oriole::Parser>::parse_text+0x6944>
  3a173a:	fe 05 44 6d 24 00    	incb   0x246d44(%rip)        # 5e8484 <__start___sancov_cntrs+0x7064>
  3a1740:	41 c6 04 24 ff       	movb   $0xff,(%r12)
  3a1745:	e9 2f ff ff ff       	jmp    3a1679 <<oriole::Parser>::parse_text+0x5049>
  3a174a:	fe 05 91 6e 24 00    	incb   0x246e91(%rip)        # 5e85e1 <__start___sancov_cntrs+0x71c1>
  3a1750:	e8 fb 79 e9 ff       	call   239150 <__asan_handle_no_return>
  3a1755:	48 8d 3d e4 54 21 00 	lea    0x2154e4(%rip),%rdi        # 5b6c40 <alloc_efbb32202b16b6582d4ef8f361fee51c>
  3a175c:	e8 3f ab de ff       	call   18c2a0 <core::hint::unreachable_unchecked::precondition_check>
  3a1761:	45 89 f4             	mov    %r14d,%r12d
  3a1764:	41 83 e4 07          	and    $0x7,%r12d
  3a1768:	45 0f b6 ff          	movzbl %r15b,%r15d
  3a176c:	44 89 e7             	mov    %r12d,%edi
  3a176f:	44 89 fe             	mov    %r15d,%esi
  3a1772:	e8 d9 90 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1777:	45 38 fc             	cmp    %r15b,%r12b
  3a177a:	0f 8d 04 18 00 00    	jge    3a2f84 <<oriole::Parser>::parse_text+0x6954>
  3a1780:	fe 05 78 6e 24 00    	incb   0x246e78(%rip)        # 5e85fe <__start___sancov_cntrs+0x71de>
  3a1786:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a178a:	e9 3e e1 ff ff       	jmp    39f8cd <<oriole::Parser>::parse_text+0x329d>
  3a178f:	fe 05 6b 6e 24 00    	incb   0x246e6b(%rip)        # 5e8600 <__start___sancov_cntrs+0x71e0>
  3a1795:	eb 06                	jmp    3a179d <<oriole::Parser>::parse_text+0x516d>
  3a1797:	fe 05 5e 6e 24 00    	incb   0x246e5e(%rip)        # 5e85fb <__start___sancov_cntrs+0x71db>
  3a179d:	e8 ae 79 e9 ff       	call   239150 <__asan_handle_no_return>
  3a17a2:	4c 8d 05 77 18 21 00 	lea    0x211877(%rip),%r8        # 5b3020 <alloc_34fa4d1c709e3476a4aacfb4897b8713>
  3a17a9:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  3a17b0:	48 8b 73 18          	mov    0x18(%rbx),%rsi
  3a17b4:	31 d2                	xor    %edx,%edx
  3a17b6:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  3a17ba:	ff 15 f8 b1 21 00    	call   *0x21b1f8(%rip)        # 5bc9b8 <_GLOBAL_OFFSET_TABLE_+0xc10>
  3a17c0:	fe 05 22 6f 24 00    	incb   0x246f22(%rip)        # 5e86e8 <__start___sancov_cntrs+0x72c8>
  3a17c6:	e8 85 79 e9 ff       	call   239150 <__asan_handle_no_return>
  3a17cb:	48 8d 3d 8e 15 21 00 	lea    0x21158e(%rip),%rdi        # 5b2d60 <alloc_33b0a44bb27b3bf3877e103cf7b9d33c>
  3a17d2:	e8 c9 aa de ff       	call   18c2a0 <core::hint::unreachable_unchecked::precondition_check>
  3a17d7:	fe 05 6b 6d 24 00    	incb   0x246d6b(%rip)        # 5e8548 <__start___sancov_cntrs+0x7128>
  3a17dd:	e8 6e 79 e9 ff       	call   239150 <__asan_handle_no_return>
  3a17e2:	48 8d 3d 37 b7 20 00 	lea    0x20b737(%rip),%rdi        # 5acf20 <alloc_3386b34d4e9344c86cf8c1c13353b2c0>
  3a17e9:	ff 15 09 ac 21 00    	call   *0x21ac09(%rip)        # 5bc3f8 <_GLOBAL_OFFSET_TABLE_+0x650>
  3a17ef:	45 89 fd             	mov    %r15d,%r13d
  3a17f2:	41 83 e5 07          	and    $0x7,%r13d
  3a17f6:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a17fa:	44 89 ef             	mov    %r13d,%edi
  3a17fd:	44 89 f6             	mov    %r14d,%esi
  3a1800:	e8 4b 90 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1805:	45 38 f5             	cmp    %r14b,%r13b
  3a1808:	0f 8d 86 17 00 00    	jge    3a2f94 <<oriole::Parser>::parse_text+0x6964>
  3a180e:	fe 05 f8 6d 24 00    	incb   0x246df8(%rip)        # 5e860c <__start___sancov_cntrs+0x71ec>
  3a1814:	e9 42 fd ff ff       	jmp    3a155b <<oriole::Parser>::parse_text+0x4f2b>
  3a1819:	fe 05 b1 6e 24 00    	incb   0x246eb1(%rip)        # 5e86d0 <__start___sancov_cntrs+0x72b0>
  3a181f:	e8 2c 79 e9 ff       	call   239150 <__asan_handle_no_return>
  3a1824:	48 8d 3d 95 d2 20 00 	lea    0x20d295(%rip),%rdi        # 5aeac0 <alloc_d00158a6670632a9087e48e739c109e4>
  3a182b:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  3a1832:	ff 15 18 b3 21 00    	call   *0x21b318(%rip)        # 5bcb50 <_GLOBAL_OFFSET_TABLE_+0xda8>
  3a1838:	0f 0b                	ud2
  3a183a:	45 89 e7             	mov    %r12d,%r15d
  3a183d:	41 83 e7 07          	and    $0x7,%r15d
  3a1841:	45 0f b6 ed          	movzbl %r13b,%r13d
  3a1845:	44 89 ff             	mov    %r15d,%edi
  3a1848:	44 89 ee             	mov    %r13d,%esi
  3a184b:	e8 00 90 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1850:	45 38 ef             	cmp    %r13b,%r15b
  3a1853:	0f 8d 4b 17 00 00    	jge    3a2fa4 <<oriole::Parser>::parse_text+0x6974>
  3a1859:	fe 05 63 6e 24 00    	incb   0x246e63(%rip)        # 5e86c2 <__start___sancov_cntrs+0x72a2>
  3a185f:	41 80 3c 24 00       	cmpb   $0x0,(%r12)
  3a1864:	0f 85 61 f5 ff ff    	jne    3a0dcb <<oriole::Parser>::parse_text+0x479b>
  3a186a:	fe 05 54 6e 24 00    	incb   0x246e54(%rip)        # 5e86c4 <__start___sancov_cntrs+0x72a4>
  3a1870:	b0 01                	mov    $0x1,%al
  3a1872:	89 83 b0 00 00 00    	mov    %eax,0xb0(%rbx)
  3a1878:	48 8b 73 20          	mov    0x20(%rbx),%rsi
  3a187c:	4c 8b a3 c0 00 00 00 	mov    0xc0(%rbx),%r12
  3a1883:	48 8b 53 28          	mov    0x28(%rbx),%rdx
  3a1887:	48 8d bb 20 01 00 00 	lea    0x120(%rbx),%rdi
  3a188e:	e8 8d fd 05 00       	call   401620 <<oriole::Parser>::consume>
  3a1893:	44 0f b6 b3 50 01 00 	movzbl 0x150(%rbx),%r14d
  3a189a:	00 
  3a189b:	bf ff 00 00 00       	mov    $0xff,%edi
  3a18a0:	44 89 f6             	mov    %r14d,%esi
  3a18a3:	e8 38 90 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a18a8:	41 81 fe ff 00 00 00 	cmp    $0xff,%r14d
  3a18af:	74 2e                	je     3a18df <<oriole::Parser>::parse_text+0x52af>
  3a18b1:	48 8d b3 20 01 00 00 	lea    0x120(%rbx),%rsi
  3a18b8:	ba 38 00 00 00       	mov    $0x38,%edx
  3a18bd:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  3a18c1:	e8 3a b7 e8 ff       	call   22d000 <__asan_memcpy>
  3a18c6:	83 7b 40 fe          	cmpl   $0xfffffffe,0x40(%rbx)
  3a18ca:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a18ce:	0f 85 97 00 00 00    	jne    3a196b <<oriole::Parser>::parse_text+0x533b>
  3a18d4:	fe 05 01 6e 24 00    	incb   0x246e01(%rip)        # 5e86db <__start___sancov_cntrs+0x72bb>
  3a18da:	e9 aa 00 00 00       	jmp    3a1989 <<oriole::Parser>::parse_text+0x5359>
  3a18df:	48 8b 43 58          	mov    0x58(%rbx),%rax
  3a18e3:	48 c1 e8 03          	shr    $0x3,%rax
  3a18e7:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a18ee:	7f 
  3a18ef:	31 ff                	xor    %edi,%edi
  3a18f1:	44 89 f6             	mov    %r14d,%esi
  3a18f4:	e8 e7 8f 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a18f9:	45 85 f6             	test   %r14d,%r14d
  3a18fc:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a1900:	0f 85 24 01 00 00    	jne    3a1a2a <<oriole::Parser>::parse_text+0x53fa>
  3a1906:	fe 05 d0 6d 24 00    	incb   0x246dd0(%rip)        # 5e86dc <__start___sancov_cntrs+0x72bc>
  3a190c:	48 8b 43 58          	mov    0x58(%rbx),%rax
  3a1910:	c6 00 01             	movb   $0x1,(%rax)
  3a1913:	48 83 c0 30          	add    $0x30,%rax
  3a1917:	49 89 c4             	mov    %rax,%r12
  3a191a:	48 c1 e8 03          	shr    $0x3,%rax
  3a191e:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a1925:	7f 
  3a1926:	31 ff                	xor    %edi,%edi
  3a1928:	44 89 f6             	mov    %r14d,%esi
  3a192b:	e8 b0 8f 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1930:	45 85 f6             	test   %r14d,%r14d
  3a1933:	0f 85 20 01 00 00    	jne    3a1a59 <<oriole::Parser>::parse_text+0x5429>
  3a1939:	fe 05 a0 6d 24 00    	incb   0x246da0(%rip)        # 5e86df <__start___sancov_cntrs+0x72bf>
  3a193f:	41 c6 04 24 ff       	movb   $0xff,(%r12)
  3a1944:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  3a194b:	c7 80 80 00 00 00 f8 	movl   $0xf8f8f8f8,0x80(%rax)
  3a1952:	f8 f8 f8 
  3a1955:	66 c7 80 84 00 00 00 	movw   $0xf8f8,0x84(%rax)
  3a195c:	f8 f8 
  3a195e:	c6 80 86 00 00 00 f8 	movb   $0xf8,0x86(%rax)
  3a1965:	4c 8b 73 68          	mov    0x68(%rbx),%r14
  3a1969:	eb 43                	jmp    3a19ae <<oriole::Parser>::parse_text+0x537e>
  3a196b:	80 bb b0 00 00 00 00 	cmpb   $0x0,0xb0(%rbx)
  3a1972:	74 0f                	je     3a1983 <<oriole::Parser>::parse_text+0x5353>
  3a1974:	fe 05 6b 6d 24 00    	incb   0x246d6b(%rip)        # 5e86e5 <__start___sancov_cntrs+0x72c5>
  3a197a:	4d 8b 34 24          	mov    (%r12),%r14
  3a197e:	e9 eb f1 ff ff       	jmp    3a0b6e <<oriole::Parser>::parse_text+0x453e>
  3a1983:	fe 05 5b 6d 24 00    	incb   0x246d5b(%rip)        # 5e86e4 <__start___sancov_cntrs+0x72c4>
  3a1989:	4c 8b 73 68          	mov    0x68(%rbx),%r14
  3a198d:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  3a1994:	c7 80 80 00 00 00 f8 	movl   $0xf8f8f8f8,0x80(%rax)
  3a199b:	f8 f8 f8 
  3a199e:	66 c7 80 84 00 00 00 	movw   $0xf8f8,0x84(%rax)
  3a19a5:	f8 f8 
  3a19a7:	c6 80 86 00 00 00 f8 	movb   $0xf8,0x86(%rax)
  3a19ae:	49 c7 45 00 0e 36 e0 	movq   $0x45e0360e,0x0(%r13)
  3a19b5:	45 
  3a19b6:	31 ff                	xor    %edi,%edi
  3a19b8:	4c 89 f6             	mov    %r14,%rsi
  3a19bb:	e8 b0 8b 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a19c0:	4d 85 f6             	test   %r14,%r14
  3a19c3:	74 15                	je     3a19da <<oriole::Parser>::parse_text+0x53aa>
  3a19c5:	fe 05 17 6d 24 00    	incb   0x246d17(%rip)        # 5e86e2 <__start___sancov_cntrs+0x72c2>
  3a19cb:	be 60 04 00 00       	mov    $0x460,%esi
  3a19d0:	4c 89 f7             	mov    %r14,%rdi
  3a19d3:	e8 d8 3e e0 ff       	call   1a58b0 <__asan_stack_free_5>
  3a19d8:	eb 17                	jmp    3a19f1 <<oriole::Parser>::parse_text+0x53c1>
  3a19da:	fe 05 03 6d 24 00    	incb   0x246d03(%rip)        # 5e86e3 <__start___sancov_cntrs+0x72c3>
  3a19e0:	be 8c 00 00 00       	mov    $0x8c,%esi
  3a19e5:	48 8b bb 88 00 00 00 	mov    0x88(%rbx),%rdi
  3a19ec:	e8 8f 06 e9 ff       	call   232080 <__asan_set_shadow_00>
  3a19f1:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
  3a19f5:	5b                   	pop    %rbx
  3a19f6:	41 5c                	pop    %r12
  3a19f8:	41 5d                	pop    %r13
  3a19fa:	41 5e                	pop    %r14
  3a19fc:	41 5f                	pop    %r15
  3a19fe:	5d                   	pop    %rbp
  3a19ff:	c3                   	ret
  3a1a00:	45 89 e7             	mov    %r12d,%r15d
  3a1a03:	41 83 e7 07          	and    $0x7,%r15d
  3a1a07:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a1a0b:	44 89 ff             	mov    %r15d,%edi
  3a1a0e:	44 89 f6             	mov    %r14d,%esi
  3a1a11:	e8 3a 8e 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1a16:	45 38 f7             	cmp    %r14b,%r15b
  3a1a19:	0f 8d 95 15 00 00    	jge    3a2fb4 <<oriole::Parser>::parse_text+0x6984>
  3a1a1f:	fe 05 b3 6c 24 00    	incb   0x246cb3(%rip)        # 5e86d8 <__start___sancov_cntrs+0x72b8>
  3a1a25:	e9 1d f1 ff ff       	jmp    3a0b47 <<oriole::Parser>::parse_text+0x4517>
  3a1a2a:	4c 8b 7b 58          	mov    0x58(%rbx),%r15
  3a1a2e:	41 83 e7 07          	and    $0x7,%r15d
  3a1a32:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a1a36:	44 89 ff             	mov    %r15d,%edi
  3a1a39:	44 89 f6             	mov    %r14d,%esi
  3a1a3c:	e8 0f 8e 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1a41:	45 38 f7             	cmp    %r14b,%r15b
  3a1a44:	0f 8d 7a 15 00 00    	jge    3a2fc4 <<oriole::Parser>::parse_text+0x6994>
  3a1a4a:	fe 05 8d 6c 24 00    	incb   0x246c8d(%rip)        # 5e86dd <__start___sancov_cntrs+0x72bd>
  3a1a50:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a1a54:	e9 b3 fe ff ff       	jmp    3a190c <<oriole::Parser>::parse_text+0x52dc>
  3a1a59:	45 89 e7             	mov    %r12d,%r15d
  3a1a5c:	41 83 e7 07          	and    $0x7,%r15d
  3a1a60:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a1a64:	44 89 ff             	mov    %r15d,%edi
  3a1a67:	44 89 f6             	mov    %r14d,%esi
  3a1a6a:	e8 e1 8d 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1a6f:	45 38 f7             	cmp    %r14b,%r15b
  3a1a72:	0f 8d 5d 15 00 00    	jge    3a2fd5 <<oriole::Parser>::parse_text+0x69a5>
  3a1a78:	fe 05 62 6c 24 00    	incb   0x246c62(%rip)        # 5e86e0 <__start___sancov_cntrs+0x72c0>
  3a1a7e:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a1a82:	e9 b8 fe ff ff       	jmp    3a193f <<oriole::Parser>::parse_text+0x530f>
  3a1a87:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  3a1a8b:	41 83 e4 07          	and    $0x7,%r12d
  3a1a8f:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a1a93:	44 89 e7             	mov    %r12d,%edi
  3a1a96:	44 89 f6             	mov    %r14d,%esi
  3a1a99:	e8 b2 8d 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1a9e:	45 38 f4             	cmp    %r14b,%r12b
  3a1aa1:	0f 8d 3e 15 00 00    	jge    3a2fe5 <<oriole::Parser>::parse_text+0x69b5>
  3a1aa7:	fe 05 ac 6b 24 00    	incb   0x246bac(%rip)        # 5e8659 <__start___sancov_cntrs+0x7239>
  3a1aad:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  3a1ab1:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a1ab5:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  3a1aba:	0f 84 09 f5 ff ff    	je     3a0fc9 <<oriole::Parser>::parse_text+0x4999>
  3a1ac0:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a1ac4:	4c 8d b0 5c 08 00 00 	lea    0x85c(%rax),%r14
  3a1acb:	4c 89 f0             	mov    %r14,%rax
  3a1ace:	48 c1 e8 03          	shr    $0x3,%rax
  3a1ad2:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a1ad9:	7f 
  3a1ada:	31 ff                	xor    %edi,%edi
  3a1adc:	44 89 e6             	mov    %r12d,%esi
  3a1adf:	e8 fc 8d 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1ae4:	45 85 e4             	test   %r12d,%r12d
  3a1ae7:	0f 85 68 08 00 00    	jne    3a2355 <<oriole::Parser>::parse_text+0x5d25>
  3a1aed:	fe 05 69 6b 24 00    	incb   0x246b69(%rip)        # 5e865c <__start___sancov_cntrs+0x723c>
  3a1af3:	48 8b b3 80 00 00 00 	mov    0x80(%rbx),%rsi
  3a1afa:	41 0f b6 3e          	movzbl (%r14),%edi
  3a1afe:	4c 89 ea             	mov    %r13,%rdx
  3a1b01:	e8 da 9f f6 ff       	call   30bae0 <<oriole::names::NameRules>::is_name>
  3a1b06:	84 c0                	test   %al,%al
  3a1b08:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  3a1b0c:	0f 84 38 01 00 00    	je     3a1c4a <<oriole::Parser>::parse_text+0x561a>
  3a1b12:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  3a1b19:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a1b20:	7f 
  3a1b21:	31 ff                	xor    %edi,%edi
  3a1b23:	44 89 f6             	mov    %r14d,%esi
  3a1b26:	e8 b5 8d 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1b2b:	45 85 f6             	test   %r14d,%r14d
  3a1b2e:	0f 85 b0 10 00 00    	jne    3a2be4 <<oriole::Parser>::parse_text+0x65b4>
  3a1b34:	48 8b 43 48          	mov    0x48(%rbx),%rax
  3a1b38:	4c 8b 30             	mov    (%rax),%r14
  3a1b3b:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  3a1b42:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a1b49:	7f 
  3a1b4a:	31 ff                	xor    %edi,%edi
  3a1b4c:	44 89 e6             	mov    %r12d,%esi
  3a1b4f:	e8 8c 8d 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1b54:	45 85 e4             	test   %r12d,%r12d
  3a1b57:	0f 85 98 10 00 00    	jne    3a2bf5 <<oriole::Parser>::parse_text+0x65c5>
  3a1b5d:	48 8b 43 38          	mov    0x38(%rbx),%rax
  3a1b61:	48 8b 30             	mov    (%rax),%rsi
  3a1b64:	4c 89 f7             	mov    %r14,%rdi
  3a1b67:	e8 c4 f9 05 00       	call   401530 <<oriole::Parser>::source>
  3a1b6c:	48 89 c7             	mov    %rax,%rdi
  3a1b6f:	e8 dc d2 fd ff       	call   37ee50 <<oriole::encoding::Source>::remaining>
  3a1b74:	49 89 d6             	mov    %rdx,%r14
  3a1b77:	4c 89 ef             	mov    %r13,%rdi
  3a1b7a:	48 89 d6             	mov    %rdx,%rsi
  3a1b7d:	e8 4e 89 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  3a1b82:	4d 39 f5             	cmp    %r14,%r13
  3a1b85:	0f 85 c7 00 00 00    	jne    3a1c52 <<oriole::Parser>::parse_text+0x5622>
  3a1b8b:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a1b8f:	4c 8d b0 28 08 00 00 	lea    0x828(%rax),%r14
  3a1b96:	4c 89 f0             	mov    %r14,%rax
  3a1b99:	48 c1 e8 03          	shr    $0x3,%rax
  3a1b9d:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a1ba4:	7f 
  3a1ba5:	31 ff                	xor    %edi,%edi
  3a1ba7:	44 89 e6             	mov    %r12d,%esi
  3a1baa:	e8 31 8d 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1baf:	45 85 e4             	test   %r12d,%r12d
  3a1bb2:	0f 85 92 10 00 00    	jne    3a2c4a <<oriole::Parser>::parse_text+0x661a>
  3a1bb8:	4d 8b 36             	mov    (%r14),%r14
  3a1bbb:	4c 89 ef             	mov    %r13,%rdi
  3a1bbe:	4c 89 f6             	mov    %r14,%rsi
  3a1bc1:	e8 0a 89 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  3a1bc6:	4d 39 f5             	cmp    %r14,%r13
  3a1bc9:	0f 86 cf 00 00 00    	jbe    3a1c9e <<oriole::Parser>::parse_text+0x566e>
  3a1bcf:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  3a1bd6:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a1bdd:	7f 
  3a1bde:	31 ff                	xor    %edi,%edi
  3a1be0:	44 89 f6             	mov    %r14d,%esi
  3a1be3:	e8 f8 8c 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1be8:	45 85 f6             	test   %r14d,%r14d
  3a1beb:	0f 85 ab 10 00 00    	jne    3a2c9c <<oriole::Parser>::parse_text+0x666c>
  3a1bf1:	48 8b 43 48          	mov    0x48(%rbx),%rax
  3a1bf5:	4c 8b 30             	mov    (%rax),%r14
  3a1bf8:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  3a1bff:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a1c06:	7f 
  3a1c07:	31 ff                	xor    %edi,%edi
  3a1c09:	44 89 fe             	mov    %r15d,%esi
  3a1c0c:	e8 cf 8c 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1c11:	45 85 ff             	test   %r15d,%r15d
  3a1c14:	0f 85 93 10 00 00    	jne    3a2cad <<oriole::Parser>::parse_text+0x667d>
  3a1c1a:	fe 05 4c 6a 24 00    	incb   0x246a4c(%rip)        # 5e866c <__start___sancov_cntrs+0x724c>
  3a1c20:	48 8b 43 38          	mov    0x38(%rbx),%rax
  3a1c24:	48 8b 10             	mov    (%rax),%rdx
  3a1c27:	4c 8d 05 b2 19 1a 00 	lea    0x1a19b2(%rip),%r8        # 5435e0 <alloc_4abb898a17df74fc0714fc8877d259bd>
  3a1c2e:	41 b9 16 00 00 00    	mov    $0x16,%r9d
  3a1c34:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  3a1c38:	4c 89 f6             	mov    %r14,%rsi
  3a1c3b:	b9 1e 00 00 00       	mov    $0x1e,%ecx
  3a1c40:	e8 6b c1 05 00       	call   3fddb0 <<oriole::Parser>::err>
  3a1c45:	e9 2f fa ff ff       	jmp    3a1679 <<oriole::Parser>::parse_text+0x5049>
  3a1c4a:	fe 05 0f 6a 24 00    	incb   0x246a0f(%rip)        # 5e865f <__start___sancov_cntrs+0x723f>
  3a1c50:	eb 0a                	jmp    3a1c5c <<oriole::Parser>::parse_text+0x562c>
  3a1c52:	fe 05 0e 6a 24 00    	incb   0x246a0e(%rip)        # 5e8666 <__start___sancov_cntrs+0x7246>
  3a1c58:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  3a1c5c:	48 8b 83 f0 00 00 00 	mov    0xf0(%rbx),%rax
  3a1c63:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a1c6a:	7f 
  3a1c6b:	31 ff                	xor    %edi,%edi
  3a1c6d:	44 89 f6             	mov    %r14d,%esi
  3a1c70:	e8 6b 8c 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1c75:	45 85 f6             	test   %r14d,%r14d
  3a1c78:	0f 85 ee 00 00 00    	jne    3a1d6c <<oriole::Parser>::parse_text+0x573c>
  3a1c7e:	fe 05 dc 69 24 00    	incb   0x2469dc(%rip)        # 5e8660 <__start___sancov_cntrs+0x7240>
  3a1c84:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a1c88:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  3a1c8d:	0f 85 12 01 00 00    	jne    3a1da5 <<oriole::Parser>::parse_text+0x5775>
  3a1c93:	fe 05 ca 69 24 00    	incb   0x2469ca(%rip)        # 5e8663 <__start___sancov_cntrs+0x7243>
  3a1c99:	e9 1b 03 00 00       	jmp    3a1fb9 <<oriole::Parser>::parse_text+0x5989>
  3a1c9e:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  3a1ca5:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a1cac:	7f 
  3a1cad:	31 ff                	xor    %edi,%edi
  3a1caf:	44 89 f6             	mov    %r14d,%esi
  3a1cb2:	e8 29 8c 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1cb7:	45 85 f6             	test   %r14d,%r14d
  3a1cba:	0f 85 fe 0f 00 00    	jne    3a2cbe <<oriole::Parser>::parse_text+0x668e>
  3a1cc0:	48 8b 43 38          	mov    0x38(%rbx),%rax
  3a1cc4:	4c 8b 30             	mov    (%rax),%r14
  3a1cc7:	bf 01 00 00 00       	mov    $0x1,%edi
  3a1ccc:	4c 89 f6             	mov    %r14,%rsi
  3a1ccf:	e8 9c 88 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a1cd4:	49 83 fe 02          	cmp    $0x2,%r14
  3a1cd8:	72 0b                	jb     3a1ce5 <<oriole::Parser>::parse_text+0x56b5>
  3a1cda:	fe 05 89 69 24 00    	incb   0x246989(%rip)        # 5e8669 <__start___sancov_cntrs+0x7249>
  3a1ce0:	e9 73 ff ff ff       	jmp    3a1c58 <<oriole::Parser>::parse_text+0x5628>
  3a1ce5:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a1ce9:	4c 8d a0 48 09 00 00 	lea    0x948(%rax),%r12
  3a1cf0:	4c 89 e0             	mov    %r12,%rax
  3a1cf3:	48 c1 e8 03          	shr    $0x3,%rax
  3a1cf7:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  3a1cfe:	7f 
  3a1cff:	31 ff                	xor    %edi,%edi
  3a1d01:	44 89 ee             	mov    %r13d,%esi
  3a1d04:	e8 d7 8b 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1d09:	45 85 ed             	test   %r13d,%r13d
  3a1d0c:	0f 85 d1 08 00 00    	jne    3a25e3 <<oriole::Parser>::parse_text+0x5fb3>
  3a1d12:	fe 05 55 69 24 00    	incb   0x246955(%rip)        # 5e866d <__start___sancov_cntrs+0x724d>
  3a1d18:	41 80 3c 24 00       	cmpb   $0x0,(%r12)
  3a1d1d:	0f 84 f0 08 00 00    	je     3a2613 <<oriole::Parser>::parse_text+0x5fe3>
  3a1d23:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a1d27:	4c 8d a0 28 01 00 00 	lea    0x128(%rax),%r12
  3a1d2e:	4c 89 e0             	mov    %r12,%rax
  3a1d31:	48 c1 e8 03          	shr    $0x3,%rax
  3a1d35:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  3a1d3c:	7f 
  3a1d3d:	31 ff                	xor    %edi,%edi
  3a1d3f:	44 89 ee             	mov    %r13d,%esi
  3a1d42:	e8 99 8b 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1d47:	45 85 ed             	test   %r13d,%r13d
  3a1d4a:	0f 85 50 0a 00 00    	jne    3a27a0 <<oriole::Parser>::parse_text+0x6170>
  3a1d50:	fe 05 1f 69 24 00    	incb   0x24691f(%rip)        # 5e8675 <__start___sancov_cntrs+0x7255>
  3a1d56:	41 f6 04 24 01       	testb  $0x1,(%r12)
  3a1d5b:	0f 84 6f 0a 00 00    	je     3a27d0 <<oriole::Parser>::parse_text+0x61a0>
  3a1d61:	fe 05 12 69 24 00    	incb   0x246912(%rip)        # 5e8679 <__start___sancov_cntrs+0x7259>
  3a1d67:	e9 ad 08 00 00       	jmp    3a2619 <<oriole::Parser>::parse_text+0x5fe9>
  3a1d6c:	41 83 e4 07          	and    $0x7,%r12d
  3a1d70:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a1d74:	44 89 e7             	mov    %r12d,%edi
  3a1d77:	44 89 f6             	mov    %r14d,%esi
  3a1d7a:	e8 d1 8a 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a1d7f:	45 38 f4             	cmp    %r14b,%r12b
  3a1d82:	0f 8d 6e 12 00 00    	jge    3a2ff6 <<oriole::Parser>::parse_text+0x69c6>
  3a1d88:	fe 05 d3 68 24 00    	incb   0x2468d3(%rip)        # 5e8661 <__start___sancov_cntrs+0x7241>
  3a1d8e:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a1d92:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  3a1d96:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a1d9a:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  3a1d9f:	0f 84 ee fe ff ff    	je     3a1c93 <<oriole::Parser>::parse_text+0x5663>
  3a1da5:	4c 8d b0 5c 08 00 00 	lea    0x85c(%rax),%r14
  3a1dac:	4c 89 f0             	mov    %r14,%rax
  3a1daf:	48 c1 e8 03          	shr    $0x3,%rax
  3a1db3:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a1dba:	7f 
  3a1dbb:	31 ff                	xor    %edi,%edi
  3a1dbd:	44 89 e6             	mov    %r12d,%esi
  3a1dc0:	e8 1b 8b 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1dc5:	45 85 e4             	test   %r12d,%r12d
  3a1dc8:	0f 85 bc 05 00 00    	jne    3a238a <<oriole::Parser>::parse_text+0x5d5a>
  3a1dce:	fe 05 ad 68 24 00    	incb   0x2468ad(%rip)        # 5e8681 <__start___sancov_cntrs+0x7261>
  3a1dd4:	48 8b b3 80 00 00 00 	mov    0x80(%rbx),%rsi
  3a1ddb:	41 0f b6 3e          	movzbl (%r14),%edi
  3a1ddf:	4c 89 ea             	mov    %r13,%rdx
  3a1de2:	e8 f9 9c f6 ff       	call   30bae0 <<oriole::names::NameRules>::is_name>
  3a1de7:	84 c0                	test   %al,%al
  3a1de9:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  3a1ded:	0f 84 ac 01 00 00    	je     3a1f9f <<oriole::Parser>::parse_text+0x596f>
  3a1df3:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  3a1dfa:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a1e01:	7f 
  3a1e02:	31 ff                	xor    %edi,%edi
  3a1e04:	44 89 f6             	mov    %r14d,%esi
  3a1e07:	e8 d4 8a 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1e0c:	45 85 f6             	test   %r14d,%r14d
  3a1e0f:	0f 85 f1 0d 00 00    	jne    3a2c06 <<oriole::Parser>::parse_text+0x65d6>
  3a1e15:	48 8b 43 48          	mov    0x48(%rbx),%rax
  3a1e19:	4c 8b 30             	mov    (%rax),%r14
  3a1e1c:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  3a1e23:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a1e2a:	7f 
  3a1e2b:	31 ff                	xor    %edi,%edi
  3a1e2d:	44 89 e6             	mov    %r12d,%esi
  3a1e30:	e8 ab 8a 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1e35:	45 85 e4             	test   %r12d,%r12d
  3a1e38:	0f 85 d9 0d 00 00    	jne    3a2c17 <<oriole::Parser>::parse_text+0x65e7>
  3a1e3e:	48 8b 43 38          	mov    0x38(%rbx),%rax
  3a1e42:	48 8b 30             	mov    (%rax),%rsi
  3a1e45:	4c 89 f7             	mov    %r14,%rdi
  3a1e48:	e8 e3 f6 05 00       	call   401530 <<oriole::Parser>::source>
  3a1e4d:	48 89 c7             	mov    %rax,%rdi
  3a1e50:	e8 fb cf fd ff       	call   37ee50 <<oriole::encoding::Source>::remaining>
  3a1e55:	49 89 d6             	mov    %rdx,%r14
  3a1e58:	4c 89 ef             	mov    %r13,%rdi
  3a1e5b:	48 89 d6             	mov    %rdx,%rsi
  3a1e5e:	e8 6d 86 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  3a1e63:	4d 39 f5             	cmp    %r14,%r13
  3a1e66:	0f 85 3b 01 00 00    	jne    3a1fa7 <<oriole::Parser>::parse_text+0x5977>
  3a1e6c:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a1e70:	4c 8d b0 88 08 00 00 	lea    0x888(%rax),%r14
  3a1e77:	4c 89 f0             	mov    %r14,%rax
  3a1e7a:	48 c1 e8 03          	shr    $0x3,%rax
  3a1e7e:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a1e85:	7f 
  3a1e86:	31 ff                	xor    %edi,%edi
  3a1e88:	44 89 e6             	mov    %r12d,%esi
  3a1e8b:	e8 50 8a 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1e90:	45 85 e4             	test   %r12d,%r12d
  3a1e93:	0f 85 b8 05 00 00    	jne    3a2451 <<oriole::Parser>::parse_text+0x5e21>
  3a1e99:	fe 05 ed 67 24 00    	incb   0x2467ed(%rip)        # 5e868c <__start___sancov_cntrs+0x726c>
  3a1e9f:	45 0f b6 36          	movzbl (%r14),%r14d
  3a1ea3:	bf ff 00 00 00       	mov    $0xff,%edi
  3a1ea8:	44 89 f6             	mov    %r14d,%esi
  3a1eab:	e8 30 8a 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1eb0:	41 81 fe ff 00 00 00 	cmp    $0xff,%r14d
  3a1eb7:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  3a1ebb:	0f 84 f2 00 00 00    	je     3a1fb3 <<oriole::Parser>::parse_text+0x5983>
  3a1ec1:	4c 8b 6b 20          	mov    0x20(%rbx),%r13
  3a1ec5:	4d 8d bd 90 08 00 00 	lea    0x890(%r13),%r15
  3a1ecc:	4c 89 f8             	mov    %r15,%rax
  3a1ecf:	48 c1 e8 03          	shr    $0x3,%rax
  3a1ed3:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a1eda:	7f 
  3a1edb:	31 ff                	xor    %edi,%edi
  3a1edd:	44 89 e6             	mov    %r12d,%esi
  3a1ee0:	e8 fb 89 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1ee5:	45 85 e4             	test   %r12d,%r12d
  3a1ee8:	0f 85 6c 0d 00 00    	jne    3a2c5a <<oriole::Parser>::parse_text+0x662a>
  3a1eee:	4d 8b bd 90 08 00 00 	mov    0x890(%r13),%r15
  3a1ef5:	49 81 c5 98 08 00 00 	add    $0x898,%r13
  3a1efc:	4c 89 e8             	mov    %r13,%rax
  3a1eff:	48 c1 e8 03          	shr    $0x3,%rax
  3a1f03:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a1f0a:	7f 
  3a1f0b:	31 ff                	xor    %edi,%edi
  3a1f0d:	44 89 e6             	mov    %r12d,%esi
  3a1f10:	e8 cb 89 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1f15:	45 85 e4             	test   %r12d,%r12d
  3a1f18:	0f 85 4c 0d 00 00    	jne    3a2c6a <<oriole::Parser>::parse_text+0x663a>
  3a1f1e:	4d 89 fc             	mov    %r15,%r12
  3a1f21:	49 8b 45 00          	mov    0x0(%r13),%rax
  3a1f25:	48 89 43 08          	mov    %rax,0x8(%rbx)
  3a1f29:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  3a1f30:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  3a1f37:	7f 
  3a1f38:	31 ff                	xor    %edi,%edi
  3a1f3a:	44 89 ee             	mov    %r13d,%esi
  3a1f3d:	e8 9e 89 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1f42:	45 85 ed             	test   %r13d,%r13d
  3a1f45:	0f 85 2f 0d 00 00    	jne    3a2c7a <<oriole::Parser>::parse_text+0x664a>
  3a1f4b:	48 8b 43 48          	mov    0x48(%rbx),%rax
  3a1f4f:	4c 8b 28             	mov    (%rax),%r13
  3a1f52:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  3a1f59:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a1f60:	7f 
  3a1f61:	31 ff                	xor    %edi,%edi
  3a1f63:	44 89 fe             	mov    %r15d,%esi
  3a1f66:	e8 75 89 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1f6b:	45 85 ff             	test   %r15d,%r15d
  3a1f6e:	0f 85 17 0d 00 00    	jne    3a2c8b <<oriole::Parser>::parse_text+0x665b>
  3a1f74:	fe 05 1a 67 24 00    	incb   0x24671a(%rip)        # 5e8694 <__start___sancov_cntrs+0x7274>
  3a1f7a:	48 8b 43 38          	mov    0x38(%rbx),%rax
  3a1f7e:	48 8b 10             	mov    (%rax),%rdx
  3a1f81:	48 83 ec 08          	sub    $0x8,%rsp
  3a1f85:	41 0f b6 ce          	movzbl %r14b,%ecx
  3a1f89:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  3a1f8d:	4c 89 ee             	mov    %r13,%rsi
  3a1f90:	4d 89 e0             	mov    %r12,%r8
  3a1f93:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
  3a1f97:	ff 73 28             	push   0x28(%rbx)
  3a1f9a:	e9 61 02 00 00       	jmp    3a2200 <<oriole::Parser>::parse_text+0x5bd0>
  3a1f9f:	fe 05 df 66 24 00    	incb   0x2466df(%rip)        # 5e8684 <__start___sancov_cntrs+0x7264>
  3a1fa5:	eb 12                	jmp    3a1fb9 <<oriole::Parser>::parse_text+0x5989>
  3a1fa7:	fe 05 de 66 24 00    	incb   0x2466de(%rip)        # 5e868b <__start___sancov_cntrs+0x726b>
  3a1fad:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  3a1fb1:	eb 06                	jmp    3a1fb9 <<oriole::Parser>::parse_text+0x5989>
  3a1fb3:	fe 05 d6 66 24 00    	incb   0x2466d6(%rip)        # 5e868f <__start___sancov_cntrs+0x726f>
  3a1fb9:	48 8b 83 f0 00 00 00 	mov    0xf0(%rbx),%rax
  3a1fc0:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a1fc7:	7f 
  3a1fc8:	31 ff                	xor    %edi,%edi
  3a1fca:	44 89 f6             	mov    %r14d,%esi
  3a1fcd:	e8 0e 89 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a1fd2:	45 85 f6             	test   %r14d,%r14d
  3a1fd5:	75 6d                	jne    3a2044 <<oriole::Parser>::parse_text+0x5a14>
  3a1fd7:	fe 05 a8 66 24 00    	incb   0x2466a8(%rip)        # 5e8685 <__start___sancov_cntrs+0x7265>
  3a1fdd:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a1fe1:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  3a1fe6:	0f 85 91 00 00 00    	jne    3a207d <<oriole::Parser>::parse_text+0x5a4d>
  3a1fec:	fe 05 96 66 24 00    	incb   0x246696(%rip)        # 5e8688 <__start___sancov_cntrs+0x7268>
  3a1ff2:	e9 31 02 00 00       	jmp    3a2228 <<oriole::Parser>::parse_text+0x5bf8>
  3a1ff7:	45 89 f4             	mov    %r14d,%r12d
  3a1ffa:	41 83 e4 07          	and    $0x7,%r12d
  3a1ffe:	45 0f b6 ff          	movzbl %r15b,%r15d
  3a2002:	44 89 e7             	mov    %r12d,%edi
  3a2005:	44 89 fe             	mov    %r15d,%esi
  3a2008:	e8 43 88 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a200d:	45 38 fc             	cmp    %r15b,%r12b
  3a2010:	0f 8d f1 0f 00 00    	jge    3a3007 <<oriole::Parser>::parse_text+0x69d7>
  3a2016:	fe 05 d8 65 24 00    	incb   0x2465d8(%rip)        # 5e85f4 <__start___sancov_cntrs+0x71d4>
  3a201c:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a2020:	e9 db f3 ff ff       	jmp    3a1400 <<oriole::Parser>::parse_text+0x4dd0>
  3a2025:	fe 05 cb 65 24 00    	incb   0x2465cb(%rip)        # 5e85f6 <__start___sancov_cntrs+0x71d6>
  3a202b:	eb 06                	jmp    3a2033 <<oriole::Parser>::parse_text+0x5a03>
  3a202d:	fe 05 be 65 24 00    	incb   0x2465be(%rip)        # 5e85f1 <__start___sancov_cntrs+0x71d1>
  3a2033:	e8 18 71 e9 ff       	call   239150 <__asan_handle_no_return>
  3a2038:	4c 8d 05 a1 0f 21 00 	lea    0x210fa1(%rip),%r8        # 5b2fe0 <alloc_a7a80b999c36c2b260d00647d4ede4d5>
  3a203f:	e9 65 f7 ff ff       	jmp    3a17a9 <<oriole::Parser>::parse_text+0x5179>
  3a2044:	41 83 e4 07          	and    $0x7,%r12d
  3a2048:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a204c:	44 89 e7             	mov    %r12d,%edi
  3a204f:	44 89 f6             	mov    %r14d,%esi
  3a2052:	e8 f9 87 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a2057:	45 38 f4             	cmp    %r14b,%r12b
  3a205a:	0f 8d b7 0f 00 00    	jge    3a3017 <<oriole::Parser>::parse_text+0x69e7>
  3a2060:	fe 05 20 66 24 00    	incb   0x246620(%rip)        # 5e8686 <__start___sancov_cntrs+0x7266>
  3a2066:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a206a:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  3a206e:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a2072:	41 80 3c 24 01       	cmpb   $0x1,(%r12)
  3a2077:	0f 84 6f ff ff ff    	je     3a1fec <<oriole::Parser>::parse_text+0x59bc>
  3a207d:	4c 8d b0 5c 08 00 00 	lea    0x85c(%rax),%r14
  3a2084:	4c 89 f0             	mov    %r14,%rax
  3a2087:	48 c1 e8 03          	shr    $0x3,%rax
  3a208b:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a2092:	7f 
  3a2093:	31 ff                	xor    %edi,%edi
  3a2095:	44 89 e6             	mov    %r12d,%esi
  3a2098:	e8 43 88 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a209d:	45 85 e4             	test   %r12d,%r12d
  3a20a0:	0f 85 19 03 00 00    	jne    3a23bf <<oriole::Parser>::parse_text+0x5d8f>
  3a20a6:	fe 05 e9 65 24 00    	incb   0x2465e9(%rip)        # 5e8695 <__start___sancov_cntrs+0x7275>
  3a20ac:	48 8b b3 80 00 00 00 	mov    0x80(%rbx),%rsi
  3a20b3:	41 0f b6 3e          	movzbl (%r14),%edi
  3a20b7:	4c 89 ea             	mov    %r13,%rdx
  3a20ba:	e8 21 9a f6 ff       	call   30bae0 <<oriole::names::NameRules>::is_name>
  3a20bf:	84 c0                	test   %al,%al
  3a20c1:	0f 84 47 01 00 00    	je     3a220e <<oriole::Parser>::parse_text+0x5bde>
  3a20c7:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  3a20ce:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a20d5:	7f 
  3a20d6:	31 ff                	xor    %edi,%edi
  3a20d8:	44 89 f6             	mov    %r14d,%esi
  3a20db:	e8 00 88 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a20e0:	45 85 f6             	test   %r14d,%r14d
  3a20e3:	0f 85 3f 0b 00 00    	jne    3a2c28 <<oriole::Parser>::parse_text+0x65f8>
  3a20e9:	48 8b 43 48          	mov    0x48(%rbx),%rax
  3a20ed:	4c 8b 30             	mov    (%rax),%r14
  3a20f0:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  3a20f7:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a20fe:	7f 
  3a20ff:	31 ff                	xor    %edi,%edi
  3a2101:	44 89 e6             	mov    %r12d,%esi
  3a2104:	e8 d7 87 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a2109:	45 85 e4             	test   %r12d,%r12d
  3a210c:	0f 85 27 0b 00 00    	jne    3a2c39 <<oriole::Parser>::parse_text+0x6609>
  3a2112:	48 8b 43 38          	mov    0x38(%rbx),%rax
  3a2116:	48 8b 30             	mov    (%rax),%rsi
  3a2119:	4c 89 f7             	mov    %r14,%rdi
  3a211c:	e8 0f f4 05 00       	call   401530 <<oriole::Parser>::source>
  3a2121:	48 89 c7             	mov    %rax,%rdi
  3a2124:	e8 27 cd fd ff       	call   37ee50 <<oriole::encoding::Source>::remaining>
  3a2129:	49 89 c6             	mov    %rax,%r14
  3a212c:	49 89 d4             	mov    %rdx,%r12
  3a212f:	4c 89 ef             	mov    %r13,%rdi
  3a2132:	48 89 d6             	mov    %rdx,%rsi
  3a2135:	e8 96 83 11 00       	call   4ba4d0 <__sanitizer_cov_trace_cmp8>
  3a213a:	4d 39 e5             	cmp    %r12,%r13
  3a213d:	0f 83 d3 00 00 00    	jae    3a2216 <<oriole::Parser>::parse_text+0x5be6>
  3a2143:	4d 01 ee             	add    %r13,%r14
  3a2146:	4c 89 f0             	mov    %r14,%rax
  3a2149:	48 c1 e8 03          	shr    $0x3,%rax
  3a214d:	44 0f b6 a0 00 80 ff 	movzbl 0x7fff8000(%rax),%r12d
  3a2154:	7f 
  3a2155:	31 ff                	xor    %edi,%edi
  3a2157:	44 89 e6             	mov    %r12d,%esi
  3a215a:	e8 81 87 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a215f:	45 85 e4             	test   %r12d,%r12d
  3a2162:	0f 85 17 03 00 00    	jne    3a247f <<oriole::Parser>::parse_text+0x5e4f>
  3a2168:	fe 05 32 65 24 00    	incb   0x246532(%rip)        # 5e86a0 <__start___sancov_cntrs+0x7280>
  3a216e:	45 0f b6 36          	movzbl (%r14),%r14d
  3a2172:	bf 3c 00 00 00       	mov    $0x3c,%edi
  3a2177:	44 89 f6             	mov    %r14d,%esi
  3a217a:	e8 61 87 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a217f:	41 83 fe 3c          	cmp    $0x3c,%r14d
  3a2183:	0f 85 95 00 00 00    	jne    3a221e <<oriole::Parser>::parse_text+0x5bee>
  3a2189:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  3a2190:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a2197:	7f 
  3a2198:	31 ff                	xor    %edi,%edi
  3a219a:	44 89 f6             	mov    %r14d,%esi
  3a219d:	e8 3e 87 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a21a2:	45 85 f6             	test   %r14d,%r14d
  3a21a5:	0f 85 24 0b 00 00    	jne    3a2ccf <<oriole::Parser>::parse_text+0x669f>
  3a21ab:	48 8b 43 48          	mov    0x48(%rbx),%rax
  3a21af:	4c 8b 30             	mov    (%rax),%r14
  3a21b2:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  3a21b9:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a21c0:	7f 
  3a21c1:	31 ff                	xor    %edi,%edi
  3a21c3:	44 89 fe             	mov    %r15d,%esi
  3a21c6:	e8 15 87 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a21cb:	45 85 ff             	test   %r15d,%r15d
  3a21ce:	0f 85 0c 0b 00 00    	jne    3a2ce0 <<oriole::Parser>::parse_text+0x66b0>
  3a21d4:	fe 05 cc 64 24 00    	incb   0x2464cc(%rip)        # 5e86a6 <__start___sancov_cntrs+0x7286>
  3a21da:	48 8b 43 38          	mov    0x38(%rbx),%rax
  3a21de:	48 8b 10             	mov    (%rax),%rdx
  3a21e1:	48 83 ec 08          	sub    $0x8,%rsp
  3a21e5:	4c 8d 05 34 14 1a 00 	lea    0x1a1434(%rip),%r8        # 543620 <alloc_c5ea841cd681278b175a43aba8663adb>
  3a21ec:	41 b9 14 00 00 00    	mov    $0x14,%r9d
  3a21f2:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  3a21f6:	4c 89 f6             	mov    %r14,%rsi
  3a21f9:	b9 03 00 00 00       	mov    $0x3,%ecx
  3a21fe:	41 55                	push   %r13
  3a2200:	e8 2b f1 05 00       	call   401330 <<oriole::Parser>::err_at>
  3a2205:	48 83 c4 10          	add    $0x10,%rsp
  3a2209:	e9 6b f4 ff ff       	jmp    3a1679 <<oriole::Parser>::parse_text+0x5049>
  3a220e:	fe 05 84 64 24 00    	incb   0x246484(%rip)        # 5e8698 <__start___sancov_cntrs+0x7278>
  3a2214:	eb 0e                	jmp    3a2224 <<oriole::Parser>::parse_text+0x5bf4>
  3a2216:	fe 05 83 64 24 00    	incb   0x246483(%rip)        # 5e869f <__start___sancov_cntrs+0x727f>
  3a221c:	eb 06                	jmp    3a2224 <<oriole::Parser>::parse_text+0x5bf4>
  3a221e:	fe 05 7f 64 24 00    	incb   0x24647f(%rip)        # 5e86a3 <__start___sancov_cntrs+0x7283>
  3a2224:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a2228:	48 05 44 09 00 00    	add    $0x944,%rax
  3a222e:	49 89 c7             	mov    %rax,%r15
  3a2231:	48 c1 e8 03          	shr    $0x3,%rax
  3a2235:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a223c:	7f 
  3a223d:	31 ff                	xor    %edi,%edi
  3a223f:	44 89 f6             	mov    %r14d,%esi
  3a2242:	e8 99 86 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a2247:	45 85 f6             	test   %r14d,%r14d
  3a224a:	75 49                	jne    3a2295 <<oriole::Parser>::parse_text+0x5c65>
  3a224c:	fe 05 47 64 24 00    	incb   0x246447(%rip)        # 5e8699 <__start___sancov_cntrs+0x7279>
  3a2252:	41 80 3f 00          	cmpb   $0x0,(%r15)
  3a2256:	74 68                	je     3a22c0 <<oriole::Parser>::parse_text+0x5c90>
  3a2258:	48 8b 43 08          	mov    0x8(%rbx),%rax
  3a225c:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a2263:	7f 
  3a2264:	31 ff                	xor    %edi,%edi
  3a2266:	44 89 f6             	mov    %r14d,%esi
  3a2269:	e8 72 86 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a226e:	45 85 f6             	test   %r14d,%r14d
  3a2271:	0f 85 7d 01 00 00    	jne    3a23f4 <<oriole::Parser>::parse_text+0x5dc4>
  3a2277:	fe 05 2a 64 24 00    	incb   0x24642a(%rip)        # 5e86a7 <__start___sancov_cntrs+0x7287>
  3a227d:	48 8b 43 18          	mov    0x18(%rbx),%rax
  3a2281:	80 38 00             	cmpb   $0x0,(%rax)
  3a2284:	b8 01 00 00 00       	mov    $0x1,%eax
  3a2289:	41 bc 08 00 00 00    	mov    $0x8,%r12d
  3a228f:	44 0f 45 e0          	cmovne %eax,%r12d
  3a2293:	eb 34                	jmp    3a22c9 <<oriole::Parser>::parse_text+0x5c99>
  3a2295:	45 89 fc             	mov    %r15d,%r12d
  3a2298:	41 83 e4 07          	and    $0x7,%r12d
  3a229c:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a22a0:	44 89 e7             	mov    %r12d,%edi
  3a22a3:	44 89 f6             	mov    %r14d,%esi
  3a22a6:	e8 a5 85 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a22ab:	45 38 f4             	cmp    %r14b,%r12b
  3a22ae:	0f 8d 74 0d 00 00    	jge    3a3028 <<oriole::Parser>::parse_text+0x69f8>
  3a22b4:	fe 05 e0 63 24 00    	incb   0x2463e0(%rip)        # 5e869a <__start___sancov_cntrs+0x727a>
  3a22ba:	41 80 3f 00          	cmpb   $0x0,(%r15)
  3a22be:	75 98                	jne    3a2258 <<oriole::Parser>::parse_text+0x5c28>
  3a22c0:	fe 05 d6 63 24 00    	incb   0x2463d6(%rip)        # 5e869c <__start___sancov_cntrs+0x727c>
  3a22c6:	41 b4 01             	mov    $0x1,%r12b
  3a22c9:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  3a22d0:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a22d7:	7f 
  3a22d8:	31 ff                	xor    %edi,%edi
  3a22da:	44 89 f6             	mov    %r14d,%esi
  3a22dd:	e8 fe 85 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a22e2:	45 85 f6             	test   %r14d,%r14d
  3a22e5:	0f 85 97 08 00 00    	jne    3a2b82 <<oriole::Parser>::parse_text+0x6552>
  3a22eb:	48 8b 43 48          	mov    0x48(%rbx),%rax
  3a22ef:	4c 8b 30             	mov    (%rax),%r14
  3a22f2:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  3a22f9:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a2300:	7f 
  3a2301:	31 ff                	xor    %edi,%edi
  3a2303:	44 89 fe             	mov    %r15d,%esi
  3a2306:	e8 d5 85 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a230b:	45 85 ff             	test   %r15d,%r15d
  3a230e:	0f 85 7f 08 00 00    	jne    3a2b93 <<oriole::Parser>::parse_text+0x6563>
  3a2314:	fe 05 92 63 24 00    	incb   0x246392(%rip)        # 5e86ac <__start___sancov_cntrs+0x728c>
  3a231a:	48 8b 43 38          	mov    0x38(%rbx),%rax
  3a231e:	48 8b 10             	mov    (%rax),%rdx
  3a2321:	41 0f b6 cc          	movzbl %r12b,%ecx
  3a2325:	4c 8d 05 34 13 1a 00 	lea    0x1a1334(%rip),%r8        # 543660 <alloc_afb9a668f175ecf49e09b76dd3eae0b7>
  3a232c:	4c 8d bb 20 01 00 00 	lea    0x120(%rbx),%r15
  3a2333:	41 b9 2b 00 00 00    	mov    $0x2b,%r9d
  3a2339:	4c 89 ff             	mov    %r15,%rdi
  3a233c:	4c 89 f6             	mov    %r14,%rsi
  3a233f:	e8 6c ba 05 00       	call   3fddb0 <<oriole::Parser>::err>
  3a2344:	ba 38 00 00 00       	mov    $0x38,%edx
  3a2349:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  3a234d:	4c 89 fe             	mov    %r15,%rsi
  3a2350:	e9 1f f3 ff ff       	jmp    3a1674 <<oriole::Parser>::parse_text+0x5044>
  3a2355:	45 89 f5             	mov    %r14d,%r13d
  3a2358:	41 83 e5 07          	and    $0x7,%r13d
  3a235c:	45 0f b6 e4          	movzbl %r12b,%r12d
  3a2360:	44 89 ef             	mov    %r13d,%edi
  3a2363:	44 89 e6             	mov    %r12d,%esi
  3a2366:	e8 e5 84 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a236b:	45 38 e5             	cmp    %r12b,%r13b
  3a236e:	0f 8d c4 0c 00 00    	jge    3a3038 <<oriole::Parser>::parse_text+0x6a08>
  3a2374:	fe 05 e3 62 24 00    	incb   0x2462e3(%rip)        # 5e865d <__start___sancov_cntrs+0x723d>
  3a237a:	48 8b b3 80 00 00 00 	mov    0x80(%rbx),%rsi
  3a2381:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a2385:	e9 70 f7 ff ff       	jmp    3a1afa <<oriole::Parser>::parse_text+0x54ca>
  3a238a:	45 89 f5             	mov    %r14d,%r13d
  3a238d:	41 83 e5 07          	and    $0x7,%r13d
  3a2391:	45 0f b6 e4          	movzbl %r12b,%r12d
  3a2395:	44 89 ef             	mov    %r13d,%edi
  3a2398:	44 89 e6             	mov    %r12d,%esi
  3a239b:	e8 b0 84 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a23a0:	45 38 e5             	cmp    %r12b,%r13b
  3a23a3:	0f 8d 9f 0c 00 00    	jge    3a3048 <<oriole::Parser>::parse_text+0x6a18>
  3a23a9:	fe 05 d3 62 24 00    	incb   0x2462d3(%rip)        # 5e8682 <__start___sancov_cntrs+0x7262>
  3a23af:	48 8b b3 80 00 00 00 	mov    0x80(%rbx),%rsi
  3a23b6:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a23ba:	e9 1c fa ff ff       	jmp    3a1ddb <<oriole::Parser>::parse_text+0x57ab>
  3a23bf:	45 89 f5             	mov    %r14d,%r13d
  3a23c2:	41 83 e5 07          	and    $0x7,%r13d
  3a23c6:	45 0f b6 e4          	movzbl %r12b,%r12d
  3a23ca:	44 89 ef             	mov    %r13d,%edi
  3a23cd:	44 89 e6             	mov    %r12d,%esi
  3a23d0:	e8 7b 84 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a23d5:	45 38 e5             	cmp    %r12b,%r13b
  3a23d8:	0f 8d 7a 0c 00 00    	jge    3a3058 <<oriole::Parser>::parse_text+0x6a28>
  3a23de:	fe 05 b2 62 24 00    	incb   0x2462b2(%rip)        # 5e8696 <__start___sancov_cntrs+0x7276>
  3a23e4:	48 8b b3 80 00 00 00 	mov    0x80(%rbx),%rsi
  3a23eb:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a23ef:	e9 bf fc ff ff       	jmp    3a20b3 <<oriole::Parser>::parse_text+0x5a83>
  3a23f4:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  3a23f8:	41 83 e4 07          	and    $0x7,%r12d
  3a23fc:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a2400:	44 89 e7             	mov    %r12d,%edi
  3a2403:	44 89 f6             	mov    %r14d,%esi
  3a2406:	e8 45 84 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a240b:	45 38 f4             	cmp    %r14b,%r12b
  3a240e:	0f 8d 54 0c 00 00    	jge    3a3068 <<oriole::Parser>::parse_text+0x6a38>
  3a2414:	fe 05 8e 62 24 00    	incb   0x24628e(%rip)        # 5e86a8 <__start___sancov_cntrs+0x7288>
  3a241a:	e9 5e fe ff ff       	jmp    3a227d <<oriole::Parser>::parse_text+0x5c4d>
  3a241f:	4c 8b a3 e0 00 00 00 	mov    0xe0(%rbx),%r12
  3a2426:	41 83 e4 07          	and    $0x7,%r12d
  3a242a:	45 0f b6 ff          	movzbl %r15b,%r15d
  3a242e:	44 89 e7             	mov    %r12d,%edi
  3a2431:	44 89 fe             	mov    %r15d,%esi
  3a2434:	e8 17 84 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a2439:	45 38 fc             	cmp    %r15b,%r12b
  3a243c:	0f 8d 37 0c 00 00    	jge    3a3079 <<oriole::Parser>::parse_text+0x6a49>
  3a2442:	fe 05 68 61 24 00    	incb   0x246168(%rip)        # 5e85b0 <__start___sancov_cntrs+0x7190>
  3a2448:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a244c:	e9 75 da ff ff       	jmp    39fec6 <<oriole::Parser>::parse_text+0x3896>
  3a2451:	45 89 f5             	mov    %r14d,%r13d
  3a2454:	41 83 e5 07          	and    $0x7,%r13d
  3a2458:	45 0f b6 e4          	movzbl %r12b,%r12d
  3a245c:	44 89 ef             	mov    %r13d,%edi
  3a245f:	44 89 e6             	mov    %r12d,%esi
  3a2462:	e8 e9 83 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a2467:	45 38 e5             	cmp    %r12b,%r13b
  3a246a:	0f 8d 1d 0c 00 00    	jge    3a308d <<oriole::Parser>::parse_text+0x6a5d>
  3a2470:	fe 05 17 62 24 00    	incb   0x246217(%rip)        # 5e868d <__start___sancov_cntrs+0x726d>
  3a2476:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a247a:	e9 20 fa ff ff       	jmp    3a1e9f <<oriole::Parser>::parse_text+0x586f>
  3a247f:	45 89 f5             	mov    %r14d,%r13d
  3a2482:	41 83 e5 07          	and    $0x7,%r13d
  3a2486:	45 0f b6 e4          	movzbl %r12b,%r12d
  3a248a:	44 89 ef             	mov    %r13d,%edi
  3a248d:	44 89 e6             	mov    %r12d,%esi
  3a2490:	e8 bb 83 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a2495:	45 38 e5             	cmp    %r12b,%r13b
  3a2498:	0f 8d ff 0b 00 00    	jge    3a309d <<oriole::Parser>::parse_text+0x6a6d>
  3a249e:	fe 05 fd 61 24 00    	incb   0x2461fd(%rip)        # 5e86a1 <__start___sancov_cntrs+0x7281>
  3a24a4:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a24a8:	e9 c1 fc ff ff       	jmp    3a216e <<oriole::Parser>::parse_text+0x5b3e>
  3a24ad:	fe 05 7b 60 24 00    	incb   0x24607b(%rip)        # 5e852e <__start___sancov_cntrs+0x710e>
  3a24b3:	4c 89 e7             	mov    %r12,%rdi
  3a24b6:	e8 b5 54 e9 ff       	call   237970 <__asan_report_load1>
  3a24bb:	0f 0b                	ud2
  3a24bd:	fe 05 83 60 24 00    	incb   0x246083(%rip)        # 5e8546 <__start___sancov_cntrs+0x7126>
  3a24c3:	48 8b 43 50          	mov    0x50(%rbx),%rax
  3a24c7:	48 03 43 40          	add    0x40(%rbx),%rax
  3a24cb:	48 03 43 70          	add    0x70(%rbx),%rax
  3a24cf:	49 8d 3c 07          	lea    (%r15,%rax,1),%rdi
  3a24d3:	48 ff c7             	inc    %rdi
  3a24d6:	e8 95 54 e9 ff       	call   237970 <__asan_report_load1>
  3a24db:	0f 0b                	ud2
  3a24dd:	fe 05 2f 60 24 00    	incb   0x24602f(%rip)        # 5e8512 <__start___sancov_cntrs+0x70f2>
  3a24e3:	48 8b 7b 70          	mov    0x70(%rbx),%rdi
  3a24e7:	e8 84 54 e9 ff       	call   237970 <__asan_report_load1>
  3a24ec:	0f 0b                	ud2
  3a24ee:	fe 05 2c 60 24 00    	incb   0x24602c(%rip)        # 5e8520 <__start___sancov_cntrs+0x7100>
  3a24f4:	4c 89 f7             	mov    %r14,%rdi
  3a24f7:	e8 74 54 e9 ff       	call   237970 <__asan_report_load1>
  3a24fc:	0f 0b                	ud2
  3a24fe:	fe 05 5d 5f 24 00    	incb   0x245f5d(%rip)        # 5e8461 <__start___sancov_cntrs+0x7041>
  3a2504:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2508:	e8 a3 56 e9 ff       	call   237bb0 <__asan_report_load8>
  3a250d:	0f 0b                	ud2
  3a250f:	fe 05 75 5f 24 00    	incb   0x245f75(%rip)        # 5e848a <__start___sancov_cntrs+0x706a>
  3a2515:	4c 89 ff             	mov    %r15,%rdi
  3a2518:	e8 93 56 e9 ff       	call   237bb0 <__asan_report_load8>
  3a251d:	0f 0b                	ud2
  3a251f:	fe 05 66 5f 24 00    	incb   0x245f66(%rip)        # 5e848b <__start___sancov_cntrs+0x706b>
  3a2525:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2529:	e8 82 56 e9 ff       	call   237bb0 <__asan_report_load8>
  3a252e:	0f 0b                	ud2
  3a2530:	fe 05 79 5f 24 00    	incb   0x245f79(%rip)        # 5e84af <__start___sancov_cntrs+0x708f>
  3a2536:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a253a:	e8 71 56 e9 ff       	call   237bb0 <__asan_report_load8>
  3a253f:	0f 0b                	ud2
  3a2541:	fe 05 69 5f 24 00    	incb   0x245f69(%rip)        # 5e84b0 <__start___sancov_cntrs+0x7090>
  3a2547:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a254b:	e8 60 56 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2550:	0f 0b                	ud2
  3a2552:	fe 05 5c 5f 24 00    	incb   0x245f5c(%rip)        # 5e84b4 <__start___sancov_cntrs+0x7094>
  3a2558:	4c 89 ff             	mov    %r15,%rdi
  3a255b:	e8 50 56 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2560:	0f 0b                	ud2
  3a2562:	fe 05 57 5f 24 00    	incb   0x245f57(%rip)        # 5e84bf <__start___sancov_cntrs+0x709f>
  3a2568:	e9 36 b3 ff ff       	jmp    39d8a3 <<oriole::Parser>::parse_text+0x1273>
  3a256d:	fe 05 76 5f 24 00    	incb   0x245f76(%rip)        # 5e84e9 <__start___sancov_cntrs+0x70c9>
  3a2573:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2577:	e8 34 56 e9 ff       	call   237bb0 <__asan_report_load8>
  3a257c:	0f 0b                	ud2
  3a257e:	fe 05 86 5f 24 00    	incb   0x245f86(%rip)        # 5e850a <__start___sancov_cntrs+0x70ea>
  3a2584:	4c 89 ff             	mov    %r15,%rdi
  3a2587:	e8 24 56 e9 ff       	call   237bb0 <__asan_report_load8>
  3a258c:	0f 0b                	ud2
  3a258e:	fe 05 a7 5f 24 00    	incb   0x245fa7(%rip)        # 5e853b <__start___sancov_cntrs+0x711b>
  3a2594:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  3a2598:	e8 d3 53 e9 ff       	call   237970 <__asan_report_load1>
  3a259d:	0f 0b                	ud2
  3a259f:	fe 05 54 5f 24 00    	incb   0x245f54(%rip)        # 5e84f9 <__start___sancov_cntrs+0x70d9>
  3a25a5:	e8 06 56 e9 ff       	call   237bb0 <__asan_report_load8>
  3a25aa:	0f 0b                	ud2
  3a25ac:	fe 05 4b 5f 24 00    	incb   0x245f4b(%rip)        # 5e84fd <__start___sancov_cntrs+0x70dd>
  3a25b2:	4c 89 e7             	mov    %r12,%rdi
  3a25b5:	e8 f6 55 e9 ff       	call   237bb0 <__asan_report_load8>
  3a25ba:	0f 0b                	ud2
  3a25bc:	fe 05 46 5f 24 00    	incb   0x245f46(%rip)        # 5e8508 <__start___sancov_cntrs+0x70e8>
  3a25c2:	e9 f2 dc ff ff       	jmp    3a02b9 <<oriole::Parser>::parse_text+0x3c89>
  3a25c7:	fe 05 bc 5f 24 00    	incb   0x245fbc(%rip)        # 5e8589 <__start___sancov_cntrs+0x7169>
  3a25cd:	48 8b 43 50          	mov    0x50(%rbx),%rax
  3a25d1:	48 03 43 40          	add    0x40(%rbx),%rax
  3a25d5:	49 8d 3c 06          	lea    (%r14,%rax,1),%rdi
  3a25d9:	48 ff cf             	dec    %rdi
  3a25dc:	e8 8f 53 e9 ff       	call   237970 <__asan_report_load1>
  3a25e1:	0f 0b                	ud2
  3a25e3:	45 89 e7             	mov    %r12d,%r15d
  3a25e6:	41 83 e7 07          	and    $0x7,%r15d
  3a25ea:	45 0f b6 ed          	movzbl %r13b,%r13d
  3a25ee:	44 89 ff             	mov    %r15d,%edi
  3a25f1:	44 89 ee             	mov    %r13d,%esi
  3a25f4:	e8 57 82 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a25f9:	45 38 ef             	cmp    %r13b,%r15b
  3a25fc:	0f 8d ab 0a 00 00    	jge    3a30ad <<oriole::Parser>::parse_text+0x6a7d>
  3a2602:	fe 05 66 60 24 00    	incb   0x246066(%rip)        # 5e866e <__start___sancov_cntrs+0x724e>
  3a2608:	41 80 3c 24 00       	cmpb   $0x0,(%r12)
  3a260d:	0f 85 10 f7 ff ff    	jne    3a1d23 <<oriole::Parser>::parse_text+0x56f3>
  3a2613:	fe 05 57 60 24 00    	incb   0x246057(%rip)        # 5e8670 <__start___sancov_cntrs+0x7250>
  3a2619:	48 8b 43 20          	mov    0x20(%rbx),%rax
  3a261d:	4c 8d a0 88 08 00 00 	lea    0x888(%rax),%r12
  3a2624:	4c 89 e0             	mov    %r12,%rax
  3a2627:	48 c1 e8 03          	shr    $0x3,%rax
  3a262b:	44 0f b6 a8 00 80 ff 	movzbl 0x7fff8000(%rax),%r13d
  3a2632:	7f 
  3a2633:	31 ff                	xor    %edi,%edi
  3a2635:	44 89 ee             	mov    %r13d,%esi
  3a2638:	e8 a3 82 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a263d:	45 85 ed             	test   %r13d,%r13d
  3a2640:	0f 85 cb 00 00 00    	jne    3a2711 <<oriole::Parser>::parse_text+0x60e1>
  3a2646:	fe 05 25 60 24 00    	incb   0x246025(%rip)        # 5e8671 <__start___sancov_cntrs+0x7251>
  3a264c:	45 0f b6 24 24       	movzbl (%r12),%r12d
  3a2651:	bf ff 00 00 00       	mov    $0xff,%edi
  3a2656:	44 89 e6             	mov    %r12d,%esi
  3a2659:	e8 82 82 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a265e:	41 81 fc ff 00 00 00 	cmp    $0xff,%r12d
  3a2665:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a2669:	74 0b                	je     3a2676 <<oriole::Parser>::parse_text+0x6046>
  3a266b:	fe 05 03 60 24 00    	incb   0x246003(%rip)        # 5e8674 <__start___sancov_cntrs+0x7254>
  3a2671:	e9 e2 f5 ff ff       	jmp    3a1c58 <<oriole::Parser>::parse_text+0x5628>
  3a2676:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  3a267d:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  3a2684:	7f 
  3a2685:	31 ff                	xor    %edi,%edi
  3a2687:	44 89 fe             	mov    %r15d,%esi
  3a268a:	e8 51 82 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a268f:	45 85 ff             	test   %r15d,%r15d
  3a2692:	0f 85 59 06 00 00    	jne    3a2cf1 <<oriole::Parser>::parse_text+0x66c1>
  3a2698:	48 8b 43 48          	mov    0x48(%rbx),%rax
  3a269c:	48 8b 38             	mov    (%rax),%rdi
  3a269f:	4c 89 f6             	mov    %r14,%rsi
  3a26a2:	e8 69 1c 00 00       	call   3a4310 <<oriole::Parser>::source_mut>
  3a26a7:	48 89 c7             	mov    %rax,%rdi
  3a26aa:	e8 71 8a fd ff       	call   37b120 <<oriole::encoding::Source>::mark_deferred>
  3a26af:	48 8b 43 58          	mov    0x58(%rbx),%rax
  3a26b3:	48 c1 e8 03          	shr    $0x3,%rax
  3a26b7:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a26be:	7f 
  3a26bf:	31 ff                	xor    %edi,%edi
  3a26c1:	44 89 f6             	mov    %r14d,%esi
  3a26c4:	e8 17 82 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a26c9:	45 85 f6             	test   %r14d,%r14d
  3a26cc:	0f 85 ac 02 00 00    	jne    3a297e <<oriole::Parser>::parse_text+0x634e>
  3a26d2:	fe 05 a3 5f 24 00    	incb   0x245fa3(%rip)        # 5e867b <__start___sancov_cntrs+0x725b>
  3a26d8:	4c 8b 7b 58          	mov    0x58(%rbx),%r15
  3a26dc:	41 c6 07 00          	movb   $0x0,(%r15)
  3a26e0:	49 83 c7 30          	add    $0x30,%r15
  3a26e4:	4c 89 f8             	mov    %r15,%rax
  3a26e7:	48 c1 e8 03          	shr    $0x3,%rax
  3a26eb:	44 0f b6 b0 00 80 ff 	movzbl 0x7fff8000(%rax),%r14d
  3a26f2:	7f 
  3a26f3:	31 ff                	xor    %edi,%edi
  3a26f5:	44 89 f6             	mov    %r14d,%esi
  3a26f8:	e8 e3 81 11 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  3a26fd:	45 85 f6             	test   %r14d,%r14d
  3a2700:	0f 85 a3 02 00 00    	jne    3a29a9 <<oriole::Parser>::parse_text+0x6379>
  3a2706:	fe 05 72 5f 24 00    	incb   0x245f72(%rip)        # 5e867e <__start___sancov_cntrs+0x725e>
  3a270c:	e9 b8 c4 ff ff       	jmp    39ebc9 <<oriole::Parser>::parse_text+0x2599>
  3a2711:	45 89 e7             	mov    %r12d,%r15d
  3a2714:	41 83 e7 07          	and    $0x7,%r15d
  3a2718:	45 0f b6 ed          	movzbl %r13b,%r13d
  3a271c:	44 89 ff             	mov    %r15d,%edi
  3a271f:	44 89 ee             	mov    %r13d,%esi
  3a2722:	e8 29 81 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a2727:	45 38 ef             	cmp    %r13b,%r15b
  3a272a:	0f 8d 8d 09 00 00    	jge    3a30bd <<oriole::Parser>::parse_text+0x6a8d>
  3a2730:	fe 05 3c 5f 24 00    	incb   0x245f3c(%rip)        # 5e8672 <__start___sancov_cntrs+0x7252>
  3a2736:	e9 11 ff ff ff       	jmp    3a264c <<oriole::Parser>::parse_text+0x601c>
  3a273b:	fe 05 f9 5e 24 00    	incb   0x245ef9(%rip)        # 5e863a <__start___sancov_cntrs+0x721a>
  3a2741:	48 8b bb d8 00 00 00 	mov    0xd8(%rbx),%rdi
  3a2748:	e8 63 54 e9 ff       	call   237bb0 <__asan_report_load8>
  3a274d:	0f 0b                	ud2
  3a274f:	fe 05 f2 5e 24 00    	incb   0x245ef2(%rip)        # 5e8647 <__start___sancov_cntrs+0x7227>
  3a2755:	4c 89 e7             	mov    %r12,%rdi
  3a2758:	e8 53 54 e9 ff       	call   237bb0 <__asan_report_load8>
  3a275d:	0f 0b                	ud2
  3a275f:	fe 05 e3 5e 24 00    	incb   0x245ee3(%rip)        # 5e8648 <__start___sancov_cntrs+0x7228>
  3a2765:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2769:	e8 42 54 e9 ff       	call   237bb0 <__asan_report_load8>
  3a276e:	0f 0b                	ud2
  3a2770:	fe 05 d6 5e 24 00    	incb   0x245ed6(%rip)        # 5e864c <__start___sancov_cntrs+0x722c>
  3a2776:	4c 89 ff             	mov    %r15,%rdi
  3a2779:	e8 32 54 e9 ff       	call   237bb0 <__asan_report_load8>
  3a277e:	0f 0b                	ud2
  3a2780:	fe 05 d0 5e 24 00    	incb   0x245ed0(%rip)        # 5e8656 <__start___sancov_cntrs+0x7236>
  3a2786:	4c 89 e7             	mov    %r12,%rdi
  3a2789:	e8 22 54 e9 ff       	call   237bb0 <__asan_report_load8>
  3a278e:	0f 0b                	ud2
  3a2790:	fe 05 1c 5f 24 00    	incb   0x245f1c(%rip)        # 5e86b2 <__start___sancov_cntrs+0x7292>
  3a2796:	4c 89 ff             	mov    %r15,%rdi
  3a2799:	e8 12 54 e9 ff       	call   237bb0 <__asan_report_load8>
  3a279e:	0f 0b                	ud2
  3a27a0:	45 89 e7             	mov    %r12d,%r15d
  3a27a3:	41 83 e7 07          	and    $0x7,%r15d
  3a27a7:	45 0f b6 ed          	movzbl %r13b,%r13d
  3a27ab:	44 89 ff             	mov    %r15d,%edi
  3a27ae:	44 89 ee             	mov    %r13d,%esi
  3a27b1:	e8 9a 80 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a27b6:	45 38 ef             	cmp    %r13b,%r15b
  3a27b9:	0f 8d 0e 09 00 00    	jge    3a30cd <<oriole::Parser>::parse_text+0x6a9d>
  3a27bf:	fe 05 b1 5e 24 00    	incb   0x245eb1(%rip)        # 5e8676 <__start___sancov_cntrs+0x7256>
  3a27c5:	41 f6 04 24 01       	testb  $0x1,(%r12)
  3a27ca:	0f 85 91 f5 ff ff    	jne    3a1d61 <<oriole::Parser>::parse_text+0x5731>
  3a27d0:	fe 05 a2 5e 24 00    	incb   0x245ea2(%rip)        # 5e8678 <__start___sancov_cntrs+0x7258>
  3a27d6:	4c 8b 63 60          	mov    0x60(%rbx),%r12
  3a27da:	4c 8b 6b 28          	mov    0x28(%rbx),%r13
  3a27de:	e9 79 f4 ff ff       	jmp    3a1c5c <<oriole::Parser>::parse_text+0x562c>
  3a27e3:	fe 05 f2 5d 24 00    	incb   0x245df2(%rip)        # 5e85db <__start___sancov_cntrs+0x71bb>
  3a27e9:	48 8b 7b 70          	mov    0x70(%rbx),%rdi
  3a27ed:	e8 7e 51 e9 ff       	call   237970 <__asan_report_load1>
  3a27f2:	0f 0b                	ud2
  3a27f4:	fe 05 e4 5d 24 00    	incb   0x245de4(%rip)        # 5e85de <__start___sancov_cntrs+0x71be>
  3a27fa:	4c 89 e7             	mov    %r12,%rdi
  3a27fd:	e8 6e 51 e9 ff       	call   237970 <__asan_report_load1>
  3a2802:	0f 0b                	ud2
  3a2804:	fe 05 ab 5d 24 00    	incb   0x245dab(%rip)        # 5e85b5 <__start___sancov_cntrs+0x7195>
  3a280a:	4c 89 ff             	mov    %r15,%rdi
  3a280d:	e8 5e 51 e9 ff       	call   237970 <__asan_report_load1>
  3a2812:	0f 0b                	ud2
  3a2814:	fe 05 8b 5d 24 00    	incb   0x245d8b(%rip)        # 5e85a5 <__start___sancov_cntrs+0x7185>
  3a281a:	4c 89 ef             	mov    %r13,%rdi
  3a281d:	e8 4e 51 e9 ff       	call   237970 <__asan_report_load1>
  3a2822:	0f 0b                	ud2
  3a2824:	fe 05 7e 5d 24 00    	incb   0x245d7e(%rip)        # 5e85a8 <__start___sancov_cntrs+0x7188>
  3a282a:	4c 89 ff             	mov    %r15,%rdi
  3a282d:	e8 3e 51 e9 ff       	call   237970 <__asan_report_load1>
  3a2832:	0f 0b                	ud2
  3a2834:	fe 05 71 5d 24 00    	incb   0x245d71(%rip)        # 5e85ab <__start___sancov_cntrs+0x718b>
  3a283a:	4c 89 ef             	mov    %r13,%rdi
  3a283d:	e8 2e 51 e9 ff       	call   237970 <__asan_report_load1>
  3a2842:	0f 0b                	ud2
  3a2844:	fe 05 6f 5d 24 00    	incb   0x245d6f(%rip)        # 5e85b9 <__start___sancov_cntrs+0x7199>
  3a284a:	48 8d 3d 9f b6 86 00 	lea    0x86b69f(%rip),%rdi        # c0def0 <std_detect::detect::cache::CACHE>
  3a2851:	e8 5a 53 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2856:	0f 0b                	ud2
  3a2858:	fe 05 35 5c 24 00    	incb   0x245c35(%rip)        # 5e8493 <__start___sancov_cntrs+0x7073>
  3a285e:	4c 89 f7             	mov    %r14,%rdi
  3a2861:	e8 4a 53 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2866:	0f 0b                	ud2
  3a2868:	fe 05 26 5c 24 00    	incb   0x245c26(%rip)        # 5e8494 <__start___sancov_cntrs+0x7074>
  3a286e:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2872:	e8 39 53 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2877:	0f 0b                	ud2
  3a2879:	fe 05 19 5c 24 00    	incb   0x245c19(%rip)        # 5e8498 <__start___sancov_cntrs+0x7078>
  3a287f:	4c 89 e7             	mov    %r12,%rdi
  3a2882:	e8 29 53 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2887:	0f 0b                	ud2
  3a2889:	fe 05 14 5c 24 00    	incb   0x245c14(%rip)        # 5e84a3 <__start___sancov_cntrs+0x7083>
  3a288f:	e9 83 e9 ff ff       	jmp    3a1217 <<oriole::Parser>::parse_text+0x4be7>
  3a2894:	fe 05 bd 5c 24 00    	incb   0x245cbd(%rip)        # 5e8557 <__start___sancov_cntrs+0x7137>
  3a289a:	e8 11 53 e9 ff       	call   237bb0 <__asan_report_load8>
  3a289f:	0f 0b                	ud2
  3a28a1:	fe 05 b1 5c 24 00    	incb   0x245cb1(%rip)        # 5e8558 <__start___sancov_cntrs+0x7138>
  3a28a7:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a28ab:	e8 00 53 e9 ff       	call   237bb0 <__asan_report_load8>
  3a28b0:	0f 0b                	ud2
  3a28b2:	fe 05 a4 5c 24 00    	incb   0x245ca4(%rip)        # 5e855c <__start___sancov_cntrs+0x713c>
  3a28b8:	4c 89 e7             	mov    %r12,%rdi
  3a28bb:	e8 f0 52 e9 ff       	call   237bb0 <__asan_report_load8>
  3a28c0:	0f 0b                	ud2
  3a28c2:	fe 05 9f 5c 24 00    	incb   0x245c9f(%rip)        # 5e8567 <__start___sancov_cntrs+0x7147>
  3a28c8:	e9 ec d9 ff ff       	jmp    3a02b9 <<oriole::Parser>::parse_text+0x3c89>
  3a28cd:	fe 05 f7 5b 24 00    	incb   0x245bf7(%rip)        # 5e84ca <__start___sancov_cntrs+0x70aa>
  3a28d3:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a28d7:	e8 d4 52 e9 ff       	call   237bb0 <__asan_report_load8>
  3a28dc:	0f 0b                	ud2
  3a28de:	fe 05 e7 5b 24 00    	incb   0x245be7(%rip)        # 5e84cb <__start___sancov_cntrs+0x70ab>
  3a28e4:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a28e8:	e8 c3 52 e9 ff       	call   237bb0 <__asan_report_load8>
  3a28ed:	0f 0b                	ud2
  3a28ef:	fe 05 da 5b 24 00    	incb   0x245bda(%rip)        # 5e84cf <__start___sancov_cntrs+0x70af>
  3a28f5:	4c 89 e7             	mov    %r12,%rdi
  3a28f8:	e8 b3 52 e9 ff       	call   237bb0 <__asan_report_load8>
  3a28fd:	0f 0b                	ud2
  3a28ff:	4c 89 6b 08          	mov    %r13,0x8(%rbx)
  3a2903:	fe 05 d1 5b 24 00    	incb   0x245bd1(%rip)        # 5e84da <__start___sancov_cntrs+0x70ba>
  3a2909:	e9 1d ea ff ff       	jmp    3a132b <<oriole::Parser>::parse_text+0x4cfb>
  3a290e:	fe 05 39 5d 24 00    	incb   0x245d39(%rip)        # 5e864d <__start___sancov_cntrs+0x722d>
  3a2914:	4c 89 ff             	mov    %r15,%rdi
  3a2917:	e8 94 52 e9 ff       	call   237bb0 <__asan_report_load8>
  3a291c:	0f 0b                	ud2
  3a291e:	fe 05 2a 5d 24 00    	incb   0x245d2a(%rip)        # 5e864e <__start___sancov_cntrs+0x722e>
  3a2924:	4c 89 ff             	mov    %r15,%rdi
  3a2927:	e8 84 52 e9 ff       	call   237bb0 <__asan_report_load8>
  3a292c:	0f 0b                	ud2
  3a292e:	fe 05 1b 5d 24 00    	incb   0x245d1b(%rip)        # 5e864f <__start___sancov_cntrs+0x722f>
  3a2934:	4c 89 ff             	mov    %r15,%rdi
  3a2937:	e8 74 52 e9 ff       	call   237bb0 <__asan_report_load8>
  3a293c:	0f 0b                	ud2
  3a293e:	fe 05 0c 5d 24 00    	incb   0x245d0c(%rip)        # 5e8650 <__start___sancov_cntrs+0x7230>
  3a2944:	4c 89 f7             	mov    %r14,%rdi
  3a2947:	e8 64 52 e9 ff       	call   237bb0 <__asan_report_load8>
  3a294c:	0f 0b                	ud2
  3a294e:	fe 05 fe 5c 24 00    	incb   0x245cfe(%rip)        # 5e8652 <__start___sancov_cntrs+0x7232>
  3a2954:	4c 89 e7             	mov    %r12,%rdi
  3a2957:	e8 54 52 e9 ff       	call   237bb0 <__asan_report_load8>
  3a295c:	0f 0b                	ud2
  3a295e:	fe 05 ef 5c 24 00    	incb   0x245cef(%rip)        # 5e8653 <__start___sancov_cntrs+0x7233>
  3a2964:	4c 89 e7             	mov    %r12,%rdi
  3a2967:	e8 44 52 e9 ff       	call   237bb0 <__asan_report_load8>
  3a296c:	0f 0b                	ud2
  3a296e:	fe 05 e0 5c 24 00    	incb   0x245ce0(%rip)        # 5e8654 <__start___sancov_cntrs+0x7234>
  3a2974:	4c 89 f7             	mov    %r14,%rdi
  3a2977:	e8 34 52 e9 ff       	call   237bb0 <__asan_report_load8>
  3a297c:	0f 0b                	ud2
  3a297e:	4c 8b 7b 58          	mov    0x58(%rbx),%r15
  3a2982:	41 83 e7 07          	and    $0x7,%r15d
  3a2986:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a298a:	44 89 ff             	mov    %r15d,%edi
  3a298d:	44 89 f6             	mov    %r14d,%esi
  3a2990:	e8 bb 7e 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a2995:	45 38 f7             	cmp    %r14b,%r15b
  3a2998:	0f 8d 3f 07 00 00    	jge    3a30dd <<oriole::Parser>::parse_text+0x6aad>
  3a299e:	fe 05 d8 5c 24 00    	incb   0x245cd8(%rip)        # 5e867c <__start___sancov_cntrs+0x725c>
  3a29a4:	e9 2f fd ff ff       	jmp    3a26d8 <<oriole::Parser>::parse_text+0x60a8>
  3a29a9:	4d 89 fc             	mov    %r15,%r12
  3a29ac:	41 83 e7 07          	and    $0x7,%r15d
  3a29b0:	45 0f b6 f6          	movzbl %r14b,%r14d
  3a29b4:	44 89 ff             	mov    %r15d,%edi
  3a29b7:	44 89 f6             	mov    %r14d,%esi
  3a29ba:	e8 91 7e 11 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  3a29bf:	45 38 f7             	cmp    %r14b,%r15b
  3a29c2:	0f 8d 26 07 00 00    	jge    3a30ee <<oriole::Parser>::parse_text+0x6abe>
  3a29c8:	fe 05 b1 5c 24 00    	incb   0x245cb1(%rip)        # 5e867f <__start___sancov_cntrs+0x725f>
  3a29ce:	41 c6 04 24 ff       	movb   $0xff,(%r12)
  3a29d3:	e9 a1 ec ff ff       	jmp    3a1679 <<oriole::Parser>::parse_text+0x5049>
  3a29d8:	fe 05 0c 5c 24 00    	incb   0x245c0c(%rip)        # 5e85ea <__start___sancov_cntrs+0x71ca>
  3a29de:	48 8b bb d8 00 00 00 	mov    0xd8(%rbx),%rdi
  3a29e5:	e8 c6 51 e9 ff       	call   237bb0 <__asan_report_load8>
  3a29ea:	0f 0b                	ud2
  3a29ec:	fe 05 39 5c 24 00    	incb   0x245c39(%rip)        # 5e862b <__start___sancov_cntrs+0x720b>
  3a29f2:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a29f6:	e8 b5 51 e9 ff       	call   237bb0 <__asan_report_load8>
  3a29fb:	0f 0b                	ud2
  3a29fd:	fe 05 29 5c 24 00    	incb   0x245c29(%rip)        # 5e862c <__start___sancov_cntrs+0x720c>
  3a2a03:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2a07:	e8 a4 51 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2a0c:	0f 0b                	ud2
  3a2a0e:	fe 05 67 5a 24 00    	incb   0x245a67(%rip)        # 5e847b <__start___sancov_cntrs+0x705b>
  3a2a14:	4c 89 f7             	mov    %r14,%rdi
  3a2a17:	e8 94 51 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2a1c:	0f 0b                	ud2
  3a2a1e:	fe 05 5a 5a 24 00    	incb   0x245a5a(%rip)        # 5e847e <__start___sancov_cntrs+0x705e>
  3a2a24:	4c 89 ff             	mov    %r15,%rdi
  3a2a27:	e8 84 51 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2a2c:	0f 0b                	ud2
  3a2a2e:	fe 05 ef 5b 24 00    	incb   0x245bef(%rip)        # 5e8623 <__start___sancov_cntrs+0x7203>
  3a2a34:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a2a38:	e8 73 51 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2a3d:	0f 0b                	ud2
  3a2a3f:	fe 05 df 5b 24 00    	incb   0x245bdf(%rip)        # 5e8624 <__start___sancov_cntrs+0x7204>
  3a2a45:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2a49:	e8 62 51 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2a4e:	0f 0b                	ud2
  3a2a50:	fe 05 20 5b 24 00    	incb   0x245b20(%rip)        # 5e8576 <__start___sancov_cntrs+0x7156>
  3a2a56:	4b 8d 3c 2e          	lea    (%r14,%r13,1),%rdi
  3a2a5a:	48 ff cf             	dec    %rdi
  3a2a5d:	e8 0e 4f e9 ff       	call   237970 <__asan_report_load1>
  3a2a62:	0f 0b                	ud2
  3a2a64:	fe 05 b2 5b 24 00    	incb   0x245bb2(%rip)        # 5e861c <__start___sancov_cntrs+0x71fc>
  3a2a6a:	48 8b 43 50          	mov    0x50(%rbx),%rax
  3a2a6e:	48 03 43 40          	add    0x40(%rbx),%rax
  3a2a72:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
  3a2a76:	48 ff cf             	dec    %rdi
  3a2a79:	e8 f2 4e e9 ff       	call   237970 <__asan_report_load1>
  3a2a7e:	0f 0b                	ud2
  3a2a80:	fe 05 ea 5a 24 00    	incb   0x245aea(%rip)        # 5e8570 <__start___sancov_cntrs+0x7150>
  3a2a86:	4b 8d 3c 2c          	lea    (%r12,%r13,1),%rdi
  3a2a8a:	48 ff cf             	dec    %rdi
  3a2a8d:	e8 de 4e e9 ff       	call   237970 <__asan_report_load1>
  3a2a92:	0f 0b                	ud2
  3a2a94:	fe 05 7c 5b 24 00    	incb   0x245b7c(%rip)        # 5e8616 <__start___sancov_cntrs+0x71f6>
  3a2a9a:	48 8b 43 50          	mov    0x50(%rbx),%rax
  3a2a9e:	48 03 43 40          	add    0x40(%rbx),%rax
  3a2aa2:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
  3a2aa6:	48 ff cf             	dec    %rdi
  3a2aa9:	e8 c2 4e e9 ff       	call   237970 <__asan_report_load1>
  3a2aae:	0f 0b                	ud2
  3a2ab0:	fe 05 06 5c 24 00    	incb   0x245c06(%rip)        # 5e86bc <__start___sancov_cntrs+0x729c>
  3a2ab6:	4c 89 e7             	mov    %r12,%rdi
  3a2ab9:	e8 b2 54 e9 ff       	call   237f70 <__asan_report_store8>
  3a2abe:	0f 0b                	ud2
  3a2ac0:	fe 05 f7 5b 24 00    	incb   0x245bf7(%rip)        # 5e86bd <__start___sancov_cntrs+0x729d>
  3a2ac6:	4c 89 f7             	mov    %r14,%rdi
  3a2ac9:	e8 a2 54 e9 ff       	call   237f70 <__asan_report_store8>
  3a2ace:	0f 0b                	ud2
  3a2ad0:	fe 05 e8 5b 24 00    	incb   0x245be8(%rip)        # 5e86be <__start___sancov_cntrs+0x729e>
  3a2ad6:	4c 89 f7             	mov    %r14,%rdi
  3a2ad9:	e8 92 54 e9 ff       	call   237f70 <__asan_report_store8>
  3a2ade:	0f 0b                	ud2
  3a2ae0:	fe 05 d9 5b 24 00    	incb   0x245bd9(%rip)        # 5e86bf <__start___sancov_cntrs+0x729f>
  3a2ae6:	4c 89 f7             	mov    %r14,%rdi
  3a2ae9:	e8 82 54 e9 ff       	call   237f70 <__asan_report_store8>
  3a2aee:	0f 0b                	ud2
  3a2af0:	fe 05 18 5b 24 00    	incb   0x245b18(%rip)        # 5e860e <__start___sancov_cntrs+0x71ee>
  3a2af6:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a2afa:	e8 b1 50 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2aff:	0f 0b                	ud2
  3a2b01:	fe 05 08 5b 24 00    	incb   0x245b08(%rip)        # 5e860f <__start___sancov_cntrs+0x71ef>
  3a2b07:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2b0b:	e8 a0 50 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2b10:	0f 0b                	ud2
  3a2b12:	fe 05 ad 5b 24 00    	incb   0x245bad(%rip)        # 5e86c5 <__start___sancov_cntrs+0x72a5>
  3a2b18:	4c 89 e7             	mov    %r12,%rdi
  3a2b1b:	e8 90 50 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2b20:	0f 0b                	ud2
  3a2b22:	fe 05 9e 5b 24 00    	incb   0x245b9e(%rip)        # 5e86c6 <__start___sancov_cntrs+0x72a6>
  3a2b28:	4c 89 ef             	mov    %r13,%rdi
  3a2b2b:	e8 80 50 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2b30:	0f 0b                	ud2
  3a2b32:	fe 05 99 5b 24 00    	incb   0x245b99(%rip)        # 5e86d1 <__start___sancov_cntrs+0x72b1>
  3a2b38:	4c 89 e7             	mov    %r12,%rdi
  3a2b3b:	e8 70 50 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2b40:	0f 0b                	ud2
  3a2b42:	fe 05 8b 5b 24 00    	incb   0x245b8b(%rip)        # 5e86d3 <__start___sancov_cntrs+0x72b3>
  3a2b48:	4c 89 ef             	mov    %r13,%rdi
  3a2b4b:	e8 20 54 e9 ff       	call   237f70 <__asan_report_store8>
  3a2b50:	0f 0b                	ud2
  3a2b52:	fe 05 7c 5b 24 00    	incb   0x245b7c(%rip)        # 5e86d4 <__start___sancov_cntrs+0x72b4>
  3a2b58:	4c 89 ef             	mov    %r13,%rdi
  3a2b5b:	e8 10 54 e9 ff       	call   237f70 <__asan_report_store8>
  3a2b60:	0f 0b                	ud2
  3a2b62:	fe 05 6d 5b 24 00    	incb   0x245b6d(%rip)        # 5e86d5 <__start___sancov_cntrs+0x72b5>
  3a2b68:	4c 89 ef             	mov    %r13,%rdi
  3a2b6b:	e8 00 54 e9 ff       	call   237f70 <__asan_report_store8>
  3a2b70:	0f 0b                	ud2
  3a2b72:	fe 05 5e 5b 24 00    	incb   0x245b5e(%rip)        # 5e86d6 <__start___sancov_cntrs+0x72b6>
  3a2b78:	4c 89 ef             	mov    %r13,%rdi
  3a2b7b:	e8 f0 53 e9 ff       	call   237f70 <__asan_report_store8>
  3a2b80:	0f 0b                	ud2
  3a2b82:	fe 05 22 5b 24 00    	incb   0x245b22(%rip)        # 5e86aa <__start___sancov_cntrs+0x728a>
  3a2b88:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a2b8c:	e8 1f 50 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2b91:	0f 0b                	ud2
  3a2b93:	fe 05 12 5b 24 00    	incb   0x245b12(%rip)        # 5e86ab <__start___sancov_cntrs+0x728b>
  3a2b99:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2b9d:	e8 0e 50 e9 ff       	call   237bb0 <__asan_report_load8>
  3a2ba2:	0f 0b                	ud2
  3a2ba4:	fe 05 1f 5b 24 00    	incb   0x245b1f(%rip)        # 5e86c9 <__start___sancov_cntrs+0x72a9>
  3a2baa:	4c 89 e7             	mov    %r12,%rdi
  3a2bad:	e8 be 53 e9 ff       	call   237f70 <__asan_report_store8>
  3a2bb2:	0f 0b                	ud2
  3a2bb4:	fe 05 10 5b 24 00    	incb   0x245b10(%rip)        # 5e86ca <__start___sancov_cntrs+0x72aa>
  3a2bba:	4c 89 f7             	mov    %r14,%rdi
  3a2bbd:	e8 ae 53 e9 ff       	call   237f70 <__asan_report_store8>
  3a2bc2:	0f 0b                	ud2
  3a2bc4:	fe 05 01 5b 24 00    	incb   0x245b01(%rip)        # 5e86cb <__start___sancov_cntrs+0x72ab>
  3a2bca:	4c 89 f7             	mov    %r14,%rdi
  3a2bcd:	e8 9e 53 e9 ff       	call   237f70 <__asan_report_store8>
  3a2bd2:	0f 0b                	ud2
  3a2bd4:	fe 05 f2 5a 24 00    	incb   0x245af2(%rip)        # 5e86cc <__start___sancov_cntrs+0x72ac>
  3a2bda:	4c 89 f7             	mov    %r14,%rdi
  3a2bdd:	e8 8e 53 e9 ff       	call   237f70 <__asan_report_store8>
  3a2be2:	0f 0b                	ud2
  3a2be4:	fe 05 7a 5a 24 00    	incb   0x245a7a(%rip)        # 5e8664 <__start___sancov_cntrs+0x7244>
  3a2bea:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a2bee:	e8 bd 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2bf3:	0f 0b                	ud2
  3a2bf5:	fe 05 6a 5a 24 00    	incb   0x245a6a(%rip)        # 5e8665 <__start___sancov_cntrs+0x7245>
  3a2bfb:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2bff:	e8 ac 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2c04:	0f 0b                	ud2
  3a2c06:	fe 05 7d 5a 24 00    	incb   0x245a7d(%rip)        # 5e8689 <__start___sancov_cntrs+0x7269>
  3a2c0c:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a2c10:	e8 9b 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2c15:	0f 0b                	ud2
  3a2c17:	fe 05 6d 5a 24 00    	incb   0x245a6d(%rip)        # 5e868a <__start___sancov_cntrs+0x726a>
  3a2c1d:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2c21:	e8 8a 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2c26:	0f 0b                	ud2
  3a2c28:	fe 05 6f 5a 24 00    	incb   0x245a6f(%rip)        # 5e869d <__start___sancov_cntrs+0x727d>
  3a2c2e:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a2c32:	e8 79 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2c37:	0f 0b                	ud2
  3a2c39:	fe 05 5f 5a 24 00    	incb   0x245a5f(%rip)        # 5e869e <__start___sancov_cntrs+0x727e>
  3a2c3f:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2c43:	e8 68 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2c48:	0f 0b                	ud2
  3a2c4a:	fe 05 17 5a 24 00    	incb   0x245a17(%rip)        # 5e8667 <__start___sancov_cntrs+0x7247>
  3a2c50:	4c 89 f7             	mov    %r14,%rdi
  3a2c53:	e8 58 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2c58:	0f 0b                	ud2
  3a2c5a:	fe 05 30 5a 24 00    	incb   0x245a30(%rip)        # 5e8690 <__start___sancov_cntrs+0x7270>
  3a2c60:	4c 89 ff             	mov    %r15,%rdi
  3a2c63:	e8 48 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2c68:	0f 0b                	ud2
  3a2c6a:	fe 05 21 5a 24 00    	incb   0x245a21(%rip)        # 5e8691 <__start___sancov_cntrs+0x7271>
  3a2c70:	4c 89 ef             	mov    %r13,%rdi
  3a2c73:	e8 38 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2c78:	0f 0b                	ud2
  3a2c7a:	fe 05 12 5a 24 00    	incb   0x245a12(%rip)        # 5e8692 <__start___sancov_cntrs+0x7272>
  3a2c80:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a2c84:	e8 27 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2c89:	0f 0b                	ud2
  3a2c8b:	fe 05 02 5a 24 00    	incb   0x245a02(%rip)        # 5e8693 <__start___sancov_cntrs+0x7273>
  3a2c91:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2c95:	e8 16 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2c9a:	0f 0b                	ud2
  3a2c9c:	fe 05 c8 59 24 00    	incb   0x2459c8(%rip)        # 5e866a <__start___sancov_cntrs+0x724a>
  3a2ca2:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a2ca6:	e8 05 4f e9 ff       	call   237bb0 <__asan_report_load8>
  3a2cab:	0f 0b                	ud2
  3a2cad:	fe 05 b8 59 24 00    	incb   0x2459b8(%rip)        # 5e866b <__start___sancov_cntrs+0x724b>
  3a2cb3:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2cb7:	e8 f4 4e e9 ff       	call   237bb0 <__asan_report_load8>
  3a2cbc:	0f 0b                	ud2
  3a2cbe:	fe 05 a4 59 24 00    	incb   0x2459a4(%rip)        # 5e8668 <__start___sancov_cntrs+0x7248>
  3a2cc4:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2cc8:	e8 e3 4e e9 ff       	call   237bb0 <__asan_report_load8>
  3a2ccd:	0f 0b                	ud2
  3a2ccf:	fe 05 cf 59 24 00    	incb   0x2459cf(%rip)        # 5e86a4 <__start___sancov_cntrs+0x7284>
  3a2cd5:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a2cd9:	e8 d2 4e e9 ff       	call   237bb0 <__asan_report_load8>
  3a2cde:	0f 0b                	ud2
  3a2ce0:	fe 05 bf 59 24 00    	incb   0x2459bf(%rip)        # 5e86a5 <__start___sancov_cntrs+0x7285>
  3a2ce6:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
  3a2cea:	e8 c1 4e e9 ff       	call   237bb0 <__asan_report_load8>
  3a2cef:	0f 0b                	ud2
  3a2cf1:	fe 05 83 59 24 00    	incb   0x245983(%rip)        # 5e867a <__start___sancov_cntrs+0x725a>
  3a2cf7:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
  3a2cfb:	e8 b0 4e e9 ff       	call   237bb0 <__asan_report_load8>
  3a2d00:	0f 0b                	ud2
  3a2d02:	fe 05 5c 57 24 00    	incb   0x24575c(%rip)        # 5e8464 <__start___sancov_cntrs+0x7044>
  3a2d08:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
  3a2d0c:	e8 5f 4c e9 ff       	call   237970 <__asan_report_load1>
  3a2d11:	0f 0b                	ud2
  3a2d13:	fe 05 4f 57 24 00    	incb   0x24574f(%rip)        # 5e8468 <__start___sancov_cntrs+0x7048>
  3a2d19:	4c 89 f7             	mov    %r14,%rdi
  3a2d1c:	e8 4f 4c e9 ff       	call   237970 <__asan_report_load1>
  3a2d21:	0f 0b                	ud2
  3a2d23:	fe 05 47 57 24 00    	incb   0x245747(%rip)        # 5e8470 <__start___sancov_cntrs+0x7050>
  3a2d29:	4c 89 f7             	mov    %r14,%rdi
  3a2d2c:	e8 3f 4c e9 ff       	call   237970 <__asan_report_load1>
  3a2d31:	0f 0b                	ud2
  3a2d33:	fe 05 3b 57 24 00    	incb   0x24573b(%rip)        # 5e8474 <__start___sancov_cntrs+0x7054>
  3a2d39:	4c 89 f7             	mov    %r14,%rdi
  3a2d3c:	e8 2f 4c e9 ff       	call   237970 <__asan_report_load1>
  3a2d41:	0f 0b                	ud2
  3a2d43:	fe 05 2f 57 24 00    	incb   0x24572f(%rip)        # 5e8478 <__start___sancov_cntrs+0x7058>
  3a2d49:	4c 89 f7             	mov    %r14,%rdi
  3a2d4c:	e8 1f 4c e9 ff       	call   237970 <__asan_report_load1>
  3a2d51:	0f 0b                	ud2
  3a2d53:	fe 05 13 57 24 00    	incb   0x245713(%rip)        # 5e846c <__start___sancov_cntrs+0x704c>
  3a2d59:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
  3a2d5d:	e8 0e 4c e9 ff       	call   237970 <__asan_report_load1>
  3a2d62:	0f 0b                	ud2
  3a2d64:	fe 05 1e 57 24 00    	incb   0x24571e(%rip)        # 5e8488 <__start___sancov_cntrs+0x7068>
  3a2d6a:	4c 89 f7             	mov    %r14,%rdi
  3a2d6d:	e8 fe 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2d72:	0f 0b                	ud2
  3a2d74:	fe 05 17 57 24 00    	incb   0x245717(%rip)        # 5e8491 <__start___sancov_cntrs+0x7071>
  3a2d7a:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
  3a2d7e:	e8 ed 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2d83:	0f 0b                	ud2
  3a2d85:	fe 05 22 57 24 00    	incb   0x245722(%rip)        # 5e84ad <__start___sancov_cntrs+0x708d>
  3a2d8b:	4c 89 f7             	mov    %r14,%rdi
  3a2d8e:	e8 dd 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2d93:	0f 0b                	ud2
  3a2d95:	fe 05 52 57 24 00    	incb   0x245752(%rip)        # 5e84ed <__start___sancov_cntrs+0x70cd>
  3a2d9b:	4c 89 ff             	mov    %r15,%rdi
  3a2d9e:	e8 cd 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2da3:	0f 0b                	ud2
  3a2da5:	fe 05 46 57 24 00    	incb   0x245746(%rip)        # 5e84f1 <__start___sancov_cntrs+0x70d1>
  3a2dab:	4c 89 ff             	mov    %r15,%rdi
  3a2dae:	e8 bd 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2db3:	0f 0b                	ud2
  3a2db5:	fe 05 ff 56 24 00    	incb   0x2456ff(%rip)        # 5e84ba <__start___sancov_cntrs+0x709a>
  3a2dbb:	4c 89 ff             	mov    %r15,%rdi
  3a2dbe:	e8 ad 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2dc3:	0f 0b                	ud2
  3a2dc5:	fe 05 fa 56 24 00    	incb   0x2456fa(%rip)        # 5e84c5 <__start___sancov_cntrs+0x70a5>
  3a2dcb:	4c 89 ff             	mov    %r15,%rdi
  3a2dce:	e8 9d 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2dd3:	0f 0b                	ud2
  3a2dd5:	fe 05 cb 56 24 00    	incb   0x2456cb(%rip)        # 5e84a6 <__start___sancov_cntrs+0x7086>
  3a2ddb:	4c 89 f7             	mov    %r14,%rdi
  3a2dde:	e8 8d 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2de3:	0f 0b                	ud2
  3a2de5:	fe 05 0b 57 24 00    	incb   0x24570b(%rip)        # 5e84f6 <__start___sancov_cntrs+0x70d6>
  3a2deb:	4c 89 ff             	mov    %r15,%rdi
  3a2dee:	e8 7d 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2df3:	0f 0b                	ud2
  3a2df5:	fe 05 13 57 24 00    	incb   0x245713(%rip)        # 5e850e <__start___sancov_cntrs+0x70ee>
  3a2dfb:	4c 89 f7             	mov    %r14,%rdi
  3a2dfe:	e8 6d 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2e03:	0f 0b                	ud2
  3a2e05:	fe 05 84 57 24 00    	incb   0x245784(%rip)        # 5e858f <__start___sancov_cntrs+0x716f>
  3a2e0b:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  3a2e0f:	e8 1c 4f e9 ff       	call   237d30 <__asan_report_store1>
  3a2e14:	0f 0b                	ud2
  3a2e16:	fe 05 76 57 24 00    	incb   0x245776(%rip)        # 5e8592 <__start___sancov_cntrs+0x7172>
  3a2e1c:	4c 89 e7             	mov    %r12,%rdi
  3a2e1f:	e8 0c 4f e9 ff       	call   237d30 <__asan_report_store1>
  3a2e24:	0f 0b                	ud2
  3a2e26:	fe 05 57 57 24 00    	incb   0x245757(%rip)        # 5e8583 <__start___sancov_cntrs+0x7163>
  3a2e2c:	4c 89 ef             	mov    %r13,%rdi
  3a2e2f:	e8 3c 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2e34:	0f 0b                	ud2
  3a2e36:	fe 05 5b 57 24 00    	incb   0x24575b(%rip)        # 5e8597 <__start___sancov_cntrs+0x7177>
  3a2e3c:	4c 89 f7             	mov    %r14,%rdi
  3a2e3f:	e8 2c 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2e44:	0f 0b                	ud2
  3a2e46:	fe 05 b7 56 24 00    	incb   0x2456b7(%rip)        # 5e8503 <__start___sancov_cntrs+0x70e3>
  3a2e4c:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  3a2e50:	e8 1b 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2e55:	0f 0b                	ud2
  3a2e57:	fe 05 d9 57 24 00    	incb   0x2457d9(%rip)        # 5e8636 <__start___sancov_cntrs+0x7216>
  3a2e5d:	4c 89 f7             	mov    %r14,%rdi
  3a2e60:	e8 0b 4b e9 ff       	call   237970 <__asan_report_load1>
  3a2e65:	0f 0b                	ud2
  3a2e67:	fe 05 df 56 24 00    	incb   0x2456df(%rip)        # 5e854c <__start___sancov_cntrs+0x712c>
  3a2e6d:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  3a2e74:	e8 f7 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2e79:	0f 0b                	ud2
  3a2e7b:	fe 05 bd 57 24 00    	incb   0x2457bd(%rip)        # 5e863e <__start___sancov_cntrs+0x721e>
  3a2e81:	48 8b 7b 18          	mov    0x18(%rbx),%rdi
  3a2e85:	e8 e6 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2e8a:	0f 0b                	ud2
  3a2e8c:	fe 05 1d 58 24 00    	incb   0x24581d(%rip)        # 5e86af <__start___sancov_cntrs+0x728f>
  3a2e92:	4c 89 ff             	mov    %r15,%rdi
  3a2e95:	e8 d6 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2e9a:	0f 0b                	ud2
  3a2e9c:	fe 05 2d 57 24 00    	incb   0x24572d(%rip)        # 5e85cf <__start___sancov_cntrs+0x71af>
  3a2ea2:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
  3a2ea9:	e8 c2 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2eae:	0f 0b                	ud2
  3a2eb0:	fe 05 1c 57 24 00    	incb   0x24571c(%rip)        # 5e85d2 <__start___sancov_cntrs+0x71b2>
  3a2eb6:	4c 89 f7             	mov    %r14,%rdi
  3a2eb9:	e8 b2 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2ebe:	0f 0b                	ud2
  3a2ec0:	fe 05 0f 57 24 00    	incb   0x24570f(%rip)        # 5e85d5 <__start___sancov_cntrs+0x71b5>
  3a2ec6:	4c 89 f7             	mov    %r14,%rdi
  3a2ec9:	e8 a2 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2ece:	0f 0b                	ud2
  3a2ed0:	fe 05 ed 56 24 00    	incb   0x2456ed(%rip)        # 5e85c3 <__start___sancov_cntrs+0x71a3>
  3a2ed6:	4c 89 ef             	mov    %r13,%rdi
  3a2ed9:	e8 92 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2ede:	0f 0b                	ud2
  3a2ee0:	fe 05 e0 56 24 00    	incb   0x2456e0(%rip)        # 5e85c6 <__start___sancov_cntrs+0x71a6>
  3a2ee6:	4c 89 e7             	mov    %r12,%rdi
  3a2ee9:	e8 82 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2eee:	0f 0b                	ud2
  3a2ef0:	fe 05 a8 55 24 00    	incb   0x2455a8(%rip)        # 5e849e <__start___sancov_cntrs+0x707e>
  3a2ef6:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  3a2efa:	e8 71 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2eff:	0f 0b                	ud2
  3a2f01:	fe 05 b2 57 24 00    	incb   0x2457b2(%rip)        # 5e86b9 <__start___sancov_cntrs+0x7299>
  3a2f07:	4c 89 ff             	mov    %r15,%rdi
  3a2f0a:	e8 21 4e e9 ff       	call   237d30 <__asan_report_store1>
  3a2f0f:	0f 0b                	ud2
  3a2f11:	fe 05 4b 56 24 00    	incb   0x24564b(%rip)        # 5e8562 <__start___sancov_cntrs+0x7142>
  3a2f17:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  3a2f1b:	e8 50 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2f20:	0f 0b                	ud2
  3a2f22:	fe 05 44 56 24 00    	incb   0x245644(%rip)        # 5e856c <__start___sancov_cntrs+0x714c>
  3a2f28:	4c 89 f7             	mov    %r14,%rdi
  3a2f2b:	e8 40 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2f30:	0f 0b                	ud2
  3a2f32:	fe 05 9d 55 24 00    	incb   0x24559d(%rip)        # 5e84d5 <__start___sancov_cntrs+0x70b5>
  3a2f38:	48 8b 7b 70          	mov    0x70(%rbx),%rdi
  3a2f3c:	e8 2f 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2f41:	0f 0b                	ud2
  3a2f43:	fe 05 9c 55 24 00    	incb   0x24559c(%rip)        # 5e84e5 <__start___sancov_cntrs+0x70c5>
  3a2f49:	4c 89 ef             	mov    %r13,%rdi
  3a2f4c:	e8 1f 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2f51:	0f 0b                	ud2
  3a2f53:	fe 05 95 56 24 00    	incb   0x245695(%rip)        # 5e85ee <__start___sancov_cntrs+0x71ce>
  3a2f59:	4c 89 f7             	mov    %r14,%rdi
  3a2f5c:	e8 0f 4a e9 ff       	call   237970 <__asan_report_load1>
  3a2f61:	0f 0b                	ud2
  3a2f63:	fe 05 19 55 24 00    	incb   0x245519(%rip)        # 5e8482 <__start___sancov_cntrs+0x7062>
  3a2f69:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  3a2f6d:	e8 be 4d e9 ff       	call   237d30 <__asan_report_store1>
  3a2f72:	0f 0b                	ud2
  3a2f74:	fe 05 0b 55 24 00    	incb   0x24550b(%rip)        # 5e8485 <__start___sancov_cntrs+0x7065>
  3a2f7a:	4c 89 e7             	mov    %r12,%rdi
  3a2f7d:	e8 ae 4d e9 ff       	call   237d30 <__asan_report_store1>
  3a2f82:	0f 0b                	ud2
  3a2f84:	fe 05 75 56 24 00    	incb   0x245675(%rip)        # 5e85ff <__start___sancov_cntrs+0x71df>
  3a2f8a:	4c 89 f7             	mov    %r14,%rdi
  3a2f8d:	e8 de 49 e9 ff       	call   237970 <__asan_report_load1>
  3a2f92:	0f 0b                	ud2
  3a2f94:	fe 05 73 56 24 00    	incb   0x245673(%rip)        # 5e860d <__start___sancov_cntrs+0x71ed>
  3a2f9a:	4c 89 ff             	mov    %r15,%rdi
  3a2f9d:	e8 ce 49 e9 ff       	call   237970 <__asan_report_load1>
  3a2fa2:	0f 0b                	ud2
  3a2fa4:	fe 05 19 57 24 00    	incb   0x245719(%rip)        # 5e86c3 <__start___sancov_cntrs+0x72a3>
  3a2faa:	4c 89 e7             	mov    %r12,%rdi
  3a2fad:	e8 be 49 e9 ff       	call   237970 <__asan_report_load1>
  3a2fb2:	0f 0b                	ud2
  3a2fb4:	fe 05 1f 57 24 00    	incb   0x24571f(%rip)        # 5e86d9 <__start___sancov_cntrs+0x72b9>
  3a2fba:	4c 89 e7             	mov    %r12,%rdi
  3a2fbd:	e8 6e 4d e9 ff       	call   237d30 <__asan_report_store1>
  3a2fc2:	0f 0b                	ud2
  3a2fc4:	fe 05 14 57 24 00    	incb   0x245714(%rip)        # 5e86de <__start___sancov_cntrs+0x72be>
  3a2fca:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  3a2fce:	e8 5d 4d e9 ff       	call   237d30 <__asan_report_store1>
  3a2fd3:	0f 0b                	ud2
  3a2fd5:	fe 05 06 57 24 00    	incb   0x245706(%rip)        # 5e86e1 <__start___sancov_cntrs+0x72c1>
  3a2fdb:	4c 89 e7             	mov    %r12,%rdi
  3a2fde:	e8 4d 4d e9 ff       	call   237d30 <__asan_report_store1>
  3a2fe3:	0f 0b                	ud2
  3a2fe5:	fe 05 6f 56 24 00    	incb   0x24566f(%rip)        # 5e865a <__start___sancov_cntrs+0x723a>
  3a2feb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
  3a2fef:	e8 7c 49 e9 ff       	call   237970 <__asan_report_load1>
  3a2ff4:	0f 0b                	ud2
  3a2ff6:	fe 05 66 56 24 00    	incb   0x245666(%rip)        # 5e8662 <__start___sancov_cntrs+0x7242>
  3a2ffc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
  3a3000:	e8 6b 49 e9 ff       	call   237970 <__asan_report_load1>
  3a3005:	0f 0b                	ud2
  3a3007:	fe 05 e8 55 24 00    	incb   0x2455e8(%rip)        # 5e85f5 <__start___sancov_cntrs+0x71d5>
  3a300d:	4c 89 f7             	mov    %r14,%rdi
  3a3010:	e8 5b 49 e9 ff       	call   237970 <__asan_report_load1>
  3a3015:	0f 0b                	ud2
  3a3017:	fe 05 6a 56 24 00    	incb   0x24566a(%rip)        # 5e8687 <__start___sancov_cntrs+0x7267>
  3a301d:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
  3a3021:	e8 4a 49 e9 ff       	call   237970 <__asan_report_load1>
  3a3026:	0f 0b                	ud2
  3a3028:	fe 05 6d 56 24 00    	incb   0x24566d(%rip)        # 5e869b <__start___sancov_cntrs+0x727b>
  3a302e:	4c 89 ff             	mov    %r15,%rdi
  3a3031:	e8 3a 49 e9 ff       	call   237970 <__asan_report_load1>
  3a3036:	0f 0b                	ud2
  3a3038:	fe 05 20 56 24 00    	incb   0x245620(%rip)        # 5e865e <__start___sancov_cntrs+0x723e>
  3a303e:	4c 89 f7             	mov    %r14,%rdi
  3a3041:	e8 2a 49 e9 ff       	call   237970 <__asan_report_load1>
  3a3046:	0f 0b                	ud2
  3a3048:	fe 05 35 56 24 00    	incb   0x245635(%rip)        # 5e8683 <__start___sancov_cntrs+0x7263>
  3a304e:	4c 89 f7             	mov    %r14,%rdi
  3a3051:	e8 1a 49 e9 ff       	call   237970 <__asan_report_load1>
  3a3056:	0f 0b                	ud2
  3a3058:	fe 05 39 56 24 00    	incb   0x245639(%rip)        # 5e8697 <__start___sancov_cntrs+0x7277>
  3a305e:	4c 89 f7             	mov    %r14,%rdi
  3a3061:	e8 0a 49 e9 ff       	call   237970 <__asan_report_load1>
  3a3066:	0f 0b                	ud2
  3a3068:	fe 05 3b 56 24 00    	incb   0x24563b(%rip)        # 5e86a9 <__start___sancov_cntrs+0x7289>
  3a306e:	48 8b 7b 18          	mov    0x18(%rbx),%rdi
  3a3072:	e8 f9 48 e9 ff       	call   237970 <__asan_report_load1>
  3a3077:	0f 0b                	ud2
  3a3079:	fe 05 32 55 24 00    	incb   0x245532(%rip)        # 5e85b1 <__start___sancov_cntrs+0x7191>
  3a307f:	48 8b bb e0 00 00 00 	mov    0xe0(%rbx),%rdi
  3a3086:	e8 a5 4c e9 ff       	call   237d30 <__asan_report_store1>
  3a308b:	0f 0b                	ud2
  3a308d:	fe 05 fb 55 24 00    	incb   0x2455fb(%rip)        # 5e868e <__start___sancov_cntrs+0x726e>
  3a3093:	4c 89 f7             	mov    %r14,%rdi
  3a3096:	e8 d5 48 e9 ff       	call   237970 <__asan_report_load1>
  3a309b:	0f 0b                	ud2
  3a309d:	fe 05 ff 55 24 00    	incb   0x2455ff(%rip)        # 5e86a2 <__start___sancov_cntrs+0x7282>
  3a30a3:	4c 89 f7             	mov    %r14,%rdi
  3a30a6:	e8 c5 48 e9 ff       	call   237970 <__asan_report_load1>
  3a30ab:	0f 0b                	ud2
  3a30ad:	fe 05 bc 55 24 00    	incb   0x2455bc(%rip)        # 5e866f <__start___sancov_cntrs+0x724f>
  3a30b3:	4c 89 e7             	mov    %r12,%rdi
  3a30b6:	e8 b5 48 e9 ff       	call   237970 <__asan_report_load1>
  3a30bb:	0f 0b                	ud2
  3a30bd:	fe 05 b0 55 24 00    	incb   0x2455b0(%rip)        # 5e8673 <__start___sancov_cntrs+0x7253>
  3a30c3:	4c 89 e7             	mov    %r12,%rdi
  3a30c6:	e8 a5 48 e9 ff       	call   237970 <__asan_report_load1>
  3a30cb:	0f 0b                	ud2
  3a30cd:	fe 05 a4 55 24 00    	incb   0x2455a4(%rip)        # 5e8677 <__start___sancov_cntrs+0x7257>
  3a30d3:	4c 89 e7             	mov    %r12,%rdi
  3a30d6:	e8 95 48 e9 ff       	call   237970 <__asan_report_load1>
  3a30db:	0f 0b                	ud2
  3a30dd:	fe 05 9a 55 24 00    	incb   0x24559a(%rip)        # 5e867d <__start___sancov_cntrs+0x725d>
  3a30e3:	48 8b 7b 58          	mov    0x58(%rbx),%rdi
  3a30e7:	e8 44 4c e9 ff       	call   237d30 <__asan_report_store1>
  3a30ec:	0f 0b                	ud2
  3a30ee:	fe 05 8c 55 24 00    	incb   0x24558c(%rip)        # 5e8680 <__start___sancov_cntrs+0x7260>
  3a30f4:	4c 89 e7             	mov    %r12,%rdi
  3a30f7:	e8 34 4c e9 ff       	call   237d30 <__asan_report_store1>
  3a30fc:	0f 0b                	ud2
  3a30fe:	49 89 c6             	mov    %rax,%r14
  3a3101:	fe 05 c1 54 24 00    	incb   0x2454c1(%rip)        # 5e85c8 <__start___sancov_cntrs+0x71a8>
  3a3107:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a310b:	eb 7e                	jmp    3a318b <<oriole::Parser>::parse_text+0x6b5b>
  3a310d:	49 89 c6             	mov    %rax,%r14
  3a3110:	fe 05 cc 54 24 00    	incb   0x2454cc(%rip)        # 5e85e2 <__start___sancov_cntrs+0x71c2>
  3a3116:	48 8b bb e8 00 00 00 	mov    0xe8(%rbx),%rdi
  3a311d:	e8 8e 70 f3 ff       	call   2da1b0 <core::ptr::drop_glue::<memchr::memmem::Finder>>
  3a3122:	eb 47                	jmp    3a316b <<oriole::Parser>::parse_text+0x6b3b>
  3a3124:	49 89 c6             	mov    %rax,%r14
  3a3127:	4d 8b 3c 24          	mov    (%r12),%r15
  3a312b:	48 c7 c7 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdi
  3a3132:	4c 89 fe             	mov    %r15,%rsi
  3a3135:	e8 36 74 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a313a:	49 83 ff fe          	cmp    $0xfffffffffffffffe,%r15
  3a313e:	75 08                	jne    3a3148 <<oriole::Parser>::parse_text+0x6b18>
  3a3140:	fe 05 6f 55 24 00    	incb   0x24556f(%rip)        # 5e86b5 <__start___sancov_cntrs+0x7295>
  3a3146:	eb 23                	jmp    3a316b <<oriole::Parser>::parse_text+0x6b3b>
  3a3148:	80 bb b0 00 00 00 00 	cmpb   $0x0,0xb0(%rbx)
  3a314f:	74 14                	je     3a3165 <<oriole::Parser>::parse_text+0x6b35>
  3a3151:	48 8b bb c0 00 00 00 	mov    0xc0(%rbx),%rdi
  3a3158:	e8 c3 49 f3 ff       	call   2d7b20 <core::ptr::drop_glue::<oriole_storage::string::Text>>
  3a315d:	fe 05 88 55 24 00    	incb   0x245588(%rip)        # 5e86eb <__start___sancov_cntrs+0x72cb>
  3a3163:	eb 06                	jmp    3a316b <<oriole::Parser>::parse_text+0x6b3b>
  3a3165:	fe 05 7f 55 24 00    	incb   0x24557f(%rip)        # 5e86ea <__start___sancov_cntrs+0x72ca>
  3a316b:	4c 8b 6b 30          	mov    0x30(%rbx),%r13
  3a316f:	eb 26                	jmp    3a3197 <<oriole::Parser>::parse_text+0x6b67>
  3a3171:	fe 05 75 55 24 00    	incb   0x245575(%rip)        # 5e86ec <__start___sancov_cntrs+0x72cc>
  3a3177:	e8 d4 5f e9 ff       	call   239150 <__asan_handle_no_return>
  3a317c:	ff 15 16 99 21 00    	call   *0x219916(%rip)        # 5bca98 <_GLOBAL_OFFSET_TABLE_+0xcf0>
  3a3182:	49 89 c6             	mov    %rax,%r14
  3a3185:	fe 05 3e 54 24 00    	incb   0x24543e(%rip)        # 5e85c9 <__start___sancov_cntrs+0x71a9>
  3a318b:	48 8d bb f0 01 00 00 	lea    0x1f0(%rbx),%rdi
  3a3192:	e8 a9 6e f3 ff       	call   2da040 <core::ptr::drop_glue::<memchr::cow::CowBytes>>
  3a3197:	49 c7 45 00 0e 36 e0 	movq   $0x45e0360e,0x0(%r13)
  3a319e:	45 
  3a319f:	31 ff                	xor    %edi,%edi
  3a31a1:	4c 8b 7b 68          	mov    0x68(%rbx),%r15
  3a31a5:	4c 89 fe             	mov    %r15,%rsi
  3a31a8:	e8 c3 73 11 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  3a31ad:	4d 85 ff             	test   %r15,%r15
  3a31b0:	74 1b                	je     3a31cd <<oriole::Parser>::parse_text+0x6b9d>
  3a31b2:	fe 05 12 54 24 00    	incb   0x245412(%rip)        # 5e85ca <__start___sancov_cntrs+0x71aa>
  3a31b8:	be 60 04 00 00       	mov    $0x460,%esi
  3a31bd:	4c 89 ff             	mov    %r15,%rdi
  3a31c0:	e8 eb 26 e0 ff       	call   1a58b0 <__asan_stack_free_5>
  3a31c5:	4c 89 f7             	mov    %r14,%rdi
  3a31c8:	e8 03 e6 dc ff       	call   1717d0 <_Unwind_Resume@plt>
  3a31cd:	fe 05 f8 53 24 00    	incb   0x2453f8(%rip)        # 5e85cb <__start___sancov_cntrs+0x71ab>
  3a31d3:	be 8c 00 00 00       	mov    $0x8c,%esi
  3a31d8:	48 8b bb 88 00 00 00 	mov    0x88(%rbx),%rdi
  3a31df:	e8 9c ee e8 ff       	call   232080 <__asan_set_shadow_00>
  3a31e4:	4c 89 f7             	mov    %r14,%rdi
  3a31e7:	e8 e4 e5 dc ff       	call   1717d0 <_Unwind_Resume@plt>
  3a31ec:	0f 1f 40 00          	nopl   0x0(%rax)
