
/tmp/oriole-frame-fuzz-study/binaries/ffi:     file format elf64-x86-64


Disassembly of section .text:

0000000000309c40 <<oriole::arena::AdapterFrame>::text_bytes>:
  309c40:	55                   	push   %rbp
  309c41:	48 89 e5             	mov    %rsp,%rbp
  309c44:	41 57                	push   %r15
  309c46:	41 56                	push   %r14
  309c48:	41 54                	push   %r12
  309c4a:	53                   	push   %rbx
  309c4b:	fe 05 55 b8 2d 00    	incb   0x2db855(%rip)        # 5e54a6 <__start___sancov_cntrs+0x4086>
  309c51:	48 89 fb             	mov    %rdi,%rbx
  309c54:	48 8b 05 7d 2d 2b 00 	mov    0x2b2d7d(%rip),%rax        # 5bc9d8 <__sancov_lowest_stack@@Base+0x5bc928>
  309c5b:	64 48 3b 28          	cmp    %fs:(%rax),%rbp
  309c5f:	0f 82 19 01 00 00    	jb     309d7e <<oriole::arena::AdapterFrame>::text_bytes+0x13e>
  309c65:	4c 8d b3 b0 00 00 00 	lea    0xb0(%rbx),%r14
  309c6c:	4c 89 f0             	mov    %r14,%rax
  309c6f:	48 c1 e8 03          	shr    $0x3,%rax
  309c73:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  309c7a:	7f 
  309c7b:	31 ff                	xor    %edi,%edi
  309c7d:	44 89 fe             	mov    %r15d,%esi
  309c80:	e8 5b 0c 1b 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  309c85:	45 85 ff             	test   %r15d,%r15d
  309c88:	0f 85 f9 00 00 00    	jne    309d87 <<oriole::arena::AdapterFrame>::text_bytes+0x147>
  309c8e:	fe 05 13 b8 2d 00    	incb   0x2db813(%rip)        # 5e54a7 <__start___sancov_cntrs+0x4087>
  309c94:	41 80 3e 00          	cmpb   $0x0,(%r14)
  309c98:	0f 84 14 01 00 00    	je     309db2 <<oriole::arena::AdapterFrame>::text_bytes+0x172>
  309c9e:	4c 8d b3 b1 00 00 00 	lea    0xb1(%rbx),%r14
  309ca5:	4c 89 f0             	mov    %r14,%rax
  309ca8:	48 c1 e8 03          	shr    $0x3,%rax
  309cac:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  309cb3:	7f 
  309cb4:	31 ff                	xor    %edi,%edi
  309cb6:	44 89 fe             	mov    %r15d,%esi
  309cb9:	e8 22 0c 1b 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  309cbe:	45 85 ff             	test   %r15d,%r15d
  309cc1:	0f 85 ff 00 00 00    	jne    309dc6 <<oriole::arena::AdapterFrame>::text_bytes+0x186>
  309cc7:	fe 05 de b7 2d 00    	incb   0x2db7de(%rip)        # 5e54ab <__start___sancov_cntrs+0x408b>
  309ccd:	45 0f b6 36          	movzbl (%r14),%r14d
  309cd1:	48 8d 35 28 77 2b 00 	lea    0x2b7728(%rip),%rsi        # 5c1400 <__sancov_gen_cov_switch_values.2608>
  309cd8:	4c 89 f7             	mov    %r14,%rdi
  309cdb:	e8 90 0c 1b 00       	call   4ba970 <__sanitizer_cov_trace_switch>
  309ce0:	41 83 fe 02          	cmp    $0x2,%r14d
  309ce4:	74 57                	je     309d3d <<oriole::arena::AdapterFrame>::text_bytes+0xfd>
  309ce6:	41 83 fe 01          	cmp    $0x1,%r14d
  309cea:	75 65                	jne    309d51 <<oriole::arena::AdapterFrame>::text_bytes+0x111>
  309cec:	4c 8d b3 a8 00 00 00 	lea    0xa8(%rbx),%r14
  309cf3:	4c 89 f0             	mov    %r14,%rax
  309cf6:	48 c1 e8 03          	shr    $0x3,%rax
  309cfa:	44 0f b6 b8 00 80 ff 	movzbl 0x7fff8000(%rax),%r15d
  309d01:	7f 
  309d02:	31 ff                	xor    %edi,%edi
  309d04:	44 89 fe             	mov    %r15d,%esi
  309d07:	e8 d4 0b 1b 00       	call   4ba8e0 <__sanitizer_cov_trace_const_cmp1>
  309d0c:	45 85 ff             	test   %r15d,%r15d
  309d0f:	0f 85 d7 00 00 00    	jne    309dec <<oriole::arena::AdapterFrame>::text_bytes+0x1ac>
  309d15:	4d 8b 36             	mov    (%r14),%r14
  309d18:	bf 18 00 00 00       	mov    $0x18,%edi
  309d1d:	4c 89 f6             	mov    %r14,%rsi
  309d20:	e8 4b 08 1b 00       	call   4ba570 <__sanitizer_cov_trace_const_cmp8>
  309d25:	4c 89 f2             	mov    %r14,%rdx
  309d28:	49 83 fe 17          	cmp    $0x17,%r14
  309d2c:	77 2b                	ja     309d59 <<oriole::arena::AdapterFrame>::text_bytes+0x119>
  309d2e:	48 81 c3 b2 00 00 00 	add    $0xb2,%rbx
  309d35:	fe 05 75 b7 2d 00    	incb   0x2db775(%rip)        # 5e54b0 <__start___sancov_cntrs+0x4090>
  309d3b:	eb 7d                	jmp    309dba <<oriole::arena::AdapterFrame>::text_bytes+0x17a>
  309d3d:	fe 05 6e b7 2d 00    	incb   0x2db76e(%rip)        # 5e54b1 <__start___sancov_cntrs+0x4091>
  309d43:	48 89 df             	mov    %rbx,%rdi
  309d46:	ff 15 9c 2c 2b 00    	call   *0x2b2c9c(%rip)        # 5bc9e8 <_GLOBAL_OFFSET_TABLE_+0xc40>
  309d4c:	48 89 c3             	mov    %rax,%rbx
  309d4f:	eb 69                	jmp    309dba <<oriole::arena::AdapterFrame>::text_bytes+0x17a>
  309d51:	fe 05 57 b7 2d 00    	incb   0x2db757(%rip)        # 5e54ae <__start___sancov_cntrs+0x408e>
  309d57:	eb 5f                	jmp    309db8 <<oriole::arena::AdapterFrame>::text_bytes+0x178>
  309d59:	fe 05 53 b7 2d 00    	incb   0x2db753(%rip)        # 5e54b2 <__start___sancov_cntrs+0x4092>
  309d5f:	48 89 d3             	mov    %rdx,%rbx
  309d62:	e8 e9 f3 f2 ff       	call   239150 <__asan_handle_no_return>
  309d67:	48 8d 0d 52 46 2a 00 	lea    0x2a4652(%rip),%rcx        # 5ae3c0 <alloc_1e9a4636d71938ce12e8d621539f6731>
  309d6e:	ba 17 00 00 00       	mov    $0x17,%edx
  309d73:	31 ff                	xor    %edi,%edi
  309d75:	48 89 de             	mov    %rbx,%rsi
  309d78:	ff 15 12 28 2b 00    	call   *0x2b2812(%rip)        # 5bc590 <_GLOBAL_OFFSET_TABLE_+0x7e8>
  309d7e:	64 48 89 28          	mov    %rbp,%fs:(%rax)
  309d82:	e9 de fe ff ff       	jmp    309c65 <<oriole::arena::AdapterFrame>::text_bytes+0x25>
  309d87:	45 89 f4             	mov    %r14d,%r12d
  309d8a:	41 83 e4 07          	and    $0x7,%r12d
  309d8e:	45 0f b6 ff          	movzbl %r15b,%r15d
  309d92:	44 89 e7             	mov    %r12d,%edi
  309d95:	44 89 fe             	mov    %r15d,%esi
  309d98:	e8 b3 0a 1b 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  309d9d:	45 38 fc             	cmp    %r15b,%r12b
  309da0:	7d 5a                	jge    309dfc <<oriole::arena::AdapterFrame>::text_bytes+0x1bc>
  309da2:	fe 05 00 b7 2d 00    	incb   0x2db700(%rip)        # 5e54a8 <__start___sancov_cntrs+0x4088>
  309da8:	41 80 3e 00          	cmpb   $0x0,(%r14)
  309dac:	0f 85 ec fe ff ff    	jne    309c9e <<oriole::arena::AdapterFrame>::text_bytes+0x5e>
  309db2:	fe 05 f2 b6 2d 00    	incb   0x2db6f2(%rip)        # 5e54aa <__start___sancov_cntrs+0x408a>
  309db8:	31 db                	xor    %ebx,%ebx
  309dba:	48 89 d8             	mov    %rbx,%rax
  309dbd:	5b                   	pop    %rbx
  309dbe:	41 5c                	pop    %r12
  309dc0:	41 5e                	pop    %r14
  309dc2:	41 5f                	pop    %r15
  309dc4:	5d                   	pop    %rbp
  309dc5:	c3                   	ret
  309dc6:	45 89 f4             	mov    %r14d,%r12d
  309dc9:	41 83 e4 07          	and    $0x7,%r12d
  309dcd:	45 0f b6 ff          	movzbl %r15b,%r15d
  309dd1:	44 89 e7             	mov    %r12d,%edi
  309dd4:	44 89 fe             	mov    %r15d,%esi
  309dd7:	e8 74 0a 1b 00       	call   4ba850 <__sanitizer_cov_trace_cmp1>
  309ddc:	45 38 fc             	cmp    %r15b,%r12b
  309ddf:	7d 2b                	jge    309e0c <<oriole::arena::AdapterFrame>::text_bytes+0x1cc>
  309de1:	fe 05 c5 b6 2d 00    	incb   0x2db6c5(%rip)        # 5e54ac <__start___sancov_cntrs+0x408c>
  309de7:	e9 e1 fe ff ff       	jmp    309ccd <<oriole::arena::AdapterFrame>::text_bytes+0x8d>
  309dec:	fe 05 bd b6 2d 00    	incb   0x2db6bd(%rip)        # 5e54af <__start___sancov_cntrs+0x408f>
  309df2:	4c 89 f7             	mov    %r14,%rdi
  309df5:	e8 b6 dd f2 ff       	call   237bb0 <__asan_report_load8>
  309dfa:	0f 0b                	ud2
  309dfc:	fe 05 a7 b6 2d 00    	incb   0x2db6a7(%rip)        # 5e54a9 <__start___sancov_cntrs+0x4089>
  309e02:	4c 89 f7             	mov    %r14,%rdi
  309e05:	e8 66 db f2 ff       	call   237970 <__asan_report_load1>
  309e0a:	0f 0b                	ud2
  309e0c:	fe 05 9b b6 2d 00    	incb   0x2db69b(%rip)        # 5e54ad <__start___sancov_cntrs+0x408d>
  309e12:	4c 89 f7             	mov    %r14,%rdi
  309e15:	e8 56 db f2 ff       	call   237970 <__asan_report_load1>
  309e1a:	0f 0b                	ud2
  309e1c:	0f 1f 40 00          	nopl   0x0(%rax)
