import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

out = Path('/tmp/oriole-frame-fuzz-study')
parent = Path('/home/dev-user/code/oss/oriole-frame-evidence/docs/validation/2026-09-10/version-consistent-fuzz/evidence.tar.gz')
targets = ['parse', 'streaming', 'ffi', 'ffi_family', 'multibyte', 'value_family']
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert json.loads((out / 'build.json').read_text())['status'] == 'passed'
assert not (out / 'campaigns').exists()
with tarfile.open(parent, 'r:gz') as archive:
    member = archive.getmember('initial-corpus.tar.gz')
    assert member.isfile()
    data = archive.extractfile(member).read()
(out / 'initial-corpus.tar.gz').write_bytes(data)
inputs = {target: {} for target in targets}
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    for member in archive.getmembers():
        path = Path(member.name)
        assert member.isfile() and len(path.parts) == 2 and path.parts[0] in targets
        target, name = path.parts
        assert len(name) == 64 and all(c in '0123456789abcdef' for c in name)
        content = archive.extractfile(member).read()
        assert hashlib.sha256(content).hexdigest() == name
        assert name not in inputs[target]
        directory = out / 'campaigns' / target / 'initial-corpus'
        directory.mkdir(parents=True, exist_ok=True)
        (directory / name).write_bytes(content)
        inputs[target][name] = len(content)
assert sum(map(len, inputs.values())) == 26689
for target, entries in inputs.items():
    assert entries
    (out / 'campaigns' / target / 'initial-manifest.json').write_text(json.dumps({'inputs': entries}, indent=2) + '\n')
report = {'parent_archive': str(parent), 'parent_sha256': digest(parent),
          'initial_archive_sha256': digest(out / 'initial-corpus.tar.gz'),
          'inputs': {target: len(entries) for target, entries in inputs.items()},
          'empty_files': sum(size == 0 for entries in inputs.values() for size in entries.values()),
          'scope': 'Every raw input in the previous retained initial corpus; no filtering, additions or length truncation.'}
(out / 'corpus-provenance.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copy2(__file__, out / Path(__file__).name)
print(json.dumps(report, indent=2))
