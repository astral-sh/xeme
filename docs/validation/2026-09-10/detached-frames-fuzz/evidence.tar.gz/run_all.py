"""Six fixed campaigns in three lanes, retaining every child result."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
lanes = [(1, ['parse', 'multibyte']), (2, ['streaming', 'value_family']), (4, ['ffi', 'ffi_family'])]
def lane(item):
    cpu, targets = item
    results = []
    for target in targets:
        command = [sys.executable, str(root / 'run_campaign.py'), target, str(cpu)]
        with (root / f'controller-{target}.log').open('wb') as log:
            code = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
        results.append({'target': target, 'cpu': cpu, 'exit_code': code})
        print(json.dumps(results[-1]), flush=True)
    return results
with ThreadPoolExecutor(max_workers=3) as executor:
    results = [result for rows in executor.map(lane, lanes) for result in rows]
(root / 'campaign-summary.json').write_text(json.dumps(results, indent=2) + '\n')
raise SystemExit(0 if all(row['exit_code'] == 0 for row in results) else 1)
