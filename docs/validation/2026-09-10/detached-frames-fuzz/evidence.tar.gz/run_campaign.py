"""Replay all retained inputs, then run one bounded ASan campaign on PR106."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('target', choices=['parse', 'streaming', 'ffi', 'ffi_family', 'multibyte', 'value_family'])
parser.add_argument('cpu', type=int)
args = parser.parse_args()
root = Path(__file__).resolve().parent
out = root / 'campaigns' / args.target
binary = root / 'binaries' / args.target
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

source = json.loads((root / 'source.json').read_text())
source_root = Path(source['worktree'])
source_hashes = source['source_sha256']
build = json.loads((root / 'build.json').read_text())
inputs = json.loads((out / 'initial-manifest.json').read_text())['inputs']
initial = out / 'initial-corpus'
assert {path.name: digest(path) for path in initial.iterdir()} == {key: key for key in inputs}
assert all(digest(source_root / path) == value for path, value in source_hashes.items())
assert digest(binary) == build['binaries'][args.target]
assert not (out / 'result.json').exists()
corpus, artifacts = out / 'corpus', out / 'artifacts'
corpus.mkdir()
artifacts.mkdir()
symbols = subprocess.check_output(['nm', '-D', str(binary)])
(out / 'dynamic-symbols.txt').write_bytes(symbols)
assert b'__asan_init' in symbols and b'__asan_report_load' in symbols
env = os.environ | {'ASAN_OPTIONS': 'detect_leaks=0:abort_on_error=1'}
common = ['taskset', '-c', str(args.cpu), str(binary), '-seed=20260911', '-max_len=65536',
          '-timeout=10', '-rss_limit_mb=1536', f'-artifact_prefix={artifacts}/']
result = {'status': 'incomplete', 'target': args.target, 'cpu': args.cpu,
          'binary_sha256': digest(binary), 'source_manifest_sha256': digest(root / 'source.json'),
          'build_json_sha256': digest(root / 'build.json'), 'runner_sha256': digest(Path(__file__)),
          'initial_manifest_sha256': digest(out / 'initial-manifest.json'), 'initial_inputs': len(inputs),
          'environment': {'ASAN_OPTIONS': env['ASAN_OPTIONS']},
          'scope': 'Rust workspace ASan with external Clang runtime; leak detection disabled in ptrace sandbox. Counts include libFuzzer initialization; bounded evidence, not a proof of safety.',
          'runs': []}
active = None
def save():
    (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
def interrupt(signum, frame):
    if active is not None and active.poll() is None:
        os.killpg(active.pid, signal.SIGKILL)
        active.wait()
    raise KeyboardInterrupt(f'signal {signum}')
for signum in (signal.SIGINT, signal.SIGTERM):
    signal.signal(signum, interrupt)
def run(label, command, timeout):
    global active
    entry = {'label': label, 'command': command, 'outer_timeout_seconds': timeout,
             'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    result['runs'].append(entry)
    save()
    start = time.monotonic()
    try:
        with (out / f'{label}.log').open('wb') as stream:
            active = subprocess.Popen(command, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                entry['exit_code'] = active.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                entry['harness_timeout'] = True
                os.killpg(active.pid, signal.SIGKILL)
                entry['exit_code'] = active.wait()
            finally:
                if active.poll() is None:
                    os.killpg(active.pid, signal.SIGKILL)
                    active.wait()
                active = None
    finally:
        entry['elapsed_seconds'] = time.monotonic() - start
        entry['log_sha256'] = digest(out / f'{label}.log')
        save()
    return entry['exit_code']

save()
try:
    if run('replay', common + ['-runs=0', str(initial)], 180) == 0:
        print(json.dumps({'started': args.target, 'initial_inputs': len(inputs)}), flush=True)
        run('campaign', common + ['-max_total_time=600', '-print_final_stats=1', str(corpus), str(initial)], 690)
finally:
    result['source_unchanged'] = all(digest(source_root / path) == value for path, value in source_hashes.items())
    result['source_manifest_unchanged'] = digest(root / 'source.json') == result['source_manifest_sha256']
    result['binary_unchanged'] = digest(binary) == result['binary_sha256']
    result['initial_inputs_unchanged'] = {path.name: digest(path) for path in initial.iterdir()} == {key: key for key in inputs}
    result['artifacts'] = [{'name': path.name, 'sha256': digest(path)} for path in artifacts.iterdir() if path.is_file()]
    result['final_corpus'] = {path.name: digest(path) for path in corpus.iterdir() if path.is_file()}
    if (out / 'campaign.log').exists():
        result['stats'] = {key: int(value) for key, value in re.findall(r'stat::(\w+):\s+(\d+)', (out / 'campaign.log').read_text(errors='replace'))}
    result['passed'] = len(result['runs']) == 2 and all(row.get('exit_code') == 0 for row in result['runs']) and not result['artifacts'] and all(result[key] for key in ['source_unchanged', 'source_manifest_unchanged', 'binary_unchanged', 'initial_inputs_unchanged'])
    result['status'] = 'passed' if result['passed'] else 'failed'
    save()
print(json.dumps({key: value for key, value in result.items() if key != 'final_corpus'}), flush=True)
raise SystemExit(0 if result['passed'] else 1)
