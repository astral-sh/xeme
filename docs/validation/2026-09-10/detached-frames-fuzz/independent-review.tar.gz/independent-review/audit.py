"""Audit frozen source/build/instrumentation and archive bytes, never run fuzzers."""
from pathlib import Path
import hashlib,io,json,re,shlex,subprocess,tarfile
S=Path('/tmp/oriole-frame-fuzz-study');B=Path('/tmp/oriole-frame-fuzz-handoff');O=Path(__file__).parent
H={}
def read(p):
 p=Path(p);d=p.read_bytes();H[str(p)]=hashlib.sha256(d).hexdigest();return d
def sha(p):read(p);return H[str(Path(p))]
def load(p):return json.loads(read(p))
source=load(S/'source.json');build=load(S/'build.json');summary=load(B/'summary.json');receipt=load(B/'readback.json')
assert source['commit']==summary['source_commit']=='5bc806e5fc2a545f22c75f2a1bcbef45cfa3632b'
assert build['status']=='passed' and build['exit']==0 and build['source_unchanged']
assert build['source_manifest_sha256']==sha(S/'source.json')
W=Path(source['worktree']);assert len(source['source_sha256'])==357
with tarfile.open(S/'source.tar.gz') as t:
 source_bytes={m.name:t.extractfile(m).read() for m in t if m.isfile()}
assert set(source_bytes)==set(source['source_sha256'])
gitdata=subprocess.check_output(['git','-C',str(W),'archive','--format=tar',source['commit'],'--','Cargo.toml','Cargo.lock','crates','include','tests/c','fuzz'])
with tarfile.open(fileobj=io.BytesIO(gitdata)) as t:
 gitfiles={m.name:t.extractfile(m).read() for m in t if m.isfile()}
assert source_bytes==gitfiles
for name,h in source['source_sha256'].items():assert hashlib.sha256(source_bytes[name]).hexdigest()==sha(W/name)==h
for name in ['source.json','build.json','summary.json','corpus-provenance.json']:assert read(B/name)==read(S/name)
assert sha('/home/dev-user/.cache/oriole/fuzz-tools/bin/cargo-fuzz')==build['cargo_fuzz_sha256']
assert build['env_overrides']['CARGO_BUILD_BUILD_DIR']=='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}'
assert build['env_overrides']['CARGO_INCREMENTAL']=='0' and build['env_overrides']['RUSTC_WRAPPER']==build['env_overrides']['RUSTC_WORKSPACE_WRAPPER']==''
assert build['env_overrides']['RUSTFLAGS']=='-Zexternal-clangrt -Clinker=clang -Clink-arg=-fsanitize=address'
assert build['removed_env']==['CARGO_ENCODED_RUSTFLAGS']
assert build['command']==['taskset','-c','2,3','cargo','+ohm','-Zohm-defaults=no','fuzz','build','-Z','ohm-defaults=no','--sanitizer','address','--verbose','--target-dir','/home/dev-user/.cache/oriole/frame-fuzz-target']
log=read(S/'build.log').decode();invocations=load(S/'compiler-invocations.json')
assert invocations==[l.strip() for l in log.splitlines() if 'Running' in l and '/rustc ' in l]
assert 'Finished `release` profile' in log
commands={}
for line in invocations:
 args=shlex.split(line[len('Running `'):-1]);name=args[args.index('--crate-name')+1]
 commands.setdefault(name,[]).append(args)
core=['oriole_storage','oriole','oriole_expat'];targets=['parse','streaming','ffi','ffi_family','multibyte','value_family']
for name in core+targets:
 assert len(commands[name])==1,(name,len(commands.get(name,[])))
 args=commands[name][0]
 assert args[0]=='/home/dev-user/.rustup/toolchains/ohm/bin/rustc'
 assert '-Zsanitizer=address' in args and '-Zexternal-clangrt' in args and '-Clinker=clang' in args and '-Clink-arg=-fsanitize=address' in args
 assert '--target' in args and args[args.index('--target')+1]=='x86_64-unknown-linux-gnu'
 assert '-Ccodegen-units=1' in args and '-Cdebug-assertions' in args and '--cfg' in args and 'fuzzing' in args
 assert '--emit=dep-info,link' in args or '--emit=dep-info,metadata,link' in args
 out=args[args.index('--out-dir')+1];assert out.startswith('/home/dev-user/.cache/ohm/verified-build/ac/4edfa815b1ae37/')
 if name in core:
  assert str(W/f'crates/{name}/src/lib.rs') in args
 else:
  assert 'fuzz_targets/'+name+'.rs' in args
  assert any(x.startswith('oriole=') for x in args)
# Compare all copied executables to stable target outputs and retained dynamic symbol receipts.
binaries={}
for name,h in build['binaries'].items():
 binary=S/'binaries'/name
 assert sha(binary)==h==sha(Path(build['env_overrides']['CARGO_TARGET_DIR'])/'x86_64-unknown-linux-gnu/release'/name)
 symbols=subprocess.check_output(['nm','-D',str(binary)])
 assert symbols==read(S/'campaigns'/name/'dynamic-symbols.txt')
 assert b'__asan_init' in symbols and b'__asan_report_load' in symbols and b'__asan_report_store' in symbols
 result=load(S/'campaigns'/name/'result.json');assert result['binary_sha256']==h
 binaries[name]={'sha256':h,'asan_dynamic_symbols_verified':True}
# Non-mutating disassembly proves Rust core and frame code instrumentation,
# beyond merely observing sanitizer symbols in libFuzzer startup code.
i=load(S/'instrumentation/report.json');assert i['binary_sha256']==build['binaries']['ffi']
disassembly=[]
for fn,stem in zip(i['functions'],['XML_Parse','parse_text','text_bytes'],strict=True):
 assert fn['command'][:3]==['objdump','-d','--demangle'] and fn['command'][-1]==str(S/'binaries/ffi')
 actual=subprocess.check_output(fn['command']);assert actual==read(S/'instrumentation'/(stem+'.asm')) and hashlib.sha256(actual).hexdigest()==fn['sha256']
 text=actual.decode();assert fn['name'] in text
 sites=[line.strip() for line in text.splitlines() if '__asan_report_' in line]
 assert sites==fn['asan_report_sites'] and sites
 disassembly.append({'name':fn['name'],'asan_call_sites':len(sites),'sha256':fn['sha256']})
assert sha(S/'binaries/ffi')==i['binary_sha256']
# Whole main archive and final corpus readback, with original source mapping.
m=load(B/'members.json');assert len(m['members'])==55 and len(m['excluded_binaries'])==6
with tarfile.open(B/'evidence.tar.gz') as t:
 members=t.getmembers();assert len(members)==55
 for member,entry in zip(members,m['members'],strict=True):
  assert member.isfile() and member.name==entry['path'] and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  data=t.extractfile(member).read();assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']==sha(entry['source'])
  assert not data.startswith((b'\x7fELF',b'!<arch>\n'))
for entry in m['excluded_binaries']:assert sha(entry['source'])==entry['sha256'] and read(entry['source']).startswith(b'\x7fELF')
assert sha(B/'evidence.tar.gz')==receipt['evidence_sha256']=='3bdd18ae72a22f770c653b9a32270da23f454d4f6fa9bd31eb5b6b2d244fedda'
f=load(B/'final-corpus-members.json');assert len(f)==receipt['final_corpus_files']==16272
with tarfile.open(B/'final-corpus.tar.gz') as t:
 entries=t.getmembers();assert len(entries)==len(f)
 for member,expected in zip(entries,f,strict=True):
  assert member.isfile() and member.name==expected['path'] and len(Path(member.name).parts)==2
  data=t.extractfile(member).read();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
  target,name=Path(member.name).parts;assert target in targets and hashlib.sha1(data).hexdigest()==name
  assert sha(S/'campaigns'/target/'corpus'/name)==expected['sha256']
assert sha(B/'final-corpus.tar.gz')==receipt['final_corpus_sha256']=='d8154f6185e1a39f054962184f503edfe9529e204ce46fbf6271fed236e7ef85'
# Verify retained initial archive is exactly the previous published nested corpus.
provenance=load(S/'corpus-provenance.json');assert sha(provenance['parent_archive'])==provenance['parent_sha256']
with tarfile.open(provenance['parent_archive']) as t: old=t.extractfile('initial-corpus.tar.gz').read()
assert old==read(S/'initial-corpus.tar.gz') and hashlib.sha256(old).hexdigest()==provenance['initial_archive_sha256']
with tarfile.open(fileobj=io.BytesIO(old)) as t:
 original=t.getmembers();assert len(original)==26689
 for member in original:
  assert member.isfile() and len(Path(member.name).parts)==2
  data=t.extractfile(member).read();target,name=Path(member.name).parts
  assert target in targets and hashlib.sha256(data).hexdigest()==name==sha(S/'campaigns'/target/'initial-corpus'/name)
# Rehash all handoff outer files. Child audit supplies independent runner/stat math.
for p in B.iterdir():
 if p.is_file():sha(p)
for p in [Path(__file__),Path('/tmp/oriole-build-frame-fuzz.py'),B/'oriole-package-frame-fuzz.py',S/'run_all.py',S/'run_campaign.py',S/'oriole-prepare-frame-fuzz.py']:sha(p)
report={'status':'source_build_package_passed','scope':'Independent source/Git/archive/compiler/binary and saved disassembly/package readback audit. Read-only nm/objdump and Git archive were used; no executable fuzz target, parser, tests, compilation or new campaign run by reviewer.',
'source':{'commit':source['commit'],'files':357,'git_archive_live_and_frozen_exact':True,'manifest_sha256':sha(S/'source.json')},
'build':{'exit':0,'core_workspace_compiles':3,'fuzz_target_compiles':6,'private_intermediates':'/home/dev-user/.cache/ohm/verified-build/ac/4edfa815b1ae37','rustc':build['rustc'],'clang':build['clang'],'cargo_fuzz':build['cargo_fuzz_version'],'sanitizer':'address','external_clang_runtime':True,'LSan':'disabled in campaign ASAN_OPTIONS; no leak-clean claim','binaries':binaries,'representative_instrumented_functions':disassembly},
'package':{'evidence_members':55,'excluded_binaries':6,'source_archive_members':357,'initial_archive_members':26689,'final_archive_members':16272,'all_member_origin_and_outer_hashes_verified':True,'evidence_sha256':sha(B/'evidence.tar.gz'),'final_corpus_sha256':sha(B/'final-corpus.tar.gz')},
'limits':['Runtime identity is5bc806e, preceding coalesced-selector193e and position prototypes. No campaigns for later code are inferred.','ASan flags plus representative machine-code checks demonstrate instrumented Rust storage/core/FFI and fuzz targets, not full compiler/std/libc instrumentation. The externally linked Clang18 runtime is separately recorded from RustLLVM22 compiler context.','Build subprocess.run timeout kills its direct process only and has no recorded process-group cleanup; the observed build completed normally with exit0. The initial missing cargo-fuzz PATH help attempt executed no build, as owner note states; raw help failure is not part of this package.','Six campaign no-finding status is bounded evidence, not proof of memory safety or general compatibility. Random executions include repeated inputs and initialization.'],
'evidence_sha256':H}
(O/'source-build-package-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'sha256':sha(O/'source-build-package-review.json')}))
