from pathlib import Path
import hashlib,json,shutil
O=Path(__file__).parent;C=Path('/tmp/oriole-frame-fuzz-stats-independent-review')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((O/'source-build-package-review.json').read_bytes());b=json.loads((C/'review.json').read_bytes())
assert a['status']=='source_build_package_passed' and b['status']=='passed'
assert sha(O/'source-build-package-review.json')=='0da9c7b724eb10013e4f2cc545de7dea9f50345974ede4c8d928aba3f2f9765a'
assert sha(C/'review.json')=='ef8fba2b8f7c4dc493f8bb975446bb83f51341f9497b9ade75bc8a28c719fc6e'
assert a['source']['commit']==b['source_commit_recorded']
S=O/'stats-review';S.mkdir(exist_ok=False)
for p in C.iterdir():
 if p.is_file():shutil.copy2(p,S/p.name)
r={'status':'passed_no_observed_findings','scope':'Combined independent source/build/ASan machine-code, campaign-source/log/stat/corpus and archive-readback audit of the six saved5bc806e campaigns. No fuzzers, parser tests, compilation or new timings executed by reviewers.',
'source_commit':a['source']['commit'],'source_files_exact':357,'workspace_crates_fresh_ASan_compiles':3,'fuzz_binaries_fresh_compiles':6,'totals':b['totals'],'limits':b['limits'],
'archive':a['package'],'representative_ASan_functions':a['build']['representative_instrumented_functions'],
'outcomes':{'replay_processes':6,'campaign_processes':6,'all12_exit0':True,'artifacts':0,'current_campaign_timeouts':0,'duration_seconds_range':[min(t['campaign']['elapsed_seconds'] for t in b['targets']),max(t['campaign']['elapsed_seconds'] for t in b['targets'])]},
'conclusion':'All recorded counts, source/build/binary identities, sanitizer evidence, original/evolved corpus mappings and archive bytes agree.14,617,069 executions is bounded repeated/initialization-inclusive evidence on5bc806e only, not a claim about later coalesced selector or position candidates.',
'caveats':a['limits']+b['caveats']+['Per-target campaign cleanup handles running child process groups on timeout/SIGINT/SIGTERM. The outer controller and build helper do not provide complete process-tree cleanup/timeout coverage; no such failure occurred in this completed evidence.','Original initial corpus and final writable corpus remain separately retained.16,272 final disk files differ from terminal live corpus counts;26,692 replay executions include six automatic empty initialization runs covering the three retained empty files.'],
'reviews':{'source_build_package':{'path':str(O/'source-build-package-review.json'),'sha256':sha(O/'source-build-package-review.json')},'statistics_and_runner':{'path':str(S/'review.json'),'sha256':sha(S/'review.json')}},
'generators_sha256':{str(p):sha(p) for p in [O/'audit.py',Path(__file__),S/'audit.py']}}
(O/'review.json').write_text(json.dumps(r,indent=2)+'\n')
(O/'files.json').write_text(json.dumps({str(p.relative_to(O)):sha(p) for p in sorted(O.rglob('*')) if p.is_file() and p.name!='files.json'},indent=2)+'\n')
print(json.dumps({'review_sha256':sha(O/'review.json'),'files_sha256':sha(O/'files.json'),'status':r['status']}))
