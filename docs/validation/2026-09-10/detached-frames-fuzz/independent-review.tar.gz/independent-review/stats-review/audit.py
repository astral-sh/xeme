"""Read saved fuzz evidence only; never executes project binaries or runners."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import sys

ROOT = Path('/tmp/oriole-frame-fuzz-study')
HANDOFF = Path('/tmp/oriole-frame-fuzz-handoff')
OUT = Path('/tmp/oriole-frame-fuzz-stats-independent-review')
TARGETS = ['parse', 'streaming', 'ffi', 'ffi_family', 'multibyte', 'value_family']
CPUS = {'parse': 1, 'multibyte': 1, 'streaming': 2, 'value_family': 2, 'ffi': 4, 'ffi_family': 4}
assert set(os.sched_getaffinity(0)) == {5}

observed = {}
checks = []
def read(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    old = observed.setdefault(str(path), digest)
    assert old == digest, f'Changed while reading: {path}'
    return raw

def digest(path):
    read(path)
    return observed[str(path)]

def load(path):
    return json.loads(read(path))

def check(name, condition):
    checks.append({'check': name, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(name)

runner_path = ROOT / 'run_campaign.py'
runner_text = read(runner_path).decode()
controller_text = read(ROOT / 'run_all.py').decode()
source = load(ROOT / 'source.json')
build = load(ROOT / 'build.json')
summary = load(ROOT / 'summary.json')
check('study and handoff summary bytes agree', read(ROOT / 'summary.json') == read(HANDOFF / 'summary.json'))
provenance = load(ROOT / 'corpus-provenance.json')
check('study and handoff provenance bytes agree', read(ROOT / 'corpus-provenance.json') == read(HANDOFF / 'corpus-provenance.json'))
summary_targets = {r['target']: r for r in summary['targets']}
campaign_summary = load(ROOT / 'campaign-summary.json')
check('controller summary exact targets, CPU assignments and successful exits',
      sorted(campaign_summary, key=lambda r:r['target']) == sorted([{'target': t, 'cpu': CPUS[t], 'exit_code': 0} for t in TARGETS], key=lambda r:r['target']))
final_manifest = load(HANDOFF / 'final-corpus-members.json')
final_manifest_by_path = {r['path']: r for r in final_manifest}
check('final manifest paths unique', len(final_manifest) == len(final_manifest_by_path))
readback = load(HANDOFF / 'readback.json')
rows = []
actual_final_paths = set()
all_initial_digests = set()
all_final_digests = set()
error_pattern = re.compile(r'^(?:==\d+==ERROR:|ERROR: (?:AddressSanitizer|libFuzzer)|SUMMARY: (?:AddressSanitizer|UndefinedBehaviorSanitizer)|.*runtime error:|thread .* panicked at|WARNING:)', re.M)

for target in TARGETS:
    path = ROOT / 'campaigns' / target
    result = load(path / 'result.json')
    result_hash = digest(path / 'result.json')
    entry = summary_targets[target]
    check(target + ': result digest matches summary', result_hash == entry['result_sha256'])
    check(target + ': runner source digest matches recorded result', digest(runner_path) == result['runner_sha256'])
    check(target + ': source and build manifest references match disk',
          digest(ROOT / 'source.json') == result['source_manifest_sha256'] and digest(ROOT / 'build.json') == result['build_json_sha256'])
    check(target + ': binary digest reference matches build manifest', result['binary_sha256'] == build['binaries'][target])
    check(target + ': success fields and CPU assignment', result['status'] == 'passed' and result['passed'] is True and result['target'] == target and result['cpu'] == CPUS[target])
    check(target + ': unchanged fields recorded true', all(result[k] is True for k in ['source_unchanged', 'source_manifest_unchanged', 'binary_unchanged', 'initial_inputs_unchanged']))
    manifest = load(path / 'initial-manifest.json')['inputs']
    check(target + ': initial manifest digest matches result', digest(path / 'initial-manifest.json') == result['initial_manifest_sha256'])
    actual_initial = {}
    for p in sorted((path / 'initial-corpus').iterdir()):
        raw = read(p)
        check(target + ': initial name matches SHA256 ' + p.name, digest(p) == p.name)
        actual_initial[p.name] = len(raw)
    check(target + ': complete initial corpus matches manifest names and lengths', actual_initial == manifest)
    check(target + ': initial counts agree across result, summary, provenance', len(manifest) == result['initial_inputs'] == entry['initial_inputs'] == provenance['inputs'][target])
    all_initial_digests.update(actual_initial)
    empty = sum(size == 0 for size in actual_initial.values())
    nonempty = len(actual_initial) - empty
    check(target + ': every initial file is strictly under configured max length', max(actual_initial.values()) < 65536)
    final = {}
    final_sizes = {}
    for p in sorted((path / 'corpus').iterdir()):
        raw = read(p)
        final[p.name] = digest(p)
        final_sizes[p.name] = len(raw)
        relative = target + '/' + p.name
        actual_final_paths.add(relative)
        check(target + ': final file agrees with handoff manifest ' + p.name,
              final_manifest_by_path.get(relative) == {'path': relative, 'bytes': len(raw), 'sha256': final[p.name]})
    check(target + ': final on-disk corpus matches result mapping', final == result['final_corpus'])
    check(target + ': final on-disk count agrees with summary', len(final) == entry['corpus_files'])
    all_final_digests.update(final.values())
    check(target + ': no artifact entries on disk or in result', list((path / 'artifacts').iterdir()) == [] and result['artifacts'] == [])
    check(target + ': replay and campaign only, both completed', [r['label'] for r in result['runs']] == ['replay', 'campaign'] and all(r['exit_code'] == 0 and not r.get('harness_timeout') for r in result['runs']))
    check(target + ': explicit ASAN options', result['environment'] == {'ASAN_OPTIONS': 'detect_leaks=0:abort_on_error=1'})
    parsed = {}
    log_refs = {}
    for run in result['runs']:
        label = run['label']
        bound = 180 if label == 'replay' else 690
        expected = ['taskset', '-c', str(CPUS[target]), str(ROOT / 'binaries' / target), '-seed=20260911', '-max_len=65536', '-timeout=10', '-rss_limit_mb=1536', f'-artifact_prefix={path}/artifacts/']
        expected += ['-runs=0', str(path / 'initial-corpus')] if label == 'replay' else ['-max_total_time=600', '-print_final_stats=1', str(path / 'corpus'), str(path / 'initial-corpus')]
        check(target + ': ' + label + ' command and bounds exactly match intended configuration', run['command'] == expected and run['outer_timeout_seconds'] == bound and 0 <= run['elapsed_seconds'] < bound)
        text = read(path / (label + '.log')).decode()
        check(target + ': ' + label + ' log hash agrees with result', digest(path / (label + '.log')) == run['log_sha256'])
        check(target + ': ' + label + ' no known sanitizer/fuzzer/panic/warning marker', error_pattern.search(text) is None)
        done = re.findall(r'^Done (\d+) runs in (\d+) second\(s\)$', text, re.M)
        check(target + ': ' + label + ' exactly one terminal runs record', len(done) == 1)
        runs, seconds = map(int, done[0])
        done_stats = re.findall(r'^#(\d+)\s+DONE\s+cov: (\d+) ft: (\d+) corp: (\d+)/([^ ]+) lim: (\d+) exec/s: (\d+) rss: (\d+)Mb$', text, re.M)
        check(target + ': ' + label + ' DONE counter agrees with terminal record', len(done_stats) == 1 and int(done_stats[0][0]) == runs)
        seed = re.findall(r'^INFO: seed corpus: files: (\d+) min: (\d+)b max: (\d+)b total: (\d+)b rss: (\d+)Mb$', text, re.M)
        expected_seed = (nonempty, min(v for v in actual_initial.values() if v), max(actual_initial.values()), sum(actual_initial.values()))
        check(target + ': ' + label + ' seed count, min, max and bytes agree with raw corpus', len(seed) == 1 and tuple(map(int, seed[0][:4])) == expected_seed)
        files_found = re.findall(r'^INFO:\s+(\d+) files found in (.+)$', text, re.M)
        expected_files = [(str(nonempty), str(path / 'initial-corpus'))]
        if label == 'campaign':
            expected_files.insert(0, ('0', str(path / 'corpus')))
        check(target + ': ' + label + ' files found records agree with expected directories', files_found == expected_files)
        check(target + ': ' + label + ' fixed seed logged once', re.findall(r'^INFO: Seed: (\d+)$', text, re.M) == ['20260911'])
        parsed[label] = {'runs': runs, 'reported_seconds': seconds, 'initial_files_loaded': nonempty, 'live_corpus_at_done': int(done_stats[0][3]), 'done_line': next(l for l in text.splitlines() if '\tDONE' in l), 'elapsed_seconds': run['elapsed_seconds'], 'started_at_utc': run['started_at_utc']}
        log_refs[label] = digest(path / (label + '.log'))
        if label == 'campaign':
            pairs = re.findall(r'^stat::(\w+):\s+(\d+)$', text, re.M)
            stats = {k: int(v) for k, v in pairs}
            check(target + ': final statistic keys unique and exactly match result', len(pairs) == len(stats) and stats == result['stats'])
            check(target + ': campaign executed count matches stats and summary', runs == stats['number_of_executed_units'] == entry['executed_units'])
            check(target + ': campaign recorded 601 seconds with consistent elapsed', seconds == 601 and 601 <= run['elapsed_seconds'] < 602 and run['elapsed_seconds'] == entry['duration_seconds'])
            check(target + ': campaign average exec/s and peak RSS consistent with bounds', stats['average_exec_per_sec'] == runs // seconds and stats['peak_rss_mb'] < 1536)
    check(target + ': replay counter is nonempty inputs plus one bootstrap', parsed['replay']['runs'] == nonempty + 1)
    controller = read(ROOT / ('controller-' + target + '.log')).decode().splitlines()
    check(target + ': controller log contains start and matching completed result', len(controller) == 2 and json.loads(controller[0]) == {'started': target, 'initial_inputs': len(manifest)} and json.loads(controller[1]) == {k:v for k,v in result.items() if k != 'final_corpus'})
    rows.append({'target': target, 'cpu': CPUS[target], 'result_sha256': result_hash, 'log_sha256': log_refs, 'initial_raw_files': len(actual_initial), 'initial_empty_files': empty, 'initial_nonempty_files': nonempty, 'initial_bytes': sum(actual_initial.values()), 'initial_max_bytes': max(actual_initial.values()), 'replay': parsed['replay'], 'campaign': parsed['campaign'], 'stats': result['stats'], 'final_corpus_disk_files': len(final), 'final_corpus_max_bytes': max(final_sizes.values()), 'artifacts': 0})

check('handoff final manifest has no extra or missing paths', actual_final_paths == set(final_manifest_by_path))
totals = {'campaign_executions': sum(r['campaign']['runs'] for r in rows), 'initial_raw_files': sum(r['initial_raw_files'] for r in rows), 'initial_nonempty_files': sum(r['initial_nonempty_files'] for r in rows), 'initial_empty_files': sum(r['initial_empty_files'] for r in rows), 'replay_runs': sum(r['replay']['runs'] for r in rows), 'final_corpus_disk_files': sum(r['final_corpus_disk_files'] for r in rows), 'initial_unique_contents_across_targets': len(all_initial_digests), 'final_unique_contents_across_targets': len(all_final_digests)}
check('campaign total matches study summary and handoff readback', totals['campaign_executions'] == summary['total_executed_units'] == readback['executed_units'] == 14617069)
check('raw initial total matches summaries and empty count', totals['initial_raw_files'] == summary['total_initial_inputs'] == readback['initial_raw_files'] == 26689 and totals['initial_empty_files'] == provenance['empty_files'] == readback['initial_empty_files'] == 3)
check('replay arithmetic matches readback', totals['replay_runs'] == totals['initial_raw_files'] - totals['initial_empty_files'] + len(TARGETS) == readback['replay_runs'] == 26692)
check('final disk corpus total matches handoff readback', totals['final_corpus_disk_files'] == readback['final_corpus_files'] == 16272)

# Second byte-hash pass detects changes during this audit. This is not a claim of
# historical immutability, and neither pass invokes any target or build tool.
changed = [name for name, expected in observed.items() if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected]
check('all inspected saved files unchanged between audit passes', not changed)
report = {
    'status': 'passed',
    'audited_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Independent saved-data-only audit of six current frame fuzz campaigns, runner/controllers, replay and campaign logs, initial and final corpus disk mapping; no binaries executed and no build/test/timing reruns.',
    'interpreter': sys.executable,
    'cpu_affinity': sorted(os.sched_getaffinity(0)),
    'source_commit_recorded': source.get('commit'),
    'generator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'runner_sha256': digest(runner_path),
    'controller_sha256': digest(ROOT / 'run_all.py'),
    'checked_file_count': len(observed),
    'passed_check_count': len(checks),
    'checked_file_hashes_sha256': hashlib.sha256(json.dumps(observed, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
    'changed_during_audit': changed,
    'totals': totals,
    'targets': rows,
    'limits': {'campaign_internal_seconds': 600, 'campaign_outer_wait_seconds': 690, 'replay_outer_wait_seconds': 180, 'input_timeout_seconds': 10, 'maximum_input_bytes': 65536, 'rss_limit_mib': 1536, 'seed': 20260911, 'ASAN_OPTIONS': 'detect_leaks=0:abort_on_error=1'},
    'runner_review': [
        'run_campaign verifies source, build/binary references and initial-content SHA256 names before launching, and refuses preexisting result/corpus/artifact directories.',
        'Each target has a separate subprocess session/process group; outer timeout sends SIGKILL to the group and waits. SIGINT/SIGTERM handler also kills and waits. Inner finally repeats cleanup while active child remains live.',
        'Replay must return zero to launch campaign. Results/log digests and elapsed values are saved around each phase; final records include unchanged predicates, artifact lists, corpus mapping and stats.',
        'run_all uses three parallel lanes, sequentially parse then multibyte on CPU1, streaming then value_family on CPU2, ffi then ffi_family on CPU4. Controller results and child logs are retained.',
        'run_all itself has no outer timeout or signal forwarding to child runner processes. Per-target wait bounds exclude preflight hashing/nm and postprocessing; nm has no explicit timeout. These are code limits, not failures observed in the six completed campaigns.',
        'The runner passed predicate does not independently require final stats/terminal DONE or check log diagnostic markers. This audit verifies the saved terminal records and matching final stats for all six completed campaigns.',
        'Controller CPU binding applies to target subprocesses through taskset, not to the Python controllers; this audit only ran saved-data Python with affinity CPU5.',
    ],
    'caveats': [
        'Counts are libFuzzer execution counts including initialization and repeated runs, not unique inputs; separate replay counts are not part of 14,617,069 campaign executions.',
        '26,689 is the sum of raw files in target-specific initial directories. Logs load 26,686 nonempty files and show one extra initialization run per target. The three retained empty files are represented by the same empty input tested at initialization.',
        'Ten-minute campaign max_total_time includes campaign corpus initialization after a separate replay. All logs report 601 seconds and saved campaign elapsed values are 601.141-601.192 seconds.',
        '16,272 is the number of retained files in the initially empty writable corpus directories. It is distinct from both the original initial corpus and the live in-memory corp counts in the terminal DONE lines; neither raw count is a global unique-input count.',
        'Leak detection is disabled; no safety proof or claims about later scanner candidates follow from bounded campaigns.',
        'Known diagnostic marker scan is a saved-log cross-check, not an exhaustive diagnostic parser.',
        'Actual source and binary bytes, ASan instruction attribution, provenance archive member mapping, and evidence/final-corpus tar readback are delegated to the parent independent audit and not re-audited here.',
        'Saved file hashes match recorded references and were unchanged during two audit passes; this cannot establish historical immutability between campaign completion and first audit read.',
    ],
    'incomplete_attempts': {'within_current_campaigns': [], 'outside_current_campaign_directories': 'Not yet inspected; excluded from six campaign totals.'},
}
(OUT / 'checked-files.json').write_text(json.dumps(observed, sort_keys=True, indent=2) + '\n')
(OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'checked_file_count': len(observed), 'passed_check_count': len(checks), 'totals': totals, 'report': str(OUT / 'review.json')}, indent=2))
