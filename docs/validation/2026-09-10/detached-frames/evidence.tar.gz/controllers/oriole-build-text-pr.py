import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path('/home/dev-user/code/oss/oriole-text-frames')
out = Path('/tmp/oriole-text-frames-pr/release')
out.mkdir(exist_ok=False)
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
names = json.loads(Path('/tmp/oriole-frame-integration/source.json').read_text())['source_sha256']
source = {name: digest(root / name) for name in names}
record = {'worktree': str(root), 'source_sha256': source,
          'note': 'PR3 on fdb7afb; all69 entries match integrated source except the retained PR1 doc comment and cfg(test) regression. See assembly.json.'}
(out / 'source.json').write_text(json.dumps(record, indent=2) + '\n')
with tarfile.open(out / 'source.tar.gz', 'w:gz') as archive:
    for name in source:
        archive.add(root / name, arcname=name, recursive=False)
for name in source:
    os.utime(root / name, None)
env = {
    'CARGO_HOME': '/home/dev-user/.cache/toucan/cargo',
    'CARGO_BUILD_BUILD_DIR': '/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}',
    'CARGO_TARGET_DIR': '/home/dev-user/.cache/oriole/text-frames-target',
    'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST': 'all',
    'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST': 'all',
    'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0',
    'RUSTC_WRAPPER': '', 'RUSTC_WORKSPACE_WRAPPER': '',
    'RUSTFLAGS': '', 'CARGO_ENCODED_RUSTFLAGS': '',
}
command = ['taskset', '-c', '2,3', 'cargo', '+ohm', '-Zohm-defaults=no', 'build', '--release', '--locked', '-p', 'oriole_expat', '-vv']
report = {'status': 'incomplete', 'command': command, 'env_overrides': env,
          'source_manifest_sha256': digest(out / 'source.json')}
try:
    with (out / 'build.log').open('wb') as log:
        run = subprocess.run(command, cwd=root, env=os.environ | env, stdout=log, stderr=subprocess.STDOUT)
    report['exit'] = run.returncode
    assert run.returncode == 0
    invocations = [line.strip() for line in (out / 'build.log').read_text().splitlines()
                   if 'Running' in line and '/rustc ' in line and 'CARGO_MANIFEST_DIR=' + str(root) + '/' in line]
    assert len(invocations) == 3, len(invocations)
    for crate in ['oriole_storage', 'oriole', 'oriole_expat']:
        assert sum('--crate-name ' + crate + ' ' in line for line in invocations) == 1
    (out / 'workspace-compiler-invocations.json').write_text(json.dumps(invocations, indent=2) + '\n')
    report['workspace_compilations'] = 3
    report['libraries'] = {}
    for name in ['liboriole_expat.so', 'liboriole_expat.a']:
        shutil.copy2(Path(env['CARGO_TARGET_DIR']) / 'release' / name, out / name)
        report['libraries'][name] = digest(out / name)
    assert all(digest(root / name) == value for name, value in source.items())
    report['source_unchanged'] = True
    report['status'] = 'passed'
finally:
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)
