import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/home/dev-user/code/oss/oriole-text-frames')
out = Path('/tmp/oriole-text-frames-pr')
env = json.loads((out / 'release/report.json').read_text())['env_overrides']
source = json.loads((out / 'release/source.json').read_text())['source_sha256']
report = {'status': 'incomplete', 'jobs': []}
try:
    for name, args in [('fmt', ['fmt', '--all', '--', '--check']), ('test', ['test', '--workspace', '--all-targets', '--locked']), ('clippy', ['clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings'])]:
        command = ['taskset', '-c', '2,3', 'cargo', '+ohm', '-Zohm-defaults=no', *args]
        with (out / (name + '.log')).open('wb') as log:
            result = subprocess.run(command, cwd=root, env=os.environ | env, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
        report['jobs'].append({'name': name, 'command': command, 'env_overrides': env, 'exit': result.returncode})
        (out / 'checks.json').write_text(json.dumps(report, indent=2) + '\n')
        print(name, result.returncode, flush=True)
        assert result.returncode == 0
    assert all(hashlib.sha256((root / name).read_bytes()).hexdigest()==value for name,value in source.items())
    report['status'] = 'passed'
    report['source_unchanged'] = True
finally:
    (out / 'checks.json').write_text(json.dumps(report, indent=2) + '\n')
