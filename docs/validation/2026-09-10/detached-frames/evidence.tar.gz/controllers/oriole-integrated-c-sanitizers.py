import json
import os
from pathlib import Path
import subprocess

root = Path('/home/dev-user/code/oss/oriole-frame-integration')
out = Path('/tmp/oriole-frame-integrated-c-sanitizers')
out.mkdir(exist_ok=False)
library = '/tmp/oriole-frame-integrated-final/liboriole_expat.so'
env = {'ASAN_OPTIONS': 'detect_leaks=1:abort_on_error=1', 'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'}
report = {'status': 'incomplete', 'scope': 'C consumers instrumented with ASan/UBSan/LSan against normal release Rust library. Retried outside ptrace sandbox after sandbox LeakSanitizer fatal error; initial failure retained in /tmp/oriole-frame-integrated-supplemental.', 'env_overrides': env, 'jobs': []}
try:
    for source in ['integration', 'adversarial', 'allocations']:
        binary = out / source
        commands = [('build', ['cc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-g', '-no-pie', '-I', str(root / 'include'), str(root / ('tests/c/' + source + '.c')), library, '-Wl,-rpath,/tmp/oriole-frame-integrated-final', '-o', str(binary)]), ('run', [str(binary)])]
        for phase, command in commands:
            with (out / (source + '-' + phase + '.log')).open('wb') as log:
                result = subprocess.run(['taskset', '-c', '2,3', *command], cwd=root, env=os.environ | env, stdout=log, stderr=subprocess.STDOUT, timeout=300)
            report['jobs'].append({'source': source, 'phase': phase, 'command': command, 'exit': result.returncode})
            print(source, phase, result.returncode, flush=True)
            assert result.returncode == 0
    report['status'] = 'passed'
finally:
    (out / 'controller.json').write_text(json.dumps(report, indent=2) + '\n')
