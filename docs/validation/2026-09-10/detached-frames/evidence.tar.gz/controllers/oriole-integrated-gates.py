import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/home/dev-user/code/oss/oriole-frame-integration')
out = Path('/tmp/oriole-frame-integrated-gates')
out.mkdir(exist_ok=False)
python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
library = Path('/tmp/oriole-frame-integrated-final/liboriole_expat.so')
archive = library.with_suffix('.a')
source = '/home/dev-user/.cache/oriole/upstream/cpython-3.12.13'
prefix = ['taskset', '-c', '2,3', python, '-I', '-S']
jobs = [
 ('api', [str(root / 'tools/upstream-expat/run.py'), '--source', '/home/dev-user/.cache/oriole/upstream/expat-2.8.4', '--config', '/tmp/oriole-security-controls-integrated/upstream-api/adapted/expat_config.h', '--library', str(library), '--output', str(out / 'upstream-api'), '--timeout', '240'], 1),
 ('strict', [str(root / 'tools/differential.py'), '--library', str(library), '--reference', '/tmp/oriole-dtd-reparse-final/liboriole_expat.so', '--output', str(out / 'strict'), '--strict', '--generated', '250'], 0),
 ('cpython-shared', [str(root / 'tools/cpython/run.py'), '--source', source, '--library', str(library), '--output', str(out / 'cpython-shared')], 2),
 ('cpython-static', [str(root / 'tools/cpython/run.py'), '--source', source, '--library', str(archive), '--output', str(out / 'cpython-static'), *[arg for name in ['gcc_s', 'util', 'rt', 'pthread', 'm', 'dl', 'c'] for arg in ['--native-library', name]]], 2),
]
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
report = {'status': 'incomplete', 'libraries': {str(p): digest(p) for p in [library, archive]}, 'jobs': []}
def save():
    (out / 'controller.json').write_text(json.dumps(report, indent=2) + '\n')
try:
    for name, command, expected in jobs:
        item = {'name': name, 'command': prefix + command, 'expected_exit': expected, 'status': 'running'}
        report['jobs'].append(item)
        save()
        with (out / (name + '.log')).open('wb') as log:
            result = subprocess.run(prefix + command, cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
        item.update(exit=result.returncode, status='completed')
        save()
        print(name, result.returncode, flush=True)
        assert result.returncode == expected, item
    assert all(digest(Path(p)) == h for p, h in report['libraries'].items())
    report['status'] = 'completed_with_original_failures_retained_pending_result_review'
finally:
    save()
