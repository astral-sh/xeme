"""Independent saved-data review; no parser, build or timing execution."""
if not __debug__: raise RuntimeError('Assertions required')
from pathlib import Path
import hashlib,json,math,random,statistics,tarfile
R=Path('/tmp/oriole-integrated-native-study');S=R/'native-screen';O=Path('/tmp/oriole-integrated-native-independent-review');O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes());key=lambda c:json.dumps(c,sort_keys=True)
p=read(S/'protocol.json');pre=read(S/'preflight.json');r=read(S/'results.json');summary=read(R/'summary.json');build=read('/tmp/oriole-verified-builds/report.json')
assert p['pairs']==7 and p['preflights']==84 and p['timed_workers']==588;assert pre['status']==r['status']=='passed';assert r['affinity']==[0]
assert pre['protocol_sha256']==r['protocol_sha256']==sha(S/'protocol.json');assert r['preflight_sha256']==sha(S/'preflight.json')
for d in [pre,r]:assert d['hashes_before']==d['hashes_after']==p['hashes']
for file,want in p['hashes'].items():assert sha(file)==want,file
sources={}
for engine,root in [('published',Path('/tmp/oriole-verified-builds/published')),('candidate',Path('/tmp/oriole-frame-integrated-final'))]:
 record=read(root/'source.json');source=record['source_sha256']
 b=build['variants']['published'] if engine=='published' else read(root/'report.json')
 assert b['status']=='passed' and b['libraries']['liboriole_expat.so']==p['libraries'][engine]['sha256']==sha(root/'liboriole_expat.so')
 with tarfile.open(root/'source.tar.gz') as archive:
  members=archive.getmembers();assert all(m.isfile() for m in members);files={m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in members}
 assert files==source and len(files)==len(members)
 if engine=='candidate':
  assert len(source)==69 and b['exit']==0 and b['source_unchanged'] and b['workspace_compilations']==3
  assert b['source_manifest_sha256']==sha(root/'source.json')
  assert all(sha(Path(record['worktree'])/name)==value for name,value in source.items())
  assert b['env_overrides']['CARGO_BUILD_BUILD_DIR']=='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}'
  assert b['env_overrides']['CARGO_INCREMENTAL']=='0'
  assert all(b['env_overrides'][k]=='' for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'])
  assert '-Zohm-defaults=no' in b['command']
  invocations=read(root/'workspace-compiler-invocations.json');assert len(invocations)==3
  for crate,line in zip(['oriole_storage','oriole','oriole_expat'],invocations,strict=True):
   assert '--crate-name '+crate+' ' in line and ('--emit=dep-info,link' if crate=='oriole_expat' else '--emit=dep-info,metadata,link') in line and '-C opt-level=3' in line and '-C codegen-units=1' in line
   assert line in (root/'build.log').read_text()
 sources[engine]={'source_files':len(source),'source_sha256':sha(root/'source.json'),'archive_sha256':sha(root/'source.tar.gz'),'library_sha256':sha(root/'liboriole_expat.so')}
controller=read('/tmp/oriole-integrated-timing-controller.json')
assert controller['status']=='passed' and len(controller['jobs'])==2 and all(j['status']=='passed' and j['exit']==0 for j in controller['jobs'])
assert controller['jobs'][1]['command'][-2:]==[str(R/'native_screen.py'),'time']
conditions=p['conditions'];assert len(conditions)==len({key(c) for c in conditions})==28;engines=['published','candidate','expat'];driver='/tmp/oriole-grammar-bench-plain/native-driver';raw=[]
fixed={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
for c in conditions:assert c['iterations']==fixed[c['name']] and c['chunk'] in [4096,65536]
assert sum(not c['name'].startswith('generated-') for c in conditions)==24

def process(row,c,pair,cpu,count):
 assert row['condition']==c and row['pair']==pair and row['returncode']==0 and row['stderr']==''
 e=row['engine'];assert e in engines;cmd=['taskset','-c',str(cpu),driver,p['libraries'][e]['path'],c['input'],str(c['chunk']),str(count)]+(['namespaces'] if c['namespaces'] else []);assert row['command']==cmd
 data=json.loads(row['stdout']);assert data['version']==('expat_2.8.4' if e=='expat' else 'oriole_compat_2.8.4');samples=data['samples'];assert len(samples)==count+1;assert [s['iteration'] for s in samples]==list(range(count+1));assert [s['warmup'] for s in samples]==[True]+[False]*count;assert all(math.isfinite(s['seconds']) and s['seconds']>0 for s in samples)
 observations=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in samples});assert len(observations)==1 and row['observations']==[list(x) for x in observations];median=statistics.median(s['seconds'] for s in samples[1:]);assert median==row['median_seconds']
 raw.append({'condition':c,'pair':pair,'engine':e,'stdout_sha256':hashlib.sha256(row['stdout'].encode()).hexdigest(),'stderr_sha256':hashlib.sha256(row['stderr'].encode()).hexdigest(),'measured_samples':count})
 return observations,median
assert len(pre['rows'])==84;expected={}
for index,c in enumerate(conditions):
 rows=pre['rows'][index*3:index*3+3];assert [r['engine'] for r in rows]==engines;values=[process(row,c,-1,3,1)[0] for row in rows];assert values[0]==values[1]==values[2];expected[key(c)]=values[0]
rng=random.Random(p['seed']);jobs=[(c,pair) for c in conditions for pair in range(7)];rng.shuffle(jobs);assert len(jobs)==len(r['rows'])==196;ratios={key(c):{n:[] for n in ['candidate_over_published','candidate_over_expat','published_over_expat']} for c in conditions};measured=0
for (c,pair),group in zip(jobs,r['rows'],strict=True):
 order=engines.copy();rng.shuffle(order);assert group['condition']==c and group['pair']==pair and group['order']==order and [x['engine'] for x in group['processes']]==order;times={}
 for row in group['processes']:
  observations,median=process(row,c,pair,0,c['iterations']);assert observations==expected[key(c)];times[row['engine']]=median;measured+=c['iterations']
 for label in ratios[key(c)]:a,b=label.split('_over_');ratios[key(c)][label].append(times[a]/times[b])
computed=[{'condition':c,'paired_ratios':ratios[key(c)],'median_ratios':{k:statistics.median(v) for k,v in ratios[key(c)].items()}} for c in conditions];assert r['summary']==computed;assert measured==105420
computed_groups={}
for name,predicate in [('real',lambda c:not c['name'].startswith('generated-')),('generated',lambda c:c['name'].startswith('generated-')),('namespaces-off',lambda c:not c['name'].startswith('generated-') and not c['namespaces']),('namespaces-on',lambda c:not c['name'].startswith('generated-') and c['namespaces'])]:
 computed_groups[name]={}
 for label in ratios[key(conditions[0])]:
  values=[row['median_ratios'][label] for row in computed if predicate(row['condition'])];result={'geomean':math.exp(sum(math.log(v) for v in values)/len(values)),'below_one':sum(v<1 for v in values),'conditions':len(values)};actual=summary[name][label];assert actual['below_one']==result['below_one'] and actual['conditions']==result['conditions'] and math.isclose(actual['geomean'],result['geomean'],rel_tol=1e-14);computed_groups[name][label]=result
(O/'streams.json').write_text(json.dumps(raw,indent=2)+'\n')
report={'status':'passed_no_findings','scope':'Independent saved-data/source identity/arithmetic audit only; no parser/build/timing rerun.','counts':{'preflight_processes':84,'preflight_samples_including_warmups':168,'timed_processes':588,'timed_warmups':588,'measured_samples':measured,'cohorts':196,'conditions':28,'ratios_per_condition':3},'sources':sources,'groups':computed_groups,'checks':['All frozen advertised hashes and both Oriole source archive member maps rehashed.','All672 stdout/stderr records, exit status, exact CPU/arguments, warmups, every per-sample callback metadata and process median verified.','All196 seeded condition/pair and three-engine execution orders reconstructed.','All588 process medians,588 paired ratios,84 condition medians and12 group geomeans reproduced.'],'limitations':['Fresh no-default Oriole builds are matched; original mode-confounded measurements are not combined.','Native timer includes construction/parsing/native callbacks/destruction, not process startup or real application work.','Callback hashes/counts are selected normalized metadata, not complete raw event/fragmentation transcripts or conformance evidence.','One warmup per timed process excluded; every measured sample retained. Affinity records do not exclude unrelated shared-host activity.','Candidate remains slower than Expat in all24 real and4 generated conditions while beating published Oriole in all24 real conditions; two of four generated conditions regress.','Batik external DTD is not loaded by this driver.'],'hashes':{str(path):sha(path) for path in [Path(__file__),R/'native_screen.py',R/'summary.json',*(S/(n+'.json') for n in ['protocol','preflight','results']),O/'streams.json',Path('/tmp/oriole-verified-builds/report.json'),Path('/tmp/oriole-frame-integrated-final/report.json'),Path('/tmp/oriole-frame-integrated-final/source.json'),Path('/tmp/oriole-frame-integrated-final/workspace-compiler-invocations.json'),Path('/tmp/oriole-integrated-timing-controller.json')]}}
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(sha(O/'review.json'))
