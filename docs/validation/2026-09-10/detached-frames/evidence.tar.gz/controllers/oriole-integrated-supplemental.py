import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/home/dev-user/code/oss/oriole-frame-integration')
out = Path('/tmp/oriole-frame-integrated-supplemental')
out.mkdir(exist_ok=False)
python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
library = '/tmp/oriole-frame-integrated-final/liboriole_expat.so'
baseline = '/tmp/oriole-dtd-reparse-final/liboriole_expat.so'
old = Path('/tmp/oriole-ns-coalesced-fresh-validation')
patches = []
for name in ['malformed_probe.py', 'coordinate_comparison.py']:
    text = (old / name).read_text()
    updated = text.replace(str(old), str(out)).replace('/tmp/oriole-ns-coalesced-study/liboriole_expat.so', baseline).replace('/tmp/oriole-verified-builds/coalesced/liboriole_expat.so', library).replace('/tmp/oriole-verified-builds/ns/liboriole_expat.so', '/tmp/oriole-verified-builds/coalesced/liboriole_expat.so').replace('old-coalesced', 'published').replace('fresh-faithful', 'prototype').replace('fresh-coalesced', 'candidate').replace('old_coalesced', 'published')
    (out / name).write_text(updated)
    patches.extend(difflib.unified_diff(text.splitlines(True), updated.splitlines(True), fromfile='prior/' + name, tofile='integrated/' + name))
(out / 'harness.patch').write_text(''.join(patches))
report = {'status': 'incomplete', 'jobs': [], 'scope': 'Final normal Rust release library; ASan/UBSan instrument the C consumers only. Original CPython failures retained; semantic checks run separately without changing suite outcomes.'}
def run(name, command, extra=None):
    with (out / (name + '.log')).open('wb') as log:
        result = subprocess.run(['taskset', '-c', '2,3', *command], cwd=root, env=os.environ | (extra or {}), stdout=log, stderr=subprocess.STDOUT, timeout=300)
    report['jobs'].append({'name': name, 'command': command, 'env_overrides': extra or {}, 'exit': result.returncode})
    (out / 'controller.json').write_text(json.dumps(report, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    assert result.returncode == 0
try:
    for name in ['malformed_probe.py', 'coordinate_comparison.py']:
        run(name[:-3], [python, '-I', '-S', str(out / name)])
    for linkage in ['shared', 'static']:
        directory = '/tmp/oriole-frame-integrated-gates/cpython-' + linkage
        run('semantic-' + linkage, [python, '-s', str(root / 'tools/cpython/text_fragmentation.py'), directory], {'PYTHONPATH': directory + ':/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Lib'})
    for sanitized in [False, True]:
        for source in ['integration', 'adversarial', 'allocations']:
            label = source + ('-sanitized' if sanitized else '-native')
            binary = out / label
            flags = ['-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-g', '-no-pie'] if sanitized else []
            run(label + '-build', ['cc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', *flags, '-I', str(root / 'include'), str(root / ('tests/c/' + source + '.c')), library, '-Wl,-rpath,/tmp/oriole-frame-integrated-final', '-o', str(binary)])
            run(label, [str(binary)], {'ASAN_OPTIONS': 'detect_leaks=1:abort_on_error=1', 'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'} if sanitized else None)
    report['status'] = 'passed'
finally:
    (out / 'controller.json').write_text(json.dumps(report, indent=2) + '\n')
