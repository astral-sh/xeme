import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

root = Path('/home/dev-user/code/oss/oriole-frame-evidence')
out = root / 'docs/validation/2026-09-10/detached-frames'
assert not (out / 'evidence.tar.gz').exists()
directories = {
    'grammar-layer': '/tmp/oriole-shared-tag-grammar-pr',
    'start-layer': '/tmp/oriole-start-frames-pr',
    'text-layer': '/tmp/oriole-text-frames-pr',
    'integration-assembly': '/tmp/oriole-frame-integration',
    'measured-build': '/tmp/oriole-frame-integrated-final',
    'compatibility': '/tmp/oriole-frame-integrated-gates',
    'supplemental': '/tmp/oriole-frame-integrated-supplemental',
    'c-sanitizers': '/tmp/oriole-frame-integrated-c-sanitizers',
    'python-benchmark': '/tmp/oriole-integrated-consumer-study',
    'native-benchmark': '/tmp/oriole-integrated-native-study',
    'fresh-control-builds': '/tmp/oriole-verified-builds',
    'trace-tools': '/tmp/oriole-ns-coalesced-study/trace-tools',
    'reviews/cleanup': '/tmp/oriole-frame-cleanup-independent-review',
    'reviews/build-controls': '/tmp/oriole-build-provenance-independent-review',
    'reviews/preflight': '/tmp/oriole-integrated-benchmark-preflight-review',
    'reviews/behavior': '/tmp/oriole-frame-behavior-independent-review',
    'reviews/python': '/tmp/oriole-integrated-python-independent-review',
    'reviews/native': '/tmp/oriole-integrated-native-independent-review',
    'reviews/stack-binary': '/tmp/oriole-pr3-binary-independent-review',
    'reviews/start-source': '/tmp/oriole-start-frames-independent-review',
}
single_files = [
    '/tmp/oriole-build-integrated-final.py', '/tmp/oriole-integrated-gates.py',
    '/tmp/oriole-integrated-supplemental.py', '/tmp/oriole-integrated-c-sanitizers.py',
    '/tmp/oriole-prepare-integrated-benchmarks.py', '/tmp/oriole-time-integrated-benchmarks.py',
    '/tmp/oriole-integrated-timing-controller.json', '/tmp/oriole-build-text-pr.py',
    '/tmp/oriole-check-text-pr.py', '/tmp/oriole-package-frame-evidence.py',
    '/tmp/oriole-verified-build-controller.py', '/tmp/oriole-section-inspection-incident.json',
    '/tmp/oriole-shared-tag-grammar-root-review.json', '/tmp/oriole-integrated-native-independent-audit.py',
]
def digest(data):
    return hashlib.sha256(data).hexdigest()
members = []
excluded = []
paths = {}
for label, directory in directories.items():
    directory = Path(directory)
    assert directory.is_dir(), directory
    for path in sorted(directory.rglob('*')):
        if not path.is_file() or path.is_symlink() or '__pycache__' in path.parts:
            continue
        name = label + '/' + str(path.relative_to(directory))
        paths[name] = path
for name in single_files:
    path = Path(name)
    assert path.is_file(), path
    paths['controllers/' + path.name] = path
with tarfile.open(out / 'evidence.tar.gz', 'w:gz', compresslevel=9) as archive:
    for name, path in sorted(paths.items()):
        data = path.read_bytes()
        entry = {'path': name, 'source': str(path), 'bytes': len(data), 'sha256': digest(data)}
        if data.startswith(b'\x7fELF') or data.startswith(b'!<arch>\n'):
            excluded.append(entry)
            continue
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
        members.append(entry)
(out / 'archive-members.json').write_text(json.dumps({'members': members, 'excluded_binaries': excluded}, indent=2) + '\n')
with tarfile.open(out / 'evidence.tar.gz', 'r:gz') as archive:
    entries = archive.getmembers()
    assert len(entries) == len(members)
    for archived, expected in zip(entries, members):
        assert archived.isfile() and archived.name == expected['path'] and archived.size == expected['bytes']
        data = archive.extractfile(archived).read()
        assert digest(data) == expected['sha256']
        assert digest(Path(expected['source']).read_bytes()) == expected['sha256']
copies = {
    'source.json': '/tmp/oriole-text-frames-pr/release/source.json',
    'measured-source.json': '/tmp/oriole-frame-integrated-final/source.json',
    'build-equivalence-review.json': '/tmp/oriole-pr3-binary-independent-review/review.json',
    'behavior-review.json': '/tmp/oriole-frame-behavior-independent-review/review.json',
    'python-review.json': '/tmp/oriole-integrated-python-independent-review/review.json',
    'native-review.json': '/tmp/oriole-integrated-native-independent-review/review.json',
    'cleanup-review.json': '/tmp/oriole-frame-cleanup-independent-review/review.json',
}
for name, path in copies.items():
    shutil.copy2(path, out / name)
atomic = out / 'unselected-accounting'
shutil.copytree('/tmp/oriole-unique-accounting-handoff', atomic)
summary = {
    'commit': '5bc806e5fc2a545f22c75f2a1bcbef45cfa3632b',
    'workspace_tests': 392,
    'workspace_executables': 33,
    'fmt_and_strict_clippy': 'passed',
    'api': {'configurations': 4740, 'passed': 4347, 'failed': 393, 'all_outcomes_unchanged_from': 'db5a867', 'results_sha256': digest(Path('/tmp/oriole-frame-integrated-gates/upstream-api/results.json').read_bytes())},
    'strict_cases': 3318,
    'malformed_cases': 2392,
    'cpython': {'per_linkage': {'run': 802, 'failures': 2, 'skips': 14, 'expected_failures': 3}, 'linkages': ['shared', 'static'], 'original_failures_retained': True},
    'native_benchmark': json.loads(Path('/tmp/oriole-integrated-native-study/summary.json').read_text()),
    'python_benchmark': json.loads(Path('/tmp/oriole-integrated-consumer-study/summary.json').read_text()),
    'measured_shared_sha256': '9277b71c85f3c0345697010eb282a3be18a0144f25bc2f78e2a0cee20c175dcd',
    'assembled_shared_sha256': '5af2406b17092dad35aa61c086cdfe39e24f51e653441fd9baf50cd12da3b2fe',
    'shared_elf_difference': '20 build-ID bytes and18 panic-location line bytes; all other bytes identical',
    'archive': {'members': len(members), 'excluded_binaries': len(excluded), 'uncompressed_bytes': sum(x['bytes'] for x in members), 'bytes': (out / 'evidence.tar.gz').stat().st_size, 'sha256': digest((out / 'evidence.tar.gz').read_bytes()), 'readback_all_members_verified': True},
    'scope': 'Original failures remain failures. No broad faster-than-Expat, full-application, fresh sustained Rust fuzz or final PBS distribution claim.',
}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary['archive'], indent=2))
