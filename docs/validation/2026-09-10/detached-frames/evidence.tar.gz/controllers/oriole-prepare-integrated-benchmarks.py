import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
consumer = Path('/tmp/oriole-integrated-consumer-study')
native = Path('/tmp/oriole-integrated-native-study')
for out in [consumer, native]:
    out.mkdir(exist_ok=False)
for name in ['build_consumers.py', 'consumer_screen.py', 'python_worker.py']:
    shutil.copy2(Path('/tmp/oriole-verified-consumer-study') / name, consumer / name)
original = Path('/tmp/oriole-verified-native-study/native_screen.py').read_text()
updated = original.replace('/tmp/oriole-verified-native-study', str(native)).replace('/tmp/oriole-verified-builds/coalesced/liboriole_expat.so', '/tmp/oriole-frame-integrated-final/liboriole_expat.so').replace('fresh coalesced namespace frame/dbeec28f candidate', 'integrated coalesced frames/9277b71c candidate (db5 fixes retained; abandoned line-policy hook removed)')
(native / 'native_screen.py').write_text(updated)
(native / 'harness.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), updated.splitlines(True), fromfile='verified-native/native_screen.py', tofile='integrated-native/native_screen.py')))
manifest = '/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json'
jobs = [
 ('build', consumer, ['taskset', '-c', '2,3', python, '-I', '-S', str(consumer / 'build_consumers.py'), '--library', '/tmp/oriole-frame-integrated-final/liboriole_expat.so', '--reference', '/tmp/oriole-verified-builds/published/liboriole_expat.so', '--expat', '/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4', '--source', '/home/dev-user/.cache/oriole/upstream/cpython-3.12.13', '--header', '/home/dev-user/code/oss/oriole-frame-integration/include', '--output', str(consumer / 'consumers')]),
 ('preflight', consumer, ['taskset', '-c', '2', python, '-I', '-S', str(consumer / 'consumer_screen.py'), '--kind', 'python', '--phase', 'prepare', '--build', str(consumer / 'consumers/build.json'), '--input', manifest, '--output', str(consumer / 'screen')]),
 ('preflight', native, ['taskset', '-c', '3', python, '-I', '-S', str(native / 'native_screen.py'), 'preflight']),
]
report = {'status': 'incomplete', 'jobs': []}
try:
    for name, out, command in jobs:
        with (out / (name + '.log')).open('wb') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
        report['jobs'].append({'name': name, 'out': str(out), 'command': command, 'exit': result.returncode})
        print(name, str(out), result.returncode, flush=True)
        assert result.returncode == 0
    report['status'] = 'passed'
finally:
    (consumer / 'prepare.json').write_text(json.dumps(report, indent=2) + '\n')
