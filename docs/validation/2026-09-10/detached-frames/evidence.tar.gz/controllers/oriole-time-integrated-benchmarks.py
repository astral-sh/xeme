import json
import os
from pathlib import Path
import signal
import subprocess

python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
consumer = Path('/tmp/oriole-integrated-consumer-study')
native = Path('/tmp/oriole-integrated-native-study')
jobs = [
 (consumer, ['taskset', '-c', '0', python, '-I', '-S', str(consumer / 'consumer_screen.py'), '--kind', 'python', '--phase', 'time', '--build', str(consumer / 'consumers/build.json'), '--input', '/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json', '--output', str(consumer / 'screen')]),
 (native, ['taskset', '-c', '0', python, '-I', '-S', str(native / 'native_screen.py'), 'time']),
]
report = {'status': 'incomplete', 'jobs': [], 'scope': 'Reviewed final9277 normal candidate against fresh4b published and pinned Expat; all fixed conditions retained. CPU0 reserved. No failed cohort rerun or sample exclusion.'}
def save():
    Path('/tmp/oriole-integrated-timing-controller.json').write_text(json.dumps(report, indent=2) + '\n')
try:
    for output, command in jobs:
        item = {'output': str(output), 'command': command, 'status': 'running'}
        report['jobs'].append(item)
        save()
        with (output / 'time.log').open('wb') as log:
            process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            try:
                item['exit'] = process.wait(timeout=1800)
            except BaseException as error:
                item['error'] = repr(error)
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                raise
        item['status'] = 'passed' if item['exit'] == 0 else 'failed'
        save()
        print(str(output), item['exit'], flush=True)
        assert item['exit'] == 0
    report['status'] = 'passed'
finally:
    save()
