"""Fresh, isolated intermediate builds for four frozen parser sources."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

output = Path('/tmp/oriole-verified-builds')
output.mkdir(exist_ok=False)
variants = {
    'e439': ('/home/dev-user/code/oss/oriole-tag-frame', 'tag-frame-target',
             '/tmp/oriole-e439-no-ohm-defaults/source.json'),
    'ns': ('/home/dev-user/code/oss/oriole-ns-tag-plan', 'ns-tag-plan-target',
           '/tmp/oriole-ns-tag-plan-study/source.json'),
    'coalesced': ('/home/dev-user/code/oss/oriole-ns-coalesced', 'ns-coalesced-target',
                  '/tmp/oriole-ns-coalesced-study/source.json'),
    'published': ('/home/dev-user/code/oss/oriole-verified-published', 'verified-published-target',
                  '/tmp/oriole-version-final/source.json'),
}
overrides = {
    'CARGO_HOME': '/home/dev-user/.cache/toucan/cargo',
    'CARGO_BUILD_BUILD_DIR': '/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}',
    'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST': 'all',
    'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST': 'all',
    'CARGO_BUILD_JOBS': '2',
    'CARGO_INCREMENTAL': '0',
    'RUSTC_WRAPPER': '',
    'RUSTC_WORKSPACE_WRAPPER': '',
    'RUSTFLAGS': '',
    'CARGO_ENCODED_RUSTFLAGS': '',
}
report = {'status': 'incomplete', 'method': 'One stable shared build-root template with manifest-path hash isolates ordinary Cargo intermediates per worktree. No old shared-cache deletion. All source mtimes advanced without byte changes; all three workspace crate compiler invocations required per variant. No PGO or timing.', 'variants': {}}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save():
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


try:
    for name, (directory, target, manifest) in variants.items():
        root = Path(directory)
        destination = output / name
        destination.mkdir()
        source = json.loads(Path(manifest).read_text())['source_sha256']
        assert all(digest(root / n) == h for n, h in source.items()), name
        source_record = {'source_sha256': source, 'source_manifest': manifest,
                         'manifest_sha256': digest(Path(manifest)), 'worktree': directory}
        (destination / 'source.json').write_text(json.dumps(source_record, indent=2) + '\n')
        with tarfile.open(destination / 'source.tar.gz', 'w:gz') as archive:
            for filename in source:
                archive.add(root / filename, arcname=filename, recursive=False)
        for filename in source:
            os.utime(root / filename, None)
        environment = overrides | {'CARGO_TARGET_DIR': '/home/dev-user/.cache/oriole/' + target}
        command = ['taskset', '-c', '2,3', 'cargo', '+ohm', '-Zohm-defaults=no', 'build',
                   '--release', '--locked', '-p', 'oriole_expat', '-vv']
        item = {'status': 'incomplete', 'command': command, 'env_overrides': environment,
                'worktree': directory, 'source_manifest_sha256': digest(destination / 'source.json')}
        report['variants'][name] = item
        save()
        with (destination / 'build.log').open('wb') as log:
            run = subprocess.run(command, cwd=root, env=os.environ | environment,
                                 stdout=log, stderr=subprocess.STDOUT)
        item['exit'] = run.returncode
        assert run.returncode == 0, name
        log = (destination / 'build.log').read_text()
        invocations = [line.strip() for line in log.splitlines()
                       if 'Running' in line and '/rustc ' in line]
        workspace = [line for line in invocations if 'CARGO_MANIFEST_DIR=' + directory + '/' in line]
        assert len(workspace) == 3, (name, len(workspace))
        for crate in ['oriole_storage', 'oriole', 'oriole_expat']:
            assert sum('--crate-name ' + crate + ' ' in line for line in workspace) == 1
        (destination / 'workspace-compiler-invocations.json').write_text(json.dumps(workspace, indent=2) + '\n')
        item['workspace_compilations'] = 3
        item['libraries'] = {}
        for library in ['liboriole_expat.so', 'liboriole_expat.a']:
            shutil.copy2(Path(environment['CARGO_TARGET_DIR']) / 'release' / library,
                         destination / library)
            item['libraries'][library] = digest(destination / library)
        assert all(digest(root / n) == h for n, h in source.items()), name
        item['source_unchanged'] = True
        item['status'] = 'passed'
        save()
        print(name, json.dumps(item['libraries']), flush=True)
    report['status'] = 'passed'
finally:
    save()
