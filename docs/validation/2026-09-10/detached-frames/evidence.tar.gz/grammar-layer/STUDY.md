# Shared complete and incremental tag grammar

**Local commit:** `ebb9aefd566ad7178b6b869aefdfc231ad45e4e1`  
**Parent:** `db5a86719e0985d3794342dde5463191f66f4f2d`  
**Branch:** `charlie/codex-oriole-shared-tag-grammar`

The first stack layer shares attribute grammar between complete tokens and an
incremental start-tag plan. The plan stores offsets in the parser's existing
attribute-record capacity. It never reserves space while a token is incomplete.
If syntax, encoding, resource bounds, or available capacity disqualify the plan,
the existing scanner handles that token. Fallback stays disabled for the rest of
the token, preventing repeated prefix scans across tiny feeds.

Successful plans provide validated name and attribute ranges to the existing
owned-event parser. Namespace mode remains excluded from incremental planning.
No detached frame, C dispatch, character-data storage, or newline-policy change
is included. The public Rust event API and C interface remain unchanged.

## Source and review

Only three core files change: `encoding.rs`, `lib.rs`, and the new `tag.rs`.
The source derives from the independently reviewed grammar prototype, with its
later grammar-only test refinements, one additional persistent-fallback
regression, and a Source accessor doc comment. The latest published entity error
origin and DTD reparse-deferral fixes remain intact.

`source.json` and `source.tar.gz` freeze 66 source/build inputs; `commit.patch`
records the exact committed diff. The worktree was clean and all source hashes
matched after validation. `root-independent-review.json` contains independent
source review, with no blocker found in planner bounds, fallback persistence,
validation/error precedence, or preservation of the published fixes.

## Build provenance

All Cargo commands used Ohm with `-Zohm-defaults=no`. Ordinary intermediates were
isolated through the stable template
`/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}` and a distinct
worktree target. The release log records actual compiler invocations for all
three workspace crates. Wrappers and Rust flags were explicitly cleared, and
incremental compilation was disabled. No old shared-cache output was used as the
candidate library.

- Shared library: `90ebe35ac5c07acb420e9f0a021545d5ac9645625e56c0203cd3e97bce6a0d99`
- Static library: `b2f8c20e8571ec4563f3afc242efaeb0e5b5ecf23c4e5368ace214519cfd3215`
- Behavioral baseline: latest published `db5a867` library `85066b10`.

The baseline is used for behavioral comparison, not compiler-matched performance
attribution. This standalone grammar layer makes no performance claim.

## Validation

| Gate | Result |
| --- | --- |
| Workspace tests, all targets | 377 pass |
| Formatting and strict Clippy | Pass |
| Strict deterministic callback/status/error/position comparison | 1,518 cases, zero differences from the published baseline |
| Cold/warm tag, name, encoding, and per-feed oracle | 186,348 conditions, zero differences from the published baseline |
| Expat final acceptance and successful final element events in that oracle | Zero differences |
| Original Expat public API configurations | 4,347 pass, 393 fail; all 4,740 outcomes unchanged |

The complete original API results JSON is byte-identical to the published
baseline, SHA-256
`dcda1affc7cfa69d1e77dd60b7c76360e572e2a7767d6d4ded084ab1575647d5`.
The 393 existing failures remain failures. No public upstream assertions were
modified or waived; pre-existing exclusions remain limited to tests of Expat
implementation-private details.

The tag oracle includes nonfinal feeds, warm and cold record capacity, malformed
decoder prefixes, UTF-16, namespace/name cases, and complete start/end payloads.
It compares per-feed status, error, byte index, line, column, and delivered
callback prefix. Existing Expat diagnostic and fragmentation/position differences
remain separately recorded: 117,517 conditions differ in exact traces, while
final acceptance and successful final element payloads agree.

The unit oracles compare the shared attribute scanner with the original grammar,
exercise token limits and every selected split/capacity combination, check that
accepted name characters are valid XML characters for both supported name
editions, and verify that cold fallback cannot restart until the source advances.
Existing selected-allocator and resource-limit suites also ran in the workspace
test gate.

## Retained setup failure

The first copied upstream harness omitted its required `runner.c` helper. That
attempt failed before executing any API configurations. Its original partial
directory, traceback, and controller record remain preserved; the latter still
shows its last pre-exception running state. `upstream-api-initial-failure.json`
classifies the setup failure. The exact missing helper was copied from the same
worktree, and the complete run is under `upstream-api-retry/`.

`summary.json` and `api-comparison.json` are the completed validation summaries.
The failed setup attempt is not counted as a parser failure or a successful API
run. Parser source was unchanged between attempts.

## Scope limits

This layer did not add a standalone benchmark, rerun the full CPython suites, or
rerun the C sanitizer corpus. The later combined frame integration must validate
its own exact source and library, retain original compatibility failures, and
measure all representative benchmark conditions against matched fresh controls.
No push or publication was performed by this subtask.
