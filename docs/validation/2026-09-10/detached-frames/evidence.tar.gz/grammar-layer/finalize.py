"""Verify and summarize the completed grammar-only PR validation."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

root = Path(__file__).parent
worktree = Path('/home/dev-user/code/oss/oriole-shared-tag-grammar')
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
baseline_path = Path('/tmp/oriole-dtd-reparse-integrated/upstream-api/results.json')
candidate_path = root / 'upstream-api-retry/results.json'
baseline = json.loads(baseline_path.read_text())
candidate = json.loads(candidate_path.read_text())
assert candidate['selection_complete'] and candidate['library_origin_verified']
assert not candidate['timed_out']
assert len(candidate['results']) == len(baseline['results']) == 4740
key = lambda row: (row['context'], row['test'])
before = {key(row): row for row in baseline['results']}
changes = [{'before': before[key(row)], 'after': row} for row in candidate['results'] if row != before[key(row)]]
assert not changes, changes
api = {'status': 'all_original_outcomes_unchanged', 'configurations': 4740,
       'baseline': {'passed': baseline['passed'], 'failed': baseline['failed'], 'results_sha256': digest(baseline_path)},
       'candidate': {'passed': candidate['passed'], 'failed': candidate['failed'], 'results_sha256': digest(candidate_path)},
       'changes': changes, 'original_suite_exit': candidate['returncode'],
       'scope': 'Original public assertions retained; the baseline 393 failures remain failures. The first attempt did not execute tests because its copied harness omitted runner.c; the complete retry is recorded separately.'}
(root / 'api-comparison.json').write_text(json.dumps(api, indent=2) + '\n')
source = json.loads((root / 'source.json').read_text())
assert all(digest(worktree / name) == expected for name, expected in source['source_sha256'].items())
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=worktree)
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip()
assert commit == 'ebb9aefd566ad7178b6b869aefdfc231ad45e4e1'
(root / 'commit.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', 'db5a867', commit], cwd=worktree))
counts = [int(n) for n in re.findall(r'test result: ok\. (\d+) passed', (root / 'tests.log').read_text())]
assert sum(counts) == 377
strict = json.loads((root / 'strict-traces/summary.json').read_text())
warm = json.loads((root / 'warm-tag-fuzz.json').read_text())
assert strict['cases'] == 1518 and strict['exact_pass']
assert warm['cases'] == 186348 and warm['baseline_differences'] == 0
assert warm['reference_fields']['final_acceptance'] == 0
assert warm['reference_fields']['successful_final_events'] == 0
validation = json.loads((root / 'validation.json').read_text())
assert validation['status'] == 'passed' and validation['workspace_compilations'] == 3
assert all(digest(root / name) == expected for name, expected in validation['libraries'].items())
summary = {
    'status': 'ready_for_parent_review_and_stack_integration',
    'commit': commit, 'base': source['base_commit'], 'branch': source['branch'],
    'source_json_sha256': digest(root / 'source.json'), 'source_files': len(source['source_sha256']),
    'source_unchanged': True, 'worktree_clean': True,
    'libraries': validation['libraries'],
    'rust': {'passed': sum(counts), 'groups': len(counts), 'fmt_exit': 0, 'strict_clippy_exit': 0},
    'strict': {'cases': 1518, 'differences': 0},
    'warm_tag_oracle': {'cases': 186348, 'baseline_differences': 0, 'expat_final_acceptance_differences': 0,
                        'expat_successful_final_event_differences': 0,
                        'existing_expat_exact_trace_differences': warm['reference_exact_differences']},
    'api': api,
    'independent_review_sha256': digest(root / 'root-independent-review.json'),
    'limitations': 'No standalone performance claim, no new CPython suite or C sanitizer run. This PR changes grammar/planning only; final frame integration requires its own exact source gates and matched benchmarks. Existing diagnostic/position differences and 393 original API failures are retained.'
}
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'status': summary['status'], 'commit': commit, 'api': api['candidate']}))
