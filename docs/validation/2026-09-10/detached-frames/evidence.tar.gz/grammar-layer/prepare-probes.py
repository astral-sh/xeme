"""Freeze existing comparison tools with the standalone grammar library paths."""
import difflib
import hashlib
import json
import shutil
from pathlib import Path

root = Path(__file__).parent
worktree = Path('/home/dev-user/code/oss/oriole-shared-tag-grammar')
tools = root / 'probe-tools'
tools.mkdir(exist_ok=True)
for name in ['differential.py', 'xml_abi.py', 'corpus.py']:
    shutil.copy2(worktree / 'tools' / name, tools / name)
shutil.copy2(worktree / 'tools/upstream-expat/run.py', tools / 'upstream-expat.py')
for name in ['bridge.h', 'bridge.c']:
    shutil.copy2(worktree / 'tools/upstream-expat' / name, tools / name)
parent = Path('/tmp/oriole-tag-frame-prototype/arena/warm_tag_fuzz.py')
original = parent.read_text()
text = original.replace('/home/dev-user/code/oss/oriole/tools', str(tools))
text = text.replace("root=Path('/tmp/oriole-tag-frame-prototype/arena')", f'root=Path({str(root)!r})')
text = text.replace("root/'control.so'", "Path('/tmp/oriole-dtd-reparse-final/liboriole_expat.so')")
(root / 'warm_tag_fuzz.py').write_text(text)
(root / 'probe-harness.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile='a/warm_tag_fuzz.py', tofile='b/warm_tag_fuzz.py')))
files = [*sorted(path for path in tools.iterdir() if path.is_file()), root / 'warm_tag_fuzz.py', root / 'probe-harness.patch',
         Path('/tmp/oriole-dtd-reparse-final/liboriole_expat.so'),
         Path('/tmp/oriole-dtd-reparse-integrated/upstream-api/results.json'),
         Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4')]
(root / 'probe-inputs.json').write_text(json.dumps({str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}, indent=2) + '\n')
