"""Validate exact standalone grammar sources with private Cargo intermediates."""
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

root = Path(__file__).parent
source = json.loads((root / 'source.json').read_text())
worktree = Path(source['worktree'])
target = Path('/home/dev-user/.cache/oriole/shared-tag-grammar-target')
overrides = {
    'CARGO_HOME': '/home/dev-user/.cache/toucan/cargo',
    'CARGO_TARGET_DIR': str(target),
    'CARGO_BUILD_BUILD_DIR': '/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}',
    'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST': 'all',
    'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST': 'all',
    'CARGO_BUILD_JOBS': '1',
    'CARGO_INCREMENTAL': '0',
    'RUSTC_WRAPPER': '',
    'RUSTC_WORKSPACE_WRAPPER': '',
    'RUSTFLAGS': '',
    'CARGO_ENCODED_RUSTFLAGS': '',
}
env = os.environ | overrides
assert os.sched_getaffinity(0) == {6}
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
check_sources = lambda: all(digest(worktree / name) == expected for name, expected in source['source_sha256'].items())
assert check_sources()
report = {'status': 'running', 'env_overrides': overrides, 'commands': [],
          'source_json_sha256': digest(root / 'source.json'),
          'rustc': subprocess.check_output(['rustc', '+ohm', '-Vv'], text=True)}
steps = [
    ('fmt', ['fmt', '--all', '--', '--check']),
    ('tests', ['test', '--workspace', '--all-targets', '--locked']),
    ('clippy', ['clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('release', ['build', '--release', '--locked', '-p', 'oriole_expat', '-vv']),
]
try:
    for name, args in steps:
        command = ['cargo', '+ohm', '-Zohm-defaults=no', *args]
        with (root / f'{name}.log').open('w') as log:
            result = subprocess.run(command, cwd=worktree, env=env, stdout=log, stderr=subprocess.STDOUT)
        report['commands'].append({'name': name, 'command': command, 'exit': result.returncode,
                                   'log_sha256': digest(root / f'{name}.log')})
        (root / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
        assert result.returncode == 0, name
        assert check_sources(), 'source changed during validation'
    invocations = [line for line in (root / 'release.log').read_text().splitlines()
                   if 'Running `' in line and any(f'--crate-name {crate} ' in line for crate in ['oriole', 'oriole_storage', 'oriole_expat'])]
    assert len(invocations) == 3, invocations
    (root / 'workspace-compiler-invocations.json').write_text(json.dumps(invocations, indent=2) + '\n')
    report['workspace_compilations'] = len(invocations)
    report['libraries'] = {}
    for name in ['liboriole_expat.so', 'liboriole_expat.a']:
        shutil.copy2(target / 'release' / name, root / name)
        report['libraries'][name] = digest(root / name)
    report['status'] = 'passed'
finally:
    report['source_unchanged'] = check_sources()
    if report['status'] != 'passed':
        report['status'] = 'failed'
    (root / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'libraries': report.get('libraries')}))
