"""Audit saved compatibility and native sanitizer evidence; never run a parser."""
import base64
import gzip
import hashlib
import itertools
import json
import re
import subprocess
from collections import Counter
from pathlib import Path

OUT=Path(__file__).parent
G=Path('/tmp/oriole-frame-integrated-gates')
S=Path('/tmp/oriole-frame-integrated-supplemental')
N=Path('/tmp/oriole-frame-integrated-c-sanitizers')
W=Path('/home/dev-user/code/oss/oriole-frame-integration')
hashes={}
def read(p):
    p=Path(p);data=p.read_bytes();hashes[str(p)]=hashlib.sha256(data).hexdigest();return data
def sha(p):read(p);return hashes[str(Path(p))]
def load(p):return json.loads(read(p))
controller=load(G/'controller.json')
for p,h in controller['libraries'].items():assert sha(p)==h
assert [j['exit'] for j in controller['jobs']]==[1,0,2,2]
assert all(j['status']=='completed' and j['expected_exit']==j['exit'] for j in controller['jobs'])
assert not any('--allow-text-fragmentation' in j['command'] or '--consumer-fix' in j['command'] for j in controller['jobs'])
assert sha('/tmp/oriole-frame-cleanup-independent-review/build-review.json')=='f01285c18cfe7008b925740dbbaa9ed7404a02ba75ac377f20f95e5cc59f2786'

# Original public C tests: reconstruct every row from stdout and compare the
# complete saved result, selection and resource settings with latest baseline.
A=G/'upstream-api';B=Path('/tmp/oriole-dtd-reparse-integrated/upstream-api')
api=load(A/'results.json');manifest=load(A/'manifest.json');prior=load(B/'manifest.json')
assert read(A/'results.json')==read(B/'results.json')
assert [k for k in manifest if manifest[k]!=prior.get(k)]==['library_sha256','compile_command','binary_sha256']
assert manifest['per_test_seconds']==3 and manifest['per_test_address_space_bytes']==1073741824 and manifest['per_test_rss_limit_bytes']==805306368 and manifest['total_timeout_seconds']==240
assert manifest['chunks']==[0,1,2,3,4,5] and manifest['deferral']==[0,1] and manifest['selected_tests'] is None
assert api['returncode']==1 and api['selection_complete'] and api['library_origin_verified'] and not api['timed_out']
assert len(api['results'])==4740 and api['passed']==4347 and api['failed']==393
log=read(A/'tests.log').decode();parsed=[]
for line in log.splitlines():
    if line.startswith('ORIOLE_RESULT\t'):
        _,context,test,outcome,code=line.split('\t');parsed.append({'context':context,'test':test,'outcome':outcome,'code':int(code)})
assert parsed==api['results'] and len({(r['context'],r['test']) for r in parsed})==4740
assert Counter(r['outcome'] for r in parsed)=={'pass':4347,'fail':393}
assert 'ORIOLE_LIBRARY\t'+str(A/'liboriole_expat.so') in log
assert sha(A/'liboriole_expat.so')==manifest['library_sha256']==controller['libraries']['/tmp/oriole-frame-integrated-final/liboriole_expat.so']
assert sha(A/'runtests')==manifest['binary_sha256']
for name,h in manifest['adapted_sources'].items():assert sha(A/'adapted'/name)==h
for name,h in manifest['upstream_include_sources'].items():assert sha(A/name)==h
for name,h in manifest['adapter_sources'].items():assert sha(W/'tools/upstream-expat'/name)==h
read(A/'build.log')

# Full strict corpus retains both workers' results rather than only a summary.
D=G/'strict';d=load(D/'summary.json');corpus=load(D/'corpus.json');left=load(D/'reference.json');right=load(D/'oriole.json')
assert d['cases']==len(corpus)==len(left['results'])==3318 and left==right
assert d['status']=='passed' and d['exact_pass'] and d['semantic_pass'] and not d['differences'] and all(v==0 for v in d['difference_counts'].values())
for case,row in zip(corpus,left['results']):
    assert hashlib.sha256(base64.b64decode(case['base64'])).hexdigest()==case['sha256']
    assert case['name']==row['name'] and case['chunk_size']==row['chunk_size']
for record in d['libraries'].values():
    assert record['returncode']==0 and not record['stderr'] and record['sha256_before']==record['sha256_after']==sha(record['path'])
read(W/'tools/differential.py')

def methods(path):
    output={};pending=None;subtests=[]
    def add(item,status):
        name,identifier=item
        if name=='setUpClass':return
        assert name.startswith('test') and identifier not in output
        output[identifier]=status
    for line in read(path).decode().splitlines():
        m=re.match(r'^(\w+) \((test\.[^)]+)\)(?: \.\.\. (.*))?$',line)
        if m:
            if pending is not None:
                assert any(f'{pending[0]} ({pending[1]}) ' in t for t in subtests);add(pending,'subtest outcomes')
            pending=(m[1],m[2]);status=m[3]
            if status:add(pending,status);pending=None
        elif pending is not None:
            if re.match(r'^(ok|FAIL|ERROR|expected failure|skipped .+)$',line):add(pending,line);pending=None
            elif line.startswith('  ') and ' ... ' in line:subtests.append(line)
            elif ' ... ' in line and line.rsplit(' ... ',1)[1]:add(pending,line.rsplit(' ... ',1)[1]);pending=None
    assert pending is None
    return output

expected_failures=['test.test_pyexpat.BufferTextTest.test1','test.test_sax.CDATAHandlerTest.test_handlers']
baseline_methods=methods('/tmp/oriole-c-text-boundaries-evidence/cpython-fresh-frozen/baseline-shared/tests.log')
python={}
for linkage in ['shared','static']:
    p=G/('cpython-'+linkage);summary=load(p/'summary.json');origin=load(p/'origin.log')
    assert summary['linkage']==linkage and summary['tests_exit_code']==summary['gate_exit_code']==2
    assert summary['probe_exit_code']==summary['origin_exit_code']==0 and summary['consumer_fix'] is None and summary['consumer_adaptation'] is None and summary['text_fragmentation'] is None
    assert summary['cpython_revision']=='3bb231a6a5dc02b95658877318bf61501a7209e9'
    assert summary['source_sha256']==summary['compiled_source_sha256']==sha(p/'pyexpat.c')==sha('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Modules/pyexpat.c')
    suffix='so' if linkage=='shared' else 'a';assert sha(p/('liboriole_expat.'+suffix))==summary['library_sha256']==controller['libraries']['/tmp/oriole-frame-integrated-final/liboriole_expat.'+suffix]
    assert summary['loader_sha256']==sha(p/'sitecustomize.py')==sha(W/'tools/cpython/extension_loader.py')
    assert summary['import_check_sha256']==sha(W/'tools/cpython/check_extension_imports.py')
    assert origin['status']=='passed' and origin['accelerator_imports']==['cET','cET_alias'] and origin['pure_python_and_blocked_imports']=='passed' and len(origin['origins'])==4
    for entry in origin['origins'].values():assert Path(entry['path']).parent==p and sha(entry['path'])==entry['sha256']
    rows=methods(p/'tests.log');assert len(rows)==802 and rows==baseline_methods
    assert sorted(k for k,v in rows.items() if v in ['FAIL','ERROR'])==expected_failures
    assert sum(v.startswith('skipped') for v in rows.values())==5 and sum(v=='expected failure' for v in rows.values())==3
    skip=[l for l in read(p/'tests.log').decode().splitlines() if ' ... skipped ' in l]
    assert len(skip)==14 and sum(l.startswith('  ') for l in skip)==8 and sum(l.startswith('setUpClass') for l in skip)==1
    for name in ['test_correct_import_cET','test_correct_import_cET_alias','test_parser_comes_from_C']:assert rows['test.test_xml_etree_c.TestAcceleratorImported.'+name]=='ok'
    for name in ['probe.log','pyexpat-build.log','_elementtree-build.log']:read(p/name)
    python[linkage]={'methods':802,'failures':expected_failures,'expected_failures':3,'reported_skips':14,'whole_method_skips':5,'subtest_skips':8,'class_setup_skips':1,'all_method_statuses_equal_corrected_baseline':True}
old_cpython=load('/tmp/oriole-pbs-version-followup/report.json')['test_count_and_coverage']['upstream_six_module_hashes_exact']
for name,h in old_cpython.items():assert sha(Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Lib/test')/(name+'.py'))==h
read(W/'tools/cpython/run.py');read(W/'tools/cpython/text_fragmentation.py')

# Recreate malformed fixture enumeration/hashes only; matching complete worker
# outputs were compared by the owner but are not individually stored here.
malformed=load(S/'malformed-probe.json');cases=[]
for prefix,tail in itertools.product(['','a','a\n','a\r','a\r\n','\n\n','\r\r','\ré\n'],['bad]]>','bad]]>\x01','\x01]]>',']\n]>','a\x01',']]','a\r\nb',']]><n/>']):
    for internal in [False,True]:
        xml=f"<!DOCTYPE r [<!ENTITY e '{prefix}{tail}'>]><r>&e;</r>" if internal else f'<r>{prefix}{tail}</r>'
        cases.append((xml,[1,2,3,7,64,4096,len(xml.encode())]))
for size,newline,tail in itertools.product([65532,65535,65536,65537,70000],['\n','\r','\r\n'],[']]>','\x01]]>','bad]]>\x01','ok']):cases.append(('<r>a\n'+'x'*(size-2)+newline+tail+'</r>',[65533,65535,65536,65537,200000]))
expected=[(hashlib.sha256(xml.encode(enc)).hexdigest(),enc,chunk) for xml,chunks in cases for enc in ['utf-8','utf-16'] for chunk in sorted(set(chunks))]
assert len(expected)==malformed['cases']==2392 and not malformed['differences']
assert [(r['sha256'],r['encoding'],r['chunk']) for r in malformed['rows']]==expected and all(not r['fields'] for r in malformed['rows'])
for file in ['malformed_probe.py','coordinate_comparison.py','harness.patch']:read(S/file)
read('/tmp/oriole-ns-coalesced-study/trace-tools/xml_abi.py')

coords=load(S/'coordinate-comparison.json');assert len(coords['rows'])==48 and len(coords['published_comparisons'])==16
traces={};coordinate_discrepancies=Counter()
xml='<r>'+'a\r\nb\nc\rdé😀'*1200+'&amp;z\r\n</r>'
for row in coords['rows']:
    assert sha(S/row['trace'])==row['trace_sha256'];trace=json.loads(gzip.decompress(read(S/row['trace'])))
    data=xml.encode('utf-16' if row['utf16'] else 'utf-8');differences=[];raws=[]
    for index,count,line,column,value in trace:
        prefix=data[:index].decode('utf-16' if row['utf16'] else 'utf-8').replace('\r\n','\n').replace('\r','\n')
        expected=[prefix.count('\n')+1,len(prefix.rsplit('\n',1)[-1])]
        if [line,column]!=expected:differences.append({'index':index,'count':count,'observed':[line,column],'expected_from_raw_prefix':expected})
        raw=data[index:index+count].decode('utf-16-le' if row['utf16'] else 'utf-8');raws.append(raw)
        assert value==('&' if raw=='&amp;' else raw.replace('\r\n','\n').replace('\r','\n'))
    values=''.join(t[4] for t in trace);assert values=='a\nb\nc\ndé😀'*1200+'&z\n'
    assert row['text_bytes']==len(values.encode()) and row['suspends']==len(trace) and row['handler_switched_after_first_event']
    assert row['raw_sha256']==hashlib.sha256(''.join(raws).encode()).hexdigest() and row['coordinate_differences']==differences
    traces[row['library'],row['utf16'],row['chunk']]=trace;coordinate_discrepancies[row['library']]+=len(differences)
for comparison in coords['published_comparisons']:
    assert comparison['exact_callback_positions_and_payloads']
    assert traces['published',comparison['utf16'],comparison['chunk']]==traces['candidate',comparison['utf16'],comparison['chunk']]

supplement=load(S/'controller.json');san=load(N/'controller.json')
assert supplement['status']=='incomplete' and [j['exit'] for j in supplement['jobs']]==[0]*11+[-6]
initial=read(S/'integration-sanitized.log').decode();assert 'LeakSanitizer has encountered a fatal error' in initial and 'does not work under ptrace' in initial
assert san['status']=='passed' and len(san['jobs'])==6 and all(j['exit']==0 for j in san['jobs'])
assert san['env_overrides']=={'ASAN_OPTIONS':'detect_leaks=1:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
assert supplement['jobs'][-1]['env_overrides']==san['env_overrides']
binary_inspection={}
for name in ['integration','adversarial','allocations']:
    src=W/'tests/c'/(name+'.c');read(src)
    # Existing test source is unchanged from the integration base.
    expected_src=subprocess.run(['git','-C',str(W),'show','db5a86719e0985d3794342dde5463191f66f4f2d:tests/c/'+name+'.c'],capture_output=True,check=True).stdout
    assert read(src)==expected_src
    build=next(j for j in san['jobs'] if j['source']==name and j['phase']=='build')
    assert '-fsanitize=address,undefined' in build['command'] and '-fno-omit-frame-pointer' in build['command'] and '-no-pie' in build['command']
    assert str(src) in build['command'] and '/tmp/oriole-frame-integrated-final/liboriole_expat.so' in build['command']
    for file in [name+'-build.log',name+'-run.log',name]:read(N/file)
    assert not read(N/(name+'-build.log'))
    native=read(S/(name+'-native.log')).decode();sanlog=read(N/(name+'-run.log')).decode();assert native==sanlog and 'passed' in sanlog
    if name=='allocations':assert '327 scenarios' in sanlog
    dynamic=subprocess.run(['readelf','-d',str(N/name)],capture_output=True,check=True).stdout.decode()
    symbols=subprocess.run(['readelf','--dyn-syms','--wide',str(N/name)],capture_output=True,check=True).stdout.decode()
    assert 'Shared library: [/tmp/oriole-frame-integrated-final/liboriole_expat.so]' in dynamic and 'libasan.so' in dynamic and 'libubsan.so' in dynamic
    assert '__asan_init' in symbols and '__ubsan_handle' in symbols
    binary_inspection[name]={'dynamic':dynamic,'symbols':symbols,'sha256':sha(N/name)}
    read(S/(name+'-native-build.log'));read(S/(name+'-native'))
for label in ['shared','static']:
    log=read(S/('semantic-'+label+'.log')).decode();assert 'Ran 2 tests' in log and log.endswith('\nOK\n') and log.count(' ... ok')==2
for path in [*G.glob('*.log'),*S.glob('*.log')]:read(path)
read(W/'include/expat.h')
(OUT/'native-binary-inspection.json').write_text(json.dumps(binary_inspection,indent=2)+'\n')
review={
    'status':'passed_with_original_failures_retained','findings':[],
    'scope':'Independent saved-data, source/hash and binary linkage/sanitizer-symbol audit. No parser executions, tests, builds or new measurements by reviewer.',
    'api':{'rows':4740,'passed':4347,'failed':393,'byte_exact_latest_results':True,'seconds_per_test':3,'address_space_bytes':1073741824,'rss_bytes':805306368,'total_timeout_seconds':240,'unchanged_selection_and_adapted_sources':True},
    'strict_differential':{'cases':3318,'all_stored_worker_results_equal':True,'reference_library':'85066b10a1c5b4613c9d98012c8c9c2f8285e90b9dc01fa395297097c78193c5','scope':'Exact comparison to latest Oriole baseline, not proof of exact agreement with Expat.'},
    'cpython':python,
    'supplemental':{'malformed_fixture_comparisons':2392,'recorded_malformed_differences':0,'coordinate_rows':48,'exact_latest_coordinate_comparisons':16,'retained_raw_prefix_coordinate_discrepancies_by_library':dict(coordinate_discrepancies),'separate_semantic_checks_per_linkage':2,'native_unsanitized_consumers':3,'native_sanitized_consumers':3,'allocation_scenarios_per_allocation_driver':327},
    'sanitizer_scope':{'initial_status':'LSan fatal ptrace environment error, process -6; controller remains incomplete and raw error retained','retry_status':'Three C ASan/UBSan consumers completed with detect_leaks=1; six build/run exits zero, matched absolute Rust-library dependency and sanitizer symbols verified. Owner records execution outside ptrace sandbox.','instrumented':'C consumers; normal optimized Rust code is not ASan/UBSan-instrumented','linkage':'All native C runs in this evidence use shared Rust library. Static linkage is covered here by CPython, not an additional three native C sanitizer runs.'},
    'limitations':[
        'Original C API393 failures and both CPython newline-grouping failures remain visible. Separate semantic checks do not waive or turn the unchanged strict suites green.',
        '14 CPython skips are five complete methods, eight subtests and one class setup; fresh accelerated ElementTree import checks pass. Three expected Pulldom failures are separate from the two unexpected failures.',
        'Matching malformed worker outputs are not individually archived; their fixture identities/counts and zero-difference record are reconstructed, while source shows complete callback/status/error/location comparisons. Unlike strict corpus and coordinate traces, these matching full streams cannot be independently re-compared from saved data alone.',
        'Coordinate traces permit raw/payload/position reconstruction; callback-time context availability, handler switches and suspension return statuses are owner-executed assertions, not individually archived API return records. Known ideal raw-prefix coordinate discrepancies remain reported.',
        'Sanitizer runtime environment and successful exits come from the retained controller/logs; ELF evidence proves linked instrumentation and exact absolute library dependency, not a new reviewer execution or proof of all possible memory behavior.',
    ],
    'libraries':controller['libraries'],'native_inspection_sha256':sha(OUT/'native-binary-inspection.json'),'artifacts_sha256':hashes,
}
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'status':review['status'],'review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'api':review['api'],'coordinates':dict(coordinate_discrepancies)}))
