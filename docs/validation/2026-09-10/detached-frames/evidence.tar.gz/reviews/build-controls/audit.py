"""Read-only audit of the preserved stale and forced Cargo rebuild receipts."""
from pathlib import Path
import hashlib
import json
import re
import shlex
import time

if not __debug__:
    raise RuntimeError("Audit requires assertions")

OUT = Path(__file__).resolve().parent
OLD = Path('/tmp/oriole-e439-no-ohm-defaults')
FORCED = Path('/tmp/oriole-e439-forced-rebuild')
SOURCE = Path('/home/dev-user/code/oss/oriole-tag-frame')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

old = json.loads((OLD / 'build.json').read_text())
new = json.loads((FORCED / 'build.json').read_text())
sources = json.loads((FORCED / 'source.json').read_text())
assert len(sources) == 68
assert {n: row['sha256'] for n, row in sources.items()} == old['source_sha256']
assert all(sha(SOURCE / n) == row['sha256'] for n, row in sources.items())
assert all(row['new_mtime_ns'] > row['old_mtime_ns'] for row in sources.values())
old_log = (OLD / 'build.log').read_text()
new_log = (FORCED / 'build.log').read_text()
assert 'Compiling ' not in old_log and 'Running ' not in old_log
commands = []
for line in new_log.splitlines():
    if 'Running `' not in line:
        continue
    text = line.split('Running `', 1)[1].removesuffix('`')
    args = shlex.split(text)
    if '--crate-name' not in args:
        continue
    crate = args[args.index('--crate-name') + 1]
    if not crate.startswith('oriole'):
        continue
    expected = str(SOURCE / 'crates' / crate)
    assert 'CARGO_MANIFEST_DIR=' + expected in args
    assert 'CARGO_MANIFEST_PATH=' + expected + '/Cargo.toml' in args
    assert any(x.startswith('--emit=') and 'link' in x for x in args)
    assert not any('relink-only' in x or 'public-api-hash' in x for x in args)
    assert '--out-dir' in args
    commands.append({'crate': crate, 'argv': args, 'out_dir': args[args.index('--out-dir') + 1]})
assert [x['crate'] for x in commands] == ['oriole_storage', 'oriole', 'oriole_expat']
assert new['exit'] == old['exit'] == 0
assert new['source_unchanged'] and old['source_unchanged']
for root, manifest in [(OLD, old), (FORCED, new)]:
    for name, digest in manifest['libraries'].items():
        assert sha(root / name) == digest
assert old['libraries'] != new['libraries']
fingerprint = Path('/home/dev-user/.cache/ohm/build/release/.fingerprint/oriole-470164d35a849422/lib-oriole.json')
fingerprint_bytes = fingerprint.read_bytes()
fingerprint_data = json.loads(fingerprint_bytes)
assert any(row.get('CheckDepInfo', {}).get('checksum') is False for row in fingerprint_data['local'])
(OUT / 'observed-fingerprint.json').write_bytes(fingerprint_bytes)
docs = Path('/home/dev-user/.rustup/toolchains/ohm/share/doc/rust/html/cargo/reference')
report = {
    'status': 'passed',
    'scope': 'Read-only verification of retained source hashes, timestamps, build logs and libraries; no compilation, parsing, profiling or timing by reviewer.',
    'observed_unix': time.time(),
    'verified_source_files': len(sources),
    'full_workspace_rustc_commands': commands,
    'stale_attempt': {'path': str(OLD), 'libraries': old['libraries'], 'compiled_workspace_crates': 0},
    'forced_attempt': {'path': str(FORCED), 'libraries': new['libraries'], 'compiled_workspace_crates': 3},
    'findings': [
        'The same 68 source bytes produced a different library after all source mtimes advanced and three workspace crates actually compiled.',
        'Both invocations used the same shared old-layout intermediate directory despite private target directories. Cargo reports checksum=false for the retained ordinary fingerprint.',
        'The old attempt does not prove compilation of its source. Its identical coalesced artifact is retained as a stale-reuse observation.',
        'Advancing source mtimes fixes this serial diagnostic, but a new private intermediate directory per source variant is the stronger reproducibility boundary.',
        'Previously verified saved arithmetic and binary identity remain valid. Source-to-binary causality and claims about which source change caused a timing difference remain on hold until matched verified recompiles.'
    ],
    'limitations': [
        'The reviewer did not execute the rebuilds or observe their process working directory directly; retained CARGO_MANIFEST paths, full commands and source/library hashes were checked.',
        'The original target hardlink inode was reported by root before replacement and is not independently re-observed by this audit.',
        'No implication is made that every prior default-Ohm artifact is stale; each relevant source/build mapping needs its own evidence.'
    ],
    'evidence_sha256': {str(p): sha(p) for p in [OLD / 'build.json', OLD / 'build.log', FORCED / 'build.json', FORCED / 'build.log', FORCED / 'source.json', docs / 'config.html', docs / 'unstable.html', OUT / 'observed-fingerprint.json']},
}
(OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'review': str(OUT / 'review.json'), 'sha256': sha(OUT / 'review.json'), 'sources': len(sources), 'rustc_commands': len(commands)}))
