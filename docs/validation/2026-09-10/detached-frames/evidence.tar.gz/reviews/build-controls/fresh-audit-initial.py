"""Audit fresh compiler records, sources and finished artifacts without rebuilding."""
from pathlib import Path
import hashlib
import json
import re
import shlex
import subprocess
import tarfile

if not __debug__:
    raise RuntimeError('Audit assertions must run')

OUT = Path(__file__).resolve().parent
ROOT = Path('/tmp/oriole-verified-builds')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

report = json.loads((ROOT / 'report.json').read_text())
assert report['status'] == 'passed'
observed = {}
source_maps = {}
normalized = {}
private_dirs = set()
tools = set()
registry_roots = set()
artifact_hashes = {str(ROOT / 'report.json'): sha(ROOT / 'report.json')}

for name, item in report['variants'].items():
    r = ROOT / name
    source = json.loads((r / 'source.json').read_text())
    assert sha(r / 'source.json') == item['source_manifest_sha256']
    assert source['worktree'] == item['worktree']
    prior = Path(source['source_manifest'])
    assert sha(prior) == source['manifest_sha256']
    assert json.loads(prior.read_text())['source_sha256'] == source['source_sha256']
    m = source_maps[name] = source['source_sha256']
    assert len(m) == (65 if name == 'published' else 68)
    assert {n: sha(Path(item['worktree']) / n) for n in m} == m
    with tarfile.open(r / 'source.tar.gz', 'r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(m) and all(x.isfile() for x in members)
        assert {x.name: hashlib.sha256(archive.extractfile(x).read()).hexdigest() for x in members} == m
    assert item['exit'] == 0 and item['status'] == 'passed' and item['source_unchanged']
    log = (r / 'build.log').read_text()
    raw = re.findall(r'Running `(.*?)`\n', log, re.S)
    parsed = []
    for command in raw:
        argv = shlex.split(command)
        if '--crate-name' not in argv:
            continue
        compiler_index = next(i for i, x in enumerate(argv) if x.endswith('/bin/rustc'))
        env = dict(x.split('=', 1) for x in argv[:compiler_index])
        tools.add(argv[compiler_index])
        args = argv[compiler_index + 1:]
        crate = args[args.index('--crate-name') + 1]
        outdir = args[args.index('--out-dir') + 1]
        assert outdir.startswith('/home/dev-user/.cache/ohm/verified-build/')
        assert outdir.endswith('/release/deps')
        assert not any(x.startswith('--target') for x in args)
        assert not any(x.startswith('-Z') or 'incremental=' in x or 'profile-use' in x or 'profile-generate' in x for x in args)
        assert '--emit=dep-info,metadata,link' in args or '--emit=dep-info,link' in args
        if crate.startswith('oriole'):
            assert env['CARGO_MANIFEST_DIR'] == item['worktree'] + '/crates/' + crate
            assert env['CARGO_MANIFEST_PATH'] == item['worktree'] + '/crates/' + crate + '/Cargo.toml'
        else:
            registry_roots.add(env['CARGO_MANIFEST_DIR'])
        normalized_args = [x.replace(outdir, '<PRIVATE-DEPS>').replace(item['worktree'], '<SOURCE>') for x in args]
        parsed.append({'crate': crate, 'compiler': argv[compiler_index], 'environment': env, 'argv': args, 'normalized_argv': normalized_args, 'outdir': outdir})
    assert sorted(x['crate'] for x in parsed) == ['allocator_api2', 'hashbrown', 'memchr', 'oriole', 'oriole_expat', 'oriole_storage']
    assert len({x['outdir'] for x in parsed}) == 1
    private_dir = parsed[0]['outdir']
    assert private_dir not in private_dirs
    private_dirs.add(private_dir)
    normalized[name] = {x['crate']: x['normalized_argv'] for x in parsed}
    for library, digest in item['libraries'].items():
        assert sha(r / library) == digest
        assert sha(Path(private_dir) / library) == digest
        assert sha(Path(item['env_overrides']['CARGO_TARGET_DIR']) / 'release' / library) == digest
    for env_name in ['RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS']:
        assert item['env_overrides'][env_name] == ''
    assert item['env_overrides']['CARGO_INCREMENTAL'] == '0'
    comments = subprocess.check_output(['readelf', '-p', '.comment', str(r / 'liboriole_expat.so')], text=True)
    observed[name] = {'source_files': len(m), 'private_deps': private_dir, 'full_compilations': 6, 'workspace_compilations': 3, 'libraries': item['libraries'], 'elf_comment': comments, 'compiler_invocations': parsed}
    for file in ['source.json', 'source.tar.gz', 'build.log', 'workspace-compiler-invocations.json', 'liboriole_expat.so', 'liboriole_expat.a']:
        artifact_hashes[str(r / file)] = sha(r / file)

assert len(tools) == 1
assert all(x == normalized['e439'] for x in normalized.values())
assert all(x['command'] == report['variants']['e439']['command'] for x in report['variants'].values())
assert all(m['Cargo.lock'] == source_maps['e439']['Cargo.lock'] for m in source_maps.values())
assert all(m['Cargo.toml'] == source_maps['e439']['Cargo.toml'] for m in source_maps.values())
deltas = {}
for a, b in [('e439', 'ns'), ('ns', 'coalesced'), ('published', 'coalesced')]:
    deltas[a + '_to_' + b] = [n for n in sorted(set(source_maps[a]) | set(source_maps[b])) if source_maps[a].get(n) != source_maps[b].get(n)]
assert deltas['e439_to_ns'] == ['crates/oriole/src/lib.rs', 'crates/oriole/tests/adapter_frame.rs']
assert deltas['ns_to_coalesced'] == ['crates/oriole_expat/src/lib.rs']

dependencies = {}
for root in sorted(registry_roots):
    p = Path(root)
    checksums = json.loads((p / '.cargo-checksum.json').read_text())
    assert all(sha(p / n) == digest for n, digest in checksums['files'].items())
    dependencies[root] = {'files': len(checksums['files']), 'checksum_manifest_sha256': sha(p / '.cargo-checksum.json'), 'package_checksum': checksums['package']}

incident_path = Path('/tmp/oriole-section-inspection-incident.json')
incident = json.loads(incident_path.read_text())
for row in incident['restorations']:
    assert sha(Path(row['destination'])) == row['expected'] == row['restored_sha256']

compiler = Path(next(iter(tools)))
tool_metadata = {'rustc_path': str(compiler), 'rustc_resolved_path': str(compiler.resolve()), 'rustc_sha256': sha(compiler), 'rustc_version_observed_after_build': subprocess.check_output([str(compiler), '-vV'], text=True)}
cargo = Path('/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/bin/cargo')
tool_metadata.update({'cargo_path': str(cargo), 'cargo_sha256': sha(cargo)})
artifact_hashes[str(incident_path)] = sha(incident_path)
controller = Path('/tmp/oriole-verified-build-controller.py')
artifact_hashes[str(controller)] = sha(controller)
(OUT / 'fresh-build-details.json').write_text(json.dumps({'variants': observed, 'normalized_rustc_args': normalized['e439'], 'dependency_source_checksums': dependencies, 'tool_metadata': tool_metadata, 'source_deltas': deltas}, indent=2) + '\n')
result = {
    'status': 'passed',
    'scope': 'Read-only saved build/source/output audit; no compiler, parser, timing or profiler executions by reviewer. rustc -vV and readelf only inspect version/ELF metadata.',
    'variants': 4,
    'archived_and_live_source_file_entries': sum(len(m) for m in source_maps.values()),
    'full_rustc_invocations': 24,
    'full_workspace_rustc_invocations': 12,
    'distinct_private_intermediate_directories': sorted(private_dirs),
    'effective_rustc_arguments_match_after_only_private_path_normalization': True,
    'identical_manifest_and_lockfile': True,
    'source_deltas': deltas,
    'libraries': {name: item['libraries'] for name, item in report['variants'].items()},
    'conclusion': 'Fresh libraries are mapped to the intended four source variants. Every dependency and workspace crate compiled under distinct private intermediates with identical effective per-crate flags. These are suitable matched-build artifacts for new behavioral gates and measurements; prior source-causal benchmark claims are not retroactively repaired.',
    'limits': [
        'No Cargo compiler-artifact JSON was requested. Freshness proof here is the 24 complete verbose rustc invocations, 12 correct workspace paths, explicit link emission, private output hashes and exit-zero receipts.',
        'The controller has no built-in timeout/process-group cleanup and records environment overrides, not the entire inherited environment. All four actual invocations completed; source/output mappings were independently checked. Reusable tooling should retain bounded process cleanup.',
        'Compiler tool paths are recorded in the commands; hashes and rustc version were observed during this audit after the builds. The controller did not hash tools before invocation.',
        'Exact linker command is not captured by Cargo -vv. The four artifacts share the recorded ELF compiler/linker .comment strings; no linker override appears in effective rustc arguments.',
        'No behavioral equivalence, speedup, broad compatibility or adoption is established by this build audit.',
        'The earlier objcopy inspection mutation and initial failed hash audit remain separate evidence; both restored inputs now match their original expected hashes.'
    ],
    'details_sha256': sha(OUT / 'fresh-build-details.json'),
    'evidence_sha256': artifact_hashes,
}
(OUT / 'fresh-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'path': str(OUT / 'fresh-review.json'), 'sha256': sha(OUT / 'fresh-review.json'), 'sources': result['archived_and_live_source_file_entries'], 'compilations': result['full_rustc_invocations']}))
