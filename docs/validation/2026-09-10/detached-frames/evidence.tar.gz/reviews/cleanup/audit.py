"""Read-only source reconstruction and retained-check audit; no parser runs."""
import hashlib
import json
import re
import tarfile
from pathlib import Path

ROOT = Path('/tmp/oriole-frame-integration')
LIVE = Path('/home/dev-user/code/oss/oriole-frame-integration')
FINAL = Path('/tmp/oriole-frame-integrated-final')
OUT = Path(__file__).parent
observed = {}

def read(path):
    path = Path(path)
    data = path.read_bytes()
    observed[str(path)] = hashlib.sha256(data).hexdigest()
    return data

def load(path):
    return json.loads(read(path))

def archive(path, manifest):
    read(path)
    with tarfile.open(path) as tar:
        members = [m for m in tar if m.isfile()]
        assert len({m.name for m in members}) == len(members)
        result = {m.name: tar.extractfile(m).read() for m in members}
    assert set(result) == set(manifest), (set(result)-set(manifest),set(manifest)-set(result))
    for name, data in result.items():
        assert hashlib.sha256(data).hexdigest() == manifest[name], name
    return result

initial_manifest = load(ROOT/'source.json')['source_sha256']
initial = archive(ROOT/'source.tar.gz', initial_manifest)
clean_manifest = load(ROOT/'cleanup/source.json')['source_sha256']
clean = archive(ROOT/'cleanup/source.tar.gz', clean_manifest)
patch = read(ROOT/'cleanup/cleanup.patch').decode().splitlines(keepends=True)
changed = {}
i = 0
while i < len(patch):
    assert patch[i].startswith('--- a/')
    name = patch[i][6:].rstrip('\n')
    assert patch[i+1] == '+++ b/'+name+'\n'
    i += 2
    original = initial[name].decode().splitlines(keepends=True)
    result = []
    cursor = 0
    while i < len(patch) and patch[i].startswith('@@'):
        header = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n', patch[i])
        assert header
        start, old_n, new_start, new_n = (int(x) if x else 1 for x in header.groups())
        result.extend(original[cursor:start-1]); cursor = start-1
        assert len(result) == new_start-1
        i += 1; old_count = new_count = 0
        while i < len(patch) and not patch[i].startswith(('@@','--- a/')):
            op, line = patch[i][0], patch[i][1:]
            assert op in ' +-'
            if op != '+':
                assert original[cursor] == line, (name, cursor)
                cursor += 1; old_count += 1
            if op != '-':
                result.append(line); new_count += 1
            i += 1
        assert (old_count,new_count) == (old_n,new_n)
    result.extend(original[cursor:])
    changed[name] = ''.join(result).encode()
    assert changed[name] == clean[name], name
assert set(changed) == {'crates/oriole/src/lib.rs','crates/oriole/tests/text_coalescing.rs','crates/oriole_expat/src/tests.rs'}
assert {n for n in initial if initial[n]!=clean[n]} == set(changed)
name = 'crates/oriole/tests/text_coalescing.rs'
old = b'fn external_children_preserve_default_coalescing() {\n    let mut parent'
new = b'fn external_children_preserve_default_coalescing() {\n    let parent'
assert clean[name].count(old) == 1
expected = dict(clean); expected[name] = clean[name].replace(old,new)
for n, data in expected.items():
    assert read(LIVE/n) == data, n
assert all(b'text_line_boundaries' not in data for n,data in expected.items() if n.startswith('crates/') and n.endswith('.rs'))

counts = {}
for relative in ['tests.log','cleanup/all-affected.log']:
    log = read(ROOT/relative).decode()
    rows = re.findall(r'test result: .*? (\d+) passed; (\d+) failed;',log)
    counts[relative] = {'executables':len(rows),'passed':sum(int(r[0]) for r in rows),'failed':sum(int(r[1]) for r in rows)}
assert counts['tests.log'] == {'executables':32,'passed':390,'failed':2}
assert counts['cleanup/all-affected.log'] == {'executables':32,'passed':391,'failed':0}
checks = load(ROOT/'cleanup/checks.json')
assert [(r['name'],r['exit']) for r in checks['commands']] == [('ffi-text',0),('core-text',0),('all-affected',0),('clippy',101)]
lint = load(ROOT/'cleanup-lint/checks.json')
assert [(r['name'],r['exit']) for r in lint['commands']] == [('clippy',0),('fmt',0)]
assert 'unused_mut' in read(ROOT/'cleanup/clippy.log').decode()
for name in ['cleanup/core-text.log','cleanup/ffi-text.log','cleanup-lint/clippy.log','cleanup-lint/fmt.log']:
    read(ROOT/name)

final_metadata = load(FINAL/'source.json')
final_manifest = final_metadata['source_sha256']
final = archive(FINAL/'source.tar.gz',final_manifest)
assert set(expected) <= set(final)
assert all(final[n] == data for n,data in expected.items())
for n,data in final.items():
    assert read(LIVE/n) == data, n
additional = sorted(set(final)-set(expected))

report = {
    'status':'passed',
    'scope':'Independent source-only cleanup review and saved check-log/source reconstruction. No builds, tests, parser executions, timing, or ABI conformance certification.',
    'findings':[],
    'source_files':{'initial':len(initial),'cleanup':len(clean),'final':len(final),'additional_final_files':additional},
    'changed_files':sorted(changed),
    'runtime_review':[
        'Only the abandoned hidden text_line_boundaries field, false initialization, inheritance, setter, and branch are removed. C construction/reset no longer used the setter before this cleanup; default coalescing uses the same existing algorithm.',
        'The remaining selector, CR/LF and internal-entity distinctions, converted source windows, malformed prefix/error ordering, current_raw save, frame preparation/publication, accounting, and selected allocator paths are unchanged.',
        'No lifetime-bearing reference or owner is added. Removing a bool can change Parser layout/code generation, so previous timings are not attributed byte-for-byte to this final artifact.',
    ],
    'test_review':[
        'The child test now checks the chosen default coalescing policy for both a parent and owned external child. The final unused-mut removal changes no test assertion.',
        'The removed FFI test specifically required the abandoned literal-newline callback policy. It is author-created, not an upstream assertion; its initial failure remains preserved.',
        'The retained Text frame lifetime test covers short/long payloads and nested DefaultCurrent, current context, base mutation, rejected free/reset/reentrant parse, callback replacement, suspension/getters/resume and final free. The owned original bytes survive callback APIs; &amp; then tail provide two later callbacks under the replacement handler.',
    ],
    'retained_checks':counts,
    'limitations':[
        'The 391 test pass covers the cleanup before the sole unused-mut lint correction. Final strict Clippy/fmt pass is recorded separately; no new final test rerun is asserted here.',
        'This cleanup retains coalesced C text behavior and does not resolve the two known original CPython newline-grouping failures. Removing an internal policy test is not an upstream waiver or a claim those tests pass.',
        'This review is of the three-file cleanup and exact final source reconstruction, not a new independent review of the entire previously reviewed frame architecture.',
    ],
    'artifacts_sha256':observed,
}
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'counts':counts,'final_source_files':len(final),'additional':additional}))
