"""Read-only fresh compile/output provenance supplement."""
import hashlib
import json
import re
import shlex
import tarfile
from pathlib import Path

OUT=Path(__file__).parent
ROOT=Path('/tmp/oriole-frame-integrated-final')
OLD=Path('/tmp/oriole-verified-builds/coalesced')
hashes={}
def read(p):
    p=Path(p);data=p.read_bytes();hashes[str(p)]=hashlib.sha256(data).hexdigest();return data
def sha(p):read(p);return hashes[str(Path(p))]
def load(p):return json.loads(read(p))
report=load(ROOT/'report.json')
source=load(ROOT/'source.json')
assert sha(ROOT/'source.json')=='e05d0c4f8de7978968e4b4dafc1ca747029f284fd4ac238064050b1ee5eec38c'
assert report['source_manifest_sha256']==sha(ROOT/'source.json')
assert report['status']=='passed' and report['exit']==0 and report['source_unchanged']
assert report['command']==['taskset','-c','2,3','cargo','+ohm','-Zohm-defaults=no','build','--release','--locked','-p','oriole_expat','-vv']
assert report['env_overrides']['CARGO_BUILD_BUILD_DIR']=='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}'
assert report['env_overrides']['CARGO_INCREMENTAL']=='0'
for name in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']:
    assert report['env_overrides'][name]==''
read(ROOT/'source.tar.gz')
with tarfile.open(ROOT/'source.tar.gz') as tar:
    files={m.name:tar.extractfile(m).read() for m in tar if m.isfile()}
assert len(files)==69 and set(files)==set(source['source_sha256'])
for name,data in files.items():
    assert hashlib.sha256(data).hexdigest()==source['source_sha256'][name]
    assert read(Path(source['worktree'])/name)==data
assert sha(OUT/'review.json')=='3e3483426c3af74a8318f53dcc3cc121e54a01dfc573caabf8ba230a74cbe84b'
prior=load('/tmp/oriole-build-provenance-independent-review/fresh-build-details.json')
assert sha('/tmp/oriole-build-provenance-independent-review/fresh-review.json')=='f3f69ee61b1e273023f81e47789ba75173d41c4729725bac4175f2dbe618c5fb'
for name in ['rustc','cargo']:
    assert sha(prior['tool_metadata'][name+'_path'])==prior['tool_metadata'][name+'_sha256']

invocations=load(ROOT/'workspace-compiler-invocations.json')
old=load(OLD/'workspace-compiler-invocations.json')
log=read(ROOT/'build.log').decode()
from_log=[x.strip() for x in log.splitlines() if x.strip().startswith('Running `')]
assert invocations==from_log and len(invocations)==report['workspace_compilations']==3
assert log.count('   Compiling ')==3 and 'Finished `release` profile [optimized]' in log
assert [re.search(r'CARGO_CRATE_NAME=(\w+)',x)[1] for x in invocations]==['oriole_storage','oriole','oriole_expat']

def parse(line):
    assert line.startswith('Running `') and line.endswith('`')
    words=shlex.split(line[9:-1]);i=next(i for i,x in enumerate(words) if x.endswith('/bin/rustc'))
    env=dict(x.split('=',1) for x in words[:i]);compiler=words[i];args=words[i+1:]
    return env,compiler,args

details=[];deps=None
for line,baseline in zip(invocations,old):
    env,compiler,args=parse(line);old_env,old_compiler,old_args=parse(baseline)
    assert compiler==old_compiler==prior['tool_metadata']['rustc_path']
    dep=args[args.index('--out-dir')+1];old_dep=old_args[old_args.index('--out-dir')+1]
    assert '/verified-build/' in dep and dep!=old_dep
    if deps is None:deps=Path(dep)
    assert deps==Path(dep)
    assert '--target' not in args and not any(x.startswith('-Z') or 'profile-use' in x or 'profile-generate' in x or 'incremental=' in x for x in args)
    assert ['opt-level=3','codegen-units=1','strip=debuginfo']==[x for x in args if x.startswith(('opt-level=','codegen-units=','strip='))]
    assert [x.replace(dep,'<PRIVATE-DEPS>') for x in args]==[x.replace(old_dep,'<PRIVATE-DEPS>') for x in old_args]
    normalize=lambda values,workspace,build:{k:v.replace(workspace,'<WORKSPACE>').replace(build,'<PRIVATE-DEPS>') for k,v in values.items()}
    assert normalize(env,source['worktree'],dep)==normalize(old_env,'/home/dev-user/code/oss/oriole-ns-coalesced',old_dep)
    assert env['CARGO_MANIFEST_DIR']==source['worktree']+'/crates/'+env['CARGO_CRATE_NAME']
    assert f"crates/{env['CARGO_CRATE_NAME']}/src/lib.rs" in args
    details.append({'crate':env['CARGO_CRATE_NAME'],'compiler':compiler,'args':args,'environment':env})

old_deps=Path('/home/dev-user/.cache/ohm/verified-build/7a/7125f21fa08f73/release/deps')
dependency_parity={}
for name in ['allocator_api2-fc665c646d4b1f7f','hashbrown-9618d82a15fe5a9f','memchr-9560a37caf6cffa1']:
    for ext in ['rmeta','rlib']:
        file='lib'+name+'.'+ext
        digest=sha(deps/file);assert digest==sha(old_deps/file)
        dependency_parity[file]=digest
for name,digest in report['libraries'].items():
    assert sha(ROOT/name)==digest
    assert sha(deps/name)==digest
    target=Path(report['env_overrides']['CARGO_TARGET_DIR'])/'release'/name
    assert sha(target)==digest
assert report['libraries']=={
    'liboriole_expat.so':'9277b71c85f3c0345697010eb282a3be18a0144f25bc2f78e2a0cee20c175dcd',
    'liboriole_expat.a':'773d48c79dd4b9d0f47327e103ae0daf706d4d23fa36239fe046f69798756e79',
}
(OUT/'build-details.json').write_text(json.dumps({'invocations':details,'dependency_byte_parity':dependency_parity},indent=2)+'\n')
review={
    'status':'passed','findings':[],
    'scope':'Independent read-only source/archive/compiler/output mapping supplement. No builds or parser executions.',
    'source_files':69,'full_workspace_compilations':3,
    'source_manifest_sha256':sha(ROOT/'source.json'),
    'libraries':report['libraries'],
    'private_intermediate_directory':str(deps),
    'effective_workspace_rustc_args_and_environment_match_prior_fresh_coalesced_after_only_private_paths':True,
    'cached_registry_dependency_rmeta_and_rlib_byte_parity_count':len(dependency_parity),
    'tool_metadata':prior['tool_metadata'],
    'conclusion':'All three workspace crates actually compiled from the reviewed final source through one worktree-specific intermediate directory. The staged shared/static libraries match both target and compiler-output copies. Compiler/effective settings match the earlier freshly verified no-default context; six cached dependency rmeta/rlib artifacts also match exactly.',
    'limits':[
        'The 69 files are the explicitly frozen integration manifest, not every repository/tool file. The absent rust-toolchain.toml startup assumption failed before any compile and is retained by the owner.',
        'Source and parser layout differ from measured dbeec28f; matching build context does not transfer its exact benchmark timings or all correctness results to this new binary. New integration gates remain separate.',
        'The registry dependencies were fresh cache hits in this invocation, not rebuilt; exact artifact byte parity is checked against the previously audited fresh build.',
        'Verbose Cargo logs record compiler invocations and completed status; this review does not claim an intercepted linker command or a fully hermetic environment.',
    ],
    'details_sha256':sha(OUT/'build-details.json'),'artifacts_sha256':hashes,
}
(OUT/'build-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((OUT/'build-review.json').read_bytes()).hexdigest(),'source_files':69,'compilations':3,'libraries':report['libraries']}))
