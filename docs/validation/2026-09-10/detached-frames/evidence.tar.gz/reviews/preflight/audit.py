"""Read-only benchmark protocol, build origins, and saved preflight audit."""
import difflib
import gzip
import hashlib
import json
import math
import statistics
from pathlib import Path

OUT=Path(__file__).parent
PY=Path('/tmp/oriole-integrated-consumer-study')
NATIVE=Path('/tmp/oriole-integrated-native-study')
OLDPY=Path('/tmp/oriole-verified-consumer-study')
OLDNATIVE=Path('/tmp/oriole-verified-native-study')
hashes={}
def read(p):
    p=Path(p);data=p.read_bytes();hashes[str(p)]=hashlib.sha256(data).hexdigest();return data
def sha(p):read(p);return hashes[str(Path(p))]
def load(p):return json.loads(read(p))

for name in ['consumer_screen.py','python_worker.py','build_consumers.py']:
    assert read(PY/name)==read(OLDPY/name)
assert sha(PY/'python_worker.py')=='4bc0ccffedb5048412b9cfc3638d28dcb30f711891c3784f3fbd3c0eb536ab68'
old=read(OLDNATIVE/'native_screen.py').decode()
new=read(NATIVE/'native_screen.py').decode()
assert ''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='verified-native/native_screen.py',tofile='integrated-native/native_screen.py'))==read(NATIVE/'harness.patch').decode()
old_scope="Normal native C callbacks, fresh published4b11/6c645730, fresh coalesced namespace frame/dbeec28f candidate, pinned Expat2.8.4."
new_scope="Normal native C callbacks, fresh published4b11/6c645730, integrated coalesced frames/9277b71c candidate (db5 fixes retained; abandoned line-policy hook removed), pinned Expat2.8.4."
assert old.replace(str(OLDNATIVE),str(NATIVE)).replace('/tmp/oriole-verified-builds/coalesced/liboriole_expat.so','/tmp/oriole-frame-integrated-final/liboriole_expat.so').replace(old_scope,new_scope)==new
libraries={
    'published':'6c64573061d9f4c8a0cc409f414f2314aa781b0baf30147388e06745872aaadc',
    'candidate':'9277b71c85f3c0345697010eb282a3be18a0144f25bc2f78e2a0cee20c175dcd',
    'expat':'7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478',
}
build=load(PY/'consumers/build.json')
assert build['status']=='passed' and build['adaptations'] is None
assert build['cpython_revision']=='3bb231a6a5dc02b95658877318bf61501a7209e9'
assert build['source_sha256_before']==build['source_sha256_after']
for p,h in build['source_sha256_before'].items():assert sha(p)==h
normalized={}
for engine,consumer in build['consumers'].items():
    assert sha(consumer['library'])==libraries[engine]
    for p,h in consumer['files'].items():assert sha(p)==h
    assert len(consumer['commands'])==2
    normalized[engine]=[]
    for module,row in zip(['pyexpat','_elementtree'],consumer['commands']):
        args=row['command'];assert args[:4]==['cc','-shared','-fPIC','-O2'] and row['returncode']==0
        assert sha(Path(consumer['directory'])/(module+'-build.log'))==row['log_sha256']
        assert args[-4]==consumer['library']
        normalized[engine].append([x.replace(consumer['library'],'<PARSER>').replace(consumer['directory'],'<CONSUMER>') for x in args])
assert all(v==normalized['published'] for v in normalized.values())
oldbuild=load(OLDPY/'consumers/build.json')
assert read('/tmp/oriole-text-frame-prototype/text/cpython-harness/include/expat.h')==read('/home/dev-user/code/oss/oriole-frame-integration/include/expat.h')
for engine,consumer in oldbuild['consumers'].items():
    normalized_old=[[x.replace(consumer['library'],'<PARSER>').replace(consumer['directory'],'<CONSUMER>').replace('-I/tmp/oriole-text-frame-prototype/text/cpython-harness/include','-I/home/dev-user/code/oss/oriole-frame-integration/include') for x in r['command']] for r in consumer['commands']]
    assert normalized_old==normalized[engine]

pre=load(PY/'screen/preflight.json');oldpre=load(OLDPY/'screen/preflight.json')
assert pre['status']=='preflight_passed' and pre['kind']=='python' and pre['affinity']==[2]
assert pre['seed']==oldpre['seed']==202609104412 and pre['pairs']==oldpre['pairs']==7
assert pre['conditions']==oldpre['conditions'] and pre['expected']==oldpre['expected'] and len(pre['conditions'])==24
assert len(pre['preflights'])==len(pre['processes'])==72
assert not pre['hash_errors'] and pre['hashes_before']==pre['hashes_after']
for p,h in pre['hashes_before'].items():assert sha(p)==h
processes={p['label']:p for p in pre['processes']}
key=lambda c:f"{c['name']}/{c['chunk']}/{c['mode']}"
conditions={key(c):c for c in pre['conditions']}
assert [(r['key'],r['engine']) for r in pre['preflights']]==[(key(c),e) for c in pre['conditions'] for e in ['published','candidate','expat']]
for row in pre['preflights']:
    p=processes[row['process']];assert p['status']=='passed' and p['returncode']==0 and p['timeout_seconds']==300 and 'failure' not in p
    for stream in ['stdout','stderr']:assert sha(PY/'screen'/p[stream])==p[stream+'_sha256']
    assert not gzip.decompress(read(PY/'screen'/p['stderr']))
    raw=json.loads(gzip.decompress(read(PY/'screen'/p['stdout'])))
    assert raw['identity']==row['identity'] and raw['samples']==row['samples'] and raw['gc_enabled']
    engine=row['engine'];consumer=build['consumers'][engine]
    assert raw['identity']['parser_library']['sha256']==libraries[engine]
    assert raw['identity']['expat_version']==('expat_2.8.4' if engine=='expat' else 'oriole_compat_2.8.4')
    for name in ['pyexpat','_elementtree','parser_library']:
        identity=raw['identity'][name];assert consumer['files'][identity['path']]==identity['sha256']==sha(identity['path'])
    args=p['command'];assert args[1:5]==['-I','-S',str(PY/'python_worker.py'),'--worker']
    spec=load(args[-1]);c=conditions[row['key']]
    assert spec=={'input':c['input'],'input_sha256':sha(c['input']),'chunk':c['chunk'],'mode':c['mode'],'consumer':consumer['directory'],'library_sha256':libraries[engine],'iterations':0}
    assert len(raw['samples'])==1 and row['median_seconds'] is None
    sample=raw['samples'][0];assert sample['iteration']==0 and sample['warmup']
    assert sample['seconds']==(sample['parse_ns']+sample['destruction_ns'])/1e9 and sample['seconds']>0
    assert [sample['output_sha256'],sample['output_rows']]==pre['expected'][row['key']]

protocol=load(NATIVE/'native-screen/protocol.json');oldprotocol=load(OLDNATIVE/'native-screen/protocol.json')
native=load(NATIVE/'native-screen/preflight.json');oldnative=load(OLDNATIVE/'native-screen/preflight.json')
assert protocol['conditions']==oldprotocol['conditions'] and len(protocol['conditions'])==28
assert protocol['seed']==oldprotocol['seed']==2026091003 and protocol['pairs']==7
assert protocol['preflights']==84 and protocol['timed_workers']==588
assert native['status']=='passed' and native['protocol_sha256']==sha(NATIVE/'native-screen/protocol.json')
assert native['hashes_before']==native['hashes_after']==protocol['hashes']
for p,h in protocol['hashes'].items():assert sha(p)==h
for e,lib in protocol['libraries'].items():assert sha(lib['path'])==lib['sha256']==libraries[e]
assert len(native['rows'])==84
for row,oldrow,(c,e) in zip(native['rows'],oldnative['rows'],[(c,e) for c in protocol['conditions'] for e in ['published','candidate','expat']]):
    assert row['condition']==c and row['engine']==e and row['pair']==-1 and row['returncode']==0 and not row['stderr']
    expected=['taskset','-c','3','/tmp/oriole-grammar-bench-plain/native-driver',protocol['libraries'][e]['path'],c['input'],str(c['chunk']),'1']+(['namespaces'] if c['namespaces'] else [])
    assert row['command']==expected
    samples=json.loads(row['stdout'])['samples'];assert len(samples)==2
    assert [s['iteration'] for s in samples]==[0,1] and [s['warmup'] for s in samples]==[True,False]
    assert all(math.isfinite(s['seconds']) and s['seconds']>0 for s in samples)
    observed=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in samples})
    assert len(observed)==1 and [list(x) for x in observed]==row['observations']==oldrow['observations']
    assert row['median_seconds']==samples[1]['seconds']
assert sha('/tmp/oriole-frame-cleanup-independent-review/build-review.json')=='f01285c18cfe7008b925740dbbaa9ed7404a02ba75ac377f20f95e5cc59f2786'
assert sha('/tmp/oriole-verified-python-independent-review/review.json')=='e1865347caa358bdd9a8e9793fc1ee6908aed58869c2c05c620c52d24dd23ed3'
assert sha('/tmp/oriole-verified-native-independent-review/review.json')=='1d0c8d1b80ed0a8394f36f54c2ffcae6ee0e6b980746337ca3b675d56fd99f0d'
review={
    'status':'passed','findings':[],
    'scope':'Bounded source/protocol/build-origin and saved preflight audit before timing. No compiler/parser executions or new timing by reviewer.',
    'libraries':libraries,'python_preflight_workers':72,'native_preflight_workers':84,
    'python_planned':{'conditions':24,'cohorts':168,'workers':504,'measured_samples':25788,'warmups':504},
    'native_planned':{'conditions':28,'cohorts':196,'workers':588,'measured_samples':105420,'warmups':588},
    'conclusion':'All three Python controller/build/worker sources are byte-identical to the previously audited study. Native changes are exactly output directory, candidate library and scope prose. Unchanged fixed counts/seeds/cohorts and ratio semantics verified; all saved preflight outputs and loaded libraries match frozen inputs and previous expected semantics. Six fresh CPython extension builds use identical flags and source/header bytes for all engines.',
    'limits':[
        'Preflight success does not assert future timing completion, performance, or exact newline callback grouping. The known two original CPython grouping failures remain separate.',
        'Automatic GC remains enabled and explicit collect/input/import/canonicalization excluded, while parsing and result destruction are included as in the existing worker.',
        'The native controller retains its existing incomplete failure receipt behavior: a nonzero or timed-out invocation can raise before its row is appended. Such a failed cohort must remain invalid, with external controller/tool output preserved; this is not a claim of comprehensive failed-attempt archival.',
        'These are native/CPython parsing studies on fixed fixtures, not full applications, PGO or a guarantee of an otherwise idle host. Root owns exclusive CPU0 scheduling.',
    ],
    'artifacts_sha256':hashes,
}
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'python_preflights':72,'native_preflights':84}))
