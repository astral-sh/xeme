"""Read ELF bytes directly; do not invoke objcopy or execute parser binaries."""
import difflib
import hashlib
import json
import re
import shlex
import struct
import subprocess
import tarfile
from pathlib import Path

OLD=Path('/tmp/oriole-frame-integrated-final')
NEW=Path('/tmp/oriole-text-frames-pr/release')
OUT=Path(__file__).parent
hashes={}
def read(p):
    p=Path(p);data=p.read_bytes();hashes[str(p)]=hashlib.sha256(data).hexdigest();return data
def sha(p):read(p);return hashes[str(Path(p))]
def load(p):return json.loads(read(p))
def source(root):
    manifest=load(root/'source.json');read(root/'source.tar.gz')
    with tarfile.open(root/'source.tar.gz') as tar:
        members=[m for m in tar if m.isfile()];files={m.name:tar.extractfile(m).read() for m in members}
    assert len(files)==len(members)==69 and set(files)==set(manifest['source_sha256'])
    for n,data in files.items():
        assert hashlib.sha256(data).hexdigest()==manifest['source_sha256'][n]
        assert read(Path(manifest['worktree'])/n)==data
    return manifest,files
old_manifest,old_src=source(OLD);new_manifest,new_src=source(NEW)
assert sha(NEW/'source.json')=='6f6bfb5c076cbf34a18b742783591612fafa8f660efbfb9b8e989461fdeb4805'
changed=[n for n in old_src if old_src[n]!=new_src[n]]
assert changed==['crates/oriole/src/encoding.rs','crates/oriole/src/tag.rs']
encoding='crates/oriole/src/encoding.rs';tag='crates/oriole/src/tag.rs'
comment=b'    /// Identify an unanchored UTF-8 token without projecting custom raw widths.\n'
assert new_src[encoding].count(comment)==1 and new_src[encoding].replace(comment,b'')==old_src[encoding]
test_start=new_src[tag].index(b'    #[test]\n    fn fallback_stays_disabled_until_the_source_advances()')
test_end=new_src[tag].index(b'    fn legacy_parse_raw_attributes(',test_start)
assert new_src[tag][:test_start]+new_src[tag][test_end:]==old_src[tag]
assert new_src[tag].index(b'#[cfg(test)]\nmod tests {')<test_start
delta=''.join(''.join(difflib.unified_diff(old_src[n].decode().splitlines(keepends=True),new_src[n].decode().splitlines(keepends=True),fromfile='9277/'+n,tofile='PR3/'+n)) for n in changed)
(OUT/'source-delta.patch').write_text(delta)

def elf(path):
    data=read(path);h=struct.unpack_from('<16sHHIQQQIHHHHHH',data)
    assert h[0][:6]==b'\x7fELF\x02\x01' and h[2]==62 and h[11]==64
    sections=[struct.unpack_from('<IIQQQQIIQQ',data,h[6]+i*h[11]) for i in range(h[12])]
    ns=sections[h[13]];names=data[ns[4]:ns[4]+ns[5]];byname={}
    for s in sections:
        name=names[s[0]:].split(b'\0',1)[0].decode();assert name not in byname
        byname[name]=(s,b'' if s[1]==8 else data[s[4]:s[4]+s[5]])
    return data,h,byname
old,h,sections=elf(OLD/'liboriole_expat.so');new,nh,nsections=elf(NEW/'liboriole_expat.so')
assert sha(OLD/'liboriole_expat.so')=='9277b71c85f3c0345697010eb282a3be18a0144f25bc2f78e2a0cee20c175dcd'
assert sha(NEW/'liboriole_expat.so')=='5af2406b17092dad35aa61c086cdfe39e24f51e653441fd9baf50cd12da3b2fe'
assert len(old)==len(new) and h==nh and set(sections)==set(nsections)
assert all(sections[n][0]==nsections[n][0] for n in sections)
different=[n for n in sections if sections[n][1]!=nsections[n][1]]
assert different==['.note.gnu.build-id','.data.rel.ro']
sec,bytes_old=sections['.data.rel.ro'];bytes_new=nsections['.data.rel.ro'][1]
byte_deltas=[i for i,(a,b) in enumerate(zip(bytes_old,bytes_new)) if a!=b];assert len(byte_deltas)==18
rela,relbytes=sections['.rela.dyn'];assert rela[9]==24
relocations={}
for offset in range(0,len(relbytes),24):
    address,info,addend=struct.unpack_from('<QQq',relbytes,offset);relocations[address]=(info,addend)
def virtual(address,count):
    s=next(s for s,b in sections.values() if s[1]!=8 and s[3]<=address and address+count<=s[3]+s[5])
    return old[s[4]+address-s[3]:s[4]+address-s[3]+count]
locations=[];allowed=set()
for offset in byte_deltas:
    # Rust Location: 16-byte file &str followed by u32 line and column.
    start=offset-16;address=sec[3]+start
    old_pointer,length,line,column=struct.unpack_from('<QQII',bytes_old,start)
    new_pointer,new_length,new_line,new_column=struct.unpack_from('<QQII',bytes_new,start)
    assert (old_pointer,length,column)==(new_pointer,new_length,new_column) and new_line==line+1
    assert old_pointer==0 and length==len(encoding.encode())
    info,filename=relocations[address];assert info==8 # R_X86_64_RELATIVE, no symbol
    assert virtual(filename,length).decode()==encoding
    assert line>725 and old_src[encoding].decode().splitlines()[line-1]==new_src[encoding].decode().splitlines()[new_line-1]
    assert bytes_old[start:start+16]==bytes_new[start:start+16] and bytes_old[start+20:start+24]==bytes_new[start+20:start+24]
    allowed.add(sec[4]+offset)
    locations.append({'address':hex(address),'section_offset':start,'file':encoding,'old_line':line,'new_line':new_line,'column':column,'source':old_src[encoding].decode().splitlines()[line-1]})
note=sections['.note.gnu.build-id'][0];allowed.update(range(note[4],note[4]+note[5]))
all_differences=[i for i,(a,b) in enumerate(zip(old,new)) if a!=b]
assert set(all_differences)<=allowed and len(all_differences)==38

# Resolve calls following every source-location reference from unchanged machine
# code through the unchanged relative GOT relocations to panic helper symbols.
sym,sybytes=sections['.symtab'];strings=sections['.strtab'][1];symbols={}
for off in range(0,len(sybytes),sym[9]):
    name,info,other,index,address,size=struct.unpack_from('<IBBHQQ',sybytes,off)
    if address:symbols[address]=strings[name:].split(b'\0',1)[0].decode()
run=subprocess.run(['objdump','-d','--demangle',str(NEW/'liboriole_expat.so')],capture_output=True,check=True,text=True)
assert not run.stderr
assembly=run.stdout.splitlines();references=[]
for location in locations:
    needle=re.compile(r'# '+location['address'][2:]+r'\b')
    refs=[]
    for i,line in enumerate(assembly):
        if not needle.search(line):continue
        following=assembly[i:i+14]
        call=next((x for x in following if re.search(r'\bcall\s',x)),None);assert call,(location,line)
        target=re.search(r'# ([0-9a-f]+)\b',call)
        assert target,(location,call)
        info,address=relocations[int(target[1],16)];assert info==8
        name=symbols[address];assert any(kind in name for kind in ['panic_bounds_check','slice_error_fail','panic_fmt','unwrap_failed','slice_index_fail','core9panicking5panic']),name
        refs.append({'assembly':following[:following.index(call)+1],'target_symbol':name})
    assert refs,location
    references.append({'location':location,'references':refs})
(OUT/'panic-location-deltas.json').write_text(json.dumps(references,indent=2)+'\n')

build=load(NEW/'report.json');oldbuild=load(OLD/'report.json');assert build['status']=='passed' and build['exit']==0 and build['source_unchanged']
assert build['source_manifest_sha256']==sha(NEW/'source.json') and build['workspace_compilations']==3
assert build['command']==oldbuild['command']
assert {k:v for k,v in build['env_overrides'].items() if k!='CARGO_TARGET_DIR'}=={k:v for k,v in oldbuild['env_overrides'].items() if k!='CARGO_TARGET_DIR'}
invocations=load(NEW/'workspace-compiler-invocations.json');oldinvocations=load(OLD/'workspace-compiler-invocations.json');assert len(invocations)==3
log=read(NEW/'build.log').decode()
assert [x.strip() for x in log.splitlines() if x.strip().startswith('Running `') and re.search(r'CARGO_CRATE_NAME=oriole(?: |_)',x)]==invocations
assert 'Finished `release` profile [optimized]' in log
def parse(line):
    words=shlex.split(line[9:-1]);i=next(i for i,x in enumerate(words) if x.endswith('/bin/rustc'))
    return dict(x.split('=',1) for x in words[:i]),words[i],words[i+1:]
compiled=[];deps=None
for current,prior in zip(invocations,oldinvocations):
    env,compiler,args=parse(current);oe,oc,oa=parse(prior)
    assert compiler==oc
    dep=args[args.index('--out-dir')+1];od=oa[oa.index('--out-dir')+1]
    assert '/verified-build/' in dep and dep!=od
    assert [x.replace(dep,'<DEPS>') for x in args]==[x.replace(od,'<DEPS>') for x in oa]
    norm=lambda e,w,d:{k:v.replace(w,'<WORKTREE>').replace(d,'<DEPS>') for k,v in e.items()}
    assert norm(env,new_manifest['worktree'],dep)==norm(oe,old_manifest['worktree'],od)
    assert not any(x in args for x in ['--test','--target'])
    compiled.append(env['CARGO_CRATE_NAME']);deps=Path(dep)
assert compiled==['oriole_storage','oriole','oriole_expat']
for name,digest in build['libraries'].items():
    assert sha(NEW/name)==sha(deps/name)==sha(Path(build['env_overrides']['CARGO_TARGET_DIR'])/'release'/name)==digest
metadata=load('/tmp/oriole-build-provenance-independent-review/fresh-build-details.json')['tool_metadata']
for tool in ['cargo','rustc']:assert sha(metadata[tool+'_path'])==metadata[tool+'_sha256']
assert sha('/tmp/oriole-frame-cleanup-independent-review/build-review.json')=='f01285c18cfe7008b925740dbbaa9ed7404a02ba75ac377f20f95e5cc59f2786'
section_report=load('/tmp/oriole-text-frames-pr/section-comparison.json');assert section_report['different_sections']==different
for key,ss in [('old_sections',sections),('new_sections',nsections)]:
    for name,record in section_report[key].items():
        data=ss['' if name=='NULL' else name][1]
        assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
review={
    'status':'passed','findings':[],
    'audit_correction':'Initial helper-name allowlist omitted core::slice::index::slice_index_fail and core::panicking::panic. These exact symbols are now accepted as panic helpers; initial two scripts/assertions retained separately. No input or parser artifact changed.',
    'scope':'Independent source/archive and fresh compiler/output mapping plus complete shared-library ELF byte comparison. Read-only files, git-free source archives, objdump disassembly; no objcopy, parser execution, build or new timing.',
    'source_files_each':69,'source_differences':changed,'workspace_compilations':3,
    'libraries':{'measured':sha(OLD/'liboriole_expat.so'),'pr3':sha(NEW/'liboriole_expat.so')},
    'elf':{'bytes_each':len(old),'different_sections':different,'changed_file_bytes':len(all_differences),'panic_location_records':18,'line_changes':'+1 in encoding.rs','column_pointer_file_fields_unchanged':True,'headers_section_layout_relocations_machine_code_and_all_other_bytes_identical':True},
    'conclusion':'The only compiled source edit is one Rustdoc line. The preserved tag regression is cfg(test)-only. All18 non-build-ID byte changes are Rust panic location line numbers for encoding.rs, each +1 at the same source expression and unchanged column. Disassembly passes these records to panic bounds/slice helpers. Shared-library normal execution machine code, addresses, relocations and data are identical to measured9277; its successful native and CPython benchmark measurements remain directly applicable to PR3 with this explicit metadata-only identity qualification.',
    'limits':[
        'The shared libraries have distinct full hashes and build IDs; retain original9277 timing inputs unchanged and record5af2406b as metadata-equivalent, never relabel the measured files.',
        'Panic reports intentionally show the corrected source line. This is not a claim of identical panic diagnostic text.',
        'This proof applies to the built shared library used by timings. The static archives are rehashed/provenance-checked but were not compared member-by-member for bit equivalence.',
        'Compiler context and three actual workspace compiles are verified; shared-host timing uncertainty and benchmark consumer/corpus limitations remain unchanged.',
    ],
    'panic_details_sha256':sha(OUT/'panic-location-deltas.json'),'source_delta_sha256':sha(OUT/'source-delta.patch'),'artifacts_sha256':hashes,
}
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'changed_bytes':len(all_differences),'locations':len(locations)}))
