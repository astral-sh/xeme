"""Independent immutable Start-frame source reconstruction and review record."""
import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

ROOT=Path('/tmp/oriole-start-frames-pr')
OUT=Path(__file__).parent
hashes={}
def read(p):
    p=Path(p);data=p.read_bytes();hashes[str(p)]=hashlib.sha256(data).hexdigest();return data
def sha(p):read(p);return hashes[str(Path(p))]
def load(p):return json.loads(read(p))
source=load(ROOT/'source.json')
assert sha(ROOT/'source.json')=='ddcd460ed5340eebc78371055b95a7061798e02d37bf6fa4bea68a89d47f9e68'
assert sha(ROOT/'start-layer.patch')=='80196df726289d43c8f474871263ce0b3a78a78ee7435d326579851476db9fe0'
assert source['base_commit']=='ebb9aefd566ad7178b6b869aefdfc231ad45e4e1'
read(ROOT/'source.tar.gz')
with tarfile.open(ROOT/'source.tar.gz') as tar:
    members=[m for m in tar if m.isfile()]
    files={m.name:tar.extractfile(m).read() for m in members}
assert len(files)==len(members)==69 and set(files)==set(source['source_sha256'])
for name,data in files.items():
    assert hashlib.sha256(data).hexdigest()==source['source_sha256'][name]
    assert read(Path(source['worktree'])/name)==data,name

# Git archive is a read-only source operation; no parser/compiler execution.
command=['git','-C',source['worktree'],'archive',source['base_commit']]
run=subprocess.run(command,capture_output=True,check=True)
assert not run.stderr
with tarfile.open(fileobj=io.BytesIO(run.stdout)) as tar:
    base={m.name:tar.extractfile(m).read() for m in tar if m.isfile() and m.name in files}
patch=read(ROOT/'start-layer.patch').decode().splitlines(keepends=True)
patched=dict(base);changed=[];i=0
while i<len(patch):
    assert patch[i].startswith('diff --git ')
    i+=1
    while not patch[i].startswith('--- '):i+=1
    old=patch[i][4:].strip();new=patch[i+1][4:].strip();assert new.startswith('b/');name=new[2:]
    original=[] if old=='/dev/null' else base[name].decode().splitlines(keepends=True)
    i+=2;result=[];cursor=0
    while i<len(patch) and patch[i].startswith('@@'):
        m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n',patch[i]);assert m
        a,old_n,b,new_n=(int(x) if x is not None else 1 for x in m.groups())
        offset=max(a-1,0);result.extend(original[cursor:offset]);cursor=offset
        assert len(result)==max(b-1,0)
        i+=1;old_count=new_count=0
        while i<len(patch) and not patch[i].startswith(('@@','diff --git ')):
            op,line=patch[i][0],patch[i][1:];assert op in ' +-'
            if op!='+':assert original[cursor]==line,(name,cursor);cursor+=1;old_count+=1
            if op!='-':result.append(line);new_count+=1
            i+=1
        assert (old_count,new_count)==(old_n,new_n)
    result.extend(original[cursor:]);patched[name]=''.join(result).encode();changed.append(name)
assert patched==files
assert all(b'text_line_boundaries' not in data for n,data in files.items() if n.endswith('.rs'))
arena=files['crates/oriole/src/arena.rs'].decode()
assert 'text_bytes' not in arena and 'prepare_text' not in arena
assert files['crates/oriole/src/encoding.rs']==base['crates/oriole/src/encoding.rs']
assert files['crates/oriole/src/tag.rs']==base['crates/oriole/src/tag.rs']
assert all(files[n]==base[n] for n in files if n.startswith('crates/oriole/src/dtd'))
review={
    'status':'passed','findings':[],
    'scope':'Bounded independent source-only review of frozen PR2 Start-frame patch and exact parent reconstruction. No builds, parser executions, differential tests, sanitizer runs or performance measurements by reviewer.',
    'source_manifest_sha256':sha(ROOT/'source.json'),'patch_sha256':sha(ROOT/'start-layer.patch'),
    'source_files':69,'base_commit':source['base_commit'],'read_only_base_command':command,
    'changed_files':changed,
    'checks':[
        'All 69 archived/live files match the manifest. Applying every exact patch hunk in memory to ebb9aef reproduces the archive, including unchanged latest DTD, decoder/source-origin and tag-scanner files. No Text frame or newline policy hook is introduced.',
        'The frame owns allocator-selected strings and offset records independently of Parser; C dispatch holds only immutable frame slices and a separately owned pointer array across callbacks. Parser handler, allocator and user-data values are copied to scalars before dispatch. No source/table/core mutable reference survives into C callbacks.',
        'The lexical plan requires a native UTF-8 root source, no DOCTYPE/foreign/shared DTD or fragment/entity child, complete valid literal attributes, and existing offset capacity. References, normalization whitespace, invalid XML, unknown/custom encodings and UTF-16 retain the existing fallback. The new namespace plan still performs semantic QName/duplicate checks.',
        'Namespace frame delivery requires colon-free element and attribute names, no xmlns attribute, and no active default namespace. Those names expand identically regardless of separator or triplet setting. All binding mutations, expanded-prefix duplicates and namespace callbacks remain on owned events.',
        'Frame preparation reserves the selected allocator before values, checks byte additions, appends one NUL per validated field, and publishes only after stack/end-tag work succeeds. Counts are bounded by 128 attributes and 4KiB token selection. Callback byte charging excludes NUL and matches old names/values; specified-attribute count and default fallback retain their existing order.',
        'Active frame delivery is checked before pending events, preserving Start-before-End on empty tags. The source token becomes current_raw before callbacks; planned native tokens cannot require alias decoding at this step. Source accounting succeeds before semantic work and no callbacks/source changes occur before consume. Error reconciliation clears unpublished/failed frames and preserves the existing queued-event and NoMemory handling.',
        'Generation IDs are checked before filling; mismatched or reset frames clear and fall back to owned events. Finishing drops frame owners before releasing its cache allowance. Normal C run_events holds one frame per busy-guarded invocation and finishes it on success, failure and suspension; callback reentry cannot create another run on that same CParser.',
        'The adapter allowance is included in the existing 64KiB retained recycling budget, evicting warm attributes if necessary and reducing later name/attribute retention. Frame allocation uses the selected suite; geometric active storage is distinct from the retained capacity guarantee.',
        'The dispatch_unhandled extraction preserves the original DTD/default fragment algorithm. Callback handler changes apply at subsequent events, DefaultCurrent copies raw state through the existing path, and parser reset/free/reentrant parsing remain guarded.',
    ],
    'test_source_review':[
        'Added tests exercise selected fail-at-each-allocation and allocation-free repeated terminal errors; exact callback-byte boundaries with and without handlers; current raw/input context and live C name/attribute pointers during nested DefaultCurrent, base mutation, rejected free/reset/reentry, suspension and handler replacement.',
        'Frame-versus-owned comparisons cover all byte widths of valid/malformed starts, namespace defaults/undeclarations, prefixed and duplicate-expanded attributes, UTF-16 fallback, low token limits and foreign/reset generation rejection. Existing scanner fallback regression and DTD tests are retained.',
        'These internal two-path comparisons share the lexical planner. The independently recorded prior old/new library oracles remain relevant separate evidence; this source-only review does not replace fresh layer-specific compatibility gates.',
    ],
    'limitations':[
        'The 4KiB token guard and 128-attribute guard bound selection, not an exact active peak-memory parity claim. A geometrically oversized byte capacity is discarded on next clear; fixed allowance describes retained cache usage.',
        'The hidden safe adapter API returns caller-owned frames, and callers can retain arbitrary owners just as they can retain ordinary Events. Aggregate parser-cache accounting is assessed for the intended single live C frame; it is not a process-wide cap on arbitrary safe Rust caller allocations.',
        'A panic during delivery drops the local frame through Rust unwinding; explicit finish may not run, leaving a conservative cache reservation in an already failed C parser. No increased cache retention follows.',
        'This layer adds Start frames only and retains the original coalesced Text behavior and known two CPython newline-grouping failures. No broad drop-in or faster-than-Expat claim is made.',
    ],
    'artifacts_sha256':hashes,
}
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'source_files':len(files),'changed_files':changed}))
