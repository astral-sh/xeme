# Owned StartElement adapter layer

Local commit `fdb7afb157fb020c9d2fa775d82b9087112c7e0b` follows grammar layer `ebb9aefd566ad7178b6b869aefdfc231ad45e4e1`. This layer delivers eligible literal start tags in an independently owned, allocator-aware buffer with attribute offsets. The existing owned Rust event API remains available. Namespace parsing uses the shared lexical plan; the frame path requires identity expansion. It adds no detached Text storage or alternate line-boundary policy.

The 69-file source freeze includes the latest published asynchronous-entity origin and DTD reparse fixes. Parent-prepared source differed only by those retained fixes and trailing-blank formatting. `source.json`, `source.tar.gz`, and both patches record exact bytes. A normal release using Ohm with automatic defaults disabled compiled all three workspace crates in a private worktree-hashed intermediate directory. The verbose compiler invocations and configuration are preserved; old ordinary shared intermediates were not reused.

## Validation

- 386 workspace tests passed, with format and strict Clippy checks.
- All 1,518 strict status/error/callback/position traces match the latest published parser.
- All 186,348 cold/warm tag oracle cases match that baseline. Existing exact Expat differences remain separately reported; successful final event streams and final acceptance agree in this corpus.
- Six C integration/adversarial/allocation runs passed using ASan and UBSan for dynamic and static linkage. Each linkage exercised 327 allocation-failure scenarios. Rust is the ordinary optimized build; LeakSanitizer is disabled because sandbox ptrace is unsupported, with explicit selected-allocation leak checks retained.
- All 4,740 original upstream API outcomes remain unchanged: 4,347 pass and 393 fail. The resulting API JSON is byte-identical to the baseline. Original failures remain failures.
- Independent source review found no blocker in callback lifetimes, cache/generation accounting, namespace guards, error ordering, raw context, or preservation of the latest fixes. That review did not execute the author probes.

No standalone speed claim or CPython suite rerun is attached to this intermediate layer. Final Text-frame composition needs its own source-specific gates and matched performance measurements. No push or GitHub publication was performed by this author.
