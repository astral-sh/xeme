"""Run exact existing behavior gates against the latest published source."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

root = Path(__file__).parent
assert os.sched_getaffinity(0) == {6}
inputs = json.loads((root / 'probe-inputs.json').read_text())
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert all(digest(path) == expected for path, expected in inputs.items())
build = json.loads((root / 'validation.json').read_text())
assert build['status'] == 'passed'
library = root / 'liboriole_expat.so'
assert digest(library) == build['libraries'][library.name]
reference = Path('/tmp/oriole-dtd-reparse-final/liboriole_expat.so')
commands = [
    ('strict', [sys.executable, str(root / 'probe-tools/differential.py'), '--library', str(library), '--reference', str(reference), '--output', str(root / 'strict-traces'), '--strict'], {0}),
    ('warm-tags', [sys.executable, str(root / 'warm_tag_fuzz.py')], {0}),
    ('native', [sys.executable, str(root / 'native_probe.py')], {0}),
    ('upstream-api', [sys.executable, str(root / 'probe-tools/upstream-expat.py'), '--source', '/home/dev-user/.cache/oriole/upstream/expat-2.8.4', '--config', '/home/dev-user/.cache/oriole/expat-build/expat_config.h', '--library', str(library), '--output', str(root / 'upstream-api'), '--test-timeout', '15', '--memory-mib', '4096', '--rss-mib', '3072', '--timeout', '900'], {0, 1}),
]
report = {'status': 'running', 'library_sha256': digest(library), 'reference_sha256': digest(reference), 'commands': []}
try:
    for name, command, accepted in commands:
        with (root / f'{name}.log').open('w') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
        report['commands'].append({'name': name, 'command': command, 'exit': result.returncode, 'log_sha256': digest(root / f'{name}.log')})
        (root / 'probes.json').write_text(json.dumps(report, indent=2) + '\n')
        assert result.returncode in accepted, name
    baseline = json.loads(Path('/tmp/oriole-dtd-reparse-integrated/upstream-api/results.json').read_text())
    candidate = json.loads((root / 'upstream-api/results.json').read_text())
    assert candidate['selection_complete'] and candidate['library_origin_verified']
    assert len(candidate['results']) == len(baseline['results']) == 4740
    key = lambda row: (row['test'], row['context'])
    base_rows = {key(row): row for row in baseline['results']}
    changed = [{'before': base_rows[key(row)], 'after': row} for row in candidate['results'] if row != base_rows[key(row)]]
    comparison = {'baseline': {'passed': baseline['passed'], 'failed': baseline['failed']},
                  'candidate': {'passed': candidate['passed'], 'failed': candidate['failed']},
                  'configurations': 4740, 'changes': changed, 'scope': 'Original public API assertions retained. Adapter exclusions remain limited to pre-existing implementation-private tests.'}
    (root / 'api-comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
    report['status'] = 'passed' if not changed else 'api_changes_require_review'
finally:
    if report['status'] == 'running':
        report['status'] = 'failed'
    report['inputs_unchanged'] = all(digest(path) == expected for path, expected in inputs.items())
    report['library_unchanged'] = digest(library) == report['library_sha256']
    (root / 'probes.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'commands': report['commands']}))
