import ctypes as c, gzip,hashlib,itertools,json,sys
from pathlib import Path
sys.path.insert(0,'/tmp/oriole-start-frames-pr/probe-tools')
from xml_abi import Expat,START,END
root=Path('/tmp/oriole-start-frames-pr')
libraries={key:Expat(str(path)).lib for key,path in [('control',Path('/tmp/oriole-dtd-reparse-final/liboriole_expat.so')),('candidate',root/'liboriole_expat.so'),('expat',Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4'))]}
def parse(lib,data,chunk,ns,final):
 p=lib.XML_ParserCreateNS(None,b'|') if ns else lib.XML_ParserCreate(None)
 assert p;events=[];progress=[]
 @START
 def start(_,name,attrs):
  values=[];index=0
  while attrs[index]:values.extend([attrs[index].decode(),attrs[index+1].decode()]);index+=2
  events.append(['start',name.decode(),values])
 @END
 def end(_,name):events.append(['end',name.decode()])
 lib.XML_SetElementHandler(p,start,end)
 try:
  for offset in range(0,len(data),chunk):
   part=data[offset:offset+chunk];status=lib.XML_Parse(p,part,len(part),final and offset+chunk>=len(data))
   progress.append([status,lib.XML_GetErrorCode(p),lib.XML_GetCurrentByteIndex(p),lib.XML_GetCurrentLineNumber(p),lib.XML_GetCurrentColumnNumber(p),len(events)])
   if status!=1:break
  return [progress,events]
 finally:lib.XML_ParserFree(p)
cases={}
alphabet=[b'r',b':',b'1',b' ',b'\t',b'\n',b'/',b'\x00',b'\xff',b'&',b'>']
for length in range(4):
 for parts in itertools.product(alphabet,repeat=length):
  body=b''.join(parts);cases[b'<r></'+body+b'>']='short-close';cases[b'<'+body+b'/>']='short-open';cases[b'<r a=\"'+body+b'\"/>']='short-attribute'
for name in ['r','é','r\u0901','\u0901','\U00010000','r\U00010000','p:r',':r','r:','p:1','p:-','p:.','p:\u0901','p::r','p:r:r']:
 for tail in ['', ' ', '\t\r\n', ' a', '\u00a0', '\u2000', '/', '\x00']:
  xml=f'<{name} xmlns:p="u"></{name}{tail}>'
  for encoding in ['utf-8','utf-16-le','utf-16-be']:
   data=xml.encode(encoding)
   if encoding=='utf-16-le':data=b'\xff\xfe'+data
   if encoding=='utf-16-be':data=b'\xfe\xff'+data
   cases[data]='name-and-encoding'
for raw in [b'\xc0\xaf',b'\xed\xa0\x80',b'\xf4\x90\x80\x80',b'\xe2',b'\xe2\x82',b'\xc3x',b'\xf0\x9f\x98']:
 for suffix in [b'',b'>',b' >',b'\n>']:
  cases[b'<r></r'+raw+suffix]='invalid-decoder-prefix'
for data, category in list(cases.items()):
 if not data.startswith((b'\xff\xfe',b'\xfe\xff')):
  cases[b"<root><warm a='x' b='y' c='z'/ >".replace(b'/ >',b'/>')+data+b'</root>']='warm-'+category
rows=[];differences=[];reference_differences=0;reference_fields={key:0 for key in ["per_feed_status_error","per_feed_position","element_events","final_acceptance","final_error_code","successful_final_events"]};reference_examples={} 
for data,category in cases.items():
 for ns in [False,True]:
  for chunk in sorted({1,2,3,7,len(data)}):
   for final in [False,True]:
    result={label:parse(lib,data,chunk,ns,final) for label,lib in libraries.items()}
    identity={'sha256':hashlib.sha256(data).hexdigest(),'category':category,'chunk':chunk,'namespaces':ns,'final':final}
    if result['control']!=result['candidate']:differences.append(identity|{'input_hex':data.hex(),'results':result})
    if result['candidate']!=result['expat']:
     reference_differences+=1
     x,y=result['candidate'],result['expat']
     fields=[]
     if [v[:2] for v in x[0]]!=[v[:2] for v in y[0]]:fields.append('per_feed_status_error')
     if [v[2:5] for v in x[0]]!=[v[2:5] for v in y[0]]:fields.append('per_feed_position')
     if x[1]!=y[1]:fields.append('element_events')
     if final:
      if (x[0][-1][0]==1)!=(y[0][-1][0]==1):fields.append('final_acceptance')
      if x[0][-1][1]!=y[0][-1][1]:fields.append('final_error_code')
      if x[0][-1][0]==y[0][-1][0]==1 and x[1]!=y[1]:fields.append('successful_final_events')
     for field in fields:
      reference_fields[field]+=1
      if field not in reference_examples:reference_examples[field]=identity|{'input_hex':data.hex(),'results':result}
    rows.append(identity|{'result_sha256':hashlib.sha256(json.dumps(result,sort_keys=True).encode()).hexdigest()})
summary={'status':'passed' if not differences else 'failed','cases':len(rows),'documents':len(cases),'baseline_differences':len(differences),'reference_exact_differences':reference_differences,'reference_fields':reference_fields,'reference_examples':reference_examples,'scope':'Exact per-feed status/error/byte-index/line/column/callback-prefix and complete start/end events; includes nonfinal input, malformed decoder tails, UTF16, namespace colon/name rules. Existing Expat differences retained separately; optimization must match control.','differences':differences}
(root/'warm-tag-fuzz.json').write_text(json.dumps(summary,indent=2)+'\n')
(root/'warm-tag-fuzz-rows.json.gz').write_bytes(gzip.compress(json.dumps(rows).encode(),mtime=0))
print(json.dumps(summary));assert not differences
