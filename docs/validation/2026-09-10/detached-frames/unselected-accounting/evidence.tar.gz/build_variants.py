if not __debug__: raise RuntimeError("Validation assertions require normal Python execution")
from pathlib import Path
import hashlib,json,shutil,subprocess,os,time,signal
R=Path('/tmp/oriole-unique-accounting-evidence');B=Path('/tmp/oriole-text-atomic-review/source')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((R/'source-freeze/source.json').read_text())['files']
w=Path('/tmp/oriole-unique-rebuilt-baseline');w.mkdir(exist_ok=False)
for n in base:
 p=w/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/n,p)
out=R/'rebuilt-baseline';out.mkdir(exist_ok=False);(out/'source.json').write_text(json.dumps({'scope':'Unmodified e439 source, fresh default-Ohm matched build; original binary preserved','files':{n:sha(w/n) for n in base}},indent=2)+'\n')
report={'scope':'Default-Ohm matched baseline/core-only/C-only attribution builds, no timing or conformance claim','compiler':subprocess.check_output(['rustc','+ohm','-vV'],text=True),'rows':[]}
for label,work in [('rebuilt-baseline',w),('core-only',Path('/tmp/oriole-unique-core-only')),('callback-only',Path('/tmp/oriole-unique-callback-only'))]:
 out=R/label;manifest=json.loads((out/'source.json').read_text());assert {n:sha(work/n) for n in manifest['files']}==manifest['files']
 target=Path('/home/dev-user/.cache/oriole/unique-'+label+'-target');env={**os.environ,'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_TARGET_DIR':str(target),'CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'1'}
 cmd=['taskset','-c','7','cargo','+ohm','build','--release','-p','oriole_expat'];started=time.time();log=out/'build.log'
 timed_out=False
 with log.open('wb') as f:
  process=subprocess.Popen(cmd,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=process.wait(timeout=300)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(process.pid,signal.SIGKILL);code=process.wait()
 row={'label':label,'cwd':str(work),'command':cmd,'environment':{k:env.get(k) for k in ['CARGO_HOME','CARGO_BUILD_BUILD_DIR','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTUP_TOOLCHAIN']},'source_manifest_sha256':sha(out/'source.json'),'started_unix':started,'completed_unix':time.time(),'returncode':code,'timed_out':timed_out,'timeout_seconds':300,'log_sha256':sha(log)}
 report['rows'].append(row);(R/'variant-builds.json').write_text(json.dumps(report,indent=2)+'\n');print(label,code,flush=True);assert code==0 and not timed_out
 for ext in ['so','a']:
  name='liboriole_expat.'+ext;shutil.copyfile(target/'release'/name,out/name);row[name+'_sha256']=sha(out/name)
 row['comment']=subprocess.check_output(['readelf','-p','.comment',str(out/'liboriole_expat.so')],text=True)
 assert {n:sha(work/n) for n in manifest['files']}==manifest['files'];row['sources_unchanged']=True
 if label=='rebuilt-baseline':row['original_shared_identical']=sha(out/'liboriole_expat.so')==sha(Path('/tmp/oriole-text-frame-prototype/text/liboriole_expat.so'));print('baseline identical',row['original_shared_identical'],flush=True)
 (R/'variant-builds.json').write_text(json.dumps(report,indent=2)+'\n')
report['status']='passed';(R/'variant-builds.json').write_text(json.dumps(report,indent=2)+'\n')
