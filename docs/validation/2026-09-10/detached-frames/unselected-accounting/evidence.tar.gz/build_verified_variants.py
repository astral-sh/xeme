if not __debug__: raise RuntimeError('Assertions required')
from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time,tarfile,io
R=Path('/tmp/oriole-unique-accounting-evidence');O=R/'verified-builds';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
root_report=Path('/tmp/oriole-verified-builds/report.json');root=json.loads(root_report.read_text());assert root['status']=='passed'
base_manifest=Path('/tmp/oriole-verified-builds/e439/source.json');base=json.loads(base_manifest.read_text())['source_sha256'];old=Path('/tmp/oriole-text-atomic-review/source');assert {n:sha(old/n) for n in base}==base
report={'status':'incomplete','scope':'Fresh no-default Ohm compilation matching root verified e43916dd context; original default195db gates preserved separately. No runtime source edits or timing.','root_report_sha256':sha(root_report),'baseline_source_sha256':sha(base_manifest),'baseline_libraries':root['variants']['e439']['libraries'],'variants':{}}
common={k:v for k,v in root['variants']['e439']['env_overrides'].items() if k!='CARGO_TARGET_DIR'}
# Preserve root flags/build-root; compile processes and descendants run on CPU7.
def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 for label,source,manifest in [('combined',Path('/tmp/oriole-unique-accounting'),R/'final-source-freeze/source.json'),('core',Path('/tmp/oriole-unique-core-only'),R/'core-only/source.json'),('callback',Path('/tmp/oriole-unique-callback-only'),R/'callback-only/source.json')]:
  work=Path('/tmp/oriole-unique-verified-'+label);work.mkdir(exist_ok=False);out=O/label;out.mkdir();files=json.loads(manifest.read_text())['files'];assert {n:sha(source/n) for n in files}==files
  for name in files:
   p=work/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source/name,p)
  record={'source_sha256':files,'parent_manifest':str(manifest),'parent_manifest_sha256':sha(manifest),'worktree':str(work)};(out/'source.json').write_text(json.dumps(record,indent=2)+'\n')
  with tarfile.open(out/'source.tar.gz','w:gz') as tar:
   for name in files:
    data=(work/name).read_bytes();item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;tar.addfile(item,io.BytesIO(data))
  target=Path('/home/dev-user/.cache/oriole/unique-verified-'+label+'-target');environment={**common,'CARGO_TARGET_DIR':str(target)}
  cmd=['taskset','-c','7','cargo','+ohm','-Zohm-defaults=no','build','--release','--locked','-p','oriole_expat','-vv'];item={'status':'incomplete','command':cmd,'cwd':str(work),'env_overrides':environment,'source_manifest_sha256':sha(out/'source.json'),'started_unix':time.time(),'timeout_seconds':300};report['variants'][label]=item;save()
  with (out/'build.log').open('wb') as log:
   p=subprocess.Popen(cmd,cwd=work,env={**os.environ,**environment},stdout=log,stderr=subprocess.STDOUT,start_new_session=True);timed_out=False
   try:code=p.wait(timeout=300)
   except subprocess.TimeoutExpired:timed_out=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
  item.update(returncode=code,timed_out=timed_out,completed_unix=time.time(),log_sha256=sha(out/'build.log'));save();assert not timed_out and code==0
  invocations=[line.strip() for line in (out/'build.log').read_text().splitlines() if 'Running' in line and '/rustc ' in line and 'CARGO_MANIFEST_DIR='+str(work)+'/' in line];assert len(invocations)==3
  for crate in ['oriole_storage','oriole','oriole_expat']:assert sum('--crate-name '+crate+' ' in line for line in invocations)==1
  (out/'workspace-compiler-invocations.json').write_text(json.dumps(invocations,indent=2)+'\n');item['workspace_compilations']=3;item['libraries']={}
  for name in ['liboriole_expat.so','liboriole_expat.a']:
   shutil.copyfile(target/'release'/name,out/name);item['libraries'][name]=sha(out/name)
  assert {n:sha(work/n) for n in files}==files;item['source_unchanged']=True;item['status']='passed';save();print(label,item['libraries'],flush=True)
 report['status']='passed'
finally:save()
