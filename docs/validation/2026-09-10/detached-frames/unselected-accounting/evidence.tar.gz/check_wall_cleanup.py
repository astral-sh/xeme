from pathlib import Path
import ast,hashlib,json,os,signal,statistics,subprocess,time,types
R=Path('/tmp/oriole-unique-accounting-evidence');O=R/'wall-cleanup-negative';O.mkdir(exist_ok=False);source=R/'native_wall_final.py';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();tree=ast.parse(source.read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run')
worker=O/'worker.py';pidfile=O/'worker.pid';worker.write_text('#!/usr/bin/python3\nimport os,sys,time\nfrom pathlib import Path\nPath(sys.argv[1]).write_text(str(os.getpid()))\nprint("started",flush=True)\ntime.sleep(30)\n');worker.chmod(0o755)
class InterruptOnce:
 def __init__(self,*args,**kwargs):self.process=subprocess.Popen(*args,**kwargs);self.first=True
 @property
 def pid(self):return self.process.pid
 @property
 def returncode(self):return self.process.returncode
 def communicate(self,*args,**kwargs):
  if self.first:
   self.first=False;deadline=time.monotonic()+5
   while not pidfile.exists() and time.monotonic()<deadline:time.sleep(.01)
   assert pidfile.exists();raise KeyboardInterrupt('controlled interrupt after child startup')
  return self.process.communicate(*args,**kwargs)
def launch_failure(*args,**kwargs):raise OSError('controlled launch failure')
records=[]
for label,popen,exception in [('interrupted',InterruptOnce,KeyboardInterrupt),('launch-error',launch_failure,OSError)]:
 out=O/label;out.mkdir();report={'attempts':[]}
 def save(name,data): (out/name).write_text(json.dumps(data,indent=2)+'\n')
 fake=types.SimpleNamespace(Popen=popen,PIPE=subprocess.PIPE,TimeoutExpired=subprocess.TimeoutExpired)
 namespace={'driver':worker,'libraries':{'probe':pidfile},'O':out,'sha':sha,'os':os,'signal':signal,'subprocess':fake,'json':json,'time':time,'statistics':statistics,'save':save}
 exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),namespace)
 try:namespace['run']({'input':'unused','chunk':4096,'namespaces':False,'held_child':False},'probe',0,7,1,label,report,'attempt.json')
 except exception:pass
 else:raise AssertionError('expected controlled failure')
 assert len(report['attempts'])==1;row=report['attempts'][0];assert row['controller_exception']['type']==exception.__name__
 if label=='interrupted':
  pid=int(pidfile.read_text());assert row['returncode']==-signal.SIGKILL
  try:os.kill(pid,0)
  except ProcessLookupError:pass
  else:raise AssertionError('worker remains alive')
  assert (out/row['stdout_file']).read_text()=='started\n'
 else:assert row['returncode'] is None
 records.append({'case':label,'recorded':row,'child_reaped':label=='interrupted'})
result={'status':'passed','scope':'Exact final run() AST tested with synthetic worker and controlled KeyboardInterrupt/Popen error; no parser execution, no CPU0 work. Verifies process-group kill/reap and saved partial output/command/exception.','source_sha256':sha(source),'rows':records};(O/'report.json').write_text(json.dumps(result,indent=2)+'\n');print('cleanup passed')
