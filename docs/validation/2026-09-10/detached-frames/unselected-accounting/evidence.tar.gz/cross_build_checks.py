if not __debug__: raise RuntimeError('Assertions required')
from pathlib import Path
import hashlib,json,shutil,subprocess,time,os,signal
R=Path('/tmp/oriole-unique-accounting-evidence');O=R/'cross-build';O.mkdir(exist_ok=False);F=Path('/tmp/oriole-text-frame-prototype/text')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
PYTHON='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
source=Path('/tmp/oriole-c-text-boundaries/tools/xml_abi.py');shutil.copyfile(source,O/'xml_abi.py')
pairs={'baseline':(F/'liboriole_expat.so',Path('/tmp/oriole-verified-builds/e439/liboriole_expat.so')),'combined':(R/'liboriole_expat.so',R/'verified-builds/combined/liboriole_expat.so')}
report={'status':'incomplete','scope':'Strict saved-generator old/fresh cross-build controls: malformed text/default/event/error coordinates and UTF8/UTF16 streaming suspension/DefaultCurrent; no timing and no full API re-execution.','before':{str(p):sha(p) for pair in pairs.values() for p in pair},'generators':{str(F/n):sha(F/n) for n in ['malformed_probe.py','streaming_probe.py']},'xml_abi_sha256':sha(source),'rows':[]}
def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
for label,(old,new) in pairs.items():
 out=O/label;out.mkdir();shutil.copyfile(old,out/'control.so');shutil.copyfile(new,out/'liboriole_expat.so')
 for name in ['malformed_probe.py','streaming_probe.py']:
  script=(F/name).read_text().replace("sys.path.insert(0,'/tmp/oriole-c-text-boundaries/tools')",'sys.path.insert(0,'+repr(str(O))+')').replace("root=Path('/tmp/oriole-text-frame-prototype/text')",'root=Path('+repr(str(out))+')')
  path=out/name;path.write_text('if not __debug__: raise RuntimeError("Assertions required")\n'+script)
  cmd=['taskset','-c','7',PYTHON,'-I','-S',str(path)];start=time.time();timed_out=False
  with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
   p=subprocess.Popen(cmd,stdout=stdout,stderr=stderr,start_new_session=True)
   try:code=p.wait(timeout=240)
   except subprocess.TimeoutExpired:timed_out=True;os.killpg(p.pid,signal.SIGKILL);code=p.wait()
  row={'pair':label,'script':name,'script_sha256':sha(path),'command':cmd,'returncode':code,'timed_out':timed_out,'timeout_seconds':240,'started_unix':start,'completed_unix':time.time(),'stdout_sha256':sha(out/(name+'.stdout')),'stderr_sha256':sha(out/(name+'.stderr'))};report['rows'].append(row);save();assert code==0 and not timed_out;print(label,name,code,flush=True)
  if name=='streaming_probe.py':
   data=json.loads((out/'streaming-probe.json').read_text());rows=data['rows'];a=[{k:v for k,v in r.items() if k!='library'} for r in rows if r['library']=='control'];b=[{k:v for k,v in r.items() if k!='library'} for r in rows if r['library']=='liboriole_expat'];assert a==b and len(a)==16;row['exact_pairs']=16
  else:
   data=json.loads((out/'malformed-probe.json').read_text());assert not data['differences'];row['exact_pairs']=data['cases']
  save()
report['after']={p:sha(Path(p)) for p in report['before']};assert report['before']==report['after'];report['status']='passed';save()
