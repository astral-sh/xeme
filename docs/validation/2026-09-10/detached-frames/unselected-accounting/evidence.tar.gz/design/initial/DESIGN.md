# Unique-owner accounting feasibility on frozen e439

## Recommendation and scope

A bounded prototype is feasible: add a safe `Shared::get_mut(&mut self) -> Option<&mut T>`, then use it only for `Parser::account_source` and the C adapter's callback-byte charges. Keep the existing atomic paths whenever another owner exists. Leave the allocation tracker, input/child counters, and every `&self` expansion/attribute accounting path unchanged. This is a source-backed design, not an implemented or timed improvement.

The reviewed runtime is e4396b26b6c9e4ebea1e97b3f568199db90d79dc428f91d3c97855229cb484b0. All 68 source-manifest files were copied from its immutable archive and rehashed. No parser, benchmark, build, or runtime mutation was performed for this review.

## Actual operations

For a successful nonempty plain character-data span, including each lexical newline callback, the core calls `consume -> account_source -> EntityBudget::account`. The latter does one Relaxed fetch_update, two Relaxed direct/indirect loads, and one threshold load (plus a factor load once the activation threshold is reached). The initial RMW includes its own load and retry loop. The C adapter then performs one Relaxed fetch_update for callback payload bytes **before** selecting/invoking its text handler, including when the handler is absent. The e439 x86-64 disassembly contains `lock cmpxchg` at 0x82998 (source accounting), 0x3401a (text frame), 0x341fa (start frame), and 0x367ba (ordinary event callback charge).

Thus two counter RMWs per nonempty delivered text span are eligible in a root-only parser. This is not a total atomic count for the entire parse: growth/free, parser feeds, entity references, DTD sharing, and callbacks that call APIs add operations. Core `account_source(0)` also runs at each event-loop entry; `accounting_bytes(0)` ordinarily returns zero and `EntityBudget::account` currently performs **no atomics** then. Do not add uniqueness probes on that zero-byte fast return. Calls to `account_source` in the profile are therefore not the count of RMWs.

Neither FamilyBudget nor EntityBudget is cloned for a text event. `RecyclingToken` is a scalar generation, not a shared owner; its process-global ID RMW happens at construction. Adapter text <=23 bytes is inline. Eligible larger text reuses the bounded frame buffer; it does not necessarily allocate once per callback. `save_current_raw` can independently grow raw storage.

`XML_Parse` itself takes/drops one AllocationTracker owner (two refcount RMWs), updates family input bytes, and updates root tracker direct bytes. Those are per API invocation, not per text event, and are outside this proposal.

## Why safe unique mutation is available

Shared has only strong owners; there is no Weak, raw-owner constructor, DerefMut, or clone-on-write API. Its clone increments the count with a Relaxed RMW; drop decrements with Release and uses an Acquire fence before final destruction.

A new `get_mut` must require **exclusive `&mut Shared<T>`**, read the reference count with Acquire, return None unless it is exactly one, and only then form an exclusive reference to the **value field**. Do not form `&mut Inner<T>` before proving uniqueness, and do not make value exclusivity depend on a sampled strong_count read through `&Shared`. The returned lifetime stays tied to the exclusive handle borrow. That borrow prevents cloning/access through the same owner; another live owner or in-flight clone requires count >=2. Once count one is observed, no Weak owner can create another owner. The Acquire load synchronizes preceding owners' Release decrements and their accesses before relinquishing ownership. Keep the existing Send/Sync bounds unchanged.

The atomic counters can then use their safe `get_mut()` APIs under that exclusive value reference. There remains one Acquire reference-count load per uniqueness check, plus ordinary integer loads/stores/checks. On the reviewed x86 build an Acquire load needs no locked instruction, but this does not quantify latency or prove a throughput win. Shared-owner inputs pay the added check before the existing atomic path.

## Owner lifetimes and callback safety

Core EntityBudget is created once and cloned only by `external_child_with_encoding`. C FamilyBudget is created once and cloned only into an external parser. No frame, input allocation, or tracking scope owns either budget. A root-only parser therefore has one owner even if it has many tracked allocations. Existing children keep these budgets shared even while idle; after their destruction the remaining parser can become unique again. A retained child after parent destruction can also be the sole owner: uniqueness is the criterion, not root/child flags.

Reset constructs a fresh core/budget and C family before replacing the old parser state. Retained children keep old budgets; reset must not redirect their counts. The tracker deliberately remains shared across reset and is not included here.

`account_source` already has `&mut Parser`. Compute raw byte delta and indirect/source flags first. If bytes == 0, retain the current no-atomic success path and accounted-source update. Otherwise obtain `&mut self.expanded`, call the unique helper if get_mut succeeds or the old atomic helper if it fails, end that borrow, then construct an error or mark source accounting at exactly the current point. No parser-field or budget reference may survive to any foreign callback.

For the C callback helper, borrow only `&mut (*parser).family` in the existing pre-callback charge scope. Charge the copied payload length, end the borrow, then call fail_parse or copy callback/argument scalars. Replace all three existing callback charging sites (ordinary Event, start frame, text frame), retaining their existing position/base/payload calculations and handler-independent charging. Do not hold a unique budget reference for an entire run_events loop or across a callback. A callback can create/free children, parse a different child, suspend, or change handlers; reevaluate ownership at the next charge. Same-parser parse/reset/free guards remain unchanged. Allocator callbacks cannot reenter C APIs, but the proposed helper itself neither allocates nor invokes one. Safe Rust child parsers may move across threads; the shared atomic fallback remains in place whenever another owner exists.

## Exact counter and error order

- Core bytes conversion failure: return false without mutation, as now. bytes==0 returns true immediately.
- Core selected counter overflow: return false without mutation. On a successful increment, store the new direct/indirect counter **before** checking direct+indirect overflow, activation threshold, or amplification. A later failure intentionally leaves that increment recorded. Do not turn this into a transaction or roll it back.
- Preserve short-circuit order: total overflow is checked even if enforcement is off. A disabled-enforcement account skips threshold/factor access; below-threshold accounting skips factor/division. Preserve the direct==0 denominator of 22, the float conversions/comparison, and NaN/infinity setter behavior.
- On core rejection, do not advance `accounted_raw`, consume source bytes, or expose the prepared text event. Preserve the same sticky error and position handling.
- C callback charge has different semantics: checked_add and <=64MiB must both succeed **before** storing the new count. Failure leaves the prior count and raises the same error43 before the callback. Keep zero-amount behavior, existing base additions, and the fact that unhandled semantic payloads are charged.
- Leave 8MiB absolute entity work, 512MiB live allocation, relative amplification factors/thresholds, token/count/depth caps, selected allocator, all allocation order and OOM paths unchanged. No new allocation is required by either helper.

## AllocationTracker is deliberately excluded

Every tracked allocation header retains a Shared<AllocationTracker>. The parser owns another, and with_parser_tracking owns a local clone throughout its operation. Resize clones its header's owner before a foreign realloc may move memory. Returned allocations may outlive their parser and be freed outside the original tracking scope, including on another allowed thread. Therefore tracker strong_count is not one during an ordinary parser allocation or charge; parser-family serialization does not establish exclusive tracker ownership. Adding get_mut there would ordinarily add overhead without eliminating its atomic work. Do not use a root/children flag or a strong_count observation through a shared reference to bypass this.

At the source API level a successful positive tracked allocation performs one owner-clone RMW, one live-reservation RMW and a peak fetch_max; freeing performs a live-release RMW and owner-drop RMW. Growth adds a temporary-owner clone/drop around its charge. Preserve reservation-before-allocator, failed-allocation rollback, peak including failed reservations, original-header ownership across realloc, and release/drop order. The proposal changes none of this.

## Quantification from existing saved profiles

The twelve existing project/namespace Callgrind profiles each collect two parses (warmup + measured), chunk4096. They record instruction counts and call edges, not locked-operation cycles or retired-atomic hardware events. `profile-counts.json` reconstructs all relevant edges; namespaces do not change the listed text delivery counts.

| Project | Text-frame deliveries / parse | Ordinary owned text callbacks / parse | Eligible source + text-frame counter RMW removals / parse |
|---|---:|---:|---:|
| Vulkan | 109344 | 49 | 218688 |
| Wayland | 5966 | 0 | 11932 |
| Maven | 3152 | 0 | 6304 |
| Batik | 189 | 0 | 378 |
| GTK | 1145 | 4 | 2290 |
| Docbook | 702 | 4 | 1404 |

The final column is a source-implied count for the two accounting sites on nonempty frames in these successful single-parser drivers; it excludes additional eligible C charges on start/end/owned events and nontext core tokens. It is **not** a measured instruction delta: a unique fast path adds checks and ordinary operations. The callback-only seam also covers the owned-text column, while their additional core reference work remains partly on the unchanged `&self` paths.

For Wayland plain, account_source self instructions are 1,677,880 / 40,285,484 = 4.165%; run_events self instructions are 1,008,402 / 40,285,484 = 2.503%. These entire functions include source metadata, branching, dispatch and frame work. Their sum is not the atomic share and is not a forecast of removable instructions. See the generated report for all twelve shares. Existing profiles cannot establish locked-instruction latency, cache contention or net throughput. A later prototype needs instruction comparison first and, only if justified, one predeclared timing study with ordinary and child-heavy controls.

## Review and validation plan before selecting a prototype

1. Independently review Shared get_mut's unsafe field access and Acquire/Release proof. Tests: unique mutation, clone refusal, drop-to-unique, cross-thread previous-owner write then Release drop/Acquire acquisition, selected allocator exact free/drop once, and existing Shared Send/Sync behavior. No new allocation on get_mut success or failure.
2. Exercise the core unique and shared paths with identical direct/indirect sequences, zero bytes, counter/total overflow, activation boundary, direct==0, rejected increments, infinite factor, and sticky parser failures. Assert internal counter values where public event output cannot expose state. Keep `&self` helper behavior unchanged.
3. C controls: exact callback-byte ceiling and rejected increment for handlers enabled/disabled, text frame versus owned reference/CR/custom text, default fallback, child creation in a text callback (unique→shared), child free (shared→unique), retained child after parent free/reset, suspend/resume, and callback-time handler/limit changes. Add no held field reference across a callback. Run existing allocation-failure/family/custom-converter tests unchanged.
4. Compare all original 4740 API outcomes against the exact e439 baseline, focused callback/position/origin tests, full Rust and C sanitizer/allocation checks. This is accounting implementation only: any callback/error/counter or OOM schedule difference needs explanation, not a waiver.
5. Measure isolated callback-only and core-only increments to attribute costs, retaining shared-owner adverse controls and all samples. No adoption or performance claim until those gates exist.
