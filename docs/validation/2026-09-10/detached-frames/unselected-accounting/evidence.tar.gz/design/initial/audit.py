import hashlib,json,re,tarfile
from pathlib import Path
root=Path('/tmp/oriole-text-atomic-review'); original=Path('/tmp/oriole-text-frame-prototype/text')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((original/'source.json').read_text())['source_sha256']
assert len(source)==68
assert sha(original/'source.json')=='73d6f17165eaa936871e5da41d0aa9eb2b9fb7dd3d6233f87ef714b81f38b96c'
assert sha(original/'liboriole_expat.so')=='e4396b26b6c9e4ebea1e97b3f568199db90d79dc428f91d3c97855229cb484b0'
with tarfile.open(original/'source.tar.gz') as t:
 files={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}
assert files==source
for p,h in source.items():assert sha(root/'source'/p)==h,p
manifest=json.loads((original/'manifest.json').read_text())['files']
inputs=[original/'source.json',original/'source.tar.gz',original/'manifest.json',original/'liboriole_expat.so',root/'DESIGN.md',root/'profile_counts.py',root/'profile-counts.json']
profiles=json.loads((root/'profile-counts.json').read_text())['rows']; findings=[]
for p in profiles:
 path=Path(p['file']); relative=str(path.relative_to(original));assert sha(path)==p['sha256']==manifest[relative]['sha256']
 meta=json.loads((path.parent/'profiles.json').read_text());name=path.name.split('-ns')[0];ns='ns1' in path.name
 observation=next(r for r in meta['rows'] if r['workload']==name and r['namespaces']==ns and r['library']=='candidate')
 assert observation['Ir']==p['Ir']
 for symbol,value in p['self_Ir'].items():
  observed=sum(f['Ir'] for f in observation['functions'] if f['function']=='???:'+symbol)
  assert observed==value,(name,symbol,observed,value)
 text=sum(e['calls'] for e in p['text_edges'] if e['caller']=='oriole_expat::run_events');owned=sum(e['calls'] for e in p['text_edges'] if e['caller']=='oriole_expat::dispatch')
 assert text%2==owned%2==0
 findings.append({'project':name,'namespaces':ns,'collected_parses':2,'frame_text_callbacks_per_parse':text//2,'owned_text_callbacks_per_parse':owned//2,'source_implied_eligible_frame_counter_RMWs_per_parse':text,'total_Ir':p['Ir'],'account_source_self_Ir':p['self_Ir']['<oriole::Parser>::account_source'],'account_source_self_Ir_fraction':p['self_Ir']['<oriole::Parser>::account_source']/p['Ir'],'run_events_self_Ir':p['self_Ir']['oriole_expat::run_events'],'run_events_self_Ir_fraction':p['self_Ir']['oriole_expat::run_events']/p['Ir']})
 inputs +=[path,path.parent/'profiles.json']
# Retain only function blocks needed to independently inspect exact locked sites.
dis=(root/'disassembly.txt').read_text(); blocks=re.split(r'\n(?=[0-9a-f]{16} <)',dis)
selected=[]
for b in blocks:
 if any(n in b.splitlines()[0] for n in ['<oriole::Parser>::account_source>', 'oriole_expat::run_events>', 'oriole_expat::dispatch>']):selected.append(b)
extract='\n'.join(selected)+'\n';assert len(selected)==3
for address in ['82998:', '3401a:', '341fa:', '367ba:']:assert address in extract and 'lock cmpxchg' in next(s for s in extract.splitlines() if address in s)
(root/'accounting-disassembly.txt').write_text(extract)
report={'status':'feasible_bounded_design_not_implemented_or_selected','scope':'Read-only frozen source, release disassembly and existing Callgrind saved-data reconstruction. No build/parser/profiler/timing rerun, no runtime edits.','source_verified_files':68,'library_sha256':sha(original/'liboriole_expat.so'),'source_manifest_sha256':sha(original/'source.json'),'package_manifest_sha256':sha(original/'manifest.json'),'design_sha256':sha(root/'DESIGN.md'),'recommendation':'Safe Shared::get_mut unique-owner primitive, used only by core account_source and all three CFamily callback-byte charge sites; preserve shared atomic fallback and exact error/counter order. Leave allocation tracker, input/child counters and &self charge_expansion/account_entity_bytes unchanged.','two_counter_RMWs_per_nonempty_text_span':True,'safe_ownership_proof':'Exclusive handle borrow + Acquire count==1 + no Weak/raw owner creation; borrow only value after check. No borrow across callback.','allocation_tracker_excluded':'Allocation headers, parser and active tracking scope retain independent owners even with one parser.','profile_scope':'Twelve XML_Parse-only chunk4096 profiles; two collected parses each. Function self-Ir includes non-accounting work, and calls to account_source include zero-byte no-atomic paths. Dynamic edges do not measure locked-instruction latency.','profiles':findings,'semantic_constraints':['core successful counter increment remains recorded on subsequent total-overflow/relative-cap rejection','C callback rejected increment leaves prior counter unchanged','core zero-byte path does not gain a uniqueness probe','no allocation/OOM schedule or limit change','unique borrow ends before errors, callbacks, allocator hooks or next event'],'files':{str(p):sha(p) for p in sorted(set(inputs+[root/'accounting-disassembly.txt',root/'audit.py']))}}
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS',len(source),'source files',len(profiles),'existing profiles',sha(root/'report.json'))
