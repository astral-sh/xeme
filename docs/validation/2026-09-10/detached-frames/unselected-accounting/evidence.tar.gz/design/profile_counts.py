import re,json,hashlib
from pathlib import Path
root=Path('/tmp/oriole-text-frame-prototype/text')
rows=[]
for folder in ['profile','profile-controls']:
 for p in sorted((root/folder).glob('*-candidate.out')):
  names={}; current=None;callee=None; edges=[];self_cost={};pending_call=False
  for line in p.read_text().splitlines():
   m=re.match(r'(c?fn)=\((\d+)\)(?: (.*))?$',line)
   if m:
    field,key,name=m.groups()
    if name is not None:
     if key in names: assert names[key]==name
     names[key]=name
    if field=='fn':current=key
    else:callee=key
    continue
   if line.startswith('calls='):
    n=int(line.split('=',1)[1].split()[0]);edges.append((current,callee,n));pending_call=True
    continue
   if re.match(r'^\d+ ',line):
    n=int(line.split()[1])
    if not pending_call:self_cost[current]=self_cost.get(current,0)+n
    pending_call=False
  resolved=[{'caller':names[a],'callee':names[b],'calls':n} for a,b,n in edges]
  def calls(name):return sum(x['calls'] for x in resolved if x['callee']==name)
  total=int(re.search(r'^summary: (\d+)',p.read_text(),re.M).group(1))
  row={'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'Ir':total,'calls':{},'self_Ir':{},'text_edges':[],'account_source_edges':[]}
  for name in ['text','start','end','<oriole::Parser>::account_source','<oriole::Parser>::consume','<oriole::Parser>::parse_text','oriole_expat::run_events']:
   row['calls'][name]=calls(name)
   row['self_Ir'][name]=sum(n for k,n in self_cost.items() if names[k]==name)
  row['text_edges']=[x for x in resolved if x['callee']=='text']
  row['account_source_edges']=[x for x in resolved if x['callee']=='<oriole::Parser>::account_source']
  rows.append(row)
Path('/tmp/oriole-text-atomic-review/profile-counts.json').write_text(json.dumps({'scope':'Existing Callgrind XML_Parse-only profiles; both warmup and measured parse collected; dynamic function entries, not hardware atomic/cycle measurements. No new parser runs.','rows':rows},indent=2)+'\n')
for r in rows:
 print(Path(r['file']).name, r['calls'],r['text_edges'])
