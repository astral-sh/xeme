if not __debug__: raise RuntimeError("Validation assertions require normal Python execution")
from pathlib import Path
import hashlib,json,shutil,subprocess,os,time,signal
R=Path('/tmp/oriole-unique-accounting-evidence');B=Path('/tmp/oriole-ns-tag-plan-gates');F=Path('/tmp/oriole-text-frame-prototype/text');T=R/'api-tools'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
observed=[*T.iterdir(),R/'liboriole_expat.so',R/'liboriole_expat.a',B/'upstream-api-canonical-baseline/results.json',B/'upstream-api-canonical-baseline/manifest.json']
report=json.loads((R/'api-native-initial.json').read_text());report['postprocessing_note']='Initial comparison stopped after successful API execution because it compared absolute output paths and the directory inventory including unused README/allocator_repro and copied wrapper/config. This continuation normalizes only output directory paths, verifies all five used adapter source hashes, and retains all actual manifest differences. No parser rerun.'
def run(label,cmd,timeout,env=None):
 cmd=['taskset','-c','7',*cmd];started=time.time();out=R/(label+'.stdout');err=R/(label+'.stderr')
 timed_out=False
 with out.open('wb') as f,err.open('wb') as e:
  process=subprocess.Popen(cmd,stdout=f,stderr=e,env=env,start_new_session=True)
  try:code=process.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(process.pid,signal.SIGKILL);code=process.wait()
 row={'label':label,'command':cmd,'returncode':code,'timed_out':timed_out,'timeout_seconds':timeout,'started_unix':started,'completed_unix':time.time(),'stdout_sha256':sha(out),'stderr_sha256':sha(err)};report['rows'].append(row);(R/'api-native.json').write_text(json.dumps(report,indent=2)+'\n');print(label,code,flush=True);assert not timed_out;return row
PYTHON='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
a=json.loads((B/'upstream-api-canonical-baseline/results.json').read_text());b=json.loads((R/'upstream-api/results.json').read_text());assert b['selection_complete'] and b['library_origin_verified'] and not b['timed_out'];assert len(a['results'])==len(b['results'])==4740
am=json.loads((B/'upstream-api-canonical-baseline/manifest.json').read_text());bm=json.loads((R/'upstream-api/manifest.json').read_text())
manifest_changes={k:{'baseline':am.get(k),'candidate':bm.get(k)} for k in am.keys()|bm.keys() if am.get(k)!=bm.get(k)}
assert set(manifest_changes)=={'library_sha256','binary_sha256','adapter_sources','compile_command'}
for name in ['run.py','runner.c','bridge.c','bridge.h','memcheck.patch']:assert am['adapter_sources'][name]==bm['adapter_sources'][name]
assert set(am['adapter_sources'])-set(bm['adapter_sources'])=={'README.md','allocator_repro.c'}
assert set(bm['adapter_sources'])-set(am['adapter_sources'])=={'expat_config.h','run_clean.py'}
assert [x.replace(str(B/'upstream-api-canonical-baseline'),'<OUTPUT>') for x in am['compile_command']]==[x.replace(str(R/'upstream-api'),'<OUTPUT>') for x in bm['compile_command']]
assert {k:v for k,v in am.items() if k not in manifest_changes}=={k:v for k,v in bm.items() if k not in manifest_changes}
report['manifest_changes']=manifest_changes
aa={(r['test'],r['context']):r for r in a['results']};bb={(r['test'],r['context']):r for r in b['results']};assert aa.keys()==bb.keys();changes=[{'baseline':aa[k],'candidate':bb[k]} for k in aa if aa[k]!=bb[k]]
(R/'api-comparison.json').write_text(json.dumps({'baseline_source':str(B/'upstream-api-canonical-baseline'),'baseline_results_sha256':sha(B/'upstream-api-canonical-baseline/results.json'),'candidate_results_sha256':sha(R/'upstream-api/results.json'),'passed':b['passed'],'failed':b['failed'],'all4740rows_exact':not changes,'changes':changes,'manifest_identical_except_library_binary_output_paths_and_directory_inventory':True,'manifest_changes':manifest_changes},indent=2)+'\n');assert not changes,changes
native=R/'native';native.mkdir(exist_ok=False)
for n in ['adversarial.c','allocations.c','integration.c','expat.h']:shutil.copyfile(F/'native'/n,native/n)
for linkage in ['dynamic','static']:
 for name in ['integration','adversarial','allocations']:
  exe=native/(name+'-'+linkage);cmd=['cc','-std=c11','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(native),str(native/(name+'.c'))]
  cmd+=['-L',str(R),'-loriole_expat','-Wl,-rpath,'+str(R)] if linkage=='dynamic' else [str(R/'liboriole_expat.a'),'-ldl','-lpthread','-lm'];cmd+=['-o',str(exe)]
  label='native-'+name+'-'+linkage;assert run(label+'-build',cmd,120)['returncode']==0
  environment={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'}
  row=run(label,[str(exe)],120,environment);row['binary_sha256']=sha(exe);assert row['returncode']==0
report['native_sources']={str(p):sha(p) for p in native.iterdir() if p.suffix in ['.c','.h']};report['after']={p:sha(Path(p)) for p in report['before']};assert report['after']==report['before'];report['status']='passed_exact_canonical_api_and_six_native_consumers';(R/'api-native.json').write_text(json.dumps(report,indent=2)+'\n')
