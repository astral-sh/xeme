from pathlib import Path
import ctypes as c,hashlib,json
R=Path('/tmp/oriole-unique-accounting-evidence');rows=[]
for name,path in [('e439','/tmp/oriole-text-frame-prototype/text/liboriole_expat.so'),('combined195db',str(R/'liboriole_expat.so')),('stale_mode_control4ee','/tmp/oriole-e439-no-ohm-defaults/liboriole_expat.so')]:
 p=Path(path);before=hashlib.sha256(p.read_bytes()).hexdigest();l=c.CDLL(path);callback=c.CFUNCTYPE(None,c.c_void_p,c.c_void_p,c.c_int);events=[]
 @callback
 def text(_,data,n):events.append(c.string_at(data,n).hex())
 l.XML_ParserCreate.argtypes=[c.c_void_p];l.XML_ParserCreate.restype=c.c_void_p;l.XML_SetCharacterDataHandler.argtypes=[c.c_void_p,callback];l.XML_Parse.argtypes=[c.c_void_p,c.c_char_p,c.c_int,c.c_int];l.XML_Parse.restype=c.c_int;l.XML_ParserFree.argtypes=[c.c_void_p]
 parser=l.XML_ParserCreate(None);assert parser;l.XML_SetCharacterDataHandler(parser,text);data=b'<r>a\nb</r>';status=l.XML_Parse(parser,data,len(data),1);l.XML_ParserFree(parser);assert status==1;assert before==hashlib.sha256(p.read_bytes()).hexdigest();rows.append({'label':name,'library':path,'sha256':before,'status':status,'text_callback_hex':events})
assert rows[0]['text_callback_hex']==rows[1]['text_callback_hex']==['61','0a','62'];assert rows[2]['text_callback_hex']==['610a62']
(R/'library-fingerprint.json').write_text(json.dumps({'scope':'One untimed UTF8 literal-LF text callback fingerprint per exact library; confirms195db preserves faithful e439 boundary whereas stale no-default output reflects coalesced source. This plus reviewed unique-counter assembly is a discriminant, not a whole source-to-binary proof.','rows':rows},indent=2)+'\n')
print(rows)
