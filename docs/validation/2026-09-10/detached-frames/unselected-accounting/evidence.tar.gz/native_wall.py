"""Frozen native wall protocol; timing requires a separate CPU0 lease."""
if not __debug__: raise RuntimeError('Assertions required')
from pathlib import Path
import hashlib,json,os,random,signal,statistics,subprocess,sys,time
R=Path('/tmp/oriole-unique-accounting-evidence');O=R/'native-wall';manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
driver=R/'shared-driver';normal_driver=Path('/tmp/oriole-grammar-bench-plain/native-driver')
libraries={'baseline':Path('/tmp/oriole-verified-builds/e439/liboriole_expat.so'),'combined':R/'verified-builds/combined/liboriole_expat.so'}
iterations={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
fixtures={}
for project in json.loads(manifest.read_text())['projects']:
 f=next(x for x in project['files'] if x['role']=='input');p=(manifest.parent/f['path']).resolve();assert sha(p)==f['sha256'];fixtures[project['name']]=p
fixtures['generated-rare-declarations']=Path('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml');fixtures['generated-entities']=Path('/tmp/oriole-grammar-bench-plain/entities.xml')
conditions=[{'name':name,'input':str(p),'chunk':chunk,'namespaces':ns,'held_child':False,'iterations':iterations[name]} for chunk in (4096,65536) for name,p in fixtures.items() for ns in ((False,) if name.startswith('generated-') else (False,True))]
assert len(conditions)==28
conditions += [{'name':name,'input':str(fixtures[name]),'chunk':4096,'namespaces':False,'held_child':True,'iterations':iterations[name]} for name in ['vulkan','wayland','batik','generated-entities']]
assert len(conditions)==32
files=[Path(__file__),manifest,driver,R/'shared_driver.c',normal_driver,*libraries.values(),*fixtures.values(),R/'verified-builds/report.json',Path('/tmp/oriole-verified-builds/report.json'),Path('/tmp/oriole-unique-accounting-shared-driver-review.json')]
hashes={str(p):sha(p) for p in files}
protocol={'scope':'Native C callback lifecycle wall time, matched fresh no-default builds e43916dd versus combined938f. Six pinned real projects in both namespace modes at4/64KiB, two generated controls at both widths, plus four synthetic held-child controls at4KiB. Selected-driver preflights must match established native-driver output in all28 ordinary conditions. Native hashes ignore text callback fragmentation; separate strict cross-build probes cover full events/positions. No PGO, no application timing, no reference Expat timing. Retained empty-context child is Oriole-only owner-count control; elapsed time includes its construct/free cost. Shared host. All samples and unsuccessful attempts retained; no outlier removal.','libraries':{k:{'path':str(p),'sha256':sha(p)} for k,p in libraries.items()},'conditions':conditions,'pairs':7,'seed':2026091027,'preflight_processes':64,'ordinary_driver_equivalence_processes':56,'timed_workers':448,'hashes':hashes}
def save(name,data):(O/name).write_text(json.dumps(data,indent=2)+'\n')
def key(c):return json.dumps(c,sort_keys=True)
def run(c,engine,pair,cpu,count,kind,report,save_name,selected_driver=driver):
 cmd=['taskset','-c',str(cpu),str(selected_driver),str(libraries[engine]),c['input'],str(c['chunk']),str(count)]+(['namespaces'] if c['namespaces'] else [])+(['hold-child'] if c['held_child'] else [])
 index=len(report['attempts']);stem=f'{kind}-{index:04d}';out=O/(stem+'.stdout');err=O/(stem+'.stderr');start=time.time();timed_out=False
 process=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 try:stdout,stderr=process.communicate(timeout=90)
 except subprocess.TimeoutExpired:timed_out=True;os.killpg(process.pid,signal.SIGKILL);stdout,stderr=process.communicate()
 out.write_bytes(stdout);err.write_bytes(stderr);row={'condition':c,'engine':engine,'pair':pair,'command':cmd,'returncode':process.returncode,'timed_out':timed_out,'timeout_seconds':90,'started_unix':start,'completed_unix':time.time(),'stdout_file':out.name,'stderr_file':err.name,'stdout_sha256':sha(out),'stderr_sha256':sha(err)}
 report['attempts'].append(row);save(save_name,report);assert process.returncode==0 and not timed_out and not stderr,row
 samples=json.loads(stdout)['samples'];assert len(samples)==count+1;assert [s['iteration'] for s in samples]==list(range(count+1));assert [s['warmup'] for s in samples]==[True]+[False]*count;assert all(s['seconds']>0 for s in samples)
 observations=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in samples});assert len(observations)==1;row['observations']=[list(x) for x in observations];row['median_seconds']=statistics.median(s['seconds'] for s in samples[1:]);row['measured_samples']=count;return row
phase=sys.argv[1]
if phase=='preflight':
 assert os.sched_getaffinity(0)=={7};O.mkdir(exist_ok=False);save('protocol.json',protocol)
 report={'status':'incomplete','protocol_sha256':sha(O/'protocol.json'),'hashes_before':hashes,'affinity':sorted(os.sched_getaffinity(0)),'attempts':[],'rows':[],'normal_driver_equivalence':[]}
 try:
  for c in conditions:
   rows=[run(c,e,-1,7,1,'preflight',report,'preflight.json') for e in libraries];assert rows[0]['observations']==rows[1]['observations'];report['rows'].extend(rows)
   if not c['held_child']:
    for e in libraries:
     row=run(c,e,-1,7,1,'normal-driver',report,'preflight.json',normal_driver);assert row['observations']==rows[0]['observations'];report['normal_driver_equivalence'].append(row)
  assert len(report['rows'])==64 and len(report['normal_driver_equivalence'])==56 and len(report['attempts'])==120
  report['hashes_after']={p:sha(p) for p in hashes};assert report['hashes_after']==hashes;report['status']='passed'
 finally:save('preflight.json',report)
 print('preflight',report['status'],len(report['attempts']),flush=True)
else:
 assert phase=='time' and os.sched_getaffinity(0)=={0};assert json.loads((O/'protocol.json').read_text())==protocol
 preflight=json.loads((O/'preflight.json').read_text());assert preflight['status']=='passed' and preflight['hashes_after']==hashes
 expected={key(r['condition']):r['observations'] for r in preflight['rows']};rng=random.Random(protocol['seed']);jobs=[(c,pair) for c in conditions for pair in range(7)];rng.shuffle(jobs)
 report={'status':'incomplete','protocol_sha256':sha(O/'protocol.json'),'preflight_sha256':sha(O/'preflight.json'),'hashes_before':hashes,'affinity':sorted(os.sched_getaffinity(0)),'attempts':[],'rows':[],'summary':[],'started_unix':time.time()}
 try:
  for c,pair in jobs:
   order=list(libraries);rng.shuffle(order);rows=[run(c,e,pair,0,c['iterations'],'time',report,'results.json') for e in order];assert all(r['observations']==expected[key(c)] for r in rows)
   report['rows'].append({'condition':c,'pair':pair,'order':order,'processes':rows});save('results.json',report)
  for c in conditions:
   groups=[r for r in report['rows'] if r['condition']==c];assert len(groups)==7
   ratios=[]
   for group in groups:
    values={r['engine']:r['median_seconds'] for r in group['processes']};ratios.append(values['combined']/values['baseline'])
   report['summary'].append({'condition':c,'paired_candidate_over_baseline':ratios,'median_candidate_over_baseline':statistics.median(ratios)})
  assert len(report['rows'])==224 and len(report['attempts'])==448 and len(report['summary'])==32
  report['hashes_after']={p:sha(p) for p in hashes};assert report['hashes_after']==hashes;report['status']='passed'
 finally:report['completed_unix']=time.time();save('results.json',report)
 print('time',report['status'],len(report['attempts']),flush=True)
