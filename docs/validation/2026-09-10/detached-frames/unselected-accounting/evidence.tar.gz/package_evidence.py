import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

SRC = Path('/tmp/oriole-unique-accounting-evidence')
OUT = Path('/tmp/oriole-unique-accounting-handoff')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

assert not OUT.exists(), 'immutable output already exists'
audit = Path('/tmp/oriole-unique-accounting-wall-independent-review')
assert sha((audit / 'review.json').read_bytes()) == '0752a5755de9544b43cf7c320b9240b5f78b3ce1f3d64986f5202bd5b5015429'
for name in ['review.json', 'audit.py', 'raw-artifacts.json']:
    shutil.copy2(audit / name, SRC / 'reviews' / ('wall-independent-' + name))

# Preserve exact small/generated inputs; real project bytes have a separate,
# repository-maintained corpus manifest, also copied here for offline replay.
protocol = json.loads((SRC / 'native-wall-final/protocol.json').read_text())
corpus = SRC / 'inputs'
corpus.mkdir(exist_ok=True)
inputs = {}
for path, digest in protocol['hashes'].items():
    p = Path(path)
    if p.suffix not in {'.xml', '.svg', '.ui', '.xsl'}:
        continue
    data = p.read_bytes()
    assert sha(data) == digest
    name = p.parent.name + '-' + p.name
    dest = corpus / name
    if dest.exists():
        assert dest.read_bytes() == data
    else:
        dest.write_bytes(data)
    inputs[path] = {'archive_path': str(dest.relative_to(SRC)), 'sha256': digest}
write(corpus / 'origins.json', inputs)
shutil.copy2('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json', corpus / 'corpus-manifest.json')
shutil.copy2(__file__, SRC / 'package_evidence.py')

files = {}
excluded = {}
for p in sorted(SRC.rglob('*')):
    assert not p.is_symlink(), f'unexpected symlink {p}'
    if not p.is_file():
        continue
    rel = str(p.relative_to(SRC))
    data = p.read_bytes()
    reason = None
    if '__pycache__' in p.parts or p.suffix == '.pyc':
        reason = 'generated Python cache'
    elif data.startswith(b'\x7fELF') or data.startswith(b'!<arch>\n'):
        reason = 'executable/shared/static binary; identity retained'
    entry = {'sha256': sha(data), 'bytes': len(data)}
    if reason:
        excluded[rel] = dict(entry, reason=reason)
    else:
        files[rel] = entry

OUT.mkdir()
archive = OUT / 'evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for rel, entry in files.items():
                data = (SRC / rel).read_bytes()
                assert sha(data) == entry['sha256']
                info = tarfile.TarInfo(rel)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
write(OUT / 'members.json', files)
write(OUT / 'excluded-binaries-and-cache.json', excluded)
shutil.copy2(SRC / 'README.md', OUT / 'README.md')
write(OUT / 'summary.json', {
    'status': 'unselected',
    'reason': 'No measured wall-time benefit; no further tuning or integration.',
    'source_manifest_sha256': sha((SRC / 'final-source-freeze/source.json').read_bytes()),
    'default_mode_gate_library_sha256': '195db6a38344b24d95abe14cb09ef0b14f2cade2fadf298d585de04069b88e7b',
    'fresh_matched_libraries': json.loads((audit / 'review.json').read_text())['identities'],
    'default_mode_tests': 391,
    'default_mode_original_api': {'pass': 4323, 'fail': 417, 'exact_rows_equal': 4740},
    'default_mode_native_c_sanitizer_runs': 6,
    'allocation_scenarios_per_linkage': 327,
    'strict_cross_build_comparisons': 4816,
    'instruction_profiles': 40,
    'wall': json.loads((audit / 'review.json').read_text())['groups'],
    'wall_counts': json.loads((audit / 'review.json').read_text())['counts'],
    'wall_independent_review_sha256': sha((audit / 'review.json').read_bytes()),
    'archive_sha256': sha(archive.read_bytes()),
    'archive_members': len(files),
    'archive_uncompressed_bytes': sum(v['bytes'] for v in files.values()),
    'limitations': ['Native lifecycle timing on shared host, no application/Expat timing claim.', 'Default-mode full gates and fresh-mode attribution are separate artifacts.', 'C-only sanitizers; Rust release uninstrumented; LeakSanitizer disabled.'],
})
print(json.dumps({'output': str(OUT), 'members': len(files), 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes())}))
