if not __debug__: raise RuntimeError("Validation assertions require normal Python execution")
from pathlib import Path
import hashlib,json,os,re,subprocess,time,signal
R=Path('/tmp/oriole-unique-accounting-evidence');P=R/'profiles';P.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def limited(command,timeout,environment=None):
 p=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=environment,start_new_session=True)
 timed_out=False
 try:stdout,stderr=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate()
 return p.returncode,stdout,stderr,timed_out
profroot=Path('/home/dev-user/.cache/oriole/profilers/local/usr');valgrind=profroot/'bin/valgrind';annotator=profroot/'bin/callgrind_annotate'
manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
fixtures={p['name']:(manifest.parent/next(f['path'] for f in p['files'] if f['role']=='input')).resolve() for p in json.loads(manifest.read_text())['projects'] if p['name'] in ['wayland','vulkan','batik']}
fixtures['entities']=Path('/tmp/oriole-grammar-bench-plain/entities.xml')
libraries={'original':Path('/tmp/oriole-text-frame-prototype/text/liboriole_expat.so'),'rebuilt':R/'rebuilt-baseline/liboriole_expat.so','core':R/'core-only/liboriole_expat.so','callback':R/'callback-only/liboriole_expat.so','combined':R/'liboriole_expat.so'}
driver=R/'shared-driver';source=R/'shared_driver.c';command=['taskset','-c','7','cc','-std=c11','-O3','-g','-Wall','-Wextra','-Werror','-rdynamic',str(source),'-ldl','-o',str(driver)]
started=time.time();code,stdout,stderr,timed_out=limited(command,60);(P/'driver-build.stdout').write_bytes(stdout);(P/'driver-build.stderr').write_bytes(stderr)
build_row={'command':command,'started_unix':started,'completed_unix':time.time(),'returncode':code,'timed_out':timed_out,'timeout_seconds':60,'source_sha256':sha(source),'stdout_sha256':sha(P/'driver-build.stdout'),'stderr_sha256':sha(P/'driver-build.stderr')}
(P/'driver-build.json').write_text(json.dumps(build_row,indent=2)+'\n');assert not timed_out and code==0
observed=[Path(__file__),source,driver,valgrind,annotator,manifest,*fixtures.values(),*libraries.values(),R/'variant-builds.json',R/'final-source-freeze/source.json',Path('/tmp/oriole-unique-accounting-shared-driver-review.json')]
report={'scope':'Callgrind XML_Parse-only instruction counts, callbacks included; no wall-time claims. Four inputs, plain namespaces, 4096-byte feeds, unique versus retained synthetic empty-context child, five builds. Both warmup and one measured parse are collected. Held-child is Oriole-only owner-count control, not reference conformance. Constructor/free excluded by collection toggle; driver seconds nevertheless include them and are ignored.','driver_build':{**build_row,'binary_sha256':sha(driver)},'environment':{'VALGRIND_LIB':str(profroot/'libexec/valgrind')},'before':{str(p):sha(p) for p in observed},'status':'incomplete','attempts':[],'preflights':[],'rows':[]}
env={**os.environ,**report['environment']}
def save(): (P/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def process(stem,command,timeout):
 start=time.time();code,stdout,stderr,timed_out=limited(command,timeout,env)
 out=P/(stem+'.stdout');err=P/(stem+'.stderr');out.write_bytes(stdout);err.write_bytes(stderr)
 row={'stem':stem,'command':command,'timeout_seconds':timeout,'timed_out':timed_out,'returncode':code,'started_unix':start,'completed_unix':time.time(),'stdout_sha256':sha(out),'stderr_sha256':sha(err)}
 report['attempts'].append(row)
 if timed_out or code!=0:report['status']='failed_process'
 save()
 assert not timed_out and code==0,(stem,row)
 return row,stdout,stderr
def run(stem,command,timeout):
 row,stdout,stderr=process(stem,command,timeout)
 data=json.loads(stdout);samples=data['samples'];assert len(samples)==2 and samples[0]['warmup'] and not samples[1]['warmup'];obs=[{k:s[k] for k in ['hash','elements','text_bytes']} for s in samples];assert obs[0]==obs[1];row['observations']=obs
 return row
# Complete all output and loader-origin preflights before profiles.
for name,fixture in fixtures.items():
 for held in [False,True]:
  expected=None
  for label,library in libraries.items():
   stem=f'preflight-{name}-held{int(held)}-{label}';cmd=['taskset','-c','7',str(driver),str(library),str(fixture),'4096','1']+(['hold-child'] if held else [])
   row=run(stem,cmd,60);assert not (P/(stem+'.stderr')).read_bytes();assert expected is None or row['observations']==expected;expected=row['observations'];row.update(workload=name,held_child=held,library=label);report['preflights'].append(row);save()
for name,fixture in fixtures.items():
 for held in [False,True]:
  for label,library in libraries.items():
   stem=f'{name}-held{int(held)}-{label}';out=P/(stem+'.callgrind');cmd=['taskset','-c','7',str(valgrind),'--tool=callgrind','--toggle-collect=XML_Parse','--callgrind-out-file='+str(out),str(driver),str(library),str(fixture),'4096','1']+(['hold-child'] if held else [])
   row=run(stem,cmd,240);raw=out.read_text();total=int(re.search(r'^summary: (\d+)',raw,re.M).group(1));assert total>0;assert int(re.search(r'Collected\s*:\s*(\d+)',(P/(stem+'.stderr')).read_text()).group(1))==total
   previous=next(r for r in report['preflights'] if r['workload']==name and r['held_child']==held and r['library']==label);assert row['observations']==previous['observations']
   cmd2=['taskset','-c','7',str(annotator),'--auto=no','--threshold=100','--show-percs=no',str(out)];annotation,stdout,stderr=process(stem+'-annotation',cmd2,60);(P/(stem+'.annotated')).write_bytes(stdout)
   row.update(workload=name,held_child=held,library=label,Ir=total,callgrind_sha256=sha(out),annotation_sha256=sha(P/(stem+'.annotated')),annotation_command=cmd2)
   report['rows'].append(row);save();print(stem,total,flush=True)
comparisons=[]
for name in fixtures:
 for held in [False,True]:
  values={r['library']:r['Ir'] for r in report['rows'] if r['workload']==name and r['held_child']==held};comparisons.append({'workload':name,'held_child':held,'Ir':values,'candidate_over_rebuilt':{k:v/values['rebuilt'] for k,v in values.items()},'candidate_over_original':{k:v/values['original'] for k,v in values.items()}})
report['comparisons']=comparisons;report['after']={p:sha(Path(p)) for p in report['before']};assert report['before']==report['after'];assert len(report['rows'])==40 and len(report['preflights'])==40 and len(report['attempts'])==120;report['status']='passed';save()
