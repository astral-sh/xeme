"""Reconstruct saved instruction attribution; never execute a parser/build."""
from pathlib import Path
import hashlib
import json
import re
import shlex
import sys
import tarfile
sys.path.insert(0, '/tmp/oriole-delivery-wrapper-study')
from extract import extract

if not __debug__:
    raise RuntimeError('Assertions must run')
ROOT = Path('/tmp/oriole-unique-accounting-evidence')
P = ROOT / 'profiles-verified'
OUT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

report = json.loads((P / 'report.json').read_text())
builds = json.loads((ROOT / 'verified-builds/report.json').read_text())
baseline = json.loads(Path('/tmp/oriole-verified-builds/report.json').read_text())
normalized_baseline = json.loads(Path('/tmp/oriole-build-provenance-independent-review/fresh-build-details.json').read_text())['normalized_rustc_args']
assert report['status'] == builds['status'] == 'passed'
assert report['before'] == report['after']
assert all(sha(Path(p)) == h for p, h in report['before'].items())
assert sha(Path('/tmp/oriole-verified-builds/report.json')) == builds['root_report_sha256']
assert builds['baseline_libraries'] == baseline['variants']['e439']['libraries']
hashes = {str(P / 'report.json'): sha(P / 'report.json'), str(ROOT / 'verified-builds/report.json'): sha(ROOT / 'verified-builds/report.json')}
build_details = {}
private_dirs = set()
for label, row in builds['variants'].items():
    r = ROOT / 'verified-builds' / label
    assert row['status'] == 'passed' and row['returncode'] == 0 and not row['timed_out']
    assert row['source_unchanged'] and sha(r / 'build.log') == row['log_sha256']
    assert sha(r / 'source.json') == row['source_manifest_sha256']
    source = json.loads((r / 'source.json').read_text())
    expected = source['source_sha256']
    assert all(sha(Path(row['cwd']) / n) == h for n, h in expected.items())
    parent = Path(source['parent_manifest'])
    assert sha(parent) == source['parent_manifest_sha256']
    parent_data = json.loads(parent.read_text())
    assert parent_data.get('files', parent_data.get('source_sha256')) == expected
    with tarfile.open(r / 'source.tar.gz', 'r:gz') as archive:
        members = archive.getmembers()
        assert all(x.isfile() for x in members)
        assert len(members) == len(expected)
        assert {x.name: hashlib.sha256(archive.extractfile(x).read()).hexdigest() for x in members} == expected
    commands = re.findall(r'Running `(.*?)`\n', (r / 'build.log').read_text(), re.S)
    normalized = {}
    dirs = set()
    for text in commands:
        argv = shlex.split(text)
        if '--crate-name' not in argv:
            continue
        idx = next(i for i, x in enumerate(argv) if x.endswith('/bin/rustc'))
        env = dict(x.split('=', 1) for x in argv[:idx])
        args = argv[idx + 1:]
        crate = args[args.index('--crate-name') + 1]
        deps = args[args.index('--out-dir') + 1]
        dirs.add(deps)
        if crate.startswith('oriole'):
            assert env['CARGO_MANIFEST_DIR'] == row['cwd'] + '/crates/' + crate
        normalized[crate] = [x.replace(deps, '<PRIVATE-DEPS>').replace(row['cwd'], '<SOURCE>') for x in args]
    assert normalized == normalized_baseline
    assert len(dirs) == 1
    deps = next(iter(dirs))
    assert deps not in private_dirs and deps.startswith('/home/dev-user/.cache/ohm/verified-build/')
    private_dirs.add(deps)
    for n, digest in row['libraries'].items():
        assert sha(r / n) == digest == sha(Path(deps) / n)
    build_details[label] = {'source_files': len(expected), 'private_deps': deps, 'compiler_invocations': len(normalized), 'effective_flags_equal_verified_baseline': True, 'libraries': row['libraries']}
    for n in ['source.json', 'source.tar.gz', 'build.log', 'liboriole_expat.so', 'liboriole_expat.a']:
        hashes[str(r / n)] = sha(r / n)

assert len(report['attempts']) == 120
for row in report['attempts']:
    assert row['returncode'] == 0 and not row['timed_out']
    assert row['command'][:3] == ['taskset', '-c', '7']
    for suffix in ['stdout', 'stderr']:
        p = P / (row['stem'] + '.' + suffix)
        assert sha(p) == row[suffix + '_sha256']
        hashes[str(p)] = sha(p)
expected_keys = {(w, held, lib) for w in ['wayland', 'vulkan', 'batik', 'entities'] for held in [False, True] for lib in ['original', 'rebuilt', 'core', 'callback', 'combined']}
assert len(report['preflights']) == len(report['rows']) == 40

def verify_samples(row):
    data = json.loads((P / (row['stem'] + '.stdout')).read_text())
    assert len(data['samples']) == 2
    assert [(s['iteration'], s['warmup']) for s in data['samples']] == [(0, True), (1, False)]
    obs = [{k: s[k] for k in ['hash', 'elements', 'text_bytes']} for s in data['samples']]
    assert obs[0] == obs[1] and obs == row['observations']
    assert ('hold-child' in row['command']) == row['held_child']
    assert '--toggle-collect=XML_Parse' in row['command'] or row['stem'].startswith('preflight-')
    return obs

preflight = {}
for row in report['preflights']:
    key = (row['workload'], row['held_child'], row['library'])
    assert key not in preflight
    preflight[key] = verify_samples(row)
assert set(preflight) == expected_keys
for w in ['wayland', 'vulkan', 'batik', 'entities']:
    assert all(preflight[(w, held, lib)] == preflight[(w, False, 'rebuilt')] for held in [False, True] for lib in ['original', 'rebuilt', 'core', 'callback', 'combined'])
values = {}
for row in report['rows']:
    key = (row['workload'], row['held_child'], row['library'])
    assert key not in values
    assert verify_samples(row) == preflight[key]
    p = P / (row['stem'] + '.callgrind')
    assert sha(p) == row['callgrind_sha256']
    extracted = extract(p)
    assert extracted['total_Ir'] == row['Ir']
    stderr = (P / (row['stem'] + '.stderr')).read_text()
    assert int(re.search(r'Collected\s*:\s*(\d+)', stderr).group(1)) == row['Ir']
    assert sha(P / (row['stem'] + '.annotated')) == row['annotation_sha256']
    hashes[str(p)] = sha(p)
    values[key] = row['Ir']
assert set(values) == expected_keys
for comparison in report['comparisons']:
    w, held = comparison['workload'], comparison['held_child']
    v = {lib: values[(w, held, lib)] for lib in ['original', 'rebuilt', 'core', 'callback', 'combined']}
    assert v == comparison['Ir']
    assert {k: n / v['rebuilt'] for k, n in v.items()} == comparison['candidate_over_rebuilt']
    assert {k: n / v['original'] for k, n in v.items()} == comparison['candidate_over_original']
assert len(report['comparisons']) == 8
driver = report['driver_build']
assert driver['returncode'] == 0 and not driver['timed_out']
assert sha(ROOT / 'shared_driver.c') == driver['source_sha256']
assert sha(ROOT / 'shared-driver') == driver['binary_sha256']
for suffix in ['stdout', 'stderr']:
    assert sha(P / ('driver-build.' + suffix)) == driver[suffix + '_sha256']
result = {
    'status': 'passed',
    'scope': 'Saved source/build/instruction arithmetic audit only; no compiler, parser or profile executions.',
    'counts': {'preflights': 40, 'profile_processes': 40, 'annotation_processes': 40, 'preflight_parse_samples': 80, 'profile_parse_samples_both_collected': 80, 'ratio_groups': 8, 'matched_variant_full_compilations': 18, 'matched_variant_workspace_compilations': 9},
    'builds': build_details,
    'comparisons': report['comparisons'],
    'conclusion': 'All frozen build inputs, metadata controls, disjoint instruction totals and ratios reproduce. Combined unique-owner instructions are essentially flat and shared-owner controls regress slightly. No wall-time or adoption claim is supported.',
    'limits': [
        'Original e439 default-Ohm binary is retained only as a diagnostic. Matched ratios use fresh16dd baseline and three equally built no-default variants.',
        'Held synthetic empty-context child is an Oriole owner-count control, not Expat API conformance; it also changes retained child/cache state.',
        'XML_Parse-only collection includes callbacks and both warmup/measured parses; constructor/free and the driver wall seconds are excluded from interpretation.',
        'Metadata hash/count agreement is the selected driver contract, not a full serialized callback transcript.',
        'The successful source controller records timeout/nonzero outputs; interruption/launch-error failure preservation is less complete than reusable production tooling. No such failure occurred in these saved120 attempts.',
        'No namespace configurations or sustained sanitizer campaign were run for this attribution. Prior full gates remain on their separately named195db build.'
    ],
    'evidence_sha256': hashes,
}
(OUT / 'review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'path': str(OUT / 'review.json'), 'sha256': sha(OUT / 'review.json'), 'raw_hashes': len(hashes)}))
