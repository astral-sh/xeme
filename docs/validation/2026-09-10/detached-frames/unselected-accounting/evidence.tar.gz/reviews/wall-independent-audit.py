"""Reconstruct frozen native lifecycle timings from retained worker outputs only."""
import hashlib
import json
import math
import random
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path('/tmp/oriole-unique-accounting-evidence')
DATA = ROOT/'native-wall-final'
OUT = Path(__file__).parent
hashes = {}

def read(path):
    path = Path(path)
    data = path.read_bytes()
    hashes[str(path)] = hashlib.sha256(data).hexdigest()
    return data

def load(path):
    return json.loads(read(path))

def sha(path):
    read(path)
    return hashes[str(Path(path))]

def key(c):
    return json.dumps(c,sort_keys=True)

protocol = load(DATA/'protocol.json')
preflight = load(DATA/'preflight.json')
result = load(DATA/'results.json')
summary = load(ROOT/'wall-summary.json')
completion = load(DATA/'controller-completion.json')
assert sha(ROOT/'native_wall_final.py') == '8d6ecf1406eb13c3611f267bfa51c59e5365b3ec486b70d8088475600cc4cee1'
assert sha(DATA/'protocol.json') == 'd5b543c39a5968abed72f6acb32d07d097324851bf9cc854f2f00abcd5d17974'
assert sha(DATA/'preflight.json') == '5417cd76cc598ef86aba745280daecc93c08baf5dbf871e5cb881b703e6cf2c6'
assert sha(DATA/'results.json') == '5c7990ea694d7e66cb3e9f1e20bd20c008f88d0c55a26ae282156d7b14cec90b'
assert completion['exit_code'] == 0 and completion['tool_completion_observed']
assert completion['result_sha256'] == sha(DATA/'results.json')
assert protocol['pairs'] == 7 and protocol['seed'] == 2026091027
assert protocol['timed_workers'] == 448 and len(protocol['conditions']) == 32
assert preflight['status'] == result['status'] == summary['status'] == 'passed'
assert result['affinity'] == [0] and preflight['affinity'] == [7]
for report in [preflight,result]:
    assert report['protocol_sha256'] == sha(DATA/'protocol.json')
    assert report['hashes_before'] == report['hashes_after'] == protocol['hashes']
for path,digest in protocol['hashes'].items():
    assert sha(path) == digest,path
for engine,lib in protocol['libraries'].items():
    assert sha(lib['path']) == lib['sha256']
assert protocol['libraries']['baseline']['sha256'] == '16dd25ddf3d3782bdafbdd5845180795632875cca04f36457f668f9212c0ec58'
assert protocol['libraries']['combined']['sha256'] == '938f6f5f6fbdce56cd5ab7f07f358ca21e191cd6f15f12d23194c2ee759e4db3'
assert result['preflight_sha256'] == sha(DATA/'preflight.json')
for field, file in [('result_sha256','results.json'),('protocol_sha256','protocol.json'),('preflight_sha256','preflight.json')]:
    assert summary[field] == sha(DATA/file)

# Existing independent source/build/Ir audit is separate. Rehash its receipt,
# not a claim to rerun compilation or re-derive compiler mode in this timing audit.
prior = Path('/tmp/oriole-unique-accounting-profile-independent-review/review.json')
assert sha(prior) == '8f22c73c8617fda2ba7da3fe3b3316eabba641156a595fa33d091d864a9c5f68'
source_review = Path('/tmp/oriole-unique-accounting-wall-final-review.json')
assert sha(source_review) == '30159118244754a287a7aedcdb83031fd995dfde09d1dde783f64701a64aae1c'

real = ['vulkan','wayland','maven','batik','gtk','docbook']
generated = ['generated-rare-declarations','generated-entities']
iterations = dict(zip(real,[7,64,128,512,256,256])) | dict.fromkeys(generated,32)
conditions = protocol['conditions']
assert [(c['name'],c['chunk'],c['namespaces'],c['held_child']) for c in conditions] == [
    (name,width,ns,False) for width in [4096,65536] for name in real+generated for ns in ([False,True] if name in real else [False])
] + [(name,4096,False,True) for name in ['vulkan','wayland','batik','generated-entities']]
assert all(c['iterations'] == iterations[c['name']] for c in conditions)

counts = defaultdict(int)
observations = {}
def check_attempt(row,count,cpu,driver):
    c=row['condition'];engine=row['engine']
    command=['taskset','-c',str(cpu),driver,protocol['libraries'][engine]['path'],c['input'],str(c['chunk']),str(count)]
    command += ['namespaces'] if c['namespaces'] else []
    command += ['hold-child'] if c['held_child'] else []
    assert row['command'] == command
    assert row['returncode'] == 0 and not row['timed_out'] and row['controller_exception'] is None
    assert row['timeout_seconds'] == 90 and row['completed_unix'] >= row['started_unix']
    for stream in ['stdout','stderr']:
        assert sha(DATA/row[stream+'_file']) == row[stream+'_sha256']
    assert not read(DATA/row['stderr_file'])
    output=load(DATA/row['stdout_file']);samples=output['samples']
    assert output['version'] == 'oriole_compat_2.8.4'
    assert len(samples)==count+1
    assert [s['iteration'] for s in samples] == list(range(count+1))
    assert [s['warmup'] for s in samples] == [True]+[False]*count
    assert all(math.isfinite(s['seconds']) and s['seconds']>0 for s in samples)
    metadata=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in samples})
    assert len(metadata)==1 and row['observations']==[list(x) for x in metadata]
    assert row['median_seconds']==statistics.median(s['seconds'] for s in samples[1:])
    assert row['measured_samples']==count
    k=key(c)
    if k in observations: assert row['observations']==observations[k]
    else: observations[k]=row['observations']
    phase='timed' if cpu==0 else 'preflight'
    counts[phase+'_processes']+=1;counts[phase+'_samples']+=count;counts[phase+'_warmups']+=1

driver=str(ROOT/'shared-driver');normal='/tmp/oriole-grammar-bench-plain/native-driver'
assert len(preflight['attempts'])==120 and len(preflight['rows'])==64 and len(preflight['normal_driver_equivalence'])==56
expected_preflight=[];selected=[];parity=[]
for c in conditions:
    for e in ['baseline','combined']: expected_preflight.append((c,e,driver,selected))
    if not c['held_child']:
        for e in ['baseline','combined']:expected_preflight.append((c,e,normal,parity))
for row,(c,e,destination,target) in zip(preflight['attempts'],expected_preflight):
    assert row['condition']==c and row['engine']==e and row['pair']==-1
    check_attempt(row,1,7,destination);target.append(row)
assert selected==preflight['rows'] and parity==preflight['normal_driver_equivalence']
assert max(x['completed_unix'] for x in preflight['attempts']) < result['started_unix']

rng=random.Random(protocol['seed']);jobs=[(c,p) for c in conditions for p in range(7)];rng.shuffle(jobs)
assert len(result['rows'])==224 and len(result['attempts'])==448
flat=[];ratios=defaultdict(list);pair_keys=set()
for group,(c,pair) in zip(result['rows'],jobs):
    order=['baseline','combined'];rng.shuffle(order)
    assert group['condition']==c and group['pair']==pair and group['order']==order
    assert len(group['processes'])==2
    values={}
    for row,e in zip(group['processes'],order):
        assert row['condition']==c and row['engine']==e and row['pair']==pair
        check_attempt(row,c['iterations'],0,driver);values[e]=row['median_seconds'];flat.append(row)
    k=key(c);assert (k,pair) not in pair_keys;pair_keys.add((k,pair))
    ratios[k].append(values['combined']/values['baseline'])
assert flat==result['attempts']
assert all(a['completed_unix']<=b['started_unix'] for a,b in zip(flat,flat[1:]))
assert flat[0]['started_unix']>=result['started_unix'] and flat[-1]['completed_unix']<=result['completed_unix']
reconstructed=[{'condition':c,'paired_candidate_over_baseline':ratios[key(c)],'median_candidate_over_baseline':statistics.median(ratios[key(c)])} for c in conditions]
assert reconstructed==result['summary']==summary['conditions']

predicates={
    'real':lambda c:not c['held_child'] and c['name'] in real,
    'generated':lambda c:not c['held_child'] and c['name'] in generated,
    'held_child':lambda c:c['held_child'],
    'real_ns0':lambda c:not c['held_child'] and c['name'] in real and not c['namespaces'],
    'real_ns1':lambda c:not c['held_child'] and c['name'] in real and c['namespaces'],
}
groups={}
for label,predicate in predicates.items():
    values=[r['median_candidate_over_baseline'] for r in reconstructed if predicate(r['condition'])]
    group={'conditions':len(values),'candidate_over_baseline_geomean':math.exp(sum(math.log(v) for v in values)/len(values)),'faster_conditions':sum(v<1 for v in values),'minimum':min(values),'maximum':max(values)}
    assert group==summary['groups'][label],label
    groups[label]=group
assert counts=={'preflight_processes':120,'preflight_samples':120,'preflight_warmups':120,'timed_processes':448,'timed_samples':78890,'timed_warmups':448}
assert summary['measured_samples']==78890 and summary['warmups']==448
raw={p:h for p,h in hashes.items() if p.endswith(('.stdout','.stderr'))}
assert len(raw)==1136
(OUT/'raw-artifacts.json').write_text(json.dumps(raw,indent=2)+'\n')
report={
    'status':'passed','findings':[],
    'scope':'Saved-data independent audit only: no parser execution, builds, profiling or wall timing. Reconstructed every sample median, paired order/ratio, preflight metadata, hash and aggregate from frozen files.',
    'counts':dict(counts),'cohorts':224,'conditions':32,'paired_ratios':224,'raw_stream_files':len(raw),
    'groups':groups,
    'identities':protocol['libraries'],
    'interpretation':'Negative wall study retained. Combined unique accounting is slower in geometric means for real, generated and synthetic held-child groups; only 4/24 real and 2/4 generated conditions have lower median ratios, with 0/4 held-child wins. No adoption or general speed claim is supported.',
    'limits':[
        'Native C lifecycle timing includes parser construction, callbacks and destruction; synthetic held-child controls also include child construction/free. This is not XML_Parse-only instruction counting, CPython, full applications or a comparison with Expat.',
        'One warmup is discarded per worker, all fixed-count measured samples retained without outlier removal. Time ordering confirms this controller ran workers serially; it does not prove absence of unrelated host load.',
        'Selected callback hashes coalesce text fragmentation and cover chosen metadata, not all events or strict boundary semantics. Separate saved cross-build and source reviews cover those concerns.',
        'Source/compiler mapping is the previously independently audited fresh no-default mode. The earlier original-default 195db gates remain a separate artifact/build context.',
    ],
    'artifacts_sha256':{p:h for p,h in hashes.items() if p not in raw},
    'raw_hash_manifest_sha256':hashlib.sha256((OUT/'raw-artifacts.json').read_bytes()).hexdigest(),
}
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'counts':dict(counts),'groups':groups}))
