if not __debug__: raise RuntimeError("Validation assertions require normal Python execution")
from pathlib import Path
import hashlib,json,shutil,subprocess,os,time,signal
R=Path('/tmp/oriole-unique-accounting-evidence');B=Path('/tmp/oriole-ns-tag-plan-gates');F=Path('/tmp/oriole-text-frame-prototype/text');T=R/'api-tools';T.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['run.py','runner.c','bridge.c','bridge.h','memcheck.patch']:shutil.copyfile(B/'tools/upstream-expat'/n,T/n)
shutil.copyfile(B/'tools/run_clean.py',T/'run_clean.py');shutil.copyfile(B/'expat_config.h',T/'expat_config.h')
observed=[*T.iterdir(),R/'liboriole_expat.so',R/'liboriole_expat.a',B/'upstream-api-canonical-baseline/results.json',B/'upstream-api-canonical-baseline/manifest.json']
report={'scope':'Exact original4740 canonical3s/1GiBAS/768MiBRSS/240s versus strict e439; unchanged assertions/selection. Six native C ASan/UBSan consumers, Rust release not instrumented, LeakSanitizer disabled. No timing.','before':{str(p):sha(p) for p in observed},'rows':[]}
def run(label,cmd,timeout,env=None):
 cmd=['taskset','-c','7',*cmd];started=time.time();out=R/(label+'.stdout');err=R/(label+'.stderr')
 timed_out=False
 with out.open('wb') as f,err.open('wb') as e:
  process=subprocess.Popen(cmd,stdout=f,stderr=e,env=env,start_new_session=True)
  try:code=process.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(process.pid,signal.SIGKILL);code=process.wait()
 row={'label':label,'command':cmd,'returncode':code,'timed_out':timed_out,'timeout_seconds':timeout,'started_unix':started,'completed_unix':time.time(),'stdout_sha256':sha(out),'stderr_sha256':sha(err)};report['rows'].append(row);(R/'api-native.json').write_text(json.dumps(report,indent=2)+'\n');print(label,code,flush=True);assert not timed_out;return row
PYTHON='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
run('api',[PYTHON,'-I','-S',str(T/'run_clean.py'),str(T/'run.py'),'--source','/home/dev-user/.cache/oriole/upstream/expat-2.8.4','--config',str(T/'expat_config.h'),'--library',str(R/'liboriole_expat.so'),'--output',str(R/'upstream-api'),'--test-timeout','3','--memory-mib','1024','--rss-mib','768','--timeout','240'],300)
a=json.loads((B/'upstream-api-canonical-baseline/results.json').read_text());b=json.loads((R/'upstream-api/results.json').read_text());assert b['selection_complete'] and b['library_origin_verified'] and not b['timed_out'];assert len(a['results'])==len(b['results'])==4740
am=json.loads((B/'upstream-api-canonical-baseline/manifest.json').read_text());bm=json.loads((R/'upstream-api/manifest.json').read_text());assert {k:v for k,v in am.items() if k not in ['library_sha256','binary_sha256']}=={k:v for k,v in bm.items() if k not in ['library_sha256','binary_sha256']}
aa={(r['test'],r['context']):r for r in a['results']};bb={(r['test'],r['context']):r for r in b['results']};assert aa.keys()==bb.keys();changes=[{'baseline':aa[k],'candidate':bb[k]} for k in aa if aa[k]!=bb[k]]
(R/'api-comparison.json').write_text(json.dumps({'baseline_source':str(B/'upstream-api-canonical-baseline'),'baseline_results_sha256':sha(B/'upstream-api-canonical-baseline/results.json'),'candidate_results_sha256':sha(R/'upstream-api/results.json'),'passed':b['passed'],'failed':b['failed'],'all4740rows_exact':not changes,'changes':changes,'manifest_identical_except_library_binary':True},indent=2)+'\n');assert not changes,changes
native=R/'native';native.mkdir(exist_ok=False)
for n in ['adversarial.c','allocations.c','integration.c','expat.h']:shutil.copyfile(F/'native'/n,native/n)
for linkage in ['dynamic','static']:
 for name in ['integration','adversarial','allocations']:
  exe=native/(name+'-'+linkage);cmd=['cc','-std=c11','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(native),str(native/(name+'.c'))]
  cmd+=['-L',str(R),'-loriole_expat','-Wl,-rpath,'+str(R)] if linkage=='dynamic' else [str(R/'liboriole_expat.a'),'-ldl','-lpthread','-lm'];cmd+=['-o',str(exe)]
  label='native-'+name+'-'+linkage;assert run(label+'-build',cmd,120)['returncode']==0
  environment={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'}
  row=run(label,[str(exe)],120,environment);row['binary_sha256']=sha(exe);assert row['returncode']==0
report['native_sources']={str(p):sha(p) for p in native.iterdir() if p.suffix in ['.c','.h']};report['after']={p:sha(Path(p)) for p in report['before']};assert report['after']==report['before'];report['status']='passed_exact_canonical_api_and_six_native_consumers';(R/'api-native.json').write_text(json.dumps(report,indent=2)+'\n')
