import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/tmp/oriole-unique-accounting-evidence/focused-ffi');R.mkdir(exist_ok=False); W=Path('/tmp/oriole-unique-accounting')
env={**os.environ,'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/unique-accounting-target','CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'1'}
commands=[('c-transaction',['test','--release','-p','oriole_expat','callback_charges_keep']),('c-lifecycle',['test','--release','-p','oriole_expat','family_ownership_between']),('c-retained',['test','--release','-p','oriole_expat','retained_children_charge'])]
report={'scope':'First focused tests only, no broad API/native/timing gate','environment':{k:v for k,v in env.items() if k.startswith('CARGO_')},'sources_before':{str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in W.rglob('*.rs')},'commands':[]}
for label,args in commands:
 cmd=['taskset','-c','7','cargo','+ohm',*args];start=time.time();log=R/(label+'.log')
 with log.open('wb') as out:result=subprocess.run(cmd,cwd=W,env=env,stdout=out,stderr=subprocess.STDOUT)
 report['commands'].append({'label':label,'command':cmd,'returncode':result.returncode,'started_unix':start,'completed_unix':time.time(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()});(R/'focused.json').write_text(json.dumps(report,indent=2)+'\n');print(label,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
report['sources_after']={str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in W.rglob('*.rs')};assert report['sources_before']==report['sources_after'];report['status']='passed';(R/'focused.json').write_text(json.dumps(report,indent=2)+'\n')
