#!/usr/bin/python3
import os,sys,time
from pathlib import Path
Path(sys.argv[1]).write_text(str(os.getpid()))
print("started",flush=True)
time.sleep(30)
