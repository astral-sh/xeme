# DOCTYPE default callback delimiters

Base `9470934`; five-file isolated patch. A start-doctype callback consumes `>` for a declaration without an internal subset. Internal-subset `]` and whitespace are separate start-handler-controlled events before external loading; only the final `>` belongs to end-doctype fallback. A scalar adapter decision survives handler mutations, suspension and external callbacks, and resets with the parser.

All 268 core/FFI tests pass, including selected-allocation sweeps and 13 focused every-width handler/mutation/suspension/reset cases. Strict Clippy and formatting pass. The 4,104 focused UTF-8/UTF-16 cases match status/error and normalized event content/order. The custom provenance replay fixes 5,328 exact observations, including all 5,112 successful callback differences; the remaining 2,316 failed-input observations are unchanged. Original baseline and preformat observations are retained.

Exact fragmentation is a separate failed gate: 2,101 baseline differences become 360, with zero newly differing keys. These retain chunked closing-whitespace aggregation. No callback or limit failure is waived. The full strict observations are included.

`probe.py LIBRARY OUTPUT.json.gz` reproduces the focused matrix. `strict-probe.py` adds exact fragment arrays. The recorded custom replay generator references the retained base helper and frozen local library paths; adjust those paths to the copied helper and rebuilt libraries when replaying elsewhere. Commands/environment, source/library hashes, logs and independent source review accompany the patch. No binaries are included.
