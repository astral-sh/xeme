from pathlib import Path
import difflib,gzip,hashlib,json,re,shutil,subprocess,tarfile
r=Path('/tmp/oriole-doctype-default');e=Path('/tmp/oriole-doctype-default-review');o=Path('/tmp/oriole-doctype-default-handoff');o.mkdir(exist_ok=True)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=['crates/oriole/src/lib.rs','crates/oriole/src/dtd.rs','crates/oriole/tests/parser.rs','crates/oriole_expat/src/lib.rs','crates/oriole_expat/src/tests.rs'];patch=[]
for f in files:
 old=subprocess.check_output(['git','show','9470934:'+f],cwd='/home/dev-user/code/oss/oriole').decode();new=(r/f).read_text();patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+f,tofile='b/'+f))
(o/'doctype-default.patch').write_text(''.join(patch))
source={'base':'9470934','source':str(r),'files':{f:h(r/f) for f in files}}
(o/'source.json').write_text(json.dumps(source,indent=2)+'\n')
with tarfile.open(o/'changed-source.tar.gz','w:gz') as tar:
 for f in files:tar.add(r/f,arcname=f)
a=json.load(gzip.open('/tmp/oriole-custom-final/probes/external-comparison.json.gz','rt'));b=json.load(gzip.open(e/'custom-external-candidate.json.gz','rt'));key=lambda x:(x['case'],x['lead'],x['scalar'],x['chunk']);old={key(x):x for x in a['differences']};new={key(x):x for x in b['differences']}
custom={'cases':b['cases'],'baseline_differences':len(old),'final_differences':len(new),'fixed':len(old.keys()-new.keys()),'new_keys':len(new.keys()-old.keys()),'changed_retained_rows':sum(old[k]!=new[k] for k in old.keys()&new.keys()),'baseline_successful_callback_differences':5112,'final_successful_callback_differences':0}
(e/'custom-external-delta.json').write_text(json.dumps(custom,indent=2)+'\n')
for name in ['probe.py','strict-probe.py','custom-external.py','baseline.json.gz','candidate.json.gz','strict-baseline.json.gz','strict-candidate.json.gz','strict-delta.json','custom-external-candidate.json.gz','custom-external-delta.json','preformat-candidate.json.gz','preformat-custom-external-candidate.json.gz','package.py']:
 shutil.copy2(e/name,o/name)
shutil.copy2('/tmp/oriole-custom-final/probes/external-comparison.json.gz',o/'custom-external-baseline.json.gz')
shutil.copy2('/tmp/oriole-custom-alias-full-events-source.py',o/'custom-alias-full-events-source.py')
shutil.copy2('/tmp/oriole-doctype-default-independent-review.json',o/'independent-review.json')
for p in e.glob('*.log'):
 with gzip.open(o/(p.name+'.gz'),'wb') as f:f.write(p.read_bytes())
lib=Path('/home/dev-user/.cache/oriole/doctype-default-target/debug/liboriole_expat.so')
focused=json.load(gzip.open(e/'candidate.json.gz','rt'));strict=json.loads((e/'strict-delta.json').read_text())
assert focused['differences']==0 and focused['sha256']==b['sha256']==h(lib)
assert custom['new_keys']==custom['changed_retained_rows']==0
summary={'status':'targeted_raw_content_and_order_fixed','base':'9470934','library':str(lib),'library_sha256':h(lib),'source_manifest_sha256':h(o/'source.json'),'runtime_files':files[:2]+files[3:4],'validation':{'core_ffi_tests_passed':268,'selected_allocator_sweeps':'pass','focused_every_width_mutation_suspend_reset_cases':13,'fmt':'pass','strict_clippy':'pass','focused_reference_comparisons':4104,'focused_reference_differences':0,'custom_external_provenance':custom,'exact_fragment_baseline_differences':strict['baseline_full_event_differences'],'exact_fragment_remaining_differences':strict['candidate_full_event_differences'],'exact_fragment_new_keys':0},'remaining_limits':['The 360 exact-fragment differences remain failed observations: chunked closing whitespace is aggregated. Normalized comparison does not establish exact callback fragmentation or parse-return timing equivalence.','The 2316 custom failed-input observations remain byte-for-byte unchanged; none is waived.','This layer does not alter custom alias provenance, logical input budgets, external-child read tracking, or the diagnostic/location contract.'], 'review_note':'Root independently reviewed runtime before cargo fmt joined one scalar assignment line; subsequent changes only format/test type alias and regressions. No runtime semantic change followed review.', 'build_environment':{'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/doctype-default-target','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0','commands':['taskset -c 4 cargo +ohm build -p oriole_expat','taskset -c 4 cargo +ohm test -p oriole -p oriole_expat','taskset -c 4 cargo +ohm clippy -p oriole -p oriole_expat --all-targets -- -D warnings','taskset -c 4 cargo +ohm fmt --all --check']}}
(o/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(o/'README.md').write_text('''# DOCTYPE default callback delimiters

Base `9470934`; five-file isolated patch. A start-doctype callback consumes `>` for a declaration without an internal subset. Internal-subset `]` and whitespace are separate start-handler-controlled events before external loading; only the final `>` belongs to end-doctype fallback. A scalar adapter decision survives handler mutations, suspension and external callbacks, and resets with the parser.

All 268 core/FFI tests pass, including selected-allocation sweeps and 13 focused every-width handler/mutation/suspension/reset cases. Strict Clippy and formatting pass. The 4,104 focused UTF-8/UTF-16 cases match status/error and normalized event content/order. The custom provenance replay fixes 5,328 exact observations, including all 5,112 successful callback differences; the remaining 2,316 failed-input observations are unchanged. Original baseline and preformat observations are retained.

Exact fragmentation is a separate failed gate: 2,101 baseline differences become 360, with zero newly differing keys. These retain chunked closing-whitespace aggregation. No callback or limit failure is waived. The full strict observations are included.

`probe.py LIBRARY OUTPUT.json.gz` reproduces the focused matrix. `strict-probe.py` adds exact fragment arrays. The recorded custom replay generator references the retained base helper and frozen local library paths; adjust those paths to the copied helper and rebuilt libraries when replaying elsewhere. Commands/environment, source/library hashes, logs and independent source review accompany the patch. No binaries are included.
''')
manifest={p.name:{'sha256':h(p),'bytes':p.stat().st_size} for p in sorted(o.iterdir()) if p.is_file() and p.name!='artifact-manifest.json'}
(o/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'path':str(o),'files':len(manifest),'summary_sha256':h(o/'summary.json'),'patch_sha256':h(o/'doctype-default.patch'),'manifest_sha256':h(o/'artifact-manifest.json')}))
