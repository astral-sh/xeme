import ctypes as c
import gzip
import hashlib
import itertools
import json
import sys
from pathlib import Path

P=c.c_void_p; S=c.c_char_p; I=c.c_int
TEXT=c.CFUNCTYPE(None,P,P,I); DOCTYPE=c.CFUNCTYPE(None,P,S,S,S,I); VOID=c.CFUNCTYPE(None,P)
EXT=c.CFUNCTYPE(I,P,S,S,S,S); START=c.CFUNCTYPE(None,P,S,P); END=c.CFUNCTYPE(None,P,S)
class Engine:
 def __init__(self,path):
  self.path=path;self.lib=c.CDLL(path)
  for n,args,ret in [('XML_ParserCreate',[S],P),('XML_Parse',[P,S,I,I],I),('XML_ParserFree',[P],None),('XML_GetErrorCode',[P],I),('XML_SetStartDoctypeDeclHandler',[P,P],None),('XML_SetEndDoctypeDeclHandler',[P,P],None),('XML_SetDefaultHandlerExpand',[P,P],None),('XML_SetExternalEntityRefHandler',[P,P],None),('XML_SetStartElementHandler',[P,P],None),('XML_SetEndElementHandler',[P,P],None),('XML_SetParamEntityParsing',[P,I],I),('XML_StopParser',[P,I],I),('XML_ResumeParser',[P],I),('XML_ExternalEntityParserCreate',[P,S,S],P)]:
   f=getattr(self.lib,n);f.argtypes=args;f.restype=ret
 def parse(self,doc,handlers,action,chunk,encoding):
  l=self.lib;events=[];done=False;p=l.XML_ParserCreate(None)
  def apply(where):
   nonlocal done
   if done or not action.startswith(where+':'):return
   done=True;command=action.split(':')[1]
   if command=='start-on':l.XML_SetStartDoctypeDeclHandler(p,startdt)
   elif command=='start-off':l.XML_SetStartDoctypeDeclHandler(p,None)
   elif command=='end-on':l.XML_SetEndDoctypeDeclHandler(p,enddt)
   elif command=='end-off':l.XML_SetEndDoctypeDeclHandler(p,None)
   elif command=='default-off':l.XML_SetDefaultHandlerExpand(p,None)
   elif command=='stop':l.XML_StopParser(p,1)
  @TEXT
  def default(_,ptr,n):
   value=c.string_at(ptr,n).decode();events.append(['default',value])
   if value==']':apply('bracket')
  @DOCTYPE
  def startdt(_,name,system,public,subset):events.append(['doctype',subset]);apply('start')
  @VOID
  def enddt(_):events.append(['enddoctype']);apply('end')
  @EXT
  def external(parent,context,base,system,public):
   events.append(['external']);apply('external');child=l.XML_ExternalEntityParserCreate(parent,context,None)
   if not child:return 0
   status=l.XML_Parse(child,b'',0,1);l.XML_ParserFree(child);return status
  @START
  def start(_,name,attrs):events.append(['start'])
  @END
  def end(_,name):events.append(['end'])
  l.XML_SetDefaultHandlerExpand(p,default);l.XML_SetStartElementHandler(p,start);l.XML_SetEndElementHandler(p,end);l.XML_SetExternalEntityRefHandler(p,external);l.XML_SetParamEntityParsing(p,2)
  if handlers&1:l.XML_SetStartDoctypeDeclHandler(p,startdt)
  if handlers&2:l.XML_SetEndDoctypeDeclHandler(p,enddt)
  data=doc.encode(encoding)
  if encoding=='utf-16-le':data=b'\xff\xfe'+data
  elif encoding=='utf-16-be':data=b'\xfe\xff'+data
  width=chunk or len(data);status=1
  for off in range(0,len(data),width):
   part=data[off:off+width];status=l.XML_Parse(p,part,len(part),int(off+width>=len(data)))
   while status==2:status=l.XML_ResumeParser(p)
   if status!=1:break
  error=l.XML_GetErrorCode(p);l.XML_ParserFree(p)
  normalized=[]
  for event in events:
   if event[0]=='default' and normalized and normalized[-1][0]=='default':normalized[-1][1]+=event[1]
   else:normalized.append(event[:])
  return {'status':status,'error':error,'events':normalized,'fragments':events}

def main():
 candidate=sys.argv[1];dest=Path(sys.argv[2]);ref=Engine('/home/dev-user/.cache/oriole/expat-build/libexpat.so');new=Engine(candidate)
 docs=['<!DOCTYPE r><r/>','<!DOCTYPE r SYSTEM "dtd"><r/>','<!DOCTYPE r []><r/>','<!DOCTYPE r [ ] \n ><r/>','<!DOCTYPE r SYSTEM "dtd" []><r/>','<!DOCTYPE r SYSTEM "dtd" [ ] \n ><r/>']
 actions=['none']+[f'{at}:{act}' for at in ['start','external','bracket'] for act in ['start-on','start-off','end-on','end-off','default-off','stop']]
 rows=[];diff=[]
 for document,handlers,action,chunk,encoding in itertools.product(docs,range(4),actions,[0,1,7],['utf-8','utf-16-le','utf-16-be']):
  a=ref.parse(document,handlers,action,chunk,encoding);b=new.parse(document,handlers,action,chunk,encoding)
  row={'document':document,'handlers':handlers,'action':action,'chunk':chunk,'encoding':encoding,'reference':a,'candidate':b};rows.append(row)
  if a!=b:diff.append(row)
 report={'library':candidate,'sha256':hashlib.sha256(Path(candidate).read_bytes()).hexdigest(),'cases':len(rows),'differences':len(diff),'observations':rows}
 with gzip.open(dest,'wt') as f:json.dump(report,f)
 print(json.dumps({'cases':len(rows),'differences':len(diff),'examples':diff[:6]},indent=2))
if __name__=='__main__':main()
