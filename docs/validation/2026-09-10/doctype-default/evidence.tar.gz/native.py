from pathlib import Path
import hashlib,json,subprocess,os
root=Path('/tmp/oriole-doctype-integrated/native');root.mkdir(exist_ok=False)
source=Path('/home/dev-user/code/oss/oriole');libs=Path('/tmp/oriole-doctype-integrated')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
observed=[source/'include/expat.h',*(source/'tests/c').glob('*.c'),libs/'liboriole_expat.so',libs/'liboriole_expat.a']
report={'scope':'C ASan/UBSan with uninstrumented release Rust; leak sanitizer disabled.','sha256_before':{str(p):sha(p) for p in observed},'rows':[]}
try:
 for prior in json.loads(Path('/tmp/oriole-api-followup-retention-native/report.json').read_text())['rows']:
  command=[value.replace('/home/dev-user/code/oss/oriole-api-followup','/home/dev-user/code/oss/oriole').replace('/tmp/oriole-api-followup-retention-native',str(root)).replace('/tmp/oriole-api-followup-retention',str(libs)) for value in prior['command']]
  label=prior['case']+'-'+prior['linkage'];binary=root/label
  row={'case':prior['case'],'linkage':prior['linkage'],'command':command};report['rows'].append(row)
  with (root/(label+'-build.log')).open('w') as log:
   result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  row['build_exit_code']=result.returncode;assert result.returncode==0
  row['binary_sha256']=sha(binary);row['run_command']=['taskset','-c','1,3',str(binary)]
  with (root/(label+'.log')).open('w') as log:
   result=subprocess.run(row['run_command'],stdout=log,stderr=subprocess.STDOUT,timeout=120,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
  row['exit_code']=result.returncode;row['log_sha256']=sha(root/(label+'.log'));assert result.returncode==0
  print(label,result.returncode,flush=True)
 report['sha256_after']={str(p):sha(p) for p in observed};assert report['sha256_after']==report['sha256_before']
 report['status']='passed'
finally:
 (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
