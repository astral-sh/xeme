from pathlib import Path
import hashlib,json,gzip,tarfile,shutil
w=Path('/tmp/oriole-doctype-integrated');r=Path('/home/dev-user/code/oss/oriole');d=r/'docs/validation/2026-09-10/doctype-default';d.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((w/'source.json').read_text())
for f,h in source['source_sha256'].items():assert sha(r/f)==h,f
old=json.loads(Path('/tmp/oriole-missing-final/upstream-complete/results.json').read_text());new=json.loads((w/'upstream-api/results.json').read_text());assert old['results']==new['results'];assert new['selection_complete'] and new['library_origin_verified'] and not new['timed_out']
api={'baseline_library_sha256':'75beb3faf3b5677567b91f9abce4122ce563bbc360f9484bce5daad693e06838','candidate_library_sha256':source['library_sha256']['liboriole_expat.so'],'configurations':len(new['results']),'passed':new['passed'],'failed':new['failed'],'changed_outcomes':0};(w/'api-comparison.json').write_text(json.dumps(api,indent=2)+'\n')
focused=json.loads(gzip.decompress((w/'focused.json.gz').read_bytes()));strict=json.loads(gzip.decompress((w/'strict.json.gz').read_bytes()));custom=json.loads(gzip.decompress((w/'custom-external.json.gz').read_bytes()));prior=json.loads(gzip.decompress(Path('/tmp/oriole-custom-final/probes/external-comparison.json.gz').read_bytes()));key=lambda x:tuple(x[k] for k in ['case','scalar','lead','chunk']);pr={key(x):x for x in prior['differences']};cr={key(x):x for x in custom['differences']};assert all(pr[k]==v for k,v in cr.items());assert len(custom['differences'])==2316;assert focused['differences']==0 and strict['differences']==360
ordinary=json.loads((w/'differential/summary.json').read_text());assert ordinary['exact_pass'];native=json.loads((w/'native/report.json').read_text());assert native['status']=='passed'
shutil.copytree('/tmp/oriole-doctype-default-handoff',w/'isolated',dirs_exist_ok=True)
review=json.loads(Path('/tmp/oriole-doctype-default-independent-review.json').read_text());review['integration_parent']=source['parent_commit'];review['integrated_source_sha256']={f:source['source_sha256'][f] for f in review['source_sha256']};review['integration_checks']=['Original reviewed patch applies without changes on the name-edition and missing-PE parent.','Root independently replays focused, custom, ordinary and full upstream API suites on its frozen release build.'];(w/'integration-review.json').write_text(json.dumps(review,indent=2)+'\n')
validation={'rust_checks':source['tests_passed'],'clippy':'passed','fmt':'passed','ordinary':{k:ordinary[k] for k in ['cases','difference_counts','exact_pass']},'focused':{'cases':focused['cases'],'differences':focused['differences']},'exact_fragmentation':{'cases':strict['cases'],'differences':strict['differences'],'gate':'failed; existing whitespace chunk aggregation retained'},'custom_external':{'cases':custom['cases'],'remaining_observations':len(cr),'fixed_observations':len(pr)-len(cr),'successful_callback_differences':0,'new_differing_keys':0,'remaining_observations_unchanged':True},'upstream':api,'native_suites':6,'allocation_scenarios_per_linkage':336};(w/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
entries={}
for p in sorted(w.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 entries[str(p.relative_to(w))]={'sha256':sha(p),'bytes':p.stat().st_size}
with tarfile.open(d/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for f in entries:t.add(w/f,arcname=f,recursive=False)
with tarfile.open(d/'evidence.tar.gz') as t:
 for f in t:assert hashlib.sha256(t.extractfile(f).read()).hexdigest()==entries[f.name]['sha256']
manifest={'archive_sha256':sha(d/'evidence.tar.gz'),'members':entries};(d/'files.json').write_text(json.dumps(manifest,indent=2)+'\n');(d/'report.json').write_text(json.dumps(validation,indent=2)+'\n')
(d/'README.md').write_text(f'''# Preserve DOCTYPE callback delimiters

A start-doctype callback handles the closing `>` of a declaration without an internal subset. With an internal subset, the closing bracket and whitespace belong to the current start-handler state before external loading; the final `>` belongs to end-doctype handling. We retain that decision across handler changes, suspension and external callbacks, and reset it with the parser.

The integrated release library is `{source['library_sha256']['liboriole_expat.so']}` on parent `{source['parent_commit']}`. **280 Rust checks**, strict Clippy/formatting, **1,518 exact ordinary comparisons**, and six shared/static native suites pass, including **336 allocation failure scenarios per linkage**. C callers use ASan/UBSan; Rust is uninstrumented, leak sanitizer is disabled, and selected live allocations are checked.

All **4,104** focused handler/mutation/chunk/UTF-8/UTF-16 conditions match callback content/order and acceptance/errors. The **7,644** custom external-DTD conditions fix **5,328** observations, including every **5,112** successful callback-content difference. All **2,316** remaining failed-input observations are byte-for-byte unchanged. The unchanged full **4,740** API matrix stays **4,065 passed / 675 failed**, with no changed outcomes.

Exact fragment boundaries remain a failed gate: **360** focused conditions aggregate existing closing-whitespace chunks differently. Their callback content/order matches; no extra delimiter bytes remain. The isolated baseline, intermediate formatting checkpoint, full raw observations and failed strict gate are retained. This layer does not claim new project throughput, CPython or PBS measurements.

[evidence.tar.gz](evidence.tar.gz) contains frozen source/build hashes, raw results, scoped independent source review and integration checks. ELF/static binaries are excluded and identified by hash. [files.json](files.json) verifies every archive member. Archive SHA256: `{manifest['archive_sha256']}`.
''')
print(json.dumps({'members':len(entries),'archive_bytes':(d/'evidence.tar.gz').stat().st_size,'archive_sha256':manifest['archive_sha256']}))
