from pathlib import Path
import gzip,hashlib,json
OUT=Path('/tmp/oriole-dtd-combined-header-replay');OUT.mkdir(exist_ok=True)
libs={'baseline':'/tmp/oriole-api-combined.so','candidate':'/tmp/oriole-dtd-combined.so'}
for label,lib in libs.items():
 for group,script,oldout in [('primary','/tmp/oriole-external-pe-compare.py','/tmp/oriole-external-pe-initial-comparison.json'),('mixed','/tmp/oriole-external-pe-review/header_mixed_independent_final.py','/tmp/oriole-external-pe-review/header-mixed-independent-final.json'),('independent','/tmp/oriole-external-pe-review/header_independent_final.py','/tmp/oriole-external-pe-review/header-independent-final.json')]:
  code=Path(script).read_text().replace('/home/dev-user/.cache/oriole/external-parameter-context-target/debug/liboriole_expat.so',lib)
  code=code.replace("sha='30959c87acac27243b80a8c822ddc74b49979e9d5cb1d4ccfaeda0ce856d94b2'",'sha='+repr(hashlib.sha256(Path(lib).read_bytes()).hexdigest()))
  code=code.replace("rows=json.loads((root/f'{collection}.json').read_text())['cases']","rows=json.loads((root/f'{collection}.json').read_text() if (root/f'{collection}.json').exists() else gzip.open(root/f'{collection}.json.gz','rt').read())['cases']")
  dest=OUT/f'{group}-{label}.json'
  code=code.replace(oldout,str(dest))
  print(group,label,flush=True);exec(code,{'__name__':'replay','gzip':gzip})
  with gzip.open(str(dest)+'.gz','wt')as f:f.write(dest.read_text())
  dest.unlink()
summary={}
for group in ['primary','mixed','independent']:
 b=json.load(gzip.open(OUT/f'{group}-baseline.json.gz','rt'));c=json.load(gzip.open(OUT/f'{group}-candidate.json.gz','rt'))
 if group=='primary':
  b=[r for rs in b['collections'].values()for r in rs];c=[r for rs in c['collections'].values()for r in rs]
 elif group=='mixed':b=b['rows'];c=c['rows']
 else:b=b['cases'];c=c['cases']
 def norm(r):
  if group=='independent':
   r={'status':r['status'],'error':r['error'],'children':[[x['name'],x['status'],x['error']]for x in r['children']],'events':[e[:2]+e[3:]for e in r['events']]}
  return r|{'events':[e for e in r['events']if e[:2]!=['parent','not-standalone']]}
 new=[];remaining=[]
 if group=='independent':
  summary[group]={'cases':len(c),'new_differences':[i for i,(x,y)in enumerate(zip(b,c))if x['match'] and not y['match']],'remaining_differences':[i for i,y in enumerate(c)if not y['match']]}
  continue
 for i,(x,y)in enumerate(zip(b,c)):
  ref=norm(y['reference']);base=norm(x['candidate']);cand=norm(y['candidate'])
  if base==ref and cand!=ref:new.append(i)
  if cand!=ref:remaining.append(i)
 summary[group]={'cases':len(c),'new_differences':new,'remaining_differences':remaining}
Path(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('SUMMARY',json.dumps(summary),flush=True)
