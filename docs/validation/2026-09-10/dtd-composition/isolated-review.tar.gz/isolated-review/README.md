# Internal parameter-entity delimiter composition

The patch accepts internal parameter entities that supply a declaration's closing `>` or a conditional header's opening `[`. Replacement text after the delimiter remains available to following declarations, including a declaration begun in the replacement and completed by its parent. Names, quoted literals and references retain lexical source boundaries. Parameter entities referenced between declarations still need complete declarations, and ignored conditional sections still close within their source.

The implementation keeps the ordinary declaration scanner fast path. Grammar references enter an owned incremental collector that preserves raw Default projections, literal normalization and active parameter provenance. A source-origin flag separates in-declaration replacements from between-declaration replacements. External conditional-header references retain the ordinary external-DTD child/read-state protocol. The old borrowed declaration expander and old header frame continuation are replaced rather than duplicated. No FFI runtime, I/O or unsafe code is added.

## Frozen patch

- Base snapshot: `/tmp/oriole-content-encoding` (decoder layer, before later root namespace/version/foreign/API changes).
- Source snapshot: `/tmp/oriole-dtd-composition`.
- Patch: `internal-dtd-delimiters.patch`, SHA256 `f0c37be05e7503c2bff42b15e514680586c99d5d173ba3c94d5e1e93556f82ae`.
- Nine changed files and their base/candidate hashes are in `source-manifest.json`. Zero-fuzz dry run passes. Preserve root's later changes when integrating.
- Library: `/home/dev-user/.cache/oriole/dtd-composition-target/debug/liboriole_expat.so`, SHA256 `e3190bd54b5dee3069e773ccbc3b1d25f41a4ad8b8488f4f2a66b7267e3fb93f`.

## Validation

All 191 core/FFI tests, strict scoped Clippy and formatting pass. Tests cover each byte width, UTF-8/UTF-16, source tails, nested replacements, quote/recursion boundaries, malformed Default prefixes, selected-allocator failure/global-bypass assertions, and C ParseBuffer use after the parent has been freed.

The 1,242-case three-way oracle fixes 270 outcome comparisons with no new outcome differences. All 552 jointly successful reference/candidate cases match normalized child events; positions and the pre-existing parent NotStandalone ordering are separately scoped. The remaining 242 differences involve failed or unsupported input.

The previous header gates were replayed against the final library and decoder baseline: 1,836 primary cases retain only the same 44 external-DTD malformed lexical diagnostics, with no new normalized differences; all 576 mixed headers and 54 nested/read/no-handler cases match. These suites overlap the primary declaration comparison, so their counts are not an independent total.

The exact five W3C descriptors were replayed through the reviewed local-only resolver at chunks 1/7/4096. Expat accepts all 15 observations, the decoder baseline accepts none, and the candidate accepts 12. The four fixed IDs are `invalid--005`, `invalid--006`, `invalid-not-sa-022`, and `rmt-e2e-14`. W3C's invalid category contains validity violations that this nonvalidating parser is required to accept; this is acceptance evidence, not canonical output comparison.

`valid-not-sa-003` still needs an external PE reference between ATTLIST grammar tokens. That feature is not included. `external-grammar-plan.md` describes the required semantic cursor so earlier attributes can be committed before the external callback without repeating work or changing callback order.

`evidence/` retains final commands, logs, generators and compressed observations; `validation.json` gives exact counts. No new sanitizer campaign is claimed for this isolated layer: root will test the integrated freeze. Independent source review found no memory, provenance or depth blocker. Its separate 450-case internal-delimiter matrix reduced 360 baseline outcome differences to 90 retained failed-input diagnostics, with no acceptance mismatch or successful-callback regression; the reviewed source hashes and exact scope are in `evidence/oriole-dtd-composition-independent-review.json`.

## Development evidence

`development/` preserves the earlier patch and log that omitted or over-emitted malformed-header Default prefixes. The expanded prior header suite found the regression; the final patch corrects it and adds a focused all-chunk regression. The initial declaration-test log also records the intentionally changed unsupported-boundary diagnostic for an extra closing `>`, now matching Expat's Syntax error.
