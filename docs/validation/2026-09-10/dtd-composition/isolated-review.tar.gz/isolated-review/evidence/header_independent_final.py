import hashlib,json
from pathlib import Path
lib=Path('/home/dev-user/.cache/oriole/external-parameter-context-target/debug/liboriole_expat.so')
sha='30959c87acac27243b80a8c822ddc74b49979e9d5cb1d4ccfaeda0ce856d94b2'
assert hashlib.sha256(lib.read_bytes()).hexdigest()==sha
base=Path('/tmp/oriole-external-pe-review/probe.py').read_text().split("if __name__ == '__main__':")[0]
base=base.replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so',str(lib))
rows=[]
for filename in ['nested-read-reference.json','no-handler-reference.json']:
 code=base
 if filename.startswith('nested'):
  code=code.replace("if name != 'd' and action == 'skip':", "if name == 'q' and action == 'skip':")
  code=code.replace("content = data if name == 'd' else b'' if action == 'empty' else external_data", "content = data if name == 'd' else b'%q;' if name == 'p' else b'' if action == 'empty' else external_data")
 else:
  code=code.replace('l.XML_SetParamEntityParsing(child, mode)',"l.XML_SetParamEntityParsing(child, mode)\n            if action == 'no-handler':\n                l.XML_SetExternalEntityRefHandler(child, EXTERNAL())")
 scope={'__name__':'imported'};exec(code,scope)
 for a in json.loads(Path('/tmp/oriole-external-pe-review',filename).read_text())['cases']:
  b=scope['probe'](a['standalone'],a['mode'],a['data'].encode(),a['external_data'].encode(),a['action'],a['chunk'])
  def semantics(r):return {'status':r['status'],'error':r['error'],'children':[(c['name'],c['status'],c['error']) for c in r['children']],'events':[[e[0],e[1],*e[3:]] for e in r['events'] if e[0]!='parent' and e[1] in ['entity','external','not-standalone','skipped']],'default':r['default']}
  match=semantics(a)==semantics(b)
  row={'file':filename,'reference':a,'candidate':b,'match':match};rows.append(row)
  if not match:print(json.dumps({'file':filename,'mode':a['mode'],'standalone':a['standalone'],'action':a['action'],'chunk':a['chunk'],'reference':semantics(a),'candidate':semantics(b)}))
assert hashlib.sha256(lib.read_bytes()).hexdigest()==sha
Path('/tmp/oriole-external-pe-review/header-independent-final.json').write_text(json.dumps({'library':str(lib),'sha256':sha,'cases':rows},indent=2)+'\n')
print('cases',len(rows),'differences',sum(not r['match'] for r in rows))
