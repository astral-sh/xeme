from pathlib import Path
import json,gzip,hashlib
source=Path('/tmp/oriole-external-pe-review/probe.py').read_text().split("if __name__ == '__main__':")[0]
paths={'baseline':'/home/dev-user/.cache/oriole/content-encoding-target/debug/liboriole_expat.so','candidate':'/home/dev-user/.cache/oriole/dtd-composition-target/debug/liboriole_expat.so'}
refs=json.load(gzip.open('/tmp/oriole-dtd-delimiter-independent.json.gz','rt'))['rows']+json.loads(Path('/tmp/oriole-external-pe-review/reference.json').read_text())['cases']
obs={}
for label,path in paths.items():
 n={};exec(source.replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so',path),n)
 rows=[]
 for i,r in enumerate(refs):
  x=n['probe'](r['standalone'],r['mode'],r['data'].encode(),r['external_data'].encode(),r['action'],r['chunk']);x['name']=r['name'];rows.append(x)
 obs[label]=rows
 print(label,len(rows),flush=True)
def outcome(r):return [r['status'],r['error'],[[c['name'],c['error']]for c in r['children']]]
def events(r):
 out=[]
 for e in r['events']:
  if e[0]=='parent':continue
  e=e[:2]+e[3:]
  if out and e[1]in ('default','text') and out[-1][:2]==e[:2]:out[-1][2]+=e[2]
  else:out.append(e)
 return out
summary={'cases':len(refs),'libraries':{k:{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()}for k,p in paths.items()},'outcome_fixed':[],'outcome_new':[],'events_new':[],'remaining':[]}
for i,(r,b,c) in enumerate(zip(refs,obs['baseline'],obs['candidate'])):
 info={'index':i,'name':r['name'],'mode':r['mode'],'standalone':r['standalone'],'chunk':r['chunk'],'reference':outcome(r),'baseline':outcome(b),'candidate':outcome(c)}
 if outcome(b)!=outcome(r) and outcome(c)==outcome(r):summary['outcome_fixed'].append(info)
 if outcome(b)==outcome(r) and outcome(c)!=outcome(r):summary['outcome_new'].append(info)
 if r['status']==1 and b['status']==1 and c['status']==1 and events(b)==events(r) and events(c)!=events(r):summary['events_new'].append(info|{'reference_events':events(r),'candidate_events':events(c)})
 if outcome(c)!=outcome(r) or (r['status']==1 and c['status']==1 and events(c)!=events(r)):summary['remaining'].append(info)
with gzip.open('/tmp/oriole-dtd-composition-comparison-cases.json.gz','wt')as f:json.dump({'reference':refs,**obs},f)
Path('/tmp/oriole-dtd-composition-comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
print({k:len(v)for k,v in summary.items()if isinstance(v,list)},flush=True)
for key in ('outcome_new','events_new'):
 print(key)
 for x in summary[key][:12]:print(x)
