import gzip,json,ctypes as c,hashlib
from pathlib import Path
source=Path('/tmp/oriole-external-pe-review/probe.py').read_text();source=source[:source.index('if __name__')]
paths=['/tmp/oriole-content-combined.so','/home/dev-user/.cache/oriole/dtd-composition-target/debug/liboriole_expat.so'];mods=[]
for path in paths:
 scope={};exec(source.replace("LIB = Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so')",f'LIB = Path({path!r})'),scope);mods.append(scope)
original=json.load(gzip.open('/tmp/oriole-dtd-delimiter-independent.json.gz','rt'));rows=[]
for old in original['rows']:
 if old['name'].startswith('external-grammar'):continue
 options=[old[k]for k in ['standalone','mode']]+[old['data'].encode(),old['external_data'].encode(),old['action'],old['chunk']]
 a,b=[m['probe'](*options)for m in mods]
 rows.append(dict(name=old['name'],reference=old,baseline=a,candidate=b))
def outcome(r):return (r['status'],r['error'],[(p['name'],p['status'],p['error'])for p in r['children']])
def events(r):return [(e[0],e[1],e[3:])for e in r['events']]
summary=dict(cases=len(rows),baseline_outcome_differences=sum(outcome(r['reference'])!=outcome(r['baseline'])for r in rows),candidate_outcome_differences=sum(outcome(r['reference'])!=outcome(r['candidate'])for r in rows),outcome_regressions=sum(outcome(r['reference'])==outcome(r['baseline']) and outcome(r['reference'])!=outcome(r['candidate'])for r in rows),successful_callback_regressions=sum(r['reference']['status']==1 and events(r['reference'])==events(r['baseline'])and events(r['reference'])!=events(r['candidate'])for r in rows),libraries={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in paths})
with gzip.open('/tmp/oriole-dtd-composition-independent.json.gz','wt')as f:json.dump(dict(summary=summary,rows=rows),f)
print(summary)
for r in rows:
 if r['reference']['mode']==2 and r['reference']['standalone']is None and r['reference']['chunk']==0 and outcome(r['reference'])!=outcome(r['candidate']): print(r['name'],outcome(r['reference']),outcome(r['candidate']))
