import importlib.util,json,gzip,hashlib
from pathlib import Path
spec=importlib.util.spec_from_file_location('probe','/tmp/oriole-external-pe-review/probe.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
cases=[]
def internal(name,value,body):
 value=value.replace('&','&amp;').replace('%','&#37;').replace('"','&#34;')
 cases.append((name,('<!ENTITY % p "'+value+'">'+body).encode(),b'', 'parse'))
for name,value,body in [
 ('close-element','>','<!ELEMENT r EMPTY %p;'),
 ('close-element-model','EMPTY>','<!ELEMENT r %p;'),
 ('close-element-nested','&#37;q;','<!ELEMENT r EMPTY %p;'),
 ('close-then-comment','><!--tail-->','<!ELEMENT r EMPTY %p;'),
 ('close-then-other','><!ENTITY z ','<!ELEMENT r EMPTY %p; "Z">'),
 ('close-then-other-name','><!ENTITY z','<!ELEMENT r EMPTY %p;oo "Z">'),
 ('close-then-other-partial-opener','><!ENT','<!ELEMENT r EMPTY %p;ITY z "Z">'),
 ('close-then-open-quote',"> <!ENTITY z '",'<!ELEMENT r EMPTY %p;Z\'>'),
 ('close-then-ref','>%q;','<!ELEMENT r EMPTY %p;'),
 ('two-closes','>>','<!ELEMENT r EMPTY %p;'),
 ('quoted-close',"'a>b'",'<!ATTLIST r a CDATA %p;>'),
 ('attlist-close','a CDATA #IMPLIED>','<!ATTLIST r %p;'),
 ('attlist-close-follow','a CDATA #IMPLIED><!ENTITY z ','<!ATTLIST r %p; "Z">'),
 ('entity-close','>','<!ENTITY z "Z" %p;'),
 ('notation-close','>','<!NOTATION z SYSTEM "Z" %p;'),
 ('header-full','INCLUDE[','<![%p;<!ENTITY z "Z">]]>'),
 ('header-full-follow','INCLUDE[<!ENTITY z ','<![%p; "Z">]]>'),
 ('header-token-splice','INCLU','<![%p;DE[<!ENTITY z "Z">]]>'),
 ('header-opener','[','<![INCLUDE%p;<!ENTITY z "Z">]]>'),
 ('header-ignore','IGNORE[','<![%p;garbage]]>'),
 ('header-ignore-close','IGNORE[garbage]]>','<![%p;'),
 ('header-include-close','INCLUDE[<!ENTITY z "Z">]]>','<![%p;'),
 ('header-open-partial-decl','INCLUDE[<!ENT','<![%p;ITY z "Z">]]>'),
 ('header-open-partial-quote',"INCLUDE[<!ENTITY z '",'<![%p;Z\'>]]>'),
]:internal(name,value,body)
# Nested PE replay supplies both delimiter and following declaration.
cases.append(('nested-close',b'<!ENTITY % q "><!ENTITY z "><!ENTITY % p "&#37;q;"><!ELEMENT r EMPTY %p; "Z">',b'','parse'))
for action in ['skip','parse','empty']:
 for data in [b'',b' ',b'EMPTY',b'<!ENTITY z "Z">']:
  cases.append(('external-grammar-'+action+'-'+data.decode(),b'<!ENTITY % p SYSTEM "p"><!ATTLIST r a CDATA %p; "v"><!ENTITY after "A">',data,action))
rows=[]
for name,dtd,data,action in cases:
 for mode in [0,1,2]:
  for standalone in [None,'yes']:
   for chunk in [0,1,3]:
    r=m.probe(standalone,mode,dtd,data,action,chunk);r['name']=name;rows.append(r)
out={'library':str(m.LIB),'sha256':hashlib.sha256(m.LIB.read_bytes()).hexdigest(),'count':len(rows),'rows':rows}
with gzip.open('/tmp/oriole-dtd-delimiter-independent.json.gz','wt') as f:json.dump(out,f)
for r in rows:
 if r['mode']==2 and r['standalone'] is None and r['chunk']==0:print(r['name'],r['status'],[(x['name'],x['error']) for x in r['children']],[(e[1],e[3:])for e in r['events'] if e[1]in('entity','attlist','external')])
