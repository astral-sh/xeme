from pathlib import Path
import hashlib,json,gzip
source=Path('/tmp/oriole-external-pe-review/probe.py').read_text();source=source[:source.index("if __name__")]
old="        content = data if name == 'd' else b'' if action == 'empty' else external_data"
new="""        if name != 'd' and action in ('create-only','empty-nonfinal'):
            status = 1 if action == 'create-only' else l.XML_Parse(child, b'', 0, 0)
            children.append({'name':name, 'status':status, 'error':l.XML_GetErrorCode(child), 'index':l.XML_GetCurrentByteIndex(child)})
            active[:] = saved
            l.XML_ParserFree(child)
            return int(status != 0)
        content = data if name == 'd' else b'' if action == 'empty' else external_data"""
assert old in source;source=source.replace(old,new);scope={};exec(source,scope);probe=scope['probe'];rows=[]
for body in ['<!ATTLIST r a CDATA %p; "v">','<!ATTLIST r a CDATA "v" %p;>','<!ELEMENT r %p; EMPTY>']:
 for standalone in [None,'yes']:
  for mode in [0,1,2]:
   for action in ['skip','create-only','empty-nonfinal','empty']:
    for chunk in [0,1]:
     row=probe(standalone,mode,('<!ENTITY % p SYSTEM "p">'+body+'<!ENTITY after "A">').encode(),b'',action,chunk);rows.append(row)
output={'source_generator_sha256':hashlib.sha256(Path('/tmp/oriole-external-pe-review/probe.py').read_bytes()).hexdigest(),'reference_sha256':hashlib.sha256(scope['LIB'].read_bytes()).hexdigest(),'count':len(rows),'rows':rows}
with gzip.open('/tmp/oriole-dtd-delimiter-read-ack.json.gz','wt')as f:json.dump(output,f)
print(len(rows));
for r in rows[:48]:
 if r['chunk']==0 and r['mode']==2:print(r['standalone'],r['action'],r['status'],[(e[0],e[1],e[3:])for e in r['events'] if e[1]in ('attlist','entity','not-standalone')])
