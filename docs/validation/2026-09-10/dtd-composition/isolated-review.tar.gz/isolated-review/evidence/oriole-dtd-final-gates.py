from pathlib import Path
import os,subprocess,json,hashlib,time
root=Path('/tmp/oriole-dtd-composition')
env=os.environ|{'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/dtd-composition-target','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all'}
commands=[('fmt',['fmt','--all','--check']),('tests',['test','-p','oriole','-p','oriole_expat']),('clippy',['clippy','-p','oriole','-p','oriole_expat','--all-targets','--','-D','warnings']),('build',['build','-p','oriole_expat'])]
rows=[]
for label,args in commands:
 command=['taskset','-c','5','cargo','+ohm',*args];log=Path('/tmp/oriole-dtd-composition-final-'+label+'.log');start=time.monotonic()
 with log.open('w')as output:r=subprocess.run(command,cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT)
 rows.append({'name':label,'command':command,'exit':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':str(log)});print(label,r.returncode,flush=True)
 if r.returncode:break
lib=Path(env['CARGO_TARGET_DIR'])/'debug/liboriole_expat.so'
Path('/tmp/oriole-dtd-composition-gates.json').write_text(json.dumps({'source':str(root),'env':{k:v for k,v in env.items()if k.startswith('CARGO_')},'runs':rows,'library':str(lib),'sha256':hashlib.sha256(lib.read_bytes()).hexdigest()},indent=2)+'\n')
