from pathlib import Path
import hashlib,json
root=Path('/tmp/oriole-external-pe-review')
lib=Path('/home/dev-user/.cache/oriole/external-parameter-context-target/debug/liboriole_expat.so')
base=(root/'probe.py').read_text().split("if __name__ == '__main__':")[0]
base=base.replace("/home/dev-user/.cache/oriole/expat-build/libexpat.so",str(lib))

def normalize(row):
    events=[]
    for raw in row['events']:
        event=raw[:2]+raw[3:]
        if event[1]=='default' and events and events[-1][:2]==event[:2]:
            events[-1][2]+=event[2]
        else:events.append(event)
    return {'status':row['status'],'error':row['error'],'children':[[r['name'],r['status'],r['error']] for r in row['children']],'events':events}

outputs={}
for collection in ['reference','header-reference','read-ack-reference']:
    rows=json.loads((root/f'{collection}.json').read_text())['cases']
    output=[]
    scopes={}
    for old in rows:
        if collection=='reference' and not old['name'].startswith('header'):continue
        default=old.get('default_handler',True)
        key=(collection=='read-ack-reference',default)
        if key not in scopes:
            code=base
            if key[0]:
                code=code.replace("child = l.XML_ExternalEntityParserCreate(parser, context, None)","child = l.XML_ExternalEntityParserCreate(parser, context, b'BOGUS' if name != 'd' and action == 'bad-encoding' else None)")
                code=code.replace("content = data if name == 'd' else b'' if action == 'empty' else external_data", "content = data if name == 'd' else b'' if action in ['empty','empty-nonfinal','bad-encoding','create-only'] else external_data")
                code=code.replace("for start in range(0, max(len(content), 1), width):", "for start in ([] if name != 'd' and action=='create-only' else range(0, max(len(content), 1), width)):")
                code=code.replace("int(start+width>=len(content)))", "int(start+width>=len(content) and not(name!='d' and action=='empty-nonfinal')))")
                code=code.replace("return int(status != 0)","return int(status != 0 or (name != 'd' and action in ['bad-encoding','ignore-error']))")
            if not default:code=code.replace('l.XML_SetDefaultHandlerExpand(parent, callbacks[0])','pass')
            scope={'__name__':'imported'};exec(code,scope);scopes[key]=scope
        new=scopes[key]['probe'](old['standalone'],old['mode'],old['data'].encode(),old['external_data'].encode(),old['action'],old['chunk'])
        a,b=normalize(old),normalize(new)
        output.append({'name':old.get('name',old['action']),'standalone':old['standalone'],'mode':old['mode'],'action':old['action'],'chunk':old['chunk'],'status_match':(a['status'],a['error'],a['children'])==(b['status'],b['error'],b['children']),'normalized_match':a==b,'reference':a,'candidate':b})
    outputs[collection]=output
result={'library':str(lib),'sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'collections':outputs,'counts':{key:{'cases':len(rows),'status_differences':sum(not r['status_match'] for r in rows),'normalized_differences':sum(not r['normalized_match'] for r in rows)} for key,rows in outputs.items()}}
Path('/tmp/oriole-external-pe-initial-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['counts']))
for key,rows in outputs.items():
 for row in rows:
  if not row['status_match'] and row['chunk']==0:print(key,json.dumps(row))
