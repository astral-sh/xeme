"""Read the original W3C catalog and compare nonvalidating XML 1.0 acceptance."""
from pathlib import Path
import ctypes as C
import hashlib
import json
import sys
import urllib.parse
import xml.parsers.expat

SUITE = next(Path('/tmp/oriole-w3c-source').iterdir()) / 'packages/test-data/xmlconf'
OUT = Path('/tmp/oriole-w3c-audit')
OUT.mkdir(exist_ok=True)


def resolve(base, value):
    uri = urllib.parse.urlsplit(urllib.parse.urljoin(base, value))
    if uri.scheme != 'file' or uri.netloc not in ('', 'localhost'):
        raise ValueError('nonlocal URI: ' + uri.geturl())
    path = Path(urllib.parse.unquote(uri.path)).resolve()
    if not path.is_relative_to(SUITE):
        raise ValueError('URI outside suite: ' + str(path))
    return path


def catalog():
    stack = [(SUITE / 'xmlconf.xml').as_uri()]
    rows = []
    def start(name, attrs):
        base = urllib.parse.urljoin(stack[-1], attrs.get('xml:base', ''))
        stack.append(base)
        if name == 'TEST':
            row = dict(attrs)
            path = resolve(base, attrs['URI'])
            # The original catalog has this documented base-URI typo. Retain
            # both paths; do not edit the suite or use the mirror's cleaned XML.
            if '/eduni/namespaces/misc/' in str(path):
                row['catalog_uri_correction'] = str(path.relative_to(SUITE))
                path = Path(str(path).replace('/eduni/namespaces/misc/', '/eduni/misc/'))
            row['path'] = str(path.relative_to(SUITE))
            rows.append(row)
    def load(parser, path):
        parser.SetBase(path.as_uri())
        parser.SetParamEntityParsing(xml.parsers.expat.XML_PARAM_ENTITY_PARSING_ALWAYS)
        parser.StartElementHandler = start
        parser.EndElementHandler = lambda name: stack.pop()
        def external(context, base, system, public):
            child = parser.ExternalEntityParserCreate(context)
            load(child, resolve(base, system))
            return 1
        parser.ExternalEntityRefHandler = external
        parser.Parse(path.read_bytes(), True)
    load(xml.parsers.expat.ParserCreate(), SUITE / 'xmlconf.xml')
    return rows


EXT = C.CFUNCTYPE(C.c_int, C.c_void_p, C.c_void_p, C.c_char_p, C.c_char_p, C.c_char_p)


class Engine:
    def __init__(self, library):
        self.lib = C.CDLL(library)
        for name, args, result in [
            ('XML_ParserCreate', [C.c_char_p], C.c_void_p),
            ('XML_ParserCreateNS', [C.c_char_p, C.c_char], C.c_void_p),
            ('XML_ParserFree', [C.c_void_p], None),
            ('XML_ExternalEntityParserCreate', [C.c_void_p,C.c_void_p,C.c_char_p], C.c_void_p),
            ('XML_SetExternalEntityRefHandler', [C.c_void_p,EXT], None),
            ('XML_SetParamEntityParsing', [C.c_void_p,C.c_int], C.c_int),
            ('XML_SetBase', [C.c_void_p,C.c_char_p], C.c_int),
            ('XML_Parse', [C.c_void_p,C.c_char_p,C.c_int,C.c_int], C.c_int),
            ('XML_GetErrorCode', [C.c_void_p], C.c_int),
            ('XML_GetCurrentByteIndex', [C.c_void_p], C.c_long),
            ('XML_ExpatVersion', [], C.c_char_p),
        ]:
            fn = getattr(self.lib,name); fn.argtypes=args; fn.restype=result
        self.version = self.lib.XML_ExpatVersion().decode()

    def parse(self, path, chunk, namespaces):
        lib = self.lib
        parser = lib.XML_ParserCreateNS(None,b'|') if namespaces else lib.XML_ParserCreate(None)
        if not parser: raise MemoryError('parser creation')
        errors=[]; loaded=[]; children=[]; depth=0; requests=0
        def feed(handle, file):
            data=file.read_bytes()
            if len(data)>2*1024*1024:raise ValueError('file budget')
            loaded.append({'path':str(file.relative_to(SUITE)), 'sha256':hashlib.sha256(data).hexdigest()})
            if not lib.XML_SetBase(handle,file.as_uri().encode()):raise MemoryError('setbase')
            lib.XML_SetParamEntityParsing(handle,2)
            lib.XML_SetExternalEntityRefHandler(handle,external)
            if not data:return lib.XML_Parse(handle,b'',0,1)
            for offset in range(0,len(data),chunk):
                part=data[offset:offset+chunk]
                status=lib.XML_Parse(handle,part,len(part),int(offset+chunk>=len(data)))
                if status!=1:return status
            return 1
        @EXT
        def external(parent,context,base,system,public):
            nonlocal depth,requests
            child=None
            try:
                depth+=1; requests+=1
                if depth>32 or requests>1024:raise ValueError('external family budget')
                file=resolve(base.decode(),system.decode())
                child=lib.XML_ExternalEntityParserCreate(parent,context,None)
                if not child:raise MemoryError('child creation')
                status=feed(child,file)
                children.append({'path':str(file.relative_to(SUITE)), 'status':status,'error':lib.XML_GetErrorCode(child)})
                return int(status==1)
            except Exception as exc:
                errors.append(type(exc).__name__+': '+str(exc)); return 0
            finally:
                if child:lib.XML_ParserFree(child)
                depth-=1
        try:
            status=feed(parser,path)
            return {'status':status,'error':lib.XML_GetErrorCode(parser),'index':lib.XML_GetCurrentByteIndex(parser),'resolver_errors':errors,'loaded':loaded,'children':children}
        finally:lib.XML_ParserFree(parser)


def worker(library, label):
    engine=Engine(library); rows=[]
    for case in json.loads((OUT/'catalog.json').read_text()):
        if case.get('skip'):continue
        for chunk in (1,7,4096):
            row={'id':case['ID'],'path':case['path'],'type':case['TYPE'],'chunk':chunk}
            (OUT/(label+'-progress.json')).write_text(json.dumps(row)+'\n')
            row['result']=engine.parse(SUITE/case['path'],chunk,case.get('NAMESPACE','yes')!='no')
            rows.append(row)
    (OUT/(label+'.json')).write_text(json.dumps({'library':library,'sha256':hashlib.sha256(Path(library).read_bytes()).hexdigest(),'version':engine.version,'rows':rows},separators=(',',':'))+'\n')
    print(label,len(rows),flush=True)

if __name__=='__main__':
    if len(sys.argv)>1:
        worker(sys.argv[1],sys.argv[2])
    else:
        rows=catalog()
        for row in rows:
            if row.get('RECOMMENDATION','XML1.0').startswith(('XML1.1','NS1.1')) or '1.0' not in row.get('VERSION','1.0').split():row['skip']='XML 1.1'
            elif '5' not in row.get('EDITION','5').split():row['skip']='Earlier XML edition only'
        (OUT/'catalog.json').write_text(json.dumps(rows,indent=2)+'\n')
        print('catalog',len(rows),'selected',sum(not r.get('skip') for r in rows),'missing',[r['path']for r in rows if not r.get('skip') and not (SUITE/r['path']).is_file()])
