import ctypes as c
import hashlib
import json
from pathlib import Path

LIB = Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so')
l = c.CDLL(str(LIB))
P, S, I = c.c_void_p, c.c_char_p, c.c_int
DEFAULT = c.CFUNCTYPE(None, P, P, I)
NOT = c.CFUNCTYPE(I, P)
SKIP = c.CFUNCTYPE(None, P, S, I)
ENTITY = c.CFUNCTYPE(None, P, S, I, P, I, S, S, S, S)
ATTLIST = c.CFUNCTYPE(None, P, S, S, S, S, I)
EXTERNAL = c.CFUNCTYPE(I, P, S, S, S, S)
START = c.CFUNCTYPE(None, P, S, c.POINTER(S))
for name, result, arguments in [
    ('XML_ParserCreate', P, [S]),
    ('XML_SetParamEntityParsing', I, [P, I]),
    ('XML_ExternalEntityParserCreate', P, [P, S, S]),
    ('XML_Parse', I, [P, S, I, I]),
    ('XML_GetErrorCode', I, [P]),
    ('XML_GetCurrentByteIndex', c.c_long, [P]),
    ('XML_ParserFree', None, [P]),
    ('XML_SetDefaultHandler', None, [P, DEFAULT]),
    ('XML_SetDefaultHandlerExpand', None, [P, DEFAULT]),
    ('XML_SetNotStandaloneHandler', None, [P, NOT]),
    ('XML_SetSkippedEntityHandler', None, [P, SKIP]),
    ('XML_SetEntityDeclHandler', None, [P, ENTITY]),
    ('XML_SetAttlistDeclHandler', None, [P, ATTLIST]),
    ('XML_SetExternalEntityRefHandler', None, [P, EXTERNAL]),
    ('XML_SetStartElementHandler', None, [P, START]),
    ('XML_SetCharacterDataHandler', None, [P, DEFAULT]),
]:
    fn = getattr(l, name)
    fn.restype = result
    fn.argtypes = arguments

def decode(value):
    return value.decode() if value is not None else None


def probe(standalone, mode, data, external_data, action='parse', chunk=0):
    events, children, keepalive = [], [], []
    parent = l.XML_ParserCreate(None)
    active = [parent, 'parent']
    def event(kind, *values):
        events.append([active[1], kind, l.XML_GetCurrentByteIndex(active[0]), *values])
    def entity(_, name, parameter, value, length, base, system, public, notation):
        event('entity', decode(name), parameter, c.string_at(value, length).decode() if value else None, decode(system))
    def external(parser, context, base, system, public):
        name = decode(system)
        event('external', name, decode(context))
        if name != 'd' and action == 'skip':
            return 1
        child = l.XML_ExternalEntityParserCreate(parser, context, None)
        if not child:
            event('child-null', name)
            return 0
        saved = active.copy()
        active[:] = [child, name]
        if name == 'd':
            l.XML_SetParamEntityParsing(child, mode)
        content = data if name == 'd' else b'' if action == 'empty' else external_data
        width = chunk or max(len(content), 1)
        status = 1
        for start in range(0, max(len(content), 1), width):
            part = content[start:start+width]
            status = l.XML_Parse(child, part, len(part), int(start+width>=len(content)))
            if status == 0:
                break
        children.append({'name':name, 'status':status, 'error':l.XML_GetErrorCode(child), 'index':l.XML_GetCurrentByteIndex(child)})
        active[:] = saved
        l.XML_ParserFree(child)
        return int(status != 0)
    callbacks = [
        DEFAULT(lambda _, value, length: event('default', c.string_at(value, length).decode())),
        NOT(lambda _: (event('not-standalone'), 1)[1]),
        SKIP(lambda _, name, parameter: event('skipped', decode(name), parameter)),
        ENTITY(entity),
        ATTLIST(lambda _, element, name, kind, value, required: event('attlist', decode(element), decode(name), decode(value))),
        EXTERNAL(external),
        START(lambda _, name, attrs: event('start', decode(name))),
        DEFAULT(lambda _, value, length: event('text', c.string_at(value, length).decode())),
    ]
    l.XML_SetParamEntityParsing(parent, 2)
    l.XML_SetDefaultHandlerExpand(parent, callbacks[0])
    l.XML_SetNotStandaloneHandler(parent, callbacks[1])
    l.XML_SetSkippedEntityHandler(parent, callbacks[2])
    l.XML_SetEntityDeclHandler(parent, callbacks[3])
    l.XML_SetAttlistDeclHandler(parent, callbacks[4])
    l.XML_SetExternalEntityRefHandler(parent, callbacks[5])
    l.XML_SetStartElementHandler(parent, callbacks[6])
    l.XML_SetCharacterDataHandler(parent, callbacks[7])
    declaration = b'' if standalone is None else f"<?xml version='1.0' standalone='{standalone}'?>".encode()
    document = declaration + b"<!DOCTYPE r SYSTEM 'd'><r/>"
    status = l.XML_Parse(parent, document, len(document), 1)
    result = {'standalone':standalone, 'mode':mode, 'data':data.decode(), 'external_data':external_data.decode(errors='backslashreplace'),
              'action':action, 'chunk':chunk, 'children':children, 'status':status, 'error':l.XML_GetErrorCode(parent), 'events':events,
              'default': ''.join(x[3] for x in events if x[0]=='d' and x[1]=='default')}
    l.XML_ParserFree(parent)
    return result

if __name__ == '__main__':
    prefix = b"<!ENTITY % p SYSTEM 'p'>"
    suffix = b"<!ENTITY after 'after'><!ATTLIST r a CDATA 'yes'>"
    cases = [
      ('header-keyword', b'<![%p;[<!ENTITY e "E">]]>', b'INCLUDE'),
      ('header-empty', b'<![INCLUDE%p;[<!ENTITY e "E">]]>', b''),
      ('header-prefix', b'<![%p;CLUDE[<!ENTITY e "E">]]>', b'IN'),
      ('header-suffix', b'<![IN%p;[<!ENTITY e "E">]]>', b'CLUDE'),
      ('header-leading-space', b'<![%p;[<!ENTITY e "E">]]>', b' INCLUDE '),
      ('header-recursive', b'<![%p;[<!ENTITY e "E">]]>', b'%p;'),
      ('header-reference', b'<![%p;[<!ENTITY e "E">]]>', b'&#73;NCLUDE'),
      ('value', b'<!ENTITY e "L%p;R">', b'X'),
      ('value-empty', b'<!ENTITY e "L%p;R">', b''),
      ('value-quote', b'<!ENTITY e "L%p;R">', b'"<x>'),
      ('value-char-ref', b'<!ENTITY e "L%p;R">', b'&#65;'),
      ('value-general-ref', b'<!ENTITY e "L%p;R">', b'&amp;'),
      ('value-partial-ref', b'<!ENTITY e "L%p;amp;R">', b'&'),
      ('value-recursive', b'<!ENTITY e "L%p;R">', b'%p;'),
      ('value-missing', b'<!ENTITY e "L%p;R">', b'%missing;'),
      ('value-textdecl', b'<!ENTITY e "L%p;R">', b'<?xml encoding="UTF-8"?>X'),
    ]
    rows=[]
    for name, body, replacement in cases:
        for standalone in [None,'yes']:
            for mode in [0,1,2]:
                for action in ['parse','skip','empty']:
                    for chunk in [0,1]:
                        row=probe(standalone,mode,prefix+body+suffix,replacement,action,chunk)
                        row['name']=name
                        rows.append(row)
    Path('/tmp/oriole-external-pe-review/reference.json').write_text(json.dumps({'library':str(LIB),'sha256':hashlib.sha256(LIB.read_bytes()).hexdigest(),'cases':rows},indent=2)+'\n')
    print('cases',len(rows))
    for row in rows:
        if row['standalone'] is None and row['chunk']==0 and row['mode']==2:
            print(json.dumps(row))
