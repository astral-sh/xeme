# External parameter references between declaration tokens

The remaining W3C case, `xmltest/valid/not-sa/003.xml`, inserts an empty external parameter entity between `CDATA` and the quoted attribute default. Expat treats that child as an ordinary external DTD: empty input, whitespace and complete declarations can succeed; child literal `EMPTY` fails. This does not require flattening child text into parent grammar or a new external-child value mode.

The new internal declaration collector supplies the owned source and raw/provenance storage needed for continuation. A safe next layer still needs a semantic cursor, because Expat commits each complete ATTLIST attribute before invoking a later external reference. A callback that skips or creates an unread child suppresses the rest of that declaration when not standalone, while already committed attributes remain present. Deferring every attribute until the closing `>` would reorder successful callbacks and mishandle handler mutations.

## Bounded implementation

1. Add an owned declaration continuation that tracks the declaration kind, committed grammar/raw offsets, the current partial attribute, and the reference awaiting dispatch. Keep the existing complete-token/literal/source metadata; lexical tokens must not splice across PE boundaries.
2. For ATTLIST, factor the current parser into incremental states for element name, attribute name, type/enumeration and default. Commit a complete attribute exactly once before crossing an external reference. Retain incomplete attribute state instead of rescanning a growing prefix after every empty reference. Other declaration kinds have one final semantic callback, but their already valid raw prefixes must still be projected before the external callback.
3. Dispatch handler-conditional raw prefix events before marking the external request active. Preserve current ENTITY/ATTLIST prefix semantics; add equivalent ELEMENT/NOTATION projections where their callback handlers suppress raw bytes. Probe unparsed/duplicate ENTITY prefixes explicitly before selecting event variants.
4. Use the existing ordinary external-DTD child construction, active `%name` inheritance, read marker, skip/standalone propagation and declaration import. `Parse(empty,false)` acknowledges input; creation alone or protocol initialization failure does not. Drain pending prefix events before yielding the external request, then resume only after its callback finishes.
5. Resume from committed grammar/raw offsets. Process missing/disabled reference metadata at its grammatical position before a later callback, retaining first-declaration/default rules and suffix suppression. Do not replay completed semantic callbacks or charge/reparse an old prefix repeatedly.

## Required gates

- The original empty W3C entity and nonempty ordinary-DTD children, including child declarations used by the parent suffix.
- References before and after completed ATTLIST attributes and inside each attribute component; malformed prefixes must not trigger callbacks after the first known grammar error.
- ENTITY/ELEMENT/NOTATION prefixes, duplicate/unparsed handlers, dynamic handler changes and DefaultCurrent.
- Disabled modes, standalone, missing-before-external references, created-only/read/nonfinal/error/skip distinctions, recursion through inherited active PEs.
- Parse/ParseBuffer, every small byte split, UTF-16, parent/child lifetime order, stop/abort, selected-allocator fault sweeps, and repeated empty references with linear work/family budget assertions.

Independent reference evidence: `/tmp/oriole-dtd-delimiter-independent.json.gz` (666 cases including external grammar) and `/tmp/oriole-dtd-delimiter-read-ack.json.gz` (144 cases). This plan is not implemented by the internal-delimiter patch.
