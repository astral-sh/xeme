from pathlib import Path
import hashlib,json,ctypes as c,tarfile
root=Path('/tmp/oriole-dtd-seeds');out=root/'fuzz/seeds/ffi_family';out.mkdir(parents=True,exist_ok=True)
CASES={
 'element-close':'''<!ENTITY % p ">"><!ELEMENT r EMPTY %p;''',
 'element-close-following-declaration':'''<!ENTITY % p "><!ENTITY z "><!ELEMENT r EMPTY %p; 'Z'>''',
 'attlist-close-following-declaration':'''<!ENTITY % p "a CDATA #IMPLIED><!ENTITY z "><!ATTLIST r %p; 'Z'>''',
 'nested-close':'''<!ENTITY % q "><!ENTITY z "><!ENTITY % p "&#37;q;"><!ELEMENT r EMPTY %p; 'Z'>''',
 'header-open-following-declaration':'''<!ENTITY % p "INCLUDE[<!ENTITY z "><![%p; 'Z'>]]>''',
 'header-ignore-complete':'''<!ENTITY % p "IGNORE[garbage]]>"><![%p;''',
 'quote-boundary-rejected':'''<!ENTITY % p "><!ENTITY z '"><!ELEMENT r EMPTY %p;Z'>''',
 'opener-boundary-rejected':'''<!ENTITY % p "><!ENT"><!ELEMENT r EMPTY %p;ITY z 'Z'>''',
}
P,S,I=c.c_void_p,c.c_char_p,c.c_int
paths=['/home/dev-user/.cache/oriole/expat-build/libexpat.so','/home/dev-user/.cache/oriole/dtd-composition-target/debug/liboriole_expat.so']
libs=[]
for path in paths:
 l=c.CDLL(path)
 for n,r,a in [('XML_ParserCreateNS',P,[S,c.c_char]),('XML_ExternalEntityParserCreate',P,[P,S,S]),('XML_ParserFree',None,[P]),('XML_Parse',I,[P,P,I,I]),('XML_SetParamEntityParsing',I,[P,I]),('XML_ParserReset',c.c_ubyte,[P,S]),('XML_GetErrorCode',I,[P])]:
  f=getattr(l,n);f.restype=r;f.argtypes=a
 libs.append(l)
def probe(l,doc,lifecycle,reference=False):
 p=l.XML_ParserCreateNS(None,b'|');prefix=b"<!DOCTYPE r [<!ENTITY e 'value'><!ATTLIST r a CDATA 'default'>]><r>";assert l.XML_Parse(p,prefix,len(prefix),0)==1
 child=l.XML_ExternalEntityParserCreate(p,None,None);assert child;l.XML_SetParamEntityParsing(child,2)
 # Expat requires its DTD parent to remain alive; Oriole deliberately owns
 # the child state independently. Only the candidate exercises parent lifetime.
 if not reference:
  if lifecycle=='free':l.XML_ParserFree(p);p=None
  else:assert l.XML_ParserReset(p,None)
 status=1
 for i in range(0,len(doc),2):
  part=doc[i:i+2];status=l.XML_Parse(child,part,len(part),0)
  if status!=1:break
 status=l.XML_Parse(child,None,0,1);error=l.XML_GetErrorCode(child);l.XML_ParserFree(child)
 if p:l.XML_ParserFree(p)
 return [status,error]
manifest={}
for name,doc in CASES.items():
 for encoding in ['utf-8','utf-16le','utf-16be']:
  body=doc.encode(encoding)
  if encoding!='utf-8':body=(b'\xff\xfe'if encoding=='utf-16le'else b'\xfe\xff')+body
  for lifecycle in ['free','reset']:
   controls=bytearray([0]*16);controls[3]=1;controls[4]=47;controls[5]=4 if lifecycle=='free'else 3;controls[6]=34;controls[7]=36;controls[8:16]=bytes([4]*8)
   data=controls+body;key='dtd-composition-'+name+'-'+encoding+'-'+lifecycle;(out/key).write_bytes(data)
   result=[probe(l,body,lifecycle,index==0)for index,l in enumerate(libs)];assert result[0]==result[1],(key,result)
   manifest[key]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),controls=list(controls),xml=doc,encoding=encoding,parent_lifecycle=lifecycle,reference=result[0],candidate=result[1])
base='dtd-composition-nested-close-utf-8-free'
for fail in [1,8,64,128,256,512]:
 data=bytearray((out/base).read_bytes());data[0]|=1;data[1:3]=(fail-1).to_bytes(2,'little');key=f'dtd-composition-fail-{fail}';(out/key).write_bytes(data);manifest[key]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),base=base,fail_nth=fail)
report=dict(libraries={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in paths},target='/home/dev-user/code/oss/oriole/fuzz/fuzz_targets/ffi_family.rs',target_sha256=hashlib.sha256(Path('/home/dev-user/code/oss/oriole/fuzz/fuzz_targets/ffi_family.rs').read_bytes()).hexdigest(),seed_count=len(manifest),oracle_cases=48,oracle_differences=0,reference_parent_lifetime='Pinned Expat parent retained until child is freed; only Oriole exercises earlier parent reset/free, an intentional supported lifetime extension.',scope='Seeds only, unchanged reviewed ffi_family target. Controls create external DTD child1, set mode2, free/reset parent, feed child in2bytechunks, free child; existing selected-allocation schedule retained. Final ASan campaign pending root freeze.',seeds=manifest)
(root/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
with tarfile.open(root/'seeds.tar.gz','w:gz')as tar:
 for p in sorted(out.iterdir()):tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
print(len(manifest))
