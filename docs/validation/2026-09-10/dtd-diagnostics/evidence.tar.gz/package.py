import hashlib,json,tarfile,shutil,collections
from pathlib import Path
w=Path('/tmp/oriole-diagnostics-integrated');d=Path('docs/validation/2026-09-10/dtd-diagnostics');d.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((w/'upstream-api/results.json').read_text());old=json.loads(Path('/tmp/oriole-security-controls-integrated/upstream-api/results.json').read_text());before={(x['test'],x['context']):x['outcome'] for x in old['results']};fixed=[];regressed=[]
for x in r['results']:
 key=(x['test'],x['context'])
 if before[key]!='pass' and x['outcome']=='pass':fixed.append(x)
 if before[key]=='pass' and x['outcome']!='pass':regressed.append(x)
assert len(r['results'])==4740 and r['selection_complete'] and r['library_origin_verified'] and not r['timed_out'];assert len(fixed)==120 and not regressed
q=json.loads((w/'lexical.json').read_text());lex=collections.Counter(cases=len(q['rows']))
for x in q['rows']:
 a,b,c=(x['results'][k] for k in ['control','candidate','reference'])
 lex['acceptance_changes']+=a['status']!=b['status'];lex['callback_changes']+=a['events']!=b['events'];lex['error_mismatches']+=b['error']!=c['error'];lex['corrected_error_codes']+=a['error']!=c['error'] and b['error']==c['error']
assert not any(lex[k] for k in ['acceptance_changes','callback_changes','error_mismatches'])
current=w/'upstream-api/adapted';prior=Path('/tmp/oriole-security-controls-integrated/upstream-api/adapted');changes=[str(p.relative_to(current)) for p in current.iterdir() if p.is_file() and (prior/p.name).is_file() and sha(p)!=sha(prior/p.name)];assert not changes
source=json.loads((w/'source.json').read_text());summary={'rust_tests':source['rust_tests'],'library_sha256':source['library_sha256'],'upstream_api':{k:r[k] for k in ['passed','failed','selection_complete','library_origin_verified','timed_out']},'matrix_configurations':4740,'fixed':len(fixed),'regressed':len(regressed),'fixed_tests':dict(collections.Counter(x['test'] for x in fixed)),'changed_adapted_tests':changes,'lexical':lex,'punctuation':json.loads((w/'punctuation-probe.json').read_text())['counts'],'differential_cases':1518,'allocation_test_failures':sum(x['outcome']!='pass' and x['test'].startswith(('test_alloc_','test_nsalloc_','test_misc_alloc_')) for x in r['results'])};(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(w/'api-comparison.json').write_text(json.dumps({'fixed':fixed,'regressed':regressed},indent=2)+'\n')
for name in ['peer-review.json','manifest.json']:shutil.copy2(Path('/tmp/oriole-malformed-diagnostics')/name,w/('isolated-'+name))
files={}
for p in sorted(w.rglob('*')):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 files[str(p.relative_to(w))]={'sha256':sha(p),'bytes':p.stat().st_size}
with tarfile.open(d/'evidence.tar.gz','w:gz',compresslevel=9) as tar:
 for n in files:tar.add(w/n,arcname=n,recursive=False)
with tarfile.open(d/'evidence.tar.gz') as tar:
 for m in tar:assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==files[m.name]['sha256']
manifest={'archive_sha256':sha(d/'evidence.tar.gz'),'members':files};(d/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
(d/'README.md').write_text(f'''# Malformed DTD diagnostics

This layer distinguishes invalid lexical tokens from valid tokens in the wrong DTD grammar role, reports invalid PUBLIC identifier characters with Expat's error code, and matches incomplete external literals and forbidden document/subset closures. Exact error positions remain outside this change.

The integrated release library is `{source['library_sha256']['liboriole_expat.so']}`, based on the security-control runtime. All **240 core/C-interface Rust checks**, formatting and strict affected-package Clippy pass. The exact 1,518-case generated replay has no status, error, callback or position regressions. A 616-case lexical probe corrects 392 error codes with zero acceptance or callback changes and zero remaining error-code differences; another 2,280 punctuation cases find no acceptance/callback changes or regressed reference-correct codes. An independent source review found no remaining issue.

The unchanged upstream matrix completes all **4,740 configurations: 3,991 pass and 749 fail**, with verified library origin and no crashes or timeouts. This fixes 120 configurations from the preceding 3,871/869 runtime, with zero newly failing configurations and no modified upstream assertions. The remaining `test_bad_doctype` configurations exercise custom encoding aliases and belong to the separate encoding work. There are 596 remaining allocation-test failures and 153 other configurations; the count alone does not establish which remaining differences are acceptable. The initial checkpoint had 987 failures.

[evidence.tar.gz](evidence.tar.gz) retains the precise source/build hashes, raw matrix, lexical/punctuation observations, regression comparison, commands, logs and independent review. The first two upstream launch attempts failed before testing (incorrect source nesting, then a nonempty output directory); their logs remain recorded and the complete final run has a separate log. ELF binaries/static archives are excluded and identified by hash. [files.json](files.json) verifies every archive member; [summary.json](summary.json) lists compact results. Archive SHA256: `{manifest['archive_sha256']}`.
''')
print(json.dumps({'tests':source['rust_tests'],'api':[r['passed'],r['failed']],'fixed':len(fixed),'regressed':len(regressed),'lexical':lex,'archive_bytes':(d/'evidence.tar.gz').stat().st_size,'members':len(files)},indent=2))
