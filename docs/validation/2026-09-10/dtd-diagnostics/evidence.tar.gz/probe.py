import ctypes as c
import hashlib
import json
import os
from pathlib import Path

ROOT = Path('/tmp/oriole-malformed-diagnostics')
LIBRARIES = {'reference': '/home/dev-user/.cache/oriole/expat-build/libexpat.so', 'control': str(ROOT / 'control.so')}
if os.environ.get('ORIOLE_LIBRARY'):
    LIBRARIES['candidate'] = os.environ['ORIOLE_LIBRARY']
START = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.POINTER(c.c_char_p))
END = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p)
TEXT = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.c_int)
DOCTYPE = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.c_char_p, c.c_char_p, c.c_int)
VOID = c.CFUNCTYPE(None, c.c_void_p)

def setup(path):
    lib = c.CDLL(path)
    for name, args, result in [
        ('XML_ParserCreate', [c.c_char_p], c.c_void_p),
        ('XML_ParserCreateNS', [c.c_char_p, c.c_char], c.c_void_p),
        ('XML_ExternalEntityParserCreate', [c.c_void_p, c.c_char_p, c.c_char_p], c.c_void_p),
        ('XML_Parse', [c.c_void_p, c.c_char_p, c.c_int, c.c_int], c.c_int),
        ('XML_GetErrorCode', [c.c_void_p], c.c_int),
        ('XML_GetCurrentByteIndex', [c.c_void_p], c.c_long),
        ('XML_ParserFree', [c.c_void_p], None),
        ('XML_SetParamEntityParsing', [c.c_void_p, c.c_int], c.c_int),
        ('XML_SetStartElementHandler', [c.c_void_p, START], None),
        ('XML_SetEndElementHandler', [c.c_void_p, END], None),
        ('XML_SetCharacterDataHandler', [c.c_void_p, TEXT], None),
        ('XML_SetStartDoctypeDeclHandler', [c.c_void_p, DOCTYPE], None),
        ('XML_SetEndDoctypeDeclHandler', [c.c_void_p, VOID], None),
    ]:
        fn = getattr(lib, name); fn.argtypes = args; fn.restype = result
    return lib

def run(lib, data, external, namespaces, width):
    parent = lib.XML_ParserCreateNS(None, b'|') if namespaces else lib.XML_ParserCreate(None)
    assert parent
    lib.XML_SetParamEntityParsing(parent, 2)
    parser = lib.XML_ExternalEntityParserCreate(parent, None, None) if external else parent
    assert parser
    events = []
    decode = lambda value: value.decode() if value is not None else None
    @START
    def start(_, name, attrs): events.append(['start', decode(name)])
    @END
    def end(_, name): events.append(['end', decode(name)])
    @TEXT
    def text(_, value, length): events.append(['text', c.string_at(value, length).decode()])
    @DOCTYPE
    def doctype(_, name, system, public, subset): events.append(['doctype', decode(name), decode(system), decode(public), subset])
    @VOID
    def end_doctype(_): events.append(['end_doctype'])
    lib.XML_SetStartElementHandler(parser, start); lib.XML_SetEndElementHandler(parser, end)
    lib.XML_SetCharacterDataHandler(parser, text); lib.XML_SetStartDoctypeDeclHandler(parser, doctype)
    lib.XML_SetEndDoctypeDeclHandler(parser, end_doctype)
    width = width or len(data)
    for offset in range(0, len(data), width):
        piece = data[offset:offset + width]
        status = lib.XML_Parse(parser, piece, len(piece), offset + width >= len(data))
        if status != 1: break
    result = {'status': status, 'error': lib.XML_GetErrorCode(parser), 'byte': lib.XML_GetCurrentByteIndex(parser), 'events': events}
    if external: lib.XML_ParserFree(parser)
    lib.XML_ParserFree(parent)
    return result

cases = {}
for name in ['foo', '1', '1+', '1*', '1?', 'foo+', 'foo!', "foo'bar'", 'foo"bar"', 'foo=bar', 'foo:!bad', ':foo', 'foo:', 'foo:a:doc']:
    cases['doctype-' + name] = (f'<!DOCTYPE {name} [ ]><r/>'.encode(), False)
for value in ['$', '!', '+', '*', '?', '#!', '#IMPLIED', 'word', '1', '\u06f2', "'wombat", "'wombat'", ']>', ']>x']:
    cases['dtd-' + value] = (value.encode(), True)
for kind in ['ATTLIST', 'ELEMENT', 'ENTITY', 'NOTATION']:
    tail = {'ATTLIST': "a CDATA 'x'", 'ELEMENT': 'EMPTY', 'ENTITY': "'x'", 'NOTATION': "SYSTEM 'x'"}[kind]
    for name in ['$doc', '!doc', '1doc', 'doc!', 'doc+', 'doc:!bad']:
        cases[f'{kind}-{name}'] = (f'<!{kind} {name} {tail}>'.encode(), True)
for word in ['#!IMPLIED', '#', '#1', '#foo', '#IMPLIED', '#REQUIRED', '#FIXED', '#IMPLIED!', '#IMPLIED+']:
    cases['attlist-' + word] = (f'<!DOCTYPE r [<!ATTLIST r a CDATA {word}>]><r/>'.encode(), False)
for public in ['ok', '{BadName}', '\t', '\u00e9']:
    for declaration in [f'<!DOCTYPE r PUBLIC {public!r} "system"><r/>', f'<!DOCTYPE r [<!ENTITY e PUBLIC {public!r} "system">]><r/>', f'<!DOCTYPE r [<!NOTATION n PUBLIC {public!r}>]><r/>']:
        cases['public-' + declaration] = (declaration.encode(), False)
for data in ['</r>', '<!DOCTYPE r></r>', '<r/></r>', "<!DOCTYPE r [<!ENTITY % e ']><r/>'>%e;"]:
    cases[data] = (data.encode(), False)
libs = {name: setup(path) for name, path in LIBRARIES.items()}
rows = []
for name, (data, external) in cases.items():
    for namespaces in [False, True]:
        for width in [0, 1, 2, 7]:
            rows.append({'name': name, 'data': data.hex(), 'external': external, 'namespaces': namespaces, 'width': width, 'results': {label: run(lib, data, external, namespaces, width) for label, lib in libs.items()}})
report = {'libraries': {label: {'path': path, 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest()} for label, path in LIBRARIES.items()}, 'rows': rows}
path = ROOT / os.environ.get('ORIOLE_REPORT', 'baseline-probe.json')
path.write_text(json.dumps(report, indent=2) + '\n')
for row in rows:
    if not row['namespaces'] and row['width'] == 0:
        print(row['name'], {label: (v['status'], v['error'], v['byte']) for label, v in row['results'].items()})
