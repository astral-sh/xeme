from pathlib import Path
import json
import hashlib
import collections
ns = {}
source = Path('/tmp/oriole-diagnostics-integrated/probe.py').read_text()
exec(source.split('cases = {}')[0], ns)
paths = {'reference': '/home/dev-user/.cache/oriole/expat-build/libexpat.so', 'control': '/tmp/oriole-security-controls-integrated/liboriole_expat.so', 'candidate': '/tmp/oriole-diagnostics-integrated/liboriole_expat.so'}
libs = {key: ns['setup'](path) for key, path in paths.items()}
rows = []
counts = collections.Counter()
for code in range(32, 127):
    char = chr(code)
    for shape, (data, external) in enumerate([
        (f'<!DOCTYPE {char}foo []><r/>', False),
        (f'<!DOCTYPE foo{char} []><r/>', False),
        (f'<!DOCTYPE 1{char} []><r/>', False),
        (f'<!ATTLIST {char}r a CDATA "x">', True),
        (f'<!ATTLIST r a CDATA #{char}X>', True),
        (f'<!ENTITY % p "EMPTY"><!ELEMENT r %p;{char}>', True),
    ]):
        for namespaces in [False, True]:
            for width in [0, 1]:
                values = {key: ns['run'](lib, data.encode(), external, namespaces, width) for key, lib in libs.items()}
                old, new, ref = values['control'], values['candidate'], values['reference']
                counts['cases'] += 1
                changed = old['status'] != new['status'] or old['events'] != new['events']
                regressed = old['error'] == ref['error'] and new['error'] != ref['error']
                if changed: counts['changed_acceptance_or_callbacks'] += 1
                if regressed: counts['regressed_error_codes'] += 1
                if changed or regressed:
                    rows.append({'code': code, 'shape': shape, 'data': data, 'namespaces': namespaces, 'width': width, 'values': values})
report = {'counts': counts, 'differences': rows, 'libraries': {key: {'path': path, 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest()} for key, path in paths.items()}}
Path('/tmp/oriole-diagnostics-integrated/punctuation-probe.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
