from pathlib import Path
import hashlib,io,json,re,tarfile
R=Path('/home/dev-user/code/oss/oriole');W=R/'docs/validation/2026-09-10/dtd-reparse-deferral';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((W/'files.json').read_text());assert sha(W/'evidence.tar.gz')==m['sha256']=='18f16a4f3aeddf8f11b5e5fe7efc3d954022d9c45527cfa034dd0bf0418cd7a9'
with tarfile.open(W/'evidence.tar.gz') as t:
 members=t.getmembers();assert len(members)==m['members']==189 and len({v.name for v in members})==189
 for v in members:
  assert v.isfile() and not v.name.startswith('/') and '..' not in Path(v.name).parts
  b=t.extractfile(v).read();assert len(b)==m['files'][v.name]['bytes'] and hashlib.sha256(b).hexdigest()==m['files'][v.name]['sha256']
 a=t.extractfile('isolated/evidence.tar.gz').read();inner=json.load(t.extractfile('isolated/members.json'));assert hashlib.sha256(a).hexdigest()==inner['archive_sha256']=='fc5e0d4085b79ddac0804a84800549799017f31f410a65fc12ff2c20bcc64241'
 with tarfile.open(fileobj=io.BytesIO(a)) as q:
  members=q.getmembers();assert len(members)==inner['members']==188
  for v in members:
   assert v.isfile() and not v.name.startswith('/') and '..' not in Path(v.name).parts
   b=q.extractfile(v).read();assert len(b)==inner['files'][v.name]['bytes'] and hashlib.sha256(b).hexdigest()==inner['files'][v.name]['sha256']
 assert hashlib.sha256(t.extractfile('isolated/manifest.json').read()).hexdigest()=='4ad3917b2d4427de3418dc5214ec51f0b79b446d0d55df035951d38b01f13106'
assert sha(W/'api-review.json')==sha(Path('/tmp/oriole-dtd-combined-api-review.json'))=='b17d7f7c57fac52ed27e06741b8f79d76a8b13a372f9aa4d527f18132e8c57d9'
assert sha(W/'source-review.json')==sha(Path('/tmp/oriole-dtd-final-source-review.json'))=='34bab17c3ed023392d443afafa28c9b92b70b3262a99c04c443c4e813f4f2f72'
docs=[R/'README.md',R/'docs/review.md',W/'README.md']
for p in docs:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).exists(),(p,target)
s=json.loads((W/'summary.json').read_text());assert s['original_api']['after_passed']==4347 and s['original_api']['after_failed']==393 and s['workspace']['passed']==373 and s['isolated']['workspace_tests']==372 and s['isolated']['allocation_scenarios_per_linkage']==327
r={'status':'passed','scope':'Documentation and compressed archive readback only; no test/build/parser reruns. Prior independent API/source reviews support the claims.','docs':{str(p):sha(p) for p in docs},'archive':{'sha256':sha(W/'evidence.tar.gz'),'outer_members_read_back_and_rehashed':189,'nested_isolated_members_read_back_and_rehashed':188,'isolated_manifest_sha256':'4ad3917b2d4427de3418dc5214ec51f0b79b446d0d55df035951d38b01f13106'},'facts_checked':['Combined4347/393 original API, exactly12 additional deferral fixes and no other rows.','Combined373 workspace checks distinct from isolated372, native6 and327selected-allocation scenarios per linkage.','Strict3318 baseline traces use async-only Oriole, not Expat.','Nine later feed-stage differences remain;18 completion callback counts fixed.','Original source/test phases and actual isolated test failures preserved; both root attempts correctly identified as pre-test OS30.','Same Rust compiler with experimental Ohm defaults disabled only for final checks; byte-identical release linkage to original API/differential preserved.','Historical benchmark/PBS/fuzz scopes remain unchanged.'],'corrections_requested':[],'supporting_reports':{str(W/n):sha(W/n) for n in ['summary.json','source-review.json','api-review.json','files.json']},'audit_script_sha256':sha(Path(__file__))}
p=Path('/tmp/oriole-dtd-docs-review.json');p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p)}))
