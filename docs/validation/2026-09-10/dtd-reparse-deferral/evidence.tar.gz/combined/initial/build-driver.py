from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import time

root = Path('/home/dev-user/code/oss/oriole')
out = Path('/tmp/oriole-dtd-reparse-integrated')
out.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
env = os.environ.copy()
overrides = {
    'CARGO_HOME': '/home/dev-user/.cache/toucan/cargo',
    'CARGO_TARGET_DIR': '/home/dev-user/.cache/oriole/target',
    'CARGO_BUILD_BUILD_DIR': '/home/dev-user/.cache/ohm/build',
    'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST': 'all',
    'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST': 'all',
    'CARGO_BUILD_JOBS': '2',
}
env.update(overrides)
os.sched_setaffinity(0, {3})
files = json.loads(Path('/tmp/oriole-dtd-deferral-study/source.json').read_text())['source_files']
source = {name: sha(root / name) for name in files}
report = {
    'base': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'source_files': source,
    'environment': overrides,
    'commands': [],
}
(out / 'integration.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=root))
shutil.copy2(root / 'crates/oriole/tests/reparse_deferral.rs', out / 'reparse_deferral.rs')
report['tracked_patch_sha256'] = sha(out / 'integration.patch')
report['new_test_sha256'] = sha(out / 'reparse_deferral.rs')
(out / 'source.json').write_text(json.dumps(report, indent=2) + '\n')
for name, args in [
    ('build', ['build', '--release', '-p', 'oriole_expat', '--locked']),
    ('tests', ['test', '--workspace', '--all-targets', '--locked']),
    ('clippy', ['clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('fmt', ['fmt', '--all', '--', '--check']),
]:
    command = ['cargo', '+ohm', *args]
    start = time.time()
    with (out / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    report['commands'].append({'name': name, 'command': command, 'exit_code': result.returncode,
                               'started': start, 'finished': time.time(), 'log_sha256': sha(out / (name + '.log'))})
    if name == 'build' and result.returncode == 0:
        report['libraries'] = {}
        for suffix in ['so', 'a']:
            name_lib = 'liboriole_expat.' + suffix
            shutil.copy2(Path(env['CARGO_TARGET_DIR']) / 'release' / name_lib, out / name_lib)
            report['libraries'][name_lib] = sha(out / name_lib)
    (out / 'checks.json').write_text(json.dumps(report, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
for name, digest in source.items():
    assert sha(root / name) == digest, name
