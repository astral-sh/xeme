# DTD reparse deferral

The existing deferral setting now applies to ordinary DTD token scans. Incomplete nonfinal tokens wait for the existing growth threshold; final input, decoding errors and token-limit overflow force processing. Active ATTLIST continuations keep their earlier dispatch precedence.

The unchanged original API matrix improves from **4,323/417 to 4,335/405** passing/failing configurations: exactly twelve `test_reparse_deferral_is_inherited` fixes and no other row changes. This source is based on 4b and excludes the separately reviewed AsyncEntity fix.

All 372 workspace tests, strict Clippy/formatting, six native C sanitizer checks and 327 allocation scenarios per linkage pass. All 3,318 strict observations against the preceding Oriole runtime are identical. These are bounded checks on the recorded source; Rust release code is not sanitizer-instrumented and leak checking is disabled in the C checks.

The focused Expat oracle has 54 configuration pairs. The 18 incorrect token-completion callback counts are fixed. Nine later growth-stage comparisons remain one 100-space feed earlier than Expat; exact feed scheduling parity is not claimed.

Three existing Rust tests needed explicit finalization or immediate-work settings after the scheduling repair; their original assertions and limits remain. Failed earlier logs and all source phases are preserved, including Clippy test cleanup and the launcher import failure. No upstream assertions or bounds changed.

`final-five-file.patch` contains the complete change against 4b. `final-test-overlay.patch` contains the three existing-test adjustments; the final new test also uses fixed slices for Clippy. The original 08cd two-file patch and original source manifest remain inside the evidence archive. All archive members were read back and rehashed. Executables are excluded; exact library hashes remain in the manifests.
