from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import shutil
import tarfile

root = Path('/home/dev-user/code/oss/oriole')
out = root / 'docs/validation/2026-09-10/dtd-reparse-deferral'
out.mkdir(exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_text())
members = {}
locations = {
    'isolated': Path('/tmp/oriole-dtd-deferral-handoff'),
    'combined/initial': Path('/tmp/oriole-dtd-reparse-integrated'),
    'combined/test-overlay': Path('/tmp/oriole-dtd-reparse-final'),
    'combined/checked': Path('/tmp/oriole-dtd-reparse-checked'),
}
for prefix, directory in locations.items():
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.name not in {'liboriole_expat.so', 'liboriole_expat.a', 'runtests'}:
            members[prefix + '/' + str(path.relative_to(directory))] = path.read_bytes()
checked = load(locations['combined/checked'] / 'checks.json')
assert all(command['exit_code'] == 0 for command in checked['commands'])
for name, digest in checked['source_files'].items():
    data = (root / name).read_bytes()
    assert sha(data) == digest, name
    members['source/' + name] = data
for name in ['manifest.json', 'results.json', 'tests.log']:
    members['baseline-api/' + name] = (Path('/tmp/oriole-async-entity-study/upstream-api') / name).read_bytes()
for name in ['oriole-dtd-final-checks.py', 'oriole-dtd-integrated-build.py',
             'oriole-dtd-combined-api-review.json', 'oriole-dtd-combined-api-audit.py']:
    members['review/' + name] = (Path('/tmp') / name).read_bytes()
members['packaging.py'] = Path(__file__).read_bytes()
counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;', (locations['combined/checked'] / 'tests.log').read_text())
assert sum(int(a) for a, _ in counts) == 373 and sum(int(b) for _, b in counts) == 0
comparison = load(locations['combined/initial'] / 'api-comparison.json')
assert comparison['candidate'] == {'passed': 4347, 'failed': 393}
for location in ['combined/initial', 'combined/test-overlay']:
    assert (locations[location] / 'tests.log').read_text().strip() == 'error: Read-only file system (os error 30)'
summary = {
    'status': 'validated_for_stack_integration',
    'integration_base': checked['base'],
    'source_files': len(checked['source_files']),
    'libraries': checked['release_libraries'],
    'original_api': {'configurations': 4740, 'before_passed': 4335, 'before_failed': 405,
                     'after_passed': 4347, 'after_failed': 393, 'fixed': 12,
                     'new_failures': 0, 'other_changes': 0, 'exit_code': 1},
    'strict_baseline': {'observations': 3318, 'differences': 0, 'reference': 'async-only Oriole3a80, not Expat'},
    'workspace': {'passed': 373, 'clippy': 'passed', 'fmt': 'passed', 'controller': 58616, 'exit_code': 0},
    'isolated': {'base': '4b11ace', 'passed_api': 4335, 'failed_api': 405, 'workspace_tests': 372,
                 'native_c_processes': 6, 'allocation_scenarios_per_linkage': 327,
                 'strict_baseline_observations': 3318},
    'retained_focused_timing_difference': 'Nine of54 Expat comparison configurations release on growth one100-space feed earlier. All18 incorrect completion counts are corrected; no complete timing-parity claim.',
    'check_attempts': 'Both root default-Ohm test launches failed before test execution with OS30. The retry with experimental Ohm defaults disabled passes. An earlier root inference that the first launch repeated the isolated accounting-test failure was incorrect; actual isolated test failures remain separately preserved.',
    'test_only_changes': 'Three existing Rust tests now explicitly flush final input or disable deferral before measuring immediate work. Their error, work, position, callback-count assertions and limits remain unchanged. Three temporary test Vecs become fixed arrays for Clippy. Upstream tests and bounds are unchanged.',
    'release_scope': 'Test-overlay release rebuild is byte-identical to the combined library used by the API/differential; later Vec-to-array cleanup is test-only. No benchmark, full PBS or sustained-fuzz claim for this source.',
}
members['summary.json'] = (json.dumps(summary, indent=2) + '\n').encode()
with (out / 'evidence.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as archive:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
with tarfile.open(out / 'evidence.tar.gz', 'r:gz') as archive:
    assert len(archive.getmembers()) == len(members)
    for member in archive.getmembers():
        assert archive.extractfile(member).read() == members[member.name], member.name
metadata = {'sha256': sha((out / 'evidence.tar.gz').read_bytes()), 'bytes': (out / 'evidence.tar.gz').stat().st_size,
            'members': len(members), 'files': {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(members.items())}}
(out / 'files.json').write_text(json.dumps(metadata, indent=2) + '\n')
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for src, dst in [
    (locations['combined/checked'] / 'source.json', 'source.json'),
    (locations['combined/initial'] / 'api-comparison.json', 'api-comparison.json'),
    (Path('/tmp/oriole-dtd-combined-api-review.json'), 'api-review.json'),
]:
    shutil.copy2(src, out / dst)
print(json.dumps({key: value for key, value in metadata.items() if key != 'files'}, indent=2))
