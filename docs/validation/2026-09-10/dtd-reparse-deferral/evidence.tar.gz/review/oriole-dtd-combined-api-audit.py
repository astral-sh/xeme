from pathlib import Path
import hashlib,json
B=Path('/tmp/oriole-async-entity-study');W=Path('/tmp/oriole-dtd-reparse-integrated');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((B/'upstream-api/manifest.json').read_text());b=json.loads((W/'upstream-api/manifest.json').read_text());assert a.keys()==b.keys()
for k in a:
 if k in ['library_sha256','binary_sha256']:continue
 if k=='compile_command':assert [x.replace(str(B),str(W)) for x in a[k]]==b[k]
 else:assert a[k]==b[k],k
for n,h in b['adapted_sources'].items():assert sha(W/'upstream-api/adapted'/n)==h
for n,h in b['upstream_include_sources'].items():assert sha(W/'upstream-api'/n)==h
assert sha(W/'liboriole_expat.so')==b['library_sha256']=='85066b10a1c5b4613c9d98012c8c9c2f8285e90b9dc01fa395297097c78193c5'
assert sha(B/'liboriole_expat.so')==a['library_sha256'];assert sha(W/'upstream-api/runtests')==b['binary_sha256']
x=json.loads((B/'upstream-api/results.json').read_text());y=json.loads((W/'upstream-api/results.json').read_text());key=lambda r:(r['test'],r['context']);old={key(r):r for r in x['results']};new={key(r):r for r in y['results']};assert len(old)==len(new)==len(x['results'])==len(y['results'])==4740 and old.keys()==new.keys()
for r in [x,y]:assert r['selection_complete'] and r['library_origin_verified'] and not r['timed_out']
changes=[{'before':old[k],'after':new[k]} for k in old if old[k]!=new[k]];assert len(changes)==12 and all(r['before']['test']=='test_reparse_deferral_is_inherited' and r['before']['outcome']=='fail' and r['after']['outcome']=='pass' for r in changes)
assert [x['passed'],x['failed'],y['passed'],y['failed']]==[4335,405,4347,393]
comparison=json.loads((W/'api-comparison.json').read_text());assert changes==comparison['changes'] and comparison['baseline_results_sha256']==sha(B/'upstream-api/results.json') and comparison['candidate_results_sha256']==sha(W/'upstream-api/results.json')
d=W/'differential-baseline';p=json.loads((d/'reference.json').read_text());q=json.loads((d/'oriole.json').read_text());assert p==q and len(p['results'])==3318
summary=json.loads((d/'summary.json').read_text());assert summary['exact_pass'] and not summary['differences']
for k,v in summary['libraries'].items():assert v['sha256_before']==v['sha256_after']==sha(Path(v['path'])) and v['returncode']==0
out={'status':'passed','scope':'Saved originalAPI and strict baseline evidence audit only; no parser reruns. Final combined source/test/check freeze is separately reviewed when available.','candidate_library_sha256':b['library_sha256'],'baseline_library_sha256':a['library_sha256'],'api':{'configurations':4740,'baseline_passed':4335,'baseline_failed':405,'candidate_passed':4347,'candidate_failed':393,'fixed':12,'new_failures':0,'other_row_changes':0,'exact_test':'test_reparse_deferral_is_inherited','all_manifest_fields_except_library_binary_paths_identical':True,'adapted_sources_rehashed':len(b['adapted_sources']),'upstream_include_files_rehashed':len(b['upstream_include_sources']),'unchanged_bounds':{k:b[k] for k in ['chunks','deferral','per_test_seconds','per_test_address_space_bytes','per_test_rss_limit_bytes','total_timeout_seconds']}},'strict_baseline':{'all3318raw_records_identical':True,'control':'AsyncEntity-only Oriole3a80; not Expat','library_hashes_stable':True},'artifacts':{str(p):sha(p) for p in [W/'api-comparison.json',W/'upstream-api/results.json',W/'upstream-api/manifest.json',W/'upstream-api/tests.log',B/'upstream-api/results.json',d/'summary.json',d/'reference.json',d/'oriole.json']},'script_sha256':sha(Path(__file__))}
p=Path('/tmp/oriole-dtd-combined-api-review.json');p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p)}))
