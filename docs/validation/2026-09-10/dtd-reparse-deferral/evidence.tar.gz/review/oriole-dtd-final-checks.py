from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('/home/dev-user/code/oss/oriole')
out = Path('/tmp/oriole-dtd-reparse-checked')
out.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
prior = json.loads(Path('/tmp/oriole-dtd-reparse-final/checks.json').read_text())
overrides = prior['environment']
env = os.environ.copy()
env.update(overrides)
os.sched_setaffinity(0, {3})
report = {
    'base': prior['base'],
    'source_files': {name: sha(root / name) for name in prior['source_files']},
    'environment': overrides,
    'release_libraries': prior['libraries'],
    'prior_release_scope': 'Same production Rust bytes; the new test only replaces three temporary Vecs with fixed arrays. The final release was already byte-identical to the library tested in the combined API/differential.',
    'commands': [],
}
(out / 'source.json').write_text(json.dumps(report, indent=2) + '\n')
for name, args in [
    ('tests', ['test', '--workspace', '--all-targets', '--locked', '--no-fail-fast']),
    ('clippy', ['clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('fmt', ['fmt', '--all', '--', '--check']),
]:
    command = ['cargo', '+ohm', '-Zohm-defaults=no', *args]
    start = time.time()
    with (out / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    report['commands'].append({'name': name, 'command': command, 'exit_code': result.returncode,
                               'started': start, 'finished': time.time(), 'log_sha256': sha(out / (name + '.log'))})
    (out / 'checks.json').write_text(json.dumps(report, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
for name, digest in report['source_files'].items():
    assert sha(root / name) == digest, name
