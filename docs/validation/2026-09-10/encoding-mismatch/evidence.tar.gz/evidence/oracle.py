import ctypes as c
import hashlib
import itertools
import json
from pathlib import Path

P, S, I = c.c_void_p, c.c_char_p, c.c_int
UNKNOWN = c.CFUNCTYPE(I, P, S, P)
DECL = c.CFUNCTYPE(None, P, S, S, I)
paths = {
    'reference': Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so'),
    'baseline': Path('/tmp/oriole-dtd-combined.so'),
    'candidate': Path('/tmp/oriole-encoding-mismatch/liboriole_expat.so'),
}
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(path, data, mode, protocol, width):
    lib = c.CDLL(str(path))
    sigs = {
      'XML_ParserCreate': (P,[S]), 'XML_ParserFree': (None,[P]),
      'XML_ExternalEntityParserCreate': (P,[P,S,S]), 'XML_Parse': (I,[P,S,I,I]),
      'XML_GetErrorCode': (I,[P]), 'XML_GetCurrentByteIndex': (c.c_long,[P]),
      'XML_SetUnknownEncodingHandler': (None,[P,UNKNOWN,P]),
      'XML_SetXmlDeclHandler': (None,[P,DECL]),
    }
    for name,(r,a) in sigs.items():
      fn = getattr(lib,name); fn.restype=r; fn.argtypes=a
    unknown, declarations = [], []
    def on_unknown(_,name,__): unknown.append(name.decode()); return 0
    def on_decl(_,version,encoding,standalone):
      declarations.append([version.decode() if version else None,encoding.decode() if encoding else None,standalone])
    callbacks = UNKNOWN(on_unknown), DECL(on_decl)
    parent = lib.XML_ParserCreate(protocol if mode == 'document' else None)
    assert parent
    child = None
    parser = parent
    try:
      if mode != 'document':
        child = lib.XML_ExternalEntityParserCreate(parent,None if mode == 'dtd' else b'',protocol)
        assert child
        parser=child
      lib.XML_SetUnknownEncodingHandler(parser,callbacks[0],None)
      lib.XML_SetXmlDeclHandler(parser,callbacks[1])
      status=1
      for offset in range(0,len(data),width):
        piece=data[offset:offset+width]
        status=lib.XML_Parse(parser,piece,len(piece),int(offset+width>=len(data)))
        if not status: break
      return {'status':status,'error':lib.XML_GetErrorCode(parser),'unknown':unknown,'declarations':declarations,'position':lib.XML_GetCurrentByteIndex(parser)}
    finally:
      if child: lib.XML_ParserFree(child)
      lib.XML_ParserFree(parent)

rows=[]
for name, mode, bom, width, protocol in itertools.product(
  ['UTF-16','utf-16','UtF-16','UTF-16LE','UTF-16BE','UTF-17'],
  ['document','dtd','content'],[False,True],[1,2,3,4096],[None,b'UTF-8',b'ISO-8859-1']):
  declaration=f"<?xml version='1.0' encoding='{name}'?>"
  suffix='<!ELEMENT r EMPTY>' if mode=='dtd' else '<r/>'
  data=(b'\xef\xbb\xbf' if bom else b'')+(declaration+suffix).encode()
  result={k:run(p,data,mode,protocol,width) for k,p in paths.items()}
  rows.append({'name':name,'mode':mode,'bom':bom,'width':width,'protocol':protocol.decode() if protocol else None,'data':data.hex(),'results':result})
for endian, mode, bom, width in itertools.product(['le','be'],['document','dtd','content'],[False,True],[1,2,3,4096]):
  suffix='<!ELEMENT r EMPTY>' if mode=='dtd' else '<r/>'
  data=((b'\xff\xfe' if endian=='le' else b'\xfe\xff') if bom else b'')+("<?xml version='1.0' encoding='UTF-16'?>"+suffix).encode('utf-16-'+endian)
  result={k:run(p,data,mode,None,width) for k,p in paths.items()}
  rows.append({'name':'valid-utf16','endian':endian,'mode':mode,'bom':bom,'width':width,'data':data.hex(),'results':result})
for form, name, mode, bom, width in itertools.product(
  ["<?xml invalid='x' encoding='{name}'?>", "<?xml version='2.0' encoding='{name}'?>",
   "<?xml encoding='{name}' version='1.0'?>", "<?xml version='1.0'\r\n encoding='{name}'?>"],
  ['UTF-16','UTF-16LE','UTF-17'],['document','dtd','content'],[False,True],[1,2,3,4096]):
  suffix='<!ELEMENT r EMPTY>' if mode=='dtd' else '<r/>'
  data=(b'\xef\xbb\xbf' if bom else b'')+(form.format(name=name)+suffix).encode()
  result={k:run(p,data,mode,None,width) for k,p in paths.items()}
  rows.append({'name':name,'form':form,'mode':mode,'bom':bom,'width':width,'data':data.hex(),'results':result})
keys=['status','error','unknown','declarations']
def semantic(result): return {k:result[k] for k in keys}
fixed=[]; new=[]; remaining=[]
for i,row in enumerate(rows):
  r,b,a=(semantic(row['results'][k]) for k in ['reference','baseline','candidate'])
  if r!=b and r==a: fixed.append(i)
  if r==b and r!=a: new.append(i)
  if r!=a: remaining.append(i)
outcome_fixed=[]; outcome_new=[]; position_fixed=[]; position_new=[]
for i,row in enumerate(rows):
  r,b,a=(row['results'][k] for k in ['reference','baseline','candidate'])
  outcome=lambda x: (x['status'],x['error'],x['unknown'])
  if outcome(r)!=outcome(b) and outcome(r)==outcome(a): outcome_fixed.append(i)
  if outcome(r)==outcome(b) and outcome(r)!=outcome(a): outcome_new.append(i)
  if r['position']!=b['position'] and r['position']==a['position']: position_fixed.append(i)
  if r['position']==b['position'] and r['position']!=a['position']: position_new.append(i)
report={'outcome_fixed':outcome_fixed,'outcome_new':outcome_new,'position_fixed':position_fixed,'position_new':position_new,'cases':len(rows),'fixed':fixed,'new':new,'remaining':remaining,'rows':rows,'hashes':{str(p):digest(p) for p in [Path(__file__),*paths.values()]},'scope':'Status, error code, unknown-encoding callback and XML declaration callbacks; byte positions retained separately.'}
Path('/tmp/oriole-encoding-mismatch/oracle.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:len(v) if isinstance(v,list) else v for k,v in report.items() if k not in ['rows','hashes']}))
assert not new and not outcome_new and not position_new
