"""Retain the complete selected and isolated end-tag studies without binaries."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

repo = Path('/home/dev-user/code/oss/oriole-end-tag-integration')
out = repo / 'docs/validation/2026-09-10/end-tag-integration'
directories = {
    'integrated/source-build': '/tmp/oriole-end-tag-integration-study',
    'integrated/gates': '/tmp/oriole-end-tag-integration-gates-handoff',
    'integrated/cpython': '/tmp/oriole-end-tag-integration-cpython-gates',
    'integrated/native': '/tmp/oriole-end-tag-integration-timing-study',
    'integrated/python': '/tmp/oriole-end-tag-integration-python-study',
    'integrated/source-review': '/tmp/oriole-end-tag-integration-independent-review',
    'isolated/source-build-profiles': '/tmp/oriole-matching-end-tags-study',
    'isolated/gates': '/tmp/oriole-matching-end-tags-gates-handoff',
    'isolated/cpython': '/tmp/oriole-matching-end-tags-cpython-gates',
    'isolated/native': '/tmp/oriole-matching-end-tags-timing-study',
    'isolated/python': '/tmp/oriole-matching-end-tags-python-study',
    'isolated/source-review': '/tmp/oriole-matching-end-tags-independent-review',
    'isolated/timing-consumer-reviews': '/tmp/oriole-matching-end-tags-timing-review-handoff',
}
controllers = [
    '/tmp/oriole-package-end-tag-integration.py',
    '/tmp/oriole-summarize-cohorts.py',
    '/tmp/oriole-end-tag-integration-components.json',
    '/tmp/oriole-end-tag-integration-assembly.json',
    '/tmp/oriole-build-end-tag-integration.py',
    '/tmp/oriole-prepare-end-tag-integration-timing.py',
    '/tmp/oriole-time-end-tag-integration-native.py',
    '/tmp/oriole-prepare-end-tag-integration-python.py',
    '/tmp/oriole-time-end-tag-integration-python.py',
    '/tmp/oriole-end-tag-integration-cpython-gates.py',
    '/tmp/oriole-build-matching-end-tags.py',
    '/tmp/oriole-prepare-matching-end-timing.py',
    '/tmp/oriole-time-matching-end-native.py',
    '/tmp/oriole-prepare-matching-end-python.py',
    '/tmp/oriole-time-matching-end-python.py',
    '/tmp/oriole-matching-end-cpython-gates.py',
]
copies = {
    'source.json': '/tmp/oriole-end-tag-integration-study/source.json',
    'assembly.json': '/tmp/oriole-end-tag-integration-assembly.json',
    'components.json': '/tmp/oriole-end-tag-integration-components.json',
    'gates.json': '/tmp/oriole-end-tag-integration-gates/summary.json',
    'workspace-counts.json': '/tmp/oriole-end-tag-integration-gates/workspace-checks/counts.json',
    'native-summary.json': '/tmp/oriole-end-tag-integration-timing-study/summary.json',
    'python-summary.json': '/tmp/oriole-end-tag-integration-python-study/summary.json',
    'source-review.json': '/tmp/oriole-end-tag-integration-independent-review/review.json',
}
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(Path(path).read_text())

# Check all required inputs before creating a package.
assert load('/tmp/oriole-end-tag-integration-study/build.json')['status'] == 'passed'
gates = load(copies['gates.json'])
assert gates['status'] == 'correctness_parity_gates_passed'
assert gates['workspace'] == {'tests': 397, 'doc-tests': 1}
assert gates['api']['all4740rows_exact']
assert gates['api']['passed'] == 4347 and gates['api']['failed'] == 393
assert load('/tmp/oriole-end-tag-integration-timing-study/timing-controller.json')['status'] == 'passed'
assert load('/tmp/oriole-end-tag-integration-python-study/timing-controller.json')['status'] == 'passed'
source = load(copies['source.json'])
assert all(sha((repo / name).read_bytes()) == digest for name, digest in source['source_sha256'].items())
for path in [*controllers, *copies.values()]:
    assert Path(path).is_file(), path
paths = {}
for prefix, path in directories.items():
    directory = Path(path)
    assert directory.is_dir(), directory
    for path in sorted(directory.rglob('*')):
        if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts:
            paths[prefix + '/' + str(path.relative_to(directory))] = path
for name in controllers:
    paths['controllers/' + Path(name).name] = Path(name)

out.mkdir(parents=True, exist_ok=False)
members, excluded = [], []
with tarfile.open(out / 'evidence.tar.gz', 'w:gz', compresslevel=9) as archive:
    for name, path in sorted(paths.items()):
        data = path.read_bytes()
        entry = {'path': name, 'source': str(path), 'bytes': len(data), 'sha256': sha(data)}
        if data.startswith(b'\x7fELF') or data.startswith(b'!<arch>\n'):
            excluded.append(entry)
            continue
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
        members.append(entry)
with tarfile.open(out / 'evidence.tar.gz', 'r:gz') as archive:
    actual = archive.getmembers()
    assert len(actual) == len(members)
    for member, entry in zip(actual, members):
        assert member.isfile() and member.name == entry['path'] and member.size == entry['bytes']
        assert sha(archive.extractfile(member).read()) == entry['sha256'] == sha(Path(entry['source']).read_bytes())
for entry in excluded:
    assert sha(Path(entry['source']).read_bytes()) == entry['sha256']
(out / 'archive-members.json').write_text(json.dumps({'members': members, 'excluded_binaries': excluded}, indent=2) + '\n')
for name, source_path in copies.items():
    shutil.copy2(source_path, out / name)
summary = {
    'runtime_commit': '503a55957f7cdebcc0b3fb3ada2751ffdb8cb9c9',
    'source_files': 70,
    'source_manifest_sha256': sha((out / 'source.json').read_bytes()),
    'libraries': load('/tmp/oriole-end-tag-integration-study/build.json')['libraries'],
    'workspace': {'all_targets': 397, 'doc_tests': 1, 'fmt_and_strict_clippy': 'passed'},
    'api': {'passed': 4347, 'failed': 393, 'original_configurations': 4740, 'canonical_bounds_verified': True},
    'cpython_each_linkage': {'tests': 802, 'failures': 2, 'skips': 14, 'expected_failures': 3},
    'native': load(out / 'native-summary.json'),
    'python': load(out / 'python-summary.json'),
    'archive': {
        'sha256': sha((out / 'evidence.tar.gz').read_bytes()),
        'members': len(members),
        'excluded_binaries': len(excluded),
        'raw_bytes': sum(entry['bytes'] for entry in members),
        'bytes': (out / 'evidence.tar.gz').stat().st_size,
        'all_members_and_origins_readback_verified': True,
    },
    'scope': 'Selected combined dd16 library exactly assembled as503a above doc-only71bf parent. Integrated behavior and performance controls use3694; isolated fdea uses5af. All conditions retained; component gains are not additive. Later timing/consumer/assembly and final documentation audits are separate indexed outer receipts.',
}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary['archive'], indent=2), flush=True)
