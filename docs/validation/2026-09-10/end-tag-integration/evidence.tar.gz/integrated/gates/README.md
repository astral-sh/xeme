# Combined end-tag integration gate handoff

Frozen combined candidate shared `dd16d23e…`, static `fbbef92d…`, integrated parent `64a270e` / `3694b683…`. All 70 source hashes remain unchanged. Independent temporary-file patch application reconstructs the exact source, and actual fresh Rust compiler arguments match the parent after private-path normalization.

The original 4,740 API cases retain 4,347 passes and 393 failures with original 3-second/1GiB/768MiB/240-second bounds and raw exit 1. No assertion or allocation ceiling changed. Workspace passes 397 all-target tests plus one documentation test, strict Clippy and formatting. Six C ASan/UBSan programs pass, with 327 allocation scenarios per linkage; Rust release code is uninstrumented and leak checking disabled.

Strict 3,318 traces, 36,456 custom-alias controls, 2,392 malformed cases and 1,304 publication cases match the direct 3694 parent. Successful alias traces are not individually retained: controllers/templates and zero-difference reports remain. Full strict, malformed and publication observations are retained. Existing reference callback-position differences remain explicit.

The same additional 38 lifecycle cases / 114 parser executions and 6 selected-OOM scenarios per library match 3694. No new supplemental assertions or thresholds were introduced. The corrected OOM helper records suspended 33 versus NoMemory 1 on repeated terminal calls, and asserts no extra allocation/callback and zero selected live blocks. Its earlier failed assumption belongs to the separately preserved isolated-study handoff 5661265d; this composed study uses the corrected helper without repeating that failed attempt.

Source/design/composition reviews, compilation receipts, controllers, raw outputs and saved-data audits are retained. Native/Python timings, strict CPython and adoption are separate root-owned evidence. Executables/static libraries are excluded by magic and indexed with hashes.
