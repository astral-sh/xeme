"""Create an immutable gate handoff and rehash every stored member; no parser execution."""
from pathlib import Path
import gzip,hashlib,io,json,shutil,tarfile
if not __debug__:raise RuntimeError('Assertions required')
r=Path('/tmp/oriole-end-tag-integration-gates');out=Path('/tmp/oriole-end-tag-integration-gates-handoff');study=Path('/tmp/oriole-end-tag-integration-study')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
assert not out.exists()
assert load(r/'summary.json')['status']=='correctness_parity_gates_passed'
assert (r/'independent-original-gates/review.json').exists()
source=load(r/'source.json');assert len(source['source_sha256'])==70
assert all(h(Path(source['worktree'])/n)==v for n,v in source['source_sha256'].items())
assert all(h(study/n)==v for n,v in load(r/'build.json')['libraries'].items())
# Freeze supplementary source-only reviews and original compilation receipts.
for label,path in [('source-review',Path('/tmp/oriole-end-tag-integration-independent-review')),('design-review',Path('/tmp/oriole-matching-end-tag-design-review'))]:
 assert not (r/label).exists();shutil.copytree(path,r/label)
be=r/'build-evidence';be.mkdir()
for n in ['release.log','focused.log','clippy.log','fmt-write.log','oriole-build-end-tag-integration.py']:shutil.copyfile(study/n,be/n)
shutil.copyfile('/tmp/oriole-end-tag-integration-components.json',r/'components.json')
(r/'HANDOFF.md').write_text("""# Combined end-tag integration gate handoff

Frozen combined candidate shared `dd16d23e…`, static `fbbef92d…`, integrated parent `64a270e` / `3694b683…`. All 70 source hashes remain unchanged. Independent temporary-file patch application reconstructs the exact source, and actual fresh Rust compiler arguments match the parent after private-path normalization.

The original 4,740 API cases retain 4,347 passes and 393 failures with original 3-second/1GiB/768MiB/240-second bounds and raw exit 1. No assertion or allocation ceiling changed. Workspace passes 397 all-target tests plus one documentation test, strict Clippy and formatting. Six C ASan/UBSan programs pass, with 327 allocation scenarios per linkage; Rust release code is uninstrumented and leak checking disabled.

Strict 3,318 traces, 36,456 custom-alias controls, 2,392 malformed cases and 1,304 publication cases match the direct 3694 parent. Successful alias traces are not individually retained: controllers/templates and zero-difference reports remain. Full strict, malformed and publication observations are retained. Existing reference callback-position differences remain explicit.

The same additional 38 lifecycle cases / 114 parser executions and 6 selected-OOM scenarios per library match 3694. No new supplemental assertions or thresholds were introduced. The corrected OOM helper records suspended 33 versus NoMemory 1 on repeated terminal calls, and asserts no extra allocation/callback and zero selected live blocks. Its earlier failed assumption belongs to the separately preserved isolated-study handoff 5661265d; this composed study uses the corrected helper without repeating that failed attempt.

Source/design/composition reviews, compilation receipts, controllers, raw outputs and saved-data audits are retained. Native/Python timings, strict CPython and adoption are separate root-owned evidence. Executables/static libraries are excluded by magic and indexed with hashes.
""")
out.mkdir()
entries=[];excluded=[]
for p in sorted(r.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink()
 data=p.read_bytes();row={'path':p.relative_to(r).as_posix(),'origin':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 if data.startswith(b'\x7fELF') or data.startswith(b'!<arch>\n'):
  excluded.append(row);continue
 entries.append(row)
with (out/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for row in entries:
    data=Path(row['origin']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
    info=tarfile.TarInfo(row['path']);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
(out/'archive-members.json').write_text(json.dumps(entries,indent=2)+'\n')
(out/'excluded-binaries.json').write_text(json.dumps(excluded,indent=2)+'\n')
shutil.copyfile(r/'summary.json',out/'summary.json');shutil.copyfile(r/'HANDOFF.md',out/'README.md');shutil.copyfile(__file__,out/'package.py')
expected={row['path']:row for row in entries};nested=[]
with tarfile.open(out/'evidence.tar.gz') as t:
 members=t.getmembers();assert len(members)==len(entries) and len({m.name for m in members})==len(members)
 for m in members:
  assert m.isfile();data=t.extractfile(m).read();row=expected[m.name];assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];assert h(row['origin'])==row['sha256']
  if m.name in ['source.tar.gz','workspace-checks/source.tar.gz']:
   with tarfile.open(fileobj=io.BytesIO(data)) as nt:
    hashes={n.name:hashlib.sha256(nt.extractfile(n).read()).hexdigest() for n in nt if n.isfile()}
   assert hashes==source['source_sha256'];nested.append({'archive':m.name,'members':len(hashes),'hashes_match_frozen_source':True})
review={'status':'full_member_and_origin_readback_passed','archive_sha256':h(out/'evidence.tar.gz'),'members':len(entries),'uncompressed_bytes':sum(row['bytes']for row in entries),'excluded_binaries':len(excluded),'nested_source_archives':nested,'live_source_unchanged':all(h(Path(source['worktree'])/n)==v for n,v in source['source_sha256'].items())}
(out/'readback.json').write_text(json.dumps(review,indent=2)+'\n')
files={p.name:{'sha256':h(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()}
(out/'manifest.json').write_text(json.dumps({'status':'complete_gate_handoff','files':files,'source_manifest_sha256':h(r/'source.json'),'source_files':70,'candidate_libraries':load(r/'build.json')['libraries'],'archive_members':len(entries),'excluded_binaries':len(excluded)},indent=2)+'\n')
for name,row in files.items():assert h(out/name)==row['sha256'] and (out/name).stat().st_size==row['bytes']
print(json.dumps({'path':str(out),'manifest_sha256':h(out/'manifest.json'),'outer_files_including_manifest':len(files)+1,'archive_sha256':h(out/'evidence.tar.gz'),'archive_bytes':(out/'evidence.tar.gz').stat().st_size,'members':len(entries),'excluded_binaries':len(excluded),'readback':review},indent=2))
