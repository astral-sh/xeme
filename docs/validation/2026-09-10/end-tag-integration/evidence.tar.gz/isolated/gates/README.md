# Matching end-tag gate handoff

Frozen candidate shared `fdea997d…`, static `33ec4171…`, base `5bc806e`; all 70 source hashes unchanged. Source review and correctness gates pass; no performance selection is claimed here.

The original 4,740 API cases retain 4,347 passes and 393 failures under 3 seconds per case, 1 GiB address space, 768 MiB RSS, and 240 seconds total. Raw exit 1 and all original assertions are preserved. Workspace checks pass 394 tests plus one documentation test, strict Clippy and formatting. Six C ASan/UBSan programs pass, including 327 allocation scenarios per linkage. Rust release code is not sanitizer-instrumented; leak checking is disabled.

Strict 3,318 traces, 36,456 custom-alias controls, 2,392 malformed cases and 1,304 publication cases match the baseline. Successful custom-alias traces are not individually retained; the original executed controllers, generated templates and zero-difference reports are retained. Full malformed and publication observations are retained. Existing Expat publication-position differences remain explicit.

Additional End-handler controls are separate: 38 cases / 114 parser executions with exact candidate/baseline records, and six selected-allocation scenarios per library (four forced failures, two successes). UTF-16 reference callback differences and supplementary post-parse context snapshots are classified without normalization of original records. The first allocation helper failed on an overly strong retry-error assumption before running the candidate; its raw failure and source are preserved under `end-oom/`. The completed `end-oom-final/` records actual retry errors (including suspended 33), asserts no extra callbacks/allocations and zero live selected blocks, and compares every baseline/candidate record.

Full CPython, wall timings and adoption are outside this handoff. Source files, tools, commands, raw outputs and independent reviews are retained. Executables/static libraries are excluded by magic with their hashes recorded.
