from pathlib import Path
import hashlib,json,subprocess,tarfile
O=Path(__file__).parent;B=Path('/tmp/oriole-text-frames-pr/release');base='5bc806e5fc2a545f22c75f2a1bcbef45cfa3632b'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((B/'source.json').read_bytes());assert len(m['source_sha256'])==69
paths=['crates/oriole/src/lib.rs','crates/oriole/src/encoding.rs','crates/oriole/src/lexical.rs','crates/oriole/src/names.rs']
with tarfile.open(B/'source.tar.gz') as t:
 entries={x.name:t.extractfile(x).read() for x in t if x.isfile()}
assert set(entries)==set(m['source_sha256'])
for name,h in m['source_sha256'].items():assert hashlib.sha256(entries[name]).hexdigest()==h
for name in paths:
 data=subprocess.check_output(['git','-C','/home/dev-user/code/oss/oriole','show',base+':'+name]);assert data==entries[name]
 p=O/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
r={'status':'design_review_no_blocker_for_bounded_prototype','scope':'Source-only design review on exact5bc806e; no implementation approval claim, build, parser probe, tests or timing. The actual future patch requires its own review.',
'initial_review_sha256':'dc9c2942f329de6fa8468e62f50e5df1cc42781aafdc042322e2145f5323aaa4','followup':'Explicit closing-byte-before-name-comparison ordering added; preserved initial draft and generator.', 'base':base,'source_manifest_sha256':sha(B/'source.json'),'source_hashes':{name:m['source_sha256'][name] for name in paths},
'proposed_guards':['ScanMode::Tag and prefix </; retain the existing initial name-start check.','Exactly one source, !fragment, source.native_utf8_byte_index().is_some(), !source.has_conversions(), nonempty stack, top.raw_encoding.is_none().','Compute expected raw name length+3 with checked_add; require end<=current max_token; use checked byte ranges for </, exact top.raw_name and final >. No whitespace or suffix allowance inside token.','Require sufficient input and check get(end-1)==Some(>) BEFORE the potentially long raw-name equality. Otherwise deferral-disabled one-byte mismatched names with a long common prefix can repeat the equality work. This cheap closing-byte prerequisite preserves scanner amortization.',
 'Apply after unchanged nonfinal reparse-deferral gate. Return only a local optional completed length; no borrowed name/source guard or cached proof crosses callback/feed/core-call boundaries.'],
'invariants':[
 'The stored top raw_name was admitted by the same fixed parser NameRules; namespace QName validation already succeeded where enabled. raw_encoding=None means opening lexical/decoded spelling had no conversion entry. Exact native plainUTF8 bytes therefore form the same valid nonempty name and contain no forbidden XML character.',
 'For eligible plain token, lexical decoded() returns Borrowed and same_name_encoding() compares empty sequences. Removing scan_token, invalid_xml_char, take_name, decoded-name comparison removes no selected allocation in this case. token_scratch clear/append, account_source, current_raw swap, emit, namespace restoration and consume must stay unchanged.',
 'sources.len()==1 plus !fragment excludes entity initial_depth/asynchronous closing rules; external DTD and CDATA paths are dispatched earlier. Nonempty stack preserves parse_end outside-root check outcome. Config name rules are not mutable through a public setter during parser lifetime.',
 'Exact prefix ends before any following markup/text; data beyond the closing > does not alter this token. Wrong name, extra characters, whitespace, incomplete name/>, converted/custom data, external source, empty stack and oversized end all use old scanner/parse_end, preserving diagnostics and limit precedence.',
 'end_element must remain the sole stack pop/event/namespace restoration implementation. Its fallible emit and binding restoration preserve the same partially queued events and errors. The token raw swap remains before parsed? so both events and terminal error retain their previous raw publication order.',
 'No source-scanner state needs publishing on fast success: ordinary consume resets it. A terminal allocation/accounting error must retain existing error latching/reentry behavior; do not add an earlier consume or raw publication. Candidate flags must not bypass foreign-DTD or pending-event lifecycle.'
],
'compact_shape':'One private pure/helper predicate returning Option<usize>, called after existing deferral and initial-name checks; reuse the existing token/semantic closure, guard only redundant validation and choose existing end_element(position) for proven case. Keep proof local rather than new Parser state.',
'focused_gates':[
 'Identical ASCII and Unicode end names, every byte feed split including incomplete UTF8, deferral enabled/disabled, and final/nonfinal data; compare full callback and error positions with baseline.',
 'Close length equal max_token and one byte above it, including an opening tag that fits but closing tag needs one extra byte. Invalid/mismatched and whitespace end tags must fall back with exact error precedence.',
 'Namespaces: default/prefixed names, shadowed binding restoration order, triplets, sibling scopes, and End/EndNamespace handler mutation and suspend/resume; verify DefaultCurrent, raw context, byte counts, line/column, tag followed by text or error.',
 'Internal entity and external general-child balancing, fabricated-name/custom aliases/raw-encoding controls, UTF16 and custom converted streams remain unchanged fallback. No weakening of legal parent/child lifetime constraints.',
 'Selected allocation fail-at-each-call on token buffer growth, End event enqueue and namespace restoration; preserve callback prefix, current raw state, terminal no-allocation retry and zero-live allocator cleanup. Retain original public API ceilings/assertions.',
 'Long matching names and one-byte feeds must preserve deferral/scanner amortization. Prefix comparison occurs only for complete sufficient input; failed fast checks remain linear in the available/bounded name, with no cached offset invalidation issue.'
],
'performance_scope':'No benefit claim from this proof. End-tag scanning cost must be measured independently on the frozen candidate; generated and Unicode/fallback controls should retain all regressions.',
'evidence_sha256':{str(B/'source.json'):sha(B/'source.json'),str(B/'source.tar.gz'):sha(B/'source.tar.gz'),str(Path(__file__)):sha(__file__)}}
(O/'review.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'sha256':sha(O/'review.json'),'status':r['status']}))
