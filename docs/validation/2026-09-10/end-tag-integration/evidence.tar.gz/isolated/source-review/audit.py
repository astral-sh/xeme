"""Source-only review of frozen native end-tag proof reuse. No parser runs."""
from pathlib import Path
import hashlib,json,re,shlex,subprocess,tarfile
B=Path('/tmp/oriole-matching-end-tags-study');O=Path(__file__).parent
H={}
def read(p):
 p=Path(p);d=p.read_bytes();H[str(p)]=hashlib.sha256(d).hexdigest();return d
def sha(p):read(p);return H[str(Path(p))]
def load(p):return json.loads(read(p))
m=load(B/'source.json');build=load(B/'build.json');W=Path(m['worktree']);base='5bc806e5fc2a545f22c75f2a1bcbef45cfa3632b'
assert m['base']==base and len(m['source_sha256'])==70
with tarfile.open(B/'source.tar.gz') as t: frozen={x.name:t.extractfile(x).read() for x in t if x.isfile()}
assert set(frozen)==set(m['source_sha256'])
changed=[]
for p,h in m['source_sha256'].items():
 assert hashlib.sha256(frozen[p]).hexdigest()==sha(W/p)==h
 prior=subprocess.check_output(['git','-C',str(W),'show',base+':'+p])
 if prior!=frozen[p]:changed.append(p)
assert changed==['crates/oriole/src/lib.rs']
s=frozen[changed[0]].decode();old=subprocess.check_output(['git','-C',str(W),'show',base+':'+changed[0]]).decode()
helper=s[s.index('    fn matching_root_end_tag'):s.index('    fn next_event_inner')]
for prerequisite in ['self.fragment || self.sources.len() != 1','source.native_utf8_byte_index()?','source.has_conversions()','self.stack.last()?','element.raw_encoding.is_some()','raw_name.len().checked_add(3)?','end > limit || bytes.get(end - 1) != Some(&b\'>\')','bytes.starts_with(b"</")','bytes.get(2..end - 1) == Some(element.raw_name.as_bytes())']:
 assert prerequisite in helper,prerequisite
assert helper.index('bytes.get(end - 1)')<helper.index('bytes.get(2..end - 1)')
# Critical old ownership/publication and balancing routines remain exact.
for start,end in [('            self.account_source(end)?;','            let parsed = (|| {'),('            // Parsing only writes queued raw overrides.','    fn parse_prolog_literal'),('    fn parse_end(','    fn expand_name(')]:
 a=s[s.index(start):s.index(end,s.index(start))];b=old[old.index(start):old.index(end,old.index(start))];assert a==b,(start,end)
assert s.index('if deferral && self.source().should_defer(max_token)')<s.index('let matched_end =')
assert s.index('"invalid element name",\n                        name_offset')<s.index('let matched_end =')
assert 'ScanMode::Tag if matched_end.is_some() => self.end_element(position)?' in s
assert 'if matched_end.is_none()\n                    && !matches!(planned' in s
assert build['source_manifest_sha256']==sha(B/'source.json') and build['status']=='passed' and build['source_unchanged']
for j in build['commands']:assert j['exit']==0 and sha(B/(j['name']+'.log'))==j['log_sha256']
assert 'test result: ok. 2 passed; 0 failed;' in read(B/'focused.log').decode()
inv=load(B/'compiler-invocations.json');log=read(B/'release.log').decode()
assert inv==[l for l in log.splitlines() if 'Running' in l and '/rustc ' in l]
crates={}
for name in ['oriole_storage','oriole','oriole_expat']:
 rows=[l for l in inv if '--crate-name '+name+' ' in l];assert len(rows)==1
 items=shlex.split(rows[0].strip()[len('Running `'):-1]);ri=next(i for i,x in enumerate(items) if x.endswith('/bin/rustc'))
 env=dict(x.split('=',1) for x in items[:ri]);args=items[ri:]
 assert env['CARGO_MANIFEST_DIR']==str(W/'crates'/name)
 source_arg=next(x for x in args[1:] if x.endswith('.rs'))
 assert (W/source_arg).resolve()==W/'crates'/name/'src/lib.rs'
 assert args[0]=='/home/dev-user/.rustup/toolchains/ohm/bin/rustc' and any(x.startswith('--emit=dep-info') and 'link' in x for x in args)
 assert '/home/dev-user/.cache/ohm/verified-build/' in args[args.index('--out-dir')+1]
 crates[name]=rows[0]
for p,h in build['libraries'].items():assert sha(B/p)==h
for p in ['candidate.patch','source.tar.gz','oriole-build-matching-end-tags.py']:sha(B/p)
assert sha('/tmp/oriole-matching-end-tag-design-review/review.json')=='0f82f5b38237e1fab1eec8d6c3ddb4e483a793ab0121d1814b4a3b1e71393bbc'
(O/'candidate.patch').write_bytes((B/'candidate.patch').read_bytes());(O/'lib.rs').write_bytes(frozen[changed[0]])
r={'status':'source_review_passed_no_findings','scope':'Independent exact frozen-source and focused-test source review, with saved build/hash identity check. No parser/build/test or timing execution. Broader gates and performance selection remain separate.',
'base':base,'source_files':70,'source_manifest_sha256':sha(B/'source.json'),'patch_sha256':sha(B/'candidate.patch'),'libraries':build['libraries'],
'findings':[],'audit_history':'Initial script assumed bare absolute rustc command; actual verbose commands carry recorded CARGO environment and relative source paths. Corrected parser validates that environment and resolves source against the recorded worktree cwd; no build/runtime failure inferred.',
'invariants_verified':[
 'Helper implements every design guard: exactly one nonfragment source, native unanchoredUTF8, no conversion entries, nonempty stack and raw_encodingNone. Name length uses checked_add(3), maximum token limit remains a prerequisite, and all recognition accesses are byte get/starts_with, not potentially invalid str slicing.',
 'Expected closing byte is checked before long raw-name comparison. This prevents repeated prefix comparison for growing mismatched names with deferral disabled; only a sufficiently complete potentially matching token performs the equality. All incomplete/ineligible/mismatched forms retain resumable scanner behavior.',
 'matched_end is a local Option<usize> computed after existing initial-name and deferral gates. Start-tag planning still excludes end tags; this proof cannot change TagScanner plan/cache state. The proof has no owned allocation and retains no borrowed parser data across later mutations or callbacks.',
 'On eligible native text, same validated opening raw_name proves name/XML character validity and old decoded() would borrow; raw_encodingNone plus no conversions prove old same_name_encoding equality. The skipped phases allocate nothing in this eligible path; resource accounting and selected allocation sequence are retained.',
 'account_source→position→token scratch clear/append is byte-identical. Existing end_element performs stack pop, End event enqueue, namespace restoration and close-root bookkeeping. Raw token swap before parsed? and scratch restore/consume after it are byte-identical, preserving queued-prefix and terminal-error publication.',
 'parse_end/end_element source itself is unchanged. Fragment/external initial_depth/asynchronous behavior, whitespace names, mismatches, converted/custom aliases and oversized tags all fall back. Scanner state is reset only by unchanged consume; no new persistent cache state or lifecycle flags are added.'
],
'focused_tests_scope':{'owner_recorded_passes':2,'source_review':'Every closing-byte split for ASCII/Unicode/prefix and1024byte names with deferral disabled; predicate fallback for whitespace/mismatch/invalid forms; closing length above limit; UTF16 fallback. The fallback syntax loop only checks predicateNone, not final error/position; full differential gates remain needed.'},
'bounded_additional_probes_recommended':[
 'Add a small End-callback-specific matrix beyond existing1304 Start-publication controls: <r xmlns="u"><n xmlns="v"></n></r>, namespace on/off, chunk1/full, UTF8/UTF16 fallback, normal versus stop/resume with End-handler replacement. Capture End/EndNamespace order, DefaultCurrent/raw context/bytecount/linecolumn, final status and every resume.',
 'Reuse selected allocation failure driver with one explicit nonempty namespace-restoring end-tag fixture. Sweep only measured allocation sites; compare baseline/candidate callback/error/raw prefixes, terminal allocation-free repeated API calls and zero-live cleanup. This targets end-event enqueue and binding restore, not only empty-tag paths.',
 'Keep a bounded long-common-prefix mismatched closing-name control with deferral disabled, several feed widths and max-token boundary. The early closing-byte check gives a source complexity proof; compare statuses/positions and instruction/work behavior if this path becomes performance-relevant.',
 'Original strict/API/custom and retained external-child tests can provide broad fallback coverage without inventing new ceilings or modifying original assertions.'
],
'build_scope':{'fresh_workspace_compiles':3,'focused_and_core_clippy_recorded':'passed','compiler':build['rustc']},
'limits':['No native or CPython speed improvement is asserted by source review. No full public API, selected-allocation, sanitizer or callback-mutation pass is inferred from the two focused owner tests.','This source has70 manifest files including unchanged FFI README, beyond the prior69 runtime/source selection.'],
'evidence_sha256':H}
(O/'review.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'sha256':sha(O/'review.json')}))
