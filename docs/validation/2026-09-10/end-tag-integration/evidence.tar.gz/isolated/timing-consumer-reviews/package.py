from pathlib import Path
import gzip,hashlib,io,json,shutil,tarfile
out=Path('/tmp/oriole-matching-end-tags-timing-review-handoff');out.mkdir(exist_ok=False)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_bytes())
roots={n:Path('/tmp/oriole-matching-end-tags-'+n+'-independent-review') for n in ['native','python','cpython','build-comparison']}
entries=[]
for label,r in roots.items():
 for p in sorted(r.rglob('*')):
  if p.is_file():entries.append({'path':label+'/'+p.relative_to(r).as_posix(),'origin':str(p),'sha256':h(p),'bytes':p.stat().st_size})
with (out/'reviews.tar.gz').open('wb')as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as t:
   for row in entries:
    data=Path(row['origin']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];info=tarfile.TarInfo(row['path']);info.size=len(data);info.mode=0o644;t.addfile(info,io.BytesIO(data))
with tarfile.open(out/'reviews.tar.gz')as t:
 members=t.getmembers();assert len(members)==len(entries)
 for m,row in zip(members,entries,strict=True):assert m.isfile()and m.name==row['path'] and hashlib.sha256(t.extractfile(m).read()).hexdigest()==row['sha256'] and h(row['origin'])==row['sha256']
(out/'archive-members.json').write_text(json.dumps(entries,indent=2)+'\n')
summary={'status':'independent_reviews_passed','scope':'Saved matching-end fdea/33ec versus5af/303988 and pinnedExpat only. No parser/build or timing reruns. Combined integration is separate.','native':{'preflights':84,'timed_workers':588,'cohorts':196,'measured_samples':105420,'timed_warmups':588,'real_conditions':24,'candidate_over_published':0.9727826180483,'lower':19,'regressions':5,'candidate_over_expat':2.04130139103759,'generated_candidate_over_published':0.9823877031373203},'python':{'preflights':72,'timed_workers':504,'cohorts':168,'measured_samples':25788,'timed_warmups':504,'conditions':24,'candidate_over_published':0.9818882554520056,'lower':22,'candidate_over_expat':1.4477439177322087,'candidate_lower_than_expat':2},'strict_cpython':{'linkages':['shared','static'],'methods_each':802,'failures_each':2,'reported_skips_each':14,'expected_failures_each':3,'raw_exit_each':2,'same_all_method_statuses_as_baseline':True},'compiler':'All three workspace rustc argument vectors identical after private build path normalization; distinct target paths, Cargo build jobs2 vs1. No historical compiler-binary hash claim.','limitations':['Shared host and limited fixtures; every adverse condition retained.','Native timer includes parser create/setup/parse/callback/free; Python sums parsing and explicit destruction, GC enabled.','Native handle-based loading, Python explicit extension/library identities; strict fresh-import finder checked separately.','Original393 API failures and two CPython grouping failures remain; no broad faster-than-Expat or drop-in compatibility claim.'],'reviews':{label:{'path':str(r/'review.json'),'sha256':h(r/'review.json')}for label,r in roots.items()},'readback':{'archive_members':len(entries),'all_stored_and_origin_bytes_rehashed':True}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copyfile(__file__,out/'package.py')
files={p.name:{'sha256':h(p),'bytes':p.stat().st_size}for p in sorted(out.iterdir())if p.is_file()}
(out/'manifest.json').write_text(json.dumps({'status':'complete','files':files},indent=2)+'\n')
for n,row in files.items():assert h(out/n)==row['sha256']
print(json.dumps({'path':str(out),'manifest_sha256':h(out/'manifest.json'),'archive_sha256':h(out/'reviews.tar.gz'),'archive_members':len(entries),'archive_bytes':(out/'reviews.tar.gz').stat().st_size,'outer_files':len(files)+1}))
