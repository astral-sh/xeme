"""Read-only final human-document audit, without executing parsers or benchmarks."""
from pathlib import Path
import hashlib
import io
import json
import math
import re
import statistics
import subprocess
import tarfile
from urllib.parse import unquote, urlsplit

REPO = Path('/home/dev-user/code/oss/oriole-end-tag-integration')
OUT = Path(__file__).resolve().parent
DOC = REPO / 'docs/validation/2026-09-10/end-tag-integration'
BENCH = REPO / 'benchmarks/results/2026-09-10/end-tag-integration'
checks = []
observed = {}

def require(value, label):
    if not value:
        raise AssertionError(label)
    checks.append(label)

def read(path):
    path = Path(path)
    data = path.read_bytes()
    observed[str(path)] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return data

def load(path):
    return json.loads(read(path))

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def close(left, right, label):
    require(math.isclose(left, right, rel_tol=1e-14), label)

def main():
    paths = [REPO / 'README.md', REPO / 'benchmarks/README.md', REPO / 'docs/compatibility.md',
             REPO / 'docs/review.md', DOC / 'README.md', BENCH / 'README.md']
    docs = {str(p.relative_to(REPO)): read(p).decode() for p in paths}
    snapshot = OUT / 'documents'
    for p in paths:
        target = snapshot / p.relative_to(REPO)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(p.read_bytes())
    top = docs['README.md']
    before = git('show', '503a55957f7cdebcc0b3fb3ada2751ffdb8cb9c9:README.md').decode()
    require(re.findall(r'^#+ .*$', top, re.M) == re.findall(r'^#+ .*$', before, re.M), 'README heading sequence unchanged')
    require(top[:top.index('| Project XML |')] == before[:before.index('| Project XML |')], 'README warning/highlights/prefix byte-exact')
    require(top[top.index('## Installation'):] == before[before.index('## Installation'):], 'README installation through license byte-exact')
    for name in ['LICENSE-MIT', 'LICENSE-APACHE']:
        require(read(REPO / name) == git('show', '503a55957f7cdebcc0b3fb3ada2751ffdb8cb9c9:' + name), name + ' byte-exact')

    links = []
    for p in paths:
        text = docs[str(p.relative_to(REPO))]
        for match in re.finditer(r'\[[^\]\n]+\]\(([^)]+)\)', text):
            target = match.group(1).strip('<>')
            if urlsplit(target).scheme or target.startswith('#'):
                continue
            path = (p.parent / unquote(target.split('#')[0])).resolve()
            require(path.exists(), 'local link exists: ' + str(p.relative_to(REPO)) + ': ' + target)
            links.append({'document': str(p.relative_to(REPO)), 'target': target, 'resolved': str(path)})

    # Reconstruct the displayed six-row subset directly from already-audited saved samples.
    native = load('/tmp/oriole-end-tag-integration-timing-study/native-screen/results.json')
    labels = {'vulkan':'Vulkan registry','wayland':'Wayland protocol','maven':'Maven POM','batik':'Batik SVG','gtk':'GTK UI','docbook':'DocBook XSL'}
    table = []
    for name, label in labels.items():
        selected = [r for r in native['rows'] if r['condition']['name'] == name and r['condition']['chunk'] == 4096 and not r['condition']['namespaces']]
        require(len(selected) == 7, name + ' displayed subset seven paired cohorts')
        medians = {'candidate':[], 'expat':[]}
        ratios = []
        for row in selected:
            pair = {}
            for process in row['processes']:
                sample = json.loads(process['stdout'])['samples']
                values = [s['seconds'] for s in sample if not s['warmup']]
                median = statistics.median(values)
                close(median, process['median_seconds'], name + ' saved process median')
                pair[process['engine']] = median
                if process['engine'] in medians:
                    medians[process['engine']].append(median)
            ratios.append(pair['candidate'] / pair['expat'])
        a, b = [statistics.median(medians[k]) for k in ['candidate','expat']]
        ratio = statistics.median(ratios)
        line = f'| {label} | {a * 1000:.3f} ms | {b * 1000:.3f} ms | {ratio:.2f}× |'
        require(line in top and line in docs[str((BENCH / 'README.md').relative_to(REPO))], name + ' both displayed table rows exact')
        table.append({'project': name, 'candidate_seconds': a, 'expat_seconds': b, 'paired_ratio': ratio, 'rendered': line})

    handoff = load(DOC / 'independent-reviews/summary.json')
    ng = load(DOC / 'native-summary.json')
    pg = load(DOC / 'python-summary.json')
    for k, group in ng['groups'].items():
        require(group == handoff['native_groups'][k], 'native complete aggregate exact: ' + k)
    for k, group in pg['groups'].items():
        for ratio, values in group['ratios'].items():
            reference = handoff['python_groups'][k][ratio]
            require(values == {n: reference[n] for n in ['geomean','below_one']} and group['conditions'] == reference['conditions'], 'Python complete aggregate exact: ' + k + '/' + ratio)
    require(ng['regressions'] == pg['regressions'] == [], 'no combined per-condition regressions omitted')
    human = docs[str((DOC / 'README.md').relative_to(REPO))]
    rows = [
        ('Native project XML', ng['groups']['real']),
        ('Actual CPython consumers', pg['groups']['all']),
        ('ElementTree', pg['groups']['elementtree']),
        ('pyexpat callbacks', pg['groups']['pyexpat-events']),
        ('Native generated adverse fixtures', ng['groups']['generated']),
    ]
    for name, group in rows:
        a,b = [group['ratios'][k] for k in ['candidate_over_published','candidate_over_expat']]
        line = f"| {name} | {group['conditions']} | {a['geomean']:.3f}× | {b['geomean']:.3f}× | {a['below_one']} | {b['below_one']} |"
        require(line in human, 'human aggregate row exact: ' + name)
    reductions = [100*(1-g['ratios']['candidate_over_published']['geomean']) for g in [ng['groups']['real'],pg['groups']['all']]]
    require([f'{r:.1f}%' for r in reductions] == ['5.1%', '2.8%'], 'percentage reductions correctly rounded')
    for text in [top,human,docs[str((BENCH / 'README.md').relative_to(REPO))]]:
        require('5.1%' in text and '2.8%' in text, 'selected percentage claims present')
    require('overall native and CPython results remain slower than Expat' in human, 'no broad faster-than-Expat claim')

    # Human source / method / compatibility claims against frozen reviews and summaries.
    gates = load(DOC / 'gates.json')
    summary = load(DOC / 'summary.json')
    require(gates['workspace'] == {'tests':397, 'doc-tests':1}, '397 workspace tests and one separate doctest')
    require(gates['api']['passed'] == 4347 and gates['api']['failed'] == 393 and gates['api']['all4740rows_exact'], 'original API4347/393 retained')
    for needle in ['3-second per-configuration timeout', '768 MiB RSS bound and 240-second total timeout', 'exit remains 1', 'retain exit 2',
                   'BufferTextTest.test1', 'CDATAHandlerTest.test_handlers', 'Successful custom-alias raw traces are not individually retained',
                   'C sanitizers instrument the consumers', 'leak detection is disabled', 'Batik\'s external DTD',
                   'isolated', 'Isolated gains cannot be', 'SUSPENDED (33)']:
        require(' '.join(needle.lower().split()) in ' '.join(human.lower().split()), 'bounded compatibility/method statement: ' + needle)
    require('post-parse context snapshots are outside the header’s handler-scoped context contract.' in ' '.join(human.lower().split()), 'post-parse context outside-contract qualifier present')
    require('the 14 reported skips comprise five whole methods, eight subtests and one class setup.' in ' '.join(human.lower().split()), 'reported CPython skip classification present')
    for mode, r in handoff['strict_cpython'].items():
        require(r['methods'] == 802 and len(r['failures']) == 2 and r['reported_skips'] == 14 and r['expected_failures'] == 3, 'strict CPython counts: ' + mode)
        require(r['whole_method_skips']+r['subtest_skips']+r['class_setup_skips'] == 14, 'skip count classification: '+mode)
    for name in ['native-summary.json','python-summary.json']:
        require(read(BENCH / name) == read(DOC / name), 'benchmark summary copy: '+name)
    require('5bc806e' in top and 'these precede the latest parser changes' in top and 'earlier `4b11ace` runtime' in top, 'unchanged earlier fuzz/PBS source scopes explicit')
    require('no allocator, PGO or LTO setting change' in human and 'private intermediate' in human, 'compiler comparison wording preserves reviewed scope')
    for needle in ['84 preflights, 588 timed','105,420 measured parses plus 588 warmups','72\npreflights, 504 timed workers and 25,788 measured parses plus 504 warmups', '2026091003','202609104412']:
        require(needle in human, 'sample/protocol claim: '+needle)
    require(handoff['counts']['native']['timed_measured_samples'] == 105420 and handoff['counts']['python']['sample_counts']['time_measured'] == 25788, 'independent full sample totals')

    # Independently confirm the isolated instruction claim from every retained Callgrind header.
    profile = load('/tmp/oriole-matching-end-tags-study/profile/report.json')
    pre = load('/tmp/oriole-matching-end-tags-study/profile/preflights.json')
    require(len(profile['rows']) == len(pre) == 32, '32 isolated profiles and32 preflights')
    ir = {}
    for r in profile['rows']:
        path = next(a.split('=',1)[1] for a in r['command'] if a.startswith('--callgrind-out-file='))
        text = read(path).decode()
        require('positions: line' in text and 'events: Ir' in text, 'Callgrind expected format: '+Path(path).name)
        measured = int(re.search(r'^summary: (\d+)$', text, re.M).group(1))
        require(measured == r['Ir'], 'Callgrind XML_Parse Ir header: '+Path(path).name)
        require('--toggle-collect=XML_Parse' in r['command'] and '--collect-atstart=no' in r['command'], 'only XML_Parse toggled: '+Path(path).name)
        ir[(r['workload'],r['namespaces'],r['chunk'],r['library'])] = measured
    ratios = []
    for c in profile['comparisons']:
        key = (c['workload'],c['namespaces'],c['chunk'])
        value = ir[(*key,'candidate')]/ir[(*key,'control')]
        close(value,c['candidate_over_control'],'isolated instruction ratio: '+str(key))
        require(value < 1,'all isolated instruction conditions lower: '+str(key))
        if c['kind'] == 'project': ratios.append(value)
    require(len(ratios) == 12 and len(profile['comparisons']) == 16, '12 real plus4 generated instruction conditions')
    pgeo = statistics.geometric_mean(ratios)
    close(pgeo,profile['project_instruction_ratio_geomean'],'isolated profile geometric mean')
    require(f'{100*(1-pgeo):.2f}%' == '3.82%', 'isolated3.82% instruction claim rounded correctly')

    source = load(DOC / 'source.json')['source_sha256']
    require(len(source) == 70, '70 measured source files')
    commit = '503a55957f7cdebcc0b3fb3ada2751ffdb8cb9c9'
    archived = git('archive', commit, '--', *source)
    with tarfile.open(fileobj=io.BytesIO(archived)) as archive:
        for name,digest in source.items():
            require(hashlib.sha256(archive.extractfile(name).read()).hexdigest() == digest, 'Git503 source: '+name)
            require(hashlib.sha256(read(REPO / name)).hexdigest() == digest, 'live source: '+name)
    require(summary['runtime_commit'] == handoff['runtime_commit'] == commit, 'commit labels consistent')
    for name,digest in handoff['libraries'].items():
        require(digest in human, 'human exact runtime binary identity: '+name)
    require('3694b683' in human and '5af2406b' in human and '503a559' in human, 'combined versus isolated identities distinguished')

    # Recheck final current outer index after root's authorized18-entry refresh.
    index_bytes = read(DOC / 'files.json')
    index = json.loads(index_bytes)['files']
    require(len(index) == 18, '18 final indexed files before this documentation review is added')
    actual = {str(p.relative_to(DOC)) for p in DOC.rglob('*') if p.is_file() and p.name != 'files.json'}
    require(actual == {r['path'] for r in index}, 'outer index covers every current file')
    for r in index:
        data = read(DOC / r['path'])
        require(len(data) == r['bytes'] and hashlib.sha256(data).hexdigest() == r['sha256'], 'outer byte/hash: '+r['path'])
    require(read(DOC / 'files.json') == index_bytes, 'index unchanged during audit')
    package_review_path = Path('/tmp/oriole-end-tag-docs-package-independent-review/review.json')
    package_review = load(package_review_path) if package_review_path.exists() else None
    report = {
        'status':'human_document_audit_passed', 'scope':'Read-only human docs, numeric rows/aggregates, raw subset arithmetic, source/Git, local links and outer index. Existing independent full benchmark/gate audits remain authoritative; no parser/compiler/timing reruns.',
        'repo':str(REPO), 'runtime_commit':commit, 'source_files':len(source), 'checked_documents':list(docs),
        'top_readme_structure_warning_installation_license_unchanged':True, 'displayed_native_rows':table,
        'native_reduction_percent': reductions[0], 'python_reduction_percent':reductions[1], 'isolated_profile_geomean':pgeo,
        'final_outer_files':len(index), 'outer_index_sha256':hashlib.sha256(index_bytes).hexdigest(), 'local_links_checked':len(links),
        'audit_correction':'Initial text-presence checks treated a Markdown line wrap and capitalized sentence start as missing wording. Whitespace and case normalization corrected the reviewer checks; initial script/log retained. No source/docs/test changes resulted.',
        'resolved_clarifications':['Post-parse context snapshots explicitly outside handler-scoped contract.','14 reported CPython skips separated into5 whole methods,8 subtests,1 class setup.'],
        'findings':[], 'limitations':['Shared-host point estimates; candidate remains slower than Expat overall.','Original393 API failures and two strict CPython failures retained.','Successful custom-alias observations are summary-only; no full trace replay claimed.','Native benchmark origin uses explicit handle loading; Python identity checks are separate from strict fresh-import coverage.','No new sustained Rust ASan, PBS, PGO or full-project claims.'],
        'package_member_review':{'path':str(package_review_path),'available_at_generation':package_review is not None},
        'passed_checks':len(checks), 'observed_files':len(observed), 'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    (OUT/'links.json').write_text(json.dumps(links,indent=2)+'\n')
    (OUT/'checked-files.json').write_text(json.dumps(observed,indent=2,sort_keys=True)+'\n')
    (OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    (OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'checks':len(checks),'files':len(observed),'links':len(links)}))

if __name__ == '__main__':
    main()
