"""Read-only package/member/origin/index audit; never runs project helpers."""
from pathlib import Path, PurePosixPath
from collections import Counter
import ast
import hashlib
import io
import json
import os
import tarfile
import traceback

ROOT = Path('/home/dev-user/code/oss/oriole-end-tag-integration')
DOC = ROOT / 'docs/validation/2026-09-10/end-tag-integration'
OUT = Path(__file__).resolve().parent
PACKAGE = Path('/tmp/oriole-package-end-tag-integration.py')
RECEIPT = Path('/tmp/oriole-end-tag-integration-timing-review-handoff')
EXPECTED_ARCHIVE = 'bf518d52a5a1c5a2e47d209e1e2f1b33f5f2c1d257cc928300783668f322ecbb'
observed = {}
checks = 0
report = {'status': 'incomplete', 'scope': 'Saved-data package audit of archive bytes, member origins, excluded binaries, copied receipts, final observed outer index and 70 measured source bytes. No runtime, build, parser, benchmark or project-generator execution; no documentation edits.', 'cpu': 5}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    path = Path(path)
    raw = path.read_bytes()
    value = digest(raw)
    assert observed.setdefault(str(path), value) == value, ('changed during audit', path)
    return raw

def h(path):
    read(path)
    return observed[str(Path(path))]

def j(path):
    return json.loads(read(path))

def ck(ok, label):
    global checks
    assert ok, label
    checks += 1

def binary_kind(raw):
    return 'ELF' if raw.startswith(b'\x7fELF') else 'ar' if raw.startswith(b'!<arch>\n') else None

def safe_name(name):
    parts = PurePosixPath(name).parts
    return bool(parts) and not name.startswith('/') and '..' not in parts and name == PurePosixPath(name).as_posix()

def regular_archive(raw, entries, origin_field, keep=()):
    kept = {}
    kinds = Counter()
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        members = archive.getmembers()
        ck(len(members) == len(entries) == len({m.name for m in members}), 'archive complete unique members')
        for member, entry in zip(members, entries, strict=True):
            ck(member.isfile() and safe_name(member.name) and member.name == entry['path'] and member.size == entry['bytes'], ('regular member metadata', member.name))
            ck(member.mode == 0o644 and member.mtime == 0, ('normalized member mode/time', member.name))
            content = archive.extractfile(member).read()
            ck(digest(content) == entry['sha256'], ('stored member digest', member.name))
            origin = Path(entry[origin_field])
            ck(origin.is_file() and not origin.is_symlink(), ('regular member origin', origin))
            raw_origin = read(origin)
            ck(len(raw_origin) == entry['bytes'] and digest(raw_origin) == entry['sha256'], ('origin digest/size', member.name))
            ck(binary_kind(content) is None, ('member excluded-binary class absent', member.name))
            kinds['/'.join(member.name.split('/')[:2])] += 1
            if member.name in keep:
                kept[member.name] = content
    return kept, dict(sorted(kinds.items()))

try:
    ck(sorted(os.sched_getaffinity(0)) == [5], 'CPU 5')
    index_bytes = read(DOC / 'files.json')
    (OUT / 'final-index-observed.json').write_bytes(index_bytes)
    index = json.loads(index_bytes)
    initial = {'files': [dict(row) for row in index['files'] if not row['path'].startswith('independent-reviews/')]}
    for row in initial['files']:
        if row['path'] == 'README.md':
            row.update(bytes=8097, sha256='bc48b8dda29d528244222cf690bd162f8c0494b9127e5d8f741c3e5aee810d5c')
        if row['path'] == 'oriole-write-end-tag-integration-docs.py':
            row.update(bytes=12297, sha256='7552b79f7e177c1018cb101486260bff6323be99909e89be4567d1d0f3e7e501')
    ck(len(initial['files']) == 13, 'initial observed index shape')
    (OUT / 'initial-index-observed.json').write_text(json.dumps(initial, indent=2) + '\n')
    (OUT / 'index-refresh-notes.json').write_text(json.dumps({'initial_observation': 'Complete initial files.json tool read contained 13 entries; this JSON is reconstructed from that read, not a byte-captured pre-refresh file.', 'authorized_refresh': 'Parent reported final README wording fixes and copy of all five immutable independent-review handoff files, then refreshed files.json. The writer source copy changed with the same wording fixes.', 'refresh_is_not_a_mismatch': True}, indent=2) + '\n')
    ck(len(index['files']) == 18 and len({row['path'] for row in index['files']}) == 18, 'final observed18 index unique')
    actual_names = sorted(str(p.relative_to(DOC)) for p in DOC.rglob('*') if p.is_file() and p != DOC / 'files.json')
    ck([row['path'] for row in index['files']] == actual_names, 'index covers all current regular outer files except itself')
    for row in index['files']:
        ck(safe_name(row['path']), 'safe outer index path')
        path = DOC / row['path']
        ck(not path.is_symlink(), ('outer regular file', path))
        raw = read(path)
        ck(len(raw) == row['bytes'] and digest(raw) == row['sha256'], ('outer indexed size/hash', row['path']))

    tree = ast.parse(read(PACKAGE))
    constants = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in ['directories', 'controllers', 'copies']:
                    constants[target.id] = ast.literal_eval(node.value)
    ck(set(constants) == {'directories','controllers','copies'}, 'literal generator selection tables')
    ck(len(constants['directories']) == 13 and len(constants['controllers']) == 16 and len(constants['copies']) == 8, 'package input selection counts')
    selected = {}
    skipped = []
    for prefix, location in constants['directories'].items():
        base = Path(location)
        ck(base.is_dir(), ('input directory', location))
        for path in sorted(base.rglob('*')):
            if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts:
                name = prefix + '/' + str(path.relative_to(base))
                ck(name not in selected, ('unique selected path', name))
                selected[name] = path
            elif path.is_symlink() or '__pycache__' in path.parts:
                skipped.append(str(path))
    for location in constants['controllers']:
        name = 'controllers/' + Path(location).name
        ck(name not in selected, 'unique standalone controller')
        selected[name] = Path(location)
    members = j(DOC / 'archive-members.json')
    (OUT / 'archive-members-observed.json').write_bytes(read(DOC / 'archive-members.json'))
    included, excluded = members['members'], members['excluded_binaries']
    ck(len(included) == 5205 and len(excluded) == 34, '5205 members34 excluded')
    merged = included + excluded
    ck(len(merged) == len({row['path'] for row in merged}) == len(selected), 'selection partition complete')
    ck({row['path']: row['source'] for row in merged} == {name: str(path) for name,path in selected.items()}, 'generator selection exactly reproduced')
    ck([row['path'] for row in included] == sorted(row['path'] for row in included) and [row['path'] for row in excluded] == sorted(row['path'] for row in excluded), 'recorded sorted partitions')
    archive_bytes = read(DOC / 'evidence.tar.gz')
    ck(digest(archive_bytes) == EXPECTED_ARCHIVE, 'exact requested evidence archive identity')
    keep = {'integrated/source-build/source.json', 'integrated/source-build/source.tar.gz', 'integrated/source-build/build.json', 'isolated/source-build-profiles/source.json', 'isolated/source-build-profiles/source.tar.gz', 'isolated/source-build-profiles/build.json'}
    payloads, groups = regular_archive(archive_bytes, included, 'source', keep)
    ck(set(payloads) == keep, 'source/build snapshots present for both studies')
    excluded_counts = Counter()
    for row in excluded:
        path = Path(row['source'])
        raw = read(path)
        kind = binary_kind(raw)
        ck(kind is not None and len(raw) == row['bytes'] and digest(raw) == row['sha256'], ('excluded actual binary classification/hash', row['path']))
        excluded_counts[kind] += 1
    (OUT / 'excluded-binaries-verified.json').write_text(json.dumps(excluded, indent=2) + '\n')
    source_results = []
    for label, prefix, shared, static in [('integrated','integrated/source-build','dd16d23e4ab67938c195970bd845b2a159d7f062beda265bb673c85b79f73fc6','fbbef92d1c22b71850016a12e6c71c2ba1adcf20430e8934696d3dee07485a28'),('isolated','isolated/source-build-profiles','fdea997de0cd52c743a5c0f9c381c684cacdaf991770f437d57df05f0071980a','33ec4171201a0735d6d0dd57ded68b3cf21b11477a24c57e21004686480771be')]:
        source = json.loads(payloads[prefix + '/source.json'])
        build = json.loads(payloads[prefix + '/build.json'])
        ck(len(source['source_sha256']) == 70, (label, 'source70 manifest'))
        ck(digest(payloads[prefix + '/source.json']) == build['source_manifest_sha256'], (label, 'source build linkage'))
        ck(build['status'] == 'passed' and build['source_unchanged'] and build['libraries'] == {'liboriole_expat.so':shared,'liboriole_expat.a':static}, (label, 'build passed exact library identities'))
        with tarfile.open(fileobj=io.BytesIO(payloads[prefix + '/source.tar.gz']),mode='r:gz') as archive:
            nested = archive.getmembers()
            ck(len(nested) == len({m.name for m in nested}) == 70 and all(m.isfile() and safe_name(m.name) for m in nested), (label, 'nested source archive70 regular'))
            ck({m.name:digest(archive.extractfile(m).read()) for m in nested} == source['source_sha256'], (label, 'nested source bytes'))
        for name,value in source['source_sha256'].items():
            ck(h(Path(source['worktree']) / name) == value, (label, 'live source',name))
        source_results.append({'study':label,'source_files':70,'source_manifest_sha256':digest(payloads[prefix + '/source.json']),'all_live_and_nested_archive_bytes_match':True,'libraries':build['libraries']})

    copy_rows = []
    for name, origin in constants['copies'].items():
        ck(read(DOC/name) == read(origin), ('exact standalone copied receipt',name))
        copy_rows.append({'path':name,'origin':origin,'sha256':h(DOC/name),'same_digest_archive_members':[row['path'] for row in included if row['sha256'] == h(DOC/name)]})
    summary = j(DOC/'summary.json')
    source = j(DOC/'source.json')
    gates = j(DOC/'gates.json')
    assembly = j(DOC/'assembly.json')
    ck(summary['source_files'] == assembly['source_files'] == 70 and summary['source_manifest_sha256'] == assembly['source_manifest_sha256'] == h(DOC/'source.json'), 'outer source identities')
    ck(summary['runtime_commit'] == assembly['runtime_commit'] == '503a55957f7cdebcc0b3fb3ada2751ffdb8cb9c9', 'recorded runtime commit linkage')
    ck(summary['libraries'] == source_results[0]['libraries'], 'outer build library identities')
    ck(gates['status'] == 'correctness_parity_gates_passed' and gates['workspace'] == {'tests':397,'doc-tests':1}, 'gates and workspace copied receipt status')
    ck(gates['api']['all4740rows_exact'] and gates['api']['passed'] == 4347 and gates['api']['failed'] == 393, 'canonical API copied receipt scope')
    ck(summary['native'] == j(DOC/'native-summary.json') and summary['python'] == j(DOC/'python-summary.json'), 'outer native and Python summaries copied exactly')
    ck(summary['archive'] == {'sha256':EXPECTED_ARCHIVE,'members':5205,'excluded_binaries':34,'raw_bytes':sum(row['bytes'] for row in included),'bytes':len(archive_bytes),'all_members_and_origins_readback_verified':True}, 'archive summary reconstructed')
    for name in ['native-summary.json','python-summary.json']:
        ck(read(ROOT/'benchmarks/results/2026-09-10/end-tag-integration'/name) == read(DOC/name), ('benchmark summary copy',name))

    receipt_paths = [row['path'].removeprefix('independent-reviews/') for row in index['files'] if row['path'].startswith('independent-reviews/')]
    ck(sorted(receipt_paths) == sorted(p.name for p in RECEIPT.iterdir() if p.is_file()) and len(receipt_paths) == 5, 'all five receipt handoff files copied')
    for name in receipt_paths:
        ck(read(DOC/'independent-reviews'/name) == read(RECEIPT/name), ('latest independent receipt exact copy',name))
    receipt_manifest = j(RECEIPT/'manifest.json')
    ck(receipt_manifest['status'] == 'complete' and set(receipt_manifest['files']) == set(receipt_paths)-{'manifest.json'}, 'receipt manifest complete')
    for name,row in receipt_manifest['files'].items():
        ck(h(RECEIPT/name) == row['sha256'] and len(read(RECEIPT/name)) == row['bytes'], ('receipt manifest hash/size',name))
    receipt_members = j(RECEIPT/'archive-members.json')
    _, receipt_groups = regular_archive(read(RECEIPT/'reviews.tar.gz'), receipt_members, 'origin')
    receipt_summary = j(RECEIPT/'summary.json')
    ck(receipt_summary['status'] == 'independent_reviews_passed' and receipt_summary['readback']['members'] == len(receipt_members) == 22, '22 independent receipt archive members')
    for name,row in receipt_summary['reviews'].items():
        ck(h(row['path']) == row['sha256'], ('receipt source review identity',name))
    ck(receipt_summary['libraries'] == summary['libraries'] and receipt_summary['source_files'] == 70 and receipt_summary['runtime_commit'] == summary['runtime_commit'], 'latest receipt source/runtime linkage')

    end_index = (DOC/'files.json').read_bytes()
    (OUT/'final-index-after.json').write_bytes(end_index)
    ck(end_index == index_bytes, 'final observed index stable during full audit')
    ck(all(digest(Path(path).read_bytes()) == value for path,value in observed.items()), 'all inspected origins and outer files unchanged during full audit')
    report.update(status='independent_docs_package_audit_passed', archive={'sha256':EXPECTED_ARCHIVE,'members':5205,'raw_bytes':sum(row['bytes'] for row in included),'compressed_bytes':len(archive_bytes),'member_origins_all_rehashed':True,'selection_reconstructed':True,'groups':groups}, excluded_binaries={'count':34,'formats':dict(excluded_counts),'all_hashed_and_absent_as_outer_archive_members':True}, generator_selection={'directories':13,'standalone_controllers':16,'selected_files':len(selected),'skipped_symlink_or_cache_paths':skipped}, source_studies=source_results, standalone_copies=copy_rows, outer_index={'entries':18,'sha256':digest(index_bytes),'exact_coverage_and_hashes':True,'stable_during_audit':True,'previous_observation_entries':13,'authorized_refresh_preserved_separately':True}, independent_outer_receipt={'files':5,'archive_members':22,'manifest_sha256':h(RECEIPT/'manifest.json'),'archive_sha256':h(RECEIPT/'reviews.tar.gz'),'all_copies_members_and_origins_match':True,'groups':receipt_groups}, limitations=['Archive classification excludes direct members starting with ELF or ar magic; it is not a general binary-content policy or scan of every possible embedded representation. The two nested source archives were separately checked as 70 regular source members each.', 'Member/origin equivalence proves retained byte identity now, not independent re-execution or new validation of each historical gate result.', 'Copied native/Python summaries retain their existing study scopes. This audit does not recompute performance or review human wording/links; parent owns that review.', 'Git commit assembly is checked through copied pinned receipts and 70 live/archive source bytes here; this audit does not rerun the separate Git assembly audit.', 'The outer index excludes itself. The initial 13-entry observation was superseded by an authorized documentation/receipt refresh; final 18-entry index is the validated snapshot. Future outer receipts require an updated index and separate review.'], checked_file_count=len(observed), checks=checks, generator_sha256=digest(Path(__file__).read_bytes()))
    (OUT/'checked-files.json').write_text(json.dumps(observed,indent=2,sort_keys=True)+'\n')
    report['checked_files_sha256'] = digest((OUT/'checked-files.json').read_bytes())
except BaseException:
    report['status'] = 'failed'
    report['error'] = traceback.format_exc()
finally:
    (OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'review_sha256':digest((OUT/'review.json').read_bytes()),'checks':report.get('checks'),'files':report.get('checked_file_count'),'error':report.get('error')},indent=2))
raise SystemExit(0 if report['status'] == 'independent_docs_package_audit_passed' else 1)
