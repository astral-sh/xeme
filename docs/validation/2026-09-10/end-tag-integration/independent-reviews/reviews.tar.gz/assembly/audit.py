"""Read committed source trees and saved build records; no builds or parser runs."""
from pathlib import Path
import hashlib,io,json,subprocess,tarfile
if not __debug__:raise RuntimeError('Assertions required')
out=Path(__file__).parent;r=Path('/tmp/oriole-end-tag-integration-study');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_bytes())
s=load(r/'source.json');a=load('/tmp/oriole-end-tag-integration-assembly.json');b=load('/tmp/oriole-scanner-integration-study/source.json');w=Path(s['worktree']);files=s['source_sha256'];assert len(files)==70 and set(files)==set(b['source_sha256'])
def git(args):return subprocess.check_output(['git','-C',str(w),*args])
def tree(revision):
 raw=git(['archive',revision,*files])
 with tarfile.open(fileobj=io.BytesIO(raw))as t:return {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest()for m in t if m.isfile()}
assert a['runtime_commit']=='503a55957f7cdebcc0b3fb3ada2751ffdb8cb9c9'
assert git(['rev-parse',a['runtime_commit']+'^']).decode().strip()==a['parent']=='71bf6bc2aabc9e57d0be914919ca6ed2e600c4eb'
assert a['frozen_build_base']==s['base']=='64a270e58f14a4b74e25ffcf25f7832a5216b2d1'
assert tree(a['frozen_build_base'])==tree(a['parent'])==b['source_sha256']
assert tree(a['runtime_commit'])==files=={name:h(w/name)for name in files}
assert a['source_manifest_sha256']==h(r/'source.json')
docpaths=git(['diff','--name-only',a['frozen_build_base'],a['parent']]).decode().splitlines();assert not(set(docpaths)&set(files))
changed=git(['diff','--name-only',a['parent'],a['runtime_commit']]).decode().splitlines();assert changed==['crates/oriole/src/lib.rs']
review=load('/tmp/oriole-end-tag-integration-independent-review/review.json');assert review['status']=='composition_source_and_fresh_build_review_passed'and review['source_manifest_sha256']==h(r/'source.json')
build=load(r/'build.json');assert build['status']=='passed'and build['source_manifest_sha256']==h(r/'source.json')
for name,value in build['libraries'].items():assert h(r/name)==value
with tarfile.open(r/'source.tar.gz')as t:archived={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest()for m in t if m.isfile()}
assert archived==files
result={'status':'commit_source_assembly_verified','scope':'Read-only Git archive, frozen/live source and saved build identity checks. No builds or parser calls.','runtime_commit':a['runtime_commit'],'parent':a['parent'],'frozen_build_base':s['base'],'source_files':70,'source_manifest_sha256':h(r/'source.json'),'all_git_live_archive_bytes_match_measured_source':True,'parent_advance_files':docpaths,'parent_advance_touches_measured_sources':False,'runtime_commit_changed_files':changed,'libraries':build['libraries'],'source_build_review_sha256':h('/tmp/oriole-end-tag-integration-independent-review/review.json'),'compiler_scope':'Existing composition review reconstructs exact isolated patch and verifies three fresh workspace rustc invocations with all arguments equal to3694 after only private build directory normalization. No new historical compiler binary hash claim.','findings':[],'evidence_sha256':{str(p):h(p)for p in [r/'source.json',r/'source.tar.gz',r/'build.json',r/'release.log',r/'compiler-invocations.json',Path('/tmp/oriole-end-tag-integration-assembly.json'),Path('/tmp/oriole-end-tag-integration-independent-review/review.json'),Path('/tmp/oriole-scanner-integration-study/source.json')]}}
(out/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(h(out/'review.json'))
