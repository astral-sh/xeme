"""Exact composition/source/build review; no compiler or parser execution."""
from pathlib import Path
import hashlib,json,re,shlex,subprocess,tarfile,tempfile
r=Path('/tmp/oriole-end-tag-integration-study');base=Path('/tmp/oriole-scanner-integration-study');isolated=Path('/tmp/oriole-matching-end-tags-study');out=Path(__file__).parent
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_bytes())
s=load(r/'source.json');b=load(base/'source.json');components=load('/tmp/oriole-end-tag-integration-components.json')
assert len(s['source_sha256'])==len(b['source_sha256'])==70
assert set(s['source_sha256'])==set(b['source_sha256']);changes=[n for n in s['source_sha256']if s['source_sha256'][n]!=b['source_sha256'][n]];assert changes==['crates/oriole/src/lib.rs']
assert components['patch_sha256']==h(isolated/'candidate.patch')=='5c0248f9fccfc1ff6d67fe672f9c9a0d4d1ee33d423a87ff3dde2259f14eeef7'
with tarfile.open(base/'source.tar.gz')as t:basefiles={m.name:t.extractfile(m).read() for m in t if m.isfile()}
assert {n:hashlib.sha256(v).hexdigest()for n,v in basefiles.items()}==b['source_sha256']
with tempfile.TemporaryDirectory(dir=out)as temp:
 path=Path(temp)/changes[0];path.parent.mkdir(parents=True);path.write_bytes(basefiles[changes[0]])
 result=subprocess.run(['git','apply',str(isolated/'candidate.patch')],cwd=temp,capture_output=True)
 assert result.returncode==0,(result.stdout,result.stderr)
 assert h(path)==s['source_sha256'][changes[0]]
for directory in [r,base]:
 source=load(directory/'source.json')
 with tarfile.open(directory/'source.tar.gz')as t:files={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest()for m in t if m.isfile()}
 assert files==source['source_sha256']
 for n,value in files.items():assert h(Path(source['worktree'])/n)==value
 build=load(directory/'build.json');assert build['status']=='passed' and build['source_manifest_sha256']==h(directory/'source.json')
 for n,value in build['libraries'].items():assert h(directory/n)==value
# Actual fresh workspace compiler invocations and normalized mode match.
normalized={};commands={}
for label,directory in [('base',base),('combined',r)]:
 inv=load(directory/'compiler-invocations.json');log=(directory/'release.log').read_text();assert inv==[x for x in log.splitlines()if 'Running' in x and '/rustc 'in x]
 commands[label]={};normalized[label]={}
 for name in ['oriole_storage','oriole','oriole_expat']:
  rows=[x for x in inv if '--crate-name '+name+' 'in x];assert len(rows)==1
  items=shlex.split(rows[0].strip()[len('Running `'):-1]);ri=next(i for i,x in enumerate(items)if x.endswith('/bin/rustc'));env=dict(x.split('=',1)for x in items[:ri]);args=items[ri:]
  assert env['CARGO_MANIFEST_DIR']==str(Path(load(directory/'source.json')['worktree'])/'crates'/name)
  assert any(x.startswith('--emit=dep-info')and 'link'in x for x in args)
  commands[label][name]=args;normalized[label][name]=[re.sub(r'/home/dev-user/.cache/ohm/verified-build/[^/]+/[^/]+','<BUILD>',x)for x in args]
assert normalized['base']==normalized['combined']
build=load(r/'build.json')
for row in build['commands']:assert row['exit']==0 and h(r/(row['name']+'.log'))==row['log_sha256']
result={'status':'composition_source_and_fresh_build_review_passed','scope':'No compiler/parser executions. Applied the already-reviewed isolated diff only in temporary reviewer files to reconstruct the exact combined lib.rs.','source_files':70,'source_manifest_sha256':h(r/'source.json'),'base':s['base'],'changed_files':changes,'input_patch_sha256':components['patch_sha256'],'candidate_libraries':build['libraries'],'fresh_workspace_compiles':3,'normalized_rustc_arguments_equal_base':True,'normalized_commands':normalized['combined'],'findings':[],'invariants':['Exact original end-tag helper/scanner bypass/owned-token publication change applies without alteration; all other69 files match64a integration.','Existing text selector and short-position implementation remain byte exact except original end-tag hunks; String hints have no layout/ownership changes.','All previous native/unconverted/single-source/name/limit guards and checked expected-closing-byte-before-equality proof remain valid; no new borrowed callback state.','Reparse deferral, account_source,token append/current raw swap,consume,namespace restoration and end event publication remain the original reviewed sequence.'],'limitations':['Original source review is reused for the identical end-tag patch; new composed correctness gates remain separately required.','Matched rustc command paths/flags and distinct private intermediates verified; no independent historical compiler executable hash assertion.'],'evidence_sha256':{str(p):h(p)for p in [r/'source.json',r/'source.tar.gz',r/'candidate.patch',r/'build.json',r/'release.log',r/'compiler-invocations.json',base/'source.json',base/'build.json',base/'release.log',base/'compiler-invocations.json',isolated/'candidate.patch',Path('/tmp/oriole-end-tag-integration-components.json'),Path('/tmp/oriole-matching-end-tags-independent-review/review.json')]}}
(out/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(h(out/'review.json'))
