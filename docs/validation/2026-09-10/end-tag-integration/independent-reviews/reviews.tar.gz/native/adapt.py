"""Prepare saved native audit only; await parent release before executing audit.py."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os

assert sorted(os.sched_getaffinity(0)) == [6]
root = Path(__file__).resolve().parent
original_path = Path('/tmp/oriole-matching-end-tags-native-independent-review/audit.py')
h = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert h(original_path) == '2f06b253f69e0941e2c843ea5865b62a5c1f543addcab841f11bacc90cdf3c1c'
original = original_path.read_text()
adapted = original.replace("R=Path('/tmp/oriole-matching-end-tags-timing-study')", "R=Path('/tmp/oriole-end-tag-integration-timing-study')")
adapted = adapted.replace('os.sched_getaffinity(0))==[5]', 'os.sched_getaffinity(0))==[6]').replace("'audit_cpu':5", "'audit_cpu':6")
adapted = adapted.replace('5af2406b17092dad35aa61c086cdfe39e24f51e653441fd9baf50cd12da3b2fe', '3694b68326939778481e42e810f53facc2ebcb8b8ad75b599704dbfef8f37926')
adapted = adapted.replace('fdea997de0cd52c743a5c0f9c381c684cacdaf991770f437d57df05f0071980a', 'dd16d23e4ab67938c195970bd845b2a159d7f062beda265bb673c85b79f73fc6')
adapted = adapted.replace('/tmp/oriole-time-matching-end-native.py', '/tmp/oriole-time-end-tag-integration-native.py')
start = adapted.index("old_path=Path('/tmp/oriole-coalesced-search-timing-study/native_screen.py')")
end = adapted.index("manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')", start)
block = '''old_path=Path('/tmp/oriole-scanner-integration-timing-study/native_screen.py')
old=read(old_path).decode()
adapted=old.replace('/tmp/oriole-scanner-integration-timing-study',str(R)).replace('/tmp/oriole-scanner-integration-study/liboriole_expat.so',protocol['libraries']['candidate']['path']).replace('/tmp/oriole-coalesced-search-study/liboriole_expat.so',protocol['libraries']['published']['path']).replace('published193e1278/50580931','published64a270e/3694b683').replace('integrated position words and String inline hints','integrated matching native end tags').replace('integrated position words and String hints/3694b683 candidate','integrated matching end tags/dd16d23e candidate')
ck('frozen timing controller only declared path/label edits',adapted==read(R/'native_screen.py').decode())
patch=''.join(difflib.unified_diff(old.splitlines(True),adapted.splitlines(True),fromfile='reviewed-coalesced-native',tofile='integrated-scanner-native'))
ck('retained controller patch exact',patch==read(R/'controller.patch').decode())
read(R/'oriole-prepare-end-tag-integration-timing.py')

candidate_root=Path('/tmp/oriole-end-tag-integration-study')
candidate_source=j(candidate_root/'source.json');candidate_build=j(candidate_root/'build.json')
baseline_root=Path('/tmp/oriole-scanner-integration-study')
baseline_source=j(baseline_root/'source.json');baseline_build=j(baseline_root/'build.json')
composition_review=Path('/tmp/oriole-end-tag-integration-independent-review/review.json')
ck('composition source review exact identity',h(composition_review)=='bc426dd2a2a1454d6f3d1ec55100bde4c2ac04b4ba98b93a02e715ead7b51b2f' and j(composition_review)['status']=='composition_source_and_fresh_build_review_passed')
ck('candidate70 source manifest identity',preparation['source_files']==70 and len(candidate_source['source_sha256'])==70 and h(candidate_root/'source.json')==preparation['source_manifest_sha256']==candidate_build['source_manifest_sha256'])
ck('direct control70 source manifest identity',len(baseline_source['source_sha256'])==70 and h(baseline_root/'source.json')==baseline_build['source_manifest_sha256'])
for label,root,source in [('candidate',candidate_root,candidate_source),('baseline',baseline_root,baseline_source)]:
    ck(label+'70 live source bytes exact',all(h(Path(source['worktree'])/name)==value for name,value in source['source_sha256'].items()))
    with tarfile.open(fileobj=io.BytesIO(read(root/'source.tar.gz')),mode='r:gz') as archive:
        members=archive.getmembers()
        ck(label+' archived source membership',len(members)==len(source['source_sha256'])==len({m.name for m in members}) and all(m.isfile() for m in members))
        ck(label+' archived source bytes exact',{m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in members}==source['source_sha256'])
ck('candidate/base source comparison retains one runtime change',set(candidate_source['source_sha256'])==set(baseline_source['source_sha256']) and [name for name,value in baseline_source['source_sha256'].items() if candidate_source['source_sha256'][name]!=value]==['crates/oriole/src/lib.rs'])
ck('candidate build library identity',candidate_build['status']=='passed' and candidate_build['source_unchanged'] and candidate_build['libraries']['liboriole_expat.so']==expected_hashes['candidate'])
ck('direct control build library identity',baseline_build['status']=='passed' and baseline_build['source_unchanged'] and baseline_build['libraries']['liboriole_expat.so']==expected_hashes['published'])
ck('candidate static library identity',h(candidate_root/'liboriole_expat.a')==candidate_build['libraries']['liboriole_expat.a']=='fbbef92d1c22b71850016a12e6c71c2ba1adcf20430e8934696d3dee07485a28')

'''
adapted = adapted[:start] + block + adapted[end:]
adapted = adapted.replace("ck('all five regressions retained',published['regressions']==regressions and len(regressions)==5 and all(not row['condition']['name'].startswith('generated-') for row in regressions))", "ck('all real or generated regressions retained',published['regressions']==regressions)")
adapted = adapted.replace("ck('real nineteen improvements and expected point estimate',groups['real']['ratios']['candidate_over_published']=={'geomean':0.9727826180483,'below_one':19})", "ck('real24 improvements and reported point estimate',groups['real']['ratios']['candidate_over_published']=={'geomean':0.9494346726453999,'below_one':24})")
adapted = adapted.replace("ck('all generated improve and every candidate/Expat condition slower',groups['generated']['ratios']['candidate_over_published']['below_one']==4 and all(row['median_ratios']['candidate_over_expat']>1 for row in computed))", "ck('all four generated conditions and every candidate/Expat ratio retained',groups['generated']['conditions']==4 and all(math.isfinite(row['median_ratios']['candidate_over_expat']) and row['median_ratios']['candidate_over_expat']>0 for row in computed))")
adapted = adapted.replace("'baseline_archived_source_files':len(baseline_source['source_sha256'])", "'baseline_archived_source_files':len(baseline_source['source_sha256']),'baseline_live_source_files_verified':70,'composition_review_sha256':h(composition_review),'comparison_baseline':'Direct integration parent 64a270e / 3694b683; separate from the standalone matching-end study against 5af2406b'")
adapted = adapted.replace("'Five real-condition regressions remain: four Batik conditions and DocBook64KiB with namespaces. All four generated controls improve versus baseline; every candidate condition remains slower than Expat.'", "f\"Retained all {len(regressions)} candidate/control regressions, all four generated conditions and all candidate/Expat ratios. Real improvements: {groups['real']['ratios']['candidate_over_published']['below_one']}/24; generated improvements: {groups['generated']['ratios']['candidate_over_published']['below_one']}/4.\"")
ast.parse(adapted)
assert not (root / 'audit.py').exists()
(root / 'original-audit.py').write_text(original)
(root / 'audit.py').write_text(adapted)
(root / 'audit.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),adapted.splitlines(True),fromfile=str(original_path),tofile=str(root/'audit.py'))))
preparation = {'status': 'prepared_not_executed_waiting_for_parent_release', 'scope': 'Adapted saved native audit. No target code imported or executed; no parser/build/timing reruns. Existing standalone and correctness-gate handoffs untouched.', 'cpu': 6, 'planned_command': ['taskset','-c','6','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S',str(root/'audit.py')], 'original_generator':str(original_path),'original_generator_sha256':h(original_path),'adapted_generator_sha256':h(root/'audit.py'),'patch_sha256':h(root/'audit.patch'),'adaptation_generator_sha256':h(__file__)}
(root / 'preparation.json').write_text(json.dumps(preparation,indent=2)+'\n')
print(json.dumps(preparation,indent=2))
