"""Independent saved native timing audit; no project code or parser execution."""
from pathlib import Path
from collections import Counter
import difflib
import hashlib
import io
import json
import math
import os
import random
import statistics
import sys
import tarfile

R=Path('/tmp/oriole-end-tag-integration-timing-study')
S=R/'native-screen'
O=Path(__file__).resolve().parent
assert sorted(os.sched_getaffinity(0))==[6]
tracked={};checks=[]
def read(path):
    path=Path(path);raw=path.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(path),value)==value,str(path)
    return raw
def h(path):read(path);return tracked[str(path)]
def j(path):return json.loads(read(path))
def ck(name,condition):
    checks.append({'name':name,'passed':bool(condition)})
    assert condition,name
key=lambda value:json.dumps(value,sort_keys=True)
engines=['published','candidate','expat']
ratio_names=['candidate_over_published','candidate_over_expat','published_over_expat']
expected_hashes={
 'published':'3694b68326939778481e42e810f53facc2ebcb8b8ad75b599704dbfef8f37926',
 'candidate':'dd16d23e4ab67938c195970bd845b2a159d7f062beda265bb673c85b79f73fc6',
 'expat':'7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478',
}
protocol=j(S/'protocol.json');pre=j(S/'preflight.json');results=j(S/'results.json')
ck('protocol full design',protocol['pairs']==7 and protocol['seed']==2026091003 and protocol['preflights']==84 and protocol['timed_workers']==588)
ck('completed phase records',pre['status']==results['status']=='passed' and results['affinity']==[0])
ck('phase linkage',pre['protocol_sha256']==results['protocol_sha256']==h(S/'protocol.json') and results['preflight_sha256']==h(S/'preflight.json'))
for label,report in [('preflight',pre),('timing',results)]:
    ck(label+' before/after hashes exact',report['hashes_before']==report['hashes_after']==protocol['hashes'])
ck('all protocol file hashes current',all(h(path)==value for path,value in protocol['hashes'].items()))
for engine in engines:
    entry=protocol['libraries'][engine]
    ck('pinned library '+engine,h(entry['path'])==entry['sha256']==expected_hashes[engine])

preparation=j(R/'preparation.json');controller=j(R/'timing-controller.json')
ck('preflight controller passed original CPU3',preparation['status']=='passed' and preparation['exit']==0 and preparation['command']==['taskset','-c','3','python3',str(R/'native_screen.py'),'preflight'])
timing_controller=Path('/tmp/oriole-time-end-tag-integration-native.py')
ck('timing controller passed recorded CPU0 and code hash',controller['status']=='passed' and controller['exit']==0 and not controller.get('timeout') and controller['controller_sha256']==h(timing_controller) and controller['command']==['taskset','-c','0','python3',str(R/'native_screen.py'),'time'])
ck('timing controller completion below outer bound',0<controller['elapsed_seconds']<1200)
old_path=Path('/tmp/oriole-scanner-integration-timing-study/native_screen.py')
old=read(old_path).decode()
adapted=old.replace('/tmp/oriole-scanner-integration-timing-study',str(R)).replace('/tmp/oriole-scanner-integration-study/liboriole_expat.so',protocol['libraries']['candidate']['path']).replace('/tmp/oriole-coalesced-search-study/liboriole_expat.so',protocol['libraries']['published']['path']).replace('published193e1278/50580931','published64a270e/3694b683').replace('integrated position words and String inline hints','integrated matching native end tags').replace('integrated position words and String hints/3694b683 candidate','integrated matching end tags/dd16d23e candidate')
ck('frozen timing controller only declared path/label edits',adapted==read(R/'native_screen.py').decode())
patch=''.join(difflib.unified_diff(old.splitlines(True),adapted.splitlines(True),fromfile='reviewed-coalesced-native',tofile='integrated-scanner-native'))
ck('retained controller patch exact',patch==read(R/'controller.patch').decode())
read(R/'oriole-prepare-end-tag-integration-timing.py')

candidate_root=Path('/tmp/oriole-end-tag-integration-study')
candidate_source=j(candidate_root/'source.json');candidate_build=j(candidate_root/'build.json')
baseline_root=Path('/tmp/oriole-scanner-integration-study')
baseline_source=j(baseline_root/'source.json');baseline_build=j(baseline_root/'build.json')
composition_review=Path('/tmp/oriole-end-tag-integration-independent-review/review.json')
ck('composition source review exact identity',h(composition_review)=='bc426dd2a2a1454d6f3d1ec55100bde4c2ac04b4ba98b93a02e715ead7b51b2f' and j(composition_review)['status']=='composition_source_and_fresh_build_review_passed')
ck('candidate70 source manifest identity',preparation['source_files']==70 and len(candidate_source['source_sha256'])==70 and h(candidate_root/'source.json')==preparation['source_manifest_sha256']==candidate_build['source_manifest_sha256'])
ck('direct control70 source manifest identity',len(baseline_source['source_sha256'])==70 and h(baseline_root/'source.json')==baseline_build['source_manifest_sha256'])
for label,root,source in [('candidate',candidate_root,candidate_source),('baseline',baseline_root,baseline_source)]:
    ck(label+'70 live source bytes exact',all(h(Path(source['worktree'])/name)==value for name,value in source['source_sha256'].items()))
    with tarfile.open(fileobj=io.BytesIO(read(root/'source.tar.gz')),mode='r:gz') as archive:
        members=archive.getmembers()
        ck(label+' archived source membership',len(members)==len(source['source_sha256'])==len({m.name for m in members}) and all(m.isfile() for m in members))
        ck(label+' archived source bytes exact',{m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in members}==source['source_sha256'])
ck('candidate/base source comparison retains one runtime change',set(candidate_source['source_sha256'])==set(baseline_source['source_sha256']) and [name for name,value in baseline_source['source_sha256'].items() if candidate_source['source_sha256'][name]!=value]==['crates/oriole/src/lib.rs'])
ck('candidate build library identity',candidate_build['status']=='passed' and candidate_build['source_unchanged'] and candidate_build['libraries']['liboriole_expat.so']==expected_hashes['candidate'])
ck('direct control build library identity',baseline_build['status']=='passed' and baseline_build['source_unchanged'] and baseline_build['libraries']['liboriole_expat.so']==expected_hashes['published'])
ck('candidate static library identity',h(candidate_root/'liboriole_expat.a')==candidate_build['libraries']['liboriole_expat.a']=='fbbef92d1c22b71850016a12e6c71c2ba1adcf20430e8934696d3dee07485a28')

manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
manifest=j(manifest_path)
fixtures={};fixture_rows=[]
for project in manifest['projects']:
    entry=next(row for row in project['files'] if row['role']=='input')
    path=(manifest_path.parent/entry['path']).resolve()
    ck('original project bytes '+project['name'],h(path)==entry['sha256'])
    fixtures[project['name']]=str(path)
    fixture_rows.append({'name':project['name'],'input':str(path),'sha256':h(path),'bytes':len(read(path))})
ck('six real project names',set(fixtures)=={'vulkan','wayland','maven','batik','gtk','docbook'})
fixtures['generated-rare-declarations']='/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml'
fixtures['generated-entities']='/tmp/oriole-grammar-bench-plain/entities.xml'
fixed={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
conditions=[{'name':name,'input':path,'chunk':chunk,'namespaces':ns,'iterations':fixed[name]} for chunk in [4096,65536] for name,path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False,True])]
ck('all28 conditions exactly reconstructed',protocol['conditions']==conditions and len({key(c) for c in conditions})==28)
ck('24real and4generated conditions',sum(not c['name'].startswith('generated-') for c in conditions)==24)

driver=Path('/tmp/oriole-grammar-bench-plain/native-driver')
driver_source=Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')
origin_path=Path('/tmp/oriole-grammar-bench-plain/summary.json');origin=j(origin_path)
ck('retained native driver original build identities',origin['status']=='passed' and origin['sha256_before'][str(driver)]==origin['sha256_after'][str(driver)]==h(driver) and origin['sha256_before'][str(driver_source)]==origin['sha256_after'][str(driver_source)]==h(driver_source))
driver_code=read(driver_source).decode()
ck('native driver explicit handle resolution','dlopen(argv[1], RTLD_NOW | RTLD_LOCAL)' in driver_code and 'dlsym(library, symbol)' in driver_code)
ck('timer encompasses construct/setup/parse/free after loading',driver_code.index('fread(data')<driver_code.index('double before = now();')<driver_code.index('Parser parser =')<driver_code.index('api.destroy(parser);\n        double elapsed = now() - before;'))

ordinal=0;streams=[];observed_by_condition={};sample_counts=Counter();process_medians={key(c):{engine:[] for engine in engines} for c in conditions}
def process(row,condition,pair,cpu,count):
    global ordinal
    worker=S/f'worker-{ordinal:04d}.json';saved=j(worker)
    ck('immediate worker original fields '+str(ordinal),set(saved)=={'condition','engine','pair','command','returncode','stdout','stderr'} and saved=={field:row[field] for field in saved})
    ck('worker metadata '+str(ordinal),row['condition']==condition and row['pair']==pair and row['engine'] in engines and row['returncode']==0 and row['stderr']=='')
    engine=row['engine'];command=['taskset','-c',str(cpu),str(driver),protocol['libraries'][engine]['path'],condition['input'],str(condition['chunk']),str(count)]+(['namespaces'] if condition['namespaces'] else [])
    ck('worker command '+str(ordinal),row['command']==command)
    data=json.loads(row['stdout']);samples=data['samples']
    ck('worker output version '+str(ordinal),data['version']==('expat_2.8.4' if engine=='expat' else 'oriole_compat_2.8.4') and set(data)=={'version','samples'})
    ck('all sample fields '+str(ordinal),all(set(sample)=={'iteration','warmup','seconds','hash','elements','text_bytes'} and isinstance(sample['seconds'],(int,float)) and math.isfinite(sample['seconds']) and sample['seconds']>0 and isinstance(sample['elements'],int) and sample['elements']>=0 and isinstance(sample['text_bytes'],int) and sample['text_bytes']>=0 and len(sample['hash'])==16 for sample in samples))
    ck('sample count/indices/warmup '+str(ordinal),len(samples)==count+1 and [sample['iteration'] for sample in samples]==list(range(count+1)) and [sample['warmup'] for sample in samples]==[True]+[False]*count)
    observations=sorted({(sample['hash'],sample['elements'],sample['text_bytes']) for sample in samples})
    ck('sample callback observations '+str(ordinal),len(observations)==1 and row['observations']==[list(value) for value in observations])
    median=statistics.median(sample['seconds'] for sample in samples[1:])
    ck('worker median exact '+str(ordinal),median==row['median_seconds'])
    stage='preflight' if pair==-1 else 'timed'
    sample_counts[stage+'_workers']+=1;sample_counts[stage+'_warmups']+=1;sample_counts[stage+'_measured']+=count
    streams.append({'ordinal':ordinal,'worker_sha256':h(worker),'condition':condition,'pair':pair,'engine':engine,'stdout_sha256':hashlib.sha256(row['stdout'].encode()).hexdigest(),'stderr_sha256':hashlib.sha256(row['stderr'].encode()).hexdigest(),'measured_samples':count,'median_seconds':median})
    ordinal+=1
    return observations,median

ck('84 preflight records',len(pre['rows'])==84)
for index,condition in enumerate(conditions):
    rows=pre['rows'][3*index:3*index+3]
    ck('preflight engine order '+str(index),[row['engine'] for row in rows]==engines)
    observations=[process(row,condition,-1,3,1)[0] for row in rows]
    ck('three-engine preflight observations '+str(index),observations[0]==observations[1]==observations[2])
    observed_by_condition[key(condition)]=observations[0]

rng=random.Random(protocol['seed']);jobs=[(condition,pair) for condition in conditions for pair in range(7)];rng.shuffle(jobs)
ck('196 complete unique cohorts',len(results['rows'])==len(jobs)==196 and len({(key(row['condition']),row['pair']) for row in results['rows']})==196)
ratios={key(c):{name:[] for name in ratio_names} for c in conditions}
for index,((condition,pair),group) in enumerate(zip(jobs,results['rows'],strict=True)):
    order=engines.copy();rng.shuffle(order)
    ck('seeded cohort and engine order '+str(index),group['condition']==condition and group['pair']==pair and group['order']==order and [row['engine'] for row in group['processes']]==order)
    seconds={}
    for row in group['processes']:
        observations,median=process(row,condition,pair,0,condition['iterations'])
        ck('timed observations equal preflight',observations==observed_by_condition[key(condition)])
        seconds[row['engine']]=median;process_medians[key(condition)][row['engine']].append(median)
    for name in ratio_names:
        numerator,denominator=name.split('_over_');ratios[key(condition)][name].append(seconds[numerator]/seconds[denominator])
computed=[{'condition':c,'paired_ratios':ratios[key(c)],'median_ratios':{name:statistics.median(values) for name,values in ratios[key(c)].items()}} for c in conditions]
ck('all588 paired ratios and84 medians exact',results['summary']==computed)
ck('exact672 immediate worker files no extras',ordinal==672 and sorted(p.name for p in S.glob('worker-*.json'))==[f'worker-{index:04d}.json' for index in range(672)])
ck('sample counts all retained',dict(sample_counts)=={'preflight_workers':84,'preflight_warmups':84,'preflight_measured':84,'timed_workers':588,'timed_warmups':588,'timed_measured':105420})
groups={}
for label,predicate in [('real',lambda c:not c['name'].startswith('generated-')),('generated',lambda c:c['name'].startswith('generated-')),('real-namespaces-off',lambda c:not c['name'].startswith('generated-') and not c['namespaces']),('real-namespaces-on',lambda c:not c['name'].startswith('generated-') and c['namespaces'])]:
    selected=[row for row in computed if predicate(row['condition'])]
    groups[label]={'conditions':len(selected),'ratios':{}}
    for name in ratio_names:
        values=[row['median_ratios'][name] for row in selected]
        groups[label]['ratios'][name]={'geomean':math.exp(sum(math.log(value) for value in values)/len(values)),'below_one':sum(value<1 for value in values)}
published=j(R/'summary.json')
ck('published real/generated group summaries exact',published['groups']=={key:groups[key] for key in ['real','generated']})
regressions=[{'condition':row['condition'],'ratio':row['median_ratios']['candidate_over_published']} for row in computed if row['median_ratios']['candidate_over_published']>1]
ck('all real or generated regressions retained',published['regressions']==regressions)
ck('real24 improvements and reported point estimate',groups['real']['ratios']['candidate_over_published']=={'geomean':0.9494346726453999,'below_one':24})
ck('all four generated conditions and every candidate/Expat ratio retained',groups['generated']['conditions']==4 and all(math.isfinite(row['median_ratios']['candidate_over_expat']) and row['median_ratios']['candidate_over_expat']>0 for row in computed))
preflight_log=json.loads(read(R/'preflight-controller.log'))
timing_log=json.loads(read(R/'timing-controller.log'))
ck('outer preflight log agrees',preflight_log=={'status':'passed','preflights':84,'protocol_sha256':h(S/'protocol.json')})
ck('outer timing log all summaries retained',timing_log=={'status':'passed','timed_workers':588,'summary':computed})
ck('all inspected input files unchanged at audit end',all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected for path,expected in tracked.items()))

condition_table=[]
for row in computed:
    condition=row['condition']
    condition_table.append({'condition':condition,'median_process_seconds':{engine:statistics.median(values) for engine,values in process_medians[key(condition)].items()},'median_ratios':row['median_ratios'],'paired_ratios':row['paired_ratios']})
(O/'streams.json').write_text(json.dumps(streams,indent=2)+'\n')
(O/'conditions.json').write_text(json.dumps(condition_table,indent=2)+'\n')
(O/'groups.json').write_text(json.dumps(groups,indent=2)+'\n')
(O/'checked-files.json').write_text(json.dumps(tracked,indent=2,sort_keys=True)+'\n')
report={
 'status':'independent_saved_native_audit_passed',
 'scope':'Saved-data-only native timing source/hash/metadata/order/arithmetic audit. No parser, build, benchmark or timing executions. Completed correctness-gate handoff left unchanged.',
 'audit_cpu':6,'interpreter':sys.executable,
 'counts':{'conditions':28,'real_conditions':24,'generated_conditions':4,'preflight_workers':84,'preflight_samples_with_warmups':168,'timed_workers':588,'timed_warmups':588,'timed_measured_samples':105420,'all_samples_with_preflights_and_warmups':106176,'seeded_cohorts':196,'immediate_worker_records':672,'paired_ratios':588,'per_condition_ratio_medians':84},
 'identities':{'libraries':protocol['libraries'],'candidate_source_manifest_sha256':h(candidate_root/'source.json'),'candidate_source_files':70,'candidate_live_and_source_archives_verified':True,'baseline_archived_source_files':len(baseline_source['source_sha256']),'baseline_live_source_files_verified':70,'composition_review_sha256':h(composition_review),'comparison_baseline':'Direct integration parent 64a270e / 3694b683; separate from the standalone matching-end study against 5af2406b','common_runtime_source_changes':['crates/oriole/src/lib.rs'],'driver':{'source_sha256':h(driver_source),'binary_sha256':h(driver),'original_build_record_sha256':h(origin_path),'original_build_command':origin['build_command'],'binding':'Per-process absolute library path, dlopen(RTLD_LOCAL|RTLD_NOW), dlsym on that handle; version output checked. No per-worker dladdr receipt was emitted.'}},
 'groups':groups,'regressions':regressions,'generated_conditions':[row for row in condition_table if row['condition']['name'].startswith('generated-')],
 'point_estimate':{'real_candidate_control_ratio':groups['real']['ratios']['candidate_over_published']['geomean'],'real_elapsed_reduction_percent':100*(1-groups['real']['ratios']['candidate_over_published']['geomean']),'real_candidate_expat_ratio':groups['real']['ratios']['candidate_over_expat']['geomean']},
 'method':['Every immediate worker record matched its copied phase record on every original field; all commands/CPUs/versions/status/stderr and106176 sample records checked.','Reconstructed conditions from pinned project manifest and retained generated inputs; fixed per-process iteration counts and exactly one excluded warmup retained.','Reproduced seed2026091003 cohort shuffle, engine order and all196 cohort labels. Recomputed process medians, all three families of paired ratios, all28 condition summaries and all published real/generated group aggregates.','Ratios are medians of seven within-cohort process-median ratios. Group results are geometric means of condition medians. Do not replace these with ratios of unpaired aggregate medians.'],
 'limits':['Native measured region includes parser construction, callback setup, XML_Parse calls/native callbacks and parser free. Input I/O, dlopen, process startup and full application work are outside the sample timer.','Selected callback FNV hashes and counts agree across engines; this does not prove exact callback fragmentation, position or API conformance.','One shared host, fixed seven cohorts, timing workers pinnedCPU0 and preflightCPU3. Pinning/shuffling does not eliminate contention or establish statistical significance.',f"Retained all {len(regressions)} candidate/control regressions, all four generated conditions and all candidate/Expat ratios. Real improvements: {groups['real']['ratios']['candidate_over_published']['below_one']}/24; generated improvements: {groups['generated']['ratios']['candidate_over_published']['below_one']}/4.",'No PGO, parser reruns, sample filtering, removal or adoption decision in this audit. Batik external DTD is not loaded by this native driver.','Driver worker timeout90s; preflight outer timeout600s; timing outer timeout1200s. Timing wrapper handles timeout with process-group kill/wait; these scripts do not provide an explicit comprehensive SIGTERM forwarding guarantee.','Recorded source and runtime identities are rehashed now and during this audit; these checks cannot prove historical immutability outside recorded before/after evidence.','Python timings and strict CPython consumer checks are parent-owned and excluded.'],
 'checked_file_count':len(tracked),'passed_checks':len(checks),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'artifact_sha256':{name:hashlib.sha256((O/name).read_bytes()).hexdigest() for name in ['streams.json','conditions.json','groups.json','checked-files.json']},
}
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest(),'checked_files':len(tracked),'checks':len(checks),'real':groups['real'],'generated':groups['generated']},indent=2))
