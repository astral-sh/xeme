import ctypes as c
import hashlib
import itertools
import json
from pathlib import Path

paths = {
    'reference': '/home/dev-user/.cache/oriole/expat-build/libexpat.so',
    'candidate': '/tmp/oriole-api-amplification/reviewed/liboriole_expat.so',
    'initial': '/tmp/oriole-api-amplification/initial/liboriole_expat.so',
}
libs = {}
rows = []
for label, path in paths.items():
    lib = c.CDLL(path)
    libs[label] = lib
    for name, args, result in [
        ('XML_ParserCreate', [c.c_char_p], c.c_void_p),
        ('XML_ExternalEntityParserCreate', [c.c_void_p, c.c_char_p, c.c_char_p], c.c_void_p),
        ('XML_Parse', [c.c_void_p, c.c_char_p, c.c_int, c.c_int], c.c_int),
        ('XML_GetErrorCode', [c.c_void_p], c.c_int),
        ('XML_ParserFree', [c.c_void_p], None),
        ('XML_SetBillionLaughsAttackProtectionMaximumAmplification', [c.c_void_p, c.c_float], c.c_ubyte),
        ('XML_SetBillionLaughsAttackProtectionActivationThreshold', [c.c_void_p, c.c_ulonglong], c.c_ubyte),
    ]:
        function = getattr(lib, name)
        function.argtypes = args
        function.restype = result
for data, encoding, final in itertools.product(
    [b'\xef\xbb\xbf', b'\xff\xfe', b'\xfe\xff', b'\xef\xbb\xbfX', b'X'],
    [None, b'UTF-8', b'UTF-16', b'US-ASCII', b'ISO-8859-1', b'custom-unknown'],
    [0, 1],
):
    results = {}
    for label, lib in libs.items():
        parser = lib.XML_ParserCreate(None)
        assert lib.XML_SetBillionLaughsAttackProtectionMaximumAmplification(parser, 1.0)
        assert lib.XML_SetBillionLaughsAttackProtectionActivationThreshold(parser, 0)
        child = lib.XML_ExternalEntityParserCreate(parser, b'', encoding)
        assert child
        status = lib.XML_Parse(child, data, len(data), final)
        error = lib.XML_GetErrorCode(child)
        results[label] = {'status': status, 'error': error}
        lib.XML_ParserFree(child)
        lib.XML_ParserFree(parser)
    rows.append({'bytes': data.hex(), 'encoding': encoding.decode() if encoding else None,
                 'final': final, 'results': results})
report = {
    'libraries': {label: {'path': path, 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest()}
                  for label, path in paths.items()},
    'rows': rows,
    'mismatches': [row for row in rows if row['results']['reference'] != row['results']['candidate']],
}
report['new_mismatches'] = [row for row in report['mismatches'] if row['results']['candidate'] != row['results']['initial']]
Path('/tmp/oriole-accounting-review-bom-reviewed.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'cases': len(rows), 'mismatches': len(report['mismatches']),
                  'new_mismatches': len(report['new_mismatches']), 'remaining': report['mismatches']}, indent=2))
