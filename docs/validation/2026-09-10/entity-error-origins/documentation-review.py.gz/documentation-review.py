from pathlib import Path
import hashlib,json,re,tarfile
R=Path('/home/dev-user/code/oss/oriole');W=R/'docs/validation/2026-09-10/entity-error-origins'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((W/'files.json').read_text());assert sha(W/'evidence.tar.gz')==manifest['sha256'];assert (W/'evidence.tar.gz').stat().st_size==manifest['bytes']
with tarfile.open(W/'evidence.tar.gz') as t:
 members=t.getmembers();assert len(members)==manifest['members']==175;assert len({m.name for m in members})==175
 for m in members:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  b=t.extractfile(m).read();expected=manifest['files'][m.name];assert len(b)==expected['bytes'] and hashlib.sha256(b).hexdigest()==expected['sha256']
 def read(n):return t.extractfile(n).read()
 tests=read('study/workspace-tests.log').decode();counts=[int(x) for x in re.findall(r'test result: ok\. (\d+) passed;',tests)];assert sum(counts)==369 and 'test result: FAILED' not in tests
 clippy=read('study/clippy.log').decode();assert 'Finished `dev` profile' in clippy and 'error:' not in clippy
 assert not read('study/fmt.log')
 a=json.loads(read('study/differential-baseline/reference.json'));b=json.loads(read('study/differential-baseline/oriole.json'));assert a==b and len(a['results'])==3318
 summary=json.loads(read('study/differential-baseline/summary.json'));assert summary['exact_pass'] and summary['semantic_pass'] and summary['cases']==3318 and not summary['differences']
 assert summary['libraries']['reference']['sha256_before']=='ac6a0a6adcabba65ef338d362f438c588ad4a01a9821989bae28f445ba7778ac'
 assert summary['libraries']['oriole']['sha256_before']=='3a80baddfd3189123378c63d08c85dd756d22b16b3d715abf2e8c2eedbf2e5ea'
 for v in summary['libraries'].values():assert v['sha256_before']==v['sha256_after'] and v['returncode']==0
prior=Path('/tmp/oriole-async-position-independent-review.json');assert sha(prior)=='b53ea9ea8cf1180607e3b02bde342c1359b94441821b4acac61b881def16f0b4';assert sha(W/'independent-review.json')==sha(prior)
source=json.loads((W/'source.json').read_text());assert len(source['source_files'])==65
for name,expected in source['source_files'].items():assert sha(R/name)==expected,(name,sha(R/name),expected)
docs=[R/'README.md',R/'docs/review.md',W/'README.md']
for p in docs:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' not in target and not target.startswith('#'):assert (p.parent/target.split('#')[0]).exists(),(p,target)
assert 'preceding `4b11ace` runtime' in docs[0].read_text()
report={'status':'passed','scope':'Saved evidence and documentation audit only; no parser/test/benchmark reruns. Prior b53ea review supplies original API/source and independently executed nested-probe verification. Root-reported controller exits are attributed, not independently observed terminal sessions.','docs':{str(p):sha(p) for p in docs},'archive':{'sha256':manifest['sha256'],'members_read_and_rehashed':175,'bytes':manifest['bytes']},'integration_source_files_rehashed':65,'workspace':{'passed_sum_reconstructed':sum(counts),'successful_test_binaries':len(counts),'clippy_completion_and_no_errors':True,'fmt_log_empty':True,'controller_exit_0':'root recorded in summary.json'},'strict_baseline':{'records_compared':3318,'all_records_exact':True,'control':'Oriole4b11ace ac6a; not Expat','candidate':'3a80badd','library_hashes_stable':True},'api':{'baseline_pass':4323,'baseline_fail':417,'candidate_pass':4335,'candidate_fail':405,'fixed':12,'new_failures':0,'prior_independent_review_sha256':sha(prior)},'review_notes':['No factual correction requested.','Remaining 18 nested diagnostic comparisons and historical binary scope are explicit.','The 369 count is all-target tests for this candidate, distinct from the older 368 plus one doc-test accounting.','Source identity is 65 integrated runtime/test/manifest files, not a claim that every repository file is unchanged.'],'artifacts':{str(W/n):sha(W/n) for n in ['files.json','summary.json','source.json','api-comparison.json','independent-review.json']},'audit_script_sha256':sha(Path(__file__))}
p=Path('/tmp/oriole-async-docs-independent-review.json');p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p)}))
