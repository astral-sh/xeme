from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import shutil
import tarfile

ROOT = Path('/home/dev-user/code/oss/oriole')
WORKTREE = Path('/home/dev-user/code/oss/oriole-async-position')
STUDY = Path('/tmp/oriole-async-entity-study')
BASE = Path('/tmp/oriole-version-final-consumer-validation/upstream-api')
OUT = ROOT / 'docs/validation/2026-09-10/entity-error-origins'
OUT.mkdir(parents=True, exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_text())
source = load(STUDY / 'source.json')
members = {}
for name, digest in source['source_files'].items():
    data = (WORKTREE / name).read_bytes()
    assert sha(data) == digest, name
    assert (ROOT / name).read_bytes() == data, name
    members['source/' + name] = data
for path in sorted(STUDY.rglob('*')):
    if path.is_file() and path.name not in {'liboriole_expat.a', 'liboriole_expat.so', 'runtests'}:
        members['study/' + str(path.relative_to(STUDY))] = path.read_bytes()
for name in ['manifest.json', 'results.json', 'tests.log', 'build.log']:
    members['baseline-api/' + name] = (BASE / name).read_bytes()
for name in ['tools/differential.py', 'tools/corpus.py', 'tools/xml_abi.py']:
    members['source/' + name] = (WORKTREE / name).read_bytes()
for name in ['oriole-async-position-independent-review.json', 'oriole-async-position-independent-audit.py',
             'oriole-async-nested-probe.json', 'oriole-async-nested-probe.py', 'oriole-async-nested-probe.log']:
    members['review/' + name] = (Path('/tmp') / name).read_bytes()
members['packaging.py'] = Path(__file__).read_bytes()
counts = [int(x) for x in re.findall(r'test result: ok\. (\d+) passed;', (STUDY / 'workspace-tests.log').read_text())]
assert sum(counts) == 369
diff = load(STUDY / 'differential-baseline/summary.json')
assert diff['exact_pass'] and diff['cases'] == 3318 and not diff['differences']
summary = {
    'status': 'reviewed_and_selected',
    'runtime_base': source['base_commit'],
    'integration_base': '450b3321a3ffb7e59879695a67776d08c7b5114f',
    'source_files': len(source['source_files']),
    'libraries': source['libraries'],
    'patch_sha256': source['patch_sha256'],
    'workspace_checks': {'session_id': 14072, 'exit_code': 0, 'all_targets_passed': 369,
                         'clippy_warnings_denied': True, 'fmt_check_passed': True},
    'focused_positions': {'session_id': 99779, 'exit_code': 0, 'tests_passed': 3},
    'strict_baseline_differential': {'session_id': 99897, 'exit_code': 0, 'observations': 3318,
                                   'all_exactly_unchanged': True,
                                   'reference_is_published_oriole_baseline_not_expat': True},
    'original_api': {'configurations': 4740, 'before_passed': 4323, 'before_failed': 417,
                     'after_passed': 4335, 'after_failed': 405, 'fixed': 12, 'new_failures': 0,
                     'other_changes': 0, 'exit_code': 1, 'unchanged_assertions_and_bounds': True},
    'scope': 'An exhausted unbalanced entity retains its reference origin after pop. No allocation, accepted/rejected outcome, callback, resource limit or performance claim changes.',
    'remaining_probe_differences': 'Other premature-close paths retain nonzero byte counts; nested CDATA retains error13 versus Expat20. These pre-existing differences are preserved in exact probe rows.',
}
members['summary.json'] = (json.dumps(summary, indent=2) + '\n').encode()
with (OUT / 'evidence.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
with tarfile.open(OUT / 'evidence.tar.gz', 'r:gz') as archive:
    assert len(archive.getmembers()) == len(members)
    for member in archive.getmembers():
        assert archive.extractfile(member).read() == members[member.name], member.name
files = {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(members.items())}
metadata = {'sha256': sha((OUT / 'evidence.tar.gz').read_bytes()), 'bytes': (OUT / 'evidence.tar.gz').stat().st_size,
            'members': len(members), 'files': files}
(OUT / 'files.json').write_text(json.dumps(metadata, indent=2) + '\n')
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for src, dest in [(STUDY / 'source.json', 'source.json'), (STUDY / 'api-comparison.json', 'api-comparison.json'),
                  (Path('/tmp/oriole-async-position-independent-review.json'), 'independent-review.json')]:
    shutil.copy2(src, OUT / dest)
print(json.dumps({key: value for key, value in metadata.items() if key != 'files'}, indent=2))
