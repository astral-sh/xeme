import ctypes,hashlib,json
from pathlib import Path
libs={'reference':'/tmp/oriole-pgo-study/expat-control-liboriole_expat.so','baseline':'/tmp/oriole-version-final/liboriole_expat.so','candidate':'/tmp/oriole-async-entity-study/liboriole_expat.so'}
cases=[
 ('nested-open',"<!DOCTYPE r [<!ENTITY i '<n>'><!ENTITY o '&i;'>]><r>&o;</n></r>"),
 ('nested-text-open',"<!DOCTYPE r [<!ENTITY i '<n>'><!ENTITY o 'x&i;'>]><r>&o;</n></r>"),
 ('nested-cdata',"<!DOCTYPE r [<!ENTITY i '<![CDATA[x'><!ENTITY o '&i;'>]><r>&o;]]></r>"),
 ('nested-close',"<!DOCTYPE r [<!ENTITY i '</r>'><!ENTITY o '&i;'>]><r>&o;"),
 ('three-level-open',"<!DOCTYPE r [<!ENTITY i '<n>'><!ENTITY m '&i;'><!ENTITY o '&m;'>]><r>&o;</n></r>"),
 ('balanced',"<!DOCTYPE r [<!ENTITY i '<n/>'><!ENTITY o '&i;'>]><r>&o;</r>"),
]
rows=[]
for label,path in libs.items():
 lib=ctypes.CDLL(path,mode=ctypes.RTLD_LOCAL)
 funcs=[('XML_ParserCreate',[ctypes.c_char_p],ctypes.c_void_p),('XML_ParserFree',[ctypes.c_void_p],None),('XML_Parse',[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int,ctypes.c_int],ctypes.c_int),('XML_GetErrorCode',[ctypes.c_void_p],ctypes.c_int),('XML_GetCurrentByteIndex',[ctypes.c_void_p],ctypes.c_long),('XML_GetCurrentByteCount',[ctypes.c_void_p],ctypes.c_int),('XML_GetCurrentLineNumber',[ctypes.c_void_p],ctypes.c_ulong),('XML_GetCurrentColumnNumber',[ctypes.c_void_p],ctypes.c_ulong)]
 for name,args,result in funcs:
  f=getattr(lib,name);f.argtypes=args;f.restype=result
 for case,xml in cases:
  for encoding in ['utf8','utf16le','utf16be']:
   data=xml.encode() if encoding=='utf8' else (b'\xff\xfe' if encoding=='utf16le' else b'\xfe\xff')+xml.encode('utf-16-le' if encoding=='utf16le' else 'utf-16-be')
   for width in [len(data),1,7]:
    p=lib.XML_ParserCreate(None);assert p
    for offset in range(0,len(data),width):
     chunk=data[offset:offset+width];status=lib.XML_Parse(p,chunk,len(chunk),int(offset+width>=len(data)))
     if status!=1:break
    result={name:int(getattr(lib,'XML_Get'+name)(p)) for name in ['ErrorCode','CurrentByteIndex','CurrentByteCount','CurrentLineNumber','CurrentColumnNumber']}
    rows.append({'engine':label,'case':case,'encoding':encoding,'width':0 if width==len(data) else width,'status':status,**result});lib.XML_ParserFree(p)
result={'scope':'Additional bounded nested source/anchor diagnostics; no callbacks, whole/1/7 byte widths and UTF8/UTF16LE/BE; clean managed Python-I-S CPU7.',
 'libraries':{k:{'path':v,'sha256':hashlib.sha256(Path(v).read_bytes()).hexdigest()} for k,v in libs.items()},'cases':cases,'rows':rows,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
p=Path('/tmp/oriole-async-nested-probe.json');p.write_text(json.dumps(result,indent=2)+'\n')
for case,_ in cases:
 print(case,{e:sorted({(r['status'],r['ErrorCode'],r['CurrentByteCount']) for r in rows if r['case']==case and r['engine']==e}) for e in libs})
