from pathlib import Path
import collections,hashlib,json
ROOT=Path('/tmp/oriole-async-entity-study')
SOURCE=Path('/home/dev-user/code/oss/oriole-async-position')
BASE=Path('/tmp/oriole-version-final-consumer-validation/upstream-api')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
source=load(ROOT/'source.json')
assert sha(ROOT/'position.patch')==source['patch_sha256']=='54f18e3b5f29afc6e8297b28fc3e75b364069dafca6b4c704a26326a551576cc'
for name,digest in source['source_files'].items():assert sha(SOURCE/name)==digest,name
for name,digest in source['libraries'].items():assert sha(ROOT/name)==digest
initial=load(ROOT/'baseline.json');candidate=load(ROOT/'candidate.json')
assert initial['cases']==candidate['cases'] and initial['test_body_sha256']==candidate['test_body_sha256']
key=lambda r:(r['engine'],r['case'],r['width'],r['deferral'])
old={key(r):r for r in initial['rows']};new={key(r):r for r in candidate['rows']}
assert len(old)==120 and len(new)==180
for k,v in old.items():assert new[k]==v
for info in candidate['libraries'].values():assert sha(Path(info['path']))==info['sha256']
counts=collections.Counter()
for case in range(5):
 for width in range(6):
  for deferred in range(2):
   rows={e:new[e,case,width,deferred] for e in ('reference','baseline','candidate')}
   r,b,c=(rows[e] for e in ('reference','baseline','candidate'))
   assert (r['status'],r['error'])==(b['status'],b['error'])==(c['status'],c['error'])==(0,13)
   assert c['feeds']==b['feeds']
   assert all(c[k]==r[k] for k in ['line','column','byte_index'])
   if case in (0,3):
    assert c['byte_count']==r['byte_count']==0
    assert any(b[k]!=r[k] for k in ['column','byte_index'])
    counts['coordinate_fixed_configurations']+=1
   else:
    assert c['byte_count']==b['byte_count']!=r['byte_count']
    counts['retained_byte_count_differences']+=1
   counts['engine_comparison_configurations']+=1
nested_path=Path('/tmp/oriole-async-nested-probe.json');nested=load(nested_path)
nd={(r['engine'],r['case'],r['encoding'],r['width']):r for r in nested['rows']}
assert len(nd)==162
fields=['status','ErrorCode','CurrentByteIndex','CurrentByteCount','CurrentLineNumber','CurrentColumnNumber']
nc=collections.Counter()
for k,r in nd.items():
 if k[0]!='reference':continue
 b=nd['baseline',*k[1:]];c=nd['candidate',*k[1:]]
 same=lambda x,y:all(x[f]==y[f] for f in fields)
 nc['comparisons']+=1
 nc['baseline_differences']+=not same(b,r)
 nc['candidate_differences']+=not same(c,r)
 nc['fully_fixed']+=not same(b,r) and same(c,r)
 nc['new_previously_matching_differences']+=same(b,r) and not same(c,r)
 assert c['status']==b['status'] and c['ErrorCode']==b['ErrorCode']
assert nc['new_previously_matching_differences']==0
bm=load(BASE/'manifest.json');cm=load(ROOT/'upstream-api/manifest.json')
exclude={'library_sha256','compile_command','binary_sha256','adapter_sources'}
assert [x.replace(str(BASE),'<root>') for x in bm['compile_command']]==[x.replace(str(ROOT/'upstream-api'),'<root>') for x in cm['compile_command']]
for name in set(bm['adapter_sources']) & set(cm['adapter_sources']): assert bm['adapter_sources'][name]==cm['adapter_sources'][name]
assert set(cm['adapter_sources'])-set(bm['adapter_sources'])=={'README.md','allocator_repro.c'}
assert set(bm['adapter_sources'])-set(cm['adapter_sources'])=={'run_clean.py'}
for k in set(bm)|set(cm):
 if k not in exclude:assert bm[k]==cm[k],k
for name,digest in cm['adapted_sources'].items():assert sha(ROOT/'upstream-api/adapted'/name)==digest,name
assert sha(ROOT/'upstream-api/runtests')==cm['binary_sha256']
assert sha(ROOT/'upstream-api/liboriole_expat.so')==cm['library_sha256']==source['libraries']['liboriole_expat.so']
br=load(BASE/'results.json');cr=load(ROOT/'upstream-api/results.json')
for d in [br,cr]:
 assert len(d['results'])==4740 and d['selection_complete'] and d['library_origin_verified'] and not d['timed_out']
 assert d['returncode']==1
 assert sum(r['outcome']=='pass' for r in d['results'])==d['passed']
 assert sum(r['outcome']=='fail' for r in d['results'])==d['failed']
changed=[]
for b,c in zip(br['results'],cr['results'],strict=True):
 assert (b['test'],b['context'])==(c['test'],c['context'])
 if b!=c:changed.append({'before':b,'after':c})
assert len(changed)==12 and all(x['before']['test']=='test_misc_async_entity_rejected' and x['before']['outcome']=='fail' and x['after']['outcome']=='pass' for x in changed)
comparison=load(ROOT/'api-comparison.json');assert comparison['changes']==changed
report={
 'status':'no_blocker_found',
 'scope':'Independent source review, hashes and saved five-case/API reconstruction; one additional bounded nested-source C probe ran under managed Python-I-S on CPU7. No builds or full test reruns.',
 'patch_sha256':source['patch_sha256'],'source_files_verified':len(source['source_files']),
 'source_manifest_sha256':sha(ROOT/'source.json'),'libraries':source['libraries'],
 'source_review':[
  'The pop still runs before the terminal imbalance check and removes the active-source index exactly once. Its returned Source remains owned until the Error value is constructed and then is dropped normally.',
  'Source.position(0) copies the saved reference anchor without allocation. No references escape and no callback, parser mutation, work-accounting, or selected-allocator path is introduced.',
  'The exhausted source and parent reference have already been consumed; using the parent position lost the reference origin. The new path retains the failing source anchor while preserving error kind13 and its static message.',
  'Clearing byte_count is correct end-of-source error behavior, but is not universally identical to the old path: a nested parent anchor previously produced its nonzero reference span. The independent nested probe confirms Expat uses zero for this failure.',
  'The new focused regression covers direct/nested-empty replacement forms, non-ASCII prefix, CRLF, and all byte widths for UTF8/UTF16LE/UTF16BE. Its saved three-test log passes; no independent Rust rerun is claimed.'
 ],
 'original_five_case_probe':{'saved_records':180,'original120_control_records_unchanged':True,**dict(counts),
                             'all_reject_same_error13':True,'candidate_vs_baseline_feed_statuses_unchanged':True},
 'nested_probe':{'records':162,**dict(nc),'remaining':'Nine nested CDATA controls retain pre-existing Expat20 versus Oriole13; nine nested premature-close controls retain the other branch\'s nonzero byte_count. No new accepted/rejected outcome or previously matching discrepancy.',
                 'sha256':sha(nested_path),'script_sha256':sha(Path('/tmp/oriole-async-nested-probe.py'))},
 'full_api':{'rows':4740,'baseline':{'passed':br['passed'],'failed':br['failed']},'candidate':{'passed':cr['passed'],'failed':cr['failed']},
             'fixed_configurations':12,'fixed_test':'test_misc_async_entity_rejected','new_failures':0,'other_changes':0,
             'same_original_selection_compiled_sources_flags_and_bounds':True,
             'adapter_inventory_scope':'Shared adapter hashes match; candidate additionally inventories README.md and separate allocator_repro.c, and does not inventory baseline run_clean.py. These inventory differences are not compiled test changes.','seconds_per_test':cm['per_test_seconds'],
             'address_space_bytes':cm['per_test_address_space_bytes'],'rss_bytes':cm['per_test_rss_limit_bytes'],
             'baseline_results_sha256':sha(BASE/'results.json'),'candidate_results_sha256':sha(ROOT/'upstream-api/results.json')},
 'evidence_sha256':{name:sha(ROOT/name) for name in ['baseline.json','candidate.json','candidate-probe.py','api-comparison.json','position-tests.log']},
 'audit_script_sha256':sha(Path(__file__))
}
p=Path('/tmp/oriole-async-position-independent-review.json');p.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'review':str(p),'sha256':sha(p),'nested':dict(nc),'api':(br['passed'],cr['passed'])}))
