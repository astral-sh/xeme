from pathlib import Path
import ast, ctypes, hashlib, json, re
source=Path('/tmp/oriole-version-final-consumer-validation/upstream-api/adapted/misc_tests.c')
body=source.read_text().split('START_TEST(test_misc_async_entity_rejected) {',1)[1].split('END_TEST',1)[0]
pattern=r'\{((?:"(?:[^"\\]|\\.)*"\s*)+),\s*(XML_STATUS_\w+),\s*(XML_ERROR_\w+),\s*(\d+),\s*(\d+)\}'
cases=[]
for strings,status,error,line,column in re.findall(pattern,body):
    cases.append({'xml': ''.join(ast.literal_eval(t) for t in re.findall(r'"(?:[^"\\]|\\.)*"',strings)), 'expected_line':int(line),'expected_column':int(column)})
assert len(cases)==5
libraries={'baseline':'/tmp/oriole-version-final/liboriole_expat.so','reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','candidate':'/tmp/oriole-async-entity-study/liboriole_expat.so'}
rows=[]
for engine,path in libraries.items():
    lib=ctypes.CDLL(path,mode=ctypes.RTLD_LOCAL)
    for name,args,result in [('XML_ParserCreate',[ctypes.c_char_p],ctypes.c_void_p),('XML_ParserFree',[ctypes.c_void_p],None),('XML_Parse',[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int,ctypes.c_int],ctypes.c_int),('XML_GetErrorCode',[ctypes.c_void_p],ctypes.c_int),('XML_GetCurrentByteIndex',[ctypes.c_void_p],ctypes.c_long),('XML_GetCurrentByteCount',[ctypes.c_void_p],ctypes.c_int),('XML_GetCurrentLineNumber',[ctypes.c_void_p],ctypes.c_ulong),('XML_GetCurrentColumnNumber',[ctypes.c_void_p],ctypes.c_ulong),('XML_SetReparseDeferralEnabled',[ctypes.c_void_p,ctypes.c_ubyte],ctypes.c_ubyte)]:
        f=getattr(lib,name);f.argtypes=args;f.restype=result
    for case_index,case in enumerate(cases):
        data=case['xml'].encode()
        for width in [0,1,2,3,4,5]:
            for deferral in [0,1]:
                p=lib.XML_ParserCreate(None);assert p
                assert lib.XML_SetReparseDeferralEnabled(p,deferral)
                step=width or len(data);feeds=[]
                for offset in range(0,len(data),step):
                    chunk=data[offset:offset+step]
                    status=lib.XML_Parse(p,chunk,len(chunk),int(offset+step>=len(data)))
                    feeds.append({'offset':offset,'status':status})
                    if status!=1:break
                row={'engine':engine,'case':case_index,'width':width,'deferral':deferral,'status':status,'error':lib.XML_GetErrorCode(p),'line':lib.XML_GetCurrentLineNumber(p),'column':lib.XML_GetCurrentColumnNumber(p),'byte_index':lib.XML_GetCurrentByteIndex(p),'byte_count':lib.XML_GetCurrentByteCount(p),'feeds':feeds}
                rows.append(row);lib.XML_ParserFree(p)
    lib._keepalive=True
result={'source_test_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'test_body_sha256':hashlib.sha256(body.encode()).hexdigest(),'cases':cases,'libraries':{n:{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for n,p in libraries.items()},'rows':rows}
Path('/tmp/oriole-async-entity-study/candidate.json').write_text(json.dumps(result,indent=2)+'\n')
for case in range(5):
    print(case,{e:sorted({(r['status'],r['error'],r['line'],r['column'],r['byte_index'],r['byte_count']) for r in rows if r['case']==case and r['engine']==e}) for e in libraries})
