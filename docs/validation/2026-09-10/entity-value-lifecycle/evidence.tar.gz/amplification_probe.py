"""Repeat the lifecycle cases across caller-selected relative limits."""
import hashlib
import itertools
import json
import sys
from pathlib import Path
import runpy

probe = runpy.run_path(str(Path(__file__).with_name("probe.py")))
CASES, run, setup = (probe[name] for name in ("CASES", "run", "setup"))

paths = {'reference': '/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4', 'candidate': '/tmp/oriole-entity-lifecycle-integrated/liboriole_expat.so'}
preloaded = probe['check_initial_libraries']()
libraries = {name: setup(path) for name, path in paths.items()}
rows = []
for case, chunk, factor in itertools.product(CASES, [0, 1, 7], [1, 1.01, 1.1, 2, 100]):
    results = {name: run(lib, case, chunk, factor) for name, lib in libraries.items()}
    rows.append({'case': case, 'chunk': chunk, 'factor': factor, 'results': results})
keys = ['statuses', 'errors', 'text', 'children']
acceptance = [row for row in rows if any(row['results']['reference'][key] != row['results']['candidate'][key] for key in keys)]
report = {'python': sys.executable, 'preloaded_expat': preloaded, 'libraries': {name: {'path': path, 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest()} for name, path in paths.items()}, 'rows': rows, 'status_error_text_child_mismatches': len(acceptance)}
Path('/tmp/oriole-entity-lifecycle-integrated/amplification-probe.json').write_text(json.dumps(report, indent=2) + '\n')
print(len(rows), len(acceptance))
for row in acceptance[:20]:
    print(row['case'], row['chunk'], row['factor'], {name: {key: result[key] for key in keys} for name, result in row['results'].items()})
