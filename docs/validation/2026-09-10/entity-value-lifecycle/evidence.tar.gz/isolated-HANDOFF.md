# Persistent parameter entity state after an external value

Candidate patch: `candidate.patch`, based on immutable root commit
`23d13af2869d2b07c35f726b366655ae49417435`. Source lives in
`/tmp/oriole-raw-attribute-scratch`, reusing its existing target. The previous raw
attribute candidate source is preserved there in `previous-raw-candidate-source.tar.gz`.
No shared checkout edits or Git writes were made.

## Result

The compiled candidate matches pinned Expat 2.8.4 status, nested error chain,
character output, and child parse outcomes for all **60 lifecycle conditions**
(20 cases, chunks 0/1/7), and all **300 relative-limit conditions** (the same
cases/chunks, factors 1/1.01/1.1/2/100, threshold 0). The baseline differs on
39/60 lifecycle conditions. The original reported input is the same-value,
later-external-reference case; it now fails with recursive error 12 in the child
and external-handler error 21 in its ancestors.

All accepted lifecycle inputs also have identical declaration callbacks. In
27/60 rejected conditions, Expat emits a partially built entity declaration before
returning the error, whereas Oriole omits that failed declaration. This callback
difference is explicitly preserved in the raw reports; this patch fixes acceptance
and recursive errors and does not claim full callback equivalence.

## Why Expat behaves this way

Pinned revision: `12cf0b1f25f026a022fe728ad8f7e3d017285b80`.

- `expat/lib/xmlparse.c:5190`: `entityValueProcessor` calls `storeEntityValue`
  directly after scanning an external value.
- `:6952` onward: an internal parameter reference calls `processEntity` and
  returns, truncating the rest of that external value.
- `:6487`: `processEntity` sets the shared DTD entity's `open` flag.
- `:7060` onward: the ordinary value wrapper drains and closes the queued entity;
  the external value processor does not call this wrapper.
- `:1920`: freeing the external child frees its queued entity nodes without
  clearing that shared entity flag.
- `:7885`: general-content DTD copies copy declarations without copying open flags.

Probes cover later references in the same value, later declarations, ordinary DTD
references, declaration fragments, conditional headers, nested children, siblings
created before and after the first parse, DTD return, empty internal values,
missing entities, untouched tail entities, independent general-content copies,
and parser reset.

## Implementation

`Entity.value_open` is an optional selected-allocator `Shared<AtomicBool>`.
Only completed internal parameter declarations allocate a flag. Ordinary general
entities, external parameter declarations, and unfinished reserved slots do not.
Parameter children and successful DTD merges share the flag, including precreated
siblings. General-content children receive a fresh false flag; a copied reserved
parameter slot becomes an empty internal entity and also gets a fresh flag.

The external value's existing internal-reference truncation branch marks the
entity open. All five parameter-reference readers check the flag alongside their
existing active recursion checks. The safe core remains free of unsafe code.

Entity count limits bound the number of flags; the selected allocator tracks their
actual live allocation including control metadata. Structural entity charges grow
with `size_of::<Entity>()`, and newly allocated atomic payloads are explicitly
charged to the absolute work budget. Caller relative limits continue to count
consumed entity bytes through the existing accounting paths. Declaration limits
are checked before allocating the new flag. No shared mutable hash tables, global
registries, or new parser-wide allocations were added.

## Validation

Final-source runs passed **105 unique Rust tests**:

- 13 core unit tests and 71 C adapter unit tests, including reset after a value
  child leaves an internal parameter entity open.
- 12 external-value integration tests, including all five reference readers,
  precreated siblings, fresh general-content copies, and parent destruction.
- 7 parameter-value integration tests, including independent depth/output/work
  limits and standalone behavior.
- 2 exhaustive allocation tests: the existing full core workload and a focused
  shared-state/sibling/copy/parent-destruction workload. Every allocation may fail;
  no leaks or global allocator escapes are allowed, and terminal OOM retries do
  not allocate.

Strict Clippy for both affected packages' libraries and tests, formatting, and
patch apply-check against saved immutable base files all pass. No release timing,
new sanitizer run, or full upstream API matrix is claimed for this candidate.

## Rerun probes

Use this interpreter explicitly. The system `/usr/bin/python3` preloads a different
system Expat, which can interpose symbols and invalidate or crash a reference
probe. Both scripts now reject an already loaded Expat before loading libraries;
reports record the interpreter and the empty initial Expat mapping.

```sh
taskset -c 7 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-external-value-lifecycle/probe.py --candidate /path/to/liboriole_expat.so --output /tmp/new-lifecycle.json
```

The relative-limit script uses this directory's frozen candidate and writes
`amplification-probe.json`:

```sh
taskset -c 7 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-external-value-lifecycle/amplification_probe.py
```

`source.json` hashes all candidate Rust sources, the patch, and frozen debug shared
library. `validation.json` hashes logs and probe reports. The original upstream
reference binary and baseline library paths/hashes are embedded in the reports.
