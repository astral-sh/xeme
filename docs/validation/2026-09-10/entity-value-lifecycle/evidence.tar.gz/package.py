from pathlib import Path
import hashlib,json,tarfile,shutil,collections
w=Path('/tmp/oriole-entity-lifecycle-integrated');d=Path('docs/validation/2026-09-10/entity-value-lifecycle');d.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((w/'source.json').read_text());api=json.loads((w/'upstream-api/results.json').read_text());old=json.loads(Path('/tmp/oriole-recycling-layout/upstream-api/results.json').read_text());before={(x['test'],x['context']):x['outcome'] for x in old['results']};changes=[x for x in api['results'] if before[x['test'],x['context']]!=x['outcome']];assert not changes and api['selection_complete'] and api['library_origin_verified'] and not api['timed_out'] and len(api['results'])==4740
r=json.loads((w/'lifecycle.json').read_text());keys=['statuses','errors','text','children'];assert len(r['rows'])==60 and all(all(x['results']['candidate'][k]==x['results']['reference'][k] for k in keys) for x in r['rows']);declarations=sum(x['results']['candidate']['declarations']!=x['results']['reference']['declarations'] for x in r['rows']);assert declarations==27
fine=json.loads((w/'amplification-probe.json').read_text());assert len(fine['rows'])==300 and fine['status_error_text_child_mismatches']==0
native=json.loads((w/'native.json').read_text());assert len(native['runs'])==6 and all(x['returncode']==0 for x in native['runs'])
summary={'library_sha256':s['library_sha256'],'rust_tests':s['rust_tests'],'lifecycle_cases':60,'amplification_cases':300,'status_error_text_child_mismatches':0,'failed_input_partial_declaration_differences':27,'exact_generated_cases':1518,'native_safety_runs':6,'allocation_scenarios_per_linkage':341,'upstream_api':{k:api[k] for k in ['passed','failed','selection_complete','library_origin_verified','timed_out']},'changed_api_outcomes_vs_storage_layer':changes};(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for n in ['HANDOFF.md','source.json','validation.json','candidate.patch']:
 shutil.copy2(Path('/tmp/oriole-external-value-lifecycle')/n,w/('isolated-'+n))
review={'scope':'Integrating-agent source review of the independent author patch, composed with boxed event payloads and attribute recycling. All runtime hunks applied without conflict; three new Rust test patterns adapted to boxed variants.','source_sha256':s['source_sha256'],'findings':[],'checks':['Only completed internal parameter declarations allocate an optional Shared<AtomicBool>; general/external/reserved entities do not.','Parameter children and merges retain shared flags; general-content copies clear them and allocate fresh flags for reserved parameter slots copied to empty values.','All five parameter-reference readers check the shared open flag before expanding, alongside active recursion checks.','Entity-count validation precedes new state allocation; structural and explicit atomic payload work charges remain bounded and actual selected-allocator live bytes remain tracked.','The external-value truncation branch marks the shared internal parameter entity open before dropping value frames; ordinary value expansions preserve their existing cleanup.','No unsafe runtime code or C ABI mutation is added. Exhaustive allocator tests cover early drops, precreated siblings, independent copies and terminal OOM.']};(w/'integration-review.json').write_text(json.dumps(review,indent=2)+'\n')
files={}
for p in sorted(w.rglob('*')):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 files[str(p.relative_to(w))]={'sha256':sha(p),'bytes':p.stat().st_size}
with tarfile.open(d/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n in files:t.add(w/n,arcname=n,recursive=False)
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==files[m.name]['sha256']
manifest={'archive_sha256':sha(d/'evidence.tar.gz'),'members':files};(d/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
(d/'README.md').write_text(f'''# External entity-value lifecycle

Expat's external value processor can leave an internal parameter entity open in its shared DTD. A later reference then fails as recursive, including through precreated siblings or after the first child is freed. The ordinary value processor closes its active entities; general-content DTD copies clear the open flags. The isolated handoff in the archive records the exact pinned Expat source locations.

We now retain that state in an optional selected-allocator shared atomic flag for completed internal parameter declarations. All five reference readers check it. General-content copies get fresh false state, reset clears it, and parameter children/merges share it. Existing declaration, work, live-allocation and relative amplification bounds remain enforced; ordinary general entities do not allocate this new state.

The integrated release library `{s['library_sha256']['liboriole_expat.so']}` passes **253 core/C-interface Rust checks**, strict affected-package Clippy, a 1,518-case exact generated replay and six native C ASan/UBSan suites with 341 injected allocation failures per linkage. C callers are sanitizer-instrumented; Rust is not. LSan is disabled and selected-allocation live counts are checked separately. Integrating-agent review found no blocker in the author patch or its composition with owned boxed callbacks and recycling.

All **60 lifecycle and 300 amplification configurations** now match Expat's status, nested error chain, text and child outcomes. The isolated baseline differed on 39 of the 60 lifecycle cases. Successful declarations match; 27 rejected cases still differ because Expat emits a partially built declaration before failure and Oriole omits it. This callback difference is retained explicitly. Probes use the pinned uv-managed Python with `-I -S` and reject a process with an already-loaded system Expat, avoiding symbol interposition.

The unchanged 4,740-configuration upstream matrix remains **4,003 passes and 737 failures**, with no changed outcomes, verified library origin and no crashes or timeouts. This regression corpus closes a substantive acceptance gap beyond the existing upstream matrix; the pass count alone did not reveal it. No performance or new full-PBS claim is made for this layer.

[evidence.tar.gz](evidence.tar.gz) retains source/build metadata, raw probes, matrix observations, logs, scope-limited reviews and the isolated handoff. ELF/static artifacts are excluded and identified by hash. [files.json](files.json) verifies every member and [summary.json](summary.json) gives compact counts. Archive SHA256: `{manifest['archive_sha256']}`.
''')
print(json.dumps({'tests':s['rust_tests'],'api':[api['passed'],api['failed']],'lifecycle':60,'amplification':300,'members':len(files),'archive_bytes':(d/'evidence.tar.gz').stat().st_size},indent=2))
