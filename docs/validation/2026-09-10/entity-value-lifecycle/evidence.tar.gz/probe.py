"""Pinned-library probes for persistent internal parameter entity open state."""
import argparse
import ctypes as c
import hashlib
import itertools
import json
import sys
from pathlib import Path

TEXT = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.c_int)
EXT = c.CFUNCTYPE(c.c_int, c.c_void_p, c.c_char_p, c.c_char_p, c.c_char_p, c.c_char_p)
DECL = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.c_int, c.c_char_p, c.c_int, c.c_char_p, c.c_char_p, c.c_char_p, c.c_char_p)


def check_initial_libraries():
    # A Python executable linked to a different system Expat can interpose its
    # symbols into the pinned reference library, even with ctypes RTLD_LOCAL.
    loaded = [line for line in Path('/proc/self/maps').read_text().splitlines()
              if line.rsplit('/', 1)[-1].startswith('libexpat.')]
    if loaded:
        raise RuntimeError('Use the pinned uv-managed Python with -I -S; Expat is already loaded: ' + repr(loaded))
    return loaded


def setup(path):
    lib = c.CDLL(path)
    for name, args, result in [
        ('XML_ParserCreate', [c.c_char_p], c.c_void_p),
        ('XML_ExternalEntityParserCreate', [c.c_void_p, c.c_char_p, c.c_char_p], c.c_void_p),
        ('XML_Parse', [c.c_void_p, c.c_char_p, c.c_int, c.c_int], c.c_int),
        ('XML_GetErrorCode', [c.c_void_p], c.c_int),
        ('XML_ParserFree', [c.c_void_p], None),
        ('XML_ParserReset', [c.c_void_p, c.c_char_p], c.c_ubyte),
        ('XML_SetParamEntityParsing', [c.c_void_p, c.c_int], c.c_int),
        ('XML_SetBillionLaughsAttackProtectionMaximumAmplification', [c.c_void_p, c.c_float], c.c_ubyte),
        ('XML_SetBillionLaughsAttackProtectionActivationThreshold', [c.c_void_p, c.c_ulonglong], c.c_ubyte),
        ('XML_SetCharacterDataHandler', [c.c_void_p, TEXT], None),
        ('XML_SetEntityDeclHandler', [c.c_void_p, DECL], None),
        ('XML_SetExternalEntityRefHandler', [c.c_void_p, EXT], None),
    ]:
        fn = getattr(lib, name)
        fn.argtypes = args
        fn.restype = result
    return lib


PREFIX = '<!ENTITY % a SYSTEM "v"><!ENTITY % b "B">'
CASES = {
    'single-truncates': (PREFIX + '<!ENTITY n "%a;">', {'v': 'L%b;R%b;'}, '&n;'),
    'same-value-later-external': (PREFIX + '<!ENTITY n "%a;%a;">', {'v': '%b;'}, '&n;'),
    'same-value-later-internal': (PREFIX + '<!ENTITY n "%a;%b;">', {'v': '%b;'}, '&n;'),
    'later-value-internal': (PREFIX + '<!ENTITY n "%a;"><!ENTITY m "%b;">', {'v': '%b;'}, '&n;&m;'),
    'later-value-external': (PREFIX + '<!ENTITY n "%a;"><!ENTITY m "%a;">', {'v': '%b;'}, '&n;&m;'),
    'later-declaration-fragment': (PREFIX.replace('\"B\"', '\"EMPTY\"') + '<!ENTITY n \"%a;\"><!ELEMENT r %b;>', {'v': '%b;'}, '&n;'),
    'later-conditional-header': (PREFIX.replace('\"B\"', '\"INCLUDE\"') + '<!ENTITY n \"%a;\"><![%b;[<!ELEMENT r EMPTY>]]>', {'v': '%b;'}, '&n;'),
    'later-dtd-reference': (PREFIX + '<!ENTITY n "%a;">%b;', {'v': '%b;'}, '&n;'),
    'nested-later-sibling': (PREFIX + '<!ENTITY % c SYSTEM "w"><!ENTITY n "%a;%c;">', {'v': '%c;', 'w': '%b;'}, '&n;'),
    'nested-later-value': (PREFIX + '<!ENTITY % c SYSTEM "w"><!ENTITY n "%a;"><!ENTITY m "%b;">', {'v': '%c;', 'w': '%b;'}, '&n;&m;'),
    'distinct-internal-entities': (PREFIX + '<!ENTITY % c "C"><!ENTITY % d SYSTEM "w"><!ENTITY n "%a;%d;">', {'v': '%b;', 'w': '%c;'}, '&n;'),
    'external-no-internal': (PREFIX + '<!ENTITY n "%a;%a;">', {'v': 'X'}, '&n;'),
    'empty-internal': ('<!ENTITY % a SYSTEM "v"><!ENTITY % b ""><!ENTITY n "%a;%b;">', {'v': '%b;'}, '&n;'),
    'internal-tail-not-evaluated': (PREFIX + '<!ENTITY % c "C"><!ENTITY n "%a;%c;">', {'v': '%b;%c;'}, '&n;'),
    'missing-truncates-without-opening': (PREFIX + '<!ENTITY n "%a;%b;">', {'v': '%missing;%b;'}, '&n;'),
    'general-copy-clears-open': (PREFIX + '<!ENTITY n "%a;"><!ENTITY g SYSTEM "g">', {'v': '%b;', 'g': '<x/>'}, '&g;'),
    'same-callback-precreated-siblings': (PREFIX + '<!ENTITY n "%a;">', {'v': '%b;'}, '&n;'),
    'same-callback-later-siblings': (PREFIX + '<!ENTITY n "%a;">', {'v': '%b;'}, '&n;'),
    'reset-clears-open': (PREFIX + '<!ENTITY n "%a;">', {'v': '%b;'}, '&n;'),
    'dtd-return-later-sibling': ('<!ENTITY % a SYSTEM "v"><!ENTITY n "%a;">', {'v': '%b;'}, '&n;'),
}


def run(lib, case, chunk, factor=100):
    dtd, external, body = CASES[case]
    external = dict(external, e=dtd)
    data = '<!DOCTYPE r SYSTEM "e"><r>' + body + '</r>'
    if case == 'dtd-return-later-sibling':
        data = '<!DOCTYPE r [<!ENTITY % b "B"><!ENTITY % e SYSTEM "e">%e;%b;]><r/>'
    parser = lib.XML_ParserCreate(None)
    assert parser
    errors, output, declarations, children = [], [], [], []
    counts = {}
    def feed(p, text, label):
        raw = text.encode()
        width = chunk or max(1, len(raw))
        for offset in range(0, max(1, len(raw)), width):
            piece = raw[offset:offset + width]
            status = lib.XML_Parse(p, piece, len(piece), offset + width >= len(raw))
            if status != 1:
                errors.append([label, lib.XML_GetErrorCode(p)])
                return 0
        return 1
    @TEXT
    def text(_, value, length):
        output.append(c.string_at(value, length).decode())
    @DECL
    def declaration(_, name, parameter, value, length, *_rest):
        declarations.append([name.decode(), parameter, None if value is None else c.string_at(value, length).decode()])
    @EXT
    def load(parent, context, _base, system, _public):
        name = system.decode()
        counts[name] = counts.get(name, 0) + 1
        assert counts[name] < 10
        siblings = 2 if name == 'v' and 'callback' in case else 1
        precreated = []
        if 'precreated' in case and name == 'v':
            precreated = [lib.XML_ExternalEntityParserCreate(parent, context, None) for _ in range(siblings)]
        result = 1
        for index in range(siblings):
            child = precreated[index] if precreated else lib.XML_ExternalEntityParserCreate(parent, context, None)
            assert child
            # A copied general-entity DTD must forget the open bit. A nested
            # parameter parser exposes that fact without changing content syntax.
            if name == 'g' and case == 'general-copy-clears-open':
                grandchild = lib.XML_ExternalEntityParserCreate(child, None, None)
                assert grandchild
                result = feed(grandchild, '<!ENTITY m "%b;">', 'g-dtd')
                lib.XML_ParserFree(grandchild)
            if result:
                result = feed(child, external[name], name)
            children.append([name, index, result])
            lib.XML_ParserFree(child)
            if not result:
                for unused in precreated[index + 1:]:
                    lib.XML_ParserFree(unused)
                break
        return result
    def configure():
        assert lib.XML_SetParamEntityParsing(parser, 2)
        # The old baseline has unsupported controls; its defaults also admit
        # these small documents. Record actual setter support separately.
        controls = [lib.XML_SetBillionLaughsAttackProtectionMaximumAmplification(parser, factor), lib.XML_SetBillionLaughsAttackProtectionActivationThreshold(parser, 0)]
        lib.XML_SetCharacterDataHandler(parser, text)
        lib.XML_SetEntityDeclHandler(parser, declaration)
        lib.XML_SetExternalEntityRefHandler(parser, load)
        return controls
    controls = configure()
    statuses = [feed(parser, data, 'root')]
    if case == 'reset-clears-open':
        assert lib.XML_ParserReset(parser, None)
        configure()
        external['e'] = '<!ENTITY % b "B"><!ENTITY m "%b;">'
        statuses.append(feed(parser, '<!DOCTYPE r SYSTEM "e"><r>&m;</r>', 'reset-root'))
    lib.XML_ParserFree(parser)
    return {'statuses': statuses, 'errors': errors, 'text': ''.join(output), 'declarations': declarations, 'children': children, 'controls': controls}


def main():
    cli = argparse.ArgumentParser()
    cli.add_argument('--candidate', default='/tmp/oriole-api-amplification/reviewed/liboriole_expat.so')
    cli.add_argument('--output', default='/tmp/oriole-entity-lifecycle-integrated/baseline-probe.json')
    args = cli.parse_args()
    paths = {'reference': '/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4', 'baseline': '/tmp/oriole-api-amplification/reviewed/liboriole_expat.so'}
    if args.candidate != paths['baseline']:
        paths['candidate'] = args.candidate
    preloaded = check_initial_libraries()
    libraries = {name: setup(path) for name, path in paths.items()}
    rows = []
    for case, chunk in itertools.product(CASES, [0, 1, 7]):
        results = {name: run(lib, case, chunk) for name, lib in libraries.items()}
        rows.append({'case': case, 'chunk': chunk, 'results': results})
    report = {'python': sys.executable, 'preloaded_expat': preloaded, 'libraries': {name: {'path': path, 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest()} for name, path in paths.items()}, 'cases': CASES, 'rows': rows}
    Path(args.output).write_text(json.dumps(report, indent=2) + '\n')
    for row in rows:
        if row['chunk'] == 0:
            print(row['case'], {name: (result['statuses'], result['errors'], result['text']) for name, result in row['results'].items()})


if __name__ == '__main__':
    main()
