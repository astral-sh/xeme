"""Bounded source/value membership oracle using managed Python without system Expat."""
import ctypes as c, gzip, hashlib, itertools, json, sys
from pathlib import Path
assert not any(line.rsplit('/',1)[-1].startswith('libexpat.') for line in Path('/proc/self/maps').read_text().splitlines())
callback_errors=[]
sys.unraisablehook=lambda event:callback_errors.append(str(event.exc_value))
OUT=Path('/tmp/oriole-event-slot-final/active-oracles')
source=Path('/tmp/oriole-custom-alias-external-source.py').read_text()
source=source.replace("b'alias'",'PROTOCOL').replace('lib.XML_SetParamEntityParsing(p,2)','lib.XML_SetParamEntityParsing(p,MODE)\n    lib.XML_SetReparseDeferralEnabled(p,DEFER)')
source=source.replace('    p=lib.XML_ParserCreate(PROTOCOL);assert p','    p=lib.XML_ParserCreateNS(PROTOCOL,b\'|\') if NS else lib.XML_ParserCreate(PROTOCOL);assert p')
source += '''\nlib.XML_ParserCreateNS.argtypes=[c.c_char_p,c.c_char]\nlib.XML_ParserCreateNS.restype=c.c_void_p\nlib.XML_SetReparseDeferralEnabled.argtypes=[c.c_void_p,c.c_ubyte]\n'''
(OUT/'oracle-source.py').write_text(source)
paths={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','baseline':'/tmp/oriole-event-slot-final/control.so','candidate':sys.argv[1]}
envs={}
for name,path in paths.items():
 env={};exec(compile(source.replace(paths['reference'],path),name,'exec'),env);envs[name]=env

def cases():
 for name,decl,body in [
  ('general-reuse',"<!ENTITY a 'X'><!ENTITY b '&a;&a;'>",'<r>&b;&a;&b;</r>'),
  ('general-cycle',"<!ENTITY a '&b;'><!ENTITY b '&a;'>",'<r>&a;</r>'),
  ('general-unbalanced',"<!ENTITY a '<x>'>",'<r>&a;</r>'),
  ('general-empty',"<!ENTITY a ''><!ENTITY b '&a;Y&a;'>",'<r>&b;&b;</r>'),
  ('parameter-cycle',"<!ENTITY % a '&#37;b;'><!ENTITY % b '&#37;a;'>%a;",'<r/>'),
  ('parameter-reuse',"<!ENTITY % a '<!--X-->'><!ENTITY % b '&#37;a;&#37;a;'>%b;%a;%b;",'<r/>'),
  ('value-cycle',"<!ENTITY % a '&#37;b;'><!ENTITY % b '&#37;a;'><!ENTITY % d \"<!ENTITY g '&#37;a;'>\">%d;",'<r/>'),
  ('value-reuse',"<!ENTITY % a 'X'><!ENTITY % b '&#37;a;&#37;a;'><!ENTITY % d \"<!ENTITY g '&#37;b;&#37;a;'>\">%d;",'<r>&g;</r>'),
 ]:yield name,f'<!DOCTYPE r [{decl}]>{body}',{}
 for depth in [1,8,24,33]:
  decl="<!ENTITY s0 'é'>"+''.join(f"<!ENTITY s{i} '&s{i-1};'>" for i in range(1,depth))
  yield f'content-depth-{depth}',f'<!DOCTYPE r [{decl}]><r>&s{depth-1};&s0;</r>',{}
  decl="<!ENTITY % s0 'é'>"+''.join(f"<!ENTITY % s{i} '&#37;s{i-1};'>" for i in range(1,depth))
  yield f'value-depth-{depth}',f'''<!DOCTYPE r [{decl}<!ENTITY % d "<!ENTITY g '&#37;s{depth-1};&#37;s0;'>">%d;]><r>&g;</r>''',{}
  for owned in [False,True]:
   dtd=decl+('''<!ENTITY % p SYSTEM 'empty'>''' if owned else '')+f'''<!ENTITY g '{'%p;' if owned else ''}%s{depth-1};%s0;'>'''
   yield f'external-value-{depth}-{owned}',"<!DOCTYPE r SYSTEM 'dtd'><r>&g;</r>",{'dtd':dtd,'empty':''}
 for kind,leaf,tail in [('header','INCLUDE[',"<!ENTITY g 'V'>]]>"),('grammar','a CDATA &#34;A&#34;',">"),('literal','&#34;V&#34;',">")]:
  depth=18;decl=f"<!ENTITY % s0 '{leaf}'>"+''.join(f"<!ENTITY % s{i} '&#37;s{i-1};'>" for i in range(1,depth))
  prefix={'header':'<![','grammar':'<!ATTLIST r ','literal':'<!ENTITY g '}[kind]
  yield kind+'-provenance',"<!DOCTYPE r SYSTEM 'dtd'><r/>",{'dtd':decl+prefix+f'%s{depth-1};'+tail}
 for name,dtd,p in [
  ('sticky',"<!ENTITY % p SYSTEM 'p'><!ENTITY % i 'I'><!ENTITY g '%p;'><!ENTITY later '%i;'>",'%i;'),
  ('sticky-prefix',"<!ENTITY % p SYSTEM 'p'><!ENTITY % i 'I'><!ENTITY g 'L%p;R'><!ENTITY later '%i;'>",'X%i;Y'),
  ('missing',"<!ENTITY % p SYSTEM 'p'><!ENTITY g 'L%p;R'><!ENTITY after 'A'>",'%missing;'),
  ('inherited-cycle',"<!ENTITY % p SYSTEM 'p'><![%p;INCLUDE[<!ENTITY g 'G'>]]>",'%p;'),
  ('grammar-gap',"<!ENTITY % p SYSTEM 'p'><!ATTLIST r a CDATA 'A' %p; b CDATA 'B'>",''),
 ]:yield name,"<!DOCTYPE r SYSTEM 'dtd'><r/>",{'dtd':dtd,'p':p}

rows=[];inputs={};count=0;new=0;reference_outcomes=0;reference_events=0
for (name,doc,resources),encoding,width,default,ns,mode,defer in itertools.product(cases(),['utf-8','utf-16-le','utf-16-be'],[0,1,7],[False,True],[False,True],[0,2],[False,True]):
 def encoded(text):
  prefix={'utf-8':b'','utf-16-le':b'\xff\xfe','utf-16-be':b'\xfe\xff'}[encoding]
  return prefix+text.encode(encoding)
 data=encoded(doc);loaded={n:encoded(v) if v else b'' for n,v in resources.items()}
 results={}
 for name2,env in envs.items():
  env.update(PROTOCOL=None,NS=ns,MODE=mode,DEFER=defer)
  results[name2]=env['parse'](data,width,default,loaded)
 a,b,d=results.values();count+=1;changed=b!=d;outcome=(a['status'],a['error'])!=(d['status'],d['error']);events=a['status']==d['status']==1 and a['events']!=d['events']
 new+=changed;reference_outcomes+=outcome;reference_events+=events
 inputs[name]={'document':doc,'resources':resources}
 if changed or outcome or events:rows.append({'case':name,'encoding':encoding,'width':width,'default':default,'namespaces':ns,'mode':mode,'deferral':defer,'results':results})
# Custom-decoded names and references: the active index preserves both old views.
custom_count=0
for scalar in [37,38,65,233]:
 for template in [b"<!DOCTYPE r [<!ENTITY @@ 'X'>]><r>&@@;&@@;</r>",b"<!DOCTYPE r [<!ENTITY @@ '&@@;'>]><r>&@@;</r>",b"<!DOCTYPE r [<!ENTITY % @@ '&#37;@@;'>%@@;]><r/>"]:
  for width,default in itertools.product([0,1,7],[False,True]):
   data=template.replace(b'@@',bytes([128,scalar]));results={}
   for n,e in envs.items():e.update(PROTOCOL=b'alias',NS=False,MODE=2,DEFER=True);results[n]=e['parse'](data,width,default,{})
   count+=1;custom_count+=1;a,b,d=results.values();changed=b!=d;new+=changed
   outcome=(a['status'],a['error'])!=(d['status'],d['error']);events=a['status']==d['status']==1 and a['events']!=d['events'];reference_outcomes+=outcome;reference_events+=events
   if changed or outcome or events:rows.append({'case':'custom-name','input':data.hex(),'width':width,'default':default,'results':results})
report={'cases':count,'custom_cases':custom_count,'baseline_differences':new,'reference_outcome_differences':reference_outcomes,'reference_successful_event_differences':reference_events,'libraries':{n:{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for n,p in paths.items()},'inputs':inputs,'differences':rows}
(OUT/'oracle.json.gz').write_bytes(gzip.compress(json.dumps(report,indent=2).encode()+b'\n',mtime=0))
print({k:v for k,v in report.items() if k not in ('inputs','differences')})
assert not callback_errors,callback_errors
assert new==0,'candidate changed baseline result or callback observations'
