from pathlib import Path
import subprocess,json,gzip,hashlib
root=Path('/tmp/oriole-event-slot-final/aliases');root.mkdir(exist_ok=True)
control='/tmp/oriole-event-slot-final/control.so';candidate='/tmp/oriole-event-slot-final/liboriole_expat.so'
reference='/home/dev-user/.cache/oriole/expat-build/libexpat.so'
base=Path('/tmp/oriole-custom-alias-probe.py').read_text().replace(reference,control)
base="from pathlib import Path\nassert not any('libexpat.' in line for line in Path('/proc/self/maps').read_text().splitlines())\n"+base
(root/'probe.py').write_text(base)
rows=[]
for name,output in [('full-events','full-events-comparison'),('external-semantic-compare','external-semantic-comparison')]:
 source=Path('/tmp/oriole-custom-alias-'+name+'.py').read_text()
 source=source.replace('/tmp/oriole-custom-alias-probe.py',str(root/'probe.py'))
 source=source.replace('/tmp/oriole-custom-alias-full-events-source.py',str(root/'full-events-source.py'))
 source=source.replace('/tmp/oriole-custom-alias-external-source.py',str(root/'external-source.py'))
 source=source.replace('/tmp/oriole-custom-alias-'+output+'.json',str(root/(output+'.json')))
 source=source.replace(reference,control).replace('/home/dev-user/.cache/oriole/api-followup-target/release/liboriole_expat.so',candidate).replace('/tmp/oriole-custom-alias-runtime/liboriole_expat.so',candidate)
 path=root/(name+'.py');path.write_text(source)
 result=subprocess.run(['taskset','-c','4','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3','-I','-S',str(path)],capture_output=True,text=True,timeout=300)
 (root/(name+'.log')).write_text(result.stdout+result.stderr);assert result.returncode==0,result.stderr
 p=root/(output+'.json');raw=p.read_bytes();data=json.loads(raw)
 (root/(output+'.json.gz')).write_bytes(gzip.compress(raw,mtime=0));p.unlink()
 row={'case':name,'comparisons':data['cases'],'all_differences':len(data['differences']),'script_sha256':hashlib.sha256(path.read_bytes()).hexdigest()};rows.append(row)
 print(row,flush=True);assert not data['differences'],data['differences'][:1]
(root/'summary.json').write_text(json.dumps({'control_sha256':hashlib.sha256(Path(control).read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(Path(candidate).read_bytes()).hexdigest(),'rows':rows},indent=2)+'\n')
