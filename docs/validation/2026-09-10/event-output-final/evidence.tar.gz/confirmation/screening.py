import hashlib,json,random,statistics,subprocess
from pathlib import Path
root=Path('/tmp/oriole-event-slot-confirmation')
repo=Path('/home/dev-user/code/oss/oriole')
manifest=repo/'benchmarks/projects/corpus-manifest.json'
fixtures={p['name']:(manifest.parent/next(f['path'] for f in p['files'] if f['role']=='input')).resolve() for p in json.loads(manifest.read_text())['projects']}
rare=root/'rare-declarations.xml'
rare.write_text('<!DOCTYPE r [\n'+''.join(f'<!ENTITY e{i} "v"><!ATTLIST r a{i} CDATA #IMPLIED><!NOTATION n{i} SYSTEM "x">\n' for i in range(2000))+']><r/>')
fixtures['generated-rare-declarations']=rare
fixtures['generated-entities']=Path('/tmp/oriole-grammar-bench-plain/entities.xml')
libraries={'control':root/'control.so','candidate':root/'liboriole_expat.so','expat':Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4')}
driver=Path('/tmp/oriole-grammar-bench-plain/native-driver')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'scope':'Screening candidate/control/Expat on all six pinned projects and two generated adverse fixtures; CPU0, shared host. Five randomized pairs; workload counts fixed before this cohort from reference speeds to lengthen the short process batches: Vulkan7, Wayland64, Maven128, Batik512, GTK/DocBook256, generated32; one warmup. Seed20260911. This confirmation follows sign-changing short Batik observations; all prior data is retained. This is native callback-driver throughput, not actual project process timing.','pairs':5,'iterations':{'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32},'rows':[],'hashes_before':{str(p):sha(p) for p in [manifest,driver,*fixtures.values(),*libraries.values()]}}
rng=random.Random(20260911)
for chunk in [4096,65536]:
 for name,fixture,namespaces in [(name,path,False) for name,path in fixtures.items()] + [(name,path,True) for name,path in fixtures.items() if not name.startswith("generated-")]:
  ratios=[]
  for pair in range(report['pairs']):
   order=list(libraries);rng.shuffle(order)
   row={'workload':name,'chunk':chunk,'namespaces':namespaces,'pair':pair,'order':order,'processes':{}}
   for label in order:
    command=['taskset','-c','0',str(driver),str(libraries[label]),str(fixture),str(chunk),str(report['iterations'][name])]+(['namespaces'] if namespaces else [])
    result=subprocess.run(command,capture_output=True,text=True,timeout=45)
    process={'command':command,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr};row['processes'][label]=process
    assert result.returncode==0,process
    samples=json.loads(result.stdout)['samples']
    process['median_seconds']=statistics.median(s['seconds'] for s in samples if not s['warmup'])
    process['observations']=list({(s['hash'],s['elements'],s['text_bytes']) for s in samples})
   assert row['processes']['control']['observations']==row['processes']['candidate']['observations']==row['processes']['expat']['observations'],row
   row['expat_over_candidate']=row['processes']['expat']['median_seconds']/row['processes']['candidate']['median_seconds']
   row['speedup']=row['processes']['control']['median_seconds']/row['processes']['candidate']['median_seconds'];ratios.append(row['speedup']);report['rows'].append(row)
   (root/'screening.json').write_text(json.dumps(report,indent=2)+'\n')
  print(chunk,name,namespaces,statistics.median(ratios),min(ratios),max(ratios),flush=True)
report['hashes_after']={p:sha(Path(p)) for p in report['hashes_before']}
assert report['hashes_before']==report['hashes_after']
report['status']='passed'
(root/'screening.json').write_text(json.dumps(report,indent=2)+'\n')
