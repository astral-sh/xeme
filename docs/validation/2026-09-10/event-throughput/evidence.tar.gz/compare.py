from pathlib import Path
import hashlib,json,os,random,statistics,subprocess,time
root=Path('/tmp/oriole-event-throughput')
libs={'baseline':Path('/tmp/oriole-grammar-combined-source/liboriole_expat.so'), 'expat':Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4')}
libs.update({name:root/name/'liboriole_expat.so' for name in ('inline','always','names','strings')})
inputs={name:Path('/tmp/oriole-grammar-bench-plain')/(name+'.xml') for name in ('elements','text','entities','namespaces')}
inputs['wayland']=Path('/tmp/oriole-real-project-bench/corpus/wayland/wayland.xml')
inputs['vulkan']=Path('/tmp/oriole-real-project-bench/corpus/vulkan/vk.xml')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
report={'started':time.time(),'affinity':[0],'iterations':5,'pairs':5,'seed':20260911,'chunk_size':4096,'namespace_processing':False,'libraries':{k:{'path':str(v),'sha256':sha(v)} for k,v in libs.items()},'inputs':{k:{'path':str(v),'sha256':sha(v)} for k,v in inputs.items()},'samples':[]}
rng=random.Random(report['seed']);os.sched_setaffinity(0,{0})
for name,xml in inputs.items():
 expected=None
 for pair in range(report['pairs']):
  order=list(libs);rng.shuffle(order)
  for label in order:
   command=['/tmp/oriole-grammar-bench-plain/native-driver',str(libs[label]),str(xml),'4096',str(report['iterations'])]
   output=json.loads(subprocess.check_output(command,text=True,timeout=90))
   for sample in output['samples']:
    signature=tuple(sample[key] for key in ('hash','elements','text_bytes'))
    if expected is None:expected=signature
    assert signature==expected,(name,label,signature,expected)
   report['samples'].append({'input':name,'pair':pair,'label':label,'command':command,'output':output})
 (root/'compare.json').write_text(json.dumps(report,indent=2)+'\n')
 medians={label:statistics.median(s['seconds'] for r in report['samples'] if r['input']==name and r['label']==label for s in r['output']['samples'] if not s['warmup']) for label in libs}
 print(name,{k:round(v*1000,3) for k,v in medians.items()},flush=True)
report['completed']=time.time()
assert all(sha(libs[k])==v['sha256'] for k,v in report['libraries'].items())
report['status']='passed'
(root/'compare.json').write_text(json.dumps(report,indent=2)+'\n')
