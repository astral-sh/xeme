# External parameter entities between declaration tokens

This patch lets an external parameter reference load a separate DTD while its
parent declaration is unfinished. The parent resumes its existing grammar after
child declarations are imported. Complete attributes and declarations are
reported before the external callback when Expat commits them at that point.
External child text never becomes literal parent grammar.

The patch is based on the accepted internal-delimiter snapshot e3190bd5. Its
frozen candidate library is c7cb6283241ca34835795d31a2cbb6bad8b1f63f599f4f324b009f4dc39edbd7.
`source.json` records all 11 changed files, their base/candidate hashes, and the
patch hash. A zero-fuzz patch dry-run succeeds against that base. Root's later
encoding, foreign-DTD, namespace/version, and C API changes must be preserved;
this patch does not change `encoding.rs`. Two root test-context conflicts are
resolved by inserting the new allocation workload and appending the two FFI
regressions while retaining the later tests.

## Implementation and resource behavior

- A monotonic grammar cursor processes complete lexical prefixes. It emits one
  completed semantic unit at a time and caches lookahead; lexical tokens and
  quotes remain within their original source. The existing declaration collector
  retains parent frames while external requests are outstanding.
- Owned continuation state and requests are restored before callback dispatch.
  Child initialization/read acknowledgement, skipped declarations, inherited
  recursion/depth, and early callback commitments use the existing family state.
- Entity names are reserved before loading children. Parsed public/system IDs
  become visible at their grammar roles. A child cannot replace the reserved
  first declaration; a non-NULL general-child context clones an uninitialized
  no-system-ID slot as empty text, matching Expat.
- Enumeration callback types capture members only while an ATTLIST handler is
  installed. Full types still govern stored defaults. Notation name capture
  likewise reflects handler availability when that name is parsed.
- Grammar stack growth, captured strings, raw projection and request storage use
  the selected allocator and shared expansion accounting. The cursor stack has
  an explicit bounded geometric-allocation charge. The safe core adds no unsafe
  code, global mutex, I/O, or handler-setter allocation.
- Undefined general entities in default attribute values use the existing
  document-versus-external/source-context predicate. External DTD and permitted
  internal-PE defaults can contribute empty text; document content attributes
  keep their stricter declaration requirement.

## Validation on the frozen candidate

| Check | Result |
| --- | --- |
| Core and C adapter tests, including allocator fault sweep and callback lifetime/stop tests | 209 passed |
| Formatting and strict scoped Clippy | Passed |
| Independent final UTF8/UTF16LE/UTF16BE positive matrix, every byte width | 8,254 cases; zero rejection, outcome, or normalized callback differences |
| Independent pure grammar cursor | 8 standalone tests, strict Clippy, and 4,500 acceptance probes passed |
| Broad declaration grammar/mode/handler matrix | 4,656 cases; zero outcome or successful normalized-event differences |
| Commit ordering and reserved slot behavior | 512 cases; exact normalized comparisons |
| Enumeration toggles, general handler toggles, parsed reserved IDs | 2,628 cases; exact normalized comparisons |
| Undefined-default context controls | 246 cases; zero outcome differences; 73 outcome fixes versus e319; zero new jointly-successful event differences |
| Earlier delimiter/composition cases | 1,242 cases; 144 outcome fixes; zero new outcome or successful-event differences |
| Earlier conditional-header cases | 1,836 + 576 + 54 cases; zero new differences |
| Five targeted W3C required-accept descriptors, widths 1/7/4096 | 15/15 accepted, matching Expat; e319 accepted 12/15 |

The matrices overlap and are reported separately. Outcomes include parent and
child status/error codes. Event comparisons normalize adjacent Default chunks;
they do not claim byte-for-byte callback fragmentation or complete position
compatibility. Reference and candidate observations and generators are retained
under `evidence/` and `reference/`, with original paths and hashes in
`evidence-provenance.json`. The development matrix is retained separately from
final results.

The pinned reference is Expat 2.8.4, revision
12cf0b1f25f026a022fe728ad8f7e3d017285b80, library SHA256
7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478.
The W3C check uses the previously reviewed local-only harness and pinned mirror;
it checks acceptance requirements for a nonvalidating parser, without canonical
output comparison.

## Retained differences and further gates

Twelve broad-matrix failed inputs retain missing partial Default callbacks after
malformed content-model punctuation. The undefined-default matrices retain 28
successful observations of an existing root internal-subset closing-bracket
Default callback ordering difference, plus four failed-input partial-callback
observations. The older header matrix retains 44 external-DTD child lexical
error-code observations; the older composition matrix retains 98 observations
within its existing diagnostic scope. None is newly introduced in the compared
baseline-success scope.

Root reviewed reservation/ID commits, raw mapping, enumeration capture, child
slot cloning, and C setter/reset integration without finding a blocker. Its
specific source review is retained in `root-review.json`. Independent cursor and
final UTF-16/source reviews likewise found no blocker; their exact source and
artifact manifests are retained under `independent/`.

A fresh combined sanitizer campaign and full consumer suite are integration
gates owned by root; this isolated handoff does not claim those campaigns or a
new performance benchmark. The separate marked `value_family` fuzz extension
adds grammar templates while preserving old corpus interpretation.
