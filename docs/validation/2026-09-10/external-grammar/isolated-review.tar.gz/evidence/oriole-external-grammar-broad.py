from pathlib import Path
import json,gzip,hashlib,itertools
base=Path('/tmp/oriole-external-grammar-review')
source=(base/'name_reservation.py').read_text().split("if __name__")[0]
libs={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','candidate':'/home/dev-user/.cache/oriole/external-grammar-target/debug/liboriole_expat.so'}
ns={}
for label,lib in libs.items():
 n={};exec(source.replace(libs['reference'],lib),n);ns[label]=n
cases=[]
masks=[0,1,2,4,8,16,32,63]
for name,body in ns['reference']['CASES'].items():
 for action,handlers,standalone,width in itertools.product(['empty','skip'],masks,[None,'yes'],[0,1,7]):
  for toggle in [None,32,63]:cases.append((name,dict(body=body,action=action,handlers=handlers,standalone=standalone,width=width,toggle=toggle)))
extra=[
 ('model-open',"<!ELEMENT r (%p;a|b)>",b''),
 ('model-nested',"<!ELEMENT r (a|(%p;b,c))>",b''),
 ('model-separator',"<!ELEMENT r (a%p;|b)>",b''),
 ('model-group',"<!ELEMENT r (a|b)%p;>",b''),
 ('model-bad-repetition',"<!ELEMENT r (a|b) %p;*>",b''),
 ('enum',"<!ATTLIST r a (x|%p;y) 'x'>",b''),
 ('notation-enum',"<!ATTLIST r a NOTATION (%p;x|y) #IMPLIED>",b''),
 ('default-fixed',"<!ATTLIST r a CDATA #FIXED %p; 'x'>",b''),
 ('external-public',"<!ENTITY e PUBLIC 'p' %p; 's'>",b''),
 ('external-ndata',"<!ENTITY e SYSTEM 's' %p; NDATA n>",b''),
 ('ndata-name',"<!ENTITY e SYSTEM 's' NDATA %p; n>",b''),
 ('public-system',"<!NOTATION n PUBLIC 'p' %p; 's'>",b''),
 ('value-first',"<!ENTITY % v SYSTEM 'v'><!ENTITY e 'L%v;R' %p;>",b'X'),
 ('value-second',"<!ENTITY % v SYSTEM 'v'><!ENTITY e %p; 'L%v;R' %p;>",b''),
 ('duplicate-value',"<!ENTITY % v SYSTEM 'v'><!ENTITY e 'OLD'><!ENTITY e %p; 'L%v;R' %p;>",b''),
 ('import-default',"<!ATTLIST r a CDATA %p; '&x;'>",b"<!ENTITY x 'X'>"),
 ('import-literal',"<!ENTITY e %p; %literal;>",b'''<!ENTITY % literal "'X'">'''),
 ('import-tail',"<!ELEMENT r EMPTY %p; %tail; 'Z'>",b'''<!ENTITY % tail "><!ENTITY z ">'''),
 ('import-entity',"<!ENTITY e %p; 'P'>",b"<!ENTITY e 'C'>"),
 ('parameter-import-entity',"<!ENTITY % e %p; 'P'><!ENTITY check '%e;'>",b"<!ENTITY % e 'C'><!ENTITY childcheck '%e;'>"),
 ('malformed-child',"<!ATTLIST r a CDATA %p; 'X'>",b'EMPTY'),
 ('child-complete',"<!ATTLIST r a CDATA %p; 'X'>",b"<!ENTITY child 'C'>"),
 ('child-recursion',"<!ATTLIST r a CDATA %p; 'X'>",b'%p;'),
 ('missing-child',"<!ATTLIST r a CDATA 'A' %p; b CDATA 'B'>",b'%missing;'),
 ('many-children',"<!ATTLIST r %p; a %p; CDATA %p; 'A' %p; b CDATA %p; 'B' %p;>",b''),
 ('unicode',"<!ATTLIST ré attré %p; (xé|yé) 'xé'><!ELEMENT ré (xé|%p;yé)>",b''),
]
for name,body,payload in extra:
 for action,handlers,standalone,width in itertools.product(['empty','skip'],[32,63],[None,'yes'],[0,1,7]):
  cases.append((name,dict(body=body,action=action,handlers=handlers,standalone=standalone,width=width,toggle=None,child_data=payload)))
def norm(r):
 out=[]
 for e in r['events']:
  if out and e[1]=='default'and out[-1][:2]==e[:2]:out[-1][2]+=e[2]
  else:out.append(e.copy())
 return out
def outcome(r):return [r['status'],r['error'],r['children']]
rows=[];diff=[]
for i,(name,kw) in enumerate(cases):
 obs={label:n['probe'](**kw) for label,n in ns.items()};r=obs['reference'];c=obs['candidate'];rows.append({'name':name,**obs})
 if outcome(r)!=outcome(c)or norm(r)!=norm(c):diff.append({'index':i,'name':name,'outcome':outcome(r)!=outcome(c),'success_events':r['status']==c['status']==1 and norm(r)!=norm(c),**obs})
 if i%500==0:print(i,'differences',len(diff),flush=True)
with gzip.open('/tmp/oriole-external-grammar-broad-cases.json.gz','wt')as f:json.dump(rows,f)
report={'libraries':{label:{'path':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()}for label,path in libs.items()},'count':len(cases),'outcomes':sum(x['outcome']for x in diff),'success_events':sum(x['success_events']for x in diff),'differences':diff}
Path('/tmp/oriole-external-grammar-broad.json').write_text(json.dumps(report,indent=2))
print('FINAL',len(cases),len(diff),report['outcomes'],report['success_events'],flush=True)
