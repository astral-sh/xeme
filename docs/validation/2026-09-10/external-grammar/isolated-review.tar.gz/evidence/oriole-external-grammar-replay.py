from pathlib import Path
import json,gzip,hashlib,sys
lib='/home/dev-user/.cache/oriole/external-grammar-target/debug/liboriole_expat.so'
base=Path('/tmp/oriole-external-grammar-review')
def events(r):
 out=[]
 for e in r['events']:
  if out and e[1]=='default' and out[-1][:2]==e[:2]:out[-1][2]+=e[2]
  else:out.append(e.copy())
 return out
reports={}
for stem in ('commit-order','name-reservation','name-reservation-unread','parameter-reservation'):
 filename={'commit-order':'commit_order','name-reservation':'name_reservation','name-reservation-unread':'name_reservation_unread','parameter-reservation':'parameter_reservation'}[stem]
 source=(base/(filename+'.py')).read_text().split("if __name__")[0]
 ns={};exec(source.replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so',lib),ns)
 refs=json.loads((base/(stem+'.json')).read_text())['rows'];rows=[];diff=[]
 for i,r in enumerate(refs):
  kw={k:r[k]for k in ('body','action','handlers','standalone','width','toggle')if k in r}
  if 'payload'in r:kw['child_data']=r['payload'].encode()
  if stem=='parameter-reservation':
   # Specialized interface below.
   import inspect
   kw={k:r[k]for k in inspect.signature(ns['probe']).parameters if k in r}
   if 'payload'in r:kw['child_data']=r['payload'].encode()
  c=ns['probe'](**kw);rows.append(c)
  if [r['status'],r['error'],r['children']] != [c['status'],c['error'],c['children']]or events(r)!=events(c):
   diff.append({'index':i,'reference':r,'candidate':c})
 reports[stem]={'count':len(rows),'differences':diff,'outcomes':sum([r['status'],r['error'],r['children']] != [c['status'],c['error'],c['children']]for r,c in zip(refs,rows))}
 print(stem,len(rows),'diff',len(diff),'outcome',reports[stem]['outcomes'],flush=True)
 with gzip.open('/tmp/oriole-external-grammar-'+stem+'-cases.json.gz','wt')as f:json.dump(rows,f)
Path('/tmp/oriole-external-grammar-replay.json').write_text(json.dumps(reports,indent=2))
