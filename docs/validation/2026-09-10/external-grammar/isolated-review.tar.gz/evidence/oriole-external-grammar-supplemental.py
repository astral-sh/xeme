from pathlib import Path
import gzip,json,hashlib
base=Path('/tmp/oriole-external-grammar-review')
lib='/home/dev-user/.cache/oriole/external-grammar-target/debug/liboriole_expat.so'
helper=Path('/tmp/oriole-external-grammar-commit-helper.py')
helper.write_text((base/'commit_order.py').read_text().replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so',lib))
sets=[('enum-toggle','enum_toggle.py'),('handler-order','handler_order.py'),('reserved-identifiers','reserved_identifiers.py'),('undefined-default','undefined_default.py'),('undefined-default-controls','undefined_default_controls.py')]
summary={}
for name,script in sets:
 original=base/(name+('.json.gz'if name in ['enum-toggle','handler-order']else '.json'))
 out=Path('/tmp/oriole-external-grammar-'+name+original.suffix)
 code=(base/script).read_text().replace('/tmp/oriole-external-grammar-review/commit_order.py',str(helper)).replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so',lib).replace(str(original),str(out))
 exec(code,{'__name__':'__main__'})
 read=lambda p:json.load(gzip.open(p,'rt'))if p.suffix=='.gz'else json.loads(p.read_text())
 refs=read(original)['rows'];cands=read(out)['rows']
 def norm(r):
  result=[]
  for e in r['events']:
   if result and ((len(e)>2 and e[1]=='default')or (len(e)==2 and e[0]=='default')) and result[-1][:-1]==e[:-1]:result[-1][-1]+=e[-1]
   else:result.append(e.copy())
  return result
 diffs=[]
 for i,(r,c) in enumerate(zip(refs,cands)):
  if'result'in r:r=r['result'];c=c['result']
  outcome=lambda x:[x['status'],x['error'],x['children']]
  if outcome(r)!=outcome(c)or norm(r)!=norm(c):diffs.append({'index':i,'outcome':outcome(r)!=outcome(c),'successful_events':r['status']==c['status']==1 and norm(r)!=norm(c),'reference':r,'candidate':c})
 summary[name]={'count':len(refs),'outcomes':sum(d['outcome']for d in diffs),'successful_events':sum(d['successful_events']for d in diffs),'differences':diffs}
 print('SUMMARY',name,len(refs),summary[name]['outcomes'],summary[name]['successful_events'],len(diffs),flush=True)
Path('/tmp/oriole-external-grammar-supplemental.json').write_text(json.dumps({'library':lib,'sha256':hashlib.sha256(Path(lib).read_bytes()).hexdigest(),'collections':summary},indent=2))
