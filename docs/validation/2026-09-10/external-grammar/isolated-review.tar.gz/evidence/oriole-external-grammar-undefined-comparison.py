from pathlib import Path
import json
root=Path('/tmp/oriole-external-grammar-review')
def normalized(row):
 row=row.get('result',row);events=[]
 for event in row['events']:
  if events and ((len(event)>2 and event[1]=='default')or(len(event)==2 and event[0]=='default')) and events[-1][:-1]==event[:-1]:events[-1][-1]+=event[-1]
  else:events.append(event.copy())
 return dict(status=row['status'],error=row['error'],children=row['children'],events=events)
def outcome(row):return [row['status'],row['error'],row['children']]
report={}
for group in ['undefined-default','undefined-default-controls']:
 paths={'reference':root/(group+'.json'),'baseline':Path('/tmp/oriole-external-grammar-baseline-'+group+'.json'),'candidate':Path('/tmp/oriole-external-grammar-'+group+'.json')}
 values={label:[normalized(row)for row in json.loads(path.read_text())['rows']]for label,path in paths.items()}
 rows=[]
 for index,(r,b,c)in enumerate(zip(values['reference'],values['baseline'],values['candidate'])):
  rows.append(dict(index=index,fixed_outcome=outcome(r)!=outcome(b)and outcome(r)==outcome(c),new_outcome=outcome(r)==outcome(b)and outcome(r)!=outcome(c),new_successful_events=r['status']==b['status']==c['status']==1 and r['events']==b['events']and r['events']!=c['events'],remaining_successful_events=r['status']==c['status']==1 and r['events']!=c['events']))
 report[group]={'cases':len(rows),**{key:sum(row[key]for row in rows)for key in ['fixed_outcome','new_outcome','new_successful_events','remaining_successful_events']},'remaining_successful_indices':[row['index']for row in rows if row['remaining_successful_events']]}
Path('/tmp/oriole-external-grammar-undefined-comparison.json').write_text(json.dumps({'collections':report,'classification':'Remaining successful differences are the pre-existing root internal-subset closing bracket Default callback occurring after the external subset callback; four controls also retain failed-input partial callbacks.'},indent=2)+'\n')
print(json.dumps(report))
