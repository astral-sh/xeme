from pathlib import Path
import importlib.util,json,hashlib
spec=importlib.util.spec_from_file_location('w3c','/tmp/oriole-w3c-audit.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ids={'invalid--005','invalid--006','invalid-not-sa-022','valid-not-sa-003','rmt-e2e-14'}
cases=[c for c in json.load(open('/tmp/oriole-w3c-audit/catalog.json'))if c['ID']in ids]
rows=[]
for label,path in [('reference','/home/dev-user/.cache/oriole/expat-build/libexpat.so'),('baseline','/home/dev-user/.cache/oriole/dtd-composition-target/debug/liboriole_expat.so'),('candidate','/home/dev-user/.cache/oriole/external-grammar-target/debug/liboriole_expat.so')]:
 engine=m.Engine(path)
 for case in cases:
  for chunk in [1,7,4096]:
   row={'label':label,'library':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'id':case['ID'],'type':case['TYPE'],'path':case['path'],'chunk':chunk,'result':engine.parse(m.SUITE/case['path'],chunk,case.get('NAMESPACE','yes')!='no')};rows.append(row)
   if chunk==1:print(label,case['ID'],row['result']['status'],row['result']['error'])
Path('/tmp/oriole-external-grammar-w3c-five.json').write_text(json.dumps(rows,indent=2)+'\n')
