import ctypes as c,json,hashlib,itertools
from pathlib import Path
P,S,I=c.c_void_p,c.c_char_p,c.c_int
EXT=c.CFUNCTYPE(I,P,S,S,S,S);ENTITY=c.CFUNCTYPE(None,P,S,I,P,I,S,S,S,S);ATT=c.CFUNCTYPE(None,P,S,S,S,S,I);ELEMENT=c.CFUNCTYPE(None,P,S,P);NOT=c.CFUNCTYPE(None,P,S,S,S,S);UNPARSED=c.CFUNCTYPE(None,P,S,S,S,S,S);DEFAULT=c.CFUNCTYPE(None,P,P,I)
LIB='/home/dev-user/.cache/oriole/expat-build/libexpat.so';l=c.CDLL(LIB)
for n,r,a in [('XML_ParserCreate',P,[S]),('XML_ExternalEntityParserCreate',P,[P,S,S]),('XML_ParserFree',None,[P]),('XML_Parse',I,[P,P,I,I]),('XML_SetParamEntityParsing',I,[P,I]),('XML_SetExternalEntityRefHandler',None,[P,EXT]),('XML_SetEntityDeclHandler',None,[P,ENTITY]),('XML_SetAttlistDeclHandler',None,[P,ATT]),('XML_SetElementDeclHandler',None,[P,ELEMENT]),('XML_SetNotationDeclHandler',None,[P,NOT]),('XML_SetUnparsedEntityDeclHandler',None,[P,UNPARSED]),('XML_SetDefaultHandlerExpand',None,[P,DEFAULT]),('XML_FreeContentModel',None,[P,P]),('XML_GetErrorCode',I,[P])]:
 f=getattr(l,n);f.restype=r;f.argtypes=a
D=lambda s:s.decode() if s is not None else None

def probe(body,action='empty',handlers=63,standalone=None,width=0,toggle=None):
 events=[];active=[None,'root'];children=[];root=l.XML_ParserCreate(None)
 @ENTITY
 def entity(_,name,param,value,n,base,system,public,notation):events.append([active[1],'entity',D(name),param,c.string_at(value,n).decode() if value else None,D(system),D(notation)])
 @ATT
 def att(_,element,name,kind,value,required):events.append([active[1],'attlist',D(element),D(name),D(kind),D(value),required])
 @ELEMENT
 def element(_,name,model):events.append([active[1],'element',D(name)]);l.XML_FreeContentModel(active[0],model)
 @NOT
 def notation(_,name,base,system,public):events.append([active[1],'notation',D(name),D(system),D(public)])
 @UNPARSED
 def unparsed(_,name,base,system,public,notation):events.append([active[1],'unparsed',D(name),D(system),D(notation)])
 @DEFAULT
 def default(_,value,n):events.append([active[1],'default',c.string_at(value,n).decode()])
 callbacks=[('XML_SetEntityDeclHandler',ENTITY,entity,1),('XML_SetAttlistDeclHandler',ATT,att,2),('XML_SetElementDeclHandler',ELEMENT,element,4),('XML_SetNotationDeclHandler',NOT,notation,8),('XML_SetUnparsedEntityDeclHandler',UNPARSED,unparsed,16),('XML_SetDefaultHandlerExpand',DEFAULT,default,32)]
 def configure(p,mask):
  for method,kind,callback,bit in callbacks:getattr(l,method)(p,callback if mask&bit else kind())
 @EXT
 def external(p,context,base,system,public):
  name=D(system);events.append([active[1],'external',name])
  if name!='d' and toggle is not None:configure(p,toggle)
  if name!='d' and action=='skip':return 1
  child=l.XML_ExternalEntityParserCreate(p,context,None);assert child
  saved=active[:];active[:]=[child,name];l.XML_SetParamEntityParsing(child,2)
  data=('<!ENTITY % p SYSTEM "p">'+body+'<!ENTITY after "A">').encode()if name=='d'else b''
  status=1
  if name=='d'or action!='create-only':
   step=width or max(len(data),1)
   for start in range(0,max(len(data),1),step):
    part=data[start:start+step];status=l.XML_Parse(child,part,len(part),int(start+step>=len(data)and action!='empty-nonfinal' or name=='d'and start+step>=len(data)))
    if status!=1:break
  children.append([name,status,l.XML_GetErrorCode(child)]);l.XML_ParserFree(child);active[:]=saved;return int(status==1)
 active[:]=[root,'root'];configure(root,handlers);l.XML_SetExternalEntityRefHandler(root,external);l.XML_SetParamEntityParsing(root,2)
 data=((f'<?xml version="1.0" standalone="{standalone}"?>'if standalone else '')+'<!DOCTYPE r SYSTEM "d"><r/>').encode();status=l.XML_Parse(root,data,len(data),1);error=l.XML_GetErrorCode(root);l.XML_ParserFree(root)
 return dict(body=body,action=action,handlers=handlers,standalone=standalone,width=width,toggle=toggle,status=status,error=error,children=children,events=events)
CASES={
 'entity-value':'''<!ENTITY e 'V' %p;>''',
 'duplicate-value':'''<!ENTITY e 'FIRST'><!ENTITY e 'V' %p;>''',
 'entity-system':'''<!ENTITY e SYSTEM 's' %p;>''',
 'entity-ndata':'''<!ENTITY e SYSTEM 's' NDATA n %p;>''',
 'notation-system':'''<!NOTATION n SYSTEM 's' %p;>''',
 'notation-public':'''<!NOTATION n PUBLIC 'pub' %p;>''',
 'notation-public-system':'''<!NOTATION n PUBLIC 'pub' 's' %p;>''',
 'element-empty':'''<!ELEMENT r EMPTY %p;>''',
 'element-any':'''<!ELEMENT r ANY %p;>''',
 'element-model':'''<!ELEMENT r (a) %p;>''',
 'attlist-two':'''<!ATTLIST r a CDATA 'A' %p; b CDATA 'B'>''',
 'attlist-partial':'''<!ATTLIST r a CDATA %p; 'A' b CDATA 'B'>''',
 'missing-before-external':'''<!ATTLIST r a CDATA 'A' %missing; %p; b CDATA 'B'>''',
 'unparsed-duplicate':'''<!ENTITY e SYSTEM 's' NDATA n><!ENTITY e SYSTEM 't' NDATA n %p;>''',
}
if __name__=='__main__':
 rows=[]
 for name,body in CASES.items():
  for action,handlers,standalone,width in itertools.product(['empty','skip','create-only','empty-nonfinal'],[63,32], [None,'yes'],[0,1]):
   r=probe(body,action,handlers,standalone,width);r['name']=name;rows.append(r)
 output=dict(library=LIB,sha256=hashlib.sha256(Path(LIB).read_bytes()).hexdigest(),cases=len(rows),rows=rows);Path('/tmp/oriole-external-grammar-review/commit-order.json').write_text(json.dumps(output,indent=2)+'\n');print(len(rows))
 for r in rows:
  if r['action']in('empty','skip')and r['handlers']==63 and r['standalone']is None and r['width']==0:print(r['name'],r['action'],r['status'],[e for e in r['events']if e[1]!='default'and e[0]=='d'])
