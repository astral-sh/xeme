import gzip, hashlib, itertools, json, random, subprocess
from pathlib import Path
import importlib.util
spec=importlib.util.spec_from_file_location("reference", "/tmp/oriole-external-grammar-review/commit_order.py")
reference=importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)
R=random.Random(20260910)
valid=set()
for name,param,literal in itertools.product(('e','_e','π'),('', '% '),("''","'v'",'"a b"')):
 valid.add(f'ENTITY {param}{name} {literal}')
for kind,name,external in itertools.product(('ENTITY','NOTATION'),('e','π'),("SYSTEM 's'","PUBLIC 'p' 's'")):
 valid.add(f'{kind} {name} {external}')
valid.update(["NOTATION n PUBLIC 'p'", "ENTITY e SYSTEM 's' NDATA n"])
for typ,default in itertools.product(('CDATA','ID','IDREF','IDREFS','ENTITY','ENTITIES','NMTOKEN','NMTOKENS','(a|b|1)','NOTATION (a|b)'),("'v'",'#REQUIRED','#IMPLIED',"#FIXED 'v'")):
 valid.add(f'ATTLIST r a {typ} {default}')
 valid.add(f'ATTLIST r first CDATA "f" a {typ} {default} last CDATA "l"')
valid.add('ATTLIST r')
def model(depth=0):
 if depth>2 or (depth>0 and R.randrange(3)==0):return R.choice(('a','b','π'))+R.choice(('','?','+','*'))
 separator=R.choice(('|',','));return '('+separator.join(model(depth+1)for _ in range(R.randrange(1,4)))+')'+R.choice(('','?','+','*'))
for _ in range(400):valid.add('ELEMENT r '+model())
valid.update('ELEMENT r '+m for m in ('EMPTY','ANY','(#PCDATA)','(#PCDATA)*','(#PCDATA|a|b)*'))
rows=[{'grammar':s,'origin':'valid'}for s in sorted(valid)]
for _ in range(4000):
 s=R.choice(sorted(valid));quote=None;outside=[]
 for i,char in enumerate(s):
  if quote==char:quote=None
  elif quote is None:
   if char in "'\"":quote=char
   else:outside.append(i)
 i=R.choice(outside);op=R.randrange(3);c=R.choice(' ()|,*+?%#012a_\t:@')
 mutated=s[:i]+(c+s[i:]if op==0 else s[i+1:]if op==1 else c+s[i+1:])
 rows.append({'grammar':mutated,'origin':'mutation'})
binary=Path('/home/dev-user/.cache/oriole/grammar-cursor-target/debug/oriole-grammar-cursor-harness')
run=subprocess.run([str(binary)],input=''.join('0\t'+r['grammar'].encode().hex()+'\n'for r in rows),text=True,capture_output=True,check=True)
outputs=run.stdout.splitlines();assert len(outputs)==len(rows)
for row,output in zip(rows,outputs):
 r=reference.probe('<!'+row['grammar']+'>',handlers=31)
 row['cursor']=output;row['reference_status']=r['status'];row['reference_error']=r['children'][-1][2];row['reference_events']=[e for e in r['events']if e[0]=='d'and e[1]not in ('external',)and not(e[1]=='entity'and e[2]in ('p','after'))]
 row['same_acceptance']=(output.startswith('ok|'))==(r['status']==1)
result={'reference':reference.LIB,'reference_sha256':hashlib.sha256(Path(reference.LIB).read_bytes()).hexdigest(),'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path('/tmp/oriole-external-grammar/crates/oriole/src/dtd/grammar.rs').read_bytes()).hexdigest(),'cases':len(rows),'acceptance_differences':sum(not r['same_acceptance']for r in rows),'rows':rows}
with gzip.open('/tmp/oriole-external-grammar-review/cursor-oracle.json.gz','wt')as f:json.dump(result,f)
print({k:v for k,v in result.items()if k!='rows'})
for r in rows:
 if not r['same_acceptance']:print(r)
