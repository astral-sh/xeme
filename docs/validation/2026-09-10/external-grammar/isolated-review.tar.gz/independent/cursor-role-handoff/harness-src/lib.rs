#![allow(dead_code)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ErrorKind {
    Syntax,
    InvalidToken,
    NoMemory,
    LimitExceeded,
}
#[path = "/tmp/oriole-external-grammar/crates/oriole/src/dtd/grammar.rs"]
mod grammar;
#[path = "/tmp/oriole-external-grammar/crates/oriole/src/names.rs"]
mod names;

#[cfg(test)]
mod allocation_tests {
    use crate::{
        ErrorKind,
        grammar::{Cursor, Progress},
    };
    use oriole_storage::Allocator;
    #[test]
    fn model_stack_uses_the_selected_allocator() {
        unsafe extern "C" fn no_malloc(_: usize) -> *mut std::ffi::c_void {
            std::ptr::null_mut()
        }
        unsafe extern "C" fn no_realloc(
            _: *mut std::ffi::c_void,
            _: usize,
        ) -> *mut std::ffi::c_void {
            std::ptr::null_mut()
        }
        unsafe extern "C" fn no_free(_: *mut std::ffi::c_void) {
            panic!("failed allocation cannot be freed")
        }
        // SAFETY: callbacks have static lifetime and return null without dereferencing input.
        let allocator = unsafe {
            Allocator::from_callbacks(oriole_storage::MemorySuite {
                malloc: Some(no_malloc),
                realloc: Some(no_realloc),
                free: Some(no_free),
            })
        }
        .unwrap();
        let mut cursor = Cursor::new(allocator, false, 64);
        assert_eq!(
            cursor.advance("ELEMENT r (a)", true),
            Err((ErrorKind::NoMemory, 10))
        );
        let mut cursor = Cursor::new(allocator, false, 64);
        assert!(matches!(
            cursor.advance("ELEMENT r EMPTY", true),
            Ok(Progress::Commit(_))
        ));
    }
}
