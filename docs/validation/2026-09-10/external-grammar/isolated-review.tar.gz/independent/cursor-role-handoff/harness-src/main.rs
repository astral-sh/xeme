#![allow(dead_code)]
use std::io::{self, BufRead};
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ErrorKind {
    Syntax,
    InvalidToken,
    NoMemory,
    LimitExceeded,
}
#[path = "/tmp/oriole-external-grammar/crates/oriole/src/dtd/grammar.rs"]
mod grammar;
#[path = "/tmp/oriole-external-grammar/crates/oriole/src/names.rs"]
mod names;
fn main() {
    for line in io::stdin().lock().lines() {
        let line = line.unwrap();
        let (mode, encoded) = line.split_once('\t').unwrap();
        let bytes: Vec<u8> = (0..encoded.len())
            .step_by(2)
            .map(|i| u8::from_str_radix(&encoded[i..i + 2], 16).unwrap())
            .collect();
        let text = std::str::from_utf8(&bytes).unwrap();
        let mut cursor = grammar::Cursor::new(oriole_storage::Allocator::System, mode == "1", 256);
        let mut commits = String::new();
        loop {
            match cursor.advance(text, true) {
                Ok(grammar::Progress::Commit(c)) => {
                    commits.push_str(&format!("{:?}:{}:{},", c.kind, c.start, c.end))
                }
                Ok(grammar::Progress::EnumerationMember { .. }) => {}
                Ok(_) => {
                    println!("ok|{commits}");
                    break;
                }
                Err((kind, at)) => {
                    println!("err:{kind:?}:{at}|{commits}");
                    break;
                }
            }
        }
    }
}
