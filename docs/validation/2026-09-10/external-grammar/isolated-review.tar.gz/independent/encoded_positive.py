"""Independent public-C-API encoding/chunk oracle for ordinary grammar PEs."""
import ctypes as c
import gzip
import hashlib
import itertools
import json
from pathlib import Path

P, S, I = c.c_void_p, c.c_char_p, c.c_int
EXT = c.CFUNCTYPE(I, P, S, S, S, S)
ENTITY = c.CFUNCTYPE(None, P, S, I, P, I, S, S, S, S)
ATT = c.CFUNCTYPE(None, P, S, S, S, S, I)
ELEMENT = c.CFUNCTYPE(None, P, S, P)
NOT = c.CFUNCTYPE(None, P, S, S, S, S)
DEFAULT = c.CFUNCTYPE(None, P, P, I)


class Model(c.Structure):
    pass


Model._fields_ = [('kind', I), ('quant', I), ('name', S), ('count', c.c_uint), ('children', c.POINTER(Model))]


def library(path):
    lib = c.CDLL(path)
    for name, result, args in [
        ('XML_ParserCreate', P, [S]), ('XML_ExternalEntityParserCreate', P, [P, S, S]),
        ('XML_ParserFree', None, [P]), ('XML_Parse', I, [P, P, I, I]),
        ('XML_SetParamEntityParsing', I, [P, I]), ('XML_SetExternalEntityRefHandler', None, [P, EXT]),
        ('XML_SetEntityDeclHandler', None, [P, ENTITY]), ('XML_SetAttlistDeclHandler', None, [P, ATT]),
        ('XML_SetElementDeclHandler', None, [P, ELEMENT]), ('XML_SetNotationDeclHandler', None, [P, NOT]),
        ('XML_SetDefaultHandlerExpand', None, [P, DEFAULT]), ('XML_FreeContentModel', None, [P, P]),
        ('XML_GetErrorCode', I, [P]),
    ]:
        function = getattr(lib, name)
        function.restype, function.argtypes = result, args
    return lib


def decode(value):
    return value.decode() if value is not None else None


def encoded(text, encoding):
    return {'utf8': b'', 'utf16le': b'\xff\xfe', 'utf16be': b'\xfe\xff'}[encoding] + text.encode({'utf8': 'utf-8', 'utf16le': 'utf-16-le', 'utf16be': 'utf-16-be'}[encoding])


PREFIX = '<!ENTITY % p SYSTEM "p"><!ENTITY % q SYSTEM "q">'
SUFFIX = '<!ENTITY after "A">'
CASES = [
    ('reservation', "<!ENTITY é %p; 'Pé'>", '<!ENTITY é "CHILD">', 31, None, None, 'read'),
    ('entity-ids', "<!ENTITY % é PUBLIC ' public  id ' %p; 's'>", '%é;', 31, None, None, 'read'),
    ('value-after-grammar', "<!ENTITY é %p; 'L%q;R'>", '<!ENTITY side "S">', 31, None, None, 'read'),
    ('value-internal-literal', "<!ENTITY % literal '\"L%q;R\"'><!ENTITY é %p; %literal;>", '', 31, None, None, 'read'),
    ('entity-early', "<!ENTITY é 'Vé' %p;>", '', 31, None, None, 'read'),
    ('attributes', "<!ATTLIST r é CDATA 'é' %p; β CDATA 'β'>", '', 31, None, None, 'read'),
    ('enum-install', "<!ATTLIST r é (é|%p;β) 'é'>", '', 16, 31, None, 'read'),
    ('enum-remove', "<!ATTLIST r é (é|%p;β) 'é' next CDATA 'N'>", '', 31, 16, None, 'read'),
    ('notation-enum', "<!ATTLIST r é NOTATION (%p;é|β) 'é'>", '', 16, 31, None, 'read'),
    ('model', "<!ELEMENT r (%p;é,(β|γ)*)>", '', 31, None, None, 'read'),
    ('notation-public-install', "<!NOTATION é PUBLIC 'public' %p;>", '', 16, 31, None, 'read'),
    ('notation-system-remove', "<!NOTATION é SYSTEM 'sé' %p;>", '', 31, 16, None, 'read'),
    ('missing-value-suffix', "<!ENTITY é %missing; %p; 'L%q;R' %missing;>", '', 31, None, 'yes', 'read'),
    ('duplicate-value', "<!ENTITY é 'FIRST'><!ENTITY é %p; 'L%q;R'>", '', 31, None, None, 'read'),
    ('skip-attribute', "<!ATTLIST r é CDATA 'é' %p; β CDATA 'β'>", '', 31, None, None, 'skip'),
    ('skip-standalone', "<!ATTLIST r é CDATA 'é' %p; β CDATA 'β'>", '', 31, None, 'yes', 'skip'),
]


def probe(lib, case, encoding, width):
    name, body, pvalue, handlers, toggle, standalone, action = case
    events, children = [], []
    active = [None, 'root']
    root = lib.XML_ParserCreate(None)
    assert root

    @ENTITY
    def entity(_, entity_name, parameter, value, length, base, system, public, notation):
        events.append([active[1], 'entity', decode(entity_name), parameter,
                       c.string_at(value, length).decode() if value else None,
                       decode(base), decode(system), decode(public), decode(notation)])

    @ATT
    def att(_, element, attribute, kind, value, required):
        events.append([active[1], 'attlist', decode(element), decode(attribute), decode(kind), decode(value), required])

    def model_data(model, depth=0):
        assert depth < 32 and model.count < 32
        return [model.kind, model.quant, decode(model.name), [model_data(model.children[i], depth + 1) for i in range(model.count)]]

    @ELEMENT
    def element(_, element_name, model):
        events.append([active[1], 'element', decode(element_name), model_data(c.cast(model, c.POINTER(Model)).contents)])
        lib.XML_FreeContentModel(active[0], model)

    @NOT
    def notation(_, notation_name, base, system, public):
        events.append([active[1], 'notation', decode(notation_name), decode(base), decode(system), decode(public)])

    @DEFAULT
    def default(_, value, length):
        value = c.string_at(value, length).decode()
        if events and events[-1][:2] == [active[1], 'default']:
            events[-1][2] += value
        else:
            events.append([active[1], 'default', value])

    def configure(parser, mask):
        for setter, typ, callback, bit in [
            ('XML_SetEntityDeclHandler', ENTITY, entity, 1), ('XML_SetAttlistDeclHandler', ATT, att, 2),
            ('XML_SetElementDeclHandler', ELEMENT, element, 4), ('XML_SetNotationDeclHandler', NOT, notation, 8),
            ('XML_SetDefaultHandlerExpand', DEFAULT, default, 16),
        ]:
            getattr(lib, setter)(parser, callback if mask & bit else typ())

    @EXT
    def external(parser, context, base, system, public):
        child_name = decode(system)
        events.append([active[1], 'external', decode(context), decode(base), child_name, decode(public)])
        if child_name == 'p' and toggle is not None:
            configure(parser, toggle)
        if child_name == 'p' and action == 'skip':
            return 1
        child = lib.XML_ExternalEntityParserCreate(parser, context, None)
        assert child
        assert lib.XML_SetParamEntityParsing(child, 2) == 1
        saved = active[:]
        active[:] = [child, child_name]
        text = PREFIX + body + SUFFIX if child_name == 'd' else pvalue if child_name == 'p' else 'Qé' if child_name == 'q' else ''
        data = encoded(text, encoding)
        status = 1
        step = width or max(len(data), 1)
        for start in range(0, max(len(data), 1), step):
            piece = data[start:start + step]
            status = lib.XML_Parse(child, piece, len(piece), int(start + step >= len(data)))
            if status != 1:
                break
        children.append([child_name, status, lib.XML_GetErrorCode(child)])
        lib.XML_ParserFree(child)
        active[:] = saved
        return int(status == 1)

    active[:] = [root, 'root']
    configure(root, handlers)
    lib.XML_SetExternalEntityRefHandler(root, external)
    assert lib.XML_SetParamEntityParsing(root, 2) == 1
    document = ((f'<?xml version="1.0" standalone="{standalone}"?>' if standalone else '') + '<!DOCTYPE r SYSTEM "d"><r/>').encode()
    status = lib.XML_Parse(root, document, len(document), 1)
    error = lib.XML_GetErrorCode(root)
    lib.XML_ParserFree(root)
    return {'status': status, 'error': error, 'children': children, 'events': events}


def main():
    reference_path = '/home/dev-user/.cache/oriole/expat-build/libexpat.so'
    candidate_path = '/home/dev-user/.cache/oriole/external-grammar-target/debug/liboriole_expat.so'
    reference, candidate = library(reference_path), library(candidate_path)
    hashes = {path: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in [reference_path, candidate_path]}
    assert hashes[candidate_path] == 'c7cb6283241ca34835795d31a2cbb6bad8b1f63f599f4f324b009f4dc39edbd7'
    rows = []
    for case, encoding in itertools.product(CASES, ['utf8', 'utf16le', 'utf16be']):
        for width in range(1, len(encoded(PREFIX + case[1] + SUFFIX, encoding)) + 1):
            expected = probe(reference, case, encoding, width)
            actual = probe(candidate, case, encoding, width)
            rows.append({'case': case[0], 'encoding': encoding, 'width': width, 'same': expected == actual,
                         'reference': expected, 'candidate': actual})
    result = {'hashes': hashes, 'cases': CASES, 'comparisons': len(rows),
              'reference_rejected': sum(r['reference']['status'] != 1 for r in rows),
              'differences': sum(not r['same'] for r in rows),
              'outcome_differences': sum(any(r['reference'][key] != r['candidate'][key] for key in ['status', 'error', 'children']) for r in rows),
              'scope': 'Every byte width from 1 through encoded external DTD length; UTF8 and BOM-qualified UTF16LE/BE. Exact callback metadata/order after merging adjacent Default fragments for the same parser. Root input fed once. Does not compare callback timing relative to individual XML_Parse returns.',
              'rows': rows}
    assert hashes == {path: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in hashes}
    with gzip.open('/tmp/oriole-external-grammar-review/encoded-positive.json.gz', 'wt') as output:
        json.dump(result, output)
    print({key: value for key, value in result.items() if key not in ['rows', 'cases']})
    for row in rows:
        if not row['same']:
            print(row)
            break


if __name__ == '__main__':
    main()
