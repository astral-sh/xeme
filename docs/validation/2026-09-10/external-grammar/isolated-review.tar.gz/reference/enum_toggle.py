import gzip,hashlib,importlib.util,itertools,json
from pathlib import Path
spec=importlib.util.spec_from_file_location('reference','/tmp/oriole-external-grammar-review/commit_order.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
rows=[]
for notation,placement,handlers,toggle,action,standalone in itertools.product((False,True),('middle','first','after'),(0,2,32,34,63),(None,0,32,34,63),('empty','skip'),(None,'yes')):
 kind='NOTATION 'if notation else ''
 body='<!ATTLIST r a '+kind+{'middle':"(x|%p;y) 'x'",'first':"(%p;x|y) 'x'",'after':"(x|y) %p; 'x'"}[placement]+'>'
 out=r.probe(body,handlers=handlers,toggle=toggle,action=action,standalone=standalone)
 rows.append(dict(notation=notation,placement=placement,result=out))
with gzip.open('/tmp/oriole-external-grammar-review/enum-toggle.json.gz','wt')as f:json.dump(dict(library=r.LIB,library_sha256=hashlib.sha256(Path(r.LIB).read_bytes()).hexdigest(),cases=len(rows),rows=rows),f)
print(len(rows))
for row in rows:
 out=row['result']
 if out['handlers']==32 and out['toggle']==34 and out['action']=='empty' and out['standalone'] is None:print(row['notation'],row['placement'],out['status'],[e for e in out['events']if e[1]=='attlist'])
