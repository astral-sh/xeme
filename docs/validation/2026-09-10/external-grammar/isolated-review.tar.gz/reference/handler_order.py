import gzip,hashlib,importlib.util,itertools,json
from pathlib import Path
spec=importlib.util.spec_from_file_location('reference','/tmp/oriole-external-grammar-review/commit_order.py')
reference=importlib.util.module_from_spec(spec);spec.loader.exec_module(reference)
rows=[]
for name,body in reference.CASES.items():
 for action,handlers,standalone,toggle in itertools.product(('empty','skip'),(0,1,2,4,8,16,31,32,63),(None,'yes'),(None,0,32,63)):
  r=reference.probe(body,action=action,handlers=handlers,standalone=standalone,toggle=toggle);r['name']=name;rows.append(r)
result={'reference':reference.LIB,'sha256':hashlib.sha256(Path(reference.LIB).read_bytes()).hexdigest(),'cases':len(rows),'rows':rows}
with gzip.open('/tmp/oriole-external-grammar-review/handler-order.json.gz','wt')as f:json.dump(result,f)
print({'cases':len(rows),'status_success':sum(r['status']==1 for r in rows)})
