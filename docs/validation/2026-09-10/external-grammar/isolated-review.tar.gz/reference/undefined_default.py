import ctypes as c,hashlib,importlib.util,itertools,json
from pathlib import Path
spec=importlib.util.spec_from_file_location('reference','/tmp/oriole-external-grammar-review/commit_order.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
def internal(body,standalone,action,external_subset=False,parameter=False):
 l=r.l;p=l.XML_ParserCreate(None);events=[];children=[]
 @r.ATT
 def att(_,element,name,kind,value,required):events.append(['att',r.D(name),r.D(value)])
 @r.DEFAULT
 def default(_,data,n):events.append(['default',c.string_at(data,n).decode()])
 @r.EXT
 def external(parent,context,base,system,public):
  events.append(['external',r.D(system)])
  if action=='skip':return 1
  child=l.XML_ExternalEntityParserCreate(parent,context,None);status=l.XML_Parse(child,b'',0,1);children.append([status,l.XML_GetErrorCode(child)]);l.XML_ParserFree(child);return status
 l.XML_SetAttlistDeclHandler(p,att);l.XML_SetDefaultHandlerExpand(p,default);l.XML_SetExternalEntityRefHandler(p,external);l.XML_SetParamEntityParsing(p,2)
 decl=f'<?xml version="1.0" standalone="{standalone}"?>'if standalone else ''
 data=(decl+'<!DOCTYPE r'+(' SYSTEM "d"'if external_subset else '')+'['+('<!ENTITY % p SYSTEM "p">%p;'if parameter else '')+body+']><r/>').encode()
 status=l.XML_Parse(p,data,len(data),1);error=l.XML_GetErrorCode(p);l.XML_ParserFree(p)
 return dict(status=status,error=error,events=events,children=children)
rows=[]
for standalone,action,literal in itertools.product((None,'no','yes'),('empty','skip'),('&u;','L&u;R','&#0;','&u','&amp;')):
 for context in ('internal','internal-system','internal-after-pe','external','external-before-value','external-after-value','external-before-declaration'):
  body=f"<!ATTLIST r a CDATA '{literal}'>"
  if context.startswith('internal'):
   out=internal(body,standalone,action,external_subset=context=='internal-system',parameter=context=='internal-after-pe')
  else:
   if context=='external-before-value':body=f"<!ATTLIST r a CDATA %p; '{literal}'>"
   elif context=='external-after-value':body=f"<!ATTLIST r a CDATA '{literal}' %p;>"
   elif context=='external-before-declaration':body='%p;'+body
   out=r.probe(body,standalone=standalone,action=action)
  rows.append(dict(context=context,standalone=standalone,action=action,literal=literal,result=out))
report=dict(library=r.LIB,library_sha256=hashlib.sha256(Path(r.LIB).read_bytes()).hexdigest(),cases=len(rows),rows=rows)
Path('/tmp/oriole-external-grammar-review/undefined-default.json').write_text(json.dumps(report,indent=2)+'\n')
for row in rows:
 if row['literal']=='L&u;R' and row['standalone']in(None,'yes'):
  out=row['result'];print(row['context'],row['standalone'],row['action'],out['status'],out['error'],out['children'],[e for e in out['events']if 'att' in e or 'attlist'in e])
