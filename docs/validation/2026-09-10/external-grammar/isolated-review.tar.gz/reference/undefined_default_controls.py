import ctypes as c,hashlib,importlib.util,itertools,json
from pathlib import Path
spec=importlib.util.spec_from_file_location('reference','/tmp/oriole-external-grammar-review/commit_order.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
def internal(body,standalone,action,external_subset=False,parameter=False,root_element="<r/>"):
 l=r.l;p=l.XML_ParserCreate(None);events=[];children=[]
 @r.ATT
 def att(_,element,name,kind,value,required):events.append(['att',r.D(name),r.D(value)])
 @r.DEFAULT
 def default(_,data,n):events.append(['default',c.string_at(data,n).decode()])
 @r.EXT
 def external(parent,context,base,system,public):
  events.append(['external',r.D(system)])
  if action=='skip':return 1
  child=l.XML_ExternalEntityParserCreate(parent,context,None);status=l.XML_Parse(child,b'',0,1);children.append([status,l.XML_GetErrorCode(child)]);l.XML_ParserFree(child);return status
 l.XML_SetAttlistDeclHandler(p,att);l.XML_SetDefaultHandlerExpand(p,default);l.XML_SetExternalEntityRefHandler(p,external);l.XML_SetParamEntityParsing(p,2)
 decl=f'<?xml version="1.0" standalone="{standalone}"?>'if standalone else ''
 data=(decl+'<!DOCTYPE r'+(' SYSTEM "d"'if external_subset else '')+'['+('<!ENTITY % p SYSTEM "p">%p;'if parameter else '')+body+']>'+root_element).encode()
 status=l.XML_Parse(p,data,len(data),1);error=l.XML_GetErrorCode(p);l.XML_ParserFree(p)
 return dict(status=status,error=error,events=events,children=children)
rows=[]
for standalone,external_subset,action in itertools.product((None,'no','yes'),(False,True),('empty','skip')):
 for context,body,root in (
  ('internal-pe-default', '<!ENTITY % decl "<!ATTLIST r a CDATA \'L&u;R\'>">%decl;', '<r/>'),
  ('root-content-attribute', '', "<r a='L&u;R'/>"),
  ('internal-pe-plus-root-attribute', '<!ENTITY % decl "<!ATTLIST r a CDATA \'L&u;R\'>">%decl;', "<r a='L&u;R'/>"),
 ):
  out=internal(body,standalone,action,external_subset=external_subset,root_element=root)
  rows.append(dict(context=context,standalone=standalone,external_subset=external_subset,action=action,result=out))
Path('/tmp/oriole-external-grammar-review/undefined-default-controls.json').write_text(json.dumps(dict(library=r.LIB,library_sha256=hashlib.sha256(Path(r.LIB).read_bytes()).hexdigest(),cases=len(rows),rows=rows),indent=2)+'\n')
for row in rows:
 if row['standalone'] in (None,'yes') and row['action']=='empty':print(row['context'],row['standalone'],row['external_subset'],row['result'])
