# External parameter references in conditional headers

The patch adds resumable external DTD loads inside conditional headers. The parent retains owned lexical frames, yields the external callback, imports successful child declarations, and then resolves the remaining header. Child input remains a separate DTD: an external body containing `INCLUDE` is not substituted into the parent header.

## Integration

- Base snapshot: `/tmp/oriole-pe-values` (final internal parameter-value layer).
- Candidate snapshot: `/tmp/oriole-external-parameter-context`.
- Patch: `external-headers.patch`, SHA256 `5e2f51b1861c007bf05502c4662383920cb1c1d0cdc0035c577262bd9016a35f`.
- Final library SHA256: `0fe9bbbe69b22392ed034add98f551a6591b7720c6e6995861dcc8758e6078a7`.
- Eight changed files and each base/final hash are recorded in `manifest.json`.
- `patch --dry-run --fuzz=0 -p1 -d /tmp/oriole-pe-values` succeeds.

The live workspace was not edited. Preserve the root's separate prolog fix and C README paragraph about broader XML names when integrating. When merging the subsequent declaration-token layer, retain `entity_chain` checks and `inherited_parameter_depth` in both declaration and entity-value expansion, in addition to the declaration layer's own active-parameter metadata.

## Behavior and ownership

- A shared read acknowledgement distinguishes no child, an unparsed child, successful protocol initialization on empty nonfinal input, and failed unknown protocol encoding. Acknowledgement occurs once per child, so a nested skipped load remains visible to the enclosing callback.
- Prefix Default events drain before the external request becomes active. Child declarations are imported before the parent resolves a later parameter reference in the header.
- Missing references immediately suppress later declarations unless standalone; external DTD children inherit that state, and their resulting skip state is imported on successful completion.
- Active external and internal parameter names and combined nesting depth cross child boundaries. Recursion fails before another callback. Storage and shared expansion accounting use the selected allocator and fallible allocations.
- Header callbacks preserve GetBuffer/ParseBuffer input, root suspension/resumption, aborts, and external-parameter suspension rejection. A child can outlive its parent.

## Validation

All local Cargo commands used `cargo +ohm` on CPU 3 with:

```
CARGO_HOME=/home/dev-user/.cache/toucan/cargo
CARGO_TARGET_DIR=/home/dev-user/.cache/oriole/external-parameter-context-target
CARGO_BUILD_BUILD_DIR=/home/dev-user/.cache/ohm/build
```

- `cargo +ohm test -p oriole -p oriole_expat`: 149 tests pass (97 core, 52 FFI), including selected-allocator failure injection, zero live allocations, and no global allocation bypass.
- `cargo +ohm clippy -p oriole -p oriole_expat --all-targets -- -D warnings`: passes.
- `cargo +ohm fmt --all`: complete.
- Seven focused core tests cover every byte chunk in UTF-8/UTF-16, child declaration imports, mode/standalone gates, read acknowledgement, nested skip propagation, recursion, shared budgets, child lifetime, and a missing reference before a later external load.
- 1,836 primary reference cases: all parent status/error results and all callback sequences after excluding the existing root NotStandalone ordering difference match Expat. 1,156 full status/error cases improve over the base, with zero new discrepancies. The 44 remaining child diagnostic differences are retained external-DTD lexical diagnostics (Syntax versus InvalidToken); they remain outside this layer and are not fixed by the separate root prolog change.
- 576 additional mixed-header cases: all status/error results match; 564 complete scoped event sequences match. The remaining 12 are the existing sparse Default callbacks on duplicate entity declarations.
- 16 upstream public API tests across six chunk modes and both reparse-deferral modes: reference 192/192, base 168/192, final candidate 192/192. Newly passing tests are `test_ext_entity_not_standalone` and `test_skipped_parameter_entity`.
- Independent final source review found no blocker. An additional 54 nested-read/absent-handler cases and 576 mixed-header cases reproduce the stated results; the earlier six inherited value-recursion cases all matched. Details are recorded in `independent-review.json`.

Full evidence paths and hashes are in `manifest.json`; concise counts are in `validation-summary.json` and `upstream-comparison.json`.

## Remaining scope

External parameter references inside entity values still need a distinct child mode and value continuation. Arbitrary declaration fragments belong to the separate declaration-token layer. This patch does not change the known root NotStandalone callback ordering or duplicate-declaration Default fragments.
