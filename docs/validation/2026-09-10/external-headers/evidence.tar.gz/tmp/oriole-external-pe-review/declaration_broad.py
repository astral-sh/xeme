import hashlib,json
from pathlib import Path
base=Path('/tmp/oriole-external-pe-review/probe.py').read_text().split("if __name__ == '__main__':")[0]
ref={'__name__':'imported'};exec(base,ref)
cand={'__name__':'imported'};exec(base.replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so','/home/dev-user/.cache/oriole/declaration-tokens-target/debug/liboriole_expat.so'),cand)
values=['',' ','r','EMPTY','ANY','a','ab','(a)','(a)*','(a|','a)','#PCDATA','a|b','a,b','*','?','CDATA','ID','(x|y)','"x"','"x','a CDATA "x"','SYSTEM "x"','PUBLIC "id" "x"','&#37;','&#37;p;','&#37;q;','&#37;missing;','a&gt;b','a&#13;&#10;b']
bodies=['<!ELEMENT %p; EMPTY>','<!ELEMENT r %p;>','<!ELEMENT r (%p;)>','<!ELEMENT r (a%p;)>','<!ELEMENT r (a)%p;>','<!ATTLIST %p; a CDATA "x">','<!ATTLIST r %p;>','<!ATTLIST r a %p; "x">','<!ATTLIST r a CDATA %p;>','<!ENTITY %p; "X">','<!ENTITY e %p;>','<!NOTATION %p; SYSTEM "x">','<!NOTATION n %p;>','<!ENTITY %p; e "X">']
rows=[]
def semantic(r):return [[e[1],*e[3:]] for e in r['events'] if e[0]=='d' and e[1] in ['entity','attlist']]
for value in values:
 for body in bodies:
  data=("<!ENTITY % q 'CDATA'><!ENTITY % p '"+value+"'>"+body+'<!ENTITY after "A">').encode()
  for mode in [0,2]:
   for standalone in [None,'yes']:
    a=ref['probe'](standalone,mode,data,b'');b=cand['probe'](standalone,mode,data,b'')
    row={'value':value,'body':body,'mode':mode,'standalone':standalone,'data':data.decode(),'reference':a,'candidate':b,'acceptance_match':a['status']==b['status'],'errors_match':[x['error'] for x in a['children']]==[x['error'] for x in b['children']],'semantics_match':semantic(a)==semantic(b),'default_match':a['default']==b['default']}
    rows.append(row)
    if not row['acceptance_match'] or (a['status']==b['status']==1 and not row['semantics_match']):print(json.dumps({'value':value,'body':body,'mode':mode,'standalone':standalone,'reference':a['children'],'candidate':b['children'],'ref_semantics':semantic(a),'cand_semantics':semantic(b)}))
Path('/tmp/oriole-external-pe-review/declaration-broad-first.json').write_text(json.dumps({'sha256':hashlib.sha256(cand['LIB'].read_bytes()).hexdigest(),'cases':rows},indent=2)+'\n')
print('cases',len(rows),'acceptance differences',sum(not r['acceptance_match'] for r in rows),'successful semantics differences',sum(r['reference']['status']==r['candidate']['status']==1 and not r['semantics_match'] for r in rows),'errors differences',sum(not r['errors_match'] for r in rows))
