import hashlib,json
from pathlib import Path
lib=Path('/home/dev-user/.cache/oriole/declaration-tokens-target/debug/liboriole_expat.so')
sha='e8b432cf3516be9b17925148cfeb49b9671f581f1832e17d2a2e33f4935766e4'
assert hashlib.sha256(lib.read_bytes()).hexdigest()==sha
base=Path('/tmp/oriole-external-pe-review/probe.py').read_text().split("if __name__ == '__main__':")[0].replace("'data':data.decode()", "'data':data.hex()")
ref={'__name__':'imported'};exec(base,ref)
cand={'__name__':'imported'};exec(base.replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so',str(lib)),cand)
inputs=[
 '<!ENTITY % name "r"><!ENTITY % model "(a|"><!ELEMENT %name; %model;b)>',
 "<!ENTITY % attrs 'a CDATA \"x\" b (x|y) \"x\"'><!ATTLIST r %attrs;>",
 "<!ENTITY % literal '\"A&#13;&#10;B\"'><!ATTLIST r a CDATA %literal;><!ENTITY e %literal;>",
 "<!ENTITY % literal '\"A&#13;B\"'><!ENTITY e SYSTEM %literal;>",
 '<!ATTLIST r a CDATA "A" %missing; b CDATA "B"><!ENTITY e "E">',
 "<!ENTITY % name '名'><!ENTITY % literal '\"文字\"'><!ENTITY %name; %literal;>",
 "<!ENTITY % q '(a)'><!ENTITY % p '&#37;q;'><!ELEMENT r %p;>",
]
def semantic(r):
 return (r['status'],r['error'],[(x['name'],x['status'],x['error']) for x in r['children']],[[e[0],e[1],*e[3:]] for e in r['events'] if e[0]=='d' and e[1] in ['entity','attlist','not-standalone','skipped']],r['default'])
count=0;differences=[]
for text in inputs:
 for encoding in ['utf-8','utf-16le','utf-16be']:
  data=text.encode(encoding)
  if encoding=='utf-16le':data=b'\xff\xfe'+data
  if encoding=='utf-16be':data=b'\xfe\xff'+data
  for chunk in range(1,len(data)+1):
   for mode in [1,2]:
    for standalone in [None,'yes']:
     a=ref['probe'](standalone,mode,data,b'',chunk=chunk);b=cand['probe'](standalone,mode,data,b'',chunk=chunk)
     count+=1
     if semantic(a)!=semantic(b):
      differences.append({'text':text,'encoding':encoding,'chunk':chunk,'mode':mode,'standalone':standalone,'reference':a,'candidate':b})
assert hashlib.sha256(lib.read_bytes()).hexdigest()==sha
Path('/tmp/oriole-external-pe-review/declaration-chunks-final.json').write_text(json.dumps({'library':str(lib),'sha256':sha,'cases':count,'differences':differences},indent=2)+'\n')
print('cases',count,'differences',len(differences))
for r in differences[:3]:print(json.dumps(r))
