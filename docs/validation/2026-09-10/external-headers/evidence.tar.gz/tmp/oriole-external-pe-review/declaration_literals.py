import json
from pathlib import Path
base=Path('/tmp/oriole-external-pe-review/probe.py').read_text().split("if __name__ == '__main__':")[0]
ref={'__name__':'imported'};exec(base,ref)
cand={'__name__':'imported'};exec(base.replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so','/home/dev-user/.cache/oriole/declaration-tokens-target/debug/liboriole_expat.so'),cand)
rows=[]
for value in ['A&#13;B','A&#13;&#10;B','A\r\nB','A&#9;B','A&amp;B','A&#38;#13;B','A&#37;missing;B']:
 for declaration in ['<!ENTITY e %p;>','<!ATTLIST r a CDATA %p;>','<!ENTITY e SYSTEM %p;>']:
  data=("<!ENTITY % p '\""+value+"\"'>"+declaration).encode()
  for chunk in [0,1]:
   a=ref['probe'](None,2,data,b'',chunk=chunk);b=cand['probe'](None,2,data,b'',chunk=chunk)
   def semantic(r):return (r['status'],r['error'],[(e['name'],e['status'],e['error']) for e in r['children']],[[e[1],*e[3:]] for e in r['events'] if e[0]=='d' and e[1] in ['entity','attlist']])
   row={'data':data.decode(),'chunk':chunk,'reference':a,'candidate':b,'match':semantic(a)==semantic(b)};rows.append(row)
   if not row['match']:print(json.dumps({'data':row['data'],'chunk':chunk,'ref':semantic(a),'candidate':semantic(b)}))
Path('/tmp/oriole-external-pe-review/declaration-literals-first.json').write_text(json.dumps({'cases':rows},indent=2)+'\n')
print('cases',len(rows),'differences',sum(not r['match'] for r in rows))
