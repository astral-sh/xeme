import hashlib,json
from pathlib import Path
namespace={'__name__':'imported'}
exec(Path('/tmp/oriole-external-pe-review/probe.py').read_text(),namespace)
probe=namespace['probe']
prefix=b"<!ENTITY % p SYSTEM 'p'>"
suffix=b"<!ENTITY after 'after'><!ATTLIST r a CDATA 'yes'>"
cases=[
 ('declaration',b'<![INCLUDE%p;[<!ENTITY e "E">]]>',b"<!ENTITY x 'X'>"),
 ('define-keyword',b'<![%p;%k;[<!ENTITY e "E">]]>',b"<!ENTITY % k 'INCLUDE'>"),
 ('define-keyword-after',b'<![INCLUDE%p;%k;[<!ENTITY e "E">]]>',b"<!ENTITY % k ''>"),
 ('change-keyword',b'<![INCLUDE%p;%k;[<!ENTITY e "E">]]>',b"<!ENTITY % k 'IGNORE'>"),
 ('ignored-declaration',b'<![IGNORE%p;[<!ENTITY e "E">]]>',b"<!ENTITY x 'X'>"),
 ('whitespace',b'<![INCLUDE%p;[<!ENTITY e "E">]]>',b' \r\n\t'),
 ('comment',b'<![INCLUDE%p;[<!ENTITY e "E">]]>',b'<!--x-->'),
 ('recursive-validheader',b'<![INCLUDE%p;[<!ENTITY e "E">]]>',b'%p;'),
 ('undefined-in-child',b'<![INCLUDE%p;[<!ENTITY e "E">]]>',b'%missing;'),
 ('closed-body-in-child',b'<![INCLUDE%p;[<!ENTITY e "E">]]>',b']]>' ),
 ('complete-conditional',b'<![INCLUDE%p;[<!ENTITY e "E">]]>',b'<![INCLUDE[<!ENTITY x "X">]]>'),
 ('reference-after-keyword',b'<![INCLUDE%p;[<!ENTITY e "E">]]>',b'&#65;'),
]
rows=[]
for name,body,replacement in cases:
 for standalone in [None,'yes']:
  for mode in [0,1,2]:
   for action in ['parse','skip','empty']:
    for chunk in [0,1,2,3,4,5,7]:
     row=probe(standalone,mode,prefix+body+suffix,replacement,action,chunk)
     row['name']=name;rows.append(row)
path=Path('/tmp/oriole-external-pe-review/header-reference.json')
path.write_text(json.dumps({'cases':rows},indent=2)+'\n')
print('cases',len(rows))
for row in rows:
 if row['standalone'] is None and row['mode']==2 and row['action']=='parse' and row['chunk']==0:
  print(json.dumps({k:row[k] for k in ['name','children','error','default']}|{'events':[x for x in row['events'] if x[0]!='parent' and x[1]!='default']}))
