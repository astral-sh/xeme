import json
from pathlib import Path
scope={'__name__':'imported'}
exec(Path('/tmp/oriole-external-pe-review/probe.py').read_text(),scope)
cases=[
 ('element-name',b'r',b'<!ELEMENT %p; EMPTY>'),
 ('element-empty',b'EMPTY',b'<!ELEMENT r %p;>'),
 ('element-model',b'(a|b)*',b'<!ELEMENT r %p;>'),
 ('element-group-items',b'a|b',b'<!ELEMENT r (%p;)>'),
 ('element-split-name',b'ab',b'<!ELEMENT r (%p;cd)>'),
 ('element-split-model',b'(a|',b'<!ELEMENT r %p;b)>'),
 ('element-quantifier',b'*',b'<!ELEMENT r (a)%p;>'),
 ('element-model-partial-group',b'a)',b'<!ELEMENT r (%p;>'),
 ('attlist-name',b'r',b'<!ATTLIST %p; a CDATA "x">'),
 ('attribute-name',b'a',b'<!ATTLIST r %p; CDATA "x">'),
 ('attribute-type',b'CDATA',b'<!ATTLIST r a %p; "x">'),
 ('attribute-enum',b'(a|b)',b'<!ATTLIST r a %p; "a">'),
 ('attribute-decl',b'a CDATA "x"',b'<!ATTLIST r %p;>'),
 ('attribute-default',b'"x"',b'<!ATTLIST r a CDATA %p;>'),
 ('attribute-default-fragment',b'"x',b'<!ATTLIST r a CDATA %p;y">'),
 ('attribute-fixed',b'#FIXED "x"',b'<!ATTLIST r a CDATA %p;>'),
 ('attribute-value-literal',b'abc',b'<!ATTLIST r a CDATA "L%p;R">'),
 ('entity-name',b'e',b'<!ENTITY %p; "X">'),
 ('entity-literal',b'"X"',b'<!ENTITY e %p;>'),
 ('notation-name',b'n',b'<!NOTATION %p; SYSTEM "x">'),
 ('notation-external-id',b'SYSTEM "x"',b'<!NOTATION n %p;>'),
 ('keyword-fragment',b'ELEMENT',b'<!%p; r EMPTY>'),
 ('cross-declaration',b'<!ELEMENT r',b'%p; EMPTY>'),
]
rows=[]
for name,replacement,body in cases:
 data=b"<!ENTITY % p '"+replacement+b"'>"+body+b'<!ENTITY after "A">'
 for standalone in [None,'yes']:
  for mode in [0,1,2]:
   for chunk in [0,1]:
    row=scope['probe'](standalone,mode,data,b'',chunk=chunk)
    row['name']=name;rows.append(row)
Path('/tmp/oriole-external-pe-review/inline-reference.json').write_text(json.dumps({'cases':rows},indent=2)+'\n')
print('cases',len(rows))
for r in rows:
 if r['standalone'] is None and r['mode']==2 and r['chunk']==0:
  print(json.dumps({'name':r['name'],'children':r['children'],'events':[x for x in r['events'] if x[0]=='d' and x[1]!='default']}))
