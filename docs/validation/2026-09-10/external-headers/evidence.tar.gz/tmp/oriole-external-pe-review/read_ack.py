import json
from pathlib import Path
base=Path('/tmp/oriole-external-pe-review/probe.py').read_text().split("if __name__ == '__main__':")[0]
base=base.replace("child = l.XML_ExternalEntityParserCreate(parser, context, None)","child = l.XML_ExternalEntityParserCreate(parser, context, b'BOGUS' if name != 'd' and action == 'bad-encoding' else None)")
base=base.replace("content = data if name == 'd' else b'' if action == 'empty' else external_data", "content = data if name == 'd' else b'' if action in ['empty','empty-nonfinal','bad-encoding','create-only'] else external_data")
base=base.replace("for start in range(0, max(len(content), 1), width):", "for start in ([] if name != 'd' and action=='create-only' else range(0, max(len(content), 1), width)):")
base=base.replace("int(start+width>=len(content)))", "int(start+width>=len(content) and not(name!='d' and action=='empty-nonfinal')))")
base=base.replace("return int(status != 0)","return int(status != 0 or (name != 'd' and action in ['bad-encoding','ignore-error']))")
rows=[]
for default in [True,False]:
 scope={'__name__':'imported'}
 code=base if default else base.replace('l.XML_SetDefaultHandlerExpand(parent, callbacks[0])','pass')
 exec(code,scope)
 for standalone in [None,'yes']:
  for mode in [0,1,2]:
   for action in ['create-only','empty-nonfinal','empty','bad-encoding','ignore-error','skip']:
    row=scope['probe'](standalone,mode,b'<!ENTITY % p SYSTEM "p"><![INCLUDE%p;[<!ENTITY e "E">]]><!ENTITY after "A">',b'?',action)
    row['default_handler']=default
    rows.append(row)
Path('/tmp/oriole-external-pe-review/read-ack-reference.json').write_text(json.dumps({'cases':rows},indent=2)+'\n')
print('cases',len(rows))
for row in rows:
 if row['default_handler'] and row['standalone'] is None and row['mode']==2:
  print(json.dumps(row))
