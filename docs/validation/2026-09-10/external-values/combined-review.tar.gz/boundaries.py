from pathlib import Path
import json

namespace = {}
exec(Path('/tmp/oriole-external-value-review/reference.py').read_text().split('rows=[]')[0], namespace)
rows=[]
for body in [b'<!ENTITY e "L%p;R">',b'<!ENTITY e "L%p;amp;R">',b'<!ENTITY e "L%p;%q;R">',b'<!ENTITY % e "L%p;R">']:
    for content in [b'"&"',b'"&#"',b'"%"',b'"%q"',b'"&#xD;&#xA;"',b'X%missing;Y',b'X%i;Y',b'X%q;Y',b'"%i;"',b'<?xml version="1.0"?>X%i;Y']:
        for standalone in [None,'yes']:
            row=namespace['probe'](standalone,2,namespace['PREFIX']+body+b'<!ENTITY after "A">',{'p':content,'q':b'Q'},'parse',1)
            row.update(group='boundaries')
            rows.append(row)
Path('/tmp/oriole-external-value-review/boundaries.json').write_text(json.dumps({'cases':rows},separators=(',',':'))+'\n')
print('cases',len(rows))
