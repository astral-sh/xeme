from pathlib import Path
import hashlib,json,collections
root=Path('/tmp/oriole-external-value-review')
base={};exec((root/'reference.py').read_text().split('rows=[]')[0],base)
lib=Path('/home/dev-user/.cache/oriole/external-values-target/debug/liboriole_expat.so')
source=base['source'].replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so',str(lib))
scopes={}
def normalize(row):
 events=[]
 for raw in row['events']:
  if raw[:2]==['parent','not-standalone']:continue
  e=raw[:2]+raw[3:]
  if e[1]=='default' and events and events[-1][:2]==e[:2]:events[-1][2]+=e[2]
  else:events.append(e)
 return {'status':row['status'],'error':row['error'],'children':[(r['name'],r['status'],r['error']) for r in row['children']],'events':events}
results={}
for collection in ['reference','boundaries','initialization','partial_values']:
 rows=json.loads((root/f'{collection}.json').read_text())['cases'];out=[]
 for row in rows:
  entities=row.get('entity_handler',True);external=row.get('external_handler',True)
  if (entities,external) not in scopes:
   code=source
   if not entities:code=code.replace('l.XML_SetEntityDeclHandler(parent, callbacks[3])','pass')
   if not external:code=code.replace('l.XML_SetParamEntityParsing(child, mode)','l.XML_SetParamEntityParsing(child, mode)\n            l.XML_SetExternalEntityRefHandler(child, EXTERNAL())')
   scope={};exec(code,scope);scopes[entities,external]=scope
  data={k:bytes.fromhex(v) for k,v in row['external_data'].items()}
  new=scopes[entities,external]['probe'](row['standalone'],row['mode'],row['data'].encode(),data,row['action'],row['chunk'])
  a,b=normalize(row),normalize(new)
  out.append({'input':{k:v for k,v in row.items() if k not in ['events','children','default']},'status_match':(a['status'],a['error'],a['children'])==(b['status'],b['error'],b['children']),'events_match':a['events']==b['events'],'reference':a,'candidate':b})
 results[collection]=out
summary={k:{'cases':len(v),'status_differences':sum(not r['status_match'] for r in v),'event_differences':sum(not r['events_match'] for r in v),'successful_event_differences':sum(not r['events_match'] and r['reference']['status']==1 and r['candidate']['status']==1 for r in v)} for k,v in results.items()}
out={'sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'summary':summary,'collections':results}
(root/'candidate-first.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(summary))
for k,rows in results.items():
 for r in rows:
  if not r['status_match'] and r['input']['chunk']==0:print(k,json.dumps(r))
