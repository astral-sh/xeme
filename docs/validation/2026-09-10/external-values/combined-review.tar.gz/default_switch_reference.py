from pathlib import Path
import json
ns={};exec(Path('/tmp/oriole-external-value-review/reference.py').read_text().split('rows=[]')[0],ns)
rows=[]
bodies=['<!ENTITY e "L%p;R">','<!ENTITY e %missing;"L%p;R">','<!ENTITY % quoted "\'L&#37;p;R\'"><!ENTITY e %quoted;>','<!ENTITY % quoted "\'L&#37;p;R\'"><!ENTITY e %quoted; %missing;>']
for initial in (False,True):
 for entity in (False,True):
  code=ns['source']
  if not initial:code=code.replace('l.XML_SetDefaultHandlerExpand(parent, callbacks[0])','pass')
  if not entity:code=code.replace('l.XML_SetEntityDeclHandler(parent, callbacks[3])','pass')
  change='DEFAULT()' if initial else 'callbacks[0]'
  code=code.replace("name = decode(system)\n        event",f"name = decode(system)\n        if name == 'p': l.XML_SetDefaultHandlerExpand(parser,{change})\n        event")
  scope={};exec(code,scope)
  for body in bodies:
   for standalone in (None,'yes'):
    r=scope['probe'](standalone,2,('<!ENTITY % p SYSTEM "p">'+body+'<!ENTITY after "A">').encode(),b'X')
    rows.append({'initial':initial,'entity':entity,'body':body,'standalone':standalone,'result':r})
Path('/tmp/oriole-external-value-review/default-switch-reference.json').write_text(json.dumps(rows,separators=(',',':'))+'\n')
print('cases',len(rows))
for row in rows:
 if row['standalone']=='yes':print(json.dumps({k:v for k,v in row.items()if k!='result'}),[x[1:2]+x[3:] for x in row['result']['events'] if x[0]=='d'])
