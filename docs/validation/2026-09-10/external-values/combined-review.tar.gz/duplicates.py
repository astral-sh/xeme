from pathlib import Path
import json
root=Path('/tmp/oriole-external-value-review');base={};exec((root/'reference.py').read_text().split('rows=[]')[0],base)
rows=[]
for handler in (False,True):
 scopes={}
 for name,path in [('reference','/home/dev-user/.cache/oriole/expat-build/libexpat.so'),('candidate','/home/dev-user/.cache/oriole/external-values-target/debug/liboriole_expat.so')]:
  src=base['source'].replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so',path)
  if not handler:src=src.replace('l.XML_SetEntityDeclHandler(parent, callbacks[3])','pass')
  s={};exec(src,s);scopes[name]=s
 for action in ['parse','skip','reject']:
  data=b'<!ENTITY % p SYSTEM "p"><!ENTITY e "OLD"><!ENTITY e "L%p;R"><!ENTITY after "A">'
  runs={name:s['probe'](None,2,data,{'p':b'X'},action,0) for name,s in scopes.items()}
  rows.append(dict(handler=handler,action=action,runs=runs))
  print(handler,action,[(r[:2]+r[3:]) for r in runs['reference']['events']])
(root/'duplicates.json').write_text(json.dumps(rows,indent=2)+'\n')
