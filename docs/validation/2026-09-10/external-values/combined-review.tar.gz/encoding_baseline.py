import ctypes as c,json,hashlib
from pathlib import Path
rows=[]
for name,path in [('reference','/home/dev-user/.cache/oriole/expat-build/libexpat.so'),('header_baseline','/home/dev-user/.cache/oriole/external-parameter-context-target/debug/liboriole_expat.so'),('candidate','/home/dev-user/.cache/oriole/external-values-target/debug/liboriole_expat.so')]:
 lib=c.CDLL(path);lib.XML_ParserCreate.argtypes=[c.c_char_p];lib.XML_ParserCreate.restype=c.c_void_p
 lib.XML_ExternalEntityParserCreate.argtypes=[c.c_void_p,c.c_char_p,c.c_char_p];lib.XML_ExternalEntityParserCreate.restype=c.c_void_p
 lib.XML_Parse.argtypes=[c.c_void_p,c.c_char_p,c.c_int,c.c_int];lib.XML_Parse.restype=c.c_int
 lib.XML_GetErrorCode.argtypes=[c.c_void_p];lib.XML_GetErrorCode.restype=c.c_int
 lib.XML_ParserFree.argtypes=[c.c_void_p]
 for width in (1,2):
  parent=lib.XML_ParserCreate(None);child=lib.XML_ExternalEntityParserCreate(parent,b'',None)
  for index in range(0,2,width):
   status=lib.XML_Parse(child,b'X\0'[index:index+width],width,int(index+width==2))
   if not status:break
  rows.append(dict(library=name,sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),width=width,status=status,error=lib.XML_GetErrorCode(child)))
  lib.XML_ParserFree(child);lib.XML_ParserFree(parent)
Path('/tmp/oriole-external-value-review/encoding-baseline.json').write_text(json.dumps(rows,indent=2)+'\n')
print(rows)
