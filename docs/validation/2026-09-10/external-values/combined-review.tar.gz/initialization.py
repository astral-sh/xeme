from pathlib import Path
import json

base = {}
exec(Path('/tmp/oriole-external-value-review/reference.py').read_text().split('rows=[]')[0], base)
rows=[]
for prefix in (b'', b' ', b'X ', b'<!--a-->', b'<?pi?>'):
    for declaration in (b'<?xml version="1.0"?>', b'<?xml version="1.0" standalone="yes"?>', b'<?xml version="1.0" standalone="no"?>', b'<?xml encoding="UTF-8"?>'):
        for chunk in (0,1):
            row=base['probe'](None,2,base['PREFIX']+base['BODY'],{'p':prefix+declaration+b'X%missing;Y','q':b'Q'},'parse',chunk)
            row.update(group='initialization')
            rows.append(row)
for entities in (False,True):
    for external in (False,True):
        source=base['source']
        if not entities:
            source=source.replace('l.XML_SetEntityDeclHandler(parent, callbacks[3])','pass')
        if not external:
            source=source.replace('l.XML_SetParamEntityParsing(child, mode)','l.XML_SetParamEntityParsing(child, mode)\n            l.XML_SetExternalEntityRefHandler(child, EXTERNAL())')
        ns={}
        exec(source,ns)
        for action in ('parse','skip','ignore-error','reject'):
            for content in (b'X',b'"&"'):
                row=ns['probe'](None,2,base['PREFIX']+base['BODY'],{'p':content,'q':b'Q'},action,1)
                row.update(group='handlers',entity_handler=entities,external_handler=external)
                rows.append(row)
Path('/tmp/oriole-external-value-review/initialization.json').write_text(json.dumps({'cases':rows},separators=(',',':'))+'\n')
print('cases',len(rows))
for row in rows:
    if row['group']=='initialization' and row['chunk']==0:
        print(bytes.fromhex(row['external_data']['p']),row['children'],[(e[3],e[5])for e in row['events']if e[1]=='entity' and e[3]in('e','after')])
    elif row['group']=='handlers' and bytes.fromhex(row['external_data']['p'])==b'X':
        print(row['entity_handler'],row['external_handler'],row['action'],[(e[0],e[1],e[3:]) for e in row['events']if e[0]=='d'])
