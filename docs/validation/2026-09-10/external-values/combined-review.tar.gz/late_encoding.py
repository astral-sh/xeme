from pathlib import Path
import json,hashlib
ns={};exec(Path('/tmp/oriole-external-value-review/reference.py').read_text().split('rows=[]')[0],ns)
source=ns['source'].replace('START = c.CFUNCTYPE', 'class MAP(c.Structure):\n    _fields_=[("map", I*256),("data",P),("convert",P),("release",P)]\nUNKNOWN=c.CFUNCTYPE(I,P,S,c.POINTER(MAP))\nSTART = c.CFUNCTYPE')
source=source.replace("('XML_ParserCreate', P, [S]),", "('XML_SetUnknownEncodingHandler',None,[P,UNKNOWN,P]),\n    ('XML_ParserCreate', P, [S]),")
source=source.replace('l.XML_SetParamEntityParsing(parent, 2)', '''def unknown(_, name, info):
        event('unknown', decode(name))
        for i in range(256): info.contents.map[i]=i
        return 1
    unknown_cb=UNKNOWN(unknown)
    l.XML_SetUnknownEncodingHandler(parent,unknown_cb,None)
    l.XML_SetParamEntityParsing(parent, 2)''')
norm={};exec(Path('/tmp/oriole-default-declarations/compare.py').read_text().split('rows=[]')[0],norm)
libs=['/home/dev-user/.cache/oriole/expat-build/libexpat.so','/home/dev-user/.cache/oriole/external-values-target/debug/liboriole_expat.so']
scopes=[]
for lib in libs:
 scope={};exec(source.replace(libs[0],lib),scope);scopes.append(scope)
rows=[]
for prefix in (b'',b' ',b'<!--old-->'):
 for encoding in ('UTF-8','ISO-8859-1','x-custom'):
  for value in (b'X',b'\xe9'):
   for chunk in (0,1,3):
    data=prefix+f'<?xml version="1.0" encoding="{encoding}"?>'.encode()+value
    args=(None,2,b'<!ENTITY % p SYSTEM "p"><!ENTITY e "L%p;R"><!ENTITY after "A">',data,'parse',chunk)
    a,b=[norm['norm'](s['probe'](*args))for s in scopes]
    rows.append({'prefix':prefix.decode(),'encoding':encoding,'value':value.hex(),'chunk':chunk,'reference':a,'candidate':b,'match':a==b})
report={'libraries':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in libs},'cases':len(rows),'differences':sum(not r['match'] for r in rows),'rows':rows}
Path('/tmp/oriole-external-value-review/late-encoding-custom-first.json').write_text(json.dumps(report,separators=(',',':'))+'\n')
print('cases',report['cases'],'differences',report['differences'])
for r in rows:
 if not r['match'] and r['chunk']==0:print(json.dumps(r))
