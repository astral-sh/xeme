from pathlib import Path
import json,hashlib
HERE=Path(__file__).resolve().parent
matrix=json.loads((HERE/'merge-first.json').read_text())
base={};exec((HERE/'reference.py').read_text().split('rows=[]')[0],base)
normalize={};exec(Path('/tmp/oriole-default-declarations/compare.py').read_text().split('rows=[]')[0],normalize)
library='/home/dev-user/.cache/oriole/default-declarations-target/debug/liboriole_expat.so'
scopes={};rows=[]
for row in matrix['rows']:
 if row['reference']['status']!=0:continue
 # No failed case reaches the external value, so install/remove actions cannot run.
 assert all(child[0]!='p' for child in row['candidate']['children'])
 handler=row['handler']
 if handler not in scopes:
  code=base['source'].replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so',library)
  if not handler:code=code.replace('l.XML_SetEntityDeclHandler(parent, callbacks[3])','pass')
  scopes[handler]={};exec(code,scopes[handler])
 data='<!ENTITY % p SYSTEM "p"><!ENTITY % i "I">'+matrix['bodies'][row['body']]+'<!ENTITY after "A"><!ATTLIST r a CDATA "yes">'
 got=scopes[handler]['probe'](row['standalone'],row['mode'],data.encode(),b'X',row['action'],row['chunk'])
 got=json.loads(json.dumps(normalize['norm'](got)))
 rows.append({k:row[k]for k in ('body','standalone','mode','action','chunk','handler','change')}|{'matches_baseline':got==row['candidate']})
report={'library':library,'sha256':hashlib.sha256(Path(library).read_bytes()).hexdigest(),'cases':len(rows),'matches_baseline':sum(row['matches_baseline']for row in rows),'rows':rows}
(HERE/'merge-malformed-baseline.json').write_text(json.dumps(report,separators=(',',':'))+'\n')
print(report['cases'],report['matches_baseline'])
