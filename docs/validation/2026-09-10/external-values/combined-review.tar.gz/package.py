from pathlib import Path
import difflib,hashlib,json
base=Path('/tmp/oriole-combined-dtd');src=Path('/tmp/oriole-external-values');out=Path('/tmp/oriole-external-values-handoff');out.mkdir(exist_ok=True)
primitive=['crates/oriole_storage/src/lib.rs','crates/oriole_storage/src/tests.rs','crates/oriole_storage/src/try_lock.rs']
values=['crates/oriole/src/dtd.rs','crates/oriole/src/lib.rs','crates/oriole/src/value.rs','crates/oriole/src/value_lexer.rs','crates/oriole/tests/allocation.rs','crates/oriole/tests/external_values.rs','crates/oriole/tests/parameter_values.rs','crates/oriole_expat/README.md','crates/oriole_expat/src/lib.rs','crates/oriole_expat/src/tests.rs','crates/oriole_expat/tests/memory.rs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'base':str(base),'candidate':str(src),'library':'/home/dev-user/.cache/oriole/external-values-target/debug/liboriole_expat.so','library_sha256':sha(Path('/home/dev-user/.cache/oriole/external-values-target/debug/liboriole_expat.so')),'patches':{}}
for name,files in [('try-lock',primitive),('external-values',values)]:
 chunks=[]
 for file in files:
  before=base/file;after=src/file
  chunks.append(f'diff --git a/{file} b/{file}\n')
  if not before.exists(): chunks.append('new file mode 100644\n')
  chunks.extend(difflib.unified_diff(before.read_text().splitlines(keepends=True) if before.exists() else [],after.read_text().splitlines(keepends=True),fromfile=f'a/{file}' if before.exists() else '/dev/null',tofile=f'b/{file}'))
 patch=out/f'{name}.patch';patch.write_text(''.join(chunks))
 manifest['patches'][name]={'path':str(patch),'sha256':sha(patch),'files':{file:{'base':sha(base/file) if (base/file).exists() else None,'candidate':sha(src/file)} for file in files}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name,entry in manifest['patches'].items(): print(entry['path'],entry['sha256'],len(entry['files']))
print('manifest',sha(out/'manifest.json'))
