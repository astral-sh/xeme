from pathlib import Path
import json
scope={};exec(Path('/tmp/oriole-external-value-review/reference.py').read_text().split('rows=[]')[0],scope)
rows=[]
for content in [b'"a&#0;b"',b'"a&bad b;z"',b'"a%b;z"',b'"a%missing;z"',b'"a&#65;z"',b'X%q;Y']:
 for standalone in [None,'yes']:
  for chunk in [0,1,3]:
   r=scope['probe'](standalone,2,scope['PREFIX']+scope['BODY'],{'p':content,'q':b'"Q&#0;Z"'},'ignore-error',chunk);rows.append(r)
Path('/tmp/oriole-external-value-review/partial_values.json').write_text(json.dumps({'cases':rows},indent=2)+'\n')
for r in rows:
 if r['chunk']==0:print(bytes.fromhex(r['external_data']['p']),r['standalone'],r['children'],[e[3:6] for e in r['events'] if e[1]=='entity' and e[3] in ['e','after']])
