from pathlib import Path
import hashlib
import json

source = Path('/tmp/oriole-external-pe-review/probe.py').read_text().split("if __name__ == '__main__':")[0]
source = source.replace("child = l.XML_ExternalEntityParserCreate(parser, context, None)", "child = l.XML_ExternalEntityParserCreate(parser, context, b'BOGUS' if name != 'd' and action == 'bad-encoding' else None)")
source = source.replace("content = data if name == 'd' else b'' if action == 'empty' else external_data", "content = data if name == 'd' else b'' if action in ('empty', 'empty-nonfinal') else external_data.get(name, b'') if isinstance(external_data, dict) else external_data")
source = source.replace("for start in range(0, max(len(content), 1), width):", "for start in ([] if name != 'd' and action == 'create-only' else range(0, max(len(content), 1), width)):")
source = source.replace("int(start+width>=len(content))", "int(start+width>=len(content) and not (name != 'd' and action in ('empty-nonfinal', 'unfinished')))")
source = source.replace("return int(status != 0)", "return 0 if name != 'd' and action == 'reject' else 1 if name != 'd' and action in ('ignore-error', 'bad-encoding') else int(status != 0)")
source = source.replace("'external_data':external_data.decode(errors='backslashreplace')", "'external_data':{k: v.hex() for k,v in external_data.items()} if isinstance(external_data, dict) else external_data.hex()")
namespace = {}
exec(source, namespace)
probe = namespace['probe']

DECL = b'<?xml version="1.0" encoding="UTF-8"?>'
PREFIX = b'<!ENTITY % p SYSTEM "p"><!ENTITY % q SYSTEM "q"><!ENTITY % i "I">'
BODY = b'<!ENTITY e "L%p;R"><!ENTITY after "A"><!ATTLIST r a CDATA "yes">'
CASES = [
    b'', b'X', b'X Y', b'X\r\nY', b'"', b"'", b'"x"', b"'x'", b'X"', b'X"x"',
    b'<a>', b'</a>', b'<', b'<!', b'<!ENTITY x "X">', b'<!ELEMENT r ANY>',
    b'<!BAD ???>', b'<![CDATA[x]]>', b'<![IGNORE[x]]>', b'<!--ok-->', b'<!--bad--x>',
    b'<?pi?>', b'<?pi bad?>', b'<?xml encoding="UTF-8"?>X',
    b'<?xml version="1.0"?>X', b'<?xml version="1.0" standalone="yes"?>X',
    b'&amp;', b'X&amp;', b' &amp;', b'"&amp;"', b'&#65;', b'"&#65;"', b'&#0;',
    b'%i;', b'X%i;', b'%missing;', b'%p;', b'%q;', b'%', b'%q', b'%q x;',
    b']', b']]>', b'[', b'>', b'=', b'/', b'?', b'*', b'+', b'|', b'(', b')',
    b'X\x00', b'X\xc3', b'X\xff', '名'.encode(),
]

rows=[]
for index, replacement in enumerate(CASES):
    for prefixed in (False, True):
        content = (DECL if prefixed else b'') + replacement
        for chunk in (0, 1, 3):
            row=probe(None, 2, PREFIX+BODY, {'p': content, 'q': b'Q'}, 'parse', chunk)
            row.update(group='lexical', case=index, prefixed=prefixed)
            rows.append(row)

for action in ('parse', 'skip', 'empty', 'empty-nonfinal', 'create-only', 'unfinished', 'bad-encoding', 'ignore-error', 'reject'):
    for standalone in (None, 'yes'):
        for mode in (0, 1, 2):
            for replacement in (b'X', b'%', DECL+b'X%i;Y', DECL+b'X%missing;Y'):
                row=probe(standalone, mode, PREFIX+BODY, {'p':replacement, 'q':b'Q'}, action, 1)
                row.update(group='lifecycle')
                rows.append(row)

for p in (b'%q;', b'X%q;Y', DECL+b'X%q;Y'):
    for q in (b'Q', b'%p;', b'%q;', b'%missing;', b'&amp;', DECL+b'&amp;', b'"'):
        for chunk in (0, 1):
            row=probe(None, 2, PREFIX+BODY, {'p':p, 'q':q}, 'parse', chunk)
            row.update(group='nested')
            rows.append(row)

output={'library':str(namespace['LIB']), 'sha256':hashlib.sha256(namespace['LIB'].read_bytes()).hexdigest(), 'cases':rows}
Path('/tmp/oriole-external-value-review/reference.json').write_text(json.dumps(output, separators=(',',':'))+'\n')
print('cases',len(rows))
for row in rows:
    if row['group']=='lexical' and row['chunk']==0:
        child=next(x for x in row['children'] if x['name']=='p')
        entities=[e[3:6] for e in row['events'] if e[0]=='d' and e[1]=='entity' and e[3] in ('e','after')]
        print(row['case'],row['prefixed'],repr(bytes.fromhex(row['external_data']['p'])), child['error'], entities)
