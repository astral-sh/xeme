#![allow(dead_code)]
use std::io::{self, BufRead};
#[derive(Debug, PartialEq, Eq, Clone, Copy)]
enum ErrorKind { Syntax, InvalidToken, UnclosedToken }
#[path="/tmp/oriole-declaration-tokens/crates/oriole/src/names.rs"]
mod names;
#[path="/tmp/oriole-external-value-review/value_lexer.rs"]
mod value_lexer;
use value_lexer::{ValueScan, ValueScanner};
fn main() {
    for line in io::stdin().lock().lines() {
        let line=line.unwrap();
        let mut parts=line.split(' ');
        let namespaces=parts.next().unwrap()=="1";
        let width:usize=parts.next().unwrap().parse().unwrap();
        let hex=parts.next().unwrap();
        let bytes:Vec<u8>=(0..hex.len()).step_by(2).map(|i|u8::from_str_radix(&hex[i..i+2],16).unwrap()).collect();
        let text=std::str::from_utf8(&bytes).unwrap();
        let mut scanner=ValueScanner::new();
        let mut error=None;
        for end in (1..=text.len()).filter(|end|text.is_char_boundary(*end) && (*end % width==0 || *end==text.len())).chain(std::iter::once(text.len())) {
            loop {
                match scanner.scan(&text[..end],end==text.len(),namespaces) {
                    Ok(ValueScan::XmlDeclaration{..})=>{},
                    Ok(_)=>break,
                    Err(e)=>{error=Some(e);break;}
                }
            }
            if error.is_some(){break;}
        }
        match error {
            Some((kind,index))=>println!("{} {}",match kind{ErrorKind::Syntax=>2,ErrorKind::InvalidToken=>4,ErrorKind::UnclosedToken=>5},index),
            None=>println!("0 0"),
        }
    }
}
