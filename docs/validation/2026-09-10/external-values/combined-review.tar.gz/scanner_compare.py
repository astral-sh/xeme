import ctypes as c
import hashlib
import itertools
import json
import subprocess
from pathlib import Path

base=Path('/tmp/oriole-external-value-review')
lib=c.CDLL(str(base/'token-oracle.so'))
lib.value_tokens.argtypes=[c.c_char_p,c.c_size_t,c.c_int,c.c_int,c.POINTER(c.c_size_t)]
lib.value_tokens.restype=c.c_int
alphabet='a0:-._<>!?%#&;\'"[]()*+|, '
cases={''.join(xs) for length in range(4) for xs in itertools.product(alphabet,repeat=length)}
tokens=['a','a:b','a::b','a:','0','a*','0*','#PCDATA','%p;','% p','<!ENTITY','<!A%p;','<!A% p','<!A_%p;','<!A: ','<!名 ',"'x'",'"&amp;"','<!--x-->','<?pi?>','<?xml?>','<?XML?>',']',']]',']]>','(',')',' ']
for first in tokens:
    for second in tokens:
        cases.add(first+second)
        cases.add(first+' '+second)
for character in ['名','文字','é','\u0300','\u200c','\U00010000','\ufeff','\x00','\t','\r','\n']:
    for token in tokens:
        cases.add(character+token)
        cases.add(token+character)
cases=sorted(cases)
specs=[]
reference=[]
for text in cases:
    data=text.encode()
    for namespaces in (False,True):
        position=c.c_size_t()
        error=lib.value_tokens(data,len(data),namespaces,1,c.byref(position))
        for width in (1,max(len(data),1)):
            specs.append((text,namespaces,width))
            reference.append((error,position.value))
payload=''.join(f'{int(ns)} {width} {text.encode().hex()}\n'for text,ns,width in specs)
result=subprocess.run([str(base/'scanner-cli')],input=payload,text=True,capture_output=True,check=True)
actual=[tuple(map(int,line.split()))for line in result.stdout.splitlines()]
assert len(actual)==len(reference)
differences=[]
for spec,want,got in zip(specs,reference,actual):
    if want[0]!=got[0] or (want[0] and want[1]!=got[1]):
        differences.append({'text':spec[0],'namespaces':spec[1],'width':spec[2],'reference':want,'candidate':got})
report={'cases':len(specs),'different':len(differences),'candidate_sha256':hashlib.sha256((base/'value_lexer.rs').read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256((base/'token-oracle.so').read_bytes()).hexdigest(),'differences':differences}
(base/'scanner-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print('cases',len(specs),'differences',len(differences))
for row in differences[:100]:print(row)
