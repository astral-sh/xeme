#![allow(dead_code)]
#[derive(Debug,PartialEq,Eq,Clone,Copy)]
enum ErrorKind { Syntax, InvalidToken, UnclosedToken }
#[path="/tmp/oriole-declaration-tokens/crates/oriole/src/names.rs"]
mod names;
#[path="/tmp/oriole-external-value-review/value_lexer.rs"]
mod value_lexer;
