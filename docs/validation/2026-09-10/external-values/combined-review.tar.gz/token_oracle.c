#include "expat_config.h"
#include "internal.h"
#include "xmltok.h"
#include <stddef.h>

int value_tokens(const char *text, size_t length, int namespaces, int final,
                 size_t *position) {
  const ENCODING *encoding = namespaces ? XmlGetUtf8InternalEncodingNS()
                                       : XmlGetUtf8InternalEncoding();
  const char *start = text, *end = text + length, *next = text;
  for (;;) {
    const int token = XmlPrologTok(encoding, start, end, &next);
    *position = (size_t)(start - text);
    if (token <= 0) {
      if (!final && token != XML_TOK_INVALID)
        return -1;
      switch (token) {
      case XML_TOK_INVALID: return 4;
      case XML_TOK_PARTIAL: return 5;
      case XML_TOK_PARTIAL_CHAR: return 6;
      default: return 0;
      }
    }
    if (token == XML_TOK_INSTANCE_START)
      return 2;
    start = next;
  }
}
