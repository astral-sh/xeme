from pathlib import Path
import subprocess,os,json,collections,hashlib
root=Path('/tmp/oriole-external-value-review')
exe=Path('/home/dev-user/.cache/oriole/upstream-api/newfeatures-final/runtests')
names=['test_external_entity_values','test_ext_entity_value_abort','test_empty_ext_param_entity_in_value','test_ext_entity_not_standalone','test_skipped_parameter_entity','test_recursive_external_parameter_entity','test_recursive_external_parameter_entity_2','test_standalone_parameter_entity','test_undefined_ext_entity_in_external_dtd','test_param_entity_with_trailing_cr','test_suspend_resume_parameter_entity','test_reject_unfinished_param_in_att_value']
rows={}
for name,lib in [('reference','/home/dev-user/.cache/oriole/expat-build/libexpat.so'),('header_baseline','/home/dev-user/.cache/oriole/external-parameter-context-target/debug/liboriole_expat.so'),('candidate','/home/dev-user/.cache/oriole/external-values-target/debug/liboriole_expat.so')]:
 env=dict(os.environ,LD_PRELOAD=lib,ORIOLE_CHUNK_MASK='63',ORIOLE_DEFERRAL_MASK='3',ORIOLE_SELECTED_TESTS=','.join(names),ORIOLE_TEST_TIMEOUT='3',ORIOLE_MEMORY_MIB='1024',ORIOLE_RSS_MIB='768')
 run=subprocess.run(['taskset','-c','3',str(exe)],env=env,capture_output=True,text=True,timeout=180)
 log=run.stdout+run.stderr
 (root/f'upstream-{name}.log').write_text(log)
 results=[line.split('\t')[1:] for line in log.splitlines() if line.startswith('ORIOLE_RESULT\t')]
 origin=[line.split('\t')[1] for line in log.splitlines() if line.startswith('ORIOLE_LIBRARY')]
 assert origin==[lib],origin
 rows[name]={'library':lib,'sha256':hashlib.sha256(Path(lib).read_bytes()).hexdigest(),'origin':origin,'status':run.returncode,'results':results,'counts':dict(collections.Counter(r[2] for r in results))}
 print(name,rows[name]['counts'],flush=True)
(root/'upstream-values.json').write_text(json.dumps({'runner':str(exe),'runner_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'tests':names,'runs':rows},indent=2)+'\n')
