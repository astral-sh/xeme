from pathlib import Path
import json
root=Path('/tmp/oriole-external-value-review')
base={};exec((root/'reference.py').read_text().split('rows=[]')[0],base)
libs={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','header_baseline':'/home/dev-user/.cache/oriole/external-parameter-context-target/debug/liboriole_expat.so','candidate':'/home/dev-user/.cache/oriole/external-values-target/debug/liboriole_expat.so'}
scopes={}
for name,lib in libs.items():
 scope={};exec(base['source'].replace(libs['reference'],lib),scope);scopes[name]=scope
cases=[b"<!ATTLIST doc a1 CDATA 'value'>",b"<!ATTLIST $doc a1 CDATA 'value'>",b"'wombat",b'\xe2\x82',b"<?xml version='1.0' encoding='utf-8'?>\n",b'<?xml?>',b"\xef\xbb\xbf<!ATTLIST doc a1 CDATA 'value'>",b"<?xml version='1.0' encoding='utf-8'?>\n$",b"<?xml version='1.0' encoding='utf-8'?>\n'wombat",b"<?xml version='1.0' encoding='utf-8'?>\n\xe2\x82",b'%p;']
rows=[]
for i,data in enumerate(cases):
 for chunk in (0,1):
  runs={name:scope['probe'](None,2,b"<!ENTITY % p SYSTEM 'p'><!ENTITY e '%p;'>%p;",{'p':data},'ignore-error',chunk) for name,scope in scopes.items()}
  row={'case':i,'input':data.hex(),'chunk':chunk,'runs':runs};rows.append(row)
  print(i,chunk,{name:[(r['name'],r['status'],r['error']) for r in run['children']] for name,run in runs.items()})
(root/'upstream-value-cases.json').write_text(json.dumps(rows,indent=2)+'\n')
