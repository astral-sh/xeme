# External parameter entities in entity values

Candidate: `a55b41c90c5ba9448311b0640e6e1fdc37bac3605d6c5fdceb0578ad752052a0`.
Source: `/tmp/oriole-external-values`; base: `/tmp/oriole-combined-dtd`.

## Two review layers

1. `try-lock.patch`: an allocation-free, nonblocking exclusive lock in the storage crate. A single Acquire compare-exchange grants access; the guard releases it with Release ordering. Guard trait bounds prevent sharing a non-Sync payload. Tests cover contention, cross-thread guard movement, unwinding, payload destruction, allocator failure, and the negative Sync bound. This replaces a draft standard mutex that could allocate globally on macOS.
2. `external-values.patch`: owned entity-value continuations, a separate external value-child lexer and output channel, inherited recursion/depth accounting, read/skip state, first-declaration behavior, and handler-aware raw prefix/suffix events. The core performs no I/O and introduces no unsafe code. Child input remains separate, append-only during lexical preflight; output contains owned text and state only.

The value patch shares `EntityDeclarationPrefix`, `EntityDeclarationDuplicate`, and duplicate Default filtering with the parallel ordinary-declaration Default layer. When merging, retain that layer's Attlist prefix and raw partitioning. Both patches pass a zero-fuzz dry run against their recorded base. `manifest.json` contains each base/candidate file hash and patch hash.

## Validation

- 201 storage/core/C-adapter tests pass, including every-allocation failure injection, custom allocator routing, rejected allocation-callback reentry, custom multibyte recovery, once-only encoding release, parent suspension/resume, abort, dynamic handler changes, and duplicate declarations.
- Formatting and scoped strict Clippy pass.
- Independent review: 18,468 complete cases with no status, error, or normalized event differences. The matrix covers every child byte width in UTF-8/UTF-16LE/UTF-16BE, all parameter modes, standalone absent/yes, handlers absent/present, duplicate and missing declarations, nested external references, Unicode, quotes, references, and CR handling.
- Primary reference matrix: 787/788 family status/error sequences match. All 481 completed successful cases have matching normalized events. The remaining full-event differences and acceptance boundary are listed below.
- Twelve focused upstream tests across twelve chunk/deferral configurations: reference 144/144 pass, accepted header baseline 108/144, candidate 132/144. The layer fixes `test_ext_entity_value_abort` and `test_empty_ext_param_entity_in_value`. The remaining test proceeds past value processing into existing ordinary external-DTD lexical diagnostics; all eleven extracted value-child inputs match at two chunk widths.
- The lexer additionally has the independent 73,360-case tokenizer comparison and root's 50,000 random-case extension. The former retains the known XML Fifth Edition name repertoire differences from Expat's older tables.

## Retained differences

The primary matrix retains one pre-existing fragmented X-NUL autodetection difference, 279 missing partial parent EntityDecl callbacks after external callback failure, and twelve unfinished-input XML-declaration callback timing differences. Byte positions and root NotStandalone timing are excluded from normalized event comparisons.

The final supplemental 54-case encoding matrix retains 24 acceptance differences when the first encoding declaration appears after whitespace, a comment, or other value content. Encoding declarations must appear first (apart from a BOM) in this layer. Six leading custom-encoding cases also differ in XML-declaration versus unknown-encoding handler order, and nine malformed UTF-8 cases share the partial-parent callback limitation. These boundaries are documented in the core and C README; no decoder rewind or failed-callback dispatch channel was added.

Pinned Expat truncates an external value child's contribution at an internal parameter reference; this layer reproduces that behavior. External references between declaration grammar tokens and declaration delimiters split across entities remain unsupported.

`validation.json`, `evidence-manifest.json`, and the compressed raw observations preserve the exact scopes, counts, sources, and review hashes. This handoff does not claim complete Expat compatibility.
