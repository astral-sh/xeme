from pathlib import Path
import collections,difflib,hashlib,json,re,shutil
base=Path('/tmp/oriole-upstream-grammar-combined');diag=Path('/tmp/oriole-grammar-allocation-audit');extra=Path('/tmp/oriole-grammar-allocation-extra');stage=Path('/tmp/oriole-nested-allocation-stage');out=Path('/tmp/oriole-allocation-independent-handoff');out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();report=json.loads((diag/'report.json').read_text());comparison=json.loads((diag/'comparison.json').read_text());original=json.loads((base/'results.json').read_text());issues=[]
def check(condition,label):
 if not condition:issues.append(label)
check(report['original_matrix_sha256']==sha(base/'results.json'),'original full matrix changed')
check(report['overlay_sha256']==sha(diag/'retry-ceilings.patch')==sha(diag/'applied.patch'),'overlay hashes differ')
check(report['library_sha256']==sha(diag/'liboriole_expat.so')=='ff5d86621114e464a0b20f108b6308fe155d9e8c87bd764bc00872cf124750f8','library mismatch')
changed=[];changes=0
for name,expected in report['adapted_sources'].items():
 p=diag/'adapted'/name;q=base/'adapted'/name;check(sha(p)==expected,'diagnostic source hash: '+name)
 if p.read_bytes()!=q.read_bytes():
  changed.append(name)
  normalize=lambda s:re.sub(r'(\b(?:max_(?:re)?alloc_count|max_allocation_count|alloc_test_max_repeats)\s*=\s*)\d+;',r'\1<ceiling>;',s)
  check(normalize(p.read_text())==normalize(q.read_text()),'non-ceiling source change: '+name)
  changes+=sum(line.startswith('+')and not line.startswith('+++')for line in difflib.unified_diff(q.read_text().splitlines(),p.read_text().splitlines()))
check(set(changed)=={'alloc_tests.c','nsalloc_tests.c'},'changed source set')
check(report['patch_exit_code']==report['build_exit_code']==0 and report['selection_complete']and report['library_origin_verified']and report['library_unchanged'],'diagnostic completion flags')
old={(r['context'],r['test']):r for r in original['results']};rows=report['results'];fixed=sum(old[(r['context'],r['test'])]['outcome']!='pass'and r['outcome']=='pass'for r in rows);new=sum(old[(r['context'],r['test'])]['outcome']=='pass'and r['outcome']!='pass'for r in rows)
check(len(rows)==696 and fixed==554 and new==0 and report['passed']==620 and report['failed']==76,'diagnostic comparison counts')
classifications={
 'test_misc_alloc_create_parser_with_encoding':{'contexts':12,'assertion':'Parser not created with max allocation count','classification':'Retry ceiling in misc_tests.c remained10 because the published overlay covers only alloc_tests.c/nsalloc_tests.c. Separate ceiling512 replay passes all12 contexts with all assertions unchanged.'},
 'test_alloc_nested_entities':{'contexts':12,'assertion':'Could not create external entity parser','classification':'The fixed successful-malloc budget12 targets an Expat-specific stage. Expat reaches child parse and reports NoMemory; Oriole exhausts its budget while creating that child. Both parent parses return ExternalEntityHandling21. The exact DTD succeeds without injection in all12 contexts for both libraries, with zero live selected allocations after cleanup.'},
 'test_nsalloc_parse_buffer':{'contexts':12,'assertion':'Pre-init XML_ParseBuffer not faulted, at the second call after XML_GetBuffer','classification':'Requires empty parse initialization to allocate after a buffer exists; Oriole succeeds without that additional malloc. First NO_BUFFER guard is not the failing assertion.'},
 'test_nsalloc_realloc_attributes':{'contexts':10,'assertion':'i == 0 under XML_GE == 1','classification':'Asserts no reallocation is needed because Expat realloc partly uses malloc. Oriole requires reallocation for some chunk widths; two contexts already pass.'},
 'test_nsalloc_realloc_binding_uri':{'contexts':2,'assertion':'Parsing worked despite failing reallocation','classification':'Requires at least one realloc at this input/chunk arrangement. Oriole can finish without realloc in two contexts; ten contexts pass.'},
 'test_nsalloc_realloc_long_prefix':{'contexts':2,'assertion':'Parsing worked despite failing reallocations','classification':'Requires at least one realloc at this input/chunk arrangement. Oriole can finish without realloc in two contexts; ten contexts pass.'},
 'test_nsalloc_realloc_longer_prefix':{'contexts':2,'assertion':'Parsing worked despite failing reallocations','classification':'Requires at least one realloc at this input/chunk arrangement. Oriole can finish without realloc in two contexts; ten contexts pass.'},
 'test_alloc_realloc_buffer':{'contexts':12,'assertion':'Parse succeeded with no reallocation','classification':'Requires at least one realloc after the chosen initial buffer allocation. Oriole completes this path without that realloc.'},
 'test_alloc_ext_entity_realloc_buffer':{'contexts':12,'assertion':'Succeeded with no reallocations','classification':'Requires at least one realloc in the chosen external entity buffer path. Oriole completes this path without that realloc.'},
}
check(set(classifications)==set(comparison['failed_tests'])and sum(x['contexts']for x in classifications.values())==76,'classification coverage')
summary={'reviewer':'/root/ffi/multibyte_fuzz','issues':issues,'scope':'Separate diagnosis; no original upstream outcome, runtime, or assertion was removed or replaced. The unchanged original matrix remains3753passes/987failures. These results are not reported as a newly passing full matrix.','ceiling_overlay':{'changed_files':changed,'changed_constants':changes,'selected_cases':len(rows),'pass':620,'fail':76,'original_failures_now_pass':fixed,'new_failures':new},'remaining_assertions':classifications,'misc_followup':json.loads((extra/'misc-report.json').read_text()),'nested_stage':json.loads((stage/'report.json').read_text())}
(out/'review.json').write_text(json.dumps(summary,indent=2)+'\n')
for p in [diag/'report.json',diag/'comparison.json',diag/'retry-ceilings.patch',diag/'patch.log',diag/'build.log',extra/'misc-report.json',extra/'misc-retry-ceiling.patch',Path('/tmp/oriole-prepare-allocation-extra.py'),Path('/tmp/oriole-nested-allocation-stage.c'),Path('/tmp/oriole-run-nested-allocation-stage.py'),Path('/tmp/oriole-audit-allocation-diagnosis.py')]:shutil.copyfile(p,out/(('diagnostic-'if p.parent==diag else '')+p.name))
for folder,name in [(extra,'misc'),(stage,'nested')]:
 d=out/name;d.mkdir(exist_ok=True)
 for p in folder.iterdir():
  if p.is_file()and p.suffix in('.json','.log','.patch'):shutil.copyfile(p,d/p.name)
(out/'artifact-manifest.json').write_text(json.dumps({str(p.relative_to(out)):sha(p)for p in out.rglob('*')if p.is_file()and p.name!='artifact-manifest.json'},indent=2)+'\n')
print(json.dumps({'issues':issues,'changed_constants':changes,'artifact':str(out),'manifest_sha256':sha(out/'artifact-manifest.json')}))
if issues:raise SystemExit(1)
