#include <expat.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int budget, width, deferral, callback_seen, child_created;
static int remaining_at_callback, child_status, child_error;
static unsigned malloc_calls, realloc_calls, failed_mallocs;
static long live;
static void *allocate(size_t size) {
  malloc_calls++;
  if (budget == 0) { failed_mallocs++; return NULL; }
  if (budget > 0) budget--;
  void *p = malloc(size);
  if (p) live++;
  return p;
}
static void *resize(void *p, size_t size) {
  realloc_calls++;
  int had_pointer = p != NULL;
  void *result = realloc(p, size);
  if (!had_pointer && result) live++;
  if (had_pointer && size == 0 && !result) live--;
  return result;
}
static void release(void *p) { if (p) live--; free(p); }
static int feed(XML_Parser p, const char *input) {
  size_t n = strlen(input), position = 0, step = width ? (size_t)width : n;
  do {
    size_t count = n - position < step ? n - position : step;
    int result = XML_Parse(p, input + position, (int)count, position + count == n);
    if (result != XML_STATUS_OK) return result;
    position += count;
  } while (position < n);
  return XML_STATUS_OK;
}
#define BLOCK "ABCDEFGHIJKLMNOPABCDEFGHIJKLMNOPABCDEFGHIJKLMNOPABCDEFGHIJKLMNOP"
static const char payload[] = "<!ENTITY % pe1 '"
  BLOCK BLOCK BLOCK BLOCK BLOCK BLOCK BLOCK BLOCK
  BLOCK BLOCK BLOCK BLOCK BLOCK BLOCK BLOCK BLOCK
  "'>\n<!ENTITY % pe2 '%pe1;'>\n<!ENTITY % pe3 '%pe2;'>";
static int external(XML_Parser parent, const XML_Char *context,
                    const XML_Char *base, const XML_Char *system,
                    const XML_Char *public_id) {
  (void)base; (void)system; (void)public_id;
  callback_seen++;
  remaining_at_callback = budget;
  XML_Parser child = XML_ExternalEntityParserCreate(parent, context, NULL);
  child_created = child != NULL;
  if (!child) return XML_STATUS_ERROR;
  child_status = feed(child, payload);
  child_error = XML_GetErrorCode(child);
  XML_ParserFree(child);
  return child_status == XML_STATUS_OK;
}
int main(void) {
  const XML_Memory_Handling_Suite suite = {allocate, resize, release};
  const char document[] = "<!DOCTYPE doc SYSTEM 'http://example.org/one.ent'>\n<doc />";
  printf("{\"version\":\"%s\",\"payload_bytes\":%zu,\"rows\":[", XML_ExpatVersion(), strlen(payload));
  int first = 1;
  for (int configured = 12; configured >= -1; configured -= 13) {
    for (width = 0; width < 6; width++) for (deferral = 0; deferral < 2; deferral++) {
      budget = -1; live = 0; malloc_calls = realloc_calls = failed_mallocs = 0;
      callback_seen = child_created = 0; child_status = child_error = -1; remaining_at_callback = -2;
      XML_Parser root = XML_ParserCreate_MM(NULL, &suite, NULL); assert(root);
      XML_SetReparseDeferralEnabled(root, deferral);
      unsigned creation_mallocs = malloc_calls;
      budget = configured;
      XML_SetParamEntityParsing(root, XML_PARAM_ENTITY_PARSING_ALWAYS);
      XML_SetExternalEntityRefHandler(root, external);
      int status = feed(root, document), error = XML_GetErrorCode(root);
      XML_ParserFree(root);
      printf("%s{\"budget\":%d,\"width\":%d,\"deferral\":%d,\"root_status\":%d,\"root_error\":%d,\"callbacks\":%d,\"remaining_at_callback\":%d,\"child_created\":%d,\"child_status\":%d,\"child_error\":%d,\"creation_mallocs\":%u,\"malloc_calls\":%u,\"realloc_calls\":%u,\"failed_mallocs\":%u,\"live_after_free\":%ld}", first ? "" : ",", configured, width, deferral, status, error, callback_seen, remaining_at_callback, child_created, child_status, child_error, creation_mallocs, malloc_calls, realloc_calls, failed_mallocs, live);
      first = 0; assert(live == 0);
    }
  }
  puts("]}");
}
