from pathlib import Path
import shutil,json,hashlib,difflib,subprocess,os,time
base=Path('/tmp/oriole-grammar-allocation-audit');out=Path('/tmp/oriole-grammar-allocation-extra');out.mkdir(exist_ok=False)
shutil.copytree(base/'adapted',out/'adapted');shutil.copytree(base/'lib',out/'lib');shutil.copyfile(base/'liboriole_expat.so',out/'liboriole_expat.so')
p=out/'adapted/misc_tests.c';old=p.read_text();start=old.index('START_TEST(test_misc_alloc_create_parser_with_encoding)');end=old.index('END_TEST',start);fragment=old[start:end];assert fragment.count('max_alloc_count = 10;')==1
new=old[:start]+fragment.replace('max_alloc_count = 10;','max_alloc_count = 512;')+old[end:];p.write_text(new)
(out/'misc-retry-ceiling.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/adapted/misc_tests.c',tofile='b/adapted/misc_tests.c')))
report=json.loads((base/'report.json').read_text());command=[x.replace(str(base),str(out))for x in report['compile_command']]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record={'scope':'Separate 12-context diagnosis; change only the misc parser-construction retry ceiling 10 to512, retain all assertions. Original matrix and root diagnostic overlay remain unchanged.','library_sha256':sha(out/'liboriole_expat.so'),'original_misc_sha256':sha(base/'adapted/misc_tests.c'),'modified_misc_sha256':sha(p),'patch_sha256':sha(out/'misc-retry-ceiling.patch'),'compile_command':command}
with(out/'build.log').open('w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
record['build_exit_code']=r.returncode;assert r.returncode==0
record['binary_sha256']=sha(out/'runtests');env={**os.environ,**report['environment'],'ORIOLE_SELECTED_TESTS':'test_misc_alloc_create_parser_with_encoding'};record['test_environment']={k:v for k,v in env.items()if k.startswith('ORIOLE_')}
with(out/'tests.log').open('w')as log:r=subprocess.run([str(out/'runtests')],stdout=log,stderr=subprocess.STDOUT,timeout=60,env=env)
record['run_exit_code']=r.returncode
rows=[]
for line in(out/'tests.log').read_text().splitlines():
 if line.startswith('ORIOLE_RESULT\t'):
  _,context,name,outcome,code=line.split('\t');rows.append(dict(context=context,test=name,outcome=outcome,code=int(code)))
record['results']=rows;record['passed']=sum(r['outcome']=='pass'for r in rows);record['failed']=sum(r['outcome']!='pass'for r in rows);record['library_unchanged']=sha(out/'liboriole_expat.so')==record['library_sha256'];(out/'misc-report.json').write_text(json.dumps(record,indent=2)+'\n');print({k:record[k]for k in ['run_exit_code','passed','failed','library_unchanged']});assert len(rows)==12
