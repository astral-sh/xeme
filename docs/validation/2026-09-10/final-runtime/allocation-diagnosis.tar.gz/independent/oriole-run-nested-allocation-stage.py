from pathlib import Path
import json,hashlib,subprocess,os,ast,re
out=Path('/tmp/oriole-nested-allocation-stage');out.mkdir(exist_ok=False)
source=Path('/tmp/oriole-nested-allocation-stage.c');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
libs={'reference':Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so'),'candidate':Path('/tmp/oriole-grammar-combined-source/liboriole_expat.so')}
reports={}
for label,lib in libs.items():
 binary=out/label;command=['cc','-O1','-g','-I/home/dev-user/code/oss/oriole/include',str(source),str(lib),'-Wl,-rpath,'+str(lib.parent),'-o',str(binary)]
 with(out/(label+'-build.log')).open('w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=60)
 assert r.returncode==0
 with(out/(label+'.json')).open('w')as log:r=subprocess.run([str(binary)],stdout=log,stderr=subprocess.PIPE,timeout=60,env={**os.environ,'LD_LIBRARY_PATH':str(lib.parent)})
 (out/(label+'-stderr.log')).write_bytes(r.stderr);assert r.returncode==0
 observations=json.loads((out/(label+'.json')).read_text());reports[label]=dict(library=str(lib),library_sha256=sha(lib),compile_command=command,binary_sha256=sha(binary),run_exit_code=r.returncode,**observations)
original=Path('/tmp/oriole-grammar-allocation-audit/adapted/alloc_tests.c').read_text();segment=original.split('START_TEST(test_alloc_nested_entities)',1)[1].split('END_TEST',1)[0];declaration=segment.split('= {',1)[1].split(',\n         "Memory Fail',1)[0];declaration=re.sub(r'/\*.*?\*/','',declaration,flags=re.S);payload=''.join(ast.literal_eval(s)for s in re.findall(r'"(?:[^"\\]|\\.)*"',declaration))
expected="<!ENTITY % pe1 '"+'ABCDEFGHIJKLMNOP'*64+"'>\n<!ENTITY % pe2 '%pe1;'>\n<!ENTITY % pe3 '%pe2;'>";assert payload==expected
summary=dict(scope='Separate diagnostic stage probe. Uses the exact upstream nested-entity DTD and its malloc budget12; realloc remains unlimited, then repeat with no injected failures. Changes no runtime or original upstream matrix.',source_sha256=sha(source),upstream_payload_sha256=hashlib.sha256(payload.encode()).hexdigest(),reports=reports)
(out/'report.json').write_text(json.dumps(summary,indent=2)+'\n')
for label,r in reports.items():
 for budget in [12,-1]:
  rows=[x for x in r['rows']if x['budget']==budget];print(label,budget,len(rows),[(x['child_created'],x['child_status'],x['child_error'],x['root_status'],x['root_error'],x['live_after_free'])for x in rows[:2]])
