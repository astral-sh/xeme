# Final combined runtime sanitizer checkpoint

This package freezes runtime `1262888`, the reviewed grammar-aware `value_family`
target, and all named seeds. `campaign-source.json` hashes every archived source
file. `build.json` and `binaries.json` identify the three AddressSanitizer builds.
Large binaries stay at their recorded local paths; this package contains no binaries.

Each target first replays the hash-deduplicated union of the earlier initial and
evolved corpora plus the new named seeds, then runs for 600 seconds. Per-target
results retain exact commands, bounds, source/binary immutability checks, statistics,
initial/evolved corpora, artifacts (including failures), and compressed full logs.
`summary.json` is authoritative for whether the run completed successfully.

The separate 84-input replay preserves the prior 18 large inputs and adds grammar,
value, and UTF-16 mismatch cases. Its generators and payload hashes are included.
These checks do not establish full Expat compatibility or replace differential,
consumer, allocator, W3C, or PBS validation on their separately named sources.
