"""Read-only verification of final campaign artifacts, not a new fuzz run."""
from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess,tarfile
root=Path('/tmp/oriole-final-grammar-campaign-handoff');live=Path('/tmp/oriole-final-grammar-campaign');issues=[]
sha=lambda data:hashlib.sha256(data).hexdigest()
def digest(path):
 with Path(path).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text())
def check(value,message):
 if not value:issues.append(message)
def members(path):
 result={}
 with tarfile.open(path,'r:gz')as tar:
  for member in tar:
   check(member.isfile(),'non-file archive entry: '+str(path)+'/'+member.name)
   if member.isfile():result[member.name]=tar.extractfile(member).read()
 return result
artifacts=read(root/'artifact-manifest.json')
for name,expected in artifacts.items():check(digest(root/name)==expected,'artifact hash mismatch: '+name)
manifest=read(root/'campaign-source.json');manifest_hash=digest(root/'campaign-source.json');check(manifest_hash=='e0a56fbd93a00bea73eeb4d88ab3e76ca91a57d4568131690a6db291fa2b3924','source manifest mismatch')
sources=members(root/'source.tar.gz');check(set(sources)==set(manifest['files']),'source archive file set')
for name,expected in manifest['files'].items():check(sha(sources[name])==expected,'archived source hash: '+name);check(digest(live/name)==expected,'live snapshot changed: '+name)
binaries=read(root/'binaries.json');build=read(root/'build.json');builds=read(root/'build-results.json');check(len(builds)==3 and all(row['returncode']==0 for row in builds),'ASan build failure/missing target');check('-Zexternal-clangrt'in build['environment']['RUSTFLAGS']and'-fsanitize=address'in build['environment']['RUSTFLAGS'],'ASan flags missing');check(digest(root/'run_campaign.py')==build['runner_sha256']=='72e9bb03d7f2a9df2a1013703478ec7eab901ef7729fe243aed79e683d0f2dc1','runner provenance mismatch')
for target,binary in binaries.items():
 check(digest(binary['path'])==binary['sha256'],'binary changed: '+target)
 table=subprocess.run(['nm','-D',binary['path']],check=True,stdout=subprocess.PIPE,text=True).stdout
 check('__asan_init'in table and '__asan_report_load1'in table and '__asan_report_store1'in table,'ASan runtime/report symbols absent: '+target)
summary=read(root/'summary.json');counts={};total_inputs=total_exec=0
for target in ['value_family','multibyte','ffi_family']:
 path=root/target;result=read(path/'result.json');initial=members(path/'initial-corpus.tar.gz');evolved=members(path/'corpus.tar.gz');failures=members(path/'artifacts.tar.gz');initial_manifest=read(path/'initial-manifest.json')
 check(result['replay_exit_code']==result['campaign_exit_code']==0,'nonzero run: '+target);check(all(result[x]for x in ['source_unchanged','source_manifest_unchanged','binary_unchanged']),'immutability failure: '+target);check(result['source_manifest_sha256']==manifest_hash and result['binary_sha256']==binaries[target]['sha256'],'result provenance mismatch: '+target)
 check(result['campaign_elapsed_seconds']>=600 and result['limits']['campaign_seconds']==600,'short/wrong-duration campaign: '+target);check(result['limits']['max_input_bytes']==65536 and result['limits']['input_timeout_seconds']==10 and result['limits']['rss_mib']==1536,'run limits mismatch: '+target)
 check(not result['artifacts']and not failures,'crash artifacts: '+target);check(set(initial)==set(initial_manifest)and len(initial)==result['initial_inputs'],'initial corpus coverage: '+target)
 for name,data in initial.items():check(sha(data)==name,'initial input hash: '+target+'/'+name)
 check({name:sha(data)for name,data in evolved.items()}==result['final_corpus'],'evolved corpus mismatch: '+target)
 union=set()
 for name,expected in result['seed_archives'].items():
  check(digest(name)==expected,'previous seed archive changed: '+name)
  union.update(sha(data)for data in members(Path(name)).values())
 union.update(sha(data)for name,data in sources.items()if name.startswith('fuzz/seeds/'+target+'/'))
 check(union==set(initial),'initial old+snapshot union mismatch: '+target)
 replay=gzip.open(path/'replay.log.gz','rb').read();log=gzip.open(path/'campaign.log.gz','rb').read()
 check(sha(replay)==summary['original_log_hashes'][target+'/replay.log']and sha(log)==summary['original_log_hashes'][target+'/campaign.log'],'compressed log mismatch: '+target)
 stats={key:int(value)for key,value in re.findall(r'stat::(\w+):\s+(\d+)',log.decode())};check(stats==result['stats'],'recorded stats mismatch: '+target)
 nonempty=sum(bool(data)for data in initial.values());bootstrap_runs=nonempty+1
 check(str(nonempty)+' files found'in replay.decode()and f'Done {bootstrap_runs} runs'in replay.decode(),'replay corpus/bootstrap coverage mismatch: '+target)
 total_inputs+=len(initial);total_exec+=stats['number_of_executed_units'];counts[target]=dict(initial_inputs=len(initial),nonempty_seed_files=nonempty,replay_executions_including_bootstrap=bootstrap_runs,executed_units=stats['number_of_executed_units'],elapsed_seconds=result['campaign_elapsed_seconds'],peak_rss_mb=stats['peak_rss_mb'],crash_artifacts=len(failures),binary_sha256=result['binary_sha256'])
extra=members(root/'extra-replays.tar.gz');extra_manifest=read(root/'extra-replays-manifest.json');extra_results=read(root/'extra-replay-results.json');check(set(extra)==set(extra_manifest)and len(extra)==84,'extra input coverage');check(not members(root/'extra-replay-artifacts.tar.gz'),'extra crash artifact')
for name,data in extra.items():check(sha(data)==extra_manifest[name]['sha256'],'extra input mismatch: '+name)
for result in extra_results:check(result['returncode']==0 and result['binary_sha256']==binaries[result['target']]['sha256'],'extra replay result/provenance: '+result['target'])
check(total_inputs==summary['initial_replays']==15713 and total_exec==summary['executed_units']==3912477 and summary['status']=='completed_pass','summary counts/status')
report={'reviewer':'/root/ffi/multibyte_fuzz','method':'Independent read-only artifact/data audit; no campaign or replay rerun.','issues':issues,'reviewed_package_manifest_sha256':digest(root/'artifact-manifest.json'),'source_manifest_sha256':manifest_hash,'source_files':len(sources),'artifacts_verified':len(artifacts),'campaigns':counts,'initial_inputs':total_inputs,'executed_units':total_exec,'extra_inputs':len(extra),'build_provenance':'All three recorded cargo+ohm fuzz builds exit0; source/binary hashes match, external-Clang AddressSanitizer flags retained, and __asan_init plus load/store report symbols independently observed in each binary.','scope':['Three fixed600second campaigns provide bounded evidence, not proof of safety or complete Expat compatibility.','LeakSanitizer disabled; harnesses retain selected-allocator live-count and converter-release checks.','Initial/evolved/stress corpora and complete compressed logs retained; arbitrary input acceptance is not asserted.']}
out=Path('/tmp/oriole-final-fuzz-independent-review.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'issues':issues,'report':str(out),'sha256':digest(out)}))
if issues:raise SystemExit(1)
