"""Read-only audit of the final snapshot against reviewed runtime/harness inputs."""
from pathlib import Path
import hashlib,io,json,subprocess,sys,tarfile
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]);repo=Path('/home/dev-user/code/oss/oriole')
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest_path=root/'campaign-source.json';manifest=json.loads(manifest_path.read_text());files=manifest['files']
manifest_mismatches=[name for name,expected in files.items()if not(root/name).is_file()or sha((root/name).read_bytes())!=expected]
required=set()
for pattern in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','crates/**/*.rs','crates/**/Cargo.toml','include/**/*.h','fuzz/Cargo.toml','fuzz/Cargo.lock','fuzz/fuzz_targets/*.rs','fuzz/seeds/**/*']:
 required.update(str(p.relative_to(root))for p in root.glob(pattern)if p.is_file())
missing_required=sorted(required-set(files))
archive=subprocess.run(['git','-C',str(repo),'archive','12628880f33d026aafd4cbd9d60185191583e268','crates','include','Cargo.toml','Cargo.lock'],check=True,stdout=subprocess.PIPE).stdout
runtime=[];mismatches=[];absent=[]
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:')as tar:
 for item in tar:
  if item.isfile()and(item.name.endswith('.rs')or item.name.endswith('.h')or Path(item.name).name in ('Cargo.toml','Cargo.lock')):
   data=tar.extractfile(item).read();path=root/item.name;runtime.append(item.name)
   if not path.is_file():absent.append(item.name)
   elif sha(path.read_bytes())!=sha(data):mismatches.append(item.name)
harness=root/'fuzz/fuzz_targets/value_family.rs';expected_harness='ccc605c3f0ae465a65e3cb1ce8151c646dd022d071a40516498545c79b14dbb3'
seed_manifest=json.loads(Path('/tmp/oriole-grammar-fuzz/seed-manifest.json').read_text())
missing_seeds=[name for name,row in seed_manifest.items()if not(root/'fuzz/seeds/value_family'/name).is_file()or sha((root/'fuzz/seeds/value_family'/name).read_bytes())!=row['sha256']]
reference_manifest=json.loads(Path('/tmp/oriole-grammar-combined-source/source.json').read_text());combined_mismatches=[name for name,expected in reference_manifest['sources'].items()if name.startswith(('crates/','include/'))and(not(root/name).is_file()or sha((root/name).read_bytes())!=expected)]
result=dict(snapshot=str(root),manifest_sha256=sha(manifest_path.read_bytes()),manifest_entries=len(files),manifest_mismatches=manifest_mismatches,required_build_and_seed_files=len(required),unmanifested_required_files=missing_required,runtime_commit='12628880f33d026aafd4cbd9d60185191583e268',runtime_files_compared=len(runtime),runtime_mismatches=mismatches,runtime_files_missing=absent,combined_ff5d_manifest_mismatches=combined_mismatches,harness_sha256=sha(harness.read_bytes()),harness_matches=sha(harness.read_bytes())==expected_harness,marked_seed_count=len(seed_manifest),marked_seed_mismatches=missing_seeds,reviewer='/root/ffi/multibyte_fuzz')
result['pass']=not(manifest_mismatches or missing_required or mismatches or absent or combined_mismatches or missing_seeds)and result['harness_matches']
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if not result['pass']:raise SystemExit(1)
