"""Package completed campaigns, keeping failures and exact source separation."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

root = Path(__file__).resolve().parent
out = Path('/tmp/oriole-final-grammar-campaign-handoff')
out.mkdir(exist_ok=False)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(path, name=None):
    destination = out / (name or path.name)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, destination)


def compress(path, name):
    destination = out / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    with path.open('rb') as source, gzip.open(destination, 'wb') as target:
        shutil.copyfileobj(source, target)


def archive(directory, name):
    with tarfile.open(out / name, 'w:gz') as tar:
        for path in sorted(directory.rglob('*')):
            if path.is_file():
                tar.add(path, arcname=str(path.relative_to(directory)))


source_manifest = json.loads((root / 'campaign-source.json').read_text())
unchanged = all(digest(root / path) == value for path, value in source_manifest['files'].items())
copy(root / 'campaign-source.json')
copy(root / 'integrated-runtime-source.json')
with tarfile.open(out / 'source.tar.gz', 'w:gz') as tar:
    for relative in source_manifest['files']:
        tar.add(root / relative, arcname=relative)
for name in ['build.json', 'build-results.json', 'binaries.json', 'run_campaign.py', 'runner-independent-review.json',
             'prepare_extra_replays.py', 'extra-replays-manifest.json', 'extra-replay-results.json', 'package_campaign.py']:
    copy(root / name)
copy(Path('/tmp/oriole-final-grammar-campaign-snapshot-review.json'), 'snapshot-independent-review.json')
copy(Path('/tmp/oriole-audit-final-campaign.py'), 'audit-snapshot.py')
for path in sorted(root.glob('build-*.log')):
    compress(path, path.name + '.gz')
for path in sorted(root.glob('*-asan-symbols.txt')):
    compress(path, path.name + '.gz')
for path in sorted(root.glob('extra-replay-*.log')):
    compress(path, path.name + '.gz')
archive(root / 'extra-replays', 'extra-replays.tar.gz')
archive(root / 'extra-replay-artifacts', 'extra-replay-artifacts.tar.gz')
campaigns = {}
original_logs = {path.name: digest(path) for path in root.glob('*.log')}
for target in ['value_family', 'multibyte', 'ffi_family']:
    directory = root / 'campaigns' / target
    result = json.loads((directory / 'result.json').read_text())
    campaigns[target] = {key: value for key, value in result.items() if key != 'final_corpus'}
    for name in ['result.json', 'initial-manifest.json']:
        copy(directory / name, target + '/' + name)
    for name in ['replay.log', 'campaign.log']:
        original_logs[target + '/' + name] = digest(directory / name)
        compress(directory / name, target + '/' + name + '.gz')
    for name in ['initial-corpus', 'corpus', 'artifacts']:
        archive(directory / name, target + '/' + name + '.tar.gz')
    compress(root / f'campaign-{target}-controller.log', target + '/controller.log.gz')

extra = json.loads((root / 'extra-replay-results.json').read_text())
runner_unchanged = digest(root / 'run_campaign.py') == json.loads((root / 'build.json').read_text())['runner_sha256']
passed = unchanged and runner_unchanged and all(row['returncode'] == 0 for row in extra) and not list((root / 'extra-replay-artifacts').iterdir())
binary_manifest = json.loads((root / 'binaries.json').read_text())
for name, row in campaigns.items():
    passed &= row.get('replay_exit_code') == 0 and row.get('campaign_exit_code') == 0 and not row.get('artifacts')
    passed &= bool(row.get('source_unchanged') and row.get('source_manifest_unchanged') and row.get('binary_unchanged'))
    passed &= row.get('source_manifest_sha256') == digest(root / 'campaign-source.json')
    binary = Path(binary_manifest[name]['path'])
    passed &= binary.exists() and digest(binary) == row.get('binary_sha256') == binary_manifest[name]['sha256']
    passed &= row.get('campaign_elapsed_seconds', 0) >= 600 and row.get('stats', {}).get('number_of_executed_units', 0) > 0
summary = {
    'status': 'completed_pass' if passed else 'failed_or_incomplete',
    'runtime_commit': source_manifest['runtime_commit'],
    'source_manifest_sha256': digest(root / 'campaign-source.json'),
    'source_unchanged_at_packaging': unchanged,
    'runner_unchanged_at_packaging': runner_unchanged,
    'campaigns': campaigns,
    'initial_replays': sum(row['initial_inputs'] for row in campaigns.values()),
    'executed_units': sum(row.get('stats', {}).get('number_of_executed_units', 0) for row in campaigns.values()),
    'extra_replays': sum(row['inputs'] for row in extra),
    'original_log_hashes': original_logs,
    'limits': ['Three fixed 600-second campaigns are bounded evidence, not proof of absence of defects.',
               'AddressSanitizer uses the external Clang runtime; exact build commands and dynamic ASan symbols are preserved.',
               'LeakSanitizer is disabled under ptrace. Harness assertions retain selected-allocator live counts and converter release ownership.',
               'Callback-driven harnesses bound family slots, nesting, feeds, requests, resumes, model traversal and input size.',
               'Standalone input and per-operation limits can terminate or reject adversarial documents; replay does not assert arbitrary XML acceptance.',
               'Previous b68 source, campaigns and PBS results remain separate evidence and were not overwritten.'],
}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(out / 'README.md').write_text('''# Final combined runtime sanitizer checkpoint

This package freezes runtime `1262888`, the reviewed grammar-aware `value_family`
target, and all named seeds. `campaign-source.json` hashes every archived source
file. `build.json` and `binaries.json` identify the three AddressSanitizer builds.
Large binaries stay at their recorded local paths; this package contains no binaries.

Each target first replays the hash-deduplicated union of the earlier initial and
evolved corpora plus the new named seeds, then runs for 600 seconds. Per-target
results retain exact commands, bounds, source/binary immutability checks, statistics,
initial/evolved corpora, artifacts (including failures), and compressed full logs.
`summary.json` is authoritative for whether the run completed successfully.

The separate 84-input replay preserves the prior 18 large inputs and adds grammar,
value, and UTF-16 mismatch cases. Its generators and payload hashes are included.
These checks do not establish full Expat compatibility or replace differential,
consumer, allocator, W3C, or PBS validation on their separately named sources.
''')
(out / 'artifact-manifest.json').write_text(json.dumps({str(path.relative_to(out)): digest(path) for path in sorted(out.rglob('*')) if path.is_file()}, indent=2) + '\n')
print(json.dumps({key: value for key, value in summary.items() if key not in ['campaigns', 'original_log_hashes', 'limits']}))
if not passed:
    raise SystemExit(1)
