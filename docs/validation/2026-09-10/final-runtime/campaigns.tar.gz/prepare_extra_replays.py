"""Preserve prior stress inputs and add bounded grammar/encoding regressions."""
from pathlib import Path
import hashlib
import json
import tarfile

root = Path(__file__).resolve().parent
out = root / 'extra-replays'
manifest = {}


def store(target, name, data, **notes):
    assert 16 <= len(data) <= 65536
    path = out / target / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    manifest[str(path.relative_to(out))] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), **notes)


archive = Path('/tmp/oriole-value-campaign-handoff/large-inputs.tar.gz')
old = json.loads(Path('/tmp/oriole-value-campaign-handoff/large-inputs-manifest.json').read_text())
with tarfile.open(archive, 'r:gz') as tar:
    for member in tar:
        if member.isfile():
            data = tar.extractfile(member).read()
            name = Path(member.name).name
            assert hashlib.sha256(data).hexdigest() == old[name]['sha256']
            store('value_family', 'previous-' + name, data, source_archive=str(archive), member=member.name)

for encoding in ['UTF-16', 'UTF-16LE', 'UTF-16BE']:
    for large in [False, True]:
        tail = f"encoding='{encoding}'?><r/>".encode()
        begin = b"<?xml version='1.0' "
        padding = b' ' * (65520 - len(begin) - len(tail)) if large else b''
        document = begin + padding + tail
        for width in ([16, 64, 256] if large else [1, 2, 16, 256]):
            for buffered in [False, True]:
                controls = bytearray(16)
                controls[0] = 64 | 4 | 8 | (2 if buffered else 0)
                controls[3] = width - 1
                controls[13] = 255
                store('multibyte', f'mismatch-{encoding}-{large}-{width}-{buffered}', bytes(controls) + document,
                      purpose='Sniffed ASCII with conflicting generic/endian UTF16 declaration; direct/buffered root and retained content child.',
                      complete_root_feed_within_iteration_bound=True, width=width)

marker = b'ORIOLE-DTD-GRAMMAR\0'
base = bytearray(32)
base[11] = 59
base[12] = 2


def grammar(name, selector, p, q, width=256, fail=0, buffered=False, purpose=''):
    controls = bytearray(base)
    controls[0] = int(fail != 0) | (2 if buffered else 0)
    if fail:
        controls[1:3] = (fail - 1).to_bytes(2, 'little')
    controls[3] = width - 1
    controls[13:15] = len(p).to_bytes(2, 'little')
    store('value_family', name, bytes(controls) + marker + bytes([selector]) + p + q,
          selector=selector, width=width, fail_nth=fail, purpose=purpose)


for selector in [4, 6, 8]:
    if selector == 8:
        p = b''
        q = b'"' + b'X' * (65536 - 32 - len(marker) - 1 - 2) + b'"'
    else:
        p = b''.join(f"<!ATTLIST r a{i} CDATA 'X'>".encode() for i in range(1800))
        q = b''
    for width in [16, 64, 256]:
        grammar(f'large-grammar-{selector}-width{width}', selector, p, q, width=width,
                purpose='Large external grammar child metadata or grammar-to-value payload; complete feed within 4096 calls.')
    grammar(f'large-grammar-{selector}-allocation128', selector, p, q, fail=128,
            purpose='Selected allocator failure during large grammar/value family lifetime.')

for encoding in ['UTF-16', 'UTF-16LE', 'UTF-16BE']:
    for large in [False, True]:
        begin = b"<?xml version='1.0' "
        tail = f"encoding='{encoding}'?>VALUE".encode()
        size = 65536 - 32 - len(marker) - 1
        document = begin + (b' ' * (size - len(begin) - len(tail)) if large else b'') + tail
        for buffered in [False, True]:
            grammar(f'value-mismatch-{encoding}-{large}-{buffered}', 8, b'', document,
                    buffered=buffered, purpose='Conflicting UTF16 declaration in external value child after grammar continuation.')

(root / 'extra-replays-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print({'inputs': len(manifest), 'by_target': {target: sum(name.startswith(target + '/') for name in manifest) for target in ['value_family', 'multibyte']}})
