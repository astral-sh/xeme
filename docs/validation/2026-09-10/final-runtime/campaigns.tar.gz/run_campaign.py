"""Replay frozen b68 corpora, then fuzz an independently frozen parser snapshot."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile
import time

p = argparse.ArgumentParser()
p.add_argument('target', choices=['value_family', 'multibyte', 'ffi_family'])
p.add_argument('cpu')
p.add_argument('--source', type=Path, required=True)
p.add_argument('--binary-dir', type=Path, required=True)
p.add_argument('--seconds', type=int, default=600)
a = p.parse_args()
root = a.source.resolve()
out = root / 'campaigns' / a.target
if out.exists() and any(out.iterdir()):
    raise SystemExit(f'Refusing to overwrite existing campaign evidence: {out}')
out.mkdir(parents=True, exist_ok=True)
manifest_path = root / 'campaign-source.json'
manifest = json.loads(manifest_path.read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
manifest_hash = digest(manifest_path)
def source_matches():
    return all(digest(root / path) == value for path, value in manifest['files'].items())
assert source_matches()
binary = a.binary_dir.resolve() / a.target
binary_hash = digest(binary)
initial = out / 'initial-corpus'
initial.mkdir(exist_ok=True)
archives = [Path('/tmp/oriole-value-campaign-handoff') / a.target / name for name in ['initial-corpus.tar.gz', 'corpus.tar.gz']]
inputs = {}
for archive in archives:
    with tarfile.open(archive, 'r:gz') as tar:
        for entry in tar:
            if not entry.isfile():
                continue
            file = tar.extractfile(entry)
            assert file is not None
            data = file.read()
            name = hashlib.sha256(data).hexdigest()
            if name not in inputs:
                (initial / name).write_bytes(data)
            inputs.setdefault(name, []).append({'archive': str(archive), 'member': entry.name})
# The combined snapshot can add reviewed regression seeds, including setters.
for path in sorted((root / 'fuzz/seeds' / a.target).iterdir()):
    if path.is_file():
        data = path.read_bytes()
        name = hashlib.sha256(data).hexdigest()
        if name not in inputs:
            (initial / name).write_bytes(data)
        inputs.setdefault(name, []).append({'snapshot': str(path.relative_to(root))})
(out / 'initial-manifest.json').write_text(json.dumps(inputs, indent=2) + '\n')
corpus, artifacts = out / 'corpus', out / 'artifacts'
corpus.mkdir(exist_ok=True)
artifacts.mkdir(exist_ok=True)
env = os.environ.copy()
env['ASAN_OPTIONS'] = 'detect_leaks=0'
common = ['taskset', '-c', a.cpu, str(binary), '-seed=20260910', '-max_len=65536', '-timeout=10', '-rss_limit_mb=1536', f'-artifact_prefix={artifacts}/']
result = {'target': a.target, 'binary': str(binary), 'binary_sha256': binary_hash,
          'source_manifest_sha256': manifest_hash, 'initial_inputs': len(inputs),
          'seed_archives': {str(path): digest(path) for path in archives},
          'runtime_environment': {'ASAN_OPTIONS': env['ASAN_OPTIONS']},
          'limits': {'max_input_bytes': 65536, 'input_timeout_seconds': 10, 'rss_mib': 1536, 'campaign_seconds': a.seconds},
          'sanitizer': 'AddressSanitizer with external Clang runtime'}
def save():
    (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
def run(command, log, timeout):
    with log.open('w') as stream:
        try:
            return subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            result['harness_timeout'] = {'command': command, 'seconds': timeout}
            return 124
replay = common + ['-runs=0', str(initial)]
result['replay_command'] = replay
save()
result['replay_exit_code'] = run(replay, out / 'replay.log', 180)
save()
if result['replay_exit_code']:
    raise SystemExit(result['replay_exit_code'])
command = common + [f'-max_total_time={a.seconds}', '-print_final_stats=1', str(corpus), str(initial)]
result['campaign_command'] = command
result['started_at_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
save()
print(json.dumps({'started': a.target, 'initial_inputs': len(inputs), 'binary_sha256': binary_hash}), flush=True)
start = time.monotonic()
result['campaign_exit_code'] = run(command, out / 'campaign.log', a.seconds + 90)
result['campaign_elapsed_seconds'] = time.monotonic() - start
result['source_unchanged'] = source_matches()
result['source_manifest_unchanged'] = digest(manifest_path) == manifest_hash
result['binary_unchanged'] = digest(binary) == binary_hash
result['stats'] = {key: int(value) for key, value in re.findall(r'stat::(\w+):\s+(\d+)', (out / 'campaign.log').read_text())}
result['artifacts'] = [{'name': path.name, 'sha256': digest(path)} for path in artifacts.iterdir() if path.is_file()]
result['final_corpus'] = {path.name: digest(path) for path in corpus.iterdir() if path.is_file()}
save()
print(json.dumps({key: value for key, value in result.items() if key != 'final_corpus'}), flush=True)
if result['campaign_exit_code'] or result['artifacts'] or not result['source_unchanged'] or not result['source_manifest_unchanged'] or not result['binary_unchanged']:
    raise SystemExit(1)
