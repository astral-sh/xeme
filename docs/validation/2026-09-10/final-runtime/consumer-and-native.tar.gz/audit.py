"""Read-only integrity and scope checks; never re-executes the tested programs."""
from pathlib import Path
import collections,hashlib,json,re
BASE=Path('/tmp');SO='ff5d86621114e464a0b20f108b6308fe155d9e8c87bd764bc00872cf124750f8';STATIC='4fa096d9ffdfcf2c01d764ae83190ab689064e10a87860822d6301d04da62651'
issues=[];observed={}
def read(path):return json.loads(Path(path).read_text())
def digest(path):
 with Path(path).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def check(value,message):
 if not value:issues.append(message)
for name,expected in [('liboriole_expat.so',SO),('liboriole_expat.a',STATIC)]:check(digest(BASE/'oriole-grammar-combined-source'/name)==expected,'combined library changed: '+name)
integration=read(BASE/'oriole-grammar-combined-gates/integration.json')
for name,row in integration['files'].items():check(digest(Path('/home/dev-user/code/oss/oriole')/name)==row['combined_sha256'],'integrated source mismatch: '+name)
log=(BASE/'oriole-grammar-combined-gates/tests.log').read_text();counts=[int(x)for x in re.findall(r'test result: ok\. (\d+) passed;',log)]
check(sum(counts)==246 and 'test result: FAILED'not in log,'workspace test count/failure mismatch')
check((BASE/'oriole-grammar-combined-gates/fmt.log').read_text()=='','format check log is nonempty')
check('Finished 'in(BASE/'oriole-grammar-combined-gates/clippy.log').read_text(),'Clippy completion log missing')
observed['workspace']={'passed':sum(counts),'fmt_log_empty':True,'clippy_completion_recorded':True}
api=BASE/'oriole-upstream-grammar-combined';manifest=read(api/'manifest.json');results=read(api/'results.json');prior=read(BASE/'oriole-upstream-dtd-combined/results.json');comparison=read(api/'comparison.json')
check(manifest['library_sha256']==SO and digest(api/'liboriole_expat.so')==SO,'API library mismatch')
check(digest(api/'runtests')==manifest['binary_sha256'],'API binary mismatch')
for name,expected in manifest['adapted_sources'].items():check(digest(api/'adapted'/name)==expected,'adapted API source mismatch: '+name)
check(results['selection_complete']and results['library_origin_verified']and not results['timed_out'],'API selection/origin/timeout flag')
check(len(results['results'])==len(manifest['public_tests_in_source'])*len(manifest['chunks'])*len(manifest['deferral'])==4740,'API observation count')
old={(r['context'],r['test']):r for r in prior['results']};new={(r['context'],r['test']):r for r in results['results']};check(old.keys()==new.keys(),'API baseline key coverage mismatch')
fixed=[new[k]for k in new if old[k]['outcome']!='pass'and new[k]['outcome']=='pass'];regressed=[new[k]for k in new if old[k]['outcome']=='pass'and new[k]['outcome']!='pass']
check(fixed==comparison['fixed']and regressed==comparison['new_failures'],'API baseline comparison mismatch')
observed['api']={'cases':len(new),'outcomes':dict(collections.Counter(r['outcome']for r in new.values())),'fixed':len(fixed),'new_failures':len(regressed),'scope':'Adapted public API observations; 12 internal tests excluded, 987 assertions still fail. Full matrix is not claimed as passing.'}
w3c=BASE/'oriole-w3c-grammar-combined';summary=read(w3c/'summary.json');ref=read(w3c/'reference.json');cand=read(w3c/'oriole.json')
check(cand['sha256']==SO and len(cand['rows'])==6003,'W3C library/count mismatch');check(not summary['worker_failures']and not summary['inconclusive_comparisons'],'W3C incomplete workers')
expected_fail=[];required=optional=0
ref_index={(r['id'],r['chunk']):r for r in ref['rows']}
for row in cand['rows']:
 kind=row['type'];result=row['result'];check(not result['resolver_errors'],'W3C resolver failure')
 if kind=='error':optional+=1;continue
 required+=1;accept=result['status']==1;want=kind in('valid','invalid')
 if accept!=want:expected_fail.append(row)
check(expected_fail==summary['mismatches']['oriole'],'W3C independent expectation mismatch')
check(all(ref_index[(r['id'],r['chunk'])]['result']['status']==r['result']['status']for r in expected_fail),'W3C failures differ from reference acceptance')
check({r['id']for r in expected_fail}=={'hst-lhs-007','rmt-e2e-38'},'W3C failure IDs changed')
observed['w3c']={'descriptors':summary['selected_descriptors'],'mandatory_pass':required-len(expected_fail),'mandatory_fail':len(expected_fail),'optional':optional,'failed_ids':sorted({r['id']for r in expected_fail}),'scope':summary['scope']}
consumer_root=BASE/'oriole-grammar-consumers';runs=read(consumer_root/'runs.json');consumer_rows=[]
for run in runs:
 directory=consumer_root/run['name'];r=read(directory/'summary.json');expected=SO if r['linkage']=='shared'else STATIC;name='liboriole_expat.so'if r['linkage']=='shared'else'liboriole_expat.a'
 check(run['exit_code']==r['probe_exit_code']==r['tests_exit_code']==0,'consumer failed: '+run['name']);check(r['library_sha256']==expected and digest(directory/name)==expected,'consumer library mismatch: '+run['name']);check(digest(directory/'pyexpat.c')==r['compiled_source_sha256'],'consumer compiled source mismatch: '+run['name'])
 text=(directory/'tests.log').read_text();check('Total tests: run=803 skipped=31'in text and 'Result: SUCCESS'in text,'consumer counts/final outcome mismatch: '+run['name'])
 consumer_rows.append({'name':run['name'],'library_sha256':expected,'run':803,'skipped':31,'test_files':6,'consumer_adaptation':r['consumer_adaptation']})
observed['consumers']=consumer_rows
native=BASE/'oriole-grammar-native';r=read(native/'report.json');check(r['status']=='passed'and r['sha256_before']==r['sha256_after'],'native status/mutation')
for name,expected in r['sha256_after'].items():check(digest(name)==expected,'native input changed: '+name)
for row in r['rows']:
 label=row['case']+'-'+row['linkage'];check(row['build_exit_code']==row['exit_code']==0,'native case failed: '+label);check(digest(native/label)==row['binary_sha256'],'native binary changed: '+label);check(digest(native/(label+'.log'))==row['log_sha256'],'native log changed: '+label)
observed['native']={'cases':len(r['rows']),'scope':r['scope'],'allocation_sweep_scenarios_each':353}
generated=BASE/'oriole-grammar-generated';r=read(generated/'summary.json');ref=read(generated/'reference.json')['results'];cand=read(generated/'oriole.json')['results'];counts=dict.fromkeys(['status','error','normalized_events','events','position','callback_errors'],0)
check(len(ref)==len(cand)==r['cases']==12318,'generated count mismatch')
for a,b in zip(ref,cand,strict=True):
 check((a['name'],a['chunk_size'])==(b['name'],b['chunk_size']),'generated case order mismatch')
 for key in counts:
  if a['result'][key]!=b['result'][key]or(key=='callback_errors'and(a['result'][key]or b['result'][key])):counts[key]+=1
check(counts==r['difference_counts'],'generated difference summary mismatch');check(r['libraries']['oriole']['sha256_before']==r['libraries']['oriole']['sha256_after']==SO,'generated library mismatch')
observed['generated']={'cases':len(cand),'difference_counts':counts,'scope':r['scope'],'semantic_pass':r['semantic_pass'],'exact_pass':r['exact_pass']}
out=BASE/'oriole-final-combined-independent-audit.json';out.write_text(json.dumps({'reviewer':'/root/ffi/multibyte_fuzz','method':'Read-only evidence audit; no tests or workers rerun.','shared_library_sha256':SO,'static_library_sha256':STATIC,'issues':issues,'observed':observed},indent=2)+'\n');print(json.dumps({'issues':issues,'artifact':str(out),'sha256':digest(out)}))
if issues:raise SystemExit(1)
