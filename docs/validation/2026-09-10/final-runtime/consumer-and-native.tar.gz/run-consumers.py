from pathlib import Path
import hashlib,json,subprocess,time
root=Path('/tmp/oriole-grammar-consumers');root.mkdir(exist_ok=False)
rows=[]
for prior in json.loads(Path('/tmp/oriole-dtd-consumers/runs.json').read_text()):
 command=[s.replace('/tmp/oriole-dtd-combined-source','/tmp/oriole-grammar-combined-source').replace('/tmp/oriole-dtd-consumers','/tmp/oriole-grammar-consumers') for s in prior['command']]
 start=time.monotonic()
 with (root/(prior['name']+'.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 rows.append({'name':prior['name'],'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start})
 (root/'runs.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(prior['name'],result.returncode,flush=True)
 assert result.returncode==0
