import hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/dev-user/code/oss/oriole')
v=root/'docs/validation/2026-09-10/final-runtime';v.mkdir(exist_ok=True)
b=root/'benchmarks/results/2026-09-10/final-runtime';b.mkdir(exist_ok=True)

def package(destination, mappings):
 index={}
 with tarfile.open(destination,'w:gz',compresslevel=9) as tf:
  for label,path in mappings:
   path=Path(path)
   files=sorted(path.rglob('*')) if path.is_dir() else [path]
   for p in files:
    if not p.is_file() or '__pycache__' in p.parts or p.suffix in ('.so','.a','.pyc'):continue
    with p.open('rb') as f:prefix=f.read(8)
    if prefix.startswith(b'\x7fELF') or prefix==b'!<arch>\n':continue
    name=str(Path(label)/p.relative_to(path)) if path.is_dir() else label
    data=p.read_bytes();index[name]=hashlib.sha256(data).hexdigest()
    tf.add(p,arcname=name,recursive=False)
 metadata=destination.with_suffix('').with_suffix('.files.json')
 metadata.write_text(json.dumps(index,indent=2)+'\n')
 with tarfile.open(destination,'r:gz') as tf:
  actual={m.name:hashlib.sha256(tf.extractfile(m).read()).hexdigest() for m in tf.getmembers() if m.isfile()}
 assert actual==index
 print(destination.name,len(index),destination.stat().st_size)

package(v/'consumer-and-native.tar.gz',[
 ('consumers','/tmp/oriole-grammar-consumers'),('native','/tmp/oriole-grammar-native'),('source.json','/tmp/oriole-grammar-combined-source/source.json'),
 ('run-consumers.py','/tmp/oriole-run-final-consumers.py'),('run-native.py','/tmp/oriole-run-final-native.py'),
 ('independent-audit.json','/tmp/oriole-final-combined-independent-audit.json'),('audit.py','/tmp/oriole-audit-combined-evidence.py')])
package(v/'generated.tar.gz',[('generated','/tmp/oriole-grammar-generated'),('generated.log','/tmp/oriole-grammar-generated.log')])
package(v/'allocation-diagnosis.tar.gz',[('independent','/tmp/oriole-allocation-independent-handoff'),('root-runner.py','/tmp/oriole-final-allocation-audit.py')])
package(b/'measurements.tar.gz',[
 ('native-plain','/tmp/oriole-grammar-bench-plain'),('native-namespaces','/tmp/oriole-grammar-bench-namespaces'),
 ('allocators','/tmp/oriole-grammar-allocator-bench'),('dtd','/tmp/oriole-grammar-dtd-bench'),('dtd-inputs','/tmp/oriole-grammar-dtd-inputs'),
 ('build','/tmp/oriole-grammar-bench-build'),('source.json','/tmp/oriole-grammar-combined-source/source.json'),
 ('driver-sanitizers','/tmp/oriole-grammar-driver-asan'),('build-benchmarks.py','/tmp/oriole-build-grammar-bench.py'),('run-benchmarks.py','/tmp/oriole-run-grammar-benchmarks.py')])
# Exact Git snapshot supplies buildable source and validation tools; results/logs stay in their packages.
paths=['Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','crates','include','benchmarks/inprocess','benchmarks/run.py','benchmarks/allocators.py','benchmarks/dtd_scaling.py','benchmarks/dtd_composition_workload.py','benchmarks/native_driver.c','benchmarks/native_dtd_driver.c','tools/cpython/run.py','tools/corpus.py','tools/differential.py','tools/xml_abi.py','tests','LICENSE-APACHE','LICENSE-MIT']
tracked=subprocess.check_output(['git','ls-files',*paths],cwd=root,text=True).splitlines()
source=v/'source.tar.gz'
with tarfile.open(source,'w:gz',compresslevel=9) as tf:
 for path in tracked:tf.add(root/path,arcname=path,recursive=False)
(v/'source-index.json').write_text(json.dumps({'git_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'runtime_commit':'1262888','files':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in tracked}},indent=2)+'\n')
print('source',len(tracked),source.stat().st_size)
