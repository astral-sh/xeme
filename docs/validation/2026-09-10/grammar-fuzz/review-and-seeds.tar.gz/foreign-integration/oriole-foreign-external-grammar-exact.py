from pathlib import Path
import importlib.util,itertools,json,gzip,hashlib
p=Path('/tmp/oriole-foreign-external-grammar.py');spec=importlib.util.spec_from_file_location('probe',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
libs={'reference':m.setup(m.REF),'candidate':m.setup(m.CAND)};rows=[]
for action,mode,standalone,width,reject,prefix in itertools.product(['skip','create','nonfinal','empty'],[0,1,2],[None,'yes'],[0,1,7],[False,True],['','<!DOCTYPE r []>']):
 case=dict(body="<!ENTITY % p SYSTEM 'p'><!ATTLIST r a CDATA 'A' %p;>",action=action,mode=mode,standalone=standalone,width=width,reject=reject,prefix=prefix,entity='missing')
 rows.append(dict(case=case,**{label:m.probe(lib,**case)for label,lib in libs.items()}))
semantic=lambda r:[e for e in r['events']if e[1]!='default'];outcome=lambda r:[r['status'],r['error'],r['children']]
summary=dict(cases=len(rows),outcome_differences=sum(outcome(r['reference'])!=outcome(r['candidate'])for r in rows),nondefault_event_differences=sum(semantic(r['reference'])!=semantic(r['candidate'])for r in rows),full_event_differences=sum(r['reference']['events']!=r['candidate']['events']for r in rows),candidate_sha256=hashlib.sha256(Path(m.CAND).read_bytes()).hexdigest(),retained='Only pre-existing root internal-subset closing bracket Default ordering differences.',source_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
with gzip.open('/tmp/oriole-foreign-external-grammar-exact.cases.json.gz','wt')as f:json.dump(rows,f)
Path('/tmp/oriole-foreign-external-grammar-exact.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary)
