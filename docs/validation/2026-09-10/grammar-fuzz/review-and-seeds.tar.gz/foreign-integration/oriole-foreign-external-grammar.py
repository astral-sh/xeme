import ctypes as c,hashlib,itertools,json,gzip,sys
from pathlib import Path
P,S,I,B=c.c_void_p,c.c_char_p,c.c_int,c.c_ubyte
EXT=c.CFUNCTYPE(I,P,S,S,S,S);NS=c.CFUNCTYPE(I,P);ATT=c.CFUNCTYPE(None,P,S,S,S,S,I);ENT=c.CFUNCTYPE(None,P,S,I,P,I,S,S,S,S);TEXT=c.CFUNCTYPE(None,P,P,I);SKIP=c.CFUNCTYPE(None,P,S,I);START=c.CFUNCTYPE(None,P,S,P)
REF='/home/dev-user/.cache/oriole/expat-build/libexpat.so'
CAND=sys.argv[1]if len(sys.argv)>1 else '/tmp/oriole-grammar-combined-source/liboriole_expat.so'
OUT=Path(sys.argv[2]if len(sys.argv)>2 else '/tmp/oriole-foreign-external-grammar')
def setup(path):
 lib=c.CDLL(path)
 for name,result,args in [('XML_ParserCreate',P,[S]),('XML_ExternalEntityParserCreate',P,[P,S,S]),('XML_ParserFree',None,[P]),('XML_Parse',I,[P,P,I,I]),('XML_GetErrorCode',I,[P]),('XML_SetParamEntityParsing',I,[P,I]),('XML_UseForeignDTD',I,[P,B]),('XML_SetExternalEntityRefHandler',None,[P,EXT]),('XML_SetNotStandaloneHandler',None,[P,NS]),('XML_SetAttlistDeclHandler',None,[P,ATT]),('XML_SetEntityDeclHandler',None,[P,ENT]),('XML_SetDefaultHandlerExpand',None,[P,TEXT]),('XML_SetCharacterDataHandler',None,[P,TEXT]),('XML_SetSkippedEntityHandler',None,[P,SKIP]),('XML_SetStartElementHandler',None,[P,START])]:
  fn=getattr(lib,name);fn.restype=result;fn.argtypes=args
 return lib
D=lambda p:p.decode()if p is not None else None
def probe(lib,body,action,mode,standalone,width,reject,entity,prefix):
 events=[];children=[];actor=['root'];root=lib.XML_ParserCreate(None);assert root
 def event(kind,*values):
  if events and kind in ('default','text')and events[-1][:2]==[actor[0],kind]:events[-1][-1]+=values[-1]
  else:events.append([actor[0],kind,*values])
 def parse(parser,data,final=True):
  step=width or max(1,len(data));status=1
  for start in range(0,max(1,len(data)),step):
   part=data[start:start+step];status=lib.XML_Parse(parser,part,len(part),int(final and start+step>=len(data)))
   if status!=1:break
  return status
 @EXT
 def external(parser,context,base,system,public):
  name=D(system)or'foreign';event('external',name)
  if name=='p'and action=='skip':return 1
  child=lib.XML_ExternalEntityParserCreate(parser,context,b'BOGUS'if name=='p'and action=='unknown'else None);assert child
  if name=='p'and action=='create':lib.XML_ParserFree(child);return 1
  saved=actor[0];actor[0]=name
  data=body.encode()if name=='foreign'else b'?'if action=='invalid'else b''
  status=parse(child,data,not(name=='p'and action=='nonfinal'));children.append([name,status,lib.XML_GetErrorCode(child)])
  actor[0]=saved;lib.XML_ParserFree(child)
  return 1 if name=='p'and action in ('unknown','invalid')else int(status==1)
 @NS
 def ns(_):event('not-standalone');return int(not reject)
 @ATT
 def att(_,element,name,kind,value,required):event('attribute',D(element),D(name),D(kind),D(value),required)
 @ENT
 def ent(_,name,parameter,value,length,base,system,public,notation):event('entity',D(name),parameter,c.string_at(value,length).decode()if value else None,D(system))
 @TEXT
 def default(_,p,n):event('default',c.string_at(p,n).decode())
 @TEXT
 def text(_,p,n):event('text',c.string_at(p,n).decode())
 @SKIP
 def skipped(_,name,parameter):event('skipped',D(name),parameter)
 @START
 def start(_,name,attrs):
  pointers=c.cast(attrs,c.POINTER(S));values=[];i=0
  while pointers[i]:values.append([D(pointers[i]),D(pointers[i+1])]);i+=2
  event('start',D(name),values)
 for setter,callback in [('XML_SetExternalEntityRefHandler',external),('XML_SetNotStandaloneHandler',ns),('XML_SetAttlistDeclHandler',att),('XML_SetEntityDeclHandler',ent),('XML_SetDefaultHandlerExpand',default),('XML_SetCharacterDataHandler',text),('XML_SetSkippedEntityHandler',skipped),('XML_SetStartElementHandler',start)]:getattr(lib,setter)(root,callback)
 assert lib.XML_UseForeignDTD(root,1)==0;assert lib.XML_SetParamEntityParsing(root,mode)==1
 doc=(('<?xml version="1.0" standalone="'+standalone+'"?>')if standalone else '')+prefix+'<r>&'+entity+';</r>'
 status=parse(root,doc.encode());error=lib.XML_GetErrorCode(root);lib.XML_ParserFree(root)
 return dict(status=status,error=error,children=children,events=events)
def main():
 libs={'reference':setup(REF),'candidate':setup(CAND)}
 bodies={
  'attribute-last':"<!ENTITY % p SYSTEM 'p'><!ENTITY supplied 'S'><!ATTLIST r a CDATA 'A' %p;>",
  'attribute-first':"<!ENTITY % p SYSTEM 'p'><!ATTLIST r a CDATA %p; 'A'><!ENTITY supplied 'S'>",
  'element-last':"<!ENTITY % p SYSTEM 'p'><!ENTITY supplied 'S'><!ELEMENT r EMPTY %p;>",
  'between-declarations':"<!ENTITY % p SYSTEM 'p'><!ENTITY supplied 'S'>%p;",
 }
 rows=[]
 for (name,body),action,mode,standalone,width,reject,entity,prefix in itertools.product(bodies.items(),['skip','create','nonfinal','empty'],[1,2],[None,'yes'],[0,1,7],[False,True],['missing','supplied'],['','<!DOCTYPE r []>']):
  args=dict(body=body,action=action,mode=mode,standalone=standalone,width=width,reject=reject,entity=entity,prefix=prefix)
  observations={label:probe(lib,**args)for label,lib in libs.items()};rows.append(dict(name=name,case=args,**observations))
 diffs=[dict(index=i,**row)for i,row in enumerate(rows)if row['reference']!=row['candidate']]
 outcomes=lambda r:[r['status'],r['error'],r['children']]
 summary=dict(cases=len(rows),differences=len(diffs),outcome_differences=sum(outcomes(r['reference'])!=outcomes(r['candidate'])for r in rows),libraries={label:dict(path=path,sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest())for label,path in [('reference',REF),('candidate',CAND)]},diffs=diffs)
 with gzip.open(str(OUT)+'.cases.json.gz','wt')as f:json.dump(rows,f)
 Path(str(OUT)+'.json').write_text(json.dumps(summary,indent=2)+'\n');print({k:v for k,v in summary.items()if k not in ('diffs','libraries')})
 for action in ['skip','create','nonfinal','empty']:
  row=next(r for r in rows if r['name']=='attribute-last'and r['case']==dict(body=bodies['attribute-last'],action=action,mode=2,standalone=None,width=0,reject=False,entity='missing',prefix=''))
  print(action,row,flush=True)
if __name__=='__main__':main()
