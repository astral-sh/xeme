from pathlib import Path
import hashlib,json,tarfile
root=Path('/tmp/oriole-grammar-fuzz');out=root/'fuzz/seeds/value_family';out.mkdir(parents=True,exist_ok=True)
marker=b'ORIOLE-DTD-GRAMMAR\0';manifest={}
def seed(name,selector,controls=None,p=b"<!ENTITY side 'S'>",q=b'Q',**notes):
 if controls is None:
  controls=bytearray(32);controls[3]=255;controls[11]=59;controls[12]=2
 else:controls=bytearray(controls)
 controls[13:15]=len(p).to_bytes(2,'little')
 data=bytes(controls)+marker+bytes([selector])+p+q
 (out/name).write_bytes(data)
 manifest[name]=dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),selector=selector,control_bytes=list(controls),p_hex=p.hex(),q_hex=q.hex(),**notes)
for selector in range(12):
 seed(f'grammar-{selector:02}-read',selector)
 c=bytearray(32);c[3]=0;c[11]=59;c[12]=2;c[18]=1
 seed(f'grammar-{selector:02}-skip-chunk1',selector,c)
 c[18]=0;c[11]=2;c[24]=7<<3
 seed(f'grammar-{selector:02}-install-handlers',selector,c)
 c[11]=59;c[24]=0;c[18]=7;c[15]=1;c[29]=3;c[30]=3;c[31]=1
 seed(f'grammar-{selector:02}-retain-unfinished',selector,c,p=b'<')
for selector,change in [(3,1),(4,1),(5,1),(7,3),(6,5),(11,3)]:
 c=bytearray(32);c[3]=255;c[11]=59;c[12]=2;c[24]=change<<3
 seed(f'grammar-{selector:02}-remove-handler',selector,c)
for fail,selector in [(1,8),(8,6),(32,4),(64,8),(128,6),(256,4)]:
 c=bytearray(32);c[0]=1;c[1:3]=(fail-1).to_bytes(2,'little');c[3]=0;c[11]=59;c[12]=2
 seed(f'grammar-allocation-{fail}',selector,c,fail_nth=fail)
for selector,p in [(0,b"<!ENTITY e 'CHILD'>"),(1,b"<!ENTITY e 'CHILD'>"),(10,b'%e;'),(8,b"<!ENTITY % inner 'I'>")]:
 seed(f'grammar-{selector:02}-reservation-or-value',selector,p=p,q=b'"Q%inner;R"')
for endian in ('utf-16-le','utf-16-be'):
 c=bytearray(32);c[3]=0;c[11]=59;c[12]=2
 bom=b'\xff\xfe' if endian.endswith('le') else b'\xfe\xff'
 seed(f'grammar-child-{endian}',8,c,p=bom+"<!ENTITY side 'S'>".encode(endian),q=bom+'"value"'.encode(endian))
for base_name,selector in [('custom-abort',6),('custom-declaration',8),('custom-two-three-four',4),('custom-reentry',10)]:
 base=Path('/home/dev-user/code/oss/oriole/fuzz/seeds/value_family')/base_name;original=base.read_bytes();c=bytearray(original[:32]);c[11]|=56
 body=original[32:];split=int.from_bytes(c[13:15],'little')%(len(body)+1)
 seed('grammar-'+base_name,selector,c,p=body[:split],q=body[split:],base=str(base),base_sha256=hashlib.sha256(original).hexdigest())
(root/'seed-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
checked=[]
files=list(Path('/home/dev-user/code/oss/oriole/fuzz/seeds/value_family').iterdir())
assert all(not p.read_bytes()[32:].startswith(marker)for p in files if p.is_file())
checked.append(dict(source='current value_family named seeds',count=sum(p.is_file()for p in files),marker_matches=0))
for archive in sorted(Path('/tmp/oriole-value-campaign-handoff/value_family').glob('*corpus.tar.gz')):
 count=0
 with tarfile.open(archive,'r:gz')as tar:
  for member in tar:
   if member.isfile():
    data=tar.extractfile(member).read();assert not data[32:].startswith(marker);count+=1
 checked.append(dict(source=str(archive),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),count=count,marker_matches=0))
(root/'corpus-compatibility.json').write_text(json.dumps(dict(marker_hex=marker.hex(),sources=checked,meaning='No existing named or frozen campaign input activates the new payload marker; all 32 control bytes and unmarked payload splitting retain their old interpretation.'),indent=2)+'\n')
print(len(manifest));print(checked)
