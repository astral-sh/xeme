# Hash-salt configuration candidate

`candidate.patch` applies against the captured files under `base/` (root HEAD
`77c1c4fb4ad8c87de113ced1b7958fb5a5b0ace2`). `source.json` records every changed
file's before/after hash and all Rust build inputs. No shared checkout was edited.

Both Expat salt APIs now mix caller bytes into the randomized hasher. Zero salt
keeps the default hash stream without an extra SipHash update. Changing salt
prepares every replacement table and nested default-attribute index before moving
entries; allocation failure preserves old tables, contents, and configuration.
The reserved `xml` namespace survives. Future duplicate-check sets, default indexes,
and child parsers inherit the configured salt.

The C adapter follows the root's existing lifetime tokens. Initial and completed
roots accept setters; roots that started but did not finish reject them, including
empty nonfinal input. Busy roots and stale child-parent tokens reject configuration.
Reset preserves caller salt. Existing children retain valid independent hash states
when their root changes salt, as agreed with root; newly created children inherit
its new salt. Secret random keys remain present even for a predictable caller salt.

## Validation

- 114 unique tests passed across the affected packages: 13 core library, 29 storage,
  69 C ABI, two safe-core allocation tests, and one C allocator/reentry test.
- Reconfiguration failure at each of seven allocation points preserves declarations,
  defaults, prior salt, allocator routing, and ownership; successful retry works.
- Strict Clippy for affected packages/all targets and formatting pass.
- Expat 2.8.4: all 48 selected configurations pass against both implementations.
  These are six chunk modes times two deferral modes for `test_hash_salt_setter`,
  `test_hash_collision`, `test_set_foreign_dtd`, and `test_foreign_dtd_with_doctype`.
  The first test covers the 12 previously failing configurations.
- `probe.py` reproduces initial, empty, partial, finished, syntax-error, and
  child-through-root setter states. Final candidate output exactly equals
  `expat-probe.json`; both outputs are retained.

Exact Cargo environment, commands, log hashes, and counts are in `validation.json`.
Upstream commands and exact linked-library origin are recorded in each
`upstream-{final,reference}/manifest.json`. The final unoptimized local Ohm binary
is `upstream-final/liboriole_expat.so`; it is not a release-performance artifact.

Rerun the selected upstream suite against an integrated library with:

```sh
taskset -c 4 python tools/upstream-expat/run.py \
  --source /home/dev-user/.cache/oriole/upstream/expat-2.8.4 \
  --config /home/dev-user/.cache/oriole/expat-build/expat_config.h \
  --library /absolute/path/to/candidate.so \
  --output /tmp/new-empty-hash-salt-results \
  --tests test_hash_salt_setter test_hash_collision \
    test_set_foreign_dtd test_foreign_dtd_with_doctype
```

No full API matrix, release benchmark, or additional sanitizer campaign was run.
The default wrapper introduces a zero-salt branch; its performance still needs
measurement in the integrated release build. The source snapshot predates root's
raw-attribute-offset integration. The core constructor adds no field, so merging
with the amplification accounting change should be straightforward. Both patches
edit the unsupported-setter bullet in the C crate README; remove that bullet once
both implementations are integrated and retain each new paragraph.
