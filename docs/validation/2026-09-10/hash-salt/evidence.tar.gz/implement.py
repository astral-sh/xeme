from pathlib import Path
root=Path('/tmp/oriole-hash-salt')
def edit(name,old,new):
 p=root/name;s=p.read_text();assert old in s,(name,old[:80]);p.write_text(s.replace(old,new))
store='crates/oriole_storage/src/lib.rs'
edit(store,'mod allocator;','mod allocator;\nmod hashing;')
edit(store,'pub use allocator::{Allocator, CustomAllocator, MemorySuite, in_allocator_callback};','pub use allocator::{Allocator, CustomAllocator, MemorySuite, in_allocator_callback};\npub use hashing::SaltedRandomState;')
edit(store,'std::collections::hash_map::RandomState, Allocator','SaltedRandomState, Allocator')
edit(store,'std::collections::hash_map::RandomState::new()','SaltedRandomState::default()')
(root/'crates/oriole_storage/src/hashing.rs').write_text('''//! Caller salt augments, rather than replaces, the process's secret hash keys.

use std::collections::hash_map::{DefaultHasher, RandomState};
use std::hash::{BuildHasher, Hasher};

/// Randomized hashing with optional caller-provided salt mixed into every hash.
///
/// Keeping `RandomState` protects tables even when an application supplies a
/// predictable salt. The all-zero default keeps the original hash stream and
/// avoids extra hashing work for applications that do not configure a salt.
#[derive(Clone, Debug, Default)]
pub struct SaltedRandomState {
    random: RandomState,
    salt: [u8; 16],
}

impl SaltedRandomState {
    /// Retain the secret random keys while selecting a caller salt.
    #[must_use]
    pub fn with_salt(&self, salt: [u8; 16]) -> Self {
        Self { random: self.random.clone(), salt }
    }

    /// Return the configured public salt, without exposing secret random keys.
    #[must_use]
    pub fn salt(&self) -> [u8; 16] {
        self.salt
    }
}

impl BuildHasher for SaltedRandomState {
    type Hasher = DefaultHasher;

    #[inline]
    fn build_hasher(&self) -> Self::Hasher {
        let mut hasher = self.random.build_hasher();
        if self.salt != [0; 16] {
            hasher.write(&self.salt);
        }
        hasher
    }
}
''')
lib='crates/oriole/src/lib.rs'
edit(lib,'AllocError, Allocator, HashMap, Queue, Shared, String, TryClone, Vec, hash_map, hash_set,','AllocError, Allocator, HashMap, HashSet, Queue, Shared, String, TryClone, Vec, hash_map,')
edit(lib,'fn new(allocator: Allocator) -> Self {\n        Self {\n            ordered: Vec::new_in(allocator),\n            by_name: hash_map(allocator),','fn new(allocator: Allocator, salt: [u8; 16]) -> Self {\n        let map: HashMap<String, usize> = hash_map(allocator);\n        Self {\n            ordered: Vec::new_in(allocator),\n            by_name: HashMap::with_hasher_in(map.hasher().with_salt(salt), allocator),')
edit(lib,'Self::new(*self.ordered.allocator())','Self::new(*self.ordered.allocator(), self.by_name.hasher().salt())')
edit(lib,'DefaultAttributes::new(self.allocator)','DefaultAttributes::new(self.allocator, self.hash_salt())')
edit('crates/oriole/src/dtd.rs','DefaultAttributes::new(self.allocator)','DefaultAttributes::new(self.allocator, self.hash_salt())')
edit(lib,'let mut names = (raw_attrs.len() > 8).then(|| hash_set(self.allocator));','let mut names = (raw_attrs.len() > 8).then(|| {\n            HashSet::with_hasher_in(self.namespaces.hasher().clone(), self.allocator)\n        });')
edit(lib,'let mut expanded = hash_set(self.allocator);','let mut expanded = HashSet::with_hasher_in(\n                self.namespaces.hasher().clone(), self.allocator,\n            );')
edit(lib,'        child\n            .decoder\n            .inherit_map','        child.set_hash_salt(self.hash_salt())?;\n        child\n            .decoder\n            .inherit_map')
anchor='    /// Change the protocol encoding before receiving input, preserving parser options.'
new='''    /// Return the public caller salt, without exposing secret randomized keys.
    #[must_use]
    pub fn hash_salt(&self) -> [u8; 16] {
        self.namespaces.hasher().salt()
    }

    /// Replace the caller salt while retaining randomized hash protection.
    ///
    /// Every table is prepared before changing any table, so allocation failure
    /// preserves all contents and the previous salt. Owned external children
    /// retain their existing hash state; subsequently created children inherit
    /// the new salt. Adapters enforce their own configuration timing rules.
    #[doc(hidden)]
    pub fn set_hash_salt(&mut self, salt: [u8; 16]) -> Result<(), Error> {
        if self.hash_salt() == salt {
            return Ok(());
        }
        let namespaces = prepare_salted_map(&self.namespaces, salt)?;
        let entities = prepare_salted_map(&self.entities, salt)?;
        let parameters = prepare_salted_map(&self.parameter_entities, salt)?;
        let defaults = prepare_salted_map(&self.defaults, salt)?;
        let mut indexes = Vec::new_in(self.allocator);
        indexes.try_reserve_exact(self.defaults.len())?;
        for attributes in self.defaults.values() {
            indexes.push(prepare_salted_map(&attributes.by_name, salt)?);
        }
        // No allocation or callback occurs after preparation. Rebuild inner
        // indexes before changing the outer table's iteration order.
        for (attributes, index) in self.defaults.values_mut().zip(indexes) {
            replace_hash_map(&mut attributes.by_name, index);
        }
        replace_hash_map(&mut self.namespaces, namespaces);
        replace_hash_map(&mut self.entities, entities);
        replace_hash_map(&mut self.parameter_entities, parameters);
        replace_hash_map(&mut self.defaults, defaults);
        Ok(())
    }

'''+anchor
edit(lib,anchor,new)
# Place helpers before the first private parser-support struct, avoiding method scopes.
anchor='#[derive(Debug)]\nstruct DefaultAttribute {'
new='''/// Reserve a replacement table without changing the live table or its secret keys.
fn prepare_salted_map<K: Eq + std::hash::Hash, V>(
    map: &HashMap<K, V>,
    salt: [u8; 16],
) -> Result<HashMap<K, V>, AllocError> {
    let mut replacement = HashMap::with_hasher_in(
        map.hasher().with_salt(salt), *map.allocator(),
    );
    replacement.try_reserve(map.len())?;
    Ok(replacement)
}

/// Move entries into a fully reserved table; keys and values retain their allocator.
fn replace_hash_map<K: Eq + std::hash::Hash, V>(
    map: &mut HashMap<K, V>,
    mut replacement: HashMap<K, V>,
) {
    debug_assert!(replacement.is_empty() && replacement.capacity() >= map.len());
    for (key, value) in map.drain() {
        replacement.insert(key, value);
    }
    *map = replacement;
}

'''+anchor
edit(lib,anchor,new)
ffi='crates/oriole_expat/src/lib.rs'
edit(ffi,'                let family = Shared::try_new_in(FamilyBudget::default(), allocator)?;\n                let lifetime = Shared::try_new_in(AtomicPtr::new(parser), allocator)?;','                core.set_hash_salt((*parser).core.hash_salt())\n                    .map_err(|_| AllocError::OutOfMemory)?;\n                let family = Shared::try_new_in(FamilyBudget::default(), allocator)?;\n                let lifetime = Shared::try_new_in(AtomicPtr::new(parser), allocator)?;')
old='''#[unsafe(no_mangle)]
pub unsafe extern "C" fn XML_SetHashSalt(_parser: XML_Parser, _salt: c_ulong) -> c_int {
    // The core's randomized hash tables do not support caller-supplied seeds.
    0
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn XML_SetHashSalt16Bytes(_parser: XML_Parser, _entropy: *const u8) -> u8 {
    0
}'''
new='''/// Configure the live root while retaining independent child table hash states.
unsafe fn set_hash_salt(mut parser: XML_Parser, salt: [u8; 16]) -> c_int {
    if parser.is_null() || in_allocator_callback() {
        return 0;
    }
    // SAFETY: Family operations are serialized. Lifetime tokens prevent walking
    // into a parent freed or replaced by reset; allocator reentry is rejected
    // before any parser reference is created.
    unsafe {
        while let Some(parent) = &(*parser).parent_lifetime {
            parser = parent.load(Ordering::Acquire);
            if parser.is_null() {
                return 0;
            }
        }
        if (*parser).destroying || (*parser).busy || !matches!((*parser).state, 0 | 2) {
            return 0;
        }
        with_parser_tracking(parser, || {
            catch_unwind(AssertUnwindSafe(|| (*parser).core.set_hash_salt(salt)))
                .ok()
                .and_then(Result::ok)
                .map_or(0, |()| 1)
        })
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn XML_SetHashSalt(parser: XML_Parser, salt: c_ulong) -> c_int {
    let mut entropy = [0; 16];
    entropy[8..].copy_from_slice(&(salt as u64).to_le_bytes());
    // SAFETY: Forward the live, serialized parser contract to the common setter.
    unsafe { set_hash_salt(parser, entropy) }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn XML_SetHashSalt16Bytes(parser: XML_Parser, entropy: *const u8) -> u8 {
    if parser.is_null() || entropy.is_null() || in_allocator_callback() {
        return 0;
    }
    // SAFETY: The caller provides sixteen readable bytes, copied before any
    // allocation callback. The common setter checks the parser family state.
    unsafe { set_hash_salt(parser, *entropy.cast::<[u8; 16]>()) as u8 }
}'''
edit(ffi,old,new)
