import ctypes as c
import json
import sys
from pathlib import Path
p=Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4')
l=c.CDLL(str(p))
for n,a,r in [('XML_ParserCreate',[c.c_void_p],c.c_void_p),('XML_ExternalEntityParserCreate',[c.c_void_p,c.c_char_p,c.c_void_p],c.c_void_p),('XML_SetHashSalt',[c.c_void_p,c.c_ulong],c.c_int),('XML_SetHashSalt16Bytes',[c.c_void_p,c.c_char_p],c.c_ubyte),('XML_Parse',[c.c_void_p,c.c_char_p,c.c_int,c.c_int],c.c_int),('XML_StopParser',[c.c_void_p,c.c_ubyte],c.c_int),('XML_ParserReset',[c.c_void_p,c.c_void_p],c.c_ubyte),('XML_ParserFree',[c.c_void_p],None)]:
 f=getattr(l,n);f.argtypes=a;f.restype=r
out={}
for name,xml,final in [('initial',None,0),('empty',b'',0),('partial',b'<r>',0),('finished',b'<r/>',1),('invalid',b'<r',1),('bad_name',b'<1/>',1)]:
 r=l.XML_ParserCreate(None)
 status=None if xml is None else l.XML_Parse(r,xml,len(xml),final)
 out[name]={'parse':status,'old':l.XML_SetHashSalt(r,123),'new':l.XML_SetHashSalt16Bytes(r,b'0123456789abcdef')}
 l.XML_ParserFree(r)
r=l.XML_ParserCreate(None)
x=l.XML_ExternalEntityParserCreate(r,b'p=urn:p',None)
out['child_created']={'child':bool(x),'salt_through_child':l.XML_SetHashSalt(x,123),'child_parse':l.XML_Parse(x,b'<p:r/>',6,1),'root_parse':l.XML_Parse(r,b'<r/>',4,1)}
l.XML_ParserFree(x);l.XML_ParserFree(r)
print(json.dumps(out,indent=2))
