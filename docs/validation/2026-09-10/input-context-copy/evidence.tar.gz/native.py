import pathlib,subprocess,json,hashlib,os
w=pathlib.Path('/tmp/oriole-context-copy-integrated');old=pathlib.Path('/tmp/oriole-security-controls-integrated');baseline=json.loads((old/'native.json').read_text());r={'runs':[],'scope':baseline['scope']};env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
for row in baseline['runs']:
 command=[x.replace(str(old),str(w)) for x in row['command']];build=subprocess.run(command,capture_output=True,text=True);assert build.returncode==0,build.stderr
 binary=pathlib.Path(command[-1]);run=subprocess.run([str(binary)],env=env,capture_output=True,text=True,timeout=120);r['runs'].append({'command':command,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr});(w/'native.json').write_text(json.dumps(r,indent=2)+'\n');print(binary.name,run.returncode,run.stdout,flush=True);assert run.returncode==0,run.stderr
