from pathlib import Path
import hashlib,json,tarfile,shutil,re,statistics
w=Path('/tmp/oriole-context-copy-integrated');d=Path('docs/validation/2026-09-10/input-context-copy');d.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for dirname,label in [('/tmp/oriole-input-context-copy','isolated'),('/tmp/oriole-handlers-snapshot','rejected-handler-snapshot')]:
 base=Path(dirname)
 for p in base.rglob('*'):
  if not p.is_file() or p.is_symlink():continue
  with p.open('rb') as f:magic=f.read(8)
  if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
  out=w/label/p.relative_to(base);out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
source=json.loads((w/'source.json').read_text());diff=json.loads((w/'differential/summary.json').read_text());screen=json.loads((w/'screen.json').read_text());assert screen['status']=='passed' and diff['exact_pass'];tests=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(w/'tests.log').read_text())));assert tests==74
review={'reviewer':'integrating root agent; independent of isolated patch author','scope':'One-line FFI input-context change and existing storage copy helper','patch_sha256':sha(w/'source.patch'),'findings':[],'checks':['The existing fallible helper reserves exactly the same additional length before initializing bytes and publishing length.','Context drain, raw input index, retention window and error propagation remain in the same order.','The input slice and context allocation are distinct under valid C API lifetimes; no parser borrow is introduced across callbacks.','Allocator selection, metadata accounting and callback guards remain on the same reserve path; no new unsafe code is added.']};(w/'review.json').write_text(json.dumps(review,indent=2)+'\n')
rows=[]
for ns in [False,True]:
 for name in ['vulkan','wayland','maven','batik','gtk','docbook']:
  medians={label:statistics.median(s['seconds'] for r in screen['samples'] if r['input']==name and r['namespaces']==ns and r['label']==label for s in r['output']['samples'] if not s['warmup']) for label in ['control','candidate','expat']};rows.append({'project':name,'namespaces':ns,'median_seconds':medians,'speedup':medians['control']/medians['candidate']})
validation={'rust_tests':tests,'differential':{k:diff[k] for k in ['cases','difference_counts','semantic_pass','exact_pass']},'streaming_cases':32,'native_suites':6,'allocation_cases_per_linkage':333,'screen':rows};(w/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
files={}
for p in sorted(w.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 files[str(p.relative_to(w))]={'sha256':sha(p),'bytes':p.stat().st_size}
with tarfile.open(d/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n in files:t.add(w/n,arcname=n,recursive=False)
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==files[m.name]['sha256']
manifest={'archive_sha256':sha(d/'evidence.tar.gz'),'members':files};(d/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
(d/'README.md').write_text(f'''# Copy retained input context in bulk

The C input-context retention path used allocator-api2's generic byte-by-byte `extend_from_slice`. We use the existing fallible storage copy helper, which reserves once and copies the initialized slice in bulk. Retention boundaries, indexing, allocator selection, accounting and callback guards retain their order. No new unsafe code is introduced.

The integrated library is `{source['library_sha256']['liboriole_expat.so']}` on parent `{source['parent_commit']}`. All **74 FFI/memory Rust checks**, strict Clippy/formatting, **1,518 exact differential comparisons**, **32 context/suspension/handler-switch probes** and six shared/static native C suites pass, including **333 allocation failure scenarios per linkage**. C callers are ASan/UBSan instrumented; Rust is uninstrumented, leak sanitizer is disabled, and selected live allocation counts are checked.

The integrated paired six-project screen (4 KiB, namespaces off/on, five randomized groups, five measured parses after warmup) improves all medians by **2–13%** over the preceding runtime. All native output hashes/counts match. The isolated 4/64 KiB screen records 5–14% improvements, and Wayland instructions fall 43,009,988 → 37,881,488 (**11.9%**). Every integrated project remains slower than Expat. These shared-host screens are not a final full-application benchmark.

We also preserve a rejected callback-handler snapshot experiment. It removed eager pointer loads and reduced instructions by only 0.52%, with no consistent project speedup. That runtime patch is not included.

[evidence.tar.gz](evidence.tar.gz) contains exact source/build hashes, commands, raw samples, focused validation and scoped source review. ELF/static artifacts are excluded and identified by hash. [files.json](files.json) verifies every member. Archive SHA256: `{manifest['archive_sha256']}`. This layer does not claim a new full API/CPython/PBS campaign.
''')
print(json.dumps({'members':len(files),'archive_bytes':(d/'evidence.tar.gz').stat().st_size,'archive_sha256':manifest['archive_sha256']}))
