
/tmp/oriole-handlers-snapshot/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .text:

000000000002fdc0 <oriole_expat::dispatch>:
   2fdc0:	55                   	push   %rbp
   2fdc1:	41 57                	push   %r15
   2fdc3:	41 56                	push   %r14
   2fdc5:	41 55                	push   %r13
   2fdc7:	41 54                	push   %r12
   2fdc9:	53                   	push   %rbx
   2fdca:	48 81 ec 98 05 00 00 	sub    $0x598,%rsp
   2fdd1:	48 89 f3             	mov    %rsi,%rbx
   2fdd4:	48 8b 06             	mov    (%rsi),%rax
   2fdd7:	48 83 e8 03          	sub    $0x3,%rax
   2fddb:	b9 0d 00 00 00       	mov    $0xd,%ecx
   2fde0:	48 0f 43 c8          	cmovae %rax,%rcx
   2fde4:	49 89 fe             	mov    %rdi,%r14
   2fde7:	48 83 f9 18          	cmp    $0x18,%rcx
   2fdeb:	0f 92 c0             	setb   %al
   2fdee:	bd 00 80 a0 00       	mov    $0xa08000,%ebp
   2fdf3:	d3 ed                	shr    %cl,%ebp
   2fdf5:	40 20 c5             	and    %al,%bpl
   2fdf8:	80 bf b8 08 00 00 00 	cmpb   $0x0,0x8b8(%rdi)
   2fdff:	49 89 fb             	mov    %rdi,%r11
   2fe02:	75 03                	jne    2fe07 <oriole_expat::dispatch+0x47>
   2fe04:	4d 8b 1e             	mov    (%r14),%r11
   2fe07:	40 84 ed             	test   %bpl,%bpl
   2fe0a:	74 24                	je     2fe30 <oriole_expat::dispatch+0x70>
   2fe0c:	41 83 be f8 08 00 00 	cmpl   $0xffffffff,0x8f8(%r14)
   2fe13:	ff 
   2fe14:	74 2d                	je     2fe43 <oriole_expat::dispatch+0x83>
   2fe16:	4d 8b be 28 09 00 00 	mov    0x928(%r14),%r15
   2fe1d:	49 ff cf             	dec    %r15
   2fe20:	48 8d 05 75 9b fd ff 	lea    -0x2648b(%rip),%rax        # 999c <std::thread::current::id::ID+0x992c>
   2fe27:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
   2fe2b:	48 01 c1             	add    %rax,%rcx
   2fe2e:	ff e1                	jmp    *%rcx
   2fe30:	45 31 ff             	xor    %r15d,%r15d
   2fe33:	48 8d 05 62 9b fd ff 	lea    -0x2649e(%rip),%rax        # 999c <std::thread::current::id::ID+0x992c>
   2fe3a:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
   2fe3e:	48 01 c1             	add    %rax,%rcx
   2fe41:	ff e1                	jmp    *%rcx
   2fe43:	45 31 ff             	xor    %r15d,%r15d
   2fe46:	48 8d 05 4f 9b fd ff 	lea    -0x264b1(%rip),%rax        # 999c <std::thread::current::id::ID+0x992c>
   2fe4d:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
   2fe51:	48 01 c1             	add    %rax,%rcx
   2fe54:	ff e1                	jmp    *%rcx
   2fe56:	49 8b 8e b8 04 00 00 	mov    0x4b8(%r14),%rcx
   2fe5d:	49 8b 86 c8 04 00 00 	mov    0x4c8(%r14),%rax
   2fe64:	48 85 c9             	test   %rcx,%rcx
   2fe67:	48 0f 45 c8          	cmovne %rax,%rcx
   2fe6b:	48 85 c0             	test   %rax,%rax
   2fe6e:	48 0f 44 c8          	cmove  %rax,%rcx
   2fe72:	e9 de 02 00 00       	jmp    30155 <oriole_expat::dispatch+0x395>
   2fe77:	48 8b 43 28          	mov    0x28(%rbx),%rax
   2fe7b:	48 8b 70 30          	mov    0x30(%rax),%rsi
   2fe7f:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   2fe83:	0f 84 7f 01 00 00    	je     30008 <oriole_expat::dispatch+0x248>
   2fe89:	48 8b 48 68          	mov    0x68(%rax),%rcx
   2fe8d:	48 01 f1             	add    %rsi,%rcx
   2fe90:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   2fe94:	0f 85 7d 01 00 00    	jne    30017 <oriole_expat::dispatch+0x257>
   2fe9a:	e9 26 02 00 00       	jmp    300c5 <oriole_expat::dispatch+0x305>
   2fe9f:	48 89 d8             	mov    %rbx,%rax
   2fea2:	4c 89 db             	mov    %r11,%rbx
   2fea5:	49 89 d4             	mov    %rdx,%r12
   2fea8:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   2fead:	48 8d 78 08          	lea    0x8(%rax),%rdi
   2feb1:	b0 01                	mov    $0x1,%al
   2feb3:	89 44 24 20          	mov    %eax,0x20(%rsp)
   2feb7:	41 b5 01             	mov    $0x1,%r13b
   2feba:	b0 01                	mov    $0x1,%al
   2febc:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   2fec0:	b0 01                	mov    $0x1,%al
   2fec2:	89 44 24 30          	mov    %eax,0x30(%rsp)
   2fec6:	b0 01                	mov    $0x1,%al
   2fec8:	89 44 24 38          	mov    %eax,0x38(%rsp)
   2fecc:	b0 01                	mov    $0x1,%al
   2fece:	89 44 24 48          	mov    %eax,0x48(%rsp)
   2fed2:	b0 01                	mov    $0x1,%al
   2fed4:	89 44 24 40          	mov    %eax,0x40(%rsp)
   2fed8:	b0 01                	mov    $0x1,%al
   2feda:	89 44 24 50          	mov    %eax,0x50(%rsp)
   2fede:	b0 01                	mov    $0x1,%al
   2fee0:	89 44 24 60          	mov    %eax,0x60(%rsp)
   2fee4:	b0 01                	mov    $0x1,%al
   2fee6:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   2feea:	b0 01                	mov    $0x1,%al
   2feec:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   2fef1:	b0 01                	mov    $0x1,%al
   2fef3:	89 44 24 14          	mov    %eax,0x14(%rsp)
   2fef7:	b0 01                	mov    $0x1,%al
   2fef9:	89 44 24 10          	mov    %eax,0x10(%rsp)
   2fefd:	b0 01                	mov    $0x1,%al
   2feff:	89 44 24 08          	mov    %eax,0x8(%rsp)
   2ff03:	b0 01                	mov    $0x1,%al
   2ff05:	89 44 24 18          	mov    %eax,0x18(%rsp)
   2ff09:	b0 01                	mov    $0x1,%al
   2ff0b:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   2ff0f:	ff 15 63 f1 09 00    	call   *0x9f163(%rip)        # cf078 <_GLOBAL_OFFSET_TABLE_+0x220>
   2ff15:	48 89 d1             	mov    %rdx,%rcx
   2ff18:	4c 89 e2             	mov    %r12,%rdx
   2ff1b:	49 89 db             	mov    %rbx,%r11
   2ff1e:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
   2ff23:	e9 2d 02 00 00       	jmp    30155 <oriole_expat::dispatch+0x395>
   2ff28:	48 8b 43 28          	mov    0x28(%rbx),%rax
   2ff2c:	48 8b 48 68          	mov    0x68(%rax),%rcx
   2ff30:	48 03 48 30          	add    0x30(%rax),%rcx
   2ff34:	48 03 88 a0 00 00 00 	add    0xa0(%rax),%rcx
   2ff3b:	83 b8 a8 00 00 00 ff 	cmpl   $0xffffffff,0xa8(%rax)
   2ff42:	0f 84 7d 01 00 00    	je     300c5 <oriole_expat::dispatch+0x305>
   2ff48:	48 8b 80 d8 00 00 00 	mov    0xd8(%rax),%rax
   2ff4f:	e9 fe 01 00 00       	jmp    30152 <oriole_expat::dispatch+0x392>
   2ff54:	48 8b 43 38          	mov    0x38(%rbx),%rax
   2ff58:	4c 8b 43 70          	mov    0x70(%rbx),%r8
   2ff5c:	4d 85 c0             	test   %r8,%r8
   2ff5f:	0f 84 21 01 00 00    	je     30086 <oriole_expat::dispatch+0x2c6>
   2ff65:	48 8b 73 60          	mov    0x60(%rbx),%rsi
   2ff69:	44 89 c7             	mov    %r8d,%edi
   2ff6c:	83 e7 03             	and    $0x3,%edi
   2ff6f:	49 83 f8 04          	cmp    $0x4,%r8
   2ff73:	0f 83 53 01 00 00    	jae    300cc <oriole_expat::dispatch+0x30c>
   2ff79:	45 31 c9             	xor    %r9d,%r9d
   2ff7c:	31 c9                	xor    %ecx,%ecx
   2ff7e:	e9 a0 01 00 00       	jmp    30123 <oriole_expat::dispatch+0x363>
   2ff83:	83 7b 38 ff          	cmpl   $0xffffffff,0x38(%rbx)
   2ff87:	0f 84 e3 00 00 00    	je     30070 <oriole_expat::dispatch+0x2b0>
   2ff8d:	48 8b 4b 68          	mov    0x68(%rbx),%rcx
   2ff91:	48 03 4b 30          	add    0x30(%rbx),%rcx
   2ff95:	e9 bb 01 00 00       	jmp    30155 <oriole_expat::dispatch+0x395>
   2ff9a:	8b 73 40             	mov    0x40(%rbx),%esi
   2ff9d:	31 c9                	xor    %ecx,%ecx
   2ff9f:	83 7b 08 ff          	cmpl   $0xffffffff,0x8(%rbx)
   2ffa3:	b8 00 00 00 00       	mov    $0x0,%eax
   2ffa8:	74 04                	je     2ffae <oriole_expat::dispatch+0x1ee>
   2ffaa:	48 8b 43 38          	mov    0x38(%rbx),%rax
   2ffae:	83 fe ff             	cmp    $0xffffffff,%esi
   2ffb1:	0f 84 9b 01 00 00    	je     30152 <oriole_expat::dispatch+0x392>
   2ffb7:	48 8b 4b 70          	mov    0x70(%rbx),%rcx
   2ffbb:	e9 92 01 00 00       	jmp    30152 <oriole_expat::dispatch+0x392>
   2ffc0:	83 7b 40 ff          	cmpl   $0xffffffff,0x40(%rbx)
   2ffc4:	0f 84 b1 00 00 00    	je     3007b <oriole_expat::dispatch+0x2bb>
   2ffca:	48 8b 4b 70          	mov    0x70(%rbx),%rcx
   2ffce:	48 03 4b 38          	add    0x38(%rbx),%rcx
   2ffd2:	e9 7e 01 00 00       	jmp    30155 <oriole_expat::dispatch+0x395>
   2ffd7:	83 7b 08 ff          	cmpl   $0xffffffff,0x8(%rbx)
   2ffdb:	74 09                	je     2ffe6 <oriole_expat::dispatch+0x226>
   2ffdd:	48 8b 4b 38          	mov    0x38(%rbx),%rcx
   2ffe1:	e9 6f 01 00 00       	jmp    30155 <oriole_expat::dispatch+0x395>
   2ffe6:	31 c9                	xor    %ecx,%ecx
   2ffe8:	e9 68 01 00 00       	jmp    30155 <oriole_expat::dispatch+0x395>
   2ffed:	48 8b 43 28          	mov    0x28(%rbx),%rax
   2fff1:	83 38 ff             	cmpl   $0xffffffff,(%rax)
   2fff4:	0f 84 93 00 00 00    	je     3008d <oriole_expat::dispatch+0x2cd>
   2fffa:	48 8b 70 30          	mov    0x30(%rax),%rsi
   2fffe:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   30002:	0f 85 81 fe ff ff    	jne    2fe89 <oriole_expat::dispatch+0xc9>
   30008:	31 c9                	xor    %ecx,%ecx
   3000a:	48 01 f1             	add    %rsi,%rcx
   3000d:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   30011:	0f 84 ae 00 00 00    	je     300c5 <oriole_expat::dispatch+0x305>
   30017:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
   3001e:	e9 2f 01 00 00       	jmp    30152 <oriole_expat::dispatch+0x392>
   30023:	48 8b 43 28          	mov    0x28(%rbx),%rax
   30027:	48 8b 70 30          	mov    0x30(%rax),%rsi
   3002b:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   3002f:	74 6d                	je     3009e <oriole_expat::dispatch+0x2de>
   30031:	48 8b 48 68          	mov    0x68(%rax),%rcx
   30035:	48 01 f1             	add    %rsi,%rcx
   30038:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   3003c:	74 6b                	je     300a9 <oriole_expat::dispatch+0x2e9>
   3003e:	48 8b b0 a0 00 00 00 	mov    0xa0(%rax),%rsi
   30045:	48 01 f1             	add    %rsi,%rcx
   30048:	83 b8 a8 00 00 00 ff 	cmpl   $0xffffffff,0xa8(%rax)
   3004f:	74 66                	je     300b7 <oriole_expat::dispatch+0x2f7>
   30051:	48 8b b0 d8 00 00 00 	mov    0xd8(%rax),%rsi
   30058:	48 01 f1             	add    %rsi,%rcx
   3005b:	83 b8 e0 00 00 00 ff 	cmpl   $0xffffffff,0xe0(%rax)
   30062:	74 61                	je     300c5 <oriole_expat::dispatch+0x305>
   30064:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
   3006b:	e9 e2 00 00 00       	jmp    30152 <oriole_expat::dispatch+0x392>
   30070:	31 c9                	xor    %ecx,%ecx
   30072:	48 03 4b 30          	add    0x30(%rbx),%rcx
   30076:	e9 da 00 00 00       	jmp    30155 <oriole_expat::dispatch+0x395>
   3007b:	31                   	.byte 0x31
