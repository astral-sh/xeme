
/tmp/oriole-text-coalescing/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .text:

000000000002fdd0 <oriole_expat::dispatch>:
   2fdd0:	55                   	push   %rbp
   2fdd1:	41 57                	push   %r15
   2fdd3:	41 56                	push   %r14
   2fdd5:	41 55                	push   %r13
   2fdd7:	41 54                	push   %r12
   2fdd9:	53                   	push   %rbx
   2fdda:	48 81 ec 08 06 00 00 	sub    $0x608,%rsp
   2fde1:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
   2fde6:	48 8b 06             	mov    (%rsi),%rax
   2fde9:	48 83 e8 03          	sub    $0x3,%rax
   2fded:	b9 0d 00 00 00       	mov    $0xd,%ecx
   2fdf2:	48 0f 43 c8          	cmovae %rax,%rcx
   2fdf6:	49 89 fe             	mov    %rdi,%r14
   2fdf9:	48 83 f9 18          	cmp    $0x18,%rcx
   2fdfd:	0f 92 c0             	setb   %al
   2fe00:	bb 00 80 a0 00       	mov    $0xa08000,%ebx
   2fe05:	d3 eb                	shr    %cl,%ebx
   2fe07:	20 c3                	and    %al,%bl
   2fe09:	80 bf b8 08 00 00 00 	cmpb   $0x0,0x8b8(%rdi)
   2fe10:	48 89 7c 24 68       	mov    %rdi,0x68(%rsp)
   2fe15:	75 08                	jne    2fe1f <oriole_expat::dispatch+0x4f>
   2fe17:	49 8b 06             	mov    (%r14),%rax
   2fe1a:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   2fe1f:	84 db                	test   %bl,%bl
   2fe21:	74 16                	je     2fe39 <oriole_expat::dispatch+0x69>
   2fe23:	41 83 be f8 08 00 00 	cmpl   $0xffffffff,0x8f8(%r14)
   2fe2a:	ff 
   2fe2b:	74 0c                	je     2fe39 <oriole_expat::dispatch+0x69>
   2fe2d:	4d 8b a6 28 09 00 00 	mov    0x928(%r14),%r12
   2fe34:	49 ff cc             	dec    %r12
   2fe37:	eb 03                	jmp    2fe3c <oriole_expat::dispatch+0x6c>
   2fe39:	45 31 e4             	xor    %r12d,%r12d
   2fe3c:	49 8b 86 00 08 00 00 	mov    0x800(%r14),%rax
   2fe43:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
   2fe4a:	00 
   2fe4b:	49 8b 86 08 08 00 00 	mov    0x808(%r14),%rax
   2fe52:	48 89 84 24 50 05 00 	mov    %rax,0x550(%rsp)
   2fe59:	00 
   2fe5a:	49 8b 86 10 08 00 00 	mov    0x810(%r14),%rax
   2fe61:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
   2fe68:	00 
   2fe69:	4d 8b 96 18 08 00 00 	mov    0x818(%r14),%r10
   2fe70:	49 8b 86 20 08 00 00 	mov    0x820(%r14),%rax
   2fe77:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
   2fe7e:	00 
   2fe7f:	49 8b 86 28 08 00 00 	mov    0x828(%r14),%rax
   2fe86:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   2fe8d:	00 
   2fe8e:	49 8b 86 30 08 00 00 	mov    0x830(%r14),%rax
   2fe95:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
   2fe9c:	00 
   2fe9d:	4d 8b 8e 38 08 00 00 	mov    0x838(%r14),%r9
   2fea4:	49 8b 86 40 08 00 00 	mov    0x840(%r14),%rax
   2feab:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
   2feb2:	00 
   2feb3:	49 8b 86 48 08 00 00 	mov    0x848(%r14),%rax
   2feba:	48 89 84 24 20 05 00 	mov    %rax,0x520(%rsp)
   2fec1:	00 
   2fec2:	4d 8b be 50 08 00 00 	mov    0x850(%r14),%r15
   2fec9:	49 8b 86 58 08 00 00 	mov    0x858(%r14),%rax
   2fed0:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
   2fed7:	00 
   2fed8:	4d 8b 86 60 08 00 00 	mov    0x860(%r14),%r8
   2fedf:	48 8d 05 b6 9a fd ff 	lea    -0x2654a(%rip),%rax        # 999c <std::thread::current::id::ID+0x992c>
   2fee6:	48 63 0c 88          	movslq (%rax,%rcx,4),%rcx
   2feea:	48 01 c1             	add    %rax,%rcx
   2feed:	4d 8b 9e 68 08 00 00 	mov    0x868(%r14),%r11
   2fef4:	4d 8b ae 78 08 00 00 	mov    0x878(%r14),%r13
   2fefb:	49 8b 86 80 08 00 00 	mov    0x880(%r14),%rax
   2ff02:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
   2ff09:	00 
   2ff0a:	49 8b 86 88 08 00 00 	mov    0x888(%r14),%rax
   2ff11:	48 89 84 24 10 05 00 	mov    %rax,0x510(%rsp)
   2ff18:	00 
   2ff19:	49 8b 86 90 08 00 00 	mov    0x890(%r14),%rax
   2ff20:	48 89 84 24 40 05 00 	mov    %rax,0x540(%rsp)
   2ff27:	00 
   2ff28:	49 8b b6 98 08 00 00 	mov    0x898(%r14),%rsi
   2ff2f:	49 8b ae a0 08 00 00 	mov    0x8a0(%r14),%rbp
   2ff36:	48 89 b4 24 30 05 00 	mov    %rsi,0x530(%rsp)
   2ff3d:	00 
   2ff3e:	ff e1                	jmp    *%rcx
   2ff40:	49 8b 8e b8 04 00 00 	mov    0x4b8(%r14),%rcx
   2ff47:	49 8b 86 c8 04 00 00 	mov    0x4c8(%r14),%rax
   2ff4e:	48 85 c9             	test   %rcx,%rcx
   2ff51:	48 0f 45 c8          	cmovne %rax,%rcx
   2ff55:	48 85 c0             	test   %rax,%rax
   2ff58:	48 0f 44 c8          	cmove  %rax,%rcx
   2ff5c:	e9 b4 03 00 00       	jmp    30315 <oriole_expat::dispatch+0x545>
   2ff61:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2ff66:	48 8b 48 38          	mov    0x38(%rax),%rcx
   2ff6a:	e9 a6 03 00 00       	jmp    30315 <oriole_expat::dispatch+0x545>
   2ff6f:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2ff74:	48 8b 48 70          	mov    0x70(%rax),%rcx
   2ff78:	48 03 48 38          	add    0x38(%rax),%rcx
   2ff7c:	e9 94 03 00 00       	jmp    30315 <oriole_expat::dispatch+0x545>
   2ff81:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2ff86:	48 8b 40 28          	mov    0x28(%rax),%rax
   2ff8a:	48 8b 70 30          	mov    0x30(%rax),%rsi
   2ff8e:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   2ff92:	0f 84 07 02 00 00    	je     3019f <oriole_expat::dispatch+0x3cf>
   2ff98:	48 8b 48 68          	mov    0x68(%rax),%rcx
   2ff9c:	48 01 f1             	add    %rsi,%rcx
   2ff9f:	83 78 70 ff          	cmpl   $0xffffffff,0x70(%rax)
   2ffa3:	0f 85 05 02 00 00    	jne    301ae <oriole_expat::dispatch+0x3de>
   2ffa9:	e9 b9 02 00 00       	jmp    30267 <oriole_expat::dispatch+0x497>
   2ffae:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2ffb3:	48 8b 40 28          	mov    0x28(%rax),%rax
   2ffb7:	48 8b 48 68          	mov    0x68(%rax),%rcx
   2ffbb:	48 03 48 30          	add    0x30(%rax),%rcx
   2ffbf:	48 03 88 a0 00 00 00 	add    0xa0(%rax),%rcx
   2ffc6:	83 b8 a8 00 00 00 ff 	cmpl   $0xffffffff,0xa8(%rax)
   2ffcd:	0f 84 94 02 00 00    	je     30267 <oriole_expat::dispatch+0x497>
   2ffd3:	48 8b 80 d8 00 00 00 	mov    0xd8(%rax),%rax
   2ffda:	48 01 c1             	add    %rax,%rcx
   2ffdd:	e9 33 03 00 00       	jmp    30315 <oriole_expat::dispatch+0x545>
   2ffe2:	48 89 ac 24 d8 02 00 	mov    %rbp,0x2d8(%rsp)
   2ffe9:	00 
   2ffea:	4c 89 94 24 b8 01 00 	mov    %r10,0x1b8(%rsp)
   2fff1:	00 
   2fff2:	4c 89 bc 24 18 04 00 	mov    %r15,0x418(%rsp)
   2fff9:	00 
   2fffa:	4c 89 cd             	mov    %r9,%rbp
   2fffd:	4d 89 ef             	mov    %r13,%r15
   30000:	4d 89 c5             	mov    %r8,%r13
   30003:	4c 89 9c 24 10 04 00 	mov    %r11,0x410(%rsp)
   3000a:	00 
   3000b:	48 89 94 24 08 04 00 	mov    %rdx,0x408(%rsp)
   30012:	00 
   30013:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   30018:	48 8d 78 08          	lea    0x8(%rax),%rdi
   3001c:	b0 01                	mov    $0x1,%al
   3001e:	89 44 24 38          	mov    %eax,0x38(%rsp)
   30022:	b0 01                	mov    $0x1,%al
   30024:	89 44 24 24          	mov    %eax,0x24(%rsp)
   30028:	b0 01                	mov    $0x1,%al
   3002a:	89 44 24 50          	mov    %eax,0x50(%rsp)
   3002e:	b0 01                	mov    $0x1,%al
   30030:	89 44 24 40          	mov    %eax,0x40(%rsp)
   30034:	b0 01                	mov    $0x1,%al
   30036:	89 44 24 48          	mov    %eax,0x48(%rsp)
   3003a:	b0 01                	mov    $0x1,%al
   3003c:	89 44 24 20          	mov    %eax,0x20(%rsp)
   30040:	b0 01                	mov    $0x1,%al
   30042:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
   30046:	b0 01                	mov    $0x1,%al
   30048:	89 44 24 10          	mov    %eax,0x10(%rsp)
   3004c:	b0 01                	mov    $0x1,%al
   3004e:	89 44 24 0c          	mov    %eax,0xc(%rsp)
   30052:	b0 01                	mov    $0x1,%al
   30054:	89 44 24 34          	mov    %eax,0x34(%rsp)
   30058:	b0 01                	mov    $0x1,%al
   3005a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3005f:	b0 01                	mov    $0x1,%al
   30061:	89 44 24 18          	mov    %eax,0x18(%rsp)
   30065:	b0 01                	mov    $0x1,%al
   30067:	89 44 24 14          	mov    %eax,0x14(%rsp)
   3006b:	b0 01                	mov    $0x1,%al
   3006d:	89 44 24 28          	mov    %eax,0x28(%rsp)
   30071:	b0 01                	mov    $0x1,%al
   30073:	89 44 24 30          	mov    %eax,0x30(%rsp)
   30077:	b0 01                	mov    $0x1,%al
   30079:	89 44 24 2c          	mov    %eax,0x2c(%rsp)
   3007d:	ff 15 f5 f2 09 00    	call   *0x9f2f5(%rip)        # cf378 <_GLOBAL_OFFSET_TABLE_+0x220>
   30083:	48 89 d1             	mov    %rdx,%rcx
   30086:	48 8b 94 24 08 04 00 	mov    0x408(%rsp),%rdx
   3008d:	00 
   3008e:	4c 8b 9c 24 10 04 00 	mov    0x410(%rsp),%r11
   30095:	00 
   30096:	4d 89 e8             	mov    %r13,%r8
   30099:	4d 89 fd             	mov    %r15,%r13
   3009c:	49 89 e9             	mov    %rbp,%r9
   3009f:	4c 8b bc 24 18 04 00 	mov    0x418(%rsp),%r15
   300a6:	00 
   300a7:	4c 8b 94 24 b8 01 00 	mov    0x1b8(%rsp),%r10
   300ae:	00 
   300af:	e9 59 02 00 00       	jmp    3030d <oriole_expat::dispatch+0x53d>
   300b4:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   300b9:	83 78 38 ff          	cmpl   $0xffffffff,0x38(%rax)
   300bd:	0f 84 4f 01 00 00    	je     30212 <oriole_expat::dispatch+0x442>
   300c3:	48 8b 48 68          	mov    0x68(%rax),%rcx
   300c7:	48 03 48 30          	add    0x30(%rax),%rcx
   300cb:	e9 45 02 00 00       	jmp    30315 <oriole_expat::dispatch+0x545>
   300d0:	48 89 ac 24 d8 02 00 	mov    %rbp,0x2d8(%rsp)
   300d7:	00 
   300d8:	4c 89 44 24 50       	mov    %r8,0x50(%rsp)
   300dd:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   300e2:	48 8b 41 38          	mov    0x38(%rcx),%rax
   300e6:	4c 8b 41 70          	mov    0x70(%rcx),%r8
   300ea:	4c 89 cd             	mov    %r9,%rbp
   300ed:	4d 85 c0             	test   %r8,%r8
