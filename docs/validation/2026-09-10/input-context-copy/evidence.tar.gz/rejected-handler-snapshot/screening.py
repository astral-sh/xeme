import hashlib,json,random,statistics,subprocess
from pathlib import Path
root=Path('/tmp/oriole-handlers-snapshot')
repo=Path('/home/dev-user/code/oss/oriole')
manifest=repo/'benchmarks/projects/corpus-manifest.json'
fixtures={p['name']:(manifest.parent/next(f['path'] for f in p['files'] if f['role']=='input')).resolve() for p in json.loads(manifest.read_text())['projects']}
rare=root/'rare-declarations.xml'
rare.write_text('<!DOCTYPE r [\n'+''.join(f'<!ENTITY e{i} "v"><!ATTLIST r a{i} CDATA #IMPLIED><!NOTATION n{i} SYSTEM "x">\n' for i in range(2000))+']><r/>')
fixtures['generated-rare-declarations']=rare
fixtures['generated-entities']=Path('/tmp/oriole-grammar-bench-plain/entities.xml')
libraries={'control':root/'control.so','candidate':root/'liboriole_expat.so'}
driver=Path('/tmp/oriole-grammar-bench-plain/native-driver')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'scope':'Screening candidate/control on all six pinned projects and two generated adverse fixtures; CPU0, shared host. Five randomized pairs, seven measured parses plus warmup per subprocess. This is native callback-driver throughput, not actual project process timing.','pairs':5,'iterations':7,'rows':[],'hashes_before':{str(p):sha(p) for p in [manifest,driver,*fixtures.values(),*libraries.values()]}}
rng=random.Random(20260910)
for chunk in [4096,65536]:
 for name,fixture in fixtures.items():
  ratios=[]
  for pair in range(report['pairs']):
   order=list(libraries);rng.shuffle(order)
   row={'workload':name,'chunk':chunk,'namespaces':False,'pair':pair,'order':order,'processes':{}}
   for label in order:
    command=['taskset','-c','0',str(driver),str(libraries[label]),str(fixture),str(chunk),str(report['iterations'])]
    result=subprocess.run(command,capture_output=True,text=True,timeout=45)
    process={'command':command,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr};row['processes'][label]=process
    assert result.returncode==0,process
    samples=json.loads(result.stdout)['samples']
    process['median_seconds']=statistics.median(s['seconds'] for s in samples if not s['warmup'])
    process['observations']=list({(s['hash'],s['elements'],s['text_bytes']) for s in samples})
   assert row['processes']['control']['observations']==row['processes']['candidate']['observations'],row
   row['speedup']=row['processes']['control']['median_seconds']/row['processes']['candidate']['median_seconds'];ratios.append(row['speedup']);report['rows'].append(row)
   (root/'screening.json').write_text(json.dumps(report,indent=2)+'\n')
  print(chunk,name,statistics.median(ratios),min(ratios),max(ratios),flush=True)
report['hashes_after']={p:sha(Path(p)) for p in report['hashes_before']}
assert report['hashes_before']==report['hashes_after']
report['status']='passed'
(root/'screening.json').write_text(json.dumps(report,indent=2)+'\n')
