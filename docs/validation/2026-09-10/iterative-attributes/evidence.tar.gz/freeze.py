from pathlib import Path
import hashlib,json,shutil,subprocess
repo=Path('/home/dev-user/code/oss/oriole-api-followup');out=Path('/tmp/oriole-iterative-final');target=Path('/home/dev-user/.cache/oriole/api-followup-target/release')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['liboriole_expat.so','liboriole_expat.a']:shutil.copy2(target/name,out/name)
paths=sorted(p for p in (repo/'crates').rglob('*.rs'))
(out/'source.json').write_text(json.dumps({str(p.relative_to(repo)):sha(p) for p in paths},indent=2)+'\n')
(out/'libraries.json').write_text(json.dumps({name:sha(out/name) for name in ['liboriole_expat.so','liboriole_expat.a']},indent=2)+'\n')
patch=subprocess.run(['git','diff','HEAD','--','crates'],cwd=repo,capture_output=True,check=True).stdout
patch+=subprocess.run(['git','diff','--no-index','/dev/null','crates/oriole/tests/attribute_entities.rs'],cwd=repo,capture_output=True).stdout
(out/'source.patch').write_bytes(patch)
print((out/'libraries.json').read_text())
