# Iterative attribute entity expansion

Apply `candidate.patch` after the three prerequisite patches in `source.json` (name edition, direct missing PE, shared parameter state), all based on root33154ff. No shared root source was edited. `apply-check.log` verifies the exact frozen previous snapshot.

Patch SHA-256: `25d1a6b46c175baf6fdfdab63c8b2d54ce2f03b4648794c209df8756ad5a5425`.
Frozen debug library SHA-256: `bba4e2939f5b864c1d00a5645d7b320970a5970bf5be1063ece1b4237e0634fc`.

## Implementation

`expand_attribute` borrows the parser immutably for one synchronous expansion. A selected-allocator vector stores borrowed parent remainders and active names. A selected-allocator hash set uses the entity table's current salted random state; external context names are seeded once on the first general reference. Local names are removed when their frames finish. No parser/map mutation or host callback occurs while these borrows live.

All output appends into one String. Entity values, entity names, and intermediate expanded strings are no longer cloned per recursive level. Whitespace normalization appends directly instead of allocating a temporary string for each literal span. Work is proportional to consumed replacement/reference bytes and produced output, with expected constant-time active membership and amortized stack/output growth. Memory is proportional to active depth plus output; successful references still charge the existing logical replacement byte budget before pushing.

Existing validation order is unchanged: lexical name, cycle, configured local depth, declaration existence, standalone declaration origin, external value, absolute expansion charge. Indirect literal/reference byte accounting stays at the same boundaries; predefined one-byte accounting retains its non-enforcing call. OOM is fallible and propagated to the parser's existing terminal-error path. No configured limits or C settings change.

## Validation

-259 affected Rust checks pass, including exhaustive selected-suite OOM, no-global-allocation and C allocator-reentry checks. Five new attribute tests pass on the final source; strict Clippy and formatting checks pass.
-A60,000-level chain runs on a256KiB thread stack, with a growing prefix at every level and subsequent reuse of a completed entity. Only this test's entity count/depth are raised; ordinary limits remain unchanged. A wide diamond stops at the existing4KiB configured work cap and expands correctly under ordinary limits.
-96 selected upstream API configurations pass, with library-origin verification.
-5,796 oracle conditions compare UTF-8/UTF-16, whole/1/7-byte chunks, namespaces, explicit/default/tokenized attributes, external declarations, cycles, generated DAGs, and seven relative-amplification settings. Candidate exactly matches the prior frozen library in status, errors, positions, callbacks and child outcomes. All acceptance outcomes also match pinned Expat.
-The oracle exposes two pre-existing issues, preserved here for a separate semantic fix:252 error-code differences for NDATA attribute references (Oriole16 vs Expat15), and732 accepted callback differences due to folding replacement CR+LF from adjacent numeric references into one space. `oracle.json` retains all evidence. Reference-only position differences are counted separately; no assertions were waived.
-No full API matrix, release throughput campaign or sanitizer campaign was run on this isolated candidate. CPU0 remained reserved for root.

## Integration with current root

1. Root's recycled attribute path should continue reusing the caller's output String. Translate this single-output loop into current `append_attribute`/`expand_attribute_into`, preserving clear/refill behavior; do not reintroduce nested owned output strings.
2. Preserve custom encoding lexical `Slice`/raw-name validation before restored names are looked up. Borrow stable map keys (`get_key_value`) for the active set/frame if a decoded lookup name is a temporary owned string. Raw source slices and replacement slices need their existing provenance; a parent frame must carry the lexical slice, not merely decoded UTF-8, when returning to direct encoded input.
3. Preserve any sticky `Entity.value_open` checks and their existing precedence. This old base has no such field; it changes only general attribute expansion and does not edit parameter lifecycle handling.
4. Retain current boxed EventKind variants in unrelated code. The new tests use only unchanged StartElement/Text shapes.
5. The semantic follow-up must distinguish physical CRLF from replacement numeric/alias CRLF. Keep the existing `cursor.last_literal_normalize == Some(false)` default prepass and custom `raw_ascii` handling. Neither bug was fixed in API author's current provenance code.

See `resource-profile.md` for a proposal only; profile implementation and default widening are outside this patch.
