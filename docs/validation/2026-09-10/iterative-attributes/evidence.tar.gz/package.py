from pathlib import Path
import gzip,hashlib,io,json,tarfile,re,subprocess
source=Path('/tmp/oriole-iterative-final');repo=Path('/home/dev-user/code/oss/oriole-api-followup');out=repo/'docs/validation/2026-09-10/iterative-attributes';out.mkdir(parents=True,exist_ok=True);original=Path('/tmp/oriole-iterative-attributes');baseline=Path('/tmp/oriole-shared-final/upstream-complete');sha=lambda b:hashlib.sha256(b).hexdigest();entries={}
for p in sorted(source.rglob('*')):
 if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log','.py','.patch','.c','.h']:entries[str(p.relative_to(source))]=p.read_bytes()
for name in ['HANDOFF.md','candidate.patch','source.json','validation.json','oracle.py','oracle.json']:entries['original-candidate/'+name]=(original/name).read_bytes()
for name in ['results.json','manifest.json','tests.log']:entries['baseline-upstream/'+name]=(baseline/name).read_bytes()
entries['independent-review.json']=Path('/tmp/oriole-iterative-composition-independent-review.json').read_bytes()
freeze=json.loads((source/'source.json').read_text())
for name,digest in freeze.items():
 data=(repo/name).read_bytes();assert sha(data)==digest;entries['frozen-source/'+name]=data
review=json.loads(entries['independent-review.json']);print(review.keys())
files=[{'path':p,'bytes':len(v),'sha256':sha(v)} for p,v in sorted(entries.items())];(out/'files.json').write_text(json.dumps(files,indent=2)+'\n')
with (out/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
a=json.loads((baseline/'results.json').read_text());b=json.loads((source/'upstream-complete/results.json').read_text());am=json.loads((baseline/'manifest.json').read_text());bm=json.loads((source/'upstream-complete/manifest.json').read_text());assert a['results']==b['results'] and am['adapted_sources']==bm['adapted_sources']
o=json.loads((source/'oracle.json').read_text());assert o['counts']['baseline_changes']==o['counts']['reference_acceptance']==0
alias=json.loads((source/'alias.json').read_text());oldalias=json.loads((source/'alias-baseline.json').read_text());assert alias['rows']==oldalias['rows']
native=json.loads((source/'native/report.json').read_text());assert native['status']=='passed'
ordinary=json.loads((source/'differential/summary.json').read_text());assert ordinary['exact_pass'] and ordinary['cases']==3918
checks=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(source/'tests.log').read_text())));assert checks==288
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'base_commit':'daeb7f9','shared_sha256':sha((source/'liboriole_expat.so').read_bytes()),'static_sha256':sha((source/'liboriole_expat.a').read_bytes()),'checks':{'rust_tests':checks,'final_allocation_tests':5,'strict_clippy':'passed','native_suites':6,'allocation_scenarios_per_linkage':333,'native_scope':native['scope'],'ordinary_exact_differential_cases':3918},'upstream':{'before':{'passed':a['passed'],'failed':a['failed']},'after':{'passed':b['passed'],'failed':b['failed']},'changes':[],'identical_adapted_sources':True},'attribute_oracle':o['counts'],'attribute_oracle_disposition':'All 5796 results are identical to the shared-state baseline, including positions. All 252 reference error differences are existing NDATA error16 versus15, and all 732 event differences are existing replacement CRLF folding.','alias_oracle':{'conditions':132,'baseline_changes':0,'reference_differences':30,'disposition':'Existing CDATA replacement CRLF folding; the other 102 cases match Expat.'},'independent_review':review,'limits':'No limit changes. The 60,000-level growing-prefix test opts into increased entity count/depth on a 256 KiB thread stack. The wide diamond still stops at its configured 4,096-byte expansion cap. Selected-allocator fail-point coverage includes explicit stack/active-set growth.','separate_work':'Attribute replacement whitespace and NDATA diagnostics remain a separate semantic layer. No production speed claim is made from these correctness tests.','artifacts':{'files':len(files),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes())}}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README.md').write_text('''# Iterative attribute expansion\n\nThe parser expands attribute entities with an explicit borrowed frame stack and a salted active-name set. Parent lexical slices preserve custom-encoding provenance, and recycled output stays owned until expansion succeeds. Entity count, depth, expansion budgets, and amplification accounting are unchanged.\n\nValidation: 288 Rust checks, the expanded allocation fail-point workload, strict Clippy, six native C ASan/UBSan suites, and 3,918 exact ordinary differential cases pass. All 4,740 upstream API outcomes remain 4,065 passed/675 failed. All 5,796 attribute oracle cases are identical to the preceding implementation. The 60,000-level small-stack test raises limits locally; default limits remain in place.\n\nThe oracle retains 252 existing NDATA error differences, 732 existing replacement-CRLF callback differences, and 2,460 position differences. The 132 custom-conversion conditions retain 30 existing replacement-CRLF differences. These are corrected or classified in separate layers, not waived here.\n\n`report.json` records exact scope, hashes, and the independent source review. `files.json` inventories every file in `evidence.tar.gz`. Native C sanitizers do not instrument the release Rust library; leak sanitizer was disabled.\n''')
with tarfile.open(out/'evidence.tar.gz') as tar:
 assert set(tar.getnames())=={r['path'] for r in files}
 for r in files:assert sha(tar.extractfile(r['path']).read())==r['sha256']
(out/'SHA256SUMS').write_text(''.join(sha((out/name).read_bytes())+'  '+name+'\n' for name in ['README.md','report.json','files.json','evidence.tar.gz']))
print(len(files),'verified files',len((out/'evidence.tar.gz').read_bytes()),'archive bytes')
