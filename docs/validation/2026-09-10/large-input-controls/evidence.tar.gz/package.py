from pathlib import Path
import hashlib
import json
import shutil

root = Path('/tmp/oriole-large-input-followup')
out = Path('/tmp/oriole-large-input-followup-handoff')
out.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
prefix = json.loads((root / 'prefix-results.json').read_text())
assert len(prefix['rows']) == 40
for row in prefix['rows']:
    assert row['exit_code'] == 0 and not row['stderr']
    o = row['observation']
    assert o['selected_final_bytes'] == 0 and o['selected_final_blocks'] == 0
for name, entry in prefix['libraries'].items():
    assert sha(Path(entry['path'])) == entry['sha256']
stream = json.loads((root / 'reference-stream/results.json').read_text())
buffer_root = Path('/tmp/oriole-deep-profile-experiment')
buffer = json.loads((buffer_root / 'reference-buffer/results.json').read_text())
assert stream['passed'] == 10 and stream['failed'] == 2
assert sum(r['outcome'] == 'timeout' for r in stream['results']) == 2
assert buffer['passed'] == 0 and buffer['failed'] == 12
assert all(r['outcome'] == 'fail' for r in buffer['results'])
summary = {
    'scope': 'Read-only diagnosis and bounded native prefix profiling. No runtime, cap, original fixture, retry ceiling, or timeout changes.',
    'libraries': prefix['libraries'],
    'candidate_source_manifest_sha256': sha(Path('/tmp/oriole-c-entity-defaults/source.json')),
    'bounds': prefix['bounds'],
    'original_stream': {
        'test': 'test_misc_input_2gb', 'active_configurations': 2,
        'total_bytes': 2147483675, 'prefix_bytes': 27, 'space_blocks': 524288, 'block_bytes': 4096,
        'same_bound_reference': {'active_timeouts': 2, 'early_return_passes': 10},
        'candidate': 'Both active original configurations reject at the unchanged 256 MiB family input cap.',
        'classification': 'Candidate policy difference plus same-bound reference timeout. These rows do not establish a reference pass within the current 3-second per-case bound.',
        'note': 'The results timed_out=false field describes the outer controller, not the two per-test timeout outcomes.'
    },
    'original_buffer': {
        'test': 'test_buffer_can_grow_to_max', 'configurations': 12,
        'first_requested_bytes': 1073741824,
        'same_bound_reference_failures': 12,
        'classification': 'The first 1 GiB allocation cannot fit inside a 1 GiB process address-space bound with runtime overhead. Oriole also has independent unchanged 256 MiB input reservation and 512 MiB live-allocation caps.',
        'note': 'Disabling Expat relative allocation tracking in the fixture does not disable Oriole absolute limits. Older wider-AS reference observations are separate.'
    },
    'prefix_profile': {
        'native_runs': 40, 'all_processes_exit_zero': True, 'all_selected_live_zero': True,
        'sizes_blocks': [256, 16384, 32768, 65535, 65536],
        'deferral_modes': [0, 1], 'allocator_modes': ['plain', 'selected suite'],
        'reference_selected_calls': 10, 'reference_selected_peak_bytes': 15984,
        'candidate_selected_calls': 29, 'candidate_selected_peak_bytes': 90198,
        'accepted_boundary_bytes': 268431387, 'next_attempt_bytes': 268435483,
        'candidate_boundary_error': 43,
        'classification': 'Retained selected storage and allocation counts remain fixed over all prefix sizes. No growing or quadratic buffer allocation was observed. Source processing consists of repeated linear byte scans and fixed-size copies.'
    },
    'safe_optimization_proposal': {
        'status': 'Source-only proposal, not implemented or claimed to pass a formerly failing test.',
        'narrow': 'In parse_text, compute source.position(end) only when a Text/Default event needs it. Ignored prolog/epilog whitespace currently computes the unused position and then consume advances it again.',
        'validation_needed': 'Paired bounded prefix timing, raw/namespace and Default handler toggles, UTF8/UTF16, CR/LF positions, malformed prefixes, and unchanged source/work/input caps.',
        'does_not_fix': 'Skipping a redundant scan does not bypass the 256 MiB cap or prove the original 2 GiB fixture completes under 3 seconds.'
    },
    'allocation_schedule_followup': {
        'report': 'independent-allocation-schedule-review.json',
        'highest_impact': 'Stream ordinary ATTLIST semantic commits and raw default segments, keeping only the current owned callback instead of declaration-sized event queues.',
        'smaller': 'Store compact default-attribute semantic kind while preserving callback type text and logical copying charges.',
        'fixture_caution': 'test_alloc_realloc_buffer also asserts at least one reallocation and a maximum retry count. Fewer allocations can violate its incidental schedule assertion even when parsing succeeds; do not emulate that schedule.'
    },
    'limitations': [
        'One timing per configuration on a shared host; timings are descriptive, with visible noise. No statistical speedup or twoGiB time extrapolation is claimed.',
        'Selected counts measure allocator-suite requested bytes and calls, not every host/runtime allocation. Zero fields in plain mode mean unmeasured.',
        'Process RSS is affected by the launcher high-water mark and is not an exact parser-only retained-memory measurement.',
        'RLIMIT_RSS is requested; enforcement depends on the operating system. RLIMIT_AS and per-case alarms remain the actual same-bound controls.',
        'The current full API matrix remains unchanged by this report. Reference-only diagnostic failures do not alter original candidate counts.'
    ]
}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for name in ['package.py', 'prefix.c', 'prefix.py', 'prefix-results.json', 'reference-prefix-build.log', 'oriole-prefix-build.log', 'reference_stream.py', 'reference-stream-command.json', 'reference-stream.log', 'independent-allocation-schedule-review.json']:
    shutil.copy2(root / name, out / name)
for relative, base in [('reference-stream', root), ('reference-buffer', buffer_root)]:
    destination = out / relative
    destination.mkdir()
    for name in ['manifest.json', 'results.json', 'tests.log']:
        shutil.copy2(base / relative / name, destination / name)
for name in ['reference-buffer-command.json', 'reference-buffer.log', 'reference_buffer.py']:
    shutil.copy2(buffer_root / name, out / name)
for name in ['test_misc_input_2gb.c', 'test_buffer_can_grow_to_max.c']:
    shutil.copy2(Path('/tmp/oriole-resource-profile-review') / name, out / name)
shutil.copy2('/tmp/oriole-c-entity-defaults/source.json', out / 'candidate-source.json')
manifest = {str(p.relative_to(out)): sha(p) for p in sorted(out.rglob('*')) if p.is_file()}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'path': str(out), 'artifacts': len(manifest), 'manifest_sha256': sha(out / 'manifest.json'), 'summary_sha256': sha(out / 'summary.json')}, indent=2))
