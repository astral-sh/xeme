/* Supplemental exact-fixture measurements, distinct from the original API tests.
 * Suite accounting counts bytes requested from the selected allocator, including
 * Oriole's own tracking headers but excluding this harness's aligned header.
 * All pointers remain within one single-threaded parser family. */
#include "expat.h"
#include <assert.h>
#include <inttypes.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <time.h>

typedef union Header { max_align_t alignment; size_t size; } Header;
static size_t live_bytes, peak_bytes, live_blocks, calls, fail_at;
static int allocation_fails(void) { ++calls; return fail_at && calls >= fail_at; }
static void *suite_malloc(size_t size) {
  if (allocation_fails() || size > SIZE_MAX - sizeof(Header)) return NULL;
  Header *header = malloc(sizeof(Header) + size);
  if (!header) return NULL;
  header->size = size; live_bytes += size; ++live_blocks;
  if (live_bytes > peak_bytes) peak_bytes = live_bytes;
  return header + 1;
}
static void suite_free(void *pointer) {
  if (!pointer) return;
  Header *header = (Header *)pointer - 1;
  assert(live_blocks && live_bytes >= header->size);
  live_bytes -= header->size; --live_blocks; free(header);
}
static void *suite_realloc(void *pointer, size_t size) {
  if (!pointer) return suite_malloc(size);
  if (allocation_fails() || size > SIZE_MAX - sizeof(Header)) return NULL;
  Header *old = (Header *)pointer - 1;
  size_t old_size = old->size;
  Header *header = realloc(old, sizeof(Header) + size);
  if (!header) return NULL;
  header->size = size; live_bytes = live_bytes - old_size + size;
  if (live_bytes > peak_bytes) peak_bytes = live_bytes;
  return header + 1;
}

static double now(void) { struct timespec t; assert(clock_gettime(CLOCK_MONOTONIC, &t) == 0); return (double)t.tv_sec + (double)t.tv_nsec / 1e9; }
int main(int argc, char **argv) {
  if (argc != 4) return 2;
  size_t blocks = strtoull(argv[1], NULL, 10);
  int deferral = atoi(argv[2]), selected = atoi(argv[3]);
  if (blocks > 524288 || deferral < 0 || deferral > 1 || selected < 0 || selected > 1) return 2;
  XML_Memory_Handling_Suite suite = {suite_malloc, suite_realloc, suite_free};
  XML_Parser parser = selected ? XML_ParserCreate_MM(NULL, &suite, NULL) : XML_ParserCreate(NULL);
  if (!parser) return 2;
  assert(XML_SetReparseDeferralEnabled(parser, (XML_Bool)deferral));
  char buffer[4096]; memset(buffer, ' ', sizeof(buffer));
  const char *prefix = "<?xml version='1.0'?><doc/>";
  size_t accepted = 0, attempted = 0, completed_blocks = 0;
  double begin = now();
  int status = XML_Parse(parser, prefix, (int)strlen(prefix), XML_FALSE);
  attempted += strlen(prefix); if (status == XML_STATUS_OK) accepted = attempted;
  while (status == XML_STATUS_OK && completed_blocks < blocks) {
    attempted += sizeof(buffer);
    status = XML_Parse(parser, buffer, sizeof(buffer), XML_FALSE);
    if (status == XML_STATUS_OK) { accepted += sizeof(buffer); ++completed_blocks; }
  }
  if (status == XML_STATUS_OK) status = XML_Parse(parser, NULL, 0, XML_TRUE);
  double end = now();
  int error = XML_GetErrorCode(parser); XML_Index index = XML_GetCurrentByteIndex(parser);
  XML_ParserFree(parser); struct rusage usage; assert(getrusage(RUSAGE_SELF, &usage) == 0);
  printf("{\"blocks\":%zu,\"deferral\":%d,\"selected\":%d,\"accepted_bytes\":%zu,\"attempted_bytes\":%zu,\"completed_blocks\":%zu,\"status\":%d,\"error\":%d,\"byte_index\":%ld,\"parse_seconds\":%.9f,\"selected_calls\":%zu,\"selected_peak_bytes\":%zu,\"selected_final_bytes\":%zu,\"selected_final_blocks\":%zu,\"max_rss_kib\":%ld}\n", blocks, deferral, selected, accepted, attempted, completed_blocks, status, error, (long)index, end-begin, calls, peak_bytes, live_bytes, live_blocks, usage.ru_maxrss);
  return live_bytes || live_blocks;
}
