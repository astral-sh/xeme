from pathlib import Path
import hashlib,json,resource,subprocess,time
w=Path('/tmp/oriole-large-input-followup');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();libs={'reference':Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so'),'oriole':Path('/tmp/oriole-c-entity-defaults/liboriole_expat.so')};header=Path('/tmp/oriole-c-entity-defaults/frozen-source/include');report={'scope':'Bounded prefixes of original2GiB whitespace fixture; no runtime/cap changes. Selected allocator and plain runs recorded separately.','libraries':{k:{'path':str(p),'sha256':sha(p)} for k,p in libs.items()},'source_sha256':sha(w/'prefix.c'),'bounds':{'wall_seconds':3,'address_bytes':1<<30,'rss_bytes_requested':768<<20},'builds':[],'rows':[]}
def limits():
 resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30));resource.setrlimit(resource.RLIMIT_RSS,(768<<20,768<<20))
try:
 for label,library in libs.items():
  command=['clang','-std=c11','-D_POSIX_C_SOURCE=200809L','-Wall','-Wextra','-Werror','-O2','-I',str(header),str(w/'prefix.c'),str(library),'-Wl,-rpath,'+str(library.parent),'-o',str(w/label)]
  with (w/(label+'-prefix-build.log')).open('w') as f:r=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,timeout=60)
  report['builds'].append({'command':command,'exit_code':r.returncode});assert r.returncode==0;report['builds'][-1]['binary_sha256']=sha(w/label)
 for label in libs:
  for blocks in [256,16384,32768,65535,65536]:
   for deferral in [0,1]:
    for selected in [0,1]:
     command=['taskset','-c','3',str(w/label),str(blocks),str(deferral),str(selected)];start=time.monotonic();r=subprocess.run(command,capture_output=True,text=True,timeout=3,preexec_fn=limits)
     row={'library':label,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start,'stderr':r.stderr,'observation':json.loads(r.stdout)};report['rows'].append(row);assert r.returncode==0 and not r.stderr,row
     (w/'prefix-results.json').write_text(json.dumps(report,indent=2)+'\n')
 report['library_hashes_after']={k:sha(p) for k,p in libs.items()};assert all(report['libraries'][k]['sha256']==h for k,h in report['library_hashes_after'].items())
 report['status']='completed'
finally:(w/'prefix-results.json').write_text(json.dumps(report,indent=2)+'\n')
print('completed',len(report['rows']),flush=True)
