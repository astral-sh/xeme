from pathlib import Path
import os, subprocess, json, hashlib
p=Path('/tmp/oriole-doctype-default/crates/oriole/tests/allocation.rs'); old=p.read_text(); patched=old.replace('let allocation_count = CALLS.get();','let allocation_count = CALLS.get();\n    eprintln!("measured_allocation_count={allocation_count}");',1)
out=Path('/tmp/oriole-constructor-review')
env=dict(os.environ,CARGO_HOME='/home/dev-user/.cache/toucan/cargo',CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/build',CARGO_TARGET_DIR='/home/dev-user/.cache/oriole/doctype-default-target',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0')
command=['taskset','-c','5','cargo','+ohm','test','-p','oriole','--test','allocation','shared_open_value_state_survives_every_allocation_failure_and_parent_drop','--','--nocapture']
try:
 p.write_text(patched)
 result=subprocess.run(command,cwd='/tmp/oriole-doctype-default',env=env,capture_output=True,text=True)
 (out/'measured-allocation-count.log').write_text(result.stdout+result.stderr)
 (out/'measured-allocation-count.json').write_text(json.dumps({'scope':'Test-only eprintln instrumentation; runtime unchanged; all measured failure-index/OOM/lifetime/routing assertions unchanged. Original file restored in finally.','command':command,'returncode':result.returncode,'original_test_sha256':hashlib.sha256(old.encode()).hexdigest(),'instrumented_test_sha256':hashlib.sha256(patched.encode()).hexdigest()},indent=2)+'\n')
finally:p.write_text(old)
