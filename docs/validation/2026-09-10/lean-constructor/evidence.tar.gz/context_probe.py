import ctypes as c,json,hashlib,itertools
from pathlib import Path
P=c.c_void_p;S=c.c_char_p;I=c.c_int
START=c.CFUNCTYPE(None,P,S,c.POINTER(S));END=c.CFUNCTYPE(None,P,S);TEXT=c.CFUNCTYPE(None,P,P,I);EXT=c.CFUNCTYPE(I,P,S,S,S,S)
class Engine:
 def __init__(self,path):
  self.path=path;self.lib=c.CDLL(path)
  for n,args,r in [('XML_ParserCreate',[S],P),('XML_ParserCreateNS',[S,c.c_char],P),('XML_ExternalEntityParserCreate',[P,S,S],P),('XML_SetExternalEntityRefHandler',[P,EXT],None),('XML_SetElementHandler',[P,START,END],None),('XML_SetCharacterDataHandler',[P,TEXT],None),('XML_SetParamEntityParsing',[P,I],I),('XML_SetReturnNSTriplet',[P,I],None),('XML_SetReparseDeferralEnabled',[P,I],I),('XML_SetHashSalt',[P,c.c_ulong],I),('XML_Parse',[P,S,I,I],I),('XML_GetErrorCode',[P],I),('XML_ParserFree',[P],None)]:f=getattr(self.lib,n);f.argtypes=args;f.restype=r
 def parse(self,document,resources,namespace,triplets,width,salt,context_marker=False):
  l=self.lib;events=[];p=l.XML_ParserCreateNS(None,b'|') if namespace else l.XML_ParserCreate(None);l.XML_SetReparseDeferralEnabled(p,0)
  @START
  def start(_,name,attrs):
   values=[];i=0
   while attrs[i]:values.append(attrs[i].decode());i+=1
   events.append(['start',name.decode(),values])
  @END
  def end(_,name):events.append(['end',name.decode()])
  @TEXT
  def text(_,ptr,n):
   value=c.string_at(ptr,n).decode()
   if events and events[-1][0]=='text':events[-1][1]+=value
   else:events.append(['text',value])
  def feed(parser,data):
   step=width or max(1,len(data));status=1
   if not data:return l.XML_Parse(parser,b'',0,1)
   for off in range(0,len(data),step):
    part=data[off:off+step];status=l.XML_Parse(parser,part,len(part),int(off+step>=len(data)))
    if status!=1:break
   return status
  @EXT
  def external(parent,ctx,base,system,public):
   events.append(['external',ctx.decode() if ctx is not None else None,system.decode() if system else None]);child=l.XML_ExternalEntityParserCreate(parent,ctx,None)
   if not child:events.append(['child-create-failed']);return 0
   data=resources.get(system.decode() if system else None,b'');status=feed(child,data)
   if status!=1:events.append(['child-error',l.XML_GetErrorCode(child)])
   l.XML_ParserFree(child);return status
  l.XML_SetElementHandler(p,start,end);l.XML_SetCharacterDataHandler(p,text);l.XML_SetExternalEntityRefHandler(p,external);l.XML_SetParamEntityParsing(p,2);l.XML_SetReturnNSTriplet(p,triplets)
  if salt:assert l.XML_SetHashSalt(p,12345)==1
  target=p
  if context_marker is not False:
   target=l.XML_ExternalEntityParserCreate(p,context_marker,None)
  status=feed(target,document);error=l.XML_GetErrorCode(target)
  if target!=p:l.XML_ParserFree(target)
  l.XML_ParserFree(p);return {'status':status,'error':error,'events':events}

def normalized(result):
 result=json.loads(json.dumps(result))
 for e in result['events']:
  if e[0]=='external' and e[1] is not None:e[1]='\f'.join(sorted(e[1].split('\f')))
 return result

def main():
 p=Path('/tmp/oriole-constructor-review');engines=[Engine('/home/dev-user/.cache/oriole/expat-build/libexpat.so'),Engine('/tmp/oriole-constructor-review/baseline.so'),Engine('/tmp/oriole-constructor-review/candidate.so')]
 fixtures=[('bare',b'<xml:r xmlns:xml="http://www.w3.org/XML/1998/namespace" xml:lang="en"/>',{},False),('declared',b'<!DOCTYPE r [<!ENTITY e SYSTEM "e"><!ENTITY f SYSTEM "f">]><r xmlns:x="u" xml:lang="en" x:a="v">&e;</r>',{'e':b'<xml:node xmlns:x="v" x:a="w">&f;</xml:node>','f':b'content'},False),('external-dtd',b'<!DOCTYPE r SYSTEM "dtd"><r>&e;</r>',{'dtd':b'<!ENTITY e SYSTEM "e">','e':b'<xml:node xml:lang="en"/>'},False),('manual-empty',b'<xml:node xml:lang="en"/>',{},b''),('manual-binding',b'<xml:node xmlns:x="u" x:a="v"/>',{},b'xml=http://www.w3.org/XML/1998/namespace\fe'),('manual-shadow',b'<xml:node/>',{},b'xml=urn:shadow\fe')]
 rows=[]
 for (name,doc,res,context),ns,triplet,width,salt in itertools.product(fixtures,[False,True],[False,True],[0,1,7],[False,True]):
  a,b,d=[e.parse(doc,res,ns,triplet,width,salt,context) for e in engines];rows.append({'case':name,'namespaces':ns,'triplets':triplet,'width':width,'salt':salt,'reference':a,'baseline':b,'candidate':d})
 report={'regressions_vs_baseline':sum(normalized(r['candidate']) != normalized(r['baseline']) for r in rows),'cases':len(rows),'differences':sum(r['reference']!=r['candidate'] for r in rows),'nonnamespace_cases':sum(not r['namespaces'] for r in rows),'nonnamespace_differences':sum(not r['namespaces'] and r['reference']!=r['candidate'] for r in rows),'libraries':{str(e.path):hashlib.sha256(Path(e.path).read_bytes()).hexdigest() for e in engines},'observations':rows};(p/'contexts.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k!='observations'})
if __name__=='__main__':main()
