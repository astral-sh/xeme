import ctypes as c,json,re,ast,hashlib
from pathlib import Path
P=c.c_void_p;I=c.c_int;S=c.c_char_p;Z=c.c_size_t
M=c.CFUNCTYPE(P,Z);R=c.CFUNCTYPE(P,P,Z);F=c.CFUNCTYPE(None,P)
class Suite(c.Structure):_fields_=[('malloc',M),('realloc',R),('free',F)]
U=c.CFUNCTYPE(I,P,S,P);RELEASE=c.CFUNCTYPE(None,P)
class Encoding(c.Structure):_fields_=[('map',I*256),('data',P),('convert',P),('release',RELEASE)]
EXT=c.CFUNCTYPE(I,P,S,S,S,S);START=c.CFUNCTYPE(None,P,S,P);END=c.CFUNCTYPE(None,P,S)
libc=c.CDLL(None);libc.malloc.argtypes=[Z];libc.malloc.restype=P;libc.realloc.argtypes=[P,Z];libc.realloc.restype=P;libc.free.argtypes=[P]
def text_for(test):
 for file in ['alloc_tests.c','nsalloc_tests.c']:
  source=(Path('/tmp/oriole-missing-final/upstream-complete/adapted')/file).read_text();m=re.search(r'START_TEST\('+test+r'\).*?\nEND_TEST',source,re.S)
  if not m:continue
  body=re.sub(r'/\*.*?\*/','',m.group(),flags=re.S);expression=re.search(r'const char \*text\s*=\s*((?:"(?:\\.|[^"\\])*"\s*)+);',body,re.S)
  return b''.join(ast.literal_eval('b'+s) for s in re.findall(r'"(?:\\.|[^"\\])*"',expression.group(1)))
 raise ValueError(test)
class Engine:
 def __init__(self,path):
  self.path=path;self.lib=c.CDLL(path)
  for name,args,result in [('XML_ParserCreate_MM',[S,c.POINTER(Suite),S],P),('XML_Parse',[P,S,I,I],I),('XML_ParserFree',[P],None),('XML_GetErrorCode',[P],I),('XML_SetUnknownEncodingHandler',[P,U,P],None),('XML_SetParamEntityParsing',[P,I],I),('XML_SetExternalEntityRefHandler',[P,EXT],None),('XML_ExternalEntityParserCreate',[P,S,S],P),('XML_SetReturnNSTriplet',[P,I],None),('XML_SetElementHandler',[P,START,END],None),('XML_SetReparseDeferralEnabled',[P,I],I)]:
   f=getattr(self.lib,name);f.argtypes=args;f.restype=result
 def run(self,document=None,encoding=None,chunk=0,namespaces=False,unknown=False,resources=None,fail_kind=None,fail_at=None,child=False,constructor_failure=False):
  l=self.lib;live={};calls=[];phase='measured' if constructor_failure else 'constructor';counts={'malloc':0,'realloc':0};release_calls=unknown_calls=0;events=[]
  def reject(kind,size):
   index=counts[kind];counts[kind]+=1;failed=phase=='measured' and fail_kind==kind and index>=fail_at if fail_kind else False
   calls.append({'phase':phase,'kind':kind,'size':size,'failed':failed});return failed
  @M
  def malloc(size):
   if reject('malloc',size):return None
   p=libc.malloc(size)
   if p:live[p]=size
   return p
  @R
  def realloc(ptr,size):
   if reject('realloc',size):return None
   p=libc.realloc(ptr,size)
   if p:
    if ptr:del live[ptr]
    live[p]=size
   return p
  @F
  def free(ptr):
   if ptr:del live[ptr];libc.free(ptr)
  @RELEASE
  def release(_):
   nonlocal release_calls
   release_calls+=1
  @U
  def codec(_,name,raw):
   nonlocal unknown_calls
   unknown_calls+=1;info=c.cast(raw,c.POINTER(Encoding)).contents
   for i in range(256):info.map[i]=i
   info.release=release;return 1
  @EXT
  def external(parent,context,base,system,public):
   document=resources.get(system.decode()) if resources else None
   if document is None:return 0
   p=l.XML_ExternalEntityParserCreate(parent,context,None)
   if not p:return 0
   status=l.XML_Parse(p,document,len(document),1);l.XML_ParserFree(p);return status
  @START
  def start(_,name,attrs):events.append(['start',name.decode()])
  @END
  def end(_,name):events.append(['end',name.decode()])
  suite=Suite(malloc,realloc,free);p=l.XML_ParserCreate_MM(encoding,c.byref(suite),b' ' if namespaces else None);ctor_counts=counts.copy();phase='measured';counts={'malloc':0,'realloc':0};status=int(bool(p));error=0;child_created=None
  if p:
   l.XML_SetReparseDeferralEnabled(p,0)
   if unknown:l.XML_SetUnknownEncodingHandler(p,codec,None)
   if namespaces:l.XML_SetReturnNSTriplet(p,1);l.XML_SetElementHandler(p,start,end)
   if resources:l.XML_SetExternalEntityRefHandler(p,external);l.XML_SetParamEntityParsing(p,2)
   if document is not None:
    width=chunk or max(1,len(document))
    if not document:status=l.XML_Parse(p,b'',0,int(not child))
    for off in range(0,len(document),width):
     part=document[off:off+width];status=l.XML_Parse(p,part,len(part),int(off+width>=len(document) and not child))
     if status!=1:break
    error=l.XML_GetErrorCode(p)
   parse_counts=counts.copy()
   if child and status==1:
    phase='child';q=l.XML_ExternalEntityParserCreate(p,None,None);child_created=int(bool(q))
    if q:l.XML_ParserFree(q)
   l.XML_ParserFree(p)
  else:parse_counts={}
  assert not live,live
  assert release_calls==unknown_calls,(release_calls,unknown_calls)
  return {'status':status,'error':error,'constructor_calls':ctor_counts,'measured_calls':parse_counts,'child_created':child_created,'child_calls':{k:sum(x['phase']=='child' and x['kind']==k for x in calls) for k in ['malloc','realloc']},'events':events,'live_after_free':len(live),'unknown_calls':unknown_calls,'release_calls':release_calls,'calls':calls}

def main():
 out=Path('/tmp/oriole-constructor-review');engines={'reference':Engine('/home/dev-user/.cache/oriole/expat-build/libexpat.so'),'baseline':Engine('/tmp/oriole-constructor-review/baseline.so'),'candidate':Engine('/tmp/oriole-constructor-review/candidate.so')};cases=[]
 for encoding in [None,b'us-ascii']:
  for namespaces in [False,True]:
   cases.append(('constructor-'+str(encoding)+'-namespaces'+str(namespaces),dict(encoding=encoding,namespaces=namespaces)))
 for name in ['test_alloc_internal_entity','test_alloc_realloc_attributes','test_nsalloc_long_element']:
  for chunk in [0,1]:
   args=dict(document=text_for(name),chunk=chunk,unknown=name=='test_alloc_internal_entity',namespaces=name=='test_nsalloc_long_element');cases.append((name+'-chunk'+str(chunk),args))
 for n in [0,1,16,128]:
  document=b'<!DOCTYPE r ['+b''.join(f'<!ENTITY e{i} "value{i}">'.encode() for i in range(n))+b']>'
  cases.append(('child-clone-'+str(n),dict(document=document,child=True)))
 rows=[]
 for name,args in cases:
  for engine,e in engines.items():rows.append({'case':name,'engine':engine,'parameters':{k:v.hex() if isinstance(v,bytes) else v for k,v in args.items()},'result':e.run(**args)})
 # Fault injection is confined to the original parse ceilings; the unlimited
 # control is a separate public-API count, not a modified upstream test.
 for name,kind,ceiling in [('test_alloc_internal_entity','malloc',20),('test_nsalloc_long_element','malloc',30),('test_alloc_realloc_attributes','realloc',5)]:
  for engine,e in engines.items():
   for fail_at in range(ceiling):
    args=dict(document=text_for(name),unknown=name=='test_alloc_internal_entity',namespaces=name=='test_nsalloc_long_element',fail_kind=kind,fail_at=fail_at)
    rows.append({'case':name+'-fault','engine':engine,'fail_kind':kind,'allowed_calls':fail_at,'result':e.run(**args)})
 for engine,e in engines.items():
  for fail_at in range(10):
   rows.append({'case':'constructor-encoding-fault','engine':engine,'fail_kind':'malloc','allowed_calls':fail_at,'result':e.run(encoding=b'us-ascii',fail_kind='malloc',fail_at=fail_at,constructor_failure=True)})
 report={'scope':'Separate counted public-API reproductions; original upstream tests/thresholds unchanged. Counted suite routes malloc/realloc/free to libc, records all chosen-suite calls and checks zero outstanding blocks and exact accepted-codec release after free. Fault rows keep each original ceiling.','libraries':{n:{'path':e.path,'sha256':hashlib.sha256(Path(e.path).read_bytes()).hexdigest()} for n,e in engines.items()},'observations':rows}
 (out/'counts.json').write_text(json.dumps(report,indent=2)+'\n')
 for row in rows[:24]:
  r=row['result'];print(row['case'],row['engine'],r['status'],r['error'],r['constructor_calls'],r['measured_calls'],r['child_calls'])
if __name__=='__main__':main()
