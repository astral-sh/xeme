import ctypes as c
import hashlib
import itertools
import json
from pathlib import Path

P, S, I = c.c_void_p, c.c_char_p, c.c_int
ROOT = Path('/tmp/oriole-constructor-review')
ENGINES = {'reference': '/home/dev-user/.cache/oriole/expat-build/libexpat.so', 'baseline': str(ROOT/'baseline.so'), 'candidate': str(ROOT/'candidate.so')}
CONTEXTS = [b'', b'xml', b'xml=urn:shadow', b'xml=http://www.w3.org/XML/1998/namespace', b'=u', b'p=u\fp=v', b'bad prefix=uri', b'a\fb', b'=']

def run(path, context, ns, encoding, action):
    l = c.CDLL(path)
    for name, args, result in [('XML_ParserCreate_MM', [S,P,S],P),('XML_ExternalEntityParserCreate',[P,S,S],P),('XML_ParserReset',[P,S],c.c_ubyte),('XML_SetHashSalt',[P,c.c_ulong],I),('XML_GetErrorCode',[P],I),('XML_Parse',[P,S,I,I],I),('XML_ParserFree',[P],None)]:
        f=getattr(l,name);f.argtypes=args;f.restype=result
    parent=l.XML_ParserCreate_MM(encoding,None,b'|' if ns else None)
    assert parent
    rows=[['salt',l.XML_SetHashSalt(parent,12345)]]
    if action=='reset-before':rows.append(['reset',l.XML_ParserReset(parent,encoding)])
    child=l.XML_ExternalEntityParserCreate(parent,context,encoding)
    rows.append(['child',bool(child)])
    if action=='reset-after':rows.append(['reset',l.XML_ParserReset(parent,encoding)])
    if action=='free-parent':l.XML_ParserFree(parent);parent=None
    if child:
        doc=b'<xml:r xml:lang="en"/>'
        rows.append(['parse',l.XML_Parse(child,doc,len(doc),1),l.XML_GetErrorCode(child)])
        l.XML_ParserFree(child)
    if parent:l.XML_ParserFree(parent)
    return rows

import subprocess
import sys
if len(sys.argv)>1:
    case=json.loads(sys.argv[1]);result=run(case['library'],case['context'].encode(),case['namespaces'],case['encoding'].encode() if case['encoding'] else None,case['action']);print(json.dumps(result));sys.exit(0)
rows=[]
for context,ns,encoding,action in itertools.product(CONTEXTS,[False,True],[None,b'UTF-8'],['reset-before','reset-after','free-parent']):
    case={'context':context.decode(),'namespaces':ns,'encoding':encoding.decode() if encoding else None,'action':action}
    result={}
    for key,path in ENGINES.items():
        process=subprocess.run([sys.executable,__file__,json.dumps(dict(case,library=path))],capture_output=True,text=True,timeout=5)
        result[key]={'returncode':process.returncode,'stdout':process.stdout,'stderr':process.stderr}
    rows.append(dict(case,**result))
report={'scope':'Robustness probes include fabricated contexts outside Expat documented callback-context contract and retained-child lifetimes. Such rows are not Expat conformance assertions. Each engine/row runs in an isolated process; all faults retained.', 'cases':len(rows),'baseline_changes':sum(r['baseline']!=r['candidate'] for r in rows),'reference_differences':sum(r['reference']!=r['candidate'] for r in rows),'libraries':{k:{'path':v,'sha256':hashlib.sha256(Path(v).read_bytes()).hexdigest()} for k,v in ENGINES.items()},'observations':rows}
(ROOT/'lifecycle.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='observations'})
