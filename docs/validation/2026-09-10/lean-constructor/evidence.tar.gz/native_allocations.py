from pathlib import Path
import hashlib,json,subprocess,os
root=Path('/tmp/oriole-constructor-review/native');root.mkdir(exist_ok=False)
repo=Path('/home/dev-user/code/oss/oriole');base='7c0d8b35c079c00da3012628ca56d7b35d2c5cd4'
for name in ['include/expat.h','tests/c/allocations.c']:
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',f'{base}:{name}'],cwd=repo))
libs={'shared':Path('/tmp/oriole-constructor-review/candidate-release.so'),'static':Path('/home/dev-user/.cache/oriole/doctype-default-target/release/liboriole_expat.a')}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
observed=[root/'include/expat.h',root/'tests/c/allocations.c',*libs.values()]
report={'scope':'C ASan/UBSan allocation tests with uninstrumented release Rust; leak sanitizer disabled. Original 7c0d8b35 native test assertions unchanged.','sha256_before':{str(p):sha(p) for p in observed},'rows':[],'status':'incomplete'}
try:
 for linkage,lib in libs.items():
  binary=root/('allocations-'+linkage)
  command=['clang','-std=c11','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(root/'include'),str(root/'tests/c/allocations.c'),str(lib),'-o',str(binary)]
  command+=['-Wl,-rpath,'+str(lib.parent)] if linkage=='shared' else ['-lgcc_s','-lutil','-lrt','-lpthread','-lm','-ldl','-lc']
  row={'case':'allocations','linkage':linkage,'command':command};report['rows'].append(row)
  with (root/(linkage+'-build.log')).open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=120)
  row['build_exit_code']=result.returncode;assert result.returncode==0
  row['binary_sha256']=sha(binary);row['run_command']=['taskset','-c','5',str(binary)]
  with (root/(linkage+'.log')).open('w') as log:result=subprocess.run(row['run_command'],stdout=log,stderr=subprocess.STDOUT,timeout=120,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
  row['exit_code']=result.returncode;row['log_sha256']=sha(root/(linkage+'.log'));assert result.returncode==0
 report['sha256_after']={str(p):sha(p) for p in observed};assert report['sha256_after']==report['sha256_before'];report['status']='passed'
finally:(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
