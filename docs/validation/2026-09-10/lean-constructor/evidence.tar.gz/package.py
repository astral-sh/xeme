from pathlib import Path
import gzip, hashlib, json, shutil, tarfile
SRC=Path('/tmp/oriole-constructor-review');DST=Path('/tmp/oriole-constructor-handoff');SNAPSHOT=Path('/tmp/oriole-doctype-default')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(path,target=None):
 target=DST/(target or path.relative_to(SRC));target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
def compress(path,target=None):
 target=DST/(target or str(path.relative_to(SRC))+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 with gzip.open(target,'wb') as f:f.write(path.read_bytes())
DST.mkdir(exist_ok=False)
for p in SRC.iterdir():
 if p.is_file() and p.suffix in ['.py','.json','.patch']:
  if p.name not in ['contexts.json','counts.json','lifecycle.json']:copy(p)
  else:compress(p)
 elif p.is_file() and p.suffix=='.log':compress(p)
copy(Path('/tmp/oriole-constructor-independent-review.json'),'independent-review.json')
for sub in ['benchmark','native']:
 for p in (SRC/sub).rglob('*'):
  if p.is_file() and (p.suffix in ['.json','.gz','.log','.stderr','.c','.h','.xml']):
   if p.suffix=='.log':compress(p)
   else:copy(p)
for sub in ['upstream-api','upstream-release']:
 for name in ['results.json','manifest.json','tests.log','build.log']:
  p=SRC/sub/name
  if p.exists():compress(p)
base=Path('/tmp/oriole-shared-integrated/upstream-api')
for name in ['results.json','manifest.json']:
 compress(base/name,'baseline-upstream/'+name+'.gz')
files=[p for p in SNAPSHOT.rglob('*') if p.is_file() and (p.suffix in ['.rs','.toml','.lock','.h'] or p.name=='Cargo.lock')]
source_manifest={str(p.relative_to(SNAPSHOT)):sha(p) for p in files}
(DST/'build-source.json').write_text(json.dumps(source_manifest,indent=2)+'\n')
with tarfile.open(DST/'source.tar.gz','w:gz') as tar:
 for p in files:tar.add(p,arcname=p.relative_to(SNAPSHOT))
summary={'base_revision':'7c0d8b35c079c00da3012628ca56d7b35d2c5cd4','runtime_change':'Initialize the built-in xml namespace binding only when namespace_separator is Some. The selected-allocator map and its hasher remain present.','patch_sha256':sha(SRC/'change.patch'),'release_sha256':sha(SRC/'candidate-release.so'),'tests':{'core_and_ffi_passed':286,'strict_clippy':True,'native_allocation_scenarios_per_linkage':330,'native_linkages':['shared','static'],'native_sanitizer_scope':'C ASan/UBSan only; linked release Rust is uninstrumented; leak sanitizer disabled.','counted_public_api_observations':237,'all_counted_live_after_free_zero':True,'accepted_custom_encoding_release_exactly_once':True},'allocation_changes':{'root_no_encoding':{'baseline_malloc':9,'candidate_malloc':6,'baseline_requested_bytes':5460,'candidate_requested_bytes':4802},'root_ascii_encoding':{'baseline_malloc':10,'candidate_malloc':7},'namespace_enabled':'No allocation change:9 without encoding,10 with us-ascii.','empty_parameter_child':{'baseline_malloc':10,'candidate_malloc':5,'baseline_requested_bytes':5452,'candidate_requested_bytes':4659}},'local_test_minimum':{'initial_failure':'Generic allocation helper required >100 calls; small shared-open-value workload measures93 after the optimization.','final':'Require nonempty allocations; sweep every measured index with unchanged semantic/OOM/terminal/leak/routing assertions.','upstream_assertions':'Unchanged. No retry ceilings adjusted.'},'upstream_release':{'baseline_pass':4065,'baseline_fail':675,'candidate_pass':4077,'candidate_fail':663,'regressions':0,'signals':0,'timeouts':0,'fixed_test':'test_misc_alloc_create_parser_with_encoding, all12 original contexts','limits':'Same1GiB address-space,768MiB RSS,3s pertest,240s overall bounds.'},'upstream_debug':'Initial debug run also has4077 passes,661assertionfailures,and2timeouts in 2GiB-input tests. Retained separately; final release comparison resolves these profile-dependent timeouts.','context_oracle':{'cases':144,'cases_with_actual_callback_context':72,'manual_context_robustness_cases':72,'baseline_changes':0,'normalized_reference_differences':36,'remaining':'24manual-shadow and12namespace-enabled manual-empty results. Raw reference differences additionally include opaque active-entity context ordering. All observations retained.'},'lifecycle_robustness':{'cases':108,'baseline_changes':0,'reference_process_aborts':20,'scope':'Manual child creation before any ExternalEntityRefHandler call violates the pinned Expat header precondition; retained-child/free-parent results are Oriole robustness checks, not Expat conformance/security assertions. No baseline/candidate signals.'},'benchmark':{'passed':True,'full_callback_preflights':12,'timed_processes':168,'paired_processes_per_configuration':7,'nonnamespace_tiny_candidate_over_baseline':[0.919,0.928,0.923],'interpretation':'Small creation/parse benefit on this host; no broad project throughput claim. Namespace controls and project measurements expose shared-host noise. Full samples, commands, library/source/input hashes retained.'},'limitations':['663 original upstream failures remain.','No full Rust sanitizer campaign rerun for this minimal constructor-only layer.','Benchmark library builds use local Ohm release defaults; deployment CI is a separate parent gate.']}
(DST/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(DST/'initial-lifecycle-outcome.json').write_text(json.dumps({'generator':'initial-lifecycle-probe.py','returncode':134,'captured_tool_stderr':'expat: Allocations(0x1289f7a8): Direct          0, allocated +      1044 to       4098 (      4098 peak), amplification      inf (xmlparse.c:8412)\nmalloc(): invalid next size (unsorted)\n','followup':'lifecycle_probe.py isolates every row and preserves individual return codes/stdout/stderr. Unsupported Expat lifecycle precondition, not a production vulnerability claim.'},indent=2)+'\n')
(DST/'README.md').write_text('''# Namespace-disabled constructor storage

The patch is based on `7c0d8b35c079c00da3012628ca56d7b35d2c5cd4`. It omits the unused built-in namespace binding when namespace expansion is disabled. The empty map keeps its allocator and salted hasher; explicit child contexts and namespace-enabled parsing keep their behavior.

Selected constructor calls fall from 9 to 6, or 10 to 7 with a requested encoding. The unchanged upstream API suite gains all 12 constructor-test configurations: 4,077 pass / 663 fail, with no new failures, signals, or timeouts in the release comparison. Both native linkage modes pass all 330 dynamically measured allocation-failure scenarios. The 286 core/FFI tests and strict Clippy pass.

The small internal allocation workload now makes 93 calls. Its test helper's arbitrary >100-call minimum was replaced with a nonempty check; every measured failure index remains exercised. The initial failure is preserved. No upstream test ceilings or assertions changed.

The 144 context oracle rows and 108 additional robustness rows have no baseline changes. The latter deliberately include manual contexts/child creation before Expat's documented first-external-callback precondition; Expat aborts in 20 parent-free rows. Those are not conformance or security findings. The original aborted attempt and isolated results remain included.

The initial debug upstream run had two 2 GiB-input timeouts; the final release run uses the parent's exact bounds and restores their existing assertion-failure outcomes. Both runs are preserved.

Seven paired native processes per configuration measured roughly 7–8% lower time on the three tiny nonnamespace inputs. Namespace controls and real-project results were mostly similar. These are parser microbenchmarks, not end-to-end project measurements, and shared-host variation remains. Every timed sample is checked against complete callback preflights and an independent native hash/count calculation.

`summary.json` records exact counts and scope; `builds.json`, `build-source.json`, and `source.tar.gz` identify the source and local builds. No binaries are packaged. `independent-review.json` is the root agent's separate source review. The original upstream failures and all unsuccessful experiments remain included.
''')
entries={str(p.relative_to(DST)):sha(p) for p in sorted(DST.rglob('*')) if p.is_file()};(DST/'artifact-manifest.json').write_text(json.dumps(entries,indent=2)+'\n');print(json.dumps({'files':len(entries),'summary_sha256':sha(DST/'summary.json'),'manifest_sha256':sha(DST/'artifact-manifest.json'),'patch_sha256':sha(DST/'change.patch')},indent=2))
