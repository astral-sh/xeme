from pathlib import Path
import hashlib,json,sys
source=Path('/tmp/oriole-custom-alias-full-events-source.py').read_text()
source=source.replace("    p=lib.XML_ParserCreate(b'alias');assert p","    END_DOCTYPE=c.CFUNCTYPE(None,c.c_void_p)\n    @END_DOCTYPE\n    def end_doctype(_):events.append(['end-doctype'])\n    lib.XML_SetEndDoctypeDeclHandler.argtypes=[c.c_void_p,END_DOCTYPE]\n    p=lib.XML_ParserCreate(b'alias');assert p\n    lib.XML_SetEndDoctypeDeclHandler(p,end_doctype)")
paths={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','baseline':'/tmp/oriole-name-final/liboriole_expat.so','candidate':sys.argv[1]};parsers={}
for name,path in paths.items():
 scope={};exec(compile(source.replace(paths['reference'],path),'alias-support','exec'),scope);parsers[name]=scope['parse']
rows=[]
for standalone in [b'',b"<?xml version='1.0' standalone='yes'?>",b"<?xml version='1.0' standalone='no'?>"]:
 for reference in [b'%\x80A;',b'%x\x809;']:
  data=standalone+b'<!DOCTYPE r ['+reference+b']><r/>'
  for width in [0,1,7]:rows.append({'input_hex':data.hex(),'chunk':width,'results':{name:parse(data,width,True) for name,parse in parsers.items()}})
report={'libraries':{name:{'path':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()} for name,path in paths.items()},'cases':len(rows),'rows':rows,'candidate_differences':sum(r['results']['reference']!=r['results']['candidate'] for r in rows),'baseline_differences':sum(r['results']['reference']!=r['results']['baseline'] for r in rows)}
Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ['libraries','rows']});assert report['candidate_differences']==0
