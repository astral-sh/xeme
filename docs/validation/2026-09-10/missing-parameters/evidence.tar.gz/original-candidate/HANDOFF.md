# Missing parameter entities between declarations

Patch: `candidate.patch`, SHA-256 `294a474d676459a9cb0eda1ff19064906f8f2f16c1c2865ff0a78a34938039e3`.
Prerequisite: name-mode patch `626923cc84b8ed7528abbe87fa6e06c670108a941064e78c5b7a61adfd032faa` on `33154ffaaf890f8d97144226d685d80551b37417`.
Frozen debug library SHA-256: `a6035a1617e0fef19a9ccc7c94b4cd5c62368d07be3bc6e5bc8f79479a605b87`.
Patch applies to the frozen name-mode source; `apply-check.log` is clean.

## Change

Expat sets hasParamEntityRefs before deciding whether an undeclared parameter reference requires a declaration. A missing name is an error only for a standalone document reference outside an internal replacement; external subsets and references inside internal PE replacements skip it. The direct fix changes that condition, retaining prior lexical name validation, source limits, declaration skip flag, SkippedEntity and raw-default behavior. See pinned Expat `xmlparse.c`6077–6135 at revision12cf0b1f25f026a022fe728ad8f7e3d017285b80.

Disabled PE processing now queues the bounded raw `%name;` after NotStandalone, so default handlers receive it. The raw owner uses the selected allocator, is bounded by the reference-token limit, and is freed/terminal on allocation failures. It adds no raw allocation without default events.

No hashing, entity expansion/declaration limits, namespace rules or ordinary XML fast path changes.

## Validation

-250 Rust checks pass, including4 new core missing-PE tests and1 C reset test. The exhaustive selected-allocator/OOM workload now exercises enabled and disabled missing-PE handling and raw default ownership. Strict Clippy and fmt pass.
-120 selected upstream configurations pass: standalone/missing/skipped parameter cases, undefined general/external entity cases, and NotStandalone accept/reject.
-1,944 oracle conditions cover standalone absent/yes/no, parsing modes0/1/2, six callback profiles, whole/1/7-byte chunks, direct/nested/internal/external references, declarations after a skip and malformed names. Baseline has468 acceptance differences; candidate has0 and exact top-level error codes.
-162 conditions still differ in events;24 include child callback execution differences because the existing external-subset NotStandalone callback fires too early. All are pre-existing condition mismatches. Failed-input partial callbacks also differ. Exact rows are retained in candidate.json; no claim that callbacks are fully exact.

## Separate shared-state bug

`siblings.py` demonstrates that declaration skip state must be shared before a parameter child finishes and before a precreated sibling starts. Three of four cases still produce a later declaration/text in Oriole that Expat skips. That needs a distinct lazy shared-state change; this patch deliberately does not introduce that state architecture.

## Integration

- Root boxed EventKind payloads must be retained when adapting the new core test's EntityDeclaration match.
- Root custom-decoding raw name validation must stay before the new missing-reference condition.
- The change to name_rules.rs removes its old expected UndefinedEntity assertion for a Fifth Edition-valid undeclared parameter name; that case is now accepted by the corrected rule.
- No shared root files were edited.

Run oracle.py with the clean uv Python interpreter and two arguments: candidate library and JSON output path. Never use system Python, which preloads another Expat. The selected upstream runner command and exact library origin are preserved under upstream-api/manifest.json.
