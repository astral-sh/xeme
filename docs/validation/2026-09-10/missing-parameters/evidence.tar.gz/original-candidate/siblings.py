import runpy,sys,json,ctypes as c
from pathlib import Path
m=runpy.run_path('/tmp/oriole-missing-parameter/oracle.py');setup=m['setup'];EXT=m['EXT'];ENTITY=m['ENTITY'];TEXT=m['TEXT'];SKIP=m['SKIP']
def run(lib,precreated,first_final):
 events=[];results=[]
 @ENTITY
 def entity(_,name,param,value,n,base,system,public,notation):events.append(['entity',name.decode()])
 @TEXT
 def text(_,data,n):events.append(['text',c.string_at(data,n).decode()])
 @SKIP
 def skip(_,name,param):events.append(['skipped',name.decode(),param])
 def parse(p,raw,final):
  r=lib.XML_Parse(p,raw,len(raw),final);return [r,lib.XML_GetErrorCode(p)]
 @EXT
 def external(parent,context,base,system,public):
  first=lib.XML_ExternalEntityParserCreate(parent,None,None);assert first
  second=lib.XML_ExternalEntityParserCreate(parent,None,None) if precreated else None
  results.append(['first',*parse(first,b'%missing;',first_final)])
  if second is None:second=lib.XML_ExternalEntityParserCreate(parent,None,None)
  assert second
  results.append(['second',*parse(second,b"<!ENTITY later 'L'>",1)])
  if not first_final:results.append(['first-finish',*parse(first,b'',1)])
  lib.XML_ParserFree(second);lib.XML_ParserFree(first);return 1
 p=lib.XML_ParserCreate(None);lib.XML_SetParamEntityParsing(p,2);lib.XML_SetExternalEntityRefHandler(p,external);lib.XML_SetEntityDeclHandler(p,entity);lib.XML_SetCharacterDataHandler(p,text);lib.XML_SetSkippedEntityHandler(p,skip)
 result=parse(p,b"<!DOCTYPE r SYSTEM 'd'><r>&later;</r>",1);lib.XML_ParserFree(p)
 return {'result':result,'children':results,'events':events}
paths={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','candidate':sys.argv[1]};libs={k:setup(v) for k,v in paths.items()}
rows=[{'precreated':a,'first_final':b,'results':{k:run(lib,a,b) for k,lib in libs.items()}} for a in [False,True] for b in [0,1]]
Path('/tmp/oriole-missing-parameter/siblings.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
