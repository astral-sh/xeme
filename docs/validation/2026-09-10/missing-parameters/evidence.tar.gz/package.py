from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
source=Path('/tmp/oriole-missing-final');repo=Path('/home/dev-user/code/oss/oriole-api-followup');out=repo/'docs/validation/2026-09-10/missing-parameters';out.mkdir(parents=True,exist_ok=True);original=Path('/tmp/oriole-missing-parameter');baseline=Path('/tmp/oriole-name-final/upstream-complete');sha=lambda b:hashlib.sha256(b).hexdigest();entries={}
for p in sorted(source.rglob('*')):
 if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log','.py','.patch','.rej','.c','.h']:entries[str(p.relative_to(source))]=p.read_bytes()
for name in ['HANDOFF.md','candidate.patch','source.json','validation.json','candidate.json','baseline.json','oracle.py','siblings.json','siblings.py']:entries['original-candidate/'+name]=(original/name).read_bytes()
for name in ['results.json','manifest.json','tests.log']:entries['baseline-upstream/'+name]=(baseline/name).read_bytes()
entries['alias-support.py']=Path('/tmp/oriole-custom-alias-full-events-source.py').read_bytes()
for name,digest in json.loads((source/'source.json').read_text()).items():
 data=(repo/name).read_bytes();assert sha(data)==digest;entries['frozen-source/'+name]=data
files=[{'path':p,'bytes':len(v),'sha256':sha(v)} for p,v in sorted(entries.items())];(out/'files.json').write_text(json.dumps(files,indent=2)+'\n')
with (out/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
a=json.loads((baseline/'results.json').read_text());b=json.loads((source/'upstream-complete/results.json').read_text());am=json.loads((baseline/'manifest.json').read_text());bm=json.loads((source/'upstream-complete/manifest.json').read_text());assert a['results']==b['results'] and am['adapted_sources']==bm['adapted_sources']
oracle=json.loads((source/'oracle.json').read_text());assert oracle['differences']==json.loads((original/'candidate.json').read_text())['differences'];native=json.loads((source/'native/report.json').read_text());assert native['status']=='passed'
report={'source_commit':'3e4d0062d198400539a4ed61433c20a35e0f8d87','base_commit':'6b19e01','shared_sha256':sha((source/'liboriole_expat.so').read_bytes()),'static_sha256':sha((source/'liboriole_expat.a').read_bytes()),'checks':{'rust_tests':279,'strict_clippy':'passed','native_suites':6,'allocation_scenarios_per_linkage':333,'native_scope':native['scope']},'upstream':{'before':{'passed':a['passed'],'failed':a['failed']},'after':{'passed':b['passed'],'failed':b['failed']},'changes':[],'identical_adapted_sources':True},'oracle':oracle['counts'],'oracle_disposition':'All remaining 24 child-execution and 162 event differences are identical to original candidate; no top-level acceptance differences.','custom_alias_oracle':{'cases':18,'exact_differences':0,'baseline_exact_differences':18,'scope':'Both doctype callbacks installed; direct disabled references with ASCII aliases, standalone absent/yes/no and whole/one/seven-byte feeds.'},'initial_alias_probe':{'cases':18,'exact_differences':18,'scope':'Without an end-doctype handler, candidate retains a preexisting extra closing-bracket default fragment. Original traces/script are archived; no exact-compatibility claim for this profile.'},'limits':'Absolute and relative security budgets unchanged. Selected-allocator exhaustive OOM includes enabled and disabled missing-PE raw ownership.','separate_work':'Precreated/nonfinal sibling declaration-skip sharing remains for the next layer.','artifacts':{'files':len(files),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes())}}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(len(files),'files',len((out/'evidence.tar.gz').read_bytes()),'archive bytes')
