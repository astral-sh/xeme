# Custom encoding lexical provenance review

The bounded probe loads the pinned reference Expat 2.8.4 library through Python
`ctypes`. Each case uses an independent parser, an identity single-byte map with
`map[0x80] = -2`, and a converter returning one fixed Unicode scalar. Input is one
final chunk. The report records exact input bytes, results, callback events,
callback counts, the loaded library SHA-256, and the probe SHA-256.

Reproduce from the repository checkout:

```sh
python3 /tmp/oriole-multibyte-provenance-review/probe.py \
  --library /home/dev-user/.cache/oriole/expat-build/libexpat.so \
  --output /tmp/oriole-multibyte-provenance-review/results.json
```

The reference distinguishes literal ASCII syntax from multibyte sequences whose
converter returns the same ASCII character. Numeric references and DTD keywords
can fail; a converted `amp` name does not receive predefined entity treatment;
and a converted `xml` processing-instruction target remains a processing
instruction. Ordinary names, namespace names, and non-ASCII controls illustrate
where decoded-name behavior is accepted.

These are reference observations, not a test run against Oriole. The follow-up
Oriole implementation deliberately rejects all multibyte-to-ASCII conversions
until it preserves enough lexical provenance to implement these distinctions.
