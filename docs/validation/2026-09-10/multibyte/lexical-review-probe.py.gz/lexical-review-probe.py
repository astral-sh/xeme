#!/usr/bin/env python3
"""Reproduce bounded custom-encoding lexical provenance cases against Expat."""

import argparse
import ctypes as c
import hashlib
import json
from pathlib import Path
import resource


CASES = [
    ("numeric_radix_alias", b"<r>&#\x80\x8041;</r>", "x", False),
    ("numeric_hex_digit_alias", b"<r>&#x\x80\x80;</r>", "A", False),
    ("numeric_attribute_alias", b'<r a="&#\x80\x8041;"/>', "x", False),
    ("numeric_entity_value_alias", b'<!DOCTYPE r [<!ENTITY e "&#x\x80\x80;">]><r>&e;</r>', "A", False),
    ("predefined_entity_alias", b"<r>&\x80\x80mp;</r>", "a", False),
    ("doctype_keyword_alias", b"<!\x80\x80OCTYPE r><r/>", "D", False),
    ("entity_keyword_alias", b'<!DOCTYPE r [<!\x80\x80NTITY e "text">]><r>&e;</r>', "E", False),
    ("system_keyword_alias", b'<!DOCTYPE r \x80\x80YSTEM "u"><r/>', "S", False),
    ("xml_target_with_version_alias", b'<?\x80\x80ml version="1.0"?><r/>', "x", False),
    ("xml_target_empty_alias", b"<?\x80\x80ml?><r/>", "x", False),
    ("declared_entity_name_alias", b'<!DOCTYPE r [<!ENTITY e "v">]><r>&\x80\x80;</r>', "e", False),
    ("ascii_content_control", b"<r>\x80\x80</r>", "A", False),
    ("non_ascii_content_control", b"<r>\x80\x80</r>", "é", False),
    ("non_ascii_element_control", b"<\x80\x80/>", "é", False),
    ("namespace_default_alias", b'<r \x80\x80mlns="u"/>', "x", True),
    ("namespace_prefix_alias", b'<r \x80\x80mlns:p="u"><p:c/></r>', "x", True),
    ("xml_element_prefix_alias", b"<\x80\x80ml:a/>", "x", True),
    ("xml_attribute_prefix_alias", b'<r \x80\x80ml:lang="en"/>', "x", True),
    ("reserved_xml_binding_alias", b'<r xmlns:\x80\x80ml="u"/>', "x", True),
    ("reserved_xmlns_binding_alias", b'<r xmlns:\x80\x80mlns="u"/>', "x", True),
]


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_CPU, (15, 15))
    resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024,) * 2)
    library = args.library.resolve(strict=True)
    expat = c.CDLL(str(library))
    convert_type = c.CFUNCTYPE(c.c_int, c.c_void_p, c.c_void_p)
    release_type = c.CFUNCTYPE(None, c.c_void_p)

    class Encoding(c.Structure):
        _fields_ = [
            ("map", c.c_int * 256),
            ("data", c.c_void_p),
            ("convert", convert_type),
            ("release", release_type),
        ]

    encoding_type = c.CFUNCTYPE(c.c_int, c.c_void_p, c.c_char_p, c.POINTER(Encoding))
    text_type = c.CFUNCTYPE(None, c.c_void_p, c.c_void_p, c.c_int)
    pi_type = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.c_char_p)
    start_type = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.POINTER(c.c_char_p))
    ns_type = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.c_char_p)
    declarations = {
        "XML_ExpatVersion": ([], c.c_char_p),
        "XML_ParserCreate": ([c.c_char_p], c.c_void_p),
        "XML_ParserCreateNS": ([c.c_char_p, c.c_char], c.c_void_p),
        "XML_SetUnknownEncodingHandler": ([c.c_void_p, encoding_type, c.c_void_p], None),
        "XML_SetCharacterDataHandler": ([c.c_void_p, text_type], None),
        "XML_SetProcessingInstructionHandler": ([c.c_void_p, pi_type], None),
        "XML_SetStartElementHandler": ([c.c_void_p, start_type], None),
        "XML_SetStartNamespaceDeclHandler": ([c.c_void_p, ns_type], None),
        "XML_Parse": ([c.c_void_p, c.c_void_p, c.c_int, c.c_int], c.c_int),
        "XML_GetErrorCode": ([c.c_void_p], c.c_int),
        "XML_GetCurrentByteIndex": ([c.c_void_p], c.c_long),
        "XML_ErrorString": ([c.c_int], c.c_char_p),
        "XML_ParserFree": ([c.c_void_p], None),
    }
    for name, (arguments, result) in declarations.items():
        function = getattr(expat, name)
        function.argtypes = arguments
        function.restype = result

    results = []
    for name, document, scalar, namespaces in CASES:
        events = []
        counts = {"unknown_encoding": 0, "convert": 0, "release": 0}
        sequences = set()

        @convert_type
        def convert(_data, sequence):
            counts["convert"] += 1
            sequences.add(c.string_at(sequence, 2).hex())
            return ord(scalar)

        @release_type
        def release(_data):
            counts["release"] += 1

        @encoding_type
        def encoding(_data, _name, info):
            counts["unknown_encoding"] += 1
            for byte in range(256):
                info.contents.map[byte] = byte
            info.contents.map[0x80] = -2
            info.contents.convert = convert
            info.contents.release = release
            info.contents.data = None
            return 1

        @text_type
        def text(_data, value, length):
            events.append({"event": "text", "value": c.string_at(value, length).decode()})

        @pi_type
        def pi(_data, target, value):
            events.append({"event": "processing_instruction", "target": target.decode(), "data": value.decode()})

        @start_type
        def start(_data, element, attributes):
            pairs = []
            index = 0
            while attributes[index]:
                pairs.append([attributes[index].decode(), attributes[index + 1].decode()])
                index += 2
            events.append({"event": "start_element", "name": element.decode(), "attributes": pairs})

        @ns_type
        def namespace(_data, prefix, uri):
            events.append({"event": "namespace", "prefix": None if prefix is None else prefix.decode(), "uri": None if uri is None else uri.decode()})

        handle = expat.XML_ParserCreateNS(b"custom", b"|") if namespaces else expat.XML_ParserCreate(b"custom")
        if not handle:
            raise MemoryError("XML_ParserCreate failed")
        expat.XML_SetUnknownEncodingHandler(handle, encoding, None)
        expat.XML_SetCharacterDataHandler(handle, text)
        expat.XML_SetProcessingInstructionHandler(handle, pi)
        expat.XML_SetStartElementHandler(handle, start)
        if namespaces:
            expat.XML_SetStartNamespaceDeclHandler(handle, namespace)
        status = expat.XML_Parse(handle, document, len(document), 1)
        error = expat.XML_GetErrorCode(handle)
        error_string = expat.XML_ErrorString(error)
        position = expat.XML_GetCurrentByteIndex(handle)
        expat.XML_ParserFree(handle)
        results.append({
            "name": name,
            "document_python_repr": repr(document),
            "document_hex": document.hex(),
            "conversion_result": scalar,
            "conversion_codepoint": ord(scalar),
            "namespace_processing": namespaces,
            "status": status,
            "error_code": error,
            "error_string": None if error_string is None else error_string.decode(),
            "byte_index": position,
            "events": events,
            "callback_counts": counts,
            "converted_sequences_hex": sorted(sequences),
        })
    report = {
        "scope": "Reference Expat only; no Oriole library is loaded. Fixed two-byte custom map with identity single-byte entries and map[0x80]=-2. Each case uses a fresh parser and one final input chunk.",
        "source_revision": "12cf0b1f25f026a022fe728ad8f7e3d017285b80",
        "source_repository": "https://github.com/libexpat/libexpat",
        "library": str(library),
        "library_sha256": sha256(library),
        "expat_version": expat.XML_ExpatVersion().decode(),
        "script_sha256": sha256(Path(__file__)),
        "limits": {"cpu_seconds": 15, "address_space_bytes": 512 * 1024 * 1024, "core_bytes": 0},
        "cases": results,
    }
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"output": str(args.output), "library_sha256": report["library_sha256"], "version": report["expat_version"], "cases": len(results)}))


if __name__ == "__main__":
    main()
