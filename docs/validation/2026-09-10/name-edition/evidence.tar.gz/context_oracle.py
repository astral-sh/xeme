"""Public C API name-context oracle; no Expat linked into this Python process."""
import ctypes as c
import hashlib,json,itertools,sys
from pathlib import Path
assert not any(line.rsplit('/',1)[-1].startswith('libexpat.') for line in Path('/proc/self/maps').read_text().splitlines())
START=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.POINTER(c.c_char_p))
END=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p)
TEXT=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_int)
PI=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_char_p)
EXT=c.CFUNCTYPE(c.c_int,c.c_void_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p)
def setup(path):
 lib=c.CDLL(path)
 for name,args,result in [('XML_ParserCreate',[c.c_char_p],c.c_void_p),('XML_ParserCreateNS',[c.c_char_p,c.c_char],c.c_void_p),('XML_ExternalEntityParserCreate',[c.c_void_p,c.c_char_p,c.c_char_p],c.c_void_p),('XML_Parse',[c.c_void_p,c.c_char_p,c.c_int,c.c_int],c.c_int),('XML_GetErrorCode',[c.c_void_p],c.c_int),('XML_GetCurrentByteIndex',[c.c_void_p],c.c_long),('XML_SetParamEntityParsing',[c.c_void_p,c.c_int],c.c_int),('XML_ParserFree',[c.c_void_p],None),('XML_SetElementHandler',[c.c_void_p,START,END],None),('XML_SetCharacterDataHandler',[c.c_void_p,TEXT],None),('XML_SetProcessingInstructionHandler',[c.c_void_p,PI],None),('XML_SetExternalEntityRefHandler',[c.c_void_p,EXT],None)]:
  fn=getattr(lib,name);fn.argtypes=args;fn.restype=result
 return lib

def run(lib,xml,chunk,encoding,ns,external):
 def encode(s):return s.encode(encoding)
 parser=lib.XML_ParserCreateNS(None,b'|') if ns else lib.XML_ParserCreate(None);assert parser
 lib.XML_SetParamEntityParsing(parser,2)
 events=[];children=[]
 @START
 def start(_,name,attrs):
  a=[];i=0
  while attrs[i]:a.append((attrs[i].decode(),attrs[i+1].decode()));i+=2
  events.append(['start',name.decode(),a])
 @END
 def end(_,name):events.append(['end',name.decode()])
 @TEXT
 def text(_,data,length):
  value=c.string_at(data,length).decode()
  if events and events[-1][0]=='text':events[-1][1]+=value
  else:events.append(['text',value])
 @PI
 def pi(_,target,data):events.append(['pi',target.decode(),data.decode()])
 def parse(p,raw):
  width=chunk or len(raw);status=1
  for offset in range(0,len(raw),width):
   piece=raw[offset:offset+width];status=lib.XML_Parse(p,piece,len(piece),int(offset+width>=len(raw)))
   if status!=1:break
  return [status,lib.XML_GetErrorCode(p)]
 @EXT
 def child(parent,context,base,system,public):
  p=lib.XML_ExternalEntityParserCreate(parent,context,None)
  if not p:return 0
  result=parse(p,encode(external[system.decode()]));children.append(result)
  lib.XML_ParserFree(p);return int(result[0]==1)
 lib.XML_SetElementHandler(parser,start,end);lib.XML_SetCharacterDataHandler(parser,text);lib.XML_SetProcessingInstructionHandler(parser,pi);lib.XML_SetExternalEntityRefHandler(parser,child)
 result=parse(parser,encode(xml));lib.XML_ParserFree(parser)
 return {'result':result,'children':children,'events':events}

def cases(name):
 return {
 'element':(f'<{name}></{name}>',{}),
 'attribute':(f"<r {name}='v'/>",{}),
 'pi':(f'<?{name} data?><r/>',{}),
 'doctype':(f'<!DOCTYPE {name}><{name}/>',{}),
 'entity':(f"<!DOCTYPE r [<!ENTITY {name} 'v'>]><r>&{name};</r>",{}),
 'attribute-reference':(f"<!DOCTYPE r [<!ENTITY {name} 'v'>]><r a='&{name};'/>",{}),
 'unbound-reference':(f'<r>&{name};</r>',{}),
 'unbound-attribute-reference':(f"<r a='&{name};'/>",{}),
 'parameter':(f"<!DOCTYPE r [<!ENTITY % {name} '<!ELEMENT r EMPTY>'>%{name};]><r/>",{}),
 'unbound-parameter':(f'<!DOCTYPE r [%{name};]><r/>',{}),
 'attlist':(f"<!DOCTYPE r [<!ATTLIST r {name} CDATA 'v'>]><r/>",{}),
 'notation':(f"<!DOCTYPE r [<!NOTATION {name} SYSTEM 'x'><!ENTITY e SYSTEM 'e' NDATA {name}>]><r/>",{}),
 'model':(f'<!DOCTYPE r [<!ELEMENT r ({name})><!ELEMENT {name} EMPTY>]><r><{name}/></r>',{}),
 'enum':(f"<!DOCTYPE r [<!ATTLIST r a ({name}) '{name}'>]><r/>",{}),
 'internal-content':(f"<!DOCTYPE r [<!ENTITY e '<{name}/>'>]><r>&e;</r>",{}),
 'namespace-prefix':(f"<{name}:r xmlns:{name}='u'/>",{}),
 'namespace-local':(f"<p:{name} xmlns:p='u'/>",{}),
 'attribute-prefix':(f"<r xmlns:{name}='u' {name}:a='v'/>",{}),
 'attribute-local':(f"<r xmlns:p='u' p:{name}='v'/>",{}),
 'external-subset':("<!DOCTYPE r SYSTEM 'd'><r/>",{'d':f"<!ENTITY {name} 'v'>"}),
 'external-value-token':("<!DOCTYPE r SYSTEM 'd'><r/>",{'d':"<!ENTITY % p SYSTEM 'p'><!ENTITY e '%p;'>",'p':name}),
 'external-value-reference':("<!DOCTYPE r SYSTEM 'd'><r/>",{'d':"<!ENTITY % p SYSTEM 'p'><!ENTITY e '%p;'>",'p':f'%{name};'}),
 }
paths={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','candidate':sys.argv[1]}
libs={label:setup(path) for label,path in paths.items()};diffs=[];total=0;acceptance=0;errors=0;events=0
for scalar,prefix in itertools.product([0xc0,0xb7,0x300,0x370,0x901,0xe01,0x3007,0x4e00,0xac00,0xd7a3,0x10000,0xe000,0xeffff],['','a']):
 name=prefix+chr(scalar)
 for (case,(xml,external)),chunk,encoding,ns in itertools.product(cases(name).items(),[0,1,7],['utf-8','utf-16'],[False,True]):
  results={label:run(lib,xml,chunk,encoding,ns,external) for label,lib in libs.items()};total+=1
  a,b=results.values()
  if a!=b:
   acceptance+=a['result'][0]!=b['result'][0];errors+=a['result']!=b['result'] or a['children']!=b['children'];events+=a['events']!=b['events']
   diffs.append({'scalar':hex(scalar),'prefix':prefix,'case':case,'chunk':chunk,'encoding':encoding,'namespaces':ns,'results':results})
report={'python':sys.executable,'libraries':{label:{'path':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()} for label,path in paths.items()},'total_conditions':total,'acceptance_differences':acceptance,'status_error_differences':errors,'event_differences':events,'differences':diffs}
Path('/tmp/oriole-name-final/context-oracle.json').write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k not in ['libraries','differences']})
