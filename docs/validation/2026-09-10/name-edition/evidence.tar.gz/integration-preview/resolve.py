from pathlib import Path

def edit(path, pairs):
 p=Path(path);s=p.read_text()
 for old,new,count in pairs:
  assert s.count(old)==count,(path,old,s.count(old),count)
  s=s.replace(old,new)
 p.write_text(s)
edit('crates/oriole/src/lib.rs',[
 ('use names::{is_name, is_uri_char, is_xml_char, whitespace};','pub use names::NameRules;\nuse names::{is_uri_char, is_xml_char, whitespace};',1),
 ('!is_name(raw_name)','!self.config.name_rules.is_name(raw_name)',2),
 ('take_name(body)','take_name(body, self.config.name_rules)',2),
 ('!names::is_qname(raw_name)','!self.config.name_rules.is_qname(raw_name)',1),
 ('!names::is_qname(attr_name)','!self.config.name_rules.is_qname(attr_name)',1),
 ('            self.config.limits.max_attributes,\n        )','            self.config.limits.max_attributes,\n            self.config.name_rules,\n        )',1),
 ('parse_raw_attributes(rest, false, &mut attrs, 3)','parse_raw_attributes(rest, false, &mut attrs, 3, self.config.name_rules)',1),
 ('    result: &mut Vec<RawAttribute>,\n    limit: usize,','    result: &mut Vec<RawAttribute>,\n    limit: usize,\n    name_rules: NameRules,',1),
])
edit('crates/oriole/src/dtd.rs',[
 ('            self.config.namespace_separator.is_some(),\n        );','            self.config.namespace_separator.is_some(),\n            self.config.name_rules,\n        );',1),
 ('crate::names::is_name(raw_name)','self.config.name_rules.is_name(raw_name)',1),
 ('crate::names::is_name(reference)','self.config.name_rules.is_name(reference)',1),
 ('Cursor::new(grammar, self.config.namespace_separator.is_some())','Cursor::new(grammar, self.config.namespace_separator.is_some(), self.config.name_rules)',1),
 ('Cursor::new(Slice::plain(""), self.config.namespace_separator.is_some())','Cursor::new(Slice::plain(""), self.config.namespace_separator.is_some(), self.config.name_rules)',1),
 ('    lexical: Slice<\'a>,\n    text: &\'a str,\n    namespaces: bool,','    lexical: Slice<\'a>,\n    text: &\'a str,\n    namespaces: bool,\n    name_rules: crate::NameRules,',1),
 ('fn new(lexical: Slice<\'a>, namespaces: bool) -> Self','fn new(lexical: Slice<\'a>, namespaces: bool, name_rules: crate::NameRules) -> Self',1),
 ('            namespaces,\n            initial_len: text.len(),','            namespaces,\n            name_rules,\n            initial_len: text.len(),',1),
 ('            } else {\n                self.err(ErrorKind::Syntax, message)\n            }\n        })?;\n        let model = cursor','            } else {\n                self.dtd_grammar_error(cursor, message)\n            }\n        })?;\n        let model = cursor',1),
])
edit('crates/oriole/src/encoding.rs',[
 ('    deferred_size: usize,\n}','    deferred_size: usize,\n    name_rules: crate::NameRules,\n}',1),
 ('pub(crate) fn new(allocator: Allocator) -> Self {\n        Self {\n            text:','pub(crate) fn new(allocator: Allocator, name_rules: crate::NameRules) -> Self {\n        Self {\n            text:',1),
 ('custom_public_byte(map, byte)','custom_public_byte(map, byte, source.name_rules)',1),
 ('custom_public_byte(map, *byte)','custom_public_byte(map, *byte, source.name_rules)',1),
 ('fn custom_public_byte(map: &[i32; 256], byte: u8) -> bool','fn custom_public_byte(map: &[i32; 256], byte: u8, name_rules: crate::NameRules) -> bool',1),
 ('.is_some_and(crate::names::is_name_char)', '.is_some_and(|character| name_rules.is_name_char(character))',1),
])
edit('crates/oriole/src/lexical.rs',[
 ('crate::names::is_name_start(scalar)','crate::NameRules::FifthEdition.is_name_start(scalar)',1),
 ('crate::names::is_name_char(scalar)','crate::NameRules::FifthEdition.is_name_char(scalar)',1),
])
edit('crates/oriole/src/dtd/composition.rs',[
 ('            state.position,\n            self.stack.len(),\n        );','            state.position,\n            self.stack.len(),\n            self.config.name_rules,\n        );',1),
])
edit('crates/oriole/src/dtd/semantic.rs',[
 ('            self.config.namespace_separator.is_some(),\n        );','            self.config.namespace_separator.is_some(),\n            self.config.name_rules,\n        );',1),
])
edit('crates/oriole_expat/src/lib.rs',[
 ('EventKind, Parser, Position, RecyclingToken','EventKind, NameRules, Parser, Position, RecyclingToken',1),
])
p=Path('crates/oriole_expat/src/tests.rs');s=p.read_text();rej=p.with_suffix('.rs.rej').read_text();new='\n'.join(line[1:] for line in rej.splitlines() if line.startswith('+') and not line.startswith('+++'))+'\n';p.write_text(s+new)
p=Path('crates/oriole/tests/allocation.rs');s=p.read_text();a='            namespace_triplets: true,\n';assert s.count(a)==1;s=s.replace(a,a+'            name_rules: oriole::NameRules::FourthEdition,\n');old=next(line for line in s.splitlines() if "<!ENTITY internal '<p:n/>'" in line);new=old.replace('parser.feed(b"','parser.feed("').replace("<p:n/>","<p:À/>").replace('", true)?;','".as_bytes(), true)?;');s=s.replace(old,new);p.write_text(s)
print('resolved runtime and tests; rejected copies retained for audit')
