# XML name edition compatibility

Candidate: `candidate.patch`, SHA-256 `626923cc84b8ed7528abbe87fa6e06c670108a941064e78c5b7a61adfd032faa`.
Base: `33154ffaaf890f8d97144226d685d80551b37417`. The patch passes apply-check against that exact base.
Frozen debug library: `liboriole_expat.so`, SHA-256 `c64778bf1c6e1d36cc84b3739a42b88fa5b3e83648b2d423ad1940df5ce5cf57`.
Source archive and exact changed file hashes: `source.tar.gz`, `source.json`.

## Behavior

- Core `Config.name_rules: NameRules` defaults to `FifthEdition`; the C constructor selects `FourthEdition`, inherited by resets and both kinds of external children.
- Every lexical name predicate, including incremental source/reference scanners, DTD grammar/composition, external entity-value scanning, QName parts and enumeration NameChar uses the selected mode. No unsafe Rust, allocation primitive, hashing or limit change.
- ASCII uses the original fast predicate before branching on the edition. Fourth Edition non-ASCII tables are merged numeric ranges from W3C XML Fourth Edition productions84–89, independent of Expat code. `xml4-character-classes.json` preserves source data/provenance; `implement.py` contains the reproducible union routine.
- Malformed names inside content models and attribute enumerations now produce InvalidToken rather than Syntax; valid tokens in the wrong role retain Syntax.
- README documents the defaults. Streaming fuzz control bit64 selects the edition, bit128 namespaces, low6bits chunk size. Existing exhaustive selected-allocator workload now exercises a non-ASCII Fourth Edition internal replacement element.

## Validation

- 245 Rust checks passed (240 existing +4 core integration tests +1 C reset/children test), selected-suite exhaustive OOM, strict Clippy, fmt, streaming fuzz target compile-check. No runtime fuzz campaign, release performance, sanitizer or full upstream matrix claim.
- Expat and final frozen candidate each parsed every non-ASCII Unicode scalar twice (`<scalar/>` and `<a scalar/>` without the illustrative space): 2,223,872 cases per library, surrogates skipped. All acceptance bits match; all rejected cases report error4. `scalar_oracle.c`, `*-scalars.json`, `*-scalars.bin` are reusable evidence.
- Context oracle: 6,864 conditions across22 contexts,13 scalar samples at initial/continuation positions, UTF-8/UTF-16, namespace on/off, chunks whole/1/7. All edition-specific results and normalized callbacks agree. The only180 remaining differences are pre-existing undeclared parameter entity semantics (`<!DOCTYPE r [%missing;]><r/>`), scheduled as a separate follow-up; no hidden skips.
- Upstream selected matrix:24/24 pass; fixes18 previously failing configurations. Six `test_utf8_in_start_tags` deferral-enabled configurations skip their upstream body and are explicitly not additional evidence. `upstream-api/results.json` and manifest preserve exact inputs/library origin.

## Integration conflicts to preserve

This base predates root raw-offset/recycling and custom encoding alias restoration.

1. Pass `self.config.name_rules` to the raw-offset `parse_raw_attributes` helper and into its `take_name` calls; retain root's scratch vector ownership/recycling design.
2. Keep root's boxed EventKind payloads when adapting the existing allocation workload. This patch changes only its config and ASCII replacement element to `À`; do not replace boxed variants with the older base patterns.
3. api_followup adds raw QName checks in parse_start and raw entity/parameter-reference checks before restoration. Route all of those through `self.config.name_rules`.
4. api_followup removes decoded `expand_name` prefix/local validation for custom ASCII aliases. Preserve that removal; this base's mode change at that old validation site must not reintroduce it.
5. api_followup's encoding `custom_public_byte` has a new NameChar predicate. Pass the selected Source.name_rules into that helper. Their raw representatives are À, middle dot and U+E000, compatible with both name editions.
6. Source::new and Source::entity now receive NameRules; keep that copyable field alongside custom-decoding metadata. No borrow crosses feed/callback boundaries.

## Rerun

```sh
cc -O2 -Wall -Wextra -Werror scalar_oracle.c -ldl -o scalar_oracle
taskset -c 7 ./scalar_oracle /path/to/candidate.so candidate-scalars.bin
cmp expat-scalars.bin candidate-scalars.bin
/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S context_oracle.py /path/to/candidate.so
```

Use the clean uv Python interpreter: system Python preloads a different Expat and causes symbol interposition. Root CPU0 remained untouched. All limits remain unchanged.
