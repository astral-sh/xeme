from pathlib import Path
import json,re
root=Path('/tmp/oriole-raw-attribute-scratch')
def edit(path,fn):
 p=root/path;p.write_text(fn(p.read_text()))
classes=json.loads(Path('/tmp/oriole-name-compatibility/xml4-character-classes.json').read_text())['classes']
def merged(keys):
 ranges=sorted((max(a,128),b) for key in keys for a,b in classes[key] if b>=128)
 out=[]
 for a,b in ranges:
  if out and a<=out[-1][1]+1:out[-1][1]=max(b,out[-1][1])
  else:out.append([a,b])
 return out
start=merged(['BaseChar','Ideographic'])
extra=merged(['Digit','CombiningChar','Extender'])
# The normative numeric character productions are data, not copied Expat code.
old=(root/'crates/oriole/src/names.rs').read_text()
prefix=old[:old.index('#[inline]')].replace('//! XML 1.0 (Fifth Edition) character and name productions.','//! XML 1.0 character and name productions.')
fifth_start=re.search(r'    matches!\(c,.*',old).group(0) if False else old[old.index("    matches!(c, ':'"):old.index('\n}',old.index("    matches!(c, ':'"))]
text=prefix+'''/// XML edition used to validate names, including names in DTDs and references.
///
/// The C interface selects Fourth Edition rules to match Expat. Other XML
/// productions and resource limits are unchanged by this setting.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub enum NameRules {
    /// The broader XML 1.0 Fifth Edition name productions.
    #[default]
    FifthEdition,
    /// The XML 1.0 Fourth Edition character classes used by Expat.
    FourthEdition,
}

impl NameRules {
    #[inline]
    pub(crate) fn is_name_start(self, c: char) -> bool {
        if c.is_ascii() {
            return c.is_ascii_alphabetic() || matches!(c, ':' | '_');
        }
        match self {
            Self::FifthEdition => fifth_name_start(c),
            Self::FourthEdition => in_ranges(c, FOURTH_START),
        }
    }

    #[inline]
    pub(crate) fn is_name_char(self, c: char) -> bool {
        if c.is_ascii() {
            return c.is_ascii_alphanumeric() || matches!(c, ':' | '_' | '-' | '.');
        }
        self.is_name_start(c) || match self {
            Self::FifthEdition => matches!(c, '\\u{b7}' | '\\u{300}'..='\\u{36f}' | '\\u{203f}'..='\\u{2040}'),
            Self::FourthEdition => in_ranges(c, FOURTH_EXTRA),
        }
    }

    pub(crate) fn is_name(self, name: &str) -> bool {
        let mut chars = name.chars();
        chars.next().is_some_and(|c| self.is_name_start(c))
            && chars.all(|c| self.is_name_char(c))
    }

    /// Namespace-qualified names allow one colon between two nonempty XML names.
    pub(crate) fn is_qname(self, name: &str) -> bool {
        if let Some((prefix, local)) = name.split_once(':') {
            self.is_name(prefix) && self.is_name(local) && !local.contains(':')
        } else {
            self.is_name(name)
        }
    }
}

#[inline]
fn fifth_name_start(c: char) -> bool {
'''+fifth_start+'''
}

fn in_ranges(c: char, ranges: &[(u16, u16)]) -> bool {
    let Ok(value) = u16::try_from(u32::from(c)) else { return false; };
    let index = ranges.partition_point(|&(_, end)| end < value);
    ranges.get(index).is_some_and(|&(start, _)| start <= value)
}

// XML 1.0 Fourth Edition productions [84]–[89], merged into disjoint ranges.
// https://www.w3.org/TR/2006/REC-xml-20060816/#CharClasses
// ASCII characters are handled above. Start = BaseChar | Ideographic;
// Extra = Digit | CombiningChar | Extender.
'''
for name,ranges in [('FOURTH_START',start),('FOURTH_EXTRA',extra)]:
 text+=f'const {name}: &[(u16, u16)] = &[\n'
 text+=''.join(f'    (0x{a:04x}, 0x{b:04x}),\n' for a,b in ranges)
 text+='];\n'
(root/'crates/oriole/src/names.rs').write_text(text)

def lib(t):
 t=t.replace('use names::{is_name, is_uri_char, is_xml_char, whitespace};','use names::{is_uri_char, is_xml_char, whitespace};\npub use names::NameRules;')
 t=t.replace('pub struct Config {','pub struct Config {\n    /// XML edition used for all names. Defaults to Fifth Edition.\n    pub name_rules: NameRules,')
 t=t.replace('Source::new(allocator)', 'Source::new(allocator, config.name_rules)')
 t=t.replace('Source::entity(value, name, position, self.stack.len())','Source::entity(value, name, position, self.stack.len(), self.config.name_rules)')
 # Parser methods only; free helpers separately.
 end=t.index('fn take_name(');a,b=t[:end],t[end:]
 a=a.replace('names::is_name_start(', 'self.config.name_rules.is_name_start(')
 a=re.sub(r'(?<![\w.:])is_name\(', 'self.config.name_rules.is_name(',a)
 a=a.replace('take_name(body)', 'take_name(body, self.config.name_rules)')
 a=a.replace('parse_raw_attributes(rest, false, self.allocator, 3)', 'parse_raw_attributes(rest, false, self.allocator, 3, self.config.name_rules)')
 a=a.replace('self.config.limits.max_attributes,\n        )','self.config.limits.max_attributes,\n            self.config.name_rules,\n        )')
 b=b.replace('fn take_name(input: &str)', 'fn take_name(input: &str, name_rules: NameRules)')
 b=b.replace('names::is_name_start(', 'name_rules.is_name_start(').replace('names::is_name_char(', 'name_rules.is_name_char(')
 b=b.replace('    limit: usize,\n)', '    limit: usize,\n    name_rules: NameRules,\n)')
 b=b.replace('take_name(text)', 'take_name(text, name_rules)')
 return a+b
edit('crates/oriole/src/lib.rs',lib)
def encoding(t):
 t=t.replace('    deferred_size: usize,','    deferred_size: usize,\n    name_rules: crate::NameRules,')
 t=t.replace('pub(crate) fn new(allocator: Allocator)', 'pub(crate) fn new(allocator: Allocator, name_rules: crate::NameRules)')
 t=t.replace('            deferred_size: 0,','            deferred_size: 0,\n            name_rules,')
 t=t.replace('        initial_depth: usize,\n    )','        initial_depth: usize,\n        name_rules: crate::NameRules,\n    )')
 t=t.replace('Self::new(allocator)', 'Self::new(allocator, name_rules)')
 t=t.replace('crate::names::is_name_start(', 'self.name_rules.is_name_start(').replace('crate::names::is_name_char(', 'self.name_rules.is_name_char(')
 return t
edit('crates/oriole/src/encoding.rs',encoding)
def dtd(t):
 end=t.index('fn invalid_dtd_token(');a,b=t[:end],t[end:]
 a=a.replace('take_name(&token[2..])','take_name(&token[2..], self.config.name_rules)')
 a=a.replace('crate::names::is_name_start(', 'self.config.name_rules.is_name_start(').replace('crate::names::is_name(', 'self.config.name_rules.is_name(')
 a=a.replace('self.config.namespace_separator.is_some(),\n        )','self.config.namespace_separator.is_some(),\n            self.config.name_rules,\n        )')
 a=a.replace('self.config.namespace_separator.is_some());','self.config.namespace_separator.is_some(), self.config.name_rules);')
 a=a.replace('Source::entity(value, source_name, position, self.stack.len())','Source::entity(value, source_name, position, self.stack.len(), self.config.name_rules)')
 a=a.replace('invalid_dtd_token(cursor.rest(), cursor.namespaces)','invalid_dtd_token(cursor.rest(), cursor.namespaces, cursor.name_rules)')
 b=b.replace('fn invalid_dtd_token(text: &str, namespaces: bool)','fn invalid_dtd_token(text: &str, namespaces: bool, name_rules: crate::NameRules)')
 end=b.index('struct Cursor');b1,b2=b[:end],b[end:]
 b1=b1.replace('crate::names::', 'name_rules.')
 b2=b2.replace('    namespaces: bool,','    namespaces: bool,\n    name_rules: crate::NameRules,',1)
 b2=b2.replace("fn new(text: &'a str, namespaces: bool)","fn new(text: &'a str, namespaces: bool, name_rules: crate::NameRules)")
 b2=b2.replace('            namespaces,','            namespaces,\n            name_rules,',1)
 b2=b2.replace('take_name(self.text)', 'take_name(self.text, self.name_rules)').replace('crate::names::is_qname(', 'self.name_rules.is_qname(')
 b2=b2.replace('crate::names::is_name_char(', 'cursor.name_rules.is_name_char(')
 return a+b1+b2
edit('crates/oriole/src/dtd.rs',dtd)
def composition(t):
 t=t.replace('crate::names::is_name(', 'self.config.name_rules.is_name(')
 t=t.replace('Source::entity(value, source_name, position, self.stack.len())','Source::entity(value, source_name, position, self.stack.len(), self.config.name_rules)')
 t=t.replace('                        self.stack.len(),\n                    );','                        self.stack.len(),\n                        self.config.name_rules,\n                    );')
 t=t.replace('            self.stack.len(),\n        );','            self.stack.len(),\n            self.config.name_rules,\n        );')
 return t
edit('crates/oriole/src/dtd/composition.rs',composition)
def grammar(t):
 t=t.replace('    namespaces: bool,','    namespaces: bool,\n    name_rules: crate::NameRules,',1)
 t=t.replace('pub(crate) fn new(allocator: Allocator, namespaces: bool, max_depth: usize)', 'pub(crate) fn new(allocator: Allocator, namespaces: bool, max_depth: usize, name_rules: crate::NameRules)')
 t=t.replace('            namespaces,','            namespaces,\n            name_rules,',1)
 t=t.replace('names::is_name(', 'self.name_rules.is_name(').replace('names::is_qname(', 'self.name_rules.is_qname(').replace('names::is_name_char(', 'self.name_rules.is_name_char(')
 t=t.replace('super::invalid_dtd_token(rest, self.namespaces)','super::invalid_dtd_token(rest, self.namespaces, self.name_rules)')
 t=re.sub(r'Cursor::new\(Allocator::System, (true|false), (64|depth)\)',r'Cursor::new(Allocator::System, \1, \2, crate::NameRules::default())',t)
 return t
edit('crates/oriole/src/dtd/grammar.rs',grammar)
edit('crates/oriole/src/dtd/semantic.rs',lambda t:t.replace('                parser.config.limits.max_depth,','                parser.config.limits.max_depth,\n                parser.config.name_rules,').replace('            self.config.namespace_separator.is_some(),\n        );','            self.config.namespace_separator.is_some(),\n            self.config.name_rules,\n        );'))
edit('crates/oriole/src/value.rs',lambda t:t.replace('ValueScanner::new()', 'ValueScanner::new(self.config.name_rules)').replace('crate::names::is_name(', 'self.config.name_rules.is_name('))
def lexer(t):
 t=t.replace('use crate::names::{is_name_char, is_name_start, is_xml_char, whitespace};','use crate::names::{NameRules, is_xml_char, whitespace};')
 t=t.replace('    cursor: usize,','    cursor: usize,\n    name_rules: NameRules,',1)
 t=t.replace('pub(crate) fn new()', 'pub(crate) fn new(name_rules: NameRules)')
 t=t.replace('            cursor: 0,','            cursor: 0,\n            name_rules,',1)
 t=t.replace('        while let Some(character)', '        let name_rules = self.name_rules;\n        while let Some(character)',1)
 t=re.sub(r'(?<![\w.:])is_name_char\(', 'name_rules.is_name_char(',t)
 t=re.sub(r'(?<![\w.:])is_name_start\(', 'name_rules.is_name_start(',t)
 t=re.sub(r'(?<!fn )(name_start|name_char|declaration_name)\(([^,()]+), namespaces\)',r'\1(\2, namespaces, name_rules)',t)
 t=t.replace('character: char, namespaces: bool)', 'character: char, namespaces: bool, name_rules: NameRules)')
 t=t.replace('ValueScanner::new()', 'ValueScanner::new(NameRules::default())')
 return t
edit('crates/oriole/src/value_lexer.rs',lexer)
edit('crates/oriole_expat/src/lib.rs',lambda t:t.replace('use oriole::{Config, ErrorKind, EventKind, Parser, Position};','use oriole::{Config, ErrorKind, EventKind, NameRules, Parser, Position};').replace('                namespace_separator: separator,','                namespace_separator: separator,\n                name_rules: NameRules::FourthEdition,'))
