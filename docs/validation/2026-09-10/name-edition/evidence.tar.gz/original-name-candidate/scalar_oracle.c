#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static unsigned encode(uint32_t c, char *s) {
  if(c < 0x80) {s[0]=(char)c; return 1;}
  if(c < 0x800) {s[0]=(char)(0xc0|(c>>6));s[1]=(char)(0x80|(c&63));return 2;}
  if(c < 0x10000) {s[0]=(char)(0xe0|(c>>12));s[1]=(char)(0x80|((c>>6)&63));s[2]=(char)(0x80|(c&63));return 3;}
  s[0]=(char)(0xf0|(c>>18));s[1]=(char)(0x80|((c>>12)&63));s[2]=(char)(0x80|((c>>6)&63));s[3]=(char)(0x80|(c&63));return 4;
}
int main(int argc, char **argv) {
  if(argc!=3) return 2;
  void *lib=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL);if(!lib){fputs(dlerror(),stderr);return 2;}
  void *(*create)(const char *)=dlsym(lib,"XML_ParserCreate");
  unsigned char (*reset)(void *,const char *)=dlsym(lib,"XML_ParserReset");
  int (*parse)(void *,const char *,int,int)=dlsym(lib,"XML_Parse");
  int (*error)(void *)=dlsym(lib,"XML_GetErrorCode");
  void (*release)(void *)=dlsym(lib,"XML_ParserFree");
  if(!create||!reset||!parse||!error||!release)return 2;
  FILE *out=fopen(argv[2],"wb"); if(!out)return 2;
  void *p=create(NULL); if(!p)return 2;
  uint64_t accepted[2]={0,0},errors[64]={0};
  clock_t started=clock();
  for(uint32_t c=0x80;c<=0x10ffff;c++) {
    unsigned char result=0;
    if(c<0xd800||c>0xdfff) {
      for(unsigned pos=0;pos<2;pos++) {
        if(!reset(p,NULL))return 2;
        char xml[16]={'<','a'};unsigned n=1+pos;n+=encode(c,xml+n);xml[n++]='/';xml[n++]='>';
        int status=parse(p,xml,n,1);int e=error(p);
        if(status==1){result|=(1<<pos);accepted[pos]++;}
        else if(e>=0&&e<64)errors[e]++; else return 2;
      }
    }
    if(fwrite(&result,1,1,out)!=1)return 2;
  }
  release(p);fclose(out);dlclose(lib);
  printf("{\"scalar_range\": [128,1114111], \"surrogates_skipped\":true, \"start_accepted\":%llu,\"continuation_accepted\":%llu,\"cpu_seconds\":%.6f,\"errors\":{",(unsigned long long)accepted[0],(unsigned long long)accepted[1],(double)(clock()-started)/CLOCKS_PER_SEC);
  int first=1;for(int i=0;i<64;i++)if(errors[i]){printf("%s\"%d\":%llu",first?"":",",i,(unsigned long long)errors[i]);first=0;}puts("}}");
}
