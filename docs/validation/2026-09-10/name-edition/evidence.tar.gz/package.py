from pathlib import Path
import gzip,hashlib,io,json,re,statistics,tarfile
source=Path('/tmp/oriole-name-final');repo=Path('/home/dev-user/code/oss/oriole-api-followup');out=repo/'docs/validation/2026-09-10/name-edition';out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();entries={}
def tree(prefix,root,suffixes):
 for p in sorted(root.rglob('*')):
  if p.is_file() and not p.is_symlink() and p.suffix in suffixes:entries[prefix+str(p.relative_to(root))]=p.read_bytes()
tree('',source,['.json','.log','.py','.patch','.bin','.c','.h'])
tree('baseline-upstream/',Path('/tmp/oriole-custom-final/upstream-complete'),['.json','.log','.c','.h'])
original=Path('/tmp/oriole-name-compatibility')
for name in ['HANDOFF.md','base.json','candidate.patch','source.json','source.tar.gz','validation.json','xml4-character-classes.json','implement.py','context-oracle.json','context_oracle.py','scalar_oracle.c','expat-scalars.json','oriole-scalars.json']:
 entries['original-name-candidate/'+name]=(original/name).read_bytes()
preview=Path('/tmp/oriole-name-integration-preview')
for name in ['apply.log','resolve.py']:entries['integration-preview/'+name]=(preview/name).read_bytes()
for p in preview.rglob('*.rej'):entries['integration-preview/'+str(p.relative_to(preview))]=p.read_bytes()
entries['independent-review.json']=Path('/tmp/oriole-name-edition-independent-review.json').read_bytes()
freeze=json.loads((source/'source.json').read_text())
for name,digest in freeze.items():
 data=(repo/name).read_bytes();assert sha(data)==digest,name;entries['frozen-source/'+name]=data
for name in ['tests/c/integration.c','tests/c/adversarial.c','tests/c/allocations.c','tools/differential.py','tools/upstream-expat/run.py']:entries['runners/'+name]=(repo/name).read_bytes()
files=[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(entries.items())]
(out/'files.json').write_text(json.dumps(files,indent=2)+'\n')
with (out/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
screen=json.loads((source/'screen/screening.json').read_text());assert screen['status']=='passed';rows=[]
for chunk in [4096,65536]:
 for name in dict.fromkeys(r['workload'] for r in screen['rows']):
  rates=[r['speedup'] for r in screen['rows'] if r['workload']==name and r['chunk']==chunk];rows.append({'chunk':chunk,'workload':name,'median_candidate_speedup':statistics.median(rates),'minimum':min(rates),'maximum':max(rates)})
checks=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(source/'tests.log').read_text())));assert checks==273
native=json.loads((source/'native/report.json').read_text());assert native['status']=='passed'
api=json.loads((source/'api-comparison.json').read_text());assert len(api['changes'])==18 and all(r['before']['outcome']=='fail' and r['after']['outcome']=='pass' for r in api['changes'])
ordinary=json.loads((source/'differential/summary.json').read_text());assert ordinary['exact_pass'] and ordinary['cases']==3918
context=json.loads((source/'context-oracle.json').read_text());assert context['differences']==json.loads((original/'context-oracle.json').read_text())['differences']
public=json.loads((source/'public-oracle.json').read_text());assert public['candidate_acceptance_error_differences']==0
report={'source_commit':'983f699c40e83315915582ce5b9fca6873a8c41e','base_commit':'261a7c1','original_patch_sha256':sha((original/'candidate.patch').read_bytes()),'shared_sha256':sha((source/'liboriole_expat.so').read_bytes()),'static_sha256':sha((source/'liboriole_expat.a').read_bytes()),'checks':{'rust_tests':checks,'strict_clippy':'passed','rustfmt':'applied; all formatted sources pass strict Clippy and release build','streaming_fuzz_target_compile_check':'passed; no runtime fuzz campaign claimed','native_suites':6,'native_allocation_scenarios_per_linkage':333,'native_scope':native['scope'],'ordinary_differential_cases':3918,'ordinary_differential_exact':'passed'},'upstream':api,'upstream_scope_note':'test_utf8_in_start_tags skips its original body with deferral enabled; these six existing pass results are preserved and are not counted as new evidence. Independent scalar/context oracles do not skip.','scalar_oracle':json.loads((source/'scalar-comparison.json').read_text()),'context_oracle':{k:v for k,v in context.items() if k!='differences'},'context_differences':'Exactly the same 180 preexisting missing-parameter-entity acceptance/error/callback differences as the original NameRules candidate. The separate missing-PE fix is not included.','custom_public_oracle':{k:v for k,v in public.items() if k!='rows'},'custom_public_scope':'72 conditions cover original bytes @^, map @=-2 and ^=U+200C/U+00B7/U+E000, converter result A, four DTD contexts including external children, namespaces on/off, whole/one/seven-byte feeds. Acceptance and error codes match Expat; converter callback counts are retained separately without claiming exact callback timing.','screening_scope':screen['scope'],'screening':rows,'independent_review':json.loads(entries['independent-review.json']),'propagation_audit':'propagation-audit.json in evidence archive enumerates lexical predicate sites and Config/Source/DTD/value/child propagation.','known_limits':['675 configurations still fail in the complete upstream API assertion matrix; this layer claims exactly 18 improvements and no other disposition changes.','Core FifthEdition defaults intentionally accept broader names than the C FourthEdition default.','Missing parameter entity behavior, direct/shared budgets, and iterative attribute expansion remain separate follow-up layers.','Resource limits and allocation contracts are unchanged. Performance screening is against the preceding Oriole custom-provenance library, not Expat.'],'artifacts':{'files':len(files),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes())}}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(len(files),'files',len((out/'evidence.tar.gz').read_bytes()),'archive bytes')
