"""Check original-byte PUBLIC-ID classification under Expat's name edition."""
import ctypes as c
import hashlib,json,sys
from pathlib import Path
assert not any(line.rsplit('/',1)[-1].startswith('libexpat.') for line in Path('/proc/self/maps').read_text().splitlines())
CONVERT=c.CFUNCTYPE(c.c_int,c.c_void_p,c.c_void_p)
RELEASE=c.CFUNCTYPE(None,c.c_void_p)
class Encoding(c.Structure):
 _fields_=[('map',c.c_int*256),('data',c.c_void_p),('convert',c.c_void_p),('release',c.c_void_p)]
UNKNOWN=c.CFUNCTYPE(c.c_int,c.c_void_p,c.c_char_p,c.POINTER(Encoding))
def setup(path):
 lib=c.CDLL(path)
 for name,args,result in [('XML_ParserCreate',[c.c_char_p],c.c_void_p),('XML_ParserCreateNS',[c.c_char_p,c.c_char],c.c_void_p),('XML_ExternalEntityParserCreate',[c.c_void_p,c.c_char_p,c.c_char_p],c.c_void_p),('XML_ParserReset',[c.c_void_p,c.c_char_p],c.c_ubyte),('XML_SetUnknownEncodingHandler',[c.c_void_p,UNKNOWN,c.c_void_p],None),('XML_Parse',[c.c_void_p,c.c_char_p,c.c_int,c.c_int],c.c_int),('XML_GetErrorCode',[c.c_void_p],c.c_int),('XML_ParserFree',[c.c_void_p],None)]:
  f=getattr(lib,name);f.argtypes=args;f.restype=result
 return lib

def parse(lib,data,width,namespaces,child,mapped):
 calls=[];releases=[]
 @CONVERT
 def convert(_,raw):
  sequence=c.string_at(raw,2);calls.append(sequence.hex());assert sequence==b'@^';return ord('A')
 @RELEASE
 def release(_):releases.append(True)
 @UNKNOWN
 def unknown(_,name,out):
  for index in range(256):out.contents.map[index]=index
  out.contents.map[ord('@')]=-2;out.contents.map[ord('^')]=mapped
  out.contents.convert=c.cast(convert,c.c_void_p).value;out.contents.release=c.cast(release,c.c_void_p).value;return 1
 parent=lib.XML_ParserCreateNS(b'custom',b'|') if namespaces else lib.XML_ParserCreate(b'custom');assert parent
 p=lib.XML_ExternalEntityParserCreate(parent,None,b'custom') if child else parent;assert p
 lib.XML_SetUnknownEncodingHandler(p,unknown,None)
 width=width or len(data);status=1
 for offset in range(0,len(data),width):
  piece=data[offset:offset+width];status=lib.XML_Parse(p,piece,len(piece),int(offset+width>=len(data)))
  if status!=1:break
 result={'status':status,'error':lib.XML_GetErrorCode(p),'conversions':calls}
 lib.XML_ParserFree(p)
 if child:lib.XML_ParserFree(parent)
 result['releases']=len(releases);assert len(releases)==1
 return result
paths={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','baseline':'/tmp/oriole-custom-final/liboriole_expat.so','candidate':sys.argv[1]};libs={key:setup(path) for key,path in paths.items()}
rows=[]
for mapped in [0x200c,0xb7,0xe000]:
 for context,data,child in [('doctype',b"<!DOCTYPE r PUBLIC '@^' 's'><r/>",False),('notation',b"<!DOCTYPE r [<!NOTATION n PUBLIC '@^'>]><r/>",False),('entity',b"<!DOCTYPE r [<!ENTITY e PUBLIC '@^' 's'>]><r/>",False),('external-dtd',b"<!NOTATION n PUBLIC '@^'>",True)]:
  for width in [0,1,7]:
   for namespaces in [False,True]:
    result={key:parse(lib,data,width,namespaces,child,mapped) for key,lib in libs.items()}
    rows.append({'map':{'64':-2,'94':mapped},'converted':'A','input_hex':data.hex(),'context':context,'chunk':width,'namespaces':namespaces,'results':result})
report={'python':sys.executable,'libraries':{key:{'path':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()} for key,path in paths.items()},'cases':len(rows),'rows':rows}
report['candidate_acceptance_error_differences']=sum((r['results']['reference']['status'],r['results']['reference']['error'])!=(r['results']['candidate']['status'],r['results']['candidate']['error']) for r in rows)
report['baseline_acceptance_error_differences']=sum((r['results']['reference']['status'],r['results']['reference']['error'])!=(r['results']['baseline']['status'],r['results']['baseline']['error']) for r in rows)
Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ['rows','libraries']})
assert report['candidate_acceptance_error_differences']==0
