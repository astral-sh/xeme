import hashlib,json,shutil,subprocess
from pathlib import Path
root=Path.cwd();out=Path('/tmp/oriole-attribute-throughput/final');out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['liboriole_expat.so','liboriole_expat.a']:shutil.copy2(Path('/home/dev-user/.cache/oriole/target/release')/n,out/n)
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff','HEAD']))
inputs=set([*root.glob('crates/**/*.rs'),*root.glob('crates/*/Cargo.toml'),root/'Cargo.toml',root/'Cargo.lock'])
report={'parent_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':{str(p.relative_to(root)):sha(p) for p in sorted(inputs)},'library_sha256':{p.name:sha(p) for p in out.glob('lib*')},'toolchain':subprocess.check_output(['rustc','+ohm','-Vv'],text=True),'build_command':['cargo','+ohm','build','--release','--locked','--offline','-p','oriole_expat'],'environment':{'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/target','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST':'all','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all','CARGO_BUILD_JOBS':'1'}}
(out/'source.json').write_text(json.dumps(report,indent=2)+'\n');print(report['library_sha256'])
