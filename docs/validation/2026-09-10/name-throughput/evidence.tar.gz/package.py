from pathlib import Path
import hashlib,json,tarfile,re,shutil,statistics
root=Path('/home/dev-user/code/oss/oriole');work=Path('/tmp/oriole-attribute-throughput');dest=root/'docs/validation/2026-09-10/name-throughput'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((work/'final-native/summary.json').read_text());assert report['status']=='passed'
diff=json.loads((work/'final-differential/summary.json').read_text());assert diff['exact_pass']
log=(work/'final-tests.log').read_text();assert 'Doc-tests oriole_expat' in log and 'FAILED' not in log
count=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',log)))
native=json.loads((work/'final/native.json').read_text());assert len(native['runs'])==6 and all(x['returncode']==0 for x in native['runs'])
reviews=work/'reviews';reviews.mkdir(exist_ok=True)
for name in ['oriole-name-lifetime-independent-review.json','oriole-namespace-skip-independent-review.json','oriole-namespace-skip-review.py']:
 shutil.copy2(Path('/tmp')/name,reviews/name)
source=json.loads((work/'final/source.json').read_text());(work/'final/native-source.json').write_text(json.dumps({str(p.relative_to(root)):sha(p) for p in [root/'include/expat.h',*root.glob('tests/c/*.c')]},indent=2)+'\n')
summary={'libraries':source['library_sha256'],'core_ffi_tests':count,'exact_differential':{'cases':diff['cases'],'exact_pass':diff['exact_pass'],'difference_counts':diff['difference_counts']},'native_runs':len(native['runs']),'allocation_scenarios_per_linkage':332,'native_project_preflights':len(report['preflights']),'native_project_timed_processes':len(report['rows']),'project_results':{k:{'median_seconds':v['median_seconds'],'median_expat_over_oriole':v['median_expat_over_oriole']}for k,v in report['summary'].items()},'equal_project_slowdown':{f'{chunk}/{ns}':1/statistics.geometric_mean(v['median_expat_over_oriole'] for k,v in report['summary'].items() if k.endswith(f'/{chunk}/namespaces-{ns}'))for chunk in [4096,65536] for ns in [0,1]},'discarded':['quoted-attribute memchr scan: mixed/regressed ordinary workload timings','raw-attribute offset scratch: held for later combined recycling measurement; not included in this runtime']}
dest.mkdir(parents=True,exist_ok=True);(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for p in sorted(work.rglob('*')):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 files[str(p.relative_to(work))]={'sha256':sha(p),'bytes':p.stat().st_size}
archive=dest/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for n in files:tar.add(work/n,arcname=n,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for m in tar:
  assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==files[m.name]['sha256']
manifest={'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':files};(dest/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
rows=[]
for name in sorted({k.split('/')[0] for k in report['summary']}):
 v=report['summary'][f'{name}/4096/namespaces-0'];m=v['median_seconds'];rows.append(f"| {name} | {1000*m['oriole']:.3f} | {1000*m['expat']:.3f} | {v['median_expat_over_oriole']:.3f}× |")
readme=f'''# XML name throughput and namespace compatibility

We retain unprefixed attribute names without expanding or hashing them again, store one element name when its raw and expanded spellings agree, and validate names in one pass. All end-event names remain owned. Unprefixed names may equal another attribute's serialized namespace name; prefixed-name collisions retain Expat's behavior. A NUL separator now ignores triplet mode, matching Expat.

The quoted-value scanning experiment regressed ordinary workloads and is excluded. Raw-attribute offset scratch is also excluded pending measurement with the next storage-recycling layer. Their exact patches, binaries' provenance and timing samples remain in the evidence archive.

## Measurements

Seven randomized process pairs measure twenty parses after a warmup on each of six original project inputs, both namespace modes and 4/64 KiB feeds. All 24 complete normalized callback preflights and 336 timed processes pass. Creation, callbacks, parsing and free are timed; file/library loading and process startup are excluded. Shared-host CPU frequency and other-CPU load remain uncontrolled. These are parser workloads, not complete project builds.

The final shared library is `{source['library_sha256']['liboriole_expat.so']}`; the static archive is `{source['library_sha256']['liboriole_expat.a']}`. Pinned Expat 2.8.4 remains the reference.

At 4 KiB with namespaces disabled:

| Project | Oriole ms | Expat ms | Expat / Oriole |
| --- | ---: | ---: | ---: |
{chr(10).join(rows)}

The equal-project geometric mean remains {summary['equal_project_slowdown']['4096/0']:.2f}× slower without namespaces and {summary['equal_project_slowdown']['4096/1']:.2f}× slower with namespaces at 4 KiB; at 64 KiB the gaps are {summary['equal_project_slowdown']['65536/0']:.2f}× and {summary['equal_project_slowdown']['65536/1']:.2f}×. Paired screening against the preceding runtime shows roughly 3–11% throughput improvement without namespaces and 4–15% with namespaces; the complete final comparison above remains slower than Expat on every project. The performance goal is unfinished.

## Validation

All {count} core/C-adapter Rust tests pass, including selected-allocation failures. Formatting and strict Clippy pass. All {diff['cases']:,} generated differential configurations match the preceding runtime exactly; the separate 84-case namespace probe matches pinned Expat, including the newly corrected cases. Shared/static C integration, adversarial and allocation-failure suites pass under ASan/UBSan, with 332 injected failures per linkage. The Rust library is uninstrumented in those C runs; leak detection is disabled and explicit allocation live counts are checked.

Independent name-lifetime and namespace reviews found no issues. A Callgrind instruction profile is included for further work; it is not hardware sampling or wall-clock evidence.

[evidence.tar.gz](evidence.tar.gz) contains raw checks, benchmark results, discarded experiments, source/build metadata and reviews, excluding ELF executables and static archives. [files.json](files.json) verifies every archived member; [summary.json](summary.json) provides compact results. Archive SHA256: `{manifest['archive_sha256']}`.
'''
(dest/'README.md').write_text(readme)
print(json.dumps({'tests':count,'archive_sha256':manifest['archive_sha256'],'archive_bytes':manifest['archive_bytes'],'members':len(files),'geometric_slowdown':summary['equal_project_slowdown']},indent=2))
