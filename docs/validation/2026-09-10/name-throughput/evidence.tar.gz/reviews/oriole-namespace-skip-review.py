import ctypes as c
import hashlib
import json
import sys
from pathlib import Path
sys.path.insert(0, '/tmp/oriole-real-project-bench/tools')
from xml_abi import Expat, START, END, decode
libraries = {'expat': '/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4'}
if len(sys.argv) > 1:
    libraries['candidate'] = sys.argv[1]
fixtures = {
    'default_namespace': ('|', '<r xmlns="u" a="1"/>'),
    'unicode_name': ('|', '<r é="1"/>'),
    'raw_duplicate': ('|', '<r a="1" a="2"/>'),
    'default_override': ('|', '<!DOCTYPE r [<!ATTLIST r a CDATA "default">]><r a="explicit"/>'),
    'default_unprefixed_collision': ('x', '<!DOCTYPE r [<!ATTLIST r axb CDATA "default">]><r xmlns:p="a" p:b="1"/>'),
    'prefixed_unprefixed': ('x', '<r xmlns:p="a" p:b="1" axb="2"/>'),
    'unprefixed_prefixed': ('x', '<r xmlns:p="a" axb="2" p:b="1"/>'),
    'two_prefixed_collision': ('x', '<r xmlns:p="ax" xmlns:q="a" p:b="1" q:xb="2"/>'),
    'nul_prefixed_unprefixed': ('\0', '<r xmlns:p="a" p:b="1" ab="2"/>'),
    'nul_two_prefixed_collision': ('\0', '<r xmlns:p="ab" xmlns:q="a" p:c="1" q:bc="2"/>'),
    'undefined_prefix': ('|', '<r p:a="1"/>'),
    'malformed_colons': ('|', '<r a:b:c="1"/>'),
    'malformed_unprefixed': ('|', '<r 1a="1"/>'),
    'reserved_xml': ('|', '<r xml:lang="en"/>'),
}
rows=[]
for engine, library in libraries.items():
    binding=Expat(library); lib=binding.lib
    lib.XML_SetReturnNSTriplet.argtypes=[c.c_void_p,c.c_int]
    lib.XML_SetReturnNSTriplet.restype=None
    for fixture, (separator, source) in fixtures.items():
        data=source.encode()
        for triplets in (0,1):
            for chunk in (1,7,len(data)):
                events=[]
                def start(_, name, attrs):
                    pairs=[]; i=0
                    while attrs[i] is not None:
                        pairs.append([decode(attrs[i]),decode(attrs[i+1])]);i+=2
                    events.append(['start',decode(name),pairs])
                callbacks=[START(start),END(lambda _, name: events.append(['end',decode(name)]))]
                parser=lib.XML_ParserCreateNS(None,separator.encode())
                lib.XML_SetReturnNSTriplet(parser,triplets)
                lib.XML_SetElementHandler(parser,*callbacks)
                for offset in range(0,len(data),chunk):
                    part=data[offset:offset+chunk]
                    status=lib.XML_Parse(parser,part,len(part),int(offset+chunk>=len(data)))
                    if status != 1:break
                rows.append({'engine':engine,'fixture':fixture,'input':source,'separator':separator,'triplets':triplets,'chunk':chunk,'status':status,'error':lib.XML_GetErrorCode(parser),'events':events})
                lib.XML_ParserFree(parser)
report={'command':['taskset','-c','7','python',str(Path(__file__).resolve()),*sys.argv[1:]],'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'libraries':{name:{'path':value,'sha256':hashlib.sha256(Path(value).read_bytes()).hexdigest()}for name,value in libraries.items()},'rows':rows}
print(json.dumps(report,indent=2))
