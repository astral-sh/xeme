from pathlib import Path
import hashlib,json
source=Path('/tmp/oriole-separators-oracle.py').read_text();ns={};exec(source[:source.index('\nrows = []')],ns)
probe,libs=ns['probe'],ns['libs'];rows=[]
for sep in [0,9,10,13,32,37,38,58,93,124,127]:
 for encoding in ['utf-8','utf-16le','utf-16be']:
  for width in [0,1,3]:
   for triplets in [False,True]:
    if sep==0 and triplets:continue
    doc=(f'<!DOCTYPE p:r [<!ENTITY u "urn:é&#{sep};水">]><p:r xmlns:p="&u;" p:a="1"/>').encode(encoding)
    if encoding!='utf-8':doc=(b'\xff\xfe'if encoding=='utf-16le'else b'\xfe\xff')+doc
    rows.append(dict(separator=sep,encoding=encoding,width=width,triplets=triplets,document_hex=doc.hex(),reference=probe(libs[0],sep,triplets,doc,width),candidate=probe(libs[2],sep,triplets,doc,width)))
p=Path('/tmp/oriole-separators-independent.json');p.write_text(json.dumps(dict(libraries={x:hashlib.sha256(Path(x).read_bytes()).hexdigest()for x in ns['paths']},cases=len(rows),differences=sum(r['reference']!=r['candidate']for r in rows),rows=rows),indent=2)+'\n');print(len(rows),sum(r['reference']!=r['candidate']for r in rows))
