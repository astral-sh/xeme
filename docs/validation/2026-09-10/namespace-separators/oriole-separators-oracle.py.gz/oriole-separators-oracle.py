import ctypes as c
import hashlib
import json
from pathlib import Path

P, S, I = c.c_void_p, c.c_char_p, c.c_int
START = c.CFUNCTYPE(None, P, S, c.POINTER(S))
NS = c.CFUNCTYPE(None, P, S, S)
paths = ['/home/dev-user/.cache/oriole/expat-build/libexpat.so', '/tmp/oriole-content-combined.so', '/tmp/oriole-separators.so']
libs = []
for path in paths:
    lib = c.CDLL(path)
    for name, result, args in [
        ('XML_ParserCreateNS', P, [S, c.c_char]),
        ('XML_ParserFree', None, [P]),
        ('XML_Parse', I, [P, P, I, I]),
        ('XML_GetErrorCode', I, [P]),
        ('XML_SetStartElementHandler', None, [P, START]),
        ('XML_SetStartNamespaceDeclHandler', None, [P, NS]),
        ('XML_SetReturnNSTriplet', None, [P, I]),
    ]:
        fn = getattr(lib, name)
        fn.restype, fn.argtypes = result, args
    libs.append(lib)


def probe(lib, sep, triplets, document, width):
    parser = lib.XML_ParserCreateNS(None, bytes([sep]))
    assert parser
    events = []
    @START
    def start(_, name, attrs):
        pairs = []
        i = 0
        while attrs[i]:
            pairs.append([attrs[i].decode(), attrs[i + 1].decode()])
            i += 2
        events.append(['start', name.decode(), pairs])
    @NS
    def namespace(_, prefix, uri):
        events.append(['ns', prefix.decode() if prefix else None, uri.decode() if uri else None])
    try:
        lib.XML_SetStartElementHandler(parser, start)
        lib.XML_SetStartNamespaceDeclHandler(parser, namespace)
        if triplets:
            lib.XML_SetReturnNSTriplet(parser, 1)
        chunks = [document] if not width else [document[i:i + width] for i in range(0, len(document), width)]
        for index, chunk in enumerate(chunks):
            status = lib.XML_Parse(parser, chunk, len(chunk), int(index + 1 == len(chunks)))
            if not status:
                break
        return {'status': status, 'error': lib.XML_GetErrorCode(parser), 'events': events}
    finally:
        lib.XML_ParserFree(parser)

rows = []
for sep in range(128):
    for triplets in [False, True]:
        if sep == 0 and triplets:
            continue  # Existing advertised constructor boundary; no new claim.
        for form in ['default', 'prefix', 'defaulted', 'absent']:
            uri = 'urn:a&#' + str(sep) + ';b' if form != 'absent' else 'urn:example'
            document = (
                f'<r xmlns="{uri}"/>' if form == 'default' else
                f'<!DOCTYPE p:r [<!ATTLIST p:r xmlns:p CDATA "{uri}">]><p:r p:a="1"/>' if form == 'defaulted' else
                f'<p:r xmlns:p="{uri}" p:a="1"/>'
            ).encode()
            for width in [0, 1, 7]:
                row = {'separator': sep, 'triplets': triplets, 'form': form, 'width': width, 'xml': document.decode()}
                for label, lib in zip(['reference', 'baseline', 'candidate'], libs):
                    row[label] = probe(lib, sep, triplets, document, width)
                rows.append(row)
report = {
    'libraries': {path: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in paths},
    'cases': len(rows),
    'baseline_differences': sum(r['baseline'] != r['reference'] for r in rows),
    'candidate_differences': sum(r['candidate'] != r['reference'] for r in rows),
    'regressions': sum(r['baseline'] == r['reference'] and r['candidate'] != r['reference'] for r in rows),
    'rows': rows,
}
Path('/tmp/oriole-separators-oracle.json').write_text(json.dumps(report, indent=2) + '\n')
print({k: v for k, v in report.items() if k != 'rows'})
