"""Compare canonical non-ASCII custom encodings without modifying either parser."""
import ctypes as c
import hashlib
import json
import resource
from pathlib import Path

CONVERT = c.CFUNCTYPE(c.c_int, c.c_void_p, c.c_void_p)
RELEASE = c.CFUNCTYPE(None, c.c_void_p)
class Encoding(c.Structure):
    _fields_ = [('map', c.c_int * 256), ('data', c.c_void_p), ('convert', CONVERT), ('release', RELEASE)]
UNKNOWN = c.CFUNCTYPE(c.c_int, c.c_void_p, c.c_char_p, c.POINTER(Encoding))
START = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.POINTER(c.c_char_p))
END = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p)
TEXT = c.CFUNCTYPE(None, c.c_void_p, c.c_void_p, c.c_int)
PI = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.c_char_p)
VOID = c.CFUNCTYPE(None, c.c_void_p)
NS = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.c_char_p)
CASES = [
 ('names_values', b"<\x80\0 a='\x81\0\0'>\x82\0\0\0</\x80\0>", b'custom', False),
 ('attribute_name', b"<r \x80\0='\x81\0\0'/>", b'custom', False),
 ('comment_pi_cdata', b"<?pi \x80\0?><r><!--\x81\0\0--><![CDATA[\x82\0\0\0]]></r>", b'custom', False),
 ('namespaces', b"<p:\x80\0 xmlns:p='urn:\x81\0\0' p:\x82\0\0\0='v'/>", b'custom', True),
 ('entity_name_value', b"<!DOCTYPE r [<!ENTITY \x80\0 '\x81\0\0'>]><r>&\x80\0;</r>", b'custom', False),
 ('default_attribute', b"<!DOCTYPE r [<!ATTLIST r \x80\0 CDATA '\x81\0\0'>]><r/>", b'custom', False),
 ('crlf', b"<r>\r\n\x80\n\r\n\x81\r\n</r>", b'custom', False),
 ('declared', b"<?xml version='1.0' encoding='custom'?><r>\x80\0</r>", None, False),
 ('declared_bom', b"\xef\xbb\xbf<?xml version='1.0' encoding='custom'?><r>\x80\0</r>", None, False),
 ('mismatch', b"<\x80\0>\r\n</\x81\0\0>", b'custom', False),
 ('partial_two', b'<r>\x80', b'custom', False),
 ('partial_three', b'<r>\x81\0', b'custom', False),
 ('partial_four', b'<r>\x82\0\0', b'custom', False),
]

def load(path):
    library = c.CDLL(str(path))
    signatures = {
      'XML_ParserCreate': ([c.c_char_p], c.c_void_p),
      'XML_ParserCreateNS': ([c.c_char_p,c.c_char],c.c_void_p),
      'XML_SetUnknownEncodingHandler': ([c.c_void_p,UNKNOWN,c.c_void_p],None),
      'XML_SetElementHandler': ([c.c_void_p,START,END],None),
      'XML_SetCharacterDataHandler': ([c.c_void_p,TEXT],None),
      'XML_SetCommentHandler': ([c.c_void_p,END],None),
      'XML_SetProcessingInstructionHandler': ([c.c_void_p,PI],None),
      'XML_SetCdataSectionHandler': ([c.c_void_p,VOID,VOID],None),
      'XML_SetStartNamespaceDeclHandler': ([c.c_void_p,NS],None),
      'XML_SetReparseDeferralEnabled': ([c.c_void_p,c.c_ubyte],c.c_ubyte),
      'XML_Parse': ([c.c_void_p,c.c_void_p,c.c_int,c.c_int],c.c_int),
      'XML_GetErrorCode': ([c.c_void_p],c.c_int),
      'XML_GetCurrentByteIndex': ([c.c_void_p],c.c_long),
      'XML_GetCurrentByteCount': ([c.c_void_p],c.c_int),
      'XML_GetCurrentLineNumber': ([c.c_void_p],c.c_ulong),
      'XML_GetCurrentColumnNumber': ([c.c_void_p],c.c_ulong),
      'XML_ParserFree': ([c.c_void_p],None),
    }
    for name,(arguments,result) in signatures.items():
        function=getattr(library,name);function.argtypes=arguments;function.restype=result
    return library

def parse(library, document, protocol, namespaces, width, deferral):
    events=[];positions=[];counts={'unknown':0,'convert':0,'release':0}
    handle=library.XML_ParserCreateNS(protocol,b'|') if namespaces else library.XML_ParserCreate(protocol)
    assert handle
    def position():
        return [getattr(library,name)(handle) for name in ['XML_GetCurrentByteIndex','XML_GetCurrentByteCount','XML_GetCurrentLineNumber','XML_GetCurrentColumnNumber']]
    def record(kind,*values):
        events.append([kind,*values]);positions.append([kind,position()])
    @CONVERT
    def convert(_, wire):
        counts['convert']+=1;lead=c.cast(wire,c.POINTER(c.c_ubyte))[0]
        return {0x80:0xe9,0x81:0x4e2d,0x82:0x754c}[lead]
    @RELEASE
    def release(_):counts['release']+=1
    @UNKNOWN
    def unknown(_,name,info):
        counts['unknown']+=1
        for byte in range(256):info.contents.map[byte]=byte if byte<128 else -1
        for lead,length in [(0x80,2),(0x81,3),(0x82,4)]:info.contents.map[lead]=-length
        info.contents.convert=convert;info.contents.release=release;info.contents.data=None;return 1
    @START
    def start(_,name,attributes):
        values=[];index=0
        while attributes[index]:values.append([attributes[index].decode(),attributes[index+1].decode()]);index+=2
        record('start',name.decode(),values)
    @END
    def end(_,name):record('end',name.decode())
    @TEXT
    def text(_,value,length):record('text',c.string_at(value,length).decode())
    @END
    def comment(_,value):record('comment',value.decode())
    @PI
    def pi(_,target,value):record('pi',target.decode(),value.decode())
    @VOID
    def cdata_start(_):record('start_cdata')
    @VOID
    def cdata_end(_):record('end_cdata')
    @NS
    def namespace(_,prefix,uri):record('namespace',None if prefix is None else prefix.decode(),None if uri is None else uri.decode())
    library.XML_SetUnknownEncodingHandler(handle,unknown,None);library.XML_SetElementHandler(handle,start,end);library.XML_SetCharacterDataHandler(handle,text);library.XML_SetCommentHandler(handle,comment);library.XML_SetProcessingInstructionHandler(handle,pi);library.XML_SetCdataSectionHandler(handle,cdata_start,cdata_end);library.XML_SetStartNamespaceDeclHandler(handle,namespace);library.XML_SetReparseDeferralEnabled(handle,deferral)
    status=1
    for offset in range(0,len(document),width):
        chunk=document[offset:offset+width];status=library.XML_Parse(handle,chunk,len(chunk),int(offset+width>=len(document)))
        if not status:break
    result={'status':status,'error':library.XML_GetErrorCode(handle),'final_position':position(),'events':events,'positions':positions,'counts':counts};library.XML_ParserFree(handle)
    assert counts['unknown']==counts['release']==1
    normalized=[]
    for event in events:
        if event[0]=='text' and normalized and normalized[-1][0]=='text':normalized[-1][1]+=event[1]
        else:normalized.append(event.copy())
    result['normalized_events']=normalized;return result

resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(1024*1024*1024,)*2)
paths=[Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so'),Path('/tmp/oriole-final-encoding-checkpoint/liboriole_expat.so')];libraries=[load(path) for path in paths];results=[]
for name,document,protocol,namespaces in CASES:
    for width in range(1,len(document)+1):
        for deferral in [0,1]:
            reference,candidate=[parse(library,document,protocol,namespaces,width,deferral) for library in libraries]
            results.append({'case':name,'width':width,'deferral':deferral,'document_hex':document.hex(),'semantic_match':all(reference[key]==candidate[key] for key in ['status','error','normalized_events']),'position_match':reference['positions']==candidate['positions'] and reference['final_position']==candidate['final_position'],'reference':reference,'candidate':candidate})
report={'libraries':{str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in paths},'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'cases':len(results),'semantic_mismatches':sum(not item['semantic_match'] for item in results),'raw_position_or_fragmentation_mismatches':sum(not item['position_match'] for item in results),'results':results};destination=Path('/tmp/oriole-multibyte-canonical-review/results.json');destination.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({key:value for key,value in report.items() if key!='results'}))
