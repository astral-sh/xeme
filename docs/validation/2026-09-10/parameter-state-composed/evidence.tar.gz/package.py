from pathlib import Path
import hashlib,json,gzip,tarfile,shutil,subprocess
w=Path('/tmp/oriole-shared-integrated');r=Path('/home/dev-user/code/oss/oriole');d=r/'docs/validation/2026-09-10/parameter-state-composed';d.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=json.loads((w/'source.json').read_text())
for f,h in source['source_sha256'].items():assert sha(r/f)==h,f
old=json.loads(Path('/tmp/oriole-doctype-integrated/upstream-api/results.json').read_text());new=json.loads((w/'upstream-api/results.json').read_text());assert old['results']==new['results'];assert new['selection_complete'] and new['library_origin_verified'] and not new['timed_out']
for name in ['siblings.json','general.json']:
 for row in json.loads((w/name).read_text()):assert row['results']['reference']==row['results']['candidate']
missing=json.loads((w/'missing.json').read_text());doctype=json.loads(gzip.decompress((w/'doctype.json.gz').read_bytes()));assert doctype['differences']==0
ordinary=json.loads((w/'differential/summary.json').read_text());assert ordinary['exact_pass'];native=json.loads((w/'native/report.json').read_text());assert native['status']=='passed'
review=json.loads(Path('/tmp/oriole-shared-state-independent-review.json').read_text());review['integration_parent']='faed660361209b8e01ef8d78dd9f76abed2b8430';review['integrated_source_sha256']={f:source['source_sha256'][f] for f in review['source_sha256']};review['integration_notes']=['The only merge conflict joined independently appended C tests; both functions were preserved verbatim.','DOCTYPE prefix queue and adapter state remain in place. Root independently reruns focused family/doctype, ordinary, native and full API validation on its release build.'];(w/'integration-review.json').write_text(json.dumps(review,indent=2)+'\n')
(w/'source.patch').write_bytes(subprocess.check_output(['git','diff','faed660','HEAD','--','crates'],cwd=r))
validation={'rust_checks':source['rust_checks'],'library_sha256':source['library_sha256'],'ordinary':{k:ordinary[k] for k in ['cases','difference_counts','exact_pass']},'family_cases':6,'family_differences':0,'missing_parameter_oracle':missing['counts'],'doctype_cases':doctype['cases'],'doctype_differences':0,'upstream':{'cases':len(new['results']),'passed':new['passed'],'failed':new['failed'],'changed_outcomes':0},'native_suites':6,'allocation_scenarios_per_linkage':336};(w/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
files={}
for p in sorted(w.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 files[str(p.relative_to(w))]={'sha256':sha(p),'bytes':p.stat().st_size}
with tarfile.open(d/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for f in files:t.add(w/f,arcname=f,recursive=False)
with tarfile.open(d/'evidence.tar.gz') as t:
 for f in t:assert hashlib.sha256(t.extractfile(f).read()).hexdigest()==files[f.name]['sha256']
manifest={'archive_sha256':sha(d/'evidence.tar.gz'),'members':files};(d/'files.json').write_text(json.dumps(manifest,indent=2)+'\n');(d/'report.json').write_text(json.dumps(validation,indent=2)+'\n')
(d/'README.md').write_text(f'''# Compose parameter-family state with DOCTYPE callbacks

This checkpoint combines the separately preserved [shared-state implementation](../shared-parameter-state/) with the [DOCTYPE callback correction](../doctype-default/). The only merge conflict appended independent C regression tests; both functions remain intact.

The frozen release library is `{source['library_sha256']['liboriole_expat.so']}` at runtime commit `{source['commit']}`. All **284 Rust checks**, strict Clippy/formatting, **1,518 exact ordinary comparisons**, **six exact family cases**, and **4,104 exact callback-content/order DOCTYPE conditions** pass. The **1,944** missing-parameter cases retain zero acceptance differences and the existing **24** child-execution / **162** event differences. Full API results remain **4,065/675**, with every one of the **4,740** outcomes unchanged from the parent.

Six shared/static native C suites pass, including **336 allocation failure scenarios per linkage**. C callers use ASan/UBSan; Rust is uninstrumented, leak sanitizer is disabled, and selected live allocations are checked. Original source review, exact integrated hashes, commands, raw results and failed compatibility observations are retained. No new project performance or PBS claim is made by this checkpoint.

[evidence.tar.gz](evidence.tar.gz) excludes ELF/static artifacts and identifies them by hash. [files.json](files.json) verifies every member. Archive SHA256: `{manifest['archive_sha256']}`.
''')
print(json.dumps({'members':len(files),'archive_bytes':(d/'evidence.tar.gz').stat().st_size,'archive_sha256':manifest['archive_sha256']}))
