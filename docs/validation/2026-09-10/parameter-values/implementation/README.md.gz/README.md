# Internal parameter entities in entity values

Frozen source: `/tmp/oriole-pe-values`, based on `/tmp/oriole-diagnostic-followup`.
Patch: `parameter-values.patch`. `manifest.json` records all eight changed files,
base and final hashes, library hash, commands, and evidence locations. No live
checkout files or Git state were changed.

## Behavior

Internal parameter entities expand inside entity values in external DTDs and
parameter entities. An iterative borrowed-frame stack retains lexical source
boundaries: replacement quotes remain value data, references cannot span frames,
and literal newlines are normalized only in their original source. Reference
work, replacement bytes, and nesting use shared parser-family limits; every
allocation is fallible and uses the selected allocator.

Missing parameters leave the current declaration and its suffix intact, then
suppress later declarations unless standalone. First declarations win, including
self-reference checks against an existing parameter declaration. Illegal direct
internal-subset value references return Expat error 10 after lexical validation.

An explicitly selected external-child mode 1 processes parameter references even
for a standalone root. A root standalone declaration converts inherited mode 1
to mode 0, preserving Expat's child-inheritance behavior.

## Validation

- 141 core and C-interface tests passed, including fail-at-every-allocation,
  zero live allocations, no global allocator bypass, UTF-16/all-chunk value tests,
  buffer input, parent import, recursion, missing values, and resource limits.
- Formatting and strict Clippy passed.
- Independent reference oracle: all 256 status/error cases matched; all 12
  inherited-mode cases matched exactly.
- Independent positive chunk/encoding oracle: 23,328 UTF-8 and UTF-16LE/BE cases
  matched normalized entity/default/attribute/not-standalone/skipped summaries.
- Fifteen relevant upstream tests across six chunk settings and both deferral
  modes: reference 180/180, diagnostic baseline 40/180, candidate 64/180. Twenty-four
  configurations newly pass, with no new failures. Details in
  `upstream-comparison.json`; full runs at `/tmp/oriole-pe-upstream-{reference,baseline,final}`.

## Remaining boundaries

Arbitrary declaration fragments and external parameter references inside entity
values/conditional headers remain explicitly unsupported. Existing differences in
partial entity callbacks on malformed declarations, sparse default fragments for
duplicate declarations, and raw callbacks for disabled between-declaration
parameter references remain. The selected upstream allocation-threshold failures
and external-value-continuation failures remain recorded rather than excluded.

Integration must preserve the live C README's newly added broader XML-name
paragraph; this patch was based on the diagnostic snapshot and does not replace
the whole live file.
