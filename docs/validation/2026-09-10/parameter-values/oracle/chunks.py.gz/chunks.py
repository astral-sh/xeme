import argparse
import hashlib
import json
from pathlib import Path

arguments = argparse.ArgumentParser()
arguments.add_argument('library', type=Path)
arguments.add_argument('--sha256', required=True)
args = arguments.parse_args()
ROOT = Path('/tmp/oriole-pe-review')
assert hashlib.sha256(args.library.read_bytes()).hexdigest() == args.sha256
source = Path('/tmp/oriole-conditional-review/probe.py').read_text().split('\nbody = ')[0]
source = source.replace('<r>&e;</r>', '<r/>').replace("'data': data.decode()", "'data': data.hex()")
source = source.replace('status = l.XML_Parse(child, data, len(data), 1)', '''status = 1
        for offset in range(0, len(data), chunk_width):
            part = data[offset:offset+chunk_width]
            status = l.XML_Parse(child, part, len(part), int(offset+chunk_width >= len(data)))
            if status == 0:
                break''')
reference, candidate = {}, {}
exec(source, reference)
exec(source.replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so', str(args.library)), candidate)
chosen = ['ordinary', 'missing', 'nested', 'quote_data', 'reparsed_character_reference',
          'reparsed_cr', 'missing_in_replacement', 'character_reference_percent']
cases = json.loads((ROOT / 'results.json').read_text())['cases']
cases = [(label, next(case['data'] for case in cases if case['label'] == label)) for label in chosen]
cases.append(('unicode', '<!ENTITY % 中 "é"><!ENTITY % é "L&#37;中;R"><!ENTITY e "%é;">'))

def summary(case):
    return {
        'status_error': [[child['status'], child['error']] for child in case['children']],
        'values': [[*event[3:]] for event in case['events'] if event[:2] == ['child', 'entity']],
        'attributes': [[*event[3:]] for event in case['events'] if event[:2] == ['child', 'attlist']],
        'default': case['child_default'],
        'not_standalone': [event[2] for event in case['events'] if event[:2] == ['child', 'not-standalone']],
        'skipped': [[*event[3:]] for event in case['events'] if event[:2] == ['child', 'skipped']],
    }

count = 0
differences = []
for label, text in cases:
    for encoding, bom in [('utf-8', b''), ('utf-16-le', b'\xff\xfe'), ('utf-16-be', b'\xfe\xff')]:
        data = bom + text.encode(encoding)
        for mode in [0, 1, 2]:
            for standalone in ['no', 'yes']:
                for width in range(1, len(data)+1):
                    reference['chunk_width'] = candidate['chunk_width'] = width
                    before = summary(reference['probe'](standalone, mode, data, True, 1))
                    after = summary(candidate['probe'](standalone, mode, data, True, 1))
                    count += 1
                    if before != after:
                        differences.append({'label': label, 'encoding': encoding, 'mode': mode,
                                            'standalone': standalone, 'chunk': width,
                                            'reference': before, 'candidate': after})
assert hashlib.sha256(args.library.read_bytes()).hexdigest() == args.sha256
(ROOT / 'final-chunks.json').write_text(json.dumps({'library': str(args.library),
                                                 'sha256': args.sha256, 'cases': count,
                                                 'differences': differences}, indent=2) + '\n')
print('cases', count, 'differences', len(differences))
for difference in differences[:10]:
    print(json.dumps(difference))
