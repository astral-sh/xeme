import argparse
import hashlib
import json
from pathlib import Path

arguments = argparse.ArgumentParser()
arguments.add_argument('library', type=Path)
arguments.add_argument('--sha256', required=True)
arguments.add_argument('--output-prefix', default='candidate')
args = arguments.parse_args()
assert hashlib.sha256(args.library.read_bytes()).hexdigest() == args.sha256
ROOT = Path('/tmp/oriole-pe-review')
SOURCE = Path('/tmp/oriole-conditional-review/probe.py').read_text().split('\nbody = ')[0]
SOURCE = SOURCE.replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so', str(args.library))

def make_probe(internal=False):
    source = SOURCE
    if internal:
        source = source.replace('document = declaration + b"<!DOCTYPE r SYSTEM \'d\'><r>&e;</r>"',
                                'document = declaration + data')
        source = source.replace('l.XML_SetParamEntityParsing(parent, 2)',
                                'l.XML_SetParamEntityParsing(parent, mode)')
    else:
        source = source.replace('<r>&e;</r>', '<r/>')
    scope = {}
    exec(source, scope)
    return scope['probe']

def summary(case, internal):
    origin = 'parent' if internal else 'child'
    return {
        'status_error': ([case['parent_status'], case['parent_error']] if internal else
                         [[child['status'], child['error']] for child in case['children']]),
        'values': [[event[3], event[4], event[5]] for event in case['events']
                   if event[0] == origin and event[1] == 'entity'],
        'attributes': [[*event[3:]] for event in case['events']
                       if event[0] == origin and event[1] == 'attlist'],
        'default': ''.join(event[3] for event in case['events']
                          if event[0] == origin and event[1] == 'default'),
        'not_standalone': [event[2] for event in case['events']
                           if event[0] == origin and event[1] == 'not-standalone'],
        'skipped': [[*event[3:]] for event in case['events']
                    if event[0] == origin and event[1] == 'skipped'],
    }

suites = {
    'external': (json.loads((ROOT / 'results.json').read_text())['cases'], False),
    'internal': (json.loads((ROOT / 'internal-contexts.json').read_text()), True),
    'duplicate': (json.loads((ROOT / 'duplicate-missing.json').read_text()), False),
}
counts = {}
for name, (references, internal) in suites.items():
    probe = make_probe(internal)
    results, differences = [], []
    for index, reference in enumerate(references):
        result = probe(reference['standalone'], reference['mode'], reference['data'].encode(),
                       reference['expand'], reference['not_result'])
        result['label'] = reference['label']
        results.append(result)
        before, after = summary(reference, internal), summary(result, internal)
        delta = {key: {'reference': before[key], 'candidate': after[key]}
                 for key in before if before[key] != after[key]}
        if delta:
            differences.append({'index': index, 'label': reference['label'],
                                'standalone': reference['standalone'], 'mode': reference['mode'],
                                'difference': delta})
    output = {'library': str(args.library), 'sha256': args.sha256,
              'cases': results, 'differences': differences}
    (ROOT / f'{args.output_prefix}-{name}.json').write_text(json.dumps(output, indent=2) + '\n')
    counts[name] = {'cases': len(results), 'full_matches': len(results)-len(differences),
                    'status_error_differences': sum('status_error' in row['difference'] for row in differences)}
    print(name, counts[name])
    unique = {}
    for row in differences:
        key = (row['label'], json.dumps(row['difference'], sort_keys=True))
        unique.setdefault(key, row)
    for row in unique.values():
        print(json.dumps(row))
assert hashlib.sha256(args.library.read_bytes()).hexdigest() == args.sha256
(ROOT / f'{args.output_prefix}-counts.json').write_text(json.dumps(counts, indent=2) + '\n')
