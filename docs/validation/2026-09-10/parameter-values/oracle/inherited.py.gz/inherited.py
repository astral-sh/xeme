from pathlib import Path
import hashlib
import json

ROOT = Path('/tmp/oriole-pe-review')
LIB = Path('/home/dev-user/.cache/oriole/pe-values-target/debug/liboriole_expat.so')
EXPECTED = '2891a41f8b7b1e4da48dc00de37ba408d360db0e4f12459f7ce8ee263b84f64f'
assert hashlib.sha256(LIB.read_bytes()).hexdigest() == EXPECTED
source = Path('/tmp/oriole-conditional-review/probe.py').read_text().split('\nbody = ')[0]
source = source.replace('/home/dev-user/.cache/oriole/expat-build/libexpat.so', str(LIB))
scope = {}
exec(source, scope)
l, ENTITY, c = scope['l'], scope['ENTITY'], scope['c']
results = []
for rootmode in [0, 1, 2]:
    for childmode in [None, 0, 1, 2]:
        parser = l.XML_ParserCreate(None)
        l.XML_SetParamEntityParsing(parser, rootmode)
        declaration = b"<?xml version='1.0' standalone='yes'?>"
        assert l.XML_Parse(parser, declaration, len(declaration), 0) == 1
        child = l.XML_ExternalEntityParserCreate(parser, None, None)
        if childmode is not None:
            l.XML_SetParamEntityParsing(child, childmode)
        events = []
        callback = ENTITY(lambda _, name, parameter, value, length, base, system, public, notation:
                          events.append([name.decode(), parameter,
                                         c.string_at(value, length).decode() if value else None]))
        l.XML_SetEntityDeclHandler(child, callback)
        data = b'<!ENTITY % d \'<!ENTITY e "ok">\'>%d;'
        status = l.XML_Parse(child, data, len(data), 1)
        results.append({'root_mode': rootmode, 'child_mode': childmode, 'status': status,
                        'error': l.XML_GetErrorCode(child), 'values': events})
        l.XML_ParserFree(child)
        l.XML_ParserFree(parser)
reference = json.loads((ROOT / 'inherited-mode.json').read_text())
differences = [{'reference': before, 'candidate': after} for before, after in zip(reference, results, strict=True)
               if before != after]
assert hashlib.sha256(LIB.read_bytes()).hexdigest() == EXPECTED
(ROOT / 'final-inherited-mode.json').write_text(json.dumps({'library': str(LIB), 'sha256': EXPECTED,
                                                         'cases': results, 'differences': differences}, indent=2) + '\n')
print('cases', len(results), 'differences', len(differences))
for difference in differences:
    print(json.dumps(difference))
