from pathlib import Path
import hashlib
import json

ROOT = Path('/tmp/oriole-pe-review')
source = Path('/tmp/oriole-conditional-review/probe.py').read_text().split('\nbody = ')[0]
source = source.replace('<r>&e;</r>', '<r/>')
scope = {}
exec(source, scope)

declarations = [
    ('ordinary', '<!ENTITY % p "P"><!ENTITY e "L%p;R">'),
    ('missing', '<!ENTITY e "L%missing;R">'),
    ('missing_then_bad', '<!ENTITY e "L%missing;&#0;R">'),
    ('self', '<!ENTITY % p "L%p;R">'),
    ('same_name_general', '<!ENTITY % e "P"><!ENTITY e "L%e;R">'),
    ('duplicate_parameter', '<!ENTITY % p "old"><!ENTITY % p "%p;"><!ENTITY e "%p;">'),
    ('indirect_recursion', '<!ENTITY % p "&#37;q;"><!ENTITY % q "&#37;p;"><!ENTITY e "%p;">'),
    ('nested', '<!ENTITY % p "P"><!ENTITY % q "Q%p;"><!ENTITY e "L%q;R">'),
    ('reparsed_percent', '<!ENTITY % p "P"><!ENTITY % q "&#37;p;"><!ENTITY e "%q;">'),
    ('quote_data', '<!ENTITY % p "&#34;\'<> "><!ENTITY e "%p;">'),
    ('general_reference', '<!ENTITY % p "&amp;"><!ENTITY e "%p;">'),
    ('reparsed_character_reference', '<!ENTITY % p "&#38;#65;"><!ENTITY e "%p;">'),
    ('incomplete_ampersand', '<!ENTITY % p "&#38;"><!ENTITY e "%p;amp;">'),
    ('incomplete_percent', '<!ENTITY % p "&#37;"><!ENTITY e "%p;p;">'),
    ('literal_prefix_reference', '<!ENTITY % p "amp"><!ENTITY e "&%p;;">'),
    ('character_reference_percent', '<!ENTITY e "&#37;missing;">'),
    ('direct_cr', '<!ENTITY e "A&#13;B">'),
    ('reparsed_cr', '<!ENTITY % p "&#13;"><!ENTITY e "A%p;B">'),
    ('boundary_cr_lf', '<!ENTITY % p "&#13;"><!ENTITY e "A%p;\nB">'),
    ('literal_cr', '<!ENTITY % p "A\rB"><!ENTITY e "%p;">'),
    ('active_source_recursion', '<!ENTITY % p "<!ENTITY e \'&#37;p;\'>">%p;'),
    ('missing_in_replacement', '<!ENTITY % p "L&#37;missing;R"><!ENTITY e "A%p;B">'),
]

results = []
for label, declaration in declarations:
    for standalone in [None, 'no', 'yes']:
        for mode in [0, 1, 2]:
            data = (declaration + '<!ENTITY after "AFTER"><!ATTLIST r a CDATA "yes">').encode()
            result = scope['probe'](standalone, mode, data, True, 1)
            results.append({'label': label, **result})
(ROOT / 'results.json').write_text(json.dumps({'reference': str(scope['LIB']),
                                             'sha256': hashlib.sha256(scope['LIB'].read_bytes()).hexdigest(),
                                             'cases': results}, indent=2) + '\n')
for result in results:
    if result['standalone'] not in ['no', 'yes'] or result['mode'] == 1:
        continue
    events = [event for event in result['events'] if event[0] == 'child' and event[1] != 'default']
    print(json.dumps({'label': result['label'], 'standalone': result['standalone'],
                      'mode': result['mode'], 'children': result['children'], 'events': events,
                      'default': result['child_default']}))
