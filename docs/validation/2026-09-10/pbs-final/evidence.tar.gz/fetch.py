import hashlib,json,subprocess,zipfile
from pathlib import Path
root=Path('/home/dev-user/code/oss/oriole');out=Path('/tmp/oriole-pbs-final-success');out.mkdir(exist_ok=True)
gh='/home/dev-user/.local/bin/gh-auto';run='34456274540'
def api(path):return json.loads(subprocess.check_output([gh,'api',path],cwd=root))
metadata=api(f'repos/astral-sh/oriole/actions/runs/{run}')
assert metadata['status']=='completed' and metadata['conclusion']=='success', (metadata['status'],metadata['conclusion'])
(out/'github-run.json').write_text(json.dumps(metadata,indent=2)+'\n')
artifacts=api(f'repos/astral-sh/oriole/actions/runs/{run}/artifacts')
(out/'github-artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
verified=[]
for artifact in artifacts['artifacts']:
 if artifact['name'] not in ('oriole-pbs-validation','oriole-pbs-experimental-distribution'):continue
 dest=out/artifact['name'];dest.mkdir(exist_ok=True)
 zip_path=out/(artifact['name']+'.zip')
 with zip_path.open('wb') as f:subprocess.run([gh,'api',f'repos/astral-sh/oriole/actions/artifacts/{artifact["id"]}/zip'],cwd=root,stdout=f,check=True)
 digest='sha256:'+hashlib.sha256(zip_path.read_bytes()).hexdigest()
 assert digest==artifact['digest'],(digest,artifact['digest'])
 with zipfile.ZipFile(zip_path) as zf:
  for info in zf.infolist():
   path=dest/info.filename
   assert path.resolve().is_relative_to(dest.resolve())
  zf.extractall(dest)
 verified.append({'name':artifact['name'],'id':artifact['id'],'zip_sha256':digest,'matches_github_digest':True,'files':{str(p.relative_to(dest)):hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.rglob('*') if p.is_file()}})
(out/'download-verification.json').write_text(json.dumps(verified,indent=2)+'\n')
print('verified',[(v['name'],v['id']) for v in verified])
