"""Independently audit retained PBS artifacts; never build or execute the distribution."""
import hashlib, io, json, os, re, subprocess, tarfile, zipfile
from pathlib import Path
ROOT=Path('/home/dev-user/code/oss/oriole')
OUT=Path('/tmp/oriole-pbs-final-success')
VALID=OUT/'oriole-pbs-validation'
FINAL=Path('/tmp/oriole-grammar-combined-source/source.json')
RUNTIME='12628880f33d026aafd4cbd9d60185191583e268'
HEAD='5f9a18fab8a77eb5eeaa6d7504f72078e25c4299'
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(path):return json.loads(path.read_text())
def git_files(ref,names):
 data=subprocess.check_output(['git','archive',ref,*sorted(names)],cwd=ROOT)
 with tarfile.open(fileobj=io.BytesIO(data)) as tf:
  return {m.name:sha(tf.extractfile(m).read()) for m in tf if m.isfile()}
run=read(OUT/'github-run.json');jobs=read(OUT/'github-jobs.json')
assert run['id']==34456274540 and run['head_sha']==HEAD and run['status']=='completed' and run['conclusion']=='success'
assert len(jobs['jobs'])==1 and all(s['conclusion']=='success' for s in jobs['jobs'][0]['steps'])
assert len(jobs['jobs'][0]['steps'])==17
artifacts=read(OUT/'github-artifacts.json')['artifacts']; verification=read(OUT/'download-verification.json')
assert len(artifacts)==len(verification)==2
verified=[]
for v in verification:
 a=next(a for a in artifacts if a['id']==v['id']); p=OUT/(v['name']+'.zip'); actual=digest(p)
 assert a['name']==v['name'] and 'sha256:'+actual==v['zip_sha256']==a['digest']
 assert a['workflow_run']['head_sha']==HEAD
 with zipfile.ZipFile(p) as zf:
  records={i.filename:sha(zf.read(i)) for i in zf.infolist() if not i.is_dir()}
 assert records==v['files']
 assert {str(p.relative_to(OUT/v['name'])):digest(p) for p in (OUT/v['name']).rglob('*') if p.is_file()}==records
 verified.append({'id':a['id'],'name':a['name'],'zip_sha256':actual,'files_verified':len(records)})
bundle_path=VALID/'oriole-bundle/manifest.json';bundle=read(bundle_path);final=read(FINAL)
assert bundle['sources']==git_files(RUNTIME,bundle['sources'])==git_files(HEAD,bundle['sources'])
common={n:h for n,h in final['sources'].items() if not n.startswith('crates/oriole_cli/')}
assert all(bundle['sources'][n]==h for n,h in common.items())
assert bundle['files']['expat.h']==bundle['sources']['include/expat.h']
assert bundle['pbs_revision']=='a4553880293fe9d1bb62747d34ab0e5121d3554f'
assert bundle['target']=='x86_64-unknown-linux-gnu' and bundle['implementation_version']=='0.0.1'
assert bundle['rustc'].startswith('rustc 1.98.1 (48a229cea 2026-09-01)') and '+ohm' not in str(bundle['command'])
assert bundle['rustflags']=='-C relocation-model=pic -C panic=unwind'
adapt=bundle['consumer_adaptation']
assert adapt['cpython_version']=='3.12.13' and adapt['cpython_revision']=='3bb231a6a5dc02b95658877318bf61501a7209e9'
assert adapt['patch_sha256']==bundle['sources']['integration/python-build-standalone/consumer-fix/cpython-3.12.13-external-parser.patch']==bundle['files']['cpython-external-parser.patch']
archive,=(OUT/'oriole-pbs-experimental-distribution').glob('*.tar.zst');archive_hash=digest(archive)
assert archive_hash==next(v for v in verification if v['name'].endswith('distribution'))['files'][archive.name]
assert (VALID/'pbs-archive-sha256.txt').read_text().split()==[archive_hash,'dist/'+archive.name]
text=(VALID/'pbs-build.log').read_text()
assert f'{archive.name} has SHA256 {archive_hash}' in text
assert 'Oriole CPython source: https://www.python.org/ftp/python/3.12.13/Python-3.12.13.tar.xz (sha256=c08bc65a81971c1dd5783182826503369466c7e67374d1646519adf05207b684)' in text
assert 'Python-3.12.13.tar.xz exists and passes integrity checks' in text
assert 'patching file Modules/pyexpat.c' in text
for n in bundle['files']:
 assert f'copying /home/runner/work/_temp/oriole-bundle/{n} to container:' in text
assert 'Finished `release` profile' in (VALID/'oriole-bundle/build.log').read_text()
assert '--wrap=__cxa_thread_atexit_impl' in text
wanted={'python/PYTHON.json','python/licenses/LICENSE.oriole-build.txt','python/licenses/LICENSE.oriole.txt','python/build/lib/libexpat.a','python/install/lib/libpython3.12.so.1.0','python/install/bin/python3.12'}
stream=subprocess.Popen(['zstd','-dc',str(archive)],stdout=subprocess.PIPE)
member_hashes={};elf={};names=set();metadata=None
with tarfile.open(fileobj=stream.stdout,mode='r|') as tf:
 for m in tf:
  assert m.name not in names,m.name
  names.add(m.name)
  if m.name not in wanted:continue
  assert m.isfile(),m.name
  content=tf.extractfile(m).read();member_hashes[m.name]={'sha256':sha(content),'bytes':len(content)}
  if m.name=='python/PYTHON.json':metadata=json.loads(content)
  if m.name in ('python/install/lib/libpython3.12.so.1.0','python/install/bin/python3.12'):
   fd=os.memfd_create('oriole-pbs-independent-elf')
   try:
    with os.fdopen(os.dup(fd),'wb') as f:f.write(content)
    symbols=subprocess.check_output(['readelf','--dyn-syms','--wide',f'/proc/self/fd/{fd}'],pass_fds=(fd,),text=True)
    versions=subprocess.check_output(['readelf','--version-info','--wide',f'/proc/self/fd/{fd}'],pass_fds=(fd,),text=True)
   finally:os.close(fd)
   glibc=sorted(set(re.findall(r'GLIBC_([0-9]+(?:\.[0-9]+)+)',versions)),key=lambda s:tuple(map(int,s.split('.'))))
   assert all(tuple(map(int,v.split('.')))<=(2,17) for v in glibc)
   hooks=[l.strip() for l in symbols.splitlines() if 'cxa_thread_atexit_impl' in l]
   if 'libpython' in m.name:
    assert len(hooks)==1 and 'WEAK' in hooks[0] and 'UND' in hooks[0] and hooks[0].endswith('__wrap___cxa_thread_atexit_impl')
    assert b'oriole_0.0.1' in content
   elf[m.name]={'glibc_versions':glibc,'maximum_glibc':glibc[-1],'tls_hook_symbols':hooks}
assert stream.wait()==0 and set(member_hashes)==wanted
assert member_hashes['python/build/lib/libexpat.a']['sha256']==bundle['files']['libexpat.a']
assert member_hashes['python/licenses/LICENSE.oriole-build.txt']['sha256']==digest(bundle_path)
assert member_hashes['python/licenses/LICENSE.oriole.txt']['sha256']==bundle['files']['LICENSE.oriole.txt']
assert metadata['python_version']=='3.12.13' and metadata['target_triple']==bundle['target'] and metadata['build_options']==metadata['optimizations']=='noopt' and metadata['libpython_link_mode']=='shared'
px,=metadata['build_info']['extensions']['pyexpat'];assert {'name':'expat','path_static':'build/lib/libexpat.a'} in px['links'];assert px['license_paths']==['licenses/LICENSE.oriole.txt'] and sorted(px['licenses'])==['Apache-2.0','MIT']
tls=read(VALID/'pbs-tls-probe/manifest.json')
assert tls['rustc']==bundle['rustc'] and tls['threads_per_binary']==32
assert {n:git_files(HEAD,['integration/python-build-standalone/'+n])['integration/python-build-standalone/'+n] for n in tls['sources']}==tls['sources']
for name in ('fallback','shared'):
 s=(VALID/f'pbs-tls-probe/{name}-symbols.txt').read_text();hooks=[l.split() for l in s.splitlines() if 'cxa_thread_atexit_impl' in l]
 assert len(hooks)==1 and hooks[0][-1]=='__wrap___cxa_thread_atexit_impl' and 'UND' in hooks[0] and 'WEAK' in hooks[0] and 'GLIBC_2.18' not in s
assert '__cxa_thread_atexit_impl@GLIBC_2.18' in (VALID/'pbs-tls-probe/native-symbols.txt').read_text()
custom=(VALID/'pbs-custom-tests.log').read_text();xml=(VALID/'pbs-xml-tests.log').read_text();glibc=(VALID/'pbs-glibc217-tests.log').read_text();validation=(VALID/'pbs-validate.log').read_text()
assert all(len(re.findall(r'Ran 22 tests',s))==1 and s.count('OK (skipped=5)')==1 for s in (custom,xml))
assert 'All 6 tests OK.' in xml and 'Total tests: run=802 skipped=12' in xml and 'Result: SUCCESS' in xml
assert 'All 6 tests OK.' in glibc and 'Total tests: run=802 skipped=13' in glibc and 'Result: SUCCESS' in glibc
identity=json.loads(next(l for l in glibc.splitlines() if l.startswith('{')))
assert identity=={'glibc':['glibc','2.17'],'expat':'oriole_0.0.1','threaded_parses':1024}
assert f'dist/{archive.name} OK' in validation
proof_sources=['.github/workflows/pbs.yml','integration/python-build-standalone/prepare.py','integration/python-build-standalone/run.sh','integration/python-build-standalone/pbs-a455388.patch','integration/python-build-standalone/test-old-glibc.py']
report={
 'status':'pass','issues':[], 'method':'Independent retained-artifact/Git/source/log audit; streamed tar members and inspected ELF via anonymous memfd; no rebuild, extraction of full distribution, or execution.',
 'github_run':{'id':run['id'],'head_sha':HEAD,'html_url':run['html_url'],'completed_successful_steps':17},
 'artifacts':verified,
 'source_identity':{'runtime_commit':RUNTIME,'bundle_source_files_exact_both_commits':len(bundle['sources']),'final_local_manifest_overlap_exact':len(common),'final_local_manifest_sha256':digest(FINAL),'final_local_release_so_sha256':final['libraries']['liboriole_expat.so'],'bundle_manifest_sha256':digest(bundle_path),'stable_ci_rustc':bundle['rustc'],'local_vs_ci_binary_identity':'Same runtime source; separate stable CI PIC static archive, not the local Ohm ff5d or 4fa binaries.'},
 'distribution':{'name':archive.name,'sha256':archive_hash,'tar_members':len(names),'member_hashes':member_hashes,'metadata':{k:metadata[k] for k in ('python_version','target_triple','build_options','optimizations','libpython_link_mode','crt_features')},'pyexpat':px,'elf':elf},
 'gates':{'complete_pbs_validator':'pass','custom_test_invocations':2,'custom_logs':['pbs-custom-tests.log','pbs-xml-tests.log'],'custom_tests_each':22,'custom_skips_each':5,'host_xml':{'files':6,'run':802,'skipped':12},'glibc217_xml':{'files':6,'run':802,'skipped':13},'glibc217_identity':identity,'tls':{'binaries':3,'threads_each':32,'destructors':'exactly once per thread per retained successful probe manifest','fallback_symbols':'unversioned undefined weak wrapper, no GLIBC_2.18'}},
 'consumer_adaptation':adapt,'ci_script_hashes':git_files(HEAD,proof_sources),
 'evidence_hashes':{str(p.relative_to(OUT)):digest(p) for p in [OUT/'github-run.json',OUT/'github-jobs.json',OUT/'github-artifacts.json',OUT/'download-verification.json',*sorted(VALID.rglob('*'))] if p.is_file()},
 'limitations':['Native Linux x86_64 CPython 3.12.13 shared noopt distribution on the pinned PBS overlay; no other platforms, architectures, optimized modes or CPython releases proven.','PBS custom tests and six XML stdlib files are scoped gates, not the complete CPython stdlib suite.','The reviewed CPython child-cleanup backport changes only Modules/pyexpat.c; published source hashes and tests are retained.','Independent audit uses CI results; no local repeat execution or rebuild was performed.','The original CPython source archive is not retained in these artifacts; pinned source checksum is corroborated by recipe, integrity-check log and backport source checks.','Metadata crt_features retains upstream spelling glibc-max-symbol-version:2.17); ELF version requirements independently confirm maximum 2.17.']
}
Path('/tmp/oriole-pbs-final-independent-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'source_files':len(bundle['sources']),'overlap':len(common),'archive_sha256':archive_hash,'elf':elf,'review_sha256':digest(Path('/tmp/oriole-pbs-final-independent-review.json'))},indent=2))
