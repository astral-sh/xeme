import hashlib,json,subprocess,tarfile
from pathlib import Path
root=Path('/home/dev-user/code/oss/oriole');out=Path('/tmp/oriole-pbs-final-success');validation=out/'oriole-pbs-validation'
local_path=Path('/tmp/oriole-grammar-combined-source/source.json');local=json.loads(local_path.read_text());bundle_path=validation/'oriole-bundle/manifest.json';bundle=json.loads(bundle_path.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
for p,h in bundle['sources'].items():
 if p in local['sources']:
  git_data=subprocess.check_output(['git','show','1262888:'+p],cwd=root)
  checks.append({'path':p,'bundle_sha256':h,'local_sha256':local['sources'][p],'git_sha256':hashlib.sha256(git_data).hexdigest(),'matches':h==local['sources'][p]==hashlib.sha256(git_data).hexdigest()})
assert all(c['matches'] for c in checks)
required={p for p in local['sources'] if (p.startswith(('crates/oriole/src/','crates/oriole_expat/src/','crates/oriole_storage/src/')) and p.endswith('.rs')) or p in ['Cargo.lock','Cargo.toml','crates/oriole/Cargo.toml','crates/oriole_expat/Cargo.toml','crates/oriole_storage/Cargo.toml','include/expat.h']}
assert required.issubset({c['path'] for c in checks})
archive,=(out/'oriole-pbs-experimental-distribution').glob('*.tar.zst')
expected=(validation/'pbs-archive-sha256.txt').read_text().split()[0];assert sha(archive)==expected
metadata=out/'archive-metadata';metadata.mkdir(exist_ok=True)
entries=[]
with subprocess.Popen(['zstd','-dc',str(archive)],stdout=subprocess.PIPE) as proc:
 with tarfile.open(fileobj=proc.stdout,mode='r|') as tf:
  for item in tf:
   if not item.isfile() or Path(item.name).name not in ['PYTHON.json','LICENSE.oriole-build.txt','LICENSE.oriole.txt']:continue
   assert item.size<2**20
   data=tf.extractfile(item).read();dest=metadata/item.name.replace('/','__');dest.write_bytes(data)
   entries.append({'archive_member':item.name,'local_file':str(dest),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 assert proc.wait()==0
embedded=[x for x in entries if x['archive_member'].endswith('/LICENSE.oriole-build.txt')];assert len(embedded)==1
assert embedded[0]['sha256']==sha(bundle_path)
notices=[x for x in entries if x['archive_member'].endswith('/LICENSE.oriole.txt')];assert len(notices)==1 and notices[0]['sha256']==bundle['files']['LICENSE.oriole.txt']
report={'runtime_revision':subprocess.check_output(['git','rev-parse','1262888'],cwd=root,text=True).strip(),'workflow_revision':json.loads((out/'github-run.json').read_text())['head_sha'],'local_source_manifest_sha256':sha(local_path),'bundle_manifest_sha256':sha(bundle_path),'source_checks':checks,'required_library_source_count':len(required),'required_library_source_paths':sorted(required),'all_sources_match':True,'distribution_file':archive.name,'distribution_bytes':archive.stat().st_size,'distribution_sha256':expected,'matches_archive_log':True,'archive_metadata':entries,'embedded_bundle_manifest_matches':True,'embedded_notices_match':True,'scope':'Same Rust library sources, manifests and public header. PBS stable Rust PIC bundle is a distinct build from the local Ohm shared/static libraries.'}
(out/'runtime-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print('source_matches',len(checks),'required',len(required),'archive',expected,'metadata',len(entries))
