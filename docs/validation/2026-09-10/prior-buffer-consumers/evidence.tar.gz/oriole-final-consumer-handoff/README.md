# Final normal-build consumer and API evidence

Frozen runtime9cc (staticb803), with64 verified source files. No runtime edits occur in this validation layer.

All four CPython configurations run803 original tests with31 existing skips and2 known text-fragmentation failures. Every original strict run exits2. The separate two-test semantic gate passes; it does not turn the original suite into a pass.

The W3C Fifth Edition selection now records4962 mandatory passes,960 mandatory failures and81 optional observations for each engine. The current C interface deliberately uses Fourth Edition XML names for Expat compatibility:954 observations across318 Fifth Edition descriptors that old Oriole accepted are now rejected by both current engines. The historical5916/6 Oriole score is not the current C score. Current reference acceptance differences are zero, while225 status/error and1785 complete result differences remain. Three malformed ELEMENT observations newly differ in error code versus the historical checkpoint and are retained. Five safe Rust descriptor controls (30 total rows) confirm default Fifth versus explicit Fourth behavior; no full Rust W3C run is claimed.

The original API matrix remains4323 pass/417 fail. Against the historical987 failures,584 contexts are fixed,403 failures remain and14 previously passing contexts now fail. The category report retains every failure, exact first assertion, original budget statement and source body. No larger retry ceilings or reference-harness exclusions override these counts.

The pinned mirror archive is recovered byte-for-byte from the published evidence after an old temporary symlink disappeared. Official W3C archive identity remains unverified. One test-runner edit only adds isolated Python worker flags, and is preserved as a patch. CPython preserves a corrected postprocessing-only ELF capsule dependency assumption, with the first audit script retained.

Compiled binaries are excluded. Their identities, original source maps, original logs, launch commands, source bodies, comparison rows and per-archive member hashes remain available here. Historical large-input reference controls use the same current Expat hash and bounds; historical Oriole prefix allocation measurements belong to their explicitly recorded older binary.
