# Remaining original API assertions

Final9cc: **4323 pass /417 fail**, across4740 original contexts and40 failing test names. Historicalff5d:3753/987. Exact comparison:584 formerly failing contexts now pass,403 failures remain, and14 previously passing contexts now fail. No outcomes are overridden.

## Categories

| Cause | Failed contexts |
| --- | ---: |
| allocation retry ceiling | 298 |
| expected reallocation schedule | 44 |
| fixed injection stage | 12 |
| one gib buffer harness and policy | 12 |
| allocation byte heuristic | 1 |
| error column | 12 |
| large stream policy and reference timeout | 2 |
| library version identity | 12 |
| expected malloc after empty parsebuffer | 12 |
| reparse deferral callback timing | 12 |

## Per-test source and bounds

Bounds below are literal source statements. All original assertions and the3-second/1GiB-address/768MiB-requested-RSS per-case controls remain.

| Test | Failures | Category | Literal budget |
| --- | ---: | --- | --- |
| test_alloc_attribute_enum_value | 12 | allocation retry ceiling | const int max_alloc_count = 30;; g_allocation_count = i; |
| test_alloc_dtd_default_handling | 12 | allocation retry ceiling | const int max_alloc_count = 25;; g_allocation_count = i; |
| test_alloc_ext_entity_realloc_buffer | 12 | expected reallocation schedule | const int max_realloc_count = 10; |
| test_alloc_ext_entity_set_encoding | 12 | allocation retry ceiling | const int max_allocation_count = 30;; g_allocation_count = i;; g_allocation_count = -1; |
| test_alloc_external_entity | 12 | allocation retry ceiling | const int alloc_test_max_repeats = 50;; g_allocation_count = -1;; g_allocation_count = i;; g_allocation_count = -1; |
| test_alloc_internal_entity | 12 | allocation retry ceiling | const unsigned int max_alloc_count = 20;; g_allocation_count = (int)i; |
| test_alloc_long_attr_default_with_char_ref | 12 | allocation retry ceiling | const int max_alloc_count = 20;; g_allocation_count = i; |
| test_alloc_long_attr_value | 12 | allocation retry ceiling | const int max_alloc_count = 25;; g_allocation_count = i; |
| test_alloc_long_base | 12 | allocation retry ceiling | const int max_alloc_count = 25;; g_allocation_count = i; |
| test_alloc_long_entity_value | 12 | allocation retry ceiling | const int max_alloc_count = 40;; g_allocation_count = i; |
| test_alloc_long_notation | 12 | allocation retry ceiling | const int max_alloc_count = 40;; g_allocation_count = i; |
| test_alloc_long_public_id | 12 | allocation retry ceiling | const int max_alloc_count = 40;; g_allocation_count = i; |
| test_alloc_nested_entities | 12 | fixed injection stage | g_allocation_count = 12; |
| test_alloc_nested_groups | 12 | allocation retry ceiling | const int max_alloc_count = 20;; g_allocation_count = i; |
| test_alloc_notation | 12 | allocation retry ceiling | const int max_alloc_count = 20;; g_allocation_count = i; |
| test_alloc_parameter_entity | 12 | allocation retry ceiling | const int alloc_test_max_repeats = 30;; g_allocation_count = i;; g_allocation_count = -1; |
| test_alloc_public_entity_value | 12 | allocation retry ceiling | const int max_alloc_count = 50;; g_allocation_count = i; |
| test_alloc_public_notation | 12 | allocation retry ceiling | const int max_alloc_count = 20;; g_allocation_count = i; |
| test_alloc_realloc_buffer | 12 | expected reallocation schedule | const int max_realloc_count = 10;; g_reallocation_count = i;; g_reallocation_count = -1; |
| test_alloc_realloc_ce_extends_pe | 2 | expected reallocation schedule | const int max_realloc_count = 5;; g_reallocation_count = i; |
| test_alloc_realloc_param_entity_newline | 2 | expected reallocation schedule | const int max_realloc_count = 5;; g_reallocation_count = i; |
| test_alloc_run_external_parser | 12 | allocation retry ceiling | const unsigned int max_alloc_count = 15;; g_allocation_count = (int)i; |
| test_alloc_set_foreign_dtd | 12 | allocation retry ceiling | const int max_alloc_count = 25;; g_allocation_count = i; |
| test_alloc_system_notation | 12 | allocation retry ceiling | const int max_alloc_count = 20;; g_allocation_count = i; |
| test_buffer_can_grow_to_max | 12 | one gib buffer harness and policy |  |
| test_bypass_heuristic_when_close_to_bufsize | 1 | allocation byte heuristic |  |
| test_misc_async_entity_rejected | 12 | error column |  |
| test_misc_input_2gb | 2 | large stream policy and reference timeout |  |
| test_misc_version | 12 | library version identity |  |
| test_nsalloc_long_context | 12 | allocation retry ceiling | const int max_alloc_count = 70;; g_allocation_count = i; |
| test_nsalloc_long_default_in_ext | 12 | allocation retry ceiling | const int max_alloc_count = 50;; g_allocation_count = i; |
| test_nsalloc_long_element | 12 | allocation retry ceiling | const int max_alloc_count = 30;; g_allocation_count = i; |
| test_nsalloc_long_systemid_in_ext | 12 | allocation retry ceiling | const int max_alloc_count = 55;; g_allocation_count = i; |
| test_nsalloc_parse_buffer | 12 | expected malloc after empty parsebuffer | g_allocation_count = 0;; g_allocation_count = ALLOC_ALWAYS_SUCCEED; |
| test_nsalloc_prefixed_element | 12 | allocation retry ceiling | const int max_alloc_count = 70;; g_allocation_count = i; |
| test_nsalloc_realloc_binding_uri | 12 | expected reallocation schedule | const unsigned max_realloc_count = 10;; g_reallocation_count = (int)i; |
| test_nsalloc_realloc_long_ge_name | 10 | allocation retry ceiling | const int max_realloc_count = 10;; g_reallocation_count = i; |
| test_nsalloc_realloc_long_prefix | 2 | expected reallocation schedule | const int max_realloc_count = 12;; g_reallocation_count = i; |
| test_nsalloc_realloc_longer_prefix | 2 | expected reallocation schedule | const int max_realloc_count = 12;; g_reallocation_count = i; |
| test_reparse_deferral_is_inherited | 12 | reparse deferral callback timing |  |

## Interpretation

**allocation retry ceiling:** The original bounded malloc/realloc retry loop still cannot complete. This is a retained allocation-cost compatibility gap; no larger retry ceiling or diagnostic replay is counted as a pass.

**expected reallocation schedule:** The assertion requires a realloc call and a failure at a particular budget. Parsing succeeds without that call for this context. The assertion remains failed; no artificial allocation is added to reproduce the schedule.

**fixed injection stage:** This test fixes g_allocation_count=12, intending failure inside the nested replacement. Oriole first fails external child creation instead. The first assertion fails at that earlier stage; this run does not prove the later fault location.

**one gib buffer harness and policy:** The first request is 1073741824 bytes, which cannot fit inside the same 1073741824-byte process address bound plus runtime. The exact same-bound reference also fails all 12. Oriole independently retains its 256MiB input reservation and 512MiB live-allocation caps. Neither fact overrides the failed count.

**allocation byte heuristic:** A post-token allocation delta exceeds the upstream <4096-byte heuristic. This is a real cost/deferral difference; one assertion does not establish either quadratic growth or harmless performance.

**error column:** The first failing asynchronous-entity case passes preceding rejection/error-kind/line checks but differs in error column. The test stops there; this report does not imply all subsequent subcases passed.

**large stream policy and reference timeout:** Only whole-input contexts execute the 2147483675-byte stream; other 10 return early. Oriole rejects at its 256MiB family input cap. Exact same-bound reference hits both 3-second per-test timeouts, so these observations do not establish reference success within that bound.

**library version identity:** The first assertion compares XML_ExpatVersionInfo() with the numeric components parsed from XML_ExpatVersion(): Oriole reports C API target 2.8.4 numerically and string oriole_0.0.1. This inconsistent numeric/string identity fails before the later header/literal assertion is reached; that later assertion is unobserved.

**expected malloc after empty parsebuffer:** Initial ParseBuffer before GetBuffer correctly fails NO_BUFFER in both engines. The failing second assertion blocks malloc after GetBuffer(1): Oriole uses no malloc and succeeds; Expat attempts one malloc and errors NO_MEMORY. See selected-allocator probe, with live allocation zero.

**reparse deferral callback timing:** The external child invokes its declaration callback earlier than the expected deferred-reparse point. This is observable callback-timing incompatibility, not proof that the setter or inheritance value was lost.

The298 retry-ceiling failures remain allocation-cost gaps. The12 fixed-stage,44 realloc-schedule and12 empty-parse malloc expectations remain failed original assertions too; explaining their cause does not make them passes. Exact per-context output, source bodies, hashes, and all584/14 comparison rows are retained in api-classification.json.

The earlier429-case classification mislabeled empty ParseBuffer as a preinitialization contract issue and grouped nested_entities with retry ceilings. The current source and selected allocator probe correct both labels. The historical large-input prefix performance measurements use an older Oriole binary and are not attributed to9cc.
