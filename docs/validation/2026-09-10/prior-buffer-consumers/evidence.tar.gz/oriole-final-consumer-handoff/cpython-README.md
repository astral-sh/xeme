# Final CPython consumer validation

The four shared/static × original/backported consumer configurations use the exact final Oriole libraries (`9cc87e9b…` shared; `b803db7d…` static).

Every strict CPython 3.12.13 run completed all six unchanged XML modules: **803 tests, 31 existing skips, two known fragmentation failures, exit 2**. The failures are `BufferTextTest.test1` and `CDATAHandlerTest.test_handlers`. The two separate, unchanged semantic checks pass in every configuration. No acceptance flag, added skip, alternate allocator, or test/source-limit change was used.

`review.json` summarizes the exact results, extensions and ELF dependencies. `results.json` retains full commands, original harness summaries, return codes, and output hashes; each configuration retains its original build, probe, upstream test and semantic logs. `setup.json` and `cpython-source.json` bind the tools, header, backport, final libraries, 64 runtime source files and all 4,737 clean CPython tracked files. All source hashes remain unchanged afterward.

All controllers, compilers and inherited children run on CPU 7. The managed controller/harness use Python `-I -S`; the unchanged harness requires `-s` and a pinned `PYTHONPATH`/`sitecustomize` loader for its fresh native extensions and test workers. The strict suite failures remain failures; this is not a claim that the unchanged CPython suite passes. Normal-allocation runs do not independently exercise the backport's allocation-failure fix.
