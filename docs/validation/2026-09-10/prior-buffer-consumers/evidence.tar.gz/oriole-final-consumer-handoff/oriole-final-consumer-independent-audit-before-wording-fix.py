"""Recompute saved API/W3C evidence; does not execute either test harness."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import os
import re

os.sched_setaffinity(0, {7})
W=Path('/tmp/oriole-final-consumer-validation')
A=Path('/tmp/oriole-attlist-capture-reserve/upstream-api')
B=Path('/tmp/oriole-upstream-grammar-combined')
OLD=Path('/tmp/oriole-w3c-grammar-combined')
L=Path('/tmp/oriole-large-input-followup-handoff')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
api=read(W/'api-classification.json'); w3c=read(W/'w3c-comparison.json')
hashes={}
for mapping in [api['input_hashes'],w3c['hashes']]:
    for path,expected in mapping.items():
        assert sha(path)==expected,path
        hashes[path]=expected
for name in ['classify_api.py','api-classification.json','api-classification.md','compare_w3c.py','w3c-comparison.json','probe_parsebuffer.py','parsebuffer-probe.json','w3c-introduced-diagnostics.json','w3c-reference-result-differences.json','rust-names-command.json','run_rust_names.py','w3c-command.json','w3c-source-recovery.json']:
    hashes[str(W/name)]=sha(W/name)

current=read(A/'results.json'); previous=read(B/'results.json'); manifest=read(A/'manifest.json')
key=lambda r:(r['test'],r['context'])
cm={key(r):r for r in current['results']}; pm={key(r):r for r in previous['results']}
assert len(cm)==len(current['results'])==len(pm)==len(previous['results'])==4740
assert cm.keys()==pm.keys()
assert Counter(r['outcome'] for r in cm.values())=={'pass':4323,'fail':417}
assert Counter(r['outcome'] for r in pm.values())=={'pass':3753,'fail':987}
assert current['excluded_internal_tests']==previous['excluded_internal_tests']
fixed=[{'before':pm[k],'after':r} for k,r in cm.items() if r['outcome']=='pass' and pm[k]['outcome']=='fail']
new=[{'before':pm[k],'after':r} for k,r in cm.items() if r['outcome']=='fail' and pm[k]['outcome']=='pass']
retained=[r for k,r in cm.items() if r['outcome']==pm[k]['outcome']=='fail']
assert [len(fixed),len(new),len(retained)]==[584,14,403]
assert api['comparison']['fixed']==fixed and api['comparison']['newly_failed']==new and api['comparison']['retained_failed']==retained
assert Counter(row['after']['test'] for row in new)=={'test_nsalloc_realloc_binding_uri':10,'test_alloc_realloc_ce_extends_pe':2,'test_alloc_realloc_param_entity_newline':2}
logs={}; context=None
for line in (A/'tests.log').read_text().splitlines():
    if line.startswith('ORIOLE_BEGIN\t'):
        _,ctx,name=line.split('\t');context=(name,ctx);assert context not in logs;logs[context]=[]
    elif line.startswith('ORIOLE_RESULT\t'):context=None
    elif context is not None:logs[context].append(line)
assert len(logs)==4740
for name,expected in manifest['adapted_sources'].items():
    assert sha(A/'adapted'/name)==expected,name
    hashes[str(A/'adapted'/name)]=expected
category_counts=Counter(); observed_keys=set(); stages=[]
for test in api['tests']:
    name=test['test']; info=test['source']; source=Path(info['file']);body=(W/info['body_file']).read_text(); text=source.read_text()
    assert sha(source)==info['source_sha256'] and sha(W/info['body_file'])==info['body_sha256']
    match=re.search(r'START_TEST\('+re.escape(name)+r'\)(.*?)END_TEST',text,re.S)
    assert match and body==match[0]+'\n' and text[:match.start()].count('\n')+1==info['start_line']
    bounds=[line.strip() for line in body.splitlines() if re.search(r'(?:(?:max_\w+|alloc_test_max_repeats)\s*=|g_(?:allocation|reallocation)_count\s*=)',line)]
    assert bounds==info['budget_statements']
    assert len(test['observations'])==test['failed_contexts']
    category_counts[test['category']]+=len(test['observations'])
    locations=set()
    for observation in test['observations']:
        row=observation['result'];k=key(row)
        assert k not in observed_keys;observed_keys.add(k)
        assert row==cm[k] and row['outcome']=='fail' and observation['diagnostics']==logs[k]
        for line in observation['diagnostics']:
            m=re.match(r'ASSERTION: (\w+) at (.+):(\d+)$',line)
            if m:
                assert m[1]==name
                path=Path(m[2]);number=int(m[3]);lines=path.read_text().splitlines()
                assert 1<=number<=len(lines)
                locations.add((str(path),number,'\n'.join(lines[max(0,number-3):number+1])))
    assert locations
    stages.append({'test':name,'category':test['category'],'contexts':test['failed_contexts'],'literal_bounds':bounds,'first_failure_source_windows':sorted(locations),'body_sha256':info['body_sha256']})
assert observed_keys=={k for k,r in cm.items() if r['outcome']=='fail'}
assert len(stages)==api['test_count']==40 and category_counts==api['category_counts']
assert sum(category_counts.values())==417
assert api['bounds']=={key:manifest[key] for key in api['bounds']}
assert manifest['per_test_seconds']==3 and manifest['per_test_address_space_bytes']==1073741824 and manifest['per_test_rss_limit_bytes']==805306368
assert manifest['chunks']==list(range(6)) and manifest['deferral']==[0,1]

probe=read(W/'parsebuffer-probe.json')
assert probe==api['parsebuffer_probe'] and len(probe['rows'])==2
for row in probe['rows']:
    assert sha(row['library'])==row['sha256'] and row['live_after_free']==0
    assert row['stages'][0]['status']==0 and row['stages'][0]['error']==42
    assert row['stages'][2]['status']==1 and row['stages'][2]['error']==0
assert probe['rows'][0]['stages'][1]=={'step':'after GetBuffer with malloc disabled','status':1,'error':0,'malloc_calls':0,'actual_malloc_failures':0}
assert probe['rows'][1]['stages'][1]=={'step':'after GetBuffer with malloc disabled','status':0,'error':1,'malloc_calls':1,'actual_malloc_failures':1}
large=read(L/'summary.json')
stream=read(L/'reference-stream/results.json'); buffer=read(L/'reference-buffer/results.json')
assert Counter(r['outcome'] for r in stream['results'])=={'pass':10,'timeout':2}
assert Counter(r['outcome'] for r in buffer['results'])=={'fail':12}
assert 524288*4096+27==2147483675
assert large['libraries']['oriole']['sha256']=='390071e398a62809dbbc5443e46ad1f574a8364647b42ed475dee6829ba60a53'
assert 'numeric XML_ExpatVersionInfo' in next(t for t in api['tests'] if t['test']=='test_misc_version')['explanation']

summary=read(W/'w3c/summary.json');catalog=read(W/'w3c/catalog.json');cat={row['ID']:row for row in catalog}
assert len(cat)==len(catalog)==2585
ref=read(W/'w3c/reference.json');ori=read(W/'w3c/oriole.json');oldref=read(OLD/'reference.json');oldori=read(OLD/'oriole.json')
assert ref['rows']==oldref['rows']
assert sha(ref['library'])==ref['sha256']=='7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'
assert sha(ori['library'])==ori['sha256']==manifest['library_sha256']=='9cc87e9bc5c22dfc33eba7bf074908421dd7b1c303920f9c8021eab887793213'
assert len(ref['rows'])==len(ori['rows'])==len(oldori['rows'])==6003
wkey=lambda row:(row['id'],row['chunk'])
assert len({wkey(row) for row in ori['rows']})==6003
counts_by_engine={}
for label,data in [('reference',ref),('oriole',ori)]:
    counts=Counter();mismatches=[]
    for row in data['rows']:
        assert not row['result']['resolver_errors']
        if row['type']=='error':counts['optional']+=1;continue
        passed=(row['result']['status']==1)==(row['type'] in ['valid','invalid'])
        counts['pass' if passed else 'fail']+=1
        if not passed:mismatches.append(row)
    assert counts=={'pass':4962,'fail':960,'optional':81}
    assert mismatches==summary['mismatches'][label]==w3c['current_mandatory_failures'][label]
    counts_by_engine[label]=dict(counts)
changes=[];differences=[];introduced=[]
for before,after,reference in zip(oldori['rows'],ori['rows'],ref['rows'],strict=True):
    assert wkey(before)==wkey(after)==wkey(reference)
    if before['result']['status']!=after['result']['status']:
        metadata=cat[after['id']]
        assert metadata['EDITION']=='5' and metadata['RECOMMENDATION']=='XML1.0-errata4e'
        assert before['result']['status']==1 and after['result']['status']==reference['result']['status']==0
        assert after['result']['error']==reference['result']['error']==4
        changes.append({'before':before,'after':after,'reference':reference,'catalog':{k:metadata[k] for k in ['TYPE','RECOMMENDATION','EDITION','SECTIONS'] if k in metadata}})
    if reference['result']!=after['result']:differences.append({'reference':reference,'oriole':after})
    sig=lambda row:(row['result']['status'],row['result']['error'])
    if sig(before)==sig(reference) and sig(after)!=sig(reference):introduced.append({'old':before,'new':after,'reference':reference})
assert changes==w3c['name_edition_changes'] and len(changes)==954 and len({r['after']['id'] for r in changes})==318
assert Counter(r['after']['type'] for r in changes)=={'valid':918,'invalid':36}==w3c['changed_type_counts']
assert differences==read(W/'w3c-reference-result-differences.json') and len(differences)==1785
assert sum((x['result']['status'],x['result']['error'])!=(y['result']['status'],y['result']['error']) for x,y in zip(ref['rows'],ori['rows']))==225
assert all(x['result']['status']==y['result']['status'] for x,y in zip(ref['rows'],ori['rows']))
assert introduced==read(W/'w3c-introduced-diagnostics.json') and len(introduced)==3
assert {r['new']['id'] for r in introduced}=={'ibm-not-wf-P51-ibm51n05.xml'}
boundary=[json.loads(line) for line in (W/'rust-names.stdout').read_text().splitlines()]
assert boundary==w3c['rust_boundary_controls']['records'] and len(boundary)==30
assert len({r['file'] for r in boundary})==5
assert Counter((r['fourth'],r['accepted'],r['error']) for r in boundary)=={(False,True,'None'):15,(True,False,'Some(InvalidToken)'):15}
rust=read(W/'rust-names-command.json')
for path,expected in (rust['inputs']|rust['source']).items():assert sha(path)==expected;hashes[path]=expected
recovery=read(W/'w3c-source-recovery.json');suite=Path(recovery['suite'])
assert sha(recovery['archive'])==recovery['sha256']
for relative,expected in summary['catalog_source_sha256'].items():assert sha(suite/relative)==expected
assert len(summary['catalog_source_sha256'])==recovery['verified_files']==3387
assert summary['catalog_source_sha256']==read(OLD/'summary.json')['catalog_source_sha256']

report={
 'scope':'Read-only independent audit of stored results, source bodies, helper assertion sites, arithmetic and hashes. No parser/API/W3C/Rust tests, builds, or probes executed.',
 'status':'Verified, including the corrected first version-assertion explanation. Original failed outcomes remain failed.',
 'api':{'contexts':4740,'current':{'pass':4323,'fail':417,'timeout':0},'historical':{'pass':3753,'fail':987},'fixed':584,'newly_failed':14,'retained_failed':403,'failing_names':40,'category_counts':dict(category_counts),'categories_explain_first_failure_only':True,'bounds':api['bounds'],'private_tests_excluded':len(current['excluded_internal_tests']),'source_body_assertion_audit':stages},
 'parsebuffer':{'source_sequence_verified':True,'before_getbuffer_both':{'status':0,'error':42},'after_getbuffer_malloc_disabled':{'oriole':{'status':1,'error':0,'malloc_calls':0},'reference':{'status':0,'error':1,'malloc_calls':1}},'restored_both_success':True,'live_after_free_both':0,'scope':'The short separate diagnostic probe does not execute the later resume/suspend assertions of the original body. It matches the first failing stage and does not change any original result.'},
 'w3c':{'rows_per_engine':6003,'descriptors_selected':2001,'counts_by_engine':counts_by_engine,'historical_reference_rows_identical':True,'current_acceptance_differences':0,'current_status_or_error_differences':225,'current_full_result_differences':1785,'edition_acceptance_changes':954,'edition_descriptor_changes':318,'changed_types':{'valid':918,'invalid':36},'new_status_error_disagreements':3,'new_disagreement_descriptor':'ibm-not-wf-P51-ibm51n05.xml','recovered_suite_files_verified':3387,'rust_boundary_conditions':30,'rust_boundary_descriptors':5,'rust_default_fifth_accepts':15,'rust_explicit_fourth_rejects_invalid_token':15},
 'correction_during_review':'Version category remains 12, but first failing assertion compares XML_ExpatVersionInfo numeric API target 2.8.4 against parsed oriole_0.0.1 string. The later expat_2.8.4 literal assertion is not reached. Author corrected generator and reports; no runtime or result changed.',
 'historical_large_input':{'same_bound_buffer_reference_failures':12,'same_bound_stream_reference_timeouts':2,'stream_early_return_passes':10,'stream_total_bytes':2147483675,'historical_oriole_library':large['libraries']['oriole']['sha256'],'current_prefix_timings_inferred':False},
 'caveats':['Retry ceilings are literal finite loops (typically i < max), not guarantees that the ceiling itself was attempted. No increased-budget probe is counted as success.','Version identity, callback timing, error columns and allocation-cost/schedule differences remain compatibility failures, regardless of category.','The 768 MiB RSS value is the requested harness limit; RLIMIT_RSS enforcement is platform-dependent.','The 1 GiB buffer request cannot fit in the same 1 GiB address-space bound plus runtime. Reference same-bound failures and timeouts do not prove a reference pass. Historical 390071e prefix cost/timing data is not attributed to 9cc.','The unchanged Fifth Edition W3C selection still has 960 mandatory failures per engine with Fourth Edition C defaults; matching reference acceptance does not make those mandatory failures passes.','The Rust name control covers five descriptors at three widths in two configurations only, not a complete Rust W3C campaign.','ParseBuffer probe callbacks remain live through parser free, selected malloc alone is blocked, and realloc remains enabled as in the upstream stage. The probe stores zero-live counters but is not a native sanitizer or exhaustive OOM sweep.'],
 'input_sha256_verified':hashes,
}
out=Path('/tmp/oriole-final-consumer-independent-review.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':sha(out),'verified_input_hashes':len(hashes),'api_categories':dict(category_counts),'w3c':report['w3c']},indent=2))
