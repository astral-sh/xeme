# Final optimized-build correctness

This package tests the final portable PGO tool output, shared bb43c2fc and static5907851e, against the exact64 source files of normal9cc. PGO build provenance is retained by hash and manifest; training and performance evidence are separate.

All4,740 original public API outcomes exactly match the normal build:4,323 pass and417 fail. The entire result JSON is byte-identical. Original assertions, exclusions and resource bounds remain intact.

All six C ASan/UBSan runs pass across shared/static integration, adversarial and allocation tests. Both allocation runs cover327 scenarios; all six raw output logs exactly match normal9cc. Sanitizers instrument the C drivers; the optimized Rust library is uninstrumented, and LeakSanitizer is disabled. Selected allocator ownership checks remain enabled.

All four CPython configurations run803 original tests,31 existing skips and two known text-fragmentation failures, preserving strict exit2. Each separate two-test semantic gate passes. This does not count the original consumer suite as a pass or independently establish the normal-allocation backport fault fix.

The source, library and recorded tool hashes remain unchanged after the gates. The API frozen adapter folder omits unused README/allocator_repro files and includes the unchanged isolated launcher: all used adapters, every adapted test and all bounds match the normal run. Compiler executable identities in native-audit.json are explicitly captured after the run; commands/results were recorded during execution.

No compiled binaries or build caches are distributed here. Original logs, source files, commands, comparison rows and archived member hashes remain available. W3C and sustained Rust sanitizer campaigns are outside this package.
