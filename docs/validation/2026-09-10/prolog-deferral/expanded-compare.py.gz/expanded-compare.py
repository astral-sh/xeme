from pathlib import Path
import hashlib,json
base=Path('/home/dev-user/.cache/oriole/differential-diagnostic-expanded')
out=Path('/tmp/oriole-differential-prolog-expanded')
fields=['status','error','normalized_events','events','position','callback_errors']
reference=json.loads((base/'reference.json').read_text())
actual=json.loads((out/'oriole.json').read_text())
previous=json.loads((base/'oriole.json').read_text())
counts=dict.fromkeys(fields,0)
changes={'fixed':0,'new':0,'changed':0}
differences=[]
for ref,got,old in zip(reference['results'],actual['results'],previous['results'],strict=True):
    assert (ref['name'],ref['chunk_size'])==(got['name'],got['chunk_size'])==(old['name'],old['chunk_size'])
    mismatch=[k for k in fields if ref['result'][k]!=got['result'][k]]
    oldm=[k for k in fields if ref['result'][k]!=old['result'][k]]
    for k in mismatch: counts[k]+=1
    if mismatch:
        differences.append({'name':got['name'],'chunk_size':got['chunk_size'],'fields':mismatch,'reference':ref['result'],'oriole':got['result']})
    if oldm and not mismatch: changes['fixed']+=1
    if mismatch and not oldm: changes['new']+=1
    if mismatch and oldm and got['result']!=old['result']: changes['changed']+=1
files=[base/'corpus.json',base/'reference.json',base/'oriole.json',out/'oriole.json',Path('/tmp/oriole-prolog-evidence/liboriole_expat.so')]
summary={'cases':len(actual['results']),'difference_counts':counts,'compared_to_diagnostic':changes,'semantic_pass':not any(counts[k] for k in ['status','error','normalized_events','callback_errors']),'exact_pass':not any(counts.values()),'files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'differences':differences}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='differences'},indent=2))
