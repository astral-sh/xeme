import base64, ctypes as c, hashlib, json, sys
from pathlib import Path
sys.path.insert(0, '/home/dev-user/code/oss/oriole/tools')
from xml_abi import Expat, TEXT, START, END
ref_path='/home/dev-user/.cache/oriole/expat-build/libexpat.so'
candidate_path='/home/dev-user/.cache/oriole/diagnostic-followup-target/debug/liboriole_expat.so'
reference=Expat(ref_path)
candidate=Expat(candidate_path)

def compare(xml, width=1):
 return reference.parse(xml,width), candidate.parse(xml,width)

def mismatch(xml):
 a,b=compare(xml)
 return a['error']==b['error']==4 and a['normalized_events']!=b['normalized_events']

def minimize(xml):
 n=2
 while len(xml)>=2:
  size=(len(xml)+n-1)//n
  reduced=False
  for i in range(0,len(xml),size):
   trial=xml[:i]+xml[i+size:]
   if mismatch(trial):
    xml=trial;n=max(2,n-1);reduced=True;break
  if not reduced:
   if n>=len(xml):break
   n=min(len(xml),n*2)
 return xml

def trace(engine, xml, width=1, deferral=True):
 lib=engine.lib;p=lib.XML_ParserCreate(None);events=[];offset=[0]
 lib.XML_SetReparseDeferralEnabled.argtypes=[c.c_void_p,c.c_ubyte]
 lib.XML_SetReparseDeferralEnabled(p,deferral)
 callbacks=(START(lambda _,n,a:events.append([offset[0],'start',n.decode()])),END(lambda _,n:events.append([offset[0],'end',n.decode()])),TEXT(lambda _,s,n:events.append([offset[0],'text',c.string_at(s,n).decode()])))
 lib.XML_SetElementHandler(p,*callbacks[:2]);lib.XML_SetCharacterDataHandler(p,callbacks[2])
 for i in range(0,len(xml),width):
  chunk=xml[i:i+width];offset[0]=i+len(chunk)
  status=lib.XML_Parse(p,chunk,len(chunk),offset[0]==len(xml))
  if status!=1:break
 result={'events':events,'status':status,'error':lib.XML_GetErrorCode(p),'offset':lib.XML_GetCurrentByteIndex(p)}
 lib.XML_ParserFree(p);return result

if __name__=='__main__':
 selected=json.loads(Path('/tmp/oriole-prolog-selected.json').read_text())
 output=[]
 for row in selected:
  if 'normalized_events' not in row['fields']:continue
  xml=base64.b64decode(row['input']['base64']); minimal=minimize(xml)
  print(row['name'],repr(minimal),flush=True)
  output.append({'name':row['name'],'original_hex':xml.hex(),'minimized_hex':minimal.hex(),'reference':trace(reference,minimal),'candidate':trace(candidate,minimal)})
 quote=[]
 for xml in [b'"',b'"x',b'"x"',b'"x" ',b'"x"y',b'"<"x',b'\'x\'x',b'"x\x01',b'"x\xf0',b' \"x\"y',b'\r\n\"x\"y',b'"x">',b'"x"<r/>',b'"x"[',b'"x"%',b'"x"\xff',b'\"x\"\xf0']:
  quote.append({'xml_hex':xml.hex(),'reference':trace(reference,xml),'candidate':trace(candidate,xml)})
 Path('/tmp/oriole-prolog-oracle.json').write_text(json.dumps({'minimal_text':output,'quoted_prolog':quote},indent=2)+'\n')
 print(json.dumps(output,indent=2))
 print(json.dumps(quote,indent=2))
