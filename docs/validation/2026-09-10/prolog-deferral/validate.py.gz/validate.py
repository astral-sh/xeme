import base64,ctypes as c,hashlib,importlib.util,json,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('probe','/tmp/oriole-prolog-probe.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
lib='/tmp/oriole-prolog-evidence/liboriole_expat.so'
engine=m.Expat(lib)
selected=json.loads(Path('/tmp/oriole-prolog-selected.json').read_text())
rows=[]
for row in selected:
 case=row['input'];result=engine.parse(base64.b64decode(case['base64']),case['chunk_size'],case['namespaces'])
 differences=[key for key in ['status','error','normalized_events','events','position','callback_errors'] if row['reference'][key]!=result[key]]
 rows.append({'name':case['name'],'chunk_size':case['chunk_size'],'input':case,'fields':differences,'reference':row['reference'],'candidate':result})
quoted=[]
for prefix in ['', ' ', '\r\n', '\t']:
 for quote in ['"',"'"]:
  for content in ['', 'x', 'é', '<', '\r\n', ']]>', 'x\u0001']:
   for ending in ['',quote,quote+'y',quote+' ',quote+'<',quote+'é',quote+'%',quote+'[']:
    xml=(prefix+quote+content+ending).encode()
    for width in sorted(set([1,2,3,7,len(xml)])):
     for deferral in [False,True]:
      a=m.trace(m.reference,xml,width,deferral);b=m.trace(engine,xml,width,deferral)
      if a!=b:quoted.append({'xml_hex':xml.hex(),'width':width,'deferral':deferral,'reference':a,'candidate':b})
text=[]
for prefix in [b'<r>',b'<r>&amp;',b'<r>&#65;',b'<r>&#x41;',b'<r><a/>',b'<r><a></a>',b'<r><a>&#65;</a>']:
 for n in range(1,33):
  for value in [b'e',b'te',b'text']:
   xml=prefix+b'<n a="'+b'x'*n+b'">'+value+b']]>'
   a=m.reference.parse(xml,1);b=engine.parse(xml,1)
   if any(a[k]!=b[k] for k in ['status','error','normalized_events']):text.append({'xml_hex':xml.hex(),'reference':a,'candidate':b})
summary={'candidate_sha256':hashlib.sha256(Path(lib).read_bytes()).hexdigest(),'selected_cases':len(rows),'selected_semantic_differences':sum(bool(set(r['fields'])&{'status','error','normalized_events'}) for r in rows),'quoted_comparisons':4248,'quoted_differences':len(quoted),'text_comparisons':672,'text_differences':len(text),'selected':rows,'quoted':quoted,'text':text}
Path('/tmp/oriole-prolog-evidence/validation.json').write_text(json.dumps(summary,indent=2)+'\n')
print({k:v for k,v in summary.items() if not isinstance(v,list)})
print('selected remaining',[(r['name'],r['chunk_size'],r['fields']) for r in rows if set(r['fields'])&{'status','error','normalized_events'}])
print('quote examples',quoted[:10]);print('text examples',text[:2])
