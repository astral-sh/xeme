import ctypes as c
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/oriole-prolog-review')
LIB = Path('/tmp/oriole-prolog-evidence/liboriole_expat.so')
EXPECTED = '5a979d284b776f0faca871b41ce36badd5d280cb4bb8bb61fbf509094aa13fa5'
assert hashlib.sha256(LIB.read_bytes()).hexdigest() == EXPECTED
P, S, I = c.c_void_p, c.c_char_p, c.c_int
TEXT = c.CFUNCTYPE(None, P, P, I)
START = c.CFUNCTYPE(None, P, S, c.POINTER(S))
END = c.CFUNCTYPE(None, P, S)

def load(path):
    lib = c.CDLL(str(path))
    for name, result, args in [
        ('XML_ParserCreate', P, [S]), ('XML_ParserFree', None, [P]),
        ('XML_Parse', I, [P, S, I, I]), ('XML_StopParser', I, [P, c.c_ubyte]),
        ('XML_ResumeParser', I, [P]), ('XML_GetErrorCode', I, [P]),
        ('XML_GetCurrentByteIndex', c.c_long, [P]),
        ('XML_SetDefaultHandler', None, [P, TEXT]),
        ('XML_SetCharacterDataHandler', None, [P, TEXT]),
        ('XML_SetElementHandler', None, [P, START, END]),
        ('XML_SetReparseDeferralEnabled', c.c_ubyte, [P, c.c_ubyte]),
    ]:
        f = getattr(lib, name)
        f.restype, f.argtypes = result, args
    return lib

def parse(lib, data, width, deferral, suspend, default):
    parser = lib.XML_ParserCreate(None)
    events, stops, status_trace = [], [], []
    def text(_, pointer, length):
        value = c.string_at(pointer, length).decode()
        events.append(['default' if default else 'text', value])
        stops.append(lib.XML_StopParser(parser, suspend))
    callbacks = [TEXT(text), START(lambda _, name, attrs: events.append(['start', name.decode()])),
                 END(lambda _, name: events.append(['end', name.decode()]))]
    lib.XML_SetReparseDeferralEnabled(parser, deferral)
    lib.XML_SetElementHandler(parser, callbacks[1], callbacks[2])
    getattr(lib, 'XML_SetDefaultHandler' if default else 'XML_SetCharacterDataHandler')(parser, callbacks[0])
    status = 1
    for offset in range(0, len(data), width):
        part = data[offset:offset+width]
        status = lib.XML_Parse(parser, part, len(part), int(offset+width >= len(data)))
        status_trace.append(status)
        resumed = 0
        while status == 2:
            status = lib.XML_ResumeParser(parser)
            status_trace.append(status)
            resumed += 1
            assert resumed < 100
        if status == 0:
            break
    normalized = []
    for event in events:
        if normalized and event[0] in ['text', 'default'] and normalized[-1][0] == event[0]:
            normalized[-1][1] += event[1]
        else:
            normalized.append(event.copy())
    result = {'status': status, 'error': lib.XML_GetErrorCode(parser),
              'index': lib.XML_GetCurrentByteIndex(parser), 'events': events,
              'normalized': normalized, 'stops': stops, 'statuses': status_trace}
    lib.XML_ParserFree(parser)
    return result

reference = load('/home/dev-user/.cache/oriole/expat-build/libexpat.so')
candidate = load(LIB)
cases = [(value, True) for value in [b' "x"y', b'\r\n\t\'x\'', b' \"x\xf0', b' \"x\"\xff', b' \"x\x01']]
cases += [(value, False) for value in [b'<r>&#x41;<n a="x">e]]>', b'<r>&amp;x</r>',
                                      b'<r>&#65;&amp;&#x4e2d;</r>', b'<r>a&#65;b</r>',
                                      b'<r>a&#65;]]>', b'<r>&#x41;<n a="xx">text</n></r>']]
rows, differences = [], []
for data, default in cases:
    for width in range(1, len(data)+1):
        for deferral in [False, True]:
            for suspend in [False, True]:
                a = parse(reference, data, width, deferral, suspend, default)
                b = parse(candidate, data, width, deferral, suspend, default)
                row = {'hex': data.hex(), 'chunk': width, 'deferral': deferral,
                       'suspend': suspend, 'default': default, 'reference': a, 'candidate': b}
                rows.append(row)
                if any(a[key] != b[key] for key in ['status', 'error', 'index', 'normalized']) or not all(b['stops']):
                    differences.append(row)
assert hashlib.sha256(LIB.read_bytes()).hexdigest() == EXPECTED
(ROOT/'suspension.json').write_text(json.dumps({'library':str(LIB),'sha256':EXPECTED,
                                            'cases':len(rows),'differences':differences},indent=2)+'\n')
print('cases',len(rows),'differences',len(differences))
unique={}
for row in differences:
    key=(row['hex'],row['suspend'],json.dumps(row['reference']['normalized']),json.dumps(row['candidate']['normalized']),row['reference']['error'],row['candidate']['error'])
    unique.setdefault(key,row)
for row in list(unique.values())[:10]:print(json.dumps(row))
