import ctypes as c
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/oriole-diagnostic-review')
CANDIDATE = Path('/tmp/oriole-final-encoding-checkpoint/liboriole_expat.so')
EXPECTED = '912be874c54d597733a986c7cd3d0ea0bd36e0329e50b84c633908d59e1163f6'
assert hashlib.sha256(CANDIDATE.read_bytes()).hexdigest() == EXPECTED

class Library:
    def __init__(self, path):
        self.lib = c.CDLL(str(path))
        for name, result, args in [
            ('XML_ParserCreate', c.c_void_p, [c.c_char_p]),
            ('XML_ParserFree', None, [c.c_void_p]),
            ('XML_Parse', c.c_int, [c.c_void_p, c.c_char_p, c.c_int, c.c_int]),
            ('XML_SetParamEntityParsing', c.c_int, [c.c_void_p, c.c_int]),
            ('XML_SetReparseDeferralEnabled', c.c_ubyte, [c.c_void_p, c.c_ubyte]),
            ('XML_GetErrorCode', c.c_int, [c.c_void_p]),
            ('XML_GetCurrentByteIndex', c.c_long, [c.c_void_p]),
            ('XML_GetCurrentLineNumber', c.c_ulong, [c.c_void_p]),
            ('XML_GetCurrentColumnNumber', c.c_ulong, [c.c_void_p]),
        ]:
            fn = getattr(self.lib, name)
            fn.restype, fn.argtypes = result, args

    def parse(self, data, chunk, deferral):
        l = self.lib
        parser = l.XML_ParserCreate(None)
        assert parser
        l.XML_SetParamEntityParsing(parser, 2)
        l.XML_SetReparseDeferralEnabled(parser, deferral)
        status = 1
        for offset in range(0, len(data), chunk):
            part = data[offset:offset+chunk]
            status = l.XML_Parse(parser, part, len(part), int(offset+chunk >= len(data)))
            if status == 0:
                break
        result = [status, l.XML_GetErrorCode(parser), l.XML_GetCurrentByteIndex(parser),
                  l.XML_GetCurrentLineNumber(parser), l.XML_GetCurrentColumnNumber(parser)]
        l.XML_ParserFree(parser)
        return result

reference = Library('/home/dev-user/.cache/oriole/expat-build/libexpat.so')
candidate = Library(CANDIDATE)
cases = []
references = ['&', '&é', '&é/', '&中/', '&𐀀/', '&\u0301', '&é\u0301/', '&\u00b7',
              '&\ufffe', '&\uffff', '&\U00100000', '&#', '&#x', '&#x;', '&#X', '&#xＧ',
              '&#١', '&#x0;', '&#xD800;', '&#x10ffff;', '&#x110000;', '&#9z']
for value in references:
    cases.append(('reference:' + repr(value), '<r>' + value))
for name in ['r', 'é', '中文', 'r\u0301', 'r\u00b7', '𐀀']:
    for ending in ['>', ' >', '\t>', '\r>', '\n>', '\r\n>', ' \r\n', '/', '"', "'", ' x', '\u00a0', '\u0001']:
        cases.append(('endtag:' + repr((name, ending)), '<' + name + '></' + name + ending))
    cases.append(('entity:' + name, f'<!DOCTYPE r [<!ENTITY {name} "v">]><r>&{name};</r>'))
    cases.append(('parameter:' + name, f'<!DOCTYPE r [<!ENTITY % {name} "<!ELEMENT r EMPTY>">%{name};]><r/>'))
for value in ['%é/', '%中/', '%\u0301', '%9', '%#x', '%;', '%é ', '%é\x01']:
    cases.append(('parameter-invalid:' + repr(value), '<!DOCTYPE r [' + value))

results = []
differences = []
for label, xml in cases:
    for encoding in ['utf-8', 'utf-16-le', 'utf-16-be']:
        prefix = {'utf-8': b'', 'utf-16-le': b'\xff\xfe', 'utf-16-be': b'\xfe\xff'}[encoding]
        data = prefix + xml.encode(encoding)
        for deferral in [False, True]:
            for chunk in range(1, len(data)+1):
                before, after = reference.parse(data, chunk, deferral), candidate.parse(data, chunk, deferral)
                record = {'label': label, 'encoding': encoding, 'chunk': chunk,
                          'deferral': deferral, 'reference': before, 'candidate': after}
                results.append(record)
                if before != after:
                    differences.append(record)

for label, prefix in [('invalid-reference', '<r>&é/'), ('valid-reference', '<r>&é'),
                      ('invalid-endtag', '<é></é"'), ('valid-endtag', '<é></é')]:
    for encoding, bom, suffix in [('utf-8', b'', b'\xf0'),
                                  ('utf-16-le', b'\xff\xfe', b'\x00\xd8'),
                                  ('utf-16-be', b'\xfe\xff', b'\xd8\x00'),
                                  ('utf-16-le-odd', b'\xff\xfe', b'x')]:
        codec = encoding.removesuffix('-odd')
        data = bom + prefix.encode(codec) + suffix
        for chunk in range(1, len(data)+1):
            before, after = reference.parse(data, chunk, False), candidate.parse(data, chunk, False)
            record = {'label': label, 'encoding': encoding, 'chunk': chunk,
                      'deferral': False, 'reference': before, 'candidate': after}
            results.append(record)
            if before != after:
                differences.append(record)

assert hashlib.sha256(CANDIDATE.read_bytes()).hexdigest() == EXPECTED
(ROOT / 'baseline-results.json').write_text(json.dumps({'candidate': str(CANDIDATE), 'sha256': EXPECTED,
                                             'cases': len(results), 'differences': differences}, indent=2) + '\n')
print('cases', len(results), 'differences', len(differences))
unique = {}
for case in differences:
    key = (case['label'], case['encoding'], tuple(case['reference']), tuple(case['candidate']))
    unique.setdefault(key, case)
print('unique', len(unique))
for case in list(unique.values())[:50]:
    print(json.dumps(case))
