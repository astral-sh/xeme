import hashlib,json,subprocess,shutil
from pathlib import Path
out=Path('/tmp/oriole-string-inline-timing-study')
assert not (out/'native-screen').exists()
command=['taskset','-c','3','python3',str(out/'native_screen.py'),'preflight']
with (out/'preflight-corrected.log').open('wb') as log:
 run=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=600)
report={'status':'passed' if run.returncode==0 else 'failed','command':command,'exit':run.returncode,'controller_sha256':hashlib.sha256((out/'native_screen.py').read_bytes()).hexdigest(),'note':'Initial outer preparation scheduled CPU4 but unchanged native controller requires CPU3; it failed before creating the worker output directory or invoking any worker. Rescheduled unchanged controller to CPU3 after other CPU3 work completed. Initial preparation and log retained; no source or worker rerun.'}
(out/'preflight-correction.json').write_text(json.dumps(report,indent=2)+'\n')
shutil.copy2(__file__,out/Path(__file__).name)
print(json.dumps(report),flush=True)
raise SystemExit(run.returncode)
