import hashlib,io,json,shutil,tarfile
from pathlib import Path
repo=Path('/home/dev-user/code/oss/oriole-scanner-integration');out=repo/'docs/validation/2026-09-10/scanner-integration';out.mkdir(parents=True,exist_ok=False)
directories={
 'integrated/source-build-profiles':'/tmp/oriole-scanner-integration-study',
 'integrated/gates':'/tmp/oriole-scanner-integration-gates',
 'integrated/cpython':'/tmp/oriole-scanner-integration-cpython-gates',
 'integrated/native':'/tmp/oriole-scanner-integration-timing-study',
 'integrated/python':'/tmp/oriole-scanner-integration-python-study',
 'position/source-build-profiles':'/tmp/oriole-position-words-study',
 'position/gates':'/tmp/oriole-position-words-gates-handoff',
 'position/cpython':'/tmp/oriole-position-words-cpython-gates',
 'position/native':'/tmp/oriole-position-words-timing-study',
 'position/python':'/tmp/oriole-position-words-python-study',
 'position/reviews/source':'/tmp/oriole-position-words-independent-review',
 'position/reviews/native':'/tmp/oriole-position-words-native-independent-review',
 'position/reviews/python':'/tmp/oriole-position-words-python-independent-review',
 'position/reviews/cpython':'/tmp/oriole-position-words-compat-independent-review',
 'string/source-build-profiles':'/tmp/oriole-string-inline-study',
 'string/gates':'/tmp/oriole-string-inline-gates-handoff',
 'string/native':'/tmp/oriole-string-inline-timing-study',
 'string/python':'/tmp/oriole-string-inline-python-study',
 'string/reviews/source':'/tmp/oriole-string-inline-independent-review',
 'string/reviews/native':'/tmp/oriole-string-inline-native-independent-review',
 'string/reviews/python':'/tmp/oriole-string-inline-python-independent-review',
 'integrated/reviews/native':'/tmp/oriole-scanner-integration-native-independent-review',
 'integrated/reviews/python':'/tmp/oriole-scanner-integration-independent-review/python',
 'integrated/reviews/cpython':'/tmp/oriole-scanner-integration-independent-review/cpython',
}
controllers=[
 '/tmp/oriole-package-scanner-integration.py','/tmp/oriole-summarize-cohorts.py',
 '/tmp/oriole-scanner-integration-components.json','/tmp/oriole-scanner-integration-assembly.json',
 '/tmp/oriole-build-scanner-integration.py','/tmp/oriole-prepare-scanner-integration-gates.py',
 '/tmp/oriole-prepare-integration-timing.py','/tmp/oriole-time-integration-native.py',
 '/tmp/oriole-prepare-integration-python.py','/tmp/oriole-time-integration-python.py','/tmp/oriole-integration-cpython-gates.py',
 '/tmp/oriole-prepare-position-timing.py','/tmp/oriole-time-position-native.py',
 '/tmp/oriole-prepare-position-python.py','/tmp/oriole-time-position-python.py','/tmp/oriole-position-cpython-gates.py',
 '/tmp/oriole-prepare-string-inline-timing.py','/tmp/oriole-correct-string-inline-preflight.py','/tmp/oriole-time-string-inline-native.py',
 '/tmp/oriole-prepare-string-inline-python.py','/tmp/oriole-time-string-inline-python.py',
]
h=lambda data:hashlib.sha256(data).hexdigest();paths={}
for prefix,dirname in directories.items():
 d=Path(dirname);assert d.is_dir(),d
 for p in sorted(d.rglob('*')):
  if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:paths[prefix+'/'+str(p.relative_to(d))]=p
for name in controllers:
 p=Path(name);assert p.is_file();paths['controllers/'+p.name]=p
members=[];excluded=[]
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for name,p in sorted(paths.items()):
  data=p.read_bytes();entry={'path':name,'source':str(p),'bytes':len(data),'sha256':h(data)}
  if data.startswith(b'\x7fELF') or data.startswith(b'!<arch>\n'):excluded.append(entry);continue
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data));members.append(entry)
with tarfile.open(out/'evidence.tar.gz','r:gz') as t:
 actual=t.getmembers();assert len(actual)==len(members)
 for m,e in zip(actual,members):
  assert m.isfile() and m.name==e['path'] and m.size==e['bytes'];assert h(t.extractfile(m).read())==e['sha256']==h(Path(e['source']).read_bytes())
for e in excluded:assert h(Path(e['source']).read_bytes())==e['sha256']
(out/'archive-members.json').write_text(json.dumps({'members':members,'excluded_binaries':excluded},indent=2)+'\n')
copies={'source.json':'/tmp/oriole-scanner-integration-study/source.json','assembly.json':'/tmp/oriole-scanner-integration-assembly.json','components.json':'/tmp/oriole-scanner-integration-components.json','gates.json':'/tmp/oriole-scanner-integration-gates/summary.json','workspace-counts.json':'/tmp/oriole-scanner-integration-gates/workspace-checks/counts.json','native-summary.json':'/tmp/oriole-scanner-integration-timing-study/summary.json','python-summary.json':'/tmp/oriole-scanner-integration-python-study/summary.json','native-review.json':'/tmp/oriole-scanner-integration-native-independent-review/review.json','python-review.json':'/tmp/oriole-scanner-integration-independent-review/python/review.json','cpython-review.json':'/tmp/oriole-scanner-integration-independent-review/cpython/review.json'}
for name,p in copies.items():shutil.copy2(p,out/name)
# Retain the complete unselected ASCII name experiment separately; no timed Python cohort existed.
shutil.copytree('/tmp/oriole-ascii-name-scan-handoff',out/'unselected-ascii-name')
summary={'runtime_commit':'64a270e58f14a4b74e25ffcf25f7832a5216b2d1','source_files':70,'source_manifest_sha256':h((out/'source.json').read_bytes()),'libraries':json.loads(Path('/tmp/oriole-scanner-integration-study/build.json').read_text())['libraries'],'workspace':{'all_targets':395,'doctests':1,'fmt_and_strict_clippy':'passed'},'api':{'passed':4347,'failed':393,'original_configurations':4740,'canonical_bounds_verified':True},'cpython_each_linkage':{'tests':802,'failures':2,'skips':14,'expected_failures':3},'native':json.loads((out/'native-summary.json').read_text()),'python':json.loads((out/'python-summary.json').read_text()),'archive':{'sha256':h((out/'evidence.tar.gz').read_bytes()),'members':len(members),'excluded_binaries':len(excluded),'raw_bytes':sum(e['bytes'] for e in members),'bytes':(out/'evidence.tar.gz').stat().st_size,'all_members_and_origins_readback_verified':True},'scope':'Measured integrated3694 library on d53 plus exact position/string components; same70 source bytes assembled as64a270e above doc-onlydfa6. Isolated position/String measurements retain5af performance controls; integrated measurements use5058. No speedup addition, failure reclassification or later end-tag prototype included.'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary['archive'],indent=2),flush=True)
