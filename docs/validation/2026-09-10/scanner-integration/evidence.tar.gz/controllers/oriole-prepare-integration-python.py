import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

out = Path('/tmp/oriole-scanner-integration-python-study')
out.mkdir(exist_ok=False)
old = Path('/tmp/oriole-coalesced-search-python-study')
python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
for name in ['build_consumers.py', 'python_worker.py']:
    shutil.copy2(old / name, out / name)
before = (old / 'consumer_screen.py').read_text()
after = before.replace('published5bc806e/5af2406b, bounded coalesced selector/50580931 candidate', 'published5bc806e/5af2406b, integrated position words and String hints/3694b683 candidate')
after = after.replace('published5bc806e/5af2406b', 'published193e1278/50580931')
assert before != after
(out / 'consumer_screen.py').write_text(after)
(out / 'controller.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='reviewed-consumer-screen', tofile='position-words-screen')))
shutil.copy2(__file__, out / Path(__file__).name)
jobs = [
    ('build', ['taskset', '-c', '3', python, '-I', '-S', str(out / 'build_consumers.py'), '--library', '/tmp/oriole-scanner-integration-study/liboriole_expat.so', '--reference', '/tmp/oriole-coalesced-search-study/liboriole_expat.so', '--expat', '/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4', '--source', '/home/dev-user/.cache/oriole/upstream/cpython-3.12.13', '--header', '/home/dev-user/code/oss/oriole-scanner-integration/include', '--output', str(out / 'consumers')]),
    ('preflight', ['taskset', '-c', '3', python, '-I', '-S', str(out / 'consumer_screen.py'), '--kind', 'python', '--phase', 'prepare', '--build', str(out / 'consumers/build.json'), '--input', '/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json', '--output', str(out / 'screen')]),
]
report = {'status': 'incomplete', 'jobs': []}
try:
    for name, command in jobs:
        with (out / (name + '.log')).open('wb') as log:
            run = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
        report['jobs'].append({'name': name, 'command': command, 'exit': run.returncode})
        print(name, run.returncode, flush=True)
        assert run.returncode == 0
    report['status'] = 'passed'
finally:
    (out / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')
