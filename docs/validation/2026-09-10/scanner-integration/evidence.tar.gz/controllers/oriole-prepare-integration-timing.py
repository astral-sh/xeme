import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

out = Path('/tmp/oriole-scanner-integration-timing-study')
out.mkdir(exist_ok=False)
study = Path('/tmp/oriole-scanner-integration-study')
source = json.loads((study / 'source.json').read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert all(digest(Path(source['worktree']) / name) == value for name, value in source['source_sha256'].items())
assert json.loads((study / 'build.json').read_text())['status'] == 'passed'
assert json.loads(Path('/tmp/oriole-scanner-integration-gates/gates-controller.json').read_text())['status'] == 'passed'
assert digest(study / 'liboriole_expat.so') == '3694b68326939778481e42e810f53facc2ebcb8b8ad75b599704dbfef8f37926'
assert digest(Path('/tmp/oriole-coalesced-search-study/liboriole_expat.so')) == '5058093123b486f7b6163ca055eb8726a5441f120bb4e74fcf7b892398ceab79'
old = Path('/tmp/oriole-coalesced-search-timing-study/native_screen.py').read_text()
new = old.replace('/tmp/oriole-coalesced-search-timing-study', str(out)).replace('/tmp/oriole-coalesced-search-study/liboriole_expat.so', str(study / 'liboriole_expat.so')).replace('bounded coalesced text selector', 'integrated position words and String inline hints').replace('bounded coalesced selector/50580931 candidate', 'integrated position words and String hints/3694b683 candidate')
new = new.replace('/tmp/oriole-text-frames-pr/release/liboriole_expat.so', '/tmp/oriole-coalesced-search-study/liboriole_expat.so').replace('published5bc806e/5af2406b', 'published193e1278/50580931')
assert new != old
(out / 'native_screen.py').write_text(new)
(out / 'controller.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='reviewed-coalesced-native', tofile='integrated-scanner-native')))
report = {'status': 'incomplete', 'source_files': len(source['source_sha256']), 'source_manifest_sha256': digest(study / 'source.json'),
          'scope': 'Same original full28 conditions,84 preflights,588 workers and seven fixed shuffled cohorts. Both components have independent source/correctness/performance evidence. Fresh integrated build, focused position oracle, original-bound API, strict/custom/malformed/publication and C sanitizer consumers pass. Full workspace checks continue; timing compares against published5058 and does not alone constitute adoption.'}
command = ['taskset', '-c', '3', 'python3', str(out / 'native_screen.py'), 'preflight']
with (out / 'preflight-controller.log').open('wb') as log:
    run = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
report.update(command=command, exit=run.returncode, status='passed' if run.returncode == 0 else 'failed')
(out / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copy2(__file__, out / Path(__file__).name)
print(json.dumps(report), flush=True)
raise SystemExit(run.returncode)
