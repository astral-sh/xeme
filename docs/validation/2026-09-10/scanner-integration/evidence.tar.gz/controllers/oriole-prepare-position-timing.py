import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

out = Path('/tmp/oriole-position-words-timing-study')
out.mkdir(exist_ok=False)
study = Path('/tmp/oriole-position-words-study')
source = json.loads((study / 'source.json').read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert all(digest(Path(source['worktree']) / name) == value for name, value in source['source_sha256'].items())
assert json.loads((study / 'build.json').read_text())['status'] == 'passed'
assert json.loads((study / 'profile/report.json').read_text())['status'] == 'passed'
assert digest(study / 'liboriole_expat.so') == '2a99058b238b4c59538e0d06b8be6512c726426e597d445cdaee194b473b805a'
assert digest(Path('/tmp/oriole-text-frames-pr/release/liboriole_expat.so')) == '5af2406b17092dad35aa61c086cdfe39e24f51e653441fd9baf50cd12da3b2fe'
old = Path('/tmp/oriole-coalesced-search-timing-study/native_screen.py').read_text()
new = old.replace('/tmp/oriole-coalesced-search-timing-study', str(out)).replace('/tmp/oriole-coalesced-search-study/liboriole_expat.so', str(study / 'liboriole_expat.so')).replace('bounded coalesced text selector', 'short position ASCII word scan').replace('bounded coalesced selector/50580931 candidate', 'short position word scan/2a99058b candidate')
assert new != old
(out / 'native_screen.py').write_text(new)
(out / 'controller.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='reviewed-coalesced-native', tofile='position-word-native')))
report = {'status': 'incomplete', 'source_files': len(source['source_sha256']), 'source_manifest_sha256': digest(study / 'source.json'),
          'scope': 'Same original full28 conditions,84 preflights,588 workers and seven fixed shuffled cohorts. Source-only independent review, focused Unicode/scalar test, original-bound API, strict/custom callbacks and instruction screen have passed. Full workspace gates continue separately; timing does not constitute adoption.'}
command = ['taskset', '-c', '3', 'python3', str(out / 'native_screen.py'), 'preflight']
with (out / 'preflight-controller.log').open('wb') as log:
    run = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
report.update(command=command, exit=run.returncode, status='passed' if run.returncode == 0 else 'failed')
(out / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copy2(__file__, out / Path(__file__).name)
print(json.dumps(report), flush=True)
raise SystemExit(run.returncode)
