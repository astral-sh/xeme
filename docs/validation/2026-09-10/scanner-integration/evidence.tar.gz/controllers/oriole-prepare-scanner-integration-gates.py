from pathlib import Path
import hashlib,json,shutil,subprocess,difflib
r=Path('/tmp/oriole-scanner-integration-gates');r.mkdir(exist_ok=False)
b=Path('/tmp/oriole-scanner-integration-study');w=Path('/home/dev-user/code/oss/oriole-scanner-integration');old=Path('/tmp/oriole-string-inline-gates')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=json.loads((b/'source.json').read_text());assert len(s['source_sha256'])==70 and all(h(w/n)==v for n,v in s['source_sha256'].items())
assert h(b/'liboriole_expat.so')=='3694b68326939778481e42e810f53facc2ebcb8b8ad75b599704dbfef8f37926'
assert h(b/'liboriole_expat.a')=='39b1a6e450814a57cfe8fa724d21f0a4cadb124da3674ecb0d5d9de508f76f38'
for n in ['source.json','source.tar.gz','build.json','candidate.patch','compiler-invocations.json']:shutil.copyfile(b/n,r/n)
shutil.copyfile('/tmp/oriole-scanner-integration-components.json',r/'components.json')
(r/'tools').mkdir();shutil.copyfile(w/'tools/xml_abi.py',r/'tools/xml_abi.py')
previous={};patch=[]
for name in ['workspace_checks.py','api_native.py','other_controls.py','publication_probe.py','run_publication.py','prepare_malformed.py','run_malformed.py','run_gates.py','classify_observations.py']:
 before=(old/name).read_text();previous[name]=h(old/name)
 text=before.replace('/tmp/oriole-string-inline-gates',str(r)).replace('/tmp/oriole-string-inline-study',str(b)).replace('/home/dev-user/code/oss/oriole-string-inline',str(w))
 if name=='workspace_checks.py':text=text.replace("'-c','7'","'-c','2'").replace('CPU7','CPU2')
 else:text=text.replace("'-c','1'","'-c','6'").replace('=={1}','=={6}').replace('CPU1','CPU6')
 if name=='api_native.py':text=text.replace("W/'crates/oriole_storage/src/string.rs']","W/'crates/oriole_storage/src/string.rs',W/'crates/oriole/src/encoding.rs']")
 (r/name).write_text(text)
 patch.extend(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='string/'+name,tofile='integration/'+name))
(r/'controllers.patch').write_text(''.join(patch))
subprocess.run(['python3',str(r/'prepare_malformed.py')],check=True)
(r/'preparation.json').write_text(json.dumps({'status':'passed','source_manifest_sha256':h(b/'source.json'),'source_files':70,'all_live_source_hashes_exact':True,'libraries':json.loads((b/'build.json').read_text())['libraries'],'source_controllers':previous,'controllers':{n:h(r/n) for n in previous},'changes':'Paths andCPU2 workspace/CPU6 other gates, additional unchanged-source hash tracking. Original bounds, fixtures, assertions and comparison control5af retained. Composition is position words plus String hints onpublished5058; fullsource maps and exact component identities recorded. No postprocessing count assumptions.'},indent=2)+'\n')
shutil.copyfile(__file__,r/'prepare.py')
print('Integration gate preparation passed',flush=True)
