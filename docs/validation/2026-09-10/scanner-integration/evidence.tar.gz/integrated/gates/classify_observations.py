"""Read saved paired data; no parser execution or normalization waiver."""
from pathlib import Path
from collections import Counter
import gzip,json,hashlib
if not __debug__:raise RuntimeError('Assertions required')
r=Path('/tmp/oriole-scanner-integration-gates');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=r/'publication-probe/observations.json.gz';rows=json.load(gzip.open(p,'rt'));assert len(rows)==1304
positions=Counter()
for row in rows:
 a=row['values']['candidate'];b=row['values']['baseline'];ref=row['values']['reference'];assert a==b
 assert {k:v for k,v in a.items() if k!='events'}=={k:v for k,v in ref.items() if k!='events'}
 assert len(a['events'])==len(ref['events'])
 for left,right in zip(a['events'],ref['events'],strict=True):
  if left!=right:
   assert left[:-1]==right[:-1] and left[1] in ['default','external'];assert all(isinstance(v,int) for v in left[-1]+right[-1]);positions[left[1]]+=1
assert positions=={'default':10416,'external':864}
(r/'publication-probe/reference-classification.json').write_text(json.dumps({'cases':len(rows),'baseline_candidate_exact':True,'reference_outcome_differences':0,'reference_callback_payload_order_differences':0,'reference_final_position_differences':0,'retained_reference_position_events':positions,'scope':'All fields checked; retained differences are callback positions only. No acceptance/data waiver.','observations_sha256':h(p)},indent=2)+'\n')
rows=[]
with gzip.open(r/'malformed/observations.jsonl.gz','rt') as f:
 for line in f:
  x=json.loads(line);assert x['control']==x['candidate'];rows.append((x['input_sha256'],x['encoding'],x['chunk']))
assert len(rows)==len(set(rows))==2392
(r/'malformed/readback.json').write_text(json.dumps({'status':'passed','paired_rows':len(rows),'all_observation_fields_exact':True,'sha256':h(r/'malformed/observations.jsonl.gz')},indent=2)+'\n')
