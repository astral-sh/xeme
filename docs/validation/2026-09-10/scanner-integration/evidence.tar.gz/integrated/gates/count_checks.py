"""Read actual per-target Cargo results and compare unchanged test inventory."""
from pathlib import Path
import re,json,hashlib
r=Path('/tmp/oriole-scanner-integration-gates');base=Path('/tmp/oriole-text-frames-pr/test.log')
def parse(p):
 rows=[];target=None
 for line in Path(p).read_text().splitlines():
  if 'Running ' in line and '(' in line:
   path=line.rsplit('(',1)[1].rstrip(')');target=re.sub(r'-[0-9a-f]{16}$','',Path(path).name)
  elif 'Doc-tests ' in line:target='doc:'+line.split('Doc-tests ',1)[1].strip()
  m=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)
  if m:
   assert target is not None;rows.append({'target':target,'passed':int(m[1]),'failed':int(m[2]),'ignored':int(m[3])});target=None
 return rows
b=parse(base);a=parse(r/'workspace-checks/tests.log');d=parse(r/'workspace-checks/doc-tests.log');differences=[{'index':i,'baseline':old,'candidate':new} for i,(old,new) in enumerate(zip(b,a)) if old!=new];assert len(a)==len(b)==33 and len(differences)==1;delta=differences[0];assert delta['index']==0 and delta['baseline']=={'target':'oriole','passed':51,'failed':0,'ignored':0} and delta['candidate']==dict(delta['baseline'],passed=54);assert sum(x['passed'] for x in a)==395 and all(x['failed']==0 for x in a+d)
report={'baseline_log':str(base),'baseline_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'baseline_profile':'dev --workspace --all-targets','candidate_profile':'release --workspace --all-targets; separate release --workspace --doc','all_target_rows':a,'doc_rows':d,'all_target_passed':sum(x['passed'] for x in a),'doc_passed':sum(x['passed'] for x in d),'same_counts_except_three_new_core_tests':True,'differences':differences}
(r/'workspace-checks/counts.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'all_targets':report['all_target_passed'],'docs':report['doc_passed']}))
