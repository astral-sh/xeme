"""Sequential CPU6 correctness gates with exact command/log retention."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time
r=Path('/tmp/oriole-scanner-integration-gates');report={'status':'incomplete','jobs':[]};h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();save=lambda:(r/'gates-controller.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 for name in ['api_native.py','other_controls.py','run_publication.py','run_malformed.py']:
  row={'script':name,'sha256':h(r/name),'command':['taskset','-c','6','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S',str(r/name)],'start':time.time()};report['jobs'].append(row);save();p=None
  with (r/(name+'.stdout')).open('wb') as out,(r/(name+'.stderr')).open('wb') as err:
   try:
    p=subprocess.Popen(row['command'],stdout=out,stderr=err,start_new_session=True);row['exit']=p.wait(timeout=660)
   except BaseException as e:
    row['exception']=repr(e)
    if p is not None:
     if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
     row['exit']=p.wait()
    raise
   finally:out.flush();err.flush();row['end']=time.time();row['stdout_sha256']=h(r/(name+'.stdout'));row['stderr_sha256']=h(r/(name+'.stderr'));save()
  assert row['exit']==0;print(name,row['exit'],flush=True)
 for path in ['api-native/report.json','other-gates/report.json','publication-launch/report.json','publication-probe/report.json','malformed/launch.json']:
  assert json.loads((r/path).read_text())['status']=='passed',path
 report['status']='passed'
finally:save()
print(report['status'],flush=True)
