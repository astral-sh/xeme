from pathlib import Path
import json,hashlib,os,signal,subprocess,time
r=Path('/tmp/oriole-scanner-integration-gates/malformed');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();before=json.loads((r/'preparation.json').read_text())['hashes'];report={'status':'incomplete','before':before,'command':['taskset','-c','6','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S',str(r/'malformed_probe.py')],'timeout':180,'start':time.time()};save=lambda:(r/'launch.json').write_text(json.dumps(report,indent=2)+'\n');save();p=None
try:
 with (r/'stdout').open('wb') as out,(r/'stderr').open('wb') as err:
  try:
   p=subprocess.Popen(report['command'],stdout=out,stderr=err,start_new_session=True);report['exit']=p.wait(timeout=180)
  except BaseException as e:
   report['exception']=repr(e)
   if p is not None:
    if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
    report['exit']=p.wait()
   raise
  finally:out.flush();err.flush();report['stdout_sha256']=h(r/'stdout');report['stderr_sha256']=h(r/'stderr')
 report['after']={s:h(s) for s in before};assert report['exit']==0 and report['before']==report['after'];data=json.loads((r/'malformed-probe.json').read_text());assert data['cases']==2392 and not data['differences'];report['cases']=2392;report['differences']=0;report['status']='passed'
finally:report['end']=time.time();save()
print(json.dumps(report),flush=True)
