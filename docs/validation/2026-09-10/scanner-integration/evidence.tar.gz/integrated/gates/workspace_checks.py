"""Final source snapshot and workspace checks, CPU2 only."""
if not __debug__:raise RuntimeError('Assertions required')
import hashlib,json,os,signal,subprocess,tarfile,time
from pathlib import Path
W=Path('/home/dev-user/code/oss/oriole-scanner-integration');R=Path('/tmp/oriole-scanner-integration-gates');O=R/'workspace-checks';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prior=json.loads((R/'build.json').read_text());env=prior['env_overrides'];paths=json.loads((R/'source.json').read_text())['source_sha256']
source=lambda:{p:sha(W/p) for p in paths}
report={'status':'incomplete','env_overrides':env,'before':source(),'commands':[]};save=lambda:(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(O/'source.json').write_text(json.dumps({'worktree':str(W),'source_sha256':source()},indent=2)+'\n')
with tarfile.open(O/'source.tar.gz','w:gz') as t:
 for p in paths:t.add(W/p,arcname=p,recursive=False)
with (O/'candidate.patch').open('wb') as f:subprocess.run(['git','diff','--binary'],cwd=W,stdout=f,check=True)
save()
try:
 for label,args in [('tests',['test','--release','--locked','--workspace','--all-targets','--no-fail-fast']),('doc-tests',['test','--release','--locked','--workspace','--doc']),('clippy',['clippy','--release','--locked','--workspace','--all-targets','--','-D','warnings']),('fmt',['fmt','--all','--','--check'])]:
  row={'label':label,'command':['taskset','-c','2','cargo','+ohm','-Zohm-defaults=no',*args],'start':time.time()};report['commands'].append(row);save();p=None
  with (O/(label+'.log')).open('wb') as out:
   try:
    p=subprocess.Popen(row['command'],cwd=W,env={**os.environ,**env},stdout=out,stderr=subprocess.STDOUT,start_new_session=True);row['exit']=p.wait(timeout=900)
   except BaseException as e:
    row['exception']=repr(e)
    if p is not None:
     if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
     row['exit']=p.wait()
    raise
   finally:
    out.flush();row['end']=time.time();row['log_sha256']=sha(O/(label+'.log'));save()
  print(label,row['exit'],flush=True)
 report['status']='passed' if all(r['exit']==0 for r in report['commands']) else 'failed'
finally:
 report['after']=source();report['unchanged']=report['before']==report['after'];save()
assert report['status']=='passed' and report['unchanged']
