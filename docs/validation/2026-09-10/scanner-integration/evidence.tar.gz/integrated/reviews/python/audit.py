"""Reconstruct fresh three-engine CPython samples without executing workers."""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import math
import random
import statistics

if not __debug__:
    raise RuntimeError('Audit assertions must run')
B = Path('/tmp/oriole-scanner-integration-python-study')
S = B / 'screen'
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_bytes())
pre = load(S / 'preflight.json')
r = load(S / 'results.json')
build = load(B / 'consumers/build.json')
summary = load(B / 'summary.json')

assert pre['status'] == 'preflight_passed' and r['status'] == 'passed'
assert pre['affinity'] == [3] and r['affinity'] == [0]
assert pre['kind'] == r['kind'] == 'python'
assert r['preflight_sha256'] == sha(S / 'preflight.json')
assert pre['conditions'] == r['conditions']
assert r['preflights'] == pre['preflights'] and r['expected'] == pre['expected']
assert len(pre['processes']) == len(pre['preflights']) == 72
assert len(r['processes']) == len(r['rows']) == 504
assert pre['pairs'] == r['pairs'] == 7
assert pre['seed'] == r['seed'] == 202609104412
assert pre['hashes_before'] == pre['hashes_after'] == r['hashes_before'] == r['hashes_after']
for record in [pre, r]:
    assert not record['hash_errors']
    assert all(sha(p) == h for p, h in record['hashes_before'].items())
assert sha(B / 'python_worker.py') == '4bc0ccffedb5048412b9cfc3638d28dcb30f711891c3784f3fbd3c0eb536ab68'
assert build['status'] == 'passed' and build['adaptations'] is None
assert build['cpython_revision'] == '3bb231a6a5dc02b95658877318bf61501a7209e9'
assert build['source_sha256_before'] == build['source_sha256_after']
assert all(sha(p) == h for p, h in build['source_sha256_before'].items())
engines = ['published', 'candidate', 'expat']
libraries = {'published': '5058093123b486f7b6163ca055eb8726a5441f120bb4e74fcf7b892398ceab79',
             'candidate': '3694b68326939778481e42e810f53facc2ebcb8b8ad75b599704dbfef8f37926',
             'expat': '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'}
assert set(build['consumers']) == set(engines)
normalized_commands = {}
for engine, consumer in build['consumers'].items():
    assert sha(consumer['library']) == libraries[engine]
    assert all(sha(p) == h for p, h in consumer['files'].items())
    assert len(consumer['commands']) == 2
    normalized = []
    for module, command in zip(['pyexpat', '_elementtree'], consumer['commands'], strict=True):
        args = command['command']
        assert command['returncode'] == 0 and args[:4] == ['cc', '-shared', '-fPIC', '-O2']
        assert sha(Path(consumer['directory']) / (module + '-build.log')) == command['log_sha256']
        assert args[-4] == consumer['library']
        normalized.append([x.replace(consumer['library'], '<PARSER-LIBRARY>').replace(consumer['directory'], '<CONSUMER-DIR>') for x in args])
    normalized_commands[engine] = normalized
assert all(v == normalized_commands['published'] for v in normalized_commands.values())

manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
iterations = {'vulkan': 3, 'wayland': 16, 'maven': 32, 'batik': 128, 'gtk': 64, 'docbook': 64}
conditions = []
for project in load(manifest)['projects']:
    entry = next(x for x in project['files'] if x['role'] == 'input')
    path = (manifest.parent / entry['path']).resolve()
    assert sha(path) == entry['sha256']
    for chunk in [4096, 65536]:
        for mode in ['elementtree', 'pyexpat-events']:
            conditions.append({'name': project['name'], 'chunk': chunk, 'mode': mode, 'input': str(path), 'iterations': iterations[project['name']]})
assert conditions == r['conditions'] and len(conditions) == 24
key = lambda c: f"{c['name']}/{c['chunk']}/{c['mode']}"
condition_map = {key(c): c for c in conditions}
index = {}
counts = Counter()
raw_hashes = {}
for phase, record, rowname in [('preflight', pre, 'preflights'), ('time', r, 'rows')]:
    processes = {p['label']: p for p in record['processes']}
    assert len(processes) == len(record['processes'])
    assert set(processes) == {row['process'] for row in record[rowname]}
    for row in record[rowname]:
        process = processes[row['process']]
        assert process['status'] == 'passed' and process['returncode'] == 0 and process['timeout_seconds'] == 300
        assert 'failure' not in process
        for stream in ['stdout', 'stderr']:
            path = S / process[stream]
            assert sha(path) == process[stream + '_sha256']
            raw_hashes[str(path)] = sha(path)
        assert not gzip.decompress((S / process['stderr']).read_bytes())
        raw = json.loads(gzip.decompress((S / process['stdout']).read_bytes()))
        assert raw['gc_enabled'] is True
        assert raw['samples'] == row['samples'] and raw['identity'] == row['identity']
        engine = row['engine']
        consumer = build['consumers'][engine]
        assert raw['identity']['parser_library']['sha256'] == libraries[engine]
        assert raw['identity']['expat_version'] == ('expat_2.8.4' if engine == 'expat' else 'oriole_compat_2.8.4')
        for name in ['pyexpat', '_elementtree', 'parser_library']:
            entry = raw['identity'][name]
            assert consumer['files'][entry['path']] == entry['sha256'] == sha(entry['path'])
        command = process['command']
        assert command[1:5] == ['-I', '-S', str(B / 'python_worker.py'), '--worker']
        specpath = Path(command[-1])
        spec = load(specpath)
        raw_hashes[str(specpath)] = sha(specpath)
        c = condition_map[row['key']]
        count = 0 if phase == 'preflight' else c['iterations']
        assert spec == {'input': c['input'], 'input_sha256': sha(c['input']), 'chunk': c['chunk'], 'mode': c['mode'], 'consumer': consumer['directory'], 'library_sha256': libraries[engine], 'iterations': count}
        assert len(raw['samples']) == count + 1
        for i, sample in enumerate(raw['samples']):
            assert sample['iteration'] == i and sample['warmup'] == (i == 0)
            assert sample['seconds'] == (sample['parse_ns'] + sample['destruction_ns']) / 1e9
            assert sample['seconds'] > 0 and math.isfinite(sample['seconds'])
            assert sample['parse_ns'] >= 0 and sample['destruction_ns'] >= 0
            assert [sample['output_sha256'], sample['output_rows']] == pre['expected'][row['key']]
            counts[phase + ('_warmups' if i == 0 else '_measured')] += 1
        median = statistics.median(s['seconds'] for s in raw['samples'][1:]) if count else None
        assert row['median_seconds'] == median
        if phase == 'time':
            identity = (row['key'], row['pair'], engine)
            assert identity not in index
            index[identity] = median
expected_preflights = [(key(c), engine) for c in conditions for engine in engines]
assert [(row['key'], row['engine']) for row in pre['preflights']] == expected_preflights
rng = random.Random(r['seed'])
jobs = [(condition, pair) for condition in conditions for pair in range(7)]
rng.shuffle(jobs)
order = []
for c, pair in jobs:
    shuffled = engines.copy()
    rng.shuffle(shuffled)
    order.extend((key(c), pair, engine, position) for position, engine in enumerate(shuffled))
assert order == [(row['key'], row['pair'], row['engine'], row['order']) for row in r['rows']]
ratio_pairs = [('candidate', 'published'), ('candidate', 'expat'), ('published', 'expat')]
summaries = []
for c in conditions:
    medians = {engine: [index[key(c), pair, engine] for pair in range(7)] for engine in engines}
    ratios = {a + '_over_' + b: [medians[a][pair] / medians[b][pair] for pair in range(7)] for a, b in ratio_pairs}
    summaries.append({'condition': c, 'process_pair_medians_seconds': medians, 'paired_ratios': ratios,
                      'median_ratios': {name: statistics.median(v) for name, v in ratios.items()}})
assert summaries == r['summary']
assert counts == {'preflight_warmups': 72, 'time_warmups': 504, 'time_measured': 25788}
groups = {}
for group in ['all', 'elementtree', 'pyexpat-events']:
    selected = [s for s in summaries if group == 'all' or s['condition']['mode'] == group]
    groups[group] = {}
    for a, b in ratio_pairs:
        name = a + '_over_' + b
        values = [s['median_ratios'][name] for s in selected]
        geo = math.exp(statistics.mean(math.log(v) for v in values))
        actual = {'geomean': geo, 'below_one': sum(v < 1 for v in values), 'conditions': len(values)}
        assert actual['below_one'] == summary['groups'][group]['ratios'][name]['below_one'] and actual['conditions'] == summary['groups'][group]['conditions']
        assert math.isclose(actual['geomean'], summary['groups'][group]['ratios'][name]['geomean'], rel_tol=1e-14)
        groups[group][name] = actual
project_groups = {}
for project in iterations:
    selected = [s for s in summaries if s['condition']['name'] == project]
    project_groups[project] = {a + '_over_' + b: math.exp(statistics.mean(math.log(s['median_ratios'][a + '_over_' + b]) for s in selected)) for a, b in ratio_pairs}
# Prior reviewed coordinator differs only in candidate-description text.
old_base=Path('/tmp/oriole-coalesced-search-python-study')
assert sha(B/'python_worker.py')==sha(old_base/'python_worker.py')
assert sha(B/'build_consumers.py')==sha(old_base/'build_consumers.py')
old=(old_base/'consumer_screen.py').read_text().splitlines();new=(B/'consumer_screen.py').read_text().splitlines();assert len(old)==len(new)
delta=[(a,b) for a,b in zip(old,new) if a!=b];assert len(delta)==1 and all(a.strip().startswith('"method":') and b.strip().startswith('"method":') for a,b in delta)
prep=load(B/'preparation.json');assert prep['status']=='passed' and len(prep['jobs'])==2 and all(x['exit']==0 for x in prep['jobs'])
assert all(x['command'][:3]==['taskset','-c','3'] for x in prep['jobs'])
timed=load(B/'timing-controller.json')
assert timed['status']=='passed' and timed['exit']==0
regressions=[{'condition':x['condition'],'ratio':x['median_ratios']['candidate_over_published']} for x in summaries if x['median_ratios']['candidate_over_published']>1]
assert regressions==summary['regressions']
raw_manifest = OUT / 'audited-raw-files.json'
raw_manifest.write_text(json.dumps(raw_hashes, indent=2) + '\n')
paths = [Path(__file__), B/'consumer_screen.py', B/'python_worker.py', B/'build_consumers.py', B/'consumers/build.json', B/'preparation.json', B/'summary.json', S/'preflight.json', S/'results.json', raw_manifest,  B/'controller.patch', B/'timing-controller.json']
result = {'status': 'passed_no_findings', 'scope': 'Independent source/build/hash and saved CPython timing audit. No compilation, parser execution, test-suite rerun or timing by reviewer.',
          'preflights': 72, 'timed_workers': 504, 'cohorts': 168, 'conditions': 24, 'sample_counts': dict(counts), 'raw_files_verified': len(raw_hashes), 'paired_ratios_verified': 504, 'condition_ratio_medians': 72,
          'preparation': 'Six unchanged extension builds and all72 preflights passed onCPU3 before timingCPU0.', 'regressions': regressions, 'libraries': libraries, 'groups': groups, 'per_project_geomeans': project_groups,
          'conclusion': 'All recorded consumer/compiler inputs, loaded artifacts, canonical outputs, worker medians, seeded orders and ratios reproduce. All per-condition wins and regressions are reconstructed without exclusions and reported in groups. Integrated candidate3694 includes position words and four String hints on current5058 control. Isolated component speedups do not predict or add to this measured result. This study is distinct from earlier9277/dbee and mode-confounded results.',
          'namespace_and_origin_scope': 'Both measured consumers enable namespaces: pyexpat explicitly uses separator |, while the unchanged C ElementTree constructor uses ParserCreate_MM with separator }. Every worker checks both extension file origins and resolves XML_Parse through the pyexpat extension using dladdr to its frozen private parser library. Strict fresh-import coverage is a separate suite audit.',
          'limitations': ['Automatic GC stays enabled. Explicit gc.collect, input/import and canonicalization are untimed; parser construction/feed/finalization and explicit result destruction are timed separately and added. Canonicalization warms result memory before destruction.',
                         'Output hashes/counts are canonicalized; pyexpat joins adjacent text. This performance gate does not prove exact Expat callback grouping. The prior baseline has two known strict grouping failures; this saved benchmark audit makes no claim that a full strict suite was executed by this saved-data performance audit; integrated strict suites are checked separately.',
                         'Only the unchanged CPython3.12.13 ElementTree and pyexpat consumers parse six original project XML fixtures. There is no full-application/Wayland-scanner/external-DTD/PGO claim.',
                         'Two Oriole builds use the matched no-default compiler context independently checked in the separate integrated source/build/gates review; published5058 includes coalesced scanning and candidate3694 adds the exact position-word and four String-inline component bytes. ReferenceExpat2.8.4 retains its pinned normal C build, rather than a claim of identical Rust/C compiler implementations.',
                         'Shared-host frequency, cache and background load remain uncontrolled. CPU0 controller sequencing and exit records do not prove absence of unrelated host activity. No samples or conditions were excluded.',
                         'No strict upstream test-suite status is newly asserted by this saved benchmark audit.'],
          'evidence_sha256': {str(p): sha(p) for p in paths}}
(OUT / 'review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'path': str(OUT / 'review.json'), 'sha256': sha(OUT / 'review.json'), 'groups': groups, 'sample_counts': dict(counts)}))
