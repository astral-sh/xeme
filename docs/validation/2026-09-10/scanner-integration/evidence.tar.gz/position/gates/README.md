# Position-word correctness gates

The frozen candidate changes only short-span position advancement in encoding.rs. It skips eight proven ASCII bytes without CR/LF and uses the existing scalar routine for the remaining suffix. This package records correctness checks; wall timing and selection remain separate.

393 all-target tests plus one doc test pass, as do strict workspace Clippy and formatting. The original API suite exits 1 with 4,347 passing and 393 failing configurations; all 4,740 rows match the canonical baseline under unchanged 3-second per-test, 1 GiB address-space, 768 MiB RSS, and 240-second total bounds.

Six C sanitizer consumers pass, including both original 327-scenario allocation sweeps. Rust release code is uninstrumented; leak checking is disabled. Baseline comparisons are exact for 3,318 deterministic traces, 36,456 custom-encoding controls, 2,392 malformed controls, and 1,304 publication cases (3,912 parses across three libraries). Full malformed observations also preserve exact callback fragmentation.

Publication controls check shared child definitions, partial input, suspension, raw data, UTF-16, and compaction. Their existing Expat differences remain 10,416 Default and 864 external-entity callback positions; outcomes, payloads, order and final positions agree. Nine same-process symbol-origin checks and before/after hashes are retained. The 5 KiB attribute cases exercise arena fallback, not lexical max_token rejection.

All 70 source hashes are unchanged. The extra README entry explains the initial 69-file setup assertion; those setup-only failures and the earlier summary lacking the malformed matrix are preserved. Executables are excluded but hashed. The archive contains original logs, generators, source snapshots, compiler evidence and independent source review; every regular member and nested source snapshot was read back and verified.
