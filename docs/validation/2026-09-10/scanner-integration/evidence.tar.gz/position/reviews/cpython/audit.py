"""Read saved canonical API and original CPython outcomes without executing tests."""
from pathlib import Path
from collections import Counter
import hashlib,json,re
OUT=Path(__file__).parent
G=Path('/tmp/oriole-position-words-cpython-gates')
W=Path('/home/dev-user/code/oss/oriole-position-words')
hashes={}
def read(p):
 p=Path(p);d=p.read_bytes();hashes[str(p)]=hashlib.sha256(d).hexdigest();return d
def sha(p):read(p);return hashes[str(Path(p))]
def load(p):return json.loads(read(p))
controller=load(G/'controller.json')
for p,h in controller['libraries'].items():assert sha(p)==h
assert len(controller['jobs'])==2
for job in controller['jobs']:
 assert job['exit']==job['expected_exit']==2
 assert not any(a in job['command'] for a in ['--allow-text-fragmentation','--consumer-fix'])
 assert sha(G/(job['linkage']+'.log'))==job['log_sha256']
def methods(path):
    output={};pending=None;subtests=[]
    def add(item,status):
        name,identifier=item
        if name=='setUpClass':return
        assert name.startswith('test') and identifier not in output
        output[identifier]=status
    for line in read(path).decode().splitlines():
        m=re.match(r'^(\w+) \((test\.[^)]+)\)(?: \.\.\. (.*))?$',line)
        if m:
            if pending is not None:
                assert any(f'{pending[0]} ({pending[1]}) ' in t for t in subtests);add(pending,'subtest outcomes')
            pending=(m[1],m[2]);status=m[3]
            if status:add(pending,status);pending=None
        elif pending is not None:
            if re.match(r'^(ok|FAIL|ERROR|expected failure|skipped .+)$',line):add(pending,line);pending=None
            elif line.startswith('  ') and ' ... ' in line:subtests.append(line)
            elif ' ... ' in line and line.rsplit(' ... ',1)[1]:add(pending,line.rsplit(' ... ',1)[1]);pending=None
    assert pending is None
    return output

expected_failures=['test.test_pyexpat.BufferTextTest.test1','test.test_sax.CDATAHandlerTest.test_handlers']
baseline_methods=methods('/tmp/oriole-frame-integrated-gates/cpython-shared/tests.log')
python={}
for linkage in ['shared','static']:
    p=G/linkage;summary=load(p/'summary.json');origin=load(p/'origin.log')
    assert summary['linkage']==linkage and summary['tests_exit_code']==summary['gate_exit_code']==2
    assert summary['probe_exit_code']==summary['origin_exit_code']==0 and summary['consumer_fix'] is None and summary['consumer_adaptation'] is None and summary['text_fragmentation'] is None
    assert summary['cpython_revision']=='3bb231a6a5dc02b95658877318bf61501a7209e9'
    assert summary['source_sha256']==summary['compiled_source_sha256']==sha(p/'pyexpat.c')==sha('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Modules/pyexpat.c')
    suffix='so' if linkage=='shared' else 'a';assert sha(p/('liboriole_expat.'+suffix))==summary['library_sha256']==controller['libraries']['/tmp/oriole-position-words-study/liboriole_expat.'+suffix]
    assert summary['loader_sha256']==sha(p/'sitecustomize.py')==sha(W/'tools/cpython/extension_loader.py')
    assert summary['import_check_sha256']==sha(W/'tools/cpython/check_extension_imports.py')
    assert origin['status']=='passed' and origin['accelerator_imports']==['cET','cET_alias'] and origin['pure_python_and_blocked_imports']=='passed' and len(origin['origins'])==4
    for entry in origin['origins'].values():assert Path(entry['path']).parent==p and sha(entry['path'])==entry['sha256']
    rows=methods(p/'tests.log');assert len(rows)==802 and rows==baseline_methods
    assert sorted(k for k,v in rows.items() if v in ['FAIL','ERROR'])==expected_failures
    assert sum(v.startswith('skipped') for v in rows.values())==5 and sum(v=='expected failure' for v in rows.values())==3
    skip=[l for l in read(p/'tests.log').decode().splitlines() if ' ... skipped ' in l]
    assert len(skip)==14 and sum(l.startswith('  ') for l in skip)==8 and sum(l.startswith('setUpClass') for l in skip)==1
    for name in ['test_correct_import_cET','test_correct_import_cET_alias','test_parser_comes_from_C']:assert rows['test.test_xml_etree_c.TestAcceleratorImported.'+name]=='ok'
    for name in ['probe.log','pyexpat-build.log','_elementtree-build.log']:read(p/name)
    python[linkage]={'methods':802,'failures':expected_failures,'expected_failures':3,'reported_skips':14,'whole_method_skips':5,'subtest_skips':8,'class_setup_skips':1,'all_method_statuses_equal_corrected_baseline':True}
old_cpython=load('/tmp/oriole-pbs-version-followup/report.json')['test_count_and_coverage']['upstream_six_module_hashes_exact']
for name,h in old_cpython.items():assert sha(Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Lib/test')/(name+'.py'))==h
read(W/'tools/cpython/run.py');read(W/'tools/cpython/text_fragmentation.py')


# Require exact full method maps and failure identity against both prior linkage outputs.
for linkage in ['shared','static']:
 assert methods(G/linkage/'tests.log')==methods(Path('/tmp/oriole-frame-integrated-gates')/('cpython-'+linkage)/'tests.log')
 sha(G/linkage/'summary.json')
for name in ['oriole-position-cpython-gates.py']:read(G/name)
# The current published harness is unmodified; persistent imports remain enabled.
for name in ['run.py','extension_loader.py','check_extension_imports.py']:
 assert read(W/'tools/cpython'/name)==read(Path('/home/dev-user/code/oss/oriole-frame-integration/tools/cpython')/name)
result={'status':'saved_outcomes_and_origins_verified','scope':'Independent saved strict CPython outcome/source/origin audit only; no builds, parser executions or test reruns. Canonical API and timing have separate receipts.',
'cpython':python,'libraries':controller['libraries'],
'limitations':['Both strict runs retain original exit2 and exactly two known text-grouping failures. Unchanged compatibility does not mean a green suite.','802 method maps are exact against both prior linkage records.14 skips comprise5 whole-method,8 subtest,1 class-setup.','Four persistent-loader origin records per linkage and three accelerator tests confirm fresh pyexpat/_elementtree imports; unmodified original tests and no waivers.','No sanitizer, fuzz, PBS or timing assertion made by this receipt.'],'evidence_sha256':hashes}
(OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'review_sha256':sha(OUT/'review.json')}))
