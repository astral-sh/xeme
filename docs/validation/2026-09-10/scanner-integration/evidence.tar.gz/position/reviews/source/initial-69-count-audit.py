"""Source-only exact snapshot review. No compilation or parser execution."""
from pathlib import Path
import hashlib,json,tarfile,subprocess
B=Path('/tmp/oriole-position-words-study');O=Path(__file__).parent
H={}
def sha(p):
 p=Path(p); h=hashlib.sha256(p.read_bytes()).hexdigest();H[str(p)]=h;return h
def load(p):sha(p);return json.loads(Path(p).read_bytes())
m=load(B/'source.json'); w=Path(m['worktree'])
assert sha(B/'source.json')=='d895ed69017264bf27b3f2790424dd52c3d7fb863a54ab364f086460b105d042'
assert m['base']=='5bc806e5fc2a545f22c75f2a1bcbef45cfa3632b'
with tarfile.open(B/'source.tar.gz') as t:
 members={a.name:t.extractfile(a).read() for a in t.getmembers() if a.isfile()}
assert len(members)==len(m['source_sha256'])==69
changed=[]
for name,h in m['source_sha256'].items():
 assert hashlib.sha256(members[name]).hexdigest()==sha(w/name)==h
 base=subprocess.check_output(['git','-C','/home/dev-user/code/oss/oriole','show',m['base']+':'+name])
 if hashlib.sha256(base).hexdigest()!=h:changed.append(name)
assert changed==['crates/oriole/src/encoding.rs']
base=subprocess.check_output(['git','-C','/home/dev-user/code/oss/oriole','show',m['base']+':crates/oriole/src/encoding.rs']).decode()
new=members['crates/oriole/src/encoding.rs'].decode()
# Exact existing scalar suffix, long-text implementation, and call sites retained.
start='        for character in text.chars() {'
a=base.index(start,base.index('fn advance_position('));b=base.index('\n#[cfg(test)]',a)
a2=new.index('        for character in rest.chars() {',new.index('fn advance_position('));b2=new.index('\n#[cfg(test)]',a2)
assert base[a:b].replace('for character in text.chars()', 'for character in rest.chars()')==new[a2:b2]
assert base[:base.index('/// Advance XML line')]==new[:new.index('/// Advance XML line')]
assert new.count('advance_position(')==5
build=load(B/'build.json');assert build['source_manifest_sha256']==sha(B/'source.json') and build['source_unchanged']
for job in build['commands']:
 assert job['exit']==0 and sha(B/(job['name']+'.log'))==job['log_sha256']
for name,h in build['libraries'].items(): assert sha(B/name)==h
for p in ['candidate.patch','source.tar.gz','DESIGN.md','compiler-invocations.json']:sha(B/p)
(O/'encoding.rs').write_bytes(members['crates/oriole/src/encoding.rs'])
(O/'candidate.patch').write_bytes((B/'candidate.patch').read_bytes())
r={'status':'source_review_passed_no_findings','scope':'Read-only review of exact69-file source, runtime delta, focused-test source and saved build identities. No build, parser execution, test rerun, timing, or full-gate certification by reviewer.',
 'changed_source_files':changed,'library_sha256':build['libraries'],
 'proof':[
 'The final mask ORs the original word before masking high bits. Zero therefore proves all eight bytes are ASCII; a non-ASCII byte cannot be hidden by the CR/LF detector.',
 'In either XOR word an equal CR/LF byte is a zero lane. Subtracting1 plus an incoming borrow yields0xff or0xfe in that lane, and &!xor preserves its high bit. Thus every equal CR/LF byte is detected. Borrow propagation can only conservatively flag other lanes; wrapping discards only the borrow beyond the highest lane.',
 'Eight proven ASCII non-CR/LF bytes are eight original scalar iterations: line remains unchanged, column increases8, previous_cr becomesfalse. Explicit from_le_bytes makes this lane argument independent of host endianness. The next8-byte string slice is a valid UTF8 boundary.',
 'First possible special word causes immediate fallback of its entire suffix to the exact previous char loop. No special or Unicode byte is skipped. Empty text leaves previous_cr unchanged; CRLF across calls keeps its prior handling; >128byte path is byte-identical.',
 'All three caller sites and their raw-width/anchor handling remain byte-identical. No allocation, ownership, parser-layout, work accounting, callback policy, compaction or error publication changes.',
 'The added pure regression compares against the prior scalar routine, both initial CR states, all Unicode scalars across an8-byte boundary, each ASCII byte at short/128byte boundaries, and adjacent ASCII pairs in all8 lanes. These are focused semantic comparisons rather than downstream callback assertions.'
 ],'peer_cross_check':'Independent source-only bit proof from /root/ffi/multibyte_fuzz agrees on no missed CR/LF/high-bit lanes and complete-suffix fallback. No reviewer runtime execution claimed.',
 'limitations':['Focused/core Clippy and release exits are recorded owner evidence only. Full external API/custom/consumer gates and performance adoption remain separate.','Existing <=128 threshold and long-text routine are unchanged. No claim that full consume/position_at profile cost can be eliminated.'],
 'evidence_sha256':H}
(O/'review.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'review_sha256':sha(O/'review.json')}))
