# String inline-hint correctness gates

The frozen candidate adds four ordinary inline hints to existing fallible append/reserve methods in storage/string.rs. All function bodies, allocator ownership and error paths are byte-identical to the control after removing those four attribute lines. This package records correctness checks; wall timing and selection remain separate.

392 all-target tests plus one separately executed doc test pass, as do strict workspace Clippy and formatting. The original API suite exits 1 with 4,347 passing and 393 failing configurations; all 4,740 rows match the canonical baseline under unchanged 3-second per-test, 1 GiB address-space, 768 MiB RSS, and 240-second total bounds.

Six C sanitizer consumers pass, including both original 327-scenario allocation sweeps. Rust release code is uninstrumented; leak checking is disabled. Baseline comparisons are exact for 3,318 deterministic traces, 36,456 custom-encoding controls, 2,392 malformed controls, and 1,304 publication cases (3,912 parses across three libraries). Full malformed observations also preserve exact callback fragmentation.

Publication controls check shared child definitions, partial input, suspension, raw data, UTF-16, and compaction. Their existing Expat differences remain 10,416 Default and 864 external-entity callback positions; outcomes, payloads, order and final positions agree. Nine same-process symbol-origin checks and before/after hashes are retained. The 5 KiB attribute cases exercise arena fallback, not lexical max_token rejection.

All 70 source hashes are unchanged. Controllers reuse the frozen ASCII gate fixtures and original bounds with candidate/worktree/output substitutions. Per-binary all-target counts match the original 392-test baseline log; documentation tests are counted separately. No new tests were introduced. Executables are excluded but hashed. The archive contains original logs, generators, source snapshots, compiler evidence and independent source review; every regular member and nested source snapshot was read back and verified.
