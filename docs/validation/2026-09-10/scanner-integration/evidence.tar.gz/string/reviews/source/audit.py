"""Read-only exact source/delta review; no compilation or parser execution."""
from pathlib import Path
import hashlib,json,tarfile,re,shutil
if not __debug__:raise RuntimeError('Assertions required')
r=Path('/tmp/oriole-string-inline-study');w=Path('/home/dev-user/code/oss/oriole-string-inline');b=Path('/tmp/oriole-text-frames-pr/release');o=Path(__file__).parent
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes());s=read(r/'source.json')['source_sha256'];base=read(b/'source.json')['source_sha256'];name='crates/oriole_storage/src/string.rs'
assert len(s)==70 and set(s)-set(base)=={'crates/oriole_expat/README.md'};assert [n for n in base if base[n]!=s[n]]==[name];assert all(h(w/n)==v for n,v in s.items())
with tarfile.open(r/'source.tar.gz') as t:
 found={}
 for m in t.getmembers():assert m.isfile() and m.name not in found;found[m.name]=hashlib.sha256(t.extractfile(m).read()).hexdigest()
 assert found==s
with tarfile.open(b/'source.tar.gz') as t:old=t.extractfile(name).read().decode()
new=(w/name).read_text();stripped=new
for method in ['try_push_str','try_push','try_reserve','try_reserve_exact']:
 before='    #[inline]\n    pub fn '+method+'(';assert stripped.count(before)==1;stripped=stripped.replace(before,'    pub fn '+method+'(',1)
assert stripped==old
build=read(r/'build.json');assert build['status']=='passed' and build['source_unchanged'] and build['source_manifest_sha256']==h(r/'source.json')
for n,v in build['libraries'].items():assert h(r/n)==v
for c in build['commands']:assert c['exit']==0 and h(r/(c['name']+'.log'))==c['log_sha256']
for n in ['source.json','candidate.patch','DESIGN.md']:shutil.copyfile(r/n,o/n)
shutil.copyfile(w/name,o/'string.rs')
result={'status':'source_review_passed_no_findings','scope':'Only four ordinary inline hints reviewed; no reviewer build, test, parser or timing execution. Source and library identity verified.','source_manifest_sha256':h(r/'source.json'),'source_files':70,'all_live_archive_hashes_exact':True,'changed_file':name,'libraries':build['libraries'],'body_equivalence':'Removing exactly four #[inline] lines restores the control source byte for byte; all other69 source entries unchanged apart from the extra README manifest entry.','proof':['try_push_str still delegates to the same fallible selected-vector extend helper; try_push still encodes exactly one char into its four-byte temporary and invokes try_push_str.','try_reserve and try_reserve_exact still call their original distinct Vec reserve methods with unchanged additional byte count and error conversion. No growth strategy, counter, maximum, checked arithmetic or OOM rule changes.','No String layout, allocator field, ownership transfer, unsafe block or reentry scope changes. UTF8 preservation depends on the same accepted str/char inputs and helper.','Ordinary #[inline] requests compiler visibility/specialization but does not force inline. Resulting code placement and instruction cost must be measured separately; no guarantee of identical machine-level allocation instruction schedule inferred.','Existing storage tests and core Clippy are owner-reported successful evidence, not a substitute for the separate authorized full gates. No new tests or function bodies introduced.'],'evidence_sha256':{str(p):h(p) for p in [r/'source.json',r/'source.tar.gz',r/'candidate.patch',r/'build.json',r/'focused.log',r/'clippy.log',r/'release.log',w/name,w/'crates/oriole_storage/src/lib.rs']}}
(o/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(h(o/'review.json'))
