from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path('/tmp/oriole-ascii-name-scan-gates');r.mkdir(exist_ok=False);b=Path('/tmp/oriole-ascii-name-scan-study');w=Path('/home/dev-user/code/oss/oriole-ascii-name-scan');old=Path('/tmp/oriole-position-words-gates')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();s=json.loads((b/'source.json').read_text());assert len(s['source_sha256'])==70 and all(h(w/n)==v for n,v in s['source_sha256'].items());assert h(b/'source.json')=='2040c1a5923ec9f5c4ff13d76fb4ac4193a12c0ed908a6cb6fb0b1e3d6f675c3';assert h(b/'liboriole_expat.so')=='0ef5ced01ba5a737d12a07d1ec7b717f392fca90517d3f08f3d8bfce6efcaf89'
for n in ['source.json','source.tar.gz','build.json','candidate.patch','compiler-invocations.json']:shutil.copyfile(b/n,r/n)
(r/'tools').mkdir();shutil.copyfile(w/'tools/xml_abi.py',r/'tools/xml_abi.py')
previous={}
for name in ['workspace_checks.py','api_native.py','other_controls.py','publication_probe.py','run_publication.py','prepare_malformed.py','run_malformed.py']:
 previous[name]=h(old/name);text=(old/name).read_text().replace('/tmp/oriole-position-words-gates',str(r)).replace('/tmp/oriole-position-words-study',str(b)).replace('/home/dev-user/code/oss/oriole-position-words',str(w))
 if name!='workspace_checks.py':
  text=text.replace("'taskset','-c','6'","'taskset','-c','1'").replace("'taskset','-c','7'","'taskset','-c','1'").replace('CPU6','CPU1').replace('=={6}','=={1}')
 if name=='api_native.py':text=text.replace("W/'crates/oriole/src/encoding.rs'","W/'crates/oriole/src/tag.rs'")
 if name=='run_publication.py':text += "\nassert r['status']=='passed' and r['exit']==0\n"
 (r/name).write_text(text)
subprocess.run(['python3',str(r/'prepare_malformed.py')],check=True)
(r/'preparation.json').write_text(json.dumps({'status':'passed','source_manifest_sha256':h(b/'source.json'),'source_files':70,'all_live_source_hashes_exact':True,'libraries':json.loads((b/'build.json').read_text())['libraries'],'source_controllers':previous,'controllers':{n:h(r/n) for n in previous},'changes':'Candidate/worktree/output paths and CPU1 substituted from frozen position gate controllers; workspace remainsCPU7. API tracked runtimefile tag.rs. Publication launcher now propagates lower-level failure. Fixture generation/assertions and all bounds unchanged.'},indent=2)+'\n')
