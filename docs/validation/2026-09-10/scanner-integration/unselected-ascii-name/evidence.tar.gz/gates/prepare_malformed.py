from pathlib import Path
import hashlib,json
r=Path('/tmp/oriole-ascii-name-scan-gates');o=r/'malformed';o.mkdir(exist_ok=False)
s=Path('/tmp/oriole-text-prefix-evidence/malformed_probe.py');original=s.read_text();(o/'original-malformed-probe.py').write_text(original)
a=original.replace("'/home/dev-user/code/oss/oriole/tools'",repr(str(r/'tools'))).replace("root=Path('/tmp/oriole-text-prefix-evidence');a=Expat(str(root/'control.so'));b=Expat(str(root/'liboriole_expat.so'));rows=[];differences=[]", "root=Path('/tmp/oriole-ascii-name-scan-gates/malformed');a=Expat('/tmp/oriole-text-frames-pr/release/liboriole_expat.so');b=Expat('/tmp/oriole-ascii-name-scan-study/liboriole_expat.so');rows=[];differences=[]")
a=a.replace('import sys,json,hashlib,itertools','import sys,json,hashlib,itertools,gzip\nif not __debug__: raise RuntimeError("Assertions required")')
a=a.replace('for xml,chunks in cases:', "observations=gzip.open(root/'observations.jsonl.gz','wt')\nfor xml,chunks in cases:")
a=a.replace('x=a.parse(data,chunk);y=b.parse(data,chunk)', 'x=a.parse(data,chunk);y=b.parse(data,chunk)\n   observations.write(json.dumps({"input_sha256":hashlib.sha256(data).hexdigest(),"encoding":encoding,"chunk":chunk,"control":x,"candidate":y})+"\\n")')
a=a.replace("report={'cases':len(rows)", "observations.close()\nassert len(rows)==2392\nreport={'cases':len(rows)")
(o/'malformed_probe.py').write_text(a)
files=[s,o/'malformed_probe.py',r/'tools/xml_abi.py',Path('/tmp/oriole-text-frames-pr/release/liboriole_expat.so'),Path('/tmp/oriole-ascii-name-scan-study/liboriole_expat.so')]
(o/'preparation.json').write_text(json.dumps({'hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'adaptation':'Only paths, assertion of2392, and retention of both full observations added; fixture generation and original comparison fields unchanged.'},indent=2)+'\n')
