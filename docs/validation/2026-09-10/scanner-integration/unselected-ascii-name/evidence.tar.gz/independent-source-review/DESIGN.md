# ASCII name-boundary scanning

Isolated from PR106 on5bc806e; no other pending optimizations included. Only tag::name_end changes: ASCII name continuation characters are recognized directly as bytes, while non-ASCII retains the same edition-specific NameRules predicate. The byte cursor advances only complete UTF8 characters; the initial suffix preserves the original boundary check. No allocation, parser layout, delimiter/error/callback policy or limits change.

The prior5058 profiles put Vulkan name_end plus NameRules::is_name_char self cost near4.6% of total instructions (those whole-function costs are upper bounds). The direct ASCII path avoids Unicode decoding and the out-of-line name predicate for common ASCII XML names. All Unicode scalars under both XML editions, adjacent ASCII pairs at every start position, empty suffixes and long/name-delimiter boundaries are checked against the original character iterator. Focused test, strict core Clippy and fresh normal release pass. Full gates and throughput are deferred until instruction evidence warrants adoption work.

The fixed screen is the same32 profiles and32 normal preflights used for other candidates: six projects, namespace off/on,4KiB; rare declarations/entities,4KiB/64KiB; published5af and candidate0ef5. All outputs, source hashes and instruction counts retained. No wall or broad compatibility claim yet.
