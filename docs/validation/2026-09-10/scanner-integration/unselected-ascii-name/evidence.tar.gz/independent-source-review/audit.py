"""Read-only source/identity audit. Does not execute parser or compiler."""
if not __debug__:raise RuntimeError('Assertions required')
from pathlib import Path
import hashlib,json,tarfile,shutil
r=Path('/tmp/oriole-ascii-name-scan-study');w=Path('/home/dev-user/code/oss/oriole-ascii-name-scan');o=Path(__file__).parent;b=Path('/tmp/oriole-text-frames-pr/release')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
s=read(r/'source.json')['source_sha256'];base=read(b/'source.json')['source_sha256'];assert len(s)==70 and set(s)-set(base)=={'crates/oriole_expat/README.md'};changes=[n for n in base if s[n]!=base[n]];assert changes==['crates/oriole/src/tag.rs'];assert all(h(w/n)==v for n,v in s.items())
with tarfile.open(r/'source.tar.gz') as t:
 found={}
 for m in t.getmembers():
  assert m.isfile() and m.name not in found;found[m.name]=hashlib.sha256(t.extractfile(m).read()).hexdigest()
 assert found==s
build=read(r/'build.json');assert build['source_unchanged'] and build['source_manifest_sha256']==h(r/'source.json')
for n,v in build['libraries'].items():assert h(r/n)==v
for c in build['commands']:assert c['exit']==0 and h(r/(c['name']+'.log'))==c['log_sha256']
for n in ['candidate.patch','DESIGN.md','source.json']:shutil.copyfile(r/n,o/n)
for n in ['tag.rs','names.rs']:shutil.copyfile(w/'crates/oriole/src'/n,o/n)
report={'status':'source_review_passed_no_findings','scope':'Independent read-only ASCII continuation scanner review; no parser, compiler, benchmark or full gate execution. Build/test success is retained owner evidence only.','source_manifest_sha256':h(r/'source.json'),'source_files':70,'all_archived_and_live_source_hashes_exact':True,'common_changes':changes,'extra_manifest_entry':'crates/oriole_expat/README.md','patch_sha256':h(r/'candidate.patch'),'libraries':build['libraries'],'proof':[
'The ASCII branch is exactly the ASCII branch of unchanged NameRules::is_name_char: alphanumeric or colon/underscore/hyphen/period. Both editions share this branch, including rejection of all controls, DEL, whitespace and other punctuation. It does not use NameStart and does not newly permit first-character digits: both production callers retain their separate unchanged NameStart validation.',
'Initial text[offset..] preserves the original bounds/UTF8-boundary precondition and panic behavior. The local index starts at zero. Advancing one ASCII byte or the full len_utf8 of the next accepted non-ASCII scalar preserves the boundary invariant. get(index) proves at least one byte exists before chars().next().unwrap(); a valid str at that boundary guarantees a scalar. A rejected byte/scalar is not consumed.',
'offset+index is bounded by text.len(): index never exceeds the initial suffix length. Empty suffix returns text.len(); complete accepted name returns text.len(); every rejection returns the same first byte offset as the old char_indices iterator. No word-sized reads or alignment assumptions are introduced.',
'On non-ASCII scalars the exact original edition-specific predicate is called. Subsequent ASCII and Unicode runs maintain the same invariant. Fourth/Fifth edition tables, QName constraints, custom-decoder lexical representations and all caller rules remain unchanged.',
'AttributeScanner::next validates the first scalar then resumes at its existing offset; TagScanner::advance does the same and retains incomplete/fallback behavior and floor_char_boundary token-limit slicing. Because the returned offset is identical, scanner state, max_token/attribute limits, raw spans, positions, callback/error order and source retention are unchanged.',
'The loop consumes one scalar per accepted iteration and terminates on the first rejected scalar or end; time remains linear and storage constant. No allocation, selected-allocator call, unsafe access, ownership change or shared state is added.',
'The focused test uses the original iterator as an oracle, all Unicode scalars under both editions after a nonzero UTF8-safe offset, ASCII adjacent pairs at every offset, empty/end suffixes, and lengths around8/16/32/64/128 plus1024. Reviewer inspected test source but did not rerun it.'
],'limitations':['No full API, C consumer, callback matrix or wall-performance certification from this source-only review.','Source proof establishes equivalence for valid str and valid supplied offset, the same precondition as before; it does not extend the function to arbitrary byte offsets.'],'evidence_sha256':{str(p):h(p) for p in [r/'source.json',r/'source.tar.gz',r/'candidate.patch',r/'build.json',r/'focused.log',r/'clippy.log',r/'release.log',w/'crates/oriole/src/tag.rs',w/'crates/oriole/src/names.rs']}}
(o/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(h(o/'review.json'))
