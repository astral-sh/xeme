"""Independent saved-data review; no parser, build or timing execution."""
if not __debug__: raise RuntimeError('Assertions required')
from pathlib import Path
import hashlib,json,math,random,statistics,tarfile
R=Path('/tmp/oriole-ascii-name-scan-timing-study');S=R/'native-screen';O=Path('/tmp/oriole-ascii-name-scan-native-independent-review');O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes());key=lambda c:json.dumps(c,sort_keys=True)
p=read(S/'protocol.json');pre=read(S/'preflight.json');r=read(S/'results.json')
assert p['pairs']==7 and p['preflights']==84 and p['timed_workers']==588;assert pre['status']==r['status']=='passed';assert r['affinity']==[0]
assert pre['protocol_sha256']==r['protocol_sha256']==sha(S/'protocol.json');assert r['preflight_sha256']==sha(S/'preflight.json')
for d in [pre,r]:assert d['hashes_before']==d['hashes_after']==p['hashes']
for file,want in p['hashes'].items():assert sha(file)==want,file
controller=read(R/'timing-controller.json')
assert controller['status']=='passed' and controller['exit']==0 and controller['controller_sha256']==sha('/tmp/oriole-time-ascii-name-native.py')
assert controller['command']==['taskset','-c','0','python3',str(R/'native_screen.py'),'time']
assert p['libraries']['published']['sha256']=='5af2406b17092dad35aa61c086cdfe39e24f51e653441fd9baf50cd12da3b2fe'
assert p['libraries']['candidate']['sha256']=='0ef5ced01ba5a737d12a07d1ec7b717f392fca90517d3f08f3d8bfce6efcaf89'
sources={'scope':'This audit rehashes advertised source/controller/library/input hashes and reconstructs driver provenance. Full70-file candidate source review and correctness gates remain separate receipts.','libraries':p['libraries']}
worker_ordinal=0
conditions=p['conditions'];assert len(conditions)==len({key(c) for c in conditions})==28;engines=['published','candidate','expat'];driver='/tmp/oriole-grammar-bench-plain/native-driver';raw=[]
fixed={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
for c in conditions:assert c['iterations']==fixed[c['name']] and c['chunk'] in [4096,65536]
assert sum(not c['name'].startswith('generated-') for c in conditions)==24

def process(row,c,pair,cpu,count):
 global worker_ordinal
 worker=S/f'worker-{worker_ordinal:04d}.json'; saved=read(worker);assert saved=={k:row[k] for k in saved};assert set(saved)=={'condition','engine','pair','command','returncode','stdout','stderr'};worker_ordinal+=1
 assert row['condition']==c and row['pair']==pair and row['returncode']==0 and row['stderr']==''
 e=row['engine'];assert e in engines;cmd=['taskset','-c',str(cpu),driver,p['libraries'][e]['path'],c['input'],str(c['chunk']),str(count)]+(['namespaces'] if c['namespaces'] else []);assert row['command']==cmd
 data=json.loads(row['stdout']);assert data['version']==('expat_2.8.4' if e=='expat' else 'oriole_compat_2.8.4');samples=data['samples'];assert len(samples)==count+1;assert [s['iteration'] for s in samples]==list(range(count+1));assert [s['warmup'] for s in samples]==[True]+[False]*count;assert all(math.isfinite(s['seconds']) and s['seconds']>0 for s in samples)
 observations=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in samples});assert len(observations)==1 and row['observations']==[list(x) for x in observations];median=statistics.median(s['seconds'] for s in samples[1:]);assert median==row['median_seconds']
 raw.append({'condition':c,'pair':pair,'engine':e,'stdout_sha256':hashlib.sha256(row['stdout'].encode()).hexdigest(),'stderr_sha256':hashlib.sha256(row['stderr'].encode()).hexdigest(),'measured_samples':count})
 return observations,median
assert len(pre['rows'])==84;expected={}
for index,c in enumerate(conditions):
 rows=pre['rows'][index*3:index*3+3];assert [r['engine'] for r in rows]==engines;values=[process(row,c,-1,3,1)[0] for row in rows];assert values[0]==values[1]==values[2];expected[key(c)]=values[0]
rng=random.Random(p['seed']);jobs=[(c,pair) for c in conditions for pair in range(7)];rng.shuffle(jobs);assert len(jobs)==len(r['rows'])==196;ratios={key(c):{n:[] for n in ['candidate_over_published','candidate_over_expat','published_over_expat']} for c in conditions};measured=0
for (c,pair),group in zip(jobs,r['rows'],strict=True):
 order=engines.copy();rng.shuffle(order);assert group['condition']==c and group['pair']==pair and group['order']==order and [x['engine'] for x in group['processes']]==order;times={}
 for row in group['processes']:
  observations,median=process(row,c,pair,0,c['iterations']);assert observations==expected[key(c)];times[row['engine']]=median;measured+=c['iterations']
 for label in ratios[key(c)]:a,b=label.split('_over_');ratios[key(c)][label].append(times[a]/times[b])
computed=[{'condition':c,'paired_ratios':ratios[key(c)],'median_ratios':{k:statistics.median(v) for k,v in ratios[key(c)].items()}} for c in conditions];assert r['summary']==computed;assert measured==105420
computed_groups={}
for name,predicate in [('real',lambda c:not c['name'].startswith('generated-')),('generated',lambda c:c['name'].startswith('generated-')),('namespaces-off',lambda c:not c['name'].startswith('generated-') and not c['namespaces']),('namespaces-on',lambda c:not c['name'].startswith('generated-') and c['namespaces'])]:
 computed_groups[name]={}
 for label in ratios[key(conditions[0])]:
  values=[row['median_ratios'][label] for row in computed if predicate(row['condition'])];result={'geomean':math.exp(sum(math.log(v) for v in values)/len(values)),'below_one':sum(v<1 for v in values),'conditions':len(values)};computed_groups[name][label]=result
assert worker_ordinal==672 and len(list(S.glob('worker-*.json')))==672
published_summary=read(R/'summary.json')
for name in ['real','generated']:
 g=published_summary['groups'][name];assert g['conditions']==computed_groups[name]['candidate_over_published']['conditions']
 for label,stats in g['ratios'].items():
  assert stats=={k:computed_groups[name][label][k] for k in ['geomean','below_one']}
regressions=[{'condition':row['condition'],'ratio':row['median_ratios']['candidate_over_published']} for row in computed if row['median_ratios']['candidate_over_published']>1]
assert published_summary['regressions']==regressions and len(regressions)==15
assert sum(not row['condition']['name'].startswith('generated-') for row in regressions)==11
# Stable driver provenance predates this timing study; no newly executed origin probe.
origin=read('/tmp/oriole-grammar-bench-plain/summary.json')
driver_source=Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')
for x in [str(driver_source),driver]:assert origin['sha256_before'][x]==sha(x)
assert origin['sha256_before'][driver]==p['hashes'][driver]
source=driver_source.read_text();assert 'dlopen(argv[1], RTLD_NOW | RTLD_LOCAL)' in source and 'dlsym(library, symbol)' in source
sources['driver']={'source_sha256':sha(driver_source),'binary_sha256':sha(driver),'original_build_command':origin['build_command'],'build_record_sha256':sha('/tmp/oriole-grammar-bench-plain/summary.json'),'binding':'Explicit per-process absolute library path, dlopen RTLD_LOCAL and dlsym on that handle. Output versions checked. No per-worker dladdr receipt was emitted by this established driver.'}

(O/'streams.json').write_text(json.dumps(raw,indent=2)+'\n')
(O/'summary.json').write_text(json.dumps(computed_groups,indent=2)+'\n')
report={'status':'passed_no_findings','scope':'Independent saved native data/hash/order/arithmetic audit only; no parser/build/timing execution. Study-root summary and both retained adverse conditions match independent reconstruction exactly. Full source/build/profile audit is separate.','counts':{'preflight_processes':84,'preflight_samples_including_warmups':168,'timed_processes':588,'timed_warmups':588,'measured_samples':measured,'cohorts':196,'conditions':28,'retained_worker_json_files':worker_ordinal},'identities':sources,'groups':computed_groups,'checks':['All advertised hashes current and before/after maps exact.','All672 immediate worker records match the later preflight/results records exactly on every original field.','All672 stdout/stderr, command CPUs/arguments, samples/callback counts/hashes and588 process medians checked.','All196 seeded cohorts/orders and588 paired ratios/84 medians/12 group geomeans reproduced.'],'limitations':['Native timer includes construct/parse/native callback/free, not process startup or application work.','Hashes/counts are normalized selected callback observations, not exact fragmentation/position conformance.','Same seven fixed cohorts, one excluded warmup per process, no sample removal. Affinity does not eliminate shared-host interference.','The engine key published denotes exact5bc control5af, not older4b source.','Candidate improves13/24 real conditions versus control, with effectively flat aggregate wall time; all four generated controls regress and no condition beats Expat. Root left candidate unselected, with no further tuning.','Batik external DTD is not loaded.','Initial audit used an inferred outer-wrapper filename that did not exist and stopped before reading samples. Corrected to actual retained oriole-time-ascii-name-native.py and checked its recorded hash; initial audit source preserved.'],'hashes':{str(x):sha(x) for x in [Path(__file__),Path('/tmp/oriole-time-ascii-name-native.py'),R/'native_screen.py',R/'timing-controller.json',R/'summary.json',R/'preparation.json',driver_source,S/'protocol.json',S/'preflight.json',S/'results.json',O/'summary.json',O/'streams.json']}}
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(sha(O/'review.json'));print(json.dumps(computed_groups['real']))
