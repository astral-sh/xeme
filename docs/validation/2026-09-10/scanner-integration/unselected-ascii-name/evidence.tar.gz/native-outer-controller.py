import hashlib
import json
from pathlib import Path
import signal
import subprocess
import time

out = Path('/tmp/oriole-ascii-name-scan-timing-study')
command = ['taskset', '-c', '0', 'python3', str(out / 'native_screen.py'), 'time']
report = {'status': 'incomplete', 'command': command, 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
          'controller_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
start = time.monotonic()
with (out / 'timing-controller.log').open('wb') as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        report['exit'] = process.wait(timeout=1200)
    except subprocess.TimeoutExpired:
        report['timeout'] = True
        import os
        os.killpg(process.pid, signal.SIGKILL)
        report['exit'] = process.wait()
    finally:
        if process.poll() is None:
            import os
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        report['elapsed_seconds'] = time.monotonic() - start
        report['status'] = 'passed' if report.get('exit') == 0 else 'failed'
        (out / 'timing-controller.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
raise SystemExit(0 if report['status'] == 'passed' else 1)
