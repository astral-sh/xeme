import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path('/home/dev-user/code/oss/oriole-ascii-name-scan')
out = Path('/tmp/oriole-ascii-name-scan-study')
out.mkdir(exist_ok=False)
target = '/home/dev-user/.cache/oriole/ascii-name-scan-target'
env_overrides = {'CARGO_HOME': '/home/dev-user/.cache/toucan/cargo', 'CARGO_TARGET_DIR': target,
                 'CARGO_BUILD_BUILD_DIR': '/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}',
                 'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST': 'all', 'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST': 'all',
                 'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0', 'RUSTC_WRAPPER': '',
                 'RUSTC_WORKSPACE_WRAPPER': '', 'RUSTFLAGS': '', 'CARGO_ENCODED_RUSTFLAGS': ''}
env = os.environ | env_overrides
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert os.sched_getaffinity(0) == {3}
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == '5bc806e5fc2a545f22c75f2a1bcbef45cfa3632b'
with (out / 'fmt-write.log').open('wb') as log:
    subprocess.run(['cargo', '+ohm', '-Zohm-defaults=no', 'fmt', '--all'], cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
names = subprocess.check_output(['git', 'ls-files', '-z', 'crates', 'include', 'tests/c', 'Cargo.toml', 'Cargo.lock'], cwd=root).decode().rstrip('\0').split('\0')
source = {name: digest(root / name) for name in names}
(out / 'source.json').write_text(json.dumps({'worktree': str(root), 'base': '5bc806e5fc2a545f22c75f2a1bcbef45cfa3632b', 'source_sha256': source}, indent=2) + '\n')
(out / 'candidate.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=root))
with tarfile.open(out / 'source.tar.gz', 'w:gz') as archive:
    for name in source:
        archive.add(root / name, arcname=name, recursive=False)
for name in source:
    os.utime(root / name, None)
shutil.copy2(__file__, out / Path(__file__).name)
report = {'status': 'incomplete', 'env_overrides': env_overrides, 'source_manifest_sha256': digest(out / 'source.json'),
          'commands': [], 'rustc': subprocess.check_output(['rustc', '+ohm', '-vV'], cwd=root, env=env, text=True),
          'note': 'Created by cargo+ohm worktree; all compilation here disables experimental defaults and uses private intermediates. Isolated ASCII name boundary scan on5bc806e with unchanged Unicode predicate and one focused oracle.'}
jobs = [('focused', ['test', '-p', 'oriole', '--lib', 'ascii_name_scan_matches_both_editions_at_unicode_boundaries', '--locked']),
        ('clippy', ['clippy', '-p', 'oriole', '--lib', '--tests', '--locked', '--', '-D', 'warnings']),
        ('release', ['build', '--release', '--locked', '-p', 'oriole_expat', '-vv'])]
try:
    for name, args in jobs:
        command = ['cargo', '+ohm', '-Zohm-defaults=no', *args]
        with (out / (name + '.log')).open('wb') as log:
            run = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
        report['commands'].append({'name': name, 'command': command, 'exit': run.returncode, 'log_sha256': digest(out / (name + '.log'))})
        print(name, run.returncode, flush=True)
        assert run.returncode == 0
        assert all(digest(root / p) == value for p, value in source.items())
    invocations = [line for line in (out / 'release.log').read_text().splitlines() if 'Running' in line and '/rustc ' in line]
    for crate in ['oriole_storage', 'oriole', 'oriole_expat']:
        assert len([line for line in invocations if '--crate-name ' + crate + ' ' in line]) == 1
    (out / 'compiler-invocations.json').write_text(json.dumps(invocations, indent=2) + '\n')
    report['libraries'] = {}
    for name in ['liboriole_expat.so', 'liboriole_expat.a']:
        shutil.copy2(Path(target) / 'release' / name, out / name)
        report['libraries'][name] = digest(out / name)
    report['status'] = 'passed'
finally:
    report['source_unchanged'] = all(digest(root / p) == value for p, value in source.items())
    (out / 'build.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ['status', 'libraries'] if key in report}), flush=True)
