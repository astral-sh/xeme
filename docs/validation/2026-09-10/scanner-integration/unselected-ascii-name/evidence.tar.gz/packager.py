"""Package completed correctness gates, excluding binaries, then hash readback."""
if not __debug__:raise RuntimeError('Assertions required')
from pathlib import Path
import hashlib,json,shutil,tarfile,io,os
r=Path('/tmp/oriole-ascii-name-scan-gates');o=Path('/tmp/oriole-ascii-name-scan-handoff');o.mkdir(exist_ok=False)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_bytes())
assert read(r/'summary.json')['malformed_baseline_comparisons']==2392
files={};excluded=[]
for prefix,root in [('gates',r),('independent-source-review',Path('/tmp/oriole-ascii-name-scan-independent-review')),('owner-study',Path('/tmp/oriole-ascii-name-scan-study')),('native-study',Path('/tmp/oriole-ascii-name-scan-timing-study')),('python-preflight-study',Path('/tmp/oriole-ascii-name-scan-python-study')),('native-review',Path('/tmp/oriole-ascii-name-scan-native-independent-review')),('python-preflight-review',Path('/tmp/oriole-ascii-name-scan-python-independent-review'))]:
 for p in sorted(root.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
  if p.is_symlink():
   assert p.read_bytes()[:4]==b'\x7fELF';excluded.append({'path':str(p),'kind':'binary_symlink','target':os.readlink(p),'target_sha256':h(p)});continue
  with p.open('rb') as f:magic=f.read(8)
  if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':excluded.append({'path':str(p),'sha256':h(p),'size':p.stat().st_size});continue
  files[prefix+'/'+str(p.relative_to(root))]=p
for n in ['release.log','focused.log','clippy.log','DESIGN.md']:
 files['owner-build/'+n]=Path('/tmp/oriole-ascii-name-scan-study')/n
for n in ['source.json','source.tar.gz','report.json','build.log','workspace-compiler-invocations.json']:
 files['control-build/'+n]=Path('/tmp/oriole-text-frames-pr/release')/n
files['packager.py']=Path(__file__)
for base in ['/tmp/oriole-ascii-name-scan-study','/tmp/oriole-text-frames-pr/release']:
 for name in ['liboriole_expat.so','liboriole_expat.a']:
  p=Path(base)/name;excluded.append({'path':str(p),'sha256':h(p),'size':p.stat().st_size})
native=read('/tmp/oriole-ascii-name-scan-timing-study/native-screen/protocol.json')
for c in native['conditions']:files['inputs/'+c['name']+'.xml']=Path(c['input'])
files['inputs/corpus-manifest.json']=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
files['native-driver.c']=Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')
files['native-audit.py']=Path('/tmp/oriole-ascii-name-scan-native-independent-audit.py')
files['native-outer-controller.py']=Path('/tmp/oriole-time-ascii-name-native.py')
members={n:{'sha256':h(p),'size':p.stat().st_size} for n,p in files.items()}
with tarfile.open(o/'evidence.tar.gz','w:gz') as t:
 for n,p in files.items():t.add(p,arcname=n,recursive=False)
with tarfile.open(o/'evidence.tar.gz','r:gz') as t:
 got={};nested=[]
 for m in t.getmembers():
  assert m.isfile() and m.name not in got;b=t.extractfile(m).read();got[m.name]={'sha256':hashlib.sha256(b).hexdigest(),'size':len(b)}
  if m.name.endswith('/source.tar.gz'):
   jname=m.name.removesuffix('source.tar.gz')+'source.json';sm=read(files[jname]);expected=sm['source_sha256'];actual={}
   with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as inner:
    for x in inner.getmembers():
     assert x.isfile() and x.name not in actual;actual[x.name]=hashlib.sha256(inner.extractfile(x).read()).hexdigest()
   assert actual==expected,(m.name,set(actual)^set(expected));nested.append({'archive':m.name,'members':len(actual),'all_source_hashes_exact':True})
 assert got==members
for n in ['candidate.patch','source.json']:shutil.copyfile(r/n,o/n)
summary=read(r/'summary.json');summary['status']='unselected';summary['selection_reason']='Native wall real geomean0.999324 is effectively flat (13/24 lower), all4 generated controls regress. No actual-Python timing run; no tuning.';summary['native_wall']=read('/tmp/oriole-ascii-name-scan-native-independent-review/review.json')['groups'];summary['python_preflight_only']={'extension_builds':6,'preflights':72,'timed_workers':0,'measured_samples':0};(o/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(o/'README.md').write_text('''# ASCII name-scanner experiment — unselected

The frozen candidate changes only tag::name_end. It recognizes ASCII name continuation bytes directly and retains the existing edition-specific predicate for each non-ASCII scalar. Both production callers keep their existing first-character validation. The isolated candidate remains unselected. Real native wall time is effectively flat (candidate/control 0.999324, 13 of 24 conditions lower); all four generated conditions regress (geomean 1.017098). All 588 workers and 84 preflights are retained. Six original CPython extension builds and 72 canonical-output preflights passed, but no actual-Python timing campaign ran. No tuning or source integration followed.

393 all-target tests plus one doc test pass, as do strict workspace Clippy and formatting. The original API suite exits 1 with 4,347 passing and 393 failing configurations; all 4,740 rows match the canonical baseline under unchanged 3-second per-test, 1 GiB address-space, 768 MiB RSS, and 240-second total bounds.

Six C sanitizer consumers pass, including both original 327-scenario allocation sweeps. Rust release code is uninstrumented; leak checking is disabled. Baseline comparisons are exact for 3,318 deterministic traces, 36,456 custom-encoding controls, 2,392 malformed controls, and 1,304 publication cases (3,912 parses across three libraries). Full malformed observations also preserve exact callback fragmentation.

Publication controls check shared child definitions, partial input, suspension, raw data, UTF-16, and compaction. Their existing Expat differences remain 10,416 Default and 864 external-entity callback positions; outcomes, payloads, order and final positions agree. Nine same-process symbol-origin checks and before/after hashes are retained. The 5 KiB attribute cases exercise arena fallback, not lexical max_token rejection.

All 70 source hashes are unchanged. Controllers reuse the position-word gate fixtures and original bounds with candidate, worktree, output and CPU substitutions; the publication launcher now propagates lower-level failure explicitly. The interim report preserves that workspace checks were initially pending. Executables are excluded but hashed. The archive contains original logs, generators, source snapshots, owner instruction profiles, all native samples, Python preflights, compiler evidence and independent source/native/preflight reviews; every regular member and nested source snapshot was read back and verified.
''')
for name,obj in [('members.json',members),('excluded-binaries.json',excluded),('readback.json',{'status':'passed','members':len(members),'bytes':sum(x['size'] for x in members.values()),'archive_sha256':h(o/'evidence.tar.gz'),'nested_sources':nested})]:
 (o/name).write_text(json.dumps(obj,indent=2)+'\n')
manifest={p.name:{'sha256':h(p),'size':p.stat().st_size} for p in sorted(o.iterdir())};(o/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(h(o/n)==v['sha256'] for n,v in manifest.items())
print(json.dumps({'directory':str(o),'manifest_sha256':h(o/'manifest.json'),'archive_sha256':h(o/'evidence.tar.gz'),'members':len(members),'nested':nested}),flush=True)
