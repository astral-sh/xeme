"""Reconstruct fresh three-engine CPython samples without executing workers."""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import math
import random
import statistics

if not __debug__:
    raise RuntimeError('Audit assertions must run')
B = Path('/tmp/oriole-ascii-name-scan-python-study')
S = B / 'screen'
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_bytes())
pre = load(S / 'preflight.json')
r = pre
build = load(B / 'consumers/build.json')

source_review = load('/tmp/oriole-ascii-name-scan-independent-review/review.json')
assert pre['status']=='preflight_passed' and not (S/'results.json').exists() and not (B/'timing-controller.json').exists()
assert pre['affinity']==[3]
assert pre['kind'] == r['kind'] == 'python'
assert pre['conditions'] == r['conditions']
assert r['preflights'] == pre['preflights'] and r['expected'] == pre['expected']
assert len(pre['processes']) == len(pre['preflights']) == 72
assert pre['pairs'] == r['pairs'] == 7
assert pre['seed'] == r['seed'] == 202609104412
assert pre['hashes_before'] == pre['hashes_after'] == r['hashes_before'] == r['hashes_after']
for record in [pre, r]:
    assert not record['hash_errors']
    assert all(sha(p) == h for p, h in record['hashes_before'].items())
assert sha(B / 'python_worker.py') == '4bc0ccffedb5048412b9cfc3638d28dcb30f711891c3784f3fbd3c0eb536ab68'
assert build['status'] == 'passed' and build['adaptations'] is None
assert build['cpython_revision'] == '3bb231a6a5dc02b95658877318bf61501a7209e9'
assert build['source_sha256_before'] == build['source_sha256_after']
assert all(sha(p) == h for p, h in build['source_sha256_before'].items())
engines = ['published', 'candidate', 'expat']
libraries = {'published': '5af2406b17092dad35aa61c086cdfe39e24f51e653441fd9baf50cd12da3b2fe',
             'candidate': '0ef5ced01ba5a737d12a07d1ec7b717f392fca90517d3f08f3d8bfce6efcaf89',
             'expat': '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'}
assert set(build['consumers']) == set(engines)
normalized_commands = {}
for engine, consumer in build['consumers'].items():
    assert sha(consumer['library']) == libraries[engine]
    assert all(sha(p) == h for p, h in consumer['files'].items())
    assert len(consumer['commands']) == 2
    normalized = []
    for module, command in zip(['pyexpat', '_elementtree'], consumer['commands'], strict=True):
        args = command['command']
        assert command['returncode'] == 0 and args[:4] == ['cc', '-shared', '-fPIC', '-O2']
        assert sha(Path(consumer['directory']) / (module + '-build.log')) == command['log_sha256']
        assert args[-4] == consumer['library']
        normalized.append([x.replace(consumer['library'], '<PARSER-LIBRARY>').replace(consumer['directory'], '<CONSUMER-DIR>') for x in args])
    normalized_commands[engine] = normalized
assert all(v == normalized_commands['published'] for v in normalized_commands.values())

manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
iterations = {'vulkan': 3, 'wayland': 16, 'maven': 32, 'batik': 128, 'gtk': 64, 'docbook': 64}
conditions = []
for project in load(manifest)['projects']:
    entry = next(x for x in project['files'] if x['role'] == 'input')
    path = (manifest.parent / entry['path']).resolve()
    assert sha(path) == entry['sha256']
    for chunk in [4096, 65536]:
        for mode in ['elementtree', 'pyexpat-events']:
            conditions.append({'name': project['name'], 'chunk': chunk, 'mode': mode, 'input': str(path), 'iterations': iterations[project['name']]})
assert conditions == r['conditions'] and len(conditions) == 24
key = lambda c: f"{c['name']}/{c['chunk']}/{c['mode']}"
condition_map = {key(c): c for c in conditions}
index = {}
counts = Counter()
raw_hashes = {}
for phase, record, rowname in [('preflight', pre, 'preflights')]:
    processes = {p['label']: p for p in record['processes']}
    assert len(processes) == len(record['processes'])
    assert set(processes) == {row['process'] for row in record[rowname]}
    for row in record[rowname]:
        process = processes[row['process']]
        assert process['status'] == 'passed' and process['returncode'] == 0 and process['timeout_seconds'] == 300
        assert 'failure' not in process
        for stream in ['stdout', 'stderr']:
            path = S / process[stream]
            assert sha(path) == process[stream + '_sha256']
            raw_hashes[str(path)] = sha(path)
        assert not gzip.decompress((S / process['stderr']).read_bytes())
        raw = json.loads(gzip.decompress((S / process['stdout']).read_bytes()))
        assert raw['gc_enabled'] is True
        assert raw['samples'] == row['samples'] and raw['identity'] == row['identity']
        engine = row['engine']
        consumer = build['consumers'][engine]
        assert raw['identity']['parser_library']['sha256'] == libraries[engine]
        assert raw['identity']['expat_version'] == ('expat_2.8.4' if engine == 'expat' else 'oriole_compat_2.8.4')
        for name in ['pyexpat', '_elementtree', 'parser_library']:
            entry = raw['identity'][name]
            assert consumer['files'][entry['path']] == entry['sha256'] == sha(entry['path'])
        command = process['command']
        assert command[1:5] == ['-I', '-S', str(B / 'python_worker.py'), '--worker']
        specpath = Path(command[-1])
        spec = load(specpath)
        raw_hashes[str(specpath)] = sha(specpath)
        c = condition_map[row['key']]
        count = 0 if phase == 'preflight' else c['iterations']
        assert spec == {'input': c['input'], 'input_sha256': sha(c['input']), 'chunk': c['chunk'], 'mode': c['mode'], 'consumer': consumer['directory'], 'library_sha256': libraries[engine], 'iterations': count}
        assert len(raw['samples']) == count + 1
        for i, sample in enumerate(raw['samples']):
            assert sample['iteration'] == i and sample['warmup'] == (i == 0)
            assert sample['seconds'] == (sample['parse_ns'] + sample['destruction_ns']) / 1e9
            assert sample['seconds'] > 0 and math.isfinite(sample['seconds'])
            assert sample['parse_ns'] >= 0 and sample['destruction_ns'] >= 0
            assert [sample['output_sha256'], sample['output_rows']] == pre['expected'][row['key']]
            counts[phase + ('_warmups' if i == 0 else '_measured')] += 1
        median = statistics.median(s['seconds'] for s in raw['samples'][1:]) if count else None
        assert row['median_seconds'] == median
        if phase == 'time':
            identity = (row['key'], row['pair'], engine)
            assert identity not in index
            index[identity] = median
expected_preflights = [(key(c), engine) for c in conditions for engine in engines]
assert [(row['key'], row['engine']) for row in pre['preflights']] == expected_preflights
assert counts=={'preflight_warmups':72}
prep=load(B/'preparation.json');assert prep['status']=='passed' and len(prep['jobs'])==2 and all(x['exit']==0 and x['command'][:3]==['taskset','-c','3'] for x in prep['jobs'])
old=Path('/tmp/oriole-position-words-python-study')
assert sha(B/'python_worker.py')==sha(old/'python_worker.py') and sha(B/'build_consumers.py')==sha(old/'build_consumers.py')
a=(old/'consumer_screen.py').read_text().splitlines();b=(B/'consumer_screen.py').read_text().splitlines();assert len(a)==len(b);delta=[(x,y) for x,y in zip(a,b) if x!=y];assert len(delta)==1 and delta[0][0].strip().startswith('"method":') and delta[0][1].strip().startswith('"method":')
(OUT/'audited-raw-files.json').write_text(json.dumps(raw_hashes,indent=2)+'\n')
paths=[Path(__file__),B/'python_worker.py',B/'consumer_screen.py',B/'build_consumers.py',B/'consumers/build.json',B/'preparation.json',S/'preflight.json',OUT/'audited-raw-files.json']
result={'status':'preflight_only_verified','scope':'Read-only saved preflight/consumer-build audit. No worker execution, compilation or timing. Candidate unselected after separate negative native screen; no actual-Python timing run exists here.','preflights':72,'timed_workers':0,'measured_samples':0,'warmup_validation_samples':72,'conditions':24,'source_extension_builds':6,'libraries':libraries,'raw_files_verified':len(raw_hashes),'checks':['All six extension build commands have identical normalized flags and unchanged original sources.','Each of72 workers proves extension paths and XML_Parse dladdr origin and canonical output matches all three engines.','All72 original specs and144 compressed streams rehashed; positive warmup times retained but not compared as performance.','No results.json or timing-controller.json; no performance ratio inferred.'],'limitations':['Both consumers use namespaces; no external DTD or full-application execution.','Only preflight canonical output equality is established; no full strict CPython suite or callback-fragmentation equivalence claim.'],'evidence_sha256':{str(x):sha(x) for x in paths}}
(OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(sha(OUT/'review.json'))
