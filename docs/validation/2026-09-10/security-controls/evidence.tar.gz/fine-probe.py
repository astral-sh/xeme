import ctypes as c
import hashlib
import itertools
import json
import os
from pathlib import Path

LIBRARIES = {
    'reference': '/home/dev-user/.cache/oriole/expat-build/libexpat.so',
    'candidate': os.environ.get('ORIOLE_LIBRARY', '/tmp/oriole-api-amplification/initial/liboriole_expat.so'),
}
TEXT = c.CFUNCTYPE(None, c.c_void_p, c.c_char_p, c.c_int)
EXTERNAL = c.CFUNCTYPE(c.c_int, c.c_void_p, c.c_char_p, c.c_char_p, c.c_char_p, c.c_char_p)

def setup(path):
    lib = c.CDLL(path)
    for name, args, result in [
        ('XML_ParserCreate', [c.c_char_p], c.c_void_p),
        ('XML_ExternalEntityParserCreate', [c.c_void_p, c.c_char_p, c.c_char_p], c.c_void_p),
        ('XML_Parse', [c.c_void_p, c.c_char_p, c.c_int, c.c_int], c.c_int),
        ('XML_GetErrorCode', [c.c_void_p], c.c_int),
        ('XML_ParserFree', [c.c_void_p], None),
        ('XML_SetParamEntityParsing', [c.c_void_p, c.c_int], c.c_int),
        ('XML_SetBillionLaughsAttackProtectionMaximumAmplification', [c.c_void_p, c.c_float], c.c_ubyte),
        ('XML_SetBillionLaughsAttackProtectionActivationThreshold', [c.c_void_p, c.c_ulonglong], c.c_ubyte),
        ('XML_SetCharacterDataHandler', [c.c_void_p, TEXT], None),
        ('XML_SetDefaultHandler', [c.c_void_p, TEXT], None),
        ('XML_SetExternalEntityRefHandler', [c.c_void_p, EXTERNAL], None),
    ]:
        fn = getattr(lib, name); fn.argtypes = args; fn.restype = result
    return lib

def document(declarations, body, padding=0):
    return f'<!DOCTYPE r [{declarations}]><r>{body}</r>'.encode() + b' ' * padding

def run(lib, data, external, factor, threshold, chunk, default):
    parser = lib.XML_ParserCreate(None)
    assert parser
    assert lib.XML_SetBillionLaughsAttackProtectionMaximumAmplification(parser, factor)
    assert lib.XML_SetBillionLaughsAttackProtectionActivationThreshold(parser, threshold)
    assert lib.XML_SetParamEntityParsing(parser, 2)
    errors = []
    output = []
    def feed(parser, data):
        width = chunk or max(1, len(data))
        for offset in range(0, max(1, len(data)), width):
            piece = data[offset:offset + width]
            status = lib.XML_Parse(parser, piece, len(piece), offset + width >= len(data))
            if status != 1:
                errors.append(lib.XML_GetErrorCode(parser))
                return 0
        return 1
    @TEXT
    def text(_, value, length):
        output.append(c.string_at(value, length).decode())
    @TEXT
    def ignored(*_):
        pass
    @EXTERNAL
    def load(parent, context, base, system, public):
        child = lib.XML_ExternalEntityParserCreate(parent, context, None)
        assert child
        result = feed(child, external[system.decode()])
        lib.XML_ParserFree(child)
        return result
    lib.XML_SetCharacterDataHandler(parser, text)
    lib.XML_SetExternalEntityRefHandler(parser, load)
    if default:
        lib.XML_SetDefaultHandler(parser, ignored)
    status = feed(parser, data)
    lib.XML_ParserFree(parser)
    return {'status': status, 'errors': errors, 'text': ''.join(output) if status else None}

cases = {
    'plain': (b'<r>' + b'a' * 100 + b'</r>', {}),
    'predefined': (b'<r>' + b'&amp;&lt;&#65;' * 20 + b'</r>', {}),
    'general': (document('<!ENTITY e "' + 'a' * 100 + '">', '&e;' * 10), {}),
    'trailing-padding': (document('<!ENTITY e "' + 'a' * 100 + '">', '&e;' * 10, 10000), {}),
    'nested': (document('<!ENTITY e "' + 'a' * 100 + '"><!ENTITY n "&e;&e;&e;">', '&n;' * 10), {}),
    'attribute': (document('<!ENTITY e "' + 'a' * 100 + '">', '<s a="' + '&e;' * 10 + '"/>'), {}),
    'attribute-predefined': (document('<!ENTITY e "a&amp;&#65;b">', '<s a="' + '&e;' * 10 + '"/>'), {}),
    'default': (document('<!ENTITY e "' + 'a' * 100 + '"><!ATTLIST s a CDATA "&e;">', '<s/>' * 30), {}),
    'parameter': (document('<!ENTITY % e "<!ELEMENT s EMPTY>">' , '<s/>').replace(b']>', b'%e;%e;%e;]>'), {}),
    'external-content': (document('<!ENTITY e SYSTEM "e">', '&e;&e;&e;'), {'e': b'<s>' + b'a' * 100 + b'</s>'}),
    'external-dtd': (b'<!DOCTYPE r SYSTEM "e"><r>&n;&n;</r>', {'e': b'<!ENTITY a "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"><!ENTITY n "&a;&a;&a;">'}),
    'external-parameter-value': (b'<!DOCTYPE r SYSTEM "e"><r>&n;&n;</r>', {'e': b'<!ENTITY % a "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"><!ENTITY n "%a;%a;%a;">'}),
    'external-value-skipped-tail': (b'<!DOCTYPE r SYSTEM "e"><r>&n;</r>', {'e': b'<!ENTITY % a SYSTEM "v"><!ENTITY n "%a;">', 'v': b'X%missing;' + b'y' * 10000}),
    'external-value-internal-tail': (b'<!DOCTYPE r SYSTEM "e"><r>&n;</r>', {'e': b'<!ENTITY % a SYSTEM "v"><!ENTITY % b "bbbb"><!ENTITY n "%a;">', 'v': b'X%b;' + b'y' * 10000}),
    'external-value': (b'<!DOCTYPE r SYSTEM "e"><r>&n;&n;</r>', {'e': b'<!ENTITY % a SYSTEM "v"><!ENTITY n "%a;%a;%a;">', 'v': b'a' * 100}),
    'external-value-existing-open-state-difference': (b'<!DOCTYPE r SYSTEM "e"><r>&n;&n;</r>', {'e': b'<!ENTITY % a SYSTEM "v"><!ENTITY % b "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"><!ENTITY n "%a;%a;%a;">', 'v': b'%b;%b;%b;'}),
}
for name in ['general', 'trailing-padding', 'attribute', 'default', 'predefined', 'external-parameter-value']:
    data, external = cases[name]
    cases[name + '-utf16'] = (b'\xff\xfe' + data.decode().encode('utf-16le'), external)

libs = {name: setup(path) for name, path in LIBRARIES.items()}
rows = []; count = 0
for (name, (data, external)), factor, threshold, chunk, default in itertools.product([(n,v) for n,v in cases.items() if n in ['general','nested','attribute','attribute-predefined','default','parameter','external-content','external-dtd','external-parameter-value','external-value']], [1 + index / 20 for index in range(181)], [0, 22, 100, 1000], [0], [False, True]):
    results = {label: run(lib, data, external, factor, threshold, chunk, default) for label, lib in libs.items()}
    count += 1
    if results['reference'] != results['candidate']:
        rows.append({'case': name, 'factor': factor, 'threshold': threshold, 'chunk': chunk, 'default': default, 'results': results})
report = {'comparisons': count, 'mismatch_count': len(rows), 'mismatches': rows, 'libraries': {name: {'path': path, 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest()} for name, path in LIBRARIES.items()}}
Path(os.environ.get('ORIOLE_REPORT', '/tmp/oriole-api-amplification/probe.json')).write_text(json.dumps(report, indent=2) + '\n')
from collections import Counter
print(json.dumps({'comparisons': count, 'mismatches': len(rows), 'cases': dict(Counter(row['case'] for row in rows))}))
