import hashlib,json,tarfile,shutil,statistics
from pathlib import Path
work=Path('/tmp/oriole-security-controls-integrated');dest=Path('docs/validation/2026-09-10/security-controls');dest.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((work/'source.json').read_text());api=json.loads((work/'upstream-api/results.json').read_text());native=json.loads((work/'native.json').read_text());screen=json.loads((work/'screen.json').read_text())
assert api['selection_complete'] and api['library_origin_verified'] and not api['timed_out'];assert len(api['results'])==4740 and len(native['runs'])==6 and all(x['returncode']==0 for x in native['runs']);assert screen['status']=='passed'
grids=[]
for name in ['amplification-grid','amplification-fine-grid']:
 r=json.loads((work/(name+'.json')).read_text());assert all(x['results']['candidate']['status']==x['results']['reference']['status'] for x in r['mismatches']);grids.append({'comparisons':r['comparisons'],'acceptance_mismatches':0,'nested_error_differences':r['mismatch_count']})
for name in ['probe.py','fine-probe.py']:shutil.copy2(Path('/tmp/oriole-api-amplification')/name,work/name)
old=Path('/tmp/oriole-upstream-grammar-combined/adapted');current=work/'upstream-api/adapted';changes=[str(p.relative_to(current)) for p in current.rglob('*') if p.is_file() and (old/p.relative_to(current)).is_file() and sha(p)!=sha(old/p.relative_to(current))]
summary={'library_sha256':source['library_sha256'],'rust_tests':source['rust_tests'],'upstream_api':{k:api[k] for k in ['passed','failed','selection_complete','library_origin_verified','timed_out']},'matrix_configurations':len(api['results']),'changed_adapted_test_files_vs_initial':changes,'allocation_test_failures':sum(r['outcome']!='pass' and r['test'].startswith(('test_alloc_','test_nsalloc_','test_misc_alloc_'))for r in api['results']),'amplification_grids':grids,'native_runs':6,'allocation_scenarios_per_linkage':332,'performance':'Paired screening measures approximately 3–10% overhead from the combined controls; the raw per-process samples are retained. This layer does not claim a speed improvement.'}
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for p in sorted(work.rglob('*')):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 files[str(p.relative_to(work))]={'sha256':sha(p),'bytes':p.stat().st_size}
with tarfile.open(dest/'evidence.tar.gz','w:gz',compresslevel=9) as tar:
 for n in files:tar.add(work/n,arcname=n,recursive=False)
with tarfile.open(dest/'evidence.tar.gz') as tar:
 for m in tar:assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==files[m.name]['sha256']
manifest={'archive_sha256':sha(dest/'evidence.tar.gz'),'members':files};(dest/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
(dest/'README.md').write_text(f'''# Combined Expat security controls

This release runtime combines consumed-byte entity amplification and caller hash salts with the name-throughput and input-context layers. Its shared library is `{source['library_sha256']['liboriole_expat.so']}`; the static archive is `{source['library_sha256']['liboriole_expat.a']}`. The [isolated amplification](../entity-amplification/README.md) and [hash-salt](../hash-salt/README.md) reports retain the independent development reviews and failure probes.

All **{source['rust_tests']} Rust checks**, formatting and strict affected-package Clippy pass. Six C ASan/UBSan runs cover shared/static integration, callback lifecycle and all 332 injected allocation failures per linkage. Rust is uninstrumented in those C runs; leak detection is disabled, with explicit selected-allocation live counts checked.

The unchanged 4,740-configuration upstream API suite completes with **3,871 passes and 869 failures**, no crashes or timeouts, and verified library origin. This is 118 fewer failures than the initial 3,753/987 checkpoint. Compared with the isolated amplification runtime, the integrated build fixes 96 configurations and regresses none: 12 hash-salt configurations and 84 allocation-retry configurations. The latter pass with the original ceilings as allocation counts fall. The initial checkpoint comparison retains 40 allocation-schedule/ceiling regressions previously introduced by input-context support; those are recorded individually. No upstream assertion or retry limit was changed for this run. There are {len(changes)} changed adapted test files compared with the initial matrix.

Of the remaining failures, 596 belong to allocation-count/failure-injection tests and 273 to other API tests. These counts do not establish that every remaining difference is acceptable; diagnostics, encodings, limits, callback behavior and identity remain under review.

The integrated amplification grids run 5,544 and 14,480 comparisons with zero acceptance differences. Their 12 and 4 remaining observations reject at different nested parser levels, matching the reviewed isolated candidate. The previously recorded external-value lifecycle acceptance difference remains a separate open issue and is not included in these grid claims.

Caller salts retain secret randomized keys, and table replacement is transactional on allocation failure. Child lifetime/reset checks and existing-child independent hash states are documented in the C interface README. Relative controls remain independent of absolute input, work, nesting, output and allocation caps. Paired six-project screening records roughly 3–10% overhead from these controls; further performance work is required.

[evidence.tar.gz](evidence.tar.gz) contains exact source/build metadata, raw upstream and grid observations, C logs and matched performance samples. ELF binaries and static archives are excluded; their hashes remain recorded. [files.json](files.json) verifies every archive member; [summary.json](summary.json) contains compact counts. Archive SHA256: `{manifest['archive_sha256']}`.
''')
print(json.dumps({'tests':source['rust_tests'],'api_passed':api['passed'],'api_failed':api['failed'],'changed_test_files':changes,'members':len(files),'archive_bytes':(dest/'evidence.tar.gz').stat().st_size,'archive_sha256':manifest['archive_sha256']},indent=2))
