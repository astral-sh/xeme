from pathlib import Path
import hashlib,json,os,random,statistics,subprocess,time
root=Path('/tmp/oriole-security-controls-integrated')
libs={'control':Path('/tmp/oriole-attribute-throughput/final/liboriole_expat.so'),'candidate':root/'liboriole_expat.so','expat':Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4')}
manifest_path=Path('benchmarks/projects/corpus-manifest.json')
manifest=json.loads(manifest_path.read_text())
inputs={project['name']:manifest_path.parent/next(f['path'] for f in project['files'] if f['role']=='input') for project in manifest['projects']}
print(inputs,flush=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report={'started':time.time(),'affinity':[0],'iterations':5,'pairs':5,'seed':20260912,'chunk_size':4096,'libraries':{k:{'path':str(v),'sha256':sha(v)} for k,v in libs.items()},'inputs':{k:{'path':str(v),'sha256':sha(v)} for k,v in inputs.items()},'samples':[]}
os.sched_setaffinity(0,{0});rng=random.Random(report['seed'])
for ns in [False,True]:
 for name,xml in inputs.items():
  expected=None
  for pair in range(report['pairs']):
   order=list(libs);rng.shuffle(order)
   for label in order:
    command=['/tmp/oriole-grammar-bench-plain/native-driver',str(libs[label]),str(xml),'4096',str(report['iterations']),*(['namespaces'] if ns else [])]
    output=json.loads(subprocess.check_output(command,text=True,timeout=90))
    for sample in output['samples']:
     signature=tuple(sample[key] for key in ('hash','elements','text_bytes'))
     if expected is None:expected=signature
     assert signature==expected,(name,ns,label,signature,expected)
    report['samples'].append({'input':name,'namespaces':ns,'pair':pair,'label':label,'command':command,'output':output})
  medians={label:statistics.median(s['seconds'] for r in report['samples'] if r['input']==name and r['namespaces']==ns and r['label']==label for s in r['output']['samples'] if not s['warmup']) for label in libs}
  print(name,ns,{k:round(v*1000,3) for k,v in medians.items()},round(medians['control']/medians['candidate'],3),flush=True)
  (root/'screen.json').write_text(json.dumps(report,indent=2)+'\n')
report['completed']=time.time();assert all(sha(libs[k])==v['sha256'] for k,v in report['libraries'].items());report['status']='passed'
(root/'screen.json').write_text(json.dumps(report,indent=2)+'\n')
