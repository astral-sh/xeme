from pathlib import Path
import hashlib,json
root=Path('/tmp/oriole-setter-fuzz');out=root/'fuzz/seeds/value_family';out.mkdir(parents=True,exist_ok=True)
base=Path('/home/dev-user/code/oss/oriole/fuzz/seeds/value_family')
manifest={}
for stage,seed in [('converter','custom-abort'),('retained-finished','finished-child-after-parent-free'),('retained-aborted','custom-abort')]:
 original=(base/seed).read_bytes()
 for name in range(4):
  for failure in [False,True]:
   data=bytearray(original);data[29]=3|(4 if failure else 0);data[30]=name;data[31]=1
   if stage in ['converter','retained-aborted']:data[8]=5
   if stage=='retained-aborted':data[18]=6;data[15]|=1
   key=f'setter-{stage}-name{name}'+('-fail-next'if failure else '')
   (out/key).write_bytes(data);manifest[key]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'base':str(base/seed),'base_sha256':hashlib.sha256(original).hexdigest(),'control_bytes':list(data[:32])}
# Existing failNth scheduling combines parser construction, custom encoding
# registration, callback setters, retained children, and eventual destructors.
original=(out/'setter-retained-aborted-name3').read_bytes()
for fail in [1,8,64,128,512]:
 data=bytearray(original);data[0]|=1;data[1:3]=(fail-1).to_bytes(2,'little')
 key=f'setter-family-failure-{fail}';(out/key).write_bytes(data);manifest[key]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'base':'setter-retained-aborted-name3','fail_nth':fail,'control_bytes':list(data[:32])}
(root/'seed-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(len(manifest))
