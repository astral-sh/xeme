import runpy,sys,json,ctypes as c
from pathlib import Path
m=runpy.run_path('/tmp/oriole-dtd-integrated/active-oracles/missing.py');ENTITY=m['ENTITY'];setup=m['setup']
def run(lib,before):
 events=[]
 @ENTITY
 def entity(_,name,param,value,n,base,system,public,notation):events.append(name.decode())
 def parse(p,raw):return [lib.XML_Parse(p,raw,len(raw),1),lib.XML_GetErrorCode(p)]
 parent=lib.XML_ParserCreate(None);lib.XML_SetParamEntityParsing(parent,2);lib.XML_SetEntityDeclHandler(parent,entity)
 general=lib.XML_ExternalEntityParserCreate(parent,b'',None) if before else None
 first=lib.XML_ExternalEntityParserCreate(parent,None,None);a=parse(first,b'%missing;')
 if general is None:general=lib.XML_ExternalEntityParserCreate(parent,b'',None)
 child=lib.XML_ExternalEntityParserCreate(general,None,None);b=parse(child,b"<!ENTITY later 'L'>")
 for p in [child,general,first,parent]:lib.XML_ParserFree(p)
 return {'children':[a,b],'declarations':events}
paths={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','candidate':sys.argv[1]};libs={k:setup(v) for k,v in paths.items()}
rows=[{'general_created_before_skip':before,'results':{k:run(lib,before) for k,lib in libs.items()}} for before in [False,True]]
Path(sys.argv[2]).write_text(json.dumps(rows,indent=2)+'\n');print(rows)
