"""Attribute replacement/relative-accounting oracle; no external I/O in callbacks."""
import ctypes as c
import hashlib, itertools, json, random, sys
from pathlib import Path
assert not any(line.rsplit('/',1)[-1].startswith('libexpat.') for line in Path('/proc/self/maps').read_text().splitlines())
START=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.POINTER(c.c_char_p))
END=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p)
ATT=c.CFUNCTYPE(None,c.c_void_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_int)
EXT=c.CFUNCTYPE(c.c_int,c.c_void_p,c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p)

def setup(path):
 lib=c.CDLL(path)
 for name,args,result in [
  ('XML_ParserCreate',[c.c_char_p],c.c_void_p),('XML_ParserCreateNS',[c.c_char_p,c.c_char],c.c_void_p),
  ('XML_ExternalEntityParserCreate',[c.c_void_p,c.c_char_p,c.c_char_p],c.c_void_p),
  ('XML_Parse',[c.c_void_p,c.c_char_p,c.c_int,c.c_int],c.c_int),('XML_GetErrorCode',[c.c_void_p],c.c_int),
  ('XML_GetCurrentByteIndex',[c.c_void_p],c.c_long),('XML_GetCurrentLineNumber',[c.c_void_p],c.c_ulong),('XML_GetCurrentColumnNumber',[c.c_void_p],c.c_ulong),
  ('XML_SetParamEntityParsing',[c.c_void_p,c.c_int],c.c_int),('XML_ParserFree',[c.c_void_p],None),
  ('XML_SetElementHandler',[c.c_void_p,START,END],None),('XML_SetAttlistDeclHandler',[c.c_void_p,ATT],None),('XML_SetExternalEntityRefHandler',[c.c_void_p,EXT],None),
  ('XML_SetBillionLaughsAttackProtectionMaximumAmplification',[c.c_void_p,c.c_float],c.c_ubyte),
  ('XML_SetBillionLaughsAttackProtectionActivationThreshold',[c.c_void_p,c.c_ulonglong],c.c_ubyte),
 ]:
  f=getattr(lib,name);f.argtypes=args;f.restype=result
 return lib

def run(lib,xml,external,chunk,encoding,namespace,factor,threshold):
 parser=lib.XML_ParserCreateNS(None,b'|') if namespace else lib.XML_ParserCreate(None)
 assert parser
 assert lib.XML_SetBillionLaughsAttackProtectionMaximumAmplification(parser,factor)
 assert lib.XML_SetBillionLaughsAttackProtectionActivationThreshold(parser,threshold)
 lib.XML_SetParamEntityParsing(parser,2)
 events=[];children=[]
 @START
 def start(_,name,attrs):
  attributes=[];i=0
  while attrs[i]:attributes.append([attrs[i].decode(),attrs[i+1].decode()]);i+=2
  events.append(['start',name.decode(),attributes])
 @END
 def end(_,name):events.append(['end',name.decode()])
 @ATT
 def att(_,element,name,kind,value,required):events.append(['attlist',element.decode(),name.decode(),kind.decode(),None if value is None else value.decode(),required])
 def parse(p,text):
  raw=text.encode(encoding);width=chunk or len(raw);status=1
  for offset in range(0,len(raw),width):
   piece=raw[offset:offset+width];status=lib.XML_Parse(p,piece,len(piece),int(offset+width>=len(raw)))
   if status!=1:break
  return [status,lib.XML_GetErrorCode(p)]
 @EXT
 def child(parent,context,base,system,public):
  key=system.decode();sub=lib.XML_ExternalEntityParserCreate(parent,context,None);assert sub
  result=parse(sub,external[key]);children.append([key,*result]);lib.XML_ParserFree(sub);return int(result[0]==1)
 lib.XML_SetElementHandler(parser,start,end);lib.XML_SetAttlistDeclHandler(parser,att);lib.XML_SetExternalEntityRefHandler(parser,child)
 result=parse(parser,xml);position=[lib.XML_GetCurrentByteIndex(parser),lib.XML_GetCurrentLineNumber(parser),lib.XML_GetCurrentColumnNumber(parser)]
 lib.XML_ParserFree(parser)
 return {'result':result,'position':position,'events':events,'children':children}

def cases():
 for name,decl,value in [
  ('literal','',' A\r\nB\tC '),('numeric','','&#13;&#10;&#9;&#32;'),('predefined','','&amp;&lt;&gt;&quot;&apos;'),
  ('branch',"<!ENTITY leaf ' A&#13;&#10;B '><!ENTITY left '&leaf;&#13;'><!ENTITY right '&#10;&leaf;'>",'&left;&right;&left;'),
  ('empty',"<!ENTITY empty ''><!ENTITY pair '&empty;&empty;'>",'x&pair;y&empty;'),
  ('unicode',"<!ENTITY À 'é&#xA0;λ'>",'&À;&#x10000;'),
  ('undefined','','&missing;'),('cycle',"<!ENTITY a '&b;'><!ENTITY b '&a;'>",'&a;'),
  ('external',"<!ENTITY e SYSTEM 'never'>",'&e;'),('ndata',"<!NOTATION n SYSTEM 'n'><!ENTITY e SYSTEM 'never' NDATA n>",'&e;'),
  ('bad-name','','&bad@name;'),('incomplete','','&amp'),('numeric-invalid','','&#0;'),
  ('encoded-lt',"<!ENTITY e '&#60;'>",'&e;'),('amp-token',"<!ENTITY e '&#38;'>",'&e;'),
  ('relative-wide',"<!ENTITY leaf '"+'x'*80+"'><!ENTITY e '&leaf;&leaf;&leaf;'>",'&e;&e;&leaf;'),
 ]:
  for where in ['specified','default-cdata','default-tokenized']:
   default='' if where=='specified' else f"<!ATTLIST r a {'CDATA' if where=='default-cdata' else 'NMTOKENS'} '{value}'>"
   body=f"<r a='{value}'/>" if where=='specified' else '<r/>'
   yield f'{name}/{where}',f'<!DOCTYPE r [{decl}{default}]>{body}',{}
 for standalone in ['',"<?xml version='1.0' standalone='yes'?>","<?xml version='1.0' standalone='no'?>"]:
  for value in ['&e;','&unknown;','&amp;&e;']:
   yield f'external/{standalone}/{value}',standalone+f"<!DOCTYPE r SYSTEM 'd'><r a='{value}'/>",{'d':"<!ENTITY e 'from-external'>"}
 for name,decl,body in [
  ('internal-attribute-numeric', "<!ENTITY e \"<r a='A&#13;&#10;B'/>\">", '<outer>&e;</outer>'),
  ('internal-attribute-physical', "<!ENTITY e \"<r a='A\r\nB'/>\">", '<outer>&e;</outer>'),
  ('internal-attribute-reference', "<!ENTITY leaf 'A&#13;&#10;B'><!ENTITY e \"<r a='&leaf;'/>\">", '<outer>&e;</outer>'),
  ('internal-attribute-retokenized-numeric', "<!ENTITY e \"<r a='A&#38;#13;&#38;#10;B'/>\">", '<outer>&e;</outer>'),
  ('parameter-default-numeric', "<!ENTITY % p \"<!ATTLIST r a CDATA 'A&#13;&#10;B'>\">%p;", '<r/>'),
  ('parameter-default-physical', "<!ENTITY % p \"<!ATTLIST r a CDATA 'A\r\nB'>\">%p;", '<r/>'),
 ]:
  yield name,f'<!DOCTYPE r [{decl}]>{body}',{}
 for standalone in ['',"<?xml version='1.0' standalone='yes'?>"]:
  yield f'ndata-external/{standalone}',standalone+"<!DOCTYPE r SYSTEM 'd'><r a='&e;'/>",{'d':"<!NOTATION n SYSTEM 'n'><!ENTITY e SYSTEM 'unused' NDATA n>"}
 rng=random.Random(86060)
 for number in range(12):
  decl="<!ENTITY e0 'A&#13;&#10;B&#9;C'>"
  for index in range(1,8):
   refs=''.join(f'&e{rng.randrange(index)};' for _ in range(rng.randrange(1,4)))
   decl+=f"<!ENTITY e{index} 'x{refs}y'>"
  yield f'generated-dag-{number}',f"<!DOCTYPE r [{decl}]><r a='&e7;|&e7;'/>",{}

if __name__=='__main__':
 paths={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','baseline':'/tmp/oriole-active-integrated/liboriole_expat.so','candidate':sys.argv[1]}
 libs={k:setup(v) for k,v in paths.items()};differences=[];counts={'conditions':0,'baseline_changes':0,'reference_acceptance':0,'reference_errors':0,'reference_events':0,'reference_positions':0}
 inputs={}
 for (name,xml,external),chunk,encoding,namespace,(factor,threshold) in itertools.product(cases(),[0,1,7],['utf-8','utf-16'],[False,True],[(100,8*1024*1024),(1,0),(1.1,0),(1.5,0),(2,0),(4,0),(1.1,1024)]):
  inputs[name]={'xml':xml,'external':external}
  result={key:run(lib,xml,external,chunk,encoding,namespace,factor,threshold) for key,lib in libs.items()}
  a,b,d=result.values();counts['conditions']+=1
  changed=b!=d;accept=a['result'][0]!=d['result'][0];errors=a['result']!=d['result'] or a['children']!=d['children'];events=a['events']!=d['events'];position=a['position']!=d['position']
  counts['baseline_changes']+=changed;counts['reference_acceptance']+=accept;counts['reference_errors']+=errors;counts['reference_events']+=events;counts['reference_positions']+=position
  if changed or accept or errors or events:
   differences.append({'case':name,'chunk':chunk,'encoding':encoding,'namespace':namespace,'factor':factor,'threshold':threshold,'results':result})
 report={'counts':counts,'libraries':{k:{'path':v,'sha256':hashlib.sha256(Path(v).read_bytes()).hexdigest()} for k,v in paths.items()},'inputs':inputs,'differences':differences,'note':'Every baseline difference includes positions; reference-only position differences are counted but omitted from the rows.'}
 Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n');print(counts)
