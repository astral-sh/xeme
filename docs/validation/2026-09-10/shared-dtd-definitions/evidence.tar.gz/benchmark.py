import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import statistics
import subprocess
import sys

ROOT=Path('/tmp/oriole-shared-dtd-implementation')
REPO=Path('/home/dev-user/code/oss/oriole')
sys.path.insert(0,str(REPO/'tools'))
sys.path.insert(0,str(REPO/'benchmarks'))
from xml_abi import Expat
from projects import native_output

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
 out=ROOT/'benchmark';out.mkdir(exist_ok=False);(out/'inputs').mkdir()
 tiny={'empty':b'<r/>','attributes':b'<r a="one" b="two" c="three"/>','text':b'<r>some text<n/>more text</r>'}
 inputs={}
 for name,data in tiny.items():p=out/'inputs'/f'{name}.xml';p.write_bytes(data);inputs[name]=p
 corpus=REPO/'benchmarks/projects/corpus-manifest.json';manifest=json.loads(corpus.read_text())
 for project in manifest['projects']:
  if project['name'] not in ['batik','docbook','gtk']:continue
  f=next(f for f in project['files'] if f['role']=='input');p=corpus.parent/f['path'];assert digest(p)==f['sha256'];inputs[project['name']]=p
 libraries={'baseline':ROOT/'baseline.so','candidate':ROOT/'liboriole_expat.so','reference':Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so')}
 driver=out/'driver';source=REPO/'benchmarks/native_driver.c';command=['cc','-O3','-std=c11','-Wall','-Wextra','-Werror',str(source),'-ldl','-o',str(driver)];build=subprocess.run(command,capture_output=True,text=True);(out/'build.log').write_text(build.stdout+build.stderr);assert build.returncode==0
 files=[source,driver,Path(__file__),corpus,REPO/'tools/xml_abi.py',REPO/'benchmarks/projects.py',*inputs.values(),*libraries.values()];hashes={str(p):digest(p) for p in files}
 report={'status':'incomplete','method':'Seven randomized paired native processes; per-process median after one warmup. Creation, callback registration, parse, native callback hashing, and free are timed; file/library load, process startup and output serialization are excluded. Full callback preflight and independently computed hash/counts must match every measured sample.','limitations':'Parser microbenchmark, not end-to-end project execution. Shared-host CPU frequency/cache/memory bandwidth uncontrolled. Native per-iteration timer overhead remains. Batik external DTD is skipped by all engines; no external loader is installed.','cpu_affinity':sorted(os.sched_getaffinity(0)),'platform':platform.platform(),'compiler':subprocess.check_output(['cc','--version'],text=True),'build_command':command,'hashes':hashes,'input_bytes':{name:p.stat().st_size for name,p in inputs.items()},'preflights':[],'measurements':[],'ratios':[]}
 try:
  expected={};engines={k:Expat(str(p)) for k,p in libraries.items()}
  for name,p in inputs.items():
   for ns in [False,True]:
    observed={k:e.parse(p.read_bytes(),65536,ns) for k,e in engines.items()}
    assert all(o['status']==1 and o['error']==0 and not o['callback_errors'] for o in observed.values())
    assert observed['baseline']['normalized_events']==observed['candidate']['normalized_events']==observed['reference']['normalized_events']
    with gzip.open(out/f'preflight-{name}-{ns}.json.gz','wt') as f:json.dump(observed,f,separators=(',',':'))
    gold=tuple(native_output(observed['reference']['normalized_events']));expected[(name,ns)]=gold;report['preflights'].append({'input':name,'namespaces':ns,'expected':gold})
  rng=random.Random(20260910);jobs=[(name,ns,pair) for name in inputs for ns in [False,True] for pair in range(7)];rng.shuffle(jobs)
  for name,ns,pair in jobs:
   order=['baseline','candidate'];rng.shuffle(order);medians={}
   for engine in order:
    count=2000 if name in tiny else 30
    command=[str(driver),str(libraries[engine]),str(inputs[name]),'65536',str(count)]+(['namespaces'] if ns else [])
    proc=subprocess.run(command,capture_output=True,text=True,timeout=20)
    filename=f'{name}-{ns}-{pair}-{engine}.json.gz'
    with gzip.open(out/filename,'wt') as f:f.write(proc.stdout)
    (out/f'{filename}.stderr').write_text(proc.stderr)
    assert proc.returncode==0,(command,proc.returncode,proc.stderr)
    samples=json.loads(proc.stdout)['samples'];assert len(samples)==count+1
    assert all((s['hash'],s['elements'],s['text_bytes'])==expected[(name,ns)] for s in samples)
    medians[engine]=statistics.median(s['seconds'] for s in samples if not s['warmup'])
    report['measurements'].append({'input':name,'namespaces':ns,'pair':pair,'engine':engine,'command':command,'returncode':proc.returncode,'samples':filename,'median_seconds':medians[engine]})
   report['ratios'].append({'input':name,'namespaces':ns,'pair':pair,'candidate_over_baseline':medians['candidate']/medians['baseline']})
  assert all(digest(p)==v for p,v in hashes.items())
  report['summary']=[{'input':name,'namespaces':ns,'median_candidate_over_baseline':statistics.median(r['candidate_over_baseline'] for r in report['ratios'] if r['input']==name and r['namespaces']==ns),'baseline_seconds':statistics.median(r['median_seconds'] for r in report['measurements'] if r['input']==name and r['namespaces']==ns and r['engine']=='baseline'),'candidate_seconds':statistics.median(r['median_seconds'] for r in report['measurements'] if r['input']==name and r['namespaces']==ns and r['engine']=='candidate')} for name in inputs for ns in [False,True]]
  report['status']='passed'
 finally:(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report.get('summary'),indent=2))
if __name__=='__main__':main()
