# Shared parameter-child DTD tables: proposed bounded implementation

Status: design and probes only. No parser runtime changes. Baseline is `7c0d8b35c079c00da3012628ca56d7b35d2c5cd4`, release `cf5562476c0f8e17c3388e17384274da1095c245363f20edf2ab5d6a59d7b7f7`. The constructor-only followup is separate.

## Why change the ownership

The legal-callback matrix has 432 observations. In every one of the 108 accepted nonfinal-child cases and 108 accepted malformed-child cases, the engines differ. For example, parsing `<!ENTITY e 'E'>` nonfinally in a parameter child, freeing it, and returning success from the external callback leaves Expat's declaration available. Oriole delivers the declaration callback but later skips `&e;`. The same gap loses default attributes, tokenized-attribute normalization, parameter definitions, external-general requests, and first-definition precedence. Both parent parsers often report success.

All child calls in that matrix occur synchronously inside the external callback; the old parser is untouched until the child is freed. Labeled cases deliberately accept nonfinal or errored child processing. A nested external DTD callback accepts its child's status in the generator, so `malformed-rejected` applies to `p`, while an enclosing `d` may still be accepted. The 3 complete-final differences are an existing standalone imported-parameter error-prefix gap: both engines return error 24, but Oriole emits later callbacks first. Do not discard those differences in the next oracle.

Four additional isolated sibling probes show Oriole's copied tables produce a second declaration callback in three cases, and a different final entity value in two. These sequences violate Expat's rule forbidding access to the old parser while a parameter child lives. They inform the intended safe-core semantics; they are not C conformance assertions.

The selected-suite count grows from 10 to 273 child mallocs when inherited definitions grow from 0 to 128 (before the constructor followup), versus Expat's constant 3. After the constructor followup those Oriole counts are 5 and 268. Sharing removes the table-copy component, not merely three more constructor calls.

## Container and lazy creation

Use a private `DtdTables` containing the three existing maps: general entities, parameter entities, and default attributes. It also owns the authoritative DTD hash seed and family metadata caps. Keep namespace bindings, source/lexical buffers, continuation state, callbacks, positions, and parser-local active-name indexes outside it. Keep the already reviewed read/skip flags and value-output/open-state channels unchanged in this layer.

Each parser has a `OnceLock<Shared<TryLock<DtdTables>>>` and an empty inline `DtdTables` working slot. The inline slot replaces the three current map fields; helpers change mechanically from `self.entities` to `self.tables.entities` etc. Ordinary documents without a DTD retain no shared allocation and take no owner-clone or lock path.

Create shared storage before the first internal-DTD step, or before returning any parameter child. Root DOCTYPE parsing always queues its start event before parsing internal declarations, so initialization can occur at the next core event entry when `in_doctype` is set. An external parameter child already has its shared owner at construction. A general child of a parser without declarations keeps no owner. These are explicit invariants, with tests for one-byte DOCTYPE input, callback-triggered child creation at StartDoctype, empty/absent DTDs, and foreign-DTD entry.

Allocate a fully formed empty owner before calling `OnceLock::set`, as the existing shared-flag implementation does. No selected allocation occurs inside a OnceLock initialization closure. Initialization failure leaves the lock unset; competing immutable initializers may allocate independently, and the losing allocation is returned to its original suite.

## Safe scope without self-referential storage

For a core operation that needs existing tables:

1. Clone the `Shared` owner into a local variable before borrowing the parser mutably.
2. Acquire its `TryLock` once.
3. Construct a private `DtdScope` containing `&mut Parser` and a guard borrowing that separate local owner.
4. Move the table container into the parser's empty working slot using `mem::swap`.
5. Run the existing inner operation through `scope.parser`.
6. `Drop` swaps the container back. The lock guard then releases; the local owner clone drops last.

`Drop` consists only of `mem::swap`; it performs no allocation, element destruction, assertions, formatting, or callbacks. The parser retains a strong owner throughout the scope, so dropping the temporary owner clone cannot free the shared container. Keep owner replacement/reset outside scoped inner methods. Both `Err` and panic return the tables to the shared family. The small actual-storage prototype compiles with `#![forbid(unsafe_code)]` and passes success/error, unwind, contention, and independent-family checks. It is not a parser implementation or allocator-routing proof.

The guard does not borrow the owner from itself or from the mutably borrowed parser. No new unsafe code, raw table pointers, lifetime erasure, blocking mutex, or `RefCell` is needed. This keeps borrowed iterative entity-value frames within their existing one-operation lifetime and avoids cloning entire records on every lookup.

No guard or reference into a table crosses return from a public core operation. C callbacks receive owned events only, after the scope has dropped. Selected allocator callbacks during ordinary parsing remain subject to the existing FFI allocation-reentry guard. Do not add callback calls to scope teardown.

## Public method inventory and lock rules

`inventory.json` records the direct table accesses against the frozen source. Entry-point rules are:

| Entry point | Table rule |
| --- | --- |
| `next_event` | One mutable scope around the existing inner event/error-publication operation when an owner exists; ensure first DTD owner before entering DTD processing. |
| `next_event_for_recycling` | Calls `next_event`; never adds another scope. FFI resume reuses this path. |
| `set_hash_salt` | One mutable scope; use a renamed inner helper to avoid reacquisition. |
| `external_child` | Delegates to `external_child_with_encoding`; no additional scope. |
| `external_child_with_encoding` | Short immutable-access guard for charging/copying a general snapshot. Parameter construction shares the owner and does not iterate the definitions. Pass the already borrowed tables to copy helpers. No call into public scoped methods on the same family while the guard lives. Configure the new child's local maps before assigning its shared owner. |
| `merge_external_subset` | Check existing completion/type contract first. Same-owner merge performs no table copy. Different-family legacy merge takes one guard per distinct owner, acquired nonblocking, and passes table references into its existing inner logic. Never acquire the same owner twice. |
| `set_limits` | If shared tables exist, take one short guard to validate existing metadata and apply an authorized family-cap change transactionally; see caps below. |
| constructors/reset | Constructors create empty inline maps only. FFI reset builds the replacement parser, validates allocations, then replaces the old parser outside any scope. Old children retain their old owner. |
| feed, encoding/map/conversion methods | No definition-table access. They mutate decoder/source/read state only; no DTD scope. |
| positions, input context, completion, raw event getter | No definition-table access; no scope. |
| handler/parameter/reparse/namespace-triplet/foreign-DTD setters; absent-handler hook; recycling | No definition-table access; no scope. |
| amplification controls | Existing shared byte-budget operations; no table scope. |

Internal parse/reference/default/value/grammar helpers operate only on the active working slot. They must not call a public scoped entry point. Child inheritance of value/parameter continuation uses its existing owned strings and channels; it does not itself inspect a table. The helper returning inherited-copy charges must accept the caller's table view, not acquire another guard.

A busy shared owner returns `ErrorKind::ExternalEntityHandling` with a fixed diagnostic before any mutation or table swap. No spin, wait, poison, allocation, or shared-table modification occurs on this path. A direct safe-core caller may retry after serialization; the C adapter may treat this as its usual terminal external-handling failure. This is a defensive result for concurrently operated parameter siblings, which Expat's C contract excludes. Distinct families retain independent locks and can run concurrently. Test actual threads with a deterministic barrier and a held guard; do not rely on scheduler timing.

## Hash identity

A shared DTD has one authoritative seed, used by its three map hashers and every default-attribute index. Rehash all of those transactionally: reserve every replacement before changing any live table/seed. Change the stored seed only after successful preparation and swaps. Newly added default indexes use the DTD seed, not a parser's namespace-map seed.

Parser-local namespace and active-name indexes retain their own hasher snapshots. They do not share buckets, cached hashes, or keys requiring rehash with the DTD. This distinction must be explicit in the internal `hash_salt` documentation and tests. A root rehash updates that root's local tables plus the one DTD family. Retained parameter children's local namespace/index hashers may remain at their previous seed, while their DTD lookups use the shared owner's current seed. That is coherent ownership, not a cached-hash transfer.

The FFI setter already follows lifetime tokens to the live root and checks its state; preserve that policy. The hidden safe-core setter acts on the receiving parser's local indexes and shared DTD. Its no-op condition must check both local and shared seeds. General-child snapshot tables get a new independent owner and preserve the source DTD seed; their local namespace salt still inherits their creating parser's local salt. Test parent rehash, retained parameter siblings, independent general snapshots, failed rehash at every allocation, and repeated old/new seed changes. Audit the new active-name-index layer before merging; do not reseed any existing hash table without rebuilding it.

## Limits and allocation accounting

Use the selected allocator for the shared owner, all maps/strings, snapshots, and any temporary index storage. Charge the owner's metadata once before allocating it. Parameter-child creation no longer charges or performs O(definitions) copies. It still charges and owns its parser/source, namespace/context, encoding, continuation, and active-name state. General snapshots continue to charge every copied definition/name/value/index before allocation. Actual expansion/use work and shared amplification counters remain unchanged.

Removing final copy/merge must not remove the parent's existing declaration limits. Store family `max_entities` and `max_attributes` caps in the shared owner; insertions, reservations, and attribute growth enforce the minimum of family and parser-local caps. Track the maximum per-element default count in the owner so validating a smaller cap is constant-time, without rescanning every definition on every event.

An independent family root (document root or general-content snapshot root) may change family caps before receiving input, through `set_limits`. Validate committed counts before replacing either caps or local configuration. A parameter child can set its own limits, but cannot raise the family caps; validate lower local caps against already visible definitions. This closes the bypass that a same-owner no-op merge would otherwise create. Existing byte-work/ratio accounting remains shared as before. Do not introduce fictitious copy charges or allocations to reproduce an upstream retry schedule.

Entity reservations retain first-definition precedence and the existing owner state in the declaration continuation. Removing a reservation must remove only the slot that continuation created. General-child `clone_for_child(false, ...)` must retain its current transformations for unfinished no-ID slots and independent `value_open` flags. Failed child parsing keeps already committed declarations visible; errors remain parser-local. No rollback of prior committed DTD declarations is implied.

## Lifetimes and provenance

Parameter children hold strong references to their DTD owner, not their parent's parser. Parent destruction and reset leave old children's storage valid; a reset parent owns a fresh family. General children keep snapshots, including detached flag/open-state semantics; later declarations in either family do not cross that boundary. The legacy explicit merge API retains its input-completion validation; same-family completion is a no-op because definitions are already visible.

Move existing entity/default objects unchanged. Do not decode, normalize, concatenate, or flatten strings while publishing or snapshotting tables. Preserve `declared_in_parameter_entity`, external IDs, notation, open flags, and the current `clone_for_child` rules. Source/lexical conversion metadata, raw DOCTYPE/declaration slices, request positions, value-channel frames, and callback-owned strings stay in their existing containers. Partial failed-input callback differences stay separately recorded.

## Gates before handoff

- Legal 432-row oracle: close publication/data differences without erasing the complete-final standalone error-prefix differences or changing rejection/error propagation.
- Core simultaneous-sibling definition/default/duplicate visibility, independent general snapshots, parent drop/reset, and reservation/value/open-state regressions.
- Scope success/Err/panic restoration, no allocation/free during publication, same-owner busy rejection, different-family threaded independence, no guard across external callbacks.
- Every selected allocation fails safely; ownership/release/global-routing counters remain exact. Rehash failure and family-cap mutation are transactional.
- Original upstream API assertions/ceilings unchanged; preserve changed outcomes and all failures.
- Existing custom-provenance/header/value/grammar/handler-change matrices and allocator/family sanitizer targets; specifically children created during owned callback delivery.
- Measure parameter-child selected calls versus inherited definitions after sharing; require a flat definition-copy component, not a guessed final count.
- Check ordinary no-DTD constructor calls remain six after the separate constructor patch, then remeasure tiny/project and DTD-heavy throughput.
