import ctypes as c
import hashlib,itertools,json,runpy
from pathlib import Path
m=runpy.run_path('/tmp/oriole-missing-parameter/oracle.py');setup=m['setup'];EXT=m['EXT'];ENTITY=m['ENTITY'];TEXT=m['TEXT'];SKIP=m['SKIP'];START=m['START'];END=m['END'];ATT=m['ATT']
LIBRARIES={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','baseline':'/tmp/oriole-shared-integrated/liboriole_expat.so'}
FIXTURES=[('general',"<!ENTITY e 'E'>",'', '<r>&e;</r>'),('attribute',"<!ATTLIST r a CDATA 'A'>",'', '<r/>'),('parameter',"<!ENTITY % q \"<!ENTITY e 'Q'>\">",'%q;', '<r>&e;</r>'),('first-definition',"<!ENTITY e 'E'>","<!ENTITY e 'P'>",'<r>&e;</r>'),('attribute-type',"<!ATTLIST r a NMTOKENS #IMPLIED>",'',"<r a=' a  b '/>"),('external-general',"<!ENTITY e SYSTEM 'g'>",'', '<r>&e;</r>')]
def run(lib,fixture,standalone,doctype,action,width):
 name,contents,suffix,body=fixture;events=[];children=[];root=lib.XML_ParserCreate(None);assert root
 lib.XML_SetReparseDeferralEnabled.argtypes=[c.c_void_p,c.c_int];lib.XML_SetReparseDeferralEnabled.restype=c.c_int;lib.XML_SetReparseDeferralEnabled(root,0)
 def parse(p,raw,final):
  raw=raw.encode();step=width or max(1,len(raw));status=1
  for i in range(0,len(raw),step):
   part=raw[i:i+step];status=lib.XML_Parse(p,part,len(part),int(final and i+step>=len(raw)))
   if status!=1:break
  if not raw:status=lib.XML_Parse(p,b'',0,final)
  return [status,lib.XML_GetErrorCode(p)]
 @START
 def start(_,name,attrs):
  pairs=[];i=0
  while attrs[i]:pairs.append([attrs[i].decode(),attrs[i+1].decode()]);i+=2
  events.append(['start',name.decode(),pairs])
 @END
 def end(_,name):events.append(['end',name.decode()])
 @TEXT
 def text(_,ptr,n):
  value=c.string_at(ptr,n).decode()
  if events and events[-1][0]=='text':events[-1][1]+=value
  else:events.append(['text',value])
 @ENTITY
 def entity(_,name,param,value,n,base,system,public,notation):events.append(['entity',name.decode(),param,c.string_at(value,n).decode() if value is not None else None,system.decode() if system else None])
 @ATT
 def att(_,element,name,kind,value,required):events.append(['attlist',element.decode(),name.decode(),kind.decode(),value.decode() if value else None,required])
 @SKIP
 def skip(_,name,param):events.append(['skipped',name.decode(),param])
 payload="<!ENTITY % p SYSTEM 'p'>%p;"+suffix
 @EXT
 def external(parent,context,base,system,public):
  key=system.decode();events.append(['external',key]);child=lib.XML_ExternalEntityParserCreate(parent,context,None);assert child
  content=contents if key=='p' else payload if key=='d' else 'G'
  final=action!='nonfinal' if key=='p' else True
  if key=='p' and action in ['malformed-accepted','malformed-rejected']:content+='<!'
  result=parse(child,content,int(final));children.append([key,*result]);lib.XML_ParserFree(child)
  return int(result[0]==1) if action=='malformed-rejected' and key=='p' else 1
 lib.XML_SetParamEntityParsing(root,2);lib.XML_SetExternalEntityRefHandler(root,external);lib.XML_SetElementHandler(root,start,end);lib.XML_SetCharacterDataHandler(root,text);lib.XML_SetSkippedEntityHandler(root,skip);lib.XML_SetEntityDeclHandler(root,entity);lib.XML_SetAttlistDeclHandler(root,att)
 decl='' if standalone=='absent' else f"<?xml version='1.0' standalone='{standalone}'?>"
 doc=decl+("<!DOCTYPE r SYSTEM 'd'>" if doctype=='external' else '<!DOCTYPE r ['+payload+']>')+body
 result=parse(root,doc,1);lib.XML_ParserFree(root)
 return {'result':result,'children':children,'events':events}
engines={k:setup(v) for k,v in LIBRARIES.items()};rows=[]
for fixture,standalone,doctype,action,width in itertools.product(FIXTURES,['absent','no','yes'],['external','internal'],['complete','nonfinal','malformed-accepted','malformed-rejected'],[0,1,7]):
 r={k:run(lib,fixture,standalone,doctype,action,width) for k,lib in engines.items()};rows.append({'fixture':fixture[0],'standalone':standalone,'doctype':doctype,'action':action,'width':width,**r})
out=Path('/tmp/oriole-shared-dtd-design');report={'scope':'Each parameter child is created, fed, and freed synchronously inside its external callback, with no access to the old parser while the child exists. Nonfinal or failed child parses are accepted explicitly by the callback in labeled cases. No fabricated contexts or precreated siblings.','libraries':{k:{'path':v,'sha256':hashlib.sha256(Path(v).read_bytes()).hexdigest()} for k,v in LIBRARIES.items()},'cases':len(rows),'differences':sum(r['reference']!=r['baseline'] for r in rows),'observations':rows};(out/'observations.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k!='observations'})
