#![forbid(unsafe_code)]

use oriole_storage::{Allocator, Shared, TryLock, TryLockGuard, Vec};

#[derive(Debug, PartialEq)]
enum Error {
    Busy,
    Parse,
}

struct Tables {
    definitions: Vec<u8>,
}
impl Tables {
    fn empty() -> Self {
        Self { definitions: Vec::new_in(Allocator::System) }
    }
}

struct Parser {
    local: Tables,
    shared: Option<Shared<TryLock<Tables>>>,
    position: usize,
}

// The owned Shared clone lives in the caller's stack frame. This guard borrows
// that owner and a separate Parser; it never borrows from its own fields.
struct Scope<'parser, 'owner> {
    parser: &'parser mut Parser,
    tables: TryLockGuard<'owner, Tables>,
}
impl<'parser, 'owner> Scope<'parser, 'owner> {
    fn new(parser: &'parser mut Parser, mut tables: TryLockGuard<'owner, Tables>) -> Self {
        debug_assert!(parser.local.definitions.is_empty());
        std::mem::swap(&mut parser.local, &mut tables);
        Self { parser, tables }
    }
}
impl Drop for Scope<'_, '_> {
    fn drop(&mut self) {
        // Move container headers only. No allocation, element drop, assertion,
        // function pointer, or callback. The lock guard releases afterward.
        std::mem::swap(&mut self.parser.local, &mut self.tables);
    }
}
impl Parser {
    fn shared_parser() -> Self {
        Self {
            local: Tables::empty(),
            shared: Some(Shared::try_new_in(TryLock::new(Tables::empty()), Allocator::System).unwrap()),
            position: 0,
        }
    }
    fn sibling(&self) -> Self {
        Self { local: Tables::empty(), shared: self.shared.clone(), position: 0 }
    }
    fn scoped<R>(&mut self, operation: impl FnOnce(&mut Self) -> Result<R, Error>) -> Result<R, Error> {
        let Some(owner) = self.shared.clone() else { return operation(self) };
        let tables = owner.try_lock().ok_or(Error::Busy)?;
        let scope = Scope::new(self, tables);
        operation(scope.parser)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::panic::{AssertUnwindSafe, catch_unwind};
    #[test]
    fn result_and_error_publish_without_leaving_local_definitions() {
        let mut parser = Parser::shared_parser();
        parser.scoped(|p| { p.local.definitions.push(1); p.position += 1; Ok(()) }).unwrap();
        assert_eq!(parser.scoped::<()>(|p| { p.local.definitions.push(2); Err(Error::Parse) }), Err(Error::Parse));
        assert!(parser.local.definitions.is_empty());
        assert_eq!(parser.position, 1);
        assert_eq!(&*parser.shared.as_ref().unwrap().try_lock().unwrap().definitions, &[1, 2]);
    }
    #[test]
    fn panic_restores_tables_and_releases_the_lock() {
        let mut parser = Parser::shared_parser();
        let result = catch_unwind(AssertUnwindSafe(|| parser.scoped::<()>(|p| {
            p.local.definitions.push(3);
            panic!("simulated internal unwind");
        })));
        assert!(result.is_err());
        assert!(parser.local.definitions.is_empty());
        assert_eq!(&*parser.shared.as_ref().unwrap().try_lock().unwrap().definitions, &[3]);
    }
    #[test]
    fn contention_is_immediate_and_different_families_are_independent() {
        let mut parser = Parser::shared_parser();
        let mut sibling = parser.sibling();
        let mut independent = Parser::shared_parser();
        parser.scoped(|p| {
            p.local.definitions.push(4);
            assert_eq!(sibling.scoped(|p| { p.position += 1; Ok(()) }), Err(Error::Busy));
            independent.scoped(|p| { p.local.definitions.push(5); Ok(()) })?;
            Ok(())
        }).unwrap();
        assert_eq!(sibling.position, 0);
        sibling.scoped(|p| { assert_eq!(&*p.local.definitions, &[4]); Ok(()) }).unwrap();
        independent.scoped(|p| { assert_eq!(&*p.local.definitions, &[5]); Ok(()) }).unwrap();
    }
}
