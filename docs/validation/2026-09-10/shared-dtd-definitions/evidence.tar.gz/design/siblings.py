import ctypes as c,hashlib,itertools,json,runpy,subprocess,sys
from pathlib import Path
m=runpy.run_path('/tmp/oriole-missing-parameter/oracle.py');setup=m['setup'];EXT=m['EXT'];ENTITY=m['ENTITY'];TEXT=m['TEXT']
LIBS={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','baseline':'/tmp/oriole-shared-integrated/liboriole_expat.so'}
def run(lib,precreated,first_final):
 events=[];children=[]
 @ENTITY
 def entity(_,name,param,value,n,base,system,public,notation):events.append(['entity',name.decode(),c.string_at(value,n).decode() if value else None])
 @TEXT
 def text(_,value,n):events.append(['text',c.string_at(value,n).decode()])
 def parse(p,raw,final):return [lib.XML_Parse(p,raw,len(raw),final),lib.XML_GetErrorCode(p)]
 @EXT
 def external(parent,context,base,system,public):
  first=lib.XML_ExternalEntityParserCreate(parent,None,None);assert first
  second=lib.XML_ExternalEntityParserCreate(parent,None,None) if precreated else None
  children.append(['first',*parse(first,b"<!ENTITY e 'FIRST'>",first_final)])
  if second is None:second=lib.XML_ExternalEntityParserCreate(parent,None,None)
  assert second
  children.append(['second',*parse(second,b"<!ENTITY e 'SECOND'>",1)])
  if not first_final:children.append(['first-finish',*parse(first,b'',1)])
  lib.XML_ParserFree(second);lib.XML_ParserFree(first);return 1
 p=lib.XML_ParserCreate(None);lib.XML_SetParamEntityParsing(p,2);lib.XML_SetExternalEntityRefHandler(p,external);lib.XML_SetEntityDeclHandler(p,entity);lib.XML_SetCharacterDataHandler(p,text)
 result=parse(p,b"<!DOCTYPE r SYSTEM 'd'><r>&e;</r>",1);lib.XML_ParserFree(p)
 return {'result':result,'children':children,'events':events}
if len(sys.argv)>1:
 case=json.loads(sys.argv[1]);print(json.dumps(run(setup(case['library']),case['precreated'],case['first_final'])));sys.exit(0)
rows=[]
for a,b in itertools.product([False,True],[0,1]):
 results={}
 for name,path in LIBS.items():
  case={'library':path,'precreated':a,'first_final':b};p=subprocess.run([sys.executable,__file__,json.dumps(case)],capture_output=True,text=True,timeout=5);results[name]={'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 rows.append({'precreated':a,'first_final':b,**results})
report={'scope':'Nonconforming C lifecycle robustness only: creating a second parameter parser from the old parser before freeing the first violates expat.h parameter-child synchrony rules. Results inform intended safe-core sharing behavior, not C conformance. Every row/engine is isolated.','libraries':{k:{'path':v,'sha256':hashlib.sha256(Path(v).read_bytes()).hexdigest()} for k,v in LIBS.items()},'observations':rows}
Path('/tmp/oriole-shared-dtd-design/siblings.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
