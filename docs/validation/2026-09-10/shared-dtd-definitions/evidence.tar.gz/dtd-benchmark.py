from pathlib import Path
import json,gzip,hashlib,subprocess,random,statistics
out=Path('/tmp/oriole-shared-dtd-implementation/dtd-benchmark');out.mkdir();base=out.parent;source=Path('/home/dev-user/code/oss/oriole/benchmarks/native_dtd_driver.c');driver=out/'driver';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
command=['cc','-O3','-std=c11','-Wall','-Wextra','-Werror','-I','/tmp/oriole-shared-dtd/include',str(source),'-ldl','-o',str(driver)]
r=subprocess.run(command,capture_output=True,text=True);(out/'build.log').write_text(r.stdout+r.stderr);assert r.returncode==0
libs={'reference':Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so'),'baseline':base/'baseline.so','candidate':base/'liboriole_expat.so'}
fixtures={}
for definitions in [0,16,128]:
 for requests in [0,32]:
  p=out/f'entities-{definitions}-requests-{requests}.dtd';p.write_text(''.join(f'<!ENTITY e{i} "value{i}">' for i in range(definitions))+"<!ENTITY % p SYSTEM 'empty'>"+'%p;'*requests);fixtures[p.stem]=(p,definitions+1,requests+1)
hashes={str(p):sha(p) for p in [source,Path(__file__),driver,*libs.values(),*[x[0] for x in fixtures.values()]]}
report={'status':'incomplete','hashes':hashes,'build_command':command,'scope':'Seven randomized paired native processes, 20 timed document parses each after one warmup. Parser creation, callback registration, all declarations, synchronous empty parameter children, metadata hashing and free are timed. Files/dlopen/process startup/output serialization excluded from timed samples; no trace writing in timed samples. In-memory fixed resolver, no application IO. Shared-host microbenchmark, not end-to-end project throughput.','preflights':[],'rows':[]}
try:
 expected={}
 for name,(p,decls,requests) in fixtures.items():
  values={}
  for engine,lib in libs.items():
   cmd=[str(driver),str(lib),str(p),'65536','1','--trace'];r=subprocess.run(cmd,capture_output=True,text=True,timeout=20);assert r.returncode==0,(cmd,r.stderr);data=json.loads(r.stdout)
   with gzip.open(out/f'{name}-{engine}-preflight.json.gz','wt') as f:json.dump(data,f)
   values[engine]=tuple(data['samples'][0][k] for k in ['trace','hash','declarations','external_calls']);assert values[engine][2:]==(decls,requests)
  assert len(set(values.values()))==1,values
  expected[name]=values['reference'][1:];report['preflights'].append({'fixture':name,'expected':values['reference']})
 jobs=[(name,pair) for name in fixtures for pair in range(7)];rng=random.Random(20260910);rng.shuffle(jobs)
 for name,pair in jobs:
  order=['baseline','candidate'];rng.shuffle(order)
  for engine in order:
   cmd=[str(driver),str(libs[engine]),str(fixtures[name][0]),'65536','20'];r=subprocess.run(cmd,capture_output=True,text=True,timeout=20);assert r.returncode==0,(cmd,r.stderr);data=json.loads(r.stdout);assert len(data['samples'])==21
   assert all(tuple(x[k] for k in ['hash','declarations','external_calls'])==expected[name] for x in data['samples'])
   filename=f'{name}-{pair}-{engine}.json.gz'
   with gzip.open(out/filename,'wt') as f:json.dump(data,f)
   report['rows'].append({'fixture':name,'pair':pair,'engine':engine,'command':cmd,'output':filename,'seconds':statistics.median(x['seconds'] for x in data['samples'] if not x['warmup'])})
 report['summary']=[]
 for name in fixtures:
  ratios=[]
  for pair in range(7):
   values={r['engine']:r['seconds'] for r in report['rows'] if r['fixture']==name and r['pair']==pair};ratios.append(values['candidate']/values['baseline'])
  report['summary'].append({'fixture':name,'candidate_over_baseline':statistics.median(ratios),'paired_ratios':ratios})
 assert all(sha(Path(p))==s for p,s in hashes.items());report['status']='passed'
finally:(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report.get('summary'),indent=2))
