from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path('/tmp/oriole-shared-dtd');out=Path('/tmp/oriole-shared-dtd-implementation');base=Path('/tmp/oriole-shared-dtd-table-base')
shutil.copytree('/tmp/oriole-shared-dtd-before-tables',base)
for p in base.rglob('*.orig'):p.unlink()
subprocess.run(['patch','-p1','-i','/tmp/oriole-deep-profile-experiment/inherited/inherited-only.patch'],cwd=base,check=True,stdout=(out/'table-base-overlay.log').open('w'))
# fmt-only context must be normalized before generating a narrow implementation patch.
env=__import__('os').environ.copy();env.update(CARGO_HOME='/home/dev-user/.cache/toucan/cargo',CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/build',CARGO_TARGET_DIR='/home/dev-user/.cache/oriole/shared-dtd-target')
subprocess.run(['cargo','+ohm','fmt','--all'],cwd=base,env=env,check=True)
for p in base.rglob('*.orig'):p.unlink()
paths=[p.relative_to(r) for p in r.rglob('*') if p.is_file() and p.suffix!='.orig']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'base':'ebcd46dd0cd720d1f28de5fda0b87cf4b1b05756','overlays':{'constructor':'dab4a4f46d313df6d5bbc484200a959a9d22af62c2ccf068c274eb7215a94854','active_control':'60400d4364a59173ae030e59f26e8f48f105fe4ff20a1969ff8de5aa6386a5f4','inherited_only':'8a67067f32f4106409a7746fdfafdb36303e5458972edebab45318b52e621cac'},'files':{str(p):sha(r/p) for p in sorted(paths)}}
(out/'source.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'source.tar.gz','w:gz') as t:
 for p in sorted(paths):t.add(r/p,arcname=str(p))
patch=[]
for p in sorted(paths):
 if p.parts[0]!='crates':continue
 a=(base/p).read_text() if (base/p).exists() else ''
 b=(r/p).read_text()
 if a!=b:
  import difflib
  patch.extend(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+str(p),tofile='b/'+str(p)))
(out/'shared-dtd.patch').write_text(''.join(patch))
for name in ['liboriole_expat.so','liboriole_expat.a']:
 shutil.copy2(Path('/home/dev-user/.cache/oriole/shared-dtd-target/release')/name,out/name)
(out/'binaries.json').write_text(json.dumps({n:sha(out/n) for n in ['liboriole_expat.so','liboriole_expat.a']},indent=2)+'\n')
print(json.dumps({'source_manifest':sha(out/'source.json'),'patch':sha(out/'shared-dtd.patch'),'libraries':json.loads((out/'binaries.json').read_text())},indent=2))
