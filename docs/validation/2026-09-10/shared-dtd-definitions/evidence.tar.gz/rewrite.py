from pathlib import Path
r=Path('/tmp/oriole-shared-dtd/crates/oriole/src')
p=r/'lib.rs';s=p.read_text()
start=s.index('        self.charge_external_child_storage(context, encoding)?;')
end=s.index('        child.namespaces.clear();',start)
new='''        // Parameter children publish into one family immediately. General-content
        // children copy a snapshot while the parent's tables are briefly guarded.
        let owner = if context.is_none() {
            Some(self.ensure_shared_tables()?.clone())
        } else {
            self.shared_tables.get().cloned()
        };
        let snapshot = if context.is_some() {
            owner.as_ref().map(|owner| owner.try_lock().ok_or_else(|| self.dtd_busy())).transpose()?
        } else {
            None
        };
        let tables = snapshot.as_deref().unwrap_or(&self.tables);
        self.charge_external_child_storage(context, encoding)?;
        if context.is_some() {
            self.charge_dtd_snapshot(tables)?;
        }
        // The stored config contains only inline values, so this cannot allocate.
        debug_assert!(self.config.encoding.is_none());
        let mut child =
            Self::try_new_with_encoding_in(self.config.clone(), encoding, self.allocator)?;
        child.set_hash_salt_inner(self.hash_salt())?;
        child.decoder.inherit_map(&self.decoder, &mut child.sources[0])?;
        if context.is_some() && owner.is_some() {
            // The DTD family's salt may differ from this parser's local index salt.
            child.tables = tables.empty_like();
            for (name, entity) in &tables.entities {
                try_insert(&mut child.tables.entities, name.try_clone()?,
                    entity.clone_for_child(false, false, self.allocator)?)?;
            }
            for (name, attributes) in &tables.defaults {
                try_insert(&mut child.tables.defaults, name.try_clone()?, attributes.try_clone()?)?;
            }
            for (name, entity) in &tables.parameter_entities {
                try_insert(&mut child.tables.parameter_entities, name.try_clone()?,
                    entity.clone_for_child(false, true, self.allocator)?)?;
            }
            child.tables.max_default_attributes = tables.max_default_attributes;
            // General-content children form independent families, with their own caps.
            child.tables.max_entities = child.config.limits.max_entities;
            child.tables.max_attributes = child.config.limits.max_attributes;
            child.publish_copied_tables()?;
        }
        drop(snapshot);
        if context.is_none() {
            child.shared_tables = OnceLock::from(owner.expect("parameter DTD owner"));
        }
'''
s=s[:start]+new+s[end:]
start=s.index('    fn charge_external_child_storage(')
end=s.index('        for (prefix, uri) in &self.namespaces {',start)
existing=s[start:end]
charge=existing[existing.index('        if context.is_some() {'):]
charge=charge.replace('self.tables.', 'tables.')
charge=charge.replace('''        if context.is_some() {
            for entity in tables.parameter_entities.values() {''','''        for entity in tables.parameter_entities.values() {''').replace('''            }
        }
        for (name, entity)''','''        }
        for (name, entity)''',1)
charge=charge.replace('if context.is_some() && entity.value_open.is_some()', 'if entity.value_open.is_some()')
helper='''    /// Charge only copies that a general-content child will actually perform.
    fn charge_dtd_snapshot(&self, tables: &DtdTables) -> Result<(), Error> {
'''+charge+'''        Ok(())
    }

'''
s=s[:start]+helper+'''    fn charge_external_child_storage(
        &self,
        context: Option<&str>,
        encoding: Option<&str>,
    ) -> Result<(), Error> {
'''+s[end:]
# Merge: acquire distinct child owner before our mutable scope; same owner needs no copy.
start=s.index('    fn merge_external_subset_inner(&mut self, child: &Self) -> Result<(), Error> {')
copy=s.index('        for (name, entity) in &child.tables.entities {',start)
prefix=s[start:copy]
prefix=prefix.replace('    fn merge_external_subset_inner(&mut self, child: &Self) -> Result<(), Error> {','    fn merge_external_subset_inner(&mut self, child: &Self) -> Result<(), Error> {')
new=prefix+'''        let same_family = self.shared_tables.get().zip(child.shared_tables.get())
            .is_some_and(|(left, right)| std::ptr::eq(&**left, &**right));
        if !same_family {
            self.ensure_shared_tables()?;
            let child_owner = child.shared_tables.get();
            let child_guard = child_owner.map(|owner| owner.try_lock().ok_or_else(|| self.dtd_busy())).transpose()?;
            let tables = child_guard.as_deref().unwrap_or(&child.tables);
            self.with_dtd_tables(|parser| parser.import_dtd_tables(tables))?;
        }
        self.set_declarations_skipped(self.declarations_skipped() || child.declarations_skipped());
        self.standalone |= child.standalone;
        Ok(())
    }

    fn import_dtd_tables(&mut self, tables: &DtdTables) -> Result<(), Error> {
'''
s=s[:start]+new+s[copy:]
start=s.index('    fn import_dtd_tables(');end=s.index('    /// Append input',start)
part=s[start:end].replace('child.tables.', 'tables.')
part=part.replace('        self.set_declarations_skipped(self.declarations_skipped() || child.declarations_skipped());\n        self.standalone |= child.standalone;\n','')
part=part.replace('self.config.limits.max_entities','self.entity_limit()')
part=part.replace('DefaultAttributes::new(self.allocator, self.namespaces.hasher().salt())','DefaultAttributes::new(self.allocator, self.tables.salt)')
part=part.replace('        for (name, attributes) in &tables.defaults {','        let attribute_limit = self.default_attribute_limit();\n        for (name, attributes) in &tables.defaults {')
part=part.replace('self.config.limits.max_attributes','attribute_limit')
part=part.replace('                    target.try_insert(attribute.try_clone()?)?;','                    target.try_insert(attribute.try_clone()?)?;\n                    self.tables.max_default_attributes = self.tables.max_default_attributes.max(target.ordered.len());')
s=s[:start]+part+s[end:]
# Update documentation owned model.
s=s.replace('''    /// preserves all contents and the previous salt. Owned external children
    /// retain their existing hash state; subsequently created children inherit
    /// the new salt. Adapters enforce their own configuration timing rules.''','''    /// preserves all contents and the previous salt. Parameter children share
    /// the DTD seed; namespace and active-name indexes retain parser-local seeds.
    /// General children retain independent snapshots. Adapters enforce timing rules.''')
s=s.replace('''    /// Construct an independent parser for an application-provided external entity.''','''    /// Construct a parser for an application-provided external entity.''')
s=s.replace('''    /// resolving a reference inside an entity value. DTD children import their
    /// declarations through [`Self::merge_external_subset`]; value children share''','''    /// resolving a reference inside an entity value. DTD children immediately share
    /// committed declarations, including declarations preceding an error; value children share''')
s=s.replace('    /// Import successfully parsed external DTD declarations. Existing declarations win.','''    /// Validate a completed external DTD. Same-family definitions are already visible;
    /// unrelated DTDs are imported with existing declarations taking precedence.''')
p.write_text(s)
for name in ['dtd.rs','dtd/semantic.rs','value.rs']:
 p=r/name;s=p.read_text().replace('self.config.limits.max_entities','self.entity_limit()')
 if name=='dtd.rs':
  s=s.replace('DefaultAttributes::new(self.allocator, self.namespaces.hasher().salt())','DefaultAttributes::new(self.allocator, self.tables.salt)')
  s=s.replace('        let declarations = self.tables\n            .defaults','        let attribute_limit = self.default_attribute_limit();\n        let declarations = self.tables\n            .defaults')
  s=s.replace('declarations.ordered.len() >= self.config.limits.max_attributes','declarations.ordered.len() >= attribute_limit')
  s=s.replace('''                value: value.try_clone()?,
            })?;
        }
        let attribute_type''','''                value: value.try_clone()?,
            })?;
            self.tables.max_default_attributes = self.tables.max_default_attributes.max(declarations.ordered.len());
        }
        let attribute_type''')
 if name=='value.rs':
  # Only this child constructor runs outside the parsing table scope. The new
  # local active-name index inherits a local index seed, not an inactive slot.
  start=s.index('    pub(crate) fn inherit_value_context(');end=s.index('    pub(crate) fn is_external_value(',start)
  part=s[start:end].replace('self.tables.parameter_entities.hasher()', 'child.active_entities.names.hasher()')
  s=s[:start]+part+s[end:]
 p.write_text(s)
p=r/'dtd_tables.rs';s=p.read_text().replace('    fn empty_like(&self)', '    pub(crate) fn empty_like(&self)');p.write_text(s)
