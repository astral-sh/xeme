from pathlib import Path
import hashlib,json,subprocess,time,os
out=Path('/tmp/oriole-shared-dtd-implementation');source=Path('/tmp/oriole-shared-dtd');prior=Path('/tmp/oriole-deep-profile-experiment/inherited')
python='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(out/'run_clean.py').write_text((prior/'run_clean.py').read_text())
for name in ['missing.py','doctype.py','siblings.py','general.py','oracle.py','native.py']:
 s=(prior/name).read_text().replace(str(prior/'frozen-source'),str(source)).replace(str(prior),str(out)).replace("'3'","'5'")
 if name=='oracle.py': s=s.replace('/tmp/oriole-deep-profile-experiment/control/liboriole_expat.so',str(prior/'liboriole_expat.so'))
 (out/name).write_text(s)
# Preserve the initial draft publication observations, then run the exact same cases on release.
(out/'initial-publication.json').write_bytes((out/'observations.json').read_bytes())
s=(out/'publication-probe.py').read_text().replace('/home/dev-user/.cache/oriole/shared-dtd-target/debug/liboriole_expat.so',str(out/'liboriole_expat.so'))
(out/'publication-release.py').write_text(s)
# Freeze the unchanged original upstream runner and adapter sources from the same Git base.
for file in ['run.py','bridge.c','bridge.h']:
 dest=out/'upstream-runner'/file;dest.parent.mkdir(exist_ok=True)
 dest.write_bytes(subprocess.check_output(['git','show','ebcd46dd0cd720d1f28de5fda0b87cf4b1b05756:tools/upstream-expat/'+file],cwd='/home/dev-user/code/oss/oriole'))
commands=[]
scripts=[('publication','publication-release.py',[]),('membership','oracle.py',[str(out/'liboriole_expat.so')]),('missing','missing.py',[str(out/'liboriole_expat.so'),str(out/'missing.json')]),('doctype','doctype.py',[str(out/'liboriole_expat.so'),str(out/'doctype.json.gz')]),('siblings','siblings.py',[str(out/'liboriole_expat.so'),str(out/'siblings.json')]),('general','general.py',[str(out/'liboriole_expat.so'),str(out/'general.json')]),('native','native.py',[]),('upstream','upstream-runner/run.py',['--source','/home/dev-user/.cache/oriole/upstream/expat-2.8.4','--config','/home/dev-user/.cache/oriole/expat-build/expat_config.h','--library',str(out/'liboriole_expat.so'),'--output',str(out/'upstream-api')])]
for label,script,args in scripts:
 command=['taskset','-c','5',python,'-I','-S',str(out/'run_clean.py'),str(out/script),*args];start=time.time()
 with (out/(label+'-final.log')).open('w') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=360)
 row={'label':label,'command':command,'exit_code':result.returncode,'seconds':time.time()-start,'log_sha256':sha(out/(label+'-final.log'))};commands.append(row)
 (out/'verification-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(row,flush=True)
 assert result.returncode in ([0,1] if label=='upstream' else [0]),row
