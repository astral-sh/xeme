from pathlib import Path
import gzip
import hashlib
import json
import math
import statistics
import sys

root = Path('/tmp/oriole-shared-dtd-tiny-profile')
screen = root / 'screen'
report = json.loads((screen / 'report.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
sys.path.insert(0, '/home/dev-user/code/oss/oriole/benchmarks')
from projects import native_output

assert report['status'] == 'passed'
assert report['affinity'] == [0]
for path, expected in report['hashes'].items():
    assert sha(Path(path)) == expected, path
source = json.loads((root / 'source.json').read_text())
for path, expected in source['files'].items():
    assert sha(Path('/tmp/oriole-shared-dtd-fast') / path) == expected, path
assert sha(root / 'fast.patch') == source['patch_sha256']

gold = {}
for row in report['preflight']:
    observations = json.loads(gzip.decompress((screen / f"preflight-{row['input']}-{row['namespaces']}.json.gz").read_bytes()))
    assert len(observations) == 5
    reference = observations['reference']
    for value in observations.values():
        assert value['status'] == 1 and value['error'] == 0 and not value['callback_errors']
        assert value['normalized_events'] == reference['normalized_events']
    key = (row['input'], row['namespaces'])
    assert key not in gold
    gold[key] = native_output(reference['normalized_events'])
    assert tuple(row['expected']) == gold[key]

seen = set()
samples = 0
ctors = 0
cohorts = {}
for row in report['rows']:
    key = (row['input'], row['namespaces'], row['pair'], row['engine'])
    assert key not in seen
    seen.add(key)
    assert row['pair'] in range(7)
    assert not (screen / (row['output'] + '.stderr')).read_bytes()
    data = json.loads(gzip.decompress((screen / row['output']).read_bytes()))
    if row['input'] == 'constructor':
        assert data['iterations'] == 200000 and data['seconds'] > 0
        value = data['seconds'] / data['iterations']
        ctors += 1
    else:
        expected_count = 2000 if row['input'] in ['empty', 'attributes', 'text'] else 30
        assert len(data['samples']) == expected_count + 1
        for i, sample in enumerate(data['samples']):
            assert sample['iteration'] == i and sample['warmup'] == (i == 0)
            assert sample['seconds'] > 0
            assert tuple(sample[k] for k in ['hash', 'elements', 'text_bytes']) == gold[row['input'], row['namespaces']]
        value = statistics.median(s['seconds'] for s in data['samples'] if not s['warmup'])
        samples += len(data['samples'])
    assert value == row['seconds']
    cohorts.setdefault(key[:3], {})[row['engine']] = value

assert len(seen) == 392 and len(cohorts) == 98 and len(gold) == 12 and ctors == 56
for values in cohorts.values():
    assert set(values) == {'baseline', 'shared', 'split', 'outlined'}
for row in report['summary']:
    pairs = [cohorts[row['input'], row['namespaces'], pair] for pair in range(7)]
    for engine, value in row['relative_to_baseline'].items():
        assert value == statistics.median(p[engine] / p['baseline'] for p in pairs)
    assert row['outlined_over_shared'] == statistics.median(p['outlined'] / p['shared'] for p in pairs)

result = {
    'status': 'passed',
    'scope': 'Read-only source, retained preflights, sample arithmetic and binary/source identity review; no builds or timing reruns.',
    'source_files_verified': len(source['files']),
    'frozen_files_verified': len(report['hashes']),
    'parse_preflights': len(gold),
    'normalized_streams_verified': len(gold) * 5,
    'paired_cohorts': len(cohorts),
    'native_process_outputs': len(seen),
    'parse_samples_including_warmups': samples,
    'constructor_process_outputs': ctors,
    'constructor_pairs_per_process': 200000,
    'constructor_warmup_pairs_per_process': 1000,
    'library_hashes': {p: h for p, h in report['hashes'].items() if p.endswith('.so')},
    'artifacts': {str(p): sha(p) for p in [Path(__file__), screen / 'report.json', root / 'screen.py', root / 'source.json', root / 'constructor_driver.c', root / 'fast.patch']},
    'findings': [],
    'constructor_review': 'Every successful constructor result is freed once before dlclose; NULL aborts the run. Function addresses are copied with checked pointer sizes. Timer covers the complete create/free loop after 1000 warmups, without parse or callback work.',
    'limitations': [
        'Seven paired process cohorts on one shared host, CPU0 affinity; no controlled clock frequency, load or cache state and no uncertainty intervals.',
        'Complete parse samples include construction, callback registration, parse, native callback hashing and free; process/library/file loading is excluded. Tiny samples remain sensitive to timing and compiler layout.',
        'Project cases are XML parser microbenchmarks on three files, not end-to-end GTK, Batik or DocBook workloads. Only one chunk size and raw/namespace modes are represented.',
        'Observed empty-document ratios versus the pre-shared baseline are 1.097/1.114 for shared and 0.947/0.968 for split. Project split ratios span about 0.987 to 1.005; these data do not support a broad project speedup claim.',
        'Constructor-only split ratios remain 1.018/1.015 versus baseline; the fast-path result is not an allocation-count reduction.',
        'The split candidate retains the same reported 80-byte assembly prologue; these results do not establish stack-frame removal as the cause of the timing change.',
        'The runner checks exit status before recording rows but does not persist numeric exit codes. Retained valid outputs and empty stderr were independently checked; this review does not reconstruct absent process metadata.'
    ],
}
Path('/tmp/oriole-shared-dtd-tiny-independent-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
