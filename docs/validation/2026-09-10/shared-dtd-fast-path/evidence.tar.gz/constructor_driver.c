#define _POSIX_C_SOURCE 200809L
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef void *(*Create)(const char *);
typedef void *(*CreateNs)(const char *, char);
typedef void (*Destroy)(void *);
static double now(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) abort();
    return (double)t.tv_sec + (double)t.tv_nsec / 1e9;
}
int main(int argc, char **argv) {
    if (argc != 3) return 2;
    int ns = strcmp(argv[2], "namespaces") == 0;
    void *lib = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (!lib) return 2;
    void *address = dlsym(lib, "XML_ParserCreate");
    Create create;
    if (!address || sizeof(create) != sizeof(address)) return 2;
    memcpy(&create, &address, sizeof(create));
    address = dlsym(lib, "XML_ParserCreateNS");
    CreateNs create_ns;
    if (!address || sizeof(create_ns) != sizeof(address)) return 2;
    memcpy(&create_ns, &address, sizeof(create_ns));
    address = dlsym(lib, "XML_ParserFree");
    Destroy destroy;
    if (!address || sizeof(destroy) != sizeof(address)) return 2;
    memcpy(&destroy, &address, sizeof(destroy));
    const size_t iterations = 200000;
    for (size_t i = 0; i < 1000; i++) {
        void *p = ns ? create_ns(NULL, '|') : create(NULL);
        if (!p) return 1;
        destroy(p);
    }
    double start = now();
    for (size_t i = 0; i < iterations; i++) {
        void *p = ns ? create_ns(NULL, '|') : create(NULL);
        if (!p) return 1;
        destroy(p);
    }
    double elapsed = now() - start;
    printf("{\"iterations\":%zu,\"seconds\":%.9f}\n", iterations, elapsed);
    dlclose(lib);
    return 0;
}
