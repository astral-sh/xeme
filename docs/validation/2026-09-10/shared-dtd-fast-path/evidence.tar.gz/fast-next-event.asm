
/home/dev-user/.cache/oriole/shared-dtd-fast-target/release/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .plt.got:

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000078bb0 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event>:
   78bb0:	push   %r15
   78bb2:	push   %r14
   78bb4:	push   %r13
   78bb6:	push   %r12
   78bb8:	push   %rbx
   78bb9:	sub    $0x50,%rsp
   78bbd:	mov    %rdi,%rbx
   78bc0:	mov    0x858(%rsi),%eax
   78bc6:	test   %eax,%eax
   78bc8:	sete   %cl
   78bcb:	movzbl 0x8b1(%rsi),%eax
   78bd2:	or     %al,%cl
   78bd4:	test   $0x1,%cl
   78bd7:	je     78ca8 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0xf8>
   78bdd:	cmpb   $0xff,0x840(%rsi)
   78be4:	sete   %cl
   78be7:	test   %al,%cl
   78be9:	je     78c9e <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0xee>
   78bef:	mov    0x858(%rsi),%eax
   78bf5:	test   %eax,%eax
   78bf7:	je     78c9e <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0xee>
   78bfd:	lea    0x8(%rsp),%rdi
   78c02:	mov    %rsi,%r14
   78c05:	call   75830 <_RNvMs1_NtCs18jjvMNnTSC_6oriole10dtd_tablesNtB7_6Parser20ensure_shared_tables>
   78c0a:	mov    %r14,%rsi
   78c0d:	cmpb   $0xff,0x38(%rsp)
   78c12:	je     78c9e <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0xee>
   78c18:	lea    0x810(%rsi),%rax
   78c1f:	mov    0x38(%rsp),%rcx
   78c24:	mov    %rcx,0x38(%rbx)
   78c28:	movups 0x8(%rsp),%xmm0
   78c2d:	movups 0x18(%rsp),%xmm1
   78c32:	movups 0x28(%rsp),%xmm2
   78c37:	movups %xmm2,0x28(%rbx)
   78c3b:	movups %xmm1,0x18(%rbx)
   78c3f:	movups %xmm0,0x8(%rbx)
   78c43:	mov    0x38(%rsp),%rcx
   78c48:	mov    %rcx,0x30(%rax)
   78c4c:	movups 0x8(%rsp),%xmm0
   78c51:	movups 0x18(%rsp),%xmm1
   78c56:	movups 0x28(%rsp),%xmm2
   78c5b:	movups %xmm2,0x20(%rax)
   78c5f:	movups %xmm1,0x10(%rax)
   78c63:	movups %xmm0,(%rax)
   78c66:	mov    0x1b8(%rsi),%rdi
   78c6d:	mov    0x1c8(%rsi),%rax
   78c74:	movq   $0x0,0x1c8(%rsi)
   78c7f:	mov    %rsi,%r14
   78c82:	mov    %rax,%rsi
   78c85:	call   49a80 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueSINtNtB4_6option6OptionNtCs18jjvMNnTSC_6oriole12PendingEventEEB10_>
   78c8a:	movq   $0x0,0x1d0(%r14)
   78c95:	movq   $0xfffffffffffffffe,(%rbx)
   78c9c:	jmp    78cb0 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x100>
   78c9e:	mov    0x858(%rsi),%eax
   78ca4:	test   %eax,%eax
   78ca6:	je     78cc1 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x111>
   78ca8:	mov    %rbx,%rdi
   78cab:	call   85230 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser17next_event_scoped>
   78cb0:	mov    %rbx,%rax
   78cb3:	add    $0x50,%rsp
   78cb7:	pop    %rbx
   78cb8:	pop    %r12
   78cba:	pop    %r13
   78cbc:	pop    %r14
   78cbe:	pop    %r15
   78cc0:	ret
   78cc1:	mov    0x850(%rsi),%r14
   78cc8:	mov    0x20(%r14),%rax
   78ccc:	movabs $0x7ffffffffffffffe,%rcx
   78cd6:	cs nopw 0x0(%rax,%rax,1)
   78ce0:	cmp    %rcx,%rax
   78ce3:	ja     78dfc <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x24c>
   78ce9:	lea    0x1(%rax),%rdx
   78ced:	lock cmpxchg %rdx,0x20(%r14)
   78cf3:	jne    78ce0 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x130>
   78cf5:	mov    $0x1,%cl
   78cf7:	xor    %eax,%eax
   78cf9:	lock cmpxchg %cl,0x170(%r14)
   78d02:	jne    78d40 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x190>
   78d04:	lea    0x28(%r14),%r15
   78d08:	lea    0x270(%rsi),%r12
   78d0f:	mov    %r12,%rdi
   78d12:	mov    %rsi,%r13
   78d15:	mov    %r15,%rsi
   78d18:	call   451f0 <_RINvNtCs6SLOTazmNXq_4core10intrinsics25typed_swap_nonoverlappingNtNtCs18jjvMNnTSC_6oriole10dtd_tables9DtdTablesEB14_>
   78d1d:	mov    %rbx,%rdi
   78d20:	mov    %r13,%rsi
   78d23:	call   85230 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser17next_event_scoped>
   78d28:	mov    %r12,%rdi
   78d2b:	mov    %r15,%rsi
   78d2e:	call   451f0 <_RINvNtCs6SLOTazmNXq_4core10intrinsics25typed_swap_nonoverlappingNtNtCs18jjvMNnTSC_6oriole10dtd_tables9DtdTablesEB14_>
   78d33:	movb   $0x0,0x170(%r14)
   78d3b:	jmp    78dd4 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x224>
   78d40:	mov    0x190(%rsi),%rax
   78d47:	test   %rax,%rax
   78d4a:	je     78de1 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x231>
   78d50:	mov    0x180(%rsi),%rcx
   78d57:	lea    (%rax,%rax,2),%rdx
   78d5b:	shl    $0x7,%rdx
   78d5f:	lea    (%rcx,%rdx,1),%rax
   78d63:	cmpl   $0x1,-0x180(%rcx,%rdx,1)
   78d6b:	jne    78d84 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x1d4>
   78d6d:	mov    -0x178(%rax),%r15
   78d74:	movups -0x170(%rax),%xmm0
   78d7b:	mov    -0x160(%rax),%rax
   78d82:	jmp    78daa <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x1fa>
   78d84:	lea    (%rcx,%rdx,1),%rdi
   78d88:	add    $0xfffffffffffffe80,%rdi
   78d8f:	mov    -0x58(%rax),%r15
   78d93:	movups -0x28(%rax),%xmm0
   78d97:	movaps %xmm0,0x40(%rsp)
   78d9c:	xor    %esi,%esi
   78d9e:	xor    %edx,%edx
   78da0:	call   6f160 <_RNvMs0_NtCs18jjvMNnTSC_6oriole8encodingNtB5_6Source7raw_len>
   78da5:	movaps 0x40(%rsp),%xmm0
   78daa:	lea    -0x66df5(%rip),%rcx        # 11fbc <_RNvNtNtNtCs6SLOTazmNXq_4core7unicode12unicode_data2cf17SHORT_OFFSET_RUNS+0x57cc>
   78db1:	mov    %rcx,0x8(%rbx)
   78db5:	movq   $0x1c,0x10(%rbx)
   78dbd:	mov    %r15,0x18(%rbx)
   78dc1:	movups %xmm0,0x20(%rbx)
   78dc5:	mov    %rax,0x30(%rbx)
   78dc9:	movb   $0x10,0x38(%rbx)
   78dcd:	movq   $0xfffffffffffffffe,(%rbx)
   78dd4:	mov    %r14,%rdi
   78dd7:	call   46940 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCsjgxDP0hrcD7_14oriole_storage6shared6SharedINtNtBG_8try_lock7TryLockNtNtCs18jjvMNnTSC_6oriole10dtd_tables9DtdTablesEEEB1R_>
   78ddc:	jmp    78cb0 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x100>
   78de1:	lea    -0x66c93(%rip),%rdi        # 12155 <_RNvNtNtNtCs6SLOTazmNXq_4core7unicode12unicode_data2cf17SHORT_OFFSET_RUNS+0x5965>
   78de8:	lea    0x698a9(%rip),%rdx        # e2698 <_RNvCs4mWuQOMK248_12oriole_expat8FEATURES+0x15a8>
   78def:	mov    $0x21,%esi
   78df4:	call   *0x6c49e(%rip)        # e5298 <_GLOBAL_OFFSET_TABLE_+0x748>
   78dfa:	ud2
   78dfc:	call   *0x6c01e(%rip)        # e4e20 <_GLOBAL_OFFSET_TABLE_+0x2d0>
   78e02:	mov    %rax,%rbx
   78e05:	mov    %r12,%rdi
   78e08:	mov    %r15,%rsi
   78e0b:	call   451f0 <_RINvNtCs6SLOTazmNXq_4core10intrinsics25typed_swap_nonoverlappingNtNtCs18jjvMNnTSC_6oriole10dtd_tables9DtdTablesEB14_>
   78e10:	movb   $0x0,0x170(%r14)
   78e18:	jmp    78e1d <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x26d>
   78e1a:	mov    %rax,%rbx
   78e1d:	mov    %r14,%rdi
   78e20:	call   46940 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCsjgxDP0hrcD7_14oriole_storage6shared6SharedINtNtBG_8try_lock7TryLockNtNtCs18jjvMNnTSC_6oriole10dtd_tables9DtdTablesEEEB1R_>
   78e25:	mov    %rbx,%rdi
   78e28:	call   2c5a0 <_Unwind_Resume@plt>
   78e2d:	call   *0x6c485(%rip)        # e52b8 <_GLOBAL_OFFSET_TABLE_+0x768>
