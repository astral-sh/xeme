
/tmp/oriole-shared-dtd-implementation/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .plt.got:

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .text:

0000000000078280 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event>:
   78280:	push   %r15
   78282:	push   %r14
   78284:	push   %r13
   78286:	push   %r12
   78288:	push   %rbx
   78289:	sub    $0x50,%rsp
   7828d:	mov    %rdi,%rbx
   78290:	cmpb   $0xff,0x840(%rsi)
   78297:	jne    7835c <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0xdc>
   7829d:	cmpb   $0x0,0x8b1(%rsi)
   782a4:	je     7835c <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0xdc>
   782aa:	mov    0x858(%rsi),%eax
   782b0:	test   %eax,%eax
   782b2:	je     7835c <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0xdc>
   782b8:	lea    0x8(%rsp),%rdi
   782bd:	mov    %rsi,%r14
   782c0:	call   74f00 <_RNvMs1_NtCs18jjvMNnTSC_6oriole10dtd_tablesNtB7_6Parser20ensure_shared_tables>
   782c5:	mov    %r14,%rsi
   782c8:	cmpb   $0xff,0x38(%rsp)
   782cd:	je     7835c <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0xdc>
   782d3:	lea    0x810(%rsi),%rax
   782da:	mov    0x38(%rsp),%rcx
   782df:	mov    %rcx,0x38(%rbx)
   782e3:	movups 0x8(%rsp),%xmm0
   782e8:	movups 0x18(%rsp),%xmm1
   782ed:	movups 0x28(%rsp),%xmm2
   782f2:	movups %xmm2,0x28(%rbx)
   782f6:	movups %xmm1,0x18(%rbx)
   782fa:	movups %xmm0,0x8(%rbx)
   782fe:	mov    0x38(%rsp),%rcx
   78303:	mov    %rcx,0x30(%rax)
   78307:	movups 0x8(%rsp),%xmm0
   7830c:	movups 0x18(%rsp),%xmm1
   78311:	movups 0x28(%rsp),%xmm2
   78316:	movups %xmm2,0x20(%rax)
   7831a:	movups %xmm1,0x10(%rax)
   7831e:	movups %xmm0,(%rax)
   78321:	mov    0x1b8(%rsi),%rdi
   78328:	mov    0x1c8(%rsi),%rax
   7832f:	movq   $0x0,0x1c8(%rsi)
   7833a:	mov    %rsi,%r14
   7833d:	mov    %rax,%rsi
   78340:	call   49970 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueSINtNtB4_6option6OptionNtCs18jjvMNnTSC_6oriole12PendingEventEEB10_>
   78345:	movq   $0x0,0x1d0(%r14)
   78350:	movq   $0xfffffffffffffffe,(%rbx)
   78357:	jmp    7848c <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x20c>
   7835c:	mov    0x858(%rsi),%eax
   78362:	test   %eax,%eax
   78364:	je     78373 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0xf3>
   78366:	mov    %rbx,%rdi
   78369:	call   a1320 <_RNvYNvMs8_Cs18jjvMNnTSC_6orioleNtB8_6Parser17next_event_scopedINtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTQBt_EE9call_onceB8_>
   7836e:	jmp    7848c <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x20c>
   78373:	mov    0x850(%rsi),%r14
   7837a:	mov    0x20(%r14),%rax
   7837e:	movabs $0x7ffffffffffffffe,%rcx
   78388:	nopl   0x0(%rax,%rax,1)
   78390:	cmp    %rcx,%rax
   78393:	ja     784b8 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x238>
   78399:	lea    0x1(%rax),%rdx
   7839d:	lock cmpxchg %rdx,0x20(%r14)
   783a3:	jne    78390 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x110>
   783a5:	mov    $0x1,%cl
   783a7:	xor    %eax,%eax
   783a9:	lock cmpxchg %cl,0x170(%r14)
   783b2:	jne    783f0 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x170>
   783b4:	lea    0x28(%r14),%r15
   783b8:	lea    0x270(%rsi),%r12
   783bf:	mov    %r12,%rdi
   783c2:	mov    %rsi,%r13
   783c5:	mov    %r15,%rsi
   783c8:	call   450e0 <_RINvNtCs6SLOTazmNXq_4core10intrinsics25typed_swap_nonoverlappingNtNtCs18jjvMNnTSC_6oriole10dtd_tables9DtdTablesEB14_>
   783cd:	mov    %rbx,%rdi
   783d0:	mov    %r13,%rsi
   783d3:	call   a1320 <_RNvYNvMs8_Cs18jjvMNnTSC_6orioleNtB8_6Parser17next_event_scopedINtNtNtCs6SLOTazmNXq_4core3ops8function6FnOnceTQBt_EE9call_onceB8_>
   783d8:	mov    %r12,%rdi
   783db:	mov    %r15,%rsi
   783de:	call   450e0 <_RINvNtCs6SLOTazmNXq_4core10intrinsics25typed_swap_nonoverlappingNtNtCs18jjvMNnTSC_6oriole10dtd_tables9DtdTablesEB14_>
   783e3:	movb   $0x0,0x170(%r14)
   783eb:	jmp    78484 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x204>
   783f0:	mov    0x190(%rsi),%rax
   783f7:	test   %rax,%rax
   783fa:	je     7849d <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x21d>
   78400:	mov    0x180(%rsi),%rcx
   78407:	lea    (%rax,%rax,2),%rdx
   7840b:	shl    $0x7,%rdx
   7840f:	lea    (%rcx,%rdx,1),%rax
   78413:	cmpl   $0x1,-0x180(%rcx,%rdx,1)
   7841b:	jne    78434 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x1b4>
   7841d:	mov    -0x178(%rax),%r15
   78424:	movups -0x170(%rax),%xmm0
   7842b:	mov    -0x160(%rax),%rax
   78432:	jmp    7845a <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x1da>
   78434:	lea    (%rcx,%rdx,1),%rdi
   78438:	add    $0xfffffffffffffe80,%rdi
   7843f:	mov    -0x58(%rax),%r15
   78443:	movups -0x28(%rax),%xmm0
   78447:	movaps %xmm0,0x40(%rsp)
   7844c:	xor    %esi,%esi
   7844e:	xor    %edx,%edx
   78450:	call   6e830 <_RNvMs0_NtCs18jjvMNnTSC_6oriole8encodingNtB5_6Source7raw_len>
   78455:	movaps 0x40(%rsp),%xmm0
   7845a:	lea    -0x664a5(%rip),%rcx        # 11fbc <_RNvNtNtNtCs6SLOTazmNXq_4core7unicode12unicode_data2cf17SHORT_OFFSET_RUNS+0x57cc>
   78461:	mov    %rcx,0x8(%rbx)
   78465:	movq   $0x1c,0x10(%rbx)
   7846d:	mov    %r15,0x18(%rbx)
   78471:	movups %xmm0,0x20(%rbx)
   78475:	mov    %rax,0x30(%rbx)
   78479:	movb   $0x10,0x38(%rbx)
   7847d:	movq   $0xfffffffffffffffe,(%rbx)
   78484:	mov    %r14,%rdi
   78487:	call   46830 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCsjgxDP0hrcD7_14oriole_storage6shared6SharedINtNtBG_8try_lock7TryLockNtNtCs18jjvMNnTSC_6oriole10dtd_tables9DtdTablesEEEB1R_>
   7848c:	mov    %rbx,%rax
   7848f:	add    $0x50,%rsp
   78493:	pop    %rbx
   78494:	pop    %r12
   78496:	pop    %r13
   78498:	pop    %r14
   7849a:	pop    %r15
   7849c:	ret
   7849d:	lea    -0x6634f(%rip),%rdi        # 12155 <_RNvNtNtNtCs6SLOTazmNXq_4core7unicode12unicode_data2cf17SHORT_OFFSET_RUNS+0x5965>
   784a4:	lea    0x6a03d(%rip),%rdx        # e24e8 <_RNvCs4mWuQOMK248_12oriole_expat8FEATURES+0x15a8>
   784ab:	mov    $0x21,%esi
   784b0:	call   *0x6cc32(%rip)        # e50e8 <_GLOBAL_OFFSET_TABLE_+0x748>
   784b6:	ud2
   784b8:	call   *0x6c7b2(%rip)        # e4c70 <_GLOBAL_OFFSET_TABLE_+0x2d0>
   784be:	mov    %rax,%rbx
   784c1:	mov    %r12,%rdi
   784c4:	mov    %r15,%rsi
   784c7:	call   450e0 <_RINvNtCs6SLOTazmNXq_4core10intrinsics25typed_swap_nonoverlappingNtNtCs18jjvMNnTSC_6oriole10dtd_tables9DtdTablesEB14_>
   784cc:	movb   $0x0,0x170(%r14)
   784d4:	jmp    784d9 <_RNvMs8_Cs18jjvMNnTSC_6orioleNtB5_6Parser10next_event+0x259>
   784d6:	mov    %rax,%rbx
   784d9:	mov    %r14,%rdi
   784dc:	call   46830 <_RINvNtCs6SLOTazmNXq_4core3ptr9drop_glueINtNtCsjgxDP0hrcD7_14oriole_storage6shared6SharedINtNtBG_8try_lock7TryLockNtNtCs18jjvMNnTSC_6oriole10dtd_tables9DtdTablesEEEB1R_>
   784e1:	mov    %rbx,%rdi
   784e4:	call   2c490 <_Unwind_Resume@plt>
   784e9:	call   *0x6cc19(%rip)        # e5108 <_GLOBAL_OFFSET_TABLE_+0x768>
