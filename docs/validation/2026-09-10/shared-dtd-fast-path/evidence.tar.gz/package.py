from pathlib import Path
import difflib,gzip,hashlib,json,re,shutil,statistics,tarfile
root=Path('/tmp/oriole-shared-dtd-tiny-profile');out=Path('/tmp/oriole-shared-dtd-fast-handoff');out.mkdir(exist_ok=True);old=Path('/tmp/oriole-shared-dtd-implementation');source=Path('/tmp/oriole-shared-dtd-fast')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,d):
 dest=out/d;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
def packed(p,d):
 dest=out/d;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
manifest=json.loads((root/'source.json').read_text());assert all(sha(source/p)==h for p,h in manifest['files'].items())
for name in ['source.json','fast.patch','screen.py','constructor_driver.c','verify-fast.py','investigation.json','fast-next-event.asm','next-event.asm','package.py']:
 copy(root/name,name)
copy(old/'source.json','parent-source.json')
with tarfile.open(out/'source.tar.gz','w:gz') as t:
 for p in manifest['files']:t.add(source/p,arcname=p)
for name in ['fast-build.log','fast-tests.log','fast-clippy.log','fast-fmt.log','outlined-build.log','screen.log','verify-fast.log','candidate.log','baseline.log','candidate.json','baseline.json']:
 packed(root/name,'logs/'+name+'.gz')
for top in ['screen','validation']:
 for p in (root/top).rglob('*'):
  if not p.is_file() or p.name=='runtests' or p.suffix in ['.so','.a']:continue
  relative=str(p.relative_to(root))
  if p.suffix in ['.log','.json'] and p.stat().st_size>100000:packed(p,relative+'.gz')
  else:copy(p,relative)
# Preserve helpers used by the complete probes and timing preflight.
helpers=[old/'run_clean.py',old/'doctype.py',Path('/tmp/oriole-missing-parameter/oracle.py'),Path('/tmp/oriole-custom-final/probes/external-compare.py'),Path('/tmp/oriole-custom-alias-external-source.py'),Path('/home/dev-user/code/oss/oriole/tools/xml_abi.py'),Path('/home/dev-user/code/oss/oriole/benchmarks/projects.py'),Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')]
for p in helpers:copy(p,'helpers/'+p.name)
for p in (old/'upstream-runner').iterdir():
 if p.is_file():copy(p,'upstream-runner/'+p.name)
copy(old/'benchmark/results.json','benchmark-parent-results.json')
report=json.loads((root/'screen/report.json').read_text());timings=[]
for summary in report['summary']:
 name,ns=summary['input'],summary['namespaces'];pairs=[{r['engine']:r['seconds'] for r in report['rows'] if (r['input'],r['namespaces'],r['pair'])==(name,ns,i)} for i in range(7)]
 ratios=[p['split']/p['shared'] for p in pairs];timings.append({**summary,'split_over_shared':statistics.median(ratios),'split_over_shared_each_pair':ratios})
for p,h in report['hashes'].items():assert sha(Path(p))==h
for p in report['hashes']:
 path=Path(p)
 if path.suffix in ['.xml','.ui','.xsl','.svg']:copy(path,'inputs/'+path.name)
counts=[int(x) for x in re.findall(r'test result: ok\. (\d+) passed',(root/'fast-tests.log').read_text())];assert sum(counts)==319
summary={'status':'passed','change':'An ordinary parser without shared DTD ownership or an active DOCTYPE calls the unchanged event body directly; all owner-bearing and first-DTD-step calls keep the original scope and initialization path.','base_source_manifest_sha256':sha(old/'source.json'),'candidate_source_manifest_sha256':sha(root/'source.json'),'patch_sha256':sha(root/'fast.patch'),'candidate_library_sha256':sha(root/'split.so'),'parent_library_sha256':sha(old/'liboriole_expat.so'),'tests':{'scoped_core_ffi_release':sum(counts),'per_suite_pass_counts':counts,'clippy':'passed release all-targets -D warnings','fmt':'passed'},'validation':json.loads((root/'validation/summary.json').read_text()),'timing':timings,'decision':'Select the plain split; retain explicit inline/inline-never comparison as an unselected experiment. No broad project speedup claim.','limits':['Four-way microbenchmark on a shared host, seven randomized paired process cohorts. CPU frequency/cache/bandwidth were not fixed. Native parser timings include one timer pair per parse; constructor-only does not.','Complete parser timing includes creation, handlers, parse, native callback hashing and free; excludes file load, dlopen, process startup and output. Project XML only, not end-to-end applications. Batik external DTD is skipped by every engine.','Plain split retains five saved registers and 80 stack bytes in next_event in this build. Control-flow/code-layout effects are plausible, but stack-frame elimination is not the demonstrated mechanism. Hardware perf events were unavailable (paranoid4); no settings changed.','The complete upstream matrix retains663 failing observations and9 publication callback-prefix differences. No limits, chosen allocator policy, upstream assertions or thresholds changed.','This followup performed no new Rust ASan campaign; selected-allocation sweeps and existing core/FFI lifecycle tests ran in release.']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
review={'reviewer':'root','kind':'independent source review reported by collaboration message','patch_sha256':sha(root/'fast.patch'),'conclusion':'No blocker','reason':'With no owner and no active DOCTYPE, original with_dtd_tables directly calls next_event_scoped and initialization condition is false. Discovery of DOCTYPE yields StartDoctype before declarations, so next call initializes owner. Error and drained-event behavior preserved.','scope':'Source equivalence review; no independent test/benchmark rerun claimed.'}
(out/'root-source-review.json').write_text(json.dumps(review,indent=2)+'\n')
build={'source':'/tmp/oriole-shared-dtd-fast','target':'/home/dev-user/.cache/oriole/shared-dtd-fast-target','environment':{'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/build','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/shared-dtd-fast-target','CARGO_INCREMENTAL':'0'},'toolchain':'rustc1.98.1-dev(f6270311094cd4b48fefce03debdffcf8396c64c),ohm1.98.1-1,LLVM22.1.8,x86_64-unknown-linux-gnu','commands':[['cargo','+ohm','build','--release','-p','oriole_expat'],['taskset','-c','6','cargo','+ohm','test','--release','-p','oriole','-p','oriole_expat'],['taskset','-c','6','cargo','+ohm','clippy','--release','-p','oriole','-p','oriole_expat','--all-targets','--','-D','warnings'],['taskset','-c','6','cargo','+ohm','fmt','--all','--','--check']],'binaries':{str(p):sha(p) for p in [root/'split.so',root/'outlined.so',old/'liboriole_expat.so',old/'baseline.so',root/'constructor-driver',old/'benchmark/driver']}}
(out/'build.json').write_text(json.dumps(build,indent=2)+'\n')
readme='''# Ordinary-document event fast path

This followup adds eight lines over the frozen shared-DTD source (manifest `24f85545`). Parsers with no table owner and no active DOCTYPE call the existing event body directly. The first DTD step, shared-family locking/publication, owned callback events, decoder state, limits and selected allocator remain as before. The full candidate source is archived; root owns integration separately.

## Validation

319 core/FFI release tests, including selected-allocation failure sweeps, pass. Strict release Clippy and formatting pass. The 4,740 public upstream observations are exactly unchanged: 4,077 pass and 663 fail. All 432 publication observations remain identical, including the nine known standalone callback-prefix differences. All 4,104 DOCTYPE handler/encoding observations match Expat; 15,288 custom-provenance observations have zero baseline changes, zero reference outcome differences, and zero successful callback differences. Failed upstream assertions remain in the logs. This layer adds no sanitizer campaign or general conformance claim.

## Timing

The four-way screen compares the pre-sharing baseline, frozen shared implementation, selected plain split, and unselected explicit inline/outline variant. Each has the same complete normalized callback preflights. Every measured parser sample matches an independently computed callback hash and element/text counts. Seven randomized process cohorts run on CPU0; each tiny-input process times 2,000 parses and each project process 30, after one warmup. The constructor-only probe times 200,000 create/free pairs after 1,000 warmups, without parsing or per-iteration timers.

Selected split/shared median paired ratios: empty 0.854/0.864, attributes 0.960/0.984, and text 0.928/0.982 (non-namespace/namespace). Six project ratios range from 0.986 to 1.022. Empty input versus the pre-sharing baseline moves from 1.097/1.114 to 0.947/0.968 in this screen. Constructor-only shared cost is about 3% over baseline. These are shared-host parser microbenchmarks; there is no broad project speedup claim.

The plain split still has the original register-save/80-byte stack prologue in this compiled library. The observed gain cannot be attributed to proven frame removal. Hardware perf sampling was denied by host paranoid4 policy; failed logs are preserved, with no host changes. The explicit outline variant is retained as an unselected comparison; only the plain split received the full release tests and final compatibility rerun.

## Artifacts

`fast.patch` is the isolated change. `source.json` and `source.tar.gz` identify every candidate source file; `parent-source.json` identifies the prior layer. `build.json`, compressed build/test logs, probe generators/observations, all native timing outputs, and the manifest preserve provenance. Local binary paths and hashes are recorded; binaries are excluded. Runner scripts retain the exact local evidence paths used in this session. `root-source-review.json` records the independent source review scope.
'''
(out/'README.md').write_text(readme)
artifacts={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='artifact-manifest.json'}
(out/'artifact-manifest.json').write_text(json.dumps({'artifacts':artifacts},indent=2)+'\n')
print(json.dumps({'handoff':str(out),'artifacts':len(artifacts),'bytes':sum(x['bytes'] for x in artifacts.values()),'summary_sha256':sha(out/'summary.json'),'manifest_sha256':sha(out/'artifact-manifest.json')},indent=2))
