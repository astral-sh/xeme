from pathlib import Path
import gzip,hashlib,json,random,statistics,subprocess,sys,os
root=Path('/tmp/oriole-shared-dtd-tiny-profile');out=root/'screen';out.mkdir();frozen=Path('/tmp/oriole-shared-dtd-implementation')
sys.path[:0]=['/home/dev-user/code/oss/oriole/tools','/home/dev-user/code/oss/oriole/benchmarks']
from xml_abi import Expat
from projects import native_output
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((frozen/'benchmark/results.json').read_text())
inputs={r['input']:Path(r['command'][2]) for r in prior['measurements']}
libs={'baseline':frozen/'baseline.so','shared':frozen/'liboriole_expat.so','split':root/'split.so','outlined':root/'outlined.so'}
reference=Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so');driver=frozen/'benchmark/driver';ctor=root/'constructor-driver'
files=[Path(__file__),driver,ctor,root/'constructor_driver.c',*inputs.values(),*libs.values(),reference,Path('/home/dev-user/code/oss/oriole/tools/xml_abi.py'),Path('/home/dev-user/code/oss/oriole/benchmarks/projects.py')]
hashes={str(p):sha(p) for p in files}
report={'status':'incomplete','hashes':hashes,'affinity':sorted(os.sched_getaffinity(0)),'method':'Seven randomized paired native process cohorts. Same frozen complete-parser driver, all callback preflights and per-sample metadata checked. Constructor-only runs each time200000create/free pairs after1000warmups, without parse/handler/timer-per-iteration work. Shared host and compiler layout effects remain.','preflight':[],'rows':[]}
try:
 engines={name:Expat(str(lib)) for name,lib in {**libs,'reference':reference}.items()};gold={}
 for name,p in inputs.items():
  for ns in [False,True]:
   observed={engine:e.parse(p.read_bytes(),65536,ns) for engine,e in engines.items()};ref=observed['reference'];assert all(r['status']==1 and r['error']==0 and not r['callback_errors'] and r['normalized_events']==ref['normalized_events'] for r in observed.values())
   with gzip.open(out/f'preflight-{name}-{ns}.json.gz','wt') as f:json.dump(observed,f)
   gold[name,ns]=tuple(native_output(ref['normalized_events']));report['preflight'].append({'input':name,'namespaces':ns,'expected':gold[name,ns]})
 rng=random.Random(20260911);jobs=[(name,ns,pair) for name in [*inputs,'constructor'] for ns in [False,True] for pair in range(7)];rng.shuffle(jobs)
 for name,ns,pair in jobs:
  order=list(libs);rng.shuffle(order)
  for engine in order:
   if name=='constructor':cmd=[str(ctor),str(libs[engine]),'namespaces' if ns else 'raw']
   else:cmd=[str(driver),str(libs[engine]),str(inputs[name]),'65536',str(2000 if name in ['empty','attributes','text'] else 30)]+(['namespaces'] if ns else [])
   r=subprocess.run(cmd,capture_output=True,text=True,timeout=30);filename=f'{name}-{ns}-{pair}-{engine}.json.gz'
   with gzip.open(out/filename,'wt') as f:f.write(r.stdout)
   (out/(filename+'.stderr')).write_text(r.stderr)
   assert r.returncode==0,(cmd,r.returncode,r.stderr);data=json.loads(r.stdout)
   if name=='constructor':assert data['iterations']==200000;seconds=data['seconds']/data['iterations']
   else:
    assert all(tuple(s[k] for k in ['hash','elements','text_bytes'])==gold[name,ns] for s in data['samples']);seconds=statistics.median(s['seconds'] for s in data['samples'] if not s['warmup'])
   report['rows'].append({'input':name,'namespaces':ns,'pair':pair,'engine':engine,'command':cmd,'seconds':seconds,'output':filename})
 report['summary']=[]
 for name in [*inputs,'constructor']:
  for ns in [False,True]:
   pairs=[{r['engine']:r['seconds'] for r in report['rows'] if r['input']==name and r['namespaces']==ns and r['pair']==pair} for pair in range(7)]
   report['summary'].append({'input':name,'namespaces':ns,'relative_to_baseline':{engine:statistics.median(p[engine]/p['baseline'] for p in pairs) for engine in libs},'outlined_over_shared':statistics.median(p['outlined']/p['shared'] for p in pairs)})
 assert all(sha(Path(p))==s for p,s in hashes.items());report['status']='passed'
finally:(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report.get('summary'),indent=2))
