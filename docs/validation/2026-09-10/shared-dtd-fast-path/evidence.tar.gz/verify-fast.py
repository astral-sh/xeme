from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,time
root=Path('/tmp/oriole-shared-dtd-tiny-profile');out=root/'validation';out.mkdir(exist_ok=True)
old=Path('/tmp/oriole-shared-dtd-implementation');candidate=root/'split.so'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((old/'source.json').read_text());source=Path('/tmp/oriole-shared-dtd-fast')
files={p:sha(source/p) for p in base['files']};changed=[p for p,h in files.items() if h!=base['files'][p]];assert changed==['crates/oriole/src/lib.rs'],changed
(root/'source.json').write_text(json.dumps({'parent_manifest_sha256':sha(old/'source.json'),'parent_library_sha256':sha(old/'liboriole_expat.so'),'patch_sha256':sha(root/'fast.patch'),'files':files},indent=2)+'\n')
py='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12';prefix=['taskset','-c','6',py,'-I','-S',str(old/'run_clean.py')]
commands=[]
def run(name,args):
 cmd=prefix+list(map(str,args));start=time.time()
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 commands.append({'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.time()-start,'log_sha256':sha(out/(name+'.log'))})
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');return r.returncode
p=(old/'publication-release.py').read_text().replace("'baseline':'/tmp/oriole-shared-dtd-implementation/liboriole_expat.so'",f"'baseline':'{candidate}'").replace("out=Path('/tmp/oriole-shared-dtd-implementation')",f"out=Path('{out}')")
(out/'publication.py').write_text(p);assert run('publication',[out/'publication.py'])==0
before=json.loads((old/'observations.json').read_text());after=json.loads((out/'observations.json').read_text());assert before['observations']==after['observations']
assert run('doctype',[old/'doctype.py',candidate,out/'doctype.json.gz'])==0
assert json.loads(gzip.decompress((out/'doctype.json.gz').read_bytes()))['differences']==0
p=(old/'custom-provenance.py').read_text().replace("out=Path('/tmp/oriole-shared-dtd-implementation')",f"out=Path('{out}')").replace("str(out/'baseline.so')",f"'{old/'liboriole_expat.so'}'").replace("str(out/'liboriole_expat.so')",f"'{candidate}'")
(out/'custom-provenance.py').write_text(p);assert run('custom-provenance',[out/'custom-provenance.py'])==0
rc=run('upstream',[old/'upstream-runner/run.py','--source','/home/dev-user/.cache/oriole/upstream/expat-2.8.4','--config','/home/dev-user/.cache/oriole/expat-build/expat_config.h','--library',candidate,'--output',out/'upstream-api'])
u=json.loads((out/'upstream-api/results.json').read_text());b=json.loads((old/'upstream-api/results.json').read_text());assert len(u['results'])==4740 and u['library_origin_verified'] and not u['timed_out'];assert u['results']==b['results'];assert rc==u['returncode']
assert all(sha(source/p)==h for p,h in files.items());assert sha(candidate)=='a9bb484b0b1469a7d767151fa15b59e471eceb9295a13d52abb8a23c5d769c6a'
summary={'status':'passed','publication_cases':after['cases'],'publication_changed':0,'publication_reference_differences':after['differences'],'doctype_cases':4104,'doctype_reference_differences':0,'custom_provenance':{k:v for k,v in json.loads(gzip.decompress((out/'custom-provenance.json.gz').read_bytes())).items() if k not in ['templates','differences']},'upstream':{k:v for k,v in u.items() if k not in ['results','excluded_internal_tests']},'upstream_changed':0}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
