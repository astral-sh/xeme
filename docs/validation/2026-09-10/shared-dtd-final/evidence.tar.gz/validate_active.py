from pathlib import Path
import subprocess,json,concurrent.futures,time
w=Path('/tmp/oriole-dtd-fast-integrated');a=w/'active-oracles';py='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
def run(name):
 cmd=['taskset','-c','3,4',py,'-I','-S',str(a/(name+'.py')),str(w/'liboriole_expat.so'),str(a/(name+'.json'))];start=time.time()
 with (a/(name+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.time()-start};print(json.dumps(row),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,['oracle','doctype','missing','siblings','general']))
(a/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(r['exit_code']==0 for r in rows)
