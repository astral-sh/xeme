# Share parameter-family declaration skip state

Patch `candidate.patch`, SHA-256 `f7d42234f8df1354e567a3ff2e22433e6f8eafa5d61670b45467598838448297`.
Apply after the name-mode and direct missing-PE patches listed in source.json, based on33154ffaaf890f8d97144226d685d80551b37417. Apply-check against that exact previous frozen source passes.
Frozen debug library SHA-256 `e45340d0485de7384cbeb02aa46797200a60f4dcd956011a517aa6e89f0beaa1`.

## Behavior and design

- Existing `parameter_read: Option<Shared<AtomicBool>>` becomes inline `OnceLock<Shared<ParameterState>>`, where ParameterState contains read and declaration-skip atomic flags. The inline local skip value remains usable before sharing.
- State initializes fallibly before returning the first parameter child, including manually precreated siblings. Existing external-DTD/value request sites reuse this same lazy allocation. Ordinary Parser construction and ordinary internal-only XML do not allocate it.
- Allocation occurs outside OnceLock's initialization lock; only the complete selected-allocator Shared is installed. Concurrent losers drop their selected allocation and use the winning state. Conservative work charging counts each attempted payload allocation.
- Parameter descendants share the state immediately, including before a child's final input. General-content children copy the current skip value into independent local/lazy state, matching Expat dtdCopy's keepProcessing snapshot; they do not share later mutations. Reset starts fresh; outstanding children own their old state.
- All declaration processing checks and mutations consult this shared state. Metadata work is charged for both flags; absolute limits remain unchanged.

## Validation

-254 Rust checks pass: previous250 plus3 private state/ownership/accounting tests and1 C sibling/reset lifecycle test. The C test exercises all four precreated/nonfinal sibling combinations and an old parameter child surviving parent reset. Strict Clippy/fmt pass.
-The selected-allocator OOM workload uses fresh parents for independent DTD fixtures. Previously it implicitly depended on siblings having copied skip state; separate new tests assert intentional sibling sharing. The exact resource-boundary fixture now budgets two atomic flags rather than one.
-Four sibling oracle conditions now match Expat in status, text, declarations and skipped callbacks; previously3 differed. Two general-child creation-order probes match Expat's independent snapshot behavior; previously the after-skip copy was incorrect. Source evidence: pinned Expat xmlparse.c6077–6135 and dtdCopy7852–7870.
-1,944 missing-PE conditions retain zero acceptance differences. The remaining24 child-execution/162 event differences are unchanged, pre-existing external-subset NotStandalone timing and partial rejected-input callbacks. No claim of full callback equality outside the six focused family probes.
-Selected120-configuration upstream rerun is recorded in upstream-api/ and final status in validation.json.

## Root integration notes

1. Retain root's boxed EventKind payloads; the two new core unit-test EntityDeclaration patterns use this older base's struct form and need the root's tuple pattern.
2. Retain Shared/AtomicBool imports in dtd.rs if root's sticky entity-value flag implementation still uses them; this patch removes them only because the pre-sticky base no longer does.
3. Preserve name-mode and custom alias raw lexical validation already integrated by root; this patch only replaces shared DTD state plumbing.
4. Existing value-state `read` ownership now refers to ParameterState, with its `.read` atomic serving exactly the previous marker role.
5. source.tar.gz preserves the entire isolated source. No shared root files were edited.

Rerun siblings.py with candidate .so and explicit JSON output path; general_snapshot.py has the same arguments. Use clean uv Python (system Python preloads another Expat). Existing missing-PE oracle accepts candidate .so and output JSON path. CPU0 remained reserved for root.
