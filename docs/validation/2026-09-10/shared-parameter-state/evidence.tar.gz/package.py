from pathlib import Path
import gzip,hashlib,io,json,tarfile
source=Path('/tmp/oriole-shared-final');repo=Path('/home/dev-user/code/oss/oriole-api-followup');out=repo/'docs/validation/2026-09-10/shared-parameter-state';out.mkdir(parents=True,exist_ok=True);original=Path('/tmp/oriole-shared-parameter-state');baseline=Path('/tmp/oriole-missing-final/upstream-complete');sha=lambda b:hashlib.sha256(b).hexdigest();entries={}
for p in sorted(source.rglob('*')):
 if p.is_file() and not p.is_symlink() and p.suffix in ['.json','.log','.py','.patch','.rej','.c','.h']:entries[str(p.relative_to(source))]=p.read_bytes()
for name in ['HANDOFF.md','candidate.patch','source.json','validation.json','missing-final.json','siblings-final.json','general-final.json','siblings.py','general_snapshot.py']:entries['original-candidate/'+name]=(original/name).read_bytes()
for name in ['results.json','manifest.json','tests.log']:entries['baseline-upstream/'+name]=(baseline/name).read_bytes()
entries['oracle-support.py']=Path('/tmp/oriole-missing-parameter/oracle.py').read_bytes();entries['independent-review.json']=Path('/tmp/oriole-shared-state-independent-review.json').read_bytes()
freeze=json.loads((source/'source.json').read_text())
for name,digest in freeze.items():
 data=(repo/name).read_bytes();assert sha(data)==digest;entries['frozen-source/'+name]=data
review=json.loads(entries['independent-review.json']);assert all(freeze[k]==v for k,v in review['source_sha256'].items())
files=[{'path':p,'bytes':len(v),'sha256':sha(v)} for p,v in sorted(entries.items())];(out/'files.json').write_text(json.dumps(files,indent=2)+'\n')
with (out/'evidence.tar.gz').open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
a=json.loads((baseline/'results.json').read_text());b=json.loads((source/'upstream-complete/results.json').read_text());am=json.loads((baseline/'manifest.json').read_text());bm=json.loads((source/'upstream-complete/manifest.json').read_text());assert a['results']==b['results'] and am['adapted_sources']==bm['adapted_sources']
o=json.loads((source/'oracle.json').read_text());assert o['differences']==json.loads(Path('/tmp/oriole-missing-final/oracle.json').read_text())['differences'];native=json.loads((source/'native/report.json').read_text());assert native['status']=='passed'
family={}
for name in ['siblings','general']:
 new=json.loads((source/(name+'.json')).read_text());old=json.loads((source/(name+'-baseline.json')).read_text());assert all(x['results']['candidate']==x['results']['reference'] for x in new);family[name]={'cases':len(new),'baseline_differences':sum(x['results']['candidate']!=x['results']['reference'] for x in old),'candidate_differences':0}
standalone=json.loads((source/'standalone-oracle.json').read_text());assert standalone['candidate_differences']==standalone['baseline_differences']==0
ordinary=json.loads((source/'differential/summary.json').read_text());assert ordinary['exact_pass'] and ordinary['cases']==3918
report={'source_commit':'d7686d2d0692b9163625905c62d758692b87abd8','base_commit':'57e613c','shared_sha256':sha((source/'liboriole_expat.so').read_bytes()),'static_sha256':sha((source/'liboriole_expat.a').read_bytes()),'checks':{'rust_tests':283,'strict_clippy':'passed','native_suites':6,'allocation_scenarios_per_linkage':333,'native_scope':native['scope'],'ordinary_exact_differential_cases':3918},'upstream':{'before':{'passed':a['passed'],'failed':a['failed']},'after':{'passed':b['passed'],'failed':b['failed']},'changes':[],'identical_adapted_sources':True},'missing_oracle':o['counts'],'missing_oracle_disposition':'All remaining 24 child-execution and 162 event differences are identical to direct missing-PE baseline.','family_oracles':family,'standalone_creation_oracle':{'cases':27,'baseline_differences':0,'candidate_differences':0,'scope':'Parent standalone absent/yes/no, precreated/read-before/created-after child, independently selected parent and child PE processing modes; valid setter returns asserted.'},'independent_review':review,'limits':'Both shared flags are charged before the first lazy allocation. Limits remain unchanged; selected-allocator OOM and lazy ordinary-path tests pass.','separate_work':'Iterative attribute expansion and attribute replacement semantics are not included.','artifacts':{'files':len(files),'archive_sha256':sha((out/'evidence.tar.gz').read_bytes())}}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(len(files),'files',len((out/'evidence.tar.gz').read_bytes()),'archive bytes')
