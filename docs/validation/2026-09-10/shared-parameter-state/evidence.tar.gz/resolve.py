from pathlib import Path
import shutil

def edit(name,pairs):
 p=Path(name);s=p.read_text()
 for old,new,count in pairs:
  assert s.count(old)==count,(name,old,s.count(old),count);s=s.replace(old,new)
 p.write_text(s)
edit('crates/oriole/src/lib.rs',[
 ('#[derive(Debug)]\nstruct PendingEvent {','/// Flags shared by the DTD and its external parameter children. General-content\n/// children have independent DTD state even though byte budgets remain shared.\n#[derive(Debug)]\nstruct ParameterState {\n    read: AtomicBool,\n    declarations_skipped: AtomicBool,\n}\n\n#[derive(Debug)]\nstruct PendingEvent {',1),
 ('matches!(event.kind, EventKind::EntityDeclaration { .. })','matches!(event.kind, EventKind::EntityDeclaration(_))',2),
])
edit('crates/oriole/src/dtd.rs',[
 ('use oriole_storage::{Allocator, Shared, String, TryClone, Vec, try_insert, try_push};', 'use oriole_storage::{Allocator, String, TryClone, Vec, try_insert, try_push};',1),
 ('use std::sync::atomic::{AtomicBool, Ordering};','use std::sync::atomic::Ordering;',1),
 ('self.declarations_skipped = !self.standalone;', 'self.set_declarations_skipped(!self.standalone);',1),
 ('self.declarations_skipped |= !self.standalone;', 'self.set_declarations_skipped(self.declarations_skipped() || !self.standalone);',1),
 ('&& self.declarations_skipped\n','&& self.declarations_skipped()\n',2),
 ('            if self.parameter_read.is_none() {\n                self.charge_expansion(size_of::<AtomicBool>())?;\n                self.parameter_read =\n                    Some(Shared::try_new_in(AtomicBool::new(false), self.allocator)?);\n            }\n            self.parameter_read\n                .as_ref()\n                .expect("parameter read marker")\n                .store(false, Ordering::Relaxed);','            self.shared_parameter_state()?;\n            self.parameter_state\n                .get()\n                .expect("parameter read marker")\n                .read\n                .store(false, Ordering::Relaxed);',1),
])
edit('crates/oriole/src/dtd/composition.rs',[
 ('self.declarations_skipped |= !self.standalone;', 'self.set_declarations_skipped(self.declarations_skipped() || !self.standalone);',1),
])
edit('crates/oriole/src/value.rs',[
 ('state.read.store(false, Ordering::Relaxed);','state.read.read.store(false, Ordering::Relaxed);',1),
 ('self.declarations_skipped = skipped;','self.set_declarations_skipped(skipped);',1),
])
for p in Path('crates').rglob('*.rej'):
 target=Path('/tmp/oriole-shared-final/rejects')/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);p.unlink()
print('resolved runtime conflicts; preserved sticky value_open helpers and boxed events; removed obsolete read-marker imports')
