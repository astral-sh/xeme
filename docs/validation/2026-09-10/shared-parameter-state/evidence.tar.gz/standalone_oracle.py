import runpy,sys,json,hashlib
from pathlib import Path
m=runpy.run_path('/tmp/oriole-missing-parameter/oracle.py');setup=m['setup'];ENTITY=m['ENTITY'];TEXT=m['TEXT']
def run(lib,declaration,created_before,read_before,mode):
 events=[]
 @ENTITY
 def entity(_,name,param,value,n,base,system,public,notation):events.append(['entity',name.decode()])
 @TEXT
 def text(_,data,n):events.append(['text',m['c'].string_at(data,n).decode()])
 def parse(p,raw,final):return [lib.XML_Parse(p,raw,len(raw),final),lib.XML_GetErrorCode(p)]
 parent=lib.XML_ParserCreate(None);assert parent;assert lib.XML_SetParamEntityParsing(parent,mode)==1;lib.XML_SetEntityDeclHandler(parent,entity);lib.XML_SetCharacterDataHandler(parent,text)
 def create_child():
  p=lib.XML_ExternalEntityParserCreate(parent,None,None);assert p;assert lib.XML_SetParamEntityParsing(p,2)==1;return p
 child=create_child() if created_before else None
 results=[]
 if child and read_before:results.append(['early-child',*parse(child,b'%missing;',1)])
 if declaration:results.append(['prefix',*parse(parent,declaration,0)])
 if child is None:child=create_child()
 if not read_before:results.append(['child',*parse(child,b'%missing;',1)])
 results.append(['root',*parse(parent,b"<!DOCTYPE r [%again;<!ENTITY later 'L'>]><r>&later;</r>",1)])
 lib.XML_ParserFree(child);lib.XML_ParserFree(parent);return {'results':results,'events':events}
paths={'reference':'/home/dev-user/.cache/oriole/expat-build/libexpat.so','baseline':'/tmp/oriole-missing-final/liboriole_expat.so','candidate':sys.argv[1]};libs={k:setup(v) for k,v in paths.items()};rows=[]
for declaration in [b'',b"<?xml version='1.0' standalone='yes'?>",b"<?xml version='1.0' standalone='no'?>"]:
 for created_before,read_before in [(True,True),(True,False),(False,False)]:
  for mode in [0,1,2]:rows.append({'declaration_hex':declaration.hex(),'child_created_before':created_before,'child_read_before':read_before,'mode':mode,'results':{k:run(v,declaration,created_before,read_before,mode) for k,v in libs.items()}})
report={'libraries':{k:{'path':v,'sha256':hashlib.sha256(Path(v).read_bytes()).hexdigest()} for k,v in paths.items()},'rows':rows,'cases':len(rows),'baseline_differences':sum(x['results']['reference']!=x['results']['baseline'] for x in rows),'candidate_differences':sum(x['results']['reference']!=x['results']['candidate'] for x in rows)}
Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ['libraries','rows']})
