from pathlib import Path
import hashlib,json,subprocess,statistics
root=Path('/home/dev-user/code/oss/oriole-start-frame-integration')
study=Path('/tmp/oriole-start-frame-integration-study')
sha=lambda data:hashlib.sha256(data).hexdigest()
s=json.loads((study/'source.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='50c20c1e73eeaacabb9df90e413f502361fb45b3'
for p,v in s['source_sha256'].items():
 assert sha((root/p).read_bytes())==v
 assert sha(subprocess.check_output(['git','show',head+':'+p],cwd=root))==v
report={'runtime_commit':head,'parent':subprocess.check_output(['git','rev-parse','HEAD^'],cwd=root,text=True).strip(),'frozen_build_base':s['base'],'source_files':len(s['source_sha256']),'source_manifest_sha256':sha((study/'source.json').read_bytes()),'all_git_and_live_bytes_match_measured_source':True,'doc_only_parent_advance':'503a559 -> 382891b; all source bytes unchanged before runtime commit'}
Path('/tmp/oriole-start-frame-integration-assembly.json').write_text(json.dumps(report,indent=2)+'\n')
n=json.loads(Path('/tmp/oriole-start-frame-integration-timing-study/native-screen/results.json').read_text())
labels={'vulkan':'Vulkan registry','wayland':'Wayland protocol','maven':'Maven POM','batik':'Batik SVG','gtk':'GTK UI','docbook':'DocBook XSL'}
lines=[]
for name,label in labels.items():
 row=next(r for r in n['summary'] if r['condition']['name']==name and r['condition']['chunk']==4096 and not r['condition']['namespaces'])
 cond=row['condition']; samples=[r for r in n['rows'] if r['condition']==cond]
 times={e:statistics.median(next(p['median_seconds'] for p in r['processes'] if p['engine']==e) for r in samples)*1000 for e in ['candidate','expat']}
 lines.append(f"| {label} | {times['candidate']:.3f} ms | {times['expat']:.3f} ms | {row['median_ratios']['candidate_over_expat']:.2f}× |")
Path('/tmp/oriole-start-frame-integration-table.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(report));print('\n'.join(lines))
