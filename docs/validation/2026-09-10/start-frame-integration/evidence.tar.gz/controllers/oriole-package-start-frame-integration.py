"""Archive the selected and isolated literal start-frame measurements."""
from pathlib import Path
import hashlib,io,json,shutil,tarfile
repo=Path('/home/dev-user/code/oss/oriole-start-frame-integration')
out=repo/'docs/validation/2026-09-10/start-frame-integration'
directories={
 'integrated/source-build':'/tmp/oriole-start-frame-integration-study',
 'integrated/gates':'/tmp/oriole-start-frame-integration-gates-handoff',
 'integrated/cpython':'/tmp/oriole-start-frame-integration-cpython-gates',
 'integrated/native':'/tmp/oriole-start-frame-integration-timing-study',
 'integrated/python':'/tmp/oriole-start-frame-integration-python-study',
 'source-composition-review':'/tmp/oriole-start-frame-source-independent-review',
 'isolated/source-gates-profiles-handoff':'/tmp/oriole-start-frame-lowering-handoff',
 'isolated/native':'/tmp/oriole-start-frame-lowering-timing-study',
 'isolated/python':'/tmp/oriole-start-frame-lowering-python-study',
 'isolated/cpython':'/tmp/oriole-start-frame-lowering-cpython-gates',
 'isolated/reviews':'/tmp/oriole-start-frame-lowering-review-handoff',
}
controllers=[
 '/tmp/oriole-package-start-frame-integration.py','/tmp/oriole-summarize-cohorts.py',
 '/tmp/oriole-start-frame-integration-components.json','/tmp/oriole-start-frame-integration-assembly.json',
 '/tmp/oriole-assemble-start-frame-integration.py','/tmp/oriole-build-start-frame-integration.py',
 '/tmp/oriole-prepare-start-frame-integration-controllers.py',
 '/tmp/oriole-prepare-start-frame-integration-timing.py','/tmp/oriole-time-start-frame-integration-native.py',
 '/tmp/oriole-prepare-start-frame-integration-python.py','/tmp/oriole-time-start-frame-integration-python.py',
 '/tmp/oriole-start-frame-integration-cpython-gates.py',
 '/tmp/oriole-prepare-start-frame-lowering-timing.py','/tmp/oriole-time-start-frame-lowering-native.py',
 '/tmp/oriole-prepare-start-frame-lowering-python.py','/tmp/oriole-time-start-frame-lowering-python.py',
 '/tmp/oriole-start-frame-lowering-cpython-gates.py',
]
copies={
 'source.json':'/tmp/oriole-start-frame-integration-study/source.json',
 'assembly.json':'/tmp/oriole-start-frame-integration-assembly.json',
 'components.json':'/tmp/oriole-start-frame-integration-components.json',
 'gates.json':'/tmp/oriole-start-frame-integration-gates/summary.json',
 'workspace-counts.json':'/tmp/oriole-start-frame-integration-gates/workspace-checks/counts.json',
 'native-summary.json':'/tmp/oriole-start-frame-integration-timing-study/summary.json',
 'python-summary.json':'/tmp/oriole-start-frame-integration-python-study/summary.json',
 'source-review.json':'/tmp/oriole-start-frame-source-independent-review/review.json',
}
sha=lambda data:hashlib.sha256(data).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
assert load('/tmp/oriole-start-frame-integration-study/build.json')['status']=='passed'
gates=load(copies['gates.json'])
assert gates['status']=='correctness_parity_gates_passed'
assert gates['workspace']=={'tests':398,'doc-tests':1}
assert gates['api']['all4740rows_exact'] and (gates['api']['passed'],gates['api']['failed'])==(4347,393)
for kind in ['timing','python']:
 assert load('/tmp/oriole-start-frame-integration-'+kind+'-study/timing-controller.json')['status']=='passed'
source=load(copies['source.json'])
assert all(sha((repo/p).read_bytes())==v for p,v in source['source_sha256'].items())
for p in [*controllers,*copies.values()]:assert Path(p).is_file(),p
paths={}
for prefix,p in directories.items():
 directory=Path(p);assert directory.is_dir(),directory
 for path in sorted(directory.rglob('*')):
  if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts:
   paths[prefix+'/'+str(path.relative_to(directory))]=path
for p in controllers:paths['controllers/'+Path(p).name]=Path(p)
out.mkdir(parents=True,exist_ok=False)
members=[];excluded=[]
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=9) as archive:
 for name,p in sorted(paths.items()):
  data=p.read_bytes();entry={'path':name,'source':str(p),'bytes':len(data),'sha256':sha(data)}
  if data.startswith(b'\x7fELF') or data.startswith(b'!<arch>\n'):
   excluded.append(entry);continue
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
  archive.addfile(info,io.BytesIO(data));members.append(entry)
with tarfile.open(out/'evidence.tar.gz','r:gz') as archive:
 actual=archive.getmembers();assert len(actual)==len(members)
 for member,entry in zip(actual,members):
  assert member.isfile() and member.name==entry['path'] and member.size==entry['bytes']
  assert sha(archive.extractfile(member).read())==entry['sha256']==sha(Path(entry['source']).read_bytes())
for entry in excluded:assert sha(Path(entry['source']).read_bytes())==entry['sha256']
(out/'archive-members.json').write_text(json.dumps({'members':members,'excluded_binaries':excluded},indent=2)+'\n')
for name,p in copies.items():shutil.copy2(p,out/name)
summary={
 'runtime_commit':'50c20c1e73eeaacabb9df90e413f502361fb45b3',
 'source_files':70,'source_manifest_sha256':sha((out/'source.json').read_bytes()),
 'libraries':load('/tmp/oriole-start-frame-integration-study/build.json')['libraries'],
 'workspace':{'all_targets':398,'doc_tests':1,'fmt_and_strict_clippy':'passed'},
 'api':{'passed':4347,'failed':393,'original_configurations':4740,'canonical_bounds_verified':True},
 'cpython_each_linkage':{'tests':802,'failures':2,'skips':14,'expected_failures':3},
 'native':load(out/'native-summary.json'),'python':load(out/'python-summary.json'),
 'archive':{'sha256':sha((out/'evidence.tar.gz').read_bytes()),'members':len(members),'excluded_binaries':len(excluded),'raw_bytes':sum(x['bytes'] for x in members),'bytes':(out/'evidence.tar.gz').stat().st_size,'all_members_and_origins_readback_verified':True},
 'scope':'Selected9815 source assembled as50c20 above doc-only382891 parent. Selected controldd16; isolatedc435 control3694. Exact isolated3-file patch applied to matching-end runtime. All conditions and isolated regression retained. Complete standalone source/build/gates/profiles/first compile failure are nested in its sealed handoff. Later selected aggregate and final-documentation reviews are separate outer receipts. No LTO or PGO setting changes in these measurements.'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive'],indent=2),flush=True)
