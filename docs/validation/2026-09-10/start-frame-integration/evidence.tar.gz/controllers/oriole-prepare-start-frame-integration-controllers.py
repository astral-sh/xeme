from pathlib import Path
import json
import hashlib
import shutil
oldroot='/tmp/oriole-start-frame-lowering'
newroot='/tmp/oriole-start-frame-integration'
oldhash='c43531f783087c7b7b532ec34e2160144a98ceeeb5dc9c9cccfa23352c667ac9'
newhash='9815cc852327d455c094b0fb72c1d33fb90a4571e67cf15965e96e2300376828'
for suffix in ['-study/liboriole_expat.so']:
 assert hashlib.sha256(Path(newroot+suffix).read_bytes()).hexdigest()==newhash
# Build the new preflight from the immediately preceding frozen controller, so source changes are paths and descriptive labels only.
out=Path('/tmp/oriole-prepare-start-frame-integration-timing.py')
before=Path('/tmp/oriole-prepare-start-frame-lowering-timing.py').read_text()
start=before.index("old = Path(")
end=before.index('assert new != old',start)
replacement="""old = Path('/tmp/oriole-start-frame-lowering-timing-study/native_screen.py').read_text()
new = old.replace('/tmp/oriole-start-frame-lowering-timing-study', str(out)).replace('/tmp/oriole-start-frame-lowering-study/liboriole_expat.so', str(study / 'liboriole_expat.so')).replace('/tmp/oriole-scanner-integration-study/liboriole_expat.so', '/tmp/oriole-end-tag-integration-study/liboriole_expat.so')
new = new.replace('published64a270e/3694b683', 'published503a559/dd16d23e').replace('dedicated literal start-frame lowering', 'integrated literal start-frame lowering').replace('literal start-frame lowering/c43531f7 candidate', 'integrated literal start-frame lowering/9815cc85 candidate')
"""
after=before[:start]+replacement+before[end:]
# Outside the replacement block, switch study assertions and output only.
pre=after[:start].replace('start-frame-lowering','start-frame-integration').replace(oldhash,newhash).replace('/tmp/oriole-scanner-integration-study/liboriole_expat.so','/tmp/oriole-end-tag-integration-study/liboriole_expat.so').replace('3694b68326939778481e42e810f53facc2ebcb8b8ad75b599704dbfef8f37926','dd16d23e4ab67938c195970bd845b2a159d7f062beda265bb673c85b79f73fc6')
post=after[start+len(replacement):].replace('published64a270e/3694','published503a559/dd16').replace('reviewed-coalesced-native','reviewed-standalone-start-frame-native').replace('integrated-scanner-native','integrated-start-frame-native')
out.write_text(pre+replacement+post)
for kind in ['native','python']:
 p=Path('/tmp/oriole-time-start-frame-lowering-'+kind+'.py')
 Path(str(p).replace('lowering','integration')).write_text(p.read_text().replace('start-frame-lowering','start-frame-integration'))
p=Path('/tmp/oriole-start-frame-lowering-cpython-gates.py')
Path(str(p).replace('lowering','integration')).write_text(p.read_text().replace('start-frame-lowering','start-frame-integration').replace(oldhash,newhash).replace('31f54d91a3f9c312c7d08d1e3142fc020452c4b6a76819e1a216c7a8a4e0092f','92eafd42ffe68dc30db920ff5ff8d67357b2c6c4273f51b0e3e841b2bfb9ea69'))
p=Path('/tmp/oriole-prepare-start-frame-lowering-python.py')
t=p.read_text().replace("out = Path('/tmp/oriole-start-frame-lowering-python-study')", "out = Path('/tmp/oriole-start-frame-integration-python-study')").replace("old = Path('/tmp/oriole-scanner-integration-python-study')", "old = Path('/tmp/oriole-start-frame-lowering-python-study')")
t=t.replace("before.replace('published193e1278/50580931', 'published64a270e/3694b683').replace('integrated position words and String hints/3694b683 candidate', 'literal start-frame lowering/c43531f7 candidate')", "before.replace('published64a270e/3694b683', 'published503a559/dd16d23e').replace('literal start-frame lowering/c43531f7 candidate', 'integrated literal start-frame lowering/9815cc85 candidate')")
t=t.replace('/tmp/oriole-start-frame-lowering-study/liboriole_expat.so','/tmp/oriole-start-frame-integration-study/liboriole_expat.so').replace('/tmp/oriole-scanner-integration-study/liboriole_expat.so','/tmp/oriole-end-tag-integration-study/liboriole_expat.so').replace('/home/dev-user/code/oss/oriole-start-frame-lowering/include','/home/dev-user/code/oss/oriole-start-frame-integration/include')
t=t.replace('position-words-screen','integrated-start-frame-screen')
Path(str(p).replace('lowering','integration')).write_text(t)
p=Path('/tmp/oriole-child-initialization-root-review/review.json')
shutil.copy2(p,p.with_name('review-initial-wording.json'))
t=p.read_text().replace('recycling-generation allocation sequence','recycling-generation initialization sequence').replace('reducing peak live memory and changing free/reserve timing','potentially reducing transient peak live memory and changing free/reserve timing; the measured small constructor probes retain the same overall peak')
p.write_text(t)
for p in [out,Path('/tmp/oriole-prepare-start-frame-integration-python.py'),Path('/tmp/oriole-start-frame-integration-cpython-gates.py')]:
 compile(p.read_text(),str(p),'exec')
 print(p)
