import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

out = Path('/tmp/oriole-start-frame-lowering-timing-study')
out.mkdir(exist_ok=False)
study = Path('/tmp/oriole-start-frame-lowering-study')
source = json.loads((study / 'source.json').read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert all(digest(Path(source['worktree']) / name) == value for name, value in source['source_sha256'].items())
assert json.loads((study / 'build.json').read_text())['status'] == 'passed'
assert digest(study / 'liboriole_expat.so') == 'c43531f783087c7b7b532ec34e2160144a98ceeeb5dc9c9cccfa23352c667ac9'
assert digest(Path('/tmp/oriole-scanner-integration-study/liboriole_expat.so')) == '3694b68326939778481e42e810f53facc2ebcb8b8ad75b599704dbfef8f37926'
old = Path('/tmp/oriole-scanner-integration-timing-study/native_screen.py').read_text()
new = old.replace('/tmp/oriole-scanner-integration-timing-study', str(out)).replace('/tmp/oriole-scanner-integration-study/liboriole_expat.so', str(study / 'liboriole_expat.so')).replace('/tmp/oriole-coalesced-search-study/liboriole_expat.so', '/tmp/oriole-scanner-integration-study/liboriole_expat.so')
new = new.replace('published193e1278/50580931', 'published64a270e/3694b683').replace('integrated position words and String inline hints', 'dedicated literal start-frame lowering').replace('integrated position words and String hints/3694b683 candidate', 'literal start-frame lowering/c43531f7 candidate')
assert new != old
(out / 'native_screen.py').write_text(new)
(out / 'controller.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='reviewed-coalesced-native', tofile='integrated-scanner-native')))
report = {'status': 'incomplete', 'source_files': len(source['source_sha256']), 'source_manifest_sha256': digest(study / 'source.json'),
          'scope': 'Same original28 conditions,84 preflights,588 timed workers and seven fixed shuffled cohorts. Fresh isolated build, focused adapter/name/allocator/grammar/FFI tests and coreClippy pass. Independent source review passes. Full gates continue independently; measurements compare against published64a270e/3694 and do not alone constitute adoption.'}
command = ['taskset', '-c', '3', 'python3', str(out / 'native_screen.py'), 'preflight']
with (out / 'preflight-controller.log').open('wb') as log:
    run = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
report.update(command=command, exit=run.returncode, status='passed' if run.returncode == 0 else 'failed')
(out / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copy2(__file__, out / Path(__file__).name)
print(json.dumps(report), flush=True)
raise SystemExit(run.returncode)
