from pathlib import Path
import json,statistics,sys
r=Path(sys.argv[1]);kind=sys.argv[2]
x=json.loads((r/('native-screen' if kind=='native' else 'screen')/'results.json').read_text())
assert x['status']=='passed';assert len(x['summary'])==(28 if kind=='native' else 24)
s={'scope':'All fixed conditions and samples; geometric means of per-condition paired median time ratios. Shared host.','groups':{},'regressions':[]}
for group in (['real','generated'] if kind=='native' else ['all','elementtree','pyexpat-events']):
 rows=[a for a in x['summary'] if (a['condition']['name'].startswith('generated-')==(group=='generated') if kind=='native' else group=='all' or a['condition']['mode']==group)]
 s['groups'][group]={'conditions':len(rows),'ratios':{}}
 for k in rows[0]['median_ratios']:
  vs=[a['median_ratios'][k] for a in rows];s['groups'][group]['ratios'][k]={'geomean':statistics.geometric_mean(vs),'below_one':sum(v<1 for v in vs)}
for a in x['summary']:
 if a['median_ratios']['candidate_over_published']>1:s['regressions'].append({'condition':a['condition'],'ratio':a['median_ratios']['candidate_over_published']})
(r/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s,indent=2))
