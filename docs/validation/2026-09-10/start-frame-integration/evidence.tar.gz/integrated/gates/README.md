# Start-frame integration correctness handoff

All requested gates passed on frozen `9815cc85` versus direct behavior control `dd16d23e`.

- Release workspace: 398 tests and one doc test; core remains 56, only adapter-frame inventory rises 7 to 8. Workspace Clippy with warnings denied and formatting pass.
- Canonical API: all 4,740 rows equal both the retained original reference and direct control; 4,347 pass and 393 preexisting failures remain with unchanged bounds.
- Six dynamic/static C sanitizer consumers pass, including 327 allocation scenarios per linkage.
- Strict 3,318, custom-alias 36,456, malformed 2,392, and publication 1,304 cases / 3,912 parses match direct control.
- Retained End38/6: all 38 complete lifecycle records and six selected OOM scenarios match control; unchanged retries and zero live allocations. Saved-data readback passes 852 checks across 149 hashed files.
- All 70 source files, three source archives, patch, libraries, and prepared controllers remain frozen. No source edits, commits, pushes, timings, or gate reruns by this worker.

`completion.json` joins the original and supplemental reports, also collected in `summary.json`. `/tmp/oriole-start-frame-integration-gates-handoff` contains the compressed evidence, member hashes, excluded binary hashes and full member readback; outer files are read-only. Standalone source/gates/profiles and first failed compile are separately sealed in `/tmp/oriole-start-frame-lowering-handoff`.

This establishes behavior parity within retained gates. The 393 canonical failures and existing Expat callback-position differences remain. C consumers have ASan/UBSan; the release Rust libraries are uninstrumented and leak checking is disabled. Parent owns elapsed/CPython studies, independent composition review, and adoption.
