"""Create a compact frozen handoff from completed saved integration records."""
from pathlib import Path
import hashlib
import gzip
import io
import json
import os
import shutil
import subprocess
import tarfile

assert __debug__ and os.sched_getaffinity(0) == {2}
root = Path('/tmp/oriole-start-frame-integration-gates')
study = Path('/tmp/oriole-start-frame-integration-study')
control = Path('/tmp/oriole-end-tag-integration-gates')
worktree = Path('/home/dev-user/code/oss/oriole-start-frame-integration')
out = Path('/tmp/oriole-start-frame-integration-gates-handoff')
out.mkdir(exist_ok=False)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

summary = read(root / 'summary.json')
assert summary['status'] == 'correctness_parity_gates_passed'
source = read(root / 'source.json')
assert source == read(study / 'source.json')
assert len(source['source_sha256']) == 70
assert all(sha(worktree / p) == h for p, h in source['source_sha256'].items())
for path in [root / 'source.tar.gz', study / 'source.tar.gz', root / 'workspace-checks/source.tar.gz']:
    with tarfile.open(path, 'r:gz') as tar:
        archived = {m.name: hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar if m.isfile()}
    assert archived == source['source_sha256']
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=worktree)
assert patch == (root / 'candidate.patch').read_bytes() == (study / 'candidate.patch').read_bytes()
current_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip()
subprocess.run(['git', 'merge-base', '--is-ancestor', source['base'], current_head], cwd=worktree, check=True)
parent_documentation_paths = subprocess.check_output(['git', 'diff', '--name-only', source['base'], current_head], cwd=worktree, text=True).splitlines()
assert not set(parent_documentation_paths).intersection(source['source_sha256'])
assert all(p == 'README.md' or p.startswith(('docs/', 'benchmarks/')) for p in parent_documentation_paths)
components_path = Path('/tmp/oriole-start-frame-integration-components.json')
prep = read(root / 'preparation.json')
assert sha(components_path) == prep['composition_components']['sha256']
components = read(components_path)
assert components['matching_end_tag_helper_retained'] is True
for name, expected in prep['controllers'].items():
    assert sha(root / name) == expected
for name, expected in prep['libraries'].items():
    assert sha(study / name) == expected
assert sha(prep['direct_control']['path']) == prep['direct_control']['sha256']

candidate_api = root / 'api-native/upstream-api'
control_api = control / 'api-native/upstream-api'
a, b = read(candidate_api / 'results.json'), read(control_api / 'results.json')
assert len(a['results']) == len(b['results']) == 4740
assert {(r['test'], r['context']): r for r in a['results']} == {(r['test'], r['context']): r for r in b['results']}
assert (a['passed'], a['failed']) == (b['passed'], b['failed']) == (4347, 393)
norm = lambda m, p: {k: [v.replace(str(p), '<OUTPUT>') for v in value] if k == 'compile_command' else value
                    for k, value in m.items() if k not in ['library_sha256', 'binary_sha256']}
assert norm(read(candidate_api / 'manifest.json'), candidate_api) == norm(read(control_api / 'manifest.json'), control_api)
direct_api = {'all4740rows_exact': True, 'candidate_results_sha256': sha(candidate_api / 'results.json'),
              'control_results': str(control_api / 'results.json'), 'control_results_sha256': sha(control_api / 'results.json'),
              'same_manifest_after_only_library_binary_output_path_normalization': True,
              'passed': 4347, 'preexisting_failures': 393}
(root / 'direct-api-comparison.json').write_text(json.dumps(direct_api, indent=2) + '\n')

lifecycle = read(root / 'end-lifecycle/review.json')
oom = read(root / 'end-oom-final/review.json')
assert lifecycle['status'] == oom['status'] == 'passed'
assert lifecycle['lifecycle']['logical_cases'] == 38 and lifecycle['lifecycle']['candidate_control_different_cases'] == 0
assert oom['logical_scenarios_per_engine'] == 6 and oom['byte_exact_candidate_control']
assert lifecycle['source_files_before_after'] == 70
assert lifecycle['no_repeated_or_discarded_new_runs']
assert lifecycle['oom_review_sha256'] == sha(root / 'end-oom-final/review.json')
counts = read(root / 'workspace-checks/counts.json')
assert counts['all_target_passed'] == 398 and counts['doc_passed'] == 1
assert counts['changes'] == [{'baseline': {'target': 'adapter_frame', 'passed': 7, 'failed': 0, 'ignored': 0},
                            'candidate': {'target': 'adapter_frame', 'passed': 8, 'failed': 0, 'ignored': 0}}]
assert next(r for r in counts['all_target_rows'] if r['target'] == 'oriole')['passed'] == 56

shutil.copyfile(root / 'summary.json', root / 'original-gate-summary.json')
summary.update(direct_api=direct_api, end_lifecycle=lifecycle['lifecycle'], end_oom=oom,
               supplemental_readback={'checks': lifecycle['passed_checks'], 'hashed_files': lifecycle['checked_file_count'],
                                      'review_sha256': sha(root / 'end-lifecycle/review.json')},
               original_gate_summary_sha256=sha(root / 'original-gate-summary.json'))
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')

completion = {
    'status': 'passed', 'base': source['base'], 'current_head': current_head,
    'parent_documentation_advance': {'paths': parent_documentation_paths, 'no_frozen_source_files_changed': True,
                                    'authorization': 'Parent reported its documentation-only FF through 382891b during gates; no runtime/Cargo changes.'},
    'scope': 'Original canonical/API/native/strict/custom/malformed/publication/workspace gates and unchanged End38/6 supplemental on frozen combined start-frame integration. No source edits, integration commit, push, elapsed timing, or gate reruns by this worker.',
    'source': {'files': 70, 'live_and_three_archives_exact': True,
               'manifest_sha256': sha(root / 'source.json'), 'patch_sha256': hashlib.sha256(patch).hexdigest(),
               'components_sha256': sha(components_path)},
    'libraries': summary['libraries'], 'original_gate_summary_sha256': sha(root / 'original-gate-summary.json'),
    'combined_summary_sha256': sha(root / 'summary.json'),
    'workspace': {'all_targets': 398, 'docs': 1, 'core': 56, 'only_inventory_change': 'adapter_frame 7 to 8',
                  'release_workspace_clippy': 'passed', 'format': 'passed'},
    'direct_api': direct_api,
    'native': summary['native'], 'strict_traces_exact': 3318, 'custom_alias_comparisons_exact': 36456,
    'malformed_comparisons_exact': 2392, 'publication_cases_exact': 1304, 'publication_parses': 3912,
    'end_lifecycle': {'cases': 38, 'parser_executions': 114, 'candidate_control_differences': 0,
                      'review_sha256': sha(root / 'end-lifecycle/review.json')},
    'end_oom': {'scenarios_per_engine': 6, 'parser_executions': 12, 'selected_failures': 4,
                'success_controls': 2, 'byte_exact_candidate_control': True, 'all_zero_live': True,
                'unchanged_terminal_retries': True, 'review_sha256': sha(root / 'end-oom-final/review.json')},
    'supplemental_readback': {'checks': lifecycle['passed_checks'], 'hashed_files': lifecycle['checked_file_count']},
    'standalone_handoff': {'directory': '/tmp/oriole-start-frame-lowering-handoff',
                          'receipt_sha256': sha('/tmp/oriole-start-frame-lowering-handoff/receipt.json')},
    'cpus_released_after_completion': [2, 4],
    'limits': ['393 preexisting canonical API failures remain; this establishes parity, not complete Expat conformance.',
               'Original reference callback-position differences remain recorded and classified.',
               'C ASan/UBSan consumers were instrumented; release Rust libraries were uninstrumented and leak checking disabled.',
               'Parent owns elapsed screens, strict CPython, independent composition review, and adoption.'],
}
(root / 'completion.json').write_text(json.dumps(completion, indent=2) + '\n')
(root / 'README.md').write_text('''# Start-frame integration correctness handoff

All requested gates passed on frozen `9815cc85` versus direct behavior control `dd16d23e`.

- Release workspace: 398 tests and one doc test; core remains 56, only adapter-frame inventory rises 7 to 8. Workspace Clippy with warnings denied and formatting pass.
- Canonical API: all 4,740 rows equal both the retained original reference and direct control; 4,347 pass and 393 preexisting failures remain with unchanged bounds.
- Six dynamic/static C sanitizer consumers pass, including 327 allocation scenarios per linkage.
- Strict 3,318, custom-alias 36,456, malformed 2,392, and publication 1,304 cases / 3,912 parses match direct control.
- Retained End38/6: all 38 complete lifecycle records and six selected OOM scenarios match control; unchanged retries and zero live allocations. Saved-data readback passes 852 checks across 149 hashed files.
- All 70 source files, three source archives, patch, libraries, and prepared controllers remain frozen. No source edits, commits, pushes, timings, or gate reruns by this worker.

`completion.json` joins the original and supplemental reports, also collected in `summary.json`. `/tmp/oriole-start-frame-integration-gates-handoff` contains the compressed evidence, member hashes, excluded binary hashes and full member readback; outer files are read-only. Standalone source/gates/profiles and first failed compile are separately sealed in `/tmp/oriole-start-frame-lowering-handoff`.

This establishes behavior parity within retained gates. The 393 canonical failures and existing Expat callback-position differences remain. C consumers have ASan/UBSan; the release Rust libraries are uninstrumented and leak checking is disabled. Parent owns elapsed/CPython studies, independent composition review, and adoption.
''')
build_evidence = root / 'build-evidence'
build_evidence.mkdir()
for name in ['release.log', 'focused.log', 'clippy.log', 'fmt-write.log', 'oriole-build-start-frame-integration.py']:
    shutil.copyfile(study / name, build_evidence / name)
shutil.copyfile(components_path, root / 'components.json')
entries, excluded = [], []
for path in sorted(root.rglob('*')):
    if not path.is_file():
        continue
    assert not path.is_symlink()
    row = {'path': path.relative_to(root).as_posix(), 'origin': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
    with path.open('rb') as f:
        magic = f.read(8)
    (excluded if magic.startswith((b'\x7fELF', b'!<arch>\n')) else entries).append(row)
archive = out / 'evidence.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w|') as tar:
            for row in entries:
                info = tarfile.TarInfo(row['path'])
                info.size, info.mode, info.mtime = row['bytes'], 0o644, 0
                with Path(row['origin']).open('rb') as f:
                    tar.addfile(info, f)
(out / 'archive-members.json').write_text(json.dumps(entries, indent=2) + '\n')
(out / 'excluded-binaries.json').write_text(json.dumps(excluded, indent=2) + '\n')
shutil.copyfile(root / 'summary.json', out / 'summary.json')
shutil.copyfile(root / 'README.md', out / 'README.md')
shutil.copyfile(__file__, out / 'package.py')
expected = {r['path']: r for r in entries}
nested = []
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(entries) == len({m.name for m in members})
    for member in members:
        assert member.isfile()
        data = tar.extractfile(member).read()
        row = expected[member.name]
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'] == sha(row['origin'])
        if member.name in ['source.tar.gz', 'workspace-checks/source.tar.gz']:
            with tarfile.open(fileobj=io.BytesIO(data)) as source_tar:
                hashes = {m.name: hashlib.sha256(source_tar.extractfile(m).read()).hexdigest() for m in source_tar if m.isfile()}
            assert hashes == source['source_sha256']
            nested.append({'archive': member.name, 'members': len(hashes), 'hashes_match_frozen_source': True})
assert all(sha(row['origin']) == row['sha256'] for row in entries + excluded)
readback = {'status': 'full_member_and_origin_readback_passed', 'archive_sha256': sha(archive), 'members': len(entries),
            'uncompressed_bytes': sum(row['bytes'] for row in entries), 'excluded_binaries': len(excluded),
            'nested_source_archives': nested, 'live_source_unchanged': all(sha(worktree / p) == h for p, h in source['source_sha256'].items())}
(out / 'readback.json').write_text(json.dumps(readback, indent=2) + '\n')
files = {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()}
manifest = {'status': 'complete_gate_handoff', 'files': files, 'source_manifest_sha256': sha(root / 'source.json'),
            'source_files': 70, 'candidate_libraries': prep['libraries'], 'direct_control': prep['direct_control'],
            'archive_members': len(entries), 'excluded_binaries': len(excluded), 'completion_sha256': sha(root / 'completion.json')}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
assert all(sha(out / name) == row['sha256'] and (out / name).stat().st_size == row['bytes'] for name, row in files.items())
for path in out.iterdir():
    path.chmod(0o444)
print(json.dumps({'path': str(out), 'manifest_sha256': sha(out / 'manifest.json'), 'archive_sha256': sha(archive),
                  'archive_bytes': archive.stat().st_size, 'members': len(entries), 'excluded_binaries': len(excluded),
                  'summary_sha256': sha(root / 'summary.json'), 'completion_sha256': sha(root / 'completion.json'),
                  'readback': readback}, indent=2))
