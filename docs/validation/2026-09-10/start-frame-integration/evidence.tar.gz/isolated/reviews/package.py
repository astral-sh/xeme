"""Seal independent standalone-start reviews; keep combined source-only scope separate."""
from pathlib import Path
import gzip,hashlib,io,json,shutil,tarfile

out=Path('/tmp/oriole-start-frame-lowering-review-handoff')
roots={n:Path('/tmp/oriole-start-frame-lowering-'+n+'-independent-review')for n in ['native','python','cpython','gate']}
roots['source-composition']=Path('/tmp/oriole-start-frame-source-independent-review')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_bytes())
native=load(roots['native']/'review.json');py=load(roots['python']/'review.json');cpp=load(roots['cpython']/'review.json');gate=load(roots['gate']/'review.json');workspace=load(roots['gate']/'workspace-review.json');source=load(roots['source-composition']/'review.json')
assert native['regressions']==[] and len(py['regressions'])==1
out.mkdir(exist_ok=False)
entries=[]
for label,r in roots.items():
    for p in sorted(r.rglob('*')):
        if p.is_file():entries.append({'path':label+'/'+p.relative_to(r).as_posix(),'origin':str(p),'sha256':h(p),'bytes':p.stat().st_size})
with (out/'reviews.tar.gz').open('wb')as f:
    with gzip.GzipFile(fileobj=f,mode='wb',mtime=0)as gz:
        with tarfile.open(fileobj=gz,mode='w')as archive:
            for row in entries:
                data=Path(row['origin']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
                info=tarfile.TarInfo(row['path']);info.size=len(data);info.mode=0o644
                archive.addfile(info,io.BytesIO(data))
with tarfile.open(out/'reviews.tar.gz')as archive:
    members=archive.getmembers();assert len(members)==len(entries)
    for m,row in zip(members,entries,strict=True):
        assert m.isfile()and m.name==row['path']and m.size==row['bytes']
        assert hashlib.sha256(archive.extractfile(m).read()).hexdigest()==row['sha256']==h(row['origin'])
(out/'archive-members.json').write_text(json.dumps(entries,indent=2)+'\n')
summary={
    'status':'independent_standalone_reviews_passed',
    'scope':'Saved standalone c435/31f source, original gates, native/Python samples and strict CPython outcomes versus3694. No reviewer parser/build/timing reruns. Combined9815/92ea composition and compiler mapping are reviewed separately here as source-only evidence; its runtime gates and timings are not claimed by this package.',
    'source_files_each':70,'standalone_libraries':source['standalone_libraries'],'combined_libraries_source_only':source['combined_libraries'],
    'native_groups':native['groups'],'python_groups':py['groups'],'strict_cpython':cpp['cpython'],
    'counts':{'native':native['counts'],'python':{'preflights':py['preflights'],'timed_workers':py['timed_workers'],'cohorts':py['cohorts'],'samples':py['sample_counts']}},
    'regressions':{'native':native['regressions'],'python':py['regressions']},
    'gate_review':gate,'workspace_review':workspace,
    'composition':'Exact standalone three-file patch reconstructs c435 on71bf/3694 and9815 on503a/dd16. Original matching-end patch independently commutes after c435 to yield9815. All four70-file source/archive/live maps and three full workspace compiler invocations each verified. Normalized command vectors match each direct control.',
    'limitations':['All conditions retained. Shared-host point estimates do not establish full-project or production performance.','Standalone Python has one DocBook4KiB ElementTree regression. Overall candidate remains slower than Expat.','Original393 API and two strict CPython grouping failures remain; no full-green consumer claim.','C sanitizer checks instrument the C consumers, with LSan disabled and normal Rust release libraries. Successful custom-alias raw records are not all archived; original executed zero-difference reports remain scoped.','Python GC stays enabled and canonical text joins do not prove exact callback grouping. Native identity uses explicit handle loading; strict fresh-import routing is separate.','Raw protocols label the3694 direct control published; combined9815 has its own503a/dd16 control and requires its own gates and measured comparisons.'],
    'reviews':{label:{'path':str(r/'review.json'),'sha256':h(r/'review.json')}for label,r in roots.items()},
    'workspace_review_sha256':h(roots['gate']/'workspace-review.json'),
    'readback':{'members':len(entries),'all_stored_and_origin_bytes_rehashed':True},
}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copyfile(__file__,out/'package.py')
files={p.name:{'sha256':h(p),'bytes':p.stat().st_size}for p in sorted(out.iterdir())if p.is_file()}
(out/'manifest.json').write_text(json.dumps({'status':'complete','files':files},indent=2)+'\n')
for n,row in files.items():assert h(out/n)==row['sha256']
print(json.dumps({'path':str(out),'manifest_sha256':h(out/'manifest.json'),'archive_sha256':h(out/'reviews.tar.gz'),'archive_bytes':(out/'reviews.tar.gz').stat().st_size,'members':len(entries),'outer_files':len(files)+1}))
