"""Saved source/build/composition audit; no compiler or parser executions."""
from pathlib import Path
import hashlib, json, re, shlex, subprocess, tarfile, tempfile

OUT=Path(__file__).resolve().parent
ROOT=Path('/home/dev-user/code/oss/oriole-end-tag-integration')
sources={
    'standalone_control':Path('/tmp/oriole-scanner-integration-study'),
    'standalone':Path('/tmp/oriole-start-frame-lowering-study'),
    'combined_control':Path('/tmp/oriole-end-tag-integration-study'),
    'combined':Path('/tmp/oriole-start-frame-integration-study'),
}
hashes={};checks=[]
def read(p):
    p=Path(p);b=p.read_bytes();hashes[str(p)]=hashlib.sha256(b).hexdigest();return b
def sha(p):read(p);return hashes[str(Path(p))]
def load(p):return json.loads(read(p))
def check(x,label):
    if not x:raise AssertionError(label)
    checks.append(label)
maps={};contents={};builds={};normalized={}
for label,directory in sources.items():
    source=load(directory/'source.json');mapping=source['source_sha256'];maps[label]=mapping
    check(len(mapping)==70,label+' source70')
    with tarfile.open(directory/'source.tar.gz')as archive:
        files={m.name:archive.extractfile(m).read()for m in archive if m.isfile()}
    check({n:hashlib.sha256(b).hexdigest()for n,b in files.items()}==mapping,label+' archive complete source map')
    sha(directory/'source.tar.gz');contents[label]=files
    for n,h in mapping.items():check(sha(Path(source['worktree'])/n)==h,label+' live source '+n)
    build=load(directory/'build.json');builds[label]=build
    check(build['status']=='passed' and build['source_manifest_sha256']==sha(directory/'source.json'),label+' build receipt')
    for n,h in build['libraries'].items():check(sha(directory/n)==h,label+' binary '+n)
    env=build['env_overrides']
    for name,value in {'CARGO_INCREMENTAL':'0','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','RUSTFLAGS':'','CARGO_ENCODED_RUSTFLAGS':''}.items():check(env[name]==value,label+' environment '+name)
    check(env['CARGO_BUILD_BUILD_DIR']=='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}',label+' isolated intermediate template')
    inv=load(directory/'compiler-invocations.json');log=read(directory/'release.log').decode()
    check(inv==[x for x in log.splitlines()if 'Running' in x and '/rustc 'in x],label+' exact compiler receipt')
    normalized[label]={}
    for name in ['oriole_storage','oriole','oriole_expat']:
        rows=[x for x in inv if '--crate-name '+name+' 'in x];check(len(rows)==1,label+' one fresh compiler '+name)
        items=shlex.split(rows[0].strip()[len('Running `'):-1]);ri=next(i for i,x in enumerate(items)if x.endswith('/bin/rustc'))
        vars=dict(x.split('=',1)for x in items[:ri]);args=items[ri:]
        check(vars['CARGO_MANIFEST_DIR']==str(Path(source['worktree'])/'crates'/name),label+' manifest directory '+name)
        check(any(x.startswith('--emit=dep-info')and 'link'in x for x in args),label+' full code emission '+name)
        normalized[label][name]=[re.sub(r'/home/dev-user/.cache/ohm/verified-build/[^/]+/[^/]+','<BUILD>',x)for x in args]
    for job in build['commands']:
        check(job['exit']==0,label+' '+job['name']+' exit')
        check(sha(directory/(job['name']+'.log'))==job['log_sha256'],label+' '+job['name']+' log')
        check(job['command'][:3]==['cargo','+ohm','-Zohm-defaults=no'],label+' Ohm defaults disabled '+job['name'])

check(normalized['standalone_control']==normalized['standalone'],'standalone complete rustc args equal3694 after private path normalization')
check(normalized['combined_control']==normalized['combined'],'combined complete rustc args equaldd16 after private path normalization')
check(len({b['env_overrides']['CARGO_TARGET_DIR']for b in builds.values()})==4,'four distinct targets')
changes=['crates/oriole/src/lib.rs','crates/oriole/tests/adapter_frame.rs','crates/oriole/tests/allocation.rs']
patch=sources['standalone']/'candidate.patch';patch_sha=sha(patch)
check(patch_sha=='7e4681e5c068543f02a4d7eff961718d4e216cb57cc189348b75dcffa15808fb','frozen isolated patch identity')
component=load('/tmp/oriole-start-frame-integration-components.json')
check(component['base']=='503a55957f7cdebcc0b3fb3ada2751ffdb8cb9c9'and component['patch_sha256']==patch_sha and component['changed_files']==changes,'root composition receipt')
for before,after in [('standalone_control','standalone'),('combined_control','combined')]:
    check([n for n in maps[after]if maps[before][n]!=maps[after][n]]==changes,after+' exactly3 changed files')
    with tempfile.TemporaryDirectory(dir=OUT)as temp:
        for n in changes:
            target=Path(temp)/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(contents[before][n])
        process=subprocess.run(['git','apply',str(patch)],cwd=temp,capture_output=True)
        check(process.returncode==0,after+' exact standalone patch applied to reviewer temporary files: '+process.stderr.decode())
        for n in changes:check(hashlib.sha256((Path(temp)/n).read_bytes()).hexdigest()==maps[after][n],after+' reconstructed '+n)
# Prove only the previously accepted matching-end change separates the two candidates.
check([n for n in maps['standalone']if maps['standalone'][n]!=maps['combined'][n]]==['crates/oriole/src/lib.rs'],'combined versus standalone only corelib')
with tempfile.TemporaryDirectory(dir=OUT)as temp:
    p=Path(temp)/'crates/oriole/src/lib.rs';p.parent.mkdir(parents=True);p.write_bytes(contents['standalone']['crates/oriole/src/lib.rs'])
    original=Path('/tmp/oriole-matching-end-tags-study/candidate.patch');sha(original)
    process=subprocess.run(['git','apply',str(original)],cwd=temp,capture_output=True)
    check(process.returncode==0,'independently commute original closing-tag patch after standalone start helper')
    check(hashlib.sha256(p.read_bytes()).hexdigest()==maps['combined']['crates/oriole/src/lib.rs'],'matching-end + start-frame composition commutes byte-exact')
for label,commit in [('standalone_control','71bf6bc2aabc9e57d0be914919ca6ed2e600c4eb'),('combined_control','503a55957f7cdebcc0b3fb3ada2751ffdb8cb9c9')]:
    for n in maps[label]:
        b=subprocess.check_output(['git','-C',str(ROOT),'show',commit+':'+n])
        check(hashlib.sha256(b).hexdigest()==maps[label][n],label+' Git base '+n)
prior=load('/tmp/oriole-start-frame-lowering-root-review/review.json')
check(prior['source_manifest_sha256']==sha(sources['standalone']/'source.json')and prior['libraries']==builds['standalone']['libraries'],'root review matches exact standalone source/libraries')
result={
    'status':'source_composition_and_matched_compiler_review_passed',
    'scope':'Read-only source and stored build-command audit; exact patches applied only to temporary reviewer files. No compiler/parser/test/timing executions.',
    'source_files_each':70,'standalone_base':'71bf6bc doc-only over64a270e/3694','combined_base':'503a559/dd16',
    'standalone_libraries':builds['standalone']['libraries'],'combined_libraries':builds['combined']['libraries'],
    'changed_files':changes,'patch_sha256':patch_sha,'fresh_workspace_compiles_each':3,
    'full_normalized_rustc_arguments_equal_each_direct_control':True,'composition_commutes_with_matching_end_patch':True,
    'findings':[],
    'invariants':[
        'Dedicated frame path retains complete literal plan,4KiB/128-attribute eligibility and namespace-identity guards. Root/depth errors precede dispatch. No declaration/default-enabled, converted, fragment or entity path is newly eligible.',
        'Complete plan already validates NameRules and literal values. Colon-free names in namespace identity mode are valid QNames; the generic path retains all alias decoding, QName checks, defaults and namespace work.',
        'Attribute limit precedes frame reserve/prepare. Duplicate checks retain per-attribute ordering and the8/9 threshold with randomized hashing. Every insertion precedes value-before-name fallible frame copy.',
        'id_attribute_index clearing, frame name copy, seen-root/declaration flags, recycled raw-name copy, stack push, optional End work, success-only attribute cache return and Start publication preserve the old order.',
        'Empty elements attach the same empty raw override and publish the Start frame only after fallible End work. No parser borrow escapes into callback data; existing owned arena/generation/reset/clear behavior is unchanged.',
        'Outer accounting/token append/raw publication/source consumption and all FFI dispatch code are unchanged. Matching-end helper and bypass are independently reproduced byte-for-byte in composition.',
        'One new adapter semantic test covers8/9 attributes, duplicate tail, colon names and Fourth/Fifth Edition chunk/namespace cases. Existing selected-allocation workload only gains two nine-attribute tags; original assertions remain.'
    ],
    'limits':['Source equivalence and saved compiler invocation matching do not replace composed runtime gates. Standalone and combined measurements must remain distinct.','Historic compiler executable hash is not independently reconstructed; full recorded compiler paths/args, Cargo environment and fresh emissions are matched.','Prior failed draft test compile and withdrawn unsupported frame-count assumption remain in owner evidence and are not runtime failures.'],
    'normalized_compiler_commands':normalized,'passed_checks':len(checks),'evidence_sha256':hashes,
    'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(sha(OUT/'review.json'))
