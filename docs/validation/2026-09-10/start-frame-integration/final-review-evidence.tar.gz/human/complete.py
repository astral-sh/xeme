"""Seal references to the independently completed human and package audits."""
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
package = Path('/tmp/oriole-start-frame-docs-package-independent-review')
paths = [out/'review.json', out/'final-update-review.json', package/'review.json', package/'final-index-review.json']
rows = []
for path in paths:
    data = path.read_bytes()
    report = json.loads(data)
    assert not report.get('findings'), str(path)
    rows.append({'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
report = {
    'status': 'final_human_and_package_audits_passed',
    'runtime_commit': '50c20c1e73eeaacabb9df90e413f502361fb45b3',
    'final_outer_files': 18,
    'final_outer_index_sha256': '1c2cc0712055b5f845af222c89fb519657b93d0303362b69840b7c9cf2ec576d',
    'main_archive_sha256': '5b3f33a1c08befe2e1b45a214003ba3962694846a0015430cc5d428c91e05217',
    'main_archive_members': 4949,
    'direct_binary_exclusions': 32,
    'reviews': rows,
    'findings': [],
    'scope': 'Saved-data/source/docs review only. No compiler, parser, test-suite, fuzz or timing reruns. README headings/warning/license, figures, scoped remaining failures, links and current index checked. Main archive/origins, nested receipts, source snapshots and all review receipt copies independently read back. Native binaries retained in the nested standalone handoff are now explicitly distinguished from direct exclusions.',
    'generator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(out/'complete.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'path': str(out/'complete.json'), 'sha256': hashlib.sha256((out/'complete.json').read_bytes()).hexdigest()}))
