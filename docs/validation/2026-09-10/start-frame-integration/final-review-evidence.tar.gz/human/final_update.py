"""Recheck the narrow packaging wording update after the full human audit."""
import difflib
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
REPO = Path('/home/dev-user/code/oss/oriole-start-frame-integration')
DOC = REPO / 'docs/validation/2026-09-10/start-frame-integration'

def sha(data):
    return hashlib.sha256(data).hexdigest()

original = json.loads((OUT / 'review.json').read_text())
before_map = json.loads((OUT / 'checked-files.json').read_text())
changed = {}
after_map = {}
generator = DOC / 'oriole-write-start-frame-integration-docs.py'
allowed = {str(DOC / 'README.md'), str(DOC / 'files.json'), str(generator)}
for name, before in before_map.items():
    data = Path(name).read_bytes()
    after = {'bytes': len(data), 'sha256': sha(data)}
    after_map[name] = after
    if after != before:
        assert name in allowed, name
        changed[name] = {'before': before, 'after': after}
assert set(changed) == allowed

old = (OUT / 'documents/docs/validation/2026-09-10/start-frame-integration/README.md').read_text()
new = (DOC / 'README.md').read_text()
old_segment = '[evidence.tar.gz](evidence.tar.gz) contains 4,949 regular members, with 32 compiled\nbinaries excluded and hashed. Its SHA-256 is\n'
new_segment = '[evidence.tar.gz](evidence.tar.gz) contains 4,949 regular members. Its 32 direct\ncompiled artifacts are excluded and hashed; original native binaries remain in\nthe nested standalone handoff. Its SHA-256 is\n'
assert old_segment in old
assert old.replace(old_segment, new_segment) == new
new_generator = generator.read_text()
assert new_segment in new_generator
assert sha(new_generator.replace(new_segment, old_segment).encode()) == before_map[str(generator)]['sha256']
index_data = (DOC / 'files.json').read_bytes()
index = json.loads(index_data)['files']
assert len(index) == 18
assert {str(p.relative_to(DOC)) for p in DOC.rglob('*') if p.is_file() and p.name != 'files.json'} == {r['path'] for r in index}
for row in index:
    data = (DOC / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
assert (DOC / 'files.json').read_bytes() == index_data
(OUT / 'final-documents').mkdir(exist_ok=True)
(OUT / 'final-documents/README.md').write_text(new)
(OUT / 'final-documents/files.json').write_bytes(index_data)
(OUT / 'final-wording.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='audited README', tofile='final README')))
(OUT / 'final-checked-files.json').write_text(json.dumps(after_map, indent=2, sort_keys=True) + '\n')
report = {
    'status': 'final_human_document_update_passed',
    'scope': 'Read-only narrow follow-up after the full human audit; no parser, compiler or timing runs.',
    'original_review_sha256': sha((OUT / 'review.json').read_bytes()),
    'changes': changed,
    'final_outer_files': len(index),
    'final_outer_index_sha256': sha(index_data),
    'statement': 'Only README archive wording, the identical prose in its retained generator, and the index changed; the new sentence distinguishes 32 directly excluded binaries from binaries retained in the nested standalone handoff. All previous numeric, compatibility, source, warning/license, link and sample findings remain applicable.',
    'reviewer_attempt': 'Initial follow-up assertion omitted the announced indexed documentation generator. Initial script/failure receipt retained separately; not a parser or documentation failure.',
    'all_other_observed_files_unchanged': len(after_map) - len(changed),
    'findings': [],
    'generator_sha256': sha(Path(__file__).read_bytes()),
}
(OUT / 'final-update-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'sha256': sha((OUT / 'final-update-review.json').read_bytes())}))
