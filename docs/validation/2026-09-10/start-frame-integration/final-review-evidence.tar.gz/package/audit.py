"""Read-only selected documentation package audit; no project code execution."""
from pathlib import Path,PurePosixPath
from collections import Counter
import ast,hashlib,io,json,os,tarfile

assert os.sched_getaffinity(0)=={6}
ROOT=Path('/home/dev-user/code/oss/oriole-start-frame-integration')
DOC=ROOT/'docs/validation/2026-09-10/start-frame-integration'
OUT=Path(__file__).resolve().parent
PACKAGE=Path('/tmp/oriole-package-start-frame-integration.py')
EXPECTED='5b3f33a1c08befe2e1b45a214003ba3962694846a0015430cc5d428c91e05217'
tracked={};checks=[]
def digest(raw):return hashlib.sha256(raw).hexdigest()
def read(p):
    p=Path(p);raw=p.read_bytes();value=digest(raw)
    assert tracked.setdefault(str(p),value)==value,('changed during audit',str(p))
    return raw
def h(p):read(p);return tracked[str(Path(p))]
def j(p):return json.loads(read(p))
def ck(value,label):assert value,label;checks.append(label)
def kind(raw):return 'ELF' if raw.startswith(b'\x7fELF') else 'ar' if raw.startswith(b'!<arch>\n') else None
def safe(name):return name==PurePosixPath(name).as_posix() and not name.startswith('/') and '..' not in PurePosixPath(name).parts
def source_snapshot(label,source_raw,archive_raw,build_raw):
    source=json.loads(source_raw);build=json.loads(build_raw)
    ck(len(source['source_sha256'])==70 and digest(source_raw)==build['source_manifest_sha256'] and build['status']=='passed' and build['source_unchanged'],label+' source build identity')
    with tarfile.open(fileobj=io.BytesIO(archive_raw),mode='r:gz') as archive:
        members=archive.getmembers()
        ck(len(members)==len({m.name for m in members})==70 and all(m.isfile() and safe(m.name) for m in members),label+' source70 archive membership')
        ck({m.name:digest(archive.extractfile(m).read()) for m in members}==source['source_sha256'],label+' archived source bytes')
    for name,value in source['source_sha256'].items():ck(h(Path(source['worktree'])/name)==value,label+' live source '+name)
    return {'study':label,'source_files':70,'manifest_sha256':digest(source_raw),'libraries':build['libraries'],'all_live_and_nested_archive_bytes_match':True}

constants={}
for node in ast.parse(read(PACKAGE)).body:
    if isinstance(node,ast.Assign):
        for target in node.targets:
            if isinstance(target,ast.Name) and target.id in ['directories','controllers','copies']:constants[target.id]=ast.literal_eval(node.value)
ck({key:len(value) for key,value in constants.items()}=={'directories':11,'controllers':17,'copies':8},'literal package selection counts')
selected={};skipped=[]
for prefix,location in constants['directories'].items():
    base=Path(location)
    for p in sorted(base.rglob('*')):
        if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:
            name=prefix+'/'+p.relative_to(base).as_posix();ck(name not in selected,'unique selected member');selected[name]=p
        elif p.is_symlink() or '__pycache__' in p.parts:skipped.append(str(p))
for location in constants['controllers']:
    name='controllers/'+Path(location).name;ck(name not in selected,'unique standalone controller');selected[name]=Path(location)
index=j(DOC/'archive-members.json');included=index['members'];excluded=index['excluded_binaries']
ck(len(included)==4949 and len(excluded)==32,'4949 members32 direct binary exclusions')
ck(len(selected)==len(included)+len(excluded)==len({r['path'] for r in included+excluded}),'complete disjoint selection')
ck({r['path']:r['source'] for r in included+excluded}=={name:str(p) for name,p in selected.items()},'exact generator selection reconstructed')
ck([r['path'] for r in included]==sorted(r['path'] for r in included) and [r['path'] for r in excluded]==sorted(r['path'] for r in excluded),'sorted member partitions')
archive_raw=read(DOC/'evidence.tar.gz');ck(digest(archive_raw)==EXPECTED,'requested archive SHA256')
keep={'integrated/source-build/source.json','integrated/source-build/source.tar.gz','integrated/source-build/build.json','isolated/source-gates-profiles-handoff/evidence.tar.gz','isolated/source-gates-profiles-handoff/index.json','isolated/source-gates-profiles-handoff/receipt.json'}
payloads={};groups=Counter()
with tarfile.open(fileobj=io.BytesIO(archive_raw),mode='r:gz') as archive:
    members=archive.getmembers();ck(len(members)==len({m.name for m in members})==4949,'all regular unique archived members')
    for member,row in zip(members,included,strict=True):
        ck(member.isfile() and safe(member.name) and member.name==row['path'] and member.size==row['bytes'] and member.mode==0o644 and member.mtime==0,'archive metadata '+member.name)
        raw=archive.extractfile(member).read();origin=Path(row['source'])
        ck(origin.is_file() and not origin.is_symlink() and digest(raw)==row['sha256'] and len(raw)==row['bytes'],'archive payload '+member.name)
        ck(read(origin)==raw and kind(raw) is None,'origin bytes and direct binary scope '+member.name)
        if member.name in keep:payloads[member.name]=raw
        groups['/'.join(member.name.split('/')[:2])]+=1
ck(set(payloads)==keep,'both study source evidence retained')
formats=Counter()
for row in excluded:
    raw=read(row['source']);k=kind(raw)
    ck(k is not None and digest(raw)==row['sha256'] and len(raw)==row['bytes'],'excluded binary '+row['path']);formats[k]+=1
integrated=source_snapshot('integrated',payloads['integrated/source-build/source.json'],payloads['integrated/source-build/source.tar.gz'],payloads['integrated/source-build/build.json'])
ck(integrated['libraries']=={'liboriole_expat.so':'9815cc852327d455c094b0fb72c1d33fb90a4571e67cf15965e96e2300376828','liboriole_expat.a':'92eafd42ffe68dc30db920ff5ff8d67357b2c6c4273f51b0e3e841b2bfb9ea69'},'integrated exact runtime hashes')

prefix='isolated/source-gates-profiles-handoff/'
nested_index=json.loads(payloads[prefix+'index.json']);receipt=json.loads(payloads[prefix+'receipt.json'])
ck(receipt['status']=='passed' and receipt['archive_sha256']==digest(payloads[prefix+'evidence.tar.gz']) and receipt['index_sha256']==digest(payloads[prefix+'index.json']),'nested standalone handoff receipt')
entries={row['archive_path']:row for row in nested_index['files']};nested_source={};initial_failed_compile=[]
with tarfile.open(fileobj=io.BytesIO(payloads[prefix+'evidence.tar.gz']),mode='r:gz') as archive:
    members=archive.getmembers();ck(len(members)==len({m.name for m in members})==receipt['archive_members_verified']==478 and len(entries)==receipt['snapshot_files']==477,'standalone478 members477 entries')
    for member in members:
        ck(member.isfile() and safe(member.name),'nested standalone regular safe member')
        raw=archive.extractfile(member).read()
        if member.name not in entries:
            ck(raw==payloads[prefix+'index.json'],'nested embedded exact index');continue
        row=entries[member.name]
        ck(len(raw)==row['bytes'] and digest(raw)==row['sha256'] and raw==read(row['path']),'nested standalone member origin identity '+member.name)
        if member.name in ['tmp/oriole-start-frame-lowering-study/source.json','tmp/oriole-start-frame-lowering-study/source.tar.gz','tmp/oriole-start-frame-lowering-study/build.json']:nested_source[Path(member.name).name]=raw
        if 'start-frame-lowering-study-attempt1-compile/' in member.name:initial_failed_compile.append(member.name)
ck(len(nested_source)==3 and initial_failed_compile,'standalone final source and historical compile attempt kept separate')
isolated=source_snapshot('isolated',nested_source['source.json'],nested_source['source.tar.gz'],nested_source['build.json'])
ck(isolated['libraries']=={'liboriole_expat.so':'c43531f783087c7b7b532ec34e2160144a98ceeeb5dc9c9cccfa23352c667ac9','liboriole_expat.a':'31f54d91a3f9c312c7d08d1e3142fc020452c4b6a76819e1a216c7a8a4e0092f'},'isolated exact runtime hashes')
copied=[]
for name,origin in constants['copies'].items():ck(read(DOC/name)==read(origin),'exact copied receipt '+name);copied.append({'path':name,'origin':origin,'sha256':h(DOC/name)})
summary=j(DOC/'summary.json');assembly=j(DOC/'assembly.json');gates=j(DOC/'gates.json')
ck(summary['runtime_commit']==assembly['runtime_commit']=='50c20c1e73eeaacabb9df90e413f502361fb45b3','selected runtime commit receipt linkage')
ck(summary['source_files']==assembly['source_files']==70 and summary['source_manifest_sha256']==assembly['source_manifest_sha256']==h(DOC/'source.json') and summary['libraries']==integrated['libraries'],'selected source build copied identities')
ck(gates['status']=='correctness_parity_gates_passed' and gates['workspace']=={'tests':398,'doc-tests':1} and gates['api']['passed']==4347 and gates['api']['failed']==393 and gates['api']['all4740rows_exact'],'copied gate receipt exact scope')
ck(summary['native']==j(DOC/'native-summary.json') and summary['python']==j(DOC/'python-summary.json'),'copied timing summaries match aggregate')
ck(summary['archive']=={'sha256':EXPECTED,'members':4949,'excluded_binaries':32,'raw_bytes':sum(r['bytes'] for r in included),'bytes':len(archive_raw),'all_members_and_origins_readback_verified':True},'archive size/count/hash summary reconstructed')
for name in ['native-summary.json','python-summary.json']:ck(read(ROOT/'benchmarks/results/2026-09-10/start-frame-integration'/name)==read(DOC/name),'benchmark copy '+name)
ck(all(digest(Path(p).read_bytes())==value for p,value in tracked.items()),'all inspected source/origin/package bytes unchanged')
(OUT/'checked-files.json').write_text(json.dumps(tracked,indent=2,sort_keys=True)+'\n')
report={'status':'independent_docs_core_package_audit_passed','scope':'Saved archive/origin/selection/copy/source audit; outer index and latest review receipt are a separate final supplement. No runtime, parser, build, benchmark or project-generator execution; no documentation changes.','cpu':6,'archive':{'sha256':EXPECTED,'members':4949,'raw_bytes':sum(r['bytes'] for r in included),'compressed_bytes':len(archive_raw),'all_member_origin_bytes_equal':True,'groups':dict(groups)},'excluded_binaries':{'count':32,'formats':dict(formats),'scope':'Direct archive members with ELF or ar magic; nested evidence may contain binaries.'},'selection':{'directories':11,'controllers':17,'standalone_copies':8,'skipped_cache_or_symlink_paths':skipped},'source_studies':[integrated,isolated],'nested_standalone_handoff':{'members':478,'indexed_origins':477,'all_member_origin_bytes_equal':True,'initial_failed_compile_member_paths':initial_failed_compile},'copied_receipts':copied,'limitations':['No historical gate re-execution. Human claims, links, numerical interpretation and current Git assembly are parent-owned.','Direct ELF/ar exclusions are a packaging boundary, not a general recursive binary policy. The retained standalone handoff contains its original native binaries and separate initial failed compile evidence.','Outer files.json and the later independent review receipt are checked in a separate final-index supplement.','Source70 from both final studies and all indexed standalone handoff members were rehashed. Historical unchanged bytes before recorded snapshots are not proven.'],'checks':len(checks),'checked_files':len(tracked),'generator_sha256':digest(Path(__file__).read_bytes()),'checked_files_sha256':h(OUT/'checked-files.json')}
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'files':len(tracked),'review_sha256':digest((OUT/'review.json').read_bytes())}))
