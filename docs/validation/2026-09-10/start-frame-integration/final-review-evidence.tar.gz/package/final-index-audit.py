"""Final18 outer index and copied independent review receipt, saved data only."""
from pathlib import Path,PurePosixPath
import hashlib,io,json,os,tarfile

assert os.sched_getaffinity(0)=={7}
OUT=Path(__file__).resolve().parent
DOC=Path('/home/dev-user/code/oss/oriole-start-frame-integration/docs/validation/2026-09-10/start-frame-integration')
RECEIPT=Path('/tmp/oriole-start-frame-integration-review-handoff')
tracked={};checks=[]
def digest(raw):return hashlib.sha256(raw).hexdigest()
def read(p):
    p=Path(p);raw=p.read_bytes();value=digest(raw)
    assert tracked.setdefault(str(p),value)==value,str(p)
    return raw
def h(p):read(p);return tracked[str(Path(p))]
def j(p):return json.loads(read(p))
def ck(value,label):assert value,label;checks.append(label)
def safe(name):return name==PurePosixPath(name).as_posix() and not name.startswith('/') and '..' not in PurePosixPath(name).parts
indexraw=read(DOC/'files.json');index=json.loads(indexraw)
(OUT/'final-index-observed.json').write_bytes(indexraw)
ck(len(index['files'])==len({r['path'] for r in index['files']})==18,'18 unique index entries')
ck([r['path'] for r in index['files']]==sorted(p.relative_to(DOC).as_posix() for p in DOC.rglob('*') if p.is_file() and p!=DOC/'files.json'),'index exact current outer coverage')
for row in index['files']:
    p=DOC/row['path'];ck(safe(row['path']) and p.is_file() and not p.is_symlink(),'safe regular indexed path')
    ck(h(p)==row['sha256'] and len(read(p))==row['bytes'],'indexed size and hash '+row['path'])
initial=j(OUT/'initial-index-observed.json');a={r['path']:r for r in initial['files']};b={r['path']:r for r in index['files']}
ck(len(a)==13 and set(a).issubset(b),'initial13 preserved before authorized refresh')
changes={'added':sorted(set(b)-set(a)),'changed_existing':[{'before':a[name],'after':b[name]} for name in a if a[name]!=b[name]],'removed':sorted(set(a)-set(b))}
ck(changes['added']==['independent-reviews/'+name for name in sorted(p.name for p in RECEIPT.iterdir() if p.is_file())] and len(changes['added'])==5 and not changes['removed'],'authorized five-file receipt addition')
for p in RECEIPT.iterdir():
    if p.is_file():ck(read(DOC/'independent-reviews'/p.name)==read(p),'exact copied review handoff file '+p.name)
manifest=j(RECEIPT/'manifest.json');summary=j(RECEIPT/'summary.json');entries=j(RECEIPT/'archive-members.json')
ck(h(RECEIPT/'manifest.json')=='dca04be30d638d2cb27a59e6c87945c49ff4346602b2f21650917b501eb11852' and manifest['status']=='complete','pinned completed receipt manifest')
ck(set(manifest['files'])=={'archive-members.json','package.py','reviews.tar.gz','summary.json'},'receipt index four other files')
for name,row in manifest['files'].items():ck(h(RECEIPT/name)==row['sha256'] and len(read(RECEIPT/name))==row['bytes'],'receipt manifest bytes '+name)
ck(read(RECEIPT/'package.py')==read('/tmp/oriole-package-start-frame-integration-reviews.py'),'exact retained receipt generator')
ck(h(RECEIPT/'reviews.tar.gz')=='ee2b18492faa8d8e07280757e421e255a93a60030c3f73bdb78f6cfd3f1a7efc' and len(read(RECEIPT/'reviews.tar.gz'))==279091,'pinned receipt archive')
ck(len(entries)==summary['readback']['members']==49,'49 indexed review members')
roots={name:Path('/tmp/oriole-start-frame-integration-'+name+'-independent-review') for name in ['native','python','cpython','assembly','gate']};roots['composition']=Path('/tmp/oriole-start-frame-source-independent-review')
selected={name+'/'+p.relative_to(root).as_posix():str(p) for name,root in roots.items() for p in root.rglob('*') if p.is_file()}
ck({row['path']:row['origin'] for row in entries}==selected,'receipt includes every selected review file')
with tarfile.open(fileobj=io.BytesIO(read(RECEIPT/'reviews.tar.gz')),mode='r:gz') as archive:
    members=archive.getmembers();ck(len(members)==len({m.name for m in members})==49,'receipt unique regular members')
    for member,row in zip(members,entries,strict=True):
        ck(member.isfile() and safe(member.name) and member.name==row['path'] and member.size==row['bytes'] and member.mode==0o644 and member.mtime==0,'receipt member metadata')
        raw=archive.extractfile(member).read();origin=Path(row['origin'])
        ck(origin.is_file() and not origin.is_symlink() and digest(raw)==row['sha256'] and raw==read(origin),'receipt archived and origin bytes '+member.name)
outer=j(DOC/'summary.json')
ck(summary['status']=='independent_reviews_passed' and summary['runtime_commit']==outer['runtime_commit']=='50c20c1e73eeaacabb9df90e413f502361fb45b3' and summary['source_files']==outer['source_files']==70 and summary['libraries']==outer['libraries'],'receipt selected runtime/source identity')
for name,row in summary['reviews'].items():ck(h(row['path'])==row['sha256'],'underlying review identity '+name)
ck(h(roots['gate']/'workspace-review.json')==summary['workspace_review_sha256'],'workspace review identity')
ck(h(Path(summary['correctness_gate_handoff']['path'])/'manifest.json')==summary['correctness_gate_handoff']['manifest_sha256'],'correctness gate handoff identity')
core=j(OUT/'review.json')
ck(core['status']=='independent_docs_core_package_audit_passed' and h(DOC/'evidence.tar.gz')==core['archive']['sha256'],'frozen core archive remains exact')
for p,value in j(OUT/'checked-files.json').items():ck(h(p)==value,'core audited byte unchanged '+p)
ck(read(DOC/'files.json')==indexraw and all(digest(Path(p).read_bytes())==value for p,value in tracked.items()),'final index and all observed bytes stable')
(OUT/'index-refresh-notes.json').write_text(json.dumps({'initial_sha256':h(OUT/'initial-index-observed.json'),'final_sha256':digest(indexraw),'authorization':'Parent explicitly reported copying five immutable combined review receipt files and refreshing files.json. Initial snapshot remains byte-exact and immutable.','changes':changes},indent=2)+'\n')
(OUT/'final-index-checked-files.json').write_text(json.dumps(tracked,indent=2,sort_keys=True)+'\n')
report={'status':'independent_final_docs_index_and_receipt_passed','scope':'Saved final outer index and receipt supplement to frozen core package audit; no parser/build/timing runs or documentation changes.','cpu':7,'core_package_review_sha256':h(OUT/'review.json'),'outer_index':{'entries':18,'sha256':digest(indexraw),'exact_coverage_and_hashes':True,'stable_during_audit':True},'authorized_refresh':changes,'independent_receipt':{'files':5,'members':49,'manifest_sha256':h(RECEIPT/'manifest.json'),'archive_sha256':h(RECEIPT/'reviews.tar.gz'),'all_archive_member_origin_and_copy_bytes_exact':True},'core_package_all_checked_bytes_reverified':True,'limits':['Human documentation wording/links and numerical interpretation are parent-owned. This supplement validates byte identity and retained source/review linkage.','The outer index excludes itself. Later changes need a new snapshot and index check.','Reviewer authored the original End supplemental helper design; the gate receipt distinguishes its authored tests from independent saved-data checks.'],'checks':len(checks),'checked_files':len(tracked),'generator_sha256':digest(Path(__file__).read_bytes()),'checked_files_sha256':h(OUT/'final-index-checked-files.json')}
(OUT/'final-index-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'files':len(tracked),'review_sha256':digest((OUT/'final-index-review.json').read_bytes())}))
