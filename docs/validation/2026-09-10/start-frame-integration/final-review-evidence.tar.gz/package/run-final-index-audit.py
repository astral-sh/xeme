"""Bounded saved-data audit runner; this never loads a target runtime."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

out=Path(__file__).resolve().parent
command=['taskset','-c','7',sys.executable,'-I','-S',str(out/'final-index-audit.py')]
start=time.monotonic()
report={'status':'incomplete','command':command,'timeout_seconds':120,'target_execution':False}
process=None
with (out/'final-index-audit.stdout').open('wb') as stdout, (out/'final-index-audit.stderr').open('wb') as stderr:
    try:
        process=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True)
        report['exit']=process.wait(timeout=120)
    except subprocess.TimeoutExpired:
        report['timeout']=True
        os.killpg(process.pid,signal.SIGKILL)
        report['exit']=process.wait()
    finally:
        if process is not None and process.poll() is None:
            os.killpg(process.pid,signal.SIGKILL)
            process.wait()
        report['elapsed_seconds']=time.monotonic()-start
        report['status']='passed' if report.get('exit')==0 else 'failed'
        report['artifacts_sha256']={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and p.name!='final-index-audit-run.json'}
        (out/'final-index-audit-run.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['status']=='passed' else 1)
