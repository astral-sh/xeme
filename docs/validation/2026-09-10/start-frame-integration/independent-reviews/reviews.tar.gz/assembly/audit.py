"""Read committed source trees and saved build records; no builds or parser runs."""
from pathlib import Path
import hashlib,io,json,subprocess,tarfile
if not __debug__:raise RuntimeError('Assertions required')
out=Path(__file__).parent;r=Path('/tmp/oriole-start-frame-integration-study');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_bytes())
s=load(r/'source.json');a=load('/tmp/oriole-start-frame-integration-assembly.json');b=load('/tmp/oriole-end-tag-integration-study/source.json');w=Path(s['worktree']);files=s['source_sha256'];assert len(files)==70 and set(files)==set(b['source_sha256'])
def git(args):return subprocess.check_output(['git','-C',str(w),*args])
def tree(revision):
 raw=git(['archive',revision,*files])
 with tarfile.open(fileobj=io.BytesIO(raw))as t:return {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest()for m in t if m.isfile()}
assert a['runtime_commit']=='50c20c1e73eeaacabb9df90e413f502361fb45b3'
assert git(['rev-parse',a['runtime_commit']+'^']).decode().strip()==a['parent']=='382891b6662321a7ae7767003e8bc157f1140188'
assert a['frozen_build_base']==s['base']=='503a55957f7cdebcc0b3fb3ada2751ffdb8cb9c9'
assert tree(a['frozen_build_base'])==tree(a['parent'])==b['source_sha256']
assert tree(a['runtime_commit'])==files=={name:h(w/name)for name in files}
assert a['source_manifest_sha256']==h(r/'source.json')
docpaths=git(['diff','--name-only',a['frozen_build_base'],a['parent']]).decode().splitlines();assert not(set(docpaths)&set(files))
changed=git(['diff','--name-only',a['parent'],a['runtime_commit']]).decode().splitlines();assert changed==['crates/oriole/src/lib.rs','crates/oriole/tests/adapter_frame.rs','crates/oriole/tests/allocation.rs']
review=load('/tmp/oriole-start-frame-source-independent-review/review.json');assert review['status']=='source_composition_and_matched_compiler_review_passed'and review['combined_libraries']==load(r/'build.json')['libraries']
build=load(r/'build.json');assert build['status']=='passed'and build['source_manifest_sha256']==h(r/'source.json')
for name,value in build['libraries'].items():assert h(r/name)==value
with tarfile.open(r/'source.tar.gz')as t:archived={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest()for m in t if m.isfile()}
assert archived==files
result={'status':'commit_source_assembly_verified','scope':'Read-only Git archive, frozen/live source and saved build identity checks. No builds or parser calls.','runtime_commit':a['runtime_commit'],'parent':a['parent'],'frozen_build_base':s['base'],'source_files':70,'source_manifest_sha256':h(r/'source.json'),'all_git_live_archive_bytes_match_measured_source':True,'parent_advance_files':docpaths,'parent_advance_touches_measured_sources':False,'runtime_commit_changed_files':changed,'libraries':build['libraries'],'source_build_review_sha256':h('/tmp/oriole-start-frame-source-independent-review/review.json'),'compiler_scope':'Existing composition review reconstructs exact isolated three-file start-frame patch and verifies three fresh workspace rustc invocations with all arguments equal todd16 after only private build directory normalization. No new historical compiler binary hash claim.','findings':[],'evidence_sha256':{str(p):h(p)for p in [r/'source.json',r/'source.tar.gz',r/'build.json',r/'release.log',r/'compiler-invocations.json',Path('/tmp/oriole-start-frame-integration-assembly.json'),Path('/tmp/oriole-start-frame-source-independent-review/review.json'),Path('/tmp/oriole-end-tag-integration-study/source.json')]}}
(out/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(h(out/'review.json'))
