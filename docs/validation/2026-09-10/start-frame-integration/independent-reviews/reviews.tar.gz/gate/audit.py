"""Independent saved-data audit only. Never imports or executes project tools."""
from pathlib import Path
from collections import Counter
import ast
import difflib
import gzip
import hashlib
import io
import itertools
import json
import os
import re
import tarfile

R = Path('/tmp/oriole-start-frame-integration-gates')
O = Path(__file__).resolve().parent
W = Path('/home/dev-user/code/oss/oriole-start-frame-integration')
L = Path('/tmp/oriole-start-frame-integration-study')
B = Path('/tmp/oriole-end-tag-integration-study')
assert sorted(os.sched_getaffinity(0)) == [6]
tracked = {}
checks = []
def read(path):
    p = Path(path)
    data = p.read_bytes()
    value = hashlib.sha256(data).hexdigest()
    assert tracked.setdefault(str(p), value) == value, str(p)
    return data
def h(path):
    read(path)
    return tracked[str(path)]
def j(path):
    return json.loads(read(path))
def ck(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})
    assert condition, name
def hashes(mapping):
    return all(h(path) == value for path, value in mapping.items())
def unchanged(report, before='before', after='after'):
    return report[before] == report[after] and hashes(report[before])
def commands(report, root, allow_api=False):
    for command in report['commands']:
        ck('command CPU4 ' + command['label'], command['command'][:3] == ['taskset','-c','4'])
        ck('command exit ' + command['label'], command['exit'] == (1 if allow_api and command['label'] == 'api' else 0))
        ck('command no exception ' + command['label'], 'exception' not in command)
        for stream in ['stdout','stderr']:
            ck('command stream hash ' + command['label'] + stream, h(root / (command['label'] + '.' + stream)) == command[stream + '_sha256'])

source = j(R / 'source.json')
build = j(R / 'build.json')
preparation = j(R / 'preparation.json')
ck('exact70 source manifest and build/preparation identity', len(source['source_sha256']) == 70 and h(R/'source.json') == h(L/'source.json') == build['source_manifest_sha256'] == preparation['source_manifest_sha256'])
ck('all70 live source hashes', all(h(W/name) == value for name,value in source['source_sha256'].items()))
with tarfile.open(fileobj=io.BytesIO(read(R/'source.tar.gz')),mode='r:gz') as archive:
    members = archive.getmembers()
    ck('source archive exactly70 unique regular members', len(members)==70 and len({m.name for m in members})==70 and all(m.isfile() for m in members))
    ck('source archive names and bytes match manifest', {m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in members} == source['source_sha256'])
baseline_manifest = j(B/'source.json')
baseline_source = baseline_manifest['source_sha256']
ck('direct control70 same names; core and two test files changed', len(baseline_source)==70 and set(source['source_sha256'])==set(baseline_source) and [name for name,value in baseline_source.items() if source['source_sha256'][name]!=value] == ['crates/oriole/src/lib.rs','crates/oriole/tests/adapter_frame.rs','crates/oriole/tests/allocation.rs'])
ck('direct control70 live source hashes', all(h(Path(baseline_manifest['worktree'])/name)==value for name,value in baseline_source.items()))
with tarfile.open(fileobj=io.BytesIO(read(B/'source.tar.gz')), mode='r:gz') as archive:
    members=archive.getmembers()
    ck('direct control70 archived names and bytes',len(members)==70 and len({m.name for m in members})==70 and all(m.isfile() for m in members) and {m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in members}==baseline_source)
expected_libraries = {'liboriole_expat.so':'9815cc852327d455c094b0fb72c1d33fb90a4571e67cf15965e96e2300376828','liboriole_expat.a':'92eafd42ffe68dc30db920ff5ff8d67357b2c6c4273f51b0e3e841b2bfb9ea69'}
ck('candidate shared/static hashes exact', build['libraries']==preparation['libraries']==expected_libraries and all(h(L/name)==value for name,value in expected_libraries.items()))
ck('direct baseline release hash exact', h(B/'liboriole_expat.so')=='dd16d23e4ab67938c195970bd845b2a159d7f062beda265bb673c85b79f73fc6'==preparation['direct_control']['sha256'] and preparation['direct_control']['path']==str(B/'liboriole_expat.so'))
composition=Path('/tmp/oriole-start-frame-source-independent-review/review.json')
ck('composition review pinned identity',h(composition)=='e4cf877aa0d3683403d524da0304b8ad30e694a9e27ff333c2488f000036c395' and j(composition)['status']=='source_composition_and_matched_compiler_review_passed')
ck('preparation component receipt identity',h(preparation['composition_components']['path'])==preparation['composition_components']['sha256']==h(R/'components.json'))
prior_root=Path('/tmp/oriole-start-frame-lowering-gates')
deltas=j(R/'controller-deltas.json')
ck('all eleven retained controllers',set(preparation['controllers'])==set(preparation['prior_controllers'])==set(deltas)=={'workspace_checks.py','api_native.py','other_controls.py','publication_probe.py','run_publication.py','prepare_malformed.py','run_malformed.py','run_gates.py','classify_observations.py','count_checks.py','summarize.py'})
for name,expected in preparation['controllers'].items():
    ck('prepared controller hash '+name,h(R/name)==expected)
    original_path=prior_root/name
    ck('prior controller hash '+name,h(original_path)==preparation['prior_controllers'][name])
    original=read(original_path).decode()
    adapted=original.replace(str(prior_root),str(R)).replace('/tmp/oriole-start-frame-lowering-study',str(L)).replace('/home/dev-user/code/oss/oriole-start-frame-lowering',str(W)).replace('/tmp/oriole-scanner-integration-study',str(B))
    if name=='workspace_checks.py':adapted=adapted.replace('CPU7','CPU2').replace("'-c','7'","'-c','2'")
    if name=='count_checks.py':adapted=adapted.replace('==396','==398').replace('/tmp/oriole-scanner-integration-gates/workspace-checks/tests.log','/tmp/oriole-end-tag-integration-gates/workspace-checks/tests.log')
    if name=='summarize.py':adapted=adapted.replace("'tests':396","'tests':398")
    ck('controller only authorized path/CPU/source and workspace-count adaptations '+name,adapted==read(R/name).decode())
    ck('retained exact controller diff '+name,deltas[name]==''.join(difflib.unified_diff(original.splitlines(True),adapted.splitlines(True),fromfile=str(original_path),tofile=str(R/name))))
read(R/'prepare.py')
gates=j(R/'gates-controller.json')
ck('four original gate controllers completed',gates['status']=='passed' and [row['script'] for row in gates['jobs']]==['api_native.py','other_controls.py','run_publication.py','run_malformed.py'])
for row in gates['jobs']:
    ck('gate controller command exit/hash '+row['script'],row['exit']==0 and row['command'][:3]==['taskset','-c','4'] and h(R/row['script'])==row['sha256'])
    for stream in ['stdout','stderr']:ck('gate controller stream '+row['script']+stream,h(R/(row['script']+'.'+stream))==row[stream+'_sha256'])
    ck('gate controller stderr empty '+row['script'],read(R/(row['script']+'.stderr'))==b'')
malformed_source=read(prior_root/'malformed/malformed_probe.py').decode().replace(str(prior_root),str(R)).replace('/tmp/oriole-start-frame-lowering-study',str(L)).replace('/tmp/oriole-scanner-integration-study',str(B))
ck('malformed worker unchanged except paths',malformed_source==read(R/'malformed/malformed_probe.py').decode())

A=R/'api-native'; U=A/'upstream-api'
api_report=j(A/'report.json'); comparison=j(A/'api-comparison.json')
ck('API/native saved report passed and references unchanged',api_report['status']=='passed' and api_report['unchanged'] and unchanged(api_report))
commands(api_report,A,allow_api=True)
ck('API and six build/run pairs count',len(api_report['commands'])==13)
manifest=j(U/'manifest.json'); results=j(U/'results.json'); baseline=Path(comparison['baseline'])
base_manifest=j(baseline/'manifest.json'); base_results=j(baseline/'results.json')
bounds={k:manifest[k] for k in ['per_test_seconds','per_test_address_space_bytes','per_test_rss_limit_bytes','total_timeout_seconds']}
ck('original bounds3s/1024MiB/768MiB/240s', list(bounds.values())==[3,1073741824,805306368,240])
ck('full original public selection',manifest['selected_tests'] is None and len(manifest['public_tests_in_source'])==395 and manifest['chunks']==[0,1,2,3,4,5] and manifest['deferral']==[0,1])
norm=lambda m,p:{k:([x.replace(str(p),'<OUTPUT>') for x in v] if k=='compile_command' else v) for k,v in m.items() if k not in ['library_sha256','binary_sha256']}
ck('baseline/candidate manifests otherwise exact',norm(manifest,U)==norm(base_manifest,baseline))
for name,value in manifest['adapted_sources'].items(): ck('adapted API source '+name,h(U/'adapted'/name)==value)
for name,value in manifest['upstream_include_sources'].items(): ck('upstream include source '+name,h(U/name)==value)
for name,value in manifest['adapter_sources'].items(): ck('API adapter source '+name,h(A/'tools'/name)==value)
ck('API compiled binary and copied library hashes', h(U/'runtests')==manifest['binary_sha256'] and h(U/'liboriole_expat.so')==manifest['library_sha256']==expected_libraries['liboriole_expat.so'])
ck('API raw result bytes match baseline and comparison hashes',read(U/'results.json')==read(baseline/'results.json') and h(U/'results.json')==comparison['candidate_results_sha256']==comparison['baseline_results_sha256'])
raw=[]; began=[]
for line in read(U/'tests.log').decode().splitlines():
    if line.startswith('ORIOLE_RESULT\t'):
        _,context,test,outcome,code=line.split('\t');raw.append({'context':context,'test':test,'outcome':outcome,'code':int(code)})
    if line.startswith('ORIOLE_BEGIN\t'):
        _,context,test=line.split('\t');began.append((test,context))
ck('all4740 rows reconstructed exactly from raw API log',len(raw)==4740 and raw==results['results'] and raw==base_results['results'])
expected_selection={(test,f'chunksize={chunk} deferral={defer}') for test in manifest['public_tests_in_source'] for chunk in manifest['chunks'] for defer in manifest['deferral']}
ck('API each selected context began and completed once',len(set(began))==len(began)==4740 and set(began)==expected_selection=={(row['test'],row['context']) for row in raw})
api_counts=Counter(row['outcome'] for row in raw)
ck('original4347 pass393 fail exit1 retained',api_counts=={'pass':4347,'fail':393} and results['passed']==4347 and results['failed']==393 and results['returncode']==1 and results['selection_complete'] and results['library_origin_verified'] and not results['timed_out'])
ck('API library origin appears in original run log',f'ORIOLE_LIBRARY\t{U}/liboriole_expat.so' in read(U/'tests.log').decode())
native=[]
for linkage in ['dynamic','static']:
    for name in ['integration','adversarial','allocations']:
        label='native-'+name+'-'+linkage
        compile_row=next(row for row in api_report['commands'] if row['label']==label+'-build')
        run_row=next(row for row in api_report['commands'] if row['label']==label)
        cmd=compile_row['command']
        ck('C ASan/UBSan flags '+label,'-fsanitize=address,undefined' in cmd and '-fno-omit-frame-pointer' in cmd and '-Werror' in cmd and '-DNDEBUG' not in cmd)
        ck('C bounded compile and run '+label,compile_row['timeout']==run_row['timeout']==120)
        ck('C original source '+label,h(A/'native'/(name+'.c'))==h(W/'tests/c'/(name+'.c')))
        ck('C binary hash '+label,h(A/'native'/(name+'-'+linkage))==run_row['binary_sha256'])
        ck('C consumer/build stderr empty '+label,read(A/(label+'.stderr'))==b'' and read(A/(label+'-build.stderr'))==b'')
        ck('C expected linkage '+label,('-loriole_expat' in cmd and '-Wl,-rpath,'+str(L) in cmd) if linkage=='dynamic' else str(L/'liboriole_expat.a') in cmd)
        output=read(A/(label+'.stdout')).decode().strip()
        if name=='allocations':ck('327 allocation scenarios '+linkage,'327 scenarios' in output)
        native.append({'consumer':name,'linkage':linkage,'exit':run_row['exit'],'stdout':output,'binary_sha256':run_row['binary_sha256']})
ck('native source manifest hashes',hashes(api_report['native_sources']))
ck('native leak/UB options retained in controller',"'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1'" in read(R/'api_native.py').decode() and "'UBSAN_OPTIONS':'halt_on_error=1'" in read(R/'api_native.py').decode())

D=R/'other-gates'; other=j(D/'report.json')
ck('other gates report identity',other['status']=='passed' and other['unchanged'] and unchanged(other) and hashes(other['tool_hashes']) and hashes(other['alias_original_hashes']))
commands(other,D)
strict=j(D/'differential/summary.json'); ref=j(D/'differential/reference.json'); cand=j(D/'differential/oriole.json')
ck('strict3318 full paired records exact',len(ref['results'])==len(cand['results'])==3318 and ref['results']==cand['results'] and strict['exact_pass'] and not strict['differences'])
ck('strict3318 no callback exceptions',all(not row['result']['callback_errors'] for row in cand['results']))
ck('strict identities and child exits',all(value['returncode']==0 and value['sha256_before']==value['sha256_after']==h(value['path']) for value in strict['libraries'].values()))
aliases=[]
for row in other['aliases']:
    label='full-events-comparison' if row['name']=='full-events' else 'external-semantic-comparison'
    path=D/'aliases'/(label+'.json');data=j(path)
    ck('alias script/report hashes '+label,h(D/'aliases'/(row['name']+'.py'))==row['script_sha256'] and h(path)==row['report_sha256'])
    ck('alias compressed report readback '+label,gzip.decompress(read(Path(str(path)+'.gz')))==read(path))
    ck('alias retained zero-difference report '+label,data['cases']==row['cases'] and data['differences']==[] and data['sha256']==expected_libraries['liboriole_expat.so'])
    aliases.append({'name':row['name'],'cases':row['cases'],'raw_successful_pairs_retained':False})
def dict_size(path, variable):
    tree=ast.parse(read(path))
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==variable for t in node.targets):
            assert isinstance(node.value,ast.Dict)
            return len(node.value.keys)
    raise AssertionError(variable)
full_count=(dict_size(D/'aliases/probe.py','CASES')+dict_size(D/'aliases/full-events.py','extra'))*3*98*2
external_count=dict_size(D/'aliases/external-semantic-compare.py','cases')*2*98*3
ck('alias source loop arithmetic',full_count==28812 and external_count==7644 and sum(row['cases'] for row in aliases)==36456)

M=R/'malformed'; ml=j(M/'launch.json'); mr=j(M/'malformed-probe.json')
ck('malformed launch complete identities',ml['status']=='passed' and ml['exit']==0 and ml['timeout']==180 and unchanged(ml))
for stream in ['stdout','stderr']:ck('malformed launch hash '+stream,h(M/stream)==ml[stream+'_sha256'])
ck('malformed stderr empty',read(M/'stderr')==b'')
paired=[json.loads(line) for line in gzip.decompress(read(M/'observations.jsonl.gz')).splitlines()]
ck('all2392 malformed full paired records exact',len(paired)==2392 and all(row['control']==row['candidate'] and not row['control']['callback_errors'] for row in paired))
reconstructed=[{'sha256':row['input_sha256'],'encoding':row['encoding'],'chunk':row['chunk'],'control_status':row['control']['status'],'error':row['control']['error'],'fields':[]} for row in paired]
ck('malformed summary reconstructed without normalization',mr['cases']==2392 and not mr['differences'] and mr['rows']==reconstructed)
fixture=[]
for prefix,tail in itertools.product(['','a','a\n','a\r','a\r\n','\n\n','\r\r','\ré\n'],['bad]]>','bad]]>\x01','\x01]]>',']\n]>','a\x01',']]','a\r\nb',']]><n/>']):
    for internal in [False,True]:
        xml=f"<!DOCTYPE r [<!ENTITY e '{prefix}{tail}'>]><r>&e;</r>" if internal else f'<r>{prefix}{tail}</r>'
        fixture.append((xml,[1,2,3,7,64,4096,len(xml.encode())]))
for size,newline,tail in itertools.product([65532,65535,65536,65537,70000],['\n','\r','\r\n'],[']]>','\x01]]>','bad]]>\x01','ok']):
    fixture.append(('<r>a\n'+('x'*(size-2))+newline+tail+'</r>',[65533,65535,65536,65537,200000]))
expected_keys=[(hashlib.sha256(xml.encode(encoding)).hexdigest(),encoding,chunk) for xml,chunks in fixture for encoding in ['utf-8','utf-16'] for chunk in sorted(set(chunks))]
actual_keys=[(row['input_sha256'],row['encoding'],row['chunk']) for row in paired]
ck('malformed every original generated input hash/encoding/chunk reconstructed',expected_keys==actual_keys and len(set(actual_keys))==2392)

P=R/'publication-probe'; pl=j(R/'publication-launch/report.json'); pr=j(P/'report.json')
ck('publication launch complete bounds',pl['status']=='passed' and pl['exit']==0 and pl['timeout']==240 and pl['generator_sha256']==h(R/'publication_probe.py'))
for stream in ['stdout','stderr']:ck('publication stream hash '+stream,h(R/'publication-launch'/stream)==pl[stream+'_sha256'])
ck('publication stderr empty',read(R/'publication-launch/stderr')==b'')
ck('publication source/helper/library hash identity',pr['status']=='passed' and pr['failure'] is None and not pr['hash_errors'] and unchanged(pr,'hashes_before','hashes_after'))
publication=json.loads(gzip.decompress(read(P/'observations.json.gz')))
ck('publication1304 cases3912 parses exact counts',len(publication)==pr['cases']==1304 and pr['library_parses']==3912)
ck('publication observation hash',h(P/'observations.json.gz')==pr['observations_sha256'])
ck('publication1304 unique full case descriptors',len({json.dumps(row['case'],sort_keys=True) for row in publication})==1304)
ck('publication matrix1152 external144 dynamic8 compaction',Counter(row['case']['label']=='compaction-large-fallback' and 'compact' or row['case']['label']=='dynamic' and 'dynamic' or 'external' for row in publication)=={'external':1152,'dynamic':144,'compact':8})
positions=Counter();reference_different=[]
for index,row in enumerate(publication):
    values=row['values'];a=values['candidate'];b=values['baseline'];ref=values['reference']
    ck('publication complete baseline equivalence '+str(index),a==b and set(values)=={'candidate','baseline','reference'} and all(not value['callback_errors'] for value in values.values()))
    ck('publication reference all non-event fields '+str(index),{k:v for k,v in a.items() if k!='events'}=={k:v for k,v in ref.items() if k!='events'})
    ck('publication reference event lengths '+str(index),len(a['events'])==len(ref['events']))
    if a!=ref:reference_different.append(index)
    for left,right in zip(a['events'],ref['events']):
        if left!=right:
            ck('reference only default/external position fields',left[:-1]==right[:-1] and left[1] in ['default','external'] and all(type(v) is int for v in left[-1]+right[-1]))
            positions[left[1]]+=1
ck('publication exact reference differences reconstructed',reference_different==pr['candidate_reference_differences'] and pr['candidate_baseline_differences']==[] and positions=={'default':10416,'external':864})
origins=pr['origins_before_parses']
ck('publication9 recorded same-process origin checks',len(origins)==3 and all({row['symbol'] for row in rows}=={'XML_Parse','XML_ParserCreate','XML_ExternalEntityParserCreate'} and all(Path(row['path']).resolve()==Path(path).resolve() and h(row['path'])==row['sha256']==pr['hashes_before'][path] for row in rows) for path,rows in origins.items()))

ck('saved files unchanged across audit',all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected for path,expected in tracked.items()))
report={
    'status':'independent_original_saved_gates_audit_passed',
    'scope':'Saved-data-only audit of original API/native C/strict/custom alias/malformed/publication gates. No builds, parser calls, or timing reruns. Matching-end lifecycle/OOM and workspace saved-data checks are separate supplements.',
    'cpu':6,
    'source':{'entries':70,'live_and_archive_all_match':True,'manifest_sha256':h(R/'source.json'),'common_runtime_changed_files':['crates/oriole/src/lib.rs'],'changed_tests':['crates/oriole/tests/adapter_frame.rs','crates/oriole/tests/allocation.rs'],'direct_control_source_entries':70,'additional_manifest_entries':[],'direct_control_shared_sha256':h(B/'liboriole_expat.so'),'composition_review_sha256':h(composition)},
    'libraries':expected_libraries,
    'api':{'rows':4740,'passed':4347,'failed':393,'suite_exit':1,'raw_rows_reconstructed_from_log':True,'all_rows_exact_against_baseline':True,'bounds':bounds,'adapted_sources':34,'upstream_include_sources':38,'public_tests':395,'configurations_per_test':12,'excluded_private_tests':12},
    'native':{'consumers':native,'allocation_scenarios_each_linkage':327,'scope':'C ASan/UBSan only; Rust release libraries uninstrumented, leak detection disabled. Six builds and six runs exited0.'},
    'strict':{'comparisons':3318,'all_saved_full_traces_exact':True},
    'aliases':{'comparisons':36456,'groups':aliases,'verified':'Controller/template/loop arithmetic, expected library hashes, command exits, script and summary hashes, compressed summary readback and retained empty difference lists. Full successful paired alias observations are not present; no independent reconstruction claim for those pairs.'},
    'malformed':{'comparisons':2392,'all_full_observation_fields_exact':True,'all_original_input_sha256_encoding_chunk_keys_reconstructed':True,'summary_rows_reconstructed':True},
    'publication':{'cases':1304,'library_parses':3912,'all_baseline_observation_fields_exact':True,'recorded_same_process_symbol_origins':9,'reference_outcome_and_callback_payload_order_and_final_position_equal':True,'retained_reference_position_event_differences':dict(positions)},
    'limits':['Parity with baseline does not make the original API suite green:393 failures and exit1 remain.','Custom alias gates retain only difference summaries for successful comparisons; independently re-reading raw successful pair outputs is impossible from these artifacts.','Recorded origin evidence is scoped to the checked symbols; no new all-symbol origin or sanitizer-attribution claim.','Outer controllers use per-command timeouts and process-group cleanup on caught exceptions; ordinary SIGTERM forwarding is not explicit in these inherited original controllers. All audited commands completed.','Workspace logs are covered by a separate saved-log supplement. Throughput and CPython/PBS are outside this gate audit. Final frozen combined build only; prior draft compile and fixture-assumption corrections described by the source review remain separate history.','Hashes verified against existing recorded references and again during this audit do not establish historical immutability before the first read.'],
    'passed_checks':len(checks),'inspected_file_count':len(tracked),'audit_generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(O/'checked-files.json').write_text(json.dumps(tracked,indent=2,sort_keys=True)+'\n')
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'files':len(tracked),'review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest()},indent=2))
