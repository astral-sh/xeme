"""Saved package and supplemental-record audit; no target code is imported."""
from pathlib import Path
import difflib
import hashlib
import io
import json
import os
import tarfile

assert os.sched_getaffinity(0)=={6}
R=Path('/tmp/oriole-start-frame-integration-gates')
H=Path('/tmp/oriole-start-frame-integration-gates-handoff')
O=Path(__file__).resolve().parent
OLD=Path('/tmp/oriole-end-tag-integration-gates')
tracked={};checks=[]
def read(p):
    p=Path(p);raw=p.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(p),value)==value,str(p)
    return raw
def h(p):read(p);return tracked[str(p)]
def j(p):return json.loads(read(p))
def ck(label,value):
    assert value,label
    checks.append(label)

manifest=j(H/'manifest.json');entries=j(H/'archive-members.json');excluded=j(H/'excluded-binaries.json')
ck('pinned handoff manifest',h(H/'manifest.json')=='759e1e1ea26d6473eb0fa269b36ad846c83cd4ff4d4953d3e2db5ef79f9e27b5')
ck('seven indexed outer files',set(manifest['files'])=={p.name for p in H.iterdir() if p.is_file()}-{'manifest.json'})
for name,row in manifest['files'].items():ck('outer index '+name,h(H/name)==row['sha256'] and len(read(H/name))==row['bytes'])
ck('262 entries and10 exclusions',len(entries)==manifest['archive_members']==262 and len(excluded)==manifest['excluded_binaries']==10)
byname={row['path']:row for row in entries};exnames={row['path'] for row in excluded}
ck('exact unique disjoint source inventory',len(byname)==len(entries) and len(exnames)==len(excluded) and not exnames.intersection(byname) and set(byname)|exnames=={p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file()})
for row in entries+excluded:
    p=Path(row['origin'])
    ck('origin exact '+row['path'],p==R/row['path'] and not p.is_symlink() and h(p)==row['sha256'] and len(read(p))==row['bytes'])
    binary=read(p).startswith((b'\x7fELF',b'!<arch>\n'))
    ck('binary exclusion predicate '+row['path'],binary==(row['path'] in exnames))
with tarfile.open(fileobj=io.BytesIO(read(H/'evidence.tar.gz')),mode='r:gz') as archive:
    members=archive.getmembers()
    ck('exact regular archive membership',len(members)==262 and len({m.name for m in members})==262 and {m.name for m in members}==set(byname) and all(m.isfile() for m in members))
    for member in members:
        raw=archive.extractfile(member).read();row=byname[member.name]
        ck('archive payload '+member.name,len(raw)==member.size==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'] and raw==read(row['origin']))
source=j(R/'source.json')
ck('source70 handoff identity',len(source['source_sha256'])==manifest['source_files']==70 and h(R/'source.json')==manifest['source_manifest_sha256'])
for path in [R/'source.tar.gz',R/'workspace-checks/source.tar.gz']:
    with tarfile.open(fileobj=io.BytesIO(read(path)),mode='r:gz') as archive:
        members=archive.getmembers()
        ck('nested source snapshot '+str(path),len(members)==70 and len({m.name for m in members})==70 and all(m.isfile() for m in members) and {m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in members}==source['source_sha256'])
for name,value in source['source_sha256'].items():ck('live source '+name,h(Path(source['worktree'])/name)==value)
ck('outer summary copied byte exactly',read(H/'summary.json')==read(R/'summary.json') and h(H/'summary.json')=='80574863b2782812d0e5881f53b1d2f4ea5016aae5f8cc50a4007486200513eb')
ck('package generator byte exact',read(H/'package.py')==read(R/'complete.py'))
completion=j(R/'completion.json');summary=j(R/'summary.json');original=j(R/'original-gate-summary.json')
ck('completion original and combined hashes',completion['status']=='passed' and h(R/'completion.json')==manifest['completion_sha256'] and completion['original_gate_summary_sha256']==summary['original_gate_summary_sha256']==h(R/'original-gate-summary.json') and completion['combined_summary_sha256']==h(R/'summary.json'))
ck('original fields preserved',all(summary[k]==v for k,v in original.items()))
gate=j(O/'review.json');workspace=j(O/'workspace-review.json')
ck('gate summary exact counts and identities',original['status']=='correctness_parity_gates_passed' and original['source']['manifest_sha256']==gate['source']['manifest_sha256'] and original['libraries']['candidate']==gate['libraries']['liboriole_expat.so'] and original['libraries']['candidate_static']==gate['libraries']['liboriole_expat.a'] and original['libraries']['direct_control']==gate['source']['direct_control_shared_sha256'] and original['workspace']=={'tests':398,'doc-tests':1} and workspace['all_target_tests_passed']==398 and original['api']['passed']==4347 and original['api']['failed']==393 and original['api']['bounds']==gate['api']['bounds'] and original['native']['consumers_passed']==6 and original['native']['allocation_scenarios_per_linkage']==327 and original['strict_baseline_traces']==3318 and original['custom_alias_baseline_comparisons']==36456 and original['malformed_baseline_comparisons']==2392 and original['publication']['cases']==1304 and original['publication']['library_parses']==3912)
direct=j(R/'direct-api-comparison.json');ap=R/'api-native/upstream-api';bp=OLD/'api-native/upstream-api'
ck('direct API result bytes equal',read(ap/'results.json')==read(bp/'results.json') and h(ap/'results.json')==direct['candidate_results_sha256']==direct['control_results_sha256'])
normal=lambda m,p:{k:([v.replace(str(p),'<OUTPUT>') for v in value] if k=='compile_command' else value) for k,value in m.items() if k not in ['library_sha256','binary_sha256']}
ck('direct API manifests otherwise exact',normal(j(ap/'manifest.json'),ap)==normal(j(bp/'manifest.json'),bp))

LC=R/'end-lifecycle';OM=R/'end-oom-final';prep=j(LC/'preparation.json');launch=j(LC/'launch.json');control=j(LC/'controller.json')
ck('shared supplemental setup',prep==j(OM/'preparation.json') and launch['status']=='passed' and launch['unchanged'] and not launch['hash_errors'] and launch['before']==launch['after'])
for p,value in launch['before'].items():ck('supplemental before after '+p,h(p)==value)
for row in prep['adaptations']:
    before=read(row['source']);after=read(row['target'])
    ck('supplemental source identity '+row['target'],hashlib.sha256(before).hexdigest()==row['source_sha256'] and hashlib.sha256(after).hexdigest()==row['target_sha256'])
    if row.get('byte_exact'):ck('exact C fixture '+row['target'],before==after)
    else:
        text=before.decode()
        for sub in row['replacements']:
            ck('declared substitution count',text.count(sub['before'])==sub['count']);text=text.replace(sub['before'],sub['after'])
        ck('only declared source adaptations',text.encode()==after)
        patch=''.join(difflib.unified_diff(before.decode().splitlines(True),text.splitlines(True),fromfile=row['source'],tofile=row['target']))
        ck('exact source adaptation patch',read(row['target']+'.patch').decode()==patch)
for row in launch['commands']:
    directory=LC if row['name']=='lifecycle' else OM
    ck('supplement outer success',row['exit_code']==0 and row['status']=='passed' and row['command'][:3]==['taskset','-c','4'])
    for stream in ['stdout','stderr']:ck('supplement outer stream',h(directory/('launch.'+stream))==row[stream+'_sha256'])
engines={name:j(LC/(name+'.json')) for name in ['baseline','candidate','expat']}
expected={'baseline':manifest['direct_control']['sha256'],'candidate':manifest['candidate_libraries']['liboriole_expat.so'],'expat':'7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'}
ck('38 lifecycle logical cases and114 parsers',control['status']=='passed' and control['logical_cases']==38 and control['parser_executions']==114 and control['outer_timeout_seconds_per_engine']==90)
for name,data in engines.items():
    ck('lifecycle runtime '+name,data['status']=='passed' and data['affinity']==[4] and len(data['cases'])==38 and data['library_unchanged'] and data['expected_sha256']==data['before_sha256']==data['after_sha256']==expected[name]==h(data['library']))
    ck('lifecycle21 same process bindings '+name,len(data['dladdr'])==21 and all(Path(v['path']).resolve()==Path(data['library']).resolve() and v['sha256']==expected[name]==h(v['path']) for v in data['dladdr'].values()))
    ck('all lifecycle case fields equal historical '+name,data['cases']==j(OLD/'end-lifecycle'/(name+'.json'))['cases'])
    ck('lifecycle case IDs unique '+name,len({c['id'] for c in data['cases']})==38)
    for case in data['cases']:
        ck('lifecycle successful invariants and cleanup',case['freed'] and case['retained_callback_count_through_free']==7 and not case['callback_errors'] and not case.get('harness_error') and not case.get('invariant_error') and all(case['invariants'].values()))
        ck('lifecycle exact input bytes',hashlib.sha256(bytes.fromhex(case['input_hex'])).hexdigest()==case['input_sha256'])
    row=next(r for r in control['runs'] if r['engine']==name)
    ck('lifecycle worker success',row['status']=='passed' and row['exit_code']==0 and row['command'][:3]==['taskset','-c','4'] and h(LC/(name+'.json'))==control['result_sha256'][name])
    for stream in ['stdout','stderr']:ck('lifecycle worker output',h(LC/(name+'.'+stream))==row[stream+'_sha256'])
    ck('38 immediate case receipts',[json.loads(line)['case'] for line in read(LC/(name+'.stdout')).splitlines()]==[case['id'] for case in data['cases']] and read(LC/(name+'.stderr'))==b'')
ck('lifecycle full candidate control equality',engines['candidate']['cases']==engines['baseline']['cases'])
comparison=j(LC/'comparison.json');oldcomparison=j(OLD/'end-lifecycle/comparison.json')
ck('exact retained full reference differences',comparison==oldcomparison and comparison['candidate_vs_baseline']==[] and len(comparison['expat_vs_baseline'])==38 and sum(any(not d['path'].startswith('/final/') for d in row['differences']) for row in comparison['expat_vs_baseline'])==14)
for name,field in [('oracle.py','oracle_sha256'),('controller.py','controller_sha256'),('SOURCE_REVIEW.md','source_review_sha256'),('comparison.json','comparison_sha256')]:ck('lifecycle source and comparison hash',h(LC/name)==control[field])
oom=j(OM/'report.json');oomreview=j(OM/'review.json')
ck('OOM recorded success',oom['status']=='passed' and oom['unchanged'] and not oom['hash_errors'] and oom['before']==oom['after'] and len(oom['commands'])==4)
for p,value in oom['before'].items():ck('OOM before after identity',h(p)==value)
for row in oom['commands']:
    ck('OOM command bounds success',row['exit']==0 and row['timeout']==120 and row['command'][:3]==['taskset','-c','4'])
    for stream in ['stdout','stderr']:ck('OOM output hash',h(OM/(row['label']+'.'+stream))==row[stream+'_sha256'])
    if row['label'].endswith('-build'):ck('C-only sanitizer flags',all(x in row['command'] for x in ['-fsanitize=address,undefined','-fno-omit-frame-pointer','-Werror']) and read(OM/(row['label']+'.stderr'))==b'')
    else:ck('OOM binary and narrow XML_Parse origin',h(OM/row['label'])==oom['binaries'][row['label']] and read(OM/(row['label']+'.stderr')).decode()=='XML_Parse origin: '+engines[row['label']]['library']+'\n')
raw=read(OM/'baseline.stdout')
ck('OOM current control candidate historical bytes exact',raw==read(OM/'candidate.stdout')==read(OLD/'end-oom-final/baseline.stdout'))
rows=[json.loads(line) for line in raw.splitlines()];summaries=[row for row in rows if row.get('summary')];retries=[]
ck('exact six OOM scenarios',len(rows)==37 and rows[-1]=={'complete':True,'scenarios':6} and [(r['scenario'],r['mode'],r['fail_index']) for r in summaries]==[(0,0,0),(1,0,1),(2,0,2),(3,1,0),(4,1,1),(5,1,2)])
for row in summaries:
    events=[r for r in rows if r.get('scenario')==row['scenario'] and 'event' in r];retry=[r for r in rows if r.get('scenario')==row['scenario'] and 'retry_error' in r]
    ck('OOM zero live and expected prefix allocations',row['live']==0 and row['calls_before']==33)
    if row['failed']:
        ck('OOM failed slot and stable retries',row['status']==0 and row['error']==1 and len(retry)==2 and retry[0]==retry[1] and retry[0]['retry_calls']==row['calls_before']+row['end_calls'] and retry[0]['retry_events']==len(events));retries.extend(retry)
    else:ck('OOM successful end namespace restoration',not retry and row['status']==1 and row['error']==0 and row['end_calls']==row['end_count']==2 and row['resumes']==row['mode'] and sum(e['event']=='namespace-end' for e in events)==2)
ck('exact measured retry33 retained',[(r['scenario'],r['retry_error']) for r in retries]==[(1,1),(1,1),(2,1),(2,1),(4,33),(4,33),(5,1),(5,1)] and oomreview['summaries']==summaries and oomreview['terminal_retries']==retries)
ck('combined supplemental summaries tied',summary['end_oom']==oomreview and summary['end_lifecycle']==j(LC/'review.json')['lifecycle'] and completion['end_lifecycle']['review_sha256']==h(LC/'review.json') and completion['end_oom']['review_sha256']==h(OM/'review.json'))
for p,value in prep['historical_references'].items():ck('retained distinct historical helper receipt',h(p)==value)
ck('all audited files unchanged',all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==value for p,value in tracked.items()))
(O/'handoff-checked-files.json').write_text(json.dumps(tracked,indent=2,sort_keys=True)+'\n')
report={'status':'saved_handoff_and_supplemental_records_passed','scope':'Independent saved package/origin/index and current supplemental result validation. This reviewer authored the original End helpers; their design is not independently certified by this supplement. No parser/build/timing execution or source edit. Parent owns current Git assembly.','cpu':6,'manifest_sha256':h(H/'manifest.json'),'archive_sha256':h(H/'evidence.tar.gz'),'archive_members':262,'excluded_binaries':10,'excluded_binary_formats':sorted({read(row['origin'])[:8].hex() for row in excluded}),'source_files':70,'all_member_origin_bytes_exact':True,'original_gates_review_sha256':h(O/'review.json'),'workspace_review_sha256':h(O/'workspace-review.json'),'workspace':{'all_targets':398,'executables':33,'doc_tests':1},'supplemental':{'lifecycle_cases':38,'lifecycle_parser_executions':114,'full_candidate_control_records_exact':True,'all_engine_records_equal_retained_historical_records':True,'reference_within_handler_differences':14,'reference_post_parse_context_different_records':38,'same_process_XML_bindings_per_engine':21,'oom_scenarios_per_engine':6,'oom_rows_per_engine':37,'oom_parser_executions':12,'oom_selected_failures_per_engine':4,'oom_success_controls_per_engine':2,'oom_candidate_control_historical_bytes_exact':True,'oom_all_zero_live':True,'retry_error33_scenario':4,'no_extra_retry_callbacks_or_allocations':True},'limits':['Canonical 393 failures remain; custom-alias raw successful pairs are absent. See original-gates review.','C consumers only have ASan/UBSan; Rust libraries are release uninstrumented and leak detection disabled. OOM origin covers XML_Parse only.','Supplemental End38/6 reuses the prior cases. The initial helper failure remains separate historical evidence; current helper uses corrected measured retry expectations.','No new semantic or performance claim beyond the retained cases. Current Git source assembly is parent-owned; live70 bytes and archived copies were independently rehashed.','Hash consistency cannot establish historical immutability before saved before/after observations.'],'passed_checks':len(checks),'checked_files':len(tracked),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checked_files_sha256':h(O/'handoff-checked-files.json')}
(O/'handoff-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'files':len(tracked),'review_sha256':hashlib.sha256((O/'handoff-review.json').read_bytes()).hexdigest()}))
