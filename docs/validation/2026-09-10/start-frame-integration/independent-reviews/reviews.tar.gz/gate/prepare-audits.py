from pathlib import Path
import difflib
import hashlib
import json

out=Path(__file__).resolve().parent
prior=Path('/tmp/oriole-start-frame-lowering-gate-independent-review')
expected={'audit.py':'c6700c87e5e175ef8dedaeb9e167e4783cc2e428800b9b18a04b3ef032ecb3ef','workspace-audit.py':'fc8437f78d4e0a4916cba914c6314a36fa8a247613aad2c762a8da2aa966eb83'}
for name,value in expected.items():
    path=prior/name
    assert hashlib.sha256(path.read_bytes()).hexdigest()==value
    old=path.read_text();new=old
    for a,b in [('/tmp/oriole-start-frame-lowering-gates','/tmp/oriole-start-frame-integration-gates'),('/tmp/oriole-start-frame-lowering-study','/tmp/oriole-start-frame-integration-study'),('/home/dev-user/code/oss/oriole-start-frame-lowering','/home/dev-user/code/oss/oriole-start-frame-integration'),('/tmp/oriole-scanner-integration-study','/tmp/oriole-end-tag-integration-study'),('== [1]','== [6]'),('==[1]','==[6]')]:
        new=new.replace(a,b)
    if name=='audit.py':
        for a,b in [('c43531f783087c7b7b532ec34e2160144a98ceeeb5dc9c9cccfa23352c667ac9','9815cc852327d455c094b0fb72c1d33fb90a4571e67cf15965e96e2300376828'),('31f54d91a3f9c312c7d08d1e3142fc020452c4b6a76819e1a216c7a8a4e0092f','92eafd42ffe68dc30db920ff5ff8d67357b2c6c4273f51b0e3e841b2bfb9ea69'),('3694b68326939778481e42e810f53facc2ebcb8b8ad75b599704dbfef8f37926','dd16d23e4ab67938c195970bd845b2a159d7f062beda265bb673c85b79f73fc6'),("'cpu':1","'cpu':6"),('No matching-end lifecycle/OOM supplemental runs are part of this standalone start-frame study. Workspace/Cargo checks are excluded.','Matching-end lifecycle/OOM and workspace saved-data checks are separate supplements.'),('Final frozen build only; the initial compile correction described by the root source review is separate history.','Final frozen combined build only; prior draft compile and fixture-assumption corrections described by the source review remain separate history.')]:new=new.replace(a,b)
        start=new.index('composition=Path(');end=new.index("gates=j(R/'gates-controller.json')",start)
        new=new[:start]+'''composition=Path('/tmp/oriole-start-frame-source-independent-review/review.json')
ck('composition review pinned identity',h(composition)=='e4cf877aa0d3683403d524da0304b8ad30e694a9e27ff333c2488f000036c395' and j(composition)['status']=='source_composition_and_matched_compiler_review_passed')
ck('preparation component receipt identity',h(preparation['composition_components']['path'])==preparation['composition_components']['sha256']==h(R/'components.json'))
prior_root=Path('/tmp/oriole-start-frame-lowering-gates')
deltas=j(R/'controller-deltas.json')
ck('all eleven retained controllers',set(preparation['controllers'])==set(preparation['prior_controllers'])==set(deltas)=={'workspace_checks.py','api_native.py','other_controls.py','publication_probe.py','run_publication.py','prepare_malformed.py','run_malformed.py','run_gates.py','classify_observations.py','count_checks.py','summarize.py'})
for name,expected in preparation['controllers'].items():
    ck('prepared controller hash '+name,h(R/name)==expected)
    original_path=prior_root/name
    ck('prior controller hash '+name,h(original_path)==preparation['prior_controllers'][name])
    original=read(original_path).decode()
    adapted=original.replace(str(prior_root),str(R)).replace('/tmp/oriole-start-frame-lowering-study',str(L)).replace('/home/dev-user/code/oss/oriole-start-frame-lowering',str(W)).replace('/tmp/oriole-scanner-integration-study',str(B))
    if name=='workspace_checks.py':adapted=adapted.replace('CPU7','CPU2').replace("'-c','7'","'-c','2'")
    if name=='count_checks.py':adapted=adapted.replace('==396','==398').replace('/tmp/oriole-scanner-integration-gates/workspace-checks/tests.log','/tmp/oriole-end-tag-integration-gates/workspace-checks/tests.log')
    if name=='summarize.py':adapted=adapted.replace("'tests':396","'tests':398")
    ck('controller only authorized path/CPU/source and workspace-count adaptations '+name,adapted==read(R/name).decode())
    ck('retained exact controller diff '+name,deltas[name]==''.join(difflib.unified_diff(original.splitlines(True),adapted.splitlines(True),fromfile=str(original_path),tofile=str(R/name))))
read(R/'prepare.py')
''' +new[end:]
        start=new.index('malformed_source=');end=new.index("ck('malformed worker unchanged",start)
        new=new[:start]+"malformed_source=read(prior_root/'malformed/malformed_probe.py').decode().replace(str(prior_root),str(R)).replace('/tmp/oriole-start-frame-lowering-study',str(L)).replace('/tmp/oriole-scanner-integration-study',str(B))\n"+new[end:]
    else:
        for a,b in [("'-c','7'","'-c','2'"),('/tmp/oriole-scanner-integration-gates/workspace-checks/tests.log','/tmp/oriole-end-tag-integration-gates/workspace-checks/tests.log'),('==396','==398'),('==395','==397'),("'all_target_tests_passed':396","'all_target_tests_passed':398"),("'baseline_all_target_tests_passed':395","'baseline_all_target_tests_passed':397"),("'recorded_execution_cpu':7,'audit_saved_data_cpu':1","'recorded_execution_cpu':2,'audit_saved_data_cpu':6"),("'tests':396","'tests':398"),('No matching-end supplemental runs are included.','Matching-end supplemental runs are checked separately.')]:new=new.replace(a,b)
    (out/name).write_text(new)
    (out/(name+'.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(path),tofile=str(out/name))))
(out/'preparation.json').write_text(json.dumps({'status':'prepared','scope':'Saved-data-only audit adaptations; original gate bounds, fixtures and raw arithmetic checks retained.','prior':str(prior),'prior_generator_hashes':expected,'audit_cpu':6},indent=2)+'\n')
