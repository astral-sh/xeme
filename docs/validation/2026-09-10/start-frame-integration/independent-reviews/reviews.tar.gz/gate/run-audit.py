"""Run only saved-data reviewer scripts with a bounded process group."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time

out=Path(__file__).resolve().parent
name=sys.argv[1]
assert name in ['audit','workspace-audit','handoff-audit']
command=['taskset','-c','6',sys.executable,'-I','-S',str(out/(name+'.py'))]
report={'status':'incomplete','command':command,'timeout_seconds':120,'target_execution':False}
start=time.monotonic();process=None
with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
    try:
        process=subprocess.Popen(command,stdout=stdout,stderr=stderr,start_new_session=True)
        report['exit']=process.wait(timeout=120)
    except subprocess.TimeoutExpired:
        report['timeout']=True;os.killpg(process.pid,signal.SIGKILL);report['exit']=process.wait()
    finally:
        if process is not None and process.poll() is None:os.killpg(process.pid,signal.SIGKILL);process.wait()
        report['elapsed_seconds']=time.monotonic()-start
        report['status']='passed' if report.get('exit')==0 else 'failed'
        report['artifacts_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file() and not p.name.endswith('-run.json')}
        (out/(name+'-run.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['status']=='passed' else 1)
