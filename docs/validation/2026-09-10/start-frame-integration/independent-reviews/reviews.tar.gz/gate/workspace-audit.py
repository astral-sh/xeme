"""Read completed Cargo output only; no build/test/lint/format execution."""
from pathlib import Path
import hashlib
import json
import os
import re

R=Path('/tmp/oriole-start-frame-integration-gates')
O=Path(__file__).resolve().parent
W=R/'workspace-checks'
assert sorted(os.sched_getaffinity(0))==[6]
observed={}
def read(p):
    p=Path(p);raw=p.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert observed.setdefault(str(p),value)==value
    return raw
def h(p):
    read(p);return observed[str(p)]
def j(p):return json.loads(read(p))
report=j(W/'report.json');counts=j(W/'counts.json');source=j(R/'source.json')
assert report['status']=='passed' and report['unchanged'] and report['before']==report['after']==source['source_sha256']
assert len(report['before'])==70
for name,value in report['before'].items():assert h(Path(source['worktree'])/name)==value
assert report['env_overrides']==j(R/'build.json')['env_overrides']
expected={
 'tests':['test','--release','--locked','--workspace','--all-targets','--no-fail-fast'],
 'doc-tests':['test','--release','--locked','--workspace','--doc'],
 'clippy':['clippy','--release','--locked','--workspace','--all-targets','--','-D','warnings'],
 'fmt':['fmt','--all','--','--check'],
}
assert [row['label'] for row in report['commands']]==list(expected)
for row in report['commands']:
    assert row['exit']==0 and row['command']==['taskset','-c','2','cargo','+ohm','-Zohm-defaults=no',*expected[row['label']]]
    assert h(W/(row['label']+'.log'))==row['log_sha256']
def inventory(path):
    target=None;rows=[];names=[]
    for line in read(path).decode().splitlines():
        if 'Running ' in line and '(' in line:
            target=re.sub(r'-[0-9a-f]{16}$','',Path(line.rsplit('(',1)[1].rstrip(')')).name)
        elif 'Doc-tests ' in line:
            target='doc:'+line.split('Doc-tests ',1)[1].strip()
        match=re.fullmatch(r'test (.+) \.\.\. ok',line)
        if match:names.append((target,match.group(1)))
        match=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)
        if match:
            assert target is not None
            rows.append({'target':target,'passed':int(match[1]),'failed':int(match[2]),'ignored':int(match[3])});target=None
    return rows,names
base=Path('/tmp/oriole-end-tag-integration-gates/workspace-checks/tests.log')
base_rows,base_names=inventory(base)
rows,names=inventory(W/'tests.log');docs,doc_names=inventory(W/'doc-tests.log')
assert rows==counts['all_target_rows'] and docs==counts['doc_rows']
assert len(rows)==len(base_rows)==33 and sum(x['passed'] for x in rows)==398 and sum(x['passed'] for x in docs)==1
assert all(x['failed']==0 and x['ignored']==0 for x in rows+docs)
changes=[{'baseline':a,'candidate':b} for a,b in zip(base_rows,rows,strict=True) if a!=b]
assert changes==counts['changes'] and len(changes)==1
assert changes[0]['candidate']['target']=='adapter_frame' and changes[0]['candidate']['passed']==changes[0]['baseline']['passed']+1
expected_new={('adapter_frame','literal_frames_keep_duplicate_checks_and_selected_name_rules')}
assert len(names)==398 and len(base_names)==397 and set(names)-set(base_names)==expected_new and set(base_names)-set(names)==set()
assert h(base)==counts['baseline_sha256']
assert read(W/'fmt.log')==b''
assert 'p.wait(timeout=900)' in read(R/'workspace_checks.py').decode()
assert counts['all_target_passed']==398 and counts['doc_passed']==1
assert counts['baseline_profile']=='release --workspace --all-targets'
assert str(base)==counts['baseline_log']
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==value for path,value in observed.items())
summary={
 'status':'independent_saved_workspace_logs_passed',
 'scope':'Read-only supplement to original-gates review. Completed release workspace test/doc/clippy/fmt logs and source identities only; no Cargo or parser execution.',
 'original_gates_review_sha256':h(O/'review.json'),
 'all_target_executables':33,'all_target_tests_passed':398,'doc_tests_passed':1,'failed':0,'ignored':0,
 'baseline_all_target_tests_passed':397,'baseline_profile':'release all-targets','candidate_profile':'release all-targets and separate release doc tests',
 'added_tests':[name for _,name in sorted(expected_new)],'original_target_counts_and_test_names_preserved':True,
 'clippy':'--release --locked --workspace --all-targets -- -D warnings, exit0',
 'fmt':'--all -- --check, exit0 and empty log',
 'source_entries_unchanged':70,
 'recorded_execution_cpu':2,'audit_saved_data_cpu':6,
 'caveats':['Baseline and candidate inventory comparisons both use release all-targets; this is not a performance comparison.','The retained workspace controller bounds each Cargo command at 900 seconds; all four recorded commands completed with exit 0.','One adapter-frame test is added; the existing allocation test body gains two large inputs. This inventory comparison does not assert unchanged test bodies. Matching-end supplemental runs are checked separately.'],
 'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checked_file_hashes':observed,
}
(O/'workspace-review.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'path':str(O/'workspace-review.json'),'sha256':hashlib.sha256((O/'workspace-review.json').read_bytes()).hexdigest(),'tests':398,'docs':1}))
