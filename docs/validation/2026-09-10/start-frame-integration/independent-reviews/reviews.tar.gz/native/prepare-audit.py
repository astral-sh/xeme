"""Adapt a frozen saved-data audit; do not execute target code."""
from pathlib import Path
import difflib
import hashlib
import json

out = Path(__file__).resolve().parent
prior = Path('/tmp/oriole-start-frame-lowering-native-independent-review/audit.py')
old = prior.read_text()
assert hashlib.sha256(prior.read_bytes()).hexdigest() == '8e353b5ef5176b3450d69b9a972c02a7d63ac11b5bb5a612417fdce5e6bd4f54'
new = old
replacements = [
    ("R=Path('/tmp/oriole-start-frame-lowering-timing-study')", "R=Path('/tmp/oriole-start-frame-integration-timing-study')"),
    ('assert sorted(os.sched_getaffinity(0))==[5]', 'assert sorted(os.sched_getaffinity(0))==[6]'),
    ("'audit_cpu':5", "'audit_cpu':6"),
    ("'published':'3694b68326939778481e42e810f53facc2ebcb8b8ad75b599704dbfef8f37926'", "'published':'dd16d23e4ab67938c195970bd845b2a159d7f062beda265bb673c85b79f73fc6'"),
    ("'candidate':'c43531f783087c7b7b532ec34e2160144a98ceeeb5dc9c9cccfa23352c667ac9'", "'candidate':'9815cc852327d455c094b0fb72c1d33fb90a4571e67cf15965e96e2300376828'"),
    ('/tmp/oriole-time-start-frame-lowering-native.py', '/tmp/oriole-time-start-frame-integration-native.py'),
    ("candidate_root=Path('/tmp/oriole-start-frame-lowering-study')", "candidate_root=Path('/tmp/oriole-start-frame-integration-study')"),
    ("baseline_root=Path('/tmp/oriole-scanner-integration-study')", "baseline_root=Path('/tmp/oriole-end-tag-integration-study')"),
    ('/tmp/oriole-start-frame-lowering-root-review/review.json', '/tmp/oriole-start-frame-source-independent-review/review.json'),
    ('dd5fa447d5f0d3d23b621b6db4203052e485deed0b2a0cf25b7bf336b5557dc7', 'e4cf877aa0d3683403d524da0304b8ad30e694a9e27ff333c2488f000036c395'),
    ('source_review_passed_no_findings', 'source_composition_and_matched_compiler_review_passed'),
    ('31f54d91a3f9c312c7d08d1e3142fc020452c4b6a76819e1a216c7a8a4e0092f', '92eafd42ffe68dc30db920ff5ff8d67357b2c6c4273f51b0e3e841b2bfb9ea69'),
    ('0.9176838106749211', '0.9066579482925923'),
    ('Direct integration parent 64a270e / 3694b683; this standalone start-frame study is separate from all matching-end studies', 'Direct integration parent 503a559 / dd16d23e; this combined start-frame study is separate from the standalone c43531f7 / 3694b683 study and all earlier studies'),
    ('Final frozen build only; the initial compile correction described by the root source review is separate history.', 'Final frozen combined build only; prior draft compile and fixture-assumption corrections described by the source review remain separate history.'),
]
for before, after in replacements:
    assert new.count(before) == 1, before
    new = new.replace(before, after)
start = new.index("old_path=Path(")
end = new.index("\ncandidate_root=Path(", start)
new = new[:start] + '''old_path=Path('/tmp/oriole-start-frame-lowering-timing-study/native_screen.py')
old=read(old_path).decode()
adapted=old.replace('/tmp/oriole-start-frame-lowering-timing-study',str(R)).replace('/tmp/oriole-start-frame-lowering-study/liboriole_expat.so',protocol['libraries']['candidate']['path']).replace('/tmp/oriole-scanner-integration-study/liboriole_expat.so',protocol['libraries']['published']['path']).replace('published64a270e/3694b683','published503a559/dd16d23e').replace('dedicated literal start-frame lowering','integrated literal start-frame lowering').replace('literal start-frame lowering/c43531f7 candidate','integrated literal start-frame lowering/9815cc85 candidate')
ck('frozen timing controller only declared path/label edits',adapted==read(R/'native_screen.py').decode())
patch=''.join(difflib.unified_diff(old.splitlines(True),adapted.splitlines(True),fromfile='reviewed-standalone-start-frame-native',tofile='integrated-start-frame-native'))
ck('retained controller patch exact',patch==read(R/'controller.patch').decode())
read(R/'oriole-prepare-start-frame-integration-timing.py')
''' + new[end:]
(out/'audit.py').write_text(new)
(out/'adaptation.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(prior),tofile=str(out/'audit.py'))))
(out/'preparation.json').write_text(json.dumps({'status':'prepared','scope':'Saved-data audit adaptation only; fixture/protocol/arithmetic assertions retained; no target code executions.','prior':str(prior),'prior_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'audit_sha256':hashlib.sha256(new.encode()).hexdigest(),'audit_cpu':6},indent=2)+'\n')
