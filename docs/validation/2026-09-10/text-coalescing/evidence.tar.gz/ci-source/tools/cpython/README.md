# CPython XML consumers

`run.py` builds the pinned CPython 3.12.13 XML extensions against a frozen Oriole shared library or static archive, verifies their loaded paths, and runs six unchanged upstream XML test modules. The source checkout must match the pinned revision and remain clean. Build commands, source hashes, logs and original exit codes are retained in the output directory.

Oriole can combine character-data callbacks across line breaks. Expat permits arbitrary character-data fragmentation, but two CPython tests assert its particular boundaries: `BufferTextTest.test1` and `CDATAHandlerTest.test_handlers`. The optional `--allow-text-fragmentation` CI gate accepts only those named failures in a complete run, with consistent test/file counts and no errors, after two additional semantic checks pass. These checks preserve ordered element/CDATA boundaries, every text character and callback-controlled buffering. They load the same compiled extensions. All original failures and exit codes remain in `tests.log` and `summary.json`; an accepted gate does not mean the unchanged upstream suite passed.

The default runner remains strict. `--consumer-fix` separately applies the pinned upstream allocation-failure backport to a temporary C source copy. `--system-allocator` separately selects the system allocator. Each adaptation is recorded explicitly.
