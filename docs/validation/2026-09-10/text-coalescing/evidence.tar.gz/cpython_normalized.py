"""Additional semantic assertions; original upstream failures are retained separately."""
import json,pyexpat,sys,unittest
from pathlib import Path
from xml.sax import make_parser
from xml.sax.handler import ContentHandler,LexicalHandler,property_lexical_handler
from xml.sax.xmlreader import InputSource
from io import StringIO
from test.test_pyexpat import BufferTextTest
from test.test_sax import CDATAHandlerTest
root=Path('/tmp/oriole-coalescing-integrated')
assert Path(pyexpat.__file__).parent==root/'cpython'
case=BufferTextTest('test1');case.setUp();case.setHandlers(['StartElementHandler'])
case.parser.Parse(b"<a>1<b buffer-text='no'/>2\n3<c buffer-text='yes'/>4\n5</a>",True)
events=[]
for item in case.stuff:
 if not item.startswith('<') and events and not events[-1].startswith('<'): events[-1]+=item
 else: events.append(item)
assert events==['<a>','1','<b>','2\n3','<c>','4\n5']
assert case.parser.buffer_text
case=CDATAHandlerTest('test_handlers');case.setUp();groups={};stack=[];in_cdata=False
class Handlers(ContentHandler,LexicalHandler):
 def startElement(self,name,attrs): stack.append(name)
 def endElement(self,name): assert stack.pop()==name
 def startCDATA(self):
  global in_cdata
  assert not in_cdata;in_cdata=True
 def endCDATA(self):
  global in_cdata
  assert in_cdata;in_cdata=False
 def characters(self,value):
  key=(stack[-1],in_cdata);groups[key]=groups.get(key,'')+value
handler=Handlers();parser=make_parser();parser.setContentHandler(handler);parser.setProperty(property_lexical_handler,handler);source=InputSource();source.setCharacterStream(case.test_data);parser.parse(source)
assert groups=={('root_doc',False):'\n\n\n',('some_pcdata',False):'\nParseable character data\n',('some_cdata',False):'\n\n',('some_cdata',True):'<> &% - assorted other XML junk.'},groups
assert not stack and not in_cdata
print(json.dumps({'status':'passed','assertions':['Buffered/unbuffered fixture preserves ordered element and normalized text groups','SAX fixture preserves every whitespace character and CDATA state per element'],'scope':'Separate additional semantic assertions; does not alter upstream tests or their failure counts.'},indent=2))
