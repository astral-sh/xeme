import sys,json,ctypes as c
from pathlib import Path
sys.path.insert(0,'/home/dev-user/code/oss/oriole/tools')
from xml_abi import Expat,TEXT,START,END
root=Path('/tmp/oriole-text-coalescing');manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');rows=[]
for lib in ['control.so','liboriole_expat.so']:
 engine=Expat(str(root/lib));api=engine.lib
 for project in json.loads(manifest.read_text())['projects']:
  data=(manifest.parent/next(f['path'] for f in project['files'] if f['role']=='input')).read_bytes()
  for chunk in [4096,65536]:
   counts={'start':0,'end':0,'text':0,'text_bytes':0};parser=api.XML_ParserCreate(None)
   def start(*args): counts['start']+=1
   def end(*args): counts['end']+=1
   def text(_,value,length): counts['text']+=1;counts['text_bytes']+=length
   callbacks=[START(start),END(end),TEXT(text)];api.XML_SetElementHandler(parser,*callbacks[:2]);api.XML_SetCharacterDataHandler(parser,callbacks[2])
   for i in range(0,len(data),chunk):
    buf=data[i:i+chunk];assert api.XML_Parse(parser,buf,len(buf),int(i+chunk>=len(data)))==1
   api.XML_ParserFree(parser);rows.append({'library':lib,'project':project['name'],'chunk':chunk,**counts})
(root/'event-counts.json').write_text(json.dumps(rows,indent=2)+'\n')
print([r for r in rows if r['project']=='wayland'])
