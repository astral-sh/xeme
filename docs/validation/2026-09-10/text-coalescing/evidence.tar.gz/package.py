from pathlib import Path
import hashlib,json,tarfile,shutil,re,statistics,subprocess
w=Path('/tmp/oriole-coalescing-integrated');d=Path('docs/validation/2026-09-10/text-coalescing');d.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=Path('/tmp/oriole-text-coalescing');isolated=w/'isolated'
for p in original.rglob('*'):
 if not p.is_file() or p.is_symlink():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 out=isolated/p.relative_to(original);out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
review=Path('/tmp/oriole-coalescing-ci-review.json');assert review.exists();shutil.copy2(review,w/review.name)
ci_paths=['.github/workflows/ci.yml','tools/cpython/run.py','tools/cpython/text_fragmentation.py','tools/cpython/test_run.py','tools/cpython/README.md']
for p in ci_paths:
 out=w/'ci-source'/p;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,out)
(w/'ci-source.patch').write_bytes(subprocess.check_output(['git','diff','HEAD','--','.github','tools/cpython']))
source=json.loads((w/'source.json').read_text());diff=json.loads((w/'differential/summary.json').read_text());screen=json.loads((w/'screen.json').read_text());assert screen['status']=='passed';assert diff['semantic_pass'];tests=sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(w/'tests.log').read_text())));assert tests==258
rows=[]
for ns in [False,True]:
 for name in ['vulkan','wayland','maven','batik','gtk','docbook']:
  medians={label:statistics.median(s['seconds'] for r in screen['samples'] if r['input']==name and r['namespaces']==ns and r['label']==label for s in r['output']['samples'] if not s['warmup']) for label in ['control','candidate','expat']}
  rows.append({'project':name,'namespaces':ns,'median_seconds':medians,'speedup':medians['control']/medians['candidate'],'expat_over_oriole':medians['expat']/medians['candidate']})
gate=json.loads((w/'cpython-gate/summary.json').read_text());assert gate['tests_exit_code']==2 and gate['gate_exit_code']==0 and gate['text_fragmentation']['semantic_exit_code']==0
validation={'runtime_source':source['source_sha256'],'ci_source_sha256':{p:sha(Path(p)) for p in ci_paths},'rust_tests':tests,'differential':{k:diff[k] for k in ['cases','difference_counts','semantic_pass','exact_pass']},'malformed_cases':2392,'streaming_cases':32,'native_c_suites':6,'allocation_cases_per_linkage':333,'cpython':{'original_tests':803,'original_failures':2,'original_skips':31,'additional_semantic_tests':2,'gate_exit_code':0},'screen':rows,'scope':'Integrated runtime and explicit semantic CI gate; original upstream failures retained. Full Expat API matrix belongs to isolated coalescing source; no integrated full matrix/PBS campaign claimed.'};(w/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
files={}
for p in sorted(w.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 files[str(p.relative_to(w))]={'sha256':sha(p),'bytes':p.stat().st_size}
with tarfile.open(d/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n in files:t.add(w/n,arcname=n,recursive=False)
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==files[m.name]['sha256']
manifest={'archive_sha256':sha(d/'evidence.tar.gz'),'members':files};(d/'files.json').write_text(json.dumps(manifest,indent=2)+'\n');(d/'summary.json').write_text(json.dumps(validation,indent=2)+'\n')
(d/'README.md').write_text(f'''# Coalesce character data across line breaks

We combine adjacent character data across physical line breaks inside elements. Newly merged spans stop at the last complete line within 64 KiB; existing individual long lines retain their prior span. CRLF, converted-input windows, raw callback spans, suspension and valid prefixes before malformed tokens retain their behavior. Prolog/epilog whitespace and CDATA boundaries are unchanged. The C ABI is unchanged.

The integrated library is `{source['library_sha256']['liboriole_expat.so']}` on parent `{source['parent_commit']}`. All **258 Rust checks**, strict core/FFI Clippy, **2,392 malformed-prefix comparisons**, **32 raw-context/suspension/handler-switch cases**, and six shared/static C ASan/UBSan suites pass. Selected allocation failure injection covers **333 scenarios per linkage**. The C callers are instrumented; Rust is uninstrumented, leak sanitizer is disabled, and selected live allocation counts are checked. The **1,518-case** differential replay has zero status, error, normalized-callback or position differences and six fragmentation differences.

The unchanged CPython 3.12.13 XML modules run **803 tests with two failures and 31 skips**. `BufferTextTest.test1` and `CDATAHandlerTest.test_handlers` assert Expat's particular text boundaries. The explicit `--allow-text-fragmentation` CI gate retains both original failures/exit codes, verifies selected-file completion and failure/error counts, and requires two additional same-extension tests preserving every text character, ordered element/CDATA boundaries and callback-controlled buffering. The default runner remains strict. Its source review, negative gate tests, Ruff/ty results, strict run and separate accepted-gate run are included. An accepted gate does not mean the unchanged upstream suite passed.

In the integrated paired six-project screen (4 KiB, namespaces off/on, five randomized process groups, five measured parses after warmup), Wayland improves **1.51–1.53×** over the preceding runtime. Other medians improve **1.03–1.14×**. All native hashes/counts match. Every workload remains slower than Expat; these are shared-host screening results, not final full-application benchmarks.

The isolated study additionally retains 4/64 KiB screens, instruction profiles and the complete unchanged 4,740-configuration Expat API run: **4,003 pass / 737 fail**, with every outcome identical to its baseline. Its Wayland instruction count falls 61,191,644 → 43,009,988 (29.7%); text callbacks fall 5,966 → 1,155 while retaining all 97,444 text bytes. An initial UTF-16 malformed-prefix defect and its correction remain archived. No integrated full API/PBS campaign is claimed by this layer.

[evidence.tar.gz](evidence.tar.gz) includes raw observations, immutable build/source metadata, initial findings and independent scoped reviews. ELF/static artifacts are excluded and identified by hash. [files.json](files.json) verifies every archive member; [summary.json](summary.json) records the integrated results. Archive SHA256: `{manifest['archive_sha256']}`.
''')
print(json.dumps({'members':len(files),'archive_bytes':(d/'evidence.tar.gz').stat().st_size,'archive_sha256':manifest['archive_sha256']}))
