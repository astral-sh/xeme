from pathlib import Path
import json,hashlib,tarfile,shutil
w=Path('/tmp/oriole-token-integrated');d=Path('docs/validation/2026-09-10/token-ownership');d.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=json.loads((w/'source.json').read_text());screen=json.loads((w/'screen.json').read_text());assert screen['status']=='passed';assert source['rust_tests']==77
isolated=w/'isolated';isolated.mkdir(exist_ok=True)
for n in ['manifest.json','token-swap.patch','screening.json','screening.py','control-callgrind.txt','candidate-callgrind.txt','control-raw-tests.log']:
 shutil.copy2(Path('/tmp/oriole-token-swap')/n,isolated/n)
review={'scope':'Integrating-agent source review of the independent token ownership patch against dc552f4.','source_sha256':source['source_sha256'],'findings':[],'checks':['Markup parse paths only enqueue raw overrides; they never read current_raw or invoke host callbacks.','The fallible closure finishes before the token owner is swapped into current_raw, preserving token contents on errors as well as success.','Errors before token construction preserve the previous raw owner; terminal parsing failures expose the current token without consuming source bytes.','The prior current_raw capacity becomes token_scratch only on success; all owners preserve their selected allocator.','The integration retains markup_text normalization from the preceding compatibility fix. Custom lexical provenance remains a separate later composition requirement.']};(w/'review.json').write_text(json.dumps(review,indent=2)+'\n')
files={}
for p in sorted(w.rglob('*')):
 if not p.is_file():continue
 with p.open('rb') as f:magic=f.read(8)
 if magic.startswith(b'\x7fELF') or magic==b'!<arch>\n':continue
 files[str(p.relative_to(w))]={'sha256':sha(p),'bytes':p.stat().st_size}
with tarfile.open(d/'evidence.tar.gz','w:gz',compresslevel=9) as t:
 for n in files:t.add(w/n,arcname=n,recursive=False)
with tarfile.open(d/'evidence.tar.gz') as t:
 for m in t:assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==files[m.name]['sha256']
manifest={'archive_sha256':sha(d/'evidence.tar.gz'),'members':files};(d/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
(d/'README.md').write_text(f'''# Reuse the owned markup token

Markup parsing previously copied the same decoded bytes into both a temporary lexical token and `current_raw`. We now publish the owned lexical token after parsing, then reuse the previous raw buffer as scratch. A fallible closure ensures terminal errors also expose the complete current token before returning; source consumption and pending raw overrides retain their order. The preceding comment/PI normalization correction is preserved.

The integrated shared library is `{source['library_sha256']['liboriole_expat.so']}`. All **77 focused Rust checks**, strict core/raw-regression Clippy and a 1,518-case exact generated differential replay pass. The regression covers every UTF-8/UTF-16 feed boundary for malformed tags, namespaces, declarations and comments, including repeated terminal errors. The allocation sweep fails every observed selected allocation. The integrating-agent source review is recorded separately.

A paired screen includes all six pinned project inputs with namespace processing off/on, 4 KiB feeds, five randomized process groups and five measured parses after warmup. All native output hashes/counts agree; candidate medians are neutral to roughly 5% faster than the preceding runtime. This short shared-host screen is not a full application benchmark or evidence of surpassing Expat. The isolated 4/64 KiB study found 0–12% project improvements but 2–5% generated entity/declaration regressions; those tradeoffs and raw samples remain retained. Its Wayland instruction count fell only 0.82%, so timing also depends on code layout. No new full API/PBS/sanitizer campaign is claimed for this isolated safe-core optimization.

[evidence.tar.gz](evidence.tar.gz) contains immutable source/build metadata, raw observations, tests and scoped review. ELF/static artifacts are excluded and identified by hash. [files.json](files.json) verifies every archive member. Archive SHA256: `{manifest['archive_sha256']}`.
''')
print(json.dumps({'tests':77,'members':len(files),'archive_bytes':(d/'evidence.tar.gz').stat().st_size,'archive_sha256':manifest['archive_sha256']},indent=2))
