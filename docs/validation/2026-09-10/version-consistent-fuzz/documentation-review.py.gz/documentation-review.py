from pathlib import Path
import hashlib,json,re,tarfile

repo=Path('/home/dev-user/code/oss/oriole')
root=repo/'docs/validation/2026-09-10/version-consistent-fuzz'
handoff=Path('/tmp/oriole-version-fuzz-handoff')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=json.loads((handoff/'summary.json').read_text())
files=json.loads((root/'files.json').read_text())
assert files['handoff_manifest_sha256']==sha(handoff/'artifact-manifest.json')
assert files['archive_sha256']==sha(root/'evidence.tar.gz')
actual={}
with tarfile.open(root/'evidence.tar.gz','r:gz') as tar:
    for member in tar:
        assert member.isfile() and member.name not in actual
        data=tar.extractfile(member).read()
        actual[member.name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
assert actual==files['members'] and len(actual)==20
text=(root/'README.md').read_text()
table=re.findall(r'^\| `(\w+)` \| ([\d,]+) \| ([\d,]+) \| ([\d,]+) \| ([\d.]+) s \| (\d+) MiB \|$',text,re.M)
assert len(table)==6
for name,executions,seeds,evolved,duration,rss in table:
    row=next(r for r in summary['campaigns'] if r['target']==name)
    assert int(executions.replace(',',''))==row['stats']['number_of_executed_units']
    assert int(seeds.replace(',',''))==row['seed_files']
    assert int(evolved.replace(',',''))==row['evolved_files']
    assert float(duration)==round(row['elapsed_seconds'],2)
    assert int(rss)==row['stats']['peak_rss_mb']
for name in ['summary.json','completion-verification.json','origin-verification.json','binaries.json']:
    assert sha(root/name)==sha(handoff/name)
assert sha(root/'independent-review.json')==sha(Path('/tmp/oriole-version-fuzz-final-independent-review.json'))
docs=[root/'README.md',repo/'README.md',repo/'docs/review.md']
links=[]
for path in docs:
    for label,target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',path.read_text()):
        if 'version-consistent-fuzz' in target or path==root/'README.md':
            if not target.startswith(('http:','https:','#')):
                assert (path.parent/target.split('#')[0]).exists()
                links.append({'document':str(path.relative_to(repo)),'target':target})
report={'scope':'Read-only factual review of published fuzz README and top-level README/review links against immutable handoff; no compiler/parser/fuzz reruns.',
        'outcome':'passed','corrections_required':[],
        'documents':{str(path.relative_to(repo)):sha(path) for path in docs},
        'evidence_archive_sha256':sha(root/'evidence.tar.gz'),'outer_members_verified':len(actual),
        'handoff_manifest_sha256':sha(handoff/'artifact-manifest.json'),
        'checked':{'table_rows':6,'executions':14502453,'initial_seed_files':26689,'empty_seed_files':3,
                   'evolved_files':15876,'origins':26937,'source_files':349,'archive_members':42978},
        'scope_review':['ASan and LeakSanitizer scope, retrospective cargo-fuzz identity, initial incomplete review versus final complete review, source-specific bounded evidence and retained compatibility failures are stated accurately.',
                        'Top-level 14.50-million rounding and links agree with the detailed report. No general memory-safety, semantic-compatibility, production-readiness or faster-than-Expat claim is made.'],
        'links_verified':links}
out=Path('/tmp/oriole-version-fuzz-docs-review.json')
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':sha(out),'outcome':'passed'}))
