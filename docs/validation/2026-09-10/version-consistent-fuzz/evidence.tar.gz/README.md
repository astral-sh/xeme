# Final runtime fuzz campaigns

Six ASan libFuzzer targets exercised frozen Oriole `4b11ace3d89fe6b7bf66ca55290eb23444f11de2` for **14,502,453 reported executions**. Each campaign ran **601.14–601.24 seconds**. All replay, campaign and controller exits were zero, with no crash artifacts or harness timeouts. Independent saved-evidence review rehashed 42,973 files and reconstructed the final counters from the raw logs.

| Target | Executions | Captured seed files | Evolved corpus files |
| --- | ---: | ---: | ---: |
| parse | 5,705,335 | 250 | 3,893 |
| streaming | 3,069,106 | 5,000 | 3,928 |
| ffi | 3,178,013 | 1,001 | 4,055 |
| ffi_family | 507,652 | 8,189 | 1,331 |
| multibyte | 1,313,667 | 9,484 | 1,769 |
| value_family | 728,680 | 2,765 | 900 |

The package retains every byte of 26,689 captured seed files and 15,876 evolved files. Three captured seeds are empty. Seed-file counts are distinct from libFuzzer's execution counts. Every recorded seed origin was reconstructed from frozen named seeds, the retained differential dataset and the retained earlier corpus archives; all transformations and original hash manifests are included.

## Scope and provenance

The source archive contains exactly 349 hash-frozen files, matching the applicable subset of the root's 358-file snapshot. The six executable binaries are excluded; their exact hashes remain in `binaries.json` and the original results. Build commands, compiler identities, build logs, actual runner scripts, controller receipt, final logs and all source/corpus manifests are retained.

Each fuzz process used a 65,536-byte maximum input, 10-second per-input timeout, 1,536 MiB RSS limit and deterministic seed 20260910. Replay and campaign outer limits were 180 and 690 seconds. Processes ran in four CPU lanes, with parse→multibyte and streaming→value_family sequential within their lanes. Python orchestration itself was not uniformly affinity-pinned. Shared-host conditions remain uncontrolled.

The builds used Ohm Rust 1.98.1-dev and the external Clang ASan runtime. Bounded disassembly shows ASan guards in Rust storage and C-adapter functions. Instrumentation of every standard-library function is not established, and these campaigns make no UBSan claim. **LeakSanitizer was disabled** (`detect_leaks=0`); ownership assertions in individual fuzz targets are separate checks.

The cargo-fuzz executable's hash/version was captured retrospectively during review, not before the build. Its current 0.13.2 source explains the generated sanitizer and coverage flags; recorded build commands/logs and representative Rust disassembly supply separate evidence. This distinction is preserved in the initial build review.

## Review history and limitations

The initial orchestration review observed four completed campaigns and two pending campaigns. It is retained unchanged beside the later complete-results review. The initial runner review documented interruption/exception cleanup gaps and incomplete final evidence checks. No live runner edits or interrupted campaigns occurred. A separate completion verifier and the independent final audit require completed six-target summaries, two successful runs per target, actual final statistics and durations, empty artifact directories, and unchanged source, binary, runner, manifests and corpus bytes.

The parent-authored original-controller completion receipt records tool session 46928 with exit zero. Independent review compares that receipt with the saved final controller/child records; it did not attach to the parent's tool session. These bounded campaigns cover this exact source/build and explored inputs. They do not prove that all inputs are safe, replace semantic conformance testing, or certify production deployment.

`archive-members.json.gz` records every regular member's size and SHA-256; `artifact-manifest.json` records every outer artifact. The companion readback verifier opens all archives and rehashes all stored member bytes. No compiler, parser, or fuzz target is rerun while packaging or verifying.
