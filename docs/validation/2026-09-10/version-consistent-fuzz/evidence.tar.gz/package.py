"""Package completed final fuzz evidence and re-read every archive member."""
from pathlib import Path
import base64
import gzip
import hashlib
import io
import json
import shutil
import tarfile

ROOT = Path('/tmp/oriole-version-fuzz')
OUT = Path('/tmp/oriole-version-fuzz-handoff')
TARGETS = ['parse', 'streaming', 'ffi', 'ffi_family', 'multibyte', 'value_family']
REVIEW = Path('/tmp/oriole-version-fuzz-final-independent-review.json')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return digest(path.read_bytes())

def load(path):
    return json.loads(path.read_text())

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

assert sha(REVIEW) == '49969e796a1acbfe41ed9c05a2ac216c89c05f63482bb9d5dee4008d00a00e22'
review = load(REVIEW)
assert review['outcome'] == 'passed' and review['total_executions'] == 14502453
# This is a fresh read after the independent audit, including corpus files/logs.
assert all(sha(Path(path)) == expected for path, expected in review['sha256'].items())
source = load(ROOT / 'campaign-source.json')
assert len(source['files']) == 349
OUT.mkdir(exist_ok=False)
archive_index = {}

def archive(name, items):
    members = {}
    with (OUT / name).open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                for path, relative in items:
                    assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
                    assert relative not in members
                    data = path.read_bytes()
                    before = digest(data)
                    info = tarfile.TarInfo(relative)
                    info.mode = 0o644
                    info.size = len(data)
                    info.mtime = 0
                    tar.addfile(info, io.BytesIO(data))
                    assert sha(path) == before
                    members[relative] = {'sha256': before, 'bytes': len(data)}
    archive_index[name] = members

def copy(path, name=None):
    dest = OUT / (name or path.name)
    assert not dest.exists()
    shutil.copyfile(path, dest)
    assert sha(dest) == sha(path)

# Reconstruct every origin, including transformed differential corpus inputs.
dataset = Path('/tmp/oriole-buffers-final/differential/corpus.json')
documents = {}
for row in load(dataset):
    data = base64.b64decode(row['base64'])
    assert digest(data) == row['sha256']
    documents[row['sha256']] = data
origin_archives = {}
archive_bytes = {}
origin_rows = []
for target in TARGETS:
    directory = ROOT / 'campaigns' / target
    manifest = load(directory / 'initial-manifest.json')
    if manifest['differential_corpus_sha256'] is not None:
        assert manifest['differential_corpus_sha256'] == sha(dataset)
    for path, expected in manifest['archives'].items():
        archive_path = Path(path)
        assert sha(archive_path) == expected
        origin_archives[path] = expected
        members = {}
        with tarfile.open(archive_path, 'r:gz') as tar:
            for member in tar:
                if member.isfile():
                    assert member.name not in members
                    members[member.name] = tar.extractfile(member).read()
        archive_bytes[path] = members
    total_origins = 0
    for name, origins in manifest['inputs'].items():
        captured = (directory / 'initial-corpus' / name).read_bytes()
        assert digest(captured) == name
        assert origins
        for origin in origins:
            if 'seed' in origin:
                data = (ROOT / origin['seed']).read_bytes()
                assert origin['seed'] in source['files']
            elif 'archive' in origin:
                data = archive_bytes[origin['archive']][origin['member']]
            else:
                data = documents[origin['differential_input_sha256']]
                if 'control' in origin:
                    value = origin['control']
                    data = (bytes([value]) if isinstance(value, int) else bytes.fromhex(value)) + data
            assert data == captured
            total_origins += 1
    origin_rows.append({'target':target, 'captured_seed_files':len(manifest['inputs']), 'verified_origin_records':total_origins})
save(OUT / 'origin-verification.json', {'scope':'Every captured seed byte reconstructed from all recorded named-seed, prior archive or transformed differential origins.',
    'differential_corpus_sha256':sha(dataset),'differential_unique_documents':len(documents),
    'archives':origin_archives,'targets':origin_rows,'passed':True})

archive('source.tar.gz', [(ROOT/name, name) for name in sorted(source['files'])])
archive('initial-corpus.tar.gz', [(ROOT/'campaigns'/target/'initial-corpus'/name, target+'/'+name)
    for target in TARGETS for name in sorted(load(ROOT/'campaigns'/target/'initial-manifest.json')['inputs'])])
archive('evolved-corpus.tar.gz', [(ROOT/'campaigns'/target/'corpus'/name, target+'/'+name)
    for target in TARGETS for name in sorted(load(ROOT/'campaigns'/target/'result.json')['final_corpus'])])
evidence = []
for name in ['build.py','run_all.py','run_campaign.py','verify_complete.py','campaign-summary.json']:
    evidence.append((ROOT/name,name))
for target in TARGETS:
    for name in [f'build-{target}.log',f'controller-{target}.log']:
        evidence.append((ROOT/name,name))
    for name in ['initial-manifest.json','result.json','replay.log','campaign.log','dynamic-symbols.txt']:
        evidence.append((ROOT/'campaigns'/target/name, f'{target}/{name}'))
archive('evidence.tar.gz', evidence)
origins = [(dataset,'differential-corpus.json'),(Path('/tmp/oriole-prepare-final-fuzz.py'),'prepare.py')]
for path in sorted(origin_archives):
    p = Path(path)
    origins.append((p, 'prior-archives/'+p.parent.name+'/'+p.name))
archive('origins.tar.gz', origins)
reviews = []
for name in ['oriole-version-fuzz-campaign-source-review.json',
             'oriole-version-fuzz-build-orchestration-review.json','oriole-version-fuzz-build-orchestration-audit.py',
             'oriole-version-fuzz-final-independent-review.json','oriole-version-fuzz-final-independent-audit.py']:
    reviews.append((Path('/tmp')/name,name))
for path in sorted(Path('/tmp/oriole-version-fuzz-build-orchestration-review').iterdir()):
    if path.is_file():
        reviews.append((path,'disassembly/'+path.name))
tool_source = Path(load(Path('/tmp/oriole-version-fuzz-build-orchestration-review.json'))['instrumentation']['local_tool_source'])
for name in ['project.rs','options.rs']:
    reviews.append((tool_source/name,'cargo-fuzz-0.13.2-source/'+name))
archive('reviews.tar.gz', reviews)
for name in ['campaign-source.json','build.json','completion-verification.json','controller-completion.json']:
    copy(ROOT/name)
copy(Path('/tmp/oriole-version-final/frozen-source.json'), 'root-frozen-source.json')
copy(Path(__file__), 'package.py')
copy(Path('/tmp/oriole-version-fuzz-handoff-readback.py'), 'readback.py')
save(OUT/'binaries.json', {'scope':'Exact executed binary hashes; executable files are intentionally excluded from this package.',
    'binaries':[{'target':r['target'],'sha256':r['binary_sha256']} for r in review['campaigns']]})
summary = {name:review[name] for name in ['commit','source_files','total_executions','initial_seed_files','initial_empty_seed_files','evolved_corpus_files','campaigns','limitations']}
summary.update({'passed':True,'independent_review_sha256':sha(REVIEW),
    'initial_build_review_sha256':sha(Path('/tmp/oriole-version-fuzz-build-orchestration-review.json')),
    'initial_runner_review_sha256':sha(Path('/tmp/oriole-version-fuzz-campaign-source-review.json')),
    'source_manifest_sha256':sha(ROOT/'campaign-source.json'),
    'origin_records_verified':sum(row['verified_origin_records'] for row in origin_rows),
    'scope':'Six bounded ASan libFuzzer campaigns on one exact source/toolchain/host. No crash artifacts or timeouts were observed; this does not establish exhaustive safety or full compatibility.'})
save(OUT/'summary.json',summary)
(OUT/'README.md').write_text('''# Final runtime fuzz campaigns

Six ASan libFuzzer targets exercised frozen Oriole `4b11ace3d89fe6b7bf66ca55290eb23444f11de2` for **14,502,453 reported executions**. Each campaign ran **601.14–601.24 seconds**. All replay, campaign and controller exits were zero, with no crash artifacts or harness timeouts. Independent saved-evidence review rehashed 42,973 files and reconstructed the final counters from the raw logs.

| Target | Executions | Captured seed files | Evolved corpus files |
| --- | ---: | ---: | ---: |
| parse | 5,705,335 | 250 | 3,893 |
| streaming | 3,069,106 | 5,000 | 3,928 |
| ffi | 3,178,013 | 1,001 | 4,055 |
| ffi_family | 507,652 | 8,189 | 1,331 |
| multibyte | 1,313,667 | 9,484 | 1,769 |
| value_family | 728,680 | 2,765 | 900 |

The package retains every byte of 26,689 captured seed files and 15,876 evolved files. Three captured seeds are empty. Seed-file counts are distinct from libFuzzer's execution counts. Every recorded seed origin was reconstructed from frozen named seeds, the retained differential dataset and the retained earlier corpus archives; all transformations and original hash manifests are included.

## Scope and provenance

The source archive contains exactly 349 hash-frozen files, matching the applicable subset of the root's 358-file snapshot. The six executable binaries are excluded; their exact hashes remain in `binaries.json` and the original results. Build commands, compiler identities, build logs, actual runner scripts, controller receipt, final logs and all source/corpus manifests are retained.

Each fuzz process used a 65,536-byte maximum input, 10-second per-input timeout, 1,536 MiB RSS limit and deterministic seed 20260910. Replay and campaign outer limits were 180 and 690 seconds. Processes ran in four CPU lanes, with parse→multibyte and streaming→value_family sequential within their lanes. Python orchestration itself was not uniformly affinity-pinned. Shared-host conditions remain uncontrolled.

The builds used Ohm Rust 1.98.1-dev and the external Clang ASan runtime. Bounded disassembly shows ASan guards in Rust storage and C-adapter functions. Instrumentation of every standard-library function is not established, and these campaigns make no UBSan claim. **LeakSanitizer was disabled** (`detect_leaks=0`); ownership assertions in individual fuzz targets are separate checks.

The cargo-fuzz executable's hash/version was captured retrospectively during review, not before the build. Its current 0.13.2 source explains the generated sanitizer and coverage flags; recorded build commands/logs and representative Rust disassembly supply separate evidence. This distinction is preserved in the initial build review.

## Review history and limitations

The initial orchestration review observed four completed campaigns and two pending campaigns. It is retained unchanged beside the later complete-results review. The initial runner review documented interruption/exception cleanup gaps and incomplete final evidence checks. No live runner edits or interrupted campaigns occurred. A separate completion verifier and the independent final audit require completed six-target summaries, two successful runs per target, actual final statistics and durations, empty artifact directories, and unchanged source, binary, runner, manifests and corpus bytes.

The parent-authored original-controller completion receipt records tool session 46928 with exit zero. Independent review compares that receipt with the saved final controller/child records; it did not attach to the parent's tool session. These bounded campaigns cover this exact source/build and explored inputs. They do not prove that all inputs are safe, replace semantic conformance testing, or certify production deployment.

`archive-members.json.gz` records every regular member's size and SHA-256; `artifact-manifest.json` records every outer artifact. The companion readback verifier opens all archives and rehashes all stored member bytes. No compiler, parser, or fuzz target is rerun while packaging or verifying.
''')
with (OUT/'archive-members.json.gz').open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
        compressed.write((json.dumps(archive_index,indent=2)+'\n').encode())
files = {path.name:{'sha256':sha(path),'bytes':path.stat().st_size} for path in sorted(OUT.iterdir()) if path.is_file()}
save(OUT/'artifact-manifest.json',{'passed':True,'files':files})
# The separate verifier is executed as plain saved-data Python by the caller.
print(json.dumps({'path':str(OUT),'artifacts':len(files),'bytes':sum(r['bytes'] for r in files.values()),
    'archives':len(archive_index),'members':sum(len(r) for r in archive_index.values()),
    'manifest_sha256':sha(OUT/'artifact-manifest.json')}))
