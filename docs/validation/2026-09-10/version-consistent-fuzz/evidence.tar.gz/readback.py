"""Read and hash every member of the immutable final fuzz package."""
from pathlib import Path
import gzip
import hashlib
import json
import tarfile

root = Path('/tmp/oriole-version-fuzz-handoff')
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest = json.loads((root/'artifact-manifest.json').read_text())
assert manifest['passed'] is True
assert {p.name for p in root.iterdir()} == set(manifest['files']) | {'artifact-manifest.json'}
for name, row in manifest['files'].items():
    path = root/name
    assert path.is_file() and path.stat().st_size == row['bytes'] and sha(path.read_bytes()) == row['sha256']
index = json.loads(gzip.decompress((root/'archive-members.json.gz').read_bytes()))
observed = {}
for name, expected in index.items():
    found = {}
    with tarfile.open(root/name,'r:gz') as tar:
        for member in tar:
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            assert member.name not in found
            data = tar.extractfile(member).read()
            found[member.name] = {'sha256':sha(data),'bytes':len(data)}
    assert found == expected
    observed[name] = len(found)
assert observed['source.tar.gz'] == 349 and observed['initial-corpus.tar.gz'] == 26689 and observed['evolved-corpus.tar.gz'] == 15876
summary = json.loads((root/'summary.json').read_text())
assert summary['total_executions'] == sum(r['stats']['number_of_executed_units'] for r in summary['campaigns']) == 14502453
assert summary['initial_seed_files'] == sum(r['seed_files'] for r in summary['campaigns']) == 26689
assert summary['evolved_corpus_files'] == sum(r['evolved_files'] for r in summary['campaigns']) == 15876
assert all(600 <= r['elapsed_seconds'] < 690 and r['artifacts'] == 0 for r in summary['campaigns'])
report = {'passed':True,'package':str(root),'scope':'Readback of saved artifacts/member bytes only; no executable binaries, parser or fuzz runs.',
          'manifest_sha256':sha((root/'artifact-manifest.json').read_bytes()),'artifacts':len(manifest['files']),
          'archives':len(index),'members':sum(observed.values()),'member_counts':observed,
          'total_executions':summary['total_executions'],'verifier_sha256':sha(Path(__file__).read_bytes())}
out = Path('/tmp/oriole-version-fuzz-handoff-readback.json')
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':sha(out.read_bytes()),**report}))
