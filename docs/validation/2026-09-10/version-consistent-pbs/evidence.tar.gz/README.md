# Final-version PBS distribution follow-up

The full PBS workflow [34516979948](https://github.com/astral-sh/oriole/actions/runs/34516979948) **failed** on the unchanged CPython XML suite. This report preserves that result. Its head was Oriole `4b11ace3d89fe6b7bf66ca55290eb23444f11de2`.

The archive validator succeeded. Each of the two custom-suite invocations ran 22 tests with 5 skips (17 non-skipped successes). The installed-identity and glibc 2.17 CI steps were skipped after XML-suite failure.

## Distribution and local follow-up

The downloaded 53,609,802-byte distribution archive has SHA-256 `504b3457b6ed8205f9f884bd1c454504e041982f55ce24e85aab20ca7793050e`. This hash was computed locally: CI did not produce its archive-SHA file because that later step was skipped. All 64 bundle source hashes match Git `4b11ace`; the archive's `libexpat.a` hash exactly matches the CI bundle. The stable Rust 1.98.1 distribution build differs from the local Ohm and PGO builds; this is source identity, not binary equivalence.

Installed built-in `pyexpat` and `_elementtree` agree on `oriole_compat_2.8.4` / `(2, 8, 4)`. The original glibc 2.17 script ran locally in the pinned CentOS image with networking disabled and read-only mounts. Its 1,024 threaded parses passed, then its XML subprocess failed the same two assertions; script/container exit 1, XML exit 2. **The local glibc gate also failed.** The saved dynamic-symbol list has no GLIBC requirement newer than 2.17; actual loading and the threaded subcheck are separate supporting observations.

Separate verbose host and glibc 2.17 diagnostic runs each executed 802 methods, with 2 failures, 13 skips and 3 expected failures. All 802 recorded method statuses match. The failures are `BufferTextTest.test1` and `CDATAHandlerTest.test_handlers`. No test edits, assertion waivers, or changed test bounds were used.

## Counts and the local harness gap

CI first ran 802 methods, then reran 4 methods selected by two broad name filters: 806 total method executions and 4 failure occurrences, representing the same 2 failing methods. CI enables the CPU test resource; the original glibc script and local verbose command do not. This explains CI's 12 versus the local 13 skips.

Earlier local harness runs reported 803 methods and 31 skips. Their one-time startup loader was bypassed by fresh `_elementtree` imports, which selected the managed interpreter's incompatible built-in extension. Thus 19 accelerator-specific tests were skipped. In the PBS distribution 18 of those execute successfully and one still skips for its 2 GiB memory requirement. The pure-Python `NoAcceleratorTest` skips during class setup with the working accelerator, explaining 802 rather than 803. Those earlier reports remain unchanged and are now explicitly limited; this package does not claim they exercised the full accelerator suite. The detailed report preserves all 22 changed statuses and exact fresh-import probes.

## Contents and limits

`report.json` records the outcomes, commands, identities and count reconciliation. `followup.tar.gz` includes original logs, probes, both analysis versions, the old local comparison log/loader, and root's independent saved-evidence audit. `ci-evidence.tar.gz` preserves downloaded logs and bundle/TLS manifests. `source-excerpts.tar.gz` includes the exact Oriole bundle sources and unchanged CPython/PBS test wrappers. `archive-members.json` records every packaged regular member's size and hash.

The initial count-analysis attempt did not handle multiline unittest headers and failed its own assertion. Its source is retained; correcting analysis required no test rerun. Executable libraries, interpreter, downloaded distribution and extracted tree are excluded, with their exact identities recorded. These local follow-ups do not turn skipped CI steps into completed CI steps or change the workflow failure. A fresh-import harness repair and text-boundary implementation are separate subsequent work.
