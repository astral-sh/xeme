from pathlib import Path
import hashlib, io, json, subprocess, tarfile

ROOT=Path('/tmp/oriole-pbs-version-followup')
CI=Path('/tmp/oriole-pbs-version-final')
OUT=Path('/tmp/oriole-pbs-version-followup-handoff')
REPO=Path('/home/dev-user/code/oss/oriole')
sha=lambda data:hashlib.sha256(data).hexdigest()
OUT.mkdir(exist_ok=False)
archives={}
def archive(name,items):
    members={}
    with tarfile.open(OUT/name,'w:gz',compresslevel=6) as out:
        for key,value in sorted(items.items()):
            data=value.read_bytes() if isinstance(value,Path) else value
            info=tarfile.TarInfo(key);info.size=len(data);info.mode=0o644;info.mtime=0
            out.addfile(info,io.BytesIO(data))
            members[key]={'bytes':len(data),'sha256':sha(data)}
    archives[name]=members

items={str(p.relative_to(ROOT)):p for p in ROOT.rglob('*') if p.is_file() and 'extracted' not in p.relative_to(ROOT).parts}
items['extract.py']=Path('/tmp/oriole-pbs-version-followup-extract.py')
items['root-review.json']=Path('/tmp/oriole-pbs-version-root-review.json')
items['root-audit.py']=Path('/tmp/oriole-pbs-version-root-audit.py')
items['prior-local-static-consumer-fix-tests.log']=Path('/tmp/oriole-version-final-consumer-validation/cpython/static-consumer-fix/tests.log')
items['prior-local-sitecustomize.py']=Path('/tmp/oriole-version-final-consumer-validation/cpython/static-consumer-fix/sitecustomize.py')
archive('followup.tar.gz',items)
items={str(p.relative_to(CI)):p for p in (CI/'validation').rglob('*') if p.is_file()}
items['failed-steps.log']=CI/'failed-steps.log'
archive('ci-evidence.tar.gz',items)
bundle=json.loads((CI/'validation/oriole-bundle/manifest.json').read_text())
items={}
for path,expected in bundle['sources'].items():
    data=subprocess.check_output(['git','show','4b11ace:'+path],cwd=REPO)
    assert sha(data)==expected,(path,expected)
    items['oriole/'+path]=data
for path in ['.github/workflows/pbs.yml','integration/python-build-standalone/test-old-glibc.py']:
    items['oriole/'+path]=subprocess.check_output(['git','show','4b11ace:'+path],cwd=REPO)
for name in json.loads((ROOT/'report.json').read_text())['test_count_and_coverage']['upstream_six_module_hashes_exact']:
    items['cpython/Lib/test/'+name+'.py']=ROOT/'extracted/python/install/lib/python3.12/test'/f'{name}.py'
items['cpython/Tools/scripts/run_tests.py']=ROOT/'extracted/python/build/run_tests.py'
items['cpython/LICENSE']=Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/LICENSE')
items['pbs/pythonbuild/testdist.py']=Path('/home/dev-user/.cache/oriole/upstream/python-build-standalone-a455388/pythonbuild/testdist.py')
archive('source-excerpts.tar.gz',items)
for name in ['report.json','extraction.json','github-run.json']:(OUT/name).write_bytes((ROOT/name).read_bytes())
(OUT/'root-review.json').write_bytes(Path('/tmp/oriole-pbs-version-root-review.json').read_bytes())
(OUT/'package.py').write_bytes(Path(__file__).read_bytes())
(OUT/'archive-members.json').write_text(json.dumps(archives,indent=2)+'\n')
(OUT/'README.md').write_text('''# Final-version PBS distribution follow-up

The full PBS workflow [34516979948](https://github.com/astral-sh/oriole/actions/runs/34516979948) **failed** on the unchanged CPython XML suite. This report preserves that result. Its head was Oriole `4b11ace3d89fe6b7bf66ca55290eb23444f11de2`.

The archive validator succeeded. Each of the two custom-suite invocations ran 22 tests with 5 skips (17 non-skipped successes). The installed-identity and glibc 2.17 CI steps were skipped after XML-suite failure.

## Distribution and local follow-up

The downloaded 53,609,802-byte distribution archive has SHA-256 `504b3457b6ed8205f9f884bd1c454504e041982f55ce24e85aab20ca7793050e`. This hash was computed locally: CI did not produce its archive-SHA file because that later step was skipped. All 64 bundle source hashes match Git `4b11ace`; the archive's `libexpat.a` hash exactly matches the CI bundle. The stable Rust 1.98.1 distribution build differs from the local Ohm and PGO builds; this is source identity, not binary equivalence.

Installed built-in `pyexpat` and `_elementtree` agree on `oriole_compat_2.8.4` / `(2, 8, 4)`. The original glibc 2.17 script ran locally in the pinned CentOS image with networking disabled and read-only mounts. Its 1,024 threaded parses passed, then its XML subprocess failed the same two assertions; script/container exit 1, XML exit 2. **The local glibc gate also failed.** The saved dynamic-symbol list has no GLIBC requirement newer than 2.17; actual loading and the threaded subcheck are separate supporting observations.

Separate verbose host and glibc 2.17 diagnostic runs each executed 802 methods, with 2 failures, 13 skips and 3 expected failures. All 802 recorded method statuses match. The failures are `BufferTextTest.test1` and `CDATAHandlerTest.test_handlers`. No test edits, assertion waivers, or changed test bounds were used.

## Counts and the local harness gap

CI first ran 802 methods, then reran 4 methods selected by two broad name filters: 806 total method executions and 4 failure occurrences, representing the same 2 failing methods. CI enables the CPU test resource; the original glibc script and local verbose command do not. This explains CI's 12 versus the local 13 skips.

Earlier local harness runs reported 803 methods and 31 skips. Their one-time startup loader was bypassed by fresh `_elementtree` imports, which selected the managed interpreter's incompatible built-in extension. Thus 19 accelerator-specific tests were skipped. In the PBS distribution 18 of those execute successfully and one still skips for its 2 GiB memory requirement. The pure-Python `NoAcceleratorTest` skips during class setup with the working accelerator, explaining 802 rather than 803. Those earlier reports remain unchanged and are now explicitly limited; this package does not claim they exercised the full accelerator suite. The detailed report preserves all 22 changed statuses and exact fresh-import probes.

## Contents and limits

`report.json` records the outcomes, commands, identities and count reconciliation. `followup.tar.gz` includes original logs, probes, both analysis versions, the old local comparison log/loader, and root's independent saved-evidence audit. `ci-evidence.tar.gz` preserves downloaded logs and bundle/TLS manifests. `source-excerpts.tar.gz` includes the exact Oriole bundle sources and unchanged CPython/PBS test wrappers. `archive-members.json` records every packaged regular member's size and hash.

The initial count-analysis attempt did not handle multiline unittest headers and failed its own assertion. Its source is retained; correcting analysis required no test rerun. Executable libraries, interpreter, downloaded distribution and extracted tree are excluded, with their exact identities recorded. These local follow-ups do not turn skipped CI steps into completed CI steps or change the workflow failure. A fresh-import harness repair and text-boundary implementation are separate subsequent work.
''')
entries={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(OUT.iterdir()) if p.is_file()}
(OUT/'manifest.json').write_text(json.dumps({'files':entries,'archives':{k:len(v) for k,v in archives.items()}},indent=2)+'\n')
print(json.dumps({'directory':str(OUT),'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'files':len(entries),'archive_members':sum(map(len,archives.values()))}))
