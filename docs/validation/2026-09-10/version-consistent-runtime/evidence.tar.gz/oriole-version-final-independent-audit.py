"""Independently verify saved final-version gate evidence without parser execution."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import os
import re

os.sched_setaffinity(0, {7})
N = Path('/tmp/oriole-version-final-consumer-validation')
P = Path('/tmp/oriole-version-final-pgo-correctness')
B = Path('/tmp/oriole-final-consumer-validation')
C = Path('/tmp/oriole-attlist-capture-reserve')
S = Path('/tmp/oriole-version-final/frozen-source')
inputs = {}
def sha(p):
    p = Path(p)
    h = hashlib.sha256(p.read_bytes()).hexdigest()
    inputs[str(p)] = h
    return h
def read(p):
    sha(p)
    return json.loads(Path(p).read_text())
def check_map(m):
    for p, h in m.items():
        assert sha(p) == h, p

def blocks(path):
    sha(path)
    out = {}; current = None
    for line in path.read_text().splitlines():
        if line.startswith('ORIOLE_BEGIN\t'):
            _, context, name = line.split('\t')
            current = (context, name)
            assert current not in out
            out[current] = []
        elif line.startswith('ORIOLE_RESULT\t'):
            current = None
        elif current is not None:
            out[current].append(line.replace(str(path.parent), '<output>'))
    assert len(out) == 4740
    return out

reports = {}
for root in [N, P]:
    report = read(root / 'report.json')
    assert report['before'] == report['after']
    check_map(report['after'])
    for row in report['rows']:
        if row['name'] != 'w3c-controller':
            assert sha(root / (row['name'] + '.log')) == row['log_sha256']
    reports[str(root)] = {'after_hashes': len(report['after']), 'w3c_invocations': sum(x['name'] == 'w3c-controller' for x in report['rows'])}
    command = read(root / 'w3c-command.json')
    assert command['sha256_before'] == command['sha256_after']
    check_map(command['sha256_after'])
    sha(root / 'verify.py'); read(root / 'verification.json')

old = read(C / 'upstream-api/results.json')
normal = read(N / 'upstream-api/results.json')
pgo = read(P / 'upstream-api/results.json')
assert old == normal == pgo
assert (normal['passed'], normal['failed']) == (4323, 417)
assert len(normal['results']) == 4740
by_key = {(r['context'], r['test']): r for r in normal['results']}
assert len(by_key) == 4740
assert Counter(r['outcome'] for r in normal['results']) == {'pass': 4323, 'fail': 417}
assert normal['selection_complete'] and normal['library_origin_verified'] and not normal['timed_out']
x = blocks(C / 'upstream-api/tests.log'); y = blocks(N / 'upstream-api/tests.log'); z = blocks(P / 'upstream-api/tests.log')
assert x.keys() == y.keys() == z.keys()
changes = [k for k in x if x[k] != y[k]]
assert len(changes) == 12 and all(k[1] == 'test_misc_version' for k in changes)
assert y == z
assert (N / 'upstream-api/tests.log').read_text().replace(str(N / 'upstream-api'), '<output>') == (P / 'upstream-api/tests.log').read_text().replace(str(P / 'upstream-api'), '<output>')
for k in changes:
    assert any('Version mismatch' in s for s in x[k])
    assert any('out of sync' in s for s in y[k])
for root in [C, N, P]:
    manifest = read(root / 'upstream-api/manifest.json')
    assert manifest['chunks'] == list(range(6)) and manifest['deferral'] == [0, 1]
    assert manifest['per_test_seconds'] == 3
    assert manifest['per_test_address_space_bytes'] == 1073741824
    assert manifest['per_test_rss_limit_bytes'] == 805306368
    assert manifest['excluded_internal_tests'] == normal['excluded_internal_tests']

classification = read(N / 'api-classification-current.json')
prior = read(B / 'api-classification.json')
assert classification['source_classification_sha256'] == sha(B / 'api-classification.json')
assert classification['final_verification_sha256'] == sha(N / 'verification.json')
check_map(classification['input_hashes']); check_map(classification['prior_input_hashes'])
assert len(classification['tests']) == 40
counts = Counter(); observed = set()
for test in classification['tests']:
    counts[test['category']] += test['failed_contexts']
    assert len(test['observations']) == test['failed_contexts']
    source = test['source']; assert sha(source['file']) == source['source_sha256']
    assert sha(B / source['body_file']) == source['body_sha256']
    for item in test['observations']:
        r = item['result']; k = (r['context'], r['test'])
        assert k not in observed and r == by_key[k] and r['outcome'] == 'fail'
        observed.add(k)
        assert [s.replace(str(N / 'upstream-api'), '<output>') for s in item['diagnostics']] == [s for s in y[k] if s.startswith(('ERROR:', 'ASSERTION:'))]
assert len(observed) == 417 and counts == classification['category_counts'] == prior['category_counts']
assert classification['comparison'] == prior['comparison']
assert classification['parsebuffer_probe'] == prior['parsebuffer_probe']
assert classification['historical_same_bound_large_input'] == prior['historical_same_bound_large_input']
source = (N / 'upstream-api/adapted/misc_tests.c').read_text()
assert 'versions_equal(&read_version, &parsed_version)' in source and 'xcstrcmp(version_text, XCS("expat_2.8.4"))' in source

native = []
for root in [N, P]:
    report = read(root / 'native/report.json')
    assert len(report['rows']) == 6
    for row in report['rows']:
        name = row['name']; path = root / (name + '.log')
        assert row['returncode'] == 0
        assert sha(path) == row['log_sha256']
        assert sha(root / 'native' / name) == row['binary_sha256']
        baseline = C / 'native' / (name + '.log') if root == N else N / (name + '.log')
        sha(baseline)
        text = path.read_text()
        comparison = text.replace('oriole_compat_2.8.4', 'oriole_0.0.1') if root == N else text
        assert comparison == baseline.read_text()
        if row['case'] == 'allocations':
            assert 'allocation failure sweep passed: 327 scenarios' in text
    native.append({'root': str(root), 'runs': 6, 'passed': 6, 'allocation_scenarios_per_linkage': 327, 'comparison': 'identity-string normalized to9cc' if root == N else 'raw bytes equal to final normal'})

regression = read(N / 'version-regression/report.json')
original = S / 'tests/c/integration.c'
text = original.read_text(); start = text.index('static void version_identity(void)'); end = text.index('\nstatic void XMLCALL', start)
fn = text[start:end]
assert hashlib.sha256(fn.encode()).hexdigest() == regression['function_sha256']
assert sha(original) == regression['integration_source_sha256']
assert sha(N / 'version-regression/version.c') == regression['source_sha256']
assert fn in (N / 'version-regression/version.c').read_text()
for row in regression['rows']:
    assert sha(row['library']) == row['library_sha256']
    assert sha(N / 'version-regression' / row['name']) == row['binary_sha256']
    assert sha(N / 'version-regression' / (row['name'] + '.log')) == row['log_sha256']
    assert row['exit_code'] == row['expected_exit_code'] == (-6 if row['name'] == 'old9cc' else 0)

w3c = []
old_summary = read(B / 'w3c/summary.json')
for root in [N, P]:
    summary = read(root / 'w3c/summary.json')
    for key in ['catalog_descriptors', 'selected_descriptors', 'chunks', 'worker_limits', 'resolver_limits', 'catalog_source_sha256']:
        assert summary[key] == old_summary[key]
    assert summary['selected_descriptors'] == 2001 and summary['catalog_descriptors'] == 2585
    assert not summary['worker_failures']
    assert sha(root / 'tools/w3c.py') == summary['harness_sha256']
    for command in summary['commands']:
        assert command['returncode'] == 0 and not command['timed_out']
    for engine in ['reference', 'oriole']:
        data = read(root / 'w3c' / (engine + '.json'))
        baseline = read(B / 'w3c' / (engine + '.json'))
        assert data['rows'] == baseline['rows'] and len(data['rows']) == 6003
        assert len({(x['id'], x['chunk']) for x in data['rows']}) == 6003
        assert sha(data['library']) == data['sha256'] == summary['engines'][engine]['sha256']
        count = Counter()
        for row in data['rows']:
            result = row['result']; assert not result['resolver_errors']
            if row['type'] == 'error':
                count['optional'] += 1
            else:
                accepted = result['status'] == 1
                should_accept = row['type'] in ['valid', 'invalid']
                count['mandatory_pass' if accepted == should_accept else 'mandatory_fail'] += 1
        assert count == {'mandatory_pass': 4962, 'mandatory_fail': 960, 'optional': 81}
        w3c.append({'root': str(root), 'engine': engine, 'rows': 6003, 'exact_previous_rows': True, 'counts': dict(count)})
suite = Path(read(N / 'w3c-command.json')['command'][read(N / 'w3c-command.json')['command'].index('--suite') + 1])
for relative, h in old_summary['catalog_source_sha256'].items():
    assert sha(suite / relative) == h

for root in [N, P]:
    manifest = read(root / 'cpython/manifest.json')
    for name, record in manifest['files'].items():
        assert sha(root / 'cpython' / name) == record['sha256']
    assert len(manifest['files']) == manifest['file_count']
    assert sum(x['size'] for x in manifest['files'].values()) == manifest['bytes']

# No parent generators are imported or executed; all evidence above was read.
sha(__file__)
result = {
    'scope': 'Independent stdlib-only saved-evidence arithmetic, source and hash review on CPU7. No parser execution, C/Rust build, test rerun, fuzzing or benchmark performed by this audit. Separate reviewer-owned CPython campaigns are linked through their frozen manifests.',
    'status': 'Verified final API/native/W3C outcomes and provenance with explicit collection-history limits.',
    'api': {'contexts': 4740, 'passed': 4323, 'failed': 417, 'failed_test_names': 40, 'unchanged_result_json_vs9cc': True, 'normal_diagnostic_changes': 12, 'pgo_full_output_path_normalized_log_equal': True, 'first_failure': 'The12 version tests now pass numeric consistency and fail only the unchanged literal expat_2.8.4 identity assertion; all remain failures.', 'categories': dict(counts), 'historical_fixed_new_retained': [584,14,403], 'bounds': {'seconds_per_test':3, 'address_bytes':1073741824, 'requested_rss_bytes':805306368}, 'private_tests_excluded':len(normal['excluded_internal_tests'])},
    'native': native,
    'version_regression': {'exact_final_function_extracted': True, 'old9cc_exit': -6, 'reference_exit': 0, 'final_exit': 0, 'scope': 'Stored ordinary C regression, not a sanitizer run; new final native integration test also includes this exact function.'},
    'w3c': {'rows': w3c, 'suite_files_rehashed':len(old_summary['catalog_source_sha256']), 'completed_scans_per_final_artifact':1, 'normal_controller_invocations':2, 'optimized_controller_invocations':1, 'normal_history': 'One complete normal scan produced the retained worker JSON/logs and summary. The accidental second wrapper invocation failed at OUT.mkdir(exist_ok=False) before worker parsing; it overwrote the outer controller log and w3c-command.json only. The wrapper did not propagate worker exit1 and printed the first scan summary. First outer log/command metadata are not separately retained, though per-launch parent rows/hashes are. A missing parent final assertion was repaired by saved-evidence before/after/current hash verification.', 'outcome_limits': 'Both engines retain960 mandatory failures against the unchanged Fifth Edition catalog selection. Matching pinned Expat fourth-edition-default acceptance is not a Fifth Edition conformance pass. No canonical output comparison. Historical Rust30 name controls are not a full Rust W3C campaign.'},
    'reports': reports,
    'historical_limits': ['The selected-allocator ParseBuffer probe remains historical9cc evidence; the final original test outcome and first assertion are unchanged, but no final-version isolated replay is claimed.', 'Same-bound1GiB buffer and2GiB stream reference evidence remains historical. No prior390 allocation/time numbers are claimed for final4b; no raised bounds or diagnostic passes replace original failures.', 'Native C ASan/UBSan coverage does not instrument the Rust libraries; leak sanitizer disabled, selected allocator zero-live/failure sweeps retained.'],
    'input_sha256': inputs,
}
out = Path('/tmp/oriole-version-final-independent-review.json')
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'path':str(out), 'sha256':hashlib.sha256(out.read_bytes()).hexdigest(), 'input_count':len(inputs), 'api': [4323,417], 'w3c_rows_per_artifact':12006}))
