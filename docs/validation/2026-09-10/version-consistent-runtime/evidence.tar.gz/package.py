from pathlib import Path
import hashlib,io,json,shutil,tarfile
N=Path('/tmp/oriole-version-final-consumer-validation');P=Path('/tmp/oriole-version-final-pgo-correctness');S=Path('/tmp/oriole-version-final/frozen-source');O=Path('/tmp/oriole-version-final-validation-handoff');O.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();entries={};archives={}
def direct(src,name):
 d=O/name;shutil.copyfile(src,d);entries[name]={'sha256':sha(d),'bytes':d.stat().st_size,'source':str(src)}
def arc(name,base,paths):
 d=O/name;members={}
 with tarfile.open(d,'w:gz',compresslevel=6) as t:
  for p in sorted(paths):
   n=str(p.relative_to(base));b=p.read_bytes();m=tarfile.TarInfo(n);m.mode=0o644;m.mtime=0;m.size=len(b);t.addfile(m,io.BytesIO(b));members[n]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 with tarfile.open(d) as t:
  assert len(t.getnames())==len(members) and set(t.getnames())==set(members)
  for m in t.getmembers():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==members[m.name]['sha256']
 entries[name]={'sha256':sha(d),'bytes':d.stat().st_size};archives[name]={'root':str(base),'members':members}
for name,w in [('normal',N),('optimized',P)]:
 cp=w/'cpython';cm=json.loads((cp/'manifest.json').read_text());cr=json.loads((cp/'review.json').read_text());assert len(cr['configurations'])==4
 for n,m in cm['files'].items():assert sha(cp/n)==m['sha256'] and (cp/n).stat().st_size==m['size']
 for r in cr['configurations']:assert r['reported_upstream_tests']==803 and r['upstream_existing_skips']==31 and len(r['upstream_failures'])==2 and r['strict_exit_code']==2 and r['semantic_tests']==2 and r['semantic_exit_code']==0
 r=json.loads((w/'report.json').read_text());assert r['before']==r['after'];assert all(sha(Path(p))==h for p,h in r['after'].items())
 api=json.loads((w/'upstream-api/results.json').read_text());assert (api['passed'],api['failed'])==(4323,417)
 for f in ['verification.json','api-comparison.json','runtime-source.json']:
  direct(w/f,name+'-'+f)
 direct(cp/'review.json',name+'-cpython-review.json')
 accepted={'.json','.py','.log','.md','.c','.h','.patch','.stdout','.stderr'}
 arc(name+'-evidence.tar.gz',w,[p for p in w.rglob('*') if p.is_file() and p.suffix in accepted and '__pycache__' not in p.parts])
direct(N/'api-classification-current.json','remaining-api-classification.json');direct(N/'version-regression/report.json','version-regression.json');direct(Path('/tmp/oriole-version-final/source.json'),'root-build-source.json');direct(Path('/tmp/oriole-version-final/frozen-source.json'),'full-frozen-source.json');direct(P/'pgo-build-manifest.json','pgo-build-manifest.json');direct(Path('/tmp/oriole-final-consumer-validation/api-classification.json'),'pre-version-api-classification.json');direct(Path('/tmp/oriole-final-consumer-independent-review.json'),'pre-version-independent-review.json')
root_checks=Path('/tmp/oriole-version-final/root-build-checks.json')
if root_checks.exists():
 direct(root_checks,'root-build-checks.json')
 checks=json.loads(root_checks.read_text())
 for n,h in checks['raw_logs'].items():assert sha(root_checks.parent/n)==h
 arc('root-build-raw-logs.tar.gz',root_checks.parent,[root_checks.parent/n for n in checks['raw_logs']])
source=json.loads(Path('/tmp/oriole-version-final/source.json').read_text())
for n,h in source['source_sha256'].items():assert sha(S/n)==h
arc('runtime-source.tar.gz',S,[S/n for n in source['source_sha256']])
old=Path('/tmp/oriole-final-consumer-validation');arc('prior-w3c-and-source-boundary-evidence.tar.gz',old,[old/'w3c-comparison.json',old/'w3c-introduced-diagnostics.json',old/'w3c-source-recovery.json',old/'rust-names.stdout',old/'rust-names-command.json']+[p for p in (old/'w3c').iterdir() if p.is_file()])
direct(Path('/home/dev-user/code/oss/oriole/docs/validation/2026-09-10/w3c/pinned-mirror.tar.gz'),'w3c-pinned-mirror.tar.gz');direct(Path('/tmp/oriole-package-final-version.py'),'package.py')
review=Path('/tmp/oriole-version-final-independent-review.json')
if review.exists():
 direct(review,'final-independent-review.json')
 for p in Path('/tmp').glob('oriole-version-final-independent-audit*.py'):direct(p,p.name)
summary={'commit':'4b11ace3d89fe6b7bf66ca55290eb23444f11de2','runtime_sources':64,'full_frozen_files':358,'normal':{'shared':'ac6a0a6adcabba65ef338d362f438c588ad4a01a9821989bae28f445ba7778ac','static':'7fd04b4de8bf7aa2cc490d35ece6f6c7a45d4106f4247f05d501e793015e43e6'},'optimized':{'shared':'4584afbf7361732cf506f762cf25885cded19ecc36ee6b03053ae674bf809505','static':'66834d59ce8f97a14c6164e832a1b94bcb9293462fe7c019ca01b3d38da700c4'},'version':{'compatibility_string':'oriole_compat_2.8.4','numeric_compatibility':[2,8,4],'implementation':'0.0.1','old_regression_exit':-6,'reference_regression_exit':0,'final_regression_exit':0,'original_version_failures_retained':12},'api_each':{'contexts':4740,'pass':4323,'fail':417,'outcome_differences_from_pre_version':0,'normal_diagnostic_changes_from_pre_version':12,'optimized_log_differences_from_normal_after_paths':0,'historical_987_comparison':{'fixed':584,'retained':403,'newly_failing':14}},'native_each':{'runs':6,'pass':6,'allocation_scenarios_per_linkage':327,'scope':'C ASan/UBSan only, Rust release uninstrumented, LSan disabled. Normal version-label changes accounted separately; final optimized raw outputs exactly equal final normal.'},'cpython_each_build':{'configurations':4,'tests_each':803,'existing_skips_each':31,'known_failures_each':2,'strict_exit_each':2,'separate_semantic_tests_each':2,'separate_semantic_exit_each':0},'w3c_each_build_each_engine':{'selected_descriptors':2001,'chunk_sizes':[1,7,4096],'observations':6003,'mandatory_pass':4962,'mandatory_fail':960,'optional':81,'record_differences_from_prior_current_C_policy':0,'scope':'C Fourth Edition naming under Fifth Edition selection, pinned mirror;954 edition-related observations remain rejected by both engines. No canonical output or full safe Rust conformance claim.'},'collection_note':'Normal controller accidentally invoked W3C twice. The second worker hit the existing-output directory guard before parsing; first completed scan rows, summary, catalog and worker logs are retained and counted once. Only the outer wrapper log/command metadata were overwritten. The wrapper ignored the failed second worker and printed the retained summary. Parent per-launch metadata, initial incorrect interpretation and original controller remain. Separate verification checked parent before/after/current hashes. Optimized W3C ran once. No runtime/test inputs changed.','binary_exclusion':'Compiled libraries and executables, Cargo caches and profiler binaries are excluded; exact identities/manifests/logs/source retained.'}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');entries['summary.json']={'sha256':sha(O/'summary.json'),'bytes':(O/'summary.json').stat().st_size}
(O/'README.md').write_text('''# Final version-consistent runtime validation

This evidence covers Git4b11ace normal ac6a/7fd and optimized4584/6683, with64 exact runtime source hashes. The full build/tool snapshot contains358 files. Compatibility string `oriole_compat_2.8.4` now agrees with the numeric API target; `ORIOLE_VERSION` and Cargo retain implementation0.0.1.

Both original API matrices retain4,323 passes and417 failures across4,740 contexts. Only the12 version-test failure messages move from inconsistent numeric/string metadata to the final expected distinctive-identity literal assertion. No count improvement is claimed. The new C consistency check rejects old9cc and passes Expat/final Oriole. The remaining API category report retains all actual gaps; the historical987 comparison is584 fixed,403 retained and14 newly failing contexts.

Both builds pass six native C ASan/UBSan processes, including327 selected-allocation scenarios per linkage. Rust is uninstrumented and LSan is disabled. All four CPython configurations per build retain803 original tests,31 existing skips and two known failures, with strict exit2. The separate semantic two-test gates pass and do not override the strict suite failures.

Each build's W3C scan retains4,962 mandatory passes,960 mandatory failures and81 optional observations per engine. All6,003 raw rows per engine exactly match the prior current C-policy scan. Both engines reject954 Fifth Edition name observations under the C interface's deliberate Fourth Edition policy. The older5,916/6 Oriole score is historical. No full safe Rust or canonical-output claim is made.

A normal-controller adaptation accidentally invoked W3C twice and changed one parent final assertion to a bare comparison. The second worker was stopped by the existing-output directory guard before parsing. The first complete rows, summary, catalog and worker logs remain intact and count once. Only outer wrapper log/command metadata were overwritten; the wrapper ignored the failed worker and printed the retained summary. Original controller, per-launch metadata and initial incorrect interpretation are retained. A separate audit proved parent before/after/current hash equality. Optimized collection used the corrected controller exactly once. This mistake and all original failures remain visible.

Compiled binaries and caches are omitted. Source maps, source files, original reports/logs, commands, reference identities, comparison rows, selected input archive and member hashes are preserved. The pinned mirror is retained; official W3C archive identity remains unverified. Earlier9cc/bb43 handoffs stay immutable and describe their earlier version string.
''');entries['README.md']={'sha256':sha(O/'README.md'),'bytes':(O/'README.md').stat().st_size}
(O/'manifest.json').write_text(json.dumps({'entries':entries,'archives':archives,'entry_count':len(entries),'bytes':sum(x['bytes'] for x in entries.values())},indent=2)+'\n');print(json.dumps({'manifest':sha(O/'manifest.json'),'entries':len(entries),'members':sum(len(a['members']) for a in archives.values()),'bytes':sum(x['bytes'] for x in entries.values())},indent=2))
