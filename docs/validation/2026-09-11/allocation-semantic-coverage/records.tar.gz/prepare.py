from pathlib import Path
import ast
import collections
import difflib
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parent
BASE = Path('/tmp/oriole-reference-frame-api-gates/api-native/upstream-api')
HISTORY = Path('/tmp/oriole-grammar-allocation-audit')
LIBRARY = Path('/tmp/oriole-reference-frame-pgo-study/pgo/runs/run-i9x6lhki/use/liboriole_expat.so')
SELECTED = ['test_alloc_public_entity_value', 'test_alloc_nested_groups', 'test_alloc_notation', 'test_alloc_public_notation', 'test_alloc_system_notation', 'test_alloc_dtd_default_handling']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write_json = lambda p, value: p.write_text(json.dumps(value, indent=2) + '\n')
original = json.loads((BASE / 'results.json').read_text())
manifest = json.loads((BASE / 'manifest.json').read_text())
assert collections.Counter(row['outcome'] for row in original['results']) == {'pass': 4347, 'fail': 391, 'timeout': 2}
assert sha(LIBRARY) == manifest['library_sha256'] == 'd3c43850247b83aa3089b7f08deb31a084ee2aecb47b52d27e9d05e97b0e1bd4'
original_pins = {str(p.relative_to(BASE)): sha(p) for p in sorted(BASE.rglob('*')) if p.is_file()}
shutil.copytree(BASE / 'adapted', ROOT / 'adapted')
shutil.copytree(BASE / 'lib', ROOT / 'lib')
shutil.copyfile(LIBRARY, ROOT / 'liboriole_expat.so')
shutil.copyfile(BASE / 'manifest.json', ROOT / 'original-manifest.json')
shutil.copyfile(BASE / 'results.json', ROOT / 'original-results.json')
shutil.copyfile('/tmp/oriole-reference-frame-pgo-study/source.json', ROOT / 'selected-source.json')
shutil.copyfile('/tmp/oriole-reference-frame-pgo-study/pair-report.json', ROOT / 'selected-build.json')
source = (BASE / 'adapted/alloc_tests.c').read_text()
historical_source = (HISTORY / 'adapted/alloc_tests.c').read_text()
modified = source
changes = []
for name in SELECTED:
    start = source.index('START_TEST(' + name + ')')
    end = source.index('END_TEST', start) + len('END_TEST')
    body = source[start:end]
    matched = re.findall(r'const int max_alloc_count = (\d+);', body)
    assert len(matched) == 1
    changed = body.replace('const int max_alloc_count = ' + matched[0] + ';', 'const int max_alloc_count = 512;')
    hstart = historical_source.index('START_TEST(' + name + ')')
    hend = historical_source.index('END_TEST', hstart) + len('END_TEST')
    assert changed == historical_source[hstart:hend]
    modified = modified.replace(body, changed, 1)
    changes.append({'test': name, 'line': source[:start].count('\n') + 1, 'old_ceiling': int(matched[0]), 'diagnostic_ceiling': 512, 'body_sha256_before': hashlib.sha256(body.encode()).hexdigest(), 'body_sha256_after': hashlib.sha256(changed.encode()).hexdigest(), 'identical_to_historical_raised_body': True})
(ROOT / 'adapted/alloc_tests.c').write_text(modified)
(ROOT / 'retry-ceilings.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True), modified.splitlines(True), fromfile='alloc_tests.c', tofile='alloc_tests.c')))
assert len(re.findall(r'^\+  const int max_alloc_count = 512;$', (ROOT / 'retry-ceilings.patch').read_text(), re.M)) == 6
for path in (ROOT / 'adapted').iterdir():
    if path.name != 'alloc_tests.c':
        assert path.read_bytes() == (BASE / 'adapted' / path.name).read_bytes()
assert re.sub(r'const int max_alloc_count = \d+;', 'const int max_alloc_count = <ceiling>;', modified) == re.sub(r'const int max_alloc_count = \d+;', 'const int max_alloc_count = <ceiling>;', source)
rows = [r for r in original['results'] if r['test'] in SELECTED]
assert len(rows) == 72 and all(r['outcome'] == 'fail' and r['code'] == 100 for r in rows)
contexts = {f'chunksize={chunk} deferral={mode}' for chunk in range(6) for mode in range(2)}
assert {(r['context'], r['test']) for r in rows} == {(context, test) for context in contexts for test in SELECTED}
log = (BASE / 'tests.log').read_text()
blocks = []
for m in re.finditer(r'^ORIOLE_BEGIN\t([^\t\n]+)\t([^\t\n]+)\n(.*?)^ORIOLE_RESULT\t\1\t\2\t([^\n]+)\n', log, re.M | re.S):
    if m[2] in SELECTED:
        blocks.append(m[0])
assert len(blocks) == 72
(ROOT / 'original-selected-failures.log').write_text(''.join(blocks))
history = json.loads((HISTORY / 'report.json').read_text())
hrows = [r for r in history['results'] if r['test'] in SELECTED]
assert len(hrows) == 72 and all(r['outcome'] == 'pass' for r in hrows)
write_json(ROOT / 'historical-selected-results.json', {'report_path': str(HISTORY / 'report.json'), 'report_sha256': sha(HISTORY / 'report.json'), 'library_sha256': history['library_sha256'], 'limits': history['limits'], 'results': hrows})
compile_command = [s.replace(str(BASE), str(ROOT)) for s in manifest['compile_command']]
compile_command[0] = str(Path(shutil.which(compile_command[0])).resolve())
compile_command[-1] = str(ROOT / 'run01/runtests')
write_json(ROOT / 'preparation.json', {
    'status': 'prepared_not_executed',
    'scope': 'Six separate raised-ceiling diagnostic tests, twelve contexts each; original matrix and all non-ceiling source bytes remain unchanged. Not a replacement API matrix, benchmark, or exhaustive OOM validation.',
    'selected_runtime': {'measured_head': '0f66d54ac8418f0a6e628ad18570677a19c9ed45', 'library_path': str(LIBRARY), 'library_sha256': sha(LIBRARY), 'source_manifest_sha256': sha(ROOT / 'selected-source.json'), 'build_report_sha256': sha(ROOT / 'selected-build.json')},
    'original_base': str(BASE), 'original_files': original_pins,
    'original_matrix_sha256': sha(BASE / 'results.json'),
    'selected_tests': SELECTED, 'expected_contexts': sorted(contexts), 'expected_configurations': 72,
    'ceiling_changes': changes, 'retry_patch_sha256': sha(ROOT / 'retry-ceilings.patch'),
    'limits': {'test_seconds': 15, 'address_space_mib': 4096, 'rss_mib': 3072, 'total_test_seconds': 300, 'compile_seconds': 120},
    'compile_command': compile_command, 'compiler_sha256': sha(Path(compile_command[0])),
    'environment': {'ORIOLE_CHUNK_MASK': '63', 'ORIOLE_DEFERRAL_MASK': '3', 'ORIOLE_TEST_TIMEOUT': '15', 'ORIOLE_MEMORY_MIB': '4096', 'ORIOLE_RSS_MIB': '3072', 'ORIOLE_SELECTED_TESTS': ','.join(SELECTED)},
    'staged_files': {str(p.relative_to(ROOT)): sha(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name not in ('preparation.json', 'run.py', 'README.md')},
})
assert original_pins == {str(p.relative_to(BASE)): sha(p) for p in sorted(BASE.rglob('*')) if p.is_file()}
print(json.dumps({'status': 'prepared_not_executed', 'configurations': 72, 'changed_files': ['adapted/alloc_tests.c'], 'changed_constants': 6, 'original_tree_unchanged': True, 'preparation_sha256': sha(ROOT / 'preparation.json')}))
