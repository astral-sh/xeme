# Current-source allocation diagnostic preparation

**Prepared, not executed.** This is one bounded replay of six historical diagnostic cases against the selected reference-frame PGO library. It closes a source-age gap only if the new run passes. It does not alter the original harness, runtime, failure allowances, or 4,740-result matrix (4,347 pass, 391 assertion failures, two timeouts).

## Scope

Each of these six upstream tests currently fails its allocation-retry ceiling in all 12 contexts. The original assertion log blocks are saved in `original-selected-failures.log`; the full original matrix and manifest are copied without modification. The test bodies are byte-identical to the historical baseline used by the separate September 10 raised-ceiling diagnostic.

The only staged source changes raise six `max_alloc_count` constants to the previously used 512 bound. `retry-ceilings.patch` contains all six edits. Every fixture, loop, handler, assertion, source line, setup/teardown routine, and runner remains otherwise unchanged. Each resulting selected body is byte-identical to its corresponding historical raised-ceiling body. Other retry ceilings remain at their original values and other tests are excluded through the existing selection environment variable.

| Test | Original retry ceiling | Assertions reached after successful retry |
| --- | ---: | --- |
| `test_alloc_public_entity_value` | 50 | Entity-declaration callback flag is exactly the expected flag. The original external loader also validates accepted external-system/public-ID routes while parsing its nested declaration fixture. |
| `test_alloc_nested_groups` | 20 | Start-element sequence equals `doce`; element-declaration callback flag is set. The dummy declaration callback frees each content model. |
| `test_alloc_notation` | 20 | Both notation and entity declaration callback flags are set for the long-notation fixture. |
| `test_alloc_public_notation` | 20 | Notation callback flag is set for the long-public-ID fixture. |
| `test_alloc_system_notation` | 20 | Notation callback flag is set for the long-system-ID fixture. |
| `test_alloc_dtd_default_handling` | 25 | Accumulated default/character text equals nine LF bytes followed by `<doc>text in doc</doc>`; all 11 original declaration, doctype, comment, PI, CDATA, and unparsed-entity handler flags are set. |

All six retain the original checks that injection first causes a failure and parsing eventually succeeds before the raised limit. The dummy declaration handlers check that callbacks occurred; they do not validate exact declaration argument values, invocation counts, callback ordering, or coordinates. The tests stop their allocation loop at the first successful parse. They therefore do not establish exhaustive OOM coverage for every later allocation or guarantee that each injected allocation failure produces an exact Expat error code.

## Execution and limits

Only the root agent should execute this controller after its elapsed campaign is finished:

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-semantic-diagnostic/run.py
```

This compiles the copied upstream C consumer once using the original `cc -O1 -DXML_TESTING -D_GNU_SOURCE` command with paths remapped to this directory, then runs exactly six tests × six chunk widths (0–5) × two deferral modes (0/1), or 72 configurations. It does not compile Rust. The C consumer and Rust PGO library are not sanitizer-instrumented.

The existing historical diagnostic limits are retained: 15 seconds per context, 4,096 MiB address space per child, 3,072 MiB RSS checked by the existing parent monitor, 300 seconds for the entire test invocation, and a separate 120-second C compile limit. The child address-space limit is enforced with `RLIMIT_AS`; RSS is sampled about every ten 1 ms polls and is not an exact peak-memory bound. On a controller timeout the process group is killed and reaped. No bound is enlarged automatically and the controller refuses to reuse `run01`.

The runner's existing `dladdr(XML_Parse)` output must identify the staged selected library. Its SHA-256 is `d3c43850247b83aa3089b7f08deb31a084ee2aecb47b52d27e9d05e97b0e1bd4`, matching the current full API matrix. The measured source is `0f66d54ac8418f0a6e628ad18570677a19c9ed45`; source/build manifests are included. All original API files are hashed before and after the new execution. The controller saves the compile/test output and all 72 outcomes, including failures, without replacing any original result.

## Historical evidence

`historical-selected-results.json` extracts the 72 passing records for these exact six tests from `/tmp/oriole-grammar-allocation-audit/report.json` (also published in `docs/validation/2026-09-10/final-runtime/allocation-diagnosis.tar.gz`). Its library was `ff5d86621114e464a0b20f108b6308fe155d9e8c87bd764bc00872cf124750f8`. Those historical passes establish the diagnostic's prior result; they are not current-runtime passes.
