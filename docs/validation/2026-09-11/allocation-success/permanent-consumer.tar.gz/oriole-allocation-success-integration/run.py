"""Compile the final permanent C consumer against identified libraries once."""
from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess

root = Path(__file__).parent
worktree = Path('/home/dev-user/code/oss/oriole-allocation-success-coverage')
control = Path('/tmp/oriole-literal-attribute-check-pgo-study')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
source = worktree / 'tests/c/integration.c'
assert not (root / 'results.json').exists()
os.sched_setaffinity(0, {5})
env = os.environ.copy()
for key in ('LD_PRELOAD', 'LD_LIBRARY_PATH', 'DYLD_INSERT_LIBRARIES'):
    env.pop(key, None)
report = {'status': 'incomplete', 'cpu': 5, 'commands': [], 'rows': [],
          'inputs_before': {str(p): sha(p) for p in [source, worktree/'include/expat.h', Path(__file__)]}}

def save():
    (root/'results.json').write_text(json.dumps(report, indent=2)+'\n')

def run(label, command, timeout):
    row = {'label': label, 'command': command, 'timeout_seconds': timeout}
    report['commands'].append(row)
    save()
    result = subprocess.run(command, capture_output=True, text=True, env=env, timeout=timeout)
    row.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
    save()
    assert result.returncode == 0, row
    return result.stdout

try:
    cases = []
    for mode, directory in [('normal', control/'normal'), ('pgo', control/'pgo/runs/run-_j_96iq1/use')]:
        for linkage, suffix in [('shared', 'so'), ('static', 'a')]:
            cases.append((f'oriole-{mode}-{linkage}', directory/f'liboriole_expat.{suffix}', linkage, 'oriole_compat_2.8.4'))
    cases.append(('expat-pgo-shared', Path('/tmp/oriole-pgo-study/expat-use-liboriole_expat.so'), 'shared', 'expat_2.8.4'))
    for label, library, linkage, version in cases:
        directory = root / label
        directory.mkdir()
        report['inputs_before'][str(library)] = sha(library)
        executable = directory/'consumer'
        args = ['/usr/bin/cc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-I'+str(worktree/'include'), str(source), str(library)]
        if linkage == 'shared':
            soname = 'libexpat.so.1' if label.startswith('expat-') else 'liboriole_expat.so'
            (directory/soname).symlink_to(library)
            args.append('-Wl,-rpath,'+str(directory))
        else:
            args.extend(['-ldl', '-lpthread', '-lm'])
        args.extend(['-o', str(executable)])
        run(label+'-build', args, 60)
        loaded = run(label+'-linkage', ['/usr/bin/ldd', str(executable)], 10)
        if linkage == 'shared':
            match = next(line for line in loaded.splitlines() if line.lstrip().startswith(soname+' =>'))
            origin = Path(match.split('=>', 1)[1].strip().split()[0]).resolve()
            assert origin == library.resolve() and sha(origin) == sha(library)
        else:
            assert 'liboriole_expat' not in loaded and 'libexpat.so' not in loaded
        output = run(label+'-run', [str(executable)], 10)
        assert output == f'C ABI full integration passed ({version})\n'
        report['rows'].append({'label': label, 'library_sha256': sha(library), 'executable_sha256': sha(executable), 'version': version, 'namespace_conditions': 12})
        save()
    # Exercise the unchanged CI reference-compiler convention against host Expat.
    flags = shlex.split(run('system-pkg-config', ['pkg-config', '--cflags', '--libs', 'expat'], 10))
    executable = root/'system-consumer'
    run('system-build', ['/usr/bin/cc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', str(source), *flags, '-o', str(executable)], 60)
    loaded = run('system-linkage', ['/usr/bin/ldd', str(executable)], 10)
    origin = Path(next(line for line in loaded.splitlines() if line.lstrip().startswith('libexpat.so.1 =>')).split('=>', 1)[1].strip().split()[0]).resolve()
    output = run('system-run', [str(executable)], 10)
    assert output.startswith('C ABI full integration passed (expat_')
    report['rows'].append({'label': 'system-expat', 'library': str(origin), 'library_sha256': sha(origin), 'executable_sha256': sha(executable), 'stdout': output})
    report['status'] = 'passed'
finally:
    report['inputs_after'] = {path: sha(path) for path in report['inputs_before']}
    report['inputs_unchanged'] = report['inputs_before'] == report['inputs_after']
    save()
    assert report['inputs_unchanged']
print(json.dumps({'status': report['status'], 'consumers': len(report['rows']), 'sha256': sha(root/'results.json')}))
