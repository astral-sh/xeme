# DTD/default-attribute/external-child success probes

**Result: 72/72 derivative conditions passed on the first attempt.** One C compile and three original fixtures × 12 input modes × two frozen libraries. The original 36 allocation-ceiling failures remain failures; the authoritative API matrix remains **4,347 pass / 393 fail**.

| Original fixture | Separate success coverage | Oriole / Expat |
| --- | --- | --- |
| `test_alloc_dtd_default_handling` | Exact original accumulated Default/character bytes; all 11 original handler flags; parent success and no error | 12/12 each |
| `test_alloc_attribute_enum_value` | Exact original external DTD and loader; original attlist callback invoked; child created, completed, and freed; parent success | 12/12 each |
| `test_nsalloc_long_default_in_ext` | Exact original 1,024-character default declaration and external `<e/>` input; original loader; child created, completed, and freed; parent success | 12/12 each |

The third original fixture has no attribute-value callback assertion. Its result establishes successful parsing with that declaration, not a new check of the delivered default value. Handler flags establish invocation; they do not validate every callback argument or invocation count.

## Minimal derivation

[derivation.patch](derivation.patch) replaces each finite allocation retry loop and allocation-schedule assertion with one parse while allocation and reallocation failure counters stay at `-1`. Original XML, expected strings, callback bodies, custom allocator functions, namespace setup, and chunk feeder are retained. Each derivative requires `XML_STATUS_OK` and `XML_ERROR_NONE`.

The standalone adapter records external-child creation, successful final parse and destruction by forwarding those API calls unchanged. Both external fixtures must complete exactly one child and one parent. The enum fixture additionally requires its original attlist handler flag. The DTD fixture retains its original final text and handler-mask assertions verbatim.

The tested modes are the original chunks `0, 1, 2, 3, 4, 5` × reparse deferral `0, 1`. Libraries:

- Accepted PR121 Oriole PGO: `8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a`.
- Expat PGO: `12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0`.

Each worker loads its absolute library path with `dlopen(RTLD_NOW | RTLD_LOCAL)`, checks the `XML_Parse` symbol origin, and uses the original custom allocation suite with injection disabled. There are no resource-policy changes.

## Evidence

[results.json](results.json) retains the one compiler command and all 72 worker commands, stdout, stderr, exits, timestamps, library identities, and input hashes before/after. SHA-256: `43aa241668641f6c857d508dc7a7dca2e34f8ac1c330c662fb805f55f97ce25b`.

[assessment.json](assessment.json) records 303 subsequent saved-source/outcome checks: original body/input/callback equality, immediate worker results, complete mode coverage, library/source hashes, and preservation of all selected original failures. This is a producer recheck, not a separate independent-agent review.

Execution used authorized CPU5. The compile had a 60-second wall bound. Each sequential parser worker had a three-second wall bound, three-second CPU limit, 1 GiB address-space limit, and 768 MiB RSS setting. No reruns occurred. No benchmark, sanitizer, allocation-failure cleanup, or broader compatibility claim is made.

The original results retain SHA-256 `dcda1affc7cfa69d1e77dd60b7c76360e572e2a7767d6d4ded084ab1575647d5`. No original suite or parser source was edited. Original `.inc` extracts and MIT notices are retained alongside the derivative.

## Coverage accounting and next boundary

The preceding namespace probe separately covered the later expanded-name callback assertions for all 12 `test_nsalloc_long_element` configurations: [namespace result](/tmp/oriole-nsalloc-long-element-success/README.md). These three fixtures add 36 success-path configurations at the explicitly stated strengths above. **All 48 original allocation-schedule outcomes remain failures.**

`test_alloc_nested_entities`, the 12 early-child failures, remains unproved by these derivatives. Its original callback specifically expects a child `XML_ERROR_NO_MEMORY` and a parent `XML_ERROR_EXTERNAL_ENTITY_HANDLING`; disabling injection would invalidate that oracle. It was inspected and excluded rather than weakening those assertions.

## Runnable probe and permanent namespace proposal

The already-built standalone worker accepts:

```sh
/tmp/oriole-dtd-default-child-success/probe /absolute/library.so test_alloc_dtd_default_handling 1 0
```

[run.py](run.py) performs the pinned sweep and refuses to overwrite existing results. Copy its source/includes/notices/preparation to a fresh directory for a new campaign.

The proposed direct-link namespace regression is saved separately in [namespace-long-names.patch](/tmp/oriole-nsalloc-long-element-permanent/namespace-long-names.patch), SHA-256 `298ba16e68f6183b2306c76041e4448753bfc641ad15d49517e12551578afe98`. It preserves the exact original XML/name expectations and 12 modes, reuses the integration test's custom allocator, and requires exactly one start/end callback. It is a proposal only and has not been compiled or applied by this reviewer. The saved source check caught and corrected two omitted newline bytes before delivery; the initial draft files remain available as `.draft0`. The executed original namespace probe was unchanged.
