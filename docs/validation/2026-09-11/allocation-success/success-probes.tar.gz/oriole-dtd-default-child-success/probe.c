/* Success-only derivatives. Exact upstream extracts and MIT notices accompany this file. */
#define _GNU_SOURCE
#define XML_DTD 1
#define XML_GE 1
#include "expat.h"
#include <assert.h>
#include <dlfcn.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static __typeof__(&XML_ParserCreate_MM) p_XML_ParserCreate_MM;
static __typeof__(&XML_ParserFree) p_XML_ParserFree;
static __typeof__(&XML_ExternalEntityParserCreate) p_XML_ExternalEntityParserCreate;
static __typeof__(&XML_Parse) p_XML_Parse;
static __typeof__(&XML_GetErrorCode) p_XML_GetErrorCode;
static __typeof__(&XML_SetUserData) p_XML_SetUserData;
static __typeof__(&XML_SetDefaultHandler) p_XML_SetDefaultHandler;
static __typeof__(&XML_SetDoctypeDeclHandler) p_XML_SetDoctypeDeclHandler;
static __typeof__(&XML_SetEntityDeclHandler) p_XML_SetEntityDeclHandler;
static __typeof__(&XML_SetNotationDeclHandler) p_XML_SetNotationDeclHandler;
static __typeof__(&XML_SetElementDeclHandler) p_XML_SetElementDeclHandler;
static __typeof__(&XML_SetAttlistDeclHandler) p_XML_SetAttlistDeclHandler;
static __typeof__(&XML_SetProcessingInstructionHandler) p_XML_SetProcessingInstructionHandler;
static __typeof__(&XML_SetCommentHandler) p_XML_SetCommentHandler;
static __typeof__(&XML_SetCdataSectionHandler) p_XML_SetCdataSectionHandler;
static __typeof__(&XML_SetUnparsedEntityDeclHandler) p_XML_SetUnparsedEntityDeclHandler;
static __typeof__(&XML_SetCharacterDataHandler) p_XML_SetCharacterDataHandler;
static __typeof__(&XML_SetParamEntityParsing) p_XML_SetParamEntityParsing;
static __typeof__(&XML_SetExternalEntityRefHandler) p_XML_SetExternalEntityRefHandler;
static __typeof__(&XML_FreeContentModel) p_XML_FreeContentModel;
static __typeof__(&XML_SetReparseDeferralEnabled) p_XML_SetReparseDeferralEnabled;
static __typeof__(&XML_ExpatVersion) p_XML_ExpatVersion;
static _Noreturn void fail(const char *message) {
  fprintf(stderr, "ASSERTION: %s\n", message);
  exit(100);
}
static XML_Parser g_parser, child_parser;
static unsigned child_created, child_finished, child_freed, parent_finished;
static int g_chunkSize;
static XML_Parser observed_child(XML_Parser parent, const XML_Char *context,
                                 const XML_Char *encoding) {
  if (parent != g_parser || child_parser) fail("Unexpected child relationship");
  child_parser = p_XML_ExternalEntityParserCreate(parent, context, encoding);
  if (child_parser) child_created++;
  return child_parser;
}
static enum XML_Status observed_parse(XML_Parser parser, const char *text,
                                      int length, int final) {
  enum XML_Status status = p_XML_Parse(parser, text, length, final);
  if (status == XML_STATUS_OK && final) {
    if (p_XML_GetErrorCode(parser) != XML_ERROR_NONE) fail("Completed parser has an error");
    if (parser == g_parser) parent_finished++;
    else if (parser == child_parser) child_finished++;
    else fail("Unknown parser completed");
  }
  return status;
}
static void observed_free(XML_Parser parser) {
  if (parser == child_parser) {
    child_freed++;
    child_parser = NULL;
  }
  p_XML_ParserFree(parser);
}
#define XML_ParserCreate_MM p_XML_ParserCreate_MM
#define XML_ParserFree observed_free
#define XML_ExternalEntityParserCreate observed_child
#define XML_Parse observed_parse
#define XML_GetErrorCode p_XML_GetErrorCode
#define XML_SetUserData p_XML_SetUserData
#define XML_SetDefaultHandler p_XML_SetDefaultHandler
#define XML_SetDoctypeDeclHandler p_XML_SetDoctypeDeclHandler
#define XML_SetEntityDeclHandler p_XML_SetEntityDeclHandler
#define XML_SetNotationDeclHandler p_XML_SetNotationDeclHandler
#define XML_SetElementDeclHandler p_XML_SetElementDeclHandler
#define XML_SetAttlistDeclHandler p_XML_SetAttlistDeclHandler
#define XML_SetProcessingInstructionHandler p_XML_SetProcessingInstructionHandler
#define XML_SetCommentHandler p_XML_SetCommentHandler
#define XML_SetCdataSectionHandler p_XML_SetCdataSectionHandler
#define XML_SetUnparsedEntityDeclHandler p_XML_SetUnparsedEntityDeclHandler
#define XML_SetCharacterDataHandler p_XML_SetCharacterDataHandler
#define XML_SetParamEntityParsing p_XML_SetParamEntityParsing
#define XML_SetExternalEntityRefHandler p_XML_SetExternalEntityRefHandler
#define XML_FreeContentModel p_XML_FreeContentModel
#define XML_SetReparseDeferralEnabled p_XML_SetReparseDeferralEnabled
#define XML_ExpatVersion p_XML_ExpatVersion
#define XCS(value) value
#define xcstrcmp strcmp
#define xcslen strlen
#define UNUSED_P(value) (void)(value)
#define START_TEST(name) static void name(void)
#define END_TEST
#include "allocator.c.inc"
#include "allocation-setup.c.inc"
#include "namespace-setup.c.inc"
#include "chunk-feeder.c.inc"
#include "chardata.c.inc"
#include "dummy-handlers.c.inc"
#include "handlers.c.inc"
#include "test_alloc_dtd_default_handling.success.inc"
#include "test_alloc_attribute_enum_value.success.inc"
#include "test_nsalloc_long_default_in_ext.success.inc"

#define LOAD(name) do { \
  void *symbol = dlsym(library, #name); \
  if (!symbol || sizeof(p_##name) != sizeof(symbol)) fail("Missing ABI symbol: " #name); \
  memcpy(&p_##name, &symbol, sizeof(symbol)); \
} while (0)
int main(int argc, char **argv) {
  if (argc != 5) fail("Expected library, test, chunk, deferral");
  char *end = NULL;
  long width = strtol(argv[3], &end, 10);
  if (*end || width < 0 || width > 5) fail("Invalid chunk width");
  long deferral = strtol(argv[4], &end, 10);
  if (*end || deferral < 0 || deferral > 1) fail("Invalid deferral");
  g_chunkSize = (int)width;
  char requested[PATH_MAX], actual[PATH_MAX];
  if (argv[1][0] != '/' || !realpath(argv[1], requested)) fail("Invalid library path");
  void *library = dlopen(requested, RTLD_NOW | RTLD_LOCAL);
  if (!library) fail(dlerror());
  LOAD(XML_ParserCreate_MM);
  LOAD(XML_ParserFree);
  LOAD(XML_ExternalEntityParserCreate);
  LOAD(XML_Parse);
  LOAD(XML_GetErrorCode);
  LOAD(XML_SetUserData);
  LOAD(XML_SetDefaultHandler);
  LOAD(XML_SetDoctypeDeclHandler);
  LOAD(XML_SetEntityDeclHandler);
  LOAD(XML_SetNotationDeclHandler);
  LOAD(XML_SetElementDeclHandler);
  LOAD(XML_SetAttlistDeclHandler);
  LOAD(XML_SetProcessingInstructionHandler);
  LOAD(XML_SetCommentHandler);
  LOAD(XML_SetCdataSectionHandler);
  LOAD(XML_SetUnparsedEntityDeclHandler);
  LOAD(XML_SetCharacterDataHandler);
  LOAD(XML_SetParamEntityParsing);
  LOAD(XML_SetExternalEntityRefHandler);
  LOAD(XML_FreeContentModel);
  LOAD(XML_SetReparseDeferralEnabled);
  LOAD(XML_ExpatVersion);

  Dl_info origin;
  if (!dladdr(dlsym(library, "XML_Parse"), &origin)
      || !realpath(origin.dli_fname, actual) || strcmp(requested, actual))
    fail("XML_Parse came from a different library");
  int namespace_mode = !strcmp(argv[2], "test_nsalloc_long_default_in_ext");
  if (namespace_mode) nsalloc_setup(); else alloc_setup();
  if (!XML_SetReparseDeferralEnabled(g_parser, (XML_Bool)deferral)) fail("Deferral setter failed");
  if (!strcmp(argv[2], "test_alloc_dtd_default_handling")) test_alloc_dtd_default_handling_success();
  else if (!strcmp(argv[2], "test_alloc_attribute_enum_value")) test_alloc_attribute_enum_value_success();
  else if (!strcmp(argv[2], "test_nsalloc_long_default_in_ext")) test_nsalloc_long_default_in_ext_success();

  else fail("Unknown test");
  unsigned expected_children = strcmp(argv[2], "test_alloc_dtd_default_handling") != 0;
  if (parent_finished != 1 || child_created != expected_children
      || child_finished != expected_children || child_freed != expected_children || child_parser)
    fail("Parent/child completion or teardown missing");
  if (g_allocation_count != -1 || g_reallocation_count != -1) fail("Injection was enabled");
  XML_ParserFree(g_parser);
  g_parser = NULL;
  printf("{\"status\":\"passed\",\"version\":\"%s\",\"test\":\"%s\","
         "\"chunk\":%d,\"deferral\":%ld,\"dummy_flags\":%lu,\"parent_finished\":%u,"
         "\"child_created\":%u,\"child_finished\":%u,\"child_freed\":%u,"
         "\"injection_disabled\":true,\"parse_symbol_origin\":\"%s\"}\n",
         XML_ExpatVersion(), argv[2], g_chunkSize, deferral, get_dummy_handler_flags(),
         parent_finished, child_created, child_finished, child_freed, actual);
  dlclose(library);
  return 0;
}
