"""One CPU5 build and at most 72 bounded workers; stop and retain any first mismatch."""
from pathlib import Path
import hashlib
import json
import os
import resource
import signal
import subprocess
import time

ROOT = Path(__file__).parent
SOURCE = Path('/home/dev-user/code/oss/oriole-literal-attribute-check')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
os.sched_setaffinity(0, {5})
assert not (ROOT/'results.json').exists()
preparation = load(ROOT/'preparation.json')
assert preparation['status'] == 'prepared_only'
inputs = {**preparation['source_paths'], str(SOURCE/'include/expat.h'):sha(SOURCE/'include/expat.h'),
          preparation['original_results']['path']:preparation['original_results']['sha256']}
for name, value in preparation['extracted_files'].items():
    inputs[str(ROOT/name)] = value
for name in ('run.py','preparation.json'):
    inputs[str(ROOT/name)] = sha(ROOT/name)
libraries = {
    'expat': {'path':'/tmp/oriole-pgo-study/expat-use-liboriole_expat.so','sha256':'12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'},
    'accepted': {'path':'/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.so','sha256':'8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a'},
}
for row in libraries.values():
    inputs[row['path']] = row['sha256']
assert all(sha(path) == value for path,value in inputs.items())
environment = dict(os.environ)
for name in ('LD_PRELOAD','LD_LIBRARY_PATH','DYLD_INSERT_LIBRARIES'):
    environment.pop(name, None)
report = {'status':'incomplete','scope':'Derivative success only; all original 36 allocation-ceiling failures remain failures.',
          'cpu':5,'commands':[],'libraries':libraries,'inputs_before':inputs,'rows':[],
          'worker_bounds':{'wall_seconds':3,'cpu_seconds':3,'address_space_bytes':1073741824,'rss_setting_bytes':805306368}}
def save():
    (ROOT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
def limits():
    resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
    resource.setrlimit(resource.RLIMIT_RSS,(805306368,805306368))
    resource.setrlimit(resource.RLIMIT_CPU,(3,3))
def run(label, command, timeout, bounded=False):
    row = {'label':label,'command':command,'timeout_seconds':timeout,'start':time.time()}
    report['commands'].append(row); save()
    process = subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=environment,
                               start_new_session=True,preexec_fn=limits if bounded else None,text=True)
    stdout=stderr=''
    try:
        stdout,stderr=process.communicate(timeout=timeout)
    except BaseException:
        os.killpg(process.pid,signal.SIGKILL)
        stdout,stderr=process.communicate()
        row['interrupted_or_timed_out']=True
        raise
    finally:
        row.update({'returncode':process.returncode,'end':time.time(),'stdout':stdout,'stderr':stderr})
        save()
    return row
try:
    build = run('build',['/usr/bin/cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-I'+str(SOURCE/'include'),
                         str(ROOT/'probe.c'),'-ldl','-o',str(ROOT/'probe')],60)
    assert build['returncode'] == 0, build
    report['probe_sha256']=sha(ROOT/'probe')
    for test in preparation['original_tests']:
        for engine,library in libraries.items():
            for chunk in preparation['chunks']:
                for deferral in preparation['deferral']:
                    label=f'{test}-{engine}-chunk{chunk}-deferral{deferral}'
                    row=run(label,[str(ROOT/'probe'),library['path'],test,str(chunk),str(deferral)],3,True)
                    assert row['returncode'] == 0, row
                    actual=json.loads(row['stdout'])
                    children=int(test!='test_alloc_dtd_default_handling')
                    flags={'test_alloc_dtd_default_handling':3839,'test_alloc_attribute_enum_value':32,
                           'test_nsalloc_long_default_in_ext':0}[test]
                    expected={'status':'passed','version':'expat_2.8.4' if engine=='expat' else 'oriole_compat_2.8.4',
                              'test':test,'chunk':chunk,'deferral':deferral,'dummy_flags':flags,'parent_finished':1,
                              'child_created':children,'child_finished':children,'child_freed':children,
                              'injection_disabled':True,'parse_symbol_origin':str(Path(library['path']).resolve())}
                    assert actual == expected and row['stderr']=='', row
                    report['rows'].append({'engine':engine,'test':test,'chunk':chunk,'deferral':deferral,'actual':actual})
                    save()
    assert len(report['rows']) == 72
    report['status']='passed_derivative_success_probes'
except BaseException as exc:
    report['status']='stopped_on_first_failure'
    report['failure']=str(exc)
    raise
finally:
    report['inputs_after']={path:sha(path) for path in inputs}
    report['inputs_unchanged']=report['inputs_after']==inputs
    original=[r for r in load(preparation['original_results']['path'])['results'] if r['test'] in preparation['original_tests']]
    report['original_failures_unchanged']=original==preparation['original_failures']
    save()
    assert report['inputs_unchanged'] and report['original_failures_unchanged']
print(json.dumps({'status':report['status'],'conditions':len(report['rows']),
                  'original_allocation_failures_preserved':36,'results_sha256':sha(ROOT/'results.json')},indent=2))
