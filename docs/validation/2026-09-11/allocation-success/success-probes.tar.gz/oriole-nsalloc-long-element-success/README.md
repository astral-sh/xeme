# Namespace allocation fixture: semantic success probe

**Result: 24/24 derivative conditions pass.** One compile and one run of each condition completed successfully on the first attempt. The original 12 `test_nsalloc_long_element` allocation-ceiling failures remain unchanged.

## What this establishes

The original test installs substantive namespace-triplet callbacks, but the accepted parser exceeds its 30-allocation retry ceiling. This derivative uses its exact XML and expected strings, namespace separator (`' '`), triplet mode, original `triplet_start_checker` / `triplet_end_checker` bodies, allocator functions and chunk feeder.

The original expected expanded element name is:

```text
http://example.org/ thisisalongenoughelementnametotriggerareallocation foo
```

The original expected expanded attribute name is:

```text
http://example.org/ a bar
```

[derivation.patch](derivation.patch) shows the only test-body changes: rename the derivative, replace the retry loop and allocation-schedule assertions with a single parse while both injection counters are `-1`, then require `XML_STATUS_OK`, `XML_ERROR_NONE`, and both original handler flags. No parser resource limit changes. No artificial allocations.

The tested modes match the authoritative matrix: chunk widths `0, 1, 2, 3, 4, 5` × reparse deferral `0, 1`. Both original handlers execute and accept their expected names in all 12 modes for each library:

- Expat PGO: `12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0`.
- Accepted PR121 Oriole PGO: `8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a`.

Each worker loads its absolute library through `dlopen(RTLD_NOW | RTLD_LOCAL)` and checks `XML_Parse`'s `dladdr` origin. Custom allocation remains active with injection disabled; both implementations use the copied original allocator functions.

## Evidence and scope

[preparation.json](preparation.json) binds the upstream extracts and all 12 original failures. [results.json](results.json) retains the compiler command and all 24 commands, stdout, stderr, exits, versions, origins, and before/after input hashes. Its SHA-256 is `0ee464645e8e54607973f1fb77f718ca046031e2c3888fdf4310ca657ed05841`.

The authoritative API results retain SHA-256 `dcda1affc7cfa69d1e77dd60b7c76360e572e2a7767d6d4ded084ab1575647d5`: **4,347 pass / 393 fail**. No original test or parser source was edited. The probe tests one fixture's successful namespace behavior; it does not prove allocation-failure cleanup, all other ceiling-blocked fixtures, callback positions, or full Expat compatibility. It deliberately retains the upstream name checks; it does not claim additional attribute-value assertions.

Execution used CPU5 after root scheduling release. Each parser worker retained a three-second wall bound, three-second CPU limit, 1 GiB address-space limit, and 768 MiB RSS setting. The one C compile had a 60-second bound. No sanitizer or performance claim.

## Run or retain as a regression

The already-built standalone worker accepts:

```sh
/tmp/oriole-nsalloc-long-element-success/probe /absolute/library.so 1 0
```

[run.py](run.py) performs the complete pinned two-library sweep and intentionally refuses to overwrite its existing result. For a fresh campaign, copy the C source, `.inc` files, notices, `preparation.json` and runner to a new directory before running it with an isolated system Python.

The small `success-test.c.inc` plus original checker callbacks is suitable for a permanent native semantic regression alongside the existing failing-allocation gate. Keep that success test separate from the upstream allocation-budget assertions. The exact source fragments and their upstream MIT notices are retained here; no archive layer was created.
