/* Success-only derivative of Expat's namespace allocation test.
 * The exact upstream extracts and MIT notices are retained alongside this file.
 */
#define _GNU_SOURCE
#include "expat.h"
#include <assert.h>
#include <dlfcn.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static struct {
  XML_Parser (*create)(const XML_Char *, const XML_Memory_Handling_Suite *, const XML_Char *);
  void (*destroy)(XML_Parser);
  enum XML_Status (*parse)(XML_Parser, const char *, int, int);
  enum XML_Error (*error)(XML_Parser);
  void (*triplets)(XML_Parser, int);
  void (*user_data)(XML_Parser, void *);
  void (*handlers)(XML_Parser, XML_StartElementHandler, XML_EndElementHandler);
  XML_Bool (*deferral)(XML_Parser, XML_Bool);
  const XML_LChar *(*version)(void);
} api;

static _Noreturn void fail(const char *message) {
  fprintf(stderr, "ASSERTION: %s\n", message);
  exit(100);
}

#define XML_ParserCreate_MM api.create
#define XML_ParserFree api.destroy
#define XML_Parse api.parse
#define XML_GetErrorCode api.error
#define XML_SetReturnNSTriplet api.triplets
#define XML_SetUserData api.user_data
#define XML_SetElementHandler api.handlers
#define XCS(value) value
#define xcstrcmp strcmp
#define XML_FMT_STR "s"
#define START_TEST(name) static void name(void)
#define END_TEST

static XML_Parser g_parser;
static int g_chunkSize;
#include "allocator.c.inc"
#include "namespace-setup.c.inc"
#include "triplet-checkers.c.inc"
#include "chunk-feeder.c.inc"
#include "success-test.c.inc"

#define LOAD(field, name) do { \
  void *symbol = dlsym(library, name); \
  if (!symbol || sizeof(api.field) != sizeof(symbol)) fail("Missing ABI symbol: " name); \
  memcpy(&api.field, &symbol, sizeof(symbol)); \
} while (0)

int main(int argc, char **argv) {
  if (argc != 4) fail("Expected absolute library, chunk width and deferral");
  char *end = NULL;
  long width = strtol(argv[2], &end, 10);
  if (*end || width < 0 || width > 5) fail("Invalid original chunk width");
  long deferral = strtol(argv[3], &end, 10);
  if (*end || deferral < 0 || deferral > 1) fail("Invalid deferral mode");
  g_chunkSize = (int)width;
  char requested[PATH_MAX], actual[PATH_MAX];
  if (argv[1][0] != '/' || !realpath(argv[1], requested)) fail("Invalid library path");
  void *library = dlopen(requested, RTLD_NOW | RTLD_LOCAL);
  if (!library) fail(dlerror());
  LOAD(create, "XML_ParserCreate_MM");
  LOAD(destroy, "XML_ParserFree");
  LOAD(parse, "XML_Parse");
  LOAD(error, "XML_GetErrorCode");
  LOAD(triplets, "XML_SetReturnNSTriplet");
  LOAD(user_data, "XML_SetUserData");
  LOAD(handlers, "XML_SetElementHandler");
  LOAD(deferral, "XML_SetReparseDeferralEnabled");
  LOAD(version, "XML_ExpatVersion");
  Dl_info origin;
  if (!dladdr(dlsym(library, "XML_Parse"), &origin)
      || !realpath(origin.dli_fname, actual) || strcmp(requested, actual))
    fail("XML_Parse came from a different shared library");

  nsalloc_setup();
  if (!api.deferral(g_parser, (XML_Bool)deferral)) fail("Deferral setter failed");
  test_nsalloc_long_element_success();
  XML_ParserFree(g_parser);
  g_parser = NULL;
  printf("{\"status\":\"passed\",\"version\":\"%s\",\"chunk\":%d,"
         "\"deferral\":%ld,\"start_checked\":%d,\"end_checked\":%d,"
         "\"injection_disabled\":true,\"parse_symbol_origin\":\"%s\"}\n",
         api.version(), g_chunkSize, deferral, g_triplet_start_flag,
         g_triplet_end_flag, actual);
  dlclose(library);
  return 0;
}
