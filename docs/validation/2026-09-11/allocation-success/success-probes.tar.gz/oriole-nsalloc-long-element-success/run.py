"""One authorized CPU5 build and 24 bounded success probes; preserve every first outcome."""
from pathlib import Path
import hashlib
import json
import os
import resource
import signal
import subprocess
import time

ROOT = Path(__file__).parent
SOURCE = Path('/home/dev-user/code/oss/oriole-literal-attribute-check')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
os.sched_setaffinity(0, {5})
assert not (ROOT/'results.json').exists()
preparation = load(ROOT/'preparation.json')
assert preparation['status'] == 'prepared_only'
inputs = {**preparation['source_paths'], str(SOURCE/'include/expat.h'):sha(SOURCE/'include/expat.h'),
          preparation['original_results']['path']:preparation['original_results']['sha256']}
for name, value in preparation['extracted_files'].items():
    inputs[str(ROOT/name)] = value
for name in ('probe.c','run.py','preparation.json'):
    inputs[str(ROOT/name)] = sha(ROOT/name)
libraries = {
    'expat': {'path':'/tmp/oriole-pgo-study/expat-use-liboriole_expat.so','sha256':'12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'},
    'accepted': {'path':'/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.so','sha256':'8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a'},
}
for row in libraries.values():
    inputs[row['path']] = row['sha256']
assert all(sha(path) == value for path,value in inputs.items())
environment = dict(os.environ)
for name in ('LD_PRELOAD','LD_LIBRARY_PATH','DYLD_INSERT_LIBRARIES'):
    environment.pop(name, None)
report = {'status':'incomplete','scope':'Derivative semantic success only; original 12 allocation-ceiling outcomes remain failures.',
          'cpu':5,'commands':[],'libraries':libraries,'inputs_before':inputs,'rows':[]}
def save():
    (ROOT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
def limits():
    resource.setrlimit(resource.RLIMIT_AS,(1073741824,1073741824))
    resource.setrlimit(resource.RLIMIT_RSS,(805306368,805306368))
    resource.setrlimit(resource.RLIMIT_CPU,(3,3))
def run(label, command, timeout, bounded=False):
    row = {'label':label,'command':command,'timeout_seconds':timeout,'start':time.time()}
    report['commands'].append(row); save()
    process = subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=environment,
                               start_new_session=True,preexec_fn=limits if bounded else None,text=True)
    try:
        stdout,stderr=process.communicate(timeout=timeout)
    except BaseException:
        os.killpg(process.pid,signal.SIGKILL)
        stdout,stderr=process.communicate()
        row['interrupted_or_timed_out']=True
        raise
    finally:
        row.update({'returncode':process.returncode,'end':time.time(),'stdout':stdout,'stderr':stderr})
        save()
    return row
try:
    build = run('build',['/usr/bin/cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-I'+str(SOURCE/'include'),
                         str(ROOT/'probe.c'),'-ldl','-o',str(ROOT/'probe')],60)
    assert build['returncode'] == 0, build
    report['probe_sha256']=sha(ROOT/'probe')
    for engine,library in libraries.items():
        for chunk in preparation['chunks']:
            for deferral in preparation['deferral']:
                label=f'{engine}-chunk{chunk}-deferral{deferral}'
                row=run(label,[str(ROOT/'probe'),library['path'],str(chunk),str(deferral)],3,True)
                assert row['returncode'] == 0, row
                actual=json.loads(row['stdout'])
                expected={'status':'passed','version':'expat_2.8.4' if engine=='expat' else 'oriole_compat_2.8.4',
                          'chunk':chunk,'deferral':deferral,'start_checked':1,'end_checked':1,'injection_disabled':True,
                          'parse_symbol_origin':str(Path(library['path']).resolve())}
                assert actual == expected and row['stderr']=='', row
                report['rows'].append({'engine':engine,'chunk':chunk,'deferral':deferral,'actual':actual})
                save()
    assert len(report['rows']) == 24
    report['inputs_after']={path:sha(path) for path in inputs}
    assert report['inputs_after']==inputs
    assert sha(ROOT/'probe')==report['probe_sha256']
    assert [r for r in load(preparation['original_results']['path'])['results'] if r['test']==preparation['original_test']]==preparation['original_failures']
    report['status']='passed_derivative_success_probe'
finally:
    save()
print(json.dumps({'status':report['status'],'conditions':len(report['rows']),
                  'original_allocation_failures_preserved':12,'results_sha256':sha(ROOT/'results.json')},indent=2))
