"""Prepare a single copied C diagnostic; never compile or load a parser."""
from pathlib import Path
import ast
import collections
import difflib
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parent
PRIOR = Path('/tmp/oriole-reference-frame-semantic-diagnostic')
prior = json.loads((PRIOR / 'preparation.json').read_text())
BASE = Path(prior['original_base'])
LIBRARY = Path(prior['selected_runtime']['library_path'])
NAME = 'test_nsalloc_parse_buffer'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write_json = lambda p, value: p.write_text(json.dumps(value, indent=2) + '\n')
original = json.loads((BASE / 'results.json').read_text())
manifest = json.loads((BASE / 'manifest.json').read_text())
assert collections.Counter(r['outcome'] for r in original['results']) == {'pass': 4347, 'fail': 391, 'timeout': 2}
assert sha(LIBRARY) == manifest['library_sha256'] == 'd3c43850247b83aa3089b7f08deb31a084ee2aecb47b52d27e9d05e97b0e1bd4'
original_pins = {str(p.relative_to(BASE)): sha(p) for p in sorted(BASE.rglob('*')) if p.is_file()}
assert original_pins == prior['original_files']
shutil.copytree(BASE / 'adapted', ROOT / 'adapted')
shutil.copytree(BASE / 'lib', ROOT / 'lib')
shutil.copyfile(LIBRARY, ROOT / 'liboriole_expat.so')
for name in ['manifest.json', 'results.json']:
    shutil.copyfile(BASE / name, ROOT / ('original-' + name))
for name in ['selected-source.json', 'selected-build.json']:
    shutil.copyfile(PRIOR / name, ROOT / name)

source = (BASE / 'adapted/nsalloc_tests.c').read_text()
old = '''  g_allocation_count = 0;
  if (XML_ParseBuffer(g_parser, 0, XML_FALSE) != XML_STATUS_ERROR)
    fail("Pre-init XML_ParseBuffer not faulted");
  if (XML_GetErrorCode(g_parser) != XML_ERROR_NO_MEMORY)
    fail("Pre-init XML_ParseBuffer faulted for wrong reason");'''
new = '''  g_allocation_count = 0;
  {
    const enum XML_Status status = XML_ParseBuffer(g_parser, 0, XML_FALSE);
    const enum XML_Error error = XML_GetErrorCode(g_parser);
    fprintf(stderr,
            "ORIOLE_EMPTY_BUFFER_OBSERVATION\\tstatus=%d\\terror=%d"
            "\\tallocation_count=%d\\n",
            (int)status, (int)error, g_allocation_count);
  }'''
assert source.count(old) == 1
modified = source.replace(old, new)
assert '#include <stdio.h>' not in modified
modified = modified.replace('#include "expat_config.h"', '#include "expat_config.h"\n#include <stdio.h>', 1)
(ROOT / 'adapted/nsalloc_tests.c').write_text(modified)
(ROOT / 'diagnostic.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True), modified.splitlines(True), fromfile='original/nsalloc_tests.c', tofile='diagnostic/nsalloc_tests.c')))
assert modified.replace(new, old).replace('#include "expat_config.h"\n#include <stdio.h>', '#include "expat_config.h"', 1) == source
start = source.index('START_TEST(' + NAME + ')')
end = source.index('END_TEST', start) + len('END_TEST')
old_body = source[start:end]
new_start = modified.index('START_TEST(' + NAME + ')')
new_end = modified.index('END_TEST', new_start) + len('END_TEST')
new_body = modified[new_start:new_end]
api_calls = re.findall(r'\b(XML_\w+)\s*\(', old_body)
assert api_calls == re.findall(r'\b(XML_\w+)\s*\(', new_body)
tail = '  /* Now with actual memory allocation */'
assert old_body[old_body.index(tail):] == new_body[new_body.index(tail):]
for p in (ROOT / 'adapted').iterdir():
    if p.name != 'nsalloc_tests.c':
        assert p.read_bytes() == (BASE / 'adapted' / p.name).read_bytes()

rows = [r for r in original['results'] if r['test'] == NAME]
contexts = {f'chunksize={chunk} deferral={mode}' for chunk in range(6) for mode in range(2)}
assert len(rows) == 12 and all(r['outcome'] == 'fail' and r['code'] == 100 for r in rows)
assert {r['context'] for r in rows} == contexts
log = (BASE / 'tests.log').read_text()
blocks = [m[0] for m in re.finditer(r'^ORIOLE_BEGIN\t([^\t\n]+)\t([^\t\n]+)\n(.*?)^ORIOLE_RESULT\t\1\t\2\t([^\n]+)\n', log, re.M | re.S) if m[2] == NAME]
assert len(blocks) == 12 and all('nsalloc_tests.c:129' in block for block in blocks)
(ROOT / 'original-selected-failures.log').write_text(''.join(blocks))

controller = (PRIOR / 'run.py').read_text()
controller = controller.replace('Run the prepared six-case diagnostic once, preserving its original matrix.', 'Run the prepared single buffer-tail diagnostic once, preserving its original matrix.')
needle = "    report['outcomes'] = dict(collections.Counter(r['outcome'] for r in rows))\n"
addition = '''    observations = []
    for block in re.finditer(r'^ORIOLE_BEGIN\\t([^\\t\\n]+)\\t([^\\t\\n]+)\\n(.*?)^ORIOLE_RESULT\\t\\1\\t\\2\\t([^\\n]+)\\n', log, re.M | re.S):
        for status, error, allocation_count in re.findall(r'^ORIOLE_EMPTY_BUFFER_OBSERVATION\\tstatus=(-?\\d+)\\terror=(-?\\d+)\\tallocation_count=(-?\\d+)$', block[3], re.M):
            observations.append({'context': block[1], 'test': block[2], 'status': int(status), 'error': int(error), 'allocation_count': int(allocation_count)})
    report['empty_buffer_observations'] = observations
    report['observation_selection_complete'] = len(observations) == len(expected) and {(r['context'], r['test']) for r in observations} == expected
'''
assert controller.count(needle) == 1
controller = controller.replace(needle, needle + addition)
controller = controller.replace("report['run_exit_code'] == 0 and all(r['outcome'] == 'pass' and r['code'] == 0 for r in rows)", "report['run_exit_code'] == 0 and report['observation_selection_complete'] and all(r['outcome'] == 'pass' and r['code'] == 0 for r in rows)")
ast.parse(controller)
(ROOT / 'run.py').write_text(controller)
(ROOT / 'controller.patch').write_text(''.join(difflib.unified_diff((PRIOR / 'run.py').read_text().splitlines(True), controller.splitlines(True), fromfile='prior/run.py', tofile='diagnostic/run.py')))
compile_command = [s.replace(str(BASE), str(ROOT)) for s in manifest['compile_command']]
compile_command[0] = str(Path(shutil.which(compile_command[0])).resolve())
compile_command[-1] = str(ROOT / 'run01/runtests')
write_json(ROOT / 'preparation.json', {
    'status': 'prepared_not_executed',
    'scope': 'Single nsalloc_parse_buffer continuation diagnostic, twelve configurations. Only the second empty-buffer allocation/OOM assertions become an observed status/error. Every parser API call and all later original assertions remain. Original matrix unchanged; no retry ceilings changed; not an OOM-equivalence or production-readiness claim.',
    'selected_runtime': prior['selected_runtime'],
    'original_base': str(BASE), 'original_files': original_pins,
    'original_matrix_sha256': sha(BASE / 'results.json'),
    'prior_controller_path': str(PRIOR / 'run.py'), 'prior_controller_sha256': sha(PRIOR / 'run.py'),
    'selected_tests': [NAME], 'expected_contexts': sorted(contexts), 'expected_configurations': 12,
    'source_change': {'file': 'adapted/nsalloc_tests.c', 'original_assertion_lines': [127, 128, 129, 130, 131], 'old_body_sha256': hashlib.sha256(old_body.encode()).hexdigest(), 'new_body_sha256': hashlib.sha256(new_body.encode()).hexdigest(), 'later_assertions_byte_identical': True, 'parser_api_call_sequence_preserved': api_calls, 'stdio_include_added_for_diagnostic': True},
    'limits': {'test_seconds': 3, 'address_space_mib': 1024, 'rss_mib': 768, 'total_test_seconds': 240, 'compile_seconds': 120},
    'compile_command': compile_command, 'compiler_sha256': sha(Path(compile_command[0])),
    'environment': {'ORIOLE_CHUNK_MASK': '63', 'ORIOLE_DEFERRAL_MASK': '3', 'ORIOLE_TEST_TIMEOUT': '3', 'ORIOLE_MEMORY_MIB': '1024', 'ORIOLE_RSS_MIB': '768', 'ORIOLE_SELECTED_TESTS': NAME},
    'staged_files': {str(p.relative_to(ROOT)): sha(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name not in ('preparation.json', 'preparation-attempt01.stdout', 'preparation-attempt01.stderr')},
})
assert original_pins == {str(p.relative_to(BASE)): sha(p) for p in sorted(BASE.rglob('*')) if p.is_file()}
print(json.dumps({'status': 'prepared_not_executed', 'configurations': 12, 'changed_c_files': ['adapted/nsalloc_tests.c'], 'original_tree_unchanged': True, 'preparation_sha256': sha(ROOT / 'preparation.json')}))
