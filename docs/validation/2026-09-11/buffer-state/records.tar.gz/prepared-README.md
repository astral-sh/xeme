# Buffered-parser continuation diagnostic — preparation

Prepared for root review; no compiler or parser has run in this directory.

The first preparation completed without targets, but patch readback found that an intended stdio include had not been inserted because its anchor was absent. `prepare-attempt01.py`, `preparation-attempt01.json`, `diagnostic-attempt01.patch` and the first stdout/stderr preserve that preparation. The finalized source inserts the header at the existing string.h include, and the preparer now asserts that anchor exists. No parser call, observation or original assertion changed in the correction.

This copies `test_nsalloc_parse_buffer` from the selected runtime's original upstream API harness. All 12 original configurations fail the assertion at `nsalloc_tests.c:129`: an empty parse after a reservation succeeded when the test expected allocation failure. The derivative records that call's actual status/error and leaves every subsequent assertion intact, exposing the buffer/suspension/resumption sequence that the early assertion hid. The original 4,740 matrix remains 4,347 pass / 391 assertion failures / 2 timeouts.

## Only behavioral adjustment

`diagnostic.patch` is the complete C source change: add the explicit stdio header, retain `g_allocation_count = 0`, and replace the two second-empty-call OOM assertions with one observation:

```text
ORIOLE_EMPTY_BUFFER_OBSERVATION<TAB>status=<integer><TAB>error=<integer><TAB>allocation_count=<integer>
```

No status/error value is forced or accepted as equivalent to Expat. The `XML_ParseBuffer` and `XML_GetErrorCode` calls stay in their original lexical order. On the selected original success path the error query was previously skipped by the failing assertion; the derivative now records it. Every call and assertion before that block and the entire tail beginning “Now with actual memory allocation” remain byte-identical. The character handler is unchanged: it calls `XML_StopParser(g_parser, g_resumable)` and clears itself.

The copied `alloc_tests.c` retains original retry constants. It is not copied from the earlier six-case derivative. All other C/header inputs, handlers, setup/teardown, case isolation, selection and origin reporting are unchanged from the original harness. `controller.patch` shows the small adaptation of the prior six-case controller: one observation per selected context is extracted, retained without value assumptions, and required for a successful report. `preparation.json` pins the complete staged inputs and original tree.

## Expected sequence, reviewed before target execution

The status/error labels below are the **unchanged original tail assertions**, not newly observed results. Only the second row is observational. The raw log identifies each context with existing `ORIOLE_BEGIN` and `ORIOLE_RESULT` records; a pass proves the tail and fixture teardown completed. No extra parser queries or trace callbacks are added elsewhere.

| Stage | Original calls / required outcome |
| --- | --- |
| Fresh parser | `ParseBuffer(0,false)` is ERROR; error is NO_BUFFER. `GetBuffer(1)` succeeds. |
| Allocator count 0 | **Observe** `ParseBuffer(0,false)` status and error. Original current evidence already showed success; its exact error is not assumed. Retain count 0 through this call. |
| Restore allocator | Set ALLOC_ALWAYS_SUCCEED; `ParseBuffer(0,false)` succeeds. `ResumeParser` is ERROR with NOT_SUSPENDED. |
| Supply complete document | Install unchanged clearing/stopping character callback; set resumable true; `GetBuffer(strlen("<doc>Hello</doc>"))`, copy exact document, `ParseBuffer(length,true)` returns SUSPENDED and error NONE. |
| While suspended | `ParseBuffer(length,true)` is ERROR with SUSPENDED; `GetBuffer(length)` is NULL. No new input is copied. |
| Resume | Clear character handler; `ResumeParser` succeeds. |
| After finishing | `ParseBuffer(length,true)` is ERROR with FINISHED; `GetBuffer(length)` is NULL. Fixture teardown frees parser. |

The two repeated positive ParseBuffer calls deliberately test rejected operations in suspended/finished states, exactly as upstream. They are not successful reuse of a prior reservation. Callback counts and text bytes are not asserted by the original fixture, and this derivative adds no such oracle.

## Runtime, commands and bounds

Selected PGO library: `d3c43850247b83aa3089b7f08deb31a084ee2aecb47b52d27e9d05e97b0e1bd4`; source/build manifests are copied from the prior current diagnostic. Measured source `0f66d54ac8418f0a6e628ad18570677a19c9ed45`, published at `4064b0653534aff690c0e0f395a6b3b48da878fc`. One C compile uses the original `-O1 -DXML_TESTING -D_GNU_SOURCE` arguments with remapped paths. No Rust build or reference-library execution is prepared.

Run only after root reviews preparation, serially outside elapsed work:

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-nsalloc-buffer-tail-diagnostic/run.py
```

Exactly one test × six chunk settings (0–5) × both deferral settings = 12 configurations. The body does not use the chunk width, but the original selection shape is retained. Original execution limits: 3 seconds per child, 1 GiB address space, sampled RSS limit 768 MiB, 240 seconds for the invocation. Compile limit 120 seconds. No retry limits changed and no automatic limit escalation. The reused controller refuses an existing `run01`, preserves failures, checks staged/original hashes, verifies the actual library origin, and kills/reaps its target group on a controller timeout. The original child runner sets RLIMIT_AS and alarm and reaps each test child; sampled RSS is not a precise peak bound.

This C consumer and the Rust PGO library are not sanitizer-instrumented. A successful derivative would establish this exact continuation sequence after the observed empty call. It would not validate the removed allocation-schedule assertion, init-OOM equivalence, all allocation failure points, or production readiness.
