"""Run the prepared single buffer-tail diagnostic once, preserving its original matrix."""
from pathlib import Path
import collections
import hashlib
import json
import os
import re
import signal
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'run01'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
prepared = json.loads((ROOT / 'preparation.json').read_text())
OUT.mkdir(exist_ok=False)
report = {'status': 'started', 'scope': prepared['scope'], 'preparation_sha256': sha(ROOT / 'preparation.json'), 'controller_sha256': sha(Path(__file__)), 'commands': []}
base = Path(prepared['original_base'])
environment = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C', 'TMPDIR': '/tmp', **prepared['environment']}

def check_original():
    return prepared['original_files'] == {str(p.relative_to(base)): sha(p) for p in sorted(base.rglob('*')) if p.is_file()}

def run(command, log_name, seconds):
    entry = {'argv': command, 'cwd': str(ROOT), 'timeout_seconds': seconds, 'environment': environment}
    report['commands'].append(entry)
    with (OUT / log_name).open('w') as stream:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            entry['exit_code'] = process.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            entry['exit_code'] = process.wait()
            entry['timed_out'] = True
            raise
    entry['log_sha256'] = sha(OUT / log_name)
    return entry['exit_code']

try:
    assert os.sched_getaffinity(0) == {3}, 'Root must schedule this controller on CPU 3 outside elapsed campaigns'
    assert check_original(), 'Original API matrix/harness changed before execution'
    for relative, expected in prepared['staged_files'].items():
        assert sha(ROOT / relative) == expected, relative
    assert sha(Path(prepared['compile_command'][0])) == prepared['compiler_sha256']
    assert sha(Path(prepared['selected_runtime']['library_path'])) == prepared['selected_runtime']['library_sha256']
    report['preflight_passed'] = True
    report['compile_exit_code'] = run(prepared['compile_command'], 'build.log', prepared['limits']['compile_seconds'])
    assert report['compile_exit_code'] == 0
    report['binary_sha256'] = sha(OUT / 'runtests')
    report['run_exit_code'] = run([str(OUT / 'runtests'), '--verbose'], 'tests.log', prepared['limits']['total_test_seconds'])
    log = (OUT / 'tests.log').read_text()
    rows = [dict(context=context, test=test, outcome=outcome, code=int(code)) for context, test, outcome, code in re.findall(r'^ORIOLE_RESULT\t([^\t]+)\t([^\t]+)\t([^\t]+)\t(\d+)$', log, re.M)]
    origins = re.findall(r'^ORIOLE_LIBRARY\t(.+)$', log, re.M)
    expected = {(context, test) for context in prepared['expected_contexts'] for test in prepared['selected_tests']}
    report['selection_complete'] = len(rows) == len(expected) and {(r['context'], r['test']) for r in rows} == expected
    report['library_origins'] = origins
    report['library_origin_verified'] = bool(origins) and all(Path(p).resolve() == ROOT / 'liboriole_expat.so' for p in origins)
    report['outcomes'] = dict(collections.Counter(r['outcome'] for r in rows))
    observations = []
    for block in re.finditer(r'^ORIOLE_BEGIN\t([^\t\n]+)\t([^\t\n]+)\n(.*?)^ORIOLE_RESULT\t\1\t\2\t([^\n]+)\n', log, re.M | re.S):
        for status, error, allocation_count in re.findall(r'^ORIOLE_EMPTY_BUFFER_OBSERVATION\tstatus=(-?\d+)\terror=(-?\d+)\tallocation_count=(-?\d+)$', block[3], re.M):
            observations.append({'context': block[1], 'test': block[2], 'status': int(status), 'error': int(error), 'allocation_count': int(allocation_count)})
    report['empty_buffer_observations'] = observations
    report['observation_selection_complete'] = len(observations) == len(expected) and {(r['context'], r['test']) for r in observations} == expected
    report['results'] = rows
    report['library_unchanged'] = sha(ROOT / 'liboriole_expat.so') == prepared['selected_runtime']['library_sha256']
    report['original_tree_unchanged'] = check_original()
    assert report['selection_complete'] and report['library_origin_verified'] and report['library_unchanged'] and report['original_tree_unchanged']
    report['all_diagnostic_contexts_passed'] = report['run_exit_code'] == 0 and report['observation_selection_complete'] and all(r['outcome'] == 'pass' and r['code'] == 0 for r in rows)
    report['status'] = 'complete' if report['all_diagnostic_contexts_passed'] else 'diagnostic_failures'
except BaseException as error:
    report['status'] = 'error'
    report['error'] = repr(error)
    raise
finally:
    report['original_tree_unchanged_on_exit'] = check_original()
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('status', 'outcomes', 'selection_complete', 'library_origin_verified', 'original_tree_unchanged_on_exit') if k in report}))
if not report['all_diagnostic_contexts_passed']:
    sys.exit(1)
