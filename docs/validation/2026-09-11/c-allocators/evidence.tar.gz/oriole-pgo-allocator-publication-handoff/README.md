# Oriole PGO allocator study publication handoff

Read `pgo-allocator-study/RESULTS.md` and `pgo-allocator-study/summary.json` first.

The artifact includes the full initial provider source/build/failure history and normal proof, the PGO provider replay, sibling C driver and fixed controllers/protocols, every raw preflight/elapsed/RSS record, and author audits. No parser/default/allocator tuning changes were made. The ordinary native driver was preserved.

Compiled executables, objects, static libraries and bytecode are excluded; `EXCLUDED_BINARIES.json` retains their exact original paths, sizes and hashes. The original manifests remain unmodified and therefore also mention those deliberately excluded files. The publication `MANIFEST.json` lists the exact files included here. Parser PGO libraries and provider archives remain bound by source/build evidence and external component hashes.

Counts: 8 replay proof processes, 224 preflights, 1,568 elapsed workers in 196 cohorts, and 672 subsequent RSS workers in 84 cohorts. All 28 conditions and every regression are retained. Both author raw audits passed. Real Oriole elapsed gains from jemalloc/mimalloc were negligible; absolute workload RSS increased. Keep current defaults; independent review is separate.

RSS is same-executable Linux VmHWM, including both linked provider constructors, input buffer, parser DSO and selected workload. It is not isolated allocator resident bytes. The instrumented proof RSS is excluded from comparisons.
