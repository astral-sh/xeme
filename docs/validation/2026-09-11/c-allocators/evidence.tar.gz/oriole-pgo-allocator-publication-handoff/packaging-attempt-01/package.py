from pathlib import Path
import hashlib,json,os,shutil,tarfile
assert os.sched_getaffinity(0)=={2}
O=Path('/tmp/oriole-pgo-allocator-publication-handoff');O.mkdir()
sources={'provider-proof':Path('/tmp/oriole-explicit-mm-provider-proof'),'pgo-allocator-study':Path('/tmp/oriole-pgo-allocator-native-study')}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
report={'status':'incomplete','scope':'Publication artifact: all source/build/proof attempts, provider provenance, drivers/controllers, raw PGO elapsed/RSS results and author audits; compiled binaries/objects/bytecode excluded and exact hashes retained. No source or harness rewrite.','sources':{},'included':{},'excluded_binaries':[]}
for prefix,base in sources.items():
 manifest=json.loads((base/'MANIFEST.json').read_text());expected=manifest['files_sha256']
 report['sources'][prefix]={'path':str(base),'manifest_sha256':sha(base/'MANIFEST.json'),'source_files_indexed':len(expected)}
 for relative,want in expected.items():assert sha(base/relative)==want,(prefix,relative)
 for p in sorted(base.rglob('*')):
  if not p.is_file():continue
  relative=p.relative_to(base);target=O/prefix/relative;digest=sha(p)
  with p.open('rb') as f:magic=f.read(8)
  kind=None
  if magic.startswith(b'\x7fELF'):kind='ELF compiled binary/object'
  elif magic==b'!<arch>\n':kind='static archive'
  elif p.suffix in ['.o','.a','.so','.pyc'] or '__pycache__' in p.parts:kind='compiled object/library/bytecode'
  if kind:
   report['excluded_binaries'].append({'path':str(p),'relative_path':str(Path(prefix)/relative),'sha256':digest,'bytes':p.stat().st_size,'kind':kind})
   continue
  target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);assert sha(target)==digest
  report['included'][str(Path(prefix)/relative)]=digest
# Package controller records itself without modifying either sealed source.
shutil.copyfile(__file__,O/'package.py');report['included']['package.py']=sha(O/'package.py')
(O/'EXCLUDED_BINARIES.json').write_text(json.dumps({'scope':'Exact compiled inputs and retained failed/superseded builds excluded from publication; source/build/command/origin proof remains included.','files':report['excluded_binaries']},indent=2)+'\n')
(O/'README.md').write_text('''# Oriole PGO allocator study publication handoff

Read `pgo-allocator-study/RESULTS.md` and `pgo-allocator-study/summary.json` first.

The artifact includes the full initial provider source/build/failure history and normal proof, the PGO provider replay, sibling C driver and fixed controllers/protocols, every raw preflight/elapsed/RSS record, and author audits. No parser/default/allocator tuning changes were made. The ordinary native driver was preserved.

Compiled executables, objects, static libraries and bytecode are excluded; `EXCLUDED_BINARIES.json` retains their exact original paths, sizes and hashes. The original manifests remain unmodified and therefore also mention those deliberately excluded files. The publication `MANIFEST.json` lists the exact files included here. Parser PGO libraries and provider archives remain bound by source/build evidence and external component hashes.

Counts: 8 replay proof processes, 224 preflights, 1,568 elapsed workers in 196 cohorts, and 672 subsequent RSS workers in 84 cohorts. All 28 conditions and every regression are retained. Both author raw audits passed. Real Oriole elapsed gains from jemalloc/mimalloc were negligible; absolute workload RSS increased. Keep current defaults; independent review is separate.

RSS is same-executable Linux VmHWM, including both linked provider constructors, input buffer, parser DSO and selected workload. It is not isolated allocator resident bytes. The instrumented proof RSS is excluded from comparisons.
''')
report['included']['EXCLUDED_BINARIES.json']=sha(O/'EXCLUDED_BINARIES.json');report['included']['README.md']=sha(O/'README.md')
report['status']='sealed';report['included_files']=len(report['included']);report['excluded_binary_files']=len(report['excluded_binaries'])
(O/'MANIFEST.json').write_text(json.dumps(report,indent=2)+'\n')
archive=O.with_suffix('.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6) as t:t.add(O,arcname=O.name)
# Verify every archived file against the publication index, and reject compiled magic.
with tarfile.open(archive) as t:
 actual={}
 for member in t.getmembers():
  if not member.isfile():continue
  relative=str(Path(member.name).relative_to(O.name));data=t.extractfile(member).read()
  assert not data.startswith(b'\x7fELF') and not data.startswith(b'!<arch>\n'),relative
  actual[relative]=hashlib.sha256(data).hexdigest()
 assert actual=={**report['included'],'MANIFEST.json':sha(O/'MANIFEST.json')}
receipt={'status':'sealed-readback-passed','directory':str(O),'archive':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'manifest_sha256':sha(O/'MANIFEST.json'),'included_files':report['included_files'],'excluded_binary_files':report['excluded_binary_files'],'original_manifests_verified':True,'all_archived_files_verified':True}
receipt_path=O.with_suffix('.json');receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
for p in sorted(O.rglob('*'),reverse=True):p.chmod(0o555 if p.is_dir() else 0o444)
O.chmod(0o555);archive.chmod(0o444);receipt_path.chmod(0o444)
print(json.dumps(receipt,indent=2))
