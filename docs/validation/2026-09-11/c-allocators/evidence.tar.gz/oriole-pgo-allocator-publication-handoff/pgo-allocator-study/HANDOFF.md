# Allocator study handoff

Complete: PGO provider proof replay, strict sibling driver build, 224 preflights, 1,568 elapsed workers and 672 separate RSS workers. Both author audits passed; all 28 conditions and every raw process are retained. CPU0/2 released. No parser/default/provider-setting changes or commits.

Read RESULTS.md and summary.json first. Full protocols, seeded schedules, driver/controller patches, approvals, build/source copies, raw records and audits are indexed by MANIFEST.json. Independent root review/adoption is separate. External pinned libraries/providers/fixtures are indexed in EXTERNAL_COMPONENTS.json and the prior sealed provider proof.

The ordinary/libc/jemalloc/mimalloc real Oriole elapsed factors are 1.000000/1.002669268/.998748605/.999782767. These show no useful real-XML Oriole gain in this screen. The respective matched real Oriole/Expat factors are 1.428561262/1.431577226/1.446136218/1.449922176. Generated gains, regressions and all RSS conditions are retained without filtering.

The compressed handoff is stored alongside this study after sealing; its detached receipt records archive and manifest hashes. No elapsed/RSS reruns or source changes are authorized by this handoff.
