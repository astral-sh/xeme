# PGO native allocator comparison — prepared, elapsed held

## Fixed components and mechanism

- Oriole PGO shared library `4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02` from the current native-byte-count PGO study.
- Expat 2.8.4 GCC PGO shared library `12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0` from the frozen Expat PGO study. These are the requested trained pair; this study does not retrain either engine.
- Sibling driver `982e7450aa5102e01d9ec3faa54615e2c9a76abdcbd9c540c7d5da2679076758`, built with original `cc -std=c11 -O3 -Wall -Wextra -Werror` optimization context and frozen namespaced static provider archives. No original native-driver source/binary changes. Exact-text checks retain original callback/hash functions, `now`, and timed loop apart from constructor selection.
- Each engine has ordinary/default creation, explicit libc memory suite, namespaced jemalloc memory suite, and mimalloc memory suite. Direct function pointers, no wrapper allocation counters/ledger, no dispatch in allocation callbacks. Provider choice is outside the loop; parser construction selection remains inside the original timed interval.
- No process malloc interposition: static/dynamic symbol checks reject unprefixed malloc-family definitions; exactly six provider allocation APIs are exported. The input buffer and stdio continue to use libc. Both providers' upstream startup constructors run for every mode; no added provider stats/config/version queries occur in the driver.

## Replay and source evidence

`proof-replay/report.json` is the new 8-process replay of the **same frozen proof executable** against the two PGO libraries. All passed: 144 parser API origin checks, 88 validated origin rows, 16 matching native trace observations, 108 allocation-failure injections, and final zero live suite blocks/bytes. Returned models, children (freed before parent per Expat contract), reset, stop/resume, callback-created child, malformed XML, and amplification cases remain intact. The older normal-library proof remains sealed and unchanged. Proof RSS is excluded from comparisons.

`evidence/` contains copied build/source/protocol receipts; all 70 Oriole source archive members match their frozen manifest. `inputs.json` records original and copy hashes. Parser sources and both PGO binaries are unchanged. Jemalloc and mimalloc source/build/version provenance is inherited from the sealed explicit-MM provider proof; no provider rebuild or tuning here.

## Exact cohort

`prepared-protocol.json`, `prepared-schedule.json`, `native_screen.py`, and `controller.patch` are the full protocol and review delta. They retain all original 28 conditions, input hashes, chunk sizes, namespace modes, iterations, seven repetitions, and seed 2026091003. The first job shuffle covers the original 196 condition/repetition cohorts; every cohort then independently shuffles all eight parser/allocator combinations.

- 224 preflights, one warmup + one observed parse per process, CPU2. All eight combinations' hash/element/text-byte observations must match on each condition, and both samples within each process must match.
- 1,568 timed workers in 196 cohorts, CPU0. Each worker discards exactly one warmup and uses the original per-condition iteration count: Vulkan7, Wayland64, Maven128, Batik512, GTK256, DocBook256, both generated inputs32.
- Parser construction, handler registration, chunked XML_Parse, callbacks, and parser destruction remain inside the timer. File I/O, DSO loading, process startup, provider selection, output, and optional RSS reading remain outside.
- Original limits: 90 seconds per worker, 600 seconds aggregate preflight, 1,200 seconds aggregate elapsed phase. SIGALRM covers phase setup/hashing through summary; each child has its own process group, killed on exit/error/timeout/interruption. Raw stdout/stderr and failure records are saved before semantic validation. No reruns or omitted conditions.
- LD injection and provider configuration environment keys are removed exactly as the frozen proof. `ORIOLE_NATIVE_RSS` is also explicitly removed; elapsed/preflight records assert its absence and reject RSS fields.
- Before/after hashes cover libraries, driver/source/controller, schedule, fixture inputs, archives, and copied evidence. Approval hashes bind the frozen protocol/controller before execution.

Per-condition summaries retain all seven paired ratios, with medians for every allocator-vs-ordinary/MM comparison within each engine and Oriole/Expat under each mode. Group summaries include each real project, each generated input, real24, generated4, and explicitly labeled all28, retaining win/regression counts and every condition ratio. No full-application or allocator-default conclusion follows automatically from this native callback screen.

## Separate memory plan

`RSS-PLAN.md` proposes a separately authorized 672-process workload cohort with the same binary/modes/inputs/iterations and current-executable Linux VmHWM. It measures absolute workload process RSS including both statically linked providers' startup state, input buffer and DSOs; it does not claim isolated allocator bytes. No RSS workload has been launched.

## Retained preparation history

`driver-comment-draft/` preserves the original misleading comment and its build; correcting it to “after all parse/free iterations” produced byte-identical executable output. `protocol-preparation-attempt-01/` retains the failed archive verifier (suffix matching `Cargo.toml` found five crate manifests). The corrected verifier matches exact archive member paths; no parser/benchmark workload ran during that failure. All proof runs passed. No elapsed comparison has been launched.
