# Separate workload peak RSS cohort — prepared, not launched

Use the exact native-allocator-driver binary and the same two PGO libraries, four modes, 28 conditions, input hashes, chunk sizes, parser lifecycle, callbacks, and per-condition iteration counts as the elapsed study. Each fresh process runs one discarded warmup plus the original measured-iteration count. No allocator fault injection, pointer ledger, provider statistics, mallctl, version queries, purge, arena changes, or allocator tuning.

Set only `ORIOLE_NATIVE_RSS=1` in the otherwise identically sanitized environment. After **all** parse/free iterations, while the input buffer and parser DSO are still loaded, the driver reads `/proc/self/status` and emits `workload_peak_rss_kib` from `VmHWM`. This is the current executable's address-space high-water value. The timing cohort removes this variable and rejects any RSS output field. RSS runs are separate fresh processes; their seconds fields are retained as raw observations but excluded from the elapsed results.

Proposed bounded cohort: three seeded repetitions of every condition and all eight combinations, 84 cohorts / 672 workers, one process per combination. Seed 2026091003; shuffle the 84 condition/repetition jobs then each eight-combination order. Use CPU2, a 90-second per-worker and 1,200-second aggregate limit, process-group cleanup, and the same output/hash checks as preflight. No launch is authorized by this preparation.

Retain each process's absolute VmHWM, all raw output, hashes, and order. Report per-condition median/min/max KiB for all eight combinations, paired KiB differences and ratios, and group tables for all six real projects and both generated workloads. Include all regressions. RSS is not additive; group summaries must not be called peak process memory for the group. Keep this result separate from elapsed ratios.

## Interpretation and common baseline

Both provider archives are linked into every worker executable. Their upstream startup constructors initialize allocator state before main even when that mode is not selected: jemalloc `src/jemalloc.c:4321` calls `malloc_init`; mimalloc `src/prim/prim.c:41` calls `_mi_auto_process_init` (`src/init.c:585`). The driver does not add metadata initialization. Provider source/build/version/origin receipts come from the separate frozen proof.

VmHWM includes executable mappings actually resident, both provider startup states, libc file/input/output allocations, the selected parser DSO, the input buffer, parser/provider workload pages, and small measurement setup. The input buffer remains allocated in all modes. This is an absolute same-executable workload comparison, **not** isolated allocator resident bytes and not requested-live-byte accounting. Shared host/kernel resident-page accounting and page granularity limit precision. Report both the absolute values and the common-baseline limitation; do not subtract the proof process's RSS or another run's high-water value.

The instrumented provider proof initializes/query all providers and exercises unrelated lifecycle/failure cases; its `proof_process_peak_rss_kib` is excluded entirely. `getrusage` may inherit pre-exec child high-water state, so it is not the primary metric and no previous Python-parent values are used.

A provider-isolated RSS experiment would need separately linked executables or loader changes. That is a different experiment and is outside this matched binary plan.
