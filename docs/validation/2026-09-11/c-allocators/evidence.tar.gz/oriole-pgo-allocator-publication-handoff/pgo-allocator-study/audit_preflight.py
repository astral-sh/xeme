from pathlib import Path
import hashlib,json,statistics
O=Path(__file__).parent;P=O/'native-screen'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
protocol=read(O/'prepared-protocol.json');report=read(P/'preflight.json')
assert read(P/'protocol.json')==protocol
assert report['status']=='passed' and len(report['rows'])==224
assert report['affinity']==[2] and report['aggregate_timeout_seconds']==600 and report['rss_environment_absent']
assert report['aggregate_elapsed_seconds']<600
assert report['hashes_before']==report['hashes_after']==protocol['hashes']
assert all(sha(path)==value for path,value in protocol['hashes'].items())
assert len(list(P.glob('worker-*.json')))==len(list(P.glob('worker-*.stdout')))==len(list(P.glob('worker-*.stderr')))==224
combinations=set(protocol['combinations']);cases=[]
for index,row in enumerate(report['rows']):
 stem=P/f'worker-{index:04d}';assert read(str(stem)+'.json')==row
 assert row['status']=='passed' and row['returncode']==0 and row['pair']==-1 and row['worker_timeout_seconds']==90
 assert row['command'][:3]==['taskset','-c','2']
 assert sha(str(stem)+'.stdout')==row['stdout_sha256'] and sha(str(stem)+'.stderr')==row['stderr_sha256']
 assert Path(str(stem)+'.stdout').read_text()==row['stdout'] and Path(str(stem)+'.stderr').read_text()==row['stderr']
 payload=json.loads(row['stdout']);assert 'workload_peak_rss_kib' not in payload
 samples=payload['samples'];assert len(samples)==2 and [s['warmup'] for s in samples]==[True,False]
 observed=[[s['hash'],s['elements'],s['text_bytes']] for s in samples]
 assert observed[0]==observed[1] and row['observations']==[observed[0]]
 assert row['median_seconds']==samples[1]['seconds']
for condition in protocol['conditions']:
 rows=[r for r in report['rows'] if r['condition']==condition]
 assert len(rows)==8 and {r['combination'] for r in rows}==combinations
 assert all(r['observations']==rows[0]['observations'] for r in rows)
 cases.append({'condition':condition,'combinations':8,'observations':rows[0]['observations']})
assert not (P/'results.json').exists()
proof=read(O/'proof-replay/report.json');assert proof['status']=='passed'
assert all(proof[k] for k in ['inputs_unchanged','providers_unchanged','source_unchanged'])
assert all(sha(path)==value for path,value in proof['inputs'].values())
assert all(sha(row['archive'])==row['sha256'] for row in proof['providers'].values())
summary={'status':'passed-preflight-elapsed-held','components':protocol['libraries'],'driver_sha256':sha(O/'native-allocator-driver'),'driver_source_sha256':sha(O/'native_allocator_driver.c'),'controller_sha256':sha(O/'native_screen.py'),'protocol_sha256':sha(O/'prepared-protocol.json'),'proof_replay_report_sha256':sha(O/'proof-replay/report.json'),'preflight_report_sha256':sha(P/'preflight.json'),'proof_replay_processes':8,'parser_origin_checks':144,'provider_origin_rows':88,'failure_injections':108,'preflight_processes':224,'preflight_parses':448,'preflight_conditions':28,'combinations_per_condition':8,'preflight_cpu':2,'preflight_elapsed_seconds_operational_only':report['aggregate_elapsed_seconds'],'all_raw_records_equal_report':True,'all_hashes_unchanged':True,'all_preflight_observations_equal':True,'rss_environment_absent':True,'rss_scope':'Separate plan only; same-executable absolute VmHWM includes both static provider constructors. No RSS results.','elapsed_authorization':'Semantically approved; held until root explicitly releases CPU0 after fat studies.','timed_workers_prepared':1568,'timed_cohorts_prepared':196,'timed_workers_executed':0,'conditions':cases,'retained_preparation_issues':['Comment-only driver rebuild retained; binary byte-identical.','Initial archive verification used suffix match for Cargo.toml and failed before any native workload; exact member names now verified.']}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='conditions'},indent=2))
