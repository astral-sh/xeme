from pathlib import Path
import hashlib,json,math,statistics,sys
O=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
phase=sys.argv[1];assert phase in ['elapsed','rss']
P=O/('native-screen' if phase=='elapsed' else 'rss-screen');report=read(P/'results.json');protocol=read(P/'protocol.json')
assert report['status']=='passed' and report['hashes_before']==report['hashes_after']==protocol['hashes']
assert all(sha(p)==h for p,h in protocol['hashes'].items())
conditions=protocol['conditions'];expected_workers=1568 if phase=='elapsed' else 672;reps=7 if phase=='elapsed' else 3
assert len(report['rows'])==28*reps and len(report['summary'])==28
assert report['aggregate_timeout_seconds']==1200 and report['aggregate_elapsed_seconds']<1200
assert report['affinity']==([0] if phase=='elapsed' else [2])
if phase=='elapsed':assert report['rss_environment_absent']
else:assert report['added_environment']=={'ORIOLE_NATIVE_RSS':'1'}
preflight=read(O/'native-screen/preflight.json');assert preflight['status']=='passed'
expected={json.dumps(r['condition'],sort_keys=True):r['observations'] for r in preflight['rows']}
raw_start=224 if phase=='elapsed' else 0
assert len(list(P.glob('worker-*.json')))==len(list(P.glob('worker-*.stdout')))==len(list(P.glob('worker-*.stderr')))==expected_workers+raw_start
schedule=read(O/('prepared-schedule.json' if phase=='elapsed' else 'rss-prepared-schedule.json'))
assert len(schedule)==len(report['rows'])
workers=0;parses=0;nonempty_stderr=0
for cohort,job in zip(report['rows'],schedule):
 condition=conditions[job['condition_index']]
 assert cohort['condition']==condition and cohort['pair']==job['pair'] and cohort['order']==job['order']
 assert [r['combination'] for r in cohort['processes']]==job['order']
 for r in cohort['processes']:
  stem=P/f'worker-{raw_start+workers:04d}';assert read(str(stem)+'.json')==r
  assert r['status']=='passed' and r['returncode']==0 and r['pair']==job['pair'] and r['condition']==condition
  assert r['command'][:3]==['taskset','-c','0' if phase=='elapsed' else '2']
  assert r['command'][3]==protocol['driver'] and r['command'][4]==protocol['libraries'][r['engine']]['path']
  assert r['command'][5:9]==[condition['input'],str(condition['chunk']),str(condition['iterations']),r['allocator']]
  assert r['command'][9:]==(['namespaces'] if condition['namespaces'] else [])
  assert sha(str(stem)+'.stdout')==r['stdout_sha256'] and sha(str(stem)+'.stderr')==r['stderr_sha256']
  assert Path(str(stem)+'.stdout').read_text()==r['stdout'] and Path(str(stem)+'.stderr').read_text()==r['stderr']
  payload=json.loads(r['stdout']);samples=payload['samples'];count=condition['iterations']
  assert len(samples)==count+1 and [s['iteration'] for s in samples]==list(range(count+1))
  assert [s['warmup'] for s in samples]==[True]+[False]*count
  observations=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in samples});assert len(observations)==1
  assert r['observations']==[list(observations[0])]==expected[json.dumps(condition,sort_keys=True)]
  if phase=='elapsed':
   assert 'workload_peak_rss_kib' not in payload and all(s['seconds']>0 for s in samples)
   assert r['median_seconds']==statistics.median(s['seconds'] for s in samples[1:])
  else:assert type(payload['workload_peak_rss_kib']) is int and payload['workload_peak_rss_kib']>0 and r['workload_peak_rss_kib']==payload['workload_peak_rss_kib']
  workers+=1;parses+=len(samples);nonempty_stderr+=bool(r['stderr'])
assert workers==expected_workers
for saved,condition in zip(report['summary'],conditions):
 assert saved['condition']==condition
 cohorts=[r for r in report['rows'] if r['condition']==condition];assert len(cohorts)==reps and {c['pair'] for c in cohorts}==set(range(reps))
 measure='median_seconds' if phase=='elapsed' else 'workload_peak_rss_kib'
 values=[{p['combination']:p[measure] for p in c['processes']} for c in cohorts]
 for a,b in protocol['ratios']:
  key=f'{a}_over_{b}';ratios=[v[a]/v[b] for v in values]
  if phase=='elapsed':assert saved['paired_ratios'][key]==ratios and saved['median_ratios'][key]==statistics.median(ratios)
  else:
   row=saved['comparisons'][key];differences=[v[a]-v[b] for v in values]
   assert row['paired_ratios']==ratios and row['median_ratio']==statistics.median(ratios)
   assert row['paired_difference_kib']==differences and row['median_difference_kib']==statistics.median(differences)
 if phase=='rss':
  for combination in protocol['combinations']:
   data=[v[combination] for v in values]
   assert saved['absolute_workload_peak_rss_kib'][combination]=={'samples':data,'median':statistics.median(data),'min':min(data),'max':max(data)}
for group,saved in report['groups'].items():
 rows=[r for r in report['summary'] if group=='all' or (group=='real' and not r['condition']['name'].startswith('generated-')) or (group=='generated' and r['condition']['name'].startswith('generated-')) or r['condition']['name']==group]
 assert (saved['conditions']==len(rows) if phase=='elapsed' else saved['conditions']==[r['condition'] for r in rows])
 for a,b in protocol['ratios']:
  key=f'{a}_over_{b}';values=[r['median_ratios'][key] if phase=='elapsed' else r['comparisons'][key]['median_ratio'] for r in rows]
  assert saved['ratios'][key]=={'geomean':math.exp(statistics.mean(map(math.log,values))),'lower_conditions':sum(v<1 for v in values),'higher_conditions':sum(v>1 for v in values),'all_ratios':values}
result={'status':'passed','phase':phase,'workers':workers,'parses_including_warmups':parses,'cohorts':len(report['rows']),'conditions':28,'observations_match_preflight':True,'raw_files_match_report':True,'schedule_exact':True,'all_hashes_unchanged':True,'summaries_recomputed_from_raw':True,'nonempty_stderr_workers':nonempty_stderr,'report_sha256':sha(P/'results.json'),'aggregate_elapsed_seconds_operational':report['aggregate_elapsed_seconds'],'groups':report['groups'],'summary':report['summary']}
(O/(phase+'-audit.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['groups','summary']},indent=2))
