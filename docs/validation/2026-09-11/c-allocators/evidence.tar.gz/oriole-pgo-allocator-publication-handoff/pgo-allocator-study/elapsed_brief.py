from pathlib import Path
import json
O=Path(__file__).parent;r=json.loads((O/'native-screen/results.json').read_text());assert r['status']=='passed'
rows={}
for group in ['real','generated']:
 g=r['groups'][group];rows[group]={'conditions':g['conditions'],'engines':{},'matched_oriole_over_expat':{}}
 for engine in ['oriole','expat']:
  rows[group]['engines'][engine]={}
  for mode in ['ordinary','libc','jemalloc','mimalloc']:
   item={'geomean':1.0,'lower_conditions':0,'higher_conditions':0} if mode=='ordinary' else {k:v for k,v in g['ratios'][f'{engine}_{mode}_over_{engine}_ordinary'].items() if k!='all_ratios'}
   rows[group]['engines'][engine][mode]=item
 for mode in ['ordinary','libc','jemalloc','mimalloc']:
  rows[group]['matched_oriole_over_expat'][mode]={k:v for k,v in g['ratios'][f'oriole_{mode}_over_expat_{mode}'].items() if k!='all_ratios'}
(O/'elapsed-brief.json').write_text(json.dumps(rows,indent=2)+'\n')
for group,g in rows.items():
 print(group,g['conditions'])
 for engine,modes in g['engines'].items():print(engine,'; '.join(f'{mode}={row["geomean"]:.9f} (lower {row["lower_conditions"]}, higher {row["higher_conditions"]})' for mode,row in modes.items()))
 print('matched Oriole/Expat','; '.join(f'{mode}={row["geomean"]:.9f} (Oriole lower {row["lower_conditions"]})' for mode,row in g['matched_oriole_over_expat'].items()))
# Every ratio retained, compact tab-separated tables for review.
keys=list(r['summary'][0]['median_ratios'])
with (O/'elapsed-conditions.tsv').open('w') as f:
 f.write('project\tchunk\tnamespaces\t'+'\t'.join(keys)+'\n')
 for row in r['summary']:
  c=row['condition'];f.write(f'{c["name"]}\t{c["chunk"]}\t{c["namespaces"]}\t'+'\t'.join(str(row['median_ratios'][k]) for k in keys)+'\n')
with (O/'elapsed-groups.tsv').open('w') as f:
 f.write('group\tconditions\t'+'\t'.join(keys)+'\n')
 for name,row in r['groups'].items():f.write(f'{name}\t{row["conditions"]}\t'+'\t'.join(str(row['ratios'][k]['geomean']) for k in keys)+'\n')
