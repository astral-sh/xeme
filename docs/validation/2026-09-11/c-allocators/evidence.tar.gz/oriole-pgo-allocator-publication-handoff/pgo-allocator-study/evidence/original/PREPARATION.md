# Four-engine native elapsed screen — prepared, not launched

The controller compares pinned Expat `7a333bc8`, End+Cell baseline `02fcab59`, generic Atomic control `86a32fbb`, and generic Local candidate `2ff8bc05`. All three Oriole libraries retain the matched C-only ThinLTO build settings. No implementation, compiler annotation, or source snapshot changed.

The 28 original conditions and iteration counts are exact matches to the previous compact allocator screen: six real projects with namespaces off/on, two feed sizes, and two generated fixtures at both feed sizes. The compact allocator supplies no runtime component. The existing corpus manifest, native driver, and every fixture hash match the prior protocol.

- 112 preflight processes, each with one warmup and one checked parse.
- Seven cohorts per condition, seed `2026091003`: 196 cohorts and 784 timed processes.
- Every timed process retains one warmup and the original workload-specific iteration count; all raw samples and cohort records remain in the original format.
- Preflight and timing affinity: CPU0. Worker timeout remains 90 seconds.
- Ratios: Atomic/base, Local/Atomic, Local/base, Local/Expat, Atomic/Expat, base/Expat.
- `run`, `digest`, and `save` function syntax trees are unchanged. Worker callback checks, median construction, process boundaries, and timing calls are unchanged.

`controller.patch` contains the complete timer delta. `prepared-protocol.json` pins the controller, libraries, driver, fixtures, frozen source archives, build receipts, and current Local source before either phase may run. Atomic and baseline source checks use archived snapshots; Local also checks all 70 live files. `prepared-schedule.json` records the seeded four-engine order. No parser process has been launched, and no `native-screen` output directory exists.

After root review, the two phase commands are recorded in `preparation.json`. The preparation script intentionally constructs only the controller and protocol; it does not execute either phase.
