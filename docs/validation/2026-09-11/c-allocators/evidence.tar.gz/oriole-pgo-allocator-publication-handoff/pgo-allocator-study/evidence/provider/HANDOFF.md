# Explicit allocator providers: untimed proof passed

The final instrumented proof passed for frozen Oriole `ccfb2295` and Expat `7a333bc8`, each using ordinary construction, libc-MM, namespaced jemalloc-MM and mimalloc-MM. There is no performance result and no default allocator change. The existing ordinary native driver and both parser implementations were untouched.

## Results

- Eight final process runs; sixteen plain/namespace trace observations all match (three elements, ten text bytes in the shared fixture).
- All eighteen loaded parser entry points resolve to the requested frozen library in each process (144 assertions).
- All eleven recorded origin rows resolve to the expected libc, executable or parser file and symbol (88 verified rows). Process malloc/realloc/free remain libc functions.
- Final executable exports exactly the six provider malloc/realloc/free entry points. Its dynamic function table excludes the packaged mimalloc weak C++ new-handler helper and all unprefixed allocator definitions.
- Models remain caller-owned across reset and are freed while the parser is alive. Both child types are parsed/freed before their parent. Callback child creation, suspension/resume, malformed input and amplification-limit cleanup pass.
- A successful small fixture requests twenty Oriole or sixteen Expat allocation operations. Every corresponding failure index is injected once in each MM mode (108 total); all yield no-memory or a null constructor and free every tracked block. No retries or ceilings are relaxed.
- Direct provider realloc growth preserves contents; an impossible-size realloc returns null and leaves the old block readable/freeable; null free succeeds.

## Frozen components

| Component | SHA-256 |
| --- | --- |
| Oriole shared | ccfb22956a11c1b241ec755f46245c61f088187ef93143b77a7afec748983821 |
| Oriole static (pinned, not linked into the proof) | f58d5bc6ed28077933fcbcb84ad876cc7208e0102c9008347223da91a328b03c |
| Expat shared | 7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478 |
| jemalloc archive | 03102704b9d2bfbb1f81111293d7c5df4095ae9ec1f6c37ae08e9d4797500dbd |
| mimalloc archive | bcfb02ff1f059f9f31e3096ad8d32dcc2b8fdd32c4934a6a56b4affb47609721 |
| Final proof executable | 9cfa73b5652d1c706a50c384b0c5d11063737d1de662cf33268913357ec749a5 |

Jemalloc5.3.0-1-ge13ca993 is rebuilt from pinned registry-vendored source with `oriole_je_` public prefix, a private namespace, static PIC output, and C++ allocation operators disabled. Default release allocation behavior remains: debug/prof off, stats/tcache on, background thread off; one arena is observed on the CPU2-only proof. Full configure/compile logs and source archive are retained.

Mimalloc2.3.2 is rebuilt from pinned `libmimalloc-sys0.1.49` v2 source using its packaged `src/static.c` recipe: release optimization, `MI_DEBUG=0`, `MI_BUILD_RELEASE`, `NDEBUG`, initial-exec TLS and no override macro. Its CMake helper files are absent from this vendor snapshot; that failed configuration is retained. Runtime version20302 is asserted. Selected option observations are recorded; no heap/arena/cache tuning was applied.

`provider-build.json` contains actual commands, source file/archive hashes and provider symbol receipts. `proof-final/report.json` contains compile/link arguments, original component hashes, every process observation and raw output hashes. `summary.json` records counts and limitations; `source-references.json` pins the reviewed design and Expat parent/child contract.

## Scope and retained failures

This is a small untimed provider/lifetime proof, not the full28-condition native cohort. The proof executable has allocation bookkeeping and must never be used for timing. Peak suite request bytes include parser metadata; proof-process RSS includes all providers, cases and possible pre-exec high-water accounting. Neither supports an allocator-specific RSS conclusion.

The unexecuted parent-before-child draft, removed-script-execute-bit build failure, missing-CMake-helper configuration failure, strict-C diagnostic failure, and successful intermediate broad-export proof are all retained. The final executable narrows exports without changing either provider's allocation algorithm or rebuilding the parser libraries.

Next step requires root review: a separate sibling native driver and preregistered allocator screen with ordinary/default and libc-MM controls for both engines. No elapsed, full corpus allocator preflight, PGO or LTO experiment was performed here.
