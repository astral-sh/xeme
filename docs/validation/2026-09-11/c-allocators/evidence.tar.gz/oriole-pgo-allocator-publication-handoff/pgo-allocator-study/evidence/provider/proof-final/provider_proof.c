/* Untimed explicit-memory-suite proof. Never use this instrumented driver for timings. */
#define _GNU_SOURCE
#include "expat.h"
#include "mimalloc.h"
#include <assert.h>
#include <dlfcn.h>
#include <gnu/libc-version.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <unistd.h>

extern void *oriole_je_malloc(size_t);
extern void *oriole_je_realloc(void *, size_t);
extern void oriole_je_free(void *);
extern int oriole_je_mallctl(const char *, void *, size_t *, void *, size_t);
extern void *mi_malloc(size_t);
extern void *mi_realloc(void *, size_t);
extern void mi_free(void *);
extern int mi_version(void);

typedef struct {
    const char *name;
    void *(*allocate)(size_t);
    void *(*resize)(void *, size_t);
    void (*release)(void *);
} Provider;
static Provider providers[] = {
    {"libc", malloc, realloc, free},
    {"jemalloc", oriole_je_malloc, oriole_je_realloc, oriole_je_free},
    {"mimalloc", mi_malloc, mi_realloc, mi_free},
};
static Provider *selected;
static int ordinary;
static size_t parser_origin_checks;
#define FIELD(name, function) __typeof__(function) *name
static struct {
    FIELD(create, XML_ParserCreate); FIELD(create_ns, XML_ParserCreateNS);
    FIELD(create_mm, XML_ParserCreate_MM); FIELD(destroy, XML_ParserFree);
    FIELD(parse, XML_Parse); FIELD(reset, XML_ParserReset);
    FIELD(user_data, XML_SetUserData); FIELD(element_handler, XML_SetElementHandler);
    FIELD(text_handler, XML_SetCharacterDataHandler); FIELD(decl_handler, XML_SetElementDeclHandler);
    FIELD(free_model, XML_FreeContentModel); FIELD(child, XML_ExternalEntityParserCreate);
    FIELD(stop, XML_StopParser); FIELD(resume, XML_ResumeParser);
    FIELD(factor, XML_SetBillionLaughsAttackProtectionMaximumAmplification);
    FIELD(threshold, XML_SetBillionLaughsAttackProtectionActivationThreshold);
    FIELD(version, XML_ExpatVersion); FIELD(error, XML_GetErrorCode);
} api;
#undef FIELD

static void fail(const char *message) {
    if (write(2, message, strlen(message)) < 0) _Exit(2);
    if (write(2, "\n", 1) < 0) _Exit(2);
    _Exit(2);
}
#define CHECK(test) do { if (!(test)) fail(#test); } while (0)
typedef struct { void *pointer; size_t bytes; Provider *owner; } Record;
static Record records[8192];
static size_t live, live_bytes, peak_bytes, operations, fail_at, injected;
static size_t total_mallocs, total_reallocs, total_frees, total_injections;
static Record *find(void *pointer) {
    for (size_t i = 0; i < 8192; i++) if (records[i].pointer == pointer) return &records[i];
    fail("pointer missing from originating-provider ledger"); return NULL;
}
static int refuse(void) {
    operations++;
    if (operations == fail_at) { injected++; total_injections++; return 1; }
    return 0;
}
static void record(void *pointer, size_t bytes) {
    if (!pointer) return;
    for (size_t i = 0; i < 8192; i++) CHECK(records[i].pointer != pointer);
    for (size_t i = 0; i < 8192; i++) {
        if (!records[i].pointer) {
            records[i] = (Record){pointer, bytes, selected};
            live++; live_bytes += bytes;
            if (live_bytes > peak_bytes) peak_bytes = live_bytes;
            return;
        }
    }
    fail("bounded pointer ledger exhausted");
}
static void *suite_malloc(size_t bytes) {
    total_mallocs++;
    if (refuse()) return NULL;
    void *pointer = selected->allocate(bytes);
    record(pointer, bytes); return pointer;
}
static void *suite_realloc(void *pointer, size_t bytes) {
    total_reallocs++;
    Record *prior = pointer ? find(pointer) : NULL;
    CHECK(!prior || prior->owner == selected);
    if (refuse()) return NULL;
    /* Parsers' nonzero requests are the proof boundary; zero is provider-defined. */
    CHECK(bytes != 0);
    void *next = selected->resize(pointer, bytes);
    if (!next) return NULL; /* Old record remains owned and live on failure. */
    if (prior) {
        live_bytes -= prior->bytes; prior->pointer = NULL; prior->bytes = 0; live--;
    }
    record(next, bytes); return next;
}
static void suite_free(void *pointer) {
    total_frees++;
    if (pointer) {
        Record *prior = find(pointer); CHECK(prior->owner == selected);
        live_bytes -= prior->bytes; prior->pointer = NULL; prior->bytes = 0; live--;
    }
    selected->release(pointer);
}
static void begin(size_t failure) {
    CHECK(live == 0 && live_bytes == 0);
    operations = 0; injected = 0; fail_at = failure;
}
static void finished(void) { CHECK(live == 0 && live_bytes == 0); }
static XML_Parser create(int namespaces) {
    static const XML_Char separator[] = "|";
    static const XML_Memory_Handling_Suite suite = {suite_malloc, suite_realloc, suite_free};
    if (ordinary) return namespaces ? api.create_ns(NULL, '|') : api.create(NULL);
    return api.create_mm(NULL, &suite, namespaces ? separator : NULL);
}

typedef struct {
    uint64_t hash; size_t elements, text_bytes;
    XML_Parser parser;
    XML_Content *models[8]; size_t models_used;
    int create_child, suspend, child_callbacks;
} State;
static void hash_bytes(State *state, const char *value, size_t length) {
    for (size_t i = 0; i < length; i++) {
        state->hash ^= (unsigned char)value[i]; state->hash *= UINT64_C(1099511628211);
    }
}
static void start(void *context, const XML_Char *name, const XML_Char **attributes) {
    State *state = context;
    hash_bytes(state, "\xffS", 2); hash_bytes(state, name, strlen(name));
    for (size_t i = 0; attributes[i]; i++) {
        hash_bytes(state, "\0", 1); hash_bytes(state, attributes[i], strlen(attributes[i]));
    }
    hash_bytes(state, "\0", 1); state->elements++;
    if (state->create_child) {
        state->create_child = 0;
        XML_Parser child = api.child(state->parser, "", NULL); CHECK(child);
        api.element_handler(child, NULL, NULL); api.text_handler(child, NULL);
        CHECK(api.parse(child, "<child/>", 8, 1) == XML_STATUS_OK);
        api.destroy(child); state->child_callbacks++;
    }
    if (state->suspend) {
        state->suspend = 0;
        CHECK(api.stop(state->parser, XML_TRUE) == XML_STATUS_OK);
    }
}
static void end(void *context, const XML_Char *name) {
    State *state = context;
    hash_bytes(state, "\xff" "E", 2); hash_bytes(state, name, strlen(name)); hash_bytes(state, "\0", 1);
}
static void text(void *context, const XML_Char *value, int length) {
    State *state = context; hash_bytes(state, value, (size_t)length); state->text_bytes += (size_t)length;
}
static void declaration(void *context, const XML_Char *name, XML_Content *model) {
    State *state = context; (void)name;
    CHECK(state->models_used < 8); state->models[state->models_used++] = model;
}
static State install(XML_Parser parser) {
    State state = {0}; state.hash = UINT64_C(14695981039346656037); state.parser = parser;
    api.element_handler(parser, start, end); api.text_handler(parser, text); return state;
}
static int parse_all(XML_Parser parser, const char *input, size_t chunk) {
    size_t length = strlen(input), offset = 0;
    do {
        size_t count = length - offset; if (count > chunk) count = chunk;
        int status = api.parse(parser, input + offset, (int)count, offset + count == length);
        if (status != XML_STATUS_OK) return status;
        offset += count;
    } while (offset < length);
    return XML_STATUS_OK;
}
static void traces(void) {
    const char *input = "<root xmlns='urn:r'><leaf a='v'>alpha&amp;beta</leaf><leaf/></root>";
    printf("\"traces\":[");
    for (int ns = 0; ns < 2; ns++) {
        begin(0); XML_Parser parser = create(ns); CHECK(parser);
        State state = install(parser); api.user_data(parser, &state);
        CHECK(parse_all(parser, input, 7) == XML_STATUS_OK); api.destroy(parser); finished();
        printf("%s{\"namespaces\":%d,\"hash\":\"%016" PRIx64 "\",\"elements\":%zu,\"text_bytes\":%zu}", ns ? "," : "", ns, state.hash, state.elements, state.text_bytes);
    }
    printf("]");
}
static void models_reset(void) {
    begin(0); XML_Parser parser = create(0); CHECK(parser);
    State state = install(parser); api.user_data(parser, &state); api.decl_handler(parser, declaration);
    CHECK(parse_all(parser, "<!DOCTYPE root [<!ELEMENT root (child*)><!ELEMENT child EMPTY>]><root><child/></root>", 11) == XML_STATUS_OK);
    CHECK(state.models_used == 2); CHECK(api.reset(parser, NULL));
    /* Returned models remain caller-owned across reset; the suite is unchanged. */
    for (size_t i = 0; i < state.models_used; i++) api.free_model(parser, state.models[i]);
    CHECK(parse_all(parser, "<again/>", 3) == XML_STATUS_OK); api.destroy(parser); finished();
}
static void shared_children(void) {
    for (int parameter = 0; parameter < 2; parameter++) {
        begin(0); XML_Parser parent = create(0); CHECK(parent);
        XML_Parser child = api.child(parent, parameter ? NULL : "", NULL); CHECK(child);
        CHECK(parse_all(child, parameter ? "<!ELEMENT child EMPTY>" : "<child a='b'>x</child>", 5) == XML_STATUS_OK);
        api.destroy(child); api.destroy(parent); finished();
    }
}
static void callbacks(void) {
    for (int suspend = 0; suspend < 2; suspend++) {
        begin(0); XML_Parser parser = create(0); CHECK(parser);
        State state = install(parser); api.user_data(parser, &state);
        state.suspend = suspend; state.create_child = !suspend;
        int status = parse_all(parser, "<root><leaf/></root>", 4096);
        if (suspend) { CHECK(status == XML_STATUS_SUSPENDED); CHECK(api.resume(parser) == XML_STATUS_OK); }
        else { CHECK(status == XML_STATUS_OK); CHECK(state.child_callbacks == 1); }
        CHECK(state.elements == 2); api.destroy(parser); finished();
    }
}
static void errors_limits(void) {
    begin(0); XML_Parser parser = create(0); CHECK(parser);
    CHECK(parse_all(parser, "<root><child></root>", 4) == XML_STATUS_ERROR);
    CHECK(api.error(parser) == XML_ERROR_TAG_MISMATCH); api.destroy(parser); finished();
    begin(0); parser = create(0); CHECK(parser);
    CHECK(api.factor(parser, 2.0f)); CHECK(api.threshold(parser, 1));
    const char *input = "<!DOCTYPE r [<!ENTITY a '0123456789'><!ENTITY b '&a;&a;&a;&a;&a;&a;&a;&a;&a;&a;'>]><r>&b;&b;&b;&b;&b;&b;&b;&b;&b;&b;</r>";
    CHECK(parse_all(parser, input, 13) == XML_STATUS_ERROR);
    CHECK(api.error(parser) == XML_ERROR_AMPLIFICATION_LIMIT_BREACH); api.destroy(parser); finished();
}
static size_t allocation_failures(void) {
    if (ordinary) { printf(",\"failure_outcomes\":[]"); return 0; }
    const char *input = "<r a='v'><c>text</c></r>";
    begin(0); XML_Parser parser = create(0); CHECK(parser);
    CHECK(parse_all(parser, input, 5) == XML_STATUS_OK); api.destroy(parser); finished();
    size_t count = operations; CHECK(count > 0 && count <= 128);
    printf(",\"failure_outcomes\":[");
    for (size_t i = 1; i <= count; i++) {
        begin(i); parser = create(0); int created = parser != NULL;
        int status = XML_STATUS_ERROR, error = XML_ERROR_NO_MEMORY;
        if (parser) {
            status = parse_all(parser, input, 5); error = api.error(parser);
            CHECK(status == XML_STATUS_OK || error == XML_ERROR_NO_MEMORY);
            api.destroy(parser);
        }
        CHECK(injected == 1); finished();
        printf("%s{\"index\":%zu,\"created\":%d,\"status\":%d,\"error\":%d,\"operations\":%zu}", i == 1 ? "" : ",", i, created, status, error, operations);
    }
    printf("]"); return count;
}
static void provider_semantics(void) {
    unsigned char *pointer = selected->allocate(32); CHECK(pointer);
    for (size_t i = 0; i < 32; i++) pointer[i] = (unsigned char)(i ^ 0xa5);
    unsigned char *resized = selected->resize(pointer, 4096); CHECK(resized);
    for (size_t i = 0; i < 32; i++) CHECK(resized[i] == (unsigned char)(i ^ 0xa5));
    volatile size_t impossible = SIZE_MAX;
    CHECK(selected->resize(resized, impossible) == NULL);
    for (size_t i = 0; i < 32; i++) CHECK(resized[i] == (unsigned char)(i ^ 0xa5));
    selected->release(resized); selected->release(NULL);
}
static void origin(void *address, const char *label) {
    Dl_info info; CHECK(dladdr(address, &info)); CHECK(info.dli_fname);
    printf("{\"label\":\"%s\",\"file\":\"%s\",\"symbol\":\"%s\"}", label, info.dli_fname, info.dli_sname ? info.dli_sname : "");
}
#define ADDRESS(function, destination) do { __typeof__(&(function)) fn = &(function); _Static_assert(sizeof(fn) == sizeof(destination), "function-pointer representation"); memcpy(&(destination), &fn, sizeof(destination)); } while (0)
#define LOAD(field, symbol) do { void *address = dlsym(library, #symbol); CHECK(address); memcpy(&api.field, &address, sizeof(address)); Dl_info info; CHECK(dladdr(address, &info)); CHECK(strcmp(info.dli_fname, argv[1]) == 0); parser_origin_checks++; } while (0)
int main(int argc, char **argv) {
    CHECK(argc == 3);
    ordinary = strcmp(argv[2], "ordinary") == 0;
    selected = NULL;
    for (size_t i = 0; i < 3; i++) if (strcmp(argv[2], providers[i].name) == 0) selected = &providers[i];
    if (ordinary) selected = &providers[0];
    CHECK(selected);
    void *libc = dlopen("libc.so.6", RTLD_NOW | RTLD_LOCAL); CHECK(libc);
    void *process_malloc = dlsym(RTLD_DEFAULT, "malloc"); CHECK(process_malloc == dlsym(libc, "malloc"));
    void *address; ADDRESS(malloc, address); CHECK(address == process_malloc);
    void *library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL); CHECK(library);
    LOAD(create, XML_ParserCreate); LOAD(create_ns, XML_ParserCreateNS); LOAD(create_mm, XML_ParserCreate_MM);
    LOAD(destroy, XML_ParserFree); LOAD(parse, XML_Parse); LOAD(reset, XML_ParserReset);
    LOAD(user_data, XML_SetUserData); LOAD(element_handler, XML_SetElementHandler); LOAD(text_handler, XML_SetCharacterDataHandler);
    LOAD(decl_handler, XML_SetElementDeclHandler); LOAD(free_model, XML_FreeContentModel); LOAD(child, XML_ExternalEntityParserCreate);
    LOAD(stop, XML_StopParser); LOAD(resume, XML_ResumeParser); LOAD(factor, XML_SetBillionLaughsAttackProtectionMaximumAmplification);
    LOAD(threshold, XML_SetBillionLaughsAttackProtectionActivationThreshold); LOAD(version, XML_ExpatVersion); LOAD(error, XML_GetErrorCode);
    const char *je_version = NULL; size_t n = sizeof(je_version);
    CHECK(oriole_je_mallctl("version", &je_version, &n, NULL, 0) == 0);
    CHECK(strcmp(je_version, "5.3.0-1-ge13ca993e8ccb9ba9847cc330696e02839f328f7") == 0); CHECK(mi_version() == 20302);
    printf("{\"mode\":\"%s\",\"parser_version\":\"%s\",\"libc_version\":\"%s\",\"jemalloc_version\":\"%s\",\"mimalloc_version\":%d,\"origins\":[", argv[2], api.version(), gnu_get_libc_version(), je_version, mi_version());
    origin(process_malloc, "process_malloc");
    for (size_t i = 0; i < 3; i++) {
        char label[64];
        memcpy(&address, &providers[i].allocate, sizeof(address));
        printf(","); snprintf(label, sizeof(label), "%s_malloc", providers[i].name); origin(address, label);
        if (i == 0) CHECK(address == dlsym(libc, "malloc"));
        memcpy(&address, &providers[i].resize, sizeof(address));
        printf(","); snprintf(label, sizeof(label), "%s_realloc", providers[i].name); origin(address, label);
        if (i == 0) CHECK(address == dlsym(libc, "realloc"));
        memcpy(&address, &providers[i].release, sizeof(address));
        printf(","); snprintf(label, sizeof(label), "%s_free", providers[i].name); origin(address, label);
        if (i == 0) CHECK(address == dlsym(libc, "free"));
    }
    printf(","); origin(dlsym(library, "XML_ParserCreate_MM"), "parser_create_mm");
    printf("],\"jemalloc_options\":{");
    const char *bool_options[] = {"opt.tcache", "opt.background_thread", "config.debug", "config.stats", "config.prof"};
    for (size_t i = 0; i < sizeof(bool_options) / sizeof(bool_options[0]); i++) {
        _Bool value = 0; size_t length = sizeof(value);
        CHECK(oriole_je_mallctl(bool_options[i], &value, &length, NULL, 0) == 0);
        printf("%s\"%s\":%d", i ? "," : "", bool_options[i], (int)value);
    }
    unsigned arenas = 0; size_t length = sizeof(arenas);
    CHECK(oriole_je_mallctl("opt.narenas", &arenas, &length, NULL, 0) == 0);
    printf(",\"opt.narenas\":%u},\"mimalloc_options\":{\"show_errors\":%ld,\"eager_commit\":%ld,\"arena_eager_commit\":%ld,\"purge_delay\":%ld,\"allow_large_os_pages\":%ld,\"destroy_on_exit\":%ld},", arenas,
        mi_option_get(mi_option_show_errors), mi_option_get(mi_option_eager_commit),
        mi_option_get(mi_option_arena_eager_commit), mi_option_get(mi_option_purge_delay),
        mi_option_get(mi_option_allow_large_os_pages), mi_option_get(mi_option_destroy_on_exit));
    CHECK(parser_origin_checks == 18);
    printf("\"parser_entrypoint_origin_checks\":%zu,", parser_origin_checks);
    provider_semantics(); traces(); models_reset(); shared_children(); callbacks(); errors_limits();
    size_t failure_cases = allocation_failures(); finished();
    CHECK(ordinary || (total_mallocs > 0 && total_frees > 0));
    /* Proof-only RSS includes every provider initialization and every test case. */
    struct rusage usage; CHECK(getrusage(RUSAGE_SELF, &usage) == 0);
    printf(",\"allocation_failure_cases\":%zu,\"injected_failures\":%zu,\"suite_mallocs\":%zu,\"suite_reallocs\":%zu,\"suite_frees\":%zu,\"live_blocks\":%zu,\"live_suite_request_bytes\":%zu,\"peak_suite_request_bytes\":%zu,\"proof_process_peak_rss_kib\":%ld,\"status\":\"passed\"}\n", failure_cases, total_injections, total_mallocs, total_reallocs, total_frees, live, live_bytes, peak_bytes, usage.ru_maxrss);
    dlclose(library); dlclose(libc); return 0;
}
