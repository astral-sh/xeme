from pathlib import Path
import hashlib,json,os,shutil,tarfile,time
O=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
assert os.sched_getaffinity(0)=={2}
a=read(O/'elapsed-audit.json');b=read(O/'rss-audit.json');assert a['status']==b['status']=='passed'
assert a['workers']==1568 and b['workers']==672
native=read(O/'native-screen/results.json');rss=read(O/'rss-screen/results.json')
assert sha(O/'native-screen/results.json')==a['report_sha256'] and sha(O/'rss-screen/results.json')==b['report_sha256']
shutil.copyfile(O/'summary.json',O/'preflight-summary.json')
brief=read(O/'elapsed-brief.json');modes=['ordinary','libc','jemalloc','mimalloc']
lines=['# PGO native allocator comparison','',
'Namespaced jemalloc and mimalloc did not produce a useful real-XML time gain for this Oriole build. Both improved generated-input elapsed aggregates. Expat benefited slightly on real XML, so the matched real-XML Oriole/Expat gap widened under either alternative allocator. No parser source, ordinary driver, default allocator, or allocator settings changed.','',
'## Native elapsed','',
'Time ratios below are geometric means of the per-condition median of seven paired process-median ratios. Lower is faster. All 28 conditions and all 1,568 timed workers are retained; each worker discards one warmup. The 224 preflights matched all eight combinations on each condition.','',
'| Group | Engine | ordinary | libc-MM / ordinary | jemalloc-MM / ordinary | mimalloc-MM / ordinary |','|---|---|---:|---:|---:|---:|']
for group in ['real','generated']:
 for engine in ['oriole','expat']:
  values=brief[group]['engines'][engine]
  cells=[f"{values[m]['geomean']:.6f} ({values[m]['higher_conditions']}/{brief[group]['conditions']} regressions)" for m in modes[1:]]
  lines.append('| '+group+' | '+engine+' | 1.000000 | '+' | '.join(cells)+' |')
lines+=['','| Group | Oriole/Expat ordinary | libc-MM | jemalloc-MM | mimalloc-MM |','|---|---:|---:|---:|---:|']
for group in ['real','generated']:
 lines.append('| '+group+' | '+' | '.join(f"{brief[group]['matched_oriole_over_expat'][m]['geomean']:.6f}" for m in modes)+' |')
lines+=['','Oriole is faster than Expat in 3/24 real conditions under each mode and 0/4 generated conditions. `elapsed-conditions.tsv` retains every condition and all 16 comparison ratios; `elapsed-groups.tsv` includes every project, both generated fixtures, and explicit real/generated/all groups. Paired raw ratios and process samples remain in `native-screen/results.json` and worker files.','',
'## Workload peak RSS','',
'The separate 672-worker/84-cohort CPU2 campaign ran after elapsed ended. Each fresh process used the same binary, provider mode, input/chunk/namespace condition and original iteration count. RSS is Linux current-executable VmHWM, read once after all parse/free iterations; seconds in these raw records are excluded from elapsed summaries. All observations matched preflight.','',
'Absolute RSS includes both static providers’ upstream startup constructors, libc/input/output buffers, parser DSO, workload pages and measurement setup. These are same-executable workload results, not isolated allocator resident bytes. The instrumented provider proof’s RSS is excluded.','',
'`rss-conditions.tsv` contains every combination’s three absolute samples and median/min/max KiB for every condition. `rss-screen/results.json` retains paired KiB differences, ratios, all raw outputs and condition-ratio group summaries. No group statistic is a group peak RSS value.','',
'## Validation and limits','',
'- Frozen 8-process provider-proof replay passed: 144 parser-entry origin checks, 88 provider-origin rows, 108 injected allocation failures, 16 matching trace observations and final zero live suite blocks/bytes. Expat child-before-parent destruction contract preserved.','- Fresh strict C driver build passed. Callback/timer functions and timed loop are byte-identical to the ordinary source except parser constructor selection. Exactly six namespaced allocator functions are exported; no process malloc interposition or allocation ledger.','- Author audit checked all raw records, complete sample vectors, original condition/iteration/seed schedule, every ratio and summary, and before/after hashes. 282,688 elapsed parses plus 448 preflight parses and 121,152 RSS parses; proof cases separately retained. No native or RSS worker failed; no reruns.','- Per-worker 90s, preflight 600s and aggregate 1,200s limits were active with process-group cleanup. Root CPU1 C/API and CPU4 strict checks overlapped the early elapsed run; both later completed. Shared-host frequency/load/memory effects remain uncontrolled.','- These are native callback workloads. They do not establish allocator effects for actual CPython applications or justify a default change. Both parser PGO histories are frozen and engine-specific; no retraining occurred here.','- Retained preparation issues: initial exact-source verifier used suffix matching and rejected ambiguous Cargo.toml; fixed to exact archive members before preflight. A comment-only driver correction produced the identical executable. No benchmark failures were discarded.','',
'## Components and reproducibility','',
'`PREPARATION.md`, `RSS-PLAN.md`, both prepared protocols/schedules, full driver/controller patches and approval receipts define the campaigns. `inputs.json` and copied evidence bind source/build histories; provider archives and their complete source/build receipts remain in the separately sealed explicit-MM proof. Parser libraries are pinned by original absolute path and hash. `EXTERNAL_COMPONENTS.json` indexes these immutable dependencies.','']
marker=lines.index('Absolute RSS includes both static providers’ upstream startup constructors, libc/input/output buffers, parser DSO, workload pages and measurement setup. These are same-executable workload results, not isolated allocator resident bytes. The instrumented provider proof’s RSS is excluded.')
rss_table=['| Group | Engine | libc-MM / ordinary | jemalloc-MM / ordinary | mimalloc-MM / ordinary |','|---|---|---:|---:|---:|']
for group in ['real','generated']:
 for engine in ['oriole','expat']:
  cells=[]
  for mode in modes[1:]:
   row=rss['groups'][group]['ratios'][f'{engine}_{mode}_over_{engine}_ordinary']
   cells.append(f"{row['geomean']:.6f} ({row['higher_conditions']}/{brief[group]['conditions']} higher)")
  rss_table.append('| '+group+' | '+engine+' | '+' | '.join(cells)+' |')
lines[marker:marker]=['Geometric means below summarize per-condition median paired VmHWM ratios; they are not a group peak RSS value.','',*rss_table,'']
(O/'RESULTS.md').write_text('\n'.join(lines))
keys=read(O/'rss-prepared-protocol.json')['combinations']
with (O/'rss-conditions.tsv').open('w') as f:
 f.write('project\tchunk\tnamespaces\tcombination\tmedian_kib\tmin_kib\tmax_kib\tall_samples_kib\n')
 for row in rss['summary']:
  c=row['condition']
  for key in keys:
   v=row['absolute_workload_peak_rss_kib'][key]
   f.write(f'{c["name"]}\t{c["chunk"]}\t{c["namespaces"]}\t{key}\t{v["median"]}\t{v["min"]}\t{v["max"]}\t{v["samples"]}\n')
summary={'status':'complete-author-audited','selection':'No default/parser change. Real Oriole elapsed allocator differences are too small here to claim useful gain. Generated gains retained. Independent root review is separate.','elapsed_brief':brief,'elapsed_groups':native['groups'],'rss_groups':rss['groups'],'counts':{'proof_processes':8,'preflights':224,'preflight_parses':448,'timed_workers':1568,'timed_parses':a['parses_including_warmups'],'timed_cohorts':196,'rss_workers':672,'rss_parses':b['parses_including_warmups'],'rss_cohorts':84,'conditions':28},'components':read(O/'prepared-protocol.json')['libraries'],'driver_sha256':sha(O/'native-allocator-driver'),'driver_source_sha256':sha(O/'native_allocator_driver.c'),'elapsed_controller_sha256':sha(O/'native_screen.py'),'rss_controller_sha256':sha(O/'rss_screen.py'),'elapsed_report_sha256':a['report_sha256'],'rss_report_sha256':b['report_sha256'],'author_audit_sha256':{'elapsed':sha(O/'elapsed-audit.json'),'rss':sha(O/'rss-audit.json')},'source_archive_files_verified':70,'cpu0_released':True,'cpu2_released':True,'defaults_unchanged':True,'parser_source_unchanged':True,'original_driver_unchanged':True,'no_allocator_tuning':True,'sequential_elapsed_then_rss':True,'limits_seconds':{'worker':90,'preflight':600,'elapsed':1200,'rss':1200},'shared_host_activity':read(O/'cpu0-release.json')['shared_host_activity'],'rss_scope':'Absolute same-executable workload VmHWM including both provider constructors; not isolated allocator resident bytes. Proof RSS excluded.'}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
paths=read(O/'prepared-protocol.json')['hashes'];external={p:h for p,h in paths.items() if not Path(p).is_relative_to(O)}
proof=Path('/tmp/oriole-explicit-mm-provider-proof')
for path in [proof/'HANDOFF.md',proof/'MANIFEST.json',proof/'provider-build.json',proof/'proof-final/provider_proof']:
 external[str(path)]=sha(path)
assert all(sha(p)==h for p,h in external.items())
(O/'EXTERNAL_COMPONENTS.json').write_text(json.dumps({'files_sha256':external,'scope':'Existing immutable fixtures/libraries/provider archives and proof provenance. No copies are silently substituted.'},indent=2)+'\n')
(O/'HANDOFF.md').write_text('''# Allocator study handoff

Complete: PGO provider proof replay, strict sibling driver build, 224 preflights, 1,568 elapsed workers and 672 separate RSS workers. Both author audits passed; all 28 conditions and every raw process are retained. CPU0/2 released. No parser/default/provider-setting changes or commits.

Read RESULTS.md and summary.json first. Full protocols, seeded schedules, driver/controller patches, approvals, build/source copies, raw records and audits are indexed by MANIFEST.json. Independent root review/adoption is separate. External pinned libraries/providers/fixtures are indexed in EXTERNAL_COMPONENTS.json and the prior sealed provider proof.

The ordinary/libc/jemalloc/mimalloc real Oriole elapsed factors are 1.000000/1.002669268/.998748605/.999782767. These show no useful real-XML Oriole gain in this screen. The respective matched real Oriole/Expat factors are 1.428561262/1.431577226/1.446136218/1.449922176. Generated gains, regressions and all RSS conditions are retained without filtering.

The compressed handoff is stored alongside this study after sealing; its detached receipt records archive and manifest hashes. No elapsed/RSS reruns or source changes are authorized by this handoff.
''')
# Index all final files; avoid including manifest/archive in its own checksum.
files={str(p.relative_to(O)):sha(p) for p in sorted(O.rglob('*')) if p.is_file() and p!=O/'MANIFEST.json'}
(O/'MANIFEST.json').write_text(json.dumps({'status':'sealed','files_sha256':files,'file_count':len(files)},indent=2)+'\n')
archive=O.with_name(O.name+'-handoff.tar.gz')
assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 t.add(O,arcname=O.name)
receipt={'study':str(O),'archive':str(archive),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'manifest_sha256':sha(O/'MANIFEST.json'),'summary_sha256':sha(O/'summary.json'),'handoff_sha256':sha(O/'HANDOFF.md'),'files_indexed':len(files)}
receipt_path=O.with_name(O.name+'-handoff.json');receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
for p in sorted(O.rglob('*'),reverse=True):
 if p.is_file():p.chmod(0o555 if os.access(p,os.X_OK) else 0o444)
 elif p.is_dir():p.chmod(0o555)
O.chmod(0o555);archive.chmod(0o444);receipt_path.chmod(0o444)
print(json.dumps(receipt,indent=2))
