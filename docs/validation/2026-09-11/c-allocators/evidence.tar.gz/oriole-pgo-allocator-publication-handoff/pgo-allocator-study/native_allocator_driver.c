/* Repeated XML_Parse calls with native callbacks; no Python callback overhead. */
#define _POSIX_C_SOURCE 200809L
#include "expat.h"
#include "mimalloc.h"
#include <dlfcn.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <inttypes.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

extern void *oriole_je_malloc(size_t);
extern void *oriole_je_realloc(void *, size_t);
extern void oriole_je_free(void *);

/* Explicit parser suites only: process malloc remains libc. No callback ledger. */
static const XML_Memory_Handling_Suite libc_suite = {malloc, realloc, free};
static const XML_Memory_Handling_Suite jemalloc_suite = {oriole_je_malloc, oriole_je_realloc, oriole_je_free};
static const XML_Memory_Handling_Suite mimalloc_suite = {mi_malloc, mi_realloc, mi_free};

typedef void *Parser;
typedef struct {
    Parser (*create)(const char *);
    Parser (*create_ns)(const char *, char);
    Parser (*create_mm)(const char *, const XML_Memory_Handling_Suite *, const char *);
    void (*destroy)(Parser);
    int (*parse)(Parser, const char *, int, int);
    void (*user_data)(Parser, void *);
    void (*element_handler)(Parser, void (*)(void *, const char *, const char **), void (*)(void *, const char *));
    void (*text_handler)(Parser, void (*)(void *, const char *, int));
    const char *(*version)(void);
    int (*error)(Parser);
} Api;
typedef struct { uint64_t hash; size_t elements; size_t text_bytes; } State;

static void hash_bytes(State *state, const char *value, size_t length) {
    for (size_t i = 0; i < length; i++) {
        state->hash ^= (unsigned char)value[i];
        state->hash *= UINT64_C(1099511628211);
    }
}
static void start(void *context, const char *name, const char **attributes) {
    State *state = context;
    hash_bytes(state, "\xffS", 2);
    hash_bytes(state, name, strlen(name));
    for (size_t i = 0; attributes[i]; i++) {
        hash_bytes(state, "\0", 1);
        hash_bytes(state, attributes[i], strlen(attributes[i]));
    }
    hash_bytes(state, "\0", 1);
    state->elements++;
}
static void end(void *context, const char *name) {
    State *state = context;
    hash_bytes(state, "\xff" "E", 2);
    hash_bytes(state, name, strlen(name));
    hash_bytes(state, "\0", 1);
}
static void text(void *context, const char *value, int length) {
    State *state = context;
    hash_bytes(state, value, (size_t)length);
    state->text_bytes += (size_t)length;
}
static double now(void) {
    struct timespec stamp;
    if (clock_gettime(CLOCK_MONOTONIC, &stamp)) abort();
    return (double)stamp.tv_sec + (double)stamp.tv_nsec / 1e9;
}
static size_t positive(const char *value) {
    char *endptr = NULL;
    errno = 0;
    unsigned long parsed = strtoul(value, &endptr, 10);
    if (errno || *endptr || !parsed || parsed > INT_MAX) {
        fprintf(stderr, "expected positive integer <= INT_MAX: %s\n", value);
        exit(2);
    }
    return (size_t)parsed;
}
/* Optional separate RSS cohort; called after all parse/free iterations and outside timers.
 * VmHWM belongs to this executable's address space, unlike inherited ru_maxrss.
 * Both statically linked providers have startup constructors in every mode. */
static unsigned long workload_peak_rss_kib(void) {
    char buffer[4096];
    int fd = open("/proc/self/status", O_RDONLY);
    if (fd < 0) { perror("open status"); exit(2); }
    ssize_t count = read(fd, buffer, sizeof(buffer) - 1);
    if (close(fd) || count <= 0) { fprintf(stderr, "status read failed\n"); exit(2); }
    buffer[count] = '\0';
    const char *field = strstr(buffer, "\nVmHWM:");
    unsigned long value = 0;
    if (!field || sscanf(field, "\nVmHWM: %lu kB", &value) != 1 || !value) {
        fprintf(stderr, "missing VmHWM\n"); exit(2);
    }
    return value;
}
#define LOAD(field, symbol) do { \
    void *address = dlsym(library, symbol); \
    if (!address) { fprintf(stderr, "missing %s: %s\n", symbol, dlerror()); return 2; } \
    memcpy(&api.field, &address, sizeof(address)); \
} while (0)
int main(int argc, char **argv) {
    if (argc != 6 && !(argc == 7 && strcmp(argv[6], "namespaces") == 0)) {
        fprintf(stderr, "usage: %s LIBRARY XML_FILE CHUNK_SIZE ITERATIONS {ordinary|libc|jemalloc|mimalloc} [namespaces]\n", argv[0]);
        return 2;
    }
    const XML_Memory_Handling_Suite *suite = NULL;
    if (strcmp(argv[5], "libc") == 0) suite = &libc_suite;
    else if (strcmp(argv[5], "jemalloc") == 0) suite = &jemalloc_suite;
    else if (strcmp(argv[5], "mimalloc") == 0) suite = &mimalloc_suite;
    else if (strcmp(argv[5], "ordinary") != 0) { fprintf(stderr, "unknown allocator\n"); return 2; }
    int namespaces = argc == 7;
    size_t chunk_size = positive(argv[3]), iterations = positive(argv[4]);
    FILE *input = fopen(argv[2], "rb");
    if (!input) { perror("fopen"); return 2; }
    if (fseek(input, 0, SEEK_END)) return 2;
    long length = ftell(input);
    if (length < 0 || fseek(input, 0, SEEK_SET)) return 2;
    char *data = malloc((size_t)length + 1);
    if (!data || fread(data, 1, (size_t)length, input) != (size_t)length) return 2;
    fclose(input);
    void *library = dlopen(argv[1], RTLD_NOW | RTLD_LOCAL);
    if (!library) { fprintf(stderr, "%s\n", dlerror()); return 2; }
    Api api;
    LOAD(create, "XML_ParserCreate");
    LOAD(create_ns, "XML_ParserCreateNS");
    LOAD(create_mm, "XML_ParserCreate_MM");
    LOAD(destroy, "XML_ParserFree");
    LOAD(parse, "XML_Parse");
    LOAD(user_data, "XML_SetUserData");
    LOAD(element_handler, "XML_SetElementHandler");
    LOAD(text_handler, "XML_SetCharacterDataHandler");
    LOAD(version, "XML_ExpatVersion");
    LOAD(error, "XML_GetErrorCode");
    /* Version is a trusted ASCII implementation string. */
    printf("{\"version\":\"%s\",\"samples\":[", api.version());
    uint64_t expected_hash = 0;
    for (size_t iteration = 0; iteration <= iterations; iteration++) {
        State state = {UINT64_C(14695981039346656037), 0, 0};
        double before = now();
        Parser parser = suite ? api.create_mm(NULL, suite, namespaces ? "|" : NULL)
                              : namespaces ? api.create_ns(NULL, '|') : api.create(NULL);
        if (!parser) { fprintf(stderr, "parser allocation failed\n"); return 1; }
        api.user_data(parser, &state);
        api.element_handler(parser, start, end);
        api.text_handler(parser, text);
        size_t offset = 0;
        do {
            size_t count = (size_t)length - offset;
            if (count > chunk_size) count = chunk_size;
            if (api.parse(parser, data + offset, (int)count, offset + count == (size_t)length) != 1) {
                fprintf(stderr, "parse failed with error %d at input offset %zu\n", api.error(parser), offset);
                api.destroy(parser);
                return 1;
            }
            offset += count;
        } while (offset < (size_t)length);
        api.destroy(parser);
        double elapsed = now() - before;
        if (iteration == 0) expected_hash = state.hash;
        if (state.hash != expected_hash) { fprintf(stderr, "unstable output\n"); return 1; }
        printf("%s{\"iteration\":%zu,\"warmup\":%s,\"seconds\":%.9f,\"hash\":\"%016" PRIx64 "\",\"elements\":%zu,\"text_bytes\":%zu}", iteration ? "," : "", iteration, iteration ? "false" : "true", elapsed, state.hash, state.elements, state.text_bytes);
    }
    printf("]");
    if (getenv("ORIOLE_NATIVE_RSS")) printf(",\"workload_peak_rss_kib\":%lu", workload_peak_rss_kib());
    puts("}");
    free(data);
    dlclose(library);
    return 0;
}
