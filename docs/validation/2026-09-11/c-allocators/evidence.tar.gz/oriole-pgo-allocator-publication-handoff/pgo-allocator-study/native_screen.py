"""Prepared, approval-gated eight-combination PGO native allocator screen."""
import hashlib
import json
import math
import os
from pathlib import Path
import random
import signal
import statistics
import subprocess
import sys
import time

root = Path('/tmp/oriole-pgo-allocator-native-study')
output = root / 'native-screen'
driver = root / 'native-allocator-driver'
original = root / 'evidence/original/prepared-protocol.json'
modes = ['ordinary', 'libc', 'jemalloc', 'mimalloc']
engines = ['oriole', 'expat']
combinations = [f'{engine}_{mode}' for engine in engines for mode in modes]
identities = {f'{engine}_{mode}': (engine, mode) for engine in engines for mode in modes}
ratios = [(f'{engine}_{a}', f'{engine}_{b}') for engine in engines
          for a, b in [('libc', 'ordinary'), ('jemalloc', 'ordinary'),
                       ('mimalloc', 'ordinary'), ('jemalloc', 'libc'),
                       ('mimalloc', 'libc'), ('mimalloc', 'jemalloc')]]
ratios += [(f'oriole_{mode}', f'expat_{mode}') for mode in modes]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    (output / name).write_text(json.dumps(value, indent=2) + '\n')


def build_protocol():
    inputs = json.loads((root / 'inputs.json').read_text())
    previous = json.loads(original.read_text())
    conditions = previous['conditions']
    assert len(conditions) == 28 and previous['pairs'] == 7 and previous['seed'] == 2026091003
    for row in inputs['libraries'].values():
        assert digest(row['path']) == row['sha256']
    fixture_paths = sorted({c['input'] for c in conditions})
    for path in fixture_paths:
        assert digest(path) == previous['hashes'][path]
    evidence = sorted(p for p in (root / 'evidence').rglob('*') if p.is_file())
    provider_root = Path('/tmp/oriole-explicit-mm-provider-proof')
    paths = [Path(__file__), driver, root / 'native_allocator_driver.c', root / 'driver-build.json',
             root / 'inputs.json', root / 'prepared-schedule.json', root / 'proof-replay/report.json',
             provider_root / 'libjemalloc.a', provider_root / 'libmimalloc.a',
             *[Path(v['path']) for v in inputs['libraries'].values()],
             *map(Path, fixture_paths), *evidence]
    return {
        'scope': 'PGO Oriole 4f1518 and PGO Expat 12d33; native callbacks only. Two parsers by four explicit allocator modes. All six original real XML inputs, both namespace modes, 4KiB/64KiB feeds; both generated adverse inputs at both feed sizes. Same statically linked provider executable for all modes; process malloc remains libc. No default change, provider tuning, or parser source change. PGO histories differ by engine and are frozen in evidence. Shared host; all conditions and raw cohorts retained.',
        'libraries': inputs['libraries'], 'driver': str(driver), 'modes': modes,
        'combinations': combinations, 'ratios': [list(p) for p in ratios],
        'conditions': conditions, 'pairs': 7, 'seed': 2026091003,
        'preflights': 224, 'timed_workers': 1568, 'cohorts': 196,
        'preflight_cpu': 2, 'timing_cpu': 0,
        'worker_timeout_seconds': 90, 'preflight_timeout_seconds': 600,
        'timed_aggregate_timeout_seconds': 1200,
        'one_discarded_warmup_per_process': True,
        'rss_scope': 'Disabled for this elapsed campaign; separate unlaunched plan uses same binary and workload with ORIOLE_NATIVE_RSS=1 after every iteration has completed.',
        'hashes': {str(p): digest(p) for p in paths}}


def schedule_for(conditions):
    rng = random.Random(2026091003)
    jobs = [(index, pair) for index in range(len(conditions)) for pair in range(7)]
    rng.shuffle(jobs)
    result = []
    for index, pair in jobs:
        order = list(combinations)
        rng.shuffle(order)
        result.append({'condition_index': index, 'pair': pair, 'order': order})
    return result


def clean_environment():
    env = os.environ.copy()
    removed = []
    for key in list(env):
        if key in ['LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH', 'MALLOC_CONF',
                   '_RJEM_MALLOC_CONF', 'ORIOLE_JE_MALLOC_CONF', 'ORIOLE_NATIVE_RSS'] or key.startswith('MIMALLOC_'):
            removed.append(key)
            del env[key]
    return env, sorted(removed)


def run(condition, combination, pair, count, protocol, env, deadline):
    engine, mode = identities[combination]
    cpu = protocol['preflight_cpu'] if pair < 0 else protocol['timing_cpu']
    command = ['taskset', '-c', str(cpu), str(driver), protocol['libraries'][engine]['path'],
               condition['input'], str(condition['chunk']), str(count), mode]
    if condition['namespaces']:
        command.append('namespaces')
    ordinal = len(list(output.glob('worker-*.json')))
    stem = f'worker-{ordinal:04d}'
    record = {'condition': condition, 'engine': engine, 'allocator': mode,
              'combination': combination, 'pair': pair, 'command': command,
              'worker_timeout_seconds': 90, 'status': 'incomplete'}
    save(stem + '.json', record)
    process = None
    with (output / (stem + '.stdout')).open('wb') as stdout, (output / (stem + '.stderr')).open('wb') as stderr:
        try:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('aggregate deadline expired before worker')
            process = subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            record['returncode'] = process.wait(timeout=min(90, remaining))
            assert record['returncode'] == 0, record
        except BaseException as exc:
            record['exception'] = repr(exc)
            record['status'] = 'failed'
            raise
        finally:
            if process is not None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                record['returncode'] = process.wait()
            stdout.flush()
            stderr.flush()
            record['stdout'] = (output / (stem + '.stdout')).read_text()
            record['stderr'] = (output / (stem + '.stderr')).read_text()
            record['stdout_sha256'] = digest(output / (stem + '.stdout'))
            record['stderr_sha256'] = digest(output / (stem + '.stderr'))
            save(stem + '.json', record)
    try:
        payload = json.loads(record['stdout'])
        assert 'workload_peak_rss_kib' not in payload
        samples = payload['samples']
        assert len(samples) == count + 1
        assert [sample['iteration'] for sample in samples] == list(range(count + 1))
        assert [sample['warmup'] for sample in samples] == [True] + [False] * count
        assert all(sample['seconds'] > 0 for sample in samples)
        observed = sorted({(sample['hash'], sample['elements'], sample['text_bytes']) for sample in samples})
        assert len(observed) == 1
        record['observations'] = [list(row) for row in observed]
        record['median_seconds'] = statistics.median(sample['seconds'] for sample in samples[1:])
        record['status'] = 'passed'
    except BaseException as exc:
        record['exception'] = repr(exc)
        record['status'] = 'failed'
        raise
    finally:
        save(stem + '.json', record)
    return record


def summarize(report, conditions):
    for condition in conditions:
        cohorts = [row for row in report['rows'] if row['condition'] == condition]
        assert len(cohorts) == 7 and {row['pair'] for row in cohorts} == set(range(7))
        values = {f'{a}_over_{b}': [] for a, b in ratios}
        for cohort in cohorts:
            seconds = {process['combination']: process['median_seconds'] for process in cohort['processes']}
            assert set(seconds) == set(combinations)
            for a, b in ratios:
                values[f'{a}_over_{b}'].append(seconds[a] / seconds[b])
        report['summary'].append({'condition': condition, 'paired_ratios': values,
                                  'median_ratios': {key: statistics.median(data) for key, data in values.items()}})
    groups = {'real': [r for r in report['summary'] if not r['condition']['name'].startswith('generated-')],
              'generated': [r for r in report['summary'] if r['condition']['name'].startswith('generated-')],
              'all': report['summary']}
    for name in dict.fromkeys(c['name'] for c in conditions):
        groups[name] = [r for r in report['summary'] if r['condition']['name'] == name]
    report['groups'] = {}
    for group, rows in groups.items():
        report['groups'][group] = {'conditions': len(rows), 'ratios': {}}
        for a, b in ratios:
            key = f'{a}_over_{b}'
            values = [r['median_ratios'][key] for r in rows]
            report['groups'][group]['ratios'][key] = {
                'geomean': math.exp(statistics.mean(map(math.log, values))),
                'lower_conditions': sum(v < 1 for v in values),
                'higher_conditions': sum(v > 1 for v in values), 'all_ratios': values}


def main():
    phase = sys.argv[1]
    assert phase in ['preflight', 'time']
    # The phase deadline covers setup/hashing, all workers, validation, and summary.
    budget = 600 if phase == 'preflight' else 1200
    started = time.monotonic()
    def expired(signum, frame):
        raise TimeoutError(f'{phase} aggregate {budget}s deadline expired')
    signal.signal(signal.SIGALRM, expired)
    signal.signal(signal.SIGTERM, expired)
    signal.setitimer(signal.ITIMER_REAL, budget)
    report = None
    try:
        assert os.sched_getaffinity(0) == ({2} if phase == 'preflight' else {0})
        protocol = build_protocol()
        assert json.loads((root / 'prepared-protocol.json').read_text()) == protocol
        assert json.loads((root / 'prepared-schedule.json').read_text()) == schedule_for(protocol['conditions'])
        approval = json.loads((root / 'approval.json').read_text())
        assert approval['approved_protocol_sha256'] == digest(root / 'prepared-protocol.json')
        assert approval['approved_controller_sha256'] == digest(Path(__file__))
        env, removed = clean_environment()
        hashes = protocol['hashes']
        conditions = protocol['conditions']
        if phase == 'preflight':
            output.mkdir(exist_ok=False)
            save('protocol.json', protocol)
            report = {'status': 'incomplete', 'rows': [], 'protocol_sha256': digest(output / 'protocol.json'),
                      'hashes_before': hashes, 'removed_environment_keys': removed,
                      'aggregate_timeout_seconds': budget, 'affinity': sorted(os.sched_getaffinity(0)),
                      'rss_environment_absent': 'ORIOLE_NATIVE_RSS' not in env}
            for condition in conditions:
                observations = []
                for combination in combinations:
                    row = run(condition, combination, -1, 1, protocol, env, started + budget)
                    report['rows'].append(row)
                    observations.append(row['observations'])
                    save('preflight.json', report)
                assert all(row == observations[0] for row in observations)
            assert len(report['rows']) == 224
        else:
            assert json.loads((output / 'protocol.json').read_text()) == protocol
            assert not (output / 'results.json').exists(), 'no reruns'
            preflight = json.loads((output / 'preflight.json').read_text())
            assert preflight['status'] == 'passed' and preflight['hashes_after'] == hashes
            expected = {json.dumps(row['condition'], sort_keys=True): row['observations'] for row in preflight['rows']}
            report = {'status': 'incomplete', 'protocol_sha256': digest(output / 'protocol.json'),
                      'preflight_sha256': digest(output / 'preflight.json'), 'hashes_before': hashes,
                      'affinity': sorted(os.sched_getaffinity(0)), 'rows': [], 'summary': [], 'removed_environment_keys': removed,
                      'aggregate_timeout_seconds': budget, 'rss_environment_absent': 'ORIOLE_NATIVE_RSS' not in env}
            for job in schedule_for(conditions):
                condition = conditions[job['condition_index']]
                cohort = {'condition': condition, 'pair': job['pair'], 'order': job['order'], 'processes': []}
                report['rows'].append(cohort)
                for combination in job['order']:
                    row = run(condition, combination, job['pair'], condition['iterations'], protocol, env, started + budget)
                    cohort['processes'].append(row)
                    assert row['observations'] == expected[json.dumps(condition, sort_keys=True)]
                    save('results.json', report)
            assert len(report['rows']) == 196 and sum(len(r['processes']) for r in report['rows']) == 1568
            summarize(report, conditions)
            assert len(report['summary']) == 28
        report['hashes_after'] = {path: digest(path) for path in hashes}
        assert report['hashes_after'] == hashes
        report['status'] = 'passed'
    except BaseException as exc:
        if report is not None:
            report['exception'] = repr(exc)
            report['status'] = 'failed'
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        if report is not None:
            report['aggregate_elapsed_seconds'] = time.monotonic() - started
            save('preflight.json' if phase == 'preflight' else 'results.json', report)
    print(json.dumps({'status': report['status'], 'phase': phase, 'rows': len(report['rows'])}), flush=True)


if __name__ == '__main__':
    main()
