from pathlib import Path
import hashlib,json,shutil,difflib,subprocess,os,signal,time
O=Path(__file__).parent;P=Path('/tmp/oriole-explicit-mm-provider-proof');assert os.sched_getaffinity(0)=={2}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
original=Path('/home/dev-user/code/oss/oriole-raw-len-split/benchmarks/native_driver.c');old=original.read_text();assert sha(original)=='3ee1dd4de79d12f8fed9224d5b1e88a3724ba7c2582b1b959c56ea4c5b1a6ee1'
shutil.copyfile(original,O/'native_driver_original.c');shutil.copyfile(P/'proof-final/expat.h',O/'expat.h')
s=old.replace('#include <dlfcn.h>','#include "expat.h"\n#include "mimalloc.h"\n#include <dlfcn.h>\n#include <fcntl.h>\n#include <unistd.h>')
s=s.replace('typedef void *Parser;', '''extern void *oriole_je_malloc(size_t);
extern void *oriole_je_realloc(void *, size_t);
extern void oriole_je_free(void *);

/* Explicit parser suites only: process malloc remains libc. No callback ledger. */
static const XML_Memory_Handling_Suite libc_suite = {malloc, realloc, free};
static const XML_Memory_Handling_Suite jemalloc_suite = {oriole_je_malloc, oriole_je_realloc, oriole_je_free};
static const XML_Memory_Handling_Suite mimalloc_suite = {mi_malloc, mi_realloc, mi_free};

typedef void *Parser;''')
s=s.replace('    Parser (*create_ns)(const char *, char);','    Parser (*create_ns)(const char *, char);\n    Parser (*create_mm)(const char *, const XML_Memory_Handling_Suite *, const char *);')
s=s.replace('#define LOAD(field, symbol)', '''/* Optional separate RSS cohort; called after all parse/free iterations and outside timers.
 * VmHWM belongs to this executable's address space, unlike inherited ru_maxrss.
 * Both statically linked providers have startup constructors in every mode. */
static unsigned long workload_peak_rss_kib(void) {
    char buffer[4096];
    int fd = open("/proc/self/status", O_RDONLY);
    if (fd < 0) { perror("open status"); exit(2); }
    ssize_t count = read(fd, buffer, sizeof(buffer) - 1);
    if (close(fd) || count <= 0) { fprintf(stderr, "status read failed\\n"); exit(2); }
    buffer[count] = '\\0';
    const char *field = strstr(buffer, "\\nVmHWM:");
    unsigned long value = 0;
    if (!field || sscanf(field, "\\nVmHWM: %lu kB", &value) != 1 || !value) {
        fprintf(stderr, "missing VmHWM\\n"); exit(2);
    }
    return value;
}
#define LOAD(field, symbol)''')
s=s.replace('if (argc != 5 && !(argc == 6 && strcmp(argv[5], "namespaces") == 0)) {','if (argc != 6 && !(argc == 7 && strcmp(argv[6], "namespaces") == 0)) {')
s=s.replace('ITERATIONS [namespaces]','ITERATIONS {ordinary|libc|jemalloc|mimalloc} [namespaces]')
s=s.replace('    size_t chunk_size = positive(argv[3]), iterations = positive(argv[4]);','''    const XML_Memory_Handling_Suite *suite = NULL;
    if (strcmp(argv[5], "libc") == 0) suite = &libc_suite;
    else if (strcmp(argv[5], "jemalloc") == 0) suite = &jemalloc_suite;
    else if (strcmp(argv[5], "mimalloc") == 0) suite = &mimalloc_suite;
    else if (strcmp(argv[5], "ordinary") != 0) { fprintf(stderr, "unknown allocator\\n"); return 2; }
    int namespaces = argc == 7;
    size_t chunk_size = positive(argv[3]), iterations = positive(argv[4]);''')
s=s.replace('    LOAD(create_ns, "XML_ParserCreateNS");','    LOAD(create_ns, "XML_ParserCreateNS");\n    LOAD(create_mm, "XML_ParserCreate_MM");')
old_create="        Parser parser = argc == 6 ? api.create_ns(NULL, '|') : api.create(NULL);"
new_create="""        Parser parser = suite ? api.create_mm(NULL, suite, namespaces ? "|" : NULL)
                              : namespaces ? api.create_ns(NULL, '|') : api.create(NULL);"""
assert old_create in s;s=s.replace(old_create,new_create)
s=s.replace('    puts("]}");','''    printf("]");
    if (getenv("ORIOLE_NATIVE_RSS")) printf(",\\"workload_peak_rss_kib\\":%lu", workload_peak_rss_kib());
    puts("}");''')
(O/'native_allocator_driver.c').write_text(s)
(O/'driver.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile=str(original),tofile=str(O/'native_allocator_driver.c'))))
# Exact callback/timer-loop comparison, allowing only reviewed constructor choice.
callbacks=lambda x:x[x.index('static void hash_bytes'):x.index('static size_t positive')]
loop=lambda x:x[x.index('    for (size_t iteration'):x.index('    puts("]}");') if '    puts("]}");' in x else x.index('    printf("]");')]
assert callbacks(old)==callbacks(s)
assert loop(old)==loop(s).replace(new_create,old_create)
providers=json.loads((P/'provider-build.json').read_text());assert all(sha(v['archive'])==v['sha256'] for v in providers['providers'].values())
cmd=['cc','-std=c11','-O3','-Wall','-Wextra','-Werror',*['-Wl,--export-dynamic-symbol='+prefix+fn for prefix in ['oriole_je_','mi_'] for fn in ['malloc','realloc','free']],'-I'+str(O),'-I'+str(P/'mimalloc-source/include'),str(O/'native_allocator_driver.c'),str(P/'libjemalloc.a'),str(P/'libmimalloc.a'),'-ldl','-lpthread','-lm','-lrt','-latomic','-o',str(O/'native-allocator-driver')]
report={'status':'incomplete','command':cmd,'affinity':[2],'original_driver_source_sha256':sha(original),'driver_source_sha256':sha(O/'native_allocator_driver.c'),'callback_and_timer_functions_byte_identical':True,'timed_loop_byte_identical_except_constructor':True,'no_workload_execution':True,'providers':providers['providers']}
def save():(O/'driver-build.json').write_text(json.dumps(report,indent=2)+'\n')
save()
with (O/'driver-compile.stdout').open('wb') as out,(O/'driver-compile.stderr').open('wb') as err:
 p=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True)
 try:report['returncode']=p.wait(timeout=180)
 except BaseException:
  os.killpg(p.pid,signal.SIGKILL);p.wait();raise
 finally:save()
assert report['returncode']==0
for name,args in [('symbols',['nm','-g','--defined-only']),('dynamic-symbols',['nm','-D','--defined-only']),('dependencies',['readelf','-d'])]:
 r=subprocess.run(args+[str(O/'native-allocator-driver')],capture_output=True,text=True,timeout=30);(O/('driver-'+name+'.stdout')).write_text(r.stdout);(O/('driver-'+name+'.stderr')).write_text(r.stderr);assert r.returncode==0
symbols=(O/'driver-symbols.stdout').read_text();defined={r.split()[-1] for r in symbols.splitlines() if len(r.split())>=3}
assert not defined&{'malloc','calloc','realloc','free','reallocarray','aligned_alloc','posix_memalign','memalign','valloc','pvalloc','malloc_usable_size'}
dynamic=(O/'driver-dynamic-symbols.stdout').read_text();exports={r.split()[-1] for r in dynamic.splitlines() if len(r.split())>=3 and r.split()[-2] in ['T','W']};assert exports=={p+f for p in ['oriole_je_','mi_'] for f in ['malloc','realloc','free']}
assert '_ZSt15get_new_handlerv' not in dynamic
report.update(status='passed',driver_sha256=sha(O/'native-allocator-driver'),dynamic_function_exports=sorted(exports),compiler=subprocess.check_output(['cc','--version'],text=True),inputs_unchanged=sha(original)==report['original_driver_source_sha256'])
save();print(json.dumps({'status':report['status'],'driver_sha256':report['driver_sha256'],'no_workload_execution':True}))
