from pathlib import Path
import ast,difflib,hashlib,importlib.util,json,os,tarfile
O=Path(__file__).parent;assert os.sched_getaffinity(0)=={2}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
script=O/'native_screen.py';ast.parse(script.read_text())
spec=importlib.util.spec_from_file_location('prepared_native',script);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
previous=read(O/'evidence/original/prepared-protocol.json');schedule=module.schedule_for(previous['conditions'])
assert len(schedule)==196
assert {(r['condition_index'],r['pair']) for r in schedule}=={(c,p) for c in range(28) for p in range(7)}
assert all(len(r['order'])==8 and set(r['order'])==set(module.combinations) for r in schedule)
(O/'prepared-schedule.json').write_text(json.dumps(schedule,indent=2)+'\n')
protocol=module.build_protocol();assert protocol['conditions']==previous['conditions']
assert protocol['timed_workers']==28*7*2*4==1568 and protocol['preflights']==28*2*4==224
assert protocol['preflight_cpu']==2 and protocol['timing_cpu']==0
assert protocol['pairs']==previous['pairs'] and protocol['seed']==previous['seed']
assert protocol['worker_timeout_seconds']==90 and protocol['preflight_timeout_seconds']==600 and protocol['timed_aggregate_timeout_seconds']==1200
(O/'prepared-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
proof=read(O/'proof-replay/report.json');assert proof['status']=='passed'
assert proof['inputs_unchanged'] and proof['providers_unchanged'] and proof['source_unchanged']
assert len(proof['observations'])==8
build=read(O/'driver-build.json');assert build['status']=='passed' and build['inputs_unchanged'] and build['no_workload_execution']
assert build['driver_sha256']==sha(O/'native-allocator-driver')
assert sha(O/'driver-comment-draft/native-allocator-driver')==build['driver_sha256']
# Copy/hash evidence, not a claim about mutable live worktrees.
for row in read(O/'inputs.json')['evidence_copies']:assert sha(row['copy'])==row['sha256']
source=read(O/'evidence/oriole/source.json')
with tarfile.open(O/'evidence/oriole/source.tar.gz') as archive:
 members={m.name:m for m in archive.getmembers() if m.isfile()}
 for name,want in source['source_sha256'].items():
  matches=[m for n,m in members.items() if n==name]
  assert len(matches)==1,(name,len(matches));assert hashlib.sha256(archive.extractfile(matches[0]).read()).hexdigest()==want
old=(O/'evidence/original/native_screen.py').read_text();new=script.read_text()
(O/'controller.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='/tmp/oriole-entity-budget-modes-thinlto-timing-study/native_screen.py',tofile=str(script))))
report={'status':'prepared-not-timed','libraries':protocol['libraries'],'driver_sha256':build['driver_sha256'],'driver_source_sha256':build['driver_source_sha256'],'controller_sha256':sha(script),'controller_patch_sha256':sha(O/'controller.patch'),'driver_patch_sha256':sha(O/'driver.patch'),'prepared_protocol_sha256':sha(O/'prepared-protocol.json'),'schedule_sha256':sha(O/'prepared-schedule.json'),'proof_replay_report_sha256':sha(O/'proof-replay/report.json'),'proof_processes':8,'parser_origin_checks':sum(r['observation']['parser_entrypoint_origin_checks'] for r in proof['observations']),'provider_origins_checked':sum(len(r['observation']['origins']) for r in proof['observations']),'fault_injections':sum(r['observation']['injected_failures'] for r in proof['observations']),'frozen_oriole_archive_files_verified':len(source['source_sha256']),'original_conditions_exact':True,'original_seed_pairs_iterations_exact':True,'preflights':224,'timed_workers':1568,'cohorts':196,'preflight_cpu':2,'timing_cpu':0,'bounds_seconds':{'worker':90,'preflight':600,'timing':1200},'rss_elapsed_environment_absent':True,'rss_plan_only':True,'driver_comment_only_rebuild_binary_identical':True,'original_driver_untouched':True,'elapsed_not_launched':True,'preflight_not_yet_launched':True}
(O/'preparation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
