from pathlib import Path
import hashlib,json,shutil,difflib
O=Path('/tmp/oriole-pgo-allocator-native-study');P=Path('/tmp/oriole-explicit-mm-provider-proof');S=O/'evidence';S.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={
'oriole':('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use/liboriole_expat.so','4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02'),
'expat':('/tmp/oriole-pgo-study/expat-use-liboriole_expat.so','12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0')}
for path,want in inputs.values():assert sha(path)==want
files={
'oriole':('/tmp/oriole-native-byte-count-pgo-study',['source.json','source.tar.gz','pair-report.json','pair-freeze.json','vector-proof.json','pgo/runs/run-7_l2jvbd/manifest.json','pgo/runs/run-7_l2jvbd/08-build-use.log']),
'expat':('/tmp/oriole-pgo-study',['expat-source.json','expat-use-build.json','expat-use-compile.log','expat-use-configure.log','expat-use-training.json']),
'provider':(str(P),['HANDOFF.md','summary.json','MANIFEST.json','provider-build.json','proof-final/report.json','proof-final/provider_proof.c','proof-final/run_proof.py','proof-final/expat-child-lifetime-reference.txt']),
'original':('/tmp/oriole-entity-budget-modes-thinlto-timing-study',['native_screen.py','prepared-protocol.json','PREPARATION.md'])}
receipts=[]
for label,(base,names) in files.items():
 for n in names:
  src=Path(base)/n;dst=S/label/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert sha(src)==sha(dst);receipts.append({'source':str(src),'copy':str(dst),'sha256':sha(dst)})
old=(P/'proof-final/run_proof.py').read_text()
s=old.replace("O=Path(__file__).parent;P=O/sys.argv[1];P.mkdir();assert os.sched_getaffinity(0)=={2}","O=Path('/tmp/oriole-explicit-mm-provider-proof');P=Path(__file__).parent/'proof-replay';P.mkdir();assert os.sched_getaffinity(0)=={2}\nEXE=O/'proof-final/provider_proof'")
b=s.index('inputs={');e=s.index('\nfor name,(path,want)',b)
s=s[:b]+'inputs='+repr({k+'_so':v for k,v in inputs.items()})+s[e:]
s=s.replace("inputs['oriole_source_manifest']=('/tmp/oriole-raw-len-split-thinlto-study/source.json',sha('/tmp/oriole-raw-len-split-thinlto-study/source.json'))", "inputs['oriole_source_manifest']=('/tmp/oriole-native-byte-count-pgo-study/source.json',sha('/tmp/oriole-native-byte-count-pgo-study/source.json'))\ninputs['proof_executable']=(str(EXE),read(O/'proof-final/report.json')['driver_sha256'])\nassert sha(EXE)==inputs['proof_executable'][1]")
b=s.index(" command=['cc'");e=s.index(" symbols=run",b)
s=s[:b]+" report['driver_sha256']=sha(EXE);report['frozen_proof_report_sha256']=sha(O/'proof-final/report.json')\n"+s[e:]
s=s.replace("P/'provider_proof'",'EXE')
(O/'replay_proof.py').write_text(s)
(O/'proof-controller.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile=str(P/'proof-final/run_proof.py'),tofile=str(O/'replay_proof.py'))))
(O/'inputs.json').write_text(json.dumps({'libraries':{k:{'path':p,'sha256':h} for k,(p,h) in inputs.items()},'evidence_copies':receipts,'frozen_proof_executable':str(P/'proof-final/provider_proof'),'proof_executable_sha256':sha(P/'proof-final/provider_proof')},indent=2)+'\n')
print('prepared frozen proof replay')
