from pathlib import Path
import ast,importlib.util,json,hashlib,difflib,os
O=Path(__file__).parent;assert os.sched_getaffinity(0)=={2}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
script=O/'rss_screen.py';ast.parse(script.read_text());spec=importlib.util.spec_from_file_location('prepared_rss',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
conditions=json.loads((O/'prepared-protocol.json').read_text())['conditions'];schedule=m.schedule_for(conditions)
assert len(schedule)==84 and {(r['condition_index'],r['pair']) for r in schedule}=={(c,p) for c in range(28) for p in range(3)}
assert all(len(r['order'])==8 and set(r['order'])==set(m.native.combinations) for r in schedule)
(O/'rss-prepared-schedule.json').write_text(json.dumps(schedule,indent=2)+'\n')
protocol=m.build_protocol();assert protocol['workers']==672 and protocol['cohorts']==84 and protocol['conditions']==conditions
(O/'rss-prepared-protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
(O/'rss-controller.patch').write_text(''.join(difflib.unified_diff((O/'native_screen.py').read_text().splitlines(True),script.read_text().splitlines(True),fromfile=str(O/'native_screen.py'),tofile=str(script))))
report={'status':'prepared-unlaunched','controller_sha256':sha(script),'protocol_sha256':sha(O/'rss-prepared-protocol.json'),'schedule_sha256':sha(O/'rss-prepared-schedule.json'),'fixed_native_controller_unchanged':sha(O/'native_screen.py')=='333b2295e95ca17a0f198ccb2b40ff79c4ce8e66753239d375be64e35fd55c1d','workers':672,'cohorts':84,'conditions':28,'repetitions':3,'cpu':2,'worker_timeout_seconds':90,'aggregate_timeout_seconds':1200,'requires_completed_elapsed':True,'same_driver_and_iterations':True,'no_seconds_summary':True}
(O/'rss-preparation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
