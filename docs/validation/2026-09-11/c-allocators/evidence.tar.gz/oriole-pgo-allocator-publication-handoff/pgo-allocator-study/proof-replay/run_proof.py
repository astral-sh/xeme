from pathlib import Path
import hashlib,json,os,re,shutil,signal,subprocess,sys,time
O=Path('/tmp/oriole-explicit-mm-provider-proof');P=Path(__file__).parent/'proof-replay';P.mkdir();assert os.sched_getaffinity(0)=={2}
EXE=O/'proof-final/provider_proof'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
providers=read(O/'provider-build.json');assert providers['status']=='passed'
inputs={'oriole_so': ('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use/liboriole_expat.so', '4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02'), 'expat_so': ('/tmp/oriole-pgo-study/expat-use-liboriole_expat.so', '12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0')}
for name,(path,want) in inputs.items():assert sha(path)==want
for name in ['provider_proof.c','expat.h','mimalloc-packaged-build.rs','expat-child-lifetime-reference.txt']:shutil.copyfile(O/name,P/name)
shutil.copyfile(__file__,P/'run_proof.py')
for name,row in providers['providers'].items():assert sha(row['archive'])==row['sha256']
inputs['ordinary_native_driver']=('/home/dev-user/code/oss/oriole-raw-len-split/benchmarks/native_driver.c',sha('/home/dev-user/code/oss/oriole-raw-len-split/benchmarks/native_driver.c'))
inputs['expat_reference']=('/home/dev-user/.cache/oriole/upstream/expat-2.8.4/expat/doc/reference.html',sha('/home/dev-user/.cache/oriole/upstream/expat-2.8.4/expat/doc/reference.html'))
inputs['oriole_source_manifest']=('/tmp/oriole-native-byte-count-pgo-study/source.json',sha('/tmp/oriole-native-byte-count-pgo-study/source.json'))
inputs['proof_executable']=(str(EXE),read(O/'proof-final/report.json')['driver_sha256'])
assert sha(EXE)==inputs['proof_executable'][1]
env=os.environ.copy();removed={}
for k in list(env):
 if k in ['LD_PRELOAD','LD_AUDIT','LD_LIBRARY_PATH','MALLOC_CONF','_RJEM_MALLOC_CONF','ORIOLE_JE_MALLOC_CONF'] or k.startswith('MIMALLOC_'):removed[k]=env.pop(k)
report={'status':'incomplete','affinity':[2],'scope':'Untimed provider-origin and lifetime proof only; not a native elapsed or allocator RSS campaign.','inputs':inputs,'source_sha256':{n:sha(P/n) for n in ['provider_proof.c','expat.h']},'providers':providers['providers'],'provider_build_report_sha256':sha(O/'provider-build.json'),'removed_environment_keys':sorted(removed),'commands':[],'observations':[]}
def save():(P/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args,timeout=120):
 row={'label':label,'command':list(map(str,args)),'timeout':timeout,'start':time.time()};report['commands'].append(row);save();p=None
 with (P/(label+'.stdout')).open('wb') as stdout,(P/(label+'.stderr')).open('wb') as stderr:
  try:
   p=subprocess.Popen(row['command'],cwd=P,env=env,stdout=stdout,stderr=stderr,start_new_session=True);row['exit']=p.wait(timeout=timeout)
   if row['exit']:raise RuntimeError(label+' failed')
  except BaseException as e:
   row['exception']=repr(e)
   if p is not None and p.poll() is None:os.killpg(p.pid,signal.SIGKILL);row['exit']=p.wait()
   raise
  finally:
   stdout.flush();stderr.flush();row['end']=time.time();row['stdout_sha256']=sha(P/(label+'.stdout'));row['stderr_sha256']=sha(P/(label+'.stderr'));save()
 print(label,row['exit'],flush=True);return (P/(label+'.stdout')).read_text()
try:
 report['driver_sha256']=sha(EXE);report['frozen_proof_report_sha256']=sha(O/'proof-final/report.json')
 symbols=run('defined-symbols',['nm','-g','--defined-only',EXE]);defined={line.split()[-1] for line in symbols.splitlines() if len(line.split())>=3}
 forbidden={'malloc','calloc','realloc','free','reallocarray','aligned_alloc','posix_memalign','memalign','valloc','pvalloc','malloc_usable_size'}
 assert not defined&forbidden,defined&forbidden
 dynamic=run('dynamic-symbols',['nm','-D','--defined-only',EXE])
 dynamic_functions={line.split()[-1] for line in dynamic.splitlines() if len(line.split())>=3 and line.split()[-2] in ['T','W']}
 expected_exports={prefix+fn for prefix in ['oriole_je_','mi_'] for fn in ['malloc','realloc','free']}
 assert dynamic_functions==expected_exports,(dynamic_functions,expected_exports)
 assert '_ZSt15get_new_handlerv' not in dynamic
 report['dynamic_function_exports']=sorted(dynamic_functions)
 run('dynamic-dependencies',['readelf','-d',EXE])
 for engine in ['oriole','expat']:
  library=inputs[engine+'_so'][0]
  for mode in ['ordinary','libc','jemalloc','mimalloc']:
   row=json.loads(run(engine+'-'+mode,[EXE,library,mode]));assert row['status']=='passed'
   assert row['live_blocks']==0 and row['live_suite_request_bytes']==0
   assert row['allocation_failure_cases']==row['injected_failures']==len(row['failure_outcomes'])
   assert [x['index'] for x in row['failure_outcomes']]==list(range(1,row['allocation_failure_cases']+1))
   assert row['parser_entrypoint_origin_checks']==18
   expected_labels={'process_malloc','parser_create_mm'}|{provider+'_'+fn for provider in ['libc','jemalloc','mimalloc'] for fn in ['malloc','realloc','free']}
   origins={x['label']:x for x in row['origins']};assert len(origins)==11 and set(origins)==expected_labels
   libc_file=Path(origins['process_malloc']['file']).resolve();assert libc_file.name=='libc.so.6',libc_file
   assert origins['process_malloc']['symbol'] in ['malloc','__libc_malloc']
   for provider in ['libc','jemalloc','mimalloc']:
    for fn in ['malloc','realloc','free']:
     origin=origins[provider+'_'+fn]
     if provider=='libc':assert Path(origin['file']).resolve()==libc_file and origin['symbol'] in [fn,'__libc_'+fn],origin
     else:
      assert Path(origin['file']).resolve()==(EXE).resolve(),origin
      assert origin['symbol']==('oriole_je_' if provider=='jemalloc' else 'mi_')+fn,origin
   assert Path(origins['parser_create_mm']['file']).resolve()==Path(library).resolve()
   assert origins['parser_create_mm']['symbol']=='XML_ParserCreate_MM'
   if report['observations']:assert row['traces']==report['observations'][0]['observation']['traces']
   report['observations'].append({'engine':engine,'mode':mode,'observation':row});save()
 assert len(report['observations'])==8;report['status']='passed'
finally:
 report['inputs_unchanged']=all(sha(path)==value for path,value in inputs.values());report['providers_unchanged']=all(sha(row['archive'])==row['sha256'] for row in providers['providers'].values());report['source_unchanged']=all(sha(P/n)==value and sha(O/n)==value for n,value in report['source_sha256'].items());save()
print(json.dumps({'status':report['status'],'processes':len(report['observations']),'no_timing':True}),flush=True)
