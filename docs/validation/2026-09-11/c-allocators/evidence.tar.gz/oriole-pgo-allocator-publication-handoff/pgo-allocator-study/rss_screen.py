"""Separate same-executable workload VmHWM campaign; never contributes elapsed ratios."""
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import random
import signal
import statistics
import subprocess
import sys
import time

root = Path('/tmp/oriole-pgo-allocator-native-study')
output = root / 'rss-screen'
spec = importlib.util.spec_from_file_location('frozen_native', root / 'native_screen.py')
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
digest = native.digest


def save(name, value):
    (output / name).write_text(json.dumps(value, indent=2) + '\n')


def schedule_for(conditions):
    rng = random.Random(2026091003)
    jobs = [(index, pair) for index in range(len(conditions)) for pair in range(3)]
    rng.shuffle(jobs)
    schedule = []
    for index, pair in jobs:
        order = list(native.combinations)
        rng.shuffle(order)
        schedule.append({'condition_index': index, 'pair': pair, 'order': order})
    return schedule


def build_protocol():
    original = json.loads((root / 'prepared-protocol.json').read_text())
    assert original == native.build_protocol()
    return {'scope': 'Separate absolute same-executable Linux VmHWM workload campaign. Both static provider constructors, libc/input buffer, parser DSO, workload pages, and measurement setup are included; not isolated allocator resident bytes. No provider tuning/stats/ledger. Seconds are retained as raw output only and excluded from elapsed summaries.',
            'native_protocol_sha256': digest(root / 'prepared-protocol.json'),
            'libraries': original['libraries'], 'driver': original['driver'],
            'combinations': original['combinations'], 'conditions': original['conditions'],
            'ratios': original['ratios'], 'repetitions': 3, 'workers': 672, 'cohorts': 84,
            'seed': 2026091003, 'cpu': 2, 'worker_timeout_seconds': 90,
            'aggregate_timeout_seconds': 1200, 'added_environment': {'ORIOLE_NATIVE_RSS': '1'},
            'one_warmup_plus_original_iterations': True,
            'requires_elapsed_complete': True,
            'hashes': {**original['hashes'], str(Path(__file__)): digest(Path(__file__)),
                       str(root / 'RSS-PLAN.md'): digest(root / 'RSS-PLAN.md'),
                       str(root / 'rss-prepared-schedule.json'): digest(root / 'rss-prepared-schedule.json')}}


def run(condition, combination, pair, protocol, env, deadline):
    engine, mode = native.identities[combination]
    count = condition['iterations']
    command = ['taskset', '-c', '2', protocol['driver'], protocol['libraries'][engine]['path'],
               condition['input'], str(condition['chunk']), str(count), mode]
    if condition['namespaces']:
        command.append('namespaces')
    stem = f'worker-{len(list(output.glob("worker-*.json"))):04d}'
    row = {'status': 'incomplete', 'condition': condition, 'combination': combination,
           'engine': engine, 'allocator': mode, 'pair': pair, 'command': command,
           'worker_timeout_seconds': 90}
    save(stem + '.json', row)
    process = None
    with (output / (stem + '.stdout')).open('wb') as stdout, (output / (stem + '.stderr')).open('wb') as stderr:
        try:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('RSS aggregate deadline expired before worker')
            process = subprocess.Popen(command, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            row['returncode'] = process.wait(timeout=min(90, remaining))
            assert row['returncode'] == 0, row
        except BaseException as exc:
            row['status'] = 'failed'
            row['exception'] = repr(exc)
            raise
        finally:
            if process is not None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                row['returncode'] = process.wait()
            stdout.flush()
            stderr.flush()
            row['stdout'] = (output / (stem + '.stdout')).read_text()
            row['stderr'] = (output / (stem + '.stderr')).read_text()
            row['stdout_sha256'] = digest(output / (stem + '.stdout'))
            row['stderr_sha256'] = digest(output / (stem + '.stderr'))
            save(stem + '.json', row)
    try:
        payload = json.loads(row['stdout'])
        rss = payload['workload_peak_rss_kib']
        assert type(rss) is int and rss > 0
        samples = payload['samples']
        assert len(samples) == count + 1
        assert [s['iteration'] for s in samples] == list(range(count + 1))
        assert [s['warmup'] for s in samples] == [True] + [False] * count
        observed = sorted({(s['hash'], s['elements'], s['text_bytes']) for s in samples})
        assert len(observed) == 1
        row['observations'] = [list(observation) for observation in observed]
        row['workload_peak_rss_kib'] = rss
        row['status'] = 'passed'
    except BaseException as exc:
        row['status'] = 'failed'
        row['exception'] = repr(exc)
        raise
    finally:
        save(stem + '.json', row)
    return row


def summarize(report, protocol):
    for condition in protocol['conditions']:
        cohorts = [r for r in report['rows'] if r['condition'] == condition]
        assert len(cohorts) == 3 and {r['pair'] for r in cohorts} == {0, 1, 2}
        values = {combination: [] for combination in protocol['combinations']}
        comparisons = {f'{a}_over_{b}': {'paired_ratios': [], 'paired_difference_kib': []}
                       for a, b in native.ratios}
        for cohort in cohorts:
            rss = {p['combination']: p['workload_peak_rss_kib'] for p in cohort['processes']}
            assert set(rss) == set(protocol['combinations'])
            for combination, value in rss.items():
                values[combination].append(value)
            for a, b in native.ratios:
                comparisons[f'{a}_over_{b}']['paired_ratios'].append(rss[a] / rss[b])
                comparisons[f'{a}_over_{b}']['paired_difference_kib'].append(rss[a] - rss[b])
        for row in comparisons.values():
            row['median_ratio'] = statistics.median(row['paired_ratios'])
            row['median_difference_kib'] = statistics.median(row['paired_difference_kib'])
        report['summary'].append({'condition': condition, 'absolute_workload_peak_rss_kib': {
            key: {'samples': data, 'median': statistics.median(data), 'min': min(data), 'max': max(data)}
            for key, data in values.items()}, 'comparisons': comparisons})
    groups = {'real': [r for r in report['summary'] if not r['condition']['name'].startswith('generated-')],
              'generated': [r for r in report['summary'] if r['condition']['name'].startswith('generated-')],
              'all': report['summary']}
    for name in dict.fromkeys(c['name'] for c in protocol['conditions']):
        groups[name] = [r for r in report['summary'] if r['condition']['name'] == name]
    report['groups'] = {}
    for name, rows in groups.items():
        report['groups'][name] = {'conditions': [r['condition'] for r in rows],
                                  'scope': 'Condition-ratio summary, not group peak RSS.', 'ratios': {}}
        for a, b in native.ratios:
            key = f'{a}_over_{b}'
            values = [r['comparisons'][key]['median_ratio'] for r in rows]
            report['groups'][name]['ratios'][key] = {
                'geomean': math.exp(statistics.mean(map(math.log, values))),
                'lower_conditions': sum(v < 1 for v in values),
                'higher_conditions': sum(v > 1 for v in values), 'all_ratios': values}


def main():
    started = time.monotonic()
    def expired(signum, frame):
        raise TimeoutError('RSS 1200s aggregate deadline or termination')
    signal.signal(signal.SIGALRM, expired)
    signal.signal(signal.SIGTERM, expired)
    signal.setitimer(signal.ITIMER_REAL, 1200)
    report = None
    try:
        assert os.sched_getaffinity(0) == {2}
        protocol = build_protocol()
        assert protocol == json.loads((root / 'rss-prepared-protocol.json').read_text())
        assert schedule_for(protocol['conditions']) == json.loads((root / 'rss-prepared-schedule.json').read_text())
        approval = json.loads((root / 'rss-approval.json').read_text())
        assert approval['approved_protocol_sha256'] == digest(root / 'rss-prepared-protocol.json')
        assert approval['approved_controller_sha256'] == digest(Path(__file__))
        elapsed = json.loads((root / 'native-screen/results.json').read_text())
        assert elapsed['status'] == 'passed' and sum(len(r['processes']) for r in elapsed['rows']) == 1568
        assert elapsed['hashes_after'] == json.loads((root / 'prepared-protocol.json').read_text())['hashes']
        preflight = json.loads((root / 'native-screen/preflight.json').read_text())
        assert preflight['status'] == 'passed'
        expected = {json.dumps(row['condition'], sort_keys=True): row['observations'] for row in preflight['rows']}
        env, removed = native.clean_environment()
        env['ORIOLE_NATIVE_RSS'] = '1'
        output.mkdir(exist_ok=False)
        save('protocol.json', protocol)
        report = {'status': 'incomplete', 'rows': [], 'summary': [], 'affinity': [2],
                  'aggregate_timeout_seconds': 1200, 'removed_environment_keys': removed,
                  'added_environment': {'ORIOLE_NATIVE_RSS': '1'},
                  'native_elapsed_report_sha256': digest(root / 'native-screen/results.json'),
                  'protocol_sha256': digest(root / 'rss-prepared-protocol.json'),
                  'hashes_before': protocol['hashes']}
        for job in schedule_for(protocol['conditions']):
            condition = protocol['conditions'][job['condition_index']]
            cohort = {'condition': condition, 'pair': job['pair'], 'order': job['order'], 'processes': []}
            report['rows'].append(cohort)
            for combination in job['order']:
                row = run(condition, combination, job['pair'], protocol, env, started + 1200)
                cohort['processes'].append(row)
                assert row['observations'] == expected[json.dumps(condition, sort_keys=True)]
                save('results.json', report)
        assert len(report['rows']) == 84 and sum(len(r['processes']) for r in report['rows']) == 672
        summarize(report, protocol)
        assert len(report['summary']) == 28
        report['hashes_after'] = {path: digest(path) for path in protocol['hashes']}
        assert report['hashes_after'] == protocol['hashes']
        report['status'] = 'passed'
    except BaseException as exc:
        if report is not None:
            report['status'] = 'failed'
            report['exception'] = repr(exc)
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        if report is not None:
            report['aggregate_elapsed_seconds'] = time.monotonic() - started
            save('results.json', report)
    print(json.dumps({'status': report['status'], 'workers': 672, 'cohorts': 84}), flush=True)


if __name__ == '__main__':
    main()
