from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,tarfile,time
O=Path(__file__).parent;assert os.sched_getaffinity(0)=={2}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();R=Path('/home/dev-user/.cache/toucan/cargo/registry/src')
J=next(R.glob('*/tikv-jemalloc-sys-0.6.1+5.3.0-1-ge13ca993e8ccb9ba9847cc330696e02839f328f7'));M=next(R.glob('*/libmimalloc-sys-0.1.49'))
report={'status':'incomplete','affinity':[2],'commands':[],'sources':{},'providers':{}}
env=os.environ.copy();removed={}
for key in list(env):
 if key in ['CC','CXX','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LD_PRELOAD','LD_AUDIT','LD_LIBRARY_PATH','MALLOC_CONF','_RJEM_MALLOC_CONF'] or key.startswith('MIMALLOC_'):
  removed[key]=env.pop(key)
env|={'CC':'cc','CXX':'c++','CFLAGS':'-O3 -fPIC','CXXFLAGS':'-O3 -fPIC'};report['environment_overrides']={k:env[k] for k in ['CC','CXX','CFLAGS','CXXFLAGS']};report['removed_environment_keys']=sorted(removed)
def save():(O/'provider-build.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args,cwd,timeout=1200):
 row={'label':label,'command':list(map(str,args)),'cwd':str(cwd),'timeout':timeout,'start':time.time()};report['commands'].append(row);save();p=None
 with (O/(label+'.log')).open('wb') as log:
  try:
   p=subprocess.Popen(row['command'],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['exit']=p.wait(timeout=timeout)
   if row['exit']:raise RuntimeError(label+' failed')
  except BaseException as e:
   row['exception']=repr(e)
   if p is not None and p.poll() is None:os.killpg(p.pid,signal.SIGKILL);row['exit']=p.wait()
   raise
  finally:
   log.flush();row['end']=time.time();row['log_sha256']=sha(O/(label+'.log'));save()
 print(label,row['exit'],flush=True);return (O/(label+'.log')).read_text()
try:
 run('cc-version-02',['cc','--version'],O,30);run('cmake-version-02',['cmake','--version'],O,30);run('make-version-02',['make','--version'],O,30)
 prior=json.loads((O/'provider-attempt-01/provider-build.json').read_text());report['sources']=prior['sources']
 for label in ['jemalloc','mimalloc']:(O/(label+'-build-02')).mkdir()
 report['prior_failed_attempt']='provider-attempt-01';save()
 jbuild=O/'jemalloc-build-02';jsource=O/'jemalloc-source'
 run('jemalloc-configure-02',[jsource/'configure','--with-version=5.3.0-1-ge13ca993e8ccb9ba9847cc330696e02839f328f7','--with-jemalloc-prefix=oriole_je_','--with-private-namespace=oriole_je_private_','--disable-shared','--enable-static','--disable-doc','--disable-cxx','--prefix='+str(jbuild/'install')],jbuild)
 run('jemalloc-build-02',['make','-j1','V=1','build_lib_static'],jbuild)
 mbuild=O/'mimalloc-build-02';msource=O/'mimalloc-source'
 run('mimalloc-configure-02',['cmake','-S',msource,'-B',mbuild,'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER=cc','-DCMAKE_CXX_COMPILER=c++','-DCMAKE_POSITION_INDEPENDENT_CODE=ON','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DMI_OVERRIDE=OFF','-DMI_BUILD_SHARED=OFF','-DMI_BUILD_STATIC=ON','-DMI_BUILD_OBJECT=OFF','-DMI_BUILD_TESTS=OFF'],O)
 run('mimalloc-build-02',['cmake','--build',mbuild,'--parallel','1','--verbose'],O)
 for label,path,required in [('jemalloc',jbuild/'lib/libjemalloc_pic.a',['oriole_je_malloc','oriole_je_realloc','oriole_je_free','oriole_je_mallctl']),('mimalloc',mbuild/'libmimalloc.a',['mi_malloc','mi_realloc','mi_free','mi_version'])]:
  assert path.is_file(),path
  dest=O/('lib'+label+'.a');shutil.copyfile(path,dest)
  nm=run(label+'-symbols-02',['nm','-g','--defined-only',dest],O,60)
  defined={line.split()[-1] for line in nm.splitlines() if len(line.split())>=3}
  assert set(required)<=defined,(label,set(required)-defined)
  forbidden={'malloc','calloc','realloc','free','reallocarray','aligned_alloc','posix_memalign','memalign','valloc','pvalloc','malloc_usable_size'}
  assert not defined&forbidden,(label,defined&forbidden)
  report['providers'][label]={'archive':str(dest),'sha256':sha(dest),'bytes':dest.stat().st_size,'required_symbols':required,'unprefixed_allocator_definitions':[]}
 report['sources_unchanged']=all(sha(O/(label+'-source')/name)==value for label,r in report['sources'].items() for name,value in r['files'].items());assert report['sources_unchanged'];report['status']='passed'
finally:save()
print(json.dumps({'status':report['status'],'providers':report['providers']}),flush=True)
