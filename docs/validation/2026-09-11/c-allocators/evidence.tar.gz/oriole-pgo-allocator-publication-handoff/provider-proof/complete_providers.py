from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,tarfile,time
O=Path(__file__).parent;assert os.sched_getaffinity(0)=={2}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();R=Path('/home/dev-user/.cache/toucan/cargo/registry/src')
J=next(R.glob('*/tikv-jemalloc-sys-0.6.1+5.3.0-1-ge13ca993e8ccb9ba9847cc330696e02839f328f7'));M=next(R.glob('*/libmimalloc-sys-0.1.49'))
report={'status':'incomplete','affinity':[2],'commands':[],'sources':{},'providers':{}}
env=os.environ.copy();removed={}
for key in list(env):
 if key in ['CC','CXX','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LD_PRELOAD','LD_AUDIT','LD_LIBRARY_PATH','MALLOC_CONF','_RJEM_MALLOC_CONF'] or key.startswith('MIMALLOC_'):
  removed[key]=env.pop(key)
env|={'CC':'cc','CXX':'c++','CFLAGS':'-O3 -fPIC','CXXFLAGS':'-O3 -fPIC'};report['environment_overrides']={k:env[k] for k in ['CC','CXX','CFLAGS','CXXFLAGS']};report['removed_environment_keys']=sorted(removed)
def save():(O/'provider-build.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args,cwd,timeout=1200):
 row={'label':label,'command':list(map(str,args)),'cwd':str(cwd),'timeout':timeout,'start':time.time()};report['commands'].append(row);save();p=None
 with (O/(label+'.log')).open('wb') as log:
  try:
   p=subprocess.Popen(row['command'],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['exit']=p.wait(timeout=timeout)
   if row['exit']:raise RuntimeError(label+' failed')
  except BaseException as e:
   row['exception']=repr(e)
   if p is not None and p.poll() is None:os.killpg(p.pid,signal.SIGKILL);row['exit']=p.wait()
   raise
  finally:
   log.flush();row['end']=time.time();row['log_sha256']=sha(O/(label+'.log'));save()
 print(label,row['exit'],flush=True);return (O/(label+'.log')).read_text()
try:
 prior=json.loads((O/'provider-attempt-02/provider-build.json').read_text());report=prior
 report['status']='incomplete';report['mimalloc_build_route']='Packaged libmimalloc-sys build.rs static.c recipe; CMake helper files absent from vendor snapshot.'
 recipe=M/'build.rs';shutil.copyfile(recipe,O/'mimalloc-packaged-build.rs');report['mimalloc_packaged_build_script_sha256']=sha(recipe)
 jbuild=O/'jemalloc-build-02';mbuild=O/'mimalloc-direct-build';mbuild.mkdir()
 msource=O/'mimalloc-source'
 run('mimalloc-direct-compile',['cc','-O3','-fPIC','-ffunction-sections','-fdata-sections','-ftls-model=initial-exec','-std=c11','-Wno-error=date-time','-DMI_DEBUG=0','-DMI_BUILD_RELEASE','-DNDEBUG','-I'+str(msource/'include'),'-I'+str(msource/'src'),'-c',msource/'src/static.c','-o',mbuild/'mimalloc.o'],O)
 run('mimalloc-direct-archive',['ar','crs',mbuild/'libmimalloc.a',mbuild/'mimalloc.o'],O)
 for label,path,required in [('jemalloc',jbuild/'lib/libjemalloc_pic.a',['oriole_je_malloc','oriole_je_realloc','oriole_je_free','oriole_je_mallctl']),('mimalloc',mbuild/'libmimalloc.a',['mi_malloc','mi_realloc','mi_free','mi_version'])]:
  assert path.is_file(),path
  dest=O/('lib'+label+'.a');shutil.copyfile(path,dest)
  nm=run(label+'-symbols-02',['nm','-g','--defined-only',dest],O,60)
  defined={line.split()[-1] for line in nm.splitlines() if len(line.split())>=3}
  assert set(required)<=defined,(label,set(required)-defined)
  forbidden={'malloc','calloc','realloc','free','reallocarray','aligned_alloc','posix_memalign','memalign','valloc','pvalloc','malloc_usable_size'}
  assert not defined&forbidden,(label,defined&forbidden)
  report['providers'][label]={'archive':str(dest),'sha256':sha(dest),'bytes':dest.stat().st_size,'required_symbols':required,'unprefixed_allocator_definitions':[]}
 report['sources_unchanged']=all(sha(O/(label+'-source')/name)==value for label,r in report['sources'].items() for name,value in r['files'].items());assert report['sources_unchanged'];report['status']='passed'
finally:save()
print(json.dumps({'status':report['status'],'providers':report['providers']}),flush=True)
