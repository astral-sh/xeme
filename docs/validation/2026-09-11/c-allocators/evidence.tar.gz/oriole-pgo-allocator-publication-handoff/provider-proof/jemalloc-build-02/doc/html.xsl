<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
  <xsl:import href="/html/docbook.xsl"/>
  <xsl:import href="/tmp/oriole-explicit-mm-provider-proof/jemalloc-source/doc/stylesheet.xsl"/>
  <xsl:output method="xml" encoding="utf-8"/>
</xsl:stylesheet>
