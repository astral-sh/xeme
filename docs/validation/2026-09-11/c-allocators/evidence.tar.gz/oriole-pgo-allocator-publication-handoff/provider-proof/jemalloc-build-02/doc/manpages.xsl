<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">
  <xsl:import href="/manpages/docbook.xsl"/>
  <xsl:import href="/tmp/oriole-explicit-mm-provider-proof/jemalloc-source/doc/stylesheet.xsl"/>
</xsl:stylesheet>
