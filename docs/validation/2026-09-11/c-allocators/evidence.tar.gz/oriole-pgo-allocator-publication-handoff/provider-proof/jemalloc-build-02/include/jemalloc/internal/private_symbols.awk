#!/usr/bin/env awk -f

BEGIN {
  sym_prefix = ""
  split("\
        oriole_je_aligned_alloc \
        oriole_je_calloc \
        oriole_je_dallocx \
        oriole_je_free \
        oriole_je_mallctl \
        oriole_je_mallctlbymib \
        oriole_je_mallctlnametomib \
        oriole_je_malloc \
        oriole_je_malloc_conf \
        oriole_je_malloc_conf_2_conf_harder \
        oriole_je_malloc_message \
        oriole_je_malloc_stats_print \
        oriole_je_malloc_usable_size \
        oriole_je_mallocx \
        oriole_je_smallocx_e13ca993e8ccb9ba9847cc330696e02839f328f7 \
        oriole_je_nallocx \
        oriole_je_posix_memalign \
        oriole_je_rallocx \
        oriole_je_realloc \
        oriole_je_sallocx \
        oriole_je_sdallocx \
        oriole_je_xallocx \
        oriole_je_memalign \
        oriole_je_valloc \
        pthread_create \
        ", exported_symbol_names)
  # Store exported symbol names as keys in exported_symbols.
  for (i in exported_symbol_names) {
    exported_symbols[exported_symbol_names[i]] = 1
  }
}

# Process 'nm -a <c_source.o>' output.
#
# Handle lines like:
#   0000000000000008 D opt_junk
#   0000000000007574 T malloc_initialized
(NF == 3 && $2 ~ /^[ABCDGRSTVW]$/ && !($3 in exported_symbols) && $3 ~ /^[A-Za-z0-9_]+$/) {
  print substr($3, 1+length(sym_prefix), length($3)-length(sym_prefix))
}

# Process 'dumpbin /SYMBOLS <c_source.obj>' output.
#
# Handle lines like:
#   353 00008098 SECT4  notype       External     | opt_junk
#   3F1 00000000 SECT7  notype ()    External     | malloc_initialized
($3 ~ /^SECT[0-9]+/ && $(NF-2) == "External" && !($NF in exported_symbols)) {
  print $NF
}
