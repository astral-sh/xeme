/*
 * Name mangling for public symbols is controlled by --with-mangling and
 * --with-jemalloc-prefix.  With default settings the je_ prefix is stripped by
 * these macro definitions.
 */
#ifndef JEMALLOC_NO_RENAME
#  define je_aligned_alloc oriole_je_aligned_alloc
#  define je_calloc oriole_je_calloc
#  define je_dallocx oriole_je_dallocx
#  define je_free oriole_je_free
#  define je_mallctl oriole_je_mallctl
#  define je_mallctlbymib oriole_je_mallctlbymib
#  define je_mallctlnametomib oriole_je_mallctlnametomib
#  define je_malloc oriole_je_malloc
#  define je_malloc_conf oriole_je_malloc_conf
#  define je_malloc_conf_2_conf_harder oriole_je_malloc_conf_2_conf_harder
#  define je_malloc_message oriole_je_malloc_message
#  define je_malloc_stats_print oriole_je_malloc_stats_print
#  define je_malloc_usable_size oriole_je_malloc_usable_size
#  define je_mallocx oriole_je_mallocx
#  define je_smallocx_e13ca993e8ccb9ba9847cc330696e02839f328f7 oriole_je_smallocx_e13ca993e8ccb9ba9847cc330696e02839f328f7
#  define je_nallocx oriole_je_nallocx
#  define je_posix_memalign oriole_je_posix_memalign
#  define je_rallocx oriole_je_rallocx
#  define je_realloc oriole_je_realloc
#  define je_sallocx oriole_je_sallocx
#  define je_sdallocx oriole_je_sdallocx
#  define je_xallocx oriole_je_xallocx
#  define je_memalign oriole_je_memalign
#  define je_valloc oriole_je_valloc
#endif
