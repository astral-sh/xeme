src/sc.o: /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/src/sc.c \
 include/jemalloc/internal/jemalloc_preamble.h \
 include/jemalloc/internal/jemalloc_internal_defs.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/jemalloc_internal_decls.h \
 include/jemalloc/internal/../jemalloc.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/jemalloc_internal_macros.h \
 include/jemalloc/internal/private_namespace.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/test_hooks.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/assert.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/malloc_io.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/jemalloc_internal_types.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/quantum.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/util.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/bit_util.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/bitmap.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/sc.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/pages.h
