src/test_hooks.pic.o: \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/src/test_hooks.c \
 include/jemalloc/internal/jemalloc_preamble.h \
 include/jemalloc/internal/jemalloc_internal_defs.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/jemalloc_internal_decls.h \
 include/jemalloc/internal/../jemalloc.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/jemalloc_internal_macros.h \
 include/jemalloc/internal/private_namespace.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/test_hooks.h
