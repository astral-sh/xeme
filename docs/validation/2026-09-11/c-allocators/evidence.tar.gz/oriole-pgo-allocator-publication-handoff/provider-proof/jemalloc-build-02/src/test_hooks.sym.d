src/test_hooks.sym.o: \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/src/test_hooks.c \
 include/jemalloc/internal/jemalloc_preamble.h \
 include/jemalloc/internal/jemalloc_internal_defs.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/jemalloc_internal_decls.h \
 include/jemalloc/internal/../jemalloc.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/jemalloc_internal_macros.h \
 /tmp/oriole-explicit-mm-provider-proof/jemalloc-source/include/jemalloc/internal/test_hooks.h
