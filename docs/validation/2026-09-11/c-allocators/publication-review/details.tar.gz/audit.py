"""Saved publication-text checks only; never import producer code or execute targets."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urlparse

ROOT = Path('/home/dev-user/code/oss/oriole-c-allocator-study')
OUT = Path(__file__).parent
REPORT = ROOT / 'docs/validation/2026-09-11/c-allocators'
RESULTS = Path('/tmp/oriole-pgo-allocator-results-independent-review')
FILES = ['README.md', 'benchmarks/README.md', 'docs/review.md',
         'benchmarks/results/2026-09-11/c-allocators/README.md',
         'docs/validation/2026-09-11/c-allocators/README.md']
seen = {}
def read(p):
    p = Path(p)
    b = p.read_bytes()
    seen[str(p)] = hashlib.sha256(b).hexdigest()
    return b
def js(p):
    return json.loads(read(p))
def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])
def dump(p, x):
    p.write_text(json.dumps(x, indent=2) + '\n')

texts = {f: read(ROOT/f).decode() for f in FILES}
head = git('rev-parse', 'HEAD').decode().strip()
old = git('show', 'HEAD:README.md').decode()
new = texts['README.md']
assert re.findall(r'^#+ .*$', old, re.M) == re.findall(r'^#+ .*$', new, re.M)
assert re.findall(r'^>.*$', old, re.M) == re.findall(r'^>.*$', new, re.M)
assert old.split('## License\n', 1)[1] == new.split('## License\n', 1)[1]
assert set(git('diff', '--name-only').decode().splitlines()) == set(FILES[:3])
source = js('/tmp/oriole-native-byte-count-pgo-study/source.json')['source_sha256']
assert len(source) == 70
for name, h in source.items():
    assert hashlib.sha256(read(ROOT/name)).hexdigest() == h, name
    assert hashlib.sha256(git('show', f'HEAD:{name}')).hexdigest() == h, name
for p in ['LICENSE-APACHE', 'LICENSE-MIT']:
    assert read(ROOT/p) == git('show', 'HEAD:'+p)
assert git('diff', '--', '.github', 'tools', 'Cargo.toml', 'Cargo.lock') == b''
links = []
for f, t in texts.items():
    for match in re.finditer(r'\[[^\]]*\]\(([^)]+)\)', t):
        s = match.group(1).strip('<>')
        if urlparse(s).scheme or s.startswith('#'):
            continue
        target = ((ROOT/f).parent / unquote(s.split('#')[0])).resolve()
        assert target.exists(), (f,s)
        links.append({'file':f, 'link':s, 'target':str(target)})

r = js(RESULTS/'review.json')
condition = json.loads(gzip.decompress(read(RESULTS/'all-conditions.json.gz')))
summary = js(REPORT/'summary.json')
for group in ['real', 'generated']:
    for engine in ['oriole', 'expat']:
        for mode in ['libc', 'jemalloc', 'mimalloc']:
            key = f'{engine}_{mode}_over_{engine}_ordinary'
            assert summary['elapsed_brief'][group]['engines'][engine][mode] == r['results']['elapsed'][group][key]
    for mode in ['ordinary', 'libc', 'jemalloc', 'mimalloc']:
        key = f'oriole_{mode}_over_expat_{mode}'
        assert summary['elapsed_brief'][group]['matched_oriole_over_expat'][mode] == r['results']['elapsed'][group][key]
    assert summary['rss_groups'][group]['ratios'] == r['results']['rss'][group]
bench = texts[FILES[3]]
labels = ['Ordinary constructor', 'Explicit libc', 'Explicit jemalloc', 'Explicit mimalloc']
for label, mode in zip(labels, ['ordinary', 'libc', 'jemalloc', 'mimalloc']):
    values = []
    for engine in ['oriole', 'expat']:
        for phase in ['elapsed', 'rss']:
            values.append(1.0 if mode == 'ordinary' else r['results'][phase]['real'][f'{engine}_{mode}_over_{engine}_ordinary']['geomean'])
    assert '| '+label+' | '+' | '.join(f'{x:.6f}×' for x in values)+' |' in bench
examples = {}
for name, label in [('vulkan','Vulkan'), ('wayland','Wayland'), ('maven','Maven'), ('batik','Batik'), ('gtk','GTK'), ('docbook','DocBook')]:
    rows = [x for x in condition['rss'] if x['condition']['name'] == name and x['condition']['chunk'] == 4096 and not x['condition']['namespaces']]
    assert len(rows) == 1
    values = [rows[0]['absolute_workload_peak_rss_kib']['oriole_'+m]['median'] for m in ['ordinary','libc','jemalloc','mimalloc']]
    assert '| '+label+' | '+' | '.join(map(str,values))+' |' in bench
    examples[name] = values
for mode in ['ordinary','libc','jemalloc','mimalloc']:
    x = r['results']['elapsed']['real'][f'oriole_{mode}_over_expat_{mode}']
    assert f"{x['geomean']:.3f}×" in bench and x['lower_conditions'] == 3
for mode in ['jemalloc','mimalloc']:
    real = r['results']['elapsed']['real'][f'oriole_{mode}_over_oriole_ordinary']
    gen = r['results']['elapsed']['generated'][f'oriole_{mode}_over_oriole_ordinary']
    assert abs(real['geomean']-1) < .002
    assert f"{100*(1-gen['geomean']):.1f}%" in bench
    assert r['results']['rss']['real'][f'oriole_{mode}_over_oriole_ordinary']['higher_conditions'] == 24
    assert r['results']['rss']['generated'][f'oriole_{mode}_over_oriole_ordinary']['higher_conditions'] == 4
validation = texts[FILES[4]]
for count in [224,1568,196,281120,672,84,120480]:
    assert format(count, ',') in validation
assert summary['counts']['timed_parses'] == 281120+1568
assert summary['counts']['rss_parses'] == 120480+672
assert summary['counts']['preflight_parses'] == 224*2
assert '/etc/oriole_je_malloc.conf' in validation and "absence was not recorded during the experiment" in validation
assert 'not transferred to all custom allocation modes' in validation
assert 'never included in elapsed summaries' in validation
package = js('/tmp/oriole-pgo-allocator-package-independent-review/review.json')
provider = js('/tmp/oriole-pgo-allocator-source-independent-review/review.json')
receipt = js(REPORT/'receipt.json')
assert receipt['included_files'] == package['included_files'] == 8502
assert receipt['excluded_binary_files'] == package['excluded_compiled_files'] == 202
assert hashlib.sha256(read(REPORT/'evidence.tar.gz')).hexdigest() == package['archive_sha256'] == receipt['archive_sha256']
assert provider['PGO_replay']['processes'] == 8 and provider['PGO_replay']['load_assertions'] == 144
assert not provider['findings'] and not r['blockers']
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p,h in seen.items())
read(__file__)
dump(OUT/'review.json', {
    'status':'passed', 'reviewer_role':'Independent agent publication-text reviewer',
    'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope':'Five Markdown documents, compact summary and archive receipt; source70/HEAD, README structure/warning/license, unchanged tooling/CI and relative file links. No target runs or repeated raw-worker reconstruction.',
    'head':head, 'assessed_markdown_sha256':{f:seen[str(ROOT/f)] for f in FILES},
    'numbers':'All 16 table values, six four-column absolute KiB examples, four matched-parser ratios, generated percentages, adverse counts and measured/warmup totals agree with independent raw reconstruction.',
    'rss_examples_kib':examples, 'source_files':70, 'relative_links_checked':len(links),
    'claims':'No useful real-project Oriole allocator gain, higher measured process VmHWM, unchanged defaults; native custom-suite scope distinct from preceding ordinary C/API and strict CPython checks. All historical fuzz/PBS and compatibility claims unchanged.',
    'configuration_limit':'Prefixed jemalloc /etc/oriole_je_malloc.conf historical absence was not recorded; text accurately narrows claims to recorded flags/proof options/environment cleanup and no deliberate tuning.',
    'reused_reviews':{str(p):seen[str(p)] for p in [RESULTS/'review.json',Path('/tmp/oriole-pgo-allocator-source-independent-review/review.json'),Path('/tmp/oriole-pgo-allocator-package-independent-review/review.json')]},
    'limitations':['Final independent-review attachments and publication index are pending and outside this snapshot.','Provider proof origins are not per-timed-worker dladdr. RSS is whole-process high-water accounting; shared-host near-one timing ratios establish no significance.'],
    'findings':[], 'all_inspected_bytes_unchanged':True})
(OUT/'checked-files.json.gz').write_bytes(gzip.compress(json.dumps(seen,sort_keys=True).encode(),mtime=0))
(OUT/'links.json.gz').write_bytes(gzip.compress(json.dumps(links,sort_keys=True).encode(),mtime=0))
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'files':len(seen),'links':len(links)}))
