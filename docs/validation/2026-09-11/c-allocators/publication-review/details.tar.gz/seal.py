"""Seal reviewer-owned files only; no producer changes or target execution."""
import hashlib
import json
from pathlib import Path
import shutil

for stem, title, detail in [
    ('results', 'Independent allocator results review',
     'Saved data only: all 224 preflights, 1,568 elapsed workers and 672 RSS workers; seeded orders, raw sample identities, medians, paired ratios, absolute RSS values and summaries reconstructed. Full maps and condition/group details are compressed. No target execution.'),
    ('prose', 'Independent allocator publication-text review',
     'Independent agent review of publication numbers, scope, relative links and unchanged source/README constraints. Uses the separately sealed raw-results, provider/source and package reviews. Final attachments/index remain a later bounded readback.')]:
    out = Path('/tmp/oriole-pgo-allocator-'+stem+'-independent-review')
    def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
    assert not (out/'files.json').exists()
    shutil.copyfile(__file__, out/'seal.py')
    (out/'README.md').write_text(f'# {title}\n\n**Passed.** {detail}\n\n[Review](review.json), [generator](audit.py), and [file index](files.json). Recorded limitations remain explicit in the review.\n')
    receipt = {'status':'sealed', 'review_sha256':h(out/'review.json'),
               'scope':detail, 'files_before_receipt':{p.name:h(p) for p in sorted(out.iterdir()) if p.is_file()}}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    index = {p.name:{'sha256':h(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()}
    (out/'files.json').write_text(json.dumps(index,indent=2)+'\n')
    assert all(h(out/p)==v['sha256'] and (out/p).stat().st_size==v['bytes'] for p,v in index.items())
    print(json.dumps({'directory':str(out),'review':h(out/'review.json'),'receipt':h(out/'receipt.json'),'index':h(out/'files.json'),'indexed_files':len(index)}))
