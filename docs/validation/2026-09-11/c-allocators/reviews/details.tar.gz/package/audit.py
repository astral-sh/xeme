"""Independent saved-only PR118 package origin and byte audit (CPU4)."""
from pathlib import Path
import difflib
import gzip
import hashlib
import io
import json
import os
import tarfile

assert os.sched_getaffinity(0) == {4}
O = Path('/tmp/oriole-pgo-allocator-package-independent-review')
O.mkdir(exist_ok=False)
P = Path('/tmp/oriole-pgo-allocator-publication-handoff')
A = P.with_suffix('.tar.gz')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
dump = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
inputs = {}
checks = 0
def record(p):
    p = Path(p)
    value = sha(p)
    if str(p) in inputs:
        assert inputs[str(p)] == value, p
    inputs[str(p)] = value
    return value
def check(cond, why):
    global checks
    assert cond, why
    checks += 1

report = {'status': 'incomplete', 'role': 'Independent saved-data/package reviewer; no parser/compiler/profiler/timing/test execution.', 'scope': 'Origin, hash, exclusion, index and nested source readback only; provider API contract and elapsed/RSS arithmetic are separate reviews.'}
try:
    check(record(A) == '0428afb9b64b99c077b84387e84232caf0f0c4af6bfafbb1accad3eff162278e', 'archive pin')
    M = load(P / 'MANIFEST.json')
    record(P / 'MANIFEST.json')
    check(M['status'] == 'sealed' and M['included_files'] == 8502 and M['excluded_binary_files'] == 202, 'sealed counts')
    exclusions = {r['relative_path']: r for r in M['excluded_binaries']}
    check(len(exclusions) == 202, 'unique exclusions')
    included = M['included']
    direct_origins = {}
    for prefix, source in M['sources'].items():
        B = Path(source['path'])
        check(record(B / 'MANIFEST.json') == source['manifest_sha256'], ('source manifest', prefix))
        original_manifest = load(B / 'MANIFEST.json')
        original_map = original_manifest.get('files_sha256', original_manifest)
        check(len(original_map) == source['source_files_indexed'], ('original count', prefix))
        for name, digest in original_map.items():
            check(record(B / name) == digest, ('original indexed hash', prefix, name))
        expected_partition = set()
        for p in sorted(B.rglob('*')):
            if not p.is_file():
                continue
            check(not p.is_symlink(), ('regular source', p))
            name = prefix + '/' + p.relative_to(B).as_posix()
            expected_partition.add(name)
            digest = record(p)
            with p.open('rb') as f:
                magic = f.read(8)
            is_binary = magic.startswith(b'\x7fELF') or magic == b'!<arch>\n' or p.suffix in ['.o', '.a', '.so', '.pyc'] or '__pycache__' in p.parts
            if is_binary:
                check(name in exclusions and name not in included, ('binary partition', name))
                row = exclusions[name]
                check(row['path'] == str(p) and row['sha256'] == digest and row['bytes'] == p.stat().st_size, ('excluded origin/hash/size', name))
            else:
                check(name in included and name not in exclusions, ('included partition', name))
                check(included[name] == digest == record(P / name), ('direct origin bytes', name))
                direct_origins[name] = str(p)
        actual_partition = {n for n in included if n.startswith(prefix + '/')} | {n for n in exclusions if n.startswith(prefix + '/')}
        check(actual_partition == expected_partition, ('all original files included or excluded', prefix))
    failed = Path('/tmp/oriole-pgo-allocator-publication-attempt-01')
    for p in sorted(failed.rglob('*')):
        if p.is_file():
            name = 'packaging-attempt-01/' + p.relative_to(failed).as_posix()
            check(record(p) == included[name] == record(P / name), ('failed packaging origin', name))
            direct_origins[name] = str(p)
    failure = load(P / 'packaging-attempt-01/failure.json')
    check(failure['status'] == 'failed-before-copy' and failure['exception'] == "KeyError: 'files_sha256'", 'retained schema-only failure')
    first = (P / 'packaging-attempt-01/package.py').read_text()
    final = (P / 'package.py').read_text()
    check("manifest=json.loads((base/'MANIFEST.json').read_text());expected=manifest['files_sha256']" in first, 'initial schema assumption')
    check("manifest.get('files_sha256',manifest)" in final, 'corrected flat/nested manifest handling')
    check(first.index("expected=manifest['files_sha256']") < first.index('shutil.copyfile(p,target)'), 'failure precedes source copy')
    (O / 'packaging-correction.patch').write_text(''.join(difflib.unified_diff(first.splitlines(True), final.splitlines(True), fromfile='retained-initial-package.py', tofile='final-package.py')))
    generated = set(included) - set(direct_origins)
    check(generated == {'README.md', 'EXCLUDED_BINARIES.json', 'package.py'}, ('package-generated files', generated))
    check(load(P / 'EXCLUDED_BINARIES.json')['files'] == M['excluded_binaries'], 'exclusion sidecar exact')
    expected_archive = included | {'MANIFEST.json': record(P / 'MANIFEST.json')}
    actual = {}
    nested = {}
    with tarfile.open(A, 'r:gz') as tf:
        for member in tf.getmembers():
            check(member.name == P.name or member.name.startswith(P.name + '/'), ('archive root', member.name))
            check('..' not in Path(member.name).parts and not member.name.startswith('/'), ('safe path', member.name))
            if member.isdir():
                continue
            check(member.isfile(), ('regular archived file', member.name))
            name = Path(member.name).relative_to(P.name).as_posix()
            check(name not in actual, ('unique member', name))
            data = tf.extractfile(member).read()
            digest = hashlib.sha256(data).hexdigest()
            actual[name] = digest
            check(expected_archive.get(name) == digest == record(P / name), ('archive/local/index byte identity', name))
            check(not data.startswith(b'\x7fELF') and not data.startswith(b'!<arch>\n'), ('no direct executable', name))
            if name.endswith('.tar.gz'):
                rows = {}
                with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as inner:
                    for item in inner.getmembers():
                        check(not item.name.startswith('/') and '..' not in Path(item.name).parts, ('nested safe', name, item.name))
                        if item.isdir():
                            continue
                        check(item.isfile() and item.name not in rows, ('nested regular/unique', name, item.name))
                        raw = inner.extractfile(item).read()
                        h = hashlib.sha256(raw).hexdigest()
                        if name.startswith('provider-proof/'):
                            origin = Path(M['sources']['provider-proof']['path']) / item.name
                            check(record(origin) == h, ('nested provider source origin', name, item.name))
                        else:
                            source = load(P / 'pgo-allocator-study/evidence/oriole/source.json')
                            check(source['source_sha256'][item.name] == h, ('nested Oriole source manifest', item.name))
                            check(record(Path(source['worktree']) / item.name) == h, ('nested Oriole live source', item.name))
                        rows[item.name] = h
                nested[name] = rows
    check(actual == expected_archive, 'complete exact archive index')
    local = {p.relative_to(P).as_posix() for p in P.rglob('*') if p.is_file()}
    check(local == set(expected_archive), 'complete local package index')
    check(len(nested) == 3 and len(nested['pgo-allocator-study/evidence/oriole/source.tar.gz']) == 70, 'nested source archives')
    receipt = load(P.with_suffix('.json'))
    record(P.with_suffix('.json'))
    check(receipt['archive_sha256'] == inputs[str(A)] and receipt['manifest_sha256'] == inputs[str(P / 'MANIFEST.json')], 'producer receipt pins')
    check(receipt['included_files'] == len(included) and receipt['excluded_binary_files'] == len(exclusions), 'producer receipt counts')
    for path, digest in inputs.items():
        check(sha(path) == digest, ('unchanged reread', path))
    details = {'input_sha256': inputs, 'archived_member_sha256': actual, 'direct_origins': direct_origins, 'nested_member_sha256': nested, 'excluded_binaries': exclusions}
    with gzip.open(O / 'details.json.gz', 'wt', encoding='utf8', compresslevel=9) as f:
        json.dump(details, f, sort_keys=True)
    report.update(status='passed', archive_sha256=inputs[str(A)], manifest_sha256=inputs[str(P / 'MANIFEST.json')], included_files=8502, archive_regular_files=len(actual), excluded_compiled_files=202, nested_source_files={k: len(v) for k, v in nested.items()}, all_direct_and_nested_origins_verified=True, initial_packaging_failure='Flat provider manifest read as files_sha256 caused KeyError before source copy; retained initial script and explicit failure record, final accepts both schemas. No target execution in either packager.', generated_package_files=sorted(generated), checks=checks, checked_files=len(inputs), all_inspected_bytes_unchanged=True, details_sha256=sha(O / 'details.json.gz'), generator_sha256=sha(__file__), limitations=['Hash/origin/package review only; no independent elapsed/RSS arithmetic or provider API contract claim.', 'Original source manifests intentionally reference the 202 excluded compiled artifacts; exact exclusions are preserved.', 'Failure-before-copy classification is corroborated by retained code order and saved failure receipt, not a rerun.'])
except BaseException as error:
    report.update(status='failed', exception=repr(error), checks=checks, checked_files=len(inputs))
    raise
finally:
    dump(O / 'review.json', report)
print(json.dumps({'status': report['status'], 'review': str(O / 'review.json'), 'sha256': sha(O / 'review.json')}), flush=True)
