"""Independently reconstruct saved allocator time and VmHWM records."""
from pathlib import Path
from collections import Counter
import gzip,hashlib,json,math,os,random,statistics
if not __debug__:raise RuntimeError('assertions required')
assert os.sched_getaffinity(0)=={6}
B=Path('/tmp/oriole-pgo-allocator-native-study');O=Path(__file__).parent
tracked={};rawhashes={}
def read(p):
 p=Path(p);b=p.read_bytes();h=hashlib.sha256(b).hexdigest();assert tracked.setdefault(str(p),h)==h;return b
def sha(p):read(p);return tracked[str(Path(p))]
def load(p):return json.loads(read(p))
N=B/'native-screen';R=B/'rss-screen';np=load(N/'protocol.json');rp=load(R/'protocol.json')
pre=load(N/'preflight.json');elapsed=load(N/'results.json');rss=load(R/'results.json');summary=load(B/'summary.json')
assert np==load(B/'prepared-protocol.json') and rp==load(B/'rss-prepared-protocol.json')
assert np['seed']==rp['seed']==2026091003 and np['pairs']==7 and rp['repetitions']==3
engines=['oriole','expat'];modes=['ordinary','libc','jemalloc','mimalloc']
combos=[e+'_'+a for e in engines for a in modes]
pairs=[(e+'_'+a,e+'_'+b) for e in engines for a,b in [('libc','ordinary'),('jemalloc','ordinary'),('mimalloc','ordinary'),('jemalloc','libc'),('mimalloc','libc'),('mimalloc','jemalloc')]]+ [('oriole_'+a,'expat_'+a) for a in modes]
assert np['combinations']==rp['combinations']==combos and np['ratios']==rp['ratios']==[list(p) for p in pairs]
conditions=np['conditions'];assert conditions==rp['conditions']==load(B/'evidence/original/prepared-protocol.json')['conditions'] and len(conditions)==28
assert np['libraries']==rp['libraries']==summary['components']
assert np['libraries']['oriole']['sha256']=='4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02'
assert np['libraries']['expat']['sha256']=='12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'
for d in np['libraries'].values():assert sha(d['path'])==d['sha256']
assert np['worker_timeout_seconds']==rp['worker_timeout_seconds']==90
assert np['preflight_timeout_seconds']==600 and np['timed_aggregate_timeout_seconds']==rp['aggregate_timeout_seconds']==1200
assert (np['preflights'],np['timed_workers'],np['cohorts'],rp['workers'],rp['cohorts'])==(224,1568,196,672,84)
assert rp['native_protocol_sha256']==sha(B/'prepared-protocol.json') and rp['added_environment']=={'ORIOLE_NATIVE_RSS':'1'} and rp['requires_elapsed_complete']
for record,protocol,cpu,budget in [(pre,np,2,600),(elapsed,np,0,1200),(rss,rp,2,1200)]:
 assert record['status']=='passed' and 'exception' not in record and record['affinity']==[cpu]
 assert record['aggregate_timeout_seconds']==budget and 0<record['aggregate_elapsed_seconds']<budget
 assert record['hashes_before']==record['hashes_after']==protocol['hashes']
 for p,h in protocol['hashes'].items():assert sha(p)==h
assert pre['protocol_sha256']==elapsed['protocol_sha256']==sha(N/'protocol.json')
assert elapsed['preflight_sha256']==sha(N/'preflight.json')
assert rss['native_elapsed_report_sha256']==sha(N/'results.json') and rss['protocol_sha256']==sha(R/'protocol.json')
assert pre['rss_environment_absent'] and elapsed['rss_environment_absent'] and rss['added_environment']==rp['added_environment']
assert all(c['chunk'] in [4096,65536] for c in conditions)
manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
real={}
for p in load(manifest)['projects']:
 f=next(x for x in p['files'] if x['role']=='input');path=(manifest.parent/f['path']).resolve();assert sha(path)==f['sha256'];real[p['name']]=str(path)
for c in conditions:
 assert sha(c['input'])==np['hashes'][c['input']]
 if not c['name'].startswith('generated-'):assert real[c['name']]==c['input']
counts=Counter();stderr_counts=Counter();observations={};measures={}
key=lambda c:json.dumps(c,sort_keys=True)
def worker(directory,ordinal,row,c,pair,combo,cpu,iterations,phase):
 stem=directory/f'worker-{ordinal:04d}'
 assert load(str(stem)+'.json')==row
 for suffix in ['.json','.stdout','.stderr']:rawhashes[str(stem)+suffix]=sha(str(stem)+suffix)
 engine,allocator=combo.split('_',1)
 assert row['status']=='passed' and row['returncode']==0 and 'exception' not in row
 assert row['condition']==c and row['pair']==pair and row['combination']==combo and row['engine']==engine and row['allocator']==allocator
 assert row['worker_timeout_seconds']==90
 assert row['command']==['taskset','-c',str(cpu),np['driver'],np['libraries'][engine]['path'],c['input'],str(c['chunk']),str(iterations),allocator]+(['namespaces'] if c['namespaces'] else [])
 for stream in ['stdout','stderr']:
  assert sha(str(stem)+'.'+stream)==row[stream+'_sha256'] and read(str(stem)+'.'+stream).decode()==row[stream]
 payload=json.loads(row['stdout']);assert payload['version']==('oriole_compat_2.8.4' if engine=='oriole' else 'expat_2.8.4')
 assert set(payload)==({'version','samples','workload_peak_rss_kib'} if phase=='rss' else {'version','samples'})
 samples=payload['samples'];assert len(samples)==iterations+1
 obs=[]
 for i,s in enumerate(samples):
  assert set(s)=={'iteration','warmup','seconds','hash','elements','text_bytes'}
  assert s['iteration']==i and s['warmup']==(i==0) and math.isfinite(s['seconds']) and s['seconds']>0
  assert type(s['elements']) is int and type(s['text_bytes']) is int and min(s['elements'],s['text_bytes'])>=0
  obs.append([s['hash'],s['elements'],s['text_bytes']]);counts[phase+('_warmups' if i==0 else '_parses')]+=1
 assert all(o==obs[0] for o in obs) and row['observations']==[obs[0]]
 if phase=='preflight':assert observations.setdefault(key(c),[obs[0]])==[obs[0]]
 else:assert observations[key(c)]==[obs[0]]
 if phase=='rss':
  value=payload['workload_peak_rss_kib'];assert type(value) is int and value>0 and row['workload_peak_rss_kib']==value
  assert 'median_seconds' not in row
 else:
  value=statistics.median(s['seconds'] for s in samples[1:]);assert row['median_seconds']==value
 counts[phase+'_workers']+=1;stderr_counts[phase]+=bool(row['stderr']);return value
assert len(pre['rows'])==224
for i,(c,combo) in enumerate((c,combo) for c in conditions for combo in combos):worker(N,i,pre['rows'][i],c,-1,combo,2,1,'preflight')
assert len(observations)==28
reconstructions={};groups_by_phase={}
for phase,record,protocol,dirname,reps,cpu,offset in [('elapsed',elapsed,np,N,7,0,224),('rss',rss,rp,R,3,2,0)]:
 rng=random.Random(2026091003);jobs=[(i,pair) for i in range(28) for pair in range(reps)];rng.shuffle(jobs);schedule=[];ordinal=offset
 assert len(record['rows'])==28*reps
 for row,(i,pair) in zip(record['rows'],jobs,strict=True):
  order=combos.copy();rng.shuffle(order);c=conditions[i]
  schedule.append({'condition_index':i,'pair':pair,'order':order})
  assert row['condition']==c and row['pair']==pair and row['order']==order and len(row['processes'])==8
  for process,combo in zip(row['processes'],order,strict=True):
   ident=(phase,key(c),pair,combo);assert ident not in measures
   measures[ident]=worker(dirname,ordinal,process,c,pair,combo,cpu,c['iterations'],phase);ordinal+=1
 assert schedule==load(B/('prepared-schedule.json' if phase=='elapsed' else 'rss-prepared-schedule.json'))
 summaries=[]
 for c in conditions:
  cohorts=[r for r in record['rows'] if r['condition']==c]
  vals=[{combo:measures[phase,key(c),cohort['pair'],combo] for combo in combos} for cohort in cohorts]
  ratios={a+'_over_'+b:[v[a]/v[b] for v in vals] for a,b in pairs}
  if phase=='elapsed':s={'condition':c,'paired_ratios':ratios,'median_ratios':{n:statistics.median(v) for n,v in ratios.items()}}
  else:
   absolute={combo:{'samples':[v[combo] for v in vals],'median':statistics.median(v[combo] for v in vals),'min':min(v[combo] for v in vals),'max':max(v[combo] for v in vals)} for combo in combos}
   comparisons={a+'_over_'+b:{'paired_ratios':ratios[a+'_over_'+b],'paired_difference_kib':[v[a]-v[b] for v in vals],'median_ratio':statistics.median(ratios[a+'_over_'+b]),'median_difference_kib':statistics.median(v[a]-v[b] for v in vals)} for a,b in pairs}
   s={'condition':c,'absolute_workload_peak_rss_kib':absolute,'comparisons':comparisons}
  summaries.append(s)
 assert summaries==record['summary'];reconstructions[phase]=summaries
 names=['real','generated','all']+list(dict.fromkeys(c['name'] for c in conditions));groups={}
 assert set(record['groups'])==set(names)
 for group in names:
  rows=[r for r in summaries if group=='all' or group=='real' and not r['condition']['name'].startswith('generated-') or group=='generated' and r['condition']['name'].startswith('generated-') or r['condition']['name']==group]
  q={'conditions':len(rows),'ratios':{}} if phase=='elapsed' else {'conditions':[r['condition'] for r in rows],'scope':'Condition-ratio summary, not group peak RSS.','ratios':{}}
  for a,b in pairs:
   name=a+'_over_'+b;v=[r['median_ratios'][name] if phase=='elapsed' else r['comparisons'][name]['median_ratio'] for r in rows]
   q['ratios'][name]={'geomean':math.exp(statistics.mean(map(math.log,v))),'lower_conditions':sum(x<1 for x in v),'higher_conditions':sum(x>1 for x in v),'all_ratios':v}
  groups[group]=q
 assert groups==record['groups']==summary[phase+'_groups'];groups_by_phase[phase]=groups
for dirname,n in [(N,1792),(R,672)]:
 assert {str(p) for p in dirname.glob('worker-*')}=={str(dirname/f'worker-{i:04d}')+s for i in range(n) for s in ['.json','.stdout','.stderr']}
assert len(rawhashes)==7392 and counts=={'preflight_workers':224,'preflight_warmups':224,'preflight_parses':224,'elapsed_workers':1568,'elapsed_warmups':1568,'elapsed_parses':281120,'rss_workers':672,'rss_warmups':672,'rss_parses':120480}
assert not any(stderr_counts.values())
# Verify every compact engine and matched-parser number from independent groups.
for group in ['real','generated']:
 brief=summary['elapsed_brief'][group];g=groups_by_phase['elapsed'][group]
 assert brief['conditions']==g['conditions']
 for engine in engines:
  for mode in modes:
   actual={'geomean':1.0,'lower_conditions':0,'higher_conditions':0} if mode=='ordinary' else {k:v for k,v in g['ratios'][engine+'_'+mode+'_over_'+engine+'_ordinary'].items() if k!='all_ratios'}
   assert brief['engines'][engine][mode]==actual
 for mode in modes:assert brief['matched_oriole_over_expat'][mode]=={k:v for k,v in g['ratios']['oriole_'+mode+'_over_expat_'+mode].items() if k!='all_ratios'}
assert summary['elapsed_report_sha256']==sha(N/'results.json') and summary['rss_report_sha256']==sha(R/'results.json')
for name in ['native_screen.py','rss_screen.py','controller.patch','rss-controller.patch','approval.json','rss-approval.json','preparation.json','rss-preparation.json','RESULTS.md','RSS-PLAN.md','cpu0-release.json']:read(B/name)
for name,protocol in [('approval.json',B/'prepared-protocol.json'),('rss-approval.json',B/'rss-prepared-protocol.json')]:
 a=load(B/name);assert a['approved_protocol_sha256']==sha(protocol)
 assert a['approved_controller_sha256']==sha(B/('native_screen.py' if name=='approval.json' else 'rss_screen.py'))
for source in ['native_screen.py','rss_screen.py']:
 text=read(B/source).decode()
 for token in ['start_new_session=True','process.wait(timeout=min(90, remaining))','os.killpg(process.pid, signal.SIGKILL)','signal.setitimer(signal.ITIMER_REAL,']:assert token in text
assert summary['defaults_unchanged'] and summary['parser_source_unchanged'] and summary['original_driver_unchanged'] and summary['no_allocator_tuning'] and summary['sequential_elapsed_then_rss']
for p,h in tracked.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
compact={phase:{group:{n:{k:v for k,v in row.items() if k!='all_ratios'} for n,row in groups_by_phase[phase][group]['ratios'].items()} for group in ['real','generated']} for phase in ['elapsed','rss']}
report={'status':'independent_saved_allocator_results_passed','scope':'Complete saved native preflight/time and separate VmHWM raw records, commands, hashes, RNG schedules, sample medians, paired ratios/differences and aggregates. No producer import, parser/compiler/profiler/timing execution.',
 'counts':dict(counts),'raw_files':7392,'elapsed_cohorts':196,'rss_cohorts':84,'elapsed_paired_ratios':3136,'rss_paired_ratios_and_differences':1344,'per_phase_condition_ratio_medians':448,
 'results':compact,'nonempty_stderr_workers':dict(stderr_counts),'libraries':np['libraries'],
 'elapsed_sha256':sha(N/'results.json'),'rss_sha256':sha(R/'results.json'),'producer_summary_sha256':sha(B/'summary.json'),
 'limitations':['Native callback workloads only; no actual CPython allocator performance claim.','RSS is per-process absolute VmHWM after parse/free workload, including both static provider constructors, process/input/output/parser/measurement memory. Ratios of condition medians are not a group peak or isolated allocator resident bytes.','RSS seconds are retained and checked as raw samples but never enter elapsed aggregates. Elapsed has one discarded warmup; RSS runs the same warmup and original iteration workload.','Provider binding and ownership proof are separately reviewed; eight proof processes are not per-worker dladdr origin attestations.','Shared host and cross-CPU activity remain uncontrolled; near-one real Oriole elapsed ratios do not establish a useful gain or statistical significance.','Only named loader/provider environment controls are stripped; the full inherited environment is not recorded. Successful jobs do not independently exercise every process-cleanup branch.'],
 'checked_files':len(tracked),'all_inspected_bytes_unchanged':True,'blockers':[]}
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
for name,data in [('checked-files.json.gz',tracked),('raw-files.json.gz',rawhashes),('all-conditions.json.gz',reconstructions),('all-groups.json.gz',groups_by_phase)]:
 with gzip.open(O/name,'wt') as f:json.dump(data,f,indent=2);f.write('\n')
print(json.dumps({'status':report['status'],'review_sha256':sha(O/'review.json'),'checked_files':len(tracked),'counts':dict(counts)}))
