# Independent allocator driver and provider review

Passed with provenance limitations. The first saved-only audit completed 6,904 checks over 1,352 files on CPU 4. No compiler, parser, profiler, test or timing process was run.

The native driver keeps static allocator suites and valid callback state throughout synchronous parsing and destruction. Its callbacks and timed loop are byte-identical to the ordinary driver except for constructor selection. The saved executable exports exactly six namespaced allocator functions and does not define the process malloc family. The comment correction produced the identical binary.

Source checks cover 70 Oriole files, 467 jemalloc files and 63 mimalloc files, including archive, working copy and provider registry origins. The saved jemalloc build contains 186 compiler vectors for 62 C sources; the mimalloc build uses the unchanged vendored `static.c` recipe. Build failures, the unexecuted parent-before-child draft, strict-C diagnostic failure and broader-export intermediate proof remain recorded.

The eight-process PGO replay uses Oriole `4f1518fc` and Expat `12d33ad2` with the frozen proof executable. It passes 144 source-level parser-entrypoint origin assertions, retains 88 individual origin rows, matches 16 independently reconstructed trace observations, and injects all 108 selected allocation failures. All explicit-suite live blocks and bytes end at zero. Both earlier successful proof phases preserve the same semantic observations. Children are destroyed before parents; returned models are freed while their parser remains alive after reset; failed nonzero realloc retains the original allocation.

## Limits

The historical absence receipt checks `/etc/malloc.conf`, but the prefixed jemalloc build reads `/etc/oriole_je_malloc.conf`. Both are absent at review time; the latter's historical absence is not established. Selected runtime options and the stripped environment are recorded, so the evidence supports those observations rather than a complete historical default-configuration claim.

Zero-size semantics are outside the proof. The failure sweep covers one small fixture and its 20 Oriole / 16 Expat allocation indices per explicit mode. The ledger is a single-process, serial proof tool, and its zero totals concern tracked suite allocations. The ordinary mode bypasses that ledger. Proof origins attest the instrumented executable; timed workers do not retain equivalent `dladdr` records. Proof RSS and workload RSS have separate meanings. The native driver retains the ordinary Linux narrow-character ABI assumptions.

## Related sealed reviews

- Package/origin readback: `/tmp/oriole-pgo-allocator-package-independent-review/review.json`, SHA `7b623f904020e5c7b524825407ae44ff8dfca26e5ab2b0886be101aa9783205b`.
- Native elapsed/RSS arithmetic: `/tmp/oriole-pgo-allocator-results-independent-review/review.json`, SHA `a8be32770ca80ba832a24689f2513ac25af41c8c6cefe6b2351c9c554784fb94`.

`generator.py` independently reads saved data. `details.json.gz` retains full checked-file hashes, source maps, actual jemalloc compiler vectors, proof semantics and source corrections. `receipt.json` binds this review to its successful attempt and the related reviews; `files.json` indexes all review artifacts except itself.
