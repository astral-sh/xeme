"""Independent saved provider source/build/proof audit; executes no producer code."""
from pathlib import Path
import ast
import collections
import difflib
import gzip
import hashlib
import io
import json
import os
import re
import shlex
import tarfile

assert os.sched_getaffinity(0) == {4}
O = Path(__file__).parent
P = Path('/tmp/oriole-explicit-mm-provider-proof')
N = Path('/tmp/oriole-pgo-allocator-native-study')
W = Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')
checked, details, count = {}, {}, 0
def ck(v, label):
    global count
    assert v, label
    count += 1
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p):
    p = Path(p); b = p.read_bytes(); h = sha(b)
    ck(str(p) not in checked or checked[str(p)] == h, ('stable read',str(p)))
    checked[str(p)] = h
    return b
def text(p): return read(p).decode()
def j(p): return json.loads(read(p))
def pin(p,h): ck(sha(read(p)) == h, ('hash',str(p)))
def dump(p,d): p.write_text(json.dumps(d,indent=2)+'\n')
def symbols(p, dynamic=False):
    rows = [r.split() for r in text(p).splitlines()]
    return {r[-1] for r in rows if len(r)>=3 and (not dynamic or r[-2] in ['T','W'])}
def diff(a,b): return ''.join(difflib.unified_diff(text(a).splitlines(True),text(b).splitlines(True),fromfile=str(a),tofile=str(b)))

prior = {
 '/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json':'cec78c70730e111f139a6fab70089e1629ffe3336843106585a35922a525bbc9',
 '/tmp/oriole-current-pgo-expat-reuse-independent-review/review.json':'9a53fcddfa80a039da800284a3ebdbe7d83316fe83768ed1f4d7e4770b53b2d9',
 '/tmp/oriole-pgo-allocator-package-independent-review/review.json':'7b623f904020e5c7b524825407ae44ff8dfca26e5ab2b0886be101aa9783205b',
}
for p,h in prior.items(): pin(p,h)
pkg = j('/tmp/oriole-pgo-allocator-package-independent-review/review.json')
ck(pkg['status'] == 'passed' and pkg['included_files']==8502 and pkg['excluded_compiled_files']==202, 'separate package review scope')
pin(N/'proof-replay/report.json','d4cdcef85e9c0eed2216e900b41c48b3f723b45aef27b0fdea4a761e3102552e')
pin(P/'provider-build.json','174178c999237291dc85387b1fdf3516f2a698a48742749cad6e4ed9d32e2f17')
pin(P/'provider_proof.c','94bc1f4ce1fb3979778309b144d0c1f13d0218cb34677a70fa8a88b8421990ed')
pin(N/'native_allocator_driver.c','729dc1a297776fcceb7439b3a416f8d0105d1a4c78560f1c4d8fb86b3a9d0583')
build = j(P/'provider-build.json')
ck(build['status']=='passed' and build['affinity']==[2] and build['sources_unchanged'], 'provider completion')
ck(build['environment_overrides']=={'CC':'cc','CXX':'c++','CFLAGS':'-O3 -fPIC','CXXFLAGS':'-O3 -fPIC'}, 'provider flags')
source_maps = {}
for name,rec in build['sources'].items():
    pin(P/f'{name}-source.tar.gz',rec['source_archive_sha256'])
    actual = {}
    with tarfile.open(fileobj=io.BytesIO(read(P/f'{name}-source.tar.gz')),mode='r:gz') as t:
        seen=set()
        for m in t.getmembers():
            ck(not m.name.startswith('/') and '..' not in Path(m.name).parts and m.name not in seen, ('safe unique provider archive',m.name)); seen.add(m.name)
            ck(m.isfile() or m.isdir(), ('source archive regular/dir',m.name))
            if m.isdir(): continue
            n=str(Path(m.name).relative_to(f'{name}-source'))
            actual[n]=sha(t.extractfile(m).read())
    ck(actual==rec['files'] and len(actual)==({'jemalloc':467,'mimalloc':63}[name]), ('complete source map',name))
    for n,h in actual.items():
        pin(P/f'{name}-source'/n,h)
        origin=rec['assembled_extra_files'].get(n,{}).get('source',str(Path(rec['registry_source'])/n))
        pin(origin,h)
    source_maps[name]=actual
recipe=P/'mimalloc-packaged-build.rs'
pin(recipe,build['mimalloc_packaged_build_script_sha256'])
registry_recipe=Path(build['sources']['mimalloc']['registry_source']).parents[2]/'build.rs'
pin(registry_recipe,build['mimalloc_packaged_build_script_sha256'])
ck('build.file(&static_source)' in text(recipe) and 'build.flag_if_supported("-ftls-model=initial-exec")' in text(recipe), 'packaged static/TLS route')

expected_exits=[0,0,0,0,0,1,0,0,0,0]
ck([r['exit'] for r in build['commands']]==expected_exits, 'retained provider build command exits')
for r in build['commands']:
    pin(P/(r['label']+'.log'),r['log_sha256'])
    ck(r['end']>=r['start'] and r['timeout'] in [30,60,1200], ('bounded build receipt',r['label']))
configure=build['commands'][3]['command']
ck(configure==[str(P/'jemalloc-source/configure'),'--with-version=5.3.0-1-ge13ca993e8ccb9ba9847cc330696e02839f328f7','--with-jemalloc-prefix=oriole_je_','--with-private-namespace=oriole_je_private_','--disable-shared','--enable-static','--disable-doc','--disable-cxx','--prefix='+str(P/'jemalloc-build-02/install')], 'exact jemalloc configure')
cc=[shlex.split(r) for r in text(P/'jemalloc-build-02.log').splitlines() if r.startswith('cc ')]
ck(len(cc)==186, '186 saved jemalloc compiler vectors')
groups=collections.defaultdict(list)
for argv in cc:
    src=next(a for a in argv if a.endswith('.c')); out=argv[argv.index('-o')+1]
    rel=Path(src).relative_to(P/'jemalloc-source').as_posix()
    ck(rel in source_maps['jemalloc'] and '-O3' in argv and '-fPIC' in argv and '-std=gnu11' in argv and '-c' in argv, ('actual compiler source/options',src,out))
    ck(not any('flto' in a or 'profile-generate' in a or 'profile-use' in a for a in argv), ('provider no PGO/LTO',out))
    groups[src].append(out)
ck(len(groups)==62, '62 distinct provider C sources')
for src,outs in groups.items():
    stem=Path(src).stem
    ck(set(outs)=={f'src/{stem}.sym.o',f'src/{stem}.o',f'src/{stem}.pic.o'}, ('three compile phases',src))
details['jemalloc_actual_compile_vectors']=cc
mc=build['commands'][6]['command']
ck(mc==['cc','-O3','-fPIC','-ffunction-sections','-fdata-sections','-ftls-model=initial-exec','-std=c11','-Wno-error=date-time','-DMI_DEBUG=0','-DMI_BUILD_RELEASE','-DNDEBUG','-I'+str(P/'mimalloc-source/include'),'-I'+str(P/'mimalloc-source/src'),'-c',str(P/'mimalloc-source/src/static.c'),'-o',str(P/'mimalloc-direct-build/mimalloc.o')], 'exact mimalloc production vector')
forbidden={'malloc','calloc','realloc','free','reallocarray','aligned_alloc','posix_memalign','memalign','valloc','pvalloc','malloc_usable_size'}
exports={prefix+fn for prefix in ['oriole_je_','mi_'] for fn in ['malloc','realloc','free']}
for name,rec in build['providers'].items():
    pin(rec['archive'],rec['sha256']); ck(Path(rec['archive']).stat().st_size==rec['bytes'], ('provider size',name))
    src=P/('jemalloc-build-02/lib/libjemalloc_pic.a' if name=='jemalloc' else 'mimalloc-direct-build/libmimalloc.a')
    pin(src,rec['sha256'])
    defs=symbols(P/f'{name}-symbols-02.log')
    ck(set(rec['required_symbols'])<=defs and not defs&forbidden, ('provider symbol binding',name))
ck('cxx                : 0' in text(P/'jemalloc-configure-02.log') and 'malloc_conf        : \n' in text(P/'jemalloc-configure-02.log'), 'disabled C++/empty compile config')

# Preserve each source/build correction and its saved failed outcome.
for phase,want in [('provider-attempt-01',[0,0,0,0,2]),('provider-attempt-02',[0,0,0,0,0,1])]:
    r=j(P/phase/'provider-build.json');ck(r['status']=='incomplete' and [v['exit'] for v in r['commands']]==want, ('failed provider phase',phase))
    ck(r['sources']==build['sources'], ('unchanged source across provider attempts',phase))
    for c in r['commands']:
        origin=P/phase/(c['label']+'.log')
        if not origin.exists():origin=P/(c['label']+'.log')
        pin(origin,c['log_sha256'])
    read(P/phase/'FAILURE.md')
ck('Permission denied' in text(P/'provider-attempt-01/jemalloc-configure.log'), 'execute-bit failure raw')
ck('cmake/JoinPaths.cmake' in text(P/'provider-attempt-02/mimalloc-configure-02.log'), 'missing CMake source raw')
old=text(P/'proof-attempt-01/provider_proof.c')
ck(old.replace('(void)write(2, message, strlen(message));','if (write(2, message, strlen(message)) < 0) _Exit(2);').replace('(void)write(2, "\\n", 1);','if (write(2, "\\n", 1) < 0) _Exit(2);')==text(P/'provider_proof.c'), 'only strict diagnostic source fix')
ck(read(P/'proof-attempt-02/provider_proof.c')==read(P/'provider_proof.c')==read(P/'proof-final/provider_proof.c')==read(N/'proof-replay/provider_proof.c'), 'final proof source unchanged through replay')
failed=j(P/'proof-attempt-01/report.json');ck(failed['status']=='incomplete' and failed['observations']==[] and [r['exit'] for r in failed['commands']]==[1], 'failed compile before proof')
for s in ['stdout','stderr']:pin(P/f'proof-attempt-01/compile.{s}',failed['commands'][0][s+'_sha256'])
ck('warn_unused_result' in text(P/'proof-attempt-01/compile.stderr'), 'strict diagnostic raw')
details['draft_to_first_compile_patch']=diff(P/'draft-01/provider_proof.c',P/'proof-attempt-01/provider_proof.c')
details['proof_export_correction_patch']=diff(P/'proof-attempt-02/run_proof.py',P/'proof-final/run_proof.py')
read(P/'draft-01/REVIEW.md');read(P/'draft-01/MANIFEST.json')

# Source contract anchors and known narrow boundaries.
source=text(P/'provider_proof.c')
ck('api.destroy(child); api.destroy(parent); finished();' in source, 'child freed before parent')
ck('CHECK(api.reset(parser, NULL));' in source and 'api.free_model(parser, state.models[i]);' in source, 'model reset lifetime case')
ck('if (!next) return NULL; /* Old record remains owned and live on failure. */' in source and 'CHECK(bytes != 0);' in source, 'failed nonzero realloc ownership')
ck('CHECK(selected->resize(resized, impossible) == NULL);' in source and 'selected->release(resized); selected->release(NULL);' in source, 'direct growth/failure/null free')
refs=j(P/'source-references.json')
for name in ['design','expat_reference']:pin(refs[name]['path'],refs[name]['sha256'])
ref_lines=text(refs['expat_reference']['path']).splitlines()
for line in text(P/'expat-child-lifetime-reference.txt').splitlines():
    n,s=line.split(': ',1);ck(ref_lines[int(n)-1]==s, ('exact Expat lifetime quotation',n))
defs=text(P/'jemalloc-build-02/include/jemalloc/internal/jemalloc_internal_defs.h')
ck('#define JEMALLOC_PREFIX "oriole_je_"' in defs and '#define JEMALLOC_CPREFIX "ORIOLE_JE_"' in defs, 'actual jemalloc config namespace')
ck('"/etc/"JEMALLOC_PREFIX"malloc.conf"' in text(P/'jemalloc-source/src/jemalloc.c'), 'prefixed config path source')
ck(refs['malloc_conf_file']['path']=='/etc/malloc.conf', 'historical receipt scope retained')
config_now={p:{'exists':Path(p).exists(),'is_symlink':Path(p).is_symlink()} for p in ['/etc/malloc.conf','/etc/oriole_je_malloc.conf']}

def trace(ns):
    p='urn:r|' if ns else ''
    def start(name,attrs):return b'\xffS'+name.encode()+b''.join(b'\0'+v.encode() for v in attrs)+b'\0'
    def end(name):return b'\xffE'+name.encode()+b'\0'
    data=start(p+'root',[] if ns else ['xmlns','urn:r'])+start(p+'leaf',['a','v'])+b'alpha&beta'+end(p+'leaf')+start(p+'leaf',[])+end(p+'leaf')+end(p+'root')
    h=14695981039346656037
    for b in data:h=((h^b)*1099511628211)&((1<<64)-1)
    return {'namespaces':ns,'hash':f'{h:016x}','elements':3,'text_bytes':10}
traces=[trace(0),trace(1)]
ck([r['hash'] for r in traces]==['53ffea4dbf385f35','0f22e975d11416d6'], 'independent expected trace reconstruction')
proof_summaries=[]
for phase in [P/'proof-attempt-02',P/'proof-final',N/'proof-replay']:
    r=j(phase/'report.json');ck(r['status']=='passed' and r['affinity']==[2] and r['inputs_unchanged'] and r['providers_unchanged'] and r['source_unchanged'], ('proof completion',str(phase)))
    ck(r['provider_build_report_sha256']==sha(read(P/'provider-build.json')) and r['providers']==build['providers'], 'proof provider linkage')
    for p,h in r['inputs'].values():pin(p,h)
    for n,h in r['source_sha256'].items():pin(phase/n,h)
    executable=P/'proof-final/provider_proof' if phase==N/'proof-replay' else phase/'provider_proof'
    pin(executable,r['driver_sha256'])
    commands=r['commands'];labels=[x['label'] for x in commands]
    expected_pairs=[(e,m) for e in ['oriole','expat'] for m in ['ordinary','libc','jemalloc','mimalloc']]
    ck([(x['engine'],x['mode']) for x in r['observations']]==expected_pairs, 'eight proof combinations exactly')
    for c in commands:
        ck(c['exit']==0 and c['end']>=c['start'] and c['timeout'] in [120,180], ('successful bounded proof command',c['label']))
        for stream in ['stdout','stderr']:pin(phase/(c['label']+'.'+stream),c[stream+'_sha256'])
        ck(read(phase/(c['label']+'.stderr'))==b'', ('empty proof stderr',c['label']))
    ck(not symbols(phase/'defined-symbols.stdout')&forbidden, 'proof no process allocator definitions')
    if phase!=P/'proof-attempt-02':ck(symbols(phase/'dynamic-symbols.stdout',True)==exports==set(r['dynamic_function_exports']), 'six final exported functions')
    total_injections=total_origins=total_entrypoints=0; semantic=[]
    for obs in r['observations']:
        e,m=obs['engine'],obs['mode']; row=obs['observation'];label=e+'-'+m
        ck(j(phase/(label+'.stdout'))==row, ('immediate raw proof output',label))
        command=next(c for c in commands if c['label']==label)
        ck(command['command']==[str(executable),r['inputs'][e+'_so'][0],m], ('proof actual argv',label))
        ck(row['mode']==m and row['status']=='passed' and row['traces']==traces, ('complete trace semantics',label))
        ck(row['live_blocks']==row['live_suite_request_bytes']==0, ('no live suite records',label))
        failures=0 if m=='ordinary' else (20 if e=='oriole' else 16)
        ck(row['allocation_failure_cases']==row['injected_failures']==len(row['failure_outcomes'])==failures, ('fault sweep count',label))
        ck([v['index'] for v in row['failure_outcomes']]==list(range(1,failures+1)), ('all fault indices',label))
        for v in row['failure_outcomes']:ck(v['status']==0 and v['error']==1 and v['created'] in [0,1] and v['operations']>=v['index'], ('recorded no-memory outcome',label,v))
        if m=='ordinary':ck(row['suite_mallocs']==row['suite_reallocs']==row['suite_frees']==row['peak_suite_request_bytes']==0,'ordinary ledger scope')
        else:ck(row['suite_mallocs']>0 and row['suite_frees']>0, 'selected suite exercised')
        ck(row['parser_entrypoint_origin_checks']==18, '18 source-level load assertions')
        origins={v['label']:v for v in row['origins']}
        expected={'process_malloc','parser_create_mm'}|{p+'_'+f for p in ['libc','jemalloc','mimalloc'] for f in ['malloc','realloc','free']}
        ck(len(row['origins'])==len(origins)==11 and set(origins)==expected, 'complete origin label set')
        libc=Path(origins['process_malloc']['file']).resolve();ck(libc.name=='libc.so.6' and origins['process_malloc']['symbol'] in ['malloc','__libc_malloc'], 'process malloc libc')
        read(libc)
        for provider in ['libc','jemalloc','mimalloc']:
            for fn in ['malloc','realloc','free']:
                rec=origins[provider+'_'+fn]
                if provider=='libc':ck(Path(rec['file']).resolve()==libc and rec['symbol'] in [fn,'__libc_'+fn], 'libc provider origin')
                else:ck(Path(rec['file']).resolve()==executable.resolve() and rec['symbol']==('oriole_je_' if provider=='jemalloc' else 'mi_')+fn, 'static provider origin')
        rec=origins['parser_create_mm'];ck(Path(rec['file']).resolve()==Path(r['inputs'][e+'_so'][0]).resolve() and rec['symbol']=='XML_ParserCreate_MM','parser library origin')
        ck(row['jemalloc_version']=='5.3.0-1-ge13ca993e8ccb9ba9847cc330696e02839f328f7' and row['mimalloc_version']==20302, 'provider versions')
        ck(row['jemalloc_options']=={'opt.tcache':1,'opt.background_thread':0,'config.debug':0,'config.stats':1,'config.prof':0,'opt.narenas':1}, 'recorded jemalloc options')
        ck(row['mimalloc_options']=={'show_errors':0,'eager_commit':1,'arena_eager_commit':2,'purge_delay':10,'allow_large_os_pages':0,'destroy_on_exit':0}, 'recorded mimalloc options')
        total_injections+=failures;total_origins+=len(origins);total_entrypoints+=row['parser_entrypoint_origin_checks']
        semantic.append({'engine':e,'mode':m,'observation':{k:v for k,v in row.items() if k not in ['origins','proof_process_peak_rss_kib']}})
    ck((total_injections,total_origins,total_entrypoints)==(108,88,144), 'proof totals')
    if proof_summaries:ck(semantic==details['proof_semantics'], 'all semantic observations retained across export correction and PGO replay')
    details['proof_semantics']=semantic
    proof_summaries.append({'phase':str(phase),'report_sha256':sha(read(phase/'report.json')),'processes':8,'trace_observations':16,'injections':108,'origin_rows':88,'load_assertions':144,'driver_sha256':r['driver_sha256']})
    if phase==N/'proof-replay':ck('compile' not in labels and r['frozen_proof_report_sha256']==sha(read(P/'proof-final/report.json')), 'replay frozen executable no compile')

# The replay source only changes paths/PGO identities and removes the build command.
ck(text(N/'proof-controller.patch')==diff(P/'proof-final/run_proof.py',N/'replay_proof.py'), 'exact replay source delta')
def function_ast(p,name):
    return ast.dump(next(x for x in ast.parse(text(p)).body if isinstance(x,ast.FunctionDef) and x.name==name),include_attributes=False)
ck(function_ast(P/'proof-final/run_proof.py','run')==function_ast(N/'replay_proof.py','run'), 'unchanged proof child execution/cleanup')
ck(read(N/'replay_proof.py')==read(N/'proof-replay/run_proof.py'), 'executed replay controller copy')

# Actual native driver build/source and its unchanged callback/timer scope.
driver=j(N/'driver-build.json');original=Path('/home/dev-user/code/oss/oriole-raw-len-split/benchmarks/native_driver.c')
pin(original,driver['original_driver_source_sha256']);ck(read(original)==read(N/'native_driver_original.c'),'ordinary source copy exact')
pin(N/'native_allocator_driver.c',driver['driver_source_sha256']);pin(N/'native-allocator-driver',driver['driver_sha256'])
ck(driver['status']=='passed' and driver['returncode']==0 and driver['affinity']==[2] and driver['providers']==build['providers'], 'native successful strict build')
ck(driver['command']==['cc','-std=c11','-O3','-Wall','-Wextra','-Werror',*['-Wl,--export-dynamic-symbol='+p+f for p in ['oriole_je_','mi_'] for f in ['malloc','realloc','free']],'-I'+str(N),'-I'+str(P/'mimalloc-source/include'),str(N/'native_allocator_driver.c'),str(P/'libjemalloc.a'),str(P/'libmimalloc.a'),'-ldl','-lpthread','-lm','-lrt','-latomic','-o',str(N/'native-allocator-driver')], 'exact native compile argv')
for n in ['driver-compile.stdout','driver-compile.stderr','driver-symbols.stderr','driver-dynamic-symbols.stderr','driver-dependencies.stderr']:ck(read(N/n)==b'', ('native build clean stream',n))
ck(not symbols(N/'driver-symbols.stdout')&forbidden and symbols(N/'driver-dynamic-symbols.stdout',True)==exports==set(driver['dynamic_function_exports']), 'native no interposition/six exports')
old,new=text(original),text(N/'native_allocator_driver.c')
callbacks=lambda s:s[s.index('static void hash_bytes'):s.index('static size_t positive')]
loop=lambda s:s[s.index('    for (size_t iteration'):s.index('    puts("]}");') if '    puts("]}");' in s else s.index('    printf("]");')]
old_create="        Parser parser = argc == 6 ? api.create_ns(NULL, '|') : api.create(NULL);"
new_create='        Parser parser = suite ? api.create_mm(NULL, suite, namespaces ? "|" : NULL)\n                              : namespaces ? api.create_ns(NULL, \'|\') : api.create(NULL);'
ck(callbacks(old)==callbacks(new) and loop(old)==loop(new).replace(new_create,old_create), 'callbacks/timer loop exact except constructor')
ck(text(N/'driver.patch')==diff(original,N/'native_allocator_driver.c'), 'exact driver source patch')
draft=text(N/'driver-comment-draft/native_allocator_driver.c')
ck(draft.replace('called after every parse/free and outside timers.','called after all parse/free iterations and outside timers.')==new, 'comment-only correction exact')
pin(N/'driver-comment-draft/native-allocator-driver',driver['driver_sha256'])
ck('suite_malloc' not in new and 'static const XML_Memory_Handling_Suite' in new, 'native direct static suites without ledger')
ck('getenv("ORIOLE_NATIVE_RSS")' in new and new.index('workload_peak_rss_kib());')>new.index('double elapsed = now() - before;'), 'RSS one read outside parse timers')

inputs=j(N/'inputs.json');prep=j(N/'preparation.json');protocol=j(N/'prepared-protocol.json')
expected_libraries={'oriole':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','expat':'12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'}
for engine,rec in inputs['libraries'].items():pin(rec['path'],expected_libraries[engine]);ck(rec['sha256']==expected_libraries[engine], 'measured PGO library pin')
ck(inputs['libraries']==prep['libraries']==protocol['libraries'], 'protocol library identities')
for rec in inputs['evidence_copies']:pin(rec['source'],rec['sha256']);pin(rec['copy'],rec['sha256'])
for p,h in protocol['hashes'].items():pin(p,h)
source_manifest=j(N/'evidence/oriole/source.json')
with tarfile.open(fileobj=io.BytesIO(read(N/'evidence/oriole/source.tar.gz')),mode='r:gz') as t:
    members=t.getmembers();ck(len(members)==70 and len({m.name for m in members})==70 and all(m.isfile() for m in members), 'source archive70')
    ck({m.name:sha(t.extractfile(m).read()) for m in members}==source_manifest['source_sha256'], 'exact archived source promise')
for n,h in source_manifest['source_sha256'].items():pin(W/n,h)
ck(prep['proof_processes']==8 and prep['parser_origin_checks']==144 and prep['provider_origins_checked']==88 and prep['fault_injections']==108, 'preparation proof counts')
ck(prep['proof_replay_report_sha256']==sha(read(N/'proof-replay/report.json')), 'preparation proof identity')
read(N/'protocol-preparation-attempt-01/protocol-preparation.log')
details['source_verifier_correction_patch']=diff(N/'protocol-preparation-attempt-01/prepare_protocol.py',N/'prepare_protocol.py')
for n in ['RESULTS.md','PREPARATION.md','driver-dependencies.stdout','rss_screen.py','native_screen.py','prepare_driver.py','prepare_replay.py','replay_proof.py']:read(N/n)
for n in ['HANDOFF.md','summary.json','build_providers.py','build_providers_retry.py','complete_providers.py','run_proof.py','seal.py']:read(P/n)
read(W/'crates/oriole_storage/src/allocator.rs');read(W/'crates/oriole_expat/src/lib.rs')
for p,h in list(checked.items()):ck(sha(Path(p).read_bytes())==h, ('final input unchanged',p))
details.update(checked_files=checked,source_maps=source_maps,proof_phases=proof_summaries,config_file_current_observation=config_now)
(O/'details.json.gz').write_bytes(gzip.compress(json.dumps(details,sort_keys=True).encode(),mtime=0))
review={
 'status':'passed_with_provenance_limitations','scope':'Independent saved driver/provider API contract, source/build/failure lineage and proof-process audit. No parser/compiler/profiler/test/timing runs. Elapsed/RSS arithmetic belongs to the separate parent review.',
 'audit_cpu':4,'findings':[],
 'driver':{'source_sha256':driver['driver_source_sha256'],'binary_sha256':driver['driver_sha256'],'original_source_sha256':driver['original_driver_source_sha256'],'callback_and_timer_bytes_exact_except_constructor':True,'static_suite_lifetime':True,'process_interposition_absent_from_saved_symbols':True,'dynamic_provider_functions':sorted(exports)},
 'providers':build['providers'],'source_files':{'oriole':70,'jemalloc':467,'mimalloc':63},'provider_actual_compile_vectors':{'jemalloc':186,'distinct_jemalloc_sources':62,'mimalloc':1},
 'current_PGO_libraries':inputs['libraries'],'PGO_replay':proof_summaries[-1],'historical_proof_phases':proof_summaries[:-1],
 'contract':'Fixed per-process provider and static suites outlive all parser callbacks. Stack user-data remains live through synchronous parse/free. Nonzero realloc failure preserves old ownership. Content models are freed with live parser after reset; both child types are destroyed before parent. Direct growth/SIZE_MAX-failure/free(NULL) semantics and selected failure indices are recorded.',
 'preserved_attempts':['Unexecuted parent-before-child draft; corrected before proof compile.','Initial jemalloc source execute-bit removal, configure diagnostics and failed build.','Mimalloc missing CMake helpers; unchanged vendored static.c recipe used afterward.','Strict-C write-result diagnostic failure before any proof processes.','Successful broader-export intermediate proof; final exact six-function exports.','Native driver comment correction with byte-identical binary.','Ambiguous Cargo.toml suffix source verifier failure before preflight; exact-member correction.'],
 'limitations':['The saved /etc/malloc.conf absence receipt does not attest the prefixed /etc/oriole_je_malloc.conf path actually read by this jemalloc build. Both are absent at review time only. Recorded selected options and stripped configuration environment are retained; complete historical default configuration is not established.','Zero-size allocation/reallocation behavior is outside this proof. The ledger rejects non-injected realloc size zero; it does not establish general zero-size equivalence.','Allocation failure injection covers one successful small fixture and its 20 Oriole / 16 Expat operation indices per explicit mode; it is not exhaustive parser OOM coverage.','Final zero ledger counts describe tracked explicit-suite blocks, not every process allocation. Ordinary mode bypasses the suite ledger.','18 entrypoint assertions per proof process are executed source checks with an aggregate count, while 11 origin rows per process are retained individually. These attest the instrumented proof executable, not separate timing-worker dladdr records.','Proof RSS is excluded from workload RSS. Both providers have startup constructors in the common native executable.','Native driver inherits the original Linux narrow-character ABI and callback/timer body; this audit establishes no cross-platform or concurrent proof-ledger guarantee.','Package origin/hash audit is separately sealed and hash-linked; historical build outputs are verified from saved commands/logs and current hashes, without reproducing the build.'],
 'reused_reviews':prior,'separate_package_archive_sha256':pkg['archive_sha256'],'passed_checks':count,'checked_files':len(checked),'all_inspected_bytes_unchanged':True,'generator_sha256':sha(Path(__file__).read_bytes()),'details_sha256':sha((O/'details.json.gz').read_bytes())}
dump(O/'review.json',review)
print(json.dumps({'status':review['status'],'review_sha256':sha((O/'review.json').read_bytes()),'checks':count,'checked_files':len(checked)}))
