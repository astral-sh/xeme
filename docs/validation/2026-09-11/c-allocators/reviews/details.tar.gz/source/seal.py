"""Seal completed saved source/provider review; no target execution."""
from pathlib import Path
import gzip
import hashlib
import json
import os
assert os.sched_getaffinity(0)=={4}
O=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
review=load(O/'review.json');attempt=load(O/'attempt01.json')
assert review['status']=='passed_with_provenance_limitations'
assert sha(O/'review.json')=='0028d3e8da086ba756da6c8314fcbf1b5961ef9459e7e661231dddeaffcdb34c'
assert attempt['returncode']==0 and attempt['generator_sha256']==review['generator_sha256']==sha(O/'generator.py')
for stream in ['stdout','stderr']:assert attempt[stream+'_sha256']==sha(O/('attempt01.'+stream))
assert (O/'attempt01.stderr').read_bytes()==b''
assert sha(O/'details.json.gz')==review['details_sha256']
details=json.loads(gzip.decompress((O/'details.json.gz').read_bytes()))
assert len(details['checked_files'])==review['checked_files']==1352
assert len(details['jemalloc_actual_compile_vectors'])==186
related={
 '/tmp/oriole-pgo-allocator-package-independent-review/review.json':'7b623f904020e5c7b524825407ae44ff8dfca26e5ab2b0886be101aa9783205b',
 '/tmp/oriole-pgo-allocator-results-independent-review/review.json':'a8be32770ca80ba832a24689f2513ac25af41c8c6cefe6b2351c9c554784fb94'}
for p,h in related.items():assert sha(p)==h
receipt={'status':'sealed','review_sha256':sha(O/'review.json'),'details_sha256':sha(O/'details.json.gz'),'generator_sha256':sha(O/'generator.py'),'attempt_sha256':sha(O/'attempt01.json'),'formal_audit_attempts':1,'formal_audit_failures':0,'passed_checks':review['passed_checks'],'checked_files':review['checked_files'],'related_reviews':related,'publication_archive_sha256':review['separate_package_archive_sha256'],'scope':review['scope'],'limitations':'Historical prefixed jemalloc config path was not snapshotted; zero-size semantics, exhaustive OOM, all-process allocations, timed-worker origin attestation and cross-platform ABI are outside this proof. Full limits remain in review.json.','seal_generator_sha256':sha(__file__)}
dump(O/'receipt.json',receipt)
files={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(O.iterdir()) if p.is_file() and p.name!='files.json'}
dump(O/'files.json',files)
for n,r in files.items():assert sha(O/n)==r['sha256'] and (O/n).stat().st_size==r['bytes']
print(json.dumps({'status':'sealed','review_sha256':sha(O/'review.json'),'receipt_sha256':sha(O/'receipt.json'),'index_sha256':sha(O/'files.json'),'indexed_files':len(files)}))
