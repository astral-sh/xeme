from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time,tarfile
W=Path('/home/dev-user/code/oss/oriole-c-library-lto');O=Path('/tmp/oriole-c-library-lto-implementation');D=O/'checks';D.mkdir(exist_ok=False)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
assert os.sched_getaffinity(0)=={1}
env=os.environ|{'UV_TOOL_DIR':'/home/dev-user/.cache/oriole/uv-tools'};py='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
r={'status':'incomplete','commands':[],'env_overrides':{'UV_TOOL_DIR':env['UV_TOOL_DIR']}};save=lambda:(D/'report.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,cmd,timeout=180):
 row={'label':label,'command':['taskset','-c','1',*cmd],'start':time.time(),'timeout':timeout};r['commands'].append(row);save();p=None
 with (D/(label+'.stdout')).open('wb') as out,(D/(label+'.stderr')).open('wb') as err:
  try:
   p=subprocess.Popen(row['command'],cwd=W,env=env,stdout=out,stderr=err,start_new_session=True);row['exit']=p.wait(timeout=timeout)
  except BaseException as e:
   row['exception']=repr(e)
   if p is not None:
    if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
    row['exit']=p.wait()
   raise
  finally:out.flush();err.flush();row['end']=time.time();row['stdout_sha256']=h(D/(label+'.stdout'));row['stderr_sha256']=h(D/(label+'.stderr'));save()
 print(label,row['exit'],flush=True);assert row['exit']==0
try:
 run('pgo-unit',[py,'-I','-S','-m','unittest','discover','-s','tools/pgo','-p','test_build.py','-v'])
 run('ruff',['uvx','--offline','--from','ruff==0.16.6','ruff','check','tools','benchmarks','integration'])
 run('ruff-format',['uvx','--offline','--from','ruff==0.16.6','ruff','format','--check','tools/pgo','integration/python-build-standalone/prepare.py','integration/python-build-standalone/validate.py'])
 run('ty',['uvx','--offline','--from','ty==0.0.80','ty','check','--extra-search-path','tools','tools','benchmarks','integration'])
 run('pbs-recipe',[py,'-I','-S','integration/python-build-standalone/validate.py','--pbs','/home/dev-user/.cache/oriole/upstream/python-build-standalone-a455388','--cpython','/home/dev-user/.cache/oriole/upstream/cpython-3.12.13'])
 run('diff-check',['git','diff','--check'])
 old=subprocess.check_output(['git','show','HEAD:.github/workflows/ci.yml'],cwd=W,text=True)
 want=old.replace('cargo build --release --locked -p oriole_expat','cargo rustc --release --locked -p oriole_expat --lib --crate-type cdylib,staticlib').replace('cargo build --release --locked --target "$host" -p oriole_expat','cargo rustc --release --locked --target "$host" -p oriole_expat --lib --crate-type cdylib,staticlib')
 assert (W/'.github/workflows/ci.yml').read_text()==want;r['ci_only_three_build_commands_changed']=True
 source=j('/tmp/oriole-thinlto-production-study/source.json')['source_sha256'];changed=[n for n,v in source.items() if h(W/n)!=v];assert changed==['crates/oriole_expat/README.md'];r['source70_changes']=changed;r['rust_implementation_bytes_unchanged']=True
 delta=subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).splitlines();assert len(delta)==9
 tracked=set(source)|set(delta)|set('tools/pgo/'+p.name for p in (W/'tools/pgo').iterdir() if p.is_file())
 inputs={n:h(W/n) for n in sorted(tracked)};record={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'worktree':str(W),'source_sha256':{n:h(W/n) for n in source},'input_sha256':inputs,'changed_files':delta,'scope':'Nine build/tool/docs files; only C ABI README differs in source70 manifest; no Rust implementation, public header, Cargo manifests or runtime configuration changes.'}
 (O/'source.json').write_text(json.dumps(record,indent=2)+'\n');(O/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=W))
 with tarfile.open(O/'source.tar.gz','w:gz') as t:
  for n in inputs:t.add(W/n,arcname=n,recursive=False)
 r['status']='passed';r['source_manifest_sha256']=h(O/'source.json');r['patch_sha256']=h(O/'candidate.patch')
finally:save()
shutil.copyfile(__file__,O/'checks.py');print(json.dumps({k:r[k] for k in ['status','source_manifest_sha256','patch_sha256']}))
