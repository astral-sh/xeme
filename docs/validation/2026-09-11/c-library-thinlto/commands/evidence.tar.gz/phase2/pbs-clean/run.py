from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time,re,shlex
W=Path('/home/dev-user/code/oss/oriole-c-library-lto');O=Path('/tmp/oriole-c-library-lto-final-implementation');D=O/'pbs-clean';P=Path('/tmp/oriole-c-library-lto-pbs-clean-validation');assert not P.exists();D.mkdir(exist_ok=False)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text());assert os.sched_getaffinity(0)=={1}
s=j(O/'source.json');before={n:h(W/n) for n in s['input_sha256']};assert before==s['input_sha256'];assert j(O/'pgo-launch.json')['status']=='passed'
for n in s['source_sha256']:os.utime(W/n,None)
ov={'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/c-library-lto-pbs-target','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/verified-build/pbs-prepare/{workspace-path-hash}','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST':'all','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all','RUSTFLAGS':'','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':''};env=os.environ|ov;env.pop('RUSTC',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
cmd=['taskset','-c','1','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S',str(W/'integration/python-build-standalone/prepare.py'),'--output',str(P),'--toolchain','ohm']
r={'status':'incomplete','command':cmd,'cwd':str(W),'env_overrides':ov,'env_unset':['RUSTC','CARGO_ENCODED_RUSTFLAGS'],'start':time.time(),'timeout':1200,'source_manifest_sha256':h(O/'source.json'),'before':before,'scope':'Actual PBS prepare bundle only, Ohm default experimental flags enabled; stable CI smoke is authored but not run here. No PBS distribution or throughput claim.'};save=lambda:(D/'report.json').write_text(json.dumps(r,indent=2)+'\n');save();p=None
try:
 with (D/'stdout').open('wb') as out,(D/'stderr').open('wb') as err:
  try:
   p=subprocess.Popen(cmd,cwd=W,env=env,stdout=out,stderr=err,start_new_session=True);r['exit']=p.wait(timeout=1200)
  except BaseException as e:
   r['exception']=repr(e)
   if p is not None:
    if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
    r['exit']=p.wait()
   raise
  finally:out.flush();err.flush();r['end']=time.time();r['stdout_sha256']=h(D/'stdout');r['stderr_sha256']=h(D/'stderr');save()
 assert r['exit']==0
 manifest=j(P/'manifest.json');assert all(h(P/n)==v for n,v in manifest['files'].items());assert all(h(W/n)==v for n,v in manifest['sources'].items())
 log=(P/'build.log').read_text();rows=[]
 for raw in re.findall(r'(?ms)^[ \t]*Running `(.*?)`[ \t]*$',log):
  a=shlex.split(raw)
  if '--crate-name' not in a:continue
  i=a.index('--crate-name');opts=[a[k+1] if v=='-C' else v[2:] for k,v in enumerate(a) if v=='-C' or v.startswith('-C')];rows.append({'crate':a[i+1],'argv':a,'codegen_options':opts,'crate_types':[a[k+1] for k,v in enumerate(a[:-1]) if v=='--crate-type']})
 for name in ['oriole_storage','oriole','oriole_expat']:
  selected=[x for x in rows if x['crate']==name];assert len(selected)==1,(name,len(selected))
  assert 'relocation-model=pic' in selected[0]['codegen_options'] and 'panic=unwind' in selected[0]['codegen_options']
  if name=='oriole_expat':assert 'lto=thin' in selected[0]['codegen_options'] and selected[0]['crate_types']==['cdylib','staticlib']
  else:assert 'linker-plugin-lto' in selected[0]['codegen_options']
 (D/'compiler-invocations.json').write_text(json.dumps(rows,indent=2)+'\n')
 symbols=subprocess.check_output(['nm','--undefined-only','--format=posix',str(P/'libexpat.a')]);(D/'undefined-symbols.txt').write_bytes(symbols);refs=[x.split()[1] for x in symbols.decode().splitlines() if x.split() and x.split()[0]=='__cxa_thread_atexit_impl'];assert refs and all(x in ['w','v'] for x in refs)
 libs=(P/'native-static-libs.txt').read_text().split();assert libs and all(re.fullmatch(r'-l[A-Za-z0-9_]+',v) for v in libs)
 r.update(status='passed',bundle=str(P),bundle_manifest_sha256=h(P/'manifest.json'),native_static_libraries=libs,tls_references=refs,workspace_compiles=3,compiler_invocations_sha256=h(D/'compiler-invocations.json'),bundle_files_sha256={p.name:h(p) for p in sorted(P.iterdir()) if p.is_file()})
finally:
 r['after']={n:h(W/n) for n in s['input_sha256']};r['unchanged']=before==r['after'];save();shutil.copyfile(__file__,D/'run.py')
assert r['status']=='passed' and r['unchanged'];print(json.dumps({k:r[k] for k in ['status','workspace_compiles','bundle_manifest_sha256','tls_references']}))
