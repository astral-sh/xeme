from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time,shlex,re
W=Path('/home/dev-user/code/oss/oriole-c-library-lto');O=Path('/tmp/oriole-c-library-lto-final-implementation');P=Path('/tmp/oriole-c-library-lto-final-pgo-validation');assert not P.exists()
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text());assert os.sched_getaffinity(0)=={1}
s=j(O/'source.json');assert all(h(W/n)==v for n,v in s['input_sha256'].items())
for n in s['source_sha256']:os.utime(W/n,None)
profile_env={k:v for k,v in os.environ.items() if k.startswith('CARGO_PROFILE_')};assert not profile_env
ov={'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/c-library-lto-target','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST':'all','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST':'all','RUSTFLAGS':'','CARGO_ENCODED_RUSTFLAGS':'','RUSTC':'','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':''}
env=os.environ|ov
cmd=['taskset','-c','1','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S',str(W/'tools/pgo/build.py'),'--source',str(W),'--output',str(P),'--llvm-profdata','/tmp/oriole-pgo-study/llvm-tools-1.98.0/bin/llvm-profdata','--toolchain','ohm','--cargo-arg=-Zohm-defaults=no']
r={'status':'incomplete','command':cmd,'cwd':str(W),'env_overrides':ov,'start':time.time(),'timeout':2400,'source_manifest_sha256':h(O/'source.json'),'before':{n:h(W/n) for n in s['input_sha256']}};save=lambda:(O/'pgo-launch.json').write_text(json.dumps(r,indent=2)+'\n');save();p=None
try:
 with (O/'pgo.stdout').open('wb') as out,(O/'pgo.stderr').open('wb') as err:
  try:
   p=subprocess.Popen(cmd,cwd=W,env=env,stdout=out,stderr=err,start_new_session=True);r['exit']=p.wait(timeout=2400)
  except BaseException as e:
   r['exception']=repr(e)
   if p is not None:
    if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
    r['exit']=p.wait()
   raise
  finally:out.flush();err.flush();r['end']=time.time();r['stdout_sha256']=h(O/'pgo.stdout');r['stderr_sha256']=h(O/'pgo.stderr');save()
 assert r['exit']==0
 latest=j(P/'latest.json');manifest=Path(latest['manifest']);assert h(manifest)==latest['sha256'];m=j(manifest);assert m['status']=='passed' and m['compared_parses']==288 and m['cargo_args']==['-Zohm-defaults=no'] and m['base_rustflags']==[]
 builds={}
 for phase in ['generate','use']:
  c=next(c for c in m['commands'] if c['label']=='build-'+phase);assert c['status']=='passed' and c['returncode']==0;args=c['argv'];assert args.index('-Zohm-defaults=no')<args.index('rustc');assert args[args.index('--crate-type')+1]=='cdylib,staticlib'
  log=manifest.parent/c['log'];assert h(log)==c['log_sha256'];rows=[]
  for raw in re.findall(r'(?ms)^[ \t]*Running `(.*?)`[ \t]*$',log.read_text()):
   tokens=shlex.split(raw)
   if '--crate-name' not in tokens:continue
   at=tokens.index('--crate-name');a=tokens[at-1:];opts=[]
   for i,t in enumerate(a):
    if t=='-C':opts.append(a[i+1])
    elif t.startswith('-C'):opts.append(t[2:])
   rows.append({'crate':a[2],'command_line':raw,'rustc_args':a,'codegen_options':opts,'crate_types':[a[i+1] for i,t in enumerate(a[:-1]) if t=='--crate-type']})
  for crate in ['oriole_storage','oriole','oriole_expat']:
   selected=[x for x in rows if x['crate']==crate];assert len(selected)==1, (phase,crate,len(selected));row=selected[0]
   assert not any(x.startswith('-Z') for x in row['rustc_args'])
   assert any(x.startswith('profile-'+phase+'=') for x in row['codegen_options'])
   if crate=='oriole_expat':assert set(row['crate_types'])=={'cdylib','staticlib'} and 'lto=thin' in row['codegen_options']
   else:assert 'linker-plugin-lto' in row['codegen_options']
  (O/(phase+'-compiler-invocations.json')).write_text(json.dumps(rows,indent=2)+'\n');builds[phase]={'workspace_compiles':3,'all_compiles':len(rows),'log_sha256':h(log),'invocations_sha256':h(O/(phase+'-compiler-invocations.json'))}
 a=j(manifest.parent/'generate-training.json');b=j(manifest.parent/'use-training.json');assert a['status']==b['status']=='passed' and len(a['rows'])==len(b['rows'])==288 and a['rows']==b['rows']
 for relative,value in m['libraries_sha256'].items():assert h(manifest.parent/relative)==value
 r.update(status='passed',manifest=str(manifest),manifest_sha256=h(manifest),builds=builds,libraries=m['libraries_sha256'],generated_parses=288,optimized_replay_parses=288,all_training_rows_exact=True)
finally:
 r['after']={n:h(W/n) for n in s['input_sha256']};r['unchanged']=r['before']==r['after'];save();shutil.copyfile(__file__,O/'run_pgo.py')
assert r['status']=='passed' and r['unchanged'];print(json.dumps(r),flush=True)
