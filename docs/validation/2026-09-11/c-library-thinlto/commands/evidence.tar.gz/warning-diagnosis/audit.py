from pathlib import Path
import hashlib,json,re,shlex,shutil
O=Path(__file__).resolve().parent;W=Path('/home/dev-user/code/oss/oriole-c-library-lto');R=Path('/tmp/oriole-c-library-lto-pgo-validation/runs/run-_rdl2z8c')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
def compiles(text):
 rows=[]
 for raw in re.findall(r'(?ms)^[ \t]*Running `(.*?)`[ \t]*$',text):
  a=shlex.split(raw)
  if '--crate-name' not in a:continue
  i=a.index('--crate-name');opts=[a[k+1] if v=='-C' else v[2:] for k,v in enumerate(a) if v=='-C' or v.startswith('-C')]
  rows.append({'crate':a[i+1],'argv':a,'codegen_options':opts,'crate_types':[a[k+1] for k,v in enumerate(a[:-1]) if v=='--crate-type']})
 return rows
logs={};builds={}
for label,path in [('normal','/tmp/oriole-thinlto-production-study/normal.stderr'),('thinlto','/tmp/oriole-thinlto-production-study/thinlto.stderr'),('generate',str(R/'04-build-generate.log')),('use',str(R/'08-build-use.log'))]:
 p=Path(path);s=p.read_text();assert 'warning: implicit autoref creates a reference' in s
 rows=compiles(s);dep=next(x for x in rows if x['crate']=='allocator_api2');assert dep['argv'][dep['argv'].index('--cap-lints')+1]=='warn'
 (O/(label+'-compiler-invocations.json')).write_text(json.dumps(rows,indent=2)+'\n')
 warnings=[line for line in s.splitlines() if line.startswith('warning:')]
 logs[label]={'path':str(p),'sha256':h(p),'warnings':warnings,'dependency_cap_lints':'warn'}
 if label in ['generate','use']:
  ws=[x for x in rows if x['crate'] in ('oriole','oriole_storage','oriole_expat')];assert len(ws)==3
  for x in ws:
   assert any(v.startswith('profile-'+label+'=') for v in x['codegen_options'])
   if x['crate']=='oriole_expat':assert x['crate_types']==['cdylib','staticlib'] and 'lto=thin' in x['codegen_options']
   else:assert 'linker-plugin-lto' in x['codegen_options']
  builds[label]={'fresh_workspace_compiles':3,'final_effective_lto':'thin'}
probe=j(O/'single-v.json');assert probe['exit']==0
s=(O/'single-v.stderr').read_text();assert 'warning:' not in s;one=compiles(s);assert len(one)==1 and one[0]['argv'][-2:]==['--cap-lints','allow']
p=next(Path('/home/dev-user/.cache/toucan/cargo/registry/src').glob('*/allocator-api2-0.2.21/src/stable/vec/mod.rs'))
shutil.copyfile(p,O/'allocator-api2-0.2.21-vec-mod.rs');source=p.read_text();assert source.count('self.append_elements(')==1
start=source.index('    pub fn append(&mut self, other: &mut Self)');end=source.index('\n    /// Removes the specified range',start)
(O/'append-elements-excerpt.txt').write_text(source[start:end])
train=j(R/'generate-training.json');assert train['status']=='passed' and len(train['rows'])==288
manifest=j(R/'manifest.json');assert manifest['status']=='incomplete';assert not (R/'use-training.json').exists()
review={'status':'diagnosed_without_dependency_change','initial_phase_manifest_sha256':h('/tmp/oriole-c-library-lto-implementation/source.json'),'logs':logs,'builds':builds,'generate_training_parses':288,'optimized_replay_parses':0,'failure':'Existing strict profile-output gate rejected an actual dependency autoref warning after successful use compile; not a PGO profile mismatch or verbose-command false positive.','single_verbose_probe':{'manifest_sha256':h(O/'single-v.json'),'compiler_invocation_retained':True,'dependency_cap_lints':'allow','warnings':0,'scope':'Fresh cargo check of allocator-api2 only; full final PGO build separately required.'},'source_review':'The sole append_elements call receives other.as_slice() from live exclusive other, and len() finishes before reserve/copy/set_len. Existing implicit reference is valid under this safe caller; this lint does not establish dangling or aliasing UB here. No dependency source modified.','upstream_fix':'https://github.com/zakarumych/allocator-api2/commit/f95e3419ce41883904fcb2279b52aa35b5f04d76','upstream_pr':'https://github.com/zakarumych/allocator-api2/pull/42','upstream_status':'PR42 merged 2025-09-08; fix explicitly borrows &(*other), preserving semantics. No compatible-version upgrade evaluated or applied.','decision':'Use one --verbose to retain Cargo normal dependency lint policy and actual compiler commands. No explicit cap-lints, log filtering, strict profile gate change, dependency mutation or runtime change. Retain warning and initial failure.','cargo_docs':'https://doc.rust-lang.org/cargo/commands/cargo-rustc.html#display-options','failed_run_manifest_sha256':h(R/'manifest.json'),'append_source_sha256':h(p)}
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n');print(h(O/'review.json'))
