"""Preserve matched C-library ThinLTO measurements and their independent reviews."""
from pathlib import Path
import hashlib
import io
import json
import shutil
import statistics
import tarfile

REPO = Path('/home/dev-user/code/oss/oriole-c-library-lto')
OUT = REPO / 'docs/validation/2026-09-11/c-library-thinlto'
BENCH = REPO / 'benchmarks/results/2026-09-11/c-library-thinlto'
SHA = lambda b: hashlib.sha256(b).hexdigest()
READ = lambda p: json.loads(Path(p).read_text())
DIRECTORIES = {
    'build': '/tmp/oriole-thinlto-production-build-handoff',
    'gates': '/tmp/oriole-thinlto-production-gates-handoff',
    'native': '/tmp/oriole-thinlto-production-timing-study',
    'python': '/tmp/oriole-thinlto-production-python-study',
    'cpython': '/tmp/oriole-thinlto-production-cpython-gates',
    'reviews': '/tmp/oriole-thinlto-review-handoff',
}
CONTROLLERS = [
    '/tmp/oriole-package-c-library-thinlto.py',
    '/tmp/oriole-summarize-cohorts.py',
    '/tmp/oriole-prepare-thinlto-production-timing.py',
    '/tmp/oriole-time-thinlto-production-native.py',
    '/tmp/oriole-prepare-thinlto-production-python.py',
    '/tmp/oriole-time-thinlto-production-python.py',
    '/tmp/oriole-thinlto-production-cpython-gates.py',
]
COPIES = {
    'build.json': '/tmp/oriole-thinlto-production-study/report.json',
    'source.json': '/tmp/oriole-thinlto-production-study/source.json',
    'gates.json': '/tmp/oriole-thinlto-production-gates/summary.json',
    'native-summary.json': '/tmp/oriole-thinlto-production-timing-study/summary.json',
    'python-summary.json': '/tmp/oriole-thinlto-production-python-study/summary.json',
    'build-review.json': '/tmp/oriole-thinlto-build-independent-review/review.json',
    'native-review.json': '/tmp/oriole-thinlto-native-independent-review/review.json',
    'python-review.json': '/tmp/oriole-thinlto-python-independent-review/review.json',
    'cpython-review.json': '/tmp/oriole-thinlto-production-cpython-independent-review/review.json',
}

assert READ(COPIES['build.json'])['status'] == 'passed'
gates = READ(COPIES['gates.json'])
assert gates['status'] == 'correctness_parity_gates_passed'
assert gates['api']['all4740rows_exact']
assert (gates['api']['passed'], gates['api']['failed']) == (4347, 393)
source = READ(COPIES['source.json'])
delta = [p for p, digest in source['source_sha256'].items()
         if SHA((REPO / p).read_bytes()) != digest]
assert delta == ['crates/oriole_expat/README.md'], delta
for p in [*CONTROLLERS, *COPIES.values()]:
    assert Path(p).is_file(), p
paths = {}
for prefix, directory in DIRECTORIES.items():
    root = Path(directory)
    assert root.is_dir()
    for p in sorted(root.rglob('*')):
        if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:
            paths[prefix + '/' + str(p.relative_to(root))] = p
for p in CONTROLLERS:
    paths['controllers/' + Path(p).name] = Path(p)
OUT.mkdir(parents=True, exist_ok=False)
BENCH.mkdir(parents=True, exist_ok=False)
members, excluded = [], []
with tarfile.open(OUT / 'evidence.tar.gz', 'w:gz', compresslevel=9) as archive:
    for name, p in sorted(paths.items()):
        data = p.read_bytes()
        entry = {'path': name, 'source': str(p), 'bytes': len(data), 'sha256': SHA(data)}
        if data.startswith((b'\x7fELF', b'!<arch>\n')):
            excluded.append(entry)
            continue
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        archive.addfile(info, io.BytesIO(data))
        members.append(entry)
with tarfile.open(OUT / 'evidence.tar.gz', 'r:gz') as archive:
    actual = archive.getmembers()
    assert len(actual) == len(members)
    for member, entry in zip(actual, members):
        assert member.isfile() and member.name == entry['path'] and member.size == entry['bytes']
        assert SHA(archive.extractfile(member).read()) == entry['sha256'] == SHA(Path(entry['source']).read_bytes())
for entry in excluded:
    assert SHA(Path(entry['source']).read_bytes()) == entry['sha256']
(OUT / 'archive-members.json').write_text(json.dumps({'members': members, 'excluded_binaries': excluded}, indent=2) + '\n')
for name, p in COPIES.items():
    shutil.copy2(p, OUT / name)
summary = {
    'runtime_commit': '50c20c1e73eeaacabb9df90e413f502361fb45b3',
    'source_files': len(source['source_sha256']),
    'current_documentation_only_source_delta': delta,
    'libraries': gates['libraries'],
    'api': gates['api'],
    'cpython_each_linkage': {'tests': 802, 'failures': 2, 'reported_skips': 14, 'expected_failures': 3},
    'native': READ(OUT / 'native-summary.json'),
    'python': READ(OUT / 'python-summary.json'),
    'archive': {'sha256': SHA((OUT / 'evidence.tar.gz').read_bytes()), 'members': len(members),
                'direct_binary_exclusions': len(excluded), 'bytes': (OUT / 'evidence.tar.gz').stat().st_size,
                'raw_bytes': sum(m['bytes'] for m in members), 'member_and_origin_readback': True},
    'scope': 'Same-source normal9815 and C-only ThinLTOa55 libraries. Expat normal7a333. No PGO or runtime changes. No transfer of same-source Rust test results to the C-only artifact. Production command validation is separate from these frozen measurements.',
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
n = READ('/tmp/oriole-thinlto-production-timing-study/native-screen/results.json')
labels = {'vulkan': 'Vulkan registry', 'wayland': 'Wayland protocol', 'maven': 'Maven POM',
          'batik': 'Batik SVG', 'gtk': 'GTK UI', 'docbook': 'DocBook XSL'}
lines = []
for name, label in labels.items():
    row = next(r for r in n['summary'] if r['condition']['name'] == name
               and r['condition']['chunk'] == 4096 and not r['condition']['namespaces'])
    samples = [r for r in n['rows'] if r['condition'] == row['condition']]
    times = {e: statistics.median(next(p['median_seconds'] for p in r['processes'] if p['engine'] == e)
                                 for r in samples) * 1000 for e in ['candidate', 'expat']}
    lines.append(f"| {label} | {times['candidate']:.3f} ms | {times['expat']:.3f} ms | {row['median_ratios']['candidate_over_expat']:.2f}× |")
(OUT / 'table.md').write_text('\n'.join(lines) + '\n')
wins = [{'condition': r['condition'], 'ratio': r['median_ratios']['candidate_over_expat']}
        for r in n['summary'] if r['median_ratios']['candidate_over_expat'] < 1]
(OUT / 'native-wins.json').write_text(json.dumps(wins, indent=2) + '\n')
print(json.dumps({'archive': summary['archive'], 'table': lines, 'native_wins': wins}, indent=2), flush=True)
