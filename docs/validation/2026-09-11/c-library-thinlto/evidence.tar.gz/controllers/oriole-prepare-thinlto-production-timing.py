import difflib,hashlib,json,shutil,subprocess
from pathlib import Path
out=Path('/tmp/oriole-thinlto-production-timing-study');out.mkdir(exist_ok=False)
study=Path('/tmp/oriole-thinlto-production-study')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((study/'report.json').read_text())['status']=='passed'
source=json.loads((study/'source.json').read_text())
assert all(sha(Path(source['worktree'])/p)==v for p,v in source['source_sha256'].items())
assert sha(study/'thinlto/liboriole_expat.so')=='a55ca0f0fed68f8db0f2e8d3ea86c271c8491fe130b5074077aecace3ab4a4df'
assert sha(study/'normal/liboriole_expat.so')=='9815cc852327d455c094b0fb72c1d33fb90a4571e67cf15965e96e2300376828'
old=Path('/tmp/oriole-start-frame-integration-timing-study/native_screen.py').read_text()
new=old.replace('/tmp/oriole-start-frame-integration-timing-study',str(out)).replace('/tmp/oriole-start-frame-integration-study/liboriole_expat.so',str(study/'thinlto/liboriole_expat.so')).replace('/tmp/oriole-end-tag-integration-study/liboriole_expat.so',str(study/'normal/liboriole_expat.so')).replace('published503a559/dd16d23e','matched normal/9815cc85').replace('integrated literal start-frame lowering/9815cc85 candidate','same-source effective ThinLTO/a55ca0f0 candidate').replace('integrated literal start-frame lowering','effective C-only ThinLTO build')
new=new.replace('No PGO. Shared host;','No PGO. Oriole C-only candidate enables configured ThinLTO; matched normal and pinned Expat retain their original non-LTO flags. Shared host;')
(out/'native_screen.py').write_text(new)
(out/'controller.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='reviewed-start-frame-native',tofile='same-source-thinlto-native')))
command=['taskset','-c','3','python3',str(out/'native_screen.py'),'preflight']
with (out/'preflight-controller.log').open('wb') as log:run=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=600)
report={'status':'passed' if run.returncode==0 else 'failed','command':command,'exit':run.returncode,'source_manifest_sha256':sha(study/'source.json'),'scope':'Same28 original conditions,84preflights,588timedworkers. Only C-only crate-type build selection changes; exact matching70 source, normal byte-exact9815. Full binary gates run separately.'}
(out/'preparation.json').write_text(json.dumps(report,indent=2)+'\n');shutil.copy2(__file__,out/Path(__file__).name)
print(json.dumps(report),flush=True);raise SystemExit(run.returncode)
