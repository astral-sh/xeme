# ThinLTO C-library compatibility gates

The C-only ThinLTO build preserves every observed result of the byte-identical-source normal build. The original upstream suite remains **4,347 passing / 393 failing**, with raw exit 1. These gates validate the new production artifacts; they do not establish a speedup.

- Normal shared `9815cc85` / static `92eafd42`.
- ThinLTO shared `a55ca0f0` / static `3f4f5125`.
- All 70 frozen source files are unchanged. Full identities are in `source.json` and `summary.json`.
- Build provenance and the actual `-C lto=thin` compiler invocation are sealed separately at `/tmp/oriole-thinlto-production-build-handoff` (archive `400be0d77b8cfd7af698c16bb2ae55373c81d3e8127a703ba58ef4757867b21d`).

## Results

| Gate | Result |
| --- | --- |
| Original upstream API | All 4,740 rows exactly match normal; 4,347 pass / 393 fail |
| Original bounds | 3 seconds per case; 1 GiB address space; 768 MiB RSS; 240 seconds total |
| Native C consumers | All six dynamic/static integration, adversarial and allocation runs pass; 327 original allocation scenarios per linkage |
| Strict deterministic traces | 3,318 exact normal comparisons |
| Custom encoding controls | 36,456 exact normal comparisons |
| Malformed input | 2,392 exact full-observation comparisons |
| DTD publication | 1,304 logical cases / 3,912 parser executions; exact normal results |
| End-handler lifecycle | 38 logical cases / 114 parser executions; exact normal results |
| End-handler selected allocation | Six scenarios per library; four fault controls and two successes, exact observations and no live allocations |

The publication oracle retains 10,416 Default and 864 external-entity callback-position differences from reference Expat. Payload, ordering, outcomes and final positions match for those publication cases. All 38 End-lifecycle cases retain their previously observed reference differences. These remain explicit; the strict and malformed suites compare against normal Oriole, not a claim of full Expat equivalence.

Native ASan/UBSan instrumentation covers the C consumers, while the Rust ThinLTO release library is uninstrumented. Leak checking is disabled. Dynamic and static linkage are both exercised. Rust workspace checks were not rerun for this unchanged source; CPython and timing evidence are owned by root and are outside this handoff.

## Provenance

The adapted controllers preserve all original fixtures, assertions, retry ceilings and bounds. Changes are retained in `controller-deltas.json`: candidate/control/source/output paths and CPU assignments only. CPU1 ran API/native gates; CPU4 ran the other controls. Both lane controllers completed with zero exits, retained every command/output, and verified the before/after source and library hashes. The upstream API's own exit 1 is retained separately.

`summary.json`, original reports, all available raw observations and source inputs are archived. Executable binaries and Python bytecode caches are excluded; excluded executable identities are recorded in the handoff manifest. Every archive member and the nested 70-file source archive are checked after compression. No parser rerun is performed during packaging.
