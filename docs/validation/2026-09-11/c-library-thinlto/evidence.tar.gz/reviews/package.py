"""Seal separate same-source effective ThinLTO reviews with complete readback."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import tarfile

out = Path('/tmp/oriole-thinlto-review-handoff')
roots = {
    'build': Path('/tmp/oriole-thinlto-build-independent-review'),
    'native': Path('/tmp/oriole-thinlto-native-independent-review'),
    'python': Path('/tmp/oriole-thinlto-python-independent-review'),
    'cpython': Path('/tmp/oriole-thinlto-production-cpython-independent-review'),
    'gates': Path('/tmp/oriole-thinlto-gates-independent-review'),
}
def h(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):
    return json.loads(Path(path).read_bytes())

native = load(roots['native']/'review.json')
python = load(roots['python']/'review.json')
cpp = load(roots['cpython']/'review.json')
build = load(roots['build']/'review.json')
gates = load(roots['gates']/'review.json')
assert len(native['regressions']) == 7 and len(python['regressions']) == 3
assert build['source_files'] == 70 and build['normal_matches_frozen9815']
assert all(r['methods'] == 802 and len(r['failures']) == 2 for r in cpp['cpython'].values())
out.mkdir(exist_ok=False)
entries = []
for label, root in roots.items():
    for p in sorted(root.rglob('*')):
        if p.is_file():
            entries.append({'path': label+'/'+p.relative_to(root).as_posix(), 'origin': str(p), 'sha256': h(p), 'bytes': p.stat().st_size})
with (out/'reviews.tar.gz').open('wb') as f:
    with gzip.GzipFile(fileobj=f, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as archive:
            for row in entries:
                data = Path(row['origin']).read_bytes()
                assert hashlib.sha256(data).hexdigest() == row['sha256']
                member = tarfile.TarInfo(row['path'])
                member.size = len(data)
                member.mode = 0o644
                archive.addfile(member, io.BytesIO(data))
with tarfile.open(out/'reviews.tar.gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(entries)
    for member, row in zip(members, entries, strict=True):
        assert member.isfile() and member.name == row['path'] and member.size == row['bytes']
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == row['sha256'] == h(row['origin'])
(out/'archive-members.json').write_text(json.dumps(entries, indent=2)+'\n')
summary = {
    'status': 'separate_thinlto_independent_reviews_passed',
    'scope': 'Same70 runtime source, matched normal9815/92ea versus effective C-only ThinLTOa55c/3f4. Build/compiler/static-artifact, canonical C-gates, full saved native/Python timings and strict CPython reviews. No reviewer parser, compiler, test, fuzz or timing reruns. Production tool implementation and future PGO builds remain separate.',
    'source_files': 70,
    'source_manifest_sha256': build['source_manifest_sha256'],
    'runtime_commit': '50c20c1e73eeaacabb9df90e413f502361fb45b3',
    'builds': build['builds'],
    'native_groups': native['groups'],
    'python_groups': python['groups'],
    'strict_cpython': cpp['cpython'],
    'api': gates['api'],
    'counts': {'native': native['counts'], 'python': {'preflights': python['preflights'], 'timed_workers': python['timed_workers'], 'cohorts': python['cohorts'], 'sample_counts': python['sample_counts']}},
    'regressions': {'native': native['regressions'], 'python': python['regressions']},
    'compiler_scope': 'Same Ohm toolchain with automatic experimental defaults disabled. Both selections compile three workspace crates freshly; normal includes rlib without an explicit cross-crate LTO flag, C-only final command emits -C lto=thin and workspace dependencies linker-plugin-lto. Cargo manifest/runtime/header bytes unchanged. Pinned Expat retains its normal compiler flags; this is not a matched LTO/LTO engine comparison.',
    'limitations': [
        'Shared-host point estimates on six original XML inputs; every condition and adverse result retained. No full-project claim.',
        'Native includes create/setup/parse/callback/free; Python sums parsing and explicit destruction with GC enabled. Canonicalized text output is not exact callback-grouping proof.',
        'Original393 API failures and two strict CPython failures remain. Overall native/Python remain slower than the pinned normal Expat reference.',
        'Six native C sanitizer consumers pass; each of the two linkage-specific allocation consumers covers327 scenarios. Rust is normal release and LSan is disabled; no new sustained Rust sanitizer campaign.',
        'Successful custom-alias raw traces are not individually retained. Executed controller/templates/zero-difference reports remain scoped.',
        'No ThinLTO Rust workspace test run is claimed or inherited: identical source is verified, while changed C artifacts have separate executed C/API/consumer gates.',
        'Historical PGO logs are nonverbose; no exact historical effective-LTO assertion is certified. Original historical measurements remain unchanged.',
        'The frozen Python method prose begins Three normal parser libraries while also explicitly naming ThinLTO. Actual compiler selection is established by build receipts; original text is preserved.',
    ],
    'reviews': {label: {'path': str(root/'review.json'), 'sha256': h(root/'review.json')} for label, root in roots.items()},
    'gate_handoff_manifest_sha256': h('/tmp/oriole-thinlto-production-gates-handoff/artifact-manifest.json'),
    'packaging_history': 'Initial archive readback passed but summary creation used the wrong gate manifest filename. Original partial directory and generator remain under /tmp/oriole-thinlto-review-handoff-initial-incomplete and /tmp/oriole-package-thinlto-reviews-initial.py; no parser, build, test or timing failure.',
    'gate_handoff_review_sha256': h(roots['gates']/'handoff-review.json'),
    'readback': {'members': len(entries), 'all_stored_and_origin_bytes_rehashed': True},
}
(out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
shutil.copyfile(__file__, out/'package.py')
files = {p.name: {'sha256': h(p), 'bytes': p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file()}
(out/'manifest.json').write_text(json.dumps({'status':'complete', 'files':files}, indent=2)+'\n')
for name, row in files.items():
    assert h(out/name) == row['sha256']
print(json.dumps({'path':str(out), 'manifest_sha256':h(out/'manifest.json'), 'archive_sha256':h(out/'reviews.tar.gz'), 'archive_bytes':(out/'reviews.tar.gz').stat().st_size, 'members':len(entries), 'outer_files':len(files)+1}))
