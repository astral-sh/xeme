"""Independently inspect stored PGO/PBS commands/results; never execute their commands."""
from pathlib import Path
import collections,hashlib,json,re,shlex,tarfile
O=Path(__file__).parent;W=Path('/home/dev-user/code/oss/oriole-c-library-lto')
P=Path('/tmp/oriole-c-library-lto-final-pgo-validation/runs/run-0gjyf0_i')
S=Path('/tmp/oriole-c-library-lto-production-implementation');B=Path('/tmp/oriole-c-library-lto-pbs-production-fresh-validation')
H=Path('/tmp/oriole-c-library-lto-command-handoff')
checks=[];files={}
def check(v,label):
 checks.append(label)
 if not v:raise AssertionError(label)
def sha(p):
 p=Path(p);h=hashlib.sha256(p.read_bytes()).hexdigest();files[str(p)]=h;return h
def load(p):sha(p);return json.loads(Path(p).read_text())
def verify(p,h):check(sha(p)==h,'sha '+str(p))
def compiles(text):
 rows=[]
 for line in text.splitlines():
  x=line.strip()
  if not x.startswith('Running `') or not '/rustc ' in x:continue
  check(x.endswith('`'),'terminated rustc command')
  a=shlex.split(x[len('Running `'):-1]);i=a.index('--crate-name');a=a[i-1:]
  cg=[]
  for j,v in enumerate(a):
   if v=='-C':cg.append(a[j+1])
   elif v.startswith('-C'):cg.append(v[2:])
  rows.append({'crate':a[a.index('--crate-name')+1],'argv':a,'codegen_options':cg,'crate_types':[a[j+1] for j,v in enumerate(a[:-1]) if v=='--crate-type']})
 return rows
def workspace(rows,label):
 selected=[r for r in rows if r['crate'] in ['oriole','oriole_expat','oriole_storage']]
 check(collections.Counter(r['crate']for r in selected)==collections.Counter(['oriole','oriole_expat','oriole_storage']),label+' exactly3 fresh workspace commands')
 final=next(r for r in selected if r['crate']=='oriole_expat')
 check(final['crate_types']==['cdylib','staticlib'] and 'lto=thin'in final['codegen_options'],label+' effective final ThinLTO')
 check(all('linker-plugin-lto'in r['codegen_options']for r in selected if r['crate']!='oriole_expat'),label+' dependency bitcode')
 return selected
try:
 m=load(P/'manifest.json');verify(P/'manifest.json','8a7aeed73432e48d7138330faf9bf7e22baac8cbb7c441b81d627238e8bd9d0a')
 check(m['status']=='passed' and m['compared_parses']==288 and m['cpu_affinity']==[1],'PGO status/count/affinity')
 check(m['cargo_args']==['-Zohm-defaults=no'] and m['base_rustflags']==[],'PGO exact globals/baseflags')
 check(re.search(r'LLVM version: (\d+\.\d+\.\d+)',m['rustc_version']).group(1)==re.search(r'LLVM version (\d+\.\d+\.\d+)',m['profdata_version']).group(1),'matching LLVM semver')
 phase3=load(S/'source.json');phase2=load('/tmp/oriole-c-library-lto-final-implementation/source.json')
 for mapkey in ['source_sha256','input_sha256']:
  check(set(phase2[mapkey])==set(phase3[mapkey]),'phase source domain '+mapkey)
  dif=[n for n in phase2[mapkey] if phase2[mapkey][n]!=phase3[mapkey][n]]
  check(dif==(['integration/python-build-standalone/prepare.py'] if mapkey=='input_sha256' else []),'phase3 only PBS helper '+mapkey)
 for n,h in m['source_sha256'].items():verify(W/n,h);check(phase3['input_sha256'][n]==h,'PGO source remains final '+n)
 for n,h in m['script_sha256'].items():verify(W/'tools/pgo'/n,h);check(phase3['input_sha256']['tools/pgo/'+n]==h,'PGO tool remains final '+n)
 for key in ['tools_sha256','cargo_config_sha256']:
  for n,h in m[key].items():verify(n,h)
 for n,h in m['inputs_sha256'].items():verify(P/'inputs'/n,h)
 for n,h in m['libraries_sha256'].items():verify(P/n,h)
 for n,h in m['profiles_sha256'].items():verify(P/n if n=='merged.profdata' else P/'raw-profiles'/n,h)
 check(len(m['commands'])==10,'ten PGO commands')
 parsed={}
 for c in m['commands']:
  verify(P/c['log'],c['log_sha256']);check(c['status']=='passed' and c['returncode']==0,'PGO command success '+c['label'])
  if c['label'].startswith('build-'):
   a=c['argv'];check(a[1:4]==['+ohm','-Zohm-defaults=no','rustc'] and a[-3:]==['--crate-type','cdylib,staticlib','--verbose'],'C-only global order '+c['label'])
   e=c['environment'];check(e['RUSTC_WRAPPER']==e['RUSTC_WORKSPACE_WRAPPER']=='' and e['CARGO_INCREMENTAL']=='0' and e['CARGO_BUILD_JOBS']=='1','PGO wrapper/parallel environment')
   raw=(P/c['log']).read_text();rs=compiles(raw);parsed[c['label']]=workspace(rs,c['label'])
   check(not any(re.search(r'(?i)^\s*warning',line) for line in raw.splitlines()),'no warning diagnostic '+c['label'])
   dep=[r for r in rs if r['crate']=='allocator_api2'];check(len(dep)==1 and dep[0]['argv'][dep[0]['argv'].index('--cap-lints')+1]=='allow','normal dependency lint policy')
   phase=c['label'][6:];flags=e['CARGO_ENCODED_RUSTFLAGS'];expected='profile-generate=' if phase=='generate' else 'profile-use='
   check(expected in flags,'PGO phase flag '+phase)
   check(all(any(z.startswith(expected) for z in r['codegen_options'])for r in parsed[c['label']]),'actual profile flag '+phase)
  if c['label']in['generate','use']:
   check(c['argv'][1:3]==['-I','-S'],'isolated trainer '+c['label'])
 ci=load(P/'inputs/manifest.json');check(len(ci['rows'])==12 and ci['iterations']==2 and ci['handlers']==['minimal','full'],'generated corpus configuration')
 check(ci['method']=='Generated XML only; Python ctypes callbacks. No external files or network input.','explicit generated scope')
 expected=[]
 for r in ci['rows']:
  data=(P/'inputs'/r['file']).read_bytes();check(len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256'],'fixture bytes '+r['name'])
  for ns in r['namespaces']:
   for chunk in r['chunks']:
    for handlers in ci['handlers']:
     for iteration in range(ci['iterations']):expected.append((r['name'],ns,chunk,handlers,iteration))
 training={}
 for phase,h in m['training_sha256'].items():
  p=P/(phase+'-training.json');verify(p,h);d=load(p);training[phase]=d
  check(d['status']=='passed' and len(d['rows'])==288,'training successful count '+phase)
  check([(r['fixture'],r['namespaces'],r['chunk'],r['handlers'],r['iteration'])for r in d['rows']]==expected,'all configured rows in order '+phase)
  check(all(r['status']==1 and r['error']==0 and not r['callback_exceptions'] and re.fullmatch('[0-9a-f]{64}',r['callback_sha256'])for r in d['rows']),'all parse outcomes '+phase)
  lib=P/phase/'liboriole_expat.so';check(d['xml_parse_origin']=={'path':str(lib),'sha256':sha(lib)} and d['library_sha256']==sha(lib),'actual recorded XML_Parse origin '+phase)
  check(d['inputs_sha256']==sha(P/'inputs/manifest.json') and d['script_sha256']==sha(W/'tools/pgo/train.py'),'trainer/corpus identity '+phase)
 check(training['generate']['rows']==training['use']['rows'],'exact288 optimized replay rows')
 # PBS final fresh source/context, actual compiler vector and static bundle records.
 pr=load(S/'pbs-fresh/report.json');check(pr['status']=='passed' and pr['exit']==0 and pr['unchanged'] and pr['before']==pr['after']==phase3['input_sha256'],'PBS success/source identity')
 check(pr['env_overrides']['CARGO_ENCODED_RUSTFLAGS']=='' and pr['env_unset']==['RUSTC'],'empty encoded flags deliberately tested')
 for n,h in pr['before'].items():verify(W/n,h)
 for n,h in pr['bundle_files_sha256'].items():verify(B/n,h)
 for n in ['stdout','stderr']:verify(S/'pbs-fresh'/n,pr[n+'_sha256'])
 verify(S/'pbs-fresh/compiler-invocations.json',pr['compiler_invocations_sha256'])
 bm=load(B/'manifest.json');check(bm['command']==['cargo','+ohm','rustc','--locked','--release','--target','x86_64-unknown-linux-gnu','-p','oriole_expat','--lib','--crate-type','cdylib,staticlib','--verbose','--','--print=native-static-libs'],'PBS default Ohm command')
 rs=compiles((B/'build.log').read_text());ps=workspace(rs,'PBS');saved=[r for r in load(S/'pbs-fresh/compiler-invocations.json') if r['crate'] in ['oriole','oriole_expat','oriole_storage']]
 # Parser drops any Ohm flags before --crate-name; compare complete trailing rustc vectors instead.
 check(len(saved)==3,'PBS saved three rows')
 for r in ps:
  s=next(x for x in saved if x['crate']==r['crate']);i=s['argv'].index('--crate-name')
  check(r['argv'][1:]==s['argv'][i:],'PBS actual command reconstruction '+r['crate'])
  check('relocation-model=pic'in r['codegen_options'] and 'panic=unwind'in r['codegen_options'],'actual explicit PIC/unwind '+r['crate'])
 check(bm['rustflags']=='-C relocation-model=pic -C panic=unwind','PBS manifest flags')
 native=(B/'native-static-libs.txt').read_text().split();check(native==pr['native_static_libraries']==['-lgcc_s','-lutil','-lrt','-lpthread','-lm','-ldl','-lc'],'native libraries bytes')
 und=S/'pbs-fresh/undefined-symbols.txt';sha(und);tls=[line.split()[-2] for line in und.read_text().splitlines() if line.split() and line.split()[-1]=='__cxa_thread_atexit_impl'];check(tls==pr['tls_references']==['w'],'saved undefined-symbol weak TLS evidence')
 neg=load(S/'pbs-nonempty.json');check(neg['exit']==2 and neg['output_directory_absent'],'nonempty encoded negative outcome')
 for n in ['stdout','stderr']:verify(S/('pbs-nonempty.'+n),neg[n+'_sha256'])
 check('CARGO_ENCODED_RUSTFLAGS'in(S/'pbs-nonempty.stderr').read_text() and not(S/'pbs-nonempty.stdout').read_bytes(),'nonempty reject diagnostic')
 # Saved tooling tests and all failure scopes. Archive byte/origin coverage belongs to the package review.
 cr=load(S/'checks/report.json');check(cr['status']=='passed','final checks status')
 for c in cr['commands']:
  check(c['exit']==0,'final tooling check '+c['label'])
  for n in ['stdout','stderr']:verify(S/'checks'/(c['label']+'.'+n),c[n+'_sha256'])
 unit=(S/'checks/pgo-unit.stderr').read_text();check('Ran 13 tests'in unit and '\nOK\n'in unit,'13 unit tests exact')
 with tarfile.open(H/'evidence.tar.gz') as ar:
  def archived(n):
   data=ar.extractfile(n).read();files['archive:'+n]=hashlib.sha256(data).hexdigest();return data
  def aj(n):return json.loads(archived(n))
  failed=aj('failed-pgo/manifest.json');check(failed['status']=='incomplete' and 'warning'in failed['failure'],'initial PGO warning failure recorded')
  check([x['label']for x in failed['commands']][-1]=='build-use' and all(x['returncode']==0 for x in failed['commands']),'both initial compiles succeeded; no replay invoked')
  check(len(aj('failed-pgo/generate-training.json')['rows'])==288,'initial training288 retained')
  check('warning' in archived('failed-pgo/08-build-use.log').decode() and 'allocator-api2'in archived('failed-pgo/08-build-use.log').decode(),'raw dependency warning retained')
  failpbs=aj('phase2/pbs/report.json');check(failpbs['exit']==1 and failpbs['status']=='incomplete' and failpbs['env_overrides']['RUSTC']=='','initial empty RUSTC controller failure')
  check('No such file or directory'in archived('phase2/pbs/stderr').decode(),'empty compiler diagnostic retained')
  for name,pic in [('pbs-02-empty-encoded-unhardened',False),('pbs-03-clean-unhardened',True),('pbs-05-hardened-fresh',True)]:
   rr=workspace(compiles(archived(name+'/build.log').decode()),name)
   check(all(('relocation-model=pic'in x['codegen_options'])==pic for x in rr),'PBS attempt actual flags '+name)
  cached=aj('phase3/pbs/report.json');check(cached['exit']==0 and cached['status']=='incomplete','cache attempt postprocess rejection retained')
  check(not compiles(archived('pbs-04-hardened-cache-reuse/build.log').decode()),'cached attempt has no new compilers')
 (O/'compiler-reconstruction.json').write_text(json.dumps({'pgo':parsed,'pbs':ps},indent=2)+'\n')
 report={'status':'passed','findings':[],'checks':len(checks),'files':len(files),'pgo':{'manifest_sha256':sha(P/'manifest.json'),'generate_parses':288,'use_parses':288,'rows_exact':True,'fresh_workspace_compiles_per_phase':3,'effective_lto':'thin','llvm':'22.1.8','source_files':len(m['source_sha256']),'tool_files':len(m['script_sha256']),'generated_fixtures':12},'pbs':{'manifest_sha256':sha(B/'manifest.json'),'fresh_compiles':3,'empty_encoded_flags':True,'explicit_pic_unwind':True,'default_ohm':True,'weak_tls_symbols':tls,'native_libraries':native,'nonempty_rejected_before_output':True},'limitations':['Saved-data audit only: no builds, tests, trainer, parser, profiler or timings executed by reviewer.','PGO576 generated parses establish tool/replay scope only; no throughput/full compatibility transfer from a55.','PBS smoke uses default Ohm; normal matched a55 uses defaults disabled. Stable CI and full PBS distribution are not claimed here.','Full subprocess environment is inherited but only an allowlist is recorded; origin assertions are recorded trainer evidence, not a reviewer parser rerun.','ELF weak TLS result reconstructed from saved symbol output; no new linker test.','All initial warning/controller/flag/freshness failures remain distinct from final successes.'], 'source_review':'/tmp/oriole-c-library-command-independent-review/final-review.json','package_review':'/tmp/oriole-thinlto-docs-package-independent-review/review.json','script_sha256':sha(__file__)}
 (O/'input-hashes.json').write_text(json.dumps(files,indent=2)+'\n');(O/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');(O/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','checks':len(checks),'files':len(files),'review_sha256':sha(O/'review.json')}))
except BaseException as e:
 (O/'failed-attempt.json').write_text(json.dumps({'exception':repr(e),'checks_completed':len(checks),'checks':checks,'files':files},indent=2)+'\n');raise
