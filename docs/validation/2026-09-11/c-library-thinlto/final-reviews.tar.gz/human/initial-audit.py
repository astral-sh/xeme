"""Saved human-document arithmetic, source receipt and local-link audit."""
from pathlib import Path
from collections import Counter
from urllib.parse import urlsplit, unquote
import hashlib
import json
import math
import os
import re
import statistics
import subprocess

assert os.sched_getaffinity(0) == {7}
ROOT = Path('/home/dev-user/code/oss/oriole-c-library-lto')
DOC = ROOT / 'docs/validation/2026-09-11/c-library-thinlto'
OUT = Path(__file__).resolve().parent
BASE = '1cb326c6dcd3aaebf37e555826b515a0b53b6641'
HEAD = 'e3666076eb444aea2c84c93fda9d6aaeb1bbdecb'
tracked, checks, git_commands = {}, [], []
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path):
    path = Path(path)
    raw = path.read_bytes()
    assert tracked.setdefault(str(path), sha(raw)) == sha(raw), ('changed during audit', str(path))
    return raw
def h(path): return sha(read(path))
def j(path): return json.loads(read(path))
def ck(value, label):
    assert value, label
    checks.append(label)
def close(a, b): return math.isclose(a, b, rel_tol=1e-13, abs_tol=1e-15)
def put(name, value): (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
def git(*args):
    command = ['git', '-C', str(ROOT), *args]
    result = subprocess.run(command, capture_output=True, timeout=30)
    git_commands.append({'command': command, 'exit': result.returncode, 'stdout_sha256': sha(result.stdout), 'stderr': result.stderr.decode()})
    ck(result.returncode == 0, 'read-only Git command ' + ' '.join(args))
    return result.stdout

names = ['README.md', 'docs/review.md', 'docs/compatibility.md', 'crates/oriole_expat/README.md',
         'benchmarks/results/2026-09-11/c-library-thinlto/README.md',
         'docs/validation/2026-09-11/c-library-thinlto/README.md',
         'docs/validation/2026-09-11/c-library-thinlto/command-validation.md']
docs = {name: read(ROOT / name).decode() for name in names}
for name in names:
    dest = OUT / 'observed-docs' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(docs[name])
main, report, command_doc, benchmark = (docs[n] for n in [names[0], names[5], names[6], names[4]])
base_main = git('show', BASE + ':README.md').decode()
(OUT / 'base-README.md').write_text(base_main)
ck(git('rev-parse', 'HEAD').decode().strip() == HEAD, 'explicit command commit')
ck(git('rev-parse', HEAD + '^').decode().strip() == BASE, 'explicit base1cb parent')
headings = lambda text: re.findall(r'^#{1,6} .+$', text, re.M)
ck(headings(main) == headings(base_main) == ['# Oriole', '## Highlights', '## Installation', '## Getting started', '## License'], 'top README heading hierarchy exact base')
warning = lambda text: '\n'.join(line for line in text.splitlines() if line.startswith('>'))
ck(warning(main) == warning(base_main) and 'not yet a' in warning(main) and 'production-ready replacement' in warning(main), 'top warning byte exact')
ck(main.split('## License\n', 1)[1] == base_main.split('## License\n', 1)[1], 'top complete license text byte exact')
ck(main.split('| Project XML |', 1)[0] == base_main.split('| Project XML |', 1)[0], 'top introduction and highlights unchanged')
ck(main.split('Optional [profile-guided builds]', 1)[1] == base_main.split('Optional [profile-guided builds]', 1)[1], 'top remainder after benchmark paragraphs unchanged')
for name in ['docs/review.md', 'docs/compatibility.md']:
    ck(read(ROOT / name) == git('show', BASE + ':' + name), name + ' byte exact base')

native_summary, python_summary = j(DOC / 'native-summary.json'), j(DOC / 'python-summary.json')
native_review, python_review = j(DOC / 'native-review.json'), j(DOC / 'python-review.json')
build_review, cpython_review = j(DOC / 'build-review.json'), j(DOC / 'cpython-review.json')
gates = j(DOC / 'gates.json')
package_review = j('/tmp/oriole-thinlto-docs-package-independent-review/review.json')
ck(h('/tmp/oriole-thinlto-docs-package-independent-review/review.json') == 'b849633583f9ab08cf0ba7d620e1f28dd06115090e1d3dc9432cdd767fea93d1', 'pinned prior package audit')
for name, digest in [('build-review.json','e9b3e851d3bce876591d5fdf2d932d3123a1aa1763e4115838e61c753d7efddd'), ('native-review.json','150dfc09c8c1fbce30db5364d4659431ec929a3af1e323c6f0fff9a7cc177699'), ('python-review.json','ab405c08444a293805cd7317a2223cc1a28bb061d22b27d54c3bde8e5e7e44bf'), ('cpython-review.json','49fa4c3c887ca810f51ed0a6ee104975300b3eaef9a4e683260f3ef51a163d9d')]:
    ck(h(DOC / name) == digest, 'pinned independent receipt ' + name)

# Recompute timing medians and ratios from saved sample values only.
native_path = Path('/tmp/oriole-thinlto-production-timing-study/native-screen/results.json')
native = j(native_path)
python_path = Path('/tmp/oriole-thinlto-production-python-study/screen/results.json')
python = j(python_path)
ck(native['status'] == python['status'] == 'passed' and native['affinity'] == python['affinity'] == [0], 'successful pinned elapsed records')
ratios = [('candidate_over_published','candidate','published'), ('candidate_over_expat','candidate','expat'), ('published_over_expat','published','expat')]
native_counts = Counter()
for cohort in native['rows']:
    ck(len(cohort['processes']) == 3 and {p['engine'] for p in cohort['processes']} == {'candidate','published','expat'}, 'complete native cohort')
    for worker in cohort['processes']:
        samples = json.loads(worker['stdout'])['samples']
        measured = [s['seconds'] for s in samples if not s['warmup']]
        ck(sum(bool(s['warmup']) for s in samples) == 1 and len(measured) == cohort['condition']['iterations'], 'native fixed warmup and measured count')
        ck(statistics.median(measured) == worker['median_seconds'], 'native worker median from raw samples')
        native_counts.update(workers=1, warmups=1, measured=len(measured))
for row in native['summary']:
    cohorts = sorted((c for c in native['rows'] if c['condition'] == row['condition']), key=lambda c:c['pair'])
    ck([c['pair'] for c in cohorts] == list(range(7)), 'seven native paired rounds')
    for key, left, right in ratios:
        values = []
        for c in cohorts:
            medians = {w['engine']:w['median_seconds'] for w in c['processes']}
            values.append(medians[left] / medians[right])
        ck(values == row['paired_ratios'][key] and statistics.median(values) == row['median_ratios'][key], 'native exact paired ratio family ' + key)
python_counts = Counter()
for worker in python['rows']:
    samples = worker['samples']
    measured = [s['seconds'] for s in samples if not s['warmup']]
    ck(sum(bool(s['warmup']) for s in samples) == 1 and statistics.median(measured) == worker['median_seconds'], 'Python warmup and raw worker median')
    python_counts.update(workers=1, warmups=1, measured=len(measured))
for row in python['summary']:
    c = row['condition']; key = f"{c['name']}/{c['chunk']}/{c['mode']}"
    selected = [w for w in python['rows'] if w['key'] == key]
    ck(len(selected) == 21, '21 Python workers per condition')
    for engine in ['candidate','published','expat']:
        workers = sorted((w for w in selected if w['engine'] == engine), key=lambda w:w['pair'])
        ck([w['pair'] for w in workers] == list(range(7)), 'seven Python paired rounds')
        ck([w['median_seconds'] for w in workers] == row['process_pair_medians_seconds'][engine], 'Python condition process medians')
        ck(all(len([s for s in w['samples'] if not s['warmup']]) == c['iterations'] for w in workers), 'Python fixed measured counts')
    for key, left, right in ratios:
        values = [a/b for a,b in zip(row['process_pair_medians_seconds'][left], row['process_pair_medians_seconds'][right], strict=True)]
        ck(values == row['paired_ratios'][key] and statistics.median(values) == row['median_ratios'][key], 'Python exact paired ratio family ' + key)
ck(dict(native_counts) == {'workers':588,'warmups':588,'measured':105420} and len(native['rows']) == 196 and len(native['summary']) == 28, 'native document counts')
ck(dict(python_counts) == {'workers':504,'warmups':504,'measured':25788} and len(python['summary']) == 24, 'Python document counts')
ck(native_review['counts']['preflight_workers'] == 84 and python_review['preflights'] == 72 and python_review['cohorts'] == 168, 'preflight/cohort counts pinned prior audits')
for suite, aggregates, selectors in [(native,native_summary,{'real':lambda c:not c['name'].startswith('generated-'),'generated':lambda c:c['name'].startswith('generated-')}), (python,python_summary,{'all':lambda c:True,'elementtree':lambda c:c['mode']=='elementtree','pyexpat-events':lambda c:c['mode']=='pyexpat-events'})]:
    for group, select in selectors.items():
        rows = [r for r in suite['summary'] if select(r['condition'])]
        ck(len(rows) == aggregates['groups'][group]['conditions'], 'group conditions ' + group)
        for key, _, _ in ratios:
            values = [r['median_ratios'][key] for r in rows]
            saved = aggregates['groups'][group]['ratios'][key]
            ck(close(statistics.geometric_mean(values),saved['geomean']) and sum(v<1 for v in values)==saved['below_one'], 'all aggregate ratios ' + group + '/' + key)
    regressions = [{'condition':r['condition'],'ratio':r['median_ratios']['candidate_over_published']} for r in suite['summary'] if r['median_ratios']['candidate_over_published']>1]
    ck(regressions == aggregates['regressions'], 'all regressions retained')

labels = {'vulkan':'Vulkan registry','wayland':'Wayland protocol','maven':'Maven POM','batik':'Batik SVG','gtk':'GTK UI','docbook':'DocBook XSL'}
table = []
for name,label in labels.items():
    row = next(r for r in native['summary'] if r['condition']['name']==name and r['condition']['chunk']==4096 and not r['condition']['namespaces'])
    cohorts = [c for c in native['rows'] if c['condition']==row['condition']]
    times = {e:statistics.median(next(w['median_seconds'] for w in c['processes'] if w['engine']==e) for c in cohorts)*1000 for e in ['candidate','expat']}
    table.append(f"| {label} | {times['candidate']:.3f} ms | {times['expat']:.3f} ms | {row['median_ratios']['candidate_over_expat']:.2f}× |")
for text in [main,report,benchmark]:
    ck(all(line in text for line in table), 'all six display rows exact saved arithmetic')
ck(read(DOC/'table.md').decode()=='\n'.join(table)+'\n','standalone display table exact')
for group,label in [('real','Project XML'),('generated','Generated controls')]:
    g=native_summary['groups'][group]; a,b=(g['ratios'][k] for k in ['candidate_over_published','candidate_over_expat'])
    ck(f"| {label} | {g['conditions']} | {a['geomean']:.6f} | {b['geomean']:.6f} | {a['below_one']} | {b['below_one']} |" in report,'native aggregate displayed '+group)
for group,label in [('elementtree','ElementTree'),('pyexpat-events','pyexpat events'),('all','Combined')]:
    g=python_summary['groups'][group];a,b=(g['ratios'][k] for k in ['candidate_over_published','candidate_over_expat'])
    ck(f"| {label} | {g['conditions']} | {a['geomean']:.6f} | {b['geomean']:.6f} | {a['below_one']} | {b['below_one']} |" in report,'Python aggregate displayed '+group)
for text in [main,report,benchmark]:
    for summary,group in [(native_summary,'real'),(python_summary,'all')]:
        g=summary['groups'][group]['ratios']
        ck(f"{(1-g['candidate_over_published']['geomean'])*100:.1f}%" in text and f"{g['candidate_over_expat']['geomean']:.2f}×" in text,'rounded headline matches elapsed ratio')
native_wins=[r for r in native['summary'] if r['median_ratios']['candidate_over_expat']<1]
python_wins=[r for r in python['summary'] if r['median_ratios']['candidate_over_expat']<1]
ck(len(native_wins)==1 and native_wins[0]['condition']['name']=='batik' and native_wins[0]['condition']['chunk']==4096 and not native_wins[0]['condition']['namespaces'],'single native Expat win exact condition')
ck(len(python_wins)==2 and all(r['condition']['name']=='wayland' and r['condition']['mode']=='pyexpat-events' for r in python_wins),'two Python Expat wins exact conditions')
win=native_wins[0]['median_ratios']['candidate_over_expat']
ck(f'{win:.6f}×' in report and f'{(1-win)*100:.2f}%' in main and f'{(1-win)*100:.2f}%' in benchmark,'Batik win size exactly rounded')
real_regressions=[r['ratio'] for r in native_summary['regressions'] if not r['condition']['name'].startswith('generated-')]
ck(len(real_regressions)==6 and f'{(min(real_regressions)-1)*100:.3f}–{(max(real_regressions)-1)*100:.3f}%' in report,'six native regressions exact range')
for r in python_summary['regressions']:
    ck(f"+{(r['ratio']-1)*100:.3f}%" in report,'Python regression rounded '+r['condition']['name'])
ck('0.831%' in report and close((native_summary['regressions'][4]['ratio']-1)*100,0.8310852102334731),'generated regression retained')

# Check compatibility statements against prior saved-data receipts, never executions.
ck((gates['api']['passed'],gates['api']['failed'])==(4347,393) and gates['api']['raw_exit']==1,'canonical nonzero outcomes')
ck(gates['api']['bounds']=={'per_test_seconds':3,'per_test_address_space_bytes':1073741824,'per_test_rss_limit_bytes':805306368,'total_timeout_seconds':240},'canonical original bounds')
for text in [main,report,docs['docs/compatibility.md'],docs['docs/review.md']]:
    ck('4,347' in text and '393' in text,'remaining canonical failures visible')
for key,value in [('strict_baseline_traces',3318),('custom_alias_baseline_comparisons',36456),('malformed_baseline_comparisons',2392)]:ck(gates[key]==value and f'{value:,}' in report,'saved baseline comparison scope '+key)
ck(gates['native']['consumers']==6 and gates['native']['allocation_scenarios_per_linkage']==327,'six native runs with327 allocation scenarios per linkage')
ck(gates['publication']['logical_cases']==1304 and gates['publication']['parser_executions']==3912 and gates['end_lifecycle']['logical_cases']==38 and gates['end_oom']['scenarios']==6,'publication and supplemental counts')
for linkage,row in cpython_review['cpython'].items():
    ck(row['methods']==802 and row['reported_skips']==14 and row['expected_failures']==3 and row['failures']==['test.test_pyexpat.BufferTextTest.test1','test.test_sax.CDATAHandlerTest.test_handlers'],'strict CPython parity '+linkage)
for phrase in ['802 tests','14 reported skips','three expected failures','Raw exits remain nonzero','No fragmentation waiver','Rust release library is uninstrumented','leak checking is disabled']:
    ck(phrase in report,'strict/instrumentation limitation '+phrase)
workspace=j('/tmp/oriole-start-frame-integration-gate-independent-review/workspace-review.json')
ck(workspace['all_target_tests_passed']==398 and workspace['doc_tests_passed']==1 and 'Not rerun:' in gates['workspace'],'preceding normal workspace only')
ck('same-source normal build has 398' in report and 'those Rust results are not represented as tests of this C-only artifact' in report,'explicit workspace scope')
ck(build_review['source_files']==70 and build_review['fresh_workspace_compiles_each']==3 and build_review['export_names_and_kinds_equal']==73,'build/source/dynamic count claims')
for engine in ['normal','thinlto']:
    ck(build_review['static_archives'][engine]=={'objects':299,'kinds':{'ELF':299}},'static native object count '+engine)
    for row in build_review['builds'][engine]['libraries'].values():
        ck(row['sha256'] in report and f"{row['size']:,}" in report,'artifact hash and displayed byte size')
for phrase in ['shared host','No samples or conditions were removed','not whole project builds','external DTD is not loaded','not a comparison of newly tuned builds of both projects','old nonverbose logs cannot directly establish whether LTO was present']:
    ck(phrase in report,'measurement boundary '+phrase)

commands=j(DOC/'commands/summary.json')
ck(commands['pgo']['generate_parses']==commands['pgo']['optimized_replay_parses']==288 and commands['pgo']['rows_exact'] and commands['pgo']['fresh_workspace_compiles_per_phase']==3,'PGO claims match frozen command summary')
ck(commands['checks']['pgo_unit_tests']==13 and commands['pbs']['fresh_workspace_compiles']==3 and commands['pbs']['empty_encoded_flags_tested'] and commands['pbs']['nonempty_encoded_flags_exit']==2,'PBS and unit claims match frozen summary')
for phrase in ['288 training parses and 288 optimized replay parses with identical rows','Ohm defaults disabled','No new throughput or full compatibility result','Ohm\'s default experimental options','stable CI job and a complete PBS distribution have not been executed','first double-verbose PGO attempt','invalid empty `RUSTC`','cached rather than fresh compilation','Those results are not reassigned']:
    ck(phrase in command_doc,'separate actual command scope '+phrase)
ck(commands['pgo']['manifest_sha256'] in command_doc and commands['pbs']['manifest_sha256'] in command_doc,'PGO and PBS exact manifest claims')
ck('c2d677b7789717169900f4de348ebf1b22988d37d0885c629f0ca2bf6228fa58' in command_doc and 'not the `a55` measured artifact' in report,'command artifacts distinguished from measured a55')
ck(commands['archive_members']==198 and commands['nested_source_members']==243 and commands['excluded_libraries']==12 and commands['tracked_inputs']==81,'command evidence numerical scope')
assembly=j(DOC/'command-assembly.json')
ck(assembly['command_commit']==HEAD and assembly['parent']==BASE and assembly['tracked_input_files']==81 and assembly['source_manifest_sha256']==h(DOC/'commands/source.json'),'assembly current command identity')
source=j(DOC/'commands/source.json')
for name,value in source['input_sha256'].items():
    ck(h(ROOT/name)==value==sha(git('show',HEAD+':'+name)),'81 assembly Git/live/frozen byte identity '+name)

# Resolve local Markdown links and GitHub-style heading anchors; remote URLs are inventoried only.
links=[]
def anchors(text):
    found=set(re.findall(r'<a\s+(?:name|id)=[\"\']([^\"\']+)',text));counts=Counter()
    for title in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',text,re.M):
        title=re.sub(r'\[([^\]]+)\]\([^)]*\)',r'\1',title)
        base=re.sub(r'[^\w\- ]','',title.lower()).replace(' ','-')
        slug=base if counts[base]==0 else f'{base}-{counts[base]}'
        counts[base]+=1;found.add(slug)
    return found
for name,text in docs.items():
    for target in re.findall(r'(?<!!)\[[^\]]+\]\(([^)]+)\)',text):
        target=target.strip().strip('<>');parsed=urlsplit(target)
        row={'document':name,'target':target}
        if parsed.scheme or parsed.netloc:
            ck(parsed.scheme in ['https','http','mailto'],'external URL scheme '+target)
            row['scope']='external URL inventoried; not fetched'
        else:
            path=(ROOT/name).parent/unquote(parsed.path) if parsed.path else ROOT/name
            path=path.resolve();ck(path.exists(),'local link exists '+name+' -> '+target)
            if path.is_dir():
                ck((path/'README.md').is_file(),'linked directory has README '+target)
                path=path/'README.md'
            if parsed.fragment:
                ck(unquote(parsed.fragment) in anchors(read(path).decode()),'local heading anchor '+name+' -> '+target)
            elif path.suffix=='.md':read(path)
            row.update(scope='local target verified',resolved=str(path))
        links.append(row)
index_raw=read(DOC/'files.json');index=json.loads(index_raw)['files']
(OUT/'observed-files.json').write_bytes(index_raw)
unindexed=sorted({p.relative_to(DOC).as_posix() for p in DOC.rglob('*') if p.is_file() and p.name!='files.json'}-set(index))
ck(unindexed in [[],['command-assembly.json']],'only authorized new assembly receipt may await index refresh')
for name,row in index.items():ck(h(DOC/name)==row['sha256'] and len(read(DOC/name))==row['bytes'],'current listed file exact '+name)
ck(all(sha(Path(path).read_bytes())==value for path,value in tracked.items()),'all read document and evidence bytes unchanged')
put('checked-files.json',tracked);put('git-commands.json',git_commands);put('links.json',links);put('checks.json',checks)
result={'status':'independent_thinlto_human_docs_audit_passed','scope':'Read-only documentation/source-receipt and saved-sample arithmetic audit. No parser/compiler/test/timing execution or repository edits. Actual PGO/PBS saved-log validation is parent-owned.','cpu':7,'base':BASE,'head':HEAD,'documents':names,'top_readme':{'headings':headings(main),'warning_and_license_byte_exact_base':True,'changes_limited_to_benchmark_table_and_adjacent_measurement_paragraphs':True},'numerical_checks':{'native':dict(native_counts),'python':dict(python_counts),'all_process_medians_and_paired_ratios_reconstructed':True,'displayed_project_rows':table,'native_groups':native_summary['groups'],'python_groups':python_summary['groups'],'native_regressions':native_summary['regressions'],'python_regressions':python_summary['regressions'],'native_Expat_wins':len(native_wins),'python_Expat_wins':len(python_wins)},'gate_scope':{'canonical_pass':4347,'canonical_fail':393,'strict_CPython_each':{'methods':802,'failures':2,'reported_skips':14,'expected_failures':3},'workspace398_plus1_preceding_normal_only':True,'native_runs_total':6,'consumer_programs':3,'allocation_scenarios_each_linkage':327,'PGO288_plus288_distinct_from_a55_measurements':True,'PBS_default_Ohm_local_bundle_distinct_from_full_distribution':True},'assembly_sha256':h(DOC/'command-assembly.json'),'index':{'entries':len(index),'sha256':sha(index_raw),'unindexed_authorized_additions':unindexed,'prior30_index_audit_remains_historical':True},'findings':[],'clarity_note':'The sentence about six native C consumers describes six executions total: three programs under two linkages. Parent was offered a wording clarification; it does not change evidence counts.','local_links_verified':sum(l['scope']=='local target verified' for l in links),'external_URLs_inventoried':sum(l['scope'].startswith('external') for l in links),'limitations':['External URLs are inventoried syntactically; no remote reachability or mutable GitHub state is certified. Local linked paths and heading anchors are checked.','Exact build/semantic conclusions refer to pinned prior independent saved-data audits. This pass recomputes saved timing medians, paired ratios, groups, wins and regressions, but does not rerun workers.','The actual command-summary claims and failed-attempt distinction are checked against frozen receipts; detailed PGO/PBS compiler/log review is a concurrent parent task.','Any authorized later doc/index refresh needs a separate snapshot supplement; this audit never overwrites repository documentation.'],'checks':len(checks),'checked_files':len(tracked),'generator_sha256':sha(Path(__file__).read_bytes()),'checked_files_sha256':h(OUT/'checked-files.json')}
put('review.json',result)
print(json.dumps({'status':result['status'],'checks':result['checks'],'files':result['checked_files'],'review_sha256':h(OUT/'review.json')}))
