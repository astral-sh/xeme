"""Bounded controller for saved-data reads; never invokes target binaries."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

OUT = Path(__file__).resolve().parent
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
command = ['taskset', '-c', '7', PYTHON, '-I', '-S', str(OUT / 'audit.py')]
attempt = 1
while (OUT / f'attempt-{attempt:02d}.json').exists():
    attempt += 1
stem = f'attempt-{attempt:02d}'
start = time.monotonic()
record = {'command': command, 'timeout_seconds': 240, 'process_group': True,
          'scope': 'Saved file hashing and archive readback only', 'status': 'starting',
          'generator_sha256': hashlib.sha256((OUT / 'audit.py').read_bytes()).hexdigest()}
(OUT / f'{stem}.json').write_text(json.dumps(record, indent=2) + '\n')
process = None
try:
    with (OUT / f'{stem}.stdout').open('wb') as stdout, (OUT / f'{stem}.stderr').open('wb') as stderr:
        process = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = process.wait(timeout=240)
            record.update(status='passed' if code == 0 else 'failed', exit=code)
        except subprocess.TimeoutExpired:
            record.update(status='timeout')
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            record['exit'] = process.returncode
finally:
    if process is not None:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait()
    record['elapsed_seconds'] = time.monotonic() - start
    for stream in ['stdout', 'stderr']:
        path = OUT / f'{stem}.{stream}'
        if path.exists():
            record[stream + '_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
    (OUT / f'{stem}.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
raise SystemExit(0 if record['status'] == 'passed' else 1)
