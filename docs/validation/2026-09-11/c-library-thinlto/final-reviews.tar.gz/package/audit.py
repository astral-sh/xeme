"""Read-only saved documentation-package audit; never imports project code."""
from pathlib import Path, PurePosixPath
from collections import Counter
import ast
import hashlib
import io
import json
import os
import tarfile

assert os.sched_getaffinity(0) == {7}
ROOT = Path('/home/dev-user/code/oss/oriole-c-library-lto')
DOC = ROOT / 'docs/validation/2026-09-11/c-library-thinlto'
OUT = Path(__file__).resolve().parent
PACKAGE = Path('/tmp/oriole-package-c-library-thinlto.py')
MAIN_SHA = '6bc7406343e1fe9d2f66906bcb67fa81cc6d520f97867bfcf9675606fbeda0cf'
COMMAND_SHA = '20d1ad701fbfec33c9cdba3c0a037eb7d73fb88526d52369520e00526da4afe6'
tracked = {}
checks = []
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path):
    path = Path(path)
    raw = path.read_bytes()
    assert tracked.setdefault(str(path), sha(raw)) == sha(raw), ('changed during audit', str(path))
    return raw
def h(path): return sha(read(path))
def j(path): return json.loads(read(path))
def ck(value, label):
    assert value, label
    checks.append(label)
def magic(raw):
    return 'ELF' if raw.startswith(b'\x7fELF') else 'ar' if raw.startswith(b'!<arch>\n') else None
def safe(name):
    return name == PurePosixPath(name).as_posix() and not name.startswith('/') and '..' not in PurePosixPath(name).parts
def unpack(raw, label):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        for member in archive:
            ck(member.isfile() and safe(member.name) and member.name not in result, label + ' safe unique member ' + member.name)
            payload = archive.extractfile(member).read()
            ck(len(payload) == member.size, label + ' member size ' + member.name)
            result[member.name] = payload
    return result
def row_matches(raw, row):
    return sha(raw) == row['sha256'] and len(raw) == row.get('bytes', row.get('size'))
def source_archive(raw, source, key, label):
    members = unpack(raw, label)
    ck({name: sha(value) for name, value in members.items()} == source[key], label + ' exact source manifest')
    return len(members)
def put(name, value): (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

# Snapshot the index before reading any listed data, and require a stable finish.
index_raw = read(DOC / 'files.json')
(OUT / 'observed-files.json').write_bytes(index_raw)
outer = json.loads(index_raw)['files']
actual_outer = {p.relative_to(DOC).as_posix() for p in DOC.rglob('*') if p.is_file() and p.name != 'files.json'}
ck(len(outer) == 30 and set(outer) == actual_outer, 'exact 30-entry outer inventory')
for name, row in outer.items():
    ck(safe(name) and not (DOC / name).is_symlink() and row_matches(read(DOC / name), row), 'outer index ' + name)

# Reconstruct literal package selection without executing its generator.
constants = {}
for node in ast.parse(read(PACKAGE)).body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in ['DIRECTORIES', 'CONTROLLERS', 'COPIES']:
                constants[target.id] = ast.literal_eval(node.value)
ck({name: len(value) for name, value in constants.items()} == {'DIRECTORIES': 6, 'CONTROLLERS': 7, 'COPIES': 9}, 'exact main package selection constants')
selected = {}
for prefix, location in constants['DIRECTORIES'].items():
    base = Path(location)
    for path in sorted(base.rglob('*')):
        if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts:
            name = prefix + '/' + path.relative_to(base).as_posix()
            ck(name not in selected, 'unique main selection ' + name)
            selected[name] = path
for location in constants['CONTROLLERS']:
    name = 'controllers/' + Path(location).name
    ck(name not in selected, 'unique controller ' + name)
    selected[name] = Path(location)
index = j(DOC / 'archive-members.json')
included, excluded = index['members'], index['excluded_binaries']
ck(len(included) == 2474 and len(excluded) == 15, '2474 main members and 15 direct exclusions')
ck(len(selected) == 2489 and {r['path']: r['source'] for r in included + excluded} == {n: str(p) for n, p in selected.items()}, 'complete reconstructed main origin inventory')
ck(len({r['path'] for r in included + excluded}) == len(selected), 'main partitions unique and disjoint')
for partition in [included, excluded]:
    ck([r['path'] for r in partition] == sorted(r['path'] for r in partition), 'sorted main partition')
archive_raw = read(DOC / 'evidence.tar.gz')
ck(sha(archive_raw) == MAIN_SHA, 'pinned main archive')
members = unpack(archive_raw, 'main')
ck(list(members) == [r['path'] for r in included], 'exact main archive inventory and order')
for row in included:
    raw = members[row['path']]
    ck(row_matches(raw, row) and raw == read(row['source']) and magic(raw) is None, 'main member origin and direct binary policy ' + row['path'])
excluded_formats = Counter()
for row in excluded:
    raw = read(row['source'])
    ck(row_matches(raw, row) and magic(raw) is not None, 'excluded main binary ' + row['path'])
    excluded_formats[magic(raw)] += 1

# All compressed build/gate members are re-read, including source70.
nested_results = {}
for label, origin, count in [('build', '/tmp/oriole-thinlto-production-study', 47), ('gates', '/tmp/oriole-thinlto-production-gates', 217)]:
    manifest = json.loads(members[label + '/artifact-manifest.json'])
    data = unpack(members[label + '/evidence.tar.gz'], label)
    receipt = json.loads(members[label + '/readback.json'])
    ck(set(data) == set(manifest) and len(data) == count, label + ' complete nested inventory')
    ck(receipt['status'] == 'passed' and receipt['members'] == count and receipt['archive_sha256'] == sha(members[label + '/evidence.tar.gz']) and receipt['artifact_manifest_sha256'] == sha(members[label + '/artifact-manifest.json']), label + ' nested receipt identity')
    for name, raw in data.items():
        ck(row_matches(raw, manifest[name]) and raw == read(Path(origin) / name) and magic(raw) is None, label + ' nested member origin ' + name)
    source = json.loads(data['source.json'])
    ck(source_archive(data['source.tar.gz'], source, 'source_sha256', label + ' source') == 70, label + ' source70')
    for name, value in source['source_sha256'].items():
        ck(h(Path(source['worktree']) / name) == value, label + ' unchanged measured source ' + name)
    ck(data['source.json'] == read(DOC / 'source.json'), label + ' outer source copy')
    nested_results[label] = {'members': count, 'source_members': 70, 'archive_sha256': sha(members[label + '/evidence.tar.gz'])}

# Independent review records are linked byte-for-byte, including the prior gate audit.
review_manifest = json.loads(members['reviews/manifest.json'])
ck(review_manifest['status'] == 'complete', 'review handoff completion')
for name, row in review_manifest['files'].items():
    ck(row_matches(members['reviews/' + name], row), 'review outer manifest ' + name)
review_index = json.loads(members['reviews/archive-members.json'])
review_data = unpack(members['reviews/reviews.tar.gz'], 'reviews')
ck(len(review_data) == len(review_index) == 37 and set(review_data) == {r['path'] for r in review_index}, '37 independent review members')
for row in review_index:
    ck(row_matches(review_data[row['path']], row) and review_data[row['path']] == read(row['origin']), 'review origin ' + row['path'])
prior_gate = Path('/tmp/oriole-thinlto-gates-independent-review')
ck(h(prior_gate / 'review.json') == 'b092908b4357c38590c661784713fe85a228248f8e05485b6c2b46fa4e820d10', 'pinned prior original gate audit')
ck(h(prior_gate / 'handoff-review.json') == 'cbd5e444ca12efd128302060032098190a1ddfae86327498ed1d3e0851f2282d', 'pinned prior handoff gate audit')
gate_receipt = j(prior_gate / 'handoff-review.json')
ck(gate_receipt['handoff']['archive_sha256'] == nested_results['gates']['archive_sha256'] == 'd881f24363afcbe987e322a9dddd13e2378fdc2799e64188d4409a7bfa61d80b', 'packaged gate archive is the previously audited archive')
ck(gate_receipt['handoff']['manifest_sha256'] == sha(members['gates/artifact-manifest.json']) == '91392ef2cd90414c3dd46b3bad796ce1d9c455735fb57b9f0f9b4d979042214f', 'packaged gate manifest is previously audited manifest')

copies = []
for name, origin in constants['COPIES'].items():
    ck(read(DOC / name) == read(origin), 'outer exact copied receipt ' + name)
    copies.append({'path': name, 'origin': origin, 'sha256': h(DOC / name)})
summary, gates, measured = j(DOC / 'summary.json'), j(DOC / 'gates.json'), j(DOC / 'source.json')
ck(summary['runtime_commit'] == '50c20c1e73eeaacabb9df90e413f502361fb45b3' and summary['source_files'] == len(measured['source_sha256']) == 70, 'measured source identity')
ck(summary['libraries'] == gates['libraries'] == gate_receipt['libraries'], 'all matched normal and ThinLTO library identities')
for engine in ['normal', 'thinlto']:
    for name, value in summary['libraries'][engine].items():
        ck(h(Path('/tmp/oriole-thinlto-production-study') / engine / name) == value, 'retained actual library ' + engine + '/' + name)
source_delta = [name for name, value in measured['source_sha256'].items() if h(ROOT / name) != value]
ck(source_delta == summary['current_documentation_only_source_delta'] == ['crates/oriole_expat/README.md'], 'only current measured-source documentation delta')
ck(summary['native'] == j(DOC / 'native-summary.json') and summary['python'] == j(DOC / 'python-summary.json'), 'aggregate includes exact complete timing summaries')
ck(summary['api'] == gates['api'] and gates['status'] == 'correctness_parity_gates_passed' and gates['api']['all4740rows_exact'] and gates['api']['passed'] == 4347 and gates['api']['failed'] == 393, 'original canonical scope retained')
ck(gates['api']['bounds'] == {'per_test_seconds': 3, 'per_test_address_space_bytes': 1073741824, 'per_test_rss_limit_bytes': 805306368, 'total_timeout_seconds': 240}, 'original canonical bounds retained')
ck(summary['archive'] == {'sha256': MAIN_SHA, 'members': 2474, 'direct_binary_exclusions': 15, 'bytes': len(archive_raw), 'raw_bytes': sum(r['bytes'] for r in included), 'member_and_origin_readback': True}, 'main summary archive metadata reconstructed')

# Commands are a separate 12-file handoff, not a reassignment of a55 timings.
COMMANDS = DOC / 'commands'
COMMAND_ORIGIN = Path('/tmp/oriole-c-library-lto-command-handoff')
command_files = {p.relative_to(COMMAND_ORIGIN).as_posix() for p in COMMAND_ORIGIN.rglob('*') if p.is_file()}
ck(len(command_files) == 12 and command_files == {p.relative_to(COMMANDS).as_posix() for p in COMMANDS.rglob('*') if p.is_file()}, '12 exact command handoff files')
for name in command_files:
    ck(read(COMMANDS / name) == read(COMMAND_ORIGIN / name), 'command copied file ' + name)
for name, row in j(COMMANDS / 'artifact-manifest.json').items():
    ck(row_matches(read(COMMANDS / name), row), 'command outer manifest ' + name)
ck(set(j(COMMANDS / 'artifact-manifest.json')) == command_files - {'artifact-manifest.json'}, 'command outer manifest complete')

# Resolve only the fixed path constants from the packaging AST.
environment = {}
def fixed_value(node):
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.Name): return environment[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Path' and len(node.args) == 1:
        return Path(fixed_value(node.args[0]))
    if isinstance(node, ast.Dict): return {fixed_value(k): fixed_value(v) for k, v in zip(node.keys, node.values, strict=True)}
    raise AssertionError(ast.dump(node))
for node in ast.parse(read(COMMANDS / 'package.py')).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id in ['final', 'phase2', 'phase1', 'roots']:
        environment[node.targets[0].id] = fixed_value(node.value)
ck(len(environment['roots']) == 11, '11 command attempt/source roots')
command_selection, command_excluded = {}, {}
for prefix, root in environment['roots'].items():
    for path in sorted(root.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            name = prefix + '/' + path.relative_to(root).as_posix()
            target = command_excluded if path.suffix in ('.so', '.a') else command_selection
            ck(name not in target and not path.is_symlink(), 'unique regular command selection ' + name)
            target[name] = path
command_index = j(COMMANDS / 'archive-members.json')
command_excluded_index = j(COMMANDS / 'excluded-binaries.json')
ck(set(command_index) == set(command_selection) and len(command_index) == 198 and set(command_excluded_index) == set(command_excluded) and len(command_excluded_index) == 12, '198 command members12 suffix exclusions reconstructed')
command_archive = read(COMMANDS / 'evidence.tar.gz')
ck(sha(command_archive) == COMMAND_SHA, 'pinned command archive')
command_data = unpack(command_archive, 'commands')
ck(set(command_data) == set(command_index), 'command archive complete')
for name, raw in command_data.items():
    ck(row_matches(raw, command_index[name]) and raw == read(command_selection[name]) and magic(raw) is None, 'command archived origin ' + name)
command_excluded_formats = Counter()
for name, row in command_excluded_index.items():
    raw = read(command_excluded[name])
    ck(row_matches(raw, row) and row['source'] == str(command_excluded[name]) and magic(raw) is not None, 'command excluded binary ' + name)
    command_excluded_formats[magic(raw)] += 1
nested_index = j(COMMANDS / 'nested-source-members.json')
ck(set(nested_index) == {name for name in command_data if name.endswith('source.tar.gz')}, 'all command nested sources indexed')
nested_command_count = 0
for name, expected in nested_index.items():
    raw_members = unpack(command_data[name], name)
    ck(set(raw_members) == set(expected) and all(row_matches(raw, expected[n]) for n, raw in raw_members.items()), name + ' nested hash/size index')
    frozen_source = json.loads(command_data[name.removesuffix('source.tar.gz') + 'source.json'])
    ck({n: sha(raw) for n, raw in raw_members.items()} == frozen_source['input_sha256'], name + ' phase source manifest')
    nested_command_count += len(raw_members)
ck(nested_command_count == 243, '243 nested command source members')
command_source = j(COMMANDS / 'source.json')
ck(source_archive(read(COMMANDS / 'source.tar.gz'), command_source, 'input_sha256', 'outer final command source') == 81, '81 final command tracked inputs')
for name, value in command_source['input_sha256'].items():
    ck(h(ROOT / name) == value, 'current final command input ' + name)
ck(len(command_source['source_sha256']) == 70 and {n: command_source['input_sha256'][n] for n in command_source['source_sha256']} == command_source['source_sha256'], 'command81 contains exact source70')
command_summary = j(COMMANDS / 'summary.json')
ck(command_summary['status'] == 'passed_with_initial_attempts_retained' and command_summary['archive_sha256'] == COMMAND_SHA and command_summary['archive_members'] == 198 and command_summary['nested_source_members'] == 243 and command_summary['excluded_libraries'] == 12, 'command summary archive metadata')
ck(command_summary['source_manifest_sha256'] == h(COMMANDS / 'source.json') and command_summary['patch_sha256'] == h(COMMANDS / 'candidate.patch'), 'command source and patch copied identities')
ck(set(environment['roots']) <= {name.split('/')[0] for name in command_data}, 'all successful and failed command attempts remain represented')
for name in ['oriole-write-c-library-thinlto-docs.py', 'oriole-attach-c-library-command-validation.py']:
    ck(read(DOC / name) == read(Path('/tmp') / name), 'outer generator copy ' + name)

ck(read(DOC / 'files.json') == index_raw, 'outer index stable during review')
ck(all(sha(Path(path).read_bytes()) == value for path, value in tracked.items()), 'all observed package/source/origin files unchanged')
put('checked-files.json', tracked)
report = {
    'status': 'independent_thinlto_docs_package_audit_passed',
    'scope': 'Saved package/index/selection/origin/source/copy review only. No project generator, parser, compiler, test, benchmark, or library execution; no repository changes.',
    'cpu': 7,
    'outer_index': {'entries': 30, 'sha256': sha(index_raw), 'snapshot': 'observed-files.json', 'readme_sha256': h(DOC / 'README.md')},
    'main_archive': {'sha256': MAIN_SHA, 'members': 2474, 'bytes': len(archive_raw), 'raw_bytes': sum(r['bytes'] for r in included), 'all_origins_exact': True, 'direct_excluded_binaries': 15, 'excluded_formats': dict(excluded_formats), 'selection_directories': 6, 'selection_controllers': 7},
    'nested_measured_evidence': nested_results,
    'nested_independent_reviews': {'members': 37, 'all_origins_exact': True, 'archive_sha256': sha(members['reviews/reviews.tar.gz']), 'prior_gate_review_sha256': h(prior_gate / 'review.json'), 'prior_gate_handoff_review_sha256': h(prior_gate / 'handoff-review.json')},
    'copied_receipts': copies,
    'measured_source': {'files': 70, 'manifest_sha256': h(DOC / 'source.json'), 'current_documentation_only_delta': source_delta, 'libraries': summary['libraries']},
    'commands': {'outer_files': 12, 'artifact_manifest_sha256': h(COMMANDS / 'artifact-manifest.json'), 'archive_sha256': COMMAND_SHA, 'members': 198, 'nested_source_members': 243, 'outer_source_members': 81, 'direct_excluded_libraries': 12, 'excluded_formats': dict(command_excluded_formats), 'all_origins_exact': True, 'roots': {n: str(p) for n, p in environment['roots'].items()}, 'final_source_manifest_sha256': h(COMMANDS / 'source.json'), 'retained_attempts': command_summary['retained_attempts']},
    'limits': [
        'Archive exclusions are direct ELF/ar magic for the matched main archive and .so/.a suffixes for the separate command archive. The retained source archives, raw profile data, logs and other nested evidence remain in scope; this is not a general binary-free-package claim.',
        'The pinned prior gate review supplies the saved semantic audit: 4740 canonical rows retain 4347 passes and393 failures; custom-alias successful raw pairs are absent. Reference position differences and the separate originally failed OOM helper remain recorded.',
        'No normal-workspace test result is transferred to the C-only ThinLTO artifact. C-only ASan/UBSan instrumentation does not instrument the Rust release library.',
        'The matched normal9815/a55 measurements and separate actual PGO/PBS command artifacts remain distinct. Parent owns human claims, arithmetic interpretation, links and actual command-outcome/compiler review.',
        'All measured build/gate source70 archive bytes and live measured-worktree bytes match. Current production command inputs contain only the recorded README delta within that measured source70; command-layer changes outside source70 are captured in the separate81-input source snapshot.',
        'The author of the reused End lifecycle helper is this reviewer; package-byte validation does not claim independent helper-design certification.'
    ],
    'checks': len(checks), 'checked_files': len(tracked),
    'generator_sha256': sha(Path(__file__).read_bytes()), 'checked_files_sha256': h(OUT / 'checked-files.json')
}
put('review.json', report)
print(json.dumps({'status': report['status'], 'checks': report['checks'], 'checked_files': report['checked_files'], 'review_sha256': h(OUT / 'review.json')}))
