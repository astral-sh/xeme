"""Review the final bounded C-command follow-up without building or training."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

OUT = Path(__file__).resolve().parent
FINAL = Path('/tmp/oriole-c-library-lto-final-implementation')
sha = lambda data: hashlib.sha256(data).hexdigest()
source_data = (FINAL/'source.json').read_bytes()
source = json.loads(source_data)
patch = (FINAL/'candidate.patch').read_bytes()
archive_data = (FINAL/'source.tar.gz').read_bytes()
files = {}
with tarfile.open(fileobj=io.BytesIO(archive_data), mode='r:gz') as archive:
    for member in archive.getmembers():
        assert member.isfile() and member.name not in files
        files[member.name] = archive.extractfile(member).read()
expected = source['input_sha256']
assert {name:sha(data) for name,data in files.items()} == expected
assert all(sha((Path(source['worktree'])/name).read_bytes()) == digest for name,digest in expected.items())
original = json.loads((OUT/'initial-source.json').read_bytes())
delta = [name for name,digest in expected.items() if digest != original['input_sha256'][name]]
assert set(delta) == {'.github/workflows/ci.yml', 'integration/python-build-standalone/prepare.py', 'tools/pgo/README.md', 'tools/pgo/build.py', 'tools/pgo/test_build.py'}
for name in delta:
    target = OUT/'final-source'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(files[name])
assert not any(name.endswith('.rs') or name.endswith('Cargo.toml') or name == 'Cargo.lock' or name.startswith('include/') for name in delta)
build = files['tools/pgo/build.py'].decode()
tests = files['tools/pgo/test_build.py'].decode()
ci = files['.github/workflows/ci.yml'].decode()
pbs = files['integration/python-build-standalone/prepare.py'].decode()
assert 'value.startswith("-C")' in build and 'and "C" in value' in build
assert 'config = tomllib.loads(value.removeprefix("--config="))' in build
assert 'if not config or "include" in config:' in build
assert 'if not value.startswith("--config="):' in build
for example in ['-C/other/workspace','-vC/other/workspace','--config=/untracked/config.toml','--config=/untracked/name=value.toml',"--config=include='/untracked/config.toml'"]:
    assert example in tests
assert build.count('"--verbose",') == 1 and pbs.count('"--verbose",') == 1
assert 'components: rust-docs' in ci
assert 'python3 integration/python-build-standalone/prepare.py --output "$RUNNER_TEMP/oriole-pbs-bundle"' in ci
assert '--crate-type cdylib,staticlib' in ci
for filename, data in [('final-source.json',source_data),('final.patch',patch)]:
    (OUT/filename).write_bytes(data)
report = {
    'status':'final_bounded_command_source_review_no_blocker',
    'scope':'Source and exact frozen snapshot only; no compiler, parser, PGO training, PBS fixture or distribution run. Actual build/gate evidence remains separately scoped.',
    'source_manifest_sha256':sha(source_data), 'patch_sha256':sha(patch), 'source_archive_sha256':sha(archive_data),
    'archive_entries':len(files), 'source_and_live_hashes_match':True,
    'delta_from_reviewed_initial':delta,
    'resolved_findings':[
        'Direct and grouped short-option forms containing Cargo -C are rejected, preserving --source as the workspace selector.',
        'Config passthrough requires attached TOML parsed inline settings, rejects file paths (including names containing equals) and include keys; accepted config bytes are the recorded argument itself.',
    ],
    'additional_changes':[
        'PGO and PBS now use one verbose option: actual compiler commands remain logged without double-verbose registry lint promotion. This preserves the strict warning gate; no filtered warning exception was added.',
        'PBS fixture CI installs pinned rust-toolchain action with stable and rust-docs, then runs actual prepare into a fresh runner-temp bundle after the unchanged fixture validation. This proves a static-bundle build when that job runs, not a Python distribution or downstream PBS consumer pass.',
    ],
    'preserved':[
        'Nine-file original scope; Rust sources, public header, Cargo manifest and lockfile unchanged.',
        'Cargo global options remain before rustc subcommand and separate from selected compiler/profiler arguments.',
        'C-only crate types belong to Cargo, before the PBS --print=native-static-libs compiler separator.',
        'Original source/config/tool/profile hashes, direct compiler selection, callback-origin and generated replay gates remain active.',
        'Optional PGO does not replace default/PBS build; no new runtime, resource, compatibility waiver or unmeasured performance claim.',
        'Initial nine-file review, both findings and earlier failed PGO warning-gate evidence remain separate rather than relabeled.',
    ],
    'findings':[],
    'initial_review_sha256':sha((OUT/'initial-review.json').read_bytes()),
    'generator_sha256':sha(Path(__file__).read_bytes()),
}
(OUT/'final-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'path':str(OUT/'final-review.json'),'sha256':sha((OUT/'final-review.json').read_bytes())}))
