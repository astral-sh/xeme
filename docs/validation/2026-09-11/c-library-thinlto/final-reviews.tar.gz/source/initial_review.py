"""Reconstruct and review the initial nine-file C-library build command layer."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

OUT = Path(__file__).resolve().parent
STUDY = Path('/tmp/oriole-c-library-lto-implementation')
REPO = Path('/home/dev-user/code/oss/oriole-c-library-lto')
sha = lambda data: hashlib.sha256(data).hexdigest()
patch = (STUDY/'candidate.patch').read_bytes()
assert sha(patch) == '6a9fc01005e4217faa66b23c7a54c3d8a3a49fb5f442bac992d5b6d4a4e0ccb4'
source_bytes = (STUDY/'source.json').read_bytes()
assert sha(source_bytes) == '3486e3f35fdc6fa6d0fa38cb095b47f73d46de04c3e2780a0064b3365d2e6f8c'
source = json.loads(source_bytes)
(OUT/'initial.patch').write_bytes(patch)
(OUT/'initial-source.json').write_bytes(source_bytes)
names = re.findall(r'^diff --git a/(\S+) b/\1$', patch.decode(), re.M)
assert len(names) == len(set(names)) == 9
snap = OUT/'initial-source'
for name in names:
    target = snap/name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(subprocess.check_output(['git','-C',str(REPO),'show','50c20c1e73eeaacabb9df90e413f502361fb45b3:'+name]))
result = subprocess.run(['patch','--batch','--forward','-s','-p1','-i',str(OUT/'initial.patch')], cwd=snap, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(OUT/'source-reconstruction.stdout').write_bytes(result.stdout)
(OUT/'source-reconstruction.stderr').write_bytes(result.stderr)
assert result.returncode == 0
hashes = {name: sha((snap/name).read_bytes()) for name in names}
assert all(value == source['input_sha256'][name] for name,value in hashes.items())
assert not any(name.endswith('.rs') or name.endswith('Cargo.toml') or name == 'Cargo.lock' or name.startswith('include/') for name in names)
local_doc = Path('/home/dev-user/.rustup/toolchains/ohm/share/doc/rust/html/cargo/commands/cargo.html')
doc = local_doc.read_text()
assert 'Changes the current working directory before executing any specified operations.' in doc
assert 'provided as a path to an extra configuration file.' in doc
build = (snap/'tools/pgo/build.py').read_text()
assert 'cargo_selection = [*selection, *args.cargo_arg]' in build
assert '"rustc",\n                "--release",' in build
assert '"--lib",\n                "--crate-type",\n                "cdylib,staticlib",' in build
assert '[cargo, *cargo_selection, "-Vv"]' in build
assert '[rustc, *selection, "-vV"]' in build
assert 'cargo_args=args.cargo_arg' in build
assert 'value in ("-", "--", "-Z")' in build
report = {
    'status': 'initial_source_review_with_two_bounded_provenance_findings',
    'scope': 'Read-only source/command review. Initial nine-file source reconstructed from frozen Git base plus exact patch and rehashed. No compiler, parser, PGO, fixture-test or timing run.',
    'base': '50c20c1e73eeaacabb9df90e413f502361fb45b3',
    'patch_sha256': sha(patch),
    'source_manifest_sha256': sha(source_bytes),
    'source_sha256': hashes,
    'runtime_header_cargo_files_unchanged': True,
    'findings': [
        {'id':'global-directory-option', 'severity':'provenance', 'file':'tools/pgo/build.py', 'detail':'cargo_option accepts attached -C/path together with -Zunstable-options. Cargo changes its effective source/config directory before rustc, while source_files and cargo_configs still inspect run.source. A successful manifest can therefore label a different workspace as the requested source.', 'minimal_fix':'Reject -C and attached -C... options; preserve --source as the only workspace selector.'},
        {'id':'external-config-input', 'severity':'provenance', 'file':'tools/pgo/build.py', 'detail':'--cargo-arg=--config=/path can load an external config file that cargo_configs does not hash. Recording the argument path does not record its bytes or detect changes across phases.', 'minimal_fix':'Restrict this passthrough to attached inline --config=KEY=VALUE, or explicitly snapshot/check externally referenced config files. Reject bare --config.'},
    ],
    'supported_invariants': ['Cargo-level --lib/--crate-type precedes any Rust compiler separator, allowing dependency LTO preparation.', 'Both PGO phases use identical C-only target selection, with existing encoded profile flags and fresh profile paths.', 'Cargo global options are recorded and passed to Cargo version/build commands, not the selected rustc/profdata executables.', 'Wrappers remain explicitly disabled; matching compiler/LLVM/profile-origin and training replay gates remain in place.', 'PBS native-static-libs output, PIC/unwind and fixed host remain unchanged; command-only fixture checks do not prove a distribution build.', 'CI C/native/Python/normal-PGO baseline commands select the two C output types; manifest rlib remains available.', 'Historical PGO wording now states requested versus proven effective ThinLTO and preserves measurements.'],
    'separate_owner_followup': 'Root identified double verbose Cargo mode promotes registry cap-lints to warn. Owner is evaluating single verbose mode to retain effective commands and prior dependency lint policy. This review does not certify the actual PGO build or replay.',
    'local_primary_documentation': {'path':str(local_doc), 'sha256':sha(local_doc.read_bytes()), 'sections':['option-cargo--C','option-cargo---config']},
    'current_run_scope': 'The owner current run uses only -Zohm-defaults=no; neither provenance finding is exercised by that invocation. Initial failed PGO use warning gate remains owner evidence, not a runtime regression.',
    'generator_sha256': sha(Path(__file__).read_bytes()),
}
(OUT/'initial-review.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'path':str(OUT/'initial-review.json'), 'sha256':sha((OUT/'initial-review.json').read_bytes())}))
