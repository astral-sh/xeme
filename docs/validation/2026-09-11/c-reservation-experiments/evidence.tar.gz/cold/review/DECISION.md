# Cold-helper refinement rejected

The root task rejected this refinement after its original fixed normal and PGO campaigns. All raw outcomes remain retained; neither campaign was rerun.

The independently reconstructed PGO real-project ratio is **1.0300841141908912× the selected capacity control**, with 21 of 24 conditions slower. Generated conditions aggregate to **1.0224108954451103× control**, with three of four slower. PGO remains **1.4135982871682438× Expat** on the real-project cohort.

The initial reservation candidate measured 1.0152594046363603× its matched capacity control in its separate campaign. These are separate runs, not a direct paired cold-versus-initial comparison. The cold-helper results do not justify selecting the refinement or spending time on its prepared CPython campaign.

The CPython scripts remain prepared and unexecuted. The combined native review retains all 56 conditions, 1,344 workers, and 212,352 samples. Its passing status refers to raw-data verification, not performance acceptance or production readiness.
