# Cold-helper native results

PASS: both phase audits reconstructed all raw worker/sample records, callbacks, seeded order, medians and ratios. Source72 and every pinned input matched before and after reading. All56 condition rows are in `conditions.csv`; generated controls remain separate.

| Build | Real/control | Real/Expat | Adverse real/control | Generated/control |
| --- | ---: | ---: | ---: | ---: |
| normal | 0.997347993 | 1.582954551 | 7/24 | 1.007156538 |
| pgo | 1.030084114 | 1.413598287 | 21/24 | 1.022410895 |

Ratios above1 mean slower. Values aggregate the per-condition medians of seven paired ratios by geometric mean; no single result is substituted for an individual condition. These measurements quantify the cold-helper refinement against the selected capacity parent; they do not decide its compatibility or consumer gates. No full compatibility, CPython timing, hardware mechanism or production-readiness claim is made here.

The reviewer adapted the benchmark controllers and arithmetic reader but did not author the fix or collect elapsed runs. Controller authorship is disclosed; this is an independent raw-outcome reconstruction rather than an independent-author review of the controller.
