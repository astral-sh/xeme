"""Independent full native saved-data audit. No target/producer execution."""
from pathlib import Path
import argparse,ast,csv,datetime,difflib,hashlib,json,math,random,statistics,sys,os
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--released",action="store_true")
parser.add_argument("--phase",required=True,choices=["normal","pgo"])
args=parser.parse_args()
assert args.released, "Run only after parent confirms the requested campaign completed and reaped"
assert os.sched_getaffinity(0)=={6}
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={}
def pin(p):inputs[str(p)]=sha(p)
report={'status':'passed','role':'Independent saved-data audit of root-collected normal and PGO native cohorts. Reviewer adapted the initial native templates and this raw reader and independently reviewed build evidence; did not author the cold-helper runtime/collector adaptation or collect build/elapsed results. The arithmetic reader is separate from producer calculations; this is not an independent-author review of the native controller. No target executions.','reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native':{}}
for phase in [args.phase]:
 S=Path('/tmp/oriole-c-reparse-cold-native-study')/phase; T=Path('/tmp/oriole-c-reparse-pressure-native-study')/phase; D=S/'native-screen'
 old,new=T/'native_screen.py',S/'native_screen.py'
 diff=''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True),new.read_text().splitlines(keepends=True),fromfile=str(old),tofile=str(new)))
 (Path(__file__).parent/(phase+'-producer-controller.patch')).write_text(diff)
 assert (S/'run.py').read_bytes()==(T/'run.py').read_bytes()
 assert sha(S/'run.py')=='5f41a419e800e95954424e2a85d2ee988609d830db18dc85c469af801cd8aef5'
 prep=read(S/'adaptation.json');old_binding=read(T/'adaptation.json')
 assert prep['origin']==str(T) and old_binding['controller_sha256']==sha(old)
 assert prep['status']=='passed' and prep['controller_sha256']==sha(new)
 expected=old.read_text()
 for old_value,new_value in prep['replacement_pairs']:expected=expected.replace(old_value,new_value)
 assert expected==new.read_text()
 restored=new.read_text()
 for old_value,new_value in reversed(prep['replacement_pairs']):restored=restored.replace(new_value,old_value)
 assert restored==old.read_text() and ast.dump(ast.parse(restored))==ast.dump(ast.parse(old.read_text()))
 # Entire AST match after reviewed caption/root and control/candidate library substitutions already reviewed in exact diff.
 def comparable(p):
  tree=ast.parse(p.read_text());tree.body[0].value=ast.Constant('<caption>')
  for n in tree.body:
   if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name):
    name=n.targets[0].id
    if name=='root':n.value=ast.Constant('<study>')
    elif name=='libraries':n.value.values[0]=ast.Constant('<control>');n.value.values[1]=ast.Constant('<candidate>')
    elif name=='protocol':n.value.values[0]=ast.Constant('<scope>')
  return ast.dump(tree)
 assert comparable(old)==comparable(new)
 for path in [D/'protocol.json',D/'preflight.json',D/'results.json',S/'controller.json']:pin(path)
 p,f,r=map(read,[D/'protocol.json',D/'preflight.json',D/'results.json'])
 assert f['status']==r['status']=='passed' and r['affinity']==[0]
 assert f['protocol_sha256']==r['protocol_sha256']==sha(D/'protocol.json')
 assert r['preflight_sha256']==sha(D/'preflight.json')
 for x in [f,r]: assert x['hashes_before']==x['hashes_after']==p['hashes']
 for q,h in p['hashes'].items():
  assert sha(q)==h
  inputs[q]=h
 assert len(p['conditions'])==28 and p['pairs']==7 and p['seed']==2026091003
 manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
 fixtures={}
 for project in read(manifest)['projects']:
  entry=next(q for q in project['files'] if q['role']=='input');path=(manifest.parent/entry['path']).resolve();assert sha(path)==entry['sha256'];fixtures[project['name']]=str(path)
 fixtures.update({'generated-rare-declarations':'/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml','generated-entities':'/tmp/oriole-grammar-bench-plain/entities.xml'})
 iterations={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
 expected_conditions=[{'name':name,'input':path,'chunk':chunk,'namespaces':ns,'iterations':iterations[name]} for chunk in [4096,65536] for name,path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False,True])]
 assert p['conditions']==expected_conditions
 assert {c['chunk'] for c in p['conditions']}=={4096,65536}
 assert sum(c['name'].startswith('generated-') for c in p['conditions'])==4
 assert len(f['rows'])==84 and len(r['rows'])==196 and len(r['summary'])==28
 assert len(list(D.glob('worker-*.json')))==672
 ctl=read(S/'controller.json');assert ctl['status']=='passed' and ctl['controller_sha256']==sha(new) and ctl['wrapper_sha256']==sha(S/'run.py')
 for row,(stage,cpu,bound) in zip(ctl['commands'],[('preflight',5,600),('time',0,1200)],strict=True):
  assert row['phase']==stage and row['exit']==0 and row['timeout']==bound
  assert row['command']==['taskset','-c',str(cpu),'python3',str(new),stage]
  assert sha(S/(stage+'-controller.log'))==row['log_sha256']
  pin(S/(stage+'-controller.log'))
 ordinal=0; medians={}; obs={}; samples_count=0
 def worker(row,c,pair,engine,cpu,count):
  global ordinal,samples_count
  raw_path=D/f'worker-{ordinal:04d}.json';pin(raw_path);raw=read(raw_path);ordinal+=1
  assert raw=={k:v for k,v in row.items() if k not in ['observations','median_seconds']}
  assert row['condition']==c and row['pair']==pair and row['engine']==engine and row['returncode']==0 and row['stderr']==''
  assert row['command']==['taskset','-c',str(cpu),'/tmp/oriole-grammar-bench-plain/native-driver',p['libraries'][engine]['path'],c['input'],str(c['chunk']),str(count)]+(['namespaces'] if c['namespaces'] else [])
  data=json.loads(row['stdout']);s=data['samples'];samples_count+=len(s)
  assert len(s)==count+1 and [x['iteration'] for x in s]==list(range(count+1))
  assert [x['warmup'] for x in s]==[True]+[False]*count
  assert all(math.isfinite(x['seconds']) and x['seconds']>0 for x in s)
  got=sorted({(x['hash'],x['elements'],x['text_bytes']) for x in s});assert len(got)==1 and row['observations']==[list(x) for x in got]
  if json.dumps(c,sort_keys=True) in obs: assert obs[json.dumps(c,sort_keys=True)]==got
  else: obs[json.dumps(c,sort_keys=True)]=got
  assert got[0][1]>=0 and got[0][2]>=0
  med=statistics.median(x['seconds'] for x in s[1:]);assert med==row['median_seconds']
  return med
 for c in p['conditions']:
  for engine in p['libraries']:
   row=f['rows'][ordinal];worker(row,c,-1,engine,5,1)
 rng=random.Random(p['seed']);jobs=[(c,i) for c in p['conditions'] for i in range(7)];rng.shuffle(jobs)
 for row,(c,pair) in zip(r['rows'],jobs,strict=True):
  order=list(p['libraries']);rng.shuffle(order);assert row['condition']==c and row['pair']==pair and row['order']==order
  for rec,engine in zip(row['processes'],order,strict=True):medians[(json.dumps(c,sort_keys=True),pair,engine)]=worker(rec,c,pair,engine,0,c['iterations'])
 summary=[]
 for c in p['conditions']:
  pairs=[x['pair'] for x in r['rows'] if x['condition']==c]
  ratios={f'{x}_over_{y}':[medians[(json.dumps(c,sort_keys=True),i,x)]/medians[(json.dumps(c,sort_keys=True),i,y)] for i in pairs] for x,y in [('candidate','control'),('candidate','expat'),('control','expat')]}
  summary.append({'condition':c,'paired_ratios':ratios,'median_ratios':{k:statistics.median(v) for k,v in ratios.items()}})
 assert summary==r['summary'] and ordinal==672 and samples_count==106176
 groups={}
 for group in ['real','generated']:
  entries=[q for q in summary if q['condition']['name'].startswith('generated-')==(group=='generated')]
  groups[group]={'conditions':len(entries),'ratios':{k:statistics.geometric_mean(q['median_ratios'][k] for q in entries) for k in entries[0]['median_ratios']},'candidate_faster_than_control':sum(q['median_ratios']['candidate_over_control']<1 for q in entries),'candidate_faster_than_expat':sum(q['median_ratios']['candidate_over_expat']<1 for q in entries)}
 adverse=[{'name':q['condition']['name'],'chunk':q['condition']['chunk'],'namespaces':q['condition']['namespaces'],'ratio':q['median_ratios']['candidate_over_control']} for q in summary if q['median_ratios']['candidate_over_control']>1]
 groups['adverse_conditions']=adverse
 A=read(S/'adaptation.json');B=Path('/tmp/oriole-c-reparse-cold-pgo-study')
 assert A['source_manifest_sha256']==sha(B/'source.json') and A['build_pair_sha256']==sha(B/'pair-report.json')
 assert A['controller_sha256']==sha(new) and A['wrapper_sha256']==sha(S/'run.py')
 proof_path=Path('/tmp/oriole-c-reparse-cold-independent-review/build-review.json');proof=read(proof_path);pair=read(B/'pair-report.json')
 assert sha(proof_path)=='2b3f554d03a02b5450412cf6d958208ff679bac1fdb8f2a78f5a7c22ac7c7a4c'
 assert proof['status']=='passed_independent_saved_build_review' and proof['findings']==[] and not proof['targets_executed']
 assert proof['pins']['source.json']==sha(B/'source.json')=='e3254dd711b823d41ceffa259c2009b952c765b62bd95da1673467bef78c15b1'
 assert proof['pins']['pair-report.json']==sha(B/'pair-report.json')=='cd549c3e7dc93b952cddfc79236b66b67dfd4a3f12f5c4fdaa01c4bc5a168c6e'
 source=read(B/'source.json');assert len(source['source_sha256'])==72
 assert source['candidate_base_commit']=='f96bf1170c2606896e291c89e2f418bbffdd29b1' and source['refinement_parent']=='60b3a0f92e3eec9dce17b9e500079a5d0c20f7e5'
 assert proof['full_source_files']==72 and proof['pipeline_source_files']==69 and proof['fresh_full_compiler_vectors']==9 and proof['generated_candidate_rows']==864
 assert proof['candidate_snapshot_files']==64
 snapshot_path=proof_path.parent/'build-output-snapshot.json';assert sha(snapshot_path)==proof['snapshot_sha256'];snapshot=read(snapshot_path);assert len(snapshot)==64
 for name,row in snapshot.items():assert sha(B/name)==row['sha256'];inputs[str(B/name)]=row['sha256']
 binding_path=proof_path.parent/'native-binding-review.json';binding=read(binding_path)
 assert sha(binding_path)=='be0758e1e45e898a558b9ecc1f7b38a8abcceb9461ce8f4e75c225a57c91d254'
 assert binding['status']=='passed_independent_native_binding_review' and binding['findings']==[] and binding['build_review_sha256']==sha(proof_path)
 assert binding['source_commit']==source['candidate_base_commit'] and binding['pair_report_sha256']==sha(B/'pair-report.json')
 assert binding['modes'][phase]['controller_sha256']==sha(new) and binding['modes'][phase]['adaptation_sha256']==sha(S/'adaptation.json')
 pin(binding_path);pin(snapshot_path)
 for name,digest in source['source_sha256'].items():
  path=Path(source['worktree'])/name;assert sha(path)==digest;inputs[str(path)]=digest
 for path in [B/'pair-report.json',B/'source.json']:pin(path)
 candidate_digest=pair['normal_libraries']['liboriole_expat.so'] if phase=='normal' else pair['pgo_libraries']['use/liboriole_expat.so']
 assert p['libraries']['candidate']['sha256']==candidate_digest
 assert p['libraries']['candidate']==A['candidate_library'] and p['libraries']['control']==A['control_library']
 old_protocol=read(T/'native-screen/protocol.json')
 assert p['libraries']['control']==old_protocol['libraries']['control']
 assert p['libraries']['expat']==old_protocol['libraries']['expat']
 assert p['conditions']==old_protocol['conditions'] and p['pairs']==old_protocol['pairs'] and p['seed']==old_protocol['seed']
 assert p['hashes'][str(manifest)]==old_protocol['hashes'][str(manifest)]
 assert p['hashes']['/tmp/oriole-grammar-bench-plain/native-driver']==old_protocol['hashes']['/tmp/oriole-grammar-bench-plain/native-driver']
 assert all(p['hashes'][q]==old_protocol['hashes'][q] for q in fixtures.values())
 for library in p['libraries'].values():assert sha(library['path'])==library['sha256']
 assert set(p['hashes'])=={str(new),str(manifest),'/tmp/oriole-grammar-bench-plain/native-driver',*fixtures.values(),*[v['path'] for v in p['libraries'].values()]}
 report['native'][phase]={'preflights':84,'timed_workers':588,'cohorts':196,'measured_samples':105420,'timed_warmups':588,'preflight_samples':168,'total_samples':106176,'groups':groups,'all_conditions':[{'condition':q['condition'],'median_ratios':q['median_ratios']} for q in summary]}
 for q in [Path(__file__).parent/(phase+'-producer-controller.patch'),T/'native_screen.py',T/'native-screen/protocol.json',S/'adaptation.json',S/'run.py',S/'native_screen.py',S/'controller.json',D/'protocol.json',D/'preflight.json',D/'results.json']:pin(q)

report['limitations']=['One original fixed native campaign per mode, all adverse conditions retained. Python and full compatibility gates are outside this review.','All 28 condition ratios and adverse cases are retained; this audit does not establish a hardware or compiler mechanism.','Legacy native worker uses explicit dlopen paths and before/after file hashes; no new same-process XML_Parse dladdr is added.']
report['decision']='Cold-helper refinement remains subject to separate compatibility and consumer gates. All adverse conditions retained; no advance speed, full compatibility or hardware-mechanism claim.'
pin(proof_path)
report['configuration_scope']='Matched O3 ThinLTO normal and fresh original-G PGO. Cold refinement changes only core lib.rs versus initial reservation candidate; source72/pipeline69 retain five changed files versus selected capacity control. C fixtures and allocator unchanged. Independent build readback binds9vectors/864training rows and a 64-file saved-output snapshot, not a candidate freeze/archive/proof. No additional training or BOLT composition.'
report['reviewer_attempts']=['First saved-data audit attempt for these cohorts; no producer or target executions.']
report['generator_sha256']=sha(__file__)
report['input_sha256']=inputs
report['totals']={'conditions':28,'preflight_workers':84,'timed_workers':588,'all_workers':672,'all_samples':106176}
report['reader_adaptation_note']='Exact prior controller to cold collector reconstruction after candidate/output/caption substitutions; full worker/sample/condition/seeded order/callback/median/ratio reconstruction is byte-identical to the completed reservation reader. Only study/source/build snapshot bindings and accurate scope text changed.'
for path,digest in inputs.items():assert sha(path)==digest,path
report['all_input_bytes_unchanged_after_read']=True
report['source_files_rehashed']=72
csv_path=Path(__file__).parent/(args.phase+'-conditions.csv')
with csv_path.open('x',newline='') as stream:
 writer=csv.writer(stream);writer.writerow(['phase','group','project','chunk','namespaces','iterations','candidate_over_control','candidate_over_expat','control_over_expat'])
 for row in report['native'][args.phase]['all_conditions']:
  c=row['condition'];r=row['median_ratios'];writer.writerow([args.phase,'generated' if c['name'].startswith('generated-') else 'real',c['name'],c['chunk'],c['namespaces'],c['iterations'],r['candidate_over_control'],r['candidate_over_expat'],r['control_over_expat']])
report['condition_csv_sha256']=sha(csv_path)
out=Path(__file__).parent/(args.phase+'-review.json');
with out.open('x') as file:file.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'review':str(out),'sha256':sha(out),'groups':{k:v['groups'] for k,v in report['native'].items()}}))
