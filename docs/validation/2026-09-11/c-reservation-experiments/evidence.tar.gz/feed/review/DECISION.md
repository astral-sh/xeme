# Feed-boundary decision

Do not select the feed-boundary runtime `49b957668d4a0b485f7cf3e1964d8d822a2b847b`. Keep the selected runtime at `de859c89577b2982d59b6923d682032f6a7c7800`.

The fixed native campaign regressed against the matched selected control by **1.12% normal** and **3.08% PGO** across the 24 real-project conditions. Candidate/Expat duration was **1.6046 normal** and **1.4124 PGO**. There were 22/24 normal and 20/24 PGO adverse conditions. All 56 condition rows, 1,344 worker records and 212,352 samples remain in the audit packet. Generated controls remain separate.

The functional reservation and custom-conversion results remain useful compatibility evidence. These timings do not infer a compiler or hardware mechanism and do not establish full API compatibility. Earlier pressure and cold variants used separate matched campaigns, so their aggregates are not a direct paired comparison with this candidate.

Feed-boundary Python controllers were prepared in `/tmp/oriole-c-reparse-feed-python-study` but were **not executed**. No CPython timing or extension-build outcome is claimed for this candidate.

The exact prepared arithmetic readers were inspected and executed by `/root/feed_native_review`, separately from their original author. See `execution-review.json` for the role distinction and first-attempt exit records.
