# Feed-boundary native results

PASS: both phase audits reconstructed all raw worker/sample records, callbacks, seeded order, medians and ratios. Source72 and every pinned input matched before and after reading. All56 condition rows are in `conditions.csv`; generated controls remain separate.

| Build | Real/control | Real/Expat | Adverse real/control | Generated/control |
| --- | ---: | ---: | ---: | ---: |
| normal | 1.011227391 | 1.604615081 | 22/24 | 1.012493792 |
| pgo | 1.030824074 | 1.412404590 | 20/24 | 1.018738855 |

Ratios above1 mean slower. Values aggregate the per-condition medians of seven paired ratios by geometric mean; no single result is substituted for an individual condition. These measurements quantify the feed-boundary candidate against the selected capacity parent; they do not decide its compatibility or consumer gates. No full compatibility, CPython timing, hardware mechanism or production-readiness claim is made here.

The reviewer adapted the benchmark controllers and arithmetic reader but did not author the fix or collect elapsed runs. Controller authorship is disclosed; this is an independent raw-outcome reconstruction rather than an independent-author review of the controller.
