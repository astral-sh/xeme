# C buffer-pressure reparse scheduling native comparison

Prepared normal and original-generated-only PGO templates compare candidate `60b3a0f92e3eec9dce17b9e500079a5d0c20f7e5` with selected capacity runtime `de859c89577b2982d59b6923d682032f6a7c7800` and the existing matching Expat controls. No compiler, parser, preflight, elapsed worker, or sealer has run during preparation.

Both collectors preserve the original 28 interleaved conditions: 24 real-project conditions and four generated conditions, seven pairs, seed `2026091003`, 84 preflight workers and 588 timed workers per mode. Iterations, warmups, callbacks, callback oracles, randomized ordering, paired ratios and statistics are unchanged. `run.py.in` is byte-identical to the prior wrapper. The collector changes are limited to output paths, candidate/control library paths, and accurate scope captions; inverse text and AST checks verify the adaptation.

The sealer requires the exact candidate commit, completed build freeze and metadata, verified build proof, all 72 source files and the 69-file pipeline inventory. Both inventories must differ from the selected capacity control in exactly five files: `context_text_tests.rs`, `dtd.rs`, core `lib.rs`, C adapter `lib.rs`, and C adapter `tests.rs`. Three are runtime files; the two standalone test files are also present in the pipeline inventory. The C integration fixture must remain byte-identical. No older timing or compatibility result transfers to this candidate.

## Prepared artifacts

- `prepare.py` and `seal_native.py`, with reviewable diffs from the capacity study.
- `normal/native_screen.py.in` and `pgo/native_screen.py.in`, their byte-exact wrappers and adaptation reports.
- `adapter-origin.json`, `preparation.json`, and `preparation-readback.json` bind the original files, controls, workload and templates.
- `adaptation-attempt01.*`, `preparation-attempt01.*`, and `readback-attempt01.*` retain the first saved-data outcomes.

## Commands for the parent task

Preparation has already run once on CPU6 with the pinned Python interpreter and `-I -S`; do not rerun it into these exclusive outputs.

After root review and completed build proof/freezing, seal using the actual reviewed SHA-256 values:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-c-reparse-pressure-native-study/seal_native.py \
  --preparation-sha256 a24ff15c488e3c049ef2b0cdc386eadeb36adb6ef74314ae1db0c62fcfa9898e \
  --build-freeze-sha256 REVIEWED_BUILD_FREEZE_SHA256 \
  --source-manifest-sha256 REVIEWED_SOURCE_MANIFEST_SHA256
```

Root owns subsequent execution after reviewing sealed bindings and CPU availability: `normal/run.py`, then `pgo/run.py`. Each unchanged wrapper runs preflight on CPU5 with a 600-second limit, followed by elapsed workers on CPU0 with a 1,200-second aggregate limit. Each worker retains its 90-second limit. First outcomes and process-group cleanup records must be retained. The prepared templates make no advance speed or readiness claim.
