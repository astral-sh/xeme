"""Adapt saved native preparation sources without running benchmark targets."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = Path('/tmp/oriole-arena-capacity-bound-native-study')
CHANGED = ['crates/oriole/src/context_text_tests.rs', 'crates/oriole/src/dtd.rs',
           'crates/oriole/src/lib.rs', 'crates/oriole_expat/src/lib.rs',
           'crates/oriole_expat/src/tests.rs']
RUNTIME = ['crates/oriole/src/dtd.rs', 'crates/oriole/src/lib.rs',
           'crates/oriole_expat/src/lib.rs']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def adapt(name, replacements):
    original = (OLD / name).read_text()
    text = original
    changes = []
    for before, after in replacements:
        assert before != after and text.count(before) == 1, (name, before, text.count(before))
        text = text.replace(before, after)
        changes.append({'before': before, 'after': after})
    restored = text
    for before, after in reversed(replacements):
        assert restored.count(after) == 1, (name, after, restored.count(after))
        restored = restored.replace(after, before)
    assert restored == original
    assert ast.dump(ast.parse(restored)) == ast.dump(ast.parse(original))
    ast.parse(text)
    with (ROOT / name).open('x') as out:
        out.write(text)
    with (ROOT / (name + '.adaptation.patch')).open('x') as out:
        out.write(''.join(difflib.unified_diff(original.splitlines(True), text.splitlines(True),
                  fromfile=str(OLD / name), tofile=str(ROOT / name))))
    return {'original_sha256': sha(OLD / name), 'adapted_sha256': sha(ROOT / name),
            'inverse_source_byte_equal': True, 'inverse_ast_equal': True,
            'replacement_pairs': changes}


reports = {}
reports['prepare.py'] = adapt('prepare.py', [
    ('Prepare held native arena-capacity-bound templates', 'Prepare held native C-reparse-pressure templates'),
    ("OLD = Path('/tmp/oriole-context-text-frame-fixed-native-study')", "OLD = Path('/tmp/oriole-arena-capacity-bound-native-study')"),
    ("CONTROL = Path('/tmp/oriole-context-text-frame-fixed-pgo-study')", "CONTROL = Path('/tmp/oriole-arena-capacity-bound-pgo-study')"),
    ("BUILD = Path('/tmp/oriole-arena-capacity-bound-pgo-study')", "BUILD = Path('/tmp/oriole-c-reparse-pressure-pgo-study')"),
    ('9e21b1c0946ac2c19bda62b533bcd498103077a81924e98ccb97c63bcbfa92ac', '6580be9b4c5ac768747eb56e6cb4ed4130c3228401ce06e20f6c5e6e64ead598'),
    ('8a7da2759b67ca85f82fb29bd775392e532b3ff355340eb10f92ea7764bbe642', '169d9e55352ab2235fed31a1e34b2a0e2c562172fa203d455cc8bad51e80ad0f'),
    ("'wrapper limits, order/statistics and CPU5/CPU0. Arena '\n             'capacity fix on selected Context runtime, original-G training only. '",
     "'wrapper limits, order/statistics and CPU5/CPU0. C buffer-pressure '\n             'reparse scheduling on selected capacity runtime de859c8, original-G training only. '"),
    ('<UNSEALED_ARENA_CAPACITY_BOUND_', '<UNSEALED_C_REPARSE_PRESSURE_'),
    ("('direct C-context Text frame', 'arena capacity fix'),\n                        ('corrected allocator baseline', 'selected Context baseline')",
     "('arena capacity fix', 'C buffer-pressure reparse scheduling'),\n                        ('selected Context baseline', 'selected capacity baseline')"),
    ('        ast.parse(source)\n', "        ast.parse(source)\n        assert ast.dump(ast.parse(restored)) == ast.dump(ast.parse(original))\n"),
    ("'replacement_pairs': replacements, 'inverse_source_byte_equal': True,", "'replacement_pairs': replacements, 'inverse_source_byte_equal': True, 'inverse_ast_equal': True,"),
    ("'candidate_worktree_expected_path': '/home/dev-user/code/oss/oriole-arena-capacity-bound',", "'candidate_worktree_expected_path': '/home/dev-user/code/oss/oriole-c-reparse-pressure',\n                   'candidate_expected_commit': '60b3a0f92e3eec9dce17b9e500079a5d0c20f7e5',\n                   'control_expected_commit': 'de859c89577b2982d59b6923d682032f6a7c7800',"),
    ("'candidate_expected_changed_files': ['crates/oriole/src/arena.rs', 'tests/c/integration.c'],",
     "'candidate_expected_changed_files': " + repr(CHANGED) + ",\n                   'candidate_expected_runtime_changed_files': " + repr(RUNTIME) + ",\n                   'candidate_expected_pipeline_source_files': 69,"),
])

reports['seal_native.py'] = adapt('seal_native.py', [
    ("BUILD = Path('/tmp/oriole-arena-capacity-bound-pgo-study')", "BUILD = Path('/tmp/oriole-c-reparse-pressure-pgo-study')"),
    ("    assert sha(__file__) == preparation['seal_controller_sha256']\n", "    assert sha(__file__) == preparation['seal_controller_sha256']\n    assert str(BUILD) == preparation['candidate_build_expected_path']\n"),
    ("    assert source['worktree'] == preparation['candidate_worktree_expected_path']\n    control_source = read(Path(preparation['control_build']) / 'source.json')['source_sha256']\n",
     "    assert source['worktree'] == preparation['candidate_worktree_expected_path']\n    assert source['candidate_base_commit'] == preparation['candidate_expected_commit']\n    assert source['base_runtime'] == preparation['control_expected_commit']\n    control_manifest = read(Path(preparation['control_build']) / 'source.json')\n    assert control_manifest['candidate_base_commit'] == preparation['control_expected_commit']\n    control_source = control_manifest['source_sha256']\n"),
    ("    assert source_delta['changed_files'] == delta\n    assert source_delta['runtime_changed_files'] == source_delta['pipeline_source_changed_files'] == ['crates/oriole/src/arena.rs']\n    assert source_delta['inherited_fixture_files'] == ['tests/c/integration.c']\n    assert source_map['tests/c/integration.c'] == source_delta['inherited_fixture_sha256'] == '88eae7992ed72f9bb039bbfb9a94b126b2dc0959bd2c7fb4234e55622b3264ca'\n",
     "    assert source_delta['changed_files'] == source_delta['pipeline_source_changed_files'] == delta\n    assert source_delta['runtime_changed_files'] == preparation['candidate_expected_runtime_changed_files']\n    assert source_delta['inherited_fixture_files'] == []\n    assert source_delta['unchanged_fixture_files'] == ['tests/c/integration.c']\n    assert source_map['tests/c/integration.c'] == control_source['tests/c/integration.c'] == source_delta['unchanged_fixture_sha256'] == '88eae7992ed72f9bb039bbfb9a94b126b2dc0959bd2c7fb4234e55622b3264ca'\n    assert source_delta['source_manifest_sha256'] == args.source_manifest_sha256\n    assert source_delta['control_source_manifest_sha256'] == sha(Path(preparation['control_build']) / 'source.json')\n    assert source_delta['source_count'] == source_delta['control_source_count'] == source['source_count'] == 72\n    assert source_delta['pipeline_source_count'] == preparation['candidate_expected_pipeline_source_files']\n    assert source_delta['same_source_key_set'] is True\n    checks = read(BUILD / 'source-checks.json')\n    assert checks['status'] == 'passed' and checks['head'] == preparation['candidate_expected_commit']\n    assert checks['source_manifest_sha256'] == args.source_manifest_sha256\n    assert checks['test_count'] == 441 and checks['test_groups'] == 34\n    assert checks['failed'] == checks['ignored'] == 0\n"),
    ("    control_pgo = read(control_pair['pgo_manifest']['path'])\n    assert len(pgo['source_sha256']) == len(control_pgo['source_sha256']) == 69\n",
     "    assert sha(control_pair['pgo_manifest']['path']) == control_pair['pgo_manifest']['sha256']\n    control_pgo = read(control_pair['pgo_manifest']['path'])\n    assert len(pgo['source_sha256']) == len(control_pgo['source_sha256']) == preparation['candidate_expected_pipeline_source_files']\n"),
    ("    assert [name for name in pgo['source_sha256'] if pgo['source_sha256'][name] != control_pgo['source_sha256'][name]] == ['crates/oriole/src/arena.rs']\n",
     "    assert [name for name in pgo['source_sha256'] if pgo['source_sha256'][name] != control_pgo['source_sha256'][name]] == preparation['candidate_expected_changed_files']\n    assert all(control_source[name] == digest for name, digest in control_pgo['source_sha256'].items())\n"),
    ("        assert sha(library) == expected[mode]\n", "        assert sha(library) == expected[mode]\n        expected_control_path = Path(preparation['control_build']) / 'normal/liboriole_expat.so' if mode == 'normal' else Path(control_pair['pgo_manifest']['path']).parent / 'use/liboriole_expat.so'\n        expected_control_sha = control_pair['normal_libraries']['liboriole_expat.so'] if mode == 'normal' else control_pair['pgo_libraries']['use/liboriole_expat.so']\n        assert template['control_library'] == {'path': str(expected_control_path), 'sha256': expected_control_sha}\n"),
    ("        text = text.replace(template['placeholder'], str(library))\n        ast.parse(text)\n", "        text = text.replace(template['placeholder'], str(library))\n        ast.parse(text)\n        restored = text.replace(str(library), template['placeholder'])\n        assert restored == (out / 'native_screen.py.in').read_text()\n        assert ast.dump(ast.parse(restored)) == ast.dump(ast.parse((out / 'native_screen.py.in').read_text()))\n"),
])
with (ROOT / 'adapter-origin.json').open('x') as out:
    json.dump({'scope': 'Saved-only exact native protocol adaptation; no targets executed or sealed.',
               'prior_preparation': str(OLD), 'files': reports}, out, indent=2)
    out.write('\n')
print(json.dumps({'status': 'adapted_no_targets', 'files': {n: r['adapted_sha256'] for n, r in reports.items()}}, indent=2))
