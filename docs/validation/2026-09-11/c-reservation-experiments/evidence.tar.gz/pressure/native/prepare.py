"""Prepare held native C-reparse-pressure templates; never execute a target."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = Path('/tmp/oriole-arena-capacity-bound-native-study')
CONTROL = Path('/tmp/oriole-arena-capacity-bound-pgo-study')
BUILD = Path('/tmp/oriole-c-reparse-pressure-pgo-study')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with path.open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')


def main():
    assert sha(CONTROL / 'pair-freeze.json') == '6580be9b4c5ac768747eb56e6cb4ed4130c3228401ce06e20f6c5e6e64ead598'
    assert sha(CONTROL / 'source.json') == '169d9e55352ab2235fed31a1e34b2a0e2c562172fa203d455cc8bad51e80ad0f'
    old_preparation = read(OLD / 'preparation.json')
    pins = {}
    origin_pins = {str(CONTROL / name): sha(CONTROL / name) for name in ['pair-freeze.json', 'pair-report.json', 'source.json', 'vector-training-proof.json']}
    modes = {}
    scope = ('Original 28 conditions (24 real + 4 generated), 7 pairs, seed2026091003, '
             '84 preflight + 588 timed workers per mode; unchanged warmups/iterations, '
             'callbacks, 90-second workers, 600-second preflight/1200-second elapsed '
             'wrapper limits, order/statistics and CPU5/CPU0. C buffer-pressure '
             'reparse scheduling on selected capacity runtime de859c8, original-G training only. '
             'Candidate source/build/library bindings remain pending; no targets executed.')
    for mode in ['normal', 'pgo']:
        old = OLD / mode
        out = ROOT / mode
        out.mkdir(exist_ok=False)
        binding = read(old / 'adaptation.json')
        assert sha(old / 'native_screen.py') == binding['controller_sha256']
        assert sha(old / 'run.py') == binding['wrapper_sha256']
        original = (old / 'native_screen.py').read_text()
        placeholder = '<UNSEALED_C_REPARSE_PRESSURE_' + mode.upper() + '_LIBRARY>'
        control = binding['candidate_library']
        expat = binding['expat_library']
        # Move the former candidate first so it becomes only the new control.
        replacements = [(binding['candidate_library']['path'], placeholder),
                        (binding['control_library']['path'], control['path']),
                        (str(old), str(out)),
                        ('arena capacity fix', 'C buffer-pressure reparse scheduling'),
                        ('selected Context baseline', 'selected capacity baseline')]
        source = original
        for before, after in replacements:
            assert before in source
            source = source.replace(before, after)
        restored = source
        for before, after in reversed(replacements):
            restored = restored.replace(after, before)
        assert restored == original and source.count(placeholder) == 1
        ast.parse(source)
        assert ast.dump(ast.parse(restored)) == ast.dump(ast.parse(original))
        (out / 'native_screen.py.in').write_text(source)
        (out / 'run.py.in').write_bytes((old / 'run.py').read_bytes())
        (out / 'template-adaptation.patch').write_text(''.join(difflib.unified_diff(
            original.splitlines(True), source.splitlines(True),
            fromfile=str(old / 'native_screen.py'), tofile=str(out / 'native_screen.py.in'))))
        for library in [control, expat]:
            assert sha(library['path']) == library['sha256']
            pins[library['path']] = library['sha256']
        for name in ['native_screen.py', 'run.py', 'adaptation.json']:
            origin_pins[str(old / name)] = sha(old / name)
        report = {'status': 'prepared_not_sealed', 'origin': str(old),
                  'original_controller_sha256': sha(old / 'native_screen.py'),
                  'original_wrapper_sha256': sha(old / 'run.py'),
                  'template_sha256': sha(out / 'native_screen.py.in'),
                  'wrapper_template_sha256': sha(out / 'run.py.in'), 'placeholder': placeholder,
                  'replacement_pairs': replacements, 'inverse_source_byte_equal': True, 'inverse_ast_equal': True,
                  'wrapper_byte_exact': True, 'control_library': control, 'expat_library': expat,
                  'candidate_library': None, 'candidate_source_manifest_sha256': None,
                  'candidate_build_freeze_sha256': None, 'scope': scope, 'targets_executed': False}
        save(out / 'template-preparation.json', report)
        modes[mode] = {name: sha(out / name) for name in ['native_screen.py.in', 'run.py.in', 'template-preparation.json', 'template-adaptation.patch']}
    old_control_paths = {read(OLD / mode / 'adaptation.json')['control_library']['path'] for mode in ['normal', 'pgo']}
    for path, digest in old_preparation['fixed_workload_pins'].items():
        if path in old_control_paths:
            continue
        assert sha(path) == digest
        assert path not in pins or pins[path] == digest
        pins[path] = digest
    assert len(pins) == 14
    preparation = {'status': 'prepared_no_execution_candidate_binding_pending', 'origin': str(OLD),
                   'control_build': str(CONTROL), 'candidate_build_expected_path': str(BUILD),
                   'candidate_worktree_expected_path': '/home/dev-user/code/oss/oriole-c-reparse-pressure',
                   'candidate_expected_commit': '60b3a0f92e3eec9dce17b9e500079a5d0c20f7e5',
                   'control_expected_commit': 'de859c89577b2982d59b6923d682032f6a7c7800',
                   'candidate_expected_source_files': 72,
                   'candidate_expected_changed_files': ['crates/oriole/src/context_text_tests.rs', 'crates/oriole/src/dtd.rs', 'crates/oriole/src/lib.rs', 'crates/oriole_expat/src/lib.rs', 'crates/oriole_expat/src/tests.rs'],
                   'candidate_expected_runtime_changed_files': ['crates/oriole/src/dtd.rs', 'crates/oriole/src/lib.rs', 'crates/oriole_expat/src/lib.rs'],
                   'candidate_expected_pipeline_source_files': 69,
                   'candidate_source_manifest_sha256': None, 'candidate_build_freeze_sha256': None,
                   'modes': modes, 'fixed_workload_pins': pins, 'origin_pins': origin_pins,
                   'pin_counts': {'fixed_workload_total': 14, 'origin_files': len(origin_pins),
                                  'native_protocol_hashes_per_mode_after_seal': 14},
                   'seal_controller_sha256': sha(ROOT / 'seal_native.py'), 'generator_sha256': sha(__file__),
                   'scope': scope}
    save(ROOT / 'preparation.json', preparation)
    print(json.dumps({'status': preparation['status'], 'preparation_sha256': sha(ROOT / 'preparation.json'), 'modes': modes, 'pin_counts': preparation['pin_counts']}, indent=2))


if __name__ == '__main__':
    main()
