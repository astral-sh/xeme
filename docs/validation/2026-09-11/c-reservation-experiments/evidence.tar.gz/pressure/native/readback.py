"""Read saved templates and source bytes; do not import or execute collectors."""
import ast
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


assert os.sched_getaffinity(0) == {6}
preparation = read(ROOT / 'preparation.json')
assert preparation['status'] == 'prepared_no_execution_candidate_binding_pending'
assert preparation['candidate_source_manifest_sha256'] is None
assert preparation['candidate_build_freeze_sha256'] is None
assert sha(ROOT / 'prepare.py') == preparation['generator_sha256']
assert sha(ROOT / 'seal_native.py') == preparation['seal_controller_sha256']
for path, digest in (preparation['fixed_workload_pins'] | preparation['origin_pins']).items():
    assert sha(path) == digest, path
adapter = read(ROOT / 'adapter-origin.json')
for name, adaptation in adapter['files'].items():
    original = Path(adapter['prior_preparation']) / name
    assert sha(original) == adaptation['original_sha256']
    assert sha(ROOT / name) == adaptation['adapted_sha256']
    restored = (ROOT / name).read_text()
    for pair in reversed(adaptation['replacement_pairs']):
        assert restored.count(pair['after']) == 1
        restored = restored.replace(pair['after'], pair['before'])
    assert restored == original.read_text()
    assert ast.dump(ast.parse(restored)) == ast.dump(ast.parse(original.read_text()))

modes = {}
for mode in ['normal', 'pgo']:
    out = ROOT / mode
    report = read(out / 'template-preparation.json')
    original = Path(report['origin']) / 'native_screen.py'
    text = (out / 'native_screen.py.in').read_text()
    for name, digest in preparation['modes'][mode].items():
        assert sha(out / name) == digest
    restored = text
    for before, after in reversed(report['replacement_pairs']):
        restored = restored.replace(after, before)
    assert restored == original.read_text()
    assert ast.dump(ast.parse(restored)) == ast.dump(ast.parse(original.read_text()))
    old_nodes = list(ast.walk(ast.parse(original.read_text())))
    new_nodes = list(ast.walk(ast.parse(text)))
    assert len(old_nodes) == len(new_nodes)
    changed_constants = []
    for old, new in zip(old_nodes, new_nodes):
        assert type(old) is type(new)
        if isinstance(old, ast.Constant) and old.value != new.value:
            assert isinstance(old.value, str) and isinstance(new.value, str)
            changed_constants.append({'line': old.lineno, 'old': old.value, 'new': new.value})
    assert len(changed_constants) == 5
    assert (out / 'run.py.in').read_bytes() == (Path(report['origin']) / 'run.py').read_bytes()
    assert not any((out / name).exists() for name in ['run.py', 'native_screen.py', 'adaptation.json', 'native-screen'])
    modes[mode] = {'inverse_source_byte_equal': True, 'inverse_ast_equal': True,
                   'changed_string_constants': changed_constants, 'wrapper_byte_exact': True,
                   'template_sha256': sha(out / 'native_screen.py.in'),
                   'control_library': report['control_library'], 'expat_library': report['expat_library']}

control = Path(preparation['control_build'])
source = read(control / 'source.json')['source_sha256']
candidate = Path(preparation['candidate_worktree_expected_path'])
current = {name: sha(candidate / name) for name in source}
delta = [name for name in source if current[name] != source[name]]
assert len(source) == preparation['candidate_expected_source_files'] == 72
assert delta == preparation['candidate_expected_changed_files']
pair = read(control / 'pair-report.json')
assert sha(pair['pgo_manifest']['path']) == pair['pgo_manifest']['sha256']
pipeline = read(pair['pgo_manifest']['path'])['source_sha256']
assert len(pipeline) == preparation['candidate_expected_pipeline_source_files'] == 69
assert all(source[name] == digest for name, digest in pipeline.items())
assert [name for name in pipeline if current[name] != pipeline[name]] == delta
assert current['tests/c/integration.c'] == source['tests/c/integration.c'] == '88eae7992ed72f9bb039bbfb9a94b126b2dc0959bd2c7fb4234e55622b3264ca'
assert not (ROOT / 'sealed-build-binding.json').exists()
report = {'status': 'passed_saved_data_readback_unsealed', 'affinity': [6],
          'preparation_sha256': sha(ROOT / 'preparation.json'), 'modes': modes,
          'source_files': len(source), 'pipeline_files': len(pipeline), 'current_source_delta': delta,
          'current_source_sha256': current, 'c_fixture_unchanged': True,
          'protocol': {'conditions': 28, 'real': 24, 'generated': 4, 'pairs': 7,
                       'seed': 2026091003, 'preflight_workers_per_mode': 84,
                       'timed_workers_per_mode': 588, 'worker_timeout_seconds': 90,
                       'preflight_wrapper_timeout_seconds': 600,
                       'elapsed_wrapper_timeout_seconds': 1200, 'preflight_cpu': 5, 'elapsed_cpu': 0},
          'targets_executed': False, 'candidate_build_binding': 'pending',
          'role': 'Preparation author saved-data readback; independent root review remains separate.'}
with (ROOT / 'preparation-readback.json').open('x') as out:
    json.dump(report, out, indent=2)
    out.write('\n')
print(json.dumps({'status': report['status'], 'readback_sha256': sha(ROOT / 'preparation-readback.json'),
                  'source_files': len(source), 'pipeline_files': len(pipeline)}, indent=2))
