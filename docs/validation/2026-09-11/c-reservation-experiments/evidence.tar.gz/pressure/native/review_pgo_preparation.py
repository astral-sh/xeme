"""Independent saved-source review; never import or execute prepared controllers."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

OUT = Path(__file__).resolve().parent
O = Path('/tmp/oriole-c-reparse-pressure-pgo-study')
B = Path('/tmp/oriole-arena-capacity-bound-pgo-study')
W = Path('/home/dev-user/code/oss/oriole-c-reparse-pressure')
HEAD = '60b3a0f92e3eec9dce17b9e500079a5d0c20f7e5'
PARENT = 'de859c89577b2982d59b6923d682032f6a7c7800'
CHANGED = ['crates/oriole/src/context_text_tests.rs', 'crates/oriole/src/dtd.rs',
           'crates/oriole/src/lib.rs', 'crates/oriole_expat/src/lib.rs',
           'crates/oriole_expat/src/tests.rs']
RUNTIME = ['crates/oriole/src/dtd.rs', 'crates/oriole/src/lib.rs', 'crates/oriole_expat/src/lib.rs']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def git(*args):
    return subprocess.check_output(['git', '-C', str(W), *args], timeout=30)


assert os.sched_getaffinity(0) == {6}
assert sha(sys.executable) == '021044895e95be79dc2f110367607e684119afbc8ce75f6f0eec94844e0acec7'
pins = {'preparation.json': 'e64e400496dba2c9f5f2d8335a2a18ef7d880722abd8736efe07873b614b830b',
        'source.json': 'eae0483cefd1932c006bdf969ade237e80648400aa7acf5d117b3539db4c86a9',
        'controller.patch': 'ceba48a55e68fecf0d27173f9430dbdfb0bb58865a8840052d075f55d4d4126e'}
for name, digest in pins.items():
    assert sha(O / name) == digest
p = load(O / 'preparation.json')
assert p['status'] == 'prepared_only_no_build' and p['candidate_base'] == HEAD
for name, key in [('source.json', 'source_manifest_sha256'), ('source.tar.gz', 'source_archive_sha256'),
                  ('source-delta.json', 'source_delta_sha256'), ('source-checks.json', 'source_checks_sha256'),
                  ('tool-source.json', 'tool_source_sha256'), ('controller.patch', 'controller_patch_sha256'),
                  ('prepare.py', 'preparer_sha256')]:
    assert sha(O / name) == p[key]
    pins[name] = p[key]
assert sha(B / 'pair-report.json') == p['control_pair_sha256']
assert sha(B / 'pair-freeze.json') == p['control_freeze_sha256']
freeze = load(B / 'pair-freeze.json')
assert freeze['status'] == 'frozen'
for name, entry in freeze['files'].items():
    assert sha(B / name) == entry['sha256']
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain')
s = load(O / 'source.json')
prior_manifest = load(B / 'source.json')
source = s['source_sha256']
prior = prior_manifest['source_sha256']
assert s['candidate_base_commit'] == HEAD and s['base_runtime'] == PARENT
assert prior_manifest['candidate_base_commit'] == PARENT and s['worktree'] == str(W)
assert set(source) == set(prior) and len(source) == s['source_count'] == 72
assert sorted(name for name in source if source[name] != prior[name]) == CHANGED
git_changed = git('diff', '--name-only', PARENT, HEAD).decode().splitlines()
assert [name for name in git_changed if name in source] == CHANGED
outside_inventory = [name for name in git_changed if name not in source]
assert all(name == 'README.md' or name.startswith('docs/') for name in outside_inventory)
assert git('diff', PARENT, HEAD, '--', *CHANGED) == (O / 'source.patch').read_bytes()
for name, digest in source.items():
    assert sha(W / name) == digest
    assert hashlib.sha256(git('show', HEAD + ':' + name)).hexdigest() == digest
with tarfile.open(O / 'source.tar.gz') as archive:
    members = archive.getmembers()
    assert len(members) == 72 and all(entry.isfile() for entry in members)
    assert {entry.name: hashlib.sha256(archive.extractfile(entry).read()).hexdigest()
            for entry in members} == source
control_pair = load(B / 'pair-report.json')
assert sha(control_pair['pgo_manifest']['path']) == control_pair['pgo_manifest']['sha256']
pipeline = load(control_pair['pgo_manifest']['path'])['source_sha256']
assert len(pipeline) == 69 and all(prior[name] == digest for name, digest in pipeline.items())
assert sorted(name for name in pipeline if source[name] != pipeline[name]) == CHANGED
assert set(source) - set(pipeline) == {'tests/c/integration.c', 'tests/c/allocations.c', 'tests/c/adversarial.c'}
for path, digest in p['auxiliary_nonbuild_pins'].items():
    assert sha(path) == digest
    assert sha(Path(prior_manifest['worktree']) / Path(path).relative_to(W)) == digest
d = load(O / 'source-delta.json')
assert d['changed_files'] == d['pipeline_source_changed_files'] == CHANGED
assert d['runtime_changed_files'] == RUNTIME
assert d['test_changed_files'] == ['crates/oriole/src/context_text_tests.rs', 'crates/oriole_expat/src/tests.rs']
assert d['inherited_fixture_files'] == [] and d['unchanged_fixture_files'] == ['tests/c/integration.c']
assert source['tests/c/integration.c'] == prior['tests/c/integration.c'] == d['unchanged_fixture_sha256'] == '88eae7992ed72f9bb039bbfb9a94b126b2dc0959bd2c7fb4234e55622b3264ca'
assert d['source_manifest_sha256'] == sha(O / 'source.json')
assert d['control_source_manifest_sha256'] == sha(B / 'source.json')
assert d['source_count'] == d['control_source_count'] == 72 and d['pipeline_source_count'] == 69
assert d['same_source_key_set'] is True
checks = load(O / 'source-checks.json')
final = load(O / 'local-checks/final-checks.json')
assert checks['status'] == final['status'] == 'passed' and checks['head'] == HEAD
assert checks['source_manifest_sha256'] == sha(O / 'source.json')
assert checks['check_report_sha256'] == sha(O / 'local-checks/final-checks.json')
assert checks['test_count'] == 441 and checks['test_groups'] == 34
assert checks['failed'] == checks['ignored'] == 0
assert checks['recorded_source_files_per_check'] == final['recorded_source_files_per_check'] == 28
assert checks['archived_source_files'] == 72 and checks['commands'] == final['commands']
for command in checks['commands']:
    label = command['label']
    raw = load(O / 'local-checks' / label / 'report.json')
    assert command == {'label': label, **raw}
    assert raw['exit'] == 0 and raw['reaped'] and raw['source_unchanged']
    assert len(raw['source_sha256']) == 28 and set(CHANGED) <= set(raw['source_sha256'])
    assert all(source[name] == digest for name, digest in raw['source_sha256'].items())
    assert sha(O / 'local-checks' / label / 'output.log') == raw['log_sha256']
groups = [tuple(map(int, match)) for match in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
          (O / 'local-checks/tests-02/output.log').read_text())]
assert len(groups) == 34 and sum(row[0] for row in groups) == 441 and all(row[1:] == (0, 0) for row in groups)
for label in ['format-01', 'format-02', 'tests-01', 'tests-02', 'clippy-01', 'release-01']:
    original = Path('/tmp/oriole-c-reparse-checks') / label
    for name in ['report.json', 'output.log']:
        assert (original / name).read_bytes() == (O / 'local-checks' / label / name).read_bytes()
    raw = load(original / 'report.json')
    assert raw['reaped'] and sha(original / 'output.log') == raw['log_sha256']
assert checks['independent_source_review_sha256'] == sha(O / 'source-review/review.json')
runtime_review = load(O / 'source-review/review.json')
assert runtime_review['status'] == 'source_review_no_blocking_issue'
assert all(runtime_review['pins'][str(W / name)] == source[name] for name in RUNTIME)
scripts = load(O / 'tool-source.json')
assert scripts == load(B / 'tool-source.json') == p['pipeline_sha256'] and len(scripts) == 6
for name, digest in scripts.items():
    assert sha(O / 'pipeline' / name) == sha(B / 'pipeline' / name) == digest
    pins['pipeline/' + name] = digest
for name, digest in p['controllers'].items():
    assert sha(O / name) == digest
    assert sha(B / name) == p['original_controllers'][str(B / name)]
    pins[name] = digest
patch = ''.join(''.join(difflib.unified_diff((B / name).read_text().splitlines(True),
                  (O / name).read_text().splitlines(True), fromfile=str(B / name), tofile=str(O / name)))
                for name in ['build_pair.py', 'prove_pair.py', 'freeze_pair.py'])
assert patch == (O / 'controller.patch').read_text()
old_build = (B / 'build_pair.py').read_text()
new_build = (O / 'build_pair.py').read_text()
assert old_build[old_build.index('def save()'):] == new_build[new_build.index('def save()'):]
old_ast = ast.parse(old_build)
new_ast = ast.parse(new_build)
guard = "assert not (O/'pair-report.json').exists(), 'First pair attempt already exists; retain it and use a reviewed fresh attempt directory'"
guard_ast = ast.dump(ast.parse(guard).body[0])
assert sum(ast.dump(node) == guard_ast for node in new_ast.body) == 1
new_ast.body = [node for node in new_ast.body if ast.dump(node) != guard_ast]
old_constants = [node for node in ast.walk(old_ast) if isinstance(node, ast.Constant)]
new_constants = [node for node in ast.walk(new_ast) if isinstance(node, ast.Constant)]
assert len(old_constants) == len(new_constants)
build_constant_changes = []
for old, new in zip(old_constants, new_constants):
    if old.value != new.value:
        build_constant_changes.append({'line': old.lineno, 'old': old.value, 'new': new.value})
        new.value = old.value
assert len(build_constant_changes) == 6
assert ast.dump(old_ast) == ast.dump(new_ast)
old_proof = (B / 'prove_pair.py').read_text()
new_proof = (O / 'prove_pair.py').read_text()
critical_start = "details = {'raw_vector_comparisons':[], 'training':[]}"
assert old_proof[old_proof.index('def vectors('):old_proof.index('source=load(')] == new_proof[new_proof.index('def vectors('):new_proof.index('source=load(')]
restored = new_proof.replace(str(B), '/tmp/oriole-context-text-frame-fixed-pgo-study').replace(str(W), '/home/dev-user/code/oss/oriole-arena-capacity-bound')
start = restored.index("assert delta['runtime_changed_files']==")
end = restored.index("assert len(bm['source_sha256'])", start)
old_start = old_proof.index("assert delta['runtime_changed_files']==")
old_end = old_proof.index("assert len(bm['source_sha256'])", old_start)
restored = restored[:start] + old_proof[old_start:old_end] + restored[end:]
restored = restored.replace('frozen selected capacity control', 'frozen selected Context Text control')
new_role = 'Root authored the reservation-pressure candidate and regressions; api_remaining_audit reviewed the runtime source. capacity_python_prepare adapted these saved-data build/proof controllers. Root owns targets and independent raw review remains separate. This candidate requires correctness and performance gates before selection.'
old_role = 'next_hotspot authored the capacity fix, regression and these adapted build/proof controllers. Root and conditional_review independently reviewed the source; build collection and later independent raw review remain separate. This mandatory capacity repair makes no performance claim.'
assert restored.count(new_role) == 1
restored = restored.replace(new_role, old_role)
assert restored == old_proof and ast.dump(ast.parse(restored)) == ast.dump(ast.parse(old_proof))
assert (O / 'freeze_pair.py').read_bytes() == (B / 'freeze_pair.py').read_bytes()
attempts = []
for number, expected in [('01', 1), ('02', 0)]:
    row = load(O / ('preparation-attempt' + number + '.json'))
    assert row['status'] == 'reaped' and row['reaped'] and row['exit'] == expected
    assert row['targets_executed'] == 0 and row['cpu'] == [6]
    for suffix in ['stdout', 'stderr']:
        name = 'preparation-attempt' + number + '.' + suffix
        assert sha(O / name) == row[name + '_sha256']
    attempts.append({'attempt': int(number), 'exit': row['exit'], 'reaped': row['reaped']})
assert 'assert set(source) == expected_names and len(source) == 72' in (O / 'preparation-attempt01.stderr').read_text()
old_prepare = (O / 'prepare-attempt01.py').read_text()
failure_line = old_prepare.splitlines()[57]
assert failure_line.strip() == 'assert set(source) == expected_names and len(source) == 72'
assert old_prepare.index(failure_line) < old_prepare.index('dest.mkdir(')
attempt_patch = ''.join(difflib.unified_diff(old_prepare.splitlines(True), (O / 'prepare.py').read_text().splitlines(True),
                         fromfile=str(O / 'prepare-attempt01.py'), tofile=str(O / 'prepare.py')))
with (OUT / 'pgo-preparation-attempt-correction.patch').open('x') as out:
    out.write(attempt_patch)
native = load(OUT / 'preparation.json')
assert native['candidate_expected_commit'] == HEAD and native['control_expected_commit'] == PARENT
assert native['candidate_expected_changed_files'] == CHANGED
assert native['candidate_expected_runtime_changed_files'] == RUNTIME
assert native['candidate_expected_source_files'] == 72 and native['candidate_expected_pipeline_source_files'] == 69
assert not any((O / name).exists() for name in ['pair-report.json', 'pair-freeze.json', 'normal', 'pgo', 'vector-training-proof.json'])
for name, digest in pins.items():
    assert sha(O / name) == digest
report = {'status': 'passed_independent_saved_preparation_review', 'findings': [], 'affinity': [6],
          'reviewer': '/root/capacity_python_prepare/native_pressure_prepare',
          'scope': 'Source, preparation and controller readback only. No build, prove, freeze, parser, training or elapsed target executed.',
          'pins': pins, 'source_commit': HEAD, 'parent_commit': PARENT,
          'full_source_files': 72, 'pipeline_source_files': 69, 'exact_changed_files': CHANGED,
          'inherited_repository_documentation_outside_source_inventory': outside_inventory,
          'reviewer_first_attempt': 'Stopped on an overly broad whole-repository Git delta assertion. Retained original reviewer and receipt; corrected to declared source inventory, with inherited README/docs differences recorded separately. No preparation or controller changes.',
          'runtime_changed_files': RUNTIME, 'c_fixture_unchanged': True, 'original_pipeline_helpers_byte_exact': 6,
          'build_changes': {'constant_changes': build_constant_changes, 'first_attempt_guard_added': True,
                            'remaining_ast_exact': True, 'full_execution_body_byte_exact': True},
          'proof_changes': {'nine_vector_loop_and_normalizer_byte_exact': True,
                            'training_identity_and_fresh_profile_checks_byte_exact': True,
                            'inverse_remaining_source_and_ast_exact': True},
          'freeze_controller_byte_exact': True,
          'local_checks': {'tests': 441, 'groups': 34, 'failed': 0, 'ignored': 0,
                           'recorded_source_files_per_check': 28, 'separate_archived_source_files': 72,
                           'all_five_changed_files_covered': True,
                           'missing_final_fmt_log_disclosed': True},
          'preparation_attempts': attempts, 'first_failure_precedes_source_artifact_writes': True,
          'attempt_correction_patch_sha256': sha(OUT / 'pgo-preparation-attempt-correction.patch'),
          'native_sealer_source_and_check_schema_compatible': True,
          'targets_executed': False, 'build_outcome': 'not yet collected'}
with (OUT / 'pgo-preparation-independent-review.json').open('x') as out:
    json.dump(report, out, indent=2)
    out.write('\n')
print(json.dumps({'status': report['status'], 'sha256': sha(OUT / 'pgo-preparation-independent-review.json'),
                  'findings': []}, indent=2))
