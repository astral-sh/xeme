"""Bind explicitly reviewed completed artifacts to held templates; no targets."""
import argparse
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUILD = Path('/tmp/oriole-c-reparse-pressure-pgo-study')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with path.open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--preparation-sha256', required=True)
    parser.add_argument('--build-freeze-sha256', required=True)
    parser.add_argument('--source-manifest-sha256', required=True)
    args = parser.parse_args()
    assert sha(ROOT / 'preparation.json') == args.preparation_sha256
    preparation = read(ROOT / 'preparation.json')
    assert sha(__file__) == preparation['seal_controller_sha256']
    assert str(BUILD) == preparation['candidate_build_expected_path']
    for path, digest in (preparation['fixed_workload_pins'] | preparation['origin_pins']).items():
        assert sha(path) == digest, path
    assert sha(BUILD / 'pair-freeze.json') == args.build_freeze_sha256
    assert sha(BUILD / 'source.json') == args.source_manifest_sha256
    freeze = read(BUILD / 'pair-freeze.json')
    assert freeze['status'] == 'frozen'
    metadata_names = ['pair-report.json', 'source.json', 'source-delta.json', 'source-checks.json',
                      'vector-training-proof.json', 'tool-source.json', 'preparation.json',
                      'build_pair.py', 'prove_pair.py', 'freeze_pair.py']
    metadata = {}
    for name in metadata_names:
        metadata[str(BUILD / name)] = sha(BUILD / name)
        assert sha(BUILD / name) == freeze['files'][name]['sha256'], name
    source = read(BUILD / 'source.json')
    assert source['worktree'] == preparation['candidate_worktree_expected_path']
    assert source['candidate_base_commit'] == preparation['candidate_expected_commit']
    assert source['base_runtime'] == preparation['control_expected_commit']
    control_manifest = read(Path(preparation['control_build']) / 'source.json')
    assert control_manifest['candidate_base_commit'] == preparation['control_expected_commit']
    control_source = control_manifest['source_sha256']
    source_map = source['source_sha256']
    assert set(source_map) == set(control_source)
    assert len(source_map) == preparation['candidate_expected_source_files']
    delta = [name for name in source_map if source_map[name] != control_source[name]]
    assert delta == preparation['candidate_expected_changed_files'], delta
    source_delta = read(BUILD / 'source-delta.json')
    assert source_delta['changed_files'] == source_delta['pipeline_source_changed_files'] == delta
    assert source_delta['runtime_changed_files'] == preparation['candidate_expected_runtime_changed_files']
    assert source_delta['inherited_fixture_files'] == []
    assert source_delta['unchanged_fixture_files'] == ['tests/c/integration.c']
    assert source_map['tests/c/integration.c'] == control_source['tests/c/integration.c'] == source_delta['unchanged_fixture_sha256'] == '88eae7992ed72f9bb039bbfb9a94b126b2dc0959bd2c7fb4234e55622b3264ca'
    assert source_delta['source_manifest_sha256'] == args.source_manifest_sha256
    assert source_delta['control_source_manifest_sha256'] == sha(Path(preparation['control_build']) / 'source.json')
    assert source_delta['source_count'] == source_delta['control_source_count'] == source['source_count'] == 72
    assert source_delta['pipeline_source_count'] == preparation['candidate_expected_pipeline_source_files']
    assert source_delta['same_source_key_set'] is True
    checks = read(BUILD / 'source-checks.json')
    assert checks['status'] == 'passed' and checks['head'] == preparation['candidate_expected_commit']
    assert checks['source_manifest_sha256'] == args.source_manifest_sha256
    assert checks['test_count'] == 441 and checks['test_groups'] == 34
    assert checks['failed'] == checks['ignored'] == 0
    assert all(sha(Path(source['worktree']) / name) == digest for name, digest in source_map.items())
    pair = read(BUILD / 'pair-report.json')
    proof = read(BUILD / 'vector-training-proof.json')
    assert pair['status'] == proof['status'] == 'passed'
    assert pair['source_unchanged'] and pair['scripts_unchanged'] and pair['tools_unchanged']
    assert pair['source_manifest_sha256'] == args.source_manifest_sha256
    assert proof['fresh_workspace_compilations'] == 9
    assert proof['generated_rows'] == {'normal': 288, 'generate': 288, 'use': 288}
    manifest = Path(pair['pgo_manifest']['path'])
    assert sha(manifest) == pair['pgo_manifest']['sha256']
    pgo = read(manifest)
    assert pgo['status'] == 'passed' and pgo['compared_parses'] == 288
    control_pair = read(Path(preparation['control_build']) / 'pair-report.json')
    assert sha(control_pair['pgo_manifest']['path']) == control_pair['pgo_manifest']['sha256']
    control_pgo = read(control_pair['pgo_manifest']['path'])
    assert len(pgo['source_sha256']) == len(control_pgo['source_sha256']) == preparation['candidate_expected_pipeline_source_files']
    assert set(pgo['source_sha256']) == set(control_pgo['source_sha256'])
    assert [name for name in pgo['source_sha256'] if pgo['source_sha256'][name] != control_pgo['source_sha256'][name]] == preparation['candidate_expected_changed_files']
    assert all(control_source[name] == digest for name, digest in control_pgo['source_sha256'].items())
    assert all(source_map[name] == digest for name, digest in pgo['source_sha256'].items())
    libraries = {'normal': BUILD / 'normal/liboriole_expat.so', 'pgo': manifest.parent / 'use/liboriole_expat.so'}
    expected = {'normal': pair['normal_libraries']['liboriole_expat.so'], 'pgo': pair['pgo_libraries']['use/liboriole_expat.so']}
    staged = []
    for mode, library in libraries.items():
        out = ROOT / mode
        template = read(out / 'template-preparation.json')
        for name, digest in preparation['modes'][mode].items():
            assert sha(out / name) == digest
        assert sha(library) == expected[mode]
        expected_control_path = Path(preparation['control_build']) / 'normal/liboriole_expat.so' if mode == 'normal' else Path(control_pair['pgo_manifest']['path']).parent / 'use/liboriole_expat.so'
        expected_control_sha = control_pair['normal_libraries']['liboriole_expat.so'] if mode == 'normal' else control_pair['pgo_libraries']['use/liboriole_expat.so']
        assert template['control_library'] == {'path': str(expected_control_path), 'sha256': expected_control_sha}
        for name in ['control_library', 'expat_library']:
            assert sha(template[name]['path']) == template[name]['sha256']
        assert not any((out / name).exists() for name in ['adaptation.json', 'native-screen', 'native_screen.py', 'run.py'])
        text = (out / 'native_screen.py.in').read_text()
        assert text.count(template['placeholder']) == 1
        text = text.replace(template['placeholder'], str(library))
        ast.parse(text)
        restored = text.replace(str(library), template['placeholder'])
        assert restored == (out / 'native_screen.py.in').read_text()
        assert ast.dump(ast.parse(restored)) == ast.dump(ast.parse((out / 'native_screen.py.in').read_text()))
        staged.append((mode, out, template, text, library))
    bindings = {}
    for mode, out, template, text, library in staged:
        (out / 'native_screen.py').write_text(text)
        (out / 'run.py').write_bytes((out / 'run.py.in').read_bytes())
        original = Path(template['origin']) / 'native_screen.py'
        (out / 'sealed-adaptation.patch').write_text(''.join(difflib.unified_diff(
            original.read_text().splitlines(True), text.splitlines(True),
            fromfile=str(original), tofile=str(out / 'native_screen.py'))))
        report = {'status': 'passed', 'prepared_not_executed': True,
                  'scope': template['scope'].replace('Candidate source/build/library bindings remain pending; no targets executed.',
                                                     'Completed source/build/library bindings verified; no targets executed by preparation.'),
                  'template_preparation_sha256': sha(out / 'template-preparation.json'),
                  'source_manifest_sha256': args.source_manifest_sha256, 'build_freeze_sha256': args.build_freeze_sha256,
                  'build_proof_sha256': sha(BUILD / 'vector-training-proof.json'),
                  'controller_sha256': sha(out / 'native_screen.py'), 'wrapper_sha256': sha(out / 'run.py'),
                  'control_library': template['control_library'], 'expat_library': template['expat_library'],
                  'candidate_library': {'path': str(library), 'sha256': sha(library)},
                  'seal_controller_sha256': sha(__file__)}
        save(out / 'adaptation.json', report)
        bindings[mode] = {'adaptation_sha256': sha(out / 'adaptation.json'), 'controller_sha256': report['controller_sha256'],
                          'sealed_adaptation_patch_sha256': sha(out / 'sealed-adaptation.patch')}
    save(ROOT / 'sealed-build-binding.json', {'status': 'sealed_no_targets_executed',
         'preparation_sha256': args.preparation_sha256, 'source_manifest_sha256': args.source_manifest_sha256,
         'build_freeze_sha256': args.build_freeze_sha256, 'build_metadata': metadata,
         'source_files': len(source_map), 'source_delta': delta, 'modes': bindings})
    print(json.dumps({'status': 'sealed_no_targets_executed', 'binding_sha256': sha(ROOT / 'sealed-build-binding.json'), 'modes': bindings}, indent=2))


if __name__ == '__main__':
    main()
