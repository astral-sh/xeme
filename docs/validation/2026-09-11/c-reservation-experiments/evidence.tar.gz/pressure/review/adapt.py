"""Adapt the completed capacity raw reader; do not execute benchmark targets."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = Path('/tmp/oriole-arena-capacity-bound-native-review')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def adapt(name, replacements):
    original = (OLD / name).read_text()
    source = original
    for before, after in replacements:
        assert source.count(before) == 1, (name, before, source.count(before))
        source = source.replace(before, after)
    restored = source
    for before, after in reversed(replacements):
        assert restored.count(after) == 1, (name, after, restored.count(after))
        restored = restored.replace(after, before)
    assert restored == original and ast.dump(ast.parse(restored)) == ast.dump(ast.parse(original))
    ast.parse(source)
    with (ROOT / name).open('x') as output:
        output.write(source)
    with (ROOT / (name + '.adaptation.patch')).open('x') as output:
        output.write(''.join(difflib.unified_diff(original.splitlines(True), source.splitlines(True),
                     fromfile=str(OLD / name), tofile=str(ROOT / name))))
    return {'original_sha256': sha(OLD / name), 'adapted_sha256': sha(ROOT / name),
            'replacement_pairs': replacements, 'inverse_text_equal': True, 'inverse_ast_equal': True}


original = (OLD / 'audit.py').read_text()
old_proof = original[original.index(" proof_path=Path("):original.index(" for name,digest in source['source_sha256'].items():")]
new_proof = """ proof_path=Path('/tmp/oriole-c-reparse-build-independent-review/review.json');proof=read(proof_path);pair=read(B/'pair-report.json')
 assert sha(proof_path)=='498a556b6ff689fa015efb7fd1d9251ba40cbb83146606bfae39702ec88bf9c5'
 assert proof['status']=='passed_independent_saved_build_review' and proof['findings']==[] and not proof['targets_executed']
 assert proof['pins']['source.json']==sha(B/'source.json')=='eae0483cefd1932c006bdf969ade237e80648400aa7acf5d117b3539db4c86a9'
 assert proof['pins']['pair-report.json']==sha(B/'pair-report.json')=='667a0b22cf5a4a9867a3a21fdbf1728e2aee37dd8ae989409235e71895344fd8'
 assert proof['pins']['pair-freeze.json']==sha(B/'pair-freeze.json')=='5fce84f6d59d672e85cf9a586f4914b1feecccef2ce95b9bb5586aefe4b44031'
 source=read(B/'source.json');assert len(source['source_sha256'])==72
 assert source['candidate_base_commit']=='60b3a0f92e3eec9dce17b9e500079a5d0c20f7e5' and source['base_runtime']=='de859c89577b2982d59b6923d682032f6a7c7800'
 assert proof['full_source_files']==72 and proof['pipeline_source_files']==69 and proof['fresh_full_compiler_vectors']==9 and proof['generated_candidate_rows']==864
 expected_delta=['crates/oriole/src/context_text_tests.rs','crates/oriole/src/dtd.rs','crates/oriole/src/lib.rs','crates/oriole_expat/src/lib.rs','crates/oriole_expat/src/tests.rs']
 assert proof['exact_changed_source_files']==read(B/'source-delta.json')['changed_files']==expected_delta
 binding_path=S.parent/'sealed-build-binding.json';binding=read(binding_path)
 assert sha(binding_path)=='c9dcb849787dfb1c522de5a630c538230c86783cdaf56c7e256a4924bbf334e5'
 assert binding['source_manifest_sha256']==sha(B/'source.json') and binding['build_freeze_sha256']==sha(B/'pair-freeze.json')
 assert binding['source_delta']==expected_delta and binding['source_files']==72
 assert binding['modes'][phase]['controller_sha256']==sha(new) and binding['modes'][phase]['adaptation_sha256']==sha(S/'adaptation.json')
 for path,digest in binding['build_metadata'].items():assert sha(path)==digest;inputs[path]=digest
 pin(binding_path)
"""
reports = {}
reports['audit.py'] = adapt('audit.py', [
    ('Reviewer authored the prepared native adapters but did not author the current build adapter or collect build/elapsed results.',
     'Reviewer adapted the native templates and raw reader and independently reviewed build evidence; did not author the runtime fix/build adapter or collect build/elapsed results.'),
    (" S=Path('/tmp/oriole-arena-capacity-bound-native-study')/phase; T=Path('/tmp/oriole-context-text-frame-fixed-native-study')/phase; D=S/'native-screen'",
     " S=Path('/tmp/oriole-c-reparse-pressure-native-study')/phase; T=Path('/tmp/oriole-arena-capacity-bound-native-study')/phase; D=S/'native-screen'"),
    (" A=read(S/'adaptation.json');B=Path('/tmp/oriole-arena-capacity-bound-pgo-study')", " A=read(S/'adaptation.json');B=Path('/tmp/oriole-c-reparse-pressure-pgo-study')"),
    (old_proof, new_proof),
    ("report['decision']='Mandatory capacity repair. All adverse conditions retained; no advance speed, full compatibility or hardware-mechanism claim.'",
     "report['decision']='C reparse-pressure scheduling candidate remains subject to separate compatibility and consumer gates. All adverse conditions retained; no advance speed, full compatibility or hardware-mechanism claim.'"),
    ("Matched O3 ThinLTO normal and fresh original-G PGO. Source72 contains arena.rs repair/regression plus separately inherited PR133 tests/c/integration.c versus selected Context control; compiled69 differs only in arena.rs; allocator e1 bytes unchanged. Independent candidate build readback binds9vectors and864training rows; native adapter authorship is disclosed. No deferred-raw, B/additive-real or BOLT composition.",
     "Matched O3 ThinLTO normal and fresh original-G PGO. Source72 and pipeline69 each differ from selected capacity control in five files: three runtime files and two test modules; C fixtures and allocator are unchanged. Independent candidate build readback binds9vectors and864training rows; native adapter authorship is disclosed. No additional training or BOLT composition."),
    ('original full worker/sample/condition/seeded order/callback/median/ratio reconstruction is byte-identical to the completed CDATA reader, with per-phase execution and source/worker hash binding added.',
     'original full worker/sample/condition/seeded order/callback/median/ratio reconstruction is byte-identical to the completed capacity reader; only study, build/source proof binding, and accurate scope text changed.'),
])
adapted = (ROOT / 'audit.py').read_text()
start = " ordinal=0; medians={}; obs={}; samples_count=0"
end = " A=read(S/'adaptation.json')"
assert original[original.index(start):original.index(end)] == adapted[adapted.index(start):adapted.index(end)]
reports['audit.py']['raw_worker_sample_order_statistics_block_byte_exact'] = True
reports['combine.py'] = adapt('combine.py', [
    ('The capacity repair is mandatory. All adverse conditions are retained; generated controls remain separate from project results.',
     'The C reparse-pressure candidate requires separate compatibility and consumer gates. All adverse conditions are retained; generated controls remain separate from project results.'),
    ('# Capacity-fix native results', '# C reparse-pressure native results'),
    ('This mandatory correctness fix is not rejected on the basis of a small timing difference.',
     'These measurements quantify the scheduling change against the selected capacity parent; they do not decide its compatibility or consumer gates.'),
])
with (ROOT / 'reader-adaptation.json').open('x') as output:
    json.dump({'status': 'prepared_saved_reader_no_execution', 'original_directory': str(OLD), 'files': reports}, output, indent=2)
    output.write('\n')
print(json.dumps({'status': 'prepared_saved_reader_no_execution', 'audit_sha256': sha(ROOT / 'audit.py'),
                  'adaptation_sha256': sha(ROOT / 'reader-adaptation.json')}, indent=2))
