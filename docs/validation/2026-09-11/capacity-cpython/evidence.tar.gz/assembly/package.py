"""Archive completed CPython records without compiled binaries or caches."""
from pathlib import Path
import csv
import gzip
import hashlib
import io
import json
import os
import tarfile

assert os.sched_getaffinity(0) == {6}
STUDY = Path('/tmp/oriole-arena-capacity-bound-python-study')
REVIEW = Path('/tmp/oriole-capacity-python-elapsed-independent-review')
OUT = Path('/tmp/oriole-arena-capacity-bound-python-publication')
assert not OUT.exists()
entries = {}
excluded = []
symlinks = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def add(path, name):
    path = Path(path)
    assert name not in entries
    if path.is_symlink():
        symlinks.append({'path': name, 'target': os.readlink(path)})
        return
    data = path.read_bytes()
    record = {'path': name, 'original': str(path), 'bytes': len(data), 'sha256': sha(data)}
    if data.startswith(b'\x7fELF') or path.suffix in ('.a', '.profraw', '.profdata'):
        excluded.append(record)
    else:
        entries[name] = (record, data)


def tree(root, prefix):
    for path in sorted(root.rglob('*')):
        if path.is_file() or path.is_symlink():
            assert '__pycache__' not in path.parts
            add(path, prefix + '/' + str(path.relative_to(root)))


reports = {}
for mode in ('normal', 'pgo'):
    controller = json.loads((STUDY / mode / 'time-controller.json').read_text())
    assert controller['status'] == 'passed'
    report = json.loads((REVIEW / (mode + '-review.json')).read_text())
    assert report['status'] == 'passed_independent_raw_elapsed_reconstruction'
    assert report['counts']['all_workers'] == 576
    assert report['counts']['all_samples'] == 26364
    reports[mode] = report
assert (STUDY / 'root-execution.json').is_file()
for path, digest, status in (
    (Path('/tmp/oriole-capacity-python-independent-preflight-review.json'),
     '172385ca2d471dc21dce5f516e252206dac5d3f9548829f2781cd0afe26d3066',
     'passed_independent_source_build_preflight_review'),
    (Path('/tmp/oriole-capacity-python-protocol-review/review.json'),
     '4c59d062677fec3f7c839c8a3220f2981bb121ed6ae61a7f85e228a05cbc115b',
     'passed'),
):
    assert sha(path.read_bytes()) == digest
    assert json.loads(path.read_text())['status'] == status
tree(STUDY, 'study')
tree(REVIEW, 'review/elapsed')
tree(Path('/tmp/oriole-capacity-python-protocol-review'), 'review/protocol')
tree(Path('/tmp/oriole-capacity-python-packaging-source-review'), 'review/packaging')
for path in sorted(Path('/tmp').glob('oriole-capacity-python-independent-preflight-review*')):
    assert path.is_file()
    add(path, 'review/preflight/' + path.name)
for label, root in (
    ('capacity', Path('/tmp/oriole-arena-capacity-bound-pgo-study')),
    ('context', Path('/tmp/oriole-context-text-frame-fixed-pgo-study')),
):
    for name in ('source.json', 'source.tar.gz', 'source-delta.json', 'pair-report.json',
                 'pair-freeze.json', 'vector-training-proof.json'):
        add(root / name, 'builds/' + label + '/' + name)
for name in ('LICENSE-APACHE', 'LICENSE-MIT'):
    add(Path('/home/dev-user/code/oss/oriole-arena-capacity-bound') / name, 'notices/oriole/' + name)
add('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/LICENSE', 'notices/cpython/LICENSE')
add(__file__, 'assembly/package.py')

OUT.mkdir()
index = {
    'format': 1,
    'scope': 'Full original JSON reports, raw compressed worker streams, worker specifications, '
             'controllers, independent reviews and selected/control source archives. No report '
             'rows are removed or reconstructed by packaging. Binary identities are excluded '
             'explicitly; original preflight review checked their actual bytes. Build freeze '
             'members beyond the listed metadata remain in the separately published build evidence.',
    'files': [row for row, _ in entries.values()],
    'excluded_binaries': excluded,
    'excluded_symlinks': symlinks,
}
(OUT / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
with (OUT / 'evidence.tar.gz').open('xb') as file:
    with gzip.GzipFile(fileobj=file, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as archive:
            for name, (_, data) in sorted(entries.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
with (OUT / 'conditions.csv').open('x', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(['build', 'project', 'chunk_bytes', 'consumer', 'candidate_over_control',
                     'candidate_over_expat', 'control_over_expat'])
    for mode, report in reports.items():
        for row in report['summary']:
            c, ratios = row['condition'], row['median_ratios']
            writer.writerow([mode, c['name'], c['chunk'], c['mode'],
                             ratios['candidate_over_control'], ratios['candidate_over_expat'],
                             ratios['control_over_expat']])
summary = {'status': 'assembled', 'candidate': 'de859c89577b2982d59b6923d682032f6a7c7800',
           'control': '0f28139f83b04290e62301c38d8ed489f183a88d',
           'modes': {mode: {'counts': r['counts'], 'aggregates': r['aggregates'],
                            'libraries': r['libraries']} for mode, r in reports.items()},
           'archive_files': len(entries), 'excluded_binary_files': len(excluded),
           'evidence_sha256': sha((OUT / 'evidence.tar.gz').read_bytes()),
           'index_sha256': sha((OUT / 'index.json').read_bytes())}
(OUT / 'report.json').write_text(json.dumps(summary, indent=2) + '\n')
(OUT / 'replay.py').write_bytes((REVIEW / 'audit.py').read_bytes())
print(json.dumps({'files': len(entries), 'excluded': len(excluded),
                  'archive_bytes': (OUT / 'evidence.tar.gz').stat().st_size,
                  'archive_sha256': summary['evidence_sha256']}, indent=2))
