"""Independent source/compiler-record/raw-preflight readback; no targets."""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import math
import os
assert os.sched_getaffinity(0) == {6}

R=Path('/tmp/oriole-arena-capacity-bound-python-study');pins={}
def read(p):
    p=Path(p);b=p.read_bytes();pins[str(p)]=hashlib.sha256(b).hexdigest();return b
def sha(p):read(p);return pins[str(Path(p))]
def load(p):return json.loads(read(p))
def check(mapping):
    for p,h in mapping.items():assert sha(p)==h,p
top=load(R/'preparation.json')
assert sha(R/'preparation.json')=='3f0c91fa9eaac048a802da48e540193e8562d0cd229cb07a1b7404b1e7112cb8'
python='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
upstream=Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13').resolve()
header='/home/dev-user/code/oss/oriole-arena-capacity-bound/include'
inc='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/include/python3.12'
suffix='.cpython-312-x86_64-linux-gnu.so';result={};outputs_by_mode={}
for mode in ('normal','pgo'):
    D=R/mode;S=D/'screen';prep=load(D/'preparation.json');a=load(D/'adaptation.json');parent=Path(prep['parent'])
    check(load(D/'preparation-freeze.json')['files'])
    assert a['source_runtime_control']=='0f28139f83b04290e62301c38d8ed489f183a88d' and a['source_runtime_candidate']=='de859c89577b2982d59b6923d682032f6a7c7800'
    for key in ('candidate_source_manifest','candidate_pair_freeze','selected_control_source_manifest','selected_control_pair_freeze'):
        v=a[key];assert sha(v['path'])==v['sha256']
    candidate=load(a['candidate_source_manifest']['path'])['source_sha256'];control=load(a['selected_control_source_manifest']['path'])['source_sha256']
    assert len(candidate)==len(control)==72
    delta={f:{'control':control.get(f),'candidate':candidate.get(f)} for f in candidate.keys()|control.keys() if candidate.get(f)!=control.get(f)}
    assert delta==a['source_delta']==prep['source_delta']
    assert set(delta)=={'crates/oriole/src/arena.rs','tests/c/integration.c'}
    assert candidate['crates/oriole_storage/src/allocator.rs']==control['crates/oriole_storage/src/allocator.rs']=='910ce7ead099bd6a306a037c77fa276f746ac0eac59f14d8bda9b9b1c2deeac7'
    for name,h in a['files'].items():assert sha(D/name)==h
    for name,h in a['parent_files'].items():assert sha(parent/name)==h
    for name,change in prep['controller_changes'].items():
        before=read(parent/name).decode();after=read(D/name).decode();reverse=after
        for old,new in reversed(change['replacements']):
            assert reverse.count(new)==1
            reverse=reverse.replace(new,old)
        assert reverse==before and ast.dump(ast.parse(reverse),include_attributes=False)==ast.dump(ast.parse(before),include_attributes=False)
        read(D/(name+'.patch'))
    assert read(D/'python_worker.py')==read(parent/'python_worker.py')
    assert sha(a['header']['path'])==a['header']['sha256']==candidate['include/expat.h']==control['include/expat.h']
    for v in a['consumer_source']['files'].values():assert sha(v['path'])==v['sha256']
    check(a['consumer_source']['interpreter_and_public_headers'])
    libs=a['libraries']
    for v in libs.values():assert sha(v['path'])==v['sha256']
    c=load(D/'prepare-controller.json');b=load(D/'consumers/build.json');p=load(S/'preflight.json')
    assert c['status']=='passed' and c['controller_sha256']==sha(D/'run.py') and len(c['jobs'])==2
    for job in c['jobs']:
        assert job['exit']==0 and job['timeout_seconds']==600 and job['command'][:6]==['taskset','-c','3',python,'-I','-S'] and 'exception' not in job
        assert sha(D/(job['label']+'-controller.log'))==job['log_sha256']
    assert b['status']=='passed' and b['adaptations'] is None and b['cpython_revision']=='3bb231a6a5dc02b95658877318bf61501a7209e9'
    assert b['source_sha256_before']==b['source_sha256_after'];check(b['source_sha256_before'])
    assert b['source_sha256_before'][str(upstream/'Modules/pyexpat.c')]=='fd679a16f36304444af11953ad276d4493f2044f904a39b8fdf028c6f7def8a0'
    assert set(b['consumers'])=={'control','candidate','expat'}
    origins={};compiles=[]
    for engine,consumer in b['consumers'].items():
        directory=D/'consumers'/engine;library=directory/Path(libs[engine]['path']).name
        assert consumer['directory']==str(directory) and consumer['library']==str(library)
        assert sha(library)==libs[engine]['sha256'];check(consumer['files'])
        assert set(consumer['files'])=={str(library),*(str(directory/(m+suffix)) for m in ('pyexpat','_elementtree'))}
        for module,command in zip(('pyexpat','_elementtree'),consumer['commands'],strict=True):
            expected=['cc','-shared','-fPIC','-O2',*['-I'+x for x in (header,inc,inc+'/internal',str(upstream/'Modules/expat'),str(upstream/'Modules'))],str(upstream/('Modules/'+module+'.c')),str(library),'-Wl,-rpath,'+str(directory),'-o',str(directory/(module+suffix))]
            assert command['command']==expected and command['returncode']==0 and command['log_sha256']==sha(directory/(module+'-build.log'))
            compiles.append(expected)
        origins[engine]={m:{'path':str(directory/(m+suffix)),'sha256':sha(directory/(m+suffix))} for m in ('pyexpat','_elementtree')}
        origins[engine]['parser_library']={'path':str(library.resolve()),'sha256':libs[engine]['sha256']}
        origins[engine]['expat_version']='expat_2.8.4' if engine=='expat' else 'oriole_compat_2.8.4'
    assert len(compiles)==6
    assert p['status']=='preflight_passed' and p['kind']=='python' and p['affinity']==[3] and p['seed']==202609104412 and p['pairs']==7
    assert p['hashes_before']==p['hashes_after'] and p['hash_errors']=={};check(p['hashes_before'])
    assert p['conditions']==prep['conditions'] and len(p['conditions'])==24 and len(p['preflights'])==len(p['processes'])==72 and p['rows']==[]
    assert p['conditions']==load(parent/'screen/preflight.json')['conditions']
    expected_outputs={}
    for index,(row,process) in enumerate(zip(p['preflights'],p['processes'],strict=True)):
        condition=p['conditions'][index//3];engine=['control','candidate','expat'][index%3]
        key=f"{condition['name']}/{condition['chunk']}/{condition['mode']}";label=key.replace('/','-')+'-'+engine+'--1-0'
        assert row['key']==key and row['engine']==engine and row['pair']==-1 and row['median_seconds'] is None and row['process']==label
        assert process['label']==label and process['status']=='passed' and process['returncode']==0 and process['timeout_seconds']==300
        specpath=S/(label+'.json')
        assert process['command']==[python,'-I','-S',str(D/'python_worker.py'),'--worker',str(specpath)]
        assert load(specpath)=={'input':condition['input'],'input_sha256':sha(condition['input']),'chunk':condition['chunk'],'mode':condition['mode'],'consumer':str(D/'consumers'/engine),'library_sha256':libs[engine]['sha256'],'iterations':0}
        for stream in ('stdout','stderr'):assert sha(S/process[stream])==process[stream+'_sha256']
        assert gzip.decompress(read(S/process['stderr']))==b''
        raw=json.loads(gzip.decompress(read(S/process['stdout'])))
        assert raw['identity']==row['identity']==origins[engine] and raw['samples']==row['samples']
        assert raw['gc_enabled'] is True and raw['python']==b['python']==p['python_version'] and len(raw['samples'])==1
        sample=raw['samples'][0]
        assert sample['iteration']==0 and sample['warmup'] is True and sample['parse_ns']>0 and sample['destruction_ns']>=0
        assert math.isfinite(sample['seconds']) and sample['seconds']==(sample['parse_ns']+sample['destruction_ns'])/1e9
        canonical=[sample['output_sha256'],sample['output_rows']];assert canonical[1]>0
        if key in expected_outputs:assert expected_outputs[key]==canonical
        else:expected_outputs[key]=canonical
    assert expected_outputs==p['expected']==load(parent/'screen/preflight.json')['expected']
    outputs_by_mode[mode]=expected_outputs
    result[mode]={'libraries':libs,'extension_compiles':6,'exact_compile_vectors':compiles,'preflight_workers':72,'canonical_conditions':24,'raw_warmup_samples':72,'origins':origins,'all_canonical_outputs_equal_Expat_and_prior_Context':True,'build_manifest_sha256':sha(D/'consumers/build.json'),'preflight_sha256':sha(S/'preflight.json')}
assert outputs_by_mode['normal']==outputs_by_mode['pgo']
read('/tmp/oriole-capacity-python-protocol-review/review.json');read('/tmp/oriole-capacity-python-protocol-review.py');read(__file__)
out={'status':'passed_independent_source_build_preflight_review','role':'Independent saved-data reader; no consumer imports, compiler, parser or elapsed commands executed.',
'scope':'Normal and fresh G-only PGO parser artifacts with unmodified CPython3.12.13 extension sources. This is separate from the cleanup-patched strict consumers. Active elapsed files were not read.',
'reviewer_attempts':'First independent reader for this capacity-fixed preparation. Previous Context reader was adapted with recorded source/path/caption changes; all original target outcomes preserved.',
'modes':result,'findings':[],'source_delta':'Only arena.rs changes in Rust runtime; tests/c/integration.c inherits the PR133 stage-aware OOM fixture. Both archives contain72source files; allocator provenance fix is byte-identical.',
'checks':['Exact Context worker; wrapper changes only byte-identical header path, builder one caption, screen five captions; reverse-text and AST equality checked.','All twelve recorded shared -fPIC -O2 extension compiler vectors, source/input/library/header and copied module hashes checked.','All144 raw workers bind XML_Parse dladdr and both module identities; every canonical output equals Expat and prior Context. Same24conditions/7pairs/seed and bounds.'],
'limitations':['No performance result or full compatibility claim. Each preflight is one untimed-for-analysis warmup parse; its elapsed field is validated for shape, not reported as a benchmark.','Parser modes and independent generated-only PGO are pinned by adaptations/build receipts. Extensions themselves remain -O2 and receive no new profile training.','Canonical benchmark output coalesces adjacent text callbacks; exact callback-boundary compatibility belongs to separate strict gates.','Host Python already has its own PGO/ThinLTO/BOLT configuration; this experiment changes only the linked parser and freshly built extensions.'],
'evidence_sha256':dict(sorted(pins.items()))}
dest=Path('/tmp/oriole-capacity-python-independent-preflight-review.json');dest.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'sha256':sha(dest),'compiles':12,'raw_workers':144,'pinned_files':len(pins)},indent=2))
