# Capacity-bound CPython benchmark preparation

The saved-data preparer passed on its first attempt. It ran on CPU6 with pinned CPython 3.12.13, `-I -S`; its child process exited 0 and was reaped. No extension compilation, parser preflight or elapsed benchmark has run in this directory. Root review and CPU release precede those phases.

The candidate is capacity-fixed `de859c89577b2982d59b6923d682032f6a7c7800`, the control is Context `0f28139f83b04290e62301c38d8ed489f183a88d`, and Expat 2.8.4 is the unchanged third engine. Both original source archives contain 72 verified files. Only `arena.rs` differs in the measured Rust runtime; the full inventory also includes the inherited PR133 `tests/c/integration.c` fixture change. The preparer verified all 83 candidate and 76 control files in their build freezes, the saved nine-compiler-vector and G288 proofs, both archives, and the current candidate source inventory. This is preparation readback, not an independent audit of the original compiler proof.

## Exact inherited protocol

Normal and PGO remain separate studies. Each has six original XML inputs, 24 conditions, three engines, six freshly built extensions, 72 origin/canonical preflights, seven pairs, seed `202609104412`, 504 timed workers, 25,788 measured parses and 504 discarded warmups. The conditions, project iteration counts, namespace behavior, scheduling, GC behavior, canonical output checks, timer boundaries and failure cleanup are inherited unchanged.

The original unmodified CPython `pyexpat.c` and `_elementtree.c` hashes are checked before preparation. Their clean checkout is pinned to `3bb231a6a5dc02b95658877318bf61501a7209e9`. These benchmark modules use no strict-suite cleanup backport. `python_worker.py` is byte-identical to the Context study. The builder changes one report string; the screen changes five caption strings; the phase controller changes only the path to the byte-identical common header. Every substitution has an exact reverse-text and AST check in `preparation.json`; all file diffs are retained alongside the files. `prepare.py.patch` shows the preparer changes against its original Context source.

Oriole uses `-O3`, ThinLTO and one codegen unit in both modes. Its PGO artifacts were separately trained on the original generated corpus. Expat uses its pinned corresponding normal or PGO artifact. Fresh extension compilation remains identical `-O2` without extension PGO/LTO. Project XML inputs remain held out of profile training.

Strict compatibility is evaluated separately; the Context baseline has two known callback-grouping failures. This benchmark measures unmodified CPython consumers of real project fixtures, rather than complete project executions.

## Held execution commands

After root review, run each preparation serially on CPU3. Preparation retains the original 600-second build and 600-second aggregate preflight limits.

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-arena-capacity-bound-python-study/normal/run.py prepare
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-arena-capacity-bound-python-study/pgo/run.py prepare
```

After successful preparation, saved-data review and root CPU0 release, run normal then PGO serially. Each timed worker retains its 300-second limit and each aggregate study retains its 1,200-second limit.

```sh
taskset -c 0 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-arena-capacity-bound-python-study/normal/run.py time
taskset -c 0 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-arena-capacity-bound-python-study/pgo/run.py time
```

The inherited controllers invoke the `python3` alias internally. The preparer verifies that alias and `python3.12` are the same executable, SHA-256 `021044895e95be79dc2f110367607e684119afbc8ce75f6f0eec94844e0acec7`.

## Preparation receipt

- `prepare.py`: `c7d35c978542731f14b29853ff2e1cc311967c2d4033c34138a9ac69ab5b94c6`
- `preparation.json`: `3f0c91fa9eaac048a802da48e540193e8562d0cd229cb07a1b7404b1e7112cb8`
- `preparation-attempt01.json`: `022b768e3e2bb50817973ef0e57663d7dead81ff5bc1134ea094315257f9f72f`
- Normal adaptation: `71ef04dabc8fa557c8577cba2cda2fd28741bba4fa6032c71e7df8eb40f7cba2`
- PGO adaptation: `4f1b4fcc331d2918d8b4d6433eece1295b5a08ae121b94abd02c440714c96577`

The first preparer stdout, empty stderr, timestamps, exact argv and exit status are preserved. No repository file was edited. Every process launched for preparation completed and was reaped; no target session is outstanding.
