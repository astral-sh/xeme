"""Pin the inherited unmodified CPython protocol using saved data only."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import subprocess
import sys
import tarfile

assert os.sched_getaffinity(0) == {6}
assert sys.version_info[:3] == (3, 12, 13)
OUT = Path(__file__).parent
PARENT = Path('/tmp/oriole-context-text-frame-fixed-python-study')
REPO = Path('/home/dev-user/code/oss/oriole-arena-capacity-bound')
PAIR = Path('/tmp/oriole-arena-capacity-bound-pgo-study')
CONTROL = Path('/tmp/oriole-context-text-frame-fixed-pgo-study')
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
CPYTHON = Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13')
FILES = ['build_consumers.py', 'consumer_screen.py', 'python_worker.py', 'run.py']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def pin(path):
    return {'path': str(path), 'sha256': sha(path)}


def save(path, value):
    with Path(path).open('x') as handle:
        handle.write(json.dumps(value, indent=2) + '\n')


def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


fixed = {
    PAIR / 'source.json': '169d9e55352ab2235fed31a1e34b2a0e2c562172fa203d455cc8bad51e80ad0f',
    PAIR / 'pair-report.json': '3d9dc4a32ee0cd08d0f5b8c1f74f23f2694eec8259f7aeb491a8108eda51fedd',
    PAIR / 'pair-freeze.json': '6580be9b4c5ac768747eb56e6cb4ed4130c3228401ce06e20f6c5e6e64ead598',
    PAIR / 'source-delta.json': '6c13908e0d6b10deb2eaccee5ab1eaaf7a07747d31fb6d464cdce89de78cbc18',
    PAIR / 'vector-training-proof.json': '721863e444675748be35fe8424ca9892ba69f52c7dde531b6d56b5771b2d00e4',
    CONTROL / 'source.json': '8a7da2759b67ca85f82fb29bd775392e532b3ff355340eb10f92ea7764bbe642',
    CONTROL / 'pair-report.json': 'a28db6054469a0573392958a970ccec11556da27adf87aebc3b99d9e60485dda',
    CONTROL / 'pair-freeze.json': '9e21b1c0946ac2c19bda62b533bcd498103077a81924e98ccb97c63bcbfa92ac',
    CONTROL / 'vector-training-proof.json': '258d92c6ffa0ade6438544275ba3f2482c8e249c468440ecf17382db53892417',
    PARENT / 'prepare.py': '9dc65ce68451e8c6bb2fb3bf0fea33deb8ee48a2631ccfcc1250f551ede40efd',
    PARENT / 'normal/adaptation.json': 'a33faa6bd8fceec119cff0532c7d699193e59cf8800951d56a38595eedfdc046',
    PARENT / 'normal/preparation.json': 'fb81bfa89e5687ddd19690c74f65b9170ef0ac394470d5ae040c2ee72d8ace15',
    PARENT / 'pgo/adaptation.json': '2235e892b6a82a69ee2b064a1d90799d0759fe23930f72779e7ce72e3861dccf',
    PARENT / 'pgo/preparation.json': '223a4cfc2616d225bb49b4f7a06856fdf850ce53e95ba21e32da1d1a4ac67853',
}
assert all(sha(path) == digest for path, digest in fixed.items())
assert sha(PYTHON) == '021044895e95be79dc2f110367607e684119afbc8ce75f6f0eec94844e0acec7'
assert Path(PYTHON).samefile(Path(PYTHON).with_name('python3'))
source = load(PAIR / 'source.json')['source_sha256']
control_source = load(CONTROL / 'source.json')['source_sha256']
assert len(source) == len(control_source) == 72
assert set(source) == set(control_source)
assert all(sha(REPO / path) == digest for path, digest in source.items())
delta = {name: {'control': control_source[name], 'candidate': digest}
         for name, digest in source.items() if digest != control_source[name]}
assert set(delta) == set(load(PAIR / 'source-delta.json')['changed_files']) == {
    'crates/oriole/src/arena.rs', 'tests/c/integration.c'}
assert load(PAIR / 'source-delta.json')['runtime_changed_files'] == ['crates/oriole/src/arena.rs']
assert source['tests/c/integration.c'] == '88eae7992ed72f9bb039bbfb9a94b126b2dc0959bd2c7fb4234e55622b3264ca'
assert source['crates/oriole_storage/src/allocator.rs'] == control_source['crates/oriole_storage/src/allocator.rs']
pair_readback = {}
for pair, manifest in [(PAIR, source), (CONTROL, control_source)]:
    frozen = load(pair / 'pair-freeze.json')['files']
    for name, row in frozen.items():
        path = pair / name
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], path
    archive = pair / 'source.tar.gz'
    with tarfile.open(archive) as handle:
        members = handle.getmembers()
        assert len(members) == 72 and all(member.isfile() for member in members)
        assert {member.name for member in members} == set(manifest)
        for member in members:
            assert hashlib.sha256(handle.extractfile(member).read()).hexdigest() == manifest[member.name]
    proof = load(pair / 'vector-training-proof.json')
    assert proof['status'] == 'passed'
    assert proof['pair_report_sha256'] == sha(pair / 'pair-report.json')
    assert proof['source_sha256'] == sha(pair / 'source.json')
    assert proof['fresh_workspace_compilations'] == 9
    assert proof['all_candidate_rows_equal_each_other_and_prior_three_phases']
    report = load(pair / 'pair-report.json')
    assert report['generated_parse_records'] == {'normal': 288, 'instrumented': 288, 'optimized': 288}
    pair_readback[str(pair)] = {'frozen_files_verified': len(frozen), 'source_archive': pin(archive),
                              'source_archive_files_verified': 72, 'saved_vector_proof': pin(pair / 'vector-training-proof.json')}

git_reads = []
for checkout, expected in [(CPYTHON, '3bb231a6a5dc02b95658877318bf61501a7209e9'),
                           (REPO, 'de859c89577b2982d59b6923d682032f6a7c7800')]:
    for args in [['rev-parse', 'HEAD'], ['status', '--porcelain']]:
        command = ['git', '-C', str(checkout), *args]
        result = subprocess.run(command, capture_output=True, text=True, timeout=30)
        git_reads.append({'argv': command, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
        assert result.returncode == 0
        assert result.stdout.strip() == (expected if args[0] == 'rev-parse' else '')

studies = []
for mode in ['normal', 'pgo']:
    parent = PARENT / mode
    out = OUT / mode
    assert not out.exists()
    original = load(parent / 'adaptation.json')
    original_prep = load(parent / 'preparation.json')
    assert load(parent / 'prepare-controller.json')['status'] == 'passed'
    assert original['counts'] == {'conditions': 24, 'engines': 3, 'extensions': 6, 'preflights': 72,
        'cohorts': 168, 'pairs': 7, 'timed_workers': 504, 'measured_parses': 25788, 'warmups': 504}
    assert original['seed'] == 202609104412
    assert original['bounds'] == {'prepare_cpu': 3, 'timing_cpu': 0, 'build_seconds': 600,
        'preflight_aggregate_seconds': 600, 'worker_seconds': 300, 'timing_aggregate_seconds': 1200}
    assert all(sha(path) == digest for path, digest in original_prep['input_pins'].items())
    consumer = original['consumer_source']
    assert consumer['revision'] == '3bb231a6a5dc02b95658877318bf61501a7209e9'
    assert all(sha(row['path']) == row['sha256'] for row in consumer['files'].values())
    assert all(sha(path) == digest for path, digest in consumer['interpreter_and_public_headers'].items())
    assert consumer['files']['pyexpat.c']['sha256'] == 'fd679a16f36304444af11953ad276d4493f2044f904a39b8fdf028c6f7def8a0'
    assert consumer['files']['_elementtree.c']['sha256'] == 'de4c3c8716f7e3b1d2fdf077656246220ef0493053c990ca7b724ad31498fad0'
    header = pin(REPO / 'include/expat.h')
    assert header['sha256'] == original['header']['sha256'] == source['include/expat.h'] == control_source['include/expat.h']
    libraries = {'expat': original['libraries']['expat']}
    for engine, pair, relative in [
        ('control', CONTROL, 'normal' if mode == 'normal' else 'pgo/runs/run-n5eot_2d/use'),
        ('candidate', PAIR, 'normal' if mode == 'normal' else 'pgo/runs/run-lm4ku8q_/use')]:
        report = load(pair / 'pair-report.json')
        assert report['status'] == 'passed'
        libraries[engine] = pin(pair / relative / 'liboriole_expat.so')
        field, key = ('normal_libraries', 'liboriole_expat.so') if mode == 'normal' else ('pgo_libraries', 'use/liboriole_expat.so')
        assert libraries[engine]['sha256'] == report[field][key]
    assert all(sha(row['path']) == row['sha256'] for row in libraries.values())
    out.mkdir()
    modifications = {}
    for name in FILES:
        assert sha(parent / name) == original['files'][name]
        before = (parent / name).read_text()
        after = before
        replacements = []
        if name == 'run.py':
            replacements = [('/home/dev-user/code/oss/oriole-context-text-frame/include', str(REPO / 'include'))]
        elif name == 'build_consumers.py':
            old = ('Both Oriole parser libraries use C-only ThinLTO with no PGO; the Expat control uses no PGO or LTO.'
                   if mode == 'normal' else
                   'Both Oriole parser libraries use C-only ThinLTO with independent fresh generated-only PGO; the Expat control uses its verified generated-only PGO without LTO.')
            new = ('The Context control and capacity-fixed candidate use -O3, ThinLTO and one codegen unit without PGO; Expat 2.8.4 uses -O3 without PGO or LTO.'
                   if mode == 'normal' else
                   'The Context control and capacity-fixed candidate use -O3, ThinLTO, one codegen unit and independent original generated-corpus PGO; Expat 2.8.4 uses its matched generated-corpus PGO at -O3 without LTO.')
            replacements = [(old, new)]
        elif name == 'consumer_screen.py':
            replacements = [
                ('Matched corrected-allocator ContextText ' + mode + ' CPython screen', 'Matched capacity-fixed ' + mode + ' CPython screen'),
                ('Expected corrected allocator control, ContextText candidate and Expat engines', 'Expected Context control, capacity-fixed candidate and Expat engines'),
                ('explicit-host corrected allocator control and ContextText candidate', 'explicit-host Context control and capacity-fixed candidate'),
                ('Both Oriole libraries use C-only ThinLTO.', 'Both Oriole libraries use -O3, ThinLTO and one codegen unit.'),
                ('The corrected allocator runtime has two known strict CPython callback-grouping failures. At protocol preparation no fresh full strict CPython suite has run on this candidate; canonical fixture outputs must match Expat.',
                 'The Context baseline has two known strict CPython callback-grouping failures. Strict-suite compatibility is evaluated separately; every canonical fixture output in this benchmark must match Expat.'),
            ]
        for old, new in replacements:
            after = replace_once(after, old, new)
        reverse = after
        for old, new in reversed(replacements):
            reverse = replace_once(reverse, new, old)
        assert reverse == before
        assert ast.dump(ast.parse(reverse), include_attributes=False) == ast.dump(ast.parse(before), include_attributes=False)
        with (out / name).open('x') as handle:
            handle.write(after)
        if name == 'python_worker.py':
            assert (out / name).read_bytes() == (parent / name).read_bytes()
        with (out / (name + '.patch')).open('x') as handle:
            handle.write(''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                                   fromfile=str(parent / name), tofile=str(out / name))))
        modifications[name] = {'parent_sha256': sha(parent / name), 'candidate_sha256': sha(out / name),
                               'replacements': replacements, 'reverse_text_and_AST_exact': True}
    adaptation = {key: original[key] for key in ['status', 'mode', 'counts', 'bounds', 'seed', 'consumer_source']}
    adaptation.update(
        source_runtime_control='0f28139f83b04290e62301c38d8ed489f183a88d',
        source_runtime_candidate='de859c89577b2982d59b6923d682032f6a7c7800',
        candidate_source_manifest=pin(PAIR / 'source.json'), candidate_pair_freeze=pin(PAIR / 'pair-freeze.json'),
        selected_control_source_manifest=pin(CONTROL / 'source.json'), selected_control_pair_freeze=pin(CONTROL / 'pair-freeze.json'),
        libraries=libraries, header=header, source_delta=delta,
        runtime_source_delta=['crates/oriole/src/arena.rs'], inherited_fixture_delta=['tests/c/integration.c'],
        files={name: sha(out / name) for name in FILES}, parent_files={name: sha(parent / name) for name in FILES},
        parent_adaptation=pin(parent / 'adaptation.json'),
        proof='Exact Context benchmark worker. Only the common byte-identical header path and explicit report captions change in the controllers. Same 24 conditions, engines, namespace setting, original inputs, iterations, seven matched pairs, seed, bounds and timing boundaries. Fresh modules use unmodified CPython; strict cleanup-backport modules are separate and are not used.',
        parser_builds='Both Oriole modes use -O3, ThinLTO and codegen-units=1 on the same explicit x86_64 host target. PGO uses each runtime independently trained on the original generated G288 corpus. Expat uses its pinned matching normal/PGO library. Fresh CPython extensions use identical -O2 compilation without extension PGO or LTO.',
        execution_prerequisites='Root review and CPU3 release are required before fresh module compilation or parser preflights. CPU0 timing remains held pending successful preparation, independent saved-data review and root release.',
        execution_status='unexecuted')
    save(out / 'adaptation.json', adaptation)
    commands = {'prepare': ['taskset', '-c', '3', PYTHON, '-I', '-S', str(out / 'run.py'), 'prepare'],
                'time_held': ['taskset', '-c', '0', PYTHON, '-I', '-S', str(out / 'run.py'), 'time']}
    preparation = {'status': 'prepared_only', 'mode': mode, 'preparer': pin(__file__), 'parent': str(parent),
        'controller_changes': modifications, 'conditions': original_prep['conditions'],
        'counts': adaptation['counts'], 'bounds': adaptation['bounds'], 'seed': adaptation['seed'],
        'both_source_72_verified': True, 'source_delta': delta, 'consumer_and_selected_git_checks': git_reads,
        'input_pins': original_prep['input_pins'], 'commands': commands, 'adaptation': pin(out / 'adaptation.json')}
    save(out / 'preparation.json', preparation)
    save(out / 'preparation-freeze.json', {'status': 'prepared_only', 'files': {str(path): sha(path) for path in sorted(out.iterdir()) if path.is_file()}})
    studies.append({'mode': mode, 'directory': str(out), 'adaptation': pin(out / 'adaptation.json'),
                    'preparation': pin(out / 'preparation.json'), 'freeze': pin(out / 'preparation-freeze.json'), 'commands': commands})
assert all(sha(REPO / path) == digest for path, digest in source.items())
save(OUT / 'preparation.json', {'status': 'prepared_only', 'role': 'saved-data protocol preparer; not an independent audit',
    'source_and_pair_pins': {str(path): digest for path, digest in fixed.items()}, 'pair_readback': pair_readback,
    'studies': studies, 'controller': pin(__file__), 'git_reads': git_reads,
    'no_compilation_parser_or_elapsed_executed_by_preparation': True})
print(json.dumps({'preparation': pin(OUT / 'preparation.json'), 'studies': studies}, indent=2), flush=True)
