from pathlib import Path
from collections import Counter
import gzip,hashlib,json
R=Path('/tmp/oriole-cdata-finder-thin-pgo-gates');B=Path('/tmp/oriole-streaming-work-thin-pgo-gates-cpu5');W=Path('/home/dev-user/code/oss/oriole-cdata-finder')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
summary=j(R/'summary.json');assert summary['status']=='compatibility_gates_completed'
for p,v in j(R/'preparation.json')['before'].items():assert h(p)==v,p
for lane in ['api','other','end']:
 c=j(R/(lane+'-controller.json'));assert c['status']=='completed_zero_exits' and c['unchanged'] and c['before']==c['after']
 for row in c['jobs']:
  assert row['exit']==0 and row['timeout']==660
  for s in ['stdout','stderr']:assert h(R/(row['script'].replace('/','-')+'.'+s))==row[s+'_sha256']
raw=j(R/'api-native/upstream-api/results.json');base=j(B/'api-native/upstream-api/results.json')
assert raw==base and len(raw['results'])==4740 and raw['selection_complete'] and raw['library_origin_verified'] and not raw['timed_out']
outcomes=Counter(row['outcome'] for row in raw['results']);assert outcomes=={'pass':4347,'fail':391,'timeout':2}
assert [(r['test'],r['context']) for r in raw['results'] if r['outcome']=='timeout']==[('test_misc_input_2gb','chunksize=0 deferral=0'),('test_misc_input_2gb','chunksize=0 deferral=1')]
m=j(R/'api-native/upstream-api/manifest.json');assert [m[k] for k in ['per_test_seconds','per_test_address_space_bytes','per_test_rss_limit_bytes','total_timeout_seconds']]==[3,1073741824,805306368,240]
a=j(R/'api-native/report.json');assert len(a['commands'])==13 and a['commands'][0]['exit']==1 and all(row['exit']==0 for row in a['commands'][1:])
for p,v in a['native_sources'].items():assert h(p)==v
assert h(R/'api-native/native/integration.c')==h(W/'tests/c/integration.c')=='72162a4d080d2fd018023aed63181663090fc291772a45e121b51187b1fe28d7'
for linkage in ['dynamic','static']:
 assert '327 scenarios' in (R/'api-native'/('native-allocations-'+linkage+'.stdout')).read_text()
 for n in ['integration','adversarial','allocations']:assert (R/'api-native'/('native-'+n+'-'+linkage+'.stderr')).read_bytes()==b''
for d in ['api-native','other-gates','end-oom-final']:
 report=j(R/d/'report.json');assert report['unchanged']
 for row in report['commands']:
  for s in ['stdout','stderr']:assert h(R/d/(row['label']+'.'+s))==row[s+'_sha256']
d=R/'other-gates/differential';left,right=j(d/'reference.json'),j(d/'oriole.json');assert left==right and len(left['results'])==3318
assert right['results']==j(B/'other-gates/differential/oriole.json')['results'];assert j(d/'corpus.json')==j(B/'other-gates/differential/corpus.json')
aliases=j(R/'other-gates/report.json')['aliases'];assert sum(row['cases'] for row in aliases)==36456 and all(row['differences']==0 for row in aliases)
for name in ['full-events-comparison','external-semantic-comparison']:
 p=R/'other-gates/aliases'/(name+'.json');v=j(p);assert not v['differences'] and gzip.decompress((p.with_suffix('.json.gz')).read_bytes())==p.read_bytes()
malformed=[json.loads(line) for line in gzip.open(R/'malformed/observations.jsonl.gz','rt')];assert len(malformed)==2392 and all(row['candidate']==row['control'] for row in malformed)
oldmalformed=[json.loads(line) for line in gzip.open(B/'malformed/observations.jsonl.gz','rt')];assert malformed==oldmalformed
pub=json.loads(gzip.decompress((R/'publication-probe/observations.json.gz').read_bytes()));assert len(pub)==1304 and all(row['values']['candidate']==row['values']['baseline'] for row in pub)
oldpub=json.loads(gzip.decompress((B/'publication-probe/observations.json.gz').read_bytes()));assert pub==oldpub
pr=j(R/'publication-probe/report.json');assert pr['library_parses']==3912 and pr['hashes_before']==pr['hashes_after'] and not pr['hash_errors']
for origins in pr['origins_before_parses'].values():
 for v in origins:assert h(v['path'])==v['sha256']
assert sum(map(len,pr['origins_before_parses'].values()))==9
engines={n:j(R/'end-lifecycle-final'/(n+'.json')) for n in ['baseline','candidate','expat']}
for name,data in engines.items():
 assert data['status']=='passed' and data['library_unchanged'] and len(data['cases'])==38
 assert h(data['library'])==data['expected_sha256']==data['before_sha256']==data['after_sha256']
 for v in data['dladdr'].values():assert h(v['path'])==v['sha256']
 assert data['cases']==j(B/'end-lifecycle-final'/('candidate.json' if name=='baseline' else name+'.json'))['cases']
assert engines['candidate']['cases']==engines['baseline']['cases']
assert sum(a!=b for a,b in zip(engines['expat']['cases'],engines['baseline']['cases'],strict=True))==38
endrows={n:[json.loads(line) for line in (R/'end-oom-final'/(n+'.stdout')).read_text().splitlines()] for n in ['baseline','candidate']}
assert endrows['baseline']==endrows['candidate'] and len(endrows['candidate'])==37
assert endrows['candidate']==[json.loads(line) for line in (B/'end-oom-final/candidate.stdout').read_text().splitlines()]
assert len([r for r in endrows['candidate'] if r.get('summary')])==6 and all(r['live']==0 for r in endrows['candidate'] if r.get('summary'))
result={'status':'passed_exact_saved_outcomes','role':'Controller preparer and collector reconstructing saved outcomes; independent package review remains separate. No target reruns.','sessions':{'C_API':4085,'strict_CPython':78903},'first_attempts':True,'reviewer_attempts':'First reviewer expected a dict for publication origins; actual schema is a list. Corrected only iteration over that recorded list; first reviewer source/log retained, producer first attempts unchanged.','all_target_sessions_reaped':True,'summary_sha256':h(R/'summary.json'),'api':{'rows':4740,'outcomes':dict(outcomes),'all_raw_bytes_equal_streaming_baseline':True,'sha256':h(R/'api-native/upstream-api/results.json'),'raw_exit':1,'bounds':[3,1073741824,805306368,240]},'native':{'runs':6,'allocations_per_linkage':327,'current_integration_sha256':h(W/'tests/c/integration.c')},'strict_trace_rows':3318,'custom_alias_comparisons':36456,'malformed_rows':2392,'publication_cases':1304,'publication_parses':3912,'end_lifecycle_cases':38,'end_lifecycle_parses':114,'retained_reference_different_cases':38,'end_oom_rows_per_engine':37,'end_oom_scenarios':6,'strict_CPython_review_sha256':h('/tmp/oriole-cdata-finder-strict-outcome-review/review.json'),'findings':[],'limitations':summary['limitations']+['C ASan/UBSan wrappers only; Rust PGO release is uninstrumented and leak checking is disabled.','Custom successful raw pairs are absent from the unchanged helper; only existing counts/commands/difference reports can be checked.']}
out=Path('/tmp/oriole-cdata-finder-cgate-outcome-review.json');out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':h(out),'status':result['status']}))
