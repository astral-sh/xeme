"""Independent saved source/compiler/training audit; no target execution."""
from pathlib import Path
import hashlib,json,re,shlex,subprocess,tarfile
O=Path('/tmp/oriole-cdata-finder-pgo-study');B=Path('/tmp/oriole-streaming-work-pgo-study-attempt02');W=Path('/home/dev-user/code/oss/oriole-cdata-finder');S=Path('/tmp/oriole-cdata-finder-study')
load=lambda p:json.loads(Path(p).read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
f=load(O/'pair-freeze.json');assert sha(O/'pair-freeze.json')=='028ba513343c8e3b56f5de28a56e70889ff03f7f5b76517f64fa5f2ee4a339db'
assert len(f['files'])==f['count']==65
for name,v in f['files'].items():assert sha(O/name)==v['sha256'] and (O/name).stat().st_size==v['bytes'],name
c,a=load(B/'pair-report.json'),load(O/'pair-report.json');cm,am=[load(x['pgo_manifest']['path']) for x in (c,a)];cr,ar=Path(cm['run']),Path(am['run'])
assert a['status']==c['status']==am['status']==cm['status']=='passed'
assert sha(O/'pair-report.json')=='ae6bf35347662d2c9c4c57d8d475a90a0fbd295d4b4e572073ae9af15cb376cf'
assert all(a[k] for k in ('source_unchanged','scripts_unchanged','tools_unchanged'))
assert a['tools_before']==a['tools_after']==c['tools_before']
for key in ('cargo_config_sha256','base_rustflags','cargo_args','toolchain','host'):assert am[key]==cm[key],key
for root,pair,m in ((O,a,am),(B,c,cm)):
 assert sha(pair['pgo_manifest']['path'])==pair['pgo_manifest']['sha256']
 for command in pair['commands']:
  assert command['exit']==0 and sha(root/(command['label']+'.log'))==command['log_sha256']
 for command in m['commands']:
  assert command['status']=='passed' and command['returncode']==0
  assert sha(Path(m['run'])/command['log'])==command['log_sha256']
metadata={'oriole_storage':'8ae6edb74b4afbee','oriole':'e41f1ff64bd2ed1c','oriole_expat':'f10a79f8fbc60887'}
def read_vectors(root,pair,m,phase):
 log=root/'normal-build.log' if phase=='normal' else Path(m['run'])/next(c['log'] for c in m['commands'] if c['label']=='build-'+phase)
 rows={}
 for line in log.read_text().splitlines():
  if 'Running `' not in line or '--crate-name ' not in line:continue
  args=shlex.split(line.split('Running `',1)[1].rsplit('`',1)[0]);name=args[args.index('--crate-name')+1]
  if name not in metadata:continue
  assert name not in rows;rows[name]=args
 assert set(rows)==set(metadata)
 expected=pair['normal_vectors'] if phase=='normal' else pair['pgo_vectors'][phase]
 assert rows=={r['crate']:r['argv'] for r in expected}
 return rows
def canonical(args,name,run):
 assert args.count('opt-level=3')==1
 assert [s for s in args if s.startswith('metadata=')]==['metadata='+metadata[name]]
 assert args[args.index('--target')+1]=='x86_64-unknown-linux-gnu'
 kinds=[args[i+1] for i,v in enumerate(args[:-1]) if v=='--crate-type']
 assert kinds==(['cdylib','staticlib'] if name=='oriole_expat' else ['lib'])
 assert ('lto=thin' if name=='oriole_expat' else 'linker-plugin-lto') in args
 out=[]
 for s in args:
  s=s.replace(str(run),'<fresh-run>')
  s=re.sub(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}(?=/)', '<private-build>',s)
  s=re.sub(r'(?<=extra-filename=-)[0-9a-f]{16}$','<suffix>',s)
  s=re.sub(r'(lib\w+)-[0-9a-f]{16}(\.(?:rlib|rmeta))$',r'\1-<suffix>\2',s)
  out.append(s)
 return out
counts={}
for phase in ('normal','generate','use'):
 left=read_vectors(B,c,cm,phase);right=read_vectors(O,a,am,phase)
 for name in metadata:
  assert len(left[name])==len(right[name])
  assert canonical(left[name],name,cr)==canonical(right[name],name,ar),(phase,name)
 counts[phase]=len(right)
reference=load(B/'normal-training.json');training=[]
for root,pair,m in ((B,c,cm),(O,a,am)):
 for phase in ('normal','generate','use'):
  p=root/'normal-training.json' if phase=='normal' else Path(m['run'])/(phase+'-training.json');r=load(p)
  assert r['status']=='passed' and len(r['rows'])==288 and r['rows']==reference['rows']
  assert all(row['status']==1 and row['error']==0 and not row['callback_exceptions'] for row in r['rows'])
  assert r['inputs_sha256']==reference['inputs_sha256']
  assert sha(r['xml_parse_origin']['path'])==r['xml_parse_origin']['sha256']==r['library_sha256']
  if phase!='normal':assert sha(p)==m['training_sha256'][phase]
  training.append({'path':str(p),'sha256':sha(p),'rows':288})
assert {p.name:sha(p) for p in (ar/'inputs').iterdir()}=={p.name:sha(p) for p in (cr/'inputs').iterdir()}
for name,digest in am['profiles_sha256'].items():assert sha(ar/name if name=='merged.profdata' else ar/'raw-profiles'/name)==digest
assert am['profiles_sha256']['merged.profdata']!=cm['profiles_sha256']['merged.profdata']
source_record=load(O/'source.json');source=source_record['source_sha256'];baseline=load(B/'source.json')['source_sha256'];assert len(source)==70
assert {p for p in source if source[p]!=baseline[p]}=={'crates/oriole/src/lib.rs','tests/c/integration.c'}
assert all(sha(W/p)==v for p,v in source.items())
base=source_record['base_commit'];base_files={p:hashlib.sha256(subprocess.check_output(['git','show',base+':'+p],cwd=W)).hexdigest() for p in source}
assert [p for p in source if source[p]!=base_files[p]]==['crates/oriole/src/lib.rs']
patch=subprocess.check_output(['git','diff',base,'--','crates/oriole/src/lib.rs'],cwd=W)
assert patch==(O/'source.patch').read_bytes()==(S/'source.patch').read_bytes()
assert sha(O/'source.patch')=='92c66996463494d1dbb987ede3aeed4170e5c51ed5dcc8fca55e99fb2f1334f2'
assert sha(O/'source.json')==sha(S/'source.json')=='69b96121a090467b3cea81eb25a4e627976f1a18c4cab628855c9880dd25f982'
assert len(am['source_sha256'])==67 and 'tests/c/integration.c' not in am['source_sha256']
assert all(source[p]==v for p,v in am['source_sha256'].items())
assert {p for p in am['source_sha256'] if am['source_sha256'][p]!=cm['source_sha256'][p]}=={'crates/oriole/src/lib.rs'}
with tarfile.open(O/'source.tar.gz') as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==source
scripts=load(O/'tool-source.json');assert len(scripts)==6 and scripts==load(B/'tool-source.json') and all(sha(W/p)==v for p,v in scripts.items())
for name,digest in a['normal_libraries'].items():assert sha(O/'normal'/name)==digest
for name,digest in am['libraries_sha256'].items():assert sha(ar/name)==digest
checks=load(S/'checks-attempt01/results.json');assert checks['status']=='passed' and checks['source_unchanged']
for row in checks['commands']:
 assert row['exit']==0
 for stream in ('stdout','stderr'):assert sha(S/'checks-attempt01'/(row['label']+'.'+stream))==row[stream+'_sha256']
log=(S/'checks-attempt01/core.stdout').read_text();test_counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed; 0 failed;',log)];assert len(test_counts)==8 and sum(test_counts)==114
# Dependency source pins and actual compiled logging feature scope.
M=Path('/home/dev-user/.cache/toucan/cargo/registry/src/socket-firewall-registry.gateway.admin-0.internal.api.openai.org-42b3aaa0d2956984/memchr-2.8.3')
memchr_lines=[l for l in (O/'normal-build.log').read_text().splitlines() if '--crate-name memchr ' in l and 'Running `' in l];assert len(memchr_lines)==1 and 'feature="logging"' not in memchr_lines[0]
result={'status':'passed','role':'Independent agent source and saved-build review; candidate author and build collector were other agents. No target execution.','source_sha256':sha(O/'source.json'),'patch_sha256':sha(O/'source.patch'),'base_commit':base,'runtime_delta':['crates/oriole/src/lib.rs'],'inherited_fixture':{'path':'tests/c/integration.c','sha256':source['tests/c/integration.c'],'matches_base':True,'excluded_from_67_pipeline_inputs':True},'source_findings':['Same byte slice and fixed needle; pinned memchr guarantees the first match. Chunk-boundary retention, invalid-XML scan and earliest-error selection remain unchanged.','Finder::new borrows the static needle; its compiled default-feature constructor uses inline search state without a parser/custom-allocator callback or owned needle allocation. No initializer reentry path found.','OnceLock publishes immutable Finder once; each find constructs fresh local PrefilterState. No per-parser borrowed source or lifetime escapes.','This also changes tiny-haystack dispatch: free find directly uses Rabin-Karp below 64 bytes, whereas cached Finder selects its own short-haystack fallback. Performance is unproven; first-use contention is possible.'],'dependency_source_sha256':{str(p.relative_to(M)):sha(p) for p in [M/'src/memmem/mod.rs',M/'src/memmem/searcher.rs',M/'src/cow.rs',M/'Cargo.toml']},'focused_checks':{'receipt_sha256':sha(S/'checks-attempt01/results.json'),'tests':114,'target_counts':test_counts,'fmt_exit':0,'strict_core_all_target_clippy_exit':0},'freeze_sha256':sha(O/'pair-freeze.json'),'frozen_files':65,'pair_sha256':sha(O/'pair-report.json'),'actual_workspace_compilations':counts,'compiler_comparison':'All nine complete actual rustc vectors match the corresponding O3 streaming control after only private build/run paths and Cargo artifact suffixes. Metadata, opt-level=3, PIC/unwind/cgu1/ThinLTO arguments and argument order are retained.','candidate_generated_records':864,'training':training,'fresh_profiles':am['profiles_sha256'],'normal_libraries':a['normal_libraries'],'pgo_use_libraries':{p:v for p,v in am['libraries_sha256'].items() if p.startswith('use/')},'blockers':[],'limitations':['Ohm build and generated-only replay, not production stable verification.','114 existing focused tests passed; no new concurrent first-use stress, full C/API/strict consumer gate or performance claim.']}
out=Path('/tmp/oriole-cdata-finder-independent-review.json');out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':sha(out),'status':'passed'}))
