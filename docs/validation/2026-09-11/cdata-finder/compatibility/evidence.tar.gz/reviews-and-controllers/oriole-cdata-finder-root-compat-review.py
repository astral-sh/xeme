"""Independently read the completed Finder compatibility artifacts."""
import ast
import hashlib
import json
from pathlib import Path
import re

C = Path('/tmp/oriole-cdata-finder-thin-pgo-gates')
P = Path('/tmp/oriole-cdata-finder-thin-pgo-cpython-gates')
B = Path('/tmp/oriole-streaming-work-thin-pgo-cpython-gates')
hashes = {}

def read(path):
    path = Path(path)
    data = path.read_bytes()
    hashes[str(path)] = hashlib.sha256(data).hexdigest()
    return data

def load(path):
    return json.loads(read(path))

def sha(path):
    read(path)
    return hashes[str(Path(path))]

# Reuse only the already-reviewed log grammar, without executing its old campaign.
grammar = Path('/tmp/oriole-native-byte-count-thinlto-cpython-root-review/audit.py')
assert sha(grammar) == '3a7439dc8261956d894f2a60424cbeaf3e1a96ce57bbe50ec5fdeaeb8751c163'
tree = ast.parse(read(grammar))
function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'methods')
exec(compile(ast.Module(body=[function], type_ignores=[]), str(grammar), 'exec'))

api = load(C/'api-native/upstream-api/results.json')
baseline = load('/tmp/oriole-streaming-work-thin-pgo-gates-cpu5/api-native/upstream-api/results.json')
assert api == baseline and len(api['results']) == 4740
assert api['passed'] == 4347 and api['failed'] == 393
assert api['selection_complete'] and api['library_origin_verified'] and not api['timed_out']
manifest = load(C/'api-native/upstream-api/manifest.json')
assert [manifest[k] for k in ['per_test_seconds', 'per_test_address_space_bytes', 'per_test_rss_limit_bytes', 'total_timeout_seconds']] == [3, 1073741824, 805306368, 240]
for lane in ['api', 'other', 'end']:
    report = load(C/(lane+'-controller.json'))
    assert report['status'] == 'completed_zero_exits' and report['unchanged']
    for row in report['jobs']:
        assert row['exit'] == 0 and sha(C/row['script']) == row['sha256']
        prefix = row['script'].replace('/', '-')
        for stream in ['stdout', 'stderr']:
            assert sha(C/(prefix+'.'+stream)) == row[stream+'_sha256']
for folder in ['api-native', 'other-gates', 'end-oom-final']:
    report = load(C/folder/'report.json')
    assert report['unchanged']
    for row in report['commands']:
        for stream in ['stdout', 'stderr']:
            assert sha(C/folder/(row['label']+'.'+stream)) == row[stream+'_sha256']
for linkage in ['dynamic', 'static']:
    assert '327 scenarios' in read(C/'api-native'/('native-allocations-'+linkage+'.stdout')).decode()

controller = load(P/'controller.json')
for path, digest in controller['libraries'].items():
    assert sha(path) == digest
for job in controller['jobs']:
    assert job['exit'] == job['expected_exit'] == 2
    assert '--consumer-fix' in job['command']
    assert '--allow-text-fragmentation' not in job['command']
    assert sha(P/(job['linkage']+'.log')) == job['log_sha256']
expected = ['test.test_pyexpat.BufferTextTest.test1', 'test.test_sax.CDATAHandlerTest.test_handlers']
outcomes = {}
for linkage in ['shared', 'static']:
    directory = P/linkage
    result, old = load(directory/'summary.json'), load(B/linkage/'summary.json')
    assert result['consumer_fix'] == old['consumer_fix']
    assert result['text_fragmentation'] is None
    assert result['tests_exit_code'] == result['gate_exit_code'] == 2
    assert result['probe_exit_code'] == result['origin_exit_code'] == 0
    assert result['compiled_source_sha256'] == sha(directory/'pyexpat.c') == old['compiled_source_sha256']
    origins = load(directory/'origin.log')
    assert origins['status'] == 'passed' and len(origins['origins']) == 4
    for entry in origins['origins'].values():
        assert Path(entry['path']).parent == directory and sha(entry['path']) == entry['sha256']
    rows = methods(directory/'tests.log')
    assert len(rows) == 802 and rows == methods(B/linkage/'tests.log')
    assert sorted(k for k, v in rows.items() if v in ('FAIL', 'ERROR')) == expected
    outcomes[linkage] = {'methods': len(rows), 'failures': expected, 'exact_baseline_map': True}
result = {'status': 'passed', 'scope': 'Saved outcome, limits, command-output and consumer-origin audit; no target execution. Collector-owned detailed C observation audit remains separate.', 'api_rows': 4740, 'api_raw_byte_identical': sha(C/'api-native/upstream-api/results.json') == sha('/tmp/oriole-streaming-work-thin-pgo-gates-cpu5/api-native/upstream-api/results.json'), 'cpython': outcomes, 'evidence_sha256': hashes}
Path('/tmp/oriole-cdata-finder-root-compat-review.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({key: value for key, value in result.items() if key != 'evidence_sha256'}))
