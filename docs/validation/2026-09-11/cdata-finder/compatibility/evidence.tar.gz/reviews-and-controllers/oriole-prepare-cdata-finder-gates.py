"""Materialize inherited candidate gates only; no compilation or parser execution."""
from pathlib import Path
import ast,difflib,hashlib,json,re,shutil
R=Path('/tmp/oriole-cdata-finder-thin-pgo-gates');OLD=Path('/tmp/oriole-streaming-work-thin-pgo-gates-cpu5')
P=Path('/tmp/oriole-cdata-finder-pgo-study');BASE=Path('/tmp/oriole-streaming-work-pgo-study-attempt02');W=Path('/home/dev-user/code/oss/oriole-cdata-finder');BW=Path('/home/dev-user/code/oss/oriole-streaming-input-bounds')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
assert not R.exists();R.mkdir()
source=j(P/'source.json');base=j(BASE/'source.json');build=j(P/'pair-report.json');bb=j(BASE/'pair-report.json');L=Path(build['pgo_manifest']['path']).parent/'use';B=Path(bb['pgo_manifest']['path']).parent/'use'
assert h(P/'pair-freeze.json')=='028ba513343c8e3b56f5de28a56e70889ff03f7f5b76517f64fa5f2ee4a339db'
assert len(source['source_sha256'])==70 and all(h(W/n)==v for n,v in source['source_sha256'].items())
assert [n for n in source['source_sha256'] if source['source_sha256'][n]!=base['source_sha256'][n]]==['crates/oriole/src/lib.rs','tests/c/integration.c']
assert h(W/'tests/c/integration.c')=='72162a4d080d2fd018023aed63181663090fc291772a45e121b51187b1fe28d7'
raw=OLD/'api-native/upstream-api/results.json';assert h(raw)=='543838aa8d725d1c5c1fd10b92d6b3ea1ab687eb21390e6260f931fe553f4afb' and len(j(raw)['results'])==4740
assert sum(r['outcome']=='timeout' for r in j(raw)['results'])==2
prior_lib='/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use'
changes=[(str(OLD),str(R)),('/tmp/oriole-literal-attribute-check-thin-pgo-gates-cpu5/api-native/upstream-api',str(OLD/'api-native/upstream-api')),(str(B),str(L)),(prior_lib,str(B)),(str(BASE),str(P)),('/tmp/oriole-literal-attribute-check-pgo-study',str(BASE)),(str(BW),str(W)),('8e12c1819a58a66ae5530a53433dd08de44921c94a2b39a6282358dfd33c0d1e',build['pgo_libraries']['use/liboriole_expat.so']),('8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a',bb['pgo_libraries']['use/liboriole_expat.so']),('1058868a7067671a1cb3b5f0de571e47cfcafe17',source['base_commit']),('this policy may change input/work-limit outcomes','every Finder candidate outcome remains subject to comparison'),('CPython gates are owned by root, outside this artifact.','Strict CPython gates are separately prepared and reported outside this artifact.')]
# Simultaneous substitutions avoid turning the selected control into the candidate.
def adapt(text):
 for i,(old,new) in enumerate(changes):text=text.replace(old,'__FINDER_GATE_'+str(i)+'__')
 for i,(old,new) in enumerate(changes):text=text.replace('__FINDER_GATE_'+str(i)+'__',new)
 assert '__FINDER_GATE_' not in text
 return text
names=['api_native.py','other_controls.py','publication_probe.py','run_publication.py','prepare_malformed.py','run_malformed.py','classify_observations.py','end-lifecycle-final/oracle.py','end-lifecycle-final/controller.py','end-oom-final/run.py','run_lane.py','run_remaining.py','summarize.py','malformed/malformed_probe.py']
deltas=[]
for n in names:
 old=(OLD/n).read_text();new=adapt(old);ast.parse(new)
 p=R/n;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(new)
 deltas.append(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(OLD/n),tofile=str(p))))
for n in ['source.json','pair-report.json']:shutil.copyfile(P/n,R/('build.json' if n=='pair-report.json' else n))
fixtures=['end-oom-final/probe.c','end-oom-final/original-allocations.c','end-oom-final/expat.h','end-lifecycle-final/SOURCE_REVIEW.md','malformed/original-malformed-probe.py','tools/xml_abi.py']
for n in fixtures:
 p=R/n;p.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(OLD/n,p)
# Reproduce the old malformed generator's output by exact identity substitution; no target or generator execution.
malformed_preparation=j(OLD/'malformed/preparation.json');new_malformed={adapt(path):h(adapt(path)) for path in malformed_preparation['hashes']}
(R/'malformed/preparation.json').write_text(json.dumps({'hashes':new_malformed,'adaptation':malformed_preparation['adaptation']},indent=2)+'\n')
(R/'controller.patch').write_text(''.join(deltas))
unchanged=['tools/differential.py','tools/corpus.py','tools/xml_abi.py','include/expat.h','tests/c/adversarial.c','tests/c/allocations.c',*[str(Path('tools/upstream-expat')/n) for n in ['run.py','runner.c','bridge.c','bridge.h','memcheck.patch','README.md','allocator_repro.c']]]
assert all(h(W/n)==h(BW/n) for n in unchanged)
external=[Path('/tmp/oriole-unique-accounting-evidence/api-tools/run_clean.py'),*[Path('/tmp/oriole-custom-alias-'+n+'.py') for n in ['probe','full-events','external-semantic-compare']],Path('/tmp/oriole-text-prefix-evidence/malformed_probe.py')]
tracked=[P/'source.json',P/'pair-report.json',P/'pair-freeze.json',Path(build['pgo_manifest']['path']),BASE/'source.json',BASE/'pair-report.json',raw,OLD/'api-native/upstream-api/manifest.json',OLD/'api-native/upstream-api/adapted/expat_config.h',*[L/n for n in ['liboriole_expat.so','liboriole_expat.a']],*[B/n for n in ['liboriole_expat.so','liboriole_expat.a']],*[W/n for n in source['source_sha256']],*[W/n for n in unchanged],*[R/n for n in names+fixtures],*[OLD/n for n in names+fixtures],*external,R/'malformed/preparation.json']
report={'status':'prepared_not_executed','role':'Controller preparer; no compilation/parsing/target execution.','before':{str(p):h(p) for p in tracked},'controllers':{n:h(R/n) for n in names},'replacements':changes,'controller_patch_sha256':h(R/'controller.patch'),'libraries':{'baseline':{n:h(B/n) for n in ['liboriole_expat.so','liboriole_expat.a']},'candidate':{n:h(L/n) for n in ['liboriole_expat.so','liboriole_expat.a']}},'source_delta_from_streaming_control':['crates/oriole/src/lib.rs','tests/c/integration.c'],'source_delta_from_PR125':['crates/oriole/src/lib.rs'],'integration_fixture_sha256':h(W/'tests/c/integration.c'),'scope':'Original all4740 API matrix,3s/test,1GiB AS,768MiB RSS,240s total; six C shared/static consumers including inherited PR125 nested-entity fixture,327 selected-allocation scenarios per linkage; strict3318/custom36456/malformed2392/publication1304/3912/End38+6. All unchanged assertions, fixture generation, process cleanup and original raw baseline rows.','baseline_api_outcomes':{'passed':4347,'assertion_failures':391,'timeouts':2,'raw_results_sha256':h(raw)},'execution':'HELD pending Python performance decision and root release. C lanes retain selected CPU3, strict CPython retains selected CPU4. No allocator override added.','limitations':['C ASan/UBSan does not instrument the Rust release artifact; original leak-check-disabled setting retained.','Successful custom alias raw pairs are not retained by the unchanged helper; original scripts, counts and differences remain.','End SOURCE_REVIEW.md is historical fixture provenance.','Existing API timeouts/failures are baseline observations, not permission to filter rows or widen bounds; all candidate changes retained.','No fresh workspace, large-stream, Rust ASan, timing or adoption claim.']}
(R/'preparation.json').write_text(json.dumps(report,indent=2)+'\n')
# Strict CPython shares the selected streaming consumer-fix status and exact method suite.
D=Path('/tmp/oriole-cdata-finder-thin-pgo-cpython-preparation');D.mkdir();old=Path('/tmp/oriole-streaming-work-thin-pgo-cpython-gates/oriole-streaming-work-thin-pgo-cpython-gates.py');out=Path('/tmp/oriole-cdata-finder-thin-pgo-cpython-gates');assert not out.exists()
strict_changes=[(str(BW),str(W)),('/tmp/oriole-streaming-work-thin-pgo-cpython-gates',str(out)),(str(B),str(L)),(str(BASE/'source.json'),str(P/'source.json')),('8e12c1819a58a66ae5530a53433dd08de44921c94a2b39a6282358dfd33c0d1e',build['pgo_libraries']['use/liboriole_expat.so']),('b5529316fb6a3bcac246267b665b70e8b8fa487e4824e5c8b2e0736dedd4371e',build['pgo_libraries']['use/liboriole_expat.a']),('streaming policy ThinLTO PGO artifact','cached Finder ThinLTO PGO artifact')]
text=old.read_text()
for a,b in strict_changes:text=text.replace(a,b)
controller=D/'oriole-cdata-finder-thin-pgo-cpython-gates.py';controller.write_text(text);ast.parse(text)
(D/'controller.patch').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),text.splitlines(True),fromfile=str(old),tofile=str(controller))))
oldprep=j('/tmp/oriole-streaming-work-thin-pgo-cpython-preparation/preparation.json');fixed=oldprep['fixed_source_inputs'];assert all(h(W/n)==v for n,v in fixed.items())
assert '--consumer-fix' in text and '--allow-text-fragmentation' not in text and '--system-allocator' not in text
strict={'status':'prepared_held','template':str(old),'template_sha256':h(old),'controller':str(controller),'controller_sha256':h(controller),'patch_sha256':h(D/'controller.patch'),'replacements':strict_changes,'source_manifest_sha256':h(P/'source.json'),'build_freeze_sha256':h(P/'pair-freeze.json'),'libraries':report['libraries']['candidate'],'fixed_source_inputs':fixed,'consumer_fix':oldprep['consumer_fix'],'cpu':4,'original_timeout_seconds_per_linkage':1200,'linkages':['shared','static'],'raw_expected_exit':2,'expected_methods':802,'expected_failure_identities':oldprep['known_baseline_failures'],'baseline':'/tmp/oriole-streaming-work-thin-pgo-cpython-gates','baseline_outcome_review_sha256':h('/tmp/oriole-streaming-work-thin-pgo-cpython-outcome-review/review.json'),'outcome_requirement':'Compare exact full802 method/outcome/skip maps and failure identities against selected streaming patched-consumer logs. Exit2 or failure count alone is insufficient. Preserve every first outcome; no retries or fragmentation/allocator overrides.','scope':'Same pinned CPython3.12.13, cleanup backport, six test modules, shared/static extension recipe, native-static-libs and process-group kill/reap bounds as selected streaming. No targets or output directory created.'}
(D/'preparation.json').write_text(json.dumps(strict,indent=2)+'\n')
print(json.dumps({'c_preparation':str(R/'preparation.json'),'c_preparation_sha256':h(R/'preparation.json'),'c_patch_sha256':h(R/'controller.patch'),'strict_preparation':str(D/'preparation.json'),'strict_preparation_sha256':h(D/'preparation.json'),'strict_patch_sha256':h(D/'controller.patch'),'strict_controller_sha256':h(controller)}))
