"""Strict CPython tests against the exact measured ThinLTO PGO artifacts."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time

root = Path('/home/dev-user/code/oss/oriole-cdata-finder')
out = Path('/tmp/oriole-cdata-finder-thin-pgo-cpython-gates')
out.mkdir(exist_ok=False)
shutil.copy2(__file__, out / Path(__file__).name)
python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
library = Path('/tmp/oriole-cdata-finder-pgo-study/pgo/runs/run-sjsgpms8/use/liboriole_expat.so')
archive = library.with_suffix('.a')
source = '/home/dev-user/.cache/oriole/upstream/cpython-3.12.13'
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert digest(library) == '82bdf9b9a3b1c26b089ab9ef28bc0207ec386bfa86a2f43736f379b9fa93ab93'
assert digest(archive) == 'a845807a35018a614f9cbaf244ba01f0ad575c958673d5e1119c59a17812d7ef'
source_map = json.loads(Path('/tmp/oriole-cdata-finder-pgo-study/source.json').read_text())['source_sha256']
assert len(source_map) == 70 and all(digest(root / name) == value for name, value in source_map.items())
report = {'status': 'incomplete', 'libraries': {str(p): digest(p) for p in [library, archive]}, 'source_sha256': source_map, 'jobs': [],
          'scope': 'Fresh CPython shared/static consumers with the pinned upstream allocation-failure cleanup backport against the cached Finder ThinLTO PGO artifact; upstream tests are unmodified. Strict test failures remain raw; expected count alone does not establish parity. Per-command 1200s with process-group cleanup. CPU4, shared host.'}
def save():
    (out / 'controller.json').write_text(json.dumps(report, indent=2) + '\n')
try:
    for linkage, path in [('shared', library), ('static', archive)]:
        command = ['taskset', '-c', '4', python, '-I', '-S', str(root / 'tools/cpython/run.py'), '--source', source, '--library', str(path), '--output', str(out / linkage), '--consumer-fix']
        if linkage == 'static':
            command += [arg for name in ['gcc_s', 'util', 'rt', 'pthread', 'm', 'dl', 'c'] for arg in ['--native-library', name]]
        item = {'linkage': linkage, 'command': command, 'expected_exit': 2, 'timeout_seconds': 1200, 'start': time.time()}
        report['jobs'].append(item)
        save()
        process = None
        log_path = out / (linkage + '.log')
        with log_path.open('wb') as log:
            try:
                process = subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                item['exit'] = process.wait(timeout=1200)
                assert item['exit'] == 2
            except BaseException as exc:
                item['exception'] = repr(exc)
                if process is not None:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    item['exit'] = process.wait()
                raise
            finally:
                log.flush()
                item['end'] = time.time()
                item['log_sha256'] = digest(log_path)
                save()
        print(linkage, item['exit'], flush=True)
    assert all(digest(p) == value for p, value in report['libraries'].items())
    assert all(digest(root / name) == value for name, value in source_map.items())
    report['status'] = 'completed_with_failures_retained_pending_outcome_audit'
except BaseException as exc:
    report['status'] = 'failed'
    report['exception'] = repr(exc)
    raise
finally:
    save()
