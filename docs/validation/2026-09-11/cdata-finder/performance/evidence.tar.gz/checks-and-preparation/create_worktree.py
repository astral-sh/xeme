"""Create the authorized isolated borrowed CDATA Finder experiment and retain its provenance."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

study = Path(__file__).resolve().parent
source = Path('/home/dev-user/code/oss/oriole-streaming-input-bounds')
destination = Path('/home/dev-user/code/oss/oriole-cdata-finder')
base = '144e69e08c5462217d54791374e579e3ef390a87'
assert source.resolve() == source
assert not destination.exists()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=source, text=True).strip()
assert git('rev-parse', '--git-common-dir') == '/home/dev-user/code/oss/oriole/.git'
assert git('config', 'user.email') == 'charlie.r.marsh@gmail.com'
assert git('rev-parse', base) == base
manifest = json.loads(Path('/tmp/oriole-streaming-work-pgo-study-attempt02/source.json').read_text())
hashes = manifest['source_sha256']
assert len(hashes) == 70
for name, digest in hashes.items():
    assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest, name
env = os.environ.copy()
for name in ['RUSTC', 'RUSTFLAGS', 'LLVM_PROFILE_FILE', 'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST', 'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST']:
    env.pop(name, None)
assert not any(name.startswith('CARGO_PROFILE_') for name in env)
overrides = dict(CARGO_HOME='/home/dev-user/.cache/toucan/cargo',
    CARGO_TARGET_DIR='/home/dev-user/.cache/oriole/targets/streaming-input-bounds',
    CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}',
    CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', RUSTC_WRAPPER='', RUSTC_WORKSPACE_WRAPPER='',
    CARGO_ENCODED_RUSTFLAGS='', RUSTUP_AUTO_INSTALL='0', CARGO_TERM_COLOR='never')
env.update(overrides)
command = ['taskset', '-c', '6', 'cargo', '+ohm', '-Zohm-defaults=yes', 'worktree', 'add', '-b',
    'charlie/codex-oriole-cdata-finder', '--target-dir',
    '/home/dev-user/.cache/oriole/targets/cdata-finder', str(destination), base]
attempt = len(list(study.glob('worktree-creation-attempt*.json'))) + 1
prefix = study / f'worktree-creation-attempt{attempt:02}'
record = dict(source=str(source), worktree=str(destination), base=base,
    common_git_dir=git('rev-parse', '--git-common-dir'), git_email=git('config', 'user.email'),
    source_manifest=manifest, command=command, environment_overrides=overrides, started=time.time())
prefix.with_suffix('.json').write_text(json.dumps(record, indent=2) + '\n')
with prefix.with_suffix('.stdout').open('w') as stdout, prefix.with_suffix('.stderr').open('w') as stderr:
    result = subprocess.run(command, cwd=source, env=env, stdout=stdout, stderr=stderr, timeout=600)
record.update(exit=result.returncode, completed=time.time())
for suffix in ['stdout', 'stderr']:
    record[suffix + '_sha256'] = hashlib.sha256(prefix.with_suffix('.' + suffix).read_bytes()).hexdigest()
if result.returncode == 0:
    for name, digest in hashes.items():
        assert hashlib.sha256((destination / name).read_bytes()).hexdigest() == hashlib.sha256(subprocess.check_output(['git', 'show', base+':'+name], cwd=source)).hexdigest(), name
    record['destination_source_files_verified'] = len(hashes)
prefix.with_suffix('.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: v for k, v in record.items() if k != 'source_manifest'}, indent=2))
print(prefix.with_suffix('.stderr').read_text())
raise SystemExit(result.returncode)
