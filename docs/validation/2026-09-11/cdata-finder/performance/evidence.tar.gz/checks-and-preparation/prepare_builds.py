"""Prepare fresh matched O3 Finder builds after focused checks; do not run them."""
from pathlib import Path
import ast
import difflib
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

S=Path(__file__).resolve().parent
W=Path('/home/dev-user/code/oss/oriole-cdata-finder')
T=Path('/tmp/oriole-native-tag-execution-pgo-study')
B=Path('/tmp/oriole-streaming-work-pgo-study-attempt02')
O=Path('/tmp/oriole-cdata-finder-pgo-study')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
checks=load(S/'checks-attempt01/results.json')
assert checks['status']=='passed' and checks['source_unchanged']
assert all(x['exit']==0 and 'exception' not in x for x in checks['commands'])
assert checks['source_manifest_sha256']==sha(S/'source.json')
source=load(S/'source.json')['source_sha256']
assert len(source)==70 and all(sha(W/n)==h for n,h in source.items())
prior=load(B/'source.json')['source_sha256']
assert sha(B/'source.json')=='e52c4fa16e71a7dcd76864b29509b157a42b6fbe4531f87b68f98395418d5fc3'
assert sha(B/'pair-report.json')=='2a5dfd8ef1ba5fb09b87c290a58d27b3c59ad5e2b07e4cdb91d527b2257059d4'
changed=[n for n in source if source[n]!=prior[n]]
assert changed==['crates/oriole/src/lib.rs','tests/c/integration.c']
base=load(S/'base-source.json')
assert base['base_commit']=='144e69e08c5462217d54791374e579e3ef390a87'
assert [n for n in source if source[n]!=base['source_sha256'][n]]==['crates/oriole/src/lib.rs']
fixture='tests/c/integration.c'
assert source[fixture]==base['source_sha256'][fixture]
assert hashlib.sha256(subprocess.check_output(['git','-C',str(W),'show',base['base_commit']+':'+fixture])).hexdigest()==source[fixture]
scripts=load(B/'tool-source.json')
assert len(scripts)==6 and all(sha(W/n)==h for n,h in scripts.items())
O.mkdir(exist_ok=False)
for name in ['source.json','base-source.json','source.patch']:
    shutil.copyfile(S/name,O/name)
shutil.copyfile(B/'tool-source.json',O/'tool-source.json')
with gzip.GzipFile(filename=str(O/'source.tar.gz'),mode='wb',mtime=0) as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as archive:
        for name in source:archive.add(W/name,arcname=name,recursive=False)
with tarfile.open(O/'source.tar.gz') as archive:
    archived={m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive if m.isfile()}
assert archived==source
logdir=O/'source-check-logs';logdir.mkdir()
for row in checks['commands']:
    for stream in ['stdout','stderr']:
        name=row['label']+'.'+stream
        assert sha(S/'checks-attempt01'/name)==row[stream+'_sha256']
        shutil.copyfile(S/'checks-attempt01'/name,logdir/name)
shutil.copyfile(S/'checks-attempt01/results.json',O/'source-checks-raw.json')
normalized=checks|{'source_manifest_sha256':sha(O/'source.json'),'raw_checks_sha256':sha(O/'source-checks-raw.json')}
(O/'source-checks.json').write_text(json.dumps(normalized,indent=2)+'\n')
scope='Reusable borrowed CDATA Finder on PR125 base144e69e; runtime source differs from selected streaming708/e52c only at the parse_text fixed-needle search. The inherited tests/c/integration.c success fixture differs separately and is excluded from Cargo library inputs. Fresh explicit-host-target C-only O3 ThinLTO/cgu1 normal and generated-only PGO versus frozen O3 streaming controls; no O2 flags, no eager Finder initialization, no held-out parsing or elapsed benchmark.'
adaptations=[]
for name in ['build_pair.py','prove_pair.py','freeze_pair.py']:
    original=(T/name).read_text()
    adapted=original.replace('/home/dev-user/code/oss/oriole-native-tag-execution',str(W)).replace('/home/dev-user/.cache/oriole/targets/native-tag-execution','/home/dev-user/.cache/oriole/targets/cdata-finder')
    if name=='build_pair.py':
        old='Native tag execution on published streaming base708ca42aa320d27bf289ce9a827ad3e64ca2522d and frozen streaming source e52c4fa1. Only core lib.rs and its adapter_frame/allocation tests differ from the control. Compare fresh explicit-host-target C-only normal and generated-only ThinPGO against the frozen streaming control. No held-out project parsing or wall benchmark.'
        assert adapted.count(old)==1;adapted=adapted.replace(old,scope)
    elif name=='prove_pair.py':
        old="['crates/oriole/src/lib.rs', 'crates/oriole/tests/adapter_frame.rs', 'crates/oriole/tests/allocation.rs']"
        assert adapted.count(old)==2;adapted=adapted.replace(old,repr(changed))
        adapted=adapted.replace("source['tests/c/integration.c']=='b2ab3710059d134e744dec95bb99d403379cca65ba011c83fa25a95349b38bc1'", "source['tests/c/integration.c']=="+repr(source[fixture]))
        needle="assert source['tests/c/integration.c']=="+repr(source[fixture])
        adapted=adapted.replace(needle,needle+"\nassert len(bm['source_sha256'])==67 and bm['source_sha256'].keys()==am['source_sha256'].keys()\nassert [n for n in bm['source_sha256'] if bm['source_sha256'][n]!=am['source_sha256'][n]]==['crates/oriole/src/lib.rs']\nassert 'tests/c/integration.c' not in bm['source_sha256']")
        adapted=adapted.replace(" 'pipeline_scope':", " 'runtime_source_delta':['crates/oriole/src/lib.rs'],'inherited_c_fixture_delta':{'path':'tests/c/integration.c','base_commit':'144e69e08c5462217d54791374e579e3ef390a87','sha256':"+repr(source[fixture])+",'excluded_from_cargo_library_inputs':True},\n 'pipeline_scope':")
        adapted=adapted.replace('conditional_review adapted these inherited controllers; next_hotspot authored the runtime. This build proof is collector-owned; independent source/build review remains separate.', 'next_hotspot prepared the Finder source and build adaptation. This proof is collector-owned; independent review remains separate. The PR125 C success fixture is retained by hash as an inherited test-only delta, not new C execution or transferred compatibility evidence.')
    ast.parse(adapted,filename=name)
    (O/name).write_text(adapted)
    adaptations.extend(difflib.unified_diff(original.splitlines(True),adapted.splitlines(True),fromfile='native-tag-controller/'+name,tofile='cdata-finder-controller/'+name))
(O/'controller-adaptation.patch').write_text(''.join(adaptations))
pair=load(B/'pair-report.json');run=Path(pair['pgo_manifest']['path']).parent
controls={}
for phase,path in [('normal',B/'normal/liboriole_expat.so'),('pgo',run/'use/liboriole_expat.so')]:
    expected=pair['normal_libraries']['liboriole_expat.so'] if phase=='normal' else pair['pgo_libraries']['use/liboriole_expat.so']
    assert sha(path)==expected;controls[phase]={'path':str(path),'sha256':expected}
assert all(sha(W/n)==h for n,h in source.items())
preparation={'status':'prepared_not_executed','scope':scope,'source_manifest_sha256':sha(O/'source.json'),'source70_and_archive_verified':True,'source_checks_sha256':sha(O/'source-checks.json'),'raw_checks_sha256':sha(O/'source-checks-raw.json'),'changed_files_vs_streaming':changed,'runtime_delta':['crates/oriole/src/lib.rs'],'inherited_c_fixture':{'path':fixture,'base_commit':base['base_commit'],'control_sha256':prior[fixture],'candidate_sha256':source[fixture],'excluded_from_pipeline_source67':True},'controls':controls,'control_source_sha256':sha(B/'source.json'),'control_pair_sha256':sha(B/'pair-report.json'),'pipeline_files_unchanged':scripts,'controller_adaptation_sha256':sha(O/'controller-adaptation.patch'),'controllers':{n:sha(O/n) for n in ['build_pair.py','prove_pair.py','freeze_pair.py']},'preparer_sha256':sha(__file__),'future_build_command':['taskset','-c','3','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S',str(O/'build_pair.py')],'builds_started':False,'performance_or_full_C_evidence_transferred':False}
(O/'preparation.json').write_text(json.dumps(preparation,indent=2)+'\n')
print(json.dumps({'status':'prepared_not_executed','preparation_sha256':sha(O/'preparation.json'),'source_manifest_sha256':sha(O/'source.json'),'controllers':preparation['controllers']}))
