"""Prepare exact inherited CPython campaigns without compiling or loading parsers."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import subprocess
import sys
import sysconfig

assert os.sched_getaffinity(0) == {6}
assert sys.version_info[:3] == (3, 12, 13)
REPO = Path('/home/dev-user/code/oss/oriole-cdata-finder')
PAIR = Path('/tmp/oriole-cdata-finder-pgo-study')
SOURCE = Path('/tmp/oriole-cdata-finder-study/source.json')
CONTROL = Path('/tmp/oriole-streaming-work-pgo-study-attempt02')
CPYTHON = Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13')
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
FILES = ['build_consumers.py', 'consumer_screen.py', 'python_worker.py', 'run.py']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def pin(path):
    return {'path': str(path), 'sha256': sha(path)}

def save(path, value):
    with path.open('x') as output:
        output.write(json.dumps(value, indent=2) + '\n')

def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)

assert sha(SOURCE) == '69b96121a090467b3cea81eb25a4e627976f1a18c4cab628855c9880dd25f982'
assert sha(PAIR / 'pair-freeze.json') == '028ba513343c8e3b56f5de28a56e70889ff03f7f5b76517f64fa5f2ee4a339db'
assert sha(PAIR / 'pair-report.json') == 'ae6bf35347662d2c9c4c57d8d475a90a0fbd295d4b4e572073ae9af15cb376cf'
assert load(PAIR / 'pair-report.json')['status'] == 'passed'
source = load(SOURCE)['source_sha256']
control_source = load(CONTROL / 'source.json')['source_sha256']
assert len(source) == len(control_source) == 70 and source.keys() == control_source.keys()
assert all(sha(REPO / name) == digest for name, digest in source.items())
assert source == load(PAIR / 'source.json')['source_sha256']
delta = {name: {'control': control_source[name], 'candidate': digest}
         for name, digest in source.items() if digest != control_source[name]}
assert set(delta) == {'crates/oriole/src/lib.rs', 'tests/c/integration.c'}
assert delta['tests/c/integration.c'] == {
    'control': 'b2ab3710059d134e744dec95bb99d403379cca65ba011c83fa25a95349b38bc1',
    'candidate': '72162a4d080d2fd018023aed63181663090fc291772a45e121b51187b1fe28d7'}
git_reads = []
for args in [['rev-parse', 'HEAD'], ['status', '--porcelain']]:
    command = ['git', '-C', str(CPYTHON), *args]
    result = subprocess.run(command, text=True, capture_output=True, timeout=30)
    git_reads.append({'argv': command, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0
assert git_reads[0]['stdout'].strip() == '3bb231a6a5dc02b95658877318bf61501a7209e9'
assert git_reads[1]['stdout'] == ''
consumer_sources = {name: pin(CPYTHON / 'Modules' / name) for name in ['pyexpat.c', '_elementtree.c']}
assert consumer_sources['pyexpat.c']['sha256'] == 'fd679a16f36304444af11953ad276d4493f2044f904a39b8fdf028c6f7def8a0'
assert consumer_sources['_elementtree.c']['sha256'] == 'de4c3c8716f7e3b1d2fdf077656246220ef0493053c990ca7b724ad31498fad0'
header = pin(REPO / 'include/expat.h')
assert header['sha256'] == source['include/expat.h'] == control_source['include/expat.h']
assert header['sha256'] == sha('/home/dev-user/code/oss/oriole-streaming-input-bounds/include/expat.h')
include = Path(sysconfig.get_path('include'))
consumer_inputs = {str(path): sha(path) for path in [Path(PYTHON).resolve(), include / 'Python.h', include / 'pyconfig.h']}
manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
corpus = load(manifest)
iterations = {'vulkan': 3, 'wayland': 16, 'maven': 32, 'batik': 128, 'gtk': 64, 'docbook': 64}
conditions = []
input_pins = {str(manifest): sha(manifest)}
for project in corpus['projects']:
    entry = next(row for row in project['files'] if row['role'] == 'input')
    path = (manifest.parent / entry['path']).resolve()
    assert sha(path) == entry['sha256']
    input_pins[str(path)] = entry['sha256']
    for chunk in [4096, 65536]:
        for mode in ['elementtree', 'pyexpat-events']:
            conditions.append({'name': project['name'], 'chunk': chunk, 'mode': mode,
                               'input': str(path), 'iterations': iterations[project['name']]})
assert len(conditions) == 24
studies = []
for mode in ['normal', 'pgo']:
    parent = Path('/tmp/oriole-streaming-work-' + mode + '-python-study-attempt02')
    out = Path('/tmp/oriole-cdata-finder-' + mode + '-python-study')
    assert not out.exists()
    original = load(parent / 'adaptation.json')
    prior_build = load(parent / 'consumers/build.json')
    assert prior_build['status'] == 'passed'
    for name, source_pin in consumer_sources.items():
        prior = [digest for path, digest in prior_build['source_sha256_before'].items() if path.endswith('/Modules/' + name)]
        assert prior == [source_pin['sha256']]
    assert load(parent / 'screen/preflight.json')['conditions'] == conditions
    assert original['counts'] == {'conditions': 24, 'engines': 3, 'extensions': 6, 'preflights': 72,
        'cohorts': 168, 'pairs': 7, 'timed_workers': 504, 'measured_parses': 25788, 'warmups': 504}
    assert original['seed'] == 202609104412
    libraries = {'control': original['libraries']['candidate'], 'expat': original['libraries']['expat']}
    if mode == 'normal':
        libraries['candidate'] = pin(PAIR / 'normal/liboriole_expat.so')
        assert libraries['candidate']['sha256'] == '195add2e0efba2f7dacc57efc06788d58212e4572bcf83097937fe57dc5f9aa7'
        assert libraries['control']['sha256'] == '1a7e89cdf0edd481aa264b018e7ec923ec0e3f37abfa22a82f27920bc2e9e11d'
    else:
        libraries['candidate'] = pin(PAIR / 'pgo/runs/run-sjsgpms8/use/liboriole_expat.so')
        assert libraries['candidate']['sha256'] == '82bdf9b9a3b1c26b089ab9ef28bc0207ec386bfa86a2f43736f379b9fa93ab93'
        assert libraries['control']['sha256'] == '8e12c1819a58a66ae5530a53433dd08de44921c94a2b39a6282358dfd33c0d1e'
    assert all(sha(row['path']) == row['sha256'] for row in libraries.values())
    out.mkdir()
    modifications = {}
    for name in FILES:
        assert sha(parent / name) == original['files'][name]
        before = (parent / name).read_text()
        after = before
        replacements = []
        if name == 'run.py':
            replacements = [('/home/dev-user/code/oss/oriole-streaming-input-bounds/include', str(REPO / 'include'))]
        elif name == 'consumer_screen.py':
            replacements = [
                ('Matched streaming-work ' + mode + ' CPython screen', 'Matched cached CDATA Finder ' + mode + ' CPython screen'),
                ('Expected frozen control, streaming-work policy candidate and Expat engines', 'Expected selected streaming control, cached CDATA Finder candidate and Expat engines'),
                ('explicit-host accepted attribute control and streaming-work policy candidate', 'explicit-host selected streaming control and cached CDATA Finder candidate'),
                ('The accepted attribute runtime has two known strict CPython callback-grouping failures.', 'The selected streaming runtime has two known strict CPython callback-grouping failures.'),
            ]
        for old, new in replacements:
            after = replace_once(after, old, new)
        reversed_text = after
        for old, new in reversed(replacements):
            reversed_text = replace_once(reversed_text, new, old)
        assert reversed_text == before
        assert ast.dump(ast.parse(reversed_text), include_attributes=False) == ast.dump(ast.parse(before), include_attributes=False)
        (out / name).write_text(after)
        if name in ['build_consumers.py', 'python_worker.py']:
            assert (out / name).read_bytes() == (parent / name).read_bytes()
        patch = ''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                           fromfile=str(parent / name), tofile=str(out / name)))
        (out / (name + '.patch')).write_text(patch)
        modifications[name] = {'parent_sha256': sha(parent / name), 'candidate_sha256': sha(out / name),
                               'replacements': replacements, 'reverse_text_and_AST_exact': True}
    adaptation = dict(original)
    adaptation.update(
        source_runtime_control='708ca42aa320d27bf289ce9a827ad3e64ca2522d',
        candidate_source_manifest=pin(SOURCE), candidate_pair_freeze=pin(PAIR / 'pair-freeze.json'),
        selected_control_source_manifest=pin(CONTROL / 'source.json'),
        selected_control_pair_freeze=pin(CONTROL / 'pair-freeze.json'),
        libraries=libraries, header=header,
        proof='Copied the exact completed streaming attempt02 protocol. Builder and worker are byte-identical to their same-mode parents. The run controller changes only the common header directory to the byte-identical Finder header; screen changes only four captions. Engine paths/hashes now bind selected streaming controls versus Finder candidate and the same Expat. All conditions, namespace behavior, seed, pairing, iteration counts, timing boundaries and bounds are unchanged.',
        execution_prerequisites='Preparation only. No compiler, extension import, parser, preflight or elapsed command is authorized by this artifact. Root must review and separately release prepare, then timing after consumers/preflights pass and CPU0 is exclusive.',
        files={name: sha(out / name) for name in FILES},
        parent_files={name: sha(parent / name) for name in FILES},
        parent_adaptation=pin(parent / 'adaptation.json'),
        consumer_source={'requested_checkout': str(CPYTHON), 'resolved_checkout': str(CPYTHON.resolve()),
                         'revision': git_reads[0]['stdout'].strip(), 'clean': True, 'files': consumer_sources,
                         'interpreter_and_public_headers': consumer_inputs},
        source_70_delta=delta,
        inherited_C_fixture_note='Only lib.rs is the Finder runtime treatment. tests/c/integration.c differs because the Finder branch inherits PR125 permanent C coverage; this fixture is not compiled into the parser libraries or CPython extension consumers. All other 68 entries, including expat.h, are byte-identical.',
        first_use='No eager Finder initialization or worker modification. Each new worker process loads extensions outside timing, then first parser search occurs inside the existing discarded warmup parse. Preflight uses a separate process. Measured parse/destruction boundaries are unchanged.',
        execution_status='unexecuted',
    )
    save(out / 'adaptation.json', adaptation)
    preparation = {'status': 'prepared_only', 'mode': mode, 'preparer': pin(Path(__file__)),
        'parent': str(parent), 'controller_changes': modifications, 'conditions': conditions,
        'counts': adaptation['counts'], 'bounds': adaptation['bounds'], 'seed': adaptation['seed'],
        'source_70_verified': True, 'source_70_delta': delta,
        'consumer_source_read_only_git_checks': git_reads, 'input_pins': input_pins,
        'future_commands_held': {
            'prepare': ['taskset', '-c', '3', PYTHON, '-I', '-S', str(out / 'run.py'), 'prepare'],
            'time': ['taskset', '-c', '0', PYTHON, '-I', '-S', str(out / 'run.py'), 'time']},
        'execution': 'No compiler or target was invoked; only source reads, exact controller copies, inert AST parsing and hash validation.',
        'adaptation': pin(out / 'adaptation.json')}
    save(out / 'preparation.json', preparation)
    save(out / 'preparation-freeze.json', {'status': 'prepared_only', 'files': {
        str(path): sha(path) for path in sorted(out.iterdir()) if path.is_file()}})
    studies.append({'mode': mode, 'path': str(out), 'adaptation': pin(out / 'adaptation.json'),
                    'preparation': pin(out / 'preparation.json'), 'freeze': pin(out / 'preparation-freeze.json')})
    print(mode, 'adaptation', sha(out / 'adaptation.json'), 'freeze', sha(out / 'preparation-freeze.json'), flush=True)
assert all(sha(REPO / name) == digest for name, digest in source.items())
receipt = {'status': 'prepared_only', 'studies': studies, 'all_70_source_files_unchanged': True,
           'compiler_target_preflight_elapsed_execution': False, 'controller': pin(Path(__file__))}
save(Path('/tmp/oriole-cdata-finder-study/python-preparation.json'), receipt)
print('receipt', sha('/tmp/oriole-cdata-finder-study/python-preparation.json'), flush=True)
