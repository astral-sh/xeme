"""Run required full Finder workspace checks after explicit CPU5 release; no source edits."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

S=Path(__file__).resolve().parent
W=Path('/home/dev-user/code/oss/oriole-cdata-finder')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((S/'source.json').read_text())['source_sha256']
assert sha(S/'source.json') == '69b96121a090467b3cea81eb25a4e627976f1a18c4cab628855c9880dd25f982'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip() == '144e69e08c5462217d54791374e579e3ef390a87'
assert subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).splitlines() == ['crates/oriole/src/lib.rs']
assert os.sched_getaffinity(0)=={5} and all(sha(W/n)==h for n,h in source.items())
assert not any(k.startswith('CARGO_PROFILE_') for k in os.environ)
env=os.environ.copy()
for key in ['RUSTC','RUSTFLAGS','LLVM_PROFILE_FILE','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST']:
    env.pop(key,None)
overrides={'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/targets/cdata-finder','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_ENCODED_RUSTFLAGS':'','RUSTUP_AUTO_INSTALL':'0','CARGO_TERM_COLOR':'never'}
env.update(overrides)
base=['cargo','+ohm','-Zohm-defaults=no']
commands=[('fmt',base+['fmt','--all','--','--check'],60),
          ('workspace',base+['test','--workspace','--locked','--offline'],1800),
          ('clippy',base+['clippy','--workspace','--all-targets','--locked','--offline','--','-D','warnings'],900)]
out=S/'workspace-checks-attempt01';out.mkdir(exist_ok=False)
report={'status':'incomplete','source_manifest_sha256':sha(S/'source.json'),'controller_sha256':sha(__file__),'prior_focused_results_sha256':sha(S/'checks-attempt01/results.json'),'commands':[],'environment_overrides':overrides,'scope':'Full workspace tests including doc tests, strict workspace all-target Clippy and fmt-check for promotion. Prior 114 focused checks are not separately repeated. Same existing per-worktree target/shared build, defaults and trust opt-ins disabled; CPU5 jobs1. No benchmark build path changed.'}
def save():
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
try:
    for label,argv,bound in commands:
        row={'label':label,'argv':argv,'cpu':5,'timeout':bound,'start':time.time()};report['commands'].append(row);save();p=None
        with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
            try:
                p=subprocess.Popen(argv,cwd=W,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
                row['exit']=p.wait(timeout=bound)
                if row['exit']:raise RuntimeError(label+' failed')
            except BaseException as error:
                row['exception']=repr(error)
                if p is not None:
                    try:os.killpg(p.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    row['exit']=p.wait()
                raise
            finally:
                stdout.flush();stderr.flush();row['end']=time.time()
                row['stdout_sha256']=sha(out/(label+'.stdout'));row['stderr_sha256']=sha(out/(label+'.stderr'));save()
        print(label,row['exit'],flush=True)
    report['status']='passed'
finally:
    report['source_unchanged']=all(sha(W/n)==h for n,h in source.items());save()
assert report['source_unchanged']
