"""Read only the Finder call site and initialization/search symbols after release."""
from pathlib import Path
import json
import os
import re
import subprocess
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import ROOT, PAIR, sha, load, verified_libraries

assert os.sched_getaffinity(0)=={1}
libraries=verified_libraries()
prior=Path('/tmp/oriole-native-tag-execution-codegen-study/assembly')
old=load(prior/'collection.json')
for name in ['control-normal','control-pgo']:
    assert old['libraries'][name]==libraries[name]
    for suffix in ['asm','nm','sections']:
        row=next(x for x in old['commands'] if x['label']==name+'.'+suffix)
        assert row['exit']==0 and sha(prior/row['label'])==row['stdout_sha256']
out=ROOT/'assembly';out.mkdir(exist_ok=False)
record={'status':'running','scope':'Saved selected control assembly and bounded candidate ELF symbol/address reads. No dlopen, parser or profiler execution. Manual call-site review must distinguish one-time Finder construction from the repeated cached search.',
        'cpu':1,'libraries':libraries,'pair_freeze_sha256':sha(PAIR/'pair-freeze.json'),
        'controller_sha256':sha(__file__),'common_sha256':sha(ROOT/'common.py'),
        'controls':{name:{'assembly':str(prior/(name+'.asm')),'sha256':sha(prior/(name+'.asm'))} for name in ['control-normal','control-pgo']},'commands':[],'symbols':{},'references':{}}
def save():
    (out/'collection.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,argv):
    row={'label':label,'argv':argv,'timeout':60,'start':time.time()};record['commands'].append(row);save()
    try:
        with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
            result=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=60,check=False)
        row['exit']=result.returncode
        assert result.returncode==0,label
    except BaseException as error:
        row['exception']=repr(error);raise
    finally:
        row.update(end=time.time(),stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr')));save()
    return (out/(label+'.stdout')).read_text()
save()
try:
    for name in ['candidate-normal','candidate-pgo']:
        path=libraries[name]['path']
        text=run(name+'-nm',['nm','-S','-C','--defined-only',path])
        run(name+'-sections',['size','-A',path])
        symbols=[]
        for line in text.splitlines():
            match=re.match(r'^([0-9a-f]+) ([0-9a-f]+) (\w) (.*)$',line)
            if match and any(key in match[4] for key in ['<oriole::Parser>::next_event','<oriole::Parser>::parse_text','CDATA_END','OnceLock','once::','memmem::searcher','packedpair::Finder']):
                symbols.append({'address':int(match[1],16),'bytes':int(match[2],16),'type':match[3],'symbol':match[4]})
        record['symbols'][name]=symbols;save()
        statics=[s for s in symbols if 'CDATA_END' in s['symbol'] and s['type'].lower() in ['b','d','r']]
        assert len(statics)==1,(name,statics)
        refs=[]
        for index,symbol in enumerate(symbols):
            if symbol['type'].lower()!='t':continue
            assembly=run(name+'-'+str(index).zfill(2),['objdump','-d','-C','-M','intel','--no-show-raw-insn','--start-address='+hex(symbol['address']),'--stop-address='+hex(symbol['address']+symbol['bytes']),path])
            lines=assembly.splitlines()
            for i,line in enumerate(lines):
                if any(key in line for key in ['CDATA_END','OnceLock','once::','searcher_kind_','with_pair_impl']):
                    refs.append({'function':symbol['symbol'],'line':line,'context':lines[max(0,i-4):i+5]})
        record['references'][name]=refs;save()
    assert verified_libraries()==libraries
    record['status']='collected_pending_manual_call_site_review'
finally:
    save()
print(json.dumps({'status':record['status'],'receipt_sha256':sha(out/'collection.json'),'candidate_symbols':{k:len(v) for k,v in record['symbols'].items()}}))
