"""Frozen inputs and receipt helpers for the approved borrowed-Finder experiment."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
PAIR = Path('/tmp/oriole-cdata-finder-pgo-study')
SOURCE = Path('/home/dev-user/code/oss/oriole-cdata-finder')
CONTROL = Path('/tmp/oriole-streaming-work-pgo-study-attempt02')
BASELINE = Path('/tmp/oriole-streaming-current-profile')
FINAL_SOURCE = Path('/tmp/oriole-cdata-finder-study/source.json')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
load = lambda path: json.loads(Path(path).read_text())

def verified_libraries():
    """Require completed matched builds and bind every frozen library/source."""
    pair = load(PAIR / 'pair-report.json')
    proof = load(PAIR / 'vector-training-proof.json')
    freeze = load(PAIR / 'pair-freeze.json')
    assert pair['status'] == proof['status'] == 'passed'
    assert freeze['status'] == 'frozen'
    assert proof['fresh_workspace_compilations'] == 9
    assert sum(proof['generated_rows'].values()) == 864
    assert proof['all_candidate_rows_equal_each_other_and_prior_three_phases']
    assert proof['same_generated_input_bytes'] and proof['effective_c_only_thinlto']
    assert proof['runtime_source_delta'] == ['crates/oriole/src/lib.rs']
    assert proof['inherited_c_fixture_delta']['excluded_from_cargo_library_inputs']
    assert proof['inherited_c_fixture_delta']['sha256'] == '72162a4d080d2fd018023aed63181663090fc291772a45e121b51187b1fe28d7'
    assert sha(FINAL_SOURCE) == '69b96121a090467b3cea81eb25a4e627976f1a18c4cab628855c9880dd25f982'
    for name, item in freeze['files'].items():
        assert sha(PAIR / name) == item['sha256'], name
    source = load(PAIR / 'source.json')['source_sha256']
    assert source == load(FINAL_SOURCE)['source_sha256']
    assert len(source) == 70
    assert all(sha(SOURCE / name) == digest for name, digest in source.items())
    libraries = {
        'control-normal': (CONTROL / 'normal/liboriole_expat.so', '1a7e89cdf0edd481aa264b018e7ec923ec0e3f37abfa22a82f27920bc2e9e11d'),
        'control-pgo': (CONTROL / 'pgo/runs/run-psjiwn9z/use/liboriole_expat.so', '8e12c1819a58a66ae5530a53433dd08de44921c94a2b39a6282358dfd33c0d1e'),
        'candidate-normal': (PAIR / 'normal/liboriole_expat.so', pair['normal_libraries']['liboriole_expat.so']),
        'candidate-pgo': (Path(pair['pgo_manifest']['path']).parent / 'use/liboriole_expat.so', pair['pgo_libraries']['use/liboriole_expat.so']),
    }
    for name, (path, digest) in libraries.items():
        assert sha(path) == digest, name
    return {name: {'path': str(path), 'sha256': digest} for name, (path, digest) in libraries.items()}
