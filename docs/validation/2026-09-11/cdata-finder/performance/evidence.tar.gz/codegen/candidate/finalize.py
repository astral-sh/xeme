"""Bind the completed bounded Finder diagnostics using saved artifacts only."""
from pathlib import Path
import json
import os
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import ROOT, BASELINE, sha, load, verified_libraries

assert os.sched_getaffinity(0) == {6}
binding = load(ROOT / 'release-binding.json')
gate = load(ROOT / 'assembly-gate.json')
assembly = load(ROOT / 'assembly/collection.json')
profile = load(ROOT / 'profile/report.json')
analysis = load(ROOT / 'instruction-comparison.json')
baseline = load(BASELINE / 'report.json')
assert gate['status'] == 'passed_cached_search_confirmed'
assert profile['status'] == analysis['status'] == 'passed'
assert profile['inputs_unchanged'] and profile['source_unchanged'] and profile['libraries_unchanged']
assert verified_libraries() == profile['libraries'] == assembly['libraries'] == binding['libraries']
assert len(profile['commands']) == len(binding['planned_profile_commands']) == 9
for actual, planned in zip(profile['commands'], binding['planned_profile_commands'], strict=True):
    assert {key: actual[key] for key in ['label', 'argv', 'timeout']} == {
        key: planned[key] for key in ['label', 'argv', 'timeout']}
for folder, commands in [('assembly', assembly['commands']), ('profile', profile['commands'])]:
    for command in commands:
        assert command['exit'] == 0 and 'exception' not in command
        for suffix in ['stdout', 'stderr']:
            assert sha(ROOT / folder / (command['label'] + '.' + suffix)) == command[suffix + '_sha256']
for path, digest in profile['hashes_after'].items():
    assert sha(path) == digest
for path, digest in profile['source_sha256'].items():
    assert sha(Path('/home/dev-user/code/oss/oriole-cdata-finder') / path) == digest

comparisons = []
for row in analysis['comparisons']:
    label = row['label']
    expected = binding['expected_callbacks'][label]
    for suffix in ['preflight', 'profile']:
        output = load(ROOT / 'profile' / (label + '-' + suffix + '.stdout'))
        assert output['version'] == expected['version']
        assert len(output['samples']) == 2
        for actual, sample in zip(output['samples'], expected['samples'], strict=True):
            assert {key: actual[key] for key in sample} == sample
    prior = next(item for item in baseline['profiles'] if item['label'] == label)
    current = next(item for item in profile['profiles'] if item['label'] == label)
    assert sha(ROOT / 'profile' / (label + '.callgrind')) == current['profile_sha256']
    assert current['unparsed_Ir'] == 0 and current['condition']['iterations'] == 1
    constructors = []
    searches = []
    for side in ['control', 'candidate']:
        constructors.append(next(f for f in row[side + '_functions'] if 'packedpair::Finder>::with_pair_impl' in f['function']))
        searches.append(next(f for f in row[side + '_functions'] if 'packedpair::Finder>::find_impl' in f['function']))
    once = next(f for f in row['candidate_functions'] if '<std::sys::sync::once::futex::Once>::call' == f['function'])
    closure = next(f for f in row['candidate_functions'] if 'call_once_force' in f['function'] and 'parse_text' in f['function'])
    assert constructors[1]['incoming_calls'] == once['incoming_calls'] == closure['incoming_calls'] == 1
    comparisons.append({
        'label': label, 'control_Ir': row['control_Ir'], 'candidate_Ir': row['candidate_Ir'],
        'candidate_over_control_Ir': row['candidate_over_control_Ir'],
        'Ir_difference': row['candidate_Ir'] - row['control_Ir'],
        'baseline_inherited_iterations_metadata': prior['condition']['iterations'],
        'actual_warmup_parses_collected': 1, 'actual_measured_parses_collected': 1,
        'control_packedpair_constructions': constructors[0]['incoming_calls'],
        'candidate_packedpair_constructions': constructors[1]['incoming_calls'],
        'candidate_Once_calls': once['incoming_calls'],
        'candidate_Once_inclusive_edge_Ir': once['callers'][0]['inclusive_edge_Ir'],
        'control_packedpair_search_calls': searches[0]['incoming_calls'],
        'candidate_packedpair_search_calls': searches[1]['incoming_calls'],
        'profile_sha256': current['profile_sha256'], 'callbacks': expected,
    })

layout = {}
for flavor in ['normal', 'pgo']:
    control = Path('/tmp/oriole-native-tag-execution-codegen-study/assembly') / ('control-' + flavor + '.sections')
    candidate = ROOT / 'assembly' / ('candidate-' + flavor + '-sections.stdout')
    sizes = []
    for file in [control, candidate]:
        sizes.append({section: int(re.search(r'^' + re.escape(section) + r'\s+(\d+)\s', file.read_text(), re.M)[1])
                      for section in ['.text', '.data', '.bss', '.rodata', '.data.rel.ro']})
    layout[flavor] = {'control': sizes[0], 'candidate': sizes[1],
        'text_ratio': sizes[1]['.text'] / sizes[0]['.text'],
        'control_sections_sha256': sha(control), 'candidate_sections_sha256': sha(candidate)}

report = {
    'status': 'passed_bounded_instruction_diagnostic_unselected',
    'scope': 'Saved-data readback after exactly three approved PGO profiles and bounded normal/PGO assembly inspection. No elapsed timing or normal instruction profile.',
    'controller_sha256': sha(__file__),
    'source_runtime_change': binding['runtime_source_delta'],
    'inherited_fixture_change_separate': binding['inherited_c_fixture_delta'],
    'libraries': verified_libraries(),
    'comparisons': comparisons, 'layout': layout,
    'cached_search_confirmed': True, 'no_eager_initialization_added': True,
    'first_use_collected': 'Each profile is a new native-driver process. Exactly one Finder initialization and packedpair construction is observed within its collected first XML_Parse warmup. Preflight is a separate process. Both warmup and measured XML_Parse bodies, including callbacks, are counted; parser creation/free/loading are outside collection.',
    'metadata_correction': 'Inherited baseline condition.iterations is Vulkan NS0/NS1 = 7 and Wayland NS0 = 64. Actual retained baseline and candidate diagnostic argv use 1 measured iteration plus 1 warmup. Earlier preparation/release/profile prose generalized the inherited value as 7; those sealed originals are preserved, and this per-case correction is authoritative for the diagnostic scope.',
    'mechanism': 'Construction moves behind Once. Cached Finder selects AVX2 search for more spans than one-shot memmem::find; short-span rolling search, guard and cached-state loads remain. The profile shows one packedpair constructor per process versus 694/694/334 in controls, and AVX2 search calls increase to 35126/35126/370 versus 694/694/334.',
    'layout_limit': 'PGO also changes compiler inlining/layout: control next_event_scoped is 127091 bytes; candidate next_event_inner is 123907 bytes with scoped 3175 bytes. Adapter entry grows from 3830 to 10485 bytes. Symbol self-Ir moves between functions, so total changes cannot be assigned solely to removed constructor instructions.',
    'limitations': ['Ir is an instruction count, not elapsed time or a predicted speedup.',
        'Only Vulkan plain/namespaces and Wayland plain at 4096 bytes are covered.',
        'Self costs are disjoint and reconstruct all raw totals; inclusive call edges overlap and are kept separate.',
        'No additional parser, profiler, stress, compiler or elapsed execution occurred after the approved three profiles.'],
    'sessions': [{'id': 43790, 'work': 'bounded assembly', 'reaped': True, 'exit': 0},
        {'id': 82328, 'work': 'all three profiles and annotations', 'reaped': True, 'exit': 0},
        {'id': 60109, 'work': 'saved raw analysis', 'reaped': True, 'exit': 0}],
    'all_first_commands_passed': True, 'all_9_profile_commands_match_release': True,
    'callbacks_versions_counts_hashes_match': True, 'all_raw_totals_reconstructed': analysis['all_raw_totals_reconstructed'],
    'all_source_library_driver_input_hashes_unchanged': True,
    'evidence': {str(path.relative_to(ROOT)): sha(path) for path in sorted(ROOT.rglob('*')) if path.is_file()},
}
output = ROOT / 'receipt.json'
with output.open('x') as file:
    file.write(json.dumps(report, indent=2) + '\n')
assert load(output) == report
print(output, sha(output))
