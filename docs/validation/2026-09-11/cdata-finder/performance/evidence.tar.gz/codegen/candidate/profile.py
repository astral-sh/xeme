"""Run only after root releases matched libraries; XML_Parse instruction counts."""
from pathlib import Path
import json
import os
import re
import signal
import subprocess
import sys
import time
sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import ROOT, PAIR, SOURCE, BASELINE, FINAL_SOURCE, sha, load, verified_libraries

assert os.sched_getaffinity(0) == {1}
libraries = verified_libraries()
library = libraries['candidate-pgo']['path']
baseline = load(BASELINE / 'report.json')
assert baseline['status'] == 'passed' and baseline['inputs_unchanged'] and baseline['source_unchanged']
for path, digest in baseline['hashes_after'].items():
    assert sha(path) == digest, path
for profile in baseline['profiles']:
    assert sha(BASELINE / (profile['label'] + '.callgrind')) == profile['profile_sha256']
out = ROOT / 'profile'
out.mkdir(exist_ok=False)
profiler = Path('/home/dev-user/.cache/oriole/profilers/local/usr')
driver = Path('/tmp/oriole-grammar-bench-plain/native-driver')
inputs = [Path(__file__), ROOT / 'common.py', BASELINE / 'report.json', PAIR / 'pair-freeze.json',
          PAIR / 'pair-report.json', PAIR / 'vector-training-proof.json', PAIR / 'source.json', FINAL_SOURCE,
          driver, Path(library), *map(Path, baseline['hashes_after'])]
record = {'status': 'running', 'scope': 'Candidate PGO versus saved current selected PGO. Vulkan plain/namespaces and Wayland plain, 4096-byte chunks, one warmup and one measured parse both collected inside XML_Parse. Construction/free/loading excluded; callbacks included. No elapsed inference.',
          'first_use_initialization_note': 'Preflight and profile each launch a new native-driver process. No eager Finder initialization is added. Its first search remains inside the first XML_Parse collection in the warmup parse; construction/free outside XML_Parse remain excluded.',
          'baseline_condition_metadata_note': 'Baseline condition.iterations=7 was inherited from the elapsed preflight matrix; actual retained commands used 1 measured iteration. Candidate uses the same actual commands and records iterations=1.',
          'cpu': 1, 'libraries': libraries, 'baseline_report_sha256': sha(BASELINE / 'report.json'),
          'source_sha256': load(FINAL_SOURCE)['source_sha256'],
          'hashes_before': {str(path): sha(path) for path in inputs}, 'commands': [], 'profiles': []}
env = os.environ | {'VALGRIND_LIB': str(profiler / 'libexec/valgrind'), 'LD_PRELOAD': '', 'LD_LIBRARY_PATH': ''}
save = lambda: (out / 'report.json').write_text(json.dumps(record, indent=2) + '\n')

def run(label, argv, timeout):
    """Retain each invocation, outputs and terminal status without retries."""
    row = {'label': label, 'argv': argv, 'timeout': timeout, 'started': time.time()}
    record['commands'].append(row)
    save()
    process = None
    try:
        with (out / (label + '.stdout')).open('xb') as stdout, (out / (label + '.stderr')).open('xb') as stderr:
            process = subprocess.Popen(argv, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
            row['exit'] = process.wait(timeout=timeout)
        assert row['exit'] == 0, label
    except BaseException as error:
        row['exception'] = repr(error)
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            row['exit'] = process.wait()
        raise
    finally:
        row.update(completed=time.time(), stdout_sha256=sha(out / (label + '.stdout')), stderr_sha256=sha(out / (label + '.stderr')))
        save()
    return (out / (label + '.stdout')).read_text()

def observations(text):
    """Compare all callback counts/hashes while ignoring diagnostic elapsed fields."""
    samples = json.loads(text)['samples']
    assert len(samples) == 2 and [sample['warmup'] for sample in samples] == [True, False]
    return [(sample['hash'], sample['elements'], sample['text_bytes']) for sample in samples]

save()
try:
    for prior in baseline['profiles']:
        label = prior['label']
        condition = prior['condition'] | {'iterations': 1}
        commands = {item['label']: item for item in baseline['commands']}
        command = list(commands[label + '-preflight']['argv'])
        assert command[1] == libraries['control-pgo']['path'] and command[3:5] == ['4096', '1']
        command[1] = library
        expected = observations((BASELINE / (label + '-preflight.stdout')).read_text())
        assert observations(run(label + '-preflight', command, 30)) == expected
        output = out / (label + '.callgrind')
        profile_command = list(commands[label + '-profile']['argv'])
        profile_command = [library if arg == libraries['control-pgo']['path'] else '--callgrind-out-file=' + str(output) if arg.startswith('--callgrind-out-file=') else arg for arg in profile_command]
        assert observations(run(label + '-profile', profile_command, 300)) == expected
        total = int(re.search(r'^summary: (\d+)', output.read_text(), re.M)[1])
        annotation = run(label + '-annotation', [str(profiler / 'bin/callgrind_annotate'), '--auto=no', '--threshold=100', '--show-percs=no', str(output)], 30)
        functions = []
        for line in annotation.splitlines():
            match = re.match(r'^\s*([\d,]+)\s+(.+?) \[([^\]]+)\]$', line)
            if match:
                functions.append({'Ir': int(match[1].replace(',', '')), 'function': match[2], 'object': match[3]})
        assert sum(function['Ir'] for function in functions) == total
        record['profiles'].append({'label': label, 'condition': condition, 'Ir': total, 'baseline_Ir': prior['Ir'],
            'candidate_over_control_Ir': total / prior['Ir'], 'Ir_difference': total - prior['Ir'],
            'profile_sha256': sha(output), 'functions': functions, 'unparsed_Ir': 0})
        save()
        print(label, total, total / prior['Ir'], flush=True)
    record['status'] = 'passed'
except BaseException as error:
    record['status'] = 'failed'
    record['exception'] = repr(error)
    raise
finally:
    record['hashes_after'] = {path: sha(path) for path in record['hashes_before']}
    record['inputs_unchanged'] = record['hashes_before'] == record['hashes_after']
    record['source_unchanged'] = all(sha(SOURCE / name) == digest for name, digest in record['source_sha256'].items())
    record['libraries_unchanged'] = verified_libraries() == libraries
    save()
assert record['inputs_unchanged'] and record['source_unchanged'] and record['libraries_unchanged']
print('complete', sha(out / 'report.json'), flush=True)
