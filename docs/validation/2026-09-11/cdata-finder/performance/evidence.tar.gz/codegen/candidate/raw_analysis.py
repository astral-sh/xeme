"""Reconstruct disjoint self costs and overlapping call edges from saved profiles."""
from collections import Counter
from pathlib import Path
import gzip
import json
import re
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import ROOT, BASELINE, sha, load

def extract(path):
    """Read both line-only and instruction+line Callgrind cost records."""
    data = path.read_text()
    positions = re.search(r'^positions: (.+)$', data, re.M)[1].split()
    assert re.search(r'^events: (.+)$', data, re.M)[1].split() == ['Ir']
    names, objects, function_objects = {}, {}, {}
    self_cost, calls, edges, inclusive = Counter(), Counter(), Counter(), Counter()
    current = callee = object_id = edge = None
    for line in data.splitlines():
        match = re.match(r'^(c?ob)=\((\d+)\)(?: (.*))?$', line)
        if match:
            kind, key, name = match.groups()
            if name is not None:
                assert key not in objects or objects[key] == name
                objects[key] = name
            if kind == 'ob':
                object_id = key
            continue
        match = re.match(r'^(c?fn)=\((\d+)\)(?: (.*))?$', line)
        if match:
            kind, key, name = match.groups()
            if name is not None:
                assert key not in names or names[key] == name
                names[key] = name
            if kind == 'fn':
                assert edge is None
                current = key
                assert key not in function_objects or function_objects[key] == object_id
                function_objects[key] = object_id
            else:
                callee = key
            continue
        if line.startswith('calls='):
            assert edge is None
            count = int(line.split('=', 1)[1].split()[0])
            calls[callee] += count
            edges[current, callee] += count
            edge = (current, callee)
            continue
        fields = line.split()
        if fields and re.fullmatch(r'(?:\*|[+-]?(?:0x[\da-fA-F]+|\d+))', fields[0]):
            # Callgrind omits trailing zero event costs on some branch records.
            assert len(fields) in [len(positions), len(positions) + 1], line
            cost = int(fields[len(positions)]) if len(fields) > len(positions) else 0
            if edge is not None:
                inclusive[edge] += cost
                edge = None
            else:
                self_cost[current] += cost
    assert edge is None
    total = int(re.search(r'^summary: (\d+)', data, re.M)[1])
    assert sum(self_cost.values()) == total
    return {'path': str(path), 'sha256': sha(path), 'total_Ir': total, 'positions': positions,
        'functions': [{'function': names[key], 'object': objects.get(function_objects.get(key), '?'),
            'self_Ir': cost, 'self_fraction': cost / total, 'incoming_calls': calls[key],
            'callers': [{'function': names[caller], 'calls': count, 'inclusive_edge_Ir': inclusive[caller, callee]}
                        for (caller, callee), count in edges.most_common() if callee == key]}
            for key, cost in self_cost.most_common()]}

def main():
    """Compare saved candidate/control counts without invoking their libraries."""
    candidate = load(ROOT / 'profile/report.json')
    baseline = load(BASELINE / 'report.json')
    assert candidate['status'] == baseline['status'] == 'passed'
    details = []
    summaries = []
    for row in candidate['profiles']:
        label = row['label']
        prior = next(item for item in baseline['profiles'] if item['label'] == label)
        control = extract(BASELINE / (label + '.callgrind'))
        current = extract(ROOT / 'profile' / (label + '.callgrind'))
        assert control['total_Ir'] == prior['Ir'] and current['total_Ir'] == row['Ir']
        assert control['sha256'] == prior['profile_sha256'] and current['sha256'] == row['profile_sha256']
        details.append({'label': label, 'control': control, 'candidate': current})
        interesting = lambda function: any(name in function['function'] for name in [
            'next_event', 'execute_native', 'execute_general', 'native_tag', 'parse_start',
            'lexical::Buffer', 'prepare_end', 'can_frame_start', 'run_events',
            'parse_text', 'memmem', 'packedpair', 'OnceLock', 'Once>::call', 'CDATA_END',
        ])
        summaries.append({'label': label, 'control_Ir': control['total_Ir'], 'candidate_Ir': current['total_Ir'],
            'candidate_over_control_Ir': current['total_Ir'] / control['total_Ir'],
            'control_functions': [function for function in control['functions'] if interesting(function)],
            'candidate_functions': [function for function in current['functions'] if interesting(function)]})
    with gzip.open(ROOT / 'raw-details.json.gz', 'wt', compresslevel=9) as output:
        json.dump(details, output, sort_keys=True)
    report = {'status': 'passed', 'scope': 'Saved Callgrind disjoint self costs and separate overlapping inclusive edges, including callbacks inside XML_Parse. No instruction-to-elapsed inference.',
        'all_raw_totals_reconstructed': True, 'controller_sha256': sha(__file__),
        'baseline_report_sha256': sha(BASELINE / 'report.json'), 'candidate_report_sha256': sha(ROOT / 'profile/report.json'),
        'details_sha256': sha(ROOT / 'raw-details.json.gz'), 'comparisons': summaries,
        'limitations': ['Inlined source helpers share the enclosing symbol cost. Function self changes alone are not removable-work estimates.',
                       'Inclusive call edges overlap; never add them to disjoint self totals.',
                       'Only three 4KiB PGO conditions are compared. Normal libraries receive assembly inspection; there is no normal instruction measurement in this study.']}
    (ROOT / 'instruction-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
