"""Independent completed Python build/preflight saved review; no target executions."""
from pathlib import Path
import datetime,gzip,hashlib,json,math
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
R=Path('/tmp/oriole-cdata-finder-python-preparation-independent-review.json');assert h(R)=='bb1bf8f5fafd4be9fb970a0dcabe5d7e6d54ace0f05c4395bca08ffb1d88b780';review=j(R)
report={'status':'passed','role':'Independent saved-data review; build and preflight collection by root. No targets or consumer imports.','reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'preparation_review_sha256':h(R),'modes':{},'blockers':[]}
python='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3';source=Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13').resolve();header='/home/dev-user/code/oss/oriole-cdata-finder/include';inc='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/include/python3.12';suffix='.cpython-312-x86_64-linux-gnu.so'
all_expected=None
for mode in ('normal','pgo'):
 D=Path('/tmp/oriole-cdata-finder-'+mode+'-python-study');S=D/'screen';prep=j(D/'preparation.json');a=j(D/'adaptation.json');c=j(D/'prepare-controller.json');b=j(D/'consumers/build.json');p=j(S/'preflight.json')
 assert h(D/'preparation.json')==review['modes'][mode]['preparation_sha256'] and h(D/'adaptation.json')==review['modes'][mode]['adaptation_sha256']
 for path,v in j(D/'preparation-freeze.json')['files'].items():assert h(path)==v
 libs=a['libraries'];assert c['status']=='passed' and c['controller_sha256']==h(D/'run.py') and len(c['jobs'])==2
 common=['--kind','python','--build',str(D/'consumers/build.json'),'--input','/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json','--output',str(S)]
 expected_commands=[['taskset','-c','3',python,'-I','-S',str(D/'build_consumers.py'),'--library',libs['candidate']['path'],'--reference',libs['control']['path'],'--expat',libs['expat']['path'],'--source','/home/dev-user/.cache/oriole/upstream/cpython-3.12.13','--header',header,'--output',str(D/'consumers')],['taskset','-c','3',python,'-I','-S',str(D/'consumer_screen.py'),'--phase','prepare',*common]]
 for row,label,cmd in zip(c['jobs'],['build','preflight'],expected_commands,strict=True):
  assert row['label']==label and row['command']==cmd and row['timeout_seconds']==600 and row['exit']==0 and 'exception' not in row and row['end']>=row['start']
  assert h(D/(label+'-controller.log'))==row['log_sha256']
 assert b['status']=='passed' and b['adaptations'] is None and b['cpython_revision']=='3bb231a6a5dc02b95658877318bf61501a7209e9'
 assert b['source_sha256_before']==b['source_sha256_after']
 expected_source={str(D/'build_consumers.py'),str(source/'Modules/pyexpat.c'),str(source/'Modules/_elementtree.c'),header+'/expat.h',*[v['path'] for v in libs.values()],str(Path(python).resolve())}
 assert set(b['source_sha256_before'])==expected_source
 for path,v in b['source_sha256_before'].items():assert h(path)==v
 assert list(b['consumers'])==['control','expat','candidate']
 compile_count=0;library_paths={};extension_paths={}
 for engine,consumer in b['consumers'].items():
  directory=D/'consumers'/engine;library=directory/Path(libs[engine]['path']).name;library_paths[engine]=str(library)
  assert consumer['directory']==str(directory) and consumer['library']==str(library) and h(library)==libs[engine]['sha256']
  assert set(consumer['files'])=={str(library),*[str(directory/(m+suffix)) for m in ['pyexpat','_elementtree']]}
  for path,v in consumer['files'].items():assert h(path)==v
  for module,cmd in zip(['pyexpat','_elementtree'],consumer['commands'],strict=True):
   expected=['cc','-shared','-fPIC','-O2',*['-I'+x for x in [header,inc,inc+'/internal',str(source/'Modules/expat'),str(source/'Modules')]],str(source/('Modules/'+module+'.c')),str(library),'-Wl,-rpath,'+str(directory),'-o',str(directory/(module+suffix))]
   assert cmd['command']==expected and cmd['returncode']==0 and cmd['log_sha256']==h(directory/(module+'-build.log'));compile_count+=1
  extension_paths[engine]={m:{'path':str(directory/(m+suffix)),'sha256':h(directory/(m+suffix))} for m in ['pyexpat','_elementtree']}
 assert compile_count==6
 assert p['status']=='preflight_passed' and p['kind']=='python' and p['affinity']==[3] and p['pairs']==7 and p['seed']==202609104412
 assert p['conditions']==prep['conditions'] and len(p['preflights'])==len(p['processes'])==72 and p['rows']==[]
 assert p['hashes_before']==p['hashes_after'] and p['hash_errors']=={}
 expected_hashfiles={str(D/'consumer_screen.py'),str(D/'python_worker.py'),python,str(D/'consumers/build.json'),'/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json',*[v['input'] for v in p['conditions']],*[path for consumer in b['consumers'].values() for path in consumer['files']]}
 assert set(p['hashes_before'])==expected_hashfiles
 for path,v in p['hashes_before'].items():assert h(path)==v
 expected={};i=0
 for condition in p['conditions']:
  key=f"{condition['name']}/{condition['chunk']}/{condition['mode']}"
  for engine in ['control','candidate','expat']:
   row,process=p['preflights'][i],p['processes'][i];i+=1
   label=key.replace('/','-')+'-'+engine+'--1-0';spec_path=S/(label+'.json');spec=j(spec_path)
   assert process['label']==row['process']==label and process['status']=='passed' and process['returncode']==0 and process['timeout_seconds']==300
   assert process['command']==[python,'-I','-S',str(D/'python_worker.py'),'--worker',str(spec_path)]
   assert row['key']==key and row['engine']==engine and row['pair']==-1 and row['median_seconds'] is None
   assert spec=={'input':condition['input'],'input_sha256':h(condition['input']),'chunk':condition['chunk'],'mode':condition['mode'],'consumer':str(D/'consumers'/engine),'library_sha256':libs[engine]['sha256'],'iterations':0}
   for stream in ['stdout','stderr']:
    assert process[stream]==label+'-'+stream+'.gz' and h(S/process[stream])==process[stream+'_sha256']
   assert gzip.decompress((S/process['stderr']).read_bytes())==b''
   raw=json.loads(gzip.decompress((S/process['stdout']).read_bytes()));assert raw['gc_enabled'] and raw['python']==b['python']==p['python_version']
   assert raw['samples']==row['samples'] and raw['identity']==row['identity'];identity=raw['identity']
   for module,pin in extension_paths[engine].items():assert identity[module]==pin
   assert identity['parser_library']=={'path':str(Path(library_paths[engine]).resolve()),'sha256':libs[engine]['sha256']}
   assert len(raw['samples'])==1
   v=raw['samples'][0];assert v['iteration']==0 and v['warmup'] is True and v['parse_ns']>0 and v['destruction_ns']>=0 and math.isfinite(v['seconds']) and v['seconds']==(v['parse_ns']+v['destruction_ns'])/1e9
   output=[v['output_sha256'],v['output_rows']]
   assert output[1]>0
   if key in expected:assert expected[key]==output
   else:expected[key]=output
 assert i==72 and expected==p['expected']
 prior=j(Path(prep['parent'])/'screen/preflight.json');assert prior['expected']==expected
 if all_expected is None:all_expected=expected
 else:assert all_expected==expected
 report['modes'][mode]={'preparation_controller_sha256':h(D/'prepare-controller.json'),'build_manifest_sha256':h(D/'consumers/build.json'),'preflight_sha256':h(S/'preflight.json'),'extension_compiles':6,'preflight_processes':72,'canonical_conditions':24,'samples':72,'all_library_copies_and_extensions_rehashed':True,'full_compiler_vectors':'Identical unmodified CPython sources and -shared -fPIC -O2 include/flags; only module, engine-specific linked library/rpath/output differ. Six exact commands checked against builder recipe.','libraries':libs,'extensions':extension_paths,'baseline_canonical_outputs_exact':True,'same_process_origin':'All72 raw worker XML_Parse dladdr records resolve to the expected per-engine library; both extension path/hash identities verified.'}
report['limitations']=['No elapsed results inspected or generated. No fresh strict802 suite or full compatibility claim.','Performance consumers use unmodified CPython, while separately held strict controllers apply the cleanup backport. Adjacent text callbacks are canonically coalesced by the unchanged benchmark.','Build records verify recorded commands/outcomes and artifact/source hashes; no compiler or parser rerun.']
out=Path('/tmp/oriole-cdata-finder-python-build-preflight-independent-review.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':h(out),'status':report['status']}))
