"""Independent source/identity review only; no build, preflight or timing output read."""
from pathlib import Path
import ast,datetime,difflib,hashlib,json
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
report={'status':'passed_preparation_only','reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'Independent agent; Python preparation and all executions are owned by other agents. No targets run and no incomplete execution outputs inspected.','modes':{},'blockers':[]}
B=Path('/tmp/oriole-cdata-finder-pgo-study');C=Path('/tmp/oriole-streaming-work-pgo-study-attempt02');bp=j(B/'pair-report.json');cp=j(C/'pair-report.json')
expected_libs={'normal':{'candidate':bp['normal_libraries']['liboriole_expat.so'],'control':cp['normal_libraries']['liboriole_expat.so'],'expat':'7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'},'pgo':{'candidate':bp['pgo_libraries']['use/liboriole_expat.so'],'control':cp['pgo_libraries']['use/liboriole_expat.so'],'expat':'12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'}}
source=j(B/'source.json')['source_sha256'];control=j(C/'source.json')['source_sha256']
assert len(source)==len(control)==70
source_delta={p:{'control':control[p],'candidate':v} for p,v in source.items() if v!=control[p]}
assert set(source_delta)=={'crates/oriole/src/lib.rs','tests/c/integration.c'}
counts={'conditions':24,'engines':3,'extensions':6,'preflights':72,'cohorts':168,'pairs':7,'timed_workers':504,'measured_parses':25788,'warmups':504}
bounds={'prepare_cpu':3,'timing_cpu':0,'build_seconds':600,'preflight_aggregate_seconds':600,'worker_seconds':300,'timing_aggregate_seconds':1200}
for mode in ('normal','pgo'):
 D=Path('/tmp/oriole-cdata-finder-'+mode+'-python-study');prep=j(D/'preparation.json');a=j(D/'adaptation.json');freeze=j(D/'preparation-freeze.json');parent=Path(prep['parent'])
 assert len(freeze['files'])==10
 for p,v in freeze['files'].items():assert h(p)==v,p
 for name,change in prep['controller_changes'].items():
  old,new=parent/name,D/name;assert h(old)==change['parent_sha256']==a['parent_files'][name] and h(new)==change['candidate_sha256']==a['files'][name]
  expected=old.read_text()
  for left,right in change['replacements']:expected=expected.replace(left,right)
  assert expected==new.read_text() and ast.dump(ast.parse(expected))==ast.dump(ast.parse(new.read_text()))
  delta=''.join(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(old),tofile=str(new)))
  assert delta==(D/(name+'.patch')).read_text()
 assert (D/'build_consumers.py').read_bytes()==(parent/'build_consumers.py').read_bytes()
 assert (D/'python_worker.py').read_bytes()==(parent/'python_worker.py').read_bytes()
 assert len(prep['controller_changes']['consumer_screen.py']['replacements'])==4
 assert prep['controller_changes']['run.py']['replacements']==[['/home/dev-user/code/oss/oriole-streaming-input-bounds/include','/home/dev-user/code/oss/oriole-cdata-finder/include']]
 for key in ('candidate_source_manifest','candidate_pair_freeze','selected_control_source_manifest','selected_control_pair_freeze','parent_adaptation'):
  assert h(a[key]['path'])==a[key]['sha256']
 assert h(prep['preparer']['path'])==prep['preparer']['sha256']
 assert a['source_70_delta']==prep['source_70_delta']==source_delta
 assert h(a['header']['path'])==a['header']['sha256']==control['include/expat.h']
 assert prep['counts']==a['counts']==counts and prep['bounds']==a['bounds']==bounds and prep['seed']==a['seed']==202609104412
 assert set(a['libraries'])==set(expected_libs[mode])
 for engine,pin in a['libraries'].items():assert h(pin['path'])==pin['sha256']==expected_libs[mode][engine]
 consumer=a['consumer_source'];assert consumer['revision']=='3bb231a6a5dc02b95658877318bf61501a7209e9' and consumer['clean']
 for pin in consumer['files'].values():assert h(pin['path'])==pin['sha256']
 assert consumer['files']['pyexpat.c']['sha256']=='fd679a16f36304444af11953ad276d4493f2044f904a39b8fdf028c6f7def8a0'
 for path,v in consumer['interpreter_and_public_headers'].items():assert h(path)==v
 for path,v in prep['input_pins'].items():assert h(path)==v
 manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');iterations={'vulkan':3,'wayland':16,'maven':32,'batik':128,'gtk':64,'docbook':64}
 conditions=[]
 for project in j(manifest)['projects']:
  entry=next(v for v in project['files'] if v['role']=='input');path=(manifest.parent/entry['path']).resolve();assert h(path)==entry['sha256']
  for chunk in (4096,65536):
   for kind in ('elementtree','pyexpat-events'):conditions.append({'name':project['name'],'chunk':chunk,'mode':kind,'input':str(path),'iterations':iterations[project['name']]})
 assert prep['conditions']==conditions and sum(v['iterations'] for v in conditions)*7*3==25788
 tree=ast.parse((D/'consumer_screen.py').read_text());assign={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['ENGINES','RATIOS','ITERATIONS']}
 assert assign['ENGINES']==('control','candidate','expat') and assign['RATIOS']==(('candidate','control'),('control','expat'),('candidate','expat')) and assign['ITERATIONS']==iterations
 report['modes'][mode]={'preparation_sha256':h(D/'preparation.json'),'adaptation_sha256':h(D/'adaptation.json'),'preparation_freeze_sha256':h(D/'preparation-freeze.json'),'frozen_files':10,'parent':str(parent),'controllers':a['files'],'libraries':a['libraries'],'counts':counts,'bounds':bounds,'seed':a['seed']}
report['source_review_sha256']=h('/tmp/oriole-cdata-finder-independent-review.json')
report['findings']=['Exact inherited builder and worker; only one byte-identical header path and four screen captions change. Same six extension compile recipes, fixture order/iterations, seven seeded cohorts and 300s worker/600s build+preflight/1200s elapsed bounds.','Wrapper binds all six mode/engine libraries to reviewed normal/PGO artifacts before use and kills/reaps process groups on timeout/interruption. Library copies, extension paths, same-process XML_Parse dladdr and hash checks remain in the unchanged worker.','No eager Finder initialization added. Imports/read/gc.collect/canonical hashing remain untimed; construction/feed/finalization/callbacks and explicit result destruction timed. First parser use occurs within the discarded warmup, not a new prewarming step.','Benchmark compiles unmodified CPython pyexpat.c and _elementtree.c. It does not apply the cleanup backport used by the separate strict suite. Canonical pyexpat output coalesces adjacent text callbacks; no full strict-suite compatibility inference.','PR125 integration.c is inherited test provenance only, excluded from parser library and extension compilation. All other 68 canonical source entries including the header are unchanged from streaming control.']
report['limitations']=['Preparation and frozen input identities only. Actual six extension compiles and72 preflights per mode await both completed/reaped preparation runs; no execution outcome or elapsed claim in this receipt.','The inherited protocol does not control shared-host frequency/cache/bandwidth and does not execute full upstream projects or external DTD workloads.']
out=Path('/tmp/oriole-cdata-finder-python-preparation-independent-review.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':h(out),'status':report['status']}))
