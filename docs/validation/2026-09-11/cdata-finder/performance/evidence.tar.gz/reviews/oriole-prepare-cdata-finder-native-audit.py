from pathlib import Path
import ast,difflib,hashlib,json
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=Path('/tmp/oriole-review-opt2-native.py');new=Path('/tmp/oriole-review-cdata-finder-native.py');s=old.read_text()
s=s.replace("'/tmp/oriole-opt2-'+phase+'-native-study'","'/tmp/oriole-cdata-finder-'+phase+'-native-study'")
a=s.index(" assert (S/'run.py').read_bytes()")
b=s.index(" # Entire AST match",a)
s=s[:a]+""" assert (S/'run.py').read_bytes()==(T/'run.py').read_bytes()
 assert sha(S/'run.py')=='5f41a419e800e95954424e2a85d2ee988609d830db18dc85c469af801cd8aef5'
 prep=read(S/'adaptation.json');assert prep['source']==str(T)
 assert prep['original_controller_sha256']==sha(old) and prep['controller_sha256']==sha(new)
 expected=old.read_text()
 for before,after in prep['replacement_pairs']:expected=expected.replace(before,after)
 assert expected==new.read_text()
"""+s[b:]
a=s.index(" decision=read('/tmp/oriole-opt2-native-decision/decision.json')")
b=s.index(" report['native'][phase]",a)
s=s[:a]+""" A=read(S/'adaptation.json');B=Path('/tmp/oriole-cdata-finder-pgo-study')
 assert A['build_freeze_sha256']==sha(B/'pair-freeze.json') and A['source_manifest_sha256']==sha(B/'source.json')
 assert A['controller_sha256']==sha(new) and A['wrapper_sha256']==sha(S/'run.py')
 proof=read('/tmp/oriole-cdata-finder-independent-review.json');pair=read(B/'pair-report.json')
 assert proof['status']=='passed' and proof['pair_sha256']==sha(B/'pair-report.json') and proof['freeze_sha256']==sha(B/'pair-freeze.json')
 candidate_digest=pair['normal_libraries']['liboriole_expat.so'] if phase=='normal' else pair['pgo_libraries']['use/liboriole_expat.so']
 assert p['libraries']['candidate']['sha256']==candidate_digest
 for library in p['libraries'].values():assert sha(library['path'])==library['sha256']
 assert set(p['hashes'])=={str(new),str(manifest),'/tmp/oriole-grammar-bench-plain/native-driver',*fixtures.values(),*[v['path'] for v in p['libraries'].values()]}
"""+s[b:]
s=s.replace(" pin('/tmp/oriole-opt2-native-decision/decision.json')\n",'')
s=s.replace("S/'template-preparation.json',S/'template-adaptation.patch',S/'native_screen.py.in',",'')
s=s.replace("report['decision']='O2 remains unselected: normal real improves 1.16% (20/24 lower), but selected PGO real regresses 3.07% (19/24 slower). Generated normal regresses 0.78%; generated PGO improves 1.40%.'","report['decision']='Saved numerical reconstruction only; candidate selection and further correctness gates are separate.'")
s=s.replace("pin('/tmp/oriole-opt2-build-independent-review.json')","pin('/tmp/oriole-cdata-finder-independent-review.json')")
a=s.index("report['configuration_scope']=");b=s.index('\n',a)
s=s[:a]+"report['configuration_scope']='Matched O3 ThinLTO normal and independent generated-only PGO builds; identical actual compiler metadata/vectors, runtime Finder change only. Inherited C fixture differs from streaming control and is excluded from Cargo library inputs. Lazy first initialization stays inside measured parser lifecycle.'"+s[b:]
s=s.replace('One original fixed native campaign per mode, all adverse conditions retained. No Python or full compatibility gates followed rejection.','One original fixed native campaign per mode, all adverse conditions retained. Python and full compatibility gates are outside this review.')
s=s.replace('These data establish a real-project native PGO regression, not a hardware or compiler mechanism. All 56 condition ratios and adverse cases are retained.','All 56 condition ratios and adverse cases are retained; this audit does not establish a hardware or compiler mechanism.')
s=s.replace("'/tmp/oriole-opt2-native-independent-review.json'","'/tmp/oriole-cdata-finder-native-independent-review.json'")
s=s.replace('import ast,datetime,difflib,hashlib,json,math,random,statistics','import ast,datetime,difflib,hashlib,json,math,random,statistics,sys\nassert sys.argv[1:]==["--released"], "Run only after parent confirms both timing campaigns completed and reaped"')
# Preserve the entire independently written worker/cohort/observation/arithmetic section byte-for-byte.
start=" p,f,r=map(read,[D/'protocol.json',D/'preflight.json',D/'results.json'])"
end=" groups['adverse_conditions']=adverse\n"
def core(t):return t[t.index(start):t.index(end)+len(end)]
assert core(s)==core(old.read_text())
ast.parse(s);new.write_text(s)
delta=Path('/tmp/oriole-cdata-finder-native-audit.patch');delta.write_text(''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True),s.splitlines(keepends=True),fromfile=str(old),tofile=str(new))))
checks={}
for phase in ('normal','pgo'):
 S=Path('/tmp/oriole-cdata-finder-'+phase+'-native-study');a=json.loads((S/'adaptation.json').read_text());T=Path(a['source']);before=(T/'native_screen.py').read_text();after=before
 for left,right in a['replacement_pairs']:after=after.replace(left,right)
 assert after==(S/'native_screen.py').read_text() and (T/'run.py').read_bytes()==(S/'run.py').read_bytes()
 checks[phase]={p:sha(S/p) for p in ('adaptation.json','adaptation.patch','native_screen.py','run.py')}
report={'status':'prepared_not_executed','source_audit':str(old),'source_audit_sha256':sha(old),'reader':str(new),'reader_sha256':sha(new),'delta':str(delta),'delta_sha256':sha(delta),'changes':'Finder paths/captions/source-build receipt binding; adapt existing preparation JSON schema; remove O2 decision comparisons and decision text. No changes to worker, cohort, sample, seed, median, callback, fixture, timeout or hash reconstruction.','full_raw_reconstruction_section_byte_identical':True,'expected_per_mode':{'conditions':28,'preflights':84,'timed_workers':588,'cohorts':196,'measured_samples':105420,'timed_warmups':588,'preflight_samples':168,'total_samples':106176},'producer_controller_checks':checks,'release':'Held until both normal and PGO campaigns are completed/reaped and parent releases. Reader requires --released. No raw result files or active logs inspected during preparation.','no_target_execution':True}
out=Path('/tmp/oriole-cdata-finder-native-audit-preparation.json');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':sha(out),'reader_sha256':sha(new)}))
