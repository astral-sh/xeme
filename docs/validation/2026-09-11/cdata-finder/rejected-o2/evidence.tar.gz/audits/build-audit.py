"""Independent saved-file review; no target execution or producer mutations."""
from pathlib import Path
import gzip,hashlib,json,re,shlex,tarfile
O=Path('/tmp/oriole-opt2-pgo-study');B=Path('/tmp/oriole-streaming-work-pgo-study-attempt02');W=Path('/home/dev-user/code/oss/oriole-opt2-study')
load=lambda p:json.loads(Path(p).read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
f=load(O/'pair-freeze.json');assert sha(O/'pair-freeze.json')=='2cea70ce4d8f3b130c6bcf7d76e66f606bd9e0b7aa38c187d00f6558479929cf'
assert len(f['files'])==f['count']==63
for name,v in f['files'].items():assert sha(O/name)==v['sha256'] and (O/name).stat().st_size==v['bytes'],name
c,a=load(B/'pair-report.json'),load(O/'pair-report.json');cm,am=[load(x['pgo_manifest']['path']) for x in (c,a)];cr,ar=Path(cm['run']),Path(am['run'])
assert a['status']==c['status']==am['status']==cm['status']=='passed'
assert sha(O/'pair-report.json')=='8f3185519ce6ad12db8a750916fb0a76e179a19119a919e67410aeacc4510ef6'
assert all(a[k] for k in ('source_unchanged','scripts_unchanged','tools_unchanged'))
assert a['tools_before']==a['tools_after']==c['tools_before']
assert am['cargo_config_sha256']==cm['cargo_config_sha256']
assert am['base_rustflags']==cm['base_rustflags']==[]
assert am['cargo_args']==cm['cargo_args']+['--config=profile.release.opt-level=2']
assert am['toolchain']==cm['toolchain']=='ohm'
for root,pair,m in ((O,a,am),(B,c,cm)):
 assert sha(pair['pgo_manifest']['path'])==pair['pgo_manifest']['sha256']
 for command in pair['commands']:
  assert command['exit']==0 and sha(root/(command['label']+'.log'))==command['log_sha256']
 for command in m['commands']:
  assert command['status']=='passed' and command['returncode']==0
  assert sha(Path(m['run'])/command['log'])==command['log_sha256']
# Compare full actual argument lists; allow only the explicitly reviewed configuration
# differences and private locations/artifact suffixes, retaining lengths and order.
metadata={3:{'oriole_storage':'8ae6edb74b4afbee','oriole':'e41f1ff64bd2ed1c','oriole_expat':'f10a79f8fbc60887'},2:{'oriole_storage':'940fdde942b9ced9','oriole':'3ff054c7a2303f29','oriole_expat':'e21525dd7ff3033d'}}
def read_vectors(root,pair,m,phase):
 log=root/'normal-build.log' if phase=='normal' else Path(m['run'])/next(c['log'] for c in m['commands'] if c['label']=='build-'+phase)
 rows={}
 for line in log.read_text().splitlines():
  if 'Running `' not in line or '--crate-name ' not in line:continue
  args=shlex.split(line.split('Running `',1)[1].rsplit('`',1)[0]);name=args[args.index('--crate-name')+1]
  if name not in metadata[2]:continue
  assert name not in rows;rows[name]=args
 assert set(rows)==set(metadata[2])
 expected=pair['normal_vectors'] if phase=='normal' else pair['pgo_vectors'][phase]
 assert rows=={r['crate']:r['argv'] for r in expected}
 return rows
def canonical(args,name,level,run):
 assert args.count('opt-level='+str(level))==1
 assert [s for s in args if s.startswith('metadata=')]==['metadata='+metadata[level][name]]
 assert args[args.index('--target')+1]=='x86_64-unknown-linux-gnu'
 kinds=[args[i+1] for i,v in enumerate(args[:-1]) if v=='--crate-type']
 assert kinds==(['cdylib','staticlib'] if name=='oriole_expat' else ['lib'])
 assert ('lto=thin' if name=='oriole_expat' else 'linker-plugin-lto') in args
 out=[]
 for s in args:
  if s=='opt-level='+str(level):s='opt-level=<approved>'
  if s=='metadata='+metadata[level][name]:s='metadata=<approved-exact-pair>'
  s=s.replace(str(run),'<fresh-run>')
  s=re.sub(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}(?=/)', '<private-build>',s)
  s=re.sub(r'(?<=extra-filename=-)[0-9a-f]{16}$','<suffix>',s)
  s=re.sub(r'(lib\w+)-[0-9a-f]{16}(\.(?:rlib|rmeta))$',r'\1-<suffix>\2',s)
  out.append(s)
 return out
counts={}
for phase in ('normal','generate','use'):
 left=read_vectors(B,c,cm,phase);right=read_vectors(O,a,am,phase)
 for name in metadata[2]:
  assert len(left[name])==len(right[name])
  assert canonical(left[name],name,3,cr)==canonical(right[name],name,2,ar),(phase,name)
 counts[phase]=len(right)
reference=load(B/'normal-training.json');training=[]
for root,pair,m in ((B,c,cm),(O,a,am)):
 for phase in ('normal','generate','use'):
  p=root/'normal-training.json' if phase=='normal' else Path(m['run'])/(phase+'-training.json');r=load(p)
  assert r['status']=='passed' and len(r['rows'])==288 and r['rows']==reference['rows']
  assert all(row['status']==1 and row['error']==0 and not row['callback_exceptions'] for row in r['rows'])
  assert r['inputs_sha256']==reference['inputs_sha256']
  assert sha(r['xml_parse_origin']['path'])==r['xml_parse_origin']['sha256']==r['library_sha256']
  if phase!='normal':assert sha(p)==m['training_sha256'][phase]
  training.append({'path':str(p),'sha256':sha(p),'rows':288})
assert {p.name:sha(p) for p in (ar/'inputs').iterdir()}=={p.name:sha(p) for p in (cr/'inputs').iterdir()}
for name,digest in am['profiles_sha256'].items():assert sha(ar/name if name=='merged.profdata' else ar/'raw-profiles'/name)==digest
assert am['profiles_sha256']['merged.profdata']!=cm['profiles_sha256']['merged.profdata']
source=load(O/'source.json')['source_sha256'];assert len(source)==70 and source==load(B/'source.json')['source_sha256']
assert all(sha(W/p)==v for p,v in source.items())
with tarfile.open(O/'source.tar.gz') as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==source
scripts=load(O/'tool-source.json');assert len(scripts)==6 and scripts==load(B/'tool-source.json') and all(sha(W/p)==v for p,v in scripts.items())
for name,digest in a['normal_libraries'].items():assert sha(O/'normal'/name)==digest
for name,digest in am['libraries_sha256'].items():assert sha(ar/name)==digest
mr=load(O/'metadata-review.json')
for name,key in [('prove_pair.py','initial_proof_sha256'),('proof-attempt01.log','initial_failure_sha256'),('vector-comparison-preliminary.json','initial_comparison_sha256'),('prove_pair_reviewed.py','reviewed_proof_sha256')]:assert sha(O/name)==mr[key]
initial=load(O/'vector-comparison-preliminary.json');assert initial['status']=='needs_review'
result={'status':'passed','role':'Independent agent saved-data audit; source adaptation/build collection/proof were performed by other agents. No target execution.',
'pair_sha256':sha(O/'pair-report.json'),'freeze_sha256':sha(O/'pair-freeze.json'),'frozen_files':63,'source_files':70,'source_and_six_pipeline_files_equal_streaming_control':True,
'actual_workspace_compilations':counts,'compiler_comparison':'Full raw argument lists equal after opt3/opt2, exact approved per-crate Cargo metadata pairs, private build/run paths and Cargo artifact suffixes only. Argument counts/order checked. This is a complete Cargo O2/O3 configuration comparison, including dependency rebuild effects; not an isolated LLVM-flag causality claim.',
'approved_metadata':metadata,'candidate_generated_records':864,'all_six_candidate_control_phase_reports_equal':True,'training':training,'fresh_profiles':am['profiles_sha256'],
'normal_libraries':a['normal_libraries'],'pgo_use_libraries':{p:v for p,v in am['libraries_sha256'].items() if p.startswith('use/')},
'initial_strict_proof_failure_retained':mr,'initial_failure_interpretation':'The original proof rejected metadata differences. Revised proof accepts only the three explicit per-crate pairs in all phases; no build or parser rerun occurred.',
'blockers':[],'limitations':['Generated-only checks; no fresh O2 workspace/ABI/strict consumer or elapsed claim. Earlier source checks belong to the unchanged source at O3.','All local build/tool outcomes are Ohm; production stable behavior is separate.']}
out=Path('/tmp/oriole-opt2-build-independent-review.json');out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'path':str(out),'sha256':sha(out),'status':'passed'}))
