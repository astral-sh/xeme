# Compact-coordinate validation: prepared, not executed

Root alone may launch these commands after ASan session 11049 and every owned descendant have completed and been reaped, and after confirming no elapsed benchmark or other target campaign overlaps. This preparation did not execute Cargo, rustc, formatting, a parser, tests, Miri, fuzzing, or benchmarks. It did not edit runtime or test source.

Selected production candidate remains the direct-reference-frame runtime `0f66d54ac8418f0a6e628ad18570677a19c9ed45`, published as PR 144 head `4064b0653534aff690c0e0f395a6b3b48da878fc`. Compact coordinates are unselected. The current prototype base is `97117de5ea51b2bd3f5d348cade85c203c6a888e`; dirty checked file bytes, including root's final additions, will identify the prototype until committed.

## 1. Preserve the first formatting result

Finish source/test edits before checks. The following root-only launch stops on the first failed command and preserves its directory:

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-compact-coordinate-validation-prep/checks.py /tmp/oriole-compact-coordinate-validation-prep/checks-attempt01
```

`checks.py` runs, in order: `cargo +ohm -Zohm-defaults=no fmt --all --check`, locked/offline workspace-package check, tests, and clippy with warnings denied. Check/clippy include all targets. Each command has a 900-second bound and a separate owned process group. It logs source before/after, exit, group cleanup and direct-child reaping. A failed attempt remains `incomplete`; it is not a pass. Preserve its stdout, per-command log/JSON, and summary.

If fmt fails solely because the snapshot needs formatting, root may run `cargo +ohm -Zohm-defaults=no fmt --all` in the worktree under the same sanitized environment and a bounded, reaped root-owned command; preserve that formatter log. Review the resulting diff, then launch `checks.py` once again with fresh output directory `checks-attempt02`. If source changes or a substantive failure occurs, fix/review it and use another fresh numbered directory. Never overwrite a first attempt. Internal command labels remain `fmt01/check01/tests01/clippy01` in every directory; the directory distinguishes attempts.

Common environment is explicit in the controller: CARGO_HOME `/home/dev-user/.cache/toucan/cargo`; target `/home/dev-user/.cache/oriole/targets/compact-coordinates`; shared build template `/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}`; one build job; no incremental compilation; no automatic rustup installation. Compiler overrides, profile/linker/rustflags, preload/sanitizer/native-build overrides and all `CARGO_UNSTABLE_OHM_*` trust settings are cleared. The shared build directory must not be deleted. This matches the selected build protocol's Ohm-defaults-disabled choice.

## 2. Freeze only after final passing checks and root review

The source collector combines the selected manifest with all current `crates/**/*.rs`. It explicitly requires `compact_coordinate_tests.rs` and the C `coordinate_tests.rs`; root's additional C tests are included automatically. It does not assume a fixed source-file or passing-test count.

Supply the actual current full HEAD and actual passing count from the final summary/log. If HEAD is still the prototype base, the full base hash above is appropriate. Replace the capitalized placeholders below; they are deliberately not guessed from unexecuted tests:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-compact-coordinate-validation-prep/freeze.py --head FULL_CURRENT_HEAD --expected-test-count ACTUAL_PASSING_COUNT --checks-dir /tmp/oriole-compact-coordinate-validation-prep/checks-attempt02
```

`freeze.py` performs no target execution. It requires all four commands passed and reaped; all checked source hashes match current bytes; no failed/ignored tests; and the supplied count equals the raw test logs. It records dirty status, archives every checked source file with a patch including untracked test modules, reads back the archive, copies all preparation and final check evidence, and pins the unchanged six selected PGO helpers. Output is `/tmp/oriole-compact-coordinates-pgo-study`; it refuses to overwrite an existing directory. A failed freeze or subsequent source change requires root inspection and a fresh reviewed binding, not patching source pins in place.

## 3. Root-only fresh normal and PGO builds

Only after the freeze succeeds, and with every previous local target session reaped:

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-compact-coordinates-pgo-study/build_pair.py
```

The normal target is `/home/dev-user/.cache/oriole/targets/compact-coordinates-build-normal`; the original PGO helper creates distinct `pgo/targets/generate` and `pgo/targets/use` inside the study. Normal and PGO target paths must be fresh. The normal target differs from the checks target. All share the canonical Ohm build-cache template.

The controller retains the selected explicit `x86_64-unknown-linux-gnu` host-target C-only O3 / ThinLTO / one-codegen-unit recipe. It uses `cargo +ohm -Zohm-defaults=no`, the same profile merger and six byte-identical Git144e69e helpers, and only the original generated training corpus. It captures actual workspace compiler vectors for normal/generate/use, tool/source/script hashes and all 288 records per mode (864 records total); normal, instrumented and optimized records must match exactly. No held-out elapsed workload is run here. Normal build is bounded at 900 seconds, PGO pipeline at 2400 seconds, normal generated replay at 300 seconds, and each nested pipeline command at 900 seconds.

On outer interruption/timeout during PGO, the controller first sends SIGINT to the helper and allows 30 seconds for its existing KeyboardInterrupt handler to kill/reap its separately grouped active child. It then kills/reaps the outer group. If `nested_cleanup_graceful` is false, root must inspect and stop any remaining helper-owned descendant before releasing any later target job; direct-child reaping alone does not prove nested cleanup. On normal completion, the existing helper waits for every command. Preserve incomplete reports; never relaunch into an existing pair-report/target directory.

## 4. Focused Miri follow-up: plan only

No dedicated compact-coordinate Miri runner was found or executed. After ordinary checks, root may reuse its existing bounded command runner, verify local Ohm Miri/component availability without installing implicitly, and run the following focused commands in both borrow models (`MIRIFLAGS=''` and `MIRIFLAGS='-Zmiri-tree-borrows'`). Use the same cleared trust/compiler environment and shared build template, with distinct targets `/home/dev-user/.cache/oriole/targets/compact-coordinates-miri-stacked` and `.../compact-coordinates-miri-tree`. Preserve command/source pins, complete output, counts, a timeout and reaping receipts. Use a 900-second per-command bound and serial execution; a timeout is incomplete coverage.

```sh
cargo +ohm -Zohm-defaults=no miri test --locked --offline -p oriole_expat --lib coordinate_tests::
cargo +ohm -Zohm-defaults=no miri test --locked --offline -p oriole --lib compact_coordinate_tests::
cargo +ohm -Zohm-defaults=no miri test --locked --offline -p oriole --lib encoding::tests::deferred_discard_preserves_both_starts_until_the_host_selects_one -- --exact
cargo +ohm -Zohm-defaults=no miri test --locked --offline -p oriole --lib context_text_tests::context_text_native_prefix_precedes_late_accounting_error -- --exact
```

These cover lazy C getter caching/reentry and reset, stale C authority, actual compaction barriers, CRLF checkpoints, and late-accounting error publication. Root's appended C getter/OOM/warmed tests should be included by their actual module/filter once finalized. The existing `oriole_expat --lib context_text_` group adds C pointer/reentry/OOM and warmed-allocation coverage when needed. Verify that every intended filter actually runs nonzero tests. The large adapter every-chunk differential sweep is deliberately left in ordinary tests, not multiplied under Miri.

## Selection and evidence limits

Checks, ASan, Miri, normal/PGO builds, and native elapsed measurements are distinct evidence. This preparation demonstrates none of their outcomes. After semantic validation and builds, perform the normal native screen first using the unchanged selected-control worker protocol. Prepare subsequent normal/PGO native auditors separately. No speed claim, allocation-policy change, API campaign, Python campaign, benchmark result, commit, push, or selection is authorized by preparation alone.
