"""Fresh explicit-target normal and generated-only PGO builds on CPU3."""
from pathlib import Path
import hashlib,json,os,re,shlex,shutil,signal,subprocess,time
O=Path(__file__).parent;W=Path('/home/dev-user/code/oss/oriole-compact-coordinates');P=O/'pipeline';PY='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12';PROF=Path('/tmp/oriole-pgo-study/llvm-tools-1.98.0/bin/llvm-profdata')
assert __debug__ and os.sched_getaffinity(0)=={3};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
CONTROL=Path('/tmp/oriole-reference-frame-pgo-study')
source=load(O/'source.json');scripts=load(O/'tool-source.json');checks=load(O/'source-checks.json');assert checks['status']=='passed' and checks['test_count']>0 and checks['failed']==checks['ignored']==0 and all(row['exit']==0 and row['reaped'] for row in checks['commands']) and sha(O/'source.json')==checks['source_manifest_sha256'];assert sha(O/'local-checks/final-checks.json')==checks['check_report_sha256'];assert all(sha(W/n)==v for n,v in source['source_sha256'].items()) and all(sha(P/n)==v for n,v in scripts.items())
env = os.environ.copy()
removed = []
for key in list(env):
    if key in {'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTDOCFLAGS', 'CARGO_ENCODED_RUSTDOCFLAGS', 'RUSTC', 'RUSTDOC', 'RUSTUP_TOOLCHAIN', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'CARGO_BUILD_RUSTFLAGS', 'CARGO_BUILD_RUSTC', 'CARGO_BUILD_RUSTDOC', 'CARGO_BUILD_RUSTC_WRAPPER', 'CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER', 'LLVM_PROFILE_FILE', 'LD_PRELOAD', 'LD_LIBRARY_PATH', 'ASAN_OPTIONS', 'LSAN_OPTIONS', 'UBSAN_OPTIONS', 'TSAN_OPTIONS', 'MSAN_OPTIONS', 'CC', 'CXX', 'CFLAGS', 'CXXFLAGS', 'CPPFLAGS', 'LDFLAGS', 'AR', 'RANLIB'} or key.startswith(('CARGO_UNSTABLE_OHM_', 'CARGO_PROFILE_')) or (key.startswith('CARGO_TARGET_') and key.endswith(('_RUSTFLAGS', '_LINKER', '_RUNNER'))):
        removed.append(key)
        env.pop(key)
overrides={'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/targets/compact-coordinates-build-normal','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_ENCODED_RUSTFLAGS':'','RUSTUP_AUTO_INSTALL':'0','CARGO_TERM_COLOR':'never'};env.update(overrides)
assert not (O/'pair-report.json').exists(), 'First pair attempt already exists; retain it and use a reviewed fresh attempt directory'
report={'status':'incomplete','source_manifest_sha256':sha(O/'source.json'),'script_source_sha256':sha(O/'tool-source.json'),'env_overrides':overrides,'removed_env':sorted(removed),'commands':[],'scope':'Unselected compact-coordinate prototype versus selected direct-reference frame runtime 0f66d54 (published4064b065). Only one Source checkpoint cursor is added; publication ownership and deferred compaction need their own semantic and allocation gates. The reviewed source snapshot includes both new test modules and is frozen only after final checks on formatted source. Fresh explicit-host-target C-only O3 ThinLTO/cgu1 normal and original-generated-only PGO use the selected reference-frame compiler recipe and six unchanged Git144e69e pipeline helpers. No held-out parsing or elapsed benchmark; selected runtime remains unchanged until a separate measured selection decision.'}
active=None;interrupted=None
def stop(signum,_frame):
 global interrupted
 interrupted=signum
 if active is not None:raise KeyboardInterrupt(f'signal {signum}')
for signum in (signal.SIGINT,signal.SIGTERM):signal.signal(signum,stop)
def save():(O/'pair-report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,cmd,timeout,environment=env):
 global active
 row={'label':label,'argv':cmd,'cwd':str(W),'cpu':3,'timeout':timeout,'start':time.time()};report['commands'].append(row);save();p=None
 with (O/(label+'.log')).open('wb') as f:
  try:
   p=subprocess.Popen(cmd,cwd=W,env=environment,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);active=p
   if interrupted is not None:raise KeyboardInterrupt(f'signal {interrupted}')
   row['exit']=p.wait(timeout=timeout)
   if row['exit']:raise RuntimeError(label+' nonzero')
  except BaseException as e:
   row['exception']=repr(e)
   if p is not None:
    if label=='pgo-pipeline' and p.poll() is None:
     # Its unchanged helper owns nested process groups and reaps them on KeyboardInterrupt.
     try:os.killpg(p.pid,signal.SIGINT)
     except ProcessLookupError:pass
     try:p.wait(timeout=30);row['nested_cleanup_graceful']=True
     except subprocess.TimeoutExpired:row['nested_cleanup_graceful']=False
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    row['exit']=p.wait()
   raise
  finally:
   if p is not None:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    p.wait()
   active=None;f.flush();row['end']=time.time();row['reaped']=p is not None and p.returncode is not None;row['log_sha256']=sha(O/(label+'.log'));save()
 print(label,row['exit'],flush=True);return (O/(label+'.log')).read_text()
def workspace_vectors(text):
 rows=[]
 for line in text.splitlines():
  if 'Running `' not in line or '/rustc ' not in line:continue
  args=shlex.split(line.strip()[len('Running `'):-1]);crate=args[args.index('--crate-name')+1]
  if crate not in ['oriole_storage','oriole','oriole_expat']:continue
  rows.append({'crate':crate,'line':line,'argv':args,'codegen':[args[i+1] for i,x in enumerate(args[:-1]) if x=='-C'],'types':[args[i+1] for i,x in enumerate(args[:-1]) if x=='--crate-type']})
 assert sorted(r['crate'] for r in rows)==['oriole','oriole_expat','oriole_storage']
 final=next(r for r in rows if r['crate']=='oriole_expat');assert final['types']==['cdylib','staticlib'] and 'lto=thin' in final['codegen']
 assert all('--target' in r['argv'] and r['argv'][r['argv'].index('--target')+1]=='x86_64-unknown-linux-gnu' for r in rows)
 return rows
try:
 version=run('rustc-version',['rustc','+ohm','-vV'],30);host=re.search(r'^host: (.+)$',version,re.M)[1];assert host=='x86_64-unknown-linux-gnu';report['host']=host;report['rustc_version']=version
 sysroot=Path(run('sysroot',['rustc','+ohm','--print','sysroot'],30).strip());compiler=sysroot/'bin/rustc';profversion=run('profdata-version',[str(PROF),'--version'],30)
 assert re.search(r'LLVM version:?\s+(\d+\.\d+\.\d+)',version)[1]==re.search(r'LLVM version:?\s+(\d+\.\d+\.\d+)',profversion)[1]
 report['tools_before']={str(p.resolve()):sha(p) for p in [compiler,sysroot/'bin/cargo',PROF,Path(PY),*list((sysroot/'lib').glob('libLLVM*')),*list((PROF.parent.parent/'lib').glob('libLLVM*'))] if p.is_file()};save()
 assert not Path(overrides['CARGO_TARGET_DIR']).exists(), 'Fresh normal target required'
 assert not (O/'pgo').exists(), 'Fresh generate/use targets required'
 for n in source['source_sha256']:os.utime(W/n,None)
 cmd=['cargo','+ohm','-Zohm-defaults=no','rustc','--release','--locked','--offline','--target',host,'-p','oriole_expat','--lib','--crate-type','cdylib,staticlib','--verbose']
 text=run('normal-build',cmd,900,env|{'RUSTC':str(compiler)});normal=O/'normal';normal.mkdir();report['normal_libraries']={}
 for n in ['liboriole_expat.so','liboriole_expat.a']:
  shutil.copyfile(Path(overrides['CARGO_TARGET_DIR'])/host/'release'/n,normal/n);report['normal_libraries'][n]=sha(normal/n)
 report['normal_vectors']=workspace_vectors(text);report['normal_identical_to_explicit_control']={n:sha(normal/n)==sha((CONTROL/'normal')/n) for n in report['normal_libraries']};save()
 command=[PY,'-I','-S',str(P/'tools/pgo/build.py'),'--source',str(W),'--output',str(O/'pgo'),'--llvm-profdata',str(PROF),'--toolchain','ohm','--cargo-arg=-Zohm-defaults=no','--command-timeout','900']
 run('pgo-pipeline',command,2400)
 latest=load(O/'pgo/latest.json');mp=Path(latest['manifest']);assert sha(mp)==latest['sha256'];m=load(mp);assert m['status']=='passed' and m['compared_parses']==288
 report['pgo_manifest']={'path':str(mp),'sha256':sha(mp)};report['pgo_libraries']=m['libraries_sha256'];report['pgo_vectors']={}
 for phase in ['generate','use']:
  entry=next(r for r in m['commands'] if r['label']=='build-'+phase);report['pgo_vectors'][phase]=workspace_vectors((mp.parent/entry['log']).read_text())
  training=load(mp.parent/(phase+'-training.json'));assert training['status']=='passed' and len(training['rows'])==288
 # The matching uninstrumented control replays the very same generated corpus;
 # this cannot add any profile data because it is not instrumented and the env is clean.
 run('normal-generated-replay',[PY,'-I','-S',str(P/'tools/pgo/train.py'),'--library',str(normal/'liboriole_expat.so'),'--inputs',str(mp.parent/'inputs'),'--report',str(O/'normal-training.json')],300)
 nr=load(O/'normal-training.json');assert nr['status']=='passed' and nr['rows']==load(mp.parent/'generate-training.json')['rows']==load(mp.parent/'use-training.json')['rows'];report['generated_parse_records']={'normal':288,'instrumented':288,'optimized':288};report['all_generated_rows_exact']=True
 report['status']='passed'
finally:
 report['source_unchanged']=all(sha(W/n)==v for n,v in source['source_sha256'].items());report['scripts_unchanged']=all(sha(P/n)==v for n,v in scripts.items())
 if 'tools_before' in report:report['tools_after']={p:sha(p) for p in report['tools_before']};report['tools_unchanged']=report['tools_before']==report['tools_after']
 save()
assert report['source_unchanged'] and report['scripts_unchanged'] and report['tools_unchanged'];print(json.dumps({'status':report['status'],'normal':report.get('normal_libraries'),'pgo':report.get('pgo_libraries')}),flush=True)
