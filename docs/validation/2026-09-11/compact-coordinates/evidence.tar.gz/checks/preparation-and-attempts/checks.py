from pathlib import Path
import hashlib, json, os, re, signal, subprocess, sys, time

W = Path('/home/dev-user/code/oss/oriole-compact-coordinates')
PREP = Path(__file__).resolve().parent
assert len(sys.argv) == 2, 'Pass a fresh output directory for this check attempt'
O = Path(sys.argv[1]).resolve()
O.mkdir(exist_ok=False)
assert os.sched_getaffinity(0) == {3}
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source_paths = set(json.loads((PREP/'selected-source.json').read_text())['source_sha256'])
source_paths.update(str(p.relative_to(W)) for p in (W/'crates').rglob('*.rs'))
sources = lambda: {name: sha(W/name) for name in sorted(source_paths)}
env = os.environ.copy()
removed = []
for key in list(env):
    if key in {'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTDOCFLAGS', 'CARGO_ENCODED_RUSTDOCFLAGS', 'RUSTC', 'RUSTDOC', 'RUSTUP_TOOLCHAIN', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'CARGO_BUILD_RUSTFLAGS', 'CARGO_BUILD_RUSTC', 'CARGO_BUILD_RUSTDOC', 'CARGO_BUILD_RUSTC_WRAPPER', 'CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER', 'LLVM_PROFILE_FILE', 'LD_PRELOAD', 'LD_LIBRARY_PATH', 'ASAN_OPTIONS', 'LSAN_OPTIONS', 'UBSAN_OPTIONS', 'TSAN_OPTIONS', 'MSAN_OPTIONS', 'CC', 'CXX', 'CFLAGS', 'CXXFLAGS', 'CPPFLAGS', 'LDFLAGS', 'AR', 'RANLIB'} or key.startswith(('CARGO_UNSTABLE_OHM_', 'CARGO_PROFILE_')) or (key.startswith('CARGO_TARGET_') and key.endswith(('_RUSTFLAGS', '_LINKER', '_RUNNER'))):
        removed.append(key)
        env.pop(key)
env.update(CARGO_HOME='/home/dev-user/.cache/toucan/cargo', CARGO_TARGET_DIR='/home/dev-user/.cache/oriole/targets/compact-coordinates', CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}', CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', RUSTUP_AUTO_INSTALL='0', CARGO_TERM_COLOR='never')
assert not (O/'summary.json').exists()
report = {'status': 'incomplete', 'commands': [], 'removed_env': sorted(removed), 'runner_sha256': sha(__file__), 'scope': 'First fmt check; no automatic formatting, retry or target release. Preserve this attempt.'}
proc = None
interrupted = None
def stop(signum, _frame):
    global interrupted
    interrupted = signum
    if proc is not None:
        raise KeyboardInterrupt(f'signal {signum}')
for signum in (signal.SIGINT, signal.SIGTERM):
    signal.signal(signum, stop)
save = lambda: (O/'summary.json').write_text(json.dumps(report, indent=2)+'\n')
packages = ['--locked', '--offline', '-p', 'oriole', '-p', 'oriole_expat', '-p', 'oriole_storage']
try:
    for label, args in [('fmt01', ['fmt', '--all', '--check']), ('check01', ['check', *packages, '--all-targets']), ('tests01', ['test', *packages]), ('clippy01', ['clippy', *packages, '--all-targets', '--', '-D', 'warnings'])]:
        cmd = ['cargo', '+ohm', '-Zohm-defaults=no', *args]
        row = {'label': label, 'command': cmd, 'cwd': str(W), 'affinity': [3], 'source_before': sources(), 'start': time.time()}
        report['commands'].append(row)
        save()
        proc = None
        with (O/(label+'.log')).open('wb') as log:
            try:
                proc = subprocess.Popen(cmd, cwd=W, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                if interrupted is not None:
                    raise KeyboardInterrupt(f'signal {interrupted}')
                row['exit'] = proc.wait(timeout=900)
            except BaseException as error:
                row['exception'] = repr(error)
                if proc is not None:
                    try:
                        os.killpg(proc.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    row['exit'] = proc.wait()
                raise
            finally:
                if proc is not None:
                    try:
                        os.killpg(proc.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    proc.wait()
                row.update(end=time.time(), reaped=proc is not None and proc.returncode is not None, source_after=sources())
                log.flush()
                row['log_sha256'] = sha(O/(label+'.log'))
                (O/(label+'.json')).write_text(json.dumps(row, indent=2)+'\n')
                save()
        assert row['exit'] == 0 and row['source_before'] == row['source_after'], label
        print(label, 'passed', flush=True)
    counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (O/'tests01.log').read_text())
    assert counts and all(int(failed) == int(ignored) == 0 for _, failed, ignored in counts)
    report.update(status='passed', test_count=sum(int(count) for count, _, _ in counts), test_groups=len(counts), source_after=sources())
finally:
    save()
print(json.dumps({'status': report['status'], 'test_count': report.get('test_count'), 'test_groups': report.get('test_groups')}), flush=True)
