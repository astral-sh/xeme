"""Freeze root-reviewed, formatted compact-coordinate source after completed checks; prepare builds only."""
from pathlib import Path
import argparse
import ast
import difflib
import hashlib
import json
import re
import shutil
import subprocess
import gzip
import io
import tarfile

PREP = Path(__file__).resolve().parent
OUTPUT = Path('/tmp/oriole-compact-coordinates-pgo-study')
WORKTREE = Path('/home/dev-user/code/oss/oriole-compact-coordinates')
CONTROL = Path('/tmp/oriole-reference-frame-pgo-study')
CHECKS = PREP / 'checks-attempt02'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--head', required=True, help='Root-confirmed current HEAD; dirty checked source is frozen by byte hashes')
    parser.add_argument('--expected-test-count', required=True, type=int, help='Root-confirmed count from completed tests')
    parser.add_argument('--checks-dir', type=Path, default=CHECKS, help='Completed summary.json and per-command JSON/log receipts')
    args = parser.parse_args()
    checks_root = args.checks_dir.resolve()
    check_labels = ['fmt01', 'check01', 'tests01', 'clippy01']
    test_label = 'tests01'
    assert args.expected_test_count > 0
    assert __debug__ and re.fullmatch('[0-9a-f]{40}', args.head)
    head = subprocess.check_output(['git', '-C', str(WORKTREE), 'rev-parse', 'HEAD'], text=True).strip()
    assert head == args.head
    dirty = bool(subprocess.check_output(['git', '-C', str(WORKTREE), 'status', '--porcelain']))
    control = read(CONTROL / 'source.json')
    paths = set(control['source_sha256'])
    paths.update(str(path.relative_to(WORKTREE)) for path in (WORKTREE / 'crates').rglob('*.rs'))
    assert {'crates/oriole/src/compact_coordinate_tests.rs', 'crates/oriole_expat/src/coordinate_tests.rs'} <= paths
    source = {name: sha(WORKTREE / name) for name in sorted(paths)}
    delta = sorted(name for name, digest in source.items() if control['source_sha256'].get(name) != digest)
    assert delta and len(source) >= 74
    commands = []
    checked_files = set(source)
    summary = read(checks_root / 'summary.json')
    assert summary['status'] == 'passed' and summary['test_count'] == args.expected_test_count
    assert [row['label'] for row in summary['commands']] == check_labels
    assert summary['source_after'] == source
    for label in check_labels:
        row = read(checks_root / (label + '.json'))
        assert row == next(command for command in summary['commands'] if command['label'] == label)
        assert row['exit'] == 0 and row['reaped'] and row['source_before'] == row['source_after']
        assert set(row['source_after']) == checked_files
        assert all(source[name] == digest for name, digest in row['source_after'].items())
        assert sha(checks_root / (label + '.log')) == row['log_sha256']
        commands.append(row | {'argv': row['command'], 'source_unchanged': True, 'source_sha256': row['source_after']})
    groups = [tuple(map(int, values)) for values in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (checks_root / (test_label + '.log')).read_text())]
    assert groups and sum(row[0] for row in groups) == args.expected_test_count and all(row[1:] == (0, 0) for row in groups)
    assert len(groups) == summary['test_groups']
    scripts = read(CONTROL / 'tool-source.json')
    assert len(scripts) == 6 and all(sha(CONTROL / 'pipeline' / name) == digest for name, digest in scripts.items())
    before = (PREP / 'prior/build_pair.py').read_text()
    after = (PREP / 'build_pair.py').read_text()
    ast.parse(after)
    assert not OUTPUT.exists(), 'Retain every first attempt; no overwrite'
    OUTPUT.mkdir()
    save(OUTPUT / 'source.json', {'status': 'recorded_source', 'base_runtime': control['candidate_base_commit'], 'candidate_base_commit': head, 'worktree_dirty_at_freeze': dirty, 'source_identity': 'Exact checked bytes below; HEAD alone does not identify a dirty prototype', 'worktree': str(WORKTREE), 'source_sha256': source, 'source_count': len(source), 'scope': 'Compact coordinates and deferred native compaction remain unselected. Snapshot includes all current Rust source and both new test modules after formatting and successful checks; original generated training and compiler settings remain unchanged.'} )
    patch = subprocess.check_output(['git', '-C', str(WORKTREE), 'diff', control['candidate_base_commit'], '--', *delta], text=True)
    untracked = set(subprocess.check_output(['git', '-C', str(WORKTREE), 'ls-files', '--others', '--exclude-standard'], text=True).splitlines())
    for name in sorted(untracked & set(source)):
        patch += f'diff --git a/{name} b/{name}\nnew file mode 100644\n' + ''.join(difflib.unified_diff([], (WORKTREE / name).read_text().splitlines(True), fromfile='/dev/null', tofile='b/' + name))
    (OUTPUT / 'source.patch').write_text(patch)
    with (OUTPUT / 'source.tar.gz').open('wb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as archive:
                for name in source:
                    data = (WORKTREE / name).read_bytes()
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    archive.addfile(info, io.BytesIO(data))
    shutil.copytree(PREP, OUTPUT / 'validation-preparation')
    (OUTPUT / 'local-checks').mkdir()
    save(OUTPUT / 'local-checks/final-checks.json', {'status': 'passed', 'commands': commands})
    shutil.copytree(checks_root, OUTPUT / 'local-checks/original')
    for row in commands:
        dest = OUTPUT / 'local-checks' / row['label']
        dest.mkdir()
        shutil.copyfile(checks_root / (row['label'] + '.json'), dest / 'report.json')
        shutil.copyfile(checks_root / (row['label'] + '.log'), dest / 'output.log')
    save(OUTPUT / 'source-checks.json', {'status': 'passed', 'test_count': args.expected_test_count, 'test_groups': len(groups), 'failed': 0, 'ignored': 0, 'commands': commands, 'source_manifest_sha256': sha(OUTPUT / 'source.json'), 'check_report_sha256': sha(OUTPUT / 'local-checks/final-checks.json')})
    for name in scripts:
        dest = OUTPUT / 'pipeline' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(CONTROL / 'pipeline' / name, dest)
    shutil.copyfile(CONTROL / 'tool-source.json', OUTPUT / 'tool-source.json')
    (OUTPUT / 'build_pair.py').write_text(after)
    (OUTPUT / 'controller.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True))))
    save(OUTPUT / 'preparation.json', {'status': 'prepared_not_executed', 'head': head, 'checks_directory': str(checks_root), 'check_labels': check_labels, 'expected_source_delta': delta, 'expected_pipeline_delta': [name for name in delta if not name.startswith('tests/c/')], 'expected_test_count': args.expected_test_count, 'test_groups': len(groups), 'control_head': control['candidate_base_commit'], 'preparer_sha256': sha(__file__), 'source_manifest_sha256': sha(OUTPUT / 'source.json'), 'controller_sha256': sha(OUTPUT / 'build_pair.py'), 'compiler_training_body_preserved_except_process_cleanup': True, 'dirty_at_freeze': dirty, 'source_count': len(source), 'targets_executed': False, 'measurement_order': 'Root owns all target release. Normal native first; separate measured decision before selection. Selected runtime remains 0f66d54/published4064b065.'})
    assert all(sha(WORKTREE / name) == digest for name, digest in source.items()), 'Source changed while freezing'
    with tarfile.open(OUTPUT / 'source.tar.gz', 'r:gz') as archive:
        assert {member.name: hashlib.sha256(archive.extractfile(member).read()).hexdigest() for member in archive.getmembers()} == source
    print((OUTPUT / 'preparation.json').read_text())


if __name__ == '__main__':
    main()
