"""Saved CI callback-Miri outcome review; does not execute any targets."""
from pathlib import Path
import collections,hashlib,json,os,re
assert os.sched_getaffinity(0)=={6}
ROOT=Path(__file__).parent
HEAD='be31c37baadcc711a84120c487ac13383dd0ccc7'
def read(name):return json.loads((ROOT/name).read_bytes())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
run=read('run.json');jobs=read('jobs.json')['jobs'];workflow=(ROOT/'workflow.yml').read_text()
assert run['id']==34656684670 and run['head_sha']==HEAD
assert run['status']=='completed' and run['conclusion']=='success'
assert len(jobs)==16 and all(j['status']=='completed' and j['conclusion']=='success' for j in jobs)
assert all(j.get('head_sha',HEAD)==HEAD for j in jobs)
core={f'context_text_tests::{name}' for name in [
 'context_text_native_prefix_precedes_late_accounting_error',
 'context_text_bounds_and_ordinary_api_reuse',
 'context_text_excluded_sources_keep_owned_text',
 'context_text_foreign_generation_uses_owned_events']}
c={f'context_text_tests::{name}' for name in [
 'context_text_pointer_survives_reentry_suspend_and_abort',
 'context_text_offsets_compaction_split_utf8_and_sizes',
 'context_text_default_and_excluded_paths_keep_exact_bytes',
 'context_text_frame_and_raw_oom_match_owned_mode',
 'context_text_invalid_host_range_fails_closed',
 'context_text_warmed_reservations_do_not_allocate',
 'context_text_late_handler_after_suspension_uses_eager_raw']}
coordinates_core={
 'compact_coordinate_tests::next_delivery_discards_after_saving_the_committed_event_even_when_it_fails',
 'compact_coordinate_tests::feed_discards_before_appending_and_keeps_the_old_c_publication_resolvable'}
coordinates_source={'encoding::tests::deferred_discard_preserves_both_starts_until_the_host_selects_one'}
coordinates_c={
 'coordinate_tests::native_coordinate_getters_preserve_bytes_and_resolve_exact_positions',
 'coordinate_tests::native_text_getters_survive_source_discard_after_suspension',
 'coordinate_tests::suspended_coordinates_survive_rejected_reset_and_encoding_release',
 'coordinate_tests::stale_same_generation_c_coordinates_fail_closed'}
expected=core|c|coordinates_core|coordinates_source|coordinates_c
assert len(expected)==18
for name in expected:assert name in workflow or name.split('::',1)[-1] in workflow
assert 'nightly-2026-09-10' in workflow
commands=[
 'cargo miri test --locked -p oriole --lib context_text_',
 'cargo miri test --locked -p oriole_expat --lib context_text_',
 'cargo miri test --locked -p oriole --lib compact_coordinate_tests::',
 'cargo miri test --locked -p oriole --lib encoding::tests::deferred_discard_preserves_both_starts_until_the_host_selects_one -- --exact',
 'cargo miri test --locked -p oriole_expat --lib coordinate_tests::']
raw=(ROOT/'workflow.log').read_text();models={}
for model in ['stacked','tree']:
    jobname=f'C callback aliasing ({model})'
    matches=[j for j in jobs if j['name']==jobname];assert len(matches)==1
    job=matches[0];steps={s['name']:s['conclusion'] for s in job['steps']}
    required=['Record interpreter and prepare sysroot','Verify focused test selection','Check core frame protocol','Check callback pointers and re-entry','Check deferred coordinate compaction','Check callback coordinate publication']
    assert all(steps[s]=='success' for s in required)
    lines=[line for line in raw.splitlines() if line.startswith(jobname+'\t')]
    assert lines,jobname
    text='\n'.join(lines)
    outcomes=re.findall(r'\btest ((?:context_text_tests|compact_coordinate_tests|encoding::tests|coordinate_tests)::[a-zA-Z0-9_]+) \.\.\. ok\s*$',text,re.M)
    assert collections.Counter(outcomes)==collections.Counter(expected),(model,outcomes)
    summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)
    assert [int(row[0]) for row in summaries]==[4,7,2,1,4],(model,summaries)
    assert all(row[1:4]==('0','0','0') for row in summaries)
    for command in commands:assert command in text
    selection='\n'.join(line for line in lines if '\tVerify focused test selection\t' in line)
    assert all(name in selection or name.split('::',1)[-1] in selection for name in expected)
    assert 'assert actual == names, (target, actual)' in selection
    assert 'assert actual == {f"context_text_tests::{name}" for name in names}' in selection
    flags=re.findall(r'\bMIRIFLAGS:\s*([^\n]*)',text)
    assert flags
    assert (any('-Zmiri-tree-borrows' in line for line in flags))==(model=='tree')
    assert not re.search(r'error: Undefined Behavior|test result: FAILED|panicked at|Traceback \(most recent call last\)',text)
    models[model]={'job_id':job['id'],'job_name':jobname,'selection_step':'success; exact five expected sets checked by pinned workflow','executed_tests':outcomes,'group_counts':[4,7,2,1,4],'passed':18,'failed':0,'miri_flags':'-Zmiri-tree-borrows' if model=='tree' else '', 'steps':{s:steps[s] for s in required},'job_log_sha256':hashlib.sha256(text.encode()).hexdigest()}
report={
 'status':'passed saved CI review','scope':'Existing remote CI metadata and full raw log only. No compiler/parser/interpreter/Miri target executed locally. All16 jobs passed; focused callback Miri sets/execution are the bounded review focus.',
 'run_id':run['id'],'url':run['html_url'],'head':HEAD,'event':run['event'],'conclusion':run['conclusion'],'jobs_passed':16,
 'models':models,'total_focused_passes':36,'findings':[],
 'inputs':{name:sha(ROOT/name) for name in ['run.json','jobs.json','workflow.log','workflow.yml']},
 'reader_sha256':sha(__file__),
 'limitations':'These are focused Miri aliasing/ownership checks under two models, not exhaustive safety or full compatibility/performance evidence. CI CPython jobs use their explicit text-fragmentation allowance; they do not erase the preserved strict failures in separate reports.'}
out=ROOT/'review.json';assert not out.exists();out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':report['status'],'head':HEAD,'jobs_passed':16,'focused_miri_passes_each':18,'review_sha256':sha(out)},indent=2))
