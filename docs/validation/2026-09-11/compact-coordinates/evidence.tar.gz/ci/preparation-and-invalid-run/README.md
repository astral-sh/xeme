# Coordinate Miri CI extension

Only the existing C callback aliasing job in `.github/workflows/ci.yml` changed. Its pinned nightly, owner-sensitive runner expression, two borrow models, timeout, and all existing context-text selection/execution remain unchanged.

The job lists and requires exactly 2 compact-coordinate core tests, 1 Source checkpoint test, and 4 C coordinate tests before executing them under each existing borrow model. Full source names were checked by saved-text readback; the embedded selection Python was parsed without execution.

No local Cargo, Rust compiler, Miri, tests, formatting, commit, push, or workflow dispatch occurred. Only the workflow file was edited. Root owns dispatch and all runtime evidence. The earlier local Miri plan is superseded by this pinned-nightly CI route because local toolchain inspection found no Miri binary.
