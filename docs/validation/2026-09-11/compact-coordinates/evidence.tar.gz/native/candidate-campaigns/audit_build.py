"""Saved-data build audit against selected reference; no compiler/parser targets."""
from pathlib import Path
import hashlib,json,re,shlex,subprocess,tarfile,os
assert os.sched_getaffinity(0)=={6}
O=Path('/tmp/oriole-compact-coordinates-pgo-study');B=Path('/tmp/oriole-reference-frame-pgo-study');W=Path('/home/dev-user/code/oss/oriole-compact-coordinates');P=O/'pipeline'
load=lambda p:json.loads(Path(p).read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
inputs={}
def pin(p,expected=None):
 p=Path(p);h=sha(p)
 if expected is not None:assert h==expected,(str(p),h,expected)
 inputs[str(p)]=h
 return h
pin(O/'source.json','560ccfd88db962696486de09b24f0bfad250f3a4fabc97fd2acfadeeb57b1014')
pin(B/'source.json','a8db4ea9e6fa1c56020e8a231343c356bce7dc6170e0766b09cc67dabd82a2af')
pin(B/'pair-report.json','c373ff0960db9318f2af70cdc22cec2cf61f25d80ee1d9670b58d00f8351ceda')
pin(O/'pair-report.json')
c,a=load(B/'pair-report.json'),load(O/'pair-report.json');cm,am=[load(x['pgo_manifest']['path']) for x in (c,a)];cr,ar=Path(cm['run']),Path(am['run'])
assert a['status']==c['status']==am['status']==cm['status']=='passed'
assert all(a[k] for k in ('source_unchanged','scripts_unchanged','tools_unchanged'))
assert a['tools_before']==a['tools_after']==c['tools_before']
for key in ('cargo_config_sha256','base_rustflags','cargo_args','toolchain','host','rustc_version','cargo_version','profdata_version','python_version','tools_sha256'):assert am[key]==cm[key],key
for path,h in (a['tools_before']|am['tools_sha256']).items():assert sha(path)==h,path
for root,pair,m in ((O,a,am),(B,c,cm)):
 assert sha(pair['pgo_manifest']['path'])==pair['pgo_manifest']['sha256']
 for command in pair['commands']:
  assert command['exit']==0 and sha(root/(command['label']+'.log'))==command['log_sha256']
 for command in m['commands']:
  assert command['status']=='passed' and command['returncode']==0
  assert sha(Path(m['run'])/command['log'])==command['log_sha256']
metadata={'oriole_storage':'8ae6edb74b4afbee','oriole':'e41f1ff64bd2ed1c','oriole_expat':'f10a79f8fbc60887'}
def read_vectors(root,pair,m,phase):
 log=root/'normal-build.log' if phase=='normal' else Path(m['run'])/next(c['log'] for c in m['commands'] if c['label']=='build-'+phase)
 rows={}
 for line in log.read_text().splitlines():
  if 'Running `' not in line or '--crate-name ' not in line:continue
  args=shlex.split(line.split('Running `',1)[1].rsplit('`',1)[0]);name=args[args.index('--crate-name')+1]
  if name not in metadata:continue
  assert name not in rows;rows[name]=args
 assert set(rows)==set(metadata)
 expected=pair['normal_vectors'] if phase=='normal' else pair['pgo_vectors'][phase]
 assert rows=={r['crate']:r['argv'] for r in expected}
 return rows
def canonical(args,name,run):
 assert args.count('opt-level=3')==1
 assert [s for s in args if s.startswith('metadata=')]==['metadata='+metadata[name]]
 assert args[args.index('--target')+1]=='x86_64-unknown-linux-gnu'
 kinds=[args[i+1] for i,v in enumerate(args[:-1]) if v=='--crate-type']
 assert kinds==(['cdylib','staticlib'] if name=='oriole_expat' else ['lib'])
 assert ('lto=thin' if name=='oriole_expat' else 'linker-plugin-lto') in args
 out=[]
 for s in args:
  s=s.replace(str(run),'<fresh-run>')
  s=re.sub(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}(?=/)', '<private-build>',s)
  s=re.sub(r'(?<=extra-filename=-)[0-9a-f]{16}$','<suffix>',s)
  s=re.sub(r'(lib\w+)-[0-9a-f]{16}(\.(?:rlib|rmeta))$',r'\1-<suffix>\2',s)
  out.append(s)
 return out
counts={}
for phase in ('normal','generate','use'):
 left=read_vectors(B,c,cm,phase);right=read_vectors(O,a,am,phase)
 for name in metadata:
  assert len(left[name])==len(right[name])
  assert canonical(left[name],name,cr)==canonical(right[name],name,ar),(phase,name)
 counts[phase]=len(right)
reference=load(B/'normal-training.json');training=[]
for root,pair,m in ((B,c,cm),(O,a,am)):
 for phase in ('normal','generate','use'):
  p=root/'normal-training.json' if phase=='normal' else Path(m['run'])/(phase+'-training.json');r=load(p)
  assert r['status']=='passed' and len(r['rows'])==288 and r['rows']==reference['rows']
  assert all(row['status']==1 and row['error']==0 and not row['callback_exceptions'] for row in r['rows'])
  assert r['inputs_sha256']==reference['inputs_sha256']
  assert sha(r['xml_parse_origin']['path'])==r['xml_parse_origin']['sha256']==r['library_sha256']
  if phase!='normal':assert sha(p)==m['training_sha256'][phase]
  training.append({'path':str(p),'sha256':sha(p),'rows':288})
assert {p.name:sha(p) for p in (ar/'inputs').iterdir()}=={p.name:sha(p) for p in (cr/'inputs').iterdir()}
for name,digest in am['profiles_sha256'].items():assert sha(ar/name if name=='merged.profdata' else ar/'raw-profiles'/name)==digest
assert am['profiles_sha256']['merged.profdata']!=cm['profiles_sha256']['merged.profdata']
# Additional exact library/profile bindings, independent of producer summary.
for root,pair,m in ((B,c,cm),(O,a,am)):
 run=Path(m['run'])
 for phase in ('normal','generate','use'):
  path=root/'normal-training.json' if phase=='normal' else run/(phase+'-training.json')
  report=load(path)
  library=root/'normal/liboriole_expat.so' if phase=='normal' else run/phase/'liboriole_expat.so'
  expected=pair['normal_libraries']['liboriole_expat.so'] if phase=='normal' else m['libraries_sha256'][phase+'/liboriole_expat.so']
  assert report['xml_parse_origin']=={'path':str(library),'sha256':expected}
  assert report['library_sha256']==sha(library)==expected
  assert report['script_sha256']=='5948d1a482a0727a74612bab98df2411c08884dac45fd143debdae6b8e42e590'
  assert report['profile_file_environment']==(str(run/'raw-profiles/oriole-%m-%p.profraw') if phase=='generate' else None)
 for name,digest in m['profiles_sha256'].items():
  assert sha(run/name if name=='merged.profdata' else run/'raw-profiles'/name)==digest
 assert set(p.name for p in (run/'raw-profiles').iterdir())==set(m['profiles_sha256'])-{'merged.profdata'}

source_record=load(O/'source.json');source=source_record['source_sha256'];control_source=load(B/'source.json');baseline=control_source['source_sha256']
base='0f66d54ac8418f0a6e628ad18570677a19c9ed45';commit='e1228bbb9dbd174e2aceff5ecea24a04fecc8515'
prep=load(O/'preparation.json');changed=set(prep['expected_source_delta']);runtime={'crates/oriole/src/arena.rs','crates/oriole/src/dtd.rs','crates/oriole/src/encoding.rs','crates/oriole/src/lib.rs','crates/oriole/src/recycling.rs','crates/oriole_expat/src/lib.rs'}
added={'crates/oriole/src/compact_coordinate_tests.rs','crates/oriole_expat/src/coordinate_tests.rs'}
assert source_record['base_runtime']==control_source['candidate_base_commit']==base
assert source_record['candidate_base_commit']=='97117de5ea51b2bd3f5d348cade85c203c6a888e'
assert len(source)==74 and len(baseline)==72 and set(source)-set(baseline)==added and set(baseline)<=set(source)
assert len(changed)==14 and runtime<=changed
assert {p for p in source if p not in baseline or source[p]!=baseline[p]}==changed
assert all(sha(W/p)==h for p,h in source.items())
assert len(am['source_sha256'])==71 and len(cm['source_sha256'])==69
assert {p for p in am['source_sha256'] if p not in cm['source_sha256'] or am['source_sha256'][p]!=cm['source_sha256'][p]}==changed==set(prep['expected_pipeline_delta'])
assert all(source[p]==h for p,h in am['source_sha256'].items())
assert all(baseline[p]==h for p,h in cm['source_sha256'].items())
assert set(source)-set(am['source_sha256'])=={'tests/c/adversarial.c','tests/c/allocations.c','tests/c/integration.c'}
allocator='crates/oriole_storage/src/allocator.rs';assert source[allocator]==baseline[allocator]
# Verify the exact committed snapshot with one read-only Git archive operation.
import io
snapshot=subprocess.check_output(['git','archive',commit,'--',*sorted(source)],cwd=W)
with tarfile.open(fileobj=io.BytesIO(snapshot)) as archive:
 assert {m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive if m.isfile()}==source
with tarfile.open(O/'source.tar.gz') as archive:
 files=[m for m in archive if m.isfile()]
 assert len(files)==74 and len({m.name for m in files})==74
 assert {m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in files}==source
binding=Path('/tmp/oriole-compact-coordinate-ci-preparation/commit-binding.json');bind=load(binding)
assert bind['status']=='passed' and bind['commit']==commit and bind['source_manifest_sha256']==sha(O/'source.json') and bind['source_files']==74
pin(binding)
assert a['source_manifest_sha256']==sha(O/'source.json')
scripts=load(O/'tool-source.json')
assert len(scripts)==6 and scripts==load(B/'tool-source.json') and all(sha(P/p)==h for p,h in scripts.items())
assert am['script_sha256']==cm['script_sha256']=={Path(p).name:h for p,h in scripts.items()}
for path,h in scripts.items():
 assert hashlib.sha256(subprocess.check_output(['git','show','144e69e08c5462217d54791374e579e3ef390a87:'+path],cwd=W)).hexdigest()==h
 pin(P/path,h)
pipeline=next(x['argv'] for x in a['commands'] if x['label']=='pgo-pipeline')
assert pipeline[3]==str(P/'tools/pgo/build.py') and pipeline[pipeline.index('--source')+1]==str(W)
assert am['invocation'][1]==str(P/'tools/pgo/build.py') and am['source']==str(W)
for phase in ('generate','use'):assert next(x for x in am['commands'] if x['label']==phase)['argv'][3]==str(P/'tools/pgo/train.py')
assert next(x for x in a['commands'] if x['label']=='normal-generated-replay')['argv'][3]==str(P/'tools/pgo/train.py')
for root,pair,m in ((O,a,am),(B,c,cm)):
 for name,h in pair['normal_libraries'].items():pin(root/'normal'/name,h)
 for name,h in m['libraries_sha256'].items():pin(Path(m['run'])/name,h)
 for command in pair['commands']:
  pin(root/(command['label']+'.log'),command['log_sha256'])
  if root==O:assert command['reaped'] and command['start']<=command['end'] and command['cwd']==str(W) and command['cpu']==3
 for command in m['commands']:pin(Path(m['run'])/command['log'],command['log_sha256'])
 pin(pair['pgo_manifest']['path'],pair['pgo_manifest']['sha256'])
 for name,h in m['profiles_sha256'].items():pin(Path(m['run'])/name if name=='merged.profdata' else Path(m['run'])/'raw-profiles'/name,h)
for row in training:pin(row['path'],row['sha256'])
checks=load(O/'source-checks.json');raw=load(O/'local-checks/final-checks.json')
assert checks['status']==raw['status']=='passed'
assert checks['commands']==raw['commands']
assert checks['source_manifest_sha256']==sha(O/'source.json')
pin(O/'local-checks/final-checks.json',checks['check_report_sha256'])
assert [r['label'] for r in checks['commands']]==['fmt01','check01','tests01','clippy01']
for row in checks['commands']:
 assert row['exit']==0 and row['reaped'] and row['affinity']==[3] and row['cwd']==str(W)
 assert row['source_unchanged'] and row['source_before']==row['source_after']==row['source_sha256']==source
 assert row['command']==row['argv'] and row['command'][:3]==['cargo','+ohm','-Zohm-defaults=no']
 assert row['end']<=a['commands'][0]['start']
 p=O/'local-checks'/row['label'];pin(p/'output.log',row['log_sha256'])
 assert load(p/'report.json')=={k:v for k,v in row.items() if k not in {'argv','source_unchanged','source_sha256'}};pin(p/'report.json')
rows=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (O/'local-checks/tests01/output.log').read_text())]
assert len(rows)==34 and sum(row[0] for row in rows)==449 and all(row[1:]==(0,0) for row in rows)
assert checks['test_count']==449 and checks['test_groups']==34 and checks['failed']==checks['ignored']==0
for name in ['source-checks.json','source.tar.gz','source.patch','tool-source.json','build_pair.py','preparation.json']:pin(O/name)
assert sha(O/'build_pair.py')==prep['controller_sha256']
assert all(sha(W/p)==h for p,h in source.items())
for path,h in inputs.items():assert sha(path)==h,path
result={'status':'passed','role':'Saved-data readback independent of runtime author and root build execution. Reviewer authored inherited C-coordinate tests and the two focused C-test extensions, adapted benchmark controllers and this saved audit. No target execution; not an independent-author controller audit.',
 'inputs':inputs,'source':source_record,'pair':a,'control_source':control_source,'control_pair':c,
 'summary':{'full_source_files':74,'pipeline_source_files':71,'changed_vs_selected':sorted(changed),'runtime_files':sorted(runtime),'test_files':sorted(changed-runtime),'raw_compiler_vectors':9,'actual_workspace_compilations':counts,'candidate_generated_rows':864,'control_generated_rows':864,'candidate_library_artifacts':6,'tests':449,'test_groups':34,'failed':0,'ignored':0,'fmt_check_tests_strict_clippy':True,'targets_executed':False},
 'compiler_comparison':'Nine complete raw compiler argv vectors matched to selected reference 0f66d54. Normalize only private build/run paths and Cargo artifact suffixes; preserve metadata, opt-level, target, crate types, all other flags and order.',
 'training':training,'library_origins_and_profile_environments_exact':True,'git144_pipeline_scripts':scripts,'allocator_unchanged':source[allocator],
 'committed_source':commit,'dirty_manifest_identity_intentionally_preserved':True,
 'limitations':['Saved-data only: no target rerun, held-out correctness or elapsed claim. Initial CI dispatch 34656508229 on e122 had invalid YAML and ran no jobs; corrected CI is separate. This audit does not claim CI/Miri results.'],
 'blockers':[],'reader_sha256':sha(__file__)}
out=O/'build-readback.json'
with out.open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':sha(out),'status':'passed','summary':result['summary']}))
