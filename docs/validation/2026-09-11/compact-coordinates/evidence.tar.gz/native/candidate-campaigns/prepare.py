"""Copy the selected-reference native protocol; no compiler or parser execution."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import shutil

OUT = Path(__file__).parent
OLD = Path('/tmp/oriole-reference-frame-native-study')
BUILD = Path('/tmp/oriole-compact-coordinates-pgo-study')
CONTROL = Path('/tmp/oriole-reference-frame-pgo-study')
COMMIT = Path('/tmp/oriole-compact-coordinate-ci-preparation/commit-binding.json')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
load = lambda path: json.loads(Path(path).read_text())


def save(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def library(root, pair, mode):
    if mode == 'normal':
        path = root / 'normal/liboriole_expat.so'
        digest = pair['normal_libraries']['liboriole_expat.so']
    else:
        path = Path(pair['pgo_manifest']['path']).parent / 'use/liboriole_expat.so'
        digest = pair['pgo_libraries']['use/liboriole_expat.so']
    assert sha(path) == digest
    return {'path': str(path), 'sha256': digest}


candidate, control = load(BUILD / 'pair-report.json'), load(CONTROL / 'pair-report.json')
binding = load(COMMIT)
assert candidate['status'] == control['status'] == binding['status'] == 'passed'
assert binding['commit'] == 'e1228bbb9dbd174e2aceff5ecea24a04fecc8515'
assert binding['source_manifest_sha256'] == sha(BUILD / 'source.json') == '560ccfd88db962696486de09b24f0bfad250f3a4fabc97fd2acfadeeb57b1014'
assert binding['source_files'] == 74
modes = {}
for mode in ('normal', 'pgo'):
    old, target = OLD / mode, OUT / mode
    prior = load(old / 'adaptation.json')
    protocol = load(old / 'native-screen/protocol.json')
    assert sha(old / 'native_screen.py') == prior['controller_sha256']
    assert sha(old / 'run.py') == prior['wrapper_sha256'] == '5f41a419e800e95954424e2a85d2ee988609d830db18dc85c469af801cd8aef5'
    selected = library(CONTROL, control, mode)
    proposed = library(BUILD, candidate, mode)
    assert selected == prior['candidate_library'] == protocol['libraries']['candidate']
    expat = prior['expat_library']
    assert expat == protocol['libraries']['expat'] and sha(expat['path']) == expat['sha256']
    assert protocol['pairs'] == 7 and len(protocol['conditions']) == 28
    assert protocol['preflights'] == 84 and protocol['timed_workers'] == 588
    assert protocol['seed'] == 2026091003
    replacements = [
        (prior['candidate_library']['path'], proposed['path']),
        (prior['control_library']['path'], selected['path']),
        (str(old), str(target)),
        ('Direct character-reference frame', 'Compact deferred coordinates'),
        ('selected suffix-sharing element-name baseline', 'selected direct-reference frame baseline'),
    ]
    original = (old / 'native_screen.py').read_text()
    text = original
    for before, after in replacements:
        assert before in text
        text = text.replace(before, after)
    inverse = text
    for before, after in reversed(replacements):
        inverse = inverse.replace(after, before)
    assert inverse == original
    assert text[text.index('def run('):] == original[original.index('def run('):]
    ast.parse(text)
    target.mkdir(exist_ok=False)
    (target / 'native_screen.py').write_text(text)
    shutil.copyfile(old / 'run.py', target / 'run.py')
    (target / 'controller.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile=str(old / 'native_screen.py'), tofile=str(target / 'native_screen.py'))))
    fixed_inputs = {path: digest for path, digest in protocol['hashes'].items() if path not in {str(old / 'native_screen.py'), *[item['path'] for item in protocol['libraries'].values()]}}
    assert all(sha(path) == digest for path, digest in fixed_inputs.items())
    metadata = {
        'status': 'passed', 'prepared_not_executed': True, 'mode': mode,
        'origin': str(old), 'original_controller_sha256': prior['controller_sha256'],
        'controller_sha256': sha(target / 'native_screen.py'), 'wrapper_sha256': sha(target / 'run.py'),
        'candidate_library': proposed, 'control_library': selected, 'expat_library': expat,
        'source_manifest_sha256': sha(BUILD / 'source.json'), 'control_source_manifest_sha256': sha(CONTROL / 'source.json'),
        'build_pair_sha256': sha(BUILD / 'pair-report.json'), 'control_build_pair_sha256': sha(CONTROL / 'pair-report.json'),
        'commit_binding_sha256': sha(COMMIT), 'candidate_source_commit': binding['commit'],
        'replacement_pairs': replacements, 'inverse_text_equal': True, 'worker_and_statistics_body_byte_exact': True,
        'fixed_inputs_sha256': fixed_inputs, 'conditions': protocol['conditions'],
        'pairs': 7, 'seed': 2026091003, 'preflights': 84, 'timed_workers': 588,
        'scope': 'Existing selected-reference seven-pair protocol unchanged. Normal runs first; PGO requires a separate root decision. All 24 real and four generated conditions, callbacks, iterations, warmups, order, statistics and worker bounds retained. No preparation target ran; candidate remains unselected.',
    }
    save(target / 'adaptation.json', metadata)
    modes[mode] = {'adaptation_sha256': sha(target / 'adaptation.json'), 'controller_sha256': metadata['controller_sha256'], 'run_command': ['python3', str(target / 'run.py')]}
save(OUT / 'preparation.json', {'status': 'prepared_no_targets_executed', 'candidate_source_commit': binding['commit'], 'source_manifest_sha256': binding['source_manifest_sha256'], 'control': str(CONTROL), 'modes': modes, 'preparer_sha256': sha(__file__), 'execution_order': 'Normal native first. PGO has no automatic launch and requires a separate root decision after normal results.', 'limits': ['Matched-build saved readback is separate and pending.', 'No correctness or CI result transfers from earlier coordinate prototypes. The original invalid CI dispatch is separate from source/build identity.']})
print(json.dumps({'path': str(OUT / 'preparation.json'), 'sha256': sha(OUT / 'preparation.json'), 'modes': modes}))
