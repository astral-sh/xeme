# Compact-coordinate PGO correctness gates

Prepared only. Root releases these after the PGO benchmark decision. No compiler, parser, benchmark or package task was executed during preparation. Candidate source is the 74 frozen files committed as `e1228bbb9dbd174e2aceff5ecea24a04fecc8515`; later CI/docs commits do not change that measured source. Compare against selected reference source `0f66d54ac8418f0a6e628ad18570677a19c9ed45` and its saved PGO results.

Candidate PGO artifacts:

- Shared: `/tmp/oriole-compact-coordinates-pgo-study/pgo/runs/run-q94s3xog/use/liboriole_expat.so`, SHA-256 `6b6731745f10adca2e6399635baf41aa9f86306cec1c9280aae6ab692fc38fbb`.
- Static: same directory, `liboriole_expat.a`, SHA-256 `ccc595ffca2ea12c2da53efdd56700e765f898b6982a2ace15424df30e61014b`.

## Launch order

Run each command after the previous command and its children are reaped. Keep target work separate from elapsed benchmarks. Commands intentionally create new output directories or exclusive first-attempt logs; preserve a failed attempt for review.

1. Full API matrix and six C consumers, CPU3:

   ```sh
   taskset -c 3 python3 /tmp/oriole-compact-coordinate-correctness-prep/api_native.py
   ```

   Exact original 4,740 configurations: chunks 0–5 × deferral 0/1, same assertions and twelve private-test exclusions. Bounds: 3 seconds per case, 1 GiB address space, 768 MiB RSS, 240 seconds for the runner, 300 seconds outer API command. Then integration/adversarial/allocations × shared/static, each compile and execution bounded to 120 seconds. C harnesses receive ASan/UBSan; linked Rust release artifacts are uninstrumented and leak checking is disabled. All differences from selected reference are retained; baseline has 4,347 passes, 391 failures and two timeouts.

2. Strict CPython shared then static, CPU3:

   ```sh
   taskset -c 3 python3 /tmp/oriole-compact-coordinate-correctness-prep/strict_cpython.py
   ```

   Complete existing six-suite commands and assertions unchanged. 1,000-second outer limit per linkage; unchanged harness limits of 900 seconds for the suite runner and 120 seconds per suite, sequential `-j1`. Preserve the explicit `--consumer-fix` upstream pyexpat allocation-failure cleanup backport (patch SHA `10999b7171ce016e249c47c7f12d562f05a28aadf17791d61664090928f736a2`, compiled pyexpat SHA `1c3cf2ee6dfa568cf833742ad786880f4816042705689a116a4f308b7a9d95f2`). No text-fragmentation allowance or allocator substitution. Both reference linkages have 802 methods and two failing callback-grouping tests; suite exit 2 stays visible. These patched strict extensions are separate from unmodified elapsed consumers.

3. Allocator probe build, then twelve cases, CPU4:

   ```sh
   taskset -c 4 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-compact-coordinate-correctness-prep/allocation/run.py build
   python3 /tmp/oriole-compact-coordinate-correctness-prep/allocation_collect.py
   ```

   The exact selected C probe and runner are copied byte-for-byte. All twelve inputs, 4 KiB feeds, warmup boundaries and expectations match selected reference. Build limit 120 seconds (15-second readelf inspection); each child has a 3-second alarm, 4-second runner timeout, 20-second collector bound, 1 GiB address space and 8 MiB output cap. Callback/depth/allocation-slot bounds are unchanged in `allocation/plan.json`. The collector adds interruption kill/reap handling; probe behavior is unchanged.

4. After all targets are reaped, saved-only outcome readers, CPU6:

   ```sh
   taskset -c 6 python3 /tmp/oriole-compact-coordinate-correctness-prep/read_outcomes.py
   taskset -c 6 python3 /tmp/oriole-compact-coordinate-correctness-prep/allocation_compare.py --released --head e1228bbb9dbd174e2aceff5ecea24a04fecc8515
   ```

   The first reconstructs all 4,740 raw API rows and all 802 strict method identities/statuses per linkage, checks extension/library origins and backport bytes, and retains every difference. The second preserves the selected allocation reader's assertions, checking all ten API origins, callback hashes, allocation histograms, every intermediate feed's live bytes/blocks, and zero live allocations after free. Allocation metrics are not process RSS or elapsed performance.

## Review receipts

`preparation.json`, `pins.json`, and the controller `.patch` files bind the adaptations. The entire strict shared/static execution loop is byte-identical to the selected controller; its preamble binds the new source and selected reference. `outcome-reader-preparation.json` records the existing multiline-aware method extractor and its saved-only readback of both reference logs. No current-candidate correctness result is claimed here.
