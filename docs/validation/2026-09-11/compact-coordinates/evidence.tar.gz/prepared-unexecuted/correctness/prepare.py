"""Prepare existing PGO correctness controllers only; execute no targets."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,shutil
P=Path('/tmp/oriole-compact-coordinate-correctness-prep')
W=Path('/home/dev-user/code/oss/oriole-compact-coordinates');B=Path('/tmp/oriole-compact-coordinates-pgo-study')
C=Path('/tmp/oriole-reference-frame-pgo-study');CW=Path('/home/dev-user/code/oss/oriole-reference-frame')
L=B/'pgo/runs/run-q94s3xog/use';SOURCE='560ccfd88db962696486de09b24f0bfad250f3a4fabc97fd2acfadeeb57b1014';COMMIT='e1228bbb9dbd174e2aceff5ecea24a04fecc8515';BASE='0f66d54ac8418f0a6e628ad18570677a19c9ed45'
read=lambda p:json.loads(Path(p).read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,d):
 with p.open('x') as f:f.write(json.dumps(d,indent=2)+'\n')
assert sha(B/'source.json')==SOURCE
source=read(B/'source.json');control=read(C/'source.json');pair=read(B/'pair-report.json');cpair=read(C/'pair-report.json')
assert source['base_runtime']==control['candidate_base_commit']==BASE
assert source['source_count']==74 and pair['status']=='passed'
assert sha(L/'liboriole_expat.so')=='6b6731745f10adca2e6399635baf41aa9f86306cec1c9280aae6ab692fc38fbb'
assert sha(L/'liboriole_expat.a')=='ccc595ffca2ea12c2da53efdd56700e765f898b6982a2ace15424df30e61014b'
pins={str(W/n):h for n,h in source['source_sha256'].items()}
paths=[B/n for n in ['source.json','pair-report.json','build-readback.json','preparation.json']]+[C/n for n in ['source.json','pair-report.json']]+[L/'liboriole_expat.so',L/'liboriole_expat.a',Path(pair['pgo_manifest']['path']),W/'include/expat.h',Path('/usr/bin/cc').resolve(),Path('/usr/bin/readelf').resolve(),Path('/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12')]
paths+=list((W/'tools/cpython').glob('*.py'))
paths+=[W/'integration/python-build-standalone/consumer-fix'/n for n in ['provenance.json','cpython-3.12.13-external-parser.patch']]
paths+=[W/'tools/upstream-expat'/n for n in ['run.py','runner.c','bridge.c','bridge.h','memcheck.patch','README.md','allocator_repro.c']]
paths+=[Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13')/n for n in ['Modules/pyexpat.c','Modules/_elementtree.c','Lib/test/test_pyexpat.py','Lib/test/test_xml_etree.py','Lib/test/test_xml_etree_c.py','Lib/test/test_minidom.py','Lib/test/test_sax.py','Lib/test/test_pulldom.py']]
API=Path('/tmp/oriole-reference-frame-api-gates/api-native/upstream-api');STRICT=Path('/tmp/oriole-reference-frame-strict-cpython')
for n in ['results.json','manifest.json','tests.log','adapted/expat_config.h']:paths.append(API/n)
for linkage in ['shared','static']:
 for n in ['summary.json','tests.log','origin.log','pyexpat.c']:paths.append(STRICT/linkage/n)
paths.append(STRICT/'report.json')
for p in paths:pins[str(p)]=sha(p)
# Helper/probe bytes are unchanged between selected and candidate trees.
for rel in [p.relative_to(W) for p in paths if p.is_relative_to(W) and ('tools' in p.relative_to(W).parts or 'consumer-fix' in p.parts)]:assert sha(W/rel)==sha(CW/rel),str(rel)
provenance=read(W/'integration/python-build-standalone/consumer-fix/provenance.json')
assert provenance['patched_source_sha256']=='1c3cf2ee6dfa568cf833742ad786880f4816042705689a116a4f308b7a9d95f2'
assert sha(W/'integration/python-build-standalone/consumer-fix/cpython-3.12.13-external-parser.patch')=='10999b7171ce016e249c47c7f12d562f05a28aadf17791d61664090928f736a2'
# Every prepared target entry validates frozen preparation pins before work.
guard="""\nfrom pathlib import Path\nimport hashlib,json\n_PREP=Path(__file__).resolve().parent\n_prepared=json.loads((_PREP/'pins.json').read_text())\nassert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in _prepared.items()), 'Prepared inputs changed'\n"""
adaptations=[]
def adapt(name,origin,before,after,changes):
 ast.parse(after);(P/name).write_text(after)
 (P/(name+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(origin),tofile=str(P/name))))
 adaptations.append({'path':str(P/name),'sha256':sha(P/name),'origin':str(origin),'origin_sha256':sha(origin),'changes':changes})
 pins[str(origin)]=sha(origin)
# Existing full API matrix and six C ASan/UBSan consumers, only path retargeting + input pins.
origin=Path('/tmp/oriole-reference-frame-api-gates/api_native.py');before=origin.read_text();after=before
replacements=[('/tmp/oriole-reference-frame-api-gates',str(P)),('/home/dev-user/code/oss/oriole-reference-frame',str(W)),('/tmp/oriole-reference-frame-pgo-study/pgo/runs/run-i9x6lhki/use',str(L)),('/tmp/oriole-suffix-element-names-api-gates/api-native/upstream-api',str(API))]
for old,new in replacements:assert old in after;after=after.replace(old,new)
# Prepend after docstring; common static pins are independent of run-time source copies.
after=after.replace("if not __debug__: raise RuntimeError('Assertions required')", "if not __debug__: raise RuntimeError('Assertions required')"+guard)
after=after.replace("row['end']=time.time();", "row['reaped']=p is not None and p.poll() is not None;row['end']=time.time();")
adapt('api_native.py',origin,before,after,'Path/source bindings and prepared pins; add explicit reaped receipt field. Matrix assertions, limits, loops, C flags and comparison retained.')
# Strict controller: replace source binding preamble; the complete shared/static runner loop is untouched.
origin=Path('/tmp/oriole-reference-frame-strict-cpython.py');before=origin.read_text();after=before
for old,new in [('/tmp/oriole-reference-frame-strict-cpython',str(P/'strict-cpython')),('/home/dev-user/code/oss/oriole-reference-frame',str(W)),('/tmp/oriole-reference-frame-pgo-study',str(B)),('/tmp/oriole-suffix-element-names-strict-cpython',str(STRICT)),('/tmp/oriole-suffix-element-names-pgo-study',str(C))]:after=after.replace(old,new)
after=after.replace('from pathlib import Path',guard+'\nfrom pathlib import Path',1)
start=after.index("assert source['candidate_base_commit']")
end=after.index('pgo_manifest = Path',start)
binding="""assert source['candidate_base_commit'] == '97117de5ea51b2bd3f5d348cade85c203c6a888e'\nassert pair['source_manifest_sha256'] == sha(BUILD / 'source.json')\nbaseline_pair=json.loads((BASELINE_BUILD/'pair-report.json').read_text())\nbaseline_source=json.loads((BASELINE_BUILD/'source.json').read_text())\nassert baseline_pair['status']=='passed'\nassert baseline_pair['source_manifest_sha256']==sha(BASELINE_BUILD/'source.json')\nassert baseline_source['candidate_base_commit']=='0f66d54ac8418f0a6e628ad18570677a19c9ed45'\npreparation=json.loads((BUILD/'preparation.json').read_text())\nsource_delta=sorted(n for n,h in source['source_sha256'].items() if baseline_source['source_sha256'].get(n)!=h)\nassert source_delta==sorted(preparation['expected_source_delta']) and len(source_delta)==14\nbuild_readback=json.loads((BUILD/'build-readback.json').read_text())\nassert build_readback['source']==source and build_readback['pair']==pair\nassert build_readback['control_source']==baseline_source and build_readback['control_pair']==baseline_pair\nassert build_readback['summary']['changed_vs_selected']==source_delta\n"""
after=after[:start]+binding+after[end:]
after=after.replace('pgo_manifest, expected_delta_file,','pgo_manifest,')
after=after.replace("BASELINE / 'report.json', BASELINE / 'independent-review.json',", "BASELINE / 'report.json',")
after=after.replace("'source_commit': source['candidate_base_commit'],", "'source_commit': '"+COMMIT+"',")
after=after.replace('measured suffix-sharing strict controls','selected reference-frame strict controls')
assert after[after.index('try:\n    for linkage'):]==before[before.index('try:\n    for linkage'):]
adapt('strict_cpython.py',origin,before,after,'Path/source74 bindings, prepared pins and selected reference comparison metadata only; complete strict suite command/execution/assertion loop byte-exact.')
# Exact allocator C/runner, twelve fixtures and selected records.
A=P/'allocation';A.mkdir();(A/'inputs').mkdir();BASE_PROBE=Path('/tmp/oriole-reference-frame-allocation-probe');baseline=read(BASE_PROBE/'plan.json');plan=copy.deepcopy(baseline)
assert len(plan['cases'])==12 and baseline['source_commit']==BASE
assert baseline['library']['sha256']==cpair['pgo_libraries']['use/liboriole_expat.so']
for name in ['probe.c','run.py']:shutil.copyfile(BASE_PROBE/name,A/name)
compared={}
for name in ['build']+[c['name'] for c in baseline['cases']]:
 r=BASE_PROBE/'runs'/(name+'.json');log=BASE_PROBE/'runs'/(name+'.log');receipt=read(r)
 assert receipt['status']=='reaped' and receipt['exit']==0 and receipt['pins_unchanged'] and receipt['plan_sha256']==sha(BASE_PROBE/'plan.json') and receipt['log_sha256']==sha(log)
 if name!='build':assert receipt['origin_verified'] and receipt['complete_result'] and receipt['successful_result']
 compared[name]={str(p):sha(p) for p in [r,log]}
plan['scope']='Fresh compact-coordinate PGO allocation diagnostic against selected reference frame. Exact runner, C fixture, twelve input sequences, feed width, warmup boundaries and limits. All intermediate CALL live-byte/block observations retained; no elapsed/RSS claim.'
plan['source_commit']=COMMIT;plan['library']={'path':str(L/'liboriole_expat.so'),'sha256':sha(L/'liboriole_expat.so')};plan['header_directory']=str(W/'include')
for old,new in zip(baseline['cases'],plan['cases'],strict=True):
 dest=A/'inputs'/Path(old['input']).name;shutil.copyfile(old['input'],dest);assert sha(dest)==old['input_sha256'];new['input']=str(dest)
 assert {k:v for k,v in old.items() if k!='input'}=={k:v for k,v in new.items() if k!='input'}
plan['pins']=dict(pins)
for path in [BASE_PROBE/'plan.json',BASE_PROBE/'probe.c',BASE_PROBE/'run.py',A/'probe.c',A/'run.py',*list((A/'inputs').iterdir())]:plan['pins'][str(path)]=sha(path)
for records in compared.values():plan['pins'].update(records)
plan['compared_selected_baseline']={'source_commit':BASE,'library':baseline['library'],'plan':{'path':str(BASE_PROBE/'plan.json'),'sha256':sha(BASE_PROBE/'plan.json')},'raw_records':compared,'comparison_rule':'Compare all twelve identical fixtures and every intermediate CALL; do not compare capacity fixtures with different input bytes.'}
assert plan['bounds']==baseline['bounds']
save(A/'plan.json',plan)
origin=Path('/tmp/oriole-reference-frame-allocation-collect.py');before=origin.read_text();after=before.replace('/tmp/oriole-reference-frame-allocation-probe',str(A)).replace('/tmp/oriole-reference-frame-allocation-collection.json',str(P/'allocation-collection.json')).replace('/tmp/oriole-reference-frame-allocation-',str(P/'allocation-'))
# Retain inner worker limits and add interruption cleanup around collector's outer wait.
after=after.replace("  except subprocess.TimeoutExpired:\n   os.killpg(p.pid,signal.SIGKILL);row['exit']=p.wait();row['timeout']=True", "  except subprocess.TimeoutExpired:\n   os.killpg(p.pid,signal.SIGKILL);row['exit']=p.wait();row['timeout']=True\n  except BaseException as e:\n   row['exception']=repr(e)\n   if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)\n   row['exit']=p.wait();row.update(completed=time.time(),reaped=True,log_sha256=sha(log));report['status']='interrupted';save();raise")
adapt('allocation_collect.py',origin,before,after,'Path substitutions; outer collector interruption kill/reap retained in receipt. Twelve cases, timeout20, inner runner and all limits unchanged.')
origin=Path('/tmp/oriole-reference-frame-allocation-compare.py');before=origin.read_text();after=before.replace("BASE = Path('/tmp/oriole-suffix-element-names-allocation-probe')", "BASE = Path('/tmp/oriole-reference-frame-allocation-probe')").replace("CANDIDATE = Path('/tmp/oriole-reference-frame-allocation-probe')", "CANDIDATE = Path('"+str(A)+"')").replace("'a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9'", "'"+BASE+"'")
adapt('allocation_compare.py',origin,before,after,'Only selected/candidate directory constants and selected source commit; every raw allocation/comparison assertion unchanged.')
# Save the existing multiline-aware methods extractor for a later independent outcome audit.
reader=Path('/tmp/oriole-native-byte-count-thinlto-cpython-root-review/audit.py');tree=ast.parse(reader.read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='methods');(P/'methods.py').write_text('from pathlib import Path\nimport re\n\n'+ast.get_source_segment(reader.read_text(),node)+'\n');pins[str(reader)]=sha(reader)
for p in [P/x['path'].split('/')[-1] for x in adaptations]+[P/'methods.py',P/'prepare.py']:pins[str(p)]=sha(p)
assert all(sha(p)==h for p,h in pins.items())
save(P/'pins.json',pins)
save(P/'preparation.json',{'status':'prepared_not_executed','targets_executed':False,'candidate_source':COMMIT,'source_manifest_sha256':SOURCE,'selected_reference_source':BASE,'candidate_pgo_library':plan['library'],'candidate_pgo_archive':{'path':str(L/'liboriole_expat.a'),'sha256':sha(L/'liboriole_expat.a')},'adaptations':adaptations,'pins_sha256':sha(P/'pins.json'),'allocator_plan_sha256':sha(A/'plan.json'),'allocator_runner_and_c_exact':True,'upstream_api_configurations':4740,'strict_linkages':['shared','static'],'strict_methods_expected':802,'consumer_fix':provenance,'launch_order':['API4740 plus six current C consumers CPU3','strict CPython shared then static CPU3','allocator build then twelve probes CPU4','saved-only full method/origin and allocation readback CPU6'],'launch_approval':'Prepared only; root must release after PGO benchmark decision. No auto-launch.'})
print(json.dumps({'prepared':str(P),'sha256':sha(P/'preparation.json'),'targets_executed':False}))
