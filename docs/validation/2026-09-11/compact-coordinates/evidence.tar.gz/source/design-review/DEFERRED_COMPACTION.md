# Alternative: compact at the next delivery boundary

**This is a simpler candidate than passing both locations through compaction.** It appears feasible on the inspected selected source with the constraints below. It is still a design review, not an implemented or measured optimization. The original requirement to preserve A and B remains; retained source bytes preserve both until the publication decision makes one authoritative.

## Source and memory facts

Selected `Source::consume` advances original bytes/cursor and compacts when `cursor >= 64 KiB && cursor >= text.len()/2`. `Buffer::discard_prefix` drains the String, drains conversion metadata and rebases remaining conversion offsets. String drain delegates to a byte-vector drain. It moves/truncates contents **without shrinking the allocation**. The proposed eligible path is native UTF-8, unanchored and unconverted, so its conversion metadata is empty.

For an eligible completed native frame, keep its already-consumed prefix until the next delivery entry. Before parsing another event, resolve the current committed location, advance the coordinate checkpoint to the consumed cursor and perform the same pending discard. No prospective next event exists at this boundary.

The pending compaction predicate can be recomputed from the unchanged consumed cursor and text length; a second large publication slot is unnecessary. Source would still need the coordinate checkpoint offset. Exact representation/layout is unmeasured.

This delays a move inside an existing allocation, not allocation release. Thus there need be **no additional source backing allocation or larger backing capacity due solely to the delayed discard**, provided the barrier runs before every subsequent append/reserve/decoder mutation. Actual object-layout growth still changes tracked memory and must be measured separately.

The logical retained prefix is **not bounded by the current frame's size**: it can include a much larger earlier consumed prefix. Its bytes are bounded by the existing source buffer length/capacity and existing input limits. Its duration is one completed eligible delivery until the next source-mutating operation. Suspension may extend wall-clock duration indefinitely, but does not grow the retained allocation. Do not describe this as a fixed 4 KiB memory bound or delay compaction across additional input feeds.

## Publication authority

Let A be the previous committed event, and B the frame currently being built.

| Point | Authoritative core publication | Bytes required for deferred resolution |
| --- | --- | --- |
| Before B starts | A | A start through current cursor retained if A is unresolved |
| B built/consumed, before delivery decision | A; B is still prospective | A and B remain in the undiscarded buffer |
| B successfully delivered | B | B start remains retained until next barrier/getter |
| B fails without delivery | A | A stays retained; error owns an explicit resolved Position |
| Next entry with pending compaction | Resolve current A or B, then discard | No prospective next event exists |

For selected matched End, raw publication and consumption occur before frame publication; the retained bytes permit its prospective location to stay local until then. Native Start and ordinary Text retain their original activation and error order. Ordinary Text may be delivered on a late non-OOM accounting failure; in that case its location becomes committed through the existing decision. NoMemory continues to discard the frame and preserve the prior core publication. A caught unwind before commit also leaves old A resolvable because no discard has occurred; entry recovery must not treat a leftover frame marker as committed.

Current eligible successful native consume normally leads directly to its frame delivery. That observation is not permission to bypass the wrapper's actual publication decision. Restrict deferral to reviewed single-frame paths, excluding implicit End/namespace queues, DTD/entities, CDATA, reference frames and other owned/fallback paths initially. Do not allow a second eligible consume after a pending discard without first taking the boundary barrier.

## C getter synchronization

The C parser retains its own publication, independent of core's prospective work. Preserve that ownership:

1. Core stores a private explicit native/resolved representation in `last_position`; the frame/local location stores B until delivery. Neither uses fabricated public Position fields.
2. A C native descriptor contains the already-required byte start/count plus checked parser generation/current-publication identity. It resolves only that exact committed core event. An owned/resolved C Position, including an error Position, is authoritative directly and never replaced from an unrelated core event.
3. `run_events` installs B into C publication before invoking any XML callback, as it currently installs `frame.position()`. Between core commit and this assignment there must be no eligible observing user callback. Existing allocator reentry guards remain active; no Source/core reference crosses dispatch.
4. Line/column getters project the exact committed start and may cache it in core/C. Byte/count/input-context getters retain their scalar behavior. Repeated getters, Stop/Resume and late DefaultCurrent preserve the same event identity. Resolving a point cannot advance the checkpoint past another unresolved authoritative point.
5. If core returns an error, its existing explicit Error Position controls the C error publication. The old core A may remain internally, but C must not resolve its error location from A. Likewise, reset's release callback observes the old C/core pair until the original replacement point; a failed reset keeps that pair intact.

The serialized-handle contract disallows a second thread observing the core-commit/C-install interval. Generation alone is insufficient: stale same-parser descriptors require exact event identity checks. Stale retained frame resolution must fail closed as in the prior explicit C seam. Ordinary Rust event/adapter APIs must materialize positions; no deferred Position leaks through their existing accessors.

## Barriers beyond next delivery

- **Feed:** after the existing rejecting guards and before any source append/reserve/decoder mutation, resolve the committed point and perform a pending discard. `feed_start_byte` needs the eager raw index, not a gratuitous line/column scan. A rejected feed may leave the old bytes retained; it cannot trigger a larger allocation.
- **Eager fallback / ordinary Rust API:** materialize the old publication and current cursor before any eager consume or source representation change. The ordinary Source consume path must not independently move its checkpoint past an unresolved core publication.
- **Encoding changes, source push/pop, entity anchors, reset/release:** preserve the prior reviewed barriers and exact observing callback order. New reference frames remain eager initially, with their raw-reference byte counts and accounting/publication behavior unchanged.
- **Error / EOF / early return:** construct exact explicit positions. Pending discard need not run merely to report an error if retained bytes remain valid; it must run before any later mutation that could grow or invalidate storage. Sticky terminal states may retain the original capacity until drop, as the eager implementation already does.
- **Free:** no final coordinate scan is required absent an observing release callback; drop releases the same backing allocation. Release-callback getters must still have access to the old valid location.

## Remaining proof and performance limits

This changes the timing of compaction relative to a callback. The earlier review prohibited *unreviewed* delayed compaction or hidden retention; it did not prove any delay impossible. Here the proposed bound is explicit and native discard is allocation-free. Implementation review must confirm every source mutation barrier, current C callback authority, panic/failed-publication recovery, UTF-8/CRLF boundaries and tracked-memory effects. Reuse the prior committed/prospective compaction tests, but adapt them to observe the new boundary; do not simply remove their old assertions.

No saved result establishes that this representation or timing is faster. V1/V2 remain rejected, and their layout/copy/branch costs were not isolated. A compact prototype, if later authorized, should preserve current runtime selection until its own semantic/allocation checks and matched normal/PGO real-project screen justify selection.
