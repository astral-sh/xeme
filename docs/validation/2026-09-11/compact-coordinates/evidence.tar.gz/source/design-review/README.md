# Compact lazy coordinates: feasibility, not an implementation approval

**An 8–24-byte Source field budget is plausible; the prior correctness proof does not require V1's 136-byte Source growth.** This would change ownership and the compaction interface, not merely shrink V1's fields. No evidence shows that the extra 136 bytes caused V1's regressions, and no speedup is established for a compact design.

This review reads selected reference-frame source and saved prior designs/results only. No source edit, compiler, parser, sanitizer, profiler or timing target was run.

## Why V1 grew

V1 added a coordinate cursor plus two `Option<NativePoint>` values to every Source. Each point carried a full native identity and either a retained offset or a resolved Position. Saved layout evidence reports Source **384 → 520 bytes**, Parser +8, AdapterFrame +8 and C parser +16. Both Source points were a deliberate simplification: `Source::consume` could resolve old committed A, prospective B and the consumed end before discarding bytes without accessing the frame or core publication.

The earlier independent ownership review explicitly permits B in the detached frame, or a local value for matched End. Its “Source owns both publication slots” section calls the two-slot representation an ownership alternative, not a correctness requirement. The proof requires **two distinct logical starts through compaction and late errors**, not two persistent Source records.

## A smaller ownership arrangement

| State | Candidate owner |
| --- | --- |
| Checkpoint offset `q` | One new Source `usize`; existing line/column/previous-CR describe that checkpoint |
| Committed A | Existing core `last_position`, changed to an explicit resolved/native location representation |
| Prospective B | Existing detached frame location, or local matched-End location until its original publication point |
| C-visible identity | Existing C publication byte start/count, with an explicit unresolved/resolved distinction |

Keep `raw_index`, consumed cursor, accounting and compaction eager. For a retained native UTF-8 root start, its buffer offset can be derived as `cursor - (raw_index - byte_index)` rather than duplicated in Source. This requires checked native/root/retention bounds; it is invalid after discarding the start. Before then, materialize its line/column into its actual owner.

The C byte index alone is **insufficient** to preserve an old location after compaction. A resolved A must survive in core publication storage so a later C getter can resolve its exact current identity. The Source checkpoint cannot be advanced past A and expected to reconstruct A later. A fully resolved C copy may remain independent; a deferred C descriptor must match the core's current generation and exact event start/count.

This leaves Source with a one-word checkpoint field in the conceptual layout. Extra state/discriminants could put it within the proposed 8–24-byte budget. **Exact Rust layouts are unmeasured.** Core/frame/C location enums may still grow, and stack argument moves may increase. Do not conceal that cost by reporting Source alone. Retained-memory and allocation-limit behavior must include actual final layouts.

Use explicit private location types. Encoding “unresolved” as bogus Position line/column values would weaken the public API contract and is not part of this proposal. No `Cell`, shared mutable references, borrowed source pointers across callbacks, or unsafe core implementation is required by the design.

## Necessary compaction seam

Selected `Parser::consume` currently charges bytes and calls `Source::consume`; the latter performs the discard internally. Eligible native consumption would need a dedicated seam with disjoint access to Source, committed A and prospective B. Merely deleting the Source slots leaves this transition unsound.

1. Preserve the existing charge, raw publication, allocation and frame-activation order. A charge failure leaves A unchanged; ordinary Text may already be deliberately deliverable on a later non-OOM error.
2. Test the original compaction predicate against the same would-be consumed cursor. On a noncompacting native step, advance byte/cursor/scanner state and leave checkpoint coordinates deferred.
3. Before any checkpoint advance or discard that would lose a point, resolve unresolved A, then B, then the consumed end, carrying CR state in order. Write A back to core and B back to its frame/local owner **without committing B**. Only then discard the same prefix and rebase `q`.
4. The existing successful `next_event_scoped` decision commits B. NoMemory and other failed publication paths preserve A; deliberate ordinary Text-prefix delivery retains its existing exception. Matched End must keep its location local until its current post-consume publication.
5. A caught unwind cannot leave the checkpoint ahead of an unresolved committed A. Complete location materialization before mutation/discard and preserve valid core state across all early exits. Keeping B local avoids a persistent prospective transaction slot, but does not prove panic recovery automatically; the actual mutation ordering needs review.

The ordinary consume path must materialize any prior lazy publication before it advances/discards source bytes. Pure `Source::position`, `position_at`, `position_cursor` and public `Parser::position` still compute correct coordinates; a mutable resolver may cache them only after preserving any older outstanding point. All coordinate-cursor movement must go through this ordering. Feed, decoding/BOM, encoding callbacks, source push/pop, owned/queued events, reset and errors remain barriers as in the prior reviewed protocol.

Start narrowly with the prior eligible positive-byte native root Start/matched End/ordinary Text paths. Keep empty-element paired events, namespaces that require expansion, DTD/entities/children, conversions and CDATA eager. **The newly selected decoded reference frames should also remain eager initially**: their payload byte count differs from the raw reference spelling, and their accounting/publication tests must stay authoritative. The current reference-frame optimization is not evidence that references fit the old lazy native-Text predicate.

## Evidence and decision

V1 regressed normal real projects **9.17%** and PGO **8.45%**, with all 56 conditions adverse. V2 checkpoint guards regressed PGO real projects **10.97%**, all 28 conditions adverse. Neither experiment isolates Source layout from extra point copies, projections, branches, or generated code. Compact ownership is distinct from V2's extra guards, but these failures remain relevant negative evidence.

The earlier observer census found substantial multi-event native runs in Vulkan, Wayland, Maven and GTK; Batik was excluded by DTD state and DocBook eligibility was lower. That establishes batching opportunities under the old eligibility restrictions, not current-reference-frame speed or savings. The historical short-coordinate instruction envelope is roughly 5.6–11.2% in six inspected cases and includes work that must still occur at barriers. It cannot by itself support closing the full remaining gap.

**Conclusion:** the prior proof does not preclude a compact representation. The credible design direction is to remove duplicated publication ownership and thread the existing frame/local location through the compaction boundary. It remains a cross-owner refactor requiring independent source review, exact layout/accounting checks, the prior committed/prospective/compaction/error tests plus current reference-frame controls, and a fresh matched performance screen. Source size alone is not a selection criterion or an established cause of the old failures.

## Evidence paths

- `/tmp/oriole-c-lazy-coordinate-independent-review.md`: the original frame-local and two-Source-slot alternatives.
- `/tmp/oriole-lazy-coordinates-pgo-study/source.patch`: V1 ownership implementation.
- `/tmp/oriole-lazy-coordinate-layout-readback.json`: exact historical layout readback.
- `/tmp/oriole-lazy-coordinates-source-review.json`: publication, compaction and API invariants.
- `/tmp/oriole-lazy-coordinates-rejected-evidence/README.md` and `/tmp/oriole-coordinate-checkpoint-guards-rejected-evidence/README.md`: negative native results.
- `/tmp/oriole-c-lazy-coordinate-diagnostic/README.md`: historical eager observer census, separate from a lazy implementation.
- `/home/dev-user/code/oss/oriole-reference-frame/crates/oriole/src/encoding.rs`, `lib.rs` and `crates/oriole_expat/src/lib.rs`: current checkpoint, publication and C getter owners.
