# Root source review: compact coordinates

Reviewed unformatted prototype patch `091c5211045f89b7eae174f8c5b9195911f9d4503910af15e16d13a7c0872866` on selected-runtime-equivalent base `97117de5ea51b2bd3f5d348cade85c203c6a888e`. This is source review only: no compilation, parser, test, Miri or benchmark execution has occurred for this candidate.

No actionable correctness defect found in the reviewed diff and surrounding publication/decoder/source paths. Independent review remains pending. In particular:

- `last_position` changes only at the existing successful publication decision. Prospective Start/End location stays in the frame/local until that decision; failed NoMemory clears the frame and preserves the old publication. Ordinary Text retains its existing late accounting-failure prefix behavior.
- Deferred consume preserves both old and prospective source bytes. The next delivery boundary can cache the committed event before compaction because no new candidate exists then. `ResolvedNative` retains the descriptor identity after the original bytes are discarded.
- Successful feed and encoding mutation materialize before source mutation; rejected feed preserves retained coordinates. The eager consume wrapper materializes before calling Source.consume. Reference/CDATA/DTD/converted/anchored and owned fallbacks remain eager.
- Generation plus exact byte start/count rejects old or foreign descriptors; native events have nonzero count. Ordinary Rust APIs continue to return real positions, while the explicit hidden C protocol requires its resolver.
- C line/column getters preserve the allocator callback guard and borrow only core during resolution. The input-context field supplying C Text pointers is separate and no core reference crosses dispatch. Byte/count/context getters remain scalar projections. Explicit error positions remain authoritative in C.
- The source checkpoint handles UTF-8 and CR/LF using the existing coordinate advancement. Only one usize is added to Source. Actual layouts and allocation effects have not been measured.

Review feedback already applied by author: direct PositionCursor construction avoids a second projection, and coordinates_at returns directly when offset equals the checkpoint. Conservative eligibility checks remain unchanged pending measurement.

Required executable gates include the reused fallback/chunk/allocator/C getter tests, new A/B and next-delivery/feed discard boundary tests, meaningful Miri C getter/payload checks, and matched normal/PGO measurements before selection. The public frame position panic is restricted to callers explicitly selecting the new hidden C protocol. The logical retained prefix is not bounded to the event size; it occupies existing source capacity until the next boundary and must be documented accurately.

## Review of subsequent test additions

Reviewed `added-tests.patch` SHA `ea89b436d03610e87ba07df4a99e2cea1ea6d5c6b416a7b34d1cd4a0f69efe9e` after the independent source seal. The MM parity checks now exercise all three delivery modes, retain original successful allocation-count expectations, and compare old native publication after failure. The C boundary fixture places native Text at bytes 65533..65537, checks exact line/column plus C context pointer identity, suspends and rereads the callback payload, then resumes through compaction and checks the detached End name and coordinates. The allocator-reentry probe also calls both new mutating coordinate getters. No actionable source-level problem found. These added tests remain unformatted and unexecuted; their authorship followed the independent runtime review.
