from pathlib import Path
import hashlib,json,re
O=Path(__file__).parent
W=Path('/home/dev-user/code/oss/oriole-current-asan');D=W/'docs/validation/2026-09-11/current-asan';H=Path('/tmp/oriole-be22-asan-handoff')
inputs={}
def read(p):
 p=Path(p);b=p.read_bytes();inputs[str(p)]=hashlib.sha256(b).hexdigest();return b
def load(p):return json.loads(read(p))
report=load(H/'report.json');ready=load(H/'readiness-review.json')
assert report['status']==ready['status']=='passed'
assert read(D/'data/report.json')==read(H/'report.json')
assert read(D/'data/readiness-review.json')==read(H/'readiness-review.json')
text=read(D/'README.md').decode();top=read(W/'README.md').decode();reviewdoc=read(W/'docs/review.md').decode();read('/tmp/oriole-publish-current-asan-docs.py')
rows=[]
for line in text.splitlines():
 if line.startswith('| ') and not line.startswith('| Target') and not line.startswith('| ---'):
  cells=[x.strip() for x in line.strip('|').split('|')];rows.append([cells[0],*[int(x.replace(',','')) for x in cells[1:]]])
keys=('initial_files','replay_exec','campaign_exec','final_disk_files')
assert len(rows)==7
assert rows[:-1]==[[r['target'],*[r[k] for k in keys]] for r in report['targets']]
assert rows[-1]==['Total',*[report['total'][k] for k in keys]]
for k in keys:assert sum(r[k] for r in report['targets'])==report['total'][k]
assert report['total']['initial_files']==26689+16272==42961
assert report['total']['replay_exec']==42961-3+6==42964
assert sum(r['initial'] for r in ready['corpus_counts'].values())==26689
assert sum(r['final'] for r in ready['corpus_counts'].values())==16272
assert sum(r['empty_files'] for r in ready['corpus_counts'].values())==3
for r in report['targets']:
 x=ready['corpus_counts'][r['target']]
 assert r['initial_files']==x['union_files'] and r['replay_exec']==x['expected_replay_executions']
assert report['total']['all_processes_exit_zero'] and report['total']['artifacts']==report['total']['harness_timeouts']==report['total']['reruns']==0
assert report['total']['replay_processes']==report['total']['campaign_processes']==6
for r in report['targets']:assert r['status']=='passed'
assert f"{min(r['duration_seconds'] for r in report['targets']):.3f}–{max(r['duration_seconds'] for r in report['targets']):.3f} seconds" in text
assert report['source']['commit']=='c1776c922b023a3558badfefa697cd11b0d37d8e' and report['source']['source_unchanged'] and not report['source']['literal_attribute_candidate_included']
assert report['source']['source_files']==ready['source_files']==357 and report['source']['runtime_files_matching_selected_pgo_source']==ready['runtime_files']==70
assert report['build']['actual_workspace_library_compilations']==3 and report['build']['actual_fuzz_target_compilations']==6 and report['build']['all_nine_have_address_sanitizer'] and ready['workspace_and_fuzz_compiler_invocations']==9
assert report['build']['ohm_defaults_disabled_for_build'] and report['build']['ohm_trust_opt_ins_absent']
assert report['build']['binaries']==ready['binary_hashes']
assert ready['ASan_report_sites']=={'XML_Parse':8,'parse_text':156,'text_bytes':3}
assert report['protocol']=={'seed':20260911,'max_len':65536,'per_input_timeout_seconds':10,'rss_limit_mb':1536,'campaign_budget_seconds':600,'replay_outer_timeout_seconds':180,'campaign_outer_timeout_seconds':690,'aggregate_outer_timeout_seconds':1920,'asan_options':'detect_leaks=0:abort_on_error=1','lanes':[[1,['parse','multibyte']],[2,['streaming','value_family']],[4,['ffi','ffi_family']]],'controller_owns_all_target_process_groups':True}
assert len(report['retained_failures'])==len(ready['failures_preserved'])==3
assert report['review']['readiness_review_sha256']==inputs[str(H/'readiness-review.json')]
assert report['review']['campaign_independent_review'].startswith('pending')
assert 'Final campaign and package review is recorded separately before publication.' in text
assert 'Leak detection remains disabled' in text and 'no new LeakSanitizer, UndefinedBehaviorSanitizer, whole-standard-library instrumentation or exhaustive safety claim' in text
assert 'these are not global unique-input counts' in text
assert 'the separate attribute and text-error experiments are excluded' in text
assert 'These sanitizer runs establish neither new compatibility nor speed.' in text
assert '393 upstream API failures and two strict CPython callback-grouping failures' in text
assert '10,496,706 executions' in top and '42,964 retained-corpus replays' in reviewdoc
pbs=load('/tmp/oriole-be22-pbs-workflow/launch.json');pbs_source=load('/tmp/oriole-be22-pbs-workflow/source.json')
assert pbs['headSha']==pbs_source['commit']==report['source']['commit'] and pbs['databaseId']==34563056904
workflow=read(W/'.github/workflows/pbs.yml');assert hashlib.sha256(workflow).hexdigest()==pbs_source['files']['.github/workflows/pbs.yml'] and b'toolchain: stable' in workflow
assert report['pbs']['url']==pbs['url'] and pbs['url'] in text and 'this report makes no PBS outcome claim.' in text
# This is prose/summary reconciliation; full archive and final raw campaign audit is separately assigned.
read(H/'README.md');read(H/'preparation-mapping.json');read(H/'files.json')
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in inputs.items())
(O/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
result={'status':'passed_for_reviewed_draft','role':'Independent publication-text review; no repo edits or target execution.','reviewed_markdown_sha256':{str(p):inputs[str(p)] for p in (W/'README.md',W/'docs/review.md',D/'README.md')},'report_sha256':inputs[str(H/'report.json')],'readiness_review_sha256':inputs[str(H/'readiness-review.json')],'counts':{'table_rows_including_total':7,'numeric_table_cells':28,'campaign_executions':10496706,'retained_replay_executions':42964,'initial_files':42961,'final_disk_files':14157},'conclusions':['All six target table rows and totals reconstruct from the frozen report; initial corpus arithmetic and empty-input replay adjustment agree with prior independent readiness metadata.','Prose preserves exact accepted be22/c177 source scope, representative ASan instrumentation and compiler/tool versions, original bounds, three preparation failures, leak-detection exclusion and distinct original/live/final corpus counts.','Candidate optimizations, performance, fresh compatibility and PBS outcomes are not inferred. Saved PBS launch/source/workflow metadata supports the separate same-commit stable-Rust workflow link.','No numerical or scope blocker found.'], 'pending_finalization':'Replace the explicitly provisional final-campaign/package-review sentence with the actual independent review link once the separately assigned audit lands. This receipt does not certify that pending raw/package audit or a later unreviewed Markdown revision.','limits':['Full campaign raw-data and archive/member-origin audit is separately owned by multibyte_fuzz; this review reconciles publication claims to frozen report/readiness evidence.','The no-overlapping-performance-timing sentence reflects the recorded root scheduling; this is not a global host process monitor.','README heading/warning/license, local links and docs-only Git scope are covered by the separately requested compact structure review.','No external workflow was queried and no PBS success result is claimed.'],'unchanged_inputs':len(inputs)}
(O/'review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest(),'inputs':len(inputs)}))
