from pathlib import Path
import hashlib,json
O=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
structure=Path('/tmp/oriole-current-asan-doc-structure-independent-review/review.json')
assert sha(structure)=='3e7f96d572afda9325c2003811495fd9a64f9c09ea9f6d03dc94f61ff3164e5c'
r={'status':'sealed_reviewed_draft','review_sha256':sha(O/'review.json'),'structure_review':{'path':str(structure),'sha256':sha(structure)},'files_before_receipt':{str(p.relative_to(O)):sha(p) for p in sorted(O.rglob('*')) if p.is_file() and p.name not in ('receipt.json','files.json')}}
(O/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
files={str(p.relative_to(O)):sha(p) for p in sorted(O.rglob('*')) if p.is_file() and p.name!='files.json'}
(O/'files.json').write_text(json.dumps(files,indent=2)+'\n');assert all(sha(O/n)==h for n,h in files.items())
print(json.dumps({'review':sha(O/'review.json'),'receipt':sha(O/'receipt.json'),'index':sha(O/'files.json'),'files':len(files)}))
