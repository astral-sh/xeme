#!/usr/bin/env python3
"""Saved-only documentation structure review; no archive or target execution."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote, urlsplit

ROOT = Path('/home/dev-user/code/oss/oriole-current-asan')
OUT = Path('/tmp/oriole-current-asan-doc-structure-independent-review')
BASE = 'c1776c922b023a3558badfefa697cd11b0d37d8e'
PREFIX = 'docs/validation/2026-09-11/current-asan/'
DOCS = ['README.md', 'docs/review.md', PREFIX+'README.md', PREFIX+'data/README.md']
inputs = {}
checks = 0

def sha(b):
    return hashlib.sha256(b).hexdigest()

def ck(value, label):
    global checks
    checks += 1
    assert value, label

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def read(p):
    p = Path(p)
    b = p.read_bytes()
    inputs[str(p)] = {'sha256': sha(b), 'bytes': len(b)}
    return b

def write(name, obj):
    (OUT/name).write_text(json.dumps(obj, indent=2, sort_keys=True)+'\n')

ck(os.sched_getaffinity(0) == {6}, 'CPU 6 only')
ck(git('rev-parse', 'HEAD').decode().strip() == BASE, 'base HEAD')
tracked = git('diff', '--name-only', BASE, '-z').decode().split('\0')[:-1]
untracked = git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')[:-1]
ck(set(tracked) == {'README.md', 'docs/review.md'}, 'tracked documentation scope')
ck(bool(untracked) and all(p.startswith(PREFIX) for p in untracked), 'untracked publication scope')
diff = git('diff', '--binary', BASE)
(OUT/'repository.patch').write_bytes(diff)
status = git('status', '--porcelain=v1', '--untracked-files=all')
(OUT/'repository-status.txt').write_bytes(status)
documents = {name: read(ROOT/name).decode() for name in DOCS}
base_docs = {name: git('show', BASE+':'+name).decode() for name in DOCS[:2]}

def headings(s):
    return re.findall(r'^#{1,6} .+$', s, re.M)

def warning(s):
    return re.search(r'^> \[!WARNING\]\n(?:>[^\n]*\n)+', s, re.M).group()

ck(headings(documents['README.md']) == headings(base_docs['README.md']), 'all README headings unchanged')
ck(warning(documents['README.md']) == warning(base_docs['README.md']), 'README warning exact')
ck(documents['README.md'].split('## License\n', 1)[1] == base_docs['README.md'].split('## License\n', 1)[1], 'README license section exact')
ck(headings(documents['docs/review.md']) == headings(base_docs['docs/review.md']), 'review headings unchanged')
for name in ['LICENSE-APACHE', 'LICENSE-MIT']:
    ck(read(ROOT/name) == git('show', BASE+':'+name), name+' exact')

links = []
for name, body in documents.items():
    # All four source documents use ordinary inline links, without definitions.
    ck(not re.search(r'^\s*\[[^\]]+\]:', body, re.M), name+' has no reference definitions')
    parsed = list(re.finditer(r'!?\[([^\]\n]+)\]\(([^\n]+?)\)', body))
    ck(len(parsed) == body.count(']('), name+' complete inline-link enumeration')
    for match in parsed:
        label, href = match.groups()
        ck(not re.search(r'\s', href), name+' simple destination syntax')
        url = urlsplit(href)
        if url.scheme or url.netloc:
            links.append({'document': name, 'label': label, 'href': href, 'scope': 'external_not_checked'})
            continue
        target = ((ROOT/name).parent / unquote(url.path)).resolve() if url.path else ROOT/name
        ck(target.is_relative_to(ROOT), name+' local link within checkout')
        ck(target.exists(), name+' target exists: '+href)
        if target.is_dir():
            ck((target/'README.md').is_file(), name+' directory has README: '+href)
        if url.fragment:
            anchor_target = target/'README.md' if target.is_dir() else target
            target_text = read(anchor_target).decode()
            counts = {}
            ids = set()
            for h in headings(target_text):
                slug = re.sub(r'[^\w\- ]', '', re.sub(r'^#+\s+', '', h).lower()).replace(' ', '-')
                n = counts.get(slug, 0)
                counts[slug] = n+1
                ids.add(slug if n == 0 else slug+'-'+str(n))
            ck(unquote(url.fragment) in ids, name+' fragment resolves: '+href)
        links.append({'document': name, 'label': label, 'href': href, 'scope': 'local', 'target': str(target), 'kind': 'directory' if target.is_dir() else 'file'})

ck('Its scope precedes campaign outcomes.' in documents[PREFIX+'README.md'], 'readiness review not presented as outcomes audit')
ck('Final campaign and package review is recorded separately before publication.' in documents[PREFIX+'README.md'], 'final attachment pending snapshot')
ck('Independent review of final campaign results is pending.' in documents[PREFIX+'data/README.md'], 'nested guide pending final review explicit')
ck(git('diff', '--name-only', BASE, '-z').decode().split('\0')[:-1] == tracked, 'tracked scope unchanged at end')
ck(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')[:-1] == untracked, 'untracked scope unchanged at end')
ck(git('diff', '--binary', BASE) == diff, 'tracked diff unchanged at end')
for name, record in inputs.items():
    b = Path(name).read_bytes()
    ck(sha(b) == record['sha256'] and len(b) == record['bytes'], name+' unchanged')

write('links.json', links)
write('inputs.json', inputs)
write('review.json', {
    'status': 'passed_current_documentation_snapshot',
    'scope': 'Read-only Git/source text and local Markdown link checks on CPU 6; no archive readback, numerical audit, external URL requests, target commands, or repository edits.',
    'repository': str(ROOT), 'base': BASE,
    'common_git_directory': git('rev-parse', '--git-common-dir').decode().strip(),
    'tracked_changes': tracked, 'untracked_files': untracked,
    'unchanged': ['README title and all section headings', 'README complete AI/experimental warning block', 'README complete license section', 'LICENSE-APACHE', 'LICENSE-MIT', 'docs/review.md headings', 'all tracked files outside README.md and docs/review.md, including runtime and CI'],
    'readme_headings': headings(documents['README.md']),
    'base_text_hashes': {k: sha(v.encode()) for k, v in base_docs.items()},
    'documents': DOCS,
    'link_counts': {'all_inline': len(links), 'local': sum(x['scope']=='local' for x in links), 'external_unchecked': sum(x['scope']!='local' for x in links), 'anchored_local': sum(x['scope']=='local' and '#' in x['href'] for x in links)},
    'inputs': len(inputs), 'assertions': checks,
    'pending': 'Final campaign/package review attachment and final publication index are not yet part of this snapshot; no finalized-publication claim.',
    'limitations': ['Archive targets were checked for existence only, not opened or hashed.', 'No sanitizer result arithmetic or factual outcome audit.', 'Only local Markdown destinations were validated; external URLs were not requested.', 'Ignored build artifacts are outside the version-controlled diff scope.'],
    'generator_sha256': sha(Path(__file__).read_bytes())
})
print(json.dumps({'status': 'passed', 'checks': checks, 'inputs': len(inputs), 'local_links': sum(x['scope']=='local' for x in links), 'review_sha256': sha((OUT/'review.json').read_bytes())}))
