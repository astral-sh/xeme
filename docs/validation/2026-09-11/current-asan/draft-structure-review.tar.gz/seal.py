import hashlib
import json
import os
from pathlib import Path

P = Path('/tmp/oriole-current-asan-doc-structure-independent-review')
assert os.sched_getaffinity(0) == {6}

def record(p):
    b = p.read_bytes()
    return {'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

review = json.loads((P/'review.json').read_text())
assert review['generator_sha256'] == record(P/'generator.py')['sha256']
assert (P/'attempt01.stderr').read_bytes() == b''
attempt = json.loads((P/'attempt01.stdout').read_text())
assert attempt['status'] == 'passed'
assert attempt['review_sha256'] == record(P/'review.json')['sha256']
inputs = json.loads((P/'inputs.json').read_text())
for name, expected in inputs.items():
    assert record(Path(name)) == expected, name
receipt = {'status': 'sealed', 'attempt': 1, 'review': record(P/'review.json'), 'generator': record(P/'generator.py'), 'inputs': record(P/'inputs.json'), 'unchanged_inputs_at_seal': len(inputs), 'scope': review['scope'], 'pending': review['pending']}
(P/'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True)+'\n')
index = {p.name: record(p) for p in sorted(P.iterdir()) if p.is_file() and p.name != 'files.json'}
(P/'files.json').write_text(json.dumps(index, indent=2, sort_keys=True)+'\n')
assert json.loads((P/'files.json').read_text()) == index
for name, expected in index.items():
    assert record(P/name) == expected, name
print(json.dumps({'review': record(P/'review.json'), 'receipt': record(P/'receipt.json'), 'index': record(P/'files.json'), 'indexed_files': len(index)}, indent=2))
