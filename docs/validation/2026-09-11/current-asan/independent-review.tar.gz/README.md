# Independent final be22 ASan audit

**Passed on the first attempt.** The saved-data reader completed 676,701 checks and rehashed all 57,597 inputs unchanged. No producer controller, parser, compiler, profiler, fuzz target, or benchmark was executed by the reviewer. All audit work used CPU6.

All six original retained-corpus replays and six sustained campaigns reconcile: **42,961 initial files, 42,964 replay executions, 10,496,706 campaign executions, and 14,157 final disk files**. All 12 recorded processes exited zero; no artifacts, sanitizer diagnostics, harness timeouts, or recorded reruns. Each campaign lasted 601.312–601.710 seconds under its unchanged 600-second budget. The three extra replays arise from empty-input initialization in targets whose retained input set has no empty file.

The audit reconstructs both raw DONE forms, all final statistics, initial corpus counts/size extents, exact seed/command/bounds, per-lane starts/completions, every input and final corpus hash, the entire author target summary, and the package totals. It verifies all 90 evidence members against origin files, all 19 preparation mappings, all 14,157 final archive members, the six-member readiness archive, nested source357 and original corpus26,689+16,272, and exactly six excluded compiled binaries. All three preparation failures are preserved. There is no omitted bytecode.

The accepted c177/be22 source and nine-compiler/instrumentation proof reuse readiness review `26762b63` by exact hash, with all 43,396 prior inputs rehashed. All 357 source bytes and 70 runtime bytes remain unchanged. This excludes the literal-attribute candidate.

`review.json` is the compact receipt. `details.json.gz` retains all input hashes, reconstructed observations, corpus identities, and package-origin maps. `audit.py` is the independent reader; `attempt-01.log` records its sole successful run.

ASan uses the external Clang runtime with leak detection disabled. This gives bounded validation evidence, not a unique-input count, complete coverage or safety proof, performance result, LSan/UBSan claim, whole-std/libc instrumentation claim, or PBS result. Successful runs do not exercise timeout/signal cleanup paths. The immutable producer package still correctly records independent final review as pending at its earlier seal; this receipt supplements it.
