"""Independent saved-data audit. Reads producer files; executes no target or producer code."""
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import tarfile
import traceback

os.sched_setaffinity(0, {6})
OUT = Path(__file__).parent
S = Path('/tmp/oriole-be22-asan-study')
P = Path('/tmp/oriole-be22-asan-preparation')
H = Path('/tmp/oriole-be22-asan-handoff')
R = Path('/tmp/oriole-be22-asan-readiness-independent-review')
inputs = {}
checks = 0
maps = {}

def check(value, label):
    global checks
    checks += 1
    if not value:
        raise AssertionError(label)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    path = Path(path)
    check(path.is_file() and not path.is_symlink(), 'regular input ' + str(path))
    data = path.read_bytes()
    h = sha(data)
    if str(path) in inputs:
        check(inputs[str(path)] == h, 'unchanged during read ' + str(path))
    inputs[str(path)] = h
    return data

def digest(path):
    return sha(read(path))

def load(path):
    return json.loads(read(path))

def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n')

def archive(data, label):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as t:
        for m in t:
            path = PurePosixPath(m.name)
            check(m.isfile() and not path.is_absolute() and '..' not in path.parts, label + ' safe member')
            check(m.name not in result, label + ' unique member ' + m.name)
            value = t.extractfile(m).read()
            check(len(value) == m.size, label + ' member size')
            result[m.name] = value
    return result

def verify_index(data, index, label):
    check(set(data) == {r['path'] for r in index} and len(data) == len(index), label + ' inventory')
    for row in index:
        b = data[row['path']]
        check(len(b) == row['bytes'] and sha(b) == row['sha256'], label + ' indexed bytes ' + row['path'])

report = {'status': 'incomplete', 'role': 'Independent saved-data reviewer; no producer code or target executions.', 'cpu': 6}
try:
    check(digest(R/'review.json') == '26762b63b360a02a262f67cc868d862ce95889898fcdd2fbd9647ad6854c0f5b', 'readiness identity')
    ready_inputs = json.loads(gzip.decompress(read(R/'inputs.json.gz')))
    for path, expected in ready_inputs.items():
        check(digest(path) == expected, 'readiness unchanged ' + path)
    check(digest(S/'ready.json') == '420ea370c129d02cc0292b318df0d32a21d9698d66a7d8a0ab8c640a01e1484b', 'prelaunch receipt')
    source = load(S/'source.json')
    check(source['commit'] == 'c1776c922b023a3558badfefa697cd11b0d37d8e', 'accepted source commit')
    check(len(source['source_sha256']) == 357, '357 source files')
    source_bytes = archive(read(S/'source.tar.gz'), 'source')
    check({n:sha(b) for n,b in source_bytes.items()} == source['source_sha256'], 'source archive exact')
    for name, expected in source['source_sha256'].items():
        check(digest(Path(source['worktree'])/name) == expected, 'source live exact ' + name)
    baseline = load(source['runtime_baseline_manifest'])
    check(digest(source['runtime_baseline_manifest']) == source['runtime_baseline_sha256'], 'runtime baseline manifest identity')
    # The prior source manifest uses files, whereas current preparation uses source_sha256.
    baseline_map = baseline.get('source_sha256', baseline.get('files'))
    check(isinstance(baseline_map, dict) and len(baseline_map) == 70, 'runtime baseline70 schema')
    for n,v in baseline_map.items():
        expected = v if isinstance(v,str) else v['sha256']
        check(source['source_sha256'][n] == expected, 'runtime baseline equality ' + n)
    build = load(S/'build.json')
    check(build['status'] == 'passed', 'build receipt passed')
    prep = load(P/'MANIFEST.json')
    check(len(prep) == 19, 'preparation19')
    for n,h in prep.items(): check(digest(P/n) == h, 'preparation member ' + n)
    controller = load(S/'campaign-summary.json')
    lanes = [[1,['parse','multibyte']],[2,['streaming','value_family']],[4,['ffi','ffi_family']]]
    cpus = {n:cpu for cpu,names in lanes for n in names}
    check(controller['lanes'] == lanes and controller['aggregate_timeout_seconds'] == 1920, 'fixed lanes/bounds')
    check(controller['environment'] == {'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1'}, 'ASan options')
    check(controller['runner_sha256'] == digest(P/'run_all.py'), 'actual controller source')
    check(controller['preparation_manifest_sha256'] == digest(P/'MANIFEST.json'), 'controller preparation pin')
    check(controller['build_json_sha256'] == digest(S/'build.json'), 'controller build pin')
    check(controller['status'] == 'passed' and not controller['unstarted_targets'], 'all targets complete')
    check(not controller.get('error') and not controller.get('aggregate_timeout'), 'no controller failure')
    check(0 < controller['elapsed_seconds'] < 1920, 'aggregate within bound')
    union = {n:{} for n in cpus}
    nested_counts = {}
    for name in ['initial-retained-corpus.tar.gz','final-retained-corpus.tar.gz']:
        data = archive(read(S/name), name)
        nested_counts[name] = len(data)
        for n,b in data.items():
            target,filename = n.split('/')
            h = sha(b)
            check(target in union, 'known retained target')
            check((h if name.startswith('initial') else hashlib.sha1(b).hexdigest()) == filename, 'retained content filename')
            check(h not in union[target], 'unique retained input within target')
            union[target][h] = len(b)
    provenance = load(S/'corpus-provenance.json')
    summary = load(S/'summary.json')
    check(summary['audit_sha256'] == digest('/tmp/oriole-be22-asan-audit.py'), 'author audit source pin')
    check(summary['controller_sha256'] == digest(S/'campaign-summary.json'), 'author controller pin')
    rows = []
    compact = []
    final_map = {}
    result_hashes = {}
    for target,cpu in cpus.items():
        d = S/'campaigns'/target
        check({p.name for p in d.iterdir()} == {'artifacts','campaign.log','corpus','initial-corpus','initial-manifest.json','replay.log','result.json'}, 'one complete target inventory')
        check(not list((d/'artifacts').iterdir()), 'no artifact files or dirs')
        result = load(d/'result.json')
        result_hashes[target] = digest(d/'result.json')
        check(result['target'] == target and result['cpu'] == cpu, 'target/cpu')
        check(digest(S/'binaries'/target) == build['binaries'][target] == result['binary_sha256'], 'binary identity ' + target)
        check(result['source_manifest_sha256'] == digest(S/'source.json'), 'result source pin')
        check(result['initial_manifest_sha256'] == digest(d/'initial-manifest.json'), 'initial pin')
        initial = load(d/'initial-manifest.json')['inputs']
        check(initial == union[target], 'retained archives reconstruct initial manifest ' + target)
        check(initial == {n:v['size'] for n,v in provenance['inputs'][target].items()}, 'initial provenance ' + target)
        actual_initial = {}
        for p in (d/'initial-corpus').iterdir():
            b = read(p)
            check(sha(b) == p.name, 'initial byte hash')
            actual_initial[p.name] = len(b)
        check(actual_initial == initial and len(initial) == result['initial_inputs'], 'all initial bytes/sizes')
        nonempty = sum(v != 0 for v in initial.values())
        expected_replay = nonempty + 1
        check(expected_replay == result['replay_expected_executions'] == result['replay_executions'], 'libFuzzer empty initialization accounting')
        check([r['label'] for r in result['runs']] == ['replay','campaign'], 'two runs exactly')
        basecmd = ['taskset','-c',str(cpu),str(S/'binaries'/target),'-seed=20260911','-max_len=65536','-timeout=10','-rss_limit_mb=1536',f'-artifact_prefix={d / "artifacts"}/']
        row = {'target':target,'cpu':cpu,'initial_inputs':len(initial),'empty_inputs':len(initial)-nonempty,'result_sha256':result_hashes[target],'runs':[]}
        module_counts = []
        for run in result['runs']:
            label = run['label']
            suffix = ['-runs=0',str(d/'initial-corpus')] if label == 'replay' else ['-max_total_time=600','-print_final_stats=1',str(d/'corpus'),str(d/'initial-corpus')]
            check(run['command'] == basecmd + suffix, 'exact command ' + target + '/' + label)
            bound = 180 if label == 'replay' else 690
            check(run['outer_timeout_seconds'] == bound and 0 < run['elapsed_seconds'] < bound, 'run bounds')
            check(run['exit_code'] == 0 and not run.get('harness_timeout') and not run.get('controller_aborted'), 'successful original exit')
            text = read(d/(label+'.log')).decode('utf8')
            check(digest(d/(label+'.log')) == run['log_sha256'], 'raw log pin')
            check(re.findall(r'^INFO: Seed: (\d+)$',text,re.M) == ['20260911'], 'raw seed')
            check(not re.search(r'^(?:ERROR:|SUMMARY:|==\d+==|WARNING:|ALARM:|Test unit written)',text,re.M), 'no raw failure diagnostic')
            done = re.findall(r'^Done (\d+) runs in (\d+) second\(s\)$',text,re.M)
            done_progress = re.findall(r'^#(\d+)\s+DONE\b',text,re.M)
            check(len(done) == 1 and done_progress == [done[0][0]], 'two raw done forms agree')
            found = re.findall(r'^INFO:\s+(\d+) files found in (.+)$',text,re.M)
            expected_found = [(str(nonempty),str(d/'initial-corpus'))] if label == 'replay' else [('0',str(d/'corpus')),(str(nonempty),str(d/'initial-corpus'))]
            check(found == expected_found, 'raw initial paths/counts')
            seed_info = re.findall(r'^INFO: seed corpus: files: (\d+) min: (\d+)b max: (\d+)b total: (\d+)b',text,re.M)
            sizes = [v for v in initial.values() if v]
            check(seed_info == [(str(nonempty),str(min(sizes)),str(max(sizes)),str(sum(sizes)))], 'raw initial count/size extents')
            counts = re.findall(r'^INFO: Loaded 1 modules\s+\((\d+) inline 8-bit counters\): (\d+) ',text,re.M)
            pc = re.findall(r'^INFO: Loaded 1 PC tables \((\d+) PCs\): (\d+) ',text,re.M)
            check(len(counts) == 1 and counts == pc and counts[0][0] == counts[0][1], 'ASan instrumented module receipt')
            module_counts.append(counts)
            row['runs'].append({'label':label,'exit_code':0,'elapsed_seconds':run['elapsed_seconds'],'raw_done':[list(x) for x in done],'harness_timeout':False,'controller_aborted':False})
            if label == 'replay':
                check(int(done[0][0]) == expected_replay, 'raw replay all inputs')
                row['replay_executions'] = expected_replay
            else:
                stat_rows = re.findall(r'^stat::(\w+):\s+(\d+)\s*$',text,re.M)
                stats = {k:int(v) for k,v in stat_rows}
                check(len(stats) == len(stat_rows) == 5 and stats == result['stats'], 'all raw final stats')
                check(int(done[0][0]) == stats['number_of_executed_units'] > 0 and int(done[0][1]) >= 600, 'campaign executions/time')
                check(600 <= run['elapsed_seconds'] < 690, 'sustained bound met')
                row['stats'] = stats
                row['executed_units'] = stats['number_of_executed_units']
        check(module_counts[0] == module_counts[1], 'same coverage module across replay/campaign')
        actual_final = {}
        for p in (d/'corpus').iterdir():
            b = read(p)
            check(hashlib.sha1(b).hexdigest() == p.name and len(b) <= 65536, 'final content filename and max_len')
            actual_final[p.name] = sha(b)
            final_map[target+'/'+p.name] = {'bytes':len(b),'sha256':sha(b)}
        check(actual_final == result['final_corpus'], 'all final corpus hashes')
        check(result['artifacts'] == [] and all(result[k] for k in ['passed','source_unchanged','binary_unchanged','initial_inputs_unchanged']), 'all result guards')
        check(result['status'] == 'passed', 'result pass')
        row.update(final_corpus_files=len(actual_final),artifacts=[],passed=True)
        rows.append(row)
        compact.append({'target':target,'initial_files':len(initial),'replay_exec':expected_replay,'campaign_exec':row['executed_units'],'final_disk_files':len(actual_final),'duration_seconds':row['runs'][1]['elapsed_seconds'],'status':'passed'})
    check(rows == summary['targets'], 'entire author target reconstruction')
    totals = {k:sum(r[v] for r in rows) for k,v in [('total_initial_inputs','initial_inputs'),('total_replay_executions','replay_executions'),('total_executed_units','executed_units'),('total_final_corpus_files','final_corpus_files')]}
    check(all(summary[k] == v for k,v in totals.items()), 'all author aggregate counts')
    check(totals == dict(total_initial_inputs=42961,total_replay_executions=42964,total_executed_units=10496706,total_final_corpus_files=14157), 'expected counts independently reproduced')
    check(summary['status'] == 'passed' and summary['all_evidence_reconciled'], 'author success scope')
    events = [json.loads(line) for line in read(S/'controller.log').decode().splitlines()]
    check(len(events) == 18, '12 starts plus6 completions')
    active = {}; stages = {}; finish_rows = []; pids = []
    for event in events:
        cpu = event['cpu']
        if 'started' in event:
            target,label = event['started'],event['stage']
            check(cpus[target] == cpu, 'event lane')
            stages.setdefault(target,[]).append(label)
            if label == 'replay': check(cpu not in active, 'lane prior target complete')
            else: check(active.get(cpu) == (target,'replay'), 'campaign after own replay')
            active[cpu] = target,label; pids.append(event['pid'])
        else:
            check(active.pop(cpu) == (event['target'],'campaign'), 'finish own campaign')
            check(event['status'] == 'passed' and event['result_sha256'] == result_hashes[event['target']], 'finish hashes')
            finish_rows.append(event)
    check(not active and len(pids) == len(set(pids)) == 12, 'no duplicate recorded starts')
    check(all(stages[n] == ['replay','campaign'] for n in cpus), 'all two-stage starts')
    check(finish_rows == controller['results'], 'controller completion order/identity')
    for cpu,names in lanes:
        check([e['started'] for e in events if e.get('stage') == 'replay' and e['cpu'] == cpu] == names, 'fixed lane order')
    first = load(S/'first-wave.json')
    check(first['total_campaign_exec'] == sum(r['executed_units'] for r in rows if r['target'] in ['parse','streaming','ffi']), 'retained first-wave counts')
    # Package direct index, origins and complete coverage (no extraction to disk).
    check(digest(H/'report.json') == '8f2ffd730bfcebfeed4ee1d880adc3bd1917e273628e0a6723b2b55b36521099', 'sealed package report')
    check(digest(H/'files.json') == '1e48c5c976b20ae19eb3b7771f3e4a6439e6974c97a53dcd4eeca5e6fdbe4f3b', 'sealed index')
    index = load(H/'files.json')
    check({p.name for p in H.iterdir()} == set(index)|{'files.json'}, 'package complete file inventory')
    for name,row in index.items():
        b=read(H/name);check(len(b)==row['bytes'] and sha(b)==row['sha256'], 'package direct file ' + name)
    report_pkg = load(H/'report.json')
    check(report_pkg['targets'] == compact, 'package target arithmetic')
    total_pkg = {'initial_files':42961,'empty_files':3,'replay_exec':42964,'campaign_exec':10496706,'final_disk_files':14157,'replay_processes':6,'campaign_processes':6,'all_processes_exit_zero':True,'artifacts':0,'harness_timeouts':0,'reruns':0,'campaign_duration_min_seconds':min(r['duration_seconds'] for r in compact),'campaign_duration_max_seconds':max(r['duration_seconds'] for r in compact)}
    check(report_pkg['total'] == total_pkg, 'package complete aggregate')
    evidence = archive(read(H/'evidence.tar.gz'),'evidence')
    members = load(H/'members.json')
    verify_index(evidence,members['members'],'evidence')
    expected_evidence = {}; exclusions = {}; omitted_caches=[]
    for p in S.rglob('*'):
        check(not p.is_symlink(), 'study no symlink ' + str(p))
        if not p.is_file(): continue
        rel = p.relative_to(S)
        if '__pycache__' in rel.parts:
            omitted_caches.append(str(rel));continue
        if len(rel.parts)>=3 and rel.parts[0]=='campaigns' and rel.parts[2] in ['initial-corpus','corpus']:continue
        if rel.parts[0]=='binaries':
            b=read(p);exclusions[str(rel)]={'bytes':len(b),'sha256':sha(b)};continue
        expected_evidence[str(rel)] = p
    mapping=load(H/'preparation-mapping.json')
    check(set(mapping)==set(prep), 'all19 prep members mapped')
    for n,row in mapping.items():
        check(row['sha256']==prep[n] and sha(evidence[row['archive_path']])==prep[n], 'mapped prep exact '+n)
        if row['archive_path'] not in expected_evidence: expected_evidence[row['archive_path']]=P/n
    expected_evidence['preparation-mapping.json']=H/'preparation-mapping.json'
    expected_evidence['controllers/oriole-be22-asan-audit.py']=Path('/tmp/oriole-be22-asan-audit.py')
    expected_evidence['controllers/oriole-package-be22-asan.py']=Path('/tmp/oriole-package-be22-asan.py')
    check(set(evidence)==set(expected_evidence) and len(evidence)==90, 'all90 evidence origins/coverage')
    for name,p in expected_evidence.items(): check(sha(evidence[name])==digest(p), 'evidence origin '+name)
    check(exclusions=={r['path']:{'bytes':r['bytes'],'sha256':r['sha256']} for r in members['excluded_binaries']} and len(exclusions)==6,'exact six binary exclusions')
    for n,row in exclusions.items():check(row['sha256']==build['binaries'][Path(n).name], 'exclusion build pin')
    for name in ['source.tar.gz','initial-retained-corpus.tar.gz','final-retained-corpus.tar.gz']:
        check(evidence[name]==read(S/name), 'nested archive exact '+name)
    final_bytes=archive(read(H/'final-corpus.tar.gz'),'final corpus')
    verify_index(final_bytes,load(H/'final-corpus-members.json'),'final corpus')
    check({n:{'bytes':len(b),'sha256':sha(b)} for n,b in final_bytes.items()}==final_map, 'all14157 final archive/source bytes')
    review_bytes=archive(read(H/'readiness-review.tar.gz'),'readiness review')
    verify_index(review_bytes,load(H/'readiness-review-members.json'),'readiness review')
    check(set(review_bytes)=={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}, 'complete readiness review inventory')
    for n,b in review_bytes.items():check(sha(b)==digest(R/n),'readiness review origin '+n)
    check(read(H/'readiness-review.json')==read(R/'review.json'), 'readiness direct copy')
    for label,name,count in [('evidence','evidence.tar.gz',90),('final_corpus','final-corpus.tar.gz',14157),('readiness_review','readiness-review.tar.gz',6)]:
        check(report_pkg['archives'][label]=={'sha256':digest(H/name),'members':count}, 'package archive pins')
    check(len(report_pkg['retained_failures'])==3, 'all3 preparation failures disclosed')
    check('preparation/failed-preparation-attempt-01/receipt.json' in evidence and any(n.startswith('setup-history/attempt-01/') for n in evidence), 'failure evidence preserved')
    check('input-materialization-attempt-01.json' in evidence and 'input-materialization-attempt-01.stderr' in evidence, 'materialization failure evidence preserved')
    check(sha(evidence['controllers/oriole-package-be22-asan.py'])==digest(H/'oriole-package-be22-asan.py'),'package controller copy')
    maps.update(inputs=inputs,targets=rows,package_origins={n:str(p) for n,p in expected_evidence.items()},excluded_binaries=exclusions,omitted_bytecode=omitted_caches,final_corpus=final_map)
    # Rehash every input again; never re-execute any producer controller.
    for name,h in list(inputs.items()):check(sha(Path(name).read_bytes())==h,'after audit unchanged '+name)
    report.update(status='passed',checks=checks,unchanged_input_files=len(inputs),readiness_reused={'path':str(R/'review.json'),'sha256':inputs[str(R/'review.json')],'previous_inputs_rehashed':len(ready_inputs)},source={'commit':source['commit'],'source_files':357,'runtime_files':70,'source_manifest_sha256':inputs[str(S/'source.json')]},results=compact,totals=total_pkg,package={'report_sha256':inputs[str(H/'report.json')],'files_sha256':inputs[str(H/'files.json')],'archives':report_pkg['archives'],'nested_source_files':357,'nested_original_corpus_members':nested_counts,'preparation_members':19,'excluded_compiled_binaries':6,'omitted_bytecode_files':len(omitted_caches)},findings=[],limitations=['Saved evidence confirms the 12 recorded original launches; successful runs do not exercise timeout or signal cleanup paths.','Executions include initialization and repeated inputs; final disk files are an evolved corpus, not a unique-input or coverage proof.','ASan external Clang runtime, leak detection disabled. No LSan/UBSan, entire std/libc instrumentation, performance, exhaustive-safety, literal-attribute prototype, or PBS result claim.','Preparation/build/input readiness and its three preserved preparation failures are reused by exact review hash, with all prior inputs rehashed. No preparation failure is a campaign rerun.'])
except BaseException as error:
    report.update(status='failed',checks=checks,error=repr(error),traceback=traceback.format_exc())
    raise
finally:
    maps['inputs']=inputs
    (OUT/'details.json.gz').write_bytes(gzip.compress(json.dumps(maps,sort_keys=True,separators=(',',':')).encode(),mtime=0))
    report['generator_sha256']=sha(Path(__file__).read_bytes())
    report['compressed_details_sha256']=sha((OUT/'details.json.gz').read_bytes())
    save('review.json',report)
    print(json.dumps({k:report[k] for k in ['status','checks']})+' '+sha((OUT/'review.json').read_bytes()))
