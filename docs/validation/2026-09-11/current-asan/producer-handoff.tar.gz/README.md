# Current be22 ASan handoff

All six retained-corpus replays and all six 600-second campaigns passed on accepted c177/be22, with **10,496,706 campaign executions** and no findings or artifacts. Separate replay executions total 42,964. This excludes the literal-attribute prototype.

| Target | Initial files | Replay executions | Campaign executions | Final disk files | Campaign seconds |
| --- | ---: | ---: | ---: | ---: | ---: |
| parse | 4,316 | 4,316 | 4,090,775 | 4,479 | 601.312 |
| multibyte | 11,282 | 11,282 | 1,137,365 | 1,531 | 601.399 |
| streaming | 9,000 | 9,001 | 1,890,912 | 2,781 | 601.343 |
| value_family | 3,686 | 3,687 | 673,319 | 769 | 601.322 |
| ffi | 5,144 | 5,145 | 2,222,031 | 3,539 | 601.386 |
| ffi_family | 9,533 | 9,533 | 482,304 | 1,058 | 601.710 |

`report.json` is the stable summary schema for publication. `evidence.tar.gz` contains complete controllers, logs, source/tool/compiler/instrumentation evidence, original input archives and provenance, initial manifests, results, author audit and all three retained preparation failures. `members.json` indexes every member and the six excluded compiled executables with exact hashes. Every archive member was read back and hashed.

`final-corpus.tar.gz` and `final-corpus-members.json` retain every final disk input separately. Both prior retained corpus archives appear once inside the evidence archive; the entire older evidence bundle is not duplicated. `preparation-mapping.json` maps all 19 frozen preparation members to their exact stored bytes, avoiding duplicate source/provenance archives. The original and new studies remain unchanged by packaging.

`readiness-review.tar.gz`, its member index and `readiness-review.json` retain the independent pre-campaign readiness review. Independent review of final campaign results is pending. Root's PBS workflow34563056904 is separate; this package makes no PBS pass claim and transfers no older PBS result.

The fresh Ohm build contains nine actual ASan compiler invocations: three workspace libraries and six fuzz targets. Representative ASan report sites were confirmed in XML_Parse, Parser::parse_text and AdapterFrame::text_bytes. External Clang ASan runtime, leak detection disabled; no LSan/UBSan or whole-std/libc instrumentation claim. Source357 and selected runtime70 bytes match the frozen manifests. Execution counts include initialization and repeated inputs; they are bounded validation evidence, not performance or exhaustive-safety evidence.
