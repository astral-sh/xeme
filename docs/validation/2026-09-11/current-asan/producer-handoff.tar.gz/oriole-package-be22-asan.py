"""Package reviewed be22 ASan evidence, storing original corpora/source only once."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

STUDY = Path('/tmp/oriole-be22-asan-study')
PREP = Path('/tmp/oriole-be22-asan-preparation')
REVIEW = Path('/tmp/oriole-be22-asan-readiness-independent-review')
OUT = Path('/tmp/oriole-be22-asan-handoff')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(path.read_bytes())


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def pack(path, entries):
    members = []
    with tarfile.open(path, 'w:gz', compresslevel=9) as archive:
        for name, source in sorted(entries.items()):
            data = source.read_bytes()
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
            members.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    with tarfile.open(path, 'r:gz') as archive:
        actual = archive.getmembers()
        assert len(actual) == len(members)
        for member, expected in zip(actual, members):
            assert member.isfile() and member.name == expected['path'] and member.size == expected['bytes']
            assert sha(archive.extractfile(member).read()) == expected['sha256']
    return members


summary = json.loads((STUDY / 'summary.json').read_text())
assert summary['status'] == 'passed' and summary['all_evidence_reconciled']
assert len(summary['targets']) == 6
build = json.loads((STUDY / 'build.json').read_text())
source = json.loads((STUDY / 'source.json').read_text())
instrumentation = json.loads((STUDY / 'instrumentation' / 'report.json').read_text())
assert all(digest(Path(source['worktree']) / name) == value for name, value in source['source_sha256'].items())
assert digest(REVIEW / 'review.json') == '26762b63b360a02a262f67cc868d862ce95889898fcdd2fbd9647ad6854c0f5b'
OUT.mkdir(exist_ok=False)

final_entries = {}
for row in summary['targets']:
    target = row['target']
    result_path = STUDY / 'campaigns' / target / 'result.json'
    assert digest(result_path) == row['result_sha256']
    result = json.loads(result_path.read_text())
    corpus = STUDY / 'campaigns' / target / 'corpus'
    actual = {path.name: digest(path) for path in corpus.iterdir()}
    assert actual == result['final_corpus']
    for path in corpus.iterdir():
        assert hashlib.sha1(path.read_bytes()).hexdigest() == path.name
        final_entries[target + '/' + path.name] = path
final_members = pack(OUT / 'final-corpus.tar.gz', final_entries)
save(OUT / 'final-corpus-members.json', final_members)

entries, excluded = {}, []
for path in sorted(STUDY.rglob('*')):
    if not path.is_file() or path.is_symlink() or '__pycache__' in path.parts:
        continue
    relative = path.relative_to(STUDY)
    # Retained input bytes are already in the two original archives; new corpus
    # bytes are in final-corpus.tar.gz. Full per-target manifests remain evidence.
    if len(relative.parts) >= 3 and relative.parts[0] == 'campaigns' and relative.parts[2] in {'initial-corpus', 'corpus'}:
        continue
    if relative.parts[0] == 'binaries':
        assert digest(path) == build['binaries'][path.name]
        excluded.append({'path': str(relative), 'bytes': path.stat().st_size, 'sha256': digest(path)})
        continue
    assert not path.read_bytes().startswith((b'\x7fELF', b'!<arch>\n')), relative
    entries[str(relative)] = path
assert len(excluded) == 6

# Preserve every frozen preparation member with an explicit mapping. Exact
# duplicate large source/provenance bytes reuse the study member already present.
preparation_manifest = json.loads((PREP / 'MANIFEST.json').read_text())
assert all(digest(PREP / name) == value for name, value in preparation_manifest.items())
existing_by_hash = {digest(path): name for name, path in entries.items()}
mapping = {}
for name, expected in preparation_manifest.items():
    archive_name = existing_by_hash.get(expected)
    if archive_name is None:
        archive_name = 'preparation/' + name
        entries[archive_name] = PREP / name
        existing_by_hash[expected] = archive_name
    mapping[name] = {'archive_path': archive_name, 'sha256': expected}
assert digest(PREP / 'MANIFEST.json') == digest(STUDY / 'preparation-MANIFEST.json')
save(OUT / 'preparation-mapping.json', mapping)
entries['preparation-mapping.json'] = OUT / 'preparation-mapping.json'
entries['controllers/oriole-be22-asan-audit.py'] = Path('/tmp/oriole-be22-asan-audit.py')
entries['controllers/oriole-package-be22-asan.py'] = Path(__file__)
evidence_members = pack(OUT / 'evidence.tar.gz', entries)
save(OUT / 'members.json', {'members': evidence_members, 'excluded_binaries': excluded})

review_entries = {str(path.relative_to(REVIEW)): path for path in REVIEW.rglob('*') if path.is_file()}
review_members = pack(OUT / 'readiness-review.tar.gz', review_entries)
save(OUT / 'readiness-review-members.json', review_members)
shutil.copy2(REVIEW / 'review.json', OUT / 'readiness-review.json')

targets = []
for row in summary['targets']:
    campaign = next(run for run in row['runs'] if run['label'] == 'campaign')
    targets.append({'target': row['target'], 'initial_files': row['initial_inputs'],
                    'replay_exec': row['replay_executions'], 'campaign_exec': row['executed_units'],
                    'final_disk_files': row['final_corpus_files'],
                    'duration_seconds': campaign['elapsed_seconds'], 'status': 'passed' if row['passed'] else 'failed'})
report = {
    'status': 'passed', 'targets': targets,
    'total': {'initial_files': sum(row['initial_files'] for row in targets),
              'empty_files': sum(row['empty_inputs'] for row in summary['targets']),
              'replay_exec': sum(row['replay_exec'] for row in targets),
              'campaign_exec': sum(row['campaign_exec'] for row in targets),
              'final_disk_files': len(final_members),
              'replay_processes': 6, 'campaign_processes': 6, 'all_processes_exit_zero': True,
              'artifacts': 0, 'harness_timeouts': 0, 'reruns': 0,
              'campaign_duration_min_seconds': min(row['duration_seconds'] for row in targets),
              'campaign_duration_max_seconds': max(row['duration_seconds'] for row in targets)},
    'source': {'commit': source['commit'], 'runtime': 'be22a27 accepted native-byte-count runtime',
               'literal_attribute_candidate_included': False, 'source_files': len(source['source_sha256']),
               'runtime_files_matching_selected_pgo_source': source['runtime_files_matching_baseline'],
               'source_manifest_sha256': digest(STUDY / 'source.json'),
               'source_archive_sha256': digest(STUDY / 'source.tar.gz'),
               'source_unchanged': True},
    'tools': {name: (STUDY / (name + '.log')).read_text().strip() for name in ['rustc', 'cargo_fuzz', 'clang']},
    'build': {'actual_workspace_library_compilations': 3, 'actual_fuzz_target_compilations': 6,
              'all_nine_have_address_sanitizer': True, 'ohm_defaults_disabled_for_build': True,
              'ohm_trust_opt_ins_absent': True, 'build_sha256': digest(STUDY / 'build.json'),
              'compiler_proof_sha256': digest(STUDY / 'workspace-and-target-proof.json'),
              'binaries': build['binaries']},
    'instrumentation': {'report_sha256': digest(STUDY / 'instrumentation' / 'report.json'),
                        'functions': [{'name': row['name'], 'size': row['size'],
                                       'asan_report_sites': len(row['asan_report_sites']),
                                       'disassembly_sha256': row['sha256']} for row in instrumentation['functions']],
                        'scope': instrumentation['scope']},
    'protocol': {'seed': 20260911, 'max_len': 65536, 'per_input_timeout_seconds': 10,
                 'rss_limit_mb': 1536, 'campaign_budget_seconds': 600,
                 'replay_outer_timeout_seconds': 180, 'campaign_outer_timeout_seconds': 690,
                 'aggregate_outer_timeout_seconds': 1920,
                 'asan_options': 'detect_leaks=0:abort_on_error=1',
                 'lanes': [[1, ['parse', 'multibyte']], [2, ['streaming', 'value_family']], [4, ['ffi', 'ffi_family']]],
                 'controller_owns_all_target_process_groups': True},
    'retained_failures': [
        'Ambient Python import hook failed during preparation before inventory/setup/build; corrected by system Python -E -S -B.',
        'Initial worktree setup rejected -Zohm-defaults=no; separate setup-only correction used required cargo +ohm worktree add. Build still disables defaults.',
        'Final redundant provenance copy failed on the identical read-only destination after input materialization; full read-only completion audit passed, no input extraction rerun.'],
    'review': {'readiness_review_sha256': digest(REVIEW / 'review.json'),
               'readiness_review_scope': 'Independent frozen preparation/build/input-readiness review before target results.',
               'campaign_independent_review': 'pending; this package includes author raw-data reconciliation only'},
    'pbs': {'run_id': 34563056904, 'url': 'https://github.com/astral-sh/oriole/actions/runs/34563056904',
            'scope': 'Separate current-source PBS workflow launched by root; no PBS result is inferred from this local ASan package.'},
    'archives': {'evidence': {'sha256': digest(OUT / 'evidence.tar.gz'), 'members': len(evidence_members)},
                 'final_corpus': {'sha256': digest(OUT / 'final-corpus.tar.gz'), 'members': len(final_members)},
                 'readiness_review': {'sha256': digest(OUT / 'readiness-review.tar.gz'), 'members': len(review_members)}},
    'readback_all_members_verified': True,
    'scope': 'Six fresh ASan retained-corpus replays and sustained campaigns on accepted be22/c177. Counts include initialization and repeated inputs. No LSan, UBSan, entire-std/libc instrumentation, performance, literal-attribute-prototype or exhaustive-safety claim. Final disk corpus is retained separately and never substitutes for original inputs.'}
save(OUT / 'report.json', report)
rows = '\n'.join(f"| {row['target']} | {row['initial_files']:,} | {row['replay_exec']:,} | {row['campaign_exec']:,} | {row['final_disk_files']:,} | {row['duration_seconds']:.3f} |"
                 for row in targets)
(OUT / 'README.md').write_text(f'''# Current be22 ASan handoff

All six retained-corpus replays and all six 600-second campaigns passed on accepted c177/be22, with **{report['total']['campaign_exec']:,} campaign executions** and no findings or artifacts. Separate replay executions total {report['total']['replay_exec']:,}. This excludes the literal-attribute prototype.

| Target | Initial files | Replay executions | Campaign executions | Final disk files | Campaign seconds |
| --- | ---: | ---: | ---: | ---: | ---: |
{rows}

`report.json` is the stable summary schema for publication. `evidence.tar.gz` contains complete controllers, logs, source/tool/compiler/instrumentation evidence, original input archives and provenance, initial manifests, results, author audit and all three retained preparation failures. `members.json` indexes every member and the six excluded compiled executables with exact hashes. Every archive member was read back and hashed.

`final-corpus.tar.gz` and `final-corpus-members.json` retain every final disk input separately. Both prior retained corpus archives appear once inside the evidence archive; the entire older evidence bundle is not duplicated. `preparation-mapping.json` maps all 19 frozen preparation members to their exact stored bytes, avoiding duplicate source/provenance archives. The original and new studies remain unchanged by packaging.

`readiness-review.tar.gz`, its member index and `readiness-review.json` retain the independent pre-campaign readiness review. Independent review of final campaign results is pending. Root's PBS workflow34563056904 is separate; this package makes no PBS pass claim and transfers no older PBS result.

The fresh Ohm build contains nine actual ASan compiler invocations: three workspace libraries and six fuzz targets. Representative ASan report sites were confirmed in XML_Parse, Parser::parse_text and AdapterFrame::text_bytes. External Clang ASan runtime, leak detection disabled; no LSan/UBSan or whole-std/libc instrumentation claim. Source357 and selected runtime70 bytes match the frozen manifests. Execution counts include initialization and repeated inputs; they are bounded validation evidence, not performance or exhaustive-safety evidence.
''')
shutil.copy2(Path(__file__), OUT / Path(__file__).name)
files = {str(path.relative_to(OUT)): {'bytes': path.stat().st_size, 'sha256': digest(path)}
         for path in sorted(OUT.rglob('*')) if path.is_file()}
save(OUT / 'files.json', files)
for path in OUT.rglob('*'):
    if path.is_file():
        path.chmod(0o444)
for path in sorted(OUT.rglob('*'), reverse=True):
    if path.is_dir():
        path.chmod(0o555)
OUT.chmod(0o555)
print(json.dumps({'status': 'passed', 'report_sha256': digest(OUT / 'report.json'),
                  'files_sha256': digest(OUT / 'files.json'), 'total': report['total'],
                  'archives': report['archives']}, indent=2))
