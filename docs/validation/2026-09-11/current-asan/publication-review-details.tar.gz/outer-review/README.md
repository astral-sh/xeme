# Current ASan outer archive review

Passed on CPU 6: 586 checks, 41 outer members and 79 unchanged inputs.

All four outer archive hashes and every member match `archive-members.json`, each live origin and the original sealed file index. Counts are 12 producer files, 7 final-review files, 10 draft-prose files and 12 draft-structure files. Member permissions match their origins. The report, readiness review and final review copies are byte-exact.

Both retained uncompressed directories contain all 12 original handoff files with exact bytes and 0444 file modes. The original handoff and final-review directories remain 0555. The correction source changes only the generated data directory to 0755 before a same-filesystem rename; it preserves the failed cross-filesystem move and both complete generated copies. Original source permissions and hashes remained unchanged during this review.

Nested campaign, corpus, readiness and text archives were treated as opaque bytes. The linked complete saved-data review is `2c8ee226e4aa494c25a751ed9e184de281600eed8bc3d506601bd4fb5e3e7899`; its work was not repeated. Final prose, links and publication index are separate. No targets ran and no producer files changed.

The first attempt passed. `generator.py`, both raw streams, `members.json` and `inputs.json` retain the complete bounded reconstruction.
