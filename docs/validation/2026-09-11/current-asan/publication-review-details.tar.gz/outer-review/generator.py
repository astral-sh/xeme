#!/usr/bin/env python3
"""Read only the four outer ASan archives, their live origins and generated copies."""
import ast
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile

OUT = Path('/tmp/oriole-current-asan-final-outer-independent-review')
PUB = Path('/home/dev-user/code/oss/oriole-current-asan/docs/validation/2026-09-11/current-asan')
ORIGINS = {
    'producer-handoff.tar.gz': Path('/tmp/oriole-be22-asan-handoff'),
    'independent-review.tar.gz': Path('/tmp/oriole-be22-asan-final-independent-review'),
    'draft-prose-review.tar.gz': Path('/tmp/oriole-current-asan-prose-independent-review'),
    'draft-structure-review.tar.gz': Path('/tmp/oriole-current-asan-doc-structure-independent-review'),
}
COUNTS = [12, 7, 10, 12]
inputs = {}
directory_modes = {}
checks = 0

def ck(ok, label):
    global checks
    checks += 1
    assert ok, label

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    path = Path(path)
    ck(not path.is_symlink() and path.is_file(), str(path)+' regular origin')
    data = path.read_bytes()
    inputs[str(path)] = {'sha256': digest(data), 'bytes': len(data), 'mode': stat.S_IMODE(path.stat().st_mode)}
    return data

def files(root):
    directory_modes[str(root)] = stat.S_IMODE(root.stat().st_mode)
    paths = sorted(root.rglob('*'))
    ck(all(not p.is_symlink() for p in paths), str(root)+' no symlinks')
    return {str(p.relative_to(root)): p for p in paths if p.is_file()}

def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

ck(os.sched_getaffinity(0) == {6}, 'CPU 6 only')
manifest = json.loads(read(PUB/'archive-members.json'))
ck(set(manifest) == set(ORIGINS), 'exact four archives indexed')
members = []
for (archive_name, origin), expected_count in zip(ORIGINS.items(), COUNTS):
    entry = manifest[archive_name]
    archive_bytes = read(PUB/archive_name)
    ck(digest(archive_bytes) == entry['sha256'] and len(archive_bytes) == entry['size'], archive_name+' outer identity')
    origin_files = files(origin)
    ck(len(origin_files) == expected_count and set(origin_files) == set(entry['members']), archive_name+' origin/manifest complete')
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as archive:
        rows = archive.getmembers()
        ck(len(rows) == expected_count, archive_name+' count')
        ck(len({m.name for m in rows}) == len(rows), archive_name+' unique names')
        ck({m.name for m in rows} == set(origin_files), archive_name+' exact members')
        for member in rows:
            ck(member.isfile() and not member.issym() and not member.islnk(), archive_name+' regular member '+member.name)
            parts = PurePosixPath(member.name)
            ck(not parts.is_absolute() and '..' not in parts.parts, 'safe member name')
            payload = archive.extractfile(member).read()
            origin_bytes = read(origin_files[member.name])
            expected = entry['members'][member.name]
            ck(payload == origin_bytes, archive_name+' live origin bytes '+member.name)
            ck(len(payload) == member.size == expected['size'], archive_name+' member size '+member.name)
            ck(digest(payload) == expected['sha256'], archive_name+' member digest '+member.name)
            ck(member.mode == stat.S_IMODE(origin_files[member.name].stat().st_mode), archive_name+' member/source permissions '+member.name)
            members.append({'archive': archive_name, 'member': member.name, 'origin': str(origin_files[member.name]), 'bytes': len(payload), 'sha256': digest(payload), 'mode': member.mode})
    original_index = json.loads(read(origin/'files.json'))
    ck(set(original_index) == set(origin_files)-{'files.json'}, archive_name+' original index complete')
    for name, value in original_index.items():
        expected_hash = value if isinstance(value, str) else value['sha256']
        ck(inputs[str(origin/name)]['sha256'] == expected_hash, archive_name+' original sealed index hash '+name)
        if isinstance(value, dict):
            ck(inputs[str(origin/name)]['bytes'] == value['bytes'], archive_name+' original sealed index size '+name)

for original in list(ORIGINS.values())[:2]:
    ck(directory_modes[str(original)] == 0o555, str(original)+' immutable directory')
    ck(all(inputs[str(p)]['mode'] == 0o444 for p in files(original).values()), str(original)+' immutable file modes')

copies = []
handoff = ORIGINS['producer-handoff.tar.gz']
for copy_root, expected_mode in [
    (Path('/tmp/oriole-current-asan-publication-uncompressed-copy'), 0o555),
    (Path('/home/dev-user/code/oss/oriole-current-asan-uncompressed-draft'), 0o755),
]:
    copy_files = files(copy_root)
    ck(set(copy_files) == set(manifest['producer-handoff.tar.gz']['members']), str(copy_root)+' full 12-file copy')
    ck(directory_modes[str(copy_root)] == expected_mode, str(copy_root)+' expected generated directory mode')
    for name, path in copy_files.items():
        data = read(path)
        expected = inputs[str(handoff/name)]
        ck(digest(data) == expected['sha256'] and len(data) == expected['bytes'], str(path)+' copy exact')
        ck(inputs[str(path)]['mode'] == expected['mode'] == 0o444, str(path)+' original file modes retained')
    copies.append({'directory': str(copy_root), 'files': len(copy_files), 'directory_mode': expected_mode, 'file_modes': 0o444})
ck(not (PUB/'data').exists(), 'generated data directory moved out of publication')

compact = {}
for name, origin in [('report.json', handoff/'report.json'), ('readiness-review.json', handoff/'readiness-review.json'), ('independent-review.json', ORIGINS['independent-review.tar.gz']/'review.json')]:
    ck(read(PUB/name) == read(origin), name+' compact copy exact')
    compact[name] = {'origin': str(origin), 'sha256': inputs[str(origin)]['sha256']}
ck(compact['independent-review.json']['sha256'] == '2c8ee226e4aa494c25a751ed9e184de281600eed8bc3d506601bd4fb5e3e7899', 'peer complete saved-data review identity')

package = read(PUB/'package-publication.py')
ck(package == read('/tmp/oriole-finalize-current-asan-docs.py'), 'package source exact origin')
ck(read(PUB/'assemble-draft.py') == read('/tmp/oriole-publish-current-asan-docs.py'), 'draft assembler exact origin')
correction = read(PUB/'packaging-correction.py').decode()
correction_json = json.loads(read(PUB/'packaging-correction.json'))
ck(correction_json['status'] == 'passed' and correction_json['sources_changed'] is False and correction_json['targets_rerun'] is False, 'correction retained scope')
tree = ast.parse(correction)
chmods = [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'chmod']
ck(len(chmods) == 1 and ast.unparse(chmods[0]) == "(destination / 'data').chmod(493)", 'sole correction chmod limited to generated data directory')
renames = [node for node in ast.walk(tree) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'rename']
ck(len(renames) == 1 and ast.unparse(renames[0]) == "(destination / 'data').rename(retained)", 'sole correction rename limited to generated data directory')
ck("Path('/home/dev-user/code/oss/oriole-current-asan-uncompressed-draft')" in correction and "Path('/tmp/oriole-current-asan-publication-uncompressed-copy')" in correction, 'both retained generated-copy paths recorded')
ck('assert actual == expected' in correction and "assert {str(p.relative_to(copy)):" in correction, 'archive and both copy checks precede correction')
ck(correction.index('assert actual == expected') < correction.index('.chmod(') and correction.index('assert {str(p.relative_to(copy)):') < correction.index('.chmod('), 'readbacks before generated chmod')
ck('subprocess' not in correction and 'subprocess' not in package.decode(), 'packaging sources contain no target launcher')

for path, expected in inputs.items():
    current = Path(path)
    payload = current.read_bytes()
    ck(digest(payload) == expected['sha256'] and len(payload) == expected['bytes'] and stat.S_IMODE(current.stat().st_mode) == expected['mode'], path+' input bytes and mode unchanged')
for name, mode in directory_modes.items():
    ck(stat.S_IMODE(Path(name).stat().st_mode) == mode, name+' directory mode unchanged')

write('members.json', members)
write('inputs.json', inputs)
write('review.json', {
    'status': 'passed', 'scope': 'CPU 6 saved-only four outer archives, original file indexes, exact live origin bytes and modes, two retained generated copies, compact reports and packaging correction source. No nested archive opening, arithmetic reconstruction, target execution or producer edits.',
    'archives': {name: {'sha256': value['sha256'], 'bytes': value['size'], 'members': len(value['members'])} for name, value in manifest.items()},
    'total_members': len(members), 'compact_copies': compact, 'retained_generated_copies': copies,
    'source_permissions': 'Original handoff and final-review directories remain 0555, all their files 0444; all 41 archived member modes match live origins. Draft review permissions are recorded, not described as immutable.',
    'correction': 'Initial cross-filesystem move left two complete generated copies. The retained correction checks all outer archives and both copies, makes only the generated data directory 0755, then renames it within the worktree filesystem. Both copies retain every original byte and file mode. Source handoff remains unchanged.',
    'linked_full_review': '2c8ee226e4aa494c25a751ed9e184de281600eed8bc3d506601bd4fb5e3e7899',
    'unchanged_inputs': len(inputs), 'checks': checks, 'directory_modes': directory_modes,
    'limitations': ['Nested evidence/corpus/readiness/text archives were treated as opaque member bytes; the earlier complete audit retains that scope.', 'Final prose, Markdown links, attachments and publication files.json are owned by the separate final publication review.', 'This audit observes and preserves source permissions; it does not reconstruct every historical chmod syscall.'],
    'generator_sha256': digest(Path(__file__).read_bytes())
})
print(json.dumps({'status': 'passed', 'checks': checks, 'inputs': len(inputs), 'members': len(members), 'review_sha256': digest((OUT/'review.json').read_bytes())}))
