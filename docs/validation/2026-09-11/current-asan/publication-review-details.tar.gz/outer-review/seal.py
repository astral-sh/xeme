import hashlib
import json
import os
from pathlib import Path
import stat

P = Path('/tmp/oriole-current-asan-final-outer-independent-review')
assert os.sched_getaffinity(0) == {6}

def record(p):
    b = p.read_bytes()
    return {'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)}

review = json.loads((P/'review.json').read_text())
assert review['generator_sha256'] == record(P/'generator.py')['sha256']
assert (P/'attempt01.stderr').read_bytes() == b''
attempt = json.loads((P/'attempt01.stdout').read_text())
assert attempt['status'] == 'passed'
assert attempt['review_sha256'] == record(P/'review.json')['sha256']
inputs = json.loads((P/'inputs.json').read_text())
for name, expected in inputs.items():
    p = Path(name)
    assert record(p) == {k: expected[k] for k in ['sha256', 'bytes']}, name
    assert stat.S_IMODE(p.stat().st_mode) == expected['mode'], name
for name, mode in review['directory_modes'].items():
    assert stat.S_IMODE(Path(name).stat().st_mode) == mode, name
receipt = {'status': 'sealed', 'attempt': 1, 'review': record(P/'review.json'), 'generator': record(P/'generator.py'), 'inputs': record(P/'inputs.json'), 'unchanged_inputs_at_seal': len(inputs), 'scope': review['scope']}
(P/'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True)+'\n')
index = {p.name: record(p) for p in sorted(P.iterdir()) if p.is_file() and p.name != 'files.json'}
(P/'files.json').write_text(json.dumps(index, indent=2, sort_keys=True)+'\n')
for name, expected in json.loads((P/'files.json').read_text()).items():
    assert record(P/name) == expected, name
print(json.dumps({'review': record(P/'review.json'), 'receipt': record(P/'receipt.json'), 'index': record(P/'files.json'), 'indexed_files': len(index)}, indent=2))
