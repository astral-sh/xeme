"""Final publication metadata/text review only; no producer or target execution."""
from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile,urllib.parse
O=Path(__file__).parent;W=Path('/home/dev-user/code/oss/oriole-current-asan');D=W/'docs/validation/2026-09-11/current-asan';base='c1776c922b023a3558badfefa697cd11b0d37d8e'
inputs={}
def read(p):
 p=Path(p);b=p.read_bytes();h=hashlib.sha256(b).hexdigest();assert inputs.setdefault(str(p),h)==h;return b
def load(p):return json.loads(read(p))
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
original=load('/tmp/oriole-current-asan-prose-independent-review/inputs.json')
for p in (W/'README.md',W/'docs/review.md'):assert hashlib.sha256(read(p)).hexdigest()==original[str(p)]
with tarfile.open('/tmp/oriole-current-asan-prose-independent-review/reviewed-text.tar.gz') as tf:
 table=load('/tmp/oriole-current-asan-prose-independent-review/reviewed-text-members.json')
 member=next(x['member'] for x in table if x['origin']==str(D/'README.md'))
 before=tf.extractfile(member).read().decode()
text=read(D/'README.md').decode()
assert text.split('## Evidence and scope')[0]==before.split('## Evidence and scope')[0]
assert text[text.index('The existing 393 upstream API failures'):]==before[before.index('The existing 393 upstream API failures'):]
assert '[publication index](files.json) records file hashes, and the [archive member index](archive-members.json) records member hashes' in text
report=load(D/'report.json');ready=load(D/'readiness-review.json');final=load(D/'independent-review.json')
assert hashlib.sha256(read(D/'report.json')).hexdigest()=='8f2ffd730bfcebfeed4ee1d880adc3bd1917e273628e0a6723b2b55b36521099'
assert hashlib.sha256(read(D/'independent-review.json')).hexdigest()=='2c8ee226e4aa494c25a751ed9e184de281600eed8bc3d506601bd4fb5e3e7899'
assert final['status']=='passed' and final['findings']==[] and final['results']==report['targets'] and final['totals']==report['total']
assert final['checks']==676701 and final['unchanged_input_files']==57597
assert final['package']['report_sha256']==hashlib.sha256(read(D/'report.json')).hexdigest()
assert final['readiness_reused']['sha256']==hashlib.sha256(read(D/'readiness-review.json')).hexdigest()
assert '676,701 checks across 57,597 unchanged inputs' in text and 'all 12 executions' in text
assert 'earlier sealing time; this final review supersedes that status' in text
assert 'They exclude this final packaging and review-link update' in text
assert git('rev-parse','HEAD').decode().strip()==base
assert set(git('diff','--name-only',base).decode().splitlines())=={'README.md','docs/review.md'}
assert not git('diff','--name-only',base,'--','crates','include','.github','Cargo.toml','Cargo.lock')
assert all(n.startswith('docs/validation/2026-09-11/current-asan/') for n in git('ls-files','--others','--exclude-standard').decode().splitlines())
for n in ('LICENSE-MIT','LICENSE-APACHE'):assert read(W/n)==git('show',base+':'+n)
# Earlier structure review covers unchanged top README/docs-review and anchors.
structure=load('/tmp/oriole-current-asan-doc-structure-independent-review/review.json')
links=[]
for label,target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',text):
 parsed=urllib.parse.urlsplit(target)
 if parsed.scheme:continue
 p=(D/urllib.parse.unquote(parsed.path)).resolve();exists=p.exists()
 if p==D/'publication-review.json':exists=True # this final receipt is written below
 assert exists or p==D/'files.json',(label,target)
 links.append({'label':label,'target':target,'present_or_written_by_review':exists,'pending_root_final_index':p==D/'files.json'})
assert not (D/'files.json').exists()
correction=load(D/'packaging-correction.json')
assert correction['status']=='passed' and not correction['sources_changed'] and not correction['targets_rerun']
assert 'Cross-filesystem' in correction['initial_attempt'] and 'read-only' in correction['initial_attempt'] and 'same-filesystem' in correction['correction']
for p in (D/'assemble-draft.py',D/'package-publication.py',D/'packaging-correction.py'):read(p)
assert 'archive member index' in (D/'package-publication.py').read_text()
outerpath=Path('/tmp/oriole-current-asan-final-outer-independent-review/review.json')
outer=load(outerpath);assert outer['status']=='passed'
archives=load(D/'archive-members.json')
assert {n:len(r['members']) for n,r in archives.items()}=={'producer-handoff.tar.gz':12,'independent-review.tar.gz':7,'draft-prose-review.tar.gz':10,'draft-structure-review.tar.gz':12}
for n,r in archives.items():assert hashlib.sha256(read(D/n)).hexdigest()==r['sha256']
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in inputs.items())
with gzip.open(O/'details.json.gz','wt') as f:json.dump({'input_hashes':inputs,'final_readme_links':links,'outer_review':outer},f,indent=2)
review={'status':'passed','role':'Independent agent review of final publication text and compact archive packaging; no parser, compiler, benchmark or producer execution.','source_commit':base,'reviewed_text_sha256':{str(p.relative_to(W)):inputs[str(p)] for p in (W/'README.md',W/'docs/review.md',D/'README.md')},'prior_draft_prose_review_sha256':'453058b3b728f2e94261b6545adaa4be239590b03955f46afe2938ff889ad6b5','structure_review_sha256':'3e7f96d572afda9325c2003811495fd9a64f9c09ea9f6d03dc94f61ff3164e5c','final_campaign_review_sha256':inputs[str(D/'independent-review.json')],'outer_archive_review_sha256':inputs[str(outerpath)],'archive_counts':{n:len(r['members']) for n,r in archives.items()},'conclusions':['Final numerical/build/protocol/source/limitation paragraphs are byte-exact to the independently reviewed draft; new final-review claims match the sealed 2c8ee226 report.','All 12 producer files, seven final-review files and earlier draft review snapshots are retained unchanged in the four outer archives. Compact report/readiness/final-review copies match sealed originals; the independent outer review verifies member hashes, origins and original preservation.','Packaging corrections are explicitly recorded as generated-copy filesystem/permission failures, separate from the three earlier preparation failures. No original evidence or target results were changed or rerun.','Top README and docs/review are unchanged since the draft review; heading/warning/license and docs-only/no-runtime-or-CI change checks remain valid. All final local links resolve except the intentionally pending files.json.'],'pending_final_index':'Root must create files.json after review artifacts are attached. This review does not certify that future index or subsequent edits. The publication-review.json link is satisfied by this receipt itself.','limitations':['Full raw campaign/corpus/source-build verification is reused from the sealed independent final review; this final pass checks compact publication packaging and wording.','No PBS outcome, new compatibility, speed, LSan/UBSan or exhaustive safety claim is added.'],'details_sha256':hashlib.sha256((O/'details.json.gz').read_bytes()).hexdigest()}
b=(json.dumps(review,indent=2)+'\n').encode();(O/'review.json').write_bytes(b);(D/'publication-review.json').write_bytes(b)
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256(b).hexdigest(),'inspected_inputs':len(inputs),'readme_links':len(links),'index_pending':True}))
