from pathlib import Path
import hashlib,io,json,tarfile
O=Path(__file__).parent;D=Path('/home/dev-user/code/oss/oriole-current-asan/docs/validation/2026-09-11/current-asan');C=Path('/tmp/oriole-current-asan-final-outer-independent-review')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (O/'review.json').read_bytes()==(D/'publication-review.json').read_bytes()
inputs={}
for prefix,root in [('publication',O),('outer-review',C)]:
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.name not in ('receipt.json','files.json') or (p.is_file() and root==C):inputs[prefix+'/'+str(p.relative_to(root))]=p
members={n:{'origin':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for n,p in inputs.items()}
(O/'archive-members.json').write_text(json.dumps(members,indent=2)+'\n')
inputs['publication/archive-members.json']=O/'archive-members.json'
archive=D/'publication-review-details.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(inputs.items()):
  b=p.read_bytes();i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
with tarfile.open(archive) as t:
 assert len(t.getmembers())==len(inputs)
 for m in t.getmembers():assert sha(t.extractfile(m).read())==sha(inputs[m.name].read_bytes())
receipt={'status':'sealed_final_publication_review','review_sha256':sha((O/'review.json').read_bytes()),'details_archive':archive.name,'details_archive_sha256':sha(archive.read_bytes()),'details_members':len(inputs),'outer_review_sha256':sha((C/'review.json').read_bytes()),'auditor_attempts':'Initial audit string assertion omitted the comma in the correctly clarified index sentence; preserved initial script/log and punctuation-only correction. No producer changes or target runs. Corrected audit passed.','final_index':'files.json deliberately remains pending root creation after these review artifacts; no future-index claim.'}
b=(json.dumps(receipt,indent=2)+'\n').encode();(O/'receipt.json').write_bytes(b);(D/'publication-review-receipt.json').write_bytes(b)
files={str(p.relative_to(O)):sha(p.read_bytes()) for p in sorted(O.rglob('*')) if p.is_file() and p.name!='files.json'}
(O/'files.json').write_text(json.dumps(files,indent=2)+'\n')
assert all(sha((O/n).read_bytes())==h for n,h in files.items())
print(json.dumps({'review':receipt['review_sha256'],'archive':receipt['details_archive_sha256'],'members':len(inputs),'receipt':sha(b),'external_index':sha((O/'files.json').read_bytes())}))
