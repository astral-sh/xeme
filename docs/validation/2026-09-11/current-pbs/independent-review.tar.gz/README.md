# Independent current PBS review

No publication blocker was found. This review checked saved data on CPU6. It did not invoke the installed interpreter, Docker, a compiler, a parser target, or any benchmark. Read-only Git, archive decompression and ELF inspection were used.

The independent audit passed 28,947 checks across 5,851 input files, all rehashed at the end. It reconstructed all 802 host/container method outcomes, including 792 direct successes, two methods with recorded subtest outcomes, three skipped methods, three expected failures and two failures. Eight skipped subtests and one skipped class complete the 12 skipped outcomes. The original glibc script additionally skips the CPU-resource Minidom method under its default resource configuration; this attribution follows preserved source and argument arrays, rather than a verbose result from that script.

Workflow 34563056904 built the exact c177 source, with the 67 included crate/header/manifest paths matching the accepted be22 revision. The 69 bundle and 97 launch source hashes form the exact 101-file snapshot. Three actual stable Rust compiler vectors establish ThinLTO, one codegen unit, PIC and unwind, with no PGO or sanitizer flags. The raw toolchain log identifies stable Rust 1.98.1. These binaries remain distinct from local Ohm/PGO binaries.

Every compact evidence member, ZIP entry and original distribution tar member reconciled. Independent decompression matched the retained 357,928,960-byte tar. Static ELF inspection reproduced all 195,584 saved symbol-output bytes. All 5,497 original regular files were rehashed; only the three recorded encoding `.pyc` cache files changed. The original compressed distribution and native/source/test bytes remain exact. All three excluded binary containers are retained and hash-bound.

The workflow and XML gates remain failed on the two documented character-data grouping assertions. CI's 802 initial tests and four selected reruns reconcile with four failure occurrences. Identity and glibc steps were skipped in CI. Five local diagnostics ran once with the planned arguments and deadlines: installed identity and fresh accelerators pass; the two verbose suites and original glibc script fail; the original script first completes 1,024 threaded parses on actual glibc 2.17. Host/container verbose method, fixture and subtest outcomes match. The initial Docker socket denial, authorized continuation of only the remaining container commands, pinned pre-existing image, disabled networking, read-only mounts and cleanup of the two owned container IDs are retained.

The final publication README, main README and review-note additions preserve this scope. The six-member publication wrapper is byte-exact to the producer handoff. Main README headings, warning and license remain unchanged. The `independent-review.json` and `files.json` links await root's final attachment/index step; their existence was not claimed by this review.

## Retained reviewer correction

The first audit attempt interpreted every `-v` argument as a Docker mount, including the installed interpreter's later `unittest -v`. Its assertion failed during the second container configuration check. The audit now inspects Docker arguments only up to the pinned image argument. The original audit source, traceback and check receipt are retained. This was a reviewer error; no producer data or target execution changed.

## Files

`receipt.json` contains the full independent check accounting. `inputs.json.gz` preserves every reviewed path, size and hash without a large plain-text array. `audit.py` is the executed successful audit; its complete stdout/stderr are retained. `static-supplement.json` contains the independent decompression/ELF result, and `static-supplement.py` reconstructs those read-only commands. `resource-skip-proof.json` retains the exact source excerpts explaining resource routing. `review.json` and `files.json` bind this complete review package.
