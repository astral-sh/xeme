"""Independent saved-evidence audit. Never invokes the installed interpreter or Docker."""
import collections
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import tarfile
import zipfile

ROOT = Path('/tmp/oriole-be22-pbs-followup')
PACKAGE = Path('/tmp/oriole-be22-pbs-followup-handoff')
LAUNCH = Path('/tmp/oriole-be22-pbs-workflow')
OUT = Path(__file__).parent
REPO = Path('/home/dev-user/code/oss/oriole-c-allocator-study')
COMMIT = 'c1776c922b023a3558badfefa697cd11b0d37d8e'
RUNTIME = 'be22a271f8a5c004d13e515cd4024a68afe57887'
INPUTS = {}
CHECKS = collections.Counter()

def check(value, category):
    CHECKS[category] += 1
    assert value, category

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    data = path.read_bytes()
    row = {'bytes': len(data), 'sha256': digest(data)}
    check(str(path) not in INPUTS or INPUTS[str(path)] == row, 'input_consistency')
    INPUTS[str(path)] = row
    return data

def hash_file(path):
    with path.open('rb') as f:
        row = {'bytes': path.stat().st_size, 'sha256': hashlib.file_digest(f, 'sha256').hexdigest()}
    check(str(path) not in INPUTS or INPUTS[str(path)] == row, 'input_consistency')
    INPUTS[str(path)] = row
    return row

def load(path):
    return json.loads(read(path))

def archive_bytes(path):
    data = read(path)
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as tar:
        result = {}
        for member in tar:
            check(member.isfile() and member.name not in result, 'compact_member_unique_regular')
            result[member.name] = tar.extractfile(member).read()
        return result

def git_blobs(revision, names):
    raw = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=REPO,
        input=''.join(f'{revision}:{name}\n' for name in names).encode())
    stream = io.BytesIO(raw)
    result = {}
    for name in names:
        head = stream.readline().decode().split()
        check(len(head) == 3 and head[1] == 'blob', 'git_blob_header')
        result[name] = stream.read(int(head[2]))
        check(stream.read(1) == b'\n', 'git_blob_separator')
    check(stream.read() == b'', 'git_blob_eof')
    return result

def verbose(data):
    text = data.decode()
    section = text.split('\n======================================================================\n', 1)[0]
    # Split into whole unittest result records, then classify each terminal status.
    starts = list(re.finditer(r'^(test\w*|setUpClass) \((test\.[^)]+)\)', section, re.M))
    methods, fixtures, subtests = {}, {}, []
    for i, match in enumerate(starts):
        block = section[match.start():starts[i + 1].start() if i + 1 < len(starts) else len(section)]
        nested = re.findall(r'^  .+ \.\.\. .+$', block, re.M)
        status_lines = re.findall(r'^(?!  ).*\.\.\. (ok|FAIL|ERROR|expected failure|skipped .+)$', block, re.M)
        if not status_lines:
            status_lines = re.findall(r'^(ok|FAIL|ERROR|expected failure|skipped .+)$', block, re.M)
        if nested:
            check(not status_lines, 'subtest_only_record')
            status = 'subtest outcomes'
            subtests.extend(nested)
        else:
            check(len(status_lines) == 1, 'single_method_terminal_status')
            status = status_lines[0]
        table = fixtures if match[1] == 'setUpClass' else methods
        check(match[2] not in table, 'method_identifier_unique')
        table[match[2]] = status
    check(re.findall(r'^Ran (\d+) tests in ', text, re.M) == [str(len(methods))], 'verbose_total')
    return {'methods': methods, 'fixtures': fixtures, 'subtests': subtests,
        'method_status_counts': dict(collections.Counter(methods.values()))}

def main():
    check(os.sched_getaffinity(0) == {6}, 'audit_cpu6_only')
    report = load(PACKAGE / 'report.json')
    package_index = load(PACKAGE / 'files.json')
    check(set(package_index) == {p.name for p in PACKAGE.iterdir()} - {'files.json'}, 'complete_package_index')
    for name, expected in package_index.items():
        check(hash_file(PACKAGE / name) == expected, 'package_hash')
    members = archive_bytes(PACKAGE / 'evidence.tar.gz')
    member_index = load(PACKAGE / 'evidence-members.json')
    check(member_index['archive_sha256'] == INPUTS[str(PACKAGE / 'evidence.tar.gz')]['sha256'], 'evidence_archive_hash')
    expected = {r['path']: r for r in member_index['members']}
    check(set(members) == set(expected) and len(members) == 124, 'all_124_members')
    for name, data in members.items():
        check(len(data) == expected[name]['bytes'] and digest(data) == expected[name]['sha256'], 'member_hash_size')
        check(read(ROOT / name) == data, 'member_origin_bytes')
        check(not data.startswith(b'\x7fELF'), 'no_direct_elf')
    check(read(PACKAGE / 'report.json') == read(ROOT / 'report.json'), 'report_copy')
    check(read(PACKAGE / 'README.md') == read(ROOT / 'RESULTS.md'), 'prose_copy')
    excluded = load(PACKAGE / 'excluded-distribution.json')['files']
    check(len(excluded) == 3, 'three_excluded_distribution_containers')
    for row in excluded:
        check(hash_file(ROOT / row['path']) == {k: row[k] for k in ['bytes', 'sha256']}, 'excluded_binary_container_hash')
        check(row['path'] not in members, 'excluded_not_packaged')
    expected_package_files = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
        and not str(p.relative_to(ROOT)).startswith(('extracted/', 'source/'))}
    check(set(members) | {r['path'] for r in excluded} == expected_package_files, 'all_producer_files_accounted')
    prep = load(ROOT / 'preparation-index.json')
    for name, expected in prep['files'].items():
        check(hash_file(ROOT / name) == expected, 'preparation_unchanged')

    # Every GitHub download's raw ZIP entries and extracted origins.
    downloads = load(ROOT / 'downloads.json')
    artifacts = load(ROOT / 'github-artifacts.json')['artifacts']
    zip_names = {'workflow-logs.zip': 'workflow-logs', 'validation-artifact.zip': 'validation',
        'experimental-distribution-artifact.zip': 'distribution'}
    artifact_names = {'validation-artifact.zip': 'oriole-pbs-validation',
        'experimental-distribution-artifact.zip': 'oriole-pbs-experimental-distribution'}
    for record in downloads['archives']:
        zpath = ROOT / record['archive']
        check(hash_file(zpath) == {k: record[k] for k in ['bytes', 'sha256']}, 'download_zip_hash')
        if record['archive'] in artifact_names:
            art, = [a for a in artifacts if a['name'] == artifact_names[record['archive']]]
            check(art['digest'] == 'sha256:' + record['sha256'], 'github_digest')
        with zipfile.ZipFile(zpath) as z:
            check(set(z.namelist()) == {r['path'] for r in record['members']}, 'zip_member_set')
            for row in record['members']:
                data = z.read(row['path'])
                check(len(data) == row['bytes'] and digest(data) == row['sha256'], 'zip_member_hash')
                check(read(ROOT / zip_names[record['archive']] / row['path']) == data, 'zip_extracted_origin')

    # Entire distribution tar inventory, regular file bytes and live unchanged native/source files.
    archive_index = load(ROOT / 'archive-members.json')
    changed = []
    with tarfile.open(ROOT / 'distribution.tar', 'r:') as tar:
        actual_members = tar.getmembers()
        check(len(actual_members) == len(archive_index) == 6546, 'distribution_all_members')
        regular = 0
        for member, row in zip(actual_members, archive_index, strict=True):
            check((member.name, member.size, member.type.decode(), member.linkname) ==
                (row['name'], row['size'], row['type'], row['linkname']), 'tar_metadata')
            if member.isfile():
                regular += 1
                data = tar.extractfile(member).read()
                check(digest(data) == row['sha256'], 'tar_original_regular_hash')
                now = hash_file(ROOT / 'extracted' / member.name)['sha256']
                if now != row['sha256']:
                    changed.append({'name': member.name, 'archive_sha256': row['sha256'], 'after_sha256': now})
        check(regular == 5497, 'regular_count')
    runtime_audit = load(ROOT / 'runtime-audit.json')
    check(changed == runtime_audit['changed_original_members'] and len(changed) == 3, 'exact_pyc_changes')
    check(all('/encodings/__pycache__/' in row['name'] and row['name'].endswith('.pyc') for row in changed), 'only_encoding_cache_changes')

    # Source snapshot is checked against Git, live checkout, launch, and bundle independently.
    source = load(ROOT / 'source.json')
    bundle = load(ROOT / 'validation/oriole-bundle/manifest.json')
    launch_source = load(LAUNCH / 'source.json')
    check(source['commit'] == launch_source['commit'] == COMMIT, 'source_commit')
    check(len(source['files']) == 101 and len(bundle['sources']) == 69 and len(launch_source['files']) == 97, 'source_counts')
    merged = {name: val if isinstance(val, str) else val['sha256'] for name, val in launch_source['files'].items()}
    for name, val in bundle['sources'].items():
        check(name not in merged or merged[name] == val, 'launch_bundle_overlap')
        merged[name] = val
    check(merged == source['files'], 'exact_source_union')
    blobs = git_blobs(COMMIT, sorted(merged))
    snapshot = archive_bytes(ROOT / 'source.tar.gz')
    check(set(snapshot) == set(merged), 'source_archive_set')
    for name, data in blobs.items():
        check(digest(data) == merged[name], 'git_source_hash')
        check(data == snapshot[name] == read(ROOT / 'source' / name) == read(REPO / name), 'source_bytes')
    # Accepted be22 to c177 has no changes in parser crates, headers, lock or workspace manifests.
    runtime_names = [n for n in merged if n.startswith(('crates/', 'include/')) or n in ['Cargo.toml', 'Cargo.lock']]
    old_blobs = git_blobs(RUNTIME, runtime_names)
    check(all(old_blobs[n] == blobs[n] for n in runtime_names), 'accepted_be22_runtime_equivalence')
    for p in LAUNCH.iterdir():
        if p.is_file():
            check(read(p) == read(ROOT / 'launch' / p.name), 'root_launch_copy')

    run = load(ROOT / 'github-run.json')
    job, = load(ROOT / 'github-jobs.json')['jobs']
    check((run['id'], run['head_sha'], run['run_attempt'], run['status'], run['conclusion']) ==
        (34563056904, COMMIT, 1, 'completed', 'failure'), 'actual_workflow_identity')
    check(job['id'] == 103149561768, 'actual_job_identity')
    check([s['name'] for s in job['steps'] if s['conclusion'] == 'failure'] == report['workflow']['failed_steps'], 'actual_failed_steps')
    check([s['name'] for s in job['steps'] if s['conclusion'] == 'skipped'] == report['workflow']['skipped_steps'], 'actual_skipped_steps')
    check(next(s for s in job['steps'] if s['name'] == 'Build CPython 3.12.13 with Oriole')['conclusion'] == 'success', 'full_distribution_built')
    log = read(ROOT / 'validation/oriole-bundle/build.log').decode()
    compiler = {}
    for line in log.splitlines():
        if 'Running `' not in line or '/rustc ' not in line:
            continue
        argv = shlex.split(line.split('Running `', 1)[1].rsplit('`', 1)[0])
        crate = argv[argv.index('--crate-name') + 1]
        if crate in ['oriole', 'oriole_storage', 'oriole_expat']:
            check(crate not in compiler, 'unique_actual_compiler')
            compiler[crate] = {'argv': argv, 'raw': line}
            check('/stable-x86_64-unknown-linux-gnu/bin/rustc' in argv[0], 'stable_rustc_path')
            check(all(arg in argv for arg in ['opt-level=3', 'codegen-units=1', 'relocation-model=pic', 'panic=unwind']), 'actual_optimization_flags')
            check(not any('profile-use' in a or 'profile-generate' in a or 'sanitizer=' in a for a in argv), 'no_pgo_sanitizer')
    check(len(compiler) == 3 and compiler == load(ROOT / 'compiler-proof.json'), 'actual_compiler_proof')
    expat_argv = compiler['oriole_expat']['argv']
    check('lto=thin' in expat_argv and [expat_argv[i+1] for i,a in enumerate(expat_argv) if a == '--crate-type'] == ['cdylib', 'staticlib'], 'c_only_thin_lto')
    check(bundle['rustc'] == report['build']['rustc'] and 'release: 1.98.1\n' in bundle['rustc'], 'stable_version')
    for name, sha in report['build']['native_hashes'].items():
        check(hash_file(ROOT / 'extracted/python' / name)['sha256'] == sha, 'native_binary_binding')
    check(bundle['files']['libexpat.a'] == report['build']['native_hashes']['build/lib/libexpat.a'], 'bundle_static_in_distribution')
    installed = ROOT / 'installed-source'
    for p in installed.rglob('*'):
        if p.is_file():
            check(read(p) == read(ROOT / 'extracted/python' / p.relative_to(installed)), 'packaged_installed_source')
    for name, expected_sha in report['source']['six_installed_xml_test_modules_match_cached_upstream'].items():
        check(hash_file(installed / 'install/lib/python3.12/test' / (name + '.py'))['sha256'] == expected_sha ==
            hash_file(Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Lib/test') / (name + '.py'))['sha256'], 'original_cpython_tests')
    check(read(ROOT / 'checks/test-old-glibc.py') == blobs['integration/python-build-standalone/test-old-glibc.py'], 'original_glibc_script_exact')
    routing = load(ROOT / 'cpython-routing.json')
    pbs_lines = read(ROOT / 'validation/pbs-build.log').decode().splitlines()
    for row in routing:
        check(pbs_lines[row['line']-1] == row['text'], 'routing_raw_line')
    check(any('patching file Modules/pyexpat.c' in row['text'] for row in routing), 'consumer_patch_applied')
    check(any('wrap=__cxa_thread_atexit_impl' in row['text'] for row in routing), 'tls_wrap_link')
    symbols = read(ROOT / 'libpython-dynamic-symbols.txt').decode()
    check(max(tuple(map(int,x.split('.'))) for x in re.findall(r'@GLIBC_([0-9.]+)', symbols)) == (2,17), 'static_glibc217_max')

    # CI outcome failure assertions, selected reruns and custom checks are reconstructed from raw logs.
    ci = read(ROOT / 'validation/pbs-xml-tests.log').decode()
    custom = read(ROOT / 'validation/pbs-custom-tests.log').decode()
    check('Ran 22 tests' in custom and 'OK (skipped=5)' in custom and 'Ran 22 tests' in ci and 'OK (skipped=5)' in ci, 'two_custom_22_5')
    check(read(ROOT / 'validation/pbs-validate.log').decode().strip().endswith('.tar.zst OK'), 'archive_validator_pass')
    check('Total tests: run=806 failures=4 skipped=12' in ci, 'ci_806_4_12')
    reruns = re.findall(r'^test\w* \((test\.[^)]+)\) \.\.\. (FAIL|ok)$', ci, re.M)
    check([{'id': a, 'status': b} for a,b in reruns] == report['ci_subchecks']['rerun_methods'] and len(reruns) == 4, 'ci_four_selected_reruns')
    failures = ['test.test_pyexpat.BufferTextTest.test1', 'test.test_sax.CDATAHandlerTest.test_handlers']
    check(sorted(set(re.findall(r'^FAIL: \w+ \(([^)]+)\)', ci, re.M))) == failures, 'ci_exact_two_failures')
    assertion_lines = re.findall(r'^AssertionError: .+$', ci, re.M)
    check(len(assertion_lines) == 4 and assertion_lines[:2] == assertion_lines[2:], 'ci_assertion_repeat')

    plan = load(ROOT / 'followup-plan.json')
    initial = load(ROOT / 'runtime/controller-result.json')
    resumed = load(ROOT / 'runtime/resume-result.json')
    check(initial['status'] == 'incomplete' and resumed['status'] == 'both_planned_docker_diagnostics_recorded', 'preserved_denial_then_resume')
    all_rows = initial['rows'] + resumed['rows']
    check(len({r['name'] for r in all_rows}) == len(all_rows), 'no_repeated_record_names')
    check([r['name'] for r in initial['rows']] == ['installed-identity-and-collection', 'fresh-accelerator', 'host-xml-verbose', 'image-inspect-initial'], 'three_host_then_denial')
    for row in all_rows:
        check(row == load(ROOT / 'runtime' / (row['name']+'.json')), 'controller_row_raw_receipt')
        for output in ['stdout','stderr']:
            check(hash_file(ROOT / 'runtime' / row[output])['sha256'] == row[output+'_sha256'], 'raw_output_hash')
        check(not row['timed_out'] and not row['interrupted'], 'no_timeout_interrupt')
        check(0 <= row['operational_seconds'] < row['timeout_seconds'], 'within_deadline')
    for number, command in enumerate(plan['commands']):
        matches = [r for r in all_rows if r['name'] == command['name']]
        check(len(matches) == 1, 'each_target_exactly_once')
        row = matches[0]
        check(row['argv'] == command['argv'] and row['timeout_seconds'] == command['timeout_seconds'], 'planned_command_exact')
        check(row['exit_code'] == [0,0,1,1,1][number], 'actual_target_exit')
        if number >= 3:
            argv = row['argv']
            docker_args = argv[:argv.index(plan['image'])]
            check('--network=none' in docker_args and '--cpuset-cpus=2' in docker_args and all(docker_args[i+1].endswith(':ro') for i,a in enumerate(docker_args) if a == '-v'), 'isolated_container_configuration')
            cid = read(ROOT / 'runtime' / (command['name']+'.cid')).decode().strip()
            cleanup = load(ROOT / 'runtime' / (command['name']+'-cleanup.json'))
            check(re.fullmatch('[0-9a-f]{64}',cid) and cleanup['argv'] == ['docker','rm','-f',cid] and cleanup['exit_code'] == 0, 'owned_cid_cleanup')
            absent = load(ROOT / 'runtime' / (command['name']+'-require-absent.json'))
            check(absent['exit_code'] != 0 and 'No such container:' in read(ROOT / 'runtime' / absent['stderr']).decode(), 'named_container_absent_before')
    check('permission denied' in read(ROOT / 'runtime/image-inspect-initial.stderr').decode(), 'raw_socket_denial')
    check(not (ROOT / 'runtime/image-pull-pinned.json').exists(), 'no_image_pull')
    image, = load(ROOT / 'runtime/image-inspect-authorized.stdout')
    check(plan['image'].removeprefix('docker.io/library/') in image['RepoDigests'], 'pinned_image_digest')
    identity = load(ROOT / 'runtime/installed-identity-and-collection.stdout')
    check(identity['expat_version'] == 'oriole_compat_2.8.4' and identity['version_info'] == [2,8,4] and identity['loader_errors'] == [], 'installed_oriole_identity')
    check(identity['pyexpat_origin'] == identity['elementtree_origin'] == 'built-in', 'built_in_accelerators')
    check(identity['glibc'] == ['glibc','2.39'], 'host_glibc')
    fresh = load(ROOT / 'runtime/fresh-accelerator.stdout')
    check(fresh == report['fresh_accelerator'] and fresh['fresh_accelerator'] == 'built-in' and fresh['cET_is_none'] is False and fresh['cET_alias_is_none'] is False, 'fresh_accelerators')
    host = verbose(read(ROOT / 'runtime/host-xml-verbose.stderr'))
    container = verbose(read(ROOT / 'runtime/glibc217-xml-verbose.stderr'))
    saved_outcomes = load(ROOT / 'method-outcomes.json')
    check(host == container == saved_outcomes['host'] == saved_outcomes['glibc217'], 'independent_802_outcomes_match')
    check(len(host['methods']) == 802, '802_executed_methods')
    statuses = collections.Counter(host['methods'].values())
    check(statuses['FAIL'] == 2 and statuses['expected failure'] == 3 and len(host['subtests']) == 8 and len(host['fixtures']) == 1, 'complete_failure_skip_xfail_accounting')
    check(sum(status.startswith('skipped ') for status in host['methods'].values()) == 3, 'three_method_skips')
    check(sorted(n for n,s in host['methods'].items() if s == 'FAIL') == failures, 'local_same_two_failures')
    collected = {r['id'] for r in identity['tests']}
    check(len(collected) == 803 and collected - host['methods'].keys() == {'test.test_xml_etree_c.NoAcceleratorTest.test_correct_import_pyET'}, '803_collection_802_execution')
    check(host['methods']['test.test_minidom.MinidomTest.testAppendChildNoQuadraticComplexity'] == 'ok', 'verbose_cpu_resource_pass')
    for name in ['host-xml-verbose','glibc217-xml-verbose','glibc217-original']:
        text = read(ROOT / 'runtime' / (name+'.stderr')).decode()
        check(re.findall(r'^AssertionError: .+$', text, re.M) == assertion_lines[:2], 'exact_local_ci_assertions')
    original = read(ROOT / 'runtime/glibc217-original.stdout').decode()
    check(json.loads(original.splitlines()[0]) == {'glibc':['glibc','2.17'],'expat':'oriole_compat_2.8.4','threaded_parses':1024}, 'actual_glibc_thread_parses')
    check('Total tests: run=802 failures=2 skipped=13' in original and 'returned non-zero exit status 2.' in read(ROOT / 'runtime/glibc217-original.stderr').decode(), 'original_script_child_failure')
    support = read(installed / 'install/lib/python3.12/test/support/__init__.py').decode()
    minidom = read(installed / 'install/lib/python3.12/test/test_minidom.py').decode()
    check('return use_resources is None or resource in use_resources' in support and "@support.requires_resource('cpu')\n    def testAppendChildNoQuadraticComplexity" in minidom, 'resource_skip_source_explanation')

    # Final publication wrapper and prose, excluding links still being finalized by root.
    publication = Path('/home/dev-user/code/oss/oriole-current-pbs')
    doc = publication / 'docs/validation/2026-09-11/current-pbs'
    wrapper = archive_bytes(doc / 'producer-handoff.tar.gz')
    wrapper_index = load(doc / 'archive-members.json')
    check(set(wrapper) == set(wrapper_index) == {p.name for p in PACKAGE.iterdir()}, 'publication_exact_six_files')
    for name, data in wrapper.items():
        check(data == read(PACKAGE / name) and wrapper_index[name] == {'sha256':digest(data),'size':len(data)}, 'publication_wrapper_byte_identity')
    check(read(doc/'report.json') == read(PACKAGE/'report.json'), 'publication_report_identity')
    prose = read(doc/'README.md').decode()
    for text in ['**The workflow and XML suites remain failed', 'three methods, eight subtests and one class',
        'CI skipped installed identity and glibc validation', '1,024 parses passed',
        '802 tests, two failures, 12 skipped outcomes, three expected failures',
        '802 tests, two failures, 13 skips', 'These sysroot-built binaries have no PGO or sanitizer instrumentation',
        'It makes no speed, exhaustive compatibility or production-readiness claim.']:
        check(text.lower() in prose.lower(), 'publication_scope_statement')
    for name in ['README.md','docs/review.md']:
        read(publication/name)
    diff = subprocess.check_output(['git','diff','--name-only'],cwd=publication).decode().splitlines()
    check(diff == ['README.md','docs/review.md'], 'tracked_documentation_only')
    base_readme = subprocess.check_output(['git','show','HEAD:README.md'],cwd=publication).decode()
    current_readme = read(publication/'README.md').decode()
    check(base_readme.split('## License',1)[1] == current_readme.split('## License',1)[1], 'readme_license_exact')
    check(re.findall(r'^#+ .+$',base_readme,re.M) == re.findall(r'^#+ .+$',current_readme,re.M), 'readme_headings_exact')
    check(re.findall(r'^>.*$',base_readme,re.M) == re.findall(r'^>.*$',current_readme,re.M), 'readme_warning_exact')
    read(Path('/tmp/oriole-publish-current-pbs-docs.py'))

    # Rehash every input a second time. No target runtime is invoked by this review.
    for filename, row in sorted(INPUTS.items()):
        path = Path(filename)
        with path.open('rb') as f:
            check(path.stat().st_size == row['bytes'] and hashlib.file_digest(f, 'sha256').hexdigest() == row['sha256'], 'unchanged_at_review_end')
    return {'status':'passed_independent_saved_data_audit', 'target_execution':False,
        'cpu_affinity':[6], 'workflow':34563056904,'source_commit':COMMIT,'accepted_runtime_commit':RUNTIME,
        'package_report_sha256':INPUTS[str(PACKAGE/'report.json')]['sha256'],
        'package_evidence_sha256':INPUTS[str(PACKAGE/'evidence.tar.gz')]['sha256'],
        'package_index_sha256':INPUTS[str(PACKAGE/'files.json')]['sha256'],
        'checks':dict(CHECKS),'total_checks':sum(CHECKS.values()),'unchanged_input_files':len(INPUTS),
        'verified_source_union':len(merged),'accepted_runtime_source_files':len(runtime_names),
        'distribution_members':6546,'original_regular_files':5497,'changed_encoding_pyc_files':3,
        'host_container_method_outcomes_each':802,'method_status_counts':dict(statuses),
        'finding':'No publication blocker. Workflow and all XML gates remain failed; installed identity, fresh accelerators and glibc 2.17 threaded loading pass.',
        'publication_prose':'Reviewed final report and main README/review additions; exact six-file wrapper. independent-review.json/files.json links are intentionally awaiting attachment.',
        'limits':['Saved-data audit; no target execution or rebenchmark.',
            'CI stable/sysroot binary differs from local Ohm and PGO artifacts.',
            'CI identity/glibc steps were skipped; local supplemental diagnostics do not change workflow failure.',
            'Original glibc script has no verbose per-method results; CPU-resource skip cause is inferred from preserved CPython source and direct-unittest result.']}

if __name__ == '__main__':
    try:
        result = main()
    except BaseException as error:
        result = {'status':'review_attempt_failed','exception':repr(error),'checks':dict(CHECKS),'target_execution':False}
        path = OUT / f'failed-attempt-{len(list(OUT.glob("failed-attempt-*.json")))+1}.json'
        path.write_text(json.dumps(result,indent=2)+'\n')
        raise
    (OUT/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    import gzip
    with gzip.GzipFile(filename=str(OUT/'inputs.json.gz'),mode='wb',mtime=0) as f:
        f.write((json.dumps(INPUTS,sort_keys=True,indent=2)+'\n').encode())
    print(json.dumps(result,indent=2))
