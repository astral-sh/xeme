"""Reconstruct the compressed archive, static ELF and resource-routing evidence."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/tmp/oriole-be22-pbs-followup')
out = Path(__file__).parent
assert os.sched_getaffinity(0) == {6}
archive, = (root / 'distribution').glob('*.tar.zst')
cmd = ['zstd', '-dc', str(archive)]
process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
sha = hashlib.sha256()
length = 0
for block in iter(lambda: process.stdout.read(1024 * 1024), b''):
    sha.update(block)
    length += len(block)
error = process.stderr.read()
code = process.wait()
assert code == 0 and not error
expected = json.loads((root / 'extraction.json').read_text())
assert (sha.hexdigest(), length) == (expected['tar_sha256'], expected['tar_bytes'])
cmd2 = ['readelf', '--dyn-syms', '--wide', str(root / 'extracted/python/install/lib/libpython3.12.so.1.0')]
elf = subprocess.run(cmd2, capture_output=True, check=True)
assert not elf.stderr and elf.stdout == (root / 'libpython-dynamic-symbols.txt').read_bytes()
log, = (root / 'workflow-logs/distribution').glob('4_Run*')
assert 'stable-x86_64-unknown-linux-gnu unchanged - rustc 1.98.1 (48a229cea 2026-09-01)' in log.read_text()
row = {'status': 'passed_static_archive_and_elf_supplement', 'target_execution': False, 'cpu': 6,
    'zstd': {'argv': cmd, 'exit_code': code, 'decompressed_bytes': length, 'sha256': sha.hexdigest()},
    'readelf': {'argv': cmd2, 'exit_code': elf.returncode, 'bytes': len(elf.stdout),
        'sha256': hashlib.sha256(elf.stdout).hexdigest(), 'saved_output_byte_exact': True},
    'raw_toolchain_log_confirms_stable_1_98_1': True}
assert row == json.loads((out / 'static-supplement.json').read_text())
print(json.dumps(row))
