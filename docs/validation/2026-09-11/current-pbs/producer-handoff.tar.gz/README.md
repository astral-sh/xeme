# Current PBS follow-up: identity and loading pass; XML gates remain failed

Workflow [34563056904](https://github.com/astral-sh/oriole/actions/runs/34563056904) built the current c177/be22 Oriole bundle and complete CPython 3.12.13 distribution. Its archive validator passed. Each of two custom-suite invocations reported 22 tests, five skips and 17 successes. The workflow failed at complete-distribution validation; installed-identity and glibc checks were skipped in CI.

The five authorized local diagnostics have now completed once each:

| Diagnostic | Observed result |
| --- | --- |
| Installed identity and collection | Exit 0; Oriole 2.8.4; `pyexpat` and `_elementtree` built in; no loader errors |
| Fresh accelerator import | Exit 0; fresh built-in `_elementtree`; both C accelerator aliases available |
| Host verbose XML, glibc 2.39 | Exit 1; 802 tests, two failures, 12 skipped outcomes, three expected failures |
| Original glibc 2.17 script | Actual glibc 2.17 and 1,024 threaded parses pass; XML child exits 2 and outer script exits 1: 802 tests, two failures, 13 skips |
| glibc 2.17 verbose XML | Exit 1; 802 tests, two failures, 12 skipped outcomes, three expected failures |

All 802 method outcomes, class-fixture outcomes and subtest outcomes match between the host and container verbose runs. Both fail `BufferTextTest.test1` and `CDATAHandlerTest.test_handlers`, with the same assertion differences present in this run's CI log. The fresh CI log reports 802 initial executions plus four automatically rerun-selected executions, for 806 executions and four failure occurrences. No old-source result was transferred to this study.

Collection sees 803 methods; `NoAcceleratorTest.test_correct_import_pyET` does not execute because its class skips when the C accelerator is present. The verbose runs' 12 skipped outcomes comprise three methods, eight subtests and one class. The original `-m test` script reports one more skip because its default resource configuration disables the CPU resource. Direct `unittest` assumes resources enabled; the two verbose logs show the CPU-resource Minidom complexity test passed. The installed CPython support and test source defining this difference is retained.

## Provenance and boundaries

All 69 CI bundle source hashes and 97 root launch-source hashes match exact c177 Git blobs: their 101-file union is frozen. Three actual workspace compiler vectors prove stable Rust 1.98.1, C-only ThinLTO, one codegen unit, PIC and unwind. This bundle has no PGO or sanitizer instrumentation. Its static library exactly matches the distribution's `build/lib/libexpat.a`, SHA-256 `3ad17c84e0e4019d0882b57c2f48584aecf58caaf9ebaf003d836d34923d2c30`. This establishes source identity; these stable/sysroot binaries differ from local Ohm and PGO binaries.

The distribution archive SHA-256 is `d7033afb5a01b88737c2e57500269f0078d9237af01455506e5343f46cba539e`. All 6,546 members were inspected; all 5,497 original regular members were rehashed after runtime checks. Source, tests and native binaries remain exact. Ordinary interpreter startup rewrote three existing encoding-module `.pyc` cache files; their before/after hashes are retained. The downloaded archive remains unchanged.

The pinned CentOS digest was already present, so no image was pulled. Both containers used networking disabled, CPU2 and read-only distribution/check mounts. Each owned container ID was cleaned up with exit 0. Initial sandbox access to the Docker socket was denied before any container executed; that complete failed prerequisite/controller receipt is preserved. Authorized access resumed only the two unexecuted container diagnostics. All five target commands retain their reviewed argument arrays and deadlines, with no timeout, target retry or source/test/workflow change.

The local identity and threaded-loading results supplement the CI steps that were skipped. They do not make the failed workflow, original glibc script or XML suites pass. No additional target execution is needed for this bounded follow-up.

## Evidence

`report.json` is the compact result schema. `method-outcomes.json` retains every verbose result. `runtime-audit.json` verifies exact planned commands, source and binary preservation, raw output hashes and cleanup. `preparation-index.json` preserves the reviewed preparation separately from later runtime results. `FOLLOWUP.md` and `followup-plan.json` are the unchanged pre-execution plan; their held status describes that earlier stage.

The compact handoff includes source snapshots, full workflow and validation logs, all local outputs, compiler/source/archive manifests, static ELF evidence and the retained operational failure. Compiled distribution files and their duplicate compressed/decompressed containers stay outside the compact package with exact hashes; the complete original download remains in the study directory.
