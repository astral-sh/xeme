from pathlib import Path
import hashlib, io, json, os, shutil, subprocess, tarfile, tempfile
W=Path('/home/dev-user/code/oss/oriole-end-frame-cells'); O=Path(__file__).parent
E=Path('/tmp/oriole-detached-end-frame-study'); C=Path('/tmp/oriole-ffi-family-cell-thinlto-study')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.sched_getaffinity(0)=={3}
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert base=='5f20adfb7b36b5e95f5cb9b18bc61a8e3fe3b780'
end=json.loads((E/'final-source.json').read_text());paths=end['source_sha256']
assert len(paths)==70 and sha(E/'final.patch')=='fdab377f5efc0f814cf1479c36e7934ec1b8315af2136943737e941c92727d57'
cellpatch=subprocess.check_output(['git','diff','89927e09a6a9f1576ee05e3cf757e2b4159d5d36','1a4cae6669cd267fa51e0e104c3eac84edb3437d','--','crates'],cwd=W)
(O/'cell.patch').write_bytes(cellpatch)
with tempfile.TemporaryDirectory(prefix='oriole-end-cell-commute-',dir='/tmp') as temp:
    root=Path(temp)
    for name,h in paths.items():
        src=Path(end['worktree'])/name;assert sha(src)==h
        dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
    subprocess.run(['git','apply',str(O/'cell.patch')],cwd=root,check=True)
    assert all(sha(root/name)==sha(W/name) for name in paths)
source={'worktree':str(W),'base':base,'source_sha256':{n:sha(W/n) for n in paths}}
(O/'source.json').write_text(json.dumps(source,indent=2)+'\n')
(O/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=W))
basefiles={n:hashlib.sha256(subprocess.check_output(['git','show',base+':'+n],cwd=W)).hexdigest() for n in paths}
(O/'base-source.json').write_text(json.dumps(basefiles,indent=2)+'\n')
with tarfile.open(O/'source.tar.gz','w:gz') as archive:
    for name in paths:
        data=(W/name).read_bytes(); info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        archive.addfile(info,io.BytesIO(data))
report={'status':'passed_source_composition','base':base,'source_manifest_sha256':sha(O/'source.json'),'source_archive_sha256':sha(O/'source.tar.gz'),'patch_sha256':sha(O/'candidate.patch'),'end_patch_sha256':sha(E/'final.patch'),'cell_patch_sha256':sha(O/'cell.patch'),'all_70_files_identical_in_both_orders':True,'changed_files':[n for n in paths if source['source_sha256'][n]!=basefiles[n]],'scope':'Exact independently reviewed End delta above published Cell PR114. No other prototype, source change, test or build in this controller.'}
(O/'composition.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
