"""Audit saved final C-only rebuild and measured artifact preservation."""
from pathlib import Path
import hashlib,io,json,os,re,shlex,tarfile
assert __debug__ and os.sched_getaffinity(0)=={4}
D=Path('/tmp/oriole-end-frame-cells-final-thinlto-study')
B=Path('/tmp/oriole-end-frame-cells-thinlto-study')
F=Path('/tmp/oriole-end-frame-cells-test-fix-study')
O=Path('/tmp/oriole-end-frame-cells-final-build-independent-review');O.mkdir(exist_ok=False)
tracked={};checks=[];sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p);data=p.read_bytes();assert tracked.setdefault(str(p),sha(data))==sha(data);return data
def j(p):return json.loads(read(p))
def ck(value,message):assert value,message;checks.append(message)
source=j(D/'source.json');oldsource=j(B/'source.json');report=j(D/'report.json');old=j(B/'report.json')
ck(sha(read(D/'source.json'))==report['source_manifest_sha256']==sha(read(F/'source.json'))=='344730269a59a8402d3e18e5eed170982d2c44acfe6fc3d869f2acc166f149df','final corrected source manifest')
ck(sha(read(B/'source.json'))=='e7eb4e525a8ae2e06889888aa4c855bc41ad830d08fd716296a1ccd0d4b9154f','unchanged original measured manifest')
ck(report['status']=='passed' and report['fresh_workspace_compiles']==3 and report['libraries_identical_to_measured'] and report['source_unchanged'] and report['original_unchanged'],'completed saved final build')
def source_archive(folder,manifest):
 raw=read(folder/'source.tar.gz');out={}
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:
  rows=t.getmembers();ck(len(rows)==70 and all(m.isfile() for m in rows),'70 regular source members '+str(folder))
  for m in rows:
   data=t.extractfile(m).read();ck(sha(data)==manifest['source_sha256'][m.name],'source archive member '+m.name);out[m.name]=data
 return out
a=source_archive(B,oldsource);b=source_archive(D,source)
ck(set(a)==set(b)==set(source['source_sha256']),'exact source path sets')
changed=[n for n in a if a[n]!=b[n]];ck(changed==['crates/oriole_expat/src/tests.rs'],'only cfg(test) module changed')
name=changed[0];before=a[name].decode();after=b[name].decode()
ck(before.replace('.store(MAX_FAMILY_CALLBACK_BYTES - remaining, Ordering::Relaxed);','.set(MAX_FAMILY_CALLBACK_BYTES - remaining);').replace('family.callback_bytes.load(Ordering::Relaxed)','family.callback_bytes.get()')==after,'exact two accessor substitutions')
ck(before.count('.store(MAX_FAMILY_CALLBACK_BYTES - remaining, Ordering::Relaxed);')==before.count('family.callback_bytes.load(Ordering::Relaxed)')==1,'exactly one setter and one getter replacement')
ck('#[cfg(test)]\nmod tests;' in b['crates/oriole_expat/src/lib.rs'].decode(),'changed module is cfg(test) only')
ck(read(D/'source.tar.gz')==read(F/'source.tar.gz') and read(D/'candidate.patch')==read(F/'candidate.patch'),'final build uses exact corrected source artifacts')
rows=j(D/'compiler-invocations.json');oldrows=j(B/'compiler-invocations.json');raw=read(D/'release.log').decode();parsed=[]
for line in raw.splitlines():
 if 'Running `' not in line or '/rustc ' not in line:continue
 args=shlex.split(line.strip()[len('Running `'):-1]);parsed.append({'crate':args[args.index('--crate-name')+1],'command_line':line,'codegen_options':[args[i+1] for i,x in enumerate(args[:-1]) if x=='-C'],'crate_types':[args[i+1] for i,x in enumerate(args[:-1]) if x=='--crate-type']})
ck(parsed==rows and len(rows)==3,'all three final compiler invocations reconstructed from raw log')
normalized={};direct_equal=True
for label,entries in [('control',oldrows),('candidate',rows)]:
 normalized[label]={}
 for crate in ['oriole_storage','oriole','oriole_expat']:
  selected=[r for r in entries if r['crate']==crate];ck(len(selected)==1,'one full workspace rustc invocation '+label+'/'+crate);r=selected[0]
  line=r['command_line'].replace(source['worktree'],'<WORKTREE>');line,count=re.subn(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}','<PRIVATE_BUILD>',line);ck(count>=3,'normalization limited to private paths');normalized[label][crate]=line
  ck(('lto=thin' if crate=='oriole_expat' else 'linker-plugin-lto') in r['codegen_options'],'effective ThinLTO '+label+'/'+crate)
  if crate=='oriole_expat':ck(r['crate_types']==['cdylib','staticlib'],'C-only final crate types '+label)
  if label=='candidate':direct_equal &= r['command_line']==next(x['command_line'] for x in oldrows if x['crate']==crate)
ck(normalized['control']==normalized['candidate'] and normalized==report['compiler_comparison']['normalized'],'actual compiler vectors identical after private paths')
ck(report['env_overrides']==old['env_overrides'],'all recorded environment overrides identical')
ck(report['rustc_version']==old['rustc_version']==read(D/'rustc-version.log').decode(),'same exact compiler version')
expected_command=['cargo','+ohm','-Zohm-defaults=no','rustc','--release','--locked','-p','oriole_expat','--lib','--crate-type','cdylib,staticlib','-vv']
ck([row['label'] for row in report['commands']]==['rustc-version','release'],'only version and release commands')
for row in report['commands']:
 ck(row['exit']==0 and row['affinity']==[3] and row['cwd']==source['worktree'] and row['end']>=row['start'] and row['end']-row['start']<row['timeout'],'bounded command completed '+row['label'])
 ck(sha(read(D/(row['label']+'.log')))==row['log_sha256'],'raw log hash '+row['label'])
 if row['label']=='release':ck(row['command']==expected_command,'exact C-only build invocation')
library_hashes={'liboriole_expat.so':'02fcab59f6e3818c128da6706d67987ae7450dd8b59e97cd28ce497a547f28f5','liboriole_expat.a':'69ebed414946cbaef1a940c052a636be277c809902943d676e824deab45d22d5'}
for name,digest in library_hashes.items():
 ck(sha(read(D/name))==sha(read(B/name))==report['libraries'][name]==old['libraries'][name]==digest,'entire final binary identical to measured '+name)
for path,digest in report['original_hashes'].items():ck(sha(read(path))==digest,'retained input unchanged '+path)
prior=Path('/tmp/oriole-end-frame-cells-build-source-independent-review')
ck(sha(read(prior/'review.json'))=='b9bbb961adf7ee32a671b4a649bc3bfac29ce62a8ca69d817ce63a6211323285','original independent build/source audit retained')
ledger=j(prior/'files.json');preserved=[]
for path,digest in ledger.items():
 if path.startswith(str(B)+'/') or path.startswith('/tmp/oriole-end-frame-cells-study/'):
  ck(sha(read(path))==digest,'original measured study unchanged since prior audit '+path);preserved.append(path)
handoff=Path('/tmp/oriole-end-frame-cells-measured-review-handoff')
ck(sha(read(handoff/'files.json'))=='7cb4c5ac4d1415a0aebcc9ce187c728b903d4b022bdd89a700bcb93b26f8ef5b','measured review handoff index unchanged')
for name,row in j(handoff/'files.json').items():ck(sha(read(handoff/name))==row['sha256'],'sealed measured handoff file unchanged '+name)
controller=read(D/'build.py').decode();oldcontroller=read(B/'build.py').decode()
ck('for n in source:os.utime(W/n,None)' in controller and 'start_new_session=True' in controller and 'os.killpg(p.pid,signal.SIGKILL)' in controller,'recorded controller forces source freshness and retains group cleanup')
ck('report[\'libraries_identical_to_measured\']' in controller,'new controller explicitly requires binary identity')
read(D/'build-controller.patch')
for path,digest in tracked.items():ck(sha(Path(path).read_bytes())==digest,'finish unchanged '+path)
for name in ['report.json','compiler-invocations.json','release.log','rustc-version.log','source.json','build.py','build-controller.patch']:(O/name).write_bytes(read(D/name))
(O/'checked-files.json').write_text(json.dumps(tracked,indent=2)+'\n');(O/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');(O/'audit.py').write_bytes(Path(__file__).read_bytes())
result={'status':'saved_final_rebuild_and_test_only_source_identity_passed','findings':[],'scope':'Read-only final saved build and frozen source comparison; no target executions. Commit blob equality will be attached separately; final normal workspace results remain outside this build audit.','measured_source_manifest_sha256':sha(read(B/'source.json')),'final_source_manifest_sha256':sha(read(D/'source.json')),'source_files':70,'changed_paths':changed,'all_other69_source_files_identical':True,'test_only_accessor_changes_preserve_assertions':True,'workspace_compiler_invocations':3,'actual_compiler_vectors_identical_after_private_paths':True,'actual_workspace_command_strings_identical_without_normalization':direct_equal,'recorded_environment_overrides_identical':True,'final_crate_types':['cdylib','staticlib'],'actual_final_lto':'thin','entire_final_libraries_byte_identical_to_measured':library_hashes,'original_study_artifacts_rechecked':preserved,'original_measured_review_handoff_unchanged':True,'limitations':['Actual same-binary identity supports applying existing02fc/69eb C-gate and timing measurements; their original source manifests are not relabeled.','The initial all-target workspace attempt failed in test compilation; corrected-source normal workspace success is a separate gate.','Recorded environment overrides and actual compiler vectors match; full inherited environment was not archived.','No additional parser, test, profiler, timing or compiler execution by reviewer.'],'checks':len(checks),'generator_sha256':sha(Path(__file__).read_bytes())}
(O/'build-review.json').write_text(json.dumps(result,indent=2)+'\n');print(sha((O/'build-review.json').read_bytes()))
