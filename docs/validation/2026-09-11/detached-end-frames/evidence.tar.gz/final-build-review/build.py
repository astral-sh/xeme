"""Build frozen End-frame plus Cell source with matched C-only ThinLTO on CPU3."""
from pathlib import Path
import hashlib,json,os,re,shlex,shutil,signal,subprocess,time
W=Path('/home/dev-user/code/oss/oriole-end-frame-cells'); O=Path(__file__).parent
S=Path('/tmp/oriole-end-frame-cells-test-fix-study'); B=Path('/tmp/oriole-end-frame-cells-thinlto-study')
assert __debug__ and os.sched_getaffinity(0)=={3}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
source=read(S/'source.json')['source_sha256']; assert len(source)==70
assert all(sha(W/n)==v for n,v in source.items())
for name in ['source.json','source.tar.gz','candidate.patch']:shutil.copyfile(S/name,O/name)
base=read(B/'report.json'); env_overrides=dict(base['env_overrides']);env_overrides['CARGO_TARGET_DIR']='/home/dev-user/.cache/oriole/end-frame-cells-target'
env=os.environ|env_overrides;assert not {k:v for k,v in env.items() if k.startswith('CARGO_PROFILE_')}
report={'status':'incomplete','source_manifest_sha256':sha(O/'source.json'),'env_overrides':env_overrides,'commands':[],'scope':'Fresh C-only ThinLTO compile of final344730 source after exactly two cfg(test) atomic-to-Cell accessor corrections. Require byte identity to measured e7eb-source02fc/69eb libraries and identical three compiler invocations; no parser or test executions here.'}
original={str(S/n):sha(S/n) for n in ['source.json','candidate.patch','source.tar.gz','report.json','test-only.patch']} | {str(B/n):sha(B/n) for n in ['source.json','report.json','liboriole_expat.so','liboriole_expat.a']}
def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,cmd,timeout=1200):
 row={'label':label,'command':cmd,'cwd':str(W),'affinity':[3],'start':time.time(),'timeout':timeout};report['commands'].append(row);save();p=None
 with (O/(label+'.log')).open('wb') as log:
  try:
   p=subprocess.Popen(cmd,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);row['exit']=p.wait(timeout=timeout)
   if row['exit']:raise RuntimeError(label+' nonzero')
  except BaseException as e:
   row['exception']=repr(e)
   if p is not None:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    row['exit']=p.wait()
   raise
  finally:
   log.flush();row['end']=time.time();row['log_sha256']=sha(O/(label+'.log'));save()
 print(label,row['exit'],flush=True);return (O/(label+'.log')).read_text()
try:
 report['rustc_version']=run('rustc-version',['rustc','+ohm','-vV'],30);assert report['rustc_version']==base['rustc_version']
 for n in source:os.utime(W/n,None)
 cmd=['cargo','+ohm','-Zohm-defaults=no','rustc','--release','--locked','-p','oriole_expat','--lib','--crate-type','cdylib,staticlib','-vv']
 text=run('release',cmd)
 lines=[x for x in text.splitlines() if 'Running `' in x and '/rustc ' in x]
 rows=[]
 for line in lines:
  args=shlex.split(line.strip()[len('Running `'):-1]); crate=args[args.index('--crate-name')+1]
  codegen=[args[i+1] for i,x in enumerate(args[:-1]) if x=='-C']; rows.append({'crate':crate,'command_line':line,'codegen_options':codegen,'crate_types':[args[i+1] for i,x in enumerate(args[:-1]) if x=='--crate-type']})
 for crate in ['oriole_storage','oriole','oriole_expat']:assert len([r for r in rows if r['crate']==crate])==1
 final=next(r for r in rows if r['crate']=='oriole_expat');assert final['crate_types']==['cdylib','staticlib'] and 'lto=thin' in final['codegen_options']
 (O/'compiler-invocations.json').write_text(json.dumps(rows,indent=2)+'\n')
 oldrows=read(B/'compiler-invocations.json'); normalized={}
 for label,rs,work in [('control',oldrows,'/home/dev-user/code/oss/oriole-end-frame-cells'),('candidate',rows,str(W))]:
  normalized[label]={}
  for crate in ['oriole_storage','oriole','oriole_expat']:
   line=next(r['command_line'] for r in rs if r['crate']==crate).replace(work,'<WORKTREE>')
   line,n=re.subn(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}','<PRIVATE_BUILD>',line);assert n>=3
   normalized[label][crate]=line
 assert normalized['control']==normalized['candidate'],normalized
 report['compiler_comparison']={'matched_after_private_paths_only':True,'normalized':normalized}
 report['libraries']={}
 for n in ['liboriole_expat.so','liboriole_expat.a']:
  shutil.copyfile(Path(env_overrides['CARGO_TARGET_DIR'])/'release'/n,O/n);report['libraries'][n]=sha(O/n)
 report['fresh_workspace_compiles']=3; report['libraries_identical_to_measured']=all(sha(O/n)==sha(B/n) for n in report['libraries']); assert report['libraries_identical_to_measured']; report['status']='passed'
finally:
 report['source_unchanged']=all(sha(W/n)==v for n,v in source.items());report['original_hashes']=original;report['original_unchanged']=all(sha(p)==v for p,v in original.items());save()
assert report['source_unchanged'] and report['original_unchanged'];print(json.dumps({'status':report['status'],'libraries':report.get('libraries')}),flush=True)
