"""Final commit/source audit only: Git reads, hashes, tar readback. No target runs."""
from pathlib import Path
import difflib,hashlib,io,json,os,subprocess,tarfile,time
assert os.sched_getaffinity(0)=={4}
O=Path(__file__).resolve().parent
W=Path('/home/dev-user/code/oss/oriole-end-frame-cells')
COMMIT='1ff7b64e4567484f42bcc974146110648c224dd3'
OLD='e7eb4e525a8ae2e06889888aa4c855bc41ad830d08fd716296a1ccd0d4b9154f'
NEW='344730269a59a8402d3e18e5eed170982d2c44acfe6fc3d869f2acc166f149df'
OLD_ARCHIVE='d67343a119b23efcf99e020e2554becd72882c465e6475f2c4c36c3473b53841'
NEW_ARCHIVE='6199967d9a89339c10dd6abae569892e2bf28ca3ea2001223454f4bf07ccb5d6'
sha=lambda b:hashlib.sha256(b).hexdigest()
checked={};commands=[]
def read(p,expected=None):
    p=Path(p);b=p.read_bytes();h=sha(b)
    if expected:assert h==expected,(str(p),h,expected)
    assert checked.setdefault(str(p),{'sha256':h,'bytes':len(b)})=={'sha256':h,'bytes':len(b)}
    return b
def js(p,expected=None):return json.loads(read(p,expected))
def put(name,obj):(O/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def git(label,*args,stdin=None):
    cmd=['git','-C',str(W),*args]
    row={'label':label,'command':cmd,'timeout_seconds':30,'affinity':[4]}
    if stdin is not None:
        (O/(label+'.stdin')).write_bytes(stdin);row['stdin_sha256']=sha(stdin)
    commands.append(row)
    try:
        result=subprocess.run(cmd,input=stdin,capture_output=True,timeout=30)
        for stream in ['stdout','stderr']:
            b=getattr(result,stream);(O/(label+'.'+stream)).write_bytes(b);row[stream+'_sha256']=sha(b)
        row['exit']=result.returncode
        assert result.returncode==0,(label,result.stderr)
        return result.stdout
    finally:put('commands.json',commands)

assert git('git-context','rev-parse','HEAD','--show-toplevel','--git-common-dir').decode().splitlines()==[COMMIT,str(W),'/home/dev-user/code/oss/oriole/.git']
commit_record=git('commit-record','show','--no-patch','--format=fuller',COMMIT).decode()
git_status=git('git-status','status','--porcelain=v1').decode()
assert git_status==''
archives={};manifests={}
for label,stem,value,archive_hash in [
    ('initial','oriole-end-frame-cells-study',OLD,OLD_ARCHIVE),
    ('measured','oriole-end-frame-cells-thinlto-study',OLD,OLD_ARCHIVE),
    ('test_fix','oriole-end-frame-cells-test-fix-study',NEW,NEW_ARCHIVE),
    ('final','oriole-end-frame-cells-final-thinlto-study',NEW,NEW_ARCHIVE),
]:
    base=Path('/tmp')/stem
    manifest=js(base/'source.json',value);manifests[label]=manifest
    expected=manifest['source_sha256'];assert len(expected)==70
    raw=read(base/'source.tar.gz',archive_hash)
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
        members=tar.getmembers();assert len(members)==70
        names=[m.name for m in members]
        assert len(set(names))==70 and set(names)==set(expected)
        assert all(m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
        contents={m.name:tar.extractfile(m).read() for m in members}
    assert {p:sha(b) for p,b in contents.items()}==expected
    archives[label]=contents
assert archives['initial']==archives['measured']
assert archives['test_fix']==archives['final']
paths=sorted(archives['final'])
tree=git('source-tree','ls-tree','-r','-z',COMMIT,'--',*paths)
objects={}
for row in tree.split(b'\0'):
    if not row:continue
    meta,path=row.split(b'\t',1);mode,kind,obj=meta.split()
    assert kind==b'blob' and mode==b'100644'
    objects[path.decode()]=obj.decode()
assert set(objects)==set(paths)
blobout=git('committed-source-blobs','cat-file','--batch',stdin=('\n'.join(objects[p] for p in paths)+'\n').encode())
offset=0;proof={}
for p in paths:
    end=blobout.index(b'\n',offset);header=blobout[offset:end].decode().split();offset=end+1
    oid,kind,size=header;assert oid==objects[p] and kind=='blob';size=int(size)
    b=blobout[offset:offset+size];offset+=size
    assert blobout[offset:offset+1]==b'\n';offset+=1
    assert b==archives['final'][p]==read(W/p)
    proof[p]={'git_blob':oid,'sha256':sha(b),'bytes':size,'committed_equals_archive_equals_live':True}
assert offset==len(blobout)
changed=[p for p in paths if archives['initial'][p]!=archives['final'][p]]
TEST='crates/oriole_expat/src/tests.rs'
assert changed==[TEST]
before=archives['initial'][TEST].decode();after=archives['final'][TEST].decode()
old_store='.store(MAX_FAMILY_CALLBACK_BYTES - remaining, Ordering::Relaxed);'
new_store='.set(MAX_FAMILY_CALLBACK_BYTES - remaining);'
old_load='family.callback_bytes.load(Ordering::Relaxed)'
new_load='family.callback_bytes.get()'
assert before.count(old_store)==before.count(old_load)==1
assert before.replace(old_store,new_store).replace(old_load,new_load)==after
diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+TEST,tofile='b/'+TEST))
assert diff.encode()==read('/tmp/oriole-end-frame-cells-test-fix-study/test-only.patch','1008764ceb0c8eb5c77aab076d80d47fb1278f086471a938aac2dc9a46062ba7')
(O/'independent-test-only.patch').write_text(diff)
lib=archives['final']['crates/oriole_expat/src/lib.rs'].decode()
assert '#[cfg(test)]\nmod tests;' in lib
assert lib.count('mod tests;')==1
name='detached_end_charges_the_name_before_handlers_or_default_fallback'
test_start=before.index('fn '+name+'(');test_end=before.index('\n#[test]',test_start)
assert all(test_start<before.index(x)<test_end for x in [old_store,old_load])
assert before.count('assert')==after.count('assert')

# Preserve earlier measured sources and receipt bytes. Their findings are not rerun here.
prior_reviews={
 '/tmp/oriole-end-frame-cells-build-source-independent-review/review.json':'b9bbb961adf7ee32a671b4a649bc3bfac29ce62a8ca69d817ce63a6211323285',
 '/tmp/oriole-end-frame-cells-native-independent-review/review.json':'2cf054a43b284619ea3e23d07de312090ee9d571b49bb1dfdd8d0b61060e4290',
 '/tmp/oriole-end-frame-cells-profile-independent-review/review.json':'c012186a4cf972f9a8b20127d579d1051d2d11cd1a477adbaabca841aaf4f7cd',
 '/tmp/oriole-end-frame-cells-codegen-independent-review/review.json':'2e6f4cac94fdec5f87c29ffdd5afc1a2b3706a2ed58dcb058455212fb8d01be8',
 '/tmp/oriole-end-frame-cells-python-independent-review/review.json':'a98011efa544ca434f2435240caa09793a55a79bed25377fa03778251e284235',
}
for p,h in prior_reviews.items():read(p,h)
testfix=js('/tmp/oriole-end-frame-cells-test-fix-independent-review/review.json')
assert checked['/tmp/oriole-end-frame-cells-test-fix-independent-review/review.json']['sha256'].startswith('d054')
assert testfix['old_measured_source']==OLD and testfix['corrected_test_source']==NEW
initial_preservation=js('/tmp/oriole-end-frame-cells-test-fix-independent-review/files.json')
for p,h in initial_preservation.items():read(p,h)
receipt_checks={}
for p,h in [
 ('/tmp/oriole-end-frame-cells-native-independent-review/receipt.json','b645888583eed87a846e43ab3c585c2b8037aad104f9308f3f2acee9c47a968d'),
 ('/tmp/oriole-end-frame-cells-codegen-independent-review/receipt.json','ec30de60515939b1687a9f45184817024fa40f074a2266ca70a4a4fdce0fbeb1'),
 ('/tmp/oriole-end-frame-cells-python-independent-review/receipt.json','64d67c120953dd2aff3645815e95b998aee9871361ede9875acba3e158eabcf1'),
]:
    receipt=js(p,h)
    for rel,record in receipt['files'].items():read(Path(p).parent/rel,record['sha256'])
    receipt_checks[p]=len(receipt['files'])
assert git('final-head','rev-parse','HEAD').decode().strip()==COMMIT
assert all(sha(Path(p).read_bytes())==v['sha256'] for p,v in checked.items())
put('source-proof.json',proof)
put('checked-files.json',checked)
review={'status':'independent_final_committed_source_audit_passed','commit':COMMIT,'worktree':str(W),'git_common_dir':'/home/dev-user/code/oss/oriole/.git',
 'source_files':70,'git_blobs_equal_final_archive_manifest_and_live':True,'source_manifests':{'initial_measured':OLD,'final_test_corrected':NEW},
 'source_archives':{'initial_measured':OLD_ARCHIVE,'final_test_corrected':NEW_ARCHIVE},
 'all_four_archives_read_back':True,'changed_from_measured':[TEST],'other69_source_files_identical':True,
 'exact_replacements':[{'before':old_store,'after':new_store},{'before':old_load,'after':new_load}],
 'assertions_fixtures_and_numeric_budgets_unchanged':True,'cfg_test_module_only':True,'test_name':name,
 'preserved_prior_reviews':prior_reviews,'fully_rehashed_prior_receipts':receipt_checks,'initial_failure_receipt':testfix['initial_attempt'],
 'checked_files':len(checked),'all_checked_bytes_unchanged':True,'read_only_git_commands':len(commands),
 'scope':'CPU4 read-only committed blobs, four source archives, manifests and prior frozen receipts. No compiler/build/parser/test/profile/timing execution.',
 'limits':['This is source identity and test-only delta evidence, not a successful workspace result. The initial failed compile executed zero all-target tests and remains a failure.','Final three-compile extraction and output-library equivalence are parent-owned separate checks; no binary equality inferred from cfg(test) alone.','Only the 70-file frozen source selection is certified; no claim about every non-source repository document. Earlier e7eb measurements and reviews retain their original identities.'],
 'generator_sha256':sha(Path(__file__).read_bytes())}
put('review.json',review)
print(json.dumps({'status':review['status'],'review_sha256':sha((O/'review.json').read_bytes()),'files':len(checked),'source_files':70,'changed':changed},indent=2))
