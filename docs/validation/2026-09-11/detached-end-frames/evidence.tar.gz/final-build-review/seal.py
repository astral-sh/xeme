"""Seal distinct final-source/build supplement; no target execution."""
from pathlib import Path
import hashlib,json,os,shutil
assert __debug__ and os.sched_getaffinity(0)=={4}
O=Path(__file__).parent;C=Path('/tmp/oriole-end-frame-cells-final-commit-independent-review')
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
assert h(O/'build-review.json')=='2cd3a53dbc8b12afadd91cdad52f88de87339b25017363c2f9088f75122da910'
assert h(C/'review.json')=='a13a1bddddd57793381ea2492c19118246c2606eff3943356fe4408ed93909f9'
assert not (O/'commit-review').exists();shutil.copytree(C,O/'commit-review')
for path in C.rglob('*'):
 if path.is_file():assert h(path)==h(O/'commit-review'/path.relative_to(C))
b=j(O/'build-review.json')
review={'status':'final_test_only_source_commit_and_identical_C_libraries_verified','findings':[],'runtime_commit':'1ff7b64e4567484f42bcc974146110648c224dd3','measured_source_manifest_sha256':b['measured_source_manifest_sha256'],'final_source_manifest_sha256':b['final_source_manifest_sha256'],'committed_source_files':70,'all_committed_blobs_equal_final_archive_manifest_and_live_files':True,'source_change_from_measured':{'path':'crates/oriole_expat/src/tests.rs','changes':['store(value, Ordering::Relaxed) to set(value)','load(Ordering::Relaxed) to get()'],'cfg_test_only':True,'assertions_unchanged':True,'other69_files_identical':True},'fresh_workspace_compiler_invocations':3,'actual_compiler_vectors_equal_without_normalization':b['actual_workspace_command_strings_identical_without_normalization'],'recorded_environment_overrides_identical':True,'final_crate_types':['cdylib','staticlib'],'actual_final_lto':'thin','entire_final_libraries_identical_to_measured':b['entire_final_libraries_byte_identical_to_measured'],'original_e7eb_artifacts_and_review_handoff_unchanged':True,'build_review_sha256':h(O/'build-review.json'),'commit_review_sha256':h(O/'commit-review/review.json'),'scope':'Distinct supplement linking corrected cfg(test) source344730/commit1ff7b64 to whole-byte-identical measured02fc/69eb libraries. Original e7eb measurements and reviews remain immutable; no reviewer compiler, parser or test execution.','limitations':['Successful final normal workspace checks are separate and not certified by this supplement.','Original workspace attempt failed test/Clippy compilation before any all-target execution; original failures and logs remain retained.','Same binary identity supports reuse of existing C-only behavior/timing evidence; their source manifests are not rewritten.','Complete compiler vectors and recorded override environment match; no full inherited-environment capture is claimed.']}
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n')
manifest={str(p.relative_to(O)):{'sha256':h(p),'size':p.stat().st_size} for p in sorted(O.rglob('*')) if p.is_file() and p.name!='files.json' and '__pycache__' not in p.parts}
# Preserve any nested files.json as evidence; omit only this outer index.
for p in sorted((O/'commit-review').rglob('files.json')):
 manifest[str(p.relative_to(O))]={'sha256':h(p),'size':p.stat().st_size}
(O/'files.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(h(O/name)==row['sha256'] and (O/name).stat().st_size==row['size'] for name,row in manifest.items())
print(json.dumps({'review_sha256':h(O/'review.json'),'files_sha256':h(O/'files.json'),'indexed_files':len(manifest)}))
