# Detached End frames with Cell family counters: C-only ThinLTO gates

This package tests the frozen combined source `e7eb4e52` (70 files), using shared library `02fcab59` and static library `69ebed41`. The control is the selected Cell implementation, shared `0cfd6108` and static `c86ad85e`. Both use the C-only ThinLTO build. The independently reconstructed compiler vectors match after private paths; applying the frozen End and Cell patches in either order produces all 70 measured source files. Source/build review is retained separately at `/tmp/oriole-end-frame-cells-build-source-independent-review`.

All original 4,740 Expat API rows match the control byte for byte: **4,347 pass and 393 fail**, with the original raw exit 1. Bounds remain 3 seconds per case, 1 GiB address space, 768 MiB RSS, and 240 seconds total. No test name, assertion, allocation ceiling or resource limit changed.

Six native C runs cover three consumers under both shared and static linkage, including **327 original selected-allocation scenarios per linkage**. All six runs pass. ASan and UBSan instrument the C consumers; the Rust ThinLTO release libraries are uninstrumented, and leak checking is disabled.

The remaining original controls match the selected Cell baseline:

- 3,318 strict differential traces.
- 36,456 custom-alias comparisons.
- 2,392 malformed-input paired observations.
- 1,304 publication cases, comprising 3,912 parser executions.
- 38 End lifecycle cases, comprising 114 parser executions.
- Six supplemental End allocation scenarios, with 37 rows per engine, four forced failures, two successful controls, and zero live allocations after cleanup.

The publication evidence retains 10,416 Default and 864 external callback-position differences from Expat. All 38 lifecycle cases retain their existing Expat differences. Baseline equality and reference equivalence are separate claims. Successful custom-alias full trace pairs are checked by the unchanged harness but are not archived; their scripts, commands, counts, identities, exit statuses and difference summaries are retained. Full malformed, publication and lifecycle paired observations are archived.

The historical `end-lifecycle/SOURCE_REVIEW.md` records prior fixture provenance; it does not describe the new detached End eligibility rules or constitute a new implementation review. The six supplemental allocation scenarios retain their namespace-restoration scope and do not prove allocation coverage of every detached End fast path. They remain separate from the original 327 scenarios.

The root reviewed the adapted controllers before execution. Both gate lanes ran sequentially on CPU 4, with no parser rerun or failed launch. The original API failures and all reference differences remain in the raw evidence. Normal workspace, strict CPython and elapsed studies are owned separately; this package makes no speed claim and does not transfer normal-workspace results to the C-only libraries.
