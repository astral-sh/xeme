"""Preserve the selected closing-tag runtime, measured and corrected sources, full gates and experiments."""
from pathlib import Path
import hashlib
import io
import json
import shutil
import statistics
import subprocess
import tarfile

REPO = Path('/home/dev-user/code/oss/oriole-end-frame-cells')
OUT = REPO / 'docs/validation/2026-09-11/detached-end-frames'
BENCH = REPO / 'benchmarks/results/2026-09-11/detached-end-frames'
SHA = lambda data: hashlib.sha256(data).hexdigest()
READ = lambda path: json.loads(Path(path).read_text())
DIRECTORIES = {'composition': '/tmp/oriole-end-frame-cells-study', 'measured-build-profile': '/tmp/oriole-end-frame-cells-thinlto-study', 'initial-workspace-failure': '/tmp/oriole-end-frame-cells-workspace-gates', 'corrected-source': '/tmp/oriole-end-frame-cells-test-fix-study', 'final-build': '/tmp/oriole-end-frame-cells-final-thinlto-study', 'final-build-review': '/tmp/oriole-end-frame-cells-final-build-independent-review', 'workspace': '/tmp/oriole-end-frame-cells-workspace-final-gates', 'gates': '/tmp/oriole-end-frame-cells-thinlto-gates-handoff', 'native': '/tmp/oriole-end-frame-cells-thinlto-timing-study', 'python': '/tmp/oriole-end-frame-cells-thinlto-python-study', 'cpython': '/tmp/oriole-end-frame-cells-thinlto-cpython-gates', 'reviews': '/tmp/oriole-end-frame-cells-measured-review-handoff', 'standalone-source-review': '/tmp/oriole-detached-end-frame-root-review', 'standalone-build-profile': '/tmp/oriole-detached-end-frame-production-handoff', 'standalone-native': '/tmp/oriole-detached-end-frame-production-timing-study', 'standalone-python': '/tmp/oriole-detached-end-frame-production-python-study', 'standalone-native-review': '/tmp/oriole-detached-end-native-independent-review', 'standalone-python-review': '/tmp/oriole-detached-end-python-independent-review'}
CONTROLLERS = ['/tmp/oriole-package-detached-end-frames.py', '/tmp/oriole-summarize-cohorts.py', '/tmp/oriole-prepare-end-frame-cells-thinlto-timing.py', '/tmp/oriole-time-end-frame-cells-thinlto-native.py', '/tmp/oriole-prepare-end-frame-cells-thinlto-python.py', '/tmp/oriole-time-end-frame-cells-thinlto-python.py', '/tmp/oriole-end-frame-cells-thinlto-cpython-gates.py', '/tmp/oriole-review-detached-end-root.py']
COPIES = {'build.json': '/tmp/oriole-end-frame-cells-final-thinlto-study/report.json', 'source.json': '/tmp/oriole-end-frame-cells-final-thinlto-study/source.json', 'measured-build.json': '/tmp/oriole-end-frame-cells-thinlto-study/report.json', 'measured-source.json': '/tmp/oriole-end-frame-cells-thinlto-study/source.json', 'workspace.json': '/tmp/oriole-end-frame-cells-workspace-final-gates/summary.json', 'gates.json': '/tmp/oriole-end-frame-cells-thinlto-gates/summary.json', 'native-summary.json': '/tmp/oriole-end-frame-cells-thinlto-timing-study/summary.json', 'python-summary.json': '/tmp/oriole-end-frame-cells-thinlto-python-study/summary.json', 'source-review.json': '/tmp/oriole-detached-end-frame-root-review/review.json', 'final-build-review.json': '/tmp/oriole-end-frame-cells-final-build-independent-review/review.json', 'build-profile-review.json': '/tmp/oriole-end-frame-cells-build-source-independent-review/review.json', 'gates-review.json': '/tmp/oriole-end-cell-gates-independent-review/final-review.json', 'native-review.json': '/tmp/oriole-end-frame-cells-native-independent-review/review.json', 'python-review.json': '/tmp/oriole-end-frame-cells-python-independent-review/review.json', 'cpython-review.json': '/tmp/oriole-end-frame-cells-thinlto-cpython-independent-review/review.json'}

assert READ(COPIES['build.json'])['status'] == 'passed'
gates = READ(COPIES['gates.json'])
assert gates['status'] == 'correctness_parity_gates_passed'
assert gates['api']['all4740rows_exact']
assert (gates['api']['passed'], gates['api']['failed']) == (4347, 393)
workspace = READ(COPIES['workspace.json'])
assert (workspace['all_target_binaries'], workspace['all_target_tests_passed'], workspace['doc_tests_passed']) == (33, 407, 1)
source = READ(COPIES['source.json'])
assert len(source['source_sha256']) == 70
assert all(SHA((REPO / p).read_bytes()) == h for p,h in source['source_sha256'].items())
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD^'], cwd=REPO, text=True).strip()
assert head.startswith('1ff7b64') and parent == '5f20adfb7b36b5e95f5cb9b18bc61a8e3fe3b780'
patch = subprocess.check_output(['git', 'diff', 'HEAD^', 'HEAD', '--binary'], cwd=REPO)
assert patch == Path('/tmp/oriole-end-frame-cells-test-fix-study/candidate.patch').read_bytes()
assert READ(COPIES['build.json'])['libraries_identical_to_measured']
assert READ(COPIES['build.json'])['libraries'] == READ(COPIES['measured-build.json'])['libraries']
measured = READ(COPIES['measured-source.json'])
delta = [p for p,h in measured['source_sha256'].items() if source['source_sha256'][p] != h]
assert delta == ['crates/oriole_expat/src/tests.rs']
assembly = {'runtime_commit': head, 'parent_commit': parent,
            'measured_source_manifest_sha256': SHA(Path(COPIES['measured-source.json']).read_bytes()),
            'final_source_manifest_sha256': SHA(Path(COPIES['source.json']).read_bytes()),
            'source_files': len(source['source_sha256']), 'test_only_delta': delta,
            'final_patch_sha256': SHA(patch), 'committed_patch_exact': True,
            'final_libraries_byte_identical_to_measured': True,
            'assembled_source_sha256': {p: SHA((REPO / p).read_bytes()) for p in source['source_sha256']}}
for p in [*CONTROLLERS, *COPIES.values()]:
    assert Path(p).is_file(), p
paths = {}
for prefix, directory in DIRECTORIES.items():
    root = Path(directory)
    assert root.is_dir(), root
    for p in sorted(root.rglob('*')):
        if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:
            paths[prefix + '/' + str(p.relative_to(root))] = p
for p in CONTROLLERS:
    paths['controllers/' + Path(p).name] = Path(p)
OUT.mkdir(parents=True, exist_ok=False)
BENCH.mkdir(parents=True, exist_ok=False)
members, excluded = [], []
with tarfile.open(OUT / 'evidence.tar.gz', 'w:gz', compresslevel=9) as archive:
    for name, p in sorted(paths.items()):
        data = p.read_bytes()
        entry = {'path': name, 'source': str(p), 'bytes': len(data), 'sha256': SHA(data)}
        if data.startswith((b'\x7fELF', b'!<arch>\n')):
            excluded.append(entry)
            continue
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        archive.addfile(info, io.BytesIO(data))
        members.append(entry)
with tarfile.open(OUT / 'evidence.tar.gz', 'r:gz') as archive:
    actual = archive.getmembers()
    assert len(actual) == len(members)
    for member, entry in zip(actual, members):
        assert member.isfile() and member.name == entry['path'] and member.size == entry['bytes']
        assert SHA(archive.extractfile(member).read()) == entry['sha256'] == SHA(Path(entry['source']).read_bytes())
for entry in excluded:
    assert SHA(Path(entry['source']).read_bytes()) == entry['sha256']
(OUT / 'archive-members.json').write_text(json.dumps({'members': members, 'excluded_binaries': excluded}, indent=2) + '\n')
(OUT / 'assembly.json').write_text(json.dumps(assembly, indent=2) + '\n')
for name, p in COPIES.items():
    shutil.copy2(p, OUT / name)
summary = {
    'runtime_commit': head,
    'source_assembly': assembly,
    'libraries': gates['libraries'],
    'workspace': workspace,
    'api': gates['api'],
    'cpython_each_linkage': {'tests': 802, 'failures': 2, 'reported_skips': 14, 'expected_failures': 3},
    'native': READ(OUT / 'native-summary.json'),
    'python': READ(OUT / 'python-summary.json'),
    'archive': {'sha256': SHA((OUT / 'evidence.tar.gz').read_bytes()), 'members': len(members),
                'direct_binary_exclusions': len(excluded), 'bytes': (OUT / 'evidence.tar.gz').stat().st_size,
                'raw_bytes': sum(m['bytes'] for m in members), 'member_and_origin_readback': True},
    'scope': 'Matched C-only ThinLTO Cell0cfd control and End+Cell02fc candidate, both without PGO. Runtime commit final344730 corrects exactly two test-only accessors from initial e7eb source; fresh three-crate compile produces byte-identical C libraries. Initial workspace compile failures preserved, successful normal workspace gates separate from C-only tests. StandaloneEnd/a55 evidence has its own earlier source/build/timing scope. No new full PBS distribution or sustained Rust sanitizer fuzz claim.',
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
n = READ('/tmp/oriole-end-frame-cells-thinlto-timing-study/native-screen/results.json')
labels = {'vulkan': 'Vulkan registry', 'wayland': 'Wayland protocol', 'maven': 'Maven POM',
          'batik': 'Batik SVG', 'gtk': 'GTK UI', 'docbook': 'DocBook XSL'}
lines = []
for name, label in labels.items():
    row = next(r for r in n['summary'] if r['condition']['name'] == name and r['condition']['chunk'] == 4096 and not r['condition']['namespaces'])
    samples = [r for r in n['rows'] if r['condition'] == row['condition']]
    times = {e: statistics.median(next(p['median_seconds'] for p in r['processes'] if p['engine'] == e) for r in samples) * 1000 for e in ['candidate', 'expat']}
    lines.append(f"| {label} | {times['candidate']:.3f} ms | {times['expat']:.3f} ms | {row['median_ratios']['candidate_over_expat']:.2f}× |")
(OUT / 'table.md').write_text('\n'.join(lines) + '\n')
(OUT / 'native-wins.json').write_text(json.dumps([{'condition': r['condition'], 'ratio': r['median_ratios']['candidate_over_expat']} for r in n['summary'] if r['median_ratios']['candidate_over_expat'] < 1], indent=2) + '\n')
print(json.dumps({'runtime': head, 'archive': summary['archive'], 'table': lines}, indent=2))

# Preserve complete unselected experiments separately without duplicating their archive.
negative = OUT / 'unselected-names'
shutil.copytree('/tmp/oriole-name-experiments-handoff', negative)
for p in negative.iterdir():
    assert p.is_file() and SHA(p.read_bytes()) == SHA((Path('/tmp/oriole-name-experiments-handoff') / p.name).read_bytes())
