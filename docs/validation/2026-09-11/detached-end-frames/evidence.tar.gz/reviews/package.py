"""Seal the completed reviews of measured End+Cell; no target execution."""
from pathlib import Path
import hashlib,io,json,os,tarfile
assert __debug__ and os.sched_getaffinity(0)=={4}
O=Path('/tmp/oriole-end-frame-cells-measured-review-handoff');O.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
groups={
 'source-build':('/tmp/oriole-end-frame-cells-build-source-independent-review','review.json','b9bbb961adf7ee32a671b4a649bc3bfac29ce62a8ca69d817ce63a6211323285'),
 'profile':('/tmp/oriole-end-frame-cells-profile-independent-review','review.json','c012186a4cf972f9a8b20127d579d1051d2d11cd1a477adbaabca841aaf4f7cd'),
 'native':('/tmp/oriole-end-frame-cells-native-independent-review','review.json','2cf054a43b284619ea3e23d07de312090ee9d571b49bb1dfdd8d0b61060e4290'),
 'python':('/tmp/oriole-end-frame-cells-python-independent-review','review.json','a98011efa544ca434f2435240caa09793a55a79bed25377fa03778251e284235'),
 'strict-cpython':('/tmp/oriole-end-frame-cells-thinlto-cpython-independent-review','review.json','f88a2b9542ec9c3df55b67a424c5104c0342622f46c75d5431c8a9c9073b8f65'),
 'entity-dynamic':('/tmp/oriole-end-frame-cells-entity-attribution','report.json','4cf0ed741fc0e124bfd76bf3ac06f648962e9164893239fea3b7f7be61d9d48b'),
 'codegen':('/tmp/oriole-end-frame-cells-codegen-independent-review','review.json','2e6f4cac94fdec5f87c29ffdd5afc1a2b3706a2ed58dcb058455212fb8d01be8'),
 'c-gates':('/tmp/oriole-end-cell-gates-independent-review','final-review.json','825c76f5958e342d3933ac98e5cfa6d5d0499138279203c5957e33c7a800ad58'),
 'controller-root':('/tmp/oriole-end-frame-cells-cgate-controller-root-review','review.json','351d03fd75c956f900cfb662d8f12bae35564b27de29461acd49bc9c486e9fa0'),
 'test-fix-source':('/tmp/oriole-end-frame-cells-test-fix-independent-review','review.json','d054e904279132b1e63f317c0825dea88d760258f0a64a0b48860ac8d8f55079'),
}
members={};contents={}
for label,(directory,review,digest) in groups.items():
 root=Path(directory);assert sha((root/review).read_bytes())==digest
 for path in sorted(root.rglob('*')):
  if not path.is_file() or '__pycache__' in path.parts:continue
  assert not path.is_symlink()
  name=label+'/'+str(path.relative_to(root));raw=path.read_bytes();assert name not in members
  members[name]={'origin':str(path),'sha256':sha(raw),'size':len(raw)};contents[name]=raw
with tarfile.open(O/'reviews.tar.gz','w:gz') as archive:
 for name,raw in contents.items():
  info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(raw))
with tarfile.open(O/'reviews.tar.gz') as archive:
 rows=archive.getmembers();assert len(rows)==len(members) and len({m.name for m in rows})==len(rows)
 for m in rows:
  assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
  raw=archive.extractfile(m).read();assert len(raw)==members[m.name]['size'] and sha(raw)==members[m.name]['sha256']
for row in members.values():assert sha(Path(row['origin']).read_bytes())==row['sha256']
write=lambda name,value:(O/name).write_text(json.dumps(value,indent=2)+'\n')
write('archive-members.json',members)
summary={'status':'completed_measured_artifact_reviews_sealed','scope':'Independent reviews of measured End+Cell source e7eb and identical02fc/69eb frozen libraries. A later test-only source correction344730 is separately reviewed here, but its fresh release identity and successful normal workspace checks are not claimed by this handoff.','measured_source_manifest':'e7eb4e525a8ae2e06889888aa4c855bc41ad830d08fd716296a1ccd0d4b9154f','measured_libraries':{'shared':'02fcab59f6e3818c128da6706d67987ae7450dd8b59e97cd28ce497a547f28f5','static':'69ebed414946cbaef1a940c052a636be277c809902943d676e824deab45d22d5'},'reviews':{label:{'path':label+'/'+row[1],'sha256':row[2]} for label,row in groups.items()},'native':{'real_ratio_vs_Cell':0.9597606278511964,'real_lower':20,'real_conditions':24,'generated_ratio_vs_Cell':1.0247364564532082,'generated_lower':1,'generated_conditions':4,'total_regressions':7},'python':{'ratio_vs_Cell':0.9790356449237602,'lower':22,'conditions':24,'regressions':2,'ratio_vs_Expat':1.2885190467903072,'wins_against_Expat':3},'C_gates':{'canonical_API':[4347,393],'API_rows':4740,'native_C_runs':6,'original_allocation_scenarios_per_linkage':327,'strict':3318,'custom_alias':36456,'malformed':2392,'publication_cases':1304,'publication_parses':3912,'End_lifecycle_cases':38,'End_lifecycle_parses':114,'End_allocation_scenarios':6},'strict_CPython':{'methods_per_linkage':802,'failures_per_linkage':2,'raw_exit_per_linkage':2,'reported_skips':14,'expected_failures':3,'scope':'Parity with existing failures; not a green suite.'},'limits':['All adverse generated/native/Python results remain; no blanket faster-than-Expat claim or adoption decision.','Normal workspace initial attempt failed compilation in test-only Cell.load/store usage before any all-target tests ran; doc1 and fmt passed. Exact set/get correction preserves assertions; final retest/release mapping is outside this handoff.','The original C gate handoff46d284 separately retains its packaging-only SameFileError and all original API failure bodies. No parser reruns were used to replace failed outcomes.','The custom-alias harness does not archive successful full paired traces; saved commands/counts/identities and difference summaries are its evidence.','C sanitizer consumers do not instrument Rust release libraries; leak checking is disabled.','Assembly and raw instruction profiles identify added payload cleanup checks; they do not prove the full cause of the generated elapsed slowdown.'],'archive_sha256':sha((O/'reviews.tar.gz').read_bytes()),'archive_members':len(members),'archive_bytes':(O/'reviews.tar.gz').stat().st_size}
write('summary.json',summary);(O/'package.py').write_bytes(Path(__file__).read_bytes())
manifest={p.name:{'sha256':sha(p.read_bytes()),'size':p.stat().st_size} for p in sorted(O.iterdir()) if p.is_file()};write('files.json',manifest)
print(json.dumps({'root':str(O),'summary_sha256':sha((O/'summary.json').read_bytes()),'archive_sha256':summary['archive_sha256'],'members':len(members),'bytes':summary['archive_bytes'],'files_sha256':sha((O/'files.json').read_bytes())}))
