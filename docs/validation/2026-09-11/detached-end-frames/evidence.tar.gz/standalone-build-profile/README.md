# Detached End frame: matched ThinLTO handoff

See SUMMARY.md for all16 instruction conditions and correctness scope. The candidate is826ada0c; controla55. Real-project instruction counts improve3.01% geometrically, with both generated entity regressions preserved. This is an instruction study, not an elapsed performance selection.

The evidence archive includes fresh three-crate compilation records, exact source hashes, all End lifecycle/allocation observations (including the initial CPU-guard failure),32 preflights,32 profiles,32 annotations and their full streams. The prior25-test focused handoff is included unchanged. Source/compiler and saved-data reviews are separate, copied with their generators. The candidate removes two Ohm trust environment opt-ins; the complete normalized compiler command vectors match, rather than the full environment dictionaries.

All archive members were reread from compressed bytes, including nested archives. Executable binaries are excluded with exact hashes retained. No full API/CPython/workspace gate, elapsed campaign or composition with selected Cell is claimed.
