# Detached End: matched ThinLTO instruction study

Candidate `826ada0c` preserves the reviewed nine-file source on89927; control is C-only ThinLTO `a55ca0f0`. All three workspace crates freshly compiled with identical complete compiler commands after private-path normalization. All70 source hashes remain unchanged and73 C exports match.

## Results

All32 preflights and32 Callgrind profiles passed. Each process ran a warmup and one other parse, with both collected in profiles:128 parser samples across preflights/profiles. XML_Parse collection includes native callbacks and excludes constructor/free/fileIO.

Real-project instruction ratio candidate/control: **0.969945398 (3.01% fewer)**, all12 lower. This is not a throughput result. Generated entity controls regress0.454–0.459%; rare-declaration4K regresses0.0037%,64K improves0.0114%. All conditions remain in the table.

|Input|NS|Chunk|Control Ir|Candidate Ir|Candidate/control|
|---|---|---:|---:|---:|---:|
|vulkan|0|4096|920465769|879125944|0.955088145|
|vulkan|1|4096|955103566|913737591|0.956689540|
|wayland|0|4096|19024059|18687319|0.982299256|
|wayland|1|4096|19617565|19281383|0.982863215|
|maven|0|4096|15926119|14973908|0.940210732|
|maven|1|4096|22264603|21295783|0.956486087|
|batik|0|4096|2444720|2443923|0.999673991|
|batik|1|4096|2768256|2756457|0.995737750|
|gtk|0|4096|6806250|6519183|0.957823030|
|gtk|1|4096|7005987|6719449|0.959100980|
|docbook|0|4096|4825171|4697209|0.973480318|
|docbook|1|4096|6795916|6672369|0.981820405|
|rare-declarations|0|4096|140481838|140487069|1.000037236|
|rare-declarations|0|65536|141360041|141343955|0.999886205|
|entities|0|4096|209617856|210579508|1.004587644|
|entities|0|65536|211265889|212225581|1.004542579|

## Correctness and limitations

End38 lifecycle covers114 parses with zero baseline changes; all38 existing reference-different cases remain exact, including Default text/raw/context/position differences. The separate End6 selected-allocation fallback gives37 exact rows perengine,4injected failures+2successes, live0; Cdriver ASan/UBSan only and leakcheckingdisabled. The earlier25 focused tests cover the newly eligible End owner/budget/reentry path.

AdapterFrame grows208→256bytes (+48), an explicit whole-loop cost included in this experiment. No full4740 API matrix, fullworkspace/CPython gate, elapsed campaign, Cell composition or release assembly-specific layout proof is claimed. Collector dladdr checks identify its loaded XML_Parse symbol; they do not independently certify each native driver process.

The initial lifecycle launcher failed before parsing because its helper still required CPU4. The final helper changes only that guard to assignedCPU6; failedsource/results are retained at their originalpaths. A separate first export-inspection launcher similarly stopped at itsCPUguard before nm; the pinned replay passed. Runtime source and fixtures were not changed.
