from pathlib import Path
import hashlib,io,json,os,shutil,sys,tarfile
O=Path(__file__).parent;P=Path('/tmp/oriole-detached-end-frame-production-handoff');assert not P.exists();assert os.sched_getaffinity(0)=={6};assert len(sys.argv)==2
R=Path(sys.argv[1]);assert R.is_dir() and (R/'final-review.json').is_file()
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text());summary=J(O/'summary.json');assert summary['status']=='passed_instruction_study_not_throughput_selection';P.mkdir()
source=J(O/'source.json');assert all(H(Path(source['worktree'])/n)==h for n,h in source['source_sha256'].items())
# Exact previous phase and both source reviews remain independent records.
archive_inputs={}
for old,new in [(Path('/tmp/oriole-detached-end-frame-handoff'),'focused-handoff'),(Path('/tmp/oriole-detached-end-profile-controller-independent-review'),'controller-review'),(Path('/tmp/oriole-detached-end-build-independent-review'),'build-review'),(R,'independent-review')]:
 archive_inputs[new+'.tar.gz']={str(p.relative_to(old)):H(p) for p in old.rglob('*') if p.is_file()}
 with tarfile.open(P/(new+'.tar.gz'),'w:gz') as t:
  for p in sorted(old.rglob('*')):
   if p.is_file():t.add(p,arcname=str(p.relative_to(old)),recursive=False)
excluded={'liboriole_expat.so','liboriole_expat.a','end-oom-final/baseline','end-oom-final/candidate'}
files={str(p.relative_to(O)):p for p in sorted(O.rglob('*')) if p.is_file() and str(p.relative_to(O)) not in excluded}
with tarfile.open(P/'evidence.tar.gz','w:gz') as t:
 for n,p in files.items():t.add(p,arcname=n,recursive=False)
for n in ['source.json','source.tar.gz','candidate.patch','build.json','compiler-comparison.json','summary.json','SUMMARY.md','control-source-lineage.json','root-source-review.json','package.py']:
 shutil.copyfile(O/n,P/n)
shutil.copyfile(R/'final-review.json',P/'independent-review.json');shutil.copyfile('/tmp/oriole-detached-end-build-independent-review/review.json',P/'build-review.json');shutil.copyfile('/tmp/oriole-detached-end-profile-controller-independent-review/review.json',P/'controller-review.json')
(P/'excluded-binaries.json').write_text(json.dumps({n:{'sha256':H(O/n),'bytes':(O/n).stat().st_size} for n in sorted(excluded)},indent=2)+'\n')
checks={}
for p in sorted(P.glob('*.tar.gz')):
 with tarfile.open(p,'r:gz') as t:
  members=t.getmembers();assert all(m.isfile() for m in members) and len(members)==len({m.name for m in members})
  mhash={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in members};checks[p.name]={'sha256':H(p),'members':len(members),'member_sha256':mhash}
  if p.name in archive_inputs:assert mhash==archive_inputs[p.name]
  if p.name=='evidence.tar.gz':assert mhash=={n:H(v) for n,v in files.items()}
  if p.name=='source.tar.gz':assert mhash==source['source_sha256']
  if p.name=='focused-handoff.tar.gz':
   manifest=json.loads(t.extractfile('manifest.json').read())['files'];assert all(mhash[n]==v['sha256'] for n,v in manifest.items())
  # Recursively verify the copied nested source/evidence archives from bytes.
  for m in members:
   if m.name.endswith('.tar.gz'):
    payload=t.extractfile(m).read()
    with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as inner:
     rows=inner.getmembers();assert all(x.isfile() for x in rows) and len(rows)==len({x.name for x in rows})
     checks[p.name].setdefault('nested',{})[m.name]={'members':len(rows),'member_sha256':{x.name:hashlib.sha256(inner.extractfile(x).read()).hexdigest() for x in rows}}
(P/'archive-readback.json').write_text(json.dumps(checks,indent=2)+'\n')
(P/'README.md').write_text('''# Detached End frame: matched ThinLTO handoff

See SUMMARY.md for all16 instruction conditions and correctness scope. The candidate is826ada0c; controla55. Real-project instruction counts improve3.01% geometrically, with both generated entity regressions preserved. This is an instruction study, not an elapsed performance selection.

The evidence archive includes fresh three-crate compilation records, exact source hashes, all End lifecycle/allocation observations (including the initial CPU-guard failure),32 preflights,32 profiles,32 annotations and their full streams. The prior25-test focused handoff is included unchanged. Source/compiler and saved-data reviews are separate, copied with their generators. The candidate removes two Ohm trust environment opt-ins; the complete normalized compiler command vectors match, rather than the full environment dictionaries.

All archive members were reread from compressed bytes, including nested archives. Executable binaries are excluded with exact hashes retained. No full API/CPython/workspace gate, elapsed campaign or composition with selected Cell is claimed.
''')
(P/'manifest.json').write_text(json.dumps({'scope':'Immutable first detached End ThinLTO build, focused lifecycle and instruction evidence.','files':{p.name:{'sha256':H(p),'bytes':p.stat().st_size} for p in sorted(P.iterdir()) if p.is_file()}},indent=2)+'\n')
manifest=J(P/'manifest.json');assert all(H(P/n)==v['sha256'] for n,v in manifest['files'].items())
print(json.dumps({'path':str(P),'manifest_sha256':H(P/'manifest.json'),'artifacts':len(manifest['files']),'archives':{n:v['members'] for n,v in checks.items()}},indent=2))
