"""Reconstruct fresh three-engine CPython samples without executing workers."""
from pathlib import Path
import os
assert os.sched_getaffinity(0)=={4}
from collections import Counter
import gzip
import hashlib
import json
import math
import random
import statistics

if not __debug__:
    raise RuntimeError('Audit assertions must run')
B = Path('/tmp/oriole-detached-end-frame-production-python-study')
S = B / 'screen'
OUT = Path(__file__).resolve().parent
tracked={}
def read(p):
    p=Path(p);raw=p.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(p),value)==value,('changed during audit',str(p))
    return raw
def sha(p):
    p=str(Path(p))
    if p not in tracked:read(p)
    return tracked[p]
def load(p):return json.loads(read(p))
pre = load(S / 'preflight.json')
r = load(S / 'results.json')
build = load(B / 'consumers/build.json')
summary = load(B / 'summary.json')
source_review_path=Path('/tmp/oriole-detached-end-frame-production-study/root-source-review.json')
source_review=load(source_review_path)
assert sha(source_review_path)=='856ee4cd02ea21ae878d0a77f23c54f203971aa4f746b57555cac9b28ea63852'
assert source_review['status']=='source_review_no_blocker' and source_review['source_files']==70
rust_build_review_path=Path('/tmp/oriole-detached-end-build-independent-review/review.json')
assert sha(rust_build_review_path)=='fe36762bfdaa1831cc219d005e34b676532b29567e930af1c8ae5dfffe00b48b' and load(rust_build_review_path)['status']=='independent_detached_end_fresh_compiler_source_audit_passed'
linked_reviews={'profile':('/tmp/oriole-detached-end-profile-independent-review/final-review.json','808f19537e7add394beb398266cc07b7bcf852ee7e17a3c984a9ce66b2385655'),'native':('/tmp/oriole-detached-end-native-independent-review/review.json','44a97deebbc667477c9e7f31cfeb71d09f1d185fd159589015b3e788f3e02813'),'prior_python':('/tmp/oriole-ascii-name-table-python-independent-review/review.json','06a5f2b4f6eddd43e512b1659a761c5dac682d14ec880ab687ff4846ba814def')}
for p,value in linked_reviews.values():assert sha(p)==value
candidate_source=Path('/tmp/oriole-detached-end-frame-production-study/source.json')
assert sha(candidate_source)==source_review['source_manifest_sha256']=='f261b87e333f393135162fcd584c4ae6dd955895ea8cac2ff1efe4b945010a63'
build_environment=load(rust_build_review_path)['build_environment_differences']
assert set(build_environment)=={'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST','CARGO_TARGET_DIR'}
assert all(build_environment[k]=={'control':'all','candidate':None} for k in ['CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'])
assert pre['status'] == 'preflight_passed' and r['status'] == 'passed'
assert pre['affinity'] == [5] and r['affinity'] == [0]
assert pre['kind'] == r['kind'] == 'python'
assert r['preflight_sha256'] == sha(S / 'preflight.json')
assert pre['conditions'] == r['conditions']
assert r['preflights'] == pre['preflights'] and r['expected'] == pre['expected']
assert len(pre['processes']) == len(pre['preflights']) == 72
assert len(r['processes']) == len(r['rows']) == 504
assert pre['pairs'] == r['pairs'] == 7
assert pre['seed'] == r['seed'] == 202609104412
assert pre['hashes_before'] == pre['hashes_after'] == r['hashes_before'] == r['hashes_after']
for record in [pre, r]:
    assert not record['hash_errors']
    assert all(sha(p) == h for p, h in record['hashes_before'].items())
assert sha(B / 'python_worker.py') == '4bc0ccffedb5048412b9cfc3638d28dcb30f711891c3784f3fbd3c0eb536ab68'
assert build['status'] == 'passed' and build['adaptations'] is None
assert build['cpython_revision'] == '3bb231a6a5dc02b95658877318bf61501a7209e9'
assert build['source_sha256_before'] == build['source_sha256_after']
assert all(sha(p) == h for p, h in build['source_sha256_before'].items())
engines = ['published', 'candidate', 'expat']
libraries = {'published': 'a55ca0f0fed68f8db0f2e8d3ea86c271c8491fe130b5074077aecace3ab4a4df',
             'candidate': '826ada0c90b35b137cdbf34c22e1e2d2e52cc46ef19a7e4739db6d1c02efcb56',
             'expat': '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'}
assert set(build['consumers']) == set(engines)
normalized_commands = {}
for engine, consumer in build['consumers'].items():
    assert sha(consumer['library']) == libraries[engine]
    assert all(sha(p) == h for p, h in consumer['files'].items())
    assert len(consumer['commands']) == 2
    normalized = []
    for module, command in zip(['pyexpat', '_elementtree'], consumer['commands'], strict=True):
        args = command['command']
        assert command['returncode'] == 0 and args[:4] == ['cc', '-shared', '-fPIC', '-O2']
        assert sha(Path(consumer['directory']) / (module + '-build.log')) == command['log_sha256']
        assert args[-4] == consumer['library'] and args[-3]=='-Wl,-rpath,'+consumer['directory'] and args[-2]=='-o' and Path(args[-1]).name.startswith(module+'.cpython-312-')
        assert args[-5].endswith('/Modules/'+('pyexpat.c' if module=='pyexpat' else '_elementtree.c')) and sha(args[-5])==build['source_sha256_before'][args[-5]]
        normalized.append([x.replace(consumer['library'], '<PARSER-LIBRARY>').replace(consumer['directory'], '<CONSUMER-DIR>') for x in args])
    normalized_commands[engine] = normalized
assert all(v == normalized_commands['published'] for v in normalized_commands.values())

manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
iterations = {'vulkan': 3, 'wayland': 16, 'maven': 32, 'batik': 128, 'gtk': 64, 'docbook': 64}
conditions = []
for project in load(manifest)['projects']:
    entry = next(x for x in project['files'] if x['role'] == 'input')
    path = (manifest.parent / entry['path']).resolve()
    assert sha(path) == entry['sha256']
    for chunk in [4096, 65536]:
        for mode in ['elementtree', 'pyexpat-events']:
            conditions.append({'name': project['name'], 'chunk': chunk, 'mode': mode, 'input': str(path), 'iterations': iterations[project['name']]})
assert conditions == r['conditions'] and len(conditions) == 24
assert set(pre['expected'])=={f"{c['name']}/{c['chunk']}/{c['mode']}" for c in conditions}
key = lambda c: f"{c['name']}/{c['chunk']}/{c['mode']}"
condition_map = {key(c): c for c in conditions}
index = {}
counts = Counter()
raw_hashes = {}
for phase, record, rowname in [('preflight', pre, 'preflights'), ('time', r, 'rows')]:
    processes = {p['label']: p for p in record['processes']}
    assert len(processes) == len(record['processes'])
    assert set(processes) == {row['process'] for row in record[rowname]}
    assert [p['label'] for p in record['processes']]==[row['process'] for row in record[rowname]]
    for row in record[rowname]:
        process = processes[row['process']]
        assert process['status'] == 'passed' and process['returncode'] == 0 and process['timeout_seconds'] == 300
        assert 'failure' not in process
        for stream in ['stdout', 'stderr']:
            path = S / process[stream]
            assert sha(path) == process[stream + '_sha256']
            raw_hashes[str(path)] = sha(path)
        assert not gzip.decompress(read(S / process['stderr']))
        raw = json.loads(gzip.decompress(read(S / process['stdout'])))
        assert raw['gc_enabled'] is True and raw['python']==build['python']==record['python_version']
        assert set(raw)=={'identity','python','gc_enabled','samples'}
        assert set(raw['identity'])=={'pyexpat','_elementtree','parser_library','expat_version'}
        assert raw['samples'] == row['samples'] and raw['identity'] == row['identity']
        engine = row['engine']
        consumer = build['consumers'][engine]
        assert raw['identity']['parser_library']['sha256'] == libraries[engine]
        assert raw['identity']['expat_version'] == ('expat_2.8.4' if engine == 'expat' else 'oriole_compat_2.8.4')
        for name in ['pyexpat', '_elementtree', 'parser_library']:
            entry = raw['identity'][name]
            assert consumer['files'][entry['path']] == entry['sha256'] == sha(entry['path'])
        command = process['command']
        assert command[0]=='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3' and len(command)==6
        assert 0<=process['wall_seconds']<300 and (S/process['stdout']).name==process['label']+'-stdout.gz' and (S/process['stderr']).name==process['label']+'-stderr.gz'
        assert command[1:5] == ['-I', '-S', str(B / 'python_worker.py'), '--worker']
        specpath = Path(command[-1])
        assert specpath.parent==S and specpath.name==process['label']+'.json'
        spec = load(specpath)
        raw_hashes[str(specpath)] = sha(specpath)
        c = condition_map[row['key']]
        count = 0 if phase == 'preflight' else c['iterations']
        assert spec == {'input': c['input'], 'input_sha256': sha(c['input']), 'chunk': c['chunk'], 'mode': c['mode'], 'consumer': consumer['directory'], 'library_sha256': libraries[engine], 'iterations': count}
        assert len(raw['samples']) == count + 1
        for i, sample in enumerate(raw['samples']):
            assert set(sample)=={'iteration','warmup','parse_ns','destruction_ns','seconds','output_sha256','output_rows'}
            assert type(sample['parse_ns']) is int and type(sample['destruction_ns']) is int and type(sample['output_rows']) is int
            assert sample['iteration'] == i and sample['warmup'] == (i == 0)
            assert sample['seconds'] == (sample['parse_ns'] + sample['destruction_ns']) / 1e9
            assert sample['seconds'] > 0 and math.isfinite(sample['seconds'])
            assert sample['parse_ns'] >= 0 and sample['destruction_ns'] >= 0
            assert [sample['output_sha256'], sample['output_rows']] == pre['expected'][row['key']]
            counts[phase + ('_warmups' if i == 0 else '_measured')] += 1
        median = statistics.median(s['seconds'] for s in raw['samples'][1:]) if count else None
        assert row['median_seconds'] == median
        if phase == 'time':
            identity = (row['key'], row['pair'], engine)
            assert identity not in index
            index[identity] = median
expected_preflights = [(key(c), engine) for c in conditions for engine in engines]
assert [(row['key'], row['engine']) for row in pre['preflights']] == expected_preflights
rng = random.Random(r['seed'])
jobs = [(condition, pair) for condition in conditions for pair in range(7)]
rng.shuffle(jobs)
order = []
for c, pair in jobs:
    shuffled = engines.copy()
    rng.shuffle(shuffled)
    order.extend((key(c), pair, engine, position) for position, engine in enumerate(shuffled))
assert order == [(row['key'], row['pair'], row['engine'], row['order']) for row in r['rows']]
ratio_pairs = [('candidate', 'published'), ('candidate', 'expat'), ('published', 'expat')]
summaries = []
for c in conditions:
    medians = {engine: [index[key(c), pair, engine] for pair in range(7)] for engine in engines}
    ratios = {a + '_over_' + b: [medians[a][pair] / medians[b][pair] for pair in range(7)] for a, b in ratio_pairs}
    summaries.append({'condition': c, 'process_pair_medians_seconds': medians, 'paired_ratios': ratios,
                      'median_ratios': {name: statistics.median(v) for name, v in ratios.items()}})
assert summaries == r['summary']
assert counts == {'preflight_warmups': 72, 'time_warmups': 504, 'time_measured': 25788}
groups = {}
for group in ['all', 'elementtree', 'pyexpat-events']:
    selected = [s for s in summaries if group == 'all' or s['condition']['mode'] == group]
    groups[group] = {}
    for a, b in ratio_pairs:
        name = a + '_over_' + b
        values = [s['median_ratios'][name] for s in selected]
        geo = math.exp(sum(math.log(v) for v in values)/len(values))
        actual = {'geomean': geo, 'below_one': sum(v < 1 for v in values), 'conditions': len(values)}
        assert actual['below_one'] == summary['groups'][group]['ratios'][name]['below_one'] and actual['conditions'] == summary['groups'][group]['conditions']
        assert actual['geomean']==summary['groups'][group]['ratios'][name]['geomean']
        groups[group][name] = actual
project_groups = {}
for project in iterations:
    selected = [s for s in summaries if s['condition']['name'] == project]
    project_groups[project] = {a + '_over_' + b: math.exp(statistics.mean(math.log(s['median_ratios'][a + '_over_' + b]) for s in selected)) for a, b in ratio_pairs}
# Worker and extension build helper are byte-exact; method label plus prepare CPU3→5 are the only controller edits.
old_base=Path('/tmp/oriole-thinlto-production-python-study')
assert sha(B/'python_worker.py')==sha(old_base/'python_worker.py')
assert sha(B/'build_consumers.py')==sha(old_base/'build_consumers.py')
old=read(old_base/'consumer_screen.py').decode();new=read(B/'consumer_screen.py').decode()
import difflib
assert ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='reviewed-consumer-screen',tofile='detached-end-frame-thinlto-screen'))==read(B/'controller.patch').decode()
oldlines=old.splitlines();newlines=new.splitlines();assert len(oldlines)==len(newlines)
delta=[(a,b) for a,b in zip(oldlines,newlines) if a!=b]
assert len(delta)==3
assert delta[0][0].replace('{3}','{5}')==delta[0][1] and delta[1][0].replace('CPU3','CPU5')==delta[1][1]
assert all(x.strip().startswith('"method":') for x in delta[2])
preparation=load(B/'preparation.json');assert preparation['status']=='passed' and [x['exit']for x in preparation['jobs']]==[0,0]
assert all(x['command'][:3]==['taskset','-c','5']for x in preparation['jobs'])
timed=load(B/'timing-controller.json');assert timed['status']=='passed' and timed['exit']==0 and timed['command'][:3]==['taskset','-c','0']
regressions=[{'condition':x['condition'],'ratio':x['median_ratios']['candidate_over_published']}for x in summaries if x['median_ratios']['candidate_over_published']>1]
assert regressions==summary['regressions']
assert len(regressions)==11 and groups['all']['candidate_over_published']['below_one']==13
assert groups['all']['candidate_over_published']['geomean']==0.9933205657284958
assert groups['elementtree']['candidate_over_published']['geomean']==0.9927491286908053 and groups['pyexpat-events']['candidate_over_published']['geomean']==0.9938923316914692
assert set(raw_hashes)=={str(p) for p in S.iterdir() if p.is_file() and p.name not in ['preflight.json','results.json']}
assert len(raw_hashes)==1728 and sum(counts.values())==26364
assert load(B/'preflight.log')=={'status':'preflight_passed','kind':'python','preflights':72,'timed_rows':0}
assert load(B/'timing-controller.log')=={'status':'passed','kind':'python','preflights':72,'timed_rows':504}
assert load(B/'build.log')=={'status':'passed','output':str(B/'consumers')}
PYTHON='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
screen_args=['--kind','python','--phase','prepare','--build',str(B/'consumers/build.json'),'--input',str(manifest),'--output',str(S)]
assert preparation['jobs'][1]['command']==['taskset','-c','5',PYTHON,'-I','-S',str(B/'consumer_screen.py'),*screen_args]
assert timed['command']==['taskset','-c','0',PYTHON,'-I','-S',str(B/'consumer_screen.py'),*[('time' if x=='prepare' else x) for x in screen_args]] and not timed.get('timeout') and 0<timed['elapsed_seconds']<1200
prepare_path=B/'oriole-prepare-detached-end-frame-production-python.py';prepare_code=read(prepare_path).decode()
assert read('/tmp/oriole-prepare-detached-end-frame-production-python.py')==read(prepare_path)
assert 'timeout=600' in prepare_code and 'subprocess.run(command, stdout=log, stderr=subprocess.STDOUT' in prepare_code
timing_path=Path('/tmp/oriole-time-detached-end-frame-production-python.py');timing_code=read(timing_path).decode()
assert 'start_new_session=True' in timing_code and 'process.wait(timeout=1200)' in timing_code and 'os.killpg(process.pid, signal.SIGKILL)' in timing_code
# Explicit origin guarantee belongs to each worker; retain the exact reviewed loader implementation.
worker_code=read(B/'python_worker.py').decode()
assert 'ctypes.cast(extension.XML_Parse, ctypes.c_void_p)' in worker_code and 'library.parent != directory.resolve()' in worker_code and 'module.__file__ is None' in worker_code
assert 'gc.collect()' in worker_code and 'gc.disable(' not in worker_code
all_read_unchanged=all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==value for p,value in tracked.items())
assert all_read_unchanged
def put(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
put('audited-raw-files.json',raw_hashes);put('checked-files.json',tracked);put('all-conditions.json',summaries);put('groups.json',groups);put('normalized-consumer-build-commands.json',normalized_commands)
result={
 'status':'independent_saved_detached_end_python_audit_passed','scope':'Saved-data audit only. No parser/build/test/worker or elapsed execution. Full gates/adoption remain outside scope.','cpu':4,'standalone_scope':'Standalone826a End candidate vs a55; no Cell composition, combined gates or published-adoption inference.',
 'counts':{'preflights':72,'timed_workers':504,'cohorts':168,'conditions':24,'preflight_warmups':72,'timed_warmups':504,'timed_measured_samples':25788,'all_samples':26364,'raw_files_verified':1728,'paired_ratios_verified':504,'condition_ratio_medians':72,'fresh_consumer_module_build_commands':6},
 'libraries':libraries,'source_review_sha256':sha(source_review_path),'rust_build_review_sha256':sha(rust_build_review_path),'source_manifest_sha256':sha(candidate_source),'linked_prior_reviews':{k:{'path':p,'sha256':value} for k,(p,value) in linked_reviews.items()},'Rust_build_environment_differences':build_environment,
 'groups':groups,'per_project_geomeans':project_groups,'regressions':regressions,'all_conditions':'all-conditions.json',
 'origins':{'worker_count':576,'module_origins_per_worker':2,'XML_Parse_library_origin_per_worker':1,'same_process_dladdr':True,'scope':'pyexpat and _elementtree are explicitly imported from each frozen consumer directory; dladdr resolves XML_Parse via the loaded pyexpat extension. This is not an independent audit of every C function called by _elementtree.'},
 'consumer_build':{'commands':6,'unmodified_CPython_revision':build['cpython_revision'],'same_source_hashes_before_after':True,'module_commands_equal_after_library_directory_only_normalization':True,'module_flags':'cc -shared -fPIC -O2; same narrow header; no extension LTO/PGO','python':build['python'],'compiler':build['compiler'],'build_receipt_sha256':sha(B/'consumers/build.json')},
 'controller_lineage':{'worker_sha256':sha(B/'python_worker.py'),'build_helper_sha256':sha(B/'build_consumers.py'),'consumer_screen_sha256':sha(B/'consumer_screen.py'),'patch_sha256':sha(B/'controller.patch'),'changes':'Only method description plus preparation-affinity guard3 to5; unchanged reviewed worker/build helper.','preparation_jobs':preparation['jobs'],'timing_controller':timed,'timing_wrapper_sha256':sha(timing_path),'preparation_source_sha256':sha(prepare_path),'worker_timeout_seconds':300,'prepare_job_timeout_seconds':600,'timing_outer_timeout_seconds':1200,'native_CPU':0,'preparation_CPU':5,'failed_worker_records':0},
 'limitations':[
  'Automatic GC stays enabled and may run inside the timed work; explicit gc.collect, imports, input reads and canonicalization are outside the timer. Timed parse_ns includes parse-function setup/construction/feed/finalization and parser-local cleanup; destruction_ns measures explicit returned tree/event-list deletion. Their sum is used for each sample.',
  'Canonical ElementTree output includes expanded names, attribute order, text/tail and child counts. pyexpat canonicalization joins adjacent text callbacks; equal digests do not establish exact callback grouping or all API compatibility.',
  'No fresh full strict CPython802 or full API/workspace suite is included for this candidate. The inherited controller limitation about two CPython failures is historical expectation, not fresh standalone-End strict-suite evidence.',
  'Only six original XML fixtures, two modes,4KiB/64KiB and seven seeded cohorts. No external DTD/full application/Wayland scanner/PGO claim. All eleven regressions and all candidate/reference ratios remain.',
  'Both Oriole libraries are C-only ThinLTO with actual compiler-vector equality separately certified by pinned fe367. Candidate removes two experimental Ohm trust opt-ins and has a distinct target directory; the Rust build environment is not byte-identical. Consumer extensions use identical -O2 arguments; normal Expat does not have identical Rust/C compiler context. No source-codegen proof repeated here.',
  'Shared host frequency/cache/background load remain uncontrolled. CPU pinning and order randomization do not establish absence of contention or statistical significance. This remains standalone study evidence; no combined-Cell, full-gate or published-adoption conclusion.',
  'Worker subprocess.run300s kills/reaps direct child on timeout; outer timing wrapper uses a new process group with1200s kill/wait. Preparation uses600s subprocess.run. These scripts do not provide an explicit comprehensive SIGTERM-forwarding guarantee; no signal tests performed.'
 ],
 'checked_file_count':len(tracked),'all_inspected_bytes_unchanged':all_read_unchanged,'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'evidence_sha256':{str(p):sha(p) for p in [B/'consumer_screen.py',B/'python_worker.py',B/'build_consumers.py',B/'consumers/build.json',B/'preparation.json',B/'summary.json',S/'preflight.json',S/'results.json',B/'controller.patch',B/'timing-controller.json',prepare_path,B/'build.log',B/'preflight.log',B/'timing-controller.log',timing_path]}
}
put('review.json',result)
print(json.dumps({'status':result['status'],'review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'checked_files':len(tracked),'raw_files':len(raw_hashes),'groups':groups},indent=2))
