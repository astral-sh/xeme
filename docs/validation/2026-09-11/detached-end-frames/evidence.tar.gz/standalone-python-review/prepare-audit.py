"""Adapt frozen saved Python checker for standalone detached End only."""
from pathlib import Path
import hashlib,difflib,json
O=Path(__file__).resolve().parent;B=Path('/tmp/oriole-ascii-name-table-python-independent-review/audit.py');b=B.read_text()
assert hashlib.sha256(b.encode()).hexdigest()=='ebc11d310b88493c0f0e02689aff0ecec70800f9d445db228fe3cb1b5822fad6'
s=b.replace('/tmp/oriole-ascii-name-table-thinlto-python-study','/tmp/oriole-detached-end-frame-production-python-study')
start=s.index('source_review_path=');end=s.index("assert pre['status']",start)
prefix='''source_review_path=Path('/tmp/oriole-detached-end-frame-production-study/root-source-review.json')
source_review=load(source_review_path)
assert sha(source_review_path)=='856ee4cd02ea21ae878d0a77f23c54f203971aa4f746b57555cac9b28ea63852'
assert source_review['status']=='source_review_no_blocker' and source_review['source_files']==70
rust_build_review_path=Path('/tmp/oriole-detached-end-build-independent-review/review.json')
assert sha(rust_build_review_path)=='fe36762bfdaa1831cc219d005e34b676532b29567e930af1c8ae5dfffe00b48b' and load(rust_build_review_path)['status']=='independent_detached_end_fresh_compiler_source_audit_passed'
linked_reviews={'profile':('/tmp/oriole-detached-end-profile-independent-review/final-review.json','808f19537e7add394beb398266cc07b7bcf852ee7e17a3c984a9ce66b2385655'),'native':('/tmp/oriole-detached-end-native-independent-review/review.json','44a97deebbc667477c9e7f31cfeb71d09f1d185fd159589015b3e788f3e02813'),'prior_python':('/tmp/oriole-ascii-name-table-python-independent-review/review.json','06a5f2b4f6eddd43e512b1659a761c5dac682d14ec880ab687ff4846ba814def')}
for p,value in linked_reviews.values():assert sha(p)==value
candidate_source=Path('/tmp/oriole-detached-end-frame-production-study/source.json')
assert sha(candidate_source)==source_review['source_manifest_sha256']=='f261b87e333f393135162fcd584c4ae6dd955895ea8cac2ff1efe4b945010a63'
build_environment=load(rust_build_review_path)['build_environment_differences']
assert set(build_environment)=={'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST','CARGO_TARGET_DIR'}
assert all(build_environment[k]=={'control':'all','candidate':None} for k in ['CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'])
'''
s=s[:start]+prefix+s[end:]
s=s.replace("'published': '0cfd610876f1bfd26a4d37a7f86adc9961896dfe24177c180ec7d15e0bae04e9'","'published': 'a55ca0f0fed68f8db0f2e8d3ea86c271c8491fe130b5074077aecace3ab4a4df'")
s=s.replace("'candidate': '02fd0819efd4b48d87974811737d3de64fe38a617f1f9d9bb6fd69f10a42b1c5'","'candidate': '826ada0c90b35b137cdbf34c22e1e2d2e52cc46ef19a7e4739db6d1c02efcb56'")
s=s.replace("tofile='ascii-name-table-thinlto-screen'","tofile='detached-end-frame-thinlto-screen'")
s=s.replace("len(regressions)==9 and groups['all']['candidate_over_published']['below_one']==15","len(regressions)==11 and groups['all']['candidate_over_published']['below_one']==13")
s=s.replace('0.9970918503348288','0.9933205657284958').replace('0.9960591744827008','0.9927491286908053').replace('0.9981255968255724','0.9938923316914692')
s=s.replace('oriole-prepare-ascii-name-table-thinlto-python.py','oriole-prepare-detached-end-frame-production-python.py')
s=s.replace('oriole-time-ascii-name-table-thinlto-python.py','oriole-time-detached-end-frame-production-python.py')
s=s.replace("'independent_saved_ascii_python_audit_passed'","'independent_saved_detached_end_python_audit_passed'")
s=s.replace("'cpu':4,","'cpu':4,'standalone_scope':'Standalone826a End candidate vs a55; no Cell composition, combined gates or published-adoption inference.',")
s=s.replace("'linked_prior_reviews':{k:{'path':p,'sha256':value} for k,(p,value) in linked_reviews.items()},","'linked_prior_reviews':{k:{'path':p,'sha256':value} for k,(p,value) in linked_reviews.items()},'Rust_build_environment_differences':build_environment,")
s=s.replace('All nine regressions','All eleven regressions')
s=s.replace('fresh ASCII-table strict-suite evidence','fresh standalone-End strict-suite evidence')
s=s.replace('Both Oriole libraries are C-only ThinLTO with source/codegen lineage separately certified by pinned aac132. Consumer extensions use identical -O2 arguments; normal Expat does not have identical Rust/C compiler context. No source-codegen proof repeated here.','Both Oriole libraries are C-only ThinLTO with actual compiler-vector equality separately certified by pinned fe367. Candidate removes two experimental Ohm trust opt-ins and has a distinct target directory; the Rust build environment is not byte-identical. Consumer extensions use identical -O2 arguments; normal Expat does not have identical Rust/C compiler context. No source-codegen proof repeated here.')
s=s.replace('This remains unselected study evidence.','This remains standalone study evidence; no combined-Cell, full-gate or published-adoption conclusion.')
(O/'audit.py').write_text(s)
(O/'adaptation.patch').write_text(''.join(difflib.unified_diff(b.splitlines(True),s.splitlines(True),fromfile=str(B),tofile=str(O/'audit.py'))))
(O/'run-audit.py').write_text((B.parent/'run-audit.py').read_text())
(O/'preparation.json').write_text(json.dumps({'scope':'Saved standalone End Python checker adaptation only; no target executions.','base_generator':str(B),'base_generator_sha256':hashlib.sha256(b.encode()).hexdigest(),'generator_sha256':hashlib.sha256(s.encode()).hexdigest(),'cpu':4},indent=2)+'\n')
