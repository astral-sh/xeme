"""Reconstruct actual Cargo target and test inventories; no target executions."""
from pathlib import Path
import hashlib,json,re
R=Path(__file__).parent;B=Path('/tmp/oriole-ffi-family-cell-workspace-gates/workspace-checks/tests.log')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def parse(path):
 rows=[];current=None
 for line in path.read_text().splitlines():
  if line.lstrip().startswith('Running ') and '(' in line:
   desc=line.split('Running ',1)[1].rsplit(' (',1)[0];binary=re.sub(r'-[0-9a-f]{16}$','',Path(line.rsplit('(',1)[1].rstrip(')')).name)
   assert current is None;current={'target':binary,'description':desc,'tests':[]}
  elif line.lstrip().startswith('Doc-tests '):
   assert current is None;current={'target':'doc:'+line.split('Doc-tests ',1)[1].strip(),'description':'doc','tests':[]}
  elif line.startswith('test ') and not line.startswith('test result:'):
   assert current is not None;name,result=line[5:].rsplit(' ... ',1);current['tests'].append({'name':name,'result':result})
  m=re.fullmatch(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;.*',line)
  if m:
   assert current is not None;current.update(dict(zip(['passed','failed','ignored','measured','filtered'],map(int,m.groups()))));assert current['passed']==len(current['tests']) and all(x['result']=='ok' for x in current['tests']);rows.append(current);current=None
 assert current is None
 assert len({(r['target'],r['description']) for r in rows})==len(rows)
 return rows
b=parse(B);a=parse(R/'workspace-checks/tests.log');d=parse(R/'workspace-checks/doc-tests.log')
assert len(a)==len(b)==33
expected={
 ('oriole','unittests src/lib.rs'):{'arena::tests::detached_end_keeps_the_warmed_start_arena_and_oversized_owner_separate'},
 ('adapter_frame','tests/adapter_frame.rs'):{'detached_end_frames_keep_native_and_namespace_undo_boundaries','detached_end_frames_recheck_child_publication_and_generation'},
 ('allocation','tests/allocation.rs'):{'detached_end_names_reuse_selected_storage_without_new_allocations'},
 ('oriole_expat','unittests src/lib.rs'):{'tests::detached_end_charges_the_name_before_handlers_or_default_fallback','tests::detached_end_owner_survives_default_current_children_stop_and_reset_rejection'},
 ('memory','tests/memory.rs'):{'detached_end_uses_the_selected_owner_and_default_failure_stays_terminal'},
}
changes=[]
for left,right in zip(b,a,strict=True):
 key=(left['target'],left['description']);assert key==(right['target'],right['description']);lt={r['name'] for r in left['tests']};rt={r['name'] for r in right['tests']};assert lt<=rt;assert rt-lt==expected.get(key,set());assert right['passed']==left['passed']+len(rt-lt)
 if rt!=lt:changes.append({'target':key,'before':left['passed'],'after':right['passed'],'added':sorted(rt-lt)})
assert all(r[k]==0 for r in a+d for k in ['failed','ignored','measured','filtered']);assert sum(r['passed'] for r in a)==sum(r['passed'] for r in b)+sum(map(len,expected.values()))==407;assert sum(r['passed'] for r in d)==1
r={'status':'actual_inventory_verified','all_target_rows':a,'doc_rows':d,'baseline_log':str(B),'baseline_sha256':sha(B),'baseline_count':sum(x['passed'] for x in b),'all_target_count':sum(x['passed'] for x in a),'doc_count':sum(x['passed'] for x in d),'added_tests':changes,'no_removed_or_changed_baseline_tests':True,'log_sha256':{n:sha(R/'workspace-checks'/n) for n in ['tests.log','doc-tests.log']}}
(R/'workspace-checks/counts.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'all_targets':r['all_target_count'],'doc':r['doc_count'],'inventory_rows':len(a),'added':changes}))
