"""Independent saved-log inventory audit; never executes Cargo or a target."""
from pathlib import Path
import hashlib, json, re

OUT = Path(__file__).parent
ROOT = Path('/tmp/oriole-end-frame-cells-workspace-final-gates')
OLD = Path('/tmp/oriole-end-frame-cells-workspace-gates/workspace-checks')
BASE = Path('/tmp/oriole-ffi-family-cell-workspace-gates/workspace-checks/tests.log')
REPO = Path('/home/dev-user/code/oss/oriole-end-frame-cells')
checked = {}

def read(path):
    p=Path(path); b=p.read_bytes(); checked[str(p)]=hashlib.sha256(b).hexdigest(); return b

def js(path): return json.loads(read(path))

def inventory(path):
    text=read(path).decode(); blocks=[]
    # Split by actual Cargo executable/doc introductions, then require one complete
    # test-run summary and exact named test statuses within every block.
    intro=re.compile(r'^\s+(?:Running (.+?) \(([^\n]+)\)|Doc-tests (\S+))$',re.M)
    matches=list(intro.finditer(text))
    for i,m in enumerate(matches):
        body=text[m.end():matches[i+1].start() if i+1<len(matches) else len(text)]
        sums=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',body,re.M)
        assert len(sums)==1 and sums[0][0]=='ok'
        passed,failed,ignored,measured,filtered=map(int,sums[0][1:])
        names=re.findall(r'^test (.+) \.\.\. (.+)$',body,re.M)
        assert len(names)==passed and len(set(n for n,s in names))==passed
        assert all(s=='ok' for n,s in names) and failed==ignored==measured==filtered==0
        declared=re.findall(r'^running (\d+) tests?$',body,re.M)
        assert declared==[str(passed)]
        target='doc:'+m[3] if m[3] else re.sub(r'-[a-f0-9]{16}$','',Path(m[2]).name)
        blocks.append({'target':target,'description':'doc' if m[3] else m[1],
            'tests':[{'name':n,'result':s} for n,s in names],
            'passed':passed,'failed':0,'ignored':0,'measured':0,'filtered':0})
    assert len(set((b['target'],b['description']) for b in blocks))==len(blocks)
    return blocks

summary=js(ROOT/'summary.json'); report=js(ROOT/'workspace-checks/report.json')
counts=js(ROOT/'workspace-checks/counts.json'); source=js(ROOT/'source.json')['source_sha256']
assert len(source)==70 and report['before']==report['after']==source
assert report['unchanged'] and report['frozen_libraries_unchanged']
for path,h in source.items(): assert hashlib.sha256(read(REPO/path)).hexdigest()==h
for path,h in report['frozen_libraries_before'].items():
    assert hashlib.sha256(read(path)).hexdigest()==h==report['frozen_libraries_after'][path]
assert report['status']=='passed' and report['normal_profile'] and report['affinity']==[6]
assert report['timeout_seconds_per_command']==900
assert len(report['commands'])==4
old=js(OLD/'report.json')
for row,prior in zip(report['commands'],old['commands'],strict=True):
    assert row['command']==prior['command'] and row['timeout_seconds']==prior['timeout_seconds']==900
    assert row['exit']==0 and row['end']-row['start']<900
    assert hashlib.sha256(read(ROOT/'workspace-checks'/(row['label']+'.log'))).hexdigest()==row['log_sha256']
    assert hashlib.sha256(read(OLD/(prior['label']+'.log'))).hexdigest()==prior['log_sha256']
assert [x['exit'] for x in old['commands']]==[101,0,101,0]
assert '--all-targets' in report['commands'][0]['command'] and '--no-fail-fast' in report['commands'][0]['command']
assert report['commands'][2]['command'][-3:]==['--','-D','warnings']
assert report['commands'][3]['command'][-2:]==['--','--check']
for label in ['tests','clippy']:
    raw=read(OLD/(label+'.log')).decode()
    assert 'error[E0599]' in raw and 'store' in raw and 'load' in raw
assert inventory(OLD/'tests.log')==[]
assert sum(x['passed'] for x in inventory(OLD/'doc-tests.log'))==1
now=inventory(ROOT/'workspace-checks/tests.log'); base=inventory(BASE); doc=inventory(ROOT/'workspace-checks/doc-tests.log')
assert now==counts['all_target_rows'] and doc==counts['doc_rows']
assert len(now)==len(base)==33 and sum(x['passed'] for x in now)==407
assert sum(x['passed'] for x in base)==400 and sum(x['passed'] for x in doc)==1
changes=[]
for b,n in zip(base,now,strict=True):
    assert (b['target'],b['description'])==(n['target'],n['description'])
    before={x['name'] for x in b['tests']};after={x['name'] for x in n['tests']}
    assert before<=after
    if before!=after: changes.append({'target':[n['target'],n['description']],
        'before':b['passed'],'after':n['passed'],'added':sorted(after-before)})
assert sum(len(x['added']) for x in changes)==7
assert changes==counts['added_tests']==summary['changed_target_inventories']
assert summary['all_target_passed']==407 and summary['all_target_inventory_rows']==33 and summary['doc_passed']==1
assert all('detached_end' in name for c in changes for name in c['added'])
result={'status':'passed','scope':'Independent read-only reconstruction of saved final normal workspace logs. No Cargo, parser, test or timing execution. Normal workspace binaries are distinct from C-only ThinLTO libraries.',
    'source_manifest_sha256':checked[str(ROOT/'source.json')], 'source_files':70,
    'all_targets':407,'target_inventories':33,'doc_tests':1,'new_tests':changes,
    'all_four_commands_exit':0,'timeout_seconds_each':900,
    'initial_attempt':{'tests_exit':101,'clippy_exit':101,'all_target_tests_executed':0,'doc_tests':1,'fmt_exit':0,'cause':'Two E0599 store/load calls in cfg(test) after Cell composition; separate final source uses set/get.'},
    'normal_source_and_frozen_c_libraries_unchanged':True,
    'checked_files':checked,'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT/'workspace-review.json').write_text(json.dumps(result,indent=2)+'\n')
(OUT/'workspace-inventories.json').write_text(json.dumps({'final':now,'baseline':base,'doc':doc},indent=2)+'\n')
print(json.dumps({'status':'passed','all_targets':407,'target_inventories':33,'doc':1,'checked_files':len(checked),'review_sha256':hashlib.sha256((OUT/'workspace-review.json').read_bytes()).hexdigest()}))
