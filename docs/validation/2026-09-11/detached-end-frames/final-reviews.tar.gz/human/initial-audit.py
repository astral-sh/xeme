"""Read-only review of publication claims and saved arithmetic. No target runs."""
from pathlib import Path
from statistics import median
from urllib.parse import unquote, urlsplit
import hashlib, json, math, re, subprocess

O=Path(__file__).parent
R=Path('/home/dev-user/code/oss/oriole-end-frame-cells')
D=R/'docs/validation/2026-09-11/detached-end-frames'
checked={}
def read(p):
    p=Path(p);b=p.read_bytes();checked[str(p)]=hashlib.sha256(b).hexdigest();return b
def js(p):return json.loads(read(p))
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
def close(a,b):assert math.isclose(a,b,rel_tol=1e-14,abs_tol=1e-15),(a,b)
def geom(xs):return math.exp(sum(map(math.log,xs))/len(xs))
texts={str(p):read(p).decode() for p in [R/'README.md',D/'README.md',D/'unselected-names/README.md',R/'benchmarks/results/2026-09-11/detached-end-frames/README.md',Path('/tmp/oriole-pr-detached-end-frames.md')]}
human=texts[str(D/'README.md')]; top=texts[str(R/'README.md')]
parent=git('show','5f20adf:README.md').decode()
headings=lambda t:re.findall(r'^#{1,6} .+$',t,re.M)
warning=lambda t:'\n'.join(x for x in t.splitlines() if x.startswith('>'))
assert headings(top)==headings(parent) and warning(top)==warning(parent)
assert top[top.index('## License'):]==parent[parent.index('## License'):]
assert top[:top.index('| Project XML')]==parent[:parent.index('| Project XML')]
assert top[top.index('## Installation'):]==parent[parent.index('## Installation'):]
toucan=read('/home/dev-user/code/oss/toucan/README.md').decode()
assert headings(top)==[x.replace('Toucan','Oriole') for x in headings(toucan)]
assert top[top.index('## License'):]==toucan[toucan.index('## License'):].replace('Toucan','Oriole')
for name in ['LICENSE-APACHE','LICENSE-MIT']:
    assert read(R/name)==git('show','5f20adf:'+name)
ci={}
for name in git('ls-tree','-r','--name-only','5f20adf','.github').decode().splitlines():
    current=read(R/name);assert current==git('show','1ff7b64:'+name)==git('show','5f20adf:'+name)
    ci[name]=hashlib.sha256(current).hexdigest()
assert not git('diff','5f20adf','1ff7b64','--','.github').strip()
assert len(git('diff','--name-only','5f20adf','1ff7b64').decode().splitlines())==9
links=[]
for path,text in texts.items():
    for href in re.findall(r'(?<!!)\[[^\]]+\]\(([^)]+)\)',text):
        url=href.strip('<>');parts=urlsplit(url)
        if parts.scheme or url.startswith('#'):continue
        dest=(Path(path).parent/unquote(parts.path)).resolve()
        assert dest.exists(),(path,href)
        links.append({'from':path,'href':href,'exists':True})

# Reconstruct native process medians from the complete saved embedded outputs.
native=js('/tmp/oriole-end-frame-cells-thinlto-timing-study/native-screen/results.json')
assert len(native['rows'])==196 and len(native['summary'])==28
paired={}; by_condition={}; nmeasured=0; nwarm=0
for row in native['rows']:
    c=row['condition'];key=(c['name'],c['chunk'],c['namespaces']);pair=row['pair']
    assert (key,pair) not in paired
    med={}
    for proc in row['processes']:
        assert proc['returncode']==0
        data=json.loads(proc['stdout']); samples=data['samples']
        assert samples[0]['warmup'] and not any(x['warmup'] for x in samples[1:])
        assert len(samples)==c['iterations']+1
        m=median(x['seconds'] for x in samples[1:]);close(m,proc['median_seconds'])
        med[proc['engine']]=m;nmeasured+=len(samples)-1;nwarm+=1
    assert set(med)=={'published','candidate','expat'};paired[key,pair]=med
    by_condition.setdefault(key,[]).append(med)
native_rows={}
for row in native['summary']:
    c=row['condition'];key=(c['name'],c['chunk'],c['namespaces'])
    assert len(by_condition[key])==7
    ratios={}
    for label,(a,b) in {'candidate_over_published':('candidate','published'),'candidate_over_expat':('candidate','expat'),'published_over_expat':('published','expat')}.items():
        values=[paired[key,p][a]/paired[key,p][b] for p in range(7)]
        assert values==row['paired_ratios'][label]
        ratios[label]=median(values);close(ratios[label],row['median_ratios'][label])
    native_rows[key]=ratios
assert (nmeasured,nwarm)==(105420,588)
ns=js(D/'native-summary.json')
for group in ['real','generated']:
    vals=[v for k,v in native_rows.items() if k[0].startswith('generated')==(group=='generated')]
    assert len(vals)==ns['groups'][group]['conditions']
    for label,expected in ns['groups'][group]['ratios'].items():
        close(geom([v[label] for v in vals]),expected['geomean'])
        assert sum(v[label]<1 for v in vals)==expected['below_one']
labels={'vulkan':'Vulkan registry','wayland':'Wayland protocol','maven':'Maven POM','batik':'Batik SVG','gtk':'GTK UI','docbook':'DocBook XSL'}
display=[]
for name in labels:
    k=(name,4096,False); times={e:median(x[e] for x in by_condition[k])*1000 for e in ['candidate','expat']}
    display.append(f"| {labels[name]} | {times['candidate']:.3f} ms | {times['expat']:.3f} ms | {native_rows[k]['candidate_over_expat']:.2f}× |")
table='\n'.join(display)
assert table==read(D/'table.md').decode().strip() and table in human and table in top

# Consumer per-process samples are already origin/raw-file audited separately;
# repeat their arithmetic here to tie the published table to this exact study.
py=js('/tmp/oriole-end-frame-cells-thinlto-python-study/screen/results.json')
assert len(py['rows'])==len(py['processes'])==504 and len(py['preflights'])==72
pymed={};pycounts=0
for row in py['rows']:
    ss=row['samples'];assert ss[0]['warmup'] and not any(s['warmup'] for s in ss[1:])
    m=median(x['seconds'] for x in ss[1:]);close(m,row['median_seconds'])
    k=(row['key'],row['pair'],row['engine']);assert k not in pymed;pymed[k]=m;pycounts+=len(ss)-1
assert pycounts==25788
pyrows={}
for row in py['summary']:
    c=row['condition'];key=f"{c['name']}/{c['chunk']}/{c['mode']}";v={}
    for label,(a,b) in {'candidate_over_published':('candidate','published'),'candidate_over_expat':('candidate','expat'),'published_over_expat':('published','expat')}.items():
        rr=[pymed[key,p,a]/pymed[key,p,b] for p in range(7)]
        assert rr==row['paired_ratios'][label];v[label]=median(rr);close(v[label],row['median_ratios'][label])
    pyrows[key]=v
ps=js(D/'python-summary.json')
for group in ['all','elementtree','pyexpat-events']:
    vals=[v for k,v in pyrows.items() if group=='all' or k.endswith('/'+group)]
    assert len(vals)==ps['groups'][group]['conditions']
    for label,expected in ps['groups'][group]['ratios'].items():
        close(geom([v[label] for v in vals]),expected['geomean']);assert sum(v[label]<1 for v in vals)==expected['below_one']
assert [k for k,v in pyrows.items() if v['candidate_over_expat']<1]==['wayland/4096/pyexpat-events','wayland/65536/elementtree','wayland/65536/pyexpat-events']
for label,group,rowname in [('native','real','Project XML'),('native','generated','Generated controls'),('python','elementtree','ElementTree'),('python','pyexpat-events','pyexpat events'),('python','all','Combined')]:
    g=(ns if label=='native' else ps)['groups'][group];a=g['ratios']['candidate_over_published'];b=g['ratios']['candidate_over_expat']
    assert f"| {rowname} | {g['conditions']} | {a['geomean']:.6f} | {b['geomean']:.6f} | {a['below_one']} | {b['below_one']} |" in human
assert f"{(1-ns['groups']['real']['ratios']['candidate_over_published']['geomean'])*100:.1f}%"=='4.0%'
assert f"{(1-ps['groups']['all']['ratios']['candidate_over_published']['geomean'])*100:.1f}%"=='2.1%'
assert f"{(ns['groups']['generated']['ratios']['candidate_over_published']['geomean']-1)*100:.1f}%"=='2.5%'

profile=js('/tmp/oriole-end-frame-cells-profile-independent-review/review.json')
assert profile['profile_processes']==profile['preflight_processes']==32 and profile['parser_samples']==128
close(profile['project_instruction_ratio_geomean'],.9699069707935961)
close(profile['generated_instruction_ratio_geomean'],1.0023000439210052)
assert profile['real_lower']==12 and profile['generated_lower']==1
codegen=js('/tmp/oriole-end-frame-cells-codegen-independent-review/review.json')
assert [v['candidate_minus_control'] for v in codegen['selected_static_path_deltas'].values()]==[4,3,-1,6]
classification=js(R/'docs/validation/2026-09-10/detached-frames/api-classification/classification.json')
assert classification['passes']==4347 and classification['failures']==393 and classification['total']==4740 and classification['failed_test_names']==38
assert sorted(g['failed_configurations'] for g in classification['groups'].values())==[1,2,12,12,12,12,44,298]
assert sum(g['failed_configurations'] for g in classification['groups'].values())==393
workspace=js(O/'workspace-review.json');assert workspace['all_targets']==407
summary=js(D/'summary.json');assert summary['workspace']==js(D/'workspace.json')
assert summary['native']==ns and summary['python']==ps
assert summary['api']['bounds']=={'per_test_seconds':3,'per_test_address_space_bytes':1073741824,'per_test_rss_limit_bytes':805306368,'total_timeout_seconds':240}
assert summary['cpython_each_linkage']=={'tests':802,'failures':2,'reported_skips':14,'expected_failures':3}
assert 'charges the callback name length before its terminator' in human
assert 'charges the original name length' not in human
assert read(D/'oriole-write-detached-end-frames-docs.py')==read('/tmp/oriole-write-detached-end-frames-docs.py')

manual_findings=[
 'Runtime eligibility and owned-name/raw/accounting/recycling prose checked against current lib.rs/arena.rs and prior source reviews. Callback charge wording now specifies callback name length before terminator; expanded names are covered.',
 'Native and actual-Python point estimates, all group counts, six displayed median rows, and both consumer groups reconstructed from complete saved process samples; no targets rerun and no new confidence claim.',
 'All four native Batik regressions, all three generated regressions, both Python regressions, three Wayland Python wins, and no native Expat wins remain explicit.',
 'Source e7eb measured versus final344730 test-only correction and exact shared02fc/static69eb identity are explicit; normal407/33/+1 tests separated from C-only gates.',
 'Existing 4347/393 API configuration failures, canonical limits, two strictCPython failures, 14 skip decomposition, uninstrumented Rust release libraries/LSan off, custom raw-pair limitation, and End6 namespace fallback scope retained.',
 'Timing includes creation/parse/destruction, Python automatic GC remains enabled, explicit collections untimed, pinned shared-host limitation and unloaded Batik DTD retained. No PBS/fuzz/PGO extension of historical claims.',
 'Standalone End baselinea55 and unselected B1–B5/ASCII baselines/scopes are separate; no additive gain or composed negative candidate claim. Negative archive nested-member scope explicitly limited.',
 'Static instruction attribution is scoped to selected paths and does not establish the full generated elapsed regression cause.',
 'Package/origin/readback and final attachment index are separate child audit scope. Current human promise of attached final reviews becomes true when root adds those receipts before publication.'
]
snap=O/'human-snapshot';snap.mkdir(exist_ok=True)
for i,(p,t) in enumerate(texts.items()): (snap/f'{i}-{Path(p).name}').write_text(t)
report={'status':'passed','scope':'Independent saved-data and human publication review; no source edits, builds, parser/test runs or timings. Package byte/origin audit is separate.',
 'runtime_commit':'1ff7b64e4567484f42bcc974146110648c224dd3','readme_headings_warning_parent_exact':True,'toucan_headings_and_license_project_substitution_exact':True,
 'unchanged_ci_files':ci,'local_links_checked':links,'workspace_review_sha256':checked[str(O/'workspace-review.json')],
 'native_counts':{'preflights':84,'workers':588,'cohorts':196,'measured':105420,'warmups':588},
 'python_counts':{'preflights':72,'workers':504,'cohorts':168,'measured':25788,'warmups':504},
 'native':ns,'python':ps,'findings':manual_findings,'blockers':[],
 'resolved_wording':'original name length -> callback name length before its terminator; root updated human report and both generators without changing evidence.',
 'checked_files':checked,'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','files':len(checked),'local_links':len(links),'review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest()}))
