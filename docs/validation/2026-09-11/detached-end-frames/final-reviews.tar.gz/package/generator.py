"""Read-only saved-evidence audit; does not build or execute a parser or packager."""
from pathlib import Path, PurePosixPath
import ast
import collections
import difflib
import hashlib
import io
import json
import os
import subprocess
import tarfile

os.sched_setaffinity(0, {4})
OUT = Path(__file__).resolve().parent
REPO = Path('/home/dev-user/code/oss/oriole-end-frame-cells')
DOC = REPO / 'docs/validation/2026-09-11/detached-end-frames'
PACKAGER = Path('/tmp/oriole-package-detached-end-frames.py')
NEGATIVE = DOC / 'unselected-names'
RUNTIME = '1ff7b64e4567484f42bcc974146110648c224dd3'
PARENT = '5f20adfb7b36b5e95f5cb9b18bc61a8e3fe3b780'
sha = lambda b: hashlib.sha256(b).hexdigest()
read_json = lambda p: json.loads(Path(p).read_text())
inputs = {}
checks = collections.Counter()
nested_inventory = []
origin_inventory = []
findings = []


def check(value, message):
    checks['assertions'] += 1
    assert value, message


def read(path):
    path = Path(path)
    data = path.read_bytes()
    row = {'bytes': len(data), 'sha256': sha(data)}
    if str(path) in inputs:
        check(inputs[str(path)] == row, f'Input changed during audit: {path}')
    inputs[str(path)] = row
    return data


def literal_assignments(data, names):
    tree = ast.parse(data)
    result = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in names:
                    result[target.id] = ast.literal_eval(node.value)
    check(set(result) == set(names), f'Missing assignment {names}')
    return result


def entries(data):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:*') as archive:
        for member in archive.getmembers():
            check(member.name not in result, f'Duplicate archive name: {member.name}')
            check(member.isfile(), f'Nonregular archive member: {member.name}')
            name = PurePosixPath(member.name)
            check(not name.is_absolute() and '..' not in name.parts, f'Unsafe member: {name}')
            content = archive.extractfile(member).read()
            check(len(content) == member.size, f'Archive size mismatch: {name}')
            result[member.name] = content
    return result


def verify_row(row, content, label):
    check(len(content) == row['bytes'], f'Size mismatch: {label}')
    check(sha(content) == row['sha256'], f'Hash mismatch: {label}')


def verify_origin(row, label):
    origin = row.get('source', row.get('origin'))
    check(bool(origin), f'Missing origin: {label}')
    data = read(origin)
    verify_row(row, data, origin)
    origin_inventory.append({'label': label, 'origin': origin,
                             'bytes': len(data), 'sha256': sha(data)})
    return data


def binary_kind(data):
    if data.startswith(b'\x7fELF'):
        return 'ELF'
    if data.startswith(b'!<arch>\n'):
        return 'ar'
    return None


def archive_inventory(data, label, level=0):
    check(level <= 10, 'Unexpected recursive archive depth')
    files = entries(data)
    rows = []
    for name, content in files.items():
        row = {'path': name, 'bytes': len(content), 'sha256': sha(content),
               'binary_kind': binary_kind(content)}
        rows.append(row)
        if name.endswith(('.tar.gz', '.tgz', '.tar.xz', '.tar')):
            archive_inventory(content, label + '!' + name, level + 1)
    nested_inventory.append({'archive': label, 'archive_sha256': sha(data),
                             'level': level, 'members': rows})
    return files


def verify_archive(root, index_name, expected_members, expected_exclusions):
    summary = json.loads(read(root / 'summary.json'))
    index = json.loads(read(root / index_name))
    data = read(root / 'evidence.tar.gz')
    files = archive_inventory(data, str(root / 'evidence.tar.gz'))
    member_rows = index['members']
    excluded_rows = index['excluded_binaries']
    check(len(member_rows) == expected_members == len(files), 'Direct member count')
    check(len(excluded_rows) == expected_exclusions, 'Direct exclusion count')
    check(list(files) == [r['path'] for r in member_rows], 'Exact member order and set')
    check(summary['archive']['sha256'] == sha(data), 'Archive summary hash')
    check(summary['archive']['bytes'] == len(data), 'Archive summary bytes')
    check(summary['archive']['members'] == len(files), 'Archive summary count')
    check(summary['archive']['direct_binary_exclusions'] == len(excluded_rows), 'Archive exclusions')
    check(summary['archive']['raw_bytes'] == sum(map(len, files.values())), 'Archive raw bytes')
    for row in member_rows:
        content = files[row['path']]
        verify_row(row, content, row['path'])
        check(not binary_kind(content), f'Direct binary retained: {row["path"]}')
        check(content == verify_origin(row, row['path']), 'Direct origin byte equality')
    for row in excluded_rows:
        check(row['path'] not in files, 'Excluded binary present')
        check(binary_kind(verify_origin(row, 'excluded:' + row['path'])), 'Exclusion is not ELF/ar')
    return files, index, summary


def expected_paths(directories, controllers):
    paths = {}
    for prefix, directory in directories.items():
        root = Path(directory)
        check(root.is_dir(), f'Missing source directory: {directory}')
        for path in sorted(root.rglob('*')):
            if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts:
                paths[prefix + '/' + str(path.relative_to(root))] = str(path)
    for controller in controllers:
        paths['controllers/' + Path(controller).name] = controller
    return paths


def verify_complete_selection(index, expected):
    rows = index['members'] + index['excluded_binaries']
    actual = {r['path']: r['source'] for r in rows}
    check(len(rows) == len(actual), 'Selection member/exclusion overlap')
    check(actual == expected, 'Complete current source-directory/controller selection')


main, main_index, main_summary = verify_archive(DOC, 'archive-members.json', 5293, 28)
negative, negative_index, negative_summary = verify_archive(NEGATIVE, 'members.json', 6002, 22)
packager_data = read(PACKAGER)
selection = literal_assignments(packager_data, ['DIRECTORIES', 'CONTROLLERS', 'COPIES'])
verify_complete_selection(main_index, expected_paths(selection['DIRECTORIES'], selection['CONTROLLERS']))

negative_packager = read(NEGATIVE / 'package.py')
neg_directories = literal_assignments(negative_packager, ['D'])['D']
negative_controllers = [r['source'] for r in negative_index['members'] if r['path'].startswith('controllers/')]
check(len(negative_controllers) == 9, 'Negative controller inventory')
verify_complete_selection(negative_index, expected_paths(neg_directories, negative_controllers))

copies = []
for name, origin in selection['COPIES'].items():
    data = read(DOC / name)
    check(data == read(origin), f'Copied top-level record differs: {name}')
    copies.append({'path': name, 'origin': origin, 'bytes': len(data), 'sha256': sha(data)})
negative_manifest = json.loads(read(NEGATIVE / 'manifest.json'))
for name, digest in negative_manifest['files'].items():
    data = read(NEGATIVE / name)
    check(sha(data) == digest, f'Negative outer manifest {name}')
    check(data == read(Path('/tmp/oriole-name-experiments-handoff') / name), f'Negative copy {name}')
check(read(NEGATIVE / 'manifest.json') == read('/tmp/oriole-name-experiments-handoff/manifest.json'),
      'Negative manifest original copy')

# Nested B1-B5 handoffs: verify each direct member, original file, exclusions,
# and enclosing handoff manifest; the recursive inventories below also read
# every nested source archive, but do not claim fresh behavioral reviews.
nested_reviews = []
for prefix in ['b1', 'b2', 'b3', 'b4', 'b5']:
    rows = json.loads(negative[prefix + '/archive-members.json'])
    omitted = json.loads(negative[prefix + '/excluded-binaries.json'])
    manifest = json.loads(negative[prefix + '/manifest.json'])
    content = entries(negative[prefix + '/evidence.tar.gz'])
    check(list(content) == [r['path'] for r in rows], f'{prefix} nested complete member list')
    for row in rows:
        verify_row(row, content[row['path']], prefix + '/' + row['path'])
        check(content[row['path']] == verify_origin(row, prefix + '!' + row['path']),
              f'{prefix} nested origin equality')
    for row in omitted:
        check(row['path'] not in content, f'{prefix} nested exclusion')
        check(binary_kind(verify_origin(row, prefix + '!excluded:' + row['path'])), 'Nested binary magic')
    study_rows = manifest['study_files']
    check({r['path']: r for r in study_rows} == {r['path']: r for r in rows + omitted},
          f'{prefix} full nested study selection')
    for row in manifest['files']:
        verify_row(row, negative[prefix + '/' + row['path']], prefix + '/manifest:' + row['path'])
    nested_reviews.append({'handoff': prefix, 'members': len(rows), 'excluded_binaries': len(omitted),
                           'members_and_origins_exact': True, 'handoff_manifest_exact': True})

# Frozen source assembly uses the explicit runtime commit; later docs commits
# do not change which runtime this receipt verifies.
assembly = json.loads(read(DOC / 'assembly.json'))
source_bytes = read(DOC / 'source.json')
measured_bytes = read(DOC / 'measured-source.json')
source = json.loads(source_bytes)['source_sha256']
measured = json.loads(measured_bytes)['source_sha256']
check(assembly == main_summary['source_assembly'], 'Summary assembly exact')
check(assembly['runtime_commit'] == RUNTIME and assembly['parent_commit'] == PARENT, 'Runtime parent')
check(assembly['final_source_manifest_sha256'] == sha(source_bytes), 'Final source identity')
check(assembly['measured_source_manifest_sha256'] == sha(measured_bytes), 'Measured source identity')
check(len(source) == len(measured) == 70 and source.keys() == measured.keys(), 'Source inventory')
check(assembly['assembled_source_sha256'] == source, 'Assembled source hashes')
git_parent = subprocess.check_output(['git', 'rev-parse', RUNTIME + '^'], cwd=REPO).decode().strip()
check(git_parent == PARENT, 'Recorded Git parent')
for path, digest in source.items():
    blob = subprocess.check_output(['git', 'show', RUNTIME + ':' + path], cwd=REPO)
    check(sha(blob) == digest == sha(read(REPO / path)), f'Committed/live source {path}')
patch = subprocess.check_output(['git', 'diff', PARENT, RUNTIME, '--binary'], cwd=REPO)
check(sha(patch) == assembly['final_patch_sha256'], 'Exact committed patch hash')
check(patch == main['corrected-source/candidate.patch'], 'Exact committed patch bytes')
source_archives = []
for name, mapping in [
    ('composition/source.tar.gz', measured),
    ('measured-build-profile/source.tar.gz', measured),
    ('initial-workspace-failure/workspace-checks/source.tar.gz', measured),
    ('corrected-source/source.tar.gz', source),
    ('final-build/source.tar.gz', source),
    ('workspace/workspace-checks/source.tar.gz', source),
]:
    content = entries(main[name])
    check(set(content) == set(mapping), f'Source archive member set: {name}')
    check(all(sha(content[path]) == digest for path, digest in mapping.items()), f'Source archive hashes: {name}')
    source_archives.append({'archive': name, 'sha256': sha(main[name]), 'source_files': len(mapping)})
delta = [p for p in source if source[p] != measured[p]]
check(delta == assembly['test_only_delta'] == ['crates/oriole_expat/src/tests.rs'], 'Only test source changed')
old_tests = entries(main['composition/source.tar.gz'])[delta[0]].decode()
new_tests = entries(main['corrected-source/source.tar.gz'])[delta[0]].decode()
expected_tests = old_tests.replace('.store(MAX_FAMILY_CALLBACK_BYTES - remaining, Ordering::Relaxed);',
                                   '.set(MAX_FAMILY_CALLBACK_BYTES - remaining);').replace(
    'family.callback_bytes.load(Ordering::Relaxed)', 'family.callback_bytes.get()')
check(expected_tests == new_tests, 'Exactly two test accessor corrections')
check(old_tests.count('.store(MAX_FAMILY_CALLBACK_BYTES - remaining, Ordering::Relaxed);') == 1,
      'Single corrected store')
check(old_tests.count('family.callback_bytes.load(Ordering::Relaxed)') == 1, 'Single corrected load')
build = json.loads(read(DOC / 'build.json'))
measured_build = json.loads(read(DOC / 'measured-build.json'))
check(build['libraries'] == measured_build['libraries'], 'Recorded libraries identical')
library_rows = []
for filename, digest in build['libraries'].items():
    final = read(Path('/tmp/oriole-end-frame-cells-final-thinlto-study') / filename)
    original = read(Path('/tmp/oriole-end-frame-cells-thinlto-study') / filename)
    check(sha(final) == digest and final == original, 'Whole measured/final library bytes identical')
    library_rows.append({'path': filename, 'sha256': digest, 'bytes': len(final)})

# Preserve the failed packager and check its correction without executing it.
failed = main['packaging-initial-attempt/package.py']
error = main['packaging-initial-attempt/stderr.log'].decode()
failure = json.loads(main['packaging-initial-attempt/report.json'])
check(sha(failed) == failure['failed_script_sha256'], 'Failed script receipt')
check("KeyError: 'all_target_binaries'" in error, 'Original failure traceback')
failed_text = failed.decode()
expected_packager = failed_text.replace(
    "DIRECTORIES = {'composition':", "DIRECTORIES = {'packaging-initial-attempt': '/tmp/oriole-detached-end-frames-package-initial-attempt', 'composition':"
).replace("workspace['all_target_binaries'], workspace['all_target_tests_passed'], workspace['doc_tests_passed']",
          "workspace['all_target_inventory_rows'], workspace['all_target_passed'], workspace['doc_passed']")
check(expected_packager.encode() == packager_data, 'Only field names and failed-attempt inclusion changed')
check(failed_text.index("workspace['all_target_binaries']") < failed_text.index('OUT.mkdir('),
      'Failed assertion precedes output creation')
check(not failure['output_created'], 'Failure receipt says no output created')
(OUT / 'packager-correction.patch').write_text(''.join(difflib.unified_diff(
    failed_text.splitlines(keepends=True), packager_data.decode().splitlines(keepends=True),
    fromfile='initial/package.py', tofile='corrected/package.py')))

binary_inventory = [{'archive': a['archive'], **m}
                    for a in nested_inventory for m in a['members'] if m['binary_kind']]
check(not binary_inventory, 'No ELF/ar binaries in direct or recursively visited tar members')

# Capture current outer files, including the currently absent final index.
# Future attachments require a separate final-index readback, not a rewrite
# of this archive audit.
outer_snapshot = []
for path in sorted(DOC.rglob('*')):
    if path.is_file():
        data = read(path)
        outer_snapshot.append({'path': str(path.relative_to(DOC)), 'bytes': len(data), 'sha256': sha(data)})
outer_index_present = (DOC / 'files.json').exists()
if not outer_index_present:
    findings.append('The final outer files.json is not present at this snapshot; future review attachments and the final index need a separate readback.')

for path, metadata in list(inputs.items()):
    data = Path(path).read_bytes()
    check(metadata == {'bytes': len(data), 'sha256': sha(data)}, f'Input changed after audit: {path}')

outputs = {
    'outer-files-snapshot.json': outer_snapshot,
    'input-files.json': inputs,
    'archive-inventory.json': nested_inventory,
    'origin-readback.json': origin_inventory,
    'copies.json': copies,
}
for filename, obj in outputs.items():
    (OUT / filename).write_text(json.dumps(obj, indent=2) + '\n')
report = {
    'status': 'saved_archives_origins_copies_and_source_assembly_verified',
    'findings': findings,
    'blocking_findings': [],
    'cpu_affinity': sorted(os.sched_getaffinity(0)),
    'runtime_commit': RUNTIME,
    'parent_commit': PARENT,
    'main_archive': main_summary['archive'],
    'negative_archive': negative_summary['archive'],
    'complete_packager_source_directory_and_controller_selections_verified': True,
    'direct_member_and_excluded_origin_rows_verified': len(main_index['members']) + len(main_index['excluded_binaries']) + len(negative_index['members']) + len(negative_index['excluded_binaries']),
    'nested_b1_b5': nested_reviews,
    'recursive_tar_readback': {
        'archive_instances': len(nested_inventory),
        'member_instances': sum(len(a['members']) for a in nested_inventory),
        'max_depth': max(a['level'] for a in nested_inventory),
        'ELF_or_ar_members': binary_inventory,
        'scope': 'Every regular member of every .tar.gz/.tgz/.tar.xz/.tar archive reached by suffix was read and hashed. ELF and ar magic were checked at all levels. This is a byte-integrity inventory, not a fresh semantic review of all nested study results.'
    },
    'top_level_original_copies': len(copies),
    'negative_outer_manifest_original_copies': len(negative_manifest['files']) + 1,
    'assembly': {
        'committed_and_live_source_files': len(source),
        'archives': source_archives,
        'source_delta': delta,
        'exactly_two_test_accessor_changes': True,
        'measured_source_manifest_sha256': sha(measured_bytes),
        'final_source_manifest_sha256': sha(source_bytes),
        'committed_patch_sha256': sha(patch),
        'whole_library_bytes_identical': library_rows,
        'prior_compiler_review_sha256': sha(read(DOC / 'final-build-review.json')),
    },
    'initial_packaging_failure': {
        'failed_script_sha256': sha(failed),
        'corrected_script_sha256': sha(packager_data),
        'traceback_sha256': sha(main['packaging-initial-attempt/stderr.log']),
        'assertion_precedes_output_creation': True,
        'correction': 'Three workspace key names plus inclusion of the preserved failed-attempt directory; byte-exact reconstruction verified.',
        'no_packager_execution_during_review': True,
    },
    'outer_file_count_at_snapshot': len(outer_snapshot),
    'outer_files_json_present': outer_index_present,
    'input_files_verified_unchanged': len(inputs),
    'origin_readback_rows_including_nested': len(origin_inventory),
    'assertions': checks['assertions'],
    'scope': 'Read-only saved-data/package integrity audit. No source edits, builds, parser executions, tests, profiling, timing or Git writes. Existing normal-workspace and numerical claims are reviewed separately by the parent; effective compiler vectors rely on the separately copied final-build review.',
    'limitations': [
        'Direct binary exclusion counts are 28 and 22; they are not recursive exclusion counts. No ELF/ar member was found in the recursively read nested tar contents.',
        'Historical nested summaries retain their original measurement and validation scope. Packaging does not upgrade them to current-source compatibility claims.',
        'A future outer index and review attachments are not covered by the current outer snapshot.',
    ],
}
(OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
files = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
         for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'files.json'}
(OUT / 'files.json').write_text(json.dumps(files, indent=2) + '\n')
for name, row in files.items():
    check(sha((OUT / name).read_bytes()) == row['sha256'], 'Audit output readback')
print(json.dumps({'status': report['status'], 'review_sha256': sha((OUT / 'review.json').read_bytes()),
                  'main_members': len(main), 'negative_members': len(negative),
                  'recursive_tar_readback': {k: v for k, v in report['recursive_tar_readback'].items() if k != 'scope'},
                  'findings': findings, 'input_files': len(inputs), 'assertions': checks['assertions']}, indent=2))
