"""Run matched C-only ThinLTO instruction profiles for the ASCII NameChar table versus selected Cell runtime."""
from pathlib import Path
import ctypes as c
import hashlib,json,math,os,re,subprocess,signal,time

root=Path(__file__).parent;out=root/'profile';out.mkdir(exist_ok=False)
assert os.sched_getaffinity(0)=={3}
assert json.loads((root/'build.json').read_text())['status']=='passed'
source=json.loads((root/'source.json').read_text())
assert all(hashlib.sha256((Path(source['worktree'])/name).read_bytes()).hexdigest()==value for name,value in source['source_sha256'].items())
repo=Path('/home/dev-user/code/oss/oriole-ascii-name-table')
manifest=repo/'benchmarks/projects/corpus-manifest.json'
driver=Path('/tmp/oriole-grammar-bench-plain/native-driver')
profiler_root=Path('/home/dev-user/.cache/oriole/profilers/local/usr')
profiler=profiler_root/'bin/valgrind';annotator=profiler_root/'bin/callgrind_annotate'
libraries={'control':Path('/tmp/oriole-ffi-family-cell-thinlto-study/liboriole_expat.so'),'candidate':root/'liboriole_expat.so'}
fixtures={p['name']:(manifest.parent/next(f['path'] for f in p['files'] if f['role']=='input')).resolve() for p in json.loads(manifest.read_text())['projects']}
assert len(fixtures)==6
conditions=[{'workload':name,'input':str(path),'namespaces':ns,'chunk':4096,'kind':'project'} for name,path in fixtures.items() for ns in [False,True]]
for name,path in [('rare-declarations',Path('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml')),('entities',Path('/tmp/oriole-grammar-bench-plain/entities.xml'))]:
 for chunk in [4096,65536]:conditions.append({'workload':name,'input':str(path),'namespaces':False,'chunk':chunk,'kind':'generated'})
assert len(conditions)==16
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(libraries['control'])=='0cfd610876f1bfd26a4d37a7f86adc9961896dfe24177c180ec7d15e0bae04e9'
assert sha(libraries['candidate'])==json.loads((root/'build.json').read_text())['libraries']['liboriole_expat.so']
assert json.loads((root/'compiler-comparison.json').read_text())['status']=='matched_after_private_paths_only'
inputs=[manifest,driver,profiler,annotator,Path(__file__),root/'source.json',root/'candidate.patch',root/'build.json',root/'compiler-comparison.json',Path('/tmp/oriole-ffi-family-cell-thinlto-study/source.json'),Path('/tmp/oriole-ffi-family-cell-thinlto-study/build.json'),*libraries.values(),*(Path(row['input']) for row in conditions)]
env=os.environ|{'VALGRIND_LIB':str(profiler_root/'libexec/valgrind'),'LD_PRELOAD':'','LD_LIBRARY_PATH':''}
protocol={'scope':'Callgrind XML_Parse-only instructions with callbacks. Both libraries use matched C-only ThinLTO; Cell0cfd control versus ASCII table02fd candidate. Six projects, namespaces off/on,4KiB; two generated controls at4KiB/64KiB. Constructor/free/file IO excluded. One warmup plus one measured parse per process, both collected. All16 conditions and32 engine profiles retained; no wall-time inference.','conditions':conditions,'libraries':{k:str(v) for k,v in libraries.items()},'hashes_before':{str(p):sha(p) for p in inputs},'affinity':[3],'profile_processes':32,'preflight_processes':32,'env_overrides':{'VALGRIND_LIB':env['VALGRIND_LIB'],'LD_PRELOAD':'','LD_LIBRARY_PATH':''}}
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
class DlInfo(c.Structure):
 _fields_=[('fname',c.c_char_p),('fbase',c.c_void_p),('sname',c.c_char_p),('saddr',c.c_void_p)]
dynamic=c.CDLL(None);dynamic.dladdr.argtypes=[c.c_void_p,c.POINTER(DlInfo)];dynamic.dladdr.restype=c.c_int
origins={}
for label,path in libraries.items():
 lib=c.CDLL(str(path));info=DlInfo();assert dynamic.dladdr(c.cast(lib.XML_Parse,c.c_void_p),c.byref(info))
 origin=Path(os.fsdecode(info.fname)).resolve();assert origin==path.resolve()
 origins[label]={'path':str(origin),'sha256':sha(origin)}
(out/'origins.json').write_text(json.dumps(origins,indent=2)+'\n')
attempts=[]
def invoke(command,stem,timeout=300):
 row={'stem':stem,'command':command,'affinity':[3],'timeout_seconds':timeout,'started':time.time()};attempts.append(row)
 def save():(out/'commands.json').write_text(json.dumps(attempts,indent=2)+'\n')
 save();process=None
 with (out/(stem+'.stdout')).open('wb') as stdout,(out/(stem+'.stderr')).open('wb') as stderr:
  try:
   process=subprocess.Popen(command,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
   row['returncode']=process.wait(timeout=timeout)
   if row['returncode']:
    try:os.killpg(process.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    raise RuntimeError(stem+' returned nonzero')
  except BaseException as error:
   row['exception']=repr(error)
   if process is not None:
    try:os.killpg(process.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    row['returncode']=process.wait()
   raise
  finally:
   stdout.flush();stderr.flush();row['elapsed_seconds']=time.time()-row['started'];row['stdout_sha256']=sha(out/(stem+'.stdout'));row['stderr_sha256']=sha(out/(stem+'.stderr'));save()
 return (out/(stem+'.stdout')).read_text()
def observations(stdout):
 data=json.loads(stdout);samples=data['samples']
 assert len(samples)==2 and [s['warmup'] for s in samples]==[True,False]
 return sorted({(s['hash'],s['elements'],s['text_bytes']) for s in samples})
preflights=[]
for index,row in enumerate(conditions):
 observed={}
 for label,path in libraries.items():
  stem=f'{index:02}-{row["workload"]}-ns{int(row["namespaces"])}-{row["chunk"]}-{label}'
  command=[str(driver),str(path),row['input'],str(row['chunk']),'1']+(['namespaces'] if row['namespaces'] else [])
  observed[label]=observations(invoke(command,stem+'-preflight',30));preflights.append({'condition':index,'library':label,'command':command,'observed':observed[label]})
 assert observed['control']==observed['candidate'],(row,observed)
(out/'preflights.json').write_text(json.dumps(preflights,indent=2)+'\n')
report={'status':'running','rows':[],'scope':protocol['scope']}
for index,row in enumerate(conditions):
 for label,path in libraries.items():
  stem=f'{index:02}-{row["workload"]}-ns{int(row["namespaces"])}-{row["chunk"]}-{label}'
  output=out/(stem+'.callgrind')
  command=[str(profiler),'--tool=callgrind','--collect-atstart=no','--toggle-collect=XML_Parse','--callgrind-out-file='+str(output),str(driver),str(path),row['input'],str(row['chunk']),'1']+(['namespaces'] if row['namespaces'] else [])
  observed=observations(invoke(command,stem));expected=next(r['observed'] for r in preflights if r['condition']==index and r['library']==label);assert observed==expected
  total=int(re.search(r'^summary: (\d+)',output.read_text(),re.M).group(1));assert total>0
  annotated=invoke([str(annotator),'--auto=no','--threshold=100','--show-percs=no',str(output)],stem+'-annotation')
  functions=[]
  for line in annotated.splitlines():
   match=re.match(r'^\s*([\d,]+)\s+(.+?) \[([^\]]+)\]$',line)
   if match:functions.append({'Ir':int(match[1].replace(',','')),'function':match[2],'object':match[3]})
  report['rows'].append(row|{'condition':index,'library':label,'command':command,'Ir':total,'observed':observed,'functions':functions,'unparsed_Ir':total-sum(f['Ir'] for f in functions)})
  (out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(stem,total,flush=True)
comparisons=[]
for index,row in enumerate(conditions):
 values={r['library']:r['Ir'] for r in report['rows'] if r['condition']==index}
 comparisons.append(row|values|{'candidate_over_control':values['candidate']/values['control']})
report['comparisons']=comparisons
report['project_instruction_ratio_geomean']=math.exp(sum(math.log(r['candidate_over_control']) for r in comparisons if r['kind']=='project')/12)
report['hashes_after']={p:sha(p) for p in protocol['hashes_before']};assert report['hashes_after']==protocol['hashes_before']
report['status']='passed';(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','project_instruction_ratio_geomean':report['project_instruction_ratio_geomean'],'comparisons':comparisons}))
