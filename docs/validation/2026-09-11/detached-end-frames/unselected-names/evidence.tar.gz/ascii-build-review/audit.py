from pathlib import Path
import hashlib,json,os,re,shlex,tarfile
assert os.sched_getaffinity(0)=={4}
D=Path('/tmp/oriole-ascii-name-table-thinlto-study');B=Path('/tmp/oriole-ffi-family-cell-thinlto-study');O=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest();tracked={};checks=[]
def read(p):
 p=Path(p);b=p.read_bytes();assert tracked.setdefault(str(p),sha(b))==sha(b);return b
def j(p):return json.loads(read(p))
def ck(v,m):assert v,m;checks.append(m)
build=j(D/'build.json');base=j(B/'report.json');source=j(D/'source.json');rows=j(D/'compiler-invocations.json');oldrows=j(B/'compiler-invocations.json')
ck(build['status']=='passed' and build['fresh_workspace_compiles']==3 and build['source_unchanged'] and build['original_unchanged'],'saved complete build')
ck(build['source_manifest_sha256']==sha(read(D/'source.json'))=='725e6e04d4926d300a3d14e2326a115489c67497458752d077b15d883100cf13','exact measured source')
with tarfile.open(D/'source.tar.gz') as t:
 members=t.getmembers();ck(len(members)==70 and all(m.isfile() for m in members),'70 regular source members')
 for m in members:ck(sha(t.extractfile(m).read())==source['source_sha256'][m.name]==sha(read(Path(source['worktree'])/m.name)),'archive/live source '+m.name)
for row in build['commands']:ck(row['exit']==0 and row['affinity']==[3] and sha(read(D/(row['label']+'.log')))==row['log_sha256'],'exact build log '+row['label'])
raw=read(D/'release.log').decode();parsed=[]
for line in raw.splitlines():
 if 'Running `' not in line or '/rustc ' not in line:continue
 args=shlex.split(line.strip()[len('Running `'):-1]);parsed.append({'crate':args[args.index('--crate-name')+1],'command_line':line,'codegen_options':[args[i+1] for i,x in enumerate(args[:-1]) if x=='-C'],'crate_types':[args[i+1] for i,x in enumerate(args[:-1]) if x=='--crate-type']})
ck(parsed==rows,'all compiler records reconstructed from actual verbose invocations')
normalized={}
for label,rs,work in [('control',oldrows,'/home/dev-user/code/oss/oriole-ffi-family-cell'),('candidate',rows,source['worktree'])]:
 normalized[label]={}
 for crate in ['oriole_storage','oriole','oriole_expat']:
  selected=[r for r in rs if r['crate']==crate];ck(len(selected)==1,'one fresh full workspace compile '+label+'/'+crate);r=selected[0]
  text=r['command_line'].replace(work,'<WORKTREE>');text,n=re.subn(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}','<PRIVATE_BUILD>',text);ck(n>=3,'only private normalization '+label+'/'+crate);normalized[label][crate]=text
  ck(('lto=thin' if crate=='oriole_expat' else 'linker-plugin-lto') in r['codegen_options'],'effective ThinLTO '+label+'/'+crate)
  if crate=='oriole_expat':ck(r['crate_types']==['cdylib','staticlib'],'actual C-only outputs '+label)
ck(normalized['control']==normalized['candidate'] and normalized==build['compiler_comparison']['normalized']==j(D/'compiler-comparison.json')['normalized'],'exact complete workspace compiler match')
ck(build['rustc_version']==base['rustc_version']==read(D/'rustc-version.log').decode(),'compiler version exact')
envdiff={k:{'control':base['env_overrides'].get(k),'candidate':build['env_overrides'].get(k)} for k in set(base['env_overrides'])|set(build['env_overrides']) if base['env_overrides'].get(k)!=build['env_overrides'].get(k)}
ck(set(envdiff)=={'CARGO_TARGET_DIR'},'recorded environment exact except distinct target')
script=read(D/'build.py').decode()
controlsource=j(B/'source.json')['source_sha256'];deltas=[n for n,digest in controlsource.items() if source['source_sha256'][n]!=digest]
ck(deltas==['crates/oriole/src/tag.rs','crates/oriole_expat/README.md'],'ASCII runtime/test delta plus inherited C README only')
prior=j('/tmp/oriole-ascii-name-table-independent-review/review.json')
ck(sha(read('/tmp/oriole-ascii-name-table-independent-review/review.json'))=='02184f26bfb8ebe2a1c0bbb1be0d3a5951973a32d7833794da0686b717b88f2d' and prior['source_sha256']==sha(read(D/'source.json')),'same independent source review')
ck(sha(read(D/'candidate.patch'))==prior['patch_sha256']=='b3a9444ff5c08e3c7fe7a2520555424084262507029d90cbce33dae5d46e8873','exact reviewed patch')
for n,digest in build['libraries'].items():ck(sha(read(D/n))==digest,'built library '+n)
for p,digest in build['original_hashes'].items():ck(sha(read(p))==digest,'original input preserved '+p)
for p,digest in tracked.items():ck(sha(Path(p).read_bytes())==digest,'finish unchanged '+p)
for n in ['build.py','build.json','compiler-invocations.json','compiler-comparison.json','source.json']:(O/n).write_bytes(read(D/n))
(O/'files.json').write_text(json.dumps(tracked,indent=2)+'\n');(O/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
review={'status':'independent_ascii_table_fresh_compiler_source_audit_passed','findings':[],'scope':'Read-only saved-build audit; no compiler or target reruns. Source correctness remains separate independent02184 review, rehashed here.','source_manifest_sha256':sha(read(D/'source.json')),'source_files':70,'libraries':build['libraries'],'workspace_compiles':3,'actual_compiler_vectors_equal_after_private_paths_only':True,'actual_final_crate_types':['cdylib','staticlib'],'actual_final_lto':'thin','build_environment_differences':envdiff,'environment_scope':'Complete compiler vectors match Cell0cfd after private paths only. Every recorded environment override matches except the distinct target directory.','limitations':['Saved verbose logs establish the three actual workspace compiler invocations and input/output hashes, not a re-execution.','No full workspace/API/CPython or elapsed result inferred.','Actual Cell0cfd source differs only in reviewed tag.rs and the inherited C-interface README; all68 other tracked source bytes equal. No namespace B5 or detached-End code is composed.'],'checks':len(checks),'generator_sha256':sha(Path(__file__).read_bytes())}
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n');print(sha((O/'review.json').read_bytes()))
