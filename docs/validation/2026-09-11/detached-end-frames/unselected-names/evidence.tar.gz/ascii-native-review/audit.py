"""Independent saved native timing audit; no project code or parser execution."""
from pathlib import Path
from collections import Counter
import difflib
import hashlib
import io
import json
import math
import os
import random
import statistics
import sys
import tarfile

R=Path('/tmp/oriole-ascii-name-table-thinlto-timing-study')
S=R/'native-screen'
O=Path(__file__).resolve().parent
assert sorted(os.sched_getaffinity(0))==[4]
tracked={};checks=[]
def read(path):
    path=Path(path);raw=path.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(path),value)==value,str(path)
    return raw
def h(path):read(path);return tracked[str(path)]
def j(path):return json.loads(read(path))
def ck(name,condition):
    checks.append({'name':name,'passed':bool(condition)})
    assert condition,name
key=lambda value:json.dumps(value,sort_keys=True)
engines=['published','candidate','expat']
ratio_names=['candidate_over_published','candidate_over_expat','published_over_expat']
expected_hashes={
 'published':'0cfd610876f1bfd26a4d37a7f86adc9961896dfe24177c180ec7d15e0bae04e9',
 'candidate':'02fd0819efd4b48d87974811737d3de64fe38a617f1f9d9bb6fd69f10a42b1c5',
 'expat':'7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478',
}
protocol=j(S/'protocol.json');pre=j(S/'preflight.json');results=j(S/'results.json')
ck('protocol full design',protocol['pairs']==7 and protocol['seed']==2026091003 and protocol['preflights']==84 and protocol['timed_workers']==588)
ck('completed phase records',pre['status']==results['status']=='passed' and results['affinity']==[0])
ck('phase linkage',pre['protocol_sha256']==results['protocol_sha256']==h(S/'protocol.json') and results['preflight_sha256']==h(S/'preflight.json'))
for label,report in [('preflight',pre),('timing',results)]:
    ck(label+' before/after hashes exact',report['hashes_before']==report['hashes_after']==protocol['hashes'])
ck('all protocol file hashes current',all(h(path)==value for path,value in protocol['hashes'].items()))
for engine in engines:
    entry=protocol['libraries'][engine]
    ck('pinned library '+engine,h(entry['path'])==entry['sha256']==expected_hashes[engine])

preparation=j(R/'preparation.json');controller=j(R/'timing-controller.json')
ck('preflight controller passed original CPU3',preparation['status']=='passed' and preparation['exit']==0 and preparation['command']==['taskset','-c','3','python3',str(R/'native_screen.py'),'preflight'])
timing_controller=Path('/tmp/oriole-time-ascii-name-table-thinlto-native.py')
ck('timing controller passed recorded CPU0 and code hash',controller['status']=='passed' and controller['exit']==0 and not controller.get('timeout') and controller['controller_sha256']==h(timing_controller) and controller['command']==['taskset','-c','0','python3',str(R/'native_screen.py'),'time'])
ck('timing controller completion below outer bound',0<controller['elapsed_seconds']<1200)
old_path=Path('/tmp/oriole-thinlto-production-timing-study/native_screen.py')
old=read(old_path).decode()
adapted=old.replace('/tmp/oriole-thinlto-production-timing-study',str(R))
adapted=adapted.replace('/tmp/oriole-thinlto-production-study/thinlto/liboriole_expat.so',protocol['libraries']['candidate']['path'])
adapted=adapted.replace('/tmp/oriole-thinlto-production-study/normal/liboriole_expat.so',protocol['libraries']['published']['path'])
adapted=adapted.replace('effective C-only ThinLTO build','ASCII name classification table in a C-only ThinLTO build')
adapted=adapted.replace('matched normal/9815cc85','published private FFI family Cell runtime with ThinLTO/0cfd6108')
adapted=adapted.replace('same-source effective ThinLTO/a55ca0f0 candidate','ASCII name table ThinLTO/02fd0819 candidate')
adapted=adapted.replace('Oriole C-only candidate enables configured ThinLTO; matched normal and pinned Expat retain their original non-LTO flags.','Both Oriole C-only libraries use matched ThinLTO flags; pinned Expat retains its original non-LTO flags.')
ck('frozen timing controller only declared path and method edits',adapted==read(R/'native_screen.py').decode())
patch=''.join(difflib.unified_diff(old.splitlines(True),adapted.splitlines(True),fromfile='reviewed-thinlto-native',tofile='ascii-name-table-thinlto-native'))
ck('retained controller patch exact',patch==read(R/'controller.patch').decode())
read(R/'oriole-prepare-ascii-name-table-thinlto-timing.py')

candidate_root=Path('/tmp/oriole-ascii-name-table-thinlto-study')
source_review_path=Path('/tmp/oriole-ascii-name-table-independent-review/review.json')
profile_review_path=Path('/tmp/oriole-ascii-name-table-profile-independent-review/review.json')
ck('pinned completed ASCII source review',h(source_review_path)=='02184f26bfb8ebe2a1c0bbb1be0d3a5951973a32d7833794da0686b717b88f2d' and j(source_review_path)['status']=='independent_ascii_name_table_source_review_passed')
ck('candidate source receipt identity only',h(candidate_root/'source.json')==preparation['source_manifest_sha256']==j(source_review_path)['source_sha256']=='725e6e04d4926d300a3d14e2326a115489c67497458752d077b15d883100cf13')
ck('separate instruction audit remains frozen',h(profile_review_path)=='fec62facb32768a29d8be8589358234b670a2eba8e83386c945b298ab304830f' and j(profile_review_path)['status']=='independent_saved_ascii_table_profile_audit_passed')
prior_review_path=Path('/tmp/oriole-ffi-family-cell-thinlto-native-independent-review/review.json')
ck('pinned reviewed Cell native protocol',h(prior_review_path)=='7a32289080e999735b88f873174b47ab72c9b375678459b875e04b82abd55566')
prior_files=j(prior_review_path.parent/'checked-files.json')
cell_controller=Path('/tmp/oriole-ffi-family-cell-thinlto-timing-study/native_screen.py')
ck('prior Cell native source exact reviewed bytes',h(cell_controller)==prior_files[str(cell_controller)])
cell=read(cell_controller).decode()
cell_adapted=cell.replace('/tmp/oriole-ffi-family-cell-thinlto-timing-study',str(R))
cell_adapted=cell_adapted.replace('/tmp/oriole-ffi-family-cell-thinlto-study/liboriole_expat.so',protocol['libraries']['candidate']['path']).replace('/tmp/oriole-thinlto-production-study/thinlto/liboriole_expat.so',protocol['libraries']['published']['path'])
cell_adapted=cell_adapted.replace('private FFI family counters in a C-only ThinLTO build','ASCII name classification table in a C-only ThinLTO build').replace('published runtime with ThinLTO/a55ca0f0','published private FFI family Cell runtime with ThinLTO/0cfd6108').replace('private FFI family Cell ThinLTO/0cfd6108 candidate','ASCII name table ThinLTO/02fd0819 candidate')
ck('native protocol exact reviewed Cell after paths and descriptive text only',cell_adapted==read(R/'native_screen.py').decode())
(O/'cell-controller-comparison.patch').write_text(''.join(difflib.unified_diff(cell.splitlines(True),cell_adapted.splitlines(True),fromfile=str(cell_controller),tofile=str(R/'native_screen.py'))))
cell_timing=Path('/tmp/oriole-time-ffi-family-cell-thinlto-native.py')
ck('outer timing process controller exact reviewed Cell after path only',h(cell_timing)==prior_files[str(cell_timing)] and read(cell_timing).decode().replace('/tmp/oriole-ffi-family-cell-thinlto-timing-study',str(R))==read(timing_controller).decode())
build_receipt=j(candidate_root/'build.json')
ck('candidate runtime identity linked to saved build receipt',build_receipt['status']=='passed' and build_receipt['libraries']['liboriole_expat.so']==expected_hashes['candidate'] and build_receipt['source_manifest_sha256']==h(candidate_root/'source.json'))

manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
manifest=j(manifest_path)
fixtures={};fixture_rows=[]
for project in manifest['projects']:
    entry=next(row for row in project['files'] if row['role']=='input')
    path=(manifest_path.parent/entry['path']).resolve()
    ck('original project bytes '+project['name'],h(path)==entry['sha256'])
    fixtures[project['name']]=str(path)
    fixture_rows.append({'name':project['name'],'input':str(path),'sha256':h(path),'bytes':len(read(path))})
ck('six real project names',set(fixtures)=={'vulkan','wayland','maven','batik','gtk','docbook'})
fixtures['generated-rare-declarations']='/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml'
fixtures['generated-entities']='/tmp/oriole-grammar-bench-plain/entities.xml'
fixed={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
conditions=[{'name':name,'input':path,'chunk':chunk,'namespaces':ns,'iterations':fixed[name]} for chunk in [4096,65536] for name,path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False,True])]
ck('all28 conditions exactly reconstructed',protocol['conditions']==conditions and len({key(c) for c in conditions})==28)
ck('24real and4generated conditions',sum(not c['name'].startswith('generated-') for c in conditions)==24)

driver=Path('/tmp/oriole-grammar-bench-plain/native-driver')
driver_source=Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')
origin_path=Path('/tmp/oriole-grammar-bench-plain/summary.json');origin=j(origin_path)
ck('retained native driver original build identities',origin['status']=='passed' and origin['sha256_before'][str(driver)]==origin['sha256_after'][str(driver)]==h(driver) and origin['sha256_before'][str(driver_source)]==origin['sha256_after'][str(driver_source)]==h(driver_source))
driver_code=read(driver_source).decode()
ck('native driver explicit handle resolution','dlopen(argv[1], RTLD_NOW | RTLD_LOCAL)' in driver_code and 'dlsym(library, symbol)' in driver_code)
ck('timer encompasses construct/setup/parse/free after loading',driver_code.index('fread(data')<driver_code.index('double before = now();')<driver_code.index('Parser parser =')<driver_code.index('api.destroy(parser);\n        double elapsed = now() - before;'))

ordinal=0;streams=[];observed_by_condition={};sample_counts=Counter();process_medians={key(c):{engine:[] for engine in engines} for c in conditions}
def process(row,condition,pair,cpu,count):
    global ordinal
    worker=S/f'worker-{ordinal:04d}.json';saved=j(worker)
    ck('immediate worker original fields '+str(ordinal),set(saved)=={'condition','engine','pair','command','returncode','stdout','stderr'} and saved=={field:row[field] for field in saved})
    ck('worker metadata '+str(ordinal),row['condition']==condition and row['pair']==pair and row['engine'] in engines and row['returncode']==0 and row['stderr']=='')
    engine=row['engine'];command=['taskset','-c',str(cpu),str(driver),protocol['libraries'][engine]['path'],condition['input'],str(condition['chunk']),str(count)]+(['namespaces'] if condition['namespaces'] else [])
    ck('worker command '+str(ordinal),row['command']==command)
    data=json.loads(row['stdout']);samples=data['samples']
    ck('worker output version '+str(ordinal),data['version']==('expat_2.8.4' if engine=='expat' else 'oriole_compat_2.8.4') and set(data)=={'version','samples'})
    ck('all sample fields '+str(ordinal),all(set(sample)=={'iteration','warmup','seconds','hash','elements','text_bytes'} and isinstance(sample['seconds'],(int,float)) and math.isfinite(sample['seconds']) and sample['seconds']>0 and isinstance(sample['elements'],int) and sample['elements']>=0 and isinstance(sample['text_bytes'],int) and sample['text_bytes']>=0 and len(sample['hash'])==16 and all(ch in '0123456789abcdef' for ch in sample['hash']) for sample in samples))
    ck('sample count/indices/warmup '+str(ordinal),len(samples)==count+1 and [sample['iteration'] for sample in samples]==list(range(count+1)) and [sample['warmup'] for sample in samples]==[True]+[False]*count)
    observations=sorted({(sample['hash'],sample['elements'],sample['text_bytes']) for sample in samples})
    ck('sample callback observations '+str(ordinal),len(observations)==1 and row['observations']==[list(value) for value in observations])
    median=statistics.median(sample['seconds'] for sample in samples[1:])
    ck('worker median exact '+str(ordinal),median==row['median_seconds'])
    stage='preflight' if pair==-1 else 'timed'
    sample_counts[stage+'_workers']+=1;sample_counts[stage+'_warmups']+=1;sample_counts[stage+'_measured']+=count
    streams.append({'ordinal':ordinal,'worker_sha256':h(worker),'condition':condition,'pair':pair,'engine':engine,'stdout_sha256':hashlib.sha256(row['stdout'].encode()).hexdigest(),'stderr_sha256':hashlib.sha256(row['stderr'].encode()).hexdigest(),'measured_samples':count,'median_seconds':median})
    ordinal+=1
    return observations,median

ck('84 preflight records',len(pre['rows'])==84)
for index,condition in enumerate(conditions):
    rows=pre['rows'][3*index:3*index+3]
    ck('preflight engine order '+str(index),[row['engine'] for row in rows]==engines)
    observations=[process(row,condition,-1,3,1)[0] for row in rows]
    ck('three-engine preflight observations '+str(index),observations[0]==observations[1]==observations[2])
    observed_by_condition[key(condition)]=observations[0]

rng=random.Random(protocol['seed']);jobs=[(condition,pair) for condition in conditions for pair in range(7)];rng.shuffle(jobs)
ck('196 complete unique cohorts',len(results['rows'])==len(jobs)==196 and len({(key(row['condition']),row['pair']) for row in results['rows']})==196)
ratios={key(c):{name:[] for name in ratio_names} for c in conditions}
for index,((condition,pair),group) in enumerate(zip(jobs,results['rows'],strict=True)):
    order=engines.copy();rng.shuffle(order)
    ck('seeded cohort and engine order '+str(index),group['condition']==condition and group['pair']==pair and group['order']==order and [row['engine'] for row in group['processes']]==order)
    seconds={}
    for row in group['processes']:
        observations,median=process(row,condition,pair,0,condition['iterations'])
        ck('timed observations equal preflight',observations==observed_by_condition[key(condition)])
        seconds[row['engine']]=median;process_medians[key(condition)][row['engine']].append(median)
    for name in ratio_names:
        numerator,denominator=name.split('_over_');ratios[key(condition)][name].append(seconds[numerator]/seconds[denominator])
computed=[{'condition':c,'paired_ratios':ratios[key(c)],'median_ratios':{name:statistics.median(values) for name,values in ratios[key(c)].items()}} for c in conditions]
ck('all588 paired ratios and84 medians exact',results['summary']==computed)
ck('exact672 immediate worker files no extras',ordinal==672 and sorted(p.name for p in S.glob('worker-*.json'))==[f'worker-{index:04d}.json' for index in range(672)])
ck('sample counts all retained',dict(sample_counts)=={'preflight_workers':84,'preflight_warmups':84,'preflight_measured':84,'timed_workers':588,'timed_warmups':588,'timed_measured':105420})
groups={}
for label,predicate in [('real',lambda c:not c['name'].startswith('generated-')),('generated',lambda c:c['name'].startswith('generated-')),('real-namespaces-off',lambda c:not c['name'].startswith('generated-') and not c['namespaces']),('real-namespaces-on',lambda c:not c['name'].startswith('generated-') and c['namespaces'])]:
    selected=[row for row in computed if predicate(row['condition'])]
    groups[label]={'conditions':len(selected),'ratios':{}}
    for name in ratio_names:
        values=[row['median_ratios'][name] for row in selected]
        groups[label]['ratios'][name]={'geomean':math.exp(sum(math.log(value) for value in values)/len(values)),'below_one':sum(value<1 for value in values)}
published=j(R/'summary.json')
ck('published real/generated group summaries exact',published['groups']=={key:groups[key] for key in ['real','generated']})
regressions=[{'condition':row['condition'],'ratio':row['median_ratios']['candidate_over_published']} for row in computed if row['median_ratios']['candidate_over_published']>1]
ck('all real or generated regressions retained',published['regressions']==regressions)
ck('all8 regressions and18real2generated lower',len(regressions)==8 and groups['real']['ratios']['candidate_over_published']['below_one']==18 and groups['generated']['ratios']['candidate_over_published']['below_one']==2)
ck('reported real point estimate',groups['real']['ratios']['candidate_over_published']['geomean']==0.9920471961937518)
ck('all four generated conditions and every candidate/Expat ratio retained',groups['generated']['conditions']==4 and all(math.isfinite(row['median_ratios']['candidate_over_expat']) and row['median_ratios']['candidate_over_expat']>0 for row in computed))
ck('reported generated point estimate',groups['generated']['ratios']['candidate_over_published']['geomean']==1.008143180115995)
preflight_log=json.loads(read(R/'preflight-controller.log'))
timing_log=json.loads(read(R/'timing-controller.log'))
ck('outer preflight log agrees',preflight_log=={'status':'passed','preflights':84,'protocol_sha256':h(S/'protocol.json')})
ck('outer timing log all summaries retained',timing_log=={'status':'passed','timed_workers':588,'summary':computed})
ck('all inspected input files unchanged at audit end',all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected for path,expected in tracked.items()))

condition_table=[]
for row in computed:
    condition=row['condition']
    condition_table.append({'condition':condition,'median_process_seconds':{engine:statistics.median(values) for engine,values in process_medians[key(condition)].items()},'median_ratios':row['median_ratios'],'paired_ratios':row['paired_ratios']})
(O/'streams.json').write_text(json.dumps(streams,indent=2)+'\n')
(O/'conditions.json').write_text(json.dumps(condition_table,indent=2)+'\n')
(O/'groups.json').write_text(json.dumps(groups,indent=2)+'\n')
(O/'checked-files.json').write_text(json.dumps(tracked,indent=2,sort_keys=True)+'\n')
report={
 'status':'independent_saved_native_audit_passed',
 'scope':'Saved-data-only native timing source/hash/metadata/order/arithmetic audit. No parser, build, benchmark or timing executions. Separate instruction profile review remains frozen; source/build/codegen reviews are parent-owned. No full gate or adoption conclusion.',
 'audit_cpu':4,'interpreter':sys.executable,
 'counts':{'conditions':28,'real_conditions':24,'generated_conditions':4,'preflight_workers':84,'preflight_samples_with_warmups':168,'timed_workers':588,'timed_warmups':588,'timed_measured_samples':105420,'all_samples_with_preflights_and_warmups':106176,'seeded_cohorts':196,'immediate_worker_records':672,'paired_ratios':588,'per_condition_ratio_medians':84},
 'identities':{'libraries':protocol['libraries'],'source_manifest_sha256':h(candidate_root/'source.json'),'source_review_sha256':h(source_review_path),'saved_build_receipt_sha256':h(candidate_root/'build.json'),'separate_instruction_review_sha256':h(profile_review_path),'prior_Cell_native_review_sha256':h(prior_review_path),'comparison_baseline':'ASCII-table02fd versus selected private FamilyBudget Cell ThinLTO0cfd, plus pinned normal Expat7a333. Actual native controller matches reviewed Cell protocol after fixed paths/descriptive text only. Source/build/compiler lineage is separately parent-owned.','driver':{'source_sha256':h(driver_source),'binary_sha256':h(driver),'original_build_record_sha256':h(origin_path),'original_build_command':origin['build_command'],'binding':'Absolute per-process requested library path, dlopen(RTLD_LOCAL|RTLD_NOW), dlsym on that handle; version checked. No per-worker dladdr receipt.'}},
 'groups':groups,'regressions':regressions,'generated_conditions':[row for row in condition_table if row['condition']['name'].startswith('generated-')],
 'point_estimate':{'real_candidate_control_ratio':groups['real']['ratios']['candidate_over_published']['geomean'],'real_elapsed_reduction_percent':100*(1-groups['real']['ratios']['candidate_over_published']['geomean']),'real_candidate_expat_ratio':groups['real']['ratios']['candidate_over_expat']['geomean']},
 'method':['Every immediate worker record matched its copied phase record on every original field; all commands/CPUs/versions/status/stderr and106176 sample records checked.','Reconstructed conditions from pinned project manifest and retained generated inputs; fixed per-process iteration counts and exactly one excluded warmup retained.','Reproduced seed2026091003 cohort shuffle, engine order and all196 cohort labels. Recomputed process medians, all three families of paired ratios, all28 condition summaries and all published real/generated group aggregates.','Ratios are medians of seven within-cohort process-median ratios. Group results are geometric means of condition medians. Do not replace these with ratios of unpaired aggregate medians.'],
 'limits':['Native measured region includes parser construction, callback setup, XML_Parse calls/native callbacks and parser free. Input I/O, dlopen, process startup and full application work are outside the sample timer.','Selected callback FNV hashes and counts agree across engines; this does not prove exact callback fragmentation, position or API conformance.','One shared host, fixed seven cohorts, timing workers pinnedCPU0 and preflightCPU3. Pinning/shuffling does not eliminate contention or establish statistical significance.',f"Retained all {len(regressions)} candidate/control regressions, all four generated conditions and all candidate/Expat ratios. Real improvements: {groups['real']['ratios']['candidate_over_published']['below_one']}/24; generated improvements: {groups['generated']['ratios']['candidate_over_published']['below_one']}/4.",'No PGO, parser reruns, sample filtering, removal or adoption decision in this audit. Batik external DTD is not loaded by this native driver.','Driver worker timeout90s; preflight outer timeout600s; timing outer timeout1200s. Timing wrapper handles timeout with process-group kill/wait; these scripts do not provide an explicit comprehensive SIGTERM forwarding guarantee.','Recorded input, controller and runtime bytes are rehashed now and during this audit; source/build receipts are pinned without repeating source70/compiler proof. These checks cannot prove historical immutability outside recorded before/after evidence.','Source/build/codegen, Python, strict CPython and full C/workspace gates are excluded. The two Oriole libraries are labeled matched ThinLTO by separately reviewed producer receipts; no equivalent compiler flags across Rust and C or adoption claim. The16-condition instruction study and28-condition elapsed campaign are kept separate.'],
 'checked_file_count':len(tracked),'passed_checks':len(checks),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'artifact_sha256':{name:hashlib.sha256((O/name).read_bytes()).hexdigest() for name in ['streams.json','conditions.json','groups.json','checked-files.json']},
}
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest(),'checked_files':len(tracked),'checks':len(checks),'real':groups['real'],'generated':groups['generated']},indent=2))
