"""Read-only saved ASCII-table profile audit; no target execution."""
from pathlib import Path
from collections import Counter
import hashlib,json,math,os,re,difflib
assert os.sched_getaffinity(0)=={4}
OUT=Path(__file__).resolve().parent
NORMAL=Path('/tmp/oriole-ascii-name-table-thinlto-study')
CONTROL=Path('/tmp/oriole-ffi-family-cell-thinlto-study')
ROOT=Path('/home/dev-user/code/oss/oriole-ascii-name-table')
PROFILE=NORMAL/'profile'
tracked={};checks=[]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):
    path=Path(path);raw=path.read_bytes()
    assert tracked.setdefault(str(path),sha(raw))==sha(raw),('changed during audit',str(path))
    return raw
def h(path):return sha(read(path))
def j(path):return json.loads(read(path))
def ck(value,label):
    assert value,label
    checks.append(label)
def put(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def all_hashes(values,label):
    for name,value in values.items():ck(h(name)==value,label+' '+name)

prior_path=Path('/tmp/oriole-ascii-name-table-independent-review/review.json')
prior=j(prior_path)
ck(h(prior_path)=='02184f26bfb8ebe2a1c0bbb1be0d3a5951973a32d7833794da0686b717b88f2d' and prior['status']=='independent_ascii_name_table_source_review_passed','pinned independent source review')
ck(h(NORMAL/'source.json')==prior['source_sha256']=='725e6e04d4926d300a3d14e2326a115489c67497458752d077b15d883100cf13' and prior['source_files']==70,'pinned source receipt only')
ck(h(NORMAL/'candidate.patch')==prior['patch_sha256']=='b3a9444ff5c08e3c7fe7a2520555424084262507029d90cbce33dae5d46e8873','pinned exact source patch')
expected_libraries={'control':'0cfd610876f1bfd26a4d37a7f86adc9961896dfe24177c180ec7d15e0bae04e9','candidate':'02fd0819efd4b48d87974811737d3de64fe38a617f1f9d9bb6fd69f10a42b1c5'}
ck(h(CONTROL/'liboriole_expat.so')==expected_libraries['control'] and h(NORMAL/'liboriole_expat.so')==expected_libraries['candidate'],'pinned two actual library hashes')
adaptation=j(NORMAL/'profile-adaptation.json')
original=Path(adaptation['original']);old=read(original).decode();collector=read(NORMAL/'collect_profiles.py').decode()
ck(h(original)==adaptation['original_sha256']=='0f9724ef49a53713754b2309c675ebb9268576060bca58c62492ce2b46c7a8e2' and h(NORMAL/'collect_profiles.py')==adaptation['adapted_sha256']=='6ddcf75c6bc7d0a55ca6d84e966540c28cdf1ce4d5727358b29dc1990d9cf7a7','pinned original and adapted collectors')
cell_review_path=Path('/tmp/oriole-ffi-family-cell-build-profile-independent-review/review.json')
ck(h(cell_review_path)=='445e938039f95741346dcf91489137631d66ee61655b69adbd4cb66b08c380be','pinned prior collector saved-data review')
old_files=j(cell_review_path.parent/'checked-files.json')
ck(old_files[str(original)]==h(original),'original collector is previously reviewed source')
adapted=old.replace('Run the matched instruction study for private serialized FFI family counters on published start-frame integration.','Run matched C-only ThinLTO instruction profiles for the ASCII NameChar table versus selected Cell runtime.')
adapted=adapted.replace('/home/dev-user/code/oss/oriole-ffi-family-cell','/home/dev-user/code/oss/oriole-ascii-name-table').replace('/tmp/oriole-start-frame-integration-study','/tmp/oriole-ffi-family-cell-thinlto-study')
adapted=adapted.replace('9815cc852327d455c094b0fb72c1d33fb90a4571e67cf15965e96e2300376828',expected_libraries['control'])
adapted=adapted.replace('os.sched_getaffinity(0)=={4}','os.sched_getaffinity(0)=={3}').replace("'affinity':[4]","'affinity':[3]")
adapted=adapted.replace('Callgrind XML_Parse-only instructions with callbacks. Six projects','Callgrind XML_Parse-only instructions with callbacks. Both libraries use matched C-only ThinLTO; Cell0cfd control versus ASCII table02fd candidate. Six projects')
ck(adapted==collector,'collector exact prior protocol after explicit paths identity CPU and descriptive text changes')
patch=''.join(difflib.unified_diff(old.splitlines(True),collector.splitlines(True),fromfile=str(original),tofile=str(NORMAL/'collect_profiles.py')))
ck(patch==read(NORMAL/'profile-adaptation.patch').decode(),'retained profile controller diff exact')
setup_path=prior_path.parent/'setup-attempt.json';setup=j(setup_path)
ck(h(setup_path)=='ac44a44374344bf2c0bf024e0fae03025bbae2a0e7e70b22217ea2714da1c156' and setup['status']=='first destination existed; no changes made','original source setup collision retained separately')
(OUT/'retained-setup-attempt.json').write_bytes(read(setup_path))

# Reconstruct all 16 fixed instruction conditions and their selected-byte fixtures.
protocol=j(PROFILE/'protocol.json');profile=j(PROFILE/'report.json');commands=j(PROFILE/'commands.json');preflights=j(PROFILE/'preflights.json')
ck(profile['status']=='passed' and profile['scope']==protocol['scope'] and protocol['affinity']==[3] and protocol['profile_processes']==protocol['preflight_processes']==32,'instruction report completion and scope')
ck(profile['hashes_after']==protocol['hashes_before'],'instruction before/after identities equal')
all_hashes(protocol['hashes_before'],'instruction immutable inputs')
manifest_path=ROOT/'benchmarks/projects/corpus-manifest.json';manifest=j(manifest_path);conditions=[]
for project in manifest['projects']:
    entry=next(f for f in project['files'] if f['role']=='input');path=(manifest_path.parent/entry['path']).resolve()
    ck(h(path)==entry['sha256'],'project corpus exact bytes '+project['name'])
    for ns in [False,True]:conditions.append({'workload':project['name'],'input':str(path),'namespaces':ns,'chunk':4096,'kind':'project'})
for name,path in [('rare-declarations','/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml'),('entities','/tmp/oriole-grammar-bench-plain/entities.xml')]:
    for chunk in [4096,65536]:conditions.append({'workload':name,'input':path,'namespaces':False,'chunk':chunk,'kind':'generated'})
ck(protocol['conditions']==conditions and len(conditions)==16,'12 real and4 generated conditions exact')
driver=Path('/tmp/oriole-grammar-bench-plain/native-driver');driver_source=Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c');driver_receipt=j('/tmp/oriole-grammar-bench-plain/summary.json')
for path in [driver,driver_source]:ck(driver_receipt['sha256_before'][str(path)]==driver_receipt['sha256_after'][str(path)]==h(path),'retained native driver source/build identity')
driver_text=read(driver_source).decode()
ck('dlopen(argv[1], RTLD_NOW | RTLD_LOCAL)' in driver_text and 'dlsym(library, symbol)' in driver_text and 'iteration <= iterations' in driver_text,'driver selected handle and both parse iterations')
origins=j(PROFILE/'origins.json')
ck(set(origins)=={'control','candidate'} and protocol['libraries']=={'control':str(CONTROL/'liboriole_expat.so'),'candidate':str(NORMAL/'liboriole_expat.so')},'profile Cell0cfd ThinLTO control and ASCII-table02fd candidate')
for label,row in origins.items():ck(row['path']==protocol['libraries'][label] and h(row['path'])==row['sha256'],'controller dladdr exact '+label)
ck(len(commands)==96 and len({r['stem'] for r in commands})==96 and len(preflights)==len(profile['rows'])==32,'32 preflight32 profiles32 annotations')
command_map={r['stem']:r for r in commands}
for row in commands:
    ck(row['returncode']==0 and 'exception' not in row and row['affinity']==[3] and row['timeout_seconds']==(30 if row['stem'].endswith('-preflight') else 300),'profile command completed within recorded bound '+row['stem'])
    for stream in ['stdout','stderr']:ck(h(PROFILE/(row['stem']+'.'+stream))==row[stream+'_sha256'],'profile captured output identity')
def observations(path):
    data=j(path);samples=data['samples']
    ck(data['version']=='oriole_compat_2.8.4' and [s['iteration'] for s in samples]==[0,1] and [s['warmup'] for s in samples]==[True,False],'both actual parse outputs retained')
    ck(all(math.isfinite(s['seconds']) and s['seconds']>0 for s in samples),'raw positive sample fields retained without elapsed inference')
    observed=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in samples})
    ck(len(observed)==1,'stable per-process callback digest and counts')
    return [list(row) for row in observed]
profiles_by_key={};comparison_rows=[];raw_totals=[];raw_self_tables=[]
profiler='/home/dev-user/.cache/oriole/profilers/local/usr/bin/valgrind';annotator='/home/dev-user/.cache/oriole/profilers/local/usr/bin/callgrind_annotate'
for index,condition in enumerate(conditions):
    condition_observations=[]
    for label,library in protocol['libraries'].items():
        stem=f'{index:02}-{condition["workload"]}-ns{int(condition["namespaces"])}-{condition["chunk"]}-{label}'
        target=[str(driver),library,condition['input'],str(condition['chunk']),'1']+(['namespaces'] if condition['namespaces'] else [])
        output=PROFILE/(stem+'.callgrind')
        expected_profile=[profiler,'--tool=callgrind','--collect-atstart=no','--toggle-collect=XML_Parse','--callgrind-out-file='+str(output),*target]
        ck(command_map[stem+'-preflight']['command']==target and command_map[stem]['command']==expected_profile,'profile/preflight exact selected command')
        ck(command_map[stem+'-annotation']['command']==[annotator,'--auto=no','--threshold=100','--show-percs=no',str(output)],'annotation complete100percent command')
        expected=next(r for r in preflights if r['condition']==index and r['library']==label)
        observed=observations(PROFILE/(stem+'-preflight.stdout'))
        ck(expected['command']==target and expected['observed']==observed==observations(PROFILE/(stem+'.stdout')),'all preflight/profile callback observations identical')
        ck(read(PROFILE/(stem+'-preflight.stderr'))==b'','preflight stderr empty')
        condition_observations.append(observed)
        row=next(r for r in profile['rows'] if r['condition']==index and r['library']==label)
        ck(all(row[k]==v for k,v in condition.items()) and row['command']==expected_profile and row['observed']==observed,'profile exact report metadata')
        raw=read(output).decode();summary=[int(x) for x in re.findall(r'^summary: (\d+)$',raw,re.M)]
        ck(re.findall(r'^events: (.+)$',raw,re.M)==['Ir'] and summary==[row['Ir']] and row['Ir']>0,'raw Callgrind only Ir and summary identity')
        ck(re.findall(r'^cmd:  (.+)$',raw,re.M)==[' '.join(target)] and 'Trigger: Program termination' in raw,'Callgrind exact target command and completed dump')
        direct=0;skip_call=False
        for line in raw.splitlines():
            if line.startswith('calls='):skip_call=True
            elif re.match(r'^(?:\*|[+-]?\d+)\s+\d+(?:\s|$)',line):
                columns=line.split();ck(len(columns)==2,'Ir cost row dimension')
                if skip_call:skip_call=False
                else:direct+=int(columns[1])
        ck(not skip_call and direct==row['Ir'],'independent sum of raw self-cost instructions excluding call edges')
        # Resolve shared Callgrind object/file/function IDs and sum only self edges.
        names={'ob':{},'fl':{},'fn':{}};current={};by_function=Counter();pending_call=False
        for line in raw.splitlines():
            match=re.match(r'^(ob|cob|fl|fi|fe|cfi|cfl|fn|cfn)=\((\d+)\)(?: (.*))?$',line)
            if match:
                kind,ident,value=match.groups();table='ob' if kind in ['ob','cob'] else 'fn' if kind in ['fn','cfn'] else 'fl'
                if value is not None:
                    ck(names[table].setdefault(ident,value)==value,'stable raw Callgrind name mapping')
                ck(ident in names[table],'defined raw Callgrind name reference')
                if not kind.startswith('c'):current[table]=names[table][ident]
            elif line.startswith('calls='):pending_call=True
            elif re.match(r'^(?:\*|[+-]?\d+)\s+\d+(?:\s|$)',line):
                amount=int(line.split()[1])
                if pending_call:pending_call=False
                else:by_function[(current['fl']+':'+current['fn'],current['ob'])]+=amount
        ck(not pending_call,'all raw call edges consumed')
        annotation=read(PROFILE/(stem+'-annotation.stdout')).decode()
        funcs=[]
        for line in annotation.splitlines():
            match=re.match(r'^\s*([\d,]+)\s+(.+?) \[([^\]]+)\]$',line)
            if match:funcs.append({'Ir':int(match[1].replace(',','')),'function':match[2],'object':match[3]})
        ck(Counter({(f['function'],f['object']):f['Ir'] for f in funcs})==+by_function,'all raw self function counts equal annotated table')
        raw_self_tables.append({'condition':index,'library':label,'functions':[{'function':k[0],'object':k[1],'Ir':v} for k,v in sorted(by_function.items()) if v]})
        ck(funcs==row['functions'] and sum(f['Ir'] for f in funcs)==row['Ir'] and row['unparsed_Ir']==0,'all annotated function rows reconstruct total')
        ck([int(x.replace(',','')) for x in re.findall(r'^([\d,]+)\s+PROGRAM TOTALS$',annotation,re.M)]==[row['Ir']],'annotation total exact raw Callgrind')
        ck(any(f['object']==library and f['function'].endswith(':XML_Parse') for f in funcs),'profile attributes XML_Parse to selected library')
        ck(any(f['object']==str(driver) and f['function'] in ['???:start','???:end','???:text'] for f in funcs),'native callbacks included inside XML_Parse collection')
        stderr=read(PROFILE/(stem+'.stderr')).decode()
        ck([int(x) for x in re.findall(r'Collected\s*:\s*(\d+)',stderr)]==[row['Ir']],'profiler stderr collected total')
        profiles_by_key[index,label]=row['Ir'];raw_totals.append({'condition':index,'library':label,'Ir':row['Ir'],'self_cost_sum':direct,'callgrind_sha256':h(output)})
    ck(condition_observations[0]==condition_observations[1],'control/candidate equal preflight and profile outputs')
    control,candidate=(profiles_by_key[index,k] for k in ['control','candidate'])
    comparison_rows.append(condition|{'control':control,'candidate':candidate,'candidate_over_control':candidate/control})
ck(comparison_rows==profile['comparisons'],'all16 reported instruction ratios exact')
project_geo=math.exp(sum(math.log(r['candidate_over_control']) for r in comparison_rows if r['kind']=='project')/12)
ck(project_geo==profile['project_instruction_ratio_geomean']==0.9741904847790345,'exact real12 instruction geometric mean')
regressions=[r for r in comparison_rows if r['candidate_over_control']>1]
ck([(r['workload'],r['namespaces'],r['chunk']) for r in regressions]==[('rare-declarations',False,4096),('rare-declarations',False,65536)],'both rare-declaration instruction regressions retained')


# Fixed order and complete raw file inventory; no missing/extra profile process.
stems=[f'{i:02}-{c["workload"]}-ns{int(c["namespaces"])}-{c["chunk"]}-{engine}' for i,c in enumerate(conditions) for engine in ['control','candidate']]
expected_command_order=[stem+'-preflight' for stem in stems]+[name for stem in stems for name in [stem,stem+'-annotation']]
ck([r['stem'] for r in commands]==expected_command_order,'fixed32 preflight then32 profile/annotation command order')
expected_files={stem+suffix for stem in stems for suffix in ['-preflight.stdout','-preflight.stderr','.stdout','.stderr','.callgrind','-annotation.stdout','-annotation.stderr']}|{'protocol.json','preflights.json','commands.json','report.json','origins.json'}
ck({p.name for p in PROFILE.iterdir() if p.is_file()}==expected_files,'exact229 profile output files')
ck(protocol['env_overrides']=={'VALGRIND_LIB':'/home/dev-user/.cache/oriole/profilers/local/usr/libexec/valgrind','LD_PRELOAD':'','LD_LIBRARY_PATH':''},'explicit profiler loader environment')
ck(all(0<=r['elapsed_seconds']<r['timeout_seconds'] for r in commands),'all96 commands complete within their own limits')
ck(sum(r['candidate_over_control']<1 for r in comparison_rows if r['kind']=='project')==12,'all12 real instruction conditions lower')

# All32 phase-completion log rows and final summary refer to these same raw totals.
log_lines=read(NORMAL/'profile-controller.log').decode().splitlines()
expected_lines=[stem+' '+str(profiles_by_key[i,engine]) for i,c in enumerate(conditions) for engine in ['control','candidate'] for stem in [f'{i:02}-{c["workload"]}-ns{int(c["namespaces"])}-{c["chunk"]}-{engine}']]
ck(log_lines[:-1]==expected_lines,'collector log all32 exact profile completion rows')
ck(json.loads(log_lines[-1])=={'status':'passed','project_instruction_ratio_geomean':project_geo,'comparisons':comparison_rows},'collector final log summary exact')
generated_geo=math.exp(sum(math.log(r['candidate_over_control']) for r in comparison_rows if r['kind']=='generated')/4)
generated_lower=sum(r['candidate_over_control']<1 for r in comparison_rows if r['kind']=='generated')
ck(generated_lower==2 and len(regressions)==2,'all two adverse generated rows retained')
ck(all(sha(Path(p).read_bytes())==value for p,value in tracked.items()),'all observed profile/source-receipt/origin bytes unchanged')
put('checked-files.json',tracked);put('checks.json',checks);put('all-instruction-conditions.json',comparison_rows);put('raw-instruction-totals.json',raw_totals);put('raw-self-function-tables.json',raw_self_tables)
report={
 'status':'independent_saved_ascii_table_profile_audit_passed','scope':'Saved instruction profiles/commands/observations/collector adaptation/receipt hashes only. No active native timing study access; no parser, build, test, profiler, annotator or project-generator execution.','cpu':4,'findings':[],
 'source_review_sha256':h(prior_path),'source_manifest_sha256':h(NORMAL/'source.json'),'patch_sha256':h(NORMAL/'candidate.patch'),'collector_sha256':h(NORMAL/'collect_profiles.py'),'collector_adaptation_sha256':h(NORMAL/'profile-adaptation.json'),'prior_collector_review_sha256':h(cell_review_path),'libraries':origins,
 'profile':{'conditions':16,'real_conditions':12,'generated_conditions':4,'preflight_processes':32,'profile_processes':32,'annotation_processes':32,'command_receipts':96,'output_files':229,'parser_samples_each_worker':2,'preflight_parser_samples':64,'profile_parser_samples':64,'all_parser_samples':128,'recorded_cpu':3,'all_raw_self_function_tables_and_totals_match_annotations':True,'unparsed_self_Ir':0,'all_selected_callback_observations_equal':True,'project_instruction_ratio_geomean':project_geo,'real_lower':12,'generated_instruction_ratio_geomean':generated_geo,'generated_lower':generated_lower,'regressions':regressions,'all_conditions_file':'all-instruction-conditions.json','raw_report_sha256':h(PROFILE/'report.json'),'protocol_sha256':h(PROFILE/'protocol.json'),'commands_sha256':h(PROFILE/'commands.json'),'preflights_sha256':h(PROFILE/'preflights.json'),'origins_sha256':h(PROFILE/'origins.json'),'elapsed_claim':False},
 'retained_attempts':{'source_setup_collision':setup,'source_setup_sha256':h(setup_path),'profile_command_failures':[],'profile_commands_all96_exit_zero':True,'scope':'Original destination collision precedes setup; not a failed parser/profile case. No failed profile command appears in this completed96-record campaign.'},
 'limits':[
  'Only instruction count is audited. Both nominal warmup and measured parse are collected under XML_Parse, with nested native callbacks. Construction, free and input I/O are outside collection. Raw driver seconds are retained and unused for elapsed conclusions.',
  'One profile per engine/condition in fixed control/candidate order,12 real4generated conditions; this is not the28-condition native elapsed protocol and establishes no elapsed gain or statistical significance.',
  'Both rare-declaration regressions and all four generated rows remain. Entity conditions are only fractionally below one; exact values, totals and all functions are retained.',
  'Collector dladdr checks XML_Parse only in its own process. Driver resolves an explicit absolute library handle with dlopen/dlsym and raw Callgrind object attribution matches selected XML_Parse. No per-worker dladdr attestation is claimed.',
  'Selected callback digest/count equality across two samples/engines does not prove exact callback fragmentation, positions, errors, all API compatibility, allocator behavior or external DTD loading.',
  'Collector inherits CPU3 for child commands, uses30s preflight or300s profile/annotation limits, starts process groups and kills/reaps on ordinary timeout/error. Its reused source has no explicit comprehensive SIGTERM forwarding handler; no signal testing is claimed.',
  'The source02184 proof and build receipts are pinned but source/build/codegen and broad gates are separately parent/root-owned. The active native timing study was not opened or audited.'
 ],
 'checks':len(checks),'checked_files':len(tracked),'generator_sha256':sha(Path(__file__).read_bytes()),'checked_files_sha256':h(OUT/'checked-files.json')
}
put('review.json',report)
print(json.dumps({'status':report['status'],'review_sha256':h(OUT/'review.json'),'checks':report['checks'],'files':report['checked_files'],'real_geomean':project_geo,'generated_geomean':generated_geo,'regressions':regressions},indent=2))
