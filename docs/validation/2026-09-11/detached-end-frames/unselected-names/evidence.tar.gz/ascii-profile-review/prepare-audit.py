"""Adapt saved-profile checker; no project execution or active timing reads."""
from pathlib import Path
import hashlib,difflib,json
O=Path(__file__).resolve().parent
B=Path('/tmp/oriole-detached-end-profile-independent-review/audit.py')
b=B.read_text()
assert hashlib.sha256(b.encode()).hexdigest()=='c6838ac5f0efc8da2adc677ea604cae27011e034a79963b030a9353c2881f885'
s=b[:b.index('# End lifecycle saved full structured results.')]
s=s.replace('saved profile and End outcome','saved ASCII-table profile')
s=s.replace('/tmp/oriole-detached-end-frame-production-study','/tmp/oriole-ascii-name-table-thinlto-study')
s=s.replace('/tmp/oriole-thinlto-production-study/thinlto','/tmp/oriole-ffi-family-cell-thinlto-study')
s=s.replace('/home/dev-user/code/oss/oriole-detached-end-frame','/home/dev-user/code/oss/oriole-ascii-name-table')
s=s.replace("protocol['affinity']==[6]","protocol['affinity']==[3]").replace("row['affinity']==[6]","row['affinity']==[3]")
s=s.replace('profile a55 ThinLTO control and detached End826a candidate','profile Cell0cfd ThinLTO control and ASCII-table02fd candidate')
s=s.replace('0.9699453979861064','0.9741904847790345')
s=s.replace("[('rare-declarations',False,4096),('entities',False,4096),('entities',False,65536)]","[('rare-declarations',False,4096),('rare-declarations',False,65536)]")
s=s.replace('all three instruction regressions retained','both rare-declaration instruction regressions retained')
s=s.replace("ck(profile['source_unchanged'],'producer reports source unchanged; source review remains separate')\n",'')
start=s.index('prior_path=Path(')
end=s.index('# Reconstruct all 16',start)
prefix='''prior_path=Path('/tmp/oriole-ascii-name-table-independent-review/review.json')
prior=j(prior_path)
ck(h(prior_path)=='02184f26bfb8ebe2a1c0bbb1be0d3a5951973a32d7833794da0686b717b88f2d' and prior['status']=='independent_ascii_name_table_source_review_passed','pinned independent source review')
ck(h(NORMAL/'source.json')==prior['source_sha256']=='725e6e04d4926d300a3d14e2326a115489c67497458752d077b15d883100cf13' and prior['source_files']==70,'pinned source receipt only')
ck(h(NORMAL/'candidate.patch')==prior['patch_sha256']=='b3a9444ff5c08e3c7fe7a2520555424084262507029d90cbce33dae5d46e8873','pinned exact source patch')
expected_libraries={'control':'0cfd610876f1bfd26a4d37a7f86adc9961896dfe24177c180ec7d15e0bae04e9','candidate':'02fd0819efd4b48d87974811737d3de64fe38a617f1f9d9bb6fd69f10a42b1c5'}
ck(h(CONTROL/'liboriole_expat.so')==expected_libraries['control'] and h(NORMAL/'liboriole_expat.so')==expected_libraries['candidate'],'pinned two actual library hashes')
adaptation=j(NORMAL/'profile-adaptation.json')
original=Path(adaptation['original']);old=read(original).decode();collector=read(NORMAL/'collect_profiles.py').decode()
ck(h(original)==adaptation['original_sha256']=='0f9724ef49a53713754b2309c675ebb9268576060bca58c62492ce2b46c7a8e2' and h(NORMAL/'collect_profiles.py')==adaptation['adapted_sha256']=='6ddcf75c6bc7d0a55ca6d84e966540c28cdf1ce4d5727358b29dc1990d9cf7a7','pinned original and adapted collectors')
cell_review_path=Path('/tmp/oriole-ffi-family-cell-build-profile-independent-review/review.json')
ck(h(cell_review_path)=='445e938039f95741346dcf91489137631d66ee61655b69adbd4cb66b08c380be','pinned prior collector saved-data review')
old_files=j(cell_review_path.parent/'checked-files.json')
ck(old_files[str(original)]==h(original),'original collector is previously reviewed source')
adapted=old.replace('Run the matched instruction study for private serialized FFI family counters on published start-frame integration.','Run matched C-only ThinLTO instruction profiles for the ASCII NameChar table versus selected Cell runtime.')
adapted=adapted.replace('/home/dev-user/code/oss/oriole-ffi-family-cell','/home/dev-user/code/oss/oriole-ascii-name-table').replace('/tmp/oriole-start-frame-integration-study','/tmp/oriole-ffi-family-cell-thinlto-study')
adapted=adapted.replace('9815cc852327d455c094b0fb72c1d33fb90a4571e67cf15965e96e2300376828',expected_libraries['control'])
adapted=adapted.replace('os.sched_getaffinity(0)=={4}','os.sched_getaffinity(0)=={3}').replace("'affinity':[4]","'affinity':[3]")
adapted=adapted.replace('Callgrind XML_Parse-only instructions with callbacks. Six projects','Callgrind XML_Parse-only instructions with callbacks. Both libraries use matched C-only ThinLTO; Cell0cfd control versus ASCII table02fd candidate. Six projects')
ck(adapted==collector,'collector exact prior protocol after explicit paths identity CPU and descriptive text changes')
patch=''.join(difflib.unified_diff(old.splitlines(True),collector.splitlines(True),fromfile=str(original),tofile=str(NORMAL/'collect_profiles.py')))
ck(patch==read(NORMAL/'profile-adaptation.patch').decode(),'retained profile controller diff exact')
setup_path=prior_path.parent/'setup-attempt.json';setup=j(setup_path)
ck(h(setup_path)=='ac44a44374344bf2c0bf024e0fae03025bbae2a0e7e70b22217ea2714da1c156' and setup['status']=='first destination existed; no changes made','original source setup collision retained separately')
(OUT/'retained-setup-attempt.json').write_bytes(read(setup_path))

'''
s=s[:start]+prefix+s[end:]
tail='''# All32 phase-completion log rows and final summary refer to these same raw totals.
log_lines=read(NORMAL/'profile-controller.log').decode().splitlines()
expected_lines=[stem+' '+str(profiles_by_key[i,engine]) for i,c in enumerate(conditions) for engine in ['control','candidate'] for stem in [f'{i:02}-{c["workload"]}-ns{int(c["namespaces"])}-{c["chunk"]}-{engine}']]
ck(log_lines[:-1]==expected_lines,'collector log all32 exact profile completion rows')
ck(json.loads(log_lines[-1])=={'status':'passed','project_instruction_ratio_geomean':project_geo,'comparisons':comparison_rows},'collector final log summary exact')
generated_geo=math.exp(sum(math.log(r['candidate_over_control']) for r in comparison_rows if r['kind']=='generated')/4)
generated_lower=sum(r['candidate_over_control']<1 for r in comparison_rows if r['kind']=='generated')
ck(generated_lower==2 and len(regressions)==2,'all two adverse generated rows retained')
ck(all(sha(Path(p).read_bytes())==value for p,value in tracked.items()),'all observed profile/source-receipt/origin bytes unchanged')
put('checked-files.json',tracked);put('checks.json',checks);put('all-instruction-conditions.json',comparison_rows);put('raw-instruction-totals.json',raw_totals);put('raw-self-function-tables.json',raw_self_tables)
report={
 'status':'independent_saved_ascii_table_profile_audit_passed','scope':'Saved instruction profiles/commands/observations/collector adaptation/receipt hashes only. No active native timing study access; no parser, build, test, profiler, annotator or project-generator execution.','cpu':4,'findings':[],
 'source_review_sha256':h(prior_path),'source_manifest_sha256':h(NORMAL/'source.json'),'patch_sha256':h(NORMAL/'candidate.patch'),'collector_sha256':h(NORMAL/'collect_profiles.py'),'collector_adaptation_sha256':h(NORMAL/'profile-adaptation.json'),'prior_collector_review_sha256':h(cell_review_path),'libraries':origins,
 'profile':{'conditions':16,'real_conditions':12,'generated_conditions':4,'preflight_processes':32,'profile_processes':32,'annotation_processes':32,'command_receipts':96,'output_files':229,'parser_samples_each_worker':2,'preflight_parser_samples':64,'profile_parser_samples':64,'all_parser_samples':128,'recorded_cpu':3,'all_raw_self_function_tables_and_totals_match_annotations':True,'unparsed_self_Ir':0,'all_selected_callback_observations_equal':True,'project_instruction_ratio_geomean':project_geo,'real_lower':12,'generated_instruction_ratio_geomean':generated_geo,'generated_lower':generated_lower,'regressions':regressions,'all_conditions_file':'all-instruction-conditions.json','raw_report_sha256':h(PROFILE/'report.json'),'protocol_sha256':h(PROFILE/'protocol.json'),'commands_sha256':h(PROFILE/'commands.json'),'preflights_sha256':h(PROFILE/'preflights.json'),'origins_sha256':h(PROFILE/'origins.json'),'elapsed_claim':False},
 'retained_attempts':{'source_setup_collision':setup,'source_setup_sha256':h(setup_path),'profile_command_failures':[],'profile_commands_all96_exit_zero':True,'scope':'Original destination collision precedes setup; not a failed parser/profile case. No failed profile command appears in this completed96-record campaign.'},
 'limits':[
  'Only instruction count is audited. Both nominal warmup and measured parse are collected under XML_Parse, with nested native callbacks. Construction, free and input I/O are outside collection. Raw driver seconds are retained and unused for elapsed conclusions.',
  'One profile per engine/condition in fixed control/candidate order,12 real4generated conditions; this is not the28-condition native elapsed protocol and establishes no elapsed gain or statistical significance.',
  'Both rare-declaration regressions and all four generated rows remain. Entity conditions are only fractionally below one; exact values, totals and all functions are retained.',
  'Collector dladdr checks XML_Parse only in its own process. Driver resolves an explicit absolute library handle with dlopen/dlsym and raw Callgrind object attribution matches selected XML_Parse. No per-worker dladdr attestation is claimed.',
  'Selected callback digest/count equality across two samples/engines does not prove exact callback fragmentation, positions, errors, all API compatibility, allocator behavior or external DTD loading.',
  'Collector inherits CPU3 for child commands, uses30s preflight or300s profile/annotation limits, starts process groups and kills/reaps on ordinary timeout/error. Its reused source has no explicit comprehensive SIGTERM forwarding handler; no signal testing is claimed.',
  'The source02184 proof and build receipts are pinned but source/build/codegen and broad gates are separately parent/root-owned. The active native timing study was not opened or audited.'
 ],
 'checks':len(checks),'checked_files':len(tracked),'generator_sha256':sha(Path(__file__).read_bytes()),'checked_files_sha256':h(OUT/'checked-files.json')
}
put('review.json',report)
print(json.dumps({'status':report['status'],'review_sha256':h(OUT/'review.json'),'checks':report['checks'],'files':report['checked_files'],'real_geomean':project_geo,'generated_geomean':generated_geo,'regressions':regressions},indent=2))
'''
s+=tail
(O/'audit.py').write_text(s)
(O/'adaptation.patch').write_text(''.join(difflib.unified_diff(b.splitlines(True),s.splitlines(True),fromfile=str(B),tofile=str(O/'audit.py'))))
(O/'run-audit.py').write_text((B.parent/'run-audit.py').read_text())
(O/'preparation.json').write_text(json.dumps({'scope':'Saved profile checker adaptation only; no active native timing access.','base_generator':str(B),'base_generator_sha256':hashlib.sha256(b.encode()).hexdigest(),'generator_sha256':hashlib.sha256(s.encode()).hexdigest(),'cpu':4},indent=2)+'\n')
