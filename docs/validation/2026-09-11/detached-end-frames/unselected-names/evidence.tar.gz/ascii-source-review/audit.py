"""Read-only source and saved focused-test provenance review; no target execution."""
import hashlib,json,os,re,subprocess,tarfile
from pathlib import Path
assert os.sched_getaffinity(0)=={4}
ROOT=Path('/home/dev-user/code/oss/oriole-ascii-name-table');IN=Path('/tmp/oriole-ascii-name-table-study');OUT=Path(__file__).parent
BASE='1a4cae6669cd267fa51e0e104c3eac84edb3437d'
tracked={};checks=[];gitreads=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p);b=p.read_bytes();assert tracked.setdefault(str(p),sha(b))==sha(b);return b
def j(p):return json.loads(read(p))
def ck(v,m):assert v,m;checks.append(m)
def git(*args):
 cmd=['git','-C',str(ROOT),*args];r=subprocess.run(cmd,capture_output=True,timeout=30);gitreads.append({'command':cmd,'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr':r.stderr.decode()});ck(r.returncode==0,'read-only Git '+' '.join(args));return r.stdout
def put(n,d):(OUT/n).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
for name,digest in [('source.json','725e6e04d4926d300a3d14e2326a115489c67497458752d077b15d883100cf13'),('candidate.patch','b3a9444ff5c08e3c7fe7a2520555424084262507029d90cbce33dae5d46e8873'),('focused.json','aecbc7ca3a47e2e799b72b3b7530f20a99286a260820450f801306cf3622353a')]:ck(sha(read(IN/name))==digest,'frozen '+name)
source=j(IN/'source.json');base=j(IN/'base-source.json');focused=j(IN/'focused.json');design=read(IN/'DESIGN.md').decode();setup=j(IN/'setup-attempt.json')
ck(source['base']==BASE and git('rev-parse','HEAD').decode().strip()==BASE,'selected Cell base independent of rejected scanner')
ck(len(source['source_sha256'])==len(base)==70,'70-source inventory')
ck([n for n in base if source['source_sha256'][n]!=base[n]]==['crates/oriole/src/tag.rs'],'one changed file only')
ck(git('diff','--binary',BASE)==read(IN/'candidate.patch'),'live exact frozen patch')
with tarfile.open(IN/'source.tar.gz') as tar:
 members=[m for m in tar if m.isfile()];ck(len(members)==70,'70 source archive members')
 for m in members:
  b=tar.extractfile(m).read();ck(sha(b)==source['source_sha256'][m.name]==sha(read(ROOT/m.name)),'source archive/live '+m.name)
for name,digest in base.items():ck(sha(git('show',BASE+':'+name))==digest,'base exact '+name)
new=read(ROOT/'crates/oriole/src/tag.rs').decode();old=git('show',BASE+':crates/oriole/src/tag.rs').decode();names=read(ROOT/'crates/oriole/src/names.rs').decode()
start='pub(crate) fn name_end(';end='/// Scalar progress plus offset records'
newfn=new[new.index(start):new.index(end)];oldfn=old[old.index(start):old.index(end)]
test_start='    #[test]\n    fn ascii_name_table_matches_both_editions_at_unicode_boundaries()';test_end='    type Outcome = ('
newtest=new[new.index(test_start):new.index(test_end)]
ck(new.replace(newfn,oldfn).replace(newtest,'')==old,'only function replacement and added test')
ck("byte.is_ascii_alphanumeric() || matches!(byte, b':' | b'_' | b'-' | b'.')" in newfn and "c.is_ascii_alphanumeric() || matches!(c, ':' | '_' | '-' | '.')" in names,'same edition-independent ASCII predicate')
ck('const ASCII_NAME_CHAR: [bool; 256]' in newfn and 'let mut table = [false; 256]' in newfn and 'while byte < 128' in newfn,'all high bytes false;66 accepted ASCII values')
ck('let suffix = &text[offset..];' in newfn and 'ASCII_NAME_CHAR[usize::from(byte)]' in newfn and 'else if byte.is_ascii()' in newfn,'same initial slicing and complete byte-index domain')
ck('suffix[index..].chars().next().unwrap()' in newfn and '!rules.is_name_char(character)' in newfn and 'index += character.len_utf8()' in newfn,'unchanged Unicode predicate on complete scalar')
ck(all(x not in newfn for x in ['unsafe','alloc(','Vec','String','Box','set_']),'no allocation, unsafe or callback ownership code')
# Compare the independently meaningful test to the prior preserved implementation without running it.
with tarfile.open('/tmp/oriole-ascii-name-scan-study/source.tar.gz') as tar: prior=tar.extractfile('crates/oriole/src/tag.rs').read().decode()
prior_name=re.search(r'    #\[test\]\n    fn (ascii_\w+matches_both_editions_at_unicode_boundaries)\(\)',prior).group(1)
prior_start='    #[test]\n    fn '+prior_name+'()';prior_test=prior[prior.index(prior_start):prior.index(test_end)]
ck(newtest.replace('ascii_name_table_matches_both_editions_at_unicode_boundaries',prior_name)==prior_test,'previous scalar-oracle test body exact except name')
oldsummary=j('/tmp/oriole-ascii-name-scan-handoff/summary.json')
ck(oldsummary['status']=='unselected' and oldsummary['native_wall']['real']['candidate_over_published']['geomean']==0.999323907426292 and oldsummary['native_wall']['generated']['candidate_over_published']['geomean']==1.0170975841302599,'retained old negative result is separate mechanism/base')
ck('No speedup is predicted' in design and 'not current ThinLTO profiling' in design and 'against0cfd' in design,'design performance limitations explicit')
ck(focused['status']=='passed_focused_only' and focused['source_manifest_sha256']==sha(read(IN/'source.json')) and focused['source_unchanged'],'focused owner receipt exact')
for row in focused['commands']:
 log=read(IN/(row['label']+'.log'));ck(sha(log)==row['log_sha256'] and row['exit']==0 and row['affinity']==[3] and row['timeout']==900,'saved focused command and log '+row['label'])
 ck(row['command'][:3]==['cargo','+ohm','-Zohm-defaults=no'],'Ohm normal focused mode '+row['label'])
 if row['label'] in ['tag-tests','name-rules']:ck('test result: ok. 5 passed; 0 failed; 0 ignored' in log.decode(),'5 original focused tests '+row['label'])
ck(setup['status']=='first destination existed; no changes made','preserved setup refusal scope')
for n in ['candidate.patch','source.json','base-source.json','focused.json','DESIGN.md','setup-attempt.json']:(OUT/n).write_bytes(read(IN/n))
(OUT/'tag-current.rs').write_text(new);(OUT/'tag-base.rs').write_text(old);(OUT/'names.rs').write_text(names)
for p,digest in tracked.items():ck(sha(Path(p).read_bytes())==digest,'final unchanged '+p)
put('checks.json',checks);put('read-files.json',tracked);put('git-reads.json',gitreads)
put('review.json',{'status':'independent_ascii_name_table_source_review_passed','findings':[],'scope':'Source-only plus saved focused-log provenance. No builds, tests, parser executions or profiling by reviewer.','source_sha256':sha(read(IN/'source.json')),'patch_sha256':sha(read(IN/'candidate.patch')),'base':BASE,'source_files':70,'changed_files':['crates/oriole/src/tag.rs'],'proof':[
'The 256-entry const table initializes false; only indices 0..127 are assigned. u8 increments at most 127 to128 and cannot overflow. Accepted bytes are exactly A-Z/a-z/0-9 and colon, underscore, hyphen, period, identical to both existing editions (66 values).',
'Initial text[offset..] retains the same bounds and UTF-8 boundary checks. Start index0 is a suffix character boundary. Successful ASCII advances exactly one character. Non-ASCII always reaches the unchanged NameRules predicate and advances exactly char.len_utf8. Induction keeps index a character boundary and never larger than suffix length, making unwrap and offset+index valid on every entered iteration.',
'Empty suffix returns offset == text.len. Invalid ASCII or rejected Unicode stops at exactly the first scalar rejected by the old char_indices loop. There is no changed first-character validation: AttributeScanner and TagScanner still validate and advance the first scalar before calling name_end.',
'Both production callers retain offset/source caching, incomplete handling, token/attribute limits, raw ranges and failure paths. No allocation, selected-allocator call, parser mutation, callback, ownership or unsafe code is introduced into name_end.',
'One added test is byte-exact to the prior scalar-oracle test apart from its name: all Unicode scalars in both editions, every ASCII pair at valid suffix offsets, lengths/delimiters and empty suffixes. Existing five tag and five edition tests passed in saved author logs; no reuse of old performance results as current evidence.'
],'saved_focused_tests':{'tag':5,'name_rules':5,'strict_core_clippy':'passed','fmt':'passed','executed_by_reviewer':False},'retained_limits':[
'Source equivalence supports an experiment, not adoption or a speedup claim. New table code has not yet been measured or passed broad compatibility gates.',
'Table access may change code generation and cache cost. Historical normal9815 self-instruction shares are not a current ThinLTO ceiling, and the previous range scanner remains rejected with real-flat/generated-regression results.',
'UTF-8 correctness derives from &str and the unchanged initial slice contract; no additional invalid-offset panic tests or target executions were requested.'
],'checks':len(checks),'files':len(tracked),'generator_sha256':sha(Path(__file__).read_bytes())})
print(json.dumps({'review_sha256':sha((OUT/'review.json').read_bytes()),'checks':len(checks)}))
