"""Freeze the table experiment and execute bounded focused correctness checks."""
from pathlib import Path
import hashlib, io, json, os, signal, subprocess, tarfile, time

W = Path('/home/dev-user/code/oss/oriole-ascii-name-table')
O = Path(__file__).parent
B = Path('/tmp/oriole-ffi-family-cell-thinlto-study')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert os.sched_getaffinity(0) == {3}
files = read(B / 'source.json')['source_sha256']
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
assert base == '1a4cae6669cd267fa51e0e104c3eac84edb3437d'
source = {'worktree': str(W), 'base': base, 'source_sha256': {name: sha(W / name) for name in files}}
(O / 'source.json').write_text(json.dumps(source, indent=2) + '\n')
base_map = {name: hashlib.sha256(subprocess.check_output(['git', 'show', base + ':' + name], cwd=W)).hexdigest() for name in files}
assert [p for p in files if source['source_sha256'][p] != base_map[p]] == ['crates/oriole/src/tag.rs']
(O / 'base-source.json').write_text(json.dumps(base_map, indent=2) + '\n')
(O / 'candidate.patch').write_bytes(subprocess.check_output(['git', 'diff'], cwd=W))
with tarfile.open(O / 'source.tar.gz', 'w:gz') as archive:
    for name in files:
        data = (W / name).read_bytes()
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(data), 0, 0o644
        archive.addfile(info, io.BytesIO(data))
env_overrides = dict(read(B / 'report.json')['env_overrides'])
env_overrides['CARGO_TARGET_DIR'] = '/home/dev-user/.cache/oriole/ascii-name-table-target'
env = os.environ | env_overrides
assert not {k: v for k, v in env.items() if k.startswith('CARGO_PROFILE_')}
report = {'status': 'incomplete', 'source_manifest_sha256': sha(O / 'source.json'), 'env_overrides': env_overrides, 'commands': []}
def save():
    (O / 'focused.json').write_text(json.dumps(report, indent=2) + '\n')
try:
    for label, args in [
        ('tag-tests', ['test', '--locked', '-p', 'oriole', '--lib', 'tag::tests']),
        ('name-rules', ['test', '--locked', '-p', 'oriole', '--test', 'name_rules']),
        ('clippy', ['clippy', '--locked', '-p', 'oriole', '--lib', '--tests', '--', '-D', 'warnings']),
        ('fmt-check', ['fmt', '--all', '--check']),
    ]:
        cmd = ['cargo', '+ohm', '-Zohm-defaults=no', *args]
        row = {'label': label, 'command': cmd, 'cwd': str(W), 'affinity': [3], 'start': time.time(), 'timeout': 900}
        report['commands'].append(row)
        save()
        process = None
        with (O / (label + '.log')).open('wb') as log:
            try:
                process = subprocess.Popen(cmd, cwd=W, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                row['exit'] = process.wait(timeout=900)
                assert row['exit'] == 0, label
            except BaseException as error:
                row['exception'] = repr(error)
                if process is not None:
                    try: os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError: pass
                    row['exit'] = process.wait()
                raise
            finally:
                log.flush()
                row['end'] = time.time()
                row['log_sha256'] = sha(O / (label + '.log'))
                save()
        print(label, row['exit'], flush=True)
    report['status'] = 'passed_focused_only'
finally:
    report['source_unchanged'] = all(sha(W / name) == digest for name, digest in source['source_sha256'].items())
    save()
assert report['source_unchanged']
