"""Read ELF metadata and constant bytes only; never execute or rewrite binaries."""
from pathlib import Path
import hashlib,json,os,struct,re
assert os.sched_getaffinity(0)=={4}
O=Path(__file__).parent
paths={'control':Path('/tmp/oriole-ffi-family-cell-thinlto-study/liboriole_expat.so'),'candidate':Path('/tmp/oriole-ascii-name-table-thinlto-study/liboriole_expat.so')}
pins={'control':'0cfd610876f1bfd26a4d37a7f86adc9961896dfe24177c180ec7d15e0bae04e9','candidate':'02fd0819efd4b48d87974811737d3de64fe38a617f1f9d9bb6fd69f10a42b1c5'}
sha=lambda b:hashlib.sha256(b).hexdigest();results={};symbols={}
table=bytes(int(65<=i<=90 or 97<=i<=122 or 48<=i<=57 or i in b':_-.') for i in range(256))
for label,p in paths.items():
 b=p.read_bytes();assert sha(b)==pins[label] and b[:6]==b'\x7fELF\x02\x01'
 offset=struct.unpack_from('<Q',b,40)[0];size,n,shstr=struct.unpack_from('<HHH',b,58);rows=[struct.unpack_from('<IIQQQQIIQQ',b,offset+i*size) for i in range(n)];sn=rows[shstr];names=b[sn[4]:sn[4]+sn[5]]
 sections={names[r[0]:].split(b'\0',1)[0].decode():r for r in rows};sec_names={i:names[r[0]:].split(b'\0',1)[0].decode() for i,r in enumerate(rows)};sym=sections['.symtab'];st=rows[sym[6]];strings=b[st[4]:st[4]+st[5]];found=[];functions={}
 for so in range(sym[4],sym[4]+sym[5],sym[9]):
  name,info,other,idx,value,length=struct.unpack_from('<IBBHQQ',b,so);name=strings[name:].split(b'\0',1)[0].decode()
  if (info&15)==2 and idx!=0:functions[name]={'size':length,'address':value,'section':sec_names.get(idx)}
  if 'name_end' in name:found.append({'name':name,'size':length,'address':value,'section':sec_names.get(idx)})
 offsets=[];start=0
 while (at:=b.find(table,start))>=0:
  sec=next((name for name,r in sections.items() if r[4]<=at and at+256<=r[4]+r[5]),None);offsets.append({'file_offset':at,'section':sec});start=at+1
 results[label]={'path':str(p),'sha256':sha(b),'file_bytes':len(b),'text_bytes':sections['.text'][5],'rodata_bytes':sections['.rodata'][5],'name_end_symbols':found,'exact_256byte_table_occurrences':offsets};symbols[label]=functions
 assert sha(p.read_bytes())==pins[label]
changes={name:{label:symbols[label].get(name) for label in symbols} for name in symbols['control'].keys()|symbols['candidate'].keys() if symbols['control'].get(name,{}).get('size')!=symbols['candidate'].get(name,{}).get('size')}
normalized={label:{re.sub(r'\.llvm\.\d+$','',name):row['size'] for name,row in ss.items()} for label,ss in symbols.items()}
assert all(len(normalized[label])==len(symbols[label]) for label in symbols)
normalized_changes={name:{label:normalized[label].get(name) for label in normalized} for name in normalized['control'].keys()|normalized['candidate'].keys() if normalized['control'].get(name)!=normalized['candidate'].get(name)}
assert len(normalized_changes)==1 and 'name_end' in next(iter(normalized_changes))
assert len(results['control']['name_end_symbols'])==len(results['candidate']['name_end_symbols'])==1
assert not results['control']['exact_256byte_table_occurrences'] and len(results['candidate']['exact_256byte_table_occurrences'])==1
assert results['candidate']['exact_256byte_table_occurrences'][0]['section']=='.rodata'
(O/'metadata.json').write_text(json.dumps({'libraries':results,'changed_function_sizes':changes},indent=2)+'\n')
review={'status':'independent_ascii_table_static_metadata_review_passed','scope':'Read-only direct ELF section/symbol and constant-byte inspection; no disassembler, target execution, build, profiling or timing rerun.','findings':[],'libraries':results,'raw_function_symbol_changes':changes,'function_size_changes_after_unique_llvm_suffix_normalization':normalized_changes,'observations':['The exact66-entry ASCII acceptance pattern occurs once as256 bytes in candidate .rodata and never in control. Read-only data increases by256 bytes.','Total .text grows96 bytes; the name_end function symbol grows from251 to346 bytes. After uniquely stripping only the trailing .llvm numeric disambiguator, name_end is the sole function-size change. This is static footprint evidence, not equal instruction bytes, retired-instruction count or throughput.'],'interpretation':['The fixed instruction and elapsed studies must determine whether cheaper ASCII classification offsets the indexed load/loop and changed layout.','Regressing namespace cases despite lower instruction totals are consistent with latency, prediction, cache or layout effects and shared-host variation, but these records do not establish which cause dominates.','No selected allocation, parser object layout or lifetime mutation is introduced by this table. Read-only constant storage and function code increase; no claim of zero memory footprint.','Hold adoption pending actual consumer results and original compatibility gates. A positive overall native mean does not erase retained Maven/DocBook and generated entity regressions.'],'generator_sha256':sha(Path(__file__).read_bytes())}
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n');print(sha((O/'review.json').read_bytes()));print(json.dumps({'changed_function_sizes':changes}))
