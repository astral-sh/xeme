"""Seal B1 source/build/profiles/counts after parent stopped before elapsed/full gates."""
from pathlib import Path
import gzip, hashlib, json, os, re, shutil, subprocess, tarfile
assert __debug__ and os.sched_getaffinity(0) == {2}
root=Path('/tmp/oriole-expanded-name-frames-study')
out=Path('/tmp/oriole-expanded-name-frames-b1-handoff')
read=lambda p: json.loads(Path(p).read_text())
sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=read(root/'source.json'); worktree=Path(source['worktree'])
assert len(source['source_sha256'])==70
assert all(sha(worktree/p)==h for p,h in source['source_sha256'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree,text=True).strip()==source['base']
assert subprocess.check_output(['git','diff','--binary'],cwd=worktree)==(root/'candidate.patch').read_bytes()
with tarfile.open(root/'source.tar.gz') as tar:
 assert {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar if m.isfile()}==source['source_sha256']
build=read(root/'build.json'); profile=read(root/'profile/report.json'); protocol=read(root/'profile/protocol.json')
assert build['status']==profile['status']=='passed'
assert all(sha(root/n)==h for n,h in build['libraries'].items())
assert all(row['exit']==0 and sha(root/(row['name']+'.log'))==row['log_sha256'] for row in build['commands'])
counts={name:sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(root/(name+'.log')).read_text()))) for name in ['core-unit','focused','ffi-focused']}
assert counts=={'core-unit':56,'focused':109,'ffi-focused':88}
assert read(root/'compiler-comparison.json')['status']=='matched_after_private_paths_only'
assert len(profile['rows'])==len(read(root/'profile/preflights.json'))==32 and len(profile['comparisons'])==16
assert profile['hashes_after']==protocol['hashes_before'] and all(sha(p)==h for p,h in protocol['hashes_before'].items())
attr=read(root/'profile-attribution.json'); alloc=read(root/'allocation-counts/report.json')
assert attr['status']=='paired_saved_attribution_reconstructed' and all(sha(p)==h for p,h in attr['hashes'].items())
assert alloc['status']=='passed' and alloc['cases']==12 and alloc['engines']==2
assert alloc['before']==alloc['after'] and all(sha(p)==h for p,h in alloc['after'].items())
assert alloc['all_callback_records_exact'] and alloc['all_selected_blocks_freed']
refs=root/'references'; refs.mkdir(exist_ok=False)
for folder in ['design','inputs','control']:(refs/folder).mkdir()
for p in sorted(Path('/tmp/oriole-namespace-storage-design-review').iterdir()):
 if p.is_file():shutil.copyfile(p,refs/'design'/p.name)
shutil.copyfile('/tmp/oriole-expanded-name-frames-preparation.json',refs/'preparation.json')
for name in ['source.json','build.json','compiler-invocations.json']:
 shutil.copyfile(Path('/tmp/oriole-start-frame-integration-study')/name,refs/'control'/name)
inputs=[]
for i,p in enumerate(sorted({r['input'] for r in profile['comparisons']})):
 p=Path(p); target=refs/'inputs'/f'{i:02d}-{p.name}'; shutil.copyfile(p,target)
 inputs.append({'origin':str(p),'archived':str(target.relative_to(root)),'sha256':sha(p)})
(refs/'inputs/index.json').write_text(json.dumps(inputs,indent=2)+'\n')
summary={'status':'b1_frozen_before_revision_no_elapsed_or_full_gates','decision':'Parent stopped B1 after material NUL-equal-spelling allocation regression; assess owner move or NUL-only fallback separately before any new implementation.',
 'base':source['base'],'source_manifest_sha256':sha(root/'source.json'),'source_files':70,'source_unchanged':True,'patch_sha256':sha(root/'candidate.patch'),
 'libraries':build['libraries'],'control_library_sha256':'9815cc852327d455c094b0fb72c1d33fb90a4571e67cf15965e96e2300376828',
 'implementation':'B only: literal planned native start frames can expand one bounded element spelling; plain non-xmlns attributes only. Existing identity specialization first. QName errors fall back before attrs; missing/reserved prefix errors fall back to original ordering; expansion/URI charge after attrs, flags before frame-name copy, native raw stack owner, empty end and publication phases retained. A end raw-name recycling unchanged.',
 'validation':{'focused_tests':counts,'total_focused_tests':sum(counts.values()),'core_clippy':'passed','fresh_workspace_library_compiles':3,'compiler_flags_match_after_only_private_paths':True,'compiler_comparison_sha256':sha(root/'compiler-comparison.json'),'source_review':'Parent read early three-file patch in full with no initial blocker; no formal final source-review artifact claimed.'},
 'profiles':{'conditions':16,'preflight_processes':32,'callgrind_processes':32,'parses_per_process':2,'both_warmup_and_measured_collected':True,'cpu':2,'all_observations_equal_control':True,'real_project_geomean':profile['project_instruction_ratio_geomean'],'generated_geomean':attr['generated_instruction_ratio_geomean'],'real_conditions_lower':2,'real_conditions_total':12,'comparisons':profile['comparisons'],'report_sha256':sha(root/'profile/report.json'),'attribution_sha256':sha(root/'profile-attribution.json')},
 'allocation_proof':{'cases':12,'engines':2,'warmup_nodes':8,'measured_nodes':128,'all_callback_records_exact':True,'all_selected_blocks_freed':True,'report_sha256':sha(root/'allocation-counts/report.json'),'comparisons':alloc['comparisons'],'limits':alloc['scope']},
 'interpretation':'Maven NS -6.61% Ir and DocBook NS -9.59%; other10 real conditions +0.11 to +0.40%. Real normal allocation call edges decrease2600→2220 and968→802, with unchanged expand_name call counts. Repeated ordinary namespace fixtures do not reduce allocation calls (128→129 or130mallocs) despite lower requested bytes. NUL equal spelling regresses0→129mallocs and1→129reallocs; selected-block leaks/callback differences absent. No elapsed inference.',
 'outer_guard_verified':'Unchanged no seen_doctype, no foreign_dtd, no shared_tables, !fragment, one source, native_utf8_byte_index; new branch also !has_conversions.',
 'failures':[],'no_discarded_parser_runs':True,'no_elapsed_or_full_gate_runs':True,'no_commits_or_pushes':True,
 'limitations':['No full conformance/native sanitizer/CPython gates; stopped before those on parent instruction.','Fallible allocation operation identity is not preserved by frame lowering; focused selected-allocation sweep guards failure cleanup and terminal retries.','Function self costs are disjoint; inclusive edge costs overlap. Inlining merges frame helpers into parse_start.','All16 conditions retained, including10 real regressions.']}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(root/'README.md').write_text('''# Expanded element start frames: frozen B1

B1 is stopped before elapsed timing or full gates. Its matched normal build passed253 focused tests, core Clippy, and three fresh workspace library compiles. All32 preflights and32 fixed instruction profiles matched callback observations. The twelve real conditions improve1.20% geometrically: Maven NS6.61% and DocBook NS9.59%, while the other ten regress0.11–0.40%. All four generated controls are retained.

The bounded selected-allocator proof passed12 conditions for each engine, with exact callback/position records and all blocks freed. Ordinary repeated namespace fixtures have slightly more allocation calls and fewer requested bytes; the NUL case with serialized spelling equal to raw exposes a material regression from zero to129 mallocs and one to129 reallocs for128 measured nodes. No fewer-allocation claim is made for these fixtures. Saved real profiles do show fewer allocation call edges for Maven NS and DocBook NS.

The parent requested a separate design review of moving an equal serialized owner directly into the raw stack field versus excluding NUL separators only from the new expansion branch. This archive contains the unchanged B1 patch, all70 source files, fresh build and focused-test logs, compiler comparison, all instruction/preflight records and inputs, all allocation records/controllers, and prior approved namespace/storage design. No B2 source or results belong to this frozen study. No commits or pushes occurred.
''')
out.mkdir(exist_ok=False)
entries=[]; excluded=[]
for p in sorted(root.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink()
 data=p.read_bytes(); row={'path':str(p.relative_to(root)),'origin':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 (excluded if data.startswith((b'\x7fELF',b'!<arch>\n')) else entries).append(row)
archive=out/'evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|') as tar:
   for row in entries:
    info=tarfile.TarInfo(row['path']); info.size=row['bytes'];info.mode=0o444;info.mtime=0
    with Path(row['origin']).open('rb') as stream:tar.addfile(info,stream)
with tarfile.open(archive) as tar:
 archived={m.name:{'bytes':m.size,'sha256':hashlib.sha256(tar.extractfile(m).read()).hexdigest()} for m in tar if m.isfile()}
assert archived=={r['path']:{'bytes':r['bytes'],'sha256':r['sha256']} for r in entries}
for name in ['summary.json','README.md']:shutil.copyfile(root/name,out/name)
shutil.copyfile(__file__,out/'package.py')
(out/'archive-members.json').write_text(json.dumps(entries,indent=2)+'\n')
(out/'excluded-binaries.json').write_text(json.dumps(excluded,indent=2)+'\n')
(out/'readback.json').write_text(json.dumps({'status':'all_members_verified','members':len(entries),'excluded_binary_count':len(excluded),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size},indent=2)+'\n')
manifest={'status':'sealed_b1','files':[{ 'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.iterdir()) if p.is_file()],'study_files':entries+excluded,'source_unchanged':True,'no_new_parser_runs_during_seal':True}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(sha(r['origin'])==r['sha256'] for r in entries+excluded)
for folder in [root,out]:
 for p in folder.rglob('*'):
  if p.is_file():p.chmod(0o444)
 for p in sorted(folder.rglob('*'),reverse=True):
  if p.is_dir():p.chmod(0o555)
 folder.chmod(0o555)
print(json.dumps({'status':'sealed_b1','manifest_sha256':sha(out/'manifest.json'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(entries),'excluded_binary_count':len(excluded),'summary_sha256':sha(root/'summary.json')},indent=2))
