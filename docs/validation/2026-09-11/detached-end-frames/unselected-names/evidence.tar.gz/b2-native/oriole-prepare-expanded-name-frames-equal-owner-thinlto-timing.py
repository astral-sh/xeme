from pathlib import Path
import difflib
import hashlib
import json
import shutil
import subprocess

out = Path('/tmp/oriole-expanded-name-frames-equal-owner-thinlto-timing-study')
out.mkdir(exist_ok=False)
study = Path('/tmp/oriole-expanded-name-frames-equal-owner-thinlto-study')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
build = json.loads((study / 'report.json').read_text())
assert build['status'] == 'passed' and build['fresh_workspace_compiles'] == 3
assert build['compiler_comparison']['matched_after_private_paths_only']
source = json.loads((study / 'source.json').read_text())
assert all(sha(Path(source['worktree']) / p) == v for p, v in source['source_sha256'].items())
assert sha(study / 'liboriole_expat.so') == 'b053dabf628ef0a2a7e83a67dcc925d0809c8272719fef7d29f4abde1d93f384'
control = Path('/tmp/oriole-thinlto-production-study/thinlto/liboriole_expat.so')
assert sha(control) == 'a55ca0f0fed68f8db0f2e8d3ea86c271c8491fe130b5074077aecace3ab4a4df'
old = Path('/tmp/oriole-thinlto-production-timing-study/native_screen.py').read_text()
new = old.replace('/tmp/oriole-thinlto-production-timing-study', str(out))
new = new.replace('/tmp/oriole-thinlto-production-study/thinlto/liboriole_expat.so', str(study / 'liboriole_expat.so'))
new = new.replace('/tmp/oriole-thinlto-production-study/normal/liboriole_expat.so', str(control))
new = new.replace('effective C-only ThinLTO build', 'expanded element start frames with equal-owner reuse in a C-only ThinLTO build')
new = new.replace('matched normal/9815cc85', 'published runtime with ThinLTO/a55ca0f0')
new = new.replace('same-source effective ThinLTO/a55ca0f0 candidate', 'expanded element start frames ThinLTO/b053dabf candidate')
new = new.replace('Oriole C-only candidate enables configured ThinLTO; matched normal and pinned Expat retain their original non-LTO flags.', 'Both Oriole C-only libraries use matched ThinLTO flags; pinned Expat retains its original non-LTO flags.')
(out / 'native_screen.py').write_text(new)
(out / 'controller.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='reviewed-thinlto-native', tofile='expanded-element-frames-thinlto-native')))
command = ['taskset', '-c', '3', 'python3', str(out / 'native_screen.py'), 'preflight']
with (out / 'preflight-controller.log').open('wb') as log:
    run = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
report = {'status': 'passed' if run.returncode == 0 else 'failed', 'command': command,
          'exit': run.returncode, 'source_manifest_sha256': sha(study / 'source.json'),
          'scope': 'Same28 original conditions,84preflights,588timedworkers. Two matched C-only ThinLTO Oriole builds; expanded element names use detached start frames and equal spellings retain their owner. Focused normal tests/source review pass; no broad gate or adoption claim. Normal instruction mean fell1.20% with10small real-condition regressions; repeated equality allocation regression corrected before this candidate. All conditions remain in elapsed measurement.'}
(out / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')
shutil.copy2(__file__, out / Path(__file__).name)
print(json.dumps(report), flush=True)
raise SystemExit(run.returncode)
