from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

out = Path('/tmp/oriole-expanded-name-frames-equal-owner-root-review')
out.mkdir(exist_ok=False)
study = Path('/tmp/oriole-expanded-name-frames-equal-owner-study')
source = json.loads((study / 'source.json').read_text())
repo = Path(source['worktree'])
sha = lambda data: hashlib.sha256(data).hexdigest()
changed = []
with tarfile.open(study / 'source.tar.gz', 'r:gz') as archive:
    members = {m.name: m for m in archive.getmembers() if m.isfile()}
    assert len(members) == len(source['source_sha256']) == 70
    for name, digest in source['source_sha256'].items():
        assert sha((repo / name).read_bytes()) == digest
        assert sha(archive.extractfile(members[name]).read()) == digest
        base = subprocess.check_output(['git', 'show', source['base'] + ':' + name], cwd=repo)
        if sha(base) != digest:
            changed.append(name)
assert changed == ['crates/oriole/src/lib.rs', 'crates/oriole/tests/adapter_frame.rs', 'crates/oriole/tests/allocation.rs']
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=repo)
assert patch == (study / 'candidate.patch').read_bytes()
report = {
    'status': 'source_review_no_blocker',
    'scope': 'Independent root source review; no compiler, parser, allocator experiment or timing run by this audit.',
    'base': source['base'], 'source_files': 70, 'changed_files': changed,
    'source_manifest_sha256': sha((study / 'source.json').read_bytes()),
    'patch_sha256': sha(patch), 'source_archive_and_live_files_exact': True,
    'findings': [],
    'reasoning': [
        'The existing identity frame predicate remains first. The added branch requires the existing complete lexical plan, one native root source without fragments, DTD/default/shared-table work or conversions, ordinary unprefixed non-xmlns attributes, a valid QName and a present binding. Generic fallbacks retain malformed and missing-prefix error precedence.',
        'Eligibility performs no expansion charge or allocation. The checked token + URI + two UTF-8 separator widths bound includes triplet punctuation; a NUL separator contributes zero. Missing bindings, invalid QName and oversized bounds choose the existing generic path.',
        'Attribute count, cache reservation, frame preparation, duplicate checks, value/name copies and id-attribute publication retain the established order. The real expand_name runs once after attributes, with its original URI charge. Seen-root/declaration flags precede the expanded frame-name copy at the prior stack-clone phase.',
        'For unequal spellings the expanded owner moves to expanded_name and the raw owner is copied afterward. For equal spellings the same String moves directly to raw_name with expanded_name None. Byte equality and absent conversion provenance preserve closing-tag matching and End callback spelling. The frame owns its independent copied spelling; no parser borrow crosses a C callback.',
        'The equal-owner case covers both NUL with URI p: and colon with URI p in non-triplet mode. It avoids the B1 discard-and-recopy regression without adding general raw-name recycling. Non-equal and const-false paths retain their former raw-name take/copy phase.',
        'Existing identity coverage remains a lower-bound assertion because eligible expanded frames add hits; complete trace comparisons remain exact. Tests retain every input split, both name editions, NUL/colon/multibyte separators, triplets, malformed and undefined prefix precedence, duplicate thresholds, arena/work boundaries, original selected-allocation workload and warmed larger-owner nested equality failure sweeps.',
    ],
    'limitations': [
        'Moving the equal owner can retain spare capacity and leave a second cached owner live. Memory remains tracked, but exact peak-memory and fail-at-N equivalence are not asserted.',
        'B1 normal6d8 had a material equality-case allocation regression and no elapsed/full-gate selection. Its source, profiles and adverse allocation evidence remain frozen separately.',
        'Focused checks, instruction profiles, allocation counts, canonical compatibility gates and elapsed performance remain separate evidence. This source review does not approve adoption or establish a speedup.',
    ],
}
(out / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
(out / 'review.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'status': report['status'], 'review_sha256': sha((out / 'review.json').read_bytes())}))
