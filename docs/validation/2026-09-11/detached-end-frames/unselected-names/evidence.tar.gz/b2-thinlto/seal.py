"""Seal the build-only ThinLTO receipt without parser execution."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
assert __debug__ and os.sched_getaffinity(0)=={2}
r=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
b=read(r/'report.json');s=read(r/'source.json');w=Path(s['worktree'])
assert b['status']=='passed' and b['source_unchanged'] and b['original_unchanged']
assert b['fresh_workspace_compiles']==3 and b['compiler_comparison']['matched_after_private_paths_only']
assert b['compiler_comparison']['normalized']['control']==b['compiler_comparison']['normalized']['candidate']
assert all(sha(r/n)==h for n,h in b['libraries'].items())
assert all(sha(p)==h for p,h in b['original_hashes'].items())
assert len(s['source_sha256'])==70 and all(sha(w/n)==h for n,h in s['source_sha256'].items())
assert subprocess.check_output(['git','diff','--binary'],cwd=w)==(r/'candidate.patch').read_bytes()
with tarfile.open(r/'source.tar.gz') as t:
 assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==s['source_sha256']
assert all(c['exit']==0 and sha(r/(c['label']+'.log'))==c['log_sha256'] for c in b['commands'])
control=Path('/tmp/oriole-thinlto-production-study');(r/'control').mkdir()
for n in ['source.json','report.json','thinlto-compiler-invocations.json']:
 shutil.copyfile(control/n,r/'control'/n)
summary={'status':'sealed_fresh_matched_c_only_thinlto','cpu':2,'source_manifest_sha256':sha(r/'source.json'),'source_files':70,'source_unchanged':True,'patch_sha256':sha(r/'candidate.patch'),'fresh_workspace_compiles':3,'final_crate_types':['cdylib','staticlib'],'final_lto':'thin','actual_compile_commands_match_after_private_paths_only':True,'report_sha256':sha(r/'report.json'),'libraries':b['libraries'],'control_library_sha256':'a55ca0f0fed68f8db0f2e8d3ea86c271c8491fe130b5074077aecace3ab4a4df','normal_library_sha256':'a425e2290f46310ef45152dbff6b7447535c573211337792fca085fbb178dd55','normal_handoff':'/tmp/oriole-expanded-name-frames-equal-owner-handoff','original_evidence_unchanged':True,'failed_or_discarded_builds':0,'no_parser_test_profile_timing_or_full_gate_runs':True,'no_source_edit_commit_or_push':True}
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(r/'README.md').write_text('''# B2 C-only ThinLTO build

Fresh build of the frozen expanded-name/equal-owner source, on CPU2, for a matched elapsed comparison against the current a55 C-only ThinLTO control. All three workspace libraries actually recompiled; final artifacts include only cdylib/staticlib with lto=thin. Saved full compiler commands match the control after only worktree/private build paths. All70 source bytes, prior normal build/profile/allocation evidence, and control artifacts remain unchanged. This controller ran no parser tests, profiles, timing or full gates. Build passed on the first attempt; source and independent reviews are preserved in the normal B2 handoff.
''')
rows=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(r.rglob('*')) if p.is_file()]
(r/'manifest.json').write_text(json.dumps({'status':'sealed','files':rows,'source_archive_live_and_patch_verified':True,'no_parser_runs_during_seal':True},indent=2)+'\n')
assert all(sha(r/x['path'])==x['sha256'] for x in rows)
for p in r.rglob('*'):
 if p.is_file():p.chmod(0o444)
for p in sorted(r.rglob('*'),reverse=True):
 if p.is_dir():p.chmod(0o555)
r.chmod(0o555)
print(json.dumps({'status':'sealed','files':len(rows),'manifest_sha256':sha(r/'manifest.json'),'report_sha256':sha(r/'report.json'),'summary_sha256':sha(r/'summary.json')},indent=2))
