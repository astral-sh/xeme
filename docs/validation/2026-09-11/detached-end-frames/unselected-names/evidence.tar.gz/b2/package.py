"""Seal B2 source/build/profiles/counts for the parent decision before elapsed/full gates."""
from pathlib import Path
import gzip, hashlib, json, os, re, shutil, subprocess, tarfile
assert __debug__ and os.sched_getaffinity(0) == {2}
root=Path('/tmp/oriole-expanded-name-frames-equal-owner-study')
out=Path('/tmp/oriole-expanded-name-frames-equal-owner-handoff')
read=lambda p: json.loads(Path(p).read_text())
sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=read(root/'source.json'); worktree=Path(source['worktree'])
assert len(source['source_sha256'])==70
assert all(sha(worktree/p)==h for p,h in source['source_sha256'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=worktree,text=True).strip()==source['base']
assert subprocess.check_output(['git','diff','--binary'],cwd=worktree)==(root/'candidate.patch').read_bytes()
with tarfile.open(root/'source.tar.gz') as tar:
 assert {m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar if m.isfile()}==source['source_sha256']
build=read(root/'build.json'); profile=read(root/'profile/report.json'); protocol=read(root/'profile/protocol.json')
assert build['status']==profile['status']=='passed'
assert all(sha(root/n)==h for n,h in build['libraries'].items())
assert all(row['exit']==0 and sha(root/(row['name']+'.log'))==row['log_sha256'] for row in build['commands'])
counts={name:sum(map(int,re.findall(r'test result: ok\. (\d+) passed',(root/(name+'.log')).read_text()))) for name in ['core-unit','focused','ffi-focused']}
assert counts=={'core-unit':56,'focused':109,'ffi-focused':88}
assert read(root/'compiler-comparison.json')['status']=='matched_after_private_paths_only'
assert len(profile['rows'])==len(read(root/'profile/preflights.json'))==32 and len(profile['comparisons'])==16
assert profile['hashes_after']==protocol['hashes_before'] and all(sha(p)==h for p,h in protocol['hashes_before'].items())
attr=read(root/'profile-attribution.json'); alloc=read(root/'allocation-counts/report.json')
assert attr['status']=='paired_saved_attribution_reconstructed' and all(sha(p)==h for p,h in attr['hashes'].items())
assert alloc['status']=='passed' and alloc['cases']==15 and alloc['engines']==2
assert alloc['before']==alloc['after'] and all(sha(p)==h for p,h in alloc['after'].items())
assert alloc['all_callback_records_exact'] and alloc['all_selected_blocks_freed']
review=read(root/'reviews/root-source-review/review.json')
assert review['status']=='source_review_no_blocker' and review['source_manifest_sha256']==sha(root/'source.json')
assert sha(root/'reviews/independent-design/review.json')=='fd12c97750eaa13a0918c81b606eea5dbfc90e75fa86f0251311dd2b5d189ea2'
b1=Path('/tmp/oriole-expanded-name-frames-study'); b1source=read(b1/'source.json')
assert all(sha(Path(b1source['worktree'])/p)==h for p,h in b1source['source_sha256'].items())

refs=root/'references'; refs.mkdir(exist_ok=False)
for folder in ['design','inputs','control']:(refs/folder).mkdir()
for p in sorted(Path('/tmp/oriole-namespace-storage-design-review').iterdir()):
 if p.is_file():shutil.copyfile(p,refs/'design'/p.name)
shutil.copyfile('/tmp/oriole-expanded-name-frames-equal-owner-preparation.json',refs/'preparation.json')
for name in ['source.json','build.json','compiler-invocations.json']:
 shutil.copyfile(Path('/tmp/oriole-start-frame-integration-study')/name,refs/'control'/name)
inputs=[]
for i,p in enumerate(sorted({r['input'] for r in profile['comparisons']})):
 p=Path(p); target=refs/'inputs'/f'{i:02d}-{p.name}'; shutil.copyfile(p,target)
 inputs.append({'origin':str(p),'archived':str(target.relative_to(root)),'sha256':sha(p)})
(refs/'inputs/index.json').write_text(json.dumps(inputs,indent=2)+'\n')
(refs/'b1').mkdir()
for n in ['manifest.json','summary.json','readback.json']:
 shutil.copyfile(Path('/tmp/oriole-expanded-name-frames-b1-handoff')/n,refs/'b1'/n)
projects=[r for r in profile['comparisons'] if r['kind']=='project']
generated=[r for r in profile['comparisons'] if r['kind']=='generated']
summary={'status':'b2_frozen_after_causal_screen_before_elapsed_or_full_gates',
 'decision':'B2 addresses the B1 equality ownership regression; parent decides any elapsed screen and full gates. No adoption claim.',
 'base':source['base'],'source_manifest_sha256':sha(root/'source.json'),'source_files':70,'source_unchanged':True,'patch_sha256':sha(root/'candidate.patch'),
 'libraries':build['libraries'],'control_library_sha256':'9815cc852327d455c094b0fb72c1d33fb90a4571e67cf15965e96e2300376828',
 'implementation':'B expanded-element literal frames with exact equality owner move after frame.set_name: equal expanded owner becomes Element.raw_name with expanded_name=None; unequal/identity paths retain subsequent raw copy. All eligibility, duplicate/QName/URI charge/flags/frame/stack/empty-end/publication phases remain. A raw-name recycling unchanged.',
 'validation':{'focused_tests':counts,'total_focused_tests':sum(counts.values()),'core_clippy':'passed','fresh_workspace_library_compiles':3,'compiler_flags_match_after_only_private_paths':True,'compiler_comparison_sha256':sha(root/'compiler-comparison.json'),'root_source_review_sha256':sha(root/'reviews/root-source-review/review.json'),'independent_equality_design_review_sha256':sha(root/'reviews/independent-design/review.json')},
 'profiles':{'conditions':16,'preflight_processes':32,'callgrind_processes':32,'parses_per_process':2,'both_warmup_and_measured_collected':True,'cpu':2,'all_observations_equal_control':True,'real_project_geomean':profile['project_instruction_ratio_geomean'],'generated_geomean':attr['generated_instruction_ratio_geomean'],'real_conditions_lower':sum(r['candidate_over_control']<1 for r in projects),'real_conditions_total':12,'generated_conditions_higher':sum(r['candidate_over_control']>1 for r in generated),'comparisons':profile['comparisons'],'report_sha256':sha(root/'profile/report.json'),'attribution_sha256':sha(root/'profile-attribution.json')},
 'allocation_proof':{'cases':15,'engines':2,'warmup_units':8,'measured_units':128,'original12_retained':True,'additional_cases':['colon-equal-spelling','nul-equal-nested','colon-equal-nested'],'nested_unit_elements':17,'nested_warmup_name_bytes':1024,'all_callback_records_exact':True,'all_selected_blocks_freed':True,'report_sha256':sha(root/'allocation-counts/report.json'),'comparisons':alloc['comparisons'],'limits':alloc['scope']},
 'interpretation':'Maven NS -6.61% Ir and DocBook NS -9.59%; other10 real conditions +0.11 to +0.40%. All4 generated controls regress by0.0000114% to0.05646%. Required expand_name calls remain. Ordinary repeated namespace fixtures do not reduce allocation calls. Equality empty fixtures now need1 measured malloc/1realloc versus control0/1, removing B1 NUL129/129 per-node regression. Nested equality mallocs2048→1922 with realloc3→4; measured peak bytes95510→95523 for NUL and95522→95519 for colon, so no peak monotonicity claim.',
 'b1':'Original B1 archive, source checkout and results remain unchanged; its selected-allocator regression is retained in separate handoff. B1 manifest/summary/readback copied as references.',
 'failure_controls':'Existing original and namespace allocation workloads retained; NUL and colon cases warm a larger raw owner before nested equality starts and empty/explicit ends. Every selected allocator failure is swept and repeated terminal error requires zero new allocation and inactive frame. Counts controller measures successful C custom allocator behavior separately.',
 'outer_guard_verified':'Unchanged no seen_doctype, no foreign_dtd, no shared_tables, !fragment, one source, native_utf8_byte_index; expansion branch also !has_conversions.',
 'failures':[],'no_discarded_parser_runs':True,'no_elapsed_or_full_gate_runs':True,'no_commits_or_pushes':True,
 'limitations':['No full conformance/native sanitizer/CPython gates yet.','Equal owner move intentionally removes the second raw-copy failure point; exact OOM indices/peak thresholds are not preserved. Capacity and unused second cached owner remain tracked under existing budgets.','Function self costs are disjoint; inclusive edge costs overlap. Inlining merges frame helpers into parse_start.','All16 conditions retained, including10 real and4 generated instruction regressions; instruction counts do not establish elapsed throughput.']}

(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(root/'README.md').write_text('''# Expanded element start frames: B2 equality owner

B2 is frozen for the parent decision before elapsed timing or full gates. It moves an exactly equal expanded spelling into the raw stack field after the existing frame-name copy. The original B1 source and evidence remain frozen separately. No end raw-name recycling is added.

All253 focused tests, core Clippy, and three fresh normal workspace library compiles passed on the first attempt. Compiler commands match normal9815 after only worktree/private build paths. Independent design and final source reviews found no source-invariant blocker. All32 preflights and32 instruction profiles matched callback observations. The twelve real conditions improve1.20% geometrically: Maven NS6.61% and DocBook NS9.59%, while the other ten regress0.11–0.40%. All four generated controls regress slightly and remain retained.

The selected-allocator proof retains all twelve B1 conditions and adds colon equality plus NUL/colon16-level nested trees, with a1024-byte warmup name. All callback/position records match and every block is freed. Equality now needs1 measured malloc/1realloc versus control0/1, eliminating B1's129/129 per-node regression. Ordinary namespace fixtures retain their slightly higher call counts. Nested equality mallocs fall2048→1922, while NUL measured peak rises13 bytes and colon falls3 bytes; no general peak/OOM-threshold identity is claimed. The frozen Rust selected-allocation sweep separately exercises nested equality and repeated terminal errors.

This handoff contains the patch, all70 source files, build/focused-test logs, compiler comparison, all instruction/preflight records and inputs, all selected-allocator records/controllers, and design/source reviews. No elapsed, full native/conformance/CPython gates, commits, or pushes occurred in this bounded task.
''')

out.mkdir(exist_ok=False)
entries=[]; excluded=[]
for p in sorted(root.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink()
 data=p.read_bytes(); row={'path':str(p.relative_to(root)),'origin':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 (excluded if data.startswith((b'\x7fELF',b'!<arch>\n')) else entries).append(row)
archive=out/'evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|') as tar:
   for row in entries:
    info=tarfile.TarInfo(row['path']); info.size=row['bytes'];info.mode=0o444;info.mtime=0
    with Path(row['origin']).open('rb') as stream:tar.addfile(info,stream)
with tarfile.open(archive) as tar:
 archived={m.name:{'bytes':m.size,'sha256':hashlib.sha256(tar.extractfile(m).read()).hexdigest()} for m in tar if m.isfile()}
assert archived=={r['path']:{'bytes':r['bytes'],'sha256':r['sha256']} for r in entries}
for name in ['summary.json','README.md']:shutil.copyfile(root/name,out/name)
shutil.copyfile(__file__,out/'package.py')
(out/'archive-members.json').write_text(json.dumps(entries,indent=2)+'\n')
(out/'excluded-binaries.json').write_text(json.dumps(excluded,indent=2)+'\n')
(out/'readback.json').write_text(json.dumps({'status':'all_members_verified','members':len(entries),'excluded_binary_count':len(excluded),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size},indent=2)+'\n')
manifest={'status':'sealed_b2_before_elapsed_or_full_gates','files':[{ 'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.iterdir()) if p.is_file()],'study_files':entries+excluded,'source_unchanged':True,'no_new_parser_runs_during_seal':True}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(sha(r['origin'])==r['sha256'] for r in entries+excluded)
for folder in [root,out]:
 for p in folder.rglob('*'):
  if p.is_file():p.chmod(0o444)
 for p in sorted(folder.rglob('*'),reverse=True):
  if p.is_dir():p.chmod(0o555)
 folder.chmod(0o555)
print(json.dumps({'status':'sealed_b2_before_elapsed_or_full_gates','manifest_sha256':sha(out/'manifest.json'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(entries),'excluded_binary_count':len(excluded),'summary_sha256':sha(root/'summary.json')},indent=2))
