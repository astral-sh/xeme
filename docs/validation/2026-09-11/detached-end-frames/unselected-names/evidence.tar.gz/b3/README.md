# B3 expanded-only wrapper: stated codegen criterion not met

B3 changed one call and added a private inline-never expanded wrapper. Source review found no blocker and a fresh C-only ThinLTO build matched a55 compiler commands after private paths, with three actual workspace compiles. No parser tests, profiles, timing or full gates were run.

The wrapper is out of line, and parse_start shrinks from B2's24,162 bytes to20,328 (a55:19,559). Its stack reservation shrinks2,088→2,008 bytes but remains48 bytes above a55's1,960. Crucially, the identity path still calls the outlined340-byte push_attribute helper once; the new wrapper also calls it once. a55 inlines that helper and has no such call. The required old identity inlining/frame restoration did not occur. This is a partial codegen change, not a demonstrated performance recovery. All B2 evidence and its negative elapsed screen remain unchanged.
