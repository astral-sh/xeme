# B4 ordinary inline hint: criterion not met

B4 adds only #[inline] to AdapterFrame::push_attribute atop frozen B3. Fresh C-only ThinLTO compiled all three workspace libraries with actual commands matching a55 after private paths. The hint did not restore inlining: common parse_start and the expanded wrapper still call push_attribute once each. parse_start remains20,328 bytes/3,740 static instructions with a2,008-byte stack reservation; the wrapper remains3,806 bytes/687 instructions and helper340 bytes/89 instructions, exactly the B3 sizes/counts.

Neither required criterion is met: the two calls remain out of line and the common stack does not improve. No instruction profiles, preflights, parser tests, elapsed timings, full gates, additional hints or retries were run. The one-line source delta, frozen70-file source map, matched build and all four-way static evidence are retained. Prior B2/B3 source and all negative evidence remain unchanged.
