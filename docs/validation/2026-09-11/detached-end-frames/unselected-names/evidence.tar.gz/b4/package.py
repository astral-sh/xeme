from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile
assert __debug__ and os.sched_getaffinity(0)=={2}
roots={'source':Path('/tmp/oriole-expanded-name-frames-attribute-inline-study'),'thinlto':Path('/tmp/oriole-expanded-name-frames-attribute-inline-thinlto-study'),'codegen':Path('/tmp/oriole-expanded-name-frames-attribute-inline-codegen-review')}
o=Path('/tmp/oriole-expanded-name-frames-attribute-inline-handoff');o.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
s=read(roots['source']/'source.json');b=read(roots['thinlto']/'report.json');c=read(roots['codegen']/'review.json');w=Path(s['worktree'])
assert len(s['source_sha256'])==70 and all(sha(w/n)==h for n,h in s['source_sha256'].items())
assert sha(roots['source']/'source.json')=='033fd61e2a37de13799273c6b51184d17c4b7060761850c74b8f380be83f96a9'
assert subprocess.check_output(['git','diff','--binary'],cwd=w)==(roots['source']/'candidate.patch').read_bytes()
assert b['status']=='passed' and b['fresh_workspace_compiles']==3 and b['source_unchanged'] and b['original_unchanged']
assert b['compiler_comparison']['matched_after_private_paths_only']
assert all(sha(p)==h for p,h in b['original_hashes'].items()) and all(sha(roots['thinlto']/n)==h for n,h in b['libraries'].items())
assert c['status']=='ordinary_inline_hint_did_not_meet_codegen_criteria'
summary={'status':c['status'],'source_manifest_sha256':sha(roots['source']/'source.json'),'source_files':70,'source_unchanged':True,'b3_to_b4_patch_sha256':sha(roots['source']/'b3-to-b4.patch'),'full_patch_sha256':sha(roots['source']/'candidate.patch'),'libraries':b['libraries'],'fresh_matched_workspace_compiles':3,'source_review':'Parent explicitly authorized one ordinary inline hint after inspecting the helper and prior codegen.','static_comparisons':c['comparisons'],'static_criteria':c['criteria'],'no_parser_test_profile_timing_or_full_gate_runs':True,'no_commit_or_push':True,'failed_or_discarded_builds':0,'decision':'Preserve B4 ordinary inline hint with neither codegen criterion met; no profiles or elapsed screen. Any always-inline mechanism test is a separate explicitly authorized prototype.'}
(o/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copyfile(__file__,o/'package.py');shutil.copyfile(roots['codegen']/'README.md',o/'README.md')
entries=[];excluded=[]
for label,r in roots.items():
 for p in sorted(r.rglob('*')):
  if not p.is_file():continue
  data=p.read_bytes();row={'path':label+'/'+str(p.relative_to(r)),'origin':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};(excluded if data.startswith((b'\x7fELF',b'!<arch>\n')) else entries).append(row)
a=o/'evidence.tar.gz'
with a.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|') as t:
   for row in entries:
    info=tarfile.TarInfo(row['path']);info.size=row['bytes'];info.mode=0o444;info.mtime=0
    with Path(row['origin']).open('rb') as f:t.addfile(info,f)
with tarfile.open(a) as t:
 assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}=={x['path']:x['sha256'] for x in entries}
(o/'archive-members.json').write_text(json.dumps(entries,indent=2)+'\n');(o/'excluded-binaries.json').write_text(json.dumps(excluded,indent=2)+'\n')
(o/'readback.json').write_text(json.dumps({'status':'all_members_verified','members':len(entries),'archive_sha256':sha(a),'archive_bytes':a.stat().st_size,'excluded_binaries':len(excluded)},indent=2)+'\n')
(o/'manifest.json').write_text(json.dumps({'status':'sealed','study_files':entries+excluded,'files':[{'path':p.name,'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(o.iterdir()) if p.is_file()]},indent=2)+'\n')
for r in [*roots.values(),o]:
 for p in r.rglob('*'):
  if p.is_file():p.chmod(0o444)
 for p in sorted(r.rglob('*'),reverse=True):
  if p.is_dir():p.chmod(0o555)
 r.chmod(0o555)
print(json.dumps({'status':'sealed_b4_criterion_not_met','manifest_sha256':sha(o/'manifest.json'),'archive_sha256':sha(a),'summary_sha256':sha(o/'summary.json'),'members':len(entries),'archive_bytes':a.stat().st_size},indent=2))
