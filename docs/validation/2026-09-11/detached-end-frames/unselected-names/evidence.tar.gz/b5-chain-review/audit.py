"""Independent B2→B5 source, fresh build, static mechanism and saved Ir audit."""
from pathlib import Path
from collections import Counter
import hashlib,json,math,os,re,shlex,struct,subprocess,tarfile
assert os.sched_getaffinity(0)=={4}
O=Path(__file__).parent;H=Path('/tmp/oriole-expanded-name-frames-attribute-always-handoff');T=Path('/tmp/oriole-expanded-name-frames-attribute-always-thinlto-study');C=Path('/tmp/oriole-expanded-name-frames-attribute-always-codegen-review');BASE='50c20c1e73eeaacabb9df90e413f502361fb45b3'
tracked={};checks=[];gitreads=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p);b=p.read_bytes();assert tracked.setdefault(str(p),sha(b))==sha(b),p;return b
def j(p):return json.loads(read(p))
def ck(v,m):assert v,m;checks.append(m)
def put(n,d):(O/n).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def git(work,*args):
 cmd=['git','-C',str(work),*args];r=subprocess.run(cmd,capture_output=True,timeout=30);gitreads.append({'command':cmd,'exit':r.returncode,'stdout_sha256':sha(r.stdout),'stderr':r.stderr.decode()});ck(r.returncode==0,'read-only Git '+' '.join(args));return r.stdout
summary=j(H/'summary.json');manifest=j(H/'manifest.json');members=j(H/'archive-members.json')
ck(manifest['status']=='sealed' and members==[r for r in manifest['study_files'] if r['path'] not in {e['path'] for e in j(H/'excluded-binaries.json')}],'sealed handoff member inventory')
for r in manifest['files']:
 b=read(H/r['path']);ck(len(b)==r['bytes'] and sha(b)==r['sha256'],'outer handoff '+r['path'])
with tarfile.open(H/'evidence.tar.gz') as tar:
 ms=tar.getmembers();ck(len(ms)==len(members) and len({m.name for m in ms})==len(ms),'unique direct members')
 for m,r in zip(ms,members,strict=True):
  ck(m.isfile() and m.name==r['path'] and m.size==r['bytes'],'regular archive member '+m.name)
  b=tar.extractfile(m).read();ck(sha(b)==r['sha256']==sha(read(r['origin'])),'archive/origin exact '+m.name)
excluded=j(H/'excluded-binaries.json');ck(len(excluded)==2,'two direct binary exclusions')
for r in excluded:
 b=read(r['origin']);ck(len(b)==r['bytes'] and sha(b)==r['sha256'] and b.startswith((b'\x7fELF',b'!<arch>\n')),'excluded compiled artifact '+r['path'])
variants={'b2':'equal-owner','b3':'outlined','b4':'attribute-inline','b5':'attribute-always'};sources={};srcbytes={}
for variant,suffix in variants.items():
 d=Path('/tmp/oriole-expanded-name-frames-'+suffix+'-study');s=j(d/'source.json');sources[variant]=s;srcbytes[variant]={}
 ck(s['base']==BASE and len(s['source_sha256'])==70,'70 source manifest and50c20 base '+variant)
 with tarfile.open(d/'source.tar.gz') as tar:
  ms=tar.getmembers();ck(len(ms)==70 and all(m.isfile() for m in ms),'70 frozen archive '+variant)
  for m in ms:
   b=tar.extractfile(m).read();ck(sha(b)==s['source_sha256'][m.name],'source archive hash '+variant+'/'+m.name);srcbytes[variant][m.name]=b
  for n,digest in s['source_sha256'].items():ck(sha(read(Path(s['worktree'])/n))==digest,'unchanged variant live '+variant+'/'+n)
 ck(git(s['worktree'],'diff','--binary',BASE)==read(d/'candidate.patch'),'full exact patch '+variant)
 sourcecopy=O/(variant+'-source.json');sourcecopy.write_bytes(read(d/'source.json'))
root_review=j('/tmp/oriole-expanded-name-frames-equal-owner-root-review/review.json')
ck(sha(read('/tmp/oriole-expanded-name-frames-equal-owner-root-review/review.json'))=='498b98e75f4aaa4633d3a827f7951f66136269c8d5afb41022e5d71cbcd2696b','prior independentB2 source review pinned')
ck(root_review['source_manifest_sha256']==sha(read('/tmp/oriole-expanded-name-frames-equal-owner-study/source.json')) and root_review['patch_sha256']==sha(read('/tmp/oriole-expanded-name-frames-equal-owner-study/candidate.patch')),'B2 reviewed exact source and patch')
basebytes={n:git(sources['b5']['worktree'],'show',BASE+':'+n) for n in sources['b5']['source_sha256']}
ck(sorted(n for n in basebytes if basebytes[n]!=srcbytes['b2'][n])==sorted(root_review['changed_files']),'B2 changed file scope matches independent review')
lib='crates/oriole/src/lib.rs';arena='crates/oriole/src/arena.rs'
ck([n for n in srcbytes['b3'] if srcbytes['b3'][n]!=srcbytes['b2'][n]]==[lib],'B3 onlylib wrapper')
s3=srcbytes['b3'][lib].decode();start=s3.index('    /// Keep expanded lowering out of the common start parser');end=s3.index('    /// Lower a validated literal tag, optionally',start);wrapper=s3[start:end]
ck('#[inline(never)]' in wrapper and wrapper.count('self.parse_start_frame::<true>(token, position, name, rest, frame)')==1,'single direct generic-true delegation in wrapper')
reconstructed=s3[:start]+s3[end:];reconstructed=reconstructed.replace('return self.parse_expanded_start_frame(token, position, raw_name, rest, frame);','return self.parse_start_frame::<true>(token, position, raw_name, rest, frame);')
ck(reconstructed.encode()==srcbytes['b2'][lib],'inverse wrapper fully reconstructs B2; no changed semantic steps')
ck([n for n in srcbytes['b4'] if srcbytes['b4'][n]!=srcbytes['b3'][n]]==[arena] and srcbytes['b4'][arena].replace(b'    #[inline]\n    pub(crate) fn push_attribute',b'    pub(crate) fn push_attribute')==srcbytes['b3'][arena],'B4 only inline attribute')
ck([n for n in srcbytes['b5'] if srcbytes['b5'][n]!=srcbytes['b4'][n]]==[arena] and srcbytes['b5'][arena].replace(b'#[inline(always)]',b'#[inline]')==srcbytes['b4'][arena],'B5 only force-inline attribute')
ck(summary['source_manifest_sha256']==sha(read(T/'source.json'))==sha(read('/tmp/oriole-expanded-name-frames-attribute-always-study/source.json')),'measured70 exactB5 source')
ck(summary['full_patch_sha256']==sha(read(T/'candidate.patch')),'measured full patch exact')
with tarfile.open(T/'source.tar.gz') as tar:
 for m in tar:
  ck(tar.extractfile(m).read()==srcbytes['b5'][m.name],'measured source archive exact '+m.name)
# Independently reconstruct effective compiler vectors from verbose logs, without compiler execution.
build=j(T/'report.json');control=j('/tmp/oriole-thinlto-production-study/report.json');control_rows=j('/tmp/oriole-thinlto-production-study/thinlto-compiler-invocations.json');rows=j(T/'compiler-invocations.json')
ck(build['status']=='passed' and build['source_unchanged'] and build['original_unchanged'],'successful fresh build source gate')
for r in build['commands']:ck(r['exit']==0 and sha(read(T/(r['label']+'.log')))==r['log_sha256'],'saved build command '+r['label'])
raw=read(T/'release.log').decode();lines=[x for x in raw.splitlines() if 'Running `' in x and '/rustc ' in x]
rederived=[]
for line in lines:
 args=shlex.split(line.strip()[len('Running `'):-1]);rederived.append({'crate':args[args.index('--crate-name')+1],'command_line':line,'codegen_options':[args[i+1] for i,x in enumerate(args[:-1]) if x=='-C'],'crate_types':[args[i+1] for i,x in enumerate(args[:-1]) if x=='--crate-type']})
ck(rows==rederived,'every recorded compiler row exact verbose log')
normalized={}
for label,rs,work in [('control',control_rows,'/home/dev-user/code/oss/oriole-thinlto-production'),('candidate',rows,sources['b5']['worktree'])]:
 normalized[label]={}
 for crate in ['oriole_storage','oriole','oriole_expat']:
  selected=[r for r in rs if r['crate']==crate];ck(len(selected)==1,'exactlyone actual full compiler '+label+'/'+crate)
  row=selected[0];line=row['command_line'].replace(work,'<WORKTREE>');line,n=re.subn(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}','<PRIVATE_BUILD>',line);ck(n>=3,'only private path normalization '+label+'/'+crate);normalized[label][crate]=line
  ck(('lto=thin' if crate=='oriole_expat' else 'linker-plugin-lto') in row['codegen_options'],'actual ThinLTO '+label+'/'+crate)
  if crate=='oriole_expat':ck(row['crate_types']==['cdylib','staticlib'],'actual C-only outputs '+label)
ck(normalized['control']==normalized['candidate']==build['compiler_comparison']['normalized']['candidate'] and normalized==build['compiler_comparison']['normalized'],'complete compiler vectors equal after private paths only')
ck({k:v for k,v in build['env_overrides'].items() if k!='CARGO_TARGET_DIR'}=={k:v for k,v in control['env_overrides'].items() if k!='CARGO_TARGET_DIR'},'same base build environment except distinct target')
ck(build['rustc_version']==control['rustc_version']==read(T/'rustc-version.log').decode(),'same exact compiler version')
for n,digest in build['libraries'].items():ck(sha(read(T/n))==digest==summary['libraries'][n],'frozen measured library '+n)
for p,digest in build['original_hashes'].items():ck(sha(read(p))==digest,'prior variant/control preserved '+p)
# Reconstruct fixed profiles from all raw parse output, summary counters and disjoint annotation lines.
P=T/'profile';protocol=j(P/'protocol.json');profile=j(P/'report.json');pre=j(P/'preflights.json');origins=j(P/'origins.json')
ck(protocol['affinity']==[2] and len(protocol['conditions'])==16 and len(pre)==32 and len(profile['rows'])==32 and profile['status']=='passed','fixed16/32 profile scope')
oldprotocol=j(protocol['condition_identity_verified_against'])
for a,b in zip(protocol['conditions'],oldprotocol['conditions'],strict=True):ck({k:v for k,v in a.items() if k!='input'}=={k:v for k,v in b.items() if k!='input'} and read(a['input'])==read(b['input']),'original condition/bytes preserved '+a['workload'])
for p,digest in protocol['hashes_before'].items():ck(sha(read(p))==digest==profile['hashes_after'][p],'profile immutable input '+p)
for label,r in origins.items():ck(r['path']==protocol['libraries'][label] and sha(read(r['path']))==r['sha256'],'collector origin receipt '+label)
def obs(stem):
 d=json.loads(read(P/(stem+'.stdout')));samples=d['samples'];ck(len(samples)==2 and [s['warmup'] for s in samples]==[True,False],'exact2 samples '+stem)
 values=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in samples});ck(len(values)==1,'bothsamples same deterministic observation '+stem);return [list(v) for v in values]
profiles={};samples=0
for i,c in enumerate(protocol['conditions']):
 compared={}
 for label,path in protocol['libraries'].items():
  stem=f'{i:02}-{c["workload"]}-ns{int(c["namespaces"])}-{c["chunk"]}-{label}'
  gate=next(r for r in pre if r['condition']==i and r['library']==label);row=next(r for r in profile['rows'] if r['condition']==i and r['library']==label)
  expected=[protocol['hashes_before'] and '/tmp/oriole-grammar-bench-plain/native-driver',path,c['input'],str(c['chunk']),'1']+(['namespaces'] if c['namespaces'] else [])
  ck(gate['command']==expected,'exact nativepreflight args '+stem)
  a=obs(stem+'-preflight');b=obs(stem);samples+=4;ck(a==b==gate['observed']==row['observed'],'all warm/measured/preflight/profile observations '+stem);compared[label]=a
  cg=read(P/(stem+'.callgrind')).decode();ck('events: Ir\n' in cg and 'positions: line\n' in cg,'pinned callgrind event/position format '+stem)
  total=int(re.search(r'^summary: (\d+)',cg,re.M)[1]);ck(total==row['Ir'] and total>0,'raw CallgrindIr '+stem)
  stderr=read(P/(stem+'.stderr')).decode();ck(int(re.search(r'Collected\s*:\s*(\d+)',stderr)[1])==total,'stderr Collected Ir '+stem)
  annotation=read(P/(stem+'-annotation.stdout')).decode();functions=[]
  for line in annotation.splitlines():
   m=re.match(r'^\s*([\d,]+)\s+(.+?) \[([^\]]+)\]$',line)
   if m:functions.append({'Ir':int(m[1].replace(',','')),'function':m[2],'object':m[3]})
  ck(functions==row['functions'] and total-sum(f['Ir'] for f in functions)==row['unparsed_Ir']>=0,'all disjoint self function totals '+stem)
  for suffix in ['-preflight.stderr','-annotation.stderr']:read(P/(stem+suffix))
  profiles[i,label]=total
 ck(compared['control']==compared['candidate'],'paired normalized outcomes '+str(i))
comparisons=[]
for i,c in enumerate(protocol['conditions']):
 values={label:profiles[i,label] for label in protocol['libraries']};comparisons.append(c|values|{'candidate_over_control':values['candidate']/values['control']})
ck(comparisons==profile['comparisons']==summary['instruction_comparisons'],'all16 exact ratios')
geo=math.exp(sum(math.log(r['candidate_over_control']) for r in comparisons if r['kind']=='project')/12);gen=math.exp(sum(math.log(r['candidate_over_control']) for r in comparisons if r['kind']=='generated')/4)
ck(geo==profile['project_instruction_ratio_geomean']==summary['project_instruction_ratio_geomean'] and gen==summary['generated_instruction_ratio_geomean'],'all instruction geomeans')
ck(sum(r['candidate_over_control']<1 for r in comparisons if r['kind']=='project')==5 and all(r['candidate_over_control']>1 for r in comparisons if r['kind']=='generated'),'5/12real lower and all4 generated worse retained')
# Static ELF and saved disassembly evidence, without executing binaries or rewriting ELF.
static=j(C/'report.json');mechanism=j(C/'review.json');static_rows={}
def sections(b):
 ck(b[:6]==b'\x7fELF\x02\x01','little-endian64 ELF')
 off=struct.unpack_from('<Q',b,40)[0];size,count,strings=struct.unpack_from('<HHH',b,58);rows=[struct.unpack_from('<IIQQQQIIQQ',b,off+i*size) for i in range(count)];s=rows[strings];names=b[s[4]:s[4]+s[5]]
 return {names[r[0]:].split(b'\0',1)[0].decode():r for r in rows}
startname='<oriole::Parser>::parse_start';wrapname='<oriole::Parser>::parse_expanded_start_frame';push='<oriole::arena::AdapterFrame>::push_attribute';append='<oriole::arena::AdapterFrame>::append'
for label,data in static['results'].items():
 b=read(data['path']);ck(sha(b)==data['sha256'],'five-way static binary '+label);sec=sections(b)['.text'];bytepart=b[sec[4]:sec[4]+sec[5]]
 for name,item in data['selected'].items():
  asm=read(C/item['asm']).decode();ins=[(int(m[1],16),m[2]) for line in asm.splitlines() if (m:=re.match(r'\s*([0-9a-f]+):\s+(.+)',line))];calls=Counter()
  for address,op in ins:
   if op.startswith(('call','jmp')) and '<' in op:
    target=op.split('<',1)[1].rsplit('>',1)[0]
    if '+0x' not in target or not target.startswith(name):calls[target]+=1
  ck(len(ins)==item['instructions'] and dict(calls)==item['direct_call_or_tail_targets'],'saved disassembly counts '+label+'/'+name)
  ck([{'offset':a-item['address'],'text':op} for a,op in ins[:20]]==item['entry'],'disassembly prologue entries '+label+'/'+name)
 p=data['selected'][startname];w=data['selected'].get(wrapname,{})
 def stack(x):return int(next(re.search(r'\$0x([0-9a-f]+),%rsp',v['text'])[1] for v in x['entry'] if v['text'].startswith('sub')),16)
 row={'sha256':sha(b),'file_bytes':len(b),'text_bytes':sec[5],'text_sha256':sha(bytepart),'parse_start_bytes':p['size'],'parse_start_static_instructions':p['instructions'],'stack_reservation_bytes':stack(p),'parse_start_push_attribute_callsites':p['direct_call_or_tail_targets'].get(push,0),'parse_start_append_callsites':p['direct_call_or_tail_targets'].get(append,0),'wrapper_push_attribute_callsites':w.get('direct_call_or_tail_targets',{}).get(push,0),'wrapper_append_callsites':w.get('direct_call_or_tail_targets',{}).get(append,0),'wrapper_bytes':w.get('size'),'wrapper_stack_bytes':stack(w) if w else None,'push_attribute_symbol_present':push in data['symbols']}
 ck(row==mechanism['comparisons'][label]==summary['static_comparisons'][label],'all static summary fields '+label);static_rows[label]=row
ck(static_rows['b3']['text_sha256']==static_rows['b4']['text_sha256'],'ordinary hint left exacttext unchanged')
ck(static_rows['candidate']['parse_start_append_callsites']==3 and static_rows['candidate']['wrapper_append_callsites']==3 and not static_rows['candidate']['push_attribute_symbol_present'],'forced inline restored direct appends')
ck(static_rows['candidate']['stack_reservation_bytes']-static_rows['control']['stack_reservation_bytes']==48 and static_rows['candidate']['parse_start_bytes']-static_rows['control']['parse_start_bytes']==1730,'48byte stack and1730byte code cost explicit')
# Preserve concrete source excerpts and prior review; do not transfer unrun broad-gate claims.
for p in [T/'collect_profiles.py',T/'build.py',Path('/tmp/oriole-expanded-name-frames-equal-owner-root-review/review.json')]: (O/p.name if p.name!='review.json' else O/'prior-b2-root-review.json').write_bytes(read(p))
for n in [lib,arena,'crates/oriole/tests/adapter_frame.rs','crates/oriole/tests/allocation.rs']:
 out=O/'source'/n;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(srcbytes['b5'][n])
for p,d in tracked.items():ck(sha(Path(p).read_bytes())==d,'final input unchanged '+p)
put('files.json',tracked);put('checks.json',checks);put('git-reads.json',gitreads);put('compiler-comparison.json',normalized);put('reconstructed-profiles.json',comparisons);put('reconstructed-static.json',static_rows)
review={'status':'independent_b5_source_build_static_instruction_chain_audit_passed','findings':[],'scope':'Read-only source and saved-data audit. No builds, target executions, profiling or elapsed reruns. B5 native audit is separate ffc53ef1; no adoption/full-gate inference.','source_manifest_sha256':summary['source_manifest_sha256'],'source_files_each_variant':70,'base':BASE,'full_patch_sha256':summary['full_patch_sha256'],'libraries':summary['libraries'],'chain':[
'B2 exact source1069 and patchd1ba match independent root review498b98. Full B2 semantics were reviewed there, including QName eligibility, selected bounds, expansion/attribute order and equal-owner lifetime; this audit independently checked the entire current patch and exact source lineage.',
'B3 introduces one inline(never) wrapper and substitutes the generic-true call with that wrapper. It delegates identical values/references and returns the same Result without added state, allocation, callback or drop operations. Removing it and restoring the one call reconstructs B2 bytes.',
'B4 only adds inline on AdapterFrame::push_attribute; B5 only strengthens that hint to inline(always). Inverse edits recover exact preceding70-file snapshots. All prior tests and semantic operations remain byte-exact.',
'B5 source remains based on50c20; selected Cell1a4cae is not composed. Its control is the original matched C-only ThinLTOa55, not Cell0cfd.'
],'build':'3 actual fresh workspace compiler commands reconstructed from verbose log, with final cdylib/staticlib lto=thin and dependency linker-plugin-lto. All complete vectors equal a55 after only worktree/private-intermediate paths. Same exact compiler/environment except distinct target.','profile':{'preflight_processes':32,'profile_processes':32,'annotation_processes':32,'parser_samples':samples,'real_conditions':12,'generated_conditions':4,'real_ratio':geo,'generated_ratio':gen,'real_lower':5,'generated_lower':0,'all_conditions_retained':True},'static_mechanism':'Read-only ELF text extraction and saved disassembly reconstruction confirm3 direct append callsites in common parser and wrapper, no push_attribute symbol; B3/B4 text bytes exact. Common stack remains2008bytes (+48/control); parse_start code remains1730bytes larger thancontrol.','package':{'members':len(members),'excluded_compiled_artifacts':2,'all_member_origin_hashes_verified':True},'limitations':[
'No broad compatibility gates were run on B3/B4/B5. B2 focused evidence remains inherited and separately scoped, not relabeled as final-gate execution.',
'B2 equal-owner retention may preserve spare capacity and a second cached owner; exact memory peaks/fail-at-N parity are not claimed.',
'Collector dladdr is process-local to the collector. Driver explicitly loads the selected library; no independent per-driver dladdr claim.',
'Profile observation normalization compares sorted hash/count/text-byte sets; saved data additionally shows both samples identical. It does not replace exact event-trace compatibility.',
'Legacy profile runner uses subprocess.run and only writes streams after completion: failed timeout cleanup/partial-output handling is weaker than current controllers. All saved successful32preflight/32profile outputs and annotation data are present; no failure is inferred or hidden by this audit.',
'Mnemonic/callsite/stack comparisons are static evidence, not dynamic frequency or causal wall attribution. All generated instruction regressions and7real instruction regressions retained.',
'Handoff scope predates later native timing; its no-elapsed language is stage-specific. Native full results and initial preparation-affinity failure are audited separately.'
],'checks':len(checks),'files':len(tracked),'generator_sha256':sha(Path(__file__).read_bytes())}
put('review.json',review);print(json.dumps({'review_sha256':sha((O/'review.json').read_bytes()),'checks':len(checks),'files':len(tracked),'profile_real':geo}))
