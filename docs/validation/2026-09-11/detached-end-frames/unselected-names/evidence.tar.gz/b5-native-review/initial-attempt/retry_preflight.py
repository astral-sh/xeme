from pathlib import Path
import json, subprocess, hashlib
p=Path(__file__).parent
cmd=['taskset','-c','3','python3',str(p/'native_screen.py'),'preflight']
with (p/'preflight-retry.log').open('wb') as log:
 run=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=600)
d=json.loads((p/'preparation.json').read_text());d.update(status='passed' if run.returncode==0 else 'failed',command=cmd,exit=run.returncode,retained_prior_attempt='preflight-affinity-attempt')
(p/'preparation-retry.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d),flush=True)
raise SystemExit(run.returncode)
