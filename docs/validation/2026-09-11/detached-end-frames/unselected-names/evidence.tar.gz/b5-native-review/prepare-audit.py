"""Adapt the frozen independent Cell saved-data checker; never execute project code."""
from pathlib import Path
import difflib
import hashlib
import json

OUT=Path(__file__).resolve().parent
BASE=Path('/tmp/oriole-ffi-family-cell-thinlto-native-independent-review/audit.py')
old=BASE.read_text()
assert hashlib.sha256(old.encode()).hexdigest()=='c83682c3f16cf568f2b2c8747d186bbd7a384d3e0ce33f78f195103494239ed1'
s=old.replace('/tmp/oriole-ffi-family-cell-thinlto-timing-study','/tmp/oriole-expanded-name-frames-attribute-always-thinlto-timing-study')
s=s.replace('sorted(os.sched_getaffinity(0))==[7]','sorted(os.sched_getaffinity(0))==[4]')
s=s.replace('0cfd610876f1bfd26a4d37a7f86adc9961896dfe24177c180ec7d15e0bae04e9','0065efd40c7164c2157bae77a478f148930c035de77a52ff246445c3e988c2aa')
s=s.replace("preparation=j(R/'preparation.json');controller=j(R/'timing-controller.json')\nck('preflight controller passed original CPU3',preparation['status']=='passed' and preparation['exit']==0 and preparation['command']==['taskset','-c','3','python3',str(R/'native_screen.py'),'preflight'])", """preparation=j(R/'preparation-retry.json');initial_preparation=j(R/'preparation.json');controller=j(R/'timing-controller.json')
ck('preflight retry passed original CPU3',preparation['status']=='passed' and preparation['exit']==0 and preparation['command']==['taskset','-c','3','python3',str(R/'native_screen.py'),'preflight'] and preparation['retained_prior_attempt']=='preflight-affinity-attempt')
ck('original wrapper CPU5 failed before preflight',initial_preparation['status']=='failed' and initial_preparation['exit']==1 and initial_preparation['command']==['taskset','-c','5','python3',str(R/'native_screen.py'),'preflight'])
ck('retry changes only command outcome and retained-attempt pointer',{k:v for k,v in preparation.items() if k not in ['status','command','exit','retained_prior_attempt']}=={k:v for k,v in initial_preparation.items() if k not in ['status','command','exit']})
initial_files={p.name:p for p in (R/'preflight-affinity-attempt').iterdir() if p.is_file()}
ck('retained initial attempt four files',set(initial_files)=={'oriole-prepare-expanded-name-frames-attribute-always-thinlto-timing.py','preflight-controller.log','preparation.json','scope.json'})
(O/'initial-attempt').mkdir(exist_ok=True)
for name,path in initial_files.items():
    raw=read(path);(O/'initial-attempt'/name).write_bytes(raw)
    if name!='scope.json':ck('initial attempt original copy '+name,raw==read(R/name))
failure_log=read(R/'preflight-controller.log').decode()
code=read(R/'native_screen.py').decode()
guard='    assert os.sched_getaffinity(0) == {3}'
ck('failure exactly at original preflight affinity guard',failure_log=='Traceback (most recent call last):\\n  File "'+str(R/'native_screen.py')+'", line 77, in <module>\\n'+guard+'\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\nAssertionError\\n' and code.splitlines()[76]==guard)
ck('failed guard before native-screen creation and parser worker dispatch',code.index(guard)<code.index('    output.mkdir(exist_ok=False)')<code.index("    save('protocol.json', protocol)")<code.index('pair = [run(condition, engine, -1, 3, 1)'))
retry_code=read(R/'retry_preflight.py').decode()
ck('retry retains600s timeout and restores CPU3 only',"cmd=['taskset','-c','3','python3',str(p/'native_screen.py'),'preflight']" in retry_code and 'timeout=600' in retry_code and "p/'preparation-retry.json'" in retry_code)
for name in ['preparation-retry.json','retry_preflight.py','preflight-retry.log']:(O/'initial-attempt'/name).write_bytes(read(R/name))
""")
s=s.replace('/tmp/oriole-time-ffi-family-cell-thinlto-native.py','/tmp/oriole-time-expanded-name-frames-attribute-always-thinlto-native.py')
s=s.replace('private FFI family counters in a C-only ThinLTO build','expanded element start frames with outlined lowering and restored attribute inlining in a C-only ThinLTO build')
s=s.replace('private FFI family Cell ThinLTO/0cfd6108 candidate','expanded element start frames ThinLTO/0065efd4 candidate')
s=s.replace("tofile='private-family-cell-thinlto-native'","tofile='expanded-element-frames-thinlto-native'")
s=s.replace("read(R/'oriole-prepare-ffi-family-cell-thinlto-timing.py')", "read(R/'oriole-prepare-expanded-name-frames-attribute-always-thinlto-timing.py')")
start=s.index("candidate_root=Path(")
end=s.index("manifest_path=Path(",start)
s=s[:start]+'''# Pin source/build receipts only: parent owns source/compiler/profile lineage review.
candidate_root=Path('/tmp/oriole-expanded-name-frames-attribute-always-thinlto-study')
candidate_source=j(candidate_root/'source.json');candidate_build=j(candidate_root/'report.json')
ck('candidate source identity linked to successful and failed preparation',h(candidate_root/'source.json')==preparation['source_manifest_sha256']==initial_preparation['source_manifest_sha256']==candidate_build['source_manifest_sha256']=='b6838fea9ea2398f62d22651365f40669f345fcbea62552113ce7a26613876c1' and len(candidate_source['source_sha256'])==70)
ck('saved build receipt is exact candidate identity',h(candidate_root/'report.json')=='0c5bdc68d7a27c61000d377e309fe5857b57ff18565d01f46b36e7afdd8a6c26' and candidate_build['libraries']['liboriole_expat.so']==expected_hashes['candidate'])
prior_review=Path('/tmp/oriole-ffi-family-cell-thinlto-native-independent-review/review.json')
ck('pinned prior Cell protocol independent review',h(prior_review)=='7a32289080e999735b88f873174b47ab72c9b375678459b875e04b82abd55566' and j(prior_review)['status']=='independent_saved_native_audit_passed')
prior_files=j(prior_review.parent/'checked-files.json')
cell_controller=Path('/tmp/oriole-ffi-family-cell-thinlto-timing-study/native_screen.py')
ck('prior Cell controller remains exactly reviewed',h(cell_controller)==prior_files[str(cell_controller)])
cell=read(cell_controller).decode()
cell_adapted=cell.replace('/tmp/oriole-ffi-family-cell-thinlto-timing-study',str(R)).replace('/tmp/oriole-ffi-family-cell-thinlto-study/liboriole_expat.so',protocol['libraries']['candidate']['path'])
cell_adapted=cell_adapted.replace('private FFI family counters in a C-only ThinLTO build','expanded element start frames with outlined lowering and restored attribute inlining in a C-only ThinLTO build').replace('private FFI family Cell ThinLTO/0cfd6108 candidate','expanded element start frames ThinLTO/0065efd4 candidate')
ck('B5 controller exact reviewed Cell protocol after paths/descriptive strings only',cell_adapted==code)
(O/'cell-controller-comparison.patch').write_text(''.join(difflib.unified_diff(cell.splitlines(True),code.splitlines(True),fromfile=str(cell_controller),tofile=str(R/'native_screen.py'))))
cell_timing=Path('/tmp/oriole-time-ffi-family-cell-thinlto-native.py')
ck('timing process-management controller exact reviewed Cell protocol',h(cell_timing)==prior_files[str(cell_timing)] and read(cell_timing).decode().replace('/tmp/oriole-ffi-family-cell-thinlto-timing-study',str(R))==read(timing_controller).decode())

'''+s[end:]
s=s.replace("ck('all4 regressions and21real3generated lower',len(regressions)==4 and groups['real']['ratios']['candidate_over_published']['below_one']==21 and groups['generated']['ratios']['candidate_over_published']['below_one']==3)","ck('all17 regressions and9real2generated lower',len(regressions)==17 and groups['real']['ratios']['candidate_over_published']['below_one']==9 and groups['generated']['ratios']['candidate_over_published']['below_one']==2)")
s=s.replace('==0.9910037981176822','==0.9851897853512278')
s=s.replace("preflight_log=json.loads(read(R/'preflight-controller.log'))","ck('reported generated point estimate',groups['generated']['ratios']['candidate_over_published']['geomean']==1.0048025896714623)\npreflight_log=json.loads(read(R/'preflight-retry.log'))")
s=s.replace("'audit_cpu':7","'audit_cpu':4")
s=s.replace('Completed build/instruction review left unchanged; full gates and actual-consumer studies are separate.','Source/build/profile lineage is parent-owned; only source/build receipt identity is pinned here. Full gates and actual-consumer studies are separate.')
start=s.index(" 'identities':{")
end=s.index(" 'groups':groups",start)
s=s[:start]+''' 'identities':{'libraries':protocol['libraries'],'candidate_source_manifest_sha256':h(candidate_root/'source.json'),'candidate_source_files':70,'candidate_build_report_sha256':h(candidate_root/'report.json'),'prior_Cell_native_review_sha256':h(prior_review),'comparison_baseline':'B5 namespace/start-frame candidate0065 versus ThinLTOa55 control and pinned Expat7a333. Source/build/profile lineage is parent-owned, not recertified by this arithmetic audit. Actual native controller is exact reviewed Cell protocol after paths/descriptive strings only.','driver':{'source_sha256':h(driver_source),'binary_sha256':h(driver),'original_build_record_sha256':h(origin_path),'original_build_command':origin['build_command'],'binding':'Per-process absolute library path, dlopen(RTLD_LOCAL|RTLD_NOW), dlsym on that handle; version output checked. No per-worker dladdr receipt was emitted.'}},
 'initial_attempt':{'status':'failed_before_native_screen_directory_and_parser_workers','original_preparation_sha256':h(R/'preparation.json'),'failure_log_sha256':h(R/'preflight-controller.log'),'original_wrapper_cpu':5,'required_preflight_cpu':3,'raw_exit':1,'failure':'AssertionError at frozen controller line77 affinity guard, before output.mkdir and worker dispatch. Input/library hashes are read before this guard.','retained_attempt_directory':'initial-attempt','successful_retry_preparation_sha256':h(R/'preparation-retry.json'),'successful_retry_cpu':3,'retry_exit':0,'native_controller_changed':False},
'''+s[end:]
s=s.replace('No PGO, parser reruns, sample filtering, removal or adoption decision in this audit.','No PGO, parser reruns, sample filtering, removal or adoption decision in this audit. Earlier B2/B3/B4 variants are outside this B5 elapsed reconstruction.')
s=s.replace('Python timings, strict CPython and full C/workspace gates are parent-owned and excluded. The two Oriole C-only builds use matched ThinLTO vectors; no equivalent compiler flags across Rust and C or adoption claim. The reviewer authored the new Cell tests, whose design is separately reviewed by root90d1.','Source/runtime/compiler/profile lineage, Python timings, strict CPython and full C/workspace gates are parent-owned and excluded. The two Oriole libraries are labeled ThinLTO by their producer receipts; this audit pins those artifact identities without independently repeating compiler-vector proof. No equivalent compiler flags across Rust and C or adoption claim.')
s=s.replace("len(sample['hash'])==16", "len(sample['hash'])==16 and all(ch in '0123456789abcdef' for ch in sample['hash'])")
(OUT/'audit.py').write_text(s)
(OUT/'adaptation.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile=str(BASE),tofile=str(OUT/'audit.py'))))
controller=(BASE.parent/'run-audit.py').read_text().replace("'7', PYTHON","'4', PYTHON")
(OUT/'run-audit.py').write_text(controller)
(OUT/'preparation.json').write_text(json.dumps({'scope':'Saved checker adaptation only; no target execution.','base_generator':str(BASE),'base_generator_sha256':hashlib.sha256(old.encode()).hexdigest(),'generator_sha256':hashlib.sha256(s.encode()).hexdigest(),'cpu':4},indent=2)+'\n')
