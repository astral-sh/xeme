"""Reconstruct fresh three-engine CPython samples without executing workers."""
from pathlib import Path
import os
assert os.sched_getaffinity(0)=={4}
from collections import Counter
import gzip
import hashlib
import json
import math
import random
import statistics

if not __debug__:
    raise RuntimeError('Audit assertions must run')
B = Path('/tmp/oriole-expanded-name-frames-attribute-always-thinlto-python-study')
S = B / 'screen'
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_bytes())
pre = load(S / 'preflight.json')
r = load(S / 'results.json')
build = load(B / 'consumers/build.json')
summary = load(B / 'summary.json')
source_review_path=Path('/tmp/oriole-expanded-name-frames-b5-chain-independent-review/review.json')
source_review=load(source_review_path)
assert sha(source_review_path)=='3d807531a6e8000997d641a1cc20bb91e0c59e77b0584d494bc1bf76124a60d1'
assert source_review['status']=='independent_b5_source_build_static_instruction_chain_audit_passed' and source_review['source_files_each_variant']==70
assert pre['status'] == 'preflight_passed' and r['status'] == 'passed'
assert pre['affinity'] == [5] and r['affinity'] == [0]
assert pre['kind'] == r['kind'] == 'python'
assert r['preflight_sha256'] == sha(S / 'preflight.json')
assert pre['conditions'] == r['conditions']
assert r['preflights'] == pre['preflights'] and r['expected'] == pre['expected']
assert len(pre['processes']) == len(pre['preflights']) == 72
assert len(r['processes']) == len(r['rows']) == 504
assert pre['pairs'] == r['pairs'] == 7
assert pre['seed'] == r['seed'] == 202609104412
assert pre['hashes_before'] == pre['hashes_after'] == r['hashes_before'] == r['hashes_after']
for record in [pre, r]:
    assert not record['hash_errors']
    assert all(sha(p) == h for p, h in record['hashes_before'].items())
assert sha(B / 'python_worker.py') == '4bc0ccffedb5048412b9cfc3638d28dcb30f711891c3784f3fbd3c0eb536ab68'
assert build['status'] == 'passed' and build['adaptations'] is None
assert build['cpython_revision'] == '3bb231a6a5dc02b95658877318bf61501a7209e9'
assert build['source_sha256_before'] == build['source_sha256_after']
assert all(sha(p) == h for p, h in build['source_sha256_before'].items())
engines = ['published', 'candidate', 'expat']
libraries = {'published': 'a55ca0f0fed68f8db0f2e8d3ea86c271c8491fe130b5074077aecace3ab4a4df',
             'candidate': '0065efd40c7164c2157bae77a478f148930c035de77a52ff246445c3e988c2aa',
             'expat': '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'}
assert set(build['consumers']) == set(engines)
normalized_commands = {}
for engine, consumer in build['consumers'].items():
    assert sha(consumer['library']) == libraries[engine]
    assert all(sha(p) == h for p, h in consumer['files'].items())
    assert len(consumer['commands']) == 2
    normalized = []
    for module, command in zip(['pyexpat', '_elementtree'], consumer['commands'], strict=True):
        args = command['command']
        assert command['returncode'] == 0 and args[:4] == ['cc', '-shared', '-fPIC', '-O2']
        assert sha(Path(consumer['directory']) / (module + '-build.log')) == command['log_sha256']
        assert args[-4] == consumer['library']
        normalized.append([x.replace(consumer['library'], '<PARSER-LIBRARY>').replace(consumer['directory'], '<CONSUMER-DIR>') for x in args])
    normalized_commands[engine] = normalized
assert all(v == normalized_commands['published'] for v in normalized_commands.values())

manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
iterations = {'vulkan': 3, 'wayland': 16, 'maven': 32, 'batik': 128, 'gtk': 64, 'docbook': 64}
conditions = []
for project in load(manifest)['projects']:
    entry = next(x for x in project['files'] if x['role'] == 'input')
    path = (manifest.parent / entry['path']).resolve()
    assert sha(path) == entry['sha256']
    for chunk in [4096, 65536]:
        for mode in ['elementtree', 'pyexpat-events']:
            conditions.append({'name': project['name'], 'chunk': chunk, 'mode': mode, 'input': str(path), 'iterations': iterations[project['name']]})
assert conditions == r['conditions'] and len(conditions) == 24
key = lambda c: f"{c['name']}/{c['chunk']}/{c['mode']}"
condition_map = {key(c): c for c in conditions}
index = {}
counts = Counter()
raw_hashes = {}
for phase, record, rowname in [('preflight', pre, 'preflights'), ('time', r, 'rows')]:
    processes = {p['label']: p for p in record['processes']}
    assert len(processes) == len(record['processes'])
    assert set(processes) == {row['process'] for row in record[rowname]}
    for row in record[rowname]:
        process = processes[row['process']]
        assert process['status'] == 'passed' and process['returncode'] == 0 and process['timeout_seconds'] == 300
        assert 'failure' not in process
        for stream in ['stdout', 'stderr']:
            path = S / process[stream]
            assert sha(path) == process[stream + '_sha256']
            raw_hashes[str(path)] = sha(path)
        assert not gzip.decompress((S / process['stderr']).read_bytes())
        raw = json.loads(gzip.decompress((S / process['stdout']).read_bytes()))
        assert raw['gc_enabled'] is True
        assert raw['samples'] == row['samples'] and raw['identity'] == row['identity']
        engine = row['engine']
        consumer = build['consumers'][engine]
        assert raw['identity']['parser_library']['sha256'] == libraries[engine]
        assert raw['identity']['expat_version'] == ('expat_2.8.4' if engine == 'expat' else 'oriole_compat_2.8.4')
        for name in ['pyexpat', '_elementtree', 'parser_library']:
            entry = raw['identity'][name]
            assert consumer['files'][entry['path']] == entry['sha256'] == sha(entry['path'])
        command = process['command']
        assert command[1:5] == ['-I', '-S', str(B / 'python_worker.py'), '--worker']
        specpath = Path(command[-1])
        spec = load(specpath)
        raw_hashes[str(specpath)] = sha(specpath)
        c = condition_map[row['key']]
        count = 0 if phase == 'preflight' else c['iterations']
        assert spec == {'input': c['input'], 'input_sha256': sha(c['input']), 'chunk': c['chunk'], 'mode': c['mode'], 'consumer': consumer['directory'], 'library_sha256': libraries[engine], 'iterations': count}
        assert len(raw['samples']) == count + 1
        for i, sample in enumerate(raw['samples']):
            assert sample['iteration'] == i and sample['warmup'] == (i == 0)
            assert sample['seconds'] == (sample['parse_ns'] + sample['destruction_ns']) / 1e9
            assert sample['seconds'] > 0 and math.isfinite(sample['seconds'])
            assert sample['parse_ns'] >= 0 and sample['destruction_ns'] >= 0
            assert [sample['output_sha256'], sample['output_rows']] == pre['expected'][row['key']]
            counts[phase + ('_warmups' if i == 0 else '_measured')] += 1
        median = statistics.median(s['seconds'] for s in raw['samples'][1:]) if count else None
        assert row['median_seconds'] == median
        if phase == 'time':
            identity = (row['key'], row['pair'], engine)
            assert identity not in index
            index[identity] = median
expected_preflights = [(key(c), engine) for c in conditions for engine in engines]
assert [(row['key'], row['engine']) for row in pre['preflights']] == expected_preflights
rng = random.Random(r['seed'])
jobs = [(condition, pair) for condition in conditions for pair in range(7)]
rng.shuffle(jobs)
order = []
for c, pair in jobs:
    shuffled = engines.copy()
    rng.shuffle(shuffled)
    order.extend((key(c), pair, engine, position) for position, engine in enumerate(shuffled))
assert order == [(row['key'], row['pair'], row['engine'], row['order']) for row in r['rows']]
ratio_pairs = [('candidate', 'published'), ('candidate', 'expat'), ('published', 'expat')]
summaries = []
for c in conditions:
    medians = {engine: [index[key(c), pair, engine] for pair in range(7)] for engine in engines}
    ratios = {a + '_over_' + b: [medians[a][pair] / medians[b][pair] for pair in range(7)] for a, b in ratio_pairs}
    summaries.append({'condition': c, 'process_pair_medians_seconds': medians, 'paired_ratios': ratios,
                      'median_ratios': {name: statistics.median(v) for name, v in ratios.items()}})
assert summaries == r['summary']
assert counts == {'preflight_warmups': 72, 'time_warmups': 504, 'time_measured': 25788}
groups = {}
for group in ['all', 'elementtree', 'pyexpat-events']:
    selected = [s for s in summaries if group == 'all' or s['condition']['mode'] == group]
    groups[group] = {}
    for a, b in ratio_pairs:
        name = a + '_over_' + b
        values = [s['median_ratios'][name] for s in selected]
        geo = math.exp(statistics.mean(math.log(v) for v in values))
        actual = {'geomean': geo, 'below_one': sum(v < 1 for v in values), 'conditions': len(values)}
        assert actual['below_one'] == summary['groups'][group]['ratios'][name]['below_one'] and actual['conditions'] == summary['groups'][group]['conditions']
        assert math.isclose(actual['geomean'], summary['groups'][group]['ratios'][name]['geomean'], rel_tol=1e-14)
        groups[group][name] = actual
project_groups = {}
for project in iterations:
    selected = [s for s in summaries if s['condition']['name'] == project]
    project_groups[project] = {a + '_over_' + b: math.exp(statistics.mean(math.log(s['median_ratios'][a + '_over_' + b]) for s in selected)) for a, b in ratio_pairs}
# Worker and extension build helper are byte-exact; method label plus prepare CPU3→5 are the only controller edits.
old_base=Path('/tmp/oriole-thinlto-production-python-study')
assert sha(B/'python_worker.py')==sha(old_base/'python_worker.py')
assert sha(B/'build_consumers.py')==sha(old_base/'build_consumers.py')
old=(old_base/'consumer_screen.py').read_text();new=(B/'consumer_screen.py').read_text()
import difflib
assert ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='reviewed-consumer-screen',tofile='expanded-namespace-frame-thinlto-screen'))==(B/'controller.patch').read_text()
oldlines=old.splitlines();newlines=new.splitlines();assert len(oldlines)==len(newlines)
delta=[(a,b) for a,b in zip(oldlines,newlines) if a!=b]
assert len(delta)==3
assert delta[0][0].replace('{3}','{5}')==delta[0][1] and delta[1][0].replace('CPU3','CPU5')==delta[1][1]
assert all(x.strip().startswith('"method":') for x in delta[2])
preparation=load(B/'preparation.json');assert preparation['status']=='passed' and [x['exit']for x in preparation['jobs']]==[0,0]
assert all(x['command'][:3]==['taskset','-c','5']for x in preparation['jobs'])
timed=load(B/'timing-controller.json');assert timed['status']=='passed' and timed['exit']==0 and timed['command'][:3]==['taskset','-c','0']
regressions=[{'condition':x['condition'],'ratio':x['median_ratios']['candidate_over_published']}for x in summaries if x['median_ratios']['candidate_over_published']>1]
assert regressions==summary['regressions']
raw_manifest=OUT/'audited-raw-files.json';raw_manifest.write_text(json.dumps(raw_hashes,indent=2)+'\n')
paths=[Path(__file__),B/'consumer_screen.py',B/'python_worker.py',B/'build_consumers.py',B/'consumers/build.json',B/'preparation.json',B/'summary.json',S/'preflight.json',S/'results.json',raw_manifest,source_review_path,B/'controller.patch',B/'timing-controller.json',B/'oriole-prepare-expanded-name-frames-attribute-always-thinlto-python.py',B/'build.log',B/'preflight.log',B/'timing-controller.log']
result={'status':'passed_no_findings','scope':'Independent saved-data audit only; no parser/build/test or timing execution.','preflights':72,'timed_workers':504,'cohorts':168,'conditions':24,'sample_counts':dict(counts),'raw_files_verified':len(raw_hashes),'paired_ratios_verified':504,'condition_ratio_medians':72,'regressions':regressions,'libraries':libraries,'groups':groups,'per_project_geomeans':project_groups,'retained_wording_note':'The method label identifies two C-only ThinLTO Oriole libraries and the normal Expat reference; exact compiler context is independently reviewed. B5 source is based on50c20 and is not composed with Cell counters. No B5 full CPython suite was run.', 'controller_changes':'Method identity prose plus prepare-affinity guard3 to5 relative to prior ThinLTO controller; worker and build helper byte exact. Python preparation used CPU5 successfully on both jobs; unlike the separate native study, no failed Python preparation attempt is recorded.','conclusion':f"All recorded inputs, loaded artifacts, canonical outputs, worker medians, seeded orders and ratios reproduce. B5 expanded-name-frame ThinLTO candidate is lower in{groups['all']['candidate_over_published']['below_one']}/24 conditions versus ThinLTO a55 and{groups['all']['candidate_over_expat']['below_one']}/24 versus Expat. Every condition remains included; this is the source-reviewed B2 namespace extension plus B3 wrapper/B4 ordinary hint/B5 forced hint under matched ThinLTO, with pinned Expat retaining normal compiler flags.",'limitations':['Automatic GC stays enabled; explicit gc.collect/input/import/canonicalization are outside timing. Parser creation/feed/finalization and explicit destruction are timed separately and added.','Canonicalized outputs join adjacent pyexpat text; timing gates do not establish exact Expat callback grouping. Strict CPython failures remain separate.','Only the six original XML inputs in unmodified CPython3.12.13 ElementTree and pyexpat; no full-project, external-DTD, Wayland-scanner or PGO claim.','Shared-host frequency/cache/background load uncontrolled. CPU0 sequencing receipts do not prove absence of unrelated host activity.','Both Oriole builds use effective C-only ThinLTO with matched compiler vectors, except the B5 source delta and private paths; independently reviewed. Pinned Expat retains its normal compiler flags, not an identically optimized LTO reference; no identical Rust/C compiler claim.'],'semantic_scope':'Canonical benchmark outputs match, but no B3/B4/B5 broad API or unchanged strict CPython802 suite was run. The inherited controller limitation says candidate/published retain two CPython failures; treat that as a historical expectation, not fresh B5 strict-suite evidence. Native and instruction studies retain non-namespace/generated regressions; no adoption verdict inferred from correctness preflights alone.','evidence_sha256':{str(p):sha(p)for p in paths}}
(OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n');print(sha(OUT/'review.json'));print(json.dumps({'groups':groups,'sample_counts':dict(counts)}))
