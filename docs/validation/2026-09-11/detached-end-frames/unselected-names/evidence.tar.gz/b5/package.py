from pathlib import Path
import gzip,hashlib,json,math,os,shutil,subprocess,tarfile
assert __debug__ and os.sched_getaffinity(0)=={2}
roots={'source':Path('/tmp/oriole-expanded-name-frames-attribute-always-study'),'thinlto':Path('/tmp/oriole-expanded-name-frames-attribute-always-thinlto-study'),'codegen':Path('/tmp/oriole-expanded-name-frames-attribute-always-codegen-review')}
o=Path('/tmp/oriole-expanded-name-frames-attribute-always-handoff');o.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
s=read(roots['source']/'source.json');b=read(roots['thinlto']/'report.json');c=read(roots['codegen']/'review.json');p=read(roots['thinlto']/'profile/report.json');a=read(roots['thinlto']/'profile-attribution.json');w=Path(s['worktree'])
assert len(s['source_sha256'])==70 and all(sha(w/n)==h for n,h in s['source_sha256'].items())
assert sha(roots['source']/'source.json')=='b6838fea9ea2398f62d22651365f40669f345fcbea62552113ce7a26613876c1'
assert subprocess.check_output(['git','diff','--binary'],cwd=w)==(roots['source']/'candidate.patch').read_bytes()
assert b['status']=='passed' and b['fresh_workspace_compiles']==3 and b['source_unchanged'] and b['original_unchanged']
assert b['compiler_comparison']['matched_after_private_paths_only']
assert all(sha(path)==h for path,h in b['original_hashes'].items()) and all(sha(roots['thinlto']/n)==h for n,h in b['libraries'].items())
assert c['status']=='identity_attribute_direct_appends_restored' and c['criterion_met']
assert p['status']=='passed' and len(p['rows'])==32 and len(p['comparisons'])==16
assert len(read(roots['thinlto']/'profile/preflights.json'))==32 and a['status']=='paired_saved_attribution_reconstructed'
assert all(sha(path)==h for path,h in p['hashes_after'].items()) and all(sha(path)==h for path,h in a['hashes'].items())
assert p['hashes_after']==read(roots['thinlto']/'profile/protocol.json')['hashes_before']
real=[r for r in p['comparisons'] if r['kind']=='project'];gen=[r for r in p['comparisons'] if r['kind']=='generated'];assert len(real)==12 and len(gen)==4
summary={'status':'static_mechanism_restored_instruction_screen_complete','source_manifest_sha256':sha(roots['source']/'source.json'),'source_files':70,'source_unchanged':True,'b4_to_b5_patch_sha256':sha(roots['source']/'b4-to-b5.patch'),'full_patch_sha256':sha(roots['source']/'candidate.patch'),'libraries':b['libraries'],'fresh_matched_workspace_compiles':3,'source_review':'Parent explicitly authorized only the inline-to-inline(always) change after inspecting helper and no-effect ordinary hint; inverse edit reconstructs frozen B4, all69 other source files exact.','static_comparisons':c['comparisons'],'static_criterion_met':c['criterion_met'],'preflight_processes':32,'profile_processes':32,'all16_conditions_retained':True,'instruction_comparisons':p['comparisons'],'project_instruction_ratio_geomean':p['project_instruction_ratio_geomean'],'generated_instruction_ratio_geomean':a['generated_instruction_ratio_geomean'],'real_conditions_lower':sum(r['candidate_over_control']<1 for r in real),'generated_conditions_lower':sum(r['candidate_over_control']<1 for r in gen),'no_new_behavioral_tests_elapsed_or_full_gates':True,'no_commit_or_push':True,'failed_or_discarded_builds':0,'setup_failures':1,'setup_failure':'cargo worktree rejects defaults=no; retained receipt, retry using required worktree defaults succeeded before source preparation. Builds use defaults=no.','decision':'Preserve complete B5 evidence and await parent review before elapsed; no further annotations. Instruction savings do not establish elapsed improvement, especially given retained B2 negative elapsed.'}
(o/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copyfile(__file__,o/'package.py')
(o/'README.md').write_text('''# B5 forced attribute inlining: bounded instruction screen

B5 changes only B4's inline hint to inline(always). The fresh C-only ThinLTO build matches a55's compiler commands except worktree/private paths and compiles all three workspace libraries. Direct attribute append calls return in both the identity path and expanded-only wrapper; push_attribute symbol disappears. The common parser stack stays2,008 bytes,48 above a55 and unchanged B3/B4. Common parse_start remains larger than a55.

All32 preflights and32 XML_Parse-only instruction profiles match observations and verify library origins. All16 original conditions are retained. Real-project instruction geometric ratio is0.9872433517510297 (1.2757% fewer), led by MavenNS6.4184% and DocBookNS8.6338%. Five of12 real conditions improve; the other10 conditions besides those namespace wins range from0.2168% fewer to0.2992% more. All four generated controls use more instructions: rare-declarations0.04120%/0.02259%; entities22/14 additional instructions. Generated ratio1.0001594976204962. No elapsed performance conclusion or adoption claim.

No new behavioral tests or full gates were run for B3/B4/B5 annotations; inherited B2 focused behavior evidence remains separately sealed. All source and prior variants are preserved, including B2's negative elapsed results. One harmless worktree setup error is retained; build and profile runs succeeded without retries. No commits or pushes. Await parent review before elapsed; no further annotations.
''')
entries=[];excluded=[]
for label,r in roots.items():
 for path in sorted(r.rglob('*')):
  if not path.is_file():continue
  data=path.read_bytes();row={'path':label+'/'+str(path.relative_to(r)),'origin':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};(excluded if data.startswith((b'\x7fELF',b'!<arch>\n')) else entries).append(row)
archive=o/'evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w|') as t:
   for row in entries:
    info=tarfile.TarInfo(row['path']);info.size=row['bytes'];info.mode=0o444;info.mtime=0
    with Path(row['origin']).open('rb') as f:t.addfile(info,f)
with tarfile.open(archive) as t:
 assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}=={x['path']:x['sha256'] for x in entries}
(o/'archive-members.json').write_text(json.dumps(entries,indent=2)+'\n');(o/'excluded-binaries.json').write_text(json.dumps(excluded,indent=2)+'\n')
(o/'readback.json').write_text(json.dumps({'status':'all_members_verified','members':len(entries),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'excluded_binaries':len(excluded)},indent=2)+'\n')
(o/'manifest.json').write_text(json.dumps({'status':'sealed','study_files':entries+excluded,'files':[{'path':path.name,'sha256':sha(path),'bytes':path.stat().st_size} for path in sorted(o.iterdir()) if path.is_file()]},indent=2)+'\n')
for r in [*roots.values(),o]:
 for path in r.rglob('*'):
  if path.is_file():path.chmod(0o444)
 for path in sorted(r.rglob('*'),reverse=True):
  if path.is_dir():path.chmod(0o555)
 r.chmod(0o555)
print(json.dumps({'status':'sealed_b5_static_and_instruction_results','manifest_sha256':sha(o/'manifest.json'),'archive_sha256':sha(archive),'summary_sha256':sha(o/'summary.json'),'members':len(entries),'archive_bytes':archive.stat().st_size},indent=2))
