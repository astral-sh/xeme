from pathlib import Path
import hashlib,json,os,signal,subprocess,time
assert os.sched_getaffinity(0)=={3}
O=Path(__file__).parent;W=Path('/home/dev-user/code/oss/oriole-end-frame-cells');B=Path('/tmp/oriole-pr115-windows-portability-build')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((O/'source.json').read_text())['source_sha256'];build=json.loads((B/'report.json').read_text());assert build['status']=='passed' and build['libraries_identical_to_measured']
env_overrides=build['env_overrides'];env=os.environ|env_overrides
before={str(W/n):v for n,v in source.items()}|{str(B/n):v for n,v in build['libraries'].items()};assert all(sha(n)==v for n,v in before.items())
report={'status':'incomplete','cpu':3,'source_manifest_sha256':sha(O/'source.json'),'build_report_sha256':sha(B/'report.json'),'env_overrides':env_overrides,'commands':[],'before':before,'scope':'One existing End callback-budget test plus format check; no full Linux matrix or Windows execution locally. All fixtures/assertions unchanged.'}
def save():(O/'checks.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 for label,argv in [('focused',['cargo','+ohm','-Zohm-defaults=no','test','--release','--locked','-p','oriole_expat','--lib','tests::detached_end_charges_the_name_before_handlers_or_default_fallback','--','--exact']),('fmt',['cargo','+ohm','-Zohm-defaults=no','fmt','--all','--','--check'])]:
  row={'label':label,'command':argv,'cwd':str(W),'timeout':900,'start':time.time()};report['commands'].append(row);save();p=None
  with (O/(label+'.log')).open('wb') as f:
   try:
    p=subprocess.Popen(argv,cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['exit']=p.wait(timeout=900)
   except BaseException as e:
    row['exception']=repr(e)
    if p:
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     row['exit']=p.wait()
    raise
   finally: f.flush();row['end']=time.time();row['log_sha256']=sha(O/(label+'.log'));save()
  assert row['exit']==0
  if label=='focused':assert 'test result: ok. 1 passed; 0 failed;' in (O/'focused.log').read_text()
 report['status']='passed';report['focused_tests']=1
finally:
 report['after']={n:sha(n) for n in before};report['source_libraries_unchanged']=report['after']==before;save()
assert report['source_libraries_unchanged'];print(json.dumps({'status':report['status'],'focused_tests':report.get('focused_tests'),'source_libraries_unchanged':report['source_libraries_unchanged']}))
