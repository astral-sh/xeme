"""Package released suffix CPython records; no parser/compiler execution."""
from pathlib import Path
import argparse, csv, gzip, hashlib, io, json, os, subprocess, tarfile
cli=argparse.ArgumentParser(description=__doc__)
cli.add_argument('--released',action='store_true')
args=cli.parse_args()
assert args.released and os.sched_getaffinity(0)=={6}
W=Path('/home/dev-user/code/oss/oriole-suffix-element-names')
O=W/'docs/validation/2026-09-11/element-name-storage/cpython'
assert not O.exists()
R=Path('/tmp/oriole-suffix-element-names-python-study')
V=Path('/tmp/oriole-suffix-python-independent-review')
entries={};excluded=[];symlinks=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def add(path,name):
    path=Path(path);assert name not in entries
    if path.is_symlink():
        symlinks.append({'path':name,'target':os.readlink(path)});return
    content=path.read_bytes();record={'path':name,'original':str(path),'bytes':len(content),'sha256':sha(content)}
    if content.startswith((b'\x7fELF',b'!<arch>')) or path.suffix in ('.a','.profraw','.profdata','.pyc'):
        excluded.append(record)
    else:entries[name]=(record,content)
def tree(root,prefix):
    root=Path(root)
    for p in sorted(root.rglob('*')):
        if '__pycache__' not in p.parts and (p.is_file() or p.is_symlink()):add(p,prefix+'/'+str(p.relative_to(root)))
reports={}
for mode in ('normal','pgo'):
    assert json.loads((R/mode/'time-controller.json').read_text())['status']=='passed'
    report=json.loads((V/(mode+'-review.json')).read_text())
    assert report['status']=='passed_independent_raw_elapsed_reconstruction'
    assert report['counts']['all_workers']==576 and report['counts']['all_samples']==26364
    reports[mode]=report
    tree(R/mode,'study/'+mode)
    for name in (mode+'-review.json',mode+'-row-aliases.json',mode+'-preflight-review.json'):
        add(V/name,'review/elapsed/'+name)
for name in ('audit.py','preflight_bindings.py','audit.py.patch','preflight_bindings.py.patch','adaptation.json','combine.py','combined-review.json','conditions.csv'):
    add(V/name,'review/elapsed/'+name)
for label,path,commit in [('suffix','/tmp/oriole-suffix-element-names-pgo-study','a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9'),('selected','/tmp/oriole-arena-capacity-bound-pgo-study','de859c89577b2982d59b6923d682032f6a7c7800')]:
    b=Path(path)
    for name in ('source.json','pair-report.json'):
        add(b/name,'builds/'+label+'/'+name)
    source=json.loads((b/'source.json').read_text())['source_sha256'];assert len(source)==72
    for name,digest in source.items():
        content=subprocess.check_output(['git','-C',str(W),'show',commit+':'+name]);assert sha(content)==digest
        dest='builds/'+label+'/source/'+name
        entries[dest]=({'path':dest,'original':commit+':'+name,'bytes':len(content),'sha256':digest},content)
    if label=='selected':add(b/'pair-freeze.json','builds/'+label+'/pair-freeze.json')
for name in ('Modules/pyexpat.c','Modules/_elementtree.c','LICENSE'):
    add(Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13')/name,'upstream/cpython/'+name)
for name in ('LICENSE-APACHE','LICENSE-MIT'):add(W/name,'notices/oriole/'+name)
tree('/tmp/oriole-suffix-element-names-strict-cpython','strict/candidate')
add('/tmp/oriole-suffix-element-names-strict-cpython.py','strict/controller.py')
# Strict review and historical baseline paths are supplied from the completed independent review.
strict_inputs=json.loads(Path('/tmp/oriole-suffix-python-strict-package-inputs.json').read_text())
for name,path in strict_inputs.items():add(path,'strict/'+name)
add('/tmp/oriole-suffix-python-portable-replay.py','assembly/replay.py')
add('/tmp/oriole-suffix-python-portable-replay.patch','assembly/replay.py.patch')
add(__file__,'assembly/package.py')
O.mkdir()
index={'format':1,'files':[row for row,_ in entries.values()],'excluded_binaries':excluded,'excluded_symlinks':symlinks}
(O/'index.json').write_text(json.dumps(index,indent=2)+'\n')
with (O/'evidence.tar.gz').open('xb') as stream:
    with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|') as archive:
            for name,(_,content) in sorted(entries.items()):
                member=tarfile.TarInfo(name);member.size=len(content);member.mode=0o644
                archive.addfile(member,io.BytesIO(content))
with (O/'conditions.csv').open('x',newline='') as stream:
    writer=csv.writer(stream);writer.writerow(['build','project','chunk_bytes','consumer','candidate_over_control','candidate_over_expat','control_over_expat'])
    for mode,report in reports.items():
        for row in report['summary']:
            c,x=row['condition'],row['median_ratios'];writer.writerow([mode,c['name'],c['chunk'],c['mode'],x['candidate_over_control'],x['candidate_over_expat'],x['control_over_expat']])
report={'status':'assembled','candidate':'a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9','control':'de859c89577b2982d59b6923d682032f6a7c7800','modes':{mode:{'counts':r['counts'],'aggregates':r['aggregates'],'libraries':r['libraries']} for mode,r in reports.items()},'archive_files':len(entries),'excluded_binary_files':len(excluded),'evidence_sha256':sha((O/'evidence.tar.gz').read_bytes()),'index_sha256':sha((O/'index.json').read_bytes())}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(O/'replay.py').write_bytes(Path('/tmp/oriole-suffix-python-portable-replay.py').read_bytes())
print(json.dumps({'files':len(entries),'excluded':len(excluded),'archive_bytes':(O/'evidence.tar.gz').stat().st_size,'archive_sha256':report['evidence_sha256']}))
