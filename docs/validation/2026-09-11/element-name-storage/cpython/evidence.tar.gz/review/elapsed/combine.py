"""Join two completed independent CPython raw audits; saved data only."""
from pathlib import Path
import csv
import hashlib
import json
import os

assert os.sched_getaffinity(0) == {6}
ROOT = Path(__file__).resolve().parent
STUDY = Path('/tmp/oriole-suffix-element-names-python-study')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs, phases, rows = {}, {}, []
for mode in ['normal', 'pgo']:
    path = ROOT / (mode + '-review.json')
    report = json.loads(path.read_text())
    assert report['status'] == 'passed_independent_raw_elapsed_reconstruction' and report['mode'] == mode
    assert report['raw_rows_exactly_reconstructed'] == 576
    assert report['all_callback_canonical_outputs_and_module_dladdr_records_verified'] and report['pair_order_verified']
    assert report['counts'] == {'conditions': 24, 'cohorts': 168, 'engines': 3, 'preflight_workers': 72,
                                'timed_workers': 504, 'all_workers': 576,
                                'samples': {'preflight_warmups': 72, 'time_warmups': 504, 'time_measured': 25788},
                                'all_samples': 26364}
    assert report['evidence_sha256'][str(ROOT / 'audit.py')] == sha(ROOT / 'audit.py')
    for name, digest in report['evidence_sha256'].items():
        actual = Path(name) if Path(name).is_absolute() else STUDY / name
        assert sha(actual) == digest, name
        assert str(actual) not in inputs or inputs[str(actual)] == digest
        inputs[str(actual)] = digest
    aliases = ROOT / (mode + '-row-aliases.json')
    assert sha(aliases) == report['row_aliases_sha256']
    assert len(json.loads(aliases.read_text())) == 576
    inputs[str(path)] = sha(path)
    inputs[str(aliases)] = sha(aliases)
    phases[mode] = {'report_sha256': sha(path), 'aggregates': report['aggregates'], 'libraries': report['libraries']}
    assert len(report['summary']) == 24
    for row in report['summary']:
        c, ratios = row['condition'], row['median_ratios']
        rows.append([mode, c['name'], c['chunk'], c['mode'], c['iterations'],
                     ratios['candidate_over_control'], ratios['candidate_over_expat'], ratios['control_over_expat']])
csv_path = ROOT / 'conditions.csv'
with csv_path.open('x', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(['build', 'project', 'chunk', 'consumer', 'iterations', 'candidate_over_control', 'candidate_over_expat', 'control_over_expat'])
    writer.writerows(rows)
result = {'status': 'passed', 'scope': 'Join of independently reconstructed normal/PGO CPython raw audits; no target execution.',
          'phases': phases, 'conditions_csv_sha256': sha(csv_path),
          'totals': {'conditions': 48, 'cohorts': 336, 'preflight_workers': 144, 'timed_workers': 1008,
                     'all_workers': 1152, 'preflight_warmups': 144, 'timed_warmups': 1008,
                     'measured_samples': 51576, 'all_samples': 52728},
          'limitations': ['All adverse conditions retained; each mode has one original campaign.',
                         'Canonical project outputs coalesce adjacent text callbacks; strict compatibility is a separate gate.',
                         'Results measure original project XML files through unmodified CPython modules, not whole-project execution.'],
          'input_sha256': inputs, 'reader_sha256': sha(__file__)}
for path, digest in inputs.items():
    assert sha(path) == digest
out = ROOT / 'combined-review.json'
with out.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': 'passed', 'report_sha256': sha(out), 'csv_sha256': sha(csv_path),
                  'totals': result['totals'], 'phases': {k: v['aggregates'] for k, v in phases.items()}}, indent=2))
