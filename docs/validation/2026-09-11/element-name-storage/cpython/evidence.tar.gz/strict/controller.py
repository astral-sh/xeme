"""Run unchanged upstream CPython tests against both fresh candidate linkages."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

ROOT = Path('/tmp/oriole-suffix-element-names-strict-cpython')
WORK = Path('/home/dev-user/code/oss/oriole-suffix-element-names')
BUILD = Path('/tmp/oriole-suffix-element-names-pgo-study')
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.sched_getaffinity(0) == {3}
ROOT.mkdir(exist_ok=False)
pair = json.loads((BUILD / 'pair-report.json').read_text())
source = json.loads((BUILD / 'source.json').read_text())
assert pair['status'] == 'passed'
library_dir = Path(pair['pgo_manifest']['path']).parent / 'use'
pins = {str(WORK / n): digest for n, digest in source['source_sha256'].items()}
for p in [*list((WORK / 'tools/cpython').glob('*.py')), Path(PYTHON),
          BUILD / 'pair-report.json', BUILD / 'source.json', Path(__file__)]:
    pins[str(p)] = sha(p)
for extension in ('so', 'a'):
    p = library_dir / ('liboriole_expat.' + extension)
    assert sha(p) == pair['pgo_libraries']['use/' + p.name]
    pins[str(p)] = sha(p)
assert all(sha(p) == h for p, h in pins.items())
report = {'status': 'incomplete', 'pins': pins, 'commands': [],
          'scope': 'Strict upstream tests, with explicit pinned CPython allocation-failure cleanup backport. No text-fragmentation allowance; strict exits and all test output retained.'}
def save():
    (ROOT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

try:
    for linkage, extension in [('shared', 'so'), ('static', 'a')]:
        output = ROOT / linkage
        command = [PYTHON, '-I', '-S', str(WORK / 'tools/cpython/run.py'),
                   '--source', '/home/dev-user/.cache/oriole/upstream/cpython-3.12.13',
                   '--library', str(library_dir / ('liboriole_expat.' + extension)),
                   '--output', str(output), '--consumer-fix']
        if linkage == 'static':
            for name in ['gcc_s', 'util', 'rt', 'pthread', 'm', 'dl', 'c']:
                command += ['--native-library', name]
        row = {'linkage': linkage, 'argv': command, 'started': time.time(), 'timeout': 1000}
        report['commands'].append(row)
        save()
        with (ROOT / (linkage + '.stdout')).open('xb') as out, (ROOT / (linkage + '.stderr')).open('xb') as err:
            process = subprocess.Popen(command, cwd=WORK, stdout=out, stderr=err, start_new_session=True)
            try:
                row['exit'] = process.wait(timeout=row['timeout'])
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                row['exit'] = process.wait()
                row['timeout_reached'] = True
            except BaseException:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL)
                row['exit'] = process.wait()
                row['reaped'] = True
                save()
                raise
            row['reaped'] = process.poll() is not None
        row['completed'] = time.time()
        for suffix in ['stdout', 'stderr']:
            row[suffix + '_sha256'] = sha(ROOT / (linkage + '.' + suffix))
        save()
        assert row['exit'] in [0, 2] and not row.get('timeout_reached'), row
        summary = json.loads((output / 'summary.json').read_text())
        assert summary['tests_exit_code'] == summary['gate_exit_code'] == row['exit']
        assert summary['probe_exit_code'] == summary['origin_exit_code'] == 0
        assert summary['text_fragmentation'] is None
        assert summary['library_sha256'] == pins[str(library_dir / ('liboriole_expat.' + extension))]
        row['summary_sha256'] = sha(output / 'summary.json')
        print(linkage, row['exit'], flush=True)
    report['status'] = 'completed_strict_results'
finally:
    report['pins_unchanged'] = all(sha(p) == h for p, h in pins.items())
    save()
assert report['pins_unchanged']
