# Selected stack-name allocation diagnostic

Prepared only: no compiler or parser target has run. `plan.json` binds the selected `de859c` PGO library, all 72 source files, the header, C compiler/reader tools, original Maven input, and all generated fixture bytes. This measures calls through `XML_ParserCreate_MM`'s selected allocator; loader, file I/O and C stdio allocations are outside the counter. It makes no elapsed-time or RSS claim.

There are 12 fixed cases: original Maven with namespaces off/on; flat, empty and nested namespaced elements with namespaces off/on; NUL-separator raw/expanded identity; namespace triplets; and two long-name fixtures whose proposed combined capacities are 4095 and 4097 bytes. Generated cases split after one warmup unit, then process fixed repeats. The warmup boundary and all other feeds are pinned; there is no tuning sweep. Maven's expected 917 starts/ends and 23,956 text bytes come from saved selected native preflight observations.

The C tracker follows the existing native allocation gate's ownership and release-poisoning pattern. New fixed-storage phase counters and size histograms distinguish creation/setup, warmup, repeated parsing and destruction. The final record includes retained/peak selected bytes and blocks, zero live blocks after free, callback counts, nesting balance and a deterministic event hash. Per-call records retain parse status/error and callback progression. Every used XML API, including `XML_Parse`, records its actual `dladdr` origin, and the runner checks all origins against the exact copied selected library.

The runner has separate explicit phases. After source review, the root task can execute:

```console
taskset -c 4 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S run.py build
taskset -c 4 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S run.py run --case maven-pipe
```

Run each name in `plan.json` once. Existing receipts cannot be overwritten. Each parser process has a three-second alarm, four-second outer timeout, 1 GiB address-space limit, 8 MiB output limit and explicit static input/callback/depth/trace bounds. Any assertion, allocation failure, missing result, unbalanced callbacks, remaining block, wrong origin or changed pin fails the run. Runtime limits are bounds, not timing samples.

The hypothesis predicts fewer warmed allocations for differing namespace spellings. The NUL identity case must preserve current reuse. The 4097-byte combined case exposes the existing 4 KiB per-name retention cutoff; it may lose cache reuse despite having individually cacheable raw/expanded names. Compare the complete phase distributions and peaks before deciding whether a future candidate has removed meaningful work.
