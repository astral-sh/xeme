# Packed element-name decision

Keep selected runtime `de859c89577b2982d59b6923d682032f6a7c7800`. Candidate `1e6c707b9a29c1ddc4fd2379db67ded7c972e409` remains unselected; preserve it as the measured raw-first packing variant.

| Build | Real/control | Real/Expat | Adverse real/control | Generated/control |
| --- | ---: | ---: | ---: | ---: |
| Normal | 0.997127099 | 1.583809222 | 12/24 | 1.012595874 |
| PGO | 0.996171270 | 1.364374017 | 13/24 | 1.013922864 |

Both saved-data audits passed on their first attempts: 1,344 workers and 212,352 samples reconstructed across all 56 condition rows. Ratios above 1 mean slower. Small aggregate improvements of 0.29% normal and 0.38% PGO, with half or more project conditions adverse and generated controls slower overall, do not demonstrate a broad speed gain sufficient to select this variant.

The separate allocation diagnostic confirms useful savings: Maven namespace-enabled malloc/realloc requests decrease from 1,323 to 584; flat, empty and triplet cases remove all 127 post-warmup malloc calls. All twelve fixture pairs preserve callback hashes, feed progression and zero live allocations after parser destruction. Costs remain: Maven realloc calls increase from 26 to 204, the 2,044-byte-name fixture retains 1,884 more bytes, and the 2,045-byte-name fixture requests 30,675 more bytes. Each capacity fixture is compared only with its identical baseline input. The two fixture lengths straddle an input-buffer boundary, so their absolute peaks are not a stack-cache comparison.

The expanded-first suffix-sharing proposal is a separate refinement requiring its own source checks and measurements. CPython consumer and API/native sanitizer controllers for this raw-first candidate are prepared but unexecuted. No full-compatibility, CPython-speed or production-readiness claim follows from these results.
