"""Join completed phase audits and their condition CSVs; saved reads only."""
from pathlib import Path
import csv
import hashlib
import json
import os

assert os.sched_getaffinity(0) == {6}
root = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
phases = {}
all_rows = []
header = None
inputs = {}
for phase in ['normal', 'pgo']:
    path = root / f'{phase}-review.json'
    report = read(path)
    assert report['status'] == 'passed' and report['all_input_bytes_unchanged_after_read']
    assert set(report['native']) == {phase}
    assert report['generator_sha256'] == sha(root / 'audit.py')
    assert report['source_files_rehashed'] == 72
    for name, digest in report['input_sha256'].items():
        assert name not in inputs or inputs[name] == digest
        assert sha(name) == digest, name
        inputs[name] = digest
    csv_path = root / f'{phase}-conditions.csv'
    assert sha(csv_path) == report['condition_csv_sha256']
    with csv_path.open(newline='') as stream:
        rows = list(csv.reader(stream))
    if header is None:
        header = rows.pop(0)
    else:
        assert rows.pop(0) == header
    assert len(rows) == 28 and all(row[0] == phase for row in rows)
    all_rows.extend(rows)
    phases[phase] = {'report_path': str(path), 'report_sha256': sha(path),
                     'conditions_csv_sha256': sha(csv_path),
                     'groups': report['native'][phase]['groups']}
    inputs[str(path)] = sha(path)
    inputs[str(csv_path)] = sha(csv_path)

csv_path = root / 'conditions.csv'
with csv_path.open('x', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(header)
    writer.writerows(all_rows)
assert len(all_rows) == 56
result = {'status': 'passed', 'role': 'Saved-data join of two independently reconstructed phase audits. The reviewer adapted the arithmetic/build-binding readers but did not author producer controllers or collect elapsed outcomes. No target execution.',
          'phases': phases, 'conditions_csv_sha256': sha(csv_path),
          'totals': {'conditions': 56, 'preflight_workers': 168, 'timed_workers': 1176, 'all_workers': 1344, 'all_samples': 212352},
          'all_input_bytes_unchanged_after_read': True,
          'limitations': ['One original fixed campaign per mode; this does not infer a hardware mechanism or establish full compatibility.', 'The packed element-name candidate requires separate compatibility and consumer gates. All adverse conditions are retained; generated controls remain separate from project results.'],
          'reader_sha256': sha(__file__), 'input_sha256': inputs}
for name, digest in inputs.items():
    assert sha(name) == digest, name
with (root / 'review.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
lines = ['# Packed element-name native results', '',
         'PASS: both phase audits reconstructed all raw worker/sample records, callbacks, seeded order, medians and ratios. Source72 and every pinned input matched before and after reading. All56 condition rows are in `conditions.csv`; generated controls remain separate.', '',
         '| Build | Real/control | Real/Expat | Adverse real/control | Generated/control |',
         '| --- | ---: | ---: | ---: | ---: |']
for phase, report in phases.items():
    real, generated = report['groups']['real'], report['groups']['generated']
    adverse = sum(not c['name'].startswith('generated-') for c in report['groups']['adverse_conditions'])
    lines.append(f"| {phase} | {real['ratios']['candidate_over_control']:.9f} | {real['ratios']['candidate_over_expat']:.9f} | {adverse}/24 | {generated['ratios']['candidate_over_control']:.9f} |")
lines += ['', 'Ratios above1 mean slower. Values aggregate the per-condition medians of seven paired ratios by geometric mean; no single result is substituted for an individual condition. These measurements quantify the packed element-name candidate against the selected capacity parent; they do not decide its compatibility or consumer gates. No full compatibility, CPython timing, hardware mechanism or production-readiness claim is made here.', '',
          'The reviewer wrote the focused custom-name test and allocation diagnostic, adapted the arithmetic/build-binding readers and reviewed runtime/native producer source, but did not author the runtime or native elapsed controllers and did not collect elapsed runs. This is a separate raw-outcome reconstruction.', '']
(root / 'README.md').write_text('\n'.join(lines))
print(json.dumps({'status': 'passed', 'review_sha256': sha(root / 'review.json'), 'conditions_csv_sha256': sha(csv_path), 'phases': phases}))
