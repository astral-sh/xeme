# Suffix-sharing element-name native results

PASS: both phase audits reconstructed all raw worker/sample records, callbacks, seeded order, medians and ratios. Source72 and every pinned input matched before and after reading. All56 condition rows are in `conditions.csv`; generated controls remain separate.

| Build | Real/control | Real/Expat | Adverse real/control | Generated/control |
| --- | ---: | ---: | ---: | ---: |
| normal | 0.998181540 | 1.582061742 | 15/24 | 1.005000399 |
| pgo | 0.983587834 | 1.351632608 | 6/24 | 1.002673656 |

Ratios above1 mean slower. Values aggregate the per-condition medians of seven paired ratios by geometric mean; no single result is substituted for an individual condition. These measurements quantify the suffix-sharing element-name candidate against the selected capacity parent; they do not decide its compatibility or consumer gates. No full compatibility, CPython timing, hardware mechanism or production-readiness claim is made here.

The reviewer wrote the focused custom-name test and allocation diagnostic, adapted the arithmetic/build-binding readers and reviewed runtime/native producer source, but did not author the runtime or native elapsed controllers and did not collect elapsed runs. This is a separate raw-outcome reconstruction.
