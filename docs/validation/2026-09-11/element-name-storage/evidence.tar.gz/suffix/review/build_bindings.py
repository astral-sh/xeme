"""Read completed build evidence directly; no compiler or parser execution."""
from pathlib import Path
import hashlib
import json
import re
import shlex

ROOT = Path('/tmp/oriole-suffix-element-names-pgo-study')
CONTROL = Path('/tmp/oriole-arena-capacity-bound-pgo-study')
HEAD = 'a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9'


def vectors(log):
    result = {}
    for line in log.read_text().splitlines():
        stripped = line.strip()
        if not stripped.startswith('Running `') or '/rustc ' not in stripped:
            continue
        assert stripped.endswith('`')
        argv = shlex.split(stripped[len('Running `'):-1])
        crate = argv[argv.index('--crate-name') + 1]
        if crate in ['oriole', 'oriole_expat', 'oriole_storage']:
            assert crate not in result
            result[crate] = argv
    assert set(result) == {'oriole', 'oriole_expat', 'oriole_storage'}
    return result


def normalize(argv, run, private_build):
    result = []
    for arg in argv:
        arg = arg.replace(private_build, '<PRIVATE_BUILD>')
        if str(run) in arg:
            assert arg in ['-Cprofile-generate=' + str(run / 'raw-profiles'),
                           '-Cprofile-use=' + str(run / 'merged.profdata')]
            arg = arg.replace(str(run), '<FRESH_RUN>')
        arg = re.sub(r'(?<=extra-filename=-)[0-9a-f]{16}$', '<ARTIFACT>', arg)
        arg = re.sub(r'(lib\w+)-[0-9a-f]{16}(\.(?:rlib|rmeta))$', r'\1-<ARTIFACT>\2', arg)
        result.append(arg)
    return result


def verify(pair_sha256):
    """Reconstruct the two complete builds and return every read input pin."""
    pins = {}

    def pin(path):
        path = Path(path)
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert str(path) not in pins or pins[str(path)] == digest
        pins[str(path)] = digest
        return digest

    def read(path):
        pin(path)
        return json.loads(Path(path).read_text())

    assert re.fullmatch('[0-9a-f]{64}', pair_sha256)
    assert pin(ROOT / 'pair-report.json') == pair_sha256
    assert pin(ROOT / 'source.json') == 'cb7d4d2a2fb203beacc6e94db411f306c276b7607750a83ee3b17c1715c5e6b5'
    assert pin(ROOT / 'build_pair.py') == 'fcb0812c00c2a629389d427b603a90a5e130df366d9e3d17dd96df04c30fc8cd'
    engines = {}
    for label, root in [('control', CONTROL), ('candidate', ROOT)]:
        pair = read(root / 'pair-report.json')
        source_manifest = read(root / 'source.json')
        source = source_manifest['source_sha256']
        worktree = Path(source_manifest['worktree'])
        assert pair['status'] == 'passed' and pair['source_unchanged'] and pair['scripts_unchanged'] and pair['tools_unchanged']
        assert pair['host'] == 'x86_64-unknown-linux-gnu'
        assert pair['source_manifest_sha256'] == pin(root / 'source.json')
        assert pair['script_source_sha256'] == pin(root / 'tool-source.json')
        manifest_path = Path(pair['pgo_manifest']['path'])
        assert pin(manifest_path) == pair['pgo_manifest']['sha256']
        manifest = read(manifest_path)
        run = Path(manifest['run'])
        assert run == manifest_path.parent and root / 'pgo/runs' == run.parent
        assert manifest['status'] == 'passed' and manifest['compared_parses'] == 288
        assert manifest['cpu_affinity'] == [3] and manifest['host'] == pair['host']
        assert manifest['base_rustflags'] == [] and manifest['cargo_args'] == ['-Zohm-defaults=no']
        assert manifest['source'] == str(worktree)
        assert len(source) == source_manifest['source_count'] == 72 and len(manifest['source_sha256']) == 69
        assert all(source[name] == value for name, value in manifest['source_sha256'].items())
        assert all(pin(worktree / name) == value for name, value in source.items())
        assert set(source) - set(manifest['source_sha256']) == {'tests/c/adversarial.c', 'tests/c/allocations.c', 'tests/c/integration.c'}
        if label == 'control':
            assert source_manifest['candidate_base_commit'] == 'de859c89577b2982d59b6923d682032f6a7c7800'
        else:
            assert source_manifest['candidate_base_commit'] == HEAD
            assert source_manifest['base_runtime'] == 'de859c89577b2982d59b6923d682032f6a7c7800'
            checks = read(root / 'source-checks.json')
            assert checks['test_count'] == 438 and checks['test_groups'] == 34
            assert checks['status'] == 'passed' and checks['failed'] == checks['ignored'] == 0
            assert checks['source_manifest_sha256'] == pin(root / 'source.json')
            assert checks['check_report_sha256'] == pin(root / 'local-checks/final-checks.json')
            for row in checks['commands']:
                assert row['exit'] == 0 and row['reaped'] and row['source_unchanged']
                assert all(source[name] == value for name, value in row['source_sha256'].items())
                assert pin(root / 'local-checks' / row['label'] / 'output.log') == row['log_sha256']
        scripts = read(root / 'tool-source.json')
        assert len(scripts) == 6 and manifest['script_sha256'] == {Path(name).name: value for name, value in scripts.items()}
        assert all(pin(root / 'pipeline' / name) == value for name, value in scripts.items())
        assert pair['tools_before'] == pair['tools_after']
        for items in [pair['tools_before'], manifest['tools_sha256'], manifest['cargo_config_sha256']]:
            for path, value in items.items():
                assert pin(path) == value
        for command in pair['commands']:
            assert command['exit'] == 0 and command['cpu'] == 3 and command['end'] >= command['start']
            assert pin(root / (command['label'] + '.log')) == command['log_sha256']
            assert 'exception' not in command and command['cwd'] == str(worktree)
        for command in manifest['commands']:
            assert command['status'] == 'passed' and command['returncode'] == 0
            assert pin(run / command['log']) == command['log_sha256']
            assert command['cwd'] == str(worktree)
        all_vectors = {}
        for phase in ['normal', 'generate', 'use']:
            if phase == 'normal':
                logfile = root / 'normal-build.log'
                expected = pair['normal_vectors']
                build = next(row for row in pair['commands'] if row['label'] == 'normal-build')
                assert build['timeout'] == 900
            else:
                build = next(row for row in manifest['commands'] if row['label'] == 'build-' + phase)
                logfile = run / build['log']
                expected = pair['pgo_vectors'][phase]
                assert build['timeout_seconds'] == 900
                env = build['environment']
                assert env['CARGO_TARGET_DIR'] == str(root / 'pgo/targets' / phase)
                flags = '-Cprofile-generate=' + str(run / 'raw-profiles') if phase == 'generate' else '-Cprofile-use=' + str(run / 'merged.profdata') + '\x1f-Cllvm-args=-pgo-warn-missing-function'
                assert env['CARGO_ENCODED_RUSTFLAGS'] == flags and 'LLVM_PROFILE_FILE' not in env
            assert build['argv'][build['argv'].index('--target') + 1] == pair['host']
            assert build['argv'][build['argv'].index('--crate-type') + 1] == 'cdylib,staticlib'
            pin(logfile)
            actual = vectors(logfile)
            assert actual == {row['crate']: row['argv'] for row in expected}
            for crate, argv in actual.items():
                assert argv[argv.index('--target') + 1] == pair['host']
                codegen = [argv[i + 1] for i, token in enumerate(argv[:-1]) if token == '-C']
                assert 'opt-level=3' in codegen and 'codegen-units=1' in codegen
                types = [argv[i + 1] for i, token in enumerate(argv[:-1]) if token == '--crate-type']
                assert types == (['cdylib', 'staticlib'] if crate == 'oriole_expat' else ['lib'])
                assert ('lto=thin' if crate == 'oriole_expat' else 'linker-plugin-lto') in codegen
                profile_args = [token for token in argv if token.startswith('-Cprofile-')]
                assert profile_args == ([] if phase == 'normal' else ['-Cprofile-' + ('generate=' + str(run / 'raw-profiles') if phase == 'generate' else 'use=' + str(run / 'merged.profdata'))])
            all_vectors[phase] = actual
        private_roots = {match for phase in all_vectors.values() for argv in phase.values() for arg in argv
                         for match in re.findall(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}', arg)}
        assert len(private_roots) == 1
        for name, value in pair['normal_libraries'].items():
            assert pin(root / 'normal' / name) == value
            assert (root / 'normal' / name).read_bytes().startswith(b'\x7fELF' if name.endswith('.so') else b'!<arch>\n')
        assert pair['pgo_libraries'] == manifest['libraries_sha256']
        for name, value in manifest['libraries_sha256'].items():
            assert pin(run / name) == value
            assert (run / name).read_bytes().startswith(b'\x7fELF' if name.endswith('.so') else b'!<arch>\n')
        generated = {path.name: pin(path) for path in (run / 'inputs').iterdir() if path.is_file()}
        assert len(generated) == 13 and generated == manifest['inputs_sha256']
        training = {}
        for phase in ['normal', 'generate', 'use']:
            path = root / 'normal-training.json' if phase == 'normal' else run / (phase + '-training.json')
            data = read(path)
            if phase != 'normal':
                assert pin(path) == manifest['training_sha256'][phase]
            library = root / 'normal/liboriole_expat.so' if phase == 'normal' else run / phase / 'liboriole_expat.so'
            assert data['status'] == 'passed' and len(data['rows']) == 288
            assert data['xml_parse_origin'] == {'path': str(library), 'sha256': pin(library)}
            assert data['library_sha256'] == pin(library)
            assert data['script_sha256'] == scripts['tools/pgo/train.py']
            assert data['inputs_sha256'] == generated['manifest.json']
            assert data['profile_file_environment'] == (str(run / 'raw-profiles/oriole-%m-%p.profraw') if phase == 'generate' else None)
            assert all(row['status'] == 1 and row['error'] == 0 and row['callback_exceptions'] == [] for row in data['rows'])
            assert len({(row['fixture'], row['namespaces'], row['chunk'], row['handlers'], row['iteration']) for row in data['rows']}) == 288
            assert len({row['fixture'] for row in data['rows']}) == 12
            training[phase] = data['rows']
        profiles = manifest['profiles_sha256']
        raw_names = {path.name for path in (run / 'raw-profiles').iterdir() if path.is_file()}
        assert raw_names == set(profiles) - {'merged.profdata'} and len(raw_names) == 1
        for name, value in profiles.items():
            path = run / name if name == 'merged.profdata' else run / 'raw-profiles' / name
            assert pin(path) == value and path.stat().st_size > 0
        merge = next(row for row in manifest['commands'] if row['label'] == 'profile-merge')
        assert merge['argv'][-1] == str(run / 'raw-profiles' / next(iter(raw_names)))
        assert merge['argv'][merge['argv'].index('-o') + 1] == str(run / 'merged.profdata')
        profile_show = next(row for row in manifest['commands'] if row['label'] == 'profile-show')
        assert 'XML_Parse' in (run / profile_show['log']).read_text()
        engines[label] = {'pair': pair, 'manifest': manifest, 'run': run, 'source': source,
                          'scripts': scripts, 'vectors': all_vectors, 'private_root': private_roots.pop(),
                          'training': training, 'generated': generated}
    left, right = engines['control'], engines['candidate']
    assert set(left['source']) == set(right['source'])
    assert sorted(name for name in left['source'] if left['source'][name] != right['source'][name]) == ['crates/oriole/src/lib.rs', 'crates/oriole/tests/multibyte.rs']
    assert set(left['manifest']['source_sha256']) == set(right['manifest']['source_sha256'])
    assert sorted(name for name in left['manifest']['source_sha256'] if left['manifest']['source_sha256'][name] != right['manifest']['source_sha256'][name]) == ['crates/oriole/src/lib.rs', 'crates/oriole/tests/multibyte.rs']
    assert left['scripts'] == right['scripts']
    assert left['pair']['tools_before'] == right['pair']['tools_before']
    assert left['manifest']['tools_sha256'] == right['manifest']['tools_sha256']
    assert left['manifest']['cargo_config_sha256'] == right['manifest']['cargo_config_sha256']
    assert left['generated'] == right['generated']
    assert left['private_root'] != right['private_root'] and left['run'] != right['run']
    for phase in ['normal', 'generate', 'use']:
        for crate in ['oriole_storage', 'oriole', 'oriole_expat']:
            a, b = left['vectors'][phase][crate], right['vectors'][phase][crate]
            assert len(a) == len(b)
            assert normalize(a, left['run'], left['private_root']) == normalize(b, right['run'], right['private_root'])
    reference = left['training']['normal']
    assert all(rows == reference for engine in engines.values() for rows in engine['training'].values())
    assert set(right['manifest']['profiles_sha256'].values()).isdisjoint(left['manifest']['profiles_sha256'].values())
    for path, value in pins.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == value
    return {'inputs': pins, 'source': read(ROOT / 'source.json'), 'pair': right['pair'],
            'summary': {'full_source_files': 72, 'pipeline_source_files': 69,
                        'changed_vs_selected': ['crates/oriole/src/lib.rs', 'crates/oriole/tests/multibyte.rs'],
                        'raw_compiler_vectors': 9, 'candidate_generated_rows': 864,
                        'candidate_library_artifacts': 6, 'targets_executed': False}}
