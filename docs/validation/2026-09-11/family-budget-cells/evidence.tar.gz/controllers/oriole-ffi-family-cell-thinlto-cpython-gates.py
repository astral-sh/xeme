import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path('/home/dev-user/code/oss/oriole-ffi-family-cell')
out = Path('/tmp/oriole-ffi-family-cell-thinlto-cpython-gates')
out.mkdir(exist_ok=False)
python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
library = Path('/tmp/oriole-ffi-family-cell-thinlto-study/liboriole_expat.so')
archive = library.with_suffix('.a')
source = '/home/dev-user/.cache/oriole/upstream/cpython-3.12.13'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(library) == '0cfd610876f1bfd26a4d37a7f86adc9961896dfe24177c180ec7d15e0bae04e9'
assert digest(archive) == 'c86ad85e232afe4f7947053e522dbc8517cdca3694740994c3d1da64540f0610'
source_map = json.loads(Path('/tmp/oriole-ffi-family-cell-thinlto-study/source.json').read_text())['source_sha256']
assert all(digest(root / name) == value for name, value in source_map.items())
report = {'status': 'incomplete', 'libraries': {str(p): digest(p) for p in [library, archive]}, 'jobs': []}
try:
    for linkage, path in [('shared', library), ('static', archive)]:
        command = ['taskset', '-c', '5', python, '-I', '-S', str(root / 'tools/cpython/run.py'), '--source', source, '--library', str(path), '--output', str(out / linkage)]
        if linkage == 'static':
            command += [arg for name in ['gcc_s', 'util', 'rt', 'pthread', 'm', 'dl', 'c'] for arg in ['--native-library', name]]
        item = {'linkage': linkage, 'command': command, 'expected_exit': 2}
        report['jobs'].append(item)
        with (out / (linkage + '.log')).open('wb') as log:
            run = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
        item['exit'] = run.returncode
        item['log_sha256'] = digest(out / (linkage + '.log'))
        (out / 'controller.json').write_text(json.dumps(report, indent=2) + '\n')
        print(linkage, run.returncode, flush=True)
        assert run.returncode == 2
    assert all(digest(Path(p)) == value for p, value in report['libraries'].items())
    assert all(digest(root / name) == value for name, value in source_map.items())
    report['status'] = 'completed_with_original_failures_retained_pending_outcome_audit'
finally:
    (out / 'controller.json').write_text(json.dumps(report, indent=2) + '\n')
    shutil.copy2(__file__, out / Path(__file__).name)
