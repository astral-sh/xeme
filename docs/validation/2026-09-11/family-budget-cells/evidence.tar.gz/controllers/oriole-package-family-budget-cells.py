"""Preserve the selected Cell runtime's source, gates and elapsed studies."""
from pathlib import Path
import hashlib
import io
import json
import shutil
import statistics
import subprocess
import tarfile

REPO = Path('/home/dev-user/code/oss/oriole-family-budget-cells')
OUT = REPO / 'docs/validation/2026-09-11/family-budget-cells'
BENCH = REPO / 'benchmarks/results/2026-09-11/family-budget-cells'
SHA = lambda data: hashlib.sha256(data).hexdigest()
READ = lambda path: json.loads(Path(path).read_text())
DIRECTORIES = {
    'normal-build-profile': '/tmp/oriole-ffi-family-cell-study',
    'thinlto-build': '/tmp/oriole-ffi-family-cell-thinlto-study',
    'workspace': '/tmp/oriole-ffi-family-cell-workspace-gates',
    'gates': '/tmp/oriole-ffi-family-cell-thinlto-gates-handoff',
    'native': '/tmp/oriole-ffi-family-cell-thinlto-timing-study',
    'python': '/tmp/oriole-ffi-family-cell-thinlto-python-study',
    'cpython': '/tmp/oriole-ffi-family-cell-thinlto-cpython-gates',
    'reviews': '/tmp/oriole-ffi-family-cell-review-handoff',
    'design': '/tmp/oriole-ffi-family-cell-design-review',
    'exposure': '/tmp/oriole-ffi-family-cell-exposure-review',
    'source-review': '/tmp/oriole-ffi-family-cell-root-review',
}
CONTROLLERS = [
    '/tmp/oriole-package-family-budget-cells.py',
    '/tmp/oriole-summarize-cohorts.py',
    '/tmp/oriole-prepare-ffi-family-cell-thinlto-timing.py',
    '/tmp/oriole-time-ffi-family-cell-thinlto-native.py',
    '/tmp/oriole-prepare-ffi-family-cell-thinlto-python.py',
    '/tmp/oriole-time-ffi-family-cell-thinlto-python.py',
    '/tmp/oriole-ffi-family-cell-thinlto-cpython-gates.py',
    '/tmp/oriole-review-ffi-family-cell-root.py',
]
COPIES = {
    'build.json': '/tmp/oriole-ffi-family-cell-thinlto-study/report.json',
    'source.json': '/tmp/oriole-ffi-family-cell-thinlto-study/source.json',
    'workspace.json': '/tmp/oriole-ffi-family-cell-workspace-gates/summary.json',
    'gates.json': '/tmp/oriole-ffi-family-cell-thinlto-gates/summary.json',
    'native-summary.json': '/tmp/oriole-ffi-family-cell-thinlto-timing-study/summary.json',
    'python-summary.json': '/tmp/oriole-ffi-family-cell-thinlto-python-study/summary.json',
    'source-review.json': '/tmp/oriole-ffi-family-cell-root-review/review.json',
    'build-profile-review.json': '/tmp/oriole-ffi-family-cell-build-profile-independent-review/review.json',
    'gates-review.json': '/tmp/oriole-cell-thinlto-gates-independent-review/final-review.json',
    'native-review.json': '/tmp/oriole-ffi-family-cell-thinlto-native-independent-review/review.json',
    'python-review.json': '/tmp/oriole-ffi-family-cell-thinlto-python-independent-review/review.json',
    'cpython-review.json': '/tmp/oriole-ffi-family-cell-thinlto-cpython-independent-review/review.json',
}

assert READ(COPIES['build.json'])['status'] == 'passed'
gates = READ(COPIES['gates.json'])
assert gates['status'] == 'correctness_parity_gates_passed'
assert gates['api']['all4740rows_exact']
assert (gates['api']['passed'], gates['api']['failed']) == (4347, 393)
workspace = READ(COPIES['workspace.json'])
assert (workspace['all_target_binaries'], workspace['all_target_tests_passed'], workspace['doc_tests_passed']) == (33, 400, 1)
source = READ(COPIES['source.json'])
delta = [p for p, digest in source['source_sha256'].items() if SHA((REPO / p).read_bytes()) != digest]
assert delta == ['crates/oriole_expat/README.md'], delta
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD^'], cwd=REPO, text=True).strip()
assert parent == '89927e09a6a9f1576ee05e3cf757e2b4159d5d36'
patch = subprocess.check_output(['git', 'diff', 'HEAD^', 'HEAD', '--', 'crates/oriole_expat/src/lib.rs', 'crates/oriole_expat/src/tests.rs'], cwd=REPO)
assert SHA(patch) == '583eb85f93fa83350f3d3674097232eed894ff19ef6908b1657419f469457a67'
assembly = {'runtime_commit': head, 'parent_commit': parent, 'measured_source_sha256': SHA(Path(COPIES['source.json']).read_bytes()),
            'source_files': len(source['source_sha256']), 'documentation_only_delta': delta,
            'measured_patch_sha256': SHA(patch), 'measured_patch_exact': True,
            'assembled_source_sha256': {p: SHA((REPO / p).read_bytes()) for p in source['source_sha256']}}
for p in [*CONTROLLERS, *COPIES.values()]:
    assert Path(p).is_file(), p
paths = {}
for prefix, directory in DIRECTORIES.items():
    root = Path(directory)
    assert root.is_dir(), root
    for p in sorted(root.rglob('*')):
        if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:
            paths[prefix + '/' + str(p.relative_to(root))] = p
for p in CONTROLLERS:
    paths['controllers/' + Path(p).name] = Path(p)
OUT.mkdir(parents=True, exist_ok=False)
BENCH.mkdir(parents=True, exist_ok=False)
members, excluded = [], []
with tarfile.open(OUT / 'evidence.tar.gz', 'w:gz', compresslevel=9) as archive:
    for name, p in sorted(paths.items()):
        data = p.read_bytes()
        entry = {'path': name, 'source': str(p), 'bytes': len(data), 'sha256': SHA(data)}
        if data.startswith((b'\x7fELF', b'!<arch>\n')):
            excluded.append(entry)
            continue
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        archive.addfile(info, io.BytesIO(data))
        members.append(entry)
with tarfile.open(OUT / 'evidence.tar.gz', 'r:gz') as archive:
    actual = archive.getmembers()
    assert len(actual) == len(members)
    for member, entry in zip(actual, members):
        assert member.isfile() and member.name == entry['path'] and member.size == entry['bytes']
        assert SHA(archive.extractfile(member).read()) == entry['sha256'] == SHA(Path(entry['source']).read_bytes())
for entry in excluded:
    assert SHA(Path(entry['source']).read_bytes()) == entry['sha256']
(OUT / 'archive-members.json').write_text(json.dumps({'members': members, 'excluded_binaries': excluded}, indent=2) + '\n')
(OUT / 'assembly.json').write_text(json.dumps(assembly, indent=2) + '\n')
for name, p in COPIES.items():
    shutil.copy2(p, OUT / name)
summary = {
    'runtime_commit': head,
    'source_assembly': assembly,
    'libraries': gates['libraries'],
    'normal_build_libraries': READ('/tmp/oriole-ffi-family-cell-study/build.json')['libraries'],
    'workspace': workspace,
    'api': gates['api'],
    'cpython_each_linkage': {'tests': 802, 'failures': 2, 'reported_skips': 14, 'expected_failures': 3},
    'native': READ(OUT / 'native-summary.json'),
    'python': READ(OUT / 'python-summary.json'),
    'archive': {'sha256': SHA((OUT / 'evidence.tar.gz').read_bytes()), 'members': len(members),
                'direct_binary_exclusions': len(excluded), 'bytes': (OUT / 'evidence.tar.gz').stat().st_size,
                'raw_bytes': sum(m['bytes'] for m in members), 'member_and_origin_readback': True},
    'scope': 'Matched C-only ThinLTO a55 control and Cell 0cfd candidate, both without PGO. Normal99ec build has separate Rust gates and instruction profiles. New commit assembles the exact measured runtime/test patch above PR113 with only a C-interface README difference among the 70 measured files. CPython elapsed is effectively flat. No new full PBS distribution or sustained Rust sanitizer fuzz claim.',
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
n = READ('/tmp/oriole-ffi-family-cell-thinlto-timing-study/native-screen/results.json')
labels = {'vulkan': 'Vulkan registry', 'wayland': 'Wayland protocol', 'maven': 'Maven POM',
          'batik': 'Batik SVG', 'gtk': 'GTK UI', 'docbook': 'DocBook XSL'}
lines = []
for name, label in labels.items():
    row = next(r for r in n['summary'] if r['condition']['name'] == name and r['condition']['chunk'] == 4096 and not r['condition']['namespaces'])
    samples = [r for r in n['rows'] if r['condition'] == row['condition']]
    times = {e: statistics.median(next(p['median_seconds'] for p in r['processes'] if p['engine'] == e) for r in samples) * 1000 for e in ['candidate', 'expat']}
    lines.append(f"| {label} | {times['candidate']:.3f} ms | {times['expat']:.3f} ms | {row['median_ratios']['candidate_over_expat']:.2f}× |")
(OUT / 'table.md').write_text('\n'.join(lines) + '\n')
(OUT / 'native-wins.json').write_text(json.dumps([{'condition': r['condition'], 'ratio': r['median_ratios']['candidate_over_expat']} for r in n['summary'] if r['median_ratios']['candidate_over_expat'] < 1], indent=2) + '\n')
print(json.dumps({'runtime': head, 'archive': summary['archive'], 'table': lines}, indent=2))
