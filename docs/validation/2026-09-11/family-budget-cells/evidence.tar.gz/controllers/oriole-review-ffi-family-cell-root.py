from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

out = Path('/tmp/oriole-ffi-family-cell-root-review')
out.mkdir(exist_ok=False)
study = Path('/tmp/oriole-ffi-family-cell-study')
source = json.loads((study / 'source.json').read_text())
repo = Path(source['worktree'])
sha = lambda data: hashlib.sha256(data).hexdigest()
changed = []
with tarfile.open(study / 'source.tar.gz', 'r:gz') as archive:
    members = {m.name: m for m in archive.getmembers() if m.isfile()}
    assert len(members) == len(source['source_sha256']) == 70
    for name, digest in source['source_sha256'].items():
        assert sha((repo / name).read_bytes()) == digest
        assert sha(archive.extractfile(members[name]).read()) == digest
        base = subprocess.check_output(['git', 'show', source['base'] + ':' + name], cwd=repo)
        if sha(base) != digest:
            changed.append(name)
assert changed == ['crates/oriole_expat/src/lib.rs', 'crates/oriole_expat/src/tests.rs']
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=repo)
assert patch == (study / 'candidate.patch').read_bytes()
report = {
    'status': 'source_review_no_blocker',
    'scope': 'Independent root source review only; no new compiler, parser or performance run.',
    'base': source['base'], 'source_files': 70, 'changed_files': changed,
    'source_manifest_sha256': sha((study / 'source.json').read_bytes()),
    'patch_sha256': sha(patch),
    'source_archive_and_live_files_exact': True,
    'findings': [],
    'reasoning': [
        'Only the private FFI FamilyBudget counters change from AtomicUsize to Cell. The header and module already require serialization across a parser family. Core EntityBudget and allocation tracker atomics, Shared reference counts and lifetime tokens are unchanged.',
        'The charge helper reads, checked-adds, applies the same inclusive limit, then writes only on success. It performs no allocation, callback, destructor or user conversion between the read and write. Zero above the limit still fails; overflow and rejected charges leave the counter unchanged.',
        'All production charge callsites and their order are unchanged. A successful attempted charge remains consumed when later child construction, allocation or parsing fails. The one GetBuffer read changes only its access syntax.',
        'Shared requires T: Send + Sync for its unsafe Send/Sync implementations; Cell removes those traits for this private family owner. No unsafe trait implementation or new safe concurrent API is added. Parser-facing C exports retain their unsafe serialized-handle contract.',
        'Existing test fixtures preserve values, limits and observations while using get/set. New boundary cases check zero, exact limit, overflow and rejection stability. The lifecycle regression checks attempted-child charge retention after allocation failure, shared callback/input limits, fresh root reset and surviving old children retaining the old budget.',
    ],
    'limitations': ['Runtime behavior, allocator layout, full gates and performance remain separately measured; this source review does not establish a speedup.'],
}
(out / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
(out / 'review.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'status': report['status'], 'review_sha256': sha((out / 'review.json').read_bytes())}))
