import json
from pathlib import Path
import signal
import subprocess
import time
import os

out = Path('/tmp/oriole-ffi-family-cell-thinlto-python-study')
python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
command = ['taskset', '-c', '0', python, '-I', '-S', str(out / 'consumer_screen.py'), '--kind', 'python', '--phase', 'time', '--build', str(out / 'consumers/build.json'), '--input', '/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json', '--output', str(out / 'screen')]
report = {'status': 'incomplete', 'command': command, 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
start = time.monotonic()
with (out / 'timing-controller.log').open('wb') as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        report['exit'] = process.wait(timeout=1200)
    except subprocess.TimeoutExpired:
        report['timeout'] = True
        os.killpg(process.pid, signal.SIGKILL)
        report['exit'] = process.wait()
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        report['elapsed_seconds'] = time.monotonic() - start
        report['status'] = 'passed' if report.get('exit') == 0 else 'failed'
        (out / 'timing-controller.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
raise SystemExit(0 if report['status'] == 'passed' else 1)
