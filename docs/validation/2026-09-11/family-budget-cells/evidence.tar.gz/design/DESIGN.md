# Private FFI family counters under serialized access

## Decision and scope

Replacing only `FamilyBudget::{input_bytes, callback_bytes, children}` with
`Cell<usize>` is consistent with the existing C API contract. This is a source
design review, not an implementation, performance result, or runtime approval.
The reviewed runtime is the 70-file `50c20c1` / `9815` source snapshot.

The module, public header and C ABI guide require serialized access to an entire
parent/child parser family. They permit transferring a handle between threads
only with external synchronization. A nested call from an XML callback can use
a related parser on the same thread, but it occurs after the enclosing charge
has completed. Concurrent parent/child operations are outside that contract.

`FamilyBudget` is private, and the field holding `Shared<FamilyBudget>` is
private. Parser operations require unsafe opaque handles. `Shared<T>` already
requires `T: Send + Sync` for its unsafe Send/Sync implementations; `Cell` makes
this particular shared owner non-Send/non-Sync. Do not add an unsafe trait
implementation to recover those traits. The core safe Rust parser's separate
entity budget, allocation tracker, Shared reference count and AtomicPtr lifetime
tokens retain their current atomics and contracts.

## Minimal implementation

Use three cells and retain `Default` initialization. The complete helper is:

```rust
fn charge(counter: &Cell<usize>, amount: usize, limit: usize) -> bool {
    let Some(next) = counter.get().checked_add(amount).filter(|&next| next <= limit)
    else {
        return false;
    };
    counter.set(next);
    true
}
```

The read, integer arithmetic, comparison and write allocate nothing and invoke
no callback or user-defined conversion/destructor. Under serialization, the old
atomic compare-and-update operation observes this same value and has no
intervening writer. Both implementations therefore accept exactly when the
addition is representable and the result does not exceed the supplied limit;
both leave the counter unchanged on rejection.

Keep amount-zero behavior exact: zero can fail if the current value already
exceeds the supplied limit. There must be no unconditional zero-amount return.
Keep charge timing and failure effects at all call sites. An accepted charge is
not rolled back when later cloning, allocation, child construction or parsing
fails. This is especially visible for attempted child creation. Do not convert
the cumulative child counter into a live-child count.

## Inventory and callback boundaries

There are five production charge sites: ordinary event dispatch, detached Start
dispatch, detached Text dispatch, XML_Parse input acceptance, and external-child
creation. XML_GetBuffer has the sole production counter read. Creation and root
reset allocate fresh default families; a child clones the existing owner.

All three dispatch paths finish charging before cloning payload/base metadata,
allocating pointer arrays, dispatching Default fragments or calling the selected
handler. `fail_parse` only records scalar errors. XML_Parse charges before input
tracking, raw-context growth, decoding and event execution. Child creation charges
before interpreting context/encoding or constructing its core and owned storage.
No borrow of a counter survives one of those callbacks.

Unknown-encoding release callbacks in reset/destruction are outside the charge
helper. A successful root reset installs a fresh family; surviving old children
retain their old `Shared` owner. A failed reset keeps its previous family. Final
Shared destruction retains the atomic Release decrement/Acquire fence and
allocator ownership; the cell payload itself has no destructor callback.

Tests contain four loads and six stores of these counters. Convert only their
syntax to `.get()` / `.set()` and preserve fixture values and assertions.
Update the existing comment claiming the budget contains atomic counters to
state the actual serialization and no-callback invariant.

## Required focused checks before selection

- Helper boundaries: exact limit, overflow, zero at/below/above limit, and no
  modification on failure.
- Related parsers consume one shared input/callback/child budget; parsing a child
  during an external handler observes completed parent charges.
- Root reset creates a fresh budget while surviving children retain the old one;
  failed reset and failed child construction keep existing accounting behavior.
- Default/Start/Text callbacks that change handlers or stop/resume preserve
  charge counts and error publication, including framed and ordinary delivery.
- Re-run original selected-allocation counts and existing native lifecycle gates
  after the source is frozen. Check actual allocation size/layout rather than
  promising exact storage equality without compilation.
- Only proceed to wider timing after a fresh, matched instruction screen shows
  a useful reduction. This design does not predict a measured gain; the earlier
  rejected unique-owner atomic optimization remains separate negative evidence.

No new safe Rust concurrency guarantee, callback restriction, cap, waiver or
resource-policy change is part of this design.
