"""Freeze a bounded read-only private FFI counter design review."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path('/home/dev-user/code/oss/oriole-start-frame-integration')
OUT = Path(__file__).resolve().parent
paths = ['crates/oriole_expat/src/lib.rs', 'crates/oriole_expat/src/tests.rs',
         'crates/oriole_expat/README.md', 'include/expat.h',
         'crates/oriole_storage/src/shared.rs']
tracked = {}
for name in paths:
    data = (ROOT/name).read_bytes()
    dest = OUT/'source'/name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    tracked[name] = hashlib.sha256(data).hexdigest()
lib = (ROOT/paths[0]).read_text()
shared = (ROOT/paths[-1]).read_text()
assert len(re.findall(r'if !charge\(', lib)) == 5
assert lib.count('family.input_bytes.load(Ordering::Relaxed)') == 1
assert lib.count('Shared::try_new_in(FamilyBudget::default(), allocator)') == 2
assert 'unsafe impl<T: Send + Sync> Send for Shared<T>' in shared
assert 'unsafe impl<T: Send + Sync> Sync for Shared<T>' in shared
assert 'current.checked_add(amount).filter(|&next| next <= limit)' in lib
assert 'serialize access to each parser family' in lib
assert 'A parser may be transferred between threads with external synchronization.' in (ROOT/'include/expat.h').read_text()
snapshot = json.loads(Path('/tmp/oriole-start-frame-integration-study/source.json').read_text())['source_sha256']
assert all(snapshot[name] == value for name, value in tracked.items())
inventory = {name: [{'line': i, 'text': line.strip()} for i,line in enumerate((ROOT/name).read_text().splitlines(), 1) if any(s in line for s in ['FamilyBudget', 'family.input_bytes', 'family.callback_bytes', 'family.children'])] for name in paths[:2]}
(OUT/'inventory.json').write_text(json.dumps(inventory, indent=2)+'\n')
report = {
    'status': 'bounded_source_design_review_no_blocker',
    'scope': 'Read-only design and exact current source inventory; no implementation, compiler, parser, test or timing run.',
    'runtime_commit': '50c20c1e73eeaacabb9df90e413f502361fb45b3',
    'source_sha256': tracked,
    'production_charge_sites': 5,
    'production_counter_reads': 1,
    'proof': ['Private family object is only reachable through the unsafe serialized parser-family API.', 'Cell prevents safe concurrent access; existing Shared Send/Sync gates are retained.', 'Read/checked addition/limit filter/write interval has no allocation or callback.', 'Success, overflow, amount-zero rejection, attempted-child accounting and later failure retention stay exact.', 'Core/entity/allocation tracking/reference-count/lifetime atomics are untouched.'],
    'required_conditions': ['No added unsafe Send/Sync implementations.', 'No zero-amount shortcut.', 'No movement of charges relative to fallible payload work or callbacks.', 'Preserve reset and surviving-child owner selection.', 'Only test access syntax changes; original values and assertions retained.'],
    'findings': [],
    'limitations': ['Source proposal only; actual code/layout, compiled tests, correctness and performance require separate evidence.', 'Concurrent family operations remain outside the existing C contract. No safe Rust core concurrency changes are justified by this review.'],
    'design_sha256': hashlib.sha256((OUT/'DESIGN.md').read_bytes()).hexdigest(),
    'generator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(OUT/'review.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'path': str(OUT/'review.json'), 'sha256': hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest()}))
