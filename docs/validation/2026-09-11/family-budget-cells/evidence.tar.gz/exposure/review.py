"""Source-only exposure/concurrency review. No target imports or execution."""
from pathlib import Path
from collections import Counter
import hashlib,json,os,re

assert os.sched_getaffinity(0)=={7}
R=Path('/home/dev-user/code/oss/oriole-start-frame-integration')
O=Path(__file__).resolve().parent
tracked={};checks=[]
def read(p):
    p=Path(p);raw=p.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(p),value)==value,str(p)
    return raw
def h(p):read(p);return tracked[str(p)]
def ck(label,condition):assert condition,label;checks.append(label)
source_path=Path('/tmp/oriole-start-frame-integration-study/source.json')
source=json.loads(read(source_path))
ck('frozen source manifest e9ea',h(source_path)=='e9eaeb4c8ee18357adbe97c91870801b41fb4553dc7259eaecc2d1d98fc5c5e4')
ck('all70 frozen live source bytes',len(source['source_sha256'])==70 and all(h(R/name)==value for name,value in source['source_sha256'].items()))
ffi_path=R/'crates/oriole_expat/src/lib.rs';ffi=read(ffi_path).decode()
test_path=R/'crates/oriole_expat/src/tests.rs';tests=read(test_path).decode()
shared_path=R/'crates/oriole_storage/src/shared.rs';shared=read(shared_path).decode()
allocator_path=R/'crates/oriole_storage/src/allocator.rs';allocator=read(allocator_path).decode()
tracker_path=R/'crates/oriole_storage/src/tracking.rs';tracker=read(tracker_path).decode()
accounting_path=R/'crates/oriole/src/accounting.rs';accounting=read(accounting_path).decode()
docs=read(R/'crates/oriole_expat/README.md').decode();header=read(R/'include/expat.h').decode()
def matches(text,pattern):
    return [{'line':text.count('\n',0,m.start())+1,'text':m.group(0),'groups':list(m.groups())} for m in re.finditer(pattern,text)]
field_accesses=matches(ffi,r'family\s*\.\s*(input_bytes|callback_bytes|children)')
charge_sites=matches(ffi,r'charge\(\s*&family\.(input_bytes|callback_bytes|children)')
loads=matches(ffi,r'family\.(input_bytes|callback_bytes|children)\.load\(Ordering::Relaxed\)')
test_operations=matches(tests,r'family\s*\.\s*(input_bytes|callback_bytes|children)\s*\.\s*(store|load)\(')
ck('six production counter accesses',Counter(m['groups'][0] for m in field_accesses)=={'callback_bytes':3,'input_bytes':2,'children':1})
ck('five production charge sites',Counter(m['groups'][0] for m in charge_sites)=={'callback_bytes':3,'input_bytes':1,'children':1})
ck('sole production input load',len(loads)==1 and loads[0]['groups']==['input_bytes'])
ck('internal test six stores and four loads',Counter(tuple(m['groups']) for m in test_operations)=={('children','store'):1,('callback_bytes','store'):5,('callback_bytes','load'):4})
ck('private budget and helper',re.search(r'(?m)^struct FamilyBudget \{',ffi) is not None and re.search(r'(?m)^fn charge\(',ffi) is not None)
struct=ffi.split('pub struct XML_ParserStruct {',1)[1].split('\n}',1)[0]
ck('all opaque parser fields private',not re.search(r'(?m)^\s*pub(?:\(|\s)',struct) and 'family: Shared<FamilyBudget>' in struct)
safe_exports=re.findall(r'pub extern "C" fn (\w+)\(',ffi)
ck('only four safe exports are parser-independent',safe_exports==['XML_ExpatVersion','XML_ExpatVersionInfo','XML_GetFeatureList','XML_ErrorString'])
ck('no parser or budget unsafe Send Sync impl',re.findall(r'unsafe impl[^\n]*',ffi)==['unsafe impl Sync for XML_Feature {}'])
ck('macro exports require unsafe calls',all(s in ffi for s in ['pub unsafe extern "C" fn $name(parser: XML_Parser, handler: $ty)','pub unsafe extern "C" fn $name(parser: XML_Parser, first: $first_ty, second: $second_ty)','pub unsafe extern "C" fn $name(parser: XML_Parser) -> $ty']))
ck('serialization and synchronized transfer explicit','serialize access to each parser family' in ffi and 'Each parser and its external-entity family require serialized access' in docs and 'including parsing, resetting, and freeing parent and child handles.' in header and 'A parser may be transferred between threads with external synchronization.' in header)
ck('Shared Send Sync retains payload bounds','unsafe impl<T: Send + Sync> Send for Shared<T> {}' in shared and 'unsafe impl<T: Send + Sync> Sync for Shared<T> {}' in shared)
ck('Shared ownership retains atomic refcount','references: AtomicUsize' in shared and 'fetch_sub(1, Ordering::Release)' in shared and 'fence(Ordering::Acquire)' in shared)
ck('allocator callback guard contract','must be safe for concurrent calls' in allocator and 'must not reenter' in allocator and 'static CALLBACK_DEPTH: Cell<usize>' in allocator and 'CallbackGuard::enter()' in allocator)
ck('independent trackers remain atomic','live: AtomicUsize' in tracker and 'direct: AtomicU64' in tracker and 'expanded: AtomicUsize' in accounting)
ck('fresh budget construction and clone inventory',ffi.count('Shared::try_new_in(FamilyBudget::default(), allocator)?')==2 and ffi.count('(*parser).family = family;')==1 and ffi.count('family: Shared::clone(&(*parser).family)')==1)
charge=ffi.split('fn charge(',1)[1].split('\n}\n',1)[0]
ck('current charge primitive pure closure','current.checked_add(amount).filter(|&next| next <= limit)' in charge and 'fetch_update(Ordering::Relaxed, Ordering::Relaxed' in charge and not any(x in charge for x in ['allocator','callback','Box','Vec','panic!','assert!']))
ck('family lifetime detached from pointer tracking','lifetime: Shared<AtomicPtr<XML_ParserStruct>>' in ffi and 'parent_lifetime: Option<Shared<AtomicPtr<XML_ParserStruct>>>' in ffi)
ck('destroy marks busy and invalidates token before release',ffi.index('(*parser).destroying = true;',ffi.index('unsafe fn destroy('))<ffi.index('lifetime.store(ptr::null_mut(), Ordering::Release);',ffi.index('unsafe fn destroy('))<ffi.index('release_encoding(parser);',ffi.index('unsafe fn destroy(')))
ck('reset release precedes fresh family publication',ffi.index('release_encoding(parser);',ffi.index('pub unsafe extern "C" fn XML_ParserReset'))<ffi.index('(*parser).family = family;'))
for p in [R/'crates/oriole_expat/src/content_model.rs',R/'crates/oriole_expat/Cargo.toml',R/'crates/oriole_storage/src/lib.rs']:read(p)
ck('no exposed FamilyBudget references outside FFI main',all('FamilyBudget' not in read(R/name).decode() for name in source['source_sha256'] if name.endswith('.rs') and name!='crates/oriole_expat/src/lib.rs'))
ck('all reviewed source bytes unchanged at finish',all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==value for p,value in tracked.items()))
report={
 'status':'no_exposure_or_concurrency_blocker_for_private_family_cell_proposal',
 'scope':'Read-only design review of replacing only private FFI FamilyBudget input_bytes/callback_bytes/children AtomicUsize with Cell<usize>. No implementation, compilation, parser call or test execution. Parent owns charge/error-equivalence analysis. The rejected unique-owner atomic prototype is outside this proposal.',
 'cpu':7,'source_manifest_sha256':h(source_path),'source_files':70,'ffi_source_sha256':h(ffi_path),
 'exposure':{'private_budget_type':True,'private_parser_field':True,'public_handle':'XML_Parser = *mut XML_ParserStruct','all_parser_using_exports_unsafe':True,'safe_exports':safe_exports,'static_state':'Only immutable feature/version/error data is exposed by safe exports; no FamilyBudget static, getter, public constructor or public safe parser-owner API exists.','auto_traits':'Cell<usize> is Send but not Sync. Existing Shared<T> Send/Sync implementations require T: Send + Sync, so private Shared<FamilyBudget> would be neither. XML_ParserStruct already contains raw pointers and has no Send/Sync implementation. No unsafe trait additions are needed or acceptable.','ffi_transfer':'The header allows thread transfer with external synchronization and forbids overlapping related-parser operations. This contract remains necessary: busy flags and lifetime tokens are not locks, and the existing relaxed counters never authorized concurrent parser access.'},
 'mutation_inventory':{'production_counter_accesses':field_accesses,'production_charge_sites':charge_sites,'production_loads':loads,'test_seed_and_read_operations':test_operations,'fresh_default_constructions':[307,525],'reset_family_assignment':563,'child_shared_clone':2315,'other_operations':'No production direct store, decrement, public limit setter or getter for these private fields. Child creation attempts remain cumulative; destruction only drops ownership.'},
 'read_write_interval_proof':['The proposed charge must read Cell<usize>, evaluate only usize::checked_add and the plain comparison/filter, then set the Copy usize on success. These operations have no allocator, callback, user trait dispatch, destructor or fallible allocation. Preserve failure as no write.','Every amount and limit argument is evaluated before charge begins. Existing dispatch allocates callback-owned base/attribute/raw storage and invokes event handlers only after charge returns; detached start/text frame dispatch follows the same order.','XML_Parse charges raw input before tracker bookkeeping, setting busy, copying input, feeding the core or invoking any callback. XML_ExternalEntityParserCreate charges children before input/core/handle allocations. XML_GetBuffer only copies the counter before reserve/resize and has no delayed write.','Synchronous handlers may create, parse, stop or free another non-busy parser in the same family. They see the completed earlier charge and cannot interleave inside a charge. Same-parser parse/buffer/reset/resume reentry is rejected; recursive DefaultCurrent has its own guard.','Selected allocator calls may occur before or after a charge, never inside it. The existing thread-local allocator callback guard rejects parser API reentry before parser access; independent allocator/tracker operations remain atomic as before.'],
 'lifecycle_proof':['Create allocates a fresh default FamilyBudget before publishing a raw handle. A child obtains an owning Shared clone; clone retains the atomic refcount and performs no allocation. There are no user callbacks inside that ownership clone.','Parser Free leaves an active parser allocated. Destroy sets busy/destroying, clears its AtomicPtr lifetime token, takes the encoding release callback and calls it before dropping the parser. No FamilyBudget read/write transaction or field borrow crosses the callback.','Root reset rejects busy parsers and child handles, builds replacement storage and a fresh FamilyBudget before encoding release, then invalidates the old lifetime token and replaces the family owner. Existing children retain their old Shared budget; callback-time changes to that old family finish before the root installs the fresh family.','FamilyBudget has no custom destructor. Its Cell<usize> fields would have trivial destruction. Shared last-owner drop still performs atomic release/acquire and deallocates with the retained allocator. Release/free callbacks can operate on other permitted handles only after any earlier charge has completed.','Parent tokens and core merge logic still depend on serialized related-parser access. The proposal does not make concurrent parent destruction safe; it leaves AtomicPtr tokens, Shared refcount, AllocationTracker and core EntityBudget atomics intact.'],
 'required_scope_constraints':['Keep FamilyBudget private and add no unsafe Send/Sync implementation or thread-sharing wrapper.','Keep read/check/set adjacent and free of allocation, tracing hooks, callbacks, async suspension, user-defined operations or RAII objects with nontrivial Drop.','Retain Shared atomic ownership, AtomicPtr lifetime tokens, AllocationTracker and core EntityBudget atomics.','Adapt the six internal test stores to set and four loads to get with exact seed values/assertions unchanged; update the stale safety comment at FFI lib.rs:672 that currently says atomic counters.','Do not claim implementation correctness, test success, timing gains or a broader removal of atomics from this source-only review.'],
 'findings':[], 'passed_source_checks':len(checks),'checked_files':len(tracked),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(O/'checked-files.json').write_text(json.dumps(tracked,indent=2,sort_keys=True)+'\n')
report['checked_files_sha256']=hashlib.sha256((O/'checked-files.json').read_bytes()).hexdigest()
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'files':len(tracked),'review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest()}))
