# Private FFI family Cell: C-only ThinLTO gates

The frozen two-file Cell prototype (`source.json` 164201b8) uses the existing externally serialized C parser-family contract. The three private counters change; core entity accounting, allocation tracking and shared ownership atomics remain unchanged.

The shared/static candidate is `0cfd6108` / `c86ad85e`; the matched C-only ThinLTO control is `a55ca0f0` / `3f4f5125`. All original 4,740 API rows match exactly: 4,347 pass and393 fail, raw exit1, with3seconds per case,1GiB address space,768MiB RSS and240seconds total. No test name, assertion or ceiling changes.

Six native C runs cover three consumers under both linkages, with327 original selected-allocation scenarios per linkage. C ASan/UBSan is enabled; Rust release is uninstrumented and leak detection disabled. All runs exit0.

The strict3,318 traces,36,456 custom-alias comparisons,2,392 malformed controls,1,304 publication cases,38 End lifecycle cases and6 supplemental selected-allocation scenarios match the control. The publication evidence retains10,416 Default and864 external callback position differences from Expat. All38 lifecycle cases have retained Expat differences; their payload/position scope is separate from baseline equality. Custom-alias successful full traces are checked by the harness but only comparison summaries are retained; malformed, publication and lifecycle paired observations are archived.

Normal workspace checks and root-owned CPython/elapsed studies are separate evidence; this package makes no throughput claim or full CPython-success claim. Exact commands, origins, source/tool/library hashes, both paired raw outputs where retained and the API failure bodies remain in the evidence archive. No parser retry or failed launch occurred in these gate campaigns.
