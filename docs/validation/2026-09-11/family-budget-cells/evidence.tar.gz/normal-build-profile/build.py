"""Freeze, build and check the private FFI Cell prototype on CPU4."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import signal
import subprocess
import tarfile
import time

ROOT = Path('/home/dev-user/code/oss/oriole-ffi-family-cell')
OUT = Path(__file__).resolve().parent
TARGET = Path('/home/dev-user/.cache/oriole/ffi-family-cell-target')
assert os.sched_getaffinity(0) == {4}
base = json.loads((OUT/'base-source.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip() == base['base']
env_overrides = dict(json.loads(Path('/tmp/oriole-start-frame-integration-study/build.json').read_text())['env_overrides'])
env_overrides['CARGO_TARGET_DIR'] = str(TARGET)
env = os.environ | env_overrides
assert not {k:v for k,v in env.items() if k.startswith('CARGO_PROFILE_')}
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
report = {'status':'incomplete','env_overrides':env_overrides,'commands':[], 'note':'Private FFI family counters only; existing serialized-family contract. Matched normal9815 build context, no effective LTO/PGO change. Focused tests only; no original API/full suite/elapsed timing claim.'}
def save():
    (OUT/'build.json').write_text(json.dumps(report, indent=2)+'\n')
def run(name, command, timeout=1200):
    row = {'name':name,'command':command,'cwd':str(ROOT),'affinity':[4],'started':time.time(),'timeout_seconds':timeout}
    report['commands'].append(row)
    save()
    process = None
    with (OUT/(name+'.log')).open('wb') as log:
        try:
            process = subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            row['exit'] = process.wait(timeout=timeout)
            if row['exit']:
                try:
                    os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:
                    pass
                raise RuntimeError(name+' failed')
        except BaseException as error:
            row['exception'] = repr(error)
            if process is not None:
                try:
                    os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:
                    pass
                row['exit'] = process.wait()
            raise
        finally:
            log.flush()
            row['elapsed_seconds'] = time.time()-row['started']
            row['log_sha256'] = sha(OUT/(name+'.log'))
            save()
    print(name,row['exit'],flush=True)
    return (OUT/(name+'.log')).read_text()

cargo = ['cargo','+ohm','-Zohm-defaults=no']
try:
    run('fmt-write',cargo+['fmt','--all'])
    source = {name:sha(ROOT/name) for name in base['source_sha256']}
    changed = [name for name,digest in source.items() if digest != base['source_sha256'][name]]
    assert changed == ['crates/oriole_expat/src/lib.rs','crates/oriole_expat/src/tests.rs'], changed
    (OUT/'source.json').write_text(json.dumps({'worktree':str(ROOT),'base':base['base'],'source_sha256':source},indent=2)+'\n')
    (OUT/'candidate.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=ROOT))
    with tarfile.open(OUT/'source.tar.gz','w:gz') as archive:
        for name in source:
            archive.add(ROOT/name,arcname=name,recursive=False)
    with tarfile.open(OUT/'source.tar.gz') as archive:
        assert len(archive.getmembers()) == 70
        for member in archive.getmembers():
            assert member.isfile() and hashlib.sha256(archive.extractfile(member).read()).hexdigest() == source[member.name]
    report['source_manifest_sha256'] = sha(OUT/'source.json')
    report['rustc'] = run('rustc-version',['rustc','+ohm','-vV'],30)
    for name in source:
        os.utime(ROOT/name,None)
    run('release',cargo+['build','--release','--locked','-p','oriole_expat','-vv'])
    invocations = [line for line in (OUT/'release.log').read_text().splitlines() if 'Running' in line and '/rustc ' in line]
    for crate in ['oriole_storage','oriole','oriole_expat']:
        assert len([line for line in invocations if '--crate-name '+crate+' ' in line]) == 1
    (OUT/'compiler-invocations.json').write_text(json.dumps(invocations,indent=2)+'\n')
    report['libraries'] = {}
    for name in ['liboriole_expat.so','liboriole_expat.a']:
        shutil.copyfile(TARGET/'release'/name,OUT/name)
        report['libraries'][name] = sha(OUT/name)
    report['fresh_workspace_compiles'] = 3
    save()
    artifacts = run('focused-compile',cargo+['test','--locked','-p','oriole_expat','--lib','--test','memory','--no-run','--message-format=json'])
    binaries = {}
    for line in artifacts.splitlines():
        if line.startswith('{'):
            row = json.loads(line)
            if row.get('reason') == 'compiler-artifact' and row.get('executable'):
                binaries[row['target']['name']] = row['executable']
    assert set(binaries) == {'oriole_expat','memory'}, binaries
    tests = json.loads((OUT/'focused-tests.json').read_text())
    for index,test in enumerate(tests['lib']):
        output = run('focused-lib-'+str(index),[binaries['oriole_expat'],test,'--exact','--nocapture'],120)
        assert '1 passed; 0 failed' in output, test
    for index,test in enumerate(tests['memory']):
        output = run('focused-memory-'+str(index),[binaries['memory'],test,'--exact','--nocapture'],120)
        assert '1 passed; 0 failed' in output, test
    run('clippy',cargo+['clippy','--locked','-p','oriole_expat','--lib','--tests','--','-D','warnings'])
    run('fmt-check',cargo+['fmt','--all','--','--check'])
    report['focused_tests'] = tests
    report['status'] = 'passed'
finally:
    if 'source' in locals():
        report['source_unchanged'] = all(sha(ROOT/name) == digest for name,digest in source.items())
    save()
assert report['source_unchanged']
print(json.dumps({'status':report['status'],'libraries':report['libraries'],'focused_tests':report['focused_tests']}),flush=True)
