"""Compare saved normal compiler commands before the instruction experiment."""
from pathlib import Path
import hashlib
import json
import os
import re

assert __debug__ and os.sched_getaffinity(0) == {4}
root = Path(__file__).parent
control = Path('/tmp/oriole-start-frame-integration-study')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
builds = {name: read(path / 'build.json') for name, path in [('control', control), ('candidate', root)]}
assert all(b['status'] == 'passed' and b['source_unchanged'] for b in builds.values())
assert builds['control']['rustc'] == builds['candidate']['rustc']
assert {k: v for k, v in builds['control']['env_overrides'].items() if k != 'CARGO_TARGET_DIR'} == {
    k: v for k, v in builds['candidate']['env_overrides'].items() if k != 'CARGO_TARGET_DIR'}
invocations = {name: read(path / 'compiler-invocations.json') for name, path in [('control', control), ('candidate', root)]}
sources = {name: read(path / 'source.json') for name, path in [('control', control), ('candidate', root)]}
assert len(sources['candidate']['source_sha256']) == len(sources['control']['source_sha256']) == 70
assert set(sources['candidate']['source_sha256']) == set(sources['control']['source_sha256'])
changes = [p for p, h in sources['candidate']['source_sha256'].items() if h != sources['control']['source_sha256'][p]]
assert changes == ['crates/oriole_expat/src/lib.rs', 'crates/oriole_expat/src/tests.rs']
normalized = {}
for name, lines in invocations.items():
    normalized[name] = {}
    for crate in ['oriole_storage', 'oriole', 'oriole_expat']:
        selected = [line for line in lines if '--crate-name ' + crate + ' ' in line]
        assert len(selected) == 1
        line = selected[0].replace(sources[name]['worktree'], '<WORKTREE>')
        line, count = re.subn(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}', '<PRIVATE_BUILD>', line)
        assert count >= 3
        normalized[name][crate] = line
assert normalized['control'] == normalized['candidate'], normalized
files = [p / n for p in [root, control] for n in ['compiler-invocations.json', 'build.json', 'source.json', 'liboriole_expat.so', 'liboriole_expat.a']]
report = {'status': 'matched_after_private_paths_only', 'normalizations': ['worktree absolute path', 'private build directory hash'],
          'fresh_workspace_library_compiles': 3, 'same_rustc': True, 'same_normal_flags_and_metadata': True,
          'changed_source_files': changes, 'normalized_commands': normalized,
          'hashes': {str(p): sha(p) for p in files}, 'script_sha256': sha(Path(__file__))}
(root / 'compiler-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'sha256': sha(root / 'compiler-comparison.json')}))
