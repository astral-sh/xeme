"""Read actual per-target Cargo results and compare unchanged test inventory."""
from pathlib import Path
import re,json,hashlib
r=Path('/tmp/oriole-ffi-family-cell-workspace-gates');base=Path('/tmp/oriole-start-frame-integration-gates/workspace-checks/tests.log')
def parse(p):
 rows=[];target=None
 for line in Path(p).read_text().splitlines():
  if 'Running ' in line and '(' in line:
   path=line.rsplit('(',1)[1].rstrip(')');target=re.sub(r'-[0-9a-f]{16}$','',Path(path).name)
  elif 'Doc-tests ' in line:target='doc:'+line.split('Doc-tests ',1)[1].strip()
  m=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',line)
  if m:
   assert target is not None;rows.append({'target':target,'passed':int(m[1]),'failed':int(m[2]),'ignored':int(m[3])});target=None
 return rows
b=parse(base);a=parse(r/'workspace-checks/tests.log');d=parse(r/'workspace-checks/doc-tests.log');assert len(a)==len(b)==33 and sum(x['passed'] for x in a)==400 and all(x['failed']==0 for x in a+d)
changes=[{'baseline':x,'candidate':y} for x,y in zip(b,a,strict=True) if x!=y]
assert len(changes)==1 and changes[0]['candidate']['target']=='oriole_expat' and changes[0]['candidate']['passed']==changes[0]['baseline']['passed']+2
assert sum(x['passed'] for x in b)==398 and sum(x['passed'] for x in d)==1
assert changes[0]['baseline']['passed']==88 and changes[0]['candidate']['passed']==90
report={'baseline_log':str(base),'baseline_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'baseline_profile':'release --workspace --all-targets','candidate_profile':'release --workspace --all-targets; separate release --workspace --doc','all_target_rows':a,'doc_rows':d,'all_target_passed':sum(x['passed'] for x in a),'doc_passed':sum(x['passed'] for x in d),'same_per_target_counts_as_baseline':False,'changes':changes,'expected_added_tests':['oriole_expat::tests::family_charge_preserves_zero_overflow_and_limit_boundaries','oriole_expat::tests::family_budgets_survive_child_failure_and_root_reset']}
(r/'workspace-checks/counts.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'all_targets':report['all_target_passed'],'docs':report['doc_passed']}))
