"""Verify and seal complete normal workspace evidence; no parser reruns."""
from pathlib import Path
import hashlib,json,os,subprocess,tarfile
assert __debug__ and os.sched_getaffinity(0)=={2}
r=Path(__file__).parent;o=r/'workspace-checks';w=Path('/home/dev-user/code/oss/oriole-ffi-family-cell')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=read(o/'report.json');s=read(r/'source.json');counts=read(o/'counts.json')
assert b['status']=='passed' and b['unchanged'] and b['normal_profile'] and b['frozen_libraries_unchanged']
assert len(b['before'])==len(b['after'])==70 and b['before']==b['after']==s['source_sha256']
assert all(sha(w/p)==h for p,h in b['after'].items())
assert b['frozen_libraries_before']==b['frozen_libraries_after'] and all(sha(p)==h for p,h in b['frozen_libraries_after'].items())
assert all(c['exit']==0 and c['timeout_seconds']==900 and sha(o/(c['label']+'.log'))==c['log_sha256'] for c in b['commands'])
base=read('/tmp/oriole-start-frame-integration-gates/workspace-checks/report.json')
assert [c['command'] for c in b['commands']]==[c['command'] for c in base['commands']]
assert {k:v for k,v in b['env_overrides'].items() if k!='CARGO_TARGET_DIR'}=={k:v for k,v in base['env_overrides'].items() if k!='CARGO_TARGET_DIR'}
assert len(counts['all_target_rows'])==33 and counts['all_target_passed']==400 and counts['doc_passed']==1
assert all(c['failed']==0 for c in counts['all_target_rows']+counts['doc_rows'])
assert len(counts['changes'])==1 and counts['changes'][0]['candidate']['target']=='oriole_expat'
assert counts['changes'][0]['baseline']['passed']==88 and counts['changes'][0]['candidate']['passed']==90
for archive in [r/'source.tar.gz',o/'source.tar.gz']:
 with tarfile.open(archive) as t:
  assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==s['source_sha256']
assert subprocess.check_output(['git','diff','--binary'],cwd=w)==(r/'candidate.patch').read_bytes()==(o/'candidate.patch').read_bytes()
summary={'status':'passed_complete_normal_workspace','source_manifest_sha256':sha(r/'source.json'),'source_files':70,'source_unchanged':True,'all_target_binaries':33,'all_target_tests_passed':400,'doc_tests_passed':1,'only_inventory_change':'FFI unit tests88→90; two Cell budget guard regressions. All other original32 binary counts unchanged.','workspace_clippy_strict':'passed','fmt_check':'passed','same_original_commands':True,'same_original_normal_env_except_target':True,'timeout_seconds_per_command':900,'cpu':2,'stable_target':b['env_overrides']['CARGO_TARGET_DIR'],'frozen_normal_and_thinlto_artifacts_unchanged':True,'frozen_libraries':b['frozen_libraries_after'],'report_sha256':sha(o/'report.json'),'counts_sha256':sha(o/'counts.json'),'failed_or_discarded_runs':0,'scope':'Normal Cargo workspace only; C-only frozen-artifact gates owned separately. No source edit, B2 full gates, elapsed measurements, commit or push.'}
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(r/'README.md').write_text('''# Frozen Cell source: normal workspace checks

All400 tests across the original33 workspace test binaries passed, plus1 doc test. Release workspace Clippy with warnings denied and fmt-check passed. The only count change from the398-test baseline is FFI unit tests88→90 for the two Cell budget guards. All original commands and900-second bounds are unchanged; CPU2 uses the stable Cell target and explicit normal environment. All70 source files and the saved normal99ec/ThinLTO0cfd shared and static libraries remain byte-identical. No source changes, elapsed measurements, B2 full gates, commits or pushes occurred. C-only frozen-artifact gates run independently under the conditional owner.
''')
rows=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(r.rglob('*')) if p.is_file()]
(r/'manifest.json').write_text(json.dumps({'status':'sealed','files':rows,'source_and_frozen_libraries_verified':True,'no_parser_reruns_during_seal':True},indent=2)+'\n')
assert all(sha(r/x['path'])==x['sha256'] for x in rows)
for p in r.rglob('*'):
 if p.is_file():p.chmod(0o444)
for p in sorted(r.rglob('*'),reverse=True):
 if p.is_dir():p.chmod(0o555)
r.chmod(0o555)
print(json.dumps({'status':'sealed','files':len(rows),'manifest_sha256':sha(r/'manifest.json'),'summary_sha256':sha(r/'summary.json'),'workspace_report_sha256':sha(o/'report.json'),'counts_sha256':sha(o/'counts.json')},indent=2))
