"""Final source snapshot and workspace checks, CPU2 only."""
if not __debug__:raise RuntimeError('Assertions required')
import hashlib,json,os,signal,subprocess,tarfile,time
from pathlib import Path
W=Path('/home/dev-user/code/oss/oriole-ffi-family-cell');R=Path('/tmp/oriole-ffi-family-cell-workspace-gates');O=R/'workspace-checks';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.sched_getaffinity(0)=={2}
prior=json.loads((R/'build.json').read_text());env=prior['env_overrides'];paths=json.loads((R/'source.json').read_text())['source_sha256']
assert sha(R/'source.json')=='164201b810c2a121e20f50c4a890fa3e1a8fa48e69e40e44069fc42059d4dfc6'
assert len(paths)==70 and all(sha(W/p)==h for p,h in paths.items())
assert not {k:v for k,v in os.environ.items() if k.startswith('CARGO_PROFILE_')}
frozen={}
for label,directory in [('normal','/tmp/oriole-ffi-family-cell-study'),('thinlto','/tmp/oriole-ffi-family-cell-thinlto-study')]:
 directory=Path(directory);build=json.loads((directory/'build.json').read_text());assert build['status']=='passed'
 for name,h in build['libraries'].items():
  assert sha(directory/name)==h;frozen[str(directory/name)]=h
frozen.update({str(R/n):sha(R/n) for n in ['source.json','build.json']})

source=lambda:{p:sha(W/p) for p in paths}
report={'status':'incomplete','env_overrides':env,'before':source(),'frozen_libraries_before':frozen,'normal_profile':True,'affinity':[2],'timeout_seconds_per_command':900,'commands':[]};save=lambda:(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(O/'source.json').write_text(json.dumps({'worktree':str(W),'source_sha256':source()},indent=2)+'\n')
with tarfile.open(O/'source.tar.gz','w:gz') as t:
 for p in paths:t.add(W/p,arcname=p,recursive=False)
with (O/'candidate.patch').open('wb') as f:subprocess.run(['git','diff','--binary'],cwd=W,stdout=f,check=True)
save()
try:
 for label,args in [('tests',['test','--release','--locked','--workspace','--all-targets','--no-fail-fast']),('doc-tests',['test','--release','--locked','--workspace','--doc']),('clippy',['clippy','--release','--locked','--workspace','--all-targets','--','-D','warnings']),('fmt',['fmt','--all','--','--check'])]:
  row={'label':label,'command':['taskset','-c','2','cargo','+ohm','-Zohm-defaults=no',*args],'start':time.time(),'timeout_seconds':900};report['commands'].append(row);save();p=None
  with (O/(label+'.log')).open('wb') as out:
   try:
    p=subprocess.Popen(row['command'],cwd=W,env={**os.environ,**env},stdout=out,stderr=subprocess.STDOUT,start_new_session=True);row['exit']=p.wait(timeout=900)
   except BaseException as e:
    row['exception']=repr(e)
    if p is not None:
     if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
     row['exit']=p.wait()
    raise
   finally:
    out.flush();row['end']=time.time();row['log_sha256']=sha(O/(label+'.log'));save()
  print(label,row['exit'],flush=True)
 report['status']='passed' if all(r['exit']==0 for r in report['commands']) else 'failed'
finally:
 report['after']=source();report['unchanged']=report['before']==report['after'];report['frozen_libraries_after']={p:sha(p) for p in frozen};report['frozen_libraries_unchanged']=report['frozen_libraries_after']==frozen;save()
assert report['status']=='passed' and report['unchanged'] and report['frozen_libraries_unchanged']
