"""Saved human-document arithmetic, source receipt and local-link audit."""
from pathlib import Path
from collections import Counter
from urllib.parse import urlsplit, unquote
import hashlib
import json
import math
import os
import re
import statistics
import subprocess

assert os.sched_getaffinity(0) == {4}
ROOT = Path('/home/dev-user/code/oss/oriole-family-budget-cells')
DOC = ROOT / 'docs/validation/2026-09-11/family-budget-cells'
OUT = Path(__file__).resolve().parent
BASE = '89927e0'
HEAD = '1a4cae6669cd267fa51e0e104c3eac84edb3437d'
tracked, checks, git_commands = {}, [], []
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path):
    path = Path(path)
    raw = path.read_bytes()
    assert tracked.setdefault(str(path), sha(raw)) == sha(raw), ('changed during audit', str(path))
    return raw
def h(path): return sha(read(path))
def j(path): return json.loads(read(path))
def ck(value, label):
    assert value, label
    checks.append(label)
def close(a, b): return math.isclose(a, b, rel_tol=1e-13, abs_tol=1e-15)
def put(name, value): (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
def git(*args):
    command = ['git', '-C', str(ROOT), *args]
    result = subprocess.run(command, capture_output=True, timeout=30)
    git_commands.append({'command': command, 'exit': result.returncode, 'stdout_sha256': sha(result.stdout), 'stderr': result.stderr.decode()})
    ck(result.returncode == 0, 'read-only Git command ' + ' '.join(args))
    return result.stdout

names = ['README.md', 'docs/review.md', 'docs/compatibility.md', 'crates/oriole_expat/README.md', 'benchmarks/results/2026-09-11/family-budget-cells/README.md', 'docs/validation/2026-09-11/family-budget-cells/README.md']
docs = {name:read(ROOT/name).decode() for name in names}
for name,text in docs.items():
    dest=OUT/'observed-docs'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(text)
main,benchmark,report=docs[names[0]],docs[names[4]],docs[names[5]]
base_main=git('show',BASE+':README.md').decode();(OUT/'base-README.md').write_text(base_main)
ck(git('rev-parse','HEAD').decode().strip()==HEAD,'exact runtime commit')
ck(git('rev-parse',HEAD+'^').decode().strip()==git('rev-parse',BASE).decode().strip(),'explicit parent89927')
headings=lambda t:re.findall(r'^#{1,6} .+$',t,re.M)
ck(headings(main)==headings(base_main)==['# Oriole','## Highlights','## Installation','## Getting started','## License'],'top Toucan heading structure exact')
warning=lambda t:'\n'.join(line for line in t.splitlines() if line.startswith('>'))
ck(warning(main)==warning(base_main) and 'production-ready replacement' in warning(main),'top warning exact')
ck(main.split('## License\n',1)[1]==base_main.split('## License\n',1)[1],'entire license exact')
ck(main.split('| Project XML |',1)[0]==base_main.split('| Project XML |',1)[0],'introduction and highlights exact')
ck(main.split('## Installation\n',1)[1]==base_main.split('## Installation\n',1)[1],'installation and remaining sections exact')
ck(main.split('Optional [profile-guided builds]',1)[1].split('The [latest compatibility report]',1)[0]==base_main.split('Optional [profile-guided builds]',1)[1].split('The [latest compatibility report]',1)[0],'historical PGO paragraph exact')
for name in ['docs/review.md','docs/compatibility.md']:ck(read(ROOT/name)==git('show',BASE+':'+name),name+' exact')
pinned={'source-review.json':'90d1b0dabd37b6b649ca09ef415f8842e5920a7646444be8df3b948fb33058e7','build-profile-review.json':'445e938039f95741346dcf91489137631d66ee61655b69adbd4cb66b08c380be','native-review.json':'7a32289080e999735b88f873174b47ab72c9b375678459b875e04b82abd55566','python-review.json':'790412b30861b431a6384d4dc1d8da13470e72e5892109ee816436b23e3e6756','cpython-review.json':'40dd87f271373e1125fee16e424dcf1553dee44960e977c5206acd575209b4a6','gates-review.json':'9188adcfdd987a00c182fc0e2ecbb74ae6282c07f7f14b91f8b343987b29f41b'}
for name,digest in pinned.items():ck(h(DOC/name)==digest,'pinned independent review '+name)
native_summary,python_summary=j(DOC/'native-summary.json'),j(DOC/'python-summary.json')
native_review,python_review=j(DOC/'native-review.json'),j(DOC/'python-review.json')
build_review,cpython_review=j(DOC/'build-profile-review.json'),j(DOC/'cpython-review.json')
gates,workspace,summary=j(DOC/'gates.json'),j(DOC/'workspace.json'),j(DOC/'summary.json')
# Recompute timing medians and ratios from saved sample values only.
native_path = Path('/tmp/oriole-ffi-family-cell-thinlto-timing-study/native-screen/results.json')
native = j(native_path)
python_path = Path('/tmp/oriole-ffi-family-cell-thinlto-python-study/screen/results.json')
python = j(python_path)
ck(native['status'] == python['status'] == 'passed' and native['affinity'] == python['affinity'] == [0], 'successful pinned elapsed records')
ratios = [('candidate_over_published','candidate','published'), ('candidate_over_expat','candidate','expat'), ('published_over_expat','published','expat')]
native_counts = Counter()
for cohort in native['rows']:
    ck(len(cohort['processes']) == 3 and {p['engine'] for p in cohort['processes']} == {'candidate','published','expat'}, 'complete native cohort')
    for worker in cohort['processes']:
        samples = json.loads(worker['stdout'])['samples']
        measured = [s['seconds'] for s in samples if not s['warmup']]
        ck(sum(bool(s['warmup']) for s in samples) == 1 and len(measured) == cohort['condition']['iterations'], 'native fixed warmup and measured count')
        ck(statistics.median(measured) == worker['median_seconds'], 'native worker median from raw samples')
        native_counts.update(workers=1, warmups=1, measured=len(measured))
for row in native['summary']:
    cohorts = [c for c in native['rows'] if c['condition'] == row['condition']]
    ck(sorted(c['pair'] for c in cohorts) == list(range(7)), 'seven native paired rounds')
    for key, left, right in ratios:
        values = []
        for c in cohorts:
            medians = {w['engine']:w['median_seconds'] for w in c['processes']}
            values.append(medians[left] / medians[right])
        ck(values == row['paired_ratios'][key] and statistics.median(values) == row['median_ratios'][key], 'native exact paired ratio family ' + key)
python_counts = Counter()
for worker in python['rows']:
    samples = worker['samples']
    measured = [s['seconds'] for s in samples if not s['warmup']]
    ck(sum(bool(s['warmup']) for s in samples) == 1 and statistics.median(measured) == worker['median_seconds'], 'Python warmup and raw worker median')
    python_counts.update(workers=1, warmups=1, measured=len(measured))
for row in python['summary']:
    c = row['condition']; key = f"{c['name']}/{c['chunk']}/{c['mode']}"
    selected = [w for w in python['rows'] if w['key'] == key]
    ck(len(selected) == 21, '21 Python workers per condition')
    for engine in ['candidate','published','expat']:
        workers = sorted((w for w in selected if w['engine'] == engine), key=lambda w:w['pair'])
        ck([w['pair'] for w in workers] == list(range(7)), 'seven Python paired rounds')
        ck([w['median_seconds'] for w in workers] == row['process_pair_medians_seconds'][engine], 'Python condition process medians')
        ck(all(len([s for s in w['samples'] if not s['warmup']]) == c['iterations'] for w in workers), 'Python fixed measured counts')
    for key, left, right in ratios:
        values = [a/b for a,b in zip(row['process_pair_medians_seconds'][left], row['process_pair_medians_seconds'][right], strict=True)]
        ck(values == row['paired_ratios'][key] and statistics.median(values) == row['median_ratios'][key], 'Python exact paired ratio family ' + key)
ck(dict(native_counts) == {'workers':588,'warmups':588,'measured':105420} and len(native['rows']) == 196 and len(native['summary']) == 28, 'native document counts')
ck(dict(python_counts) == {'workers':504,'warmups':504,'measured':25788} and len(python['summary']) == 24, 'Python document counts')
ck(native_review['counts']['preflight_workers'] == 84 and python_review['preflights'] == 72 and python_review['cohorts'] == 168, 'preflight/cohort counts pinned prior audits')
for suite, aggregates, selectors in [(native,native_summary,{'real':lambda c:not c['name'].startswith('generated-'),'generated':lambda c:c['name'].startswith('generated-')}), (python,python_summary,{'all':lambda c:True,'elementtree':lambda c:c['mode']=='elementtree','pyexpat-events':lambda c:c['mode']=='pyexpat-events'})]:
    for group, select in selectors.items():
        rows = [r for r in suite['summary'] if select(r['condition'])]
        ck(len(rows) == aggregates['groups'][group]['conditions'], 'group conditions ' + group)
        for key, _, _ in ratios:
            values = [r['median_ratios'][key] for r in rows]
            saved = aggregates['groups'][group]['ratios'][key]
            ck(close(statistics.geometric_mean(values),saved['geomean']) and sum(v<1 for v in values)==saved['below_one'], 'all aggregate ratios ' + group + '/' + key)
    regressions = [{'condition':r['condition'],'ratio':r['median_ratios']['candidate_over_published']} for r in suite['summary'] if r['median_ratios']['candidate_over_published']>1]
    ck(regressions == aggregates['regressions'], 'all regressions retained')

labels = {'vulkan':'Vulkan registry','wayland':'Wayland protocol','maven':'Maven POM','batik':'Batik SVG','gtk':'GTK UI','docbook':'DocBook XSL'}
table = []
for name,label in labels.items():
    row = next(r for r in native['summary'] if r['condition']['name']==name and r['condition']['chunk']==4096 and not r['condition']['namespaces'])
    cohorts = [c for c in native['rows'] if c['condition']==row['condition']]
    times = {e:statistics.median(next(w['median_seconds'] for w in c['processes'] if w['engine']==e) for c in cohorts)*1000 for e in ['candidate','expat']}
    table.append(f"| {label} | {times['candidate']:.3f} ms | {times['expat']:.3f} ms | {row['median_ratios']['candidate_over_expat']:.2f}× |")
for text in [main,report]:
    ck(all(line in text for line in table), 'all six display rows exact saved arithmetic')
ck(read(DOC/'table.md').decode()=='\n'.join(table)+'\n','standalone display table exact')
for group,label in [('real','Project XML'),('generated','Generated controls')]:
    g=native_summary['groups'][group]; a,b=(g['ratios'][k] for k in ['candidate_over_published','candidate_over_expat'])
    ck(f"| {label} | {g['conditions']} | {a['geomean']:.6f} | {b['geomean']:.6f} | {a['below_one']} | {b['below_one']} |" in report,'native aggregate displayed '+group)
for group,label in [('elementtree','ElementTree'),('pyexpat-events','pyexpat events'),('all','Combined')]:
    g=python_summary['groups'][group];a,b=(g['ratios'][k] for k in ['candidate_over_published','candidate_over_expat'])
    ck(f"| {label} | {g['conditions']} | {a['geomean']:.6f} | {b['geomean']:.6f} | {a['below_one']} | {b['below_one']} |" in report,'Python aggregate displayed '+group)
for text in [main,report,benchmark]:
    ck('0.9%' in text and '1.71×' in text and '1.31×' in text and 'effectively unchanged' in text,'headlines correct; no Python speedup')
ck(close((1-native_summary['groups']['real']['ratios']['candidate_over_published']['geomean'])*100,0.899620188231775),'native rounded0.9 gain')
native_wins=[r for r in native['summary'] if r['median_ratios']['candidate_over_expat']<1]
python_wins=[r for r in python['summary'] if r['median_ratios']['candidate_over_expat']<1]
ck(len(native_wins)==1 and native_wins[0]['condition']['name']=='batik' and native_wins[0]['condition']['chunk']==4096 and not native_wins[0]['condition']['namespaces'],'one native Batik win')
ck(len(python_wins)==3 and all(r['condition']['name']=='wayland' for r in python_wins),'three Wayland Python wins')
ck({(r['condition']['mode'],r['condition']['chunk']) for r in python_wins}=={('pyexpat-events',4096),('pyexpat-events',65536),('elementtree',65536)},'exact Python win modes')
win=native_wins[0]['median_ratios']['candidate_over_expat'];etwin=next(r['median_ratios']['candidate_over_expat'] for r in python_wins if r['condition']['mode']=='elementtree')
ck(f'{win:.6f}×' in report and f'{(1-win)*100:.2f}%' in main and f'{(1-etwin)*100:.2f}%' in main,'narrow win margins retained')
ck(len(native_summary['regressions'])==4,'all4 native regressions retained')
for r in native_summary['regressions']:ck(f"{(r['ratio']-1)*100:.3f}%" in report,'native regression size '+r['condition']['name'])
pyreg=[r['ratio'] for r in python_summary['regressions']]
ck(len(pyreg)==11 and f'{(min(pyreg)-1)*100:.3f}% to {(max(pyreg)-1)*100:.3f}%' in report,'all11 Python regressions exact range')
ck(summary['native']==native_summary and summary['python']==python_summary,'main summary complete aggregates equal')
ck((gates['api']['passed'],gates['api']['failed'],gates['api']['raw_exit'])==(4347,393,1) and gates['api']['all4740rows_exact'],'unchanged canonical nonzero API outcomes')
ck(gates['api']['bounds']=={'per_test_seconds':3,'per_test_address_space_bytes':1073741824,'per_test_rss_limit_bytes':805306368,'total_timeout_seconds':240},'original canonical bounds')
for key,value in [('strict_baseline_traces',3318),('custom_alias_baseline_comparisons',36456),('malformed_baseline_comparisons',2392)]:ck(gates[key]==value and f'{value:,}' in report,'comparison count '+key)
ck(gates['native']['consumers']==6 and gates['native']['allocation_scenarios_per_linkage']==327,'3 consumers by2 linkage allocation scopes')
ck(gates['publication']['logical_cases']==1304 and gates['publication']['parser_executions']==3912 and gates['end_lifecycle']['logical_cases']==38 and gates['end_oom']['failed_indices']==4 and gates['end_oom']['success_controls']==2,'supplemental publication/End scopes')
for linkage,row in cpython_review['cpython'].items():
    ck(row['methods']==802 and row['reported_skips']==14 and row['expected_failures']==3 and row['failures']==['test.test_pyexpat.BufferTextTest.test1','test.test_sax.CDATAHandlerTest.test_handlers'],'strictCPython outcomes '+linkage)
    ck((row['whole_method_skips'],row['subtest_skips'],row['class_setup_skips'])==(5,8,1),'precise skip categories '+linkage)
ck(workspace['all_target_tests_passed']==400 and workspace['all_target_binaries']==33 and workspace['doc_tests_passed']==1 and workspace['timeout_seconds_per_command']==900 and workspace['failed_or_discarded_runs']==0,'normal workspace counts and unchanged limits')
ck(workspace['same_original_commands'] and workspace['same_original_normal_env_except_target'] and workspace['frozen_normal_and_thinlto_artifacts_unchanged'],'workspace command and source invariants')
thin=build_review['thinlto_build'];normal=build_review['normal_build']
ck(thin['fresh_workspace_compiles']==3 and thin['actual_final_codegen']=='lto=thin' and thin['actual_dependency_codegen']=='linker-plugin-lto' and thin['final_crate_types']==['cdylib','staticlib'] and thin['all_actual_compiler_lines_equal_a55_after_private_paths_only'],'actual0cfd/a55 three-compiler comparison independently covered')
ck(thin['compiler_comparison_sha256']==h('/tmp/oriole-ffi-family-cell-thinlto-study/compiler-comparison.json'),'compiler comparison receipt exact')
ck(normal['fresh_workspace_compiles']==3 and normal['all_actual_compiler_lines_equal_control_after_private_paths_only'],'separate normal build context')
for group in ['libraries','normal_build_libraries']:
    def hashes(v):
        if isinstance(v,dict):
            for x in v.values():yield from hashes(x)
        elif isinstance(v,str) and re.fullmatch('[a-f0-9]{64}',v):yield v
    for digest in hashes(summary[group]):ck(digest in report,'artifact identity disclosed '+digest[:8])
for phrase in ['Raw exits remain nonzero','No callback-fragmentation waiver','normal workspace','Rust release library is uninstrumented','leak checking is disabled','not full successful raw pairs','not represented as Rust tests of the C-only artifact','automatic GC remains enabled','explicit `gc.collect` calls are outside timing','explicit result destruction are timed','No new sustained Rust sanitizer campaign or complete PBS distribution','same two failures','existing Expat differences','not general coverage of a future detached End path','shared host','No samples or conditions are removed','not whole project builds','external DTD is not loaded']:
    ck(phrase in report,'scope limitation '+phrase)
source,assembly=j(DOC/'source.json'),j(DOC/'assembly.json')
ck(assembly['runtime_commit']==HEAD and assembly['parent_commit']==git('rev-parse',BASE).decode().strip() and assembly['source_files']==70,'exact assembly commit scope')
ck(assembly['measured_source_sha256']==h(DOC/'source.json') and assembly['measured_patch_exact'] and assembly['measured_patch_sha256']=='583eb85f93fa83350f3d3674097232eed894ff19ef6908b1657419f469457a67','exact measured two-file patch')
ck(assembly['documentation_only_delta']==['crates/oriole_expat/README.md'],'only additional README changed')
for name,digest in assembly['assembled_source_sha256'].items():ck(h(ROOT/name)==sha(git('show',HEAD+':'+name))==digest,'assembled70 Git/live '+name)
ck([name for name,digest in source['source_sha256'].items() if digest!=assembly['assembled_source_sha256'][name]]==['crates/oriole_expat/README.md'],'source69 equal with single documented difference')
ck(h(DOC/'evidence.tar.gz')==summary['archive']['sha256']=='5dae7cbfb08171d24ac002e425e7c225edfee401129f323396d9480c8731c7fa' and summary['archive']['members']==2801 and summary['archive']['direct_binary_exclusions']==19,'exact main archive identity/counts; child owns full readback')
ck(h(DOC/'files.json')=='07ce4df663a916fa719f5267124519e166f7268222619dc076f3da8288e068c7','initial20 index identity')
# Resolve local Markdown links and GitHub-style heading anchors; remote URLs are inventoried only.
links=[]
def anchors(text):
    found=set(re.findall(r'<a\s+(?:name|id)=[\"\']([^\"\']+)',text));counts=Counter()
    for title in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',text,re.M):
        title=re.sub(r'\[([^\]]+)\]\([^)]*\)',r'\1',title)
        base=re.sub(r'[^\w\- ]','',title.lower()).replace(' ','-')
        slug=base if counts[base]==0 else f'{base}-{counts[base]}'
        counts[base]+=1;found.add(slug)
    return found
for name,text in docs.items():
    for target in re.findall(r'(?<!!)\[[^\]]+\]\(([^)]+)\)',text):
        target=target.strip().strip('<>');parsed=urlsplit(target)
        row={'document':name,'target':target}
        if parsed.scheme or parsed.netloc:
            ck(parsed.scheme in ['https','http','mailto'],'external URL scheme '+target)
            row['scope']='external URL inventoried; not fetched'
        else:
            path=(ROOT/name).parent/unquote(parsed.path) if parsed.path else ROOT/name
            path=path.resolve();ck(path.exists(),'local link exists '+name+' -> '+target)
            if path.is_dir():
                if (path/'README.md').is_file():
                    path=path/'README.md'
                else:
                    ck(not parsed.fragment,'directory listing link has no heading anchor '+target)
            if parsed.fragment:
                ck(unquote(parsed.fragment) in anchors(read(path).decode()),'local heading anchor '+name+' -> '+target)
            elif path.suffix=='.md':read(path)
            row.update(scope='local target verified',resolved=str(path))
        links.append(row)
index_raw=read(DOC/'files.json');index=json.loads(index_raw)['files']
(OUT/'observed-files.json').write_bytes(index_raw)
unindexed=sorted({p.relative_to(DOC).as_posix() for p in DOC.rglob('*') if p.is_file() and p.name!='files.json'}-set(index))
ck(unindexed in [[],['command-assembly.json']],'only authorized new assembly receipt may await index refresh')
stale_index_entries=[]
for name,row in index.items():
    raw=read(DOC/name)
    if sha(raw)!=row['sha256'] or len(raw)!=row['bytes']:
        stale_index_entries.append({'path':name,'indexed':row,'current':{'sha256':sha(raw),'bytes':len(raw)}})
ck({r['path'] for r in stale_index_entries} <= {'README.md','oriole-write-c-library-thinlto-docs.py','oriole-attach-c-library-command-validation.py'},'only authorized native-run wording edits await index refresh')
ck(all(sha(Path(path).read_bytes())==value for path,value in tracked.items()),'all read document and evidence bytes unchanged')

for path,digest in tracked.items():ck(sha(Path(path).read_bytes())==digest,'end-of-audit unchanged '+path)
verified_input_files=len(tracked)
put('read-files.json',tracked);put('checks.json',checks);put('links.json',links);put('git-reads.json',git_commands)
put('arithmetic.json',{'native_counts':dict(native_counts),'python_counts':dict(python_counts),'native':native_summary,'python':python_summary,'table':table})
put('review.json',{'status':'independent_cell_human_document_audit_passed','scope':'Read-only saved-data/source and human-document audit; no builds, parser executions, test or timing reruns. Separate child audits archive members/origins/nested handoffs/index.','findings':[],'runtime_commit':HEAD,'initial_index_sha256':h(DOC/'files.json'),'source_files':70,'native_workers':588,'python_workers':504,'native_measured':105420,'python_measured':25788,'normal_workspace':'400 tests across 33 binaries plus 1 doc test; C-only artifact gates separate','thinlto_compiler_comparison':'Independent 445e review proves 3 actual fresh workspace compiler invocations for 0cfd match a55 after private paths only; digest rechecked','numeric_conclusion':'Native 0.8996% lower across 24 conditions; Python effectively flat, with 13/24 lower and 11 regressions. Expat comparison remains 1.71375 native / 1.30703 Python.','readme_invariants':'Exact base heading hierarchy, warning, complete license, intro/highlights and installation/remainder; historical PGO/fuzz/PBS scope retained.','links':len(links),'checks':len(checks),'verified_input_files':verified_input_files,'generator_sha256':h(__file__),'read_files_sha256':h(OUT/'read-files.json'),'limitations':['No new full PBS distribution or sustained sanitizer evidence.','Original 393 API and 2 strict CPython failures remain.','Custom successful raw pairs were not retained; prior independent C gate scope explicitly limited.','Shared host; no CPU exclusivity proof; no broad faster-than-Expat claim.','Reviewer authored prototype/runtime; independent root source 90d1 and child source/build/native/C gates reviews separately retained.']})
print(json.dumps({'review_sha256':h(OUT/'review.json'),'checks':len(checks),'files':len(tracked)}))
