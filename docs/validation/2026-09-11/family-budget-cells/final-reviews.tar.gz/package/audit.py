"""Saved package-byte audit. No project code imports or target execution."""
from pathlib import Path, PurePosixPath
from collections import Counter
import ast
import hashlib
import io
import json
import os
import subprocess
import tarfile

assert os.sched_getaffinity(0) == {4}
ROOT = Path('/home/dev-user/code/oss/oriole-family-budget-cells')
DOC = ROOT / 'docs/validation/2026-09-11/family-budget-cells'
OUT = Path(__file__).resolve().parent
PACKAGE = Path('/tmp/oriole-package-family-budget-cells.py')
MAIN_SHA = '5dae7cbfb08171d24ac002e425e7c225edfee401129f323396d9480c8731c7fa'
INDEX_SHA = '07ce4df663a916fa719f5267124519e166f7268222619dc076f3da8288e068c7'
SOURCE_SHA = '164201b810c2a121e20f50c4a890fa3e1a8fa48e69e40e44069fc42059d4dfc6'
PATCH_SHA = '583eb85f93fa83350f3d3674097232eed894ff19ef6908b1657419f469457a67'
HEAD = '1a4cae6669cd267fa51e0e104c3eac84edb3437d'
PARENT = '89927e09a6a9f1576ee05e3cf757e2b4159d5d36'
GATE_SHA = '259d620494e7a42655dcdaf12daa6817a133d54065b539df109399e7527abb81'
REVIEW_SHA = '9f0ed037603d5def2494cd7dcce197d09d2fc534f1cadbd7463ff6a1f0c8d7b1'
tracked, checks, git_reads = {}, [], []
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path):
    path = Path(path)
    raw = path.read_bytes()
    assert tracked.setdefault(str(path), sha(raw)) == sha(raw), ('changed during audit', str(path))
    return raw
def h(path): return sha(read(path))
def j(path): return json.loads(read(path))
def ck(value, label):
    assert value, label
    checks.append(label)
def magic(raw): return 'ELF' if raw.startswith(b'\x7fELF') else 'ar' if raw.startswith(b'!<arch>\n') else None
def safe(name): return name == PurePosixPath(name).as_posix() and not name.startswith('/') and '..' not in PurePosixPath(name).parts
def unpack(raw, label, normalized=False):
    result = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        for member in archive:
            ck(member.isfile() and safe(member.name) and member.name not in result, label + ' safe unique regular ' + member.name)
            payload = archive.extractfile(member).read()
            ck(len(payload) == member.size, label + ' size ' + member.name)
            if normalized: ck(member.mode == 0o644 and member.mtime == 0, label + ' normalized metadata ' + member.name)
            result[member.name] = payload
    return result
def matches(raw, row): return sha(raw) == row['sha256'] and len(raw) == row.get('bytes', row.get('size'))
def put(name, obj): (OUT / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')
def git(*args):
    command = ['git', '-C', str(ROOT), *args]
    p = subprocess.run(command, capture_output=True, timeout=20)
    ck(p.returncode == 0, 'read-only Git success ' + ' '.join(args))
    git_reads.append({'command': command, 'exit': p.returncode, 'stdout_sha256': sha(p.stdout), 'stderr_sha256': sha(p.stderr), 'stdout_bytes': len(p.stdout)})
    return p.stdout

# Keep the authorized initial index immutable; a future publication refresh is separate.
index_raw = read(DOC / 'files.json')
(OUT / 'observed-files.json').write_bytes(index_raw)
outer = json.loads(index_raw)['files']
ck(sha(index_raw) == INDEX_SHA, 'pinned initial index')
ck(len(outer) == 20 and set(outer) == {p.relative_to(DOC).as_posix() for p in DOC.rglob('*') if p.is_file() and p.name != 'files.json'}, 'exact initial20 inventory')
for name, row in outer.items():
    ck(safe(name) and not (DOC / name).is_symlink() and matches(read(DOC / name), row), 'outer index ' + name)

# Read generator literals, never import or execute the project packager.
constants = {}
for node in ast.parse(read(PACKAGE)).body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in ['DIRECTORIES', 'CONTROLLERS', 'COPIES']:
                constants[target.id] = ast.literal_eval(node.value)
ck({k:len(v) for k,v in constants.items()} == {'DIRECTORIES':11,'CONTROLLERS':8,'COPIES':12}, 'package selection constants')
selected = {}
for prefix, location in constants['DIRECTORIES'].items():
    base = Path(location)
    for path in sorted(base.rglob('*')):
        if path.is_file() and not path.is_symlink() and '__pycache__' not in path.parts:
            name = prefix + '/' + path.relative_to(base).as_posix()
            ck(name not in selected, 'unique selection ' + name)
            selected[name] = str(path)
for location in constants['CONTROLLERS']:
    name = 'controllers/' + Path(location).name
    ck(name not in selected, 'unique controller ' + name)
    selected[name] = location
index = j(DOC / 'archive-members.json')
included, excluded = index['members'], index['excluded_binaries']
ck(len(included) == 2801 and len(excluded) == 19, '2801 members19 direct exclusions')
ck(len(selected) == 2820 and {r['path']:r['source'] for r in included+excluded} == selected, 'complete reconstructed member-origin selection')
ck(len({r['path'] for r in included+excluded}) == len(selected), 'disjoint unique partitions')
for rows in [included, excluded]: ck([r['path'] for r in rows] == sorted(r['path'] for r in rows), 'sorted partition')
archive_raw = read(DOC / 'evidence.tar.gz')
ck(sha(archive_raw) == MAIN_SHA, 'pinned main archive')
members = unpack(archive_raw, 'main', True)
ck(list(members) == [r['path'] for r in included], 'exact main archive inventory/order')
for row in included:
    raw = members[row['path']]
    ck(matches(raw,row) and raw == read(row['source']) and magic(raw) is None, 'main origin and direct exclusion policy ' + row['path'])
excluded_formats = Counter()
for row in excluded:
    raw = read(row['source'])
    ck(matches(raw,row) and magic(raw) is not None, 'direct excluded origin ' + row['path'])
    excluded_formats[magic(raw)] += 1

measured = j(DOC / 'source.json')
source_map = measured['source_sha256']
ck(len(source_map) == 70 and h(DOC / 'source.json') == SOURCE_SHA, 'pinned measured source70')
source_archives = {}
def check_source_archive(raw, manifest, label):
    source = json.loads(manifest)
    data = unpack(raw, label)
    ck({n:sha(b) for n,b in data.items()} == source['source_sha256'] == source_map, label + ' exact measured source70')
    for name, value in source_map.items(): ck(h(Path(source['worktree']) / name) == value, label + ' live measured source ' + name)
    source_archives[label] = {'archive_sha256':sha(raw),'manifest_sha256':sha(manifest),'members':len(data)}
    return data
source_names = [n for n in members if n.endswith('source.tar.gz')]
ck(source_names == ['normal-build-profile/source.tar.gz','thinlto-build/source.tar.gz','workspace/source.tar.gz','workspace/workspace-checks/source.tar.gz'], 'four direct nested source archives')
for name in source_names:
    check_source_archive(members[name], members[name.removesuffix('source.tar.gz')+'source.json'], name)

# Re-read nested C gate member bytes and every retained/excluded origin.
gate_manifest = json.loads(members['gates/artifact-manifest.json'])
gate_data = unpack(members['gates/evidence.tar.gz'], 'nested gates')
gate_origin = Path('/tmp/oriole-ffi-family-cell-thinlto-gates')
gate_readback = json.loads(members['gates/readback.json'])
ck(sha(members['gates/evidence.tar.gz']) == GATE_SHA and len(gate_data) == 223 and set(gate_data) == set(gate_manifest), 'pinned complete gate223')
ck(gate_readback['status'] == 'passed' and gate_readback['archive_sha256'] == GATE_SHA and gate_readback['archive_bytes'] == len(members['gates/evidence.tar.gz']) and gate_readback['artifact_manifest_sha256'] == sha(members['gates/artifact-manifest.json']) and gate_readback['summary_sha256'] == sha(members['gates/summary.json']) and gate_readback['members'] == 223 and gate_readback['nested_source_members'] == 70 and gate_readback['excluded_binary_count'] == 10, 'all gate readback metadata')
for name, raw in gate_data.items():
    ck(matches(raw,gate_manifest[name]) and raw == read(gate_origin/name) and magic(raw) is None, 'nested gate origin ' + name)
check_source_archive(gate_data['source.tar.gz'], gate_data['source.json'], 'gates/source.tar.gz')
ck(gate_data['source.json'] == read(DOC/'source.json'), 'gate source outer copy exact')
gate_exclusions = json.loads(members['gates/excluded-binaries.json'])
gate_formats = Counter()
ck(len(gate_exclusions) == 10 and not set(gate_exclusions).intersection(gate_data), 'ten separate gate exclusions')
for name, row in gate_exclusions.items():
    raw = read(gate_origin/name)
    ck(matches(raw,row) and magic(raw) is not None, 'nested gate exclusion origin ' + name)
    gate_formats[magic(raw)] += 1

# Review handoff: all63 stored files and their origins, including failed checker attempts.
review_manifest = json.loads(members['reviews/manifest.json'])
ck(set(review_manifest) == {'members.json','package.py','reviews.tar.gz','summary.json'}, 'review outer four-file manifest')
for name,row in review_manifest.items(): ck(matches(members['reviews/'+name],row), 'review outer manifest '+name)
review_index = json.loads(members['reviews/members.json'])
review_data = unpack(members['reviews/reviews.tar.gz'], 'nested reviews')
ck(sha(members['reviews/reviews.tar.gz']) == REVIEW_SHA and len(review_data) == 63 and set(review_data) == set(review_index), 'pinned complete review63')
for name,row in review_index.items():
    ck(matches(review_data[name],row) and review_data[name] == read(row['source']) and magic(review_data[name]) is None, 'review member origin '+name)
review_roots = {}
for node in ast.parse(members['reviews/package.py']).body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='roots' for t in node.targets):
        ck(isinstance(node.value,ast.Dict), 'review roots literal dict')
        for key,value in zip(node.value.keys,node.value.values,strict=True):
            ck(isinstance(value,ast.Call) and isinstance(value.func,ast.Name) and value.func.id=='Path' and len(value.args)==1, 'review fixed Path literal')
            review_roots[ast.literal_eval(key)] = Path(ast.literal_eval(value.args[0]))
review_selection = {prefix+'/'+p.relative_to(root).as_posix():str(p) for prefix,root in review_roots.items() for p in sorted(root.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
ck(len(review_roots)==7 and review_selection == {n:r['source'] for n,r in review_index.items()}, 'complete review seven-root selection')
review_summary = json.loads(members['reviews/summary.json'])
pinned_reviews = {'source':'90d1b0dabd37b6b649ca09ef415f8842e5920a7646444be8df3b948fb33058e7','build-profile':'445e938039f95741346dcf91489137631d66ee61655b69adbd4cb66b08c380be','native':'7a32289080e999735b88f873174b47ab72c9b375678459b875e04b82abd55566','python':'790412b30861b431a6384d4dc1d8da13470e72e5892109ee816436b23e3e6756','cpython':'40dd87f271373e1125fee16e424dcf1553dee44960e977c5206acd575209b4a6','c-gates':'9188adcfdd987a00c182fc0e2ecbb74ae6282c07f7f14b91f8b343987b29f41b','workspace':'fcde3480b1128963c1f63f7c32b63802fdf99ab5ff5ff43298b26c587da73b71'}
for label,value in pinned_reviews.items():
    name = label + ('/final-review.json' if label=='c-gates' else '/review.json')
    row = review_summary['reviews'][label]
    ck(sha(review_data[name]) == h(row['path']) == row['sha256'] == value, 'pinned review '+label)
    ck(json.loads(review_data[name])['status'] == row['status'], 'review status exact '+label)
gate_review = json.loads(review_data['c-gates/final-review.json'])
ck(gate_review['archive'] == {'manifest_sha256':sha(members['gates/artifact-manifest.json']),'archive_sha256':GATE_SHA,'members':223,'nested_source_members':70,'direct_excluded_binaries':10,'all_stored_origin_bytes_exact':True}, 'nested gate is previously independently audited archive')
build_review = json.loads(review_data['build-profile/review.json'])
for label,field,expected in [('normal-build-profile','normal_build','5d18c9c89da352b1fb7b8a85c2c4a7406c50139671a4205a7892a8251e21fd84'),('thinlto-build','thinlto_build','c5270b2a6e6e6445c9ae868384b14ef7fbf8023e3e1c4a215c0cd8994a5c5e81')]:
    ck(sha(members[label+'/compiler-comparison.json']) == build_review[field]['compiler_comparison_sha256'] == expected, 'pinned actual compiler comparison '+label)

copies=[]
for name,origin in constants['COPIES'].items():
    ck(read(DOC/name) == read(origin), 'outer exact copied receipt '+name)
    copies.append({'path':name,'origin':origin,'sha256':h(DOC/name)})
writer='oriole-write-family-budget-cells-docs.py'
ck(read(DOC/writer) == read(Path('/tmp')/writer), 'current writer copied exactly')
summary,assembly,gates = j(DOC/'summary.json'),j(DOC/'assembly.json'),j(DOC/'gates.json')
ck(summary['source_assembly'] == assembly and summary['runtime_commit'] == HEAD, 'summary source assembly copy')
ck(summary['native'] == j(DOC/'native-summary.json') and summary['python'] == j(DOC/'python-summary.json') and summary['workspace'] == j(DOC/'workspace.json') and summary['api'] == gates['api'], 'summary exact complete copied report objects')
ck(summary['archive'] == {'sha256':MAIN_SHA,'members':2801,'direct_binary_exclusions':19,'bytes':len(archive_raw),'raw_bytes':sum(r['bytes'] for r in included),'member_and_origin_readback':True}, 'summary archive arithmetic')
ck(summary['libraries'] == gates['libraries'] and summary['libraries']['candidate'] == gate_review['libraries'] == build_review['libraries']['thinlto'] and summary['normal_build_libraries'] == build_review['libraries']['normal'], 'normal and actual ThinLTO library identities linked')
for role,root in [('baseline',Path('/tmp/oriole-thinlto-production-study/thinlto')),('candidate',Path('/tmp/oriole-ffi-family-cell-thinlto-study'))]:
    for name,value in summary['libraries'][role].items(): ck(h(root/name)==value, 'retained library hash '+role+'/'+name)
for name,value in summary['normal_build_libraries'].items(): ck(h(Path('/tmp/oriole-ffi-family-cell-study')/name)==value, 'normal library retained hash '+name)

# Verify actual Git assembly without executing any build or parser.
ck(git('rev-parse','--show-toplevel').decode().strip() == str(ROOT), 'real checkout root')
ck(git('rev-parse','--git-common-dir').decode().strip() == '/home/dev-user/code/oss/oriole/.git', 'linked common Git directory')
ck(git('rev-parse','HEAD').decode().strip() == HEAD and git('rev-parse','HEAD^').decode().strip() == PARENT, 'actual parent and runtime commit')
ck(assembly['runtime_commit']==HEAD and assembly['parent_commit']==PARENT and assembly['source_files']==70 and assembly['measured_source_sha256']==SOURCE_SHA and assembly['measured_patch_sha256']==PATCH_SHA and assembly['measured_patch_exact'], 'pinned assembly metadata')
assembled = assembly['assembled_source_sha256']
ck(set(assembled)==set(source_map), 'assembled source70 inventory')
for name,value in assembled.items():
    ck(h(ROOT/name)==value and sha(git('show',HEAD+':'+name))==value, 'source live and GitHEAD exact '+name)
delta=[name for name in source_map if source_map[name]!=assembled[name]]
ck(delta==assembly['documentation_only_delta']==['crates/oriole_expat/README.md'], 'only measured-source delta inherited FFI README')
readme=delta[0]
ck(git('show',PARENT+':'+readme)==read(ROOT/readme), 'FFI README inherited unchanged from parent')
changed=git('diff','--name-only',PARENT,HEAD).decode().splitlines()
ck(changed==['crates/oriole_expat/src/lib.rs','crates/oriole_expat/src/tests.rs'], 'exact two-file runtime commit')
patch=git('diff',PARENT,HEAD,'--',*changed)
(OUT/'observed-runtime.patch').write_bytes(patch)
ck(sha(patch)==PATCH_SHA and patch==members['normal-build-profile/candidate.patch']==members['thinlto-build/candidate.patch'], 'assembled commit patch exact measured patch')

ck(read(DOC/'files.json')==index_raw,'initial index unchanged during audit')
ck(all(sha(Path(p).read_bytes())==value for p,value in tracked.items()),'all observed source/package/origin bytes unchanged')
put('checked-files.json',tracked)
put('checks.json',checks)
put('git-reads.json',git_reads)
report={
 'status':'independent_cell_publication_package_audit_passed',
 'scope':'Saved byte/index/member/origin/source-assembly audit only. No project generator, parser, compiler, test, profile, timing or loaded library execution; no repository writes.',
 'cpu':4,'findings':[],
 'outer_index':{'entries':20,'sha256':INDEX_SHA,'snapshot':'observed-files.json','readme_sha256':h(DOC/'README.md'),'scope':'Initial frozen20 before authorized later addition of the package/human review receipts.'},
 'main_archive':{'sha256':MAIN_SHA,'bytes':len(archive_raw),'raw_bytes':sum(r['bytes'] for r in included),'members':2801,'direct_excluded_binaries':19,'excluded_formats':dict(excluded_formats),'all_member_origins_exact':True,'directories':11,'controllers':8},
 'nested_gates':{'archive_sha256':GATE_SHA,'manifest_sha256':sha(members['gates/artifact-manifest.json']),'members':223,'source_members':70,'direct_excluded_binaries':10,'excluded_formats':dict(gate_formats),'all_member_and_excluded_origins_exact':True,'pinned_review_sha256':pinned_reviews['c-gates']},
 'nested_reviews':{'archive_sha256':REVIEW_SHA,'manifest_sha256':sha(members['reviews/manifest.json']),'members':63,'all_origins_exact':True,'pinned_reviews':pinned_reviews},
 'source_archives':source_archives,
 'assembly':{'runtime_commit':HEAD,'parent_commit':PARENT,'files':70,'source_sha256':SOURCE_SHA,'assembly_sha256':h(DOC/'assembly.json'),'measured_patch_sha256':PATCH_SHA,'runtime_changed_files':changed,'measured_source_documentation_delta':delta,'all70_live_and_GitHEAD_exact':True},
 'copied_receipts':copies,'libraries':summary['libraries'],'normal_build_libraries':summary['normal_build_libraries'],
 'compiler_comparisons':{'normal_sha256':build_review['normal_build']['compiler_comparison_sha256'],'thinlto_sha256':build_review['thinlto_build']['compiler_comparison_sha256'],'prior_saved_build_profile_review_sha256':pinned_reviews['build-profile']},
 'limits':[
  'Main19 exclusions and nested C-gate10 exclusions are separate direct archive policies, verified by ELF/ar magic. This is not a claim that every compressed/container payload is generally binary-free.',
  'All five source70 archives were fully read; source archives repeat the same measured bytes, while the current publication tree inherits only its recorded C-ABI README difference. The actual two-file runtime commit patch exactly matches the measured patch.',
  'Prior pinned reviews supply saved build, instruction, native, Python, CPython, gate and workspace outcome validation. This audit verifies their packaging and raw-copy identities without re-running their semantic checks or transferring normal-workspace outcomes to the C-only ThinLTO library.',
  'Original canonical393 failures, custom-alias missing successful raw pairs, reference callback/position differences, normal instruction regressions, elapsed regressions, and original setup/checker attempts remain retained in byte-identical reports and raw artifacts; no new correctness or speed claim is inferred.',
  'The reviewer authored the two added helper/lifecycle tests and the earlier End lifecycle oracle. Their independent source-design review is owned by root/peer reviewers; this package review does not independently certify its own authored tests.',
  'Human wording, table interpretation, links and top-level documentation invariants are owned by a concurrent separate reviewer. A later index refresh is outside this initial20 snapshot.'
 ],
 'checks':len(checks),'checked_files':len(tracked),'git_read_commands':len(git_reads),'generator_sha256':sha(Path(__file__).read_bytes()),'checked_files_sha256':h(OUT/'checked-files.json')
}
put('review.json',report)
print(json.dumps({'status':report['status'],'checks':report['checks'],'checked_files':report['checked_files'],'review_sha256':h(OUT/'review.json')}))
