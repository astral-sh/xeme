"""Prepare the unchanged current ThinPGO C gates; never execute a target."""
from pathlib import Path
import difflib
import hashlib
import json
import os
import shutil
import subprocess

if not __debug__:
    raise RuntimeError('Assertions required')
assert os.sched_getaffinity(0)=={6}
R=Path(__file__).parent
OLD=Path('/tmp/oriole-current-thin-pgo-gates')
P=Path('/tmp/oriole-literal-attribute-check-pgo-study')
BASE=Path('/tmp/oriole-native-byte-count-pgo-study')
W=Path('/home/dev-user/code/oss/oriole-literal-attribute-check')
REVIEW=Path('/tmp/oriole-literal-attribute-check-source-independent-review')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
j=lambda p:json.loads(Path(p).read_text())
assert not (R/'preparation.json').exists()
build=j(P/'pair-report.json');base_build=j(BASE/'pair-report.json')
assert build['status']==base_build['status']=='passed'
assert all(build[k] for k in ['source_unchanged','scripts_unchanged','tools_unchanged'])
source=j(P/'source.json');baseline_source=j(BASE/'source.json')
assert len(source['source_sha256'])==70
assert [n for n,v in source['source_sha256'].items() if v!=baseline_source['source_sha256'][n]]==['crates/oriole/src/tag.rs']
assert all(sha(W/n)==v for n,v in source['source_sha256'].items())
assert sha(REVIEW/'review.json')=='0600b8974dec93d761f644f53d18e8b4dedc6a50bddbff6babd49e520da4d97c'
assert j(REVIEW/'review.json')['source_manifest_sha256']==sha(P/'source.json')
L=Path(build['pgo_manifest']['path']).parent/'use'
B=Path(base_build['pgo_manifest']['path']).parent/'use'
expected={label+'_'+kind:sha(folder/('liboriole_expat.'+suffix))
          for label,folder in [('baseline',B),('candidate',L)]
          for suffix,kind in [('so','shared'),('a','static')]}
for label,data in [('baseline',base_build),('candidate',build)]:
    for suffix,kind in [('so','shared'),('a','static')]:
        assert expected[label+'_'+kind]==data['pgo_libraries']['use/liboriole_expat.'+suffix]
assert expected['baseline_shared']=='4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02'
assert expected['baseline_static']=='8b6ca03e6fd4be81aba81cccf10b4aa2d67e16586010477cba1e8f23a4dec97d'
raw=OLD/'api-native/upstream-api/results.json'
assert sha(raw)=='dcda1affc7cfa69d1e77dd60b7c76360e572e2a7767d6d4ded084ab1575647d5'
assert len(j(raw)['results'])==4740
for n in ['source.json','source.tar.gz']:
    shutil.copyfile(P/n,R/n)
shutil.copyfile(P/'pair-report.json',R/'build.json')
shutil.copyfile(P/'candidate.patch',R/'runtime-source.patch')
(R/'tools').mkdir()
shutil.copyfile(W/'tools/xml_abi.py',R/'tools/xml_abi.py')
assert sha(R/'tools/xml_abi.py')==sha(OLD/'tools/xml_abi.py')

# Simultaneous replacement avoids mapping the old candidate into the new candidate
# after that old candidate was intentionally selected as the new behavior control.
changes=[
 ('/tmp/oriole-native-byte-count-thinlto-study/source.json',str(BASE/'source.json')),
 (str(OLD),str(R)),
 ('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use',str(L)),
 ('/tmp/oriole-native-byte-count-thinlto-study',str(B)),
 ('/tmp/oriole-native-byte-count-gates/api-native/upstream-api',str(OLD/'api-native/upstream-api')),
 ('/home/dev-user/code/oss/oriole-native-byte-count-pgo',str(W)),
 ('ccfb22956a11c1b241ec755f46245c61f088187ef93143b77a7afec748983821',expected['baseline_shared']),
 ('4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02',expected['candidate_shared']),
 ('f58d5bc6ed28077933fcbcb84ad876cc7208e0102c9008347223da91a328b03c',expected['baseline_static']),
 ('8b6ca03e6fd4be81aba81cccf10b4aa2d67e16586010477cba1e8f23a4dec97d',expected['candidate_static']),
 ("'taskset','-c','1'", "'taskset','-c','5'"),
 ("'taskset', '-c', '1'", "'taskset', '-c', '5'"),
 ('os.sched_getaffinity(0)=={1}', 'os.sched_getaffinity(0)=={5}'),
 ("cpu={'api':1,'other':1}", "cpu={'api':5,'other':5}"),
 ("cpu={'end':1}", "cpu={'end':5}"),
 ("'cpu': 1", "'cpu': 5"),
 ('os.sched_getaffinity(0)) == [1]', 'os.sched_getaffinity(0)) == [5]'),
 ("report['affinity'] == [1]", "report['affinity'] == [5]"),
 ('CPU1','CPU5'),
 ("report['source']['git_commit']='be22a27'", "report['source']['base_commit']='c1776c922b023a3558badfefa697cd11b0d37d8e'"),
]
names=['api_native.py','other_controls.py','publication_probe.py','run_publication.py',
 'prepare_malformed.py','run_malformed.py','classify_observations.py',
 'end-lifecycle-final/oracle.py','end-lifecycle-final/controller.py',
 'end-oom-final/run.py','run_lane.py','run_remaining.py','summarize.py']
deltas={};prior={}
for n in names:
    a=(OLD/n).read_text();b=a
    for i,(x,y) in enumerate(changes):b=b.replace(x,'__LITERAL_GATE_'+str(i)+'__')
    for i,(x,y) in enumerate(changes):b=b.replace('__LITERAL_GATE_'+str(i)+'__',y)
    assert '__LITERAL_GATE_' not in b
    p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(b)
    compile(b,str(p),'exec')
    deltas[n]=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=str(OLD/n),tofile=str(p)))
    prior[str(OLD/n)]=sha(OLD/n)
for n in ['probe.c','original-allocations.c','expat.h']:
    shutil.copyfile(OLD/'end-oom-final'/n,R/'end-oom-final'/n)
shutil.copyfile(OLD/'end-lifecycle-final/SOURCE_REVIEW.md',R/'end-lifecycle-final/SOURCE_REVIEW.md')
for n in ['integration.c','adversarial.c','allocations.c']:
    assert sha(W/'tests/c'/n)==sha(OLD/'api-native/native'/n)

# This small preparer only copies and hashes Python source; it loads no parser.
cmd=['taskset','-c','6','python3','-I','-S',str(R/'prepare_malformed.py')]
completed=subprocess.run(cmd,capture_output=True,timeout=30)
(R/'prepare-malformed.stdout').write_bytes(completed.stdout)
(R/'prepare-malformed.stderr').write_bytes(completed.stderr)
assert completed.returncode==0
(R/'controller.patch').write_text(''.join(deltas.values()))
(R/'controller-deltas.json').write_text(json.dumps(deltas,indent=2)+'\n')
tracked=[P/'pair-report.json',P/'source.json',P/'tool-source.json',Path(build['pgo_manifest']['path']),
 BASE/'pair-report.json',BASE/'source.json',Path(base_build['pgo_manifest']['path']),
 L/'liboriole_expat.so',L/'liboriole_expat.a',B/'liboriole_expat.so',B/'liboriole_expat.a',
 raw,OLD/'api-native/upstream-api/manifest.json',REVIEW/'review.json',
 *[W/n for n in source['source_sha256']],*[R/n for n in names],*[Path(n) for n in prior],
 R/'tools/xml_abi.py',R/'end-lifecycle-final/SOURCE_REVIEW.md',
 *[R/'end-oom-final'/n for n in ['probe.c','original-allocations.c','expat.h']],
 R/'malformed/malformed_probe.py',R/'malformed/original-malformed-probe.py']
report={
 'status':'prepared_not_executed','before':{str(p):sha(p) for p in tracked},
 'controllers':{n:sha(R/n) for n in names},'prior_controllers':prior,'replacements':changes,
 'libraries':expected,'candidate_library_directory':str(L),'baseline_library_directory':str(B),
 'candidate_source_manifest_sha256':sha(P/'source.json'),'source_runtime_delta':['crates/oriole/src/tag.rs'],
 'baseline_rationale':'Use the measured current ThinPGO4f/8b6 libraries and original current-thin-PGO dcda API rows as the behavior baseline. New normal and fresh PGO compiler/profile comparisons are reviewed separately.',
 'scope':'Original4740 at3s/test,1GiB AS,768MiB RSS,240s total;6 native C runs and327 allocation scenarios per linkage; strict3318/custom36456/malformed2392/publication1304/3912/End38+6. Original fixtures/assertions/limits and failure retention unchanged.',
 'execution':'Prepared CPU5 api/other/end lanes; all target execution remains unscheduled pending root direction. Preparation used CPU6 and performed file operations/syntax compilation only.',
 'adaptation':'Paths, candidate/control identities, CPU1-to-5 metadata/affinity and source base label only. All existing subprocess timeouts, session/group cleanup, fixture enumeration, row comparison and corrected End/classifier ordering retained.',
 'limitations':['C ASan/UBSan only; optimized Rust library uninstrumented, leak checking disabled.','Successful custom alias raw pairs are absent from unchanged helper; its counts/scripts/commands/differences remain the retained scope.','Original393 API failures and reference callback-position differences remain; new result changes are recorded before any parity assertion.','Historical End SOURCE_REVIEW describes original fixture provenance, not the current helper.','No workspace, strictCPython, timing or adoption claim.']}
(R/'preparation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'preparation_sha256':sha(R/'preparation.json'),'controller_patch_sha256':sha(R/'controller.patch'),'libraries':expected}))
