from pathlib import Path
import hashlib,json,os,signal,subprocess,time,sys
if not __debug__:raise RuntimeError('Assertions required')
R=Path(__file__).parent;lane=sys.argv[1];cpu={'api':4,'other':4}[lane]
assert os.sched_getaffinity(0)=={cpu}
py='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12';h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
names={'api':['api_native.py'],'other':['other_controls.py','run_publication.py','run_malformed.py','classify_observations.py']}[lane]
r={'status':'incomplete','lane':lane,'cpu':cpu,'jobs':[]};save=lambda:(R/(lane+'-controller.json')).write_text(json.dumps(r,indent=2)+'\n')
expected=json.loads((R/'preparation.json').read_text())['before'];active=None
try:
 r['before']={p:h(p) for p in expected};assert r['before']==expected;save()
 for n in names:
  script=R/n;prefix=R/(n.replace('/','-'));row={'script':n,'sha256':h(script),'command':['taskset','-c',str(cpu),py,'-I','-S',str(script)],'start':time.time(),'timeout':660};r['jobs'].append(row);save()
  with Path(str(prefix)+'.stdout').open('wb') as out,Path(str(prefix)+'.stderr').open('wb') as err:
   try:
    active=subprocess.Popen(row['command'],stdout=out,stderr=err,start_new_session=True);row['exit']=active.wait(timeout=row['timeout'])
   except BaseException as e:
    row['exception']=repr(e)
    if active is not None:
     if active.poll() is None:os.killpg(active.pid,signal.SIGKILL)
     row['exit']=active.wait()
    raise
   finally:
    active=None;out.flush();err.flush();row['end']=time.time();row['stdout_sha256']=h(Path(str(prefix)+'.stdout'));row['stderr_sha256']=h(Path(str(prefix)+'.stderr'));save()
  print(n,row['exit'],flush=True);assert row['exit']==0
 r['status']='completed_zero_exits'
except BaseException as e:r['status']='failed';r['exception']=repr(e);raise
finally:
 r['after']={};r['hash_errors']=[]
 for p in expected:
  try:r['after'][p]=h(p)
  except BaseException as e:r['hash_errors'].append({'path':p,'exception':repr(e)})
 r['unchanged']=r.get('before')==r['after'] and not r['hash_errors']
 if not r['unchanged']:r['status']='failed_identity'
 save()
assert r['unchanged'];print(r['status'],flush=True)
