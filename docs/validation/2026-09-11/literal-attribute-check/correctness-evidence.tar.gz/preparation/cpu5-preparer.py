"""Create a scheduling-only preparer revision, without running any gates."""
import difflib
import hashlib
import json
from pathlib import Path
old=Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates')
new=Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates-cpu5')
assert not new.exists()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p):h(p) for p in old.rglob('*') if p.is_file()}
assert h(old/'preparation.json')=='32bb5070992ae5e01fc7b484e3400244d74d8fd5527b4672b0e150dd9cd3f04f'
original=(old/'prepare.py').read_text();revised=original
changes=[
 ("'taskset','-c','4'", "'taskset','-c','5'"),
 ("'taskset', '-c', '4'", "'taskset', '-c', '5'"),
 ('os.sched_getaffinity(0)=={4}', 'os.sched_getaffinity(0)=={5}'),
 ("cpu={'api':4,'other':4}", "cpu={'api':5,'other':5}"),
 ("cpu={'end':4}", "cpu={'end':5}"),
 ("'cpu': 4", "'cpu': 5"),
 ('os.sched_getaffinity(0)) == [4]', 'os.sched_getaffinity(0)) == [5]'),
 ("report['affinity'] == [4]", "report['affinity'] == [5]"),
 ('CPU4','CPU5'),
 ('CPU1-to-4','CPU1-to-5'),
]
for x,y in changes:
    assert x in revised,x
    revised=revised.replace(x,y)
compile(revised,str(new/'prepare.py'),'exec')
new.mkdir()
(new/'prepare-cpu4.py').write_text(original)
(new/'prepare.py').write_text(revised)
(new/'cpu-scheduling-revision.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),revised.splitlines(True),fromfile=str(old/'prepare.py'),tofile=str(new/'prepare.py'))))
(new/'cpu-scheduling-revision.json').write_text(json.dumps({
 'status':'prepared_revision_not_executed','reason':'Root reserves CPUs1/2/4 for later sanitizer campaigns; correctness lane moves4→5 before any gate execution.',
 'original_directory':str(old),'new_directory':str(new),'original_files_sha256':before,
 'changes':changes,'output_identity':'R derives from __file__; new artifacts use the separate CPU5 directory. All runtime/source/library/fixture/bounds/cleanup choices remain identical.',
 'preparer_sha256':h(new/'prepare.py'),'prior_preparer_sha256':h(old/'prepare.py'),
},indent=2)+'\n')
assert all(h(Path(p))==v for p,v in before.items())
print(json.dumps({'status':'CPU5 preparer created; no gates executed','preparer_sha256':h(new/'prepare.py'),'revision_sha256':h(new/'cpu-scheduling-revision.json')}))
