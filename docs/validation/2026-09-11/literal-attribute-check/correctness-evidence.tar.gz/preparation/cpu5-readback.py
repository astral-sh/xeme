"""Saved preparation comparison only; no gate execution."""
import difflib
import hashlib
import json
from pathlib import Path
O=Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates')
N=Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates-cpu5')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
j=lambda p:json.loads(Path(p).read_text())
old=j(O/'preparation.json');new=j(N/'preparation.json')
revision=j(N/'cpu-scheduling-revision.json')
changes=[(str(O),str(N)),*revision['changes']]
patches=[]
names=[*old['controllers'],'malformed/malformed_probe.py']
for name in names:
    a=(O/name).read_text();expected=a
    for x,y in changes:expected=expected.replace(x,y)
    b=(N/name).read_text()
    assert expected==b,name
    compile(b,str(N/name),'exec')
    patches.append(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=str(O/name),tofile=str(N/name))))
for name in ['source.json','source.tar.gz','build.json','runtime-source.patch','tools/xml_abi.py',
             'end-lifecycle-final/SOURCE_REVIEW.md','end-oom-final/probe.c','end-oom-final/original-allocations.c',
             'end-oom-final/expat.h','malformed/original-malformed-probe.py']:
    assert (O/name).read_bytes()==(N/name).read_bytes(),name
assert old['libraries']==new['libraries']
assert old['source_runtime_delta']==new['source_runtime_delta']
assert old['prior_controllers']==new['prior_controllers']
assert old['candidate_source_manifest_sha256']==new['candidate_source_manifest_sha256']
for path,value in old['before'].items():
    newpath=path.replace(str(O),str(N))
    assert new['before'][newpath]==sha(newpath)
    if not path.startswith(str(O)+'/'):assert new['before'][newpath]==value
assert all(sha(p)==v for p,v in revision['original_files_sha256'].items())
(N/'cpu-scheduling-controllers.patch').write_text(''.join(patches))
report={'status':'prepared_readback_passed_not_executed','old_preparation_sha256':sha(O/'preparation.json'),
 'new_preparation_sha256':sha(N/'preparation.json'),'controller_revision_sha256':sha(N/'cpu-scheduling-controllers.patch'),
 'controller_sources':len(names),'original_source_and_fixtures_byte_exact':True,
 'original_CPU4_files_unchanged':len(revision['original_files_sha256']),
 'scope':'Only separate output root and CPU4-to-5 affinity/metadata constants differ. Source/library/baseline/fixtures/bounds/cleanup unchanged. No target execution.'}
(N/'cpu-scheduling-readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
