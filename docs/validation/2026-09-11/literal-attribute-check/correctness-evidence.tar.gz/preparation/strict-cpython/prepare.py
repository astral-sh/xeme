from pathlib import Path
import ast,difflib,hashlib,json,shutil
O=Path('/tmp/oriole-literal-attribute-strict-cpython-preparation');O.mkdir(exist_ok=False)
prior=Path('/tmp/oriole-current-thin-pgo-cpython-gates.py')
controller=Path('/tmp/oriole-literal-attribute-thin-pgo-cpython-gates.py')
output=Path('/tmp/oriole-literal-attribute-thin-pgo-cpython-gates')
assert not controller.exists() and not output.exists()
W=Path('/home/dev-user/code/oss/oriole-literal-attribute-check')
oldW=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')
P=Path('/tmp/oriole-literal-attribute-check-pgo-study')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={}
def pin(p):p=Path(p);h=sha(p);inputs[str(p)]=h;return h
text=prior.read_text();old=text
replacements={
 str(oldW):str(W),
 '/tmp/oriole-current-thin-pgo-cpython-gates':'/tmp/oriole-literal-attribute-thin-pgo-cpython-gates',
 '/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use/liboriole_expat.so':'/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.so',
 '4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02':'8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a',
 '8b6ca03e6fd4be81aba81cccf10b4aa2d67e16586010477cba1e8f23a4dec97d':'a294cbd13adbb0af5eaa3722178690374df1b96eda5613c89461f575aa6fa643',
 '/tmp/oriole-native-byte-count-pgo-study/source.json':str(P/'source.json'),
 "['taskset', '-c', '4', python":"['taskset', '-c', '5', python",
 'CPU4, shared host.':'CPU5, shared host.',
}
for a,b in replacements.items():
 assert a in text,a
 text=text.replace(a,b)
ast.parse(text)
# Exact independent inverse confirms no other source difference.
restored=text
for a,b in reversed(list(replacements.items())):restored=restored.replace(b,a)
assert restored==old
controller.write_text(text)
shutil.copyfile(prior,O/'original-controller.py');shutil.copyfile(controller,O/'controller.py')
(O/'controller.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile=str(prior),tofile=str(controller))))
pin(prior);pin(controller);pin(P/'source.json');pin(P/'pair-freeze.json')
source=json.loads((P/'source.json').read_text())['source_sha256'];assert len(source)==70
for n,h in source.items():assert pin(W/n)==h
for n in ('liboriole_expat.so','liboriole_expat.a'):
 path=P/'pgo/runs/run-_j_96iq1/use'/n;pin(path)
for p in sorted((W/'tools/cpython').iterdir()):
 if p.is_file():assert pin(p)==pin(oldW/'tools/cpython'/p.name)
C=Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13')
for p in [C/'Modules/pyexpat.c',C/'Modules/_elementtree.c',*[C/'Lib/test'/('test_'+n+'.py') for n in ('pyexpat','xml_etree','xml_etree_c','minidom','sax','pulldom')]]:pin(p)
assert '--allow-text-fragmentation' not in text and '--consumer-fix' not in text and '--system-allocator' not in text and '--tests' not in text
assert "['taskset', '-c', '5', python" in text and "['taskset', '-c', '4', python" not in text
assert all(sha(p)==h for p,h in inputs.items())
receipt={'status':'prepared_only','target_execution':False,'controller':{'path':str(controller),'sha256':sha(controller)},'prior_controller':{'path':str(prior),'sha256':sha(prior)},'output':str(output),'source_manifest_sha256':sha(P/'source.json'),'candidate_libraries':{n:sha(P/'pgo/runs/run-_j_96iq1/use'/n) for n in ('liboriole_expat.so','liboriole_expat.a')},'changes':'Only worktree/output/source/library paths and library hashes, CPU4 to CPU5 affinity/scope. All executable flow and cleanup inherited exactly.','expected_scope':'Two fresh unmodified shared/static CPython 3.12.13 extension sets; original six strict modules; no consumer fix, fragmentation acceptance, alternate allocator or filtered tests. Historical baseline is 802 tests each with two failures, 14 reported skips and three expected failures, but exact method/outcome audit is required after any future run.','bounds':{'cpu':5,'module_seconds':120,'test_runner_seconds':900,'outer_per_linkage_seconds':1200},'failure_scope':'Prior exact-exit2 assertion retained; unexpected status including all-pass is saved and stops the controller, rather than silently forcing parity. Process-group kill/reap and raw output retention unchanged.','prerequisite':'Root controller review and explicit scheduling required before execution. No output directory exists.','limitations':'Strict runner pins copied library bytes and verifies extension imports/aliases; this inherited strict runner does not make an XML_Parse dladdr assertion. It is separate from benchmark canonical-output checks.','input_hashes':inputs}
(O/'preparation.json').write_text(json.dumps(receipt,indent=2)+'\n')
shutil.copyfile(__file__,O/'prepare.py')
print(json.dumps({'controller':sha(controller),'preparation':sha(O/'preparation.json'),'patch':sha(O/'controller.patch'),'inputs':len(inputs),'output_absent':not output.exists()}))
