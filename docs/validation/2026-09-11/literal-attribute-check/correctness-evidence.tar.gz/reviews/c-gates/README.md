# Literal-attribute ThinPGO C-gate audit

**Passed on the first attempt.** The completed CPU 5 gates preserve the current ThinPGO baseline observations. Candidate `8cc1c414…` / `a294cbd1…`, baseline `4f1518fc…` / `8b6ca03e…`, and source `1120c74e…` verify against saved bindings. All 117 prepared inputs and 70 live source files remain unchanged.

| Saved evidence | Independently checked outcome |
| --- | --- |
| Original API | All 4,740 log rows match baseline: 4,347 pass, 393 fail, raw exit 1; original 3 s / 1 GiB / 768 MiB / 240 s limits |
| Native C consumers | Six builds/runs pass; 327 allocation scenarios per linkage |
| Strict differential | 3,318 full paired traces match |
| Custom aliases | 36,456 comparisons: source/count/hash/command/difference-summary evidence verified |
| Malformed XML | 2,392 full pairs match; every input hash, encoding and chunk reconstructed |
| Publication | 1,304 cases / 3,912 parser executions; complete baseline observations match |
| End lifecycle / OOM | 38 cases / 114 parser executions; six OOM scenarios per engine, exact retained rows and retry-error 33 |

The 393 original API failures remain. Successful custom-alias raw pairs were not retained by the inherited helper, so no reread of those pairs is claimed. Only the C consumers are sanitizer-instrumented; optimized Rust is not, and leak checks are disabled. Reference callback-position and End differences remain unchanged. This establishes the recorded baseline parity, not blanket Expat equivalence or full compatibility.

The complete prior raw reader was reused with only child CPU constants changed to 5; current source/identity checks and summary metadata are handled separately. Three lanes complete sequentially, with the reviewed limits, cleanup, classifier order and End helpers intact. The audit made 15,801 assertions over 343 inspected files; all inspected bytes remained unchanged.

This was saved-data Python on CPU 6 only. No target, parser, compiler, profiler, test or timing jobs ran. No package/archive audit, strict CPython result, normal-workspace result or adoption decision is claimed. Summary identity: `81fe6a43daff9c46d99c1adc69a5c14e03f1d386ab63a0748a58dbb4e8045b14`.
