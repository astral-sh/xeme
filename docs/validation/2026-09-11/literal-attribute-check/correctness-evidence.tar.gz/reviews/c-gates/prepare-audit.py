"""Prepare saved-data reader source only; never run it before completion notice."""
from pathlib import Path
import difflib,hashlib,json
O=Path(__file__).resolve().parent
prior=Path('/tmp/oriole-current-thin-pgo-gates-independent-review/generator.py');old=prior.read_text()
head=old[:old.index("S=Path('/tmp/oriole-native-byte-count-pgo-study')")]
head=head.replace("R = Path('/tmp/oriole-current-thin-pgo-gates')","R = Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates-cpu5')")
head=head.replace("W = Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')","W = Path('/home/dev-user/code/oss/oriole-literal-attribute-check')")
head=head.replace("L = Path('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use')","L = Path('/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use')")
head=head.replace("B = Path('/tmp/oriole-native-byte-count-thinlto-study')","B = Path('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use')")
head=head.replace('== [4]','== [6]').replace('cpu=1','cpu=5')
core=old[old.index("A=R/'api-native'"):old.index("\nclassification=j(R/'publication-probe/reference-classification.json')")]
adapted=core.replace('cpu=1','cpu=5').replace("data['affinity']==[1]","data['affinity']==[5]").replace("['taskset','-c','1']","['taskset','-c','5']")
new=head+(O/'setup.py').read_text()+adapted+(O/'tail.py').read_text()
(O/'generator.py').write_text(new)
(O/'core-adaptation.patch').write_text(''.join(difflib.unified_diff(core.splitlines(True),adapted.splitlines(True),fromfile='prior-complete-raw-core',tofile='literal-attribute-complete-raw-core')))
(O/'method.json').write_text(json.dumps({'prior_generator':str(prior),'prior_generator_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'generator_sha256':hashlib.sha256(new.encode()).hexdigest(),'method':'Complete prior API/native/strict/alias/malformed/publication/End saved-data core reused; only checked child CPU1→5 constants change. Current identities/preparation and final source label handled separately. No target calls.'},indent=2)+'\n')
