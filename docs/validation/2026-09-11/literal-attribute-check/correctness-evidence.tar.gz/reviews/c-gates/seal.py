from pathlib import Path
import gzip,hashlib,json,os
R=Path(__file__).resolve().parent
assert __debug__ and os.sched_getaffinity(0)=={6}
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
review=json.loads((R/'review.json').read_text());attempt=json.loads((R/'attempt01.json').read_text())
assert attempt['returncode']==0 and attempt['generator_sha256']==review['generator_sha256']==h(R/'generator.py')
for p,v in json.loads(gzip.decompress((R/'checked-files.json.gz').read_bytes())).items():assert h(Path(p))==v
receipt={'status':'passed','review_sha256':h(R/'review.json'),'generator_sha256':h(R/'generator.py'),'summary_sha256':review['summary_sha256'],'checks':review['passed_checks'],'checked_files':review['checked_files'],'attempts':1,'scope':'Saved raw gate/source binding audit; no target or package execution.'}
(R/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
index={str(p.relative_to(R)):{'sha256':h(p),'bytes':p.stat().st_size} for p in sorted(R.rglob('*')) if p.is_file() and p.name!='files.json'}
(R/'files.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
for n,v in index.items():assert (R/n).stat().st_size==v['bytes'] and h(R/n)==v['sha256']
print(json.dumps({'indexed_files':len(index),'review':h(R/'review.json'),'receipt':h(R/'receipt.json'),'index':h(R/'files.json')},indent=2))
