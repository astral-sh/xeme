S=Path('/tmp/oriole-literal-attribute-check-pgo-study')
BASE=Path('/tmp/oriole-native-byte-count-pgo-study')
prior_root=Path('/tmp/oriole-current-thin-pgo-gates')
pins=j(O/'final-inputs.json')
ck('completion authorized audit pin',pins['completion_notified'] is True)
source=j(R/'source.json');preparation=j(R/'preparation.json');build=j(R/'build.json');summary=j(R/'summary.json')
reviews={
 '/tmp/oriole-current-thin-pgo-gates-independent-review/review.json':'57db9323050ba4910ff46fbc8c7321e2430b03bfeac00f7675bc380ca9b91e63',
 '/tmp/oriole-literal-attribute-check-build-independent-review/review.json':'51b5001bfcfab7c08efc2b52d33d16d1eaf96a88e541d66fe781327075e947e8',
 '/tmp/oriole-literal-attribute-gate-cpu5-independent-review/review.json':'e44cd7baba0f36ca34c065a2793a7a5add279566a5e9e49fdf3578f5e65a9152'}
for path,value in reviews.items():ck('sealed prerequisite '+path,h(path)==value)
ck('completed summary pinned',h(R/'summary.json')==pins['summary_sha256'])
ck('reviewed CPU5 preparation pinned',h(R/'preparation.json')=='d89b959a8aa3137d51b920dd8aa2f8f84b7b0a5e365721ed8a929028f6b06363' and h(R/'cpu-scheduling-controllers.patch')=='348b0843c3fd9eb539c2d50ec18c2de73278b619daa31c90c317e29bbdb1d2e6')
prepared_review=j('/tmp/oriole-literal-attribute-gate-cpu5-independent-review/review.json')
ck('reviewed CPU5 preparer unchanged',h(R/'prepare.py')==prepared_review['cpu5_preparer_sha256'])
ck('source70 exact',len(source['source_sha256'])==70 and h(R/'source.json')==h(S/'source.json')==build['source_manifest_sha256']=='1120c74e96c7f562cecfa25db227a830e8a1667a67dba30732ca039fb5e7dbec')
ck('only tag runtime delta',[n for n,v in source['source_sha256'].items() if v!=j(BASE/'source.json')['source_sha256'][n]]==summary['source']['changed_files_from_control']==preparation['source_runtime_delta']==['crates/oriole/src/tag.rs'])
ck('all70 live source hashes',all(h(W/n)==v for n,v in source['source_sha256'].items()))
ck('source and patch copies exact',read(R/'source.tar.gz')==read(S/'source.tar.gz') and read(R/'runtime-source.patch')==read(S/'candidate.patch'))
expected_libraries={'liboriole_expat.so':'8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a','liboriole_expat.a':'a294cbd13adbb0af5eaa3722178690374df1b96eda5613c89461f575aa6fa643'}
normal_libraries={'liboriole_expat.so':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','liboriole_expat.a':'8b6ca03e6fd4be81aba81cccf10b4aa2d67e16586010477cba1e8f23a4dec97d'}
ck('current build alias exact',read(R/'build.json')==read(S/'pair-report.json') and build['status']=='passed' and build['source_unchanged'] and {n:build['pgo_libraries']['use/'+n] for n in expected_libraries}==expected_libraries)
for root,mapping in [(L,expected_libraries),(B,normal_libraries)]:ck('current library bytes '+str(root),all(h(root/n)==v for n,v in mapping.items()))
ck('117 prepared inputs unchanged',len(preparation['before'])==117 and hashes(preparation['before']))
for name,value in preparation['controllers'].items():ck('reviewed generated controller unchanged '+name,h(R/name)==value)
for lane,names in [('api',['api_native.py']),('other',['other_controls.py','run_publication.py','run_malformed.py','classify_observations.py']),('end',['end-lifecycle-final/controller.py','end-oom-final/run.py'])]:
 report=j(R/(lane+'-controller.json'))
 ck('successful lane and stable inputs '+lane,report['status']=='completed_zero_exits' and report['unchanged'] and report['before']==report['after']==preparation['before'] and not report['hash_errors'] and report['cpu']==5 and [r['script'] for r in report['jobs']]==names)
 for row in report['jobs']:
  ck('bounded successful launch '+row['script'],row['exit']==0 and row['timeout']==660 and 'exception' not in row and row['command']==['taskset','-c','5','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S',str(R/row['script'])] and h(R/row['script'])==row['sha256'] and 0<row['end']-row['start']<660)
  for stream in ['stdout','stderr']:ck('lane stream '+row['script']+stream,h(R/(row['script'].replace('/','-')+'.'+stream))==row[stream+'_sha256'])
  ck('empty child stderr '+row['script'],read(R/(row['script'].replace('/','-')+'.stderr'))==b'')
 ck('sequential jobs within lane '+lane,all(a['end']<=b['start'] for a,b in zip(report['jobs'],report['jobs'][1:])))
lanes=[j(R/(n+'-controller.json')) for n in ['api','other','end']]
ck('three lanes sequential',all(a['jobs'][-1]['end']<=b['jobs'][0]['start'] for a,b in zip(lanes,lanes[1:])))
