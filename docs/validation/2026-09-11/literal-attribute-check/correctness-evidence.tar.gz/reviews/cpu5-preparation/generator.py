"""Saved CPU5 preparation readback only; never invoke producer or target code."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
O=Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates')
N=Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates-cpu5')
PRIOR=Path('/tmp/oriole-literal-attribute-gate-preparation-readback')
inputs={};checks=0
def check(v,label):
    global checks
    assert v,label
    checks+=1
def read(p):
    p=Path(p);b=p.read_bytes();v={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
    check(str(p) not in inputs or inputs[str(p)]==v,'input stable '+str(p));inputs[str(p)]=v;return b
def sha(p):read(p);return inputs[str(p)]['sha256']
def js(p):return json.loads(read(p))
def put(n,d):(OUT/n).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
check(sha(PRIOR/'review.json')=='d30f343a018d9b13458bdcacb63cfb5ce8ece38b9d74d13946e7e605eb5f5dea','CPU4 review')
check(sha(O/'preparation.json')=='32bb5070992ae5e01fc7b484e3400244d74d8fd5527b4672b0e150dd9cd3f04f','CPU4 preparation')
check(sha(N/'preparation.json')=='d89b959a8aa3137d51b920dd8aa2f8f84b7b0a5e365721ed8a929028f6b06363','CPU5 preparation')
check(sha(N/'cpu-scheduling-controllers.patch')=='348b0843c3fd9eb539c2d50ec18c2de73278b619daa31c90c317e29bbdb1d2e6','CPU5 controller patch')
old=js(O/'preparation.json');new=js(N/'preparation.json');revision=js(N/'cpu-scheduling-revision.json')
expected_changes=[
 ["'taskset','-c','4'", "'taskset','-c','5'"],
 ["'taskset', '-c', '4'", "'taskset', '-c', '5'"],
 ['os.sched_getaffinity(0)=={4}', 'os.sched_getaffinity(0)=={5}'],
 ["cpu={'api':4,'other':4}", "cpu={'api':5,'other':5}"],
 ["cpu={'end':4}", "cpu={'end':5}"],
 ["'cpu': 4", "'cpu': 5"],
 ['os.sched_getaffinity(0)) == [4]', 'os.sched_getaffinity(0)) == [5]'],
 ["report['affinity'] == [4]", "report['affinity'] == [5]"],
 ['CPU4','CPU5'],['CPU1-to-4','CPU1-to-5']]
check(revision['changes']==expected_changes,'only ten specified scheduling substitutions')
def transform(s,root=True):
    if root:s=s.replace(str(O),str(N))
    for a,b in expected_changes:s=s.replace(a,b)
    return s
check(read(N/'prepare-cpu4.py')==read(O/'prepare.py'),'retained prior preparer')
check(read(N/'prepare.py').decode()==transform(read(O/'prepare.py').decode(),False),'preparer exact ten substitutions')
check(sha(N/'prepare.py')==revision['preparer_sha256'] and sha(O/'prepare.py')==revision['prior_preparer_sha256'],'preparer pins')
check(len(revision['original_files_sha256'])==35,'original file count')
check({str(p) for p in O.rglob('*') if p.is_file()}==set(revision['original_files_sha256']),'original file inventory')
for p,v in revision['original_files_sha256'].items():check(sha(p)==v,'original CPU4 file unchanged '+p)
names=[*old['controllers'],'malformed/malformed_probe.py'];check(len(names)==14,'13 controllers plus malformed source')
patch=[];identities=[]
for name in names:
    a=read(O/name).decode();b=read(N/name).decode();check(transform(a)==b,'exact scheduling source delta '+name)
    patch.extend(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=str(O/name),tofile=str(N/name)))
    if name in new['controllers']:check(sha(N/name)==new['controllers'][name],'controller binding '+name)
    for node in ast.walk(ast.parse(b)):
        if isinstance(node,ast.List) and len(node.elts)>=3 and all(isinstance(x,ast.Constant) for x in node.elts[:3]):
            if [x.value for x in node.elts[:2]]==['taskset','-c']:check(node.elts[2].value=='5','CPU5 argv '+name)
    identities.append({'name':name,'cpu4_sha256':sha(O/name),'cpu5_sha256':sha(N/name)})
check(''.join(patch)==read(N/'cpu-scheduling-controllers.patch').decode(),'full scheduling patch')
fixtures=['source.json','source.tar.gz','build.json','runtime-source.patch','tools/xml_abi.py','end-lifecycle-final/SOURCE_REVIEW.md','end-oom-final/probe.c','end-oom-final/original-allocations.c','end-oom-final/expat.h','malformed/original-malformed-probe.py']
for name in fixtures:check(read(O/name)==read(N/name),'byte-exact source/fixture '+name)
check(len(old['before'])==len(new['before'])==117,'117 bindings')
check({p.replace(str(O),str(N)) for p in old['before']}==set(new['before']),'same mapped binding keys')
for p,v in old['before'].items():
    q=p.replace(str(O),str(N));check(sha(q)==new['before'][q],'CPU5 current binding '+q)
    if not p.startswith(str(O)+'/'):check(new['before'][q]==v,'external binding exact '+p)
for k in ['libraries','candidate_library_directory','baseline_library_directory','candidate_source_manifest_sha256','source_runtime_delta','baseline_rationale','scope','limitations','prior_controllers','status']:
    check(old[k]==new[k],'unchanged preparation metadata '+k)
for k in ['execution','adaptation']:check(transform(old[k])==new[k],'scheduling metadata '+k)
check([[transform(x),transform(y)] for x,y in old['replacements']]==new['replacements'],'preparer substitutions remain bounded')
for p,v in js(N/'malformed/preparation.json')['hashes'].items():check(sha(p)==v,'malformed preparation binding '+p)
check(read(N/'prepare-malformed.stdout')==read(N/'prepare-malformed.stderr')==b'','source-only helper empty streams')
log=read(N/'prepare-attempt-01.log').decode();check('prepared_not_executed' in log and sha(N/'preparation.json') in log,'saved preparation completion')
author=js(N/'cpu-scheduling-readback.json');check(author['new_preparation_sha256']==sha(N/'preparation.json') and author['controller_revision_sha256']==sha(N/'cpu-scheduling-controllers.patch'),'author readback identities')
read('/tmp/oriole-prepare-literal-gates-cpu5.py');read('/tmp/oriole-check-literal-gates-cpu5-revision.py')
absent=['api-controller.json','other-controller.json','end-controller.json','summary.json','api-native','other-gates','publication-probe','publication-launch','malformed/launch.json','end-lifecycle-final/controller.json','end-oom-final/report.json']
check(all(not (N/p).exists() for p in absent),'no CPU5 target result artifacts at readback')
for p,v in list(inputs.items()):check(sha(p)==v['sha256'],'final unchanged input '+p)
review={'status':'passed','scope':'Independent saved source/identity comparison of prepared CPU5 revision. No producer, preparer, gate, compiler or parser executed.',
 'prior_cpu4_review_sha256':sha(PRIOR/'review.json'),'cpu4_preparation_sha256':sha(O/'preparation.json'),'cpu5_preparation_sha256':sha(N/'preparation.json'),'cpu5_controller_revision_sha256':sha(N/'cpu-scheduling-controllers.patch'),'cpu5_preparer_sha256':sha(N/'prepare.py'),
 'counts':{'controllers':13,'generated_malformed_sources':1,'byte_exact_source_and_fixture_copies':10,'original_cpu4_files_unchanged':35,'before_bindings':117},
 'conclusion':'Every generated controller and malformed source equals frozen CPU4 after only output-root and explicit CPU4-to-5 substitutions. Fixtures, source, libraries, baseline, assertions, limits, order and process cleanup remain unchanged.',
 'libraries':new['libraries'],'source_manifest_sha256':new['candidate_source_manifest_sha256'],
 'target_result_artifacts_absent_at_readback':absent,'all_inspected_inputs_unchanged':True,'input_files':len(inputs),'checks':checks,
 'limitations':['Preparation-only identity receipt; no gate outcome or scheduling authorization. Root owns any future launch.','Earlier compiler/source proofs and CPU4 controller semantics are reused by hash; no repeated target tests.','Existing custom-success raw-pair, optimized-Rust sanitizer, original API393 failure and reference-position limitations remain.'], 'findings':[]}
put('review.json',review);put('controller-identities.json',identities);put('inputs.json',inputs)
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'input_files':len(inputs),'checks':checks}))
