# Literal-attribute strict CPython audit

**Saved-result audit passed on the first attempt.** Shared and static linkages each retain all 802 method statuses exactly as in the accepted current ThinPGO baseline. Both still exit 2 with the same two ordinary-text fragmentation failures; this is parity, not a fully passing suite.

Full failure bodies match after normalizing only source-path prefixes. All 14 reported skip lines match: five whole methods, eight subtests and one class setup. Three expected failures are separate. All three accelerator import test methods pass in each linkage.

All four saved successful compiler vectors equal the baseline vectors after private path changes. Both copied `pyexpat.c` sources and upstream `_elementtree.c` match; all six test modules and six tooling files verify. Eight initial/fresh extension origin records bind the saved extension bytes. All 96 prepared inputs and 70 runtime source hashes remain intact; 141 inspected files are unchanged.

The strict runner checks extension import/alias origins and exact library copies. It does **not** make an `XML_Parse` dladdr assertion. Compile commands come from the successful pinned runner's summaries; compiler stdout/stderr logs are empty and retained. No independent compiler trace is claimed.

Prepared controller `f4effad3…` ran shared then static on CPU 5 with the original 120 / 900 / 1,200-second bounds. This review used saved-file Python on CPU 6 only; no controller, compiler, parser or test jobs ran. Method maps, failure bodies, skips, commands, origins and input hashes are retained compressed. No package audit or adoption decision is included.
