"""Read saved canonical API and original CPython outcomes without executing tests."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,os,gzip
assert __debug__ and os.sched_getaffinity(0)=={6}
OUT=Path(__file__).parent
G=Path('/tmp/oriole-literal-attribute-thin-pgo-cpython-gates')
W=Path('/home/dev-user/code/oss/oriole-literal-attribute-check')
hashes={}
def read(p):
 p=Path(p);d=p.read_bytes();h=hashlib.sha256(d).hexdigest();assert hashes.setdefault(str(p),h)==h;return d
def sha(p):read(p);return hashes[str(Path(p))]
def load(p):return json.loads(read(p))
controller=load(G/'controller.json')
for p,h in controller['libraries'].items():assert sha(p)==h
assert len(controller['jobs'])==2
for job in controller['jobs']:
 assert job['exit']==job['expected_exit']==2
 assert not any(a in job['command'] for a in ['--allow-text-fragmentation','--consumer-fix'])
 assert sha(G/(job['linkage']+'.log'))==job['log_sha256']
def methods(path):
    output={};pending=None;subtests=[]
    def add(item,status):
        name,identifier=item
        if name=='setUpClass':return
        assert name.startswith('test') and identifier not in output
        output[identifier]=status
    for line in read(path).decode().splitlines():
        m=re.match(r'^(\w+) \((test\.[^)]+)\)(?: \.\.\. (.*))?$',line)
        if m:
            if pending is not None:
                assert any(f'{pending[0]} ({pending[1]}) ' in t for t in subtests);add(pending,'subtest outcomes')
            pending=(m[1],m[2]);status=m[3]
            if status:add(pending,status);pending=None
        elif pending is not None:
            if re.match(r'^(ok|FAIL|ERROR|expected failure|skipped .+)$',line):add(pending,line);pending=None
            elif line.startswith('  ') and ' ... ' in line:subtests.append(line)
            elif ' ... ' in line and line.rsplit(' ... ',1)[1]:add(pending,line.rsplit(' ... ',1)[1]);pending=None
    assert pending is None
    return output

expected_failures=['test.test_pyexpat.BufferTextTest.test1','test.test_sax.CDATAHandlerTest.test_handlers']
baseline_methods=methods('/tmp/oriole-current-thin-pgo-cpython-gates/shared/tests.log')
python={}
for linkage in ['shared','static']:
    p=G/linkage;summary=load(p/'summary.json');origin=load(p/'origin.log')
    assert summary['linkage']==linkage and summary['tests_exit_code']==summary['gate_exit_code']==2
    assert summary['probe_exit_code']==summary['origin_exit_code']==0 and summary['consumer_fix'] is None and summary['consumer_adaptation'] is None and summary['text_fragmentation'] is None
    assert summary['cpython_revision']=='3bb231a6a5dc02b95658877318bf61501a7209e9'
    assert summary['source_sha256']==summary['compiled_source_sha256']==sha(p/'pyexpat.c')==sha('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Modules/pyexpat.c')
    suffix='so' if linkage=='shared' else 'a';assert sha(p/('liboriole_expat.'+suffix))==summary['library_sha256']==controller['libraries']['/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.'+suffix]
    assert summary['loader_sha256']==sha(p/'sitecustomize.py')==sha(W/'tools/cpython/extension_loader.py')
    assert summary['import_check_sha256']==sha(W/'tools/cpython/check_extension_imports.py')
    assert origin['status']=='passed' and origin['accelerator_imports']==['cET','cET_alias'] and origin['pure_python_and_blocked_imports']=='passed' and len(origin['origins'])==4
    for entry in origin['origins'].values():assert Path(entry['path']).parent==p and sha(entry['path'])==entry['sha256']
    rows=methods(p/'tests.log');assert len(rows)==802 and rows==baseline_methods
    assert sorted(k for k,v in rows.items() if v in ['FAIL','ERROR'])==expected_failures
    assert sum(v.startswith('skipped') for v in rows.values())==5 and sum(v=='expected failure' for v in rows.values())==3
    skip=[l for l in read(p/'tests.log').decode().splitlines() if ' ... skipped ' in l]
    assert len(skip)==14 and sum(l.startswith('  ') for l in skip)==8 and sum(l.startswith('setUpClass') for l in skip)==1
    for name in ['test_correct_import_cET','test_correct_import_cET_alias','test_parser_comes_from_C']:assert rows['test.test_xml_etree_c.TestAcceleratorImported.'+name]=='ok'
    for name in ['probe.log','pyexpat-build.log','_elementtree-build.log']:read(p/name)
    python[linkage]={'methods':802,'failures':expected_failures,'expected_failures':3,'reported_skips':14,'whole_method_skips':5,'subtest_skips':8,'class_setup_skips':1,'all_method_statuses_equal_corrected_baseline':True}
old_cpython=load('/tmp/oriole-pbs-version-followup/report.json')['test_count_and_coverage']['upstream_six_module_hashes_exact']
for name,h in old_cpython.items():assert sha(Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Lib/test')/(name+'.py'))==h
read(W/'tools/cpython/run.py');read(W/'tools/cpython/text_fragmentation.py')


# Require exact full method maps and failure identity against both prior linkage outputs.
for linkage in ['shared','static']:
 assert methods(G/linkage/'tests.log')==methods(Path('/tmp/oriole-current-thin-pgo-cpython-gates')/linkage/'tests.log')
 sha(G/linkage/'summary.json')
for name in ['oriole-literal-attribute-thin-pgo-cpython-gates.py']:read(G/name)
# The current published harness is unmodified; persistent imports remain enabled.
for name in ['run.py','extension_loader.py','check_extension_imports.py']:
 assert read(W/'tools/cpython'/name)==read(Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo/tools/cpython')/name)
if not __debug__:raise RuntimeError('assertions required')
pair_source=load('/tmp/oriole-literal-attribute-check-pgo-study/source.json')
assert controller['status']=='completed_with_failures_retained_pending_outcome_audit'
assert controller['source_sha256']==pair_source['source_sha256'] and len(controller['source_sha256'])==70
for name,h in controller['source_sha256'].items():assert sha(W/name)==h
pair_review=load('/tmp/oriole-literal-attribute-check-build-independent-review/review.json')
assert sha('/tmp/oriole-literal-attribute-check-build-independent-review/review.json')=='51b5001bfcfab7c08efc2b52d33d16d1eaf96a88e541d66fe781327075e947e8'
assert controller['libraries']=={
 '/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.so':'8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a',
 '/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.a':'a294cbd13adbb0af5eaa3722178690374df1b96eda5613c89461f575aa6fa643'}
failure_blocks={};method_maps={};skip_lines={};source_inputs={}
def failures(path):
 text=read(path).decode()
 blocks=re.findall(r'^FAIL: .*?(?=^-{70}\nRan )',text,re.M|re.S)
 blocks=[re.sub(r'File "[^"]*/pyexpat\.c"','File "<PYEXPAT_SOURCE>"',s) for s in blocks]
 return [re.sub(r'File "[^"]*/Lib/','File "<CPYTHON_LIB>/',s) for s in blocks]
for linkage in ['shared','static']:
 p=G/linkage;summary=load(p/'summary.json');job=next(j for j in controller['jobs'] if j['linkage']==linkage)
 assert job['command'][:3]==['taskset','-c','5'] and job['timeout_seconds']==1200
 assert not job.get('exception') and 0<job['end']-job['start']<1200
 assert summary['test_command'][1:8]==['-s','-m','test','-v','-j1','--timeout','120']
 assert summary['test_command'][8:]==['test_pyexpat','test_xml_etree','test_xml_etree_c','test_minidom','test_sax','test_pulldom']
 assert len(summary['commands'])==2
 for module,command in zip(['pyexpat','_elementtree'],summary['commands'],strict=True):
  assert command[:4]==['cc','-shared','-fPIC','-O2'] and command[-2]=='-o'
  assert Path(command[-1]).parent==p and Path(command[-1]).name.startswith(module+'.cpython-312-')
  assert '-Wl,-rpath,'+str(p) in command
  source=next(x for x in command if x.endswith('/'+('pyexpat.c' if module=='pyexpat' else '_elementtree.c')))
  source_inputs[source]=sha(source)
  if module=='_elementtree':assert sha(source)==sha('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Modules/_elementtree.c')
  if linkage=='static':assert [x for x in command if x.startswith('-l')]==['-lgcc_s','-lutil','-lrt','-lpthread','-lm','-ldl','-lc']
 probe=read(p/'probe.log').decode().splitlines()
 assert probe==[str(p/'pyexpat.cpython-312-x86_64-linux-gnu.so'),str(p/'_elementtree.cpython-312-x86_64-linux-gnu.so'),'oriole_compat_2.8.4']
 old=Path('/tmp/oriole-current-thin-pgo-cpython-gates')/linkage/'tests.log'
 failure_blocks[linkage]=failures(p/'tests.log')
 assert len(failure_blocks[linkage])==2 and failure_blocks[linkage]==failures(old)
 method_maps[linkage]=methods(p/'tests.log')
 skip_lines[linkage]=[l for l in read(p/'tests.log').decode().splitlines() if ' ... skipped ' in l]
 assert skip_lines[linkage]==[l for l in read(old).decode().splitlines() if ' ... skipped ' in l]
 assert 'Total tests: run=802 failures=2 skipped=14' in read(p/'tests.log').decode()
assert method_maps['shared']==method_maps['static']
# Capture unchanged helper source and exact outer bounds/cleanup source.
for name in ['run.py','extension_loader.py','check_extension_imports.py','text_fragmentation.py']:source_inputs[str(W/'tools/cpython'/name)]=sha(W/'tools/cpython'/name)
outer=read(G/'oriole-literal-attribute-thin-pgo-cpython-gates.py').decode()
for token in ['process.wait(timeout=1200)','start_new_session=True','os.killpg(process.pid, signal.SIGKILL)',"item['exit'] = process.wait()"]:assert token in outer
assert 'timeout=900' in read(W/'tools/cpython/run.py').decode()
# Exact linkage/source/controller provenance beyond the unchanged outcome reader.
PREP=Path('/tmp/oriole-literal-attribute-strict-cpython-preparation')
PRIOR=Path('/tmp/oriole-current-thin-pgo-cpython-gates')
oldW=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')
assert sha('/tmp/oriole-current-thin-pgo-cpython-independent-review/review.json')=='7b8b055505931c115a5d315268c8b5571518fc794601281052ee865261e736c2'
assert sha('/tmp/oriole-literal-attribute-strict-controller-independent-review/review.json')=='b191359db75929c0969eb12b357b5d7fc606ea9a04d5589711cd772d1491be24'
assert sha(PREP/'preparation.json')=='0c9daf418a9f05fb1182c3227387c4efc6d604c126e1a542377b91f24f96ea23'
prep=load(PREP/'preparation.json')
assert len(prep['input_hashes'])==96
for path,value in prep['input_hashes'].items():assert sha(path)==value,path
assert read(G/'oriole-literal-attribute-thin-pgo-cpython-gates.py')==read(prep['controller']['path'])==read(PREP/'controller.py')
assert sha(prep['controller']['path'])=='f4effad366ccbcd7490a257ce150fa747ae5eab6d76d06282541cda56ed6b636'
assert [j['linkage'] for j in controller['jobs']]==['shared','static']
assert controller['jobs'][0]['end']<=controller['jobs'][1]['start']
assert read('/tmp/oriole-literal-attribute-thin-pgo-cpython-launch.log')==b'shared 2\nstatic 2\n'
assert controller['source_sha256']==load('/tmp/oriole-literal-attribute-check-pgo-study/source.json')['source_sha256']
baseline_source=load('/tmp/oriole-native-byte-count-pgo-study/source.json')['source_sha256']
assert [n for n,v in controller['source_sha256'].items() if v!=baseline_source[n]]==['crates/oriole/src/tag.rs']
tool_names=['README.md','check_extension_imports.py','extension_loader.py','run.py','test_run.py','text_fragmentation.py']
for name in tool_names:assert read(W/'tools/cpython'/name)==read(oldW/'tools/cpython'/name)
def normalize(arg):return arg.replace(str(PRIOR),str(G)).replace(str(oldW),str(W))
compiler_vectors={};origin_records={}
for linkage in ['shared','static']:
 p=G/linkage;old=PRIOR/linkage;s=load(p/'summary.json');b=load(old/'summary.json')
 assert s['commands']==[[normalize(arg) for arg in command] for command in b['commands']]
 assert s['test_command']==b['test_command']
 assert s['origin_command']==[normalize(arg) for arg in b['origin_command']]
 assert s['python']==b['python'] and s['schema_version']==b['schema_version']
 for module in ['pyexpat','_elementtree']:assert read(p/(module+'-build.log'))==b''
 job=next(row for row in controller['jobs'] if row['linkage']==linkage)
 expected_command=['taskset','-c','5','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3','-I','-S',str(W/'tools/cpython/run.py'),'--source','/home/dev-user/.cache/oriole/upstream/cpython-3.12.13','--library','/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.'+('so' if linkage=='shared' else 'a'),'--output',str(p)]
 if linkage=='static':expected_command += [a for name in ['gcc_s','util','rt','pthread','m','dl','c'] for a in ['--native-library',name]]
 assert job['command']==expected_command
 compiler_vectors[linkage]=s['commands'];origin_records[linkage]=load(p/'origin.log')
 # Saved compiler summaries are produced only after both successful compile
 # calls by the pinned runner; the logs retain stdout/stderr, not command lines.
 assert 'commands.append(command)' in read(W/'tools/cpython/run.py').decode()
 assert 'if result.returncode:' in read(W/'tools/cpython/run.py').decode()
 assert 'return result.returncode' in read(W/'tools/cpython/run.py').decode()
method=load(OUT/'method.json')
assert sha(OUT/'audit.py')==method['audit_sha256'] and sha(method['prior_reader'])==method['prior_reader_sha256']
for name in ['prepare-audit.py','tail.py','adaptation.patch']:read(OUT/name)
for p,h in list(hashes.items()):assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
review={'status':'passed','scope':'Independent saved strict ThinPGO shared/static outcomes, sources, compiler vectors, method maps, failure bodies, skips and extension import origins. No target execution.','audit_cpu':6,
 'source_manifest_sha256':sha('/tmp/oriole-literal-attribute-check-pgo-study/source.json'),'source_base':'c1776c922b023a3558badfefa697cd11b0d37d8e','source_files':70,'runtime_delta':['crates/oriole/src/tag.rs'],'libraries':controller['libraries'],
 'prepared_controller_review_sha256':sha('/tmp/oriole-literal-attribute-strict-controller-independent-review/review.json'),'prior_accepted_strict_review_sha256':sha('/tmp/oriole-current-thin-pgo-cpython-independent-review/review.json'),'build_review_sha256':sha('/tmp/oriole-literal-attribute-check-build-independent-review/review.json'),'controller_sha256':sha(G/'controller.json'),
 'linkages':python,'compiler_vectors':'All four saved successful-runner vectors equal the prior currentThinPGO vectors after only worktree/output paths. Same cc/shared/fPIC/O2 flags, includes, native-library ordering and rpath. Build logs are empty and hashed; commands are retained by the pinned runner summary.',
 'source_and_imports':'Both copied pyexpat.c files exactly equal upstream source; _elementtree.c and all six upstream test module hashes verified. Six tool files unchanged. Four initial/fresh extension origins per linkage bind exact extension bytes; all three accelerator import test methods pass.',
 'outcome':'Each linkage retains all802 method statuses, the same two ordinary-text fragmentation failures, all failure diagnostic bodies after only source-path prefix normalization, and all14 skip lines exactly equal accepted currentThinPGO baseline.',
 'bounds':'CPU5;120 seconds per module,900 seconds runner,1200 seconds per outer linkage; sequential shared then static. Exact expectedexit2 and raw logs retained.',
 'limitations':['This is exact baseline parity, not a fully passing suite; two failures remain. Fourteen reported skips comprise five whole methods, eight subtests and one class setup. Three expected failures are separate.','Strict runner checks extension imports/aliases and exact copied libraries; no XML_Parse dladdr assertion.','Saved successful compiler commands and source flow are checked, but no independent compiler-invocation tracing or new compiler execution is claimed.','Source-path prefixes alone are normalized in failure bodies. Successful runs do not exercise timeout or signal cleanup.','Only this candidate ThinPGO shared/static strict scope; no normal/fat-PGO, PBS, sanitizer, fuzz, broad C-API or full-application claim.','No archive/package readback or adoption decision is included.'],
 'findings':[],'checked_files':len(hashes),'all_inspected_inputs_unchanged':True,'audit_sha256':method['audit_sha256']}
for name,value in [('methods.json.gz',method_maps),('failure-bodies.json.gz',failure_blocks),('skip-lines.json.gz',skip_lines),('source-inputs.json.gz',source_inputs),('checked-files.json.gz',hashes),('compiler-vectors.json.gz',compiler_vectors),('origins.json.gz',origin_records)]:
 (OUT/name).write_bytes(gzip.compress((json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'checked_files':len(hashes)}))
