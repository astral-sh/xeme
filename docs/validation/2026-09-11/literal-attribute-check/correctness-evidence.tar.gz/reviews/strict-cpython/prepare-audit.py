"""Assemble the saved strict-outcome reader; never invoke test/project tools."""
from pathlib import Path
import difflib,hashlib,json
O=Path(__file__).resolve().parent
prior=Path('/tmp/oriole-current-thin-pgo-cpython-independent-review/audit.py')
old=prior.read_text();core=old[:old.index('\nfor p,h in hashes.items():')]
changes=[
 ("G=Path('/tmp/oriole-current-thin-pgo-cpython-gates')","G=Path('/tmp/oriole-literal-attribute-thin-pgo-cpython-gates')"),
 ("W=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')","W=Path('/home/dev-user/code/oss/oriole-literal-attribute-check')"),
 ('/tmp/oriole-frame-integrated-gates/cpython-shared/tests.log','/tmp/oriole-current-thin-pgo-cpython-gates/shared/tests.log'),
 ("Path('/tmp/oriole-frame-integrated-gates')/('cpython-'+linkage)","Path('/tmp/oriole-current-thin-pgo-cpython-gates')/linkage"),
 ('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use','/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use'),
 ('/tmp/oriole-native-byte-count-pgo-study/source.json','/tmp/oriole-literal-attribute-check-pgo-study/source.json'),
 ('/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json','/tmp/oriole-literal-attribute-check-build-independent-review/review.json'),
 ('cec78c70730e111f139a6fab70089e1629ffe3336843106585a35922a525bbc9','51b5001bfcfab7c08efc2b52d33d16d1eaf96a88e541d66fe781327075e947e8'),
 ('4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a'),
 ('8b6ca03e6fd4be81aba81cccf10b4aa2d67e16586010477cba1e8f23a4dec97d','a294cbd13adbb0af5eaa3722178690374df1b96eda5613c89461f575aa6fa643'),
 ('oriole-current-thin-pgo-cpython-gates.py','oriole-literal-attribute-thin-pgo-cpython-gates.py'),
 ('/home/dev-user/code/oss/oriole-frame-integration/tools/cpython','/home/dev-user/code/oss/oriole-native-byte-count-pgo/tools/cpython'),
 ("['taskset','-c','4']","['taskset','-c','5']")]
new=core
for a,b in changes:
 assert a in new,a
 new=new.replace(a,b)
new=new.replace('import hashlib,json,re','import hashlib,json,re,os,gzip\nassert __debug__ and os.sched_getaffinity(0)=={6}')
new+='\n'+(O/'tail.py').read_text()
(O/'audit.py').write_text(new)
(O/'adaptation.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(prior),tofile=str(O/'audit.py'))))
(O/'method.json').write_text(json.dumps({'prior_reader':str(prior),'prior_reader_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'audit_sha256':hashlib.sha256(new.encode()).hexdigest(),'changes':changes,'scope':'Reuse complete methods/failure/skip/origin/source reader against accepted currentThinPGO baseline; add exact compiler-vector and preparation bindings. No target jobs.'},indent=2)+'\n')
