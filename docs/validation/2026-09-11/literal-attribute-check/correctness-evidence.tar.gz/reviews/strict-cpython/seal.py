from pathlib import Path
import gzip,hashlib,json,os
R=Path(__file__).resolve().parent
assert __debug__ and os.sched_getaffinity(0)=={6}
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
review=json.loads((R/'review.json').read_text());attempt=json.loads((R/'attempt01.json').read_text())
assert attempt['returncode']==0 and attempt['audit_sha256']==review['audit_sha256']==h(R/'audit.py')
for p,v in json.loads(gzip.decompress((R/'checked-files.json.gz').read_bytes())).items():assert h(Path(p))==v
receipt={'status':'passed','review_sha256':h(R/'review.json'),'audit_sha256':h(R/'audit.py'),'checked_files':141,'attempts':1,'methods_per_linkage':802,'linkages':['shared','static'],'scope':'Saved strict-outcome/source/command/origin audit only; no target or package jobs.'}
(R/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
index={str(p.relative_to(R)):{'sha256':h(p),'bytes':p.stat().st_size} for p in sorted(R.rglob('*')) if p.is_file() and p.name!='files.json'}
(R/'files.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
for n,v in index.items():assert (R/n).stat().st_size==v['bytes'] and h(R/n)==v['sha256']
print(json.dumps({'indexed_files':len(index),'review':h(R/'review.json'),'receipt':h(R/'receipt.json'),'index':h(R/'files.json')},indent=2))
