# Exact linkage/source/controller provenance beyond the unchanged outcome reader.
PREP=Path('/tmp/oriole-literal-attribute-strict-cpython-preparation')
PRIOR=Path('/tmp/oriole-current-thin-pgo-cpython-gates')
oldW=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')
assert sha('/tmp/oriole-current-thin-pgo-cpython-independent-review/review.json')=='7b8b055505931c115a5d315268c8b5571518fc794601281052ee865261e736c2'
assert sha('/tmp/oriole-literal-attribute-strict-controller-independent-review/review.json')=='b191359db75929c0969eb12b357b5d7fc606ea9a04d5589711cd772d1491be24'
assert sha(PREP/'preparation.json')=='0c9daf418a9f05fb1182c3227387c4efc6d604c126e1a542377b91f24f96ea23'
prep=load(PREP/'preparation.json')
assert len(prep['input_hashes'])==96
for path,value in prep['input_hashes'].items():assert sha(path)==value,path
assert read(G/'oriole-literal-attribute-thin-pgo-cpython-gates.py')==read(prep['controller']['path'])==read(PREP/'controller.py')
assert sha(prep['controller']['path'])=='f4effad366ccbcd7490a257ce150fa747ae5eab6d76d06282541cda56ed6b636'
assert [j['linkage'] for j in controller['jobs']]==['shared','static']
assert controller['jobs'][0]['end']<=controller['jobs'][1]['start']
assert read('/tmp/oriole-literal-attribute-thin-pgo-cpython-launch.log')==b'shared 2\nstatic 2\n'
assert controller['source_sha256']==load('/tmp/oriole-literal-attribute-check-pgo-study/source.json')['source_sha256']
baseline_source=load('/tmp/oriole-native-byte-count-pgo-study/source.json')['source_sha256']
assert [n for n,v in controller['source_sha256'].items() if v!=baseline_source[n]]==['crates/oriole/src/tag.rs']
tool_names=['README.md','check_extension_imports.py','extension_loader.py','run.py','test_run.py','text_fragmentation.py']
for name in tool_names:assert read(W/'tools/cpython'/name)==read(oldW/'tools/cpython'/name)
def normalize(arg):return arg.replace(str(PRIOR),str(G)).replace(str(oldW),str(W))
compiler_vectors={};origin_records={}
for linkage in ['shared','static']:
 p=G/linkage;old=PRIOR/linkage;s=load(p/'summary.json');b=load(old/'summary.json')
 assert s['commands']==[[normalize(arg) for arg in command] for command in b['commands']]
 assert s['test_command']==b['test_command']
 assert s['origin_command']==[normalize(arg) for arg in b['origin_command']]
 assert s['python']==b['python'] and s['schema_version']==b['schema_version']
 for module in ['pyexpat','_elementtree']:assert read(p/(module+'-build.log'))==b''
 job=next(row for row in controller['jobs'] if row['linkage']==linkage)
 expected_command=['taskset','-c','5','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3','-I','-S',str(W/'tools/cpython/run.py'),'--source','/home/dev-user/.cache/oriole/upstream/cpython-3.12.13','--library','/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.'+('so' if linkage=='shared' else 'a'),'--output',str(p)]
 if linkage=='static':expected_command += [a for name in ['gcc_s','util','rt','pthread','m','dl','c'] for a in ['--native-library',name]]
 assert job['command']==expected_command
 compiler_vectors[linkage]=s['commands'];origin_records[linkage]=load(p/'origin.log')
 # Saved compiler summaries are produced only after both successful compile
 # calls by the pinned runner; the logs retain stdout/stderr, not command lines.
 assert 'commands.append(command)' in read(W/'tools/cpython/run.py').decode()
 assert 'if result.returncode:' in read(W/'tools/cpython/run.py').decode()
 assert 'return result.returncode' in read(W/'tools/cpython/run.py').decode()
method=load(OUT/'method.json')
assert sha(OUT/'audit.py')==method['audit_sha256'] and sha(method['prior_reader'])==method['prior_reader_sha256']
for name in ['prepare-audit.py','tail.py','adaptation.patch']:read(OUT/name)
for p,h in list(hashes.items()):assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
review={'status':'passed','scope':'Independent saved strict ThinPGO shared/static outcomes, sources, compiler vectors, method maps, failure bodies, skips and extension import origins. No target execution.','audit_cpu':6,
 'source_manifest_sha256':sha('/tmp/oriole-literal-attribute-check-pgo-study/source.json'),'source_base':'c1776c922b023a3558badfefa697cd11b0d37d8e','source_files':70,'runtime_delta':['crates/oriole/src/tag.rs'],'libraries':controller['libraries'],
 'prepared_controller_review_sha256':sha('/tmp/oriole-literal-attribute-strict-controller-independent-review/review.json'),'prior_accepted_strict_review_sha256':sha('/tmp/oriole-current-thin-pgo-cpython-independent-review/review.json'),'build_review_sha256':sha('/tmp/oriole-literal-attribute-check-build-independent-review/review.json'),'controller_sha256':sha(G/'controller.json'),
 'linkages':python,'compiler_vectors':'All four saved successful-runner vectors equal the prior currentThinPGO vectors after only worktree/output paths. Same cc/shared/fPIC/O2 flags, includes, native-library ordering and rpath. Build logs are empty and hashed; commands are retained by the pinned runner summary.',
 'source_and_imports':'Both copied pyexpat.c files exactly equal upstream source; _elementtree.c and all six upstream test module hashes verified. Six tool files unchanged. Four initial/fresh extension origins per linkage bind exact extension bytes; all three accelerator import test methods pass.',
 'outcome':'Each linkage retains all802 method statuses, the same two ordinary-text fragmentation failures, all failure diagnostic bodies after only source-path prefix normalization, and all14 skip lines exactly equal accepted currentThinPGO baseline.',
 'bounds':'CPU5;120 seconds per module,900 seconds runner,1200 seconds per outer linkage; sequential shared then static. Exact expectedexit2 and raw logs retained.',
 'limitations':['This is exact baseline parity, not a fully passing suite; two failures remain. Fourteen reported skips comprise five whole methods, eight subtests and one class setup. Three expected failures are separate.','Strict runner checks extension imports/aliases and exact copied libraries; no XML_Parse dladdr assertion.','Saved successful compiler commands and source flow are checked, but no independent compiler-invocation tracing or new compiler execution is claimed.','Source-path prefixes alone are normalized in failure bodies. Successful runs do not exercise timeout or signal cleanup.','Only this candidate ThinPGO shared/static strict scope; no normal/fat-PGO, PBS, sanitizer, fuzz, broad C-API or full-application claim.','No archive/package readback or adoption decision is included.'],
 'findings':[],'checked_files':len(hashes),'all_inspected_inputs_unchanged':True,'audit_sha256':method['audit_sha256']}
for name,value in [('methods.json.gz',method_maps),('failure-bodies.json.gz',failure_blocks),('skip-lines.json.gz',skip_lines),('source-inputs.json.gz',source_inputs),('checked-files.json.gz',hashes),('compiler-vectors.json.gz',compiler_vectors),('origins.json.gz',origin_records)]:
 (OUT/name).write_bytes(gzip.compress((json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'checked_files':len(hashes)}))
