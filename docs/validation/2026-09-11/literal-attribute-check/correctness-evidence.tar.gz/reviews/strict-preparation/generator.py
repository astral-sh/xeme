"""Read source and hashes only; never execute/import the target controller."""
from pathlib import Path
import ast,difflib,hashlib,json,os
O=Path(__file__).resolve().parent
P=Path('/tmp/oriole-literal-attribute-strict-cpython-preparation')
inputs={};checks=0
def ck(label,value):
 global checks
 assert value,label
 checks+=1
def read(path):
 p=Path(path);b=p.read_bytes();v={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 ck('stable '+str(p),str(p) not in inputs or inputs[str(p)]==v);inputs[str(p)]=v;return b
def h(path):read(path);return inputs[str(path)]['sha256']
def j(path):return json.loads(read(path))
ck('CPU6 only',__debug__ and os.sched_getaffinity(0)=={6})
ck('preparation pin',h(P/'preparation.json')=='0c9daf418a9f05fb1182c3227387c4efc6d604c126e1a542377b91f24f96ea23')
prep=j(P/'preparation.json');oldpath=Path(prep['prior_controller']['path']);newpath=Path(prep['controller']['path'])
ck('controller pin',h(newpath)==prep['controller']['sha256']=='f4effad366ccbcd7490a257ce150fa747ae5eab6d76d06282541cda56ed6b636')
ck('prior controller pin',h(oldpath)==prep['prior_controller']['sha256']=='67cc5c4ff0decf33744c9728e1cee099bfd54ec44a5701ff4346b6d27903f7fe')
old=read(oldpath).decode();new=read(newpath).decode()
ck('controller copies',read(P/'original-controller.py')==old.encode() and read(P/'controller.py')==new.encode())
changes=[
('/home/dev-user/code/oss/oriole-native-byte-count-pgo','/home/dev-user/code/oss/oriole-literal-attribute-check'),
('/tmp/oriole-current-thin-pgo-cpython-gates','/tmp/oriole-literal-attribute-thin-pgo-cpython-gates'),
('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use/liboriole_expat.so','/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.so'),
('4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a'),
('8b6ca03e6fd4be81aba81cccf10b4aa2d67e16586010477cba1e8f23a4dec97d','a294cbd13adbb0af5eaa3722178690374df1b96eda5613c89461f575aa6fa643'),
('/tmp/oriole-native-byte-count-pgo-study/source.json','/tmp/oriole-literal-attribute-check-pgo-study/source.json'),
("['taskset', '-c', '4', python","['taskset', '-c', '5', python"),('CPU4, shared host.','CPU5, shared host.')]
expected=old
for a,b in changes:ck('expected substitution exists '+a,a in expected);expected=expected.replace(a,b)
ck('exact eight substitutions',expected==new)
patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(oldpath),tofile=str(newpath)))
ck('complete exact patch',read(P/'controller.patch').decode()==patch)
aa=ast.parse(old);bb=ast.parse(new);an=list(ast.walk(aa));bn=list(ast.walk(bb));ck('AST node count',len(an)==len(bn));deltas=[]
for a,b in zip(an,bn):
 ck('same AST node kind',type(a) is type(b))
 if isinstance(a,ast.Constant) and a.value!=b.value:
  ck('only string constants change',isinstance(a.value,str) and isinstance(b.value,str))
  deltas.append({'line':a.lineno,'before':a.value,'after':b.value});a.value=b.value
ck('full AST identical after permitted constants',ast.dump(aa)==ast.dump(bb))
ck('96 recorded bindings',len(prep['input_hashes'])==96)
for path,value in prep['input_hashes'].items():ck('bound input '+path,h(path)==value)
W=Path('/home/dev-user/code/oss/oriole-literal-attribute-check');B=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')
names=['README.md','check_extension_imports.py','extension_loader.py','run.py','test_run.py','text_fragmentation.py']
ck('six tool files',sorted(p.name for p in (W/'tools/cpython').iterdir() if p.is_file())==names)
for name in names:ck('tool unchanged '+name,read(W/'tools/cpython'/name)==read(B/'tools/cpython'/name))
runner=read(W/'tools/cpython/run.py').decode();tree=ast.parse(runner)
modules=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TESTS' for t in n.targets))
ck('original strict modules',modules==['test_pyexpat','test_xml_etree','test_xml_etree_c','test_minidom','test_sax','test_pulldom'])
ck('no alternate test or consumer modes',all(flag not in new for flag in ['--tests','--allow-text-fragmentation','--consumer-fix','--system-allocator']))
ck('default strict module choice','parser.add_argument("--tests", nargs="+", default=TESTS)' in runner)
ck('120/900 runner bounds','"--timeout",\n        "120",\n        *args.tests,' in runner and 'timeout=900,' in runner)
ck('1200 linkage and expectedexit2','process.wait(timeout=1200)' in new and "'expected_exit': 2, 'timeout_seconds': 1200" in new and "assert item['exit'] == 2" in new)
ck('strict extension source revision',"(3, 12, 13)" in runner and 'REVISION = "3bb231a6a5dc02b95658877318bf61501a7209e9"' in runner)
ck('inherited process group cleanup',all(s in new for s in ['start_new_session=True','except BaseException as exc:','os.killpg(process.pid, signal.SIGKILL)','item[\'exit\'] = process.wait()','log.flush()','item[\'log_sha256\'] = digest(log_path)']))
ck('shared then static exact',"for linkage, path in [('shared', library), ('static', archive)]:" in new)
ck('output absent at readback',not Path(prep['output']).exists())
for p,v in list(inputs.items()):ck('final hash stable '+p,h(p)==v['sha256'])
report={'status':'passed','scope':'Independent static controller and prepared-input readback only; no controller, compiler, parser, test or other target execution.','audit_cpu':6,
 'preparation_sha256':h(P/'preparation.json'),'controller_sha256':h(newpath),'prior_controller_sha256':h(oldpath),'controller_patch_sha256':h(P/'controller.patch'),'bindings_verified':96,'unchanged_tools':names,'modules':modules,
 'conclusion':'Exact eight substitutions affect paths, candidate hashes and CPU4-to-5 scope/argv only. Full AST structure, module choice, two linkage runs, bounds, expected-exit2 handling and process-group cleanup remain unchanged.',
 'bounds':prep['bounds'],'output_absent_at_readback':True,
 'expected_exit_behavior':'Exact expected exit2 retained. Any unexpected exit, including zero/all-pass, is saved, triggers cleanup and stops the controller; future exact test/outcome comparison is still required.',
 'limitations':['Preparation review supplies no fresh802 or strict compatibility outcome. Historical two failures/14 skips/three expected failures are expectations only.','No filtering, consumer-fix, fragmentation acceptance or alternate allocator flags are enabled.','Inherited extension import/alias checks do not attest XML_Parse by dladdr.','Existing process-group cleanup is source-reviewed, not signal-tested here; no broader signal-handling guarantee.','Root owns scheduling; this reviewer executes no target jobs.'],
 'findings':[],'all_inspected_inputs_unchanged':True,'input_files':len(inputs),'checks':checks}
for name,value in [('review.json',report),('inputs.json',inputs),('constant-deltas.json',deltas)]: (O/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest(),'inputs':len(inputs),'checks':checks}))
