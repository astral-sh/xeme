"""Freeze both completed native cohorts and their exact readiness receipts."""
from pathlib import Path
import hashlib,json,shutil
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
proof=Path('/tmp/oriole-literal-attribute-check-pgo-study/pair-freeze.json')
for name,row in load(proof)['files'].items():
    assert sha(proof.parent/name)==row['sha256']
for mode,session in [('normal',58057),('pgo',32685)]:
    p=Path('/tmp/oriole-literal-attribute-'+mode+'-native-study')
    c=load(p/'controller.json');r=load(p/'native-screen/results.json')
    assert c['status']==r['status']=='passed' and all(x['exit']==0 for x in c['commands'])
    assert len(r['rows'])==196 and len(r['summary'])==28
    assert r['hashes_before']==r['hashes_after']
    assert all(sha(n)==h for n,h in r['hashes_after'].items())
    shutil.copyfile('/tmp/oriole-literal-attribute-native-summary.py',p/'summarize.py')
    receipt={'status':'complete','session':session,'controller_exit':0,'preflights':84,'timed_workers':588,
        'source_build_freeze':{'path':str(proof),'sha256':sha(proof)},
        'build_review':{'path':'/tmp/oriole-literal-attribute-check-build-independent-review/review.json','sha256':sha('/tmp/oriole-literal-attribute-check-build-independent-review/review.json')},
        'ASan_readiness':{'path':'/tmp/oriole-be22-asan-study/ready.json','sha256':sha('/tmp/oriole-be22-asan-study/ready.json')},
        'scheduling':'Root authorized normal then PGO sequentially. All other target builds, gates, and ASan campaigns held throughout. CPU0 released after session32685 exit0. Light read-only controller/result inspection only.',
        'limits':['Author completion receipt and summary, independent raw audit separate.','C native lifecycle scope; no actual CPython/full compatibility or source adoption claim.','Normal and PGO cohorts compared separately to their same-cohort controls.'],
        'summary_sha256':sha(p/'summary.json')}
    (p/'completion.json').write_text(json.dumps(receipt,indent=2)+'\n')
    files={n.relative_to(p).as_posix():{'sha256':sha(n),'bytes':n.stat().st_size} for n in sorted(p.rglob('*')) if n.is_file() and n.name!='freeze.json' and '__pycache__' not in n.parts}
    f={'status':'frozen','files':files,'count':len(files),'bytes':sum(x['bytes'] for x in files.values())}
    (p/'freeze.json').write_text(json.dumps(f,indent=2)+'\n')
    assert all(sha(p/n)==row['sha256'] for n,row in files.items())
    print(json.dumps({'mode':mode,'files':len(files),'freeze_sha256':sha(p/'freeze.json')}))
