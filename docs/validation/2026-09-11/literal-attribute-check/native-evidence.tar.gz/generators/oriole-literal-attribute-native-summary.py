"""Summarize saved normal/PGO native cohorts; no target execution."""
from pathlib import Path
import hashlib,json,math,sys
mode=sys.argv[1]
assert mode in ('normal','pgo')
p=Path('/tmp/oriole-literal-attribute-'+mode+'-native-study')
d=json.loads((p/'native-screen/results.json').read_text())
assert d['status']=='passed' and len(d['rows'])==196 and len(d['summary'])==28
assert d['hashes_before']==d['hashes_after']
assert all(len(x['processes'])==3 for x in d['rows'])
assert json.loads((p/'controller.json').read_text())['status']=='passed'
groups={}
for name,rows in [('real',[x for x in d['summary'] if not x['condition']['name'].startswith('generated-')]),('generated',[x for x in d['summary'] if x['condition']['name'].startswith('generated-')])]:
    groups[name]={k:{'geomean':math.exp(sum(math.log(x['median_ratios'][k]) for x in rows)/len(rows)),
        'lower':sum(x['median_ratios'][k]<1 for x in rows),'higher':sum(x['median_ratios'][k]>1 for x in rows),'count':len(rows)} for k in rows[0]['median_ratios']}
summary={'status':d['status'],'scope':'Author summary of '+('normal no-PGO' if mode=='normal' else 'fresh ThinPGO')+' cohort only; each condition is the median of seven paired process-median ratios; independent raw audit pending. No cross-cohort ratio.',
    'results_sha256':hashlib.sha256((p/'native-screen/results.json').read_bytes()).hexdigest(),
    'groups':groups,'regressions':[{'condition':x['condition'],'ratio':x['median_ratios']['candidate_over_control']} for x in d['summary'] if x['median_ratios']['candidate_over_control']>1]}
dest=p/'summary.json'
if dest.exists():
    assert json.loads(dest.read_text())==summary
else:
    dest.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'mode':mode,'groups':groups,'summary_sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}))
