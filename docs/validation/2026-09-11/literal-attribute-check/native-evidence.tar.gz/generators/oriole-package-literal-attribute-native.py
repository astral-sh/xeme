"""Seal native build/results with origin readback; no target execution."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile

O=Path('/tmp/oriole-literal-attribute-native-handoff')
B=Path('/tmp/oriole-literal-attribute-check-pgo-study')
R=Path('/tmp/oriole-literal-attribute-check-build-independent-review')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
sources={'build':B,'normal':Path('/tmp/oriole-literal-attribute-normal-native-study'),
         'pgo':Path('/tmp/oriole-literal-attribute-pgo-native-study'),
         'build-independent-review':R}
files={};exclusions={}
for prefix,root in sources.items():
    if prefix=='build':
        freeze=load(root/'pair-freeze.json')
        selected=list(freeze['files'])+['pair-freeze.json']
    elif prefix in ('normal','pgo'):
        freeze=load(root/'freeze.json')
        selected=list(freeze['files'])+['freeze.json']
    else:
        freeze=None
        selected=[p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    for n in selected:
        path=root/n
        h=sha(path)
        if freeze and n in freeze['files']:
            assert h==freeze['files'][n]['sha256']
        row={'origin':str(path),'sha256':h,'bytes':path.stat().st_size}
        if path.suffix in ('.so','.a'):
            exclusions[prefix+'/'+n]=row
        else:
            files[prefix+'/'+n]=row
assert len(exclusions)==6
for f in ('/tmp/oriole-literal-attribute-native-summary.py','/tmp/oriole-freeze-literal-attribute-native.py',__file__):
    p=Path(f);files['generators/'+p.name]={'origin':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
normal=load(sources['normal']/'summary.json')
pgo=load(sources['pgo']/'summary.json')
pair=load(B/'pair-report.json')
origin={'files':files,'excluded_copied_binaries':exclusions,
 'scope':'Reusable Cargo pgo/targets cache was excluded by producer build freeze. Six copied libraries excluded from this archive; exact hashes remain here and in original build records. Native driver and referenced control libraries/corpus remain external with protocol hashes.'}
origin_bytes=(json.dumps(origin,indent=2)+'\n').encode()
O.mkdir(exist_ok=False)
archive=O/'details.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,compresslevel=6) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tf:
    for n,row in sorted(files.items()):
        data=Path(row['origin']).read_bytes()
        assert hashlib.sha256(data).hexdigest()==row['sha256']
        info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644
        tf.addfile(info,io.BytesIO(data))
    info=tarfile.TarInfo('ORIGINS.json');info.size=len(origin_bytes);info.mode=0o644
    tf.addfile(info,io.BytesIO(origin_bytes))
with tarfile.open(archive,'r:gz') as tf:
    members={m.name:m for m in tf if m.isfile()}
    assert set(members)==set(files)|{'ORIGINS.json'}
    assert tf.extractfile(members['ORIGINS.json']).read()==origin_bytes
    for n,row in files.items():
        data=tf.extractfile(members[n]).read()
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    for archive_name,manifest_name in [('build/source.tar.gz','build/source.json'),('build/tool-source.tar.gz','build/tool-source.json')]:
        mapping=json.loads(tf.extractfile(members[manifest_name]).read())
        if 'source_sha256' in mapping:mapping=mapping['source_sha256']
        with tarfile.open(fileobj=io.BytesIO(tf.extractfile(members[archive_name]).read()),mode='r:gz') as nested:
            actual={m.name:hashlib.sha256(nested.extractfile(m).read()).hexdigest() for m in nested if m.isfile()}
        assert actual==mapping
assert all(sha(row['origin'])==row['sha256'] for row in files.values())
assert all(sha(row['origin'])==row['sha256'] for row in exclusions.values())
report={'status':'complete_native_screen_candidate_not_selected','source_manifest_sha256':sha(B/'source.json'),
 'runtime_source_scope':'70 source files, only tag.rs changed from be22. Implementation/focused tests authored by root; build/native controllers and summary by multibyte_fuzz. Independent source and build review passed.',
 'build':{'workspace_compiler_invocations':9,'effective_c_only_thinlto':True,'generated_records_per_phase':288,'normal_libraries':pair['normal_libraries'],'pgo_libraries':{k:v for k,v in pair['pgo_libraries'].items() if k.startswith('use/')}},
 'normal':normal['groups'],'pgo':pgo['groups'],
 'counts_per_cohort':{'preflights':84,'timed_workers':588,'seeded_cohorts':196,'conditions':28,'pairs':7,'measured_parses':105420,'warmups':588},
 'archive':{'path':'details.tar.gz','sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(files)+1,'binary_exclusions':6},
 'source_review_sha256':'0600b8974dec93d761f644f53d18e8b4dedc6a50bddbff6babd49e520da4d97c',
 'build_review_sha256':sha(R/'review.json'),
 'native_independent_audit':'Pending separate receipt; this core archive is immutable.',
 'limitations':['Native C lifecycle study only; no full candidate compatibility or actual CPython result.','Two separate cohorts; no cross-cohort ratio or additive speedup claim.','Normal flat/adverse result and all PGO adverse conditions retained.','All other target jobs held during native measurements; ASan campaigns started afterward.']}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
readback={'status':'passed','archive_sha256':sha(archive),'members_rehashed':len(files)+1,'all_member_origins_rehashed':True,'nested_source_files':70,'nested_tool_files':6,'excluded_copied_binaries_rehashed':6,'ORIGINS_sha256':hashlib.sha256(origin_bytes).hexdigest()}
(O/'readback.json').write_text(json.dumps(readback,indent=2)+'\n')
(O/'README.md').write_text('''# Literal attribute eligibility: native screen

The candidate is promising only under PGO in these native measurements. It is
not selected; full candidate correctness and actual CPython results are pending.

| Matched cohort | Real-project time / control | Faster conditions | Generated time / control |
| --- | ---: | ---: | ---: |
| No PGO | 1.002103 | 12/24 | 1.021219 |
| Fresh ThinPGO | 0.978634 | 23/24 | 0.981787 |

Smaller is faster. Each condition is the median of seven paired process-median
ratios. The PGO candidate takes 1.37537 times Expat PGO's time across real
conditions; it wins 7/24. Maven with namespaces at 4 KiB is the sole PGO
regression, +0.5937%. All normal and PGO adverse cases remain in the archive.

Each separate cohort passed 84 preflights and 588 timed workers over all six
real projects and two generated controls. No conditions or samples were removed.
The original driver, iteration counts, seed and 90-second worker / 1200-second
timing bounds were preserved. Other target jobs were held throughout timing.

The source change fuses two literal-attribute eligibility scans. Root authored
the implementation and passed 58 core tests, Clippy and formatting. Independent
source and build reviews passed. Fresh normal/generate/use phases contain nine
actual workspace compiler invocations with effective C-only ThinLTO and 288
matching generated cases per phase. A new profile was generated and merged.

`details.tar.gz` preserves source/tool archives, patch, commands, compiler
vectors, generated training/profile bytes, all native raw workers and the build
review. `ORIGINS.json` inside it maps each member to its retained origin and hash.
Six copied libraries are excluded, with their complete hashes preserved.
`readback.json` records full member/origin and nested-source verification.
Native numerical review is a separate pending receipt. The core archive will
remain unchanged when that receipt arrives.
''')
index={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(O.iterdir()) if p.is_file()}
(O/'handoff.json').write_text(json.dumps({'status':'sealed','files':index},indent=2)+'\n')
print(json.dumps({'path':str(O),'archive_sha256':sha(archive),'members':len(files)+1,'handoff_sha256':sha(O/'handoff.json')}))
