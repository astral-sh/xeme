# Final attribute publication review

No publication blocker was found. This is a saved-data publication review on CPU6, with no target execution. Source, build, native/Python numerical, C/API, strict CPython and workspace reviews are reused by their exact archive-member hashes.

The rebased commit `5212291` has only `tag.rs` changed against PBS documentation parent `f1b69fe`; all 70 committed and live source hashes match frozen manifest `1120c74e`. Evidence copies, archive counts, aggregate table cells and the final Python package review match their original identities.

The final main README table was checked against 84 raw worker medians and 42 paired ratios for six current PGO conditions. All 18 numeric cells, PGO column labels and the 4 KiB/namespace-disabled/held-out-input caption match. Main README headings, warning and license are unchanged. Its 2.1%/1.2% PGO improvements, flat normal results, generated-control regression and remaining Expat performance gap retain their correct scope. ASan/PBS results explicitly describe preceding `be22a27` runtime bytes.

The final audit passed 960 checks across 108 unchanged inputs and resolved 56 local links. A separate narrow origin check verified all 52 supplementary/workspace archive members against their original files. The final Python package review is `6a3f2dfa`; the complete 20-file publication index reviewed here is `dc4f750d`. Root will add this receipt and refresh that index afterward.

The earlier successful receipt/input map is retained as `before-table-*`: root subsequently replaced the historical README table with current PGO values and attached the completed package review. `receipt.json`, `inputs.json.gz`, and `final-audit.*` describe the final review. There were no reviewer or producer target reruns.
