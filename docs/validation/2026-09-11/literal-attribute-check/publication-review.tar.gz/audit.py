"""Narrow publication audit, reusing prior reviews by hash; no target jobs."""
from pathlib import Path
import collections
import gzip
import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
import urllib.parse

ROOT = Path('/home/dev-user/code/oss/oriole-literal-attribute-check')
DOC = ROOT / 'docs/validation/2026-09-11/literal-attribute-check'
OUT = Path(__file__).parent
INPUTS = {}
CHECKS = collections.Counter()

def check(value, name):
    CHECKS[name] += 1
    assert value, name

def read(path):
    data = path.read_bytes()
    row = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    check(str(path) not in INPUTS or INPUTS[str(path)] == row, 'input_unchanged')
    INPUTS[str(path)] = row
    return data

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(read(path))

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def main():
    check(os.sched_getaffinity(0) == {6}, 'cpu6')
    head = git('rev-parse','HEAD').decode().strip()
    parent = git('rev-parse','HEAD^').decode().strip()
    check(head == '5212291c0b9f19a03666290d3a42401ebf1777ee' and parent == 'f1b69fef282ae97a180ecf97c2136cd349b7e5d9', 'rebased_commit_parent')
    check(git('diff','--name-only','HEAD^','HEAD').decode().splitlines() == ['crates/oriole/src/tag.rs'], 'only_tag_commit')
    check(git('diff','--name-only').decode().splitlines() == ['README.md','docs/review.md'], 'tracked_documentation_only')
    manifest_path = Path('/tmp/oriole-literal-attribute-check-study/source.json')
    frozen = load(manifest_path)
    manifest_sha = '1120c74e96c7f562cecfa25db227a830e8a1667a67dba30732ca039fb5e7dbec'
    check(INPUTS[str(manifest_path)]['sha256'] == manifest_sha, 'source_manifest_identity')
    check(len(frozen['source_sha256']) == 70, '70_frozen_sources')
    for name, expected in frozen['source_sha256'].items():
        check(sha(read(ROOT/name)) == expected, 'live_source_hash')
        check(sha(git('show','HEAD:'+name)) == expected, 'committed_source_hash')
    check(git('diff','--no-ext-diff',frozen['base'],'HEAD','--','crates/oriole/src/tag.rs') == read(DOC/'candidate.patch'), 'exact_candidate_patch')

    artifact_index = load(DOC/'artifacts.json')
    check(artifact_index['source_manifest_sha256'] == manifest_sha, 'artifact_source_identity')
    archives = {}
    for name, row in artifact_index['artifacts'].items():
        data = read(DOC/name)
        check(sha(data) == row['sha256'] and len(data) == row['bytes'], 'artifact_hash_and_size')
        if row.get('origin','').startswith('/'):
            check(data == read(Path(row['origin'])), 'exact_artifact_copy')
        if name.endswith('.tar.gz'):
            with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as archive:
                members = archive.getmembers()
                check(len(members) == row['members'], 'archive_member_count')
                check(len({m.name for m in members}) == len(members), 'archive_unique_names')
                archives[name] = {m.name: archive.extractfile(m).read() for m in members if m.isfile() and m.name.endswith('review.json')}
    source_review = json.loads(archives['native-evidence.tar.gz']['build/source-independent-review/review.json'])
    build_review = json.loads(archives['native-evidence.tar.gz']['build-independent-review/review.json'])
    native_review = json.loads(archives['supplementary-reviews.tar.gz']['review.json'])
    gates_review = json.loads(archives['correctness-evidence.tar.gz']['reviews/c-gates/review.json'])
    strict_review = json.loads(archives['correctness-evidence.tar.gz']['reviews/strict-cpython/review.json'])
    workspace_review = json.loads(archives['workspace-evidence.tar.gz']['review/review.json'])
    python_reviews = {mode:json.loads(archives['python-evidence.tar.gz'][f'{mode}/review/review.json']) for mode in ['normal','pgo']}
    reused = {
        'source':('native-evidence.tar.gz','build/source-independent-review/review.json','0600b8974dec93d761f644f53d18e8b4dedc6a50bddbff6babd49e520da4d97c'),
        'build':('native-evidence.tar.gz','build-independent-review/review.json','51b5001bfcfab7c08efc2b52d33d16d1eaf96a88e541d66fe781327075e947e8'),
        'native_numerical':('supplementary-reviews.tar.gz','review.json','1076bf1b7d9b2fce011e959f794d80b3a53f0d05d8c118f57059d9b04c5a0413'),
        'c_api_gates':('correctness-evidence.tar.gz','reviews/c-gates/review.json','f53fa60bfdd723ec036f6974cf3e9fb3ec48250f743a1df860ae7ccc62600db6'),
        'strict_cpython':('correctness-evidence.tar.gz','reviews/strict-cpython/review.json','ae4d9c48d28f42e9d3841ea86cebfbdf0548b09e3628f0f5b7a37a7dd8ac8e2c'),
        'workspace':('workspace-evidence.tar.gz','review/review.json','4988667dfb632a8503c75b35b43152862bda63192c375cadf077a17b2dd697e9'),
        'normal_python':('python-evidence.tar.gz','normal/review/review.json','49b60a8b17ef89d3c70943280f90335a72d8f9cb9327e699cd9b93469fc12e81'),
        'pgo_python':('python-evidence.tar.gz','pgo/review/review.json','db6821c028996387979d120ef755e1d96efd95cbce4e949741d664c25a6fcfca'),
    }
    for label,(archive,path,digest) in reused.items():
        data=archives[archive][path]
        check(sha(data)==digest and json.loads(data)['status']=='passed', 'reused_review_exact_hash')
    check(source_review['source_manifest_sha256']==build_review['source_manifest_sha256']==gates_review['source_manifest_sha256']==strict_review['source_manifest_sha256']==workspace_review['source_manifest_sha256']==manifest_sha,'review_source_identity')
    check(source_review['saved_checks']['oracle_total']==1243809 and source_review['saved_checks']['core_tests']==58,'source_oracle_claims')
    check(build_review['phase_compiles']=={'normal':3,'generate':3,'use':3} and build_review['generated_training']['candidate_rows']=={'normal':288,'generate':288,'use':288},'compiler_training_claims')
    check(gates_review['api']['rows']==4740 and gates_review['api']['pass']==4347 and gates_review['api']['fail']==393 and gates_review['api']['exit']==1,'api_exact_claims')
    for mode in ['shared','static']:
        r=strict_review['linkages'][mode]
        check(r['methods']==802 and len(r['failures'])==2 and r['reported_skips']==14 and r['expected_failures']==3 and r['all_method_statuses_equal_corrected_baseline'],'strict_claims')
    check(workspace_review['workspace_tests']==408 and workspace_review['workspace_test_binaries']==33 and workspace_review['doctests']==1 and workspace_review['commands_all_exit_zero'] and workspace_review['workspace_after_both_python_cohorts'],'workspace_claims')

    native=load(DOC/'native-report.json')
    python=load(DOC/'python-report.json')
    prose=read(DOC/'README.md').decode()
    ng=native_review['cohorts']
    pg=python['cohorts']
    table=[]
    for label,norm,pgo in [
        ('Native real projects',ng['normal']['groups']['real']['candidate_over_control'],ng['pgo']['groups']['real']['candidate_over_control']),
        ('Native generated controls',ng['normal']['groups']['generated']['candidate_over_control'],ng['pgo']['groups']['generated']['candidate_over_control']),
        ('Python, both consumers',pg['normal']['groups']['all']['candidate_over_control'],pg['pgo']['groups']['all']['candidate_over_control']),
        ('ElementTree',pg['normal']['groups']['elementtree']['candidate_over_control'],pg['pgo']['groups']['elementtree']['candidate_over_control']),
        ('Pyexpat events',pg['normal']['groups']['pyexpat-events']['candidate_over_control'],pg['pgo']['groups']['pyexpat-events']['candidate_over_control'])]:
        lo=lambda r:r.get('lower',r.get('below_one'))
        count=lambda r:r.get('count',r.get('conditions'))
        line=f"| {label} | {norm['geomean']:.6f} | {lo(norm)}/{count(norm)} | {pgo['geomean']:.6f} | {lo(pgo)}/{count(pgo)} |"
        check(line in prose,'exact_aggregate_table_row')
        table.append(line)
    native_gain=(1-ng['pgo']['groups']['real']['candidate_over_control']['geomean'])*100
    python_gain=(1-pg['pgo']['groups']['all']['candidate_over_control']['geomean'])*100
    regression=(ng['normal']['groups']['generated']['candidate_over_control']['geomean']-1)*100
    check(f'{native_gain:.2f}% less native time and {python_gain:.2f}% less CPython consumer time' in prose,'headline_percentages')
    check(f'regress by {regression:.2f}%' in prose,'generated_regression_visible')
    check('1.375× Expat PGO\'s native time and 1.132× its CPython time' in prose,'remaining_gap_visible')
    check('The normal build is flat overall' in prose and 'not complete application timings or a claim of statistical significance' in prose,'no_normal_or_significance_overclaim')
    check('Rust PGO release library is not sanitizer-instrumented' in prose and '14 reported skip lines and three expected failures' in prose,'correctness_scope_explicit')
    # The final main-README table replaces the historical baseline with current PGO results.
    benchmark=load(DOC/'readme-benchmark.json')
    benchmark_raw=read(Path(benchmark['source']))
    check(sha(benchmark_raw)==benchmark['source_sha256']=='97a6a890726318a41f0ad08f74784e7217e424e987f7c6cbfea99ff11b7e70c3','readme_benchmark_frozen_source')
    raw=json.loads(benchmark_raw)
    check(raw['status']=='passed','readme_benchmark_status')
    median=lambda values: (lambda v:v[len(v)//2] if len(v)%2 else (v[len(v)//2-1]+v[len(v)//2])/2)(sorted(values))
    current_readme=read(ROOT/'README.md').decode()
    check(len(benchmark['rows'])==6 and {r['name'] for r in benchmark['rows']}=={'vulkan','wayland','maven','batik','gtk','docbook'},'readme_six_projects')
    worker_count=pair_count=0
    for row in benchmark['rows']:
        groups=[g for g in raw['rows'] if g['condition']['name']==row['name'] and g['condition']['chunk']==4096 and g['condition']['namespaces'] is False]
        check(len(groups)==7 and {g['pair'] for g in groups}==set(range(7)),'readme_seven_pairs')
        by_engine={'candidate':[],'expat':[]};pairs=[]
        for group in sorted(groups,key=lambda g:g['pair']):
            observed={}
            for process in group['processes']:
                if process['engine'] not in by_engine:continue
                samples=json.loads(process['stdout'])['samples']
                check(process['returncode']==0 and sum(s['warmup'] for s in samples)==1,'readme_worker_success_warmup')
                times=[s['seconds'] for s in samples if not s['warmup']]
                check(len(times)==group['condition']['iterations'],'readme_measured_sample_count')
                value=median(times)
                check(value==process['median_seconds'],'readme_raw_worker_median')
                check(process['engine'] not in observed,'readme_unique_engine')
                observed[process['engine']]=value;by_engine[process['engine']].append(value);worker_count+=1
            check(set(observed)==set(by_engine),'readme_pair_both_engines')
            pairs.append(observed['candidate']/observed['expat']);pair_count+=1
        check(by_engine==row['process_medians_seconds'] and pairs==row['paired_ratios'],'readme_process_and_pair_arrays')
        check(median(by_engine['candidate'])*1000==row['oriole_ms'] and median(by_engine['expat'])*1000==row['expat_ms'] and median(pairs)==row['ratio'],'readme_three_cells_exact')
        line=f"| {row['label']} | {row['oriole_ms']:.3f} ms | {row['expat_ms']:.3f} ms | {row['ratio']:.2f}× |"
        check(line in current_readme,'readme_rendered_row')
    check(worker_count==84 and pair_count==42,'readme_84_workers_42_pairs')
    for phrase in ['Oriole (PGO) | Expat (PGO)', '4 KiB chunks and namespaces disabled',
        'Both parsers use PGO trained on generated XML; these projects are held out of training.',
        'Times are medians of seven process medians; ratios are medians of paired ratios.',
        'Expat is version 2.8.4.', 'ThinLTO is the default', 'PGO is opt-in']:
        check(phrase in current_readme,'readme_caption_scope')
    read(DOC/'readme-benchmark.py');read(Path('/tmp/oriole-refresh-attribute-benchmark-table.py'))
    for path in [ROOT/'README.md',ROOT/'docs/review.md']:
        current=read(path).decode();relative=str(path.relative_to(ROOT));previous=git('show','HEAD:'+relative).decode()
        if relative=='README.md':
            check(re.findall(r'^#+ .+$',current,re.M)==re.findall(r'^#+ .+$',previous,re.M),'readme_headings_unchanged')
            check(re.findall(r'^>.*$',current,re.M)==re.findall(r'^>.*$',previous,re.M),'readme_warning_unchanged')
            check(current.split('## License',1)[1]==previous.split('## License',1)[1],'readme_license_exact')
            check('preceding `be22a27` runtime' in current and '[`be22a27` PBS distribution]' in current,'readme_prior_asan_pbs_scope')
        else:
            check('Sustained ASan and full PBS results above remain scoped to the preceding `be22a27` runtime.' in current,'review_prior_asan_pbs_scope')
    link_counts={}
    for path in [ROOT/'README.md',ROOT/'docs/review.md',DOC/'README.md']:
        count=0
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',read(path).decode()):
            if re.match(r'^[a-z]+:',target) or target.startswith('#'):continue
            target=urllib.parse.unquote(target.split('#',1)[0])
            check((path.parent/target).exists(),'local_link_exists');count+=1
        link_counts[str(path.relative_to(ROOT))]=count
    attachment=load(Path('/tmp/oriole-literal-attribute-doc-final-attachment.json'))
    package_review=load(DOC/'python-package-review.json')
    check(sha(read(DOC/'python-package-review.json'))==attachment['review_sha256']=='6a3f2dfa18cfc313edd437b84d0bc02b5f36d0e94870349c93426bdeba2d2784','final_python_package_review_hash')
    check(package_review['status']=='passed' and package_review['archive_sha256']==artifact_index['artifacts']['python-evidence.tar.gz']['sha256'] and package_review['members']==3572,'final_python_package_scope')
    check(sha(read(DOC/'python-package-review.tar.gz'))==attachment['review_archive_sha256']=='d6a02f1beb4fc9c5ce63565837e9b360ac6e29c5d6de75d009b7772dfdab649d','final_python_package_archive_hash')
    check(sha(read(DOC/'README.md'))==attachment['readme_after_sha256'],'final_documentation_readme_hash')
    index=load(DOC/'files.json')
    check(sha(read(DOC/'files.json'))==attachment['final_index_sha256'],'final_attachment_index_hash')
    check(len(index)==20 and set(index)=={p.name for p in DOC.iterdir() if p.is_file()}-{'files.json'},'final_attachment_complete_index')
    for name,row in index.items():
        data=read(DOC/name);check(len(data)==row['bytes'] and sha(data)==row['sha256'],'final_attachment_index_member_hash')
    check(git('diff','--check')==b'','git_diff_whitespace')
    read(Path('/tmp/oriole-update-attribute-readme.py'))
    for filename,row in INPUTS.items():
        data=Path(filename).read_bytes();check(len(data)==row['bytes'] and sha(data)==row['sha256'],'inputs_unchanged_at_end')
    return {'status':'passed_final_publication_review','findings':[],'target_execution':False,'cpu':6,
        'scope':'Narrow final source/rebase/evidence-copy/prose/link review. Earlier raw numerical, source, build and correctness audits reused by hash; no target reruns.',
        'head':head,'parent':parent,'source_manifest_sha256':manifest_sha,'source_files':70,
        'reused_reviews':{label:{'archive':a,'member':p,'sha256':s} for label,(a,p,s) in reused.items()},
        'source_runtime_delta':['crates/oriole/src/tag.rs'],'native_pgo_time_reduction_percent':native_gain,'python_pgo_time_reduction_percent':python_gain,'normal_generated_native_regression_percent':regression,
        'readme_heading_warning_license_unchanged':True,'prior_asan_pbs_scope_retained':True,
        'readme_table':{'projects':6,'numeric_cells':18,'raw_worker_medians':84,'paired_ratios':42,'scope':'Current attribute PGO candidate versus Expat PGO; 4KiB namespace-disabled display subset.'},
        'final_python_package_review_sha256':attachment['review_sha256'],'reviewed_publication_index_sha256':attachment['final_index_sha256'],
        'local_links_checked':link_counts,'checks':dict(CHECKS),'total_checks':sum(CHECKS.values()),'unchanged_input_files':len(INPUTS),
        'remaining_publication_steps':'Root attaches this review and writes the final publication file index. These later bytes are outside this receipt.'}

if __name__=='__main__':
    try:
        result=main()
    except BaseException as error:
        failure={'status':'review_attempt_failed','exception':repr(error),'checks':dict(CHECKS),'target_execution':False}
        (OUT/f'failed-attempt-{len(list(OUT.glob("failed-attempt-*.json")))+1}.json').write_text(json.dumps(failure,indent=2)+'\n')
        raise
    (OUT/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    with gzip.GzipFile(filename=str(OUT/'inputs.json.gz'),mode='wb',mtime=0) as output:
        output.write((json.dumps(INPUTS,indent=2,sort_keys=True)+'\n').encode())
    print(json.dumps({k:v for k,v in result.items() if k not in ['checks','reused_reviews']},indent=2))
