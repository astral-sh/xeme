"""Independently read saved builds/training/profiles; no target tools execute."""
import datetime
import gzip
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import shlex
import tarfile

OUT=Path(__file__).parent
P=Path('/tmp/oriole-literal-attribute-check-pgo-study')
B=Path('/tmp/oriole-native-byte-count-pgo-study')
W=Path('/home/dev-user/code/oss/oriole-literal-attribute-check')
seen={}
def read(p):
    p=Path(p);b=p.read_bytes();seen[str(p)]=hashlib.sha256(b).hexdigest();return b
def js(p):return json.loads(read(p))
def checkhash(p,expected):assert hashlib.sha256(read(p)).hexdigest()==expected,str(p)
def outjson(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
f=js(P/'pair-freeze.json')
assert seen[str(P/'pair-freeze.json')]=='ff7d95fd7edb5b6733d30fd0be5260ae013cc118401cc922568577467be51c3e'
assert f['count']==len(f['files'])==73
for n,v in f['files'].items():
    b=read(P/n);assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
pair=[js(x/'pair-report.json') for x in [B,P]]
man=[js(x['pgo_manifest']['path']) for x in pair]
runs=[Path(x['run']) for x in man]
for x in pair:
    assert x['status']=='passed' and all(x[k] for k in ['source_unchanged','scripts_unchanged','tools_unchanged'])
    checkhash(x['pgo_manifest']['path'],x['pgo_manifest']['sha256'])
assert pair[0]['tools_before']==pair[1]['tools_before']==pair[1]['tools_after']
for p,v in pair[1]['tools_before'].items():checkhash(p,v)
assert man[0]['cargo_config_sha256']==man[1]['cargo_config_sha256']
assert man[0]['base_rustflags']==man[1]['base_rustflags']==[]
assert man[0]['cargo_args']==man[1]['cargo_args']==['-Zohm-defaults=no']
source=js(P/'source.json')['source_sha256'];oldsource=js(B/'source.json')['source_sha256']
assert len(source)==70 and [n for n in source if source[n]!=oldsource[n]]==['crates/oriole/src/tag.rs']
for n,v in source.items():checkhash(W/n,v)
tools=js(P/'tool-source.json');oldtools=js(B/'tool-source.json')
assert len(tools)==6 and [n for n in tools if tools[n]!=oldtools[n]]==['tools/pgo/README.md']
for n,v in tools.items():checkhash(W/n,v)
for archive,expected in [('source.tar.gz',source),('tool-source.tar.gz',tools)]:
    with tarfile.open(P/archive) as t:
        assert all(m.isfile() for m in t.getmembers())
        actual={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t}
        assert actual==expected
assert len(man[1]['source_sha256'])==67
assert man[1]['source_sha256']=={n:v for n,v in source.items() if not n.startswith('tests/c/')}
assert man[1]['script_sha256']=={Path(n).name:v for n,v in tools.items()}

vectors={};deltas=[];logs={}
for side,(root,pr,m,run) in enumerate(zip([B,P],pair,man,runs)):
    assert m['status']=='passed' and m['compared_parses']==288
    for cmd in pr['commands']:
        assert cmd['exit']==0
        checkhash(root/(cmd['label']+'.log'),cmd['log_sha256'])
    for cmd in m['commands']:
        assert cmd['returncode']==0 and cmd['status']=='passed'
        checkhash(run/cmd['log'],cmd['log_sha256'])
    for phase in ['normal','generate','use']:
        path=root/'normal-build.log' if phase=='normal' else run/next(c['log'] for c in m['commands'] if c['label']=='build-'+phase)
        text=read(path).decode();logs[(side,phase)]=text
        result=[]
        for line in text.splitlines():
            stripped=line.strip()
            if not (stripped.startswith('Running `') and '/rustc ' in stripped):continue
            argv=shlex.split(stripped[len('Running `'):-1])
            if '--crate-name' not in argv:continue
            crate=argv[argv.index('--crate-name')+1]
            if crate in ['oriole_storage','oriole','oriole_expat']:result.append({'crate':crate,'argv':argv})
        expected=pr['normal_vectors'] if phase=='normal' else pr['pgo_vectors'][phase]
        assert result==[{'crate':x['crate'],'argv':x['argv']} for x in expected]
        assert sorted(x['crate'] for x in result)==['oriole','oriole_expat','oriole_storage']
        for x in result:
            a=x['argv'];assert a[a.index('--target')+1]=='x86_64-unknown-linux-gnu'
            assert 'opt-level=3' in a and 'codegen-units=1' in a
            assert a[0]==list(pr['tools_before'])[0]
            types=[a[i+1] for i,v in enumerate(a[:-1]) if v=='--crate-type']
            if x['crate']=='oriole_expat':assert types==['cdylib','staticlib'] and 'lto=thin' in a
            else:assert types==['lib'] and 'linker-plugin-lto' in a
            wanted=[] if phase=='normal' else [f'-Cprofile-generate={run}/raw-profiles'] if phase=='generate' else [f'-Cprofile-use={run}/merged.profdata','-Cllvm-args=-pgo-warn-missing-function']
            assert [v for v in a if v.startswith(('-Cprofile-','-Cllvm-args='))]==wanted
        vectors[(side,phase)]=result
def normalized(argv,run,artifacts):
    # Only these two known per-worktree directories and the exact current run
    # are replaced. Metadata, options, order, crate types and target stay visible.
    result=[]
    for v in argv:
        for prefix in ['/home/dev-user/.cache/ohm/verified-build/0c/7ddaf39b3f7b8e','/home/dev-user/.cache/ohm/verified-build/1b/7fb24181a32ec8']:
            v=v.replace(prefix,'<PRIVATE_BUILD>')
        v=v.replace(str(run),'<FRESH_RUN>')
        if artifacts:
            v=re.sub(r'(?<=extra-filename=-)[0-9a-f]{16}$','<ARTIFACT>',v)
            v=re.sub(r'(lib\w+)-[0-9a-f]{16}(\.(?:rlib|rmeta))$',r'\1-<ARTIFACT>\2',v)
        result.append(v)
    return result
for phase in ['normal','generate','use']:
    for a,b in zip(vectors[0,phase],vectors[1,phase],strict=True):
        assert a['crate']==b['crate']
        assert normalized(a['argv'],runs[0],phase!='normal')==normalized(b['argv'],runs[1],phase!='normal')
        deltas.append({'phase':phase,'crate':a['crate'],'control_argv':a['argv'],'candidate_argv':b['argv'],
                       'changed_arguments':[{'index':i,'control':x,'candidate':y} for i,(x,y) in enumerate(zip(a['argv'],b['argv'],strict=True)) if x!=y]})
assert not re.search(r'(?im)^\s*warning[:\[]|\b(?:hash mismatch|counter mismatch|malformed instrumentation profile|no profile data available)\b',logs[1,'use'])
for i,(root,pr,run,m) in enumerate(zip([B,P],pair,runs,man)):
    for n,v in pr['normal_libraries'].items():checkhash(root/'normal'/n,v)
    for n,v in pr['pgo_libraries'].items():checkhash(run/n,v)
    for n,v in m['inputs_sha256'].items():checkhash(run/'inputs'/n,v)
assert man[0]['inputs_sha256']==man[1]['inputs_sha256'] and len(man[1]['inputs_sha256'])==13
inputs=js(runs[1]/'inputs/manifest.json')
assert len(inputs['rows'])==12 and inputs['iterations']==2
expected_keys={(x['name'],ns,ch,mode,it) for x in inputs['rows'] for ns,ch,mode,it in itertools.product(x['namespaces'],x['chunks'],inputs['handlers'],range(inputs['iterations']))}
assert len(expected_keys)==288
reference=js(B/'normal-training.json')['rows'];training=[]
for i,(root,run,pr,m) in enumerate(zip([B,P],runs,pair,man)):
    for phase in ['normal','generate','use']:
        path=root/'normal-training.json' if phase=='normal' else run/(phase+'-training.json')
        t=js(path);assert t['status']=='passed' and t['rows']==reference
        assert {(x['fixture'],x['namespaces'],x['chunk'],x['handlers'],x['iteration']) for x in t['rows']}==expected_keys
        assert len(t['rows'])==288 and all(x['status']==1 and x['error']==0 and not x['callback_exceptions'] for x in t['rows'])
        assert t['inputs_sha256']==m['inputs_sha256']['manifest.json'] and t['script_sha256']==tools['tools/pgo/train.py']
        origin=t['xml_parse_origin'];checkhash(origin['path'],origin['sha256']);assert origin['sha256']==t['library_sha256']
        expected_lib=root/'normal/liboriole_expat.so' if phase=='normal' else run/phase/'liboriole_expat.so'
        assert Path(origin['path']).resolve()==expected_lib.resolve()
        assert t['profile_file_environment']==(str(run/'raw-profiles/oriole-%m-%p.profraw') if phase=='generate' else None)
        training.append({'build':'control' if i==0 else 'candidate','phase':phase,'sha256':seen[str(path)],'rows':len(t['rows']),'origin':origin})
rawdir=runs[1]/'raw-profiles'
raw_names=set(man[1]['profiles_sha256'])-{'merged.profdata'}
assert {p.name for p in rawdir.iterdir()}==raw_names and len(raw_names)==1
for n,v in man[1]['profiles_sha256'].items():checkhash(runs[1]/n if n=='merged.profdata' else rawdir/n,v)
assert man[1]['profiles_sha256']['merged.profdata']!=man[0]['profiles_sha256']['merged.profdata']
merge=next(c for c in man[1]['commands'] if c['label']=='profile-merge')
assert merge['argv'][1:]==['merge','--num-threads=1','--failure-mode=any','-o',str(runs[1]/'merged.profdata'),*[str(rawdir/n) for n in sorted(raw_names)]]
show=read(runs[1]/next(c['log'] for c in man[1]['commands'] if c['label']=='profile-show')).decode()
entries=re.findall(r'^  (.+):\n    Hash: (\S+)\n    Counters: (\d+)\n    Block counts: (\[.*\])$',show,re.M)
assert len(entries)==630
counters={name:json.loads(blocks) for name,hash_,count,blocks in entries}
assert all(len(json.loads(blocks))==int(count) for name,hash_,count,blocks in entries)
blocks=sum(map(len,counters.values()));total=sum(map(sum,counters.values()))
assert f'Total number of blocks: {blocks}' in show and f'Total count: {total}' in show
feeds=sum(math.ceil(x['bytes']/ch)*len(x['namespaces'])*len(inputs['handlers'])*inputs['iterations'] for x in inputs['rows'] for ch in x['chunks'])
assert counters['XML_Parse'][0]==feeds==870312
proof=js(P/'vector-training-proof.json')
assert proof['phase_vectors']=={'normal':3,'generate':3,'use':3}
assert proof['fresh_profile']==man[1]['profiles_sha256'] and proof['fresh_workspace_compilations']==9
prior_reviews={}
for p in ['/tmp/oriole-literal-attribute-check-source-independent-review/review.json','/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json','/tmp/oriole-native-byte-count-pgo-training-independent-review/review.json']:
    read(p);prior_reviews[p]=seen[p]
read(__file__)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in seen.items())
detail={'compiler_comparisons':deltas,'training':training,'checked_files':seen,'profiles':man[1]['profiles_sha256']}
(OUT/'details.json.gz').write_bytes(gzip.compress(json.dumps(detail,sort_keys=True).encode(),mtime=0))
outjson('review.json',{
 'status':'passed','role':'Independent source/compiler/training saved-data reviewer',
 'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'pair_freeze_sha256':seen[str(P/'pair-freeze.json')],'frozen_files':73,
 'source_manifest_sha256':seen[str(P/'source.json')],'source_files':70,'only_runtime_delta':'crates/oriole/src/tag.rs',
 'pipeline':'Five code/test/init tools unchanged; tools/pgo/README publication-only delta retained. Exact 67-file inner runtime manifest is the 70-file outer manifest minus three C fixtures.',
 'compiler':'Nine actual workspace rustc invocations reconstructed from raw verbose logs. Corresponding normal control/candidate vectors differ only in exact private paths; generate/use also differ in fresh profile paths and artifact suffixes. Metadata and all other flags remain exact. Each phase is explicit-host C-only ThinLTO/O3/one codegen unit; dependencies use linker-plugin-lto.',
 'phase_compiles':{'normal':3,'generate':3,'use':3},'tools_match_control':True,
 'generated_training':{'fixtures':12,'candidate_rows':{'normal':288,'generate':288,'use':288},'all_rows_equal_prior_three_phases':True,'XML_Parse_origins_checked':6,'profile_XML_Parse_feeds':feeds},
 'profile':{'raw_files':1,'merged_sha256':man[1]['profiles_sha256']['merged.profdata'],'functions':len(entries),'blocks':blocks,'total_count':total,'strict_use_warning_gate':'passed'},
 'candidate_normal_libraries':pair[1]['normal_libraries'],'candidate_pgo_libraries':{n:v for n,v in pair[1]['pgo_libraries'].items() if n.startswith('use/')},
 'reused_reviews':prior_reviews,'details_sha256':hashlib.sha256((OUT/'details.json.gz').read_bytes()).hexdigest(),
 'limitations':['No target tools, parser, compiler, profiler or test execution by reviewer. No held-out project/elapsed/full compatibility claim.','Actual compiler vectors and recorded configuration/overrides are compared; identity of every ambient environment variable is not established.','Compiler/llvm-profdata numeric LLVM versions match the verified control, but their 1.98.1/1.98.0 distributions remain distinct.','Fresh profile lineage is supported by unchanged pipeline source/order, unique run, empty-raw precheck, commands and hashes; merged binary bytes were not recomputed from raw profile.'],
 'findings':[],'all_inspected_bytes_unchanged':True})
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'checked_files':len(seen),'compiler_invocations':9}))
