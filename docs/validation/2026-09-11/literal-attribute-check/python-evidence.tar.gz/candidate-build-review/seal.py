import hashlib
import json
from pathlib import Path
p=Path(__file__).parent
h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
assert not (p/'files.json').exists()
(p/'README.md').write_text('# Independent literal-attribute build review\n\n**Passed.** Nine fresh compiler invocations, source/tools, generated training, profile lineage and retained outputs match the documented scope. [Review](review.json), [audit](audit.py), [compressed full vectors and inputs](details.json.gz), [index](files.json). No target jobs or elapsed inference.\n')
(p/'receipt.json').write_text(json.dumps({'status':'sealed','review_sha256':h(p/'review.json'),'details_sha256':h(p/'details.json.gz'),'scope':'Saved source/compiler/training/profile audit only; limitations retained.'},indent=2)+'\n')
index={f.name:{'sha256':h(f),'bytes':f.stat().st_size} for f in sorted(p.iterdir()) if f.is_file()}
(p/'files.json').write_text(json.dumps(index,indent=2)+'\n')
assert all(h(p/f)==v['sha256'] for f,v in index.items())
print(json.dumps({'review':h(p/'review.json'),'receipt':h(p/'receipt.json'),'index':h(p/'files.json'),'indexed_files':len(index)}))
