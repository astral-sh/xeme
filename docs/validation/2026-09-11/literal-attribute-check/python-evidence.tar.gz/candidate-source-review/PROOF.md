# Literal attribute eligibility: independent source review

The frozen change has no source blocker. It changes only the pure eligibility check for a completed attribute value; it does not change name scanning, token completion, source positions, callback publication, ownership or accounting.

## Boolean equivalence

The previous check accepts exactly when no byte is `&`, TAB, CR or LF and every scalar satisfies the existing `is_xml_char`. ASCII bytes cannot occur inside a non-ASCII UTF-8 encoding. XMLChar permits only TAB/CR/LF below U+0020, so removing those three permitted controls makes the conjunction exactly `c >= U+0020 && c != '&' && is_xml_char(c)` for every scalar. DEL and permitted C1 controls remain allowed. U+FFFE/U+FFFF remain rejected; supplementary noncharacters remain allowed by the unchanged XMLChar function. `<` is deliberately not added to this predicate: the unchanged lexical scanner rejects it before returning a completed attribute.

For an eight-byte word, the control mask subtracts 0x20 in each lane, then keeps high bits only where the original byte was below 0x80. With no byte below 0x20, no subtraction borrows between lanes and no eligible high bit can be set. At the first byte below 0x20, no earlier borrow exists, subtraction wraps to 0xe0..0xff, and the retained high bit is set. Subsequent borrow propagation can mark a byte equal to 0x20, but the word already contains a genuine control. Thus nonzero means that at least one control exists, even for words containing high bytes.

The ampersand mask applies the same zero-byte existence argument to each byte XOR 0x26. If no lane is zero, subtracting one causes no borrow; the high-bit filter eliminates nonzero high lanes. The first zero wraps to 0xff and is marked. Later spurious lane marks require that earlier real zero. Wrapping beyond the highest lane does not erase its mark. Both masks are used only as aggregate booleans, never to derive an offset.

After both masks are zero, a word with any high byte falls back from the current, unchanged string boundary. Only a word consisting entirely of ASCII advances by eight. The safe `first_chunk` bounds check and ASCII-only advancement make `rest[8..]` a valid UTF-8 slice on all platforms; `from_le_bytes` fixes the lane interpretation without unaligned access or unsafe code. Scalar fallback applies the equivalent conjunction above to the entire remaining suffix, including word-crossing encodings and short tails.

## Parser and resource invariants

The pre-existing capacity test remains the first short-circuit operand. The helper takes only an immutable string and allocates nothing. Attribute range adjustment and the capacity-proven record push are unchanged. A rejected value returns the same `Planned::Fallback`; `scan` disables that plan as before. Existing token scanning, invalid-character diagnostics, raw publication, positions, budget charges and semantic parsing remain responsible for errors. A different early rejection location inside this boolean computation cannot change an error offset or error precedence.

Incremental scanning still records an attribute only when its closing quote arrives. Incomplete values are not rescanned by this helper. Each completed value gets at most one pass over its ASCII words followed by one scalar pass over the remaining suffix; existing source-generation, token-limit and fallback guards are unchanged.

## Saved validation and limits

The new test compares against the exact original two checks. Its source contains 1 empty case, 131,072 adjacent ASCII-pair/alignment cases, 1,112,064 Unicode-scalar cases crossing a word boundary, and 672 mixed UTF-8/control/tail cases: 1,243,809 assertions. The saved core run passes all 58 tests, including this oracle and unchanged split/capacity/limit scanner controls; strict core all-targets Clippy and formatting checks pass. This review reads those outputs and source; it runs no parser, compiler or test.

This establishes no elapsed improvement, fresh PGO correctness gate, exhaustive full-parser OOM coverage or platform performance claim. Prior ASCII name byte-range/table scans and completed-tag position/validation fusion are separately recorded rejected experiments. They are not implementations of this completed-attribute boolean fusion.
