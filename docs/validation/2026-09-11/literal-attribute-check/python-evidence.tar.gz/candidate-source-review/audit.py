"""Read frozen source and saved checks; no builds, parser or oracle reruns."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile

OUT=Path(__file__).parent
STUDY=Path('/tmp/oriole-literal-attribute-check-study')
ROOT=Path('/home/dev-user/code/oss/oriole-literal-attribute-check')
TAG='crates/oriole/src/tag.rs'
seen={}
def read(p):
    p=Path(p);b=p.read_bytes();seen[str(p)]=hashlib.sha256(b).hexdigest();return b
def js(p):return json.loads(read(p))
def git(*args):return subprocess.check_output(['git','-C',str(ROOT),*args])
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')

source=js(STUDY/'source.json')
assert seen[str(STUDY/'source.json')].startswith('1120c74e')
assert source['base']=='c1776c922b023a3558badfefa697cd11b0d37d8e'
assert git('rev-parse','HEAD').decode().strip()==source['base']
assert git('diff','--name-only').decode().splitlines()==[TAG]
assert git('diff','--',TAG)==read(STUDY/'candidate.patch')
assert len(source['source_sha256'])==70
changed=[]
for name,sha in source['source_sha256'].items():
    assert hashlib.sha256(read(ROOT/name)).hexdigest()==sha,name
    if hashlib.sha256(git('show',source['base']+':'+name)).hexdigest()!=sha:changed.append(name)
assert changed==[TAG]
read(STUDY/'source.tar.gz')
with tarfile.open(STUDY/'source.tar.gz') as t:
    ms=t.getmembers();assert len(ms)==70
    assert {m.name for m in ms}==set(source['source_sha256'])
    for m in ms:
        assert m.isfile()
        assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==source['source_sha256'][m.name]
tag=read(ROOT/TAG).decode()
old=git('show',source['base']+':'+TAG).decode()
assert tag.count('fn is_literal_value(')==1
assert 'if records.len() == records.capacity() || !is_literal_value(value)' in tag
assert 'fn name_end'+tag.split('fn name_end',1)[1].split('\n}\n',1)[0]== 'fn name_end'+old.split('fn name_end',1)[1].split('\n}\n',1)[0]
checks=js(STUDY/'checks.json')
assert checks['status']=='passed' and checks['source_sha256']==source['source_sha256'][TAG]
assert [c['label'] for c in checks['commands']]==['core-tests','clippy','fmt']
logs={}
for c in checks['commands']:
    assert c['exit']==0 and c['timeout']==600
    b=read(STUDY/(c['label']+'.log'))
    assert hashlib.sha256(b).hexdigest()==c['log_sha256']
    logs[c['label']]=b.decode()
core=logs['core-tests']
names=re.findall(r'^test (\S+) \.\.\. ok$',core,re.M)
assert len(names)==len(set(names))==58
assert 'tag::tests::literal_values_match_separate_checks_at_word_and_unicode_boundaries' in names
assert 'test result: ok. 58 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;' in core
assert checks['commands'][1]['command'][-3:]==['--','-D','warnings']
assert '--all-targets' in checks['commands'][1]['command']
assert checks['commands'][2]['command'][-2:]==['--all','--check']
oracle={'empty':1,'ASCII_pair_alignments':8*128*128,'Unicode_scalars':0x110000-0x800,'mixed_tails':16*7*6}
assert sum(oracle.values())==1243809
read(OUT/'PROOF.md');read(__file__)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in seen.items())
dump(OUT/'inputs.json',seen)
dump(OUT/'review.json',{
 'status':'passed', 'role':'Independent source and saved-check reviewer',
 'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Pure literal-attribute eligibility fusion; frozen source/archive/patch and saved core checks. No target execution, build, test rerun or timing claim.',
 'source_manifest_sha256':seen[str(STUDY/'source.json')], 'base':source['base'],
 'tag_sha256':source['source_sha256'][TAG], 'patch_sha256':seen[str(STUDY/'candidate.patch')],
 'source_files_verified':70, 'only_changed_file':TAG,
 'proof':'PROOF.md', 'proof_sha256':seen[str(OUT/'PROOF.md')],
 'conclusion':'Both word masks are exact existence predicates despite propagated marks; ASCII-only advancement preserves UTF-8 boundaries; scalar fallback equals the old normalization/XMLChar conjunction. Capacity, incremental progress, fallback, ownership, allocation and error/publication paths remain unchanged.',
 'saved_checks':{'core_tests':58,'core_clippy_all_targets':'passed -D warnings','fmt':'passed --check','oracle_case_counts_from_source':oracle,'oracle_total':sum(oracle.values())},
 'historical_distinction':'Prior ASCII name byte-range/table loops and completed-tag position/validation fusion were rejected separately. Current change touches neither name scanning nor positions; durable negative note is a separate supplement.',
 'limitations':['No performance, full C/API, CPython, allocator-failure or compiler-vector claim from this source review.','Oracle total is reconstructed from exact test loops and successful saved test outcome; no new oracle execution.'],
 'findings':[], 'all_inspected_bytes_unchanged':True})
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'source_files':70,'oracle_cases':sum(oracle.values())}))
