"""Seal this review, without modifying producer evidence."""
import hashlib
import json
from pathlib import Path
p=Path(__file__).parent
def h(x):return hashlib.sha256(x.read_bytes()).hexdigest()
assert not (p/'files.json').exists()
(p/'README.md').write_text('# Independent literal-attribute source review\n\n**Passed; no source blocker.** [Proof and limits](PROOF.md), [review](review.json), [saved-source audit](audit.py), and [file index](files.json). No builds, parser runs or test reruns were performed.\n')
(p/'receipt.json').write_text(json.dumps({'status':'sealed','review_sha256':h(p/'review.json'),'proof_sha256':h(p/'PROOF.md'),'source_manifest_sha256':json.loads((p/'review.json').read_text())['source_manifest_sha256']},indent=2)+'\n')
index={f.name:{'sha256':h(f),'bytes':f.stat().st_size} for f in sorted(p.iterdir()) if f.is_file()}
(p/'files.json').write_text(json.dumps(index,indent=2)+'\n')
assert all(h(p/f)==x['sha256'] for f,x in index.items())
print(json.dumps({'review':h(p/'review.json'),'receipt':h(p/'receipt.json'),'index':h(p/'files.json'),'indexed_files':len(index)}))
