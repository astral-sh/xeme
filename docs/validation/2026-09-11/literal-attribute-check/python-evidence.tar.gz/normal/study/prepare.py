"""Prepare two matched CPython cohorts; do not build or execute consumers."""
from pathlib import Path
import ast,difflib,hashlib,json,shutil

H=Path('/tmp/oriole-fat-pgo-python-root-study')
B=Path('/tmp/oriole-literal-attribute-check-pgo-study')
W=Path('/home/dev-user/code/oss/oriole-literal-attribute-check')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
source=load(B/'source.json')['source_sha256']
assert all(sha(W/n)==h for n,h in source.items())
assert sha('/tmp/oriole-literal-attribute-check-build-independent-review/review.json')=='51b5001bfcfab7c08efc2b52d33d16d1eaf96a88e541d66fe781327075e947e8'
nodes=lambda s,n:[ast.dump(x,include_attributes=False) for x in ast.walk(ast.parse(s)) if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) and x.name==n]
renames={'"thin_pgo"':'"control"','"fat_pgo"':'"candidate"','"expat_pgo"':'"expat"'}
prepared=[]
for mode in ('normal','pgo'):
    out=Path('/tmp/oriole-literal-attribute-'+mode+'-python-study')
    out.mkdir(exist_ok=False)
    libraries=load('/tmp/oriole-literal-attribute-'+mode+'-native-study/adaptation.json')['libraries']
    assert all(sha(v['path'])==v['sha256'] for v in libraries.values())
    shutil.copyfile(H/'python_worker.py',out/'python_worker.py')
    def delta(name,before,after):
        assert before!=after
        ast.parse(after)
        (out/name).write_text(after)
        (out/(name+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(H/name),tofile=str(out/name))))
    before=(H/'build_consumers.py').read_text()
    after=before
    for old,new in renames.items():after=after.replace(old,new)
    caption='PGO and Thin/fat LTO apply to the frozen linked parser libraries only.'
    assert caption in after
    after=after.replace(caption,'Both Oriole parser libraries use C-only ThinLTO with '+('no PGO; the Expat control uses no PGO or LTO.' if mode=='normal' else 'independent fresh generated-only PGO; the Expat control uses its verified generated-only PGO without LTO.'))
    start='        for engine, library in libraries.items():'
    end='        report["source_sha256_after"]'
    assert before[before.index(start):before.index(end)]==after[after.index(start):after.index(end)]
    delta('build_consumers.py',before,after)

    before=(H/'consumer_screen.py').read_text()
    after=before.replace(before.splitlines()[0],'"""Matched literal-attribute '+mode+' CPython screen with separate correctness and timing phases."""')
    for old,new in renames.items():after=after.replace(old,new)
    after=after.replace('Expected frozen ThinLTO PGO, fat LTO PGO and Expat PGO engines','Expected frozen control, literal-attribute candidate and Expat engines')
    method='Current be22 parser libraries: matched explicit-host generated-only PGO with ThinLTO or fat LTO, and pinned Expat2.8.4 PGO.'
    assert method in after
    after=after.replace(method,'Matched '+('no-PGO' if mode=='normal' else 'generated-only ThinPGO')+' parser cohort: explicit-host be22 control and literal-attribute eligibility candidate, plus pinned Expat2.8.4 '+('normal' if mode=='normal' else 'PGO')+'. Both Oriole libraries use C-only ThinLTO. This cohort is assessed separately from the other profile mode.')
    limit='These fresh explicit-target ThinLTO and fat LTO PGO library variants have not yet run the full strict suite; canonical fixture outputs must match Expat.'
    assert limit in after
    after=after.replace(limit,'At protocol preparation no fresh full strict CPython suite has run on this candidate; canonical fixture outputs must match Expat. This benchmark does not establish full-suite compatibility.')
    for name in ('digest','save','run_process','execute'):
        assert nodes(before,name)==nodes(after,name) and len(nodes(after,name))==1
    tail='    try:\n        if args.phase == "prepare":'
    assert before[before.index(tail):]==after[after.index(tail):]
    iterations=lambda s:[ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='ITERATIONS' for x in n.targets)]
    assert iterations(before)==iterations(after)
    delta('consumer_screen.py',before,after)

    before=(H/'run.py').read_text()
    after=before.replace("libraries['fat_pgo']['path']","libraries['candidate']['path']").replace("libraries['thin_pgo']['path']","libraries['control']['path']").replace("libraries['expat_pgo']['path']","libraries['expat']['path']").replace('/home/dev-user/code/oss/oriole-native-byte-count-pgo/include',str(W/'include'))
    assert before[before.index('report_path = '):]==after[after.index('report_path = '):]
    delta('run.py',before,after)
    assert sha(out/'python_worker.py')==sha(H/'python_worker.py')
    receipt={'status':'prepared_only','mode':mode,'source_runtime_control':'be22a271f8a5c004d13e515cd4024a68afe57887',
      'candidate_source_manifest':{'path':str(B/'source.json'),'sha256':sha(B/'source.json')},
      'candidate_pair_freeze':{'path':str(B/'pair-freeze.json'),'sha256':sha(B/'pair-freeze.json')},
      'libraries':libraries,'header':{'path':str(W/'include/expat.h'),'sha256':sha(W/'include/expat.h')},
      'counts':{'conditions':24,'engines':3,'extensions':6,'preflights':72,'cohorts':168,'pairs':7,'timed_workers':504,'measured_parses':25788,'warmups':504},
      'bounds':{'prepare_cpu':4,'timing_cpu':0,'build_seconds':600,'preflight_aggregate_seconds':600,'worker_seconds':300,'timing_aggregate_seconds':1200},
      'seed':202609104412,
      'proof':'Worker bytes, full extension compile loop, digest/save/run_process/execute AST, iteration table and entire preflight/timing/ratio tail exact. Changes only engine labels, matching library inputs, common byte-identical header path, private output directory and explanatory scope. All process-group watchdog/cleanup code and bounds exact.',
      'execution_prerequisites':'Root review and scheduling after accepted-be22 ASan campaigns. No build, preflight or elapsed execution authorized by this preparation.',
      'files':{p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file()},
      'parent_files':{n:sha(H/n) for n in ('python_worker.py','build_consumers.py','consumer_screen.py','run.py')}}
    (out/'adaptation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    shutil.copyfile(__file__,out/'prepare.py')
    prepared.append({'mode':mode,'path':str(out),'adaptation_sha256':sha(out/'adaptation.json'),'patches':{n:sha(out/n) for n in ('build_consumers.py.patch','consumer_screen.py.patch','run.py.patch')}})
print(json.dumps(prepared,indent=2))
