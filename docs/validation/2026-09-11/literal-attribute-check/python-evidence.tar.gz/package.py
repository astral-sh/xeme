"""Compact, immutable wrapper for both completed literal-attribute Python cohorts."""
import gzip,hashlib,io,json,os,tarfile,traceback
from pathlib import Path
os.sched_setaffinity(0,{6})
OUT=Path('/tmp/oriole-literal-attribute-python-final-handoff')
OUT.mkdir(exist_ok=False)
entries={};excluded=[];pins={};aliases=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p);assert p.is_file() and not p.is_symlink(),p
 b=p.read_bytes();h=sha(b);assert pins.setdefault(str(p),h)==h,p;return b
def digest(p):return sha(read(p))
def load(p):return json.loads(read(p))
def add(n,p):
 assert n not in entries,n
 b=read(p);assert not b.startswith((b'\x7fELF',b'!<arch>\n')),p
 entries[n]=Path(p)
def tree(label,p,exclude_binaries=False):
 for f in sorted(p.rglob('*')):
  if f.is_symlink():
   assert exclude_binaries and f.name=='libexpat.so.1',f
   target=f.resolve(strict=True);assert target.parent==f.parent and not target.is_symlink()
   b=read(target);assert b.startswith(b'\x7fELF')
   aliases.append({'path':label+'/'+str(f.relative_to(p)),'origin':str(f),'link_text':str(f.readlink()),'target':str(target),'target_sha256':sha(b),'reason':'compiled library alias; target separately excluded'})
   continue
  if not f.is_file():continue
  n=label+'/'+str(f.relative_to(p));b=read(f)
  if b.startswith((b'\x7fELF',b'!<arch>\n')):
   assert exclude_binaries
   excluded.append({'path':n,'origin':str(f),'bytes':len(b),'sha256':sha(b),'reason':'compiled consumer extension or copied parser library'});continue
  assert '__pycache__' not in f.parts and f.suffix!='.pyc',f
  add(n,f)
def write(n,j):(OUT/n).write_text(json.dumps(j,indent=2)+'\n')
report={'status':'incomplete'}
try:
 reviews={}
 for mode in ['normal','pgo']:
  B=Path('/tmp/oriole-literal-attribute-'+mode+'-python-study')
  R=Path('/tmp/oriole-literal-attribute-'+mode+'-python-independent-review')
  reviews[mode]=load(R/'review.json');assert reviews[mode]['status']=='passed'
  assert load(B/'time-controller.json')['status']=='passed'
  tree(mode+'/study',B,True)
  tree(mode+'/review',R)
 assert len(excluded)==18 and len(aliases)==2
 tree('initial-packaging-attempt',Path('/tmp/oriole-literal-attribute-python-handoff'))
 tree('protocol-review',Path('/tmp/oriole-literal-attribute-python-protocol-independent-review'))
 tree('candidate-source-review',Path('/tmp/oriole-literal-attribute-check-source-independent-review'))
 tree('candidate-build-review',Path('/tmp/oriole-literal-attribute-check-build-independent-review'))
 pair=Path('/tmp/oriole-literal-attribute-check-pgo-study')
 for n in ['source.json','source.tar.gz','candidate.patch','source-checks.json','source-binding.json','pair-freeze.json','pair-report.json','vector-training-proof.json','vector-training-details.json.gz','tool-source.json','tool-source.tar.gz']:
  add('candidate-build/'+n,pair/n)
 baseline=Path('/tmp/oriole-native-byte-count-pgo-study')
 for n in ['source.json','source.tar.gz']:
  add('control-source/'+n,baseline/n)
 # Include all nonbinary source bytes pinned by fresh CPython build receipts.
 for mode in ['normal','pgo']:
  b=load(Path('/tmp/oriole-literal-attribute-'+mode+'-python-study/consumers/build.json'))
  for p,h in b['source_sha256_before'].items():
   data=read(p);assert sha(data)==h
   if data.startswith(b'\x7fELF'):continue
   n='external-sources/'+h+'-'+Path(p).name
   if n not in entries:add(n,p)
 manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
 add('projects/corpus-manifest.json',manifest)
 for project in load(manifest)['projects']:
  f=next(x for x in project['files'] if x['role']=='input')
  p=(manifest.parent/f['path']).resolve();assert digest(p)==f['sha256']
  add('projects/'+project['name']+'/'+p.name,p)
 add('package.py',Path(__file__))
 members=[]
 with tarfile.open(OUT/'details.tar.gz','w:gz',compresslevel=9) as t:
  for n,p in sorted(entries.items()):
   b=read(p);i=tarfile.TarInfo(n);i.size=len(b);i.mtime=0;i.mode=0o444
   t.addfile(i,io.BytesIO(b));members.append({'path':n,'origin':str(p),'bytes':len(b),'sha256':sha(b)})
 with tarfile.open(OUT/'details.tar.gz','r:gz') as t:
  actual=t.getmembers();assert len(actual)==len(members)
  for m,e in zip(actual,members,strict=True):
   assert m.isfile() and m.name==e['path'] and m.size==e['bytes']
   assert sha(t.extractfile(m).read())==e['sha256']==digest(e['origin'])
   if m.name.endswith('/source.tar.gz'):
    nested=t.extractfile(m).read()
    source_json=entries[m.name.removesuffix('.tar.gz')+'.json']
    source=load(source_json)['source_sha256']
    with tarfile.open(fileobj=io.BytesIO(nested),mode='r:gz') as st:
     mm=st.getmembers();assert len(mm)==70 and all(x.isfile() for x in mm)
     assert {x.name:sha(st.extractfile(x).read()) for x in mm}==source
 for p,h in pins.items():assert sha(Path(p).read_bytes())==h,p
 for alias in aliases:
  assert str(Path(alias['origin']).readlink())==alias['link_text'] and digest(alias['target'])==alias['target_sha256']
 member_report={'members':members,'excluded_binaries':excluded,'excluded_library_aliases':aliases,'all_input_hashes':pins}
 (OUT/'members.json.gz').write_bytes(gzip.compress(json.dumps(member_report,sort_keys=True,separators=(',',':')).encode(),mtime=0))
 report={'status':'passed','mode_scope':'Two separate matched normal and ThinPGO cohorts; no cross-cohort ratio or additive speedup.','counts_per_cohort':{'conditions':24,'engines':3,'extensions':6,'preflights':72,'timed_workers':504,'cohorts':168,'measured_samples':25788,'timing_warmups':504},'cohorts':{mode:{'groups':r['groups'],'regressions':r['regressions'],'review_sha256':digest(Path('/tmp/oriole-literal-attribute-'+mode+'-python-independent-review/review.json')),'library_bindings':r['library_bindings']} for mode,r in reviews.items()},'protocol_review_sha256':'ec34d8dc61f63f6ede20ee68d08c6491000bc39b86943eb208c81d83433c3de7','candidate_build_review_sha256':'51b5001bfcfab7c08efc2b52d33d16d1eaf96a88e541d66fe781327075e947e8','candidate_source_manifest_sha256':'1120c74e96c7f562cecfa25db227a830e8a1667a67dba30732ca039fb5e7dbec','package':{'archive_sha256':sha((OUT/'details.tar.gz').read_bytes()),'archive_members':len(members),'members_map_sha256':sha((OUT/'members.json.gz').read_bytes()),'excluded_compiled_files':len(excluded),'excluded_library_aliases':len(aliases),'preserved_packaging_attempts':1,'nested_source_files':140,'unchanged_inputs':len(pins),'all_member_origin_readback_passed':True},'roles':{'collector':'Root executed both completed Python cohorts.','numerical_reviewer':'Prepared-controller author independently reconstructed all saved raw outcomes; preparation authorship disclosed.','protocol_and_build_reviewers':'Separate independent source/protocol/build reviewers, exact receipts included.'},'assessment':'A small measured gain for the recommended ThinPGO build: 1.23% lower actual Python time and prior native2.14% lower. Normal Python is flat and normal generated-native controls regress; no general normal-build improvement claim. Remaining candidate/ExpatPGO Python ratio1.1323 means the performance goal is not met.','limitations':['Both Python consumers use namespace processing. Measurement includes parser lifecycle, callbacks/tree creation and explicit result destruction; imports, reads, canonical comparison and explicit gc.collect are outside, automatic GC remains enabled.','Canonical pyexpat comparison merges adjacent text callbacks and does not replace the separate strict compatibility suites.','These are fixed fixture measurements, not whole-application or statistical-confidence claims. All adverse conditions remain included.','No target reruns, source changes, or producer mutation occurred during numerical audit or packaging. No compiled binary is shipped; exact hashes and original locations are retained.']}
 write('report.json',report)
 rows='\n'.join('| '+m+' | '+f"{r['groups']['all']['candidate_over_control']['geomean']:.9f}"+' | '+str(r['groups']['all']['candidate_over_control']['below_one'])+'/24 | '+f"{r['groups']['elementtree']['candidate_over_control']['geomean']:.9f}"+' | '+f"{r['groups']['pyexpat-events']['candidate_over_control']['geomean']:.9f}"+' |' for m,r in reviews.items())
 (OUT/'README.md').write_text('''# Literal-attribute CPython cohorts

Both saved-data numerical audits passed. Each separate cohort contains 72 preflights and 504 timed workers across 24 conditions and seven seeded rounds, retaining all 25,788 measured samples and 504 warmups.

| Cohort | Candidate/control time | Lower conditions | ElementTree | Pyexpat events |
| --- | ---: | ---: | ---: | ---: |
'''+rows+'''

Ratios below one mean less measured time. Normal is flat overall, with 13/24 adverse conditions. ThinPGO improves 22/24 conditions; the retained regressions are Batik pyexpat4K (+0.612%) and GTK ElementTree64K (+0.072%). Candidate/ExpatPGO remains1.132312410: this is a small improvement, not completion of the performance goal. Prior native results show PGO improvement with normal/generated adverse controls; no cross-cohort or additive speedup is inferred.

`details.tar.gz` preserves both complete nonbinary studies, controllers, raw streams/specifications, sources, external CPython input sources, exact project inputs, and review records. `members.json.gz` retains every member origin, complete input hashes, and all18 excluded compiled consumer/parser files. Both Expat soname aliases are recorded against their target hashes; the initial packaging-only alias rejection is retained. Both70-file source archives and every archive member were read back against exact originals. No original evidence was modified.

`report.json` gives compact results and identities. Numerical reconstruction was separate from root's target collection, but performed by the prepared-controller author; independent protocol and build reviews are retained explicitly. Both consumers use namespaces. Timing includes parser lifecycle, callbacks/tree creation and explicit result destruction; canonical comparisons and explicit gc.collect are outside, automatic GC remains enabled. Adjacent pyexpat text callbacks are merged for the canonical oracle; strict compatibility evidence remains separate.
''')
 # Copy concise reviews for straightforward publication links.
 for mode in reviews:(OUT/(mode+'-review.json')).write_bytes(read(Path('/tmp/oriole-literal-attribute-'+mode+'-python-independent-review/review.json')))
 (OUT/'package.py').write_bytes(Path(__file__).read_bytes())
 files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(OUT.iterdir()) if p.is_file()}
 write('files.json',files)
 for p in OUT.iterdir():p.chmod(0o444)
 OUT.chmod(0o555)
 print(json.dumps({'status':'passed','report_sha256':sha((OUT/'report.json').read_bytes()),'files_sha256':sha((OUT/'files.json').read_bytes()),'package':report['package']},indent=2))
except BaseException as e:
 write('failure.json',{'status':'failed','error':repr(e),'traceback':traceback.format_exc()})
 raise
