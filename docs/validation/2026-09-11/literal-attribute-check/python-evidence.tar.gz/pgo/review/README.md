# Literal-attribute pgo Python numerical audit

**Passed on the first attempt.** All 72 preflights, 504 measured workers, 168 seeded cohorts, 25,788 measured samples and 504 timing warmups reconcile. All 1,728 raw stream/specification files, 576 same-process parser origins, six identical-flag extension builds, per-worker medians, 504 paired ratios and all 24 condition summaries are checked. 1,856 input files remain unchanged.

Candidate/control time ratio is **0.987734561830** (22/24 lower, 2/24 higher). ElementTree: 0.985853035709. Pyexpat events: 0.989619678893. Candidate/Expat: 1.132312410052. All regressions are retained. Ratios below one indicate less measured time. The pgo cohort is interpreted separately from the other build mode.

The numerical reviewer did not collect these Python targets, but authored the prepared controller adaptation. Its independent protocol/source review ec34d8dc is reused by exact hash; all six normal/PGO library bindings and both prepared controller identities are rehashed. No target, compiler, profiler, or producer controller ran during this audit.

Both consumers enable namespace processing. Construction, feeding, closing, Python callbacks/tree creation and explicit result destruction are measured. Imports, input reads, canonical checks and explicit gc.collect are outside; automatic GC stays enabled. Canonical pyexpat comparison combines adjacent text callbacks, so this audit is separate from strict compatibility. The successful saved runs do not exercise failure cleanup paths.

`review.json` is the compact receipt. `details.json.gz` contains all raw/input hashes, condition medians, paired ratios, regressions and normalized build commands. `audit.py` and `attempt-01.log` retain the complete independent reader and its sole run. The producer studies remain unchanged.
