from pathlib import Path
import ast, copy, difflib, gzip, hashlib, json
O=Path(__file__).parent
H=Path('/tmp/oriole-fat-pgo-python-root-study')
inputs={}; findings={}
def sha(p):
 p=Path(p); h=hashlib.sha256(p.read_bytes()).hexdigest(); inputs[str(p)]=h; return h
def load(p):sha(p);return json.loads(Path(p).read_text())
def check(p,h):assert sha(p)==h,(str(p),h)
expected={'normal':'24f08981cc946d64a6210f9451186f316bed488b7d95997118eb3c18c86d9ae0','pgo':'8426f96046a377014c8c3eed546198170f9699b75328235835341cb8c7df14a1'}
rename={'thin_pgo':'control','fat_pgo':'candidate','expat_pgo':'expat','/home/dev-user/code/oss/oriole-native-byte-count-pgo/include':'/home/dev-user/code/oss/oriole-literal-attribute-check/include'}
for mode,expected_hash in expected.items():
 D=Path('/tmp/oriole-literal-attribute-'+mode+'-python-study');check(D/'adaptation.json',expected_hash);a=load(D/'adaptation.json')
 assert a['status']=='prepared_only' and a['mode']==mode
 for p,h in a['files'].items():check(D/p,h)
 for p,h in a['parent_files'].items():check(H/p,h)
 for key in ('candidate_source_manifest','candidate_pair_freeze','header'):check(a[key]['path'],a[key]['sha256'])
 for row in a['libraries'].values():check(row['path'],row['sha256'])
 assert a['libraries']==load('/tmp/oriole-literal-attribute-'+mode+'-native-study/adaptation.json')['libraries']
 assert (D/'python_worker.py').read_bytes()==(H/'python_worker.py').read_bytes()
 check(D/'prepare.py',sha('/tmp/oriole-prepare-literal-attribute-python.py'))
 assert not any((D/p).exists() for p in ('consumers','screen','prepare-controller.json','time-controller.json'))
 source=load(a['candidate_source_manifest']['path'])['source_sha256'];assert len(source)==70
 for p,h in source.items():check(Path('/home/dev-user/code/oss/oriole-literal-attribute-check')/p,h)
 assert sha(a['header']['path'])==sha('/home/dev-user/code/oss/oriole-native-byte-count-pgo/include/expat.h')
 changes={}
 for name in ('build_consumers.py','consumer_screen.py','run.py'):
  before=(H/name).read_text();after=(D/name).read_text(); b=ast.parse(before);c=ast.parse(after)
  bc=[n for n in ast.walk(b) if isinstance(n,ast.Constant)];cc=[n for n in ast.walk(c) if isinstance(n,ast.Constant)];assert len(bc)==len(cc)
  delta=[]
  for old,new in zip(bc,cc):
   if old.value==new.value:continue
   x,y=old.value,new.value;assert isinstance(x,str) and isinstance(y,str)
   allowed=rename.get(x)==y
   if name=='build_consumers.py' and x.startswith('All three engines compile identical unmodified CPython'):
    needle='PGO and Thin/fat LTO apply to the frozen linked parser libraries only.'
    replacement='Both Oriole parser libraries use C-only ThinLTO with '+('no PGO; the Expat control uses no PGO or LTO.' if mode=='normal' else 'independent fresh generated-only PGO; the Expat control uses its verified generated-only PGO without LTO.')
    allowed=y==x.replace(needle,replacement)
   if name=='consumer_screen.py':
    if x=='Paired coalesced namespace tag plan actual-consumer screen with separate correctness and timing phases.':allowed=y=='Matched literal-attribute '+mode+' CPython screen with separate correctness and timing phases.'
    elif x=='Expected frozen ThinLTO PGO, fat LTO PGO and Expat PGO engines':allowed=y=='Expected frozen control, literal-attribute candidate and Expat engines'
    elif x.startswith('Current be22 parser libraries:'):
     old_prefix='Current be22 parser libraries: matched explicit-host generated-only PGO with ThinLTO or fat LTO, and pinned Expat2.8.4 PGO.'
     new_prefix='Matched '+('no-PGO' if mode=='normal' else 'generated-only ThinPGO')+' parser cohort: explicit-host be22 control and literal-attribute eligibility candidate, plus pinned Expat2.8.4 '+('normal' if mode=='normal' else 'PGO')+'. Both Oriole libraries use C-only ThinLTO. This cohort is assessed separately from the other profile mode.'
     allowed=y==x.replace(old_prefix,new_prefix)
    elif x.startswith('Shared host frequency/cache/memory bandwidth uncontrolled.'):
     old_sentence='These fresh explicit-target ThinLTO and fat LTO PGO library variants have not yet run the full strict suite; canonical fixture outputs must match Expat.'
     new_sentence='At protocol preparation no fresh full strict CPython suite has run on this candidate; canonical fixture outputs must match Expat. This benchmark does not establish full-suite compatibility.'
     allowed=y==x.replace(old_sentence,new_sentence)
   assert allowed,(mode,name,x,y)
   delta.append([x,y]);new.value=old.value
  assert ast.dump(b,include_attributes=False)==ast.dump(c,include_attributes=False),(mode,name)
  assert ''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(H/name),tofile=str(D/name)))==(D/(name+'.patch')).read_text()
  changes[name]=delta
 # Derive fixed count math from the actual unchanged iteration assignment.
 tree=ast.parse((D/'consumer_screen.py').read_text())
 assignments={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('ITERATIONS','ENGINES','RATIOS')}
 assert assignments['ENGINES']==('control','candidate','expat')
 assert assignments['RATIOS']==(('candidate','control'),('control','expat'),('candidate','expat'))
 counts={'conditions':len(assignments['ITERATIONS'])*2*2,'engines':3,'extensions':6,'preflights':72,'cohorts':168,'pairs':7,'timed_workers':504,'measured_parses':sum(assignments['ITERATIONS'].values())*4*7*3,'warmups':504}
 assert counts==a['counts'] and a['seed']==202609104412
 assert a['bounds']=={'prepare_cpu':4,'timing_cpu':0,'build_seconds':600,'preflight_aggregate_seconds':600,'worker_seconds':300,'timing_aggregate_seconds':1200}
 findings[mode]={'adaptation_sha256':expected_hash,'libraries':a['libraries'],'counts':counts,'allowed_constant_deltas':changes}
check('/tmp/oriole-literal-attribute-check-build-independent-review/review.json','51b5001bfcfab7c08efc2b52d33d16d1eaf96a88e541d66fe781327075e947e8')
check('/tmp/oriole-fat-pgo-python-protocol-independent-review/review.json','c69c24102466ff403b665ac52798d5504bd80e135bdb909d41c5ddc4e6cf4b6a')
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in inputs.items())
with gzip.open(O/'details.json.gz','wt') as f:json.dump({'inputs':inputs,'findings':findings},f,indent=2)
review={'status':'passed','date_utc':'2026-09-11','scope':'Independent source and saved binding review only; no producer, compiler, parser, preflight or timing was executed.','inputs_count':len(inputs),'cohorts':{m:{k:v for k,v in f.items() if k!='allowed_constant_deltas'} for m,f in findings.items()},'findings':['All six parser-library hashes, common header, 70 source files and pair-freeze match the reviewed build and native cohorts.','Worker bytes match the prior reviewed worker. Whole-controller AST differs only by enumerated engine labels, common-header path and explicit mode/compatibility captions; exact recorded patches reconstructed. This preserves the extension compile loop, conditions, seeded orders, ratios, callback digest, warmup/destruction boundaries and process-group watchdog/cleanup.','Both prepared cohorts retain 600s build, 600s preflight, 300s worker and 1200s timing aggregate limits; preparation CPU4 and timing CPU0 require root scheduling. All target-output directories remain absent.'],'limits':['Protocol readiness is not permission to run during the current ASan campaigns or C gates.','No fresh candidate strict CPython compatibility or elapsed result is established. Canonical fixture callback comparison can tolerate adjacent-text fragmentation and is separate from the strict suite.','The worker includes explicit destruction and callbacks in native lifecycle timing; imports/input reads/canonical checks/explicit gc.collect are outside, automatic GC remains enabled.','Ambient host cache/frequency/bandwidth and full application behavior are outside this fixed fixture experiment.'],'details_sha256':hashlib.sha256((O/'details.json.gz').read_bytes()).hexdigest()}
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps({'status':'passed','inputs':len(inputs),'review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest()}))
