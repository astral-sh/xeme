from pathlib import Path
import hashlib,json
p=Path(__file__).parent
h=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
files={str(x.relative_to(p)):h(x) for x in sorted(p.rglob('*')) if x.is_file() and x.name not in ('files.json','receipt.json')}
(p/'receipt.json').write_text(json.dumps({'status':'sealed','review_sha256':h(p/'review.json'),'files_before_receipt':files},indent=2)+'\n')
files['receipt.json']=h(p/'receipt.json')
(p/'files.json').write_text(json.dumps(files,indent=2)+'\n')
assert all(h(p/n)==v for n,v in files.items())
print(json.dumps({'review':h(p/'review.json'),'receipt':h(p/'receipt.json'),'index':h(p/'files.json'),'files':len(files)}))
