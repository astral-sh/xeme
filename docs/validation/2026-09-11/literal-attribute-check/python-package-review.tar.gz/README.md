# Literal-attribute Python package review

Passed on CPU 6: 46,028 assertions and 3,742 unchanged inspected inputs. The first attempt passed.

All 3,572 direct archive members match their indexes and live origins. Independent directory reconstruction confirms both complete nonbinary study trees, all review trees, source/build receipts, external compile sources and six project inputs. Each cohort retains exactly 1,728 raw streams/specifications for 72 preflight and 504 timed workers. All 3,595 producer input hashes match.

Both 70-file source archives match their manifests and live worktrees. Six nested tool sources match their manifest. All 18 regular ELF exclusions are exact and absent from the archive. Both Expat soname symlinks are excluded, retain relative link text and resolve to separately excluded files in their own consumer directory.

The four-file initial packaging failure remains intact: its symlink guard failed before archive writing. The final packager uses a separate output path and records the two aliases. No target or numerical audit was rerun. The normal `49b60a8b` and PGO `db6821c0` numerical reviews are byte-exact; report groups, regressions and library bindings match them. Controller-preparation authorship stays explicit.

Compiled-file checks cover direct members and the three source/tool archives identified here, not arbitrary recursive compressed data. Publication text, elapsed arithmetic and statistical interpretations remain outside this review. No producer files changed.

`generator.py`, raw attempt streams and compressed input/member/nested maps retain the independent checks. `receipt.json` and `files.json` seal this directory.
