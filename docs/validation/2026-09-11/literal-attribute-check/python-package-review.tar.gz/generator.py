"""Independent saved-only package/origin reconstruction; no producer execution."""
import ast, collections, gzip, hashlib, io, json, os, stat, tarfile
from pathlib import Path, PurePosixPath

P=Path('/tmp/oriole-literal-attribute-python-final-handoff')
O=Path('/tmp/oriole-literal-attribute-python-package-independent-review')
inputs={}; checks=0; payloads={}; expected={}; exclusions={}; aliases={}; nested=[]
def ck(v,msg):
 global checks
 checks+=1
 assert v,msg
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p); ck(p.is_file() and not p.is_symlink(),str(p)+' regular file')
 b=p.read_bytes(); inputs[str(p)]={'sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(p.stat().st_mode)}; return b
def load(p): return json.loads(read(p))
def save(n,v):
 b=(json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
 (O/n).write_bytes(gzip.compress(b,mtime=0) if n.endswith('.gz') else b)
def compiled(b): return b.startswith((b'\x7fELF',b'!<arch>\n'))
ck(os.sched_getaffinity(0)=={6},'CPU 6')
index=load(P/'files.json'); report=load(P/'report.json'); mapping=json.loads(gzip.decompress(read(P/'members.json.gz')))
ck(sha(read(P/'report.json'))=='4f2bcba6b81589f5f308f2b44844eb3bf2152015716afcd53cc81cfced755739','report identity')
ck(set(index)=={x.name for x in P.iterdir() if x.is_file()}-{'files.json'},'outer index complete')
for name,row in index.items():
 b=read(P/name); ck(sha(b)==row['sha256'] and len(b)==row['bytes'],'outer '+name)
ck(stat.S_IMODE(P.stat().st_mode)==0o555 and all(inputs[str(P/n)]['mode']==0o444 for n in index),'sealed outer permissions')
members={r['path']:r for r in mapping['members']}
ck(len(members)==len(mapping['members'])==3572,'member count and uniqueness')
archive=read(P/'details.tar.gz')
ck(sha(archive)==report['package']['archive_sha256']=='ea88fe3aafe25a3c8269a7059dccc394274665989e4c4289f8808ab8eeaf0c93','archive pinned')
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as t:
 rows=t.getmembers(); ck(len(rows)==3572 and {m.name for m in rows}==set(members),'all archive names exact')
 ck(len({m.name for m in rows})==len(rows),'no duplicate archive names')
 for m in rows:
  ck(m.isfile() and not m.issym() and not m.islnk() and m.mode==0o444,'regular readonly member '+m.name)
  pp=PurePosixPath(m.name); ck(not pp.is_absolute() and '..' not in pp.parts,'safe member path')
  b=t.extractfile(m).read(); r=members[m.name]
  ck(len(b)==m.size==r['bytes'] and sha(b)==r['sha256'],'member index '+m.name)
  ck(b==read(r['origin']),'exact live origin '+m.name)
  ck(not compiled(b),'no directly archived ELF/ar '+m.name)
  payloads[m.name]=b

def add(n,p):
 ck(n not in expected,'unique reconstructed member '+n); expected[n]=str(p)
def tree(label,root,allow=False):
 for p in sorted(root.rglob('*')):
  n=label+'/'+str(p.relative_to(root))
  if p.is_symlink():
   ck(allow and p.name=='libexpat.so.1','only expected symlink '+str(p)); aliases[n]=str(p); continue
  if not p.is_file(): continue
  b=read(p)
  if compiled(b):
   ck(allow,'compiled exclusion only in study'); exclusions[n]=str(p)
  else: add(n,p)
for mode in ['normal','pgo']:
 tree(mode+'/study',Path('/tmp/oriole-literal-attribute-'+mode+'-python-study'),True)
 tree(mode+'/review',Path('/tmp/oriole-literal-attribute-'+mode+'-python-independent-review'))
for label,root in [('initial-packaging-attempt','/tmp/oriole-literal-attribute-python-handoff'),('protocol-review','/tmp/oriole-literal-attribute-python-protocol-independent-review'),('candidate-source-review','/tmp/oriole-literal-attribute-check-source-independent-review'),('candidate-build-review','/tmp/oriole-literal-attribute-check-build-independent-review')]: tree(label,Path(root))
pair=Path('/tmp/oriole-literal-attribute-check-pgo-study')
for n in ['source.json','source.tar.gz','candidate.patch','source-checks.json','source-binding.json','pair-freeze.json','pair-report.json','vector-training-proof.json','vector-training-details.json.gz','tool-source.json','tool-source.tar.gz']: add('candidate-build/'+n,pair/n)
for n in ['source.json','source.tar.gz']: add('control-source/'+n,Path('/tmp/oriole-native-byte-count-pgo-study')/n)
build_pins={}
for mode in ['normal','pgo']:
 build=json.loads(payloads[mode+'/study/consumers/build.json'])
 ck(build['source_sha256_before']==build['source_sha256_after'],'compile inputs stable '+mode)
 for p,h in build['source_sha256_before'].items():
  b=read(p); ck(sha(b)==h,'compile input '+p); build_pins[p]=h
  if not compiled(b):
   n='external-sources/'+h+'-'+Path(p).name
   if n not in expected: add(n,Path(p))
manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
manifest=load(manifest_path); add('projects/corpus-manifest.json',manifest_path)
for project in manifest['projects']:
 row=next(x for x in project['files'] if x['role']=='input'); p=(manifest_path.parent/row['path']).resolve()
 ck(sha(read(p))==row['sha256'],'project input'); add('projects/'+project['name']+'/'+p.name,p)
ck(len(manifest['projects'])==6,'six project inputs')
add('package.py',Path(members['package.py']['origin']))
ck(expected=={n:r['origin'] for n,r in members.items()},'complete independently reconstructed inventory and origins')
ck(exclusions=={r['path']:r['origin'] for r in mapping['excluded_binaries']} and len(exclusions)==18,'all 18 compiled exclusions')
for r in mapping['excluded_binaries']:
 b=read(r['origin']); ck(compiled(b) and b.startswith(b'\x7fELF') and sha(b)==r['sha256'] and len(b)==r['bytes'],'excluded binary '+r['path'])
 ck(r['path'] not in members,'compiled file absent')
ck(aliases=={r['path']:r['origin'] for r in mapping['excluded_library_aliases']} and len(aliases)==2,'both aliases exact')
for r in mapping['excluded_library_aliases']:
 p=Path(r['origin']); target=p.resolve(strict=True)
 ck(str(p.readlink())==r['link_text'] and not Path(r['link_text']).is_absolute(),'relative alias text')
 ck(str(target)==r['target'] and target.parent==p.parent and not target.is_symlink(),'same consumer target')
 ck(sha(read(target))==r['target_sha256'] and str(target) in exclusions.values(),'alias target separately excluded')
 ck(r['path'] not in members,'alias absent from archive')
all_pins={r['origin'] for r in mapping['members']+mapping['excluded_binaries']}|set(build_pins)
ck(all_pins==set(mapping['all_input_hashes']) and len(all_pins)==3595,'complete producer input map')
for p,h in mapping['all_input_hashes'].items(): ck(sha(read(p))==h,'producer frozen input '+p)

for label in ['candidate-build','control-source']:
 source=json.loads(payloads[label+'/source.json']); mp=source['source_sha256']; ck(len(mp)==70,label+' 70 sources')
 with tarfile.open(fileobj=io.BytesIO(payloads[label+'/source.tar.gz']),mode='r:gz') as t:
  ms=t.getmembers(); ck(len(ms)==70 and len({m.name for m in ms})==70 and {m.name for m in ms}==set(mp),'nested source inventory')
  for m in ms:
   ck(m.isfile() and not m.issym() and not m.islnk(),'nested regular source')
   b=t.extractfile(m).read(); ck(not compiled(b) and sha(b)==mp[m.name],'nested source hash')
   ck(b==read(Path(source['worktree'])/m.name),'nested source live bytes')
   nested.append({'archive':label+'/source.tar.gz','member':m.name,'sha256':sha(b)})
toolmap=json.loads(payloads['candidate-build/tool-source.json'])
with tarfile.open(fileobj=io.BytesIO(payloads['candidate-build/tool-source.tar.gz']),mode='r:gz') as t:
 ms=t.getmembers(); ck(len(ms)==6 and {m.name for m in ms}==set(toolmap),'six nested tool sources')
 for m in ms:
  ck(m.isfile(),'regular tool source'); b=t.extractfile(m).read()
  ck(not compiled(b) and sha(b)==toolmap[m.name],'tool source hash')
  nested.append({'archive':'candidate-build/tool-source.tar.gz','member':m.name,'sha256':sha(b)})

coverage={}
for mode,wanted in [('normal','49b60a8b17ef89d3c70943280f90335a72d8f9cb9327e699cd9b93469fc12e81'),('pgo','db6821c028996387979d120ef755e1d96efd95cbce4e949741d664c25a6fcfca')]:
 review=json.loads(payloads[mode+'/review/review.json'])
 ck(sha(payloads[mode+'/review/review.json'])==wanted and read(P/(mode+'-review.json'))==payloads[mode+'/review/review.json'],'exact numerical review reused')
 for k in ['groups','regressions','library_bindings']: ck(report['cohorts'][mode][k]==review[k],'reported '+mode+' '+k+' exact prior review')
 ck(report['cohorts'][mode]['review_sha256']==wanted,'report review pointer')
 pref=json.loads(payloads[mode+'/study/screen/preflight.json']); result=json.loads(payloads[mode+'/study/screen/results.json'])
 ck(len(pref['processes'])==72 and len(result['processes'])==504,'recorded worker coverage')
 ck(sha(payloads[mode+'/study/screen/preflight.json'])==review['preflight_sha256'] and sha(payloads[mode+'/study/screen/results.json'])==review['results_sha256'],'same reviewed result inputs')
 raw=set()
 for rec in pref['processes']+result['processes']:
  spec=mode+'/study/screen/'+Path(rec['command'][-1]).name; ck(spec in members,'worker specification archived'); raw.add(spec)
  for stream in ['stdout','stderr']:
   n=mode+'/study/screen/'+rec[stream]; ck(n in members,'raw stream archived'); raw.add(n)
   ck(sha(payloads[n])==rec[stream+'_sha256'],'raw stream recorded digest')
 actual={n for n in members if n.startswith(mode+'/study/screen/')}- {mode+'/study/screen/preflight.json',mode+'/study/screen/results.json'}
 ck(raw==actual and len(raw)==1728,'all raw records exact inventory')
 coverage[mode]={'preflights':72,'timed_workers':504,'raw_streams_and_specs':len(raw),'review_sha256':wanted,'retained_regressions':len(review['regressions'])}
ck(report['roles']['numerical_reviewer'].find('authorship disclosed')>=0,'preparation authorship disclosed')
initial={n for n in members if n.startswith('initial-packaging-attempt/')}
ck(len(initial)==4 and not any(n.endswith('.tar.gz') for n in initial),'initial four files before archive')
failure=json.loads(payloads['initial-packaging-attempt/failure.json'])
ck(failure['status']=='failed' and 'libexpat.so.1' in failure['error'],'initial alias rejection retained')
old=payloads['initial-packaging-attempt/package-initial.py'].decode(); new=payloads['package.py'].decode()
ck(old.index("tree(mode+'/study',B,True)") < old.index('with tarfile.open('),'initial failure before archive-writing block')
ck("assert not f.is_symlink(),f" in old and "f.name=='libexpat.so.1'" in new,'bounded alias correction retained')
ck(read(P/'package.py')==payloads['package.py'],'final packaged generator exact')

for p,r in inputs.items():
 b=Path(p).read_bytes(); ck(sha(b)==r['sha256'] and len(b)==r['bytes'] and stat.S_IMODE(Path(p).stat().st_mode)==r['mode'],'unchanged audited input '+p)
for r in mapping['excluded_library_aliases']: ck(str(Path(r['origin']).readlink())==r['link_text'],'alias remains unchanged')
save('inputs.json.gz',inputs); save('members.json.gz',mapping['members']); save('nested.json.gz',nested)
save('review.json',{'status':'passed','scope':'CPU 6 independent saved-only package inventory/origin/hash/source-archive and exclusion review. No arithmetic reconstruction, target execution, or producer mutation.','package':str(P),'report_sha256':sha(read(P/'report.json')),'archive_sha256':sha(archive),'members':3572,'producer_input_hashes':3595,'audited_unchanged_inputs':len(inputs),'assertions':checks,'nested_source_files':140,'nested_tool_files':6,'compiled_exclusions':18,'excluded_aliases':mapping['excluded_library_aliases'],'coverage':coverage,'initial_packaging_failure':'All four original attempt files retained; libexpat.so.1 symlink guard rejected before archive creation. Final output uses a separate path and excludes relative same-directory aliases with target hashes.','source_provenance':'Both 70-file archived source maps match exact live worktrees. All six nested tool sources match the packaged map. All direct archive member origins and complete study trees match; raw data and all adversarial rows remain retained.','numerical_review_reuse':'Normal49b60a8b and PGOdb6821c0 copied byte-exact; report groups, regressions and library pointers match. Numerical reconstruction not repeated; reviewer preparation authorship remains explicit.','limitations':['Compiled filtering is verified for every direct member and the three identified nested source/tool archives; arbitrary recursive compressed-data scanning is not claimed.','No interpretation of elapsed arithmetic, statistical significance, strict compatibility or current publication-copy links is added.'],'generator_sha256':sha(Path(__file__).read_bytes())})
print(json.dumps({'status':'passed','checks':checks,'inputs':len(inputs),'review_sha256':sha((O/'review.json').read_bytes())}))
