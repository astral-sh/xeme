import gzip, hashlib, json, os, stat
from pathlib import Path
P=Path('/tmp/oriole-literal-attribute-python-package-independent-review')
assert os.sched_getaffinity(0)=={6}
def record(p):
 b=p.read_bytes(); return {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
r=json.loads((P/'review.json').read_text())
assert r['generator_sha256']==record(P/'generator.py')['sha256']
assert (P/'attempt01.stderr').read_bytes()==b''
a=json.loads((P/'attempt01.stdout').read_text())
assert a['status']=='passed' and a['review_sha256']==record(P/'review.json')['sha256']
inputs=json.loads(gzip.decompress((P/'inputs.json.gz').read_bytes()))
for name,v in inputs.items():
 p=Path(name); assert record(p)=={k:v[k] for k in ['sha256','bytes']},name
 assert stat.S_IMODE(p.stat().st_mode)==v['mode'],name
for a in r['excluded_aliases']:
 p=Path(a['origin']); assert str(p.readlink())==a['link_text'] and str(p.resolve())==a['target']
receipt={'status':'sealed','attempt':1,'review':record(P/'review.json'),'generator':record(P/'generator.py'),'input_map':record(P/'inputs.json.gz'),'unchanged_inputs_at_seal':len(inputs),'scope':r['scope']}
(P/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
index={p.name:record(p) for p in sorted(P.iterdir()) if p.is_file() and p.name!='files.json'}
(P/'files.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
for n,v in json.loads((P/'files.json').read_text()).items(): assert record(P/n)==v
print(json.dumps({'review':record(P/'review.json'),'receipt':record(P/'receipt.json'),'index':record(P/'files.json'),'indexed_files':len(index)},indent=2))
