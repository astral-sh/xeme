# Literal-attribute native timing audit

Both saved cohorts passed independent raw-data audits on the first attempt. All worker records, stream bytes, callback observations, execution orders, process medians, paired ratios and frozen-file inventories verify.

| Cohort | Real candidate/control time | Real lower/higher | Generated candidate/control time | Generated lower/higher |
| --- | --- | --- | --- | --- |
| Normal, no PGO | **1.002102987038012** | 12 / 12 | **1.021218811320024** | 1 / 3 |
| ThinPGO | **0.9786338733080541** | 23 / 1 | **0.9817869569080734** | 4 / 0 |

Lower time ratios are faster. The PGO Maven namespace-enabled 4 KiB condition remains a regression. All 15 normal candidate/control regressions and all three ratio families' adverse rows are retained in compressed records. Against the matching Expat build, the candidate real geometric ratios are 1.6190466322292334 (normal; 1/24 lower) and 1.375370450159329 (PGO; 7/24 lower).

Each cohort retains 84 preflights, 588 timed workers, 196 seeded cohorts, 105,420 measured timings plus 588 timed warmups. All 672 immediate records and 106,176 samples, including preflight samples, were checked per cohort. The complete prior native raw reader was reused without changing its reconstruction code; cohort setup and author-summary schema handling are retained separately.

Normal and PGO are separate sequential campaigns. No cross-cohort ratio, statistical significance or full-application claim follows. The timer includes parser creation, callbacks and destruction. Absolute library handles and versions are checked; there is no per-worker `dladdr` attestation. Original callback-digest, historical Expat build and shared-host limitations remain. Source/build/training reviews are linked by hash rather than repeated.

This review used saved-file Python on CPU 6 only. No parser, compiler, profiler, training, test or timing jobs ran. The published freeze identities are normal `96f1b853…` and PGO `d8b24b6e…`; producer files remain unchanged. No package audit or adoption decision is claimed.
