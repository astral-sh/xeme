# Literal-attribute correctness evidence

The original C/API and strict CPython controls match the accepted baseline. All 4,740 API rows retain 4,347 passes and 393 failures under original resource bounds. The independent strict review records exact method outcomes, including the original failures and skips.

The archive preserves raw results, controllers, preparation history and independent reviews. No timing or new normal-workspace claim is made. Successful custom-alias raw pairs were not saved by the unchanged helper; the existing limitation is retained. C consumers have ASan/UBSan instrumentation; linked optimized Rust libraries do not, and leak detection was disabled.

See [summary.json](summary.json), [archive-members.json](archive-members.json) and [evidence.tar.gz](evidence.tar.gz). Every included member and excluded binary was rehashed against its original; nested source archives were fully read.
