"""Seal existing correctness evidence only; never execute parser/compiler/test commands."""
from pathlib import Path
import argparse,hashlib,io,json,tarfile
ap=argparse.ArgumentParser();ap.add_argument('--strict-review',required=True);args=ap.parse_args()
O=Path('/tmp/oriole-literal-attribute-correctness-handoff');O.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
C=Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates-cpu5')
S=Path('/tmp/oriole-literal-attribute-thin-pgo-cpython-gates')
strict_review=Path(args.strict_review)
assert load(C/'summary.json')['status']=='correctness_parity_gates_passed'
assert load(S/'controller.json')['status']=='completed_with_failures_retained_pending_outcome_audit'
assert load(strict_review/'review.json')['status']=='passed'
groups={
 'c-gates':C,
 'strict-cpython':S,
 'preparation/cpu4':Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates'),
 'preparation/strict-cpython':Path('/tmp/oriole-literal-attribute-strict-cpython-preparation'),
 'reviews/c-gates':Path('/tmp/oriole-literal-attribute-c-gates-independent-review'),
 'reviews/strict-cpython':strict_review,
 'reviews/cpu5-preparation':Path('/tmp/oriole-literal-attribute-gate-cpu5-independent-review'),
 'reviews/strict-preparation':Path('/tmp/oriole-literal-attribute-strict-controller-independent-review'),
}
extras={
 'execution/c-gates-completion.json':Path('/tmp/oriole-literal-attribute-c-gates-completion.json'),
 'execution/strict-launch.log':Path('/tmp/oriole-literal-attribute-thin-pgo-cpython-launch.log'),
 'execution/strict-controller.py':Path('/tmp/oriole-literal-attribute-thin-pgo-cpython-gates.py'),
 'preparation/strict-preparation-launch.log':Path('/tmp/oriole-literal-strict-cpython-preparation-launch.log'),
 'preparation/cpu5-preparer.py':Path('/tmp/oriole-prepare-literal-gates-cpu5.py'),
 'preparation/cpu5-readback.py':Path('/tmp/oriole-check-literal-gates-cpu5-revision.py'),
 'package.py':Path(__file__),
 'baseline/api-results.json':Path('/tmp/oriole-current-thin-pgo-gates/api-native/upstream-api/results.json'),
}
for linkage in ('shared','static'):
 for name in ('tests.log','summary.json','origin.log','probe.log'):
  extras[f'baseline/strict-{linkage}/{name}']=Path('/tmp/oriole-current-thin-pgo-cpython-gates')/linkage/name
inputs=dict(extras)
for prefix,root in groups.items():
 for p in sorted(root.rglob('*')):
  if p.is_file():
   n=prefix+'/'+str(p.relative_to(root));assert n not in inputs;inputs[n]=p
members=[];excluded=[]
with tarfile.open(O/'evidence.tar.gz','w:gz',compresslevel=6) as tf:
 for n,p in sorted(inputs.items()):
  b=p.read_bytes();r={'member':n,'origin':str(p),'sha256':sha(b),'bytes':len(b)}
  if b[:4]==b'\x7fELF' or b[:8]==b'!<arch>\n':r['reason']='compiled ELF or static archive';excluded.append(r);continue
  if '__pycache__' in p.parts or p.suffix=='.pyc':r['reason']='Python bytecode cache';excluded.append(r);continue
  info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(b));members.append(r)
with tarfile.open(O/'evidence.tar.gz','r:gz') as tf:
 regular=[m for m in tf.getmembers() if m.isfile()];assert len(regular)==len(members)
 expected={m['member']:m for m in members};assert set(expected)=={m.name for m in regular}
 nested=[]
 for m in regular:
  data=tf.extractfile(m).read();r=expected[m.name];assert len(data)==r['bytes'] and sha(data)==r['sha256']
  assert sha(Path(r['origin']).read_bytes())==r['sha256']
  if m.name.endswith('source.tar.gz'):
   with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as nested_tf:
    rows=[x for x in nested_tf.getmembers() if x.isfile()];nested.append({'member':m.name,'files':len(rows),'sha256':{x.name:sha(nested_tf.extractfile(x).read()) for x in rows}})
for r in excluded:assert sha(Path(r['origin']).read_bytes())==r['sha256']
manifest={'status':'readback_passed','archive_sha256':sha((O/'evidence.tar.gz').read_bytes()),'included_files':len(members),'excluded_files':len(excluded),'members':members,'excluded':excluded,'nested_source_readback':nested}
(O/'archive-members.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary={'status':'correctness_evidence_sealed','c_gate_summary':load(C/'summary.json'),'strict_independent_review_sha256':sha((strict_review/'review.json').read_bytes()),'archive':{k:manifest[k] for k in ('archive_sha256','included_files','excluded_files')},'scope':'Existing saved C/API/adversarial and strict CPython correctness evidence. No parser/build/timing jobs or new criteria were introduced by packaging. CPU4 preparation and CPU5 revision remain distinct; only CPU5 gates ran.','exclusions':'Compiled ELF/static libraries and Python bytecode caches excluded with origin/byte/hash records. Referenced full build-pair and benchmark evidence are separate, not claimed to be wholly included here.'}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(O/'README.md').write_text('# Literal-attribute correctness evidence\n\nThe original C/API and strict CPython controls match the accepted baseline. All 4,740 API rows retain 4,347 passes and 393 failures under original resource bounds. The independent strict review records exact method outcomes, including the original failures and skips.\n\nThe archive preserves raw results, controllers, preparation history and independent reviews. No timing or new normal-workspace claim is made. Successful custom-alias raw pairs were not saved by the unchanged helper; the existing limitation is retained. C consumers have ASan/UBSan instrumentation; linked optimized Rust libraries do not, and leak detection was disabled.\n\nSee [summary.json](summary.json), [archive-members.json](archive-members.json) and [evidence.tar.gz](evidence.tar.gz). Every included member and excluded binary was rehashed against its original; nested source archives were fully read.\n')
(O/'package.py').write_bytes(Path(__file__).read_bytes())
files={p.name:sha(p.read_bytes()) for p in sorted(O.iterdir()) if p.is_file()}
(O/'files.json').write_text(json.dumps(files,indent=2)+'\n')
assert all(sha((O/n).read_bytes())==h for n,h in files.items())
print(json.dumps({'path':str(O),**summary['archive'],'files_index_sha256':sha((O/'files.json').read_bytes())}))
