"""Independent saved normal/PGO native audit; no target execution."""
from pathlib import Path
from collections import Counter
import ast, copy, difflib, gzip, hashlib, json, math, os, random, statistics, sys

mode=sys.argv[1];assert mode in ['normal','pgo']
OUT=Path(__file__).resolve().parent;O=OUT/mode;O.mkdir(exist_ok=True)
R=Path('/tmp/oriole-literal-attribute-'+mode+'-native-study');S=R/'native-screen'
tracked={};passed_checks=0
def read(path):
    path=Path(path);raw=path.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(path),value)==value,str(path)
    return raw
def h(path):read(path);return tracked[str(path)]
def j(path):return json.loads(read(path))
def ck(name,condition):
    global passed_checks
    assert condition,name
    passed_checks+=1
key=lambda value:json.dumps(value,sort_keys=True)
engines=['control','candidate','expat']
ratio_names=['candidate_over_control','candidate_over_expat','control_over_expat']
ck('CPU6 saved-only audit',__debug__ and os.sched_getaffinity(0)=={6})
freeze_hash={'normal':'96f1b853e4bec110296d5373d23083af8b8c21e31f8f7cb35f97088a855e6a1f','pgo':'d8b24b6e845d3f844888dba2d74dcddaef76a1c1ed943e231701952071b2ed14'}[mode]
frozen_count={'normal':686,'pgo':685}[mode]
ck('final freeze pinned',h(R/'freeze.json')==freeze_hash)
freeze=j(R/'freeze.json')
ck('complete frozen inventory',freeze['status']=='frozen' and freeze['count']==len(freeze['files'])==frozen_count and set(freeze['files'])|{'freeze.json'}=={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()})
for n,v in freeze['files'].items():ck('frozen bytes '+n,h(R/n)==v['sha256'] and len(read(R/n))==v['bytes'])
ck('freeze byte sum',sum(v['bytes'] for v in freeze['files'].values())==freeze['bytes'])
reviews={
 '/tmp/oriole-current-pgo-lto-native-independent-review/review.json':'58aa681104408e074836fdb73230f0e2dcdfdbabc06f37483dde33f4572d38c2',
 '/tmp/oriole-literal-attribute-check-build-independent-review/review.json':'51b5001bfcfab7c08efc2b52d33d16d1eaf96a88e541d66fe781327075e947e8',
 '/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json':'cec78c70730e111f139a6fab70089e1629ffe3336843106585a35922a525bbc9',
 '/tmp/oriole-native-byte-count-pgo-training-independent-review/review.json':'9e7a8451c1429ea888904ae16ba6c120e0a86ec4e4695a72bfe7dce5ff9e0934',
 '/tmp/oriole-current-pgo-expat-reuse-independent-review/review.json':'9a53fcddfa80a039da800284a3ebdbe7d83316fe83768ed1f4d7e4770b53b2d9'}
for p,v in reviews.items():ck('sealed review '+p,h(p)==v)
prior=j('/tmp/oriole-current-pgo-lto-native-independent-review/review.json')
prior_generator=Path('/tmp/oriole-current-pgo-lto-native-independent-review/generator.py')
ck('prior complete raw generator pinned',h(prior_generator)==prior['generator_sha256'])
prior_text=read(prior_generator).decode()
core=prior_text[prior_text.index("manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')"):prior_text.index("\n\nck('all588 paired ratios and84 condition medians exact'")]
ck('complete raw core exact prior bytes',read(OUT/'raw-core.py').decode()==core)
protocol=j(S/'protocol.json');pre=j(S/'preflight.json');results=j(S/'results.json')
adaptation=j(R/'adaptation.json');controller=j(R/'controller.json');published=j(R/'summary.json')
ck('protocol fixed campaign',protocol['pairs']==7 and protocol['seed']==2026091003 and protocol['preflights']==84 and protocol['timed_workers']==588)
ck('successful phase records',pre['status']==results['status']=='passed' and results['affinity']==[0])
ck('phase hash links',pre['protocol_sha256']==results['protocol_sha256']==h(S/'protocol.json') and results['preflight_sha256']==h(S/'preflight.json'))
ck('14 identical phase pins',len(protocol['hashes'])==14 and protocol['hashes']==pre['hashes_before']==pre['hashes_after']==results['hashes_before']==results['hashes_after'])
for p,v in protocol['hashes'].items():ck('protocol origin '+p,h(p)==v)
expected={
 'normal':{'control':'0c8c58750c029174bfb522cee85949c11360696978e13b92d96e21f84461e96d','candidate':'8ad88e13e07c7c321fe13b36528b63e392cfd48db22722bf955a14de7241889f','expat':'7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'},
 'pgo':{'control':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','candidate':'8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a','expat':'12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'}}[mode]
ck('three engine mappings',list(protocol['libraries'])==engines and adaptation['libraries']==protocol['libraries'])
for name,row in protocol['libraries'].items():ck('reviewed library '+name,h(row['path'])==row['sha256']==expected[name])
P=Path('/tmp/oriole-literal-attribute-check-pgo-study')
ck('pair report/source binding',adaptation['pair_report_sha256']==h(P/'pair-report.json') and adaptation['source_binding_sha256']==h(P/'source-binding.json'))
ck('candidate source identity',adaptation['source_manifest_sha256']==h(P/'source.json')=='1120c74e96c7f562cecfa25db227a830e8a1667a67dba30732ca039fb5e7dbec')
oldroot=Path('/tmp/oriole-current-pgo-lto-native-study');oldpath=oldroot/'native_screen.py'
oldtext=read(oldpath).decode();newtext=read(R/'native_screen.py').decode()
ck('parent controller pin',h(oldpath)==adaptation['parent_controller_sha256']=='5269999b6229d9e5862303d1f61f2e761ca859d3a7c683cc21a9237dd1e353a3')
ck('current controller pin',h(R/'native_screen.py')==adaptation['controller_sha256']==controller['controller_sha256'])
ck('wrapper exact inherited bytes',h(oldroot/'run.py')==h(R/'run.py')==adaptation['wrapper_sha256']==adaptation['parent_wrapper_sha256']==controller['wrapper_sha256']=='5f41a419e800e95954424e2a85d2ee988609d830db18dc85c469af801cd8aef5')
ck('controller patch exact',h(R/'controller.patch')==adaptation['controller_patch_sha256'] and read(R/'controller.patch').decode()==''.join(difflib.unified_diff(oldtext.splitlines(True),newtext.splitlines(True),fromfile=str(oldpath),tofile=str(R/'native_screen.py'))))
oldast=ast.parse(oldtext);newast=ast.parse(newtext)
def assignment(tree,name):return next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
for name in ['run','digest','save']:
    nodes=[next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name) for tree in [oldast,newast]]
    ck('worker/helper AST '+name,ast.dump(nodes[0])==ast.dump(nodes[1]))
for name in ['iterations','conditions']:ck('fixed AST '+name,ast.dump(assignment(oldast,name))==ast.dump(assignment(newast,name)))
ck('exact three ratios',[a+'_over_'+b for a,b in ast.literal_eval(assignment(newast,'ratios').value)]==ratio_names)
# Allow only the module description, root, engine mapping, ratio labels and
# protocol scope. All other module code, including the entire tail, is equal.
normalized=copy.deepcopy(oldast);normalized.body[0]=copy.deepcopy(newast.body[0])
for name in ['root','libraries','ratios']:
    oldnode=assignment(normalized,name);normalized.body[normalized.body.index(oldnode)]=copy.deepcopy(assignment(newast,name))
oldprotocol=assignment(normalized,'protocol').value;newprotocol=assignment(newast,'protocol').value
scope_index=next(i for i,k in enumerate(oldprotocol.keys) if isinstance(k,ast.Constant) and k.value=='scope')
oldprotocol.values[scope_index]=copy.deepcopy(newprotocol.values[scope_index])
ck('entire controller AST expected changes only',ast.dump(normalized)==ast.dump(newast))
ck('passed aggregate controller',controller['status']=='passed' and len(controller['commands'])==2)
for row,(phase,cpu,bound) in zip(controller['commands'],[('preflight',5,600),('time',0,1200)],strict=True):
    ck('phase command bounds and stream '+phase,row['phase']==phase and row['exit']==0 and row['timeout']==bound and 0<row['end']-row['start']<bound and row['command']==['taskset','-c',str(cpu),'python3',str(R/'native_screen.py'),phase] and h(R/(phase+'-controller.log'))==row['log_sha256'])
ck('preflight precedes timing',controller['commands'][0]['end']<=controller['commands'][1]['start'])
completion=j(R/'completion.json')
ck('completion counts',completion['status']=='complete' and completion['controller_exit']==0 and completion['preflights']==84 and completion['timed_workers']==588 and completion['summary_sha256']==h(R/'summary.json'))
for name in ['source_build_freeze','build_review','ASan_readiness']:
    row=completion[name];ck('completion pinned evidence '+name,h(row['path'])==row['sha256'])
if mode=='normal':
    launch=j(R/'launch-prerequisites.json')
    for p,v in launch['prerequisites'].items():ck('launch prerequisite '+p,h(p)==v)

manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');manifest=j(manifest_path)
fixtures={}
for project in manifest['projects']:
    entry=next(row for row in project['files'] if row['role']=='input');path=(manifest_path.parent/entry['path']).resolve()
    ck('original project input '+project['name'],h(path)==entry['sha256']);fixtures[project['name']]=str(path)
ck('six real projects',set(fixtures)=={'vulkan','wayland','maven','batik','gtk','docbook'})
fixtures['generated-rare-declarations']='/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml';fixtures['generated-entities']='/tmp/oriole-grammar-bench-plain/entities.xml'
fixed={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
conditions=[{'name':name,'input':path,'chunk':chunk,'namespaces':ns,'iterations':fixed[name]} for chunk in [4096,65536] for name,path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False,True])]
ck('all28 fixed conditions exact',conditions==protocol['conditions'] and len(conditions)==28 and len({key(c) for c in conditions})==28)
driver=Path('/tmp/oriole-grammar-bench-plain/native-driver');driver_source=Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')
origin_path=Path('/tmp/oriole-grammar-bench-plain/summary.json');origin=j(origin_path)
ck('unchanged native driver original build identity',origin['status']=='passed' and origin['sha256_before'][str(driver)]==origin['sha256_after'][str(driver)]==h(driver) and origin['sha256_before'][str(driver_source)]==origin['sha256_after'][str(driver_source)]==h(driver_source))
driver_code=read(driver_source).decode()
ck('explicit driver library handle','dlopen(argv[1], RTLD_NOW | RTLD_LOCAL)' in driver_code and 'dlsym(library, symbol)' in driver_code)
ck('native timer scope',driver_code.index('fread(data')<driver_code.index('double before = now();')<driver_code.index('Parser parser =')<driver_code.index('api.destroy(parser);\n        double elapsed = now() - before;'))

ordinal=0;streams=[];observed_by_condition={};sample_counts=Counter();process_medians={key(c):{engine:[] for engine in engines} for c in conditions}
def process(row,condition,pair,cpu,count):
    global ordinal
    worker=S/f'worker-{ordinal:04d}.json';saved=j(worker)
    ck('immediate worker original fields '+str(ordinal),set(saved)=={'condition','engine','pair','command','returncode','stdout','stderr'} and saved=={field:row[field] for field in saved})
    ck('worker metadata '+str(ordinal),row['condition']==condition and row['pair']==pair and row['engine'] in engines and row['returncode']==0 and row['stderr']=='')
    engine=row['engine'];command=['taskset','-c',str(cpu),str(driver),protocol['libraries'][engine]['path'],condition['input'],str(condition['chunk']),str(count)]+(['namespaces'] if condition['namespaces'] else [])
    ck('worker command '+str(ordinal),row['command']==command)
    data=json.loads(row['stdout']);samples=data['samples']
    ck('worker output version '+str(ordinal),data['version']==('expat_2.8.4' if engine.startswith('expat') else 'oriole_compat_2.8.4') and set(data)=={'version','samples'})
    ck('all sample fields '+str(ordinal),all(set(sample)=={'iteration','warmup','seconds','hash','elements','text_bytes'} and isinstance(sample['seconds'],(int,float)) and math.isfinite(sample['seconds']) and sample['seconds']>0 and isinstance(sample['elements'],int) and sample['elements']>=0 and isinstance(sample['text_bytes'],int) and sample['text_bytes']>=0 and len(sample['hash'])==16 and all(ch in '0123456789abcdef' for ch in sample['hash']) for sample in samples))
    ck('sample count/indices/warmup '+str(ordinal),len(samples)==count+1 and [sample['iteration'] for sample in samples]==list(range(count+1)) and [sample['warmup'] for sample in samples]==[True]+[False]*count)
    observations=sorted({(sample['hash'],sample['elements'],sample['text_bytes']) for sample in samples})
    ck('sample callback observations '+str(ordinal),len(observations)==1 and row['observations']==[list(value) for value in observations])
    median=statistics.median(sample['seconds'] for sample in samples[1:])
    ck('worker median exact '+str(ordinal),median==row['median_seconds'])
    stage='preflight' if pair==-1 else 'timed'
    sample_counts[stage+'_workers']+=1;sample_counts[stage+'_warmups']+=1;sample_counts[stage+'_measured']+=count
    streams.append({'ordinal':ordinal,'worker_sha256':h(worker),'condition':condition,'pair':pair,'engine':engine,'stdout_sha256':hashlib.sha256(row['stdout'].encode()).hexdigest(),'stderr_sha256':hashlib.sha256(row['stderr'].encode()).hexdigest(),'measured_samples':count,'median_seconds':median})
    ordinal+=1
    return observations,median

ck('84 preflight records',len(pre['rows'])==84)
for index,condition in enumerate(conditions):
    rows=pre['rows'][3*index:3*index+3]
    ck('preflight engine order '+str(index),[row['engine'] for row in rows]==engines)
    observations=[process(row,condition,-1,5,1)[0] for row in rows]
    ck('three-engine preflight observations '+str(index),all(x==observations[0] for x in observations))
    observed_by_condition[key(condition)]=observations[0]

rng=random.Random(protocol['seed']);jobs=[(condition,pair) for condition in conditions for pair in range(7)];rng.shuffle(jobs)
ck('196 complete unique cohorts',len(results['rows'])==len(jobs)==196 and len({(key(row['condition']),row['pair']) for row in results['rows']})==196)
ratios={key(c):{name:[] for name in ratio_names} for c in conditions}
for index,((condition,pair),group) in enumerate(zip(jobs,results['rows'],strict=True)):
    order=engines.copy();rng.shuffle(order)
    ck('seeded cohort and engine order '+str(index),group['condition']==condition and group['pair']==pair and group['order']==order and [row['engine'] for row in group['processes']]==order)
    seconds={}
    for row in group['processes']:
        observations,median=process(row,condition,pair,0,condition['iterations'])
        ck('timed observations equal preflight',observations==observed_by_condition[key(condition)])
        seconds[row['engine']]=median;process_medians[key(condition)][row['engine']].append(median)
    for name in ratio_names:
        numerator,denominator=name.split('_over_');ratios[key(condition)][name].append(seconds[numerator]/seconds[denominator])
computed=[{'condition':c,'paired_ratios':ratios[key(c)],'median_ratios':{name:statistics.median(values) for name,values in ratios[key(c)].items()}} for c in conditions]
ck('all588 paired ratios and84 medians exact',results['summary']==computed)
ck('exact672 immediate worker files no extras',ordinal==672 and sorted(p.name for p in S.glob('worker-*.json'))==[f'worker-{index:04d}.json' for index in range(672)])
ck('sample counts all retained',dict(sample_counts)=={'preflight_workers':84,'preflight_warmups':84,'preflight_measured':84,'timed_workers':588,'timed_warmups':588,'timed_measured':105420})
groups={}
for label,predicate in [('real',lambda c:not c['name'].startswith('generated-')),('generated',lambda c:c['name'].startswith('generated-')),('real_plain',lambda c:not c['name'].startswith('generated-') and not c['namespaces']),('real_namespaces',lambda c:not c['name'].startswith('generated-') and c['namespaces'])]:
    selected=[row for row in computed if predicate(row['condition'])]
    groups[label]={'conditions':len(selected),'ratios':{}}
    for name in ratio_names:
        values=[row['median_ratios'][name] for row in selected]
        groups[label]['ratios'][name]={'geomean':math.exp(sum(math.log(value) for value in values)/len(values)),'below_one':sum(value<1 for value in values)}

# Cohort-specific author schema; all arithmetic below derives from the unchanged
# complete raw worker reconstruction above.
author_groups={label:{name:{'geomean':r['geomean'],'lower':r['below_one'],'higher':sum(row['median_ratios'][name]>1 for row in computed if row['condition']['name'].startswith('generated-')==(label=='generated')),'count':group['conditions']} for name,r in group['ratios'].items()} for label,group in groups.items() if label in ['real','generated']}
all_adverse={name:[{'condition':r['condition'],'ratio':r['median_ratios'][name]} for r in computed if r['median_ratios'][name]>1] for name in ratio_names}
ck('author summary exact from raw workers',published['status']=='passed' and published['results_sha256']==h(S/'results.json') and published['groups']==author_groups and published['regressions']==all_adverse['candidate_over_control'])
ck('preflight stdout exact',j(R/'preflight-controller.log')=={'status':'passed','preflights':84,'protocol_sha256':h(S/'protocol.json')})
ck('timing stdout exact',j(R/'time-controller.log')=={'status':'passed','timed_workers':588,'summary':computed})
ck('complete675 native screen files',{p.name for p in S.iterdir()}=={f'worker-{i:04d}.json' for i in range(672)}|{'protocol.json','preflight.json','results.json'})
expected_real={'normal':(1.002102987038012,12,12),'pgo':(0.9786338733080541,23,1)}[mode]
real=author_groups['real']['candidate_over_control']
ck('retained real outcome',(real['geomean'],real['lower'],real['higher'])==expected_real)
if mode=='pgo':
    ck('one retained Maven namespace regression',len(all_adverse['candidate_over_control'])==1 and all_adverse['candidate_over_control'][0]['condition']['name']=='maven' and all_adverse['candidate_over_control'][0]['condition']['namespaces'] and all_adverse['candidate_over_control'][0]['condition']['chunk']==4096)
else:ck('all15 normal adverse rows retained',len(all_adverse['candidate_over_control'])==15)
method=j(OUT/'method.json')
ck('auditor source pin',h(OUT/'generator.py')==method['generator_sha256'])
for name in ['setup.py','raw-core.py','tail.py','prepare-audit.py']:h(OUT/name)
ck('all inspected bytes unchanged',all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in tracked.items()))
condition_table=[{'condition':r['condition'],'median_process_seconds':{e:statistics.median(v) for e,v in process_medians[key(r['condition'])].items()},'median_ratios':r['median_ratios'],'paired_ratios':r['paired_ratios']} for r in computed]
for name,value in [('streams.json.gz',streams),('conditions.json.gz',condition_table),('all-adverse-conditions.json.gz',all_adverse),('checked-files.json.gz',tracked)]:
    (O/name).write_bytes(gzip.compress((json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
report={'status':'passed','cohort':mode,'scope':'Independent saved native worker, identity, order and arithmetic audit; no target execution and no cross-cohort ratios.',
 'freeze_sha256':freeze_hash,'frozen_files':frozen_count,'source_manifest_sha256':adaptation['source_manifest_sha256'],'libraries':protocol['libraries'],'reused_reviews':reviews,
 'counts':dict(sample_counts)|{'conditions':28,'real_conditions':24,'generated_conditions':4,'cohorts':196,'immediate_workers':672,'native_screen_files':675,'paired_ratios':588,'condition_ratio_medians':84,'all_samples':106176},
 'groups':author_groups,'candidate_control_regressions':all_adverse['candidate_over_control'],'all_ratio_adverse_rows':'all-adverse-conditions.json.gz',
 'controller':'Entire module AST equals reviewed prior controller after only description/root/library/ratio-label/protocol-scope changes. Worker, fixtures, iterations, preflight/timing and aggregation tail unchanged. Wrapper byte exact;90-second workers,600-second preflight and1200-second timing bounds.',
 'method':['All672 immediate records compared with aggregate copies, complete commands, return codes, stdout/stderr, versions and sample fields. All106176 sample indices, warmup flags and finite positive durations verified.','All84 preflight callback observations and105420 measured timings retained. One excluded warmup per worker; every process median reconstructed.','Seed2026091003 reconstructs196 cohort orders and588 engine positions. All588 paired ratios and84 condition medians match raw summary exactly; all aggregate means/counts and adverse rows match author summary.','All frozen members, inventories, external protocol hashes, source/build review links and completion/phase logs checked.'],
 'driver':{'binary_sha256':h(driver),'source_sha256':h(driver_source),'binding':'Absolute dlopen RTLD_NOW|RTLD_LOCAL handle plus dlsym; versions and arguments checked, no per-worker dladdr attestation.','timer':'Parser creation, handlers, parse/callbacks and destruction included; input I/O, loading and process startup excluded.'},
 'limitations':['Normal and PGO are separate sequential campaigns; no cross-cohort performance ratio or causal interaction estimate.','Shared host: scheduling receipts say competing target work was held, but historical absence of interference is not independently observed. No statistical significance claim.','PGO variants use their separately generated training profiles; baseline/profile/compiler and historical Expat differences remain as documented by sealed reviews. No fresh Expat training claimed.','Only six project XML inputs and generated controls; no full applications. Batik external DTD is not loaded. Callback hashes/counts do not certify exact fragmentation, positions or full correctness.','Every regression and every Expat comparison retained. No adoption recommendation or completed C/CPython correctness claim.','No parser, compiler, training, profiler, test or timing jobs ran during this CPU6 readback.'],
 'passed_checks':passed_checks,'checked_files':len(tracked),'all_inspected_bytes_unchanged':True,'generator_sha256':method['generator_sha256']}
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','mode':mode,'review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest(),'checks':passed_checks,'checked_files':len(tracked),'groups':author_groups}))
