# Literal attribute eligibility: native screen

The candidate is promising only under PGO in these native measurements. It is
not selected; full candidate correctness and actual CPython results are pending.

| Matched cohort | Real-project time / control | Faster conditions | Generated time / control |
| --- | ---: | ---: | ---: |
| No PGO | 1.002103 | 12/24 | 1.021219 |
| Fresh ThinPGO | 0.978634 | 23/24 | 0.981787 |

Smaller is faster. Each condition is the median of seven paired process-median
ratios. The PGO candidate takes 1.37537 times Expat PGO's time across real
conditions; it wins 7/24. Maven with namespaces at 4 KiB is the sole PGO
regression, +0.5937%. All normal and PGO adverse cases remain in the archive.

Each separate cohort passed 84 preflights and 588 timed workers over all six
real projects and two generated controls. No conditions or samples were removed.
The original driver, iteration counts, seed and 90-second worker / 1200-second
timing bounds were preserved. Other target jobs were held throughout timing.

The source change fuses two literal-attribute eligibility scans. Root authored
the implementation and passed 58 core tests, Clippy and formatting. Independent
source and build reviews passed. Fresh normal/generate/use phases contain nine
actual workspace compiler invocations with effective C-only ThinLTO and 288
matching generated cases per phase. A new profile was generated and merged.

`details.tar.gz` preserves source/tool archives, patch, commands, compiler
vectors, generated training/profile bytes, all native raw workers and the build
review. `ORIGINS.json` inside it maps each member to its retained origin and hash.
Six copied libraries are excluded, with their complete hashes preserved.
`readback.json` records full member/origin and nested-source verification.
Native numerical review is a separate pending receipt. The core archive will
remain unchanged when that receipt arrives.
