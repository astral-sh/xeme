"""Assemble the saved-data checker from the exact prior raw core; no target calls."""
from pathlib import Path
import hashlib,json
O=Path(__file__).resolve().parent
prior=Path('/tmp/oriole-current-pgo-lto-native-independent-review/generator.py')
old=prior.read_text()
core=old[old.index("manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')"):old.index("\n\nck('all588 paired ratios and84 condition medians exact'")]
(O/'raw-core.py').write_text(core)
generated=(O/'setup.py').read_text()+'\n'+core+'\n'+(O/'tail.py').read_text()
(O/'generator.py').write_text(generated)
(O/'method.json').write_text(json.dumps({'prior_generator':str(prior),'prior_generator_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'raw_core_sha256':hashlib.sha256(core.encode()).hexdigest(),'generator_sha256':hashlib.sha256(generated.encode()).hexdigest(),'scope':'Exact prior complete raw core reused; cohort setup and author-summary schemas adapted. No target jobs.'},indent=2)+'\n')
