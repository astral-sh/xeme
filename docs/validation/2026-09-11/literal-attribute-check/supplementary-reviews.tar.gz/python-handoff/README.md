# Literal-attribute CPython cohorts

Both saved-data numerical audits passed. Each separate cohort contains 72 preflights and 504 timed workers across 24 conditions and seven seeded rounds, retaining all 25,788 measured samples and 504 warmups.

| Cohort | Candidate/control time | Lower conditions | ElementTree | Pyexpat events |
| --- | ---: | ---: | ---: | ---: |
| normal | 1.000027396 | 11/24 | 0.995050513 | 1.005029171 |
| pgo | 0.987734562 | 22/24 | 0.985853036 | 0.989619679 |

Ratios below one mean less measured time. Normal is flat overall, with 13/24 adverse conditions. ThinPGO improves 22/24 conditions; the retained regressions are Batik pyexpat4K (+0.612%) and GTK ElementTree64K (+0.072%). Candidate/ExpatPGO remains1.132312410: this is a small improvement, not completion of the performance goal. Prior native results show PGO improvement with normal/generated adverse controls; no cross-cohort or additive speedup is inferred.

`details.tar.gz` preserves both complete nonbinary studies, controllers, raw streams/specifications, sources, external CPython input sources, exact project inputs, and review records. `members.json.gz` retains every member origin, complete input hashes, and all18 excluded compiled consumer/parser files. Both Expat soname aliases are recorded against their target hashes; the initial packaging-only alias rejection is retained. Both70-file source archives and every archive member were read back against exact originals. No original evidence was modified.

`report.json` gives compact results and identities. Numerical reconstruction was separate from root's target collection, but performed by the prepared-controller author; independent protocol and build reviews are retained explicitly. Both consumers use namespaces. Timing includes parser lifecycle, callbacks/tree creation and explicit result destruction; canonical comparisons and explicit gc.collect are outside, automatic GC remains enabled. Adjacent pyexpat text callbacks are merged for the canonical oracle; strict compatibility evidence remains separate.
