manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');manifest=j(manifest_path)
fixtures={}
for project in manifest['projects']:
    entry=next(row for row in project['files'] if row['role']=='input');path=(manifest_path.parent/entry['path']).resolve()
    ck('original project input '+project['name'],h(path)==entry['sha256']);fixtures[project['name']]=str(path)
ck('six real projects',set(fixtures)=={'vulkan','wayland','maven','batik','gtk','docbook'})
fixtures['generated-rare-declarations']='/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml';fixtures['generated-entities']='/tmp/oriole-grammar-bench-plain/entities.xml'
fixed={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
conditions=[{'name':name,'input':path,'chunk':chunk,'namespaces':ns,'iterations':fixed[name]} for chunk in [4096,65536] for name,path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False,True])]
ck('all28 fixed conditions exact',conditions==protocol['conditions'] and len(conditions)==28 and len({key(c) for c in conditions})==28)
driver=Path('/tmp/oriole-grammar-bench-plain/native-driver');driver_source=Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')
origin_path=Path('/tmp/oriole-grammar-bench-plain/summary.json');origin=j(origin_path)
ck('unchanged native driver original build identity',origin['status']=='passed' and origin['sha256_before'][str(driver)]==origin['sha256_after'][str(driver)]==h(driver) and origin['sha256_before'][str(driver_source)]==origin['sha256_after'][str(driver_source)]==h(driver_source))
driver_code=read(driver_source).decode()
ck('explicit driver library handle','dlopen(argv[1], RTLD_NOW | RTLD_LOCAL)' in driver_code and 'dlsym(library, symbol)' in driver_code)
ck('native timer scope',driver_code.index('fread(data')<driver_code.index('double before = now();')<driver_code.index('Parser parser =')<driver_code.index('api.destroy(parser);\n        double elapsed = now() - before;'))

ordinal=0;streams=[];observed_by_condition={};sample_counts=Counter();process_medians={key(c):{engine:[] for engine in engines} for c in conditions}
def process(row,condition,pair,cpu,count):
    global ordinal
    worker=S/f'worker-{ordinal:04d}.json';saved=j(worker)
    ck('immediate worker original fields '+str(ordinal),set(saved)=={'condition','engine','pair','command','returncode','stdout','stderr'} and saved=={field:row[field] for field in saved})
    ck('worker metadata '+str(ordinal),row['condition']==condition and row['pair']==pair and row['engine'] in engines and row['returncode']==0 and row['stderr']=='')
    engine=row['engine'];command=['taskset','-c',str(cpu),str(driver),protocol['libraries'][engine]['path'],condition['input'],str(condition['chunk']),str(count)]+(['namespaces'] if condition['namespaces'] else [])
    ck('worker command '+str(ordinal),row['command']==command)
    data=json.loads(row['stdout']);samples=data['samples']
    ck('worker output version '+str(ordinal),data['version']==('expat_2.8.4' if engine.startswith('expat') else 'oriole_compat_2.8.4') and set(data)=={'version','samples'})
    ck('all sample fields '+str(ordinal),all(set(sample)=={'iteration','warmup','seconds','hash','elements','text_bytes'} and isinstance(sample['seconds'],(int,float)) and math.isfinite(sample['seconds']) and sample['seconds']>0 and isinstance(sample['elements'],int) and sample['elements']>=0 and isinstance(sample['text_bytes'],int) and sample['text_bytes']>=0 and len(sample['hash'])==16 and all(ch in '0123456789abcdef' for ch in sample['hash']) for sample in samples))
    ck('sample count/indices/warmup '+str(ordinal),len(samples)==count+1 and [sample['iteration'] for sample in samples]==list(range(count+1)) and [sample['warmup'] for sample in samples]==[True]+[False]*count)
    observations=sorted({(sample['hash'],sample['elements'],sample['text_bytes']) for sample in samples})
    ck('sample callback observations '+str(ordinal),len(observations)==1 and row['observations']==[list(value) for value in observations])
    median=statistics.median(sample['seconds'] for sample in samples[1:])
    ck('worker median exact '+str(ordinal),median==row['median_seconds'])
    stage='preflight' if pair==-1 else 'timed'
    sample_counts[stage+'_workers']+=1;sample_counts[stage+'_warmups']+=1;sample_counts[stage+'_measured']+=count
    streams.append({'ordinal':ordinal,'worker_sha256':h(worker),'condition':condition,'pair':pair,'engine':engine,'stdout_sha256':hashlib.sha256(row['stdout'].encode()).hexdigest(),'stderr_sha256':hashlib.sha256(row['stderr'].encode()).hexdigest(),'measured_samples':count,'median_seconds':median})
    ordinal+=1
    return observations,median

ck('84 preflight records',len(pre['rows'])==84)
for index,condition in enumerate(conditions):
    rows=pre['rows'][3*index:3*index+3]
    ck('preflight engine order '+str(index),[row['engine'] for row in rows]==engines)
    observations=[process(row,condition,-1,5,1)[0] for row in rows]
    ck('three-engine preflight observations '+str(index),all(x==observations[0] for x in observations))
    observed_by_condition[key(condition)]=observations[0]

rng=random.Random(protocol['seed']);jobs=[(condition,pair) for condition in conditions for pair in range(7)];rng.shuffle(jobs)
ck('196 complete unique cohorts',len(results['rows'])==len(jobs)==196 and len({(key(row['condition']),row['pair']) for row in results['rows']})==196)
ratios={key(c):{name:[] for name in ratio_names} for c in conditions}
for index,((condition,pair),group) in enumerate(zip(jobs,results['rows'],strict=True)):
    order=engines.copy();rng.shuffle(order)
    ck('seeded cohort and engine order '+str(index),group['condition']==condition and group['pair']==pair and group['order']==order and [row['engine'] for row in group['processes']]==order)
    seconds={}
    for row in group['processes']:
        observations,median=process(row,condition,pair,0,condition['iterations'])
        ck('timed observations equal preflight',observations==observed_by_condition[key(condition)])
        seconds[row['engine']]=median;process_medians[key(condition)][row['engine']].append(median)
    for name in ratio_names:
        numerator,denominator=name.split('_over_');ratios[key(condition)][name].append(seconds[numerator]/seconds[denominator])
computed=[{'condition':c,'paired_ratios':ratios[key(c)],'median_ratios':{name:statistics.median(values) for name,values in ratios[key(c)].items()}} for c in conditions]
ck('all588 paired ratios and84 medians exact',results['summary']==computed)
ck('exact672 immediate worker files no extras',ordinal==672 and sorted(p.name for p in S.glob('worker-*.json'))==[f'worker-{index:04d}.json' for index in range(672)])
ck('sample counts all retained',dict(sample_counts)=={'preflight_workers':84,'preflight_warmups':84,'preflight_measured':84,'timed_workers':588,'timed_warmups':588,'timed_measured':105420})
groups={}
for label,predicate in [('real',lambda c:not c['name'].startswith('generated-')),('generated',lambda c:c['name'].startswith('generated-')),('real_plain',lambda c:not c['name'].startswith('generated-') and not c['namespaces']),('real_namespaces',lambda c:not c['name'].startswith('generated-') and c['namespaces'])]:
    selected=[row for row in computed if predicate(row['condition'])]
    groups[label]={'conditions':len(selected),'ratios':{}}
    for name in ratio_names:
        values=[row['median_ratios'][name] for row in selected]
        groups[label]['ratios'][name]={'geomean':math.exp(sum(math.log(value) for value in values)/len(values)),'below_one':sum(value<1 for value in values)}
