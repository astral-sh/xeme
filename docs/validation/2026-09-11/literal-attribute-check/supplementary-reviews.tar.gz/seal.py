from pathlib import Path
import gzip,hashlib,json,os
R=Path(__file__).resolve().parent
assert __debug__ and os.sched_getaffinity(0)=={6}
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reviews={mode:json.loads((R/mode/'review.json').read_text()) for mode in ['normal','pgo']}
union={}
for mode,review in reviews.items():
    attempt=json.loads((R/mode/'attempt01.json').read_text())
    assert attempt['returncode']==0 and attempt['generator_sha256']==review['generator_sha256']==h(R/'generator.py')
    for path,digest in json.loads(gzip.decompress((R/mode/'checked-files.json.gz').read_bytes())).items():
        assert union.setdefault(path,digest)==digest
        assert h(Path(path))==digest
normal=Path('/tmp/oriole-literal-attribute-normal-native-study')
pgo=Path('/tmp/oriole-literal-attribute-pgo-native-study')
a=json.loads((normal/'controller.json').read_text());b=json.loads((pgo/'controller.json').read_text())
assert a['commands'][-1]['end']<=b['commands'][0]['start']
assert json.loads((normal/'native-screen/protocol.json').read_text())['conditions']==json.loads((pgo/'native-screen/protocol.json').read_text())['conditions']
review={'status':'passed','scope':'Independent saved raw numerical audit of separate normal and PGO native cohorts. No target execution or cross-cohort ratios.',
 'cohorts':{m:{'review':m+'/review.json','review_sha256':h(R/m/'review.json'),'freeze_sha256':v['freeze_sha256'],'frozen_files':v['frozen_files'],'groups':v['groups'],'candidate_control_regressions':v['candidate_control_regressions']} for m,v in reviews.items()},
 'total_counts':{'preflights':168,'timed_workers':1176,'seeded_cohorts':392,'immediate_records':1344,'timed_measured_samples':210840,'timed_warmups':1176,'all_samples_including_preflights':212352,'paired_ratios':1176,'condition_ratio_medians':168},
 'normal_completed_before_pgo_preflights':True,'shared_condition_design_exact':True,'prior_raw_reconstruction_byte_exact':True,'attempts_per_cohort':1,'passed_cohort_checks':sum(v['passed_checks'] for v in reviews.values()),'unique_inspected_files':len(union),'all_inspected_bytes_unchanged':True,'audit_cpu':6,'generator_sha256':h(R/'generator.py'),
 'limitations':['Separate within-cohort comparisons; no cross-cohort ratio or significance claim.','Timing includes native parser lifecycle; no full application, callback-position correctness or full compatibility claim.','No independent historical idle-host attestation or per-worker dladdr receipt. Existing source/build/training and historical Expat limits retained.','Source/build proofs reused by hash. No package readback, new target jobs or adoption decision.'],'findings':[]}
(R/'review.json').write_text(json.dumps(review,indent=2)+'\n')
receipt={'status':'passed','review_sha256':h(R/'review.json'),'normal_review_sha256':h(R/'normal/review.json'),'pgo_review_sha256':h(R/'pgo/review.json'),'unique_inspected_files':len(union),'cohort_checks':review['passed_cohort_checks'],'generator_sha256':h(R/'generator.py'),'seal_sha256':h(Path(__file__))}
(R/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
index={str(p.relative_to(R)):{'sha256':h(p),'bytes':p.stat().st_size} for p in sorted(R.rglob('*')) if p.is_file() and p.name!='files.json'}
(R/'files.json').write_text(json.dumps(index,indent=2,sort_keys=True)+'\n')
for n,v in index.items():assert (R/n).stat().st_size==v['bytes'] and h(R/n)==v['sha256']
print(json.dumps({'status':'passed','indexed_files':len(index),'review_sha256':h(R/'review.json'),'receipt_sha256':h(R/'receipt.json'),'index_sha256':h(R/'files.json'),'unique_inputs':len(union),'cohort_checks':review['passed_cohort_checks']},indent=2))
