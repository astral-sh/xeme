"""Independent saved normal/PGO native audit; no target execution."""
from pathlib import Path
from collections import Counter
import ast, copy, difflib, gzip, hashlib, json, math, os, random, statistics, sys

mode=sys.argv[1];assert mode in ['normal','pgo']
OUT=Path(__file__).resolve().parent;O=OUT/mode;O.mkdir(exist_ok=True)
R=Path('/tmp/oriole-literal-attribute-'+mode+'-native-study');S=R/'native-screen'
tracked={};passed_checks=0
def read(path):
    path=Path(path);raw=path.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(path),value)==value,str(path)
    return raw
def h(path):read(path);return tracked[str(path)]
def j(path):return json.loads(read(path))
def ck(name,condition):
    global passed_checks
    assert condition,name
    passed_checks+=1
key=lambda value:json.dumps(value,sort_keys=True)
engines=['control','candidate','expat']
ratio_names=['candidate_over_control','candidate_over_expat','control_over_expat']
ck('CPU6 saved-only audit',__debug__ and os.sched_getaffinity(0)=={6})
freeze_hash={'normal':'96f1b853e4bec110296d5373d23083af8b8c21e31f8f7cb35f97088a855e6a1f','pgo':'d8b24b6e845d3f844888dba2d74dcddaef76a1c1ed943e231701952071b2ed14'}[mode]
frozen_count={'normal':686,'pgo':685}[mode]
ck('final freeze pinned',h(R/'freeze.json')==freeze_hash)
freeze=j(R/'freeze.json')
ck('complete frozen inventory',freeze['status']=='frozen' and freeze['count']==len(freeze['files'])==frozen_count and set(freeze['files'])|{'freeze.json'}=={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()})
for n,v in freeze['files'].items():ck('frozen bytes '+n,h(R/n)==v['sha256'] and len(read(R/n))==v['bytes'])
ck('freeze byte sum',sum(v['bytes'] for v in freeze['files'].values())==freeze['bytes'])
reviews={
 '/tmp/oriole-current-pgo-lto-native-independent-review/review.json':'58aa681104408e074836fdb73230f0e2dcdfdbabc06f37483dde33f4572d38c2',
 '/tmp/oriole-literal-attribute-check-build-independent-review/review.json':'51b5001bfcfab7c08efc2b52d33d16d1eaf96a88e541d66fe781327075e947e8',
 '/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json':'cec78c70730e111f139a6fab70089e1629ffe3336843106585a35922a525bbc9',
 '/tmp/oriole-native-byte-count-pgo-training-independent-review/review.json':'9e7a8451c1429ea888904ae16ba6c120e0a86ec4e4695a72bfe7dce5ff9e0934',
 '/tmp/oriole-current-pgo-expat-reuse-independent-review/review.json':'9a53fcddfa80a039da800284a3ebdbe7d83316fe83768ed1f4d7e4770b53b2d9'}
for p,v in reviews.items():ck('sealed review '+p,h(p)==v)
prior=j('/tmp/oriole-current-pgo-lto-native-independent-review/review.json')
prior_generator=Path('/tmp/oriole-current-pgo-lto-native-independent-review/generator.py')
ck('prior complete raw generator pinned',h(prior_generator)==prior['generator_sha256'])
prior_text=read(prior_generator).decode()
core=prior_text[prior_text.index("manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')"):prior_text.index("\n\nck('all588 paired ratios and84 condition medians exact'")]
ck('complete raw core exact prior bytes',read(OUT/'raw-core.py').decode()==core)
protocol=j(S/'protocol.json');pre=j(S/'preflight.json');results=j(S/'results.json')
adaptation=j(R/'adaptation.json');controller=j(R/'controller.json');published=j(R/'summary.json')
ck('protocol fixed campaign',protocol['pairs']==7 and protocol['seed']==2026091003 and protocol['preflights']==84 and protocol['timed_workers']==588)
ck('successful phase records',pre['status']==results['status']=='passed' and results['affinity']==[0])
ck('phase hash links',pre['protocol_sha256']==results['protocol_sha256']==h(S/'protocol.json') and results['preflight_sha256']==h(S/'preflight.json'))
ck('14 identical phase pins',len(protocol['hashes'])==14 and protocol['hashes']==pre['hashes_before']==pre['hashes_after']==results['hashes_before']==results['hashes_after'])
for p,v in protocol['hashes'].items():ck('protocol origin '+p,h(p)==v)
expected={
 'normal':{'control':'0c8c58750c029174bfb522cee85949c11360696978e13b92d96e21f84461e96d','candidate':'8ad88e13e07c7c321fe13b36528b63e392cfd48db22722bf955a14de7241889f','expat':'7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'},
 'pgo':{'control':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','candidate':'8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a','expat':'12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'}}[mode]
ck('three engine mappings',list(protocol['libraries'])==engines and adaptation['libraries']==protocol['libraries'])
for name,row in protocol['libraries'].items():ck('reviewed library '+name,h(row['path'])==row['sha256']==expected[name])
P=Path('/tmp/oriole-literal-attribute-check-pgo-study')
ck('pair report/source binding',adaptation['pair_report_sha256']==h(P/'pair-report.json') and adaptation['source_binding_sha256']==h(P/'source-binding.json'))
ck('candidate source identity',adaptation['source_manifest_sha256']==h(P/'source.json')=='1120c74e96c7f562cecfa25db227a830e8a1667a67dba30732ca039fb5e7dbec')
oldroot=Path('/tmp/oriole-current-pgo-lto-native-study');oldpath=oldroot/'native_screen.py'
oldtext=read(oldpath).decode();newtext=read(R/'native_screen.py').decode()
ck('parent controller pin',h(oldpath)==adaptation['parent_controller_sha256']=='5269999b6229d9e5862303d1f61f2e761ca859d3a7c683cc21a9237dd1e353a3')
ck('current controller pin',h(R/'native_screen.py')==adaptation['controller_sha256']==controller['controller_sha256'])
ck('wrapper exact inherited bytes',h(oldroot/'run.py')==h(R/'run.py')==adaptation['wrapper_sha256']==adaptation['parent_wrapper_sha256']==controller['wrapper_sha256']=='5f41a419e800e95954424e2a85d2ee988609d830db18dc85c469af801cd8aef5')
ck('controller patch exact',h(R/'controller.patch')==adaptation['controller_patch_sha256'] and read(R/'controller.patch').decode()==''.join(difflib.unified_diff(oldtext.splitlines(True),newtext.splitlines(True),fromfile=str(oldpath),tofile=str(R/'native_screen.py'))))
oldast=ast.parse(oldtext);newast=ast.parse(newtext)
def assignment(tree,name):return next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
for name in ['run','digest','save']:
    nodes=[next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name) for tree in [oldast,newast]]
    ck('worker/helper AST '+name,ast.dump(nodes[0])==ast.dump(nodes[1]))
for name in ['iterations','conditions']:ck('fixed AST '+name,ast.dump(assignment(oldast,name))==ast.dump(assignment(newast,name)))
ck('exact three ratios',[a+'_over_'+b for a,b in ast.literal_eval(assignment(newast,'ratios').value)]==ratio_names)
# Allow only the module description, root, engine mapping, ratio labels and
# protocol scope. All other module code, including the entire tail, is equal.
normalized=copy.deepcopy(oldast);normalized.body[0]=copy.deepcopy(newast.body[0])
for name in ['root','libraries','ratios']:
    oldnode=assignment(normalized,name);normalized.body[normalized.body.index(oldnode)]=copy.deepcopy(assignment(newast,name))
oldprotocol=assignment(normalized,'protocol').value;newprotocol=assignment(newast,'protocol').value
scope_index=next(i for i,k in enumerate(oldprotocol.keys) if isinstance(k,ast.Constant) and k.value=='scope')
oldprotocol.values[scope_index]=copy.deepcopy(newprotocol.values[scope_index])
ck('entire controller AST expected changes only',ast.dump(normalized)==ast.dump(newast))
ck('passed aggregate controller',controller['status']=='passed' and len(controller['commands'])==2)
for row,(phase,cpu,bound) in zip(controller['commands'],[('preflight',5,600),('time',0,1200)],strict=True):
    ck('phase command bounds and stream '+phase,row['phase']==phase and row['exit']==0 and row['timeout']==bound and 0<row['end']-row['start']<bound and row['command']==['taskset','-c',str(cpu),'python3',str(R/'native_screen.py'),phase] and h(R/(phase+'-controller.log'))==row['log_sha256'])
ck('preflight precedes timing',controller['commands'][0]['end']<=controller['commands'][1]['start'])
completion=j(R/'completion.json')
ck('completion counts',completion['status']=='complete' and completion['controller_exit']==0 and completion['preflights']==84 and completion['timed_workers']==588 and completion['summary_sha256']==h(R/'summary.json'))
for name in ['source_build_freeze','build_review','ASan_readiness']:
    row=completion[name];ck('completion pinned evidence '+name,h(row['path'])==row['sha256'])
if mode=='normal':
    launch=j(R/'launch-prerequisites.json')
    for p,v in launch['prerequisites'].items():ck('launch prerequisite '+p,h(p)==v)
