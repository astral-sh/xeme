# Cohort-specific author schema; all arithmetic below derives from the unchanged
# complete raw worker reconstruction above.
author_groups={label:{name:{'geomean':r['geomean'],'lower':r['below_one'],'higher':sum(row['median_ratios'][name]>1 for row in computed if row['condition']['name'].startswith('generated-')==(label=='generated')),'count':group['conditions']} for name,r in group['ratios'].items()} for label,group in groups.items() if label in ['real','generated']}
all_adverse={name:[{'condition':r['condition'],'ratio':r['median_ratios'][name]} for r in computed if r['median_ratios'][name]>1] for name in ratio_names}
ck('author summary exact from raw workers',published['status']=='passed' and published['results_sha256']==h(S/'results.json') and published['groups']==author_groups and published['regressions']==all_adverse['candidate_over_control'])
ck('preflight stdout exact',j(R/'preflight-controller.log')=={'status':'passed','preflights':84,'protocol_sha256':h(S/'protocol.json')})
ck('timing stdout exact',j(R/'time-controller.log')=={'status':'passed','timed_workers':588,'summary':computed})
ck('complete675 native screen files',{p.name for p in S.iterdir()}=={f'worker-{i:04d}.json' for i in range(672)}|{'protocol.json','preflight.json','results.json'})
expected_real={'normal':(1.002102987038012,12,12),'pgo':(0.9786338733080541,23,1)}[mode]
real=author_groups['real']['candidate_over_control']
ck('retained real outcome',(real['geomean'],real['lower'],real['higher'])==expected_real)
if mode=='pgo':
    ck('one retained Maven namespace regression',len(all_adverse['candidate_over_control'])==1 and all_adverse['candidate_over_control'][0]['condition']['name']=='maven' and all_adverse['candidate_over_control'][0]['condition']['namespaces'] and all_adverse['candidate_over_control'][0]['condition']['chunk']==4096)
else:ck('all15 normal adverse rows retained',len(all_adverse['candidate_over_control'])==15)
method=j(OUT/'method.json')
ck('auditor source pin',h(OUT/'generator.py')==method['generator_sha256'])
for name in ['setup.py','raw-core.py','tail.py','prepare-audit.py']:h(OUT/name)
ck('all inspected bytes unchanged',all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in tracked.items()))
condition_table=[{'condition':r['condition'],'median_process_seconds':{e:statistics.median(v) for e,v in process_medians[key(r['condition'])].items()},'median_ratios':r['median_ratios'],'paired_ratios':r['paired_ratios']} for r in computed]
for name,value in [('streams.json.gz',streams),('conditions.json.gz',condition_table),('all-adverse-conditions.json.gz',all_adverse),('checked-files.json.gz',tracked)]:
    (O/name).write_bytes(gzip.compress((json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0))
report={'status':'passed','cohort':mode,'scope':'Independent saved native worker, identity, order and arithmetic audit; no target execution and no cross-cohort ratios.',
 'freeze_sha256':freeze_hash,'frozen_files':frozen_count,'source_manifest_sha256':adaptation['source_manifest_sha256'],'libraries':protocol['libraries'],'reused_reviews':reviews,
 'counts':dict(sample_counts)|{'conditions':28,'real_conditions':24,'generated_conditions':4,'cohorts':196,'immediate_workers':672,'native_screen_files':675,'paired_ratios':588,'condition_ratio_medians':84,'all_samples':106176},
 'groups':author_groups,'candidate_control_regressions':all_adverse['candidate_over_control'],'all_ratio_adverse_rows':'all-adverse-conditions.json.gz',
 'controller':'Entire module AST equals reviewed prior controller after only description/root/library/ratio-label/protocol-scope changes. Worker, fixtures, iterations, preflight/timing and aggregation tail unchanged. Wrapper byte exact;90-second workers,600-second preflight and1200-second timing bounds.',
 'method':['All672 immediate records compared with aggregate copies, complete commands, return codes, stdout/stderr, versions and sample fields. All106176 sample indices, warmup flags and finite positive durations verified.','All84 preflight callback observations and105420 measured timings retained. One excluded warmup per worker; every process median reconstructed.','Seed2026091003 reconstructs196 cohort orders and588 engine positions. All588 paired ratios and84 condition medians match raw summary exactly; all aggregate means/counts and adverse rows match author summary.','All frozen members, inventories, external protocol hashes, source/build review links and completion/phase logs checked.'],
 'driver':{'binary_sha256':h(driver),'source_sha256':h(driver_source),'binding':'Absolute dlopen RTLD_NOW|RTLD_LOCAL handle plus dlsym; versions and arguments checked, no per-worker dladdr attestation.','timer':'Parser creation, handlers, parse/callbacks and destruction included; input I/O, loading and process startup excluded.'},
 'limitations':['Normal and PGO are separate sequential campaigns; no cross-cohort performance ratio or causal interaction estimate.','Shared host: scheduling receipts say competing target work was held, but historical absence of interference is not independently observed. No statistical significance claim.','PGO variants use their separately generated training profiles; baseline/profile/compiler and historical Expat differences remain as documented by sealed reviews. No fresh Expat training claimed.','Only six project XML inputs and generated controls; no full applications. Batik external DTD is not loaded. Callback hashes/counts do not certify exact fragmentation, positions or full correctness.','Every regression and every Expat comparison retained. No adoption recommendation or completed C/CPython correctness claim.','No parser, compiler, training, profiler, test or timing jobs ran during this CPU6 readback.'],
 'passed_checks':passed_checks,'checked_files':len(tracked),'all_inspected_bytes_unchanged':True,'generator_sha256':method['generator_sha256']}
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','mode':mode,'review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest(),'checks':passed_checks,'checked_files':len(tracked),'groups':author_groups}))
