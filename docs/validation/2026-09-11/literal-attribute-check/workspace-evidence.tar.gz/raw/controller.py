"""Complete workspace checks for the reviewed attribute candidate."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

worktree = Path('/home/dev-user/code/oss/oriole-literal-attribute-check')
output = Path('/tmp/oriole-literal-attribute-workspace-checks')
output.mkdir()
source = json.loads(Path('/tmp/oriole-literal-attribute-check-study/source.json').read_text())['source_sha256']
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(worktree / name) == value for name, value in source.items())
assert os.sched_getaffinity(0) == {4}
env = os.environ.copy()
for key in ('RUSTC', 'LLVM_PROFILE_FILE', 'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST', 'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'):
    env.pop(key, None)
env.update(CARGO_HOME='/home/dev-user/.cache/toucan/cargo', CARGO_TARGET_DIR='/home/dev-user/.cache/oriole/targets/literal-attribute-check', CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}', CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', RUSTC_WRAPPER='', RUSTC_WORKSPACE_WRAPPER='', RUSTFLAGS='', CARGO_ENCODED_RUSTFLAGS='')
report = {'status': 'running', 'source_manifest_sha256': sha('/tmp/oriole-literal-attribute-check-study/source.json'), 'cpu': 4, 'commands': []}
def save():
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
for label, args in [('workspace-tests', ['test', '--workspace', '--all-targets', '--locked', '--offline']), ('doctests', ['test', '--workspace', '--doc', '--locked', '--offline']), ('clippy', ['clippy', '--workspace', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings'])]:
    command = ['cargo', '+ohm', '-Zohm-defaults=no', *args]
    row = {'label': label, 'argv': command, 'timeout': 900, 'start': time.time()}
    report['commands'].append(row)
    save()
    with (output / (label + '.log')).open('wb') as log:
        child = subprocess.Popen(command, cwd=worktree, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            row['exit'] = child.wait(timeout=900)
        except BaseException as error:
            row['error'] = repr(error)
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            row['exit'] = child.wait()
            raise
        finally:
            log.flush()
            row['end'] = time.time()
            row['log_sha256'] = sha(output / (label + '.log'))
            save()
    print(label, row['exit'], flush=True)
    if row['exit']:
        raise SystemExit(row['exit'])
report['source_unchanged'] = all(sha(worktree / name) == value for name, value in source.items())
assert report['source_unchanged']
report['status'] = 'passed'
save()
(output / 'controller.py').write_bytes(Path(__file__).read_bytes())
