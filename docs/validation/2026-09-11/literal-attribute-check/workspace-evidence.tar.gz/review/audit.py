import gzip,hashlib,json,os,re
from pathlib import Path
os.sched_setaffinity(0,{6})
B=Path('/tmp/oriole-literal-attribute-workspace-checks');O=Path(__file__).parent
tracked={}
def read(p):
 p=Path(p);b=p.read_bytes();h=hashlib.sha256(b).hexdigest();assert tracked.setdefault(str(p),h)==h;return b
def load(p):return json.loads(read(p))
def sha(p):return hashlib.sha256(read(p)).hexdigest()
sourcepath=Path('/tmp/oriole-literal-attribute-check-study/source.json');source=load(sourcepath)
assert sha(sourcepath)=='1120c74e96c7f562cecfa25db227a830e8a1667a67dba30732ca039fb5e7dbec'
for n,h in source['source_sha256'].items():assert sha(Path(source['worktree'])/n)==h
assert len(source['source_sha256'])==70
r=load(B/'report.json');assert r['status']=='passed' and r['cpu']==4 and r['source_unchanged'] and r['source_manifest_sha256']==sha(sourcepath)
expected=[('workspace-tests',['test','--workspace','--all-targets','--locked','--offline']),('doctests',['test','--workspace','--doc','--locked','--offline']),('clippy',['clippy','--workspace','--all-targets','--locked','--offline','--','-D','warnings'])]
assert len(r['commands'])==3
inventories={}
for row,(label,args) in zip(r['commands'],expected,strict=True):
 assert row['label']==label and row['argv']==['cargo','+ohm','-Zohm-defaults=no']+args
 assert row['exit']==0 and row['timeout']==900 and 0<row['end']-row['start']<900 and not row.get('error')
 log=read(B/(label+'.log')).decode();assert sha(B/(label+'.log'))==row['log_sha256']
 if label=='clippy':assert 'Finished' in log and not re.search(r'^error(?:\[|:)',log,re.M);continue
 inventory=[];active=None;names=[];announced=None
 for line in log.splitlines():
  if re.match(r'^\s+(?:Running |Doc-tests )',line):
   assert active is None;active=line.strip();names=[];announced=None
  m=re.match(r'^running (\d+) tests?$',line)
  if m:assert active is not None and announced is None;announced=int(m[1])
  m=re.match(r'^test (.+) \.\.\. ok$',line)
  if m:names.append(m[1])
  m=re.match(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',line)
  if m:
   assert active is not None and announced==int(m[1])==len(names) and len(set(names))==len(names)
   assert all(int(x)==0 for x in m.groups()[1:])
   inventory.append({'target':active,'passed':int(m[1]),'tests':names});active=None
 assert active is None
 inventories[label]=inventory
assert len(inventories['workspace-tests'])==33 and sum(x['passed'] for x in inventories['workspace-tests'])==408
assert len(inventories['doctests'])==3 and sum(x['passed'] for x in inventories['doctests'])==1
core=load('/tmp/oriole-literal-attribute-check-study/checks.json')
fmt=next(x for x in core['commands'] if x['label']=='fmt')
assert fmt['exit']==0 and fmt['command']==['cargo','+ohm','-Zohm-defaults=no','fmt','--all','--check']
assert sha('/tmp/oriole-literal-attribute-check-study/fmt.log')==fmt['log_sha256']
controller=read(B/'controller.py').decode()
assert "CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}'" in controller
assert "CARGO_TARGET_DIR='/home/dev-user/.cache/oriole/targets/literal-attribute-check'" in controller
assert "CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0'" in controller
assert "child.wait(timeout=900)" in controller
# Workspace checks follow both elapsed cohorts; no test-build overlap with them.
python_receipts={}
for mode in ['normal','pgo']:
 p=Path('/tmp/oriole-literal-attribute-'+mode+'-python-study/time-controller.json');x=load(p)
 assert x['status']=='passed' and x['jobs'][0]['end']<r['commands'][0]['start']
 python_receipts[mode]=sha(p)
for p,h in tracked.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
(O/'details.json.gz').write_bytes(gzip.compress(json.dumps({'inputs':tracked,'inventory':inventories},sort_keys=True,separators=(',',':')).encode(),mtime=0))
review={'status':'passed','scope':'Independent saved-log/source readback only; no target or producer executions.','source_manifest_sha256':sha(sourcepath),'source_files_unchanged':70,'workspace_tests':408,'workspace_test_binaries':33,'zero_test_binaries':sum(x['passed']==0 for x in inventories['workspace-tests']),'doctests':1,'doctest_crates':3,'clippy':'workspace/all-targets -D warnings passed','fmt':'Earlier same-source cargo fmt --all --check passed; no Rust source changed afterward.','profile':'Normal debug test profile; measured C-only ThinPGO artifact compatibility is separately established by C/strict suites.','per_command_timeout_seconds':900,'commands_all_exit_zero':True,'report_sha256':sha(B/'report.json'),'controller_sha256':sha(B/'controller.py'),'unchanged_inputs':len(tracked),'timing_receipt_hashes':python_receipts,'workspace_after_both_python_cohorts':True,'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'details_sha256':hashlib.sha256((O/'details.json.gz').read_bytes()).hexdigest()}
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(review,indent=2))
