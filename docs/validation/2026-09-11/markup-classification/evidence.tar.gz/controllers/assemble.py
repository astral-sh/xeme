"""Package saved classifier evidence; no compiler/parser/benchmark execution."""
from pathlib import Path
import csv
import gzip
import hashlib
import io
import json
import os
import statistics
import tarfile

assert os.sched_getaffinity(0) == {6}
OUT = Path('/tmp/oriole-markup-classification-evidence')
BUILD = Path('/tmp/oriole-markup-classification-pgo-study')
CONTROL = Path('/tmp/oriole-reference-frame-pgo-study')
NATIVE = Path('/tmp/oriole-markup-classification-native-study')
REVIEWS = Path('/tmp/oriole-markup-classification-native-independent-review')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert not OUT.exists()
audits = {mode: read(REVIEWS / f'{mode}-review.json') for mode in ['normal', 'pgo']}
readbacks = {mode: read(REVIEWS / f'{mode}-independent-readback.json') for mode in audits}
source, selected = read(BUILD / 'source.json'), read(CONTROL / 'source.json')
assert source['candidate_base_commit'] == 'b4e262db0ffd84cc73f7047b55adf568f7834651'
assert selected['candidate_base_commit'] == source['base_runtime'] == '0f66d54ac8418f0a6e628ad18570677a19c9ed45'
assert sorted(n for n in source['source_sha256'] if source['source_sha256'][n] != selected['source_sha256'][n]) == ['crates/oriole/src/lib.rs']
assert all(a['status'] == 'passed' and a['totals']['all_workers'] == 672 and a['totals']['all_samples'] == 106176 for a in audits.values())
assert all(a['status'] == 'passed' and a['workers'] == 672 and a['samples'] == 106176 for a in readbacks.values())
for mode, audit in audits.items():
    assert sha(REVIEWS / 'audit.py') == audit['generator_sha256']
    assert sha(REVIEWS / f'{mode}-conditions.csv') == audit['condition_csv_sha256']
    for path, digest in audit['input_sha256'].items():
        assert sha(path) == digest
checks = read(BUILD / 'source-checks.json')
assert checks['status'] == 'passed' and checks['test_count'] == 440 and checks['test_groups'] == 34
pair = read(BUILD / 'pair-report.json')
assert pair['status'] == 'passed'
entries = {}
originals = {}

def add(path, member):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert member not in entries, member
    data = path.read_bytes()
    assert not data.startswith((b'\x7fELF', b'!<arch>\n')), path
    assert path.suffix not in {'.pyc', '.profraw', '.profdata', '.a', '.so'}, path
    entries[member] = data
    originals[member] = str(path)

def tree(root, prefix):
    for path in sorted(Path(root).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add(path, prefix + '/' + str(path.relative_to(root)))

# Exact candidate and selected source snapshots, not the unrelated later diagnostic.
for label, manifest in [('candidate', source), ('selected', selected)]:
    worktree = Path(manifest['worktree'])
    for name, digest in manifest['source_sha256'].items():
        assert sha(worktree / name) == digest
        add(worktree / name, f'source/{label}/{name}')
    for name in ['LICENSE-APACHE', 'LICENSE-MIT', 'THIRD_PARTY_LICENSES.md', 'licenses/expat.txt', 'licenses/libxml2.txt', 'licenses/cpython.txt', 'tests/c/UPSTREAM-NOTICES.txt']:
        add(worktree / name, f'source/{label}/{name}')

tree('/tmp/oriole-markup-classification-review', 'source/independent-review')
tree('/tmp/oriole-markup-classification-proposal', 'source/proposal')
tree('/tmp/oriole-markup-classification-checks', 'checks')
tree(REVIEWS, 'native/independent-review')
tree(NATIVE, 'native/candidate-campaigns')

# Selected native controller/protocol records establish the preserved protocol.
for mode in ['normal', 'pgo']:
    previous = Path('/tmp/oriole-reference-frame-native-study') / mode
    for name in ['adaptation.json', 'native_screen.py', 'run.py', 'native-screen/protocol.json']:
        add(previous / name, f'native/selected-protocol/{mode}/{name}')

# Both completed build records, tools, generated inputs and training stdout.
# Executables, archives and binary PGO profiles remain hash-identified receipts.
for label, build in [('candidate', BUILD), ('selected', CONTROL)]:
    for path in sorted(build.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log', '.py', '.patch'}:
            add(path, f'build/{label}/{path.name}')
    tree(build / 'pipeline', f'build/{label}/pipeline')
    run = Path(read(build / 'pair-report.json')['pgo_manifest']['path']).parent
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log'}:
            add(path, f'build/{label}/pgo/{path.name}')
    tree(run / 'inputs', f'build/{label}/pgo/inputs')
    add(build / 'pgo/latest.json', f'build/{label}/pgo/latest.json')
    if label == 'candidate':
        tree(build / 'local-checks', 'build/candidate/local-checks')

for path in [
    '/tmp/oriole-markup-classification-prepare.py',
    '/tmp/oriole-markup-classification-postbuild-prepare.py',
    '/tmp/oriole-markup-classification-reviewed-delta.json',
    '/tmp/oriole-markup-classification-measurement-preparation.md',
    '/tmp/oriole-reference-frame-build-bindings.py',
    '/tmp/oriole-reference-frame-native-independent-review/audit.py',
    __file__,
    '/tmp/oriole-markup-classification-evidence-preparation/assemble-attempt01.py',
    '/tmp/oriole-markup-classification-evidence-preparation/attempt01.md',
]:
    parent = 'origin-' if path.endswith('native-independent-review/audit.py') else ''
    add(path, 'controllers/' + parent + Path(path).name)

# All corpus files referenced by the fixture manifest, with their original licenses.
manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
add(manifest, 'native/inputs/corpus-manifest.json')
for project in read(manifest)['projects']:
    for file in project['files']:
        path = manifest.parent / file['path']
        assert sha(path) == file['sha256']
        add(path, 'native/inputs/' + file['path'])
add('/tmp/oriole-grammar-bench-plain/entities.xml', 'native/inputs/generated/entities.xml')
add('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml', 'native/inputs/generated/rare-declarations.xml')

# Save a compact index of deliberately external input pins as well.
all_pins = {}
for audit in audits.values():
    for path, digest in audit['input_sha256'].items():
        assert path not in all_pins or all_pins[path] == digest
        all_pins[path] = digest
archived_paths = set(originals.values())
excluded = [{'path': path, 'sha256': digest, 'size': Path(path).stat().st_size,
             'reason': 'external executable/library/profile or machine Cargo configuration; original receipt pin retained'}
            for path, digest in sorted(all_pins.items()) if path not in archived_paths]
assert all(Path(row['path']).suffix in {'.so', '.a', '.profraw', '.profdata', '.toml'} or Path(row['path']).name in {'rustup', 'rustc', 'cargo', 'llvm-profdata', 'python3.12', 'native-driver'} or '.so.' in Path(row['path']).name for row in excluded), excluded

OUT.mkdir()
rows = []
for mode in ['normal', 'pgo']:
    with (REVIEWS / f'{mode}-conditions.csv').open(newline='') as stream:
        rows.extend(list(csv.DictReader(stream)))
assert len(rows) == 56
with (OUT / 'conditions.csv').open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)

members = []
with (OUT / 'evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for member, data in sorted(entries.items()):
                info = tarfile.TarInfo(member)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
                members.append({'member': member, 'original_path': originals[member], 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
archive_path = OUT / 'evidence.tar.gz'
# One complete archive readback, without extraction or target execution.
with tarfile.open(archive_path, 'r:gz') as archive:
    actual = archive.getmembers()
    assert [m.name for m in actual] == [m['member'] for m in members]
    for record, member in zip(members, actual, strict=True):
        assert member.isfile() and member.size == record['size']
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == record['sha256']
index = {'schema': 'saved-record-bundle-v1', 'scope': 'Rejected markup classifier: exact source, checks, build/training and raw normal/PGO native records. No parser/compiler/benchmark targets executed by packaging.', 'archive': 'evidence.tar.gz', 'archive_sha256': sha(archive_path), 'archive_bytes': archive_path.stat().st_size, 'archive_readback_passed': True, 'members': members, 'excluded': excluded}
(OUT / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
report = {
    'decision': 'rejected',
    'source_commit': source['candidate_base_commit'],
    'selected_control_runtime': selected['candidate_base_commit'],
    'selected_publication': {'pull_request': 144, 'url': 'https://github.com/astral-sh/oriole/pull/144', 'head': '4064b0653534aff690c0e0f395a6b3b48da878fc'},
    'reason': 'The 0.51% normal real-project gain reverses to a 0.38% PGO regression with 17/24 conditions adverse; generated PGO is effectively flat, and normal generated references regress 3.31% in all 14 pairs. There is no consistent broad performance benefit.',
    'source72_delta': ['crates/oriole/src/lib.rs'],
    'pipeline69_delta': ['crates/oriole/src/lib.rs'],
    'checks': {'passed': 440, 'groups': 34, 'formatting_check_and_clippy_passed': True, 'all_61_Rust_sources_match_final_commit': True, 'failures': 0},
    'native': {mode: audits[mode]['native'][mode] for mode in audits},
    'projects': {mode: readbacks[mode]['projects'] for mode in readbacks},
    'worker_totals': {'conditions': 56, 'preflight_workers': 168, 'timed_workers': 1176, 'all_workers': 1344, 'all_samples': 212352},
    'builds': {'normal_generated_records': 288, 'instrumented_generated_records': 288, 'pgo_generated_records': 288, 'compiler_vectors': 9, 'library_artifacts': 6, 'normal_libraries': pair['normal_libraries'], 'pgo_libraries': pair['pgo_libraries'], 'compiler_body_and_six_pipeline_tools_unchanged': True},
    'executed': ['local Rust formatting/check/test/Clippy', 'normal and generated-only instrumented/PGO builds and 864 generated replay records', 'normal native campaign', 'PGO native campaign', 'saved-data source/build/native reviews'],
    'not_prepared_or_executed': ['upstream API campaign', 'CPython performance campaign', 'strict CPython campaign', 'allocation campaign'],
    'not_measured': ['current-source instruction profile or causal mechanism', 'layout/heap/peak memory/RSS', 'whole-application performance'],
    'unrelated_selected_runtime_semantic_diagnostic_included': False,
    'source_review': {'findings': 0, 'exact_error_callback_position_equivalence_intended': True, 'no_new_storage_or_unsafe_operations': True},
    'evidence': {'archive': {'path': 'evidence.tar.gz', 'sha256': sha(archive_path), 'bytes': archive_path.stat().st_size, 'members': len(members), 'readback_passed': True}, 'index': {'path': 'index.json', 'sha256': sha(OUT / 'index.json')}, 'conditions': {'path': 'conditions.csv', 'sha256': sha(OUT / 'conditions.csv'), 'rows': 56}, 'native_reviews': {mode: {'sha256': sha(REVIEWS / f'{mode}-review.json'), 'independent_readback_sha256': sha(REVIEWS / f'{mode}-independent-readback.json')} for mode in audits}},
    'scope': 'Evidence-only record. Selected direct-reference frame runtime remains unchanged. One campaign per mode on this machine; no significance or broad hardware claim. Absolute paths retain original provenance, not an executable portable installation. Original executables/libraries/binary profiles and machine Cargo configurations are excluded with pins retained.',
}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
(OUT / 'README.md').write_text('''# Ordinary markup classification — rejected

**Reject this candidate.** The normal release build is 0.51% faster across real-project native conditions, but PGO is 0.38% slower with 17 of 24 conditions regressing. Generated PGO results are effectively flat, while normal generated character references regress by 3.31% across their two conditions and all 14 paired measurements. The change does not show a consistent broad gain. Keep direct-reference frames selected.

Candidate: `b4e262db0ffd84cc73f7047b55adf568f7834651`. Measured selected control: `0f66d54ac8418f0a6e628ad18570677a19c9ed45`, published in [PR144](https://github.com/astral-sh/oriole/pull/144) at `4064b0653534aff690c0e0f395a6b3b48da878fc`. This packet publishes evidence only; the classifier remains unselected.

## Native results

| Build and scope | Candidate / selected control | Candidate / Expat | Adverse conditions |
| --- | ---: | ---: | ---: |
| Normal, 24 real-project conditions | 0.994929× (−0.51%) | 1.594791× | 6 / 24 |
| PGO, 24 real-project conditions | 1.003822× (+0.38%) | 1.328854× | 17 / 24 |
| Normal, 4 generated conditions | 1.006409× (+0.64%) | 4.123563× | 2 / 4 |
| PGO, 4 generated conditions | 0.999659× (−0.03%) | 3.885920× | 2 / 4 |

Normal gains are led by Vulkan (1.84%) and Wayland (0.72%). Five of six project aggregates regress with PGO: Batik is 1.37% slower and GTK 0.68% slower; Wayland improves 0.18%. Generated references improve 1.49% with PGO while generated declaration stress regresses 1.44%. The normal reference regressions are 3.55% at 4 KiB and 3.08% at 64 KiB, with every paired ratio above one. All 56 conditions, including every regression, are retained in [conditions.csv](conditions.csv).

Both campaigns use the same six original real-project inputs, 4 KiB and 64 KiB chunks, namespaces off/on, and four generated conditions. Each retains seven seeded, interleaved process pairs. A condition ratio is the median of paired process-median ratios; aggregates are geometric means across conditions. Audits reconstruct all 1,344 workers and 212,352 samples, including preflights, callback observations, library paths and byte hashes. These are native parser/consumer measurements on this machine, without a statistical-significance or whole-application claim.

Both Oriole builds use O3, ThinLTO and one codegen unit on the same explicit x86_64 target, with the selected allocator. PGO uses independently generated original training profiles. Expat 2.8.4 uses matching normal or PGO GCC 13.3 O3/shared builds without LTO. Driver, fixtures, callbacks, order, limits and timing arithmetic remain unchanged. The small normal improvement does not meet the within-10%-of-Expat goal, and PGO does not improve the selected runtime.

## Source, checks and builds

Only `crates/oriole/src/lib.rs` differs in both the 72-file source manifest and 69-file pipeline manifest. The candidate adds a local predicate after recognizing `<`: a present second lexical byte other than `!` or `?` selects the existing Tag scanner immediately. Lone `<`, declarations and processing instructions retain the original classification branch. No parser field, allocation, unsafe operation or new scanner is added. The 14-line source diff and exact candidate/selected snapshots are archived.

Independent source review found no actionable correctness issue. For ordinary tags, every skipped exceptional-prefix condition was already false; the same subsequent name checks, incremental scan, token bounds, decoding-error precedence, accounting and callback path remain. Existing contextual CDATA, malformed/end-tag, Unicode and custom-encoding tests cover the relevant boundary behavior. The intended behavior is identical, including errors and positions; no compatibility assertion was relaxed.

Completed checks report 440 passing Rust checks in 34 groups, formatting, all-target checking and Clippy. All 61 Rust source hashes match the candidate. Normal, instrumented and optimized builds completed with the original 288 generated parse records per phase, 864 candidate records total. Saved build review verifies nine actual compiler vectors, six library artifacts, fresh profiles, source/tool bindings, and identical generated observations. The build execution body and six pipeline tools are unchanged from the selected control.

## Scope and unexecuted campaigns

The classifier was rejected after normal and PGO native measurements. **No upstream API, CPython performance, strict CPython or allocation campaign was prepared or run for it.** There is no new full-compatibility, CPython, sanitizer, heap, peak-memory, RSS or whole-application result. The separate semantic diagnostic on the selected reference-frame runtime is unrelated and excluded.

The earlier archived proposal and suffix-build disassembly explain the attempted shortcut. Their instruction estimates concern older saved profiles and are not current candidate measurements or a causal explanation of these elapsed results. No current-source profile or code-generation mechanism is claimed.

## Saved evidence

[report.json](report.json) records the rejected decision, complete results and campaign scope. [evidence.tar.gz](evidence.tar.gz) preserves exact source snapshots/patches, checks, build and generated-training records, original native controllers, all raw worker outputs, independent reviews, and corpus licenses/notices. [index.json](index.json) records every archive member's original path, size and SHA-256; packaging read back every member once.

Executables, shared/static libraries, binary PGO profiles and machine Cargo configurations are excluded with their original receipt hashes retained. Absolute paths identify the original machine. This is a saved-record bundle, not a self-contained executable benchmark or a new verification framework. Packaging executed no parser, compiler or benchmark.
''')
print(json.dumps({'directory': str(OUT), 'files': [p.name for p in sorted(OUT.iterdir())], 'archive_sha256': sha(archive_path), 'archive_bytes': archive_path.stat().st_size, 'archive_members': len(members), 'excluded_inputs': len(excluded), 'report_sha256': sha(OUT / 'report.json'), 'index_sha256': sha(OUT / 'index.json'), 'conditions_sha256': sha(OUT / 'conditions.csv')}, indent=2))
