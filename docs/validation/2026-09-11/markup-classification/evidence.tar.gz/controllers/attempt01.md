# First packaging attempt

The saved-only packager exited 1 before creating the evidence directory. Its external-input classifier omitted the executable name `rustup` from the excluded-tool allowlist, although the auditor correctly recorded `/home/dev-user/.cargo/bin/rustup`. The source, build and native data checks had passed. The condition was extended to recognize `rustup`; no parser, compiler, test, benchmark, or saved-data auditor was rerun. `assemble-attempt01.py` preserves the exact first packaging script.
