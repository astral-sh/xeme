# Markup classification measurement preparation

Prepared only; no compiler, parser, training, preflight, or elapsed target executed by this agent. The completed root checks were read and bound: 440 checks in 34 groups, fmt/check/test/Clippy exit 0 and reaped. The candidate worktree is clean at `b4e262db0ffd84cc73f7047b55adf568f7834651`.

The selected control is `/tmp/oriole-reference-frame-pgo-study`, runtime `0f66d54ac8418f0a6e628ad18570677a19c9ed45`, source-equivalent to restacked `8b00d4cbb3f540647e1d7d795d0a04df00ed92f4`. Both the 72-file source manifest and 69-file pipeline manifest differ only in `crates/oriole/src/lib.rs`. No older suffix-sharing source or library is selected as the control.

The build controller changes only worktree, distinct target directory, selected control path, and captions. Everything from `def save()` onward is byte-identical to the selected build controller, as are all six original pipeline tools. It preserves the explicit host, O3/ThinLTO/one codegen unit, generated-only training, 288 records per normal/generate/use phase, timeouts, environment clearing, and source/tool bindings.

## Root launch sequence

Run the prepared build once:

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-markup-classification-pgo-study/build_pair.py
```

After that process completes and is reaped, the following saved-file reader verifies the actual build records, all six libraries, compiler vectors, training records, and source delta. It then materializes the normal and PGO native controllers with actual library paths and digests. It executes no compiler, parser, or timing target:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-markup-classification-postbuild-prepare.py --released-build --head b4e262db0ffd84cc73f7047b55adf568f7834651
```

Root runs the normal native screen first, after checking for competing compilation/parser work:

```sh
/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-markup-classification-native-study/normal/run.py
```

The unchanged wrapper runs preflight on CPU5 and elapsed timing on CPU0, with one attempt for each. The PGO wrapper will be `/tmp/oriole-markup-classification-native-study/pgo/run.py`; leave it unexecuted until root assesses the normal result. No allocation, API, Python, or strict-suite preparation is included.

## Bindings and scope

- Build controller: `/tmp/oriole-markup-classification-pgo-study/build_pair.py`, SHA256 `3bb42906b85e00912b91183b273142bfb4a3b5807573844cf3b450e3a8061f53`.
- Candidate source manifest: `/tmp/oriole-markup-classification-pgo-study/source.json`, SHA256 `8dbc4520d1ef2c572cce16754c3b9f143427cbfce631119ccb449264e7bb4f24`.
- Postbuild native preparer: `/tmp/oriole-markup-classification-postbuild-prepare.py`, SHA256 `e98f7d919bddcd7048150b656b148158625c48e1bdc7085ca28c9b599a9d377e`.
- The original generic reader `/tmp/oriole-reference-frame-build-bindings.py` is reused byte-identically, SHA256 `252f0d0c2dfde9f246e1cd26f84e16df4c229d92a0754e12ed70f72331cdb548`.
- Selected normal shared library SHA256 `087d131c215012d2a93527a4ec66a716216e8ab4009948a1f79d0a7644d5d949`.
- Selected PGO shared library SHA256 `d3c43850247b83aa3089b7f08deb31a084ee2aecb47b52d27e9d05e97b0e1bd4`.

`preparation.json`, `preparation-readback.json`, the controller diff, source diff, complete local-check receipts, and copied pipeline files are in the build-study directory. Native controller transformation was checked statically with inverse text/AST equality for both modes. The postbuild preparer remains unexecuted, so actual native controller paths do not exist yet. The temporary PGO path used only in the static transformation check is not a build or library claim.

The native protocol retains all 28 conditions, seven pairs, seed 2026091003, fixture bytes, callback hashes, warmups, iteration counts, worker/aggregate limits, and all adverse results. Captions consistently identify markup classification against selected direct-reference frames.
