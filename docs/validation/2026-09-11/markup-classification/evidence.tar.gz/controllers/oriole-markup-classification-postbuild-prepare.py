"""Bind completed markup-classification builds to unchanged native protocols."""
from pathlib import Path
import argparse
import ast
import difflib
import hashlib
import importlib.util
import json
import os
import re

BUILD = Path('/tmp/oriole-markup-classification-pgo-study')
CONTROL = Path('/tmp/oriole-reference-frame-pgo-study')
BASE_NATIVE = Path('/tmp/oriole-reference-frame-native-study')
NATIVE = Path('/tmp/oriole-markup-classification-native-study')
BINDER = Path('/tmp/oriole-reference-frame-build-bindings.py')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def library(build, pair, mode):
    path = build / 'normal/liboriole_expat.so' if mode == 'normal' else Path(pair['pgo_manifest']['path']).parent / 'use/liboriole_expat.so'
    digest = pair['normal_libraries']['liboriole_expat.so'] if mode == 'normal' else pair['pgo_libraries']['use/liboriole_expat.so']
    assert sha(path) == digest
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--released-build', action='store_true')
    parser.add_argument('--head', required=True)
    args = parser.parse_args()
    assert __debug__ and args.released_build and re.fullmatch('[0-9a-f]{40}', args.head)
    assert os.sched_getaffinity(0) == {6}
    assert not NATIVE.exists() and not (BUILD / 'build-readback.json').exists()
    assert sha(BINDER) == '252f0d0c2dfde9f246e1cd26f84e16df4c229d92a0754e12ed70f72331cdb548'
    spec = importlib.util.spec_from_file_location('reference_frame_build_bindings', BINDER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    prepared = read(BUILD / 'preparation.json')
    assert prepared['head'] == args.head
    bindings = module.verify(BUILD, CONTROL, args.head, prepared['expected_source_delta'], prepared['expected_test_count'])
    save(BUILD / 'build-readback.json', bindings)
    pair, selected = bindings['pair'], bindings['control_pair']

    # Retain all conditions, randomization, timing arithmetic, callback checks and limits.
    NATIVE.mkdir()
    for mode in ['normal', 'pgo']:
        old, out = BASE_NATIVE / mode, NATIVE / mode
        original = read(old / 'adaptation.json')
        assert sha(old / 'native_screen.py') == original['controller_sha256'] and sha(old / 'run.py') == original['wrapper_sha256']
        candidate_lib, control_lib = library(BUILD, pair, mode), library(CONTROL, selected, mode)
        assert original['candidate_library'] == {'path': str(control_lib), 'sha256': sha(control_lib)}
        assert sha(original['expat_library']['path']) == original['expat_library']['sha256']
        before = (old / 'native_screen.py').read_text()
        replacements = [(original['candidate_library']['path'], str(candidate_lib)), (original['control_library']['path'], str(control_lib)), (str(old), str(out)), ('Direct character-reference frame', 'Second-byte markup classification'), ('selected suffix-sharing element-name baseline', 'selected direct-reference frame baseline')]
        after = before
        for left, right in replacements:
            assert left in after
            after = after.replace(left, right)
        restored = after
        for left, right in reversed(replacements):
            restored = restored.replace(right, left)
        assert restored == before and ast.dump(ast.parse(restored)) == ast.dump(ast.parse(before))
        out.mkdir()
        (out / 'native_screen.py').write_text(after)
        (out / 'run.py').write_bytes((old / 'run.py').read_bytes())
        (out / 'adaptation.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True))))
        save(out / 'adaptation.json', {'status': 'passed', 'prepared_not_executed': True, 'source_manifest_sha256': sha(BUILD / 'source.json'), 'control_source_manifest_sha256': sha(CONTROL / 'source.json'), 'build_pair_sha256': sha(BUILD / 'pair-report.json'), 'control_build_pair_sha256': sha(CONTROL / 'pair-report.json'), 'build_readback_sha256': sha(BUILD / 'build-readback.json'), 'controller_sha256': sha(out / 'native_screen.py'), 'wrapper_sha256': sha(out / 'run.py'), 'candidate_library': {'path': str(candidate_lib), 'sha256': sha(candidate_lib)}, 'control_library': {'path': str(control_lib), 'sha256': sha(control_lib)}, 'expat_library': original['expat_library'], 'origin': str(old), 'replacement_pairs': replacements, 'inverse_text_and_ast_equal': True, 'scope': 'Second-byte markup classification candidate ' + args.head + ' versus selected direct-reference frame control 0f66d54. Source72 and pipeline69 differ only in lib.rs. Same 28 conditions, seven pairs, 2026091003 seed, callbacks, limits and compiler settings. Ordinary tag classification changes; all adverse conditions must be reported. Preparation executes no parser/compiler/elapsed targets.'})
    print(json.dumps({'status': 'prepared_not_executed', 'head': args.head, 'native_study': str(NATIVE), 'measurement_order': 'Normal native screen first; all remaining targets await root release.', 'build_summary': bindings['summary'], 'targets_executed': False}))


if __name__ == '__main__':
    main()
