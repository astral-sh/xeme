"""Bind a confirmed markup-classification commit to the unchanged normal/PGO protocol."""
from pathlib import Path
import argparse
import ast
import difflib
import hashlib
import json
import re
import shutil
import subprocess

OUTPUT = Path('/tmp/oriole-markup-classification-pgo-study')
WORKTREE = Path('/home/dev-user/code/oss/oriole-markup-classification')
CONTROL = Path('/tmp/oriole-reference-frame-pgo-study')
CHECKS = Path('/tmp/oriole-markup-classification-checks')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--head', required=True, help='Root-confirmed clean composed candidate commit')
    parser.add_argument('--expected-source-delta', required=True, type=Path, help='Reviewed JSON array of changed source paths')
    parser.add_argument('--expected-test-count', required=True, type=int, help='Root-confirmed count from completed tests')
    parser.add_argument('--checks-dir', type=Path, default=CHECKS, help='Completed summary.json and per-command JSON/log receipts')
    parser.add_argument('--check-attempt', default='01', help='Completed check attempt suffix, such as 02; earlier attempts remain untouched')
    args = parser.parse_args()
    checks_root = args.checks_dir.resolve()
    assert re.fullmatch(r'[0-9]{2}', args.check_attempt)
    args.expected_source_delta = args.expected_source_delta.resolve()
    check_labels = [phase + args.check_attempt for phase in ['fmt', 'check', 'tests', 'clippy']]
    test_label = 'tests' + args.check_attempt
    delta = read(args.expected_source_delta)
    assert isinstance(delta, list) and delta and all(isinstance(name, str) for name in delta)
    assert len(delta) == len(set(delta)) and args.expected_test_count > 0
    delta = sorted(delta)
    assert __debug__ and re.fullmatch('[0-9a-f]{40}', args.head)
    head = subprocess.check_output(['git', '-C', str(WORKTREE), 'rev-parse', 'HEAD'], text=True).strip()
    assert head == args.head
    assert not subprocess.check_output(['git', '-C', str(WORKTREE), 'status', '--porcelain'])
    control = read(CONTROL / 'source.json')
    source = {name: sha(WORKTREE / name) for name in control['source_sha256']}
    assert len(source) == 72
    assert sorted(name for name in source if source[name] != control['source_sha256'][name]) == delta
    assert all(hashlib.sha256(subprocess.check_output(['git', '-C', str(WORKTREE), 'show', head + ':' + name])).hexdigest() == digest for name, digest in source.items())
    commands = []
    rust_files = {name for name in source if name.startswith('crates/') and name.endswith('.rs')}
    summary = read(checks_root / 'summary.json')
    assert summary['status'] == 'passed' and summary['test_count'] == args.expected_test_count
    assert [row['label'] for row in summary['commands']] == check_labels
    assert summary['source_after'] == {name: source[name] for name in rust_files}
    for label in check_labels:
        row = read(checks_root / (label + '.json'))
        assert row == next(command for command in summary['commands'] if command['label'] == label)
        assert row['exit'] == 0 and row['reaped'] and row['source_before'] == row['source_after']
        assert set(row['source_after']) == rust_files
        assert all(source[name] == digest for name, digest in row['source_after'].items())
        assert sha(checks_root / (label + '.log')) == row['log_sha256']
        commands.append(row | {'argv': row['command'], 'source_unchanged': True, 'source_sha256': row['source_after']})
    groups = [tuple(map(int, values)) for values in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (checks_root / (test_label + '.log')).read_text())]
    assert groups and sum(row[0] for row in groups) == args.expected_test_count and all(row[1:] == (0, 0) for row in groups)
    assert len(groups) == summary['test_groups']
    scripts = read(CONTROL / 'tool-source.json')
    assert len(scripts) == 6 and all(sha(CONTROL / 'pipeline' / name) == digest for name, digest in scripts.items())
    before = (CONTROL / 'build_pair.py').read_text()
    assert sha(CONTROL / 'build_pair.py') == 'c2d7bb9e3f23f468f3e4702c0985513132df79a1411beb470a2f4df12e66f756'
    after = before.replace('/home/dev-user/code/oss/oriole-reference-frame', str(WORKTREE))
    after = after.replace('/home/dev-user/.cache/oriole/targets/reference-frame', '/home/dev-user/.cache/oriole/targets/markup-classification')
    after = after.replace("CONTROL=Path('/tmp/oriole-suffix-element-names-pgo-study')", "CONTROL=Path('/tmp/oriole-reference-frame-pgo-study')")
    after = after.replace("checks['test_count']==440", f"checks['test_count']=={args.expected_test_count}")
    after = after.replace('Direct character-reference adapter frame candidate versus selected suffix-sharing element-name runtime a0acaf1. The exact reviewed source delta is recorded in preparation.json. The source delta may include inherited integration coverage; selected allocator, original generated training and compiler recipe are unchanged. Error handling, source position and callback behavior require separate correctness review; no speedup is assumed.', 'Second-byte markup classification candidate versus selected direct-reference frame runtime 0f66d54. Source72 and pipeline69 differ only in crates/oriole/src/lib.rs. The local lexical predicate routes ordinary tags to the existing Tag scanner; selected allocator, callback delivery, source accounting, original generated training and compiler recipe are unchanged. The exact reviewed source delta is recorded in preparation.json; no speedup is assumed.')
    after = after.replace('versus selected suffix-sharing element-name controls.', 'versus selected direct-reference frame controls.')
    assert before[before.index('def save()'):] == after[after.index('def save()'):]
    ast.parse(after)
    assert not OUTPUT.exists(), 'Retain every first attempt; no overwrite'
    OUTPUT.mkdir()
    save(OUTPUT / 'source.json', {'status': 'recorded_source', 'base_runtime': control['candidate_base_commit'], 'candidate_base_commit': head, 'worktree': str(WORKTREE), 'source_sha256': source, 'source_count': len(source), 'scope': 'Classify ordinary markup with a second-lexical-byte predicate before the unchanged declaration branch; only lib.rs differs from selected direct-reference frames. The compiler recipe and selected allocator remain unchanged. No measured benefit is assumed.'} )
    (OUTPUT / 'source.patch').write_bytes(subprocess.check_output(['git', '-C', str(WORKTREE), 'diff', control['candidate_base_commit'], head, '--', *delta]))
    (OUTPUT / 'local-checks').mkdir()
    save(OUTPUT / 'local-checks/final-checks.json', {'status': 'passed', 'commands': commands})
    shutil.copytree(checks_root, OUTPUT / 'local-checks/original')
    for row in commands:
        dest = OUTPUT / 'local-checks' / row['label']
        dest.mkdir()
        shutil.copyfile(checks_root / (row['label'] + '.json'), dest / 'report.json')
        shutil.copyfile(checks_root / (row['label'] + '.log'), dest / 'output.log')
    save(OUTPUT / 'source-checks.json', {'status': 'passed', 'test_count': args.expected_test_count, 'test_groups': len(groups), 'failed': 0, 'ignored': 0, 'commands': commands, 'source_manifest_sha256': sha(OUTPUT / 'source.json'), 'check_report_sha256': sha(OUTPUT / 'local-checks/final-checks.json')})
    for name in scripts:
        dest = OUTPUT / 'pipeline' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(CONTROL / 'pipeline' / name, dest)
    shutil.copyfile(CONTROL / 'tool-source.json', OUTPUT / 'tool-source.json')
    (OUTPUT / 'build_pair.py').write_text(after)
    (OUTPUT / 'controller.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True))))
    save(OUTPUT / 'preparation.json', {'status': 'prepared_not_executed', 'head': head, 'check_attempt': args.check_attempt, 'check_labels': check_labels, 'expected_source_delta': delta, 'expected_pipeline_delta': [name for name in delta if not name.startswith('tests/c/')], 'expected_source_delta_file': str(args.expected_source_delta), 'expected_source_delta_sha256': sha(args.expected_source_delta), 'expected_test_count': args.expected_test_count, 'test_groups': len(groups), 'control_head': control['candidate_base_commit'], 'preparer_sha256': sha(__file__), 'source_manifest_sha256': sha(OUTPUT / 'source.json'), 'controller_sha256': sha(OUTPUT / 'build_pair.py'), 'controller_body_byte_identical': True, 'targets_executed': False, 'measurement_order': 'Normal native first; later campaigns require root release after that result.'})
    print((OUTPUT / 'preparation.json').read_text())


if __name__ == '__main__':
    main()
