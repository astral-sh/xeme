# Saved-only markup classification native auditor

Prepared for candidate `b4e262db0ffd84cc73f7047b55adf568f7834651` against measured direct-reference frame control `0f66d54ac8418f0a6e628ad18570677a19c9ed45`. The selected runtime was subsequently published in PR144; this reader deliberately binds the measured source/library manifests. Both source72 and pipeline69 deltas must be exactly `crates/oriole/src/lib.rs`.

No auditor or compiler/parser/preflight/elapsed target has been executed during preparation. The original native validation and measurement block is byte-identical to `/tmp/oriole-reference-frame-native-independent-review/audit.py`: original wrapper/body checks, all 28 conditions, seven pairs, seeded order, 672 workers, 106176 samples, callback observations, commands, warmups, and all ratio calculations remain. The reader retains direct build-readback input pins and adds direct equality of the candidate/selected build execution body. The postbuild reader verifies actual compiler vectors and artifact/training bindings before this audit is eligible to run.

After root has reaped both build7103 and the normal native campaign, and has run the postbuild binder:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-markup-classification-native-independent-review/audit.py --released --head b4e262db0ffd84cc73f7047b55adf568f7834651 --phase normal
```

After separate root release and completion/reaping of a PGO native campaign, the same command with `--phase pgo` reads that campaign. Do not run it before PGO is actually collected.

Outputs are `normal-review.json` and `normal-conditions.csv`, or the corresponding `pgo-*` files. First outputs must not be overwritten. No suffix-sharing control assumptions remain in the auditor.

`audit.py` SHA256: `7f45b94ee63f16335a3cef57ff897b53bb4ce35bd0bed70b7e1d47a0e070a8e3`.

`adaptation.patch` preserves the exact reader delta; `preparation.json` records source/reader pins and static body equivalence. This reviewer also reviewed the runtime source and prepared the build/native controllers; it did not author the runtime or original benchmark arithmetic.
