# Markup classification source review

No actionable correctness or simplicity finding in the 14-line diff. This is a source-only review; no compiler, parser, test, timing, or benchmark target ran, and repository source was not modified. The candidate remains unselected pending root validation and measurement.

## Equivalence and error precedence

The loop has established that the source is nonempty and its first lexical byte is `<`. If a second byte exists and is neither `!` nor `?`, the old outside-root `<![` check, full declaration/PI tests, partial-declaration tests, and unknown-declaration error were all false. The old end-tag branch or final fallback selected `ScanMode::Tag`. The new branch selects exactly that mode without moving any fallible or state-mutating operation.

For a lone `<`, the predicate is false, preserving the incomplete-markup final/nonfinal decision. Every `<!...` and `<?...` spelling also follows the unchanged exceptional branch, including contextual Syntax/JunkAfterDocumentElement for partial CDATA and incomplete/invalid declaration distinctions. Root, closed-root, and fragment state cannot alter this exclusion proof.

Malformed ordinary starts, invalid or unfinished end tags, Unicode name prefixes, token limits, deferred scans, and pending decoding errors still reach the identical name validation, finality, scanner, and error-position code. The predicate does not assert name validity or consume a byte. A non-ASCII UTF-8 leading byte simply selects the same Tag fallback as before.

`Source::remaining` exposes the existing lexical string. Custom multi-byte ASCII aliases are represented by non-ASCII characters (`lexical.rs::representative`) while genuine markup retains its ASCII spelling. Both old and new classifiers inspect that same string. The gate neither changes raw-width projection nor bypasses custom name validation. UTF-16 decoding and incomplete units also occur before this classification; later decoding-error precedence is untouched.

## Existing meaningful coverage

- `parser.rs::truncated_cdata_openers_and_utf16_units_have_contextual_errors`: contextual partial CDATA and UTF-16 endings across every chunk width.
- `parser.rs::streaming_tokens_references_and_normalization` and `reject_malformed_xml`: ordinary tags, declarations, comments, PI, CDATA, illegal names, and malformed tokens.
- `diagnostics.rs::invalid_reference_and_end_tag_prefixes_take_precedence_over_eof`, `valid_unfinished_reference_and_end_tag_prefixes_remain_unclosed`, and `malformed_prefixes_precede_a_later_decoding_failure`: exact error kinds/offsets, incremental input, and both deferral settings where applicable.
- `diagnostics.rs::long_unicode_names_and_end_tag_whitespace_resume_across_small_feeds`, plus `multibyte.rs` name/byte-position, ASCII-alias, and raw-delimiter cases: non-ASCII and custom lexical behavior.

No new test is required solely to mirror this predicate; the unchanged suites remain the execution gate. This review does not claim they passed. The source change adds one local boolean and reuses the old branch without storage, allocation, unsafe indexing, or a cached parser state. Retaining the old exceptional classifier is appropriately small in scope.

## Exact reviewed state

The JSON manifest records HEAD, source hashes, and the saved patch hash. `git diff --check` passed. `git status --short` showed only `crates/oriole/src/lib.rs` modified. Performance benefit and generated-code quality are outside this source review.
