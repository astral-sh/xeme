# Next bounded real-project proposal: ordinary markup classification

**Proposal only: add a second-byte gate before the existing markup classifier.** No implementation, compiler, parser, profile or timing target ran in this investigation. This is the clearest remaining small redundant-work proposal found in the inspected evidence, not a demonstrated large bottleneck or a prediction of reaching the Expat target.

## Change boundary

At `crates/oriole/src/lib.rs:2089` in the selected suffix/direct-reference source, input is already nonempty and its first lexical byte is `<`. If a second byte exists and is neither `!` nor `?`, select `ScanMode::Tag`. Keep the existing classifier and leading `<![` outside-root check unchanged when this local predicate is false. The drafted patch uses one local boolean at both existing checks, avoiding reindentation of the exceptional branch. This retains the old behavior for `<`, `<!...`, and `<?...`; it routes both ordinary opening names and closing tags to their existing later checks.

This is a read-only lexical classification. Do not add a cached parser mode, token executor, new storage field, unsafe indexing, eager token scan, ASCII-name acceptance rule, or new source borrow across mutation. All existing first-name legality, matching-end checks, deferral, finality, token bounds, TagScanner/generic fallback, source accounting, raw scratch ownership and publication stay after the classifier exactly as before. Invalid ordinary tag/name bytes still reach the same name/scanner error logic. Converted/custom lexical representations use the same existing byte/string semantics.

The exclusion proof is simple: when the second byte is present and is neither `!` nor `?`, the old `<![`, `<!--`, `<![CDATA[`, `<?`, `<!DOCTYPE`, partial-declaration and unknown-declaration conditions are all false; `</` and the final branch both select Tag. The initial `<`-only incomplete case remains in the original branch. No fallible or state-mutating work moves on the newly selected ordinary path.

## Observed envelope

Closest saved instruction profiles measure Context source `0f28139f83b04290e62301c38d8ed489f183a88d`, library `7cd7c5a8ef99d06097e3be388ff36c62d4f14da04d9a8e48988c5f0217373e83`. The disjoint, instruction-level `markup_prefix_classification` region includes the required short-input/declaration classification work and remains a gross envelope, not removable instructions or time:

| 4 KiB condition | Region Ir | Share of total Ir |
| --- | ---: | ---: |
| vulkan-ns0 | 9,311,842 | 1.3650% |
| vulkan-ns1 | 9,311,842 | 1.3177% |
| wayland-ns0 | 114,272 | 0.7425% |
| maven-ns0 | 179,316 | 1.5474% |
| maven-ns1 | 179,316 | 1.0859% |
| gtk-ns0 | 58,048 | 1.1352% |

The main observed path loads and compares full comment, CDATA and DOCTYPE openers even for ordinary element tags. Vulkan visits this region about 189,576 times across two collected parses. Ordinary source first-byte selection, name validation, scanning, accounting and callback costs are outside this envelope.

The current suffix PGO DSO is separately verified as SHA256 `5872374889ad673fcf7f397057de33a95a1e8f72be591b9bb996b8dbc1fd9280`, at `/tmp/oriole-suffix-element-names-pgo-study/pgo/runs/run-kj_rp37s/use/liboriole_expat.so`. Read-only disassembly in `suffix-classifier.asm` confirms the same prefix chain at `0x3e4fc..0x3e5ef`, including comment compare `0x3e54f`, CDATA setup `0x3e565`, PI compare `0x3e586`, DOCTYPE setup `0x3e591` and end-tag compare `0x3e5b5`. This static confirmation does not transfer historical instruction counts onto the suffix build or the newly built scalar-frame candidate.

The potential net saving is smaller than the displayed 0.74–1.55% envelope because the replacement needs a length/byte test and declaration inputs retain full work. Nothing here establishes a large fraction of the remaining native elapsed gap.

## Prior-attempt exclusions

- All 102 inspected local worktree `crates/oriole/src/lib.rs` files still use the same `let mode = if remaining.starts_with("<!--")` chain. Bounded searches of immediate saved patches and all local Git log subjects found no prior second-byte classifier experiment. This is a bounded search, not proof about every historical artifact.
- Rejected **native-tag execution** preserved this recognition phase and split the later already-recognized token execution/lowering. Its PGO real ratio was 1.008560552, with all four generated conditions adverse. This proposal does not repeat that executor split.
- Rejected **parameter-reference presence** already tested guarding the empty 88-byte Option take. Normal text stress regressed 7.66%, PGO 2.08%. Do not present that attractive-looking profile row as untried.
- Rejected **compact delivery status** changed the private return ABI; **scoped error split** changed error outlining; neither identifies this byte-classification gate. Continuation grouping has only a 0.21–0.35% gross region and was already documented as too small to prioritize.
- Lazy coordinate variants, core serialized counters, callback-frame reuse, namespace/name ownership variants, and start-tag shape caching have their own negative evidence. Their larger gross profile regions do not override those results. Scalar reference frames remain a separate current candidate.

## Bounded decision and validation

Implement at most this classifier gate, with the original exceptional classifier kept intact. First verify that ordinary tag code generation actually branches around the full-prefix comparisons without equivalent setup moved before the gate. A smaller total function size alone is insufficient. Then reuse the established unchanged correctness and paired normal/fresh-PGO native campaigns, retaining every real/generated condition; reject the candidate if its small mechanism does not produce a useful balanced result.

Meaningful focused coverage is the short lexical boundary: every split/finality state of `<`, `</`, `<!`, `<![`, `<!--`, `<![CDATA[`, `<!DOCTYPE`, `<?`, invalid declaration/name prefixes, and legal non-ASCII names. Verify root/closed-root/fragment and UTF-16/custom provenance behavior with exact event/raw/position/error traces. The classifier itself allocates nothing; existing downstream OOM and C handler-mutation/suspension gates remain unchanged. Do not add accepted-failure lists or relax callback assertions for this candidate, which intends identical semantics.

## Evidence pointers

- `/tmp/oriole-context-text-frame-current-profile-review/{README.md,regions.json}`
- `/tmp/oriole-context-text-frame-maven-gtk-profile-review/{README.md,regions.json}`
- `/tmp/oriole-c-delivery-setup-review/README.md`
- `/tmp/oriole-context-guard-repetition-plan/README.md`
- `/tmp/oriole-native-tag-execution-source-independent-review.json`
- `/tmp/oriole-parameter-reference-presence-build-stress-independent-review.json`

Observed input hashes:
- `/tmp/oriole-context-text-frame-current-profile-review/regions.json`: `350e28516a0c71d446f30ad8cae86840e9b710e7415480e6a79e2de68099a838`
- `/tmp/oriole-context-text-frame-maven-gtk-profile-review/regions.json`: `18eba301e808b86034bf23edcf6dc08f61215bb4a82a92aa15b04d2bbcf90c19`

## Prepared patch

`markup-classification.patch` contains only the local byte predicate and its two uses in `crates/oriole/src/lib.rs`, based on committed direct-reference source `0f66d54ac8418f0a6e628ad18570677a19c9ed45`. `selected-lib.rs` and `proposed-lib.rs` preserve the input and proposed source. Existing worktrees were not modified. The patch has not been formatted by Cargo, compiled, or executed.

No new test is drafted: existing `parser.rs::truncated_cdata_openers_and_utf16_units_have_contextual_errors` already checks the crucial Syntax/JunkAfterDocumentElement/UnclosedToken distinctions across every chunk width; `diagnostics.rs` checks invalid and unfinished end tags, exact error offsets, and both deferral settings. `streaming_tokens_references_and_normalization`, `reject_malformed_xml`, multibyte/custom provenance and adapter differential tests cover the ordinary and exceptional paths. The planned build still needs those unchanged tests; this source-only assessment is not an execution claim.

- `selected-lib.rs` SHA256: `246e281e1fcdc2c181714e78e8da05dbee4bd66f59ef95b2bc59449e4c3a43d4`
- `proposed-lib.rs` SHA256: `2ad5d2c9a95826f46215eba6a811a738b5f292f3f9352e5338eb7d9d703af57d`
- `markup-classification.patch` SHA256: `a3a996512dc935610bfd29c08ba8947ca78544b4ba0742b54b7f04153c531f36`
