
/tmp/oriole-suffix-element-names-pgo-study/pgo/runs/run-kj_rp37s/use/liboriole_expat.so:     file format elf64-x86-64


Disassembly of section .text:

000000000003e4fc <<oriole::Parser>::next_event_inner+0x4ac>:
   3e4fc:	49 83 fe 03          	cmp    r14,0x3
   3e500:	0f 82 7b 47 00 00    	jb     42c81 <<oriole::Parser>::next_event_inner+0x4c31>
   3e506:	0f b7 08             	movzx  ecx,WORD PTR [rax]
   3e509:	81 f1 3c 21 00 00    	xor    ecx,0x213c
   3e50f:	0f b6 50 02          	movzx  edx,BYTE PTR [rax+0x2]
   3e513:	83 f2 5b             	xor    edx,0x5b
   3e516:	66 09 ca             	or     dx,cx
   3e519:	0f 95 c2             	setne  dl
   3e51c:	49 8b 8f d0 02 00 00 	mov    rcx,QWORD PTR [r15+0x2d0]
   3e523:	48 85 c9             	test   rcx,rcx
   3e526:	40 0f 95 c6          	setne  sil
   3e52a:	40 08 d6             	or     sil,dl
   3e52d:	41 0f b6 b7 5a 09 00 	movzx  esi,BYTE PTR [r15+0x95a]
   3e534:	00 
   3e535:	b2 01                	mov    dl,0x1
   3e537:	0f 84 09 79 00 00    	je     45e46 <<oriole::Parser>::next_event_inner+0x7df6>
   3e53d:	84 d2                	test   dl,dl
   3e53f:	0f 84 2a b1 01 00    	je     5966f <<oriole::Parser>::next_event_inner+0x1b61f>
   3e545:	49 83 fe 03          	cmp    r14,0x3
   3e549:	0f 84 6b 0d 00 00    	je     3f2ba <<oriole::Parser>::next_event_inner+0x126a>
   3e54f:	81 38 3c 21 2d 2d    	cmp    DWORD PTR [rax],0x2d2d213c
   3e555:	0f 84 69 18 00 00    	je     3fdc4 <<oriole::Parser>::next_event_inner+0x1d74>
   3e55b:	49 83 fe 09          	cmp    r14,0x9
   3e55f:	0f 82 55 0d 00 00    	jb     3f2ba <<oriole::Parser>::next_event_inner+0x126a>
   3e565:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   3e568:	48 bf 3c 21 5b 43 44 	movabs rdi,0x41544144435b213c
   3e56f:	41 54 41 
   3e572:	48 31 fa             	xor    rdx,rdi
   3e575:	0f b6 78 08          	movzx  edi,BYTE PTR [rax+0x8]
   3e579:	48 83 f7 5b          	xor    rdi,0x5b
   3e57d:	48 09 d7             	or     rdi,rdx
   3e580:	0f 84 ab 26 00 00    	je     40c31 <<oriole::Parser>::next_event_inner+0x2be1>
   3e586:	66 81 38 3c 3f       	cmp    WORD PTR [rax],0x3f3c
   3e58b:	0f 84 37 0d 00 00    	je     3f2c8 <<oriole::Parser>::next_event_inner+0x1278>
   3e591:	48 8b 10             	mov    rdx,QWORD PTR [rax]
   3e594:	48 bf 3c 21 44 4f 43 	movabs rdi,0x505954434f44213c
   3e59b:	54 59 50 
   3e59e:	48 31 fa             	xor    rdx,rdi
   3e5a1:	0f b6 78 08          	movzx  edi,BYTE PTR [rax+0x8]
   3e5a5:	48 83 f7 45          	xor    rdi,0x45
   3e5a9:	45 31 c0             	xor    r8d,r8d
   3e5ac:	48 09 d7             	or     rdi,rdx
   3e5af:	0f 84 3b 6c 00 00    	je     451f0 <<oriole::Parser>::next_event_inner+0x71a0>
   3e5b5:	66 81 38 3c 2f       	cmp    WORD PTR [rax],0x2f3c
   3e5ba:	0f 84 f0 46 00 00    	je     42cb0 <<oriole::Parser>::next_event_inner+0x4c60>
   3e5c0:	0f b7 10             	movzx  edx,WORD PTR [rax]
   3e5c3:	81 f2 3c 21 00 00    	xor    edx,0x213c
   3e5c9:	0f b6 78 02          	movzx  edi,BYTE PTR [rax+0x2]
   3e5cd:	83 f7 5b             	xor    edi,0x5b
   3e5d0:	66 09 d7             	or     di,dx
   3e5d3:	0f 94 c2             	sete   dl
   3e5d6:	41 84 d0             	test   r8b,dl
   3e5d9:	0f 85 6a 97 01 00    	jne    57d49 <<oriole::Parser>::next_event_inner+0x19cf9>
   3e5df:	66 81 38 3c 21       	cmp    WORD PTR [rax],0x213c
   3e5e4:	ba 01 00 00 00       	mov    edx,0x1
   3e5e9:	0f 84 e6 91 01 00    	je     577d5 <<oriole::Parser>::next_event_inner+0x19785>
