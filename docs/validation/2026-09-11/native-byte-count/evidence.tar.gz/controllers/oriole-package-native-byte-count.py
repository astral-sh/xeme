"""Publish one frozen runtime and its complete measured/validated evidence."""
from pathlib import Path
import argparse
import hashlib
import io
import json
import shutil
import statistics
import subprocess
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('--gates-handoff', type=Path, required=True)
parser.add_argument('--python-review', type=Path, required=True)
args = parser.parse_args()
repo = Path('/home/dev-user/code/oss/oriole-native-byte-count')
out = repo / 'docs/validation/2026-09-11/native-byte-count'
bench = repo / 'benchmarks/results/2026-09-11/native-byte-count'
read = lambda p: json.loads(Path(p).read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
source = Path('/tmp/oriole-native-byte-count-study')
build = Path('/tmp/oriole-native-byte-count-thinlto-study')
workspace = Path('/tmp/oriole-native-byte-count-workspace-gates')
gates = Path('/tmp/oriole-native-byte-count-gates')
native = Path('/tmp/oriole-raw-len-split-thinlto-timing-study')
python = Path('/tmp/oriole-raw-len-split-thinlto-python-root-study')
cpython = Path('/tmp/oriole-native-byte-count-thinlto-cpython-gates')
source_review = Path('/tmp/oriole-native-byte-count-source-build-independent-review')
cpython_review = Path('/tmp/oriole-native-byte-count-thinlto-cpython-root-review')
ws = read(workspace / 'summary.json')
assert (ws['target_inventory_rows'], ws['all_target_tests'], ws['doc_tests']) == (33, 407, 1)
g = read(gates / 'summary.json')
assert g['status'] == 'correctness_parity_gates_passed'
assert g['api']['all4740rows_exact'] and (g['api']['passed'], g['api']['failed']) == (4347, 393)
b = read(build / 'report.json')
assert b['status'] == 'passed' and all(b['library_bytes_identical_to_control'].values())
s = read(source / 'source.json')
assert len(s['source_sha256']) == 70
for name, digest in s['source_sha256'].items():
    assert sha((repo / name).read_bytes()) == digest
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD^'], cwd=repo, text=True).strip()
assert head == 'be22a271f8a5c004d13e515cd4024a68afe57887'
assert parent == '079fb66dc159cdc0e1c3ad16397f149751783014'
patch = subprocess.check_output(['git', 'diff', 'HEAD^', 'HEAD', '--binary'], cwd=repo)
assert patch == (source / 'candidate.patch').read_bytes()
assert read(cpython_review / 'review.json')['status'] == 'strict_cpython_saved_outcomes_and_origins_verified'
assert read(args.python_review / 'review.json')['status'] == 'independent_saved_raw_len_python_audit_passed'
assert args.gates_handoff.is_dir()
directories = {
    'prototype-native': Path('/tmp/oriole-raw-len-split-handoff'),
    'source': source,
    'build': build,
    'workspace': workspace,
    'gates': args.gates_handoff,
    'python': python,
    'cpython': cpython,
    'source-build-review': source_review,
    'python-review': args.python_review,
    'cpython-root-review': cpython_review,
    'python-initial-directory-collision': Path('/tmp/oriole-raw-len-python-directory-collision'),
}
controllers = [Path(__file__), Path('/tmp/oriole-summarize-cohorts.py'),
               Path('/tmp/oriole-prepare-raw-len-split-thinlto-python-root.py'),
               Path('/tmp/oriole-time-raw-len-split-thinlto-python-root.py'),
               Path('/tmp/oriole-native-byte-count-thinlto-cpython-gates.py'),
               Path('/tmp/oriole-native-byte-count-thinlto-cpython-controller.patch')]
paths = {}
for prefix, directory in directories.items():
    assert directory.is_dir(), directory
    for p in sorted(directory.rglob('*')):
        if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:
            paths[prefix + '/' + str(p.relative_to(directory))] = p
for p in controllers:
    assert p.is_file(), p
    paths['controllers/' + p.name] = p
out.mkdir(exist_ok=False, parents=True)
bench.mkdir(exist_ok=False, parents=True)
members, excluded = [], []
with tarfile.open(out / 'evidence.tar.gz', 'w:gz', compresslevel=9) as archive:
    for name, p in sorted(paths.items()):
        data = p.read_bytes()
        entry = {'path': name, 'source': str(p), 'bytes': len(data), 'sha256': sha(data)}
        if data.startswith((b'\x7fELF', b'!<arch>\n')):
            excluded.append(entry)
            continue
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o644, 0
        archive.addfile(info, io.BytesIO(data))
        members.append(entry)
with tarfile.open(out / 'evidence.tar.gz', 'r:gz') as archive:
    actual = archive.getmembers()
    assert len(actual) == len(members)
    for member, entry in zip(actual, members):
        assert member.isfile() and member.name == entry['path'] and member.size == entry['bytes']
        assert sha(archive.extractfile(member).read()) == entry['sha256'] == sha(Path(entry['source']).read_bytes())
for entry in excluded:
    assert sha(Path(entry['source']).read_bytes()) == entry['sha256']
(out / 'archive-members.json').write_text(json.dumps({'members': members, 'excluded_binaries': excluded}, indent=2) + '\n')
copies = {'source.json': source / 'source.json', 'build.json': build / 'report.json',
          'workspace.json': workspace / 'summary.json', 'gates.json': gates / 'summary.json',
          'native-summary.json': native / 'summary.json', 'python-summary.json': python / 'summary.json',
          'source-build-review.json': source_review / 'review.json',
          'python-review.json': args.python_review / 'review.json',
          'cpython-root-review.json': cpython_review / 'review.json'}
for name, p in copies.items():
    shutil.copy2(p, out / name)
summary = {'runtime_commit': head, 'parent_commit': parent,
           'source_manifest_sha256': sha((source / 'source.json').read_bytes()),
           'committed_patch_sha256': sha(patch), 'source_files': 70,
           'libraries': b['libraries'], 'workspace': ws, 'api': g['api'],
           'cpython_each_linkage': {'methods': 802, 'failures': 2, 'reported_skips': 14, 'expected_failures': 3},
           'native': read(native / 'summary.json')['groups'],
           'python': read(python / 'summary.json'),
           'archive': {'sha256': sha((out / 'evidence.tar.gz').read_bytes()),
                       'bytes': (out / 'evidence.tar.gz').stat().st_size,
                       'members': len(members), 'binary_exclusions': len(excluded),
                       'all_direct_members_and_origins_read_back': True},
           'scope': 'Native byte-count extraction atop PR115. Measured prototype and integrated release libraries are byte-identical; integration inherits only the parent Windows test cast. Current normal C-only ThinLTO measurements, without PGO or alternate allocator. Strict CPython retains two failures; no new sustained Rust sanitizer campaign or full PBS distribution build.'}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
n = read(native / 'native-screen/results.json')
labels = {'vulkan': 'Vulkan registry', 'wayland': 'Wayland protocol', 'maven': 'Maven POM',
          'batik': 'Batik SVG', 'gtk': 'GTK UI', 'docbook': 'DocBook XSL'}
table = []
for name, label in labels.items():
    row = next(r for r in n['summary'] if r['condition']['name'] == name and r['condition']['chunk'] == 4096 and not r['condition']['namespaces'])
    rows = [r for r in n['rows'] if r['condition'] == row['condition']]
    times = {e: statistics.median(next(p['median_seconds'] for p in r['processes'] if p['engine'] == e) for r in rows) * 1000 for e in ['candidate', 'expat']}
    table.append(f"| {label} | {times['candidate']:.3f} ms | {times['expat']:.3f} ms | {row['median_ratios']['candidate_over_expat']:.2f}× |")
(out / 'table.md').write_text('\n'.join(table) + '\n')
print(json.dumps({'archive': summary['archive'], 'table': table}, indent=2))
