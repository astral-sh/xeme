import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

out = Path('/tmp/oriole-raw-len-split-thinlto-python-root-study')
out.mkdir(exist_ok=False)
old = Path('/tmp/oriole-thinlto-production-python-study')
python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
for name in ['build_consumers.py', 'python_worker.py']:
    shutil.copy2(old / name, out / name)
before = (old / 'consumer_screen.py').read_text()
after = before.replace('Three normal parser libraries: matched normal/9815cc85, same-source effective ThinLTO/a55ca0f0 candidate, and pinned Expat2.8.4.', 'Two Oriole C-only ThinLTO libraries: selected detached End plus Cell/02fcab59, inlined native byte counts/ccfb2295 candidate, and pinned normal Expat2.8.4.')
after = after.replace('args.phase == "prepare" and os.sched_getaffinity(0) != {3}', 'args.phase == "prepare" and os.sched_getaffinity(0) != {5}').replace('Preflights require CPU3', 'Preflights require CPU5')
old_caption = 'Candidate and published retain two known unchanged CPython callback-grouping test failures; canonical fixture outputs must match Expat.'
assert old_caption in after
after = after.replace(old_caption, 'The selected control has two known CPython callback-grouping failures. No fresh strict CPython suite has run on this native-byte-count candidate; canonical fixture outputs must match Expat.')
assert before != after
(out / 'consumer_screen.py').write_text(after)
(out / 'controller.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='reviewed-consumer-screen', tofile='raw-len-split-thinlto-screen')))
shutil.copy2(__file__, out / Path(__file__).name)
jobs = [
    ('build', ['taskset', '-c', '5', python, '-I', '-S', str(out / 'build_consumers.py'), '--library', '/tmp/oriole-raw-len-split-thinlto-study/liboriole_expat.so', '--reference', '/tmp/oriole-end-frame-cells-thinlto-study/liboriole_expat.so', '--expat', '/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4', '--source', '/home/dev-user/.cache/oriole/upstream/cpython-3.12.13', '--header', '/home/dev-user/code/oss/oriole-raw-len-split/include', '--output', str(out / 'consumers')]),
    ('preflight', ['taskset', '-c', '5', python, '-I', '-S', str(out / 'consumer_screen.py'), '--kind', 'python', '--phase', 'prepare', '--build', str(out / 'consumers/build.json'), '--input', '/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json', '--output', str(out / 'screen')]),
]
report = {'status': 'incomplete', 'jobs': []}
try:
    for name, command in jobs:
        with (out / (name + '.log')).open('wb') as log:
            run = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=600)
        report['jobs'].append({'name': name, 'command': command, 'exit': run.returncode})
        print(name, run.returncode, flush=True)
        assert run.returncode == 0
    report['status'] = 'passed'
finally:
    (out / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')
