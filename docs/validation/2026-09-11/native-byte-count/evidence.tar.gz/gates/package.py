"""Package frozen integration source, fresh build and completed bounded gates."""
from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile
O=Path('/tmp/oriole-native-byte-count-validation-handoff');O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
S=Path('/tmp/oriole-native-byte-count-study');B=Path('/tmp/oriole-native-byte-count-thinlto-study');G=Path('/tmp/oriole-native-byte-count-gates');W=Path('/tmp/oriole-native-byte-count-workspace-gates');source=load(S/'source.json');build=load(B/'report.json');gate=load(G/'summary.json');workspace=load(W/'workspace-checks/report.json');counts=load(W/'workspace-checks/counts.json')
assert len(source['source_sha256'])==70 and all(sha(Path(source['worktree'])/n)==h for n,h in source['source_sha256'].items())
assert build['status']=='passed' and build['fresh_workspace_compiles']==3 and all(build['library_bytes_identical_to_control'].values())
assert gate['status']=='correctness_parity_gates_passed' and gate['api']['raw_exit']==1 and gate['api']['passed']==4347 and gate['api']['failed']==393
assert workspace['status']=='passed' and workspace['unchanged'] and workspace['frozen_libraries_unchanged'] and len(workspace['commands'])==4 and all(r['exit']==0 for r in workspace['commands'])
assert counts['status']=='actual_inventory_verified' and counts['all_target_count']==407 and counts['doc_count']==1 and len(counts['all_target_rows'])==33 and not counts['added_tests']
roots={'source':S,'build':B,'c-gates':G,'workspace':W,'initial-cpu4-preparation':Path('/tmp/oriole-native-byte-count-gates-initial-cpu4'),'source-build-independent-review':Path('/tmp/oriole-native-byte-count-source-build-independent-review')}
inputs={};excluded=[]
for label,root in roots.items():
 for p in sorted(root.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  data=p.read_bytes()
  if data.startswith(b'\x7fELF') or data.startswith(b'!<arch>\n'):
   excluded.append({'source':str(p),'sha256':sha(p),'bytes':len(data)});continue
  inputs[label+'/'+str(p.relative_to(root))]=p
for name,p in [('control-api/results.json',Path('/tmp/oriole-end-frame-cells-thinlto-gates/api-native/upstream-api/results.json')),('control-api/manifest.json',Path('/tmp/oriole-end-frame-cells-thinlto-gates/api-native/upstream-api/manifest.json')),('control-workspace/tests.log',Path(counts['baseline_log'])),('prototype-build/report.json',Path('/tmp/oriole-raw-len-split-thinlto-study/report.json')),('prototype-build/source.json',Path('/tmp/oriole-raw-len-split-thinlto-study/source.json')),('prototype-build/compiler-invocations.json',Path('/tmp/oriole-raw-len-split-thinlto-study/compiler-invocations.json'))]:inputs[name]=p
members={n:{'source':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for n,p in inputs.items()}
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(inputs.items()):t.add(p,arcname=n,recursive=False)
nested=[]
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(members)
 for e in t.getmembers():
  assert e.isfile() and not e.name.startswith('/') and '..' not in Path(e.name).parts
  raw=t.extractfile(e).read();assert len(raw)==members[e.name]['bytes'] and hashlib.sha256(raw).hexdigest()==members[e.name]['sha256']
  if e.name.endswith('.tar.gz'):
   with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as inner:
    rows=[]
    for x in inner.getmembers():
     assert x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts
     b=inner.extractfile(x).read();rows.append({'name':x.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    if e.name.endswith('source.tar.gz'):
     n=e.name[:-len('source.tar.gz')]+'source.json'
     if n in inputs:assert {x['name']:x['sha256'] for x in rows}==load(inputs[n])['source_sha256']
    nested.append({'archive':e.name,'members':rows})
assert all(sha(p)==members[n]['sha256'] for n,p in inputs.items())
for n,v in [('members.json',members),('nested-readback.json',nested),('excluded-binaries.json',excluded)]: (O/n).write_text(json.dumps(v,indent=2)+'\n')
report={'status':'sealed_readback_passed','role':'Integration source/build/gate author; separately recorded independent integration source/compiler review. All saved gate outputs and actual Cargo inventory rehashed; no source-safety independence claimed by author.','commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source['worktree'],text=True).strip(),'source_manifest_sha256':sha(S/'source.json'),'patch_sha256':sha(S/'candidate.patch'),'source_files':70,'source_lineage':'Runtime is exact faf56975 prototype on079fb Windows portability base. Only the published cfg(test) c_long cast differs from1ff7-based measured source. Three fresh C-only compiles produce whole libraries byte-identical to measuredccfb/f58.','libraries':build['libraries'],'workspace':{'all_target_tests':407,'target_rows':33,'doc_tests':1,'all_four_commands_exit':0,'timeout_per_command_seconds':900,'new_tests':0,'test_inventory_equal_to_previous_EndCell':True,'report_sha256':sha(W/'workspace-checks/report.json'),'counts_sha256':sha(W/'workspace-checks/counts.json')},'c_gates':gate,'preserved_development_attempts':['Initial source verifier used an incorrect hand-written expected literal; failed before source freeze/build, corrected by verifying exact published opening.to_bytes cast. No source or test fixture edits.','CPU4 C-gate preparation had no parser runs; corrected to CPU1 before execution due root strictCPython lease.','Original other lane passed strict/custom/publication/malformed then End38 sorted CPU4 guard failed before any End parser. Originalfailure retained; final directory changes only CPU guards/report metadata to1 and runs remaining End38/End6 once.','First summary ran before saved classifier generated malformed/readback.json; failed postprocessing preserved. Classifier and unchanged summary then pass, no parser reruns.'],'independent_source_build_review_sha256':sha(roots['source-build-independent-review']/'review.json'),'outside_scope':['Root-owned strictCPython802 shared/static and actualPython timing packaged separately.','Prototype85 focused tests/32profiles/native588 timing package is separately sealed; no measurement regeneration here.','Original393 API failures and reference callback-position differences remain; no lowered limits, raised harness bounds or assertion waivers.'],'archive':{'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(members),'nested_archives':len(nested),'nested_members':sum(len(x['members']) for x in nested),'excluded_binary_paths':len(excluded),'readback':'All regular outer and nested members independently read from compressed bytes, hashes matched and source maps checked.'}}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');shutil.copyfile(__file__,O/'package.py');(O/'manifest.json').write_text(json.dumps({p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in O.iterdir() if p.is_file()},indent=2)+'\n');print(json.dumps({'archive':report['archive'],'manifest_sha256':sha(O/'manifest.json'),'report_sha256':sha(O/'report.json')}))
