"""Seal bounded prototype source/build/profile/native proof; no parser or source edits."""
from pathlib import Path
import hashlib,io,json,os,tarfile,shutil
O=Path('/tmp/oriole-raw-len-split-handoff');O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
roots={'source':Path('/tmp/oriole-raw-len-split-study'),'build':Path('/tmp/oriole-raw-len-split-thinlto-study'),'codegen':Path('/tmp/oriole-raw-len-split-codegen-study'),'instructions':Path('/tmp/oriole-raw-len-split-instruction-study'),'native':Path('/tmp/oriole-raw-len-split-thinlto-timing-study'),'source-build-review':Path('/tmp/oriole-raw-len-split-independent-review'),'profile-review':Path('/tmp/oriole-raw-len-split-profile-independent-review'),'native-review':Path('/tmp/oriole-raw-len-split-native-independent-review'),'python-scripts-only':Path('/tmp/oriole-raw-len-split-thinlto-python-study')}
assert load(roots['source']/'focused/report.json')['status']=='passed';build=load(roots['build']/'report.json');assert build['status']=='passed';ir=load(roots['instructions']/'profile/report.json');assert ir['status']=='passed';native=load(roots['native']/'summary.json');assert native['status']=='passed'
inputs={};excluded=[]
for label,root in roots.items():
 for p in sorted(root.rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  data=p.read_bytes()
  if data.startswith(b'\x7fELF') or data.startswith(b'!<arch>\n'):
   excluded.append({'path':str(p),'sha256':sha(p),'bytes':len(data)});continue
  inputs[label+'/'+str(p.relative_to(root))]=p
B=Path('/tmp/oriole-end-frame-cells-final-thinlto-study')
for name in ['source.json','source.tar.gz','report.json','compiler-invocations.json','release.log','build.py']:inputs['control-build/'+name]=B/name
for name in ['source.json','build.json']:inputs['original-control/'+name]=Path('/tmp/oriole-end-frame-cells-thinlto-study')/name
manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');inputs['benchmark-inputs/corpus-manifest.json']=manifest
for row in load(manifest)['projects']:
 entry=next(x for x in row['files'] if x['role']=='input');path=(manifest.parent/entry['path']).resolve();assert sha(path)==entry['sha256'];inputs['benchmark-inputs/'+entry['path']]=path
inputs['benchmark-inputs/rare-declarations.xml']=Path('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml');inputs['benchmark-inputs/entities.xml']=Path('/tmp/oriole-grammar-bench-plain/entities.xml');inputs['driver/native_driver.c']=Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c');inputs['driver/original-build.json']=Path('/tmp/oriole-grammar-bench-plain/summary.json')
for p in [B/'liboriole_expat.so',B/'liboriole_expat.a',Path('/tmp/oriole-grammar-bench-plain/native-driver'),Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4')]:excluded.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
members={n:{'sha256':sha(p),'bytes':p.stat().st_size,'source':str(p)} for n,p in inputs.items()}
archive=O/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(inputs.items()):t.add(p,arcname=n,recursive=False)
nested=[]
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(members)
 for entry in t.getmembers():
  assert entry.isfile() and entry.name in members and not entry.name.startswith('/') and '..' not in Path(entry.name).parts
  data=t.extractfile(entry).read();m=members[entry.name];assert len(data)==m['bytes'] and hashlib.sha256(data).hexdigest()==m['sha256']
  if entry.name.endswith('.tar.gz'):
   with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as inner:
    rows=[]
    for x in inner.getmembers():
     assert x.isfile() and not x.name.startswith('/') and '..' not in Path(x.name).parts
     raw=inner.extractfile(x).read();rows.append({'name':x.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    # Every source archive is checked against its adjacent frozen source map.
    source_name=entry.name[:-len('source.tar.gz')]+'source.json'
    if source_name in members:
     source=load(inputs[source_name]);expected=source['source_sha256'];assert {x['name']:x['sha256'] for x in rows}==expected
    nested.append({'archive':entry.name,'members':rows})
assert all(sha(p)==members[n]['sha256'] for n,p in inputs.items())
(O/'members.json').write_text(json.dumps(members,indent=2)+'\n');(O/'nested-readback.json').write_text(json.dumps(nested,indent=2)+'\n');(O/'excluded-binaries.json').write_text(json.dumps(excluded,indent=2)+'\n')
report={'status':'sealed_readback_passed','selection':'Proceeding to separate integrated-source full gates and root-owned Python consumer timing; this immutable prototype artifact does not claim those future results.','source':{'base':'1ff7b64e4567484f42bcc974146110648c224dd3','files':70,'manifest_sha256':sha(roots['source']/'source.json'),'patch_sha256':sha(roots['source']/'candidate.patch'),'change':'Private converted_raw_len extraction and inline unchanged UTF8/ASCII native wrapper only. No tests, allocations, limits, counters or API changes; inherited Windows i64 test fix is intentionally absent. Integration atop079 is separate.'},'libraries':build['libraries'],'checks':{'existing_focused_core_tests':85,'targets':4,'strict_core_clippy':'passed','fmt':'passed','fresh_workspace_compiles':3,'matched_compiler_vectors':True},'instructions':{'profiles':32,'preflights':32,'commands':96,'samples':128,'real_conditions':12,'real_geomean':ir['project_instruction_ratio_geomean'],'all12lower':True,'generated_conditions':4,'all4lower':True},'codegen':{'native_wrapper_inlined':True,'text_delta_bytes':2944,'scope':'Actual branch-around-call in consume and position_at. Native logic moves into callers; disappearing old self-Ir is not a standalone prediction of total saving.'},'native':{'groups':native['groups'],'counts':native['counts'],'cohorts':196,'regressions':native['regressions']},'independent_reviews':{'source_build_focused':sha(roots['source-build-review']/'review.json'),'profile':sha(roots['profile-review']/'review.json'),'native':sha(roots['native-review']/'review.json')},'limits':['Native sample measures parser construction, handler setup, parse/callback/free; no full application claim. Both Oriole libraries match C-only ThinLTO; Expat retains original compiler flags. Shared-host single campaign, all conditions/raw workers retained.','Callgrind collection is XML_Parse-only, both one warmup/one measured parse collected. Origin checks run in collector process; no per-driver dladdr assertion.','No original4740 matrix, full C sanitizer gates, strict3318, full workspace, strict CPython802 or actual Python elapsed results for prototype are claimed here. Those are later separate integration/root-owned records.','The optional Python directory contains six scripts/preparation files only. Root separate attempt collided with it before work and moved to another output; no consumer execution occurred here.','Source author generated code/profile/native studies and author reconstruction. Independent source/build/profile/native audits are separately identified.'],'archive':{'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(members),'nested_archives':len(nested),'nested_members':sum(len(x['members']) for x in nested),'readback':'Every outer and nested member read from compressed bytes and hashed; source maps matched; no executable libraries included.'}}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');shutil.copyfile(__file__,O/'package.py')
manifest_out={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in O.iterdir() if p.is_file()};(O/'manifest.json').write_text(json.dumps(manifest_out,indent=2)+'\n');print(json.dumps({'archive':report['archive'],'manifest_sha256':sha(O/'manifest.json'),'report_sha256':sha(O/'report.json')}))
