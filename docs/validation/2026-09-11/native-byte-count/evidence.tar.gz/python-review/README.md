# Raw-byte-count Python benchmark: independent saved-data review

All 72 preflights, 504 timed workers, 168 seeded cohorts and 25,788 measured samples matched the retained raw outputs, origins and summaries. Candidate/control geometric-mean time is 0.9846466186; 23 of 24 conditions are lower. The DocBook 64KiB pyexpat regression remains. This review ran no parser, compiler, test or benchmark.

The sole executed campaign is the `python-root-study`. Six extensions were freshly compiled with matched flags. The scripts-only directory and root's earlier mkdir collision remain separately recorded; the corrected caption preceded every actual build/preflight. Full strict CPython validation is a separate receipt.

`review.json` states the scope and limitations. `generator.py` and `adaptation.patch` retain the complete reconstruction. Every inspected input was read back at sealing; `files.json` indexes the review files without self-reference.
