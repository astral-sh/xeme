# Bind the successful fresh-build campaign to its exact source and preparation.
import ast
import difflib
prior=Path('/tmp/oriole-end-frame-cells-python-independent-review/review.json')
prior_review=load(prior)
assert sha(prior)=='a98011efa544ca434f2435240caa09793a55a79bed25377fa03778251e284235'
old_base=Path('/tmp/oriole-thinlto-production-python-study')
for name in ['python_worker.py','build_consumers.py']:
    assert read(B/name)==read(old_base/name)
assert sha(B/'python_worker.py')==prior_review['controller_lineage']['worker_sha256']
assert sha(B/'build_consumers.py')==prior_review['controller_lineage']['build_helper_sha256']
old_code=read(old_base/'consumer_screen.py').decode()
new_code=read(B/'consumer_screen.py').decode()
replacements={
 'Three normal parser libraries: matched normal/9815cc85, same-source effective ThinLTO/a55ca0f0 candidate, and pinned Expat2.8.4.':'Two Oriole C-only ThinLTO libraries: selected detached End plus Cell/02fcab59, inlined native byte counts/ccfb2295 candidate, and pinned normal Expat2.8.4.',
 'args.phase == "prepare" and os.sched_getaffinity(0) != {3}':'args.phase == "prepare" and os.sched_getaffinity(0) != {5}',
 'Preflights require CPU3':'Preflights require CPU5',
 'Candidate and published retain two known unchanged CPython callback-grouping test failures; canonical fixture outputs must match Expat.':'The selected control has two known CPython callback-grouping failures. No fresh strict CPython suite has run on this native-byte-count candidate; canonical fixture outputs must match Expat.',
}
reverse=new_code
for a,b in replacements.items():
    assert reverse.count(b)==1
    reverse=reverse.replace(b,a)
assert reverse==old_code and ast.dump(ast.parse(reverse))==ast.dump(ast.parse(old_code))
assert ''.join(difflib.unified_diff(old_code.splitlines(True),new_code.splitlines(True),fromfile='reviewed-consumer-screen',tofile='raw-len-split-thinlto-screen'))==read(B/'controller.patch').decode()
assert 'No fresh strict CPython suite has run on this native-byte-count candidate' in pre['limitations']==r['limitations']
assert pre['method']==r['method']
assert load(B/'build.log')=={'status':'passed','output':str(B/'consumers')}
preparation=load(B/'preparation.json')
assert preparation['status']=='passed' and len(preparation['jobs'])==2
PYTHON='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
screen_args=['--kind','python','--phase','prepare','--build',str(B/'consumers/build.json'),'--input',str(manifest),'--output',str(S)]
assert preparation['jobs'][1]=={'name':'preflight','command':['taskset','-c','5',PYTHON,'-I','-S',str(B/'consumer_screen.py'),*screen_args],'exit':0}
build_command=['taskset','-c','5',PYTHON,'-I','-S',str(B/'build_consumers.py'),'--library','/tmp/oriole-raw-len-split-thinlto-study/liboriole_expat.so','--reference','/tmp/oriole-end-frame-cells-thinlto-study/liboriole_expat.so','--expat','/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','--source','/home/dev-user/.cache/oriole/upstream/cpython-3.12.13','--header','/home/dev-user/code/oss/oriole-raw-len-split/include','--output',str(B/'consumers')]
assert preparation['jobs'][0]=={'name':'build','command':build_command,'exit':0}
prepare_path=B/'oriole-prepare-raw-len-split-thinlto-python-root.py'
prepare_code=read(prepare_path).decode()
assert read(prepare_path)==read('/tmp/oriole-prepare-raw-len-split-thinlto-python-root.py')
assert 'timeout=600' in prepare_code
assert prepare_code.index("after = after.replace(old_caption")<prepare_code.index("(out / 'consumer_screen.py').write_text(after)")<prepare_code.index('subprocess.run(command')
timed=load(B/'timing-controller.json')
assert timed['status']=='passed' and timed['exit']==0
assert timed['command']==['taskset','-c','0',PYTHON,'-I','-S',str(B/'consumer_screen.py'),*[('time' if x=='prepare' else x) for x in screen_args]]
assert not timed.get('timeout') and 0<timed['elapsed_seconds']<1200
timing_path=Path('/tmp/oriole-time-raw-len-split-thinlto-python-root.py')
timing_code=read(timing_path).decode()
assert 'start_new_session=True' in timing_code and 'process.wait(timeout=1200)' in timing_code and 'os.killpg(process.pid, signal.SIGKILL)' in timing_code
assert timing_code==read('/tmp/oriole-time-end-frame-cells-thinlto-python.py').decode().replace('/tmp/oriole-end-frame-cells-thinlto-python-study',str(B))

# Original scripts-only preparation and the rejected output-directory collision
# are distinct from this sole successful build/preflight/timing campaign.
unused=Path('/tmp/oriole-raw-len-split-thinlto-python-study')
expected_unused={'controller.patch','consumer_screen.py','python_worker.py','script-preparation.json','build_consumers.py','prepare-scripts.py'}
assert {p.name for p in unused.iterdir()}==expected_unused
for p in unused.iterdir():read(p)
unused_receipt=load(unused/'script-preparation.json')
assert unused_receipt['status']=='scripts_prepared_not_executed' and unused_receipt['controller_sha256']==sha(unused/'consumer_screen.py')
assert read(unused/'python_worker.py')==read(B/'python_worker.py') and read(unused/'build_consumers.py')==read(B/'build_consumers.py')
collision=Path('/tmp/oriole-raw-len-python-directory-collision')
failure=load(collision/'failure.json')
failed_source=collision/'oriole-prepare-raw-len-split-thinlto-python.py'
assert failure['exit']==1 and failure['status']=='failed_before_any_consumer_build_or_parser_run' and failure['preparer_sha256']==sha(failed_source)
failed_code=read(failed_source).decode()
assert failed_code.replace(str(unused),str(B))==prepare_code
assert failed_code.index('out.mkdir(exist_ok=False)')<failed_code.index('shutil.copy2(')<failed_code.index('subprocess.run(')

rust_study=Path('/tmp/oriole-raw-len-split-thinlto-study')
rust_report=load(rust_study/'report.json')
assert rust_report['status']=='passed' and rust_report['libraries']['liboriole_expat.so']==libraries['candidate']
assert rust_report['source_manifest_sha256']==sha(rust_study/'source.json')=='bb6d1c3d27e54c30e36b6d6d7c8b7f41be6782dd9cc2e98cbaca8612cf8a0891'
assert sha(rust_study/'liboriole_expat.so')==libraries['candidate']
source_build_review=Path('/tmp/oriole-native-byte-count-source-build-independent-review/review.json')
source_review=load(source_build_review)
assert sha(source_build_review)=='f1f801a46736344b8fae130ed3ca815c9d71c542c0dda15b098cd5e784c0d886'
assert source_review['libraries']['liboriole_expat.so']==libraries['candidate']
assert sha('/tmp/oriole-end-frame-cells-final-thinlto-study/liboriole_expat.so')==libraries['published']
assert sha('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4')==libraries['expat']

worker_code=read(B/'python_worker.py').decode()
assert 'ctypes.cast(extension.XML_Parse, ctypes.c_void_p)' in worker_code and 'library.parent != directory.resolve()' in worker_code and 'module.__file__ is None' in worker_code
assert 'gc.collect()' in worker_code and 'gc.disable(' not in worker_code
worker_body=worker_code[worker_code.index('def worker('):worker_code.index('\ndef main(')]
needles=['data = Path(spec["input"]).read_bytes()', 'chunks = [', 'import xml.etree.ElementTree as ET', 'for i in range(spec["iterations"] + 1):', 'gc.collect()', 'before = time.perf_counter_ns()', 'value = parse(spec["mode"], chunks)', 'parsed = time.perf_counter_ns() - before', 'output = canonical(spec["mode"], value)', 'before = time.perf_counter_ns()', 'del value', 'destroyed = time.perf_counter_ns() - before']
pos=0
for needle in needles:pos=worker_body.index(needle,pos)+len(needle)
assert 'parser = ET.XMLParser()' in worker_code and 'parser.feed(chunk)' in worker_code and 'return parser.close()' in worker_code
assert 'parser = pyexpat.ParserCreate(namespace_separator="|")' in worker_code and 'parser.Parse(chunk, i == len(chunks) - 1)' in worker_code
assert 'rows.append(["text", "".join(parts)])' in worker_code
for path in B.iterdir():
    if path.is_file():read(path)
read(Path(__file__))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in tracked.items())
def put(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
put('audited-raw-files.json',raw_hashes)
put('all-conditions.json',summaries)
put('groups.json',groups)
put('normalized-consumer-build-commands.json',normalized_commands)
put('checked-files.json',tracked)
result={
 'status':'independent_saved_raw_len_python_audit_passed','blocking_findings':[],
 'scope':'Saved raw arithmetic, loaded origins, fresh extension build receipts and controller lineage only. No parser, compiler, test, profiler or timing execution by reviewer.',
 'counts':{'preflights':72,'timed_workers':504,'cohorts':168,'conditions':24,'timed_measured_samples':25788,'timed_warmups':504,'preflight_warmups':72,'raw_files':1728,'paired_ratios':504,'condition_medians':72,'fresh_extension_build_commands':6},
 'libraries':libraries,'groups':groups,'regressions':regressions,'per_project_geomeans':project_groups,
 'source_manifest_sha256':sha(rust_study/'source.json'),'selected_source_build_review':{'path':str(source_build_review),'sha256':sha(source_build_review)},
 'origins':{'workers':576,'module_origins_per_worker':2,'XML_Parse_same_process_dladdr':True},
 'consumer_build':{'module_flags':'cc -shared -fPIC -O2; same narrow header; no extension LTO/PGO','commands_equal_after_library_directory_normalization':True,'source_revision':build['cpython_revision'],'manifest_sha256':sha(B/'consumers/build.json'),'python':build['python'],'compiler':build['compiler']},
 'controller':{'script_sha256':sha(B/'consumer_screen.py'),'worker_sha256':sha(B/'python_worker.py'),'builder_sha256':sha(B/'build_consumers.py'),'four_allowed_replacements':replacements,'complete_ast_after_reversal_exact':True,'preparation':preparation,'timing':timed,'prepare_source_sha256':sha(prepare_path),'timing_source_sha256':sha(timing_path)},
 'history':{'scripts_only_directory':str(unused),'files':sorted(expected_unused),'receipt':unused_receipt,'collision_receipt':failure,'failed_source_sha256':sha(failed_source),'corrected_prepare_diff':'Output directory path only; caption was corrected before the first successful extension build/preflight.'},
 'limits':[
  'Caption explicitly records no fresh candidate strict CPython suite at preparation time. Later full strict compatibility evidence is separate; canonical benchmark outputs alone do not establish it.',
  'Original scripts-only directory and initial root collision remain separate. The collision scope is supported by the retained author receipt and source ordering (mkdir before copies/commands); no separate raw traceback is retained here.',
  'Automatic GC remains enabled during timing. Explicit gc.collect, imports, fixture reads, chunk preparation and canonical hashing are untimed. Samples sum parse/construction/feeds/finalization/local cleanup and explicit deletion of the returned tree/event list.',
  'The pyexpat canonical output joins adjacent text callbacks, so it does not prove exact callback fragmentation. Each worker verifies both extension file origins and XML_Parse through pyexpat, not every C function invoked by ElementTree.',
  'All24 conditions and the sole DocBook64KiB pyexpat regression remain. No external DTD, full-project application, Wayland generator, PBS distribution or PGO claim.',
  'One shared-host campaign with seven seeded paired cohorts. Affinity/randomization do not prove exclusive host resources, statistical significance or exact causal speedup.',
  'Inherited worker timeout300s, preparation600s per phase, aggregate timing1200s with process-group kill/wait. Successful saved commands do not validate arbitrary launch/interruption failure handling.'
 ],
 'checked_files':len(tracked),'all_inspected_bytes_unchanged':True,'generator_sha256':sha(Path(__file__)),
}
put('review.json',result)
print(json.dumps({'status':result['status'],'review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'files':len(tracked),'groups':groups,'regressions':len(regressions)}))
