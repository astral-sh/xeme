"""Reconstruct fresh three-engine CPython samples without executing workers."""
from pathlib import Path
import os
assert os.sched_getaffinity(0)=={5}
from collections import Counter
import gzip
import hashlib
import json
import math
import random
import statistics

if not __debug__:
    raise RuntimeError('Audit assertions must run')
B = Path('/tmp/oriole-raw-len-split-thinlto-python-root-study')
S = B / 'screen'
OUT = Path(__file__).resolve().parent
tracked={}
def read(p):
    p=Path(p);raw=p.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(p),value)==value,('changed during audit',str(p))
    return raw
def sha(p):
    p=str(Path(p))
    if p not in tracked:read(p)
    return tracked[p]
def load(p):return json.loads(read(p))
pre = load(S / 'preflight.json')
r = load(S / 'results.json')
build = load(B / 'consumers/build.json')
summary = load(B / 'summary.json')
assert pre['status'] == 'preflight_passed' and r['status'] == 'passed'
assert pre['affinity'] == [5] and r['affinity'] == [0]
assert pre['kind'] == r['kind'] == 'python'
assert r['preflight_sha256'] == sha(S / 'preflight.json')
assert pre['conditions'] == r['conditions']
assert r['preflights'] == pre['preflights'] and r['expected'] == pre['expected']
assert len(pre['processes']) == len(pre['preflights']) == 72
assert len(r['processes']) == len(r['rows']) == 504
assert pre['pairs'] == r['pairs'] == 7
assert pre['seed'] == r['seed'] == 202609104412
assert pre['hashes_before'] == pre['hashes_after'] == r['hashes_before'] == r['hashes_after']
for record in [pre, r]:
    assert not record['hash_errors']
    assert all(sha(p) == h for p, h in record['hashes_before'].items())
assert sha(B / 'python_worker.py') == '4bc0ccffedb5048412b9cfc3638d28dcb30f711891c3784f3fbd3c0eb536ab68'
assert build['status'] == 'passed' and build['adaptations'] is None
assert build['cpython_revision'] == '3bb231a6a5dc02b95658877318bf61501a7209e9'
assert build['source_sha256_before'] == build['source_sha256_after']
assert all(sha(p) == h for p, h in build['source_sha256_before'].items())
engines = ['published', 'candidate', 'expat']
libraries = {'published': '02fcab59f6e3818c128da6706d67987ae7450dd8b59e97cd28ce497a547f28f5',
             'candidate': 'ccfb22956a11c1b241ec755f46245c61f088187ef93143b77a7afec748983821',
             'expat': '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'}
assert set(build['consumers']) == set(engines)
normalized_commands = {}
for engine, consumer in build['consumers'].items():
    assert sha(consumer['library']) == libraries[engine]
    assert all(sha(p) == h for p, h in consumer['files'].items())
    assert len(consumer['commands']) == 2
    normalized = []
    for module, command in zip(['pyexpat', '_elementtree'], consumer['commands'], strict=True):
        args = command['command']
        assert command['returncode'] == 0 and args[:4] == ['cc', '-shared', '-fPIC', '-O2']
        assert sha(Path(consumer['directory']) / (module + '-build.log')) == command['log_sha256']
        assert args[-4] == consumer['library'] and args[-3]=='-Wl,-rpath,'+consumer['directory'] and args[-2]=='-o' and Path(args[-1]).name.startswith(module+'.cpython-312-')
        assert args[-5].endswith('/Modules/'+('pyexpat.c' if module=='pyexpat' else '_elementtree.c')) and sha(args[-5])==build['source_sha256_before'][args[-5]]
        normalized.append([x.replace(consumer['library'], '<PARSER-LIBRARY>').replace(consumer['directory'], '<CONSUMER-DIR>') for x in args])
    normalized_commands[engine] = normalized
assert all(v == normalized_commands['published'] for v in normalized_commands.values())

manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
iterations = {'vulkan': 3, 'wayland': 16, 'maven': 32, 'batik': 128, 'gtk': 64, 'docbook': 64}
conditions = []
for project in load(manifest)['projects']:
    entry = next(x for x in project['files'] if x['role'] == 'input')
    path = (manifest.parent / entry['path']).resolve()
    assert sha(path) == entry['sha256']
    for chunk in [4096, 65536]:
        for mode in ['elementtree', 'pyexpat-events']:
            conditions.append({'name': project['name'], 'chunk': chunk, 'mode': mode, 'input': str(path), 'iterations': iterations[project['name']]})
assert conditions == r['conditions'] and len(conditions) == 24
assert set(pre['expected'])=={f"{c['name']}/{c['chunk']}/{c['mode']}" for c in conditions}
key = lambda c: f"{c['name']}/{c['chunk']}/{c['mode']}"
condition_map = {key(c): c for c in conditions}
index = {}
counts = Counter()
raw_hashes = {}
for phase, record, rowname in [('preflight', pre, 'preflights'), ('time', r, 'rows')]:
    processes = {p['label']: p for p in record['processes']}
    assert len(processes) == len(record['processes'])
    assert set(processes) == {row['process'] for row in record[rowname]}
    assert [p['label'] for p in record['processes']]==[row['process'] for row in record[rowname]]
    for row in record[rowname]:
        process = processes[row['process']]
        assert process['status'] == 'passed' and process['returncode'] == 0 and process['timeout_seconds'] == 300
        assert 'failure' not in process
        for stream in ['stdout', 'stderr']:
            path = S / process[stream]
            assert sha(path) == process[stream + '_sha256']
            raw_hashes[str(path)] = sha(path)
        assert not gzip.decompress(read(S / process['stderr']))
        raw = json.loads(gzip.decompress(read(S / process['stdout'])))
        assert raw['gc_enabled'] is True and raw['python']==build['python']==record['python_version']
        assert set(raw)=={'identity','python','gc_enabled','samples'}
        assert set(raw['identity'])=={'pyexpat','_elementtree','parser_library','expat_version'}
        assert raw['samples'] == row['samples'] and raw['identity'] == row['identity']
        engine = row['engine']
        consumer = build['consumers'][engine]
        assert raw['identity']['parser_library']['sha256'] == libraries[engine]
        assert raw['identity']['expat_version'] == ('expat_2.8.4' if engine == 'expat' else 'oriole_compat_2.8.4')
        for name in ['pyexpat', '_elementtree', 'parser_library']:
            entry = raw['identity'][name]
            assert consumer['files'][entry['path']] == entry['sha256'] == sha(entry['path'])
        command = process['command']
        assert command[0]=='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3' and len(command)==6
        assert 0<=process['wall_seconds']<300 and (S/process['stdout']).name==process['label']+'-stdout.gz' and (S/process['stderr']).name==process['label']+'-stderr.gz'
        assert command[1:5] == ['-I', '-S', str(B / 'python_worker.py'), '--worker']
        specpath = Path(command[-1])
        assert specpath.parent==S and specpath.name==process['label']+'.json'
        spec = load(specpath)
        raw_hashes[str(specpath)] = sha(specpath)
        c = condition_map[row['key']]
        count = 0 if phase == 'preflight' else c['iterations']
        assert spec == {'input': c['input'], 'input_sha256': sha(c['input']), 'chunk': c['chunk'], 'mode': c['mode'], 'consumer': consumer['directory'], 'library_sha256': libraries[engine], 'iterations': count}
        assert len(raw['samples']) == count + 1
        for i, sample in enumerate(raw['samples']):
            assert set(sample)=={'iteration','warmup','parse_ns','destruction_ns','seconds','output_sha256','output_rows'}
            assert type(sample['parse_ns']) is int and type(sample['destruction_ns']) is int and type(sample['output_rows']) is int
            assert sample['iteration'] == i and sample['warmup'] == (i == 0)
            assert sample['seconds'] == (sample['parse_ns'] + sample['destruction_ns']) / 1e9
            assert sample['seconds'] > 0 and math.isfinite(sample['seconds'])
            assert sample['parse_ns'] >= 0 and sample['destruction_ns'] >= 0
            assert [sample['output_sha256'], sample['output_rows']] == pre['expected'][row['key']]
            counts[phase + ('_warmups' if i == 0 else '_measured')] += 1
        median = statistics.median(s['seconds'] for s in raw['samples'][1:]) if count else None
        assert row['median_seconds'] == median
        if phase == 'time':
            identity = (row['key'], row['pair'], engine)
            assert identity not in index
            index[identity] = median
expected_preflights = [(key(c), engine) for c in conditions for engine in engines]
assert [(row['key'], row['engine']) for row in pre['preflights']] == expected_preflights
rng = random.Random(r['seed'])
jobs = [(condition, pair) for condition in conditions for pair in range(7)]
rng.shuffle(jobs)
order = []
for c, pair in jobs:
    shuffled = engines.copy()
    rng.shuffle(shuffled)
    order.extend((key(c), pair, engine, position) for position, engine in enumerate(shuffled))
assert order == [(row['key'], row['pair'], row['engine'], row['order']) for row in r['rows']]
ratio_pairs = [('candidate', 'published'), ('candidate', 'expat'), ('published', 'expat')]
summaries = []
for c in conditions:
    medians = {engine: [index[key(c), pair, engine] for pair in range(7)] for engine in engines}
    ratios = {a + '_over_' + b: [medians[a][pair] / medians[b][pair] for pair in range(7)] for a, b in ratio_pairs}
    summaries.append({'condition': c, 'process_pair_medians_seconds': medians, 'paired_ratios': ratios,
                      'median_ratios': {name: statistics.median(v) for name, v in ratios.items()}})
assert summaries == r['summary']
assert counts == {'preflight_warmups': 72, 'time_warmups': 504, 'time_measured': 25788}
groups = {}
for group in ['all', 'elementtree', 'pyexpat-events']:
    selected = [s for s in summaries if group == 'all' or s['condition']['mode'] == group]
    groups[group] = {}
    for a, b in ratio_pairs:
        name = a + '_over_' + b
        values = [s['median_ratios'][name] for s in selected]
        geo = math.exp(sum(math.log(v) for v in values)/len(values))
        actual = {'geomean': geo, 'below_one': sum(v < 1 for v in values), 'conditions': len(values)}
        assert actual['below_one'] == summary['groups'][group]['ratios'][name]['below_one'] and actual['conditions'] == summary['groups'][group]['conditions']
        assert actual['geomean']==summary['groups'][group]['ratios'][name]['geomean']
        groups[group][name] = actual
project_groups = {}
for project in iterations:
    selected = [s for s in summaries if s['condition']['name'] == project]
    project_groups[project] = {a + '_over_' + b: math.exp(statistics.mean(math.log(s['median_ratios'][a + '_over_' + b]) for s in selected)) for a, b in ratio_pairs}
# Additional label and raw inventory checks independently bind every execution.
for phase, record, rows in [('prepare', pre, pre['preflights']), ('time', r, r['rows'])]:
    for row in rows:
        pair = -1 if phase == 'prepare' else row['pair']
        assert row['pair'] == pair
        assert row['process'] == row['key'].replace('/', '-') + '-' + row['engine'] + '-' + str(pair) + '-0'
assert set(raw_hashes)=={str(p) for p in S.iterdir() if p.is_file() and p.name not in ['preflight.json','results.json']}
assert len(raw_hashes)==1728 and sum(counts.values())==26364
assert load(B/'preflight.log')=={'status':'preflight_passed','kind':'python','preflights':72,'timed_rows':0}
assert load(B/'timing-controller.log')=={'status':'passed','kind':'python','preflights':72,'timed_rows':504}
regressions=[{'condition':x['condition'],'ratio':x['median_ratios']['candidate_over_published']}for x in summaries if x['median_ratios']['candidate_over_published']>1]
assert regressions==summary['regressions'] and len(regressions)==1
assert groups['all']['candidate_over_published']=={'geomean':0.984646618568893,'below_one':23,'conditions':24}
assert groups['elementtree']['candidate_over_published']['geomean']==0.9794459862427116
assert groups['pyexpat-events']['candidate_over_published']['geomean']==0.9898748650534579

# Bind the successful fresh-build campaign to its exact source and preparation.
import ast
import difflib
prior=Path('/tmp/oriole-end-frame-cells-python-independent-review/review.json')
prior_review=load(prior)
assert sha(prior)=='a98011efa544ca434f2435240caa09793a55a79bed25377fa03778251e284235'
old_base=Path('/tmp/oriole-thinlto-production-python-study')
for name in ['python_worker.py','build_consumers.py']:
    assert read(B/name)==read(old_base/name)
assert sha(B/'python_worker.py')==prior_review['controller_lineage']['worker_sha256']
assert sha(B/'build_consumers.py')==prior_review['controller_lineage']['build_helper_sha256']
old_code=read(old_base/'consumer_screen.py').decode()
new_code=read(B/'consumer_screen.py').decode()
replacements={
 'Three normal parser libraries: matched normal/9815cc85, same-source effective ThinLTO/a55ca0f0 candidate, and pinned Expat2.8.4.':'Two Oriole C-only ThinLTO libraries: selected detached End plus Cell/02fcab59, inlined native byte counts/ccfb2295 candidate, and pinned normal Expat2.8.4.',
 'args.phase == "prepare" and os.sched_getaffinity(0) != {3}':'args.phase == "prepare" and os.sched_getaffinity(0) != {5}',
 'Preflights require CPU3':'Preflights require CPU5',
 'Candidate and published retain two known unchanged CPython callback-grouping test failures; canonical fixture outputs must match Expat.':'The selected control has two known CPython callback-grouping failures. No fresh strict CPython suite has run on this native-byte-count candidate; canonical fixture outputs must match Expat.',
}
reverse=new_code
for a,b in replacements.items():
    assert reverse.count(b)==1
    reverse=reverse.replace(b,a)
assert reverse==old_code and ast.dump(ast.parse(reverse))==ast.dump(ast.parse(old_code))
assert ''.join(difflib.unified_diff(old_code.splitlines(True),new_code.splitlines(True),fromfile='reviewed-consumer-screen',tofile='raw-len-split-thinlto-screen'))==read(B/'controller.patch').decode()
assert 'No fresh strict CPython suite has run on this native-byte-count candidate' in pre['limitations']==r['limitations']
assert pre['method']==r['method']
assert load(B/'build.log')=={'status':'passed','output':str(B/'consumers')}
preparation=load(B/'preparation.json')
assert preparation['status']=='passed' and len(preparation['jobs'])==2
PYTHON='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
screen_args=['--kind','python','--phase','prepare','--build',str(B/'consumers/build.json'),'--input',str(manifest),'--output',str(S)]
assert preparation['jobs'][1]=={'name':'preflight','command':['taskset','-c','5',PYTHON,'-I','-S',str(B/'consumer_screen.py'),*screen_args],'exit':0}
build_command=['taskset','-c','5',PYTHON,'-I','-S',str(B/'build_consumers.py'),'--library','/tmp/oriole-raw-len-split-thinlto-study/liboriole_expat.so','--reference','/tmp/oriole-end-frame-cells-thinlto-study/liboriole_expat.so','--expat','/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4','--source','/home/dev-user/.cache/oriole/upstream/cpython-3.12.13','--header','/home/dev-user/code/oss/oriole-raw-len-split/include','--output',str(B/'consumers')]
assert preparation['jobs'][0]=={'name':'build','command':build_command,'exit':0}
prepare_path=B/'oriole-prepare-raw-len-split-thinlto-python-root.py'
prepare_code=read(prepare_path).decode()
assert read(prepare_path)==read('/tmp/oriole-prepare-raw-len-split-thinlto-python-root.py')
assert 'timeout=600' in prepare_code
assert prepare_code.index("after = after.replace(old_caption")<prepare_code.index("(out / 'consumer_screen.py').write_text(after)")<prepare_code.index('subprocess.run(command')
timed=load(B/'timing-controller.json')
assert timed['status']=='passed' and timed['exit']==0
assert timed['command']==['taskset','-c','0',PYTHON,'-I','-S',str(B/'consumer_screen.py'),*[('time' if x=='prepare' else x) for x in screen_args]]
assert not timed.get('timeout') and 0<timed['elapsed_seconds']<1200
timing_path=Path('/tmp/oriole-time-raw-len-split-thinlto-python-root.py')
timing_code=read(timing_path).decode()
assert 'start_new_session=True' in timing_code and 'process.wait(timeout=1200)' in timing_code and 'os.killpg(process.pid, signal.SIGKILL)' in timing_code
assert timing_code==read('/tmp/oriole-time-end-frame-cells-thinlto-python.py').decode().replace('/tmp/oriole-end-frame-cells-thinlto-python-study',str(B))

# Original scripts-only preparation and the rejected output-directory collision
# are distinct from this sole successful build/preflight/timing campaign.
unused=Path('/tmp/oriole-raw-len-split-thinlto-python-study')
expected_unused={'controller.patch','consumer_screen.py','python_worker.py','script-preparation.json','build_consumers.py','prepare-scripts.py'}
assert {p.name for p in unused.iterdir()}==expected_unused
for p in unused.iterdir():read(p)
unused_receipt=load(unused/'script-preparation.json')
assert unused_receipt['status']=='scripts_prepared_not_executed' and unused_receipt['controller_sha256']==sha(unused/'consumer_screen.py')
assert read(unused/'python_worker.py')==read(B/'python_worker.py') and read(unused/'build_consumers.py')==read(B/'build_consumers.py')
collision=Path('/tmp/oriole-raw-len-python-directory-collision')
failure=load(collision/'failure.json')
failed_source=collision/'oriole-prepare-raw-len-split-thinlto-python.py'
assert failure['exit']==1 and failure['status']=='failed_before_any_consumer_build_or_parser_run' and failure['preparer_sha256']==sha(failed_source)
failed_code=read(failed_source).decode()
assert failed_code.replace(str(unused),str(B))==prepare_code
assert failed_code.index('out.mkdir(exist_ok=False)')<failed_code.index('shutil.copy2(')<failed_code.index('subprocess.run(')

rust_study=Path('/tmp/oriole-raw-len-split-thinlto-study')
rust_report=load(rust_study/'report.json')
assert rust_report['status']=='passed' and rust_report['libraries']['liboriole_expat.so']==libraries['candidate']
assert rust_report['source_manifest_sha256']==sha(rust_study/'source.json')=='bb6d1c3d27e54c30e36b6d6d7c8b7f41be6782dd9cc2e98cbaca8612cf8a0891'
assert sha(rust_study/'liboriole_expat.so')==libraries['candidate']
source_build_review=Path('/tmp/oriole-native-byte-count-source-build-independent-review/review.json')
source_review=load(source_build_review)
assert sha(source_build_review)=='f1f801a46736344b8fae130ed3ca815c9d71c542c0dda15b098cd5e784c0d886'
assert source_review['libraries']['liboriole_expat.so']==libraries['candidate']
assert sha('/tmp/oriole-end-frame-cells-final-thinlto-study/liboriole_expat.so')==libraries['published']
assert sha('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4')==libraries['expat']

worker_code=read(B/'python_worker.py').decode()
assert 'ctypes.cast(extension.XML_Parse, ctypes.c_void_p)' in worker_code and 'library.parent != directory.resolve()' in worker_code and 'module.__file__ is None' in worker_code
assert 'gc.collect()' in worker_code and 'gc.disable(' not in worker_code
worker_body=worker_code[worker_code.index('def worker('):worker_code.index('\ndef main(')]
needles=['data = Path(spec["input"]).read_bytes()', 'chunks = [', 'import xml.etree.ElementTree as ET', 'for i in range(spec["iterations"] + 1):', 'gc.collect()', 'before = time.perf_counter_ns()', 'value = parse(spec["mode"], chunks)', 'parsed = time.perf_counter_ns() - before', 'output = canonical(spec["mode"], value)', 'before = time.perf_counter_ns()', 'del value', 'destroyed = time.perf_counter_ns() - before']
pos=0
for needle in needles:pos=worker_body.index(needle,pos)+len(needle)
assert 'parser = ET.XMLParser()' in worker_code and 'parser.feed(chunk)' in worker_code and 'return parser.close()' in worker_code
assert 'parser = pyexpat.ParserCreate(namespace_separator="|")' in worker_code and 'parser.Parse(chunk, i == len(chunks) - 1)' in worker_code
assert 'rows.append(["text", "".join(parts)])' in worker_code
for path in B.iterdir():
    if path.is_file():read(path)
read(Path(__file__))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in tracked.items())
def put(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
put('audited-raw-files.json',raw_hashes)
put('all-conditions.json',summaries)
put('groups.json',groups)
put('normalized-consumer-build-commands.json',normalized_commands)
put('checked-files.json',tracked)
result={
 'status':'independent_saved_raw_len_python_audit_passed','blocking_findings':[],
 'scope':'Saved raw arithmetic, loaded origins, fresh extension build receipts and controller lineage only. No parser, compiler, test, profiler or timing execution by reviewer.',
 'counts':{'preflights':72,'timed_workers':504,'cohorts':168,'conditions':24,'timed_measured_samples':25788,'timed_warmups':504,'preflight_warmups':72,'raw_files':1728,'paired_ratios':504,'condition_medians':72,'fresh_extension_build_commands':6},
 'libraries':libraries,'groups':groups,'regressions':regressions,'per_project_geomeans':project_groups,
 'source_manifest_sha256':sha(rust_study/'source.json'),'selected_source_build_review':{'path':str(source_build_review),'sha256':sha(source_build_review)},
 'origins':{'workers':576,'module_origins_per_worker':2,'XML_Parse_same_process_dladdr':True},
 'consumer_build':{'module_flags':'cc -shared -fPIC -O2; same narrow header; no extension LTO/PGO','commands_equal_after_library_directory_normalization':True,'source_revision':build['cpython_revision'],'manifest_sha256':sha(B/'consumers/build.json'),'python':build['python'],'compiler':build['compiler']},
 'controller':{'script_sha256':sha(B/'consumer_screen.py'),'worker_sha256':sha(B/'python_worker.py'),'builder_sha256':sha(B/'build_consumers.py'),'four_allowed_replacements':replacements,'complete_ast_after_reversal_exact':True,'preparation':preparation,'timing':timed,'prepare_source_sha256':sha(prepare_path),'timing_source_sha256':sha(timing_path)},
 'history':{'scripts_only_directory':str(unused),'files':sorted(expected_unused),'receipt':unused_receipt,'collision_receipt':failure,'failed_source_sha256':sha(failed_source),'corrected_prepare_diff':'Output directory path only; caption was corrected before the first successful extension build/preflight.'},
 'limits':[
  'Caption explicitly records no fresh candidate strict CPython suite at preparation time. Later full strict compatibility evidence is separate; canonical benchmark outputs alone do not establish it.',
  'Original scripts-only directory and initial root collision remain separate. The collision scope is supported by the retained author receipt and source ordering (mkdir before copies/commands); no separate raw traceback is retained here.',
  'Automatic GC remains enabled during timing. Explicit gc.collect, imports, fixture reads, chunk preparation and canonical hashing are untimed. Samples sum parse/construction/feeds/finalization/local cleanup and explicit deletion of the returned tree/event list.',
  'The pyexpat canonical output joins adjacent text callbacks, so it does not prove exact callback fragmentation. Each worker verifies both extension file origins and XML_Parse through pyexpat, not every C function invoked by ElementTree.',
  'All24 conditions and the sole DocBook64KiB pyexpat regression remain. No external DTD, full-project application, Wayland generator, PBS distribution or PGO claim.',
  'One shared-host campaign with seven seeded paired cohorts. Affinity/randomization do not prove exclusive host resources, statistical significance or exact causal speedup.',
  'Inherited worker timeout300s, preparation600s per phase, aggregate timing1200s with process-group kill/wait. Successful saved commands do not validate arbitrary launch/interruption failure handling.'
 ],
 'checked_files':len(tracked),'all_inspected_bytes_unchanged':True,'generator_sha256':sha(Path(__file__)),
}
put('review.json',result)
print(json.dumps({'status':result['status'],'review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'files':len(tracked),'groups':groups,'regressions':len(regressions)}))
