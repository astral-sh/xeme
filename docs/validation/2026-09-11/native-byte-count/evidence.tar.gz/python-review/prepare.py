from pathlib import Path
import hashlib,json,difflib
O=Path('/tmp/oriole-raw-len-split-python-independent-review')
O.mkdir(exist_ok=False)
prior=Path('/tmp/oriole-compact-allocator-python-independent-review/generator.py')
old=prior.read_text()
body=old[:old.index('# The earlier saved audit establishes')]
body=body.replace('os.sched_getaffinity(0)=={4}','os.sched_getaffinity(0)=={5}').replace('/tmp/oriole-compact-allocator-thinlto-python-final-study','/tmp/oriole-raw-len-split-thinlto-python-root-study').replace('c0ffc492fe10a13cfc96f703263fb3e88d67d37a4fd2cff45c82d2d9e2f38e88','ccfb22956a11c1b241ec755f46245c61f088187ef93143b77a7afec748983821')
body=body.replace('len(regressions)==17','len(regressions)==1').replace("{'geomean':1.0090240645314288,'below_one':7,'conditions':24}","{'geomean':0.984646618568893,'below_one':23,'conditions':24}").replace('==1.0093923910523284','==0.9794459862427116').replace('==1.0086558724125985','==0.9898748650534579')
tail=Path('/tmp/oriole-raw-len-python-audit-tail.py')
new=body+tail.read_text()
(O/'generator.py').write_text(new)
(O/'audit-tail.py').write_bytes(tail.read_bytes())
(O/'prepare.py').write_bytes(Path(__file__).read_bytes())
(O/'adaptation.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(prior),tofile='generator.py')))
(O/'preparation.json').write_text(json.dumps({'prior':str(prior),'prior_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'scope':'Same independent raw/medians/order/canonical/origin arithmetic; replace study/library/expected aggregates and rewrite fresh6build +caption/collision lineage. No target execution.'},indent=2)+'\n')
print(O)
