from pathlib import Path
import hashlib,json
O=Path(__file__).parent
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs=json.loads((O/'checked-files.json').read_text())
assert all(h(Path(p))==v for p,v in inputs.items())
assert not (O/'attempt-01.stderr').read_bytes()
assert json.loads((O/'attempt-01.stdout').read_text())['review_sha256']==h(O/'review.json')
(O/'attempt-01.json').write_text(json.dumps({'command':['taskset','-c','5','python3',str(O/'generator.py')],'tool_session':12141,'exit':0,'scope':'First saved-data audit attempt; no target executions.','generator_sha256':h(O/'generator.py'),'stdout_sha256':h(O/'attempt-01.stdout'),'stderr_sha256':h(O/'attempt-01.stderr')},indent=2)+'\n')
(O/'README.md').write_text('''# Raw-byte-count Python benchmark: independent saved-data review

All 72 preflights, 504 timed workers, 168 seeded cohorts and 25,788 measured samples matched the retained raw outputs, origins and summaries. Candidate/control geometric-mean time is 0.9846466186; 23 of 24 conditions are lower. The DocBook 64KiB pyexpat regression remains. This review ran no parser, compiler, test or benchmark.

The sole executed campaign is the `python-root-study`. Six extensions were freshly compiled with matched flags. The scripts-only directory and root's earlier mkdir collision remain separately recorded; the corrected caption preceded every actual build/preflight. Full strict CPython validation is a separate receipt.

`review.json` states the scope and limitations. `generator.py` and `adaptation.patch` retain the complete reconstruction. Every inspected input was read back at sealing; `files.json` indexes the review files without self-reference.
''')
receipt={'status':'sealed_independent_saved_data_review','review_sha256':h(O/'review.json'),'input_files':len(inputs),'all_input_bytes_rehashed_unchanged':True,'target_executions':0,'attempts':1}
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
files={p.name:{'size':p.stat().st_size,'sha256':h(p)} for p in sorted(O.iterdir()) if p.is_file() and p.name!='files.json'}
(O/'files.json').write_text(json.dumps(files,indent=2)+'\n')
assert all(h(O/n)==v['sha256'] for n,v in files.items())
print(json.dumps({'path':str(O),'review_sha256':h(O/'review.json'),'receipt_sha256':h(O/'receipt.json'),'files_sha256':h(O/'files.json'),'files':len(files)}))
