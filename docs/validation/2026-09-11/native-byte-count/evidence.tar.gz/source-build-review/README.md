# Selected native byte-count source and build review

The independent saved-data audit passed on its first attempt: 225 checks, 105 inspected files and 215 read-only Git operations. No target, parser, test, compiler or build was executed.

All 70 inputs in source manifest `735afb94` match the source archive, live worktree and committed integration `be22a271`. The commit applies exact runtime patch `faf56975` atop base `079fb66d`. Compared with measured prototype source `bb6d1c3d`, the only source-map difference is the already published `cfg(test)` cast from `i64` to `c_long`; all other 69 inputs are identical.

The fresh release log has three workspace compiler invocations and two registry dependency invocations. Every saved invocation record was reconstructed from the raw logs. The three workspace compiler commands match the measured prototype after worktree and private build paths. Recorded environment overrides differ only by target directory. Shared library `ccfb2295` and static library `f58d5bc6` are each byte-for-byte identical to the measured prototype outputs.

The initial failed source verifier is retained as a JSON declaration describing a wrong hand-written literal before source freeze or build. Its original raw helper and traceback are absent from the source-study directory; this audit independently verifies the corrected expression and composition without claiming to replay that history.

`generator.py` contains the audit. `attempt-01.*` records its sole successful attempt. `checked-files.json`, `checks.json`, `git-reads.json`, and the compiler tables retain the evidence. `receipt.json` and `files.json` seal the complete review. Full compatibility and workspace gates remain separate.
