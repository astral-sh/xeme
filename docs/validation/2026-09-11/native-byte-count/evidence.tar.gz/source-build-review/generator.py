"""Independent saved source and compiler audit. Only local reads and git show/diff."""
from pathlib import Path
import difflib,hashlib,json,os,re,shlex,subprocess,tarfile
assert os.sched_getaffinity(0)=={4}
O=Path(__file__).resolve().parent
S=Path('/tmp/oriole-native-byte-count-study');B=Path('/tmp/oriole-native-byte-count-thinlto-study')
P=Path('/tmp/oriole-raw-len-split-study');C=Path('/tmp/oriole-raw-len-split-thinlto-study')
W=Path('/home/dev-user/code/oss/oriole-native-byte-count')
tracked={};checks=[];git_reads=[]
def read(p):
 p=Path(p);raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest();assert tracked.setdefault(str(p),digest)==digest;return raw
def sha(p):read(p);return tracked[str(p)]
def js(p):return json.loads(read(p))
def ck(name,value):checks.append({'name':name,'passed':bool(value)});assert value,name
def git(*args):
 command=['git','-C',str(W),*args];raw=subprocess.check_output(command);git_reads.append({'command':command,'stdout_sha256':hashlib.sha256(raw).hexdigest(),'stdout_bytes':len(raw)});return raw
base='079fb66dc159cdc0e1c3ad16397f149751783014';oldbase='1ff7b64e4567484f42bcc974146110648c224dd3';head='be22a271f8a5c004d13e515cd4024a68afe57887'
ck('checkout/common directory',git('rev-parse','--show-toplevel').decode().strip()==str(W) and git('rev-parse','--git-common-dir').decode().strip()=='/home/dev-user/code/oss/oriole/.git')
ck('reviewed commit and parent',git('rev-parse',head+'^').decode().strip()==base)
source=js(S/'source.json');prototype=js(P/'source.json');composition=js(S/'composition.json')
ck('fixed source identities',sha(S/'source.json')=='735afb9491158c3a34fd376109edc2312727382b5fa61e5e8b084796d7294f1d' and sha(P/'source.json')=='bb6d1c3d27e54c30e36b6d6d7c8b7f41be6782dd9cc2e98cbaca8612cf8a0891')
ck('source metadata',source['base']==base and source['worktree']==str(W) and source['changed_files']==['crates/oriole/src/encoding.rs'] and prototype['base']==oldbase)
names=source['source_sha256'];ck('same70 inputs',len(names)==70 and set(names)==set(prototype['source_sha256']))
ck('composition claims',composition['status']=='passed' and composition['source_manifest_sha256']==sha(S/'source.json') and composition['prototype_source_manifest_sha256']==sha(P/'source.json') and composition['prototype_delta']==['crates/oriole_expat/src/tests.rs'] and composition['unchanged_files']==69)
archives={}
for label,root,manifest in [('integrated',S,source),('prototype',P,prototype)]:
 sha(root/'source.tar.gz')
 with tarfile.open(root/'source.tar.gz') as archive:
  members=archive.getmembers();ck(label+' archive has70 unique regular members',len(members)==70 and len({m.name for m in members})==70 and all(m.isfile() for m in members))
  files={m.name:archive.extractfile(m).read() for m in members}
 ck(label+' archive matches source map',{n:hashlib.sha256(v).hexdigest() for n,v in files.items()}==manifest['source_sha256']);archives[label]=files
oldfiles={};basefiles={};headfiles={}
for n,digest in names.items():
 ck('live input '+n,sha(W/n)==digest)
 oldfiles[n]=git('show',oldbase+':'+n);basefiles[n]=git('show',base+':'+n);headfiles[n]=git('show',head+':'+n)
 ck('committed selected source '+n,headfiles[n]==archives['integrated'][n])
ck('only expected source difference from prototype',[n for n in names if archives['integrated'][n]!=archives['prototype'][n]]==['crates/oriole_expat/src/tests.rs'])
ck('only test portability differs between bases',[n for n in names if oldfiles[n]!=basefiles[n]]==['crates/oriole_expat/src/tests.rs'])
ck('only encoding differs from integration base',[n for n in names if archives['integrated'][n]!=basefiles[n]]==['crates/oriole/src/encoding.rs'])
test='crates/oriole_expat/src/tests.rs';old=oldfiles[test];new=archives['integrated'][test]
ck('test-only exact cast correction',old.count(b'opening.to_bytes().len() as i64')==1 and old.replace(b'opening.to_bytes().len() as i64',b'opening.to_bytes().len() as c_long')==new==basefiles[test] and old==archives['prototype'][test])
ck('test module gated and return type matched',b'#[cfg(test)]\nmod tests;' in archives['integrated']['crates/oriole_expat/src/lib.rs'] and b'fn XML_GetCurrentByteIndex(parser: XML_Parser) -> c_long' in archives['integrated']['crates/oriole_expat/src/lib.rs'])
ck('portability patch exact',read(S/'test-portability.patch').decode()==''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True))))
name='crates/oriole/src/encoding.rs';old=basefiles[name].decode();new=archives['integrated'][name].decode()
needle='    fn raw_len(&self, offset: usize, count: usize) -> usize {'
ck('unique raw_len signature',old.count(needle)==1);transformed=old.replace(needle,'    #[inline]\n'+needle)
needle='            return count;\n        }\n        if self.encoding == Encoding::MultiByte {'
replacement='            return count;\n        }\n        self.converted_raw_len(offset, count)\n    }\n\n    /// Count original encoded bytes in a converted source range.\n    fn converted_raw_len(&self, offset: usize, count: usize) -> usize {\n        if self.encoding == Encoding::MultiByte {'
ck('exact whole encoding reconstruction',transformed.count(needle)==1 and transformed.replace(needle,replacement)==new)
patch=read(S/'candidate.patch')
ck('patch byte identity and committed diff',patch==read(P/'candidate.patch')==git('diff','--binary',base,head,'--','crates/oriole/src/encoding.rs') and sha(S/'candidate.patch')==composition['patch_sha256']=='faf56975ae27c070276be8bcc65d6f6178a78f6dcba360902769ec7e26128b68')
ck('entire committed delta is encoding only',git('diff','--name-only',base,head).decode().splitlines()==['crates/oriole/src/encoding.rs'])
initial=js(S/'initial-generator-attempt.json')
ck('initial producer verifier failure retained',initial['status']=='failed_before_source_freeze_or_build' and initial['error']=='AssertionError in hand-written expected literal replacement' and '<root>text</root>' in initial['scope'])
freeze=read(S/'freeze.py').decode();sha(S/'worktree.log')
ck('corrected verifier uses actual expression before archive/build setup',"a.replace(b'opening.to_bytes().len() as i64',b'opening.to_bytes().len() as c_long')==b" in freeze and freeze.index("a.count(b'opening.to_bytes().len() as i64')")<freeze.index("(P/'source.json').write_text")<freeze.index("O=Path('/tmp/oriole-native-byte-count-thinlto-study')"))
build=js(B/'report.json');control=js(C/'report.json')
ck('fresh build completed',sha(B/'report.json')=='c7abfbc1ff2e5be3ba8610329c5db262ec86985758cb9e19cdc2b11dc7410f65' and build['status']=='passed' and build['source_unchanged'] and build['original_unchanged'] and build['source_manifest_sha256']==sha(S/'source.json') and build['fresh_workspace_compiles']==3)
for n in ['source.json','source.tar.gz','candidate.patch']:ck('build source copy '+n,read(B/n)==read(S/n))
for p,digest in build['original_hashes'].items():ck('build original input '+p,sha(p)==digest)
for row,(label,command,bound) in zip(build['commands'],[('rustc-version',['rustc','+ohm','-vV'],30),('release',['cargo','+ohm','-Zohm-defaults=no','rustc','--release','--locked','-p','oriole_expat','--lib','--crate-type','cdylib,staticlib','-vv'],1200)],strict=True):
 ck('build command '+label,row['label']==label and row['command']==command and row['cwd']==str(W) and row['affinity']==[3] and row['exit']==0 and row['timeout']==bound and 0<row['end']-row['start']<bound and 'exception' not in row and row['log_sha256']==sha(B/(label+'.log')))
normalized={};raw_invocations={}
workspace={'oriole_storage','oriole','oriole_expat'}
for label,root,work in [('control',C,'/home/dev-user/code/oss/oriole-raw-len-split'),('candidate',B,str(W))]:
 text=read(root/'release.log').decode();rows=[];normalized[label]={}
 for line in text.splitlines():
  if 'Running `' not in line or '/rustc ' not in line:continue
  args=shlex.split(line.strip()[len('Running `'):-1]);crate=args[args.index('--crate-name')+1]
  codegen=[args[i+1] for i,a in enumerate(args[:-1]) if a=='-C'];types=[args[i+1] for i,a in enumerate(args[:-1]) if a=='--crate-type']
  rows.append({'crate':crate,'command_line':line,'codegen_options':codegen,'crate_types':types})
  if crate not in workspace:continue
  ck(label+' unique workspace compile '+crate,crate not in normalized[label])
  ck(label+' ThinLTO opts '+crate,'opt-level=3' in codegen and 'codegen-units=1' in codegen and ('lto=thin' if crate=='oriole_expat' else 'linker-plugin-lto') in codegen and not any('profile-use' in a or 'profile-generate' in a for a in args))
  ck(label+' crate types '+crate,types==(['cdylib','staticlib'] if crate=='oriole_expat' else ['lib']))
  line,count=re.subn(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}','<PRIVATE_BUILD>',line.replace(work,'<WORKTREE>'));ck(label+' private path replacements '+crate,count>=3);normalized[label][crate]=line
 ck(label+' actual invocation manifest exact',rows==js(root/'compiler-invocations.json'))
 ck(label+' exactly three workspace compiles',set(normalized[label])==workspace and sum(r['crate'] in workspace for r in rows)==3)
 raw_invocations[label]=rows
ck('candidate extra compiler lines are two registry dependencies',len(raw_invocations['candidate'])==5 and {r['crate'] for r in raw_invocations['candidate'] if r['crate'] not in workspace}=={'allocator_api2','hashbrown'})
ck('three actual vectors equal',normalized['control']==normalized['candidate']==build['compiler_comparison']['normalized']['candidate'] and normalized==build['compiler_comparison']['normalized'] and build['compiler_comparison']['matched_after_private_paths_only'])
ck('compiler versions byte equal',read(B/'rustc-version.log')==read(C/'rustc-version.log') and build['rustc_version']==control['rustc_version']==read(B/'rustc-version.log').decode())
envdiff={k:[control['env_overrides'].get(k),build['env_overrides'].get(k)] for k in set(control['env_overrides'])|set(build['env_overrides']) if control['env_overrides'].get(k)!=build['env_overrides'].get(k)}
ck('only target directory differs in recorded overrides',set(envdiff)=={'CARGO_TARGET_DIR'})
expected_libraries={'liboriole_expat.so':'ccfb22956a11c1b241ec755f46245c61f088187ef93143b77a7afec748983821','liboriole_expat.a':'f58d5bc6ed28077933fcbcb84ad876cc7208e0102c9008347223da91a328b03c'}
ck('both library identities recorded',build['libraries']==control['libraries']==expected_libraries and build['library_bytes_identical_to_control']=={n:True for n in expected_libraries})
for n,digest in expected_libraries.items():ck('whole library bytes identical '+n,read(B/n)==read(C/n) and sha(B/n)==digest)
oldbuild=read(C/'build.py').decode();newbuild=read(B/'build.py').decode()
changes=[('raw-length fallback split source','integrated native byte-count source'),('/home/dev-user/code/oss/oriole-raw-len-split','/home/dev-user/code/oss/oriole-native-byte-count'),("S=Path('/tmp/oriole-raw-len-split-study'); B=Path('/tmp/oriole-end-frame-cells-final-thinlto-study')","S=Path('/tmp/oriole-native-byte-count-study'); B=Path('/tmp/oriole-raw-len-split-thinlto-study')"),('/home/dev-user/.cache/oriole/raw-len-split-target','/home/dev-user/.cache/oriole/native-byte-count-target'),("['source.json','candidate.patch','source.tar.gz','base-source.json','focused/report.json']","['source.json','candidate.patch','source.tar.gz','composition.json']"),("('control',oldrows,'/home/dev-user/code/oss/oriole-end-frame-cells')","('control',oldrows,'/home/dev-user/code/oss/oriole-raw-len-split')"),('versus final1ff7 End+Cell02fc/69eb','versus isolated prototypeccfb/f58'),("report['fresh_workspace_compiles']=3; report['library_bytes_differ_from_control']={n:sha(O/n)!=sha(B/n) for n in report['libraries']}; report['status']='passed'","report['fresh_workspace_compiles']=3; report['library_bytes_identical_to_control']={n:sha(O/n)==sha(B/n) for n in report['libraries']}; assert all(report['library_bytes_identical_to_control'].values()); report['status']='passed'")]
adapted=oldbuild
for a,b in changes:ck('builder expected unique replacement '+a,adapted.count(a)==1);adapted=adapted.replace(a,b)
ck('build controller exact adaptation',adapted==newbuild)
ck('build controller patch exact',read(B/'controller.patch').decode()==''.join(difflib.unified_diff(oldbuild.splitlines(True),newbuild.splitlines(True),fromfile='prototype-build.py',tofile='integrated-build.py')))
sha(B/'controller.log')
reviews={}
for label,path,digest in [('prototype_source_build','/tmp/oriole-raw-len-split-independent-review/review.json','4bb36d5f416a2e3cf45230777bf74c125edc7f3f2e0c16f6b7517da5b5ffa504'),('prototype_native','/tmp/oriole-raw-len-split-native-independent-review/review.json','4c38aebbd27e3f15a2f49ac5da410f2c76a0f5aec371bc424d89840cde196585'),('prototype_instruction','/tmp/oriole-raw-len-split-profile-independent-review/review.json','79c42f912f291103a5271adf99b0e3950385661bf9cbffd4fe57ac483560d5e3')]:ck('prior review pinned '+label,sha(path)==digest);reviews[label]={'path':path,'sha256':digest}
sha(Path(__file__))
ck('all inspected bytes unchanged',all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in tracked.items()))
for name,value in [('checked-files.json',tracked),('checks.json',checks),('git-reads.json',git_reads),('normalized-compiler-vectors.json',normalized),('actual-compiler-invocations.json',raw_invocations)]: (O/name).write_text(json.dumps(value,indent=2)+'\n')
report={'status':'independent_selected_source_and_fresh_build_audit_passed','blocking_findings':[],'scope':'Saved source, archives, immutable Git blobs and actual compiler logs only. No builds, compiler executions, target runs or tests.','source_manifest_sha256':sha(S/'source.json'),'base':base,'reviewed_commit':head,'source_files_verified_live_archive_base_and_commit':70,'prototype_source_manifest_sha256':sha(P/'source.json'),'prototype_changed_files':[test],'runtime_patch_sha256':sha(S/'candidate.patch'),'composition':'Exact prior runtime patch atop079fb; only source-map difference from measured1ff prototype is the previously published cfg(test) i64-to-c_long cast. All69 other inputs match prototype bytes.','fresh_build_report_sha256':sha(B/'report.json'),'actual_workspace_compiler_vectors':3,'actual_compiler_invocations':5,'extra_registry_compiles':['allocator_api2','hashbrown'],'actual_vectors_equal_after_private_paths_only':True,'recorded_environment_differences':envdiff,'libraries':expected_libraries,'shared_and_static_whole_bytes_equal_to_measured_prototype':True,'prior_reviews':reviews,'initial_producer_verifier_failure':initial,'limitations':['Initial failed helper is described in the retained JSON declaration. Its original raw script and traceback are absent from the source-study directory; this audit does not claim to replay or independently establish that historical execution. The corrected verifier and source composition are independently checked.','Recorded environment overrides differ only by target directory versus measured prototype; complete ambient environment identity is not established. Earlier prototype removed two Ohm trust opt-ins relative to End+Cell.','Native instruction and timing measurements retain their original prototype sourcebb6d identity; integrated source735afb is separately verified to yield byte-identical libraries.','Full workspace, C API, strict differential and CPython gates are handled separately; none were run or evaluated by this source/build audit.'],'checked_files':len(tracked),'passed_checks':len(checks),'git_read_operations':len(git_reads),'all_inspected_files_unchanged':True,'generator_sha256':sha(Path(__file__))}
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest(),'status':report['status'],'checked_files':len(tracked),'passed_checks':len(checks),'git_reads':len(git_reads)},indent=2))
