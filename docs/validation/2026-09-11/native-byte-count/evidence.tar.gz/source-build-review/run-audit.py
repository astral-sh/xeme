from pathlib import Path
import subprocess,json,hashlib,time
O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt={'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'command':['taskset','-c','4','python3',str(O/'generator.py')],'scope':'Saved source/compiler audit; only git show/diff and file reads, no target or compiler execution.'}
with (O/'attempt-01.stdout').open('xb') as stdout,(O/'attempt-01.stderr').open('xb') as stderr:
 p=subprocess.run(receipt['command'],stdout=stdout,stderr=stderr,timeout=120)
receipt['exit']=p.returncode;receipt['generator_sha256']=sha(O/'generator.py')
for stream in ['stdout','stderr']:receipt[stream+'_sha256']=sha(O/f'attempt-01.{stream}')
(O/'attempt-01.json').write_text(json.dumps(receipt,indent=2)+'\n')
print((O/'attempt-01.stdout').read_text());print((O/'attempt-01.stderr').read_text());raise SystemExit(p.returncode)
