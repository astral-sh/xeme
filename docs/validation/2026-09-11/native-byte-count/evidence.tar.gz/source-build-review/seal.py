from pathlib import Path
import hashlib,json,os
assert os.sched_getaffinity(0)=={4}
O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checked=json.loads((O/'checked-files.json').read_text());r=json.loads((O/'review.json').read_text());a=json.loads((O/'attempt-01.json').read_text())
assert len(checked)==105 and all(sha(p)==h for p,h in checked.items())
assert sha(O/'review.json')=='f1f801a46736344b8fae130ed3ca815c9d71c542c0dda15b098cd5e784c0d886'
assert r['checked_files']==105 and r['passed_checks']==225 and r['git_read_operations']==215
assert len(json.loads((O/'checks.json').read_text()))==225 and len(json.loads((O/'git-reads.json').read_text()))==215
assert a['exit']==0 and a['generator_sha256']==r['generator_sha256']==sha(O/'generator.py')
for stream in ['stdout','stderr']:assert a[stream+'_sha256']==sha(O/f'attempt-01.{stream}')
assert (O/'attempt-01.stderr').read_bytes()==b''
receipt={'status':'sealed_selected_source_and_build_review','review_sha256':sha(O/'review.json'),'generator_sha256':sha(O/'generator.py'),'all105_inspected_files_unchanged':True,'audit_attempts':1,'first_attempt_exit':0,'target_executions':0,'scope':'Saved source, immutable Git blobs, archives and actual compiler logs; fresh library equality to the measured prototype. No target or compiler execution.'}
(O/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.iterdir()) if p.is_file() and p.name!='files.json'}
(O/'files.json').write_text(json.dumps(files,indent=2)+'\n')
for name,row in files.items():assert row=={'bytes':(O/name).stat().st_size,'sha256':sha(O/name)}
assert all(sha(p)==h for p,h in checked.items())
print(json.dumps({'review_sha256':sha(O/'review.json'),'receipt_sha256':sha(O/'receipt.json'),'files_sha256':sha(O/'files.json'),'indexed_output_files':len(files)},indent=2))
