from pathlib import Path
import hashlib,io,json,tarfile
R=Path(__file__).parent;D=R/'workspace-checks';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
r=j(D/'report.json');c=j(D/'counts.json');s=j(R/'source.json');assert r['status']=='passed' and r['before']==r['after']==s['source_sha256'] and len(r['before'])==70
assert r['unchanged'] and r['frozen_libraries_before']==r['frozen_libraries_after'] and r['frozen_libraries_unchanged']
assert all(sha(p)==v for p,v in r['frozen_libraries_before'].items())
assert len(r['commands'])==4
for row in r['commands']:assert row['exit']==0 and row['timeout_seconds']==900 and row['end']-row['start']<900 and sha(D/(row['label']+'.log'))==row['log_sha256']
assert c['all_target_count']==407 and len(c['all_target_rows'])==33 and c['doc_count']==1 and not c['added_tests'] and c['no_removed_or_changed_baseline_tests']
with tarfile.open(D/'source.tar.gz','r:gz') as t:
 actual={e.name:hashlib.sha256(t.extractfile(e).read()).hexdigest() for e in t.getmembers() if e.isfile()};assert actual==s['source_sha256'] and len(t.getmembers())==70
assert all(sha(Path(s['worktree'])/n)==v for n,v in s['source_sha256'].items())
report={'status':'author_saved_workspace_review_passed','source_manifest_sha256':sha(R/'source.json'),'source_files':70,'all_target_tests':407,'target_inventory_rows':33,'doc_tests':1,'new_or_removed_tests':0,'four_commands_exit0':True,'timeout_seconds_per_command':900,'raw_report_sha256':sha(D/'report.json'),'actual_counts_sha256':sha(D/'counts.json'),'scope':'Source/gate author rehashed saved Cargo logs, exact per-target test names versus prior407 baseline, all70 archive/live bytes and frozen C-only library hashes. No fresh parser reruns by this saved review; independent source/compiler review remains separate. Normal Rust workspace test binaries are distinct from the frozen C-only production artifacts.','frozen_libraries':r['frozen_libraries_before'],'original_failed_gates':'No failures in this workspace attempt. C End CPU guard and postprocessing-only attempts are preserved in separate C-gate evidence.'}
(R/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
