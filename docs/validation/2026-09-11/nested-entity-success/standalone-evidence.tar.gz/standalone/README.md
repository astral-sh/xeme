# Nested parameter-entity values: proposed positive fixture

**Prepared only. No compiler, parser worker or success result has run.** Source review and a separate execution release are required before `run.py --execute`.

This fixture targets the success path hidden by `test_alloc_nested_entities`: all 12 original chunk/deferral rows fail while creating its external child with allocation budget 12. The original negative callback requires child `XML_ERROR_NO_MEMORY` and parent `XML_ERROR_EXTERNAL_ENTITY_HANDLING`. Those assertions and results remain untouched.

## Exact inputs and independent oracle

`original-test.c.inc` and `original-handler.c.inc` preserve the adapted upstream body and failure callback. `inputs.inc` extracts their exact root and external-DTD C literal expressions. The root is 58 bytes; the DTD is 1,090 bytes. `input-bytes.json` pins both decoded byte strings. No XML changes or higher injection ceiling are used.

The separate success callback disables allocation injection and requires:

- Exactly one external subset request with the original system identifier, one child created, successfully parsed, and freed before root element callbacks.
- Exactly three parameter-entity declaration callbacks, in order `pe1`, `pe2`, `pe3`, each with 1,024 bytes. Every byte must equal `A + (index % 16)`, an independently specified oracle. The hashes in output supplement the exact byte comparison.
- Exactly one `doc` start and end with no attributes, successful final parse, and no parser error.
- Final root position: byte 58, line 2, column 7. Final external-DTD position: byte 1,090, line 3, column 23. These follow the fixed input lengths and newlines.
- Zero live custom-allocator blocks and requested bytes after freeing the root, including zero-size blocks. No allocation operation may fail.

Declaration-callback positions are recorded and compared separately; they are not a pass criterion. The existing suite records implementation differences in declaration-phase positions. Final positions and all semantic/lifecycle counts are strict criteria established before execution.

## Proposed execution

The controller pins current streaming PGO `8e12c181…` and Expat PGO `12d33ad2…`, uses chunks `0,1,2,3,4,5` × deferral `0,1`, and launches 24 fresh workers forming 12 library pairs. Chunk zero means a whole-input call; positive widths use the upstream feeder's non-final chunks followed by one final chunk. The child inherits the parent's handlers, user data and reparse-deferral mode, as in the original fixture.

Every API pointer is resolved from the explicit `RTLD_NOW|RTLD_LOCAL` handle and checked with `dladdr`/`realpath` against that library. Fourteen API origins are required. The canonical 70-file current-source manifest, fixture bytes, original result file and library bytes are checked before execution and after each worker.

One C11/O2/Wall/Wextra/Werror build is proposed on CPU 5, with a 60-second outer bound. Each worker retains the prior success-probe limits: CPU 5, three-second wall and CPU bounds, 1 GiB address-space limit, and a 768 MiB RSS rlimit setting. The RSS setting is not claimed as independently verified enforcement. The controller preserves stdout/stderr, commands, hashes and all first outcomes; it refuses to overwrite results or retry a build/worker. Owned process groups are killed/reaped on timeout, interruption and normal exit.

## Scope

The custom allocator prefixes allocations with an aligned header, checks addition overflow, and changes accounting only after successful malloc/realloc. Realloc failure retains the old block and accounting. Counts and requested-byte peaks exclude header/libc overhead and transient realloc overlap; they are not RSS or whole-process memory measurements. This is a positive-path balance check, not injected-allocation-failure recovery or sanitizer evidence. Unexpected assertion exits are retained failures, not cleanup proofs.

The prior six success-probed bodies remain separate. Existing Rust parameter-value, external-value and deep-entity tests already cover related semantics; this fixture adds the exact long-value C/custom-allocator/child callback path. Even if all proposed workers pass, the original 4,740-row matrix and its 12 negative-oracle failures remain unchanged.
