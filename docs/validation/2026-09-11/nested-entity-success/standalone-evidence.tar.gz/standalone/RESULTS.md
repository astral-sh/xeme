# Nested-entity success results

**All 24 first-run workers passed**, forming 12 exact semantic/final-position comparisons across chunks 0..5 and deferral 0/1. The one compiler attempt passed. There were no timeouts, retries or changed assertions. This is a collector-owned report; the C/controller received independent source review before execution.

Each worker delivered exactly `pe1`, `pe2`, `pe3` in order, each a parameter entity with all 1,024 value bytes matching the independent A..P pattern. The parent and its one external child completed without error; the child was freed before one `doc` start/end pair. All custom allocators ended with zero live bytes and blocks and no allocation failures.

Final positions matched: root byte 58, line 2, column 7; child byte 1,090, line 3, column 23. Declaration positions remain different in all 12 pairs: Oriole reports declaration starts at bytes 0/1,043/1,067, column 0; Expat reports value starts at bytes 15/1,058/1,082, column 15. Both report lines 1/2/3. These positions were observational in the reviewed fixture and were not normalized.

Oriole used 62 successful mallocs and 62 frees per worker; whole-input mode used five reallocs and peaked at 25,492 requested bytes, while positive chunk widths used seven reallocs and peaked at 26,276 bytes. Expat used 23 mallocs/frees, no reallocs, and peaked at 15,884 requested bytes. These are custom-allocator requested bytes, excluding metadata, libc overhead and transient realloc overlap, not RSS.

[Raw results](results.json), [compact saved assessment](assessment.json), [original failure rows](original-failure-rows.json), and the [reviewed design](README.md) retain their distinct scope. The original 12 injected-failure assertions and full 4,740-row matrix remain unchanged. This establishes a separate positive path; it does not establish allocation-failure cleanup, sanitizer safety, or full callback-position compatibility.
