#define _GNU_SOURCE
#include "expat.h"
#include <dlfcn.h>
#include <inttypes.h>
#include <limits.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "inputs.inc"

#define REQUIRE(c) do { if (!(c)) { \
  fprintf(stderr, "failed: %s at line %d\n", #c, __LINE__); exit(2); \
} } while (0)

static struct {
  XML_Parser (*create)(const XML_Char *, const XML_Memory_Handling_Suite *, const XML_Char *);
  XML_Parser (*child)(XML_Parser, const XML_Char *, const XML_Char *);
  void (*free_parser)(XML_Parser);
  enum XML_Status (*parse)(XML_Parser, const char *, int, int);
  enum XML_Error (*error)(XML_Parser);
  void (*user_data)(XML_Parser, void *);
  int (*parameter_mode)(XML_Parser, enum XML_ParamEntityParsing);
  void (*external_handler)(XML_Parser, XML_ExternalEntityRefHandler);
  void (*declaration_handler)(XML_Parser, XML_EntityDeclHandler);
  void (*element_handlers)(XML_Parser, XML_StartElementHandler, XML_EndElementHandler);
  XML_Bool (*deferral)(XML_Parser, XML_Bool);
  XML_Index (*byte_index)(XML_Parser);
  XML_Size (*line)(XML_Parser);
  XML_Size (*column)(XML_Parser);
} api;

typedef union Header {
  max_align_t alignment;
  struct { size_t size; uint64_t magic; } data;
} Header;
#define MAGIC UINT64_C(0x129ea718420ddcb5)
static struct {
  size_t live_bytes, peak_bytes, live_blocks, peak_blocks;
  uint64_t malloc_ok, realloc_ok, free_calls, failed;
} memory;

static int can_allocate(size_t n, size_t replaced) {
  return n <= SIZE_MAX - sizeof(Header)
      && n <= SIZE_MAX - (memory.live_bytes - replaced);
}

static void account_allocation(size_t n, size_t replaced, int new_block) {
  memory.live_bytes = memory.live_bytes - replaced + n;
  if (new_block) { REQUIRE(memory.live_blocks < SIZE_MAX); memory.live_blocks++; }
  if (memory.live_bytes > memory.peak_bytes) memory.peak_bytes = memory.live_bytes;
  if (memory.live_blocks > memory.peak_blocks) memory.peak_blocks = memory.live_blocks;
}

static void *tracked_malloc(size_t n) {
  if (!can_allocate(n, 0)) { memory.failed++; return NULL; }
  Header *h = malloc(sizeof(*h) + n);
  if (h == NULL) { memory.failed++; return NULL; }
  h->data.size = n; h->data.magic = MAGIC;
  account_allocation(n, 0, 1); memory.malloc_ok++;
  return h + 1;
}

static void *tracked_realloc(void *p, size_t n) {
  if (p == NULL) {
    if (!can_allocate(n, 0)) { memory.failed++; return NULL; }
    Header *h = realloc(NULL, sizeof(*h) + n);
    if (h == NULL) { memory.failed++; return NULL; }
    h->data.size = n; h->data.magic = MAGIC;
    account_allocation(n, 0, 1); memory.realloc_ok++;
    return h + 1;
  }
  Header *old = (Header *)p - 1;
  REQUIRE(old->data.magic == MAGIC && old->data.size <= memory.live_bytes);
  const size_t previous = old->data.size;
  if (!can_allocate(n, previous)) { memory.failed++; return NULL; }
  Header *h = realloc(old, sizeof(*h) + n);
  if (h == NULL) { memory.failed++; return NULL; }
  h->data.size = n; h->data.magic = MAGIC;
  account_allocation(n, previous, 0); memory.realloc_ok++;
  return h + 1;
}

static void tracked_free(void *p) {
  if (p == NULL) return;
  Header *h = (Header *)p - 1;
  REQUIRE(h->data.magic == MAGIC && memory.live_blocks > 0);
  REQUIRE(h->data.size <= memory.live_bytes);
  memory.live_bytes -= h->data.size; memory.live_blocks--; memory.free_calls++;
  h->data.magic = 0; free(h);
}

typedef struct { int64_t byte; uint64_t line, column; } Position;
static Position position(XML_Parser p) {
  Position r = {(int64_t)api.byte_index(p), (uint64_t)api.line(p), (uint64_t)api.column(p)};
  return r;
}
static void print_position(Position p) {
  printf("{\"byte\":%" PRId64 ",\"line\":%" PRIu64 ",\"column\":%" PRIu64 "}", p.byte, p.line, p.column);
}
static uint64_t hash_value(const char *value, size_t n) {
  uint64_t h = UINT64_C(14695981039346656037);
  for (size_t i = 0; i < n; i++) { h ^= (unsigned char)value[i]; h *= UINT64_C(1099511628211); }
  return h;
}

static struct {
  XML_Parser root, active_child;
  int chunk, deferral;
  unsigned declarations, starts, ends, external_calls, created, completed, freed;
  uint64_t value_hash[3];
  Position declaration_positions[3], root_position, child_position;
} state;

static enum XML_Status feed(XML_Parser p, const char *text, size_t length) {
  REQUIRE(length <= INT_MAX);
  if (state.chunk > 0) {
    while (length > (size_t)state.chunk) {
      enum XML_Status status = api.parse(p, text, state.chunk, XML_FALSE);
      if (status != XML_STATUS_OK) return status;
      text += state.chunk; length -= (size_t)state.chunk;
    }
  }
  return api.parse(p, text, (int)length, XML_TRUE);
}

static void XMLCALL declaration(void *user, const XML_Char *name, int parameter,
    const XML_Char *value, int length, const XML_Char *base,
    const XML_Char *system, const XML_Char *public_id, const XML_Char *notation) {
  static const char *const expected_names[] = {"pe1", "pe2", "pe3"};
  REQUIRE(user == &state && state.active_child != NULL);
  REQUIRE(state.declarations < 3 && parameter == 1 && value != NULL && length == 1024);
  REQUIRE(strcmp(name, expected_names[state.declarations]) == 0);
  REQUIRE(base == NULL && system == NULL && public_id == NULL && notation == NULL);
  /* Independent oracle: 64 repetitions of A..P, not bytes copied from the input. */
  for (int i = 0; i < length; i++) REQUIRE(value[i] == 'A' + i % 16);
  state.value_hash[state.declarations] = hash_value(value, (size_t)length);
  state.declaration_positions[state.declarations] = position(state.active_child);
  state.declarations++;
}

static void XMLCALL start(void *user, const XML_Char *name, const XML_Char **attributes) {
  REQUIRE(user == &state && state.active_child == NULL && state.freed == 1);
  REQUIRE(strcmp(name, "doc") == 0 && attributes != NULL && attributes[0] == NULL);
  REQUIRE(state.starts == 0 && state.ends == 0); state.starts++;
}
static void XMLCALL end(void *user, const XML_Char *name) {
  REQUIRE(user == &state && state.active_child == NULL && strcmp(name, "doc") == 0);
  REQUIRE(state.starts == 1 && state.ends == 0); state.ends++;
}

static int XMLCALL external(XML_Parser parent, const XML_Char *context,
    const XML_Char *base, const XML_Char *system, const XML_Char *public_id) {
  REQUIRE(parent == state.root && state.external_calls == 0);
  REQUIRE(context == NULL && base == NULL && public_id == NULL);
  REQUIRE(system != NULL && strcmp(system, "http://example.org/one.ent") == 0);
  state.external_calls++;
  XML_Parser child = api.child(parent, context, NULL);
  REQUIRE(child != NULL); state.created++; state.active_child = child;
  /* As upstream, the child inherits handlers, user data and deferral from the parent. */
  REQUIRE(feed(child, external_dtd, sizeof(external_dtd) - 1) == XML_STATUS_OK);
  REQUIRE(api.error(child) == XML_ERROR_NONE && state.declarations == 3);
  state.child_position = position(child);
  REQUIRE(state.child_position.byte == (int64_t)(sizeof(external_dtd) - 1));
  REQUIRE(state.child_position.line == 3 && state.child_position.column == 23);
  state.completed++;
  api.free_parser(child); state.active_child = NULL; state.freed++;
  return XML_STATUS_OK;
}

int main(int argc, char **argv) {
  REQUIRE(argc == 4 && argv[1][0] == '/');
  REQUIRE(strlen(argv[2]) == 1 && argv[2][0] >= '0' && argv[2][0] <= '5');
  REQUIRE(strlen(argv[3]) == 1 && (argv[3][0] == '0' || argv[3][0] == '1'));
  state.chunk = argv[2][0] - '0'; state.deferral = argv[3][0] - '0';
  char requested[PATH_MAX]; REQUIRE(realpath(argv[1], requested) != NULL);
  void *library = dlopen(requested, RTLD_NOW | RTLD_LOCAL);
  if (library == NULL) { fprintf(stderr, "%s\n", dlerror()); return 2; }
  unsigned origin_checks = 0;
#define LOAD(field, name) do { \
  void *symbol = dlsym(library, name); Dl_info info; char actual[PATH_MAX]; \
  _Static_assert(sizeof(api.field) == sizeof(symbol), "function pointer ABI"); \
  REQUIRE(symbol != NULL && dladdr(symbol, &info) != 0 && info.dli_fname != NULL); \
  REQUIRE(realpath(info.dli_fname, actual) != NULL && strcmp(actual, requested) == 0); \
  memcpy(&api.field, &symbol, sizeof(symbol)); origin_checks++; \
} while (0)
  LOAD(create, "XML_ParserCreate_MM"); LOAD(child, "XML_ExternalEntityParserCreate");
  LOAD(free_parser, "XML_ParserFree"); LOAD(parse, "XML_Parse"); LOAD(error, "XML_GetErrorCode");
  LOAD(user_data, "XML_SetUserData"); LOAD(parameter_mode, "XML_SetParamEntityParsing");
  LOAD(external_handler, "XML_SetExternalEntityRefHandler"); LOAD(declaration_handler, "XML_SetEntityDeclHandler");
  LOAD(element_handlers, "XML_SetElementHandler"); LOAD(deferral, "XML_SetReparseDeferralEnabled");
  LOAD(byte_index, "XML_GetCurrentByteIndex"); LOAD(line, "XML_GetCurrentLineNumber"); LOAD(column, "XML_GetCurrentColumnNumber");
#undef LOAD
  const XML_Memory_Handling_Suite suite = {tracked_malloc, tracked_realloc, tracked_free};
  state.root = api.create(NULL, &suite, NULL); REQUIRE(state.root != NULL);
  api.user_data(state.root, &state);
  REQUIRE(api.parameter_mode(state.root, XML_PARAM_ENTITY_PARSING_ALWAYS) != 0);
  REQUIRE(api.deferral(state.root, state.deferral ? XML_TRUE : XML_FALSE) != 0);
  api.external_handler(state.root, external); api.declaration_handler(state.root, declaration);
  api.element_handlers(state.root, start, end);
  REQUIRE(feed(state.root, root_xml, sizeof(root_xml) - 1) == XML_STATUS_OK);
  REQUIRE(api.error(state.root) == XML_ERROR_NONE);
  REQUIRE(state.declarations == 3 && state.starts == 1 && state.ends == 1);
  REQUIRE(state.external_calls == 1 && state.created == 1 && state.completed == 1 && state.freed == 1);
  state.root_position = position(state.root);
  REQUIRE(state.root_position.byte == (int64_t)(sizeof(root_xml) - 1));
  REQUIRE(state.root_position.line == 2 && state.root_position.column == 7);
  api.free_parser(state.root); state.root = NULL;
  REQUIRE(memory.live_bytes == 0 && memory.live_blocks == 0 && memory.failed == 0);
  REQUIRE(origin_checks == 14 && dlclose(library) == 0);
  printf("{\"status\":\"passed\",\"chunk\":%d,\"deferral\":%d,\"origin_checks\":%u,\"canonical\":{\"declarations\":[", state.chunk, state.deferral, origin_checks);
  for (unsigned i = 0; i < 3; i++) {
    printf("%s{\"name\":\"pe%u\",\"parameter\":1,\"length\":1024,\"fnv1a64\":\"%016" PRIx64 "\"}", i ? "," : "", i + 1, state.value_hash[i]);
  }
  printf("],\"starts\":1,\"ends\":1,\"children_created\":1,\"children_completed\":1,\"children_freed\":1,\"root_position\":");
  print_position(state.root_position); printf(",\"child_position\":"); print_position(state.child_position);
  printf("},\"declaration_positions\":[");
  for (unsigned i = 0; i < 3; i++) { if (i) putchar(','); print_position(state.declaration_positions[i]); }
  printf("],\"allocator\":{\"live_bytes\":%zu,\"live_blocks\":%zu,\"peak_requested_bytes\":%zu,\"peak_blocks\":%zu,\"successful_mallocs\":%" PRIu64 ",\"successful_reallocs\":%" PRIu64 ",\"frees\":%" PRIu64 ",\"failures\":%" PRIu64 "}}\n", memory.live_bytes, memory.live_blocks, memory.peak_bytes, memory.peak_blocks, memory.malloc_ok, memory.realloc_ok, memory.free_calls, memory.failed);
  return 0;
}
