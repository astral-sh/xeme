"""HELD until source review and root release; 24 fresh success-only workers."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/dev-user/code/oss/oriole-streaming-input-bounds')
LIBRARIES = {
    'streaming_pgo': (Path('/tmp/oriole-streaming-work-pgo-study-attempt02/pgo/runs/run-psjiwn9z/use/liboriole_expat.so'),
                      '8e12c1819a58a66ae5530a53433dd08de44921c94a2b39a6282358dfd33c0d1e'),
    'expat_pgo': (Path('/tmp/oriole-pgo-study/expat-use-liboriole_expat.so'),
                  '12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'),
}
CPU = 5
active = None
interrupted = None

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def check_sources():
    pins = json.loads((HERE / 'source-pins.json').read_text())
    for name, expected in pins['fixture_files'].items():
        assert digest(HERE / name) == expected, name
    source = json.loads((HERE / 'current-source.json').read_text())
    assert digest(HERE / 'current-source.json') == 'e52c4fa16e71a7dcd76864b29509b157a42b6fbe4531f87b68f98395418d5fc3'
    assert len(source['source_sha256']) == 70
    for name, expected in source['source_sha256'].items():
        assert digest(ROOT / name) == expected, name
    for name, expected in pins['external_inputs'].items():
        assert digest(name) == expected, name
    for path, expected in LIBRARIES.values():
        assert digest(path) == expected, str(path)

def kill_owned():
    global active
    if active is not None:
        try:
            os.killpg(active.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        active.wait()

def interrupt(signum, _frame):
    global interrupted
    interrupted = signum
    if active is not None:
        kill_owned()
        raise KeyboardInterrupt(f'signal {signum}')

def main():
    global active
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', required=True)
    parser.parse_args()
    check_sources()
    assert not (HERE / 'results.json').exists()
    assert not (HERE / 'probe').exists()
    logdir = HERE / 'logs'
    logdir.mkdir(exist_ok=False)
    env = dict(os.environ)
    remove = ['LD_PRELOAD', 'LD_LIBRARY_PATH', 'ASAN_OPTIONS', 'LSAN_OPTIONS', 'UBSAN_OPTIONS',
              'CFLAGS', 'CPPFLAGS', 'LDFLAGS', 'CC', 'CXX', 'LLVM_PROFILE_FILE']
    removed = sorted(key for key in remove if key in env)
    for key in remove:
        env.pop(key, None)
    report = {'status': 'incomplete', 'scope': 'Separate positive fixture; original 4740-row matrix and injected-failure assertions remain unchanged.',
              'source_pins_sha256': digest(HERE / 'source-pins.json'),
              'controller_sha256': digest(Path(__file__)), 'removed_env': removed,
              'bounds': {'cpu': CPU, 'worker_wall_seconds': 3, 'worker_cpu_seconds': 3,
                         'address_space_bytes': 1073741824, 'rss_rlimit_setting_bytes': 805306368,
                         'compile_wall_seconds': 60},
              'compiler': {'path': '/usr/bin/cc', 'resolved': str(Path('/usr/bin/cc').resolve()),
                           'sha256': digest('/usr/bin/cc')},
              'libraries': {name: {'path': str(path), 'sha256': expected} for name, (path, expected) in LIBRARIES.items()},
              'commands': [], 'workers': [], 'comparisons': []}

    def run(command, label, timeout):
        global active
        stdout, stderr = logdir / (label + '.stdout'), logdir / (label + '.stderr')
        row = {'label': label, 'command': command, 'wall_seconds': timeout,
               'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
        report['commands'].append(row)
        save(HERE / 'results.json', report)
        start_time = time.monotonic()
        try:
            with stdout.open('xb') as out, stderr.open('xb') as err:
                active = subprocess.Popen(command, cwd=HERE, env=env, stdout=out, stderr=err, start_new_session=True)
                if interrupted is not None:
                    raise KeyboardInterrupt(f'signal {interrupted}')
                try:
                    row['exit_code'] = active.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    row['timed_out'] = True
                    kill_owned()
                    row['exit_code'] = active.returncode
                finally:
                    kill_owned()
                    active = None
        finally:
            row['elapsed_seconds'] = time.monotonic() - start_time
            if stdout.exists(): row['stdout_sha256'] = digest(stdout)
            if stderr.exists(): row['stderr_sha256'] = digest(stderr)
            save(HERE / 'results.json', report)
        return row, stdout.read_text(errors='replace')

    for sig in [signal.SIGINT, signal.SIGTERM]: signal.signal(sig, interrupt)
    try:
        version, _ = run(['taskset', '-c', str(CPU), '/usr/bin/cc', '--version'], 'compiler-version', 10)
        assert version['exit_code'] == 0
        command = ['taskset', '-c', str(CPU), '/usr/bin/cc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror',
                   '-I', str(HERE), str(HERE / 'probe.c'), '-ldl', '-o', str(HERE / 'probe')]
        build, _ = run(command, 'build', 60)
        assert build['exit_code'] == 0 and not build.get('timed_out'), 'first compile failed; no workers launched'
        check_sources()
        report['probe_sha256'] = digest(HERE / 'probe')
        observations = {}
        for chunk in range(6):
            for deferral in range(2):
                for engine, (library, _) in LIBRARIES.items():
                    check_sources()
                    assert digest(HERE / 'probe') == report['probe_sha256']
                    label = f'{engine}-chunk{chunk}-deferral{deferral}'
                    command = ['taskset', '-c', str(CPU), '/usr/bin/prlimit', '--cpu=3:3',
                               '--as=1073741824:1073741824', '--rss=805306368:805306368', '--',
                               str(HERE / 'probe'), str(library), str(chunk), str(deferral)]
                    row, stdout = run(command, label, 3)
                    worker = {'engine': engine, 'chunk': chunk, 'deferral': deferral, 'command_label': label,
                              'exit_code': row['exit_code'], 'timed_out': row.get('timed_out', False)}
                    if row['exit_code'] == 0 and not row.get('timed_out'):
                        try:
                            observed = json.loads(stdout)
                            assert observed['status'] == 'passed' and observed['origin_checks'] == 14
                            assert observed['chunk'] == chunk and observed['deferral'] == deferral
                            worker['observation'] = observed
                            observations[engine, chunk, deferral] = observed
                        except (ValueError, KeyError, AssertionError) as error:
                            worker['observation_error'] = repr(error)
                    report['workers'].append(worker)
                    check_sources()
                    assert digest(HERE / 'probe') == report['probe_sha256']
                    save(HERE / 'results.json', report)
                left = observations.get(('streaming_pgo', chunk, deferral))
                right = observations.get(('expat_pgo', chunk, deferral))
                report['comparisons'].append({'chunk': chunk, 'deferral': deferral,
                    'both_successful': left is not None and right is not None,
                    'canonical_equal': left is not None and right is not None and left['canonical'] == right['canonical'],
                    'declaration_positions_equal': left is not None and right is not None and left['declaration_positions'] == right['declaration_positions']})
        report['status'] = 'passed' if len(observations) == 24 and all(r['canonical_equal'] for r in report['comparisons']) else 'failed'
        report['source_unchanged'] = True
    except BaseException as error:
        report['status'] = 'failed'
        report['exception'] = repr(error)
        raise
    finally:
        kill_owned()
        active = None
        save(HERE / 'results.json', report)
    raise SystemExit(0 if report['status'] == 'passed' else 1)

if __name__ == '__main__':
    main()
