"""Saved-data audit only; never executes the downloaded interpreter or parser."""
import hashlib
import json
import re
import shlex
import subprocess
import zipfile
from pathlib import Path

ROOT = Path('/tmp/oriole-pr124-pbs-results')
SOURCE = Path('/home/dev-user/code/oss/oriole-pbs-independent-checks')
HEAD = '4d603c7487ca93cc73dbd4acfe6fa5714ffc2151'
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def read(name):
    return (ROOT / name).read_text()
def data(name):
    return json.loads(read(name))

run = data('run.json')
assert run['head_sha'] == HEAD and run['conclusion'] == 'failure'
assert run['event'] == 'pull_request' and run['id'] == 34582636093
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == HEAD
assert subprocess.check_output(['git', 'diff', 'HEAD', '--'], cwd=SOURCE) == b''
jobs = data('jobs.json')['jobs']
assert len(jobs) == 1
steps = {step['name']: step['conclusion'] for step in jobs[0]['steps']}
for name in ('Build the distribution validator', 'Build the frozen Oriole bundle', 'Build CPython 3.12.13 with Oriole', 'Verify the installed parser identity'):
    assert steps[name] == 'success'
for name in ('Validate the complete distribution', 'Run the installed interpreter on glibc 2.17'):
    assert steps[name] == 'failure'
artifacts = data('artifacts.json')['artifacts']
for filename, name in (('validation.zip', 'oriole-pbs-validation'), ('distribution.zip', 'oriole-pbs-experimental-distribution')):
    artifact = next(a for a in artifacts if a['name'] == name)
    assert artifact['digest'] == 'sha256:' + sha(ROOT / filename)
    assert artifact['workflow_run']['head_sha'] == HEAD
    with zipfile.ZipFile(ROOT / filename) as archive:
        assert archive.testzip() is None
        for member in archive.infolist():
            actual = ROOT / ('validation/' + member.filename if filename == 'validation.zip' else member.filename)
            with archive.open(member) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == sha(actual)

bundle = data('validation/oriole-bundle/manifest.json')
for name, expected in bundle['sources'].items():
    assert sha(SOURCE / name) == expected, name
assert len(bundle['sources']) == 69 and 'pgo' not in bundle
baseline_path = Path('/tmp/oriole-streaming-work-pgo-study-attempt02/source.json')
baseline = json.loads(baseline_path.read_text())['source_sha256']
overlap = baseline.keys() & bundle['sources'].keys()
assert len(overlap) == 64
assert all(baseline[name] == bundle['sources'][name] for name in overlap)
assert bundle['rustc'].startswith('rustc 1.98.1 (48a229cea 2026-09-01)\n')
assert 'LLVM version: 22.1.8\n' in bundle['rustc']
assert bundle['rustflags'] == '-C relocation-model=pic -C panic=unwind'
assert read('selected/python/licenses/LICENSE.oriole-build.txt') == read('validation/oriole-bundle/manifest.json')
assert sha(ROOT / 'selected/python/build/lib/libexpat.a') == bundle['files']['libexpat.a']
assert sha(ROOT / 'selected/python/licenses/LICENSE.oriole.txt') == bundle['files']['LICENSE.oriole.txt']
distribution = data('distribution-members.json')
assert distribution['sha256'] == sha(ROOT / distribution['archive'])
assert distribution['sha256'] == read('validation/pbs-archive-sha256.txt').split()[0]

vectors = []
for line in read('validation/oriole-bundle/build.log').splitlines():
    if 'Running `' not in line or '--crate-name ' not in line:
        continue
    args = shlex.split(line.split('Running `')[1].rsplit('`', 1)[0])
    name = args[args.index('--crate-name') + 1]
    if name not in ('oriole_storage', 'oriole', 'oriole_expat'):
        continue
    assert args[0] == '/home/runner/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustc'
    assert args[args.index('--target') + 1] == 'x86_64-unknown-linux-gnu'
    assert not any(x.startswith('-Z') or 'profile-use' in x or 'profile-generate' in x for x in args)
    codegen = [args[i+1] if a == '-C' else a[2:] for i,a in enumerate(args) if a.startswith('-C')]
    checked = [a for a in codegen if not a.startswith(('metadata=', 'extra-filename='))]
    assert checked == ['opt-level=3', 'lto=thin' if name == 'oriole_expat' else 'linker-plugin-lto', 'codegen-units=1', 'strip=debuginfo', 'relocation-model=pic', 'panic=unwind']
    kinds = [args[i+1] for i,a in enumerate(args) if a == '--crate-type']
    assert kinds == (['cdylib', 'staticlib'] if name == 'oriole_expat' else ['lib'])
    vectors.append({'crate': name, 'argv': args, 'codegen': codegen})
assert len(vectors) == 3
tls = data('validation/pbs-tls-probe/manifest.json')
assert tls['rustc'] == bundle['rustc'] and tls['threads_per_binary'] == 32
for name, expected in tls['sources'].items():
    assert sha(SOURCE / 'integration/python-build-standalone' / name) == expected
elf = {}
for name in ('python', 'libpython'):
    symbols = read(name + '-dynsym.txt')
    versions = sorted(set(re.findall(r'@GLIBC_([0-9.]+)', symbols)), key=lambda v: tuple(map(int, v.split('.'))))
    assert versions[-1] == '2.17'
    hooks = [s for s in symbols.splitlines() if 'thread_atexit' in s]
    assert len(hooks) == 1 and 'WEAK' in hooks[0] and 'UND __wrap___cxa_thread_atexit_impl' in hooks[0] and '@' not in hooks[0]
    dynamic = read(name + '-dynamic.txt')
    assert 'libexpat' not in dynamic
    elf[name] = {'maximum_glibc_symbol_version': versions[-1], 'tls_hook': hooks[0].strip(), 'needed': re.findall(r'Shared library: \[([^]]+)\]', dynamic)}
host = read('validation/pbs-xml-tests.log')
glibc = read('validation/pbs-glibc217-tests.log')
expected_assertions = ["AssertionError: Lists differ: ['<a>', '1', '<b>', '2\\n3', '<c>', '4\\n5'] != ['<a>', '1', '<b>', '2', '\\n', '3', '<c>', '4\\n5']", "AssertionError: 'Parseable character data' != '\\nParseable character data\\n'"]
assert set(line for line in host.splitlines() if line.startswith('AssertionError:')) == set(expected_assertions)
assert set(line for line in glibc.splitlines() if line.startswith('AssertionError:')) == set(expected_assertions)
assert 'Total tests: run=806 failures=4 skipped=12' in host
assert 'Total test files: run=8/6 failed=2 rerun=2' in host
assert 'Total tests: run=802 failures=2 skipped=13' in glibc
thread_result = next(json.loads(line) for line in glibc.splitlines() if line.startswith('{"glibc":'))
assert thread_result == {'glibc': ['glibc', '2.17'], 'expat': 'oriole_compat_2.8.4', 'threaded_parses': 1024}
assert glibc.index('"threaded_parses": 1024') < glibc.index('AssertionError:')
assert 'returned non-zero exit status 2' in glibc
assert 'Ran 22 tests' in read('validation/pbs-custom-tests.log') and 'OK (skipped=5)' in read('validation/pbs-custom-tests.log')
assert read('validation/pbs-validate.log').strip().endswith(distribution['archive'] + ' OK')
workflow = read('workflow.log')
merge = 'a1068cba2ff0ecbd5718e7e5d704e1e7ebfb329a'
assert merge in workflow and f'Merge {HEAD} into 708ca42aa320d27bf289ce9a827ad3e64ca2522d' in workflow
build_log = read('validation/pbs-build.log')
for expected in ('fd679a16f36304444af11953ad276d4493f2044f904a39b8fdf028c6f7def8a0', '1c3cf2ee6dfa568cf833742ad786880f4816042705689a116a4f308b7a9d95f2', '-Wl,--wrap=__cxa_thread_atexit_impl'):
    assert expected in build_log
metadata = data('selected/python/PYTHON.json')
expat_link = metadata['build_info']['extensions']['pyexpat'][0]
assert {'name': 'expat', 'path_static': 'build/lib/libexpat.a'} in expat_link['links']
assert expat_link['license_paths'] == ['licenses/LICENSE.oriole.txt']
assert metadata['build_info']['extensions']['_elementtree'][0]['links'] == []
assert "['-u', 'all,-largefile,-audio,-gui']" in read('selected/python/build/run_tests.py')
assert "'-w'," in read('selected/python/build/run_tests.py')
for name in ('pbs.yml', 'test-old-glibc.py'):
    path = SOURCE / ('.github/workflows/pbs.yml' if name == 'pbs.yml' else 'integration/python-build-standalone/test-old-glibc.py')
    (ROOT / name).write_bytes(path.read_bytes())

report = {
    'status': 'review passed; workflow remains failed on the two preserved XML assertions',
    'scope': 'Read-only GitHub retrieval, hashes, saved compiler-command review, archive inspection and readelf only. No rerun, dispatch, compiler, container or downloaded interpreter/parser execution.',
    'run': {'id': run['id'], 'url': run['html_url'], 'head': HEAD, 'checkout_merge': merge, 'event': run['event'], 'created_at': run['created_at'], 'updated_at': run['updated_at'], 'conclusion': run['conclusion'], 'steps': steps},
    'source': {'bundle_source_pins_verified_against_head': len(bundle['sources']), 'selected_streaming_manifest_sha256': sha(baseline_path), 'shared_streaming_source_pins_equal': len(overlap), 'scope_note': 'The 69 bundle inputs include 64 of the 70 local benchmark source pins plus licenses/backport provenance; CLI/C harness/README files are outside the bundle input inventory.'},
    'compiler': {'rustc': bundle['rustc'], 'normal_release': True, 'pgo': False, 'vectors': vectors, 'limitation': 'Normal CI retained compiler version/commit and actual invocations, but not a hash of the compiler executable.'},
    'distribution': {'archive': distribution['archive'], 'sha256': distribution['sha256'], 'size': (ROOT / distribution['archive']).stat().st_size, 'member_count': len(distribution['members']), 'libexpat_a_sha256': bundle['files']['libexpat.a'], 'bundle_manifest_sha256': sha(ROOT / 'validation/oriole-bundle/manifest.json'), 'embedded_manifest_identical': True, 'notices_identical': True, 'consumer_cleanup_patch': bundle['consumer_adaptation'], 'pyexpat_link': expat_link, 'elf': elf},
    'outcomes': {'distribution_validator': 'passed', 'custom_suite': {'run': 22, 'passed': 17, 'skipped': 5}, 'host_xml': {'initial_run': 802, 'initial_failures': 2, 'reported_skipped': 12, 'builtin_retry_methods': 4, 'builtin_retry_failures': 2, 'aggregate_run': 806, 'aggregate_failures': 4, 'files': 6}, 'glibc217': {'thread_probe': thread_result, 'xml_run': 802, 'xml_failures': 2, 'reported_skipped': 13, 'files': 6, 'failure_cause': 'Strict XML subprocess exited 2 after successful glibc identity and threaded parse probe.'}, 'failure_methods': ['test.test_pyexpat.BufferTextTest.test1', 'test.test_sax.CDATAHandlerTest.test_handlers'], 'assertions': expected_assertions, 'skip_scope': 'Host distribution harness enables all resources except largefile/audio/gui and automatic verbose retries; old-glibc script uses direct -I -m test with default resources. Aggregate logs do not expose all skipped or expected-failure method IDs; no 802-entry outcome map was inferred.'},
    'conclusion': 'The default normal-build selected streaming runtime linked and ran on actual glibc 2.17 with 1024 threaded parses; no new glibc/linkage regression is evident. Both strict XML gates retain the same two callback grouping/payload assertions. This is not an all-green distribution or a PGO deployment result.',
    'artifact_origins': artifacts,
    'binary_publication_exclusions': ['distribution.zip', distribution['archive'], 'selected/python/build/lib/libexpat.a', 'selected/python/install/bin/python3.12', 'selected/python/install/lib/libpython3.12.so.1.0'],
}
(ROOT / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print('report', sha(ROOT / 'report.json'))
print('source pins', len(bundle['sources']), 'compiler vectors', len(vectors), 'archive', distribution['sha256'])
