"""One root-authorized local Ohm PBS PGO build; retain first outcome."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,time
W=Path('/home/dev-user/code/oss/oriole-pbs-pgo-bundle')
O=Path('/tmp/oriole-pbs-pgo-bundle-local-attempt01')
STUDY=Path('/tmp/oriole-pbs-pgo-bundle-study')
P=Path('/tmp/oriole-pbs-pgo-bundle-local-attempt01-launch.json')
PY=Path('/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12')
PROF=Path('/tmp/oriole-pgo-study/llvm-tools-1.98.0/bin/llvm-profdata')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert __debug__ and os.sched_getaffinity(0)=={3} and not O.exists() and not P.exists()
review=json.loads(Path('/tmp/oriole-pbs-pgo-bundle-source-independent-review.json').read_text())
prep=json.loads((STUDY/'preparation.json').read_text())
assert review['status']=='passed_source_review' and sha(STUDY/'candidate.patch')==review['patch_sha256']
pins={p:v for p,v in prep['selected_runtime_70_files_unchanged'].items()}
pins.update({p:v for p,v in prep['files'].items() if p not in ['.github/workflows/ci.yml','integration/python-build-standalone/README.md']})
pins.update({str(p.relative_to(W)):sha(p) for p in (W/'tools/pgo').rglob('*') if p.is_file() and '__pycache__' not in p.parts})
for rel in ['LICENSE-MIT','LICENSE-APACHE','licenses/cpython.txt','integration/python-build-standalone/consumer-fix/provenance.json','integration/python-build-standalone/consumer-fix/cpython-3.12.13-external-parser.patch']:
    pins[rel]=sha(W/rel)
assert all(sha(W/p)==v for p,v in pins.items())
env=os.environ.copy()
removed=['RUSTC','RUSTFLAGS','LLVM_PROFILE_FILE','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST','PYTHONPATH','PYTHONHOME','LD_PRELOAD','LD_LIBRARY_PATH','CARGO_BUILD_RUSTC_WRAPPER','CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER']
removed += [k for k in env if k.startswith('CARGO_PROFILE_')]
for k in removed:env.pop(k,None)
overrides={'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/targets/pbs-pgo-bundle','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_ENCODED_RUSTFLAGS':'','RUSTUP_AUTO_INSTALL':'0','CARGO_TERM_COLOR':'never'}
env.update(overrides)
report={'status':'incomplete','role':'Collector-owned local Ohm build; independent source review preceded execution. Production stable build/distribution and timing remain separate.','cpu':3,'worktree':str(W),'output':str(O),'source_before':pins,'review_sha256':sha('/tmp/oriole-pbs-pgo-bundle-source-independent-review.json'),'controller_sha256':sha(__file__),'environment_removed':removed,'environment_overrides':overrides,'tools_before':{str(PY.resolve()):sha(PY),str(PROF.resolve()):sha(PROF)},'commands':[]}
def save():P.write_text(json.dumps(report,indent=2)+'\n')
def run(label,command,timeout):
    logfile=Path('/tmp/oriole-pbs-pgo-bundle-local-attempt01-'+label+'.log')
    row={'label':label,'argv':command,'cwd':str(W),'cpu':3,'timeout_seconds':timeout,'log':str(logfile),'started':time.time()};report['commands'].append(row);save();process=None
    with logfile.open('wb') as log:
        try:
            process=subprocess.Popen(command,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            row['returncode']=process.wait(timeout=timeout)
            if row['returncode']:raise RuntimeError(label+' failed')
        except BaseException as e:
            row['failure']=repr(e)
            if process is not None:
                try:os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                row['returncode']=process.wait()
            raise
        finally:log.flush();row['finished']=time.time();row['log_sha256']=sha(logfile);save()
    print(label,row['returncode'],flush=True)
    return logfile.read_text()
try:
    report['python_version']=run('python-version',[str(PY),'-E','-S','-B','--version'],30)
    report['rustc_version']=run('rustc-version',['rustc','+ohm','-vV'],30)
    sysroot=Path(run('sysroot',['rustc','+ohm','--print','sysroot'],30).strip())
    notices=sysroot/'share/doc/rust/COPYRIGHT-library.html';assert notices.is_file()
    tools=[sysroot/'bin/rustc',sysroot/'bin/cargo',notices,*list((sysroot/'lib').glob('libLLVM*')),*list((PROF.parent.parent/'lib').glob('libLLVM*'))]
    report['tools_before'].update({str(p.resolve()):sha(p) for p in tools if p.is_file()});save()
    command=[str(PY),'-E','-S','-B',str(W/'integration/python-build-standalone/prepare.py'),'--output',str(O),'--pgo','--toolchain','ohm','--cargo-arg=-Zohm-defaults=no','--llvm-profdata',str(PROF)]
    run('build',command,4200)
    assert (O/'manifest.json').is_file()
    report['manifest_sha256']=sha(O/'manifest.json');report['status']='passed'
except BaseException as e:
    report['failure']=repr(e);raise
finally:
    report['source_after']={p:sha(W/p) for p in pins};report['source_unchanged']=pins==report['source_after']
    report['tools_after']={p:sha(p) for p in report['tools_before']};report['tools_unchanged']=report['tools_before']==report['tools_after'];save()
assert report['source_unchanged'] and report['tools_unchanged']
print(json.dumps({'status':report['status'],'manifest':report['manifest_sha256']}),flush=True)
