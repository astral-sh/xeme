"""Validate the built local Ohm bundle and two existing C integration consumers."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time
O=Path('/tmp/oriole-pbs-pgo-bundle-local-attempt01')
W=Path('/home/dev-user/code/oss/oriole-pbs-pgo-bundle')
D=O/'local-validation';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert __debug__ and os.sched_getaffinity(0)=={3}
launch=json.loads(Path('/tmp/oriole-pbs-pgo-bundle-local-attempt01-launch.json').read_text());assert launch['status']=='passed' and launch['source_unchanged'] and launch['tools_unchanged']
assert sha(O/'manifest.json')==launch['manifest_sha256']
manifest=json.loads((O/'manifest.json').read_text());pgo=manifest['pgo']['manifest'];run=Path(pgo['run'])
assert pgo['status']=='passed' and pgo['toolchain']=='ohm' and pgo['cargo_args']==['-Zohm-defaults=no']
assert pgo['base_rustflags']==['-C','relocation-model=pic','-C','panic=unwind'] and pgo['host']=='x86_64-unknown-linux-gnu'
assert sha(run/'manifest.json')==manifest['pgo']['manifest_sha256']
assert all(sha(O/p)==v for p,v in manifest['files'].items())
assert sha(O/'libexpat.a')==sha(run/'use/liboriole_expat.a')==pgo['libraries_sha256']['use/liboriole_expat.a']
assert sha(run/'use/liboriole_expat.so')==pgo['libraries_sha256']['use/liboriole_expat.so']
assert (O/'libexpat.a').read_bytes().startswith(b'!<arch>\n')
assert all(sha(W/p)==v for p,v in launch['source_before'].items())
commands={c['label']:c for c in pgo['commands']};use_log=run/commands['build-use']['log'];assert sha(use_log)==commands['build-use']['log_sha256']
assert commands['build-use']['argv'][-2:]==['--','--print=native-static-libs']
assert commands['build-generate']['argv'][-1]=='--verbose'
matches=re.findall(r'native-static-libs:\s*([^\n]+)',use_log.read_text());assert matches
native=matches[-1].split();assert native==pgo['native_static_libraries']==(O/'native-static-libs.txt').read_text().split()
assert all(re.fullmatch(r'-l[A-Za-z0-9_]+',arg) for arg in native)
assert f"Libs.private: {' '.join(native)}\n" in (O/'expat.pc').read_text()
reports={phase:json.loads((run/f'{phase}-training.json').read_text()) for phase in ('generate','use')}
for phase,r in reports.items():
    assert sha(run/f'{phase}-training.json')==pgo['training_sha256'][phase]
    assert r['status']=='passed' and len(r['rows'])==288
    assert r['xml_parse_origin']=={'path':str(run/phase/'liboriole_expat.so'),'sha256':sha(run/phase/'liboriole_expat.so')}
assert reports['generate']['rows']==reports['use']['rows']
D.mkdir(exist_ok=False)
env=os.environ.copy()
for key in ['LD_PRELOAD','LD_LIBRARY_PATH','DYLD_INSERT_LIBRARIES']:env.pop(key,None)
report={'status':'incomplete','role':'Collector-owned local Ohm artifact/C-consumer validation; no installed PBS or stable-toolchain result implied.','source_review_sha256':launch['review_sha256'],'bundle_manifest_sha256':sha(O/'manifest.json'),'pgo_manifest_sha256':sha(run/'manifest.json'),'archive_identity':{'bundle':sha(O/'libexpat.a'),'use':sha(run/'use/liboriole_expat.a'),'exact':True},'native_static_libraries':native,'generated_rows_each_phase':288,'generated_rows_equal':True,'commands':[],'consumers':[],'source_before':launch['source_before']}
def save():(D/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def command(label,argv,timeout):
    log=D/(label+'.log');row={'label':label,'argv':argv,'timeout_seconds':timeout,'cpu':3,'cwd':str(W),'start':time.time(),'log':str(log)};report['commands'].append(row);save();process=None
    with log.open('wb') as stream:
        try:
            process=subprocess.Popen(argv,cwd=W,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
            row['returncode']=process.wait(timeout=timeout)
            if row['returncode']:raise RuntimeError(label+' failed')
        except BaseException as e:
            row['failure']=repr(e)
            if process is not None:
                try:os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:pass
                row['returncode']=process.wait()
            raise
        finally:stream.flush();row['end']=time.time();row['log_sha256']=sha(log);save()
    print(label,row['returncode'],flush=True);return log.read_text()
try:
    archive_members=command('archive-members',['ar','t',str(O/'libexpat.a')],30).splitlines();assert archive_members
    report['archive_members']=len(archive_members)
    symbols=command('weak-tls',['nm','--undefined-only','--format=posix',str(O/'libexpat.a')],30)
    refs=[line.split() for line in symbols.splitlines() if line.split() and line.split()[0]=='__cxa_thread_atexit_impl']
    assert refs and all(fields[1] in ('w','v') for fields in refs);report['weak_tls_references']=refs;save()
    source=W/'tests/c/integration.c';report['integration_source_sha256']=sha(source)
    for label,library in [('shared',run/'use/liboriole_expat.so'),('static',O/'libexpat.a')]:
        exe=D/('consumer-'+label)
        args=['/usr/bin/cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-I'+str(O),str(source),str(library)]
        args += ['-Wl,-rpath,'+str(library.parent)] if label=='shared' else native
        args += ['-o',str(exe)]
        command(label+'-compile',args,60)
        loaded=command(label+'-linkage',['ldd',str(exe)],10)
        if label=='shared':
            origins=[]
            for line in loaded.splitlines():
                fields=line.split();p=fields[2] if len(fields)>2 and fields[1]=='=>' else fields[0] if fields else ''
                if p.startswith('/') and Path(p).resolve()==library.resolve():origins.append(p)
            assert len(origins)==1
        else:assert 'liboriole_expat' not in loaded and 'libexpat.so' not in loaded
        output=command(label+'-run',[str(exe)],10)
        assert output=='C ABI full integration passed (oriole_compat_2.8.4)\n'
        report['consumers'].append({'linkage':label,'library':str(library),'library_sha256':sha(library),'executable_sha256':sha(exe),'status':'passed'});save()
    assert len(report['consumers'])==2
    report['status']='passed'
except BaseException as e:report['failure']=repr(e);raise
finally:
    report['source_unchanged']=all(sha(W/p)==v for p,v in report['source_before'].items())
    report['bundle_payload_unchanged']=all(sha(O/p)==v for p,v in manifest['files'].items())
    report['manifest_unchanged']=sha(O/'manifest.json')==report['bundle_manifest_sha256'];save()
assert report['source_unchanged'] and report['bundle_payload_unchanged'] and report['manifest_unchanged']
print(json.dumps({'status':report['status'],'report_sha256':sha(D/'report.json')}),flush=True)
