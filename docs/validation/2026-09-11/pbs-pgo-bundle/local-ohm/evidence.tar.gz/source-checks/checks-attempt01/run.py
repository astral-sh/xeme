import hashlib
import json
import os
import pathlib
import subprocess
import time

root = pathlib.Path('/home/dev-user/code/oss/oriole-pbs-pgo-bundle')
out = pathlib.Path(__file__).resolve().parent
paths = ['.github/workflows/ci.yml', 'integration/python-build-standalone/README.md', 'integration/python-build-standalone/prepare.py', 'integration/python-build-standalone/pgo_bundle.py', 'integration/python-build-standalone/test_pgo_bundle.py', 'tools/pgo/README.md', 'tools/pgo/build.py', 'tools/pgo/test_build.py']
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def snapshot(name):
    files = {p: digest(root / p) for p in paths}
    (out / (name + '.json')).write_text(json.dumps(files, indent=2) + '\n')
    (out / (name + '.patch')).write_bytes(subprocess.check_output(['git', 'diff', 'HEAD'], cwd=root))
    for p in paths:
        if p.endswith(('pgo_bundle.py', 'test_pgo_bundle.py')):
            (out / (name + '-' + pathlib.Path(p).name)).write_bytes((root / p).read_bytes())
snapshot('before')
ruff = ['/home/dev-user/.virtualenvs/openai/bin/uvx', '--offline', '--from', 'ruff==0.16.6', 'ruff']
ty = ['/home/dev-user/.virtualenvs/openai/bin/uvx', '--offline', '--from', 'ty==0.0.80', 'ty']
pys = [p for p in paths if p.endswith('.py')]
commands = [
    ('ruff-version', [*ruff, '--version']),
    ('ty-version', [*ty, '--version']),
    ('format', [*ruff, 'format', *pys]),
    ('pgo-tests', ['/usr/bin/python3', '-E', '-S', '-B', '-m', 'unittest', 'discover', '-s', 'tools/pgo', '-p', 'test_build.py']),
    ('bundle-tests', ['/usr/bin/python3', '-E', '-S', '-B', '-m', 'unittest', 'discover', '-s', 'integration/python-build-standalone', '-p', 'test_pgo_bundle.py']),
    ('ruff-check', [*ruff, 'check', 'tools/pgo', 'integration/python-build-standalone']),
    ('ty-check', [*ty, 'check', '--extra-search-path', 'tools', 'tools/pgo', 'integration/python-build-standalone']),
    ('format-check', [*ruff, 'format', '--check', *pys]),
    ('diff-check', ['git', 'diff', '--check']),
]
results = []
for label, argv in commands:
    start = time.time()
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    process = subprocess.run(['taskset', '-c', '6', 'nice', '-n', '19', *argv], cwd=root, env=env, capture_output=True, timeout=180)
    stdout, stderr = out / (label + '.stdout'), out / (label + '.stderr')
    stdout.write_bytes(process.stdout)
    stderr.write_bytes(process.stderr)
    results.append({'label': label, 'argv': argv, 'cpu': 6, 'returncode': process.returncode, 'seconds': time.time() - start, 'stdout_sha256': digest(stdout), 'stderr_sha256': digest(stderr)})
    (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(label, process.returncode, flush=True)
    if process.returncode:
        print(process.stdout.decode() + process.stderr.decode(), flush=True)
        break
snapshot('after')
raise SystemExit(results[-1]['returncode'])
