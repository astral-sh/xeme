"""Independent saved archive/freeze audit. Does not execute producer code."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import tarfile

assert os.sched_getaffinity(0) == {4}
O = Path(__file__).parent
R = Path('/tmp/oriole-current-thin-pgo-gates')
P = Path('/tmp/oriole-current-thin-pgo-gates-handoff')
checked, members, nested = {}, {}, {}
checks = 0
def ck(value, label):
    global checks
    assert value, label
    checks += 1
def digest(b):
    return hashlib.sha256(b).hexdigest()
def read(p):
    p = Path(p)
    b = p.read_bytes()
    h = digest(b)
    ck(str(p) not in checked or checked[str(p)] == h, ('stable', str(p)))
    checked[str(p)] = h
    return b
def load(p):
    return json.loads(read(p))
def dump(p, value):
    p.write_text(json.dumps(value, indent=2) + '\n')
def binary(b):
    return b.startswith(b'\x7fELF') or b.startswith(b'!<arch>\n')
def safe(m):
    return m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts

raw_review = load(O/'review.json')
ck(digest(read(O/'review.json')) == '57db9323050ba4910ff46fbc8c7321e2430b03bfeac00f7675bc380ca9b91e63', 'raw review pin')
ck(raw_review['status'] == 'passed', 'raw review passed')
raw_map = json.loads(gzip.decompress(read(O/'checked-files.json.gz')))
for p, h in raw_map.items():
    ck(digest(read(p)) == h, ('raw-audited origin unchanged', p))
freeze = load(R/'freeze.json')
ck(digest(read(R/'freeze.json')) == '213ca9c1e8e57351b4fca7131ab9bd76843379bec00aade9f6d364e203171501', 'freeze pin')
ck(freeze['status'] == 'frozen' and freeze['file_count'] == len(freeze['files_sha256']) == 240, 'freeze counts')
for n, h in freeze['files_sha256'].items():
    ck(digest(read(R/n)) == h, ('freeze file', n))
actual = {p.relative_to(R).as_posix() for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
ck(actual == set(freeze['files_sha256']) | {'freeze.json'}, 'complete current study inventory')

handoff = load(P/'handoff.json')
ck(digest(read(P/'handoff.json')) == '2e9f3ffecafbec4f072b041430b48441fba78c88cc9c8666f1544947341dcfa8', 'handoff pin')
for n, key in [('report.json','report_sha256'), ('readback.json','readback_sha256'), ('README.md','readme_sha256')]:
    ck(digest(read(P/n)) == handoff[key], ('outer link', n))
report, rb = load(P/'report.json'), load(P/'readback.json')
archive_bytes = read(P/'evidence.tar.gz')
archive = {'file':'evidence.tar.gz', 'sha256':digest(archive_bytes), 'bytes':len(archive_bytes), 'members':233}
ck(archive['sha256'] == 'a67f40ec001486921627ae7142ba342448990d72509ccf9c62a6e8bd4af85168', 'archive pin')
ck(archive == handoff['archive'] == report['archive'] == rb['archive'], 'archive records exact')
with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as t:
    entries = t.getmembers()
    ck(len(entries) == len({m.name for m in entries}) == 233, 'archive unique complete count')
    for m in entries:
        ck(safe(m), ('safe regular member',m.name))
        b = t.extractfile(m).read()
        ck(not binary(b), ('direct binary absent',m.name))
        members[m.name] = {'sha256':digest(b), 'bytes':len(b)}
    manifest = json.load(t.extractfile('packaging/manifest.json'))
    ck(set(members) == set(manifest['files']) | {'packaging/manifest.json'}, 'manifest member coverage')
    ck(members['packaging/manifest.json']['sha256'] == report['detailed_manifest_sha256'], 'manifest outer hash')
    for n, rec in manifest['files'].items():
        b = read(rec['path'])
        ck(members[n] == {'sha256':rec['sha256'], 'bytes':rec['bytes']} == {'sha256':digest(b), 'bytes':len(b)}, ('member-origin',n))
    excluded = manifest['excluded_binaries']
    ck(len(excluded) == report['excluded_binary_count'] == rb['excluded_binary_count'] == 10, 'exclusion count')
    for rec in excluded:
        b = read(rec['original_path'])
        ck(binary(b) and digest(b) == rec['sha256'] and len(b) == rec['bytes'], ('excluded binary hash',rec['member']))
        ck(rec['member'] not in members, ('excluded absent',rec['member']))
    included_names = {n.removeprefix('gates/') for n in manifest['files'] if n.startswith('gates/')}
    excluded_names = {r['member'].removeprefix('gates/') for r in excluded}
    ck(not included_names & excluded_names and included_names | excluded_names == actual, 'entire study included or hashed exclusion')
    source = load(R/'source.json')
    for n in members:
        if not n.endswith('.tar.gz'):
            continue
        inner_map = {}
        with tarfile.open(fileobj=io.BytesIO(t.extractfile(n).read()), mode='r:gz') as inner:
            for m in inner.getmembers():
                ck(safe(m) and m.name not in inner_map, ('safe unique nested',n,m.name))
                b = inner.extractfile(m).read()
                ck(not binary(b), ('nested binary absent',m.name))
                inner_map[m.name] = digest(b)
        nested[n] = inner_map
    ck(set(nested) == {'gates/source.tar.gz'}, 'one nested source archive')
    ck(nested['gates/source.tar.gz'] == source['source_sha256'] and len(source['source_sha256']) == 70, 'nested source70 manifest exact')
    ck(rb['nested_archives'] == {n:{'members':len(v),'canonical_member_map_sha256':digest(json.dumps(v,sort_keys=True).encode())} for n,v in nested.items()}, 'nested recorded maps')
    ck(members['packaging/generator.py']['sha256'] == rb['generator_sha256'], 'packager identity')

ck(report['summary'] == load(R/'summary.json'), 'report exact summary copy')
ck(report['summary_sha256'] == freeze['summary_sha256'] == digest(read(R/'summary.json')), 'summary links')
ck(report['freeze_sha256'] == digest(read(R/'freeze.json')), 'report freeze link')
ck(freeze['source_manifest_sha256'] == digest(read(R/'source.json')) == raw_review['source_manifest_sha256'], 'source links')
completion = load(R/'completion.json')
for lane in ['api','other','end']:
    rec = load(R/f'{lane}-controller.json')
    ck(completion['lanes'][lane] == {'sha256':digest(read(R/f'{lane}-controller.json')), 'status':rec['status'], 'unchanged':rec['unchanged']}, ('completion lane',lane))
ck(completion['status'] == 'completed' and completion['cpu'] == 1 and completion['original_api_exit'] == 1 and completion['original_api_failures'] == 393, 'completion scope')
ck(completion['source_manifest_sha256'] == freeze['source_manifest_sha256'] and completion['summary_sha256'] == freeze['summary_sha256'], 'completion pins')
ck(completion['generator_sha256'] == rb['generator_sha256'], 'completion producer generator')
ck(all(x == 0 for x in completion['tool_session_exits'].values()), 'author-recorded session exits')
ck(digest(read(Path(report['first_handoff']['path'])/'evidence.tar.gz')) == report['first_handoff']['archive_sha256'], 'earlier build handoff archive link only')
for p,h in list(checked.items()):
    ck(digest(Path(p).read_bytes()) == h, ('final stable',p))
(O/'package-hash-maps.json.gz').write_bytes(gzip.compress(json.dumps({'checked_files':checked,'members':members,'nested':nested},sort_keys=True).encode(),mtime=0))
result = {
    'status':'passed', 'scope':'Saved freeze, package, member/origin and nested source readback only; no target execution or repeated raw arithmetic.',
    'raw_review_sha256':digest(read(O/'review.json')), 'freeze_sha256':digest(read(R/'freeze.json')), 'handoff_sha256':digest(read(P/'handoff.json')),
    'archive':archive, 'frozen_study_files':240, 'direct_members':233, 'nested_source_members':70, 'excluded_binary_files':10,
    'all_member_origins_and_current_source_hashes_exact':True, 'raw_audited_inputs_rehashed':len(raw_map),
    'checked_files':len(checked), 'passed_checks':checks,
    'limitations':['Binary exclusion is a direct-file filter. The one nested source archive was independently inspected and contains no ELF/ar members.', 'Author tool-session completion is linked to saved lane reports; historical scheduling is not independently observed.', 'The package preserves raw-gate limitations, source identities and CPU1 overlap disclosure. Earlier build handoff is hash-linked only in this package check.'],
    'generator_sha256':digest(Path(__file__).read_bytes())}
dump(O/'package-review.json',result)
print(json.dumps({'status':'passed','review_sha256':digest((O/'package-review.json').read_bytes()),'checks':checks,'checked_files':len(checked)}))
