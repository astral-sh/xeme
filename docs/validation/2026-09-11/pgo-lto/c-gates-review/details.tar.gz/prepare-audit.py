from pathlib import Path
import difflib,hashlib,json
O=Path(__file__).parent;prior=Path('/tmp/oriole-native-byte-count-gates-independent-review/generator.py');old=prior.read_text()
head=old[:old.index('\nS=L;prior_root=')]
head=head.replace("R = Path('/tmp/oriole-native-byte-count-gates')","R = Path('/tmp/oriole-current-thin-pgo-gates')").replace("W = Path('/home/dev-user/code/oss/oriole-native-byte-count')","W = Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')").replace("L = Path('/tmp/oriole-native-byte-count-thinlto-study')","L = Path('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use')").replace("B = Path('/tmp/oriole-end-frame-cells-thinlto-study')","B = Path('/tmp/oriole-native-byte-count-thinlto-study')")
head=head.replace('checks = []','passed_checks = 0').replace("    checks.append({'name': name, 'passed': bool(condition)})\n    assert condition, name","    global passed_checks\n    assert condition, name\n    passed_checks += 1")
core=old[old.index("A=R/'api-native'"):old.index('\nOLD=prior_root')]
start=old.index("LC=R/'end-lifecycle-final'");end=old.index("initial_summary=j(",start);endcore=old[start:end]
endcore=endcore.replace("OLD/'end-lifecycle'","OLD/'end-lifecycle-final'").replace("OLD/'end-lifecycle/comparison.json'","OLD/'end-lifecycle-final/comparison.json'")
new=head+(O/'setup.py').read_text()+core+"\nOLD=prior_root\ngate={'source':{'direct_control_shared_sha256':normal_libraries['liboriole_expat.so']},'libraries':expected_libraries}\n"+endcore+(O/'tail.py').read_text()
(O/'generator.py').write_text(new)
(O/'core-adaptation.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(prior),tofile='thin-pgo-gates-independent-generator')))
(O/'method.json').write_text(json.dumps({'prior_generator':str(prior),'prior_generator_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'generator_sha256':hashlib.sha256(new.encode()).hexdigest(),'method':'Reuse exact complete prior saved API/native/strict/alias/malformed/publication core and End core. Only outer identities/preparation and successful-first-run lineage change; End historical paths point at prior final corrected records. Assertions count without a giant array.'},indent=2)+'\n')
