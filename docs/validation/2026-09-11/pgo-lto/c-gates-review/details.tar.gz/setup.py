S=Path('/tmp/oriole-native-byte-count-pgo-study');prior_root=Path('/tmp/oriole-native-byte-count-gates')
source=j(R/'source.json');preparation=j(R/'preparation.json');build=j(R/'build.json');summary=j(R/'summary.json')
reviews={'/tmp/oriole-native-byte-count-gates-independent-review/review.json':'7d88712eb34eec26f9612bffe611aabdb5079ae5e5e269db5e5ada2e1145f619','/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json':'cec78c70730e111f139a6fab70089e1629ffe3336843106585a35922a525bbc9','/tmp/oriole-native-byte-count-pgo-training-independent-review/review.json':'9e7a8451c1429ea888904ae16ba6c120e0a86ec4e4695a72bfe7dce5ff9e0934'}
for path,value in reviews.items():ck('sealed prerequisite '+path,h(path)==value)
ck('summary pinned',h(R/'summary.json')=='c71e4f8ddad65ff4999bc6072c1208b65914c1f927237e12788a45ed9adf26a1')
ck('approved preparation pinned',h(R/'preparation.json')=='f37245226478f0cb0b7e7478494b08de465bea2f92d68c8fb918948ba506b2e6' and h(R/'controller.patch')=='52100c26841502060411a902c1969c4aa1ac395aa9156942e654df17346b7a30')
ck('source70 current exact',len(source['source_sha256'])==70 and h(R/'source.json')==h(S/'source.json')==build['source_manifest_sha256']=='d1e021143e45331358ea63dcb20663e80d808fc7cee87510dc59e076b803451f')
ck('runtime unchanged from PR116 source',source['source_sha256']==j(B/'source.json')['source_sha256'] and summary['source']['changed_files_from_control']==preparation['source_runtime_delta']==[] and read(R/'runtime-source.patch')==b'')
ck('all70 live source hashes',all(h(W/n)==v for n,v in source['source_sha256'].items()))
for p in [R/'source.tar.gz',S/'source.tar.gz']:
 with tarfile.open(fileobj=io.BytesIO(read(p)),mode='r:gz') as a:
  ms=a.getmembers();ck('archive70 exact '+str(p),len(ms)==len({m.name for m in ms})==70 and all(m.isfile() for m in ms) and {m.name:hashlib.sha256(a.extractfile(m).read()).hexdigest() for m in ms}==source['source_sha256'])
expected_libraries={'liboriole_expat.so':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','liboriole_expat.a':'8b6ca03e6fd4be81aba81cccf10b4aa2d67e16586010477cba1e8f23a4dec97d'}
normal_libraries={'liboriole_expat.so':'ccfb22956a11c1b241ec755f46245c61f088187ef93143b77a7afec748983821','liboriole_expat.a':'f58d5bc6ed28077933fcbcb84ad876cc7208e0102c9008347223da91a328b03c'}
ck('current build alias exact',read(R/'build.json')==read(S/'pair-report.json') and build['status']=='passed' and build['source_unchanged'] and {n:build['pgo_libraries']['use/'+n] for n in expected_libraries}==expected_libraries)
for root,mapping in [(L,expected_libraries),(B,normal_libraries)]:ck('current libraries '+str(root),all(h(root/n)==v for n,v in mapping.items()))
ck('82 prepared inputs unchanged',len(preparation['before'])==82 and hashes(preparation['before']))
repls=[(str(prior_root),str(R)),(str(B),str(L)),('/tmp/oriole-end-frame-cells-thinlto-study',str(B)),('/tmp/oriole-end-frame-cells-thinlto-gates/api-native/upstream-api',str(prior_root/'api-native/upstream-api')),('/home/dev-user/code/oss/oriole-native-byte-count',str(W)),('02fcab59f6e3818c128da6706d67987ae7450dd8b59e97cd28ce497a547f28f5',normal_libraries['liboriole_expat.so']),(normal_libraries['liboriole_expat.so'],expected_libraries['liboriole_expat.so'])]
ck('seven declared identity substitutions',preparation['replacements']==[list(x) for x in repls])
def adapt(value):
 for i,(a,b) in enumerate(repls):value=value.replace(a,'__PGO_AUDIT_'+str(i)+'__')
 for i,(a,b) in enumerate(repls):value=value.replace('__PGO_AUDIT_'+str(i)+'__',b)
 return value
deltas=j(R/'controller-deltas.json')
expected_controllers=['api_native.py','other_controls.py','publication_probe.py','run_publication.py','prepare_malformed.py','run_malformed.py','classify_observations.py','end-lifecycle-final/oracle.py','end-lifecycle-final/controller.py','end-lifecycle-final/SOURCE_REVIEW.md','end-oom-final/run.py','run_lane.py','run_remaining.py']
ck('13 inherited final controllers',list(preparation['controllers'])==list(deltas)==expected_controllers)
for name,value in preparation['controllers'].items():
 original=read(prior_root/name).decode();current=read(R/name).decode();adapted=adapt(original)
 if name=='run_lane.py':
  old="'other':['other_controls.py','run_publication.py','run_malformed.py','end-lifecycle/controller.py','end-oom-final/run.py']";new="'other':['other_controls.py','run_publication.py','run_malformed.py','classify_observations.py']"
  ck('single declared final lane correction',adapted.count(old)==1);adapted=adapted.replace(old,new)
 ck('original and current controller pins '+name,h(prior_root/name)==preparation['prior_controllers'][str(prior_root/name)] and h(R/name)==value)
 ck('only declared substitutions and final lane selection '+name,adapted==current)
 ck('exact retained controller delta '+name,deltas[name]==''.join(difflib.unified_diff(original.splitlines(True),current.splitlines(True),fromfile=str(prior_root/name),tofile=str(R/name))))
ck('complete combined controller patch',read(R/'controller.patch')==''.join(deltas.values()).encode())
ck('same xml ABI helper',read(R/'tools/xml_abi.py')==read(prior_root/'tools/xml_abi.py'))
for name in ['probe.c','original-allocations.c','expat.h']:ck('original OOM assertions '+name,read(R/'end-oom-final'/name)==read(prior_root/'end-oom-final'/name))
for lane,names in [('api',['api_native.py']),('other',['other_controls.py','run_publication.py','run_malformed.py','classify_observations.py']),('end',['end-lifecycle-final/controller.py','end-oom-final/run.py'])]:
 report=j(R/(lane+'-controller.json'))
 ck('successful lane and stable inputs '+lane,report['status']=='completed_zero_exits' and report['unchanged'] and report['before']==report['after']==preparation['before'] and not report['hash_errors'] and report['cpu']==1 and [r['script'] for r in report['jobs']]==names)
 for row in report['jobs']:
  ck('bounded successful first launch '+row['script'],row['exit']==0 and row['timeout']==660 and 'exception' not in row and row['command']==['taskset','-c','1','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S',str(R/row['script'])] and h(R/row['script'])==row['sha256'] and 0<row['end']-row['start']<660)
  for stream in ['stdout','stderr']:ck('lane stream '+row['script']+stream,h(R/(row['script'].replace('/','-')+'.'+stream))==row[stream+'_sha256'])
  ck('empty child stderr '+row['script'],read(R/(row['script'].replace('/','-')+'.stderr'))==b'')
 ck('sequential jobs within lane '+lane,all(a['end']<=b['start'] for a,b in zip(report['jobs'],report['jobs'][1:])))
ck('historical failures absent in this first-success phase',not (R/'end-lifecycle').exists() and not (R/'summary-initial-attempt').exists() and 'prior_harness_corrections' in summary)
ck('malformed preparation helper exact',adapt(read(prior_root/'malformed/malformed_probe.py').decode())==read(R/'malformed/malformed_probe.py').decode())
for name in ['prepare.py','summary-adaptation.json','summary-adaptation.patch','summarize.py','summary.log','api-lane.log','other-lane.log','end-lane.log','prepare-malformed.stdout','prepare-malformed.stderr']:h(R/name)
