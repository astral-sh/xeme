"""Prepare corrected PR116 C/adversarial gates for the measured ThinPGO library."""
from pathlib import Path
import difflib,hashlib,json,os,shutil,subprocess
assert os.sched_getaffinity(0)=={1}
R=Path(__file__).parent;OLD=Path('/tmp/oriole-native-byte-count-gates');W=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo');P=Path('/tmp/oriole-native-byte-count-pgo-study');B=Path('/tmp/oriole-native-byte-count-thinlto-study')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
build=j(P/'pair-report.json');source=j(P/'source.json');L=Path(build['pgo_manifest']['path']).parent/'use'
assert build['status']=='passed' and len(source['source_sha256'])==70 and all(sha(W/n)==h for n,h in source['source_sha256'].items())
assert source['source_sha256']==j(B/'source.json')['source_sha256']
expected={'candidate_shared':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','candidate_static':'8b6ca03e6fd4be81aba81cccf10b4aa2d67e16586010477cba1e8f23a4dec97d','baseline_shared':'ccfb22956a11c1b241ec755f46245c61f088187ef93143b77a7afec748983821','baseline_static':'f58d5bc6ed28077933fcbcb84ad876cc7208e0102c9008347223da91a328b03c'}
for label,folder in [('candidate',L),('baseline',B)]:
 for suffix,kind in [('so','shared'),('a','static')]:assert sha(folder/('liboriole_expat.'+suffix))==expected[label+'_'+kind]
for n in ['source.json','source.tar.gz']:shutil.copyfile(P/n,R/n)
shutil.copyfile(P/'pair-report.json',R/'build.json');(R/'runtime-source.patch').write_text('')
(R/'tools').mkdir();shutil.copyfile(W/'tools/xml_abi.py',R/'tools/xml_abi.py');assert sha(R/'tools/xml_abi.py')==sha(OLD/'tools/xml_abi.py')
changes=[(str(OLD),str(R)),(str(B),str(L)),('/tmp/oriole-end-frame-cells-thinlto-study',str(B)),('/tmp/oriole-end-frame-cells-thinlto-gates/api-native/upstream-api',str(OLD/'api-native/upstream-api')),('/home/dev-user/code/oss/oriole-native-byte-count',str(W)),('02fcab59f6e3818c128da6706d67987ae7450dd8b59e97cd28ce497a547f28f5',expected['baseline_shared']),('ccfb22956a11c1b241ec755f46245c61f088187ef93143b77a7afec748983821',expected['candidate_shared'])]
names=['api_native.py','other_controls.py','publication_probe.py','run_publication.py','prepare_malformed.py','run_malformed.py','classify_observations.py','end-lifecycle-final/oracle.py','end-lifecycle-final/controller.py','end-lifecycle-final/SOURCE_REVIEW.md','end-oom-final/run.py','run_lane.py','run_remaining.py']
deltas={};before_controllers={}
for n in names:
 a=(OLD/n).read_text();b=a
 for i,(x,y) in enumerate(changes):b=b.replace(x,'__THIN_PGO_'+str(i)+'__')
 for i,(x,y) in enumerate(changes):b=b.replace('__THIN_PGO_'+str(i)+'__',y)
 if n=='run_lane.py':
  old="'other':['other_controls.py','run_publication.py','run_malformed.py','end-lifecycle/controller.py','end-oom-final/run.py']"
  new="'other':['other_controls.py','run_publication.py','run_malformed.py','classify_observations.py']"
  assert b.count(old)==1;b=b.replace(old,new)
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(b)
 if p.suffix=='.py':compile(b,str(p),'exec')
 deltas[n]=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=str(OLD/n),tofile=str(p)));before_controllers[str(OLD/n)]=sha(OLD/n)
for n in ['probe.c','original-allocations.c','expat.h']:shutil.copyfile(OLD/'end-oom-final'/n,R/'end-oom-final'/n)
for n in ['integration.c','adversarial.c','allocations.c']:assert sha(W/'tests/c'/n)==sha(OLD/'api-native/native'/n)
cmd=['taskset','-c','1','python3','-I','-S',str(R/'prepare_malformed.py')];p=subprocess.run(cmd,capture_output=True,text=True,timeout=30);(R/'prepare-malformed.stdout').write_text(p.stdout);(R/'prepare-malformed.stderr').write_text(p.stderr);assert p.returncode==0
tracked=[P/'pair-report.json',P/'source.json',P/'tool-source.json',Path(build['pgo_manifest']['path']),B/'source.json',B/'report.json',L/'liboriole_expat.so',L/'liboriole_expat.a',B/'liboriole_expat.so',B/'liboriole_expat.a',OLD/'api-native/upstream-api/results.json',OLD/'api-native/upstream-api/manifest.json',*[W/n for n in source['source_sha256']]]
assert sha(OLD/'api-native/upstream-api/results.json')=='dcda1affc7cfa69d1e77dd60b7c76360e572e2a7767d6d4ded084ab1575647d5'
(R/'controller.patch').write_text(''.join(deltas.values()));(R/'controller-deltas.json').write_text(json.dumps(deltas,indent=2)+'\n')
r={'status':'prepared_not_executed','before':{str(p):sha(p) for p in tracked},'controllers':{n:sha(R/n) for n in names},'prior_controllers':before_controllers,'replacements':changes,'libraries':expected,'source_runtime_delta':[],'baseline_rationale':'Use the verified PR116 implicit-target ccfb/f58 libraries as behavior baseline and its canonical dcda rows as API baseline, as requested by root. All70 source bytes equal current measured PGO4f/8b6. Performance studies separately use matched explicit-target normal0c8c; no full-gate certification of0c8c is inferred.','scope':'Original4740 at3s/1GiBAS/768MiBRSS/240s and raw failures; sixC sanitizer executions327allocation scenarios perlink; strict3318/custom36456/malformed2392/publication1304/3912/End38+6. No fixture/assertion/limit changes. CPU1 execution remains pending root coordination. No parser execution during this preparation.','corrections_carried_forward':'Use already-corrected end-lifecycle-final CPU1 controller/oracle. Remove earlier failed End launch from other lane; run final End38+6 once in end lane. Schedule existing saved-observation classifier after malformed so its required readback exists. Old failures remain in immutable prior study; no fabricated failure in this fresh phase.','limitations':['C ASan/UBSan only; Rust optimized library uninstrumented, leak checking disabled.','Successful custom alias raw pairs absent from original helper; counts/scripts/commands and differences retained.','Original393 upstream failures and retained reference callback-position differences are not waived.','Fresh strict CPython belongs to root; no workspace/timing claim.']}
(R/'preparation.json').write_text(json.dumps(r,indent=2)+'\n');print('patch',sha(R/'controller.patch'));print('preparation',sha(R/'preparation.json'))
