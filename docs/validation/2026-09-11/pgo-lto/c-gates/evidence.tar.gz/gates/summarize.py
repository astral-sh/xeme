from pathlib import Path
import hashlib,json,gzip,os,re
if not __debug__:raise RuntimeError('Assertions required')
assert os.sched_getaffinity(0)=={1}
R=Path(__file__).parent;S=Path('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use');W=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo');h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();j=lambda p:json.loads(Path(p).read_text())
s=j(R/'source.json')['source_sha256'];assert len(s)==70 and all(h(W/n)==v for n,v in s.items())
build=j(R/'build.json');assert build['status']=='passed' and build['source_unchanged'] and build['scripts_unchanged'] and build['tools_unchanged'] and len(build['pgo_vectors']['use'])==3
assert build['pgo_vectors']['use'][-1]['types']==['cdylib','staticlib'] and 'lto=thin' in build['pgo_vectors']['use'][-1]['codegen']
for lane in ['api','other','end']:
 d=j(R/(lane+'-controller.json'));assert d['status']=='completed_zero_exits' and d['unchanged'] and all(x['exit']==0 for x in d['jobs'])
 for row in d['jobs']:
  pre=R/row['script'].replace('/','-');assert h(R/row['script'])==row['sha256'] and h(Path(str(pre)+'.stdout'))==row['stdout_sha256'] and h(Path(str(pre)+'.stderr'))==row['stderr_sha256']
a=j(R/'api-native/report.json');assert a['status']=='passed' and a['unchanged'] and len(a['commands'])==13;assert a['commands'][0]['exit']==1 and all(x['exit']==0 for x in a['commands'][1:])
api=j(R/'api-native/api-comparison.json');raw=j(R/'api-native/upstream-api/results.json');base=j(Path(api['baseline'])/'results.json');assert raw['results']==base['results'] and len(raw['results'])==4740 and raw['selection_complete'] and raw['library_origin_verified'] and not raw['timed_out'];assert api['all4740rows_exact'] and (api['passed'],api['failed'])==(4347,393)
m=j(R/'api-native/upstream-api/manifest.json');bounds={k:m[k] for k in ['per_test_seconds','per_test_address_space_bytes','per_test_rss_limit_bytes','total_timeout_seconds']};assert list(bounds.values())==[3,1073741824,805306368,240]
for mode in ['dynamic','static']:assert '327 scenarios' in (R/'api-native'/('native-allocations-'+mode+'.stdout')).read_text()
o=j(R/'other-gates/report.json');assert o['status']=='passed' and o['unchanged'];assert o['differential']['cases']==3318 and o['differential']['exact_pass'];assert sum(x['cases'] for x in o['aliases'])==36456 and all(x['differences']==0 for x in o['aliases'])
p=j(R/'publication-probe/report.json');q=j(R/'publication-launch/report.json');assert p['status']==q['status']=='passed' and q['exit']==0 and p['cases']==1304 and p['library_parses']==3912 and not p['candidate_baseline_differences'];assert p['hashes_before']==p['hashes_after'] and not p['hash_errors'];assert sum(map(len,p['origins_before_parses'].values()))==9
mr=j(R/'malformed/readback.json');assert mr['status']=='passed' and mr['paired_rows']==2392 and mr['all_observation_fields_exact']
e=j(R/'end-lifecycle-final/controller.json');assert e['status']=='passed' and e['logical_cases']==38 and e['parser_executions']==114 and e['candidate_vs_baseline_different_cases']==0 and not any(e['invariant_failures'].values())
f=j(R/'end-oom-final/report.json');assert f['status']=='passed' and f['unchanged'] and f['observations_exact']
# Rehash every recorded subprocess output in API/native, aliases, and End OOM reports.
streams=0
for folder in ['api-native','other-gates','end-oom-final']:
 data=j(R/folder/'report.json')
 for row in data['commands']:
  for stream in ['stdout','stderr']:
   assert h(R/folder/(row['label']+'.'+stream))==row[stream+'_sha256'];streams+=1
report={'status':'correctness_parity_gates_passed','source':{'files':70,'manifest_sha256':h(R/'source.json'),'live_unchanged':True,'changed_files_from_control':[n for n,v in s.items() if v!=j(Path('/tmp/oriole-native-byte-count-thinlto-study/source.json'))['source_sha256'][n]]},'libraries':{label:{n:h(folder/n) for n in ['liboriole_expat.so','liboriole_expat.a']} for label,folder in [('baseline',Path('/tmp/oriole-native-byte-count-thinlto-study')),('candidate',S)]},'workspace':'No fresh normal-workspace test claim for this PGO artifact; measured C-only optimized libraries are exercised by these C gates.','api':{'raw_exit':1,'passed':4347,'failed':393,'all4740rows_exact':True,'raw_results_sha256':h(R/'api-native/upstream-api/results.json'),'baseline':api['baseline'],'baseline_sha256':api['baseline_results_sha256'],'bounds':bounds},'native':{'consumers':6,'allocation_scenarios_per_linkage':327,'scope':'C ASan/UBSan only; Rust ThinLTO PGO-use release is not sanitizer-instrumented; leak checking disabled; dynamic and static linkage both exercised.'},'strict_baseline_traces':3318,'custom_alias_baseline_comparisons':36456,'malformed_baseline_comparisons':2392,'publication':{'logical_cases':1304,'parser_executions':3912,'exact_baseline':True,'same_process_origin_checks':9,'retained_reference_position_events':j(R/'publication-probe/reference-classification.json')['retained_reference_position_events']},'end_lifecycle':{k:e[k] for k in ['logical_cases','parser_executions','candidate_vs_baseline_different_cases','expat_vs_baseline_different_cases','invariant_failures']},'end_oom':{k:f[k] for k in ['row_counts','scenarios','failed_indices','success_controls','observations_exact']},'rehash_recorded_subprocess_streams':streams,'limitations':['No timing or speed claim.','Successful custom alias raw pairs are not archived by the unchanged helper; scripts, counts, commands, hashes and difference summaries are retained.','End SOURCE_REVIEW.md describes historical fixture provenance, not current detached End eligibility or a fresh source audit.','End6 namespace-restoration fixtures retain their original scope; they do not establish coverage of every detached End fast path.','Original393 upstream failures and reference callback-position differences remain.','CPython gates are owned by root, outside this artifact.','Normal workspace checks are separately owned and are not claimed by this C-only gate receipt.']}
report['prior_harness_corrections']='Corrected End-final CPU1 guards and existing saved-observation classifier used from first launch; historical failures remain only in prior immutable PR116 evidence.'
report['source']['git_commit']='be22a27'
(R/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));print('summary_sha256',h(R/'summary.json'))
