"""Prepare fixed thin-PGO/fat-PGO/Expat-PGO comparison without running workers."""
from pathlib import Path
import ast,difflib,hashlib,json,shutil
O=Path(__file__).parent;B=Path('/tmp/oriole-raw-len-split-thinlto-timing-study');P=Path('/tmp/oriole-native-byte-count-pgo-study');F=Path('/tmp/oriole-native-byte-count-fat-pgo-study')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
pair=load(P/'pair-report.json');fat=load(F/'report.json');assert pair['status']==fat['status']=='passed'
for root,name in [(P,'pair-freeze.json'),(F,'freeze.json')]:assert all(sha(root/n)==h for n,h in load(root/name)['files_sha256'].items())
thinlib=Path(pair['pgo_manifest']['path']).parent/'use/liboriole_expat.so';fatlib=Path(fat['manifest']['path']).parent/'use/liboriole_expat.so';expatlib=Path('/tmp/oriole-pgo-study/expat-use-liboriole_expat.so')
libraries={'thin_pgo':thinlib,'fat_pgo':fatlib,'expat_pgo':expatlib};expected={'thin_pgo':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','fat_pgo':'d4e911d2a9148e898fe2c7e51056fd7dcf77dc85f91d6a8b1827fb200ed753a6','expat_pgo':'12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'}
assert all(sha(p)==expected[k] for k,p in libraries.items())
ratios=[('fat_pgo','thin_pgo'),('fat_pgo','expat_pgo'),('thin_pgo','expat_pgo')]
original=(B/'native_screen.py').read_text();tree=ast.parse(original);s=original;changes=[]
def change(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b);changes.append([a,b])
change('"""Frozen paired native screen for the raw-length fallback split in a C-only ThinLTO build."""','"""Fixed three-engine thin-PGO/fat-PGO/Expat-PGO native screen."""')
change(str(B),str(O))
for var,value in [('libraries','libraries = {'+',\n             '.join(repr(k)+': Path('+repr(str(p))+')' for k,p in libraries.items())+'}'),('ratios','ratios = '+repr(ratios))]:
 n=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==var for x in n.targets));change(ast.get_source_segment(original,n),value)
protocol=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='protocol' for t in n.targets));oldscope=next(v.value for k,v in zip(protocol.value.keys,protocol.value.values) if isinstance(k,ast.Constant) and k.value=='scope')
change(repr(oldscope),repr('Native C callback comparison on current be22 runtime: fresh generated-only PGO ThinLTO4f1518 and independently trained PGO fat-LTOd4e911, plus verified existing Expat2.8.4 PGO12d33. Same explicit host target/source/compiler for Oriole; fresh profile per LTO mode, no Thin profile reuse for fat. Expat retains GCC13.3 -O3/shared/no-LTO. All six held-out project inputs, both namespace modes,4KiB/64KiB, plus two generated controls at both widths. No application/full-correctness claim; shared host and all conditions/samples retained.'))
reverse=s
for a,b in reversed(changes):reverse=reverse.replace(b,a)
assert reverse==original
nt=ast.parse(s)
for name in ['run','save','digest']:
 get=lambda t:next(x for x in t.body if isinstance(x,ast.FunctionDef) and x.name==name)
 assert ast.dump(get(tree))==ast.dump(get(nt))
for name in ['iterations','conditions']:
 get=lambda t:next(n for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==name for x in n.targets))
 assert ast.dump(get(tree))==ast.dump(get(nt))
getphase=lambda t:next(n for n in t.body if isinstance(n,ast.If) and ast.unparse(n.test)=="phase == 'preflight'")
assert ast.dump(getphase(tree))==ast.dump(getphase(nt))
(O/'native_screen.py').write_text(s);shutil.copyfile(B/'run.py',O/'run.py');(O/'controller.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile=str(B/'native_screen.py'),tofile=str(O/'native_screen.py'))))
r={'status':'passed','stage':'prepared only; no worker execution','changes':changes,'libraries':{k:{'path':str(p),'sha256':sha(p)} for k,p in libraries.items()},'source_manifest_sha256':sha(P/'source.json'),'parent_controller_sha256':sha(B/'native_screen.py'),'controller_sha256':sha(O/'native_screen.py'),'wrapper_sha256':sha(O/'run.py'),'parent_wrapper_sha256':sha(B/'run.py'),'proof':'Five reversible substitutions change only root/libraries/ratios/prose. All worker, condition, iteration, preflight and timing phase AST exact. Wrapper byte-identical root-compatible600/1200 aggregate limits and90worker; group cleanup retained.','counts':{'conditions':28,'pairs':7,'seed':2026091003,'preflights':84,'timed_workers':588,'cohorts':196,'measured_samples':105420,'warmups':588},'build_receipts':{str(p):sha(p) for p in [P/'pair-freeze.json',F/'freeze.json',Path('/tmp/oriole-current-pgo-expat-reuse-independent-review/review.json')]}}
assert r['wrapper_sha256']==r['parent_wrapper_sha256'];(O/'adaptation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'controller':r['controller_sha256'],'patch':sha(O/'controller.patch'),'adaptation':sha(O/'adaptation.json')}))
