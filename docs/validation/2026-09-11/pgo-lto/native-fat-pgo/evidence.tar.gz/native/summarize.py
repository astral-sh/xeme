"""Author reconstruction of every saved native sample/order/ratio; no target execution."""
from pathlib import Path
from collections import Counter
import hashlib,json,math,random,statistics
P=Path(__file__).parent;S=P/'native-screen';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
controller=load(P/'controller.json');assert controller['status']=='passed' and len(controller['commands'])==2
for row,(phase,cpu,timeout) in zip(controller['commands'],[('preflight',5,600),('time',0,1200)],strict=True):
 assert row['phase']==phase and row['exit']==0 and row['timeout']==timeout and 0<row['end']-row['start']<timeout and row['command']==['taskset','-c',str(cpu),'python3',str(P/'native_screen.py'),phase] and row['log_sha256']==sha(P/(phase+'-controller.log'))
p=load(S/'protocol.json');pre=load(S/'preflight.json');r=load(S/'results.json');assert pre['status']==r['status']=='passed'
assert p['pairs']==7 and p['seed']==2026091003 and p['preflights']==84 and p['timed_workers']==588
assert pre['protocol_sha256']==r['protocol_sha256']==sha(S/'protocol.json') and r['preflight_sha256']==sha(S/'preflight.json')
assert p['hashes']==pre['hashes_before']==pre['hashes_after']==r['hashes_before']==r['hashes_after'];assert all(sha(n)==h for n,h in p['hashes'].items())
engines=['thin_pgo','fat_pgo','expat_pgo'];conditions=p['conditions'];assert len(conditions)==28 and len(pre['rows'])==84
key=lambda c:json.dumps(c,sort_keys=True)
ordinal=0;counts=Counter();streams=[];expected={}
def process(row,c,pair,cpu,count):
 global ordinal
 saved=load(S/f'worker-{ordinal:04d}.json');assert set(saved)=={'condition','engine','pair','command','returncode','stdout','stderr'} and saved=={k:row[k] for k in saved}
 assert row['condition']==c and row['pair']==pair and row['returncode']==0 and row['stderr']==''
 engine=row['engine'];assert row['command']==['taskset','-c',str(cpu),'/tmp/oriole-grammar-bench-plain/native-driver',p['libraries'][engine]['path'],c['input'],str(c['chunk']),str(count)]+(['namespaces'] if c['namespaces'] else [])
 data=json.loads(row['stdout']);samples=data['samples'];assert data['version']==('expat_2.8.4' if engine=='expat_pgo' else 'oriole_compat_2.8.4')
 assert len(samples)==count+1 and [s['iteration'] for s in samples]==list(range(count+1)) and [s['warmup'] for s in samples]==[True]+[False]*count
 assert all(math.isfinite(s['seconds']) and s['seconds']>0 for s in samples)
 obs=sorted({(s['hash'],s['elements'],s['text_bytes']) for s in samples});assert len(obs)==1 and row['observations']==[list(x) for x in obs]
 median=statistics.median(s['seconds'] for s in samples[1:]);assert median==row['median_seconds']
 stage='preflight' if pair==-1 else 'timed';counts[stage+'_workers']+=1;counts[stage+'_warmups']+=1;counts[stage+'_measured']+=count
 streams.append({'ordinal':ordinal,'sha256':sha(S/f'worker-{ordinal:04d}.json'),'median_seconds':median,'stdout_sha256':hashlib.sha256(row['stdout'].encode()).hexdigest()});ordinal+=1;return obs,median
for i,c in enumerate(conditions):
 rows=pre['rows'][i*3:i*3+3];assert [x['engine'] for x in rows]==engines
 obs=[process(x,c,-1,5,1)[0] for x in rows];assert obs[0]==obs[1]==obs[2];expected[key(c)]=obs[0]
rng=random.Random(2026091003);jobs=[(c,pair) for c in conditions for pair in range(7)];rng.shuffle(jobs)
assert len(r['rows'])==196 and len({(key(g['condition']),g['pair']) for g in r['rows']})==196
ratio_names=['fat_pgo_over_thin_pgo','fat_pgo_over_expat_pgo','thin_pgo_over_expat_pgo'];ratios={key(c):{k:[] for k in ratio_names} for c in conditions}
for group,(c,pair) in zip(r['rows'],jobs,strict=True):
 order=engines.copy();rng.shuffle(order);assert group['condition']==c and group['pair']==pair and group['order']==order and [x['engine'] for x in group['processes']]==order
 seconds={}
 for row in group['processes']:
  obs,median=process(row,c,pair,0,c['iterations']);assert obs==expected[key(c)];seconds[row['engine']]=median
 for name in ratio_names:
  a,b=name.split('_over_');ratios[key(c)][name].append(seconds[a]/seconds[b])
summary=[{'condition':c,'paired_ratios':ratios[key(c)],'median_ratios':{k:statistics.median(v) for k,v in ratios[key(c)].items()}} for c in conditions];assert summary==r['summary']
assert ordinal==672 and len(list(S.glob('worker-*.json')))==672
assert dict(counts)=={'preflight_workers':84,'preflight_warmups':84,'preflight_measured':84,'timed_workers':588,'timed_warmups':588,'timed_measured':105420}
groups={}
for label,generated in [('real',False),('generated',True)]:
 rows=[x for x in summary if x['condition']['name'].startswith('generated-')==generated]
 groups[label]={'conditions':len(rows),'ratios':{k:{'geomean':math.exp(sum(math.log(x['median_ratios'][k]) for x in rows)/len(rows)),'below_one':sum(x['median_ratios'][k]<1 for x in rows)} for k in ratio_names}}
report={'status':'passed','role':'Source and experiment author reconstructing all saved sample medians, seeded orders, paired ratios and counts. Independent audit remains separate.','groups':groups,'regressions':[{'condition':x['condition'],'ratio':x['median_ratios']['fat_pgo_over_thin_pgo']} for x in summary if x['median_ratios']['fat_pgo_over_thin_pgo']>1],'counts':dict(counts),'cohorts':196,'summary':summary,'source_manifest_sha256':load(P/'adaptation.json')['source_manifest_sha256'],'libraries':p['libraries'],'scope':'Native callbacks; sample timer includes parser creation, handler setup, parse and free, excludes file I/O/library loading. All28 conditions retained. Both Oriole C-only builds use fresh mode-specific PGO, identical explicit target/source/compiler with ThinLTO versus fat LTO; Expat retains its verified original GCC PGO/no-LTO flags. No full application or consumer result, no fresh full compatibility gates and no adoption claim.','generator_sha256':sha(__file__),'input_sha256':{n:sha(S/n) for n in ['protocol.json','preflight.json','results.json']},'controller_sha256':sha(P/'controller.json')}
(P/'streams.json').write_text(json.dumps(streams,indent=2)+'\n');report['streams_sha256']=sha(P/'streams.json');(P/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'groups':groups,'regressions':report['regressions']}))
