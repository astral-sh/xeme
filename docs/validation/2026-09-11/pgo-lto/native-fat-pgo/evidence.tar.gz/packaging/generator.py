"""Package saved PGO evidence only; no compiler, parser, or timing commands."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
dump = lambda p, v: Path(p).write_text(json.dumps(v, indent=2) + "\n")
G = Path('/tmp/oriole-current-thin-pgo-gates')
N = Path('/tmp/oriole-current-pgo-lto-native-study')
FIRST = Path('/tmp/oriole-current-pgo-native-handoff')


def assert_frozen(root, name='freeze.json'):
    for path, digest in load(root / name)['files_sha256'].items():
        assert sha(root / path) == digest, (root, path)


def seal_gates():
    assert sha(G / 'summary.json') == 'c71e4f8ddad65ff4999bc6072c1208b65914c1f927237e12788a45ed9adf26a1'
    # Final saved lane receipts record completion independently of the API score.
    lanes = {}
    for name in ['api', 'other', 'end']:
        p = G / f'{name}-controller.json'
        row = load(p)
        assert row['status'] == 'completed_zero_exits' and row['unchanged']
        lanes[name] = {'sha256': sha(p), 'status': row['status'], 'unchanged': True}
    completion = {
        'status': 'completed',
        'role': 'Study author; independent saved-data review is separate.',
        'summary_sha256': sha(G / 'summary.json'),
        'lanes': lanes,
        'tool_session_exits': {'api_2985': 0, 'other_98547': 0, 'end_98108': 0, 'summary_2511': 0},
        'session_receipt_scope': 'Author records tool completion; saved lane reports and raw logs are archived.',
        'cpu': 1,
        'shared_host': 'Root allocator elapsed jobs on CPU0 and strict CPython gates on CPU4 overlapped these CPU1 gates.',
        'no_new_failed_attempts_or_reruns': True,
        'original_api_exit': 1,
        'original_api_failures': 393,
        'source_manifest_sha256': sha(G / 'source.json'),
        'generator_sha256': sha(__file__),
    }
    assert not (G / 'completion.json').exists()
    dump(G / 'completion.json', completion)
    rows = {p.relative_to(G).as_posix(): sha(p) for p in sorted(G.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
    assert not (G / 'freeze.json').exists()
    dump(G / 'freeze.json', {'status': 'frozen', 'files_sha256': rows, 'file_count': len(rows), 'source_manifest_sha256': sha(G / 'source.json'), 'summary_sha256': sha(G / 'summary.json')})
    print(json.dumps({'gate_freeze_sha256': sha(G / 'freeze.json'), 'files': len(rows)}), flush=True)


def package(out, roots, report, readme):
    out.mkdir(exist_ok=False)
    files, excluded = {}, []
    for prefix, root in roots.items():
        for p in sorted(root.rglob('*')):
            rel = p.relative_to(root)
            if not p.is_file() or any(x in ['__pycache__', 'targets'] for x in rel.parts):
                continue
            name = prefix + '/' + rel.as_posix()
            assert name not in files and not p.is_symlink(), p
            with p.open('rb') as f:
                magic = f.read(8)
            if magic.startswith(b'\x7fELF') or magic == b'!<arch>\n' or p.suffix in ['.a', '.so'] or '.so.' in p.name:
                excluded.append({'member': name, 'original_path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size})
            else:
                files[name] = p
    files['packaging/generator.py'] = Path(__file__)
    manifest = {'status': 'prepared', 'files': {n: {'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size} for n, p in sorted(files.items())}, 'excluded_binaries': excluded}
    archive = out / 'evidence.tar.gz'
    # Store detailed inventory inside the compressed archive, not a plain Git JSON.
    mbytes = (json.dumps(manifest, indent=2) + '\n').encode()
    expected = {n: (v['sha256'], v['bytes']) for n, v in manifest['files'].items()}
    expected['packaging/manifest.json'] = (hashlib.sha256(mbytes).hexdigest(), len(mbytes))
    with tarfile.open(archive, 'w:gz', compresslevel=6) as tf:
        for name in sorted(expected):
            data = mbytes if name == 'packaging/manifest.json' else files[name].read_bytes()
            assert (hashlib.sha256(data).hexdigest(), len(data)) == expected[name]
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            tf.addfile(info, io.BytesIO(data))
    nested = {}
    with tarfile.open(archive, 'r:gz') as tf:
        members = tf.getmembers()
        assert len(members) == len(expected) and len({m.name for m in members}) == len(members)
        for m in members:
            assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
            data = tf.extractfile(m).read()
            assert (hashlib.sha256(data).hexdigest(), len(data)) == expected[m.name]
            if m.name.endswith('.tar.gz'):
                with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as inner:
                    hashes = {}
                    for item in inner.getmembers():
                        assert item.isfile() and item.name not in hashes and not item.name.startswith('/') and '..' not in Path(item.name).parts
                        b = inner.extractfile(item).read()
                        hashes[item.name] = hashlib.sha256(b).hexdigest()
                    nested[m.name] = hashes
                    if m.name == 'gates/source.tar.gz':
                        assert hashes == load(G / 'source.json')['source_sha256']
    assert all(sha(p) == manifest['files'][name]['sha256'] for name, p in files.items())
    archive_row = {'file': 'evidence.tar.gz', 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'members': len(expected)}
    readback = {'status': 'passed', 'archive': archive_row, 'all_outer_member_hashes_verified': True, 'all_original_files_unchanged': True, 'nested_archives': {k: {'members': len(v), 'canonical_member_map_sha256': hashlib.sha256(json.dumps(v, sort_keys=True).encode()).hexdigest()} for k, v in nested.items()}, 'source70_matches_manifest': 'gates/source.tar.gz' in nested, 'excluded_binary_count': len(excluded), 'generator_sha256': sha(__file__)}
    dump(out / 'readback.json', readback)
    report.update({'archive': archive_row, 'readback_sha256': sha(out / 'readback.json'), 'detailed_manifest_member': 'packaging/manifest.json', 'detailed_manifest_sha256': expected['packaging/manifest.json'][0], 'excluded_binary_count': len(excluded), 'first_handoff': {'path': str(FIRST), 'archive_sha256': 'd2a6b5926d33c3037f84087fb0a611202c0e6a186d572d875d0021c3a71c3872', 'scope': 'Complete fresh normal/PGO ThinLTO and fat-LTO build/source/profile/training bytes, historical Expat reuse, and initial five-engine native campaign.'}})
    dump(out / 'report.json', report)
    (out / 'README.md').write_text(readme)
    dump(out / 'handoff.json', {'status': 'sealed', 'archive': archive_row, 'report_sha256': sha(out / 'report.json'), 'readback_sha256': sha(out / 'readback.json'), 'readme_sha256': sha(out / 'README.md'), 'raw_inventory': 'evidence.tar.gz:packaging/manifest.json'})
    print(json.dumps({'path': str(out), 'handoff_sha256': sha(out / 'handoff.json'), 'archive': archive_row, 'report_sha256': sha(out / 'report.json'), 'readback_sha256': sha(out / 'readback.json')}), flush=True)


if __name__ == '__main__':
    assert sha(FIRST / 'evidence.tar.gz') == 'd2a6b5926d33c3037f84087fb0a611202c0e6a186d572d875d0021c3a71c3872'
    seal_gates()
    assert_frozen(G)
    assert_frozen(N)
    n = load(N / 'summary.json')
    package(Path('/tmp/oriole-current-pgo-lto-native-handoff'), {
        'native': N,
        'reviews/native': Path('/tmp/oriole-current-pgo-lto-native-independent-review'),
        'reviews/fat-pgo-build': Path('/tmp/oriole-native-byte-count-fat-pgo-independent-review'),
    }, {
        'status': 'saved_evidence_verified', 'scope': 'Three-engine native lifecycle timings only; separate fresh fat-PGO build review included.',
        'role': 'Study author and packager; independent native and fat-PGO build reviews are archived.',
        'source_manifest_sha256': n['source_manifest_sha256'], 'libraries': n['libraries'], 'counts': n['counts'], 'groups': n['groups'],
        'fat_over_thin_regressions': {'real': 24, 'generated': 2},
        'summary_sha256': sha(N / 'summary.json'), 'freeze_sha256': sha(N / 'freeze.json'),
        'independent_reviews': {'native': '58aa681104408e074836fdb73230f0e2dcdfdbabc06f37483dde33f4572d38c2', 'fat_pgo_build': '46d23adae877d331dfbc198f312e62deebb01efc785e52413d3ce52af65cb63c'},
        'limitations': ['All28 conditions retained; fat-PGO regresses all24 real conditions and both generated entity conditions against ThinPGO.', 'Native lifecycle timings include construction/free and native callbacks; actual Python is a separate root-owned study.', 'Shared host: CPU4 Python extension build/preflight overlapped CPU0 timing.', 'No new full correctness or workspace claim for fat-PGO; ThinPGO C gates are a separate handoff.', 'Historical Expat PGO reuse has explicit-library hashes without retroactive same-process loaded-origin attestation.'],
    }, '# Current PGO: fat versus thin native evidence\n\nFat-PGO took 6.76% longer than ThinPGO across the 24 real native conditions (geometric mean); all 24 regressed. The four generated controls averaged 4.64% longer, with both entity cases regressing and both rare-declaration cases improving.\n\nThe fixed study retained 84 preflights, 588 timed workers, 196 seeded cohorts, and 105,420 measured samples. CPU4 Python preparation overlapped the CPU0 lifecycle timing. No reruns or tuning.\n\n`evidence.tar.gz` contains complete raw records, controllers, all condition results, the independent native audit, and the independent fresh fat-PGO build/training audit. `readback.json` records verification of every archive member. Detailed inventory is compressed inside the archive. Source/build bytes are preserved in the earlier `oriole-current-pgo-native-handoff` archive identified by `report.json`. Actual Python and fresh ThinPGO correctness gates are separate.\n')
    package(Path('/tmp/oriole-current-thin-pgo-gates-handoff'), {'gates': G}, {
        'status': 'correctness_parity_gates_passed', 'role': 'Study author and packager; independent C-gate audit is supplied separately.',
        'summary': load(G / 'summary.json'), 'summary_sha256': sha(G / 'summary.json'), 'freeze_sha256': sha(G / 'freeze.json'),
        'shared_host': 'CPU1 gates overlapped root allocator timing on CPU0 and strict CPython on CPU4.',
    }, '# Current ThinPGO C correctness evidence\n\nThe measured ThinPGO library preserves all 4,740 original API outcomes: 4,347 pass and 393 fail, with original API exit 1 and bounds of 3 seconds/test, 1 GiB address space, 768 MiB RSS, and 240 seconds total.\n\nBoth linkages pass the original C integration, adversarial, and 327-scenario allocation suites. Saved parity checks cover 3,318 strict traces, 36,456 custom-alias comparisons, 2,392 malformed comparisons, 1,304 publication cases (3,912 parses), and the original End38/End6 fixtures. Existing reference callback-position differences remain.\n\nThe baseline is the previously verified PR116 implicit-target library ccfb/f58; the measured candidate is current ThinPGO 4f/8b6. All70 source bytes match. The fresh explicit-target performance control 0c8c is a separate artifact.\n\n`evidence.tar.gz` preserves source, scripts, commands, bounds, raw outputs, summary, and detailed inventory. Executable binaries are excluded with exact hashes retained. All outer and 70 nested source member hashes were read back. Independent C-gate audit is a separate receipt.\n\nLimits: C sanitizer instrumentation excludes the Rust release library; leak checking is disabled. The unchanged custom-alias helper does not retain every successful raw pair. Root owns strict CPython evidence separately. No fresh workspace claim. These CPU1 gates overlapped allocator timing on CPU0 and strict CPython on CPU4. No new failed attempts or reruns.\n')
