# Independent fresh fat-PGO supplement

Passed the first saved-data audit attempt: 1,638 assertions over 193 files. All 40 current frozen files, 52 earlier pair files and nine fat-control files remain exact. All 70 runtime sources and six production PGO tools were rehashed against the sealed source proof.

| Build | No PGO shared SHA prefix | PGO shared SHA prefix |
| --- | --- | --- |
| ThinLTO | `0c8c5875` | `4f1518fc` |
| Fat LTO | `b86bb49a` | `d4e911d2` |

Six fresh workspace compiler calls—three generate and three use—match the fat control after removing only the current phase's profile options and normalizing Cargo artifact suffixes. Compiler, source and output paths, metadata and all other arguments remain exact. The C root produces only shared/static C artifacts with `lto=fat`; its Rust dependencies retain `linker-plugin-lto`.

Both fresh 288-row training reports equal the 288-row fat-control replay. The control rows are reused from its sealed earlier run. All three XML_Parse origin records and all 12 generated fixture bytes/configurations are checked; the earlier pure-corpus reconstruction proof is reused by exact hash.

The fresh run has one distinct raw profile and one distinct merged profile. Saved profile output accounts for 630 functions, 278 with nonzero counters, 17,615 blocks, 838,850,498 total counts and exactly 870,312 XML_Parse entries. The use log passes the strict warning check. No ThinLTO profile is reused.

`review.json` contains the conclusion and links prior proofs. `compiler-comparisons.json` retains all six raw comparisons; `generator.py` and `checked-files.json` retain the audit. No large assertion array is emitted. The reviewer ran only CPU 4 Python file/hash/JSON/text arithmetic. No target, compiler, parser, corpus generator, profiler, training, timing or test job ran. This is a build/profile proof, with no elapsed-performance, broad correctness or adoption claim.
