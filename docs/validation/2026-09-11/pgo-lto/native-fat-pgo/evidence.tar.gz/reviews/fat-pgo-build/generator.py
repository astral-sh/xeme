"""Saved fresh fat-PGO source/compiler/training/profile audit, with sealed reuse."""
from pathlib import Path
import ast,difflib,hashlib,json,math,os,re,shlex
B=Path('/tmp/oriole-native-byte-count-fat-pgo-study');P=B/'pgo/runs/run-xe8qfw8c'
OLD=Path('/tmp/oriole-native-byte-count-pgo-study');OP=OLD/'pgo/runs/run-7_l2jvbd'
F=Path('/tmp/oriole-native-byte-count-fat-lto-study');W=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo');S=W/'tools/pgo';O=Path(__file__).parent
seen={};passed=0
def read(p):
 p=Path(p);b=p.read_bytes();digest=hashlib.sha256(b).hexdigest();assert seen.setdefault(str(p),digest)==digest,str(p);return b
def sha(p):
 p=Path(p)
 with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 assert seen.setdefault(str(p),digest)==digest,str(p)
 return digest
def js(p):return json.loads(read(p))
def ck(name,value):
 global passed
 assert value,name
 passed+=1
def dump(n,v):(O/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def vectors(p):
 rows=[]
 for line in read(p).decode().splitlines():
  match=re.fullmatch(r'\s*Running `(.*)`',line)
  if not match:continue
  args=shlex.split(match[1])
  if '--crate-name' not in args:continue
  crate=args[args.index('--crate-name')+1]
  if crate in ['oriole_storage','oriole','oriole_expat']:rows.append({'crate':crate,'argv':args,'line':line})
 ck('three raw workspace invocations '+str(p),[r['crate'] for r in rows]==['oriole_storage','oriole','oriole_expat'])
 return rows
def normalize(args,phase):
 options=[] if phase=='normal' else ([f'-Cprofile-generate={P}/raw-profiles'] if phase=='generate' else [f'-Cprofile-use={P}/merged.profdata','-Cllvm-args=-pgo-warn-missing-function'])
 ck('exact phase profile options '+phase,args[-len(options):]==options if options else not any('profile-' in x or 'pgo-' in x for x in args))
 ck('no other profile options '+phase,[a for a in args if 'profile-' in a or 'pgo-' in a]==options)
 result=[]
 for i,a in enumerate(args):
  if a in options:continue
  if i and args[i-1]=='-C':a=re.sub(r'^extra-filename=-[a-f0-9]{16}$','extra-filename=-ARTIFACT_HASH',a)
  if i and args[i-1]=='--extern':a=re.sub(r'(?<=-)[a-f0-9]{16}(?=\.(?:rmeta|rlib)$)','ARTIFACT_HASH',a)
  result.append(a)
 return result

ck('CPU4 saved data only',__debug__ and os.sched_getaffinity(0)=={4})
reviews={
 '/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json':'cec78c70730e111f139a6fab70089e1629ffe3336843106585a35922a525bbc9',
 '/tmp/oriole-native-byte-count-pgo-training-independent-review/review.json':'9e7a8451c1429ea888904ae16ba6c120e0a86ec4e4695a72bfe7dce5ff9e0934',
 '/tmp/oriole-native-byte-count-fat-lto-independent-review/review.json':'9b0043f8c1df50652136a956277c11fde5df012498d84f0672e73d1487fa42f0'}
for p,h in reviews.items():ck('sealed review '+p,sha(p)==h)
ck('fresh fat PGO freeze',sha(B/'freeze.json')=='f44f0415c663ddf90c3267f994d5e5d025482b013aa4becce0afff50a1086eb4')
freeze=js(B/'freeze.json');ck('forty frozen files',freeze['status']=='frozen' and len(freeze['files_sha256'])==40)
for n,h in freeze['files_sha256'].items():ck('frozen bytes '+n,sha(B/n)==h)
report=js(B/'report.json');m=js(P/'manifest.json');pair=js(OLD/'pair-report.json');oldm=js(OP/'manifest.json');normal=js(F/'report.json');source=js(OLD/'source.json');scripts=js(OLD/'tool-source.json')
ck('report and inner manifest complete',report['status']==m['status']=='passed' and m['compared_parses']==288)
for root,name,count in [(OLD,'pair-freeze.json',52),(F,'freeze.json',9)]:
 f=js(root/name);ck('prior freeze count '+str(root),len(f['files_sha256'])==count)
 for n,h in f['files_sha256'].items():ck('prior frozen bytes unchanged '+str(root/n),sha(root/n)==h)
ck('normal fat links',report['normal_fat_report_sha256']==sha(F/'report.json') and report['normal_fat_freeze_sha256']==sha(F/'freeze.json'))
ck('source map identity',report['source_manifest_sha256']==sha(OLD/'source.json')=='d1e021143e45331358ea63dcb20663e80d808fc7cee87510dc59e076b803451f' and len(source['source_sha256'])==70)
ck('tool source identity',report['tools_source_manifest_sha256']==sha(OLD/'tool-source.json') and len(scripts)==6)
for n,h in source['source_sha256'].items():ck('live unchanged source '+n,sha(W/n)==h)
for n,h in scripts.items():ck('live unchanged pipeline tool '+n,sha(W/n)==h)
ck('inner source/scripts same earlier pipeline',m['source_sha256']==oldm['source_sha256'] and m['script_sha256']==oldm['script_sha256'])
ck('inner latest links',js(B/'pgo/latest.json')=={'manifest':str(P/'manifest.json'),'sha256':sha(P/'manifest.json')} and report['manifest']=={'path':str(P/'manifest.json'),'sha256':sha(P/'manifest.json')})
ck('new run independent from prior',m['run']==str(P) and P!=OP and m['started_unix']>oldm['completed_unix'] and report['new_raw_profile_directory']==str(P/'raw-profiles'))
ck('same inherited config map',m['cargo_config_sha256']==oldm['cargo_config_sha256'])
for p,h in m['cargo_config_sha256'].items():ck('config current '+p,sha(p)==h)
ck('all tools match prior and before/after',m['tools_sha256']==oldm['tools_sha256'] and report['tools_before']==report['tools_after']==pair['tools_before'] and report['tools_unchanged'] and len(m['tools_sha256'])==9)
for p,h in m['tools_sha256'].items():ck('current tool executable/library '+p,sha(p)==h)
ck('source/tools/prior studies producer guards passed',report['source_tools_and_previous_studies_unchanged'])
ck('no base PGO and explicit global fat config',m['base_rustflags']==[] and m['cargo_args']==['-Zohm-defaults=no','--config=profile.release.lto="fat"'] and m['host']==pair['host']=='x86_64-unknown-linux-gnu' and m['toolchain']=='ohm')
ck('same compiler/profiler versions',m['rustc_version']==oldm['rustc_version'] and m['profdata_version']==oldm['profdata_version'])
ck('outer overrides only output target',report['env_overrides']==pair['env_overrides']|{'CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/native-byte-count-fat-pgo-target'})
outer=report['commands'];ck('one bounded pipeline command',len(outer)==1 and outer[0]['label']=='pgo-pipeline' and outer[0]['cpu']==1 and outer[0]['exit']==0 and outer[0]['timeout']==2400 and outer[0]['cwd']==str(W) and outer[0]['log_sha256']==sha(B/'pgo-pipeline.log'))
expectedouter=pair['commands'][4]['argv'].copy();expectedouter[expectedouter.index(str(OLD/'pgo'))]=str(B/'pgo');expectedouter.insert(expectedouter.index('--command-timeout'),'--cargo-arg=--config=profile.release.lto="fat"')
ck('pipeline argv differs only output/global fat config',outer[0]['argv']==expectedouter)
outercode=read(B/'build_pair.py').decode();oldcode=read(OLD/'build_pair.py').decode()
ck('exact archived outer controller patch',read(B/'controller.patch').decode()==''.join(difflib.unified_diff(oldcode.splitlines(True),outercode.splitlines(True),fromfile=str(OLD/'build_pair.py'),tofile=str(B/'build_pair.py'))))
ck('preparation controller hash',js(B/'preparation.json')['controller_sha256']==sha(B/'build_pair.py'))
ck('outer fresh-output guard',"not (O/'pgo').exists()" in outercode and "env.pop(k,None)" in outercode)
commands={c['label']:c for c in m['commands']}
labels=['rustc-version','cargo-version','rustc-sysroot','profdata-version','build-generate','generate','profile-merge','profile-show','build-use','use']
ck('ten phase commands exact order',[c['label'] for c in m['commands']]==labels and m['cpu_affinity']==[1])
for c in m['commands']:ck('successful bounded phase '+c['label'],c['returncode']==0 and c['status']=='passed' and c['timeout_seconds']==900 and c['cwd']==str(W) and c['log_sha256']==sha(P/c['log']))
basevectors=vectors(F/'fat-build.log');ck('fat control raw vectors match reviewed report',basevectors==normal['workspace_vectors'])
comparisons=[]
for phase in ['generate','use']:
 c=commands['build-'+phase];raw=vectors(P/c['log']);ck('raw producer workspace vector table '+phase,raw==report['workspace_vectors'][phase])
 ck('global fat cargo command '+phase,c['argv'][1:]==normal['commands'][0]['argv'][1:])
 ck('phase target and compiler env '+phase,c['environment']['CARGO_TARGET_DIR']==str(B/'pgo/targets'/phase) and c['environment']['RUSTC']==basevectors[0]['argv'][0])
 for a,b,delta in zip(basevectors,raw,report['normal_fat_deltas'][phase],strict=True):
  ck('all metadata/paths/other arguments preserved '+phase+'/'+a['crate'],a['crate']==b['crate']==delta['crate'] and normalize(a['argv'],'normal')==normalize(b['argv'],phase))
  ck('complete raw delta '+phase+'/'+a['crate'],delta['delta']==list(difflib.unified_diff(a['argv'],b['argv'],n=2)))
  cg=[b['argv'][i+1] if x=='-C' else x[2:] for i,x in enumerate(b['argv']) if x.startswith('-C')]
  types=[b['argv'][i+1] for i,x in enumerate(b['argv'][:-1]) if x=='--crate-type']
  ck('effective C-only fat build '+phase+'/'+a['crate'],'opt-level=3' in cg and 'codegen-units=1' in cg and ('lto=fat' if a['crate']=='oriole_expat' else 'linker-plugin-lto') in cg and types==(['cdylib','staticlib'] if a['crate']=='oriole_expat' else ['lib']))
  comparisons.append({'phase':phase,'crate':a['crate'],'normal':a['argv'],'pgo':b['argv'],'delta':delta['delta']})
ck('four library identities exact',report['libraries']==m['libraries_sha256'] and len(m['libraries_sha256'])==4)
for n,h in m['libraries_sha256'].items():ck('fresh saved library '+n,sha(P/n)==h)
ck('treatment use pinned',m['libraries_sha256']['use/liboriole_expat.so']=='d4e911d2a9148e898fe2c7e51056fd7dcf77dc85f91d6a8b1827fb200ed753a6' and m['libraries_sha256']['use/liboriole_expat.a']=='15ab814c5b2ec247e275dbefac4e5cc25a89c5f2c3558dfc8c8c911c4c89beeb')
inputs=js(P/'inputs/manifest.json')
ck('fresh generated bytes exact prior pure-corpus proof',m['inputs_sha256']==oldm['inputs_sha256'] and len(m['inputs_sha256'])==13 and inputs==js(OP/'inputs/manifest.json'))
for n,h in m['inputs_sha256'].items():ck('generated input byte identity '+n,sha(P/'inputs'/n)==sha(OP/'inputs'/n)==h)
ck('fixed generated design',len(inputs['rows'])==12 and inputs['seed']==0x4F52494F4C45 and inputs['iterations']==2 and inputs['handlers']==['minimal','full'])
expected=[];feeds=0
for f in inputs['rows']:
 data=read(P/'inputs'/f['file'])
 ck('fixture metadata '+f['name'],f['bytes']==len(data) and f['sha256']==hashlib.sha256(data).hexdigest() and f['file']==f['name']+'.xml' and f['chunks']==[1 if f['name']=='latin1' else 17,4096,65536] and f['namespaces']==[False,True])
 for ns in f['namespaces']:
  for chunk in f['chunks']:
   for handlers in inputs['handlers']:
    for iteration in range(2):expected.append((f['name'],ns,chunk,handlers,iteration));feeds+=math.ceil(len(data)/chunk)
ck('full generated coverage288 and870312feeds',len(expected)==288 and feeds==870312)
training={}
for phase,path,library in [('normal',F/'training.json',F/'liboriole_expat.so'),('generate',P/'generate-training.json',P/'generate/liboriole_expat.so'),('use',P/'use-training.json',P/'use/liboriole_expat.so')]:
 d=js(path);training[phase]=d
 ck('all288 rows complete '+phase,d['status']=='passed' and len(d['rows'])==288 and [tuple(r[k] for k in ['fixture','namespaces','chunk','handlers','iteration']) for r in d['rows']]==expected)
 ck('selected library/script/inputs origin '+phase,d['xml_parse_origin']=={'path':str(library),'sha256':sha(library)} and d['library_sha256']==sha(library) and d['inputs_sha256']==sha(P/'inputs/manifest.json') and d['script_sha256']==sha(S/'train.py'))
 ck('profile pattern only instrumented training '+phase,d['profile_file_environment']==(str(P/'raw-profiles/oriole-%m-%p.profraw') if phase=='generate' else None))
 for i,r in enumerate(d['rows']):
  ck('valid successful callback row '+phase+'/'+str(i),r['status']==1 and r['error']==0 and r['callback_exceptions']==[] and re.fullmatch('[0-9a-f]{64}',r['callback_sha256']) and all(isinstance(n,int) and n>=0 for n in r['counts'].values()))
  if i%2:ck('repeated fresh parser rows equal '+phase+'/'+str(i),{k:v for k,v in r.items() if k!='iteration'}=={k:v for k,v in d['rows'][i-1].items() if k!='iteration'})
ck('all864 saved rows exact within fat build family',training['normal']['rows']==training['generate']['rows']==training['use']['rows'] and report['all_generated_rows_exact'] and report['generated_records']=={'previous_no_pgo_fat_replay':288,'fresh_instrumented_fat':288,'fresh_optimized_fat':288})
for phase in ['generate','use']:
 c=commands[phase];ck('training manifest and log link '+phase,m['training_sha256'][phase]==sha(P/(phase+'-training.json')) and js(P/c['log'])=={'status':'passed','parses':288})
 ck('training direct selected command '+phase,c['argv']==[outer[0]['argv'][0],'-I','-S',str(S/'train.py'),'--library',str(P/phase/'liboriole_expat.so'),'--inputs',str(P/'inputs'),'--report',str(P/(phase+'-training.json'))] and c['environment'].get('LLVM_PROFILE_FILE')==training[phase]['profile_file_environment'])
raws=sorted((P/'raw-profiles').iterdir());ck('one isolated raw profile',len(raws)==1 and all(p.is_file() and not p.is_symlink() and p.stat().st_size>0 for p in raws))
ck('exact raw and merged profile inventory',set(m['profiles_sha256'])=={raws[0].name,'merged.profdata'})
for n,h in m['profiles_sha256'].items():ck('profile bytes '+n,sha(P/n if n=='merged.profdata' else P/'raw-profiles'/n)==h)
ck('new raw/merged distinct from thin run',not set(m['profiles_sha256'].values())&set(oldm['profiles_sha256'].values()))
profiler=commands['profile-merge']['argv'][0]
ck('merge uses only new isolated raw file',commands['profile-merge']['argv']==[profiler,'merge','--num-threads=1','--failure-mode=any','-o',str(P/'merged.profdata'),*map(str,raws)] and profiler in m['tools_sha256'])
ck('show uses exact new merged profile',commands['profile-show']['argv']==[profiler,'show','--all-functions','--counts',str(P/'merged.profdata')])
show=read(P/'07-profile-show.log').decode();parsed=re.findall(r'^  (.+):\n    Hash: (0x[0-9a-f]+)\n    Counters: (\d+)\n    Block counts: (\[[^\n]+\])$',show,re.M)
counts={name:ast.literal_eval(values) for name,_,n,values in parsed}
ck('full profile function table',len(counts)==len(parsed)==630 and all(len(counts[name])==int(n) and all(isinstance(v,int) and v>=0 for v in counts[name]) for name,_,n,_ in parsed))
metrics={'functions':len(parsed),'functions_with_nonzero_counter':sum(any(v) for v in counts.values()),'blocks':sum(map(len,counts.values())),'total_count':sum(map(sum,counts.values())),'max_function_count':max(v[0] for v in counts.values()),'max_internal_block_count':max(map(max,counts.values())),'XML_Parse_entry_count':counts['XML_Parse'][0]}
ck('all raw counters match show totals',metrics['blocks']==17615 and metrics['total_count']==838850498 and metrics['max_function_count']==18096032 and metrics['max_internal_block_count']==20561364 and metrics['XML_Parse_entry_count']==feeds)
for name,val in [('Functions shown',metrics['functions']),('Total functions',metrics['functions']),('Total number of blocks',metrics['blocks']),('Total count',metrics['total_count']),('Maximum function count',metrics['max_function_count']),('Maximum internal block count',metrics['max_internal_block_count'])]:ck('show footer '+name,f'{name}: {val}' in show)
use=read(P/'08-build-use.log').decode()
ck('strict profile-use warning gate',not re.search(r'(?im)^\s*warning[:\[]|\b(?:hash mismatch|counter mismatch|malformed instrumentation profile|no profile data available)\b',use))
ck('fresh profile use and warning flags',f'-Cprofile-use={P}/merged.profdata' in use and '-Cllvm-args=-pgo-warn-missing-function' in use)
ck('final all inspected bytes stable',all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in seen.items()))
review={'status':'passed','scope':'Saved fresh fat-PGO build, generated replay and profile supplement; no target or elapsed executions.',
 'freeze_sha256':sha(B/'freeze.json'),'frozen_files':40,'reused_reviews':reviews,'source_manifest_sha256':report['source_manifest_sha256'],'current_source_files':70,'unchanged_production_tool_files':6,'tool_executable_and_LLVM_files':9,
 'source_proof':'All70 live sources/six tool files rehashed against the exact prior archive/commit-reviewed maps. Earlier pair52 and fat9 frozen files remain unchanged.',
 'compiler_proof':'Three actual workspace compiles each for generate/use match no-PGO fat control after only exact current profile flags and Cargo artifact suffixes. Every metadata value, compiler/source/output path and other argument stays exact. Root C-only cdylib/staticlib uses lto=fat; two Rust workspace dependencies use linker-plugin-lto.',
 'libraries':report['libraries'],'control_fat_libraries':normal['libraries'],'thin_normal_libraries':pair['normal_libraries'],'thin_PGO_libraries':pair['pgo_libraries'],
 'training':{'saved_rows':864,'normal_fat_rows_reused':288,'fresh_generate_rows':288,'fresh_use_rows':288,'all_rows_exact':True,'origin_records':3,'fixtures':12,'XML_Parse_feeds_per_report':feeds,'input_proof':'All13 input-file hashes and manifest exactly match the prior9e7a review that independently reconstructed deterministic corpus bytes; no project generator code executed here.'},
 'profile':metrics|{'raw_files':1,'raw_sha256':sha(raws[0]),'merged_sha256':sha(P/'merged.profdata'),'strict_use_warning_gate_passed':True,'new_run':str(P)},
 'freshness':'Unchanged production tool creates unique run and empty raw directory, removes inherited profile flags, enables LLVM_PROFILE_FILE only for generate, then merges the sole current raw file and uses the exact new merged path. Current raw and merged hashes differ from prior ThinLTO profiles. Saved command order, isolated paths and before/after guards support freshness.',
 'limitations':['The no-PGO fat control288 rows are reused from its sealed earlier replay; only generate/use576 rows are fresh here.','Source/runtime metadata proof is a separate2x2 build comparison, not elapsed performance, application performance, adoption or fresh full correctness certification.','Profile binary identities and saved llvm-profdata-show output are checked; raw-to-merged binary reconstruction and profiler execution were not performed. Counters may differ by LTO mode; only generated feed/row parity is asserted.','Inherited environments are allowlisted, not wholly captured; exact raw compiler vectors establish reviewed flags. Numeric LLVM22.1.8 compatibility retains prior distinct compiler/profiler distribution identities.','Callback hash/count parity does not certify all API semantics, positions, malformed cases or exact fragmentation. Current origin attestation covers XML_Parse, not every API.','timing-prerequisite.json is hash-preserved author evidence of the prior Python campaign completion; this supplement does not audit that campaign or claim independent observation of historical scheduling.'],
 'passed_checks':passed,'checked_files':len(seen),'all_inspected_bytes_unchanged':True,'execution':'CPU4 Python standard library file/hash/JSON/text arithmetic only. No producer imports, corpus generation, parser, compiler, training, profiler, timing or tests.'}
dump('compiler-comparisons.json',comparisons);dump('checked-files.json',seen);dump('review.json',review)
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest(),'passed_checks':passed,'checked_files':len(seen),'profile':metrics}))
