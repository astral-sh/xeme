from pathlib import Path
import hashlib,json,os
p=Path(__file__).parent
assert os.sched_getaffinity(0)=={4}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((p/n).read_text())
r=load('review.json');a=load('attempt01.json')
assert r['status']=='passed' and a['returncode']==0 and r['passed_checks']==1638 and r['checked_files']==193
assert a['generator_sha256']==sha(p/'generator.py')
assert a['stdout_sha256']==sha(p/'attempt01.stdout') and a['stderr_sha256']==sha(p/'attempt01.stderr')
assert not (p/'attempt01.stderr').read_bytes()
assert len(load('compiler-comparisons.json'))==6 and len(load('checked-files.json'))==193
receipt={'status':'passed','review_sha256':sha(p/'review.json'),'generator_sha256':sha(p/'generator.py'),'attempts':1,'checks':r['passed_checks'],'checked_files':r['checked_files'],'scope':r['scope']}
(p/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
files={q.name:{'sha256':sha(q),'bytes':q.stat().st_size} for q in sorted(p.iterdir()) if q.is_file() and q.name!='files.json'}
(p/'files.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n')
assert all(sha(p/n)==v['sha256'] and (p/n).stat().st_size==v['bytes'] for n,v in files.items())
print(json.dumps({'review_sha256':sha(p/'review.json'),'receipt_sha256':sha(p/'receipt.json'),'files_sha256':sha(p/'files.json'),'indexed_files':len(files)}))
