# Independent three-engine PGO/LTO native audit

Passed the first saved-data audit attempt: 6,998 assertions across 728 inspected files. All 691 frozen files remain exact. No large assertion array is emitted; the retained generator contains the checks.

All 84 preflight workers and 588 timed workers match immediate raw records. The audit reconstructs 196 seeded cohorts, all 105,420 measured timings, 588 paired ratios and 84 condition-ratio medians. The complete sample count including warmups and preflights is 106,176.

| Real-input comparison | Geometric mean | Conditions below 1 |
| --- | ---: | ---: |
| Fat-PGO / Thin-PGO | 1.0675959640 | 0 / 24 |
| Fat-PGO / Expat PGO | 1.4969877189 | 3 / 24 |
| Thin-PGO / Expat PGO | 1.4004107976 | 4 / 24 |

Fat-PGO regresses in every real condition and both generated entity conditions; both generated rare-declaration conditions improve. The generated aggregate Fat-PGO/Thin-PGO ratio is 1.0463596950. All 28 conditions and all three ratio families remain in `conditions.json`; all adverse ratios remain in `adverse-conditions.json`.

The five producer controller substitutions affect only paths, library/ratio mappings and explanatory text. The worker, conditions, iterations and entire preflight/timing phase ASTs match the prior controller. Its wrapper remains byte-identical, retaining 90-second worker and 600/1,200-second aggregate bounds.

`review.json` links the sealed source/build/profile and prior native reviews. `generator.py`, `method.json` and the two adaptation patches retain the independent reconstruction. Only CPU 4 saved-file/JSON/hash arithmetic ran. This is one shared-host run, with recorded overlapping CPU 4 Python extension build/preflight; it supplies no idle-host, full-application, broad correctness, statistical-significance or adoption claim. Historical Expat reuse caveats remain linked.
