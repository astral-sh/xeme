"""Independent completed five-engine native evidence audit; no target execution."""
from pathlib import Path
from collections import Counter
import ast, difflib, hashlib, json, math, os, random, statistics

R=Path('/tmp/oriole-current-pgo-lto-native-study');S=R/'native-screen';O=Path(__file__).parent
tracked={};passed_checks=0
def read(path):
    path=Path(path);raw=path.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(path),value)==value,str(path)
    return raw
def h(path): read(path);return tracked[str(path)]
def j(path): return json.loads(read(path))
def ck(name,condition):
    global passed_checks
    assert condition,name
    passed_checks+=1
key=lambda value:json.dumps(value,sort_keys=True)
engines=['thin_pgo','fat_pgo','expat_pgo']
ratio_names=['fat_pgo_over_thin_pgo','fat_pgo_over_expat_pgo','thin_pgo_over_expat_pgo']
ck('CPU4 saved evidence only',__debug__ and os.sched_getaffinity(0)=={4})
ck('final freeze pinned',h(R/'freeze.json')=='47ef547f4928e47c2b7331cd847ae9ae93c4450e48842568efbf5f0b9a9586a3')
freeze=j(R/'freeze.json')
ck('final691 file freeze',freeze['status']=='frozen' and len(freeze['files_sha256'])==691)
ck('complete freeze file inventory',set(freeze['files_sha256'])|{'freeze.json'}=={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()})
for n,v in freeze['files_sha256'].items():ck('frozen file '+n,h(R/n)==v)
reviews={
 '/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json':'cec78c70730e111f139a6fab70089e1629ffe3336843106585a35922a525bbc9',
 '/tmp/oriole-native-byte-count-pgo-training-independent-review/review.json':'9e7a8451c1429ea888904ae16ba6c120e0a86ec4e4695a72bfe7dce5ff9e0934',
 '/tmp/oriole-native-byte-count-fat-lto-independent-review/review.json':'9b0043f8c1df50652136a956277c11fde5df012498d84f0672e73d1487fa42f0',
 '/tmp/oriole-current-pgo-expat-reuse-independent-review/review.json':'9a53fcddfa80a039da800284a3ebdbe7d83316fe83768ed1f4d7e4770b53b2d9',
 '/tmp/oriole-raw-len-split-native-independent-review/review.json':'4c38aebbd27e3f15a2f49ac5da410f2c76a0f5aec371bc424d89840cde196585'}
reviews['/tmp/oriole-native-byte-count-fat-pgo-independent-review/review.json']='46d23adae877d331dfbc198f312e62deebb01efc785e52413d3ce52af65cb63c'
reviews['/tmp/oriole-current-pgo-native-independent-review/review.json']='0388188f7efe8ba3f1d1d612b330263ae7e7c63b3a71aa0b58301304324952fb'
for p,v in reviews.items():ck('sealed prerequisite '+p,h(p)==v)
prior_native_review=j('/tmp/oriole-raw-len-split-native-independent-review/review.json')
ck('prior independent arithmetic generator matches sealed receipt',h('/tmp/oriole-raw-len-split-native-independent-review/generator.py')==prior_native_review['generator_sha256'])
protocol=j(S/'protocol.json');pre=j(S/'preflight.json');results=j(S/'results.json')
adaptation=j(R/'adaptation.json');controller=j(R/'controller.json');published=j(R/'summary.json')
ck('protocol design',protocol['pairs']==7 and protocol['seed']==2026091003 and protocol['preflights']==84 and protocol['timed_workers']==588)
ck('completed phase records',pre['status']==results['status']=='passed' and results['affinity']==[0])
ck('phase hash links',pre['protocol_sha256']==results['protocol_sha256']==h(S/'protocol.json') and results['preflight_sha256']==h(S/'preflight.json'))
ck('complete before after14 file identities',len(protocol['hashes'])==14 and protocol['hashes']==pre['hashes_before']==pre['hashes_after']==results['hashes_before']==results['hashes_after'])
for p,v in protocol['hashes'].items():ck('protocol external bytes '+p,h(p)==v)
expected_hashes={'thin_pgo':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','fat_pgo':'d4e911d2a9148e898fe2c7e51056fd7dcf77dc85f91d6a8b1827fb200ed753a6','expat_pgo':'12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'}
ck('three exact engine mappings',list(protocol['libraries'])==engines and adaptation['libraries']==published['libraries']==protocol['libraries'])
for engine in engines:
    row=protocol['libraries'][engine];ck('exact reviewed library '+engine,h(row['path'])==row['sha256']==expected_hashes[engine])
for p,v in adaptation['build_receipts'].items():ck('preparation proof link '+p,h(p)==v)
source_manifest=Path('/tmp/oriole-native-byte-count-pgo-study/source.json')
ck('exact selected source manifest',adaptation['source_manifest_sha256']==published['source_manifest_sha256']==h(source_manifest)=='d1e021143e45331358ea63dcb20663e80d808fc7cee87510dc59e076b803451f')
oldroot=Path('/tmp/oriole-raw-len-split-thinlto-timing-study')
oldpath=oldroot/'native_screen.py';oldtext=read(oldpath).decode();newtext=read(R/'native_screen.py').decode()
ck('prior native script pin',h(oldpath)==adaptation['parent_controller_sha256']=='6a88b52ca4e6049e9975f062e6841af2a035218c3be8dd950b0f86899ed1fdfd')
ck('current native script pin',h(R/'native_screen.py')==adaptation['controller_sha256']==controller['controller_sha256']=='5269999b6229d9e5862303d1f61f2e761ca859d3a7c683cc21a9237dd1e353a3')
ck('wrapper exact prior bytes',h(oldroot/'run.py')==h(R/'run.py')==adaptation['wrapper_sha256']==adaptation['parent_wrapper_sha256']==controller['wrapper_sha256']=='5f41a419e800e95954424e2a85d2ee988609d830db18dc85c469af801cd8aef5')
rebuilt=oldtext
ck('five declared controller substitutions',adaptation['status']=='passed' and len(adaptation['changes'])==5)
for old,new in adaptation['changes']:
    ck('unique controller substitution',rebuilt.count(old)==1);rebuilt=rebuilt.replace(old,new)
ck('exact whole controller adaptation',rebuilt==newtext)
ck('exact controller patch',read(R/'controller.patch').decode()==''.join(difflib.unified_diff(oldtext.splitlines(True),newtext.splitlines(True),fromfile=str(oldpath),tofile=str(R/'native_screen.py'))))
oldast=ast.parse(oldtext);newast=ast.parse(newtext)
for name in ['run','digest','save']:
    nodes=[next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name) for tree in [oldast,newast]]
    ck('complete worker/helper AST '+name,ast.dump(nodes[0])==ast.dump(nodes[1]))
for name in ['iterations','conditions']:
    nodes=[next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)) for tree in [oldast,newast]]
    ck('condition iteration AST '+name,ast.dump(nodes[0])==ast.dump(nodes[1]))
phase_nodes=[next(n for n in tree.body if isinstance(n,ast.If) and ast.unparse(n.test)=="phase == 'preflight'") for tree in [oldast,newast]]
ck('entire preflight and timing phase AST exact',ast.dump(phase_nodes[0])==ast.dump(phase_nodes[1]))
ratio_ast=next(n.value for n in newast.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ratios' for t in n.targets))
ck('three exact ratio definitions',[a+'_over_'+b for a,b in ast.literal_eval(ratio_ast)]==ratio_names)
ck('controller successful phases',controller['status']=='passed' and len(controller['commands'])==2)
for row,(phase,cpu,timeout) in zip(controller['commands'],[('preflight',5,600),('time',0,1200)],strict=True):
    ck('successful bounded phase '+phase,row['phase']==phase and row['exit']==0 and row['timeout']==timeout and 0<row['end']-row['start']<timeout and row['command']==['taskset','-c',str(cpu),'python3',str(R/'native_screen.py'),phase] and h(R/(phase+'-controller.log'))==row['log_sha256'])
ck('preflight before timing',controller['commands'][0]['end']<=controller['commands'][1]['start'])
ck('outer run stdout',read(R/'run.log')==b'preflight 0\ntime 0\n')
completion=j(R/'completion.json')
ck('author completion links',completion['status']=='passed' and completion['observed_tool_exit']==0 and completion['controller_sha256']==h(R/'controller.json') and completion['summary_sha256']==h(R/'summary.json') and completion['cpu0_released_after_terminal'])
manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');manifest=j(manifest_path)
fixtures={}
for project in manifest['projects']:
    entry=next(row for row in project['files'] if row['role']=='input');path=(manifest_path.parent/entry['path']).resolve()
    ck('original project input '+project['name'],h(path)==entry['sha256']);fixtures[project['name']]=str(path)
ck('six real projects',set(fixtures)=={'vulkan','wayland','maven','batik','gtk','docbook'})
fixtures['generated-rare-declarations']='/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml';fixtures['generated-entities']='/tmp/oriole-grammar-bench-plain/entities.xml'
fixed={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
conditions=[{'name':name,'input':path,'chunk':chunk,'namespaces':ns,'iterations':fixed[name]} for chunk in [4096,65536] for name,path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False,True])]
ck('all28 fixed conditions exact',conditions==protocol['conditions'] and len(conditions)==28 and len({key(c) for c in conditions})==28)
driver=Path('/tmp/oriole-grammar-bench-plain/native-driver');driver_source=Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')
origin_path=Path('/tmp/oriole-grammar-bench-plain/summary.json');origin=j(origin_path)
ck('unchanged native driver original build identity',origin['status']=='passed' and origin['sha256_before'][str(driver)]==origin['sha256_after'][str(driver)]==h(driver) and origin['sha256_before'][str(driver_source)]==origin['sha256_after'][str(driver_source)]==h(driver_source))
driver_code=read(driver_source).decode()
ck('explicit driver library handle','dlopen(argv[1], RTLD_NOW | RTLD_LOCAL)' in driver_code and 'dlsym(library, symbol)' in driver_code)
ck('native timer scope',driver_code.index('fread(data')<driver_code.index('double before = now();')<driver_code.index('Parser parser =')<driver_code.index('api.destroy(parser);\n        double elapsed = now() - before;'))

ordinal=0;streams=[];observed_by_condition={};sample_counts=Counter();process_medians={key(c):{engine:[] for engine in engines} for c in conditions}
def process(row,condition,pair,cpu,count):
    global ordinal
    worker=S/f'worker-{ordinal:04d}.json';saved=j(worker)
    ck('immediate worker original fields '+str(ordinal),set(saved)=={'condition','engine','pair','command','returncode','stdout','stderr'} and saved=={field:row[field] for field in saved})
    ck('worker metadata '+str(ordinal),row['condition']==condition and row['pair']==pair and row['engine'] in engines and row['returncode']==0 and row['stderr']=='')
    engine=row['engine'];command=['taskset','-c',str(cpu),str(driver),protocol['libraries'][engine]['path'],condition['input'],str(condition['chunk']),str(count)]+(['namespaces'] if condition['namespaces'] else [])
    ck('worker command '+str(ordinal),row['command']==command)
    data=json.loads(row['stdout']);samples=data['samples']
    ck('worker output version '+str(ordinal),data['version']==('expat_2.8.4' if engine.startswith('expat') else 'oriole_compat_2.8.4') and set(data)=={'version','samples'})
    ck('all sample fields '+str(ordinal),all(set(sample)=={'iteration','warmup','seconds','hash','elements','text_bytes'} and isinstance(sample['seconds'],(int,float)) and math.isfinite(sample['seconds']) and sample['seconds']>0 and isinstance(sample['elements'],int) and sample['elements']>=0 and isinstance(sample['text_bytes'],int) and sample['text_bytes']>=0 and len(sample['hash'])==16 and all(ch in '0123456789abcdef' for ch in sample['hash']) for sample in samples))
    ck('sample count/indices/warmup '+str(ordinal),len(samples)==count+1 and [sample['iteration'] for sample in samples]==list(range(count+1)) and [sample['warmup'] for sample in samples]==[True]+[False]*count)
    observations=sorted({(sample['hash'],sample['elements'],sample['text_bytes']) for sample in samples})
    ck('sample callback observations '+str(ordinal),len(observations)==1 and row['observations']==[list(value) for value in observations])
    median=statistics.median(sample['seconds'] for sample in samples[1:])
    ck('worker median exact '+str(ordinal),median==row['median_seconds'])
    stage='preflight' if pair==-1 else 'timed'
    sample_counts[stage+'_workers']+=1;sample_counts[stage+'_warmups']+=1;sample_counts[stage+'_measured']+=count
    streams.append({'ordinal':ordinal,'worker_sha256':h(worker),'condition':condition,'pair':pair,'engine':engine,'stdout_sha256':hashlib.sha256(row['stdout'].encode()).hexdigest(),'stderr_sha256':hashlib.sha256(row['stderr'].encode()).hexdigest(),'measured_samples':count,'median_seconds':median})
    ordinal+=1
    return observations,median

ck('84 preflight records',len(pre['rows'])==84)
for index,condition in enumerate(conditions):
    rows=pre['rows'][3*index:3*index+3]
    ck('preflight engine order '+str(index),[row['engine'] for row in rows]==engines)
    observations=[process(row,condition,-1,5,1)[0] for row in rows]
    ck('three-engine preflight observations '+str(index),all(x==observations[0] for x in observations))
    observed_by_condition[key(condition)]=observations[0]

rng=random.Random(protocol['seed']);jobs=[(condition,pair) for condition in conditions for pair in range(7)];rng.shuffle(jobs)
ck('196 complete unique cohorts',len(results['rows'])==len(jobs)==196 and len({(key(row['condition']),row['pair']) for row in results['rows']})==196)
ratios={key(c):{name:[] for name in ratio_names} for c in conditions}
for index,((condition,pair),group) in enumerate(zip(jobs,results['rows'],strict=True)):
    order=engines.copy();rng.shuffle(order)
    ck('seeded cohort and engine order '+str(index),group['condition']==condition and group['pair']==pair and group['order']==order and [row['engine'] for row in group['processes']]==order)
    seconds={}
    for row in group['processes']:
        observations,median=process(row,condition,pair,0,condition['iterations'])
        ck('timed observations equal preflight',observations==observed_by_condition[key(condition)])
        seconds[row['engine']]=median;process_medians[key(condition)][row['engine']].append(median)
    for name in ratio_names:
        numerator,denominator=name.split('_over_');ratios[key(condition)][name].append(seconds[numerator]/seconds[denominator])
computed=[{'condition':c,'paired_ratios':ratios[key(c)],'median_ratios':{name:statistics.median(values) for name,values in ratios[key(c)].items()}} for c in conditions]
ck('all588 paired ratios and84 medians exact',results['summary']==computed)
ck('exact672 immediate worker files no extras',ordinal==672 and sorted(p.name for p in S.glob('worker-*.json'))==[f'worker-{index:04d}.json' for index in range(672)])
ck('sample counts all retained',dict(sample_counts)=={'preflight_workers':84,'preflight_warmups':84,'preflight_measured':84,'timed_workers':588,'timed_warmups':588,'timed_measured':105420})
groups={}
for label,predicate in [('real',lambda c:not c['name'].startswith('generated-')),('generated',lambda c:c['name'].startswith('generated-')),('real_plain',lambda c:not c['name'].startswith('generated-') and not c['namespaces']),('real_namespaces',lambda c:not c['name'].startswith('generated-') and c['namespaces'])]:
    selected=[row for row in computed if predicate(row['condition'])]
    groups[label]={'conditions':len(selected),'ratios':{}}
    for name in ratio_names:
        values=[row['median_ratios'][name] for row in selected]
        groups[label]['ratios'][name]={'geomean':math.exp(sum(math.log(value) for value in values)/len(values)),'below_one':sum(value<1 for value in values)}


ck('all588 paired ratios and84 condition medians exact',results['summary']==computed)
ck('author arithmetic/counts exact',published['status']=='passed' and published['summary']==computed and published['counts']==dict(sample_counts) and published['cohorts']==196 and published['groups']=={k:groups[k] for k in ['real','generated']})
ck('author summary origins',published['generator_sha256']==h(R/'summarize.py') and published['input_sha256']=={n:h(S/n) for n in ['protocol.json','preflight.json','results.json']} and published['controller_sha256']==h(R/'controller.json'))
author_streams=j(R/'streams.json')
ck('all immediate stream hashes and medians exact',published['streams_sha256']==h(R/'streams.json') and author_streams==[{'ordinal':r['ordinal'],'sha256':r['worker_sha256'],'median_seconds':r['median_seconds'],'stdout_sha256':r['stdout_sha256']} for r in streams])
all_adverse={name:[{'condition':r['condition'],'ratio':r['median_ratios'][name]} for r in computed if r['median_ratios'][name]>1] for name in ratio_names}
ck('all author fat/Thin regressions exact',published['regressions']==all_adverse['fat_pgo_over_thin_pgo'] and len(published['regressions'])==26)
ck('all24 real fat/Thin regressions',len([r for r in published['regressions'] if not r['condition']['name'].startswith('generated-')])==24)
generated=[r for r in computed if r['condition']['name'].startswith('generated-')]
ck('both entity adverse/both rare lower',all((r['median_ratios']['fat_pgo_over_thin_pgo']>1)==(r['condition']['name']=='generated-entities') for r in generated))
ck('preflight stdout exact',j(R/'preflight-controller.log')=={'status':'passed','preflights':84,'protocol_sha256':h(S/'protocol.json')})
ck('timing stdout exact',j(R/'time-controller.log')=={'status':'passed','timed_workers':588,'summary':computed})
ck('complete675 native screen files',{p.name for p in S.iterdir()}=={f'worker-{i:04d}.json' for i in range(672)}|{'protocol.json','preflight.json','results.json'})
condition_table=[{'condition':r['condition'],'median_process_seconds':{e:statistics.median(v) for e,v in process_medians[key(r['condition'])].items()},'median_ratios':r['median_ratios'],'paired_ratios':r['paired_ratios']} for r in computed]
method=j(O/'method.json')
ck('auditor source pinned',h(O/'generator.py')==method['generator_sha256'])
ck('reused complete native auditor pinned',h(method['prior_generator'])==method['prior_generator_sha256']==j('/tmp/oriole-current-pgo-native-independent-review/review.json')['generator_sha256'])
for n in ['setup.py','tail.py','prepare-audit.py','core-adaptation.patch','setup-adaptation.patch']:h(O/n)
ck('all inspected bytes unchanged',all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in tracked.items()))
for name,value in [('streams.json',author_streams),('conditions.json',condition_table),('groups.json',groups),('adverse-conditions.json',all_adverse),('checked-files.json',tracked)]:
    (O/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
report={
 'status':'passed','scope':'Independent saved thin-PGO/fat-PGO/Expat-PGO native worker/hash/order/arithmetic audit; no target execution.',
 'freeze_sha256':h(R/'freeze.json'),'frozen_files':691,'source_manifest_sha256':adaptation['source_manifest_sha256'],'libraries':protocol['libraries'],'reused_reviews':reviews,
 'counts':dict(sample_counts)|{'conditions':28,'real_conditions':24,'generated_conditions':4,'cohorts':196,'immediate_workers':672,'native_screen_files':675,'paired_ratios':588,'condition_ratio_medians':84,'all_samples':106176},
 'groups':{k:groups[k] for k in ['real','generated']},'fat_over_thin_regressions':published['regressions'],'all_adverse_conditions_file':'adverse-conditions.json',
 'real_wins_against_Expat_PGO':{engine:[r['condition'] for r in computed if not r['condition']['name'].startswith('generated-') and r['median_ratios'][engine+'_over_expat_pgo']<1] for engine in ['thin_pgo','fat_pgo']},
 'controller_review':'Exactly five substitutions from reviewed raw_len native controller: prose, root path, three engine libraries and three ratios. Full worker/digest/save, conditions/iterations and complete preflight/timing phase ASTs match. Wrapper byte-identical with90-second worker,600-second preflight and1200-second timing bounds. Saved preflightCPU5 and timingCPU0 each complete once.',
 'method':['All672 immediate worker records match copied fields, exact commands, version, status and empty stderr. Every one of106176 samples has valid fields, positive finite time and exact index/warmup marking.','All three callback hashes/counts agree in84 preflights and every timed sample across28 conditions. One warmup excluded per worker; all105420 measured timings contribute to588 process medians.','Seed2026091003 reconstructs all196 shuffled cohorts and588 engine positions. All588 paired ratios,84 condition medians, published groups, stream metadata and phase summaries match exactly.','Aggregate uses exp(sum(log(condition median))/condition count), retaining separate real/generated groups and every adverse condition.'],
 'driver':{'binary_sha256':h(driver),'source_sha256':h(driver_source),'binding':'Absolute per-worker library handle via dlopen RTLD_LOCAL|RTLD_NOW and dlsym; versions checked, no per-worker dladdr attestation.','timer':'Parser construction, handler setup, parsing/callbacks and destruction included; file I/O, dynamic loading and process startup excluded.'},
 'limitations':['One shared-host campaign with recorded concurrent rootCPU4 Python extension build/preflight; no idle-host, statistical-significance or broad causal claim.','Fat-PGO is slower in all24 real condition medians and both generated-entity conditions; both generated-rare conditions improve. All three ratio families and losses remain. No adoption decision.','Both Oriole variants share source/compiler/explicit host but use separately generated mode-specific profiles and ThinLTO versus fat LTO. Expat retains historical verified GCC13.3 PGO/no-LTO; no compiler parity across engines.','Historical Expat launch/metadata/origin caveats remain in sealed9a53fcdd reuse review. This audit does not claim fresh Expat training or build.','Project XML inputs plus generated controls are not full applications; Batik external DTD is not loaded. Callback hashes/counts do not certify positions, fragmentation, allocation behavior or full compatibility.','No compiler, parser, profiling, training, native/Python timing or full correctness jobs ran during this review.','Author completion.json records external tool exit and CPU0 release; saved controller exits are checked, but historical scheduling is not independently observed.'],
 'passed_checks':passed_checks,'checked_files':len(tracked),'all_inspected_bytes_unchanged':True,'generator_sha256':method['generator_sha256']}
(O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest(),'checks':passed_checks,'checked_files':len(tracked),'real':groups['real']['ratios'],'generated':groups['generated']['ratios']}))
