"""Adapt the complete prior independent five-engine saved-data auditor."""
from pathlib import Path
import hashlib,json,difflib
o=Path(__file__).parent;priorroot=Path('/tmp/oriole-current-pgo-native-independent-review');prior=priorroot/'generator.py'
setup=(priorroot/'setup.py').read_text();new=setup
replacements=[
 ("/tmp/oriole-current-pgo-native-study","/tmp/oriole-current-pgo-lto-native-study"),
 ("fcc549b4c7e665b3cb619c7b3d5b2cf27f064c6d35c926247dfc2d690bc6c491","47ef547f4928e47c2b7331cd847ae9ae93c4450e48842568efbf5f0b9a9586a3"),
 ("1139","691"),
 ("engines=['normal','pgo','fat','expat','expat_pgo']","engines=['thin_pgo','fat_pgo','expat_pgo']"),
 ("ratio_names=['pgo_over_normal','fat_over_normal','pgo_over_fat','normal_over_expat','pgo_over_expat_pgo','fat_over_expat','expat_pgo_over_expat']","ratio_names=['fat_pgo_over_thin_pgo','fat_pgo_over_expat_pgo','thin_pgo_over_expat_pgo']"),
 ("protocol['preflights']==140 and protocol['timed_workers']==980","protocol['preflights']==84 and protocol['timed_workers']==588"),
 ("complete before after16 file identities","complete before after14 file identities"),("len(protocol['hashes'])==16","len(protocol['hashes'])==14"),
 ("five exact engine mappings","three exact engine mappings"),("adaptation['proofs_sha256']","adaptation['build_receipts']"),
 ("371cef5e50386d132aa4dc90b179082312235cdda0796eaf204ede860aaa5b59","5269999b6229d9e5862303d1f61f2e761ca859d3a7c683cc21a9237dd1e353a3"),
 ("eight declared controller substitutions","five declared controller substitutions"),("len(adaptation['changes'])==8","len(adaptation['changes'])==5"),
 ("seven exact ratio definitions","three exact ratio definitions"),(" and adaptation['ratios']==[list(x) for x in ast.literal_eval(ratio_ast)]",""),
 ("completion['cpu0_released_after_controller_completion']","completion['cpu0_released_after_terminal']")]
for a,b in replacements:
 assert a in new,a
 new=new.replace(a,b)
oldhashline=next(x for x in new.splitlines() if x.startswith('expected_hashes='))
new=new.replace(oldhashline,"expected_hashes={'thin_pgo':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','fat_pgo':'d4e911d2a9148e898fe2c7e51056fd7dcf77dc85f91d6a8b1827fb200ed753a6','expat_pgo':'12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'}")
anchor="for p,v in reviews.items():"
extra="reviews['/tmp/oriole-native-byte-count-fat-pgo-independent-review/review.json']='46d23adae877d331dfbc198f312e62deebb01efc785e52413d3ce52af65cb63c'\nreviews['/tmp/oriole-current-pgo-native-independent-review/review.json']='0388188f7efe8ba3f1d1d612b330263ae7e7c63b3a71aa0b58301304324952fb'\n"
new=new.replace(anchor,extra+anchor)
anchor="ratio_ast=next("
extra="phase_nodes=[next(n for n in tree.body if isinstance(n,ast.If) and ast.unparse(n.test)==\"phase == 'preflight'\") for tree in [oldast,newast]]\nck('entire preflight and timing phase AST exact',ast.dump(phase_nodes[0])==ast.dump(phase_nodes[1]))\n"
new=new.replace(anchor,extra+anchor)
(o/'setup.py').write_text(new)
(o/'setup-adaptation.patch').write_text(''.join(difflib.unified_diff(setup.splitlines(True),new.splitlines(True),fromfile='prior-five-engine-setup',tofile='three-PGO-engine-setup')))
full=prior.read_text();start=full.index('ordinal=0;streams=[];');end=full.index("ck('all 1372 paired ratios and196 condition ratio medians exact'",start);core=full[start:end];adapted=core
core_replacements=[("140 preflight records","84 preflight records"),("len(pre['rows'])==140","len(pre['rows'])==84"),("pre['rows'][5*index:5*index+5]","pre['rows'][3*index:3*index+3]"),("five-engine preflight observations","three-engine preflight observations"),("all1372 paired ratios and196 medians exact","all588 paired ratios and84 medians exact"),("exact1120 immediate worker files no extras","exact672 immediate worker files no extras"),("ordinal==1120","ordinal==672"),("range(1120)","range(672)"),("{'preflight_workers':140,'preflight_warmups':140,'preflight_measured':140,'timed_workers':980,'timed_warmups':980,'timed_measured':175700}","{'preflight_workers':84,'preflight_warmups':84,'preflight_measured':84,'timed_workers':588,'timed_warmups':588,'timed_measured':105420}")]
for a,b in core_replacements:
 assert adapted.count(a)==1,a
 adapted=adapted.replace(a,b)
(o/'core-adaptation.patch').write_text(''.join(difflib.unified_diff(core.splitlines(True),adapted.splitlines(True),fromfile='prior-independent-five-engine-core',tofile='three-PGO-engine-core')))
(o/'generator.py').write_text(new+'\n'+adapted+'\n'+(o/'tail.py').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(o/'method.json').write_text(json.dumps({'prior_generator':str(prior),'prior_generator_sha256':sha(prior),'generator_sha256':sha(o/'generator.py'),'setup_replacements':replacements,'core_replacements':core_replacements,'scope':'Reuse sealed complete independent native core with only engine labels, grouping and derived count changes. Additional build/source review links retained; no producer execution.'},indent=2)+'\n')
