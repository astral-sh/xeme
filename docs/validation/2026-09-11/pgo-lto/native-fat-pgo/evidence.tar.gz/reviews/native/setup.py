"""Independent completed five-engine native evidence audit; no target execution."""
from pathlib import Path
from collections import Counter
import ast, difflib, hashlib, json, math, os, random, statistics

R=Path('/tmp/oriole-current-pgo-lto-native-study');S=R/'native-screen';O=Path(__file__).parent
tracked={};passed_checks=0
def read(path):
    path=Path(path);raw=path.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(path),value)==value,str(path)
    return raw
def h(path): read(path);return tracked[str(path)]
def j(path): return json.loads(read(path))
def ck(name,condition):
    global passed_checks
    assert condition,name
    passed_checks+=1
key=lambda value:json.dumps(value,sort_keys=True)
engines=['thin_pgo','fat_pgo','expat_pgo']
ratio_names=['fat_pgo_over_thin_pgo','fat_pgo_over_expat_pgo','thin_pgo_over_expat_pgo']
ck('CPU4 saved evidence only',__debug__ and os.sched_getaffinity(0)=={4})
ck('final freeze pinned',h(R/'freeze.json')=='47ef547f4928e47c2b7331cd847ae9ae93c4450e48842568efbf5f0b9a9586a3')
freeze=j(R/'freeze.json')
ck('final691 file freeze',freeze['status']=='frozen' and len(freeze['files_sha256'])==691)
ck('complete freeze file inventory',set(freeze['files_sha256'])|{'freeze.json'}=={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()})
for n,v in freeze['files_sha256'].items():ck('frozen file '+n,h(R/n)==v)
reviews={
 '/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json':'cec78c70730e111f139a6fab70089e1629ffe3336843106585a35922a525bbc9',
 '/tmp/oriole-native-byte-count-pgo-training-independent-review/review.json':'9e7a8451c1429ea888904ae16ba6c120e0a86ec4e4695a72bfe7dce5ff9e0934',
 '/tmp/oriole-native-byte-count-fat-lto-independent-review/review.json':'9b0043f8c1df50652136a956277c11fde5df012498d84f0672e73d1487fa42f0',
 '/tmp/oriole-current-pgo-expat-reuse-independent-review/review.json':'9a53fcddfa80a039da800284a3ebdbe7d83316fe83768ed1f4d7e4770b53b2d9',
 '/tmp/oriole-raw-len-split-native-independent-review/review.json':'4c38aebbd27e3f15a2f49ac5da410f2c76a0f5aec371bc424d89840cde196585'}
reviews['/tmp/oriole-native-byte-count-fat-pgo-independent-review/review.json']='46d23adae877d331dfbc198f312e62deebb01efc785e52413d3ce52af65cb63c'
reviews['/tmp/oriole-current-pgo-native-independent-review/review.json']='0388188f7efe8ba3f1d1d612b330263ae7e7c63b3a71aa0b58301304324952fb'
for p,v in reviews.items():ck('sealed prerequisite '+p,h(p)==v)
prior_native_review=j('/tmp/oriole-raw-len-split-native-independent-review/review.json')
ck('prior independent arithmetic generator matches sealed receipt',h('/tmp/oriole-raw-len-split-native-independent-review/generator.py')==prior_native_review['generator_sha256'])
protocol=j(S/'protocol.json');pre=j(S/'preflight.json');results=j(S/'results.json')
adaptation=j(R/'adaptation.json');controller=j(R/'controller.json');published=j(R/'summary.json')
ck('protocol design',protocol['pairs']==7 and protocol['seed']==2026091003 and protocol['preflights']==84 and protocol['timed_workers']==588)
ck('completed phase records',pre['status']==results['status']=='passed' and results['affinity']==[0])
ck('phase hash links',pre['protocol_sha256']==results['protocol_sha256']==h(S/'protocol.json') and results['preflight_sha256']==h(S/'preflight.json'))
ck('complete before after14 file identities',len(protocol['hashes'])==14 and protocol['hashes']==pre['hashes_before']==pre['hashes_after']==results['hashes_before']==results['hashes_after'])
for p,v in protocol['hashes'].items():ck('protocol external bytes '+p,h(p)==v)
expected_hashes={'thin_pgo':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','fat_pgo':'d4e911d2a9148e898fe2c7e51056fd7dcf77dc85f91d6a8b1827fb200ed753a6','expat_pgo':'12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'}
ck('three exact engine mappings',list(protocol['libraries'])==engines and adaptation['libraries']==published['libraries']==protocol['libraries'])
for engine in engines:
    row=protocol['libraries'][engine];ck('exact reviewed library '+engine,h(row['path'])==row['sha256']==expected_hashes[engine])
for p,v in adaptation['build_receipts'].items():ck('preparation proof link '+p,h(p)==v)
source_manifest=Path('/tmp/oriole-native-byte-count-pgo-study/source.json')
ck('exact selected source manifest',adaptation['source_manifest_sha256']==published['source_manifest_sha256']==h(source_manifest)=='d1e021143e45331358ea63dcb20663e80d808fc7cee87510dc59e076b803451f')
oldroot=Path('/tmp/oriole-raw-len-split-thinlto-timing-study')
oldpath=oldroot/'native_screen.py';oldtext=read(oldpath).decode();newtext=read(R/'native_screen.py').decode()
ck('prior native script pin',h(oldpath)==adaptation['parent_controller_sha256']=='6a88b52ca4e6049e9975f062e6841af2a035218c3be8dd950b0f86899ed1fdfd')
ck('current native script pin',h(R/'native_screen.py')==adaptation['controller_sha256']==controller['controller_sha256']=='5269999b6229d9e5862303d1f61f2e761ca859d3a7c683cc21a9237dd1e353a3')
ck('wrapper exact prior bytes',h(oldroot/'run.py')==h(R/'run.py')==adaptation['wrapper_sha256']==adaptation['parent_wrapper_sha256']==controller['wrapper_sha256']=='5f41a419e800e95954424e2a85d2ee988609d830db18dc85c469af801cd8aef5')
rebuilt=oldtext
ck('five declared controller substitutions',adaptation['status']=='passed' and len(adaptation['changes'])==5)
for old,new in adaptation['changes']:
    ck('unique controller substitution',rebuilt.count(old)==1);rebuilt=rebuilt.replace(old,new)
ck('exact whole controller adaptation',rebuilt==newtext)
ck('exact controller patch',read(R/'controller.patch').decode()==''.join(difflib.unified_diff(oldtext.splitlines(True),newtext.splitlines(True),fromfile=str(oldpath),tofile=str(R/'native_screen.py'))))
oldast=ast.parse(oldtext);newast=ast.parse(newtext)
for name in ['run','digest','save']:
    nodes=[next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name) for tree in [oldast,newast]]
    ck('complete worker/helper AST '+name,ast.dump(nodes[0])==ast.dump(nodes[1]))
for name in ['iterations','conditions']:
    nodes=[next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets)) for tree in [oldast,newast]]
    ck('condition iteration AST '+name,ast.dump(nodes[0])==ast.dump(nodes[1]))
phase_nodes=[next(n for n in tree.body if isinstance(n,ast.If) and ast.unparse(n.test)=="phase == 'preflight'") for tree in [oldast,newast]]
ck('entire preflight and timing phase AST exact',ast.dump(phase_nodes[0])==ast.dump(phase_nodes[1]))
ratio_ast=next(n.value for n in newast.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ratios' for t in n.targets))
ck('three exact ratio definitions',[a+'_over_'+b for a,b in ast.literal_eval(ratio_ast)]==ratio_names)
ck('controller successful phases',controller['status']=='passed' and len(controller['commands'])==2)
for row,(phase,cpu,timeout) in zip(controller['commands'],[('preflight',5,600),('time',0,1200)],strict=True):
    ck('successful bounded phase '+phase,row['phase']==phase and row['exit']==0 and row['timeout']==timeout and 0<row['end']-row['start']<timeout and row['command']==['taskset','-c',str(cpu),'python3',str(R/'native_screen.py'),phase] and h(R/(phase+'-controller.log'))==row['log_sha256'])
ck('preflight before timing',controller['commands'][0]['end']<=controller['commands'][1]['start'])
ck('outer run stdout',read(R/'run.log')==b'preflight 0\ntime 0\n')
completion=j(R/'completion.json')
ck('author completion links',completion['status']=='passed' and completion['observed_tool_exit']==0 and completion['controller_sha256']==h(R/'controller.json') and completion['summary_sha256']==h(R/'summary.json') and completion['cpu0_released_after_terminal'])
manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');manifest=j(manifest_path)
fixtures={}
for project in manifest['projects']:
    entry=next(row for row in project['files'] if row['role']=='input');path=(manifest_path.parent/entry['path']).resolve()
    ck('original project input '+project['name'],h(path)==entry['sha256']);fixtures[project['name']]=str(path)
ck('six real projects',set(fixtures)=={'vulkan','wayland','maven','batik','gtk','docbook'})
fixtures['generated-rare-declarations']='/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml';fixtures['generated-entities']='/tmp/oriole-grammar-bench-plain/entities.xml'
fixed={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
conditions=[{'name':name,'input':path,'chunk':chunk,'namespaces':ns,'iterations':fixed[name]} for chunk in [4096,65536] for name,path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False,True])]
ck('all28 fixed conditions exact',conditions==protocol['conditions'] and len(conditions)==28 and len({key(c) for c in conditions})==28)
driver=Path('/tmp/oriole-grammar-bench-plain/native-driver');driver_source=Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')
origin_path=Path('/tmp/oriole-grammar-bench-plain/summary.json');origin=j(origin_path)
ck('unchanged native driver original build identity',origin['status']=='passed' and origin['sha256_before'][str(driver)]==origin['sha256_after'][str(driver)]==h(driver) and origin['sha256_before'][str(driver_source)]==origin['sha256_after'][str(driver_source)]==h(driver_source))
driver_code=read(driver_source).decode()
ck('explicit driver library handle','dlopen(argv[1], RTLD_NOW | RTLD_LOCAL)' in driver_code and 'dlsym(library, symbol)' in driver_code)
ck('native timer scope',driver_code.index('fread(data')<driver_code.index('double before = now();')<driver_code.index('Parser parser =')<driver_code.index('api.destroy(parser);\n        double elapsed = now() - before;'))
