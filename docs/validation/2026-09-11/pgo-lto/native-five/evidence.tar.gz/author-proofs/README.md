# Current runtime PGO and LTO build comparison

Runtime source is commit `be22a271f8a5c004d13e515cd4024a68afe57887`, the native-byte-count change later published in PR116. All 70 frozen source bytes and the six production PGO tool files stayed unchanged.

The fresh uninstrumented control and PGO builds use an explicit `x86_64-unknown-linux-gnu` target and C-only `cdylib,staticlib` output. Their final compiler calls contain `-C lto=thin`; storage and core dependencies use `-C linker-plugin-lto`. Each phase recorded three fresh workspace compiler invocations. Normal and PGO vectors differ only in profile flags and Cargo artifact suffixes. The explicit-target normal binaries differ from the earlier implicit-target binaries, so all comparisons must use the new normal control.

The separate no-PGO fat build changes the global Cargo profile option to `profile.release.lto="fat"`. Its final compiler call changes `lto=thin` to `lto=fat`. All six compiled crates also change Cargo metadata or artifact suffixes; these complete differences are retained. Dependency `linker-plugin-lto` flags remain unchanged.

| Build | Shared library SHA-256 |
| --- | --- |
| Current normal ThinLTO | `0c8c58750c029174bfb522cee85949c11360696978e13b92d96e21f84461e96d` |
| Current PGO ThinLTO | `4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02` |
| Current no-PGO fat LTO | `b86bb49a27b4072cbe37a4af622580359876138de38719c0227f1044db3a14d5` |
| Existing Expat normal | `7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478` |
| Existing Expat PGO | `12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0` |

## Training and correctness scope

The unchanged PGO tool generated 12 deterministic documents, using both namespace modes, three feed widths, two callback modes, and two iterations. All 288 instrumented records equal the 288 optimized records and the 288 fresh normal records. The separate fat build also passed the same 288-record replay. All six benchmark projects are held out. No earlier Oriole profile was reused.

These checks establish generated-corpus replay equality and build provenance. They do not establish a fresh full API, sanitizer, or CPython test result for these new binaries. No throughput result is claimed by this build report.

## Existing Expat PGO reuse

The saved Expat source, compiler, configuration, library, raw profiles and training records were rehashed. Its seven C compilation commands plus link command match within the engine after accounting for instrumentation/use flags and build paths. All 288 records in each of normal, generate and use match. The exact generated input bytes and parse configurations match the current Oriole training set.

Expat retains its existing GCC 13.3 `-O3`, shared-library, no-LTO build. This is a within-engine PGO comparison; Rust and C compiler configurations are not identical. The historical interpreter/launch identity receipt is explicitly retrospective. The historical input manifest's `iterations: 1` and “native callbacks” prose are inaccurate; saved rows and the actual driver establish two iterations and Python ctypes callbacks. The historical generic training report's source-manifest field points to the old Oriole manifest even for Expat; Expat source identity is established separately by its own source map, complete compiler receipts and library hashes. The historical training driver uses an absolute `ctypes.CDLL` handle and hashes its file, but does not perform the current Oriole driver's same-process `dladdr` check. This is explicit-library provenance, not retrospective proof of the loaded symbol origin. All historical records remain unchanged.

## Evidence

- `/tmp/oriole-native-byte-count-pgo-study`: frozen normal/generate/use source, tools, compiler commands, raw profiles, merged profile, generated inputs and replay records.
- `/tmp/oriole-native-byte-count-fat-lto-study`: separate fat build, complete compiler differences and generated replay.
- `/tmp/oriole-current-pgo-expat-reuse-proof`: saved-data verification of the existing Expat normal/PGO pair.
- `/tmp/oriole-current-pgo-native-study`: prepared fixed five-engine native protocol; execution requires the separate timing authorization.

All build and replay processes ran on CPU1 with bounded timeouts. This report is written by the build-study author; independent reviews are separate.
