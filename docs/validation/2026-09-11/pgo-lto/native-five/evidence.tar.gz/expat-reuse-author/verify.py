"""Read-only verification of existing Expat PGO artifacts for current paired timing."""
from pathlib import Path
import hashlib,json,shlex,itertools,difflib
O=Path(__file__).parent;H=Path('/tmp/oriole-pgo-study');N=Path('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
inputs={};checks=0
def check(v,message):
 global checks
 checks+=1
 if not v:raise AssertionError(message)
def checked(p,expected=None):
 p=Path(p);h=sha(p);inputs[str(p)]=h
 if expected is not None:check(h==expected,str(p))
 return h
r={'status':'incomplete','scope':'Saved-data verification only; no Expat compilation/training/parser execution. Existing GCC PGO artifacts may be reused; current Oriole profiles are independently fresh.'}
try:
 source=load(H/'expat-source.json');checked(H/'expat-source.json')
 for n,h in source['files'].items():checked(H/'expat-source'/n,h);checked(Path(source['upstream'])/n,h)
 builds={p:load(H/f'expat-{p}-build.json') for p in ['control','generate','use']};libraries={};vectors={}
 for p,b in builds.items():
  checked(H/f'expat-{p}-build.json');check(b['status']=='passed' and b['source_manifest_sha256']==sha(H/'expat-source.json'),p)
  check(b['features']==builds['control']['features'] and b['compiler']==builds['control']['compiler'] and b['tools_sha256']==builds['control']['tools_sha256'],p+' compiler/features')
  for path,h in b['tools_sha256'].items():checked(path,h)
  for cmd in b['commands']:check(cmd['returncode']==0,p+' exit');checked(cmd['log'],cmd['log_sha256'])
  lib=H/f'expat-{p}-liboriole_expat.so';checked(lib,b['library_sha256']);checked(H/f'expat-{p}-build/libexpat.so',b['library_sha256']);libraries[p]={'path':str(lib),'sha256':sha(lib)}
  checked(H/f'expat-{p}-build/expat_config.h',b['generated_config_sha256']);check(b['generated_config_sha256']==builds['control']['generated_config_sha256'],p+' config')
  vectors[p]=[shlex.split(line) for line in (H/f'expat-{p}-compile.log').read_text().splitlines() if line.startswith('/usr/bin/cc ')]
  check(len(vectors[p])==8,p+' seven C compile commands plus link')
 def normalize(a,p):return [x.replace(f'expat-{p}-build','expat-<phase>-build') for x in a if not x.startswith(('-fprofile-generate=','-fprofile-use=','-fprofile-prefix-path='))]
 for p in ['generate','use']:
  for a,b in zip(vectors['control'],vectors[p],strict=True):check(normalize(a,'control')==normalize(b,p),p+' vector')
 checked('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4',libraries['control']['sha256'])
 old=load(H/'training-inputs.json');new=load(N/'inputs/manifest.json');checked(H/'training-inputs.json');checked(N/'inputs/manifest.json')
 check(len(old['rows'])==len(new['rows'])==12 and old['seed']==new['seed'],'input12/seed')
 for a,b in zip(old['rows'],new['rows'],strict=True):
  check({k:v for k,v in a.items() if k!='path'}=={k:v for k,v in b.items() if k!='file'},'exact input bytes and parse configuration')
  checked(a['path'],a['sha256']);checked(N/'inputs'/b['file'],b['sha256'])
 manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');heldout=[];checked(manifest)
 for project in load(manifest)['projects']:
  e=next(x for x in project['files'] if x['role']=='input');path=manifest.parent/e['path'];checked(path,e['sha256']);heldout.append(e['sha256'])
 check(len(heldout)==6 and not set(heldout)&{x['sha256'] for x in old['rows']},'six held-out inputs disjoint')
 checked(H/'train.py');checked(H/'generate_training.py',old['generator_sha256']);checked(H/'build_expat.py')
 rows={};launch=load(H/'training-launch-provenance.json');checked(H/'training-launch-provenance.json');checked(launch['python_executable'],launch['python_sha256']);checked(launch['taskset_executable'],launch['taskset_sha256'])
 expected=[(f['name'],ns,ch,ha,i) for f in old['rows'] for ns in f['namespaces'] for ch in f['chunks'] for ha in ['minimal','full'] for i in range(2)]
 for p in ['control','generate','use']:
  path=H/f'expat-{p}-training.json';t=load(path);l=next(x for x in launch['records'] if x['label']=='expat-'+p);checked(path,l['result_sha256'])
  check(t['status']=='passed' and t['library_sha256']==libraries[p]['sha256'] and t['script_sha256']==sha(H/'train.py') and t['inputs_sha256']==sha(H/'training-inputs.json'),'training identities')
  check(t['source_manifest_sha256']==sha(H/'source.json'),'legacy training source field retains old Oriole manifest')
  check([(x['fixture'],x['namespaces'],x['chunk'],x['handlers'],x['iteration']) for x in t['rows']]==expected,'288 ordered configurations')
  check(all(x['status']==1 and x['error']==0 and not x['callback_exceptions'] for x in t['rows']),'all parse successes')
  rows[p]=t['rows']
 check(len(expected)==288 and rows['control']==rows['generate']==rows['use'],'exact864 saved Expat rows')
 profile=load(H/'expat-profile.json');checked(H/'expat-profile.json');check(profile['status']=='passed' and profile['source_manifest_sha256']==sha(H/'expat-source.json'),'profile source')
 for p,h in profile['files'].items():checked(H/p,h)
 check(len(profile['files'])==7 and profile['returncode']==0,'seven native GCC profiles');checked(H/'expat-profile-counts.txt',profile['counts_sha256'])
 checked(H/'train.py',profile['training_driver_sha256']);checked(H/'expat-generate-training.json',profile['training_report_sha256'])
 r.update(status='passed',libraries=libraries,expat_source_files=len(source['files']),actual_compile_and_link_vectors=vectors,source_manifest_sha256=sha(H/'expat-source.json'),features=builds['control']['features'],generated_rows_per_phase=288,training_inputs_exact_current=True,heldout_project_count=6,profiles=profile['files'],limitations=['Historical launch/interpreter identity is explicitly retrospective; actual results/profiles were captured during execution.','Historical training-inputs iterations=1 and native callbacks prose are inaccurate; actual saved rows and driver establish two iterations and Python ctypes callbacks. Frozen originals remain unchanged.','Historical generic train.py source_manifest_sha256 points at old Oriole source.json even for Expat labels; Expat identity is established separately by expat-source.json, all source bytes, full compiler receipts, and exact loaded library hashes.','Expat keeps its existing GCC13.3 -O3/shared/no-LTO configuration; this verifies normal/PGO matching within Expat, not compiler parity with Rust/LLVM ThinLTO.','No historical Oriole profile is reused. Generated documents/configurations match current training; callback records are compared within each engine.'])
except BaseException as e:r['exception']=repr(e);raise
finally:
 r['checks']=checks;r['inputs_sha256']=inputs;r['generator_sha256']=sha(__file__);(O/'review.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'checks':checks,'libraries':libraries}))
