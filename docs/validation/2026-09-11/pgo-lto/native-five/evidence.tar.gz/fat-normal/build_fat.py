"""Bounded no-PGO fat comparison; preserves the already frozen ThinLTO pair."""
from pathlib import Path
import difflib, hashlib, json, os, shlex, shutil, signal, subprocess, time
O=Path(__file__).parent; P=Path('/tmp/oriole-native-byte-count-pgo-study'); W=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); load=lambda p:json.loads(Path(p).read_text())
assert __debug__ and os.sched_getaffinity(0)=={1}
pair=load(P/'pair-report.json'); freeze=load(P/'pair-freeze.json'); source=load(P/'source.json'); assert pair['status']=='passed'
def unchanged():
 return all(sha(P/n)==v for n,v in freeze['files_sha256'].items()) and all(sha(W/n)==v for n,v in source['source_sha256'].items())
assert unchanged()
assert not {k:v for k,v in os.environ.items() if k.startswith('CARGO_PROFILE_')}
env=os.environ.copy()
for k in ['RUSTC','RUSTFLAGS','LLVM_PROFILE_FILE','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST']:env.pop(k,None)
overrides=pair['env_overrides']|{'CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/native-byte-count-fat-lto-target','RUSTC':pair['normal_vectors'][0]['argv'][0]};env.update(overrides)
cmd=next(r['argv'] for r in pair['commands'] if r['label']=='normal-build').copy();cmd.insert(cmd.index('rustc'),'--config=profile.release.lto="fat"')
report={'status':'incomplete','source_manifest_sha256':sha(P/'source.json'),'pair_freeze_sha256':sha(P/'pair-freeze.json'),'env_overrides':overrides,'commands':[],'scope':'Separate no-PGO fat-LTO comparison; explicit target and source/compiler match normal ThinLTO. No elapsed benchmark. Actual full vectors/deltas retained.'}
def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,argv,timeout):
 row={'label':label,'argv':argv,'cwd':str(W),'cpu':1,'timeout':timeout,'start':time.time()};report['commands'].append(row);save();p=None
 with (O/(label+'.log')).open('wb') as f:
  try:
   p=subprocess.Popen(argv,cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['exit']=p.wait(timeout=timeout)
   if row['exit']:raise RuntimeError(label+' nonzero')
  except BaseException as e:
   row['exception']=repr(e)
   if p is not None:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    row['exit']=p.wait()
   raise
  finally:f.flush();row['end']=time.time();row['log_sha256']=sha(O/(label+'.log'));save()
 return (O/(label+'.log')).read_text()
try:
 report['tools_before']={p:sha(p) for p in pair['tools_before']}; assert report['tools_before']==pair['tools_before']
 # Timestamp-only invalidation forces source compilation without changing any byte.
 for n in source['source_sha256']:os.utime(W/n,None)
 text=run('fat-build',cmd,900);rows=[];allrows=[]
 for line in text.splitlines():
  if 'Running `' not in line or '/rustc ' not in line:continue
  a=shlex.split(line.strip()[len('Running `'):-1]);crate=a[a.index('--crate-name')+1];r={'crate':crate,'argv':a,'line':line};allrows.append(r)
  if crate in ['oriole_storage','oriole','oriole_expat']:rows.append(r)
 assert sorted(r['crate'] for r in rows)==['oriole','oriole_expat','oriole_storage']
 final=next(r for r in rows if r['crate']=='oriole_expat');assert 'lto=fat' in final['argv'] and [final['argv'][i+1] for i,x in enumerate(final['argv'][:-1]) if x=='--crate-type']==['cdylib','staticlib']
 assert all('--target' in r['argv'] and r['argv'][r['argv'].index('--target')+1]==pair['host'] for r in rows)
 assert not any('profile-use=' in x or 'profile-generate=' in x for r in allrows for x in r['argv'])
 report['workspace_vectors']=rows;report['all_fresh_rustc_vectors']=allrows;report['workspace_deltas']=[{'crate':n['crate'],'delta':list(difflib.unified_diff(n['argv'],f['argv'],n=2))} for n,f in zip(pair['normal_vectors'],rows)]
 report['libraries']={}
 for n in ['liboriole_expat.so','liboriole_expat.a']:
  shutil.copyfile(Path(overrides['CARGO_TARGET_DIR'])/pair['host']/'release'/n,O/n);report['libraries'][n]=sha(O/n)
 mp=Path(pair['pgo_manifest']['path']);py='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
 run('generated-replay',[py,'-I','-S',str(W/'tools/pgo/train.py'),'--library',str(O/'liboriole_expat.so'),'--inputs',str(mp.parent/'inputs'),'--report',str(O/'training.json')],300)
 t=load(O/'training.json');assert t['status']=='passed' and len(t['rows'])==288 and t['rows']==load(P/'normal-training.json')['rows'];report['generated_parses']=288;report['all_rows_exact_normal']=True;report['status']='passed'
finally:
 report['pair_and_source_unchanged']=unchanged();report['tools_after']={p:sha(p) for p in pair['tools_before']};report['tools_unchanged']=report['tools_after']==pair['tools_before'];save()
assert report['pair_and_source_unchanged'] and report['tools_unchanged'];print(json.dumps({'status':report['status'],'libraries':report.get('libraries')}),flush=True)
