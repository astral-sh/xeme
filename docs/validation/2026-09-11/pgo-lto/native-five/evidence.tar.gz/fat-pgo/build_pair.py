"""Prepared fresh fat-LTO PGO run; execute only after the parent's timing lease ends."""
from pathlib import Path
import difflib,hashlib,json,os,re,shlex,signal,subprocess,time
O=Path(__file__).parent;P=Path('/tmp/oriole-native-byte-count-pgo-study');F=Path('/tmp/oriole-native-byte-count-fat-lto-study');W=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')
PY='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12';PROF='/tmp/oriole-pgo-study/llvm-tools-1.98.0/bin/llvm-profdata'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
assert __debug__ and os.sched_getaffinity(0)=={1}
source=load(P/'source.json');scripts=load(P/'tool-source.json');normal=load(F/'report.json');pair=load(P/'pair-report.json')
def unchanged():
 return all(sha(W/n)==h for n,h in source['source_sha256'].items()) and all(sha(W/n)==h for n,h in scripts.items()) and all(sha(F/n)==h for n,h in load(F/'freeze.json')['files_sha256'].items()) and all(sha(P/n)==h for n,h in load(P/'pair-freeze.json')['files_sha256'].items())
assert unchanged() and normal['status']=='passed' and not (O/'pgo').exists()
assert not {k:v for k,v in os.environ.items() if k.startswith('CARGO_PROFILE_')}
env=os.environ.copy()
for k in ['RUSTC','RUSTFLAGS','LLVM_PROFILE_FILE','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST']:env.pop(k,None)
overrides=pair['env_overrides']|{'CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/native-byte-count-fat-pgo-target'};env.update(overrides)
report={'status':'incomplete','source_manifest_sha256':sha(P/'source.json'),'tools_source_manifest_sha256':sha(P/'tool-source.json'),'normal_fat_report_sha256':sha(F/'report.json'),'normal_fat_freeze_sha256':sha(F/'freeze.json'),'env_overrides':overrides,'commands':[],'scope':'Fresh fat-LTO generate/train/merge/use through unchanged production PGO tool; no ThinLTO profile reuse. Compare with frozen explicit-target uninstrumented fat b86. No benchmark or full correctness-gate claim.'}
def save():(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,argv,timeout):
 row={'label':label,'argv':argv,'cwd':str(W),'cpu':1,'timeout':timeout,'start':time.time()};report['commands'].append(row);save();p=None
 with (O/(label+'.log')).open('wb') as f:
  try:
   p=subprocess.Popen(argv,cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);row['exit']=p.wait(timeout=timeout)
   if row['exit']:raise RuntimeError(label+' nonzero')
  except BaseException as e:
   row['exception']=repr(e)
   if p is not None:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    row['exit']=p.wait()
   raise
  finally:f.flush();row['end']=time.time();row['log_sha256']=sha(O/(label+'.log'));save()
def vectors(text):
 rows=[]
 for line in text.splitlines():
  if 'Running `' not in line or '/rustc ' not in line:continue
  a=shlex.split(line.strip()[len('Running `'):-1]);crate=a[a.index('--crate-name')+1]
  if crate in ['oriole_storage','oriole','oriole_expat']:rows.append({'crate':crate,'argv':a,'line':line})
 assert sorted(x['crate'] for x in rows)==['oriole','oriole_expat','oriole_storage']
 final=next(x for x in rows if x['crate']=='oriole_expat')['argv'];assert 'lto=fat' in final and [final[i+1] for i,x in enumerate(final[:-1]) if x=='--crate-type']==['cdylib','staticlib']
 assert all(a['argv'][a['argv'].index('--target')+1]=='x86_64-unknown-linux-gnu' for a in rows)
 return rows
def normalize(a):
 return [re.sub(r'-[a-f0-9]{16}(\.(?:rlib|rmeta))',r'-<artifact>\1',re.sub(r'^extra-filename=-[a-f0-9]{16}$','extra-filename=<artifact>',x)) for x in a if not x.startswith(('-Cprofile-generate=','-Cprofile-use=')) and x!='-Cllvm-args=-pgo-warn-missing-function']
try:
 report['tools_before']={p:sha(p) for p in pair['tools_before']};assert report['tools_before']==pair['tools_before'];save()
 for n in source['source_sha256']:os.utime(W/n,None)
 argv=[PY,'-I','-S',str(W/'tools/pgo/build.py'),'--source',str(W),'--output',str(O/'pgo'),'--llvm-profdata',PROF,'--toolchain','ohm','--cargo-arg=-Zohm-defaults=no','--cargo-arg=--config=profile.release.lto="fat"','--command-timeout','900']
 run('pgo-pipeline',argv,2400)
 latest=load(O/'pgo/latest.json');mp=Path(latest['manifest']);assert sha(mp)==latest['sha256'];m=load(mp);assert m['status']=='passed' and m['compared_parses']==288
 report['manifest']={'path':str(mp),'sha256':sha(mp)};report['libraries']=m['libraries_sha256'];report['workspace_vectors']={};report['normal_fat_deltas']={}
 for phase in ['generate','use']:
  command=next(x for x in m['commands'] if x['label']=='build-'+phase);rows=vectors((mp.parent/command['log']).read_text());report['workspace_vectors'][phase]=rows;report['normal_fat_deltas'][phase]=[]
  for a,b in zip(normal['workspace_vectors'],rows,strict=True):
   assert a['crate']==b['crate'] and normalize(a['argv'])==normalize(b['argv'])
   report['normal_fat_deltas'][phase].append({'crate':a['crate'],'delta':list(difflib.unified_diff(a['argv'],b['argv'],n=2))})
 nr=load(F/'training.json');g=load(mp.parent/'generate-training.json');u=load(mp.parent/'use-training.json');assert nr['status']==g['status']==u['status']=='passed' and len(g['rows'])==288 and nr['rows']==g['rows']==u['rows']
 oldinputs=Path(pair['pgo_manifest']['path']).parent/'inputs';assert load(mp.parent/'inputs/manifest.json')==load(oldinputs/'manifest.json')
 report['generated_records']={'previous_no_pgo_fat_replay':288,'fresh_instrumented_fat':288,'fresh_optimized_fat':288};report['all_generated_rows_exact']=True;report['new_raw_profile_directory']=str(mp.parent/'raw-profiles');report['status']='passed'
finally:
 report['source_tools_and_previous_studies_unchanged']=unchanged();report['tools_after']={p:sha(p) for p in pair['tools_before']};report['tools_unchanged']=report['tools_after']==pair['tools_before'];save()
assert report['source_tools_and_previous_studies_unchanged'] and report['tools_unchanged'];print(json.dumps({'status':report['status'],'libraries':report.get('libraries')}),flush=True)
