"""Prepare only: five-engine fixed native protocol; no worker execution."""
from pathlib import Path
import ast,difflib,hashlib,json,shutil
O=Path(__file__).parent;P=Path('/tmp/oriole-native-byte-count-pgo-study');F=Path('/tmp/oriole-native-byte-count-fat-lto-study');H=Path('/tmp/oriole-current-pgo-expat-reuse-proof');B=Path('/tmp/oriole-raw-len-split-thinlto-timing-study')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
pair=load(P/'pair-report.json');fat=load(F/'report.json');reuse=load(H/'review.json');assert pair['status']==fat['status']==reuse['status']=='passed'
for root,name in [(P,'pair-freeze.json'),(F,'freeze.json')]:assert all(sha(root/p)==h for p,h in load(root/name)['files_sha256'].items())
mp=Path(pair['pgo_manifest']['path']);libraries={'normal':P/'normal/liboriole_expat.so','pgo':mp.parent/'use/liboriole_expat.so','fat':F/'liboriole_expat.so','expat':Path(reuse['libraries']['control']['path']),'expat_pgo':Path(reuse['libraries']['use']['path'])}
ratios=[('pgo','normal'),('fat','normal'),('pgo','fat'),('normal','expat'),('pgo','expat_pgo'),('fat','expat'),('expat_pgo','expat')]
old=(B/'native_screen.py').read_text();tree=ast.parse(old)
scope='Native C callbacks on current be22 runtime: fresh explicit-host-target normal ThinLTO, fresh generated-only PGO ThinLTO and separate no-PGO fat LTO; pinned Expat2.8.4 normal and verified existing generated-only Expat PGO. Expat keeps GCC13.3 -O3/no-LTO; Oriole uses Rust/LLVM22 effective C-only LTO. Within-engine controls match. Six held-out real projects, both namespace modes, 4KiB/64KiB feeds, two existing generated controls at both widths. No application or fresh full correctness claim. All samples retained.'
changes=[]
def change(a,b):
 global old
 assert old.count(a)==1,(a,old.count(a));old=old.replace(a,b);changes.append((a,b))
change('"""Frozen paired native screen for the raw-length fallback split in a C-only ThinLTO build."""','"""Fixed five-engine current PGO and LTO native screen."""')
change(str(B),str(O))
for var,text in [('libraries',"libraries = {"+',\n             '.join(repr(k)+': Path('+repr(str(p))+')' for k,p in libraries.items())+'}'),('ratios','ratios = '+repr(ratios))]:
 n=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==var for t in n.targets));change(ast.get_source_segment((B/'native_screen.py').read_text(),n),text)
protocol=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='protocol' for t in n.targets))
oldscope=next(v.value for k,v in zip(protocol.value.keys,protocol.value.values) if isinstance(k,ast.Constant) and k.value=='scope');change(repr(oldscope),repr(scope))
change("'preflights': 84, 'timed_workers': 588","'preflights': 140, 'timed_workers': 980")
change("assert len(report['rows']) == 84","assert len(report['rows']) == 140")
change("'timed_workers': 3 * len(report['rows'])","'timed_workers': 5 * len(report['rows'])")
new=old;old=(B/'native_screen.py').read_text();newtree=ast.parse(new)
for name in ['run','digest','save']:
 a=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name);b=next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name==name);assert ast.dump(a)==ast.dump(b)
for name in ['iterations','conditions']:
 def find(t):return next(n for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==name for x in n.targets))
 assert ast.dump(find(tree))==ast.dump(find(newtree))
reverse=new
for a,b in reversed(changes):reverse=reverse.replace(b,a)
assert reverse==old
(O/'native_screen.py').write_text(new);shutil.copyfile(B/'run.py',O/'run.py')
(O/'controller.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(B/'native_screen.py'),tofile=str(O/'native_screen.py'))))
report={'status':'passed','stage':'prepared only; no target execution','changes':changes,'libraries':{k:{'path':str(p),'sha256':sha(p)} for k,p in libraries.items()},'ratios':ratios,'controller_sha256':sha(O/'native_screen.py'),'parent_controller_sha256':sha(B/'native_screen.py'),'wrapper_sha256':sha(O/'run.py'),'parent_wrapper_sha256':sha(B/'run.py'),'source_manifest_sha256':sha(P/'source.json'),'proofs_sha256':{str(p):sha(p) for p in [P/'pair-freeze.json',P/'vector-proof.json',F/'freeze.json',F/'vector-proof.json',H/'review.json']},'proof':'Worker run/digest/save plus iterations/conditions AST exact; reversible changes limited to paths, scope, engine/ratio lists and derived counts. Root-compatible wrapper byte-identical: sequential preflight CPU5 bound600 then exclusive CPU0 bound1200, each worker90; process-group kill/wait on timeout/interruption. No generic unbounded mode.','limits':{'worker_seconds':90,'preflight_seconds':600,'timing_aggregate_seconds':1200},'counts':{'conditions':28,'cohorts':196,'engines':5,'preflights':140,'timed_workers':980,'measured_samples':175700,'warmups':980},'scope':'Prepared protocol only. Use of generated training results is not full API/consumer certification. Expat reuse has explicit retrospective launch and old metadata caveats.'}
assert report['wrapper_sha256']==report['parent_wrapper_sha256'];(O/'adaptation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'patch':sha(O/'controller.patch'),'controller':sha(O/'native_screen.py'),'adaptation':sha(O/'adaptation.json')}))
