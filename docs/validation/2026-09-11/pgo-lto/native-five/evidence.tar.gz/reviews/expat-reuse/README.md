# Independent Expat PGO reuse review

Passed saved source, compiler, generated-input, profile and within-Expat callback-record checks. Historical GCC normal/PGO builds remain separate from fresh LLVM Oriole builds. No targets, compiler, profiler or timing ran.

The historical interpreter receipt is retrospective, training is two iterations with Python ctypes callbacks, and the generic historical source field names old Oriole rather than Expat. Expat identity is established separately. The old driver has no dladdr attestation; absolute CDLL path and file hashes are the retained binding evidence. See review.json for full limits.
