"""Bounded saved Expat PGO reuse check; no target/tool execution."""
from pathlib import Path
import hashlib,json,re,shlex
O=Path(__file__).parent;B=Path('/tmp/oriole-current-pgo-expat-reuse-proof');H=Path('/tmp/oriole-pgo-study');N=Path('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd')
sha=lambda b:hashlib.sha256(b).hexdigest();seen={}
def read(p):
 p=Path(p);b=p.read_bytes();seen[str(p)]=sha(b);return b
def js(p):return json.loads(read(p))
author=js(B/'review.json');supp=js(B/'diagnostic-and-generator-supplement.json');read(B/'verify.py')
assert author['status']==supp['status']=='passed'
for p,h in author['inputs_sha256'].items():assert sha(read(p))==h,p
source=js(H/'expat-source.json');assert len(source['files'])==167 and source['version']=='2.8.4'
for n,h in source['files'].items():assert sha(read(H/'expat-source'/n))==sha(read(Path(source['upstream'])/n))==h
vectors={};builds={}
for phase in ['control','generate','use']:
 b=js(H/f'expat-{phase}-build.json');builds[phase]=b
 assert b['status']=='passed' and b['source_manifest_sha256']==sha(read(H/'expat-source.json'))
 assert b['features']==builds['control']['features'] and b['compiler']==builds['control']['compiler'] and b['tools_sha256']==builds['control']['tools_sha256']
 assert b['generated_config_sha256']==builds['control']['generated_config_sha256']
 for c in b['commands']:assert c['returncode']==0 and sha(read(c['log']))==c['log_sha256']
 text=read(H/f'expat-{phase}-compile.log').decode();vectors[phase]=[shlex.split(x) for x in text.splitlines() if x.startswith('/usr/bin/cc ')]
 assert len(vectors[phase])==8 and len([x for x in vectors[phase] if '-c' in x])==7 and '-shared' in vectors[phase][-1]
 assert vectors[phase]==author['actual_compile_and_link_vectors'][phase]
 assert not re.search(r'(?mi)(?:^|\s)(?:warning|error):|profile.*(?:mismatch|missing)|coverage-mismatch|missing-profile',text)
 for v in vectors[phase]:
  flags=[x for x in v if x.startswith('-fprofile')]
  expected=[] if phase=='control' else [f'-fprofile-{phase}={H}/expat-raw-profiles',f'-fprofile-prefix-path={H}/expat-{phase}-build']
  assert flags==expected,(phase,flags)
  assert '-O3' in v and not any(x.startswith('-flto') for x in v)
for phase in ['generate','use']:
 def norm(v,p):return [x.replace(f'expat-{p}-build','expat-PHASE-build') for x in v if not x.startswith('-fprofile')]
 assert [norm(v,'control') for v in vectors['control']]==[norm(v,phase) for v in vectors[phase]]
old=js(H/'training-inputs.json');new=js(N/'inputs/manifest.json');assert old['seed']==new['seed'] and old['iterations']==1 and new['iterations']==2
assert len(old['rows'])==len(new['rows'])==12
for a,b in zip(old['rows'],new['rows'],strict=True):
 assert {k:v for k,v in a.items() if k!='path'}=={k:v for k,v in b.items() if k!='file'}
 assert read(a['path'])==read(N/'inputs'/b['file'])
expected=[(f['name'],ns,ch,ha,i) for f in old['rows'] for ns in f['namespaces'] for ch in f['chunks'] for ha in ['minimal','full'] for i in range(2)]
assert len(expected)==288
reports={}
for phase in ['control','generate','use']:
 d=js(H/f'expat-{phase}-training.json');reports[phase]=d
 assert d['status']=='passed' and d['library_sha256']==builds[phase]['library_sha256']
 assert d['script_sha256']==sha(read(H/'train.py')) and d['inputs_sha256']==sha(read(H/'training-inputs.json'))
 assert d['source_manifest_sha256']==sha(read(H/'source.json'))
 assert [tuple(r[k] for k in ['fixture','namespaces','chunk','handlers','iteration']) for r in d['rows']]==expected
 assert all(r['status']==1 and r['error']==0 and r['callback_exceptions']==[] for r in d['rows'])
assert reports['control']['rows']==reports['generate']['rows']==reports['use']['rows']
profile=js(H/'expat-profile.json');assert profile['status']=='passed' and profile['returncode']==0 and profile['stderr']=='' and len(profile['files'])==7
assert profile['source_manifest_sha256']==sha(read(H/'expat-source.json')) and profile['training_report_sha256']==sha(read(H/'expat-generate-training.json'))
for p,h in profile['files'].items():assert sha(read(H/p))==h
assert sha(read(H/'expat-profile-counts.txt'))==profile['counts_sha256']
assert set((H/'expat-raw-profiles').glob('*.gcda'))=={H/p for p in profile['files']}
launch=js(H/'training-launch-provenance.json');assert 'Retrospective' in launch['scope']
train=read(H/'train.py').decode();assert 'dladdr' not in train and 'lib=c.CDLL(str(libpath))' in train
assert 'for iteration in range(2)' in train
# Source-only interpretation: no execution/import of the historical parser driver.
read(H/'generate_training.py');read(H/'build_expat.py')
assert author['libraries']['control']['sha256']=='7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'
assert author['libraries']['use']['sha256']=='12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0'
report={'status':'independent_saved_expat_pgo_reuse_review_passed','scope':'Read-only check of retained historical Expat source/compiler/training/profile evidence and current generated-input identity; no parser/compiler/profiler execution and no elapsed claim.','source_files':167,'source_manifest_sha256':sha(read(H/'expat-source.json')),'compile_and_link_commands_per_phase':8,'generated_rows_per_phase':288,'saved_training_rows':864,'same_current_generated_inputs':12,'native_GCC_profile_files':7,'libraries':author['libraries'],'author_review_sha256':seen[str(B/'review.json')],'blockers':[],
 'limitations':author['limitations']+['Historical train.py uses an absolute ctypes.CDLL handle and hashes that library, but has no same-process dladdr attestation. Do not attribute current Oriole origin checks to these historical Expat runs.','Historical setup occurs before free-finally and content-model callback does not use a separate finally around free_model; saved successful rows have zero callback faults. No claim of comprehensive failure-cleanup correctness follows from reuse.','Profile file/dump identities and profile-use command paths are checked; gcov-dump or a profile merger was not rerun. No new Expat training/fresh-build claim.'],
 'checked_files':len(seen),'all_inspected_inputs_unchanged':True,'generator_sha256':sha(Path(__file__).read_bytes())}
for p,h in seen.items():assert sha(Path(p).read_bytes())==h
(O/'checked-files.json').write_text(json.dumps(seen,indent=2)+'\n');(O/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'review_sha256':sha((O/'review.json').read_bytes()),'files':len(seen)}))
