"""Bounded saved fat-LTO supplement; no producer imports or target execution."""
from pathlib import Path
import difflib, hashlib, json, os, re, shlex

O=Path(__file__).parent
F=Path('/tmp/oriole-native-byte-count-fat-lto-study')
P=Path('/tmp/oriole-native-byte-count-pgo-study')
W=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')
checked={}; checks=[]
def data(p):
    p=Path(p); b=p.read_bytes(); record={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
    assert str(p) not in checked or checked[str(p)]==record
    checked[str(p)]=record
    return b
def sha(p):
    p=Path(p)
    with p.open('rb') as f: digest=hashlib.file_digest(f,'sha256').hexdigest()
    record={'sha256':digest,'bytes':p.stat().st_size}
    assert str(p) not in checked or checked[str(p)]==record
    checked[str(p)]=record
    return digest
def load(p): return json.loads(data(p))
def check(label,value):
    checks.append({'check':label,'passed':bool(value)})
    assert value,label
def write(name,value): (O/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def vectors(path):
    result=[]
    for line in data(path).decode().splitlines():
        m=re.fullmatch(r'\s*Running `(.*)`',line)
        if not m: continue
        argv=shlex.split(m[1])
        if '--crate-name' not in argv: continue
        result.append({'crate':argv[argv.index('--crate-name')+1],'argv':argv,'line':line})
    return result
def norm(argv):
    result=[]
    for i,a in enumerate(argv):
        if i and argv[i-1]=='-C':
            a=re.sub(r'^metadata=[0-9a-f]{16}$','metadata=CARGO_HASH',a)
            a=re.sub(r'^extra-filename=-[0-9a-f]{16}$','extra-filename=-ARTIFACT_HASH',a)
            if a in ['lto=thin','lto=fat']: a='lto=COMPARISON'
        if i and argv[i-1]=='--extern': a=re.sub(r'(?<=-)[0-9a-f]{16}(?=\.(?:rlib|rmeta)$)','ARTIFACT_HASH',a)
        result.append(a)
    return result

check('CPU 4 saved-data audit only',__debug__ and os.sched_getaffinity(0)=={4})
dependencies={
 '/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json':'cec78c70730e111f139a6fab70089e1629ffe3336843106585a35922a525bbc9',
 '/tmp/oriole-native-byte-count-pgo-training-independent-review/review.json':'9e7a8451c1429ea888904ae16ba6c120e0a86ec4e4695a72bfe7dce5ff9e0934'}
for path,digest in dependencies.items(): check('sealed reused review: '+path,sha(path)==digest and load(path)['status']=='passed')
check('pinned fat freeze',sha(F/'freeze.json')=='de96beb44048a7fe9bc7087c63e1a909d9a5cf45d22aebed995e5ccaec8280ae')
freeze=load(F/'freeze.json')
check('complete fat nine-member file inventory',freeze['status']=='frozen' and len(freeze['files_sha256'])==9 and set(freeze['files_sha256'])|{'freeze.json'}=={p.name for p in F.iterdir() if p.is_file()})
for n,h in freeze['files_sha256'].items(): check('fat frozen bytes: '+n,sha(F/n)==h)
pair=load(P/'pair-report.json'); source=load(P/'source.json'); scripts=load(P/'tool-source.json')
pairfreeze=load(P/'pair-freeze.json'); report=load(F/'report.json'); proof=load(F/'vector-proof.json')
check('pair freeze identity unchanged',sha(P/'pair-freeze.json')==report['pair_freeze_sha256']=='0aa2605be71abb0e7bf4ca48281de6a760d5e11595b98e98f717a4c585a1b14c')
for n,h in pairfreeze['files_sha256'].items(): check('original pair bytes unchanged: '+n,sha(P/n)==h)
check('source manifest reused exact',sha(P/'source.json')==report['source_manifest_sha256']=='d1e021143e45331358ea63dcb20663e80d808fc7cee87510dc59e076b803451f' and len(source['source_sha256'])==70)
for n,h in source['source_sha256'].items(): check('current source unchanged: '+n,sha(W/n)==h)
for n,h in scripts.items(): check('current PGO tool unchanged: '+n,sha(W/n)==h)
check('all final statuses',report['status']==proof['status']=='passed' and report['pair_and_source_unchanged'] and report['tools_unchanged'])
check('exact prior eight tools',report['tools_before']==report['tools_after']==pair['tools_before'])
for path,h in report['tools_before'].items(): check('current compiler/Python/LLVM bytes: '+path,sha(path)==h)
check('fat env only expected overrides',report['env_overrides']==pair['env_overrides']|{'CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/native-byte-count-fat-lto-target','RUSTC':pair['normal_vectors'][0]['argv'][0]})
normalcmd=next(r['argv'] for r in pair['commands'] if r['label']=='normal-build')
expectedcmd=normalcmd.copy(); expectedcmd.insert(expectedcmd.index('rustc'),'--config=profile.release.lto="fat"')
check('only build/replay commands', [r['label'] for r in report['commands']]==['fat-build','generated-replay'])
check('fat cargo command adds only explicit LTO config',report['commands'][0]['argv']==expectedcmd)
for row in report['commands']:
    check('saved successful command: '+row['label'],row['exit']==0 and row['cwd']==str(W) and row['cpu']==1 and row['timeout']==(900 if row['label']=='fat-build' else 300) and row['log_sha256']==sha(F/(row['label']+'.log')))
normal=vectors(P/'normal-build.log'); fat=vectors(F/'fat-build.log')
order=['allocator_api2','hashbrown','oriole_storage','memchr','oriole','oriole_expat']
check('six actual compiler invocations each', [r['crate'] for r in normal]==[r['crate'] for r in fat]==order)
check('fat producer all raw vectors exact',fat==report['all_fresh_rustc_vectors'])
check('fat producer three workspace vectors exact',[r for r in fat if r['crate'].startswith('oriole')]==report['workspace_vectors'])
check('proof origins match raw logs',sha(P/'normal-build.log')==proof['normal_log_sha256'] and sha(F/'fat-build.log')==proof['fat_log_sha256'])
check('six proof entries',len(proof['all_six_actual_rustc_vectors'])==6)
comparisons=[]
for n,f,author in zip(normal,fat,proof['all_six_actual_rustc_vectors']):
    crate=n['crate']; a=n['argv']; b=f['argv']; delta=list(difflib.unified_diff(a,b,n=2))
    check('raw proof and delta exact: '+crate,author['crate']==crate and author['raw_normal']==a and author['raw_fat']==b and author['raw_delta']==delta)
    check('full normalized vectors exact: '+crate,norm(a)==norm(b))
    for phase,args in [('normal',a),('fat',b)]:
        cg=[args[i+1] if x=='-C' else x[2:] for i,x in enumerate(args) if x.startswith('-C')]
        types=[args[i+1] for i,x in enumerate(args[:-1]) if x=='--crate-type']
        check('effective build flags: '+phase+'/'+crate,'opt-level=3' in cg and 'codegen-units=1' in cg and args[0]==report['env_overrides']['RUSTC'] and args[args.index('--target')+1]==pair['host'] and not any('profile-use' in x or 'profile-generate' in x or 'pgo-' in x for x in args))
        check('effective LTO/output types: '+phase+'/'+crate,types==(['cdylib','staticlib'] if crate=='oriole_expat' else ['lib']) and ('lto='+('thin' if phase=='normal' else 'fat') if crate=='oriole_expat' else 'linker-plugin-lto') in cg)
    comparisons.append({'crate':crate,'normal_argv':a,'fat_argv':b,'delta':delta,'normalized':norm(a)})
    if crate.startswith('oriole'):
        check('workspace delta exact: '+crate,next(r['delta'] for r in report['workspace_deltas'] if r['crate']==crate)==delta)
check('two retained fat artifacts',set(report['libraries'])=={'liboriole_expat.so','liboriole_expat.a'})
for n,h in report['libraries'].items(): check('retained fat library: '+n,sha(F/n)==h)
training=load(F/'training.json'); normal_training=load(P/'normal-training.json')
inputs=Path(pair['pgo_manifest']['path']).parent/'inputs'
check('fat training complete and byte-for-byte row values equal normal',training['status']=='passed' and len(training['rows'])==report['generated_parses']==288 and report['all_rows_exact_normal'] and training['rows']==normal_training['rows'])
check('fat training actual library origin',training['xml_parse_origin']=={'path':str(F/'liboriole_expat.so'),'sha256':report['libraries']['liboriole_expat.so']} and training['library_sha256']==sha(F/'liboriole_expat.so'))
check('fat training reused input/script identities',training['inputs_sha256']==normal_training['inputs_sha256']==sha(inputs/'manifest.json') and training['script_sha256']==normal_training['script_sha256']==scripts['tools/pgo/train.py'])
check('fat no profiling environment',training['profile_file_environment'] is None and report['env_overrides']['CARGO_ENCODED_RUSTFLAGS']=='')
expectedreplay=[report['commands'][1]['argv'][0],'-I','-S',str(W/'tools/pgo/train.py'),'--library',str(F/'liboriole_expat.so'),'--inputs',str(inputs),'--report',str(F/'training.json')]
check('fat replay exact inherited driver command',report['commands'][1]['argv']==expectedreplay and expectedreplay[0] in report['tools_before'])
for path,record in list(checked.items()): check('final input readback unchanged: '+path,sha(path)==record['sha256'])
review={'status':'passed','scope':'Saved fat-LTO source/compiler and generated replay supplement; no target executions or elapsed-performance review.',
 'study':str(F),'freeze_sha256':checked[str(F/'freeze.json')]['sha256'],'fat_frozen_files':9,'preserved_pair_files':52,
 'reused_reviews':dependencies,'source_manifest_sha256':report['source_manifest_sha256'],'current_source_records':70,'current_tool_source_records':6,
 'source_archived_commit_proof':'Reused exact cec78c review establishes archived/live/be22 equality; this supplement freshly rehashes all 70 live sources and six tools and confirms the same manifest.',
 'actual_compiler_vectors_per_build':6,'workspace_crates':3,'registry_dependencies':3,
 'compiler_conclusion':'Full normal/fat vectors differ only in final C root lto=thin to lto=fat, Cargo metadata and artifact suffixes. All five dependencies retain linker-plugin-lto. Compiler paths, source paths, target, diagnostics, outputs and remaining flags match. No PGO options.',
 'libraries_sha256':report['libraries'],'normal_control_libraries_sha256':pair['normal_libraries'],
 'training_rows':288,'training_rows_exact_normal':True,'training_library_origin_verified':True,
 'training_scope':'Exact all-row comparison to normal replay whose fixture construction, row coverage and driver semantics are covered by sealed 9e7a8451 review; no fixture or parser rerun.',
 'tools_before_after_and_current':8,'checks':len(checks),'checked_files':len(checked),
 'limitations':['Inherited environment is only allowlisted in saved records; actual compiler vectors establish reviewed flags.','Saved build/replay completion is not an elapsed benchmark or an adoption conclusion.','Concurrent native timing study is excluded.'],
 'execution':'CPU 4 standard-library Python file/hash/JSON/command-text audit only; producer modules were neither imported nor executed.'}
write('compiler-comparisons.json',comparisons);write('checked-files.json',checked);write('checks.json',checks);write('review.json',review)
print(json.dumps({'status':'passed','checks':len(checks),'checked_files':len(checked),'review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest()}))
