from pathlib import Path
import hashlib,json,os
p=Path(__file__).parent
assert os.sched_getaffinity(0)=={4}
sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
load=lambda n:json.loads((p/n).read_text())
r=load('review.json');a=load('attempt02.json');first=load('attempt01.json')
assert r['status']=='passed' and a['returncode']==0 and first['returncode']==1
assert a['generator_sha256']==sha(p/'generator.py') and first['generator_sha256']==sha(p/'generator-attempt01.py')
for name,record in [('attempt01',first),('attempt02',a)]:
 assert record['stdout_sha256']==sha(p/(name+'.stdout')) and record['stderr_sha256']==sha(p/(name+'.stderr'))
assert not (p/'attempt02.stderr').read_bytes()
assert len(load('checks.json'))==r['checks']==360 and all(c['passed'] for c in load('checks.json'))
receipt={'status':'passed','review_sha256':sha(p/'review.json'),'generator_sha256':sha(p/'generator.py'),'checks':r['checks'],'checked_files':r['checked_files'],'attempts':2,'reviewer_correction':'One prior-receipt status literal; producer data unchanged.','scope':r['scope']}
(p/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
files={q.name:{'sha256':sha(q),'bytes':q.stat().st_size} for q in sorted(p.iterdir()) if q.is_file() and q.name!='files.json'}
(p/'files.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n')
assert all(sha(p/n)==v['sha256'] for n,v in files.items())
print(json.dumps({'review_sha256':sha(p/'review.json'),'receipt_sha256':sha(p/'receipt.json'),'files_sha256':sha(p/'files.json'),'indexed_files':len(files)}))
