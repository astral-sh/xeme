# Current five-engine native study: independent audit

Passed the first saved-data audit attempt: 11,427 assertions across 1,177 inspected files. No target, compiler, parser, profiler or timing jobs ran. No large assertion array is emitted; `generator.py` retains the checks.

The final freeze contains 1,139 files. All 140 preflight workers and 980 timed workers match their immediate raw records. All 176,960 samples, including preflights and warmups, reconcile. The audit reproduces 196 seeded cohorts, 1,372 paired ratios and 196 condition-ratio medians. Exactly 175,700 timed samples remain after excluding one warmup per timed worker.

| Real-input comparison | Geometric mean | Conditions below 1 |
| --- | ---: | ---: |
| Oriole PGO / normal | 0.7518974454 | 24 / 24 |
| Oriole fat / normal | 0.9717715325 | 20 / 24 |
| Expat PGO / normal | 0.8674024396 | 24 / 24 |
| Oriole PGO / Expat PGO | 1.4023291166 | 4 / 24 |

All 28 conditions and all seven comparisons remain in `conditions.json`. `adverse-conditions.json` retains every ratio above one, including four real and one generated fat-LTO regression and all PGO-versus-PGO losses. Generated controls are reported separately.

`review.json` links sealed Oriole source/build, training, fat-LTO, Expat reuse and prior native-method reviews. The worker and fixed-condition ASTs remain exact; controller changes are the eight recorded engine/ratio/count/path/prose substitutions. The wrapper is byte-identical to the reviewed parent. The preserved core adaptation in `core-adaptation.patch` changes only five-engine handling and derived counts in the prior independent arithmetic audit.

This is one shared-host run, with CPU 4 preparation overlap recorded by the author. Native timing includes parser construction, callback setup, parsing and destruction. It excludes file loading, dynamic-library loading and process startup. The result does not establish full application performance, full API conformance, statistical significance or an adoption decision. Expat's historical reuse caveats remain linked in its separate review.
