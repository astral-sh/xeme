"""Reuse the previously sealed independent native raw arithmetic core only."""
from pathlib import Path
import hashlib,json,difflib
o=Path(__file__).parent;prior=Path('/tmp/oriole-raw-len-split-native-independent-review/generator.py')
text=prior.read_text();begin=text.index('ordinal=0;streams=[];');end=text.index("published=j(R/'summary.json')",begin);core=text[begin:end]
replacements=[
 ("engine=='expat'","engine.startswith('expat')"),
 ("ck('84 preflight records',len(pre['rows'])==84)","ck('140 preflight records',len(pre['rows'])==140)"),
 ("pre['rows'][3*index:3*index+3]","pre['rows'][5*index:5*index+5]"),
 ("ck('three-engine preflight observations '+str(index),observations[0]==observations[1]==observations[2])","ck('five-engine preflight observations '+str(index),all(x==observations[0] for x in observations))"),
 ("all588 paired ratios and84 medians exact","all1372 paired ratios and196 medians exact"),
 ("exact672 immediate worker files no extras","exact1120 immediate worker files no extras"),
 ("ordinal==672","ordinal==1120"),("range(672)","range(1120)"),
 ("{'preflight_workers':84,'preflight_warmups':84,'preflight_measured':84,'timed_workers':588,'timed_warmups':588,'timed_measured':105420}","{'preflight_workers':140,'preflight_warmups':140,'preflight_measured':140,'timed_workers':980,'timed_warmups':980,'timed_measured':175700}")]
new=core
for a,b in replacements:
 assert new.count(a)==1,a
 new=new.replace(a,b)
(o/'core-adaptation.patch').write_text(''.join(difflib.unified_diff(core.splitlines(True),new.splitlines(True),fromfile='prior-independent-core',tofile='five-engine-independent-core')))
(o/'generator.py').write_text((o/'setup.py').read_text()+'\n'+new+'\n'+(o/'tail.py').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(o/'method.json').write_text(json.dumps({'prior_generator':str(prior),'prior_generator_sha256':sha(prior),'generator_sha256':sha(o/'generator.py'),'replacements':replacements,'scope':'Exact prior independent raw worker/sample/median/shuffle/ratio core, changed only five-engine versions, preflight grouping and derived counts. No producer import or execution.'},indent=2)+'\n')
