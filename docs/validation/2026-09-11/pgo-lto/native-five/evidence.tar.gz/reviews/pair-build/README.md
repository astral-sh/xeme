# Fresh PGO pair: independent build/source review

Passed saved-evidence review of the 52-file pair freeze, 70 runtime sources, six unchanged PGO tools, and nine actual workspace compiler invocations. All archived/live sources match commit `be22a271f8a5c004d13e515cd4024a68afe57887`.

Normal, generate and use compile the same C-only shared/static root with ThinLTO. The complete compiler vectors match after removing only the exact phase profile options and replacing Cargo artifact hash suffixes; compiler, metadata, paths and other options remain exact. The fresh explicit-host normal artifacts (`0c8c…`/`9753…`) remain distinct from prior implicit-target artifacts (`ccfb…`/`f58d…`).

`review.json` is the compact conclusion. `generator.py` retains the audit; the supporting JSON records contain all source hashes, actual/normalized compiler vectors and deltas. First audit attempt passed 593 checks over 144 files and 78 read-only Git queries. `attempt01.json` records its execution; `files.json` indexes this directory excluding itself.

The compiler and profiler both report LLVM 22.1.8 but come from distinct Rust distributions; executable and LLVM library bytes are individually pinned. Only allowlisted environment values are recorded. No compiler, parser, profiler, training or timing job was run by this reviewer; the concurrent fat-LTO study is outside scope.

Training/profile semantics are covered separately by `/tmp/oriole-native-byte-count-pgo-training-independent-review/review.json`, SHA-256 `9e7a8451c1429ea888904ae16ba6c120e0a86ec4e4695a72bfe7dce5ff9e0934`. This review only checked those frozen file bytes.
