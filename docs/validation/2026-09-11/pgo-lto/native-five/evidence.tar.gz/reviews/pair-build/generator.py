"""Read-only source/compiler audit; never imports or executes producer tools."""
from pathlib import Path
import ast
import difflib
import hashlib
import io
import json
import os
import re
import shlex
import subprocess
import tarfile
import tomllib

OUT = Path(__file__).parent
STUDY = Path('/tmp/oriole-native-byte-count-pgo-study')
WORK = Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo')
RUN = STUDY / 'pgo/runs/run-7_l2jvbd'
BASE = 'be22a271f8a5c004d13e515cd4024a68afe57887'
FREEZE = '0aa2605be71abb0e7bf4ca48281de6a760d5e11595b98e98f717a4c585a1b14c'
HOST = 'x86_64-unknown-linux-gnu'
CRATES = ['oriole_storage', 'oriole', 'oriole_expat']
checked = {}
checks = []
git_reads = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(label, condition):
    checks.append({'check': label, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(label)

def read(path):
    path = Path(path)
    data = path.read_bytes()
    value = {'sha256': sha(data), 'bytes': len(data)}
    if str(path) in checked:
        check('repeated input stable: ' + str(path), checked[str(path)] == value)
    checked[str(path)] = value
    return data

def hashfile(path):
    path = Path(path)
    with path.open('rb') as stream:
        value = {'sha256': hashlib.file_digest(stream, 'sha256').hexdigest(), 'bytes': path.stat().st_size}
    if str(path) in checked:
        check('repeated input stable: ' + str(path), checked[str(path)] == value)
    checked[str(path)] = value
    return value['sha256']

def load(path):
    return json.loads(read(path))

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def git(*args):
    command = ['git', '-C', str(WORK), *args]
    result = subprocess.run(command, capture_output=True, check=True)
    git_reads.append({'argv': command, 'returncode': result.returncode,
                      'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})
    return result.stdout

def archive(path, expected):
    rows = []
    with tarfile.open(fileobj=io.BytesIO(read(path)), mode='r:gz') as tar:
        members = tar.getmembers()
        check('archive exact member names: ' + path.name, sorted(m.name for m in members) == sorted(expected))
        for m in members:
            check('archive regular safe member: ' + m.name, m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts)
            data = tar.extractfile(m).read()
            actual = sha(data)
            live = hashfile(WORK / m.name)
            commit = sha(git('show', BASE + ':' + m.name))
            check('archive/live/commit/manifest: ' + m.name, actual == live == commit == expected[m.name])
            rows.append({'path': m.name, 'archive_sha256': actual, 'live_sha256': live,
                         'commit_sha256': commit, 'bytes': len(data)})
    return rows

def vectors(path):
    result = []
    for line in read(path).decode().splitlines():
        match = re.fullmatch(r'\s*Running `(.*)`', line)
        if not match:
            continue
        args = shlex.split(match[1])
        if '--crate-name' not in args:
            continue
        crate = args[args.index('--crate-name') + 1]
        if crate not in CRATES:
            continue
        result.append({'crate': crate, 'line': line, 'argv': args,
                       'codegen': [args[i+1] for i, x in enumerate(args[:-1]) if x == '-C'],
                       'types': [args[i+1] for i, x in enumerate(args[:-1]) if x == '--crate-type']})
    check('exact fresh workspace compile sequence: ' + path.name, [r['crate'] for r in result] == CRATES)
    return result

def effective_codegen(args):
    result = []
    for i, arg in enumerate(args):
        if arg == '-C':
            result.append(args[i + 1])
        elif arg.startswith('-C'):
            result.append(arg[2:])
    return result

def normalize(args, phase):
    expected_profiles = {
        'normal': [],
        'generate': ['-Cprofile-generate=' + str(RUN / 'raw-profiles')],
        'use': ['-Cprofile-use=' + str(RUN / 'merged.profdata'), '-Cllvm-args=-pgo-warn-missing-function'],
    }[phase]
    actual_profiles = [a for a in args if any(x in a for x in ('profile-generate', 'profile-use', 'pgo-warn'))]
    check('exact profile arguments: ' + phase + '/' + args[2], actual_profiles == expected_profiles)
    normalized = []
    for i, arg in enumerate(args):
        if arg in expected_profiles:
            continue
        if i and args[i - 1] == '-C' and re.fullmatch(r'extra-filename=-[0-9a-f]{16}', arg):
            arg = 'extra-filename=-ARTIFACT_HASH'
        if i and args[i - 1] == '--extern':
            arg = re.sub(r'(?<=-)[0-9a-f]{16}(?=\.(?:rlib|rmeta)$)', 'ARTIFACT_HASH', arg)
        normalized.append(arg)
    return normalized

check('auditor CPU 4, assertions enabled', __debug__ and os.sched_getaffinity(0) == {4})
check('pinned pair freeze', hashfile(STUDY / 'pair-freeze.json') == FREEZE)
freeze = load(STUDY / 'pair-freeze.json')
check('freeze status and count', freeze['status'] == 'frozen' and len(freeze['files_sha256']) == 52)
for name, digest in freeze['files_sha256'].items():
    check('safe frozen relative path: ' + name, not Path(name).is_absolute() and '..' not in Path(name).parts)
    check('frozen bytes: ' + name, hashfile(STUDY / name) == digest)
source = load(STUDY / 'source.json')
scripts = load(STUDY / 'tool-source.json')
pair = load(STUDY / 'pair-report.json')
manifest = load(RUN / 'manifest.json')
latest = load(STUDY / 'pgo/latest.json')
proof = load(STUDY / 'vector-proof.json')
check('pair status', pair['status'] == manifest['status'] == proof['status'] == 'passed')
check('source identity and size', source['base'] == BASE and source['worktree'] == str(WORK) and len(source['source_sha256']) == 70)
check('source and script pinned reports', pair['source_manifest_sha256'] == hashfile(STUDY / 'source.json') and pair['script_source_sha256'] == hashfile(STUDY / 'tool-source.json'))
check('worktree HEAD', git('rev-parse', 'HEAD').decode().strip() == BASE)
check('live worktree tracked files clean', git('diff', '--name-only', BASE).decode() == '')
source_rows = archive(STUDY / 'source.tar.gz', source['source_sha256'])
script_rows = archive(STUDY / 'tool-source.tar.gz', scripts)
check('six expected PGO tool sources', set(scripts) == {'tools/pgo/' + n for n in ['README.md','__init__.py','build.py','corpus.py','test_build.py','train.py']})
old_source = load(Path('/tmp/oriole-native-byte-count-study/source.json'))
check('runtime source map exactly prior selected integration', source['source_sha256'] == old_source['source_sha256'])
omitted = sorted(set(source['source_sha256']) - set(manifest['source_sha256']))
check('inner scope exactly outer minus C consumers', omitted == ['tests/c/adversarial.c','tests/c/allocations.c','tests/c/integration.c'] and len(manifest['source_sha256']) == 67 and all(source['source_sha256'].get(k) == v for k,v in manifest['source_sha256'].items()))
check('inner six scripts exact outer', {'tools/pgo/' + k: v for k,v in manifest['script_sha256'].items()} == scripts)
check('latest/pair manifest origin', latest == {'manifest':str(RUN/'manifest.json'),'sha256':hashfile(RUN/'manifest.json')} and pair['pgo_manifest'] == {'path':str(RUN/'manifest.json'),'sha256':latest['sha256']})
check('vector proof origin', proof['pair_report_sha256'] == hashfile(STUDY/'pair-report.json'))
for name,digest in manifest['cargo_config_sha256'].items():
    check('Cargo config bytes: ' + name, hashfile(name) == digest)
config_candidates = [directory / '.cargo' / name for directory in [WORK,*WORK.parents] for name in ['config','config.toml']]
config_candidates += [Path(pair['env_overrides']['CARGO_HOME']) / name for name in ['config','config.toml']]
actual_configs = {str(p.resolve()):hashfile(p) for p in config_candidates if p.is_file()}
check('complete inherited Cargo config discovery', actual_configs == manifest['cargo_config_sha256'])
check('effective Cargo config no build flags', all(set(tomllib.loads(read(p).decode())) == {'source'} for p in actual_configs))
cargo_toml = tomllib.loads(read(WORK/'Cargo.toml').decode())
check('release profile ThinLTO and one codegen unit', cargo_toml['profile']['release'] == {'lto':'thin','codegen-units':1})
check('pair tools before/after unchanged', pair['tools_before'] == pair['tools_after'] and pair['tools_unchanged'] is True and len(pair['tools_before']) == 8)
check('inner tools superset adds rustup', len(manifest['tools_sha256']) == 9 and all(manifest['tools_sha256'].get(k) == v for k,v in pair['tools_before'].items()) and set(manifest['tools_sha256'])-set(pair['tools_before']) == {'/home/dev-user/.cargo/bin/rustup'})
for path,digest in manifest['tools_sha256'].items():
    check('compiler/profiler/Python/LLVM bytes: ' + path, hashfile(path) == digest)
check('compiler version reports exact raw', read(STUDY/'rustc-version.log').decode() == pair['rustc_version'] == manifest['rustc_version'])
check('profiler version report exact raw', read(STUDY/'profdata-version.log').decode() == manifest['profdata_version'])
compiler = read(STUDY/'sysroot.log').decode().strip() + '/bin/rustc'
llvm_versions = [re.search(r'LLVM version:?\s+(\d+\.\d+\.\d+)', text)[1] for text in [pair['rustc_version'],manifest['profdata_version']]]
check('LLVM numeric major/minor/patch compatibility', llvm_versions == ['22.1.8','22.1.8'])
check('host and toolchain', pair['host'] == manifest['host'] == HOST and manifest['toolchain'] == 'ohm' and manifest['cargo_args'] == ['-Zohm-defaults=no'] and manifest['base_rustflags'] == [])
producer = read(STUDY/'build_pair.py').decode()
producer_ast = ast.parse(producer)
literal_overrides = next(ast.literal_eval(n.value) for n in producer_ast.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='overrides' for t in n.targets))
check('outer reported overrides exact controller source', literal_overrides == pair['env_overrides'])
check('outer successful unchanged assertions', all(pair[k] is True for k in ['source_unchanged','scripts_unchanged','tools_unchanged']))
check('six outer commands exact order', [r['label'] for r in pair['commands']] == ['rustc-version','sysroot','profdata-version','normal-build','pgo-pipeline','normal-generated-replay'])
for row in pair['commands']:
    check('outer command success/bounds: '+row['label'], row['exit']==0 and row['cpu']==1 and row['cwd']==str(WORK) and row['end']>=row['start'] and row['timeout']>0)
    check('outer command log hash: '+row['label'], hashfile(STUDY/(row['label']+'.log')) == row['log_sha256'])
check('ten inner commands complete', len(manifest['commands']) == 10 and manifest['cpu_affinity'] == [1])
for row in manifest['commands']:
    check('inner command success/bounds: '+row['label'], row['status']=='passed' and row['returncode']==0 and row['cwd']==str(WORK) and row['timeout_seconds']==900.0)
    check('inner command log hash: '+row['label'], hashfile(RUN/row['log']) == row['log_sha256'])
normal_command = next(r for r in pair['commands'] if r['label']=='normal-build')
check('normal complete cargo invocation', normal_command['argv']==['cargo','+ohm','-Zohm-defaults=no','rustc','--release','--locked','--offline','--target',HOST,'-p','oriole_expat','--lib','--crate-type','cdylib,staticlib','--verbose'])
actual = {'normal':vectors(STUDY/'normal-build.log')}
build_envs = {}
for phase in ['generate','use']:
    entry=next(r for r in manifest['commands'] if r['label']=='build-'+phase)
    check('matched cargo argv: '+phase, entry['argv'][1:]==normal_command['argv'][1:] and entry['argv'][0]=='/home/dev-user/.cargo/bin/cargo')
    actual[phase]=vectors(RUN/entry['log'])
    env=entry['environment']
    check('direct selected compiler: '+phase, env['RUSTC']==compiler)
    check('isolated phase output path: '+phase, env['CARGO_TARGET_DIR']==str(STUDY/'pgo/targets'/phase))
    build_envs[phase]={k:v for k,v in env.items() if k not in ['CARGO_TARGET_DIR','CARGO_ENCODED_RUSTFLAGS']}
check('generate/use environment exact except phase flags and targets',build_envs['generate']==build_envs['use'])
normalized={}
effective=[]
for phase,rows in actual.items():
    check('raw workspace rows equal producer: '+phase, rows==(pair['normal_vectors'] if phase=='normal' else pair['pgo_vectors'][phase]))
    normalized[phase]={}
    for row in rows:
        crate=row['crate'];args=row['argv'];cg=effective_codegen(args)
        check('actual compiler executable: '+phase+'/'+crate,args[0]==compiler)
        check('actual explicit host: '+phase+'/'+crate,args.count('--target')==1 and args[args.index('--target')+1]==HOST)
        check('actual optimization and no Ohm injected flags: '+phase+'/'+crate, 'opt-level=3' in cg and 'codegen-units=1' in cg and not any(a.startswith('-Z') for a in args))
        check('actual types/LTO: '+phase+'/'+crate,row['types']==(['cdylib','staticlib'] if crate=='oriole_expat' else ['lib']) and ('lto=thin' if crate=='oriole_expat' else 'linker-plugin-lto') in cg and not any('lto=fat' in a for a in cg))
        normalized[phase][crate]=normalize(args,phase)
        effective.append({'phase':phase,'crate':crate,'codegen_including_compact_flags':cg,'crate_types':row['types']})
check('all three full normalized vectors exact across all phases',normalized['normal']==normalized['generate']==normalized['use'])
deltas=[]
for phase in ['generate','use']:
    for before,after in zip(actual['normal'],actual[phase]):
        delta=list(difflib.unified_diff(before['argv'],after['argv'],n=2))
        author=next(r for r in proof['vectors'] if r['phase']==phase and r['crate']==before['crate'])
        check('author delta exact raw reconstruction: '+phase+'/'+before['crate'],author['delta']==delta and author['matching_except_profile_flags_and_artifact_hash_suffixes'] is True)
        deltas.append({'phase':phase,'crate':before['crate'],'delta':delta})
check('six author proof vectors',len(proof['vectors'])==6)
libraries={}
check('PGO library maps exact',pair['pgo_libraries']==manifest['libraries_sha256'] and len(pair['pgo_libraries'])==4)
for phase,root,mapping in [('normal',STUDY/'normal',pair['normal_libraries']),('pgo',RUN,pair['pgo_libraries'])]:
    for name,digest in mapping.items():
        check('retained library bytes: '+phase+'/'+name,hashfile(root/name)==digest)
        libraries[phase+'/'+name]=digest
old_build=Path('/tmp/oriole-native-byte-count-thinlto-study')
old_report=load(old_build/'report.json')
prior_review=Path('/tmp/oriole-native-byte-count-source-build-independent-review/review.json')
check('prior selected build independent receipt',hashfile(prior_review)=='f1f801a46736344b8fae130ed3ca815c9d71c542c0dda15b098cd5e784c0d886')
for name,digest in old_report['libraries'].items():
    check('prior implicit-target library remains distinct: '+name,hashfile(old_build/name)==digest and digest!=pair['normal_libraries'][name] and pair['normal_identical_to_implicit_target'][name] is False)
for path,record in list(checked.items()):
    with Path(path).open('rb') as stream:
        check('all audit inputs unchanged on final read: '+path,hashlib.file_digest(stream,'sha256').hexdigest()==record['sha256'])
write('source-records.json',source_rows)
write('tool-source-records.json',script_rows)
write('compiler-vectors.json',actual)
write('normalized-vectors.json',normalized)
write('effective-codegen.json',effective)
write('compiler-deltas.json',deltas)
write('git-reads.json',git_reads)
write('checked-files.json',checked)
write('checks.json',checks)
review={
 'status':'passed','scope':'Saved fresh explicit-host normal/generate/use source and build provenance only; no producer or target executions.',
 'study':str(STUDY),'pair_freeze_sha256':FREEZE,'frozen_files_checked':52,
 'source_manifest_sha256':checked[str(STUDY/'source.json')]['sha256'],'commit':BASE,
 'source_records':70,'script_records':6,'archived_live_commit_all_equal':True,
 'inner_source_records':67,'inner_source_omissions':omitted,
 'fresh_workspace_compiles_per_phase':3,'total_workspace_compiles':9,
 'effective_build':'All phases compile only cdylib and staticlib at the C ABI root, with lto=thin, opt-level=3, codegen-units=1; two Rust workspace dependencies use linker-plugin-lto.',
 'vector_comparison':'All three complete rustc vectors match across phases after removing only the exact current phase profile flags and replacing extra-filename and extern artifact hash suffixes. Compiler, metadata, all paths, target, emits, diagnostics, crate types and other flags remain exact.',
 'retained_libraries_sha256':libraries,'prior_implicit_target_libraries_sha256':old_report['libraries'],
 'prior_implicit_target_distinction':'Fresh explicit-host normal shared/static bytes differ from prior ccfb/f58 implicit-host build; no timing or equivalence between those artifacts is inferred.',
 'compiler_profiler_python_and_llvm_tools':9,'outer_tools_before_after':8,'llvm_numeric_version':'22.1.8',
 'toolchain_limit':'Compiler and llvm-profdata match LLVM major.minor.patch, but originate from distinct Rust 1.98.1 and 1.98.0 distributions; full executable and dynamic LLVM hashes retained, not claimed identical.',
 'environment_limit':'Commands inherit ambient environment with recorded overrides; allowlisted receipts do not establish identity of every ambient variable. Actual saved compiler vectors establish the flags reviewed.',
 'source_annotation':'source.json changed_files names the inherited encoding.rs implementation delta; archived/live files themselves match every be22 commit blob.',
 'excluded_semantics':['Generated fixture/training rows, XML_Parse origins, profiler count arithmetic, strict warning gate and profile creation lineage are assigned to separate parent review; their files received hash-only integrity checks here.','No real-corpus correctness, native/Python performance, or PGO adoption conclusion.','Concurrent separate fat-LTO study excluded; only pair-freeze listed paths read from the PGO study.'],
 'checks':len(checks),'checked_files':len(checked),'git_reads':len(git_reads),
 'prior_source_build_review':{'path':str(prior_review),'sha256':checked[str(prior_review)]['sha256']},
 'reviewer_execution':'CPU 4 Python standard-library audit and read-only Git blob/diff queries only; no compiler, parser, profiler, training, timing, or target jobs.'
}
write('review.json',review)
print(json.dumps({'status':'passed','checks':len(checks),'checked_files':len(checked),'git_reads':len(git_reads),'review_sha256':sha((OUT/'review.json').read_bytes())}))
