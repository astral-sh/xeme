"""Seal only this independent review's artifacts; no producer executions."""
from pathlib import Path
import hashlib
import json
import os

p = Path(__file__).parent
assert os.sched_getaffinity(0) == {4}
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
review = json.loads((p/'review.json').read_text())
attempt = json.loads((p/'attempt01.json').read_text())
assert review['status'] == 'passed' and attempt['returncode'] == 0
assert attempt['generator_sha256'] == sha(p/'generator.py')
assert attempt['stdout_sha256'] == sha(p/'attempt01.stdout')
assert attempt['stderr_sha256'] == sha(p/'attempt01.stderr')
assert not (p/'attempt01.stderr').read_bytes()
assert len(json.loads((p/'checks.json').read_text())) == review['checks'] == 593
assert all(r['passed'] for r in json.loads((p/'checks.json').read_text()))
training = Path('/tmp/oriole-native-byte-count-pgo-training-independent-review/review.json')
assert sha(training) == '9e7a8451c1429ea888904ae16ba6c120e0a86ec4e4695a72bfe7dce5ff9e0934'
receipt = {'status':'passed','review_sha256':sha(p/'review.json'),
           'generator_sha256':sha(p/'generator.py'),'attempts':1,
           'checks':review['checks'],'checked_files':review['checked_files'],
           'git_reads':review['git_reads'],'scope':review['scope'],
           'separate_training_review':{'path':str(training),'sha256':sha(training)}}
(p/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
files={q.name:{'sha256':sha(q),'bytes':q.stat().st_size} for q in sorted(p.iterdir()) if q.is_file() and q.name != 'files.json'}
(p/'files.json').write_text(json.dumps(files,indent=2,sort_keys=True)+'\n')
assert all(sha(p/n)==r['sha256'] and (p/n).stat().st_size==r['bytes'] for n,r in files.items())
print(json.dumps({'review_sha256':sha(p/'review.json'),'receipt_sha256':sha(p/'receipt.json'),
                  'files_sha256':sha(p/'files.json'),'indexed_files':len(files)}))
