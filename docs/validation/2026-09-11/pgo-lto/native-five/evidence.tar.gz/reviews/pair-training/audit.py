"""Saved PGO training/profile provenance only; no parser/compiler/profiler execution."""
from pathlib import Path
import ast,hashlib,json,math,random,re
B=Path('/tmp/oriole-native-byte-count-pgo-study');P=B/'pgo/runs/run-7_l2jvbd';S=Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo/tools/pgo');O=Path(__file__).parent
seen={}
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p);b=p.read_bytes();seen[str(p)]=sha(b);return b
def js(p):return json.loads(read(p))
freeze=js(B/'pair-freeze.json');assert seen[str(B/'pair-freeze.json')]=='0aa2605be71abb0e7bf4ca48281de6a760d5e11595b98e98f717a4c585a1b14c'
for name,h in freeze['files_sha256'].items():assert sha(read(B/name))==h,name
pair=js(B/'pair-report.json');m=js(P/'manifest.json');inputs=js(P/'inputs/manifest.json')
assert pair['status']==m['status']=='passed' and m['compared_parses']==288
assert m['base_rustflags']==[] and m['cargo_args']==['-Zohm-defaults=no']
assert pair['source_manifest_sha256']==sha(read(B/'source.json'))
# Evaluate only the reviewed pure documents() function and constant; no generator I/O or parser is imported.
corpus=read(S/'corpus.py').decode();tree=ast.parse(corpus);nodes=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='SEED' for x in n.targets) or isinstance(n,ast.FunctionDef) and n.name=='documents']
assert len(nodes)==2
ns={'random':random};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(S/'corpus.py'),'exec'),ns);docs=ns['documents']()
assert len(docs)==len(inputs['rows'])==12 and inputs['seed']==ns['SEED']==0x4F52494F4C45
assert inputs['iterations']==2 and inputs['handlers']==['minimal','full']
expected=[];feeds=0
assert [r['name'] for r in inputs['rows']]==list(docs)
for f in inputs['rows']:
 data,enc=docs[f['name']];assert data==read(P/'inputs'/f['file'])
 assert f['bytes']==len(data) and f['encoding']==enc and f['sha256']==sha(data)
 assert f['file']==f['name']+'.xml' and f['chunks']==[1 if f['name']=='latin1' else 17,4096,65536] and f['namespaces']==[False,True]
 for namespaces in f['namespaces']:
  for chunk in f['chunks']:
   for handlers in inputs['handlers']:
    for iteration in range(2):
     expected.append((f['name'],namespaces,chunk,handlers,iteration));feeds+=math.ceil(len(data)/chunk)
assert len(expected)==288 and feeds==870312
assert len(m['inputs_sha256'])==13
for name,h in m['inputs_sha256'].items():assert sha(read(P/'inputs'/name))==h
for name,h in m['script_sha256'].items():assert sha(read(S/name))==h
reports={}
for phase,path,lib in [('normal',B/'normal-training.json',B/'normal/liboriole_expat.so'),('generate',P/'generate-training.json',P/'generate/liboriole_expat.so'),('use',P/'use-training.json',P/'use/liboriole_expat.so')]:
 d=js(path);reports[phase]=d
 assert d['status']=='passed' and len(d['rows'])==288
 assert d['xml_parse_origin']=={'path':str(lib),'sha256':sha(read(lib))}
 assert d['library_sha256']==sha(read(lib)) and d['inputs_sha256']==sha(read(P/'inputs/manifest.json')) and d['script_sha256']==sha(read(S/'train.py'))
 assert d['profile_file_environment']==(str(P/'raw-profiles/oriole-%m-%p.profraw') if phase=='generate' else None)
 assert [tuple(r[k] for k in ['fixture','namespaces','chunk','handlers','iteration']) for r in d['rows']]==expected
 for i,r in enumerate(d['rows']):
  assert r['status']==1 and r['error']==0 and r['callback_exceptions']==[]
  assert re.fullmatch('[0-9a-f]{64}',r['callback_sha256']) and all(isinstance(n,int) and n>=0 for n in r['counts'].values())
  if i%2:assert {k:v for k,v in r.items() if k!='iteration'}=={k:v for k,v in d['rows'][i-1].items() if k!='iteration'}
assert reports['normal']['rows']==reports['generate']['rows']==reports['use']['rows']
for phase,h in m['training_sha256'].items():assert sha(read(P/(phase+'-training.json')))==h
commands={c['label']:c for c in m['commands']};assert len(commands)==len(m['commands'])==10
for c in m['commands']:
 assert c['returncode']==0 and c['status']=='passed' and sha(read(P/c['log']))==c['log_sha256']
for phase in ['generate','use']:
 c=commands[phase];assert c['argv'][1:3]==['-I','-S'] and c['argv'][3]==str(S/'train.py')
 assert c['environment'].get('LLVM_PROFILE_FILE')==reports[phase]['profile_file_environment']
 assert json.loads(read(P/c['log']))=={'status':'passed','parses':288}
raws=sorted((P/'raw-profiles').iterdir());assert len(raws)==1 and all(p.is_file() and not p.is_symlink() and p.stat().st_size>0 for p in raws)
for name,h in m['profiles_sha256'].items():assert sha(read(P/name if name=='merged.profdata' else P/'raw-profiles'/name))==h
profiler=commands['profile-merge']['argv'][0]
assert commands['profile-merge']['argv']==[profiler,'merge','--num-threads=1','--failure-mode=any','-o',str(P/'merged.profdata'),*map(str,raws)]
assert commands['profile-show']['argv']==[profiler,'show','--all-functions','--counts',str(P/'merged.profdata')]
show=read(P/'07-profile-show.log').decode();rows=re.findall(r'^  (.+):\n    Hash: (0x[0-9a-f]+)\n    Counters: (\d+)\n    Block counts: (\[[^\n]+\])$',show,re.M)
counts={name:ast.literal_eval(values) for name,_,n,values in rows};assert len(counts)==len(rows)==630
assert all(len(counts[name])==int(n) for name,_,n,_ in rows)
assert sum(map(len,counts.values()))==17615 and sum(map(sum,counts.values()))==857813111
assert max(x[0] for x in counts.values())==18096032 and max(map(max,counts.values()))==39512765
assert counts['XML_Parse'][0]==feeds and sum(any(x) for x in counts.values())==278
for text in ['Functions shown: 630','Total functions: 630','Total number of blocks: 17615','Total count: 857813111','Maximum function count: 18096032','Maximum internal block count: 39512765']:assert text in show
assert 'LLVM version: 22.1.8' in m['rustc_version'] and '22.1.8' in m['profdata_version']
use_log=read(P/'08-build-use.log').decode()
assert not re.search(r'(?im)^\s*warning[:\[]|\b(?:hash mismatch|counter mismatch|malformed instrumentation profile|no profile data available)\b',use_log)
assert '-Cprofile-use='+str(P/'merged.profdata') in use_log and '-Cllvm-args=-pgo-warn-missing-function' in use_log
read(S/'build.py');read(S/'train.py');read(B/'build_pair.py')
assert pair['normal_identical_to_implicit_target']=={'liboriole_expat.so':False,'liboriole_expat.a':False}
report={'status':'independent_saved_pgo_training_profile_provenance_passed','scope':'Saved generated training and profile provenance only. Pure deterministic corpus byte generation ran in reviewer Python; no XML parser, compiler, profiler, build, timing or test execution. Source/compiler/tool identity review is separate.',
 'pair_freeze_sha256':seen[str(B/'pair-freeze.json')],'source_manifest_sha256':pair['source_manifest_sha256'],'manifest_sha256':seen[str(P/'manifest.json')],'fixtures':12,'rows_per_normal_generate_use':288,'total_saved_parse_records':864,'generate_XML_Parse_feeds':feeds,'all_training_rows_exact':True,'XML_Parse_origins_verified':3,
 'normal_shared_sha256':reports['normal']['library_sha256'],'instrumented_shared_sha256':reports['generate']['library_sha256'],'optimized_shared_sha256':reports['use']['library_sha256'],
 'profile':{'raw_files':1,'merged_sha256':m['profiles_sha256']['merged.profdata'],'functions':630,'functions_with_nonzero_saved_counter':278,'blocks':17615,'total_count':857813111,'XML_Parse_saved_entry_count':counts['XML_Parse'][0],'strict_use_warning_gate_passed':True},
 'source_review':['Reviewed deterministic corpus and unchanged train/build driver. Fresh parser is freed by contextmanager; callback objects stay retained through free, text/entity values use explicit lengths, content models are freed in finally, callback exceptions are captured and rejected.','Training calls XML_Parse only after same-process dladdr resolves the selected absolute library. Other APIs bind the same ctypes library handle but are not individually dladdr-attested.','Unique run creates empty raw directory, removes inherited LLVM_PROFILE_FILE/PGO flags, enables raw pattern only for instrumented training, merges the sole saved raw file, then uses that exact merged path and rejects missing-function or profile warnings. Source/config/input/tool/library/profile before-after guards remain intact.'],
 'limitations':['Callback hashes/counts prove saved training parity, not full API semantics, exact positions, malformed coverage or reference-Expat correctness. Element content-model callback hashes its name, not the whole model.','Freshness is supported by retained pipeline source/order/manifest and profile hashes; this saved audit does not rerun llvm-profdata or reconstruct merged binary bytes from the raw profile.','Normal and optimized replays do not write profiles. Python itself is uninstrumented; training durations are not benchmarks. No project XML or external files enter the fixed generated corpus.','Explicit-host normal0c8c differs from earlier implicit-targetccfb; new normal is the matched comparison. Separate fat-LTO, allocators, broad gates and elapsed studies are outside this receipt.'],
 'blockers':[],'checked_files':len(seen),'all_inspected_inputs_unchanged':True,'generator_sha256':sha(Path(__file__).read_bytes())}
for path,h in seen.items():assert sha(Path(path).read_bytes())==h
(O/'checked-files.json').write_text(json.dumps(seen,indent=2)+'\n');(O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checked_files':len(seen),'review_sha256':sha((O/'review.json').read_bytes())}))
