"""Bounded publication-text review against already audited saved outcomes."""
from pathlib import Path
import gzip,hashlib,json,re,statistics,subprocess
P=Path(__file__).parent;W=Path('/home/dev-user/code/oss/oriole-pgo-lto-study');tracked={}
def read(p):
 p=Path(p);b=p.read_bytes();h=hashlib.sha256(b).hexdigest();assert tracked.setdefault(str(p),h)==h;return b
def sha(p):read(p);return tracked[str(Path(p))]
def load(p):return json.loads(read(p))
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
if not __debug__:raise RuntimeError('assertions required')
docs=['README.md','benchmarks/README.md','tools/pgo/README.md','docs/review.md','benchmarks/results/2026-09-11/pgo-lto/README.md','docs/validation/2026-09-11/pgo-lto/README.md']
texts={n:read(W/n).decode() for n in docs};main=texts['README.md'];bench=texts[docs[-2]];report=texts[docs[-1]]
old=git('show','HEAD:README.md').decode()
assert re.findall(r'^#+ .*$',main,re.M)==re.findall(r'^#+ .*$',old,re.M)
assert re.findall(r'^>.*$',main,re.M)==re.findall(r'^>.*$',old,re.M)
assert main[main.index('## License'):]==old[old.index('## License'):]
for n in ['LICENSE-APACHE','LICENSE-MIT']:assert read(W/n)==git('show','HEAD:'+n)
changed=git('diff','--name-only').decode().splitlines()
assert set(changed)<=set(docs)
source=load('/tmp/oriole-native-byte-count-pgo-study/source.json')
assert len(source['source_sha256'])==70
for n,h in source['source_sha256'].items():assert sha(W/n)==h
tools=load('/tmp/oriole-native-byte-count-pgo-study/tool-source.json')
# The guide is intentionally post-experiment; Python tool sources stay frozen.
for p in (W/'tools/pgo').glob('*.py'):
 assert read(p)==read(Path('/home/dev-user/code/oss/oriole-native-byte-count-pgo/tools/pgo')/p.name)
review_paths={
 '/tmp/oriole-current-pgo-native-independent-review/review.json':'0388188f7efe8ba3f1d1d612b330263ae7e7c63b3a71aa0b58301304324952fb',
 '/tmp/oriole-current-pgo-lto-native-independent-review/review.json':'58aa681104408e074836fdb73230f0e2dcdfdbabc06f37483dde33f4572d38c2',
 '/tmp/oriole-current-pgo-python-review-handoff/review.json':'ac59cc3ef4cf13bbda074ca127855aa81c2cca4c4151177a08e55cc2f1466af7',
 '/tmp/oriole-fat-pgo-python-review-handoff/review.json':'80783a4ccf19198297e240dd3994dccdf47d58d04e02601c923c90747942cca8',
 '/tmp/oriole-current-thin-pgo-cpython-handoff/review.json':'7b8b055505931c115a5d315268c8b5571518fc794601281052ee865261e736c2',
}
for p,h in review_paths.items():assert sha(p)==h
native=load('/tmp/oriole-current-pgo-native-study/summary.json');fatnative=load('/tmp/oriole-current-pgo-lto-native-study/summary.json')
assert native['groups']==load(list(review_paths)[0])['groups'] and fatnative['groups']==load(list(review_paths)[1])['groups']
py=load(list(review_paths)[2]);fatpy=load(list(review_paths)[3]);N=native['groups']['real']['ratios'];F=fatnative['groups']['real']['ratios'];Y=py['overall'];Z=fatpy['overall']
comparisons=[('Oriole ThinLTO PGO / normal ThinLTO','pgo_over_normal'),('Oriole normal fat LTO / normal ThinLTO','fat_over_normal'),('Expat PGO / normal Expat','expat_pgo_over_expat'),('Oriole ThinLTO PGO / Expat PGO','pgo_over_expat_pgo')]
for label,key in comparisons:assert f"| {label} | {N[key]['geomean']:.3f}× | {Y[key]['geomean']:.3f}× |" in bench
assert f"{100*(1-N['pgo_over_normal']['geomean']):.1f}%"=='24.8%'
assert f"{100*(1-Y['pgo_over_normal']['geomean']):.1f}%"=='15.5%'
assert f"{100*(F['fat_pgo_over_thin_pgo']['geomean']-1):.1f}%"=='6.8%'
assert f"{100*(Z['fat_pgo_over_thin_pgo']['geomean']-1):.1f}%"=='2.6%'
assert N['pgo_over_normal']['below_one']==Y['pgo_over_normal']['below_one']==24
assert N['fat_over_normal']['below_one']==20 and Y['fat_over_normal']['below_one']==17
assert F['fat_pgo_over_thin_pgo']['below_one']==0 and Z['fat_pgo_over_thin_pgo']['below_one']==4
assert N['pgo_over_expat_pgo']['below_one']==Y['pgo_over_expat_pgo']['below_one']==F['thin_pgo_over_expat_pgo']['below_one']==Z['thin_pgo_over_expat_pgo']['below_one']==4
raw=load('/tmp/oriole-current-pgo-native-study/native-screen/results.json');representative=[]
for name,label in [('vulkan','Vulkan registry'),('wayland','Wayland protocol'),('maven','Maven POM'),('batik','Batik SVG'),('gtk','GTK UI'),('docbook','DocBook XSL')]:
 rows=[r for r in raw['rows'] if r['condition']['name']==name and r['condition']['chunk']==4096 and not r['condition']['namespaces']]
 assert len(rows)==7
 times={e:statistics.median(next(p['median_seconds'] for p in r['processes'] if p['engine']==e) for r in rows)*1000 for e in ['pgo','expat_pgo']}
 c=next(s for s in raw['summary'] if s['condition']==rows[0]['condition']);ratio=c['median_ratios']['pgo_over_expat_pgo']
 row=f"| {label} | {times['pgo']:.3f} ms | {times['expat_pgo']:.3f} ms | {ratio:.2f}× |"
 assert row in bench;representative.append({'project':name,'times_ms':times,'paired_ratio':ratio})
assert '175,700 measured parses' in bench and '42,980 measured parses' in bench and '105,420 measured parses' in bench and '25,788 measured parses' in bench
assert native['counts']['timed_workers']==980 and fatnative['counts']['timed_workers']==588 and py['counts']['workers']==840 and fatpy['counts']['workers']==504
gates=load('/tmp/oriole-current-thin-pgo-gates/summary.json')
gate_review=load('/tmp/oriole-current-thin-pgo-gates-independent-review/review.json')
assert 'pass' in gate_review['status']
assert gates['api']['passed']==4347 and gates['api']['failed']==393 and gates['api']['raw_exit']==1
assert gates['api']['bounds']=={'per_test_seconds':3,'per_test_address_space_bytes':1073741824,'per_test_rss_limit_bytes':805306368,'total_timeout_seconds':240}
assert gates['native']['consumers']==6 and gates['native']['allocation_scenarios_per_linkage']==327
assert sum([298,44,12,12,12,14,1])==393
prior=read(W/'docs/validation/2026-09-11/native-byte-count/README.md').decode()
assert '393 failures span 38 of 395 test bodies' in prior
assert '407 workspace tests' in main and '5bc806e' in main and '4b11ace' in main
assert 'The current Oriole build and training runs preserve' in report
assert 'compiler caches are outside the retained evidence scope' in report
assert 'four extension-origin records per linkage' in report and 'No text-fragmentation adaptation is enabled.' in report
assert 'Rust release code itself is not sanitizer-instrumented' in report and 'leak detection is disabled' in report and 'does not save every successful raw pair' in report
links=[]
for n,s in texts.items():
 for target in re.findall(r'\]\(([^)]+)\)',s):
  if target.startswith(('https://','http://','#','mailto:')):continue
  path=(W/n).parent/target.split('#')[0]
  assert path.exists(),(n,target);links.append({'file':n,'target':target})
for p,h in tracked.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
result={'status':'independent_publication_text_review_passed','date_utc':'2026-09-11','scope':'Six Markdown files, numerical tables/rounding, source/build/compatibility scope, relative links and unchanged main README structure/warning/license. Final inventory paragraph and later attachment changes are excluded.',
 'assessed_files':{n:tracked[str(W/n)] for n in docs},'source_files_unchanged':70,
 'numerical_conclusion':'Every aggregate ratio, reduction, win/regression count and six representative native rows agrees with independently audited saved results. Paired ratios remain distinct from ratios of displayed medians. Separate campaigns are not pooled.',
 'compatibility_conclusion':'4,347/393 original API parity and 802-method/two-failure strict CPython parity are accurately limited to the measured ThinLTO-PGO artifacts. Prior normal workspace/fuzz/PBS scope remains explicit. C sanitizer and custom-success-record limitations retained.',
 'corrections_applied':['Current Oriole source preservation distinguished from historical Expat reuse.','Binary exclusion hashes distinguished from omitted compiler-cache scope.'],
 'review_role':'Independent AI agent; raw source/build/training/timing/gate reviews are separate pinned receipts.','blockers':[],'relative_links_checked':len(links),'checked_inputs':len(tracked)}
(P/'review.json').write_text(json.dumps(result,indent=2)+'\n')
(P/'representative-rows.json').write_text(json.dumps(representative,indent=2)+'\n')
for n,d in [('checked-files.json.gz',tracked),('links.json.gz',links)]:
 with gzip.open(P/n,'wt') as f:json.dump(d,f,indent=2);f.write('\n')
print(json.dumps({'status':result['status'],'review_sha256':sha(P/'review.json'),'inputs':len(tracked),'links':len(links)}))
