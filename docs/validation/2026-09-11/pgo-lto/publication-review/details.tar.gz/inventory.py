"""Bounded final inventory supplement; prior raw-member audits stay separate."""
from pathlib import Path
import gzip,hashlib,json,tarfile
P=Path(__file__).parent;B=Path('/home/dev-user/code/oss/oriole-pgo-lto-study/docs/validation/2026-09-11/pgo-lto')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_bytes())
report=(B/'README.md').read_text();rows=[]
for label,name,expected,n in [
 ('Normal/PGO build matrix and five-engine native campaign','native-five','d2a6b5926d33c3037f84087fb0a611202c0e6a186d572d875d0021c3a71c3872',1525),
 ('Fresh fat-PGO proof and three-engine native campaign','native-fat-pgo','71a2717130fa90fcde41a4cc5554d99abc3209386829f159e26ba200d13e4729',725),
 ('Both CPython benchmark campaigns','python','972ce9832b4faf75d61a38625f10cf3c02f1c7b0a99aa3939816a15a46bc9e33',4699),
 ('Measured ThinLTO PGO C/API checks','c-gates','a67f40ec001486921627ae7142ba342448990d72509ccf9c62a6e8bd4af85168',233),
 ('Strict shared/static CPython checks','strict-python','fc01522ca3bc3a23c9146c6896dadce7d7cdafb30fced205ac82cab5cdb50813',54)]:
 p=B/name;archive=p/'evidence.tar.gz';assert sha(archive)==expected
 with tarfile.open(archive,'r:gz') as t:assert len(t.getmembers())==n
 leaf='summary.json' if name=='python' else 'receipt.json' if name=='strict-python' else 'handoff.json'
 assert f'| [{label}]({name}/{leaf}) | `{expected[:12]}` | {n:,} |' in report
 hand=load(p/leaf)
 if leaf=='receipt.json':assert hand['archive_sha256']==expected and hand['archive_members']==n
 else:assert hand['archive']['sha256']==expected and hand['archive']['members']==n
 if leaf=='handoff.json':
  for stem in ['report','readback']:
   q=p/(stem+'.json');raw=q.read_bytes() if q.exists() else gzip.decompress((p/(stem+'.json.gz')).read_bytes())
   assert hashlib.sha256(raw).hexdigest()==hand[stem+'_sha256']
  if name=='native-five':assert hashlib.sha256(gzip.decompress((p/'manifest.json.gz').read_bytes())).hexdigest()==hand['manifest_sha256']
 rows.append({'directory':name,'archive_sha256':expected,'members':n})
for name,origin in [('python','/tmp/oriole-pgo-python-studies-handoff'),('strict-python','/tmp/oriole-current-thin-pgo-cpython-handoff')]:
 for row in load(Path(origin)/'files.json'):
  assert sha(B/name/row['path'])==row['sha256']==sha(Path(origin)/row['path'])
ex=load(B/'python/excluded-binaries.json')
assert len(ex)==37 and len({r['path'] for r in ex})==34 and sum('symlink_target' in r for r in ex)==3
assert sha(B/'python-package-review/review.json')=='812019183eb8e9cd05d15c6df0b9fafbd5e99e44fbe5349658f214aed27f139e'
out={'status':'final_inventory_text_and_archive_identity_passed','scope':'Five listed archive hashes/member counts, retained summary/readback hashes, compressed-original JSON bytes, copied Python/strict packages and Python exclusion wording. Full member/origin audits remain separate. No targets run.',
 'report_sha256':sha(B/'README.md'),'archives':rows,'python_exclusions':{'records':37,'unique_paths':34,'aliases':3},'blockers':[]}
(P/'inventory-review.json').write_text(json.dumps(out,indent=2)+'\n');print(sha(P/'inventory-review.json'))
