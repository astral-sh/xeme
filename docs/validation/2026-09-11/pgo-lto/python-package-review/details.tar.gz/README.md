# Independent Python publication package audit

Passed the first audit attempt: 19,290 assertions across 4,841 inspected files. No target jobs, producer execution or arithmetic reruns occurred.

The archive SHA-256 is `972ce9832b4faf75d61a38625f10cf3c02f1c7b0a99aa3939816a15a46bc9e33`: 4,885,990 compressed bytes, 4,699 regular members and 31,736,557 uncompressed bytes. Every included member and recorded origin matches. The outer index and exact package-source copy match.

Coverage includes both complete study file trees, three review trees, recorded external compile inputs, both summary generators, six project fixtures and the corpus manifest. Four nested archives contain exactly 103 members: 70 runtime sources, six PGO tool sources and 13/14 independent-review detail files. All nested review origins and source/live hashes match. No ELF/ar member was observed in those nested archives.

The direct binary-exclusion ledger has 37 entries for 34 unique archive paths. Three shared compile-input paths recur across the campaigns; three entries preserve binary alias targets. Each excluded content hash, size and alias target matches. The implementation filters ELF/ar directly; it is not a general recursive binary filter.

The initial packager rejected a consumer binary symlink before creating output. Its exact source and traceback are archived. The final source change permits binary aliases only as hashed exclusions, continues to reject nonbinary symlinks and retains the failed attempt. No producer data changed.

`review.json` gives the compact conclusion. The compressed checked-file, included-member and nested-member maps retain the complete readback. Individual sealed Python reviews supply the numerical conclusions; build/training/native evidence remains separate. Recorded compile inputs do not constitute a standalone complete CPython header/toolchain distribution.
