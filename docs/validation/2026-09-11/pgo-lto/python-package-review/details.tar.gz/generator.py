"""Read-only completed Python publication package integrity/coverage audit."""
from pathlib import Path
from collections import Counter
import difflib,gzip,hashlib,io,json,os,tarfile
O=Path(__file__).parent;P=Path('/tmp/oriole-pgo-python-studies-handoff')
STUDIES={'five-engine':Path('/tmp/oriole-current-pgo-python-root-study'),'fat-versus-thin-pgo':Path('/tmp/oriole-fat-pgo-python-root-study')}
REVIEWS={'five-engine':Path('/tmp/oriole-current-pgo-python-review-handoff'),'fat-versus-thin-pgo':Path('/tmp/oriole-fat-pgo-python-review-handoff'),'fat-pgo-protocol':Path('/tmp/oriole-fat-pgo-python-protocol-independent-review')}
SCRIPT=Path('/tmp/oriole-package-pgo-python-studies.py');SOURCE=Path('/tmp/oriole-native-byte-count-pgo-study')
seen={};passed=0
def read(p):
 p=Path(p);b=p.read_bytes();v=hashlib.sha256(b).hexdigest();assert seen.setdefault(str(p),v)==v,str(p);return b
def h(p):read(p);return seen[str(p)]
def j(p):return json.loads(read(p))
def gz(p):return json.loads(gzip.decompress(read(p)))
def ck(name,condition):
 global passed
 assert condition,name
 passed+=1
def binary(b):return b.startswith((b'\x7fELF',b'!<arch>\n'))
def safe(n):return not Path(n).is_absolute() and '..' not in Path(n).parts
def put(n,v):
 if n.endswith('.gz'):
  with gzip.open(O/n,'wt') as f:json.dump(v,f,sort_keys=True);f.write('\n')
 else:(O/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
ck('CPU4 saved package only',__debug__ and os.sched_getaffinity(0)=={4})
script=read(SCRIPT).decode();initial=read('/tmp/oriole-package-pgo-python-studies-attempt-01.py').decode()
expected=initial.replace('p=Path(p);assert p.is_file() and not p.is_symlink(),p','p=Path(p);assert p.is_file(),p').replace("row={'path':name,'origin':str(p),'size':len(b),'sha256':h}\n","row={'path':name,'origin':str(p),'size':len(b),'sha256':h}\n if p.is_symlink():row['symlink_target']=str(p.readlink())\n").replace(' planned[name]=row',' assert not p.is_symlink(),p\n planned[name]=row').replace("add('packager.py',Path(__file__))","add('packager.py',Path(__file__))\nfor name in ['oriole-package-pgo-python-studies-attempt-01.py','oriole-package-pgo-python-studies-attempt-01.log']:\n add('packaging-attempts/'+name,Path('/tmp')/name)")
ck('correction limited to binary alias exclusions and failed-attempt retention',expected==script)
failure=read('/tmp/oriole-package-pgo-python-studies-attempt-01.log').decode()
ck('original rejection before output creation',failure.rstrip().endswith('AssertionError: /tmp/oriole-current-pgo-python-root-study/consumers/expat/libexpat.so.1') and initial.index("for label,b in STUDIES.items():")<initial.index('OUT.mkdir()'))
ck('packager copy exact',read(P/'package.py')==read(SCRIPT))
planned={};excluded=[]
def add(name,path):
 p=Path(path);ck('selected origin exists '+str(p),p.is_file() and safe(name) and name not in planned)
 b=read(p);r={'path':name,'origin':str(p),'size':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 if p.is_symlink():r['symlink_target']=str(p.readlink())
 if binary(b):excluded.append(r)
 else:
  ck('nonbinary origins regular '+str(p),not p.is_symlink());planned[name]=r
review_summary={};condition_inputs=set();compile_origins=set()
for label,root in STUDIES.items():
 for p in sorted(root.rglob('*')):
  if p.is_file():add(f'studies/{label}/{p.relative_to(root).as_posix()}',p)
 result=j(root/'screen/results.json');summary=j(root/'summary.json');review=j(REVIEWS[label]/'review.json')
 ck('completed study/review link '+label,j(root/'time-controller.json')['status']=='passed' and result['status']=='passed' and 'passed' in review['status'] and summary['raw_result_sha256']==review['results_sha256']==h(root/'screen/results.json'))
 review_summary[label]={'result_sha256':h(root/'screen/results.json'),'summary_sha256':h(root/'summary.json'),'review_sha256':h(REVIEWS[label]/'review.json'),'counts':review['counts'],'overall':review['overall']}
 build=j(root/'consumers/build.json')
 ck('recorded compile sources before/after '+label,build['source_sha256_before']==build['source_sha256_after'])
 for p,digest in build['source_sha256_before'].items():
  ck('recorded external compile source '+p,h(p)==digest);compile_origins.add(p)
  name=f'compile-inputs/{digest}/{Path(p).name}'
  if name not in planned:add(name,p)
 for c in result['conditions']:
  p=Path(c['input']);condition_inputs.add(str(p));digest=h(p);name=f'project-inputs/{digest}/{p.name}'
  if name not in planned:add(name,p)
for label,root in REVIEWS.items():
 for p in sorted(root.rglob('*')):
  if p.is_file():add(f'independent-reviews/{label}/{p.relative_to(root).as_posix()}',p)
for name in ['source.json','source.tar.gz','tool-source.json','tool-source.tar.gz']:add('parser-source/'+name,SOURCE/name)
manifest_path=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');add('project-inputs/corpus-manifest.json',manifest_path)
corpus=j(manifest_path);corpus_inputs={str((manifest_path.parent/f['path']).resolve()):f['sha256'] for project in corpus['projects'] for f in project['files'] if f['role']=='input'}
ck('exact six project inputs',len(condition_inputs)==6 and condition_inputs==set(corpus_inputs) and all(h(p)==digest for p,digest in corpus_inputs.items()))
for label,path in [('five-engine','/tmp/oriole-summarize-current-pgo-python.py'),('fat-versus-thin-pgo','/tmp/oriole-summarize-fat-pgo-python.py')]:
 ck('external summary generator origin '+label,j(STUDIES[label]/'summary.json')['script_sha256']==h(path));add(f'studies/{label}/summary-generator.py',path)
add('packager.py',SCRIPT)
for name in ['oriole-package-pgo-python-studies-attempt-01.py','oriole-package-pgo-python-studies-attempt-01.log']:add('packaging-attempts/'+name,Path('/tmp')/name)
member_rows=gz(P/'archive-members.json.gz');declared_nested=gz(P/'nested-members.json.gz');declared_excluded=j(P/'excluded-binaries.json');summary=j(P/'summary.json')
ck('complete ordered included selection and origins',member_rows==list(planned.values()) and len(planned)==4699)
ck('complete exclusion ledger exact including aliases/duplicates',declared_excluded==excluded and len(excluded)==37)
ck('main archive pinned',h(P/'evidence.tar.gz')=='972ce9832b4faf75d61a38625f10cf3c02f1c7b0a99aa3939816a15a46bc9e33')
nested=[];nested_tables={};binary_members=[];archive_instances=[]
def inspect(name,b):
 with tarfile.open(fileobj=io.BytesIO(b),mode='r:*') as tar:
  members=tar.getmembers();ck('nested safe unique members '+name,len({m.name for m in members})==len(members))
  table={};archive_instances.append({'archive':name,'members':len(members)})
  for m in members:
   ck('nested safe type/path '+name+'!'+m.name,safe(m.name) and not m.issym() and not m.islnk() and (m.isfile() or m.isdir()))
   if not m.isfile():continue
   raw=tar.extractfile(m).read();ck('nested member size '+m.name,len(raw)==m.size)
   record={'archive':name,'path':m.name,'size':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};nested.append(record);table[m.name]=record
   if binary(raw):binary_members.append(name+'!'+m.name)
   if m.name.endswith(('.tar.gz','.tgz','.tar')):inspect(name+'!'+m.name,raw)
  nested_tables[name]=table
with tarfile.open(P/'evidence.tar.gz','r:gz') as tar:
 members=tar.getmembers();ck('exact sorted4699 main members',[m.name for m in members]==sorted(planned))
 for m in members:
  ck('safe regular main member '+m.name,m.isfile() and safe(m.name) and not m.issym() and not m.islnk())
  b=tar.extractfile(m).read();r=planned[m.name]
  ck('main content/origin/member hash '+m.name,len(b)==m.size==r['size'] and hashlib.sha256(b).hexdigest()==r['sha256']==h(r['origin']) and not binary(b))
  if m.name.endswith(('.tar.gz','.tgz','.tar')):inspect(m.name,b)
ck('all declared nested records exact',nested==declared_nested and len(nested)==103)
ck('observed nested archives have no ELF/ar content',not binary_members and len(archive_instances)==4)
for label in ['five-engine','fat-versus-thin-pgo']:
 root=REVIEWS[label];rows=j(root/'archive-members.json');table=nested_tables[f'independent-reviews/{label}/details.tar.gz']
 ck('review detail archive complete '+label,set(table)=={r['path'] for r in rows})
 for r in rows:ck('review detail member/origin '+label+'/'+r['path'],table[r['path']]['sha256']==r['sha256']==h(r['origin']) and table[r['path']]['size']==r['size'])
source=j(SOURCE/'source.json');toolsource=j(SOURCE/'tool-source.json')
for archive,mapping,worktree in [('parser-source/source.tar.gz',source['source_sha256'],Path(source['worktree'])),('parser-source/tool-source.tar.gz',toolsource,Path(source['worktree']))]:
 table=nested_tables[archive];ck('complete source archive '+archive,set(table)==set(mapping))
 for name,digest in mapping.items():ck('nested source/live identity '+name,table[name]['sha256']==digest==h(worktree/name))
ck('70 runtime and6 tool source members',len(source['source_sha256'])==70 and len(toolsource)==6)
for label,root in REVIEWS.items():
 rows=j(root/'files.json');ck('nested review outer index complete '+label,{r['path'] for r in rows}=={p.name for p in root.iterdir() if p.is_file() and p.name!='files.json'})
 for r in rows:ck('nested review outer index hash '+label+'/'+r['path'],h(root/r['path'])==r['sha256'] and (root/r['path']).stat().st_size==r['size'])
for r in excluded:
 ck('excluded content retains hash/type '+r['path'],h(r['origin'])==r['sha256'] and len(read(r['origin']))==r['size'] and binary(read(r['origin'])))
 ck('excluded alias target exact '+r['path'],(str(Path(r['origin']).readlink()) if Path(r['origin']).is_symlink() else None)==r.get('symlink_target'))
actual_archive={'sha256':h(P/'evidence.tar.gz'),'bytes':(P/'evidence.tar.gz').stat().st_size,'members':len(planned),'uncompressed_bytes':sum(r['size'] for r in planned.values()),'nested_members_read':len(nested),'direct_compiled_exclusions':len(excluded)}
ck('summary copies review aggregates/counts exactly',summary['studies']==review_summary and summary['archive']==actual_archive)
ck('published archive exact byte counts',actual_archive['bytes']==4885990 and actual_archive['uncompressed_bytes']==31736557)
outer_index=j(P/'files.json');ck('outer complete file index',{r['path'] for r in outer_index}=={p.name for p in P.iterdir() if p.is_file() and p.name!='files.json'})
for r in outer_index:ck('outer index hash/size '+r['path'],h(P/r['path'])==r['sha256'] and (P/r['path']).stat().st_size==r['size'])
ck('all inspected sources remain unchanged',all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in seen.items()))
unique_excluded={r['path'] for r in excluded};aliases=[r for r in excluded if 'symlink_target' in r]
report={'status':'passed','scope':'Completed Python publication package selection/member/origin/nested/index review only; no arithmetic reruns or target executions.',
 'package':str(P),'archive':actual_archive,'outer_index_sha256':h(P/'files.json'),'packager_sha256':h(SCRIPT),
 'coverage':'Both entire producer trees, all three independent-review trees, exact recorded external compile inputs, both external summary generators, six project fixtures/corpus manifest, shared70 runtime/six tool source snapshots, and initial packaging failure source/log are retained.',
 'review_links':{label:{'path':str(root/'review.json'),'sha256':h(root/'review.json')} for label,root in REVIEWS.items()},
 'source_archive_members':70,'tool_source_archive_members':6,'review_archive_members':{label:len(nested_tables[f'independent-reviews/{label}/details.tar.gz']) for label in ['five-engine','fat-versus-thin-pgo']},
 'nested_archive_instances':archive_instances,'nested_members':103,'nested_ELF_or_ar_members_observed':binary_members,
 'exclusions':{'ledger_entries':len(excluded),'unique_archive_paths':len(unique_excluded),'repeated_ledger_paths':{p:n for p,n in Counter(r['path'] for r in excluded).items() if n>1},'binary_alias_entries':len(aliases),'scope':'Direct ELF/ar filtering; excluded alias target text and dereferenced content hashes checked. Nested archives were inspected and no ELF/ar members were observed in this package. This does not establish a general recursive binary filter.'},
 'failure_lineage':'Initial packager rejected an existing consumer/libexpat.so.1 binary symlink during selection, before OUT.mkdir. Exact failed script and traceback are archived. Final correction handles binary aliases as exclusions, still rejects nonbinary symlinks and adds failed-attempt evidence. Producer data unchanged.',
 'summary_readback':'Both packaged count and overall tables exactly copy the already independently audited review.json values. Cross-study timing samples are never paired here.',
 'limitations':['This package includes the recorded immediate CPython C compile inputs and parser header, not a standalone complete CPython include tree/toolchain distribution. External tool/compiler identities remain in the original build receipts.','Full build/training/native evidence is packaged separately; source snapshots here establish content identity. Raw arithmetic and correctness conclusions are reused from the sealed individual reviews.','Shared-host, historical Expat PGO, canonical-preflight-only and measurement-boundary limitations remain with each study.','ELF/ar exclusion counts are ledger occurrences, with three shared compile-input paths repeated across the two studies; unique counts and alias targets are explicit.'],
 'passed_checks':passed,'checked_files':len(seen),'all_inspected_bytes_unchanged':True,'execution':'CPU4 Python file, gzip, tar, hash and JSON inspection only. Packager/producer code was neither imported nor executed.'}
put('checked-files.json.gz',seen);put('verified-members.json.gz',member_rows);put('verified-nested-members.json.gz',nested);put('verified-exclusions.json',excluded);put('review.json',report)
(O/'packager-correction.patch').write_text(''.join(difflib.unified_diff(initial.splitlines(True),script.splitlines(True),fromfile='initial-packager',tofile='final-packager')))
print(json.dumps({'status':'passed','review_sha256':hashlib.sha256((O/'review.json').read_bytes()).hexdigest(),'checks':passed,'checked_files':len(seen),'exclusions':report['exclusions']}))
