"""Review prepared protocol/source and saved build receipts only."""
from pathlib import Path
import ast,difflib,hashlib,json
P=Path(__file__).parent
B=Path('/tmp/oriole-fat-pgo-python-root-study')
OLD=Path('/tmp/oriole-current-pgo-python-root-study')
THREE=Path('/tmp/oriole-raw-len-split-thinlto-python-root-study')
tracked={}
def read(p):
 p=Path(p);b=p.read_bytes();h=hashlib.sha256(b).hexdigest()
 assert tracked.setdefault(str(p),h)==h
 return b
def sha(p):read(p);return tracked[str(Path(p))]
def load(p):return json.loads(read(p))
if not __debug__:raise RuntimeError('assertions required')
adapt=load(B/'adaptation.json')
for name,h in adapt['files'].items():assert sha(B/name)==h
assert read(B/'python_worker.py')==read(OLD/'python_worker.py')
for name,base in [('consumer_screen.py',OLD),('build_consumers.py',THREE),('run.py',OLD)]:
 old=read(base/name).decode();new=read(B/name).decode()
 assert ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(base/name),tofile=str(B/name)))==read(B/(name+'.patch')).decode()
 oldast=ast.parse(old);newast=ast.parse(new)
 if name=='consumer_screen.py':
  oldfunc={n.name:ast.dump(n) for n in ast.walk(oldast) if isinstance(n,ast.FunctionDef)}
  newfunc={n.name:ast.dump(n) for n in ast.walk(newast) if isinstance(n,ast.FunctionDef)}
  for n in ['digest','save','run_process','execute']:assert oldfunc[n]==newfunc[n]
  constants={n.targets[0].id:ast.literal_eval(n.value) for n in newast.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['ENGINES','RATIOS','ITERATIONS']}
  assert constants['ENGINES']==('thin_pgo','fat_pgo','expat_pgo')
  assert constants['RATIOS']==(('fat_pgo','thin_pgo'),('thin_pgo','expat_pgo'),('fat_pgo','expat_pgo'))
  assert constants['ITERATIONS']=={'vulkan':3,'wayland':16,'maven':32,'batik':128,'gtk':64,'docbook':64}
  assert 'default=202609104412' in new and 'default=7' in new
 elif name=='build_consumers.py':
  getloop=lambda a:next(n for n in ast.walk(a) if isinstance(n,ast.For) and ast.unparse(n.target)=='(engine, library)')
  assert ast.dump(getloop(oldast))==ast.dump(getloop(newast))
 else:
  # Exact only change in outer process owner: the build arguments.
  before="""--library', libraries['pgo']['path'], '--reference', libraries['normal']['path'],
                        '--fat', libraries['fat']['path'], '--expat', libraries['expat']['path'],
                        '--expat-pgo', libraries['expat_pgo']['path'], '--source'"""
  after="""--library', libraries['fat_pgo']['path'], '--reference', libraries['thin_pgo']['path'],
                        '--expat', libraries['expat_pgo']['path'], '--source'"""
  assert old.count(before)==1 and old.replace(before,after)==new
assert adapt['counts']=={'conditions':24,'engines':3,'preflights':72,'cohorts':168,'timed_workers':504,'measured_parses':25788,'warmups':504}
assert adapt['source_runtime']=='be22a271f8a5c004d13e515cd4024a68afe57887'
for e,v in adapt['libraries'].items():assert sha(v['path'])==v['sha256']
build=load(B/'consumers/build.json');normalized={}
assert build['status']=='passed' and build['adaptations'] is None
assert build['source_sha256_before']==build['source_sha256_after']
for p,h in build['source_sha256_before'].items():assert sha(p)==h
for e,c in build['consumers'].items():
 assert sha(c['library'])==adapt['libraries'][e]['sha256']
 assert len(c['commands'])==2
 for p,h in c['files'].items():assert sha(p)==h
 normalized[e]=[]
 for module,cmd in zip(['pyexpat','_elementtree'],c['commands'],strict=True):
  argv=cmd['command'];assert cmd['returncode']==0 and argv[:4]==['cc','-shared','-fPIC','-O2']
  assert sha(Path(c['directory'])/(module+'-build.log'))==cmd['log_sha256']
  normalized[e].append([x.replace(c['library'],'<LIB>').replace(c['directory'],'<DIR>') for x in argv])
assert all(v==normalized['thin_pgo'] for v in normalized.values())
launch=load(B/'prepare-controller.json')
assert launch['status']=='passed' and len(launch['jobs'])==2 and launch['controller_sha256']==sha(B/'run.py')
for job in launch['jobs']:
 assert job['exit']==0 and 'exception' not in job and job['command'][:3]==['taskset','-c','4'] and job['timeout_seconds']==600
 assert sha(B/(job['label']+'-controller.log'))==job['log_sha256']
pre=load(B/'screen/preflight.json')
assert pre['status']=='preflight_passed' and len(pre['preflights'])==len(pre['processes'])==72 and pre['affinity']==[4]
assert pre['hashes_before']==pre['hashes_after'] and not pre['hash_errors']
for p,h in pre['hashes_before'].items():assert sha(p)==h
assert pre['seed']==202609104412 and pre['pairs']==7 and len(pre['conditions'])==24
assert 'have not yet run the full strict suite' in pre['limitations']
read(B/'oriole-prepare-fat-pgo-python-root.py')
for p,h in tracked.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
report={'status':'independent_source_and_preparation_review_passed','date_utc':'2026-09-11',
 'scope':'Read-only source/protocol and completed extension-build/preflight receipts. No timing results or raw preflight reconstruction assessed here.',
 'source_runtime':adapt['source_runtime'],'libraries':adapt['libraries'],'planned_counts':adapt['counts'],
 'conclusion':'Worker bytes and measured execution/compile loop ASTs match prior reviewed campaigns. Engine maps/ratios/captions and build arguments are the complete inspected source delta. Six saved extension compiler vectors match after library/output directory normalization. All hashes and preparation receipts pass.',
 'bounds':'Unchanged 300-second workers, 600-second preparation jobs and 1,200-second aggregate timing process; group kill and reap code byte-identical outside build arguments.',
 'limitations':['This receipt does not establish full strict CPython/API compatibility or any elapsed result.','Diff-header correction is disclosed by the preparation note; executable source delta independently verified against named parents.','Generated-only fat-PGO build/training provenance is a separately delegated review; library hash verified here.','Source cleanup review and successful preparation do not exercise every interruption/failure branch.'],
 'blockers':[],'checked_files':len(tracked),'controller_sha256':sha(B/'consumer_screen.py'),'wrapper_sha256':sha(B/'run.py')}
for n,d in [('review.json',report),('checked-files.json',tracked),('normalized-build-commands.json',normalized)]: (P/n).write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'status':report['status'],'review_sha256':sha(P/'review.json'),'checked_files':len(tracked)}))
