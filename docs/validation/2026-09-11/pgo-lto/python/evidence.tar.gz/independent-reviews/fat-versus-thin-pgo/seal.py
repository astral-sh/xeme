"""Package the completed saved-data review; never execute measured code."""
from pathlib import Path
import hashlib
import json
import tarfile

P=Path(__file__).parent
S=Path('/tmp/oriole-fat-pgo-python-independent-review')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(n,v): (P/n).write_text(json.dumps(v,indent=2)+'\n')
full=json.loads((S/'review.json').read_text())
assert sha(S/'review.json')=='3bcb88d6a3a3dc14b773fa1d98d9657a0c06f56d8dae00053bdb81d7a4fc643a'
members=[{'path':p.name,'origin':str(p),'size':p.stat().st_size,'sha256':sha(p)} for p in sorted(S.iterdir()) if p.is_file()]
with tarfile.open(P/'details.tar.gz','w:gz') as t:
    for m in members: t.add(m['origin'],arcname=m['path'],recursive=False)
with tarfile.open(P/'details.tar.gz','r:gz') as t:
    assert len(t.getmembers())==len(members)
    for m,a in zip(members,t.getmembers(),strict=True):
        assert a.isfile() and a.name==m['path'] and a.size==m['size']
        assert hashlib.sha256(t.extractfile(a).read()).hexdigest()==m['sha256']==sha(m['origin'])
write('archive-members.json',members)
review={
 'status':'independent_saved_data_review_passed','date_utc':'2026-09-11',
 'study':'/tmp/oriole-fat-pgo-python-root-study',
 'scope':'Saved raw Python samples, all paired arithmetic, origins, extension compile vectors, source/controller changes and launch records. No target executions.',
 'counts':full['counts'],
 'arithmetic':{'paired_ratios':504,'condition_ratio_medians':72,'all_sample_seconds_and_process_medians_exact':True,'all_seeded_orders_exact':True,'all_three_summary_comparisons_exact':True},
 'overall':full['groups']['all'],
 'retained_adverse_conditions':full['regression_counts'],
 'provenance':'All three parser hashes match the separately reviewed source/build/training records. Six fresh CPython extension commands retain the same compiler flags after library/directory normalization. Worker byte-identical; measured execution and compilation loops unchanged. All 1,785 inspected inputs rehashed unchanged.',
 'limitations':full['limitations'],
 'blockers':[],
 'full_review_sha256':sha(S/'review.json'),
 'results_sha256':full['results_sha256'],
 'preflight_sha256':full['preflight_sha256'],
 'summary_sha256':full['summary_sha256'],
 'details_archive_sha256':sha(P/'details.tar.gz'),
 'details_members':len(members),
 'first_attempt_passed':True,
 'details':'Archive contains the complete independent generator, hash inventories, every reconstructed condition/ratio, and the successful audit log. Original producer raw measurements remain at the study path; they are not duplicated here.'
}
write('review.json',review)
write('files.json',[{'path':p.name,'size':p.stat().st_size,'sha256':sha(p)} for p in sorted(P.iterdir()) if p.is_file() and p.name!='files.json'])
print(json.dumps({'review_sha256':sha(P/'review.json'),'archive_sha256':sha(P/'details.tar.gz'),'files_sha256':sha(P/'files.json'),'archive_members':len(members)}))
