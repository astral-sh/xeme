"""Prepare a matched Thin/fat PGO CPython experiment without executing targets."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import shutil

out = Path('/tmp/oriole-fat-pgo-python-root-study')
out.mkdir(exist_ok=False)
old = Path('/tmp/oriole-raw-len-split-thinlto-python-root-study')
current = Path('/tmp/oriole-current-pgo-python-root-study')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
shutil.copy2(current / 'python_worker.py', out / 'python_worker.py')

def write_delta(name, before, after):
    assert before != after
    ast.parse(after)
    (out / name).write_text(after)
    (out / (name + '.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile=str(old / name), tofile=str(out / name))))

before = (old / 'build_consumers.py').read_text()
after = before.replace('"published": args.reference.resolve(strict=True),', '"thin_pgo": args.reference.resolve(strict=True),').replace('"candidate": args.library.resolve(strict=True),', '"fat_pgo": args.library.resolve(strict=True),').replace('"expat": args.expat.resolve(strict=True),', '"expat_pgo": args.expat.resolve(strict=True),')
after = after.replace('No source adaptation, alternate allocator, LTO or PGO is applied.', 'PGO and Thin/fat LTO apply to the frozen linked parser libraries only. No source adaptation, alternate allocator, or profile training of the interpreter/extensions is applied.')
start = '        for engine, library in libraries.items():'
end = '        report["source_sha256_after"]'
assert before[before.index(start):before.index(end)] == after[after.index(start):after.index(end)]
write_delta('build_consumers.py', before, after)

before = (current / 'consumer_screen.py').read_text()
after = before.replace('ENGINES = ("normal", "pgo", "fat", "expat", "expat_pgo")', 'ENGINES = ("thin_pgo", "fat_pgo", "expat_pgo")')
after = after.replace('RATIOS = (("pgo", "normal"), ("fat", "normal"), ("pgo", "fat"), ("normal", "expat"), ("pgo", "expat_pgo"), ("fat", "expat"), ("expat_pgo", "expat"))', 'RATIOS = (("fat_pgo", "thin_pgo"), ("thin_pgo", "expat_pgo"), ("fat_pgo", "expat_pgo"))')
after = after.replace('Expected frozen normal, PGO, fat-LTO, Expat normal and Expat PGO engines', 'Expected frozen ThinLTO PGO, fat LTO PGO and Expat PGO engines')
after = after.replace('matched explicit-host normal ThinLTO, fresh generated-only PGO ThinLTO, separate no-PGO fat LTO, and pinned Expat2.8.4 normal and PGO', 'matched explicit-host generated-only PGO with ThinLTO or fat LTO, and pinned Expat2.8.4 PGO')
after = after.replace('840 timed workers after120 preflights', '504 timed workers after72 preflights')
after = after.replace('These fresh explicit-target normal, PGO and fat-LTO library variants', 'These fresh explicit-target ThinLTO and fat LTO PGO library variants')
def nodes(source, name):
    return [ast.dump(n, include_attributes=False) for n in ast.walk(ast.parse(source)) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name]
for name in ['digest', 'save', 'run_process', 'execute']:
    assert nodes(before, name) == nodes(after, name) and len(nodes(after, name)) == 1
get_iterations = lambda source: [ast.dump(n, include_attributes=False) for n in ast.parse(source).body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'ITERATIONS' for t in n.targets)]
assert get_iterations(before) == get_iterations(after)
write_delta('consumer_screen.py', before, after)

libs = json.loads((current / 'adaptation.json').read_text())['libraries']
fat = json.loads(Path('/tmp/oriole-native-byte-count-fat-pgo-study/report.json').read_text())
assert fat['status'] == 'passed'
libraries = {'thin_pgo': libs['pgo'], 'fat_pgo': {'path': str(Path(fat['manifest']['path']).parent / 'use/liboriole_expat.so'), 'sha256': fat['libraries']['use/liboriole_expat.so']}, 'expat_pgo': libs['expat_pgo']}
for entry in libraries.values():
    assert sha(entry['path']) == entry['sha256']

before = (current / 'run.py').read_text()
after = before.replace("libraries['pgo']['path']", "libraries['fat_pgo']['path']").replace("libraries['normal']['path']", "libraries['thin_pgo']['path']")
after = after.replace("                        '--fat', libraries['fat']['path'], '--expat', libraries['expat']['path'],\n                        '--expat-pgo', libraries['expat_pgo']['path'],", "                        '--expat', libraries['expat_pgo']['path'],")
write_delta('run.py', before, after)
receipt = {'status': 'prepared_only', 'source_runtime': 'be22a271f8a5c004d13e515cd4024a68afe57887', 'libraries': libraries,
           'counts': {'conditions': 24, 'engines': 3, 'preflights': 72, 'cohorts': 168, 'timed_workers': 504, 'measured_parses': 25788, 'warmups': 504},
           'proof': 'Exact worker and extension compile loop; exact digest/save/run_process/execute AST and iteration table. Changed engine maps, ratios, library arguments, counts and scope only. No target executions.',
           'files': {p.name: sha(p) for p in sorted(out.iterdir()) if p.is_file()}}
(out / 'adaptation.json').write_text(json.dumps(receipt, indent=2) + '\n')
shutil.copy2(__file__, out / Path(__file__).name)
print(json.dumps(receipt['counts']))
