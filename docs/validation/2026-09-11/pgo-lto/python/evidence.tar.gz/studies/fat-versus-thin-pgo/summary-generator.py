"""Reconstruct every saved process median and fixed comparison; emit a compact summary."""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import random
import statistics

out = Path('/tmp/oriole-fat-pgo-python-root-study')
path = out / 'screen/results.json'
results = json.loads(path.read_text())
assert results['status'] == 'passed'
engines = ('thin_pgo', 'fat_pgo', 'expat_pgo')
pairs = (('fat_pgo', 'thin_pgo'), ('thin_pgo', 'expat_pgo'), ('fat_pgo', 'expat_pgo'))
assert len(results['rows']) == 504 and len(results['preflights']) == 72 and len(results['summary']) == 24
groups = defaultdict(dict)
samples = 0
for row in results['rows']:
    assert len(row['samples']) > 1
    assert [r['warmup'] for r in row['samples']] == [True] + [False] * (len(row['samples']) - 1)
    median = statistics.median(r['seconds'] for r in row['samples'][1:])
    assert median == row['median_seconds']
    group = groups[row['key'], row['pair']]
    assert row['engine'] not in group
    group[row['engine']] = median
    samples += len(row['samples']) - 1
assert len(groups) == 168 and all(set(g) == set(engines) for g in groups.values()) and samples == 25788
rng = random.Random(202609104412)
jobs = [(c, p) for c in results['conditions'] for p in range(7)]
rng.shuffle(jobs)
expected = []
for condition, pair in jobs:
    order = list(engines)
    rng.shuffle(order)
    key = f"{condition['name']}/{condition['chunk']}/{condition['mode']}"
    expected.extend((key, pair, engine, index) for index, engine in enumerate(order))
assert expected == [(r['key'], r['pair'], r['engine'], r['order']) for r in results['rows']]
for row in results['summary']:
    c = row['condition']
    key = f"{c['name']}/{c['chunk']}/{c['mode']}"
    for a, b in pairs:
        ratios = [groups[key, p][a] / groups[key, p][b] for p in range(7)]
        assert ratios == row['paired_ratios'][a + '_over_' + b]
        assert statistics.median(ratios) == row['median_ratios'][a + '_over_' + b]
summary = {'scope': 'All24 fixed CPython conditions and504 timed workers, with exact saved process medians, seeded order and paired-ratio reconstruction. Shared host; no discarded conditions or samples.',
           'counts': {'conditions': 24, 'preflights': 72, 'timed_workers': 504, 'cohorts': 168, 'measured_parses': samples, 'timed_warmups': 504},
           'groups': {}, 'regressions': [], 'raw_result_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
           'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
for group in ('all', 'elementtree', 'pyexpat-events'):
    rows = [r for r in results['summary'] if group == 'all' or r['condition']['mode'] == group]
    summary['groups'][group] = {'conditions': len(rows), 'ratios': {}}
    for a, b in pairs:
        key = a + '_over_' + b
        values = [r['median_ratios'][key] for r in rows]
        summary['groups'][group]['ratios'][key] = {'geomean': statistics.geometric_mean(values), 'below_one': sum(v < 1 for v in values)}
for row in results['summary']:
    for key in ('fat_pgo_over_thin_pgo',):
        if row['median_ratios'][key] > 1:
            summary['regressions'].append({'condition': row['condition'], 'comparison': key, 'ratio': row['median_ratios'][key]})
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
