"""Prepare five matched CPython consumers; elapsed timing is a separate controller."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import shutil

out = Path('/tmp/oriole-current-pgo-python-root-study')
out.mkdir(exist_ok=False)
old = Path('/tmp/oriole-raw-len-split-thinlto-python-root-study')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
shutil.copy2(old / 'python_worker.py', out / 'python_worker.py')
before = (old / 'build_consumers.py').read_text()
after = before.replace('parser.add_argument("--expat", type=Path, required=True)', 'parser.add_argument("--expat", type=Path, required=True)\n    parser.add_argument("--expat-pgo", type=Path, required=True)\n    parser.add_argument("--fat", type=Path, required=True)')
after = after.replace('"published": args.reference.resolve(strict=True),', '"normal": args.reference.resolve(strict=True),').replace('"candidate": args.library.resolve(strict=True),', '"pgo": args.library.resolve(strict=True),\n        "fat": args.fat.resolve(strict=True),\n        "expat_pgo": args.expat_pgo.resolve(strict=True),')
caption = 'All three engines compile identical unmodified CPython 3.12.13 pyexpat.c and _elementtree.c with identical -O2 flags and the same narrow Expat-compatible header. Only the linked parser library and its rpath differ. No source adaptation, alternate allocator, LTO or PGO is applied.'
assert caption in after
after = after.replace(caption, 'All five engines compile identical unmodified CPython 3.12.13 pyexpat.c and _elementtree.c with identical -O2 flags and the same narrow Expat-compatible header. Only the linked parser library and its rpath differ. PGO/LTO choices apply to the frozen parser libraries, not to these extensions or the interpreter. No alternate allocator or source adaptation is applied.')
assert before != after
(out / 'build_consumers.py').write_text(after)
(out / 'build-controller.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='reviewed-build-consumers', tofile='current-pgo-build-consumers')))
def nodes(source, name):
    return [ast.dump(n, include_attributes=False) for n in ast.walk(ast.parse(source)) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name]
# The actual compile loop stays byte-identical, including all ten command flags.
start = '        for engine, library in libraries.items():'
end = '        report["source_sha256_after"]'
assert before[before.index(start):before.index(end)] == after[after.index(start):after.index(end)]
before = (old / 'consumer_screen.py').read_text()
after = before.replace('ENGINES = ("published", "candidate", "expat")', 'ENGINES = ("normal", "pgo", "fat", "expat", "expat_pgo")')
after = after.replace('RATIOS = (("candidate", "published"), ("candidate", "expat"), ("published", "expat"))', 'RATIOS = (("pgo", "normal"), ("fat", "normal"), ("pgo", "fat"), ("normal", "expat"), ("pgo", "expat_pgo"), ("fat", "expat"), ("expat_pgo", "expat"))')
after = after.replace('args.phase == "prepare" and os.sched_getaffinity(0) != {5}', 'args.phase == "prepare" and os.sched_getaffinity(0) != {4}').replace('Preflights require CPU5', 'Preflights require CPU4')
after = after.replace('Expected frozen published, coalesced namespace tag-plan candidate, and Expat engines', 'Expected frozen normal, PGO, fat-LTO, Expat normal and Expat PGO engines')
old_method = 'Two Oriole C-only ThinLTO libraries: selected detached End plus Cell/02fcab59, inlined native byte counts/ccfb2295 candidate, and pinned normal Expat2.8.4. All24 original CPython conditions, seven fixed seeded cohorts,504 timed workers after72 preflights. Unchanged reviewed worker times creation/feed/finalization/callbacks and explicit destruction, with canonical checks/imports/input reads/gc.collect outside. One discarded warmup per worker; automatic GC remains enabled. No PGO.'
assert old_method in after
after = after.replace(old_method, 'Current be22 parser libraries: matched explicit-host normal ThinLTO, fresh generated-only PGO ThinLTO, separate no-PGO fat LTO, and pinned Expat2.8.4 normal and PGO. All24 original CPython conditions, seven fixed seeded cohorts,840 timed workers after120 preflights. Unchanged reviewed worker times creation/feed/finalization/callbacks and explicit destruction, with canonical checks/imports/input reads/gc.collect outside. One discarded warmup per worker; automatic GC remains enabled. Six project XML inputs are held out of profile training. PGO/LTO affects linked parsers only.')
old_limit = 'The selected control has two known CPython callback-grouping failures. No fresh strict CPython suite has run on this native-byte-count candidate; canonical fixture outputs must match Expat.'
assert old_limit in after
after = after.replace(old_limit, 'The published be22 runtime has two known strict CPython callback-grouping failures. These fresh explicit-target normal, PGO and fat-LTO library variants have not yet run the full strict suite; canonical fixture outputs must match Expat.')
for name in ['digest', 'save', 'run_process', 'execute']:
    assert nodes(before, name) == nodes(after, name) and len(nodes(after, name)) == 1, name
for name in ['ITERATIONS']:
    get = lambda source: [ast.dump(n, include_attributes=False) for n in ast.parse(source).body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets)]
    assert get(before) == get(after)
(out / 'consumer_screen.py').write_text(after)
(out / 'controller.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='reviewed-consumer-screen', tofile='current-pgo-screen')))
libraries = json.loads(Path('/tmp/oriole-current-pgo-native-study/adaptation.json').read_text())['libraries']
for entry in libraries.values():
    assert sha(entry['path']) == entry['sha256']
receipt = {'status': 'prepared_only', 'source_runtime': 'be22a271f8a5c004d13e515cd4024a68afe57887', 'libraries': libraries,
           'counts': {'conditions': 24, 'engines': 5, 'preflights': 120, 'cohorts': 168, 'timed_workers': 840, 'measured_parses': 42980, 'warmups': 840},
           'proof': 'Worker bytes, extension compile-loop bytes, process/execute/digest/save AST and iteration table exact. Only engine arguments/maps/ratios, descriptive scope and preflight CPU differ. No target executions yet.',
           'files': {n: sha(out / n) for n in ['python_worker.py', 'build_consumers.py', 'build-controller.patch', 'consumer_screen.py', 'controller.patch']}}
assert sha(out / 'python_worker.py') == sha(old / 'python_worker.py')
(out / 'adaptation.json').write_text(json.dumps(receipt, indent=2) + '\n')
shutil.copy2(__file__, out / Path(__file__).name)
print(json.dumps(receipt['counts']))
