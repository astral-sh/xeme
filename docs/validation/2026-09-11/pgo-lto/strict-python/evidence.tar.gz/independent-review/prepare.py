from pathlib import Path
import difflib,hashlib,json
P=Path(__file__).parent
old=Path('/tmp/oriole-native-byte-count-thinlto-cpython-root-review/audit.py').read_text()
s=old[:old.index("result={'status'")]
changes={
 '/tmp/oriole-native-byte-count-thinlto-cpython-gates':'/tmp/oriole-current-thin-pgo-cpython-gates',
 '/home/dev-user/code/oss/oriole-native-byte-count':'/home/dev-user/code/oss/oriole-native-byte-count-pgo',
 '/tmp/oriole-native-byte-count-thinlto-study':'/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use',
 'oriole-native-byte-count-thinlto-cpython-gates.py':'oriole-current-thin-pgo-cpython-gates.py',
 "hashes[str(p)]=hashlib.sha256(d).hexdigest();return d":"h=hashlib.sha256(d).hexdigest();assert hashes.setdefault(str(p),h)==h;return d",
}
for a,b in changes.items():assert a in s;s=s.replace(a,b)
s=s.replace("A=Path('/tmp/oriole-coalesced-search-canonical-api/run')\nB=Path('/tmp/oriole-frame-integrated-gates/upstream-api')\n",'')
(P/'adaptation.patch').write_text(''.join(difflib.unified_diff(old[:old.index("result={'status'")].splitlines(True),s.splitlines(True),fromfile='prior-method-origin-reader',tofile='fresh-thin-pgo-reader')))
(P/'preparation.json').write_text(json.dumps({'prior_reader_sha256':hashlib.sha256(old.encode()).hexdigest(),'scope':'Saved data only; current source/build/probe/failure verification extends the prior method-map reader.'},indent=2)+'\n')
(P/'audit.py').write_text(s+(P/'tail.py').read_text())
