if not __debug__:raise RuntimeError('assertions required')
pair_source=load('/tmp/oriole-native-byte-count-pgo-study/source.json')
assert controller['status']=='completed_with_failures_retained_pending_outcome_audit'
assert controller['source_sha256']==pair_source['source_sha256'] and len(controller['source_sha256'])==70
for name,h in controller['source_sha256'].items():assert sha(W/name)==h
pair_review=load('/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json')
assert sha('/tmp/oriole-native-byte-count-pgo-build-independent-review/review.json')=='cec78c70730e111f139a6fab70089e1629ffe3336843106585a35922a525bbc9'
assert controller['libraries']=={
 '/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use/liboriole_expat.so':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02',
 '/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use/liboriole_expat.a':'8b6ca03e6fd4be81aba81cccf10b4aa2d67e16586010477cba1e8f23a4dec97d'}
failure_blocks={};method_maps={};skip_lines={};source_inputs={}
def failures(path):
 text=read(path).decode()
 blocks=re.findall(r'^FAIL: .*?(?=^-{70}\nRan )',text,re.M|re.S)
 blocks=[re.sub(r'File "[^"]*/pyexpat\.c"','File "<PYEXPAT_SOURCE>"',s) for s in blocks]
 return [re.sub(r'File "[^"]*/Lib/','File "<CPYTHON_LIB>/',s) for s in blocks]
for linkage in ['shared','static']:
 p=G/linkage;summary=load(p/'summary.json');job=next(j for j in controller['jobs'] if j['linkage']==linkage)
 assert job['command'][:3]==['taskset','-c','4'] and job['timeout_seconds']==1200
 assert not job.get('exception') and 0<job['end']-job['start']<1200
 assert summary['test_command'][1:8]==['-s','-m','test','-v','-j1','--timeout','120']
 assert summary['test_command'][8:]==['test_pyexpat','test_xml_etree','test_xml_etree_c','test_minidom','test_sax','test_pulldom']
 assert len(summary['commands'])==2
 for module,command in zip(['pyexpat','_elementtree'],summary['commands'],strict=True):
  assert command[:4]==['cc','-shared','-fPIC','-O2'] and command[-2]=='-o'
  assert Path(command[-1]).parent==p and Path(command[-1]).name.startswith(module+'.cpython-312-')
  assert '-Wl,-rpath,'+str(p) in command
  source=next(x for x in command if x.endswith('/'+('pyexpat.c' if module=='pyexpat' else '_elementtree.c')))
  source_inputs[source]=sha(source)
  if module=='_elementtree':assert sha(source)==sha('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Modules/_elementtree.c')
  if linkage=='static':assert [x for x in command if x.startswith('-l')]==['-lgcc_s','-lutil','-lrt','-lpthread','-lm','-ldl','-lc']
 probe=read(p/'probe.log').decode().splitlines()
 assert probe==[str(p/'pyexpat.cpython-312-x86_64-linux-gnu.so'),str(p/'_elementtree.cpython-312-x86_64-linux-gnu.so'),'oriole_compat_2.8.4']
 old=Path('/tmp/oriole-frame-integrated-gates')/('cpython-'+linkage)/'tests.log'
 failure_blocks[linkage]=failures(p/'tests.log')
 assert len(failure_blocks[linkage])==2 and failure_blocks[linkage]==failures(old)
 method_maps[linkage]=methods(p/'tests.log')
 skip_lines[linkage]=[l for l in read(p/'tests.log').decode().splitlines() if ' ... skipped ' in l]
 assert skip_lines[linkage]==[l for l in read(old).decode().splitlines() if ' ... skipped ' in l]
 assert 'Total tests: run=802 failures=2 skipped=14' in read(p/'tests.log').decode()
assert method_maps['shared']==method_maps['static']
# Capture unchanged helper source and exact outer bounds/cleanup source.
for name in ['run.py','extension_loader.py','check_extension_imports.py','text_fragmentation.py']:source_inputs[str(W/'tools/cpython'/name)]=sha(W/'tools/cpython'/name)
outer=read(G/'oriole-current-thin-pgo-cpython-gates.py').decode()
for token in ['process.wait(timeout=1200)','start_new_session=True','os.killpg(process.pid, signal.SIGKILL)',"item['exit'] = process.wait()"]:assert token in outer
assert 'timeout=900' in read(W/'tools/cpython/run.py').decode()
for p,h in hashes.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
review={'status':'independent_strict_cpython_parity_review_passed','date_utc':'2026-09-11',
 'scope':'Saved shared/static ThinLTO PGO strict suites, exact 802 method maps, failure bodies, skip lines, commands, source and fresh-import origins. No target executions.',
 'source_runtime':'be22a271f8a5c004d13e515cd4024a68afe57887','source_files':70,'libraries':controller['libraries'],'linkages':python,
 'outcome':'Both strict suites exit 2 with the same two existing ordinary-text callback-fragmentation failures. All method statuses, full failure bodies after source-path normalization, and 14 skip lines equal the corrected original baseline. Three accelerator import checks execute successfully in both linkages.',
 'limits':'120 seconds per CPython module; 900 seconds runner timeout; 1200 seconds outer job with process-group cleanup.',
 'limitations':['Parity is not a green-suite claim; two failures remain. Reported 14 skips comprise five whole methods, eight subtests and one class setup; three expected failures are separate.','Persistent loader checks attest four initial/fresh extension origin records per linkage. Strict logs do not separately record XML_Parse dladdr; parser provenance uses exact library copies, compile/link arguments and probe version.','Only ThinLTO PGO shared/static variants are covered; no fat-PGO, normal-variant, PBS, sanitizer, fuzz or broad C-API certification implied.','Full failure-body comparison normalizes only source path prefixes; diagnostic content is unchanged. Successful jobs do not independently exercise timeout/failure cleanup.'],
 'blockers':[],'checked_files':len(hashes),'controller_sha256':sha(G/'controller.json'),'source_manifest_sha256':sha('/tmp/oriole-native-byte-count-pgo-study/source.json')}
for name,data in [('review.json',review),('methods.json',method_maps),('failure-bodies.json',failure_blocks),('skip-lines.json',skip_lines),('source-inputs.json',source_inputs),('checked-files.json',hashes)]: (OUT/name).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'status':review['status'],'review_sha256':sha(OUT/'review.json'),'checked_files':len(hashes)}))
