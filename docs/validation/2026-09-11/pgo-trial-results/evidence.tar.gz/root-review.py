"""Independent root saved-artifact review; never executes downloaded code."""
from pathlib import Path
import json
import hashlib

root = Path('/tmp/oriole-pr126-pbs-results')
source = Path('/home/dev-user/code/oss/oriole-pbs-pgo-bundle')
bundle = root / 'validation/oriole-bundle'
run = bundle / 'pgo/runs/run-lcsrdws1'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = read(run / 'manifest.json')
outer = read(bundle / 'manifest.json')
assert read(bundle / 'pgo/latest.json')['sha256'] == sha(run / 'manifest.json')
assert (root / 'selected/python/licenses/LICENSE.oriole-build.txt').read_bytes() == (bundle / 'manifest.json').read_bytes()
for relative, digest in outer['sources'].items():
    assert sha(source / relative) == digest, relative
for relative, digest in manifest['source_sha256'].items():
    assert sha(source / relative) == digest, relative
for relative, digest in manifest['script_sha256'].items():
    assert sha(source / 'tools/pgo' / relative) == digest, relative
assert len(manifest['commands']) == 10
for command in manifest['commands']:
    assert command['returncode'] == 0 and command['status'] == 'passed'
    assert sha(run / command['log']) == command['log_sha256']
for relative, digest in manifest['profiles_sha256'].items():
    path = run / relative if relative == 'merged.profdata' else run / 'raw-profiles' / relative
    assert sha(path) == digest, relative
for relative, digest in manifest['inputs_sha256'].items():
    assert sha(run / 'inputs' / relative) == digest, relative
for phase, digest in manifest['training_sha256'].items():
    assert sha(run / (phase + '-training.json')) == digest, phase
static_hash = sha(root / 'selected/python/build/lib/libexpat.a')
assert static_hash == manifest['libraries_sha256']['use/liboriole_expat.a'] == '37c412bf52ba1891cb0268cba74bb57394698cc846fdc9954e7407e5c0faffb9'
generate = read(run / 'generate-training.json')
use = read(run / 'use-training.json')
assert generate['status'] == use['status'] == 'passed'
assert generate['rows'] == use['rows'] and len(generate['rows']) == 288
for artifact in read(root / 'artifacts.json')['artifacts']:
    filename = 'validation.zip' if artifact['name'] == 'oriole-pbs-validation' else 'distribution.zip'
    assert sha(root / filename) == artifact['digest'].removeprefix('sha256:')
result = {
    'status': 'passed',
    'scope': 'Root independent saved source/profile/log/training/static-archive and API ZIP digest review. Raw XML/glibc logs manually reviewed separately; no target/compiler execution.',
    'bundle_source_files': len(outer['sources']),
    'pgo_source_files': len(manifest['source_sha256']),
    'pipeline_files': len(manifest['script_sha256']),
    'successful_commands': 10,
    'generated_records_per_phase': 288,
    'manifest_sha256': sha(run / 'manifest.json'),
    'bundle_sha256': sha(bundle / 'manifest.json'),
    'shipped_static_sha256': static_hash,
    'controller_sha256': sha(Path(__file__)),
    'reviewer_correction': 'Initial inline reader failed before completion at script README.md because script keys are relative to tools/pgo, not repository root. This retained reader resolves each manifest map using its own documented root. No producer rerun or artifact mutation.',
    'limitations': 'Remote tools and non-shipped generated/shared library binaries are absent; their producer hashes remain scoped to the remote build. API digests are not a separately checked attestation.',
}
Path('/tmp/oriole-pr126-pbs-root-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
