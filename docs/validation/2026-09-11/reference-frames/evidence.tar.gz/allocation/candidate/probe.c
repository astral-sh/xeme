/* Allocation diagnostics only. Adapted from tests/c/allocations.c and the
 * reservation probe's dladdr binding; no elapsed-time measurements. */
#define _GNU_SOURCE
#include "expat.h"
#include <assert.h>
#include <dlfcn.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

enum { SLOT_LIMIT = 8192, SIZE_LIMIT = 4096, DEPTH_LIMIT = 256,
       INPUT_LIMIT = 2 * 1024 * 1024, NAME_LIMIT = 8192,
       CALLBACK_LIMIT = 262144, CALLBACK_BYTE_LIMIT = 32 * 1024 * 1024 };
typedef struct { void *pointer; size_t size; } Block;
typedef struct { char operation; unsigned phase; size_t size, count; } SizeCount;
typedef struct { size_t mallocs, reallocs, frees, requested, peak_bytes, peak_blocks; } Phase;
typedef struct { uint64_t hash; size_t length; } Name;
static Block blocks[SLOT_LIMIT];
static SizeCount sizes[SIZE_LIMIT];
static Phase phases[4];
static Name names[DEPTH_LIMIT];
static unsigned char input[INPUT_LIMIT];
static size_t size_count, live_bytes, live_blocks, peak_bytes, peak_blocks;
static size_t starts, ends, texts, text_bytes, callback_bytes, callbacks, depth;
static uint64_t event_hash = UINT64_C(14695981039346656037);
static unsigned phase;
static int allocation_failed;

static size_t add(size_t left, size_t right) {
    assert(right <= SIZE_MAX - left);
    return left + right;
}
static void record(char operation, size_t size) {
    for (size_t i = 0; i < size_count; i++) {
        if (sizes[i].operation == operation && sizes[i].phase == phase && sizes[i].size == size) {
            sizes[i].count++;
            return;
        }
    }
    assert(size_count < SIZE_LIMIT);
    sizes[size_count++] = (SizeCount){operation, phase, size, 1};
}
static Block *find(void *pointer) {
    for (size_t i = 0; i < SLOT_LIMIT; i++)
        if (blocks[i].pointer == pointer) return &blocks[i];
    assert(!"unknown, interior, or double-freed allocation");
    return NULL;
}
static void peaks(void) {
    if (live_bytes > peak_bytes) peak_bytes = live_bytes;
    if (live_blocks > peak_blocks) peak_blocks = live_blocks;
    if (live_bytes > phases[phase].peak_bytes) phases[phase].peak_bytes = live_bytes;
    if (live_blocks > phases[phase].peak_blocks) phases[phase].peak_blocks = live_blocks;
}
static void remember(void *pointer, size_t size) {
    if (!pointer) { allocation_failed = 1; return; }
    Block *block = find(NULL);
    *block = (Block){pointer, size};
    live_bytes = add(live_bytes, size);
    live_blocks++;
    peaks();
}
static void *tracked_malloc(size_t size) {
    phases[phase].mallocs++;
    phases[phase].requested = add(phases[phase].requested, size);
    record('M', size);
    void *pointer = malloc(size ? size : 1);
    remember(pointer, size);
    return pointer;
}
static void *tracked_realloc(void *pointer, size_t size) {
    phases[phase].reallocs++;
    phases[phase].requested = add(phases[phase].requested, size);
    record('R', size);
    if (!pointer) {
        void *replacement = malloc(size ? size : 1);
        remember(replacement, size);
        return replacement;
    }
    Block *block = find(pointer);
    void *replacement = realloc(pointer, size ? size : 1);
    if (!replacement) { allocation_failed = 1; return NULL; }
    assert(live_bytes >= block->size);
    live_bytes = add(live_bytes - block->size, size);
    *block = (Block){replacement, size};
    peaks();
    return replacement;
}
static void tracked_free(void *pointer) {
    phases[phase].frees++;
    if (!pointer) { record('F', 0); return; }
    Block *block = find(pointer);
    record('F', block->size);
    assert(live_bytes >= block->size && live_blocks > 0);
    live_bytes -= block->size;
    live_blocks--;
    /* Preserve the established native gate's release poisoning. */
    memset(pointer, 0xA5, block->size);
    free(pointer);
    *block = (Block){NULL, 0};
}
static uint64_t hash_bytes(uint64_t hash, const void *bytes, size_t length) {
    const unsigned char *text = bytes;
    for (size_t i = 0; i < length; i++) {
        hash ^= text[i];
        hash *= UINT64_C(1099511628211);
    }
    return hash;
}
static void hash_length(size_t length) {
    for (unsigned i = 0; i < 8; i++) {
        unsigned char byte = (unsigned char)(((uint64_t)length >> (8 * i)) & 255);
        event_hash = hash_bytes(event_hash, &byte, 1);
    }
}
static size_t name_length(const char *name) {
    size_t length = strnlen(name, NAME_LIMIT + 1);
    assert(length <= NAME_LIMIT);
    return length;
}
static void event(char kind, const char *bytes, size_t length) {
    callback_bytes = add(callback_bytes, length);
    assert(callback_bytes <= CALLBACK_BYTE_LIMIT);
    event_hash = hash_bytes(event_hash, &kind, 1);
    hash_length(length);
    event_hash = hash_bytes(event_hash, bytes, length);
}
static void start(void *data, const XML_Char *name, const XML_Char **attributes) {
    (void)data;
    assert(++callbacks <= CALLBACK_LIMIT && depth < DEPTH_LIMIT);
    size_t length = name_length(name);
    names[depth++] = (Name){hash_bytes(UINT64_C(14695981039346656037), name, length), length};
    starts++;
    event('S', name, length);
    size_t count = 0;
    for (; attributes[2 * count]; count++) {
        assert(count < 1024 && attributes[2 * count + 1]);
        event('A', attributes[2 * count], name_length(attributes[2 * count]));
        event('V', attributes[2 * count + 1], name_length(attributes[2 * count + 1]));
    }
    hash_length(count);
}
static void end(void *data, const XML_Char *name) {
    (void)data;
    assert(++callbacks <= CALLBACK_LIMIT && depth > 0);
    size_t length = name_length(name);
    Name expected = names[--depth];
    assert(expected.length == length && expected.hash == hash_bytes(UINT64_C(14695981039346656037), name, length));
    ends++;
    event('E', name, length);
}
static void text(void *data, const XML_Char *bytes, int length) {
    (void)data;
    assert(++callbacks <= CALLBACK_LIMIT && length >= 0);
    texts++;
    text_bytes = add(text_bytes, (size_t)length);
    event('T', bytes, (size_t)length);
}
static int origin(const char *name, void *address) {
    Dl_info info;
    if (!dladdr(address, &info) || !info.dli_fname) return 0;
    printf("ORIGIN_API\t%s\t%s\n", name, info.dli_fname);
    return 1;
}
static size_t number(const char *value) {
    char *end = NULL;
    unsigned long long n = strtoull(value, &end, 10);
    assert(value[0] && end && !end[0] && n <= SIZE_MAX);
    return (size_t)n;
}
int main(int argc, char **argv) {
    assert(argc == 7);
    alarm(3);
    setvbuf(stdout, NULL, _IONBF, 0);
#define ORIGIN(fn) assert(origin(#fn, (void *)fn))
    ORIGIN(XML_ParserCreate_MM); ORIGIN(XML_SetUserData);
    ORIGIN(XML_SetElementHandler); ORIGIN(XML_SetCharacterDataHandler);
    ORIGIN(XML_SetReturnNSTriplet); ORIGIN(XML_SetHashSalt);
    ORIGIN(XML_Parse); ORIGIN(XML_GetErrorCode); ORIGIN(XML_GetParsingStatus);
    ORIGIN(XML_ParserFree);
#undef ORIGIN
    FILE *file = fopen(argv[1], "rb");
    assert(file);
    size_t length = fread(input, 1, sizeof(input), file);
    assert(length > 0 && !ferror(file) && fgetc(file) == EOF);
    fclose(file);
    size_t expected_starts = number(argv[4]), expected_text = number(argv[5]);
    size_t warmup = number(argv[6]);
    assert(warmup <= length);
    char separator = !strcmp(argv[2], "nul") ? '\0' : '|';
    assert(!strcmp(argv[2], "off") || !strcmp(argv[2], "pipe") || !strcmp(argv[2], "nul"));
    const XML_Memory_Handling_Suite suite = {tracked_malloc, tracked_realloc, tracked_free};
    XML_Parser parser = XML_ParserCreate_MM(NULL, &suite, !strcmp(argv[2], "off") ? NULL : &separator);
    assert(parser && XML_SetHashSalt(parser, 1));
    XML_SetUserData(parser, NULL);
    XML_SetElementHandler(parser, start, end);
    XML_SetCharacterDataHandler(parser, text);
    XML_SetReturnNSTriplet(parser, number(argv[3]) != 0);
    int status = XML_STATUS_OK;
    size_t calls = 0;
    for (size_t offset = 0; offset < length;) {
        size_t count = length - offset < 4096 ? length - offset : 4096;
        if (offset < warmup && count > warmup - offset) count = warmup - offset;
        phase = offset < warmup ? 1 : 2;
        peaks();
        int final = offset + count == length;
        status = XML_Parse(parser, (const char *)input + offset, (int)count, final);
        printf("CALL\t%zu\t%u\t%zu\t%d\t%d\t%d\t%zu\t%zu\t%zu\t%zu\t%zu\n",
               ++calls, phase, count, final, status, (int)XML_GetErrorCode(parser),
               starts, ends, depth, live_bytes, live_blocks);
        if (status != XML_STATUS_OK) break;
        offset += count;
    }
    XML_ParsingStatus state = {XML_INITIALIZED, XML_FALSE};
    XML_GetParsingStatus(parser, &state);
    int error = XML_GetErrorCode(parser);
    size_t retained_bytes = live_bytes, retained_blocks = live_blocks;
    phase = 3;
    peaks();
    XML_ParserFree(parser);
    for (unsigned i = 0; i < 4; i++) {
        Phase *p = &phases[i];
        printf("PHASE\t%u\t%zu\t%zu\t%zu\t%zu\t%zu\t%zu\n", i,
               p->mallocs, p->reallocs, p->frees, p->requested, p->peak_bytes, p->peak_blocks);
    }
    for (size_t i = 0; i < size_count; i++)
        printf("SIZE\t%u\t%c\t%zu\t%zu\n", sizes[i].phase, sizes[i].operation, sizes[i].size, sizes[i].count);
    printf("RESULT\t%d\t%d\t%d\t%zu\t%zu\t%zu\t%zu\t%zu\t%zu\t%016" PRIx64 "\t%zu\t%zu\t%zu\t%zu\t%zu\t%zu\t%d\n",
           status, error, (int)state.parsing, starts, ends, depth, texts, text_bytes,
           callbacks, event_hash, retained_bytes, retained_blocks, peak_bytes,
           peak_blocks, live_bytes, live_blocks, allocation_failed);
    assert(status == XML_STATUS_OK && error == XML_ERROR_NONE && state.parsing == XML_FINISHED);
    assert(starts == expected_starts && ends == starts && depth == 0 && text_bytes == expected_text);
    assert(!allocation_failed && live_bytes == 0 && live_blocks == 0);
    return 0;
}
