"""Bounded, explicit build/run phases for selected-allocator diagnostics."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import resource
import shutil
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def limits():
    resource.setrlimit(resource.RLIMIT_AS, (1024**3,) * 2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024**2,) * 2)
    signal.alarm(3)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=['build', 'run'])
    parser.add_argument('--case')
    args = parser.parse_args()
    assert os.sched_getaffinity(0) == {4}
    plan = read(ROOT / 'plan.json')
    assert plan['status'] == 'prepared_not_executed'
    cases = {row['name']: row for row in plan['cases']}
    assert args.phase == 'build' or args.case in cases
    directory = ROOT / 'runs'
    directory.mkdir(exist_ok=True)
    name = 'build' if args.phase == 'build' else args.case
    receipt_path, log = directory / (name + '.json'), directory / (name + '.log')
    assert not receipt_path.exists() and not log.exists(), 'Retain every first attempt; no overwrite'
    receipt = {'status': 'started', 'phase': args.phase, 'case': args.case,
               'plan_sha256': sha(ROOT / 'plan.json'), 'started': time.time(),
               'scope': 'Selected allocation calls and callbacks; no elapsed performance claim.'}
    receipt_path.write_text(json.dumps(receipt) + '\n')
    process = None
    try:
        assert all(sha(path) == digest for path, digest in plan['pins'].items())
        library = directory / 'liboriole_expat.so'
        binary = directory / 'probe'
        environment = os.environ.copy()
        for key in ['LD_PRELOAD', 'LD_LIBRARY_PATH', 'LD_AUDIT', 'LLVM_PROFILE_FILE',
                    'PYTHONPATH', 'PYTHONHOME', 'CC', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS']:
            environment.pop(key, None)
        if args.phase == 'build':
            shutil.copy2(plan['library']['path'], library)
            command = ['/usr/bin/readelf', '-d', str(library)]
            dynamic = subprocess.run(command, capture_output=True, text=True, timeout=15, check=True)
            (directory / 'readelf.log').write_text(dynamic.stdout + dynamic.stderr)
            match = re.search(r'\(SONAME\).*\[([^]]+)\]', dynamic.stdout)
            if match and match[1] != library.name:
                assert Path(match[1]).name == match[1]
                (directory / match[1]).symlink_to(library.name)
            command = ['/usr/bin/cc', '-std=c11', '-O1', '-g', '-Wall', '-Wextra', '-Werror',
                       '-I' + plan['header_directory'], str(ROOT / 'probe.c'), str(library),
                       '-Wl,-rpath,' + str(directory), '-ldl', '-o', str(binary)]
            timeout = 120
        else:
            build = read(directory / 'build.json')
            assert build['status'] == 'reaped' and build['exit'] == 0
            assert sha(binary) == build['binary_sha256']
            assert sha(library) == plan['library']['sha256']
            case = cases[args.case]
            command = [str(binary), case['input'], case['namespace'], str(case['triplets']),
                       str(case['expected_starts']), str(case['expected_text_bytes']), str(case['warmup_bytes'])]
            timeout = 4
        receipt['argv'] = command
        receipt['timeout_seconds'] = timeout
        with log.open('xb') as stream:
            process = subprocess.Popen(command, stdout=stream, stderr=subprocess.STDOUT,
                                       env=environment, start_new_session=True,
                                       preexec_fn=limits if args.phase == 'run' else None)
            try:
                receipt['exit'] = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                receipt['outer_timeout'] = True
                os.killpg(process.pid, signal.SIGKILL)
                receipt['exit'] = process.wait()
        receipt['status'] = 'reaped'
        if args.phase == 'build' and receipt['exit'] == 0:
            receipt['binary_sha256'] = sha(binary)
        if args.phase == 'run':
            contents = log.read_text(errors='replace')
            origins = re.findall(r'^ORIGIN_API\t([^\t]+)\t(.+)$', contents, re.MULTILINE)
            expected = {'XML_ParserCreate_MM', 'XML_SetUserData', 'XML_SetElementHandler',
                        'XML_SetCharacterDataHandler', 'XML_SetReturnNSTriplet', 'XML_SetHashSalt',
                        'XML_Parse', 'XML_GetErrorCode', 'XML_GetParsingStatus', 'XML_ParserFree'}
            receipt['origin_verified'] = (len(origins) == len(expected)
                                          and {name for name, _ in origins} == expected
                                          and all(Path(path).resolve() == library.resolve() for _, path in origins))
            receipt['xml_parse_origin'] = next((path for name, path in origins if name == 'XML_Parse'), None)
            results = [line.split('\t') for line in contents.splitlines() if line.startswith('RESULT\t')]
            receipt['complete_result'] = len(results) == 1 and len(results[0]) == 18
            if receipt['complete_result']:
                row = results[0]
                receipt['callbacks'] = {'starts': int(row[4]), 'ends': int(row[5]), 'depth': int(row[6]),
                                        'text_callbacks': int(row[7]), 'text_bytes': int(row[8]),
                                        'count': int(row[9]), 'hash': row[10]}
                receipt['allocation'] = {'retained_bytes': int(row[11]), 'retained_blocks': int(row[12]),
                                         'peak_bytes': int(row[13]), 'peak_blocks': int(row[14]),
                                         'live_bytes_after_free': int(row[15]), 'live_blocks_after_free': int(row[16]),
                                         'allocation_failed': int(row[17])}
                receipt['successful_result'] = (row[1:4] == ['1', '0', '2']
                                                 and int(row[4]) == int(row[5]) == case['expected_starts']
                                                 and row[6] == '0' and int(row[8]) == case['expected_text_bytes']
                                                 and row[15:18] == ['0', '0', '0'])
    except BaseException as error:
        receipt['exception'] = repr(error)
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
            receipt['exit'] = process.wait()
        raise
    finally:
        receipt['completed'] = time.time()
        if log.exists():
            receipt['log_sha256'] = sha(log)
        receipt['pins_unchanged'] = all(sha(path) == digest for path, digest in plan['pins'].items())
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))
    return 0 if (receipt['exit'] == 0 and receipt['pins_unchanged']
                 and receipt.get('origin_verified', True) and receipt.get('successful_result', True)) else 1


if __name__ == '__main__':
    raise SystemExit(main())
