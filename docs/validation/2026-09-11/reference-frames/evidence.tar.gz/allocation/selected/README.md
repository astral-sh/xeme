# Suffix-sharing element-name allocation diagnostic

Prepared files only. C, runner, all twelve input byte sequences, warmup boundaries, callback expectations and limits are unchanged from `/tmp/oriole-stack-name-allocation-probe`. The plan binds the committed two-file candidate and its completed fresh PGO-use artifact. Original selected receipts/logs remain separately pinned comparison records.

Root runs `taskset -c 4 python3 run.py build` once, then `taskset -c 4 python3 run.py run --case CASE` once per declared case. Every first attempt is retained. Run only outside elapsed benchmark collection.

These are selected-allocator counts and tracked live/peak bytes, not elapsed performance or process RSS. Compare each fixed fixture against identical selected bytes; the two long-name fixtures straddle an input-buffer boundary. Suffix checks and retained name-buffer capacities remain costs to evaluate.
