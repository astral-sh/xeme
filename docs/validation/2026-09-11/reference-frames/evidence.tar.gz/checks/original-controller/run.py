from pathlib import Path
import hashlib, json, os, re, signal, subprocess, time

W = Path('/home/dev-user/code/oss/oriole-reference-frame')
O = Path(__file__).parent
assert os.sched_getaffinity(0) == {3}
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources = lambda: {str(p.relative_to(W)): sha(p) for p in sorted((W/'crates').rglob('*.rs'))}
env = os.environ.copy()
for key in ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'LLVM_PROFILE_FILE', 'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST', 'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST']:
    env.pop(key, None)
env.update(CARGO_HOME='/home/dev-user/.cache/toucan/cargo', CARGO_TARGET_DIR='/home/dev-user/.cache/oriole/targets/reference-frame', CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}', CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', RUSTUP_AUTO_INSTALL='0', CARGO_TERM_COLOR='never')
assert not (O/'summary.json').exists()
report = {'status': 'incomplete', 'commands': []}
save = lambda: (O/'summary.json').write_text(json.dumps(report, indent=2)+'\n')
packages = ['--locked', '--offline', '-p', 'oriole', '-p', 'oriole_expat', '-p', 'oriole_storage']
try:
    for label, args in [('fmt01', ['fmt', '--all', '--check']), ('check01', ['check', *packages, '--all-targets']), ('tests01', ['test', *packages]), ('clippy01', ['clippy', *packages, '--all-targets', '--', '-D', 'warnings'])]:
        cmd = ['cargo', '+ohm', '-Zohm-defaults=no', *args]
        row = {'label': label, 'command': cmd, 'cwd': str(W), 'affinity': [3], 'source_before': sources(), 'start': time.time()}
        report['commands'].append(row)
        save()
        proc = None
        with (O/(label+'.log')).open('wb') as log:
            try:
                proc = subprocess.Popen(cmd, cwd=W, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                row['exit'] = proc.wait(timeout=900)
            except BaseException as error:
                row['exception'] = repr(error)
                if proc is not None:
                    os.killpg(proc.pid, signal.SIGKILL)
                    row['exit'] = proc.wait()
                raise
            finally:
                row.update(end=time.time(), reaped=proc is not None and proc.returncode is not None, source_after=sources())
                log.flush()
                row['log_sha256'] = sha(O/(label+'.log'))
                (O/(label+'.json')).write_text(json.dumps(row, indent=2)+'\n')
                save()
        assert row['exit'] == 0 and row['source_before'] == row['source_after'], label
        print(label, 'passed', flush=True)
    counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (O/'tests01.log').read_text())
    assert counts and all(int(failed) == int(ignored) == 0 for _, failed, ignored in counts)
    report.update(status='passed', test_count=sum(int(count) for count, _, _ in counts), test_groups=len(counts), source_after=sources())
finally:
    save()
print(json.dumps({'status': report['status'], 'test_count': report.get('test_count'), 'test_groups': report.get('test_groups')}), flush=True)
