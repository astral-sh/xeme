# Reference-frame downstream controllers

Candidate `0f66d54ac8418f0a6e628ad18570677a19c9ed45`; selected suffix control `a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9`. Source changes: one runtime file (`crates/oriole/src/lib.rs`), adapter tests (`crates/oriole/tests/adapter_frame.rs`), and inherited integration coverage (`tests/c/integration.c`). These instructions launch targets only when root releases each stage. No agent has executed them during preparation.

## Allocation diagnostic

Build the existing probe first, then run each of its twelve unchanged cases once:

```sh
taskset -c 4 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-allocation-probe/run.py build
```

```sh
taskset -c 4 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-allocation-collect.py
```

After all cases finish and their process handles are reaped, the saved-only comparison reads the original suffix records and every intermediate `CALL` live-byte/block value:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-allocation-compare.py --released --head 0f66d54ac8418f0a6e628ad18570677a19c9ed45
```

These fixed 4 KiB fixtures measure selected allocation calls, peaks and callback behavior, not elapsed time or process RSS. They are not a new reference-specific allocation workload.

## Strict CPython

The controller preserves the explicit cleanup backport, both linkages, original timeouts and all 809 rendered baseline outcomes. It uses the matching suffix strict controls and candidate PGO libraries.

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-strict-cpython.py
```

## Python performance

Root has already started PGO preparation. Do not repeat it. The remaining ordinary-build preparation command is:

```sh
/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-python-study/normal/run.py prepare
```

Each preparation wrapper compiles six extensions and runs 72 canonical preflights on CPU 3. Performance extensions remain unmodified CPython sources. After preparation checks and root release, each timing wrapper runs on CPU 0; run them separately and retain all first results:

```sh
/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-python-study/normal/run.py time
```

```sh
/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-python-study/pgo/run.py time
```

The worker, conditions, order, time intervals, iteration counts and limits remain the original suffix protocol. Source and library paths plus captions identify this candidate. API, allocation, strict and performance consumers are separate campaigns; completion of one does not establish another's result.
