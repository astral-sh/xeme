"""Bind completed reference-frame builds to unchanged saved-allocation and native protocols."""
from pathlib import Path
import argparse
import ast
import copy
import difflib
import hashlib
import importlib.util
import json
import os
import re
import shutil

BUILD = Path('/tmp/oriole-reference-frame-pgo-study')
CONTROL = Path('/tmp/oriole-suffix-element-names-pgo-study')
BASE_PROBE = Path('/tmp/oriole-suffix-element-names-allocation-probe')
PROBE = Path('/tmp/oriole-reference-frame-allocation-probe')
BASE_NATIVE = Path('/tmp/oriole-suffix-element-names-native-study')
NATIVE = Path('/tmp/oriole-reference-frame-native-study')
BINDER = Path('/tmp/oriole-reference-frame-build-bindings.py')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def library(build, pair, mode):
    path = build / 'normal/liboriole_expat.so' if mode == 'normal' else Path(pair['pgo_manifest']['path']).parent / 'use/liboriole_expat.so'
    digest = pair['normal_libraries']['liboriole_expat.so'] if mode == 'normal' else pair['pgo_libraries']['use/liboriole_expat.so']
    assert sha(path) == digest
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--released-build', action='store_true')
    parser.add_argument('--head', required=True)
    args = parser.parse_args()
    assert __debug__ and args.released_build and re.fullmatch('[0-9a-f]{40}', args.head)
    assert os.sched_getaffinity(0) == {6}
    assert not PROBE.exists() and not NATIVE.exists() and not (BUILD / 'build-readback.json').exists()
    assert sha(BINDER) == '252f0d0c2dfde9f246e1cd26f84e16df4c229d92a0754e12ed70f72331cdb548'
    spec = importlib.util.spec_from_file_location('reference_frame_build_bindings', BINDER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    prepared = read(BUILD / 'preparation.json')
    assert prepared['head'] == args.head
    bindings = module.verify(BUILD, CONTROL, args.head, prepared['expected_source_delta'], prepared['expected_test_count'])
    save(BUILD / 'build-readback.json', bindings)
    pair, selected = bindings['pair'], bindings['control_pair']
    worktree = Path(bindings['source']['worktree'])

    # Exactly the existing twelve 4KiB-feed diagnostics, with suffix now the selected control.
    baseline = read(BASE_PROBE / 'plan.json')
    assert len(baseline['cases']) == 12 and baseline['status'] == 'prepared_not_executed'
    assert baseline['source_commit'] == bindings['control_source']['candidate_base_commit']
    assert baseline['library'] == {'path': str(library(CONTROL, selected, 'pgo')), 'sha256': sha(library(CONTROL, selected, 'pgo'))}
    compared = {}
    for name in ['build'] + [row['name'] for row in baseline['cases']]:
        receipt_path, log = BASE_PROBE / 'runs' / (name + '.json'), BASE_PROBE / 'runs' / (name + '.log')
        receipt = read(receipt_path)
        assert receipt['status'] == 'reaped' and receipt['exit'] == 0 and receipt['pins_unchanged']
        assert receipt['plan_sha256'] == sha(BASE_PROBE / 'plan.json') and receipt['log_sha256'] == sha(log)
        if name != 'build':
            assert receipt['origin_verified'] and receipt['complete_result'] and receipt['successful_result']
        compared[name] = {str(p): sha(p) for p in [receipt_path, log]}
    PROBE.mkdir()
    (PROBE / 'inputs').mkdir()
    for name in ['probe.c', 'run.py']:
        shutil.copyfile(BASE_PROBE / name, PROBE / name)
    plan = copy.deepcopy(baseline)
    plan['scope'] = 'Fresh reference-frame PGO allocation diagnostic against selected suffix sharing. Identical C, runner, twelve input byte sequences, 4KiB feed width, warmup boundaries and limits. Every CALL records intermediate live bytes/blocks. Direct character-reference frame uses direct reference frames, with identical compiler recipes. Preparation executes no targets.'
    plan['source_commit'] = args.head
    plan['library'] = {'path': str(library(BUILD, pair, 'pgo')), 'sha256': sha(library(BUILD, pair, 'pgo'))}
    plan['header_directory'] = str(worktree / 'include')
    for before, after in zip(baseline['cases'], plan['cases'], strict=True):
        dest = PROBE / 'inputs' / Path(before['input']).name
        shutil.copyfile(before['input'], dest)
        assert sha(dest) == before['input_sha256']
        after['input'] = str(dest)
        assert {k: v for k, v in before.items() if k != 'input'} == {k: v for k, v in after.items() if k != 'input'}
    pins = dict(bindings['inputs'])
    for path in [Path(__file__), BINDER, BASE_PROBE / 'plan.json', BASE_PROBE / 'probe.c', BASE_PROBE / 'run.py', PROBE / 'probe.c', PROBE / 'run.py', Path('/usr/bin/cc').resolve(), Path('/usr/bin/readelf').resolve()]:
        pins[str(path)] = sha(path)
    for case in plan['cases']:
        pins[case['input']] = case['input_sha256']
    for records in compared.values():
        pins.update(records)
    plan['pins'] = pins
    plan['compared_selected_baseline'] = {'source_commit': baseline['source_commit'], 'library': baseline['library'], 'plan': {'path': str(BASE_PROBE / 'plan.json'), 'sha256': sha(BASE_PROBE / 'plan.json')}, 'raw_records': compared, 'comparison_rule': 'Compare matching fixed fixtures and every intermediate CALL live-byte/block value. The capacity fixtures straddle an input-buffer growth boundary; compare only identical inputs.'}
    assert plan['bounds'] == baseline['bounds'] and all(sha(path) == digest for path, digest in pins.items())
    save(PROBE / 'plan.json', plan)
    (PROBE / 'README.md').write_text('# Direct character-reference frame allocation diagnostic\n\nPrepared files only. Run the existing build phase, then each of the twelve cases once. Original 4KiB feeds, fixture bytes, limits and callback expectations are unchanged. Suffix-sharing measurements remain separately pinned selected records.\n\nInspect every intermediate CALL live-byte and live-block value as well as aggregate peaks and final retained bytes. These allocation metrics do not measure RSS or elapsed speed.\n')

    # Retain all conditions, randomization, timing arithmetic, callback checks and limits.
    NATIVE.mkdir()
    for mode in ['normal', 'pgo']:
        old, out = BASE_NATIVE / mode, NATIVE / mode
        original = read(old / 'adaptation.json')
        assert sha(old / 'native_screen.py') == original['controller_sha256'] and sha(old / 'run.py') == original['wrapper_sha256']
        candidate_lib, control_lib = library(BUILD, pair, mode), library(CONTROL, selected, mode)
        assert original['candidate_library'] == {'path': str(control_lib), 'sha256': sha(control_lib)}
        assert sha(original['expat_library']['path']) == original['expat_library']['sha256']
        before = (old / 'native_screen.py').read_text()
        replacements = [(original['candidate_library']['path'], str(candidate_lib)), (original['control_library']['path'], str(control_lib)), (str(old), str(out)), ('Expanded-first element names with shared raw suffixes', 'Direct character-reference frame'), ('selected capacity baseline', 'selected suffix-sharing element-name baseline')]
        after = before
        for left, right in replacements:
            assert left in after
            after = after.replace(left, right)
        restored = after
        for left, right in reversed(replacements):
            restored = restored.replace(right, left)
        assert restored == before and ast.dump(ast.parse(restored)) == ast.dump(ast.parse(before))
        out.mkdir()
        (out / 'native_screen.py').write_text(after)
        (out / 'run.py').write_bytes((old / 'run.py').read_bytes())
        (out / 'adaptation.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True))))
        save(out / 'adaptation.json', {'status': 'passed', 'prepared_not_executed': True, 'source_manifest_sha256': sha(BUILD / 'source.json'), 'control_source_manifest_sha256': sha(CONTROL / 'source.json'), 'build_pair_sha256': sha(BUILD / 'pair-report.json'), 'control_build_pair_sha256': sha(CONTROL / 'pair-report.json'), 'build_readback_sha256': sha(BUILD / 'build-readback.json'), 'controller_sha256': sha(out / 'native_screen.py'), 'wrapper_sha256': sha(out / 'run.py'), 'candidate_library': {'path': str(candidate_lib), 'sha256': sha(candidate_lib)}, 'control_library': {'path': str(control_lib), 'sha256': sha(control_lib)}, 'expat_library': original['expat_library'], 'origin': str(old), 'replacement_pairs': replacements, 'inverse_text_and_ast_equal': True, 'scope': 'Direct character-reference frame candidate ' + args.head + ' versus suffix selected control. Same 28 conditions, seven pairs, 2026091003 seed, callbacks, limits and compiler settings. Character-reference delivery changes; all adverse conditions must be reported. Preparation executes no parser/compiler/elapsed targets.'})
    print(json.dumps({'status': 'prepared_not_executed', 'head': args.head, 'allocation_plan': str(PROBE / 'plan.json'), 'allocation_plan_sha256': sha(PROBE / 'plan.json'), 'native_study': str(NATIVE), 'measurement_order': 'Normal native screen first; all remaining targets await root release.', 'build_summary': bindings['summary'], 'targets_executed': False}))


if __name__ == '__main__':
    main()
