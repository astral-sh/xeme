"""Run unchanged upstream CPython tests against both fresh candidate linkages."""
from pathlib import Path
import hashlib
import json
import os
import re
import signal
import subprocess
import time

ROOT = Path('/tmp/oriole-reference-frame-strict-cpython')
WORK = Path('/home/dev-user/code/oss/oriole-reference-frame')
BUILD = Path('/tmp/oriole-reference-frame-pgo-study')
BASELINE = Path('/tmp/oriole-suffix-element-names-strict-cpython')
BASELINE_BUILD = Path('/tmp/oriole-suffix-element-names-pgo-study')
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.sched_getaffinity(0) == {3}
pair = json.loads((BUILD / 'pair-report.json').read_text())
source = json.loads((BUILD / 'source.json').read_text())
assert pair['status'] == 'passed'
assert source['candidate_base_commit'] == '0f66d54ac8418f0a6e628ad18570677a19c9ed45'
assert pair['source_manifest_sha256'] == sha(BUILD / 'source.json')
baseline_pair = json.loads((BASELINE_BUILD / 'pair-report.json').read_text())
baseline_source = json.loads((BASELINE_BUILD / 'source.json').read_text())
assert baseline_pair['status'] == 'passed'
assert baseline_pair['source_manifest_sha256'] == sha(BASELINE_BUILD / 'source.json')
assert baseline_source['candidate_base_commit'] == 'a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9'
preparation = json.loads((BUILD / 'preparation.json').read_text())
assert preparation['head'] == source['candidate_base_commit']
assert preparation['control_head'] == baseline_source['candidate_base_commit']
assert preparation['source_manifest_sha256'] == sha(BUILD / 'source.json')
assert source['source_sha256'].keys() == baseline_source['source_sha256'].keys()
source_delta = sorted(n for n, digest in source['source_sha256'].items()
                      if digest != baseline_source['source_sha256'][n])
assert source_delta == sorted(preparation['expected_source_delta'])
assert source_delta == ['crates/oriole/src/lib.rs', 'crates/oriole/tests/adapter_frame.rs',
                        'tests/c/integration.c']
expected_delta_file = Path(preparation['expected_source_delta_file'])
assert sha(expected_delta_file) == preparation['expected_source_delta_sha256']
assert sorted(json.loads(expected_delta_file.read_text())) == source_delta
build_readback = json.loads((BUILD / 'build-readback.json').read_text())
assert build_readback['source'] == source and build_readback['pair'] == pair
assert build_readback['control_source'] == baseline_source
assert build_readback['control_pair'] == baseline_pair
assert build_readback['summary']['changed_vs_selected'] == source_delta
pgo_manifest = Path(pair['pgo_manifest']['path'])
assert sha(pgo_manifest) == pair['pgo_manifest']['sha256']
library_dir = pgo_manifest.parent / 'use'
pins = {str(WORK / n): digest for n, digest in source['source_sha256'].items()}
for p in [*list((WORK / 'tools/cpython').glob('*.py')), Path(PYTHON),
          BUILD / 'pair-report.json', BUILD / 'source.json', BUILD / 'preparation.json',
          BUILD / 'build-readback.json', pgo_manifest, expected_delta_file,
          WORK / 'integration/python-build-standalone/consumer-fix/provenance.json',
          WORK / 'integration/python-build-standalone/consumer-fix/cpython-3.12.13-external-parser.patch',
          Path(__file__)]:
    pins[str(p)] = sha(p)
for extension in ('so', 'a'):
    p = library_dir / ('liboriole_expat.' + extension)
    assert sha(p) == pair['pgo_libraries']['use/' + p.name]
    pins[str(p)] = sha(p)
for p in [BASELINE / 'report.json', BASELINE / 'independent-review.json',
          BASELINE_BUILD / 'pair-report.json', BASELINE_BUILD / 'source.json']:
    pins[str(p)] = sha(p)
for linkage, extension in [('shared', 'so'), ('static', 'a')]:
    summary = json.loads((BASELINE / linkage / 'summary.json').read_text())
    assert summary['library_sha256'] == baseline_pair['pgo_libraries']['use/liboriole_expat.' + extension]
    assert summary['text_fragmentation'] is None
    assert summary['consumer_fix'] == json.loads(
        (WORK / 'integration/python-build-standalone/consumer-fix/provenance.json').read_text())
    for name in ['summary.json', 'tests.log', 'origin.log', 'pyexpat.c']:
        p = BASELINE / linkage / name
        pins[str(p)] = sha(p)
assert all(sha(p) == h for p, h in pins.items())
ROOT.mkdir(exist_ok=False)
report = {'status': 'incomplete', 'pins': pins, 'commands': [],
          'source_commit': source['candidate_base_commit'],
          'source_delta': source_delta,
          'baseline_source_commit': baseline_source['candidate_base_commit'],
          'scope': 'Strict upstream tests with the explicit pinned CPython allocation-failure cleanup backport. Compare both linkages with the measured suffix-sharing strict controls; no text-fragmentation allowance. Performance extensions remain unmodified and are not used here; strict exits and all test output are retained.'}
def save():
    (ROOT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

try:
    for linkage, extension in [('shared', 'so'), ('static', 'a')]:
        output = ROOT / linkage
        command = [PYTHON, '-I', '-S', str(WORK / 'tools/cpython/run.py'),
                   '--source', '/home/dev-user/.cache/oriole/upstream/cpython-3.12.13',
                   '--library', str(library_dir / ('liboriole_expat.' + extension)),
                   '--output', str(output), '--consumer-fix']
        if linkage == 'static':
            for name in ['gcc_s', 'util', 'rt', 'pthread', 'm', 'dl', 'c']:
                command += ['--native-library', name]
        row = {'linkage': linkage, 'argv': command, 'started': time.time(), 'timeout': 1000}
        report['commands'].append(row)
        save()
        with (ROOT / (linkage + '.stdout')).open('xb') as out, (ROOT / (linkage + '.stderr')).open('xb') as err:
            process = subprocess.Popen(command, cwd=WORK, stdout=out, stderr=err, start_new_session=True)
            try:
                row['exit'] = process.wait(timeout=row['timeout'])
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                row['exit'] = process.wait()
                row['timeout_reached'] = True
            except BaseException:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL)
                row['exit'] = process.wait()
                row['reaped'] = True
                save()
                raise
            row['reaped'] = process.poll() is not None
        row['completed'] = time.time()
        for suffix in ['stdout', 'stderr']:
            row[suffix + '_sha256'] = sha(ROOT / (linkage + '.' + suffix))
        save()
        assert row['exit'] in [0, 2] and not row.get('timeout_reached'), row
        summary = json.loads((output / 'summary.json').read_text())
        assert summary['tests_exit_code'] == summary['gate_exit_code'] == row['exit']
        assert summary['probe_exit_code'] == summary['origin_exit_code'] == 0
        assert summary['text_fragmentation'] is None
        assert summary['library_sha256'] == pins[str(library_dir / ('liboriole_expat.' + extension))]
        row['summary_sha256'] = sha(output / 'summary.json')
        baseline_summary = json.loads((BASELINE / linkage / 'summary.json').read_text())
        assert summary['test_command'] == baseline_summary['test_command']
        assert summary['cpython_revision'] == baseline_summary['cpython_revision']
        assert summary['consumer_fix'] == baseline_summary['consumer_fix']
        assert sha(output / 'pyexpat.c') == sha(BASELINE / linkage / 'pyexpat.c')
        pattern = r'^(.+?) \.\.\. (ok|FAIL|ERROR|skipped.*|expected failure|unexpected success)$'
        baseline_outcomes = [match.group(0) for match in re.finditer(
            pattern, (BASELINE / linkage / 'tests.log').read_text(), re.MULTILINE)]
        candidate_outcomes = [match.group(0) for match in re.finditer(
            pattern, (output / 'tests.log').read_text(), re.MULTILINE)]
        assert baseline_outcomes and candidate_outcomes
        comparison = {
            'baseline': str(BASELINE / linkage),
            'baseline_source_commit': baseline_source['candidate_base_commit'],
            'baseline_tests_log_sha256': sha(BASELINE / linkage / 'tests.log'),
            'candidate_tests_log_sha256': sha(output / 'tests.log'),
            'baseline_tests_exit': baseline_summary['tests_exit_code'],
            'candidate_tests_exit': summary['tests_exit_code'],
            'baseline_rendered_outcome_lines': len(baseline_outcomes),
            'candidate_rendered_outcome_lines': len(candidate_outcomes),
            'outcome_lines_equal': candidate_outcomes == baseline_outcomes,
            'changes': [
                {'index': index,
                 'baseline': baseline_outcomes[index] if index < len(baseline_outcomes) else None,
                 'candidate': candidate_outcomes[index] if index < len(candidate_outcomes) else None}
                for index in range(max(len(baseline_outcomes), len(candidate_outcomes)))
                if (baseline_outcomes[index] if index < len(baseline_outcomes) else None)
                != (candidate_outcomes[index] if index < len(candidate_outcomes) else None)
            ],
        }
        (output / 'comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
        row['comparison'] = comparison
        print(linkage, row['exit'], flush=True)
    report['status'] = 'completed_strict_results'
finally:
    report['pins_unchanged'] = all(sha(p) == h for p, h in pins.items())
    save()
assert report['pins_unchanged']
