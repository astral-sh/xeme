"""Package the selected scalar-reference frame's completed saved records; no targets."""
from pathlib import Path
import csv
import gzip
import hashlib
import io
import json
import os
import tarfile

assert __debug__ and os.sched_getaffinity(0) == {6}
O = Path('/tmp/oriole-reference-frame-evidence')
D = Path('/tmp/oriole-reference-frame-evidence-drafts')
W = Path('/home/dev-user/code/oss/oriole-reference-frame')
B = Path('/tmp/oriole-reference-frame-pgo-study')
N = Path('/tmp/oriole-reference-frame-native-study')
NV = Path('/tmp/oriole-reference-frame-native-independent-review')
P = Path('/tmp/oriole-reference-frame-python-study')
PV = Path('/tmp/oriole-reference-frame-python-independent-review')
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(Path(path).read_text())
if not D.exists():
    assert set(p.name for p in O.iterdir()) == {'inventory.json', 'README.draft.md', 'report.draft.json'}
    O.rename(D)
assert not O.exists()
source = read(B / 'source.json')
assert source['candidate_base_commit'] == '0f66d54ac8418f0a6e628ad18570677a19c9ed45'
assert source['source_count'] == 72
native = {phase: read(NV / (phase + '-review.json')) for phase in ['normal', 'pgo']}
python = {phase: read(PV / (phase + '-review.json')) for phase in ['normal', 'pgo']}
for phase in ['normal', 'pgo']:
    assert native[phase]['status'] == 'passed'
    assert native[phase]['totals'] == {'conditions': 28, 'preflight_workers': 84, 'timed_workers': 588, 'all_workers': 672, 'all_samples': 106176}
    assert python[phase]['status'] == 'passed_independent_raw_elapsed_reconstruction'
    assert python[phase]['counts']['all_workers'] == 576
    assert python[phase]['counts']['all_samples'] == 26364
assert sha((PV / 'normal-review.json').read_bytes()) == '1dd4850527864b4bc0d4e087c7f009df6842bb26f7e061e6d4695ae14d543284'
files = {}
members = []
excluded = []


def add(path, name):
    path = Path(path)
    assert name not in files, name
    if path.is_symlink():
        excluded.append({'path': str(path), 'reason': 'symlink'})
        return
    content = path.read_bytes()
    if content.startswith((b'\x7fELF', b'!<arch>')) or path.suffix in {'.a', '.so', '.rlib', '.rmeta', '.profraw', '.profdata', '.pyc'}:
        excluded.append({'path': str(path), 'size': len(content), 'sha256': sha(content), 'reason': 'binary'})
        return
    files[name] = content
    members.append({'member': name, 'original_path': str(path), 'size': len(content), 'sha256': sha(content)})


def tree(path, prefix):
    path = Path(path)
    assert path.is_dir(), path
    for child in sorted(path.rglob('*')):
        if child.is_file() and '__pycache__' not in child.parts:
            add(child, prefix + str(child.relative_to(path)))


for label, build in [('candidate', B), ('selected', Path('/tmp/oriole-suffix-element-names-pgo-study'))]:
    for path in sorted(build.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log', '.py', '.patch'}:
            add(path, 'build/' + label + '/' + path.name)
    tree(build / 'pipeline', 'build/' + label + '/pipeline/')
    if label == 'candidate':
        tree(build / 'local-checks', 'checks/')
    pair = read(build / 'pair-report.json')
    run = Path(pair['pgo_manifest']['path']).parent
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log'}:
            add(path, 'build/' + label + '/pgo/' + path.name)
    tree(run / 'inputs', 'build/' + label + '/pgo/inputs/')
    manifest = read(build / 'source.json')
    for name, digest in manifest['source_sha256'].items():
        path = Path(manifest['worktree']) / name
        assert sha(path.read_bytes()) == digest, path
        add(path, 'source/' + label + '/' + name)
tree('/tmp/oriole-reference-frame-checks', 'checks/original-controller/')
tree(W / 'tools/cpython', 'source/consumer-tools/')
tree(W / 'integration/python-build-standalone/consumer-fix', 'source/strict-consumer-fix/')
tree('/tmp/oriole-reference-frame-review', 'review/')
for phase in ['normal', 'pgo']:
    tree(N / phase, 'native/' + phase + '/')
    tree(P / phase, 'python/' + phase + '/')
tree(NV, 'native/review/')
tree(PV, 'python/review/')
add('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c', 'native/support/native_driver.c')
tree('/tmp/oriole-reference-frame-api-gates', 'compatibility/api/candidate/')
for name in ['results.json', 'tests.log', 'manifest.json']:
    add(Path('/tmp/oriole-suffix-element-names-api-gates/api-native/upstream-api') / name,
        'compatibility/api/selected/' + name)
for label, stem in [('candidate', 'reference-frame'), ('selected', 'suffix-element-names')]:
    tree('/tmp/oriole-' + stem + '-strict-cpython', 'compatibility/strict/' + label + '/')
    tree('/tmp/oriole-' + stem + '-allocation-probe', 'allocation/' + label + '/')
for original in read(D / 'inventory.json')['additional_controllers']:
    add(original, 'controllers/' + Path(original).name)
add(__file__, 'controllers/package.py')
for path in sorted(Path('/tmp').glob('oriole-reference-frame-allocation-*.stdout')):
    add(path, 'allocation/controller-stdout/' + path.name)

# Original Expat compiler/training records describe both comparison libraries.
for path in sorted(Path('/tmp/oriole-pgo-study').glob('expat-*')):
    if path.is_file() and (path.suffix == '.json' or path.name.endswith(('-compile.log', '-configure.log'))):
        add(path, 'build/expat/' + path.name)
protocol = read(N / 'normal/native-screen/protocol.json')
for original, digest in protocol['hashes'].items():
    path = Path(original)
    if path.suffix in {'.xml', '.svg', '.ui', '.xsl'}:
        assert sha(path.read_bytes()) == digest
        add(path, 'inputs/native/' + path.parent.name + '/' + path.name)
corpus = Path('/home/dev-user/code/oss/oriole/benchmarks/projects')
add(corpus / 'corpus-manifest.json', 'inputs/projects/corpus-manifest.json')
for project in read(corpus / 'corpus-manifest.json')['projects']:
    for item in project['files']:
        path = corpus / item['path']
        assert sha(path.read_bytes()) == item['sha256']
        add(path, 'inputs/projects/' + item['path'])
cp = Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13')
for name in ['Modules/pyexpat.c', 'Modules/_elementtree.c', 'Include/pyexpat.h']:
    add(cp / name, 'source/cpython-unmodified/' + name)
for name in ['LICENSE-MIT', 'LICENSE-APACHE', 'tests/c/UPSTREAM-NOTICES.txt']:
    add(W / name, 'notices/oriole/' + Path(name).name)
add('/home/dev-user/.cache/oriole/upstream/expat-2.8.4/COPYING', 'notices/expat/COPYING')
add(cp / 'LICENSE', 'notices/cpython/LICENSE')

O.mkdir()
with (O / 'evidence.tar.gz').open('xb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as archive:
            for name, content in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(content)
                archive.addfile(info, io.BytesIO(content))
index = {'schema': 'saved-record-bundle-v1', 'scope': 'Selected direct scalar-reference adapter frame: completed source/build/check/compatibility/allocation and ordinary/PGO native/CPython saved records. Original absolute paths identify the measuring machine. No targets are executed by this bundle.', 'archive': 'evidence.tar.gz', 'archive_sha256': sha((O / 'evidence.tar.gz').read_bytes()), 'members': sorted(members, key=lambda row: row['member']), 'excluded': excluded}
(O / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
for directory, filename, count in [(NV, 'conditions.csv', 56), (PV, 'python-conditions.csv', 48)]:
    ordinary = list(csv.reader(io.StringIO((directory / 'normal-conditions.csv').read_text())))
    pgo = list(csv.reader(io.StringIO((directory / 'pgo-conditions.csv').read_text())))
    assert ordinary[0] == pgo[0]
    rows = ordinary + pgo[1:]
    assert len(rows) == count + 1
    with (O / filename).open('w', newline='') as stream:
        csv.writer(stream).writerows(rows)
(O / 'allocations.csv').write_bytes(Path('/tmp/oriole-reference-frame-allocation-probe/comparison.csv').read_bytes())
report = read(D / 'report.draft.json')
report['status'] = 'completed_saved_records'
report['decision'] = 'selected'
report['measured_source_commit'] = source['candidate_base_commit']
report['source_equivalent_restacked_commit'] = '8b00d4cbb3f540647e1d7d795d0a04df00ed92f4'
report['selection_reason'] = 'Accept the tiny existing-frame reuse for PGO native -2.03%, ordinary CPython -1.03% and generated reference improvements, with PGO CPython effectively flat. Disclose ordinary native +0.79% and 18/24 adverse conditions; no new compatibility gap or added storage. This is a considered tradeoff, not a predeclared numeric acceptance rule.'
report['native'] = {phase: native[phase]['native'][phase] for phase in ['normal', 'pgo']}
report['python'] = {phase: {'counts': python[phase]['counts'], 'aggregates': python[phase]['aggregates'], 'all_conditions': [{'condition': row['condition'], 'median_ratios': row['median_ratios']} for row in python[phase]['summary']]} for phase in ['normal', 'pgo']}
report['totals'] = report.pop('expected_totals_after_final_python_audit')
report['totals']['all_conditions'] = 104
pair = read(B / 'pair-report.json')
report['builds']['normal_libraries'] = pair['normal_libraries']
report['builds']['pgo_libraries'] = pair['pgo_libraries']
report['review_corrections'] = [
    'Initial source review captured an empty unqualified diff after root committed; original note/empty patch and corrected explicit-revision patch are preserved.',
    'Consumer preparer changed source-scope prose before execution: focused adapter tests and inherited C fixture; original and corrected preparers retained.',
    'Compatibility reviewer initially assumed _elementtree directly linked Expat. The corrected saved-only review recognizes the pyexpat expat_CAPI capsule; the review note is retained. Failed ad-hoc tool output was in the conversation, not a separate archived raw receipt.',
]
report['scope'] = 'Selected small runtime optimization; original and PGO results remain separate. One machine and fixed corpus, not whole-application performance. Overall PGO native 1.326116x and CPython 1.117937x Expat remain outside the 1.10x goal. API/strict failures remain. No RSS/layout probe or one-allocation-per-reference saving is claimed.'
evidence_names = ['build/candidate/build-readback.json', 'checks/original-controller/summary.json', 'native/review/normal-review.json', 'native/review/pgo-review.json', 'python/review/normal-preflight-review.json', 'python/review/pgo-preflight-review.json', 'python/review/normal-review.json', 'python/review/pgo-review.json', 'compatibility/api/candidate/api-native/report.json', 'compatibility/strict/candidate/report.json', 'allocation/candidate/comparison.json']
report['evidence'] = {'reports': [{'member': name, 'sha256': sha(files[name])} for name in evidence_names], 'archive_sha256': index['archive_sha256'], 'archive_members': len(members)}
(O / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
readme = (D / 'README.draft.md').read_text()
readme = readme.replace('**Draft: selection pending the final ordinary-build CPython result.**', '**Selected, with an ordinary native performance cost.**')
readme = readme.replace('PGO CPython time is effectively flat (0.17% faster).', 'Ordinary CPython time improves by 1.03%, with 22 of 24 conditions faster. PGO CPython time is effectively flat (0.17% faster).')
readme = readme.replace('The proposed runtime change', 'The selected runtime change')
readme = readme.replace('Candidate: `0f66d54ac8418f0a6e628ad18570677a19c9ed45`.', 'Measured candidate: `0f66d54ac8418f0a6e628ad18570677a19c9ed45`; source-equivalent restack: `8b00d4cbb3f540647e1d7d795d0a04df00ed92f4`. All 72 measured source hashes remain exact after restacking onto the preceding documentation layer.')
readme = readme.replace('| Ordinary | All / ElementTree / pyexpat | Pending final audit | Pending final audit | Pending |', '| Ordinary | All | 0.989673× | 1.264743× | 2 / 24 |\n| Ordinary | ElementTree | 0.988155× | 1.347298× | 1 / 12 |\n| Ordinary | pyexpat | 0.991194× | 1.187246× | 1 / 12 |')
readme = readme.replace('The final packet will retain all 56 native and 48 Python condition rows, including every regression.', 'The packet retains all 56 native and 48 Python condition rows, including every regression. The two ordinary Python regressions are Maven at 4 KiB in pyexpat and Batik at 64 KiB in ElementTree.')
readme = readme.replace('## Change and validation', 'Selection accepts the disclosed ordinary native cost because this small change reuses an existing frame, improves the other measured aggregates or leaves them effectively flat, and preserves the measured compatibility and allocation behavior. This is a judgment about the complete tradeoff, not a predeclared numerical acceptance rule.\n\n## Change and validation')
readme = readme.replace('**Packaging pending:** the final archive will retain', 'The archive retains')
readme = readme.replace('It will preserve', 'It preserves')
readme = readme.replace('The bundle will contain saved records and an index, with no compiled libraries, executables or binary profiles and no new verification framework. Absolute paths in original receipts describe the original machine. Selection and the final complete worker/sample counts remain pending the ordinary Python result and root release.', 'The completed bundle contains 2,496 worker records and 265,080 samples: 1,344 native workers / 212,352 samples and 1,152 Python workers / 52,728 samples. These totals include preflights and warmups. All 104 condition rows appear in the two condition CSVs. `allocations.csv` contains the fixed allocation comparisons.\n\n`evidence.tar.gz` contains saved records; `index.json` identifies every member by original path, size and SHA-256. Compiled libraries, executables and binary profiles are excluded. The original audits checked library bytes and recorded their identities; archive readback verifies the saved evidence, not an absent binary. Original absolute paths describe the measuring machine, and archived controllers/readers remain historical records rather than a newly portable verification framework.\n\nThe compatibility review note preserves the corrected ElementTree linkage assumption; the initial failed ad-hoc tool output remains in the conversation and is not a separate archive member. `_elementtree` obtains Expat through pyexpat’s `expat_CAPI` capsule. Generic C consumers retain compile/ELF binding evidence rather than an added in-process `dladdr` probe. No parser, compiler or benchmark target was executed while packaging.')
assert 'Pending' not in readme and 'Draft:' not in readme
(O / 'README.md').write_text(readme)

# One complete archive readback validates packaging only.
with tarfile.open(O / 'evidence.tar.gz', 'r:gz') as archive:
    stored = archive.getmembers()
    assert len(stored) == len(members) and len({entry.name for entry in stored}) == len(stored)
    for entry in stored:
        assert entry.isfile() and not entry.name.startswith('/') and '..' not in Path(entry.name).parts
        assert archive.extractfile(entry).read() == files[entry.name]
assert set(path.name for path in O.iterdir()) == {'README.md', 'report.json', 'conditions.csv', 'python-conditions.csv', 'allocations.csv', 'evidence.tar.gz', 'index.json'}
print(json.dumps({'status': 'assembled_and_read_back', 'output': str(O), 'members': len(members), 'archive_bytes': (O / 'evidence.tar.gz').stat().st_size, 'sha256': {path.name: sha(path.read_bytes()) for path in sorted(O.iterdir())}, 'decision': report['decision'], 'totals': report['totals'], 'targets_executed': False}, indent=2))
