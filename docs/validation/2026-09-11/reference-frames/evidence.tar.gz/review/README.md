# Scalar-reference adapter frame source review

Verdict: no actionable source defect found. Read-only source and saved-check review; no compiler, parser, test, or benchmark target was executed by this reviewer.

Reviewed worktree: `/home/dev-user/code/oss/oriole-reference-frame`, commit `0f66d54ac8418f0a6e628ad18570677a19c9ed45`, with the exact two-file diff from `b9fb212e6e915a43896a1589107718579762b7c3` retained as `reviewed.patch`. All 61 Rust source hashes match every before/after source map and the final source map in `/tmp/oriole-reference-frame-checks/summary.json`. That completed root-owned summary reports 440 tests across 34 groups plus successful fmt/check/Clippy. This is source binding to those saved receipts, not an independent test rerun.

## Behavior and ownership

- `crates/oriole/src/lib.rs:2611` passes EventOutput into parse_reference. Only a successfully decoded predefined/numeric scalar takes the new frame branch. Source scanning, validation, original raw capture, direct/indirect accounting and consume all retain their order before publication. Numeric references still add no predefined replacement-byte charge; predefined named references still add one. General, external, skipped and disabled-internal-expansion paths retain the original event flow.
- `crates/oriole/src/arena.rs:93` copies each 1–4-byte scalar into detached inline storage (capacity 23). This cannot retain a temporary UTF-8 buffer reference, allocate payload storage, or claim the decoded bytes are an original-input range. No parser-size, retained-heap ceiling, allocator ownership, unsafe-code or callback reentry contract changes are introduced.
- `crates/oriole/src/lib.rs:1972` returns when the published frame is observed before further source parsing. The frame position equals the former event position and current raw remains the original reference spelling. Ordinary Rust and foreign-generation fallback calls retain their owned event behavior. Reference callback boundaries do not coalesce.
- `crates/oriole_expat/src/lib.rs:1237` and generic Text dispatch at lines 644/800 both charge decoded length and invoke the same text handler and argument. An absent text handler follows `dispatch_unhandled(parser, false, None)` in both cases. Text needs no base metadata. The C event loop publishes the same position and checks suspension, abortion, destruction and parse errors before the next delivery. DefaultCurrent still observes the unchanged raw reference.
- `emit` only queues a PendingEvent and performs no hidden resource charge. Avoiding its queue operation changes a possible allocation/failure schedule; it does not weaken a semantic work limit. Custom-allocator/API checks still need to assess actual observable outcomes on the built candidate. No claim that allocator call schedules must remain identical is made.

## Coverage assessment

`crates/oriole/tests/adapter_frame.rs:442` compares complete owned/adapted events, positions, raw spellings and errors across every input chunk width, UTF-8 and UTF-16LE, four token limits, all predefined references, decimal/hex Unicode scalars, internal entity replacement text, malformed references, illegal scalars, incomplete input and illegal following text. The ownership/accounting test at line 479 verifies a 4-byte detached scalar after parser drop, no native range, exact byte charging metadata and no publication on shared entity-accounting failure.

The new accounting failure occurs at source accounting; it does not by itself isolate failure of the later one-byte predefined-reference charge. That ordering is unchanged and the existing amplification tests cover predefined/numeric differences. This is not a blocking coverage gap for this diff. Existing C tests `arena_text_enforces_exact_callback_budget_with_default_fallback`, `arena_text_keeps_bytes_raw_context_and_handlers_live_through_suspension`, and context-text fallback tests already exercise the reused dispatch protocol. No additional mirrored test is requested.

## Performance scope

Text already stores scalars inline (`crates/oriole_storage/src/string.rs:250`), so this targets PendingEvent/owned Event construction, queue push/pop and generic dispatch overhead, not one heap allocation per scalar. The historical generated-entities corpus contains predefined/numeric references without a DTD; shared immutable DTD replacement storage would not address that workload. No speedup or fresh native/C API result is claimed in this source review.

## Reviewed source hashes

- `crates/oriole/src/lib.rs`: `246e281e1fcdc2c181714e78e8da05dbee4bd66f59ef95b2bc59449e4c3a43d4`
- `crates/oriole/tests/adapter_frame.rs`: `a5e38074c872c21bbb963c83f7976652d83968c5bb20ca350aaa78dceaab0c8e`
- `reviewed.patch`: `584b80b290e61746834b6985545c4c25b3e668f95dbf0eeedcb84a4bf1e68a54`
- root checks summary: `151a5282b40aaa71a0be5340ec9ff3dd6ec86263a589566acdf273f5b40c1f26`

## Metadata correction

The initial packet raced the root commit: its unqualified git diff was empty after commit, although the source review and all 61 source hashes described the intended two-file change. `initial-README.md` and `initial-reviewed.patch` preserve that first packet (empty patch SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`). The refreshed patch names both revisions explicitly; the reviewed source hashes and completed-check binding remain unchanged. No target was rerun.
