# Reference-frame compatibility and allocation review

**No new finding or observed regression.** Independent saved-only review; no compiler, parser, test, profiler or timing target was executed. The reviewed candidate is commit `0f66d54ac8418f0a6e628ad18570677a19c9ed45`, with the previously checked 72-file source/build map. These gates use its PGO shared library `d3c43850247b83aa3089b7f08deb31a084ee2aecb47b52d27e9d05e97b0e1bd4` and static archive `04913727cd94b1d0db93c05980048e638d143cad66a48872cc0d318f716d89aa`.

## Original API and C consumers

- Reconstructed all 4,740 begin/result pairs directly from the API raw log; each unique test/context outcome exactly matches the selected suffix. Counts remain **4,347 pass, 391 assertion failures, two per-case timeouts**. The latter are both chunk-zero `test_misc_input_2gb` cases. The suite exits 1; matching outcomes is not a fully passing API suite.
- Adapted test/include/bridge source hashes and the full manifest match the suffix baseline except library/binary/output paths. The original 12 contexts, existing private-internal exclusions, assertions, 3-second per-case bound, 1 GiB address-space bound, 768 MiB RSS bound and 240-second aggregate bound remain unchanged.
- All six C consumers pass: integration, adversarial lifecycle and the 327-scenario allocation-failure sweep, each dynamic and static. Their copied sources and header exactly match committed candidate files, including the long-default inherited-value regression. All raw command outputs and binary hashes were rechecked. Read-only ELF inspection confirms candidate dynamic RUNPATH/NEEDED and static XML_Parse definitions, with no system Expat dependency.
- Sanitizer scope is **C ASan/UBSan only**, with the optimized Rust library uninstrumented and leak detection disabled. This is not a fresh Rust sanitizer or fuzz campaign.

Evidence: `/tmp/oriole-reference-frame-api-gates/api-native/{report.json,upstream-api/tests.log,upstream-api/results.json}` and six `native-*.stdout/.stderr` receipts.

## Strict CPython

Both shared and static strict suites exit **2**, exactly as the fresh selected suffix baseline. Each reports **802 tests, two failures, 14 skips**, with three expected failures. All **809 rendered outcome lines** match the corresponding baseline, including the expected-failure lines; this line count is not a distinct test count. The remaining failures are `test_pyexpat.BufferTextTest.test1` and `test_sax.CDATAHandlerTest.test_handlers`.

The explicit `--consumer-fix` backports only the pinned CPython pyexpat allocation-failure cleanup fix, upstream commit `e6b9a1406980fbb1d4032eca9cc0b4f8f252b716`, patch SHA256 `10999b7171ce016e249c47c7f12d562f05a28aadf17791d61664090928f736a2`. Patched `pyexpat.c` bytes, CPython revision and exact test command equal the fresh suffix baseline. There is no text-fragmentation allowance or upstream test modification. The performance extensions remain outside this strict-consumer backport scope.

Initial and fresh-import origin records resolve both pyexpat and _elementtree to the intended generated extensions, including pure-Python/blocked-import checks. ELF inspection confirms pyexpat's exact shared library dependency or static XML_Parse definition. _elementtree has no direct XML_Parse or Expat dependency: the inspected CPython source loads pyexpat's `expat_CAPI` capsule at `Modules/_elementtree.c:4384`. All 101 strict source/tool/library pins and raw summary/log hashes remain exact.

Evidence: `/tmp/oriole-reference-frame-strict-cpython/{report.json,shared/summary.json,shared/tests.log,shared/origin.log,static/summary.json,static/tests.log,static/origin.log}`.

## Allocation and between-feed retention

All **12 paired fixtures** have byte-identical raw traces after replacing only the exact selected/candidate library path in the ten API-origin records. This includes every allocation-size histogram, phase count/requested bytes, callback count/hash, peak/retained bytes and blocks, final zero-live-allocation result, and **all 74 CALL rows per engine (148 combined)**. No intermediate feed has increased retained bytes or blocks. Histogram counts and requested-byte sums independently reproduce all four phase summaries; feed progression, successful final state, balanced start/end callbacks and zero final live storage are verified.

Maven remains 188 mallocs/119 reallocs without namespaces and 380/204 with namespaces. All copied fixture bytes, probe source, original bounds, selected/candidate library bindings and saved result pins remain exact. All ten API origins per fixture point at the copied candidate PGO library. These are allocator-requested memory counts, not process RSS, and do not establish identical allocation schedules on inputs outside these twelve fixtures.

Evidence: `/tmp/oriole-reference-frame-allocation-probe/{plan.json,comparison.json,comparison.csv,runs/*.json,runs/*.log}`.

## Readiness and review scope

These results preserve the prior experimental compatibility level and add no reason to reject this small change on correctness or selected allocation evidence. They do not resolve existing API failures, make strict CPython green, establish broad resource behavior, or replace the pending CPython elapsed decision. Native performance remains a separate mixed ordinary/PGO tradeoff.

The first ad-hoc strict ELF read incorrectly required a direct Expat dependency from _elementtree and stopped at that reviewer-only assertion. Inspection confirmed the existing pyexpat capsule linkage; the corrected saved-only check passed. Original tool output preserves the failed attempt. No producer result, source, test assertion, target or library was changed or rerun.

## Result-file hashes

- `/tmp/oriole-reference-frame-api-gates/api-native/report.json`: `d57c771a6783e13ff54fee7bfc94aa3a2c31f71371f766cb0e005280ea8286b8`
- `/tmp/oriole-reference-frame-strict-cpython/report.json`: `c357c4a9ca5ea5ba5043ee851175d34cf22800063590abb6f2fa2ff5441fb95a`
- `/tmp/oriole-reference-frame-allocation-probe/comparison.json`: `084b539d708d481f82b8f7ac41861133f9f58e6a1981de539d15889239c9f05e`
