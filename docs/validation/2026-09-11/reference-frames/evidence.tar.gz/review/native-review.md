# Independent native result review

The completed native campaigns support continuing to API and CPython gates. They do not yet support an unconditional adoption or readiness claim. Read-only review only; no compiler, parser, preflight, profiler or timing target executed by this reviewer.

| Build | Real candidate/control | Faster real conditions | Real candidate/Expat | Generated candidate/control |
| --- | ---: | ---: | ---: | ---: |
| Ordinary O3 ThinLTO | 1.007887 | 6/24 | 1.594148 | 0.838334 |
| Fresh generated-only PGO | 0.979686 | 22/24 | 1.326116 | 0.773533 |

Ratios above one mean slower. All 28 conditions per mode are retained, including 18 ordinary real regressions and both ordinary rare-declaration regressions. The largest ordinary regression is Wayland 64 KiB with namespaces, +3.3200%; both PGO real regressions are Wayland 4 KiB, approximately +0.21–0.22%. PGO beats Expat in seven real conditions; ordinary beats it in none. The generated reference fixture itself improves 30.75–31.43% ordinary and 39.43–39.63% PGO, while remaining roughly 3.26–3.58 times Expat. Generated controls do not establish a real-project gain.

## Independent saved-data checks

Directly read all 1,344 raw worker files and 212,352 samples across the two modes, including every predefined warmup and all preflights. Reconstructed the exact seeded condition/engine order, complete command vectors, every measured process median, each seven-pair condition median and all group geometric means. Every result agrees exactly with the retained native results and independent auditor reports/CSVs. Normalized output hashes, element counts and text-byte counts agree across every sample/engine for each condition; this is not a proof of identical callback segmentation or positions.

Both complete 72-file source maps match current source and build readback. Relative to selected suffix a0acaf1, the candidate has exactly the reviewed scalar-reference runtime file, adapter tests, and inherited long-default C integration test. Source is committed 0f66d54ac8418f0a6e628ad18570677a19c9ed45; the long-default fixture is not performance-driver code. Actual nine candidate and nine control compiler vectors are present in their raw logs, match their saved argv, and use the expected O3/ThinLTO/codegen-unit recipe. All 864 generated replay rows per engine are identical between normal, generate and use phases, and between candidate and control. The reviewed build-binding helper additionally compares compiler vectors after only private build/run paths and artifact suffix normalization, and binds source, six library artifacts, tools, training and fresh profiles. Every consumed original build/native input hash was checked unchanged.

Candidate ordinary library SHA256: `087d131c215012d2a93527a4ec66a716216e8ab4009948a1f79d0a7644d5d949`.
Candidate PGO library SHA256: `d3c43850247b83aa3089b7f08deb31a084ee2aecb47b52d27e9d05e97b0e1bd4`.
Raw results: `/tmp/oriole-reference-frame-native-study/{normal,pgo}/native-screen/`.
Full condition CSVs: `/tmp/oriole-reference-frame-native-independent-review/{normal,pgo}-conditions.csv`.
Build binding: `/tmp/oriole-reference-frame-pgo-study/build-readback.json`.
Auditor report hashes: normal `20f3aef25933123f971cf510007975419e678d52c44ed86bc2887592920e8457`; PGO `d018d7a5c93d2d4d544a8c1d1a7c99ffbf2c9563762fe36c23eb23b31d677021`.

## Adoption tradeoff and unsupported claims

My provisional recommendation is to continue validation, with conditional acceptance reasonable if API outcomes do not regress and CPython measurements preserve a useful balance. The tiny runtime change, unchanged callback boundary and substantial reference-workload improvement are better grounds for tolerating a disclosed +0.79% ordinary native aggregate than a large new mode/layout/cache would be. This is a judgement about a tradeoff, not an existing predeclared numeric acceptance threshold. A material additional CPython or compatibility regression would change that recommendation.

Do not claim faster real projects generally: the ordinary aggregate regresses and 18/24 ordinary conditions are adverse. Do not hide that cost behind the PGO result or average ordinary and PGO campaigns. Do not describe the remaining 1.3261 PGO ratio as within 10% of Expat; reaching 1.10 requires about another 17.05% reduction in current candidate native time. The native benchmark includes parser lifecycle and callback hashing, not whole-application performance. No cycle/cache/compiler mechanism is established. The unchanged legacy native worker uses explicit library paths and before/after hashes; it does not add same-process XML_Parse dladdr checks. Separate training origins are verified. Full API, strict CPython, CPython elapsed, allocation and distribution evidence remain outside this native review.
