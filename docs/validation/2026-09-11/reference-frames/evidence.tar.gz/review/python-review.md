# Independent CPython and selection review

No actionable finding. Saved-only review on CPU 6, after both original elapsed campaigns and their auditors completed and were reaped. No parser, compiler, test, elapsed worker, or built extension was run/imported by this reviewer.

## Raw results

Independently reconstructed all 1,152 workers and 52,728 samples (51,576 measured, 1,152 warmups), seeded order, exact worker specifications/commands, same-pair process medians, all 48 condition rows, and group geometric means. Every sample has the expected complete canonical output; all reported extension identities and same-process `XML_Parse` dladdr origins match the frozen libraries. Rehashed 3,805 distinct original evidence pins without a change. Raw samples include parsing and explicit result destruction; canonical validation and explicit GC collection are outside timing, automatic GC remains enabled.

| Campaign | Candidate / selected control | Candidate / Expat | Conditions faster than control |
| --- | ---: | ---: | ---: |
| Ordinary, all CPython | 0.9896730004 | 1.2647428915 | 22 / 24 |
| Ordinary, ElementTree | 0.9881545708 | 1.3472978875 | 11 / 12 |
| Ordinary, pyexpat | 0.9911937633 | 1.1872464111 | 11 / 12 |
| PGO, all CPython | 0.9982701583 | 1.1179371192 | 14 / 24 |
| PGO, ElementTree | 0.9948518653 | 1.1622777809 | 9 / 12 |
| PGO, pyexpat | 1.0017001965 | 1.0752880448 | 5 / 12 |

The ordinary campaign improved 1.03%; both adverse conditions remain in the results (Maven 4 KiB pyexpat +0.236%, Batik 64 KiB ElementTree +0.261%). PGO CPython is effectively flat, with ten adverse conditions and a largest adverse median of Maven 4 KiB pyexpat +1.342%. The older published 1.128 versus the current 1.118 Expat ratio is not a controlled 1% gain: this campaign's selected control was 1.1203772382 versus Expat. No significance or whole-project execution claim is supported by these shared-host XML-consumer measurements.

## Source and library binding

The tested candidate remains `0f66d54ac8418f0a6e628ad18570677a19c9ed45`, selected runtime control `a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9`. The only runtime source delta is `crates/oriole/src/lib.rs`; the adapter test and inherited long-default C test are the other two source-manifest differences. The unchanged allocator and public header remain bound by the saved build/readback and source records.

Verified all twelve exact extension compile vectors across both modes against the original commands (`cc -shared -fPIC -O2`, identical include sets), matching committed header and unmodified CPython 3.12.13 sources. `adaptations` is null; the strict-test cleanup backport is absent from these performance extensions. Candidate ordinary SO SHA-256 `087d131c215012d2a93527a4ec66a716216e8ab4009948a1f79d0a7644d5d949`; candidate PGO SO `d3c43850247b83aa3089b7f08deb31a084ee2aecb47b52d27e9d05e97b0e1bd4`. Both match `/tmp/oriole-reference-frame-pgo-study/build-readback.json` (SHA-256 `76e926154cb74f77f4a642921d73d44f0b54e692b5a26209f721e299f53774bc`).

Read-only ELF inspection agrees with the raw process origins: Oriole pyexpat extensions directly need their frozen absolute SO paths; the Expat references need `libexpat.so.1`, whose local symlink resolves to the frozen, hash-matched Expat file in the extension RUNPATH. `_elementtree` consumes pyexpat's `expat_CAPI` capsule and has no direct XML_Parse dependency. Initial reviewer-only ELF checks first assumed an unresolved upstream cache path, then assumed an absolute Oriole-style NEEDED name for the Expat reference. Those checks stopped before completion; resolving the path and checking Expat's SONAME/local symlink corrected the saved-only checks. Producer records were unchanged, with no target reruns.

## Selection and readiness

Accepting this small protocol-preserving change is reasonable: PGO native improves 2.03%, ordinary CPython improves 1.03%, and generated reference-heavy input improves about 31% ordinary / 40% PGO. State the ordinary native regression (+0.79%, 18/24 adverse) and effectively flat PGO CPython alongside those gains. The change preserves all measured API outcomes, strict outcomes, and allocation traces; those checks establish no new observed regression, not full compatibility.

The 10% overall speed goal remains unmet: PGO native is 32.61% behind Expat and combined PGO CPython is 11.79% behind (ElementTree 16.23%, pyexpat 7.53%). Production readiness remains experimental: the upstream API campaign still has 391 failures and two bounded timeouts, and both strict CPython linkages retain two callback-grouping failures. Existing C parser-family serialization and resource contracts continue to apply.

## Original evidence

- `/tmp/oriole-reference-frame-python-study/{normal,pgo}/screen/results.json`, `preflight.json`, all raw gzipped worker stdout/stderr and worker JSON specifications.
- `/tmp/oriole-reference-frame-python-study/{normal,pgo}/consumers/build.json`, `adaptation.json`, controller records and logs.
- `/tmp/oriole-reference-frame-python-independent-review/normal-review.json`: SHA-256 `1dd4850527864b4bc0d4e087c7f009df6842bb26f7e061e6d4695ae14d543284`.
- `/tmp/oriole-reference-frame-python-independent-review/pgo-review.json`: SHA-256 `8fac8df055a70e518030016ccea551966a9e8dc60f2269562974eb7fb16192d0`.
- All 24 rows per mode: normal-conditions.csv SHA-256 `b60a14d2768e21f3100f218558af40a8a44086df60d015bf4a6abd84f55e1938`; pgo-conditions.csv SHA-256 `b5d52436d614f8b34cea357c72da520e6fd0ca3ee5e55633eacf779b9441c114` in the same independent-review directory.
- Source, native, and compatibility reviews alongside this file retain their original bounds and corrections.
