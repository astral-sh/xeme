"""Package the released PBS bundle checks using the existing saved-record format."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import os
import sys
import tarfile

cli = argparse.ArgumentParser(description=__doc__)
cli.add_argument('--released', action='store_true', required=True)
cli.parse_args()
assert os.sched_getaffinity(0) == {6}
ROOT = Path('/home/dev-user/code/oss/oriole-v3-trial')
BUILD = Path('/tmp/oriole-pbs-v3-bundle-checks')
CHECKS = Path('/tmp/oriole-pbs-v3-integration-checks')
OUT = Path('/tmp/oriole-pbs-v3-bundle-evidence')
assert not OUT.exists()
sys.path.insert(0, str(ROOT / 'integration/python-build-standalone'))
import pbs_target
import pgo_bundle

sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
read = lambda path: json.loads(Path(path).read_text())
entries, originals, excluded = {}, {}, {}

def exclude(path, expected):
    path = Path(path)
    assert sha(path) == expected, path
    excluded[str(path)] = {'path': str(path), 'size': path.stat().st_size,
                           'sha256': expected,
                           'reason': 'Library, compiler, profile or machine Cargo configuration; original identity retained.'}

def add(path, member):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert member not in entries, member
    data = path.read_bytes()
    assert not data.startswith((b'\x7fELF', b'!<arch>\n')), path
    assert path.suffix not in {'.pyc', '.profraw', '.profdata', '.a', '.so'}, path
    entries[member], originals[member] = data, str(path)

sources = {}
def add_sources(mapping, base):
    for name, digest in mapping.items():
        path = Path(name) if Path(name).is_absolute() else base / name
        assert sha(path) == digest, path
        relative = str(path.relative_to(ROOT))
        if relative in sources:
            assert sources[relative] == digest
        else:
            sources[relative] = digest
            add(path, 'source/' + relative)

frozen = read(CHECKS / 'summary.json')
assert frozen['status'] == 'passed_source_frozen' and frozen['tests'] == 12
add_sources(frozen['owned_files_sha256'], ROOT)
for name in frozen['saved_logs_sha256']:
    assert sha(CHECKS / name) == frozen['saved_logs_sha256'][name], name
for path in sorted(CHECKS.iterdir()):
    if path.is_file():
        add(path, 'focused-checks/' + path.name)
for path in sorted(BUILD.iterdir()):
    if path.is_file():
        add(path, 'build/' + path.name)

rows = []
bundle_sources = None
for mode in ('normal-generic', 'normal-v3', 'pgo-v3'):
    bundle = BUILD / mode
    controller_name = 'normal-generic-attempt02' if mode == 'normal-generic' else mode
    controller = read(BUILD / (controller_name + '-controller.json'))
    assert controller['status'] == 'passed' and controller['exit'] == 0
    assert sha(BUILD / (controller_name + '-controller.log')) == controller['log_sha256']
    assert sha(BUILD / 'run.py') == controller['controller_sha256']
    manifest = read(bundle / 'manifest.json')
    target = 'x86_64-unknown-linux-gnu' if mode == 'normal-generic' else 'x86_64_v3-unknown-linux-gnu'
    cpu = pbs_target.cpu(target)
    pbs_target.validate(manifest, target)
    assert manifest['rustflags'] == ' '.join(pgo_bundle.flags(cpu))
    assert manifest['pbs_revision'] == 'a4553880293fe9d1bb62747d34ab0e5121d3554f'
    if bundle_sources is None:
        bundle_sources = manifest['sources']
    assert manifest['sources'] == bundle_sources
    add_sources(manifest['sources'], ROOT)
    for name, digest in manifest['files'].items():
        assert sha(bundle / name) == digest, (mode, name)
    for path in sorted(bundle.iterdir()):
        if path.is_file():
            if path.name == 'libexpat.a':
                exclude(path, manifest['files'][path.name])
            else:
                add(path, 'build/' + mode + '/' + path.name)
    for path, digest in manifest['cargo_config_sha256'].items():
        exclude(path, digest)
    phase_rows = {}
    if mode == 'pgo-v3':
        env = dict(os.environ) | controller['environment_overrides']
        archive, libraries, pgo, command = pgo_bundle.verify(
            bundle / 'pgo', ROOT, env, 'ohm', ['-Zohm-defaults=no'], cpu)
        assert pgo == manifest['pgo']
        assert command == manifest['command']
        assert pgo['compiler_vectors'] == manifest['compiler_vectors']
        assert (bundle / 'native-static-libs.txt').read_text().split() == libraries
        run = Path(pgo['manifest']['run'])
        add(bundle / 'pgo/latest.json', 'build/pgo-v3/pgo/latest.json')
        for path in sorted(run.iterdir()):
            if path.is_file() and path.suffix in {'.json', '.log'}:
                add(path, 'build/pgo-v3/pgo/' + path.name)
        for path in sorted((run / 'inputs').rglob('*')):
            if path.is_file():
                add(path, 'build/pgo-v3/pgo/inputs/' + str(path.relative_to(run / 'inputs')))
        add_sources(pgo['manifest']['source_sha256'], ROOT)
        add_sources(pgo['manifest']['script_sha256'], ROOT / 'tools/pgo')
        for name, digest in pgo['manifest']['profiles_sha256'].items():
            path = run / name if name == 'merged.profdata' else run / 'raw-profiles' / name
            exclude(path, digest)
        for name, digest in pgo['manifest']['libraries_sha256'].items():
            exclude(run / name, digest)
        for name, digest in pgo['manifest']['tools_sha256'].items():
            exclude(Path(name), digest)
        for phase in ('generate', 'use'):
            report = read(run / f'{phase}-training.json')
            assert report['status'] == 'passed' and len(report['rows']) == 288
            phase_rows[phase] = len(report['rows'])
        assert read(run / 'generate-training.json')['rows'] == read(run / 'use-training.json')['rows']
    else:
        compiler = Path(manifest['compiler_vectors']['normal'][0][0]).resolve(strict=True)
        vectors = pgo_bundle.verify_vectors((bundle / 'build.log').read_text(), 'normal', bundle, compiler, cpu)
        assert vectors == manifest['compiler_vectors']['normal']
        exclude(compiler, sha(compiler))
        assert 'pgo' not in manifest
    rows.append({'mode': mode, 'pbs_target': target, 'rust_target': manifest['rust_target'],
                 'target_cpu': cpu, 'manifest_sha256': sha(bundle / 'manifest.json'),
                 'static_archive_sha256': manifest['files']['libexpat.a'],
                 'compiler_vectors': {phase: len(vectors) for phase, vectors in manifest['compiler_vectors'].items()},
                 'training_observations': phase_rows, 'bundle_source_files': len(manifest['sources']),
                 'host_check': manifest['host_check'], 'status': 'passed'})
assert read(BUILD / 'normal-generic-controller.json')['status'] == 'failed'
assert 'ModuleNotFoundError' in (BUILD / 'normal-generic-controller.log').read_text()
add(__file__, 'controllers/assemble.py')
for name in ('LICENSE-MIT', 'LICENSE-APACHE', 'THIRD_PARTY_LICENSES.md', 'licenses/cpython.txt'):
    if 'source/' + name not in entries:
        add(ROOT / name, 'source/' + name)

report = {'status': 'passed_saved_bundle_readback', 'scope': 'Local Ohm builds with defaults disabled and saved-only verification; no distribution build or elapsed measurement.',
          'bundles': rows, 'source_files_in_each_bundle': len(bundle_sources),
          'focused_tests': 12, 'compiler_vectors': sum(sum(r['compiler_vectors'].values()) for r in rows),
          'training_observations': sum(sum(r['training_observations'].values()) for r in rows),
          'historical_failures': ['Initial root normal-generic invocation failed on sibling import before any compiler execution; corrected invocation clears PYTHONSAFEPATH.',
                                  'Focused overlay invocation had the same import setup issue; Ruff/ty tool-directory setup and initial import-order findings are preserved.'],
          'limitations': ['These local bundle builds use Ohm with automatic experimental defaults disabled. Production CI uses plain stable Cargo.',
                          'The explicit v3 PBS distribution, installed archive checks, complete XML tests and glibc 2.17 gate have not been run for this integration change.',
                          'Training observations are generated correctness/training cases, not a real-project benchmark.',
                          'The prior strict CPython callback failures and API ceilings remain; this is not a complete compatibility or production-readiness claim.'],
          'excluded': list(excluded.values())}
OUT.mkdir()
members = []
with (OUT / 'evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for member, data in sorted(entries.items()):
                info = tarfile.TarInfo(member)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                archive.addfile(info, io.BytesIO(data))
                members.append({'member': member, 'original_path': originals[member], 'size': len(data),
                                'sha256': hashlib.sha256(data).hexdigest()})
with tarfile.open(OUT / 'evidence.tar.gz', 'r:gz') as archive:
    actual = archive.getmembers()
    assert [member.name for member in actual] == [member['member'] for member in members]
    for record, member in zip(members, actual, strict=True):
        assert member.isfile() and member.size == record['size']
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == record['sha256']
index = {'schema': 'saved-record-bundle-v1', 'archive': 'evidence.tar.gz', 'archive_sha256': sha(OUT / 'evidence.tar.gz'),
         'archive_bytes': (OUT / 'evidence.tar.gz').stat().st_size, 'archive_readback_passed': True,
         'members': members, 'excluded': list(excluded.values())}
(OUT / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
(OUT / 'README.md').write_text('''# Explicit PBS target bundle validation

The normal generic, normal x86-64-v3 and PGO x86-64-v3 local bundles passed. The
generic target remains the default. The v3 product uses the generic Rust ABI
target with an explicit `target-cpu=x86-64-v3` requirement.

The saved build logs reproduce all 12 workspace compiler vectors: three per
normal bundle and three in each PGO phase. They retain O3, ThinLTO, one codegen
unit, PIC and unwind behavior, with no hidden CPU or experimental rustc options.
The PGO bundle retains both sets of 288 generated training observations and the
exact selected static archive identity. These observations are not benchmarks.

The packet includes 12 focused Python tests, pinned-overlay fixtures, Ruff, ty,
workflow checks and the generic-ISA GCC CPU/OS guard. It preserves failed setup
attempts, including the initial sibling-import error before compilation.

These are local `cargo +ohm -Zohm-defaults=no` builds. Production CI uses plain
stable Cargo. The new explicit v3 PBS distribution and installed target/manifest/
archive checks remain pending, along with its complete XML and glibc 2.17 gates.
Existing API ceiling differences and strict callback failures remain; this
packet makes no new performance or production-readiness claim.

[Report](report.json) lists each bundle and its limitations. The
[index](index.json) binds every member of [the saved records](evidence.tar.gz)
to its original byte count and SHA-256; all members were read back after packing.
`original_path` is the historical machine location. Archive member paths are
relative. Libraries, compilers, profile blobs and machine Cargo configuration
are excluded with their byte identities retained. The saved assembler reuses
the repository's bundle verifier and the existing deterministic packet method;
it does not execute targets.
''')
print(json.dumps({'status': report['status'], 'members': len(members), 'archive_bytes': index['archive_bytes'],
                  'archive_sha256': index['archive_sha256'], 'report_sha256': sha(OUT / 'report.json'),
                  'index_sha256': sha(OUT / 'index.json'), 'compiler_vectors': report['compiler_vectors'],
                  'training_observations': report['training_observations']}, indent=2))
