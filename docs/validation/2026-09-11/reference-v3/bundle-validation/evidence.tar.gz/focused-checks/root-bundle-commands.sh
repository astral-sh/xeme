#!/usr/bin/env bash
# Prepared commands only; root owns execution. Run sequentially from this worktree.
set -euo pipefail
cd /home/dev-user/code/oss/oriole-v3-trial
oriole_python=/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12
oriole_shared_build='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}'

env -u PYTHONSAFEPATH \
  CARGO_TARGET_DIR=/home/dev-user/.cache/oriole/targets/pbs-v3-trial-normal-generic \
  CARGO_BUILD_BUILD_DIR="$oriole_shared_build" CARGO_BUILD_JOBS=1 \
  taskset -c 3 "$oriole_python" -B integration/python-build-standalone/prepare.py \
  --toolchain ohm --cargo-arg=-Zohm-defaults=no \
  --output /tmp/oriole-pbs-v3-integration-builds/normal-generic

env -u PYTHONSAFEPATH \
  CARGO_TARGET_DIR=/home/dev-user/.cache/oriole/targets/pbs-v3-trial-normal-v3 \
  CARGO_BUILD_BUILD_DIR="$oriole_shared_build" CARGO_BUILD_JOBS=1 \
  taskset -c 3 "$oriole_python" -B integration/python-build-standalone/prepare.py \
  --toolchain ohm --cargo-arg=-Zohm-defaults=no \
  --pbs-target x86_64_v3-unknown-linux-gnu \
  --output /tmp/oriole-pbs-v3-integration-builds/normal-v3

env -u PYTHONSAFEPATH \
  CARGO_TARGET_DIR=/home/dev-user/.cache/oriole/targets/pbs-v3-trial-pgo-v3 \
  CARGO_BUILD_BUILD_DIR="$oriole_shared_build" CARGO_BUILD_JOBS=1 \
  taskset -c 3 "$oriole_python" -B integration/python-build-standalone/prepare.py \
  --toolchain ohm --cargo-arg=-Zohm-defaults=no \
  --pbs-target x86_64_v3-unknown-linux-gnu \
  --pgo --llvm-profdata /tmp/oriole-pgo-study/llvm-tools-1.98.0/bin/llvm-profdata \
  --output /tmp/oriole-pbs-v3-integration-builds/pgo-v3
