"""Package released current-source v3 evidence with the existing deterministic packet method."""
from pathlib import Path
import argparse,csv,gzip,hashlib,io,json,os,tarfile
cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('--released',action='store_true',required=True);cli.parse_args()
assert os.sched_getaffinity(0)=={6}
OUT=Path('/tmp/oriole-reference-frame-v3-evidence');assert not OUT.exists()
BUILD=Path('/tmp/oriole-reference-frame-v3-pgo-study');CONTROL=Path('/tmp/oriole-reference-frame-pgo-study')
NATIVE=Path('/tmp/oriole-reference-frame-v3-native-review');PYTHON=Path('/tmp/oriole-reference-frame-v3-consumer-preparation/python');PYREV=Path('/tmp/oriole-reference-frame-v3-python-review')
CORRECT=Path('/tmp/oriole-reference-frame-v3-correctness-prep');DOCS=Path('/home/dev-user/code/oss/oriole-v3-trial/docs/validation/2026-09-11/reference-v3')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text())
source=read(BUILD/'source.json');assert source['source_sha256']==read(CONTROL/'source.json')['source_sha256'] and len(source['source_sha256'])==72
native={m:read(NATIVE/(m+'.json')) for m in ['normal','pgo']}
python={m:read(PYREV/(m+'-review.json')) for m in ['normal','pgo']}
assert all(r['status']=='passed_saved_native_audit' and r['all_workers']==896 for r in native.values())
assert all(r['status']=='passed_independent_raw_elapsed_reconstruction' and r['counts']['all_workers']==576 for r in python.values())
assert all(read(PYTHON/m/'time-controller.json')['status']=='passed' for m in python)
correct=read(CORRECT/'outcome-readback.json');assert correct['status']=='saved_results_verified' and correct['api_changes']==[]
assert all(r['changes']==[] and r['methods']==802 and r['raw_exit']==2 for r in correct['strict'].values())
rust=read('/tmp/oriole-reference-frame-v3-build-review/rust.json');assert rust['status']=='passed'
expat=read('/tmp/oriole-reference-frame-v3-expat-reuse-review/report.json')
entries, originals, excluded = {}, {}, []

def add(path, member):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert member not in entries, member
    data = path.read_bytes()
    assert not data.startswith((b'\x7fELF', b'!<arch>\n')), path
    assert path.suffix not in {'.pyc', '.profraw', '.profdata', '.a', '.so'}, path
    entries[member], originals[member] = data, str(path)

def tree(root, prefix):
    assert Path(root).is_dir(), root
    for path in sorted(Path(root).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add(path, prefix + '/' + str(path.relative_to(root)))

# Source is byte-identical, so retain one exact snapshot and both manifests.
W=Path(source['worktree'])
for name,digest in source['source_sha256'].items():
    assert sha(BUILD/'source-snapshot'/name)==digest
    add(BUILD/'source-snapshot'/name,'source/selected-and-candidate/'+name)
for name in ['LICENSE-APACHE','LICENSE-MIT','THIRD_PARTY_LICENSES.md','licenses/expat.txt','licenses/libxml2.txt','licenses/cpython.txt','tests/c/UPSTREAM-NOTICES.txt']:
    add(W/name,'source/licenses/'+name)
# Completed local adapters and first-attempt failures, source/build proof and raw native/Python records.
for root,prefix in [(NATIVE,'native/reviews'),(PYREV,'python/reviews'),(Path('/tmp/oriole-reference-frame-v3-build-review'),'build/review'),(Path('/tmp/oriole-reference-frame-v3-expat-reuse-review'),'expat/reuse-review')]:
    tree(root,prefix)
for mode in ['normal','pgo']:
    tree(BUILD/('native-'+mode),'native/'+mode)
    for p in sorted((PYTHON/mode).iterdir()):
        if p.is_file():add(p,'python/'+mode+'/'+p.name)
    tree(PYTHON/mode/'screen','python/'+mode+'/screen')
    for p in sorted((PYTHON/mode/'consumers').rglob('*')):
        if p.is_file() and p.suffix in {'.py','.json','.log','.md','.patch'}:add(p,'python/'+mode+'/consumers/'+str(p.relative_to(PYTHON/mode/'consumers')))
for p in sorted(CORRECT.rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts and p.suffix in {'.json','.stdout','.stderr','.log','.py','.md','.patch','.c','.h','.xml','.dtd','.txt'}:
        add(p,'correctness/'+str(p.relative_to(CORRECT)))
for root,prefix in [(BUILD,'build/candidate'),(CONTROL,'build/generic-control')]:
    for p in sorted(root.iterdir()):
        if p.is_file() and p.suffix in {'.json','.log','.py','.patch','.stdout','.stderr','.md','.gz'}:add(p,prefix+'/'+p.name)
    tree(root/'pipeline',prefix+'/pipeline')
    run=Path(read(root/'pair-report.json')['pgo_manifest']['path']).parent
    for p in sorted(run.iterdir()):
        if p.is_file() and p.suffix in {'.json','.log'}:add(p,prefix+'/pgo/'+p.name)
    tree(run/'inputs',prefix+'/pgo/inputs');add(root/'pgo/latest.json',prefix+'/pgo/latest.json')
for name in ['README.md','materialized.json','pins.json','preparation.json','attempt01.json','materialize.py','materialize-before-freeze-output-fix.py']:
    add(PYTHON.parent/name,'python/preparation/'+name)
for p in Path('/tmp/oriole-reference-frame-v3-evidence-inventory').iterdir():
    if p.is_file() and p.name in {'read_python.py','read_normal_python.py','python-interpretation.json','normal-python-interpretation.json','PYTHON.md','render_docs.py'}:add(p,'review/'+p.name)
add('/tmp/oriole-compact-coordinate-evidence-preparation/assemble.py','controllers/origin-assemble.py')
add(__file__,'controllers/assemble.py')
manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json');add(manifest,'inputs/corpus-manifest.json')
for project in read(manifest)['projects']:
    for record in project['files']:
        p=manifest.parent/record['path'];assert sha(p)==record['sha256'];add(p,'inputs/'+record['path'])
# Include all audited non-binary inputs missing from explicit groups. Preserve excluded byte identities.
all_pins={}
def inherit(mapping,base=None):
    for path,digest in mapping.items():
        path=str(Path(base)/path) if base and not Path(path).is_absolute() else path
        assert path not in all_pins or all_pins[path]==digest,path
        all_pins[path]=digest
inherit(rust['verified_file_pins']);inherit(expat['verified_pins']);inherit(correct['input_sha256'])
for r in native.values():inherit(r['raw_files_sha256'])
for r in python.values():inherit(r['evidence_sha256'],PYTHON)
archived_paths=set(originals.values())
for path,digest in sorted(all_pins.items()):
    assert sha(path)==digest,path
    if path in archived_paths:continue
    p=Path(path)
    with p.open('rb') as stream:head=stream.read(8)
    binary=head.startswith((b'\x7fELF',b'!<arch>\n')) or p.suffix in {'.so','.a','.profraw','.profdata','.pyc'} or '.so.' in p.name
    machine=p.name in {'rustup','rustc','cargo','llvm-profdata','python3.12','native-driver'} or (p.name=='config.toml' and ('.cargo' in p.parts or 'cargo' in p.parts))
    if binary or machine:
        excluded.append({'path':path,'sha256':digest,'size':p.stat().st_size,'reason':'external executable/library/profile or machine Cargo configuration; exact receipt identity retained'})
    else:add(p,'other-pinned-inputs/'+str(p).lstrip('/'))
assert sum('/native-screen/worker-' in name for name in entries)==1792
assert sum(name.startswith('python/') and '/screen/' in name and name.endswith('-stdout.gz') for name in entries)==1152
OUT.mkdir()
members = []
with (OUT / 'evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for member, data in sorted(entries.items()):
                info = tarfile.TarInfo(member)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                archive.addfile(info, io.BytesIO(data))
                members.append({'member': member, 'original_path': originals[member], 'size': len(data),
                                'sha256': hashlib.sha256(data).hexdigest()})
archive_path = OUT / 'evidence.tar.gz'
with tarfile.open(archive_path, 'r:gz') as archive:
    actual = archive.getmembers()
    assert [m.name for m in actual] == [m['member'] for m in members]
    for record, member in zip(members, actual, strict=True):
        assert member.isfile() and member.size == record['size']
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == record['sha256']
index={'schema':'saved-record-bundle-v1','scope':'Same-source optional fixed-v3 compiler experiment: exact source/build/training records, historical Expat reuse proof, both native and both unmodified Python campaigns, fresh PGO API/C/strict gates, all raw worker payloads and first attempts. No stable v3 PBS distribution claim.','archive':'evidence.tar.gz','archive_sha256':sha(archive_path),'archive_bytes':archive_path.stat().st_size,'archive_readback_passed':True,'members':members,'excluded':excluded}
(OUT/'index.json').write_text(json.dumps(index,indent=2)+'\n')
receipt={'status':'passed_all_member_readback','members':len(members),'archive_bytes':archive_path.stat().st_size,'archive_sha256':sha(archive_path),'index_sha256':sha(OUT/'index.json'),'native_workers':1792,'python_workers':1152,'targets_executed':False,'scope':'Saved files only. All archive bytes compared with their recorded original SHA256 and sizes. Actual paths identify the original machine; archive members are portable relative paths. Binaries/profiles/machine configuration excluded with identities retained.'}
(OUT/'package-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
