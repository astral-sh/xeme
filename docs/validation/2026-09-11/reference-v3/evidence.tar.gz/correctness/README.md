# Reference-frame x86-64-v3 correctness gates — prepared

**Prepared only; no parser, compiler or test targets have run from this directory.** Root releases each launch after the native campaign and saved audit complete.

The candidate uses the exact 72 measured source files from `0f66d54ac8418f0a6e628ad18570677a19c9ed45`, source-equivalent to publication `4064b0653534aff690c0e0f395a6b3b48da878fc`. The treatment is `-Ctarget-cpu=x86-64-v3`; the selected allocator and original O3/ThinLTO recipe remain. PGO artifacts are from `/tmp/oriole-reference-frame-v3-pgo-study/pgo/runs/run-o12jfqdr/use`:

- Shared library: `3637826b979a392f28bd04e9421b01ed6f86e353b62faed31fc2bded8144faa7`.
- Static archive: `685d151726d447fab5ac29003603fd7597f7f2d123524ae3ca73916d65e48c8e`.

## Root launch commands

Run sequentially after explicit release. Each controller verifies prepared input pins first and preserves failures, stdout/stderr and child cleanup receipts.

Original API matrix and six C consumers:

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-v3-correctness-prep/api_native.py
```

Strict CPython shared, then static:

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-v3-correctness-prep/strict_cpython.py
```

Saved-only outcome reader, after both controllers complete and all child processes are reaped:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-v3-correctness-prep/read_outcomes.py
```

## Preserved protocol and outcomes

- Original 4,740 API configurations: 3 seconds per case, 1 GiB address space, 768 MiB RSS and 240 seconds for the matrix (300-second outer process bound). Original assertions, allocation ceilings, context/chunk order and manifest comparison remain. Selected generic baseline: **4,347 passes, 391 assertion failures and two timeouts**.
- Six C consumers: integration/adversarial/allocations, each dynamically and statically linked. Compile and run bounds remain 120 seconds each. Only C is compiled with ASan/UBSan; the Rust PGO library is uninstrumented, and leak checking is disabled as in the original controls.
- Strict CPython: complete unchanged shared/static execution loop, 1,000 seconds per linkage, 802 method identities plus saved supplementary outcome lines. The explicit pinned upstream pyexpat allocation-failure cleanup backport is applied only to these strict extensions. There is no text-fragmentation allowance or allocator override.
- The strict generic baseline exits 2 in both linkages, with `test.test_pyexpat.BufferTextTest.test1` and `test.test_sax.CDATAHandlerTest.test_handlers` failing. The reader reports all API and method differences and preserves the full method map; a controller completing does not convert those failures into passes.

The controllers are copied from the already prepared current-v3 adapters; only the API output root changes. The strict execution loop is byte-identical to the original selected-reference controller. The full multiline-aware methods reader remains unchanged. `preparation.json`, `pins.json` and the small adapter diffs record the bindings. A first saved-only preparation attempt omitted the methods helper's byte-reader binding; its script, partial copies and error log are preserved. No target ran in that attempt.

The older rejected compact-coordinate gates remain untouched and unexecuted. The separate consumer-preparation directory owns unmodified Python elapsed extensions; no Python performance or sanitizer conclusion is made here. The 440 historical Rust tests in the reused source-check record concern selected generic source validation, not new executable coverage for these ISA artifacts.
