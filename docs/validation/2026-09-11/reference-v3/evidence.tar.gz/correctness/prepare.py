"""Copy reviewed current-v3 correctness controllers; saved inputs only, no targets."""
from pathlib import Path
import ast
import collections
import difflib
import hashlib
import json
import os
import re

assert os.sched_getaffinity(0) == {6}
P = Path(__file__).parent
ORIGIN = Path('/tmp/oriole-reference-frame-v3-consumer-preparation')
BUILD = Path('/tmp/oriole-reference-frame-v3-pgo-study')
CONTROL = Path('/tmp/oriole-reference-frame-pgo-study')
WORK = Path('/home/dev-user/code/oss/oriole-reference-frame')
API = Path('/tmp/oriole-reference-frame-api-gates/api-native/upstream-api')
STRICT = Path('/tmp/oriole-reference-frame-strict-cpython')
read = lambda p: json.loads(Path(p).read_text())
def sha(p):
    with Path(p).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def save(p, value):
    with Path(p).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

materialized = read(ORIGIN / 'materialized.json')
assert materialized['status'] == 'prepared_not_executed' and not materialized['targets_executed']
origin_pins = read(ORIGIN / 'pins.json')
assert sha(ORIGIN / 'pins.json') == materialized['pins_sha256']
source = read(BUILD / 'source.json')
selected = read(CONTROL / 'source.json')
pair = read(BUILD / 'pair-report.json')
proof = read(BUILD / 'vector-training-proof.json')
independent_path = Path('/tmp/oriole-reference-frame-v3-build-review/rust.json')
independent = read(independent_path)
assert source == selected and source['source_count'] == 72
assert source['candidate_base_commit'] == '0f66d54ac8418f0a6e628ad18570677a19c9ed45'
assert pair['status'] == proof['status'] == independent['status'] == 'passed'
assert pair['source_manifest_sha256'] == sha(BUILD / 'source.json')
assert independent['pair_sha256'] == proof['pair_report_sha256'] == sha(BUILD / 'pair-report.json')
assert independent['author_proof_sha256'] == sha(BUILD / 'vector-training-proof.json')
manifest = Path(pair['pgo_manifest']['path'])
assert sha(manifest) == pair['pgo_manifest']['sha256'] == independent['manifest_sha256']
assert read(manifest)['base_rustflags'] == ['-Ctarget-cpu=x86-64-v3']
library_dir = manifest.parent / 'use'
assert pair['pgo_libraries']['use/liboriole_expat.so'] == '3637826b979a392f28bd04e9421b01ed6f86e353b62faed31fc2bded8144faa7'
assert pair['pgo_libraries']['use/liboriole_expat.a'] == '685d151726d447fab5ac29003603fd7597f7f2d123524ae3ca73916d65e48c8e'

# Do not couple these gates to separately owned Python elapsed-controller changes.
removed_pins = {p: h for p, h in origin_pins.items() if Path(p).is_relative_to(ORIGIN)}
pins = {p: h for p, h in origin_pins.items() if p not in removed_pins}
for name, digest in source['source_sha256'].items():
    assert pins[str(WORK / name)] == digest
    assert sha(WORK / name) == digest
for p in [independent_path, BUILD / 'vector-training-proof.json', BUILD / 'pair-report.json',
          BUILD / 'source.json', manifest, library_dir / 'liboriole_expat.so',
          library_dir / 'liboriole_expat.a', Path('/tmp/oriole-unique-accounting-evidence/api-tools/run_clean.py')]:
    pins[str(p)] = sha(p)

scripts = []
for name in ['api_native.py', 'strict_cpython.py', 'read_outcomes.py', 'methods.py']:
    origin = ORIGIN / name
    before = origin.read_text()
    assert sha(origin) == origin_pins[str(origin)]
    after = before.replace(str(ORIGIN), str(P)) if name == 'api_native.py' else before
    ast.parse(after)
    with (P / name).open('x') as stream:
        stream.write(after)
    with (P / (name + '.patch')).open('x') as stream:
        stream.write(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                               fromfile=str(origin), tofile=str(P / name))))
    scripts.append({'path': str(P / name), 'sha256': sha(P / name),
                    'origin': str(origin), 'origin_sha256': sha(origin),
                    'changes': 'API output directory only' if name == 'api_native.py' else 'byte-identical copy'})
    pins[str(P / name)] = sha(P / name)

original_strict = Path('/tmp/oriole-reference-frame-strict-cpython.py').read_text()
strict = (P / 'strict_cpython.py').read_text()
assert strict[strict.index('try:\n    for linkage'):] == original_strict[original_strict.index('try:\n    for linkage'):]
assert "'--consumer-fix'" in strict and '--allow-text-fragmentation' not in strict and '--system-allocator' not in strict
api = (P / 'api_native.py').read_text()
for fragment in ["'--test-timeout','3'", "'--memory-mib','1024'", "'--rss-mib','768'", "'--timeout','240'",
                 "len(a['results'])==len(b['results'])==4740", "for linkage in ['dynamic','static']:",
                 "for name in ['integration','adversarial','allocations']:"]:
    assert fragment in api, fragment
assert str(P) in api and str(ORIGIN) not in api

# Preserve the original non-green baseline rather than replacing it with allowances.
baseline_api = read(API / 'results.json')
raw = []
for line in (API / 'tests.log').read_text().splitlines():
    if line.startswith('ORIOLE_RESULT\t'):
        _, context, test, outcome, code = line.split('\t')
        raw.append({'context': context, 'test': test, 'outcome': outcome, 'code': int(code)})
assert raw == baseline_api['results'] and len(raw) == 4740
outcomes = collections.Counter(row['outcome'] for row in raw)
assert baseline_api['passed'] == 4347 and baseline_api['failed'] == 393
assert sorted(outcomes.values()) == [2, 391, 4347]

# This existing multiline-aware function reads saved logs; it executes no CPython suite.
namespace = {'Path': Path, 're': re, 'read': lambda p: Path(p).read_bytes()}
tree = ast.parse((P / 'methods.py').read_text())
function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'methods')
exec(compile(ast.Module(body=[function], type_ignores=[]), str(P / 'methods.py'), 'exec'), namespace)
method_summary = {}
for linkage in ['shared', 'static']:
    directory = STRICT / linkage
    summary = read(directory / 'summary.json')
    methods = namespace['methods'](directory / 'tests.log')
    assert len(methods) == 802 and summary['text_fragmentation'] is None
    assert summary['tests_exit_code'] == summary['gate_exit_code'] == 2
    failures = sorted(name for name, outcome in methods.items() if outcome in ['FAIL', 'ERROR'])
    assert len(failures) == 2
    method_summary[linkage] = {'methods': len(methods), 'failures': failures,
                               'tests_exit_code': summary['tests_exit_code'],
                               'method_map_sha256': hashlib.sha256(json.dumps(methods, sort_keys=True).encode()).hexdigest()}
provenance = read(WORK / 'integration/python-build-standalone/consumer-fix/provenance.json')
assert provenance['patched_source_sha256'] == '1c3cf2ee6dfa568cf833742ad786880f4816042705689a116a4f308b7a9d95f2'
pins[str(P / 'prepare.py')] = sha(P / 'prepare.py')
assert all(sha(p) == h for p, h in pins.items())
save(P / 'pins.json', pins)
save(P / 'preparation.json', {
    'status': 'prepared_not_executed', 'targets_executed': False,
    'source_commit': source['candidate_base_commit'], 'published_source_equivalent': '4064b0653534aff690c0e0f395a6b3b48da878fc',
    'source_files': 72, 'source_delta': [], 'source_manifest_sha256': sha(BUILD / 'source.json'),
    'compiler_treatment': 'x86-64-v3 only; original selected allocator/O3/ThinLTO recipe retained',
    'libraries': {ext: {'path': str(library_dir / ('liboriole_expat.' + ext)),
                        'sha256': sha(library_dir / ('liboriole_expat.' + ext))} for ext in ['so', 'a']},
    'build_proof': {'path': str(BUILD / 'vector-training-proof.json'), 'sha256': sha(BUILD / 'vector-training-proof.json')},
    'independent_build_review': {'path': str(independent_path), 'sha256': sha(independent_path)},
    'scripts': scripts, 'origin_materialization': {'path': str(ORIGIN / 'materialized.json'), 'sha256': sha(ORIGIN / 'materialized.json')},
    'separate_elapsed_preparation_pins_removed': sorted(removed_pins),
    'api': {'configurations': 4740, 'baseline_passed': 4347, 'baseline_failed': 393,
            'baseline_outcomes': dict(outcomes), 'test_seconds': 3, 'address_space_mib': 1024, 'rss_mib': 768, 'suite_seconds': 240,
            'outer_seconds': 300, 'assertions_and_limits_unchanged': True},
    'c_consumers': {'names': ['integration', 'adversarial', 'allocations'], 'linkages': ['dynamic', 'static'],
                    'total': 6, 'each_compile_and_run_seconds': 120, 'instrumentation': 'C ASan/UBSan; Rust release library uninstrumented; leak checking disabled'},
    'strict': {'linkages': ['shared', 'static'], 'each_seconds': 1000, 'baseline': method_summary,
               'complete_execution_loop_byte_identical_to_selected_controller': True, 'text_fragmentation_allowance': False,
               'consumer_fix': provenance, 'full_multiline_method_map_reader_preserved': True},
    'pins_sha256': sha(P / 'pins.json'), 'pins_count': len(pins),
    'scope': 'Preparation and saved-baseline materialization only. Root must explicitly release target runs after current measurements. Older rejected-coordinate gates remain unexecuted and untouched. Python elapsed extensions belong to the separate consumer-preparation and remain unmodified there.',
})
print(json.dumps({'prepared': str(P), 'preparation_sha256': sha(P / 'preparation.json'),
                  'pins': len(pins), 'targets_executed': False, 'baseline_outcomes': dict(outcomes),
                  'strict_baseline': method_summary}, indent=2))
