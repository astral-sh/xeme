"""Bounded saved Expat reuse check: exact Expat section of prior reader plus current identities."""
from pathlib import Path
import hashlib,json,os,re,shlex
assert os.sched_getaffinity(0)=={6}
O=Path('/tmp/oriole-x86-64-v3-pgo-study'); B=Path('/tmp/oriole-pgo-study')
OUT=Path('/tmp/oriole-reference-frame-v3-expat-reuse-review')
load=lambda p:json.loads(Path(p).read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
pins={}
def verify(p,h):
 if str(p) not in pins:pins[str(p)]=sha(p)
 assert pins[str(p)]==h,str(p)
 return h
old_path=Path('/tmp/oriole-x86-64-v3-build-independent-review/expat-native.json')
historical=load(old_path);assert historical['status']=='passed'
verify(O/'expat/report.json',historical['expat_report_sha256'])
verify('/tmp/oriole-x86-64-v3-expat-native-independent-review.py',historical['reader_sha256'])
r=load(O/'expat/report.json');assert r['status']=='passed' and all(r[k] for k in ('source_unchanged','pipeline_unchanged','tools_unchanged'))
prep=load(O/'preparation.json');assert r['preparation_sha256']==sha(O/'preparation.json')
assert r['tools_before']==r['tools_after']==load(B/'expat-control-build.json')['tools_sha256']
for p,h in r['tools_before'].items():verify(p,h)
assert r['source_manifest_sha256']==sha(B/'expat-source.json')==prep['expat_source_manifest_sha256']
source=load(B/'expat-source.json')['files']
for n,h in source.items():verify(B/'expat-source'/n,h)
assert len(r['commands'])==10
for cmd in r['commands']:
 assert cmd['exit']==0 and cmd['cpu']==3
 verify(O/'expat'/(cmd['label']+'.log'),cmd['log_sha256'])
 assert cmd['timeout']==(300 if cmd['label'].endswith('-training') else 60 if cmd['label']=='profile-counts' else 900)
pair=load(O/'pair-report.json');m=load(pair['pgo_manifest']['path']);inputs=Path(m['run'])/'inputs';im=load(inputs/'manifest.json')
expected=[(x['name'],ns,ch,handler,it) for x in im['rows'] for ns in x['namespaces'] for ch in x['chunks'] for handler in ['minimal','full'] for it in range(2)]
comparisons=[];traces=[]
for phase,oldphase in [('normal','control'),('generate','generate'),('use','use')]:
 prior=load(B/('expat-'+oldphase+'-build.json'))
 verify(B/('expat-'+oldphase+'-build.json'),prep['generic_expat_build_reports'][oldphase]['sha256'])
 build=O/'expat'/(phase+'-build');oldbuild=B/('expat-'+oldphase+'-build');raw=O/'expat/raw-profiles';oldraw=B/'expat-raw-profiles'
 verify(build/'expat_config.h',prior['generated_config_sha256'])
 cmd=next(x for x in r['commands'] if x['label']==phase+'-configure')
 expectedflags='-march=x86-64-v3'+('' if phase=='normal' else ' -fprofile-'+phase+'='+str(raw)+' -fprofile-prefix-path='+str(build))
 assert cmd['argv']==['/usr/bin/cmake','-S',str(B/'expat-source'),'-B',str(build),'-G','Unix Makefiles','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER=/usr/bin/cc','-DCMAKE_C_FLAGS='+expectedflags,'-DCMAKE_C_FLAGS_RELEASE=-O3 -DNDEBUG',*[f'-D{k}={v}' for k,v in prior['features'].items()]]
 newlog=O/'expat'/(phase+'-compile.log');oldlog=B/('expat-'+oldphase+'-compile.log')
 verify(oldlog,next(x['log_sha256'] for x in prior['commands'] if Path(x['log'])==oldlog))
 text=newlog.read_text();assert not re.search(r'warning:|error:',text,re.I)
 vv=[[shlex.split(line) for line in p.read_text().splitlines() if line.startswith('/usr/bin/cc ')] for p in (oldlog,newlog)]
 assert len(vv[0])==len(vv[1])==8
 assert sum('-c' in row for row in vv[1])==7 and sum('-shared' in row for row in vv[1])==1
 for av,bv in zip(*vv,strict=True):
  assert bv.count('-march=x86-64-v3')==1 and not any(x.startswith(('-march=','-mtune=')) for x in av)
  assert '-O3' in av and '-O3' in bv and not any(x.startswith('-flto') for x in bv)
  norm=[x.replace(str(build),'<BUILD>').replace(str(raw),'<RAW>') for x in bv if x!='-march=x86-64-v3']
  old=[x.replace(str(oldbuild),'<BUILD>').replace(str(oldraw),'<RAW>') for x in av]
  assert norm==old
  comparisons.append({'phase':phase,'generic':av,'v3':bv})
 assert r['actual_compile_vectors'][phase]==[{'generic':x,'v3':y} for x,y in zip(*vv,strict=True)]
 path=O/'expat'/(phase+'-training.json');t=load(path);priortraining=load(B/('expat-'+oldphase+'-training.json'))
 assert t['status']=='passed' and t['rows']==priortraining['rows'] and len(t['rows'])==288
 assert [(x['fixture'],x['namespaces'],x['chunk'],x['handlers'],x['iteration']) for x in t['rows']]==expected
 assert all(x['status']==1 and x['error']==0 and not x['callback_exceptions'] for x in t['rows'])
 library=r['libraries'][phase];verify(library['path'],library['sha256'])
 assert t['library_sha256']==library['sha256'] and t['xml_parse_origin']==library
 assert t['inputs_sha256']==m['inputs_sha256']['manifest.json']==sha(inputs/'manifest.json')
 verify(B/'training-inputs.json',priortraining['inputs_sha256'])
 oldinputs=load(B/'training-inputs.json');assert oldinputs['seed']==im['seed']
 assert len(oldinputs['rows'])==len(im['rows'])==12
 for old,new in zip(oldinputs['rows'],im['rows'],strict=True):
  assert {k:old[k] for k in ('name','encoding','bytes','sha256','chunks','namespaces')}=={k:new[k] for k in ('name','encoding','bytes','sha256','chunks','namespaces')}
  verify(old['path'],new['sha256'])
 assert t['script_sha256']==prep['pipeline_files']['tools/pgo/train.py'] and t['profile_file_environment'] is None
 cmd=next(x for x in r['commands'] if x['label']==phase+'-training')
 assert cmd['argv'][1:]==['-I','-S',str(O/'pipeline/tools/pgo/train.py'),'--library',library['path'],'--inputs',str(inputs),'--report',str(path)]
 traces.append({'phase':phase,'path':str(path),'sha256':sha(path),'rows':288,'origin':library})
assert load(O/'expat/normal-training.json')['rows']==load(O/'expat/generate-training.json')['rows']==load(O/'expat/use-training.json')['rows']
assert len(r['profiles_sha256'])==7
assert {p.name for p in (O/'expat/raw-profiles').iterdir()}==set(r['profiles_sha256'])
for n,h in r['profiles_sha256'].items():
 assert n.startswith('CMakeFiles#expat.dir#lib#') and n.endswith('.gcda');verify(O/'expat/raw-profiles'/n,h)
gcov=(O/'expat/profile-counts.log').read_text();assert len(re.findall(r'OBJECT_SUMMARY runs=1, sum_max=18094024',gcov))==7
assert {Path(x).name for x in re.findall(r'^(.+?):data:magic',gcov,re.M)}==set(r['profiles_sha256'])
assert ': 288 288 ' in gcov and '870312' in gcov

# Current byte identity and exact saved origin on all reusable libraries, with no dlopen.
assert comparisons==historical['compiler_vectors']
assert traces==historical['training']
assert r['libraries']==historical['expat_libraries']
for row in im['rows']:
 verify(inputs/row['file'],row['sha256'])
 assert (inputs/row['file']).stat().st_size==row['bytes']
for phase in ['normal','generate','use']:
 real=O/'expat'/f'{phase}-build/libexpat.so.1.12.4'
 verify(real,r['libraries'][phase]['sha256'])
 assert Path(r['libraries'][phase]['path']).read_bytes()==real.read_bytes()
 library=Path(r['libraries'][phase]['path'])
 assert library.read_bytes().startswith(b'\x7fELF')
 generic=load(B/f"expat-{'control' if phase=='normal' else phase}-build.json")
 assert generic['source_manifest_sha256']==r['source_manifest_sha256']
 assert generic['tools_sha256']==r['tools_before']
 generic_build=B/f"expat-{'control' if phase=='normal' else phase}-build"
 verify(generic_build/'expat_config.h',generic['generated_config_sha256'])
 generic_path=B/f"expat-{'control' if phase=='normal' else phase}-liboriole_expat.so"
 verify(generic_path,generic['library_sha256'])
 if phase!='generate':verify(generic_path,historical['verified_pins'][str(generic_path)])
assert Path('/usr/bin/cc').resolve()==Path('/usr/bin/x86_64-linux-gnu-gcc-13')
assert len(source)==167 and len(comparisons)==24 and len(traces)==3
# Every currently checked pin also agrees with the historical reviewer where overlapping.
for p,h in pins.items():
 if p in historical['verified_pins']:assert h==historical['verified_pins'][p],p
result={'status':'passed','scope':'Bounded saved-only reuse audit of existing Expat x86-64-v3 and generic controls for fresh selected-Oriole comparisons. No parser/compiler/loader/profile/benchmark target executed.',
 'origin_reader':{'path':'/tmp/oriole-x86-64-v3-expat-native-independent-review.py','sha256':sha('/tmp/oriole-x86-64-v3-expat-native-independent-review.py'),'adaptation':'Exact Expat build/source/vector/training/profile section copied unchanged; old Oriole/native freeze and campaign review deliberately excluded.'},
 'original_review':{'path':str(old_path),'sha256':sha(old_path)},'original_expat_report':{'path':str(O/'expat/report.json'),'sha256':sha(O/'expat/report.json')},
 'verified_source_files':len(source),'actual_vectors':len(comparisons),'object_vectors':21,'link_vectors':3,'generated_observations':864,'generated_fixtures':12,'profile_files':7,'compiler_tools':r['tools_before'],
 'reusable_libraries':{'normal_v3':r['libraries']['normal'],'pgo_v3':r['libraries']['use'],
  'normal_generic':{'path':str(B/'expat-control-liboriole_expat.so'),'sha256':sha(B/'expat-control-liboriole_expat.so')},
  'pgo_generic':{'path':str(B/'expat-use-liboriole_expat.so'),'sha256':sha(B/'expat-use-liboriole_expat.so')}},
 'configuration':'Expat2.8.4; GCC13.3 O3 shared PIC C99, fixed feature configuration; no LTO. Exactly -march=x86-64-v3 added to all three phases, plus normalized private build/profile paths. All24 raw argv vectors match generic controls after only these permitted differences.',
 'training_scope':'Original12 generated fixtures/288 observations per phase, including identical namespace/chunk/handler/iteration order and exact success/callback rows. Normal has no PGO; generated and PGO-use reuse the original distinct seven-file GCC training profile.',
 'reuse_verdict':'Existing normal and PGO-use v3 Expat libraries remain byte-identical to the independent audited builds and may be reused alongside original generic controls; no Expat rebuild required for the proposed fresh selected-Oriole study.',
 'limitations':['This proves saved/current artifact identity, not runtime linkage for a new process; root must retain fresh native preflight origin checks.','The prior Oriole-v3 libraries, observations and earlier study outcome are outside this reuse decision.','No new hardware eligibility, compatibility, performance or portable deployment claim; retain current host ISA guard and root-controlled execution.'],
 'verified_pins':pins,'reader_sha256':sha(__file__)}
p=OUT/'report.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'passed','path':str(p),'sha256':sha(p),'source_files':len(source),'vectors':len(comparisons),'pins':len(pins),'library_hashes':{k:v['sha256'] for k,v in result['reusable_libraries'].items()}},indent=2))
