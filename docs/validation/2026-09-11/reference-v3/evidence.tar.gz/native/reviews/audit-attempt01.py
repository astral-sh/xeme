"""Independently reconstruct completed fixed-ISA four-engine native runs; no target execution."""
import argparse,ast,collections,hashlib,json,math,random,statistics
from pathlib import Path
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--mode',choices=['normal','pgo'],required=True)
parser.add_argument('--completed-release',action='store_true')
args=parser.parse_args()
assert args.completed_release, 'Audit only after root confirms the mode completed and reaped'
P=Path('/tmp/oriole-reference-frame-v3-pgo-study');S=P/('native-'+args.mode);D=S/'native-screen'
OUT=Path('/tmp/oriole-reference-frame-v3-native-review');OUT.mkdir(exist_ok=True)
pins={}
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p,h=None):
 actual=sha(p);assert h is None or actual==h,str(p)
 assert pins.setdefault(str(p),actual)==actual
 return actual
def read(p):pin(p);return json.loads(Path(p).read_text())
build_path=Path('/tmp/oriole-reference-frame-v3-expat-reuse-review/report.json')
rust_path=Path('/tmp/oriole-reference-frame-v3-build-review/rust.json')
pin(build_path,'62a185644d285533486b7880f8f9eeffdaf5e9cad68dda84f69bedf043c752bc')
pin(rust_path,'8b18b30e670982f7e5e059657ff2d5c254af70773cff3629bfdd2503af6ffeee')
rust_review=read(rust_path);assert rust_review['status']=='passed' and rust_review['source_files']==72
for q,h in rust_review['verified_file_pins'].items():pin(q,h)
a=read(S/'adaptation.json');p=read(D/'protocol.json');f=read(D/'preflight.json');r=read(D/'results.json');ctl=read(S/'controller.json')
assert a['status']==ctl['status']==f['status']==r['status']=='passed'
assert a['mode']==args.mode and a['worker_body_byte_exact'] and a['prepared_not_executed']
pin(S/'native_screen.py',a['controller_sha256']);pin(S/'run.py',a['wrapper_sha256'])
origin=Path('/tmp/oriole-x86-64-v3-pgo-study')/('native-'+args.mode)
pin(origin/'native_screen.py');pin(origin/'run.py')
assert (S/'run.py').read_bytes()==(origin/'run.py').read_bytes()
assert (S/'native_screen.py').read_text().split('def run(',1)[1]==(origin/'native_screen.py').read_text().split('def run(',1)[1]
pin(P/'source.json',a['source_manifest_sha256']);assert a['source_manifest_sha256']=='a8db4ea9e6fa1c56020e8a231343c356bce7dc7'+'170e0766b09cc67dabd82a2af'
pin(P/'pair-report.json',a['pair_sha256']);assert a['pair_sha256']==rust_review['pair_sha256']
pin(P/'pair-freeze.json',a['freeze_sha256']);freeze=read(P/'pair-freeze.json');assert freeze['count']==len(freeze['files'])==153
freeze_self_output=None
for rel,rec in freeze['files'].items():
 q=P/rel
 if rel=='freeze01.stdout':
  assert rec=={'sha256':hashlib.sha256(b'').hexdigest(),'bytes':0}
  assert read(q)=={'count':153,'sha256':a['freeze_sha256']}
  freeze_self_output={'path':str(q),'original':rec,'final_sha256':sha(q),'final_bytes':q.stat().st_size,'reason':'Freezer inventoried its pre-opened stdout before writing its success record; the other 152 entries match exactly.'}
 else:pin(q,rec['sha256']);assert q.stat().st_size==rec['bytes']
assert freeze_self_output is not None
pin(P/'expat-reuse.json',a['reuse_sha256']);reuse=read(P/'expat-reuse.json');assert reuse['status']=='verified_reuse'
assert reuse['independent_receipt']=={'path':str(build_path),'sha256':sha(build_path)}
assert ctl['controller_sha256']==sha(S/'native_screen.py') and ctl['wrapper_sha256']==sha(S/'run.py')
for row,(stage,cpu,bound) in zip(ctl['commands'],[('preflight',5,600),('time',0,1200)],strict=True):
 assert row['phase']==stage and row['exit']==0 and row['timeout']==bound and 0<row['end']-row['start']<bound
 assert row['command']==['taskset','-c',str(cpu),'python3',str(S/'native_screen.py'),stage]
 pin(S/(stage+'-controller.log'),row['log_sha256'])
assert ctl['commands'][0]['end']<=ctl['commands'][1]['start']
for q in [P/'pair-report.json',Path('/tmp/oriole-x86-64-v3-pgo-study/expat/report.json')]:
 report=read(q);assert report['status']=='passed'
 assert ctl['commands'][0]['start']>max(x['end'] for x in report['commands'])
assert r['affinity']==[0] and f['protocol_sha256']==r['protocol_sha256']==sha(D/'protocol.json')
assert r['preflight_sha256']==sha(D/'preflight.json')
for result in [f,r]:assert result['hashes_before']==result['hashes_after']==p['hashes']
for q,h in p['hashes'].items():pin(q,h)
engines=['oriole-generic','oriole-v3','expat-generic','expat-v3']
expected_libraries=a['libraries']
assert p['libraries']==expected_libraries and list(p['libraries'])==engines
for rec in expected_libraries.values():pin(rec['path'],rec['sha256'])
for engine in ['expat-generic','expat-v3']:assert expected_libraries[engine]==reuse['libraries'][args.mode][engine]
for engine,base in [('oriole-generic',Path('/tmp/oriole-reference-frame-pgo-study')),('oriole-v3',P)]:
 report=read(base/'pair-report.json')
 if args.mode=='normal':expected={'path':str(base/'normal/liboriole_expat.so'),'sha256':report['normal_libraries']['liboriole_expat.so']}
 else:
  manifest=Path(report['pgo_manifest']);pin(manifest)
  expected={'path':str(manifest.parent/'use/liboriole_expat.so'),'sha256':report['pgo_libraries']['use/liboriole_expat.so']}
 assert expected_libraries[engine]==expected
ratios=[('oriole-v3','oriole-generic'),('expat-v3','expat-generic'),('oriole-generic','expat-generic'),('oriole-v3','expat-v3'),('oriole-v3','expat-generic')]
assert a['ratios']==[list(x) for x in ratios]
assert p['pairs']==a['pairs']==7 and p['seed']==2026091003
assert p['preflights']==a['preflights']==112 and p['timed_workers']==a['timed_workers']==784
manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
fixtures={}
for project in read(manifest)['projects']:
 entry=next(q for q in project['files'] if q['role']=='input');path=(manifest.parent/entry['path']).resolve();pin(path,entry['sha256']);fixtures[project['name']]=str(path)
fixtures.update({'generated-rare-declarations':'/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml','generated-entities':'/tmp/oriole-grammar-bench-plain/entities.xml'})
iterations={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
conditions=[{'name':name,'input':path,'chunk':chunk,'namespaces':ns,'iterations':iterations[name]} for chunk in [4096,65536] for name,path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False,True])]
assert p['conditions']==conditions and len(conditions)==28
assert len(f['rows'])==112 and len(r['rows'])==196 and len(r['summary'])==28
assert {x.name for x in D.glob('worker-*.json')}=={f'worker-{i:04d}.json' for i in range(896)}
ordinal=0;count_samples=collections.Counter();medians={};observations={};worker_rows=[]
def worker(row,c,pair,engine,cpu,count):
 global ordinal
 path=D/f'worker-{ordinal:04d}.json';raw=read(path);idx=ordinal;ordinal+=1
 assert raw=={k:v for k,v in row.items() if k not in ['observations','median_seconds']}
 assert row['condition']==c and row['pair']==pair and row['engine']==engine and row['returncode']==0 and row['stderr']==''
 assert row['command']==['taskset','-c',str(cpu),'/tmp/oriole-grammar-bench-plain/native-driver',p['libraries'][engine]['path'],c['input'],str(c['chunk']),str(count)]+(['namespaces'] if c['namespaces'] else [])
 data=json.loads(row['stdout']);samples=data['samples']
 assert data['version']==('oriole_compat_2.8.4' if engine.startswith('oriole-') else 'expat_2.8.4')
 assert len(samples)==count+1 and [x['iteration'] for x in samples]==list(range(count+1))
 assert [x['warmup'] for x in samples]==[True]+[False]*count
 assert all(type(x['seconds']) in [int,float] and math.isfinite(x['seconds']) and x['seconds']>0 for x in samples)
 got=sorted({(x['hash'],x['elements'],x['text_bytes']) for x in samples});assert len(got)==1
 assert row['observations']==[list(x) for x in got]
 key=json.dumps(c,sort_keys=True)
 assert observations.setdefault(key,got)==got
 assert all(type(x) is int and x>=0 for x in got[0][1:])
 med=statistics.median(x['seconds'] for x in samples[1:]);assert med==row['median_seconds']
 if pair==-1:count_samples['preflight']+=len(samples)
 else:count_samples['measured']+=len(samples)-1;count_samples['timed_warmup']+=1
 worker_rows.append({'ordinal':idx,'condition':c,'pair':pair,'engine':engine,'median_seconds':med,'samples':len(samples),'raw_sha256':pins[str(path)]})
 return med
for c in conditions:
 for engine in engines:worker(f['rows'][ordinal],c,-1,engine,5,1)
rng=random.Random(2026091003);jobs=[(c,i) for c in conditions for i in range(7)];rng.shuffle(jobs)
for row,(c,pair) in zip(r['rows'],jobs,strict=True):
 order=list(engines);rng.shuffle(order)
 assert row['condition']==c and row['pair']==pair and row['order']==order
 for rec,engine in zip(row['processes'],order,strict=True):medians[(json.dumps(c,sort_keys=True),pair,engine)]=worker(rec,c,pair,engine,0,c['iterations'])
assert ordinal==896 and count_samples=={'preflight':224,'measured':140560,'timed_warmup':784}
assert sum(count_samples.values())==141568
summary=[]
for c in conditions:
 pair_order=[x['pair'] for x in r['rows'] if x['condition']==c];assert sorted(pair_order)==list(range(7))
 values={f'{x}_over_{y}':[medians[(json.dumps(c,sort_keys=True),i,x)]/medians[(json.dumps(c,sort_keys=True),i,y)] for i in pair_order] for x,y in ratios}
 summary.append({'condition':c,'paired_ratios':values,'median_ratios':{k:statistics.median(v) for k,v in values.items()}})
assert summary==r['summary']
groups={}
for group in ['real','generated']:
 entries=[x for x in summary if x['condition']['name'].startswith('generated-')==(group=='generated')]
 groups[group]={'conditions':len(entries),'ratios':{k:statistics.geometric_mean(x['median_ratios'][k] for x in entries) for k in entries[0]['median_ratios']},'lower_counts':{k:sum(x['median_ratios'][k]<1 for x in entries) for k in entries[0]['median_ratios']}}
assert groups['real']['conditions']==24 and groups['generated']['conditions']==4
adverse={key:[{'condition':x['condition'],'ratio':x['median_ratios'][key]} for x in summary if x['median_ratios'][key]>1] for key in summary[0]['median_ratios']}
for q,h in pins.items():assert sha(q)==h

out={'status':'passed_saved_native_audit','mode':args.mode,'selection':'Root owns selection; no adoption is inferred from the independent arithmetic audit.',
 'role':'Independent reconstruction of root-collected native observations. Reviewer adapted this old reader and candidate controllers and authored prior C coordinate tests; no runtime authorship, target execution, or independent-author controller-review claim.',
 'freeze_self_output':freeze_self_output,
 'primary_comparator':'Generic Expat declared before collection; all five ratios and all adverse conditions retained.',
 'build_review_sha256':sha(build_path),'rust_review_sha256':sha(rust_path),'protocol_sha256':sha(D/'protocol.json'),'results_sha256':sha(D/'results.json'),'controller_sha256':sha(S/'controller.json'),
 'preflight_workers':112,'timed_workers':784,'all_workers':896,'cohorts':196,'samples':dict(count_samples),'total_samples':141568,'conditions':28,'pairs':7,'seed':2026091003,
 'groups':groups,'all_condition_paired_ratios':summary,'all_adverse_conditions_by_ratio':adverse,
 'observed_callbacks':{'all_samples_and_four_engines_agree_per_condition':True,'conditions':[{'condition':c,'hash_elements_text_bytes':observations[json.dumps(c,sort_keys=True)]} for c in conditions]},
 'libraries':expected_libraries,'worker_medians':worker_rows,'raw_files_sha256':pins,
 'limits':['One fixed first-attempt campaign; all seven pairs and all28conditions retained. No confidence interval or causal mechanism claim.',
 'The unchanged native driver times parser creation, callback registration, parse/native callbacks and free. Loading/process startup are excluded. Saved hashes and explicit library paths bind artifacts; no fresh same-process XML_Parse dladdr record exists in this legacy benchmark driver. Training origins were audited separately.',
 'Native callback hash covers names/attributes/character bytes independent of text fragmentation, plus element and text-byte counts. This is not the full XML API suite.',
 'Within-engine ratios compare explicit v3 ISA with generic under its fixed compiler configuration. Cross-engine generic/generic and v3/v3 comparisons retain Ohm/LLVM22 ThinLTO versus GCC13.3 without LTO differences.',
 'Normal artifacts have no PGO and only replay G288 for correctness. All PGO artifacts use the original generated-only G288 schedule. Candidate Oriole v3 profiles are fresh; generic controls and independently reverified historical Expat v3 builds are reused. All native workers in this campaign are fresh.',
 'No actual Python/full API or deployment result is inferred. No source, corpus, library, profile, producer record or assertion was changed by this reader.'],
 'reader_sha256':sha(__file__)}
dest=OUT/(args.mode+'.json')
with dest.open('x') as stream:stream.write(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'path':str(dest),'sha256':sha(dest),'groups':groups,'workers':896,'samples':141568},indent=2))
