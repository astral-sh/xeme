from pathlib import Path
import ast,hashlib,json,difflib
old=Path('/tmp/oriole-x86-64-v3-native-independent-review/audit.py')
out=Path('/tmp/oriole-reference-frame-v3-native-review')
s=old.read_text()
s=s.replace("P=Path('/tmp/oriole-x86-64-v3-pgo-study')", "P=Path('/tmp/oriole-reference-frame-v3-pgo-study')")
s=s.replace("OUT=Path('/tmp/oriole-x86-64-v3-native-independent-review')", "OUT=Path('/tmp/oriole-reference-frame-v3-native-review')")
a=s.index('build_path=');b=s.index("assert ctl['controller_sha256']",a)
s=s[:a]+'''build_path=Path('/tmp/oriole-reference-frame-v3-expat-reuse-review/report.json')
rust_path=Path('/tmp/oriole-reference-frame-v3-build-review/rust.json')
pin(build_path,'62a185644d285533486b7880f8f9eeffdaf5e9cad68dda84f69bedf043c752bc')
pin(rust_path,'8b18b30e670982f7e5e059657ff2d5c254af70773cff3629bfdd2503af6ffeee')
rust_review=read(rust_path);assert rust_review['status']=='passed' and rust_review['source_files']==72
for q,h in rust_review['verified_file_pins'].items():pin(q,h)
a=read(S/'adaptation.json');p=read(D/'protocol.json');f=read(D/'preflight.json');r=read(D/'results.json');ctl=read(S/'controller.json')
assert a['status']==ctl['status']==f['status']==r['status']=='passed'
assert a['mode']==args.mode and a['worker_body_byte_exact'] and a['prepared_not_executed']
pin(S/'native_screen.py',a['controller_sha256']);pin(S/'run.py',a['wrapper_sha256'])
origin=Path('/tmp/oriole-x86-64-v3-pgo-study')/('native-'+args.mode)
pin(origin/'native_screen.py');pin(origin/'run.py')
assert (S/'run.py').read_bytes()==(origin/'run.py').read_bytes()
assert (S/'native_screen.py').read_text().split('def run(',1)[1]==(origin/'native_screen.py').read_text().split('def run(',1)[1]
pin(P/'source.json',a['source_manifest_sha256']);assert a['source_manifest_sha256']=='a8db4ea9e6fa1c56020e8a231343c356bce7dc6170e0766b09cc67dabd82a2af'
pin(P/'pair-report.json',a['pair_sha256']);assert a['pair_sha256']==rust_review['pair_sha256']
pin(P/'pair-freeze.json',a['freeze_sha256']);freeze=read(P/'pair-freeze.json');assert freeze['count']==len(freeze['files'])==153
freeze_self_output=None
for rel,rec in freeze['files'].items():
 q=P/rel
 if rel=='freeze01.stdout':
  assert rec=={'sha256':hashlib.sha256(b'').hexdigest(),'bytes':0}
  assert read(q)=={'count':153,'sha256':a['freeze_sha256']}
  freeze_self_output={'path':str(q),'original':rec,'final_sha256':sha(q),'final_bytes':q.stat().st_size,'reason':'Freezer inventoried its pre-opened stdout before writing its success record; the other 152 entries match exactly.'}
 else:pin(q,rec['sha256']);assert q.stat().st_size==rec['bytes']
assert freeze_self_output is not None
pin(P/'expat-reuse.json',a['reuse_sha256']);reuse=read(P/'expat-reuse.json');assert reuse['status']=='verified_reuse'
assert reuse['independent_receipt']=={'path':str(build_path),'sha256':sha(build_path)}
''' +s[b:]
s=s.replace("[P/'pair-report.json',P/'expat/report.json']", "[P/'pair-report.json',Path('/tmp/oriole-x86-64-v3-pgo-study/expat/report.json')]")
a=s.index("assert a['build_artifacts_sha256']");b=s.index("assert p['pairs']",a)
s=s[:a]+'''engines=['oriole-generic','oriole-v3','expat-generic','expat-v3']
expected_libraries=a['libraries']
assert p['libraries']==expected_libraries and list(p['libraries'])==engines
for rec in expected_libraries.values():pin(rec['path'],rec['sha256'])
for engine in ['expat-generic','expat-v3']:assert expected_libraries[engine]==reuse['libraries'][args.mode][engine]
for engine,base in [('oriole-generic',Path('/tmp/oriole-reference-frame-pgo-study')),('oriole-v3',P)]:
 report=read(base/'pair-report.json')
 if args.mode=='normal':expected={'path':str(base/'normal/liboriole_expat.so'),'sha256':report['normal_libraries']['liboriole_expat.so']}
 else:
  manifest=Path(report['pgo_manifest']['path']);pin(manifest,report['pgo_manifest']['sha256'])
  expected={'path':str(manifest.parent/'use/liboriole_expat.so'),'sha256':report['pgo_libraries']['use/liboriole_expat.so']}
 assert expected_libraries[engine]==expected
ratios=[('oriole-v3','oriole-generic'),('expat-v3','expat-generic'),('oriole-generic','expat-generic'),('oriole-v3','expat-v3'),('oriole-v3','expat-generic')]
assert a['ratios']==[list(x) for x in ratios]
''' +s[b:]
s=s.replace("a['preflight_workers']", "a['preflights']")
s=s.replace(" 'role':'Independent reconstruction of root-collected fixed x86-64-v3 native measurements; no parser/compiler/benchmark executed for this audit.',", " 'role':'Independent reconstruction of root-collected native observations. Reviewer adapted this old reader and candidate controllers and authored prior C coordinate tests; no runtime authorship, target execution, or independent-author controller-review claim.',\n 'freeze_self_output':freeze_self_output,\n 'primary_comparator':'Generic Expat declared before collection; all five ratios and all adverse conditions retained.',")
s=s.replace("'Normal artifacts have no PGO and only replay G288 for correctness. Both PGO artifacts use the original generated-only G288 schedule; generic controls are the frozen prior builds and v3 builds have fresh profiles.'", "'Normal artifacts have no PGO and only replay G288 for correctness. All PGO artifacts use the original generated-only G288 schedule. Candidate Oriole v3 profiles are fresh; generic controls and independently reverified historical Expat v3 builds are reused. All native workers in this campaign are fresh.'")
ast.parse(s)
(out/'audit.py').write_text(s)
(out/'adaptation.patch').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),s.splitlines(True),fromfile=str(old),tofile=str(out/'audit.py'))))
body=lambda t:t.split("manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')",1)[1].split("out={'status'",1)[0]
assert body(s)==body(old.read_text())
d={'status':'prepared_saved_only_reader','origin':str(old),'origin_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'reader_sha256':hashlib.sha256(s.encode()).hexdigest(),'worker_schedule_arithmetic_body_byte_exact':True,'fifth_ratio':'oriole-v3_over_expat-generic','target_execution':False,'scope':'Current binding and fifth predeclared ratio, with existing raw worker reconstruction unchanged. Execute only after root reaps the requested mode.'}
(out/'preparation.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
