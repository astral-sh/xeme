"""Independent saved Expat build/freeze and native-adapter review; no target execution."""
from pathlib import Path
import ast,copy,hashlib,json,re,shlex
O=Path('/tmp/oriole-x86-64-v3-pgo-study');B=Path('/tmp/oriole-pgo-study');OUT=Path('/tmp/oriole-x86-64-v3-build-independent-review')
load=lambda p:json.loads(Path(p).read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
pins={}
def verify(p,h):
 if str(p) not in pins:pins[str(p)]=sha(p)
 assert pins[str(p)]==h,str(p)
 return h
rust=load(OUT/'rust.json');assert rust['status']=='passed';verify(OUT/'rust.json','13d89a1f1fb5e00e809e73bbdf5a90c06f14c4265ee9277b77e63db31c6eea10')
f=load(O/'pair-freeze.json');assert f['status']=='frozen' and len(f['files'])==f['count']==108
verify(O/'pair-freeze.json','0d43ec2a9c9c7c0483feb28c2cdb9558662de80c15ab5ace7279053f93950199')
for n,r in f['files'].items():verify(O/n,r['sha256']);assert (O/n).stat().st_size==r['bytes']
for p,h in rust['verified_file_pins'].items():
 if p in pins:assert pins[p]==h
 # Rust receipt already independently hashed tools/libraries, source, logs.
 pins[p]=h
r=load(O/'expat/report.json');assert r['status']=='passed' and all(r[k] for k in ('source_unchanged','pipeline_unchanged','tools_unchanged'))
prep=load(O/'preparation.json');assert r['preparation_sha256']==sha(O/'preparation.json')
assert r['tools_before']==r['tools_after']==load(B/'expat-control-build.json')['tools_sha256']
for p,h in r['tools_before'].items():verify(p,h)
assert r['source_manifest_sha256']==sha(B/'expat-source.json')==prep['expat_source_manifest_sha256']
source=load(B/'expat-source.json')['files']
for n,h in source.items():verify(B/'expat-source'/n,h)
assert len(r['commands'])==10
for cmd in r['commands']:
 assert cmd['exit']==0 and cmd['cpu']==3
 verify(O/'expat'/(cmd['label']+'.log'),cmd['log_sha256'])
 assert cmd['timeout']==(300 if cmd['label'].endswith('-training') else 60 if cmd['label']=='profile-counts' else 900)
pair=load(O/'pair-report.json');m=load(pair['pgo_manifest']['path']);inputs=Path(m['run'])/'inputs';im=load(inputs/'manifest.json')
expected=[(x['name'],ns,ch,handler,it) for x in im['rows'] for ns in x['namespaces'] for ch in x['chunks'] for handler in ['minimal','full'] for it in range(2)]
comparisons=[];traces=[]
for phase,oldphase in [('normal','control'),('generate','generate'),('use','use')]:
 prior=load(B/('expat-'+oldphase+'-build.json'))
 verify(B/('expat-'+oldphase+'-build.json'),prep['generic_expat_build_reports'][oldphase]['sha256'])
 build=O/'expat'/(phase+'-build');oldbuild=B/('expat-'+oldphase+'-build');raw=O/'expat/raw-profiles';oldraw=B/'expat-raw-profiles'
 verify(build/'expat_config.h',prior['generated_config_sha256'])
 cmd=next(x for x in r['commands'] if x['label']==phase+'-configure')
 expectedflags='-march=x86-64-v3'+('' if phase=='normal' else ' -fprofile-'+phase+'='+str(raw)+' -fprofile-prefix-path='+str(build))
 assert cmd['argv']==['/usr/bin/cmake','-S',str(B/'expat-source'),'-B',str(build),'-G','Unix Makefiles','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER=/usr/bin/cc','-DCMAKE_C_FLAGS='+expectedflags,'-DCMAKE_C_FLAGS_RELEASE=-O3 -DNDEBUG',*[f'-D{k}={v}' for k,v in prior['features'].items()]]
 newlog=O/'expat'/(phase+'-compile.log');oldlog=B/('expat-'+oldphase+'-compile.log')
 verify(oldlog,next(x['log_sha256'] for x in prior['commands'] if Path(x['log'])==oldlog))
 text=newlog.read_text();assert not re.search(r'warning:|error:',text,re.I)
 vv=[[shlex.split(line) for line in p.read_text().splitlines() if line.startswith('/usr/bin/cc ')] for p in (oldlog,newlog)]
 assert len(vv[0])==len(vv[1])==8
 assert sum('-c' in row for row in vv[1])==7 and sum('-shared' in row for row in vv[1])==1
 for av,bv in zip(*vv,strict=True):
  assert bv.count('-march=x86-64-v3')==1 and not any(x.startswith(('-march=','-mtune=')) for x in av)
  assert '-O3' in av and '-O3' in bv and not any(x.startswith('-flto') for x in bv)
  norm=[x.replace(str(build),'<BUILD>').replace(str(raw),'<RAW>') for x in bv if x!='-march=x86-64-v3']
  old=[x.replace(str(oldbuild),'<BUILD>').replace(str(oldraw),'<RAW>') for x in av]
  assert norm==old
  comparisons.append({'phase':phase,'generic':av,'v3':bv})
 assert r['actual_compile_vectors'][phase]==[{'generic':x,'v3':y} for x,y in zip(*vv,strict=True)]
 path=O/'expat'/(phase+'-training.json');t=load(path);priortraining=load(B/('expat-'+oldphase+'-training.json'))
 assert t['status']=='passed' and t['rows']==priortraining['rows'] and len(t['rows'])==288
 assert [(x['fixture'],x['namespaces'],x['chunk'],x['handlers'],x['iteration']) for x in t['rows']]==expected
 assert all(x['status']==1 and x['error']==0 and not x['callback_exceptions'] for x in t['rows'])
 library=r['libraries'][phase];verify(library['path'],library['sha256'])
 assert t['library_sha256']==library['sha256'] and t['xml_parse_origin']==library
 assert t['inputs_sha256']==m['inputs_sha256']['manifest.json']==sha(inputs/'manifest.json')
 verify(B/'training-inputs.json',priortraining['inputs_sha256'])
 oldinputs=load(B/'training-inputs.json');assert oldinputs['seed']==im['seed']
 assert len(oldinputs['rows'])==len(im['rows'])==12
 for old,new in zip(oldinputs['rows'],im['rows'],strict=True):
  assert {k:old[k] for k in ('name','encoding','bytes','sha256','chunks','namespaces')}=={k:new[k] for k in ('name','encoding','bytes','sha256','chunks','namespaces')}
  verify(old['path'],new['sha256'])
 assert t['script_sha256']==prep['pipeline_files']['tools/pgo/train.py'] and t['profile_file_environment'] is None
 cmd=next(x for x in r['commands'] if x['label']==phase+'-training')
 assert cmd['argv'][1:]==['-I','-S',str(O/'pipeline/tools/pgo/train.py'),'--library',library['path'],'--inputs',str(inputs),'--report',str(path)]
 traces.append({'phase':phase,'path':str(path),'sha256':sha(path),'rows':288,'origin':library})
assert load(O/'expat/normal-training.json')['rows']==load(O/'expat/generate-training.json')['rows']==load(O/'expat/use-training.json')['rows']
assert len(r['profiles_sha256'])==7
assert {p.name for p in (O/'expat/raw-profiles').iterdir()}==set(r['profiles_sha256'])
for n,h in r['profiles_sha256'].items():
 assert n.startswith('CMakeFiles#expat.dir#lib#') and n.endswith('.gcda');verify(O/'expat/raw-profiles'/n,h)
gcov=(O/'expat/profile-counts.log').read_text();assert len(re.findall(r'OBJECT_SUMMARY runs=1, sum_max=18094024',gcov))==7
assert {Path(x).name for x in re.findall(r'^(.+?):data:magic',gcov,re.M)}==set(r['profiles_sha256'])
assert ': 288 288 ' in gcov and '870312' in gcov
# Full AST comparison: remove only literal root/library/ratio bindings, caption and scope.
BASE=Path('/tmp/oriole-bulk-pgo-training-study/native');original=(BASE/'native_screen.py').read_text()
def normalized_ast(text):
 tree=ast.parse(text)
 if isinstance(tree.body[0],ast.Expr) and isinstance(tree.body[0].value,ast.Constant):tree.body[0].value=ast.Constant(value='<CAPTION>')
 for node in tree.body:
  if not isinstance(node,ast.Assign) or len(node.targets)!=1 or not isinstance(node.targets[0],ast.Name):continue
  name=node.targets[0].id
  if name in {'root','libraries','ratios'}:node.value=ast.Constant(value='<'+name+'>')
  elif name=='protocol':
   assert isinstance(node.value,ast.Dict)
   loc=[i for i,k in enumerate(node.value.keys) if isinstance(k,ast.Constant) and k.value=='scope'];assert len(loc)==1
   node.value.values[loc[0]]=ast.Constant(value='<SCOPE>')
 return ast.dump(tree,include_attributes=False)

def assignment(tree,name):return next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
adapters=[]
for mode in ('normal','pgo'):
 root=O/('native-'+mode);a=load(root/'adaptation.json');assert a['status']=='prepared_only'
 verify(root/'native_screen.py',a['controller_sha256']);verify(root/'run.py',a['wrapper_sha256'])
 assert (root/'run.py').read_bytes()==(BASE/'run.py').read_bytes()
 text=(root/'native_screen.py').read_text();tree=ast.parse(text);assert normalized_ast(text)==normalized_ast(original)
 libs=assignment(tree,'libraries');actual={ast.literal_eval(k):ast.literal_eval(v.args[0]) for k,v in zip(libs.keys,libs.values,strict=True)}
 assert actual==a['libraries'] and list(actual)==['oriole-generic','oriole-v3','expat-generic','expat-v3']
 assert a['ratios']==[['oriole-v3','oriole-generic'],['expat-v3','expat-generic'],['oriole-generic','expat-generic'],['oriole-v3','expat-v3']]
 assert ast.literal_eval(assignment(tree,'ratios'))==[tuple(v) for v in a['ratios']]
 for path,h in a['build_artifacts_sha256'].items():verify(path,h)
 assert actual['oriole-v3']==str(O/'normal/liboriole_expat.so' if mode=='normal' else Path(m['run'])/'use/liboriole_expat.so')
 assert actual['expat-v3']==r['libraries']['normal' if mode=='normal' else 'use']['path']
 generic=load(Path('/tmp/oriole-allocator-provenance-pgo-study/pair-report.json'))
 assert actual['oriole-generic']==str(Path('/tmp/oriole-allocator-provenance-pgo-study/normal/liboriole_expat.so') if mode=='normal' else Path(generic['pgo_manifest']['path']).parent/'use/liboriole_expat.so')
 assert actual['expat-generic']==str(B/('expat-control-liboriole_expat.so' if mode=='normal' else 'expat-use-liboriole_expat.so'))
 assert a['conditions']==28 and a['pairs']==7 and a['preflight_workers']==112 and a['timed_workers']==784
 iterations=ast.literal_eval(assignment(tree,'iterations'))
 cond=[(name,chunk,ns) for chunk in [4096,65536] for name in iterations for ns in ([False] if name.startswith('generated-') else [False,True])]
 assert len(cond)==28 and sum(iterations[name]*4*7 for name,_,_ in cond)==a['measured_samples']==140560
 assert a['warmup_samples']==784 and a['preflight_samples']==224
 if mode=='normal':
  assert 'Normal artifacts have no PGO; each replays the original G288 corpus for correctness' in text
  initial=(root/'native_screen-initial.py').read_text()
  assert initial.replace('Original G288 training only, fresh v3 profiles.','Normal artifacts have no PGO; each replays the original G288 corpus for correctness.')==text
 adapters.append({'mode':mode,'adaptation_sha256':sha(root/'adaptation.json'),'controller_sha256':a['controller_sha256'],'wrapper_sha256':a['wrapper_sha256'],'libraries':a['build_artifacts_sha256'],'ratios':a['ratios'],'preflight_workers':112,'timed_workers':784,'timed_measured_samples':140560,'timed_warmups':784,'preflight_samples':224,'status_at_review':a['status']})
# Actual Linux guard ran in both builds, includes CPU5 before native preflight release.
host=load(O/'host-features.json');assert set(host)=={'0','3','5'}
result={'status':'passed','scope':'Independent saved-data Expat24-vector/G864/profile audit, full108-file build freeze and two disabled native adapters. No compiler/parser/profiler/benchmark execution.',
 'rust_review_sha256':sha(OUT/'rust.json'),'pair_freeze_sha256':sha(O/'pair-freeze.json'),'frozen_files':108,'expat_report_sha256':sha(O/'expat/report.json'),'expat_source_files':len(source),'expat_vector_count':24,'expat_object_compiles':21,'expat_link_vectors':3,'compiler_vectors':comparisons,'training':traces,'fresh_gcda_files':r['profiles_sha256'],'expat_libraries':r['libraries'],'native_adapters':adapters,'host_features_sha256':sha(O/'host-features.json'),'verified_pins':pins,
 'verdict':'No blocker to root-scheduled native preflight/elapsed after all other target jobs finish. Keep same-engine ISA ratios separate from matched cross-engine ratios; do not claim v3 deployment suitability from generated training.',
 'limitations':['Rust Ohm/LLVM and Expat GCC compilers differ and only Rust uses ThinLTO. This is an ISA treatment within each fixed compiler configuration.','Normal artifacts do not use PGO. Exact G288 normal replay is a correctness check.','Fresh GCC profiles are bound by seven actual gcda files and raw gcov output; no new gcov/profile tool executed by reviewer.','Generic controls retain their earlier generated-only builds; v3 normal/generate/use are fresh builds on identical source, tool/configuration pins and original training.','No elapsed or full compatibility results from these ISA artifacts are claimed.'],'reader_correction':{'first_attempt':'/tmp/oriole-x86-64-v3-expat-native-independent-attempt01.stderr','reason':'Reader compared scalar training-manifest digest to a file-hash map and historical manifest. Historical Expat manifest uses absolute paths and retained stale captions; current portable manifest differs. Corrected check binds both exact manifest hashes, all12 same fixture bytes/encoding/chunks/namespaces and all288 exact actual rows. No producer data changed or target rerun.','second_attempt':'/tmp/oriole-x86-64-v3-expat-native-independent-attempt02.stderr','second_reason':'Reader literal used abbreviated parent-message caption rather than exact saved normal source. Corrected to exact saved wording; AST/timing and all preceding Expat checks already passed.','historical_manifest_sha256':sha(B/'training-inputs.json'),'current_manifest_sha256':sha(inputs/'manifest.json')},'reader_sha256':sha(__file__)}
p=OUT/'expat-native.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'passed','path':str(p),'sha256':sha(p),'verified_pins':len(pins),'freeze':108,'vectors':24}))
