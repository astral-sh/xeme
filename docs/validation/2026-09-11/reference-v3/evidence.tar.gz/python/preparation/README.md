# Conditional CPython elapsed experiment

Prepared, bound, and unexecuted. Root owns release and execution after the native PGO decision and fresh correctness gates. Keep all other local compiler/parser/elapsed targets idle during each elapsed campaign.

## Launch order

After root releases PGO consumer preparation:

```sh
python3 /tmp/oriole-reference-frame-v3-consumer-preparation/python/pgo/run.py prepare
```

This builds six extensions on CPU3 (600 seconds) and runs 72 canonical preflights on CPU3 (600 seconds). After both commands complete and all children are reaped, inspect their raw origins and canonical outputs before separately releasing timing:

```sh
python3 /tmp/oriole-reference-frame-v3-consumer-preparation/python/pgo/run.py time
```

Timing uses CPU0, 24 original conditions, seven seeded pairs, three engines, 504 workers, and 25,788 measured parses plus 504 discarded warmups. Worker timeout is 300 seconds; aggregate timing timeout is 1,200 seconds. The unchanged wrapper kills and reaps its process group on timeout/interruption. Normal mode uses the same two commands with `/python/normal/`, only if separately released.

## Pins and scope

- `materialized.json` binds source72, the completed candidate pair and vector proof, original freeze, and all adapted scripts; `pins.json` binds their upstream inputs. The original153-entry freeze remains intact: only the freezer's initially empty own stdout became its verified success record; all other152 entries match.
- Candidate PGO shared library: `/tmp/oriole-reference-frame-v3-pgo-study/pgo/runs/run-o12jfqdr/use/liboriole_expat.so`, SHA256 `3637826b979a392f28bd04e9421b01ed6f86e353b62faed31fc2bded8144faa7`.
- Generic Oriole PGO: `/tmp/oriole-reference-frame-pgo-study/pgo/runs/run-i9x6lhki/use/liboriole_expat.so`, SHA256 `d3c43850247b83aa3089b7f08deb31a084ee2aecb47b52d27e9d05e97b0e1bd4`.
- Primary Expat PGO: `/tmp/oriole-pgo-study/expat-use-liboriole_expat.so`, SHA256 `12d33ad26315e8b46a02e598df8581679d0561fb2d98a3d4744e483a573fbdd0`.
- Both Oriole arms use identical selected source72. The sole intended parser compiler treatment is fixed `x86-64-v3`; the generic default remains unchanged. Both PGO arms use original generated G288 training, with fresh profiles for the v3 candidate.
- CPython3.12.13, six held-out project XML inputs, pyexpat and ElementTree consumers, extension compilation flags, 24 conditions, worker code, timing boundary, iterations, seed202609104412, canonical checks, and destruction behavior are unchanged from the selected-reference recipe. Preparation captions alone changed. Extension compilation remains O2, without extension PGO or LTO.
- The elapsed pyexpat source is unmodified SHA256 `fd679a16f36304444af11953ad276d4493f2044f904a39b8fdf028c6f7def8a0`; the worker records same-process parser-library origins. The explicit CPython cleanup backport belongs only to separate strict correctness extensions.
- Three Python engines compare candidate/generic Oriole, candidate/generic Expat, and generic Oriole/generic Expat. This protocol provides no Python comparison with v3 Expat; native four-engine results cover that separately.

Root assigned API, six C consumers, and strict CPython execution to the separate `/tmp/oriole-reference-frame-v3-correctness-prep` owner. Earlier unexecuted API/strict adapters in this directory remain preparation history and are not a second launch queue.

Reviewer authored these controller adaptations and prior focused C coordinate tests, but no runtime changes. Root owns target collection and selection. No adoption or generic performance goal is inferred from preparation.
