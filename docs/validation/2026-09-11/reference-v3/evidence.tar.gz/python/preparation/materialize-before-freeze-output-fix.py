"""Materialize conditional Python/API/strict controllers after completed v3 build proof."""
from pathlib import Path
import argparse,ast,copy,difflib,hashlib,json,os
P=Path(__file__).parent;B=Path('/tmp/oriole-reference-frame-v3-pgo-study');C=Path('/tmp/oriole-reference-frame-pgo-study');W=Path('/home/dev-user/code/oss/oriole-reference-frame')
OLDPY=Path('/tmp/oriole-reference-frame-python-study');OLDAPI=Path('/tmp/oriole-reference-frame-api-gates');OLDSTRICT=Path('/tmp/oriole-reference-frame-strict-cpython')
PY='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();read=lambda p:json.loads(Path(p).read_text());pin=lambda p:{'path':str(p),'sha256':sha(p)}
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--released-build',action='store_true');args=parser.parse_args();assert __debug__ and args.released_build and os.sched_getaffinity(0)=={6}
assert not (P/'materialized.json').exists(), 'Preserve first materialization'
pre=read(P/'preparation.json');assert sha(__file__)==pre['materializer_sha256'] and all(sha(p)==h for p,h in pre['template_pins'].items())
source=read(B/'source.json');pair=read(B/'pair-report.json');control=read(C/'source.json');cpair=read(C/'pair-report.json');proof=read(B/'vector-training-proof.json');freeze=read(B/'pair-freeze.json')
assert source==control and len(source['source_sha256'])==72 and source['candidate_base_commit']=='0f66d54ac8418f0a6e628ad18570677a19c9ed45'
assert pair['status']==cpair['status']==proof['status']=='passed' and freeze['status']=='frozen'
assert pair['source_manifest_sha256']==cpair['source_manifest_sha256']==sha(B/'source.json')
assert proof['source_sha256']==sha(B/'source.json') and proof['pair_report_sha256']==sha(B/'pair-report.json') and proof['control_pair_report_sha256']==sha(C/'pair-report.json')
for name,row in freeze['files'].items():assert sha(B/name)==row['sha256'] and (B/name).stat().st_size==row['bytes']
assert all(sha(W/n)==h for n,h in source['source_sha256'].items())
mp=Path(pair['pgo_manifest']['path']);cm=Path(cpair['pgo_manifest']['path']);assert sha(mp)==pair['pgo_manifest']['sha256'] and read(mp)['base_rustflags']==['-Ctarget-cpu=x86-64-v3'];use=mp.parent/'use';cuse=cm.parent/'use'
pins={str(W/n):h for n,h in source['source_sha256'].items()}
for p in [B/'source.json',B/'pair-report.json',B/'vector-training-proof.json',B/'pair-freeze.json',mp,C/'source.json',C/'pair-report.json',cm,W/'include/expat.h',Path(PY),Path(__file__)]:pins[str(p)]=sha(p)
for p in [*list((W/'tools/cpython').glob('*.py')),*list((W/'tools/upstream-expat').iterdir()),W/'integration/python-build-standalone/consumer-fix/provenance.json',W/'integration/python-build-standalone/consumer-fix/cpython-3.12.13-external-parser.patch']:
 if p.is_file():pins[str(p)]=sha(p)
for linkage in ['shared','static']:
 for n in ['summary.json','tests.log','origin.log','pyexpat.c']:pins[str(OLDSTRICT/linkage/n)]=sha(OLDSTRICT/linkage/n)
for n in ['report.json']:pins[str(OLDSTRICT/n)]=sha(OLDSTRICT/n)
for n in ['results.json','manifest.json','tests.log','adapted/expat_config.h']:pins[str(OLDAPI/'api-native/upstream-api'/n)]=sha(OLDAPI/'api-native/upstream-api'/n)
records=[]
def save(path,data):
 with path.open('x') as f:f.write(json.dumps(data,indent=2)+'\n')
def copied_script(dest,origin,text,scope):
 ast.parse(text);dest.write_text(text);dest.with_suffix('.patch').write_text(''.join(difflib.unified_diff(origin.read_text().splitlines(True),text.splitlines(True),fromfile=str(origin),tofile=str(dest))))
 records.append({'path':str(dest),'sha256':sha(dest),'origin':pin(origin),'scope':scope});pins[str(dest)]=sha(dest)
# Existing three-engine Python protocol. Only captions change; worker/commands stay intact.
(P/'python').mkdir()
for mode in ['normal','pgo']:
 old=OLDPY/mode;out=P/'python'/mode;out.mkdir();original=read(old/'adaptation.json')
 for item in original['consumer_source']['files'].values():assert sha(item['path'])==item['sha256'];pins[item['path']]=item['sha256']
 for path,h in original['consumer_source']['interpreter_and_public_headers'].items():assert sha(path)==h;pins[path]=h
 candidate=B/'normal/liboriole_expat.so' if mode=='normal' else use/'liboriole_expat.so';selected=C/'normal/liboriole_expat.so' if mode=='normal' else cuse/'liboriole_expat.so'
 assert original['libraries']['candidate']==pin(selected)
 libs={'candidate':pin(candidate),'control':pin(selected),'expat':original['libraries']['expat']}
 expected=pair['normal_libraries']['liboriole_expat.so'] if mode=='normal' else pair['pgo_libraries']['use/liboriole_expat.so'];assert sha(candidate)==expected
 for item in libs.values():assert sha(item['path'])==item['sha256'];pins[item['path']]=item['sha256']
 changed={}
 for name,h in original['files'].items():
  assert sha(old/name)==h;text=(old/name).read_text();updated=text
  replacements=[('suffix control and reference-frame candidate','generic selected control and fixed-v3 candidate'),('suffix control, reference-frame candidate','generic selected control, fixed-v3 candidate'),('reference-frame '+mode+' CPython screen','fixed-v3 '+mode+' CPython screen')]
  applied=[]
  for a,b in replacements:
   if a in updated:updated=updated.replace(a,b);applied.append([a,b])
  if name in ['python_worker.py','run.py']:assert updated==text
  copied_script(out/name,old/name,updated,'Caption changes only; unmodified extension compiler commands, worker and timing protocol retained.');changed[name]=applied
 d=copy.deepcopy(original)
 d.update(libraries=libs,files={n:sha(out/n) for n in original['files']},parent_files=original['files'],parent_adaptation=pin(old/'adaptation.json'),changes=changed,candidate_source_manifest=pin(B/'source.json'),candidate_pair_report=pin(B/'pair-report.json'),selected_control_source_manifest=pin(C/'source.json'),selected_control_pair_report=pin(C/'pair-report.json'),source_runtime_control=source['candidate_base_commit'],source_runtime_candidate=source['candidate_base_commit'],source_delta={},runtime_source_delta=[],candidate_test_delta=[],inherited_fixture_delta=[],test_scope='Identical72-file source; ISA-only compiler treatment. New artifact correctness remains separate.',proof='Three engines only: current generic and v3 Oriole with generic Expat primary. Exact selected24-condition/7-pair protocol; no Python-v3-Expat claim. Original pyexpat/_elementtree sources and extension flags remain unchanged. Parser ISA alone differs.',execution_status='unexecuted',candidate_isa='x86-64-v3',primary_goal_comparator='generic Expat',candidate_vector_proof=pin(B/'vector-training-proof.json'))
 d.pop('selected_control_pair_freeze',None);save(out/'adaptation.json',d)
# Original4740 API plus six C consumers: only paths, same source tree/ceilings.
origin=OLDAPI/'api_native.py';before=origin.read_text();after=before
for a,b in [(str(OLDAPI),str(P)),(str(cuse),str(use)),('/tmp/oriole-suffix-element-names-api-gates/api-native/upstream-api',str(OLDAPI/'api-native/upstream-api'))]:assert a in after;after=after.replace(a,b)
# Guards verify all materialized bindings before target work.
guard="\nfrom pathlib import Path\nimport hashlib,json\n_pins=json.loads((Path(__file__).parent/'pins.json').read_text())\nassert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in _pins.items()), 'Prepared inputs changed'\n"
after=after.replace("if not __debug__: raise RuntimeError('Assertions required')", "if not __debug__: raise RuntimeError('Assertions required')"+guard)
after=after.replace("row['end']=time.time();", "row['reaped']=p is not None and p.poll() is not None;row['end']=time.time();")
copied_script(P/'api_native.py',origin,after,'Only output/library/reference paths and frozen-pin guard; exact original matrix/assertions/limits/C flags retained, explicit reaped receipt added.')
# Strict unchanged shared/static loop, with a small ISA/source binding preamble.
origin=Path('/tmp/oriole-reference-frame-strict-cpython.py');before=origin.read_text();loop=before[before.index('try:\n    for linkage'):]
prefix='''"""Strict CPython with the explicit cleanup backport; separate from elapsed extensions."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time
ROOT=Path(__file__).parent/'strict-cpython';WORK=Path('/home/dev-user/code/oss/oriole-reference-frame');BUILD=Path('/tmp/oriole-reference-frame-v3-pgo-study');BASELINE=Path('/tmp/oriole-reference-frame-strict-cpython');BASELINE_BUILD=Path('/tmp/oriole-reference-frame-pgo-study')
PYTHON='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert __debug__ and os.sched_getaffinity(0)=={3}
pins=json.loads((Path(__file__).parent/'pins.json').read_text());assert all(sha(p)==h for p,h in pins.items())
pair=json.loads((BUILD/'pair-report.json').read_text());source=json.loads((BUILD/'source.json').read_text());baseline_pair=json.loads((BASELINE_BUILD/'pair-report.json').read_text());baseline_source=json.loads((BASELINE_BUILD/'source.json').read_text())
assert pair['status']==baseline_pair['status']=='passed' and source==baseline_source
pgo_manifest=Path(pair['pgo_manifest']['path']);assert sha(pgo_manifest)==pair['pgo_manifest']['sha256'];library_dir=pgo_manifest.parent/'use'
assert json.loads(pgo_manifest.read_text())['base_rustflags']==['-Ctarget-cpu=x86-64-v3']
provenance=json.loads((WORK/'integration/python-build-standalone/consumer-fix/provenance.json').read_text())
assert provenance['patched_source_sha256']=='1c3cf2ee6dfa568cf833742ad786880f4816042705689a116a4f308b7a9d95f2'
for linkage,extension in [('shared','so'),('static','a')]:
 p=library_dir/('liboriole_expat.'+extension);assert sha(p)==pins[str(p)]==pair['pgo_libraries']['use/'+p.name]
 b=json.loads((BASELINE/linkage/'summary.json').read_text());assert b['library_sha256']==baseline_pair['pgo_libraries']['use/'+p.name] and b['text_fragmentation'] is None and b['consumer_fix']==provenance
ROOT.mkdir(exist_ok=False)
report={'status':'incomplete','pins':pins,'commands':[],'source_commit':source['candidate_base_commit'],'source_delta':[],'baseline_source_commit':baseline_source['candidate_base_commit'],'compiler_treatment':'x86-64-v3','scope':'Exact current source. Explicit pinned upstream pyexpat allocation-failure cleanup backport, unchanged strict suites and shared/static loop; no text-fragmentation allowance or system allocator. Compare all method outcomes/origins with selected generic reference. Elapsed extensions remain unmodified and separate.'}
def save():(ROOT/'report.json').write_text(json.dumps(report,indent=2)+'\\n')

'''
text=prefix+loop;assert text[text.index('try:\n    for linkage'):]==loop
copied_script(P/'strict_cpython.py',origin,text,'ISA/source/pin preamble only; entire selected shared/static command/wait/summary/comparison/assertion loop byte-exact.')
for n in ['liboriole_expat.so','liboriole_expat.a']:
 assert sha(use/n)==pair['pgo_libraries']['use/'+n];pins[str(use/n)]=sha(use/n)
# Existing full802 method/origin reader retargeted only to same source/new paths.
origin=Path('/tmp/oriole-compact-coordinate-correctness-prep/read_outcomes.py');before=origin.read_text();text=before.replace("W=Path('/home/dev-user/code/oss/oriole-compact-coordinates')", "W=Path('/home/dev-user/code/oss/oriole-reference-frame')")
copied_script(P/'read_outcomes.py',origin,text,'Source path only; same4740/6C/802 strict raw outcome/origin reader. No allocator reader needed in this compiler-only preparation.')
(P/'methods.py').write_bytes(Path('/tmp/oriole-compact-coordinate-correctness-prep/methods.py').read_bytes());pins[str(P/'methods.py')]=sha(P/'methods.py')
save(P/'pins.json',pins)
save(P/'materialized.json',{'status':'prepared_not_executed','targets_executed':False,'source':pin(B/'source.json'),'pair':pin(B/'pair-report.json'),'proof':pin(B/'vector-training-proof.json'),'freeze':pin(B/'pair-freeze.json'),'scripts':records,'pins_sha256':sha(P/'pins.json'),'python_protocol':'Three engines,24conditions,7pairs,72preflights,504timedworkers; genericExpatprimary. No Python-v3-Expat inference.','strict_protocol':'PGOshared/static,unchanged802methods,explicitcleanupbackport,unchangedlimits; raw failures remain.','api_protocol':'PGO original4740configuration matrix plus6Cconsumers, unchangedassertions/limits.'})
print(json.dumps({'materialized':str(P),'sha256':sha(P/'materialized.json'),'targets_executed':False}))
