"""Direct completed CPython source/build/preflight binding; saved reads only."""
from pathlib import Path
import argparse
import ast
import gzip
import hashlib
import importlib.util
import json
import math
import os

R=Path('/tmp/oriole-reference-frame-v3-consumer-preparation/python');pins={}
def read(p):
    p=Path(p);b=p.read_bytes();pins[str(p)]=hashlib.sha256(b).hexdigest();return b
def sha(p):read(p);return pins[str(Path(p))]
def load(p):return json.loads(read(p))
def check(mapping):
    for p,h in mapping.items():assert sha(p)==h,p

def verify(mode):
    assert os.sched_getaffinity(0) == {6}
    assert mode in ('normal','pgo')
    pins.clear()
    build=Path('/tmp/oriole-reference-frame-v3-pgo-study')
    readback=Path('/tmp/oriole-reference-frame-v3-build-review/rust.json')
    assert sha(readback)=='8b18b30e670982f7e5e059657ff2d5c254af70773cff3629bfdd2503af6ffeee'
    reviewed=load(readback);assert reviewed['status']=='passed' and reviewed['source_files']==72
    check(reviewed['verified_file_pins'])
    direct=load(build/'pair-report.json');assert sha(build/'pair-report.json')==reviewed['pair_sha256']
    source=load(build/'source.json');assert sha(build/'source.json')=='a8db4ea9e6fa1c56020e8a231343c356bce7dc6170e0766b09cc67dabd82a2af'
    python='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
    upstream=Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13').resolve()
    header='/home/dev-user/code/oss/oriole-reference-frame/include'
    inc='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/include/python3.12'
    suffix='.cpython-312-x86_64-linux-gnu.so';result={};outputs_by_mode={}
    for mode in (mode,):
        D=R/mode;S=D/'screen';a=load(D/'adaptation.json');parent=Path(a['parent_adaptation']['path']).parent
        prior=load(parent/'adaptation.json')
        assert parent==Path('/tmp/oriole-reference-frame-python-study')/mode
        assert a['status']=='prepared_only' and a['mode']==mode
        assert a['source_runtime_control']==a['source_runtime_candidate']=='0f66d54ac8418f0a6e628ad18570677a19c9ed45'
        assert a['candidate_isa']=='x86-64-v3' and a['primary_goal_comparator']=='generic Expat'
        for key in ('candidate_source_manifest','candidate_pair_report','selected_control_source_manifest','selected_control_pair_report','parent_adaptation','candidate_vector_proof'):
            v=a[key];assert sha(v['path'])==v['sha256']
        candidate=load(a['candidate_source_manifest']['path'])['source_sha256'];control=load(a['selected_control_source_manifest']['path'])['source_sha256']
        assert len(candidate)==len(control)==72
        assert candidate==control==source['source_sha256']
        delta={f:{'control':control.get(f),'candidate':candidate.get(f)} for f in candidate.keys()|control.keys() if candidate.get(f)!=control.get(f)}
        assert delta==a['source_delta']=={}
        assert a['runtime_source_delta']==[]
        assert a['candidate_test_delta']==[]
        assert a['inherited_fixture_delta']==[]
        assert candidate['crates/oriole_storage/src/allocator.rs']==control['crates/oriole_storage/src/allocator.rs']=='910ce7ead099bd6a306a037c77fa276f746ac0eac59f14d8bda9b9b1c2deeac7'
        assert a['parent_files']==prior['files']
        assert all(a[key]==prior[key] for key in ('counts','bounds','seed','consumer_source','parser_builds'))
        for name,h in a['files'].items():assert sha(D/name)==h
        for name,h in a['parent_files'].items():assert sha(parent/name)==h
        for name,replacements in a['changes'].items():
            before=read(parent/name).decode();after=read(D/name).decode();reverse=after
            for old,new in reversed(replacements):reverse=reverse.replace(new,old)
            assert reverse==before and ast.dump(ast.parse(reverse),include_attributes=False)==ast.dump(ast.parse(before),include_attributes=False)
        assert read(D/'python_worker.py')==read(parent/'python_worker.py')
        assert sha(a['header']['path'])==a['header']['sha256']==candidate['include/expat.h']==control['include/expat.h']
        for v in a['consumer_source']['files'].values():assert sha(v['path'])==v['sha256']
        check(a['consumer_source']['interpreter_and_public_headers'])
        libs=a['libraries']
        for v in libs.values():assert sha(v['path'])==v['sha256']
        assert libs['control']==prior['libraries']['candidate'] and libs['expat']==prior['libraries']['expat']
        assert libs['candidate']['sha256']==(direct['normal_libraries']['liboriole_expat.so'] if mode=='normal' else direct['pgo_libraries']['use/liboriole_expat.so'])
        c=load(D/'prepare-controller.json');b=load(D/'consumers/build.json');p=load(S/'preflight.json')
        assert c['jobs'][0]['end']<=c['jobs'][1]['start']
        assert c['jobs'][0]['start']>max(j['end'] for j in direct['commands'])
        assert c['status']=='passed' and c['controller_sha256']==sha(D/'run.py') and len(c['jobs'])==2
        for job in c['jobs']:
            assert job['exit']==0 and job['timeout_seconds']==600 and job['command'][:6]==['taskset','-c','3',python,'-I','-S'] and 'exception' not in job
            assert sha(D/(job['label']+'-controller.log'))==job['log_sha256']
        assert b['status']=='passed' and b['adaptations'] is None and b['cpython_revision']=='3bb231a6a5dc02b95658877318bf61501a7209e9'
        assert b['source_sha256_before']==b['source_sha256_after'];check(b['source_sha256_before'])
        assert b['source_sha256_before'][str(upstream/'Modules/pyexpat.c')]=='fd679a16f36304444af11953ad276d4493f2044f904a39b8fdf028c6f7def8a0'
        assert set(b['consumers'])=={'control','candidate','expat'}
        origins={};compiles=[]
        for engine,consumer in b['consumers'].items():
            directory=D/'consumers'/engine;library=directory/Path(libs[engine]['path']).name
            assert consumer['directory']==str(directory) and consumer['library']==str(library)
            assert sha(library)==libs[engine]['sha256'];check(consumer['files'])
            assert set(consumer['files'])=={str(library),*(str(directory/(m+suffix)) for m in ('pyexpat','_elementtree'))}
            for module,command in zip(('pyexpat','_elementtree'),consumer['commands'],strict=True):
                expected=['cc','-shared','-fPIC','-O2',*['-I'+x for x in (header,inc,inc+'/internal',str(upstream/'Modules/expat'),str(upstream/'Modules'))],str(upstream/('Modules/'+module+'.c')),str(library),'-Wl,-rpath,'+str(directory),'-o',str(directory/(module+suffix))]
                assert command['command']==expected and command['returncode']==0 and command['log_sha256']==sha(directory/(module+'-build.log'))
                compiles.append(expected)
            origins[engine]={m:{'path':str(directory/(m+suffix)),'sha256':sha(directory/(m+suffix))} for m in ('pyexpat','_elementtree')}
            origins[engine]['parser_library']={'path':str(library.resolve()),'sha256':libs[engine]['sha256']}
            origins[engine]['expat_version']='expat_2.8.4' if engine=='expat' else 'oriole_compat_2.8.4'
        assert len(compiles)==6
        assert p['status']=='preflight_passed' and p['kind']=='python' and p['affinity']==[3] and p['seed']==202609104412 and p['pairs']==7
        assert p['hashes_before']==p['hashes_after'] and p['hash_errors']=={};check(p['hashes_before'])
        assert p['conditions']==load(parent/'screen/preflight.json')['conditions'] and len(p['conditions'])==24 and len(p['preflights'])==len(p['processes'])==72 and p['rows']==[]
        assert p['conditions']==load(parent/'screen/preflight.json')['conditions']
        expected_outputs={}
        for index,(row,process) in enumerate(zip(p['preflights'],p['processes'],strict=True)):
            condition=p['conditions'][index//3];engine=['control','candidate','expat'][index%3]
            key=f"{condition['name']}/{condition['chunk']}/{condition['mode']}";label=key.replace('/','-')+'-'+engine+'--1-0'
            assert row['key']==key and row['engine']==engine and row['pair']==-1 and row['median_seconds'] is None and row['process']==label
            assert process['label']==label and process['status']=='passed' and process['returncode']==0 and process['timeout_seconds']==300
            specpath=S/(label+'.json')
            assert process['command']==[python,'-I','-S',str(D/'python_worker.py'),'--worker',str(specpath)]
            assert load(specpath)=={'input':condition['input'],'input_sha256':sha(condition['input']),'chunk':condition['chunk'],'mode':condition['mode'],'consumer':str(D/'consumers'/engine),'library_sha256':libs[engine]['sha256'],'iterations':0}
            for stream in ('stdout','stderr'):assert sha(S/process[stream])==process[stream+'_sha256']
            assert gzip.decompress(read(S/process['stderr']))==b''
            raw=json.loads(gzip.decompress(read(S/process['stdout'])))
            assert raw['identity']==row['identity']==origins[engine] and raw['samples']==row['samples']
            assert raw['gc_enabled'] is True and raw['python']==b['python']==p['python_version'] and len(raw['samples'])==1
            sample=raw['samples'][0]
            assert sample['iteration']==0 and sample['warmup'] is True and sample['parse_ns']>0 and sample['destruction_ns']>=0
            assert math.isfinite(sample['seconds']) and sample['seconds']==(sample['parse_ns']+sample['destruction_ns'])/1e9
            canonical=[sample['output_sha256'],sample['output_rows']];assert canonical[1]>0
            if key in expected_outputs:assert expected_outputs[key]==canonical
            else:expected_outputs[key]=canonical
        assert expected_outputs==p['expected']==load(parent/'screen/preflight.json')['expected']
        outputs_by_mode[mode]=expected_outputs
        result[mode]={'libraries':libs,'extension_compiles':6,'exact_compile_vectors':compiles,'preflight_workers':72,'canonical_conditions':24,'raw_warmup_samples':72,'origins':origins,'all_canonical_outputs_equal_Expat_and_selected_control':True,'build_manifest_sha256':sha(D/'consumers/build.json'),'preflight_sha256':sha(S/'preflight.json')}
    for path,digest in pins.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
    return {'inputs':dict(pins),'summary':result[mode],'conditions':p['conditions'],'source_delta':sorted(delta),'mode':mode,'targets_executed':False}

if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--mode',choices=('normal','pgo'),required=True)
    cli.add_argument('--released',action='store_true')
    args=cli.parse_args();assert args.released,'Only after the root confirms this consumer preparation completed and reaped'
    result=verify(args.mode)
    result['reader_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    dest=Path(__file__).parent/(args.mode+'-preflight-review.json')
    with dest.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps({'status':'passed','mode':args.mode,'extension_compiles':6,'preflight_workers':72,'input_pins':len(result['inputs']),'report_sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}))
