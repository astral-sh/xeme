from pathlib import Path
import ast,difflib,hashlib,json
old=Path('/tmp/oriole-reference-frame-python-independent-review');out=Path('/tmp/oriole-reference-frame-v3-python-review');root='/tmp/oriole-reference-frame-v3-consumer-preparation/python'
s=(old/'preflight_bindings.py').read_text().replace("R=Path('/tmp/oriole-reference-frame-python-study')",f"R=Path('{root}')")
a=s.index("    build=Path(");b=s.index("    python=",a)
s=s[:a]+'''    build=Path('/tmp/oriole-reference-frame-v3-pgo-study')
    readback=Path('/tmp/oriole-reference-frame-v3-build-review/rust.json')
    assert sha(readback)=='8b18b30e670982f7e5e059657ff2d5c254af70773cff3629bfdd2503af6ffeee'
    reviewed=load(readback);assert reviewed['status']=='passed' and reviewed['source_files']==72
    check(reviewed['verified_file_pins'])
    direct=load(build/'pair-report.json');assert sha(build/'pair-report.json')==reviewed['pair_sha256']
    source=load(build/'source.json');assert sha(build/'source.json')=='a8db4ea9e6fa1c56020e8a231343c356bce7dc6170e0766b09cc67dabd82a2af'
''' +s[b:]
s=s.replace("assert parent==Path('/tmp/oriole-suffix-element-names-python-study')/mode", "assert parent==Path('/tmp/oriole-reference-frame-python-study')/mode")
s=s.replace("assert a['source_runtime_control']=='a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9' and a['source_runtime_candidate']==prepared['head']", "assert a['source_runtime_control']==a['source_runtime_candidate']=='0f66d54ac8418f0a6e628ad18570677a19c9ed45'\n        assert a['candidate_isa']=='x86-64-v3' and a['primary_goal_comparator']=='generic Expat'")
s=s.replace("'parent_adaptation')", "'parent_adaptation','candidate_vector_proof')")
s=s.replace("assert candidate==direct['source']['source_sha256'] and control==direct['control_source']['source_sha256']", "assert candidate==control==source['source_sha256']")
s=s.replace("assert delta==a['source_delta'] and sorted(delta)==prepared['expected_source_delta']", "assert delta==a['source_delta']=={}")
s=s.replace("assert a['runtime_source_delta']==['crates/oriole/src/lib.rs']", "assert a['runtime_source_delta']==[]")
s=s.replace("assert sorted(a['candidate_test_delta'])==['crates/oriole/tests/adapter_frame.rs','tests/c/integration.c']", "assert a['candidate_test_delta']==[]")
s=s.replace("assert a['inherited_fixture_delta']==['tests/c/integration.c']", "assert a['inherited_fixture_delta']==[]")
s=s.replace("direct['pair']['normal_libraries']", "direct['normal_libraries']").replace("direct['pair']['pgo_libraries']", "direct['pgo_libraries']")
s=s.replace("        assert c['status']=='passed'", "        assert c['jobs'][0]['end']<=c['jobs'][1]['start']\n        assert c['jobs'][0]['start']>max(j['end'] for j in direct['commands'])\n        assert c['status']=='passed'")
ast.parse(s);(out/'preflight_bindings.py').write_text(s)
# Preserve the complete extension/compiler/preflight checking body, aside from two ordering assertions.
expected=(old/'preflight_bindings.py').read_text().split("        c=load(D/'prepare-controller.json')",1)[1]
actual=s.split("        c=load(D/'prepare-controller.json')",1)[1].replace("        assert c['jobs'][0]['end']<=c['jobs'][1]['start']\n        assert c['jobs'][0]['start']>max(j['end'] for j in direct['commands'])\n",'')
assert actual==expected
(out/'preflight_bindings.patch').write_text(''.join(difflib.unified_diff((old/'preflight_bindings.py').read_text().splitlines(True),s.splitlines(True))))
h=hashlib.sha256(s.encode()).hexdigest()
audit=(old/'audit.py').read_text().replace("Path('/tmp/oriole-reference-frame-python-study')",f"Path('{root}')")
audit=audit.replace('a0cf4b1815a8d0305a2d84d3c11904e1617cecc5ad40f7dd343b1bac2d7d1f8c',h)
audit=audit.replace("    '", "    '")
audit=audit.replace("out={'status':'passed_independent_raw_elapsed_reconstruction'", "out={'role':'Reviewer adapted selected-reference controllers/readers and authored prior C coordinate tests; no runtime authorship or target execution. Independent reconstruction of root-collected observations, not independent-author controller review.','primary_comparator':'Generic Expat; no Python v3 Expat comparison.','status':'passed_independent_raw_elapsed_reconstruction'")
ast.parse(audit);(out/'audit.py').write_text(audit)
assert audit.split("a=load(D/'adaptation.json')",1)[1].split("out={'role'",1)[0]==(old/'audit.py').read_text().split("a=load(D/'adaptation.json')",1)[1].split("out={'status'",1)[0]
(out/'audit.patch').write_text(''.join(difflib.unified_diff((old/'audit.py').read_text().splitlines(True),audit.splitlines(True))))
r={'status':'prepared_saved_only','target_execution':False,'helper_sha256':h,'reader_sha256':hashlib.sha256(audit.encode()).hexdigest(),'origins':{str(old/n):hashlib.sha256((old/n).read_bytes()).hexdigest() for n in ['preflight_bindings.py','audit.py']},'scope':'Current source/pair/ISA bindings replace earlier source-delta assertions. Extension commands, all72 raw preflights, all504 timed workers, sequence/sample/arithmetic/canonical/origin checks remain exact. Two child ordering checks added. Only run after root reaps the named phase.'}
(out/'preparation.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
