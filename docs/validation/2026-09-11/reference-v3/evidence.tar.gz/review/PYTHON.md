# Completed optional v3 PGO Python measurement

No adoption decision. Generic Expat is the predeclared comparator. All24 conditions and all adverse results remain included.

| Group | Candidate / generic Oriole | Candidate / generic Expat | Within1.10 of Expat |
|---|---:|---:|---:|
| all | 0.988272897 | 1.094264715 | 11/24 |
| elementtree | 0.985511285 | 1.127756040 | 5/12 |
| pyexpat-events | 0.991042247 | 1.061767992 | 6/12 |

The overall geometric mean is9.43% slower than generic Expat. ElementTree is12.78% slower, and pyexpat is6.18% slower. Thirteen individual conditions exceed10%; the aggregate does not establish that every workload meets the threshold.

The separate raw readback reconstructed all504 timed workers,25,788 measured samples and504 discarded warmups. Parser-library and extension identities, canonical outputs, recorded medians and every pair ratio matched the saved records. The broader source/build/preflight/schedule audit remains separately attributed to its root-executed reader. No parser or compiler was run for this readback.

## Every condition

Ratios above1 are adverse; Expat ratios above1.10 miss the requested condition threshold. All three ratios are included, so no slower baseline or candidate cases disappear.

| Project | Chunk | Consumer | Candidate / generic Oriole | Generic Oriole / generic Expat | Candidate / generic Expat | Within1.10 |
|---|---:|---|---:|---:|---:|---|
| vulkan | 4096 | elementtree | 0.978759193 | 1.006380352 | 0.984844305 | yes |
| vulkan | 4096 | pyexpat-events | 0.979884604 | 1.097721674 | 1.079847234 | yes |
| vulkan | 65536 | elementtree | 0.980399739 | 1.131640132 | 1.109459690 | no |
| vulkan | 65536 | pyexpat-events | 0.988968214 | 1.090565709 | 1.080331864 | yes |
| wayland | 4096 | elementtree | 0.992139657 | 0.867550334 | 0.859422370 | yes |
| wayland | 4096 | pyexpat-events | 0.997151375 | 0.699795407 | 0.698171018 | yes |
| wayland | 65536 | elementtree | 0.982826506 | 0.840821330 | 0.821655610 | yes |
| wayland | 65536 | pyexpat-events | 1.005514149 | 0.686907278 | 0.685920222 | yes |
| maven | 4096 | elementtree | 0.994357653 | 1.533287175 | 1.526089798 | no |
| maven | 4096 | pyexpat-events | 0.983339289 | 1.299151293 | 1.287622731 | no |
| maven | 65536 | elementtree | 0.992611074 | 1.489409079 | 1.468905700 | no |
| maven | 65536 | pyexpat-events | 0.982158728 | 1.330156083 | 1.318364603 | no |
| batik | 4096 | elementtree | 0.983125375 | 1.104266195 | 1.083440424 | yes |
| batik | 4096 | pyexpat-events | 0.980698137 | 1.040525098 | 1.013783324 | yes |
| batik | 65536 | elementtree | 0.990456334 | 1.090418219 | 1.074139449 | yes |
| batik | 65536 | pyexpat-events | 0.996988078 | 1.076665636 | 1.068210329 | yes |
| gtk | 4096 | elementtree | 0.993978791 | 1.212999019 | 1.155092743 | no |
| gtk | 4096 | pyexpat-events | 1.003879115 | 1.127026089 | 1.130323818 | no |
| gtk | 65536 | elementtree | 0.977817592 | 1.122230344 | 1.102554624 | no |
| gtk | 65536 | pyexpat-events | 1.001956223 | 1.163669475 | 1.165945872 | no |
| docbook | 4096 | elementtree | 0.983812962 | 1.346295109 | 1.291372475 | no |
| docbook | 4096 | pyexpat-events | 0.984774342 | 1.241730903 | 1.210226771 | no |
| docbook | 65536 | elementtree | 0.976106105 | 1.299748945 | 1.278492406 | no |
| docbook | 65536 | pyexpat-events | 0.987693500 | 1.271165682 | 1.253217667 | no |

The candidate is slower than generic Oriole in three pyexpat conditions: Wayland65536 (+0.5514%), GTK4096 (+0.3879%), and GTK65536 (+0.1956%). It is slower than Expat in19 conditions. The slowest is Maven4096 through ElementTree at1.52609× Expat.

This is one fixed campaign on one host with unchanged CPython3.12.13 sources. No confidence interval, broad CPU coverage, normal-Python outcome, full project execution, or generic ISA performance claim is inferred. Generic default remains unchanged.
