"""Bounded, separate raw Python arithmetic readback; saved files only."""
from pathlib import Path
import collections,gzip,hashlib,json,math,statistics
R=Path('/tmp/oriole-reference-frame-v3-consumer-preparation/python/pgo');S=R/'screen';O=Path('/tmp/oriole-reference-frame-v3-evidence-inventory');pins={}
def read(p):
 p=Path(p);b=p.read_bytes();pins[str(p)]=hashlib.sha256(b).hexdigest();return b
def load(p):return json.loads(read(p))
def gm(v):return statistics.geometric_mean(v)
d=load(S/'results.json');b=load('/tmp/oriole-reference-frame-v3-python-review/pgo-preflight-review.json')
assert pins['/tmp/oriole-reference-frame-v3-python-review/pgo-preflight-review.json']=='04faa634928531b356abda8d12c9a282c7a0d8c20c51c4141de799e5b8943214'
assert d['status']=='passed' and len(d['rows'])==len(d['processes'])==504 and len(d['conditions'])==24
conditions={f"{c['name']}/{c['chunk']}/{c['mode']}":c for c in d['conditions']};medians={};counts=collections.Counter()
for row,p in zip(d['rows'],d['processes'],strict=True):
 assert p['label']==row['process'] and p['returncode']==0 and p['status']=='passed'
 payload=read(S/p['stdout']);assert pins[str(S/p['stdout'])]==p['stdout_sha256']
 stderr=read(S/p['stderr']);assert pins[str(S/p['stderr'])]==p['stderr_sha256'] and gzip.decompress(stderr)==b''
 raw=json.loads(gzip.decompress(payload));assert raw['samples']==row['samples'] and raw['identity']==row['identity']==b['summary']['origins'][row['engine']]
 c=conditions[row['key']];samples=raw['samples'];assert len(samples)==c['iterations']+1
 measured=[]
 for i,s in enumerate(samples):
  assert s['iteration']==i and s['warmup']==(i==0) and s['parse_ns']>0 and s['destruction_ns']>=0
  total=(s['parse_ns']+s['destruction_ns'])/1e9;assert total==s['seconds'] and math.isfinite(total) and total>0
  assert [s['output_sha256'],s['output_rows']]==d['expected'][row['key']]
  counts['warmups' if i==0 else 'measured']+=1
  if i:measured.append(total)
 key=row['key'],row['pair'],row['engine'];assert key not in medians
 medians[key]=statistics.median(measured);assert medians[key]==row['median_seconds']
assert counts=={'measured':25788,'warmups':504} and len(medians)==504
ratios={'candidate_over_control':('candidate','control'),'control_over_expat':('control','expat'),'candidate_over_expat':('candidate','expat')};all_conditions=[]
for saved in d['summary']:
 c=saved['condition'];key=f"{c['name']}/{c['chunk']}/{c['mode']}";assert c==conditions[key]
 values={k:[medians[key,p,a]/medians[key,p,b] for p in range(7)] for k,(a,b) in ratios.items()};assert values==saved['paired_ratios']
 values={k:statistics.median(v) for k,v in values.items()};assert values==saved['median_ratios']
 all_conditions.append({'condition':c,'median_ratios':values})
groups={}
for name in ['all','elementtree','pyexpat-events']:
 rows=[r for r in all_conditions if name=='all' or r['condition']['mode']==name]
 groups[name]={'conditions':len(rows),'ratios':{k:gm(r['median_ratios'][k] for r in rows) for k in ratios},'lower_than_generic_Oriole':sum(r['median_ratios']['candidate_over_control']<1 for r in rows),'lower_than_generic_Expat':sum(r['median_ratios']['candidate_over_expat']<1 for r in rows),'within_1_10_generic_Expat':sum(r['median_ratios']['candidate_over_expat']<=1.10 for r in rows)}
adverse={k:sorted([r for r in all_conditions if r['median_ratios'][k]>1],key=lambda r:r['median_ratios'][k],reverse=True) for k in ratios}
misses=sorted([r for r in all_conditions if r['median_ratios']['candidate_over_expat']>1.10],key=lambda r:r['median_ratios']['candidate_over_expat'],reverse=True)
for p,h in pins.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
out={'status':'passed_saved_python_arithmetic_readback','role':'Separate bounded arithmetic over all504 raw compressed stdout payloads, plus identity/canonical checks against the completed72-preflight receipt. Root owns the broader shared reader audit; no target execution, compression, or adoption decision.','timed_workers':504,'samples':dict(counts),'groups':groups,'all_conditions':all_conditions,'all_adverse_conditions_by_ratio':adverse,'all_above_1_10_generic_Expat':misses,'threshold':'Within1.10 means a condition median(candidate/Expat)<=1.10. Overall geomean is separate and does not make each condition compliant.','reader_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'raw_inputs_sha256':pins}
p=O/'python-interpretation.json';p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'groups':groups,'adverse_counts':{k:len(v) for k,v in adverse.items()},'misses':len(misses)},indent=2))
