# Reference-frame stable PGO PBS audit preparation

Prepared for the root-dispatched PBS workflow **34653585245**, attempt 1, at `4064b0653534aff690c0e0f395a6b3b48da878fc` (`workflow_dispatch`, PGO enabled). One initial metadata read confirmed that head and an in-progress run. Root owns monitoring, download and any interpreter/container execution. No downloaded artifact has been inspected or executed by this preparation.

## Expected source changes

The prior stable PGO PBS run was 34586223169 at PR126 head `c61b63476ce83b69814fd704b6c6710811e52a9c`, checked out through a PR merge. The new dispatch checks out its branch head directly; the old merge commit must not be required.

| Source inventory | Previous | New |
| --- | ---: | ---: |
| PBS bundle inputs | 71 | 73 |
| PGO source inputs | 67 | 69 |
| Pipeline files | 6 | 6 |
| Bundle/PGO overlap | 64 | 66 |

`expected-source.json` records exact Git-blob hashes at the dispatched head and the nine changed files. All 69 PGO source pins also match the measured reference-frame source `0f66d54ac8418f0a6e628ad18570677a19c9ed45`.

Four runtime files differ: `crates/oriole/src/arena.rs`, `crates/oriole/src/lib.rs`, `crates/oriole_expat/src/lib.rs`, and `crates/oriole_storage/src/allocator.rs`. Five test modules differ: core and C-adapter `context_text_tests.rs` are new, while `crates/oriole/tests/adapter_frame.rs`, `crates/oriole/tests/multibyte.rs`, and `crates/oriole_expat/src/tests.rs` changed. The C integration fixtures are outside both Rust build inventories.

The PBS workflow, integration builders, overlay patch, consumer cleanup backport, TLS probe/old-glibc script, six PGO tools, public header, Cargo manifests and lockfile are unchanged. The PBS revision remains `a4553880293fe9d1bb62747d34ab0e5121d3554f`; CPython remains 3.12.13. New library/profile hashes and profile function/block totals are expected and must be read from this run. They must not be copied from the old trial or the local Ohm benchmark build.

## Root retrieval after completion

Use a fresh result directory, suggested `/tmp/oriole-reference-frame-pbs-results`. From the OSS checkout, save these outputs using `/home/dev-user/.local/bin/gh-auto`:

```sh
gh-auto api repos/astral-sh/oriole/actions/runs/34653585245
gh-auto api repos/astral-sh/oriole/actions/runs/34653585245/jobs
gh-auto api repos/astral-sh/oriole/actions/runs/34653585245/artifacts
gh-auto run view 34653585245 --repo astral-sh/oriole --log
```

Save them as `run.json`, `jobs.json`, `artifacts.json`, and `workflow.log`. Retrieve the artifact-specific `/repos/astral-sh/oriole/actions/artifacts/<id>/zip` endpoints selected by exact names:

- `oriole-pbs-validation` → `validation.zip` (14-day retention).
- `oriole-pbs-experimental-distribution` → `distribution.zip` (7-day retention).

Keep the original ZIP files and final API metadata. Artifact IDs and SHA-256 digests must come from this run, with matching workflow/run/head identity. Do not use a branch-latest artifact or an extracted download without its original API-digest-verifiable ZIP. A matching API digest is not an independently verified signature/attestation.

## Prepared saved-data commands

After root finishes download, the first command verifies both ZIP digests, extracts their data into the original audit layout, decompresses the distribution, saves its member inventory, copies seven selected regular members and records host `readelf` output. It never loads or runs a downloaded executable.

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-pbs-review-prep/inspect_distribution.py --released --root /tmp/oriole-reference-frame-pbs-results
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-reference-frame-pbs-review-prep/audit.py --released --root /tmp/oriole-reference-frame-pbs-results
```

Capture each command's stdout/stderr and retain any first failure before correcting a reader assumption. Neither command has been run during preparation; only their Python syntax and source mappings were checked. `previous-audit.py` preserves the previous trial reader and `audit-adaptation.patch` shows the direct adaptation. The reader requires the same stable Rust 1.98.1 / LLVM 22.1.8 versions and flags; unexpected toolchain drift must be reviewed, not silently accepted.

## Required checks

1. Final workflow metadata, direct checkout head and successful optional-PGO preparation. Preserve each actual step outcome. Expected validator/build/identity successes do not imply a green workflow.
2. All 73 bundle, 69 PGO and six pipeline hashes against the dispatched source; unchanged integration/TLS/backport inputs. Verify embedded and uploaded PGO manifests plus `latest.json` agree.
3. Ten successful PGO command receipts and six actual workspace compiler vectors. Preserve explicit x86-64 GNU Linux, O3, ThinLTO, one codegen unit, PIC/unwind, no Ohm experimental defaults, no compiler wrappers, fresh generate/use outputs and profile-use native-static-libs. Record compiler/profiler hashes as producer identities; their binaries are absent from the upload.
4. Original generated-only corpus: 12 fixtures, seed 87214835846213, two iterations, minimal/full handlers and 288 cases per phase. Inputs, raw/merged profiles and command logs must match their recorded hashes; generate/use callback records must match exactly. Recompute fresh profile function/block/count totals from the saved profiler text.
5. Shipped `python/build/lib/libexpat.a` equals this run's exact profile-use archive hash; embedded build notice equals the uploaded bundle manifest. Verify license bytes, `PYTHON.json` static Expat route and ElementTree's capsule route, unchanged cleanup-backport source hashes and native TLS wrapping.
6. Host ELF inspection: no dynamic libexpat dependency, maximum referenced glibc version 2.17, expected unversioned weak TLS wrapper in executable and libpython. The workflow's actual container log must independently show glibc 2.17, Oriole identity and 1,024 threaded parses. Saved ELF inspection alone is not execution evidence.
7. Complete validator success and 22 custom tests / five skips. Preserve strict host and old-glibc failures exactly as below. Any different failure, missing gate, cancellation or changed counts should stop the expected-result audit for review.

## Strict failures remain failures

The expected methods are `test.test_pyexpat.BufferTextTest.test1` and `test.test_sax.CDATAHandlerTest.test_handlers`, with the original assertion payloads. Host totals historically contain 802 initial tests and two failures, plus four retry executions repeating those failures: aggregate 806 executions, four failures and 12 skips. Old-glibc totals are 802 tests, two failures and 13 skips, exit 2. These are not four distinct failures, and the terse logs do not support an 802-row exact outcome map. Host resources are `all,-largefile,-audio,-gui`; old-glibc uses defaults.

The prepared audit requires the preserved failure outcome. If results unexpectedly change, investigate instead of rewriting a failing strict gate as successful. This campaign can refresh the selected-source PGO deployment evidence; it does not prove full Expat compatibility, add performance measurements, refresh all platform coverage, or replace sustained fuzz/sanitizer evidence.
