"""Saved-data audit only; never executes the downloaded interpreter or parser."""
import argparse
import hashlib
import json
import re
import shlex
import subprocess
import zipfile
from pathlib import Path

cli = argparse.ArgumentParser(description=__doc__)
cli.add_argument('--root', type=Path, required=True)
cli.add_argument('--released', action='store_true', required=True)
args = cli.parse_args()
ROOT = args.root
SOURCE = Path('/home/dev-user/code/oss/oriole-reference-frame')
EXPECTED = json.loads((Path(__file__).parent / 'expected-source.json').read_text())
HEAD = EXPECTED['head']
assert not (ROOT / 'report.json').exists(), 'Preserve previous audit reports.'
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def read(name):
    return (ROOT / name).read_text()
def data(name):
    return json.loads(read(name))

run = data('run.json')
assert run['head_sha'] == HEAD and run['status'] == 'completed' and run['conclusion'] == 'failure'
assert run['event'] == EXPECTED['event'] and run['id'] == EXPECTED['run_id']
for pins in ('bundle_source_sha256', 'pgo_source_sha256', 'support_sha256'):
    for name, digest in EXPECTED[pins].items():
        assert hashlib.sha256(subprocess.check_output(['git', 'show', HEAD + ':' + name], cwd=SOURCE)).hexdigest() == digest
        assert sha(SOURCE / name) == digest
jobs = data('jobs.json')['jobs']
assert len(jobs) == 1
steps = {step['name']: step['conclusion'] for step in jobs[0]['steps']}
for name in ('Build the distribution validator', 'Build the frozen Oriole bundle', 'Build CPython 3.12.13 with Oriole', 'Verify the installed parser identity'):
    assert steps[name] == 'success'
for name in ('Validate the complete distribution', 'Run the installed interpreter on glibc 2.17'):
    assert steps[name] == 'failure'
artifacts = data('artifacts.json')['artifacts']
for filename, name in (('validation.zip', 'oriole-pbs-validation'), ('distribution.zip', 'oriole-pbs-experimental-distribution')):
    artifact = next(a for a in artifacts if a['name'] == name)
    assert artifact['digest'] == 'sha256:' + sha(ROOT / filename)
    assert artifact['workflow_run']['head_sha'] == HEAD
    with zipfile.ZipFile(ROOT / filename) as archive:
        assert archive.testzip() is None
        for member in archive.infolist():
            if member.is_dir():
                continue
            actual = ROOT / ('validation/' + member.filename if filename == 'validation.zip' else member.filename)
            with archive.open(member) as stream:
                assert hashlib.file_digest(stream, 'sha256').hexdigest() == sha(actual)

bundle = data('validation/oriole-bundle/manifest.json')
for name, expected in bundle['sources'].items():
    assert sha(SOURCE / name) == expected, name
assert bundle['sources'] == EXPECTED['bundle_source_sha256'] and len(bundle['sources']) == 73 and 'pgo' in bundle
baseline_path = Path(__file__).parent / 'expected-source.json'
baseline = EXPECTED['pgo_source_sha256']
overlap = baseline.keys() & bundle['sources'].keys()
assert len(overlap) == 66
assert all(baseline[name] == bundle['sources'][name] for name in overlap)
assert bundle['rustc'].startswith('rustc 1.98.1 (48a229cea 2026-09-01)\n')
assert 'LLVM version: 22.1.8\n' in bundle['rustc']
assert bundle['rustflags'] == '-C relocation-model=pic -C panic=unwind'
assert read('selected/python/licenses/LICENSE.oriole-build.txt') == read('validation/oriole-bundle/manifest.json')
assert sha(ROOT / 'selected/python/build/lib/libexpat.a') == bundle['files']['libexpat.a']
assert sha(ROOT / 'selected/python/licenses/LICENSE.oriole.txt') == bundle['files']['LICENSE.oriole.txt']
distribution = data('distribution-members.json')
assert distribution['sha256'] == sha(ROOT / distribution['archive'])
assert distribution['sha256'] == read('validation/pbs-archive-sha256.txt').split()[0]

pgo = bundle['pgo']['manifest']
remote_run = Path(pgo['run'])
local_run = ROOT / 'validation/oriole-bundle/pgo/runs' / remote_run.name
assert remote_run.name.startswith('run-') and len(list((ROOT / 'validation/oriole-bundle/pgo/runs').iterdir())) == 1
assert sha(local_run / 'manifest.json') == bundle['pgo']['manifest_sha256']
assert json.loads((local_run / 'manifest.json').read_text()) == pgo
latest = data('validation/oriole-bundle/pgo/latest.json')
assert latest == {'manifest': str(remote_run / 'manifest.json'), 'sha256': bundle['pgo']['manifest_sha256']}
assert pgo['status'] == 'passed' and pgo['compared_parses'] == 288
assert pgo['toolchain'] is None and pgo['cargo_args'] == [] and pgo['cargo_config_sha256'] == {}
assert pgo['base_rustflags'] == ['-C', 'relocation-model=pic', '-C', 'panic=unwind']
assert pgo['rustc_version'] == bundle['rustc']
assert 'LLVM version 22.1.8' in pgo['profdata_version']
assert pgo['source_sha256'] == EXPECTED['pgo_source_sha256'] and len(pgo['source_sha256']) == 69
assert pgo['script_sha256'] == EXPECTED['pipeline_sha256'] and len(pgo['script_sha256']) == 6
for name, expected in pgo['source_sha256'].items():
    assert sha(SOURCE / name) == expected == baseline[name]
for name, expected in pgo['script_sha256'].items():
    assert sha(SOURCE / 'tools/pgo' / name) == expected
for name, expected in pgo['inputs_sha256'].items():
    assert sha(local_run / 'inputs' / name) == expected
for name, expected in pgo['profiles_sha256'].items():
    assert sha(local_run / (name if name == 'merged.profdata' else 'raw-profiles/' + name)) == expected
raw_profiles = sorted(name for name in pgo['profiles_sha256'] if name != 'merged.profdata')
assert raw_profiles and {p.name for p in (local_run / 'raw-profiles').iterdir()} == set(raw_profiles)
assert not list(local_run.rglob('*.a')) and not list(local_run.rglob('*.so'))
commands = {c['label']: c for c in pgo['commands']}
assert len(commands) == 10
for c in commands.values():
    assert c['status'] == 'passed' and c['returncode'] == 0 and c['timeout_seconds'] == 1800
    assert sha(local_run / c['log']) == c['log_sha256']
compiler = '/home/runner/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustc'
assert bundle['pgo']['compiler'] == compiler
assert re.fullmatch('[0-9a-f]{64}', pgo['tools_sha256'][compiler])
profiler = '/home/runner/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/bin/llvm-profdata'
assert re.fullmatch('[0-9a-f]{64}', pgo['tools_sha256'][profiler])
assert commands['profile-merge']['argv'] == [profiler, 'merge', '--num-threads=1', '--failure-mode=any', '-o', str(remote_run / 'merged.profdata'), *[str(remote_run / 'raw-profiles' / name) for name in raw_profiles]]
vectors = []
for phase in ('generate', 'use'):
    command = commands['build-' + phase]
    expected_argv = ['/home/runner/.cargo/bin/cargo', 'rustc', '--release', '--locked', '--offline', '--target', 'x86_64-unknown-linux-gnu', '-p', 'oriole_expat', '--lib', '--crate-type', 'cdylib,staticlib', '--verbose']
    if phase == 'use':
        expected_argv += ['--', '--print=native-static-libs']
    assert command['argv'] == expected_argv
    environment = command['environment']
    assert environment['RUSTC'] == compiler and environment['RUSTC_WRAPPER'] == environment['RUSTC_WORKSPACE_WRAPPER'] == ''
    assert environment['CARGO_INCREMENTAL'] == '0' and environment['RUSTUP_AUTO_INSTALL'] == '0'
    assert environment['CARGO_TARGET_DIR'] == '/home/runner/work/_temp/oriole-bundle/pgo/targets/' + phase
    profile_options = [f'profile-generate={remote_run / "raw-profiles"}'] if phase == 'generate' else [f'profile-use={remote_run / "merged.profdata"}', 'llvm-args=-pgo-warn-missing-function']
    assert environment['CARGO_ENCODED_RUSTFLAGS'].split(chr(31)) == pgo['base_rustflags'] + ['-C' + x for x in profile_options]
    for line in (local_run / command['log']).read_text().splitlines():
        if 'Running `' not in line or '--crate-name ' not in line:
            continue
        args = shlex.split(line.split('Running `')[1].rsplit('`', 1)[0])
        name = args[args.index('--crate-name') + 1]
        if name not in ('oriole_storage', 'oriole', 'oriole_expat'):
            continue
        assert args[0] == compiler and args[args.index('--target') + 1] == 'x86_64-unknown-linux-gnu'
        assert not any(x.startswith('-Z') for x in args)
        codegen = [args[i+1] if a == '-C' else a[2:] for i,a in enumerate(args) if a.startswith('-C')]
        checked = [a for a in codegen if not a.startswith(('metadata=', 'extra-filename='))]
        assert checked == ['opt-level=3', 'lto=thin' if name == 'oriole_expat' else 'linker-plugin-lto', 'codegen-units=1', 'strip=debuginfo', 'relocation-model=pic', 'panic=unwind', *profile_options]
        kinds = [args[i+1] for i,a in enumerate(args) if a == '--crate-type']
        assert kinds == (['cdylib', 'staticlib'] if name == 'oriole_expat' else ['lib'])
        assert ('--print=native-static-libs' in args) == (name == 'oriole_expat' and phase == 'use')
        vectors.append({'phase': phase, 'crate': name, 'argv': args, 'codegen': codegen})
assert len(vectors) == 6
assert len({(v['phase'], v['crate']) for v in vectors}) == 6
use_log = (local_run / commands['build-use']['log']).read_text()
assert not re.search(r'warning(?:\[|:)|hash mismatch|counter mismatch|no profile data', use_log, re.IGNORECASE)
native = re.findall(r'native-static-libs: *([^\n]+)', use_log)[-1].split()
assert native == pgo['native_static_libraries'] == ['-lgcc_s', '-lutil', '-lrt', '-lpthread', '-lm', '-ldl', '-lc']
assert bundle['command'] == commands['build-use']['argv']
assert bundle['files']['libexpat.a'] == pgo['libraries_sha256']['use/liboriole_expat.a']
inputs = json.loads((local_run / 'inputs/manifest.json').read_text())
assert inputs['seed'] == 87214835846213 and inputs['iterations'] == 2
assert inputs['handlers'] == ['minimal', 'full'] and len(inputs['rows']) == 12
assert sum(row['bytes'] for row in inputs['rows']) == 1325736
expected_cases = {(row['name'], ns, chunk, handler, iteration) for row in inputs['rows'] for ns in row['namespaces'] for chunk in row['chunks'] for handler in inputs['handlers'] for iteration in range(inputs['iterations'])}
reports = {}
for phase in ('generate', 'use'):
    report_path = local_run / (phase + '-training.json')
    assert sha(report_path) == pgo['training_sha256'][phase]
    result = json.loads(report_path.read_text())
    expected_library = {'path': str(remote_run / phase / 'liboriole_expat.so'), 'sha256': pgo['libraries_sha256'][phase + '/liboriole_expat.so']}
    assert result['status'] == 'passed' and result['xml_parse_origin'] == expected_library
    assert result['library_sha256'] == expected_library['sha256'] and result['inputs_sha256'] == sha(local_run / 'inputs/manifest.json')
    assert result['script_sha256'] == pgo['script_sha256']['train.py']
    assert result['profile_file_environment'] == (str(remote_run / 'raw-profiles/oriole-%m-%p.profraw') if phase == 'generate' else None)
    actual = {(r['fixture'],r['namespaces'],r['chunk'],r['handlers'],r['iteration']) for r in result['rows']}
    assert actual == expected_cases and len(result['rows']) == 288
    assert all(r['status'] == 1 and r['error'] == 0 and not r['callback_exceptions'] for r in result['rows'])
    assert commands[phase]['argv'][:3] == ['/usr/bin/python3', '-I', '-S']
    reports[phase] = result
assert reports['generate']['rows'] == reports['use']['rows']
show = (local_run / commands['profile-show']['log']).read_text()
counts = [list(map(int, part.split(', '))) for part in re.findall(r'Block counts: \[([^]]*)\]', show)]
profile_functions = len(counts)
profile_blocks = sum(map(len, counts))
profile_total = sum(map(sum, counts))
assert profile_functions > 0 and profile_blocks > 0 and profile_total > 0
assert f'Total functions: {profile_functions}' in show and f'Total number of blocks: {profile_blocks}' in show and f'Total count: {profile_total}' in show
pgo_review = {'run': str(remote_run), 'source_pins': 69, 'pipeline_pins': 6, 'successful_commands': 10, 'actual_compiler_vectors': 6, 'generated_parses_per_phase': 288, 'unique_generated_conditions_per_phase': len(expected_cases), 'generated_callbacks_identical': True, 'generated_input_bytes': 1325736, 'profile_functions': profile_functions, 'profile_blocks': profile_blocks, 'profile_total_count': profile_total, 'native_static_libraries': native, 'profile_hashes': pgo['profiles_sha256'], 'recorded_tool_hashes': pgo['tools_sha256'], 'exact_shipped_static_hash': pgo['libraries_sha256']['use/liboriole_expat.a'], 'limitation': 'Tool executables and non-shipped instrumented/shared libraries are excluded from the uploaded evidence; their identities are the producer-verified hashes and training dladdr origins retained in the API-digest-verified artifact. The shipped static archive and profile/input/log bytes were independently read back.'}
tls = data('validation/pbs-tls-probe/manifest.json')
assert tls['rustc'] == bundle['rustc'] and tls['threads_per_binary'] == 32
for name, expected in tls['sources'].items():
    assert sha(SOURCE / 'integration/python-build-standalone' / name) == expected
elf = {}
for name in ('python', 'libpython'):
    symbols = read(name + '-dynsym.txt')
    versions = sorted(set(re.findall(r'@GLIBC_([0-9.]+)', symbols)), key=lambda v: tuple(map(int, v.split('.'))))
    assert versions[-1] == '2.17'
    hooks = [s for s in symbols.splitlines() if 'thread_atexit' in s]
    assert len(hooks) == 1 and 'WEAK' in hooks[0] and 'UND __wrap___cxa_thread_atexit_impl' in hooks[0] and '@' not in hooks[0]
    dynamic = read(name + '-dynamic.txt')
    assert 'libexpat' not in dynamic
    elf[name] = {'maximum_glibc_symbol_version': versions[-1], 'tls_hook': hooks[0].strip(), 'needed': re.findall(r'Shared library: \[([^]]+)\]', dynamic)}
host = read('validation/pbs-xml-tests.log')
glibc = read('validation/pbs-glibc217-tests.log')
expected_assertions = ["AssertionError: Lists differ: ['<a>', '1', '<b>', '2\\n3', '<c>', '4\\n5'] != ['<a>', '1', '<b>', '2', '\\n', '3', '<c>', '4\\n5']", "AssertionError: 'Parseable character data' != '\\nParseable character data\\n'"]
assert set(line for line in host.splitlines() if line.startswith('AssertionError:')) == set(expected_assertions)
assert set(line for line in glibc.splitlines() if line.startswith('AssertionError:')) == set(expected_assertions)
assert 'Total tests: run=806 failures=4 skipped=12' in host
assert 'Total test files: run=8/6 failed=2 rerun=2' in host
assert 'Total tests: run=802 failures=2 skipped=13' in glibc
thread_result = next(json.loads(line) for line in glibc.splitlines() if line.startswith('{"glibc":'))
assert thread_result == {'glibc': ['glibc', '2.17'], 'expat': 'oriole_compat_2.8.4', 'threaded_parses': 1024}
assert glibc.index('"threaded_parses": 1024') < glibc.index('AssertionError:')
assert 'returned non-zero exit status 2' in glibc
assert 'Ran 22 tests' in read('validation/pbs-custom-tests.log') and 'OK (skipped=5)' in read('validation/pbs-custom-tests.log')
assert read('validation/pbs-validate.log').strip().endswith(distribution['archive'] + ' OK')
workflow = read('workflow.log')
checkout = HEAD
assert HEAD in workflow and run['event'] == 'workflow_dispatch'
assert steps['Prepare optional PGO tools'] == 'success'
build_log = read('validation/pbs-build.log')
for expected in ('fd679a16f36304444af11953ad276d4493f2044f904a39b8fdf028c6f7def8a0', '1c3cf2ee6dfa568cf833742ad786880f4816042705689a116a4f308b7a9d95f2', '-Wl,--wrap=__cxa_thread_atexit_impl'):
    assert expected in build_log
metadata = data('selected/python/PYTHON.json')
expat_link = metadata['build_info']['extensions']['pyexpat'][0]
assert {'name': 'expat', 'path_static': 'build/lib/libexpat.a'} in expat_link['links']
assert expat_link['license_paths'] == ['licenses/LICENSE.oriole.txt']
assert metadata['build_info']['extensions']['_elementtree'][0]['links'] == []
assert "['-u', 'all,-largefile,-audio,-gui']" in read('selected/python/build/run_tests.py')
assert "'-w'," in read('selected/python/build/run_tests.py')
for name in ('pbs.yml', 'test-old-glibc.py'):
    path = SOURCE / ('.github/workflows/pbs.yml' if name == 'pbs.yml' else 'integration/python-build-standalone/test-old-glibc.py')
    (ROOT / name).write_bytes(path.read_bytes())

report = {
    'status': 'review passed; workflow remains failed on the two preserved XML assertions',
    'scope': 'Saved hashes, compiler-command review, archives and saved readelf output only. Root dispatched workflow 34653585245; this auditor performs no download, compiler, container or downloaded interpreter/parser execution.',
    'run': {'id': run['id'], 'url': run['html_url'], 'head': HEAD, 'checkout_commit': checkout, 'event': run['event'], 'created_at': run['created_at'], 'updated_at': run['updated_at'], 'conclusion': run['conclusion'], 'steps': steps},
    'source': {'bundle_source_pins_verified_against_head': len(bundle['sources']), 'expected_source_record_sha256': sha(baseline_path), 'bundle_PGO_source_overlap_equal': len(overlap), 'scope_note': 'The 73 bundle inputs overlap 66 of the 69 PGO inputs and include licenses/backport provenance and both builders. All 69 PGO pins match dispatched reference-frame head 4064b065 and measured 0f66d54 source. C integration fixtures are outside these Rust build inventories. The source delta from prior stable PBS has four runtime files and five test modules; no workflow/PBS/PGO tool or public-header change.'},
    'pgo_verification': pgo_review,
    'compiler': {'rustc': bundle['rustc'], 'normal_release': False, 'pgo': True, 'vectors': vectors, 'recorded_tools': pgo['tools_sha256'], 'limitation': 'Compiler/profiler executable hashes are recorded and source-verified by the pipeline; those executable binaries were not included in the upload.'},
    'distribution': {'archive': distribution['archive'], 'sha256': distribution['sha256'], 'size': (ROOT / distribution['archive']).stat().st_size, 'member_count': len(distribution['members']), 'libexpat_a_sha256': bundle['files']['libexpat.a'], 'bundle_manifest_sha256': sha(ROOT / 'validation/oriole-bundle/manifest.json'), 'embedded_manifest_identical': True, 'notices_identical': True, 'consumer_cleanup_patch': bundle['consumer_adaptation'], 'pyexpat_link': expat_link, 'elf': elf},
    'outcomes': {'distribution_validator': 'passed', 'custom_suite': {'run': 22, 'passed': 17, 'skipped': 5}, 'host_xml': {'initial_run': 802, 'initial_failures': 2, 'reported_skipped': 12, 'builtin_retry_methods': 4, 'builtin_retry_failures': 2, 'aggregate_run': 806, 'aggregate_failures': 4, 'files': 6}, 'glibc217': {'thread_probe': thread_result, 'xml_run': 802, 'xml_failures': 2, 'reported_skipped': 13, 'files': 6, 'failure_cause': 'Strict XML subprocess exited 2 after successful glibc identity and threaded parse probe.'}, 'failure_methods': ['test.test_pyexpat.BufferTextTest.test1', 'test.test_sax.CDATAHandlerTest.test_handlers'], 'assertions': expected_assertions, 'skip_scope': 'Host distribution harness enables all resources except largefile/audio/gui and automatic verbose retries; old-glibc script uses direct -I -m test with default resources. Aggregate logs do not expose all skipped or expected-failure method IDs; no 802-entry outcome map was inferred.'},
    'conclusion': 'The actual stable PGO selected reference-frame runtime linked and ran on glibc 2.17 with 1024 threaded parses. Its shipped static archive exactly matches the verified profile-use archive. No new glibc/linkage or strict XML regression is evident against the normal PBS baseline; both strict XML gates retain the same two callback assertions. This is not an all-green XML result or a new performance measurement.',
    'artifact_origins': artifacts,
    'binary_publication_exclusions': ['distribution.zip', distribution['archive'], 'selected/python/build/lib/libexpat.a', 'selected/python/install/bin/python3.12', 'selected/python/install/lib/libpython3.12.so.1.0'],
}
(ROOT / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print('report', sha(ROOT / 'report.json'))
print('source pins', len(bundle['sources']), 'compiler vectors', len(vectors), 'archive', distribution['sha256'])
