"""Independent compact PBS archive readback; saved bytes only."""
from pathlib import Path
import gzip,hashlib,io,json,os,tarfile,zipfile
assert os.sched_getaffinity(0)=={6}
OUT=Path(__file__).parent
PACKAGE=Path('/tmp/oriole-reference-frame-pbs-package')
ROOT=Path('/tmp/oriole-reference-frame-pbs-results')
def read(path):return json.loads(Path(path).read_bytes())
def digest(data):return hashlib.sha256(data).hexdigest()
def sha(path):return digest(Path(path).read_bytes())
files=read(PACKAGE/'files.json')['files']
assert {p.name for p in PACKAGE.iterdir()}=={'files.json',*[r['name'] for r in files]}
assert len(files)==6
for row in files:
    data=(PACKAGE/row['name']).read_bytes()
    assert len(data)==row['bytes'] and digest(data)==row['sha256']
index=read(PACKAGE/'archive-members.json')
assert sha(PACKAGE/index['archive'])==index['sha256']
rows={r['name']:r for r in index['members']}
assert len(rows)==len(index['members']) and list(rows)==sorted(rows)
members={}
with tarfile.open(PACKAGE/index['archive'],'r:gz') as archive:
    for item in archive:
        assert item.isfile() and item.name not in members and not item.name.startswith('/') and '..' not in Path(item.name).parts
        assert item.mode==0o644 and item.uid==item.gid==item.mtime==0
        data=archive.extractfile(item).read();row=rows[item.name]
        assert len(data)==row['bytes'] and digest(data)==row['sha256']
        assert not data.startswith((b'\x7fELF',b'!<arch>\n'))
        assert item.name!='distribution.zip' and not item.name.endswith(('.so','.a','.tar.zst'))
        members[item.name]=data
assert list(members)==list(rows)
archive_origins={}
for name,row in rows.items():
    origin=row['origin']
    if 'path' in origin:
        original=Path(origin['path']).read_bytes()
        assert len(original)==origin['source_bytes'] and digest(original)==origin['source_sha256']
        if 'transformation' in origin:
            assert origin['transformation']=='gzip level 3, mtime 0'
            assert gzip.decompress(members[name])==original
        else: assert members[name]==original
    elif 'archive' in origin:
        archive_origins.setdefault(origin['archive'],[]).append((name,origin))
    else: assert name=='validation-members.json' and origin['derived_from']=='validation.zip'
for path,items in archive_origins.items():
    with Path(path).open('rb') as stream: pin=hashlib.file_digest(stream,'sha256').hexdigest()
    assert all(origin['archive_sha256']==pin for _,origin in items)
    wanted={origin['member']:(name,origin) for name,origin in items};seen=set()
    with tarfile.open(path,'r:') as archive:
        for item in archive:
            if item.name not in wanted:continue
            name,origin=wanted[item.name];data=archive.extractfile(item).read()
            assert data==members[name] and digest(data)==origin['source_sha256']
            seen.add(item.name)
    assert seen==set(wanted)
raw=json.loads(members['validation-members.json'])
with zipfile.ZipFile(io.BytesIO(members['validation.zip'])) as archive:
    assert archive.testzip() is None and len(archive.infolist())==42
    assert archive.namelist()==[r['name'] for r in raw]
    for row in raw:
        data=archive.read(row['name'])
        assert len(data)==row['bytes'] and digest(data)==row['sha256']
        assert data==(ROOT/'validation'/row['name']).read_bytes()
        assert not data.startswith((b'\x7fELF',b'!<arch>\n'))
review=json.loads(members['independent-review.json']);report=json.loads(members['report.json'])
assert digest(members['report.json'])==review['report_sha256']=='df565b6fecfbae6045a7b7653fec180047f412b1016fbff942ad50af525cf6e7'
assert report['distribution']['sha256']=='30df6e4693682f14ff639a5752f6453a7e6c5edc7c05e6a5eb78c743add79090'
assert report['run']['conclusion']=='failure' and review['outcomes']==report['outcomes']
assert report['outcomes']['failure_methods']==['test.test_pyexpat.BufferTextTest.test1','test.test_sax.CDATAHandlerTest.test_handlers']
assert len(review['source_sha256'])==87
for name,pin in review['source_sha256'].items():assert digest(members['source/'+name])==pin
assert len([n for n in members if n.startswith('source/')])==index['source_snapshot_files']==90
selected={n.removeprefix('selected/'):data for n,data in members.items() if n.startswith('selected/')}
assert set(selected)==set(index['selected_nonbinary_distribution_members']) and len(selected)==25
assert len([n for n in selected if Path(n).name=='COPYING'])==2
for name,row in review['distribution_selected_members'].items():
    if row['compiled_binary']:
        assert name not in selected
    else: assert digest(selected[name])==row['sha256']
assert selected['python/licenses/LICENSE.oriole-build.txt']==(ROOT/'validation/oriole-bundle/manifest.json').read_bytes()
assert 'python/licenses/LICENSE.cpython.txt' in selected
for name in ['README.md','report.json','independent-review.json','package.py']:
    assert (PACKAGE/name).read_bytes()==members[name]
text=members['README.md'].decode()
for phrase in ['workflow remains failed','47,997,060-byte','87 files','69 PGO source pins','802 initial tests, 2 failures','806 executions and four failures','run-clljfotz','641 functions, 17,719 blocks','1,024 threaded parses','performance within 10% of Expat']:
    assert phrase in text,phrase
assert 'no performance measurements' in text
result={
 'status':'passed saved archive readback','scope':'All final files/index/archive origins, nested ZIP bytes, source snapshots and selected nonbinary distribution data checked. No target/compiler/container execution.',
 'archive_members':len(members),'validation_zip_members':42,'source_snapshot_files':90,'selected_nonbinary_distribution_members':25,
 'archive_sha256':index['sha256'],'report_sha256':review['report_sha256'],'independent_review_sha256':digest(members['independent-review.json']),
 'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in PACKAGE.iterdir()},
 'workflow_status_preserved':'failure: same two strict callback methods','distribution_and_compiled_binaries_excluded':True,
 'limitations':'Compact package readback verifies retained data; excluded binary execution and code generation remain bounded by the original remote records and separately completed binary/archive readback.'}
path=OUT/'package-readback.json';assert not path.exists()
path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':result['status'],'receipt_sha256':sha(path),'archive_members':len(members),'archive_sha256':index['sha256']},indent=2))
