"""Independent saved PBS source/profile/outcome/distribution readback.

Reuses the preceding stable PBS root reviewer, extending its direct data checks.
No downloaded executable, parser, compiler, container or workflow is launched.
"""
from pathlib import Path
import collections,hashlib,json,os,re,shlex,subprocess,tarfile,zipfile
assert os.sched_getaffinity(0)=={6}
OUT=Path(__file__).parent
ROOT=Path('/tmp/oriole-reference-frame-pbs-results')
SOURCE=Path('/home/dev-user/code/oss/oriole-reference-frame')
PREP=Path('/tmp/oriole-reference-frame-pbs-review-prep')
def read(path): return json.loads(Path(path).read_bytes())
def sha(path):
    with Path(path).open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
def hashed(data): return hashlib.sha256(data).hexdigest()
REPORT_HASH='df565b6fecfbae6045a7b7653fec180047f412b1016fbff942ad50af525cf6e7'
assert sha(ROOT/'report.json')==REPORT_HASH
report=read(ROOT/'report.json'); expected=read(PREP/'expected-source.json')
head=expected['head']
assert head=='4064b0653534aff690c0e0f395a6b3b48da878fc'
assert expected['run_id']==34653585245
api=read(ROOT/'run.json'); jobs=read(ROOT/'jobs.json')['jobs']
assert api['id']==expected['run_id'] and api['head_sha']==head
assert api['event']=='workflow_dispatch' and api['status']=='completed' and api['conclusion']=='failure'
assert len(jobs)==1
steps={row['name']:row['conclusion'] for row in jobs[0]['steps']}
assert steps==report['run']['steps']
assert {k for k,v in steps.items() if v=='failure'}=={'Validate the complete distribution','Run the installed interpreter on glibc 2.17'}
for name in ['Prepare optional PGO tools','Build the frozen Oriole bundle','Build CPython 3.12.13 with Oriole','Verify the installed parser identity']:
    assert steps[name]=='success'
source_pins={}
for key in ['bundle_source_sha256','pgo_source_sha256','support_sha256']:
    for name,pin in expected[key].items():
        if name in source_pins: assert source_pins[name]==pin
        source_pins[name]=pin
for name,pin in expected['pipeline_sha256'].items():
    name='tools/pgo/'+name
    if name in source_pins: assert source_pins[name]==pin
    source_pins[name]=pin
for name,pin in source_pins.items():
    assert sha(SOURCE/name)==pin
    assert hashed(subprocess.check_output(['git','show',head+':'+name],cwd=SOURCE))==pin
selected=read('/tmp/oriole-reference-frame-pgo-study/source.json')['source_sha256']
assert len(selected)==72
assert all(selected[name]==pin for name,pin in expected['pgo_source_sha256'].items())
assert [len(expected[k]) for k in ['bundle_source_sha256','pgo_source_sha256','pipeline_sha256']]==[73,69,6]
bundle=ROOT/'validation/oriole-bundle'
outer=read(bundle/'manifest.json')
run=bundle/'pgo/runs/run-clljfotz'
manifest=read(run/'manifest.json')
assert outer['sources']==expected['bundle_source_sha256']
assert manifest['source_sha256']==expected['pgo_source_sha256'] and manifest['script_sha256']==expected['pipeline_sha256']
assert outer['pgo']['manifest']==manifest and outer['pgo']['manifest_sha256']==sha(run/'manifest.json')
assert read(bundle/'pgo/latest.json')=={'manifest':manifest['run']+'/manifest.json','sha256':sha(run/'manifest.json')}
assert manifest['run']=='/home/runner/work/_temp/oriole-bundle/pgo/runs/run-clljfotz'
assert (ROOT/'selected/python/licenses/LICENSE.oriole-build.txt').read_bytes()==(bundle/'manifest.json').read_bytes()
assert sha(ROOT/'selected/python/licenses/LICENSE.oriole.txt')==outer['files']['LICENSE.oriole.txt']
assert len(manifest['commands'])==10
commands={c['label']:c for c in manifest['commands']}
for c in commands.values():
    assert c['returncode']==0 and c['status']=='passed' and c['timeout_seconds']==1800
    assert sha(run/c['log'])==c['log_sha256']
for name,pin in manifest['profiles_sha256'].items():
    assert sha(run/name if name=='merged.profdata' else run/'raw-profiles'/name)==pin
for name,pin in manifest['inputs_sha256'].items(): assert sha(run/'inputs'/name)==pin
for phase,pin in manifest['training_sha256'].items(): assert sha(run/(phase+'-training.json'))==pin
static_hash=sha(ROOT/'selected/python/build/lib/libexpat.a')
assert static_hash==manifest['libraries_sha256']['use/liboriole_expat.a']==outer['files']['libexpat.a']==report['distribution']['libexpat_a_sha256']
assert static_hash=='b71dfdb0969de8c529e64a2c04b1e4f2243995afa10e16abf7838272e00e360e'
inputs=read(run/'inputs/manifest.json')
expected_cases={(r['name'],ns,chunk,handler,iteration) for r in inputs['rows'] for ns in r['namespaces'] for chunk in r['chunks'] for handler in inputs['handlers'] for iteration in range(inputs['iterations'])}
assert len(inputs['rows'])==12 and inputs['seed']==87214835846213 and inputs['iterations']==2
assert len(expected_cases)==288
phases={phase:read(run/(phase+'-training.json')) for phase in ['generate','use']}
for phase,result in phases.items():
    assert result['status']=='passed'
    assert len(result['rows'])==288 and {(r['fixture'],r['namespaces'],r['chunk'],r['handlers'],r['iteration']) for r in result['rows']}==expected_cases
    assert all(r['status']==1 and r['error']==0 and not r['callback_exceptions'] for r in result['rows'])
    assert result['xml_parse_origin']=={'path':manifest['run']+'/'+phase+'/liboriole_expat.so','sha256':manifest['libraries_sha256'][phase+'/liboriole_expat.so']}
assert phases['generate']['rows']==phases['use']['rows']
vectors=[]
for phase in ['generate','use']:
    for line in (run/commands['build-'+phase]['log']).read_text().splitlines():
        if 'Running `' not in line or '--crate-name ' not in line: continue
        argv=shlex.split(line.split('Running `')[1].rsplit('`',1)[0]); crate=argv[argv.index('--crate-name')+1]
        if crate not in ('oriole_storage','oriole','oriole_expat'): continue
        codegen=[argv[i+1] if a=='-C' else a[2:] for i,a in enumerate(argv) if a.startswith('-C')]
        vectors.append({'phase':phase,'crate':crate,'argv':argv,'codegen':codegen})
assert len(vectors)==6 and vectors==report['compiler']['vectors']
for row in vectors:
    flags=row['codegen']
    assert 'opt-level=3' in flags and 'codegen-units=1' in flags and 'relocation-model=pic' in flags and 'panic=unwind' in flags
    assert ('lto=thin' if row['crate']=='oriole_expat' else 'linker-plugin-lto') in flags
    assert not any(a.startswith('-Z') for a in row['argv'])
profile=(run/commands['profile-show']['log']).read_text()
blocks=[list(map(int,s.split(', '))) for s in re.findall(r'Block counts: \[([^]]*)\]',profile)]
assert (len(blocks),sum(map(len,blocks)),sum(map(sum,blocks)))==(641,17719,837998455)
assert (report['pgo_verification']['profile_functions'],report['pgo_verification']['profile_blocks'],report['pgo_verification']['profile_total_count'])==(641,17719,837998455)
artifacts=read(ROOT/'artifacts.json')['artifacts']
assert len(artifacts)==2 and artifacts==report['artifact_origins']
zip_members={}
for artifact in artifacts:
    filename={'oriole-pbs-validation':'validation.zip','oriole-pbs-experimental-distribution':'distribution.zip'}[artifact['name']]
    assert sha(ROOT/filename)==artifact['digest'].removeprefix('sha256:')
    assert artifact['workflow_run']['head_sha']==head and artifact['workflow_run']['id']==34653585245
    with zipfile.ZipFile(ROOT/filename) as archive:
        assert archive.testzip() is None
        for item in archive.infolist():
            assert not item.is_dir() and not item.filename.startswith('/') and '..' not in Path(item.filename).parts
            path=ROOT/'validation'/item.filename if filename=='validation.zip' else ROOT/item.filename
            data=archive.read(item.filename); assert hashed(data)==sha(path)
            zip_members[filename+'/'+item.filename]={'bytes':len(data),'sha256':hashed(data)}
assert sum(k.startswith('validation.zip/') for k in zip_members)==42
inventory=read(ROOT/'distribution-members.json')
zst=ROOT/inventory['archive']
assert sha(zst)==inventory['sha256']==report['distribution']['sha256']=='30df6e4693682f14ff639a5752f6453a7e6c5edc7c05e6a5eb78c743add79090'
# Host decompression is data inspection, not downloaded-code execution. Bind the
# saved uncompressed tar before independently selecting notice/source members.
command=['zstd','--decompress','--stdout',str(zst)]
with subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE) as process:
    tar_hash=hashlib.file_digest(process.stdout,'sha256').hexdigest()
    stderr=process.stderr.read(); assert process.wait()==0 and not stderr
assert tar_hash==sha(ROOT/'distribution.tar')
recorded={r['name']:r for r in inventory['members']}
assert len(recorded)==len(inventory['members'])==6546
selected_members={}
with tarfile.open(ROOT/'distribution.tar','r:') as archive:
    seen=[]
    for item in archive:
        seen.append(item.name)
        record=recorded[item.name]
        assert item.size==record['size'] and item.linkname==record['linkname'] and item.type.decode()==record['type']
        select=('sha256' in record or item.name.startswith('python/licenses/') and item.isfile())
        if not select: continue
        data=archive.extractfile(item).read(); pin=hashed(data)
        if 'sha256' in record:
            assert pin==record['sha256'] and pin==sha(ROOT/'selected'/item.name)
        selected_members[item.name]={'bytes':len(data),'sha256':pin,'compiled_binary':data.startswith((b'\x7fELF',b'!<arch>\n'))}
    assert len(seen)==len(recorded) and len(set(seen))==len(seen)
assert selected_members['python/build/lib/libexpat.a']['sha256']==static_hash
for name in ['python','libpython']:
    symbols=(ROOT/(name+'-dynsym.txt')).read_text();dynamic=(ROOT/(name+'-dynamic.txt')).read_text()
    versions=sorted(set(re.findall(r'@GLIBC_([0-9.]+)',symbols)),key=lambda s:tuple(map(int,s.split('.'))))
    assert versions[-1]=='2.17' and 'libexpat' not in dynamic
    hooks=[s.strip() for s in symbols.splitlines() if 'thread_atexit' in s]
    assert len(hooks)==1 and 'WEAK' in hooks[0] and 'UND __wrap___cxa_thread_atexit_impl' in hooks[0] and '@' not in hooks[0]
    assert hooks[0]==report['distribution']['elf'][name]['tls_hook']
host=(ROOT/'validation/pbs-xml-tests.log').read_text();glibc=(ROOT/'validation/pbs-glibc217-tests.log').read_text()
assertions=report['outcomes']['assertions']
assert collections.Counter(re.findall(r'^AssertionError:.*$',host,re.M))==collections.Counter({s:2 for s in assertions})
assert collections.Counter(re.findall(r'^AssertionError:.*$',glibc,re.M))==collections.Counter({s:1 for s in assertions})
methods=re.findall(r'^FAIL: \w+ \(([^)]+)\)',host,re.M)
assert methods==report['outcomes']['failure_methods']==['test.test_pyexpat.BufferTextTest.test1','test.test_sax.CDATAHandlerTest.test_handlers']
assert 'test_pyexpat.py", line 401, in test1' in glibc and 'test_sax.py", line 1554, in test_handlers' in glibc
assert re.findall(r'^Total tests:.*$',host,re.M)==['Total tests: run=806 failures=4 skipped=12']
assert re.findall(r'^Total tests:.*$',glibc,re.M)==['Total tests: run=802 failures=2 skipped=13']
assert 'returned non-zero exit status 2' in glibc
probe=next(json.loads(s) for s in glibc.splitlines() if s.startswith('{"glibc":'))
assert probe==report['outcomes']['glibc217']['thread_probe']=={'glibc':['glibc','2.17'],'expat':'oriole_compat_2.8.4','threaded_parses':1024}
custom=(ROOT/'validation/pbs-custom-tests.log').read_text()
assert 'Ran 22 tests' in custom and 'OK (skipped=5)' in custom
assert (ROOT/'validation/pbs-validate.log').read_text().strip().endswith(inventory['archive']+' OK')
assert sha(ROOT/'report.json')==REPORT_HASH
receipt={
 'status':'passed saved-record review; remote workflow retains two strict XML failures',
 'scope':'Independent source/profile/training/compiler/outcome/API ZIP/distribution-data readback. Host git and zstd only; no compiler/parser/container/downloaded target execution.',
 'report_sha256':REPORT_HASH,'reader_sha256':sha(__file__),'run':34653585245,'head':head,
 'bundle_source_files':73,'pgo_source_files':69,'pipeline_files':6,'source_files_union':len(source_pins),'source_sha256':source_pins,
 'selected_measured_runtime':'0f66d54ac8418f0a6e628ad18570677a19c9ed45','successful_commands':10,'actual_workspace_compiler_vectors':6,
 'generated_records_per_phase':288,'callbacks_identical':True,'profile_functions':641,'profile_blocks':17719,'profile_total_count':837998455,
 'manifest_sha256':sha(run/'manifest.json'),'bundle_sha256':sha(bundle/'manifest.json'),'shipped_static_sha256':static_hash,
 'distribution_sha256':inventory['sha256'],'distribution_tar_sha256':tar_hash,'decompression_command':command,
 'api_zip_members':zip_members,'distribution_selected_members':selected_members,
 'outcomes':report['outcomes'],
 'limitations':'GitHub API ZIP digests are not a separately checked signature/attestation. Remote tool and non-shipped library identities remain producer hashes. Logs do not expose a complete per-method outcome map. ELF readback is data; glibc/thread execution evidence is the saved remote log. No performance, full compatibility or production-readiness claim.'}
output=OUT/'independent-review.json';assert not output.exists()
output.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':receipt['status'],'source_files':len(source_pins),'distribution_selected_members':len(selected_members),'receipt_sha256':sha(output)},indent=2))
