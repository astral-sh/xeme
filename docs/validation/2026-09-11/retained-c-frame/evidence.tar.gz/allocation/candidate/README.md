# Retained C frame allocation diagnostic

Prepared files only. Run the existing build phase, then each of the twelve cases once. Original 4KiB feeds, fixture bytes, limits and callback expectations are unchanged. Suffix-sharing measurements remain separately pinned selected records.

Inspect every intermediate CALL live-byte and live-block value as well as aggregate peaks and final retained bytes: the candidate parks the frame between feeds and drops it when final input finishes. The parser handle also grows by 256 bytes. These allocation metrics do not measure RSS or elapsed speed.
