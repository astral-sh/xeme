"""Reconstruct completed selected/candidate C allocation records; no targets."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import os

BASE = Path('/tmp/oriole-suffix-element-names-allocation-probe')
CANDIDATE = Path('/tmp/oriole-retained-c-frame-allocation-probe')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs = {}


def pin(path):
    digest = sha(path)
    assert str(path) not in inputs or inputs[str(path)] == digest
    inputs[str(path)] = digest
    return digest


def read(path):
    pin(path)
    return json.loads(Path(path).read_text())


def audit(root):
    plan = read(root / 'plan.json')
    assert plan['status'] == 'prepared_not_executed' and len(plan['cases']) == 12
    for path, digest in plan['pins'].items():
        assert pin(path) == digest
    library, binary = root / 'runs/liboriole_expat.so', root / 'runs/probe'
    assert pin(library) == plan['library']['sha256'] == pin(plan['library']['path'])
    build = read(root / 'runs/build.json')
    assert build['status'] == 'reaped' and build['exit'] == 0 and build['pins_unchanged']
    assert build['plan_sha256'] == pin(root / 'plan.json')
    assert build['binary_sha256'] == pin(binary)
    assert build['log_sha256'] == pin(root / 'runs/build.log')
    assert build['timeout_seconds'] == 120 and 'exception' not in build and 'outer_timeout' not in build
    assert build['argv'] == ['/usr/bin/cc', '-std=c11', '-O1', '-g', '-Wall', '-Wextra', '-Werror',
                             '-I' + plan['header_directory'], str(root / 'probe.c'), str(library),
                             '-Wl,-rpath,' + str(root / 'runs'), '-ldl', '-o', str(binary)]
    rows = []
    for case in plan['cases']:
        receipt = read(root / 'runs' / (case['name'] + '.json'))
        log = root / 'runs' / (case['name'] + '.log')
        assert receipt['status'] == 'reaped' and receipt['exit'] == 0 and receipt['pins_unchanged']
        assert receipt['plan_sha256'] == pin(root / 'plan.json') and receipt['log_sha256'] == pin(log)
        assert receipt['origin_verified'] and receipt['complete_result'] and receipt['successful_result']
        assert 'exception' not in receipt and 'outer_timeout' not in receipt and receipt['timeout_seconds'] == 4
        assert receipt['argv'] == [str(binary), case['input'], case['namespace'], str(case['triplets']),
                                  str(case['expected_starts']), str(case['expected_text_bytes']), str(case['warmup_bytes'])]
        assert pin(case['input']) == case['input_sha256']
        origins, calls, phases, histograms, results = {}, [], {}, {}, []
        for line in log.read_text().splitlines():
            row = line.split('\t')
            if row[0] == 'ORIGIN_API':
                assert len(row) == 3 and row[1] not in origins
                origins[row[1]] = row[2]
            elif row[0] == 'CALL':
                assert len(row) == 12
                calls.append([int(value) for value in row[1:]])
            elif row[0] == 'PHASE':
                assert len(row) == 8 and int(row[1]) not in phases
                phases[int(row[1])] = dict(zip(['mallocs', 'reallocs', 'frees', 'requested', 'peak_bytes', 'peak_blocks'], map(int, row[2:]), strict=True))
            elif row[0] == 'SIZE':
                assert len(row) == 5 and row[2] in ['M', 'R', 'F']
                key = (int(row[1]), row[2], int(row[3]))
                assert key not in histograms and int(row[4]) > 0
                histograms[key] = int(row[4])
            elif row[0] == 'RESULT':
                assert len(row) == 18
                results.append(row)
            else:
                raise AssertionError(('unknown raw record', row))
        assert set(origins) == {'XML_ParserCreate_MM', 'XML_SetUserData', 'XML_SetElementHandler',
                                'XML_SetCharacterDataHandler', 'XML_SetReturnNSTriplet', 'XML_SetHashSalt',
                                'XML_Parse', 'XML_GetErrorCode', 'XML_GetParsingStatus', 'XML_ParserFree'}
        assert all(Path(value).resolve() == library.resolve() for value in origins.values())
        assert receipt['xml_parse_origin'] == origins['XML_Parse']
        assert set(phases) == {0, 1, 2, 3} and len(results) == 1
        assert all(phase in phases and size >= 0 for phase, _, size in histograms)
        assert all(value >= 0 for phase in phases.values() for value in phase.values())
        for phase, totals in phases.items():
            for operation, key in [('M', 'mallocs'), ('R', 'reallocs'), ('F', 'frees')]:
                assert sum(count for (p, op, _), count in histograms.items() if p == phase and op == operation) == totals[key]
            assert sum(size * count for (p, op, size), count in histograms.items() if p == phase and op in ['M', 'R']) == totals['requested']
        length, warmup, offset = Path(case['input']).stat().st_size, case['warmup_bytes'], 0
        previous_starts = previous_ends = 0
        for index, call in enumerate(calls, 1):
            ordinal, phase, count, final, status, error, starts, ends, depth, live, blocks = call
            expected_count = min(4096, length - offset)
            if offset < warmup:
                expected_count = min(expected_count, warmup - offset)
            assert ordinal == index and phase == (1 if offset < warmup else 2)
            assert count == expected_count > 0 and final == int(offset + count == length)
            assert status == 1 and error == 0 and starts >= previous_starts and ends >= previous_ends
            assert depth == starts - ends >= 0 and live >= 0 and blocks >= 0
            assert phases[phase]['peak_bytes'] >= live and phases[phase]['peak_blocks'] >= blocks
            previous_starts, previous_ends = starts, ends
            offset += count
        assert offset == length and calls
        result = results[0]
        assert result[1:4] == ['1', '0', '2']
        callbacks = dict(zip(['starts', 'ends', 'depth', 'text_callbacks', 'text_bytes', 'count'], map(int, result[4:10]), strict=True))
        callbacks['hash'] = result[10]
        allocation = dict(zip(['retained_bytes', 'retained_blocks', 'peak_bytes', 'peak_blocks', 'live_bytes_after_free', 'live_blocks_after_free', 'allocation_failed'], map(int, result[11:]), strict=True))
        assert callbacks == receipt['callbacks'] and allocation == receipt['allocation']
        assert callbacks['starts'] == callbacks['ends'] == case['expected_starts'] and callbacks['depth'] == 0
        assert callbacks['count'] == callbacks['starts'] + callbacks['ends'] + callbacks['text_callbacks']
        assert callbacks['text_bytes'] == case['expected_text_bytes']
        assert calls[-1][6:] == [callbacks['starts'], callbacks['ends'], 0, allocation['retained_bytes'], allocation['retained_blocks']]
        assert allocation['live_bytes_after_free'] == allocation['live_blocks_after_free'] == allocation['allocation_failed'] == 0
        assert allocation['peak_bytes'] == max(row['peak_bytes'] for row in phases.values())
        assert allocation['peak_blocks'] == max(row['peak_blocks'] for row in phases.values())
        assert phases[3]['mallocs'] == phases[3]['reallocs'] == phases[3]['requested'] == 0
        assert phases[3]['peak_bytes'] == allocation['retained_bytes'] and phases[3]['peak_blocks'] == allocation['retained_blocks']
        assert sum(size * count for (phase, kind, size), count in histograms.items() if phase == 3 and kind == 'F') == allocation['retained_bytes']
        row = {'case': case['name'], 'create': phases[0], 'warmup': phases[1], 'parse': phases[2], 'free': phases[3],
               'callbacks': callbacks, 'allocation': allocation,
               'parse_histogram': [{'kind': op, 'size': size, 'count': count} for (phase, op, size), count in sorted(histograms.items()) if phase == 2],
               'all_histograms': [{'phase': phase, 'kind': op, 'size': size, 'count': count} for (phase, op, size), count in sorted(histograms.items())],
               'parse_calls': calls, 'xml_parse_origin': origins['XML_Parse']}
        rows.append(row)
    return plan, rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--released', action='store_true')
    parser.add_argument('--head', required=True)
    args = parser.parse_args()
    assert args.released, 'Only after both complete collections are confirmed reaped'
    assert os.sched_getaffinity(0) == {6}
    out = CANDIDATE / 'comparison.json'
    csv_path = CANDIDATE / 'comparison.csv'
    assert not out.exists() and not csv_path.exists(), 'Retain first attempt; no overwrite'
    selected_plan, selected = audit(BASE)
    candidate_plan, candidate = audit(CANDIDATE)
    assert selected_plan['bounds'] == candidate_plan['bounds']
    assert selected_plan['source_commit'] == 'a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9'
    assert candidate_plan['source_commit'] == args.head
    for name in ['probe.c', 'run.py']:
        assert pin(BASE / name) == pin(CANDIDATE / name)
    compared = candidate_plan['compared_selected_baseline']
    assert compared['source_commit'] == selected_plan['source_commit'] and compared['library'] == selected_plan['library']
    assert compared['plan'] == {'path': str(BASE / 'plan.json'), 'sha256': pin(BASE / 'plan.json')}
    for records in compared['raw_records'].values():
        for path, digest in records.items():
            assert pin(path) == digest
    rows = []
    for selected_case, candidate_case, a, b in zip(selected_plan['cases'], candidate_plan['cases'], selected, candidate, strict=True):
        assert {k: v for k, v in selected_case.items() if k != 'input'} == {k: v for k, v in candidate_case.items() if k != 'input'}
        assert a['case'] == b['case'] and a['callbacks'] == b['callbacks']
        # All feed/callback progression agrees; live bytes/blocks are the diagnostic outcome.
        assert [call[:9] for call in a['parse_calls']] == [call[:9] for call in b['parse_calls']]
        delta = {phase: {key: b[phase][key] - a[phase][key] for key in a[phase]} for phase in ['create', 'warmup', 'parse', 'free', 'allocation']}
        feed_memory = [{'ordinal': left[0], 'final': bool(left[3]), 'selected_live_bytes': left[9], 'candidate_live_bytes': right[9], 'delta_live_bytes': right[9] - left[9], 'selected_live_blocks': left[10], 'candidate_live_blocks': right[10], 'delta_live_blocks': right[10] - left[10]} for left, right in zip(a['parse_calls'], b['parse_calls'], strict=True)]
        rows.append({'case': a['case'], 'selected': a, 'candidate': b, 'candidate_minus_selected': delta, 'every_feed_memory': feed_memory, 'max_intermediate_live_bytes_increase': max((row['delta_live_bytes'] for row in feed_memory if not row['final']), default=None)})
    for path, digest in inputs.items():
        assert sha(path) == digest
    with csv_path.open('x', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['case', 'selected_parse_mallocs', 'candidate_parse_mallocs', 'selected_parse_reallocs', 'candidate_parse_reallocs', 'selected_peak_bytes', 'candidate_peak_bytes', 'selected_retained_bytes', 'candidate_retained_bytes', 'max_intermediate_live_bytes_increase'])
        for row in rows:
            a, b = row['selected'], row['candidate']
            writer.writerow([row['case'], a['parse']['mallocs'], b['parse']['mallocs'], a['parse']['reallocs'], b['parse']['reallocs'], a['allocation']['peak_bytes'], b['allocation']['peak_bytes'], a['allocation']['retained_bytes'], b['allocation']['retained_bytes'], row['max_intermediate_live_bytes_increase']])
    result = {'status': 'passed', 'targets_executed': False, 'cases': len(rows), 'rows': rows,
              'reader_sha256': sha(__file__), 'input_sha256': inputs, 'csv_sha256': sha(csv_path),
              'scope': 'Saved raw C diagnostic reconstruction. Histogram sums, feed progression, status, all ten API origins, callback hashes/balance and final zero live allocations agree. All twelve cases retained.',
              'limitations': ['Tracked peaks are recorded by the inspected allocation tracker, not reconstructed from an address-level trace.', 'Allocation counts and selected live/peak bytes are not elapsed performance or process RSS.', 'Every intermediate feed is compared because parked frame allocations disappear before the final retained-byte measurement. The opaque parser handle grows by 256 bytes (3160 to 3416).' , 'Compare each capacity fixture only with identical baseline bytes: the two fixtures straddle an input-buffer growth boundary.']}
    with out.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': 'passed', 'comparison': str(out), 'sha256': sha(out), 'cases': len(rows)}))
    print(csv_path.read_text(), end='')


if __name__ == '__main__':
    main()
