"""Prepare one directly parameterized saved-build reader; execute no targets."""
from pathlib import Path
import ast,difflib,hashlib
old=Path('/tmp/oriole-suffix-element-names-native-independent-review/build_bindings.py')
new=Path('/tmp/oriole-retained-c-frame-build-bindings.py')
before=old.read_text()
after=before.replace("ROOT = Path('/tmp/oriole-suffix-element-names-pgo-study')\nCONTROL = Path('/tmp/oriole-arena-capacity-bound-pgo-study')\nHEAD = 'a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9'\n", '')
after=after.replace('def verify(pair_sha256):', 'def verify(candidate, control, head, delta, test_count=441):')
after=after.replace('    pins = {}\n', '    ROOT, CONTROL, HEAD = Path(candidate), Path(control), head\n    assert __debug__ and re.fullmatch("[0-9a-f]{40}", HEAD)\n    pins = {}\n',1)
start=after.index("    assert re.fullmatch('[0-9a-f]{64}', pair_sha256)")
end=after.index('    engines = {}',start)
after=after[:start]+'''    preparation = read(ROOT / 'preparation.json')
    assert preparation['status'] == 'prepared_not_executed' and preparation['head'] == HEAD
    assert preparation['source_manifest_sha256'] == pin(ROOT / 'source.json')
    assert preparation['controller_sha256'] == pin(ROOT / 'build_pair.py')
    assert preparation['controller_body_byte_identical'] and not preparation['targets_executed']
    selected_head = read(CONTROL / 'source.json')['candidate_base_commit']
    assert preparation['control_head'] == selected_head
'''+after[end:]
after=after.replace("assert source_manifest['candidate_base_commit'] == 'de859c89577b2982d59b6923d682032f6a7c7800'", "assert source_manifest['candidate_base_commit'] == selected_head")
after=after.replace("assert source_manifest['base_runtime'] == 'de859c89577b2982d59b6923d682032f6a7c7800'", "assert source_manifest['base_runtime'] == selected_head")
after=after.replace("checks['test_count'] == 438", "checks['test_count'] == test_count")
after=after.replace("['crates/oriole/src/lib.rs', 'crates/oriole/tests/multibyte.rs']", 'delta')
needle="            for row in checks['commands']:\n"
after=after.replace(needle,"            assert [row['label'] for row in checks['commands']] == ['tests-01', 'clippy-01', 'format-check-01']\n            rust_files = {name for name in source if name.startswith('crates/') and name.endswith('.rs')}\n"+needle)
after=after.replace("                assert all(source[name] == value for name, value in row['source_sha256'].items())", "                assert set(row['source_sha256']) == rust_files\n                assert all(source[name] == value for name, value in row['source_sha256'].items())")
needle="        scripts = read(root / 'tool-source.json')"
after=after.replace(needle,"            groups = [tuple(map(int, values)) for values in re.findall(r'test result: ok\\. (\\d+) passed; (\\d+) failed; (\\d+) ignored;', (root / 'local-checks/tests-01/output.log').read_text())]\n            assert len(groups) == 34 and sum(row[0] for row in groups) == test_count and all(row[1:] == (0, 0) for row in groups)\n"+needle)
after=after.replace("'pair': right['pair'],\n", "'pair': right['pair'], 'control_source': read(CONTROL / 'source.json'), 'control_pair': left['pair'],\n")
ast.parse(after)
assert not new.exists();new.write_text(after)
Path(str(new)+'.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(old),tofile=str(new))))
print(hashlib.sha256(new.read_bytes()).hexdigest())
