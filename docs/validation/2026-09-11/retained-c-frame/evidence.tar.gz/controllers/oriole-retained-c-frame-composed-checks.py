from pathlib import Path
import hashlib, json, os, signal, subprocess, sys, time
root = Path('/tmp/oriole-retained-c-frame-composed-checks')
worktree = Path('/home/dev-user/code/oss/oriole-retained-c-frame')
phase = sys.argv[1]
commands = {
 'format': ['fmt', '--all'],
 'format-check': ['fmt', '--all', '--check'],
 'check': ['check', '--locked', '--offline', '-p', 'oriole', '-p', 'oriole_expat'],
 'tests': ['test', '--locked', '--offline', '-p', 'oriole', '-p', 'oriole_expat', '-p', 'oriole_storage'],
 'clippy': ['clippy', '--locked', '--offline', '-p', 'oriole', '-p', 'oriole_expat', '-p', 'oriole_storage', '--all-targets', '--', '-D', 'warnings'],
 'release': ['build', '--release', '--locked', '--offline', '-p', 'oriole_expat'],
}
out = root / (phase + '-' + sys.argv[2]); out.mkdir(parents=True, exist_ok=False)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
source = {str(p.relative_to(worktree)): sha(p) for p in worktree.glob('crates/**/*.rs')}
env = os.environ.copy()
for key in list(env):
 if key.startswith('CARGO_PROFILE_') or key in {'RUSTFLAGS','LLVM_PROFILE_FILE','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST','RUSTC'}: env.pop(key, None)
overrides = {'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/targets/retained-c-frame','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_ENCODED_RUSTFLAGS':'','RUSTUP_AUTO_INSTALL':'0','CARGO_TERM_COLOR':'never'}
env.update(overrides)
cmd=['cargo','+ohm','-Zohm-defaults=no',*commands[phase]]
report={'argv':cmd,'source_sha256':source,'environment_overrides':overrides,'started':time.time(),'cpu':sorted(os.sched_getaffinity(0)),'timeout_seconds':900}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
with (out/'output.log').open('wb') as log:
 p=subprocess.Popen(cmd,cwd=worktree,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try: report['exit']=p.wait(timeout=900)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL); report['exit']=p.wait(); report['timed_out']=True
report.update(completed=time.time(),reaped=p.poll() is not None,log_sha256=sha(out/'output.log'),source_unchanged=all(sha(worktree/name)==value for name,value in source.items()))
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'phase':phase,'exit':report['exit'],'report':str(out/'report.json')}))
sys.exit(report['exit'])
