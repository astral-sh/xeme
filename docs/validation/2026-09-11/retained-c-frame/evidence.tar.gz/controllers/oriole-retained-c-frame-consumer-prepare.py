"""Prepare consumer controllers after a completed build; execute no consumers."""
from pathlib import Path
import ast, hashlib, json
BUILD=Path('/tmp/oriole-retained-c-frame-pgo-study')
CONTROL=Path('/tmp/oriole-suffix-element-names-pgo-study')
WORK=Path('/home/dev-user/code/oss/oriole-retained-c-frame')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
pin=lambda p:{'path':str(p),'sha256':sha(p)}
pair=read(BUILD/'pair-report.json'); source=read(BUILD/'source.json'); control=read(CONTROL/'source.json')
assert pair['status']=='passed' and pair['source_unchanged']
assert all(sha(WORK/n)==v for n,v in source['source_sha256'].items())
use=Path(pair['pgo_manifest']['path']).parent/'use'
assert sha(use/'liboriole_expat.so')==pair['pgo_libraries']['use/liboriole_expat.so']
root=Path('/tmp/oriole-retained-c-frame-api-gates');root.mkdir(exist_ok=False)
before=Path('/tmp/oriole-suffix-element-names-api-gates/api_native.py').read_text()
after=before.replace('suffix-element-names-api-gates','retained-c-frame-api-gates').replace('/home/dev-user/code/oss/oriole-suffix-element-names',str(WORK)).replace('/tmp/oriole-suffix-element-names-pgo-study/pgo/runs/run-kj_rp37s/use',str(use)).replace('/tmp/oriole-context-text-frame-fixed-thin-pgo-gates/api-native/upstream-api','/tmp/oriole-suffix-element-names-api-gates/api-native/upstream-api')
ast.parse(after);(root/'api_native.py').write_text(after)
# Scripts keep the same workloads, order, timing interval and bounds.
out=Path('/tmp/oriole-retained-c-frame-python-study');out.mkdir(exist_ok=False)
delta={n:{'control':control['source_sha256'][n],'candidate':v} for n,v in source['source_sha256'].items() if v!=control['source_sha256'][n]}
assert sorted(delta)==['crates/oriole_expat/src/lib.rs','crates/oriole_expat/src/tests.rs']
for mode in ('normal','pgo'):
 old=Path('/tmp/oriole-suffix-element-names-python-study')/mode; dest=out/mode;dest.mkdir()
 original=read(old/'adaptation.json'); record=dict(original)
 for key in ('consumer_source',):
  for entry in original[key]['files'].values():assert sha(entry['path'])==entry['sha256']
 candidate=BUILD/'normal/liboriole_expat.so' if mode=='normal' else use/'liboriole_expat.so'
 libraries={'candidate':pin(candidate),'control':original['libraries']['candidate'],'expat':original['libraries']['expat']}
 assert all(sha(entry['path'])==entry['sha256'] for entry in libraries.values())
 changes={}
 for name,digest in original['files'].items():
  assert sha(old/name)==digest
  text=(old/name).read_text()
  updated=text.replace('/home/dev-user/code/oss/oriole-suffix-element-names/include',str(WORK/'include')).replace('capacity control and packed-name candidate','suffix control and retained-frame candidate').replace('capacity control, packed-name candidate','suffix control, retained-frame candidate').replace('packed-name '+mode+' CPython screen','retained-frame '+mode+' CPython screen')
  if name=='python_worker.py':assert updated==text
  ast.parse(updated);(dest/name).write_text(updated);changes[name]=text!=updated
 record.pop('selected_control_pair_freeze',None)
 record.update(source_runtime_control=control['candidate_base_commit'],source_runtime_candidate=source['candidate_base_commit'],candidate_source_manifest=pin(BUILD/'source.json'),candidate_pair_report=pin(BUILD/'pair-report.json'),selected_control_source_manifest=pin(CONTROL/'source.json'),selected_control_pair_report=pin(CONTROL/'pair-report.json'),libraries=libraries,header=pin(WORK/'include/expat.h'),source_delta=delta,runtime_source_delta=['crates/oriole_expat/src/lib.rs'],candidate_test_delta=['crates/oriole_expat/src/tests.rs'],files={n:sha(dest/n) for n in original['files']},parent_files=original['files'],parent_adaptation=pin(old/'adaptation.json'),changes=changes,proof='Header paths and captions only change in the controllers; raw worker and measurement protocol unchanged. Selected suffix controls, independent original-generated candidate PGO. Unmodified CPython extensions.',execution_status='unexecuted')
 (dest/'adaptation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'prepared_only','api':str(root),'python':str(out)}))
