"""Bind a confirmed retained-C-frame commit to the unchanged normal/PGO protocol."""
from pathlib import Path
import argparse
import ast
import difflib
import hashlib
import json
import re
import shutil
import subprocess

OUTPUT = Path('/tmp/oriole-retained-c-frame-pgo-study')
WORKTREE = Path('/home/dev-user/code/oss/oriole-retained-c-frame')
CONTROL = Path('/tmp/oriole-suffix-element-names-pgo-study')
CHECKS = Path('/tmp/oriole-retained-c-frame-composed-checks')
DELTA = ['crates/oriole_expat/src/lib.rs', 'crates/oriole_expat/src/tests.rs']
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--head', required=True, help='Root-confirmed clean composed candidate commit')
    args = parser.parse_args()
    assert __debug__ and re.fullmatch('[0-9a-f]{40}', args.head)
    head = subprocess.check_output(['git', '-C', str(WORKTREE), 'rev-parse', 'HEAD'], text=True).strip()
    assert head == args.head
    assert not subprocess.check_output(['git', '-C', str(WORKTREE), 'status', '--porcelain'])
    control = read(CONTROL / 'source.json')
    source = {name: sha(WORKTREE / name) for name in control['source_sha256']}
    assert len(source) == 72
    assert sorted(name for name in source if source[name] != control['source_sha256'][name]) == DELTA
    assert all(hashlib.sha256(subprocess.check_output(['git', '-C', str(WORKTREE), 'show', head + ':' + name])).hexdigest() == digest for name, digest in source.items())
    commands = []
    rust_files = {name for name in source if name.startswith('crates/') and name.endswith('.rs')}
    for label in ['tests-01', 'clippy-01', 'format-check-01']:
        row = read(CHECKS / label / 'report.json')
        assert row['exit'] == 0 and row['reaped'] and row['source_unchanged']
        assert set(row['source_sha256']) == rust_files
        assert all(source[name] == digest for name, digest in row['source_sha256'].items())
        assert sha(CHECKS / label / 'output.log') == row['log_sha256']
        commands.append(row | {'label': label})
    groups = [tuple(map(int, values)) for values in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (CHECKS / 'tests-01/output.log').read_text())]
    assert len(groups) == 34 and sum(row[0] for row in groups) == 441 and all(row[1:] == (0, 0) for row in groups)
    scripts = read(CONTROL / 'tool-source.json')
    assert len(scripts) == 6 and all(sha(CONTROL / 'pipeline' / name) == digest for name, digest in scripts.items())
    before = (CONTROL / 'build_pair.py').read_text()
    assert sha(CONTROL / 'build_pair.py') == 'fcb0812c00c2a629389d427b603a90a5e130df366d9e3d17dd96df04c30fc8cd'
    after = before.replace('suffix-element-names', 'retained-c-frame').replace('/tmp/oriole-arena-capacity-bound-pgo-study', str(CONTROL)).replace("checks['test_count']==438", "checks['test_count']==441")
    after = after.replace('Suffix-sharing element-name candidate versus selected capacity runtime de859. Source72 and pipeline69 differ in lib.rs and the custom-name regression in multibyte.rs; C fixtures, selected allocator and callback interface are unchanged.', 'Retained C adapter frame candidate versus selected suffix-sharing element-name runtime a0acaf1. Source72 and pipeline69 differ in oriole_expat/src/lib.rs and its tests.rs; C fixtures, selected allocator and callback interface are unchanged. The opaque parser handle grows by 256 bytes (3160 to 3416); allocation counts, retained bytes and tiny-input costs require measurement.')
    after = after.replace('versus frozen selected capacity controls.', 'versus selected suffix-sharing element-name controls.')
    assert before[before.index('def save()'):] == after[after.index('def save()'):]
    ast.parse(after)
    assert not OUTPUT.exists(), 'Retain every first attempt; no overwrite'
    OUTPUT.mkdir()
    save(OUTPUT / 'source.json', {'status': 'recorded_source', 'base_runtime': control['candidate_base_commit'], 'candidate_base_commit': head, 'worktree': str(WORKTREE), 'source_sha256': source, 'source_count': len(source), 'scope': 'Retain inactive C AdapterFrame allocations across successful incremental feeds; changes only the C adapter and its tests. The opaque parser handle grows by 256 bytes (3160 to 3416).'} )
    (OUTPUT / 'source.patch').write_bytes(subprocess.check_output(['git', '-C', str(WORKTREE), 'diff', control['candidate_base_commit'], head, '--', *DELTA]))
    (OUTPUT / 'local-checks').mkdir()
    save(OUTPUT / 'local-checks/final-checks.json', {'status': 'passed', 'commands': commands})
    for row in commands:
        shutil.copytree(CHECKS / row['label'], OUTPUT / 'local-checks' / row['label'])
    save(OUTPUT / 'source-checks.json', {'status': 'passed', 'test_count': 441, 'test_groups': 34, 'failed': 0, 'ignored': 0, 'commands': commands, 'source_manifest_sha256': sha(OUTPUT / 'source.json'), 'check_report_sha256': sha(OUTPUT / 'local-checks/final-checks.json')})
    for name in scripts:
        dest = OUTPUT / 'pipeline' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(CONTROL / 'pipeline' / name, dest)
    shutil.copyfile(CONTROL / 'tool-source.json', OUTPUT / 'tool-source.json')
    (OUTPUT / 'build_pair.py').write_text(after)
    (OUTPUT / 'controller.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True))))
    save(OUTPUT / 'preparation.json', {'status': 'prepared_not_executed', 'head': head, 'control_head': control['candidate_base_commit'], 'preparer_sha256': sha(__file__), 'source_manifest_sha256': sha(OUTPUT / 'source.json'), 'controller_sha256': sha(OUTPUT / 'build_pair.py'), 'controller_body_byte_identical': True, 'targets_executed': False})
    print((OUTPUT / 'preparation.json').read_text())


if __name__ == '__main__':
    main()
