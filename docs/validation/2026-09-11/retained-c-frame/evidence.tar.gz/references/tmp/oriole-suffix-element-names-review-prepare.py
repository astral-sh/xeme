"""Bind completed suffix-sharing builds to unchanged allocation/native readers; files only."""
from pathlib import Path
import argparse
import ast
import copy
import difflib
import hashlib
import importlib.util
import json
import os
import re
import shutil

BUILD = Path('/tmp/oriole-suffix-element-names-pgo-study')
CONTROL = Path('/tmp/oriole-arena-capacity-bound-pgo-study')
BASELINE = Path('/tmp/oriole-stack-name-allocation-probe')
PROBE = Path('/tmp/oriole-suffix-element-names-allocation-probe')
OLD_READER = Path('/tmp/oriole-bare-tag-native-independent-review')
READER = Path('/tmp/oriole-suffix-element-names-native-independent-review')
WORKTREE = Path('/home/dev-user/code/oss/oriole-suffix-element-names')
HEAD = None
DELTA = ['crates/oriole/src/lib.rs', 'crates/oriole/tests/multibyte.rs']
FINAL = dict(zip(DELTA, [
    'f9928d1798a8e75fe2cd7cbb2c30e557b37ec79ea17402ace85e9311aca95f0c',
    '30d9506ed6468dfeae4bcecdd9373dfbeb0a61be9261befd91f2191df7959ecd',
], strict=True))
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


def main():
    global HEAD
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--released-build', action='store_true')
    parser.add_argument('--head', required=True, help='Exact root-confirmed suffix candidate commit')
    args = parser.parse_args()
    assert re.fullmatch('[0-9a-f]{40}', args.head)
    HEAD = args.head
    assert args.released_build, 'Only after the root confirms the build completed and reaped'
    assert os.sched_getaffinity(0) == {6}
    assert not PROBE.exists() and not READER.exists(), 'Retain first attempt; no overwrite'
    pair = read(BUILD / 'pair-report.json')
    assert pair['status'] == 'passed'
    source = read(BUILD / 'source.json')
    selected = read(CONTROL / 'source.json')
    assert source['candidate_base_commit'] == HEAD
    assert source['base_runtime'] == selected['candidate_base_commit'] == 'de859c89577b2982d59b6923d682032f6a7c7800'
    assert source['worktree'] == str(WORKTREE)
    assert set(source['source_sha256']) == set(selected['source_sha256'])
    assert len(source['source_sha256']) == 72
    assert sorted(n for n in source['source_sha256'] if source['source_sha256'][n] != selected['source_sha256'][n]) == DELTA
    assert all(source['source_sha256'][n] == value == sha(WORKTREE / n) for n, value in FINAL.items())
    checks = read(BUILD / 'source-checks.json')
    assert [row['label'] for row in checks['commands']] == ['tests-01', 'clippy-01', 'format-check-01']
    rust_files = {name for name in source['source_sha256'] if name.startswith('crates/') and name.endswith('.rs')}
    assert all(set(row['source_sha256']) == rust_files for row in checks['commands'])
    pressure = Path('/tmp/oriole-c-reparse-pressure-pgo-study/build_pair.py').read_text()
    expected = pressure.replace('c-reparse-pressure', 'suffix-element-names').replace("checks['test_count']==441", "checks['test_count']==438").replace(
        'C input reservation pressure and retained-buffer lifecycle candidate versus selected capacity runtime de859. Source72 and pipeline69 differ in five files: three runtime files and two test modules; C fixtures and allocator are unchanged.',
        'Suffix-sharing element-name candidate versus selected capacity runtime de859. Source72 and pipeline69 differ in lib.rs and the custom-name regression in multibyte.rs; C fixtures, selected allocator and callback interface are unchanged.')
    assert (BUILD / 'build_pair.py').read_text() == expected
    assert pressure[pressure.index('def save()'):] == expected[expected.index('def save()'):]
    for filename, digest in {
        'build_bindings.py': '570f31f7ce56ecc89da53abd639690239905e06355f224f6106b0d0bf9add181',
        'audit.py': '22033a6c4ec43c808f2cc86e3fc5b03ad2b098b8a9cfcce1c94639de526c3511',
        'combine.py': 'd678f14c9564afbfa213d5e9d315e1ad0ff2997f9053dc4542493d317a7e8efc',
    }.items():
        assert sha(OLD_READER / filename) == digest
    baseline_plan = read(BASELINE / 'plan.json')
    assert sha(BASELINE / 'plan.json') == '0f74489be7fcc4f83e250697fcc7111439844c9f79ada2520f2826ec692ef008'
    assert all(sha(path) == digest for path, digest in baseline_plan['pins'].items())
    assert len(baseline_plan['cases']) == 12

    # Static source/build pins are inserted only after the completed pair is released.
    old_helper = (OLD_READER / 'build_bindings.py').read_text()
    helper = old_helper.replace('/tmp/oriole-bare-tag-pgo-study', str(BUILD)).replace(
        'a01cbbf57b126a37f1c1a1350c9a4fbd5731067f', HEAD).replace(
        '21b3ab7dc7d9704ce6df7af1a3e45a13dcc8b20935363d0705f0e210e262d81a', sha(BUILD / 'source.json')).replace(
        'd604f8b5097ebf53a1de70cb3ae2938de3c390b95589660c1cf7b0958a2854aa', sha(BUILD / 'build_pair.py')).replace(
        "['crates/oriole/src/tag.rs']", repr(DELTA))
    assert helper.count(repr(DELTA)) == 3
    READER.mkdir()
    (READER / 'build_bindings.py').write_text(helper)
    spec = importlib.util.spec_from_file_location('packed_build_bindings', READER / 'build_bindings.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    bindings = module.verify(sha(BUILD / 'pair-report.json'))
    assert bindings['summary']['changed_vs_selected'] == DELTA
    save(READER / 'build-readback.json', bindings)

    old_audit = (OLD_READER / 'audit.py').read_text()
    audit = old_audit.replace('/tmp/oriole-bare-tag-', '/tmp/oriole-suffix-element-names-').replace(
        'a01cbbf57b126a37f1c1a1350c9a4fbd5731067f', HEAD).replace(
        '570f31f7ce56ecc89da53abd639690239905e06355f224f6106b0d0bf9add181', sha(READER / 'build_bindings.py')).replace(
        '379590259e6d45348eed98ee6eadd9c6eaa1f692c2c8da712f79501a0841366e', sha(BUILD / 'pair-report.json'))
    audit = audit.replace('Bare-tag', 'Suffix-sharing element-name').replace('bare-tag', 'suffix-sharing element-name')
    audit = replace_once(audit,
        'This reviewer inspected the runtime patch and producer preparation, and adapted the arithmetic/build-binding readers; did not author the runtime or producer controllers and did not collect build/elapsed results.',
        'This reviewer inspected the runtime patch and native producer preparation, wrote the focused custom-name test extension and allocation diagnostic, and adapted the arithmetic/build-binding readers; did not author the runtime or native elapsed controllers and did not collect build/elapsed results.')
    audit = replace_once(audit,
        'Suffix-sharing element-name candidate differs from selected capacity control only in tag.rs across source72/pipeline69; tests, C fixtures, allocator and callback lowering unchanged.',
        'Suffix-sharing element-name candidate differs from selected capacity control in lib.rs and the custom-name regression in multibyte.rs across source72/pipeline69; C fixtures, selected allocator and callback interface unchanged.')
    start, end = ' ordinal=0; medians={}; obs={}; samples_count=0\n', " A=read(S/'adaptation.json');B="
    old_body = old_audit[old_audit.index(start):old_audit.index(end)]
    new_body = audit[audit.index(start):audit.index(end)]
    assert old_body == new_body
    measurement_sha = hashlib.sha256(new_body.encode()).hexdigest()
    (READER / 'audit.py').write_text(audit)
    old_combine = (OLD_READER / 'combine.py').read_text()
    combine = old_combine.replace('Bare-tag', 'Suffix-sharing element-name').replace('bare-tag', 'suffix-sharing element-name').replace(
        'The reviewer adapted the arithmetic/build-binding readers and reviewed producer source, but did not author the fix or producer controllers and did not collect elapsed runs.',
        'The reviewer wrote the focused custom-name test and allocation diagnostic, adapted the arithmetic/build-binding readers and reviewed runtime/native producer source, but did not author the runtime or native elapsed controllers and did not collect elapsed runs.')
    (READER / 'combine.py').write_text(combine)
    for filename, before, after in [('build_bindings.py', old_helper, helper), ('audit.py', old_audit, audit), ('combine.py', old_combine, combine)]:
        ast.parse(after)
        (READER / (filename + '.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile=str(OLD_READER / filename), tofile=str(READER / filename))))
    save(READER / 'reader-adaptation.json', {
        'status': 'prepared_not_executed', 'candidate_head': HEAD,
        'builder_sha256': sha(__file__), 'build_pair_sha256': sha(BUILD / 'pair-report.json'),
        'source_manifest_sha256': sha(BUILD / 'source.json'), 'source_delta': DELTA,
        'measurement_body_sha256': measurement_sha, 'measurement_body_byte_identical': True,
        'reader_sha256': {n: sha(READER / n) for n in ['build_bindings.py', 'audit.py', 'combine.py']},
        'scope': 'Completed build/source raw binding only. Run each audit only after the corresponding root native campaign completes and is reaped. No compiler/parser/elapsed targets executed by this preparation.',
    })

    # Keep selected raw runs separately referenced; never relabel them as candidate data.
    compared = {}
    for name in ['build'] + [row['name'] for row in baseline_plan['cases']]:
        receipt_path, log_path = BASELINE / 'runs' / (name + '.json'), BASELINE / 'runs' / (name + '.log')
        receipt = read(receipt_path)
        assert receipt['status'] == 'reaped' and receipt['exit'] == 0 and receipt['pins_unchanged']
        assert receipt['plan_sha256'] == sha(BASELINE / 'plan.json')
        assert receipt['log_sha256'] == sha(log_path)
        if name != 'build':
            assert receipt['origin_verified'] and receipt['complete_result'] and receipt['successful_result']
        compared[name] = {str(p): sha(p) for p in [receipt_path, log_path]}
    assert sha(BASELINE / 'selected-review.json') == 'e59f14f06de6be0ba411202788ab21b31db9da1c4756226a64257ba2ac6a1b95'
    manifest = read(pair['pgo_manifest']['path'])
    library = Path(manifest['run']) / 'use/liboriole_expat.so'
    assert sha(library) == pair['pgo_libraries']['use/liboriole_expat.so']
    PROBE.mkdir()
    (PROBE / 'inputs').mkdir()
    for name in ['probe.c', 'run.py']:
        shutil.copyfile(BASELINE / name, PROBE / name)
        assert (BASELINE / name).read_bytes() == (PROBE / name).read_bytes()
    plan = copy.deepcopy(baseline_plan)
    plan['scope'] = 'Fresh suffix-sharing element-name PGO C allocator diagnostics. Same baseline C/runner/input bytes and limits. Preparation executed no compiler/parser/elapsed targets.'
    plan['source_commit'] = HEAD
    plan['library'] = {'path': str(library), 'sha256': sha(library)}
    plan['header_directory'] = str(WORKTREE / 'include')
    for old_case, new_case in zip(baseline_plan['cases'], plan['cases'], strict=True):
        dest = PROBE / 'inputs' / Path(old_case['input']).name
        shutil.copyfile(old_case['input'], dest)
        assert sha(dest) == old_case['input_sha256']
        new_case['input'] = str(dest)
        assert {k: v for k, v in old_case.items() if k != 'input'} == {k: v for k, v in new_case.items() if k != 'input'}
    pins = dict(baseline_plan['pins'])
    pins.update(bindings['inputs'])
    for path in [Path(__file__), BASELINE / 'plan.json', BASELINE / 'selected-review.json', PROBE / 'probe.c', PROBE / 'run.py']:
        pins[str(path)] = sha(path)
    for case in plan['cases']:
        pins[case['input']] = case['input_sha256']
    for paths in compared.values():
        pins.update(paths)
    plan['pins'] = pins
    plan['compared_selected_baseline'] = {
        'source_commit': baseline_plan['source_commit'], 'library': baseline_plan['library'],
        'plan': {'path': str(BASELINE / 'plan.json'), 'sha256': sha(BASELINE / 'plan.json')},
        'raw_records': compared,
        'review': {'path': str(BASELINE / 'selected-review.json'), 'sha256': sha(BASELINE / 'selected-review.json')},
        'comparison_rule': 'Compare each unchanged case only against its matching selected case. The two capacity fixtures straddle an input-buffer boundary; their absolute peaks must not be compared to infer stack-cache effects.',
    }
    assert plan['bounds'] == baseline_plan['bounds']
    assert all(sha(path) == digest for path, digest in pins.items())
    save(PROBE / 'plan.json', plan)
    (PROBE / 'README.md').write_text(
        '# Suffix-sharing element-name allocation diagnostic\n\n'
        'Prepared files only. C, runner, all twelve input byte sequences, warmup boundaries, callback expectations and limits are unchanged from `/tmp/oriole-stack-name-allocation-probe`. The plan binds the committed two-file candidate and its completed fresh PGO-use artifact. Original selected receipts/logs remain separately pinned comparison records.\n\n'
        'Root runs `taskset -c 4 python3 run.py build` once, then `taskset -c 4 python3 run.py run --case CASE` once per declared case. Every first attempt is retained. Run only outside elapsed benchmark collection.\n\n'
        'These are selected-allocator counts and tracked live/peak bytes, not elapsed performance or process RSS. Compare each fixed fixture against identical selected bytes; the two long-name fixtures straddle an input-buffer boundary. Suffix checks and retained name-buffer capacities remain costs to evaluate.\n')
    print(json.dumps({'status': 'prepared_not_executed', 'candidate_head': HEAD,
                      'allocation_plan': str(PROBE / 'plan.json'), 'allocation_plan_sha256': sha(PROBE / 'plan.json'),
                      'native_reader': str(READER / 'audit.py'), 'native_reader_sha256': sha(READER / 'audit.py'),
                      'measurement_body_sha256': measurement_sha, 'source_delta': DELTA,
                      'build_summary': bindings['summary'], 'targets_executed': False}))


if __name__ == '__main__':
    main()
