# Retained C frame: size and diagnostic review

## Measured type sizes

The existing checked debug rlibs report these x86_64 Linux layouts with `rustc +ohm` (direct rustc receives no Cargo automatic experimental flags):

| Type | Selected suffix | Retained-frame prototype | Alignment |
| --- | ---: | ---: | ---: |
| `XML_ParserStruct` | 3160 | 3416 | 8 |
| `Parser` | 2408 | 2408 | 8 |
| `AdapterFrame` | 256 | 256 | 8 |
| `Option<AdapterFrame>` | 256 | 256 | 8 |

The inline field therefore adds 256 bytes, or 8.10%, to every root and child handle allocation. It adds no separate allocation. It preserves previous repr(C) field offsets and the first `user_data` field, but size is a real creation/allocation-budget cost even for one-feed parses that never benefit. Type size is not RSS or an allocator usable-size measurement. The prototype still uses the older de859 core; the selected suffix core has the same public `Parser` size. Remeasure after composition if the core changes further.

`report.json` records exact compile commands, rlib hashes, source-to-passed-check verification and outputs. The source only evaluates `size_of`/`align_of`; it does not create or execute a parser. Both compiles and executions exited 0. The retained check log sums to 441 passed tests/doc-tests, with no ignored or failed tests; Clippy and fmt-check also passed.

## Lifecycle review

No new ownership defect found in the bounded source review. `run_events` takes the Option before event delivery and parks a frame only on successful unfinished parsing, after the core has cleared its payload. The frame owns its buffers and contains scalar ranges; no active payload or parser borrow crosses the pause between feeds. Callback-time setters continue to operate while the frame is detached. Suspension, parse error and normal completion finish the frame; successful reset finishes it against the old core before replacement, while failed reset preserves it transactionally. Destruction finishes it after the guarded encoding-release callback. Root and external-child constructors initialize the cache to None.

Idle StopParser and failures before run_events can retain the inactive frame until resume/reset/free. This is charged retention, not a leak. The existing reservation remains part of the aggregate 64 KiB recycling cap. The retained arena reserves up to 8192 bytes (4096 byte arena plus 128 attributes of 32 bytes), which may now displace other cache storage between feeds. The allocation schedule and tiny-document cost must therefore be measured. This review does not replace C allocation-failure, sanitizer or upstream API checks on the composed source.

## Bounded allocation diagnostic plan

1. Compose onto selected suffix source first; use its measured library as the control, not de859.
2. Reuse `/tmp/oriole-suffix-element-names-allocation-probe/probe.c`, `run.py`, the 12 exact inputs and their callback/count checks. For the initial 4 KiB diagnostic, only paths/source/library pins change. Compare per-phase allocation histograms, every CALL's live bytes/blocks, final retained bytes, peak bytes and zero final live allocations. In particular, intermediate CALL rows expose parked-frame retention that final RESULT alone misses because finalization drops the frame.
3. If extending to 64 KiB, parameterize only the chunk size identically for both libraries and run both fresh at each width; retain first attempts. Preserve the current warmup boundary, limits, callback hash, origin verification, and phase meanings. Maven is a single-feed creation-cost control at 64 KiB. Many generated cases are split by the explicit warmup boundary even when they fit in one chunk; report that geometry. The two capacity inputs cross the 64 KiB input-buffer boundary, so compare each exact fixture to itself rather than inferring a cache-cutoff effect from cross-fixture peaks.
4. Keep current 3-second child alarm, 4-second outer wait, 1 GiB address-space limit, 8 MiB output and 2 MiB input caps. No new large corpus is needed for this allocation diagnostic. Elapsed performance belongs to the existing separately bounded 4 KiB/64 KiB native/CPython benchmark studies.
5. Root owns compiler/parser execution. Existing phase commands remain `taskset -c 4 <pinned-python> -I -S <probe-root>/run.py build` and `... run --case <case>`; update the collector paths, retain all receipts, and compare against the matching selected-suffix case only.
