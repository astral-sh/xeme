fn main() {
    println!("XML_ParserStruct {} {}", size_of::<oriole_expat::XML_ParserStruct>(), align_of::<oriole_expat::XML_ParserStruct>());
    println!("Parser {} {}", size_of::<oriole::Parser>(), align_of::<oriole::Parser>());
    println!("AdapterFrame {} {}", size_of::<oriole::AdapterFrame>(), align_of::<oriole::AdapterFrame>());
    println!("OptionAdapterFrame {} {}", size_of::<Option<oriole::AdapterFrame>>(), align_of::<Option<oriole::AdapterFrame>>());
}
