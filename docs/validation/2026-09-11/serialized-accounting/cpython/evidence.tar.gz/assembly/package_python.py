"""Package released CPython measurements and strict outcomes; no target execution."""
from pathlib import Path
import argparse,csv,gzip,hashlib,io,json,os,subprocess,tarfile
cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('--released',action='store_true');cli.add_argument('--output',type=Path,required=True)
args=cli.parse_args();assert args.released and os.sched_getaffinity(0)=={6}
W=Path('/home/dev-user/code/oss/oriole-serialized-accounting');O=args.output;assert not O.exists()
R=Path('/tmp/oriole-serialized-accounting-python-study');V=Path('/tmp/oriole-serialized-accounting-python-independent-review')
entries={};excluded=[];symlinks=[];sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(Path(p).read_text())
def add(path,name):
    path=Path(path);assert name not in entries
    if path.is_symlink():symlinks.append({'path':name,'target':os.readlink(path)});return
    content=path.read_bytes();record={'path':name,'original':str(path),'bytes':len(content),'sha256':sha(content)}
    if content.startswith((b'\x7fELF',b'!<arch>')) or path.suffix in ('.a','.profraw','.profdata','.pyc'):excluded.append(record)
    else:entries[name]=(record,content)
def tree(root,prefix):
    root=Path(root)
    for p in sorted(root.rglob('*')):
        if '__pycache__' not in p.parts and (p.is_file() or p.is_symlink()):add(p,prefix+'/'+str(p.relative_to(root)))
reports={}
for mode in ('normal','pgo'):
    assert read(R/mode/'time-controller.json')['status']=='passed'
    report=read(V/(mode+'-review.json'))
    assert report['status']=='passed_independent_raw_elapsed_reconstruction' and report['counts']['all_workers']==576 and report['counts']['all_samples']==26364
    reports[mode]=report;tree(R/mode,'study/'+mode)
    for name in (mode+'-review.json',mode+'-row-aliases.json',mode+'-preflight-review.json',mode+'-conditions.csv'):add(V/name,'review/elapsed/'+name)
for name in ('audit.py','preflight_bindings.py'):add(V/name,'review/elapsed/'+name)
for label,stem in [('candidate','serialized-accounting'),('selected','suffix-element-names')]:
    build=Path('/tmp/oriole-'+stem+'-pgo-study');source=read(build/'source.json');assert len(source['source_sha256'])==72
    for name in ('source.json','pair-report.json'):add(build/name,'builds/'+label+'/'+name)
    if label=='candidate':add(build/'preparation.json','builds/candidate/preparation.json')
    for name,digest in source['source_sha256'].items():
        content=subprocess.check_output(['git','-C',str(W),'show',source['candidate_base_commit']+':'+name]);assert sha(content)==digest
        dest='builds/'+label+'/source/'+name
        entries[dest]=({'path':dest,'original':source['candidate_base_commit']+':'+name,'bytes':len(content),'sha256':digest},content)
for name in ('Modules/pyexpat.c','Modules/_elementtree.c','LICENSE'):add(Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13')/name,'upstream/cpython/'+name)
for name in ('LICENSE-APACHE','LICENSE-MIT'):add(W/name,'notices/oriole/'+name)
strict=Path('/tmp/oriole-serialized-accounting-strict-cpython')
assert read(strict/'report.json')['status']=='completed_strict_results'
assert read(strict/'independent-review.json')['status']=='strict_outcomes_match_suffix_control_with_two_failures'
tree(strict,'strict/candidate');tree('/tmp/oriole-suffix-element-names-strict-cpython','strict/selected')
add('/tmp/oriole-serialized-accounting-strict-cpython.py','strict/controller.py')
add(W/'integration/python-build-standalone/consumer-fix/cpython-3.12.13-external-parser.patch','strict/consumer-fix.patch')
add(Path(__file__).parent/'replay_python.py','assembly/replay.py');add(__file__,'assembly/package_python.py')
O.mkdir(parents=True)
index={'format':1,'files':[row for row,_ in entries.values()],'excluded_binaries':excluded,'excluded_symlinks':symlinks}
(O/'index.json').write_text(json.dumps(index,indent=2)+'\n')
with (O/'evidence.tar.gz').open('xb') as stream:
    with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|') as archive:
            for name,(_,content) in sorted(entries.items()):
                member=tarfile.TarInfo(name);member.size=len(content);member.mode=0o644;archive.addfile(member,io.BytesIO(content))
with (O/'conditions.csv').open('x',newline='') as stream:
    writer=csv.writer(stream);writer.writerow(['build','project','chunk_bytes','consumer','candidate_over_control','candidate_over_expat','control_over_expat'])
    for mode,report in reports.items():
        for row in report['summary']:
            c,x=row['condition'],row['median_ratios'];writer.writerow([mode,c['name'],c['chunk'],c['mode'],x['candidate_over_control'],x['candidate_over_expat'],x['control_over_expat']])
report={'status':'assembled','candidate':'bcf15427e861b832f2ec53a57a765c2c4ecb7165','control':'a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9','modes':{mode:{'counts':r['counts'],'aggregates':r['aggregates'],'libraries':r['libraries']} for mode,r in reports.items()},'archive_files':len(entries),'excluded_binary_files':len(excluded),'evidence_sha256':sha((O/'evidence.tar.gz').read_bytes()),'index_sha256':sha((O/'index.json').read_bytes())}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(O/'replay.py').write_bytes((Path(__file__).parent/'replay_python.py').read_bytes());(O/'verify.py').write_bytes((Path(__file__).parent/'verify_python.py').read_bytes())
(O/'files.json').write_text(json.dumps({p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(O.iterdir()) if p.is_file()},indent=2)+'\n')
print(json.dumps({'files':len(entries),'excluded':len(excluded),'archive_bytes':(O/'evidence.tar.gz').stat().st_size,'archive_sha256':report['evidence_sha256']}))
