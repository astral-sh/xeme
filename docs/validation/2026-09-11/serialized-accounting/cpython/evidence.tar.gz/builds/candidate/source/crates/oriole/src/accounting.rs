//! Shared byte accounting for entity amplification, separate from work limits.

use std::cell::Cell;
use std::fmt::Debug;
use std::sync::atomic::{AtomicU32, AtomicU64, AtomicUsize, Ordering};

pub(crate) const MAXIMUM_AMPLIFICATION_DEFAULT: f32 = 100.0;
pub(crate) const ACTIVATION_THRESHOLD_DEFAULT: u64 = 8 * 1024 * 1024;

mod sealed {
    pub trait Sealed {}
}

/// Counter storage selected by the parser type, never by Cargo features.
#[doc(hidden)]
pub trait BudgetMode: sealed::Sealed + Debug {
    type Usize: Counter<usize>;
    type U64: Counter<u64>;
}

/// Atomic accounting for the public Rust parser and its shared children.
#[derive(Debug)]
#[doc(hidden)]
pub enum AtomicMode {}

/// Accounting for the C interface's externally serialized parser families.
#[derive(Debug)]
#[doc(hidden)]
pub enum SerializedMode {}

impl sealed::Sealed for AtomicMode {}
impl sealed::Sealed for SerializedMode {}

impl BudgetMode for AtomicMode {
    type Usize = AtomicUsize;
    type U64 = AtomicU64;
}

impl BudgetMode for SerializedMode {
    type Usize = Cell<usize>;
    type U64 = Cell<u64>;
}

/// A checked counter update that invokes no user code or allocator.
#[doc(hidden)]
pub trait Counter<T>: sealed::Sealed + Debug {
    fn new(value: T) -> Self;
    fn read(&self) -> T;
    fn add_with_limit(&self, amount: T, limit: T) -> bool;
}

macro_rules! counters {
    ($value:ty, $atomic:ty) => {
        impl sealed::Sealed for $atomic {}
        impl sealed::Sealed for Cell<$value> {}

        impl Counter<$value> for $atomic {
            fn new(value: $value) -> Self {
                Self::new(value)
            }

            fn read(&self) -> $value {
                self.load(Ordering::Relaxed)
            }

            fn add_with_limit(&self, amount: $value, limit: $value) -> bool {
                self.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |current| {
                    current.checked_add(amount).filter(|&next| next <= limit)
                })
                .is_ok()
            }
        }

        impl Counter<$value> for Cell<$value> {
            fn new(value: $value) -> Self {
                Self::new(value)
            }

            fn read(&self) -> $value {
                self.get()
            }

            fn add_with_limit(&self, amount: $value, limit: $value) -> bool {
                let Some(next) = self.get().checked_add(amount).filter(|&next| next <= limit)
                else {
                    return false;
                };
                self.set(next);
                true
            }
        }
    };
}

counters!(usize, AtomicUsize);
counters!(u64, AtomicU64);

#[derive(Debug)]
pub(crate) struct EntityBudget<M: BudgetMode> {
    pub(crate) expanded: M::Usize,
    direct: M::U64,
    indirect: M::U64,
    factor: AtomicU32,
    threshold: AtomicU64,
}

impl<M: BudgetMode> EntityBudget<M> {
    pub(crate) fn new() -> Self {
        Self {
            expanded: M::Usize::new(0),
            direct: M::U64::new(0),
            indirect: M::U64::new(0),
            factor: AtomicU32::new(MAXIMUM_AMPLIFICATION_DEFAULT.to_bits()),
            threshold: AtomicU64::new(ACTIVATION_THRESHOLD_DEFAULT),
        }
    }

    pub(crate) fn set_factor(&self, factor: f32) -> bool {
        if factor.is_nan() || factor < 1.0 {
            return false;
        }
        self.factor.store(factor.to_bits(), Ordering::Relaxed);
        true
    }

    pub(crate) fn set_threshold(&self, bytes: u64) {
        self.threshold.store(bytes, Ordering::Relaxed);
    }

    /// Bound cumulative work by consumed root bytes, retaining a fixed allowance
    /// for small documents. Saturation never exempts the work counter's overflow
    /// check. External bytes and input waiting in the decoder provide no credit.
    pub(crate) fn work_limit(&self, initial: usize, factor: Option<usize>) -> usize {
        let Some(factor) = factor else {
            return initial;
        };
        let direct = usize::try_from(self.direct.read()).unwrap_or(usize::MAX);
        initial.max(direct.saturating_mul(factor))
    }

    /// Count bytes before processing their token. Predefined entities contribute
    /// one extra byte without checking immediately, matching Expat's contract.
    pub(crate) fn account(&self, bytes: usize, indirect: bool, enforce: bool) -> bool {
        if bytes == 0 {
            return true;
        }
        let Ok(bytes) = u64::try_from(bytes) else {
            return false;
        };
        let counter = if indirect {
            &self.indirect
        } else {
            &self.direct
        };
        if !counter.add_with_limit(bytes, u64::MAX) {
            return false;
        }
        let direct = self.direct.read();
        let indirect = self.indirect.read();
        let Some(total) = direct.checked_add(indirect) else {
            return false;
        };
        if !enforce || total < self.threshold.load(Ordering::Relaxed) {
            return true;
        }
        // An independently parsed external entity may precede every root byte.
        // Expat uses the shortest external-entity declaration (22 bytes) as the
        // denominator in that case; real direct input is never replaced by it.
        let amplification = if direct == 0 {
            let Some(total) = indirect.checked_add(22) else {
                return false;
            };
            total as f32 / 22.0
        } else {
            total as f32 / direct as f32
        };
        amplification <= f32::from_bits(self.factor.load(Ordering::Relaxed))
    }
}

#[cfg(test)]
mod tests {
    use super::{AtomicMode, BudgetMode, Counter, EntityBudget, SerializedMode};
    use oriole_storage::{Allocator, Shared};

    #[test]
    fn work_threshold_uses_only_direct_credit_and_saturates() {
        fn check<M: BudgetMode>() {
            let mut budget = EntityBudget::<M>::new();
            assert!(budget.account(1000, true, false));
            assert_eq!(budget.work_limit(7, Some(100)), 7);
            assert!(budget.account(3, false, true));
            assert_eq!(budget.work_limit(7, None), 7);
            assert_eq!(budget.work_limit(7, Some(100)), 300);
            assert_eq!(budget.work_limit(400, Some(100)), 400);
            assert!(budget.set_factor(f32::INFINITY));
            budget.set_threshold(u64::MAX);
            assert_eq!(budget.work_limit(7, Some(100)), 300);
            budget.direct = M::U64::new(u64::MAX);
            assert_eq!(budget.work_limit(7, Some(100)), usize::MAX);
            assert!(!budget.account(1, false, false));
        }
        check::<AtomicMode>();
        check::<SerializedMode>();
    }

    #[test]
    fn counters_reject_overflow_even_when_relative_limits_are_disabled() {
        fn check<M: BudgetMode>() {
            let mut budget = EntityBudget::<M>::new();
            assert!(budget.set_factor(f32::INFINITY));
            budget.set_threshold(u64::MAX);
            budget.direct = M::U64::new(u64::MAX);
            assert!(!budget.account(1, false, true));
            assert_eq!(budget.direct.read(), u64::MAX);
            assert!(!budget.account(1, true, true));

            budget.direct = M::U64::new(0);
            budget.indirect = M::U64::new(u64::MAX - 1);
            assert!(!budget.account(1, true, true));
            assert_eq!(budget.indirect.read(), u64::MAX);
            assert!(!budget.account(1, true, false));
            assert_eq!(budget.indirect.read(), u64::MAX);

            budget.expanded = M::Usize::new(usize::MAX);
            assert!(!budget.expanded.add_with_limit(1, usize::MAX));
            assert_eq!(budget.expanded.read(), usize::MAX);
        }
        check::<AtomicMode>();
        check::<SerializedMode>();
    }

    #[test]
    fn shared_counters_preserve_failed_charge_order_and_zero_boundaries() {
        fn check<M: BudgetMode>() {
            let parent = Shared::try_new_in(EntityBudget::<M>::new(), Allocator::System).unwrap();
            let child = parent.clone();
            assert!(parent.set_factor(1.0));
            parent.set_threshold(0);
            assert!(parent.account(1, false, true));
            // Amplification rejects after retaining the accepted byte increment.
            assert!(!child.account(1, true, true));
            assert_eq!(parent.direct.read(), 1);
            assert_eq!(parent.indirect.read(), 1);
            assert!(!parent.account(1, false, true));
            assert_eq!(child.direct.read(), 2);
            assert!(child.account(0, true, true));
            assert_eq!(parent.indirect.read(), 1);
            assert_eq!(child.work_limit(0, Some(3)), 6);

            // Work-limit rejection leaves the shared counter unchanged, even
            // for a zero charge above a subsequently tightened limit.
            assert!(parent.expanded.add_with_limit(3, 3));
            assert!(!child.expanded.add_with_limit(1, 3));
            assert!(child.expanded.add_with_limit(0, 3));
            assert!(!child.expanded.add_with_limit(0, 2));
            assert_eq!(parent.expanded.read(), 3);
            drop(parent);
            assert_eq!(child.direct.read(), 2);
            assert_eq!(child.expanded.read(), 3);
        }
        check::<AtomicMode>();
        check::<SerializedMode>();
    }
}
