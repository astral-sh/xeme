"""Package released native/build/allocation/API records using the existing archive layout."""
from pathlib import Path
import argparse, csv, gzip, hashlib, io, json, os, subprocess, tarfile
cli=argparse.ArgumentParser(description=__doc__)
cli.add_argument('--released',action='store_true')
cli.add_argument('--output',type=Path,required=True)
args=cli.parse_args();assert args.released and os.sched_getaffinity(0)=={6}
W=Path('/home/dev-user/code/oss/oriole-serialized-accounting')
B=Path('/tmp/oriole-serialized-accounting-pgo-study')
V=Path('/tmp/oriole-serialized-accounting-native-independent-review')
O=args.output
assert not O.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
reviews={mode:read(V/(mode+'-review.json')) for mode in ('normal','pgo')}
assert all(r['status']=='passed' and r['totals']=={'conditions':28,'preflight_workers':84,'timed_workers':588,'all_workers':672,'all_samples':106176} for r in reviews.values())
assert read(B/'source.json')['candidate_base_commit']=='bcf15427e861b832f2ec53a57a765c2c4ecb7165'
files={};origins={};excluded=[]
def add(path,name):
    p=Path(path);assert name not in files
    if p.is_symlink():return
    data=p.read_bytes()
    if data.startswith((b'\x7fELF',b'!<arch>')) or p.suffix in ('.a','.profraw','.profdata','.pyc'):
        excluded.append({'path':str(p),'bytes':len(data),'sha256':sha(data)});return
    files[name]=data;origins[str(p)]=name

def tree(path,prefix,allowed=None):
    for p in sorted(Path(path).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and (allowed is None or p.suffix in allowed):add(p,prefix+str(p.relative_to(path)))

tree('/tmp/oriole-serialized-accounting-native-study','candidate/native/')
tree(V,'candidate/review/',{'.json','.csv','.py','.patch','.md'})
for label,build in [('candidate',B),('selected',Path('/tmp/oriole-suffix-element-names-pgo-study'))]:
    for name in ['source.json','pair-report.json','build_pair.py','source-checks.json','tool-source.json','source.patch','normal-build.log','normal-training.json','pgo-pipeline.log']:
        add(build/name,label+'/build/'+name)
    if label=='candidate':
        for name in ['preparation.json','build-readback.json','controller.patch']:add(build/name,label+'/build/'+name)
        tree(build/'local-checks',label+'/build/local-checks/')
    tree(build/'pipeline',label+'/build/pipeline/')
    run=Path(read(build/'pair-report.json')['pgo_manifest']['path']).parent
    for p in sorted(run.iterdir()):
        if p.is_file() and p.suffix in ('.json','.log'):add(p,label+'/build/pgo/'+p.name)
    tree(run/'inputs',label+'/build/pgo/inputs/')
    source=read(build/'source.json')
    for name,digest in source['source_sha256'].items():
        data=subprocess.check_output(['git','-C',str(W),'show',source['candidate_base_commit']+':'+name])
        assert sha(data)==digest
        files[label+'/source/'+name]=data
for label,stem in [('candidate','serialized-accounting'),('selected','suffix-element-names')]:
    tree('/tmp/oriole-'+stem+'-allocation-probe','allocation/'+label+'/',{'.json','.log','.c','.py','.md','.csv','.xml'})
tree('/tmp/oriole-serialized-accounting-api-gates','candidate/api/',{'.json','.log','.py','.c','.h','.md','.patch','.stdout','.stderr'})
for name in ['results.json','manifest.json','tests.log']:
    add('/tmp/oriole-suffix-element-names-api-gates/api-native/upstream-api/'+name,'selected/api/'+name)
tree('/tmp/oriole-serialized-accounting-checks','candidate/prior-and-final-checks/',{'.json','.log'})
for name in ['source-review.json','source-review-addendum.json','consumer-preparation-attempt01.md','dtd-mode-coverage.patch','reviewed-delta.json']:
    add('/tmp/oriole-serialized-accounting-'+name,'candidate/review-notes/'+name)
tree('/tmp/oriole-serialized-accounting-codegen','codegen/',{'.json','.stdout','.stderr','.asm','.py','.txt'})
tree('/tmp/oriole-serialized-accounting-layout','layout/',{'.json','.stdout','.stderr'})
for name in ['inspect.py','inspect-attempt01.py','layout-run.py','layout.rs']:
    add('/tmp/oriole-serialized-accounting-'+name,('layout/' if name.startswith('layout') else 'codegen/')+name)
for label,stem,attempt in [('control','suffix-element-names','01'),('candidate','serialized-accounting','03')]:
    for name in ['report.json','output.log']:
        add('/tmp/oriole-'+stem+'-checks/tests-'+attempt+'/'+name,'layout/checks/'+label+'/'+name)
for name in ['LICENSE-MIT','LICENSE-APACHE']:add(W/name,'notices/oriole/'+name)
add('/home/dev-user/.cache/oriole/upstream/expat-2.8.4/COPYING','notices/expat/COPYING')
add(__file__,'assembly/package_native.py')
O.mkdir(parents=True)
with (O/'evidence.tar.gz').open('xb') as output:
    with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|') as archive:
            for name,data in sorted(files.items()):
                member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;archive.addfile(member,io.BytesIO(data))
index={'archive_sha256':sha((O/'evidence.tar.gz').read_bytes()),'files':{name:{'sha256':sha(data),'bytes':len(data)} for name,data in sorted(files.items())},'original_paths':origins,'excluded_binaries':excluded}
(O/'files.json').write_text(json.dumps(index,indent=2)+'\n')
rows=[]
for mode in ['normal','pgo']:
    with (V/(mode+'-conditions.csv')).open() as stream:rows.extend({'variant':'candidate',**row} for row in csv.DictReader(stream))
with (O/'conditions.csv').open('x',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
(O/'allocations.csv').write_bytes(Path('/tmp/oriole-serialized-accounting-allocation-probe/comparison.csv').read_bytes())
(O/'verify.py').write_bytes((Path(__file__).parent/'verify_native.py').read_bytes())
summary={'status':'assembled','candidate':read(B/'source.json')['candidate_base_commit'],'control':'a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9','modes':{mode:r['native'][mode] for mode,r in reviews.items()},'archive_files':len(files),'archive_sha256':index['archive_sha256'],'scope':'Saved records and source snapshots; original binaries are represented by recorded identities.'}
summary['codegen_and_layout']={'comparison_sha256':sha(files['codegen/comparison.json']),'layout_sha256':sha(files['layout/report.json']),'handle_bytes':3160,'core_bytes':2408,'pgo_text_bytes':read('/tmp/oriole-serialized-accounting-codegen/comparison.json')['changes']['pgo']['text_section_bytes'],'scope':'Named accounting paths lose counter CAS; storage atomics remain. Layout uses checked debug artifacts; private EntityBudget heap layout is unmeasured.'}
(O/'report.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':'assembled','files':len(files),'archive_bytes':(O/'evidence.tar.gz').stat().st_size,'archive_sha256':index['archive_sha256']}))
