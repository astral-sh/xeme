   aa680:	41 56                                           	push   %r14
   aa682:	53                                              	push   %rbx
   aa683:	48 83 ec 18                                     	sub    $0x18,%rsp
   aa687:	b0 ff                                           	mov    $0xff,%al
   aa689:	48 85 d2                                        	test   %rdx,%rdx
   aa68c:	0f 84 92 01 00 00                               	je     aa824 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x1a4>
   aa692:	4c 8b 86 e8 08 00 00                            	mov    0x8e8(%rsi),%r8
   aa699:	49 03 50 38                                     	add    0x38(%r8),%rdx
   aa69d:	0f 82 e1 00 00 00                               	jb     aa784 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x104>
   aa6a3:	49 89 50 38                                     	mov    %rdx,0x38(%r8)
   aa6a7:	4d 8b 48 30                                     	mov    0x30(%r8),%r9
   aa6ab:	4d 8d 14 11                                     	lea    (%r9,%rdx,1),%r10
   aa6af:	84 c9                                           	test   %cl,%cl
   aa6b1:	74 54                                           	je     aa707 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x87>
   aa6b3:	4d 39 ca                                        	cmp    %r9,%r10
   aa6b6:	72 4f                                           	jb     aa707 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x87>
   aa6b8:	49 8b 48 40                                     	mov    0x40(%r8),%rcx
   aa6bc:	49 39 ca                                        	cmp    %rcx,%r10
   aa6bf:	0f 82 5f 01 00 00                               	jb     aa824 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x1a4>
   aa6c5:	4d 85 c9                                        	test   %r9,%r9
   aa6c8:	74 47                                           	je     aa711 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x91>
   aa6ca:	4d 85 d2                                        	test   %r10,%r10
   aa6cd:	78 55                                           	js     aa724 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0xa4>
   aa6cf:	f3 49 0f 2a c2                                  	cvtsi2ss %r10,%xmm0
   aa6d4:	4d 85 c9                                        	test   %r9,%r9
   aa6d7:	79 66                                           	jns    aa73f <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0xbf>
   aa6d9:	4c 89 c9                                        	mov    %r9,%rcx
   aa6dc:	48 d1 e9                                        	shr    $1,%rcx
   aa6df:	41 83 e1 01                                     	and    $0x1,%r9d
   aa6e3:	49 09 c9                                        	or     %rcx,%r9
   aa6e6:	f3 49 0f 2a c9                                  	cvtsi2ss %r9,%xmm1
   aa6eb:	f3 0f 58 c9                                     	addss  %xmm1,%xmm1
   aa6ef:	f3 0f 5e c1                                     	divss  %xmm1,%xmm0
   aa6f3:	f3 41 0f 10 48 48                               	movss  0x48(%r8),%xmm1
   aa6f9:	0f 2e c8                                        	ucomiss %xmm0,%xmm1
   aa6fc:	0f 82 82 00 00 00                               	jb     aa784 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x104>
   aa702:	e9 1d 01 00 00                                  	jmp    aa824 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x1a4>
   aa707:	4d 39 ca                                        	cmp    %r9,%r10
   aa70a:	72 78                                           	jb     aa784 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x104>
   aa70c:	e9 13 01 00 00                                  	jmp    aa824 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x1a4>
   aa711:	48 83 fa e9                                     	cmp    $0xffffffffffffffe9,%rdx
   aa715:	77 6d                                           	ja     aa784 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x104>
   aa717:	48 83 c2 16                                     	add    $0x16,%rdx
   aa71b:	78 3b                                           	js     aa758 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0xd8>
   aa71d:	f3 48 0f 2a c2                                  	cvtsi2ss %rdx,%xmm0
   aa722:	eb 49                                           	jmp    aa76d <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0xed>
   aa724:	4c 89 d1                                        	mov    %r10,%rcx
   aa727:	48 d1 e9                                        	shr    $1,%rcx
   aa72a:	41 83 e2 01                                     	and    $0x1,%r10d
   aa72e:	49 09 ca                                        	or     %rcx,%r10
   aa731:	f3 49 0f 2a c2                                  	cvtsi2ss %r10,%xmm0
   aa736:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   aa73a:	4d 85 c9                                        	test   %r9,%r9
   aa73d:	78 9a                                           	js     aa6d9 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x59>
   aa73f:	f3 49 0f 2a c9                                  	cvtsi2ss %r9,%xmm1
   aa744:	f3 0f 5e c1                                     	divss  %xmm1,%xmm0
   aa748:	f3 41 0f 10 48 48                               	movss  0x48(%r8),%xmm1
   aa74e:	0f 2e c8                                        	ucomiss %xmm0,%xmm1
   aa751:	72 31                                           	jb     aa784 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x104>
   aa753:	e9 cc 00 00 00                                  	jmp    aa824 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x1a4>
   aa758:	48 89 d1                                        	mov    %rdx,%rcx
   aa75b:	48 d1 e9                                        	shr    $1,%rcx
   aa75e:	83 e2 01                                        	and    $0x1,%edx
   aa761:	48 09 ca                                        	or     %rcx,%rdx
   aa764:	f3 48 0f 2a c2                                  	cvtsi2ss %rdx,%xmm0
   aa769:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   aa76d:	f3 0f 5e 05 cb 0f f6 ff                         	divss  -0x9f035(%rip),%xmm0        # b740 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x8c>
   aa775:	f3 41 0f 10 48 48                               	movss  0x48(%r8),%xmm1
   aa77b:	0f 2e c8                                        	ucomiss %xmm0,%xmm1
   aa77e:	0f 83 a0 00 00 00                               	jae    aa824 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x1a4>
   aa784:	48 8b 8e 58 02 00 00                            	mov    0x258(%rsi),%rcx
   aa78b:	48 85 c9                                        	test   %rcx,%rcx
   aa78e:	0f 84 9b 00 00 00                               	je     aa82f <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x1af>
   aa794:	48 8b 86 48 02 00 00                            	mov    0x248(%rsi),%rax
   aa79b:	48 8d 0c 49                                     	lea    (%rcx,%rcx,2),%rcx
   aa79f:	48 c1 e1 07                                     	shl    $0x7,%rcx
   aa7a3:	48 8d 14 08                                     	lea    (%rax,%rcx,1),%rdx
   aa7a7:	83 bc 08 80 fe ff ff 01                         	cmpl   $0x1,-0x180(%rax,%rcx,1)
   aa7af:	75 1b                                           	jne    aa7cc <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x14c>
   aa7b1:	48 8d 47 10                                     	lea    0x10(%rdi),%rax
   aa7b5:	0f 10 82 88 fe ff ff                            	movups -0x178(%rdx),%xmm0
   aa7bc:	0f 10 8a 98 fe ff ff                            	movups -0x168(%rdx),%xmm1
   aa7c3:	0f 11 48 10                                     	movups %xmm1,0x10(%rax)
   aa7c7:	0f 11 00                                        	movups %xmm0,(%rax)
   aa7ca:	eb 44                                           	jmp    aa810 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x190>
   aa7cc:	48 8b 5a a8                                     	mov    -0x58(%rdx),%rbx
   aa7d0:	0f 10 42 d8                                     	movups -0x28(%rdx),%xmm0
   aa7d4:	0f b6 52 fc                                     	movzbl -0x4(%rdx),%edx
   aa7d8:	f6 c2 03                                        	test   $0x3,%dl
   aa7db:	75 04                                           	jne    aa7e1 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x161>
   aa7dd:	31 c0                                           	xor    %eax,%eax
   aa7df:	eb 23                                           	jmp    aa804 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x184>
   aa7e1:	48 01 c8                                        	add    %rcx,%rax
   aa7e4:	48 05 80 fe ff ff                               	add    $0xfffffffffffffe80,%rax
   aa7ea:	49 89 fe                                        	mov    %rdi,%r14
   aa7ed:	48 89 c7                                        	mov    %rax,%rdi
   aa7f0:	31 f6                                           	xor    %esi,%esi
   aa7f2:	31 d2                                           	xor    %edx,%edx
   aa7f4:	0f 29 04 24                                     	movaps %xmm0,(%rsp)
   aa7f8:	e8 83 45 f9 ff                                  	call   3ed80 <<oriole::encoding::Source>::converted_raw_len>
   aa7fd:	0f 28 04 24                                     	movaps (%rsp),%xmm0
   aa801:	4c 89 f7                                        	mov    %r14,%rdi
   aa804:	48 89 5f 10                                     	mov    %rbx,0x10(%rdi)
   aa808:	0f 11 47 18                                     	movups %xmm0,0x18(%rdi)
   aa80c:	48 89 47 28                                     	mov    %rax,0x28(%rdi)
   aa810:	48 8d 05 ef 4b f6 ff                            	lea    -0x9b411(%rip),%rax        # f406 <anon.30029722b35a0dea18e479b6be687fec.245.llvm.7845226830220971649+0x1b8b>
   aa817:	48 89 07                                        	mov    %rax,(%rdi)
   aa81a:	48 c7 47 08 23 00 00 00                         	movq   $0x23,0x8(%rdi)
   aa822:	b0 1e                                           	mov    $0x1e,%al
   aa824:	88 47 30                                        	mov    %al,0x30(%rdi)
   aa827:	48 83 c4 18                                     	add    $0x18,%rsp
   aa82b:	5b                                              	pop    %rbx
   aa82c:	41 5e                                           	pop    %r14
   aa82e:	c3                                              	ret
   aa82f:	48 8d 3d cc 49 f6 ff                            	lea    -0x9b634(%rip),%rdi        # f202 <anon.30029722b35a0dea18e479b6be687fec.245.llvm.7845226830220971649+0x1987>
   aa836:	48 8d 15 9b 2f 04 00                            	lea    0x42f9b(%rip),%rdx        # ed7d8 <oriole_expat::FEATURES+0x13b0>
   aa83d:	be 21 00 00 00                                  	mov    $0x21,%esi
   aa842:	ff 15 d8 45 04 00                               	call   *0x445d8(%rip)        # eee20 <_DYNAMIC+0x380>
