   97420:	55                                              	push   %rbp
   97421:	41 57                                           	push   %r15
   97423:	41 56                                           	push   %r14
   97425:	41 55                                           	push   %r13
   97427:	41 54                                           	push   %r12
   97429:	53                                              	push   %rbx
   9742a:	48 83 ec 18                                     	sub    $0x18,%rsp
   9742e:	4c 8b a6 58 02 00 00                            	mov    0x258(%rsi),%r12
   97435:	4d 85 e4                                        	test   %r12,%r12
   97438:	0f 84 c6 01 00 00                               	je     97604 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x1e4>
   9743e:	48 89 fb                                        	mov    %rdi,%rbx
   97441:	48 8b 86 48 02 00 00                            	mov    0x248(%rsi),%rax
   97448:	4b 8d 0c 64                                     	lea    (%r12,%r12,2),%rcx
   9744c:	48 c1 e1 07                                     	shl    $0x7,%rcx
   97450:	4c 8d 3c 08                                     	lea    (%rax,%rcx,1),%r15
   97454:	4c 8d 34 08                                     	lea    (%rax,%rcx,1),%r14
   97458:	49 81 c6 80 fe ff ff                            	add    $0xfffffffffffffe80,%r14
   9745f:	4c 8b 6c 08 a8                                  	mov    -0x58(%rax,%rcx,1),%r13
   97464:	0f b6 44 08 fc                                  	movzbl -0x4(%rax,%rcx,1),%eax
   97469:	a8 03                                           	test   $0x3,%al
   9746b:	74 13                                           	je     97480 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x60>
   9746d:	4c 89 f7                                        	mov    %r14,%rdi
   97470:	48 89 f5                                        	mov    %rsi,%rbp
   97473:	31 f6                                           	xor    %esi,%esi
   97475:	e8 06 79 fa ff                                  	call   3ed80 <<oriole::encoding::Source>::converted_raw_len>
   9747a:	48 89 ee                                        	mov    %rbp,%rsi
   9747d:	48 89 c2                                        	mov    %rax,%rdx
   97480:	4c 01 ea                                        	add    %r13,%rdx
   97483:	31 c0                                           	xor    %eax,%eax
   97485:	49 2b 57 b0                                     	sub    -0x50(%r15),%rdx
   97489:	48 0f 43 c2                                     	cmovae %rdx,%rax
   9748d:	0f 86 59 01 00 00                               	jbe    975ec <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x1cc>
   97493:	48 8b 8e e8 08 00 00                            	mov    0x8e8(%rsi),%rcx
   9749a:	49 83 fc 01                                     	cmp    $0x1,%r12
   9749e:	40 0f 95 c7                                     	setne  %dil
   974a2:	40 0a be 5a 09 00 00                            	or     0x95a(%rsi),%dil
   974a9:	48 8d 71 38                                     	lea    0x38(%rcx),%rsi
   974ad:	48 8d 51 30                                     	lea    0x30(%rcx),%rdx
   974b1:	44 0f b6 c7                                     	movzbl %dil,%r8d
   974b5:	45 84 c0                                        	test   %r8b,%r8b
   974b8:	48 89 d7                                        	mov    %rdx,%rdi
   974bb:	48 0f 45 fe                                     	cmovne %rsi,%rdi
   974bf:	4e 8b 44 c1 30                                  	mov    0x30(%rcx,%r8,8),%r8
   974c4:	49 01 c0                                        	add    %rax,%r8
   974c7:	72 11                                           	jb     974da <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0xba>
   974c9:	4c 89 07                                        	mov    %r8,(%rdi)
   974cc:	48 8b 12                                        	mov    (%rdx),%rdx
   974cf:	48 8b 36                                        	mov    (%rsi),%rsi
   974d2:	48 89 f7                                        	mov    %rsi,%rdi
   974d5:	48 01 d7                                        	add    %rdx,%rdi
   974d8:	73 39                                           	jae    97513 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0xf3>
   974da:	41 83 3e 01                                     	cmpl   $0x1,(%r14)
   974de:	75 1d                                           	jne    974fd <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0xdd>
   974e0:	48 8d 43 10                                     	lea    0x10(%rbx),%rax
   974e4:	41 0f 10 87 88 fe ff ff                         	movups -0x178(%r15),%xmm0
   974ec:	41 0f 10 8f 98 fe ff ff                         	movups -0x168(%r15),%xmm1
   974f4:	0f 11 48 10                                     	movups %xmm1,0x10(%rax)
   974f8:	0f 11 00                                        	movups %xmm0,(%rax)
   974fb:	eb 54                                           	jmp    97551 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x131>
   974fd:	4d 8b 67 a8                                     	mov    -0x58(%r15),%r12
   97501:	41 0f 10 47 d8                                  	movups -0x28(%r15),%xmm0
   97506:	41 0f b6 47 fc                                  	movzbl -0x4(%r15),%eax
   9750b:	a8 03                                           	test   $0x3,%al
   9750d:	75 22                                           	jne    97531 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x111>
   9750f:	31 c0                                           	xor    %eax,%eax
   97511:	eb 32                                           	jmp    97545 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x125>
   97513:	4c 8b 41 40                                     	mov    0x40(%rcx),%r8
   97517:	4c 39 c7                                        	cmp    %r8,%rdi
   9751a:	0f 82 cc 00 00 00                               	jb     975ec <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x1cc>
   97520:	48 85 d2                                        	test   %rdx,%rdx
   97523:	74 45                                           	je     9756a <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x14a>
   97525:	48 85 ff                                        	test   %rdi,%rdi
   97528:	78 57                                           	js     97581 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x161>
   9752a:	f3 48 0f 2a c7                                  	cvtsi2ss %rdi,%xmm0
   9752f:	eb 65                                           	jmp    97596 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x176>
   97531:	4c 89 f7                                        	mov    %r14,%rdi
   97534:	31 f6                                           	xor    %esi,%esi
   97536:	31 d2                                           	xor    %edx,%edx
   97538:	0f 29 04 24                                     	movaps %xmm0,(%rsp)
   9753c:	e8 3f 78 fa ff                                  	call   3ed80 <<oriole::encoding::Source>::converted_raw_len>
   97541:	0f 28 04 24                                     	movaps (%rsp),%xmm0
   97545:	4c 89 63 10                                     	mov    %r12,0x10(%rbx)
   97549:	0f 11 43 18                                     	movups %xmm0,0x18(%rbx)
   9754d:	48 89 43 28                                     	mov    %rax,0x28(%rbx)
   97551:	48 8d 05 ae 7e f7 ff                            	lea    -0x88152(%rip),%rax        # f406 <anon.30029722b35a0dea18e479b6be687fec.245.llvm.7845226830220971649+0x1b8b>
   97558:	48 89 03                                        	mov    %rax,(%rbx)
   9755b:	48 c7 43 08 23 00 00 00                         	movq   $0x23,0x8(%rbx)
   97563:	b0 1e                                           	mov    $0x1e,%al
   97565:	e9 88 00 00 00                                  	jmp    975f2 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x1d2>
   9756a:	48 83 fe e9                                     	cmp    $0xffffffffffffffe9,%rsi
   9756e:	0f 87 66 ff ff ff                               	ja     974da <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0xba>
   97574:	48 83 c6 16                                     	add    $0x16,%rsi
   97578:	78 47                                           	js     975c1 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x1a1>
   9757a:	f3 48 0f 2a c6                                  	cvtsi2ss %rsi,%xmm0
   9757f:	eb 55                                           	jmp    975d6 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x1b6>
   97581:	48 89 fe                                        	mov    %rdi,%rsi
   97584:	48 d1 ee                                        	shr    $1,%rsi
   97587:	83 e7 01                                        	and    $0x1,%edi
   9758a:	48 09 f7                                        	or     %rsi,%rdi
   9758d:	f3 48 0f 2a c7                                  	cvtsi2ss %rdi,%xmm0
   97592:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   97596:	48 85 d2                                        	test   %rdx,%rdx
   97599:	78 0b                                           	js     975a6 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x186>
   9759b:	f3 48 0f 2a ca                                  	cvtsi2ss %rdx,%xmm1
   975a0:	f3 0f 5e c1                                     	divss  %xmm1,%xmm0
   975a4:	eb 38                                           	jmp    975de <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x1be>
   975a6:	48 89 d6                                        	mov    %rdx,%rsi
   975a9:	48 d1 ee                                        	shr    $1,%rsi
   975ac:	83 e2 01                                        	and    $0x1,%edx
   975af:	48 09 f2                                        	or     %rsi,%rdx
   975b2:	f3 48 0f 2a ca                                  	cvtsi2ss %rdx,%xmm1
   975b7:	f3 0f 58 c9                                     	addss  %xmm1,%xmm1
   975bb:	f3 0f 5e c1                                     	divss  %xmm1,%xmm0
   975bf:	eb 1d                                           	jmp    975de <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x1be>
   975c1:	48 89 f2                                        	mov    %rsi,%rdx
   975c4:	48 d1 ea                                        	shr    $1,%rdx
   975c7:	83 e6 01                                        	and    $0x1,%esi
   975ca:	48 09 d6                                        	or     %rdx,%rsi
   975cd:	f3 48 0f 2a c6                                  	cvtsi2ss %rsi,%xmm0
   975d2:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   975d6:	f3 0f 5e 05 62 41 f7 ff                         	divss  -0x8be9e(%rip),%xmm0        # b740 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x8c>
   975de:	f3 0f 10 49 48                                  	movss  0x48(%rcx),%xmm1
   975e3:	0f 2e c8                                        	ucomiss %xmm0,%xmm1
   975e6:	0f 82 ee fe ff ff                               	jb     974da <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0xba>
   975ec:	49 01 47 b0                                     	add    %rax,-0x50(%r15)
   975f0:	b0 ff                                           	mov    $0xff,%al
   975f2:	88 43 30                                        	mov    %al,0x30(%rbx)
   975f5:	48 83 c4 18                                     	add    $0x18,%rsp
   975f9:	5b                                              	pop    %rbx
   975fa:	41 5c                                           	pop    %r12
   975fc:	41 5d                                           	pop    %r13
   975fe:	41 5e                                           	pop    %r14
   97600:	41 5f                                           	pop    %r15
   97602:	5d                                              	pop    %rbp
   97603:	c3                                              	ret
   97604:	48 8d 3d f7 7b f7 ff                            	lea    -0x88409(%rip),%rdi        # f202 <anon.30029722b35a0dea18e479b6be687fec.245.llvm.7845226830220971649+0x1987>
   9760b:	48 8d 15 c6 61 05 00                            	lea    0x561c6(%rip),%rdx        # ed7d8 <oriole_expat::FEATURES+0x13b0>
   97612:	be 21 00 00 00                                  	mov    $0x21,%esi
   97617:	ff 15 03 78 05 00                               	call   *0x57803(%rip)        # eee20 <_DYNAMIC+0x380>
