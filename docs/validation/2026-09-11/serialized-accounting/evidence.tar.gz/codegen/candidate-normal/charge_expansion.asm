   9b7d0:	41 56                                           	push   %r14
   9b7d2:	53                                              	push   %rbx
   9b7d3:	48 83 ec 18                                     	sub    $0x18,%rsp
   9b7d7:	48 89 d1                                        	mov    %rdx,%rcx
   9b7da:	4c 8b 4e 28                                     	mov    0x28(%rsi),%r9
   9b7de:	4c 8b 86 e8 08 00 00                            	mov    0x8e8(%rsi),%r8
   9b7e5:	83 3e 01                                        	cmpl   $0x1,(%rsi)
   9b7e8:	75 15                                           	jne    9b7ff <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x2f>
   9b7ea:	49 8b 40 30                                     	mov    0x30(%r8),%rax
   9b7ee:	48 f7 66 08                                     	mulq   0x8(%rsi)
   9b7f2:	0f 80 e7 00 00 00                               	jo     9b8df <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x10f>
   9b7f8:	4c 39 c8                                        	cmp    %r9,%rax
   9b7fb:	4c 0f 47 c8                                     	cmova  %rax,%r9
   9b7ff:	49 8b 40 28                                     	mov    0x28(%r8),%rax
   9b803:	48 01 c1                                        	add    %rax,%rcx
   9b806:	48 39 c1                                        	cmp    %rax,%rcx
   9b809:	72 10                                           	jb     9b81b <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x4b>
   9b80b:	4c 39 c9                                        	cmp    %r9,%rcx
   9b80e:	77 0b                                           	ja     9b81b <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x4b>
   9b810:	49 89 48 28                                     	mov    %rcx,0x28(%r8)
   9b814:	b0 ff                                           	mov    $0xff,%al
   9b816:	e9 a0 00 00 00                                  	jmp    9b8bb <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0xeb>
   9b81b:	48 8b 8e 58 02 00 00                            	mov    0x258(%rsi),%rcx
   9b822:	48 85 c9                                        	test   %rcx,%rcx
   9b825:	0f 84 9b 00 00 00                               	je     9b8c6 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0xf6>
   9b82b:	48 8b 86 48 02 00 00                            	mov    0x248(%rsi),%rax
   9b832:	48 8d 0c 49                                     	lea    (%rcx,%rcx,2),%rcx
   9b836:	48 c1 e1 07                                     	shl    $0x7,%rcx
   9b83a:	48 8d 14 08                                     	lea    (%rax,%rcx,1),%rdx
   9b83e:	83 bc 08 80 fe ff ff 01                         	cmpl   $0x1,-0x180(%rax,%rcx,1)
   9b846:	75 1b                                           	jne    9b863 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x93>
   9b848:	48 8d 47 10                                     	lea    0x10(%rdi),%rax
   9b84c:	0f 10 82 88 fe ff ff                            	movups -0x178(%rdx),%xmm0
   9b853:	0f 10 8a 98 fe ff ff                            	movups -0x168(%rdx),%xmm1
   9b85a:	0f 11 48 10                                     	movups %xmm1,0x10(%rax)
   9b85e:	0f 11 00                                        	movups %xmm0,(%rax)
   9b861:	eb 44                                           	jmp    9b8a7 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0xd7>
   9b863:	48 8b 5a a8                                     	mov    -0x58(%rdx),%rbx
   9b867:	0f 10 42 d8                                     	movups -0x28(%rdx),%xmm0
   9b86b:	0f b6 52 fc                                     	movzbl -0x4(%rdx),%edx
   9b86f:	f6 c2 03                                        	test   $0x3,%dl
   9b872:	75 04                                           	jne    9b878 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0xa8>
   9b874:	31 c0                                           	xor    %eax,%eax
   9b876:	eb 23                                           	jmp    9b89b <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0xcb>
   9b878:	48 01 c8                                        	add    %rcx,%rax
   9b87b:	48 05 80 fe ff ff                               	add    $0xfffffffffffffe80,%rax
   9b881:	49 89 fe                                        	mov    %rdi,%r14
   9b884:	48 89 c7                                        	mov    %rax,%rdi
   9b887:	31 f6                                           	xor    %esi,%esi
   9b889:	31 d2                                           	xor    %edx,%edx
   9b88b:	0f 29 04 24                                     	movaps %xmm0,(%rsp)
   9b88f:	e8 ec 34 fa ff                                  	call   3ed80 <<oriole::encoding::Source>::converted_raw_len>
   9b894:	0f 28 04 24                                     	movaps (%rsp),%xmm0
   9b898:	4c 89 f7                                        	mov    %r14,%rdi
   9b89b:	48 89 5f 10                                     	mov    %rbx,0x10(%rdi)
   9b89f:	0f 11 47 18                                     	movups %xmm0,0x18(%rdi)
   9b8a3:	48 89 47 28                                     	mov    %rax,0x28(%rdi)
   9b8a7:	48 8d 05 7e 3d f7 ff                            	lea    -0x8c282(%rip),%rax        # f62c <anon.30029722b35a0dea18e479b6be687fec.245.llvm.7845226830220971649+0x1db1>
   9b8ae:	48 89 07                                        	mov    %rax,(%rdi)
   9b8b1:	48 c7 47 08 24 00 00 00                         	movq   $0x24,0x8(%rdi)
   9b8b9:	b0 1e                                           	mov    $0x1e,%al
   9b8bb:	88 47 30                                        	mov    %al,0x30(%rdi)
   9b8be:	48 83 c4 18                                     	add    $0x18,%rsp
   9b8c2:	5b                                              	pop    %rbx
   9b8c3:	41 5e                                           	pop    %r14
   9b8c5:	c3                                              	ret
   9b8c6:	48 8d 3d 35 39 f7 ff                            	lea    -0x8c6cb(%rip),%rdi        # f202 <anon.30029722b35a0dea18e479b6be687fec.245.llvm.7845226830220971649+0x1987>
   9b8cd:	48 8d 15 04 1f 05 00                            	lea    0x51f04(%rip),%rdx        # ed7d8 <oriole_expat::FEATURES+0x13b0>
   9b8d4:	be 21 00 00 00                                  	mov    $0x21,%esi
   9b8d9:	ff 15 41 35 05 00                               	call   *0x53541(%rip)        # eee20 <_DYNAMIC+0x380>
   9b8df:	48 c7 c0 ff ff ff ff                            	mov    $0xffffffffffffffff,%rax
   9b8e6:	e9 0d ff ff ff                                  	jmp    9b7f8 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x28>
