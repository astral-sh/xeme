0x9b7d0: 4156  push   %r14
0x9b7d2: 53  push   %rbx
0x9b7d3: 4883ec18  sub    $0x18,%rsp
0x9b7d7: 4889d1  mov    %rdx,%rcx
0x9b7da: 4c8b4e28  mov    0x28(%rsi),%r9
0x9b7de: 4c8b86e8080000  mov    0x8e8(%rsi),%r8
0x9b7e5: 833e01  cmpl   $0x1,(%rsi)
0x9b7e8: 7515  jne    9b7ff <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x2f>
0x9b7ea: 498b4030  mov    0x30(%r8),%rax
0x9b7ee: 48f76608  mulq   0x8(%rsi)
0x9b7f2: 0f80e7000000  jo     9b8df <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x10f>
0x9b7f8: 4c39c8  cmp    %r9,%rax
0x9b7fb: 4c0f47c8  cmova  %rax,%r9
0x9b7ff: 498b4028  mov    0x28(%r8),%rax
0x9b803: 4801c1  add    %rax,%rcx
0x9b806: 4839c1  cmp    %rax,%rcx
0x9b809: 7210  jb     9b81b <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x4b>
0x9b80b: 4c39c9  cmp    %r9,%rcx
0x9b80e: 770b  ja     9b81b <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x4b>
0x9b810: 49894828  mov    %rcx,0x28(%r8)
0x9b814: b0ff  mov    $0xff,%al
0x9b816: e9a0000000  jmp    9b8bb <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0xeb>
0x9b81b: 488b8e58020000  mov    0x258(%rsi),%rcx
0x9b822: 4885c9  test   %rcx,%rcx
0x9b825: 0f849b000000  je     9b8c6 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0xf6>
0x9b82b: 488b8648020000  mov    0x248(%rsi),%rax
0x9b832: 488d0c49  lea    (%rcx,%rcx,2),%rcx
0x9b836: 48c1e107  shl    $0x7,%rcx
0x9b83a: 488d1408  lea    (%rax,%rcx,1),%rdx
0x9b83e: 83bc0880feffff01  cmpl   $0x1,-0x180(%rax,%rcx,1)
0x9b846: 751b  jne    9b863 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x93>
0x9b848: 488d4710  lea    0x10(%rdi),%rax
0x9b84c: 0f108288feffff  movups -0x178(%rdx),%xmm0
0x9b853: 0f108a98feffff  movups -0x168(%rdx),%xmm1
0x9b85a: 0f114810  movups %xmm1,0x10(%rax)
0x9b85e: 0f1100  movups %xmm0,(%rax)
0x9b861: eb44  jmp    9b8a7 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0xd7>
0x9b863: 488b5aa8  mov    -0x58(%rdx),%rbx
0x9b867: 0f1042d8  movups -0x28(%rdx),%xmm0
0x9b86b: 0fb652fc  movzbl -0x4(%rdx),%edx
0x9b86f: f6c203  test   $0x3,%dl
0x9b872: 7504  jne    9b878 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0xa8>
0x9b874: 31c0  xor    %eax,%eax
0x9b876: eb23  jmp    9b89b <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0xcb>
0x9b878: 4801c8  add    %rcx,%rax
0x9b87b: 480580feffff  add    $0xfffffffffffffe80,%rax
0x9b881: 4989fe  mov    %rdi,%r14
0x9b884: 4889c7  mov    %rax,%rdi
0x9b887: 31f6  xor    %esi,%esi
0x9b889: 31d2  xor    %edx,%edx
0x9b88b: 0f290424  movaps %xmm0,(%rsp)
0x9b88f: e8ec34faff  call   3ed80 <<oriole::encoding::Source>::converted_raw_len>
0x9b894: 0f280424  movaps (%rsp),%xmm0
0x9b898: 4c89f7  mov    %r14,%rdi
0x9b89b: 48895f10  mov    %rbx,0x10(%rdi)
0x9b89f: 0f114718  movups %xmm0,0x18(%rdi)
0x9b8a3: 48894728  mov    %rax,0x28(%rdi)
0x9b8a7: 488d057e3df7ff  lea    -0x8c282(%rip),%rax        # f62c <anon.30029722b35a0dea18e479b6be687fec.245.llvm.7845226830220971649+0x1db1>
0x9b8ae: 488907  mov    %rax,(%rdi)
0x9b8b1: 48c7470824000000  movq   $0x24,0x8(%rdi)
0x9b8b9: b01e  mov    $0x1e,%al
0x9b8bb: 884730  mov    %al,0x30(%rdi)
0x9b8be: 4883c418  add    $0x18,%rsp
0x9b8c2: 5b  pop    %rbx
0x9b8c3: 415e  pop    %r14
0x9b8c5: c3  ret
0x9b8c6: 488d3d3539f7ff  lea    -0x8c6cb(%rip),%rdi        # f202 <anon.30029722b35a0dea18e479b6be687fec.245.llvm.7845226830220971649+0x1987>
0x9b8cd: 488d15041f0500  lea    0x51f04(%rip),%rdx        # ed7d8 <oriole_expat::FEATURES+0x13b0>
0x9b8d4: be21000000  mov    $0x21,%esi
0x9b8d9: ff1541350500  call   *0x53541(%rip)        # eee20 <_DYNAMIC+0x380>
0x9b8df: 48c7c0ffffffff  mov    $0xffffffffffffffff,%rax
0x9b8e6: e90dffffff  jmp    9b7f8 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x28>
