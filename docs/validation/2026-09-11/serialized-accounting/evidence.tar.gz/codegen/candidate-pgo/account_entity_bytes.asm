   e0f40:	53                                              	push   %rbx
   e0f41:	b0 ff                                           	mov    $0xff,%al
   e0f43:	48 85 d2                                        	test   %rdx,%rdx
   e0f46:	75 05                                           	jne    e0f4d <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0xd>
   e0f48:	88 47 30                                        	mov    %al,0x30(%rdi)
   e0f4b:	5b                                              	pop    %rbx
   e0f4c:	c3                                              	ret
   e0f4d:	48 8b 8e e8 08 00 00                            	mov    0x8e8(%rsi),%rcx
   e0f54:	48 03 51 38                                     	add    0x38(%rcx),%rdx
   e0f58:	0f 82 9b 00 00 00                               	jb     e0ff9 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0xb9>
   e0f5e:	48 89 51 38                                     	mov    %rdx,0x38(%rcx)
   e0f62:	4c 8b 49 30                                     	mov    0x30(%rcx),%r9
   e0f66:	4d 89 ca                                        	mov    %r9,%r10
   e0f69:	49 01 d2                                        	add    %rdx,%r10
   e0f6c:	0f 82 87 00 00 00                               	jb     e0ff9 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0xb9>
   e0f72:	4c 8b 41 40                                     	mov    0x40(%rcx),%r8
   e0f76:	4d 39 c2                                        	cmp    %r8,%r10
   e0f79:	72 cd                                           	jb     e0f48 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x8>
   e0f7b:	49 89 f8                                        	mov    %rdi,%r8
   e0f7e:	4d 85 c9                                        	test   %r9,%r9
   e0f81:	74 0c                                           	je     e0f8f <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x4f>
   e0f83:	4d 85 d2                                        	test   %r10,%r10
   e0f86:	78 24                                           	js     e0fac <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x6c>
   e0f88:	f3 49 0f 2a c2                                  	cvtsi2ss %r10,%xmm0
   e0f8d:	eb 33                                           	jmp    e0fc2 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x82>
   e0f8f:	48 83 fa e9                                     	cmp    $0xffffffffffffffe9,%rdx
   e0f93:	4c 89 c7                                        	mov    %r8,%rdi
   e0f96:	77 61                                           	ja     e0ff9 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0xb9>
   e0f98:	48 83 c2 16                                     	add    $0x16,%rdx
   e0f9c:	0f 88 c4 00 00 00                               	js     e1066 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x126>
   e0fa2:	f3 48 0f 2a c2                                  	cvtsi2ss %rdx,%xmm0
   e0fa7:	e9 cf 00 00 00                                  	jmp    e107b <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x13b>
   e0fac:	4c 89 d2                                        	mov    %r10,%rdx
   e0faf:	48 d1 ea                                        	shr    $1,%rdx
   e0fb2:	41 83 e2 01                                     	and    $0x1,%r10d
   e0fb6:	49 09 d2                                        	or     %rdx,%r10
   e0fb9:	f3 49 0f 2a c2                                  	cvtsi2ss %r10,%xmm0
   e0fbe:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   e0fc2:	4d 85 c9                                        	test   %r9,%r9
   e0fc5:	78 07                                           	js     e0fce <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x8e>
   e0fc7:	f3 49 0f 2a c9                                  	cvtsi2ss %r9,%xmm1
   e0fcc:	eb 16                                           	jmp    e0fe4 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0xa4>
   e0fce:	4c 89 ca                                        	mov    %r9,%rdx
   e0fd1:	48 d1 ea                                        	shr    $1,%rdx
   e0fd4:	41 83 e1 01                                     	and    $0x1,%r9d
   e0fd8:	49 09 d1                                        	or     %rdx,%r9
   e0fdb:	f3 49 0f 2a c9                                  	cvtsi2ss %r9,%xmm1
   e0fe0:	f3 0f 58 c9                                     	addss  %xmm1,%xmm1
   e0fe4:	f3 0f 5e c1                                     	divss  %xmm1,%xmm0
   e0fe8:	f3 0f 10 49 48                                  	movss  0x48(%rcx),%xmm1
   e0fed:	0f 2e c8                                        	ucomiss %xmm0,%xmm1
   e0ff0:	4c 89 c7                                        	mov    %r8,%rdi
   e0ff3:	0f 83 4f ff ff ff                               	jae    e0f48 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x8>
   e0ff9:	48 8b 86 58 02 00 00                            	mov    0x258(%rsi),%rax
   e1000:	48 85 c0                                        	test   %rax,%rax
   e1003:	74 48                                           	je     e104d <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x10d>
   e1005:	48 8b 8e 48 02 00 00                            	mov    0x248(%rsi),%rcx
   e100c:	48 8d 04 40                                     	lea    (%rax,%rax,2),%rax
   e1010:	48 c1 e0 07                                     	shl    $0x7,%rax
   e1014:	48 8d 34 01                                     	lea    (%rcx,%rax,1),%rsi
   e1018:	48 81 c6 80 fe ff ff                            	add    $0xfffffffffffffe80,%rsi
   e101f:	48 8d 47 10                                     	lea    0x10(%rdi),%rax
   e1023:	48 89 fb                                        	mov    %rdi,%rbx
   e1026:	48 89 c7                                        	mov    %rax,%rdi
   e1029:	31 d2                                           	xor    %edx,%edx
   e102b:	ff 15 c7 8c 03 00                               	call   *0x38cc7(%rip)        # 119cf8 <_DYNAMIC+0x738>
   e1031:	48 89 df                                        	mov    %rbx,%rdi
   e1034:	48 8d 05 78 dc f2 ff                            	lea    -0xd2388(%rip),%rax        # ecb3 <anon.b10ce9657b3f93e1697575985b0b062f.244.llvm.6842587102190995845+0x1a25>
   e103b:	48 89 03                                        	mov    %rax,(%rbx)
   e103e:	48 c7 43 08 23 00 00 00                         	movq   $0x23,0x8(%rbx)
   e1046:	b0 1e                                           	mov    $0x1e,%al
   e1048:	e9 fb fe ff ff                                  	jmp    e0f48 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0x8>
   e104d:	48 8d 3d 5b da f2 ff                            	lea    -0xd25a5(%rip),%rdi        # eaaf <anon.b10ce9657b3f93e1697575985b0b062f.244.llvm.6842587102190995845+0x1821>
   e1054:	48 8d 15 4d 73 03 00                            	lea    0x3734d(%rip),%rdx        # 1183a8 <oriole_expat::FEATURES+0x1320>
   e105b:	be 21 00 00 00                                  	mov    $0x21,%esi
   e1060:	ff 15 ea 88 03 00                               	call   *0x388ea(%rip)        # 119950 <_DYNAMIC+0x390>
   e1066:	48 89 d7                                        	mov    %rdx,%rdi
   e1069:	48 d1 ef                                        	shr    $1,%rdi
   e106c:	83 e2 01                                        	and    $0x1,%edx
   e106f:	48 09 fa                                        	or     %rdi,%rdx
   e1072:	f3 48 0f 2a c2                                  	cvtsi2ss %rdx,%xmm0
   e1077:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   e107b:	f3 0f 5e 05 8d a3 f2 ff                         	divss  -0xd5c73(%rip),%xmm0        # b410 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x8c>
   e1083:	e9 60 ff ff ff                                  	jmp    e0fe8 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_entity_bytes+0xa8>
