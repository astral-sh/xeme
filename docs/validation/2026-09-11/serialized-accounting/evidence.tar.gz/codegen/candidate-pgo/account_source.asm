   96210:	55                                              	push   %rbp
   96211:	41 57                                           	push   %r15
   96213:	41 56                                           	push   %r14
   96215:	41 55                                           	push   %r13
   96217:	41 54                                           	push   %r12
   96219:	53                                              	push   %rbx
   9621a:	50                                              	push   %rax
   9621b:	48 8b ae 58 02 00 00                            	mov    0x258(%rsi),%rbp
   96222:	48 85 ed                                        	test   %rbp,%rbp
   96225:	0f 84 bd 00 00 00                               	je     962e8 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0xd8>
   9622b:	49 89 f7                                        	mov    %rsi,%r15
   9622e:	48 89 fb                                        	mov    %rdi,%rbx
   96231:	4c 8b a6 48 02 00 00                            	mov    0x248(%rsi),%r12
   96238:	4c 8d 2c 6d 00 00 00 00                         	lea    0x0(,%rbp,2),%r13
   96240:	49 01 ed                                        	add    %rbp,%r13
   96243:	49 c1 e5 07                                     	shl    $0x7,%r13
   96247:	4f 8d 34 2c                                     	lea    (%r12,%r13,1),%r14
   9624b:	49 81 c6 80 fe ff ff                            	add    $0xfffffffffffffe80,%r14
   96252:	4c 89 f7                                        	mov    %r14,%rdi
   96255:	48 89 d6                                        	mov    %rdx,%rsi
   96258:	ff 15 72 3a 08 00                               	call   *0x83a72(%rip)        # 119cd0 <_DYNAMIC+0x710>
   9625e:	48 85 c0                                        	test   %rax,%rax
   96261:	75 1c                                           	jne    9627f <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x6f>
   96263:	4d 01 ec                                        	add    %r13,%r12
   96266:	49 01 44 24 b0                                  	add    %rax,-0x50(%r12)
   9626b:	b0 ff                                           	mov    $0xff,%al
   9626d:	88 43 30                                        	mov    %al,0x30(%rbx)
   96270:	48 83 c4 08                                     	add    $0x8,%rsp
   96274:	5b                                              	pop    %rbx
   96275:	41 5c                                           	pop    %r12
   96277:	41 5d                                           	pop    %r13
   96279:	41 5e                                           	pop    %r14
   9627b:	41 5f                                           	pop    %r15
   9627d:	5d                                              	pop    %rbp
   9627e:	c3                                              	ret
   9627f:	49 8b 8f e8 08 00 00                            	mov    0x8e8(%r15),%rcx
   96286:	48 83 fd 01                                     	cmp    $0x1,%rbp
   9628a:	40 0f 95 c7                                     	setne  %dil
   9628e:	41 0a bf 5a 09 00 00                            	or     0x95a(%r15),%dil
   96295:	48 8d 71 38                                     	lea    0x38(%rcx),%rsi
   96299:	48 8d 51 30                                     	lea    0x30(%rcx),%rdx
   9629d:	44 0f b6 c7                                     	movzbl %dil,%r8d
   962a1:	45 84 c0                                        	test   %r8b,%r8b
   962a4:	48 89 d7                                        	mov    %rdx,%rdi
   962a7:	48 0f 45 fe                                     	cmovne %rsi,%rdi
   962ab:	4e 8b 44 c1 30                                  	mov    0x30(%rcx,%r8,8),%r8
   962b0:	49 01 c0                                        	add    %rax,%r8
   962b3:	0f 82 a6 00 00 00                               	jb     9635f <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x14f>
   962b9:	4c 89 07                                        	mov    %r8,(%rdi)
   962bc:	48 8b 12                                        	mov    (%rdx),%rdx
   962bf:	48 8b 36                                        	mov    (%rsi),%rsi
   962c2:	48 89 f7                                        	mov    %rsi,%rdi
   962c5:	48 01 d7                                        	add    %rdx,%rdi
   962c8:	0f 82 91 00 00 00                               	jb     9635f <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x14f>
   962ce:	4c 8b 41 40                                     	mov    0x40(%rcx),%r8
   962d2:	4c 39 c7                                        	cmp    %r8,%rdi
   962d5:	72 8c                                           	jb     96263 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x53>
   962d7:	48 85 d2                                        	test   %rdx,%rdx
   962da:	74 25                                           	je     96301 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0xf1>
   962dc:	48 85 ff                                        	test   %rdi,%rdi
   962df:	78 36                                           	js     96317 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x107>
   962e1:	f3 48 0f 2a c7                                  	cvtsi2ss %rdi,%xmm0
   962e6:	eb 44                                           	jmp    9632c <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x11c>
   962e8:	48 8d 3d c0 87 f7 ff                            	lea    -0x87840(%rip),%rdi        # eaaf <anon.b10ce9657b3f93e1697575985b0b062f.244.llvm.6842587102190995845+0x1821>
   962ef:	48 8d 15 b2 20 08 00                            	lea    0x820b2(%rip),%rdx        # 1183a8 <oriole_expat::FEATURES+0x1320>
   962f6:	be 21 00 00 00                                  	mov    $0x21,%esi
   962fb:	ff 15 4f 36 08 00                               	call   *0x8364f(%rip)        # 119950 <_DYNAMIC+0x390>
   96301:	48 83 fe e9                                     	cmp    $0xffffffffffffffe9,%rsi
   96305:	77 58                                           	ja     9635f <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x14f>
   96307:	48 83 c6 16                                     	add    $0x16,%rsi
   9630b:	78 7a                                           	js     96387 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x177>
   9630d:	f3 48 0f 2a c6                                  	cvtsi2ss %rsi,%xmm0
   96312:	e9 85 00 00 00                                  	jmp    9639c <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x18c>
   96317:	48 89 fe                                        	mov    %rdi,%rsi
   9631a:	48 d1 ee                                        	shr    $1,%rsi
   9631d:	83 e7 01                                        	and    $0x1,%edi
   96320:	48 09 f7                                        	or     %rsi,%rdi
   96323:	f3 48 0f 2a c7                                  	cvtsi2ss %rdi,%xmm0
   96328:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   9632c:	48 85 d2                                        	test   %rdx,%rdx
   9632f:	78 07                                           	js     96338 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x128>
   96331:	f3 48 0f 2a ca                                  	cvtsi2ss %rdx,%xmm1
   96336:	eb 15                                           	jmp    9634d <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x13d>
   96338:	48 89 d6                                        	mov    %rdx,%rsi
   9633b:	48 d1 ee                                        	shr    $1,%rsi
   9633e:	83 e2 01                                        	and    $0x1,%edx
   96341:	48 09 f2                                        	or     %rsi,%rdx
   96344:	f3 48 0f 2a ca                                  	cvtsi2ss %rdx,%xmm1
   96349:	f3 0f 58 c9                                     	addss  %xmm1,%xmm1
   9634d:	f3 0f 5e c1                                     	divss  %xmm1,%xmm0
   96351:	f3 0f 10 49 48                                  	movss  0x48(%rcx),%xmm1
   96356:	0f 2e c8                                        	ucomiss %xmm0,%xmm1
   96359:	0f 83 04 ff ff ff                               	jae    96263 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x53>
   9635f:	48 8d 7b 10                                     	lea    0x10(%rbx),%rdi
   96363:	4c 89 f6                                        	mov    %r14,%rsi
   96366:	31 d2                                           	xor    %edx,%edx
   96368:	ff 15 8a 39 08 00                               	call   *0x8398a(%rip)        # 119cf8 <_DYNAMIC+0x738>
   9636e:	48 8d 05 3e 89 f7 ff                            	lea    -0x876c2(%rip),%rax        # ecb3 <anon.b10ce9657b3f93e1697575985b0b062f.244.llvm.6842587102190995845+0x1a25>
   96375:	48 89 03                                        	mov    %rax,(%rbx)
   96378:	48 c7 43 08 23 00 00 00                         	movq   $0x23,0x8(%rbx)
   96380:	b0 1e                                           	mov    $0x1e,%al
   96382:	e9 e6 fe ff ff                                  	jmp    9626d <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x5d>
   96387:	48 89 f2                                        	mov    %rsi,%rdx
   9638a:	48 d1 ea                                        	shr    $1,%rdx
   9638d:	83 e6 01                                        	and    $0x1,%esi
   96390:	48 09 d6                                        	or     %rdx,%rsi
   96393:	f3 48 0f 2a c6                                  	cvtsi2ss %rsi,%xmm0
   96398:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   9639c:	f3 0f 5e 05 6c 50 f7 ff                         	divss  -0x8af94(%rip),%xmm0        # b410 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x8c>
   963a4:	eb ab                                           	jmp    96351 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::account_source+0x141>
