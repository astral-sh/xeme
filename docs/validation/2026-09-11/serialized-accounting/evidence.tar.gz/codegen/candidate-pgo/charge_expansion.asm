   aa450:	53                                              	push   %rbx
   aa451:	48 89 d1                                        	mov    %rdx,%rcx
   aa454:	4c 8b 4e 28                                     	mov    0x28(%rsi),%r9
   aa458:	4c 8b 86 e8 08 00 00                            	mov    0x8e8(%rsi),%r8
   aa45f:	83 3e 01                                        	cmpl   $0x1,(%rsi)
   aa462:	75 11                                           	jne    aa475 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x25>
   aa464:	49 8b 40 30                                     	mov    0x30(%r8),%rax
   aa468:	48 f7 66 08                                     	mulq   0x8(%rsi)
   aa46c:	70 71                                           	jo     aa4df <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x8f>
   aa46e:	4c 39 c8                                        	cmp    %r9,%rax
   aa471:	4c 0f 47 c8                                     	cmova  %rax,%r9
   aa475:	49 8b 40 28                                     	mov    0x28(%r8),%rax
   aa479:	48 01 c1                                        	add    %rax,%rcx
   aa47c:	48 39 c1                                        	cmp    %rax,%rcx
   aa47f:	72 10                                           	jb     aa491 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x41>
   aa481:	4c 39 c9                                        	cmp    %r9,%rcx
   aa484:	77 0b                                           	ja     aa491 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x41>
   aa486:	49 89 48 28                                     	mov    %rcx,0x28(%r8)
   aa48a:	b0 ff                                           	mov    $0xff,%al
   aa48c:	88 47 30                                        	mov    %al,0x30(%rdi)
   aa48f:	5b                                              	pop    %rbx
   aa490:	c3                                              	ret
   aa491:	48 8b 86 58 02 00 00                            	mov    0x258(%rsi),%rax
   aa498:	48 85 c0                                        	test   %rax,%rax
   aa49b:	74 4b                                           	je     aa4e8 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x98>
   aa49d:	48 8b 8e 48 02 00 00                            	mov    0x248(%rsi),%rcx
   aa4a4:	48 8d 04 40                                     	lea    (%rax,%rax,2),%rax
   aa4a8:	48 c1 e0 07                                     	shl    $0x7,%rax
   aa4ac:	48 8d 34 01                                     	lea    (%rcx,%rax,1),%rsi
   aa4b0:	48 81 c6 80 fe ff ff                            	add    $0xfffffffffffffe80,%rsi
   aa4b7:	48 89 fb                                        	mov    %rdi,%rbx
   aa4ba:	48 83 c7 10                                     	add    $0x10,%rdi
   aa4be:	31 d2                                           	xor    %edx,%edx
   aa4c0:	ff 15 32 f8 06 00                               	call   *0x6f832(%rip)        # 119cf8 <_DYNAMIC+0x738>
   aa4c6:	48 89 df                                        	mov    %rbx,%rdi
   aa4c9:	48 8d 05 09 4a f6 ff                            	lea    -0x9b5f7(%rip),%rax        # eed9 <anon.b10ce9657b3f93e1697575985b0b062f.244.llvm.6842587102190995845+0x1c4b>
   aa4d0:	48 89 03                                        	mov    %rax,(%rbx)
   aa4d3:	48 c7 43 08 24 00 00 00                         	movq   $0x24,0x8(%rbx)
   aa4db:	b0 1e                                           	mov    $0x1e,%al
   aa4dd:	eb ad                                           	jmp    aa48c <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x3c>
   aa4df:	48 c7 c0 ff ff ff ff                            	mov    $0xffffffffffffffff,%rax
   aa4e6:	eb 86                                           	jmp    aa46e <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x1e>
   aa4e8:	48 8d 3d c0 45 f6 ff                            	lea    -0x9ba40(%rip),%rdi        # eaaf <anon.b10ce9657b3f93e1697575985b0b062f.244.llvm.6842587102190995845+0x1821>
   aa4ef:	48 8d 15 b2 de 06 00                            	lea    0x6deb2(%rip),%rdx        # 1183a8 <oriole_expat::FEATURES+0x1320>
   aa4f6:	be 21 00 00 00                                  	mov    $0x21,%esi
   aa4fb:	ff 15 4f f4 06 00                               	call   *0x6f44f(%rip)        # 119950 <_DYNAMIC+0x390>
