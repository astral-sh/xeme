0xaa450: 53  push   %rbx
0xaa451: 4889d1  mov    %rdx,%rcx
0xaa454: 4c8b4e28  mov    0x28(%rsi),%r9
0xaa458: 4c8b86e8080000  mov    0x8e8(%rsi),%r8
0xaa45f: 833e01  cmpl   $0x1,(%rsi)
0xaa462: 7511  jne    aa475 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x25>
0xaa464: 498b4030  mov    0x30(%r8),%rax
0xaa468: 48f76608  mulq   0x8(%rsi)
0xaa46c: 7071  jo     aa4df <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x8f>
0xaa46e: 4c39c8  cmp    %r9,%rax
0xaa471: 4c0f47c8  cmova  %rax,%r9
0xaa475: 498b4028  mov    0x28(%r8),%rax
0xaa479: 4801c1  add    %rax,%rcx
0xaa47c: 4839c1  cmp    %rax,%rcx
0xaa47f: 7210  jb     aa491 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x41>
0xaa481: 4c39c9  cmp    %r9,%rcx
0xaa484: 770b  ja     aa491 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x41>
0xaa486: 49894828  mov    %rcx,0x28(%r8)
0xaa48a: b0ff  mov    $0xff,%al
0xaa48c: 884730  mov    %al,0x30(%rdi)
0xaa48f: 5b  pop    %rbx
0xaa490: c3  ret
0xaa491: 488b8658020000  mov    0x258(%rsi),%rax
0xaa498: 4885c0  test   %rax,%rax
0xaa49b: 744b  je     aa4e8 <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x98>
0xaa49d: 488b8e48020000  mov    0x248(%rsi),%rcx
0xaa4a4: 488d0440  lea    (%rax,%rax,2),%rax
0xaa4a8: 48c1e007  shl    $0x7,%rax
0xaa4ac: 488d3401  lea    (%rcx,%rax,1),%rsi
0xaa4b0: 4881c680feffff  add    $0xfffffffffffffe80,%rsi
0xaa4b7: 4889fb  mov    %rdi,%rbx
0xaa4ba: 4883c710  add    $0x10,%rdi
0xaa4be: 31d2  xor    %edx,%edx
0xaa4c0: ff1532f80600  call   *0x6f832(%rip)        # 119cf8 <_DYNAMIC+0x738>
0xaa4c6: 4889df  mov    %rbx,%rdi
0xaa4c9: 488d05094af6ff  lea    -0x9b5f7(%rip),%rax        # eed9 <anon.b10ce9657b3f93e1697575985b0b062f.244.llvm.6842587102190995845+0x1c4b>
0xaa4d0: 488903  mov    %rax,(%rbx)
0xaa4d3: 48c7430824000000  movq   $0x24,0x8(%rbx)
0xaa4db: b01e  mov    $0x1e,%al
0xaa4dd: ebad  jmp    aa48c <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x3c>
0xaa4df: 48c7c0ffffffff  mov    $0xffffffffffffffff,%rax
0xaa4e6: eb86  jmp    aa46e <<oriole::ParserCore<oriole::accounting::SerializedMode>>::charge_expansion+0x1e>
0xaa4e8: 488d3dc045f6ff  lea    -0x9ba40(%rip),%rdi        # eaaf <anon.b10ce9657b3f93e1697575985b0b062f.244.llvm.6842587102190995845+0x1821>
0xaa4ef: 488d15b2de0600  lea    0x6deb2(%rip),%rdx        # 1183a8 <oriole_expat::FEATURES+0x1320>
0xaa4f6: be21000000  mov    $0x21,%esi
0xaa4fb: ff154ff40600  call   *0x6f44f(%rip)        # 119950 <_DYNAMIC+0x390>
