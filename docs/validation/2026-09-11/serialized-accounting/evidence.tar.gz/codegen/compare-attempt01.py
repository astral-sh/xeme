"""Summarize already-verified release ELF records and selected source regions."""
import hashlib
import json
from pathlib import Path
import re
import struct

root = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def footprint(path):
    data = path.read_bytes()
    shoff = struct.unpack_from('<Q', data, 40)[0]
    shsize, shcount, strings_index = struct.unpack_from('<HH', data, 58)
    headers = [struct.unpack_from('<IIQQQQIIQQ', data, shoff + index * shsize) for index in range(shcount)]
    names_header = headers[strings_index]
    names = data[names_header[4]:names_header[4] + names_header[5]]
    text = []
    executable = 0
    for name_offset, _, flags, _, _, size, *_ in headers:
        name = names[name_offset:names.index(0, name_offset)].decode()
        if flags & 4:
            executable += size
        if name == '.text':
            text.append(size)
    assert len(text) == 1
    return {'file_bytes': len(data), 'text_section_bytes': text[0], 'executable_section_bytes': executable}


report = {'variants': {}, 'scope': 'Exact released ELF bytes and static source-corresponding regions, not dynamic counts or speed predictions.'}
stores = {'candidate-normal': {'account_source': 0x974c9, 'charge_expansion': 0x9b810},
          'candidate-pgo': {'account_source': 0x962b9, 'charge_expansion': 0xaa486}}
for name in ['control-normal-02', 'control-pgo-02', 'candidate-normal', 'candidate-pgo']:
    saved = root / name
    record = json.loads((saved / 'report.json').read_text())
    library = Path(record['library'])
    assert sha(library) == record['library_sha256']
    for tool in ['nm', 'objdump']:
        run = json.loads((saved / f'{tool}.json').read_text())
        assert run['exit'] == 0 and run['reaped']
        assert sha(saved / f'{tool}.stdout') == run['stdout_sha256']
    assembly = []
    for line in (saved / 'objdump.stdout').read_text().splitlines():
        match = re.match(r'^\s*([0-9a-fA-F]+):\s*((?:[0-9a-fA-F]{2}\s+)+)(\S.*)?$', line)
        if match:
            assembly.append((int(match[1], 16), line))
    methods = {}
    for line in (saved / 'nm.stdout').read_text().splitlines():
        match = re.fullmatch(r'([0-9a-fA-F]+) ([0-9a-fA-F]+) ([tT]) (.+)', line)
        if not match:
            continue
        address, size, symbol = int(match[1], 16), int(match[2], 16), match[4]
        method = symbol.rsplit('::', 1)[-1]
        if method not in {'account_source', 'account_entity_bytes', 'charge_expansion'}:
            continue
        rows = [(pc, text) for pc, text in assembly if address <= pc < address + size]
        assert method not in methods
        methods[method] = {'symbol': symbol, 'address': hex(address), 'symbol_bytes': size,
                           'static_instruction_rows': len(rows),
                           'locked_or_cas_rows': [text.strip() for _, text in rows if re.search(r'\block\b|\bcmpxchg\w*\b', text)],
                           'calls': [text.strip() for _, text in rows if re.search(r'\bcall\s', text)]}
        (saved / f'{method}.asm').write_text('\n'.join(text for _, text in rows) + '\n')
        if name in stores and method in stores[name]:
            selected = [text.strip() for pc, text in rows if pc == stores[name][method]]
            assert len(selected) == 1 and 'mov' in selected[0]
            assert not methods[method]['locked_or_cas_rows']
            methods[method]['reviewed_counter_store'] = selected[0]
    report['variants'][name] = {'library': str(library), 'sha256': sha(library),
                               'static_readback_sha256': sha(saved / 'report.json'),
                               **footprint(library), 'methods': methods,
                               'remaining_storage_atomic_examples': record['storage_helpers_with_atomics']}
report['changes'] = {}
for mode in ['normal', 'pgo']:
    control = report['variants'][f'control-{mode}-02']
    candidate = report['variants'][f'candidate-{mode}']
    report['changes'][mode] = {field: {'control': control[field], 'candidate': candidate[field],
                                     'difference': candidate[field] - control[field],
                                     'percent': 100 * (candidate[field] / control[field] - 1)}
                                for field in ['file_bytes', 'text_section_bytes', 'executable_section_bytes']}
    for method in ['account_source', 'charge_expansion']:
        assert len(control['methods'][method]['locked_or_cas_rows']) == 1
        assert not candidate['methods'][method]['locked_or_cas_rows']
source_root = Path('/home/dev-user/code/oss/oriole-serialized-accounting')
control_root = Path('/home/dev-user/code/oss/oriole-suffix-element-names')
report['storage_source_equal'] = {}
for name in ['shared.rs', 'tracking.rs', 'allocator.rs']:
    path = Path('crates/oriole_storage/src') / name
    assert sha(source_root / path) == sha(control_root / path)
    report['storage_source_equal'][str(path)] = sha(source_root / path)
report['limitations'] = [
    'Only named source-accounting and work-charge regions are compared; no whole-parser lock-count inference.',
    'PGO control EntityBudget::account is an outlined indirect/enforced specialization; candidate has no such symbol.',
    'Inlining differs: PGO account_source shrinks partly because source accounting bytes/position helpers are outlined.',
    'PGO charge_expansion grows even though its counter CAS is removed; symbol size is not performance.',
    'Refcount and allocation/tracker atomics remain. Their source bytes match; complete generated helper bytes are not claimed identical.',
    'Private heap EntityBudget layout and runtime memory were not measured.',
]
report['reader_sha256'] = sha(Path(__file__))
(root / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['changes'], indent=2))
