   947b0:	41 56                                           	push   %r14
   947b2:	53                                              	push   %rbx
   947b3:	48 83 ec 18                                     	sub    $0x18,%rsp
   947b7:	41 b0 ff                                        	mov    $0xff,%r8b
   947ba:	48 85 d2                                        	test   %rdx,%rdx
   947bd:	0f 84 9e 01 00 00                               	je     94961 <<oriole::Parser>::account_entity_bytes+0x1b1>
   947c3:	4c 8b 8e e8 08 00 00                            	mov    0x8e8(%rsi),%r9
   947ca:	49 8b 41 38                                     	mov    0x38(%r9),%rax
   947ce:	66 90                                           	xchg   %ax,%ax
   947d0:	49 89 c2                                        	mov    %rax,%r10
   947d3:	49 01 d2                                        	add    %rdx,%r10
   947d6:	0f 82 e8 00 00 00                               	jb     948c4 <<oriole::Parser>::account_entity_bytes+0x114>
   947dc:	f0 4d 0f b1 51 38                               	lock cmpxchg %r10,0x38(%r9)
   947e2:	75 ec                                           	jne    947d0 <<oriole::Parser>::account_entity_bytes+0x20>
   947e4:	49 8b 41 30                                     	mov    0x30(%r9),%rax
   947e8:	49 8b 51 38                                     	mov    0x38(%r9),%rdx
   947ec:	4c 8d 14 02                                     	lea    (%rdx,%rax,1),%r10
   947f0:	84 c9                                           	test   %cl,%cl
   947f2:	74 53                                           	je     94847 <<oriole::Parser>::account_entity_bytes+0x97>
   947f4:	49 39 c2                                        	cmp    %rax,%r10
   947f7:	72 4e                                           	jb     94847 <<oriole::Parser>::account_entity_bytes+0x97>
   947f9:	49 8b 49 40                                     	mov    0x40(%r9),%rcx
   947fd:	49 39 ca                                        	cmp    %rcx,%r10
   94800:	0f 82 5b 01 00 00                               	jb     94961 <<oriole::Parser>::account_entity_bytes+0x1b1>
   94806:	48 85 c0                                        	test   %rax,%rax
   94809:	74 46                                           	je     94851 <<oriole::Parser>::account_entity_bytes+0xa1>
   9480b:	4d 85 d2                                        	test   %r10,%r10
   9480e:	78 54                                           	js     94864 <<oriole::Parser>::account_entity_bytes+0xb4>
   94810:	f3 49 0f 2a c2                                  	cvtsi2ss %r10,%xmm0
   94815:	48 85 c0                                        	test   %rax,%rax
   94818:	79 65                                           	jns    9487f <<oriole::Parser>::account_entity_bytes+0xcf>
   9481a:	48 89 c1                                        	mov    %rax,%rcx
   9481d:	48 d1 e9                                        	shr    $1,%rcx
   94820:	83 e0 01                                        	and    $0x1,%eax
   94823:	48 09 c8                                        	or     %rcx,%rax
   94826:	f3 48 0f 2a c8                                  	cvtsi2ss %rax,%xmm1
   9482b:	f3 0f 58 c9                                     	addss  %xmm1,%xmm1
   9482f:	f3 0f 5e c1                                     	divss  %xmm1,%xmm0
   94833:	f3 41 0f 10 49 48                               	movss  0x48(%r9),%xmm1
   94839:	0f 2e c8                                        	ucomiss %xmm0,%xmm1
   9483c:	0f 82 82 00 00 00                               	jb     948c4 <<oriole::Parser>::account_entity_bytes+0x114>
   94842:	e9 1a 01 00 00                                  	jmp    94961 <<oriole::Parser>::account_entity_bytes+0x1b1>
   94847:	49 39 c2                                        	cmp    %rax,%r10
   9484a:	72 78                                           	jb     948c4 <<oriole::Parser>::account_entity_bytes+0x114>
   9484c:	e9 10 01 00 00                                  	jmp    94961 <<oriole::Parser>::account_entity_bytes+0x1b1>
   94851:	48 83 fa e9                                     	cmp    $0xffffffffffffffe9,%rdx
   94855:	77 6d                                           	ja     948c4 <<oriole::Parser>::account_entity_bytes+0x114>
   94857:	48 83 c2 16                                     	add    $0x16,%rdx
   9485b:	78 3b                                           	js     94898 <<oriole::Parser>::account_entity_bytes+0xe8>
   9485d:	f3 48 0f 2a c2                                  	cvtsi2ss %rdx,%xmm0
   94862:	eb 49                                           	jmp    948ad <<oriole::Parser>::account_entity_bytes+0xfd>
   94864:	4c 89 d1                                        	mov    %r10,%rcx
   94867:	48 d1 e9                                        	shr    $1,%rcx
   9486a:	41 83 e2 01                                     	and    $0x1,%r10d
   9486e:	49 09 ca                                        	or     %rcx,%r10
   94871:	f3 49 0f 2a c2                                  	cvtsi2ss %r10,%xmm0
   94876:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   9487a:	48 85 c0                                        	test   %rax,%rax
   9487d:	78 9b                                           	js     9481a <<oriole::Parser>::account_entity_bytes+0x6a>
   9487f:	f3 48 0f 2a c8                                  	cvtsi2ss %rax,%xmm1
   94884:	f3 0f 5e c1                                     	divss  %xmm1,%xmm0
   94888:	f3 41 0f 10 49 48                               	movss  0x48(%r9),%xmm1
   9488e:	0f 2e c8                                        	ucomiss %xmm0,%xmm1
   94891:	72 31                                           	jb     948c4 <<oriole::Parser>::account_entity_bytes+0x114>
   94893:	e9 c9 00 00 00                                  	jmp    94961 <<oriole::Parser>::account_entity_bytes+0x1b1>
   94898:	48 89 d0                                        	mov    %rdx,%rax
   9489b:	48 d1 e8                                        	shr    $1,%rax
   9489e:	83 e2 01                                        	and    $0x1,%edx
   948a1:	48 09 c2                                        	or     %rax,%rdx
   948a4:	f3 48 0f 2a c2                                  	cvtsi2ss %rdx,%xmm0
   948a9:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   948ad:	f3 0f 5e 05 fb 67 f7 ff                         	divss  -0x89805(%rip),%xmm0        # b0b0 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x8c>
   948b5:	f3 41 0f 10 49 48                               	movss  0x48(%r9),%xmm1
   948bb:	0f 2e c8                                        	ucomiss %xmm0,%xmm1
   948be:	0f 83 9d 00 00 00                               	jae    94961 <<oriole::Parser>::account_entity_bytes+0x1b1>
   948c4:	48 8b 8e 58 02 00 00                            	mov    0x258(%rsi),%rcx
   948cb:	48 85 c9                                        	test   %rcx,%rcx
   948ce:	0f 84 99 00 00 00                               	je     9496d <<oriole::Parser>::account_entity_bytes+0x1bd>
   948d4:	48 8b 86 48 02 00 00                            	mov    0x248(%rsi),%rax
   948db:	48 8d 0c 49                                     	lea    (%rcx,%rcx,2),%rcx
   948df:	48 c1 e1 07                                     	shl    $0x7,%rcx
   948e3:	48 8d 14 08                                     	lea    (%rax,%rcx,1),%rdx
   948e7:	83 bc 08 80 fe ff ff 01                         	cmpl   $0x1,-0x180(%rax,%rcx,1)
   948ef:	75 17                                           	jne    94908 <<oriole::Parser>::account_entity_bytes+0x158>
   948f1:	48 8b 9a 88 fe ff ff                            	mov    -0x178(%rdx),%rbx
   948f8:	0f 10 82 90 fe ff ff                            	movups -0x170(%rdx),%xmm0
   948ff:	48 8b 82 a0 fe ff ff                            	mov    -0x160(%rdx),%rax
   94906:	eb 38                                           	jmp    94940 <<oriole::Parser>::account_entity_bytes+0x190>
   94908:	48 8b 5a a8                                     	mov    -0x58(%rdx),%rbx
   9490c:	0f 10 42 d8                                     	movups -0x28(%rdx),%xmm0
   94910:	0f b6 52 fc                                     	movzbl -0x4(%rdx),%edx
   94914:	f6 c2 03                                        	test   $0x3,%dl
   94917:	75 04                                           	jne    9491d <<oriole::Parser>::account_entity_bytes+0x16d>
   94919:	31 c0                                           	xor    %eax,%eax
   9491b:	eb 23                                           	jmp    94940 <<oriole::Parser>::account_entity_bytes+0x190>
   9491d:	48 01 c8                                        	add    %rcx,%rax
   94920:	48 05 80 fe ff ff                               	add    $0xfffffffffffffe80,%rax
   94926:	49 89 fe                                        	mov    %rdi,%r14
   94929:	48 89 c7                                        	mov    %rax,%rdi
   9492c:	31 f6                                           	xor    %esi,%esi
   9492e:	31 d2                                           	xor    %edx,%edx
   94930:	0f 29 04 24                                     	movaps %xmm0,(%rsp)
   94934:	e8 b7 72 fd ff                                  	call   6bbf0 <<oriole::encoding::Source>::converted_raw_len>
   94939:	0f 28 04 24                                     	movaps (%rsp),%xmm0
   9493d:	4c 89 f7                                        	mov    %r14,%rdi
   94940:	48 8d 0d 7f 9a f7 ff                            	lea    -0x86581(%rip),%rcx        # e3c6 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.70.llvm.2776412514376943886+0x1bf7>
   94947:	48 89 0f                                        	mov    %rcx,(%rdi)
   9494a:	48 c7 47 08 23 00 00 00                         	movq   $0x23,0x8(%rdi)
   94952:	48 89 5f 10                                     	mov    %rbx,0x10(%rdi)
   94956:	0f 11 47 18                                     	movups %xmm0,0x18(%rdi)
   9495a:	48 89 47 28                                     	mov    %rax,0x28(%rdi)
   9495e:	41 b0 1e                                        	mov    $0x1e,%r8b
   94961:	44 88 47 30                                     	mov    %r8b,0x30(%rdi)
   94965:	48 83 c4 18                                     	add    $0x18,%rsp
   94969:	5b                                              	pop    %rbx
   9496a:	41 5e                                           	pop    %r14
   9496c:	c3                                              	ret
   9496d:	48 8d 3d 46 98 f7 ff                            	lea    -0x867ba(%rip),%rdi        # e1ba <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.70.llvm.2776412514376943886+0x19eb>
   94974:	48 8d 15 6d 98 05 00                            	lea    0x5986d(%rip),%rdx        # ee1e8 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.381.llvm.2776412514376943886+0xc18>
   9497b:	be 21 00 00 00                                  	mov    $0x21,%esi
   94980:	ff 15 c2 b2 05 00                               	call   *0x5b2c2(%rip)        # efc48 <_DYNAMIC+0x380>
