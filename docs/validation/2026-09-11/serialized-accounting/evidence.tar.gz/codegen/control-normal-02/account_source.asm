   86670:	55                                              	push   %rbp
   86671:	41 57                                           	push   %r15
   86673:	41 56                                           	push   %r14
   86675:	41 55                                           	push   %r13
   86677:	41 54                                           	push   %r12
   86679:	53                                              	push   %rbx
   8667a:	48 83 ec 18                                     	sub    $0x18,%rsp
   8667e:	4c 8b a6 58 02 00 00                            	mov    0x258(%rsi),%r12
   86685:	4d 85 e4                                        	test   %r12,%r12
   86688:	0f 84 c4 01 00 00                               	je     86852 <<oriole::Parser>::account_source+0x1e2>
   8668e:	48 89 fb                                        	mov    %rdi,%rbx
   86691:	48 8b 86 48 02 00 00                            	mov    0x248(%rsi),%rax
   86698:	4b 8d 0c 64                                     	lea    (%r12,%r12,2),%rcx
   8669c:	48 c1 e1 07                                     	shl    $0x7,%rcx
   866a0:	4c 8d 3c 08                                     	lea    (%rax,%rcx,1),%r15
   866a4:	4c 8d 34 08                                     	lea    (%rax,%rcx,1),%r14
   866a8:	49 81 c6 80 fe ff ff                            	add    $0xfffffffffffffe80,%r14
   866af:	4c 8b 6c 08 a8                                  	mov    -0x58(%rax,%rcx,1),%r13
   866b4:	0f b6 44 08 fc                                  	movzbl -0x4(%rax,%rcx,1),%eax
   866b9:	a8 03                                           	test   $0x3,%al
   866bb:	74 13                                           	je     866d0 <<oriole::Parser>::account_source+0x60>
   866bd:	4c 89 f7                                        	mov    %r14,%rdi
   866c0:	48 89 f5                                        	mov    %rsi,%rbp
   866c3:	31 f6                                           	xor    %esi,%esi
   866c5:	e8 26 55 fe ff                                  	call   6bbf0 <<oriole::encoding::Source>::converted_raw_len>
   866ca:	48 89 ee                                        	mov    %rbp,%rsi
   866cd:	48 89 c2                                        	mov    %rax,%rdx
   866d0:	4c 01 ea                                        	add    %r13,%rdx
   866d3:	31 c9                                           	xor    %ecx,%ecx
   866d5:	49 2b 57 b0                                     	sub    -0x50(%r15),%rdx
   866d9:	48 0f 43 ca                                     	cmovae %rdx,%rcx
   866dd:	0f 86 57 01 00 00                               	jbe    8683a <<oriole::Parser>::account_source+0x1ca>
   866e3:	48 8b 96 e8 08 00 00                            	mov    0x8e8(%rsi),%rdx
   866ea:	49 83 fc 01                                     	cmp    $0x1,%r12
   866ee:	0f 95 c0                                        	setne  %al
   866f1:	0a 86 5a 09 00 00                               	or     0x95a(%rsi),%al
   866f7:	48 8d 72 38                                     	lea    0x38(%rdx),%rsi
   866fb:	48 8d 7a 30                                     	lea    0x30(%rdx),%rdi
   866ff:	0f b6 c0                                        	movzbl %al,%eax
   86702:	84 c0                                           	test   %al,%al
   86704:	49 89 f8                                        	mov    %rdi,%r8
   86707:	4c 0f 45 c6                                     	cmovne %rsi,%r8
   8670b:	48 8b 44 c2 30                                  	mov    0x30(%rdx,%rax,8),%rax
   86710:	49 89 c1                                        	mov    %rax,%r9
   86713:	49 01 c9                                        	add    %rcx,%r9
   86716:	72 15                                           	jb     8672d <<oriole::Parser>::account_source+0xbd>
   86718:	f0 4d 0f b1 08                                  	lock cmpxchg %r9,(%r8)
   8671d:	75 f1                                           	jne    86710 <<oriole::Parser>::account_source+0xa0>
   8671f:	48 8b 07                                        	mov    (%rdi),%rax
   86722:	48 8b 36                                        	mov    (%rsi),%rsi
   86725:	48 89 f7                                        	mov    %rsi,%rdi
   86728:	48 01 c7                                        	add    %rax,%rdi
   8672b:	73 34                                           	jae    86761 <<oriole::Parser>::account_source+0xf1>
   8672d:	41 83 3e 01                                     	cmpl   $0x1,(%r14)
   86731:	75 18                                           	jne    8674b <<oriole::Parser>::account_source+0xdb>
   86733:	4d 8b a7 88 fe ff ff                            	mov    -0x178(%r15),%r12
   8673a:	41 0f 10 87 90 fe ff ff                         	movups -0x170(%r15),%xmm0
   86742:	49 8b 87 a0 fe ff ff                            	mov    -0x160(%r15),%rax
   86749:	eb 48                                           	jmp    86793 <<oriole::Parser>::account_source+0x123>
   8674b:	4d 8b 67 a8                                     	mov    -0x58(%r15),%r12
   8674f:	41 0f 10 47 d8                                  	movups -0x28(%r15),%xmm0
   86754:	41 0f b6 47 fc                                  	movzbl -0x4(%r15),%eax
   86759:	a8 03                                           	test   $0x3,%al
   8675b:	75 22                                           	jne    8677f <<oriole::Parser>::account_source+0x10f>
   8675d:	31 c0                                           	xor    %eax,%eax
   8675f:	eb 32                                           	jmp    86793 <<oriole::Parser>::account_source+0x123>
   86761:	4c 8b 42 40                                     	mov    0x40(%rdx),%r8
   86765:	4c 39 c7                                        	cmp    %r8,%rdi
   86768:	0f 82 cc 00 00 00                               	jb     8683a <<oriole::Parser>::account_source+0x1ca>
   8676e:	48 85 c0                                        	test   %rax,%rax
   86771:	74 45                                           	je     867b8 <<oriole::Parser>::account_source+0x148>
   86773:	48 85 ff                                        	test   %rdi,%rdi
   86776:	78 57                                           	js     867cf <<oriole::Parser>::account_source+0x15f>
   86778:	f3 48 0f 2a c7                                  	cvtsi2ss %rdi,%xmm0
   8677d:	eb 65                                           	jmp    867e4 <<oriole::Parser>::account_source+0x174>
   8677f:	4c 89 f7                                        	mov    %r14,%rdi
   86782:	31 f6                                           	xor    %esi,%esi
   86784:	31 d2                                           	xor    %edx,%edx
   86786:	0f 29 04 24                                     	movaps %xmm0,(%rsp)
   8678a:	e8 61 54 fe ff                                  	call   6bbf0 <<oriole::encoding::Source>::converted_raw_len>
   8678f:	0f 28 04 24                                     	movaps (%rsp),%xmm0
   86793:	48 8d 0d 2c 7c f8 ff                            	lea    -0x783d4(%rip),%rcx        # e3c6 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.70.llvm.2776412514376943886+0x1bf7>
   8679a:	48 89 0b                                        	mov    %rcx,(%rbx)
   8679d:	48 c7 43 08 23 00 00 00                         	movq   $0x23,0x8(%rbx)
   867a5:	4c 89 63 10                                     	mov    %r12,0x10(%rbx)
   867a9:	0f 11 43 18                                     	movups %xmm0,0x18(%rbx)
   867ad:	48 89 43 28                                     	mov    %rax,0x28(%rbx)
   867b1:	b0 1e                                           	mov    $0x1e,%al
   867b3:	e9 88 00 00 00                                  	jmp    86840 <<oriole::Parser>::account_source+0x1d0>
   867b8:	48 83 fe e9                                     	cmp    $0xffffffffffffffe9,%rsi
   867bc:	0f 87 6b ff ff ff                               	ja     8672d <<oriole::Parser>::account_source+0xbd>
   867c2:	48 83 c6 16                                     	add    $0x16,%rsi
   867c6:	78 47                                           	js     8680f <<oriole::Parser>::account_source+0x19f>
   867c8:	f3 48 0f 2a c6                                  	cvtsi2ss %rsi,%xmm0
   867cd:	eb 55                                           	jmp    86824 <<oriole::Parser>::account_source+0x1b4>
   867cf:	48 89 fe                                        	mov    %rdi,%rsi
   867d2:	48 d1 ee                                        	shr    $1,%rsi
   867d5:	83 e7 01                                        	and    $0x1,%edi
   867d8:	48 09 f7                                        	or     %rsi,%rdi
   867db:	f3 48 0f 2a c7                                  	cvtsi2ss %rdi,%xmm0
   867e0:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   867e4:	48 85 c0                                        	test   %rax,%rax
   867e7:	78 0b                                           	js     867f4 <<oriole::Parser>::account_source+0x184>
   867e9:	f3 48 0f 2a c8                                  	cvtsi2ss %rax,%xmm1
   867ee:	f3 0f 5e c1                                     	divss  %xmm1,%xmm0
   867f2:	eb 38                                           	jmp    8682c <<oriole::Parser>::account_source+0x1bc>
   867f4:	48 89 c6                                        	mov    %rax,%rsi
   867f7:	48 d1 ee                                        	shr    $1,%rsi
   867fa:	83 e0 01                                        	and    $0x1,%eax
   867fd:	48 09 f0                                        	or     %rsi,%rax
   86800:	f3 48 0f 2a c8                                  	cvtsi2ss %rax,%xmm1
   86805:	f3 0f 58 c9                                     	addss  %xmm1,%xmm1
   86809:	f3 0f 5e c1                                     	divss  %xmm1,%xmm0
   8680d:	eb 1d                                           	jmp    8682c <<oriole::Parser>::account_source+0x1bc>
   8680f:	48 89 f0                                        	mov    %rsi,%rax
   86812:	48 d1 e8                                        	shr    $1,%rax
   86815:	83 e6 01                                        	and    $0x1,%esi
   86818:	48 09 c6                                        	or     %rax,%rsi
   8681b:	f3 48 0f 2a c6                                  	cvtsi2ss %rsi,%xmm0
   86820:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   86824:	f3 0f 5e 05 84 48 f8 ff                         	divss  -0x7b77c(%rip),%xmm0        # b0b0 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x8c>
   8682c:	f3 0f 10 4a 48                                  	movss  0x48(%rdx),%xmm1
   86831:	0f 2e c8                                        	ucomiss %xmm0,%xmm1
   86834:	0f 82 f3 fe ff ff                               	jb     8672d <<oriole::Parser>::account_source+0xbd>
   8683a:	49 01 4f b0                                     	add    %rcx,-0x50(%r15)
   8683e:	b0 ff                                           	mov    $0xff,%al
   86840:	88 43 30                                        	mov    %al,0x30(%rbx)
   86843:	48 83 c4 18                                     	add    $0x18,%rsp
   86847:	5b                                              	pop    %rbx
   86848:	41 5c                                           	pop    %r12
   8684a:	41 5d                                           	pop    %r13
   8684c:	41 5e                                           	pop    %r14
   8684e:	41 5f                                           	pop    %r15
   86850:	5d                                              	pop    %rbp
   86851:	c3                                              	ret
   86852:	48 8d 3d 61 79 f8 ff                            	lea    -0x7869f(%rip),%rdi        # e1ba <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.70.llvm.2776412514376943886+0x19eb>
   86859:	48 8d 15 88 79 06 00                            	lea    0x67988(%rip),%rdx        # ee1e8 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.381.llvm.2776412514376943886+0xc18>
   86860:	be 21 00 00 00                                  	mov    $0x21,%esi
   86865:	ff 15 dd 93 06 00                               	call   *0x693dd(%rip)        # efc48 <_DYNAMIC+0x380>
