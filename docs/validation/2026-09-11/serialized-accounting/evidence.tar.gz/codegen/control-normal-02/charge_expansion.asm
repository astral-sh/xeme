   8afc0:	41 56                                           	push   %r14
   8afc2:	53                                              	push   %rbx
   8afc3:	48 83 ec 18                                     	sub    $0x18,%rsp
   8afc7:	48 89 d1                                        	mov    %rdx,%rcx
   8afca:	4c 8b 46 28                                     	mov    0x28(%rsi),%r8
   8afce:	80 3e 00                                        	cmpb   $0x0,(%rsi)
   8afd1:	74 1e                                           	je     8aff1 <<oriole::Parser>::charge_expansion+0x31>
   8afd3:	4c 8b 8e e8 08 00 00                            	mov    0x8e8(%rsi),%r9
   8afda:	49 8b 41 30                                     	mov    0x30(%r9),%rax
   8afde:	48 f7 66 08                                     	mulq   0x8(%rsi)
   8afe2:	0f 80 f5 00 00 00                               	jo     8b0dd <<oriole::Parser>::charge_expansion+0x11d>
   8afe8:	4c 39 c0                                        	cmp    %r8,%rax
   8afeb:	4c 0f 47 c0                                     	cmova  %rax,%r8
   8afef:	eb 07                                           	jmp    8aff8 <<oriole::Parser>::charge_expansion+0x38>
   8aff1:	4c 8b 8e e8 08 00 00                            	mov    0x8e8(%rsi),%r9
   8aff8:	49 8b 41 28                                     	mov    0x28(%r9),%rax
   8affc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   8b000:	48 8d 14 08                                     	lea    (%rax,%rcx,1),%rdx
   8b004:	48 39 c2                                        	cmp    %rax,%rdx
   8b007:	72 14                                           	jb     8b01d <<oriole::Parser>::charge_expansion+0x5d>
   8b009:	4c 39 c2                                        	cmp    %r8,%rdx
   8b00c:	77 0f                                           	ja     8b01d <<oriole::Parser>::charge_expansion+0x5d>
   8b00e:	f0 49 0f b1 51 28                               	lock cmpxchg %rdx,0x28(%r9)
   8b014:	75 ea                                           	jne    8b000 <<oriole::Parser>::charge_expansion+0x40>
   8b016:	b0 ff                                           	mov    $0xff,%al
   8b018:	e9 9c 00 00 00                                  	jmp    8b0b9 <<oriole::Parser>::charge_expansion+0xf9>
   8b01d:	48 8b 8e 58 02 00 00                            	mov    0x258(%rsi),%rcx
   8b024:	48 85 c9                                        	test   %rcx,%rcx
   8b027:	0f 84 97 00 00 00                               	je     8b0c4 <<oriole::Parser>::charge_expansion+0x104>
   8b02d:	48 8b 86 48 02 00 00                            	mov    0x248(%rsi),%rax
   8b034:	48 8d 0c 49                                     	lea    (%rcx,%rcx,2),%rcx
   8b038:	48 c1 e1 07                                     	shl    $0x7,%rcx
   8b03c:	48 8d 14 08                                     	lea    (%rax,%rcx,1),%rdx
   8b040:	83 bc 08 80 fe ff ff 01                         	cmpl   $0x1,-0x180(%rax,%rcx,1)
   8b048:	75 17                                           	jne    8b061 <<oriole::Parser>::charge_expansion+0xa1>
   8b04a:	48 8b 9a 88 fe ff ff                            	mov    -0x178(%rdx),%rbx
   8b051:	0f 10 82 90 fe ff ff                            	movups -0x170(%rdx),%xmm0
   8b058:	48 8b 82 a0 fe ff ff                            	mov    -0x160(%rdx),%rax
   8b05f:	eb 38                                           	jmp    8b099 <<oriole::Parser>::charge_expansion+0xd9>
   8b061:	48 8b 5a a8                                     	mov    -0x58(%rdx),%rbx
   8b065:	0f 10 42 d8                                     	movups -0x28(%rdx),%xmm0
   8b069:	0f b6 52 fc                                     	movzbl -0x4(%rdx),%edx
   8b06d:	f6 c2 03                                        	test   $0x3,%dl
   8b070:	75 04                                           	jne    8b076 <<oriole::Parser>::charge_expansion+0xb6>
   8b072:	31 c0                                           	xor    %eax,%eax
   8b074:	eb 23                                           	jmp    8b099 <<oriole::Parser>::charge_expansion+0xd9>
   8b076:	48 01 c8                                        	add    %rcx,%rax
   8b079:	48 05 80 fe ff ff                               	add    $0xfffffffffffffe80,%rax
   8b07f:	49 89 fe                                        	mov    %rdi,%r14
   8b082:	48 89 c7                                        	mov    %rax,%rdi
   8b085:	31 f6                                           	xor    %esi,%esi
   8b087:	31 d2                                           	xor    %edx,%edx
   8b089:	0f 29 04 24                                     	movaps %xmm0,(%rsp)
   8b08d:	e8 5e 0b fe ff                                  	call   6bbf0 <<oriole::encoding::Source>::converted_raw_len>
   8b092:	0f 28 04 24                                     	movaps (%rsp),%xmm0
   8b096:	4c 89 f7                                        	mov    %r14,%rdi
   8b099:	48 8d 0d 4c 35 f8 ff                            	lea    -0x7cab4(%rip),%rcx        # e5ec <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.70.llvm.2776412514376943886+0x1e1d>
   8b0a0:	48 89 0f                                        	mov    %rcx,(%rdi)
   8b0a3:	48 c7 47 08 24 00 00 00                         	movq   $0x24,0x8(%rdi)
   8b0ab:	48 89 5f 10                                     	mov    %rbx,0x10(%rdi)
   8b0af:	0f 11 47 18                                     	movups %xmm0,0x18(%rdi)
   8b0b3:	48 89 47 28                                     	mov    %rax,0x28(%rdi)
   8b0b7:	b0 1e                                           	mov    $0x1e,%al
   8b0b9:	88 47 30                                        	mov    %al,0x30(%rdi)
   8b0bc:	48 83 c4 18                                     	add    $0x18,%rsp
   8b0c0:	5b                                              	pop    %rbx
   8b0c1:	41 5e                                           	pop    %r14
   8b0c3:	c3                                              	ret
   8b0c4:	48 8d 3d ef 30 f8 ff                            	lea    -0x7cf11(%rip),%rdi        # e1ba <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.70.llvm.2776412514376943886+0x19eb>
   8b0cb:	48 8d 15 16 31 06 00                            	lea    0x63116(%rip),%rdx        # ee1e8 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.381.llvm.2776412514376943886+0xc18>
   8b0d2:	be 21 00 00 00                                  	mov    $0x21,%esi
   8b0d7:	ff 15 6b 4b 06 00                               	call   *0x64b6b(%rip)        # efc48 <_DYNAMIC+0x380>
   8b0dd:	48 c7 c0 ff ff ff ff                            	mov    $0xffffffffffffffff,%rax
   8b0e4:	e9 ff fe ff ff                                  	jmp    8afe8 <<oriole::Parser>::charge_expansion+0x28>
