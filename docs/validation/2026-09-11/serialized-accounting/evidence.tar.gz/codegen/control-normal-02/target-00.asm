0x8afc0: 4156  push   %r14
0x8afc2: 53  push   %rbx
0x8afc3: 4883ec18  sub    $0x18,%rsp
0x8afc7: 4889d1  mov    %rdx,%rcx
0x8afca: 4c8b4628  mov    0x28(%rsi),%r8
0x8afce: 803e00  cmpb   $0x0,(%rsi)
0x8afd1: 741e  je     8aff1 <<oriole::Parser>::charge_expansion+0x31>
0x8afd3: 4c8b8ee8080000  mov    0x8e8(%rsi),%r9
0x8afda: 498b4130  mov    0x30(%r9),%rax
0x8afde: 48f76608  mulq   0x8(%rsi)
0x8afe2: 0f80f5000000  jo     8b0dd <<oriole::Parser>::charge_expansion+0x11d>
0x8afe8: 4c39c0  cmp    %r8,%rax
0x8afeb: 4c0f47c0  cmova  %rax,%r8
0x8afef: eb07  jmp    8aff8 <<oriole::Parser>::charge_expansion+0x38>
0x8aff1: 4c8b8ee8080000  mov    0x8e8(%rsi),%r9
0x8aff8: 498b4128  mov    0x28(%r9),%rax
0x8affc: 0f1f4000  nopl   0x0(%rax)
0x8b000: 488d1408  lea    (%rax,%rcx,1),%rdx
0x8b004: 4839c2  cmp    %rax,%rdx
0x8b007: 7214  jb     8b01d <<oriole::Parser>::charge_expansion+0x5d>
0x8b009: 4c39c2  cmp    %r8,%rdx
0x8b00c: 770f  ja     8b01d <<oriole::Parser>::charge_expansion+0x5d>
0x8b00e: f0490fb15128  lock cmpxchg %rdx,0x28(%r9)
0x8b014: 75ea  jne    8b000 <<oriole::Parser>::charge_expansion+0x40>
0x8b016: b0ff  mov    $0xff,%al
0x8b018: e99c000000  jmp    8b0b9 <<oriole::Parser>::charge_expansion+0xf9>
0x8b01d: 488b8e58020000  mov    0x258(%rsi),%rcx
0x8b024: 4885c9  test   %rcx,%rcx
0x8b027: 0f8497000000  je     8b0c4 <<oriole::Parser>::charge_expansion+0x104>
0x8b02d: 488b8648020000  mov    0x248(%rsi),%rax
0x8b034: 488d0c49  lea    (%rcx,%rcx,2),%rcx
0x8b038: 48c1e107  shl    $0x7,%rcx
0x8b03c: 488d1408  lea    (%rax,%rcx,1),%rdx
0x8b040: 83bc0880feffff01  cmpl   $0x1,-0x180(%rax,%rcx,1)
0x8b048: 7517  jne    8b061 <<oriole::Parser>::charge_expansion+0xa1>
0x8b04a: 488b9a88feffff  mov    -0x178(%rdx),%rbx
0x8b051: 0f108290feffff  movups -0x170(%rdx),%xmm0
0x8b058: 488b82a0feffff  mov    -0x160(%rdx),%rax
0x8b05f: eb38  jmp    8b099 <<oriole::Parser>::charge_expansion+0xd9>
0x8b061: 488b5aa8  mov    -0x58(%rdx),%rbx
0x8b065: 0f1042d8  movups -0x28(%rdx),%xmm0
0x8b069: 0fb652fc  movzbl -0x4(%rdx),%edx
0x8b06d: f6c203  test   $0x3,%dl
0x8b070: 7504  jne    8b076 <<oriole::Parser>::charge_expansion+0xb6>
0x8b072: 31c0  xor    %eax,%eax
0x8b074: eb23  jmp    8b099 <<oriole::Parser>::charge_expansion+0xd9>
0x8b076: 4801c8  add    %rcx,%rax
0x8b079: 480580feffff  add    $0xfffffffffffffe80,%rax
0x8b07f: 4989fe  mov    %rdi,%r14
0x8b082: 4889c7  mov    %rax,%rdi
0x8b085: 31f6  xor    %esi,%esi
0x8b087: 31d2  xor    %edx,%edx
0x8b089: 0f290424  movaps %xmm0,(%rsp)
0x8b08d: e85e0bfeff  call   6bbf0 <<oriole::encoding::Source>::converted_raw_len>
0x8b092: 0f280424  movaps (%rsp),%xmm0
0x8b096: 4c89f7  mov    %r14,%rdi
0x8b099: 488d0d4c35f8ff  lea    -0x7cab4(%rip),%rcx        # e5ec <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.70.llvm.2776412514376943886+0x1e1d>
0x8b0a0: 48890f  mov    %rcx,(%rdi)
0x8b0a3: 48c7470824000000  movq   $0x24,0x8(%rdi)
0x8b0ab: 48895f10  mov    %rbx,0x10(%rdi)
0x8b0af: 0f114718  movups %xmm0,0x18(%rdi)
0x8b0b3: 48894728  mov    %rax,0x28(%rdi)
0x8b0b7: b01e  mov    $0x1e,%al
0x8b0b9: 884730  mov    %al,0x30(%rdi)
0x8b0bc: 4883c418  add    $0x18,%rsp
0x8b0c0: 5b  pop    %rbx
0x8b0c1: 415e  pop    %r14
0x8b0c3: c3  ret
0x8b0c4: 488d3def30f8ff  lea    -0x7cf11(%rip),%rdi        # e1ba <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.70.llvm.2776412514376943886+0x19eb>
0x8b0cb: 488d1516310600  lea    0x63116(%rip),%rdx        # ee1e8 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.381.llvm.2776412514376943886+0xc18>
0x8b0d2: be21000000  mov    $0x21,%esi
0x8b0d7: ff156b4b0600  call   *0x64b6b(%rip)        # efc48 <_DYNAMIC+0x380>
0x8b0dd: 48c7c0ffffffff  mov    $0xffffffffffffffff,%rax
0x8b0e4: e9fffeffff  jmp    8afe8 <<oriole::Parser>::charge_expansion+0x28>
