0x3bf00: f048ff4f20  lock decq 0x20(%rdi)
0x3bf05: 752e  jne    3bf35 <core::ptr::drop_glue::<oriole_storage::shared::Shared<oriole::accounting::EntityBudget>>+0x35>
0x3bf07: 4883ec28  sub    $0x28,%rsp
0x3bf0b: 4889fe  mov    %rdi,%rsi
0x3bf0e: 0f1007  movups (%rdi),%xmm0
0x3bf11: 0f104f10  movups 0x10(%rdi),%xmm1
0x3bf15: 0f294c2410  movaps %xmm1,0x10(%rsp)
0x3bf1a: 0f290424  movaps %xmm0,(%rsp)
0x3bf1e: 4889e7  mov    %rsp,%rdi
0x3bf21: ba08000000  mov    $0x8,%edx
0x3bf26: b950000000  mov    $0x50,%ecx
0x3bf2b: ff153f3f0b00  call   *0xb3f3f(%rip)        # efe70 <_DYNAMIC+0x5a8>
0x3bf31: 4883c428  add    $0x28,%rsp
0x3bf35: c3  ret
