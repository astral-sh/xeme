   8e300:	41 57                                           	push   %r15
   8e302:	41 56                                           	push   %r14
   8e304:	41 55                                           	push   %r13
   8e306:	41 54                                           	push   %r12
   8e308:	53                                              	push   %rbx
   8e309:	4c 8b b6 58 02 00 00                            	mov    0x258(%rsi),%r14
   8e310:	4d 85 f6                                        	test   %r14,%r14
   8e313:	0f 84 da 06 00 00                               	je     8e9f3 <<oriole::Parser>::account_source+0x6f3>
   8e319:	49 89 f8                                        	mov    %rdi,%r8
   8e31c:	48 8b 86 48 02 00 00                            	mov    0x248(%rsi),%rax
   8e323:	4b 8d 0c 76                                     	lea    (%r14,%r14,2),%rcx
   8e327:	48 c1 e1 07                                     	shl    $0x7,%rcx
   8e32b:	48 8d 1c 08                                     	lea    (%rax,%rcx,1),%rbx
   8e32f:	4c 8b 7c 08 a8                                  	mov    -0x58(%rax,%rcx,1),%r15
   8e334:	44 0f b6 54 08 fc                               	movzbl -0x4(%rax,%rcx,1),%r10d
   8e33a:	41 f6 c2 03                                     	test   $0x3,%r10b
   8e33e:	75 2a                                           	jne    8e36a <<oriole::Parser>::account_source+0x6a>
   8e340:	48 89 d0                                        	mov    %rdx,%rax
   8e343:	4c 01 f8                                        	add    %r15,%rax
   8e346:	31 c9                                           	xor    %ecx,%ecx
   8e348:	48 2b 43 b0                                     	sub    -0x50(%rbx),%rax
   8e34c:	48 0f 43 c8                                     	cmovae %rax,%rcx
   8e350:	0f 87 47 02 00 00                               	ja     8e59d <<oriole::Parser>::account_source+0x29d>
   8e356:	48 01 4b b0                                     	add    %rcx,-0x50(%rbx)
   8e35a:	b0 ff                                           	mov    $0xff,%al
   8e35c:	41 88 40 30                                     	mov    %al,0x30(%r8)
   8e360:	5b                                              	pop    %rbx
   8e361:	41 5c                                           	pop    %r12
   8e363:	41 5d                                           	pop    %r13
   8e365:	41 5e                                           	pop    %r14
   8e367:	41 5f                                           	pop    %r15
   8e369:	c3                                              	ret
   8e36a:	41 83 fa 06                                     	cmp    $0x6,%r10d
   8e36e:	0f 84 b7 06 00 00                               	je     8ea2b <<oriole::Parser>::account_source+0x72b>
   8e374:	48 8b bb c8 fe ff ff                            	mov    -0x138(%rbx),%rdi
   8e37b:	48 8b 8b d8 fe ff ff                            	mov    -0x128(%rbx),%rcx
   8e382:	48 8b 43 a0                                     	mov    -0x60(%rbx),%rax
   8e386:	48 85 c0                                        	test   %rax,%rax
   8e389:	74 13                                           	je     8e39e <<oriole::Parser>::account_source+0x9e>
   8e38b:	48 39 c1                                        	cmp    %rax,%rcx
   8e38e:	0f 86 f7 04 00 00                               	jbe    8e88b <<oriole::Parser>::account_source+0x58b>
   8e394:	80 3c 07 bf                                     	cmpb   $0xbf,(%rdi,%rax,1)
   8e398:	0f 8e f3 04 00 00                               	jle    8e891 <<oriole::Parser>::account_source+0x591>
   8e39e:	49 89 c9                                        	mov    %rcx,%r9
   8e3a1:	49 29 c1                                        	sub    %rax,%r9
   8e3a4:	48 01 c7                                        	add    %rax,%rdi
   8e3a7:	4c 39 ca                                        	cmp    %r9,%rdx
   8e3aa:	0f 87 5c 06 00 00                               	ja     8ea0c <<oriole::Parser>::account_source+0x70c>
   8e3b0:	48 39 c1                                        	cmp    %rax,%rcx
   8e3b3:	74 0f                                           	je     8e3c4 <<oriole::Parser>::account_source+0xc4>
   8e3b5:	4c 39 ca                                        	cmp    %r9,%rdx
   8e3b8:	74 0a                                           	je     8e3c4 <<oriole::Parser>::account_source+0xc4>
   8e3ba:	80 3c 17 bf                                     	cmpb   $0xbf,(%rdi,%rdx,1)
   8e3be:	0f 8e 48 06 00 00                               	jle    8ea0c <<oriole::Parser>::account_source+0x70c>
   8e3c4:	41 8d 42 ff                                     	lea    -0x1(%r10),%eax
   8e3c8:	83 f8 02                                        	cmp    $0x2,%eax
   8e3cb:	0f 83 50 02 00 00                               	jae    8e621 <<oriole::Parser>::account_source+0x321>
   8e3d1:	48 85 d2                                        	test   %rdx,%rdx
   8e3d4:	0f 84 78 02 00 00                               	je     8e652 <<oriole::Parser>::account_source+0x352>
   8e3da:	0f b6 07                                        	movzbl (%rdi),%eax
   8e3dd:	84 c0                                           	test   %al,%al
   8e3df:	0f 88 eb 04 00 00                               	js     8e8d0 <<oriole::Parser>::account_source+0x5d0>
   8e3e5:	4c 8d 4f 01                                     	lea    0x1(%rdi),%r9
   8e3e9:	89 c1                                           	mov    %eax,%ecx
   8e3eb:	48 01 d7                                        	add    %rdx,%rdi
   8e3ee:	b8 01 00 00 00                                  	mov    $0x1,%eax
   8e3f3:	81 f9 00 00 01 00                               	cmp    $0x10000,%ecx
   8e3f9:	0f 83 79 06 00 00                               	jae    8ea78 <<oriole::Parser>::account_source+0x778>
   8e3ff:	31 c9                                           	xor    %ecx,%ecx
   8e401:	49 39 f9                                        	cmp    %rdi,%r9
   8e404:	0f 95 c2                                        	setne  %dl
   8e407:	0f 84 88 01 00 00                               	je     8e595 <<oriole::Parser>::account_source+0x295>
   8e40d:	88 d1                                           	mov    %dl,%cl
   8e40f:	4c 01 c9                                        	add    %r9,%rcx
   8e412:	45 0f b6 11                                     	movzbl (%r9),%r10d
   8e416:	45 84 d2                                        	test   %r10b,%r10b
   8e419:	0f 88 d6 04 00 00                               	js     8e8f5 <<oriole::Parser>::account_source+0x5f5>
   8e41f:	44 89 d2                                        	mov    %r10d,%edx
   8e422:	41 b9 01 00 00 00                               	mov    $0x1,%r9d
   8e428:	81 fa 00 00 01 00                               	cmp    $0x10000,%edx
   8e42e:	0f 83 4e 06 00 00                               	jae    8ea82 <<oriole::Parser>::account_source+0x782>
   8e434:	4c 01 c8                                        	add    %r9,%rax
   8e437:	31 d2                                           	xor    %edx,%edx
   8e439:	48 39 f9                                        	cmp    %rdi,%rcx
   8e43c:	41 0f 95 c1                                     	setne  %r9b
   8e440:	0f 84 4f 01 00 00                               	je     8e595 <<oriole::Parser>::account_source+0x295>
   8e446:	44 88 ca                                        	mov    %r9b,%dl
   8e449:	48 01 ca                                        	add    %rcx,%rdx
   8e44c:	44 0f b6 11                                     	movzbl (%rcx),%r10d
   8e450:	45 84 d2                                        	test   %r10b,%r10b
   8e453:	0f 88 c2 04 00 00                               	js     8e91b <<oriole::Parser>::account_source+0x61b>
   8e459:	44 89 d1                                        	mov    %r10d,%ecx
   8e45c:	41 b9 01 00 00 00                               	mov    $0x1,%r9d
   8e462:	81 f9 00 00 01 00                               	cmp    $0x10000,%ecx
   8e468:	0f 83 1f 06 00 00                               	jae    8ea8d <<oriole::Parser>::account_source+0x78d>
   8e46e:	4c 01 c8                                        	add    %r9,%rax
   8e471:	31 c9                                           	xor    %ecx,%ecx
   8e473:	48 39 fa                                        	cmp    %rdi,%rdx
   8e476:	41 0f 95 c1                                     	setne  %r9b
   8e47a:	0f 84 15 01 00 00                               	je     8e595 <<oriole::Parser>::account_source+0x295>
   8e480:	44 88 c9                                        	mov    %r9b,%cl
   8e483:	48 01 d1                                        	add    %rdx,%rcx
   8e486:	44 0f b6 12                                     	movzbl (%rdx),%r10d
   8e48a:	45 84 d2                                        	test   %r10b,%r10b
   8e48d:	0f 88 ae 04 00 00                               	js     8e941 <<oriole::Parser>::account_source+0x641>
   8e493:	44 89 d2                                        	mov    %r10d,%edx
   8e496:	41 b9 01 00 00 00                               	mov    $0x1,%r9d
   8e49c:	81 fa 00 00 01 00                               	cmp    $0x10000,%edx
   8e4a2:	0f 83 f0 05 00 00                               	jae    8ea98 <<oriole::Parser>::account_source+0x798>
   8e4a8:	4c 01 c8                                        	add    %r9,%rax
   8e4ab:	31 d2                                           	xor    %edx,%edx
   8e4ad:	48 39 f9                                        	cmp    %rdi,%rcx
   8e4b0:	41 0f 95 c1                                     	setne  %r9b
   8e4b4:	0f 84 db 00 00 00                               	je     8e595 <<oriole::Parser>::account_source+0x295>
   8e4ba:	44 88 ca                                        	mov    %r9b,%dl
   8e4bd:	48 01 ca                                        	add    %rcx,%rdx
   8e4c0:	44 0f b6 11                                     	movzbl (%rcx),%r10d
   8e4c4:	45 84 d2                                        	test   %r10b,%r10b
   8e4c7:	0f 88 9a 04 00 00                               	js     8e967 <<oriole::Parser>::account_source+0x667>
   8e4cd:	44 89 d1                                        	mov    %r10d,%ecx
   8e4d0:	41 b9 01 00 00 00                               	mov    $0x1,%r9d
   8e4d6:	81 f9 00 00 01 00                               	cmp    $0x10000,%ecx
   8e4dc:	0f 83 cb 05 00 00                               	jae    8eaad <<oriole::Parser>::account_source+0x7ad>
   8e4e2:	4c 01 c8                                        	add    %r9,%rax
   8e4e5:	45 31 c9                                        	xor    %r9d,%r9d
   8e4e8:	48 39 fa                                        	cmp    %rdi,%rdx
   8e4eb:	0f 95 c1                                        	setne  %cl
   8e4ee:	0f 84 a1 00 00 00                               	je     8e595 <<oriole::Parser>::account_source+0x295>
   8e4f4:	41 88 c9                                        	mov    %cl,%r9b
   8e4f7:	49 01 d1                                        	add    %rdx,%r9
   8e4fa:	44 0f b6 12                                     	movzbl (%rdx),%r10d
   8e4fe:	45 84 d2                                        	test   %r10b,%r10b
   8e501:	0f 88 86 04 00 00                               	js     8e98d <<oriole::Parser>::account_source+0x68d>
   8e507:	44 89 d1                                        	mov    %r10d,%ecx
   8e50a:	ba 01 00 00 00                                  	mov    $0x1,%edx
   8e50f:	81 f9 00 00 01 00                               	cmp    $0x10000,%ecx
   8e515:	0f 83 9f 05 00 00                               	jae    8eaba <<oriole::Parser>::account_source+0x7ba>
   8e51b:	48 01 d0                                        	add    %rdx,%rax
   8e51e:	31 c9                                           	xor    %ecx,%ecx
   8e520:	49 39 f9                                        	cmp    %rdi,%r9
   8e523:	0f 95 c2                                        	setne  %dl
   8e526:	74 6d                                           	je     8e595 <<oriole::Parser>::account_source+0x295>
   8e528:	88 d1                                           	mov    %dl,%cl
   8e52a:	4c 01 c9                                        	add    %r9,%rcx
   8e52d:	45 0f b6 11                                     	movzbl (%r9),%r10d
   8e531:	45 84 d2                                        	test   %r10b,%r10b
   8e534:	0f 88 79 04 00 00                               	js     8e9b3 <<oriole::Parser>::account_source+0x6b3>
   8e53a:	44 89 d2                                        	mov    %r10d,%edx
   8e53d:	81 fa 00 00 01 00                               	cmp    $0x10000,%edx
   8e543:	48 83 d8 00                                     	sbb    $0x0,%rax
   8e547:	48 83 c0 02                                     	add    $0x2,%rax
   8e54b:	31 d2                                           	xor    %edx,%edx
   8e54d:	48 39 f9                                        	cmp    %rdi,%rcx
   8e550:	41 0f 95 c1                                     	setne  %r9b
   8e554:	74 3f                                           	je     8e595 <<oriole::Parser>::account_source+0x295>
   8e556:	44 88 ca                                        	mov    %r9b,%dl
   8e559:	48 01 ca                                        	add    %rcx,%rdx
   8e55c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   8e560:	44 0f b6 09                                     	movzbl (%rcx),%r9d
   8e564:	45 84 c9                                        	test   %r9b,%r9b
   8e567:	0f 88 37 03 00 00                               	js     8e8a4 <<oriole::Parser>::account_source+0x5a4>
   8e56d:	48 89 d1                                        	mov    %rdx,%rcx
   8e570:	ba 01 00 00 00                                  	mov    $0x1,%edx
   8e575:	41 81 f9 00 00 01 00                            	cmp    $0x10000,%r9d
   8e57c:	0f 83 9f 04 00 00                               	jae    8ea21 <<oriole::Parser>::account_source+0x721>
   8e582:	48 01 d0                                        	add    %rdx,%rax
   8e585:	31 d2                                           	xor    %edx,%edx
   8e587:	48 39 f9                                        	cmp    %rdi,%rcx
   8e58a:	0f 95 c2                                        	setne  %dl
   8e58d:	48 01 ca                                        	add    %rcx,%rdx
   8e590:	48 39 f9                                        	cmp    %rdi,%rcx
   8e593:	75 cb                                           	jne    8e560 <<oriole::Parser>::account_source+0x260>
   8e595:	48 01 c0                                        	add    %rax,%rax
   8e598:	e9 a6 fd ff ff                                  	jmp    8e343 <<oriole::Parser>::account_source+0x43>
   8e59d:	48 8b 96 e8 08 00 00                            	mov    0x8e8(%rsi),%rdx
   8e5a4:	49 83 fe 01                                     	cmp    $0x1,%r14
   8e5a8:	0f 95 c0                                        	setne  %al
   8e5ab:	0a 86 5a 09 00 00                               	or     0x95a(%rsi),%al
   8e5b1:	48 8d 7a 38                                     	lea    0x38(%rdx),%rdi
   8e5b5:	4c 8d 4a 30                                     	lea    0x30(%rdx),%r9
   8e5b9:	0f b6 c0                                        	movzbl %al,%eax
   8e5bc:	84 c0                                           	test   %al,%al
   8e5be:	4d 89 ca                                        	mov    %r9,%r10
   8e5c1:	4c 0f 45 d7                                     	cmovne %rdi,%r10
   8e5c5:	48 8b 44 c2 30                                  	mov    0x30(%rdx,%rax,8),%rax
   8e5ca:	49 89 c3                                        	mov    %rax,%r11
   8e5cd:	49 01 cb                                        	add    %rcx,%r11
   8e5d0:	0f 82 6a 05 00 00                               	jb     8eb40 <<oriole::Parser>::account_source+0x840>
   8e5d6:	f0 4d 0f b1 1a                                  	lock cmpxchg %r11,(%r10)
   8e5db:	75 ed                                           	jne    8e5ca <<oriole::Parser>::account_source+0x2ca>
   8e5dd:	4d 8b 09                                        	mov    (%r9),%r9
   8e5e0:	4c 8b 17                                        	mov    (%rdi),%r10
   8e5e3:	4d 89 d3                                        	mov    %r10,%r11
   8e5e6:	4d 01 cb                                        	add    %r9,%r11
   8e5e9:	0f 82 51 05 00 00                               	jb     8eb40 <<oriole::Parser>::account_source+0x840>
   8e5ef:	48 8b 42 40                                     	mov    0x40(%rdx),%rax
   8e5f3:	49 39 c3                                        	cmp    %rax,%r11
   8e5f6:	0f 82 5a fd ff ff                               	jb     8e356 <<oriole::Parser>::account_source+0x56>
   8e5fc:	48 89 f0                                        	mov    %rsi,%rax
   8e5ff:	4c 89 c7                                        	mov    %r8,%rdi
   8e602:	4d 85 c9                                        	test   %r9,%r9
   8e605:	0f 84 b9 04 00 00                               	je     8eac4 <<oriole::Parser>::account_source+0x7c4>
   8e60b:	4d 85 db                                        	test   %r11,%r11
   8e60e:	0f 88 d3 04 00 00                               	js     8eae7 <<oriole::Parser>::account_source+0x7e7>
   8e614:	0f 57 c0                                        	xorps  %xmm0,%xmm0
   8e617:	f3 49 0f 2a c3                                  	cvtsi2ss %r11,%xmm0
   8e61c:	e9 df 04 00 00                                  	jmp    8eb00 <<oriole::Parser>::account_source+0x800>
   8e621:	44 89 d0                                        	mov    %r10d,%eax
   8e624:	48 8d 0d b9 d8 f7 ff                            	lea    -0x82747(%rip),%rcx        # bee4 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.109.llvm.4530151907887530887+0xa24>
   8e62b:	48 63 04 81                                     	movslq (%rcx,%rax,4),%rax
   8e62f:	48 01 c8                                        	add    %rcx,%rax
   8e632:	ff e0                                           	jmp    *%rax
   8e634:	48 83 fa 20                                     	cmp    $0x20,%rdx
   8e638:	0f 83 9b 03 00 00                               	jae    8e9d9 <<oriole::Parser>::account_source+0x6d9>
   8e63e:	48 85 d2                                        	test   %rdx,%rdx
   8e641:	74 0f                                           	je     8e652 <<oriole::Parser>::account_source+0x352>
   8e643:	48 83 fa 04                                     	cmp    $0x4,%rdx
   8e647:	73 10                                           	jae    8e659 <<oriole::Parser>::account_source+0x359>
   8e649:	31 c9                                           	xor    %ecx,%ecx
   8e64b:	31 c0                                           	xor    %eax,%eax
   8e64d:	e9 99 07 00 00                                  	jmp    8edeb <<oriole::Parser>::account_source+0xaeb>
   8e652:	31 c0                                           	xor    %eax,%eax
   8e654:	e9 ea fc ff ff                                  	jmp    8e343 <<oriole::Parser>::account_source+0x43>
   8e659:	89 d1                                           	mov    %edx,%ecx
   8e65b:	83 e1 1c                                        	and    $0x1c,%ecx
   8e65e:	0f b7 07                                        	movzwl (%rdi),%eax
   8e661:	66 0f 6e c0                                     	movd   %eax,%xmm0
   8e665:	0f b7 47 02                                     	movzwl 0x2(%rdi),%eax
   8e669:	66 0f 6e c8                                     	movd   %eax,%xmm1
   8e66d:	66 0f 6f 15 3b b8 f7 ff                         	movdqa -0x847c5(%rip),%xmm2        # 9eb0 <anon.6d978c0ff76fb7c7580bdf886695e467.415.llvm.4677468819421477425+0x260>
   8e675:	66 0f 64 c2                                     	pcmpgtb %xmm2,%xmm0
   8e679:	66 0f 60 c0                                     	punpcklbw %xmm0,%xmm0
   8e67d:	f2 0f 70 c0 d4                                  	pshuflw $0xd4,%xmm0,%xmm0
   8e682:	66 0f 70 c0 d4                                  	pshufd $0xd4,%xmm0,%xmm0
   8e687:	66 0f 6f 1d 51 b8 f7 ff                         	movdqa -0x847af(%rip),%xmm3        # 9ee0 <anon.6d978c0ff76fb7c7580bdf886695e467.1.llvm.4677468819421477425+0x20>
   8e68f:	66 0f db c3                                     	pand   %xmm3,%xmm0
   8e693:	66 0f 64 ca                                     	pcmpgtb %xmm2,%xmm1
   8e697:	66 0f 60 c9                                     	punpcklbw %xmm1,%xmm1
   8e69b:	f2 0f 70 c9 d4                                  	pshuflw $0xd4,%xmm1,%xmm1
   8e6a0:	66 0f 70 c9 d4                                  	pshufd $0xd4,%xmm1,%xmm1
   8e6a5:	66 0f db cb                                     	pand   %xmm3,%xmm1
   8e6a9:	48 83 f9 04                                     	cmp    $0x4,%rcx
   8e6ad:	0f 84 c1 01 00 00                               	je     8e874 <<oriole::Parser>::account_source+0x574>
   8e6b3:	0f b7 47 04                                     	movzwl 0x4(%rdi),%eax
   8e6b7:	66 0f 6e e0                                     	movd   %eax,%xmm4
   8e6bb:	0f b7 47 06                                     	movzwl 0x6(%rdi),%eax
   8e6bf:	66 0f 6e e8                                     	movd   %eax,%xmm5
   8e6c3:	66 0f 64 e2                                     	pcmpgtb %xmm2,%xmm4
   8e6c7:	66 0f 60 e4                                     	punpcklbw %xmm4,%xmm4
   8e6cb:	f2 0f 70 e4 d4                                  	pshuflw $0xd4,%xmm4,%xmm4
   8e6d0:	66 0f 70 e4 d4                                  	pshufd $0xd4,%xmm4,%xmm4
   8e6d5:	66 0f db e3                                     	pand   %xmm3,%xmm4
   8e6d9:	66 0f 64 ea                                     	pcmpgtb %xmm2,%xmm5
   8e6dd:	66 0f 60 ed                                     	punpcklbw %xmm5,%xmm5
   8e6e1:	f2 0f 70 ed d4                                  	pshuflw $0xd4,%xmm5,%xmm5
   8e6e6:	66 0f 70 ed d4                                  	pshufd $0xd4,%xmm5,%xmm5
   8e6eb:	66 0f db eb                                     	pand   %xmm3,%xmm5
   8e6ef:	66 0f d4 c4                                     	paddq  %xmm4,%xmm0
   8e6f3:	66 0f d4 cd                                     	paddq  %xmm5,%xmm1
   8e6f7:	83 f9 08                                        	cmp    $0x8,%ecx
   8e6fa:	0f 84 74 01 00 00                               	je     8e874 <<oriole::Parser>::account_source+0x574>
   8e700:	0f b7 47 08                                     	movzwl 0x8(%rdi),%eax
   8e704:	66 0f 6e e0                                     	movd   %eax,%xmm4
   8e708:	0f b7 47 0a                                     	movzwl 0xa(%rdi),%eax
   8e70c:	66 0f 6e e8                                     	movd   %eax,%xmm5
   8e710:	66 0f 64 e2                                     	pcmpgtb %xmm2,%xmm4
   8e714:	66 0f 60 e4                                     	punpcklbw %xmm4,%xmm4
   8e718:	f2 0f 70 e4 d4                                  	pshuflw $0xd4,%xmm4,%xmm4
   8e71d:	66 0f 70 e4 d4                                  	pshufd $0xd4,%xmm4,%xmm4
   8e722:	66 0f db e3                                     	pand   %xmm3,%xmm4
   8e726:	66 0f 64 ea                                     	pcmpgtb %xmm2,%xmm5
   8e72a:	66 0f 60 ed                                     	punpcklbw %xmm5,%xmm5
   8e72e:	f2 0f 70 ed d4                                  	pshuflw $0xd4,%xmm5,%xmm5
   8e733:	66 0f 70 ed d4                                  	pshufd $0xd4,%xmm5,%xmm5
   8e738:	66 0f db eb                                     	pand   %xmm3,%xmm5
   8e73c:	66 0f d4 c4                                     	paddq  %xmm4,%xmm0
   8e740:	66 0f d4 cd                                     	paddq  %xmm5,%xmm1
   8e744:	83 f9 0c                                        	cmp    $0xc,%ecx
   8e747:	0f 84 27 01 00 00                               	je     8e874 <<oriole::Parser>::account_source+0x574>
   8e74d:	0f b7 47 0c                                     	movzwl 0xc(%rdi),%eax
   8e751:	66 0f 6e e0                                     	movd   %eax,%xmm4
   8e755:	0f b7 47 0e                                     	movzwl 0xe(%rdi),%eax
   8e759:	66 0f 6e e8                                     	movd   %eax,%xmm5
   8e75d:	66 0f 64 e2                                     	pcmpgtb %xmm2,%xmm4
   8e761:	66 0f 60 e4                                     	punpcklbw %xmm4,%xmm4
   8e765:	f2 0f 70 e4 d4                                  	pshuflw $0xd4,%xmm4,%xmm4
   8e76a:	66 0f 70 e4 d4                                  	pshufd $0xd4,%xmm4,%xmm4
   8e76f:	66 0f db e3                                     	pand   %xmm3,%xmm4
   8e773:	66 0f 64 ea                                     	pcmpgtb %xmm2,%xmm5
   8e777:	66 0f 60 ed                                     	punpcklbw %xmm5,%xmm5
   8e77b:	f2 0f 70 ed d4                                  	pshuflw $0xd4,%xmm5,%xmm5
   8e780:	66 0f 70 ed d4                                  	pshufd $0xd4,%xmm5,%xmm5
   8e785:	66 0f db eb                                     	pand   %xmm3,%xmm5
   8e789:	66 0f d4 c4                                     	paddq  %xmm4,%xmm0
   8e78d:	66 0f d4 cd                                     	paddq  %xmm5,%xmm1
   8e791:	83 f9 10                                        	cmp    $0x10,%ecx
   8e794:	0f 84 da 00 00 00                               	je     8e874 <<oriole::Parser>::account_source+0x574>
   8e79a:	0f b7 47 10                                     	movzwl 0x10(%rdi),%eax
   8e79e:	66 0f 6e e0                                     	movd   %eax,%xmm4
   8e7a2:	0f b7 47 12                                     	movzwl 0x12(%rdi),%eax
   8e7a6:	66 0f 6e e8                                     	movd   %eax,%xmm5
   8e7aa:	66 0f 64 e2                                     	pcmpgtb %xmm2,%xmm4
   8e7ae:	66 0f 60 e4                                     	punpcklbw %xmm4,%xmm4
   8e7b2:	f2 0f 70 e4 d4                                  	pshuflw $0xd4,%xmm4,%xmm4
   8e7b7:	66 0f 70 e4 d4                                  	pshufd $0xd4,%xmm4,%xmm4
   8e7bc:	66 0f db e3                                     	pand   %xmm3,%xmm4
   8e7c0:	66 0f 64 ea                                     	pcmpgtb %xmm2,%xmm5
   8e7c4:	66 0f 60 ed                                     	punpcklbw %xmm5,%xmm5
   8e7c8:	f2 0f 70 ed d4                                  	pshuflw $0xd4,%xmm5,%xmm5
   8e7cd:	66 0f 70 ed d4                                  	pshufd $0xd4,%xmm5,%xmm5
   8e7d2:	66 0f db eb                                     	pand   %xmm3,%xmm5
   8e7d6:	66 0f d4 c4                                     	paddq  %xmm4,%xmm0
   8e7da:	66 0f d4 cd                                     	paddq  %xmm5,%xmm1
   8e7de:	83 f9 14                                        	cmp    $0x14,%ecx
   8e7e1:	0f 84 8d 00 00 00                               	je     8e874 <<oriole::Parser>::account_source+0x574>
   8e7e7:	0f b7 47 14                                     	movzwl 0x14(%rdi),%eax
   8e7eb:	66 0f 6e e0                                     	movd   %eax,%xmm4
   8e7ef:	0f b7 47 16                                     	movzwl 0x16(%rdi),%eax
   8e7f3:	66 0f 6e e8                                     	movd   %eax,%xmm5
   8e7f7:	66 0f 64 e2                                     	pcmpgtb %xmm2,%xmm4
   8e7fb:	66 0f 60 e4                                     	punpcklbw %xmm4,%xmm4
   8e7ff:	f2 0f 70 e4 d4                                  	pshuflw $0xd4,%xmm4,%xmm4
   8e804:	66 0f 70 e4 d4                                  	pshufd $0xd4,%xmm4,%xmm4
   8e809:	66 0f db e3                                     	pand   %xmm3,%xmm4
   8e80d:	66 0f 64 ea                                     	pcmpgtb %xmm2,%xmm5
   8e811:	66 0f 60 ed                                     	punpcklbw %xmm5,%xmm5
   8e815:	f2 0f 70 ed d4                                  	pshuflw $0xd4,%xmm5,%xmm5
   8e81a:	66 0f 70 ed d4                                  	pshufd $0xd4,%xmm5,%xmm5
   8e81f:	66 0f db eb                                     	pand   %xmm3,%xmm5
   8e823:	66 0f d4 c4                                     	paddq  %xmm4,%xmm0
   8e827:	66 0f d4 cd                                     	paddq  %xmm5,%xmm1
   8e82b:	83 f9 18                                        	cmp    $0x18,%ecx
   8e82e:	74 44                                           	je     8e874 <<oriole::Parser>::account_source+0x574>
   8e830:	0f b7 47 18                                     	movzwl 0x18(%rdi),%eax
   8e834:	66 0f 6e e0                                     	movd   %eax,%xmm4
   8e838:	0f b7 47 1a                                     	movzwl 0x1a(%rdi),%eax
   8e83c:	66 0f 6e e8                                     	movd   %eax,%xmm5
   8e840:	66 0f 64 e2                                     	pcmpgtb %xmm2,%xmm4
   8e844:	66 0f 60 e4                                     	punpcklbw %xmm4,%xmm4
   8e848:	f2 0f 70 e4 d4                                  	pshuflw $0xd4,%xmm4,%xmm4
   8e84d:	66 0f 70 e4 d4                                  	pshufd $0xd4,%xmm4,%xmm4
   8e852:	66 0f db e3                                     	pand   %xmm3,%xmm4
   8e856:	66 0f 64 ea                                     	pcmpgtb %xmm2,%xmm5
   8e85a:	66 0f 60 ed                                     	punpcklbw %xmm5,%xmm5
   8e85e:	f2 0f 70 d5 d4                                  	pshuflw $0xd4,%xmm5,%xmm2
   8e863:	66 0f 70 d2 d4                                  	pshufd $0xd4,%xmm2,%xmm2
   8e868:	66 0f db d3                                     	pand   %xmm3,%xmm2
   8e86c:	66 0f d4 c4                                     	paddq  %xmm4,%xmm0
   8e870:	66 0f d4 ca                                     	paddq  %xmm2,%xmm1
   8e874:	66 0f d4 c1                                     	paddq  %xmm1,%xmm0
   8e878:	66 0f 70 c8 ee                                  	pshufd $0xee,%xmm0,%xmm1
   8e87d:	66 0f d4 c8                                     	paddq  %xmm0,%xmm1
   8e881:	66 48 0f 7e c8                                  	movq   %xmm1,%rax
   8e886:	e9 71 05 00 00                                  	jmp    8edfc <<oriole::Parser>::account_source+0xafc>
   8e88b:	0f 84 0d fb ff ff                               	je     8e39e <<oriole::Parser>::account_source+0x9e>
   8e891:	4c 8d 05 18 46 08 00                            	lea    0x84618(%rip),%r8        # 112eb0 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.376.llvm.4530151907887530887>
   8e898:	48 89 ce                                        	mov    %rcx,%rsi
   8e89b:	48 89 c2                                        	mov    %rax,%rdx
   8e89e:	ff 15 64 6b 08 00                               	call   *0x86b64(%rip)        # 115408 <_DYNAMIC+0x358>
   8e8a4:	45 89 ca                                        	mov    %r9d,%r10d
   8e8a7:	41 83 e2 1f                                     	and    $0x1f,%r10d
   8e8ab:	0f b6 0a                                        	movzbl (%rdx),%ecx
   8e8ae:	83 e1 3f                                        	and    $0x3f,%ecx
   8e8b1:	41 80 f9 df                                     	cmp    $0xdf,%r9b
   8e8b5:	0f 87 d0 02 00 00                               	ja     8eb8b <<oriole::Parser>::account_source+0x88b>
   8e8bb:	48 ff c2                                        	inc    %rdx
   8e8be:	41 c1 e2 06                                     	shl    $0x6,%r10d
   8e8c2:	41 09 ca                                        	or     %ecx,%r10d
   8e8c5:	48 89 d1                                        	mov    %rdx,%rcx
   8e8c8:	45 89 d1                                        	mov    %r10d,%r9d
   8e8cb:	e9 a0 fc ff ff                                  	jmp    8e570 <<oriole::Parser>::account_source+0x270>
   8e8d0:	89 c1                                           	mov    %eax,%ecx
   8e8d2:	83 e1 1f                                        	and    $0x1f,%ecx
   8e8d5:	44 0f b6 5f 01                                  	movzbl 0x1(%rdi),%r11d
   8e8da:	41 83 e3 3f                                     	and    $0x3f,%r11d
   8e8de:	3c e0                                           	cmp    $0xe0,%al
   8e8e0:	0f 83 f4 02 00 00                               	jae    8ebda <<oriole::Parser>::account_source+0x8da>
   8e8e6:	4c 8d 4f 02                                     	lea    0x2(%rdi),%r9
   8e8ea:	c1 e1 06                                        	shl    $0x6,%ecx
   8e8ed:	44 09 d9                                        	or     %r11d,%ecx
   8e8f0:	e9 f6 fa ff ff                                  	jmp    8e3eb <<oriole::Parser>::account_source+0xeb>
   8e8f5:	44 89 d2                                        	mov    %r10d,%edx
   8e8f8:	83 e2 1f                                        	and    $0x1f,%edx
   8e8fb:	44 0f b6 19                                     	movzbl (%rcx),%r11d
   8e8ff:	41 83 e3 3f                                     	and    $0x3f,%r11d
   8e903:	41 80 fa e0                                     	cmp    $0xe0,%r10b
   8e907:	0f 83 04 03 00 00                               	jae    8ec11 <<oriole::Parser>::account_source+0x911>
   8e90d:	48 ff c1                                        	inc    %rcx
   8e910:	c1 e2 06                                        	shl    $0x6,%edx
   8e913:	44 09 da                                        	or     %r11d,%edx
   8e916:	e9 07 fb ff ff                                  	jmp    8e422 <<oriole::Parser>::account_source+0x122>
   8e91b:	44 89 d1                                        	mov    %r10d,%ecx
   8e91e:	83 e1 1f                                        	and    $0x1f,%ecx
   8e921:	44 0f b6 1a                                     	movzbl (%rdx),%r11d
   8e925:	41 83 e3 3f                                     	and    $0x3f,%r11d
   8e929:	41 80 fa e0                                     	cmp    $0xe0,%r10b
   8e92d:	0f 83 1a 03 00 00                               	jae    8ec4d <<oriole::Parser>::account_source+0x94d>
   8e933:	48 ff c2                                        	inc    %rdx
   8e936:	c1 e1 06                                        	shl    $0x6,%ecx
   8e939:	44 09 d9                                        	or     %r11d,%ecx
   8e93c:	e9 1b fb ff ff                                  	jmp    8e45c <<oriole::Parser>::account_source+0x15c>
   8e941:	44 89 d2                                        	mov    %r10d,%edx
   8e944:	83 e2 1f                                        	and    $0x1f,%edx
   8e947:	44 0f b6 19                                     	movzbl (%rcx),%r11d
   8e94b:	41 83 e3 3f                                     	and    $0x3f,%r11d
   8e94f:	41 80 fa e0                                     	cmp    $0xe0,%r10b
   8e953:	0f 83 30 03 00 00                               	jae    8ec89 <<oriole::Parser>::account_source+0x989>
   8e959:	48 ff c1                                        	inc    %rcx
   8e95c:	c1 e2 06                                        	shl    $0x6,%edx
   8e95f:	44 09 da                                        	or     %r11d,%edx
   8e962:	e9 2f fb ff ff                                  	jmp    8e496 <<oriole::Parser>::account_source+0x196>
   8e967:	44 89 d1                                        	mov    %r10d,%ecx
   8e96a:	83 e1 1f                                        	and    $0x1f,%ecx
   8e96d:	44 0f b6 1a                                     	movzbl (%rdx),%r11d
   8e971:	41 83 e3 3f                                     	and    $0x3f,%r11d
   8e975:	41 80 fa e0                                     	cmp    $0xe0,%r10b
   8e979:	0f 83 46 03 00 00                               	jae    8ecc5 <<oriole::Parser>::account_source+0x9c5>
   8e97f:	48 ff c2                                        	inc    %rdx
   8e982:	c1 e1 06                                        	shl    $0x6,%ecx
   8e985:	44 09 d9                                        	or     %r11d,%ecx
   8e988:	e9 43 fb ff ff                                  	jmp    8e4d0 <<oriole::Parser>::account_source+0x1d0>
   8e98d:	44 89 d1                                        	mov    %r10d,%ecx
   8e990:	83 e1 1f                                        	and    $0x1f,%ecx
   8e993:	45 0f b6 19                                     	movzbl (%r9),%r11d
   8e997:	41 83 e3 3f                                     	and    $0x3f,%r11d
   8e99b:	41 80 fa e0                                     	cmp    $0xe0,%r10b
   8e99f:	0f 83 6b 03 00 00                               	jae    8ed10 <<oriole::Parser>::account_source+0xa10>
   8e9a5:	49 ff c1                                        	inc    %r9
   8e9a8:	c1 e1 06                                        	shl    $0x6,%ecx
   8e9ab:	44 09 d9                                        	or     %r11d,%ecx
   8e9ae:	e9 57 fb ff ff                                  	jmp    8e50a <<oriole::Parser>::account_source+0x20a>
   8e9b3:	44 89 d2                                        	mov    %r10d,%edx
   8e9b6:	83 e2 1f                                        	and    $0x1f,%edx
   8e9b9:	44 0f b6 19                                     	movzbl (%rcx),%r11d
   8e9bd:	41 83 e3 3f                                     	and    $0x3f,%r11d
   8e9c1:	41 80 fa e0                                     	cmp    $0xe0,%r10b
   8e9c5:	0f 83 9e 03 00 00                               	jae    8ed69 <<oriole::Parser>::account_source+0xa69>
   8e9cb:	48 ff c1                                        	inc    %rcx
   8e9ce:	c1 e2 06                                        	shl    $0x6,%edx
   8e9d1:	44 09 da                                        	or     %r11d,%edx
   8e9d4:	e9 64 fb ff ff                                  	jmp    8e53d <<oriole::Parser>::account_source+0x23d>
   8e9d9:	4d 89 c4                                        	mov    %r8,%r12
   8e9dc:	49 89 f5                                        	mov    %rsi,%r13
   8e9df:	48 89 d6                                        	mov    %rdx,%rsi
   8e9e2:	ff 15 e0 69 08 00                               	call   *0x869e0(%rip)        # 1153c8 <_DYNAMIC+0x318>
   8e9e8:	4c 89 ee                                        	mov    %r13,%rsi
   8e9eb:	4d 89 e0                                        	mov    %r12,%r8
   8e9ee:	e9 50 f9 ff ff                                  	jmp    8e343 <<oriole::Parser>::account_source+0x43>
   8e9f3:	48 8d 3d 84 f2 f7 ff                            	lea    -0x80d7c(%rip),%rdi        # dc7e <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.24.llvm.4530151907887530887+0x1ba2>
   8e9fa:	48 8d 15 7f 50 08 00                            	lea    0x8507f(%rip),%rdx        # 113a80 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.621.llvm.4530151907887530887+0xc0>
   8ea01:	be 21 00 00 00                                  	mov    $0x21,%esi
   8ea06:	ff 15 34 6a 08 00                               	call   *0x86a34(%rip)        # 115440 <_DYNAMIC+0x390>
   8ea0c:	4c 8d 05 f5 43 08 00                            	lea    0x843f5(%rip),%r8        # 112e08 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.368.llvm.4530151907887530887>
   8ea13:	4c 89 ce                                        	mov    %r9,%rsi
   8ea16:	48 89 d1                                        	mov    %rdx,%rcx
   8ea19:	31 d2                                           	xor    %edx,%edx
   8ea1b:	ff 15 e7 69 08 00                               	call   *0x869e7(%rip)        # 115408 <_DYNAMIC+0x358>
   8ea21:	ba 02 00 00 00                                  	mov    $0x2,%edx
   8ea26:	e9 57 fb ff ff                                  	jmp    8e582 <<oriole::Parser>::account_source+0x282>
   8ea2b:	48 89 f1                                        	mov    %rsi,%rcx
   8ea2e:	48 8b 83 48 ff ff ff                            	mov    -0xb8(%rbx),%rax
   8ea35:	48 8b 7b a0                                     	mov    -0x60(%rbx),%rdi
   8ea39:	48 89 fe                                        	mov    %rdi,%rsi
   8ea3c:	48 01 d6                                        	add    %rdx,%rsi
   8ea3f:	0f 82 14 03 00 00                               	jb     8ed59 <<oriole::Parser>::account_source+0xa59>
   8ea45:	48 39 c6                                        	cmp    %rax,%rsi
   8ea48:	0f 87 0b 03 00 00                               	ja     8ed59 <<oriole::Parser>::account_source+0xa59>
   8ea4e:	49 89 d1                                        	mov    %rdx,%r9
   8ea51:	48 85 d2                                        	test   %rdx,%rdx
   8ea54:	74 4d                                           	je     8eaa3 <<oriole::Parser>::account_source+0x7a3>
   8ea56:	48 03 bb 38 ff ff ff                            	add    -0xc8(%rbx),%rdi
   8ea5d:	31 c0                                           	xor    %eax,%eax
   8ea5f:	31 d2                                           	xor    %edx,%edx
   8ea61:	48 89 ce                                        	mov    %rcx,%rsi
   8ea64:	0f b6 0c 17                                     	movzbl (%rdi,%rdx,1),%ecx
   8ea68:	48 01 c8                                        	add    %rcx,%rax
   8ea6b:	48 ff c2                                        	inc    %rdx
   8ea6e:	49 39 d1                                        	cmp    %rdx,%r9
   8ea71:	75 f1                                           	jne    8ea64 <<oriole::Parser>::account_source+0x764>
   8ea73:	e9 cb f8 ff ff                                  	jmp    8e343 <<oriole::Parser>::account_source+0x43>
   8ea78:	b8 02 00 00 00                                  	mov    $0x2,%eax
   8ea7d:	e9 7d f9 ff ff                                  	jmp    8e3ff <<oriole::Parser>::account_source+0xff>
   8ea82:	41 b9 02 00 00 00                               	mov    $0x2,%r9d
   8ea88:	e9 a7 f9 ff ff                                  	jmp    8e434 <<oriole::Parser>::account_source+0x134>
   8ea8d:	41 b9 02 00 00 00                               	mov    $0x2,%r9d
   8ea93:	e9 d6 f9 ff ff                                  	jmp    8e46e <<oriole::Parser>::account_source+0x16e>
   8ea98:	41 b9 02 00 00 00                               	mov    $0x2,%r9d
   8ea9e:	e9 05 fa ff ff                                  	jmp    8e4a8 <<oriole::Parser>::account_source+0x1a8>
   8eaa3:	31 c0                                           	xor    %eax,%eax
   8eaa5:	48 89 ce                                        	mov    %rcx,%rsi
   8eaa8:	e9 96 f8 ff ff                                  	jmp    8e343 <<oriole::Parser>::account_source+0x43>
   8eaad:	41 b9 02 00 00 00                               	mov    $0x2,%r9d
   8eab3:	e9 2a fa ff ff                                  	jmp    8e4e2 <<oriole::Parser>::account_source+0x1e2>
   8eab8:	0f 0b                                           	ud2
   8eaba:	ba 02 00 00 00                                  	mov    $0x2,%edx
   8eabf:	e9 57 fa ff ff                                  	jmp    8e51b <<oriole::Parser>::account_source+0x21b>
   8eac4:	49 83 fa e9                                     	cmp    $0xffffffffffffffe9,%r10
   8eac8:	49 89 f8                                        	mov    %rdi,%r8
   8eacb:	48 89 c6                                        	mov    %rax,%rsi
   8eace:	77 70                                           	ja     8eb40 <<oriole::Parser>::account_source+0x840>
   8ead0:	49 83 c2 16                                     	add    $0x16,%r10
   8ead4:	0f 88 8e 00 00 00                               	js     8eb68 <<oriole::Parser>::account_source+0x868>
   8eada:	0f 57 c0                                        	xorps  %xmm0,%xmm0
   8eadd:	f3 49 0f 2a c2                                  	cvtsi2ss %r10,%xmm0
   8eae2:	e9 9a 00 00 00                                  	jmp    8eb81 <<oriole::Parser>::account_source+0x881>
   8eae7:	4c 89 de                                        	mov    %r11,%rsi
   8eaea:	48 d1 ee                                        	shr    $1,%rsi
   8eaed:	41 83 e3 01                                     	and    $0x1,%r11d
   8eaf1:	49 09 f3                                        	or     %rsi,%r11
   8eaf4:	0f 57 c0                                        	xorps  %xmm0,%xmm0
   8eaf7:	f3 49 0f 2a c3                                  	cvtsi2ss %r11,%xmm0
   8eafc:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   8eb00:	4d 85 c9                                        	test   %r9,%r9
   8eb03:	78 0a                                           	js     8eb0f <<oriole::Parser>::account_source+0x80f>
   8eb05:	0f 57 c9                                        	xorps  %xmm1,%xmm1
   8eb08:	f3 49 0f 2a c9                                  	cvtsi2ss %r9,%xmm1
   8eb0d:	eb 19                                           	jmp    8eb28 <<oriole::Parser>::account_source+0x828>
   8eb0f:	4c 89 ce                                        	mov    %r9,%rsi
   8eb12:	48 d1 ee                                        	shr    $1,%rsi
   8eb15:	41 83 e1 01                                     	and    $0x1,%r9d
   8eb19:	49 09 f1                                        	or     %rsi,%r9
   8eb1c:	0f 57 c9                                        	xorps  %xmm1,%xmm1
   8eb1f:	f3 49 0f 2a c9                                  	cvtsi2ss %r9,%xmm1
   8eb24:	f3 0f 58 c9                                     	addss  %xmm1,%xmm1
   8eb28:	f3 0f 5e c1                                     	divss  %xmm1,%xmm0
   8eb2c:	f3 0f 10 4a 48                                  	movss  0x48(%rdx),%xmm1
   8eb31:	0f 2e c8                                        	ucomiss %xmm0,%xmm1
   8eb34:	49 89 f8                                        	mov    %rdi,%r8
   8eb37:	48 89 c6                                        	mov    %rax,%rsi
   8eb3a:	0f 83 16 f8 ff ff                               	jae    8e356 <<oriole::Parser>::account_source+0x56>
   8eb40:	49 8d 78 10                                     	lea    0x10(%r8),%rdi
   8eb44:	4c 89 c3                                        	mov    %r8,%rbx
   8eb47:	e8 64 ac f9 ff                                  	call   297b0 <<oriole::Parser>::here>
   8eb4c:	49 89 d8                                        	mov    %rbx,%r8
   8eb4f:	48 8d 05 34 f3 f7 ff                            	lea    -0x80ccc(%rip),%rax        # de8a <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.24.llvm.4530151907887530887+0x1dae>
   8eb56:	48 89 03                                        	mov    %rax,(%rbx)
   8eb59:	48 c7 43 08 23 00 00 00                         	movq   $0x23,0x8(%rbx)
   8eb61:	b0 1e                                           	mov    $0x1e,%al
   8eb63:	e9 f4 f7 ff ff                                  	jmp    8e35c <<oriole::Parser>::account_source+0x5c>
   8eb68:	4c 89 d6                                        	mov    %r10,%rsi
   8eb6b:	48 d1 ee                                        	shr    $1,%rsi
   8eb6e:	41 83 e2 01                                     	and    $0x1,%r10d
   8eb72:	49 09 f2                                        	or     %rsi,%r10
   8eb75:	0f 57 c0                                        	xorps  %xmm0,%xmm0
   8eb78:	f3 49 0f 2a c2                                  	cvtsi2ss %r10,%xmm0
   8eb7d:	f3 0f 58 c0                                     	addss  %xmm0,%xmm0
   8eb81:	f3 0f 5e 05 77 c2 f7 ff                         	divss  -0x83d89(%rip),%xmm0        # ae00 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x8c>
   8eb89:	eb a1                                           	jmp    8eb2c <<oriole::Parser>::account_source+0x82c>
   8eb8b:	44 0f b6 5a 01                                  	movzbl 0x1(%rdx),%r11d
   8eb90:	c1 e1 06                                        	shl    $0x6,%ecx
   8eb93:	41 83 e3 3f                                     	and    $0x3f,%r11d
   8eb97:	41 09 cb                                        	or     %ecx,%r11d
   8eb9a:	41 80 f9 f0                                     	cmp    $0xf0,%r9b
   8eb9e:	72 24                                           	jb     8ebc4 <<oriole::Parser>::account_source+0x8c4>
   8eba0:	44 0f b6 4a 02                                  	movzbl 0x2(%rdx),%r9d
   8eba5:	48 83 c2 03                                     	add    $0x3,%rdx
   8eba9:	41 83 e2 07                                     	and    $0x7,%r10d
   8ebad:	41 c1 e2 12                                     	shl    $0x12,%r10d
   8ebb1:	41 c1 e3 06                                     	shl    $0x6,%r11d
   8ebb5:	41 83 e1 3f                                     	and    $0x3f,%r9d
   8ebb9:	45 09 d9                                        	or     %r11d,%r9d
   8ebbc:	45 09 d1                                        	or     %r10d,%r9d
   8ebbf:	e9 a9 f9 ff ff                                  	jmp    8e56d <<oriole::Parser>::account_source+0x26d>
   8ebc4:	48 83 c2 02                                     	add    $0x2,%rdx
   8ebc8:	41 c1 e2 0c                                     	shl    $0xc,%r10d
   8ebcc:	45 09 d3                                        	or     %r10d,%r11d
   8ebcf:	48 89 d1                                        	mov    %rdx,%rcx
   8ebd2:	45 89 d9                                        	mov    %r11d,%r9d
   8ebd5:	e9 96 f9 ff ff                                  	jmp    8e570 <<oriole::Parser>::account_source+0x270>
   8ebda:	44 0f b6 57 02                                  	movzbl 0x2(%rdi),%r10d
   8ebdf:	41 c1 e3 06                                     	shl    $0x6,%r11d
   8ebe3:	41 83 e2 3f                                     	and    $0x3f,%r10d
   8ebe7:	45 09 da                                        	or     %r11d,%r10d
   8ebea:	3c f0                                           	cmp    $0xf0,%al
   8ebec:	0f 82 0f 01 00 00                               	jb     8ed01 <<oriole::Parser>::account_source+0xa01>
   8ebf2:	4c 8d 4f 04                                     	lea    0x4(%rdi),%r9
   8ebf6:	0f b6 47 03                                     	movzbl 0x3(%rdi),%eax
   8ebfa:	83 e1 07                                        	and    $0x7,%ecx
   8ebfd:	c1 e1 12                                        	shl    $0x12,%ecx
   8ec00:	41 c1 e2 06                                     	shl    $0x6,%r10d
   8ec04:	83 e0 3f                                        	and    $0x3f,%eax
   8ec07:	44 09 d0                                        	or     %r10d,%eax
   8ec0a:	09 c1                                           	or     %eax,%ecx
   8ec0c:	e9 da f7 ff ff                                  	jmp    8e3eb <<oriole::Parser>::account_source+0xeb>
   8ec11:	44 0f b6 49 01                                  	movzbl 0x1(%rcx),%r9d
   8ec16:	41 c1 e3 06                                     	shl    $0x6,%r11d
   8ec1a:	41 83 e1 3f                                     	and    $0x3f,%r9d
   8ec1e:	45 09 d9                                        	or     %r11d,%r9d
   8ec21:	41 80 fa f0                                     	cmp    $0xf0,%r10b
   8ec25:	0f 82 1f 01 00 00                               	jb     8ed4a <<oriole::Parser>::account_source+0xa4a>
   8ec2b:	44 0f b6 51 02                                  	movzbl 0x2(%rcx),%r10d
   8ec30:	48 83 c1 03                                     	add    $0x3,%rcx
   8ec34:	83 e2 07                                        	and    $0x7,%edx
   8ec37:	c1 e2 12                                        	shl    $0x12,%edx
   8ec3a:	41 c1 e1 06                                     	shl    $0x6,%r9d
   8ec3e:	41 83 e2 3f                                     	and    $0x3f,%r10d
   8ec42:	45 09 ca                                        	or     %r9d,%r10d
   8ec45:	44 09 d2                                        	or     %r10d,%edx
   8ec48:	e9 d5 f7 ff ff                                  	jmp    8e422 <<oriole::Parser>::account_source+0x122>
   8ec4d:	44 0f b6 4a 01                                  	movzbl 0x1(%rdx),%r9d
   8ec52:	41 c1 e3 06                                     	shl    $0x6,%r11d
   8ec56:	41 83 e1 3f                                     	and    $0x3f,%r9d
   8ec5a:	45 09 d9                                        	or     %r11d,%r9d
   8ec5d:	41 80 fa f0                                     	cmp    $0xf0,%r10b
   8ec61:	0f 82 3a 01 00 00                               	jb     8eda1 <<oriole::Parser>::account_source+0xaa1>
   8ec67:	44 0f b6 52 02                                  	movzbl 0x2(%rdx),%r10d
   8ec6c:	48 83 c2 03                                     	add    $0x3,%rdx
   8ec70:	83 e1 07                                        	and    $0x7,%ecx
   8ec73:	c1 e1 12                                        	shl    $0x12,%ecx
   8ec76:	41 c1 e1 06                                     	shl    $0x6,%r9d
   8ec7a:	41 83 e2 3f                                     	and    $0x3f,%r10d
   8ec7e:	45 09 ca                                        	or     %r9d,%r10d
   8ec81:	44 09 d1                                        	or     %r10d,%ecx
   8ec84:	e9 d3 f7 ff ff                                  	jmp    8e45c <<oriole::Parser>::account_source+0x15c>
   8ec89:	44 0f b6 49 01                                  	movzbl 0x1(%rcx),%r9d
   8ec8e:	41 c1 e3 06                                     	shl    $0x6,%r11d
   8ec92:	41 83 e1 3f                                     	and    $0x3f,%r9d
   8ec96:	45 09 d9                                        	or     %r11d,%r9d
   8ec99:	41 80 fa f0                                     	cmp    $0xf0,%r10b
   8ec9d:	0f 82 0d 01 00 00                               	jb     8edb0 <<oriole::Parser>::account_source+0xab0>
   8eca3:	44 0f b6 51 02                                  	movzbl 0x2(%rcx),%r10d
   8eca8:	48 83 c1 03                                     	add    $0x3,%rcx
   8ecac:	83 e2 07                                        	and    $0x7,%edx
   8ecaf:	c1 e2 12                                        	shl    $0x12,%edx
   8ecb2:	41 c1 e1 06                                     	shl    $0x6,%r9d
   8ecb6:	41 83 e2 3f                                     	and    $0x3f,%r10d
   8ecba:	45 09 ca                                        	or     %r9d,%r10d
   8ecbd:	44 09 d2                                        	or     %r10d,%edx
   8ecc0:	e9 d1 f7 ff ff                                  	jmp    8e496 <<oriole::Parser>::account_source+0x196>
   8ecc5:	44 0f b6 4a 01                                  	movzbl 0x1(%rdx),%r9d
   8ecca:	41 c1 e3 06                                     	shl    $0x6,%r11d
   8ecce:	41 83 e1 3f                                     	and    $0x3f,%r9d
   8ecd2:	45 09 d9                                        	or     %r11d,%r9d
   8ecd5:	41 80 fa f0                                     	cmp    $0xf0,%r10b
   8ecd9:	0f 82 e0 00 00 00                               	jb     8edbf <<oriole::Parser>::account_source+0xabf>
   8ecdf:	44 0f b6 52 02                                  	movzbl 0x2(%rdx),%r10d
   8ece4:	48 83 c2 03                                     	add    $0x3,%rdx
   8ece8:	83 e1 07                                        	and    $0x7,%ecx
   8eceb:	c1 e1 12                                        	shl    $0x12,%ecx
   8ecee:	41 c1 e1 06                                     	shl    $0x6,%r9d
   8ecf2:	41 83 e2 3f                                     	and    $0x3f,%r10d
   8ecf6:	45 09 ca                                        	or     %r9d,%r10d
   8ecf9:	44 09 d1                                        	or     %r10d,%ecx
   8ecfc:	e9 cf f7 ff ff                                  	jmp    8e4d0 <<oriole::Parser>::account_source+0x1d0>
   8ed01:	4c 8d 4f 03                                     	lea    0x3(%rdi),%r9
   8ed05:	c1 e1 0c                                        	shl    $0xc,%ecx
   8ed08:	44 09 d1                                        	or     %r10d,%ecx
   8ed0b:	e9 db f6 ff ff                                  	jmp    8e3eb <<oriole::Parser>::account_source+0xeb>
   8ed10:	41 0f b6 51 01                                  	movzbl 0x1(%r9),%edx
   8ed15:	41 c1 e3 06                                     	shl    $0x6,%r11d
   8ed19:	83 e2 3f                                        	and    $0x3f,%edx
   8ed1c:	44 09 da                                        	or     %r11d,%edx
   8ed1f:	41 80 fa f0                                     	cmp    $0xf0,%r10b
   8ed23:	0f 82 a5 00 00 00                               	jb     8edce <<oriole::Parser>::account_source+0xace>
   8ed29:	45 0f b6 51 02                                  	movzbl 0x2(%r9),%r10d
   8ed2e:	49 83 c1 03                                     	add    $0x3,%r9
   8ed32:	83 e1 07                                        	and    $0x7,%ecx
   8ed35:	c1 e1 12                                        	shl    $0x12,%ecx
   8ed38:	c1 e2 06                                        	shl    $0x6,%edx
   8ed3b:	41 83 e2 3f                                     	and    $0x3f,%r10d
   8ed3f:	41 09 d2                                        	or     %edx,%r10d
   8ed42:	44 09 d1                                        	or     %r10d,%ecx
   8ed45:	e9 c0 f7 ff ff                                  	jmp    8e50a <<oriole::Parser>::account_source+0x20a>
   8ed4a:	48 83 c1 02                                     	add    $0x2,%rcx
   8ed4e:	c1 e2 0c                                        	shl    $0xc,%edx
   8ed51:	44 09 ca                                        	or     %r9d,%edx
   8ed54:	e9 c9 f6 ff ff                                  	jmp    8e422 <<oriole::Parser>::account_source+0x122>
   8ed59:	48 8d 0d 90 40 08 00                            	lea    0x84090(%rip),%rcx        # 112df0 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.367.llvm.4530151907887530887>
   8ed60:	48 89 c2                                        	mov    %rax,%rdx
   8ed63:	ff 15 8f 66 08 00                               	call   *0x8668f(%rip)        # 1153f8 <_DYNAMIC+0x348>
   8ed69:	44 0f b6 49 01                                  	movzbl 0x1(%rcx),%r9d
   8ed6e:	41 c1 e3 06                                     	shl    $0x6,%r11d
   8ed72:	41 83 e1 3f                                     	and    $0x3f,%r9d
   8ed76:	45 09 d9                                        	or     %r11d,%r9d
   8ed79:	41 80 fa f0                                     	cmp    $0xf0,%r10b
   8ed7d:	72 5d                                           	jb     8eddc <<oriole::Parser>::account_source+0xadc>
   8ed7f:	44 0f b6 51 02                                  	movzbl 0x2(%rcx),%r10d
   8ed84:	48 83 c1 03                                     	add    $0x3,%rcx
   8ed88:	83 e2 07                                        	and    $0x7,%edx
   8ed8b:	c1 e2 12                                        	shl    $0x12,%edx
   8ed8e:	41 c1 e1 06                                     	shl    $0x6,%r9d
   8ed92:	41 83 e2 3f                                     	and    $0x3f,%r10d
   8ed96:	45 09 ca                                        	or     %r9d,%r10d
   8ed99:	44 09 d2                                        	or     %r10d,%edx
   8ed9c:	e9 9c f7 ff ff                                  	jmp    8e53d <<oriole::Parser>::account_source+0x23d>
   8eda1:	48 83 c2 02                                     	add    $0x2,%rdx
   8eda5:	c1 e1 0c                                        	shl    $0xc,%ecx
   8eda8:	44 09 c9                                        	or     %r9d,%ecx
   8edab:	e9 ac f6 ff ff                                  	jmp    8e45c <<oriole::Parser>::account_source+0x15c>
   8edb0:	48 83 c1 02                                     	add    $0x2,%rcx
   8edb4:	c1 e2 0c                                        	shl    $0xc,%edx
   8edb7:	44 09 ca                                        	or     %r9d,%edx
   8edba:	e9 d7 f6 ff ff                                  	jmp    8e496 <<oriole::Parser>::account_source+0x196>
   8edbf:	48 83 c2 02                                     	add    $0x2,%rdx
   8edc3:	c1 e1 0c                                        	shl    $0xc,%ecx
   8edc6:	44 09 c9                                        	or     %r9d,%ecx
   8edc9:	e9 02 f7 ff ff                                  	jmp    8e4d0 <<oriole::Parser>::account_source+0x1d0>
   8edce:	49 83 c1 02                                     	add    $0x2,%r9
   8edd2:	c1 e1 0c                                        	shl    $0xc,%ecx
   8edd5:	09 d1                                           	or     %edx,%ecx
   8edd7:	e9 2e f7 ff ff                                  	jmp    8e50a <<oriole::Parser>::account_source+0x20a>
   8eddc:	48 83 c1 02                                     	add    $0x2,%rcx
   8ede0:	c1 e2 0c                                        	shl    $0xc,%edx
   8ede3:	44 09 ca                                        	or     %r9d,%edx
   8ede6:	e9 52 f7 ff ff                                  	jmp    8e53d <<oriole::Parser>::account_source+0x23d>
   8edeb:	45 31 c9                                        	xor    %r9d,%r9d
   8edee:	80 3c 0f c0                                     	cmpb   $0xc0,(%rdi,%rcx,1)
   8edf2:	41 0f 9d c1                                     	setge  %r9b
   8edf6:	4c 01 c8                                        	add    %r9,%rax
   8edf9:	48 ff c1                                        	inc    %rcx
   8edfc:	48 39 ca                                        	cmp    %rcx,%rdx
   8edff:	75 ea                                           	jne    8edeb <<oriole::Parser>::account_source+0xaeb>
   8ee01:	e9 3d f5 ff ff                                  	jmp    8e343 <<oriole::Parser>::account_source+0x43>
