   a2760:	53                                              	push   %rbx
   a2761:	48 89 d1                                        	mov    %rdx,%rcx
   a2764:	4c 8b 46 28                                     	mov    0x28(%rsi),%r8
   a2768:	80 3e 00                                        	cmpb   $0x0,(%rsi)
   a276b:	74 60                                           	je     a27cd <<oriole::Parser>::charge_expansion+0x6d>
   a276d:	4c 8b 8e e8 08 00 00                            	mov    0x8e8(%rsi),%r9
   a2774:	49 8b 41 30                                     	mov    0x30(%r9),%rax
   a2778:	48 f7 66 08                                     	mulq   0x8(%rsi)
   a277c:	70 58                                           	jo     a27d6 <<oriole::Parser>::charge_expansion+0x76>
   a277e:	4c 39 c0                                        	cmp    %r8,%rax
   a2781:	4c 0f 47 c0                                     	cmova  %rax,%r8
   a2785:	49 8b 41 28                                     	mov    0x28(%r9),%rax
   a2789:	48 89 c2                                        	mov    %rax,%rdx
   a278c:	48 01 ca                                        	add    %rcx,%rdx
   a278f:	72 14                                           	jb     a27a5 <<oriole::Parser>::charge_expansion+0x45>
   a2791:	4c 39 c2                                        	cmp    %r8,%rdx
   a2794:	77 0f                                           	ja     a27a5 <<oriole::Parser>::charge_expansion+0x45>
   a2796:	f0 49 0f b1 51 28                               	lock cmpxchg %rdx,0x28(%r9)
   a279c:	b2 ff                                           	mov    $0xff,%dl
   a279e:	75 e9                                           	jne    a2789 <<oriole::Parser>::charge_expansion+0x29>
   a27a0:	88 57 30                                        	mov    %dl,0x30(%rdi)
   a27a3:	5b                                              	pop    %rbx
   a27a4:	c3                                              	ret
   a27a5:	48 8d 47 10                                     	lea    0x10(%rdi),%rax
   a27a9:	48 89 fb                                        	mov    %rdi,%rbx
   a27ac:	48 89 c7                                        	mov    %rax,%rdi
   a27af:	e8 fc 6f f8 ff                                  	call   297b0 <<oriole::Parser>::here>
   a27b4:	48 89 df                                        	mov    %rbx,%rdi
   a27b7:	48 8d 05 f2 b8 f6 ff                            	lea    -0x9470e(%rip),%rax        # e0b0 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.24.llvm.4530151907887530887+0x1fd4>
   a27be:	48 89 03                                        	mov    %rax,(%rbx)
   a27c1:	48 c7 43 08 24 00 00 00                         	movq   $0x24,0x8(%rbx)
   a27c9:	b2 1e                                           	mov    $0x1e,%dl
   a27cb:	eb d3                                           	jmp    a27a0 <<oriole::Parser>::charge_expansion+0x40>
   a27cd:	4c 8b 8e e8 08 00 00                            	mov    0x8e8(%rsi),%r9
   a27d4:	eb af                                           	jmp    a2785 <<oriole::Parser>::charge_expansion+0x25>
   a27d6:	48 c7 c0 ff ff ff ff                            	mov    $0xffffffffffffffff,%rax
   a27dd:	eb 9f                                           	jmp    a277e <<oriole::Parser>::charge_expansion+0x1e>
