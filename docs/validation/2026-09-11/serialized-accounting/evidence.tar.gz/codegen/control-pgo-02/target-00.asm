0xa2760: 53  push   %rbx
0xa2761: 4889d1  mov    %rdx,%rcx
0xa2764: 4c8b4628  mov    0x28(%rsi),%r8
0xa2768: 803e00  cmpb   $0x0,(%rsi)
0xa276b: 7460  je     a27cd <<oriole::Parser>::charge_expansion+0x6d>
0xa276d: 4c8b8ee8080000  mov    0x8e8(%rsi),%r9
0xa2774: 498b4130  mov    0x30(%r9),%rax
0xa2778: 48f76608  mulq   0x8(%rsi)
0xa277c: 7058  jo     a27d6 <<oriole::Parser>::charge_expansion+0x76>
0xa277e: 4c39c0  cmp    %r8,%rax
0xa2781: 4c0f47c0  cmova  %rax,%r8
0xa2785: 498b4128  mov    0x28(%r9),%rax
0xa2789: 4889c2  mov    %rax,%rdx
0xa278c: 4801ca  add    %rcx,%rdx
0xa278f: 7214  jb     a27a5 <<oriole::Parser>::charge_expansion+0x45>
0xa2791: 4c39c2  cmp    %r8,%rdx
0xa2794: 770f  ja     a27a5 <<oriole::Parser>::charge_expansion+0x45>
0xa2796: f0490fb15128  lock cmpxchg %rdx,0x28(%r9)
0xa279c: b2ff  mov    $0xff,%dl
0xa279e: 75e9  jne    a2789 <<oriole::Parser>::charge_expansion+0x29>
0xa27a0: 885730  mov    %dl,0x30(%rdi)
0xa27a3: 5b  pop    %rbx
0xa27a4: c3  ret
0xa27a5: 488d4710  lea    0x10(%rdi),%rax
0xa27a9: 4889fb  mov    %rdi,%rbx
0xa27ac: 4889c7  mov    %rax,%rdi
0xa27af: e8fc6ff8ff  call   297b0 <<oriole::Parser>::here>
0xa27b4: 4889df  mov    %rbx,%rdi
0xa27b7: 488d05f2b8f6ff  lea    -0x9470e(%rip),%rax        # e0b0 <anon.0bd59d8d17ee2316f14fc4ed73db6dc3.24.llvm.4530151907887530887+0x1fd4>
0xa27be: 488903  mov    %rax,(%rbx)
0xa27c1: 48c7430824000000  movq   $0x24,0x8(%rbx)
0xa27c9: b21e  mov    $0x1e,%dl
0xa27cb: ebd3  jmp    a27a0 <<oriole::Parser>::charge_expansion+0x40>
0xa27cd: 4c8b8ee8080000  mov    0x8e8(%rsi),%r9
0xa27d4: ebaf  jmp    a2785 <<oriole::Parser>::charge_expansion+0x25>
0xa27d6: 48c7c0ffffffff  mov    $0xffffffffffffffff,%rax
0xa27dd: eb9f  jmp    a277e <<oriole::Parser>::charge_expansion+0x1e>
