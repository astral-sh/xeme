0xb6ad0: b001  mov    $0x1,%al
0xb6ad2: 4885f6  test   %rsi,%rsi
0xb6ad5: 7501  jne    b6ad8 <<oriole::accounting::EntityBudget>::account+0x8>
0xb6ad7: c3  ret
0xb6ad8: 488b4f10  mov    0x10(%rdi),%rcx
0xb6adc: 4889ca  mov    %rcx,%rdx
0xb6adf: 4801f2  add    %rsi,%rdx
0xb6ae2: 724d  jb     b6b31 <<oriole::accounting::EntityBudget>::account+0x61>
0xb6ae4: 4889c8  mov    %rcx,%rax
0xb6ae7: f0480fb15710  lock cmpxchg %rdx,0x10(%rdi)
0xb6aed: 4889c1  mov    %rax,%rcx
0xb6af0: b001  mov    $0x1,%al
0xb6af2: 75e8  jne    b6adc <<oriole::accounting::EntityBudget>::account+0xc>
0xb6af4: 488b4f08  mov    0x8(%rdi),%rcx
0xb6af8: 488b5710  mov    0x10(%rdi),%rdx
0xb6afc: 4889d6  mov    %rdx,%rsi
0xb6aff: 4801ce  add    %rcx,%rsi
0xb6b02: 722d  jb     b6b31 <<oriole::accounting::EntityBudget>::account+0x61>
0xb6b04: 4c8b4718  mov    0x18(%rdi),%r8
0xb6b08: 4c39c6  cmp    %r8,%rsi
0xb6b0b: 72ca  jb     b6ad7 <<oriole::accounting::EntityBudget>::account+0x7>
0xb6b0d: 4885c9  test   %rcx,%rcx
0xb6b10: 740c  je     b6b1e <<oriole::accounting::EntityBudget>::account+0x4e>
0xb6b12: 4885f6  test   %rsi,%rsi
0xb6b15: 781e  js     b6b35 <<oriole::accounting::EntityBudget>::account+0x65>
0xb6b17: f3480f2ac6  cvtsi2ss %rsi,%xmm0
0xb6b1c: eb2c  jmp    b6b4a <<oriole::accounting::EntityBudget>::account+0x7a>
0xb6b1e: 4883fae9  cmp    $0xffffffffffffffe9,%rdx
0xb6b22: 770d  ja     b6b31 <<oriole::accounting::EntityBudget>::account+0x61>
0xb6b24: 4883c216  add    $0x16,%rdx
0xb6b28: 7855  js     b6b7f <<oriole::accounting::EntityBudget>::account+0xaf>
0xb6b2a: f3480f2ac2  cvtsi2ss %rdx,%xmm0
0xb6b2f: eb63  jmp    b6b94 <<oriole::accounting::EntityBudget>::account+0xc4>
0xb6b31: 31c0  xor    %eax,%eax
0xb6b33: eba2  jmp    b6ad7 <<oriole::accounting::EntityBudget>::account+0x7>
0xb6b35: 4889f0  mov    %rsi,%rax
0xb6b38: 48d1e8  shr    $1,%rax
0xb6b3b: 83e601  and    $0x1,%esi
0xb6b3e: 4809c6  or     %rax,%rsi
0xb6b41: f3480f2ac6  cvtsi2ss %rsi,%xmm0
0xb6b46: f30f58c0  addss  %xmm0,%xmm0
0xb6b4a: 4885c9  test   %rcx,%rcx
0xb6b4d: 7807  js     b6b56 <<oriole::accounting::EntityBudget>::account+0x86>
0xb6b4f: f3480f2ac9  cvtsi2ss %rcx,%xmm1
0xb6b54: eb15  jmp    b6b6b <<oriole::accounting::EntityBudget>::account+0x9b>
0xb6b56: 4889c8  mov    %rcx,%rax
0xb6b59: 48d1e8  shr    $1,%rax
0xb6b5c: 83e101  and    $0x1,%ecx
0xb6b5f: 4809c1  or     %rax,%rcx
0xb6b62: f3480f2ac9  cvtsi2ss %rcx,%xmm1
0xb6b67: f30f58c9  addss  %xmm1,%xmm1
0xb6b6b: f30f5ec1  divss  %xmm1,%xmm0
0xb6b6f: f30f104f20  movss  0x20(%rdi),%xmm1
0xb6b74: 0f2ec8  ucomiss %xmm0,%xmm1
0xb6b77: 0f93c0  setae  %al
0xb6b7a: e958ffffff  jmp    b6ad7 <<oriole::accounting::EntityBudget>::account+0x7>
0xb6b7f: 4889d0  mov    %rdx,%rax
0xb6b82: 48d1e8  shr    $1,%rax
0xb6b85: 83e201  and    $0x1,%edx
0xb6b88: 4809c2  or     %rax,%rdx
0xb6b8b: f3480f2ac2  cvtsi2ss %rdx,%xmm0
0xb6b90: f30f58c0  addss  %xmm0,%xmm0
0xb6b94: f30f5e056442f5ff  divss  -0xabd9c(%rip),%xmm0        # ae00 <core::unicode::unicode_data::cf::SHORT_OFFSET_RUNS+0x8c>
0xb6b9c: ebd1  jmp    b6b6f <<oriole::accounting::EntityBudget>::account+0x9f>
