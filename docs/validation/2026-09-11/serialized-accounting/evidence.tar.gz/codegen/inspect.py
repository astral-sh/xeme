"""Inspect released ELF bytes; never load a parser or infer speed from lock counts."""

import argparse
from bisect import bisect_left
import hashlib
import json
from pathlib import Path
import re
import signal
import struct
import subprocess
import time


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(out, label, argv):
    started = time.time()
    with (out / f'{label}.stdout').open('wb') as stdout, (out / f'{label}.stderr').open('wb') as stderr:
        process = subprocess.Popen(argv, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = process.wait(timeout=60)
        except BaseException:
            if process.poll() is None:
                import os
                os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            raise
    record = {'argv': argv, 'exit': code, 'reaped': process.poll() is not None,
              'started': started, 'completed': time.time(),
              'stdout_sha256': sha(out / f'{label}.stdout'),
              'stderr_sha256': sha(out / f'{label}.stderr')}
    (out / f'{label}.json').write_text(json.dumps(record, indent=2) + '\n')
    if code:
        raise RuntimeError(f'{label} exited {code}')
    return (out / f'{label}.stdout').read_text()


def main():
    args = argparse.ArgumentParser()
    args.add_argument('--library', type=Path, required=True)
    args.add_argument('--sha256', required=True)
    args.add_argument('--out', type=Path, required=True)
    options = args.parse_args()
    library = options.library.resolve()
    assert sha(library) == options.sha256
    out = options.out
    out.mkdir(parents=True, exist_ok=False)
    binary = library.read_bytes()
    assert binary[:6] == b'\x7fELF\x02\x01', 'requires ELF64 little-endian'
    assert struct.unpack_from('<H', binary, 18)[0] == 62, 'requires x86_64'
    phoff = struct.unpack_from('<Q', binary, 32)[0]
    phsize, phcount = struct.unpack_from('<HH', binary, 54)
    loads = []
    for index in range(phcount):
        kind, flags, offset, address, _, size, _, _ = struct.unpack_from('<IIQQQQQQ', binary, phoff + index * phsize)
        if kind == 1 and flags & 1:
            loads.append((address, address + size, offset))
    symbols_text = command(out, 'nm', ['nm', '-S', '-n', '--defined-only', '-C', str(library)])
    assembly = command(out, 'objdump', ['objdump', '-d', '-C', '-w', '--insn-width=16', str(library)])
    symbols = []
    for line in symbols_text.splitlines():
        match = re.fullmatch(r'([0-9a-fA-F]+) ([0-9a-fA-F]+) ([tT]) (.+)', line)
        if match:
            symbols.append({'address': int(match[1], 16), 'size': int(match[2], 16), 'name': match[4]})
    instructions = {}
    for line in assembly.splitlines():
        match = re.match(r'^\s*([0-9a-fA-F]+):\s*((?:[0-9a-fA-F]{2}\s+)+)(\S.*)?$', line)
        if not match:
            continue
        address = int(match[1], 16)
        data = bytes.fromhex(match[2])
        segments = [(start, end, offset) for start, end, offset in loads if start <= address and address + len(data) <= end]
        assert len(segments) == 1, hex(address)
        start, _, offset = segments[0]
        assert binary[offset + address - start:offset + address - start + len(data)] == data, hex(address)
        assert address not in instructions, hex(address)
        instructions[address] = {'address': hex(address), 'bytes': data.hex(), 'asm': match[3] or ''}
    assert instructions and symbols
    addresses = sorted(instructions)
    ordered_instructions = [instructions[address] for address in addresses]
    targets = []
    helpers_with_atomics = []
    for symbol in symbols:
        name = symbol['name']
        rows = ordered_instructions[bisect_left(addresses, symbol['address']):bisect_left(addresses, symbol['address'] + symbol['size'])]
        atomics = [row for row in rows if re.search(r'\block\b|\bcmpxchg\w*\b|\bxadd\w*\b', row['asm'])]
        category = None
        if 'EntityBudget' in name and re.search(r'::account(?:\.llvm\..*)?$', name):
            category = 'entity_account'
        elif '::charge_expansion' in name:
            category = 'expanded_work'
        elif 'accounting::' in name and 'add_with_limit' in name:
            category = 'counter_update'
        if category:
            calls = [row for row in rows if re.match(r'(?:call\w*|jmp\w*)\s', row['asm'])]
            index = len(targets)
            (out / f'target-{index:02}.asm').write_text('\n'.join(f"{row['address']}: {row['bytes']}  {row['asm']}" for row in rows) + '\n')
            targets.append({**symbol, 'category': category, 'instructions': len(rows),
                            'atomic_instructions': atomics, 'calls_and_tail_jumps': calls,
                            'assembly': f'target-{index:02}.asm'})
        storage_helper = name.startswith(('<oriole_storage::allocator::Allocator', '<oriole_storage::tracking::AllocationTracker'))
        shared_drop = name.startswith('core::ptr::drop_glue::') and 'oriole_storage::shared::Shared<' in name
        if atomics and (storage_helper or shared_drop):
            helpers_with_atomics.append({**symbol, 'atomic_instructions': atomics})
    report = {'library': str(library), 'library_sha256': sha(library),
              'script_sha256': sha(Path(__file__)), 'verified_instruction_rows': len(instructions),
              'entity_account_symbol_present': any(row['category'] == 'entity_account' for row in targets),
              'expanded_work_symbol_present': any(row['category'] == 'expanded_work' for row in targets),
              'targets': targets, 'storage_helpers_with_atomics': helpers_with_atomics,
              'limitations': ['Static exact-ELF inspection only; no parser, layout target or timing executed.',
                              'Missing or generic-erased symbols require manual mapping of inlined source and call edges.',
                              'No-atomic instructions inside one function does not prove that its callees avoid atomics.',
                              'Remaining storage atomics are separately identified; no total-lock-count performance inference.',
                              'No compiler companion, source-line attribution or symbol-mode identity is assumed.']}
    assert report['library_sha256'] == options.sha256
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'out': str(out), 'targets': len(targets), 'storage_helpers_with_atomics': len(helpers_with_atomics)}))


if __name__ == '__main__':
    main()
