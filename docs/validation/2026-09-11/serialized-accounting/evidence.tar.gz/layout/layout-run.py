"""Compile and execute only size_of/align_of against checked debug rlibs."""
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

root = Path('/tmp/oriole-serialized-accounting-layout')
root.mkdir(exist_ok=False)
source = Path('/tmp/oriole-serialized-accounting-layout.rs')
assert os.sched_getaffinity(0) == {6}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


env = os.environ.copy()
for key in list(env):
    if key.startswith('CARGO_PROFILE_') or key in {'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC', 'LLVM_PROFILE_FILE', 'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST', 'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'}:
        env.pop(key)
overrides = {'CARGO_HOME': '/home/dev-user/.cache/toucan/cargo', 'RUSTC_WRAPPER': '', 'RUSTC_WORKSPACE_WRAPPER': '', 'RUSTUP_AUTO_INSTALL': '0'}
env.update(overrides)
commands = []


def run(label, argv):
    started = time.time()
    with (root / f'{label}.stdout').open('wb') as stdout, (root / f'{label}.stderr').open('wb') as stderr:
        child = subprocess.Popen(argv, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = child.wait(timeout=120)
        except BaseException:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGKILL)
            child.wait()
            raise
    record = {'label': label, 'argv': argv, 'started': started, 'completed': time.time(), 'exit': code,
              'reaped': child.poll() is not None, 'stdout_sha256': sha(root / f'{label}.stdout'), 'stderr_sha256': sha(root / f'{label}.stderr')}
    commands.append(record)
    (root / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert code == 0, label
    return (root / f'{label}.stdout').read_text()


report = {'source': str(source), 'source_sha256': sha(source), 'source_text': source.read_text(),
          'cpu': [6], 'environment_overrides': overrides, 'variants': {},
          'scope': 'Public layouts from checked debug artifacts; no parser creation or parsing. No measurement of private heap EntityBudget layout.'}
report['compiler'] = run('rustc-version', ['rustc', '+ohm', '--version', '--verbose'])
old_layout = Path('/tmp/oriole-retained-c-frame-size/report.json')
old = json.loads(old_layout.read_text())
for label, worktree, check in [
    ('control', Path('/home/dev-user/code/oss/oriole-suffix-element-names'), Path('/tmp/oriole-suffix-element-names-checks/tests-01/report.json')),
    ('candidate', Path('/home/dev-user/code/oss/oriole-serialized-accounting'), Path('/tmp/oriole-serialized-accounting-checks/tests-03/report.json')),
]:
    checked = json.loads(check.read_text())
    assert checked['exit'] == 0 and checked['reaped'] and checked['source_unchanged']
    assert all(sha(worktree / name) == digest for name, digest in checked['source_sha256'].items())
    log = check.parent / 'output.log'
    assert sha(log) == checked['log_sha256']
    matches = re.findall(r'Running unittests src/lib.rs \((/[^\n]+/debug/deps)/oriole-[^)]+\)', log.read_text())
    assert len(set(matches)) == 1
    deps = Path(matches[0])
    cores = list(deps.glob('liboriole-*.rlib'))
    assert len(cores) == 1, cores
    libraries = {'oriole': cores[0], 'oriole_expat': deps / 'liboriole_expat.rlib'}
    hashes = {str(path): sha(path) for path in libraries.values()}
    if label == 'control':
        assert hashes == old['variants']['suffix']['rlib_sha256']
    argv = ['rustc', '+ohm', '--edition=2024', str(source)]
    if label == 'candidate':
        argv += ['--cfg', 'serialized']
    for crate, path in libraries.items():
        argv += ['--extern', f'{crate}={path}']
    argv += ['-L', f'dependency={deps}', '-o', str(root / label)]
    run(f'{label}-compile', argv)
    output = run(f'{label}-sizes', [str(root / label)])
    assert all(sha(Path(path)) == digest for path, digest in hashes.items())
    assert all(sha(worktree / name) == digest for name, digest in checked['source_sha256'].items())
    report['variants'][label] = {'worktree': str(worktree), 'checked_source_files': len(checked['source_sha256']),
                                'check_report': str(check), 'check_report_sha256': sha(check),
                                'check_log_sha256': sha(log), 'source_matches_passed_checks_before_after': True,
                                'rlib_sha256': hashes, 'output': output, 'probe_sha256': sha(root / label)}
report['control_previous_layout_receipt'] = {'path': str(old_layout), 'sha256': sha(old_layout), 'rlibs_unchanged': True}
report['commands'] = commands
report['script_sha256'] = sha(Path(__file__))
(root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({label: value['output'] for label, value in report['variants'].items()}))
