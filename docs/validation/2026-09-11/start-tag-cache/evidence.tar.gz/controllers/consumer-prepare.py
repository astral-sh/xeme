"""Prepare API and CPython consumer controllers after root releases a completed build."""
from pathlib import Path
import argparse
import ast
import difflib
import hashlib
import json
import os
import re

BUILD = Path('/tmp/oriole-start-tag-shapes-pgo-study')
CONTROL = Path('/tmp/oriole-suffix-element-names-pgo-study')
WORK = Path('/home/dev-user/code/oss/oriole-start-tag-shapes')
API = Path('/tmp/oriole-start-tag-shapes-api-gates')
PYTHON = Path('/tmp/oriole-start-tag-shapes-python-study')
PREVIOUS_API = Path('/tmp/oriole-suffix-element-names-api-gates')
PREVIOUS_PYTHON = Path('/tmp/oriole-suffix-element-names-python-study')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
pin = lambda p: {'path': str(p), 'sha256': sha(p)}


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def replace(text, pairs):
    """Apply only declared substitutions and verify their inverse."""
    updated = text
    for before, after in pairs:
        assert before in updated
        updated = updated.replace(before, after)
    restored = updated
    for before, after in reversed(pairs):
        restored = restored.replace(after, before)
    assert restored == text
    ast.parse(updated)
    return updated


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--released-build', action='store_true')
    parser.add_argument('--head', required=True)
    args = parser.parse_args()
    assert __debug__ and args.released_build and re.fullmatch('[0-9a-f]{40}', args.head)
    assert os.sched_getaffinity(0) == {6}
    assert not API.exists() and not PYTHON.exists(), 'Retain first preparations; no overwrite'
    prepared = read(BUILD / 'preparation.json')
    pair, source, control = read(BUILD / 'pair-report.json'), read(BUILD / 'source.json'), read(CONTROL / 'source.json')
    assert prepared['head'] == source['candidate_base_commit'] == args.head
    assert source['base_runtime'] == control['candidate_base_commit']
    assert source['worktree'] == str(WORK)
    assert prepared['source_manifest_sha256'] == pair['source_manifest_sha256'] == sha(BUILD / 'source.json')
    assert prepared['controller_sha256'] == sha(BUILD / 'build_pair.py')
    assert pair['status'] == 'passed' and pair['source_unchanged'] and pair['tools_unchanged'] and pair['scripts_unchanged']
    assert all(row['exit'] == 0 for row in pair['commands'])
    assert len(source['source_sha256']) == len(control['source_sha256']) == 72
    assert set(source['source_sha256']) == set(control['source_sha256'])
    assert all(sha(WORK / name) == digest for name, digest in source['source_sha256'].items())
    delta = {name: {'control': control['source_sha256'][name], 'candidate': digest} for name, digest in source['source_sha256'].items() if digest != control['source_sha256'][name]}
    assert sorted(delta) == prepared['expected_source_delta']
    assert sha(prepared['expected_source_delta_file']) == prepared['expected_source_delta_sha256']
    assert sorted(read(prepared['expected_source_delta_file'])) == sorted(delta)
    manifest_path = Path(pair['pgo_manifest']['path'])
    assert sha(manifest_path) == pair['pgo_manifest']['sha256']
    manifest = read(manifest_path)
    assert manifest['status'] == 'passed' and manifest['compared_parses'] == 288
    use = manifest_path.parent / 'use'
    for name in ['liboriole_expat.so', 'liboriole_expat.a']:
        assert sha(use / name) == pair['pgo_libraries']['use/' + name]
    control_pair = read(CONTROL / 'pair-report.json')
    control_use = Path(control_pair['pgo_manifest']['path']).parent / 'use'
    before = (PREVIOUS_API / 'api_native.py').read_text()
    substitutions = [(str(PREVIOUS_API), str(API)), (control['worktree'], str(WORK)), (str(control_use), str(use)), ('/tmp/oriole-context-text-frame-fixed-thin-pgo-gates/api-native/upstream-api', str(PREVIOUS_API / 'api-native/upstream-api'))]
    after = replace(before, substitutions)
    API.mkdir()
    (API / 'api_native.py').write_text(after)
    (API / 'controller.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True))))
    save(API / 'preparation.json', {'status': 'prepared_not_executed', 'head': args.head, 'source_manifest': pin(BUILD / 'source.json'), 'pair_report': pin(BUILD / 'pair-report.json'), 'controller_sha256': sha(API / 'api_native.py'), 'parent_controller': pin(PREVIOUS_API / 'api_native.py'), 'replacement_pairs': substitutions, 'inverse_text_equal': True, 'scope': 'Same 4740 API configurations, assertions, per-case and aggregate ceilings; selected suffix results are the comparator. Same six C ASan/UBSan consumers, with Rust release library uninstrumented and leak checking disabled. No target executions by preparation.'})

    # Four existing scripts retain workload, order, timing intervals and bounds.
    PYTHON.mkdir()
    for mode in ['normal', 'pgo']:
        old, dest = PREVIOUS_PYTHON / mode, PYTHON / mode
        original = read(old / 'adaptation.json')
        for entry in original['consumer_source']['files'].values():
            assert sha(entry['path']) == entry['sha256']
        for path, digest in original['consumer_source']['interpreter_and_public_headers'].items():
            assert sha(path) == digest
        candidate = BUILD / 'normal/liboriole_expat.so' if mode == 'normal' else use / 'liboriole_expat.so'
        selected = CONTROL / 'normal/liboriole_expat.so' if mode == 'normal' else control_use / 'liboriole_expat.so'
        expected = pair['normal_libraries']['liboriole_expat.so'] if mode == 'normal' else pair['pgo_libraries']['use/liboriole_expat.so']
        assert sha(candidate) == expected and original['libraries']['candidate'] == pin(selected)
        libraries = {'candidate': pin(candidate), 'control': pin(selected), 'expat': original['libraries']['expat']}
        assert all(sha(entry['path']) == entry['sha256'] for entry in libraries.values())
        dest.mkdir()
        changes = {}
        for name, digest in original['files'].items():
            assert sha(old / name) == digest
            text = (old / name).read_text()
            possible = [(control['worktree'] + '/include', str(WORK / 'include')), ('capacity control and packed-name candidate', 'suffix control and start-tag-shapes candidate'), ('capacity control, packed-name candidate', 'suffix control, start-tag-shapes candidate'), ('packed-name ' + mode + ' CPython screen', 'start-tag-shapes ' + mode + ' CPython screen')]
            replacements = [(before, after) for before, after in possible if before in text]
            updated = replace(text, replacements)
            if name == 'python_worker.py':
                assert updated == text
            (dest / name).write_text(updated)
            changes[name] = replacements
        test_modules = [name for name in delta if name.startswith('tests/') or '/tests/' in name or Path(name).name == 'tests.rs']
        record = dict(original)
        record.pop('selected_control_pair_freeze', None)
        record.update(source_runtime_control=control['candidate_base_commit'], source_runtime_candidate=source['candidate_base_commit'], candidate_source_manifest=pin(BUILD / 'source.json'), candidate_pair_report=pin(BUILD / 'pair-report.json'), selected_control_source_manifest=pin(CONTROL / 'source.json'), selected_control_pair_report=pin(CONTROL / 'pair-report.json'), libraries=libraries, header=pin(WORK / 'include/expat.h'), source_delta=delta, runtime_source_delta=[name for name in delta if name not in test_modules], candidate_test_delta=test_modules, inherited_fixture_delta=[name for name in delta if name.startswith('tests/c/')], test_scope='Reviewed runtime files also contain inline cache tests; candidate_test_delta lists separate test-module paths only.', files={name: sha(dest / name) for name in original['files']}, parent_files=original['files'], parent_adaptation=pin(old / 'adaptation.json'), changes=changes, proof='Only header paths and captions change in the controllers. Raw worker and measurement protocol are unchanged. Selected suffix controls and independently trained original-generated candidate PGO use unmodified CPython extensions. Private start-tag cache adds bounded private cache storage, with the same compiler recipes.', execution_status='unexecuted')
        save(dest / 'adaptation.json', record)
    print(json.dumps({'status': 'prepared_only', 'head': args.head, 'source_delta': sorted(delta), 'measurement_order': 'Normal native screen first; root releases subsequent targets only after review.', 'api': str(API), 'python': str(PYTHON), 'targets_executed': False}))


if __name__ == '__main__':
    main()
