# Start-tag cache measurement controllers

Candidate d8c5e503a4a432fb79f9ce5c05f44baf3428e425; selected suffix runtime a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9. The build study is prepared; root owns every compiler, parser and elapsed target.

## Execution order

1. Root completes and reaps `/tmp/oriole-start-tag-shapes-pgo-study/build_pair.py` on CPU 3.
2. After root release, run the saved-only `/tmp/oriole-start-tag-shapes-postbuild-prepare.py --released-build --head d8c5e503a4a432fb79f9ce5c05f44baf3428e425` on CPU 6. It directly validates build records and prepares both native modes and the existing 12 allocation diagnostics.
3. Root runs `/tmp/oriole-start-tag-shapes-native-study/normal/run.py` once. The wrapper uses CPU 5 for preflights and CPU 0 for timing. After it exits and is reaped, run `/tmp/oriole-start-tag-shapes-native-independent-review/audit.py --released --phase normal` on CPU 6.
4. Root reviews the ordinary release native result before expanding the campaign. The PGO native wrapper is prepared but unexecuted. Allocation, API, strict CPython and ordinary/PGO Python targets await separate root release.

The saved-only `/tmp/oriole-start-tag-shapes-consumer-prepare.py --released-build --head d8c5e503a4a432fb79f9ce5c05f44baf3428e425` prepares the API and both Python controllers on CPU 6. The Python wrappers keep separate `prepare` and `time` phases. `/tmp/oriole-start-tag-shapes-strict-cpython.py` is a CPU 3 target controller; its outcome comparison includes all 809 rendered baseline lines. None of these scripts has executed targets during preparation.

## Existing evidence to retain

- `/tmp/oriole-start-tag-shape-checks`: 443 checks/34 groups, formatting, all-target check and Clippy; original check01 failure retained. All 61 Rust source hashes match the committed candidate. Original receipts retain their precommit metadata.
- `/tmp/oriole-start-tag-shape-review`: independent private-token/cache-budget/value/namespace/ownership review.
- `/tmp/oriole-start-tag-shape-layout/report.json`, probe source, controller and raw logs: checked debug Parser 2456 versus 2408 bytes, C handle 3208 versus 3160 bytes (+48 each), AdapterFrame 256 unchanged. Private ShapeCache heap layout, allocator overhead and peak memory were not measured by the layout probe.
- Build source72 differs in four Rust files plus the inherited integration.c regression from PR142. Pipeline source69 differs only in four Rust files. All original six PGO tools, 288-record generated training, normal/PGO compiler settings and selected allocator remain unchanged.

No binary, source or elapsed result is inferred from these prepared controllers. Raw results and every adverse condition remain part of the eventual report.
