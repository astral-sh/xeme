"""Assemble the rejected start-tag cache's saved records; execute no targets."""
from pathlib import Path
import argparse
import csv
import gzip
import hashlib
import io
import json
import os
import tarfile

cli = argparse.ArgumentParser(description=__doc__)
cli.add_argument('--output', type=Path, required=True)
args = cli.parse_args()
assert __debug__ and os.sched_getaffinity(0) == {6}
O = args.output
assert not O.exists()
W = Path('/home/dev-user/code/oss/oriole-start-tag-shapes')
B = Path('/tmp/oriole-start-tag-shapes-pgo-study')
N = Path('/tmp/oriole-start-tag-shapes-native-study')
V = Path('/tmp/oriole-start-tag-shapes-native-independent-review')
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
review = read(V / 'normal-review.json')
assert review['status'] == 'passed'
assert review['totals'] == {'conditions': 28, 'preflight_workers': 84, 'timed_workers': 588, 'all_workers': 672, 'all_samples': 106176}
source = read(B / 'source.json')
assert source['candidate_base_commit'] == 'd8c5e503a4a432fb79f9ce5c05f44baf3428e425'
assert all(sha((W / name).read_bytes()) == digest for name, digest in source['source_sha256'].items())
assert not (N / 'pgo/controller.json').exists()
assert not (N / 'pgo/native-screen').exists()
assert not Path('/tmp/oriole-start-tag-shapes-allocation-probe/runs').exists()
for name in ['api-gates', 'python-study', 'strict-cpython']:
    assert not Path('/tmp/oriole-start-tag-shapes-' + name).exists()
files = {}
members = []
excluded = []


def add(path, name):
    path = Path(path)
    assert name not in files
    if path.is_symlink():
        excluded.append({'path': str(path), 'reason': 'symlink'})
        return
    content = path.read_bytes()
    if content.startswith((b'\x7fELF', b'!<arch>')) or path.suffix in {'.a', '.profraw', '.profdata', '.pyc'}:
        excluded.append({'path': str(path), 'size': len(content), 'sha256': sha(content), 'reason': 'binary'})
        return
    files[name] = content
    members.append({'member': name, 'original_path': str(path), 'size': len(content), 'sha256': sha(content)})


def tree(path, prefix, allowed=None):
    path = Path(path)
    for child in sorted(path.rglob('*')):
        if child.is_file() and '__pycache__' not in child.parts and (allowed is None or child.suffix in allowed):
            add(child, prefix + str(child.relative_to(path)))


for label, build in [('candidate', B), ('selected', Path('/tmp/oriole-suffix-element-names-pgo-study'))]:
    for name in ['source.json', 'pair-report.json', 'build_pair.py', 'source-checks.json', 'tool-source.json', 'source.patch', 'normal-build.log', 'normal-training.json', 'pgo-pipeline.log']:
        add(build / name, 'build/' + label + '/' + name)
    if label == 'candidate':
        for name in ['preparation.json', 'build-readback.json', 'controller.patch']:
            add(build / name, 'build/' + label + '/' + name)
        tree(build / 'local-checks', 'checks/')
    tree(build / 'pipeline', 'build/' + label + '/pipeline/')
    pair = read(build / 'pair-report.json')
    run = Path(pair['pgo_manifest']['path']).parent
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log'}:
            add(path, 'build/' + label + '/pgo/' + path.name)
    tree(run / 'inputs', 'build/' + label + '/pgo/inputs/')
    manifest = read(build / 'source.json')
    for name, digest in manifest['source_sha256'].items():
        path = Path(manifest['worktree']) / name
        assert sha(path.read_bytes()) == digest
        add(path, 'source/' + label + '/' + name)
tree(N / 'normal', 'native/normal/')
tree(V, 'native/review/')
tree('/tmp/oriole-start-tag-shape-review', 'source/review/')
tree('/tmp/oriole-start-tag-shape-layout', 'layout/')
tree('/tmp/oriole-start-tag-shape-diagnostic', 'diagnostic/')
tree(N / 'pgo', 'prepared-unexecuted/native-pgo/')
tree('/tmp/oriole-start-tag-shapes-allocation-probe', 'prepared-unexecuted/allocation/')
for name in ['prepare.py', 'build-bindings.py', 'postbuild-prepare.py', 'consumer-prepare.py', 'strict-cpython.py', 'reviewed-delta.json', 'measurement-preparation.md']:
    add('/tmp/oriole-start-tag-shapes-' + name, 'controllers/' + name)
add(__file__, 'controllers/package.py')
protocol = read(N / 'normal/native-screen/protocol.json')
for original, digest in protocol['hashes'].items():
    path = Path(original)
    assert sha(path.read_bytes()) == digest
    if path.suffix in {'.xml', '.svg', '.ui', '.xsl'}:
        add(path, 'native/inputs/' + path.parent.name + '/' + path.name)
add('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json', 'native/inputs/corpus-manifest.json')
corpus = Path('/home/dev-user/code/oss/oriole/benchmarks/projects')
for project in read(corpus / 'corpus-manifest.json')['projects']:
    for item in project['files']:
        if item['role'] in {'license', 'notice'}:
            path = corpus / item['path']
            assert sha(path.read_bytes()) == item['sha256']
            add(path, 'notices/projects/' + project['name'] + '/' + path.name)
for name in ['LICENSE-MIT', 'LICENSE-APACHE', 'tests/c/UPSTREAM-NOTICES.txt']:
    add(W / name, 'notices/oriole/' + Path(name).name)
add('/home/dev-user/.cache/oriole/upstream/expat-2.8.4/COPYING', 'notices/expat/COPYING')
O.mkdir()
with (O / 'evidence.tar.gz').open('xb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as archive:
            for name, content in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(content)
                archive.addfile(info, io.BytesIO(content))
index = {'schema': 'saved-record-bundle-v1', 'scope': 'Rejected private start-tag cache: raw records and source snapshots. Original paths identify saved machine evidence; no targets are executed by this bundle.', 'archive': 'evidence.tar.gz', 'archive_sha256': sha((O / 'evidence.tar.gz').read_bytes()), 'members': sorted(members, key=lambda row: row['member']), 'excluded': excluded}
(O / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
(O / 'conditions.csv').write_bytes((V / 'normal-conditions.csv').read_bytes())
native = review['native']['normal']
rows = list(csv.DictReader(io.StringIO((O / 'conditions.csv').read_text())))
assert len(rows) == 28
layout = read('/tmp/oriole-start-tag-shape-layout/report.json')
report = {'decision': 'rejected', 'source_commit': source['candidate_base_commit'], 'selected_control_runtime': source['base_runtime'], 'reason': 'Ordinary release native time regresses by 1.16% across real projects, with 17 of 24 conditions adverse, while both parser and C handle grow by 48 bytes and a new private heap cache is introduced.', 'native_normal': native, 'worker_totals': review['totals'], 'source_delta': read(B / 'preparation.json')['expected_source_delta'], 'checks': {'passed': 443, 'groups': 34, 'formatting_check_and_clippy_passed': True, 'first_E0502_attempt_retained': True, 'all_61_Rust_sources_match_final_commit': True}, 'builds': {'normal_generated_records': 288, 'instrumented_generated_records': 288, 'pgo_generated_records': 288, 'compiler_vectors': 9, 'library_artifacts': 6, 'normal_library_sha256': read(B / 'pair-report.json')['normal_libraries']['liboriole_expat.so'], 'pgo_library_sha256': read(B / 'pair-report.json')['pgo_libraries']['use/liboriole_expat.so']}, 'layout': {'control': layout['variants']['control']['output'], 'candidate': layout['variants']['candidate']['output'], 'handle_and_core_delta_bytes': 48, 'private_heap_RSS_or_peak_memory_measured': False}, 'executed': ['local Rust formatting/check/test/Clippy', 'normal and original-generated PGO builds and 864 generated training/replay records', 'debug size_of/align_of probes', 'pre-prototype Expat-only locality census', 'normal native preflights and elapsed screen', 'independent saved-record audits'], 'prepared_unexecuted': ['PGO native preflights and elapsed screen', 'allocation diagnostics', 'upstream API and C sanitizer consumers', 'normal and PGO CPython preparation/preflights/elapsed screens', 'strict CPython consumers'], 'evidence': {'native_review': {'member': 'native/review/normal-review.json', 'sha256': sha(files['native/review/normal-review.json'])}, 'build_readback': {'member': 'build/candidate/build-readback.json', 'sha256': sha(files['build/candidate/build-readback.json'])}, 'layout': {'member': 'layout/report.json', 'sha256': sha(files['layout/report.json'])}, 'diagnostic': {'member': 'diagnostic/run01/report.json', 'sha256': sha(files['diagnostic/run01/report.json'])}, 'archive_sha256': index['archive_sha256'], 'archive_members': len(members)}, 'scope': 'Documentation-only rejected experiment. The Expat-only census is a lexical opportunity model, not candidate hit-rate, memory or speed measurement. No runtime adoption or compatibility improvement is claimed.'}
(O / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
# Read back the completed archive once; this is packaging validation, not a new reader framework.
with tarfile.open(O / 'evidence.tar.gz', 'r:gz') as archive:
    stored = archive.getmembers()
    assert len(stored) == len(members) and len({entry.name for entry in stored}) == len(stored)
    for entry in stored:
        assert entry.isfile() and not entry.name.startswith('/') and '..' not in Path(entry.name).parts
        assert archive.extractfile(entry).read() == files[entry.name]
print(json.dumps({'status': 'assembled_and_read_back', 'output': str(O), 'members': len(members), 'archive_bytes': (O / 'evidence.tar.gz').stat().st_size, 'archive_sha256': index['archive_sha256'], 'decision': report['decision'], 'targets_executed': False}))
