"""Bind the reviewed start-tag cache source to the existing normal/PGO build recipe."""
from pathlib import Path
import argparse
import ast
import difflib
import hashlib
import json
import re
import shutil
import subprocess

OUTPUT = Path('/tmp/oriole-start-tag-shapes-pgo-study')
WORKTREE = Path('/home/dev-user/code/oss/oriole-start-tag-shapes')
CONTROL = Path('/tmp/oriole-suffix-element-names-pgo-study')
CHECKS = Path('/tmp/oriole-start-tag-shape-checks')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--head', required=True)
    parser.add_argument('--expected-source-delta', type=Path, required=True)
    args = parser.parse_args()
    assert __debug__ and re.fullmatch('[0-9a-f]{40}', args.head)
    args.expected_source_delta = args.expected_source_delta.resolve()
    delta = sorted(read(args.expected_source_delta))
    expected = ['crates/oriole/src/lib.rs', 'crates/oriole/src/recycling.rs', 'crates/oriole/src/tag.rs', 'crates/oriole/tests/adapter_frame.rs', 'tests/c/integration.c']
    assert delta == expected
    assert subprocess.check_output(['git', '-C', str(WORKTREE), 'rev-parse', 'HEAD'], text=True).strip() == args.head
    assert not subprocess.check_output(['git', '-C', str(WORKTREE), 'status', '--porcelain'])
    control = read(CONTROL / 'source.json')
    source = {name: sha(WORKTREE / name) for name in control['source_sha256']}
    assert len(source) == 72
    assert sorted(name for name in source if source[name] != control['source_sha256'][name]) == delta
    assert all(hashlib.sha256(subprocess.check_output(['git', '-C', str(WORKTREE), 'show', args.head + ':' + name])).hexdigest() == digest for name, digest in source.items())
    # The inherited integration fixture was independently validated in PR142.
    assert source['tests/c/integration.c'] == '1e77767b31d4aa2c4bf16321dc545f0faa6ce6e401d5080f96993bbca978d399'
    summary = read(CHECKS / 'summary.json')
    assert summary['status'] == 'passed' and summary['exit_code'] == 0 and summary['reaped']
    assert summary['tests_passed_including_doctests'] == 443 and summary['test_groups'] == 34
    assert summary['runtime_files_match_all_passed_checks']
    assert all(source[name] == digest for name, digest in summary['files'].items())
    check_labels = ['tests01', 'clippy01', 'fmt02', 'check02']
    rust_files = {name for name in source if name.startswith('crates/') and name.endswith('.rs')}
    commands = []
    for label in check_labels:
        row = read(CHECKS / (label + '.json'))
        assert row['exit_code'] == 0 and row['cwd'] == str(WORKTREE)
        assert row['source_before'] == row['source_after']
        assert set(row['source_after']) == rust_files
        assert all(source[name] == digest for name, digest in row['source_after'].items())
        assert sha(CHECKS / (label + '.log')) == row['log_sha256'] == summary['checks'][label]['log_sha256']
        assert row['command'] == summary['checks'][label]['command']
        commands.append(row | {'label': label, 'argv': row['command'], 'exit': row['exit_code'], 'reaped': summary['reaped'], 'reaped_receipt': 'original/summary.json', 'original_receipt_sha256': sha(CHECKS / (label + '.json')), 'source_unchanged': True, 'source_sha256': row['source_after']})
    groups = [tuple(map(int, values)) for values in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (CHECKS / 'tests01.log').read_text())]
    assert len(groups) == 34 and sum(row[0] for row in groups) == 443 and all(row[1:] == (0, 0) for row in groups)
    scripts = read(CONTROL / 'tool-source.json')
    assert len(scripts) == 6 and all(sha(CONTROL / 'pipeline' / name) == digest for name, digest in scripts.items())
    before = (CONTROL / 'build_pair.py').read_text()
    assert sha(CONTROL / 'build_pair.py') == 'fcb0812c00c2a629389d427b603a90a5e130df366d9e3d17dd96df04c30fc8cd'
    after = before.replace('suffix-element-names', 'start-tag-shapes').replace('/tmp/oriole-arena-capacity-bound-pgo-study', str(CONTROL)).replace("checks['test_count']==438", "checks['test_count']==443")
    after = after.replace('Suffix-sharing element-name candidate versus selected capacity runtime de859. Source72 and pipeline69 differ in lib.rs and the custom-name regression in multibyte.rs; C fixtures, selected allocator and callback interface are unchanged.', 'Bounded private start-tag structure cache versus selected suffix runtime a0acaf1. Source72 differs in four Rust files plus the inherited integration.c regression; pipeline69 differs only in those four Rust files. Selected allocator, callback interface, original generated training and compiler recipe are unchanged. No measured benefit is assumed.')
    after = after.replace('versus frozen selected capacity controls.', 'versus selected suffix-sharing controls.')
    assert before[before.index('def save()'):] == after[after.index('def save()'):]
    ast.parse(after)
    assert not OUTPUT.exists(), 'Keep every first preparation and execution attempt'
    OUTPUT.mkdir()
    save(OUTPUT / 'source.json', {'status': 'recorded_source', 'base_runtime': control['candidate_base_commit'], 'candidate_base_commit': args.head, 'worktree': str(WORKTREE), 'source_sha256': source, 'source_count': len(source), 'scope': 'Private eight-entry start-tag structure cache with bounded key/probe/retained storage. Source delta includes the inherited integration fixture; source-matching precommit checks retain their original receipts.'})
    (OUTPUT / 'source.patch').write_bytes(subprocess.check_output(['git', '-C', str(WORKTREE), 'diff', control['candidate_base_commit'], args.head, '--', *delta]))
    (OUTPUT / 'local-checks').mkdir()
    shutil.copytree(CHECKS, OUTPUT / 'local-checks/original')
    save(OUTPUT / 'local-checks/final-checks.json', {'status': 'passed', 'commands': commands, 'original_summary_sha256': sha(CHECKS / 'summary.json')})
    for row in commands:
        dest = OUTPUT / 'local-checks' / row['label']
        dest.mkdir()
        shutil.copyfile(CHECKS / (row['label'] + '.json'), dest / 'report.json')
        shutil.copyfile(CHECKS / (row['label'] + '.log'), dest / 'output.log')
    save(OUTPUT / 'source-checks.json', {'status': 'passed', 'test_count': 443, 'test_groups': 34, 'failed': 0, 'ignored': 0, 'commands': commands, 'source_manifest_sha256': sha(OUTPUT / 'source.json'), 'check_report_sha256': sha(OUTPUT / 'local-checks/final-checks.json'), 'scope': 'Original check receipts retain precommit metadata; all 61 Rust bytes match the confirmed commit. Reaping is recorded by the author summary.'})
    for name in scripts:
        dest = OUTPUT / 'pipeline' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(CONTROL / 'pipeline' / name, dest)
    shutil.copyfile(CONTROL / 'tool-source.json', OUTPUT / 'tool-source.json')
    (OUTPUT / 'build_pair.py').write_text(after)
    (OUTPUT / 'controller.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True))))
    save(OUTPUT / 'preparation.json', {'status': 'prepared_not_executed', 'head': args.head, 'check_labels': check_labels, 'expected_source_delta': delta, 'expected_pipeline_delta': [name for name in delta if name.startswith('crates/')], 'expected_source_delta_file': str(args.expected_source_delta), 'expected_source_delta_sha256': sha(args.expected_source_delta), 'expected_test_count': 443, 'test_groups': 34, 'control_head': control['candidate_base_commit'], 'preparer_sha256': sha(__file__), 'source_manifest_sha256': sha(OUTPUT / 'source.json'), 'controller_sha256': sha(OUTPUT / 'build_pair.py'), 'controller_body_byte_identical': True, 'targets_executed': False, 'measurement_order': 'Normal native screen first; root reviews before any expanded timing campaign.'})
    print((OUTPUT / 'preparation.json').read_text())


if __name__ == '__main__':
    main()
