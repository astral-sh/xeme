# Start-tag shape locality diagnostic

The script uses the existing pinned CPython Expat consumer loader, then checks
the raw opening tags against Expat callbacks at their original byte indices.
It models 1/4/8-entry LRU caches with a 512-byte key limit per entry. Logical
element/ordered-attribute shapes and exact non-value byte skeletons are separate.

The report includes both namespace modes, native literal eligibility, the
existing identity-frame subset, and byte coverage. Hits are opportunities to
test, not predicted time savings. Namespace lookup/expanded duplicates, value
validation, accounting, and error/callback ordering remain required.

Source and consumer files are pinned in `pins.json`; the six original XML hashes
come from the selected suffix worktree's unchanged corpus manifest. No runtime
source is modified and no Oriole parser is loaded. Use the pinned CPython 3.12.13
executable with `-I -S`, CPU3, and a fresh `--output` directory.
