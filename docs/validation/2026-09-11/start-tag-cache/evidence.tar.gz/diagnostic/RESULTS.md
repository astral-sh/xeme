# Start-tag shape locality results

**First run passed.** All six pinned documents matched the checked Expat CPython consumer at 4 KiB and 64 KiB feeds, with namespaces off/on. No Oriole runtime or compiler executed.

## Exact skeleton cache

Each key retains the exact bytes outside attribute values, including names, whitespace, quotes and closing punctuation. Fully associative LRU starts empty per document; ineligible tags do not evict. Each key is at most 512 bytes (descriptor metadata additional). The table uses native-root/literal/no-DTD/4 KiB-token/128-attribute eligibility; it does not simulate scanner spare capacity or split-token admission.

| Project | Eligible starts | Last 1 hit rate | 4 entries | 8 entries | 8-entry hit name+grammar bytes / input |
|---|---:|---:|---:|---:|---:|
| vulkan | 53,070 | 14.24% | 72.47% | 92.62% | 22.90% |
| wayland | 764 | 30.76% | 68.06% | 81.02% | 12.32% |
| maven | 917 | 2.94% | 49.40% | 63.47% | 12.30% |
| batik | 0 | — | — | — | 0.00% |
| gtk | 311 | 24.76% | 57.56% | 84.89% | 17.36% |
| docbook | 235 | 27.23% | 47.66% | 62.98% | 18.43% |

The logical element-plus-ordered-attribute-name cache is almost identical on Vulkan, Maven and GTK. At 8 entries it is 84.69% versus 81.02% exact-skeleton hits on Wayland, and 68.51% versus 62.98% on DocBook. Batik has a DOCTYPE and remains excluded.

## Namespace and semantic boundaries

The lexical hit counts above are the same in both namespace modes. Current identity-frame eligibility remains unchanged for Vulkan, Wayland and GTK, but excludes every Maven and DocBook start under namespace mode. A useful lexical cache must therefore sit before namespace expansion; broadening frames is not implied. Bindings, expanded-attribute duplicates and URI charges cannot be cached from raw shape equality.

Only exact privately validated ordered names establish raw-name uniqueness. Reusing that proof must retain duplicate-before-value/error precedence, configured NameRules, reset/child separation, resumable-feed complexity and all current fallback/limit rules. Values remain scanned and validated on every hit. Cache probes and copies still touch the purportedly covered name/grammar bytes.

## Interpretation

Eight entries expose substantially more reuse than last-one: Vulkan 49,153/53,070 eligible starts versus 7,557. The original Vulkan opening-token bytes are 28.94% names, 54.55% values and 16.51% punctuation/whitespace. This justifies designing a bounded prototype; it does not establish an instruction or elapsed gain. The byte-coverage column must not be presented as predicted savings.

No runtime implementation is selected. Report details include immediately adjacent starts, both key definitions, both namespace modes, upper-bound rows, input/consumer/source hashes and explicit limitations.

Files: `diagnose.py`, `pins.json`, `run01/report.json`, `run01.log`, `execution.json`.
