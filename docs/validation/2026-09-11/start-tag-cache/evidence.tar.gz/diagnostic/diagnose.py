"""Count bounded start-tag shape reuse in the unchanged six-project corpus.

Diagnostic only: the pinned Expat consumer supplies valid token boundaries and
ordered attributes. A small raw lexer splits only those already accepted tags.
It is checked against Expat in both namespace modes and two feed sizes. No
Oriole library is loaded and no elapsed/performance claim is produced.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SPACE = b" \t\r\n"
NAME = re.compile(rb"[^ \t\r\n/=<>\"']+")
MAX_TOKEN = 4096
MAX_ATTRIBUTES = 128
MAX_KEY_BYTES = 512


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def checked_files(pins):
    actual = {path: digest(path) for path in pins}
    assert actual == pins, "pinned source/consumer changed"
    return actual


def raw_start(data, start):
    """Split an Expat-accepted opening token; do not implement XML validity."""
    assert data[start : start + 1] == b"<"
    index = start + 1
    match = NAME.match(data, index)
    assert match is not None
    element = match.group()
    index = match.end()
    attrs, values, segments = [], [], []
    segment_start = start
    while True:
        prior = index
        while data[index] in SPACE:
            index += 1
        if data[index : index + 2] == b"/>":
            index += 2
            break
        if data[index : index + 1] == b">":
            index += 1
            break
        assert index > prior, "attributes require separating whitespace"
        match = NAME.match(data, index)
        assert match is not None
        attrs.append(match.group())
        index = match.end()
        while data[index] in SPACE:
            index += 1
        assert data[index] == ord("=")
        index += 1
        while data[index] in SPACE:
            index += 1
        quote = data[index]
        assert quote in (ord("'"), ord('"'))
        index += 1
        value_end = data.find(bytes([quote]), index)
        assert value_end >= index
        segments.append(data[segment_start:index])
        values.append(data[index:value_end])
        segment_start = value_end
        index = value_end + 1
    segments.append(data[segment_start:index])
    names = (element, *attrs)
    token_bytes = index - start
    name_bytes = sum(map(len, names))
    value_bytes = sum(map(len, values))
    grammar_bytes = token_bytes - name_bytes - value_bytes
    assert name_bytes + value_bytes + grammar_bytes == token_bytes
    assert sum(map(len, segments)) == name_bytes + grammar_bytes
    return {
        "start": start,
        "end": index,
        "names": names,
        "values": tuple(values),
        "segments": tuple(segments),
        "token_bytes": token_bytes,
        "name_bytes": name_bytes,
        "value_bytes": value_bytes,
        "grammar_bytes": grammar_bytes,
        "literal": all(not any(byte in value for byte in (b"&", b"\t", b"\r", b"\n")) for value in values),
    }


def expanded(raw, bindings, attribute=False):
    name = raw.decode("utf-8")
    if ":" in name:
        prefix, local = name.split(":", 1)
        return bindings[prefix] + "|" + local
    uri = None if attribute else bindings.get("")
    return uri + "|" + name if uri else name


def collect(expat, data, namespaces, chunk, reference=None):
    """Cross-check raw names/order and literal values against the pinned parser."""
    parser = expat.ParserCreate(namespace_separator="|" if namespaces else None)
    parser.ordered_attributes = True
    parser.specified_attributes = True
    parser.SetParamEntityParsing(expat.XML_PARAM_ENTITY_PARSING_NEVER)
    bindings = {"xml": "http://www.w3.org/XML/1998/namespace"}
    undo = {}
    rows, doctype = [], []

    def start_namespace(prefix, uri):
        prefix = prefix or ""
        undo.setdefault(prefix, []).append(bindings.get(prefix))
        if uri:
            bindings[prefix] = uri
        else:
            bindings.pop(prefix, None)

    def end_namespace(prefix):
        prefix = prefix or ""
        previous = undo[prefix].pop()
        if previous is None:
            bindings.pop(prefix, None)
        else:
            bindings[prefix] = previous

    def start(name, attrs):
        row = raw_start(data, parser.CurrentByteIndex)
        pairs = list(zip(attrs[::2], attrs[1::2], strict=True))
        raw_names = row["names"]
        if namespaces:
            assert reference is not None
            original = reference[len(rows)]
            assert row == {key: value for key, value in original.items() if key != "namespace_identity"}
            assert name == expanded(raw_names[0], bindings)
            relevant = [(key, value) for key, value in zip(raw_names[1:], row["values"], strict=True)
                        if key != b"xmlns" and not key.startswith(b"xmlns:")]
            assert [name for name, _ in pairs] == [expanded(key, bindings, True) for key, _ in relevant]
            if row["literal"] and not doctype:
                assert [value for _, value in pairs] == [value.decode("utf-8") for _, value in relevant]
            row["namespace_identity"] = (
                b":" not in raw_names[0] and not bindings.get("")
                and all(key != b"xmlns" and b":" not in key for key in raw_names[1:])
            )
        else:
            assert name == raw_names[0].decode("utf-8")
            assert [key for key, _ in pairs] == [key.decode("utf-8") for key in raw_names[1:]]
            assert len(set(raw_names[1:])) == len(raw_names) - 1
            if row["literal"] and not doctype:
                assert [value for _, value in pairs] == [value.decode("utf-8") for value in row["values"]]
        rows.append(row)

    parser.StartElementHandler = start
    parser.StartDoctypeDeclHandler = lambda *args: doctype.append(args)
    if namespaces:
        parser.StartNamespaceDeclHandler = start_namespace
        parser.EndNamespaceDeclHandler = end_namespace
    for offset in range(0, len(data), chunk):
        parser.Parse(data[offset : offset + chunk], offset + chunk >= len(data))
    return rows, bool(doctype)


def counters(rows):
    return {key: sum(row[key] for row in rows)
            for key in ("token_bytes", "name_bytes", "value_bytes", "grammar_bytes")}


def model(rows, accepted, key_kind, slots, input_bytes):
    """Fully associative LRU, empty per document; ignored tags leave it intact."""
    cache, hits, eligible = [], [], []
    key_field = "names" if key_kind == "element_ordered_attributes" else "segments"
    key_rejected = 0
    for row, allowed in zip(rows, accepted, strict=True):
        if not allowed:
            continue
        key = row[key_field]
        if sum(map(len, key)) > MAX_KEY_BYTES:
            key_rejected += 1
            continue
        eligible.append(row)
        if key in cache:
            hits.append(row)
            cache.remove(key)
        cache.insert(0, key)
        del cache[slots:]
    hit_bytes = counters(hits)
    return {
        "slots": slots,
        "hits": len(hits),
        "eligible": len(eligible),
        "key_bytes_rejected": key_rejected,
        "hit_fraction_eligible": len(hits) / len(eligible) if eligible else None,
        "hit_fraction_all_starts": len(hits) / len(rows) if rows else None,
        "hit_bytes": hit_bytes,
        "hit_name_fraction_input_bytes": hit_bytes["name_bytes"] / input_bytes,
        "hit_grammar_fraction_input_bytes": hit_bytes["grammar_bytes"] / input_bytes,
        "hit_name_and_grammar_fraction_input_bytes": (hit_bytes["name_bytes"] + hit_bytes["grammar_bytes"]) / input_bytes,
    }


def summarize(rows, doctype, input_bytes):
    policies = {
        "all_lexical_upper_bound": [True] * len(rows),
        "native_literal_bounded": [not doctype and row["literal"] and row["token_bytes"] <= MAX_TOKEN
                                   and len(row["names"]) - 1 <= MAX_ATTRIBUTES for row in rows],
    }
    policies["native_literal_identity_frame"] = [allowed and row["namespace_identity"]
                                                for allowed, row in zip(policies["native_literal_bounded"], rows, strict=True)]
    totals = counters(rows)
    return {
        "starts": len(rows),
        "doctype_excludes_native_fast_path": doctype,
        "bytes": totals,
        "fractions_of_start_tag_bytes": {key: value / totals["token_bytes"] for key, value in totals.items()},
        "unique_name_shapes": len({row["names"] for row in rows}),
        "unique_exact_skeletons": len({row["segments"] for row in rows}),
        "immediately_adjacent_start_hits": {
            kind: sum(left[field] == right[field] for left, right in zip(rows, rows[1:]))
            for kind, field in (("element_ordered_attributes", "names"), ("exact_literal_skeleton", "segments"))
        },
        "policies": {
            policy: {
                "accepted_starts_before_key_bound": sum(accepted),
                "accepted_bytes_before_key_bound": counters([row for row, allowed in zip(rows, accepted, strict=True) if allowed]),
                "models": {kind: [model(rows, accepted, kind, slots, input_bytes) for slots in (1, 4, 8)]
                           for kind in ("element_ordered_attributes", "exact_literal_skeleton")},
            }
            for policy, accepted in policies.items()
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists(), "use a fresh output directory"
    args.output.mkdir()
    pins = json.loads((ROOT / "pins.json").read_text())
    before = checked_files(pins["files"])
    assert Path(sys.executable).resolve() == Path("/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12").resolve()
    helper = Path(pins["source"]) / "benchmarks/python_projects.py"
    spec = importlib.util.spec_from_file_location("pinned_consumers", helper)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    identity = module.load_consumers(Path(pins["consumer"]))
    import pyexpat
    assert identity["parser_library"]["sha256"] == pins["files"][identity["parser_library"]["path"]]
    manifest_path = Path(pins["source"]) / "benchmarks/projects/corpus-manifest.json"
    manifest = json.loads(manifest_path.read_text())
    results, input_pins = {}, {}
    for project in manifest["projects"]:
        entries = [entry for entry in project["files"] if entry["role"] == "input"]
        assert len(entries) == 1
        entry = entries[0]
        path = manifest_path.parent / entry["path"]
        data = path.read_bytes()
        assert len(data) == entry["bytes"] and digest(path) == entry["sha256"]
        input_pins[str(path)] = entry["sha256"]
        data.decode("utf-8")
        plain, doctype = collect(pyexpat, data, False, 4096)
        namespaced, ns_doctype = collect(pyexpat, data, True, 4096, plain)
        assert doctype == ns_doctype and len(plain) == len(namespaced)
        assert collect(pyexpat, data, False, 65536) == (plain, doctype)
        assert collect(pyexpat, data, True, 65536, plain) == (namespaced, doctype)
        for row in plain:
            row["namespace_identity"] = True
        results[project["name"]] = {
            "path": str(path), "input_bytes": len(data), "sha256": entry["sha256"],
            "namespace_0": summarize(plain, doctype, len(data)),
            "namespace_1": summarize(namespaced, doctype, len(data)),
        }
        print(project["name"], len(plain), "start tags checked", flush=True)
    assert checked_files(pins["files"]) == before
    checked_files(input_pins)
    report = {
        "status": "passed", "script_sha256": digest(__file__), "pins_sha256": digest(ROOT / "pins.json"),
        "argv": sys.argv, "python": sys.version, "affinity": sorted(os.sched_getaffinity(0)),
        "consumer": identity, "source_and_consumer_pins": before, "inputs": input_pins,
        "configuration": {"token_bytes_max": MAX_TOKEN, "attributes_max": MAX_ATTRIBUTES,
                          "key_bytes_max": MAX_KEY_BYTES, "slots": [1, 4, 8], "chunks_checked": [4096, 65536]},
        "scope": "Corpus locality diagnostic. Expat validates whole documents; raw lexer matches its byte-indexed names and ordered explicit attributes in both namespace modes/two feeds. Literal values are checked for no-DTD documents; DTDs can normalize tokenized values. No Oriole execution or timing.",
        "limitations": [
            "Last1 means last cache-admitted eligible start, not necessarily the immediately preceding XML start; rejected tags do not evict entries.",
            "Logical name shapes ignore whitespace, quote style, empty-tag syntax and values; exact skeletons retain all bytes outside value interiors, including quotes and whitespace.",
            "LRU key lookup is conceptual: reported hits exclude lookup/copy/insertion costs and are not predicted instruction or elapsed savings. Entry byte bound excludes descriptor metadata.",
            "Input-byte shares measure corpus coverage, not instruction shares. Name/grammar bytes still require identity comparison and value-boundary discovery.",
            "Native literal eligibility approximates selected guards; it does not simulate scanner spare capacity, feed-boundary progress, reparse deferral, decoder setup or actual cache admission/eviction.",
            "Namespace1 identity is the existing frame guard. Broader lexical hits cannot cache namespace bindings, expanded names/duplicates or expansion charges. Same raw shape can resolve differently after rebinding.",
            "Raw duplicate checks can be skipped only for a privately proven exact ordered-name match. Expanded-attribute duplicate errors and duplicate-before-value/error ordering remain authoritative.",
            "No cache may trust returned/recycled public strings. Parser reset, children, NameRules editions, incomplete feeds, adversarial misses and selected-allocation failures need separate implementation tests.",
            "DTD documents remain excluded from native fast-path rows; all-lexical rows are an upper bound, not proposed eligibility. External DTDs are not loaded.",
        ],
        "projects": results,
    }
    (args.output / "report.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
