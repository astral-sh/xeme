// Evaluate layouts only; construct no parser and call no parsing entry point.
fn main() {
    println!(
        "XML_ParserStruct {} {}",
        size_of::<oriole_expat::XML_ParserStruct>(),
        align_of::<oriole_expat::XML_ParserStruct>()
    );
    println!(
        "Parser {} {}",
        size_of::<oriole::Parser>(),
        align_of::<oriole::Parser>()
    );
    #[cfg(serialized)]
    println!(
        "CParser {} {}",
        size_of::<oriole::CParser>(),
        align_of::<oriole::CParser>()
    );
    println!(
        "AdapterFrame {} {}",
        size_of::<oriole::AdapterFrame>(),
        align_of::<oriole::AdapterFrame>()
    );
}
