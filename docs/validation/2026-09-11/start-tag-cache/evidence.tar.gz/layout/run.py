"""Compile and execute only size_of/align_of against checked debug rlibs."""
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

root = Path('/tmp/oriole-start-tag-shape-layout')
source = root / 'layout.rs'
assert os.sched_getaffinity(0) == {6}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


env = os.environ.copy()
for key in list(env):
    if key.startswith('CARGO_PROFILE_') or key in {'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC', 'LLVM_PROFILE_FILE', 'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST', 'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'}:
        env.pop(key)
overrides = {'CARGO_HOME': '/home/dev-user/.cache/toucan/cargo', 'RUSTC_WRAPPER': '', 'RUSTC_WORKSPACE_WRAPPER': '', 'RUSTUP_AUTO_INSTALL': '0'}
env.update(overrides)
commands = []


def run(label, argv):
    started = time.time()
    with (root / f'{label}.stdout').open('wb') as stdout, (root / f'{label}.stderr').open('wb') as stderr:
        child = subprocess.Popen(argv, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = child.wait(timeout=120)
        except BaseException:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGKILL)
            child.wait()
            raise
    record = {'label': label, 'argv': argv, 'started': started, 'completed': time.time(), 'exit': code,
              'reaped': child.poll() is not None, 'stdout_sha256': sha(root / f'{label}.stdout'), 'stderr_sha256': sha(root / f'{label}.stderr')}
    commands.append(record)
    (root / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert code == 0, label
    return (root / f'{label}.stdout').read_text()


report = {'source': str(source), 'source_sha256': sha(source), 'source_text': source.read_text(),
          'cpu': [6], 'environment_overrides': overrides, 'variants': {},
          'scope': 'Public layouts from checked debug artifacts; no parser creation or parsing. No measurement of private ShapeCache heap layout, allocator metadata, peak memory or speed.'}
report['compiler'] = run('rustc-version', ['rustc', '+ohm', '--version', '--verbose'])
old_layout = Path('/tmp/oriole-retained-c-frame-size/report.json')
old = json.loads(old_layout.read_text())
for label, worktree, check in [
    ('control', Path('/home/dev-user/code/oss/oriole-suffix-element-names'), Path('/tmp/oriole-suffix-element-names-checks/tests-01/report.json')),
    ('candidate', Path('/home/dev-user/code/oss/oriole-start-tag-shapes'), Path('/tmp/oriole-start-tag-shape-checks/tests01.json')),
]:
    checked = json.loads(check.read_text())
    if label == 'candidate':
        assert checked['exit_code'] == 0 and checked['source_before'] == checked['source_after']
        checked['source_sha256'] = checked['source_after']
        log = check.with_suffix('.log')
    else:
        assert checked['exit'] == 0 and checked['reaped'] and checked['source_unchanged']
        log = check.parent / 'output.log'
    assert all(sha(worktree / name) == digest for name, digest in checked['source_sha256'].items())
    assert sha(log) == checked['log_sha256']
    matches = re.findall(r'Running unittests src/lib.rs \((/[^\n]+/debug/deps)/oriole-[^)]+\)', log.read_text())
    assert len(set(matches)) == 1
    deps = Path(matches[0])
    cores = list(deps.glob('liboriole-*.rlib'))
    assert len(cores) == 1, cores
    libraries = {'oriole': cores[0], 'oriole_expat': deps / 'liboriole_expat.rlib'}
    hashes = {str(path): sha(path) for path in libraries.values()}
    previous_control_matches = None
    if label == 'control':
        previous_control_matches = hashes == old['variants']['suffix']['rlib_sha256']
    argv = ['rustc', '+ohm', '--edition=2024', str(source)]
    for crate, path in libraries.items():
        argv += ['--extern', f'{crate}={path}']
    argv += ['-L', f'dependency={deps}', '-o', str(root / label)]
    run(f'{label}-compile', argv)
    output = run(f'{label}-sizes', [str(root / label)])
    assert all(sha(Path(path)) == digest for path, digest in hashes.items())
    assert all(sha(worktree / name) == digest for name, digest in checked['source_sha256'].items())
    report['variants'][label] = {'worktree': str(worktree), 'checked_source_files': len(checked['source_sha256']),
                                'check_report': str(check), 'check_report_sha256': sha(check),
                                'check_log_sha256': sha(log), 'source_matches_passed_checks_before_after': True,
                                'head': run(f'{label}-head', ['git', '-C', str(worktree), 'rev-parse', 'HEAD']).strip(),
                                'previous_control_artifacts_unchanged': previous_control_matches,
                                'rlib_sha256': hashes, 'output': output, 'probe_sha256': sha(root / label)}
report['control_previous_layout_receipt'] = {'path': str(old_layout), 'sha256': sha(old_layout), 'rlibs_unchanged': report['variants']['control']['previous_control_artifacts_unchanged']}
report['commands'] = commands
report['script_sha256'] = sha(Path(__file__))
(root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({label: value['output'] for label, value in report['variants'].items()}))
