"""Reconstruct start-tag-shapes native measurements from saved workers only."""
from pathlib import Path
import argparse
import ast
import csv
import datetime
import hashlib
import json
import math
import os
import random
import statistics

ROOT = Path('/tmp/oriole-start-tag-shapes-native-study')
PREVIOUS = Path('/tmp/oriole-suffix-element-names-native-study')
BUILD = Path('/tmp/oriole-start-tag-shapes-pgo-study')
CONTROL = Path('/tmp/oriole-suffix-element-names-pgo-study')
HEAD = 'd8c5e503a4a432fb79f9ce5c05f44baf3428e425'
SELECTED = 'a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9'
DRIVER = Path('/tmp/oriole-grammar-bench-plain/native-driver')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs = {}


def pin(path):
    path = Path(path)
    digest = sha(path)
    assert str(path) not in inputs or inputs[str(path)] == digest
    inputs[str(path)] = digest
    return digest


def read(path):
    pin(path)
    return json.loads(Path(path).read_text())


def comparable(path):
    """Only study labels and the two Oriole library paths may change."""
    tree = ast.parse(Path(path).read_text())
    tree.body[0].value = ast.Constant('<caption>')
    for node in tree.body:
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name == 'root':
                node.value = ast.Constant('<study>')
            elif name == 'libraries':
                assert [key.value for key in node.value.keys] == ['control', 'candidate', 'expat']
                node.value.values[0] = ast.Constant('<control>')
                node.value.values[1] = ast.Constant('<candidate>')
            elif name == 'protocol':
                assert node.value.keys[0].value == 'scope'
                node.value.values[0] = ast.Constant('<scope>')
    return ast.dump(tree)


def library(build, pair, phase):
    if phase == 'normal':
        path = build / 'normal/liboriole_expat.so'
        digest = pair['normal_libraries']['liboriole_expat.so']
    else:
        path = Path(pair['pgo_manifest']['path']).parent / 'use/liboriole_expat.so'
        digest = pair['pgo_libraries']['use/liboriole_expat.so']
    assert pin(path) == digest
    return {'path': str(path), 'sha256': digest}


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--released', action='store_true')
parser.add_argument('--phase', required=True, choices=['normal', 'pgo'])
args = parser.parse_args()
assert __debug__ and args.released, 'Run only after root confirms this campaign completed and reaped'
assert os.sched_getaffinity(0) == {6}
OUT = Path(__file__).parent
assert not (OUT / (args.phase + '-review.json')).exists()
assert not (OUT / (args.phase + '-conditions.csv')).exists()

# Reuse the completed direct build readback, checking its original inputs rather
# than reconstructing a chain of earlier experiment-reader substitutions.
readback_path = BUILD / 'build-readback.json'
pin(readback_path)  # Bound below by the actual preparation for this phase.
readback = read(readback_path)
for path, digest in readback['inputs'].items():
    assert pin(path) == digest
source, pair = read(BUILD / 'source.json'), read(BUILD / 'pair-report.json')
selected_source, selected_pair = read(CONTROL / 'source.json'), read(CONTROL / 'pair-report.json')
assert source == readback['source'] and pair == readback['pair']
assert selected_source == readback['control_source'] and selected_pair == readback['control_pair']
assert source['candidate_base_commit'] == HEAD and source['base_runtime'] == SELECTED
assert selected_source['candidate_base_commit'] == SELECTED
assert pair['status'] == selected_pair['status'] == 'passed'
assert len(source['source_sha256']) == len(selected_source['source_sha256']) == 72
preparation = read(BUILD / 'preparation.json')
assert preparation['head'] == HEAD and preparation['check_labels'] == ['tests01', 'clippy01', 'fmt02', 'check02'] and preparation['expected_test_count'] == 443
assert sorted(name for name, digest in source['source_sha256'].items() if digest != selected_source['source_sha256'][name]) == preparation['expected_source_delta']
assert len(preparation['expected_source_delta']) == 5 and len(preparation['expected_pipeline_delta']) == 4

report = {'status': 'passed', 'role': 'Saved-data reviewer independently reconstructs root-collected native worker records. This reviewer prepared the directly bound native controller and allocation diagnostic, but did not author the runtime or original native arithmetic and did not execute compiler, parser, preflight or timing targets.', 'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'native': {}}
for phase in [args.phase]:
 S, T = ROOT / phase, PREVIOUS / phase
 D = S / 'native-screen'
 old, new = T / 'native_screen.py', S / 'native_screen.py'
 prep, old_prep = read(S / 'adaptation.json'), read(T / 'adaptation.json')
 assert prep['status'] == 'passed' and prep['prepared_not_executed']
 assert prep['origin'] == str(T) and old_prep['controller_sha256'] == pin(old)
 assert prep['controller_sha256'] == pin(new) and prep['wrapper_sha256'] == pin(S / 'run.py')
 assert prep['build_readback_sha256'] == pin(readback_path)
 assert prep['source_manifest_sha256'] == pin(BUILD / 'source.json')
 assert prep['control_source_manifest_sha256'] == pin(CONTROL / 'source.json')
 assert prep['build_pair_sha256'] == pin(BUILD / 'pair-report.json')
 assert prep['control_build_pair_sha256'] == pin(CONTROL / 'pair-report.json')
 assert (S / 'run.py').read_bytes() == (T / 'run.py').read_bytes()
 assert pin(S / 'run.py') == pin(T / 'run.py') == '5f41a419e800e95954424e2a85d2ee988609d830db18dc85c469af801cd8aef5'
 assert comparable(old) == comparable(new)
 assert old.read_text()[old.read_text().index('def run('):] == new.read_text()[new.read_text().index('def run('):]
 p, f, r = map(read, [D / 'protocol.json', D / 'preflight.json', D / 'results.json'])
 original_protocol = read(T / 'native-screen/protocol.json')
 assert list(p['libraries']) == ['control', 'candidate', 'expat']
 assert p['libraries']['candidate'] == prep['candidate_library'] == library(BUILD, pair, phase)
 assert p['libraries']['control'] == prep['control_library'] == library(CONTROL, selected_pair, phase) == original_protocol['libraries']['candidate']
 assert p['libraries']['expat'] == prep['expat_library'] == original_protocol['libraries']['expat']
 for item in p['libraries'].values():
  assert pin(item['path']) == item['sha256']
 assert f['status'] == r['status'] == 'passed' and r['affinity'] == [0]
 assert f['protocol_sha256'] == r['protocol_sha256'] == pin(D / 'protocol.json')
 assert r['preflight_sha256'] == pin(D / 'preflight.json')
 for item in [f, r]:
  assert item['hashes_before'] == item['hashes_after'] == p['hashes']
 for path, digest in p['hashes'].items():
  assert pin(path) == digest
 manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
 fixtures = {}
 for project in read(manifest)['projects']:
  entry = next(item for item in project['files'] if item['role'] == 'input')
  path = (manifest.parent / entry['path']).resolve()
  assert pin(path) == entry['sha256']
  fixtures[project['name']] = str(path)
 fixtures.update({'generated-rare-declarations': '/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml', 'generated-entities': '/tmp/oriole-grammar-bench-plain/entities.xml'})
 iterations = {'vulkan': 7, 'wayland': 64, 'maven': 128, 'batik': 512, 'gtk': 256, 'docbook': 256, 'generated-rare-declarations': 32, 'generated-entities': 32}
 expected_conditions = [{'name': name, 'input': path, 'chunk': chunk, 'namespaces': ns, 'iterations': iterations[name]} for chunk in [4096, 65536] for name, path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False, True])]
 assert p['conditions'] == original_protocol['conditions'] == expected_conditions
 assert len(p['conditions']) == 28 and p['pairs'] == original_protocol['pairs'] == 7
 assert p['seed'] == original_protocol['seed'] == 2026091003
 assert p['preflights'] == 84 and p['timed_workers'] == 588
 assert sum(item['name'].startswith('generated-') for item in p['conditions']) == 4
 assert len(f['rows']) == 84 and len(r['rows']) == 196 and len(r['summary']) == 28
 assert {path.name for path in D.glob('worker-*.json')} == {f'worker-{n:04d}.json' for n in range(672)}
 assert set(p['hashes']) == {str(new), str(manifest), str(DRIVER), *fixtures.values(), *[item['path'] for item in p['libraries'].values()]}
 for path in [str(manifest), str(DRIVER), *fixtures.values()]:
  assert p['hashes'][path] == original_protocol['hashes'][path]
 ctl = read(S / 'controller.json')
 assert ctl['status'] == 'passed' and ctl['controller_sha256'] == pin(new) and ctl['wrapper_sha256'] == pin(S / 'run.py')
 for row, (stage, cpu, bound) in zip(ctl['commands'], [('preflight', 5, 600), ('time', 0, 1200)], strict=True):
  assert row['phase'] == stage and row['exit'] == 0 and row['timeout'] == bound
  assert row['end'] >= row['start'] and 'exception' not in row
  assert row['command'] == ['taskset', '-c', str(cpu), 'python3', str(new), stage]
  assert pin(S / (stage + '-controller.log')) == row['log_sha256']
 ordinal=0; medians={}; obs={}; samples_count=0
 def worker(row,c,pair,engine,cpu,count):
  global ordinal,samples_count
  raw_path=D/f'worker-{ordinal:04d}.json';pin(raw_path);raw=read(raw_path);ordinal+=1
  assert raw=={k:v for k,v in row.items() if k not in ['observations','median_seconds']}
  assert row['condition']==c and row['pair']==pair and row['engine']==engine and row['returncode']==0 and row['stderr']==''
  assert row['command']==['taskset','-c',str(cpu),'/tmp/oriole-grammar-bench-plain/native-driver',p['libraries'][engine]['path'],c['input'],str(c['chunk']),str(count)]+(['namespaces'] if c['namespaces'] else [])
  data=json.loads(row['stdout']);s=data['samples'];samples_count+=len(s)
  assert len(s)==count+1 and [x['iteration'] for x in s]==list(range(count+1))
  assert [x['warmup'] for x in s]==[True]+[False]*count
  assert all(math.isfinite(x['seconds']) and x['seconds']>0 for x in s)
  got=sorted({(x['hash'],x['elements'],x['text_bytes']) for x in s});assert len(got)==1 and row['observations']==[list(x) for x in got]
  if json.dumps(c,sort_keys=True) in obs: assert obs[json.dumps(c,sort_keys=True)]==got
  else: obs[json.dumps(c,sort_keys=True)]=got
  assert got[0][1]>=0 and got[0][2]>=0
  med=statistics.median(x['seconds'] for x in s[1:]);assert med==row['median_seconds']
  return med
 for c in p['conditions']:
  for engine in p['libraries']:
   row=f['rows'][ordinal];worker(row,c,-1,engine,5,1)
 rng=random.Random(p['seed']);jobs=[(c,i) for c in p['conditions'] for i in range(7)];rng.shuffle(jobs)
 for row,(c,pair) in zip(r['rows'],jobs,strict=True):
  order=list(p['libraries']);rng.shuffle(order);assert row['condition']==c and row['pair']==pair and row['order']==order
  for rec,engine in zip(row['processes'],order,strict=True):medians[(json.dumps(c,sort_keys=True),pair,engine)]=worker(rec,c,pair,engine,0,c['iterations'])
 summary=[]
 for c in p['conditions']:
  pairs=[x['pair'] for x in r['rows'] if x['condition']==c]
  ratios={f'{x}_over_{y}':[medians[(json.dumps(c,sort_keys=True),i,x)]/medians[(json.dumps(c,sort_keys=True),i,y)] for i in pairs] for x,y in [('candidate','control'),('candidate','expat'),('control','expat')]}
  summary.append({'condition':c,'paired_ratios':ratios,'median_ratios':{k:statistics.median(v) for k,v in ratios.items()}})
 assert summary==r['summary'] and ordinal==672 and samples_count==106176
 groups={}
 for group in ['real','generated']:
  entries=[q for q in summary if q['condition']['name'].startswith('generated-')==(group=='generated')]
  groups[group]={'conditions':len(entries),'ratios':{k:statistics.geometric_mean(q['median_ratios'][k] for q in entries) for k in entries[0]['median_ratios']},'candidate_faster_than_control':sum(q['median_ratios']['candidate_over_control']<1 for q in entries),'candidate_faster_than_expat':sum(q['median_ratios']['candidate_over_expat']<1 for q in entries)}
 adverse=[{'name':q['condition']['name'],'chunk':q['condition']['chunk'],'namespaces':q['condition']['namespaces'],'ratio':q['median_ratios']['candidate_over_control']} for q in summary if q['median_ratios']['candidate_over_control']>1]
 groups['adverse_conditions']=adverse
 report['native'][phase] = {'preflights': 84, 'timed_workers': 588, 'cohorts': 196, 'measured_samples': 105420, 'timed_warmups': 588, 'preflight_samples': 168, 'total_samples': 106176, 'groups': groups, 'all_conditions': [{'condition': item['condition'], 'median_ratios': item['median_ratios']} for item in summary]}

report['limitations'] = ['One original fixed native campaign per released mode; all adverse conditions retained. Python and full compatibility gates are outside this review.', 'This audit does not establish a hardware or compiler mechanism or whole-application performance.', 'Legacy native worker uses explicit dlopen paths and before/after file hashes; no same-process XML_Parse dladdr check was added.', 'Serialized accounting changes nominal core types. Correctness and ownership behavior require the separate source/API/consumer reviews; this elapsed audit establishes no concurrency or lifetime guarantee.']
report['direct_build_binding'] = readback['summary']
report['configuration_scope'] = 'Matched O3 ThinLTO normal and fresh original-generated-only PGO. Serialized accounting candidate differs from selected suffix source in the nine reviewed runtime files recorded by preparation.json. Inline accounting tests are included in those sources. C fixtures, selected allocator, original native callback accounting and compiler options are unchanged. Existing direct build readback verifies nine vectors, 864 generated records, six artifacts and source/tool/profile bindings.'
report['reader_adaptation_note'] = 'Worker/sample/callback/seeded-order/median/ratio arithmetic is byte-identical to the suffix saved-data reader. Study/source/build/library bindings are direct, with no transitive old-reader pin substitution.'
report['measurement_body_sha256'] = hashlib.sha256((' ordinal=0; medians={}; obs={}; samples_count=0\n' + Path(__file__).read_text().split(' ordinal=0; medians={}; obs={}; samples_count=0\n', 1)[1].split(" report['native'][phase] =", 1)[0]).encode()).hexdigest()
report['source_files_rehashed'] = 72
report['totals'] = {'conditions': 28, 'preflight_workers': 84, 'timed_workers': 588, 'all_workers': 672, 'all_samples': 106176}
report['generator_sha256'] = pin(__file__)
for path, digest in inputs.items():
    assert sha(path) == digest
report['all_input_bytes_unchanged_after_read'] = True
report['input_sha256'] = inputs
csv_path = OUT / (args.phase + '-conditions.csv')
with csv_path.open('x', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(['phase', 'group', 'project', 'chunk', 'namespaces', 'iterations', 'candidate_over_control', 'candidate_over_expat', 'control_over_expat'])
    for row in report['native'][args.phase]['all_conditions']:
        condition, ratios = row['condition'], row['median_ratios']
        writer.writerow([args.phase, 'generated' if condition['name'].startswith('generated-') else 'real', condition['name'], condition['chunk'], condition['namespaces'], condition['iterations'], ratios['candidate_over_control'], ratios['candidate_over_expat'], ratios['control_over_expat']])
report['condition_csv_sha256'] = sha(csv_path)
out = OUT / (args.phase + '-review.json')
with out.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': report['status'], 'review': str(out), 'sha256': sha(out), 'groups': {key: value['groups'] for key, value in report['native'].items()}}))
