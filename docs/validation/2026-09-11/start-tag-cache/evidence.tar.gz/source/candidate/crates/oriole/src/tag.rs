//! Resumable lexical boundaries shared by complete and incremental tag parsing.

use oriole_storage::{AllocError, Allocator, Box, Vec};

use crate::names::is_xml_char;
use crate::{ErrorKind, NameRules, RawAttribute};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Phase {
    Space,
    Name,
    Equals,
    Quote,
    Value(u8),
}

#[derive(Clone, Copy, Debug)]
pub(crate) struct AttributeScanner {
    phase: Phase,
    offset: usize,
    separated: bool,
    name_start: usize,
    name_end: usize,
    value_start: usize,
    count: usize,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct Failure {
    pub(crate) kind: ErrorKind,
    pub(crate) message: &'static str,
    pub(crate) offset: usize,
}

#[derive(Clone, Copy, Debug)]
pub(crate) enum Step {
    Attribute(RawAttribute),
    End,
    TagEnd { end: usize, empty: bool },
    Incomplete,
}

impl AttributeScanner {
    pub(crate) fn new(offset: usize) -> Self {
        Self {
            phase: Phase::Space,
            offset,
            separated: false,
            name_start: 0,
            name_end: 0,
            value_start: 0,
            count: 0,
        }
    }

    /// Resume over an append-only UTF-8 input. Attribute ranges own no references.
    /// `tag_end` permits the closing syntax excluded by complete attribute views.
    pub(crate) fn next(
        &mut self,
        text: &str,
        final_input: bool,
        tag_end: bool,
        allow_refs: bool,
        limit: usize,
        rules: NameRules,
    ) -> Result<Step, Failure> {
        let fail = |kind, message, offset| Failure {
            kind,
            message,
            offset,
        };
        loop {
            match self.phase {
                Phase::Space => {
                    let start = self.offset;
                    self.skip_space(text);
                    self.separated |= self.offset != start;
                    if self.offset == text.len() {
                        return Ok(if final_input {
                            Step::End
                        } else {
                            Step::Incomplete
                        });
                    }
                    if tag_end {
                        match text.as_bytes()[self.offset] {
                            b'>' => {
                                return Ok(Step::TagEnd {
                                    end: self.offset + 1,
                                    empty: false,
                                });
                            }
                            b'/' if text.as_bytes().get(self.offset + 1) == Some(&b'>') => {
                                return Ok(Step::TagEnd {
                                    end: self.offset + 2,
                                    empty: true,
                                });
                            }
                            b'/' if self.offset + 1 == text.len() && !final_input => {
                                return Ok(Step::Incomplete);
                            }
                            _ => {}
                        }
                    }
                    if !self.separated {
                        return Err(fail(
                            ErrorKind::InvalidToken,
                            "attributes must be separated by whitespace",
                            self.offset,
                        ));
                    }
                    if self.count >= limit {
                        return Err(fail(
                            ErrorKind::LimitExceeded,
                            "attribute count limit exceeded",
                            self.offset,
                        ));
                    }
                    self.name_start = self.offset;
                    self.phase = Phase::Name;
                }
                Phase::Name => {
                    if self.offset == self.name_start {
                        let Some(first) = text[self.offset..].chars().next() else {
                            return Ok(Step::Incomplete);
                        };
                        if !rules.is_name_start(first) {
                            return Err(fail(
                                ErrorKind::InvalidToken,
                                "invalid attribute name",
                                self.offset,
                            ));
                        }
                        self.offset += first.len_utf8();
                    }
                    self.offset = name_end(text, self.offset, rules);
                    if self.offset == text.len() && !final_input {
                        return Ok(Step::Incomplete);
                    }
                    self.name_end = self.offset;
                    self.phase = Phase::Equals;
                }
                Phase::Equals => {
                    self.skip_space(text);
                    if self.offset == text.len() && !final_input {
                        return Ok(Step::Incomplete);
                    }
                    if text.as_bytes().get(self.offset) != Some(&b'=') {
                        return Err(fail(
                            ErrorKind::InvalidToken,
                            "attribute is missing equals sign",
                            self.offset,
                        ));
                    }
                    self.offset += 1;
                    self.phase = Phase::Quote;
                }
                Phase::Quote => {
                    self.skip_space(text);
                    if self.offset == text.len() && !final_input {
                        return Ok(Step::Incomplete);
                    }
                    let Some(&quote @ (b'\'' | b'"')) = text.as_bytes().get(self.offset) else {
                        return Err(fail(
                            ErrorKind::InvalidToken,
                            "attribute value must be quoted",
                            self.offset,
                        ));
                    };
                    self.offset += 1;
                    self.value_start = self.offset;
                    self.phase = Phase::Value(quote);
                }
                Phase::Value(quote) => {
                    let suffix = &text.as_bytes()[self.offset..];
                    let next = if tag_end {
                        memchr::memchr2(quote, b'<', suffix)
                    } else {
                        memchr::memchr(quote, suffix)
                    };
                    let Some(relative) = next else {
                        self.offset = text.len();
                        if final_input {
                            return Err(fail(
                                ErrorKind::UnclosedToken,
                                "unclosed attribute value",
                                self.value_start,
                            ));
                        }
                        return Ok(Step::Incomplete);
                    };
                    let end = self.offset + relative;
                    if text.as_bytes()[end] == b'<' {
                        return Err(fail(
                            ErrorKind::InvalidToken,
                            "invalid character in attribute value",
                            end,
                        ));
                    }
                    let value = &text[self.value_start..end];
                    // Complete views reject '<' before '&' even when '&' occurs
                    // earlier. Keep that precedence when input arrives in parts.
                    if let Some(offset) = value
                        .find('<')
                        .or_else(|| (!allow_refs).then(|| value.find('&')).flatten())
                    {
                        return Err(fail(
                            ErrorKind::InvalidToken,
                            "invalid character in attribute value",
                            self.value_start + offset,
                        ));
                    }
                    let attribute = RawAttribute {
                        name_start: self.name_start,
                        name_end: self.name_end,
                        value_start: self.value_start,
                        value_end: end,
                    };
                    self.offset = end + 1;
                    self.count += 1;
                    self.separated = false;
                    self.phase = Phase::Space;
                    return Ok(Step::Attribute(attribute));
                }
            }
        }
    }

    fn skip_space(&mut self, text: &str) {
        while text
            .as_bytes()
            .get(self.offset)
            .is_some_and(|b| matches!(b, b' ' | b'\t' | b'\r' | b'\n'))
        {
            self.offset += 1;
        }
    }
}

/// Find a name's next boundary; callers validate the first character separately.
pub(crate) fn name_end(text: &str, offset: usize, rules: NameRules) -> usize {
    text[offset..]
        .char_indices()
        .find(|(_, c)| !rules.is_name_char(*c))
        .map_or(text.len(), |(index, _)| offset + index)
}

/// Check literal attribute eligibility without separate normalization and XML scans.
fn is_literal_value(text: &str) -> bool {
    let mut rest = text;
    while let Some(chunk) = rest.as_bytes().first_chunk::<8>() {
        let word = u64::from_le_bytes(*chunk);
        let high = 0x8080_8080_8080_8080;
        let control = word.wrapping_sub(0x2020_2020_2020_2020) & !word & high;
        let ampersand = word ^ 0x2626_2626_2626_2626;
        let reference = ampersand.wrapping_sub(0x0101_0101_0101_0101) & !ampersand & high;
        // Each nonzero mask implies an actual control byte or ampersand.
        // Borrow propagation can mark later bytes, but cannot create a match.
        if control | reference != 0 {
            return false;
        }
        if word & high != 0 {
            break;
        }
        rest = &rest[8..];
    }
    // Only ASCII words were skipped, so this remains a UTF-8 boundary.
    // XML's allowed TAB/CR/LF still require attribute normalization.
    rest.chars()
        .all(|character| character >= ' ' && character != '&' && is_xml_char(character))
}

/// Scalar progress plus offset records supplied by the parser's existing cache.
/// Failed or cold plans fall back once; they never allocate while input arrives.
#[derive(Debug, Default)]
pub(crate) struct TagScanner {
    source_index: Option<usize>,
    offset: usize,
    name_end: Option<usize>,
    attributes: Option<AttributeScanner>,
    disabled: bool,
    resumed: bool,
    shapes: Option<Box<ShapeCache>>,
}

#[derive(Clone, Copy, Debug)]
pub(crate) enum Planned {
    Complete {
        end: usize,
        name_end: usize,
        unique_names: bool,
    },
    Incomplete,
    Fallback,
}

impl Planned {
    /// A hit proves raw-name uniqueness, never namespace-expanded uniqueness.
    pub(crate) fn unique_names(self) -> bool {
        matches!(
            self,
            Self::Complete {
                unique_names: true,
                ..
            }
        )
    }
}

const SHAPE_ENTRIES: usize = 8;
const SHAPE_BYTES: usize = 512;
const SHAPE_ATTRIBUTES: usize = 8;
const SHAPE_TOKEN_BYTES: usize = 4096;
const SHAPE_PROBE_BYTES: usize = 8192;

#[derive(Clone, Copy, Debug, Default)]
struct ShapeAttribute {
    prefix_end: u16,
    name_start: u16,
    name_end: u16,
}

/// Exact bytes outside literal values, with offsets into this private byte array.
#[derive(Debug)]
struct Shape {
    bytes: [u8; SHAPE_BYTES],
    attributes: [ShapeAttribute; SHAPE_ATTRIBUTES],
    length: u16,
    name_end: u16,
    count: u8,
    rules: NameRules,
}

impl Default for Shape {
    fn default() -> Self {
        Self {
            bytes: [0; SHAPE_BYTES],
            attributes: [ShapeAttribute::default(); SHAPE_ATTRIBUTES],
            length: 0,
            name_end: 0,
            count: 0,
            rules: NameRules::default(),
        }
    }
}

impl Shape {
    /// Copy only after successful lowering proved the private ordered names unique.
    fn store(&mut self, token: &str, name_end: usize, records: &[RawAttribute], rules: NameRules) {
        let mut input_start = 0;
        let mut key_start = 0;
        for (index, record) in records.iter().enumerate() {
            let value_start = name_end + record.value_start;
            let prefix = &token.as_bytes()[input_start..value_start];
            let prefix_end = key_start + prefix.len();
            self.bytes[key_start..prefix_end].copy_from_slice(prefix);
            self.attributes[index] = ShapeAttribute {
                prefix_end: prefix_end as u16,
                name_start: (key_start + name_end + record.name_start - input_start) as u16,
                name_end: (key_start + name_end + record.name_end - input_start) as u16,
            };
            input_start = name_end + record.value_end;
            key_start = prefix_end;
        }
        let tail = &token.as_bytes()[input_start..];
        let length = key_start + tail.len();
        self.bytes[key_start..length].copy_from_slice(tail);
        self.length = length as u16;
        self.name_end = name_end as u16;
        self.count = records.len() as u8;
        self.rules = rules;
    }

    /// Compare exact syntax and revalidate every value within a shared scan budget.
    fn matches(
        &self,
        text: &str,
        records: &mut Vec<RawAttribute>,
        budget: &mut usize,
    ) -> Option<usize> {
        let name_end = usize::from(self.name_end);
        let mut input_start = 0;
        let mut key_start = 0;
        for attribute in &self.attributes[..usize::from(self.count)] {
            let key_end = usize::from(attribute.prefix_end);
            let prefix = &self.bytes[key_start..key_end];
            take_probe_budget(budget, prefix.len())?;
            let value_start = input_start + prefix.len();
            if text.as_bytes().get(input_start..value_start)? != prefix {
                return None;
            }
            let quote = *prefix.last()?;
            // Each inspected value byte is charged for quote search and literal
            // validation. A truncated probe never changes resumable scan state.
            let suffix = &text.as_bytes()[value_start..];
            let search = &suffix[..suffix.len().min(*budget / 2)];
            let found = memchr::memchr2(quote, b'<', search);
            let inspected = found.map_or(search.len(), |offset| offset + 1);
            *budget -= inspected * 2;
            let end = value_start + found?;
            if text.as_bytes()[end] != quote || !is_literal_value(&text[value_start..end]) {
                return None;
            }
            records.push(RawAttribute {
                name_start: input_start + usize::from(attribute.name_start) - key_start - name_end,
                name_end: input_start + usize::from(attribute.name_end) - key_start - name_end,
                value_start: value_start - name_end,
                value_end: end - name_end,
            });
            input_start = end;
            key_start = key_end;
        }
        let tail = &self.bytes[key_start..usize::from(self.length)];
        take_probe_budget(budget, tail.len())?;
        let end = input_start + tail.len();
        (text.as_bytes().get(input_start..end)? == tail).then_some(end)
    }
}

fn take_probe_budget(budget: &mut usize, count: usize) -> Option<()> {
    let Some(remaining) = budget.checked_sub(count) else {
        *budget = 0;
        return None;
    };
    *budget = remaining;
    Some(())
}

/// One caller-allocated owner; LRU indices move without copying the fixed entries.
#[derive(Debug)]
struct ShapeCache {
    entries: [Shape; SHAPE_ENTRIES],
    recent: [u8; SHAPE_ENTRIES],
    length: usize,
}

impl ShapeCache {
    #[cold]
    fn new_in(allocator: Allocator) -> Result<Box<Self>, AllocError> {
        oriole_storage::try_box(
            Self {
                entries: std::array::from_fn(|_| Shape::default()),
                recent: std::array::from_fn(|index| index as u8),
                length: 0,
            },
            allocator,
        )
    }

    fn touch(&mut self, index: usize) {
        self.recent[..=index].rotate_right(1);
    }

    fn scan(
        &mut self,
        text: &str,
        limit: usize,
        rules: NameRules,
        records: &mut Vec<RawAttribute>,
    ) -> Option<Planned> {
        let mut budget = SHAPE_PROBE_BYTES;
        for recent in 0..self.length {
            let entry = &self.entries[usize::from(self.recent[recent])];
            if entry.rules != rules || usize::from(entry.count) > limit.min(records.capacity()) {
                continue;
            }
            if let Some(end) = entry.matches(text, records, &mut budget) {
                let name_end = usize::from(entry.name_end);
                self.touch(recent);
                return Some(Planned::Complete {
                    end,
                    name_end,
                    unique_names: true,
                });
            }
            records.clear();
            if budget == 0 {
                break;
            }
        }
        None
    }
}

impl TagScanner {
    /// Record only into already allocated capacity. Syntax failures are left to
    /// the original token boundary/error path, preserving its error precedence.
    pub(crate) fn scan(
        &mut self,
        text: &str,
        source_index: usize,
        token_limit: usize,
        attribute_limit: usize,
        rules: NameRules,
        records: &mut Vec<RawAttribute>,
    ) -> Planned {
        if self.source_index != Some(source_index) {
            self.source_index = Some(source_index);
            self.offset = 1;
            self.name_end = None;
            self.attributes = None;
            self.disabled = false;
            self.resumed = false;
            records.clear();
            if let Some(shapes) = &mut self.shapes {
                let visible =
                    text.floor_char_boundary(text.len().min(token_limit).min(SHAPE_TOKEN_BYTES));
                if let Some(planned) =
                    shapes.scan(&text[..visible], attribute_limit, rules, records)
                {
                    return planned;
                }
            }
        } else {
            self.resumed = true;
        }
        if self.disabled {
            return Planned::Fallback;
        }
        let visible = text.floor_char_boundary(text.len().min(token_limit.saturating_add(1)));
        let input = &text[..visible];
        let result = self.advance(input, token_limit, attribute_limit, rules, records);
        let result = if matches!(result, Planned::Incomplete) && text.len() > token_limit {
            Planned::Fallback
        } else {
            result
        };
        if matches!(result, Planned::Fallback) {
            self.disabled = true;
        }
        result
    }

    fn advance(
        &mut self,
        text: &str,
        token_limit: usize,
        attribute_limit: usize,
        rules: NameRules,
        records: &mut Vec<RawAttribute>,
    ) -> Planned {
        if self.name_end.is_none() {
            if self.offset == 1 {
                let Some(first) = text.get(1..).and_then(|rest| rest.chars().next()) else {
                    return Planned::Incomplete;
                };
                if !rules.is_name_start(first) {
                    return Planned::Fallback;
                }
                self.offset += first.len_utf8();
            }
            self.offset = name_end(text, self.offset, rules);
            if self.offset == text.len() {
                return Planned::Incomplete;
            }
            self.name_end = Some(self.offset);
            self.attributes = Some(AttributeScanner::new(self.offset));
        }
        let name_end = self.name_end.unwrap();
        let scanner = self.attributes.as_mut().unwrap();
        loop {
            match scanner.next(text, false, true, true, attribute_limit, rules) {
                Ok(Step::Attribute(mut attribute)) => {
                    let value = attribute.value(text);
                    if records.len() == records.capacity() || !is_literal_value(value) {
                        return Planned::Fallback;
                    }
                    attribute.name_start -= name_end;
                    attribute.name_end -= name_end;
                    attribute.value_start -= name_end;
                    attribute.value_end -= name_end;
                    // Capacity was checked above. No allocation is possible.
                    records.push(attribute);
                }
                Ok(Step::TagEnd { end, empty }) => {
                    debug_assert_eq!(empty, text[..end].ends_with("/>"));
                    return if end <= token_limit {
                        Planned::Complete {
                            end,
                            name_end,
                            unique_names: false,
                        }
                    } else {
                        Planned::Fallback
                    };
                }
                Ok(Step::Incomplete) => return Planned::Incomplete,
                Ok(Step::End) | Err(_) => return Planned::Fallback,
            }
        }
    }

    /// Admit only fully lowered native adapter starts, never returned event owners.
    /// The one lazy allocation is fallible and uses normal caller accounting.
    pub(crate) fn remember(
        &mut self,
        token: &str,
        name_end: usize,
        records: &[RawAttribute],
        rules: NameRules,
        allocator: Allocator,
        recycling: &mut crate::recycling::EventRecycling,
    ) -> Result<(), AllocError> {
        if self.resumed || token.len() > SHAPE_TOKEN_BYTES || records.len() > SHAPE_ATTRIBUTES {
            return Ok(());
        }
        let values: usize = records
            .iter()
            .map(|record| record.value_end - record.value_start)
            .sum();
        if token.len() - values > SHAPE_BYTES {
            return Ok(());
        }
        if self.shapes.is_none() {
            recycling.reserve_shapes(size_of::<ShapeCache>());
            match ShapeCache::new_in(allocator) {
                Ok(shapes) => self.shapes = Some(shapes),
                Err(error) => {
                    recycling.reserve_shapes(0);
                    return Err(error);
                }
            }
        }
        let shapes = self.shapes.as_mut().unwrap();
        let recent = if shapes.length < SHAPE_ENTRIES {
            let recent = shapes.length;
            shapes.length += 1;
            recent
        } else {
            SHAPE_ENTRIES - 1
        };
        let entry = usize::from(shapes.recent[recent]);
        shapes.entries[entry].store(token, name_end, records, rules);
        shapes.touch(recent);
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        Error, Position, invalid_xml_char, parse_raw_attributes, take_name, try_push, whitespace,
    };
    use oriole_storage::Allocator;

    type Outcome = (
        std::vec::Vec<[usize; 4]>,
        Option<(ErrorKind, &'static str, usize)>,
    );

    #[test]
    fn literal_values_match_separate_checks_at_word_and_unicode_boundaries() {
        fn check(text: &str) {
            let expected = !text
                .bytes()
                .any(|byte| matches!(byte, b'&' | b'\t' | b'\r' | b'\n'))
                && invalid_xml_char(text).is_none();
            assert_eq!(is_literal_value(text), expected, "{text:?}");
        }

        check("");
        // Adjacent ASCII pairs exercise both word masks and propagated borrows.
        for offset in 0..8 {
            for first in 0..128 {
                for second in 0..128 {
                    let mut bytes = [b'x'; 24];
                    bytes[offset] = first;
                    bytes[offset + 1] = second;
                    check(std::str::from_utf8(&bytes).unwrap());
                }
            }
        }
        let mut text = std::string::String::new();
        for scalar in 0..=0x10ffff {
            if let Some(character) = char::from_u32(scalar) {
                text.clear();
                text.push_str("0123456");
                text.push(character);
                text.push_str("abcdefghi");
                check(&text);
            }
        }
        for offset in 0..16 {
            for value in ["é&", "é\t", "é\r\n", "é\0", "é😀", "\u{fffe}", "\u{ffff}"] {
                for tail in [0, 7, 8, 9, 128, 4096] {
                    check(&format!(
                        "{}{value}{}",
                        "x".repeat(offset),
                        "x".repeat(tail)
                    ));
                }
            }
        }
    }

    fn outcome(text: &str, refs: bool, limit: usize, legacy: bool) -> Outcome {
        let mut attrs = Vec::new_in(Allocator::System);
        let result = if legacy {
            legacy_parse_raw_attributes(text, refs, &mut attrs, limit, NameRules::default())
        } else {
            parse_raw_attributes(text, refs, &mut attrs, limit, NameRules::default())
        };
        (
            attrs
                .iter()
                .map(|a| [a.name_start, a.name_end, a.value_start, a.value_end])
                .collect(),
            result
                .err()
                .map(|e| (e.kind, e.message, e.position.byte_index)),
        )
    }

    #[test]
    fn complete_grammar_matches_original_short_alphabet_and_error_prefix() {
        let alphabet = b" a='\"&</\t";
        for len in 0..=4 {
            for mut word in 0..alphabet.len().pow(len) {
                let mut bytes = vec![0; len as usize];
                for byte in &mut bytes {
                    *byte = alphabet[word % alphabet.len()];
                    word /= alphabet.len();
                }
                let text = std::str::from_utf8(&bytes).unwrap();
                for refs in [false, true] {
                    for limit in [0, 1, 3] {
                        assert_eq!(
                            outcome(text, refs, limit, false),
                            outcome(text, refs, limit, true),
                            "{text:?} refs={refs} limit={limit}"
                        );
                    }
                }
            }
        }
        for text in [
            " a='x' b=",
            " a='&x<'",
            " a='&x' b='<'",
            " é = 'α😀' :x=\"z\"",
            " a='x'\r\nb='y'",
            " a='x' a='y'",
            " a='x' b='unterminated",
        ] {
            for refs in [false, true] {
                for limit in [0, 1, 2, 3] {
                    assert_eq!(
                        outcome(text, refs, limit, false),
                        outcome(text, refs, limit, true),
                        "{text:?}"
                    );
                }
            }
        }
    }

    #[test]
    fn planned_boundaries_and_records_match_original_across_every_split() {
        use crate::ScanMode;
        use crate::encoding::Source;
        let mut inputs: std::vec::Vec<std::string::String> = [
            "<root>",
            "<r/>",
            "<r a='x' b=\"y\"/>",
            "<é α='😀' b='a > b' />",
            "<r a='x' b='y' c='z'/>",
            "<r a='x'bad='y'>",
            "<r a='x<' >",
            "<r a='x&y' />",
            "<r a='\0' >",
            "<r a='x' / >",
            "<r a='unterminated",
        ]
        .into_iter()
        .map(str::to_owned)
        .collect();
        for name in ["r", "p:r", ":r", "1r", "r\u{901}", "\u{901}", "é", "😀"] {
            for tail in [
                "",
                " a=\"v\"",
                " a=\"x<\"",
                " a=\"x&y\"",
                " a=\"\0\"",
                " a=\"v\"bad=\"x\"",
                " a=\"v\" a=\"x\"",
                " a=\"unterminated",
                " /",
                "/ ",
            ] {
                inputs.push(format!("<{name}{tail}>"));
            }
        }
        for input in inputs {
            for limit in 0..=input.len() + 1 {
                for split in 0..=input.len() {
                    if !input.is_char_boundary(split) {
                        continue;
                    }
                    for capacity in [0, 1, 4] {
                        let mut records = Vec::new_in(Allocator::System);
                        records.try_reserve_exact(capacity).unwrap();
                        let original_capacity = records.capacity();
                        let original_pointer = records.as_ptr();
                        let mut plan = TagScanner::default();
                        let mut source = Source::new(Allocator::System, NameRules::default());
                        let mut before = 0;
                        for end in [split, input.len()] {
                            source.text.try_push_str(&input[before..end]).unwrap();
                            before = end;
                            let observed = plan.scan(
                                &input[..end],
                                0,
                                limit,
                                10,
                                NameRules::default(),
                                &mut records,
                            );
                            assert_eq!(records.capacity(), original_capacity);
                            assert_eq!(records.as_ptr(), original_pointer);
                            let reference = source.scan_token(ScanMode::Tag, limit);
                            match observed {
                                Planned::Complete {
                                    end: tag_end,
                                    name_end,
                                    ..
                                } => {
                                    assert_eq!(
                                        reference,
                                        Ok(Some(tag_end)),
                                        "{input:?} split={split} limit={limit}"
                                    );
                                    assert!(invalid_xml_char(&input[..tag_end]).is_none());
                                    let body_end = tag_end
                                        - if input[..tag_end].ends_with("/>") {
                                            2
                                        } else {
                                            1
                                        };
                                    let mut expected = Vec::new_in(Allocator::System);
                                    legacy_parse_raw_attributes(
                                        &input[name_end..body_end],
                                        true,
                                        &mut expected,
                                        10,
                                        NameRules::default(),
                                    )
                                    .unwrap();
                                    assert_eq!(
                                        records
                                            .iter()
                                            .map(|a| [
                                                a.name_start,
                                                a.name_end,
                                                a.value_start,
                                                a.value_end
                                            ])
                                            .collect::<std::vec::Vec<_>>(),
                                        expected
                                            .iter()
                                            .map(|a| [
                                                a.name_start,
                                                a.name_end,
                                                a.value_start,
                                                a.value_end
                                            ])
                                            .collect::<std::vec::Vec<_>>()
                                    );
                                }
                                Planned::Incomplete => assert_eq!(
                                    reference,
                                    Ok(None),
                                    "{input:?} split={split} limit={limit}"
                                ),
                                Planned::Fallback => {}
                            }
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn accepted_name_characters_are_valid_xml_characters() {
        for rules in [NameRules::FourthEdition, NameRules::FifthEdition] {
            for code in 0..=0x10ffff {
                if let Some(c) = char::from_u32(code)
                    && rules.is_name_char(c)
                {
                    assert!(crate::is_xml_char(c), "{rules:?} {code:x}");
                }
            }
        }
    }

    #[test]
    fn fallback_stays_disabled_until_the_source_advances() {
        let input = "<r a='x' b='y'>";
        let mut records = Vec::new_in(Allocator::System);
        let mut scanner = TagScanner::default();
        // The first completed attribute exhausts the initially empty cache.
        assert!(matches!(
            scanner.scan(&input[..8], 0, 100, 10, NameRules::default(), &mut records),
            Planned::Fallback
        ));
        records.try_reserve_exact(2).unwrap();
        let pointer = records.as_ptr();
        for end in 8..=input.len() {
            assert!(matches!(
                scanner.scan(
                    &input[..end],
                    0,
                    100,
                    10,
                    NameRules::default(),
                    &mut records
                ),
                Planned::Fallback
            ));
            assert!(records.is_empty());
            assert_eq!(records.as_ptr(), pointer);
        }
        // A distinct physical token can use the available capacity again.
        assert!(matches!(
            scanner.scan(input, 1, 100, 10, NameRules::default(), &mut records),
            Planned::Complete { end, name_end: 2, .. } if end == input.len()
        ));
        assert_eq!(records.len(), 2);
        assert_eq!(records.as_ptr(), pointer);
    }

    fn remember_shape(scanner: &mut TagScanner, token: &str, index: usize, rules: NameRules) {
        let mut records = Vec::new_in(Allocator::System);
        records.try_reserve_exact(SHAPE_ATTRIBUTES).unwrap();
        let Planned::Complete { name_end, .. } =
            scanner.scan(token, index, 4096, 8, rules, &mut records)
        else {
            panic!("test seed must be a complete literal tag");
        };
        for (index, record) in records.iter().enumerate() {
            assert!(
                records[..index]
                    .iter()
                    .all(|prior| prior.name(&token[name_end..]) != record.name(&token[name_end..]))
            );
        }
        let mut recycling = crate::recycling::EventRecycling::new(Allocator::System).unwrap();
        scanner
            .remember(
                token,
                name_end,
                &records,
                rules,
                Allocator::System,
                &mut recycling,
            )
            .unwrap();
    }

    #[test]
    fn shape_hits_revalidate_values_and_misses_preserve_resumable_scanning() {
        let rules = NameRules::FourthEdition;
        let seed = "<r a='first' b=\"second\"/>";
        let changed = "<r a='α😀' b=\"different\"/>";
        let mut scanner = TagScanner::default();
        remember_shape(&mut scanner, seed, 0, rules);
        let mut records = Vec::new_in(Allocator::System);
        records.try_reserve_exact(8).unwrap();
        let pointer = records.as_ptr();
        assert!(
            scanner
                .scan(changed, 1, 4096, 8, rules, &mut records)
                .unique_names()
        );
        assert_eq!(records[0].value(&changed[2..]), "α😀");
        assert_eq!(records[1].value(&changed[2..]), "different");
        assert_eq!(records.as_ptr(), pointer);
        for (index, value) in ["&amp;", "\n", "<", "\0", "\u{fffe}"].iter().enumerate() {
            let input = format!("<r a='{value}' b=\"second\"/>");
            assert!(
                !scanner
                    .scan(&input, index + 2, 4096, 8, rules, &mut records)
                    .unique_names()
            );
        }
        assert!(
            !scanner
                .scan(seed, 20, 4096, 8, NameRules::FifthEdition, &mut records)
                .unique_names()
        );
        assert!(
            !scanner
                .scan(seed, 21, 4096, 1, rules, &mut records)
                .unique_names()
        );
        assert!(
            !scanner
                .scan(seed, 22, seed.len() - 1, 8, rules, &mut records)
                .unique_names()
        );
        let duplicate = "<r a='first' a=\"second\"/>";
        assert!(
            !scanner
                .scan(duplicate, 23, 4096, 8, rules, &mut records)
                .unique_names()
        );
        for (index, input) in [
            "<r a='first'  b=\"second\"/>",
            "<r a=\"first\" b=\"second\"/>",
            "<r b='first' a=\"second\"/>",
        ]
        .iter()
        .enumerate()
        {
            assert!(
                !scanner
                    .scan(input, 30 + index, 4096, 8, rules, &mut records)
                    .unique_names()
            );
        }
        for split in 1..changed.len() {
            if !changed.is_char_boundary(split) {
                continue;
            }
            let index = 100 + split;
            assert!(
                !scanner
                    .scan(&changed[..split], index, 4096, 8, rules, &mut records)
                    .unique_names()
            );
            assert!(
                !scanner
                    .scan(changed, index, 4096, 8, rules, &mut records)
                    .unique_names()
            );
            assert_eq!(records.len(), 2);
            assert_eq!(records[1].value(&changed[2..]), "different");
        }
        assert!(
            scanner
                .scan(changed, 1000, 4096, 8, rules, &mut records)
                .unique_names()
        );
    }

    #[test]
    fn shape_cache_caps_replacement_storage_and_cumulative_probes() {
        let rules = NameRules::default();
        let mut scanner = TagScanner::default();
        for index in 0..9 {
            remember_shape(
                &mut scanner,
                &format!("<r a='value' b{index}='v'/>"),
                index,
                rules,
            );
        }
        let shapes = scanner.shapes.as_ref().unwrap();
        assert_eq!(shapes.length, SHAPE_ENTRIES);
        assert!(size_of::<ShapeCache>() < 5 * 1024);
        let mut records = Vec::new_in(Allocator::System);
        records.try_reserve_exact(8).unwrap();
        assert!(
            !scanner
                .scan("<r a='value' b0='v'/>", 20, 4096, 8, rules, &mut records)
                .unique_names()
        );
        assert!(
            scanner
                .scan("<r a='value' b8='v'/>", 21, 4096, 8, rules, &mut records)
                .unique_names()
        );
        let long = format!("<r a='{}' missing='v'/>", "x".repeat(4000));
        let shapes = scanner.shapes.as_ref().unwrap();
        let mut budget = SHAPE_PROBE_BYTES;
        for entry in &shapes.entries {
            assert!(entry.matches(&long, &mut records, &mut budget).is_none());
            records.clear();
        }
        assert_eq!(budget, 0);
        assert!(
            !scanner
                .scan(&long, 22, 4096, 8, rules, &mut records)
                .unique_names()
        );
        assert_eq!(records.len(), 2);
        assert_eq!(records[1].name(&long[2..]), "missing");
    }

    #[test]
    fn shape_allocation_failure_and_drop_use_the_original_tracker() {
        use oriole_storage::{AllocationTracker, with_tracking};
        let token = "<r/>";
        let rules = NameRules::default();
        let mut scanner = TagScanner::default();
        let mut recycling = crate::recycling::EventRecycling::new(Allocator::System).unwrap();
        let tracker = AllocationTracker::try_new_in(Allocator::System).unwrap();
        tracker.set_activation_threshold(0);
        assert!(tracker.set_maximum_amplification(1.0));
        assert_eq!(
            with_tracking(&tracker, || scanner.remember(
                token,
                2,
                &[],
                rules,
                Allocator::TrackedSystem,
                &mut recycling
            )),
            Err(AllocError::OutOfMemory)
        );
        assert!(scanner.shapes.is_none());
        assert_eq!(tracker.live_bytes(), 0);
        assert!(tracker.add_direct_bytes(65536));
        with_tracking(&tracker, || {
            scanner.remember(
                token,
                2,
                &[],
                rules,
                Allocator::TrackedSystem,
                &mut recycling,
            )
        })
        .unwrap();
        let bytes = tracker.live_bytes();
        assert!(bytes >= size_of::<ShapeCache>());
        let pointer = std::ptr::from_ref(&**scanner.shapes.as_ref().unwrap());
        let mut records = Vec::new_in(Allocator::System);
        assert!(
            scanner
                .scan(token, 1, 4096, 8, rules, &mut records)
                .unique_names()
        );
        assert_eq!(
            std::ptr::from_ref(&**scanner.shapes.as_ref().unwrap()),
            pointer
        );
        assert_eq!(tracker.live_bytes(), bytes);
        drop(scanner);
        assert_eq!(tracker.live_bytes(), 0);
        let mut fresh = TagScanner::default();
        assert!(
            !fresh
                .scan(token, 1, 4096, 8, rules, &mut records)
                .unique_names()
        );
    }

    #[test]
    fn cache_allocation_failure_does_not_publish_or_retry_a_start() {
        use oriole_storage::{AllocationTracker, with_tracking};
        let tracker = AllocationTracker::try_new_in(Allocator::System).unwrap();
        let mut parser = with_tracking(&tracker, || {
            let mut parser =
                crate::Parser::try_new_in(crate::Config::default(), Allocator::TrackedSystem)
                    .unwrap();
            parser.feed(b"<root><n/></root>", true).unwrap();
            drop(parser.next_event().unwrap().unwrap());
            parser
        });
        let mut frame = parser.adapter_frame();
        assert!(parser.tag_scanner.shapes.is_none());
        // Fund small token/frame/name owners, but not the fixed cache payload.
        tracker.reset_direct_bytes();
        assert!(tracker.add_direct_bytes((tracker.live_bytes() + 1024) as u64));
        tracker.set_activation_threshold(0);
        assert!(tracker.set_maximum_amplification(1.0));
        let mut event = None;
        let error = with_tracking(&tracker, || {
            parser.next_event_for_adapter_into(&mut event, &mut frame)
        })
        .unwrap_err();
        assert_eq!(error.kind, ErrorKind::NoMemory);
        assert!(parser.tag_scanner.shapes.is_none());
        assert!(!frame.is_active() && event.is_none());
        let live = tracker.live_bytes();
        assert!(tracker.add_direct_bytes(65536));
        assert_eq!(
            with_tracking(&tracker, || parser
                .next_event_for_adapter_into(&mut event, &mut frame))
            .unwrap_err(),
            error
        );
        assert_eq!(tracker.live_bytes(), live);
        parser.finish_adapter_frame(frame);
        drop(parser);
        assert_eq!(tracker.live_bytes(), 0);
    }

    fn legacy_parse_raw_attributes(
        text: &str,
        allow_refs: bool,
        result: &mut Vec<RawAttribute>,
        limit: usize,
        name_rules: NameRules,
    ) -> Result<(), Error> {
        let original_len = text.len();
        let mut text = text;
        result.clear();
        let error_at = |kind, message, remaining: &str| Error {
            kind,
            message,
            position: Position {
                byte_index: original_len - remaining.len(),
                line: 1,
                column: 0,
                byte_count: 0,
            },
        };
        while !text.is_empty() {
            let trimmed = text.trim_start_matches(whitespace);
            if trimmed.len() == text.len() {
                return Err(error_at(
                    ErrorKind::InvalidToken,
                    "attributes must be separated by whitespace",
                    text,
                ));
            }
            text = trimmed;
            if text.is_empty() {
                break;
            }
            if result.len() >= limit {
                return Err(error_at(
                    ErrorKind::LimitExceeded,
                    "attribute count limit exceeded",
                    text,
                ));
            }
            let name_offset = original_len - text.len();
            let (name, rest) = take_name(text, name_rules).ok_or(error_at(
                ErrorKind::InvalidToken,
                "invalid attribute name",
                text,
            ))?;
            let rest = rest.trim_start_matches(whitespace);
            let rest = rest
                .strip_prefix('=')
                .ok_or(error_at(
                    ErrorKind::InvalidToken,
                    "attribute is missing equals sign",
                    rest,
                ))?
                .trim_start_matches(whitespace);
            let quote = rest
                .chars()
                .next()
                .filter(|c| matches!(c, '\'' | '"'))
                .ok_or(error_at(
                    ErrorKind::InvalidToken,
                    "attribute value must be quoted",
                    rest,
                ))?;
            let rest = &rest[1..];
            let end = rest.find(quote).ok_or(error_at(
                ErrorKind::UnclosedToken,
                "unclosed attribute value",
                rest,
            ))?;
            let value = &rest[..end];
            let value_offset = original_len - rest.len();
            if let Some(offset) = value
                .find('<')
                .or_else(|| (!allow_refs).then(|| value.find('&')).flatten())
            {
                return Err(error_at(
                    ErrorKind::InvalidToken,
                    "invalid character in attribute value",
                    &rest[offset..],
                ));
            }
            try_push(
                result,
                RawAttribute {
                    name_start: name_offset,
                    name_end: name_offset + name.len(),
                    value_start: value_offset,
                    value_end: value_offset + value.len(),
                },
            )?;
            text = &rest[end + 1..];
        }
        Ok(())
    }
}
