# Private start-tag structure cache review

Completed read-only source review of `/home/dev-user/code/oss/oriole-start-tag-shapes`, based on selected suffix `4929a90`. The author owns source changes and compilation. This reviewer has executed no parser, compiler, or benchmark.

## Verdict

No actionable runtime defect found in the stable four-file diff. The source matches all 61 Rust pins in the author's check02 receipt. This review permits proceeding to the parent's compatibility, allocation and performance gates; it does not establish their outcomes.

- Admission takes private lexical token bytes and offset records after successful lowering, not returned public event strings. Cached raw-name uniqueness cannot be supplied by an API caller.
- The existing planner gate requires unanchored native UTF-8, no DTD/shared tables, no fragment and a sole source. Custom ASCII-alias decoding and entity context cannot reuse this proof.
- Keys preserve element/attribute syntax, whitespace, quotes and closing syntax; every variable value is searched and validated anew. References, normalization-requiring characters and invalid XML characters fall back. Failed candidate records are cleared before ordinary scanning.
- Namespace resolution and expanded-name duplicate checks use current bindings after a hit. The identity-expansion adapter guard is also reevaluated on every start.
- Eight entries share an 8,192-byte scan budget. A token receives one fresh probe, then uses existing incremental scanner state; a partial probe does not advance that state. Key/offset ranges are privately constructed and bounded by a 4,096-byte token, 512-byte key and eight attributes.
- Cache payload is reserved within the same 64 KiB recycling ceiling before lazy caller allocation. Allocation failure releases that scalar reservation. Existing NoMemory handling clears pending events and unpublished frames; ordinary parser/child/reset ownership handles the private box.

## Focused coverage in the reviewed source

- `tag.rs:962` checks value revalidation (including changed UTF-8 and references/control/invalid characters), key syntax changes, edition and resource limits, and every character-boundary split. The resumed complete token cannot claim a shape hit.
- `tag.rs:1048` checks fixed entry replacement, bounded payload, shared candidate budget exhaustion and correct fallback records.
- `tag.rs:1092` checks fallible caller-accounted allocation, stable owner across hits and release through the original tracker.
- `tag.rs:1151` exercises actual adapter delivery under a budget that excludes the cache payload: NoMemory publishes no Start, a later funded retry remains terminal, and final ownership balances.
- `adapter_frame.rs:112` compares warmed adapter parsing with ordinary owned parsing for changed values, malformed/incomplete tails, and current namespace binding changes that create expanded-name duplicates, across both name editions and several input chunk sizes.
- `recycling.rs:237` includes shape reservation in the shared retained-capacity check while moving between owned, arena and text paths. Finishing an adapter releases its reservation while retaining the private shape owner.

One nonblocking coverage gap remains: no explicit combined regression warms the private cache and then mutates/recycles public owned-event name strings. Source inspection shows that admission copies only private token/offset data and that recycling never writes this cache, so this is not a discovered poisoning path. Existing key-mutation tests alter input syntax, not returned owners.

## Boundaries

The proof of raw-name uniqueness remains dependent on the existing planner eligibility guard in `lib.rs:2171`; preserve it for custom encodings, DTD/shared tables and entity sources. Hits skip only raw-name duplicate checks; current namespace qualification, expanded duplicates, source/event accounting and semantic limits still execute. Cache admission happens before frame publication; NoMemory clears pending events and inactive output through existing error handling at `lib.rs:1610`.

No Rust unsafe block, atomic operation, public type/API change or source sharing was added by this prototype. `reviewed.patch` saves the exact reviewed four-file diff. Tests/Clippy were running under the author's controller during this source review; this reviewer made no execution or passing-test claim. The prototype's larger retained allocation and speed remain measurements for the parent.

## Source binding

- check02 receipt: `/tmp/oriole-start-tag-shape-checks/check02.json` (SHA256 `ae9d4e84de5fe1817a64cfdf8b59c1e4a3821a33107ccc5df1e024175e40ed82`); all 61 source hashes re-read and matched.
- Reviewed diff SHA256: `e5bd94431430394e5b0fddc0af981daaff444282496d1769b6e193282c7701f6`.
- `crates/oriole/src/lib.rs`: `0ae2bbb595ee15cfcb3d09dbe452d82f6fbb508a125798fe0572c02c56876754`.
- `crates/oriole/src/recycling.rs`: `34271e2d932ee825e5c89cae383c6fa01c0573be96fe9dc2f4bf2b259e198771`.
- `crates/oriole/src/tag.rs`: `c413ff132fee76b1140951220d1bec47029324de63970227a35d6b318ab13276`.
- `crates/oriole/tests/adapter_frame.rs`: `b8836d4f0f33ba590e68368e9b7ed93680c0fcefd192d20ba061a515e3f4315b`.

Final author handoff: `/tmp/oriole-start-tag-shape-checks/summary.json` reports 443 passing tests, strict Clippy, formatting and check completion. The same 61 source hashes still match after that handoff. This review did not execute those checks.

Coverage decision: no additional mutated-public-owner test is required before measurement. The private array is populated exclusively from validated lexical tokens, and returned public strings cannot reach it. If the optimization is retained, a compact combined regression would be useful future hardening, but it should not block the bounded prototype gates or duplicate the existing recycling suite.
