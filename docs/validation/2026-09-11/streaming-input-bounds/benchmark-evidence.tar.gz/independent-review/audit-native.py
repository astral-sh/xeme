"""Saved native timing reconstruction. No target execution."""
from pathlib import Path
import ast,datetime,difflib,gzip,hashlib,json,math,random,statistics
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={}
def pin(p):
 h=sha(p);assert inputs.setdefault(str(p),h)==h
report={'status':'passed','role':'Independent saved reconstruction of root-collected timings. Reviewer authored current runtime/tests and Cgate adaptations; did not collect these elapsed campaigns.','native':{}}
for phase in ['normal','pgo']:
 S=Path('/tmp/oriole-streaming-work-'+phase+'-native-study'); T=Path('/tmp/oriole-ascii-prefix-iterator-'+phase+'-native-study'); D=S/'native-screen'
 old,new=T/'native_screen.py',S/'native_screen.py'
 diff=''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True),new.read_text().splitlines(keepends=True),fromfile=str(old),tofile=str(new)))
 assert diff==(S/'controller.patch').read_text()
 assert (S/'run.py').read_bytes()==(T/'run.py').read_bytes()
 # Entire AST match after only three assignment/string substitutions already reviewed in exact diff.
 def comparable(p):
  tree=ast.parse(p.read_text());tree.body[0].value=ast.Constant('<caption>')
  for n in tree.body:
   if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name):
    name=n.targets[0].id
    if name=='root':n.value=ast.Constant('<study>')
    elif name=='libraries':n.value.values[1]=ast.Constant('<candidate>')
    elif name=='protocol':n.value.values[0]=ast.Constant('<scope>')
  return ast.dump(tree)
 assert comparable(old)==comparable(new)
 p,f,r=map(read,[D/'protocol.json',D/'preflight.json',D/'results.json'])
 assert f['status']==r['status']=='passed' and r['affinity']==[0]
 assert f['protocol_sha256']==r['protocol_sha256']==sha(D/'protocol.json')
 assert r['preflight_sha256']==sha(D/'preflight.json')
 for x in [f,r]: assert x['hashes_before']==x['hashes_after']==p['hashes']
 for q,h in p['hashes'].items(): assert sha(q)==h
 assert len(p['conditions'])==28 and p['pairs']==7 and p['seed']==2026091003
 manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
 fixtures={}
 for project in read(manifest)['projects']:
  entry=next(q for q in project['files'] if q['role']=='input');path=(manifest.parent/entry['path']).resolve();assert sha(path)==entry['sha256'];fixtures[project['name']]=str(path)
 fixtures.update({'generated-rare-declarations':'/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml','generated-entities':'/tmp/oriole-grammar-bench-plain/entities.xml'})
 iterations={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
 expected_conditions=[{'name':name,'input':path,'chunk':chunk,'namespaces':ns,'iterations':iterations[name]} for chunk in [4096,65536] for name,path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False,True])]
 assert p['conditions']==expected_conditions
 assert {c['chunk'] for c in p['conditions']}=={4096,65536}
 assert sum(c['name'].startswith('generated-') for c in p['conditions'])==4
 assert len(f['rows'])==84 and len(r['rows'])==196 and len(r['summary'])==28
 assert len(list(D.glob('worker-*.json')))==672
 ctl=read(S/'controller.json');assert ctl['status']=='passed' and ctl['controller_sha256']==sha(new) and ctl['wrapper_sha256']==sha(S/'run.py')
 for row,(stage,cpu,bound) in zip(ctl['commands'],[('preflight',5,600),('time',0,1200)],strict=True):
  assert row['phase']==stage and row['exit']==0 and row['timeout']==bound
  assert row['command']==['taskset','-c',str(cpu),'python3',str(new),stage]
  assert sha(S/(stage+'-controller.log'))==row['log_sha256']
 ordinal=0; medians={}; obs={}; samples_count=0
 def worker(row,c,pair,engine,cpu,count):
  global ordinal,samples_count
  raw=read(D/f'worker-{ordinal:04d}.json');ordinal+=1
  assert raw=={k:v for k,v in row.items() if k not in ['observations','median_seconds']}
  assert row['condition']==c and row['pair']==pair and row['engine']==engine and row['returncode']==0 and row['stderr']==''
  assert row['command']==['taskset','-c',str(cpu),'/tmp/oriole-grammar-bench-plain/native-driver',p['libraries'][engine]['path'],c['input'],str(c['chunk']),str(count)]+(['namespaces'] if c['namespaces'] else [])
  data=json.loads(row['stdout']);s=data['samples'];samples_count+=len(s)
  assert len(s)==count+1 and [x['iteration'] for x in s]==list(range(count+1))
  assert [x['warmup'] for x in s]==[True]+[False]*count
  assert all(math.isfinite(x['seconds']) and x['seconds']>0 for x in s)
  got=sorted({(x['hash'],x['elements'],x['text_bytes']) for x in s});assert len(got)==1 and row['observations']==[list(x) for x in got]
  if json.dumps(c,sort_keys=True) in obs: assert obs[json.dumps(c,sort_keys=True)]==got
  else: obs[json.dumps(c,sort_keys=True)]=got
  assert got[0][1]>=0 and got[0][2]>=0
  med=statistics.median(x['seconds'] for x in s[1:]);assert med==row['median_seconds']
  return med
 for c in p['conditions']:
  for engine in p['libraries']:
   row=f['rows'][ordinal];worker(row,c,-1,engine,5,1)
 rng=random.Random(p['seed']);jobs=[(c,i) for c in p['conditions'] for i in range(7)];rng.shuffle(jobs)
 for row,(c,pair) in zip(r['rows'],jobs,strict=True):
  order=list(p['libraries']);rng.shuffle(order);assert row['condition']==c and row['pair']==pair and row['order']==order
  for rec,engine in zip(row['processes'],order,strict=True):medians[(json.dumps(c,sort_keys=True),pair,engine)]=worker(rec,c,pair,engine,0,c['iterations'])
 summary=[]
 for c in p['conditions']:
  pairs=[x['pair'] for x in r['rows'] if x['condition']==c]
  ratios={f'{x}_over_{y}':[medians[(json.dumps(c,sort_keys=True),i,x)]/medians[(json.dumps(c,sort_keys=True),i,y)] for i in pairs] for x,y in [('candidate','control'),('candidate','expat'),('control','expat')]}
  summary.append({'condition':c,'paired_ratios':ratios,'median_ratios':{k:statistics.median(v) for k,v in ratios.items()}})
 assert summary==r['summary'] and ordinal==672 and samples_count==106176
 groups={}
 for group in ['real','generated']:
  entries=[q for q in summary if q['condition']['name'].startswith('generated-')==(group=='generated')]
  groups[group]={'conditions':len(entries),'ratios':{k:statistics.geometric_mean(q['median_ratios'][k] for q in entries) for k in entries[0]['median_ratios']},'candidate_faster_than_control':sum(q['median_ratios']['candidate_over_control']<1 for q in entries),'candidate_faster_than_expat':sum(q['median_ratios']['candidate_over_expat']<1 for q in entries)}
 adverse=[{'name':q['condition']['name'],'chunk':q['condition']['chunk'],'namespaces':q['condition']['namespaces'],'ratio':q['median_ratios']['candidate_over_control']} for q in summary if q['median_ratios']['candidate_over_control']>1]
 groups['adverse_conditions']=adverse
 A=read(S/'adaptation.json');B=Path('/tmp/oriole-streaming-work-pgo-study-attempt02')
 assert A['pair_report_sha256']==sha(B/'pair-report.json') and A['pair_freeze_sha256']==sha(B/'pair-freeze.json') and A['source_manifest_sha256']==sha(B/'source.json')
 report['native'][phase]={'preflights':84,'timed_workers':588,'cohorts':196,'measured_samples':105420,'timed_warmups':588,'preflight_samples':168,'total_samples':106176,'groups':groups,'all_conditions':[{'condition':q['condition'],'median_ratios':q['median_ratios']} for q in summary]}
 for q in [S/'controller.patch',S/'adaptation.json',S/'run.py',S/'native_screen.py',S/'controller.json',D/'protocol.json',D/'preflight.json',D/'results.json']:pin(q)

B=Path('/tmp/oriole-streaming-work-pgo-study-attempt02');pair=read(B/'pair-report.json');run=Path(pair['pgo_manifest']['path']).parent
assert sha(B/'source.json')=='e52c4fa16e71a7dcd76864b29509b157a42b6fbe4531f87b68f98395418d5fc3'
assert sha(B/'pair-report.json')=='2a5dfd8ef1ba5fb09b87c290a58d27b3c59ad5e2b07e4cdb91d527b2257059d4'
assert sha(B/'pair-freeze.json')=='c3de58fb747d0d97594c6011ea3f59972167cb29f0770b65d351d8bd594d6058'
source=read(B/'source.json');assert len(source['source_sha256'])==70
for name,h in source['source_sha256'].items():assert sha(Path('/home/dev-user/code/oss/oriole-streaming-input-bounds')/name)==h
control=Path('/tmp/oriole-literal-attribute-check-pgo-study');cpair=read(control/'pair-report.json');crun=Path(cpair['pgo_manifest']['path']).parent
for phase in ['normal','pgo']:
 S=Path('/tmp/oriole-streaming-work-'+phase+'-native-study');p=read(S/'native-screen/protocol.json')
 expected=B/'normal/liboriole_expat.so' if phase=='normal' else run/'use/liboriole_expat.so'
 parent=control/'normal/liboriole_expat.so' if phase=='normal' else crun/'use/liboriole_expat.so'
 assert p['libraries']['candidate']['path']==str(expected) and p['libraries']['control']['path']==str(parent)
 assert sha(expected)==(pair['normal_libraries']['liboriole_expat.so'] if phase=='normal' else pair['pgo_libraries']['use/liboriole_expat.so'])
 assert sha(parent)==(cpair['normal_libraries']['liboriole_expat.so'] if phase=='normal' else cpair['pgo_libraries']['use/liboriole_expat.so'])
 for q in p['hashes']:pin(q)
for q in [B/'source.json',B/'pair-report.json',B/'pair-freeze.json',control/'pair-report.json']:pin(q)
assert math.isclose(report['native']['normal']['groups']['real']['ratios']['candidate_over_control'],.9861850669122444,rel_tol=1e-14)
assert math.isclose(report['native']['normal']['groups']['real']['ratios']['candidate_over_expat'],1.6039131883715148,rel_tol=1e-14)
assert math.isclose(report['native']['normal']['groups']['generated']['ratios']['candidate_over_control'],1.0118261509561532,rel_tol=1e-14)
for q,h in inputs.items():assert sha(q)==h
report['limits']=['One original fixed campaign per phase; no confidence interval or hardware/causal attribution. All28conditions and adverse results retained. Native C and actualPython are separate scopes.','Native legacy driver uses explicit dlopen paths and before/after hashes, but no fresh sameprocess XML_Parse dladdr receipt. PGO training origins are separate.','No parser/compiler/benchmark or producer controller was executed. Build review is not repeated.']
report['input_sha256']=inputs;report['generator_sha256']=sha(__file__)
out=Path(__file__).with_name('native-review.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','sha256':sha(out),'native':{k:{g:v['groups'][g] for g in ['real','generated']} for k,v in report['native'].items()}}))
