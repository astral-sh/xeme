"""Reconstruct fresh three-engine CPython samples without executing workers."""
from pathlib import Path
import os
os.sched_setaffinity(0, {6})
from collections import Counter
import gzip
import hashlib
import json
import math
import random
import statistics

if not __debug__:
    raise RuntimeError('Audit assertions must run')
import sys, ast, difflib
assert len(sys.argv)==2 and sys.argv[1] in ['normal','pgo']
MODE=sys.argv[1]
B=Path('/tmp/oriole-streaming-work-'+MODE+'-python-study-attempt02')
S = B / 'screen'
OUT = Path(__file__).resolve().parent / ('python-'+MODE)
OUT.mkdir(exist_ok=True)
tracked={}
def read(p):
    p=Path(p);raw=p.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(p),value)==value,('changed during audit',str(p))
    return raw
def sha(p):
    p=str(Path(p))
    if p not in tracked:read(p)
    return tracked[p]
def load(p):return json.loads(read(p))
pre = load(S / 'preflight.json')
r = load(S / 'results.json')
build = load(B / 'consumers/build.json')
assert pre['status'] == 'preflight_passed' and r['status'] == 'passed'
assert pre['affinity'] == [3] and r['affinity'] == [0]
assert pre['kind'] == r['kind'] == 'python'
assert r['preflight_sha256'] == sha(S / 'preflight.json')
assert pre['conditions'] == r['conditions']
assert r['preflights'] == pre['preflights'] and r['expected'] == pre['expected']
assert len(pre['processes']) == len(pre['preflights']) == 72
assert len(r['processes']) == len(r['rows']) == 504
assert pre['pairs'] == r['pairs'] == 7
assert pre['seed'] == r['seed'] == 202609104412
assert pre['hashes_before'] == pre['hashes_after'] == r['hashes_before'] == r['hashes_after']
for record in [pre, r]:
    assert not record['hash_errors']
    assert all(sha(p) == h for p, h in record['hashes_before'].items())
assert sha(B / 'python_worker.py') == '4bc0ccffedb5048412b9cfc3638d28dcb30f711891c3784f3fbd3c0eb536ab68'
assert build['status'] == 'passed' and build['adaptations'] is None
assert build['cpython_revision'] == '3bb231a6a5dc02b95658877318bf61501a7209e9'
assert build['source_sha256_before'] == build['source_sha256_after']
assert all(sha(p) == h for p, h in build['source_sha256_before'].items())
engines = ['control', 'candidate', 'expat']
adaptation = load(B / 'adaptation.json')
libraries = {k:v['sha256'] for k,v in adaptation['libraries'].items()}
assert set(build['consumers']) == set(engines)
normalized_commands = {}
for engine, consumer in build['consumers'].items():
    assert sha(consumer['library']) == libraries[engine]
    assert all(sha(p) == h for p, h in consumer['files'].items())
    assert len(consumer['commands']) == 2
    normalized = []
    for module, command in zip(['pyexpat', '_elementtree'], consumer['commands'], strict=True):
        args = command['command']
        assert command['returncode'] == 0 and args[:4] == ['cc', '-shared', '-fPIC', '-O2']
        assert sha(Path(consumer['directory']) / (module + '-build.log')) == command['log_sha256']
        assert args[-4] == consumer['library'] and args[-3]=='-Wl,-rpath,'+consumer['directory'] and args[-2]=='-o' and Path(args[-1]).name.startswith(module+'.cpython-312-')
        assert args[-5].endswith('/Modules/'+('pyexpat.c' if module=='pyexpat' else '_elementtree.c')) and sha(args[-5])==build['source_sha256_before'][args[-5]]
        normalized.append([x.replace(consumer['library'], '<PARSER-LIBRARY>').replace(consumer['directory'], '<CONSUMER-DIR>') for x in args])
    normalized_commands[engine] = normalized
assert all(v == normalized_commands['control'] for v in normalized_commands.values())

manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
iterations = {'vulkan': 3, 'wayland': 16, 'maven': 32, 'batik': 128, 'gtk': 64, 'docbook': 64}
conditions = []
for project in load(manifest)['projects']:
    entry = next(x for x in project['files'] if x['role'] == 'input')
    path = (manifest.parent / entry['path']).resolve()
    assert sha(path) == entry['sha256']
    for chunk in [4096, 65536]:
        for mode in ['elementtree', 'pyexpat-events']:
            conditions.append({'name': project['name'], 'chunk': chunk, 'mode': mode, 'input': str(path), 'iterations': iterations[project['name']]})
assert conditions == r['conditions'] and len(conditions) == 24
assert set(pre['expected'])=={f"{c['name']}/{c['chunk']}/{c['mode']}" for c in conditions}
key = lambda c: f"{c['name']}/{c['chunk']}/{c['mode']}"
condition_map = {key(c): c for c in conditions}
index = {}
counts = Counter()
raw_hashes = {}
for phase, record, rowname in [('preflight', pre, 'preflights'), ('time', r, 'rows')]:
    processes = {p['label']: p for p in record['processes']}
    assert len(processes) == len(record['processes'])
    assert set(processes) == {row['process'] for row in record[rowname]}
    assert [p['label'] for p in record['processes']]==[row['process'] for row in record[rowname]]
    for row in record[rowname]:
        process = processes[row['process']]
        assert process['status'] == 'passed' and process['returncode'] == 0 and process['timeout_seconds'] == 300
        assert 'failure' not in process
        for stream in ['stdout', 'stderr']:
            path = S / process[stream]
            assert sha(path) == process[stream + '_sha256']
            raw_hashes[str(path)] = sha(path)
        assert not gzip.decompress(read(S / process['stderr']))
        raw = json.loads(gzip.decompress(read(S / process['stdout'])))
        assert raw['gc_enabled'] is True and raw['python']==build['python']==record['python_version']
        assert set(raw)=={'identity','python','gc_enabled','samples'}
        assert set(raw['identity'])=={'pyexpat','_elementtree','parser_library','expat_version'}
        assert raw['samples'] == row['samples'] and raw['identity'] == row['identity']
        engine = row['engine']
        consumer = build['consumers'][engine]
        assert raw['identity']['parser_library']['sha256'] == libraries[engine]
        assert raw['identity']['expat_version'] == ('expat_2.8.4' if engine == 'expat' else 'oriole_compat_2.8.4')
        for name in ['pyexpat', '_elementtree', 'parser_library']:
            entry = raw['identity'][name]
            assert consumer['files'][entry['path']] == entry['sha256'] == sha(entry['path'])
        command = process['command']
        assert command[0]=='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3' and len(command)==6
        assert 0<=process['wall_seconds']<300 and (S/process['stdout']).name==process['label']+'-stdout.gz' and (S/process['stderr']).name==process['label']+'-stderr.gz'
        assert command[1:5] == ['-I', '-S', str(B / 'python_worker.py'), '--worker']
        specpath = Path(command[-1])
        assert specpath.parent==S and specpath.name==process['label']+'.json'
        spec = load(specpath)
        raw_hashes[str(specpath)] = sha(specpath)
        c = condition_map[row['key']]
        count = 0 if phase == 'preflight' else c['iterations']
        assert spec == {'input': c['input'], 'input_sha256': sha(c['input']), 'chunk': c['chunk'], 'mode': c['mode'], 'consumer': consumer['directory'], 'library_sha256': libraries[engine], 'iterations': count}
        assert len(raw['samples']) == count + 1
        for i, sample in enumerate(raw['samples']):
            assert set(sample)=={'iteration','warmup','parse_ns','destruction_ns','seconds','output_sha256','output_rows'}
            assert type(sample['parse_ns']) is int and type(sample['destruction_ns']) is int and type(sample['output_rows']) is int
            assert sample['iteration'] == i and sample['warmup'] == (i == 0)
            assert sample['seconds'] == (sample['parse_ns'] + sample['destruction_ns']) / 1e9
            assert sample['seconds'] > 0 and math.isfinite(sample['seconds'])
            assert sample['parse_ns'] >= 0 and sample['destruction_ns'] >= 0
            assert [sample['output_sha256'], sample['output_rows']] == pre['expected'][row['key']]
            counts[phase + ('_warmups' if i == 0 else '_measured')] += 1
        median = statistics.median(s['seconds'] for s in raw['samples'][1:]) if count else None
        assert row['median_seconds'] == median
        if phase == 'time':
            identity = (row['key'], row['pair'], engine)
            assert identity not in index
            index[identity] = median
expected_preflights = [(key(c), engine) for c in conditions for engine in engines]
assert [(row['key'], row['engine']) for row in pre['preflights']] == expected_preflights
rng = random.Random(r['seed'])
jobs = [(condition, pair) for condition in conditions for pair in range(7)]
rng.shuffle(jobs)
order = []
for c, pair in jobs:
    shuffled = engines.copy()
    rng.shuffle(shuffled)
    order.extend((key(c), pair, engine, position) for position, engine in enumerate(shuffled))
assert order == [(row['key'], row['pair'], row['engine'], row['order']) for row in r['rows']]
ratio_pairs = [('candidate', 'control'), ('candidate', 'expat'), ('control', 'expat')]
summaries = []
for c in conditions:
    medians = {engine: [index[key(c), pair, engine] for pair in range(7)] for engine in engines}
    ratios = {a + '_over_' + b: [medians[a][pair] / medians[b][pair] for pair in range(7)] for a, b in ratio_pairs}
    summaries.append({'condition': c, 'process_pair_medians_seconds': medians, 'paired_ratios': ratios,
                      'median_ratios': {name: statistics.median(v) for name, v in ratios.items()}})
assert summaries == r['summary']
assert counts == {'preflight_warmups': 72, 'time_warmups': 504, 'time_measured': 25788}
groups = {}
for group in ['all', 'elementtree', 'pyexpat-events']:
    selected = [s for s in summaries if group == 'all' or s['condition']['mode'] == group]
    groups[group] = {}
    for a, b in ratio_pairs:
        name = a + '_over_' + b
        values = [s['median_ratios'][name] for s in selected]
        geo = math.exp(sum(math.log(v) for v in values)/len(values))
        actual = {'geomean': geo, 'below_one': sum(v < 1 for v in values), 'conditions': len(values)}
        groups[group][name] = actual
project_groups = {}
for project in iterations:
    selected = [s for s in summaries if s['condition']['name'] == project]
    project_groups[project] = {a + '_over_' + b: math.exp(statistics.mean(math.log(s['median_ratios'][a + '_over_' + b]) for s in selected)) for a, b in ratio_pairs}

# Independently verify current protocol adaptation, retaining unchanged worker source proof.
T=Path('/tmp/oriole-literal-attribute-'+MODE+'-python-study')
P=Path('/tmp/oriole-streaming-work-'+MODE+'-python-study')
protocol_path=Path('/tmp/oriole-literal-attribute-python-protocol-independent-review/review.json')
assert sha(protocol_path)=='ec34d8dc61f63f6ede20ee68d08c6491000bc39b86943eb208c81d83433c3de7'
for filename in ['build_consumers.py','python_worker.py']:
    assert read(B/filename)==read(T/filename)==read(P/filename)
    assert read(B/(filename+'.patch'))==b''
assert read(B/'run.py')==read(P/'run.py') and read(B/'run.py.patch')==b''
assert read(P/'consumer_screen.py')==read(T/'consumer_screen.py')
for oldpath,newpath,patchpath in [(T/'run.py',P/'run.py',P/'run.py.patch'),(P/'consumer_screen.py',B/'consumer_screen.py',B/'consumer_screen.py.patch')]:
    diff=''.join(difflib.unified_diff(read(oldpath).decode().splitlines(keepends=True),read(newpath).decode().splitlines(keepends=True),fromfile=str(oldpath),tofile=str(newpath)))
    assert diff==read(patchpath).decode()
oldrun=read(T/'run.py').decode()
newrun=read(B/'run.py').decode()
assert oldrun.replace("'taskset', '-c', '4'", "'taskset', '-c', '3'").replace('/home/dev-user/code/oss/oriole-literal-attribute-check/include','/home/dev-user/code/oss/oriole-streaming-input-bounds/include').replace('compilation and canonical preflights on CPU4','compilation and canonical preflights on CPU3')==newrun
class ScreenNormalizer(ast.NodeTransformer):
    def visit_Constant(self,node):
        if isinstance(node.value,str) and (node.value.startswith('Matched ') or node.value.startswith('Shared host ') or node.value.startswith('Expected frozen control, ') or node.value.startswith('Preflights require CPU')):
            return ast.Constant('<reviewed-caption>')
        return node
oldscreen=ast.parse(read(T/'consumer_screen.py'))
newtext=read(B/'consumer_screen.py').decode()
assert newtext.count('args.phase == "prepare" and os.sched_getaffinity(0) != {3}')==1
newscreen=ast.parse(newtext.replace('args.phase == "prepare" and os.sched_getaffinity(0) != {3}','args.phase == "prepare" and os.sched_getaffinity(0) != {4}'))
assert ast.dump(ScreenNormalizer().visit(oldscreen))==ast.dump(ScreenNormalizer().visit(newscreen))
for name,h in adaptation['files'].items():assert sha(B/name)==h
for name,h in adaptation['parent_files'].items():assert sha(P/name)==h
for entry in [adaptation['candidate_source_manifest'],adaptation['candidate_pair_freeze']]:assert sha(entry['path'])==entry['sha256']
assert adaptation['candidate_source_manifest']['sha256']=='e52c4fa16e71a7dcd76864b29509b157a42b6fbe4531f87b68f98395418d5fc3'
assert adaptation['candidate_pair_freeze']['sha256']=='c3de58fb747d0d97594c6011ea3f59972167cb29f0770b65d351d8bd594d6058'
source=load(adaptation['candidate_source_manifest']['path']);assert len(source['source_sha256'])==70
for name,h in source['source_sha256'].items():assert sha(Path('/home/dev-user/code/oss/oriole-streaming-input-bounds')/name)==h
pairdir=Path('/tmp/oriole-streaming-work-pgo-study-attempt02');parentdir=Path('/tmp/oriole-literal-attribute-check-pgo-study')
for engine,directory in [('candidate',pairdir),('control',parentdir)]:
    pair=load(directory/'pair-report.json');run=Path(pair['pgo_manifest']['path']).parent
    lib=directory/'normal/liboriole_expat.so' if MODE=='normal' else run/'use/liboriole_expat.so'
    assert adaptation['libraries'][engine]['path']==str(lib)
    assert libraries[engine]==(pair['normal_libraries']['liboriole_expat.so'] if MODE=='normal' else pair['pgo_libraries']['use/liboriole_expat.so'])
native=load(Path(__file__).with_name('native-review.json'));assert native['status']=='passed'
native_protocol=load('/tmp/oriole-streaming-work-'+MODE+'-native-study/native-screen/protocol.json')
assert adaptation['libraries']==native_protocol['libraries']
for engine in engines:
    assert sha(adaptation['libraries'][engine]['path'])==libraries[engine]
    assert sha(build['consumers'][engine]['library'])==libraries[engine]
pyexpat_sources=[h for path,h in build['source_sha256_before'].items() if path.endswith('/Modules/pyexpat.c')]
assert pyexpat_sources==['fd679a16f36304444af11953ad276d4493f2044f904a39b8fdf028c6f7def8a0']
# Failed first preparation executed the build, then stopped at CPU guard before reading its build or running any parser.
first=Path('/tmp/oriole-streaming-work-normal-python-study');failure=load(first/'prepare-controller.json')
assert failure['status']=='incomplete' and [j['exit'] for j in failure['jobs']]==[0,2]
assert failure['controller_sha256']==sha(first/'run.py') and not (first/'screen').exists()
for job in failure['jobs']:
    assert sha(first/(job['label']+'-controller.log'))==job['log_sha256']
assert read(first/'preflight-controller.log').decode().endswith('error: Preflights require CPU4\n')
assert load(first/'consumers/build.json')['status']=='passed'
assert 'if args.phase == "prepare" and os.sched_getaffinity(0) != {4}:' in read(first/'consumer_screen.py').decode()
assert not (Path('/tmp/oriole-streaming-work-pgo-python-study')/'prepare-controller.json').exists()
# Controller bounds, completed receipts and exact retained stream inventories.
phase_jobs={}
for filename,wanted in [('prepare-controller.json',['build','preflight']),('time-controller.json',['time'])]:
    controller=load(B/filename)
    assert controller['status']=='passed' and controller['controller_sha256']==sha(B/'run.py')
    assert [j['label'] for j in controller['jobs']]==wanted
    for job in controller['jobs']:
        label=job['label'];phase_jobs[label]=job
        assert job['exit']==0 and 'error' not in job
        assert job['timeout_seconds']==(1200 if label=='time' else 600)
        assert 0<job['end']-job['start']<job['timeout_seconds']
        assert sha(B/(label+'-controller.log'))==job['log_sha256']
        assert job['command'][:3]==['taskset','-c','0' if label=='time' else '3']
        assert job['command'][3:6]==['/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3','-I','-S']
        if label!='build':
            assert job['command'][6:]==[str(B/'consumer_screen.py'),'--phase','time' if label=='time' else 'prepare','--kind','python','--build',str(B/'consumers/build.json'),'--input',str(manifest),'--output',str(S)]
        else:
            assert job['command'][6:]==[str(B/'build_consumers.py'),'--library',adaptation['libraries']['candidate']['path'],'--reference',adaptation['libraries']['control']['path'],'--expat',adaptation['libraries']['expat']['path'],'--source','/home/dev-user/.cache/oriole/upstream/cpython-3.12.13','--header',str(Path(adaptation['header']['path']).parent),'--output',str(B/'consumers')]
assert phase_jobs['build']['end']<=phase_jobs['preflight']['start']<phase_jobs['preflight']['end']<=phase_jobs['time']['start']
for phase, record, phase_rows in [('prepare',pre,pre['preflights']),('time',r,r['rows'])]:
    for row in phase_rows:
        pair=-1 if phase=='prepare' else row['pair']
        assert row['pair']==pair
        assert row['process']==row['key'].replace('/','-')+'-'+row['engine']+'-'+str(pair)+'-0'
assert set(raw_hashes)=={str(p) for p in S.iterdir() if p.is_file() and p.name not in ['preflight.json','results.json']}
assert len(raw_hashes)==1728 and sum(counts.values())==26364
assert load(B/'preflight-controller.log')=={'status':'preflight_passed','kind':'python','preflights':72,'timed_rows':0}
assert load(B/'time-controller.log')=={'status':'passed','kind':'python','preflights':72,'timed_rows':504}
regressions=[{'condition':s['condition'],'ratio':s['median_ratios']['candidate_over_control']} for s in summaries if s['median_ratios']['candidate_over_control']>1]
for path,h in list(tracked.items()):assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h,('changed after audit',path)
def save(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
details={'input_hashes':tracked,'raw_hashes':raw_hashes,'conditions':summaries,'regressions':regressions,'normalized_build_commands':normalized_commands,'project_groups':project_groups}
(OUT/'details.json.gz').write_bytes(gzip.compress(json.dumps(details,sort_keys=True,separators=(',',':')).encode(),mtime=0))
review={'status':'passed','mode':MODE,'role':'Independent saved reconstruction of root-collected actualPython timings. Reviewer authored current runtime/tests and Cgate adapters; did not collect this elapsed campaign. Current protocol adaptation is checked here; unchanged worker source proof ec34d8dc reused by hash.','unchanged_worker_protocol_review_sha256':sha(protocol_path),'consumer_scope':'Unmodified CPython3.12.13 pyexpat.c fd679a16; separate strict802 gate uses cleanup-patched consumer1c3cf2ee. No benchmark inference about patched consumer timing.','preparation_history':'First normal build succeeded, preflight guard rejected CPU3 expectingCPU4 before parser execution; original failure/logs retained. Both attempt02 variants used corrected preparationCPU3 guard with unchanged CPU0 timing and original bounds. OriginalPGO prepared-only sibling not executed.','source_manifest_sha256':adaptation['candidate_source_manifest']['sha256'],'library_bindings':adaptation['libraries'],'preflight_sha256':sha(S/'preflight.json'),'results_sha256':sha(S/'results.json'),'build_sha256':sha(B/'consumers/build.json'),'counts':dict(counts),'workers':{'preflight':72,'timed':504,'cohorts':168,'raw_streams_and_specs':1728,'same_process_origins':576,'extension_builds':6},'unchanged_input_files':len(tracked),'groups':groups,'regressions':regressions,'retained_conditions':24,'findings':[],'limits':['Standalone normal and PGO cohorts must be interpreted separately; no cross-cohort speedup arithmetic.','Both consumers enable namespace processing. Timing includes parser construction/feed/close, Python callbacks/tree creation and explicit result destruction; imports, input reads, canonical comparison and explicit gc.collect are outside. Automatic GC remains enabled.','Canonical pyexpat observation combines adjacent text callbacks and is separate from strict compatibility. XML_Parse origin is attested in every worker through its loaded extension; full application behavior and host cache/frequency effects are outside this fixed study.','No target, compiler or producer controller was executed in this audit. Runtime/test authorship is disclosed.'],'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'details_sha256':hashlib.sha256((OUT/'details.json.gz').read_bytes()).hexdigest()}
save('review.json',review)
print(json.dumps({'status':'passed','mode':MODE,'groups':groups,'unchanged_input_files':len(tracked),'review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest()},indent=2))
