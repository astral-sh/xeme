"""Combine completed saved audits and independently check the README's six-row subset."""
from pathlib import Path
import hashlib,json,math,statistics,subprocess
root=Path(__file__).parent
repo=Path('/home/dev-user/code/oss/oriole-streaming-input-bounds')
doc=repo/'docs/validation/2026-09-11/streaming-input-bounds'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
inputs={}
def pin(p):inputs[str(p)]=sha(p)
expected={'native-review.json':'423fb4dc4df842d1c0d7772f64436ee903bb09e20268ec64f9d1ccc0f57a5a4e','python-normal/review.json':'f17d0f6453f19e43b95c1ae0539ae70509b50c977c2efa7fd4a386315649fe93','python-pgo/review.json':'35e7192c520678e4bcd3c83c2529495e0774d7adc1ce7d7dcc96d112c822b2b5'}
for name,h in expected.items():assert sha(root/name)==h;pin(root/name)
native=load(root/'native-review.json');py={p:load(root/f'python-{p}/review.json') for p in ['normal','pgo']}
assert native['status']=='passed' and all(p['status']=='passed' for p in py.values())
seqpath=Path('/tmp/oriole-streaming-work-elapsed-sequence.json');seq=load(seqpath);pin(seqpath)
assert seq['status']=='passed' and len(seq['commands'])==4
for row,(phase,kind) in zip(seq['commands'], [('normal','native'),('pgo','native'),('normal','python'),('pgo','python')],strict=True):
    d=Path('/tmp/oriole-streaming-work-'+phase+'-'+kind+'-study'+('-attempt02' if kind=='python' else ''))
    assert row['command']==['python3',str(d/'run.py')]+(['time'] if kind=='python' else []) and row['exit']==0
    ctlpath=d/('controller.json' if kind=='native' else 'time-controller.json');ctl=load(ctlpath);pin(ctlpath)
    for job in ctl['commands' if kind=='native' else 'jobs']:
        assert row['start']<=job['start']<job['end']<=row['end']
for a,b in zip(seq['commands'],seq['commands'][1:]):assert a['end']<=b['start']
# Display subset:84 worker medians,42 pair ratios,18 formatted data cells.
tabledata=load(doc/'readme-benchmark.json');data=load(tabledata['source']);assert data['status']=='passed' and sha(tabledata['source'])==tabledata['source_sha256'];pin(tabledata['source'])
rows=[];table=['| Project XML | Oriole (PGO) | Expat (PGO) | Oriole / Expat |','| --- | ---: | ---: | ---: |']
for name,label in [('vulkan','Vulkan registry'),('wayland','Wayland protocol'),('maven','Maven POM'),('batik','Batik SVG'),('gtk','GTK UI'),('docbook','DocBook XSL')]:
    cohorts=sorted([r for r in data['rows'] if r['condition']['name']==name and r['condition']['chunk']==4096 and not r['condition']['namespaces']],key=lambda r:r['pair'])
    assert len(cohorts)==7 and [r['pair'] for r in cohorts]==list(range(7))
    medians={e:[] for e in ['candidate','expat']};paired=[]
    for cohort in cohorts:
        vals={}
        for engine in medians:
            proc=next(p for p in cohort['processes'] if p['engine']==engine);samples=json.loads(proc['stdout'])['samples'];assert proc['returncode']==0 and not proc['stderr']
            assert samples[0]['warmup'] and all(not s['warmup'] for s in samples[1:])
            med=statistics.median(s['seconds'] for s in samples[1:]);assert med==proc['median_seconds'];medians[engine].append(med);vals[engine]=med
        paired.append(vals['candidate']/vals['expat'])
    ratio=statistics.median(paired);row={'name':name,'label':label,'chunk':4096,'namespaces':False,'process_medians_seconds':medians,'paired_ratios':paired,'oriole_ms':statistics.median(medians['candidate'])*1000,'expat_ms':statistics.median(medians['expat'])*1000,'ratio':ratio};rows.append(row)
    table.append(f"| {label} | {row['oriole_ms']:.3f} ms | {row['expat_ms']:.3f} ms | {ratio:.2f}× |")
assert rows==tabledata['rows'];table='\n'.join(table);text=(repo/'README.md').read_text();assert table in text
parent=subprocess.check_output(['git','show','HEAD:README.md'],cwd=repo,text=True)
assert [s for s in parent.splitlines() if s.startswith('#')]==[s for s in text.splitlines() if s.startswith('#')]
assert [s for s in parent.splitlines() if s.startswith('>')]==[s for s in text.splitlines() if s.startswith('>')]
assert parent[parent.index('## License'):]==text[text.index('## License'):]
for p in [doc/'readme-benchmark.py',doc/'readme-benchmark.json',root/'audit-native.py',root/'audit-python.py']:pin(p)
report={'status':'passed','role':'Independent saved numerical review of root-collected four campaigns; reviewer authored current parser policy/tests but did not collect timings. Current protocol adaptations and raw data were reviewed without executing producers or targets.','source_manifest_sha256':'e52c4fa16e71a7dcd76864b29509b157a42b6fbe4531f87b68f98395418d5fc3','native':native['native'],'python':{p:{k:v[k] for k in ['groups','regressions','library_bindings','consumer_scope','preparation_history','counts','workers','results_sha256']} for p,v in py.items()},'counts':{'native_preflights':168,'native_timed_workers':1176,'python_preflights':144,'python_timed_workers':1008,'total_workers':2496,'total_samples_including_preflights_and_warmups':265080},'readme_subset':{'conditions':6,'worker_medians':84,'paired_ratios':42,'formatted_data_cells':18,'table':table,'headings_warning_license':'Exact equality with worktree HEAD observed; receipt binds numerical subset, not subsequent mainREADME edits.'},'interpretation':'The policy removes arbitrary lifetime-stream rejection while native and actualPython real-project timings remain close to the preceding accepted control. The fixed PGO aggregate remains slower than Expat:1.37540x native and1.13775x actualPython. This does not meet the faster-than-Expat objective. Generated controls and every per-condition regression remain recorded.','limits':native['limits']+["Python uses unmodified CPython3.12.13 consumer source; strict802 gate separately uses cleanup-patched pyexpat. Worker canonicalization coalesces adjacent text callbacks and does not replace strict compatibility.","Each Python worker proves loaded extension paths/hashes and the pyexpat extension's XML_Parse dladdr library; no all-symbol origin claim.","One original fixed elapsed campaign per mode/consumer, no significance interval or causal attribution. No cross-campaign speedup multiplication."],'input_sha256':inputs,'generator_sha256':sha(__file__)}
p=root/'review.json';p.write_text(json.dumps(report,indent=2)+'\n');print(str(p),sha(p))
