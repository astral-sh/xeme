# Independent end-handler lifecycle oracle: source review before execution

The oracle owns 38 new logical cases / 114 parser executions, separate from the
original publication matrix. Three documents (namespace rebinding/restoration,
Unicode names, whitespace end-tag fallback) cross UTF8/UTF16LE, one-byte/full
feeds, and plain/suspend/suspend-plus-handler-mutation. Two extra cases use a
4096-byte opening name and closing name sharing 4095 bytes then differing, with
one-byte/full feeds. All cases disable reparse deferral before parsing.

The expected successful namespace end order is p1:b, p1:a, restored p0:c,
u2:e/u2:d, then restored u0:f/u0:r. End callbacks call DefaultCurrent. The first
end in suspension cases stops resumably; mutation also switches user data, the
end handler and default handler. DefaultCurrent is called after the stop; the
original end-name pointer is read again while its callback is still active.
Resume must occur, and later end callbacks must reach the replacement handler.

All callback outputs, raw bytes, raw input contexts, byte index/count,
line/column, parsing status, stop/parse/resume return codes and final error codes
are retained. Namespace, start, default and end callbacks are all represented.
Candidate/baseline comparisons use full records without normalization. Expat
differences are retained separately and do not relax candidate/baseline checks.
Independent expected statuses require successful valid inputs and tag mismatch
(error 7) for invalid common-prefix inputs.

Every C function receives an explicit ctypes signature matching the LP64 public
C interface. String memory is copied during callbacks. All callback objects are
retained through parser free. Parser creation and every setup operation occur
inside try/finally, so partial setup failures also free the parser. Callback
exceptions are captured with tracebacks and abort parsing; they never escape
silently through ctypes. Inputs remain live throughout XML_Parse.

Each engine runs in a separate process. Before any XML API call, the worker
checks the requested library SHA256 and uses same-process dladdr on all 21
called XML symbols to verify resolved library path and SHA256. It verifies the
library hash again afterward. Reports are saved before loading and after every
case, preserving incomplete/failing attempts. Original library/runtime/source
files are never edited.

The controller and each worker use CPU1. Each worker starts a new process group
with a 90-second wait bound; timeout, controller SIGINT/SIGTERM and finalization
kill that group and wait. The controller retains commands, exit codes, stdout,
stderr and hashes. No elapsed-time samples or performance claims are collected.

The public C interface offers no configurable maximum-token-byte setter. Its
default token limit is 16MiB. This modest lifecycle matrix has no exact-limit C
claim and does not create huge 16MiB names merely to reach that boundary. The
candidate's separate Rust focused tests own configurable token-limit coverage.

Bounds: 38 cases per engine, three engines, 114 parser lifetimes, largest raw
input 8197 bytes, at most two resume calls per parse, bounded callback attribute
iteration, no external entities, threads, network calls, file reads from parser
input or recursive parser operations. These are functional observations only;
they do not demonstrate absence of quadratic work or replace sanitizer gates.
