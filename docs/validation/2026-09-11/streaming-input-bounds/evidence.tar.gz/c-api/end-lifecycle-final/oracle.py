"""Bounded C end-handler lifecycle oracle; load one pinned library per process."""
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback

ROOT = Path(__file__).resolve().parent
LIBRARIES = {
    'candidate': ('/tmp/oriole-streaming-work-pgo-study-attempt02/pgo/runs/run-psjiwn9z/use/liboriole_expat.so', '8e12c1819a58a66ae5530a53433dd08de44921c94a2b39a6282358dfd33c0d1e'),
    'baseline': ('/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.so', '8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a'),
    'expat': ('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4', '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'),
}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def cases():
    documents = {
        'namespace_restore': '<r xmlns="u0" xmlns:p="p0">\n<p:a xmlns:p="p1"><p:b></p:b></p:a>\n<p:c></p:c><d xmlns="u2"><e></e></d><f></f></r>',
        'unicode_names': '<r><é><雪></雪></é><a·b></a·b></r>',
        'whitespace_fallback': '<r>\n<a></a ><b></b\r\n></r >',
    }
    result = []
    for label, xml in documents.items():
        for encoding in ['utf8', 'utf16le']:
            raw = xml.encode('utf-8') if encoding == 'utf8' else b'\xff\xfe' + xml.encode('utf-16le')
            for chunk in [1, len(raw)]:
                for mode in ['plain', 'suspend', 'suspend_mutate']:
                    result.append({'id': f'{label}-{encoding}-chunk{chunk}-{mode}', 'document': label, 'encoding': encoding, 'chunk': chunk, 'mode': mode, 'raw': raw, 'valid': True})
    name = 'n' * 4096
    raw = ('<' + name + '></' + name[:-1] + 'x>').encode()
    for chunk in [1, len(raw)]:
        result.append({'id': f'long_common_prefix_mismatch-utf8-chunk{chunk}', 'document': 'long_common_prefix_mismatch', 'encoding': 'utf8', 'chunk': chunk, 'mode': 'plain', 'raw': raw, 'valid': False})
    assert len(result) == 38
    return result

P = C.c_void_p
S = C.c_char_p
I = C.c_int
U = C.c_ubyte
START = C.CFUNCTYPE(None, P, P, C.POINTER(S))
END = C.CFUNCTYPE(None, P, P)
TEXT = C.CFUNCTYPE(None, P, P, I)
NSSTART = C.CFUNCTYPE(None, P, S, S)
NSEND = C.CFUNCTYPE(None, P, S)

class ParsingStatus(C.Structure):
    _fields_ = [('parsing', I), ('finalBuffer', U)]

class DlInfo(C.Structure):
    _fields_ = [('filename', S), ('base', P), ('symbol', S), ('address', P)]

SIGNATURES = {
    'XML_ParserCreateNS': ([S, C.c_char], P),
    'XML_ParserFree': ([P], None),
    'XML_SetUserData': ([P, P], None),
    'XML_SetStartElementHandler': ([P, START], None),
    'XML_SetEndElementHandler': ([P, END], None),
    'XML_SetStartNamespaceDeclHandler': ([P, NSSTART], None),
    'XML_SetEndNamespaceDeclHandler': ([P, NSEND], None),
    'XML_SetDefaultHandler': ([P, TEXT], None),
    'XML_SetReturnNSTriplet': ([P, I], None),
    'XML_SetReparseDeferralEnabled': ([P, U], U),
    'XML_DefaultCurrent': ([P], None),
    'XML_Parse': ([P, S, I, I], I),
    'XML_StopParser': ([P, U], I),
    'XML_ResumeParser': ([P], I),
    'XML_GetErrorCode': ([P], I),
    'XML_GetCurrentByteIndex': ([P], C.c_long),
    'XML_GetCurrentByteCount': ([P], I),
    'XML_GetCurrentLineNumber': ([P], C.c_ulong),
    'XML_GetCurrentColumnNumber': ([P], C.c_ulong),
    'XML_GetInputContext': ([P, C.POINTER(I), C.POINTER(I)], P),
    'XML_GetParsingStatus': ([P, C.POINTER(ParsingStatus)], None),
}

def execute(lib, case):
    raw = case['raw']
    output = {k:v for k,v in case.items() if k != 'raw'}
    output.update({'input_hex': raw.hex(), 'input_sha256': hashlib.sha256(raw).hexdigest(), 'events': [], 'calls': [], 'callback_errors': [], 'invariants': {}, 'freed': False})
    parser = None
    keepalive = []
    acted = False

    def text(pointer):
        return C.string_at(pointer).decode('utf-8') if pointer else None

    def position():
        offset, size = I(-1), I(-1)
        context = lib.XML_GetInputContext(parser, C.byref(offset), C.byref(size))
        status = ParsingStatus()
        lib.XML_GetParsingStatus(parser, C.byref(status))
        count = lib.XML_GetCurrentByteCount(parser)
        answer = {'byte_index': lib.XML_GetCurrentByteIndex(parser), 'byte_count': count, 'line': lib.XML_GetCurrentLineNumber(parser), 'column': lib.XML_GetCurrentColumnNumber(parser), 'parsing': status.parsing, 'final_buffer': status.finalBuffer, 'context_present': bool(context)}
        if context:
            assert 0 <= offset.value <= size.value <= len(raw), (offset.value, size.value, len(raw))
            content = C.string_at(context, size.value)
            answer.update({'context_offset': offset.value, 'context_size': size.value, 'context_hex': content.hex(), 'token_hex': content[offset.value:offset.value + count].hex()})
        return answer

    def event(kind, arg, **fields):
        output['events'].append({'kind': kind, 'user_data': arg, **fields, 'position': position()})

    def callback(kind, function):
        def wrapped(*args):
            try:
                function(*args)
            except BaseException:
                output['callback_errors'].append(traceback.format_exc())
                if parser:
                    lib.XML_StopParser(parser, 0)
        result = kind(wrapped)
        keepalive.append(result)
        return result

    def default(label):
        return callback(TEXT, lambda arg, pointer, count: event('default_' + label, arg, text_hex=C.string_at(pointer, count).hex()))

    def start(arg, name, attrs):
        values = []
        at = 0
        while attrs[at] is not None:
            assert at < 100
            values.append([attrs[at].decode(), attrs[at + 1].decode()])
            at += 2
        event('start', arg, name=text(name), attributes=values)

    def end(label, arg, pointer):
        nonlocal acted
        before = text(pointer)
        event('end_' + label, arg, name=before)
        lib.XML_DefaultCurrent(parser)
        if not acted and case['mode'] != 'plain':
            acted = True
            if case['mode'] == 'suspend_mutate':
                lib.XML_SetUserData(parser, P(0xB))
                lib.XML_SetEndElementHandler(parser, end_b)
                lib.XML_SetDefaultHandler(parser, default_b)
                event('handlers_mutated', arg, new_user_data=0xB)
            output['calls'].append({'operation': 'stop_inside_end', 'return': lib.XML_StopParser(parser, 1), 'position': position()})
            lib.XML_DefaultCurrent(parser)
            after = text(pointer)
            event('end_pointer_after_stop', arg, before=before, after=after)
            assert before == after

    try:
        # Every resource creation/setup step is protected by this finally block.
        parser = lib.XML_ParserCreateNS(None, b'|')
        assert parser, 'parser allocation failed'
        start_cb = callback(START, start)
        end_a = callback(END, lambda arg, name: end('a', arg, name))
        end_b = callback(END, lambda arg, name: end('b', arg, name))
        default_a, default_b = default('a'), default('b')
        ns_start = callback(NSSTART, lambda arg, prefix, uri: event('namespace_start', arg, prefix=prefix.decode() if prefix else None, uri=uri.decode() if uri else None))
        ns_end = callback(NSEND, lambda arg, prefix: event('namespace_end', arg, prefix=prefix.decode() if prefix else None))
        lib.XML_SetUserData(parser, P(0xA))
        lib.XML_SetStartElementHandler(parser, start_cb)
        lib.XML_SetEndElementHandler(parser, end_a)
        lib.XML_SetDefaultHandler(parser, default_a)
        lib.XML_SetStartNamespaceDeclHandler(parser, ns_start)
        lib.XML_SetEndNamespaceDeclHandler(parser, ns_end)
        lib.XML_SetReturnNSTriplet(parser, 1)
        output['deferral_disabled_return'] = lib.XML_SetReparseDeferralEnabled(parser, 0)
        assert output['deferral_disabled_return'] == 1
        status = 1
        for at in range(0, len(raw), case['chunk']):
            block = raw[at:at + case['chunk']]
            status = lib.XML_Parse(parser, block, len(block), int(at + len(block) == len(raw)))
            output['calls'].append({'operation': 'parse', 'input_offset': at, 'input_length': len(block), 'return': status, 'error': lib.XML_GetErrorCode(parser)})
            resumes = 0
            while status == 2:
                resumes += 1
                assert resumes <= 2, 'unexpected repeated suspension'
                status = lib.XML_ResumeParser(parser)
                output['calls'].append({'operation': 'resume', 'return': status, 'error': lib.XML_GetErrorCode(parser)})
            if status == 0:
                break
        output['final'] = {'return': status, 'error': lib.XML_GetErrorCode(parser), 'position': position()}
        expected = (1, 0) if case['valid'] else (0, 7)
        output['invariants']['expected_final_status'] = (status, output['final']['error']) == expected
        output['invariants']['no_callback_errors'] = not output['callback_errors']
        output['invariants']['action_exercised'] = acted == (case['mode'] != 'plain')
        output['invariants']['resume_exercised'] = any(x['operation'] == 'resume' for x in output['calls']) == (case['mode'] != 'plain')
        output['invariants']['replacement_end_exercised'] = any(x['kind'] == 'end_b' for x in output['events']) == (case['mode'] == 'suspend_mutate')
        if case['document'] == 'namespace_restore':
            names = [x['name'] for x in output['events'] if x['kind'].startswith('end_') and 'name' in x]
            output['invariants']['namespace_restoration_names'] = names == ['p1|b|p', 'p1|a|p', 'p0|c|p', 'u2|e', 'u2|d', 'u0|f', 'u0|r']
        if not all(output['invariants'].values()):
            output['invariant_error'] = 'One or more independent expected lifecycle invariants failed'
    except BaseException:
        output['harness_error'] = traceback.format_exc()
    finally:
        if parser:
            lib.XML_ParserFree(parser)
            output['freed'] = True
        # keepalive is intentionally still in scope through XML_ParserFree.
        output['retained_callback_count_through_free'] = len(keepalive)
    return output

def main():
    engine = sys.argv[1]
    library, expected = LIBRARIES[engine]
    target = ROOT / (engine + '.json')
    report = {'engine': engine, 'library': library, 'expected_sha256': expected, 'interpreter': sys.executable, 'affinity': sorted(os.sched_getaffinity(0)), 'command': sys.argv, 'status': 'incomplete', 'dladdr': {}, 'cases': []}
    def save():
        target.write_text(json.dumps(report, indent=2) + '\n')
    save()
    try:
        assert report['affinity'] == [3]
        report['before_sha256'] = sha(library)
        assert report['before_sha256'] == expected
        lib = C.CDLL(library, mode=os.RTLD_LOCAL | os.RTLD_NOW)
        process = C.CDLL(None)
        process.dladdr.argtypes = [P, C.POINTER(DlInfo)]
        process.dladdr.restype = I
        # Verify every target function's actual binding before calling any XML API.
        for name, (arguments, result) in SIGNATURES.items():
            function = getattr(lib, name)
            function.argtypes, function.restype = arguments, result
            info = DlInfo()
            assert process.dladdr(C.cast(function, P), C.byref(info)) == 1
            resolved = str(Path(os.fsdecode(info.filename)).resolve())
            assert resolved == str(Path(library).resolve()), (name, resolved)
            assert sha(resolved) == expected
            report['dladdr'][name] = {'path': resolved, 'sha256': expected, 'symbol': os.fsdecode(info.symbol) if info.symbol else None}
        save()
        for case in cases():
            row = execute(lib, case)
            report['cases'].append(row)
            save()
            print(json.dumps({'engine': engine, 'case': row['id'], 'harness_error': row.get('harness_error'), 'invariants': row['invariants']}), flush=True)
        report['status'] = 'passed' if len(report['cases']) == 38 and all(not x.get('harness_error') and not x.get('invariant_error') and x['freed'] for x in report['cases']) else 'failed'
    except BaseException:
        report['error'] = traceback.format_exc()
        report['status'] = 'failed'
    finally:
        report['after_sha256'] = sha(library)
        report['library_unchanged'] = report.get('before_sha256') == report['after_sha256'] == expected
        if not report['library_unchanged']:
            report['status'] = 'failed'
        save()
    raise SystemExit(0 if report['status'] == 'passed' else 1)

if __name__ == '__main__':
    main()
