/* Separate end-tag allocation/lifecycle probe; original allocator gate included unchanged. */
#define _GNU_SOURCE
#define main original_allocation_main
#include "original-allocations.c"
#undef main
#include <dlfcn.h>
#include <limits.h>

typedef struct { XML_Parser parser; int mode, stopped, end_count, events, ns_count; } EndContext;
static size_t scenario;
static void hex_bytes(const void *input, size_t length) {
    const unsigned char *value = input;
    putchar('"');
    for (size_t i = 0; i < length; i++) printf("%02x", value[i]);
    putchar('"');
}
static void event(EndContext *context, const char *kind, const char *value, size_t length) {
    context->events++;
    XML_Parser p = context->parser;
    int offset = 0, size = 0;
    const char *input = XML_GetInputContext(p, &offset, &size);
    const int count = XML_GetCurrentByteCount(p);
    printf("{\"scenario\":%zu,\"event\":\"%s\",\"value\":", scenario, kind);
    if (value) hex_bytes(value, length); else printf("null");
    printf(",\"position\":[%ld,%d,%lu,%lu],\"raw\":", (long)XML_GetCurrentByteIndex(p), count,
        (unsigned long)XML_GetCurrentLineNumber(p), (unsigned long)XML_GetCurrentColumnNumber(p));
    if (input) { assert(offset >= 0 && offset <= size && count >= 0 && count <= size-offset); hex_bytes(input+offset,(size_t)count); }
    else printf("null");
    printf("}\n");
}
static void end_default(void *data, const XML_Char *value, int length) {
    assert(length >= 0);event(data, "default", value, (size_t)length);
}
static void replacement_end(void *data, const XML_Char *name) {
    EndContext *context = data; context->end_count++;
    assert(context->end_count==2 && strcmp(name,"urn:outer|r")==0);
    event(context, "end-replacement", name, strlen(name));
    XML_DefaultCurrent(context->parser);
}
static void closing_end(void *data, const XML_Char *name) {
    EndContext *context = data;context->end_count++;
    assert(strcmp(name,context->end_count==1 ? "urn:inner|n" : "urn:outer|r")==0);
    event(context, "end", name, strlen(name));
    XML_DefaultCurrent(context->parser);
    if (context->mode && !context->stopped) {
        context->stopped = 1;
        XML_SetEndElementHandler(context->parser, replacement_end);
        assert(XML_StopParser(context->parser, XML_TRUE) == XML_STATUS_OK);
    }
}
static void closing_namespace(void *data, const XML_Char *prefix) {
    EndContext *context=data;context->ns_count++;assert(prefix==NULL && context->ns_count<=2);
    event(context, "namespace-end", prefix, prefix ? strlen(prefix) : 0);
}
static size_t run_end_case(int mode, size_t failure) {
    static const char prefix[] = "<r xmlns='urn:outer'><n xmlns='urn:inner'>";
    static const char suffix[] = "</n></r>";
    memset(&first,0,sizeof(first));memset(&second,0,sizeof(second));
    XML_Parser p = XML_ParserCreate_MM(NULL, &suite_first, "|");assert(p);
    assert(XML_SetReparseDeferralEnabled(p, XML_FALSE));
    assert(XML_Parse(p, prefix, (int)sizeof(prefix)-1, XML_FALSE) == XML_STATUS_OK);
    EndContext context={p,mode,0,0,0,0};
    XML_SetUserData(p,&context);
    XML_SetEndElementHandler(p,closing_end);
    XML_SetEndNamespaceDeclHandler(p,closing_namespace);
    XML_SetDefaultHandler(p,end_default);
    const size_t before=first.calls;
    first.fail_at=failure ? before+failure : 0;
    enum XML_Status status=XML_Parse(p,suffix,(int)sizeof(suffix)-1,XML_TRUE);
    int resumes=0;
    while (status == XML_STATUS_SUSPENDED) { assert(++resumes<=1);status=XML_ResumeParser(p); }
    const size_t end_calls=first.calls-before;
    const enum XML_Error error=XML_GetErrorCode(p);
    assert(!failure || first.failed);
    if (first.failed) {
        assert(status==XML_STATUS_ERROR && error==XML_ERROR_NO_MEMORY);
        size_t terminal_calls=first.calls;int terminal_events=context.events;
        assert(XML_Parse(p,"",0,XML_TRUE)==XML_STATUS_ERROR);
        printf("{\"scenario\":%zu,\"retry_error\":%d,\"retry_calls\":%zu,\"retry_events\":%d}\n",scenario,XML_GetErrorCode(p),first.calls,context.events);
        assert(context.events==terminal_events);
        assert(XML_Parse(p,"",0,XML_TRUE)==XML_STATUS_ERROR);
        printf("{\"scenario\":%zu,\"retry_error\":%d,\"retry_calls\":%zu,\"retry_events\":%d}\n",scenario,XML_GetErrorCode(p),first.calls,context.events);
        assert(context.events==terminal_events);
        assert(first.calls==terminal_calls);
    } else { assert(status==XML_STATUS_OK && context.end_count==2 && context.ns_count==2 && resumes==mode); }
    XML_ParserFree(p);check_freed();
    printf("{\"scenario\":%zu,\"summary\":true,\"mode\":%d,\"fail_index\":%zu,\"calls_before\":%zu,\"end_calls\":%zu,\"failed\":%d,\"status\":%d,\"error\":%d,\"end_count\":%d,\"resumes\":%d,\"live\":%zu}\n",scenario,mode,failure,before,end_calls,first.failed,status,error,context.end_count,resumes,first.live);
    scenario++;
    return end_calls;
}
int main(int argc,char **argv) {
    setvbuf(stdout,NULL,_IONBF,0);
    assert(argc==2);Dl_info info;assert(dladdr((void *)XML_Parse,&info));
    char requested[PATH_MAX],loaded[PATH_MAX];assert(realpath(argv[1],requested));assert(realpath(info.dli_fname,loaded));assert(strcmp(requested,loaded)==0);
    fprintf(stderr,"XML_Parse origin: %s\n",loaded);
    for(int mode=0;mode<2;mode++) {
        size_t count=run_end_case(mode,0);assert(count>0 && count<10000);
        for(size_t fail=1;fail<=count;fail++)run_end_case(mode,fail);
    }
    printf("{\"complete\":true,\"scenarios\":%zu}\n",scenario);
    return 0;
}
