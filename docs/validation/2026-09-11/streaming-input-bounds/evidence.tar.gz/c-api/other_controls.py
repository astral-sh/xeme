"""Retained deterministic/custom alias controls and allocation-byte observations."""
if not __debug__:raise RuntimeError('Assertions required')
from pathlib import Path
import hashlib,json,gzip,os,shutil,signal,subprocess,time
R=Path('/tmp/oriole-streaming-work-thin-pgo-gates-cpu5');W=Path('/home/dev-user/code/oss/oriole-streaming-input-bounds');O=R/'other-gates';O.mkdir(exist_ok=False)
B=Path('/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.so');C=Path('/tmp/oriole-streaming-work-pgo-study-attempt02/pgo/runs/run-psjiwn9z/use/liboriole_expat.so');P='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
report={'status':'incomplete','scope':'Strict3318 baseline C traces and retained36456 full/custom-external alias comparisons, no reference equivalence claim. All CPU3; no timing.','before':{str(p):sha(p) for p in [B,C,Path(__file__),W/'include/expat.h']},'commands':[]}
save=lambda:(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args,timeout=180):
 row={'label':label,'command':['taskset','-c','3',*args],'start':time.time(),'timeout':timeout};report['commands'].append(row);save();p=None
 with (O/(label+'.stdout')).open('wb') as out,(O/(label+'.stderr')).open('wb') as err:
  try:
   p=subprocess.Popen(row['command'],stdout=out,stderr=err,start_new_session=True);row['exit']=p.wait(timeout=timeout)
  except BaseException as e:
   row['exception']=repr(e)
   if p is not None:
    if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
    row['exit']=p.wait()
   raise
  finally:
   out.flush();err.flush();row['end']=time.time();row['stdout_sha256']=sha(O/(label+'.stdout'));row['stderr_sha256']=sha(O/(label+'.stderr'));save()
 print(label,row['exit'],flush=True);assert row['exit']==0,row
 return row
try:
 t=O/'tools';t.mkdir()
 for n in ['differential.py','corpus.py','xml_abi.py']:shutil.copyfile(W/'tools'/n,t/n)
 report['tool_hashes']={str(p):sha(p) for p in t.iterdir()};save()
 run('differential',[P,'-I','-S',str(t/'differential.py'),'--library',str(C),'--reference',str(B),'--output',str(O/'differential'),'--generated','250','--strict'])
 d=json.loads((O/'differential/summary.json').read_text());assert d['cases']==3318 and d['exact_pass'];report['differential']=d;save()
 aliases=O/'aliases';aliases.mkdir();reference='/home/dev-user/.cache/oriole/expat-build/libexpat.so'
 sources=['probe','full-events','external-semantic-compare'];report['alias_original_hashes']={str(Path('/tmp/oriole-custom-alias-'+n+'.py')):sha('/tmp/oriole-custom-alias-'+n+'.py') for n in sources}
 (aliases/'probe.py').write_text(Path('/tmp/oriole-custom-alias-probe.py').read_text().replace(reference,str(B)))
 report['aliases']=[]
 for name,output in [('full-events','full-events-comparison'),('external-semantic-compare','external-semantic-comparison')]:
  s=Path('/tmp/oriole-custom-alias-'+name+'.py').read_text()
  for old,new in [('/tmp/oriole-custom-alias-probe.py',str(aliases/'probe.py')),('/tmp/oriole-custom-alias-full-events-source.py',str(aliases/'full-events-source.py')),('/tmp/oriole-custom-alias-external-source.py',str(aliases/'external-source.py')),('/tmp/oriole-custom-alias-'+output+'.json',str(aliases/(output+'.json'))),(reference,str(B)),('/home/dev-user/.cache/oriole/api-followup-target/release/liboriole_expat.so',str(C)),('/tmp/oriole-custom-alias-runtime/liboriole_expat.so',str(C))]:s=s.replace(old,new)
  script=aliases/(name+'.py');script.write_text(s);run('aliases-'+name,[P,'-I','-S',str(script)],300)
  p=aliases/(output+'.json');data=json.loads(p.read_text());row={'name':name,'cases':data['cases'],'differences':len(data['differences']),'script_sha256':sha(script),'report_sha256':sha(p)};report['aliases'].append(row);save();assert not data['differences'];(aliases/(output+'.json.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 assert sum(r['cases'] for r in report['aliases'])==36456
 report['status']='passed'
finally:
 report['after']={p:sha(p) for p in report['before']};report['unchanged']=report['before']==report['after'];save()
assert report['unchanged']
