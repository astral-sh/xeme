"""Prepare existing C/API controls against the final streaming-policy build; no targets."""
from pathlib import Path
import difflib,hashlib,json,os,shutil,subprocess
assert __debug__ and os.sched_getaffinity(0)=={6}
R=Path(__file__).parent
OLD=Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates-cpu5')
P=Path('/tmp/oriole-streaming-work-pgo-study-attempt02')
BASE=Path('/tmp/oriole-literal-attribute-check-pgo-study')
W=Path('/home/dev-user/code/oss/oriole-streaming-input-bounds')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
j=lambda p:json.loads(Path(p).read_text())
assert not (R/'preparation.json').exists()
build=j(P/'pair-report.json');base_build=j(BASE/'pair-report.json')
assert build['status']==base_build['status']=='passed'
assert all(build[k] for k in ['source_unchanged','scripts_unchanged','tools_unchanged'])
assert sha(P/'source.json')=='e52c4fa16e71a7dcd76864b29509b157a42b6fbe4531f87b68f98395418d5fc3'
source=j(P/'source.json');baseline_source=j(BASE/'source.json')
assert len(source['source_sha256'])==70
assert all(sha(W/n)==v for n,v in source['source_sha256'].items())
delta=[n for n,v in source['source_sha256'].items() if v!=baseline_source['source_sha256'][n]]
assert delta==['crates/oriole/src/accounting.rs','crates/oriole/src/encoding.rs','crates/oriole/src/lib.rs','crates/oriole_expat/src/lib.rs','crates/oriole_expat/src/tests.rs','tests/c/integration.c']
L=Path(build['pgo_manifest']['path']).parent/'use';B=Path(base_build['pgo_manifest']['path']).parent/'use'
expected={label+'_'+kind:sha(folder/('liboriole_expat.'+suffix)) for label,folder in [('baseline',B),('candidate',L)] for suffix,kind in [('so','shared'),('a','static')]}
for label,data in [('baseline',base_build),('candidate',build)]:
 for suffix,kind in [('so','shared'),('a','static')]:assert expected[label+'_'+kind]==data['pgo_libraries']['use/liboriole_expat.'+suffix]
assert expected['baseline_shared']=='8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a'
raw=OLD/'api-native/upstream-api/results.json'
assert sha(raw)=='dcda1affc7cfa69d1e77dd60b7c76360e572e2a7767d6d4ded084ab1575647d5'
assert len(j(raw)['results'])==4740
shutil.copyfile(P/'source.json',R/'source.json');shutil.copyfile(P/'pair-report.json',R/'build.json')
(R/'tools').mkdir();shutil.copyfile(W/'tools/xml_abi.py',R/'tools/xml_abi.py')
assert sha(R/'tools/xml_abi.py')==sha(OLD/'tools/xml_abi.py')
changes=[
 (str(OLD),str(R)),
 ('/tmp/oriole-current-thin-pgo-gates/api-native/upstream-api',str(OLD/'api-native/upstream-api')),
 ('/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use',str(L)),
 ('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use',str(B)),
 ('/tmp/oriole-literal-attribute-check-pgo-study',str(P)),
 ('/tmp/oriole-native-byte-count-pgo-study',str(BASE)),
 ('/home/dev-user/code/oss/oriole-literal-attribute-check',str(W)),
 ('4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02',expected['baseline_shared']),
 ('8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a',expected['candidate_shared']),
 ("report['source']['base_commit']='c1776c922b023a3558badfefa697cd11b0d37d8e'", "report['source']['base_commit']='1058868a7067671a1cb3b5f0de571e47cfcafe17'"),
]
names=['api_native.py','other_controls.py','publication_probe.py','run_publication.py','prepare_malformed.py','run_malformed.py','classify_observations.py','end-lifecycle-final/oracle.py','end-lifecycle-final/controller.py','end-oom-final/run.py','run_lane.py','run_remaining.py','summarize.py']
diffs={};prior={}
for n in names:
 a=(OLD/n).read_text();b=a
 for i,(x,y) in enumerate(changes):b=b.replace(x,'__STREAMING_GATE_'+str(i)+'__')
 for i,(x,y) in enumerate(changes):b=b.replace('__STREAMING_GATE_'+str(i)+'__',y)
 assert '__STREAMING_GATE_' not in b
 if n=='summarize.py':
  b=b.replace("assert a['status']=='passed' and a['unchanged']", "assert a['status'] in ['passed','api_differences_native_passed'] and a['unchanged']")
  b=b.replace("assert a['commands'][0]['exit']==1", "assert a['commands'][0]['exit'] in [0,1]")
  b=b.replace("assert raw['results']==base['results'] and len(raw['results'])==4740", "assert len(raw['results'])==len(base['results'])==4740")
  b=b.replace("assert api['all4740rows_exact'] and (api['passed'],api['failed'])==(4347,393)", "assert (api['passed'],api['failed'])==(raw['passed'],raw['failed']) and raw['passed']+raw['failed']==4740; assert api['all4740rows_exact']==(raw['results']==base['results'])")
  b=b.replace("'status':'correctness_parity_gates_passed'", "'status':'compatibility_gates_completed'")
  b=b.replace("'raw_exit':1,'passed':4347,'failed':393,'all4740rows_exact':True", "'raw_exit':a['commands'][0]['exit'],'passed':raw['passed'],'failed':raw['failed'],'all4740rows_exact':api['all4740rows_exact'],'changed_rows':api['changes'],'comparison_sha256':h(R/'api-native/api-comparison.json')")
  b=b.replace('Original393 upstream failures and reference callback-position differences remain.', 'Original baseline API outcomes remain retained; this policy may change input/work-limit outcomes. Every changed candidate row is reported. Reference callback-position differences are retained.')
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(b);compile(b,str(p),'exec')
 diffs[n]=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=str(OLD/n),tofile=str(p)))
 prior[str(OLD/n)]=sha(OLD/n)
for n in ['probe.c','original-allocations.c','expat.h']:shutil.copyfile(OLD/'end-oom-final'/n,R/'end-oom-final'/n)
shutil.copyfile(OLD/'end-lifecycle-final/SOURCE_REVIEW.md',R/'end-lifecycle-final/SOURCE_REVIEW.md')
# Native current integration includes the already-published PR122 success probes.
assert sha(W/'tests/c/integration.c')=='b2ab3710059d134e744dec95bb99d403379cca65ba011c83fa25a95349b38bc1'
for n in ['adversarial.c','allocations.c']:assert sha(W/'tests/c'/n)==sha(OLD/'api-native/native'/n)
for n in ['run.py','runner.c','bridge.c','bridge.h','memcheck.patch','README.md','allocator_repro.c']:assert sha(W/'tools/upstream-expat'/n)==sha(OLD/'api-native/tools'/n)
cmd=['taskset','-c','6','/usr/bin/python3','-I','-S','-B',str(R/'prepare_malformed.py')]
p=subprocess.run(cmd,capture_output=True,timeout=30);(R/'prepare-malformed.stdout').write_bytes(p.stdout);(R/'prepare-malformed.stderr').write_bytes(p.stderr);assert p.returncode==0
(R/'controller.patch').write_text(''.join(diffs.values()))
tracked=[P/'pair-report.json',P/'source.json',P/'tool-source.json',Path(build['pgo_manifest']['path']),BASE/'pair-report.json',BASE/'source.json',Path(base_build['pgo_manifest']['path']),L/'liboriole_expat.so',L/'liboriole_expat.a',B/'liboriole_expat.so',B/'liboriole_expat.a',raw,OLD/'api-native/upstream-api/manifest.json',*[W/n for n in source['source_sha256']],*[R/n for n in names],*[Path(n) for n in prior],R/'tools/xml_abi.py',R/'end-lifecycle-final/SOURCE_REVIEW.md',*[R/'end-oom-final'/n for n in ['probe.c','original-allocations.c','expat.h']],R/'malformed/malformed_probe.py',R/'malformed/original-malformed-probe.py']
report={'status':'prepared_not_executed','before':{str(p):sha(p) for p in tracked},'controllers':{n:sha(R/n) for n in names},'prior_controllers':prior,'replacements':changes,'libraries':expected,'candidate_library_directory':str(L),'baseline_library_directory':str(B),'candidate_source_manifest_sha256':sha(P/'source.json'),'source_delta_from_attribute_control':delta,'scope':'Original4740 at3s/test,1GiB AS,768MiB RSS,240s total;6 native C dynamic/static runs including current PR122 integration and327 allocation scenarios per linkage; strict3318/custom36456/malformed2392/publication1304/3912/End38+6. Original fixtures, assertions, limits and failure rows retained.','material_changes':['Candidate output/source/library paths and hashes; accepted8cc controls and saved attribute API rows.','Summary records candidate API counts and all changed rows rather than requiring the earlier393 failures or exact API parity. No API test/assertion/resource ceiling changed.','Current C integration source includes published PR122 allocation-success regression coverage; original allocations/adversarial/End fixtures unchanged.'],'execution':'Preparation CPU6 reads/copies and Python syntax validation only; CPU5 target lanes remain held.','limitations':['C ASan/UBSan only; Rust release library uninstrumented, leak checks disabled.','Other strict semantic checks remain strict; any differences stop that lane and remain recorded for review.','Successful custom alias raw pairs are absent from unchanged helpers; counts/scripts/commands/differences retained.','Expat publication/lifecycle reference remains exact existing7a333bc8; separate root large-stream harness uses12d.','No workspace rerun, CPython, benchmark or adoption claim.']}
(R/'preparation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'preparation_sha256':sha(R/'preparation.json'),'controller_patch_sha256':sha(R/'controller.patch'),'libraries':expected}))
