from pathlib import Path
import hashlib,json,difflib,os
assert os.sched_getaffinity(0)=={6}
R=Path(__file__).parent;old=Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates-cpu5')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=R/'preparation.json';a=json.loads(p.read_text())
assert all(sha(k)==v for k,v in a['before'].items())
assert not (R/'preparation-cpu5-unexecuted.json').exists()
(R/'preparation-cpu5-unexecuted.json').write_bytes(p.read_bytes())
subs=[("'taskset','-c','5'", "'taskset','-c','3'"),("'taskset', '-c', '5'", "'taskset', '-c', '3'"),("'cpu': 5", "'cpu': 3"),("cpu={'api':5,'other':5}", "cpu={'api':3,'other':3}"),("cpu={'end':5}", "cpu={'end':3}"),('os.sched_getaffinity(0)=={5}', 'os.sched_getaffinity(0)=={3}'),('os.sched_getaffinity(0)) == [5]', 'os.sched_getaffinity(0)) == [3]'),("report['affinity'] == [5]", "report['affinity'] == [3]"),('CPU5','CPU3')]
diffs=[];full=[]
for name in a['controllers']:
 q=R/name;before=q.read_text();after=before
 for x,y in subs:after=after.replace(x,y)
 compile(after,str(q),'exec');q.write_text(after)
 diffs.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=name+' (prepared CPU5)',tofile=name+' (released CPU3)'))
 full.extend(difflib.unified_diff((old/name).read_text().splitlines(True),after.splitlines(True),fromfile=str(old/name),tofile=str(q)))
 a['controllers'][name]=sha(q)
 a['before'][str(q)]=sha(q)
freeze=Path('/tmp/oriole-streaming-work-pgo-study-attempt02/pair-freeze.json')
assert sha(freeze)=='c3de58fb747d0d97594c6011ea3f59972167cb29f0770b65d351d8bd594d6058'
a['before'][str(freeze)]=sha(freeze)
a['execution']='Prepared on CPU6. Parent released sequential C/API lanes on CPU3 after candidate build; root large streams CPU5 and strict CPython CPU4 are independent correctness jobs. Directory cpu5 suffix records template lineage, not actual affinity.'
a['material_changes'].append('Explicit scheduling revision: all target subprocess affinity and matching guards/metadata changed CPU5 to CPU3. All timeouts and fixture limits unchanged.')
a['scheduling_revision']={'from':5,'to':3,'previous_preparation_sha256':sha(R/'preparation-cpu5-unexecuted.json'),'pair_freeze_sha256':sha(freeze)}
(R/'cpu-scheduling-revision.patch').write_text(''.join(diffs));(R/'controller.patch').write_text(''.join(full))
p.write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({'preparation_sha256':sha(p),'controller_patch_sha256':sha(R/'controller.patch'),'scheduling_patch_sha256':sha(R/'cpu-scheduling-revision.patch')}))
