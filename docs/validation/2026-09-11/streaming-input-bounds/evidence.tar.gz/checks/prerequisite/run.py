from pathlib import Path
import hashlib,json,os,subprocess,tarfile,time
ROOT=Path('/home/dev-user/code/oss/oriole-streaming-input-bounds')
OUT=Path(__file__).parent
manifest=json.loads(Path('/tmp/oriole-literal-attribute-check-pgo-study/source.json').read_text())
files=list(manifest['source_sha256'])+['docs/validation/2026-09-11/streaming-input-bounds/README.md']
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def freeze(label):
 data={name:sha(ROOT/name) for name in files}
 (OUT/(label+'.json')).write_text(json.dumps(data,indent=2)+'\n')
 with tarfile.open(OUT/(label+'.tar.gz'),'w:gz') as archive:
  for name in files:archive.add(ROOT/name,arcname=name,recursive=False)
 return sha(OUT/(label+'.json'))
env=os.environ.copy()
for name in ['RUSTC','RUSTFLAGS','LLVM_PROFILE_FILE','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST']:env.pop(name,None)
overrides={'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/targets/streaming-input-bounds','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_ENCODED_RUSTFLAGS':'','RUSTUP_AUTO_INSTALL':'0','CARGO_TERM_COLOR':'never'}
env.update(overrides)
report={'before_fmt_source':freeze('before-fmt-source'),'environment_overrides':overrides,'steps':[],'completed':False}
def save():(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for name,args in [('fmt',['fmt','--all']),('test',['test','--workspace','--locked']),('clippy',['clippy','--workspace','--all-targets','--locked','--','-D','warnings'])]:
 command=['taskset','-c','4','cargo','+ohm','-Zohm-defaults=no',*args]
 entry={'step':name,'command':command,'started':time.time()};report['steps'].append(entry);save()
 with (OUT/(name+'.stdout')).open('w') as stdout,(OUT/(name+'.stderr')).open('w') as stderr:
  try:process=subprocess.run(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,timeout=600);entry['exit_code']=process.returncode
  except subprocess.TimeoutExpired:entry['timeout']=True;entry['exit_code']=None
 entry['completed_at']=time.time();entry['stdout_sha256']=sha(OUT/(name+'.stdout'));entry['stderr_sha256']=sha(OUT/(name+'.stderr'));save()
 print(name,entry['exit_code'],flush=True)
 if entry['exit_code']!=0:raise SystemExit(1)
 if name=='fmt':report['formatted_source']=freeze('formatted-source');save()
report['after_checks_source']=freeze('after-checks-source')
assert report['after_checks_source']==report['formatted_source']
report['completed']=True;save();print('completed',sha(OUT/'results.json'),flush=True)
