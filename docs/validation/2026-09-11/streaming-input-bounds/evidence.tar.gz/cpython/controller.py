"""Strict CPython tests against the exact measured ThinLTO PGO artifacts."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time

root = Path('/home/dev-user/code/oss/oriole-streaming-input-bounds')
out = Path('/tmp/oriole-streaming-work-thin-pgo-cpython-gates')
out.mkdir(exist_ok=False)
shutil.copy2(__file__, out / Path(__file__).name)
python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
library = Path('/tmp/oriole-streaming-work-pgo-study-attempt02/pgo/runs/run-psjiwn9z/use/liboriole_expat.so')
archive = library.with_suffix('.a')
source = '/home/dev-user/.cache/oriole/upstream/cpython-3.12.13'
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert digest(library) == '8e12c1819a58a66ae5530a53433dd08de44921c94a2b39a6282358dfd33c0d1e'
assert digest(archive) == 'b5529316fb6a3bcac246267b665b70e8b8fa487e4824e5c8b2e0736dedd4371e'
source_map = json.loads(Path('/tmp/oriole-streaming-work-pgo-study-attempt02/source.json').read_text())['source_sha256']
assert len(source_map) == 70 and all(digest(root / name) == value for name, value in source_map.items())
report = {'status': 'incomplete', 'libraries': {str(p): digest(p) for p in [library, archive]}, 'source_sha256': source_map, 'jobs': [],
          'scope': 'Fresh CPython shared/static consumers with the pinned upstream allocation-failure cleanup backport against the streaming policy ThinLTO PGO artifact; upstream tests are unmodified. Strict test failures remain raw; expected count alone does not establish parity. Per-command 1200s with process-group cleanup. CPU4, shared host.'}
def save():
    (out / 'controller.json').write_text(json.dumps(report, indent=2) + '\n')
try:
    for linkage, path in [('shared', library), ('static', archive)]:
        command = ['taskset', '-c', '4', python, '-I', '-S', str(root / 'tools/cpython/run.py'), '--source', source, '--library', str(path), '--output', str(out / linkage), '--consumer-fix']
        if linkage == 'static':
            command += [arg for name in ['gcc_s', 'util', 'rt', 'pthread', 'm', 'dl', 'c'] for arg in ['--native-library', name]]
        item = {'linkage': linkage, 'command': command, 'expected_exit': 2, 'timeout_seconds': 1200, 'start': time.time()}
        report['jobs'].append(item)
        save()
        process = None
        log_path = out / (linkage + '.log')
        with log_path.open('wb') as log:
            try:
                process = subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                item['exit'] = process.wait(timeout=1200)
                assert item['exit'] == 2
            except BaseException as exc:
                item['exception'] = repr(exc)
                if process is not None:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    item['exit'] = process.wait()
                raise
            finally:
                log.flush()
                item['end'] = time.time()
                item['log_sha256'] = digest(log_path)
                save()
        print(linkage, item['exit'], flush=True)
    assert all(digest(p) == value for p, value in report['libraries'].items())
    assert all(digest(root / name) == value for name, value in source_map.items())
    report['status'] = 'completed_with_failures_retained_pending_outcome_audit'
except BaseException as exc:
    report['status'] = 'failed'
    report['exception'] = repr(exc)
    raise
finally:
    save()
