from pathlib import Path
import ast,collections,hashlib,json,re,subprocess
O=Path(__file__).parent;G=Path('/tmp/oriole-streaming-work-thin-pgo-cpython-gates');B=Path('/tmp/oriole-literal-attribute-thin-pgo-cpython-gates');W=Path('/home/dev-user/code/oss/oriole-streaming-input-bounds')
hashes={}
def read(p):
 p=Path(p);b=p.read_bytes();hashes[str(p)]=hashlib.sha256(b).hexdigest();return b
def sha(p):read(p);return hashes[str(Path(p))]
def load(p):return json.loads(read(p))
reference=Path('/tmp/oriole-native-byte-count-thinlto-cpython-root-review/audit.py')
tree=ast.parse(read(reference));node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='methods');exec(compile(ast.Module(body=[node],type_ignores=[]),str(reference),'exec'))
c=load(G/'controller.json');assert c['status']=='completed_with_failures_retained_pending_outcome_audit' and len(c['jobs'])==2
for p,h in c['libraries'].items():assert sha(p)==h
assert len(c['source_sha256'])==70 and all(sha(W/f)==h for f,h in c['source_sha256'].items())
fix=W/'integration/python-build-standalone/consumer-fix';prov=load(fix/'provenance.json');assert sha(fix/'cpython-3.12.13-external-parser.patch')==prov['patch_sha256']
assert prov['patched_source_sha256']=='1c3cf2ee6dfa568cf833742ad786880f4816042705689a116a4f308b7a9d95f2'
U=Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13');assert sha(U/'Modules/pyexpat.c')==prov['source_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=U,text=True).strip()==prov['cpython_revision'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=U)
expected=['test.test_pyexpat.BufferTextTest.test1','test.test_sax.CDATAHandlerTest.test_handlers'];rowsummary={}
for job in c['jobs']:
 linkage=job['linkage'];p=G/linkage;command=job['command'];assert command[:3]==['taskset','-c','4'];assert job['exit']==job['expected_exit']==2 and job['timeout_seconds']==1200
 assert command.count('--consumer-fix')==1 and '--allow-text-fragmentation' not in command and '--system-allocator' not in command
 assert sha(G/(linkage+'.log'))==job['log_sha256']
 s=load(p/'summary.json');base=load(B/linkage/'summary.json');origin=load(p/'origin.log')
 assert s['linkage']==linkage and s['tests_exit_code']==s['gate_exit_code']==2 and s['probe_exit_code']==s['origin_exit_code']==0
 assert s['consumer_fix']==prov and s['consumer_adaptation']=='CPython upstream allocation-failure fix' and s['text_fragmentation'] is None
 assert base['consumer_fix'] is None and base['consumer_adaptation'] is None
 assert s['cpython_revision']==prov['cpython_revision'] and s['source_sha256']==prov['source_sha256']
 assert s['compiled_source_sha256']==sha(p/'pyexpat.c')==prov['patched_source_sha256']
 assert s['test_command']==base['test_command']
 suffix='so' if linkage=='shared' else 'a';lib=p/('liboriole_expat.'+suffix)
 assert sha(lib)==s['library_sha256']==next(h for x,h in c['libraries'].items() if x.endswith('.'+suffix))
 assert sha(p/'sitecustomize.py')==s['loader_sha256']==sha(W/'tools/cpython/extension_loader.py')
 assert s['import_check_sha256']==sha(W/'tools/cpython/check_extension_imports.py')
 assert origin['status']=='passed' and origin['accelerator_imports']==['cET','cET_alias'] and origin['pure_python_and_blocked_imports']=='passed' and len(origin['origins'])==4
 for value in origin['origins'].values():assert Path(value['path']).parent==p and sha(value['path'])==value['sha256']
 a=methods(p/'tests.log');b=methods(B/linkage/'tests.log');assert len(a)==802 and a==b
 failures=sorted(k for k,v in a.items() if v in ('FAIL','ERROR'));assert failures==expected
 text=read(p/'tests.log').decode();baseline=read(B/linkage/'tests.log').decode();skip=[l for l in text.splitlines() if ' ... skipped ' in l];base_skip=[l for l in baseline.splitlines() if ' ... skipped ' in l]
 assert skip==base_skip and len(skip)==14 and sum(l.startswith('  ') for l in skip)==8 and sum(l.startswith('setUpClass') for l in skip)==1
 assert sum(v.startswith('skipped') for v in a.values())==5 and sum(v=='expected failure' for v in a.values())==3
 assert re.findall(r'^(FAIL|ERROR): (.+)$',text,re.M)==re.findall(r'^(FAIL|ERROR): (.+)$',baseline,re.M)
 for n in ['consumer-fix.log','probe.log','pyexpat-build.log','_elementtree-build.log']:read(p/n)
 rowsummary[linkage]={'methods':len(a),'method_map_sha256':hashlib.sha256(json.dumps(a,sort_keys=True).encode()).hexdigest(),'all_method_outcomes_equal_accepted_unmodified_consumer_baseline':True,'raw_exit':2,'failure_identities':failures,'expected_failures':3,'skips':{'reported':14,'methods':5,'subtests':8,'class_setup':1}}
old=load('/tmp/oriole-pbs-version-followup/report.json')['test_count_and_coverage']['upstream_six_module_hashes_exact'];assert all(sha(U/'Lib/test'/(n+'.py'))==h for n,h in old.items())
read('/tmp/oriole-streaming-work-thin-pgo-cpython-gates.py');read('/tmp/oriole-streaming-work-thin-pgo-cpython-preparation/binding-cpu4.json')
r={'status':'passed_exact_saved_method_outcome_comparison','role':'This agent prepared and collected the two runs, then reconstructed their saved outcomes; not an independent collector audit.','session':50543,'controller_exit':0,'first_attempts':True,'cpu4_released':True,'scope':'Strict CPython 3.12.13, shared/static streaming-policy PGO8e12/b552; no test relaxation, system-allocator override, rerun, full PBS or timing claim.','consumer_scope':'New runs apply the explicitly approved upstream allocation-failure cleanup backport. Prior accepted8cc strict baseline used unmodified consumer C source. Tests/802 method outcomes are equal; consumer source identity is not claimed.','consumer_fix':prov,'cpython':rowsummary,'libraries':c['libraries'],'source_manifest_sha256':sha('/tmp/oriole-streaming-work-pgo-study-attempt02/source.json'),'findings':[],'limitations':['Both suites retain the two callback-boundary failures and raw exit2; this is exact outcome parity, not a green test suite.','Four persistent-loader origin records per linkage and all six unchanged upstream modules were checked. No full distribution build or allocation-fault campaign is implied.'],'evidence_sha256':hashes}
(O/'review.json').write_text(json.dumps(r,indent=2)+'\n');print(sha(O/'review.json'));print(json.dumps(rowsummary,indent=2))
