/* Bounded-memory stream oracle. Dynamically loads one engine; no Expat link. */
#define _GNU_SOURCE
#define XML_DTD 1
#include "expat.h"
#include <dlfcn.h>
#include <inttypes.h>
#include <limits.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define APIS(X) \
  X(XML_ParserCreate_MM) X(XML_ParserFree) X(XML_Parse) X(XML_GetBuffer) \
  X(XML_ParseBuffer) X(XML_GetErrorCode) X(XML_SetUserData) \
  X(XML_SetElementHandler) X(XML_SetCharacterDataHandler) X(XML_StopParser) \
  X(XML_ResumeParser) X(XML_GetCurrentByteIndex) X(XML_GetCurrentLineNumber) \
  X(XML_GetCurrentColumnNumber) X(XML_ExpatVersion)
#define DECLARE(name) static __typeof__(&name) p_##name;
APIS(DECLARE)
static void fail(const char *message) {
  fprintf(stderr, "ASSERTION: %s\n", message);
  exit(100);
}
/* The union keeps returned memory aligned as malloc would. */
union Header { max_align_t align; size_t size; };
static size_t live, peak, live_blocks, malloc_calls, realloc_calls;
static void *tracked_malloc(size_t size) {
  if (size > SIZE_MAX - sizeof(union Header)) return NULL;
  union Header *h = malloc(sizeof(*h) + size);
  if (!h) return NULL;
  h->size = size;
  if (size > SIZE_MAX - live) fail("Live allocation overflow");
  live += size;
  if (live > peak) peak = live;
  malloc_calls++;
  live_blocks++;
  return h + 1;
}
static void tracked_free(void *pointer) {
  if (!pointer) return;
  union Header *h = (union Header *)pointer - 1;
  if (h->size > live || !live_blocks) fail("Unbalanced allocator free");
  live -= h->size;
  live_blocks--;
  free(h);
}
static void *tracked_realloc(void *pointer, size_t size) {
  if (!pointer) return tracked_malloc(size);
  if (!size) { tracked_free(pointer); return NULL; }
  if (size > SIZE_MAX - sizeof(union Header)) return NULL;
  union Header *old = (union Header *)pointer - 1;
  size_t old_size = old->size;
  union Header *h = realloc(old, sizeof(*h) + size);
  if (!h) return NULL;
  if (old_size > live || size > SIZE_MAX - (live - old_size))
    fail("Reallocation accounting overflow");
  h->size = size;
  live = live - old_size + size;
  if (live > peak) peak = live;
  realloc_calls++;
  return h + 1;
}
static uint64_t hash_bytes(uint64_t hash, const char *bytes, size_t length) {
  for (size_t i = 0; i < length; i++) {
    hash ^= (unsigned char)bytes[i];
    hash *= UINT64_C(1099511628211);
  }
  return hash;
}
static uint64_t hash_string(uint64_t hash, const char *text) {
  return hash_bytes(hash, text, strlen(text) + 1);
}
struct State {
  XML_Parser parser;
  uint64_t starts, ends, text_bytes, event_hash, text_hash;
  uint64_t next_stop, suspensions, resumes;
  const char *child_name;
  int suspend;
};
static void XMLCALL on_start(void *data, const XML_Char *name,
                             const XML_Char **attributes) {
  struct State *s = data;
  const char *expected = s->starts == 0 ? "r" : s->child_name;
  if (strcmp(name, expected)) fail("Unexpected element name");
  if (s->starts == 0) {
    if (attributes[0]) fail("Unexpected root attribute");
  } else if (!attributes[0] || strcmp(attributes[0], "a") ||
             !attributes[1] || strcmp(attributes[1], "value") || attributes[2]) {
    fail("Unexpected child attributes");
  }
  s->starts++;
  s->event_hash = hash_string(s->event_hash, "+");
  s->event_hash = hash_string(s->event_hash, name);
  for (size_t i = 0; attributes[i]; i++)
    s->event_hash = hash_string(s->event_hash, attributes[i]);
}
static void XMLCALL on_end(void *data, const XML_Char *name) {
  struct State *s = data;
  s->ends++;
  s->event_hash = hash_string(s->event_hash, "-");
  s->event_hash = hash_string(s->event_hash, name);
}
static void XMLCALL on_text(void *data, const XML_Char *text, int length) {
  struct State *s = data;
  if (length < 0) fail("Negative text length");
  s->text_bytes += (unsigned)length;
  s->text_hash = hash_bytes(s->text_hash, text, (size_t)length);
  if (s->suspend && s->text_bytes >= s->next_stop) {
    s->next_stop += UINT64_C(16) * 1024 * 1024;
    if (p_XML_StopParser(s->parser, XML_TRUE) != XML_STATUS_OK)
      fail("Suspension rejected");
    s->suspensions++;
  }
}
static int feed(struct State *s, const char *bytes, size_t length, int final,
                int buffered) {
  if (length > 4096) fail("Input chunk exceeded bound");
  int status;
  if (buffered) {
    void *buffer = p_XML_GetBuffer(s->parser, (int)length);
    if (!buffer) return XML_STATUS_ERROR;
    memcpy(buffer, bytes, length);
    status = p_XML_ParseBuffer(s->parser, (int)length, final);
  } else status = p_XML_Parse(s->parser, bytes, (int)length, final);
  while (status == XML_STATUS_SUSPENDED) {
    s->resumes++;
    status = p_XML_ResumeParser(s->parser);
  }
  return status;
}
#define LOAD(name) do { \
  void *symbol = dlsym(library, #name); \
  if (!symbol || sizeof(p_##name) != sizeof(symbol)) fail("Missing " #name); \
  Dl_info location; char found[PATH_MAX]; \
  if (!dladdr(symbol, &location) || !realpath(location.dli_fname, found) || \
      strcmp(found, requested)) fail("Unexpected origin for " #name); \
  memcpy(&p_##name, &symbol, sizeof(symbol)); \
} while (0);
int main(int argc, char **argv) {
  if (argc != 4) fail("Expected absolute library, mode, body MiB");
  if (dlsym(RTLD_DEFAULT, "XML_Parse") || dlsym(RTLD_DEFAULT, "XML_ParserCreate_MM"))
    fail("Preexisting global Expat symbols");
  char requested[PATH_MAX], actual[PATH_MAX];
  if (argv[1][0] != '/' || !realpath(argv[1], requested)) fail("Invalid library");
  void *library = dlopen(requested, RTLD_NOW | RTLD_LOCAL);
  if (!library) fail(dlerror());
  APIS(LOAD)
  Dl_info origin;
  if (!dladdr(dlsym(library, "XML_Parse"), &origin) ||
      !realpath(origin.dli_fname, actual) || strcmp(requested, actual))
    fail("Unexpected XML_Parse origin");
  char *end;
  unsigned long mib = strtoul(argv[3], &end, 10);
  if (*end || mib < 1 || mib > 1024) fail("Invalid bounded stream size");
  const char *mode = argv[2], *prefix = "<r>", *unit;
  char padded_element[1025];
  int buffered = 0, handlers = 1, namespaces = 0, suspend = 0;
  if (!strcmp(mode, "text")) { unit = "A"; suspend = 1; }
  else if (!strcmp(mode, "tags")) { unit = "<i a='value'>text\n</i>"; buffered = 1; }
  else if (!strcmp(mode, "namespaces")) {
    unit = "<p:i a='value'>text\n</p:i>"; buffered = namespaces = 1;
    prefix = "<r xmlns:p='urn:example:stable'>";
  } else if (!strcmp(mode, "defaults")) {
    unit = "<i>text\n</i>";
    prefix = "<!DOCTYPE r [<!ATTLIST i a CDATA 'value'>]><r>";
    handlers = 0;
  } else if (!strcmp(mode, "input")) {
    /* Less than 1 MiB of event payload for a 257 MiB input stream. */
    memset(padded_element, ' ', 1024);
    padded_element[0] = '<'; padded_element[1] = 'i';
    padded_element[1022] = '/'; padded_element[1023] = '>';
    padded_element[1024] = '\0';
    unit = padded_element;
    handlers = 0;
  } else fail("Unknown mode");
  XML_Memory_Handling_Suite suite = {tracked_malloc, tracked_realloc, tracked_free};
  XML_Char separator = '|';
  struct State s = {.event_hash = UINT64_C(14695981039346656037),
                    .text_hash = UINT64_C(14695981039346656037),
                    .next_stop = UINT64_C(16) * 1024 * 1024,
                    .child_name = namespaces ? "urn:example:stable|i" : "i",
                    .suspend = suspend};
  s.parser = p_XML_ParserCreate_MM(NULL, &suite, namespaces ? &separator : NULL);
  if (!s.parser) fail("Parser creation failed");
  p_XML_SetUserData(s.parser, &s);
  if (handlers) {
    p_XML_SetElementHandler(s.parser, on_start, on_end);
    p_XML_SetCharacterDataHandler(s.parser, on_text);
  }
  size_t unit_length = strlen(unit), units_per_chunk = 4096 / unit_length;
  char chunk[4096];
  for (size_t i = 0; i < units_per_chunk; i++)
    memcpy(chunk + i * unit_length, unit, unit_length);
  uint64_t units = ((uint64_t)mib * 1024 * 1024 + unit_length - 1) / unit_length;
  uint64_t remaining = units, input_bytes = strlen(prefix);
  int status = feed(&s, prefix, strlen(prefix), 0, buffered);
  while (remaining && status == XML_STATUS_OK) {
    size_t count = remaining < units_per_chunk ? (size_t)remaining : units_per_chunk;
    size_t length = count * unit_length;
    input_bytes += length;
    status = feed(&s, chunk, length, 0, buffered);
    remaining -= count;
  }
  if (status == XML_STATUS_OK) {
    input_bytes += 4;
    status = feed(&s, "</r>", 4, 1, buffered);
  }
  int error = p_XML_GetErrorCode(s.parser);
  XML_Index index = p_XML_GetCurrentByteIndex(s.parser);
  XML_Size line = p_XML_GetCurrentLineNumber(s.parser);
  XML_Size column = p_XML_GetCurrentColumnNumber(s.parser);
  size_t retained = live;
  if (status == XML_STATUS_OK) {
    if (error || remaining || index < 0 || (uint64_t)index != input_bytes)
      fail("Successful stream has unexpected final state");
    int text_mode = !strcmp(mode, "text"), input_mode = !strcmp(mode, "input");
    uint64_t children = text_mode ? 0 : units;
    uint64_t text_bytes = text_mode ? units : input_mode ? 0 : units * 5;
    if (handlers && (s.starts != children + 1 || s.ends != children + 1 ||
                     s.text_bytes != text_bytes)) fail("Incorrect callback counts");
    uint64_t expected_line = text_mode || input_mode ? 1 : units + 1;
    uint64_t expected_column = text_mode ? units + 7 : input_mode ? units * 1024 + 7
                                                : namespaces ? 10 : 8;
    if (line != expected_line || column != expected_column)
      fail("Incorrect final line or column");
    uint64_t expected_stops = suspend ? text_bytes / (UINT64_C(16) * 1024 * 1024) : 0;
    if (s.suspensions != expected_stops || s.resumes != expected_stops)
      fail("Incorrect suspension/resume count");
  }
  p_XML_ParserFree(s.parser);
  if (live || live_blocks) fail("Parser leaked application allocations");
  printf("{\"mode\":\"%s\",\"mib\":%lu,\"version\":\"%s\","
         "\"library_origin\":\"%s\",\"status\":%d,\"error\":%d,"
         "\"attempted_input_bytes\":%" PRIu64 ",\"remaining_units\":%" PRIu64 ","
         "\"starts\":%" PRIu64 ",\"ends\":%" PRIu64 ",\"text_bytes\":%" PRIu64 ","
         "\"event_hash\":\"%016" PRIx64 "\",\"text_hash\":\"%016" PRIx64 "\","
         "\"suspensions\":%" PRIu64 ",\"resumes\":%" PRIu64 ",\"byte_index\":%lld,\"line\":%llu,"
         "\"column\":%llu,\"peak_bytes\":%zu,\"retained_bytes\":%zu,"
         "\"successful_malloc_calls\":%zu,\"successful_realloc_calls\":%zu,"
         "\"live_after_free\":%zu,\"live_blocks_after_free\":%zu}\n",
         mode, mib, p_XML_ExpatVersion(), actual, status, error, input_bytes, remaining,
         s.starts, s.ends, s.text_bytes, s.event_hash, s.text_hash, s.suspensions, s.resumes,
         (long long)index, (unsigned long long)line, (unsigned long long)column,
         peak, retained, malloc_calls, realloc_calls, live, live_blocks);
  dlclose(library);
  return 0;
}
