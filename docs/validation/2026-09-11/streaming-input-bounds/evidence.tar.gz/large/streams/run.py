"""Run fixed, resource-bounded stream checks; elapsed time is not a benchmark."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import time


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def limits():
    os.sched_setaffinity(0, {5})
    resource.setrlimit(resource.RLIMIT_CPU, (120, 120))
    resource.setrlimit(resource.RLIMIT_AS, (1024**3, 1024**3))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("output", type=Path)
parser.add_argument("libraries", type=Path)
parser.add_argument("--sizes", nargs="+", type=int, default=[1, 65, 257])
parser.add_argument("--reference", default="reference")
parser.add_argument("--require-success", nargs="*", default=[])
args = parser.parse_args()
assert args.sizes and all(1 <= size <= 1024 for size in args.sizes)
root = Path(__file__).parent
binary = root / "probe"
libraries = json.loads(args.libraries.read_text())
assert libraries and all(Path(path).is_absolute() for path in libraries.values())
assert args.reference in libraries
assert all(name in libraries for name in args.require_success)
args.output.mkdir(exist_ok=False)
paths = [Path(__file__), root / "probe.c", binary, args.libraries]
paths.extend(Path(path) for path in libraries.values())
hashes = {str(path): sha(path) for path in paths}
report = {
    "status": "incomplete",
    "scope": "Correctness and application allocator requested-byte high water; no elapsed comparison, total process-memory or system allocator overhead claim. Absent-handler default/input modes check parsing and positions, not delivered callback/default values. Attempted input includes a failing request, not necessarily consumed bytes.",
    "bounds": {"cpu_seconds_per_worker": 120, "wall_seconds_per_worker": 150,
               "address_space_bytes": 1024**3, "cpu": 5},
    "sizes_mib": args.sizes,
    "libraries": libraries,
    "hashes_before": hashes,
    "commands": [],
}


def save():
    (args.output / "results.json").write_text(json.dumps(report, indent=2) + "\n")


try:
    for size in args.sizes:
        for mode in ["text", "tags", "namespaces", "defaults", "input"]:
            observed = {}
            for name, library in libraries.items():
                command = [str(binary), library, mode, str(size)]
                row = {"library": name, "mode": mode, "mib": size,
                       "command": command, "started": time.time()}
                report["commands"].append(row)
                save()
                process = None
                try:
                    process = subprocess.Popen(command, stdout=subprocess.PIPE,
                                               stderr=subprocess.PIPE,
                                               start_new_session=True,
                                               preexec_fn=limits)
                    stdout, stderr = process.communicate(timeout=150)
                except BaseException as error:
                    row["exception"] = repr(error)
                    if process is not None:
                        try:
                            os.killpg(process.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                        stdout, stderr = process.communicate()
                        row.update(returncode=process.returncode,
                                   stdout=stdout.decode(), stderr=stderr.decode())
                    raise
                else:
                    row.update(returncode=process.returncode,
                               stdout=stdout.decode(), stderr=stderr.decode())
                    assert process.returncode == 0 and not stderr, row
                    result = json.loads(stdout)
                    assert result["library_origin"] == str(Path(library).resolve())
                    assert result["mode"] == mode and result["mib"] == size
                    assert result["live_after_free"] == result["live_blocks_after_free"] == 0
                    if name == args.reference or name in args.require_success:
                        assert result["status"] == 1 and result["error"] == 0, result
                    observed[name] = result
                    row["result"] = result
                finally:
                    row["finished"] = time.time()
                    save()
                print(name, mode, size, result["status"], result["error"],
                      result["peak_bytes"], flush=True)
            canonical = ["status", "error", "attempted_input_bytes", "remaining_units", "starts",
                         "ends", "text_bytes", "event_hash", "text_hash", "suspensions",
                         "resumes", "byte_index", "line", "column"]
            expected = {key: observed[args.reference][key] for key in canonical}
            for result in observed.values():
                if result["status"] == 1:
                    assert {key: result[key] for key in canonical} == expected
    report["hashes_after"] = {path: sha(path) for path in hashes}
    assert report["hashes_after"] == hashes
    report["status"] = "passed"
finally:
    save()
