"""Run the separately reviewed oracle with bounded process-group cleanup."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import traceback

ROOT = Path(__file__).resolve().parent
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
active = None
report = {'status': 'incomplete', 'runs': [], 'scope': '38 new logical lifecycle cases, 114 parser executions; separate from original publication1304. No timing observations.', 'outer_timeout_seconds_per_engine': 90, 'cpu': 5}

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save():
    (ROOT / 'controller.json').write_text(json.dumps(report, indent=2) + '\n')

def cleanup():
    global active
    if active is not None:
        # The child starts its own process group, with no unrelated members.
        try:
            os.killpg(active.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        active.wait()
        active = None

def interrupted(signum, frame):
    cleanup()
    raise KeyboardInterrupt(f'signal {signum}')

def differences(left, right, path=''):
    if type(left) is not type(right):
        return [{'path': path, 'baseline': left, 'other': right}]
    if isinstance(left, dict):
        output = []
        for key in sorted(set(left) | set(right)):
            if key not in left or key not in right:
                output.append({'path': path + '/' + key, 'baseline': left.get(key), 'other': right.get(key)})
            else:
                output += differences(left[key], right[key], path + '/' + key)
        return output
    if isinstance(left, list):
        if len(left) != len(right):
            return [{'path': path + '/length', 'baseline': len(left), 'other': len(right)}]
        return [item for index, (a, b) in enumerate(zip(left, right)) for item in differences(a, b, path + '/' + str(index))]
    return [] if left == right else [{'path': path, 'baseline': left, 'other': right}]

for sig in [signal.SIGINT, signal.SIGTERM]:
    signal.signal(sig, interrupted)

try:
    assert sorted(os.sched_getaffinity(0)) == [5]
    report['oracle_sha256'] = sha(ROOT / 'oracle.py')
    report['controller_sha256'] = sha(Path(__file__))
    report['source_review_sha256'] = sha(ROOT / 'SOURCE_REVIEW.md')
    save()
    for engine in ['baseline', 'candidate', 'expat']:
        command = ['taskset', '-c', '5', PYTHON, '-I', '-S', str(ROOT / 'oracle.py'), engine]
        entry = {'engine': engine, 'command': command, 'status': 'incomplete'}
        report['runs'].append(entry)
        save()
        with (ROOT / (engine + '.stdout')).open('wb') as stdout, (ROOT / (engine + '.stderr')).open('wb') as stderr:
            try:
                active = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True)
                try:
                    entry['exit_code'] = active.wait(timeout=90)
                except subprocess.TimeoutExpired:
                    entry['timeout'] = True
                finally:
                    cleanup()
            finally:
                entry['stdout_sha256'] = sha(ROOT / (engine + '.stdout'))
                entry['stderr_sha256'] = sha(ROOT / (engine + '.stderr'))
                entry['status'] = 'passed' if entry.get('exit_code') == 0 and not entry.get('timeout') else 'failed'
                save()
        print(json.dumps(entry), flush=True)
    engines = {name: json.loads((ROOT / (name + '.json')).read_text()) for name in ['baseline', 'candidate', 'expat']}
    compare = {'candidate_vs_baseline': [], 'expat_vs_baseline': []}
    for name, key in [('candidate', 'candidate_vs_baseline'), ('expat', 'expat_vs_baseline')]:
        assert len(engines[name]['cases']) == len(engines['baseline']['cases']) == 38
        for left, right in zip(engines['baseline']['cases'], engines[name]['cases']):
            assert left['id'] == right['id']
            diff = differences(left, right)
            if diff:
                compare[key].append({'case': left['id'], 'differences': diff})
    (ROOT / 'comparison.json').write_text(json.dumps(compare, indent=2) + '\n')
    report['logical_cases'] = 38
    report['parser_executions'] = sum(len(v['cases']) for v in engines.values())
    report['candidate_vs_baseline_different_cases'] = len(compare['candidate_vs_baseline'])
    report['expat_vs_baseline_different_cases'] = len(compare['expat_vs_baseline'])
    report['invariant_failures'] = {name: [row['id'] for row in data['cases'] if row.get('harness_error') or row.get('invariant_error')] for name, data in engines.items()}
    report['result_sha256'] = {name: sha(ROOT / (name + '.json')) for name in engines}
    report['comparison_sha256'] = sha(ROOT / 'comparison.json')
    report['status'] = 'passed' if all(row['status'] == 'passed' for row in report['runs']) and not compare['candidate_vs_baseline'] else 'failed'
except BaseException:
    report['error'] = traceback.format_exc()
    report['status'] = 'failed'
finally:
    cleanup()
    save()
print(json.dumps(report, indent=2), flush=True)
raise SystemExit(0 if report['status'] == 'passed' else 1)
