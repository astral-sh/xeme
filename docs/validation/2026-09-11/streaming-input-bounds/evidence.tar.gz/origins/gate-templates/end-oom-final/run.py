"""Separate bounded End-tag selected-allocation probe; no original fixtures changed."""
if not __debug__:raise RuntimeError('Assertions required')
from pathlib import Path
import hashlib,json,os,signal,subprocess,time
def terminated(signum,frame):raise InterruptedError(f'signal {signum}')
signal.signal(signal.SIGTERM,terminated)
r=Path(__file__).parent
libs={'baseline':Path('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use/liboriole_expat.so'),'candidate':Path('/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.so')}
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
tracked=[*libs.values(),r/'probe.c',r/'original-allocations.c',r/'expat.h',Path(__file__)]
report={'status':'incomplete','before':{str(p):h(p) for p in tracked},'commands':[],'scope':'Additional dynamic C ASan/UBSan end-tag selected allocation sweep only; Rust release is uninstrumented and leak checking disabled. Original327 allocation scenarios remain separate.'}
save=lambda:(r/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,cmd,env=None):
 row={'label':label,'command':['taskset','-c','5',*cmd],'timeout':120,'start':time.time()};report['commands'].append(row);save();p=None
 with (r/(label+'.stdout')).open('wb') as out,(r/(label+'.stderr')).open('wb') as err:
  try:
   p=subprocess.Popen(row['command'],stdout=out,stderr=err,env=env,start_new_session=True);row['exit']=p.wait(timeout=120)
   if row['exit']:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
  except BaseException as error:
   row['exception']=repr(error)
   if p is not None:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    row['exit']=p.wait()
   raise
  finally:
   out.flush();err.flush();row.update(end=time.time(),stdout_sha256=h(r/(label+'.stdout')),stderr_sha256=h(r/(label+'.stderr')));save()
 assert row['exit']==0,row
try:
 expected={'baseline':'4f1518fc819bf4e8c92da914adea92acf2492cbf681de6324eeece8360186c02','candidate':'8cc1c414442727b3649acea7222e7b5827b309f818f302264840d89952f73a4a'}
 assert all(h(libs[label])==value for label,value in expected.items())
 report['expected_libraries']=expected;save()
 for label,lib in libs.items():
  exe=r/label
  run(label+'-build',['cc','-std=c11','-O1','-g','-Wall','-Wextra','-Werror','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I',str(r),str(r/'probe.c'),str(lib),'-Wl,-rpath,'+str(lib.parent),'-ldl','-o',str(exe)])
  report.setdefault('binaries',{})[label]=h(exe);save()
  run(label,[str(exe),str(lib)],{**os.environ,'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'})
 a=[json.loads(x) for x in (r/'baseline.stdout').read_text().splitlines()];b=[json.loads(x) for x in (r/'candidate.stdout').read_text().splitlines()]
 report['observations_exact']=a==b;report['row_counts']=[len(a),len(b)];report['scenarios']={label:rows[-1] for label,rows in [('baseline',a),('candidate',b)]};assert a==b
 summaries=[row for row in a if row.get('summary')];assert all(row['live']==0 for row in summaries)
 report['failed_indices']=len([row for row in summaries if row['failed']]);report['success_controls']=len([row for row in summaries if not row['failed']]);report['status']='passed'
except BaseException as error:report['exception']=repr(error);raise
finally:
 report['after']={};report['hash_errors']=[]
 for path in tracked:
  try:report['after'][str(path)]=h(path)
  except OSError as error:report['hash_errors'].append({'path':str(path),'error':repr(error)})
 report['unchanged']=report['before']==report['after'] and not report['hash_errors']
 if not report['unchanged']:report['status']='failed_identity'
 save()
assert report['status']=='passed' and report['unchanged']
print(json.dumps({k:report[k] for k in ['status','row_counts','scenarios','failed_indices','success_controls']}))
