"""Exact C callback/position/publication controls; local libraries, no XML I/O."""
if not __debug__:
    raise RuntimeError('Assertions required')
import ctypes as c
import gzip
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT/'tools'))
from xml_abi import Expat,P,S,I,START,END,TEXT,PI,VOID,NS_START,DECL,decode

EXTERNAL=c.CFUNCTYPE(I,P,S,S,S,S)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
ORIGINS={}
LIBRARIES={
    'reference':Path('/home/dev-user/.cache/oriole/expat-build/libexpat.so.1.12.4'),
    'baseline':Path('/tmp/oriole-native-byte-count-pgo-study/pgo/runs/run-7_l2jvbd/use/liboriole_expat.so'),
    'candidate':Path('/tmp/oriole-literal-attribute-check-pgo-study/pgo/runs/run-_j_96iq1/use/liboriole_expat.so'),
}

def binding(path):
    l=Expat(str(path)).lib
    for name,result,args in [
        ('XML_SetDefaultHandler',None,[P,TEXT]),
        ('XML_DefaultCurrent',None,[P]),
        ('XML_GetCurrentByteCount',I,[P]),
        ('XML_GetSpecifiedAttributeCount',I,[P]),
        ('XML_GetIdAttributeIndex',I,[P]),
        ('XML_GetInputContext',P,[P,c.POINTER(I),c.POINTER(I)]),
        ('XML_ExternalEntityParserCreate',P,[P,S,S]),
        ('XML_SetExternalEntityRefHandler',None,[P,EXTERNAL]),
        ('XML_SetParamEntityParsing',I,[P,I]),
        ('XML_SetReparseDeferralEnabled',I,[P,c.c_ubyte]),
        ('XML_StopParser',I,[P,c.c_ubyte]),
        ('XML_ResumeParser',I,[P]),
    ]:
        f=getattr(l,name);f.restype=result;f.argtypes=args
    class Info(c.Structure):
        _fields_=[('filename',S),('base',P),('symbol',S),('address',P)]
    loader=c.CDLL(None);loader.dladdr.argtypes=[P,c.POINTER(Info)];loader.dladdr.restype=I
    rows=[]
    for name in ['XML_Parse','XML_ParserCreate','XML_ExternalEntityParserCreate']:
        info=Info();assert loader.dladdr(c.cast(getattr(l,name),P),c.byref(info))
        origin=Path(info.filename.decode()).resolve();assert origin==path.resolve()
        rows.append({'symbol':name,'path':str(origin),'sha256':sha(origin)})
    ORIGINS[str(path)]=rows
    return l

def parse(l,case):
    events=[];errors=[];kept=[];published=False
    p=l.XML_ParserCreateNS(None,b'|') if case['ns'] else l.XML_ParserCreate(None)
    if not p:raise MemoryError('root')
    def position(parser):
        return [l.XML_GetCurrentByteIndex(parser),l.XML_GetCurrentByteCount(parser),l.XML_GetCurrentLineNumber(parser),l.XML_GetCurrentColumnNumber(parser)]
    def event(parser,depth,name,*values):
        events.append([depth,name,*values,position(parser)])
    def encoded(text,bom=True):
        if case['encoding']=='utf8':return text.encode()
        endian='le' if case['encoding']=='utf16le' else 'be'
        return (bytes.fromhex('fffe' if endian=='le' else 'feff') if bom else b'')+text.encode('utf-16-'+endian)
    def feed(parser,data,final=True):
        width=case['chunk'] or max(1,len(data));status=1
        parts=[data[i:i+width] for i in range(0,len(data),width)] or [b'']
        for i,part in enumerate(parts):
            status=l.XML_Parse(parser,part,len(part),int(final and i==len(parts)-1))
            while status==2:status=l.XML_ResumeParser(parser)
            if status!=1:break
        return status
    def child(parent,depth):
        q=l.XML_ExternalEntityParserCreate(parent,None,None)
        if not q:raise MemoryError('child')
        try:
            callbacks(q,depth)
            status=1 if case['action']=='create-only' else feed(q,encoded(case['dtd']))
            event(q,depth,'child-result',status,l.XML_GetErrorCode(q))
        finally:l.XML_ParserFree(q)
        # Success after a failed child is deliberate: committed DTD prefixes
        # remain visible while the application elects to continue the parent.
        return 1
    def callbacks(parser,depth):
        def safe(fn):
            def wrapped(*args):
                try:return fn(*args)
                except BaseException as error:
                    errors.append(repr(error));return 0
            return wrapped
        def default(_,value,length):
            event(parser,depth,'default',decode(c.string_at(value,length)))
        def start(_,name,attributes):
            pairs=[];i=0
            while attributes[i] is not None:
                pairs.append([decode(attributes[i]),decode(attributes[i+1])]);i+=2
            event(parser,depth,'start',decode(name),pairs,l.XML_GetSpecifiedAttributeCount(parser),l.XML_GetIdAttributeIndex(parser))
            offset=I();size=I();data=l.XML_GetInputContext(parser,c.byref(offset),c.byref(size))
            count=l.XML_GetCurrentByteCount(parser)
            if data:
                assert 0<=offset.value<=size.value and count<=size.value-offset.value
                events.append([depth,'raw-context',c.string_at(data+offset.value,count).hex()])
            l.XML_DefaultCurrent(parser)
            if case['stop'] and depth==0:
                assert l.XML_StopParser(parser,1)==1
        def comment(_,value):
            nonlocal published
            event(parser,depth,'comment',decode(value))
            if depth==0 and case['publication']=='comment' and not published:
                published=True;child(parser,1)
        def external(parent,context,base,system,public):
            event(parser,depth,'external',decode(context),decode(system),decode(public))
            if case['action']=='skip':return 1
            assert parent==parser and depth==0
            return child(parser,depth+1)
        keep=[START(safe(start)),END(safe(lambda _,n:event(parser,depth,'end',decode(n)))),TEXT(safe(lambda _,v,n:event(parser,depth,'text',decode(c.string_at(v,n))))),END(safe(comment)),TEXT(safe(default)),EXTERNAL(safe(external))]
        kept.extend(keep)
        l.XML_SetElementHandler(parser,keep[0],keep[1]);l.XML_SetCharacterDataHandler(parser,keep[2]);l.XML_SetCommentHandler(parser,keep[3]);l.XML_SetDefaultHandler(parser,keep[4]);l.XML_SetExternalEntityRefHandler(parser,keep[5]);l.XML_SetParamEntityParsing(parser,2);l.XML_SetReparseDeferralEnabled(parser,case['deferral'])
    try:
        callbacks(p,0)
        if case['publication']=='partial':
            prefix="<!DOCTYPE r []><r><warm a='v' b='w'/><n a=' one  two ' b='"
            status=feed(p,encoded(prefix),False)
            assert status==1
            child(p,1)
            status=feed(p,encoded("identifier'/></r>",False))
        else:
            status=feed(p,encoded(case['xml']))
        return {'status':status,'error':l.XML_GetErrorCode(p),'position':position(p),'events':events,'callback_errors':errors}
    finally:l.XML_ParserFree(p)

def cases():
    definitions="<!ATTLIST n a NMTOKENS #IMPLIED b ID #REQUIRED extra CDATA 'D'>"
    templates=[
        ('empty',"<!DOCTYPE r []>",'','empty'),
        ('entities',"<!DOCTYPE r [<!ENTITY e 'E'>]>",'','empty'),
        ('unread',"<!DOCTYPE r SYSTEM 'dtd'>",'','skip'),
        ('created',"<!DOCTYPE r SYSTEM 'dtd'>",'','create-only'),
        ('read-empty',"<!DOCTYPE r SYSTEM 'dtd'>",'','empty'),
        ('read-types',"<!DOCTYPE r SYSTEM 'dtd'>",definitions,'empty'),
        ('read-unrelated',"<!DOCTYPE r SYSTEM 'dtd'>","<!ATTLIST other a ID #IMPLIED>",'empty'),
        ('read-failed-prefix',"<!DOCTYPE r SYSTEM 'dtd'>",definitions+'<?','empty'),
    ]
    suffixes=["<r><warm a='v' b='w'/><n a=' one  two ' b='identifier'/></r>","<r><warm a='v'/><n a='v' a='duplicate'/></r>","<r xmlns:p='urn:p'><warm a='v'/><p:n p:a='v'/></r>","<r><warm a='v'/><n a='v' b='&missing;'/></r>"]
    for label,prefix,dtd,action in templates:
        for suffix in suffixes:
            for encoding in ['utf8','utf16le','utf16be']:
                for chunk in [0,1,7]:
                    for ns in [False,True]:
                        for stop in [False,True]:
                            yield dict(label=label,xml=prefix+suffix,dtd=dtd,action=action,publication='external',encoding=encoding,chunk=chunk,ns=ns,stop=stop,deferral=True)
    for publication in ['partial','comment']:
        for dtd in ['',definitions,definitions+'<?',"<!ATTLIST unrelated a ID #IMPLIED>"]:
            for encoding in ['utf8','utf16le','utf16be']:
                for chunk in [0,1,7]:
                    for ns in [False,True]:
                        yield dict(label='dynamic',xml="<!DOCTYPE r []><r><warm a='v' b='w'/><!--publish--><n a=' one  two ' b='identifier'/></r>",dtd=dtd,action='empty',publication=publication,encoding=encoding,chunk=chunk,ns=ns,stop=True,deferral=False)
    # Consume more than the Source compaction threshold, then alternate a
    # warm literal tag and a token above the4KiB Start arena threshold.
    # This remains below max_token and is not a lexical limit rejection.
    compact_xml="<!--"+'x'*70000+"--><!DOCTYPE r []><r><warm a='v'/><n a='literal'/><n a='"+'v'*5000+"'/><n a='last'/></r>"
    for chunk in [7,65536]:
        for ns in [False,True]:
            for stop in [False,True]:
                yield dict(label='compaction-large-fallback',xml=compact_xml,dtd='',action='empty',publication='external',encoding='utf8',chunk=chunk,ns=ns,stop=stop,deferral=True)

if __name__=='__main__':
    import os
    assert os.sched_getaffinity(0)=={5}
    out=ROOT/'publication-probe';out.mkdir(exist_ok=False)
    tracked=[*LIBRARIES.values(),Path(__file__),ROOT/'tools/xml_abi.py']
    before={str(p):sha(p) for p in tracked}
    libraries={name:binding(p) for name,p in LIBRARIES.items()}
    observations=[];differences=[];reference_differences=[]
    failure=None
    try:
        for index,case in enumerate(cases()):
            values={}
            for name,lib in libraries.items():
                values[name]=parse(lib,case)
            observations.append({'case':case,'values':values})
            assert all(not value['callback_errors'] for value in values.values()),(case,values)
            if values['candidate']!=values['baseline']:differences.append(index)
            if values['candidate']!=values['reference']:reference_differences.append(index)
    except BaseException as error:
        failure={'exception':repr(error),'index':index,'case':case,'partial_values':values}
    finally:
        with gzip.open(out/'observations.json.gz','wt') as f:json.dump(observations,f,separators=(',',':'))
    after={};hash_errors=[]
    for path in tracked:
        try:after[str(path)]=sha(path)
        except BaseException as error:hash_errors.append({'path':str(path),'error':repr(error)})
    observations_hash=None
    try:observations_hash=sha(out/'observations.json.gz')
    except BaseException as error:hash_errors.append({'path':str(out/'observations.json.gz'),'error':repr(error)})
    report={'status':'incomplete' if failure or hash_errors or before!=after else 'passed' if not differences else 'differences','failure':failure,'cases':len(observations),'library_parses':len(observations)*3,'candidate_baseline_differences':differences,'candidate_reference_differences':reference_differences,'hashes_before':before,'hashes_after':after,'hash_errors':hash_errors,'origins_before_parses':ORIGINS,'generator_sha256':after.get(str(Path(__file__))),'helper_sha256':after.get(str(ROOT/'tools/xml_abi.py')),'observations_sha256':observations_hash,'scope':'Exact status/errors/all captured callbacks, positions, attribute ID/specified metadata and Start DefaultCurrent/raw context. No normalization or assertion waiver.'}
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k in ['status','cases','library_parses','candidate_baseline_differences']}),flush=True)
    assert report['hashes_before']==report['hashes_after'] and not hash_errors
    assert failure is None, failure
    assert not differences
