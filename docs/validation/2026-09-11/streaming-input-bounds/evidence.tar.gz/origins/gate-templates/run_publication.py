"""Bounded, recorded publication oracle execution."""
import hashlib,json,os,signal,subprocess,time
from pathlib import Path
R=Path('/tmp/oriole-literal-attribute-check-thin-pgo-gates-cpu5');O=R/'publication-launch';O.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cmd=['taskset','-c','5','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S',str(R/'publication_probe.py')]
r={'status':'incomplete','command':cmd,'generator_sha256':sha(R/'publication_probe.py'),'start':time.time(),'timeout':240};save=lambda:(O/'report.json').write_text(json.dumps(r,indent=2)+'\n');save();p=None
try:
 with (O/'stdout').open('wb') as out,(O/'stderr').open('wb') as err:
  try:
   p=subprocess.Popen(cmd,stdout=out,stderr=err,start_new_session=True);r['exit']=p.wait(timeout=240)
  except BaseException as e:
   r['exception']=repr(e)
   if p is not None:
    if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
    r['exit']=p.wait()
   raise
  finally:
   out.flush();err.flush();r['stdout_sha256']=sha(O/'stdout');r['stderr_sha256']=sha(O/'stderr')
 r['status']='passed' if r['exit']==0 else 'failed'
finally:r['end']=time.time();save()
print(json.dumps(r),flush=True)

assert r['status']=='passed' and r['exit']==0
