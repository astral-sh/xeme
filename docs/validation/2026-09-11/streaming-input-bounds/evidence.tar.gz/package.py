"""Deterministic saved-data packages only. No target, compiler or Git writes."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
repo=Path('/home/dev-user/code/oss/oriole-streaming-input-bounds')
doc=repo/'docs/validation/2026-09-11/streaming-input-bounds'
review=Path('/tmp/oriole-streaming-work-timing-independent-review')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def entry(p,destination,purpose):
 p=Path(p);return {'source':str(p),'destination':destination,'bytes':p.stat().st_size,'sha256':sha(p),'purpose':purpose}
def package(label,selection):
 files=selection['files'];seen={};aliases=list(selection.get('additional_aliases',[]));stored=[]
 for row in files:
  p=Path(row['source']);raw=p.read_bytes();assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],str(p)
  assert not raw.startswith(b'\x7fELF') and not any(x in row['destination'] for x in ['.tar.gz','.tar.xz','.zip','.profraw','.profdata'])
  assert not p.is_symlink(),str(p)
  if row['sha256'] in seen:
   aliases.append({'source':row['source'],'destination':row['destination'],'sha256':row['sha256'],'same_bytes_as_destination':seen[row['sha256']]})
  else:seen[row['sha256']]=row['destination'];stored.append(row)
 for a in aliases:
  assert sha(a['source'])==a['sha256']
  canonical=seen[a['sha256']]
  if a['same_bytes_as_destination']!=canonical:
   a['original_same_bytes_as_destination']=a['same_bytes_as_destination'];a['same_bytes_as_destination']=canonical
  assert any(r['destination']==a['same_bytes_as_destination'] and r['sha256']==a['sha256'] for r in stored)
 stored.sort(key=lambda r:r['destination']);assert len({r['destination'] for r in stored})==len(stored)
 archive=doc/(label+'.tar.gz');assert not archive.exists()
 with archive.open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=9) as gz:
   with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tf:
    for row in stored:
     raw=Path(row['source']).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];t=tarfile.TarInfo(row['destination']);t.size=len(raw);t.mtime=0;t.mode=0o644;t.uid=t.gid=0;t.uname=t.gname='';tf.addfile(t,io.BytesIO(raw))
 # Streaming readback verifies every member without extracting or executing it.
 actual=[]
 with tarfile.open(archive,'r|gz') as tf:
  for m in tf:
   assert m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts
   raw=tf.extractfile(m).read();actual.append((m.name,len(raw),hashlib.sha256(raw).hexdigest()))
 assert actual==[(r['destination'],r['bytes'],r['sha256']) for r in stored]
 index={'status':'all_members_read_back','members':stored,'aliases':aliases,'archive':archive.name,'archive_sha256':sha(archive),'excluded':selection.get('excluded',[])}
 ip=doc/(label+'-members.json.gz');ip.write_bytes(gzip.compress(json.dumps(index,sort_keys=True,separators=(',',':')).encode(),mtime=0))
 assert json.loads(gzip.decompress(ip.read_bytes()))==index
 receipt={'status':'passed','scope':'Deterministic producer packaging and complete streaming readback; independent benchmark audits are separate. No executable target or historical nested archive included.','archive':archive.name,'archive_sha256':sha(archive),'compressed_bytes':archive.stat().st_size,'member_index':ip.name,'member_index_sha256':sha(ip),'members':len(stored),'uncompressed_bytes':sum(r['bytes'] for r in stored),'duplicate_source_aliases':len(aliases),'source_selection_count':len(files),'package_generator_sha256':sha(__file__),'excluded':selection.get('excluded',[])}
 rp=doc/(label+'-archive.json');rp.write_text(json.dumps(receipt,indent=2)+'\n');return receipt
# Core selection retains original validation and failure evidence.
selection_path=Path('/tmp/oriole-streaming-input-bounds-study/compact-evidence-files.json');core=load(selection_path)
adversarial=Path('/tmp/oriole-streaming-policy-adversarial-review.json');assert sha(adversarial)=='e958e8f113d2c7ba66f68bbd467012f3a9f36cb4ae5969d02b4d506f901976b3'
if not any(r['source']==str(adversarial) for r in core['files']):core['files'].append(entry(adversarial,'source/adversarial-review.json','Independent adversarial review of consumed-root work policy and boundaries'))
core['file_count']=len(core['files']);core['total_uncompressed_bytes']=sum(r['bytes'] for r in core['files']);selection_path.write_text(json.dumps(core,indent=2)+'\n')
# Add the selection source and exact packager once; no self-referential archive/index member.
core['files']+= [entry(selection_path,'selection.json','Original compact source inventory'),entry(__file__,'package.py','Deterministic package/readback controller')]
core_receipt=package('evidence',core)
# Four immediate campaigns, preserving all workers/specs/stdout/stderr, controllers and failure attempts.
files=[]
for phase in ['normal','pgo']:
 for kind in ['native','python']:
  root=Path('/tmp/oriole-streaming-work-'+phase+'-'+kind+'-study'+('-attempt02' if kind=='python' else ''))
  for p in sorted(root.rglob('*')):
   if not p.is_file() or p.is_symlink():continue
   rel=p.relative_to(root)
   if 'consumers' in rel.parts and not (p.name=='build.json' or p.name.endswith('-build.log')):continue
   assert p.suffix in ['.json','.py','.patch','.log','.gz'],str(p)
   files.append(entry(p,f'{kind}-{phase}/{rel}','Immediate campaign controller, raw observations or consumer build/origin record'))
for phase in ['normal','pgo']:
 root=Path('/tmp/oriole-streaming-work-'+phase+'-python-study')
 for p in sorted(root.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(root)
  if 'consumers' in rel.parts and not (p.name=='build.json' or p.name.endswith('-build.log')):continue
  files.append(entry(p,f'python-{phase}-initial-preparation/{rel}','Retained first normal CPU guard failure, successful build, or unexecuted originalPGO preparation'))
for p in sorted(review.rglob('*')):
 if p.is_file():files.append(entry(p,'independent-review/'+str(p.relative_to(review)),'Independent saved numerical audits and compressed raw-input indexes'))
for name in ['source.json','pair-report.json','pair-freeze.json','vector-training-proof.json']:
 p=Path('/tmp/oriole-streaming-work-pgo-study-attempt02')/name;files.append(entry(p,'build/'+name,'Candidate source and exact normal/PGO build bindings; binaries excluded'))
for phase in ['normal','pgo']:
 for kind in ['native','python']:
  root=Path('/tmp/oriole-ascii-prefix-iterator-'+phase+'-native-study') if kind=='native' else Path('/tmp/oriole-literal-attribute-'+phase+'-python-study')
  for name in (['native_screen.py','run.py'] if kind=='native' else ['build_consumers.py','consumer_screen.py','python_worker.py','run.py']):files.append(entry(root/name,f'templates/{kind}-{phase}/{name}','Exact parent controller source for minimal adaptation proof'))
files.append(entry('/tmp/oriole-literal-attribute-python-protocol-independent-review/review.json','templates/python-worker-source-review.json','Prior independent protocol proof reused only for unchanged worker bytes'))
files.append(entry('/tmp/oriole-literal-attribute-check-pgo-study/pair-report.json','build/accepted-control-pair-report.json','Accepted attribute normal/PGO parser control identities'))
for name in ['readme-benchmark.py','readme-benchmark.json']:files.append(entry(doc/name,'readme/'+name,'Current six-condition table reconstructed from84worker medians and42pair ratios'))
for name in ['native_driver.c','projects/corpus-manifest.json','projects/README.md','projects/RERUN.md']:
 files.append(entry(repo/'benchmarks'/name,'source/benchmarks/'+name,'Native driver source and corpus provenance; binary is hash-pinned separately'))
# Inputs already published in repository: retain exact fixture bytes and accompanying notices.
for p in sorted((repo/'benchmarks/projects/corpus').rglob('*')):
 if p.is_file():files.append(entry(p,'source/benchmarks/projects/corpus/'+str(p.relative_to(repo/'benchmarks/projects/corpus')),'Original sixproject fixture and license/notice bytes'))
for p,dest in [('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml','inputs/generated-rare-declarations.xml'),('/tmp/oriole-grammar-bench-plain/entities.xml','inputs/generated-entities.xml'),('/tmp/oriole-streaming-work-elapsed-sequence.json','elapsed-sequence.json')]:files.append(entry(p,dest,'Generatedcontrol input or original root sequential launch receipt'))
sourcepaths=load('/tmp/oriole-streaming-work-normal-python-study-attempt02/consumers/build.json')['source_sha256_before']
for p in sourcepaths:
 if '/Modules/' in p:files.append(entry(p,'source/cpython/Modules/'+Path(p).name,'Exact unmodified CPython source compiled for benchmark consumer; strictcleanup patch is separate'))
files.append(entry(repo/'include/expat.h','source/include/expat.h','Common unchanged header used for all benchmark consumer builds'))
files.append(entry(__file__,'package.py','Deterministic package/readback controller'))
bench={'files':files,'excluded':['Parser libraries, static archives, native driver binary, Python interpreter and all compiled consumer extensions; these remain identified by recorded path/hash and origin receipts.','Target/build caches, profile data, nested historical archives, full CPython trees and unrelated study outputs.','Strict cleanup-patched consumer timings: benchmark consumer source is unmodified CPython3.12.13.']}
bench_receipt=package('benchmark-evidence',bench)
print(json.dumps({'status':'passed','core':core_receipt,'benchmark':bench_receipt},indent=2))
