import collections,hashlib,json,pathlib,re
P=pathlib.Path('/tmp/oriole-real-pgo-training-study');S=pathlib.Path('/home/dev-user/code/oss/oriole-cdata-finder')
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def normalized(events):
 out=[]
 for event in events:
  if event[0]=='text' and out and out[-1][0]=='text':out[-1][1]+=event[1]
  else:out.append(event.copy())
 return out
prep=read(P/'preparation.json');pre=read(P/'normal-preflight.json')
assert sha(P/'preparation.json')=='f6c314e0b60bf3a6e12a5e3343dd32b920d450fd29a26fb37b217c9ae3f5b773'
assert pre['status']==prep['status']=='passed' and pre['preparation_sha256']==sha(P/'preparation.json')
for key,name in [('prepare_sha256','prepare.py'),('controller_sha256','build_arms.py'),('preflight_sha256','preflight_real.py'),('normal_preflight_controller_sha256','run_normal_preflight.py'),('semantic_probe_sha256','preflight-support/xml_abi.py')]:assert sha(P/name)==prep[key]
assert len(prep['oriole_source_sha256'])==70 and len(prep['pipeline_source_sha256'])==67
for name,h in prep['oriole_source_sha256'].items():assert sha(S/name)==h
for name,h in prep['pipeline_source_sha256'].items():assert prep['oriole_source_sha256'][name]==h
for name,h in prep['pipeline_sha256'].items():assert sha(P/'pipeline/tools/pgo'/name)==h
for name,h in prep['inputs_sha256'].items():assert sha(name)==h
realpath=pathlib.Path(prep['real_inputs']['manifest']);real=read(realpath)
assert sha(realpath)==prep['real_inputs']['manifest_sha256']
assert len(real['documents'])==6 and sum(r['bytes'] for r in real['documents'])==503245
G=P/'normal-generated-inputs';gen=read(G/'manifest.json')
oldgen=pathlib.Path('/tmp/oriole-cdata-finder-pgo-study/pgo/runs/run-sjsgpms8/inputs')
assert sha(G/'manifest.json')==sha(oldgen/'manifest.json')
assert len(gen['rows'])==12
for row in gen['rows']:
 assert sha(G/row['file'])==sha(oldgen/row['file'])==row['sha256']
 assert (G/row['file']).stat().st_size==row['bytes']
expected_training=[]
for f in gen['rows']:
 assert f['chunks']==[1 if f['name']=='latin1' else 17,4096,65536] and f['namespaces']==[False,True]
 for ns in [False,True]:
  for chunk in f['chunks']:
   for handlers in ['minimal','full']:
    for iteration in range(2):expected_training.append((f['name'],ns,chunk,handlers,iteration))
for f in real['documents']:
 for ns in [False,True]:
  for chunk in [4096,65536]:
   for handlers in ['minimal','full']:expected_training.append(('real/'+f['id'],ns,chunk,handlers,0))
assert len(expected_training)==336
expected_rich=[('real/'+d['id'],ns,chunk) for d in real['documents'] for ns in [False,True] for chunk in [4096,65536]]
assert len(pre['commands'])==4
for index,c in enumerate(pre['commands']):
 assert c['exit']==0 and c['cpu']==5 and c['timeout']==600
 assert c['argv'][0:3]==['/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S']
 assert sha(P/(c['label']+'.log'))==c['log_sha256']
 assert c['end']>=c['start']
 if index:assert c['start']>=pre['commands'][index-1]['end']
training={};rich={};rich_summary={};origins={};pins={}
for engine in ['oriole','expat']:
 lib=prep['normal_libraries'][engine];assert sha(lib['path'])==lib['sha256']
 origin={'path':str(pathlib.Path(lib['path']).resolve()),'sha256':lib['sha256']};origins[engine]=origin
 tr=pre['exact_training_reports'][engine];assert sha(tr['path'])==tr['sha256'];t=read(tr['path']);pins[tr['path']]=tr['sha256']
 assert t['status']=='passed' and t['xml_parse_origin']==origin and t['library_sha256']==lib['sha256']
 assert t['inputs_sha256']==sha(G/'manifest.json') and t['experimental_real_inputs']==prep['real_inputs']
 assert t['script_sha256']==prep['pipeline_sha256']['train.py']
 assert t['real_input_script_sha256']==prep['pipeline_sha256']['real_inputs.py']
 assert t['profile_file_environment'] is None
 assert [(r['fixture'],r['namespaces'],r['chunk'],r['handlers'],r['iteration']) for r in t['rows']]==expected_training
 for r in t['rows']:
  assert r['status']==1 and r['error']==0 and r['callback_exceptions']==[]
  assert re.fullmatch('[0-9a-f]{64}',r['callback_sha256'])
  assert all(type(v)is int and v>=0 for v in r['counts'].values())
 for i in range(0,288,2):
  assert {k:v for k,v in t['rows'][i].items() if k!='iteration'}=={k:v for k,v in t['rows'][i+1].items() if k!='iteration'}
 training[engine]=t['rows']
 rp=P/('real-preflight-'+engine)/'report.json';r=read(rp);pins[str(rp)]=sha(rp)
 assert r['status']=='passed' and r['preparation_sha256']==sha(P/'preparation.json') and r['engine']==engine
 assert r['origin']==origin and r['real']==prep['real_inputs']
 assert r['version']==('oriole_compat_2.8.4' if engine=='oriole' else 'expat_2.8.4')
 assert [(x['document'],x['namespaces'],x['chunk']) for x in r['rows']]==expected_rich
 rich[engine]=[];rich_summary[engine]=[]
 for row in r['rows']:
  assert sha(row['path'])==row['sha256'];pins[row['path']]=row['sha256'];raw=read(row['path'])
  assert all(raw[k]==row[k] for k in ['document','namespaces','chunk'])
  result=raw['result'];assert result['status']==1 and result['error']==0 and result['callback_errors']==[]
  n=normalized(result['events']);assert n==result['normalized_events']
  rich[engine].append(result)
  rich_summary[engine].append({'document':row['document'],'namespaces':row['namespaces'],'chunk':row['chunk'],'events':len(result['events']),'normalized_events':len(n),'event_counts':dict(collections.Counter(x[0] for x in result['events'])),'position':result['position']})
 for i in range(0,24,2):assert rich[engine][i]['normalized_events']==rich[engine][i+1]['normalized_events']
comparisons=[]
for key,a,b in zip(expected_rich,rich['oriole'],rich['expat'],strict=True):
 x=dict(zip(['document','namespaces','chunk'],key));x.update(normalized_callbacks_equal=a['normalized_events']==b['normalized_events'],exact_callbacks_equal=a['events']==b['events'],final_positions_equal=a['position']==b['position']);comparisons.append(x)
assert comparisons==pre['semantic_comparisons']
assert all(r['normalized_callbacks_equal'] and r['final_positions_equal'] for r in comparisons)
report={'status':'passed_saved_normal_preflight_audit','preparation_sha256':sha(P/'preparation.json'),'normal_preflight_sha256':sha(P/'normal-preflight.json'),'normal_origins':origins,'source_files_verified':70,'pipeline_source_subset':67,'generated_manifest_sha256':sha(G/'manifest.json'),'original_generated_manifest_exact':True,'real_manifest_sha256':sha(realpath),'commands':4,'rich_cases':48,'cross_engine_semantic_comparisons':24,'normalized_equal':sum(x['normalized_callbacks_equal'] for x in comparisons),'exact_equal':sum(x['exact_callbacks_equal'] for x in comparisons),'final_positions_equal':sum(x['final_positions_equal'] for x in comparisons),'comparisons':comparisons,'per_engine_rich_summary':rich_summary,'exact_training_records':672,'per_engine_training':{'generated':288,'real':48,'generated_repeated_pairs_equal':144},'cross_engine_exact_training_rows_equal':sum(a==b for a,b in zip(training['oriole'],training['expat'],strict=True)),'raw_files_sha256':pins,'limitations':['Read-only saved audit; no parser/library/compiler/profile execution.','Exact callback differences are retained: normalized rich traces and final positions match all24 configurations; exact rich traces match only the four Inkscape blend-mode cases.','Exact training digests remain fragmentation-sensitive, so cross-engine digest equality is not the semantic oracle. Normal/gen/use exact comparison must remain within each engine.','There is one real parse percondition in each normal training replay; generated conditions retain their two fresh repetitions. No repeated real target invocation was added.'],'reader_sha256':sha(pathlib.Path(__file__))}
out=P/'normal-preflight-independent-review.json';out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','rich_cases','normalized_equal','exact_equal','final_positions_equal','exact_training_records','cross_engine_exact_training_rows_equal']}|{'path':str(out),'sha256':sha(out)},indent=2))
