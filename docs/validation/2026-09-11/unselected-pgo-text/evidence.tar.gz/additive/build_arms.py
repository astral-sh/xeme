"""One fixed generated-only versus additive-real PGO experiment, both engines."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/dev-user/code/oss/oriole-cdata-finder')
EXPAT_SOURCE = Path('/tmp/oriole-pgo-study/expat-source')
PIPELINE = ROOT / 'pipeline/tools/pgo'
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
PROFDATA = '/tmp/oriole-pgo-study/llvm-tools-1.98.0/bin/llvm-profdata'
REAL = Path('/tmp/oriole-real-pgo-training-inputs/manifest.json')
BASELINE = Path('/home/dev-user/.cache/oriole/expat-build')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def files(directory):
    return {str(p.relative_to(directory)): sha(p) for p in sorted(directory.rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts}


assert os.sched_getaffinity(0) == {3}
assert len(sys.argv) == 3 and sys.argv[1] in ('oriole', 'expat') and sys.argv[2] in ('g', 'gr')
engine, arm = sys.argv[1:]
PREPARATION = read(ROOT / 'preparation.json')
assert PREPARATION['status'] == 'passed'
PREFLIGHT = read(ROOT / 'normal-preflight.json')
assert PREFLIGHT['status'] == 'passed' and PREFLIGHT['preparation_sha256'] == sha(ROOT / 'preparation.json')
assert PREPARATION['controller_sha256'] == sha(__file__)
assert PREPARATION['pipeline_sha256'] == files(PIPELINE)
assert all(sha(SOURCE / p) == h for p, h in PREPARATION['oriole_source_sha256'].items())
assert all(sha(EXPAT_SOURCE / p) == h for p, h in PREPARATION['expat_source_sha256'].items())
assert all(sha(p) == h for p, h in PREPARATION['inputs_sha256'].items())
assert all(sha(p) == h for p, h in PREPARATION['gcc_tools_sha256'].items())
assert not {k: v for k, v in os.environ.items() if k.startswith('CARGO_PROFILE_')}
OUT = ROOT / (engine + '-' + arm)
OUT.mkdir(exist_ok=False)
env = os.environ.copy()
cleared = ['RUSTC', 'RUSTFLAGS', 'LLVM_PROFILE_FILE', 'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST',
           'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST', 'CFLAGS', 'CXXFLAGS', 'CPPFLAGS', 'LDFLAGS',
           'GCOV_PREFIX', 'GCOV_PREFIX_STRIP', 'GCOV_ERROR_FILE', 'GCOV_EXIT_AT_ERROR']
for key in cleared:
    env.pop(key, None)
overrides = {'CARGO_HOME': '/home/dev-user/.cache/toucan/cargo',
             'CARGO_TARGET_DIR': '/home/dev-user/.cache/oriole/targets/real-pgo-training',
             'CARGO_BUILD_BUILD_DIR': '/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}',
             'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0', 'RUSTC_WRAPPER': '',
             'RUSTC_WORKSPACE_WRAPPER': '', 'CARGO_ENCODED_RUSTFLAGS': '',
             'RUSTUP_AUTO_INSTALL': '0', 'CARGO_TERM_COLOR': 'never', 'CC': '/usr/bin/cc',
             'CXX': '/usr/bin/c++', 'PYTHONDONTWRITEBYTECODE': '1'}
env.update(overrides)
REPORT = {'status': 'incomplete', 'engine': engine, 'arm': arm,
          'preparation_sha256': sha(ROOT / 'preparation.json'), 'normal_preflight_sha256': sha(ROOT / 'normal-preflight.json'), 'commands': [],
          'cleared_environment': cleared, 'environment_overrides': overrides,
          'scope': 'Fresh G versus G+R profiles for fixed PR128 runtime and pinned Expat2.8.4. '
                   'Generated schedule unchanged; G+R adds one pass per six pinned real inputs, '
                   '4/64KiB, plain/namespace, minimal/full. No held-out timing or source tuning.'}


def save():
    (OUT / 'report.json').write_text(json.dumps(REPORT, indent=2) + '\n')


def run(label, argv, timeout=900, environment=env):
    row = {'label': label, 'argv': argv, 'cwd': str(SOURCE), 'cpu': 3,
           'timeout': timeout, 'start': time.time()}
    REPORT['commands'].append(row)
    save()
    process = None
    log = OUT / (label + '.log')
    with log.open('wb') as stream:
        try:
            process = subprocess.Popen(argv, cwd=SOURCE, env=environment, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            row['exit'] = process.wait(timeout=timeout)
            if row['exit']:
                raise RuntimeError(f'{label}: exit {row["exit"]}')
        except BaseException as error:
            row['exception'] = repr(error)
            if process is not None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                row['exit'] = process.wait()
            raise
        finally:
            stream.flush()
            row.update(end=time.time(), log_sha256=sha(log))
            save()
    print(engine, arm, label, row['exit'], flush=True)
    return log.read_text()


def train(library, inputs, phase):
    argv = [PYTHON, '-I', '-S', str(PIPELINE / 'train.py'), '--library', str(library),
            '--inputs', str(inputs), '--report', str(OUT / (phase + '-training.json'))]
    if arm == 'gr':
        argv += ['--experimental-real-manifest', str(REAL), '--experimental-real-manifest-sha256', PREPARATION['inputs_sha256'][str(REAL)]]
    run(phase + '-training', argv, 600)
    result = read(OUT / (phase + '-training.json'))
    assert result['status'] == 'passed' and len(result['rows']) == (336 if arm == 'gr' else 288)
    assert result['library_sha256'] == sha(library)
    assert result['xml_parse_origin'] == {'path': str(library.resolve()), 'sha256': sha(library)}
    assert result['inputs_sha256'] == sha(inputs / 'manifest.json')
    return result


try:
    if engine == 'oriole':
        argv = [PYTHON, '-I', '-S', str(PIPELINE / 'build.py'), '--source', str(SOURCE),
                '--output', str(OUT / 'pgo'), '--llvm-profdata', PROFDATA, '--toolchain', 'ohm',
                '--cargo-arg=-Zohm-defaults=no', '--command-timeout', '900']
        if arm == 'gr':
            argv += ['--experimental-real-manifest', str(REAL), '--experimental-real-manifest-sha256', PREPARATION['inputs_sha256'][str(REAL)]]
        run('pipeline', argv, 2400)
        latest = read(OUT / 'pgo/latest.json')
        manifest_path = Path(latest['manifest'])
        assert sha(manifest_path) == latest['sha256']
        manifest = read(manifest_path)
        assert manifest['status'] == 'passed'
        assert manifest['compared_parses'] == (336 if arm == 'gr' else 288)
        assert manifest['source_sha256'] == PREPARATION['pipeline_source_sha256']
        assert sha(PREFLIGHT['exact_training_reports'][engine]['path']) == PREFLIGHT['exact_training_reports'][engine]['sha256']
        normal_report = read(PREFLIGHT['exact_training_reports'][engine]['path'])
        assert read(manifest_path.parent / 'generate-training.json')['rows'] == (normal_report['rows'] if arm == 'gr' else normal_report['rows'][:288])
        REPORT['manifest'] = {'path': str(manifest_path), 'sha256': sha(manifest_path)}
        REPORT['libraries'] = {phase: {'path': str(manifest_path.parent / phase / 'liboriole_expat.so'),
                                      'sha256': sha(manifest_path.parent / phase / 'liboriole_expat.so')}
                               for phase in ('generate', 'use')}
    else:
        inputs = OUT / 'inputs'
        run('generate-inputs', [PYTHON, '-I', '-S', '-c',
                                'from pathlib import Path; import sys; sys.path.insert(0, sys.argv[1]); '
                                'from pgo.corpus import generate; generate(Path(sys.argv[2]))',
                                str(PIPELINE.parent), str(inputs)], 30)
        raw = OUT / 'raw'
        raw.mkdir()
        cache = (BASELINE / 'CMakeCache.txt').read_text()
        features = dict(re.findall(r'^(EXPAT_[A-Z0-9_]+):(?:BOOL|STRING|UNINITIALIZED)=(.*)$', cache, re.M))
        REPORT['features'] = features
        REPORT['compiler_version'] = run('compiler-version', ['/usr/bin/cc', '--version'], 30)
        REPORT['tools_sha256'] = PREPARATION['gcc_tools_sha256']
        reports = []
        REPORT['libraries'] = {}
        for phase in ('generate', 'use'):
            build = OUT / (phase + '-build')
            flag = '-fprofile-generate=' if phase == 'generate' else '-fprofile-use='
            flags = flag + str(raw) + ' -fprofile-prefix-path=' + str(build)
            if phase == 'generate':
                assert not list(raw.iterdir())
            else:
                assert REPORT['profiles_sha256'] == files(raw)
            argv = ['/usr/bin/cmake', '-S', str(EXPAT_SOURCE), '-B', str(build), '-G', 'Unix Makefiles',
                    '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_C_COMPILER=/usr/bin/cc',
                    '-DCMAKE_C_FLAGS=' + flags, '-DCMAKE_C_FLAGS_RELEASE=-O3 -DNDEBUG',
                    *[f'-D{k}={v}' for k, v in features.items()]]
            run(phase + '-configure', argv)
            log = run(phase + '-build', ['/usr/bin/cmake', '--build', str(build), '--target', 'expat',
                                        '--parallel', '1', '--verbose'])
            assert not re.search(r'warning:|error:', log, re.I), 'Expat compilation warning/error'
            assert sha(build / 'expat_config.h') == PREPARATION['expat_config_sha256']
            library = OUT / (phase + '-libexpat.so')
            shutil.copyfile(build / 'libexpat.so', library)
            REPORT['libraries'][phase] = {'path': str(library), 'sha256': sha(library)}
            result = train(library, inputs, phase)
            reports.append(result)
            if phase == 'generate':
                profiles = files(raw)
                assert len(profiles) == 7 and all(n.startswith('CMakeFiles#expat.dir#lib#') and
                                                 n.endswith('.gcda') for n in profiles)
                REPORT['profiles_sha256'] = profiles
                run('profile-counts', ['/usr/bin/gcov-dump', '-l', *[str(raw / n) for n in profiles]], 60)
            else:
                assert REPORT['profiles_sha256'] == files(raw)
            save()
        assert reports[0]['rows'] == reports[1]['rows']
        assert sha(PREFLIGHT['exact_training_reports'][engine]['path']) == PREFLIGHT['exact_training_reports'][engine]['sha256']
        normal_report = read(PREFLIGHT['exact_training_reports'][engine]['path'])
        assert reports[0]['rows'] == (normal_report['rows'] if arm == 'gr' else normal_report['rows'][:288])
        REPORT['compared_parses'] = len(reports[0]['rows'])
    REPORT['status'] = 'passed'
except BaseException as error:
    REPORT['failure'] = repr(error)
    raise
finally:
    REPORT['unchanged'] = {
        'oriole_source': all(sha(SOURCE / p) == h for p, h in PREPARATION['oriole_source_sha256'].items()),
        'expat_source': all(sha(EXPAT_SOURCE / p) == h for p, h in PREPARATION['expat_source_sha256'].items()),
        'pipeline': PREPARATION['pipeline_sha256'] == files(PIPELINE),
        'inputs': all(sha(p) == h for p, h in PREPARATION['inputs_sha256'].items()),
        'tools': all(sha(p) == h for p, h in PREPARATION['gcc_tools_sha256'].items()),
    }
    if not all(REPORT['unchanged'].values()):
        REPORT['status'] = 'failed-input-change'
    save()
assert REPORT['status'] == 'passed'
print(json.dumps({'status': REPORT['status'], 'engine': engine, 'arm': arm,
                  'libraries': REPORT.get('libraries')}), flush=True)
