"""Pinned inputs for one external-only, additive PGO training experiment."""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

SELECTED_RUNTIME = "78c748d9de5c497858458cbf7a1229148781b2bf"
MAX_FILE_BYTES = 1024 * 1024
MAX_TOTAL_BYTES = 4 * MAX_FILE_BYTES
REAL_PARSE_COUNT = 48


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256(value: Any) -> str:
    if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise ValueError("Expected a lowercase SHA256")
    return value


def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def pinned_file(root: Path, filename: Any, expected: Any) -> bytes:
    """Read a bounded regular file inside the manifest directory, without symlinks."""
    if not isinstance(filename, str) or not filename:
        raise ValueError("Expected a relative input filename")
    relative = PurePosixPath(filename)
    if (
        relative.is_absolute()
        or str(relative) != filename
        or ".." in relative.parts
        or "\\" in filename
    ):
        raise ValueError("Input filenames must stay inside the manifest directory")
    path = root
    for part in relative.parts:
        path /= part
        if path.is_symlink():
            raise ValueError("Symlink input paths are not supported")
    if not path.is_file() or not path.resolve().is_relative_to(root):
        raise ValueError("Input must be a regular file inside the manifest directory")
    expected = sha256(expected)
    if not 0 < path.stat().st_size <= MAX_FILE_BYTES:
        raise ValueError("Input file exceeds its size bound or is empty")
    with path.open("rb") as stream:
        data = stream.read(MAX_FILE_BYTES + 1)
    if not 0 < len(data) <= MAX_FILE_BYTES or digest(data) != expected:
        raise ValueError(f"Pinned input content changed: {filename}")
    return data


@dataclass(frozen=True)
class RealDocument:
    name: str
    file: str
    data: bytes


@dataclass(frozen=True)
class RealInputs:
    manifest: Path
    manifest_sha256: str
    documents: tuple[RealDocument, ...]
    files_sha256: dict[str, str]

    def provenance(self) -> dict[str, Any]:
        return {
            "manifest": str(self.manifest),
            "manifest_sha256": self.manifest_sha256,
            "files_sha256": self.files_sha256.copy(),
            "documents": len(self.documents),
            "unique_input_bytes": sum(
                len(document.data) for document in self.documents
            ),
            "additional_parses": REAL_PARSE_COUNT,
            "selected_runtime": SELECTED_RUNTIME,
        }

    def require_unchanged(self) -> None:
        current = load_real_inputs(self.manifest, self.manifest_sha256)
        if current is None or current.provenance() != self.provenance():
            raise ValueError("Experimental real training inputs changed")


def load_real_inputs(manifest: Path | None, expected: str | None) -> RealInputs | None:
    """Validate all extra bytes before parser loading; never relax generated guards."""
    if manifest is None and expected is None:
        return None
    if manifest is None or expected is None:
        raise ValueError(
            "Real manifest and its explicit SHA256 must be supplied together"
        )
    expected = sha256(expected)
    if manifest.is_symlink():
        raise ValueError("Real manifest must not be a symlink")
    manifest = manifest.resolve(strict=True)
    if not manifest.is_file() or not 0 < manifest.stat().st_size <= 256 * 1024:
        raise ValueError("Real manifest exceeds its size bound or is empty")
    with manifest.open("rb") as stream:
        raw = stream.read(256 * 1024 + 1)
    if digest(raw) != expected or len(raw) > 256 * 1024:
        raise ValueError("Real manifest SHA256 mismatch")
    value = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_object)
    if not isinstance(value, dict):
        raise ValueError("Real manifest must be an object")
    if type(value.get("schema_version")) is not int or value["schema_version"] != 1:
        raise ValueError("Unsupported real manifest schema")
    if value.get("selected_runtime") != SELECTED_RUNTIME:
        raise ValueError("Real manifest must select the frozen Finder runtime")
    if not isinstance(value.get("criteria"), dict):
        raise ValueError("Real manifest must retain selection criteria")
    schedule = value.get("schedule")
    if (
        not isinstance(schedule, dict)
        or set(schedule) != {"chunks", "namespaces", "handlers", "iterations"}
        or schedule.get("chunks") != [4096, 65536]
        or any(type(v) is not int for v in schedule["chunks"])
        or schedule.get("namespaces") != [False, True]
        or any(type(v) is not bool for v in schedule["namespaces"])
        or schedule.get("handlers") != ["minimal", "full"]
        or type(schedule.get("iterations")) is not int
        or schedule["iterations"] != 1
    ):
        raise ValueError("Real training schedule changed")
    rows = value.get("documents")
    if not isinstance(rows, list) or len(rows) != 6:
        raise ValueError("Exactly six real documents are required")
    names: set[str] = set()
    files: dict[str, str] = {}
    documents: list[RealDocument] = []
    categories: Counter[str] = Counter()
    repositories: Counter[str] = Counter()
    hashes: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("Real document must be an object")
        name = row.get("id")
        if (
            not isinstance(name, str)
            or re.fullmatch(r"[a-z0-9][a-z0-9_-]*", name) is None
        ):
            raise ValueError("Invalid real document id")
        if name in names:
            raise ValueError("Duplicate real document id")
        names.add(name)
        category = row.get("category")
        if category not in ("config", "mixed_content", "namespaces"):
            raise ValueError("Unexpected real document category")
        categories[category] += 1
        repository = row.get("repository")
        if not isinstance(repository, str) or not repository.startswith("https://"):
            raise ValueError("Expected a canonical HTTPS repository URL")
        repositories[repository] += 1
        for key in ("upstream_path", "canonical_url"):
            if not isinstance(row.get(key), str) or not row[key]:
                raise ValueError(f"Missing upstream provenance: {key}")
        if not row["canonical_url"].startswith("https://"):
            raise ValueError("Expected a canonical HTTPS input URL")
        if (
            not isinstance(row.get("commit"), str)
            or re.fullmatch(r"[0-9a-f]{40}", row["commit"]) is None
        ):
            raise ValueError("Expected a pinned upstream commit")
        if not isinstance(row.get("structure"), dict):
            raise ValueError("Expected reviewed input structure metadata")
        filename = row.get("file")
        data = pinned_file(manifest.parent, filename, row.get("sha256"))
        if filename in files or row["sha256"] in hashes:
            raise ValueError("Duplicate real input path or content")
        if type(row.get("bytes")) is not int or row["bytes"] != len(data):
            raise ValueError("Real input byte length changed")
        if row.get("encoding") != "UTF-8":
            raise ValueError("Real inputs must declare UTF-8")
        text = data.decode("utf-8", errors="strict")
        declaration = re.match(r"\ufeff?<\?xml\s+([^?]*)\?>", text)
        if declaration:
            encoding = re.search(r"encoding\s*=\s*(['\"])([^'\"]+)\1", declaration[1])
            if encoding and encoding[2].lower() != "utf-8":
                raise ValueError("XML declaration must select UTF-8")
        files[filename] = row["sha256"]
        hashes.add(row["sha256"])
        documents.append(RealDocument("real/" + name, filename, data))
        notices = row.get("license_files")
        if not isinstance(notices, list) or not notices:
            raise ValueError("Real input must pin its license notices")
        for notice in notices:
            if not isinstance(notice, dict) or set(notice) != {"file", "sha256"}:
                raise ValueError("Invalid pinned license notice")
            pinned_file(manifest.parent, notice["file"], notice["sha256"])
            previous = files.setdefault(notice["file"], notice["sha256"])
            if previous != notice["sha256"]:
                raise ValueError("Conflicting notice hashes")
    if categories != {"config": 2, "mixed_content": 2, "namespaces": 2}:
        raise ValueError("Real inputs must include exactly two documents per category")
    if len(repositories) != 3 or sorted(repositories.values()) != [2, 2, 2]:
        raise ValueError("Real inputs must come from exactly three project pairs")
    if sum(len(document.data) for document in documents) > MAX_TOTAL_BYTES:
        raise ValueError("Combined real inputs exceed four MiB")
    return RealInputs(manifest, expected, tuple(documents), files)
