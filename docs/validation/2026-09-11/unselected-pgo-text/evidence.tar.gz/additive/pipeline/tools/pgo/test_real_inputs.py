"""External experiment checks; parser libraries are never invoked by these tests."""

import ast
import copy
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from pgo import build, train
from pgo.corpus import documents, generate
from pgo.real_inputs import SELECTED_RUNTIME, digest, load_real_inputs


class RealInputTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.manifest = self.root / "manifest.json"
        notice = self.root / "LICENSE"
        notice.write_bytes(b"Synthetic unit-test fixture notice\n")
        rows = []
        for index in range(6):
            filename = f"fixture-{index}.xml"
            data = f"<root id='{index}'>text</root>".encode()
            (self.root / filename).write_bytes(data)
            rows.append(
                {
                    "id": f"fixture-{index}",
                    "category": ["config", "mixed_content", "namespaces"][index // 2],
                    "file": filename,
                    "bytes": len(data),
                    "sha256": digest(data),
                    "encoding": "UTF-8",
                    "repository": f"https://example.invalid/project-{index // 2}",
                    "commit": "1" * 40,
                    "upstream_path": filename,
                    "canonical_url": f"https://example.invalid/raw/{filename}",
                    "license_files": [
                        {"file": "LICENSE", "sha256": digest(notice.read_bytes())}
                    ],
                    "structure": {"test_fixture": True},
                }
            )
        self.value: dict[str, Any] = {
            "schema_version": 1,
            "selected_runtime": SELECTED_RUNTIME,
            "criteria": {"synthetic_unit_tests_only": True},
            "documents": rows,
            "schedule": {
                "chunks": [4096, 65536],
                "namespaces": [False, True],
                "handlers": ["minimal", "full"],
                "iterations": 1,
            },
        }

    def save(self, value=None):
        self.manifest.write_text(json.dumps(self.value if value is None else value))
        return digest(self.manifest.read_bytes())

    def test_valid_snapshot_and_disabled_mode(self):
        self.assertIsNone(load_real_inputs(None, None))
        real = load_real_inputs(self.manifest, self.save())
        self.assertIsNotNone(real)
        assert real is not None
        self.assertEqual(len(real.documents), 6)
        self.assertEqual(real.provenance()["additional_parses"], 48)
        self.assertEqual(len(real.files_sha256), 7)
        self.assertEqual(real.documents[0].name, "real/fixture-0")
        real.require_unchanged()

    def test_manifest_pin_required_and_tampering_rejected_before_library_load(self):
        expected = self.save()
        for manifest, pin in [
            (None, expected),
            (self.manifest, None),
            (self.manifest, "0" * 64),
        ]:
            with (
                self.subTest(manifest=manifest, pin=pin),
                self.assertRaises(ValueError),
            ):
                load_real_inputs(manifest, pin)
        args = [
            "train.py",
            "--library",
            "never-loaded.so",
            "--inputs",
            str(self.root),
            "--report",
            str(self.root / "report.json"),
            "--experimental-real-manifest",
            str(self.manifest),
            "--experimental-real-manifest-sha256",
            "0" * 64,
        ]
        with patch.object(sys, "argv", args), patch("pgo.train.c.CDLL") as library:
            with self.assertRaisesRegex(ValueError, "SHA256 mismatch"):
                train.main()
            library.assert_not_called()
        self.manifest.write_text('{"schema_version":1,"schema_version":1}')
        with self.assertRaisesRegex(ValueError, "Duplicate JSON key"):
            load_real_inputs(self.manifest, digest(self.manifest.read_bytes()))

    def test_exact_types_schedule_categories_and_uniqueness(self):
        cases = []
        for field, invalid in [
            ("chunks", [17, 65536]),
            ("namespaces", [0, 1]),
            ("handlers", ["full", "minimal"]),
            ("iterations", True),
            ("iterations", 2),
        ]:
            value = copy.deepcopy(self.value)
            value["schedule"][field] = invalid
            cases.append(value)
        for field, invalid in [
            ("bytes", True),
            ("encoding", "utf-16"),
            ("sha256", "0" * 64),
            ("id", "../escape"),
            ("category", "other"),
            ("commit", "main"),
        ]:
            value = copy.deepcopy(self.value)
            value["documents"][0][field] = invalid
            cases.append(value)
        value = copy.deepcopy(self.value)
        value["schema_version"] = True
        cases.append(value)
        value = copy.deepcopy(self.value)
        value["documents"][1] = copy.deepcopy(value["documents"][0])
        cases.append(value)
        value = copy.deepcopy(self.value)
        value["documents"][1]["id"] = "other-id"
        value["documents"][1]["file"] = value["documents"][0]["file"]
        value["documents"][1]["sha256"] = value["documents"][0]["sha256"]
        cases.append(value)
        for index, value in enumerate(cases):
            with self.subTest(case=index), self.assertRaises(ValueError):
                load_real_inputs(self.manifest, self.save(value))

    def test_paths_symlinks_and_notice_tampering(self):
        for filename in [
            "../outside.xml",
            "/absolute.xml",
            "./fixture-0.xml",
            "a/../fixture-0.xml",
        ]:
            value = copy.deepcopy(self.value)
            value["documents"][0]["file"] = filename
            with self.subTest(filename=filename), self.assertRaises(ValueError):
                load_real_inputs(self.manifest, self.save(value))
        (self.root / "link.xml").symlink_to(self.root / "fixture-0.xml")
        value = copy.deepcopy(self.value)
        value["documents"][0]["file"] = "link.xml"
        with self.assertRaisesRegex(ValueError, "Symlink"):
            load_real_inputs(self.manifest, self.save(value))
        pin = self.save()
        real = load_real_inputs(self.manifest, pin)
        assert real is not None
        (self.root / "LICENSE").write_bytes(b"changed notice")
        with self.assertRaises(ValueError):
            real.require_unchanged()

    def test_utf8_size_and_mutation_boundaries(self):
        path = self.root / self.value["documents"][0]["file"]
        for data in [
            b"\xff",
            b"x" * (1024 * 1024 + 1),
            b"",
            b'<?xml version="1.0" encoding="ISO-8859-1"?><r/>',
        ]:
            path.write_bytes(data)
            value = copy.deepcopy(self.value)
            value["documents"][0].update(bytes=len(data), sha256=digest(data))
            with self.subTest(length=len(data)), self.assertRaises(ValueError):
                load_real_inputs(self.manifest, self.save(value))
        path.write_bytes(b"<valid/>")
        self.value["documents"][0].update(bytes=8, sha256=digest(b"<valid/>"))
        real = load_real_inputs(self.manifest, self.save())
        assert real is not None
        original = real.documents[0].data
        path.write_bytes(b"<other/>")
        self.assertEqual(real.documents[0].data, original)
        with self.assertRaises(ValueError):
            real.require_unchanged()
        path.write_bytes(original)
        self.manifest.write_bytes(self.manifest.read_bytes() + b" ")
        with self.assertRaisesRegex(ValueError, "SHA256 mismatch"):
            real.require_unchanged()

    def test_combined_input_bound(self):
        for index, row in enumerate(self.value["documents"]):
            data = str(index).encode() + b"x" * (800 * 1024)
            (self.root / row["file"]).write_bytes(data)
            row.update(bytes=len(data), sha256=digest(data))
        with self.assertRaisesRegex(ValueError, "four MiB"):
            load_real_inputs(self.manifest, self.save())

    def test_original_exercise_digest_and_origin_guard_are_unchanged(self):
        tree = ast.parse(Path(train.__file__).read_text())
        expected = {
            "exercise": "d3a063cf3cbeb8750518e62d665176d3dc3ff43bb5ce48bb720f964abfc7ad85",
            "verify_origin": "f8db812731646f9358820b8f5e4b6817830aac87c5be6907f185090ed1c13bab",
            "parser_scope": "48c5e45bf7b376b8a12aee4e5d95ec912a5e306fe6202f66127bde719f28cc95",
        }
        for name, digest_value in expected.items():
            function = next(
                node
                for node in ast.walk(tree)
                if isinstance(node, ast.FunctionDef) and node.name == name
            )
            self.assertEqual(
                hashlib.sha256(
                    ast.dump(function, include_attributes=False).encode()
                ).hexdigest(),
                digest_value,
            )

    def test_generated_loop_is_exact_old_ast_and_still_288_parses(self):
        tree = ast.parse(Path(train.__file__).read_text())
        loop = next(
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.For)
            and ast.unparse(node.target) == "fixture"
            and ast.unparse(node.iter) == "inputs['rows']"
        )
        # Exact AST of the previously measured Git144 loop, including its guards.
        self.assertEqual(
            hashlib.sha256(
                ast.dump(loop, include_attributes=False).encode()
            ).hexdigest(),
            "d0bf193c5ee4b5c5f6ff939d885c669a7c883584f93c8ed0d58ad4794a5dd3d0",
        )
        inputs = generate(self.root / "generated")
        calls = []

        def exercise(data, name, ns, chunk, handlers, iteration):
            calls.append((name, ns, chunk, handlers, iteration, len(data)))
            return {
                "iteration": iteration,
                "status": 1,
                "error": 0,
                "callback_exceptions": [],
            }

        context = {
            "inputs": inputs,
            "generated": documents(),
            "hashlib": hashlib,
            "args": type("Args", (), {"inputs": self.root / "generated"})(),
            "report": {"rows": []},
            "exercise": exercise,
        }
        exec(  # noqa: S102 - trusted local schedule AST with a fake callback
            compile(ast.Module(body=[loop], type_ignores=[]), "generated-loop", "exec"),
            context,
        )
        self.assertEqual(len(calls), 288)
        self.assertEqual(sum(call[-1] for call in calls), 31_817_664)
        for name, ns, chunk, handlers, iteration, size in calls:
            self.assertIn(ns, [False, True])
            self.assertIn(chunk, [1 if name == "latin1" else 17, 4096, 65536])
            self.assertIn(handlers, ["minimal", "full"])
            self.assertIn(iteration, [0, 1])
            self.assertEqual(size, len(context["generated"][name][0]))
        inputs["rows"][0]["chunks"] = [4096, 65536]
        with self.assertRaisesRegex(ValueError, "configuration changed"):
            exec(  # noqa: S102 - trusted local schedule AST with a fake callback
                compile(
                    ast.Module(body=[loop], type_ignores=[]), "generated-loop", "exec"
                ),
                context,
            )

    def test_real_loop_is_48_single_passes_with_existing_callback_exercise(self):
        real = load_real_inputs(self.manifest, self.save())
        assert real is not None
        tree = ast.parse(Path(train.__file__).read_text())
        loop = next(
            node
            for node in ast.walk(tree)
            if isinstance(node, ast.For) and ast.unparse(node.target) == "document"
        )
        calls = []

        def exercise(data, name, ns, chunk, handlers, iteration):
            calls.append((name, ns, chunk, handlers, iteration))
            return {"status": 1, "error": 0, "callback_exceptions": []}

        exec(  # noqa: S102 - trusted local schedule AST with a fake callback
            compile(ast.Module(body=[loop], type_ignores=[]), "real-loop", "exec"),
            {"real_inputs": real, "report": {"rows": []}, "exercise": exercise},
        )
        self.assertEqual(len(calls), 48)
        self.assertEqual(len(set(calls)), 48)
        self.assertTrue(all(row[-1] == 0 for row in calls))
        self.assertEqual({row[2] for row in calls}, {4096, 65536})

    def test_build_forwards_pin_and_rejects_wrong_identity_or_count(self):
        real = load_real_inputs(self.manifest, self.save())
        assert real is not None
        library = self.root / "mock-library"
        library.write_bytes(b"Not a parser; command is mocked")
        inputs = self.root / "generated"
        generate(inputs)
        run_directory = self.root / "run"
        run_directory.mkdir()
        run = build.Run(run_directory, self.root, 1)
        report = {
            "status": "passed",
            "rows": [{}] * 336,
            "library_sha256": build.digest(library),
            "inputs_sha256": build.digest(inputs / "manifest.json"),
            "xml_parse_origin": {"path": str(library), "sha256": build.digest(library)},
            "script_sha256": build.digest(Path(train.__file__)),
            "experimental_real_inputs": real.provenance(),
            "real_input_script_sha256": build.digest(
                Path(train.__file__).with_name("real_inputs.py")
            ),
        }

        def command(label, args, env):
            (run_directory / f"{label}-training.json").write_text(json.dumps(report))
            self.assertEqual(args[1:3], ["-I", "-S"])
            self.assertEqual(
                args[-4:],
                [
                    "--experimental-real-manifest",
                    str(self.manifest),
                    "--experimental-real-manifest-sha256",
                    real.manifest_sha256,
                ],
            )
            return ""

        with patch.object(run, "command", side_effect=command):
            build.train(run, library, inputs, "mock", {}, real)
            report["rows"] = report["rows"][:-1]
            with self.assertRaisesRegex(build.BuildError, "Incomplete training"):
                build.train(run, library, inputs, "mock", {}, real)
            report["rows"] = [{}] * 336
            report["experimental_real_inputs"] = {}
            with self.assertRaisesRegex(build.BuildError, "identity mismatch"):
                build.train(run, library, inputs, "mock", {}, real)


if __name__ == "__main__":
    unittest.main()
