"""Compare normalized real-training XML callbacks before fresh instrumentation."""
from pathlib import Path
import hashlib
import json
import os
import sys

ROOT = Path(__file__).resolve().parent
assert os.sched_getaffinity(0) == {5}
assert len(sys.argv) == 2 and sys.argv[1] in ('oriole', 'expat')
engine = sys.argv[1]
preparation = json.loads((ROOT / 'preparation.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert preparation['status'] == 'passed'
assert sha(__file__) == preparation['preflight_sha256']
assert sha(ROOT / 'preflight-support/xml_abi.py') == preparation['semantic_probe_sha256']
pipeline = ROOT / 'pipeline/tools/pgo'
def pipeline_files():
    return {str(p.relative_to(pipeline)): sha(p) for p in sorted(pipeline.rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts}
assert pipeline_files() == preparation['pipeline_sha256']
sys.path.insert(0, str(pipeline.parent))
sys.path.insert(0, str(ROOT / 'preflight-support'))
from pgo.real_inputs import load_real_inputs
from pgo.train import verify_origin
from xml_abi import Expat
manifest = Path('/tmp/oriole-real-pgo-training-inputs/manifest.json')
real = load_real_inputs(manifest, preparation['inputs_sha256'][str(manifest)])
assert real is not None
selected = preparation['normal_libraries'][engine]
library = Path(selected['path'])
assert sha(library) == selected['sha256']
consumer = Expat(str(library))
origin = verify_origin(consumer.lib.XML_Parse, library)
assert consumer.version == ('oriole_compat_2.8.4' if engine == 'oriole' else 'expat_2.8.4')
output = ROOT / ('real-preflight-' + engine)
output.mkdir(exist_ok=False)
report = {'status': 'incomplete', 'scope': 'Normal uninstrumented libraries only; semantic callback preflight, no elapsed performance claim. Adjacent character callbacks coalesced. Exact callbacks and final parser positions retained separately. No external resource resolution.',
          'preparation_sha256': sha(ROOT / 'preparation.json'), 'engine': engine,
          'version': consumer.version, 'origin': origin, 'real': real.provenance(), 'rows': []}
try:
    for document in real.documents:
        for namespaces in (False, True):
            expected = None
            for chunk in (4096, 65536):
                result = consumer.parse(document.data, chunk, namespaces)
                row = {'document': document.name, 'namespaces': namespaces, 'chunk': chunk,
                       'result': result}
                path = output / f'case-{len(report["rows"]):02d}.json'
                path.write_text(json.dumps(row, ensure_ascii=False, indent=2) + '\n')
                report['rows'].append({'document': document.name, 'namespaces': namespaces,
                                       'chunk': chunk, 'path': str(path), 'sha256': sha(path)})
                assert result['status'] == 1 and result['error'] == 0 and not result['callback_errors']
                if expected is None:
                    expected = result['normalized_events']
                else:
                    assert result['normalized_events'] == expected, 'Feed width changed normalized callbacks'
    real.require_unchanged()
    assert sha(library) == selected['sha256']
    assert pipeline_files() == preparation['pipeline_sha256']
    report['status'] = 'passed'
finally:
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'engine': engine, 'cases': len(report['rows'])}))
