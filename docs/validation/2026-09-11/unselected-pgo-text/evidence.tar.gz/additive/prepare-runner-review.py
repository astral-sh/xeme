import ast,difflib,hashlib,json,pathlib
P=pathlib.Path('/tmp/oriole-real-pgo-training-study')
B=pathlib.Path('/tmp/oriole-compact-delivery-status-pgo-study/pipeline/tools/pgo')
N=P/'pipeline/tools/pgo'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((P/'base.json').read_text())
assert all(sha(B/name)==h for name,h in base['files_sha256'].items())
patch=[]
for p in sorted(N.glob('*')):
 if p.is_file():
  before=(B/p.name).read_text() if (B/p.name).exists() else ''
  patch.extend(difflib.unified_diff(before.splitlines(True),p.read_text().splitlines(True),fromfile='a/tools/pgo/'+p.name,tofile='b/tools/pgo/'+p.name))
(P/'runner-attempt01.patch').write_text(''.join(patch))
old=ast.parse((B/'train.py').read_text());new=ast.parse((N/'train.py').read_text())
for name in ['exercise','verify_origin','parser_scope']:
 a=next(n for n in ast.walk(old) if isinstance(n,ast.FunctionDef) and n.name==name)
 b=next(n for n in ast.walk(new) if isinstance(n,ast.FunctionDef) and n.name==name)
 assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False),name
json.dump({'status':'prepared_before_checks','base':base,'pipeline_sha256':{p.name:sha(p) for p in sorted(N.glob('*')) if p.is_file()},'patch_sha256':sha(P/'runner-attempt01.patch'),'source_and_parser_changes':0,'test_execution':0,'parser_execution':0,'cargo_execution':0,'scopes':{'G':288,'G+R':336,'real':48},'proposed_checks':{'python':'/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S -B -m unittest discover -s pipeline/tools/pgo -p test_*.py','format_lint_type':'uv offline Ruff and ty; record actual versions/paths'}},(P/'runner-preparation-attempt01.json').open('w'),indent=2)
print(json.dumps({'patch':str(P/'runner-attempt01.patch'),'patch_sha256':sha(P/'runner-attempt01.patch'),'preparation_sha256':sha(P/'runner-preparation-attempt01.json')},indent=2))
