"""Freeze one additive training experiment after source and corpus review."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/home/dev-user/code/oss/oriole-cdata-finder')
EXPAT = Path('/tmp/oriole-pgo-study/expat-source')
PIPELINE = ROOT / 'pipeline/tools/pgo'
REAL = Path('/tmp/oriole-real-pgo-training-inputs/manifest.json')
BASELINE = Path('/home/dev-user/.cache/oriole/expat-build')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert not (ROOT / 'preparation.json').exists()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == '78c748d9de5c497858458cbf7a1229148781b2bf'
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True) == ''
source = read('/tmp/oriole-cdata-finder-pgo-study/source.json')['source_sha256']
expat = read('/tmp/oriole-pgo-study/expat-source.json')['files']
assert len(source) == 70 and all(sha(SOURCE / p) == h for p, h in source.items())
assert all(sha(EXPAT / p) == h for p, h in expat.items())
sys.path.insert(0, str(PIPELINE.parent))
from pgo.real_inputs import load_real_inputs
from pgo.build import source_files
real = load_real_inputs(REAL, sha(REAL))
assert real is not None
pipeline_source = source_files(SOURCE)
assert len(pipeline_source) == 67 and all(source.get(p) == h for p, h in pipeline_source.items())
inputs = {str(REAL): sha(REAL), **{str(REAL.parent / p): h for p, h in real.files_sha256.items()}}
for path in [BASELINE / 'CMakeCache.txt', BASELINE / 'expat_config.h',
             Path('/tmp/oriole-pgo-training-distribution-review/PLAN.md')]:
    inputs[str(path)] = sha(path)
heldout = read('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
heldout_hashes = {f['sha256'] for project in heldout['projects'] for f in project['files'] if f['role'] == 'input'}
from pgo.corpus import documents
assert not {sha(REAL.parent / d.file) for d in real.documents} & heldout_hashes
assert not {sha(REAL.parent / d.file) for d in real.documents} & {hashlib.sha256(d[0]).hexdigest() for d in documents().values()}
cc1 = subprocess.check_output(['/usr/bin/cc', '-print-prog-name=cc1'], text=True, timeout=30).strip()
tools = ['/usr/bin/cc', '/usr/bin/gcov-tool', '/usr/bin/gcov-dump', '/usr/bin/ld', '/usr/bin/cmake', '/usr/bin/make', cc1]
normal = {
    'oriole': {'path': '/tmp/oriole-cdata-finder-pgo-study/normal/liboriole_expat.so',
               'sha256': '195add2e0efba2f7dacc57efc06788d58212e4572bcf83097937fe57dc5f9aa7'},
    'expat': {'path': '/tmp/oriole-pgo-study/expat-control-liboriole_expat.so',
              'sha256': '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'},
}
assert all(sha(d['path']) == d['sha256'] for d in normal.values())
report = {
    'status': 'passed', 'runtime_revision': '78c748d9de5c497858458cbf7a1229148781b2bf',
    'experiment': 'One fixed additive arm; exact generated schedule versus generated plus six independently pinned real XML files. Source/config/allocators fixed; no weight sweep or held-out training.',
    'prepare_sha256': sha(__file__), 'controller_sha256': sha(ROOT / 'build_arms.py'),
    'preflight_sha256': sha(ROOT / 'preflight_real.py'),
    'normal_preflight_controller_sha256': sha(ROOT / 'run_normal_preflight.py'),
    'semantic_probe_sha256': sha(ROOT / 'preflight-support/xml_abi.py'),
    'oriole_source_sha256': source, 'pipeline_source_sha256': pipeline_source,
    'expat_source_sha256': expat, 'expat_config_sha256': sha(BASELINE / 'expat_config.h'),
    'gcc_tools_sha256': {str(Path(p).resolve()): sha(p) for p in tools},
    'pipeline_sha256': {str(p.relative_to(PIPELINE)): sha(p) for p in sorted(PIPELINE.rglob('*')) if p.is_file() and '__pycache__' not in p.parts},
    'inputs_sha256': inputs, 'normal_libraries': normal, 'real_inputs': real.provenance(),
    'heldout_manifest_sha256': sha('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json'),
    'heldout_hashes': sorted(heldout_hashes),
    'limitations': ['Hashes establish exact artifacts; source provenance and project-lineage disjointness require the separate independent corpus review.',
                    'Oriole uses Ohm with defaults disabled and LLVM22 ThinLTO; Expat uses GCC13 O3 without LTO. Compare training changes within each engine before comparing engines.',
                    'The parser is unchanged from PR128. These inputs are training only and cannot become timing fixtures.'],
}
(ROOT / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'real_documents': len(real.documents), 'pipeline_sources': len(pipeline_source), 'full_sources': len(source), 'preparation_sha256': sha(ROOT / 'preparation.json')}))
