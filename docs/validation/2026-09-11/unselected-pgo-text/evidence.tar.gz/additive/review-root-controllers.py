import ast,hashlib,json,pathlib
P=pathlib.Path('/tmp/oriole-real-pgo-training-study')
B=pathlib.Path('/tmp/oriole-cdata-finder-pgo-native-study')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def tree(p):return ast.parse(p.read_text())
files=['prepare.py','run_normal_preflight.py','preflight_real.py','build_arms.py','prepare_native.py']
source={name:(P/name).read_text() for name in files}
for s in source.values():ast.parse(s)
assert "PREFLIGHT['status'] == 'passed' and PREFLIGHT['preparation_sha256'] == sha(ROOT / 'preparation.json')" in source['build_arms.py']
assert source['build_arms.py'].count("assert sha(PREFLIGHT['exact_training_reports'][engine]['path']) == PREFLIGHT['exact_training_reports'][engine]['sha256']")==2
assert source['build_arms.py'].count("normal_report['rows'] if arm == 'gr' else normal_report['rows'][:288]")==2
assert "len(training['rows']) == 336" in source['run_normal_preflight.py']
assert "len(r['rows']) == 24" in source['run_normal_preflight.py']
assert "assert compared['normalized_callbacks_equal']" in source['run_normal_preflight.py']
assert "exact_callbacks_equal=" in source['run_normal_preflight.py'] and "final_positions_equal=" in source['run_normal_preflight.py']
assert "len(pipeline_source) == 67" in source['prepare.py'] and "len(source) == 70" in source['prepare.py']
# Independently synthesize only the adapter's text substitutions; no controller execution.
original=(B/'native_screen.py').read_text();t=ast.parse(original)
assignments={n.targets[0].id:n for n in t.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
iterations=ast.literal_eval(assignments['iterations'].value)
ratios=[('oriole-gr','oriole-g'),('expat-gr','expat-g'),('oriole-g','expat-g'),('oriole-gr','expat-gr')]
replacements={'root':"root = Path('/review-only/native')\n",'libraries':'libraries = {'+', '.join(repr(n)+': Path('+repr('/review-only/'+n+'.so')+')' for n in ['oriole-g','oriole-gr','expat-g','expat-gr'])+'}\n','ratios':'ratios = '+repr(ratios)+'\n'}
lines=original.splitlines(True)
for n in sorted([assignments[k] for k in replacements],key=lambda n:n.lineno,reverse=True):lines[n.lineno-1:n.end_lineno]=[replacements[n.targets[0].id]]
candidate=''.join(lines)
oldscope=ast.literal_eval(assignments['protocol'].value.values[0])
candidate=candidate.replace('Fixed three-engine matched pgo reusable CDATA Finder native screen.','Fixed four-engine generated-only versus additive-real PGO native screen.').replace(repr(oldscope),repr('reviewed four-engine scope'))
candidate=candidate.replace("'preflights': 84, 'timed_workers': 588","'preflights': 112, 'timed_workers': 784").replace("len(report['rows']) == 84","len(report['rows']) == 112").replace("'timed_workers': 3 * len(report['rows'])","'timed_workers': 4 * len(report['rows'])")
ct=ast.parse(candidate)
for name in ['run','digest','save']:
 a=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name==name)
 b=next(n for n in ct.body if isinstance(n,ast.FunctionDef) and n.name==name)
 assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
# Other numeric protocol constants and every condition/iteration construction remain identical.
for name in ['iterations','conditions','manifest','driver','fixtures']:
 a=next(n for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==name for x in n.targets))
 b=next(n for n in ct.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==name for x in n.targets))
 assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
protocol=assignments['protocol'].value
numbers={ast.literal_eval(k):ast.literal_eval(v) for k,v in zip(protocol.keys,protocol.values) if isinstance(v,ast.Constant)}
assert numbers['seed']==2026091003 and numbers['pairs']==7
real_names=[name for name in iterations if not name.startswith('generated-')]
generated_names=[name for name in iterations if name.startswith('generated-')]
assert len(real_names)==6 and len(generated_names)==2
conditions=len(real_names)*4+len(generated_names)*2
iteration_sum=sum(iterations[n]*4 for n in real_names)+sum(iterations[n]*2 for n in generated_names)
counts={'conditions':conditions,'pairs':7,'engines':4,'preflight_workers':conditions*4,'timed_workers':conditions*7*4,'measured_samples':iteration_sum*7*4,'timed_warmup_samples':conditions*7*4,'preflight_samples':conditions*4*2}
counts['all_samples']=counts['measured_samples']+counts['timed_warmup_samples']+counts['preflight_samples']
assert counts=={'conditions':28,'pairs':7,'engines':4,'preflight_workers':112,'timed_workers':784,'measured_samples':140560,'timed_warmup_samples':784,'preflight_samples':224,'all_samples':141568}
for k,v in [('conditions',28),('pairs',7),('preflight_workers',112),('timed_workers',784),('measured_samples',140560),('warmup_samples',784),('preflight_samples',224)]:assert f"'{k}': {v}" in source['prepare_native.py']
assert "(OUT / 'run.py').write_bytes((BASE / 'run.py').read_bytes())" in source['prepare_native.py']
report={'status':'no_blocker_in_bounded_source_review','scope':'Five controllers read and ASTs evaluated without executing controllers or parser/compiler/profiler/native targets','sources_sha256':{n:sha(P/n) for n in files},'support_sha256':{'xml_abi.py':sha(P/'preflight-support/xml_abi.py'),'old_native_screen.py':sha(B/'native_screen.py'),'old_native_run.py':sha(B/'run.py'),'runner-manifest.json':sha(P/'runner-manifest.json'),'PLAN.md':sha(pathlib.Path('/tmp/oriole-pgo-training-distribution-review/PLAN.md'))},'findings':['prepare.py freezes exact PR128 clean checkout/full70 source, pipeline67 build subset, external helper files, pinned Expat source, CMakeCache/config/GCC tools, normal Oriole195add2e and Expat7a333bc8, real document/notice hashes and held-out/generated disjointness by bytes. Independent corpus lineage review remains a required separate condition before freeze.','Normal wrapper requires its preparation identity and checks pinned pipeline, performs24 semantic cases per engine and336 exact training records per engine. Semantic wrapper validates parse status/error, loaded XML_Parse origin, version and retained bytes; feed-width and cross-engine normalized callbacks must match. Exact callback lists and final positions remain separately retained/compared, not silently normalized into equality.','Both fresh build engines require a passed normal preflight bound to the same preparation, validate the corresponding exact normal replay path/SHA, and compare either all336 rows or its exact288 generated prefix. Generate/use equality remains per engine. New G/GR manifests and profile directories are independent; inherited PGO/GCOV flags are cleared. Expat GCC native profiles remain separate from Oriole LLVM profiles.','Native adapter waits for all four passed build reports with unchanged input/tool/source checks and matching preparation. It binds four fresh use libraries and four declared ratios. Original native run/digest/save functions, condition construction, input paths, iteration table, seed and7 pairs are unchanged. Engine-count edits consistently cover112 preflights/784 timed workers.','The existing wrapper launches CPU5 preflight then CPU0 elapsed, retains90-second individual workers and600/1200-second phase bounds with process-group cleanup. No timing execution is authorized by this source review.'],'native_protocol':{'counts':counts,'seed':2026091003,'ratios':ratios,'iteration_sum_across_conditions':iteration_sum,'per_worker_timeout_seconds':90,'aggregate_preflight_timeout_seconds':600,'aggregate_timing_timeout_seconds':1200},'limitations':['This establishes source readiness only. No preparation/preflight/build/native outputs or actual fresh compiler/profile/library identities were produced or audited here.','The normal exact replay runs G+R once per engine, preserving two generated repetitions and one real pass percondition; additional repeat determinism is checked by fresh generate/use records, not extra training passes.','The xml_abi semantic probe coalesces adjacent text while retaining other event boundaries; it is a separate semantic subset from the existing minimal/full training digest. No complete C ABI or model-content equivalence is claimed.','The four-engine cohort changes randomized engine-order draws relative to the old three-engine study; the seed, condition/pair shuffle, iteration counts and timing algorithm are retained. It must be measured as its own campaign.','Oriole O3/ThinLTO/cgu1 and Expat GCC13 O3/no-LTO differ across engines as disclosed. Actual compiler vectors and fresh profile provenance still require post-build audit before elapsed selection.'],'target_executions':0,'producer_edits':0,'reader_sha256':sha(pathlib.Path(__file__))}
out=P/'root-controllers-independent-review.json';out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'path':str(out),'sha256':sha(out),'counts':counts},indent=2))
