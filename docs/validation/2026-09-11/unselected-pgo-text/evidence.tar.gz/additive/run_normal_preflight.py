"""Normal-library semantic and exact training replays before instrumentation."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert os.sched_getaffinity(0) == {5}
preparation = read(ROOT / 'preparation.json')
assert preparation['normal_preflight_controller_sha256'] == sha(__file__)
assert not (ROOT / 'normal-preflight.json').exists()
manifest = Path('/tmp/oriole-real-pgo-training-inputs/manifest.json')
report = {'status': 'incomplete', 'preparation_sha256': sha(ROOT / 'preparation.json'),
          'commands': [], 'exact_training_reports': {}, 'semantic_comparisons': []}


def save():
    (ROOT / 'normal-preflight.json').write_text(json.dumps(report, indent=2) + '\n')


def run(label, argv):
    row = {'label': label, 'argv': argv, 'cpu': 5, 'timeout': 600, 'start': time.time()}
    report['commands'].append(row)
    save()
    process = None
    log = ROOT / (label + '.log')
    with log.open('wb') as stream:
        try:
            process = subprocess.Popen(argv, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            row['exit'] = process.wait(timeout=600)
            if row['exit']:
                raise RuntimeError(f'{label}: exit {row["exit"]}')
        except BaseException as error:
            row['failure'] = repr(error)
            if process is not None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                row['exit'] = process.wait()
            raise
        finally:
            stream.flush()
            row.update(end=time.time(), log_sha256=sha(log))
            save()
    print(label, row['exit'], flush=True)


try:
    pipeline = ROOT / 'pipeline/tools/pgo'
    assert preparation['pipeline_sha256'] == {str(p.relative_to(pipeline)): sha(p) for p in sorted(pipeline.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
    sys.path.insert(0, str(pipeline.parent))
    from pgo.corpus import generate
    inputs = ROOT / 'normal-generated-inputs'
    generate(inputs)
    for engine, library in preparation['normal_libraries'].items():
        run('semantic-' + engine, [PYTHON, '-I', '-S', str(ROOT / 'preflight_real.py'), engine])
        target = ROOT / ('normal-' + engine + '-training.json')
        run('normal-training-' + engine, [PYTHON, '-I', '-S', str(pipeline / 'train.py'),
                                         '--library', library['path'], '--inputs', str(inputs),
                                         '--report', str(target), '--experimental-real-manifest', str(manifest),
                                         '--experimental-real-manifest-sha256', preparation['inputs_sha256'][str(manifest)]])
        training = read(target)
        assert training['status'] == 'passed' and len(training['rows']) == 336
        assert training['library_sha256'] == library['sha256']
        assert training['xml_parse_origin'] == {'path': str(Path(library['path']).resolve()), 'sha256': library['sha256']}
        assert training['experimental_real_inputs'] == preparation['real_inputs']
        assert training['inputs_sha256'] == sha(inputs / 'manifest.json')
        report['exact_training_reports'][engine] = {'path': str(target), 'sha256': sha(target)}
    normal = {engine: read(ROOT / ('real-preflight-' + engine) / 'report.json') for engine in ('oriole', 'expat')}
    assert all(r['status'] == 'passed' and len(r['rows']) == 24 for r in normal.values())
    for o, e in zip(normal['oriole']['rows'], normal['expat']['rows'], strict=True):
        key = ['document', 'namespaces', 'chunk']
        assert all(o[k] == e[k] for k in key)
        assert sha(o['path']) == o['sha256'] and sha(e['path']) == e['sha256']
        a, b = read(o['path'])['result'], read(e['path'])['result']
        compared = {k: o[k] for k in key}
        compared.update(normalized_callbacks_equal=a['normalized_events'] == b['normalized_events'],
                        exact_callbacks_equal=a['events'] == b['events'],
                        final_positions_equal=a['position'] == b['position'])
        report['semantic_comparisons'].append(compared)
        assert compared['normalized_callbacks_equal'], compared
    assert all(sha(p) == h for p, h in preparation['inputs_sha256'].items())
    assert preparation['pipeline_sha256'] == {str(p.relative_to(pipeline)): sha(p) for p in sorted(pipeline.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
    report['status'] = 'passed'
finally:
    save()
print(json.dumps({'status': report['status'], 'comparisons': len(report['semantic_comparisons'])}))
