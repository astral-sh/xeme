import ast,difflib,hashlib,json,pathlib
P=pathlib.Path('/tmp/oriole-real-pgo-training-study');N=P/'pipeline/tools/pgo'
B=pathlib.Path('/tmp/oriole-compact-delivery-status-pgo-study/pipeline/tools/pgo')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
base=json.loads((P/'base.json').read_text())
assert all(sha(B/name)==h for name,h in base['files_sha256'].items())
files={p.name:sha(p) for p in sorted(N.iterdir()) if p.is_file()}
assert len(files)==8
for name in ['corpus.py','test_build.py','__init__.py']:assert files[name]==base['files_sha256'][name]
patch=[]
for name in files:
 before=(B/name).read_text() if (B/name).exists() else ''
 patch.extend(difflib.unified_diff(before.splitlines(True),(N/name).read_text().splitlines(True),fromfile='a/tools/pgo/'+name,tofile='b/tools/pgo/'+name))
(P/'runner.patch').write_text(''.join(patch))
old=ast.parse((B/'train.py').read_text());new=ast.parse((N/'train.py').read_text());ast_hashes={}
for name in ['exercise','verify_origin','parser_scope']:
 a=next(n for n in ast.walk(old) if isinstance(n,ast.FunctionDef) and n.name==name)
 b=next(n for n in ast.walk(new) if isinstance(n,ast.FunctionDef) and n.name==name)
 x=ast.dump(a,include_attributes=False);assert x==ast.dump(b,include_attributes=False)
 ast_hashes[name]=hashlib.sha256(x.encode()).hexdigest()
for tree in [old,new]:
 loop=next(n for n in ast.walk(tree) if isinstance(n,ast.For) and ast.unparse(n.target)=='fixture' and ast.unparse(n.iter)=="inputs['rows']")
 h=hashlib.sha256(ast.dump(loop,include_attributes=False).encode()).hexdigest()
 assert h==(P/'generated-loop-ast.sha256').read_text().strip()
ast_hashes['generated_loop']=h
python=pathlib.Path('/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12')
uv=pathlib.Path('/home/dev-user/.local/bin/uv')
checks={}
for name,exit_code in {
 'unit-attempt01':1,'unit-attempt02':0,'unit-attempt03':0,'unit-attempt04':0,
 'ruff-version-attempt01':2,'ty-version-attempt01':2,'ruff-version-attempt02':0,'ty-version-attempt02':0,
 'ruff-check-attempt01':1,'ruff-check-attempt02':1,'ruff-check-attempt03':0,
 'ruff-format-attempt01':1,'ruff-format-attempt02':0,'ruff-format-attempt03':0,
 'ty-check-attempt01':1,'ty-check-attempt02':0,'ty-check-attempt03':0,
 'ruff-format-apply':0,'real-manifest-schema-check':0,
}.items():
 checks[name]={'exit':exit_code,'stdout_sha256':sha(P/(name+'.stdout')),'stderr_sha256':sha(P/(name+'.stderr'))}
assert 'Ran 23 tests' in (P/'unit-attempt04.stderr').read_text()
assert (P/'unit-attempt04.stderr').read_text().rstrip().endswith('OK')
assert (P/'ruff-check-attempt03.stdout').read_text().strip()=='All checks passed!'
assert (P/'ruff-format-attempt03.stdout').read_text().strip()=='8 files already formatted'
assert (P/'ty-check-attempt03.stdout').read_text().strip()=='All checks passed!'
versions={'ruff':(P/'ruff-version-attempt02.stdout').read_text().strip(),'ty':(P/'ty-version-attempt02.stdout').read_text().strip()}
manifest={'status':'frozen_external_experiment_runner','runtime':'selected Finder PR128 78c748d9de5c497858458cbf7a1229148781b2bf; no runtime source edits','base':base,'pipeline_sha256':files,'licenses_sha256':{name:sha(P/'pipeline'/name) for name in ['LICENSE-APACHE','LICENSE-MIT']},'patch_sha256':sha(P/'runner.patch'),'unchanged_ast_sha256':ast_hashes,'schedule':{'G':288,'G_plus_R':336,'real_additional':48,'real_chunks':[4096,65536],'real_namespaces':[False,True],'real_handlers':['minimal','full'],'real_iterations':1},'manifest_arguments':['--experimental-real-manifest','--experimental-real-manifest-sha256'],'tool_inputs':{'python':{'path':str(python),'sha256':sha(python)},'uv':{'path':str(uv),'sha256':sha(uv)},'ruff_config':{'path':'/home/dev-user/code/oss/oriole-cdata-finder/ruff.toml','sha256':sha(pathlib.Path('/home/dev-user/code/oss/oriole-cdata-finder/ruff.toml'))}},'tool_versions':versions,'source_edits_in_published_repository':0,'parser_executions':0,'compiler_or_cargo_executions':0,'first_patch_sha256':sha(P/'runner-attempt01.patch'),'first_preparation_sha256':sha(P/'runner-preparation-attempt01.json')}
dump(P/'runner-manifest.json',manifest)
result={'status':'passed_tool_checks_only','runner_manifest_sha256':sha(P/'runner-manifest.json'),'patch_sha256':sha(P/'runner.patch'),'final_tests':23,'final_lint':'Ruff check passes','final_format':'Ruff format --check passes,8files','final_types':'ty check passes','commands':{'unit':[str(python),'-I','-S','-B','-m','unittest','discover','-s',str(N),'-p','test_*.py'],'uv_prefix':[str(uv),'tool','run','--offline','--python',str(python)],'ruff_check':['ruff','check','--config','/home/dev-user/code/oss/oriole-cdata-finder/ruff.toml',str(N)],'ruff_format':['ruff','format','--check','--config','/home/dev-user/code/oss/oriole-cdata-finder/ruff.toml',str(N)],'ty':['ty','check','--extra-search-path',str(N.parent),str(N)]},'execution_environment':{'cpu_affinity':[6],'nice':19,'UV_TOOL_DIR':str(P/'uv-tools'),'UV_TOOL_BIN_DIR':str(P/'uv-bin')},'attempts':checks,'first_outcomes':['unit-attempt01 failed one mock-only path-collision test: Run manifest overwrote synthetic input manifest; corrected test to a separate run directory. All23 passed attempt02.','Initial uv version probes failed because default UV_TOOL_DIR was read-only; task-local tool dirs allowed cached offline Ruff0.16.6 and ty0.0.80. No network fallback.','Ruff first pass required formatting and flagged three deliberate local schedule-AST exec calls. Added narrow explained S102 annotations. Formatting moved annotations off call lines, detected by attempt02; moved them to call lines, attempt03 passed.','ty first pass reported94 diagnostics, all in deliberately heterogeneous test JSON fixture inference; annotated fixture dict[str,Any]. Runtime/helper code had no ty diagnostics. Attempts02/03 passed.','Unit/ty final-byte confirmations followed the final comment-only annotation placement; all sessions were reaped. No parser library or compiler was run.'], 'actual_candidate_manifest_schema_check':json.loads((P/'real-manifest-schema-check.stdout').read_text()),'limitations':['Synthetic tests and mocked commands do not validate XML parser behavior.','Corpus licence/provenance/lineage and held-out leakage require the independent corpus review. Schema/hash/UTF8 checks are not XML well-formedness proof.','Generated and real callback digests remain fragmentation-sensitive; use exact per-engine replay and separate cross-engine semantic checks. Element model contents remain outside the inherited digest.','No fresh PGO training/build, normal callback preflight or elapsed benchmark has been run by this author. This is an external experiment, not production adoption.'],'reader_sha256':sha(pathlib.Path(__file__))}
dump(P/'runner-checks.json',result)
print(json.dumps({'runner_patch_sha256':sha(P/'runner.patch'),'runner_manifest_sha256':sha(P/'runner-manifest.json'),'runner_checks_sha256':sha(P/'runner-checks.json'),'pipeline_files':len(files),'tests':23,'versions':versions},indent=2))
