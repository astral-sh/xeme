"""Independent inert source/metadata audit; excludes the held 98-input reread."""
from pathlib import Path
import ast,hashlib,json
P=Path('/tmp/oriole-bulk-pgo-training-study');R=P/'python';O=Path('/tmp/oriole-cdata-finder-pgo-python-study')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
pins={'adaptation.json':'23db4649750f27698df408b1c2fc61feba26c55570c6bb330d0a0278a9931ccf','preparation.json':'13f573e259ea6868b12b9f6d8c60c321d8acdef24f075454cd4c06b633e094dc','preparation-freeze.json':'4c29d02f3e99bc1d15d22c70de79aa1997f4993b99f485a19911778e38031619'}
for name,h in pins.items():assert sha(R/name)==h,name
A=load(R/'adaptation.json');S=load(R/'preparation.json');F=load(R/'preparation-freeze.json');old=load(O/'adaptation.json');oldprep=load(O/'preparation.json')
verified={}
for p,h in F['files'].items():assert sha(p)==h;verified[p]=h
changes={}
for name,row in S['changes'].items():
 before=(O/name).read_text();after=(R/name).read_text();assert sha(O/name)==row['parent_sha256'];assert sha(R/name)==row['sha256']==A['files'][name]
 restored=after
 for oldtext,newtext in reversed(row['replacements']):assert restored.count(newtext)==1;restored=restored.replace(newtext,oldtext)
 assert restored==before
 assert ast.dump(ast.parse(restored),include_attributes=False)==ast.dump(ast.parse(before),include_attributes=False)
 changes[name]={'source_sha256':sha(R/name),'parent_sha256':sha(O/name),'reverse_text_and_AST_exact':True,'replacements':len(row['replacements'])}
assert (R/'python_worker.py').read_bytes()==(O/'python_worker.py').read_bytes()
# Extract literal constants only; neither module is imported/executed.
def constants(tree):
 result={}
 for n in tree.body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:result[n.targets[0].id]=ast.literal_eval(n.value)
   except (ValueError,TypeError):pass
 return result
C=constants(ast.parse((R/'consumer_screen.py').read_text()));OC=constants(ast.parse((O/'consumer_screen.py').read_text()))
assert C['ITERATIONS']==OC['ITERATIONS']=={'vulkan':3,'wayland':16,'maven':32,'batik':128,'gtk':64,'docbook':64}
assert list(C['ENGINES'])==['oriole-g','oriole-b','expat-g','expat-b']
assert C['RATIOS']==(('oriole-b','oriole-g'),('expat-b','expat-g'),('oriole-g','expat-g'),('oriole-b','expat-b'))
assert A['conditions']==S['conditions']==oldprep['conditions']
assert len(A['conditions'])==24 and len({(r['name'],r['chunk'],r['mode']) for r in A['conditions']})==24
assert {r['chunk'] for r in A['conditions']}=={4096,65536}
assert {r['mode'] for r in A['conditions']}=={'elementtree','pyexpat-events'}
assert all(r['iterations']==C['ITERATIONS'][r['name']] for r in A['conditions'])
counts={'conditions':24,'engines':4,'extensions':8,'preflights':24*4,'cohorts':24*7,'pairs':7,'timed_workers':24*7*4,'measured_parses':sum(r['iterations'] for r in A['conditions'])*7*4,'warmups':24*7*4,'all_workers':24*4+24*7*4,'all_samples':sum(r['iterations'] for r in A['conditions'])*7*4+24*7*4+24*4}
assert counts==A['counts']==S['counts']
assert A['bounds']==S['bounds']==old['bounds']=={'prepare_cpu':3,'timing_cpu':0,'build_seconds':600,'preflight_aggregate_seconds':600,'worker_seconds':300,'timing_aggregate_seconds':1200}
assert A['seed']==S['seed']==old['seed']==202609104412
build=load(P/'build-arms-independent-review.json')
assert sha(P/'build-arms-independent-review.json')==A['build_review']['sha256']
assert A['libraries']=={name:build['libraries'][name]['use'] for name in C['ENGINES']}
N=ast.parse((P/'native/native_screen.py').read_text());libnode=next(n.value for n in N.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='libraries' for t in n.targets))
assert isinstance(libnode,ast.Dict)
nativelibs={ast.literal_eval(k):ast.literal_eval(v.args[0]) for k,v in zip(libnode.keys,libnode.values)}
assert nativelibs=={n:v['path'] for n,v in A['libraries'].items()}
assert A['header']==old['header'] and A['consumer_source']==old['consumer_source']
assert len(A['input_pins'])==98
assert sha(A['header']['path'])==A['header']['sha256']
assert Path('/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3').resolve()==Path('/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12').resolve()
report={'status':'passed_bounded_independent_source_review','scope':'Inert source/AST and small manifest/header reads only during Text elapsed. No compiler, parser, extension import, profiler or benchmark. No current rehash of all98 source/tool/library/input files; that bulk readback remains an execution-stage prerequisite and author preparation is separately retained.','reader_sha256':sha(__file__),'pins':pins,'verified_package_files':verified,'files':changes,'libraries':A['libraries'],'counts':counts,'conditions':A['conditions'],'seed':A['seed'],'bounds':A['bounds'],'header':A['header'],'consumer_source_metadata':A['consumer_source'],'metadata_library_mapping_matches_independent_build_and_native_controller':True,'findings':[
'All four engine names flow from reviewed libraries through explicit build arguments to disjoint per-engine extension directories, build manifest keys, worker consumer directory and expected parser hash. Native G/B paths exactly match the prior four-arm campaign and independent build receipt; no Finder19/82 or GR/Text candidate substitution.',
'Unmodified worker bytes match Finder. Consumer_screen uses only its --worker entry, so the unchanged historical standalone worker main with old engine labels is unreachable in this campaign. New ratio computation belongs to consumer_screen and uses correct within-engine B/G and matched G/G,B/B denominators.',
'Each engine compiles the same pinned CPython3.12.13 sources and header with identical shared/PIC/O2/includes and only library/rpath/output path changes. SONAME aliases are preserved. No interpreter/extension training, LTO or source adaptation introduced.',
'XML_Parse is resolved from explicitly loaded pyexpat via dladdr; path must reside in that engine directory and actual hash must equal worker spec before samples. Both extension file origins are checked; copied libraries and extensions are hashed before/after campaign and worker. Root must read actual module/parser identities after fresh preparation before elapsed.',
'Same six held-out inputs and24namespace-enabled conditions; original per-project3/16/32/128/64/64 iterations. Same random seed, pre-shuffled condition/pair cohorts, four-way shuffled engine order, medians of nonwarmup process samples and pairwise medians. Cardinality increase is deliberate and fully counted.',
'Creation/feed/finalization/callback work plus separately timed explicit result destruction remain measured; import/input chunk construction/canonical checks/gc.collect outside. Automatic GC stays enabled. All per-sample outputs compare within worker and against cross-engine canonical preflight including both Expat arms; preflight uses one sample perworker and elapsed one discarded warmup.',
'Original worker300s/build600s/preflight600s/timing1200s limits and CPU3/CPU0 split retained. Wrapper kills/reaps process group on aggregate failure; fresh output/report existence guards and raw failures retained. Added before-launch hashes include controller and98 input pins.',
'Pinned source/header identities were compared to original metadata, and header bytes were read independently. Full98 input bytes and four current DSO bytes were intentionally not scanned during elapsed. Runtime guard performs full verification before the released preparation/time process. Execute with the existing pinned Python and clean PATH so cc/readelf resolve to recorded tools.'
],'blockers':[],'execution_release':'Parent-owned; this pass approves source protocol only, not a build/preflight or timing result.'}
p=Path('/tmp/oriole-bulk-pgo-python-independent-source-review.json')
with p.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({'status':report['status'],'sha256':sha(p),'counts':counts}))
