"""Prepare a saved-data-only four-engine reader; do not read elapsed artifacts."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os

assert os.sched_getaffinity(0) == {6}
old = Path('/tmp/oriole-review-cdata-finder-python-elapsed.py')
new = Path('/tmp/oriole-review-bulk-python-elapsed.py')
original = old.read_text()
assert hashlib.sha256(original.encode()).hexdigest() == 'eeb27be6b13ff0bffe00c5609911ed21a14e3fea8ab708f153903f1cf613e359'
s = original
changes = []
def replace(before, after):
    global s
    assert before in s, before
    changes.append({'before': before, 'after': after, 'occurrences': s.count(before)})
    s = s.replace(before, after)

replace('Reconstruct fresh three-engine CPython samples without executing workers.', 'Reconstruct frozen G versus bulk B four-engine CPython samples without executing workers.')
replace("assert len(sys.argv)==3 and sys.argv[1] in ['normal','pgo'] and sys.argv[2]=='--released', 'Both timing campaigns must be completed/reaped and explicitly released before this reader runs'\nMODE=sys.argv[1]\nB=Path('/tmp/oriole-cdata-finder-'+MODE+'-python-study')", "assert sys.argv[1:]==['--released'], 'The B Python timing campaign must be completed/reaped and explicitly released before this saved-data reader runs'\nMODE='bulk-g-versus-b'\nB=Path('/tmp/oriole-bulk-pgo-training-study/python')")
replace("OUT = Path('/tmp/oriole-cdata-finder-python-elapsed-independent-review') / MODE", "OUT = Path('/tmp/oriole-bulk-pgo-python-elapsed-independent-review')")
replace("engines = ['control', 'candidate', 'expat']", "engines = ['oriole-g', 'oriole-b', 'expat-g', 'expat-b']")
replace("normalized_commands['control']", "normalized_commands['oriole-g']")
replace("engine == 'expat'", "engine.startswith('expat-')")
replace("ratio_pairs = [('candidate', 'control'), ('candidate', 'expat'), ('control', 'expat')]", "ratio_pairs = [('oriole-b', 'oriole-g'), ('expat-b', 'expat-g'), ('oriole-g', 'expat-g'), ('oriole-b', 'expat-b')]")
replace('== 72', '== 96')
replace('== 504', '== 672')
replace("{'preflight_warmups': 72, 'time_warmups': 504, 'time_measured': 25788}", "{'preflight_warmups': 96, 'time_warmups': 672, 'time_measured': 34384}")
replace('len(raw_hashes)==1728 and sum(counts.values())==26364', 'len(raw_hashes)==2304 and sum(counts.values())==35152')
replace("'preflights':72,'timed_rows':0", "'preflights':96,'timed_rows':0")
replace("'preflights':72,'timed_rows':504", "'preflights':96,'timed_rows':672")
before = "[str(B/'build_consumers.py'),'--library',adaptation['libraries']['candidate']['path'],'--reference',adaptation['libraries']['control']['path'],'--expat',adaptation['libraries']['expat']['path'],'--source'"
after = "[str(B/'build_consumers.py'),'--oriole-g',adaptation['libraries']['oriole-g']['path'],'--oriole-b',adaptation['libraries']['oriole-b']['path'],'--expat-g',adaptation['libraries']['expat-g']['path'],'--expat-b',adaptation['libraries']['expat-b']['path'],'--source'"
replace(before, after)
a = s.index('# Bind the unchanged numerical reconstruction')
b = s.index('# Controller bounds', a)
binding = '''# Bind this reconstruction to independently reviewed four-engine source preparation.
protocol_path=Path('/tmp/oriole-bulk-pgo-python-independent-source-review.json')
build_review_path=B/'root-preflight-review.json'
assert sha(protocol_path)=='e610d93f1b897ee6b9ffd0e184256c5ff9982ad7a1150291dec47bb67e19d6c5'
assert sha(build_review_path)=='6b4b84a4a00817d737e0c5c86fca130bd8ca0ff9235dae7255b92434299e39e4'
protocol_review=load(protocol_path);build_review=load(build_review_path)
assert protocol_review['status']=='passed_bounded_independent_source_review' and build_review['status']=='passed'
for name,expected in protocol_review['pins'].items():assert sha(B/name)==expected
assert sha(S/'preflight.json')==build_review['preflight_sha256']=='e2a240ece6ac0fc5b3a89a83e6922edbf94cd019728b82a066508532a5b0cdbb'
assert sha(B/'consumers/build.json')==build_review['build_sha256']=='4196006edb352a00c595b70f30d55f83facca2884ecb10c2aae90e20c49dfbc5'
for path,expected in load(B/'preparation-freeze.json')['files'].items():assert sha(path)==expected
preparation=load(B/'preparation.json');parent=Path('/tmp/oriole-cdata-finder-pgo-python-study')
for name,change in preparation['changes'].items():
    before=read(parent/name).decode();after=before
    for oldtext,newtext in change['replacements']:
        assert oldtext in after
        after=after.replace(oldtext,newtext)
    assert after==read(B/name).decode()
    assert sha(parent/name)==change['parent_sha256'] and sha(B/name)==change['sha256']
    reverse=after
    for oldtext,newtext in reversed(change['replacements']):reverse=reverse.replace(newtext,oldtext)
    assert reverse==before and ast.dump(ast.parse(reverse))==ast.dump(ast.parse(before))
    diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(parent/name),tofile=str(B/name)))
    assert diff==read(B/(name+'.patch')).decode()
assert len(adaptation['input_pins'])==98
for path,expected in adaptation['input_pins'].items():assert sha(path)==expected
for name,expected in adaptation['files'].items():assert sha(B/name)==expected
assert adaptation['libraries']==protocol_review['libraries']
for field in ['build_review','native_review']:
    entry=adaptation[field];assert sha(entry['path'])==entry['sha256']
native_protocol=load('/tmp/oriole-bulk-pgo-training-study/native/native-screen/protocol.json')
assert adaptation['libraries']==native_protocol['libraries']
for engine in engines:
    assert sha(adaptation['libraries'][engine]['path'])==libraries[engine]
    assert sha(build['consumers'][engine]['library'])==libraries[engine]
assert adaptation['conditions']==conditions
assert adaptation['ratios']==[list(pair) for pair in ratio_pairs]
assert adaptation['counts']=={'conditions':24,'engines':4,'extensions':8,'preflights':96,'cohorts':168,'pairs':7,'timed_workers':672,'measured_parses':34384,'warmups':672,'all_workers':768,'all_samples':35152}
assert adaptation['bounds']=={'prepare_cpu':3,'timing_cpu':0,'build_seconds':600,'preflight_aggregate_seconds':600,'worker_seconds':300,'timing_aggregate_seconds':1200}
assert adaptation['seed']==202609104412
for suffix,expected in [('/Modules/pyexpat.c','fd679a16f36304444af11953ad276d4493f2044f904a39b8fdf028c6f7def8a0'),('/Modules/_elementtree.c','de4c3c8716f7e3b1d2fdf077656246220ef0493053c990ca7b724ad31498fad0')]:
    assert [value for path,value in build['source_sha256_before'].items() if path.endswith(suffix)]==[expected]
# Compare all eight actual compiler vectors to the previous Finder control too.
old_build=load(parent/'consumers/build.json')
old_consumer=old_build['consumers']['control']
old_normalized=[[arg.replace(old_consumer['library'],'<PARSER-LIBRARY>').replace(old_consumer['directory'],'<CONSUMER-DIR>') for arg in row['command']] for row in old_consumer['commands']]
assert all(v==old_normalized for v in normalized_commands.values())
'''
s = s[:a] + binding + s[b:]
replace("regressions=[{'condition':s['condition'],'ratio':s['median_ratios']['candidate_over_control']} for s in summaries if s['median_ratios']['candidate_over_control']>1]", "regressions={a+'_over_'+b:[{'condition':s['condition'],'ratio':s['median_ratios'][a+'_over_'+b]} for s in summaries if s['median_ratios'][a+'_over_'+b]>1] for a,b in ratio_pairs}")
a=s.index("review={'status':'passed'")
b=s.index("save('review.json',review)",a)
s=s[:a]+'''review={
    'status':'passed','mode':MODE,
    'role':'Independent saved reconstruction of root-collected bulk B versus frozen G Python timings. Reviewer source-reviewed the producer adapters and adapted the old Finder saved reader; did not author the B producer or collect this elapsed campaign.',
    'protocol_review_sha256':sha(protocol_path),'root_build_preflight_review_sha256':sha(build_review_path),
    'consumer_scope':'Unmodified CPython3.12.13 pyexpat.c fd679a16 and _elementtree.c de4c3c87; strict cleanup-backport source is excluded.',
    'preparation_history':'Producer first build and preflight passed. Any independent reader failure and correction is retained separately; no target rerun.',
    'library_bindings':adaptation['libraries'],'preflight_sha256':sha(S/'preflight.json'),'results_sha256':sha(S/'results.json'),'build_sha256':sha(B/'consumers/build.json'),
    'counts':dict(counts),'workers':{'preflight':96,'timed':672,'total':768,'cohorts':168,'raw_streams_and_specs':2304,'same_process_origins':768,'extension_builds':8,'total_samples':35152},
    'unchanged_input_files':len(tracked),'groups':groups,'regressions':regressions,'retained_conditions':24,'findings':[],
    'limits':[
        'This fixed cohort compares frozen generated G and bulk B PGO policy per engine. Both Oriole libraries use LLVM22 O3 ThinLTO; both Expat libraries use GCC13.3 O3 without LTO. No source optimization or cross-cohort speedup arithmetic.',
        'Both consumers enable namespace processing. Timing includes parser construction/feed/close, Python callbacks/tree creation and explicit result destruction; imports, input reads, canonical comparison and explicit gc.collect are outside. Automatic GC remains enabled.',
        'Canonical pyexpat observation combines adjacent text callbacks and is separate from strict compatibility. XML_Parse origin is attested in every worker through its loaded extension; full application behavior and host cache/frequency effects are outside this fixed study.',
        'No target, compiler or producer controller was executed in this audit.'],
    'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'details_sha256':hashlib.sha256((OUT/'details.json.gz').read_bytes()).hexdigest()}
'''+s[b:]
ast.parse(s)
assert not any(isinstance(node,(ast.Import,ast.ImportFrom)) and any(alias.name.startswith(('subprocess','ctypes')) for alias in node.names) for node in ast.walk(ast.parse(s)))
assert not new.exists()
new.write_text(s)
delta=Path('/tmp/oriole-bulk-python-elapsed-audit.patch')
delta.write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile=str(old),tofile=str(new))))
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt={
    'status':'prepared_not_executed','source_reader':str(old),'source_reader_sha256':h(old),'reader':str(new),'reader_sha256':h(new),'delta':str(delta),'delta_sha256':h(delta),
    'scope':'Source-only small reads and inert AST parsing during active elapsed. No result/preflight raw files, compiled libraries or98-input scan read by preparer. No parser/compiler/producer execution.',
    'changes':'Four engine identifiers, four ratio comparisons,96+672 process counts, eight command/library bindings and B preparation/provenance replace Finder-specific bindings. Full per-sample reconstruction, canonical/origin checks, seeded shuffle, per-process/pair medians and geomean arithmetic retained.',
    'expected_counts':{'conditions':24,'cohorts':168,'preflights':96,'timed_workers':672,'all_workers':768,'measured_parses':34384,'timed_warmups':672,'all_samples':35152,'raw_streams_and_specs':2304},
    'reader_command_held':['taskset','-c','6','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S',str(new),'--released'],
    'release':'HELD until root confirms elapsed48929 completed/reaped and releases saved-data scan. Fresh output directory fails if reused.',
    'preparer_sha256':h(__file__)}
out=Path('/tmp/oriole-bulk-python-elapsed-audit-preparation.json')
out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':h(out),'reader_sha256':h(new),'delta_sha256':h(delta)}))
