"""Reconstruct frozen G versus bulk B four-engine CPython samples without executing workers."""
from pathlib import Path
import os
os.sched_setaffinity(0, {6})
from collections import Counter
import gzip
import hashlib
import json
import math
import random
import statistics

if not __debug__:
    raise RuntimeError('Audit assertions must run')
import sys, ast, difflib
assert sys.argv[1:]==['--released'], 'The B Python timing campaign must be completed/reaped and explicitly released before this saved-data reader runs'
MODE='bulk-g-versus-b'
B=Path('/tmp/oriole-bulk-pgo-training-study/python')
S = B / 'screen'
OUT = Path('/tmp/oriole-bulk-pgo-python-elapsed-independent-review')
OUT.mkdir(parents=True,exist_ok=False)
tracked={}
def read(p):
    p=Path(p);raw=p.read_bytes();value=hashlib.sha256(raw).hexdigest()
    assert tracked.setdefault(str(p),value)==value,('changed during audit',str(p))
    return raw
def sha(p):
    p=str(Path(p))
    if p not in tracked:read(p)
    return tracked[p]
def load(p):return json.loads(read(p))
pre = load(S / 'preflight.json')
r = load(S / 'results.json')
build = load(B / 'consumers/build.json')
assert pre['status'] == 'preflight_passed' and r['status'] == 'passed'
assert pre['affinity'] == [3] and r['affinity'] == [0]
assert pre['kind'] == r['kind'] == 'python'
assert r['preflight_sha256'] == sha(S / 'preflight.json')
assert pre['conditions'] == r['conditions']
assert r['preflights'] == pre['preflights'] and r['expected'] == pre['expected']
assert len(pre['processes']) == len(pre['preflights']) == 96
assert len(r['processes']) == len(r['rows']) == 672
assert pre['pairs'] == r['pairs'] == 7
assert pre['seed'] == r['seed'] == 202609104412
assert pre['hashes_before'] == pre['hashes_after'] == r['hashes_before'] == r['hashes_after']
for record in [pre, r]:
    assert not record['hash_errors']
    assert all(sha(p) == h for p, h in record['hashes_before'].items())
assert sha(B / 'python_worker.py') == '4bc0ccffedb5048412b9cfc3638d28dcb30f711891c3784f3fbd3c0eb536ab68'
assert build['status'] == 'passed' and build['adaptations'] is None
assert build['cpython_revision'] == '3bb231a6a5dc02b95658877318bf61501a7209e9'
assert build['source_sha256_before'] == build['source_sha256_after']
assert all(sha(p) == h for p, h in build['source_sha256_before'].items())
engines = ['oriole-g', 'oriole-b', 'expat-g', 'expat-b']
adaptation = load(B / 'adaptation.json')
libraries = {k:v['sha256'] for k,v in adaptation['libraries'].items()}
assert set(build['consumers']) == set(engines)
normalized_commands = {}
for engine, consumer in build['consumers'].items():
    assert sha(consumer['library']) == libraries[engine]
    assert all(sha(p) == h for p, h in consumer['files'].items())
    assert len(consumer['commands']) == 2
    normalized = []
    for module, command in zip(['pyexpat', '_elementtree'], consumer['commands'], strict=True):
        args = command['command']
        assert command['returncode'] == 0 and args[:4] == ['cc', '-shared', '-fPIC', '-O2']
        assert sha(Path(consumer['directory']) / (module + '-build.log')) == command['log_sha256']
        assert args[-4] == consumer['library'] and args[-3]=='-Wl,-rpath,'+consumer['directory'] and args[-2]=='-o' and Path(args[-1]).name.startswith(module+'.cpython-312-')
        assert args[-5].endswith('/Modules/'+('pyexpat.c' if module=='pyexpat' else '_elementtree.c')) and sha(args[-5])==build['source_sha256_before'][args[-5]]
        normalized.append([x.replace(consumer['library'], '<PARSER-LIBRARY>').replace(consumer['directory'], '<CONSUMER-DIR>') for x in args])
    normalized_commands[engine] = normalized
assert all(v == normalized_commands['oriole-g'] for v in normalized_commands.values())

manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
iterations = {'vulkan': 3, 'wayland': 16, 'maven': 32, 'batik': 128, 'gtk': 64, 'docbook': 64}
conditions = []
for project in load(manifest)['projects']:
    entry = next(x for x in project['files'] if x['role'] == 'input')
    path = (manifest.parent / entry['path']).resolve()
    assert sha(path) == entry['sha256']
    for chunk in [4096, 65536]:
        for mode in ['elementtree', 'pyexpat-events']:
            conditions.append({'name': project['name'], 'chunk': chunk, 'mode': mode, 'input': str(path), 'iterations': iterations[project['name']]})
assert conditions == r['conditions'] and len(conditions) == 24
assert set(pre['expected'])=={f"{c['name']}/{c['chunk']}/{c['mode']}" for c in conditions}
key = lambda c: f"{c['name']}/{c['chunk']}/{c['mode']}"
condition_map = {key(c): c for c in conditions}
index = {}
counts = Counter()
raw_hashes = {}
for phase, record, rowname in [('preflight', pre, 'preflights'), ('time', r, 'rows')]:
    processes = {p['label']: p for p in record['processes']}
    assert len(processes) == len(record['processes'])
    assert set(processes) == {row['process'] for row in record[rowname]}
    assert [p['label'] for p in record['processes']]==[row['process'] for row in record[rowname]]
    for row in record[rowname]:
        process = processes[row['process']]
        assert process['status'] == 'passed' and process['returncode'] == 0 and process['timeout_seconds'] == 300
        assert 'failure' not in process
        for stream in ['stdout', 'stderr']:
            path = S / process[stream]
            assert sha(path) == process[stream + '_sha256']
            raw_hashes[str(path)] = sha(path)
        assert not gzip.decompress(read(S / process['stderr']))
        raw = json.loads(gzip.decompress(read(S / process['stdout'])))
        assert raw['gc_enabled'] is True and raw['python']==build['python']==record['python_version']
        assert set(raw)=={'identity','python','gc_enabled','samples'}
        assert set(raw['identity'])=={'pyexpat','_elementtree','parser_library','expat_version'}
        assert raw['samples'] == row['samples'] and raw['identity'] == row['identity']
        engine = row['engine']
        consumer = build['consumers'][engine]
        assert raw['identity']['parser_library']['sha256'] == libraries[engine]
        assert raw['identity']['expat_version'] == ('expat_2.8.4' if engine.startswith('expat-') else 'oriole_compat_2.8.4')
        for name in ['pyexpat', '_elementtree', 'parser_library']:
            entry = raw['identity'][name]
            assert consumer['files'][entry['path']] == entry['sha256'] == sha(entry['path'])
        command = process['command']
        assert command[0]=='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3' and len(command)==6
        assert 0<=process['wall_seconds']<300 and (S/process['stdout']).name==process['label']+'-stdout.gz' and (S/process['stderr']).name==process['label']+'-stderr.gz'
        assert command[1:5] == ['-I', '-S', str(B / 'python_worker.py'), '--worker']
        specpath = Path(command[-1])
        assert specpath.parent==S and specpath.name==process['label']+'.json'
        spec = load(specpath)
        raw_hashes[str(specpath)] = sha(specpath)
        c = condition_map[row['key']]
        count = 0 if phase == 'preflight' else c['iterations']
        assert spec == {'input': c['input'], 'input_sha256': sha(c['input']), 'chunk': c['chunk'], 'mode': c['mode'], 'consumer': consumer['directory'], 'library_sha256': libraries[engine], 'iterations': count}
        assert len(raw['samples']) == count + 1
        for i, sample in enumerate(raw['samples']):
            assert set(sample)=={'iteration','warmup','parse_ns','destruction_ns','seconds','output_sha256','output_rows'}
            assert type(sample['parse_ns']) is int and type(sample['destruction_ns']) is int and type(sample['output_rows']) is int
            assert sample['iteration'] == i and sample['warmup'] == (i == 0)
            assert sample['seconds'] == (sample['parse_ns'] + sample['destruction_ns']) / 1e9
            assert sample['seconds'] > 0 and math.isfinite(sample['seconds'])
            assert sample['parse_ns'] >= 0 and sample['destruction_ns'] >= 0
            assert [sample['output_sha256'], sample['output_rows']] == pre['expected'][row['key']]
            counts[phase + ('_warmups' if i == 0 else '_measured')] += 1
        median = statistics.median(s['seconds'] for s in raw['samples'][1:]) if count else None
        assert row['median_seconds'] == median
        if phase == 'time':
            identity = (row['key'], row['pair'], engine)
            assert identity not in index
            index[identity] = median
expected_preflights = [(key(c), engine) for c in conditions for engine in engines]
assert [(row['key'], row['engine']) for row in pre['preflights']] == expected_preflights
rng = random.Random(r['seed'])
jobs = [(condition, pair) for condition in conditions for pair in range(7)]
rng.shuffle(jobs)
order = []
for c, pair in jobs:
    shuffled = engines.copy()
    rng.shuffle(shuffled)
    order.extend((key(c), pair, engine, position) for position, engine in enumerate(shuffled))
assert order == [(row['key'], row['pair'], row['engine'], row['order']) for row in r['rows']]
ratio_pairs = [('oriole-b', 'oriole-g'), ('expat-b', 'expat-g'), ('oriole-g', 'expat-g'), ('oriole-b', 'expat-b')]
summaries = []
for c in conditions:
    medians = {engine: [index[key(c), pair, engine] for pair in range(7)] for engine in engines}
    ratios = {a + '_over_' + b: [medians[a][pair] / medians[b][pair] for pair in range(7)] for a, b in ratio_pairs}
    summaries.append({'condition': c, 'process_pair_medians_seconds': medians, 'paired_ratios': ratios,
                      'median_ratios': {name: statistics.median(v) for name, v in ratios.items()}})
assert summaries == r['summary']
assert counts == {'preflight_warmups': 96, 'time_warmups': 672, 'time_measured': 34384}
groups = {}
for group in ['all', 'elementtree', 'pyexpat-events']:
    selected = [s for s in summaries if group == 'all' or s['condition']['mode'] == group]
    groups[group] = {}
    for a, b in ratio_pairs:
        name = a + '_over_' + b
        values = [s['median_ratios'][name] for s in selected]
        geo = math.exp(sum(math.log(v) for v in values)/len(values))
        actual = {'geomean': geo, 'below_one': sum(v < 1 for v in values), 'conditions': len(values)}
        groups[group][name] = actual
project_groups = {}
for project in iterations:
    selected = [s for s in summaries if s['condition']['name'] == project]
    project_groups[project] = {a + '_over_' + b: math.exp(statistics.mean(math.log(s['median_ratios'][a + '_over_' + b]) for s in selected)) for a, b in ratio_pairs}

# Bind this reconstruction to independently reviewed four-engine source preparation.
protocol_path=Path('/tmp/oriole-bulk-pgo-python-independent-source-review.json')
build_review_path=B/'root-preflight-review.json'
assert sha(protocol_path)=='e610d93f1b897ee6b9ffd0e184256c5ff9982ad7a1150291dec47bb67e19d6c5'
assert sha(build_review_path)=='6b4b84a4a00817d737e0c5c86fca130bd8ca0ff9235dae7255b92434299e39e4'
protocol_review=load(protocol_path);build_review=load(build_review_path)
assert protocol_review['status']=='passed_bounded_independent_source_review' and build_review['status']=='passed'
for name,expected in protocol_review['pins'].items():assert sha(B/name)==expected
assert sha(S/'preflight.json')==build_review['preflight_sha256']=='e2a240ece6ac0fc5b3a89a83e6922edbf94cd019728b82a066508532a5b0cdbb'
assert sha(B/'consumers/build.json')==build_review['build_sha256']=='4196006edb352a00c595b70f30d55f83facca2884ecb10c2aae90e20c49dfbc5'
for path,expected in load(B/'preparation-freeze.json')['files'].items():assert sha(path)==expected
preparation=load(B/'preparation.json');parent=Path('/tmp/oriole-cdata-finder-pgo-python-study')
for name,change in preparation['changes'].items():
    before=read(parent/name).decode();after=before
    for oldtext,newtext in change['replacements']:
        assert oldtext in after
        after=after.replace(oldtext,newtext)
    assert after==read(B/name).decode()
    assert sha(parent/name)==change['parent_sha256'] and sha(B/name)==change['sha256']
    reverse=after
    for oldtext,newtext in reversed(change['replacements']):reverse=reverse.replace(newtext,oldtext)
    assert reverse==before and ast.dump(ast.parse(reverse))==ast.dump(ast.parse(before))
    diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(parent/name),tofile=str(B/name)))
    assert diff==read(B/(name+'.patch')).decode()
assert len(adaptation['input_pins'])==98
for path,expected in adaptation['input_pins'].items():assert sha(path)==expected
for name,expected in adaptation['files'].items():assert sha(B/name)==expected
assert adaptation['libraries']==protocol_review['libraries']
for field in ['build_review','native_review']:
    entry=adaptation[field];assert sha(entry['path'])==entry['sha256']
native_protocol=load('/tmp/oriole-bulk-pgo-training-study/native/native-screen/protocol.json')
assert adaptation['libraries']==native_protocol['libraries']
for engine in engines:
    assert sha(adaptation['libraries'][engine]['path'])==libraries[engine]
    assert sha(build['consumers'][engine]['library'])==libraries[engine]
assert adaptation['conditions']==conditions
assert adaptation['ratios']==[list(pair) for pair in ratio_pairs]
assert adaptation['counts']=={'conditions':24,'engines':4,'extensions':8,'preflights':96,'cohorts':168,'pairs':7,'timed_workers':672,'measured_parses':34384,'warmups':672,'all_workers':768,'all_samples':35152}
assert adaptation['bounds']=={'prepare_cpu':3,'timing_cpu':0,'build_seconds':600,'preflight_aggregate_seconds':600,'worker_seconds':300,'timing_aggregate_seconds':1200}
assert adaptation['seed']==202609104412
for suffix,expected in [('/Modules/pyexpat.c','fd679a16f36304444af11953ad276d4493f2044f904a39b8fdf028c6f7def8a0'),('/Modules/_elementtree.c','de4c3c8716f7e3b1d2fdf077656246220ef0493053c990ca7b724ad31498fad0')]:
    assert [value for path,value in build['source_sha256_before'].items() if path.endswith(suffix)]==[expected]
# Compare all eight actual compiler vectors to the previous Finder control too.
old_build=load(parent/'consumers/build.json')
old_consumer=old_build['consumers']['control']
old_normalized=[[arg.replace(old_consumer['library'],'<PARSER-LIBRARY>').replace(old_consumer['directory'],'<CONSUMER-DIR>') for arg in row['command']] for row in old_consumer['commands']]
assert all(v==old_normalized for v in normalized_commands.values())
# Controller bounds, completed receipts and exact retained stream inventories.
phase_jobs={}
for filename,wanted in [('prepare-controller.json',['build','preflight']),('time-controller.json',['time'])]:
    controller=load(B/filename)
    assert controller['status']=='passed' and controller['controller_sha256']==sha(B/'run.py')
    assert [j['label'] for j in controller['jobs']]==wanted
    for job in controller['jobs']:
        label=job['label'];phase_jobs[label]=job
        assert job['exit']==0 and 'error' not in job
        assert job['timeout_seconds']==(1200 if label=='time' else 600)
        assert 0<job['end']-job['start']<job['timeout_seconds']
        assert sha(B/(label+'-controller.log'))==job['log_sha256']
        assert job['command'][:3]==['taskset','-c','0' if label=='time' else '3']
        assert job['command'][3:6]==['/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3','-I','-S']
        if label!='build':
            assert job['command'][6:]==[str(B/'consumer_screen.py'),'--phase','time' if label=='time' else 'prepare','--kind','python','--build',str(B/'consumers/build.json'),'--input',str(manifest),'--output',str(S)]
        else:
            assert job['command'][6:]==[str(B/'build_consumers.py'),'--oriole-g',adaptation['libraries']['oriole-g']['path'],'--oriole-b',adaptation['libraries']['oriole-b']['path'],'--expat-g',adaptation['libraries']['expat-g']['path'],'--expat-b',adaptation['libraries']['expat-b']['path'],'--source','/home/dev-user/.cache/oriole/upstream/cpython-3.12.13','--header',str(Path(adaptation['header']['path']).parent),'--output',str(B/'consumers')]
assert phase_jobs['build']['end']<=phase_jobs['preflight']['start']<phase_jobs['preflight']['end']<=phase_jobs['time']['start']
for phase, record, phase_rows in [('prepare',pre,pre['preflights']),('time',r,r['rows'])]:
    for row in phase_rows:
        pair=-1 if phase=='prepare' else row['pair']
        assert row['pair']==pair
        assert row['process']==row['key'].replace('/','-')+'-'+row['engine']+'-'+str(pair)+'-0'
assert set(raw_hashes)=={str(p) for p in S.iterdir() if p.is_file() and p.name not in ['preflight.json','results.json']}
assert len(raw_hashes)==2304 and sum(counts.values())==35152
assert load(B/'preflight-controller.log')=={'status':'preflight_passed','kind':'python','preflights':96,'timed_rows':0}
assert load(B/'time-controller.log')=={'status':'passed','kind':'python','preflights':96,'timed_rows':672}
regressions={a+'_over_'+b:[{'condition':s['condition'],'ratio':s['median_ratios'][a+'_over_'+b]} for s in summaries if s['median_ratios'][a+'_over_'+b]>1] for a,b in ratio_pairs}
for path,h in list(tracked.items()):assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h,('changed after audit',path)
def save(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
details={'input_hashes':tracked,'raw_hashes':raw_hashes,'conditions':summaries,'regressions':regressions,'normalized_build_commands':normalized_commands,'project_groups':project_groups}
(OUT/'details.json.gz').write_bytes(gzip.compress(json.dumps(details,sort_keys=True,separators=(',',':')).encode(),mtime=0))
review={
    'status':'passed','mode':MODE,
    'role':'Independent saved reconstruction of root-collected bulk B versus frozen G Python timings. Reviewer source-reviewed the producer adapters and adapted the old Finder saved reader; did not author the B producer or collect this elapsed campaign.',
    'protocol_review_sha256':sha(protocol_path),'root_build_preflight_review_sha256':sha(build_review_path),
    'consumer_scope':'Unmodified CPython3.12.13 pyexpat.c fd679a16 and _elementtree.c de4c3c87; strict cleanup-backport source is excluded.',
    'preparation_history':'Producer first build and preflight passed. Any independent reader failure and correction is retained separately; no target rerun.',
    'library_bindings':adaptation['libraries'],'preflight_sha256':sha(S/'preflight.json'),'results_sha256':sha(S/'results.json'),'build_sha256':sha(B/'consumers/build.json'),
    'counts':dict(counts),'workers':{'preflight':96,'timed':672,'total':768,'cohorts':168,'raw_streams_and_specs':2304,'same_process_origins':768,'extension_builds':8,'total_samples':35152},
    'unchanged_input_files':len(tracked),'groups':groups,'regressions':regressions,'retained_conditions':24,'findings':[],
    'limits':[
        'This fixed cohort compares frozen generated G and bulk B PGO policy per engine. Both Oriole libraries use LLVM22 O3 ThinLTO; both Expat libraries use GCC13.3 O3 without LTO. No source optimization or cross-cohort speedup arithmetic.',
        'Both consumers enable namespace processing. Timing includes parser construction/feed/close, Python callbacks/tree creation and explicit result destruction; imports, input reads, canonical comparison and explicit gc.collect are outside. Automatic GC remains enabled.',
        'Canonical pyexpat observation combines adjacent text callbacks and is separate from strict compatibility. XML_Parse origin is attested in every worker through its loaded extension; full application behavior and host cache/frequency effects are outside this fixed study.',
        'No target, compiler or producer controller was executed in this audit.'],
    'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'details_sha256':hashlib.sha256((OUT/'details.json.gz').read_bytes()).hexdigest()}
save('review.json',review)
print(json.dumps({'status':'passed','mode':MODE,'groups':groups,'unchanged_input_files':len(tracked),'review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest()},indent=2))
