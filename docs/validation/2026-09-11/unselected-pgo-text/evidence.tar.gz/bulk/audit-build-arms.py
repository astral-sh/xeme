"""Audit saved bulk-arm compiler, source, profile and replay evidence; no targets."""
import hashlib,json,re,shlex,tarfile
from pathlib import Path
P=Path('/tmp/oriole-bulk-pgo-training-study')
C=Path('/tmp/oriole-real-pgo-training-study')
import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--expected-normal-preflight',required=True)
args=parser.parse_args()
assert re.fullmatch('[0-9a-f]{64}',args.expected_normal_preflight)
S=Path('/home/dev-user/code/oss/oriole-cdata-finder')
H=Path('/tmp/oriole-cdata-finder-pgo-study')
PY='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
pins={}
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):
 p=Path(p);pins[str(p)]=sha(p);return json.loads(p.read_text())
def checked(p,h):
 assert sha(p)==h,str(p)
 pins[str(p)]=h
def tree(root):return {p.name:sha(p) for p in Path(root).iterdir() if p.is_file()}
prep=read(P/'preparation.json');pre=read(P/'normal-preflight.json')
checked(P/'preparation.json','6fc457fe0247fa71784932bb3ff35ad4804180388ed9e6adc68c79b178a9e80b')
checked(P/'normal-preflight.json',args.expected_normal_preflight)
checked(P/'independent-source-review.json','ffa9135fc4a54c6b8e20ec4172279827c7114b181e09d5dd4b9a81b9f1aa31f1')
checked(C/'build-arms-independent-review.json','c5f2a0d3f0b6a188f197785776a870a1e9cc5de084b5934aec370412f13c8dc1')
controls=read(C/'build-arms-independent-review.json')
control_preparation=read(C/'preparation.json')
assert prep['control_preparation_sha256']==sha(C/'preparation.json')
assert prep['control_build_audit_sha256']==sha(C/'build-arms-independent-review.json')
for key in ['oriole_source_sha256','pipeline_source_sha256','expat_source_sha256','gcc_tools_sha256','expat_config_sha256','normal_libraries','real_inputs','heldout_manifest_sha256','heldout_hashes']:assert prep[key]==control_preparation[key],key
assert pre['status']==prep['status']=='passed' and pre['preparation_sha256']==sha(P/'preparation.json')
for key,name in [('prepare_sha256','prepare.py'),('controller_sha256','build_arms.py'),('normal_preflight_controller_sha256','run_normal_preflight.py'),('native_preparation_controller_sha256','prepare_native.py')]:checked(P/name,prep[key])
assert len(prep['oriole_source_sha256'])==70 and len(prep['pipeline_source_sha256'])==67
for name,h in prep['oriole_source_sha256'].items():checked(S/name,h)
for name,h in prep['pipeline_source_sha256'].items():assert prep['oriole_source_sha256'][name]==h
assert prep['oriole_source_sha256']==read(H/'source.json')['source_sha256']
with tarfile.open(H/'source.tar.gz') as t:
 archive={m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}
assert archive==prep['oriole_source_sha256'];pins[str(H/'source.tar.gz')]=sha(H/'source.tar.gz')
for name,h in prep['expat_source_sha256'].items():checked(Path('/tmp/oriole-pgo-study/expat-source')/name,h)
for name,h in prep['pipeline_sha256'].items():checked(P/'pipeline/tools/pgo'/name,h)
assert len(prep['pipeline_sha256'])==8
for group in ['inputs_sha256','gcc_tools_sha256']:
 for name,h in prep[group].items():checked(name,h)
generated=tree(P/'normal-generated-inputs');assert len(generated)==13
assert generated==tree(C/'normal-generated-inputs')
checked(C/'normal-preflight.json','9c0b131602296e692cda8625235256d4d6716a8307b26fcec0e812456ae29431')
original_preflight=read(C/'normal-preflight.json')
normal={}
for e in ['oriole','expat']:
 t=pre['exact_training_reports'][e];checked(t['path'],t['sha256']);normal[e]=read(t['path'])
 assert len(normal[e]['rows'])==240 and normal[e]['experimental_bulk_training'] is True
 old_path=C/('normal-'+e+'-training.json')
 checked(old_path,t['original']['sha256'])
 assert t['original']==original_preflight['exact_training_reports'][e]
 old=read(old_path)
 frozen_training=Path(controls['libraries'][e+'-g']['use']['path']).parent
 if e=='oriole':frozen_training=frozen_training.parent
 frozen_training=frozen_training/'use-training.json'
 checked(frozen_training,controls['raw_files_sha256'][str(frozen_training)])
 assert old['rows'][:288]==read(frozen_training)['rows']
 assert normal[e]['rows']==[row for row in old['rows'] if row['chunk'] in [4096,65536]]
 assert normal[e]['xml_parse_origin']==old['xml_parse_origin']==prep['normal_libraries'][e]
 assert normal[e]['library_sha256']==old['library_sha256']
 assert normal[e]['profile_file_environment'] is None
 assert normal[e]['script_sha256']==prep['pipeline_sha256']['train.py']
 assert normal[e]['real_input_script_sha256']==prep['pipeline_sha256']['real_inputs.py']
 assert normal[e]['experimental_real_inputs']==prep['real_inputs']
 assert sum(not row['fixture'].startswith('real/') for row in normal[e]['rows'])==192
 assert sum(row['fixture'].startswith('real/') for row in normal[e]['rows'])==48
 assert normal[e]['inputs_sha256']==sha(P/'normal-generated-inputs/manifest.json')
for c in pre['commands']:
 assert c['exit']==0 and c['cpu']==5 and c['timeout']==600
 assert c['argv'][:3]==[PY,'-I','-S'] and c['argv'][-1]=='--experimental-bulk-training'
 checked(P/(c['label']+'.log'),c['log_sha256'])
assert len(pre['commands'])==2 and pre['commands'][0]['end']<=pre['commands'][1]['start']
assert pre['original_normal_preflight_sha256']==sha(C/'normal-preflight.json')
control_oriole=read(C/'oriole-g/report.json');hm=read(control_oriole['manifest']['path'])
checked(control_oriole['manifest']['path'],control_oriole['manifest']['sha256'])
metadata={'allocator_api2':'96dffcda8b0af4f2','hashbrown':'e561713ee1a868fe','memchr':'39aaaaa39085b985','oriole_storage':'8ae6edb74b4afbee','oriole':'e41f1ff64bd2ed1c','oriole_expat':'f10a79f8fbc60887'}
def vectors(m,phase):
 c=next(x for x in m['commands'] if x['label']=='build-'+phase);p=Path(m['run'])/c['log'];checked(p,c['log_sha256']);result={}
 for line in p.read_text().splitlines():
  if 'Running `' not in line or '--crate-name ' not in line:continue
  a=shlex.split(line.split('Running `',1)[1].rsplit('`',1)[0]);name=a[a.index('--crate-name')+1]
  assert name not in result;result[name]=a
 assert set(result)==set(metadata)
 return result
def canonical_rust(a,name,m,phase):
 assert a[0]=='/home/dev-user/.local/share/ohm/toolchains/ohm-1.98.1-1/bin/rustc'
 assert a[a.index('--target')+1]=='x86_64-unknown-linux-gnu'
 assert [s for s in a if s.startswith('metadata=')]==['metadata='+metadata[name]]
 assert a.count('opt-level=3')==a.count('codegen-units=1')==1
 assert [a[i+1] for i,s in enumerate(a[:-1]) if s=='--crate-type']==(['cdylib','staticlib'] if name=='oriole_expat' else ['lib'])
 assert a.count('lto=thin' if name=='oriole_expat' else 'linker-plugin-lto')==1
 profile='-Cprofile-generate='+m['run']+'/raw-profiles' if phase=='generate' else '-Cprofile-use='+m['run']+'/merged.profdata'
 assert [s for s in a if s.startswith(('-Cprofile-generate=','-Cprofile-use='))]==[profile]
 assert ('-Cllvm-args=-pgo-warn-missing-function' in a)==(phase=='use')
 assert not any(x.startswith(('-Z','panic=','target-cpu=','relocation-model=','-Cpanic=','-Ctarget-cpu=','-Crelocation-model=')) for x in a)
 out=[]
 for s in a:
  s=s.replace(m['run'],'<RUN>')
  s=re.sub(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}(?=/)','<BUILD>',s)
  s=re.sub(r'(?<=extra-filename=-)[0-9a-f]{16}$','<SUFFIX>',s)
  s=re.sub(r'(lib\w+)-[0-9a-f]{16}(\.(?:rlib|rmeta))$',r'\1-<SUFFIX>\2',s)
  out.append(s)
 return out
historical_vectors={ph:{n:canonical_rust(a,n,hm,ph) for n,a in vectors(hm,ph).items()} for ph in ['generate','use']}
reports={};manifests={};training=[];rust_vectors={};gcc_vectors={};gcc_links={};profiles={};sequence=[]
def audit_training(engine,arm,phase,p,lib,llvm_profile):
 t=read(p);expected=normal[engine]['rows']
 assert t['status']=='passed' and t['rows']==expected
 assert t['inputs_sha256']==generated['manifest.json']
 assert t['xml_parse_origin']=={'path':str(Path(lib['path']).resolve()),'sha256':lib['sha256']}
 assert t['library_sha256']==lib['sha256'];checked(lib['path'],lib['sha256'])
 assert t['script_sha256']==prep['pipeline_sha256']['train.py']
 assert t['profile_file_environment']==llvm_profile
 if arm=='b':
  assert t['experimental_bulk_training'] is True
  assert t['experimental_real_inputs']==prep['real_inputs']
  assert t['real_input_script_sha256']==prep['pipeline_sha256']['real_inputs.py']
 else:assert 'experimental_real_inputs' not in t
 assert all(r['status']==1 and r['error']==0 and not r['callback_exceptions'] for r in t['rows'])
 training.append({'engine':engine,'arm':arm,'phase':phase,'path':str(p),'sha256':sha(p),'rows':len(expected),'normal_exact':True,'origin':lib})
 return t
for engine,arm in [('oriole','b'),('expat','b')]:
 key=engine+'-'+arm;out=P/key;r=read(out/'report.json');reports[key]=r
 assert r['status']=='passed' and r['engine']==engine and r['arm']==arm
 assert r['preparation_sha256']==sha(P/'preparation.json') and r['normal_preflight_sha256']==sha(P/'normal-preflight.json')
 assert all(r['unchanged'].values())
 assert r['environment_overrides']==reports['oriole-b']['environment_overrides']
 assert r['cleared_environment']==reports['oriole-b']['cleared_environment']
 for c in r['commands']:
  assert c['exit']==0 and c['cpu']==3 and c['cwd']==str(S) and c['end']>=c['start']
  assert c['end']-c['start']<c['timeout']
  if sequence:assert c['start']>=sequence[-1]['end']
  sequence.append({'arm':key,'label':c['label'],'start':c['start'],'end':c['end']})
  checked(out/(c['label']+'.log'),c['log_sha256'])
 for lib in r['libraries'].values():checked(lib['path'],lib['sha256'])
 if engine=='oriole':
  checked(r['manifest']['path'],r['manifest']['sha256']);m=read(r['manifest']['path']);manifests[key]=m;run=Path(m['run'])
  assert read(out/'pgo/latest.json')=={'manifest':str(run/'manifest.json'),'sha256':sha(run/'manifest.json')}
  assert m['status']=='passed' and m['compared_parses']==240
  assert m['training_arm']=='B'
  assert m['experimental_real_inputs']==prep['real_inputs']
  assert m['source_sha256']==prep['pipeline_source_sha256'] and m['source']==str(S)
  assert m['script_sha256']==prep['pipeline_sha256'] and m['cpu_affinity']==[3]
  assert m['inputs_sha256']==tree(run/'inputs')==generated
  for name in ['base_rustflags','cargo_args','cargo_config_sha256','cargo_version','rustc_version','host','toolchain','python_version','profdata_version','tools_sha256']:
   assert m[name]==hm[name],(key,name)
  for group in ['cargo_config_sha256','tools_sha256']:
   for path,h in m[group].items():checked(path,h)
  assert [c['label'] for c in m['commands']]==['rustc-version','cargo-version','rustc-sysroot','profdata-version','build-generate','generate','profile-merge','profile-show','build-use','use']
  assert len(m['commands'])==10
  for c in m['commands']:
   assert c['status']=='passed' and c['returncode']==0 and c['timeout_seconds']==900 and c['cwd']==str(S)
   checked(run/c['log'],c['log_sha256'])
   assert c['environment'].get('RUSTC_WRAPPER')==c['environment'].get('RUSTC_WORKSPACE_WRAPPER')==''
   assert c['environment'].get('CARGO_INCREMENTAL')=='0'
   assert not any(k.startswith('CARGO_PROFILE_') or k.startswith('CARGO_UNSTABLE_OHM_') for k in c['environment'])
  assert r['commands'][0]['start']<=m['started_unix']<m['completed_unix']<=r['commands'][0]['end']
  rust_vectors[key]={}
  for phase in ['generate','use']:
   v=vectors(m,phase);rust_vectors[key][phase]=v
   assert {n:canonical_rust(a,n,m,phase) for n,a in v.items()}==historical_vectors[phase]
   c=next(x for x in m['commands'] if x['label']=='build-'+phase)
   assert c['argv']==['/home/dev-user/.cargo/bin/cargo','+ohm','-Zohm-defaults=no','rustc','--release','--locked','--offline','--target','x86_64-unknown-linux-gnu','-p','oriole_expat','--lib','--crate-type','cdylib,staticlib','--verbose']
   expected_flags='-Cprofile-generate='+str(run/'raw-profiles') if phase=='generate' else '-Cprofile-use='+str(run/'merged.profdata')+'\x1f-Cllvm-args=-pgo-warn-missing-function'
   assert c['environment']['CARGO_ENCODED_RUSTFLAGS']==expected_flags
   assert c['environment']['CARGO_TARGET_DIR']==str(out/'pgo/targets'/phase)
   log=(run/c['log']).read_text();assert not re.search(r'(?im)^\s*warning[:\[]|\b(?:hash mismatch|counter mismatch|malformed instrumentation profile|no profile data available)\b',log)
   tc=next(x for x in m['commands'] if x['label']==phase)
   expected_profile=str(run/'raw-profiles/oriole-%m-%p.profraw') if phase=='generate' else None
   assert tc['environment'].get('LLVM_PROFILE_FILE')==expected_profile
   assert tc['argv'][:4]==[PY,'-I','-S',str(P/'pipeline/tools/pgo/train.py')]
   checked(run/(phase+'-training.json'),m['training_sha256'][phase])
   audit_training(engine,arm,phase,run/(phase+'-training.json'),r['libraries'][phase],expected_profile)
  for n,h in m['libraries_sha256'].items():checked(run/n,h)
  raw=tree(run/'raw-profiles');assert len(raw)==1 and set(m['profiles_sha256'])==set(raw)|{'merged.profdata'}
  for n,h in m['profiles_sha256'].items():checked(run/n if n=='merged.profdata' else run/'raw-profiles'/n,h)
  for p in list((run/'raw-profiles').iterdir())+[run/'merged.profdata']:
   assert m['started_unix']<=p.stat().st_mtime<=m['completed_unix'],p
  merge=next(c for c in m['commands'] if c['label']=='profile-merge')
  assert merge['argv']==['/tmp/oriole-pgo-study/llvm-tools-1.98.0/bin/llvm-profdata','merge','--num-threads=1','--failure-mode=any','-o',str(run/'merged.profdata'),*[str(run/'raw-profiles'/n) for n in raw]]
  show=(run/'07-profile-show.log').read_text();counts={}
  for symbol in ['XML_ParserCreate','XML_ParserCreateNS','XML_Parse']:
   match=re.search(r'^  '+symbol+r':\n    Hash: [^\n]+\n    Counters: \d+\n    Block counts: (\[[^\n]+\])',show,re.M);assert match,symbol
   counts[symbol]=json.loads(match[1])
  assert counts['XML_ParserCreate']==counts['XML_ParserCreateNS']==[120,0]
  sizes={x['name']:x['bytes'] for x in read(run/'inputs/manifest.json')['rows']}
  realmanifest=read(prep['real_inputs']['manifest']);sizes.update({'real/'+x['id']:x['bytes'] for x in realmanifest['documents']})
  expected_rows=normal['oriole']['rows']
  calls=sum((sizes[x['fixture']]+x['chunk']-1)//x['chunk'] for x in expected_rows)
  assert counts['XML_Parse'][0]==calls==3388
  profiles[key]={'hashes':m['profiles_sha256'],'saved_symbol_counts':counts,'derived_XML_Parse_calls':calls,'fresh_run':str(run),'status':'passed'}
 else:
  assert r['compared_parses']==240
  assert r['tools_sha256']==prep['gcc_tools_sha256']
  assert r['compiler_version']==(out/'compiler-version.log').read_text() and '13.3.0' in r['compiler_version']
  basecache=Path('/home/dev-user/.cache/oriole/expat-build/CMakeCache.txt').read_text()
  features=dict(re.findall(r'^(EXPAT_[A-Z0-9_]+):(?:BOOL|STRING|UNINITIALIZED)=(.*)$',basecache,re.M));assert r['features']==features
  assert tree(out/'inputs')==generated
  gcc_vectors[key]={};gcc_links[key]={}
  for phase in ['generate','use']:
   build=out/(phase+'-build');checked(build/'expat_config.h',prep['expat_config_sha256'])
   cache=(build/'CMakeCache.txt').read_text();assert dict(re.findall(r'^(EXPAT_[A-Z0-9_]+):(?:BOOL|STRING|UNINITIALIZED)=(.*)$',cache,re.M))==features
   flag='-fprofile-'+phase+'='+str(out/'raw');prefix='-fprofile-prefix-path='+str(build)
   config=next(c for c in r['commands'] if c['label']==phase+'-configure')
   assert config['argv']==['/usr/bin/cmake','-S','/tmp/oriole-pgo-study/expat-source','-B',str(build),'-G','Unix Makefiles','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER=/usr/bin/cc','-DCMAKE_C_FLAGS='+flag+' '+prefix,'-DCMAKE_C_FLAGS_RELEASE=-O3 -DNDEBUG',*[f'-D{k}={v}' for k,v in features.items()]]
   log=(out/(phase+'-build.log')).read_text();assert not re.search('warning:|error:',log,re.I)
   commands=[shlex.split(l) for l in log.splitlines() if l.startswith('/usr/bin/cc ')]
   objects=[a for a in commands if '-c' in a];links=[a for a in commands if '-shared' in a]
   assert len(objects)==7 and len(links)==1
   names=['xmlparse','xmlrole','xmltok','random_arc4random','random_arc4random_buf','random_getentropy','random_getrandom']
   assert [Path(a[a.index('-c')+1]).stem for a in objects]==names
   for a in commands:
    assert a.count(flag)==a.count(prefix)==a.count('-O3')==a.count('-DNDEBUG')==a.count('-fPIC')==1
    assert not any(x.startswith(('-flto','-march=','-mtune=','-fprofile-correction','-Wno-missing-profile')) for x in a)
   assert shlex.split((build/'CMakeFiles/expat.dir/link.txt').read_text())==links[0]
   assert sha(build/'libexpat.so')==r['libraries'][phase]['sha256']
   gcc_vectors[key][phase]=objects;gcc_links[key][phase]=links[0]
   audit_training(engine,arm,phase,out/(phase+'-training.json'),r['libraries'][phase],None)
  assert tree(out/'raw')==r['profiles_sha256'] and len(r['profiles_sha256'])==7
  pcommands={c['label']:c for c in r['commands']}
  dump=(out/'profile-counts.log').read_text()
  assert len(re.findall(r'OBJECT_SUMMARY runs=1,',dump))==7 and not re.search(r'OBJECT_SUMMARY runs=(?!1,)',dump)
  for n,h in r['profiles_sha256'].items():
   p=out/'raw'/n;checked(p,h)
   assert pcommands['generate-training']['start']<=p.stat().st_mtime<=pcommands['generate-training']['end']
   assert f"{p}:data:magic `gcda':version `B33*'" in dump
  random_path=str(out/'raw/CMakeFiles#expat.dir#lib#random_arc4random_buf.c.gcda')
  count=240
  assert re.search(re.escape(random_path)+r':\s+0: '+str(count)+' '+str(count)+r'\s',dump)
  profiles[key]={'hashes':r['profiles_sha256'],'raw_directory':str(out/'raw'),'gcov_object_summaries':7,'each_runs':1,'parser_random_seed_call_count':count,'status':'passed'}
def canonical_gcc(a,out,phase):return [s.replace(str(out),'<ARM>').replace('/'+phase+'-build','/<PHASE>-build').replace('-fprofile-'+phase+'=','-fprofile-<PHASE>=') for s in a]
control_expat=read(C/'expat-g/report.json')
for phase in ['generate','use']:
 log=(C/'expat-g'/(phase+'-build.log')).read_text()
 checked(C/'expat-g'/(phase+'-build.log'),next(x['log_sha256'] for x in control_expat['commands'] if x['label']==phase+'-build'))
 args=[shlex.split(l) for l in log.splitlines() if l.startswith('/usr/bin/cc ')]
 objects=[a for a in args if '-c' in a];link=[a for a in args if '-shared' in a]
 assert len(objects)==7 and len(link)==1
 assert [canonical_gcc(a,P/'expat-b',phase) for a in gcc_vectors['expat-b'][phase]]==[canonical_gcc(a,C/'expat-g',phase) for a in objects]
 assert canonical_gcc(gcc_links['expat-b'][phase],P/'expat-b',phase)==canonical_gcc(link[0],C/'expat-g',phase)
assert [canonical_gcc(a,P/'expat-b','generate') for a in gcc_vectors['expat-b']['generate']]==[canonical_gcc(a,P/'expat-b','use') for a in gcc_vectors['expat-b']['use']]
assert profiles['oriole-b']['hashes']['merged.profdata']!=hm['profiles_sha256']['merged.profdata']
assert len(training)==4 and sum(t['rows'] for t in training)==960
for key in ['oriole-g','expat-g']:
 r=read(C/key/'report.json')
 assert r['libraries']==controls['libraries'][key]
 for lib in r['libraries'].values():checked(lib['path'],lib['sha256'])
 reports[key]=r
assert pre['commands'][-1]['end']<=sequence[0]['start']
report={'status':'passed_saved_build_audit','role':'Independent saved-data B normal/build audit. No parser/compiler/profile/disassembly execution.','selected_runtime':prep['runtime_revision'],'preparation_sha256':sha(P/'preparation.json'),'normal_preflight_sha256':sha(P/'normal-preflight.json'),'source_review_sha256':sha(P/'independent-source-review.json'),'frozen_G_build_review_sha256':sha(C/'build-arms-independent-review.json'),'source_files':70,'pipeline_source_files':67,'source_archive_sha256':sha(H/'source.tar.gz'),'source_unchanged_from_selected_Finder':True,'pipeline_files':prep['pipeline_sha256'],'commands':sequence,'normal_B_records':480,'normal_B_matches_filtered_original_GR':True,'normal_B_generated_rows_per_engine':192,'normal_B_real_rows_per_engine':48,'rust_actual_workspace_vectors':6,'rust_actual_dependency_vectors':6,'rust_vectors':rust_vectors,'rust_comparison':'All six workspace and six dependency actual B vectors match frozen G in each phase after only fresh run paths/private build paths/Cargo artifact suffixes. Metadata and every compiler option remain significant.','rust_toolchain':{k:manifests['oriole-b'][k] for k in ['rustc_version','cargo_version','profdata_version','python_version','cargo_config_sha256','tools_sha256']},'gcc_actual_object_vectors':14,'gcc_vectors':gcc_vectors,'gcc_links':gcc_links,'gcc_comparison':'Seven objects plus one shared link in each B phase match frozen G after arm paths; generate/use differ only matching profile mode/build prefix. No new flags or feature/config difference.','gcc_toolchain':{'compiler':reports['expat-b']['compiler_version'],'hashes':prep['gcc_tools_sha256'],'features':reports['expat-b']['features'],'expat_config_sha256':prep['expat_config_sha256']},'training_records':960,'training':training,'profiles':profiles,'libraries':{k:r['libraries'] for k,r in reports.items()},'blockers':[],'limitations':['B changes the training distribution and generated byte weighting; no causal or speed claim from counts.','240 records each normal/gen/use perengine:192generated plus48real. New source/scripts, old input bytes, old runtime and frozen freshG controls are explicit.','Oriole uses Ohm/LLVM22 O3 ThinLTO; Expat uses GCC13.3 O3 without LTO. Within-engine comparison comes first.','Saved manifests/logs establish provenance; this is not an independent compiler run or complete system trace.','No elapsed/performance/fullAPI claim.'], 'raw_files_sha256':pins,'reader_sha256':sha(__file__)}
dest=P/'build-arms-independent-review.json';dest.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'path':str(dest),'sha256':sha(dest),'new_rust_workspace_vectors':6,'new_gcc_objects':14,'new_training_records':960,'normal_B_records':480,'blockers':[]},indent=2))
