"""Independently reconstruct the fixed four-arm native campaign from saved workers."""
import ast,collections,difflib,hashlib,json,math,random,statistics
from pathlib import Path
P=Path('/tmp/oriole-bulk-pgo-training-study');C=Path('/tmp/oriole-real-pgo-training-study');S=P/'native';D=S/'native-screen'
import argparse,re
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--expected-build-review',required=True)
args=parser.parse_args()
assert re.fullmatch('[0-9a-f]{64}',args.expected_build_review)
B=Path('/tmp/oriole-cdata-finder-pgo-native-study')
pins={}
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p,h=None):
 actual=sha(p);assert h is None or actual==h,str(p)
 assert pins.setdefault(str(p),actual)==actual
 return actual
def read(p):pin(p);return json.loads(Path(p).read_text())
pin(P/'build-arms-independent-review.json',args.expected_build_review)
build_review=read(P/'build-arms-independent-review.json')
pin(C/'normal-preflight-independent-review.json','d2a8e3bc7b679c99511fc16afdef22ca497760224b43fd6a9bd658ed7f8e041f')
a=read(S/'adaptation.json');p=read(D/'protocol.json');f=read(D/'preflight.json');r=read(D/'results.json');ctl=read(S/'controller.json')
assert a['status']==ctl['status']==f['status']==r['status']=='passed'
pin(B/'native_screen.py',a['source_controller_sha256']);pin(S/'native_screen.py',a['controller_sha256']);pin(S/'run.py',a['wrapper_sha256']);pin(S/'adaptation.patch',a['patch_sha256'])
pin(P/'preparation.json',a['preparation_sha256'])
assert (S/'run.py').read_bytes()==(B/'run.py').read_bytes()
diff=''.join(difflib.unified_diff((B/'native_screen.py').read_text().splitlines(True),(S/'native_screen.py').read_text().splitlines(True),fromfile=str(B/'native_screen.py'),tofile=str(S/'native_screen.py')))
assert diff==(S/'adaptation.patch').read_text()
base_tree,new_tree=ast.parse((B/'native_screen.py').read_text()),ast.parse((S/'native_screen.py').read_text())
for name in ['run','digest','save']:
 original=next(x for x in base_tree.body if isinstance(x,ast.FunctionDef) and x.name==name)
 actual=next(x for x in new_tree.body if isinstance(x,ast.FunctionDef) and x.name==name)
 assert ast.dump(original)==ast.dump(actual)
for name in ['iterations','conditions','fixtures','manifest','driver']:
 original=[x for x in base_tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in x.targets)]
 actual=[x for x in new_tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in x.targets)]
 assert [ast.dump(x) for x in original]==[ast.dump(x) for x in actual]
assert ctl['controller_sha256']==sha(S/'native_screen.py') and ctl['wrapper_sha256']==sha(S/'run.py')
for row,(stage,cpu,bound) in zip(ctl['commands'],[('preflight',5,600),('time',0,1200)],strict=True):
 assert row['phase']==stage and row['exit']==0 and row['timeout']==bound and 0<row['end']-row['start']<bound
 assert row['command']==['taskset','-c',str(cpu),'python3',str(S/'native_screen.py'),stage]
 pin(S/(stage+'-controller.log'),row['log_sha256'])
assert ctl['commands'][0]['end']<=ctl['commands'][1]['start']
assert ctl['commands'][0]['start']>max(x['end'] for x in build_review['commands'])
assert r['affinity']==[0] and f['protocol_sha256']==r['protocol_sha256']==sha(D/'protocol.json')
assert r['preflight_sha256']==sha(D/'preflight.json')
for result in [f,r]:assert result['hashes_before']==result['hashes_after']==p['hashes']
for q,h in p['hashes'].items():pin(q,h)
for q,h in a['build_artifacts_sha256'].items():pin(q,h)
expected_libraries={}
engines=['oriole-g','oriole-b','expat-g','expat-b']
for engine in engines:
 origin=C if engine.endswith('-g') else P
 report=read(origin/engine/'report.json');assert report['status']=='passed'
 expected_libraries[engine]=report['libraries']['use']
 assert expected_libraries[engine]==build_review['libraries'][engine]['use']
 assert a['libraries'][engine]==expected_libraries[engine]['path']
assert p['libraries']==expected_libraries and list(p['libraries'])==engines
ratios=[('oriole-b','oriole-g'),('expat-b','expat-g'),('oriole-g','expat-g'),('oriole-b','expat-b')]
assert a['ratios']==[list(x) for x in ratios]
assert p['pairs']==a['pairs']==7 and p['seed']==2026091003
assert p['preflights']==a['preflight_workers']==112 and p['timed_workers']==a['timed_workers']==784
manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
fixtures={}
for project in read(manifest)['projects']:
 entry=next(q for q in project['files'] if q['role']=='input');path=(manifest.parent/entry['path']).resolve();pin(path,entry['sha256']);fixtures[project['name']]=str(path)
fixtures.update({'generated-rare-declarations':'/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml','generated-entities':'/tmp/oriole-grammar-bench-plain/entities.xml'})
iterations={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
conditions=[{'name':name,'input':path,'chunk':chunk,'namespaces':ns,'iterations':iterations[name]} for chunk in [4096,65536] for name,path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False,True])]
assert p['conditions']==conditions and len(conditions)==28
assert len(f['rows'])==112 and len(r['rows'])==196 and len(r['summary'])==28
assert {x.name for x in D.glob('worker-*.json')}=={f'worker-{i:04d}.json' for i in range(896)}
ordinal=0;count_samples=collections.Counter();medians={};observations={};worker_rows=[]
def worker(row,c,pair,engine,cpu,count):
 global ordinal
 path=D/f'worker-{ordinal:04d}.json';raw=read(path);idx=ordinal;ordinal+=1
 assert raw=={k:v for k,v in row.items() if k not in ['observations','median_seconds']}
 assert row['condition']==c and row['pair']==pair and row['engine']==engine and row['returncode']==0 and row['stderr']==''
 assert row['command']==['taskset','-c',str(cpu),'/tmp/oriole-grammar-bench-plain/native-driver',p['libraries'][engine]['path'],c['input'],str(c['chunk']),str(count)]+(['namespaces'] if c['namespaces'] else [])
 data=json.loads(row['stdout']);samples=data['samples']
 assert data['version']==('oriole_compat_2.8.4' if engine.startswith('oriole-') else 'expat_2.8.4')
 assert len(samples)==count+1 and [x['iteration'] for x in samples]==list(range(count+1))
 assert [x['warmup'] for x in samples]==[True]+[False]*count
 assert all(type(x['seconds']) in [int,float] and math.isfinite(x['seconds']) and x['seconds']>0 for x in samples)
 got=sorted({(x['hash'],x['elements'],x['text_bytes']) for x in samples});assert len(got)==1
 assert row['observations']==[list(x) for x in got]
 key=json.dumps(c,sort_keys=True)
 assert observations.setdefault(key,got)==got
 assert all(type(x) is int and x>=0 for x in got[0][1:])
 med=statistics.median(x['seconds'] for x in samples[1:]);assert med==row['median_seconds']
 if pair==-1:count_samples['preflight']+=len(samples)
 else:count_samples['measured']+=len(samples)-1;count_samples['timed_warmup']+=1
 worker_rows.append({'ordinal':idx,'condition':c,'pair':pair,'engine':engine,'median_seconds':med,'samples':len(samples),'raw_sha256':pins[str(path)]})
 return med
for c in conditions:
 for engine in engines:worker(f['rows'][ordinal],c,-1,engine,5,1)
rng=random.Random(2026091003);jobs=[(c,i) for c in conditions for i in range(7)];rng.shuffle(jobs)
for row,(c,pair) in zip(r['rows'],jobs,strict=True):
 order=list(engines);rng.shuffle(order)
 assert row['condition']==c and row['pair']==pair and row['order']==order
 for rec,engine in zip(row['processes'],order,strict=True):medians[(json.dumps(c,sort_keys=True),pair,engine)]=worker(rec,c,pair,engine,0,c['iterations'])
assert ordinal==896 and count_samples=={'preflight':224,'measured':140560,'timed_warmup':784}
assert sum(count_samples.values())==141568
summary=[]
for c in conditions:
 pair_order=[x['pair'] for x in r['rows'] if x['condition']==c];assert sorted(pair_order)==list(range(7))
 values={f'{x}_over_{y}':[medians[(json.dumps(c,sort_keys=True),i,x)]/medians[(json.dumps(c,sort_keys=True),i,y)] for i in pair_order] for x,y in ratios}
 summary.append({'condition':c,'paired_ratios':values,'median_ratios':{k:statistics.median(v) for k,v in values.items()}})
assert summary==r['summary']
groups={}
for group in ['real','generated']:
 entries=[x for x in summary if x['condition']['name'].startswith('generated-')==(group=='generated')]
 groups[group]={'conditions':len(entries),'ratios':{k:statistics.geometric_mean(x['median_ratios'][k] for x in entries) for k in entries[0]['median_ratios']},'lower_counts':{k:sum(x['median_ratios'][k]<1 for x in entries) for k in entries[0]['median_ratios']}}
assert groups['real']['conditions']==24 and groups['generated']['conditions']==4
adverse={key:[{'condition':x['condition'],'ratio':x['median_ratios'][key]} for x in summary if x['median_ratios'][key]>1] for key in summary[0]['median_ratios']}
for q,h in pins.items():assert sha(q)==h
out={'status':'passed_saved_native_audit','selection':'B remains an experimental training policy; root owns selection after this saved audit.','role':'Independent reconstruction of root-collected native measurements. Reviewer authored experimental training helper, independently reviewed by next_hotspot; no parser/compiler/benchmark executed for this audit.','build_review_sha256':sha(P/'build-arms-independent-review.json'),'normal_preflight_review_sha256':sha(C/'normal-preflight-independent-review.json'),'protocol_sha256':sha(D/'protocol.json'),'results_sha256':sha(D/'results.json'),'preflight_workers':112,'timed_workers':784,'all_workers':896,'cohorts':196,'samples':dict(count_samples),'total_samples':141568,'conditions':28,'pairs':7,'seed':2026091003,'groups':groups,'all_condition_paired_ratios':summary,'all_adverse_conditions_by_ratio':adverse,'observed_callbacks':{'all_samples_and_four_engines_agree_per_condition':True,'conditions':[{'condition':c,'hash_elements_text_bytes':observations[json.dumps(c,sort_keys=True)]} for c in conditions]},'libraries':expected_libraries,'worker_medians':worker_rows,'raw_files_sha256':pins,'limits':['One fixed first-attempt campaign; all seven pairs and all28conditions retained. No confidence interval or causal mechanism claim.','The unchanged native driver times parser creation, callback registration, parse/native callbacks and free. Loading/process startup are excluded. Saved hashes and explicit library paths bind artifacts; no fresh same-process XML_Parse dladdr record exists in this legacy benchmark driver. Training origins were audited separately.','Native callback hash covers names/attributes/character bytes independent of text fragmentation, plus element and text-byte counts. This is not the full XML API suite.','The G controls are the frozen fresh artifacts from the prior campaign; B is newly built. Within-engine ratios isolate this fixed training recipe under its compiler settings; cross-engine comparisons retain Ohm/LLVM22 ThinLTO versus GCC13.3 without LTO differences.','This receipt covers only the fixed native campaign; no actual Python/full API result is inferred.','No source, corpus, library, profile, producer record or assertion was changed by this reader.'],'reader_sha256':sha(__file__)}
dest=P/'native-independent-review.json';dest.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'path':str(dest),'sha256':sha(dest),'groups':groups,'workers':896,'samples':141568},indent=2))
