"""Tool-only checks: no XML parser, Cargo, compiler or profile execution."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PIPELINE = ROOT / "pipeline/tools/pgo"
PYTHON = "/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12"
UV = "/home/dev-user/.local/bin/uv"
CONFIG = "/home/dev-user/code/oss/oriole-cdata-finder/ruff.toml"
env = os.environ.copy()
env.pop("PYTHONPATH", None)
env.update(UV_TOOL_DIR=str(ROOT / "uv-tools"), UV_TOOL_BIN_DIR=str(ROOT / "uv-bin"))

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def source():
    return {p.name: sha(p) for p in sorted(PIPELINE.iterdir()) if p.is_file()}

uv = [UV, "tool", "run", "--offline", "--python", PYTHON]
ruff = uv + ["--from", "ruff==0.16.6", "ruff"]
commands = [
    ("unit-final", [PYTHON, "-I", "-S", "-B", "-m", "unittest", "discover", "-s", str(PIPELINE), "-p", "test_*.py"]),
    ("ruff-final", ruff + ["check", "--config", CONFIG, str(PIPELINE)]),
    ("format-final", ruff + ["format", "--check", "--config", CONFIG, str(PIPELINE)]),
    ("ty-final", uv + ["--from", "ty==0.0.80", "ty", "check", "--extra-search-path", str(PIPELINE.parent), str(PIPELINE)]),
]
report = {
    "role": "pipeline author; tool checks, not independent review",
    "scope": "Tests use synthetic generated/input bytes, AST fake callbacks and mocked parser/build commands. No parser, compiler, training or benchmark targets.",
    "source_before": source(),
    "tools": {p: sha(p) for p in [PYTHON, UV, CONFIG]},
    "cpu_affinity": sorted(os.sched_getaffinity(0)),
    "prior_attempts": [
        {"log": "unit-attempt01.log", "exit": 1, "reason": "Two mock-report subcases used the input manifest directory for build.Run and overwrote their synthetic manifest; fixed only test run directory. No parser/build command."},
        {"log": "unit-attempt02.log", "exit": 0, "tests": 25},
        {"log": "ruff-attempt01.log", "exit": 1, "reason": "B023: two test closure variables; bound explicitly before final checks."},
        {"log": "ty-attempt01.log", "exit": 0},
        {"log": "format.log", "exit": 0},
    ],
    "commands": [],
    "status": "running",
}
for item in report["prior_attempts"]:
    item["sha256"] = sha(ROOT / item["log"])
for label, command in commands:
    path = ROOT / f"{label}.log"
    started = time.time()
    with path.open("xb") as stream:
        result = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=180, check=False)
    report["commands"].append({"label": label, "command": command, "exit": result.returncode, "started_unix": started, "completed_unix": time.time(), "log": path.name, "log_sha256": sha(path)})
    (ROOT / "checks.json").write_text(json.dumps(report, indent=2) + "\n")
    if result.returncode:
        break
report["source_after"] = source()
report["status"] = "passed" if len(report["commands"]) == len(commands) and all(row["exit"] == 0 for row in report["commands"]) and report["source_before"] == report["source_after"] else "failed"
(ROOT / "checks.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": report["status"], "checks_sha256": sha(ROOT / "checks.json")}))
raise SystemExit(0 if report["status"] == "passed" else 1)
