"""Saved source/tool-result review of bulk PGO preparation; no target execution."""
import ast,copy,difflib,hashlib,json,math,re
from pathlib import Path
P=Path('/tmp/oriole-bulk-pgo-training-study');C=Path('/tmp/oriole-real-pgo-training-study');W=Path('/home/dev-user/code/oss/oriole-cdata-finder')
pins={}
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p,h=None):
 actual=sha(p);assert h is None or h==actual,str(p);assert pins.setdefault(str(p),actual)==actual;return actual
def read(p):pin(p);return json.loads(Path(p).read_text())
def parse(p):pin(p);return ast.parse(Path(p).read_text())
def find(tree,kind,**fields):return next(n for n in ast.walk(tree) if isinstance(n,kind) and all(getattr(n,k,None)==v for k,v in fields.items()))
def dump(node):return ast.dump(node,include_attributes=False)
pin(P/'runner-manifest.json','e864278db51b034e24eca87bfb281d5ccb0d4b74e281735eeb8318778fd947e4')
manifest=read(P/'runner-manifest.json');base=read(P/'base.json');checks=read(P/'checks.json')
pin(P/'base.json',manifest['base']['sha256']);pin(P/'pipeline.patch',manifest['patch']['sha256']);pin(P/'PLAN.md',manifest['plan']['sha256']);pin(P/'checks.json',manifest['checks']['sha256']);pin(P/'schedule-proof.json',manifest['arithmetic']['sha256'])
pin(base['runner_manifest']['path'],base['runner_manifest']['sha256'])
assert base['pipeline_sha256']==read(C/'preparation.json')['pipeline_sha256']
changed=[];patch=''
for name,h in manifest['pipeline_sha256'].items():
 pin(P/'pipeline/tools/pgo'/name,h);pin(P/'base/tools/pgo'/name,base['pipeline_sha256'][name]);pin(C/'pipeline/tools/pgo'/name,base['pipeline_sha256'][name])
 if h!=base['pipeline_sha256'][name]:changed.append(name)
 patch+=''.join(difflib.unified_diff((P/'base/tools/pgo'/name).read_text().splitlines(True),(P/'pipeline/tools/pgo'/name).read_text().splitlines(True),fromfile='base/tools/pgo/'+name,tofile='pipeline/tools/pgo/'+name))
assert changed==manifest['changed_files']==['README.md','build.py','test_real_inputs.py','train.py']
assert patch==(P/'pipeline.patch').read_text()
assert checks['status']=='passed' and checks['source_before']==checks['source_after']==manifest['pipeline_sha256']
for path,h in checks['tools'].items():pin(path,h)
for c in checks['commands']:
 assert c['exit']==0;pin(P/c['log'],c['log_sha256'])
for c in checks['prior_attempts']:pin(P/c['log'],c['sha256'])
assert 'Ran 25 tests' in (P/'unit-final.log').read_text() and (P/'unit-final.log').read_text().endswith('\nOK\n')
assert [c['label'] for c in checks['commands']]==['unit-final','ruff-final','format-final','ty-final']
before=parse(P/'base/tools/pgo/train.py');after=parse(P/'pipeline/tools/pgo/train.py')
ast_checks={}
for name in ['verify_origin','exercise','parser_scope']:
 a=find(before,ast.FunctionDef,name=name);b=find(after,ast.FunctionDef,name=name);assert dump(a)==dump(b);ast_checks[name]=hashlib.sha256(dump(b).encode()).hexdigest()
old_loop=next(n for n in ast.walk(before) if isinstance(n,ast.For) and ast.unparse(n.target)=='fixture' and ast.unparse(n.iter)=="inputs['rows']")
new_loop=next(n for n in ast.walk(after) if isinstance(n,ast.For) and ast.unparse(n.target)=='fixture' and ast.unparse(n.iter)=="inputs['rows']")
restored=copy.deepcopy(new_loop);chunk=next(n for n in ast.walk(restored) if isinstance(n,ast.For) and ast.unparse(n.target)=='chunk')
assert dump(chunk.iter)==dump(ast.parse('[4096,65536] if args.experimental_bulk_training else fixture["chunks"]',mode='eval').body)
chunk.iter=chunk.iter.orelse
assert dump(restored)==dump(old_loop)
ast_checks['generated_loop_except_explicit_iterator']=hashlib.sha256(dump(restored).encode()).hexdigest()
assert ast_checks['generated_loop_except_explicit_iterator']=='d0bf193c5ee4b5c5f6ff939d885c669a7c883584f93c8ed0d58ad4794a5dd3d0'
old_real=next(n for n in ast.walk(before) if isinstance(n,ast.For) and ast.unparse(n.target)=='document');new_real=next(n for n in ast.walk(after) if isinstance(n,ast.For) and ast.unparse(n.target)=='document');assert dump(old_real)==dump(new_real)
ast_checks['real_loop']=hashlib.sha256(dump(new_real).encode()).hexdigest()
oldbuild=parse(P/'base/tools/pgo/build.py');newbuild=parse(P/'pipeline/tools/pgo/build.py')
for n in oldbuild.body:
 if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name not in ['train','execute','main']:
  m=next(x for x in newbuild.body if isinstance(x,type(n)) and x.name==n.name);assert dump(m)==dump(n);ast_checks['build.'+n.name]=hashlib.sha256(dump(m).encode()).hexdigest()
oe=find(oldbuild,ast.FunctionDef,name='execute');ne=find(newbuild,ast.FunctionDef,name='execute')
ol=next(n for n in ast.walk(oe) if isinstance(n,ast.For) and ast.unparse(n.target)=='phase');nl=copy.deepcopy(next(n for n in ast.walk(ne) if isinstance(n,ast.For) and ast.unparse(n.target)=='phase'))
calls=[n for n in ast.walk(nl) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='train'];assert len(calls)==1
assert isinstance(calls[0].args[-1],ast.Name) and calls[0].args[-1].id=='bulk_training';calls[0].args.pop()
assert dump(ol)==dump(nl);ast_checks['build.generate_use_loop_except_bulk_argument']=hashlib.sha256(dump(nl).encode()).hexdigest()
cp=read(C/'preparation.json');source=read('/tmp/oriole-cdata-finder-pgo-study/source.json')['source_sha256'];assert source==cp['oriole_source_sha256'] and len(source)==70
for n,h in source.items():pin(W/n,h)
assert len(cp['pipeline_source_sha256'])==67 and all(source[n]==h for n,h in cp['pipeline_source_sha256'].items())
pin('/tmp/oriole-real-pgo-training-inputs/manifest.json','c4bef3dbcb2ccea5a65cb940ed51e1fb3b2ec46e5019516821eb0bab06cb83a8')
real=read('/tmp/oriole-real-pgo-training-inputs/manifest.json');assert len(real['documents'])==6
for n,h in cp['real_inputs']['files_sha256'].items():pin(Path('/tmp/oriole-real-pgo-training-inputs')/n,h)
for engine in ['oriole','expat']:
 r=read(C/(engine+'-g')/'report.json');assert r['status']=='passed' and r['preparation_sha256']==sha(C/'preparation.json')
 pin(r['libraries']['use']['path'],r['libraries']['use']['sha256'])
 assert r['libraries']['use']['sha256']==({'oriole':'dd2a1adf6c1be4468e0de3cb1dde265be71e75ce92847f6f220f6b2fdfc5b7a3','expat':'4b0deeb5ea03e6c3023038d1176c2b1282f2feac0f681f502b6134623914533c'}[engine])
gen=read(C/'normal-generated-inputs/manifest.json');sizes={r['name']:r['bytes'] for r in gen['rows']};sizes.update({'real/'+r['id']:r['bytes'] for r in real['documents']})
normal=read(C/'normal-oriole-training.json')['rows'];assert len(normal)==336
g=[r for r in normal if not r['fixture'].startswith('real/')];reals=[r for r in normal if r['fixture'].startswith('real/')];bgen=[r for r in g if r['chunk'] in [4096,65536]];bulk=[r for r in normal if r['chunk'] in [4096,65536]]
def totals(rows):return {'parses':len(rows),'bytes_fed':sum(sizes[r['fixture']] for r in rows),'xml_parse_calls':sum(math.ceil(sizes[r['fixture']]/r['chunk']) for r in rows)}
counts={'generated_g':totals(g),'generated_b':totals(bgen),'real_unchanged':totals(reals),'bulk_total':totals(bulk)}
proof=read(P/'schedule-proof.json');assert all(proof[k]==v for k,v in counts.items())
assert counts['bulk_total']=={'parses':240,'bytes_fed':25237736,'xml_parse_calls':3388}
controller_names=['prepare.py','build_arms.py','prepare_native.py','run_normal_preflight.py'];controllers={name:pin(P/name) for name in controller_names}
for name in controller_names:parse(P/name)
preparation=(P/'prepare.py').read_text();build=(P/'build_arms.py').read_text();native=(P/'prepare_native.py').read_text();normal_controller=(P/'run_normal_preflight.py').read_text()
for phrase in ["'native_preparation_controller_sha256': sha(ROOT / 'prepare_native.py')","'runner_manifest_sha256': sha(ROOT / 'runner-manifest.json')","'runner_checks_sha256': sha(ROOT / 'checks.json')"]:assert phrase in preparation
for phrase in ["assert result['experimental_bulk_training'] is True","assert result['experimental_real_inputs'] == PREPARATION['real_inputs']","assert result['script_sha256'] == sha(PIPELINE / 'train.py')","assert manifest['training_arm'] == 'B'","assert manifest['experimental_real_inputs'] == PREPARATION['real_inputs']"]:assert phrase in build
assert "assert read(ROOT / 'preparation.json')['native_preparation_controller_sha256'] == sha(__file__)" in native
assert "for arm in ('g', 'b')" in native and "Path('/tmp/oriole-real-pgo-training-study') if arm == 'g' else ROOT" in native
assert "expected = [row for row in old_report['rows'] if row['chunk'] in (4096, 65536)]" in normal_controller
assert "assert len(expected) == 240" in normal_controller and "training['rows'] == expected" in normal_controller
assert "--experimental-bulk-training" in normal_controller and "training['experimental_bulk_training'] is True" in normal_controller
assert "sha(PREFLIGHT['exact_training_reports'][engine]['path']) == PREFLIGHT['exact_training_reports'][engine]['sha256']" in build
# Stable process execution and cleanup wrappers are identical to the accepted study.
cb=parse(C/'build_arms.py');nb=parse(P/'build_arms.py')
for name in ['sha','read','files','save','run']:assert dump(find(cb,ast.FunctionDef,name=name))==dump(find(nb,ast.FunctionDef,name=name))
for name in ['cleared','overrides']:
 a=next(n for n in cb.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets));b=next(n for n in nb.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets));assert dump(a)==dump(b)
for path,h in pins.items():assert sha(path)==h
report={'status':'passed_source_review_no_blocker','scope':'Read-only source and saved tool-check review. No prepare/controller, parser/library, compiler, instrumented training, profiler or elapsed target executed by reviewer.','runner_manifest_sha256':sha(P/'runner-manifest.json'),'pipeline_patch_sha256':sha(P/'pipeline.patch'),'plan_sha256':sha(P/'PLAN.md'),'pipeline_hashes':manifest['pipeline_sha256'],'controller_sha256':controllers,'selected_runtime':cp['runtime_revision'],'source_files_verified':70,'pipeline_source_subset':67,'ast_checks':ast_checks,'schedules':counts,'G_and_GR_unchanged':True,'checks':{'receipt_sha256':sha(P/'checks.json'),'unit_tests':25,'Ruff':'0.16.6','ty':'0.0.80','final_commands_passed':4,'prior_failures_preserved':True},'findings':[],'resolved_preparation_findings':['Stale additive/G+R docstrings corrected.','Expat trainer output now explicitly requires B marker, exact real provenance and trainer hash. Oriole manifest explicitly requires arm B and real provenance.','Preparation binds native adapter, runner manifest and tool-check receipt; native adapter verifies its own pin before writing.'],'controller_assessment':['Normal B replay is a fresh240-case run per engine using exact previous normal19/7a libraries and comparison to the same-width subset of prior336 rows; original semantic comparison is retained by reference.','Build controller requires passed normal preflight bound to preparation and exact training report hashes. Fresh B output directories and profile dirs fail on reuse; original source70/subset67, source checks, environment reset, Ohm defaults-disabled O3/ThinLTO/cgu1 and GCC13 O3 feature/configuration paths remain unchanged.','Oriole pipeline phase loop is AST-identical except forwarding bulk flag: full actual compiler/profile/source audit remains required after builds. Expat fresh seven-profile generation/use logic and command bounds remain intact.','Native adaptation reads frozen G from the prior completed experiment, B from new study; checks source equality and artifact hashes. It retains original28conditions/7pairs/seed2026091003/iterations/timing functions and emits4 paired comparisons with112preflight+784timed workers. No GR library is used.'],'limitations':['Training policy changes both feed sizes and generated byte weighting: generated byte work becomes two thirds of G. Counts do not prove a performance cause or improvement.','New B normal/gen/use execution, exact compiler vectors and generated profile counts remain pending; tool tests do not execute parsers or builds.','No additional input selection, weighting sweep, repeated elapsed campaign, runtime change or production adoption is authorized by this review.','Current runtime is selected Finder78c; no rejected compact-status or deferred C raw prototype source enters B.'], 'input_sha256':pins,'reader_sha256':sha(__file__)}
out=P/'independent-source-review.json';out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'path':str(out),'sha256':sha(out),'controllers':controllers,'counts':counts},indent=2))
