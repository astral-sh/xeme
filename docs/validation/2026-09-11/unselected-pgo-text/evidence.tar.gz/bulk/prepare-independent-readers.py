"""Adapt saved-data readers only; never executes either output reader."""
import ast,difflib,re
from pathlib import Path
P=Path('/tmp/oriole-bulk-pgo-training-study');C=Path('/tmp/oriole-real-pgo-training-study')
def change(s,a,b,n=1):
 assert s.count(a)==n,(a,s.count(a),n)
 return s.replace(a,b)
s=(C/'audit-build-arms.py').read_text();s=change(s,'four-arm compiler','bulk-arm compiler');s=change(s,"P=Path('/tmp/oriole-real-pgo-training-study')","P=Path('/tmp/oriole-bulk-pgo-training-study')\nC=Path('/tmp/oriole-real-pgo-training-study')\nimport argparse\nparser=argparse.ArgumentParser(description=__doc__)\nparser.add_argument('--expected-normal-preflight',required=True)\nargs=parser.parse_args()\nassert re.fullmatch('[0-9a-f]{64}',args.expected_normal_preflight)")
s=change(s,"checked(P/'preparation.json','f6c314e0b60bf3a6e12a5e3343dd32b920d450fd29a26fb37b217c9ae3f5b773')","checked(P/'preparation.json','6fc457fe0247fa71784932bb3ff35ad4804180388ed9e6adc68c79b178a9e80b')")
s=change(s,"checked(P/'normal-preflight-independent-review.json','d2a8e3bc7b679c99511fc16afdef22ca497760224b43fd6a9bd658ed7f8e041f')","checked(P/'normal-preflight.json',args.expected_normal_preflight)\nchecked(P/'independent-source-review.json','ffa9135fc4a54c6b8e20ec4172279827c7114b181e09d5dd4b9a81b9f1aa31f1')\nchecked(C/'build-arms-independent-review.json','c5f2a0d3f0b6a188f197785776a870a1e9cc5de084b5934aec370412f13c8dc1')\ncontrols=read(C/'build-arms-independent-review.json')\ncontrol_preparation=read(C/'preparation.json')\nassert prep['control_preparation_sha256']==sha(C/'preparation.json')\nassert prep['control_build_audit_sha256']==sha(C/'build-arms-independent-review.json')\nfor key in ['oriole_source_sha256','pipeline_source_sha256','expat_source_sha256','gcc_tools_sha256','expat_config_sha256','normal_libraries','real_inputs','heldout_manifest_sha256','heldout_hashes']:assert prep[key]==control_preparation[key],key")
s=change(s,"('preflight_sha256','preflight_real.py'),",'');s=change(s,",('semantic_probe_sha256','preflight-support/xml_abi.py')",",('native_preparation_controller_sha256','prepare_native.py')")
s=change(s," assert len(normal[e]['rows'])==336",''' assert len(normal[e]['rows'])==240 and normal[e]['experimental_bulk_training'] is True
 old_path=C/('normal-'+e+'-training.json')
 checked(old_path,t['original']['sha256'])
 assert t['original']==original_preflight['exact_training_reports'][e]
 old=read(old_path)
 frozen_training=Path(controls['libraries'][e+'-g']['use']['path']).parent
 if e=='oriole':frozen_training=frozen_training.parent
 frozen_training=frozen_training/'use-training.json'
 checked(frozen_training,controls['raw_files_sha256'][str(frozen_training)])
 assert old['rows'][:288]==read(frozen_training)['rows']
 assert normal[e]['rows']==[row for row in old['rows'] if row['chunk'] in [4096,65536]]
 assert normal[e]['xml_parse_origin']==old['xml_parse_origin']==prep['normal_libraries'][e]
 assert normal[e]['library_sha256']==old['library_sha256']
 assert normal[e]['profile_file_environment'] is None
 assert normal[e]['script_sha256']==prep['pipeline_sha256']['train.py']
 assert normal[e]['real_input_script_sha256']==prep['pipeline_sha256']['real_inputs.py']
 assert normal[e]['experimental_real_inputs']==prep['real_inputs']
 assert sum(not row['fixture'].startswith('real/') for row in normal[e]['rows'])==192
 assert sum(row['fixture'].startswith('real/') for row in normal[e]['rows'])==48
 assert normal[e]['inputs_sha256']==sha(P/'normal-generated-inputs/manifest.json')
for c in pre['commands']:
 assert c['exit']==0 and c['cpu']==5 and c['timeout']==600
 assert c['argv'][:3]==[PY,'-I','-S'] and c['argv'][-1]=='--experimental-bulk-training'
 checked(P/(c['label']+'.log'),c['log_sha256'])
assert len(pre['commands'])==2 and pre['commands'][0]['end']<=pre['commands'][1]['start']
assert pre['original_normal_preflight_sha256']==sha(C/'normal-preflight.json')''')
s=change(s,"generated=tree(P/'normal-generated-inputs');assert len(generated)==13", "generated=tree(P/'normal-generated-inputs');assert len(generated)==13\nassert generated==tree(C/'normal-generated-inputs')\nchecked(C/'normal-preflight.json','9c0b131602296e692cda8625235256d4d6716a8307b26fcec0e812456ae29431')\noriginal_preflight=read(C/'normal-preflight.json')")
s=change(s,"historical_pair=read(H/'pair-report.json');hm=read(historical_pair['pgo_manifest']['path'])\nchecked(historical_pair['pgo_manifest']['path'],historical_pair['pgo_manifest']['sha256'])","control_oriole=read(C/'oriole-g/report.json');hm=read(control_oriole['manifest']['path'])\nchecked(control_oriole['manifest']['path'],control_oriole['manifest']['sha256'])")
s=change(s,"expected=normal[engine]['rows'][:288] if arm=='g' else normal[engine]['rows']","expected=normal[engine]['rows']")
s=change(s," if arm=='gr':"," if arm=='b':")
s=change(s,"  assert t['experimental_real_inputs']==prep['real_inputs']","  assert t['experimental_bulk_training'] is True\n  assert t['experimental_real_inputs']==prep['real_inputs']")
s=change(s,"for engine,arm in [('oriole','g'),('oriole','gr'),('expat','g'),('expat','gr')]:","for engine,arm in [('oriole','b'),('expat','b')]:")
s=change(s,"reports['oriole-g']","reports['oriole-b']",2)
s=change(s,"(288 if arm=='g' else 336)","240",2)
s=change(s,"('G' if arm=='g' else 'G+R')","'B'")
s=change(s,"(None if arm=='g' else prep['real_inputs'])","prep['real_inputs']")
s=change(s,"[144 if arm=='g' else 168,0]","[120,0]")
s=change(s,"expected_rows=normal['oriole']['rows'][:288] if arm=='g' else normal['oriole']['rows']","expected_rows=normal['oriole']['rows']")
s=change(s,"  assert counts['XML_Parse'][0]==calls","  assert counts['XML_Parse'][0]==calls==3388")
s=change(s,"  count=288 if arm=='g' else 336","  count=240")
s=change(s,"   checked(build/'CMakeFiles/expat.dir/link.txt',hashlib.sha256((shlex.join(links[0])+'\\n').encode()).hexdigest()) if False else None\n",'')
start=s.index("for phase in ['generate','use']:\n assert [canonical_gcc")
s=s[:start]+'''control_expat=read(C/'expat-g/report.json')
for phase in ['generate','use']:
 log=(C/'expat-g'/(phase+'-build.log')).read_text()
 checked(C/'expat-g'/(phase+'-build.log'),next(x['log_sha256'] for x in control_expat['commands'] if x['label']==phase+'-build'))
 args=[shlex.split(l) for l in log.splitlines() if l.startswith('/usr/bin/cc ')]
 objects=[a for a in args if '-c' in a];link=[a for a in args if '-shared' in a]
 assert len(objects)==7 and len(link)==1
 assert [canonical_gcc(a,P/'expat-b',phase) for a in gcc_vectors['expat-b'][phase]]==[canonical_gcc(a,C/'expat-g',phase) for a in objects]
 assert canonical_gcc(gcc_links['expat-b'][phase],P/'expat-b',phase)==canonical_gcc(link[0],C/'expat-g',phase)
assert [canonical_gcc(a,P/'expat-b','generate') for a in gcc_vectors['expat-b']['generate']]==[canonical_gcc(a,P/'expat-b','use') for a in gcc_vectors['expat-b']['use']]
assert profiles['oriole-b']['hashes']['merged.profdata']!=hm['profiles_sha256']['merged.profdata']
assert len(training)==4 and sum(t['rows'] for t in training)==960
for key in ['oriole-g','expat-g']:
 r=read(C/key/'report.json')
 assert r['libraries']==controls['libraries'][key]
 for lib in r['libraries'].values():checked(lib['path'],lib['sha256'])
 reports[key]=r
assert pre['commands'][-1]['end']<=sequence[0]['start']
report={'status':'passed_saved_build_audit','role':'Independent saved-data B normal/build audit. No parser/compiler/profile/disassembly execution.','selected_runtime':prep['runtime_revision'],'preparation_sha256':sha(P/'preparation.json'),'normal_preflight_sha256':sha(P/'normal-preflight.json'),'source_review_sha256':sha(P/'independent-source-review.json'),'frozen_G_build_review_sha256':sha(C/'build-arms-independent-review.json'),'source_files':70,'pipeline_source_files':67,'source_archive_sha256':sha(H/'source.tar.gz'),'source_unchanged_from_selected_Finder':True,'pipeline_files':prep['pipeline_sha256'],'commands':sequence,'normal_B_records':480,'normal_B_matches_filtered_original_GR':True,'normal_B_generated_rows_per_engine':192,'normal_B_real_rows_per_engine':48,'rust_actual_workspace_vectors':6,'rust_actual_dependency_vectors':6,'rust_vectors':rust_vectors,'rust_comparison':'All six workspace and six dependency actual B vectors match frozen G in each phase after only fresh run paths/private build paths/Cargo artifact suffixes. Metadata and every compiler option remain significant.','rust_toolchain':{k:manifests['oriole-b'][k] for k in ['rustc_version','cargo_version','profdata_version','python_version','cargo_config_sha256','tools_sha256']},'gcc_actual_object_vectors':14,'gcc_vectors':gcc_vectors,'gcc_links':gcc_links,'gcc_comparison':'Seven objects plus one shared link in each B phase match frozen G after arm paths; generate/use differ only matching profile mode/build prefix. No new flags or feature/config difference.','gcc_toolchain':{'compiler':reports['expat-b']['compiler_version'],'hashes':prep['gcc_tools_sha256'],'features':reports['expat-b']['features'],'expat_config_sha256':prep['expat_config_sha256']},'training_records':960,'training':training,'profiles':profiles,'libraries':{k:r['libraries'] for k,r in reports.items()},'blockers':[],'limitations':['B changes the training distribution and generated byte weighting; no causal or speed claim from counts.','240 records each normal/gen/use perengine:192generated plus48real. New source/scripts, old input bytes, old runtime and frozen freshG controls are explicit.','Oriole uses Ohm/LLVM22 O3 ThinLTO; Expat uses GCC13.3 O3 without LTO. Within-engine comparison comes first.','Saved manifests/logs establish provenance; this is not an independent compiler run or complete system trace.','No elapsed/performance/fullAPI claim.'], 'raw_files_sha256':pins,'reader_sha256':sha(__file__)}
dest=P/'build-arms-independent-review.json';dest.write_text(json.dumps(report,indent=2)+'\\n')
print(json.dumps({'status':report['status'],'path':str(dest),'sha256':sha(dest),'new_rust_workspace_vectors':6,'new_gcc_objects':14,'new_training_records':960,'normal_B_records':480,'blockers':[]},indent=2))
'''
ast.parse(s);(P/'audit-build-arms.py').write_text(s)
# Same four-engine worker/sample protocol; only source/arm bindings and result expectations differ.
n=(C/'audit-native.py').read_text()
n=change(n,"P=Path('/tmp/oriole-real-pgo-training-study');S=P/'native';D=S/'native-screen'","P=Path('/tmp/oriole-bulk-pgo-training-study');C=Path('/tmp/oriole-real-pgo-training-study');S=P/'native';D=S/'native-screen'\nimport argparse,re\nparser=argparse.ArgumentParser(description=__doc__)\nparser.add_argument('--expected-build-review',required=True)\nargs=parser.parse_args()\nassert re.fullmatch('[0-9a-f]{64}',args.expected_build_review)")
n=change(n,"pin(P/'build-arms-independent-review.json','c5f2a0d3f0b6a188f197785776a870a1e9cc5de084b5934aec370412f13c8dc1')","pin(P/'build-arms-independent-review.json',args.expected_build_review)")
n=n.replace("P/'normal-preflight-independent-review.json'","C/'normal-preflight-independent-review.json'")
n=change(n," report=read(P/engine/'report.json');assert report['status']=='passed'"," origin=C if engine.endswith('-g') else P\n report=read(origin/engine/'report.json');assert report['status']=='passed'")
n=re.sub(r'\boriole-gr\b','oriole-b',n);n=re.sub(r'\bexpat-gr\b','expat-b',n)
start=n.index("for group,key,want in [");end=n.index("adverse={key:",start);n=n[:start]+n[end:]
n=change(n,"'selection':'Additive G+R training arm rejected; selected runtime and generated-only training remain unchanged.'","'selection':'B remains an experimental training policy; root owns selection after this saved audit.'")
n=change(n,'All four engines are fresh use-profile artifacts.','The G controls are the frozen fresh artifacts from the prior campaign; B is newly built.')
n=change(n,'No actual Python campaign or full API gate was run for this rejected training recipe.','This receipt covers only the fixed native campaign; no actual Python/full API result is inferred.')
ast.parse(n);(P/'audit-native.py').write_text(n)
for name in ['audit-build-arms.py','audit-native.py']:
 old=(C/name).read_text();new=(P/name).read_text();(P/(name+'.adaptation.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(C/name),tofile=str(P/name))))
print('Prepared both source-only readers; neither output reader executed.')
