"""Bind frozen G and fresh B libraries to the existing fixed native benchmark conditions."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parent
BASE = Path('/tmp/oriole-cdata-finder-pgo-native-study')
OUT = ROOT / 'native'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert not OUT.exists()
assert read(ROOT / 'preparation.json')['native_preparation_controller_sha256'] == sha(__file__)
libraries = {}
artifacts = {}
for engine in ('oriole', 'expat'):
    for arm in ('g', 'b'):
        name = engine + '-' + arm
        origin = Path('/tmp/oriole-real-pgo-training-study') if arm == 'g' else ROOT
        report_path = origin / name / 'report.json'
        report = read(report_path)
        assert report['status'] == 'passed' and all(report['unchanged'].values())
        assert report['preparation_sha256'] == sha(origin / 'preparation.json')
        assert read(origin / 'preparation.json')['oriole_source_sha256'] == read(ROOT / 'preparation.json')['oriole_source_sha256']
        assert read(origin / 'preparation.json')['expat_source_sha256'] == read(ROOT / 'preparation.json')['expat_source_sha256']
        library = report['libraries']['use']
        assert sha(library['path']) == library['sha256']
        libraries[name] = library['path']
        artifacts[str(report_path)] = sha(report_path)
        artifacts[library['path']] = library['sha256']
ratios = [('oriole-b', 'oriole-g'), ('expat-b', 'expat-g'),
          ('oriole-g', 'expat-g'), ('oriole-b', 'expat-b')]
source = (BASE / 'native_screen.py').read_text()
original = source
lines = source.splitlines(keepends=True)
changes = []
for node in ast.parse(source).body:
    if not isinstance(node, ast.Assign) or len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
        continue
    name = node.targets[0].id
    replacement = None
    if name == 'root':
        replacement = f'root = Path({str(OUT)!r})\n'
    elif name == 'libraries':
        replacement = 'libraries = {' + ',\n'.join(f'{k!r}: Path({v!r})' for k, v in libraries.items()) + '}\n'
    elif name == 'ratios':
        replacement = f'ratios = {ratios!r}\n'
    if replacement is not None:
        changes.append((node.lineno - 1, node.end_lineno, replacement))
assert len(changes) == 3
for start, end, replacement in reversed(changes):
    lines[start:end] = [replacement]
source = ''.join(lines)
source = source.replace('Fixed three-engine matched pgo reusable CDATA Finder native screen.',
                        'Fixed four-engine generated-only versus bulk-chunk PGO native screen.')
old_scope = ast.literal_eval(next(node.value for node in ast.parse(original).body
                                 if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'protocol' for t in node.targets)).values[0])
new_scope = ('Four PGO artifacts: unchanged PR128 Oriole and pinned Expat2.8.4, each trained on '
             'G (retained fresh original generated schedule) or B (fresh bulk4/64KiB generated+same6real inputs). '
             'Original28 held-out/native conditions, iterations, 7 pairs and seed retained. '
             'Four engines per randomized cohort; same observed lifecycle scope and native callbacks. '
             'Oriole Ohm defaults disabled O3 ThinLTO/cgu1; Expat GCC13.3 O3 shared no LTO. '
             'Training comparisons within each engine plus matched G/G and B/B across engines. '
             'No source, allocator, benchmark input or timing boundary changes.')
source = source.replace(repr(old_scope), repr(new_scope))
assert old_scope not in source
source = source.replace("'preflights': 84, 'timed_workers': 588", "'preflights': 112, 'timed_workers': 784")
source = source.replace("len(report['rows']) == 84", "len(report['rows']) == 112")
source = source.replace("'timed_workers': 3 * len(report['rows'])", "'timed_workers': 4 * len(report['rows'])")
ast.parse(source)
# The callbacks, timers, per-process samples, condition construction, iteration
# table, paired medians and PRNG seed are preserved in the original controller.
base_tree, candidate_tree = ast.parse(original), ast.parse(source)
for name in ('run', 'digest', 'save'):
    a = next(n for n in base_tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    b = next(n for n in candidate_tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    assert ast.dump(a, include_attributes=False) == ast.dump(b, include_attributes=False)
OUT.mkdir()
(OUT / 'native_screen.py').write_text(source)
(OUT / 'run.py').write_bytes((BASE / 'run.py').read_bytes())
patch = ''.join(difflib.unified_diff(original.splitlines(True), source.splitlines(True), fromfile=str(BASE / 'native_screen.py'), tofile=str(OUT / 'native_screen.py')))
(OUT / 'adaptation.patch').write_text(patch)
report = {'status': 'passed', 'source_controller_sha256': sha(BASE / 'native_screen.py'),
          'controller_sha256': sha(OUT / 'native_screen.py'), 'wrapper_sha256': sha(OUT / 'run.py'),
          'patch_sha256': sha(OUT / 'adaptation.patch'), 'preparation_sha256': sha(ROOT / 'preparation.json'),
          'build_artifacts_sha256': artifacts, 'libraries': libraries, 'ratios': ratios,
          'conditions': 28, 'pairs': 7, 'preflight_workers': 112, 'timed_workers': 784,
          'measured_samples': 140560, 'warmup_samples': 784, 'preflight_samples': 224,
          'scope': 'Four engines require corresponding worker-count changes; all condition/iteration/sample/timing semantics are unchanged. Fresh library/build artifacts separately bound. No execution yet.'}
(OUT / 'adaptation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'controller_sha256': report['controller_sha256']}))
