"""Prepare four-engine G/B Python adapters using saved, verified artifacts only."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

P = Path('/tmp/oriole-bulk-pgo-training-study')
B = Path('/tmp/oriole-cdata-finder-pgo-python-study')
OUT = P / 'python'
SOURCE = Path('/home/dev-user/code/oss/oriole-cdata-finder')
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3'
FILES = ['build_consumers.py', 'consumer_screen.py', 'python_worker.py', 'run.py']
ENGINES = ['oriole-g', 'oriole-b', 'expat-g', 'expat-b']
RATIOS = [('oriole-b', 'oriole-g'), ('expat-b', 'expat-g'), ('oriole-g', 'expat-g'), ('oriole-b', 'expat-b')]
pins = {}

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def pin(path, expected=None):
    path = Path(path)
    value = sha(path)
    assert expected is None or expected == value, str(path)
    assert pins.setdefault(str(path), value) == value
    return {'path': str(path), 'sha256': value}

def read(path):
    pin(path)
    return json.loads(Path(path).read_text())

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')

def replace(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)

pin(P / 'build-arms-independent-review.json', 'a0e19e095a391337d91f05e20b47b4033315f7bda823bfdb9bc5fc9daed5f5e7')
pin(P / 'native-independent-review.json', '2074f94143bb4dba9d477fa85393c9d761269d49a252c3bd924127b8f8027750')
build = read(P / 'build-arms-independent-review.json')
prep = read(P / 'preparation.json')
assert build['status'] == 'passed_saved_build_audit'
assert build['preparation_sha256'] == sha(P / 'preparation.json')
original = read(B / 'adaptation.json')
prior = read(B / 'preparation.json')
assert original['counts'] == {'conditions': 24, 'engines': 3, 'extensions': 6, 'preflights': 72, 'cohorts': 168, 'pairs': 7, 'timed_workers': 504, 'measured_parses': 25788, 'warmups': 504}
assert original['seed'] == 202609104412
for name, digest in prep['oriole_source_sha256'].items():
    pin(SOURCE / name, digest)
assert len(prep['oriole_source_sha256']) == 70
libraries = {engine: build['libraries'][engine]['use'] for engine in ENGINES}
for entry in libraries.values():
    pin(entry['path'], entry['sha256'])
for entry in original['consumer_source']['files'].values():
    pin(entry['path'], entry['sha256'])
for path, digest in original['consumer_source']['interpreter_and_public_headers'].items():
    pin(path, digest)
pin(original['header']['path'], original['header']['sha256'])
for path, digest in prior['input_pins'].items():
    pin(path, digest)
cpython = Path(original['consumer_source']['requested_checkout'])
git_reads = []
for args in [['rev-parse', 'HEAD'], ['status', '--porcelain']]:
    command = ['git', '-C', str(cpython), *args]
    result = subprocess.run(command, capture_output=True, text=True, check=True)
    git_reads.append({'argv': command, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
assert git_reads[0]['stdout'].strip() == original['consumer_source']['revision']
assert git_reads[1]['stdout'] == ''
for tool in ['/usr/bin/cc', '/usr/bin/readelf']:
    pin(Path(tool).resolve())
assert not OUT.exists()
OUT.mkdir()
changes = {}
for name in FILES:
    pin(B / name, original['files'][name])
    before = (B / name).read_text()
    after = before
    replacements = []
    if name == 'build_consumers.py':
        replacements = [
            ('    parser.add_argument("--library", type=Path, required=True)\n    parser.add_argument("--reference", type=Path, required=True)\n    parser.add_argument("--expat", type=Path, required=True)',
             '    parser.add_argument("--oriole-g", type=Path, required=True)\n    parser.add_argument("--oriole-b", type=Path, required=True)\n    parser.add_argument("--expat-g", type=Path, required=True)\n    parser.add_argument("--expat-b", type=Path, required=True)'),
            ('        "control": args.reference.resolve(strict=True),\n        "expat": args.expat.resolve(strict=True),\n        "candidate": args.library.resolve(strict=True),',
             '        "oriole-g": args.oriole_g.resolve(strict=True),\n        "oriole-b": args.oriole_b.resolve(strict=True),\n        "expat-g": args.expat_g.resolve(strict=True),\n        "expat-b": args.expat_b.resolve(strict=True),'),
            ('All three engines compile identical unmodified CPython 3.12.13 pyexpat.c and _elementtree.c with identical -O2 flags and the same narrow Expat-compatible header. Only the linked parser library and its rpath differ. Both Oriole parser libraries use C-only ThinLTO with independent fresh generated-only PGO; the Expat control uses its verified generated-only PGO without LTO. No source adaptation, alternate allocator, or profile training of the interpreter/extensions is applied.',
             'All four engines compile identical unmodified CPython 3.12.13 pyexpat.c and _elementtree.c with identical -O2 flags and the same narrow Expat-compatible header. Only the linked parser library and its rpath differ. Each engine compares its frozen generated-only G profile against the fresh bulk B profile on the same source and compiler settings. Both Oriole libraries use Ohm/LLVM22 O3 ThinLTO; both Expat libraries use GCC13.3 O3 without LTO. No source adaptation, alternate allocator, or profile training of the interpreter/extensions is applied.'),
        ]
    elif name == 'consumer_screen.py':
        replacements = [
            ('Matched cached CDATA Finder pgo CPython screen', 'Matched frozen G versus bulk B PGO CPython screen'),
            ('ENGINES = ("control", "candidate", "expat")', 'ENGINES = ("oriole-g", "oriole-b", "expat-g", "expat-b")'),
            ('RATIOS = (("candidate", "control"), ("control", "expat"), ("candidate", "expat"))', 'RATIOS = (("oriole-b", "oriole-g"), ("expat-b", "expat-g"), ("oriole-g", "expat-g"), ("oriole-b", "expat-b"))'),
            ('Expected selected streaming control, cached CDATA Finder candidate and Expat engines', 'Expected frozen G and bulk B Oriole and Expat engines'),
            ('Matched generated-only ThinPGO parser cohort: explicit-host selected streaming control and cached CDATA Finder candidate, plus pinned Expat2.8.4 PGO. Both Oriole libraries use C-only ThinLTO. This cohort is assessed separately from the other profile mode. All24 original CPython conditions, seven fixed seeded cohorts,504 timed workers after72 preflights.',
             'Matched training-policy cohort: frozen G and fresh bulk B profiles for each of selected Finder Oriole and Expat2.8.4. Both Oriole libraries use Ohm/LLVM22 O3 ThinLTO; both Expat libraries use GCC13.3 O3 without LTO. Within-engine policy comparisons are primary. All24 original CPython conditions, seven fixed seeded cohorts,672 timed workers after96 preflights.'),
            ('The selected streaming runtime has two known strict CPython callback-grouping failures. At protocol preparation no fresh full strict CPython suite has run on this candidate;',
             'The selected runtime retains two known strict CPython callback-grouping failures. This training experiment has no new full strict CPython suite result;'),
        ]
    elif name == 'run.py':
        replacements = [
            ("                        '--library', libraries['candidate']['path'], '--reference', libraries['control']['path'],\n                        '--expat', libraries['expat']['path'], '--source',", "                        '--oriole-g', libraries['oriole-g']['path'], '--oriole-b', libraries['oriole-b']['path'],\n                        '--expat-g', libraries['expat-g']['path'], '--expat-b', libraries['expat-b']['path'], '--source',"),
            ("libraries = adaptation['libraries']", "libraries = adaptation['libraries']\nfor name, expected in adaptation['files'].items():\n    assert hashlib.sha256((out / name).read_bytes()).hexdigest() == expected\nfor path, expected in adaptation['input_pins'].items():\n    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected"),
        ]
    for old, new in replacements:
        after = replace(after, old, new)
    restored = after
    for old, new in reversed(replacements):
        restored = replace(restored, new, old)
    assert restored == before
    ast.parse(after)
    (OUT / name).write_text(after)
    (OUT / (name + '.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile=str(B / name), tofile=str(OUT / name))))
    changes[name] = {'parent_sha256': sha(B / name), 'sha256': sha(OUT / name), 'replacements': replacements, 'reverse_text_and_AST_exact': True}
assert (OUT / 'python_worker.py').read_bytes() == (B / 'python_worker.py').read_bytes()
counts = {'conditions': 24, 'engines': 4, 'extensions': 8, 'preflights': 96, 'cohorts': 168, 'pairs': 7, 'timed_workers': 672, 'measured_parses': 34384, 'warmups': 672, 'all_workers': 768, 'all_samples': 35152}
assert sum(row['iterations'] for row in prior['conditions']) * 7 * 4 == counts['measured_parses']
for path, digest in pins.items():
    assert sha(path) == digest
adaptation = {'status': 'prepared_only', 'execution_status': 'unexecuted', 'preparer': pin(__file__), 'libraries': libraries, 'files': {name: sha(OUT / name) for name in FILES}, 'input_pins': pins.copy(), 'counts': counts, 'seed': original['seed'], 'bounds': original['bounds'], 'ratios': RATIOS, 'conditions': prior['conditions'], 'header': original['header'], 'consumer_source': original['consumer_source'], 'build_review': pin(P / 'build-arms-independent-review.json'), 'native_review': pin(P / 'native-independent-review.json'), 'parent_adaptation': pin(B / 'adaptation.json'), 'proof': 'Exact Finder PGO worker and protocol; changes are four engine keys/ratios/library arguments, captions, and before-execution source hash guards. Conditions, iterations, seed, random pairing mechanics, measurement boundaries, compiler flags and timeouts are unchanged. Same selected Finder source for G and B. Six project benchmark fixtures remain held out of both profile schedules.', 'execution_prerequisites': 'Source-only preparation. Root must separately release extension compilation/preflights, inspect exact module and XML_Parse origins, then reserve CPU0 before the single elapsed campaign.'}
save(OUT / 'adaptation.json', adaptation)
preparation = {'status': 'prepared_only', 'changes': changes, 'counts': counts, 'bounds': original['bounds'], 'conditions': prior['conditions'], 'seed': original['seed'], 'git_reads': git_reads, 'adaptation': pin(OUT / 'adaptation.json'), 'future_commands_held': {phase: ['taskset', '-c', str(cpu), PYTHON, '-I', '-S', str(OUT / 'run.py'), phase] for phase, cpu in [('prepare', 3), ('time', 0)]}, 'scope': 'Only source reads, hashes, inert AST parsing, read-only Git checks and adapter writes occurred. No compiler, XML parser, extension import, preflight or elapsed run.'}
save(OUT / 'preparation.json', preparation)
save(OUT / 'preparation-freeze.json', {'status': 'prepared_only', 'files': {str(path): sha(path) for path in sorted(OUT.iterdir()) if path.is_file()}})
print(json.dumps({'status': 'prepared_only', 'output': str(OUT), 'adaptation_sha256': sha(OUT / 'adaptation.json'), 'preparation_sha256': sha(OUT / 'preparation.json'), 'freeze_sha256': sha(OUT / 'preparation-freeze.json'), 'counts': counts}, indent=2))
