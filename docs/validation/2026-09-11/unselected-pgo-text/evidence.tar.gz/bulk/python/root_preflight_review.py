"""Read actual consumer compiler vectors and fixed preflight identities."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
BASE = Path('/tmp/oriole-cdata-finder-pgo-python-study')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
build = read(ROOT / 'consumers/build.json')
prior = read(BASE / 'consumers/build.json')
adaptation = read(ROOT / 'adaptation.json')
preflight = read(ROOT / 'screen/preflight.json')
assert build['status'] == prior['status'] == 'passed'
assert build['source_sha256_before'] == build['source_sha256_after']
assert build['compiler'] == prior['compiler']
assert build['adaptations'] is None
assert set(build['consumers']) == set(adaptation['libraries'])


def vector(command, entry):
    return [value.replace(entry['library'], '<library>').replace(entry['directory'], '<output>')
            for value in command]


old = prior['consumers']['control']
commands = 0
for engine, entry in build['consumers'].items():
    assert sha(entry['library']) == adaptation['libraries'][engine]['sha256']
    assert all(sha(path) == expected for path, expected in entry['files'].items())
    assert len(entry['commands']) == 2
    for index, row in enumerate(entry['commands']):
        assert row['returncode'] == 0
        assert vector(row['command'], entry) == vector(old['commands'][index]['command'], old)
        module = ('pyexpat', '_elementtree')[index]
        assert sha(Path(entry['directory']) / (module + '-build.log')) == row['log_sha256']
        commands += 1

assert preflight['status'] == 'preflight_passed'
assert preflight['hashes_before'] == preflight['hashes_after']
assert not preflight['hash_errors'] and not preflight['rows']
assert len(preflight['conditions']) == 24 and len(preflight['preflights']) == 96
observations = {}
for row in preflight['preflights']:
    assert row['pair'] == -1 and len(row['samples']) == 1
    assert row['samples'][0]['warmup'] is True
    entry = build['consumers'][row['engine']]
    for module in ('pyexpat', '_elementtree', 'parser_library'):
        identity = row['identity'][module]
        assert sha(identity['path']) == identity['sha256']
        assert entry['files'][identity['path']] == identity['sha256']
    observation = (row['samples'][0]['output_sha256'], row['samples'][0]['output_rows'])
    observations.setdefault(row['key'], set()).add(observation)
assert len(observations) == 24 and all(len(values) == 1 for values in observations.values())
assert all(sha(path) == expected for path, expected in adaptation['input_pins'].items())
report = {'status': 'passed', 'reader_sha256': sha(__file__),
          'build_sha256': sha(ROOT / 'consumers/build.json'),
          'preflight_sha256': sha(ROOT / 'screen/preflight.json'),
          'actual_compiler_vectors': commands, 'preflights': 96, 'canonical_conditions': 24,
          'scope': 'Actual eight consumer compiler vectors match the prior Finder control except library/output paths. All preflight module/library identities and canonical observations agree. Full raw-process reconstruction remains a separate independent saved-data audit; no target rerun.'}
(ROOT / 'root-preflight-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
