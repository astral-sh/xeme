"""Replay the B schedule on normal libraries and compare existing exact cases."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
CONTROL = Path('/tmp/oriole-real-pgo-training-study')
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert os.sched_getaffinity(0) == {5}
preparation = read(ROOT / 'preparation.json')
assert preparation['normal_preflight_controller_sha256'] == sha(__file__)
assert not (ROOT / 'normal-preflight.json').exists()
manifest = Path('/tmp/oriole-real-pgo-training-inputs/manifest.json')
original = read(CONTROL / 'normal-preflight.json')
assert original['status'] == 'passed'
assert original['preparation_sha256'] == preparation['control_preparation_sha256']
report = {'status': 'incomplete', 'preparation_sha256': sha(ROOT / 'preparation.json'),
          'commands': [], 'exact_training_reports': {},
          'original_normal_preflight_sha256': sha(CONTROL / 'normal-preflight.json'),
          'scope': 'New normal-library B240 replays; compare each exact case against the same-width subset of existing verified normalG+R records. Existing unchanged six-input semantic comparisons are retained by reference, not rerun or relabeled as new.'}


def save():
    (ROOT / 'normal-preflight.json').write_text(json.dumps(report, indent=2) + '\n')


def run(label, argv):
    row = {'label': label, 'argv': argv, 'cpu': 5, 'timeout': 600, 'start': time.time()}
    report['commands'].append(row)
    save()
    process = None
    log = ROOT / (label + '.log')
    with log.open('wb') as stream:
        try:
            process = subprocess.Popen(argv, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            row['exit'] = process.wait(timeout=600)
            if row['exit']:
                raise RuntimeError(f'{label}: exit {row["exit"]}')
        except BaseException as error:
            row['failure'] = repr(error)
            if process is not None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                row['exit'] = process.wait()
            raise
        finally:
            stream.flush()
            row.update(end=time.time(), log_sha256=sha(log))
            save()
    print(label, row['exit'], flush=True)


try:
    pipeline = ROOT / 'pipeline/tools/pgo'
    def pipeline_files():
        return {str(p.relative_to(pipeline)): sha(p) for p in sorted(pipeline.rglob('*'))
                if p.is_file() and '__pycache__' not in p.parts}
    assert preparation['pipeline_sha256'] == pipeline_files()
    assert all(sha(p) == h for p, h in preparation['inputs_sha256'].items())
    sys.path.insert(0, str(pipeline.parent))
    from pgo.corpus import generate
    inputs = ROOT / 'normal-generated-inputs'
    generate(inputs)
    for engine, library in preparation['normal_libraries'].items():
        assert sha(library['path']) == library['sha256']
        previous = original['exact_training_reports'][engine]
        assert sha(previous['path']) == previous['sha256']
        old_report = read(previous['path'])
        assert old_report['library_sha256'] == library['sha256']
        expected = [row for row in old_report['rows'] if row['chunk'] in (4096, 65536)]
        assert len(expected) == 240
        target = ROOT / ('normal-' + engine + '-training.json')
        run('normal-training-' + engine, [PYTHON, '-I', '-S', str(pipeline / 'train.py'),
                                         '--library', library['path'], '--inputs', str(inputs),
                                         '--report', str(target), '--experimental-real-manifest', str(manifest),
                                         '--experimental-real-manifest-sha256', preparation['inputs_sha256'][str(manifest)],
                                         '--experimental-bulk-training'])
        training = read(target)
        assert training['status'] == 'passed' and training['rows'] == expected
        assert training['library_sha256'] == library['sha256']
        assert training['xml_parse_origin'] == {'path': str(Path(library['path']).resolve()), 'sha256': library['sha256']}
        assert training['experimental_real_inputs'] == preparation['real_inputs']
        assert training['experimental_bulk_training'] is True
        assert training['inputs_sha256'] == sha(inputs / 'manifest.json')
        assert training['script_sha256'] == sha(pipeline / 'train.py')
        report['exact_training_reports'][engine] = {'path': str(target), 'sha256': sha(target),
                                                    'original': previous, 'exact_filtered_rows': len(expected)}
    assert all(sha(p) == h for p, h in preparation['inputs_sha256'].items())
    assert preparation['pipeline_sha256'] == pipeline_files()
    report['status'] = 'passed'
finally:
    save()
print(json.dumps({'status': report['status'], 'normal_rows': 480}))
