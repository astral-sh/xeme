"""Save the external B preparation; no parser or compiler execution."""
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PIPELINE = ROOT / "pipeline/tools/pgo"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def write(name, value):
    with (ROOT / name).open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")

base = read(ROOT / "base.json")
old = ROOT / "base/tools/pgo"
origin = Path(base["origin"])
names = sorted(base["pipeline_sha256"])
assert len(names) == 8
for name in names:
    assert sha(old / name) == sha(origin / name) == base["pipeline_sha256"][name]
current = {name: sha(PIPELINE / name) for name in names}
checks = read(ROOT / "checks.json")
assert checks["status"] == "passed"
assert checks["source_before"] == checks["source_after"] == current
changed = [name for name in names if current[name] != base["pipeline_sha256"][name]]
assert changed == ["README.md", "build.py", "test_real_inputs.py", "train.py"]
with (ROOT / "pipeline.patch").open("x") as patch:
    for name in changed:
        patch.writelines(difflib.unified_diff(
            (old / name).read_text().splitlines(keepends=True),
            (PIPELINE / name).read_text().splitlines(keepends=True),
            fromfile=f"base/tools/pgo/{name}", tofile=f"pipeline/tools/pgo/{name}",
        ))

spec = importlib.util.spec_from_file_location("bulk_corpus_for_arithmetic", PIPELINE / "corpus.py")
assert spec is not None and spec.loader is not None
corpus = importlib.util.module_from_spec(spec)
spec.loader.exec_module(corpus)
generated = corpus.documents()
manifest_path = Path("/tmp/oriole-real-pgo-training-inputs/manifest.json")
assert sha(manifest_path) == base["real_manifest_sha256"]
manifest = read(manifest_path)
real = []
for row in manifest["documents"]:
    path = manifest_path.parent / row["file"]
    assert sha(path) == row["sha256"] and path.stat().st_size == row["bytes"]
    real.append(row["bytes"])

def totals(sizes, widths, repetitions):
    return {
        "parses": sum(len(chunks) * repetitions for _, chunks in zip(sizes, widths)),
        "bytes_fed": sum(size * len(chunks) * repetitions for size, chunks in zip(sizes, widths)),
        "xml_parse_calls": sum(((size + width - 1) // width) * repetitions for size, chunks in zip(sizes, widths) for width in chunks),
    }

g_sizes = [len(value[0]) for value in generated.values()]
g = totals(g_sizes, [[1 if name == "latin1" else 17, 4096, 65536] for name in generated], 8)
b = totals(g_sizes, [[4096, 65536]] * 12, 8)
r = totals(real, [[4096, 65536]] * 6, 4)
all_b = {key: b[key] + r[key] for key in b}
assert g == {"parses": 288, "bytes_fed": 31817664, "xml_parse_calls": 870312}
assert b == {"parses": 192, "bytes_fed": 21211776, "xml_parse_calls": 2848}
assert r == {"parses": 48, "bytes_fed": 4025960, "xml_parse_calls": 540}
assert all_b == {"parses": 240, "bytes_fed": 25237736, "xml_parse_calls": 3388}
write("schedule-proof.json", {
    "role": "preparer-owned source arithmetic; no parser execution",
    "generated_g": g, "generated_b": b, "real_unchanged": r, "bulk_total": all_b,
    "generated_unique_bytes": sum(g_sizes), "real_unique_bytes": sum(real),
    "real_manifest_sha256": sha(manifest_path), "corpus_script_sha256": sha(PIPELINE / "corpus.py"),
    "limits": "Counts follow the existing data-bearing final call rule. Arithmetic is not a successful-parser or performance claim.",
})
write("runner-manifest.json", {
    "status": "prepared_tool_checks_passed_targets_not_run",
    "role": "pipeline author/collector; independent source review pending",
    "selected_runtime": base["selected_runtime"],
    "base": {"record": "base.json", "sha256": sha(ROOT / "base.json"), "original_runner": base["runner_manifest"]},
    "pipeline_sha256": current,
    "changed_files": changed,
    "production_change_scope": "External train/build only: explicit flag requiring pinned real inputs, B generated feed iterator, report marker, training-arm manifest and count. corpus.py, real_inputs.py, __init__.py and test_build.py are byte-identical to base.",
    "patch": {"path": "pipeline.patch", "sha256": sha(ROOT / "pipeline.patch")},
    "plan": {"path": "PLAN.md", "sha256": sha(ROOT / "PLAN.md")},
    "checks": {"path": "checks.json", "sha256": sha(ROOT / "checks.json"), "tests": 25, "ruff": "0.16.6", "ty": "0.0.80", "first_failures_retained": True},
    "arithmetic": {"path": "schedule-proof.json", "sha256": sha(ROOT / "schedule-proof.json")},
    "real_manifest_sha256": base["real_manifest_sha256"],
    "held": "No B library preflight, Cargo/native compile, training, profiler or elapsed targets executed by this preparer. Root-owned controller drafts are separate and not reviewed by this receipt.",
})
for name in names:
    (PIPELINE / name).chmod(0o444)
print(json.dumps({"runner_manifest_sha256": sha(ROOT / "runner-manifest.json"), "patch_sha256": sha(ROOT / "pipeline.patch"), "plan_sha256": sha(ROOT / "PLAN.md"), "changed": changed}))
