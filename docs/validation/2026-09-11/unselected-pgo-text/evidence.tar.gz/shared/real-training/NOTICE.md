# Upstream notices for the six selected inputs

These files are unchanged upstream documents. Their canonical file URLs, revisions, Git blob identities and SHA256 values are in manifest.json.

- **qBittorrent UI source:** repository COPYING specifies GPL version 2 or later with its OpenSSL exception. Exact COPYING, GPLv2/GPLv3 texts and AUTHORS are retained under licenses/qbittorrent. The repository's separate binary-distribution wording does not reclassify these source XML files.
- **Standard Ebooks:** exact LICENSE.md says the source text/artwork is believed public domain in the United States and retains its jurisdiction caveat; contributors dedicate their work via CC0 1.0. The selected files contain Jane Austen's text; no cover artwork is selected. The colophon and content.opf document contributors and source transcription/scans. Copies are retained under licenses/standardebooks and provenance.
- **Inkscape examples:** blend_modes.svg explicitly credits Copyright 2007 Niko Kiirala and CC BY-SA 3.0. turbulence_filters.svg credits Niko Kiirala, explicitly states CC BY-SA 3.0 and separately allows free use of filter definitions. Complete RDF rights/author/license metadata remains inside the unmodified SVGs. The upstream example README and repository COPYING are retained as context; the embedded grants govern the selected artwork. License URL: https://creativecommons.org/licenses/by-sa/3.0/ .

CC BY-SA 3.0 and CC0 1.0 text copies are pinned from spdx/license-list-data; provenance/spdx-license-acquired.json records exact revision, original path, URL and hashes. They are text mirrors, not new grants. Direct Creative Commons acquisition failures are preserved separately. No file has been relicensed or represented as Oriole-authored.
