# Proposed additive real XML training inputs

Six unmodified upstream UTF-8 files, selected before any parser, compiler, profile or elapsed run. The selected runtime is PR128 `78c748d9de5c497858458cbf7a1229148781b2bf`. This directory changes no production source or production generated-corpus guard.

The complete input list is [manifest.json](manifest.json), SHA256 `c4bef3dbcb2ccea5a65cb940ed51e1fb3b2ec46e5019516821eb0bab06cb83a8`. Only its six rows are training inputs. Total **503,245 bytes**; largest **192,023 bytes**. The unchanged proposed schedule adds **48 parses / 4,025,960 input bytes**: two chunk widths (4096/65536), two namespace modes, two handler modes, one iteration. Existing generated G training remains unchanged. Acquisition does not establish parser success or authorize training.

| Category | Canonical upstream source | Bytes | Structure |
| --- | --- | ---: | --- |
| config | [qBittorrent optionsdialog.ui](https://github.com/qbittorrent/qBittorrent/blob/3c4409d1a204a8b7d878727a538a8f4c5ae292f1/src/gui/optionsdialog.ui) | 177,543 | Complete Qt options dialog: 366 widgets, 728 properties, nested layouts/items. |
| config | [qBittorrent propertieswidget.ui](https://github.com/qbittorrent/qBittorrent/blob/3c4409d1a204a8b7d878727a538a8f4c5ae292f1/src/gui/properties/propertieswidget.ui) | 48,485 | Complete torrent properties tree: 80 widgets and 216 properties. |
| mixed_content | [Pride and Prejudice chapter 18](https://github.com/standardebooks/jane-austen_pride-and-prejudice/blob/ed94a32be3e875c0814568050c7544e03aad3ef5/src/epub/text/chapter-18.xhtml) | 34,236 | Complete Netherfield-ball chapter: 76 paragraphs and inline abbreviations/emphasis. |
| mixed_content | [Pride and Prejudice chapter 43](https://github.com/standardebooks/jane-austen_pride-and-prejudice/blob/ed94a32be3e875c0814568050c7544e03aad3ef5/src/epub/text/chapter-43.xhtml) | 31,168 | Complete Pemberley chapter: 77 paragraphs and inline abbreviations/emphasis. |
| namespaces | [Inkscape blend_modes.svg](https://gitlab.com/inkscape/inkscape/-/blob/884658ec37ad1d90f9c2d21eca0b033ef1308150/share/examples/blend_modes.svg) | 192,023 | Eight namespace declarations, author/licence RDF, 26 blend filters, 219 gradients, 209 rectangles, 50 text labels. |
| namespaces | [Inkscape turbulence_filters.svg](https://gitlab.com/inkscape/inkscape/-/blob/884658ec37ad1d90f9c2d21eca0b033ef1308150/share/examples/turbulence_filters.svg) | 19,790 | Eight namespace declarations, author/licence RDF, six turbulence filters and associated filter operations. |

Structure counts come from lexical source inspection, not runtime callback measurements. The category strata are not mutually exclusive XML features: the mixed-content XHTML files also use namespaces.

## Provenance and exclusions

[selection.json](selection.json) records the predeclared criteria, original held-out and generated manifest hashes, rehashed input comparisons, selection changes and limitations. Files are <=1 MiB each and <=4 MiB aggregate, from three distinct upstream projects. GitHub requests use `gh-auto` from the selected checkout; request commands/responses are retained. Inkscape's organization-owned GitHub redirect identifies its canonical GitLab repository; its commit, trees, base64 blobs and four-entry histories for each selected file are retained. Both original paths trace to Niko Kiirala's 2007/2008 Inkscape examples. Every selected decoded blob matches its Git object ID, length and SHA256. Local filename changes do not change file bytes.

No selected hash equals the seven held-out/related XML inputs or twelve generated inputs. Provenance also distinguishes Qt UI source from GTK fixtures, Standard Ebooks' transcription/scans from DocBook transformations, and Inkscape-authored examples from Batik samples. Inkscape's application dependency on GTK is not ancestry of these XML documents. This is a bounded source-lineage review, not an exhaustive Internet-wide duplicate search.

None of the files declares an external DTD/entity or uses non-predefined entities. SVG href values point to existing internal IDs. XHTML stylesheet links are ordinary attributes and require no resource resolution during XML parsing; book/application rendering is outside this experiment. Namespace URI strings are identifiers, not retrieval requests.

## Licences and retained selection attempts

[NOTICE.md](NOTICE.md) identifies the upstream grants and local notice copies. Full notices and the SVG embedded attribution remain intact. The Inkscape example directory is distributed artwork; these two files are authored filter examples, not a parser benchmark suite.

Two prospective Inkscape artworks were excluded for missing individual licence statements. Their exact bytes and original acquisition records remain under `provenance/unselected-artworks`, with a relocation map. Seven alternate example files were inspected for licence metadata; only the manifest pair is selected. Mermaid was excluded during source selection because its substantive current SVG pair comprises near-identical themes and the inspected older release provides only tiny logos. No selection used performance outcomes.

The first GitHub blob-fetch script failed before requests because the environment omitted its sibling import path; the failed script/receipt and explicit import correction are retained. Direct Creative Commons legal-text requests failed with TLS EOF; those failures are retained. The licence text copies subsequently obtained from a pinned SPDX repository are mirrors; the grants come from the actual upstream files/metadata.

## Review and freeze

The selector/acquirer is `/root/ffi/conditional_review`. An independent source/provenance review must pass before the final freeze. A later `freeze.json` will bind the reviewed inputs and evidence. No XML parser, library, compiler, training or benchmark was executed during acquisition. Future preflight must keep every first result and must not silently replace files after observing performance.
