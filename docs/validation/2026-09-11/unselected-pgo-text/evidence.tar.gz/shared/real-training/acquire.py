#!/usr/bin/env python3
"""Record read-only GitHub API acquisition; never execute an XML parser."""
import datetime,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def api(endpoint,label):
    out=ROOT/'provenance'; out.mkdir(exist_ok=True)
    path=out/(label+'.json')
    if path.exists():
        raise RuntimeError('refusing overwrite: '+str(path))
    cmd=['gh-auto','api',endpoint]
    proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd='/home/dev-user/code/oss/oriole-cdata-finder')
    path.write_bytes(proc.stdout); (out/(label+'.stderr')).write_bytes(proc.stderr)
    (out/(label+'-command.json')).write_text(json.dumps({'argv':cmd,'cwd':'/home/dev-user/code/oss/oriole-cdata-finder','exit_code':proc.returncode,'stdout_sha256':hashlib.sha256(proc.stdout).hexdigest(),'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
    if proc.returncode:
        raise RuntimeError(proc.stderr.decode())
    return json.loads(proc.stdout)

if __name__=='__main__':
    print(json.dumps(api(sys.argv[1],sys.argv[2]),indent=2))
