#!/usr/bin/env python3
import datetime,hashlib,json,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def api(endpoint,label):
    url='https://gitlab.com/api/v4/projects/3472737/'+endpoint
    path=ROOT/'provenance'/(label+'.json');assert not path.exists()
    try:
        with urllib.request.urlopen(url,timeout=30) as response:
            data=response.read();status=response.status
        path.write_bytes(data)
        (ROOT/'provenance'/(label+'-request.json')).write_text(json.dumps({'url':url,'method':'GET','status':status,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':hashlib.sha256(data).hexdigest()},indent=2)+'\n')
        return json.loads(data)
    except Exception as error:
        (ROOT/'provenance'/(label+'-failure.json')).write_text(json.dumps({'url':url,'error':str(error)},indent=2)+'\n')
        raise

if __name__=='__main__':
    c=api('repository/commits/master','inkscape-gitlab-commit');print(c['id'])
    t=api('repository/tree?path=share/examples&per_page=100&ref='+c['id'],'inkscape-gitlab-examples-tree');print(json.dumps(t,indent=2))
    t=api('repository/tree?per_page=100&ref='+c['id'],'inkscape-gitlab-root-tree');print([(r['path'],r['type']) for r in t])
