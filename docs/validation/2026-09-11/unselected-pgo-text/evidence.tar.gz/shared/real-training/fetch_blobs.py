#!/usr/bin/env python3
import base64,hashlib,json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from acquire import api,ROOT

def fetch(repo,label,paths):
    tree=json.loads((ROOT/'provenance'/(label+'-tree.json')).read_text())
    commit=json.loads((ROOT/'provenance'/(label+'-commit.json')).read_text())['sha']
    entries={row['path']:row for row in tree['tree']}
    records=[]
    for upstream_path,local_path,role in paths:
        row=entries[upstream_path]
        blob=api('repos/'+repo+'/git/blobs/'+row['sha'],label+'-blob-'+row['sha'])
        assert blob['encoding']=='base64'
        data=base64.b64decode(blob['content'])
        gitsha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        assert blob['sha']==row['sha']==gitsha and len(data)==row['size']==blob['size']
        dest=ROOT/local_path;dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();dest.write_bytes(data)
        records.append({'repository':'https://github.com/'+repo,'commit':commit,'upstream_path':upstream_path,'canonical_url':'https://github.com/'+repo+'/blob/'+commit+'/'+upstream_path,'git_blob_sha1':gitsha,'file':local_path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'role':role,'blob_response':'provenance/'+label+'-blob-'+row['sha']+'.json'})
        print(local_path,len(data))
    dest=ROOT/'provenance'/(label+'-acquired.json');assert not dest.exists();dest.write_text(json.dumps(records,indent=2)+'\n')
    return records

if __name__=='__main__':
 fetch('qbittorrent/qBittorrent','qbittorrent--qBittorrent',[
  ('src/gui/optionsdialog.ui','inputs/qbittorrent-options.ui','input'),
  ('src/gui/properties/propertieswidget.ui','inputs/qbittorrent-properties.ui','input'),
  ('COPYING','licenses/qbittorrent/COPYING','license'),
  ('COPYING.GPLv2','licenses/qbittorrent/COPYING.GPLv2','license'),
  ('COPYING.GPLv3','licenses/qbittorrent/COPYING.GPLv3','license'),
  ('README.md','provenance/qbittorrent-README.md','provenance')])
 fetch('standardebooks/jane-austen_pride-and-prejudice','standardebooks--jane-austen_pride-and-prejudice',[
  ('src/epub/text/chapter-18.xhtml','inputs/pride-and-prejudice-18.xhtml','input'),
  ('src/epub/text/chapter-43.xhtml','inputs/pride-and-prejudice-43.xhtml','input'),
  ('LICENSE.md','licenses/standardebooks/LICENSE.md','license'),
  ('src/epub/text/colophon.xhtml','provenance/standardebooks-colophon.xhtml','provenance'),
  ('src/epub/content.opf','provenance/standardebooks-content.opf','provenance')])
