#!/usr/bin/env python3
import base64,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from acquire_gitlab import api,ROOT
commit=json.loads((ROOT/'provenance/inkscape-gitlab-commit.json').read_text())['id']
entries={r['path']:r for f in ['inkscape-gitlab-root-tree.json','inkscape-gitlab-examples-tree.json'] for r in json.loads((ROOT/'provenance'/f).read_text())}
records=[]
for upstream_path,local_path,role in [
 ('share/examples/README','licenses/inkscape/examples-README','notice'),
 ('COPYING','licenses/inkscape/COPYING','license'),
 ('README.md','provenance/inkscape-README.md','provenance'),
 ('share/examples/art-nouveau-P3.svg','inputs/inkscape-art-nouveau-P3.svg','input'),
 ('share/examples/eastern-motive-P4G.svg','inputs/inkscape-eastern-motive-P4G.svg','input')]:
 row=entries[upstream_path];blob=api('repository/blobs/'+row['id'],'inkscape-blob-'+row['id'])
 assert blob['encoding']=='base64';data=base64.b64decode(blob['content'])
 gitsha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert gitsha==row['id']==blob['sha'] and len(data)==blob['size']
 dest=ROOT/local_path;dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();dest.write_bytes(data)
 records.append({'repository':'https://gitlab.com/inkscape/inkscape','commit':commit,'upstream_path':upstream_path,'canonical_url':'https://gitlab.com/inkscape/inkscape/-/blob/'+commit+'/'+upstream_path,'git_blob_sha1':gitsha,'file':local_path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'role':role,'blob_response':'provenance/inkscape-blob-'+row['id']+'.json'})
 print(local_path,len(data))
(ROOT/'provenance/inkscape-acquired.json').write_text(json.dumps(records,indent=2)+'\n')
