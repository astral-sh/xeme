#!/usr/bin/env python3
import base64,hashlib,json,re,sys,concurrent.futures
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from acquire_gitlab import api,ROOT
entries={r['path']:r for r in json.loads((ROOT/'provenance/inkscape-gitlab-examples-tree.json').read_text())}
paths=['blend_modes.svg','glass.svg','lighting_filters.svg','live-path-effects-gears.svg','rope-3D.svg','text-on-path.svg','turbulence_filters.svg']
def one(name):
 r=entries['share/examples/'+name];blob=api('repository/blobs/'+r['id'],'inkscape-blob-'+r['id']);b=base64.b64decode(blob['content']);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['id']
 p=ROOT/'provenance/svg-license-candidates'/name;p.parent.mkdir(exist_ok=True);assert not p.exists();p.write_bytes(b)
 s=b.decode('utf8');found=[s[max(0,m.start()-80):m.start()+230] for m in re.finditer('license|License|creator|title|copyright|Copyright',s)]
 return {'file':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'blob':r['id'],'matches':found}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 result=list(pool.map(one,paths))
(ROOT/'provenance/svg-license-inspection.json').write_text(json.dumps(result,indent=2)+'\n')
for r in result: print(json.dumps(r,ensure_ascii=False))
