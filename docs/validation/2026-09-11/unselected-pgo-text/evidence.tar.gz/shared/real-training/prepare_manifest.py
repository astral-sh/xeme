#!/usr/bin/env python3
"""Prepare fixed corpus metadata by byte/text inspection; no XML parser execution."""
import collections,hashlib,json,re,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads((ROOT/p).read_text())

# Preserve prospective artwork bytes and their original acquisition records.
relocations=[]
for name in ['inkscape-art-nouveau-P3.svg','inkscape-eastern-motive-P4G.svg']:
 old=ROOT/'inputs'/name;new=ROOT/'provenance/unselected-artworks'/name
 new.parent.mkdir(exist_ok=True);assert old.exists() and not new.exists();b=old.read_bytes();old.rename(new)
 relocations.append({'acquired_file':'inputs/'+name,'retained_file':str(new.relative_to(ROOT)),'sha256':sha(b),'reason':'No explicit individual artwork license; replaced before parser/build/performance execution.'})
(ROOT/'provenance/prospective-artwork-relocations.json').write_text(json.dumps(relocations,indent=2)+'\n')

records=[]
for name in ['qbittorrent--qBittorrent-acquired.json','standardebooks--jane-austen_pride-and-prejudice-acquired.json']:
 records += [r for r in load('provenance/'+name) if r['role']=='input']
ink_commit=load('provenance/inkscape-gitlab-commit.json')['id']
ink_rows={r['name']:r for r in load('provenance/inkscape-gitlab-examples-tree.json')}
for name in ['blend_modes.svg','turbulence_filters.svg']:
 src=ROOT/'provenance/svg-license-candidates'/name;dest=ROOT/'inputs'/('inkscape-'+name);assert not dest.exists();dest.write_bytes(src.read_bytes());b=dest.read_bytes();row=ink_rows[name]
 records.append({'repository':'https://gitlab.com/inkscape/inkscape','commit':ink_commit,'upstream_path':'share/examples/'+name,'canonical_url':'https://gitlab.com/inkscape/inkscape/-/blob/'+ink_commit+'/share/examples/'+name,'git_blob_sha1':row['id'],'file':str(dest.relative_to(ROOT)),'bytes':len(b),'sha256':sha(b),'blob_response':'provenance/inkscape-blob-'+row['id']+'.json'})

heldout_origin=Path('/home/dev-user/code/oss/oriole-cdata-finder/benchmarks/projects/corpus-manifest.json')
generated_origin=Path('/tmp/oriole-cdata-finder-pgo-study/pgo/runs/run-sjsgpms8/inputs/manifest.json')
for origin,name in [(heldout_origin,'heldout-corpus-manifest.json'),(generated_origin,'generated-corpus-manifest.json')]:
 (ROOT/'provenance'/name).write_bytes(origin.read_bytes())
heldout=json.loads(heldout_origin.read_text());generated=json.loads(generated_origin.read_text())
comparison=[]
for project in heldout['projects']:
 for row in project['files']:
  if row['role'] not in ['input','related-small-input']:continue
  p=heldout_origin.parent/row['path'];b=p.read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes']
  comparison.append({'kind':'heldout_or_related','project':project['name'],'path':str(p),'sha256':sha(b)})
for row in generated['rows']:
 p=generated_origin.parent/row['file'];b=p.read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'];comparison.append({'kind':'generated','name':row['name'],'path':str(p),'sha256':sha(b)})
excluded={r['sha256'] for r in comparison}

choices=[
 ('qbittorrent-options','config','Qt OptionsDialog: nested widgets/layouts/items, 728 properties, literal class/name attributes and textual settings.', 'GPL-2.0-or-later with upstream OpenSSL exception; see COPYING.', ['licenses/qbittorrent/COPYING','licenses/qbittorrent/COPYING.GPLv2','licenses/qbittorrent/COPYING.GPLv3','licenses/qbittorrent/AUTHORS']),
 ('qbittorrent-properties','config','Qt torrent PropertiesWidget: nested property/layout tree, 80 widgets and 216 properties.', 'GPL-2.0-or-later with upstream OpenSSL exception; see COPYING.', ['licenses/qbittorrent/COPYING','licenses/qbittorrent/COPYING.GPLv2','licenses/qbittorrent/COPYING.GPLv3','licenses/qbittorrent/AUTHORS']),
 ('pride-and-prejudice-18','mixed_content','Complete Netherfield-ball chapter: 76 paragraphs, inline abbreviations/emphasis, typographic Unicode; XHTML and EPUB namespaces.', 'Upstream LICENSE.md: source believed public domain in the US, with jurisdiction caveat; contributions dedicated under CC0-1.0.', ['licenses/standardebooks/LICENSE.md','licenses/standardebooks/CC0-1.0.txt']),
 ('pride-and-prejudice-43','mixed_content','Complete Pemberley chapter: 77 paragraphs with inline abbreviations/emphasis, typographic Unicode; XHTML and EPUB namespaces.', 'Upstream LICENSE.md: source believed public domain in the US, with jurisdiction caveat; contributions dedicated under CC0-1.0.', ['licenses/standardebooks/LICENSE.md','licenses/standardebooks/CC0-1.0.txt']),
 ('inkscape-blend-modes','namespaces','Complete authored blending-mode example: eight namespace declarations, RDF/CC/DC author/license metadata, 26 blend filters, 219 gradients, 209 rectangles and 50 text labels.', 'CC-BY-SA-3.0, Copyright 2007 Niko Kiirala; explicit embedded RDF grant retained byte-exact.', ['licenses/inkscape/CC-BY-SA-3.0.txt','licenses/inkscape/examples-README','licenses/inkscape/COPYING']),
 ('inkscape-turbulence-filters','namespaces','Complete authored filter gallery: eight namespace declarations, prefixed Inkscape elements/attributes and RDF/CC/DC metadata, six turbulence filters with displacement/color/composite/lighting operations.', 'CC-BY-SA-3.0, Niko Kiirala; embedded rights also permit free use of filter effect definitions.', ['licenses/inkscape/CC-BY-SA-3.0.txt','licenses/inkscape/examples-README','licenses/inkscape/COPYING'])]
assert len(records)==len(choices)==6
for r,(ident,category,description,license_description,license_paths) in zip(records,choices,strict=True):
 b=(ROOT/r['file']).read_bytes();s=b.decode('utf-8');assert len(b)<=1048576 and sha(b)==r['sha256'] and r['sha256'] not in excluded
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['git_blob_sha1']
 assert '<!DOCTYPE' not in s and '<!ENTITY' not in s and '\x00' not in s
 assert set(re.findall(r'&([A-Za-z_][\w.-]*);',s)) <= {'amp','lt','gt','quot','apos'}
 namespaces=re.findall(r'\bxmlns(?::([\w.-]+))?\s*=\s*"([^"]*)"',s)
 refs=re.findall(r'(?:xlink:href|href|src)\s*=\s*"([^"]*)"',s)
 r.pop('role',None);r.update({'id':ident,'category':category,'encoding':'UTF-8','license':license_description,'license_files':[{'file':p,'sha256':sha((ROOT/p).read_bytes())} for p in license_paths],'structure':{'description':description,'inspection':'UTF-8 decode and lexical source inspection only, not XML parser validation or runtime event counts.','lexical_start_tag_counts':dict(collections.Counter(re.findall(r'<([A-Za-z_][\w:.-]*)\b',s))),'namespace_declarations':[{'prefix':p,'uri':u} for p,u in namespaces],'external_doctype_or_entity_declaration':False,'link_attribute_values':sorted(set(refs))}})
 if category=='namespaces':
  assert all(ref.startswith('#') for ref in refs)
  ids=set(re.findall(r'\bid\s*=\s*"([^"]*)"',s));assert all(ref[1:] in ids for ref in refs)

manifest={'schema_version':1,'selected_runtime':'78c748d9de5c497858458cbf7a1229148781b2bf','criteria':{'predeclared_plan':'/tmp/oriole-pgo-training-distribution-review/PLAN.md','predeclared_plan_sha256':'9e61facbc7d90c59daf549ac7c02d58f15af4dac31411e241022b4978922459b','documents':6,'projects':3,'category_counts':{'config':2,'mixed_content':2,'namespaces':2},'max_document_bytes':1048576,'max_total_bytes':4194304,'unmodified_utf8':True,'excluded_projects':['Vulkan','Wayland','Maven','Batik','GTK','DocBook'],'exclusion_scope':'Also exclude their forks, derived data, and adjacent held-out fixtures. Project software dependencies are not XML-source ancestry. No performance observations were used for selection.','external_independence':'No DTD/entity declarations or non-predefined entity references. No external resource is needed to parse XML. XHTML CSS links are data, not parser resource requests; SVG href values are checked internal IDs. Rendering the complete applications/books/artworks is outside scope.'},'documents':records,'schedule':{'chunks':[4096,65536],'namespaces':[False,True],'handlers':['minimal','full'],'iterations':1}}
assert sum(r['bytes'] for r in records)<=4194304
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
receipt={'status':'prepared_pending_independent_review','role':'Corpus selector/acquirer; not independent reviewer.','target_execution':False,'manifest_sha256':sha((ROOT/'manifest.json').read_bytes()),'selected_documents':6,'selected_bytes':sum(r['bytes'] for r in records),'additional_parses':48,'additional_input_bytes':sum(r['bytes'] for r in records)*8,'heldout_manifest_sha256':sha(heldout_origin.read_bytes()),'generated_manifest_sha256':sha(generated_origin.read_bytes()),'comparison_source_records':comparison,'byte_hash_disjoint':True,'lineage_evidence':['qBittorrent canonical source/README identifies Qt client and its original dialog tree; not a GTK UI fixture.','Standard Ebooks colophon identifies Gutenberg/Distributed Proofreaders transcription and HathiTrust scans of Jane Austen, not DocBook transformation.','Inkscape canonical history records Niko Kiirala adding the blend and turbulence examples in 2007/2008; embedded metadata credits him and Inkscape. These are distributed artwork examples, not Batik samples or parser fixtures.'],'selection_changes':['Official Inkscape GitHub is a redirect; use its expressly linked canonical GitLab repository.','Mermaid inspected but excluded: large assets are near-identical theme variants, older checked release has tiny logos.','Inkscape art-nouveau/eastern-motive prospective pair was replaced before any targets because individual licenses are unspecified; exact bytes/acquisition/relocation record retained.','Inspected seven alternative Inkscape examples for explicit license provenance. Selected substantive blend/turbulence pair; no runtime/performance feedback existed.'],'acquisition_limitations':['First fetch_blobs.py invocation failed at sibling import before API/input writes; source/failure retained; explicit sibling import then succeeded.','Direct Creative Commons legalcode requests failed TLS EOF; retained. SPDX GitHub commit-pinned texts are mirrors only; actual grants remain upstream LICENSE.md/embedded SVG metadata.','No XML parser has validated the proposed inputs. Future explicitly released preflight must validate the fixed schedule without silently replacing failed inputs.']}
(ROOT/'selection.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt['manifest_sha256'],receipt['selected_bytes'],receipt['additional_input_bytes'])
