"""Independent full native saved-data audit. No target/producer execution."""
from pathlib import Path
import ast,datetime,difflib,hashlib,json,math,random,statistics,sys,os
assert sys.argv[1:]==["--released"], "Run only after parent confirms both Text campaigns completed and reaped"
assert os.sched_getaffinity(0)=={6}
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={}
def pin(p):inputs[str(p)]=sha(p)
report={'status':'passed','role':'Independent saved-data audit of root-collected normal and PGO native cohorts. No target executions.','reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native':{}}
for phase in ['normal','pgo']:
 S=Path('/tmp/oriole-deferred-c-text-raw-'+phase+'-native-study'); T=Path('/tmp/oriole-compact-delivery-status-'+phase+'-native-study'); D=S/'native-screen'
 old,new=T/'native_screen.py',S/'native_screen.py'
 diff=''.join(difflib.unified_diff(old.read_text().splitlines(keepends=True),new.read_text().splitlines(keepends=True),fromfile=str(old),tofile=str(new)))
 (Path(__file__).parent/(phase+'-producer-controller.patch')).write_text(diff)
 assert (S/'run.py').read_bytes()==(T/'run.py').read_bytes()==(S/'run.py.in').read_bytes()
 assert sha(S/'run.py')=='5f41a419e800e95954424e2a85d2ee988609d830db18dc85c469af801cd8aef5'
 prep=read(S/'adaptation.json');template=read(S/'template-preparation.json')
 assert template['origin']==str(T) and template['original_controller_sha256']==sha(old)
 assert prep['status']=='passed' and prep['template_preparation_sha256']==sha(S/'template-preparation.json')
 assert prep['controller_sha256']==sha(new) and sha(S/'native_screen.py.in')==template['template_sha256']
 expected=old.read_text()
 for old_value,new_value in template['replacement_pairs']:expected=expected.replace(old_value,new_value)
 assert expected==(S/'native_screen.py.in').read_text() and expected.count(template['placeholder'])==1
 assert expected.replace(template['placeholder'],prep['candidate_library']['path'])==new.read_text()
 # Entire AST match after only three assignment/string substitutions already reviewed in exact diff.
 def comparable(p):
  tree=ast.parse(p.read_text());tree.body[0].value=ast.Constant('<caption>')
  for n in tree.body:
   if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name):
    name=n.targets[0].id
    if name=='root':n.value=ast.Constant('<study>')
    elif name=='libraries':n.value.values[1]=ast.Constant('<candidate>')
    elif name=='protocol':n.value.values[0]=ast.Constant('<scope>')
  return ast.dump(tree)
 assert comparable(old)==comparable(new)
 p,f,r=map(read,[D/'protocol.json',D/'preflight.json',D/'results.json'])
 assert f['status']==r['status']=='passed' and r['affinity']==[0]
 assert f['protocol_sha256']==r['protocol_sha256']==sha(D/'protocol.json')
 assert r['preflight_sha256']==sha(D/'preflight.json')
 for x in [f,r]: assert x['hashes_before']==x['hashes_after']==p['hashes']
 for q,h in p['hashes'].items(): assert sha(q)==h
 assert len(p['conditions'])==28 and p['pairs']==7 and p['seed']==2026091003
 manifest=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
 fixtures={}
 for project in read(manifest)['projects']:
  entry=next(q for q in project['files'] if q['role']=='input');path=(manifest.parent/entry['path']).resolve();assert sha(path)==entry['sha256'];fixtures[project['name']]=str(path)
 fixtures.update({'generated-rare-declarations':'/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml','generated-entities':'/tmp/oriole-grammar-bench-plain/entities.xml'})
 iterations={'vulkan':7,'wayland':64,'maven':128,'batik':512,'gtk':256,'docbook':256,'generated-rare-declarations':32,'generated-entities':32}
 expected_conditions=[{'name':name,'input':path,'chunk':chunk,'namespaces':ns,'iterations':iterations[name]} for chunk in [4096,65536] for name,path in fixtures.items() for ns in ([False] if name.startswith('generated-') else [False,True])]
 assert p['conditions']==expected_conditions
 assert {c['chunk'] for c in p['conditions']}=={4096,65536}
 assert sum(c['name'].startswith('generated-') for c in p['conditions'])==4
 assert len(f['rows'])==84 and len(r['rows'])==196 and len(r['summary'])==28
 assert len(list(D.glob('worker-*.json')))==672
 ctl=read(S/'controller.json');assert ctl['status']=='passed' and ctl['controller_sha256']==sha(new) and ctl['wrapper_sha256']==sha(S/'run.py')
 for row,(stage,cpu,bound) in zip(ctl['commands'],[('preflight',5,600),('time',0,1200)],strict=True):
  assert row['phase']==stage and row['exit']==0 and row['timeout']==bound
  assert row['command']==['taskset','-c',str(cpu),'python3',str(new),stage]
  assert sha(S/(stage+'-controller.log'))==row['log_sha256']
 ordinal=0; medians={}; obs={}; samples_count=0
 def worker(row,c,pair,engine,cpu,count):
  global ordinal,samples_count
  raw=read(D/f'worker-{ordinal:04d}.json');ordinal+=1
  assert raw=={k:v for k,v in row.items() if k not in ['observations','median_seconds']}
  assert row['condition']==c and row['pair']==pair and row['engine']==engine and row['returncode']==0 and row['stderr']==''
  assert row['command']==['taskset','-c',str(cpu),'/tmp/oriole-grammar-bench-plain/native-driver',p['libraries'][engine]['path'],c['input'],str(c['chunk']),str(count)]+(['namespaces'] if c['namespaces'] else [])
  data=json.loads(row['stdout']);s=data['samples'];samples_count+=len(s)
  assert len(s)==count+1 and [x['iteration'] for x in s]==list(range(count+1))
  assert [x['warmup'] for x in s]==[True]+[False]*count
  assert all(math.isfinite(x['seconds']) and x['seconds']>0 for x in s)
  got=sorted({(x['hash'],x['elements'],x['text_bytes']) for x in s});assert len(got)==1 and row['observations']==[list(x) for x in got]
  if json.dumps(c,sort_keys=True) in obs: assert obs[json.dumps(c,sort_keys=True)]==got
  else: obs[json.dumps(c,sort_keys=True)]=got
  assert got[0][1]>=0 and got[0][2]>=0
  med=statistics.median(x['seconds'] for x in s[1:]);assert med==row['median_seconds']
  return med
 for c in p['conditions']:
  for engine in p['libraries']:
   row=f['rows'][ordinal];worker(row,c,-1,engine,5,1)
 rng=random.Random(p['seed']);jobs=[(c,i) for c in p['conditions'] for i in range(7)];rng.shuffle(jobs)
 for row,(c,pair) in zip(r['rows'],jobs,strict=True):
  order=list(p['libraries']);rng.shuffle(order);assert row['condition']==c and row['pair']==pair and row['order']==order
  for rec,engine in zip(row['processes'],order,strict=True):medians[(json.dumps(c,sort_keys=True),pair,engine)]=worker(rec,c,pair,engine,0,c['iterations'])
 summary=[]
 for c in p['conditions']:
  pairs=[x['pair'] for x in r['rows'] if x['condition']==c]
  ratios={f'{x}_over_{y}':[medians[(json.dumps(c,sort_keys=True),i,x)]/medians[(json.dumps(c,sort_keys=True),i,y)] for i in pairs] for x,y in [('candidate','control'),('candidate','expat'),('control','expat')]}
  summary.append({'condition':c,'paired_ratios':ratios,'median_ratios':{k:statistics.median(v) for k,v in ratios.items()}})
 assert summary==r['summary'] and ordinal==672 and samples_count==106176
 groups={}
 for group in ['real','generated']:
  entries=[q for q in summary if q['condition']['name'].startswith('generated-')==(group=='generated')]
  groups[group]={'conditions':len(entries),'ratios':{k:statistics.geometric_mean(q['median_ratios'][k] for q in entries) for k in entries[0]['median_ratios']},'candidate_faster_than_control':sum(q['median_ratios']['candidate_over_control']<1 for q in entries),'candidate_faster_than_expat':sum(q['median_ratios']['candidate_over_expat']<1 for q in entries)}
 adverse=[{'name':q['condition']['name'],'chunk':q['condition']['chunk'],'namespaces':q['condition']['namespaces'],'ratio':q['median_ratios']['candidate_over_control']} for q in summary if q['median_ratios']['candidate_over_control']>1]
 groups['adverse_conditions']=adverse
 A=read(S/'adaptation.json');B=Path('/tmp/oriole-deferred-c-text-raw-pgo-study')
 assert A['build_freeze_sha256']==sha(B/'pair-freeze.json') and A['source_manifest_sha256']==sha(B/'source.json')
 assert A['controller_sha256']==sha(new) and A['wrapper_sha256']==sha(S/'run.py')
 proof=read('/tmp/oriole-deferred-c-text-raw-build-independent-review.json');pair=read(B/'pair-report.json')
 assert sha('/tmp/oriole-deferred-c-text-raw-build-independent-review.json')=='68dd884aac3f81f3a6a195cc07a80c7a78beb4af7e655be734bd137e944b04bb'
 assert sha(B/'pair-report.json')=='f0dcbef4a1d0559bae00ad5ce8b79d0156e7c36a72b9ada2e3de1084a43ebc49'
 assert sha(B/'pair-freeze.json')=='1ae202d5daf63fddc25b93b60cf3916f99f8be73e056c90ccd384ea24d9ba4a4'
 assert sha(B/'source.json')=='dfa4fb42c7c6601d402d06adc17a4d0efa1208f57cd11658df65d9bb25c74009'
 assert proof['status']=='passed' and proof['pair_sha256']==sha(B/'pair-report.json') and proof['freeze_sha256']==sha(B/'pair-freeze.json')
 candidate_digest=pair['normal_libraries']['liboriole_expat.so'] if phase=='normal' else pair['pgo_libraries']['use/liboriole_expat.so']
 assert p['libraries']['candidate']['sha256']==candidate_digest
 assert p['libraries']['candidate']==A['candidate_library'] and p['libraries']['control']==A['control_library']
 old_protocol=read(T/'native-screen/protocol.json')
 assert p['libraries']['control']==old_protocol['libraries']['control']
 assert p['libraries']['expat']==old_protocol['libraries']['expat']
 assert p['conditions']==old_protocol['conditions'] and p['pairs']==old_protocol['pairs'] and p['seed']==old_protocol['seed']
 assert p['hashes'][str(manifest)]==old_protocol['hashes'][str(manifest)]
 assert p['hashes']['/tmp/oriole-grammar-bench-plain/native-driver']==old_protocol['hashes']['/tmp/oriole-grammar-bench-plain/native-driver']
 assert all(p['hashes'][q]==old_protocol['hashes'][q] for q in fixtures.values())
 for library in p['libraries'].values():assert sha(library['path'])==library['sha256']
 assert set(p['hashes'])=={str(new),str(manifest),'/tmp/oriole-grammar-bench-plain/native-driver',*fixtures.values(),*[v['path'] for v in p['libraries'].values()]}
 report['native'][phase]={'preflights':84,'timed_workers':588,'cohorts':196,'measured_samples':105420,'timed_warmups':588,'preflight_samples':168,'total_samples':106176,'groups':groups,'all_conditions':[{'condition':q['condition'],'median_ratios':q['median_ratios']} for q in summary]}
 for q in [Path(__file__).parent/(phase+'-producer-controller.patch'),T/'native_screen.py',T/'native-screen/protocol.json',S/'template-preparation.json',S/'native_screen.py.in',S/'adaptation.json',S/'run.py',S/'native_screen.py',S/'controller.json',D/'protocol.json',D/'preflight.json',D/'results.json']:pin(q)

report['limitations']=['One original fixed native campaign per mode, all adverse conditions retained. Python and full compatibility gates are outside this review.','All 56 condition ratios and adverse cases are retained; this audit does not establish a hardware or compiler mechanism.','Legacy native worker uses explicit dlopen paths and before/after file hashes; no new same-process XML_Parse dladdr is added.']
report['decision']='Saved numerical reconstruction only; candidate selection and further correctness gates are separate.'
pin('/tmp/oriole-deferred-c-text-raw-build-independent-review.json')
report['configuration_scope']='Matched O3 ThinLTO normal and independently fresh original generated-only G profiles. Full actual compiler vectors match Finder controls; seven source/test files changed, four runtime files. The deferred C Text change and its host protocol are isolated from additive/bulk training. Source/build and focused-check reviews are pinned separately; this reviewer proposed the earlier design but neither authored runtime nor collected elapsed results.'
report['reviewer_attempts']=['First saved-data audit attempt for these cohorts; no producer or target executions.']
report['generator_sha256']=sha(__file__)
report['input_sha256']=inputs
report['totals']={'conditions':56,'preflight_workers':168,'timed_workers':1176,'all_workers':1344,'all_samples':212352}
report['reader_adaptation_note']='Exact old controller to reviewed template to final candidate path reconstruction; original full worker/sample/condition/seeded order/callback/median/ratio reconstruction is byte-identical to the completed Finder reader.'
out=Path('/tmp/oriole-deferred-c-text-raw-native-independent-review.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'review':str(out),'sha256':sha(out),'groups':{k:v['groups'] for k,v in report['native'].items()}}))
