"""Collect frozen static code after explicit parent release; never run a parser."""
from pathlib import Path
import hashlib,json,os,re,subprocess,time
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
assert os.sched_getaffinity(0)=={1}
plan=load(R/'plan.json');release=load(R/'released-inputs.json')
assert release['status']=='released_for_static_inspection'
assert release['plan_sha256']==sha(R/'plan.json')
assert release['controller_sha256']==sha(__file__)
P=Path(plan['candidate_pair_directory']);S=Path(plan['source_manifest']['path'])
required={str(P/n) for n in ['pair-report.json','vector-training-proof.json','pair-freeze.json','source.json']}
required|={str(S),'/tmp/oriole-deferred-c-text-raw-study/checks-attempt02/results.json','/tmp/oriole-deferred-c-text-raw-study/independent-source-review-attempt02.json'}
assert required<=release['verified_files'].keys()
def verify():
    assert sha(S)==plan['source_manifest']['sha256']
    assert all(sha(p)==h for p,h in plan['tool_pins'].items())
    assert all(sha(p)==h for p,h in release['verified_files'].items())
    assert sha(plan['control_pair_freeze']['path'])==plan['control_pair_freeze']['sha256']
    pair=load(P/'pair-report.json');proof=load(P/'vector-training-proof.json');freeze=load(P/'pair-freeze.json')
    assert pair['status']==proof['status']=='passed' and freeze['status']=='frozen'
    assert proof['fresh_workspace_compilations']==9 and sum(proof['generated_rows'].values())==864
    assert load('/tmp/oriole-deferred-c-text-raw-study/checks-attempt02/results.json')['status']=='passed'
    assert load(P/'source.json')['source_sha256']==load(S)['source_sha256']
    assert len(load(S)['source_sha256'])==70
    for name,h in load(S)['source_sha256'].items():assert sha(Path('/home/dev-user/code/oss/oriole-deferred-c-text-raw')/name)==h
    for name,entry in freeze['files'].items():assert sha(P/name)==entry['sha256']
    libs=dict(plan['control_libraries']);libs.update(release['candidate_libraries'])
    assert set(libs)=={'control-normal','control-pgo','candidate-normal','candidate-pgo'}
    assert libs['candidate-normal']=={'path':str(P/'normal/liboriole_expat.so'),'sha256':pair['normal_libraries']['liboriole_expat.so']}
    assert libs['candidate-pgo']=={'path':str(Path(pair['pgo_manifest']['path']).parent/'use/liboriole_expat.so'),'sha256':pair['pgo_libraries']['use/liboriole_expat.so']}
    assert all(sha(row['path'])==row['sha256'] for row in libs.values())
    return libs
libraries=verify();out=R/'assembly-attempt01';out.mkdir(exist_ok=False)
record={'status':'running','scope':'Static ELF reads only; manual deferred Text copy/reservation/layout gate pending. No parser/profiler/elapsed work.','plan_sha256':sha(R/'plan.json'),'release_sha256':sha(R/'released-inputs.json'),'controller_sha256':sha(__file__),'libraries':libraries,'commands':[],'relevant_symbols':{}}
def save():
    (out/'collection.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
    for name,library in libraries.items():
        for suffix,template in zip(['nm','asm','sections','segments'],plan['commands_per_library']):
            argv=[library['path'] if arg=='LIBRARY' else arg for arg in template]
            row={'name':name+'.'+suffix,'argv':argv,'start':time.time(),'timeout':60};record['commands'].append(row);save()
            stdout=out/(name+'.'+suffix);stderr=out/(name+'.'+suffix+'.stderr')
            try:
                with stdout.open('xb') as o,stderr.open('xb') as e:
                    result=subprocess.run(argv,env=plan['environment'],stdin=subprocess.DEVNULL,stdout=o,stderr=e,timeout=60)
                row['exit']=result.returncode
                assert result.returncode==0,row['name']
            except BaseException as error:
                row['exception']=repr(error);raise
            finally:
                row['end']=time.time();row['stdout_sha256']=sha(stdout);row['stderr_sha256']=sha(stderr);save()
        symbols=[]
        for line in (out/(name+'.nm')).read_text().splitlines():
            m=re.match(r'^([0-9a-f]+) ([0-9a-f]+) (\S) (.+)$',line)
            if m and any(k in m[4] for k in ['<oriole::Parser>::next_event','<oriole::Parser>::next_delivery','<oriole::Parser>::next_adapter_event','<oriole::Parser>::parse_text','<oriole::Parser>::save_text_raw','<oriole::Parser>::save_current_raw','<oriole::Parser>::current_raw','<oriole::Parser>::materialize_current_raw','<oriole::Parser>::try_new','<oriole::Parser>::feed','with_dtd_tables','oriole_expat::run_events','XML_Parse','XML_DefaultCurrent']):
                symbols.append({'address':hex(int(m[1],16)),'bytes':int(m[2],16),'type':m[3],'name':m[4]})
        record['relevant_symbols'][name]=symbols;save()
    assert verify()==libraries
    record['status']='collected_pending_manual_Text_raw_review'
finally:
    save()
print(json.dumps({'status':record['status'],'collection_sha256':sha(out/'collection.json')}))
