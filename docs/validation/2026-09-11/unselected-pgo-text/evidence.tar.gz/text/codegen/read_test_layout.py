"""Read existing test ELF DWARF as data; never execute the ELF or compile code."""
from pathlib import Path
import gzip,hashlib,json,os,re,subprocess,time
R=Path(__file__).resolve().parent;S=Path('/tmp/oriole-deferred-c-text-raw-study');W=Path('/home/dev-user/code/oss/oriole-deferred-c-text-raw')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.sched_getaffinity(0)=={6}
checks=json.loads((S/'checks-attempt02/results.json').read_text());assert checks['status']=='passed'
assert sha(S/'checks-attempt02/results.json')=='7e44fce650c7c844364b432a4922e51430697c14909caef5ab1f58460bf00f31'
source=json.loads((S/'source-attempt02.json').read_text());assert all(sha(W/n)==h for n,h in source['source_sha256'].items())
log=S/'checks-attempt02/core.stderr';core=next(row for row in checks['commands'] if row['label']=='core');assert sha(log)==core['stderr_sha256']
binary=Path(re.search(r'Running unittests src/lib.rs \(([^)]+)\)',log.read_text())[1]);assert binary.stat().st_size<256*1024*1024
out=R/'test-layout-attempt01';out.mkdir(exist_ok=False)
command=['/usr/bin/timeout','--signal=TERM','--kill-after=5s','60s','/usr/bin/readelf','--debug-dump=info','--dwarf-depth=6',str(binary)]
record={'status':'running','scope':'Static existing exact-source test ELF type readback, not target execution or release layout proof. Artifact is pinned after the passed checks; release assembly must corroborate relevant offsets/sizes.','command':command,'cpu':6,'binary':{'path':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size},'source_manifest_sha256':sha(S/'source-attempt02.json'),'checks_sha256':sha(S/'checks-attempt02/results.json'),'core_stderr_sha256':sha(log),'tool_pins':{p:sha(p) for p in ['/usr/bin/readelf','/usr/bin/timeout']},'reader_sha256':sha(__file__),'stdout_max_bytes':256*1024*1024,'start':time.time()}
def save():(out/'layout.json').write_text(json.dumps(record,indent=2)+'\n')
save();digest=hashlib.sha256();size=0;proc=None
try:
 with (out/'readelf.stderr').open('wb') as err:
  proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=err,stdin=subprocess.DEVNULL,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'})
  with (out/'readelf-info.txt.gz').open('wb') as file:
   with gzip.GzipFile(filename='',mode='wb',fileobj=file,compresslevel=1,mtime=0) as dest:
    while True:
     chunk=proc.stdout.read(65536)
     if not chunk:break
     size+=len(chunk);digest.update(chunk);dest.write(chunk)
     if size>record['stdout_max_bytes']:proc.kill();raise RuntimeError('DWARF output bound exceeded')
  record['exit']=proc.wait();assert record['exit']==0
 # Keep only requested complete DIE attributes and their children in the concise report.
 rows=[];stack=[];selected=set();current=None
 header=re.compile(r'^\s*<(\d+)><([0-9a-f]+)>: Abbrev Number: (\d+)(?: \((DW_TAG_\w+)\))?')
 def finish():
  global current
  if current is None:return
  depth=current['depth'];stack[:]=[row for row in stack if row['depth']<depth]
  current['parents']=[{'offset':row['offset'],'name':row.get('name'),'tag':row['tag']} for row in stack]
  if current.get('name') in ['Parser','NativeRawRange','Option<oriole::NativeRawRange>'] and current['tag'] in ['DW_TAG_structure_type','DW_TAG_union_type']:
   selected.add(current['offset']);current['selected_type']=True
  if current['offset'] in selected or any(row['offset'] in selected for row in stack):rows.append(current.copy())
  if current['tag']:stack.append(current)
 with gzip.open(out/'readelf-info.txt.gz','rt') as file:
  for line in file:
   m=header.match(line)
   if m:
    finish();current={'depth':int(m[1]),'offset':m[2],'tag':m[4],'attributes':[]};continue
   if current is not None and 'DW_AT_' in line:
    current['attributes'].append(line.rstrip())
    if 'DW_AT_name' in line:
     name=line.split('DW_AT_name',1)[1].split(':',1)[1].strip();current['name']=re.sub(r'^\([^)]*\):\s*','',name)
    if 'DW_AT_byte_size' in line:current['byte_size']=int(line.rsplit(':',1)[1].strip(),0)
    if 'DW_AT_data_member_location' in line:
     value=line.rsplit(':',1)[1].strip()
     if value.isdigit():current['member_offset']=int(value)
 finish()
 record['selected_dies']=rows
 roots=[row for row in rows if row.get('selected_type')]
 assert any(row['name']=='Parser' and any(x.get('name')=='oriole' for x in row['parents']) for row in roots)
 assert any(row['name']=='NativeRawRange' for row in roots)
 record['type_sizes']=[{'name':row['name'],'bytes':row.get('byte_size'),'offset':row['offset'],'parents':row['parents']} for row in roots]
 assert sha(binary)==record['binary']['sha256']
 assert all(sha(W/n)==h for n,h in source['source_sha256'].items())
 record['status']='passed_static_test_type_readback'
except BaseException as error:
 record['exception']=repr(error)
 if proc is not None and proc.poll() is None:proc.kill();record['exit']=proc.wait()
 raise
finally:
 record.update(end=time.time(),stdout_bytes=size,stdout_sha256=digest.hexdigest(),stderr_sha256=sha(out/'readelf.stderr'),compressed_stdout_sha256=sha(out/'readelf-info.txt.gz'));save()
print(json.dumps({'status':record['status'],'type_sizes':record['type_sizes'],'stdout_bytes':size,'report_sha256':sha(out/'layout.json')}))
