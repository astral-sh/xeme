   91f91:	mov    rax,QWORD PTR [r14+0xa8]
   91f98:	xor    ecx,ecx
   91f9a:	cmp    rax,QWORD PTR [r12+0x768]
   91fa2:	cmove  rcx,r14
   91fa6:	mov    QWORD PTR [rsp+0x38],r15
   91fab:	mov    QWORD PTR [rsp+0x40],rcx
   91fb0:	mov    BYTE PTR [rsp+0x48],bpl
