   ab366:	add    rsi,0x30
   ab36a:	lea    rdi,[rsp+0xc0]
   ab372:	mov    rdx,r13
   ab375:	lea    rcx,[rsp+0x140]
   ab37d:	mov    r8d,0x1
   ab383:	call   91e90 <<oriole::Parser>::next_adapter_event>
