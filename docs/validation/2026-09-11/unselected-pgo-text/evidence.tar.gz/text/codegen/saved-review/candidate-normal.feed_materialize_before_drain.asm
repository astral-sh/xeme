   aae6a:	mov    r15,QWORD PTR [r13+0x0]
   aae6e:	mov    rdi,QWORD PTR [r15+0x980]
   aae75:	test   rdi,rdi
   aae78:	mov    QWORD PTR [rsp+0x8],r13
   aae7d:	je     aaed6 <std::panicking::catch_unwind::do_call::<core::panic::unwind_safe::AssertUnwindSafe<oriole_expat::XML_Parse::{closure#0}::{closure#0}>, i32>+0xa6>
   aae7f:	mov    rdx,QWORD PTR [r15+0xba0]
   aae86:	mov    rcx,QWORD PTR [r15+0xbb0]
   aae8d:	mov    r8,QWORD PTR [r15+0xbb8]
   aae94:	mov    rsi,QWORD PTR [r15+0x988]
   aae9b:	call   71660 <<oriole::NativeRawRange>::resolve>
   aaea0:	cmp    QWORD PTR [r15+0x638],rdx
   aaea7:	jb     ab17b <std::panicking::catch_unwind::do_call::<core::panic::unwind_safe::AssertUnwindSafe<oriole_expat::XML_Parse::{closure#0}::{closure#0}>, i32>+0x34b>
   aaead:	mov    r12,rdx
   aaeb0:	mov    rdi,QWORD PTR [r15+0x630]
   aaeb7:	mov    rsi,rax
   aaeba:	call   QWORD PTR [rip+0x44a58]        # ef918 <memcpy@GLIBC_2.14>
   aaec0:	mov    QWORD PTR [r15+0x640],r12
   aaec7:	mov    QWORD PTR [r15+0x980],0x0
   aaed2:	mov    r15,QWORD PTR [r13+0x0]
   aaed6:	lea    rdi,[r15+0x30]
   aaeda:	call   QWORD PTR [rip+0x44ec0]        # efda0 <_DYNAMIC+0x6a8>
   aaee0:	mov    rcx,QWORD PTR [r15+0xbb8]
   aaee7:	xor    edx,edx
   aaee9:	sub    rax,rcx
   aaeec:	cmovb  rax,rdx
   aaef0:	mov    r13,rax
   aaef3:	sub    r13,0x400
   aaefa:	cmovb  r13,rdx
   aaefe:	mov    rdi,QWORD PTR [r15+0xba0]
   aaf05:	mov    r12,QWORD PTR [r15+0xbb0]
   aaf0c:	mov    QWORD PTR [r15+0xbb0],0x0
   aaf17:	cmp    r12,r13
   aaf1a:	cmovb  r13,r12
   aaf1e:	jbe    aaf48 <std::panicking::catch_unwind::do_call::<core::panic::unwind_safe::AssertUnwindSafe<oriole_expat::XML_Parse::{closure#0}::{closure#0}>, i32>+0x118>
   aaf20:	sub    r12,r13
   aaf23:	cmp    rax,0x400
   aaf29:	jbe    aaf3f <std::panicking::catch_unwind::do_call::<core::panic::unwind_safe::AssertUnwindSafe<oriole_expat::XML_Parse::{closure#0}::{closure#0}>, i32>+0x10f>
   aaf2b:	lea    rsi,[rdi+r13*1]
   aaf2f:	mov    rdx,r12
   aaf32:	call   QWORD PTR [rip+0x44cf0]        # efc28 <memmove@GLIBC_2.2.5>
   aaf38:	mov    rcx,QWORD PTR [r15+0xbb8]
   aaf3f:	mov    QWORD PTR [r15+0xbb0],r12
