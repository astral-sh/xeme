   ad785:	lea    rdi,[rsp+0x120]
   ad78d:	lea    rsi,[rsp+0xd60]
   ad795:	mov    edx,0x978
   ad79a:	call   QWORD PTR [rip+0x42178]        # ef918 <memcpy@GLIBC_2.14>
