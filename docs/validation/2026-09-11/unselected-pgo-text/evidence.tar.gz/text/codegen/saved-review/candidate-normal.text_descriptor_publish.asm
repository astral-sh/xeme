   7f050:	test   rax,rax
   7f053:	je     7f1c4 <<oriole::Parser>::parse_text+0x14c4>
   7f059:	mov    QWORD PTR [r14+0x600],rax
   7f060:	mov    QWORD PTR [r14+0x608],r15
   7f067:	mov    QWORD PTR [r14+0x950],r12
   7f06e:	mov    QWORD PTR [r14+0x958],rbx
   7f075:	mov    BYTE PTR [r14+0x966],0x0
   7f07d:	mov    r15,QWORD PTR [rsp+0x110]
   7f085:	cmp    r15,0xfffffffffffffffe
   7f089:	je     7e917 <<oriole::Parser>::parse_text+0xc17>
