   7e855:	lea    rdi,[rsp+0x40]
   7e85a:	mov    rsi,r14
   7e85d:	mov    rdx,r12
   7e860:	call   8fcd0 <<oriole::Parser>::save_current_raw>
   7e865:	cmp    BYTE PTR [rsp+0x70],0xff
   7e86a:	mov    r15,QWORD PTR [rsp+0x110]
   7e872:	je     7e8f3 <<oriole::Parser>::parse_text+0xbf3>
