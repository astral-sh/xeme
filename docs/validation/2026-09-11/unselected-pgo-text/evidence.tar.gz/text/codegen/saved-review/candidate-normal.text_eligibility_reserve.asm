   7e9a7:	cmp    BYTE PTR [rbp+0x10],0x1
   7e9ab:	jne    7e852 <<oriole::Parser>::parse_text+0xb52>
   7e9b1:	cmp    BYTE PTR [r14+0x96a],0x0
   7e9b9:	jne    7e852 <<oriole::Parser>::parse_text+0xb52>
   7e9bf:	cmp    BYTE PTR [r14+0x96b],0x0
   7e9c7:	jne    7e852 <<oriole::Parser>::parse_text+0xb52>
   7e9cd:	cmp    QWORD PTR [r14+0x258],0x1
   7e9d5:	jne    7e852 <<oriole::Parser>::parse_text+0xb52>
   7e9db:	mov    rax,QWORD PTR [r14+0x248]
   7e9e2:	cmp    QWORD PTR [rax+0x90],0x0
   7e9ea:	jne    7e852 <<oriole::Parser>::parse_text+0xb52>
   7e9f0:	cmp    BYTE PTR [rax+0x17c],0x0
   7e9f7:	jne    7e852 <<oriole::Parser>::parse_text+0xb52>
   7e9fd:	or     r15b,BYTE PTR [rax]
   7ea00:	jne    7e852 <<oriole::Parser>::parse_text+0xb52>
   7ea06:	mov    rbx,QWORD PTR [rax+0x128]
   7ea0d:	mov    rdx,QWORD PTR [r14+0x610]
   7ea14:	xor    eax,eax
   7ea16:	mov    rcx,r12
   7ea19:	sub    rcx,rdx
   7ea1c:	cmovae rax,rcx
   7ea20:	mov    rcx,QWORD PTR [r14+0x608]
   7ea27:	mov    rsi,rcx
   7ea2a:	sub    rsi,rdx
   7ea2d:	cmp    rax,rsi
   7ea30:	jbe    7f067 <<oriole::Parser>::parse_text+0x1367>
   7ea36:	add    rax,rdx
   7ea39:	jb     7f1c4 <<oriole::Parser>::parse_text+0x14c4>
   7ea3f:	lea    rdi,[r14+0x5e0]
   7ea46:	lea    rdx,[rcx+rcx*1]
   7ea4a:	cmp    rax,rdx
   7ea4d:	cmova  rdx,rax
   7ea51:	cmp    rdx,0x9
   7ea55:	mov    r15d,0x8
   7ea5b:	cmovae r15,rdx
   7ea5f:	test   rcx,rcx
   7ea62:	je     7f036 <<oriole::Parser>::parse_text+0x1336>
   7ea68:	test   r15,r15
   7ea6b:	js     7f1c4 <<oriole::Parser>::parse_text+0x14c4>
   7ea71:	mov    rsi,QWORD PTR [r14+0x600]
   7ea78:	mov    bpl,0x1
   7ea7b:	mov    edx,0x1
   7ea80:	mov    r8d,0x1
   7ea86:	mov    r9,r15
   7ea89:	call   QWORD PTR [rip+0x71239]        # efcc8 <_DYNAMIC+0x5d0>
   7ea8f:	jmp    7f050 <<oriole::Parser>::parse_text+0x1350>
