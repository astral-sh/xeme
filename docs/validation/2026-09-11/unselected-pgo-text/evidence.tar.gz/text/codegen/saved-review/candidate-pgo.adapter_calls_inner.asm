   3bf08:	lea    rdi,[rsp+0x18]
   3bf0d:	lea    rdx,[rsp+0x250]
   3bf15:	mov    rsi,rbx
   3bf18:	call   3e8d0 <<oriole::Parser>::next_event_inner>
