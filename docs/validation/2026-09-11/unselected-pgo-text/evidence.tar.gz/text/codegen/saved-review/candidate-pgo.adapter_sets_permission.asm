   3be9a:	mov    QWORD PTR [rsp+0x250],r14
   3bea2:	mov    QWORD PTR [rsp+0x258],r13
   3beaa:	mov    BYTE PTR [rsp+0x260],0x1
