   2e793:	mov    rax,QWORD PTR [rbx+0x988]
   2e79a:	sub    rax,QWORD PTR [rbx+0xbb8]
   2e7a1:	jb     2f791 <XML_Parse+0x1521>
   2e7a7:	mov    rcx,rax
   2e7aa:	add    rcx,r14
   2e7ad:	jb     2f7a9 <XML_Parse+0x1539>
   2e7b3:	cmp    rcx,QWORD PTR [rbx+0xbb0]
   2e7ba:	ja     2f7c1 <XML_Parse+0x1551>
   2e7c0:	mov    r8,QWORD PTR [rbx+0xba0]
   2e7c7:	movabs rcx,0x8080808080808080
   2e7d1:	lea    rsi,[r8+rax*1]
   2e7d5:	xor    edi,edi
   2e7d7:	mov    rdx,r14
   2e7da:	sub    rdx,0xf
   2e7de:	cmovb  rdx,rdi
   2e7e2:	lea    rdi,[r8+rax*1]
   2e7e6:	add    rdi,0x7
   2e7ea:	and    rdi,0xfffffffffffffff8
   2e7ee:	sub    rdi,rsi
   2e7f1:	add    r8,rax
   2e7f4:	add    r8,0x8
   2e7f8:	lea    r9,[rip+0xfffffffffffdc346]        # ab45 <anon.6d978c0ff76fb7c7580bdf886695e467.208.llvm.4677468819421477425>
   2e7ff:	xor    eax,eax
   2e801:	jmp    2e81f <XML_Parse+0x5af>
   2e803:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   2e810:	inc    r11
   2e813:	mov    rax,r11
   2e816:	cmp    rax,r14
   2e819:	jae    2e9c9 <XML_Parse+0x759>
   2e81f:	movzx  r11d,BYTE PTR [rsi+rax*1]
   2e824:	test   r11b,r11b
   2e827:	js     2e880 <XML_Parse+0x610>
   2e829:	mov    r10d,edi
   2e82c:	sub    r10d,eax
   2e82f:	test   r10b,0x7
   2e833:	je     2e844 <XML_Parse+0x5d4>
   2e835:	inc    rax
   2e838:	jmp    2e816 <XML_Parse+0x5a6>
   2e83a:	nop    WORD PTR [rax+rax*1+0x0]
   2e840:	add    rax,0x10
   2e844:	cmp    rax,rdx
   2e847:	jae    2e857 <XML_Parse+0x5e7>
   2e849:	mov    r10,QWORD PTR [r8+rax*1]
   2e84d:	or     r10,QWORD PTR [r8+rax*1-0x8]
   2e852:	test   r10,rcx
   2e855:	je     2e840 <XML_Parse+0x5d0>
   2e857:	cmp    rax,r14
   2e85a:	jae    2e816 <XML_Parse+0x5a6>
   2e85c:	nop    DWORD PTR [rax+0x0]
   2e860:	cmp    BYTE PTR [rsi+rax*1],0x0
   2e864:	js     2e816 <XML_Parse+0x5a6>
   2e866:	inc    rax
   2e869:	cmp    r14,rax
   2e86c:	jne    2e860 <XML_Parse+0x5f0>
   2e86e:	jmp    2e9c9 <XML_Parse+0x759>
   2e873:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
   2e880:	movzx  ebp,BYTE PTR [r11+r9*1]
   2e885:	mov    r10d,0x101
   2e88b:	cmp    ebp,0x4
   2e88e:	je     2e8ea <XML_Parse+0x67a>
   2e890:	cmp    ebp,0x3
   2e893:	je     2e8bb <XML_Parse+0x64b>
   2e895:	cmp    ebp,0x2
   2e898:	jne    2eb10 <XML_Parse+0x8a0>
   2e89e:	lea    r11,[rax+0x1]
   2e8a2:	cmp    r11,r14
   2e8a5:	jae    2eb0d <XML_Parse+0x89d>
   2e8ab:	cmp    BYTE PTR [rsi+r11*1],0xbf
   2e8b0:	jle    2e810 <XML_Parse+0x5a0>
   2e8b6:	jmp    2eb10 <XML_Parse+0x8a0>
   2e8bb:	lea    r15,[rax+0x1]
   2e8bf:	cmp    r15,r14
   2e8c2:	jae    2eb0d <XML_Parse+0x89d>
   2e8c8:	movzx  ebp,BYTE PTR [rsi+r15*1]
   2e8cd:	cmp    r11,0xe0
   2e8d4:	je     2e919 <XML_Parse+0x6a9>
   2e8d6:	cmp    r11d,0xed
   2e8dd:	jne    2e937 <XML_Parse+0x6c7>
   2e8df:	cmp    bpl,0x9f
   2e8e3:	jle    2e959 <XML_Parse+0x6e9>
   2e8e5:	jmp    2eb10 <XML_Parse+0x8a0>
   2e8ea:	lea    r15,[rax+0x1]
   2e8ee:	cmp    r15,r14
   2e8f1:	jae    2eb0d <XML_Parse+0x89d>
   2e8f7:	movzx  ebp,BYTE PTR [rsi+r15*1]
   2e8fc:	cmp    r11,0xf0
   2e903:	je     2e928 <XML_Parse+0x6b8>
   2e905:	cmp    r11d,0xf4
   2e90c:	jne    2e976 <XML_Parse+0x706>
   2e90e:	cmp    bpl,0x8f
   2e912:	jle    2e98e <XML_Parse+0x71e>
   2e914:	jmp    2eb10 <XML_Parse+0x8a0>
   2e919:	and    bpl,0xe0
   2e91d:	cmp    bpl,0xa0
   2e921:	je     2e959 <XML_Parse+0x6e9>
   2e923:	jmp    2eb10 <XML_Parse+0x8a0>
   2e928:	add    bpl,0x70
   2e92c:	cmp    bpl,0x30
   2e930:	jb     2e98e <XML_Parse+0x71e>
   2e932:	jmp    2eb10 <XML_Parse+0x8a0>
   2e937:	lea    r15d,[r11+0x1f]
   2e93b:	cmp    r15b,0xc
   2e93f:	jb     2e94f <XML_Parse+0x6df>
   2e941:	and    r11b,0xfe
   2e945:	cmp    r11b,0xee
   2e949:	jne    2eb10 <XML_Parse+0x8a0>
   2e94f:	cmp    bpl,0xc0
   2e953:	jge    2eb10 <XML_Parse+0x8a0>
   2e959:	lea    r11,[rax+0x2]
   2e95d:	cmp    r11,r14
   2e960:	jae    2eb0d <XML_Parse+0x89d>
   2e966:	cmp    BYTE PTR [rsi+r11*1],0xbf
   2e96b:	jle    2e810 <XML_Parse+0x5a0>
   2e971:	jmp    2eb44 <XML_Parse+0x8d4>
   2e976:	add    r11b,0xf
   2e97a:	cmp    r11b,0x2
   2e97e:	ja     2eb10 <XML_Parse+0x8a0>
   2e984:	cmp    bpl,0xc0
   2e988:	jge    2eb10 <XML_Parse+0x8a0>
   2e98e:	lea    r10,[rax+0x2]
   2e992:	cmp    r10,r14
   2e995:	jae    2eb0d <XML_Parse+0x89d>
   2e99b:	cmp    BYTE PTR [rsi+r10*1],0xbf
   2e9a0:	jg     2eb44 <XML_Parse+0x8d4>
   2e9a6:	lea    r11,[rax+0x3]
   2e9aa:	cmp    r11,r14
   2e9ad:	jae    2eb0d <XML_Parse+0x89d>
   2e9b3:	cmp    BYTE PTR [rsi+r11*1],0xc0
   2e9b8:	jl     2e810 <XML_Parse+0x5a0>
   2e9be:	mov    r10d,0x301
   2e9c4:	jmp    2eb10 <XML_Parse+0x8a0>
   2e9c9:	cmp    QWORD PTR [rbx+0x638],r14
   2e9d0:	jb     2f7d9 <XML_Parse+0x1569>
   2e9d6:	mov    rdi,QWORD PTR [rbx+0x630]
   2e9dd:	mov    rdx,r14
   2e9e0:	call   QWORD PTR [rip+0xe584a]        # 114230 <memcpy@GLIBC_2.14>
   2e9e6:	mov    QWORD PTR [rbx+0x640],r14
   2e9ed:	mov    QWORD PTR [rbx+0x980],0x0
   2e9f8:	jmp    2e440 <XML_Parse+0x1d0>
