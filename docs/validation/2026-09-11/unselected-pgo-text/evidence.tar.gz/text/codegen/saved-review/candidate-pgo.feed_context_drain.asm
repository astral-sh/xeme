   2e62c:	mov    rax,QWORD PTR [rbx+0xbb8]
   2e633:	xor    ecx,ecx
   2e635:	sub    rbp,rax
   2e638:	cmovb  rbp,rcx
   2e63c:	mov    r15,rbp
   2e63f:	sub    r15,0x400
   2e646:	cmovb  r15,rcx
   2e64a:	mov    rdi,QWORD PTR [rbx+0xba0]
   2e651:	mov    r14,QWORD PTR [rbx+0xbb0]
   2e658:	mov    QWORD PTR [rbx+0xbb0],0x0
   2e663:	cmp    r14,r15
   2e666:	cmovb  r15,r14
   2e66a:	jbe    2ea18 <XML_Parse+0x7a8>
   2e670:	sub    r14,r15
   2e673:	cmp    rbp,0x400
   2e67a:	jbe    2e690 <XML_Parse+0x420>
   2e67c:	lea    rsi,[rdi+r15*1]
   2e680:	mov    rdx,r14
   2e683:	call   QWORD PTR [rip+0xe5ed7]        # 114560 <memmove@GLIBC_2.2.5>
   2e689:	mov    rax,QWORD PTR [rbx+0xbb8]
   2e690:	mov    QWORD PTR [rbx+0xbb0],r14
   2e697:	mov    rbp,QWORD PTR [rsp+0x18]
   2e69c:	lea    r12,[rbx+0xb80]
   2e6a3:	add    rax,r15
   2e6a6:	mov    QWORD PTR [rbx+0xbb8],rax
