   2e40f:	mov    BYTE PTR [rbx+0xac9],0x1
   2e416:	mov    BYTE PTR [rbx+0xbc0],0x1
   2e41d:	mov    DWORD PTR [rbx+0xacc],0x1
   2e427:	test   ebp,ebp
   2e429:	setne  BYTE PTR [rbx+0xad8]
   2e430:	mov    r14,QWORD PTR [rbx+0x980]
   2e437:	test   r14,r14
   2e43a:	jne    2e793 <XML_Parse+0x523>
   2e440:	mov    rdi,QWORD PTR [rbx+0x2c8]
