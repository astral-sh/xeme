   2e6fa:	add    rdi,r14
   2e6fd:	mov    r14,QWORD PTR [rsp+0x60]
   2e702:	mov    rsi,r14
   2e705:	mov    r12,QWORD PTR [rsp+0x18]
   2e70a:	mov    rdx,r12
   2e70d:	call   QWORD PTR [rip+0xe5b1d]        # 114230 <memcpy@GLIBC_2.14>
   2e713:	mov    QWORD PTR [rbx+0xbb0],r13
   2e71a:	lea    rdi,[rsp+0xa8]
   2e722:	mov    rsi,r15
   2e725:	mov    rdx,r14
   2e728:	mov    rcx,r12
   2e72b:	mov    r8d,ebp
   2e72e:	call   QWORD PTR [rip+0xe5ffc]        # 114730 <_DYNAMIC+0x720>
   2e734:	movzx  r14d,BYTE PTR [rsp+0xd8]
   2e73d:	cmp    r14d,0xff
   2e744:	jne    2f48e <XML_Parse+0x121e>
