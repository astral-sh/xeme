   8f5a5:	lea    rdx,[rax+0x1]
   8f5a9:	lock cmpxchg QWORD PTR [rbx+0x20],rdx
   8f5af:	jne    8f59c <oriole_expat::create+0x2ec>
   8f5b1:	lea    rdi,[rsp+0x120]
   8f5b9:	lea    rsi,[rsp+0xd60]
   8f5c1:	mov    edx,0x978
   8f5c6:	call   QWORD PTR [rip+0x84c64]        # 114230 <memcpy@GLIBC_2.14>
   8f5cc:	movups xmm0,XMMWORD PTR [rsp+0x20]
   8f5d1:	movups xmm1,XMMWORD PTR [rsp+0x30]
   8f5d6:	movups XMMWORD PTR [rsp+0xc30],xmm0
   8f5de:	movups XMMWORD PTR [rsp+0xc40],xmm1
