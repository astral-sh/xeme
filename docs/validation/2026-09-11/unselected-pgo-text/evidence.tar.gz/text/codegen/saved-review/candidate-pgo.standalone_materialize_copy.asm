   a52a6:	cmp    QWORD PTR [rdi+0x608],rbx
   a52ad:	jb     a5362 <<oriole::Parser>::materialize_current_raw_for_c_adapter+0x2f2>
   a52b3:	mov    rax,QWORD PTR [rdi+0x600]
   a52ba:	mov    r14,rdi
   a52bd:	mov    rdi,rax
   a52c0:	mov    rdx,rbx
   a52c3:	call   QWORD PTR [rip+0x6ef67]        # 114230 <memcpy@GLIBC_2.14>
   a52c9:	mov    QWORD PTR [r14+0x610],rbx
   a52d0:	mov    QWORD PTR [r14+0x950],0x0
   a52db:	jmp    a5086 <<oriole::Parser>::materialize_current_raw_for_c_adapter+0x16>
