   a5070:	push   rbp
   a5071:	push   r15
   a5073:	push   r14
   a5075:	push   rbx
   a5076:	sub    rsp,0x18
   a507a:	mov    rbx,QWORD PTR [rdi+0x950]
   a5081:	test   rbx,rbx
   a5084:	jne    a5091 <<oriole::Parser>::materialize_current_raw_for_c_adapter+0x21>
   a5086:	add    rsp,0x18
   a508a:	pop    rbx
   a508b:	pop    r14
   a508d:	pop    r15
   a508f:	pop    rbp
   a5090:	ret
   a5091:	mov    rax,QWORD PTR [rdi+0x958]
   a5098:	sub    rax,rcx
   a509b:	jb     a5317 <<oriole::Parser>::materialize_current_raw_for_c_adapter+0x2a7>
   a50a1:	mov    rcx,rax
   a50a4:	add    rcx,rbx
   a50a7:	jb     a5330 <<oriole::Parser>::materialize_current_raw_for_c_adapter+0x2c0>
   a50ad:	cmp    rcx,rdx
   a50b0:	ja     a5349 <<oriole::Parser>::materialize_current_raw_for_c_adapter+0x2d9>
