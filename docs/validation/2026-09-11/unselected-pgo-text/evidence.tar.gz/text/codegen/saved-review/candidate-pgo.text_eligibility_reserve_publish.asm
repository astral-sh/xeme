   402e9:	mov    rdx,QWORD PTR [rsp+0x860]
   402f1:	cmp    BYTE PTR [rdx+0x10],0x1
   402f5:	mov    edx,DWORD PTR [rsp+0x510]
   402fc:	mov    esi,DWORD PTR [rsp+0x513]
   40303:	mov    DWORD PTR [rsp+0x670],edx
   4030a:	mov    DWORD PTR [rsp+0x673],esi
   40311:	mov    edx,DWORD PTR [rsp+0x670]
   40318:	mov    esi,DWORD PTR [rsp+0x673]
   4031f:	mov    DWORD PTR [rsp+0x581],edx
   40326:	mov    DWORD PTR [rsp+0x584],esi
   4032d:	mov    QWORD PTR [rsp+0x550],rbp
   40335:	mov    QWORD PTR [rsp+0x558],rdi
   4033d:	mov    QWORD PTR [rsp+0x560],rax
   40345:	mov    QWORD PTR [rsp+0x568],rcx
   4034d:	movdqu XMMWORD PTR [rsp+0x570],xmm0
   40356:	mov    BYTE PTR [rsp+0x580],r15b
   4035e:	mov    cl,0x1
   40360:	mov    al,0x1
   40362:	jne    4036d <<oriole::Parser>::next_event_inner+0x1a9d>
   40364:	movzx  eax,BYTE PTR [r12+0x96a]
   4036d:	test   al,al
   4036f:	mov    esi,DWORD PTR [rsp+0x30]
   40373:	jne    4037e <<oriole::Parser>::next_event_inner+0x1aae>
   40375:	movzx  ecx,BYTE PTR [r12+0x96b]
   4037e:	mov    rax,QWORD PTR [r12+0x258]
   40386:	cmp    rax,0x1
   4038a:	setne  dl
   4038d:	test   cl,cl
   4038f:	jne    46e79 <<oriole::Parser>::next_event_inner+0x85a9>
   40395:	test   dl,dl
   40397:	jne    46adc <<oriole::Parser>::next_event_inner+0x820c>
   4039d:	mov    rcx,QWORD PTR [r12+0x248]
   403a5:	mov    eax,0x1
   403aa:	cmp    QWORD PTR [rcx+0x90],0x0
   403b2:	jne    46adc <<oriole::Parser>::next_event_inner+0x820c>
   403b8:	cmp    BYTE PTR [rcx+0x17c],0x0
   403bf:	jne    46adc <<oriole::Parser>::next_event_inner+0x820c>
   403c5:	movzx  edx,BYTE PTR [rcx]
   403c8:	or     dl,sil
   403cb:	jne    46adc <<oriole::Parser>::next_event_inner+0x820c>
   403d1:	mov    rbx,QWORD PTR [rcx+0x128]
   403d8:	mov    rdx,QWORD PTR [r12+0x610]
   403e0:	mov    rcx,r14
   403e3:	sub    rcx,rdx
   403e6:	mov    eax,0x0
   403eb:	cmovae rax,rcx
   403ef:	mov    rcx,QWORD PTR [r12+0x608]
   403f7:	mov    rsi,rcx
   403fa:	sub    rsi,rdx
   403fd:	cmp    rax,rsi
   40400:	ja     457be <<oriole::Parser>::next_event_inner+0x6eee>
   40406:	mov    QWORD PTR [r12+0x950],r14
   4040e:	mov    QWORD PTR [r12+0x958],rbx
   40416:	mov    BYTE PTR [r12+0x966],0x0
   4041f:	cmp    rbp,0xfffffffffffffffe
   40423:	jne    46bde <<oriole::Parser>::next_event_inner+0x830e>
   40429:	cmp    BYTE PTR [rsp+0x48],0x0
   4042e:	je     46eb4 <<oriole::Parser>::next_event_inner+0x85e4>
   40434:	mov    rax,QWORD PTR [rsp+0x60]
   40439:	test   rax,rax
   4043c:	je     58cfe <<oriole::Parser>::next_event_inner+0x1a42e>
