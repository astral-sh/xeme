   402a8:	mov    rdx,r14
   402ab:	mov    r14,QWORD PTR [rsp+0x60]
   402b0:	lea    rdi,[r14+0xe9]
   402b7:	call   QWORD PTR [rip+0xd3f73]        # 114230 <memcpy@GLIBC_2.14>
   402bd:	mov    ebx,0x4
   402c2:	cmp    DWORD PTR [r14+0x70],0x2
   402c7:	jbe    46f9b <<oriole::Parser>::next_event_inner+0x86cb>
   402cd:	mov    rax,QWORD PTR [rsp+0x60]
   402d2:	mov    QWORD PTR [rax+0x70],rbx
   402d6:	mov    r14,QWORD PTR [rsp+0x20]
   402db:	mov    QWORD PTR [rax+0xe0],r14
   402e2:	mov    rbp,0xfffffffffffffffe
