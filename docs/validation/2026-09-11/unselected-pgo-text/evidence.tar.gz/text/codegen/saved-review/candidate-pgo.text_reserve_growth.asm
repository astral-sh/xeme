   457be:	mov    r13,rbp
   457c1:	add    rax,rdx
   457c4:	jb     494b8 <<oriole::Parser>::next_event_inner+0xabe8>
   457ca:	lea    rdx,[rcx+rcx*1]
   457ce:	cmp    rax,rdx
   457d1:	cmova  rdx,rax
   457d5:	cmp    rdx,0x9
   457d9:	mov    r14d,0x8
   457df:	cmovae r14,rdx
   457e3:	mov    r8,r14
   457e6:	not    r8
   457e9:	shr    r8,0x3f
   457ed:	test   rcx,rcx
   457f0:	je     4cb4a <<oriole::Parser>::next_event_inner+0xe27a>
   457f6:	test   r14,r14
   457f9:	js     494b8 <<oriole::Parser>::next_event_inner+0xabe8>
   457ff:	mov    rax,QWORD PTR [rsp+0x10]
   45804:	mov    rsi,QWORD PTR [rax+0x600]
   4580b:	mov    bpl,0x1
   4580e:	mov    edx,0x1
   45813:	mov    rdi,QWORD PTR [rsp+0xa8]
   4581b:	mov    r9,r14
   4581e:	call   QWORD PTR [rip+0xceddc]        # 114600 <_DYNAMIC+0x5f0>
   45824:	test   rax,rax
   45827:	je     494b8 <<oriole::Parser>::next_event_inner+0xabe8>
   4582d:	mov    r12,QWORD PTR [rsp+0x10]
   45832:	mov    QWORD PTR [r12+0x600],rax
   4583a:	mov    QWORD PTR [r12+0x608],r14
   45842:	mov    r14,QWORD PTR [rsp+0x20]
   45847:	mov    rbp,r13
   4584a:	jmp    40406 <<oriole::Parser>::next_event_inner+0x1b36>
