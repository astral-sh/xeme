   ad405:	lea    rdi,[rsp+0x120]
   ad40d:	lea    rsi,[rsp+0xd50]
   ad415:	mov    edx,0x968
   ad41a:	call   QWORD PTR [rip+0x42098]        # ef4b8 <memcpy@GLIBC_2.14>
