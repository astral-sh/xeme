   720a1:	movaps XMMWORD PTR [rsp+0x100],xmm0
   720a9:	mov    al,0x1
   720ab:	mov    DWORD PTR [rsp+0x10],eax
   720af:	lea    rdi,[rsp+0x30]
   720b4:	mov    rsi,r14
   720b7:	mov    rdx,rbx
   720ba:	call   832d0 <<oriole::Parser>::save_current_raw>
   720bf:	cmp    BYTE PTR [rsp+0x60],0xff
   720c4:	je     7213b <<oriole::Parser>::parse_text+0xbeb>
   720c6:	mov    rax,QWORD PTR [rsp+0x60]
