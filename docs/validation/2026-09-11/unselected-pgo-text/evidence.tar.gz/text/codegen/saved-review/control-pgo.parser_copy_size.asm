   8e9f1:	lea    rdi,[rsp+0x120]
   8e9f9:	lea    rsi,[rsp+0xd50]
   8ea01:	mov    edx,0x968
   8ea06:	call   QWORD PTR [rip+0x86054]        # 114a60 <memcpy@GLIBC_2.14>
   8ea0c:	movups xmm0,XMMWORD PTR [rsp+0x20]
   8ea11:	movups xmm1,XMMWORD PTR [rsp+0x30]
   8ea16:	movups XMMWORD PTR [rsp+0xc20],xmm0
   8ea1e:	movups XMMWORD PTR [rsp+0xc30],xmm1
   8ea26:	movups XMMWORD PTR [rsp+0xc60],xmm0
   8ea2e:	movups XMMWORD PTR [rsp+0xc70],xmm1
