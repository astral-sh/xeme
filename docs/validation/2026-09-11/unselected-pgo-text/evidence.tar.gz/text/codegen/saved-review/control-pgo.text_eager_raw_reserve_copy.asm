   3f8b3:	mov    rdx,QWORD PTR [r12+0x610]
   3f8bb:	mov    rcx,QWORD PTR [rsp+0x20]
   3f8c0:	sub    rcx,rdx
   3f8c3:	mov    eax,0x0
   3f8c8:	cmovae rax,rcx
   3f8cc:	mov    rcx,QWORD PTR [r12+0x608]
   3f8d4:	mov    rsi,rcx
   3f8d7:	sub    rsi,rdx
   3f8da:	cmp    rax,rsi
   3f8dd:	mov    QWORD PTR [rsp+0x48],rbx
   3f8e2:	ja     44cfb <<oriole::Parser>::next_event_inner+0x6edb>
   3f8e8:	mov    r14,rcx
   3f8eb:	mov    QWORD PTR [r12+0x610],0x0
   3f8f7:	mov    rax,QWORD PTR [r12+0x258]
   3f8ff:	test   rax,rax
   3f902:	je     58f77 <<oriole::Parser>::next_event_inner+0x1b157>
   3f908:	mov    rcx,QWORD PTR [r12+0x248]
   3f910:	lea    rax,[rax+rax*2]
   3f914:	shl    rax,0x7
   3f918:	lea    r15,[rcx+rax*1]
   3f91c:	cmp    QWORD PTR [rcx+rax*1-0xf0],0x0
   3f925:	jne    461d1 <<oriole::Parser>::next_event_inner+0x83b1>
   3f92b:	mov    rax,QWORD PTR [r15-0x138]
   3f932:	mov    rsi,QWORD PTR [r15-0x128]
   3f939:	mov    rdx,QWORD PTR [r15-0x60]
   3f93d:	test   rdx,rdx
   3f940:	mov    r15,QWORD PTR [rsp+0x20]
   3f945:	je     3f95a <<oriole::Parser>::next_event_inner+0x1b3a>
   3f947:	cmp    rsi,rdx
   3f94a:	jbe    41b91 <<oriole::Parser>::next_event_inner+0x3d71>
   3f950:	cmp    BYTE PTR [rax+rdx*1],0xbf
   3f954:	jle    58a9c <<oriole::Parser>::next_event_inner+0x1ac7c>
   3f95a:	add    rax,rdx
   3f95d:	test   bpl,bpl
   3f960:	jne    3f979 <<oriole::Parser>::next_event_inner+0x1b59>
   3f962:	sub    rsi,rdx
   3f965:	cmp    r15,rsi
   3f968:	jae    40359 <<oriole::Parser>::next_event_inner+0x2539>
   3f96e:	cmp    BYTE PTR [rax+r15*1],0xbf
   3f973:	jle    5964e <<oriole::Parser>::next_event_inner+0x1b82e>
   3f979:	cmp    r15,r14
   3f97c:	ja     4637e <<oriole::Parser>::next_event_inner+0x855e>
   3f982:	mov    rdi,QWORD PTR [r12+0x600]
   3f98a:	mov    rsi,rax
   3f98d:	mov    rdx,r15
   3f990:	call   r13
   3f993:	mov    QWORD PTR [r12+0x610],r15
   3f99b:	mov    rdx,QWORD PTR [rsp+0x50]
   3f9a0:	mov    BYTE PTR [r12+0x956],0x0
