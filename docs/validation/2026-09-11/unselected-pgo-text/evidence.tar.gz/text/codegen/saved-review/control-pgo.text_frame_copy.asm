   3f7a0:	mov    r13,QWORD PTR [rip+0xd52b9]        # 114a60 <memcpy@GLIBC_2.14>
   3f7a7:	test   rbx,rbx
   3f7aa:	je     5a156 <<oriole::Parser>::next_event_inner+0x1c336>
   3f7b0:	mov    rax,QWORD PTR [r12+0x248]
   3f7b8:	lea    rdx,[rbx+rbx*2]
   3f7bc:	shl    rdx,0x7
   3f7c0:	mov    rsi,QWORD PTR [rax+rdx*1-0x138]
   3f7c8:	mov    rcx,QWORD PTR [rax+rdx*1-0x128]
   3f7d0:	mov    rdx,QWORD PTR [rax+rdx*1-0x60]
   3f7d5:	test   rdx,rdx
   3f7d8:	je     3f7ed <<oriole::Parser>::next_event_inner+0x19cd>
   3f7da:	cmp    rcx,rdx
   3f7dd:	jbe    42622 <<oriole::Parser>::next_event_inner+0x4802>
   3f7e3:	cmp    BYTE PTR [rsi+rdx*1],0xbf
   3f7e7:	jle    58008 <<oriole::Parser>::next_event_inner+0x1a1e8>
   3f7ed:	add    rsi,rdx
   3f7f0:	test   bpl,bpl
   3f7f3:	jne    3f811 <<oriole::Parser>::next_event_inner+0x19f1>
   3f7f5:	sub    rcx,rdx
   3f7f8:	cmp    r15,rcx
   3f7fb:	jb     40349 <<oriole::Parser>::next_event_inner+0x2529>
   3f801:	jne    58dd7 <<oriole::Parser>::next_event_inner+0x1afb7>
   3f807:	cmp    r15,0x18
   3f80b:	jae    43bf6 <<oriole::Parser>::next_event_inner+0x5dd6>
   3f811:	mov    r14,QWORD PTR [rsp+0x58]
   3f816:	lea    rdi,[r14+0xe9]
   3f81d:	mov    rdx,r15
   3f820:	call   r13
   3f823:	mov    ebx,0x4
   3f828:	cmp    DWORD PTR [r14+0x70],0x2
   3f82d:	jbe    46529 <<oriole::Parser>::next_event_inner+0x8709>
   3f833:	mov    rax,QWORD PTR [rsp+0x58]
   3f838:	mov    QWORD PTR [rax+0x70],rbx
   3f83c:	mov    QWORD PTR [rax+0xe0],r15
