"""Summarize only already-collected assembly/type records; never load a DSO."""
from pathlib import Path
import hashlib,json,re,os
assert os.sched_getaffinity(0)=={6}
R=Path(__file__).resolve().parent; A=R/'assembly-attempt01'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
c=load(A/'collection.json'); d=load(R/'test-layout-attempt01/layout.json')
assert c['status']=='collected_pending_manual_Text_raw_review'
assert len(c['commands'])==16 and all(r['exit']==0 for r in c['commands'])
assert d['status']=='passed_static_test_type_readback'
assert sha(R/'test-layout-attempt01/layout.json')=='f63063cf47b2cc0a1683cafd20f34eb356af5e4445ecce8bcc0c742392ed7440'
assert {(x['name'],x['bytes']) for x in d['type_sizes']}=={('Parser',2424),('NativeRawRange',16),('Option<oriole::NativeRawRange>',16)}
wanted={'<oriole::Parser>::next_event_inner','<oriole::Parser>::next_event_scoped','<oriole::Parser>::parse_text','<oriole::Parser>::next_delivery_into','<oriole::Parser>::next_event_for_adapter_into','<oriole::Parser>::next_event_for_c_adapter_into','<oriole::Parser>::next_adapter_event','oriole_expat::run_events','oriole_expat::create','XML_Parse','<oriole::NativeRawRange>::resolve','<oriole::Parser>::materialize_current_raw_for_c_adapter'}
# Half-open ranges; each is read from maintained objdump text, not disassembled again.
ranges={
 'control-normal':{'text_eager_call':(0x7209d,0x720cb),'parser_copy_size':(0xad405,0xad420)},
 'candidate-normal':{'c_sets_permission':(0xab366,0xab388),'adapter_forwards_permission':(0x91f91,0x91fb5),'text_eligibility_reserve':(0x7e9a7,0x7ea94),'text_eager_fallback':(0x7e855,0x7e874),'text_descriptor_publish':(0x7f050,0x7f08f),'feed_materialize_before_drain':(0xaae6a,0xaaf46),'parser_copy_size':(0xad785,0xad7a0)},
 'control-pgo':{'text_frame_copy':(0x3f7a0,0x3f843),'text_eager_raw_reserve_copy':(0x3f8b3,0x3f9a9),'parser_copy_size':(0x8e9f0,0x8ea30)},
 'candidate-pgo':{'adapter_sets_permission':(0x3be9a,0x3beb2),'adapter_calls_inner':(0x3bf08,0x3bf1d),'text_frame_copy':(0x402a8,0x402e9),'text_eligibility_reserve_publish':(0x402e9,0x40442),'text_reserve_growth':(0x457be,0x4584f),'feed_materialize_guard':(0x2e40f,0x2e447),'feed_context_drain':(0x2e62c,0x2e6ad),'feed_checked_materialize':(0x2e793,0x2e9fd),'feed_then_parse':(0x2e6fa,0x2e74a),'parser_copy_size':(0x8f5a0,0x8f5e0),'standalone_materialize_entry':(0xa5070,0xa50b6),'standalone_materialize_copy':(0xa52a6,0xa52e0)}
}
out=R/'saved-review';out.mkdir(exist_ok=False);table={};excerpts={}
for key in ranges:
 nm=A/(key+'.nm'); sec=A/(key+'.sections')
 expected={r['name']:r for r in c['commands']}
 assert sha(nm)==expected[key+'.nm']['stdout_sha256']
 assert sha(sec)==expected[key+'.sections']['stdout_sha256']
 syms={}
 for line in nm.read_text().splitlines():
  m=re.match(r'^([0-9a-f]+) ([0-9a-f]+) (\S) (.+)$',line)
  if m and m[4] in wanted:syms[int(m[1],16)]={'name':m[4],'bytes':int(m[2],16),'address':hex(int(m[1],16)),'prologue':[]}
 text=re.search(r'^\.text\s+(\d+)\s+(\d+)',sec.read_text(),re.M)
 captures={k:[] for k in ranges[key]}; pro={base:[] for base in syms}
 for line in (A/(key+'.asm')).open():
  m=re.match(r'\s+([0-9a-f]+):\s+(.+)',line)
  if not m:continue
  a=int(m[1],16)
  for k,(start,end) in ranges[key].items():
   if start<=a<end:captures[k].append(line)
  for base in pro:
   if base<=a<base+48:pro[base].append(line)
  if a>=max(max(end for start,end in ranges[key].values()),max(pro)+48):break
 for base,row in syms.items():
  row['prologue']=pro[base]
  # All leading explicit reservations, including stack-probe page reservations.
  row['explicit_stack_subtractions']=[int(m[1],16) for line in pro[base] if (m:=re.search(r'\bsub\s+rsp,0x([0-9a-f]+)',line))]
 for k,lines in captures.items():
  assert lines,(key,k)
  p=out/(key+'.'+k+'.asm');p.write_text(''.join(lines));excerpts[key+'.'+k]={'path':str(p),'sha256':sha(p),'range':[hex(v) for v in ranges[key][k]],'lines':len(lines),'source_assembly_sha256':expected[key+'.asm']['stdout_sha256']}
 table[key]={'text_bytes':int(text[1]),'text_address':hex(int(text[2])),'functions':list(syms.values())}
fields={}
for die in d['selected_dies']:
 if die['tag']=='DW_TAG_member' and die['parents'][-1].get('name') in ['Parser','NativeRawRange']:
  name=die['parents'][-1]['name'];fields.setdefault(name,{}).setdefault(die['name'],set()).add(die['member_offset'])
assert all(len(v)==1 for f in fields.values() for v in f.values())
report={'status':'passed_static_deferred_text_gate','scope':'Static saved evidence only. No parser/profiler/elapsed execution or performance prediction. Candidate remains unselected.','reader_sha256':sha(__file__),'collection_sha256':sha(A/'collection.json'),'release_sha256':sha(R/'released-inputs.json'),'layout_sha256':sha(R/'test-layout-attempt01/layout.json'),'source_manifest_sha256':d['source_manifest_sha256'],'libraries':c['libraries'],'type_layout':{'debug_test_sizes':{'Parser':2424,'NativeRawRange':16,'Option<NativeRawRange>':16},'unique_member_offsets':{n:{k:next(iter(v)) for k,v in f.items()} for n,f in fields.items()},'release_parser_copy_bytes':{'control':2408,'candidate':2424},'release_offsets':{'current_raw_start':1504,'raw_data_pointer':1536,'raw_capacity':1544,'raw_physical_length':1552,'range_length_and_niche':2384,'range_start':2392},'limitations':'Type sizes/offsets are actual test ELF DWARF, bound post-check to exact source. Release code corroborates raw/range offsets and Parser copy size; Rust layout is not a stable ABI. The C object places its core at +0x30.'},'table':table,'excerpts':excerpts,'findings':[
'Normal C run_events supplies true at ab37d; adapter preserves permission at91fb0. PGO specialized C entry supplies true at3beaa and calls the single inner body at3bf18.',
'Normal Text eligibility/reserve7e9a7..7ea8f retains physical String len/capacity and allocation/overflow failures before descriptor stores7f067/7f06e; eager fallback call7e860 remains. It does not copy raw bytes on eligible path.',
'PGO control native Text has retained frame copy3f820 and raw memcpy3f990. Candidate retains frame copy402b7, then eligible reserve403d8..40400 and stores40406/4040e; no equivalent raw copy is unconditionally moved into caller. Growth457be..4584a rejoins only after success.',
'Normal feed materialization checks active length, checked resolver and capacity, then memcpy aaeba, clears range aaec7, before context drain memmove aaf32. PGO active guard2e430 branches to checked bounds plus safe UTF8 validation2e793..2e9c9, capacity check2e9c9 then memcpy2e9e0 and clear2e9ed, before context drain2e683 and later core feed2e72e. Only the C feed path calls materialization in source; explicit Rust host seam remains callable. Existing eager fallback/raw/default callback copies are preserved.',
'No new duplicate parse_text or next_event_inner body appears in either release symbol table. Normal parse_text remains out of line and grows558B; PGO still inlines it into one next_event_inner, growing331B. Candidate adapter boundary consolidates old helper layout rather than adding a second hot parser. No inference about elapsed frontend cost.',
'Required safe validation and protocol checks add work: PGO XML_Parse grows1588B; PGO C adapter grows518B. Normal .text grows720B; PGO .text shrinks2464B. These totals include compiler/inlining/layout changes and cannot be assigned solely to removed copies.',
'Parser grows16B (2408 to2424); niche keeps Option at16B. Normal Text stack reservation grows16B, PGO C adapter grows32B, C create explicit reservations grow32B in both modes. Main inner/scoped and XML_Parse reservation sizes remain unchanged. run_events reservations shrink96B normal/16B PGO. Table records individual explicit subtractions; pushes and callees are excluded.'
]}
p=R/'report.json';p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'report_sha256':sha(p),'excerpts':len(excerpts),'status':report['status']}))
