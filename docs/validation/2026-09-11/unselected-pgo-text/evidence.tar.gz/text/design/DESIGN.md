# C-context deferred raw: Text-only design

Status: design only; no checkout edits or executions. Base: selected PR128 `78c748d9de5c497858458cbf7a1229148781b2bf`. Defer only the raw byte copy; retain callback Text ownership, the eager raw reservation and all accounting/publication order.

## Minimal protocol

Keep `Parser.current_raw: String`. Add one private `Option<NativeRawRange { start: usize, len: usize }>` alongside it. `None` means the String is authoritative (its empty value already expresses an empty override); `Some` means original C input bytes are authoritative and the String holds stale but valid UTF-8 plus reserved capacity. Do not keep a raw pointer or another String. This adds roughly 24 bytes on the current 64-bit target, subject to actual layout.

Add an explicit C adapter entry seam, separate from existing `next_event_for_adapter_into`, carrying a per-operation permission to defer (for example in EventOutput). Existing Rust and adapter entry points remain eager. Expose a C-protocol raw query (Owned/NativeRange), and a materialize operation that takes the checked UTF-8 range. The descriptor belongs to the core generation; reset constructs None, children construct None and do not inherit deferred raw. C must retain its context while a range is active. No descriptor is cleared merely because an event slot/frame is cleared or a call returns Err/None.

**API constraint:** `Parser::current_raw(&self)` cannot return bytes owned solely by CParser. The new seam must explicitly establish an exclusive host protocol: C readers use the new raw query, and the host materializes before handing the core to any ordinary Rust raw getter/event interface. It cannot silently make the old getter return stale bytes. CParser's private core can remain in this protocol between callbacks/operations, with materialization before feed/drain; a debug assertion in the old getter can catch misuse. If unchanged getter semantics are required even while the new C seam is active, this minimal external-storage design is insufficient: move ownership behind a wrapper that prevents ordinary access, or materialize before exposing that access. Do not advertise mixed-interface transparency.

Initial eligibility: ordinary `parse_text` character data only; explicit C seam; `!fragment`, `sources.len()==1`, native unanchored UTF-8 index, no conversions, and no external-subset/child source. Gate at the old raw-save point after successful Text/frame preparation. Root CR/CRLF may use the existing owned normalized Text fallback while the raw descriptor still names literal original bytes; restricting CR to eager for the first patch is optional scope reduction, not a semantic necessity. No CDATA, reference, prolog/default, DTD, markup, matched End, or general raw-save call gains deferred behavior.

## Publication and capacity proof

At the existing `parse_text` save point: compute the native start/count without mutating raw state; execute the identical `current_raw.try_reserve(count.saturating_sub(current_raw.len()))?`; then publish NativeRange instead of clearing/appending bytes. Reserve failure retains the previous owned/range spelling and leaves the prepared frame unpublished, as today. Subsequent declaration state, Text emit/frame publish, consume and error cleanup retain their present order. Ordinary Text still precedes a late accounting error; CDATA remains eager and preserves its different order.

Let L be stale owned length and C capacity, with L <= C. If count <= L, no reservation is needed and C >= count. Otherwise L + (count-L) = count, so success guarantees C >= count. The same proof applies to repeated deferred spans of different lengths. Reservation size/growth remains tied to the target count/capacity, not the logical previous range length. Logical raw readers must nevertheless use the range length, never L.

Materialize by checked range lookup and UTF-8 validation first; assert capacity >= range.len before changing anything; clear the owned String and append the validated bytes into its existing capacity; clear the range only after success. No allocation is possible under that invariant. An invalid range/capacity is an internal protocol defect: stop before altering raw state; never return stale String bytes as a fallback. Do not add unchecked set_len or an unsafe byte-to-str conversion.

## Exact raw writer inventory

All locations below are in the selected source. Initialization/reset/child construction additionally creates a fresh empty String and must set range None.

| Writer | Required range transition |
| --- | --- |
| `lib.rs:1807` pop_event, PendingEvent.raw | None override leaves state unchanged. Some(empty) clears String and range together. Some(owned) replaces both. Constructing a queued event/raw override does not yet change current raw. |
| `lib.rs:1817` save_current_raw | Existing eager reserve failure keeps range. At the existing String clear, invalidate range. Later alias decoding failure therefore leaves empty raw exactly as before. Native Text uses its separate reserve-and-defer path. |
| `lib.rs:2263` token.swap_decoded | Clear range after successful swap, before parsed? returns or events are exposed. Alias decode failure occurs before swap and preserves the previous range. Old String bytes moved to scratch may be stale: scratch is cleared before reuse, and capacity/allocator ownership stay intact. |
| `dtd.rs:358` finish_foreign_dtd NotStandalone | Explicit String clear also clears range. |
| `dtd/attlist.rs:178–181` attlist_raw | Decode/reserve failures before clear retain range. At clear, invalidate it before the already-reserved append/emit. |

`event_raw` and all PendingEvent raw constructors only create future overrides. No extra production `current_raw` writer was found by a full Rust-source search. Wrap transitions narrowly or add adjacent explicit resets; avoid a generalized raw-storage refactor.

## Exact C reader and lifecycle changes

Three production readers in `crates/oriole_expat/src/lib.rs` must use one checked resolver: dispatch's default/declaration callback-byte length at line634, `dispatch_unhandled` at1064, and `XML_DefaultCurrent` at1961. Length query is allocation-free and uses descriptor.len. Both callback paths retain their current selected-allocator owned copy and queue behavior, including DefaultCurrent's copy even when its callback option is absent, attlist empty fallback, and recursive-default guard. No context slice survives into a callback.

Lookup uses absolute start.checked_sub(input_context_start), then checked slice bounds; C's stored event/error position is not the descriptor. Do not round-trip through XML_GetInputContext/c_int. UTF-8 origin guarantees identity, but bounds and safe UTF-8 validation protect the host seam.

Materialize **before preserve_input_context can drain or append and before core.feed**. Put it inside the existing guarded/caught XML_Parse body, immediately before preserve_input_context, after unchanged request/accounting checks. Invalid requests that return earlier leave the old range intact. Source.consume compaction needs no materialization because C context is independent. No additional context retention, capacity or memory-limit changes are required.

ParseBuffer already funnels through XML_Parse after copying from its distinct writable buffer. Resume does not feed/drain, so may keep the range; Stop/abort also retain it. Reset/free may discard it with the old core/context, after their existing guards. Materialize before explicitly leaving the new host protocol or exposing ordinary raw access; doing so at every finish_operation is a simpler optional policy, but can add an avoidable last-span copy, particularly on suspension. Never carry the range into a replacement generation or use it in an external child.

Pending owned/empty raw and malformed-token publication outrank a preceding native range. No early blanket invalidation on error: partial ordinary Text can publish a range and then return before its stored accounting error. Namespace cleanup/default queues retain the established raw semantics. Current event position can be an interior error, reference anchor, or zero-length synthetic End, so it never authorizes a new range.

## Borrow and failure boundaries

Only a temporary disjoint borrow of C input_context and mutable core is needed for materialization. Allocator callbacks cannot reenter; materialization itself must not allocate. Raw readers borrow context only to make an independent owned copy, release all parser/context borrows, then call C. Event Text remains independently owned. Busy guards still reject same-parser feed/GetBuffer/reset/free; allowed setters, child work and DefaultCurrent remain supported. Handler absence is never eligibility: a later callback may install a default handler.

Retain eager reserve position, Text/raw owner drop order, callback/work charges, existing pending/error cleanup and original limits. No new OOM can first occur at materialization. More general claims of bit-identical allocator traces require current tests: scratch-owner exchanges preserve capacities but are outside this Text-only optimization's copying change.

## Meaningful tests before any selection

- Differential eager/new C-seam traces of events, exact logical raw, position and final error across native Text lengths 0/1/23/24/4096/4097/64KiB, several deferred spans with increasing/decreasing lengths, CR/LF/CRLF and partial trailing CR/brackets. Confirm ordinary Rust/old adapter remain eager.
- Force Text/frame allocation failure, eager raw reserve failure, and error immediately after deferred publication. Assert prior logical raw survives where expected; ordinary Text/accounting prefix differs from CDATA exactly as before.
- Install an allocator that rejects every later allocation after a successful reserve: materialization before next direct/ParseBuffer feed must allocate zero times. Check capacity, bytes, live balance and no callback while borrowing.
- Override each writer above after an active range, including empty implicit End, malformed complete markup/alias failure, pending raw inheritance, ATTLIST fragments and NotStandalone clear. Compare raw after terminal errors and across every feed boundary.
- Default handler absent/installed/replaced within callbacks; DefaultCurrent nested rejection, owned bytes live through setters; stop/resume/abort, ignored busy free/reset/reparse and callback-time child parsing. Check default queues exactly once.
- Cross Source compaction and C-context discard separately; failed feed/reservation, empty feed, reset and stale frame/child generation. UTF16, custom aliases, internal/external entities and CDATA must prove eager fallback; no same-index range from another source.

## Prior art and extension boundary

The earlier `/tmp/oriole-text-current-raw-design/DESIGN.md` proposed unimplemented lazy decoded-Source ranges, with compaction materialization and an old Wayland gross 3.439% instruction ceiling; it was unselected. Text-span reuse and native-tag execution experiments retained raw copies and were rejected on PGO performance. They do not measure this C-context seam. Current sampled token-buffer regions are not a removable-cost estimate.

Matched End stays out: its lexical token append plus token/current String rotation affects allocation failure and scratch capacities. A later extension must separately preserve append-before-detachment, full malformed raw, swap-on-error and empty-End semantics; Text-only success cannot authorize it. No speedup or implementation pass is claimed by this design.
