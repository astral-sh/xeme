# Deferred C Text raw-copy prototype

Unselected source prototype, based on Finder PR128 `78c748d9de5c497858458cbf7a1229148781b2bf`. No rejected compact-status code is included. The frozen patch is `source-attempt01.patch`; `source-attempt01.json` pins all 70 source files and the exact seven-file delta. No parser, compiler, test, profile or elapsed benchmark has run. Root-authorized Cargo formatting passed twice, before and after the final test edit; all creation/format outcomes are retained.

## Runtime change

The C adapter explicitly calls `next_event_for_c_adapter_into`. Only ordinary root character Text with a single unanchored native UTF-8 source and no conversions can retain a `NativeRawRange`. Its private nonzero length supplies an Option niche; actual Parser size/codegen effects are unmeasured. Callback Text remains independently owned. The old raw String remains in its original field/drop order and reserves at the old save point using its physical length. No allocation, counter, limit or public C ABI is added.

The host resolves raw against checked original-context bounds and safe UTF-8 before making the existing selected-allocator callback copy. No context borrow survives a callback. The dispatch accounting reader uses the logical raw length. `XML_DefaultCurrent` still copies even when no default handler is installed and retains its old empty-ATTLIST and recursive-default behavior.

`XML_Parse` materializes inside the existing caught operation, after every old early guard/accounting step and immediately before `preserve_input_context` can drain or append. Materialization validates range, UTF-8 and existing capacity before clearing/copying, and clears the descriptor only after the copy succeeds. It cannot allocate under the reservation invariant. ParseBuffer delegates to this path; resume and stop retain context. Reset/free discard the old generation and context together.

Ordinary `current_raw`, feed, owned event paths and the old adapter entry point unconditionally reject an unmaterialized descriptor. The new documented seam is an exclusive host protocol, not mixed-interface transparency. Allowed setters and child construction remain available; children start without a descriptor. There are no unchecked conversions, raw pointers, inline hints, allocator changes, counter changes or source-compaction hooks.

## Writer/order audit

| Existing writer | Descriptor transition |
| --- | --- |
| Pending raw override | None inherits. Some(empty/owned) invalidates at the same replacement; queue construction does not publish. |
| Eager save_current_raw | Reserve failure preserves old state; clear invalidates before alias decoding/append. |
| Successful token.swap_decoded | Invalidate immediately after success, before parsed error/event publication; failed decode preserves old descriptor. |
| Foreign DTD NotStandalone | Existing String clear also invalidates. |
| ATTLIST raw | Decode/reserve precede mutation; String clear invalidates before append/emit. |

Text/frame preparation still precedes raw reservation. Declaration state, pending/frame publication, consume/accounting and error cleanup remain afterward, including successful Text prefixes with a stored terminal error. CDATA/reference/prolog/DTD/markup/End/conversion/internal-source/external-child paths retain eager raw storage.

## Meaningful validation prepared, not executed

- New core tests: release ordinary-interface rejection; bad bounds/UTF-8 retain prior state; explicit materialization and child independence; failing native/eager raw growth preserves active range; custom-map/child eager fallbacks; real consecutive 64/128KiB/short Text spans across Source compaction; pending inheritance/empty/owned overrides; reference save and malformed complete-token publication; ordinary Text versus CDATA late-accounting order; NotStandalone clear.
- ATTLIST unit test uses a real continuation and verifies its raw fragment invalidates an active descriptor.
- Existing adapter collector retains all prior event/position/raw/error comparisons. Its new C-host mode adds differential native/BOM/UTF-16, lengths 0/1/23/24/4096/4097/64KiB, varied chunks, CR/LF/brackets, references/internal entities, malformed tokens and prolog/epilog cases.
- Allocation test derives the Text frame/raw allocation points from a successful pass, then fails each one and checks prior raw/unpublished frame/terminal retry and selected-allocator balance. A successful raw reservation followed by rejection of every later allocation verifies materialization makes zero allocation calls.
- Existing C suspension assertion keeps exact raw bytes through the checked resolver. The test now includes default initially absent and installs it inside the first Text callback before DefaultCurrent, preserving setter/busy-free/reset/reparse/live-pointer/suspend/resume assertions.
- New C fail-next suite verifies direct and ParseBuffer materialize before context drain+append OOM, including old raw outside the retained window, unchanged callbacks, exact first allocation and zero live tracked bytes after free. An explicit materialization subcase keeps the failure flag armed and proves no allocation call.

After independent source review, proposed CPU3 checks use the established clean Ohm environment with trust variables unset, unique target and shared verified build directory: fmt-check; core unit plus text_coalescing/diagnostics/encodings/raw_tokens/positions/event_output/adapter_frame/allocation tests; all C adapter unit tests and existing memory integration tests; strict all-target Clippy for core and C adapter. Keep first outcomes and fix only diagnosed failures. Build/codegen/performance gates require a later release; no speedup is predicted.
