"""Bind already-completed checks and source; no build or parser execution."""
from pathlib import Path
import gzip,hashlib,io,json,re,tarfile
S=Path(__file__).resolve().parent;O=Path('/tmp/oriole-deferred-c-text-raw-pgo-study');W=Path('/home/dev-user/code/oss/oriole-deferred-c-text-raw')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
source=load(O/'source.json');checks=load(S/'checks-attempt02/results.json')
assert sha(O/'source.json')=='dfa4fb42c7c6601d402d06adc17a4d0efa1208f57cd11658df65d9bb25c74009'
assert checks['status']=='passed' and checks['source_unchanged'] and checks['source_manifest_sha256']==sha(O/'source.json')
assert [(row['label'],row['exit']) for row in checks['commands']]==[('fmt',0),('core',0),('c-adapter',0),('clippy',0)]
assert all(sha(W/n)==h for n,h in source['source_sha256'].items())
assert not (O/'source-checks.json').exists()
for row in checks['commands']:
 for stream in ['stdout','stderr']:
  p=S/'checks-attempt02'/f"{row['label']}.{stream}";assert sha(p)==row[stream+'_sha256']
  q=O/'source-checks'/p.name;q.parent.mkdir(exist_ok=True);q.write_bytes(p.read_bytes())
(O/'source-checks.json').write_bytes((S/'checks-attempt02/results.json').read_bytes())
(O/'source-checks-controller.py').write_bytes((S/'checks-attempt02.py').read_bytes())
for name in ['independent-source-review.json','independent-source-review-attempt02.json','source-attempt01.json','source-attempt01.patch','attempt02-only.patch']:
 (O/name).write_bytes((S/name).read_bytes())
# Preserve the first failed check rather than transferring the successful rerun backward.
for name in ['results.json','core.stdout','core.stderr','fmt.stdout','fmt.stderr']:
 q=O/'source-checks-attempt01'/name;q.parent.mkdir(exist_ok=True);q.write_bytes((S/'checks-attempt01'/name).read_bytes())
with (O/'source.tar.gz').open('wb') as file:
 with gzip.GzipFile(filename='',mode='wb',fileobj=file,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as archive:
   for name in sorted(source['source_sha256']):
    raw=(W/name).read_bytes();item=tarfile.TarInfo(name);item.size=len(raw);item.mode=0o644;item.mtime=0;archive.addfile(item,io.BytesIO(raw))
with tarfile.open(O/'source.tar.gz') as archive:
 archived={m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive}
assert archived==source['source_sha256']
(O/'README.md').write_text('''# Deferred C Text raw build study — prepared, unexecuted

Selected Finder PR12878c is the source base. The exact reviewed seven-file Text
prototype delta is pinned in source.json and source-delta.json; source.tar.gz
reads back to all70 source hashes. source-checks.json binds passed formatting,
126 core tests,97 C unit tests,3 memory tests and strict core+C all-target Clippy.
The first new test-oracle failure and its test/comment-only correction remain
separate. No runtime token change followed the independent source review.

The three build/proof/freeze controllers are adapted from compact-delivery-status,
but source and controls are selected Finder, not that rejected implementation.
All six external tools/pgo files are exact Git144 historical helpers matching
Finder pins. Current production/PBS helpers remain untouched. No additive G+R or
B training code is present. Normal/generate/use keep O3 ThinLTO/cgu1, explicit
host, original toolchain, limits, fresh generated-only profiles,288 parses per
phase (864 records), and all9 complete compiler vectors. Metadata is retained;
only the existing private paths/artifact suffix normalization remains.

Builds have not run. Root must separately release CPU3 build_pair.py, then saved
prove_pair.py/freeze_pair.py and independent artifact review. Native templates
are /tmp/oriole-deferred-c-text-raw-{normal,pgo}-native-study; they preserve the
fixed28condition/7pair protocol and byte-identical runner, but candidate library
paths/hashes are placeholders until matched build proof/freeze. No elapsed or
compatibility outcome transfers from a previous experiment.
''')
files={p.relative_to(O).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(O.rglob('*')) if p.is_file()}
report={'status':'prepared_and_bound_awaiting_root_execution_release','source_manifest_sha256':sha(O/'source.json'),'source_archive_sha256':sha(O/'source.tar.gz'),'source_checks_sha256':sha(O/'source-checks.json'),'independent_source_reviews':[sha(O/'independent-source-review.json'),sha(O/'independent-source-review-attempt02.json')],'adapter_preparation_sha256':sha(O/'adapter-preparation.json'),'files':files,'file_count':len(files),'source_archive_readback_files':len(archived),'native_template_preparation':load(S/'native-template-preparation.json'),'generator_sha256':sha(__file__),'targets_executed_by_preparation':False}
(O/'preparation-freeze.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(O/'preparation-freeze.json'),'sha256':sha(O/'preparation-freeze.json'),'files':len(files),'source_checks':sha(O/'source-checks.json'),'source_archive':sha(O/'source.tar.gz')}))
