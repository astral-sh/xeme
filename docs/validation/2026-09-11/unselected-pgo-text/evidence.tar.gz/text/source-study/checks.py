"""Run reviewed deferred C Text raw checks only after root releases CPU3."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

S=Path(__file__).resolve().parent
W=Path('/home/dev-user/code/oss/oriole-deferred-c-text-raw')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
PYTHON=Path('/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12')
assert sha(PYTHON)=='021044895e95be79dc2f110367607e684119afbc8ce75f6f0eec94844e0acec7'
import sys
assert Path(sys.executable).resolve()==PYTHON.resolve()
assert sha(S/'source-attempt01.json')=='dee0dab3374f33325375940d8b14d1f286efa44dfd3638712aab2e17e7680cdb'
source=json.loads((S/'source-attempt01.json').read_text())['source_sha256']
assert os.sched_getaffinity(0)=={3} and all(sha(W/n)==h for n,h in source.items())
assert not any(k.startswith('CARGO_PROFILE_') for k in os.environ)
env=os.environ.copy()
for key in ['RUSTC','RUSTFLAGS','LLVM_PROFILE_FILE','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST']:
    env.pop(key,None)
overrides={'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/targets/deferred-c-text-raw','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_ENCODED_RUSTFLAGS':'','RUSTUP_AUTO_INSTALL':'0','CARGO_TERM_COLOR':'never'}
env.update(overrides)
base=['cargo','+ohm','-Zohm-defaults=no']
commands=[('fmt',base+['fmt','--all','--','--check'],60),
          ('core',base+['test','-p','oriole','--lib','--test','text_coalescing','--test','diagnostics','--test','encodings','--test','raw_tokens','--test','positions','--test','event_output','--test','adapter_frame','--test','allocation','--locked','--offline'],600),
          ('c-adapter',base+['test','-p','oriole_expat','--lib','--test','memory','--locked','--offline'],600),
          ('clippy',base+['clippy','-p','oriole','-p','oriole_expat','--all-targets','--locked','--offline','--','-D','warnings'],600)]
out=S/'checks-attempt01';out.mkdir(exist_ok=False)
report={'status':'incomplete','source_manifest_sha256':sha(S/'source-attempt01.json'),'commands':[],'environment_overrides':overrides,'scope':'Reviewed core unit plus text/error/encoding/raw/position/event/frame/allocation tests, C adapter unit and memory integration tests, strict core+C all-target Clippy and fmt-check. No target execution at preparation; no full API/PGO/performance claim.'}
def save():
    (out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
try:
    for label,argv,bound in commands:
        row={'label':label,'argv':argv,'cpu':3,'timeout':bound,'start':time.time()};report['commands'].append(row);save();p=None
        with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
            try:
                p=subprocess.Popen(argv,cwd=W,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
                row['exit']=p.wait(timeout=bound)
                if row['exit']:raise RuntimeError(label+' failed')
            except BaseException as error:
                row['exception']=repr(error)
                if p is not None:
                    try:os.killpg(p.pid,signal.SIGKILL)
                    except ProcessLookupError:pass
                    row['exit']=p.wait()
                raise
            finally:
                stdout.flush();stderr.flush();row['end']=time.time()
                row['stdout_sha256']=sha(out/(label+'.stdout'));row['stderr_sha256']=sha(out/(label+'.stderr'));save()
        print(label,row['exit'],flush=True)
    report['status']='passed'
finally:
    report['source_unchanged']=all(sha(W/n)==h for n,h in source.items());save()
assert report['source_unchanged']
