from pathlib import Path
import hashlib,json,os,subprocess,time
study=Path(__file__).resolve().parent
source=Path('/home/dev-user/code/oss/oriole-cdata-finder')
destination=Path('/home/dev-user/code/oss/oriole-deferred-c-text-raw')
base='78c748d9de5c497858458cbf7a1229148781b2bf'
def git(*args): return subprocess.check_output(['git',*args],cwd=source,text=True).strip()
assert source.resolve()==source and not destination.exists()
assert git('rev-parse','--show-toplevel')==str(source)
assert git('rev-parse','--path-format=absolute','--git-common-dir')=='/home/dev-user/code/oss/oriole/.git'
assert git('config','user.email')=='charlie.r.marsh@gmail.com'
assert git('rev-parse','HEAD')==base
assert git('status','--porcelain')==''
env=os.environ.copy()
for key in ['RUSTC','RUSTFLAGS','LLVM_PROFILE_FILE','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST']: env.pop(key,None)
assert not any(k.startswith('CARGO_PROFILE_') for k in env)
overrides={'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/targets/cdata-finder','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_ENCODED_RUSTFLAGS':'','RUSTUP_AUTO_INSTALL':'0','CARGO_TERM_COLOR':'never'}
env.update(overrides)
command=['taskset','-c','6','cargo','+ohm','-Zohm-defaults=yes','worktree','add','-b','charlie/codex-oriole-deferred-c-text-raw','--target-dir','/home/dev-user/.cache/oriole/targets/deferred-c-text-raw',str(destination),base]
prefix=study/('worktree-creation-attempt%02d'%(len(list(study.glob('worktree-creation-attempt*.json')))+1))
record={'source':str(source),'destination':str(destination),'base':base,'common_git_dir':git('rev-parse','--path-format=absolute','--git-common-dir'),'git_email':git('config','user.email'),'command':command,'environment_overrides':overrides,'started':time.time()}
prefix.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
with prefix.with_suffix('.stdout').open('w') as stdout,prefix.with_suffix('.stderr').open('w') as stderr:
 result=subprocess.run(command,cwd=source,env=env,stdout=stdout,stderr=stderr,timeout=600)
record.update(exit=result.returncode,completed=time.time())
for suffix in ['stdout','stderr']:record[suffix+'_sha256']=hashlib.sha256(prefix.with_suffix('.'+suffix).read_bytes()).hexdigest()
prefix.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2)); print(prefix.with_suffix('.stderr').read_text())
raise SystemExit(result.returncode)
