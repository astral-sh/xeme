from pathlib import Path
root=Path('/home/dev-user/code/oss/oriole-deferred-c-text-raw')
p=root/'crates/oriole/src/lib.rs';s=p.read_text()
def change(old,new):
 global s
 assert s.count(old)==1,old[:100]
 s=s.replace(old,new)
change('use std::fmt;','use std::fmt;\nuse std::num::NonZeroUsize;')
change("    frame: Option<&'a mut AdapterFrame>,\n}","    frame: Option<&'a mut AdapterFrame>,\n    defer_native_raw: bool,\n}\n\n/// Original host bytes for a nonempty native Text token. The nonzero length\n/// keeps the optional descriptor to two words without another parser owner.\n#[derive(Clone, Copy, Debug)]\nstruct NativeRawRange {\n    start: usize,\n    len: NonZeroUsize,\n}\n\nimpl NativeRawRange {\n    /// Resolve only within the host's retained original UTF-8 input. Protocol\n    /// violations fail before publication or callbacks, including in release.\n    fn resolve(self, input: &[u8], input_start: usize) -> &str {\n        let start = self.start.checked_sub(input_start).expect(\n            \"C adapter discarded deferred raw input\",\n        );\n        let end = start.checked_add(self.len.get()).expect(\n            \"C adapter raw range overflow\",\n        );\n        let bytes = input.get(start..end).expect(\n            \"C adapter did not retain deferred raw input\",\n        );\n        std::str::from_utf8(bytes).expect(\"C adapter raw input is not UTF-8\")\n    }\n}")
change('    current_raw: String,','    current_raw: String,\n    native_raw: Option<NativeRawRange>,')
change('            current_raw: String::new_in(allocator),','            current_raw: String::new_in(allocator),\n            native_raw: None,')
change('    pub fn feed(&mut self, bytes: &[u8], is_final: bool) -> Result<(), Error> {','    pub fn feed(&mut self, bytes: &[u8], is_final: bool) -> Result<(), Error> {\n        self.assert_owned_raw();')
change('''    fn next_event_into(&mut self, output: &mut Option<Event>) -> Result<(), Error> {
        self.next_delivery_into(&mut EventOutput {
            event: output,
            frame: None,
        })
    }''','''    fn next_event_into(&mut self, output: &mut Option<Event>) -> Result<(), Error> {
        self.assert_owned_raw();
        self.next_delivery_into(&mut EventOutput {
            event: output,
            frame: None,
            defer_native_raw: false,
        })
    }''')
change('''    ) -> Result<Option<RecyclingToken>, Error> {
        *event = None;
        frame.clear();
        if !self.event_recycling.accepts(&frame.generation) {
            return self.next_event_for_recycling_into(event);
        }
        self.next_delivery_into(&mut EventOutput {
            event,
            frame: Some(frame),
        })?;
        Ok((event.is_some() || frame.active).then(|| self.event_recycling.token()))
    }''','''    ) -> Result<Option<RecyclingToken>, Error> {
        self.assert_owned_raw();
        self.next_adapter_event(event, frame, false)
    }

    /// Fill detached slots under an exclusive C-host raw-input protocol.
    ///
    /// The host must retain its original input while a native raw range is active,
    /// use the C-adapter raw readers, and materialize before feeding, discarding
    /// input, or returning to an ordinary raw/event interface. Ordinary interfaces
    /// panic on an unmaterialized range in release builds too. Setters and child
    /// operations remain available; children start with independent owned raw.
    #[doc(hidden)]
    pub fn next_event_for_c_adapter_into(
        &mut self,
        event: &mut Option<Event>,
        frame: &mut AdapterFrame,
    ) -> Result<Option<RecyclingToken>, Error> {
        self.next_adapter_event(event, frame, true)
    }

    /// Share slot clearing and generation checks without enabling deferred raw
    /// for the existing Rust adapter interface.
    fn next_adapter_event(
        &mut self,
        event: &mut Option<Event>,
        frame: &mut AdapterFrame,
        defer_native_raw: bool,
    ) -> Result<Option<RecyclingToken>, Error> {
        *event = None;
        frame.clear();
        let accepted = self.event_recycling.accepts(&frame.generation);
        self.next_delivery_into(&mut EventOutput {
            event,
            frame: accepted.then_some(&mut *frame),
            defer_native_raw,
        })?;
        Ok((event.is_some() || frame.active).then(|| self.event_recycling.token()))
    }''')
change('''    pub fn current_raw(&self) -> Option<&str> {
        (!self.current_raw.is_empty()).then_some(self.current_raw.as_str())
    }''','''    pub fn current_raw(&self) -> Option<&str> {
        self.assert_owned_raw();
        (!self.current_raw.is_empty()).then_some(self.current_raw.as_str())
    }

    /// Reject ordinary raw/event access until the C host restores owned bytes.
    fn assert_owned_raw(&self) {
        assert!(self.native_raw.is_none(), "C adapter must materialize current raw input");
    }

    /// Resolve logical raw bytes under [`Self::next_event_for_c_adapter_into`]'s
    /// host protocol. The host must copy this borrow before invoking callbacks.
    /// Invalid context bounds or UTF-8 panic without returning stale owned bytes.
    #[doc(hidden)]
    #[must_use]
    pub fn current_raw_for_c_adapter<'a>(
        &'a self,
        input: &'a [u8],
        input_start: usize,
    ) -> Option<&'a str> {
        match self.native_raw {
            Some(range) => Some(range.resolve(input, input_start)),
            None => self.current_raw(),
        }
    }

    /// Return the logical raw length without resolving or allocating host bytes.
    #[doc(hidden)]
    #[must_use]
    pub fn current_raw_len_for_c_adapter(&self) -> usize {
        self.native_raw.map_or(self.current_raw.len(), |range| range.len.get())
    }

    /// Restore owned raw bytes before host input changes or ordinary access.
    /// Bounds, UTF-8 and the eager reservation are checked before mutation. The
    /// reserved capacity makes the copy allocation-free; failure is a host bug.
    #[doc(hidden)]
    pub fn materialize_current_raw_for_c_adapter(&mut self, input: &[u8], input_start: usize) {
        let Some(range) = self.native_raw else {
            return;
        };
        let raw = range.resolve(input, input_start);
        assert!(self.current_raw.capacity() >= raw.len(), "missing C adapter raw reservation");
        self.current_raw.clear();
        self.current_raw.try_push_str(raw).expect("reserved C adapter raw capacity");
        self.native_raw = None;
    }''')
change('''        if let Some(raw) = pending.raw {
            if raw.is_empty() {''','''        if let Some(raw) = pending.raw {
            self.native_raw = None;
            if raw.is_empty() {''')
change('''        self.current_raw.clear();
        let source = self''','''        self.current_raw.clear();
        self.native_raw = None;
        let source = self''')
change('''    fn event_raw(&mut self, raw: &str) -> Result<(), Error> {''','''    /// Reserve at the ordinary Text raw-save point, deferring only the copy.
    /// Stale owned length intentionally controls the unchanged reserve request.
    fn save_text_raw(&mut self, count: usize, defer_native_raw: bool) -> Result<(), Error> {
        if defer_native_raw
            && !self.fragment
            && !self.external_subset
            && self.sources.len() == 1
            && !self.source().has_conversions()
            && let Some(start) = self.source().native_utf8_byte_index()
            && let Some(len) = NonZeroUsize::new(count)
        {
            self.current_raw
                .try_reserve(count.saturating_sub(self.current_raw.len()))?;
            self.native_raw = Some(NativeRawRange { start, len });
            Ok(())
        } else {
            self.save_current_raw(count)
        }
    }

    fn event_raw(&mut self, raw: &str) -> Result<(), Error> {''')
change('''            token.swap_decoded(&mut self.current_raw)?;
            parsed?;''','''            token.swap_decoded(&mut self.current_raw)?;
            self.native_raw = None;
            parsed?;''')
change('''        self.save_current_raw(end)?;
        self.declaration_allowed = false;''','''        self.save_text_raw(end, character_data && output.defer_native_raw)?;
        self.declaration_allowed = false;''')
p.write_text(s)
for name in ['crates/oriole/src/dtd.rs','crates/oriole/src/dtd/attlist.rs']:
 p=root/name;s=p.read_text();assert s.count('self.current_raw.clear();')==1
 s=s.replace('self.current_raw.clear();','self.current_raw.clear();\n'+(' '*16 if name.endswith('dtd.rs') else ' '*8)+'self.native_raw = None;');p.write_text(s)
p=root/'crates/oriole_expat/src/lib.rs';s=p.read_text()
s=s.replace('(*parser).core.current_raw().map_or(0, str::len)','(*parser).core.current_raw_len_for_c_adapter()')
assert s.count('''let raw = (*parser)
                .core
                .current_raw()''')==1
s=s.replace('''let raw = (*parser)
                .core
                .current_raw()''','''let raw = current_raw_for_c_adapter(&*parser)''')
assert s.count('''let raw = (*parser)
                    .core
                    .current_raw()''')==1
s=s.replace('''let raw = (*parser)
                    .core
                    .current_raw()''','''let raw = current_raw_for_c_adapter(&*parser)''')
s=s.replace('.next_event_for_adapter_into(&mut event, frame)','.next_event_for_c_adapter_into(&mut event, frame)')
old='''                if preserve_input_context(parser, input).is_err() {'''
assert s.count(old)==1
s=s.replace(old,'''                (*parser).core.materialize_current_raw_for_c_adapter(
                    &(*parser).input_context,
                    (*parser).input_context_start,
                );
'''+old)
old='''unsafe fn dispatch_unhandled('''
assert s.count(old)==1
s=s.replace(old,'''/// Resolve raw spelling without retaining a context borrow across callbacks.
/// Callers first copy it into their existing selected-allocator owner.
fn current_raw_for_c_adapter(parser: &XML_ParserStruct) -> Option<&str> {
    parser.core.current_raw_for_c_adapter(
        &parser.input_context,
        parser.input_context_start,
    )
}

'''+old)
p.write_text(s)
p=root/'crates/oriole_expat/src/tests.rs';s=p.read_text();old='assert_eq!((*parser).core.current_raw(), Some(content.as_str()));';assert s.count(old)==1;s=s.replace(old,'assert_eq!(current_raw_for_c_adapter(&*parser), Some(content.as_str()));');p.write_text(s)
