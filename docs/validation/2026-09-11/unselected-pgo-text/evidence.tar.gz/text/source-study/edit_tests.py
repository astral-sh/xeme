from pathlib import Path
r=Path('/home/dev-user/code/oss/oriole-deferred-c-text-raw')
p=r/'crates/oriole/tests/adapter_frame.rs';s=p.read_text()
old='''    adapter: bool,
) -> (std::vec::Vec<std::string::String>, usize) {
    let mut parser = Parser::new(config);'''
new='''    adapter: bool,
) -> (std::vec::Vec<std::string::String>, usize) {
    collect_with_raw_protocol(input, chunk, config, adapter, false)
}

fn collect_with_raw_protocol(
    input: &[u8],
    chunk: usize,
    config: Config,
    adapter: bool,
    c_host: bool,
) -> (std::vec::Vec<std::string::String>, usize) {
    let mut parser = Parser::new(config);
    let raw = |parser: &Parser| {
        if c_host {
            parser.current_raw_for_c_adapter(input, 0).map(str::to_owned)
        } else {
            parser.current_raw().map(str::to_owned)
        }
    };'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('''    'input: for (index, data) in input.chunks(chunk).enumerate() {
        if let Err(error)''','''    'input: for (index, data) in input.chunks(chunk).enumerate() {
        if c_host {
            parser.materialize_current_raw_for_c_adapter(&input[..index * chunk], 0);
        }
        if let Err(error)''',1)
s=s.replace('''            let result = if adapter {
                parser.next_event_for_adapter_into''','''            let result = if c_host {
                parser.next_event_for_c_adapter_into(&mut event, &mut frame)
            } else if adapter {
                parser.next_event_for_adapter_into''',1)
# Keep all old comparisons, including exact raw bytes, using the selected protocol.
prefix,rest=s.split('\n#[test]',1);prefix=prefix.replace('parser.current_raw()));','raw(&parser)));');s=prefix+'\n#[test]'+rest
s+='''
#[test]
fn deferred_c_raw_matches_eager_events_errors_positions_and_spelling() {
    for count in [0, 1, 23, 24, 4096, 4097, 65_536] {
        let text = "x".repeat(count);
        // Consecutive spans change size without an intervening markup owner swap.
        let xml = format!("\\u{feff}<r>{text}\\r\\nsmall&amp;{text}<![CDATA[raw]]>é😀</r>");
        let utf16 = [0xfeff]
            .into_iter()
            .chain(xml.trim_start_matches('\\u{feff}').encode_utf16())
            .flat_map(u16::to_le_bytes)
            .collect::<std::vec::Vec<_>>();
        for input in [xml.as_bytes(), utf16.as_slice()] {
            for chunk in [1, 23, 4096, input.len()] {
                if count > 4097 && chunk == 1 {
                    continue;
                }
                for namespace_separator in [None, Some('|')] {
                    let config = Config { namespace_separator, ..Config::default() };
                    assert_eq!(
                        collect(input, chunk, config.clone(), true),
                        collect_with_raw_protocol(input, chunk, config, true, true),
                        "count={count}, chunk={chunk}, namespace={namespace_separator:?}"
                    );
                }
            }
        }
    }
    for input in [
        "<r>before\\r\\nafter\\0</r>",
        "<r>before\\ninvalid]]></r>",
        "<r>text</wrong>",
        "<r>text<n a='1' a='2'/>",
        "<!DOCTYPE r [<!ENTITY e 'inner'>]><r>before&e;after</r>",
        " \\r\\n<r/> \\n",
    ] {
        for chunk in 1..=input.len() {
            assert_eq!(
                collect(input.as_bytes(), chunk, Config::default(), true),
                collect_with_raw_protocol(input.as_bytes(), chunk, Config::default(), true, true),
                "input={input:?}, chunk={chunk}"
            );
        }
    }
}
'''
p.write_text(s)
p=r/'crates/oriole/src/lib.rs';s=p.read_text();s+='''
#[cfg(test)]
mod deferred_raw_tests {
    use super::*;
    use std::panic::{AssertUnwindSafe, catch_unwind};

    fn text_parser(input: &[u8]) -> (Parser, AdapterFrame) {
        let mut parser = Parser::new(Config::default());
        parser.feed(input, false).unwrap();
        let mut frame = parser.adapter_frame();
        let mut event = None;
        parser.next_event_for_c_adapter_into(&mut event, &mut frame).unwrap().unwrap();
        assert!(frame.is_active());
        parser.next_event_for_c_adapter_into(&mut event, &mut frame).unwrap().unwrap();
        assert!(parser.native_raw.is_some());
        (parser, frame)
    }

    #[test]
    fn host_protocol_rejects_stale_access_and_materializes_before_ordinary_use() {
        let input = b"<r>native text";
        let (mut parser, mut frame) = text_parser(input);
        assert_eq!(parser.current_raw.as_str(), "<r>");
        assert_eq!(parser.current_raw_len_for_c_adapter(), 11);
        assert_eq!(parser.current_raw_for_c_adapter(input, 0), Some("native text"));
        assert!(catch_unwind(AssertUnwindSafe(|| parser.current_raw())).is_err());
        assert!(catch_unwind(AssertUnwindSafe(|| parser.next_event())).is_err());
        assert!(catch_unwind(AssertUnwindSafe(|| parser.feed(b"</r>", true))).is_err());
        let mut event = None;
        assert!(catch_unwind(AssertUnwindSafe(|| {
            parser.next_event_for_adapter_into(&mut event, &mut frame)
        })).is_err());
        // Bounds/UTF-8 defects are rejected before touching the last raw owner.
        for (bytes, start) in [(b"".as_slice(), 0), (input.as_slice(), 4), (b"<r>\\xffative text".as_slice(), 0)] {
            assert!(catch_unwind(AssertUnwindSafe(|| {
                parser.materialize_current_raw_for_c_adapter(bytes, start);
            })).is_err());
            assert_eq!(parser.current_raw_for_c_adapter(input, 0), Some("native text"));
            assert_eq!(parser.current_raw.as_str(), "<r>");
        }
        let child = parser.external_child(Some(""), None).unwrap();
        assert!(child.native_raw.is_none());
        assert_eq!(child.current_raw(), None);
        let capacity = parser.current_raw.capacity();
        parser.materialize_current_raw_for_c_adapter(input, 0);
        assert_eq!(parser.current_raw.capacity(), capacity);
        assert_eq!(parser.current_raw(), Some("native text"));
        parser.feed(b"</r>", true).unwrap();
        while parser.next_event().unwrap().is_some() {}
        parser.finish_adapter_frame(frame);
    }

    #[test]
    fn repeated_deferred_spans_keep_the_eager_reservation_and_logical_raw() {
        let mut parser = Parser::new(Config::default());
        parser.current_raw.try_push_str("old owned spelling").unwrap();
        // Directly exercise reservation across consecutive native spans without
        // a markup swap, including a short span following a long one.
        for count in [1, 24, 4096, 23, 4097, 1] {
            let before = parser.current_raw.len();
            parser.save_text_raw(count, true).unwrap();
            assert_eq!(parser.current_raw.len(), before);
            assert!(parser.current_raw.capacity() >= count);
            assert_eq!(parser.current_raw_len_for_c_adapter(), count);
            assert_eq!(parser.native_raw.unwrap().len.get(), count);
        }
        parser.materialize_current_raw_for_c_adapter(b"x", 0);
        assert_eq!(parser.current_raw(), Some("x"));
        assert_eq!(size_of::<Option<NativeRawRange>>(), 2 * size_of::<usize>());
    }

    #[test]
    fn pending_overrides_and_eager_writers_replace_deferred_spelling() {
        let input = b"<r>text";
        for replacement in [None, Some(""), Some("owned")] {
            let (mut parser, frame) = text_parser(input);
            parser.emit(EventKind::Default, parser.position()).unwrap();
            if let Some(raw) = replacement {
                parser.event_raw(raw).unwrap();
            }
            assert_eq!(parser.current_raw_for_c_adapter(input, 0), Some("text"));
            parser.pop_event().unwrap();
            assert_eq!(parser.current_raw_for_c_adapter(input, 0), match replacement {
                None => Some("text"), Some("") => None, Some(raw) => Some(raw),
            });
            assert_eq!(parser.native_raw.is_some(), replacement.is_none());
            parser.finish_adapter_frame(frame);
        }
        let input = b"<r>text&amp;after</wrong>";
        let (mut parser, mut frame) = text_parser(input);
        let mut event = None;
        // Reference uses save_current_raw; complete malformed markup swaps raw
        // before its error. Neither may expose the earlier native descriptor.
        parser.next_event_for_c_adapter_into(&mut event, &mut frame).unwrap().unwrap();
        assert!(parser.native_raw.is_none());
        assert_eq!(parser.current_raw(), Some("&amp;"));
        parser.next_event_for_c_adapter_into(&mut event, &mut frame).unwrap().unwrap();
        assert_eq!(parser.current_raw_for_c_adapter(input, 0), Some("after"));
        let error = parser.next_event_for_c_adapter_into(&mut event, &mut frame).unwrap_err();
        assert_eq!(error.kind, ErrorKind::TagMismatch);
        assert_eq!(parser.current_raw(), Some("</wrong>"));
        assert!(event.is_none() && !frame.is_active());
        parser.finish_adapter_frame(frame);
    }

    #[test]
    fn ordinary_text_still_publishes_before_late_accounting_error() {
        for cdata in [false, true] {
            let input = if cdata { b"<r><![CDATA[abc]]>".as_slice() } else { b"<r>abc".as_slice() };
            let mut parser = Parser::new(Config::default());
            parser.feed(input, false).unwrap();
            parser.next_event().unwrap().unwrap();
            if cdata {
                assert!(matches!(parser.next_event().unwrap().unwrap().kind, EventKind::StartCdata));
            }
            assert!(parser.expanded.account(1000, true, false));
            parser.expanded.set_factor(1.0);
            parser.expanded.set_threshold(0);
            let mut frame = parser.adapter_frame();
            let mut event = None;
            let result = parser.next_event_for_c_adapter_into(&mut event, &mut frame);
            if cdata {
                assert_eq!(result.unwrap_err().kind, ErrorKind::LimitExceeded);
                assert!(parser.native_raw.is_none());
                assert!(event.is_none() && !frame.is_active());
            } else {
                assert!(result.unwrap().is_some());
                assert_eq!(frame.text_bytes(), Some(b"abc".as_slice()));
                assert!(parser.native_raw.is_some() && parser.error.is_some());
                assert_eq!(parser.current_raw_for_c_adapter(input, 0), Some("abc"));
                assert_eq!(parser.next_event_for_c_adapter_into(&mut event, &mut frame).unwrap_err().kind, ErrorKind::LimitExceeded);
                assert_eq!(parser.current_raw_for_c_adapter(input, 0), Some("abc"));
                assert!(event.is_none() && !frame.is_active());
            }
            parser.finish_adapter_frame(frame);
        }
    }

    #[test]
    fn not_standalone_clear_invalidates_an_existing_native_override() {
        let mut parser = Parser::new(Config::default());
        parser.set_param_entity_parsing(2);
        parser.start_foreign_dtd(Position::default()).unwrap();
        parser.pop_event().unwrap();
        parser.shared_parameter_state().unwrap().read.store(true, Ordering::Relaxed);
        parser.save_text_raw(3, true).unwrap();
        assert!(parser.native_raw.is_some());
        assert!(matches!(parser.finish_foreign_dtd().unwrap().kind, EventKind::NotStandalone));
        assert!(parser.native_raw.is_none());
        assert_eq!(parser.current_raw(), None);
    }
}
''';p.write_text(s)
