from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/home/dev-user/code/oss/oriole-deferred-c-text-raw'); study=Path(__file__).resolve().parent
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='78c748d9de5c497858458cbf7a1229148781b2bf'
env=os.environ.copy()
for k in ['RUSTC','RUSTFLAGS','LLVM_PROFILE_FILE','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST']:env.pop(k,None)
assert not any(k.startswith('CARGO_PROFILE_') for k in env)
overrides={'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/targets/deferred-c-text-raw','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_ENCODED_RUSTFLAGS':'','RUSTUP_AUTO_INSTALL':'0','CARGO_TERM_COLOR':'never'}
env.update(overrides)
command=['taskset','-c','6','cargo','+ohm','-Zohm-defaults=no','fmt','--all']
prefix=study/'fmt-attempt02';assert not prefix.with_suffix('.json').exists()
record={'command':command,'environment_overrides':overrides,'started':time.time(),'scope':'root-released formatting only; no compilation/tests'}
with prefix.with_suffix('.stdout').open('w') as out,prefix.with_suffix('.stderr').open('w') as err:
 result=subprocess.run(command,cwd=root,env=env,stdout=out,stderr=err,timeout=120)
record.update(exit=result.returncode,completed=time.time())
for stream in ['stdout','stderr']:record[stream+'_sha256']=hashlib.sha256(prefix.with_suffix('.'+stream).read_bytes()).hexdigest()
prefix.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
raise SystemExit(result.returncode)
