from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/dev-user/code/oss/oriole-deferred-c-text-raw');study=Path(__file__).resolve().parent
base='78c748d9de5c497858458cbf7a1229148781b2bf'
def git(*args): return subprocess.check_output(['git',*args],cwd=root)
d=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==base
assert git('config','user.email').decode().strip()=='charlie.r.marsh@gmail.com'
keys=sorted(json.loads(Path('/tmp/oriole-cdata-finder-study/source.json').read_text())['source_sha256']);assert len(keys)==70
before={p:d(git('show',base+':'+p)) for p in keys};after={p:d((root/p).read_bytes()) for p in keys}
changed=sorted(p for p in keys if before[p]!=after[p]);expected=sorted(['crates/oriole/src/lib.rs','crates/oriole/src/dtd.rs','crates/oriole/src/dtd/attlist.rs','crates/oriole/tests/adapter_frame.rs','crates/oriole/tests/allocation.rs','crates/oriole_expat/src/lib.rs','crates/oriole_expat/src/tests.rs']);assert changed==expected,changed
assert sorted(git('diff','--name-only').decode().splitlines())==expected
assert not git('ls-files','--others','--exclude-standard')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
patch=git('diff','--binary',base);(study/'source-attempt01.patch').write_bytes(patch)
record={'status':'source_frozen_for_review_no_tests_or_builds','base_commit':base,'worktree':str(root),'branch':git('branch','--show-current').decode().strip(),'common_git_dir':git('rev-parse','--path-format=absolute','--git-common-dir').decode().strip(),'base_source_sha256':before,'source_sha256':after,'changed_files':changed,'patch_sha256':d(patch),'format_attempts':{p.name:d(p.read_bytes()) for p in sorted(study.glob('fmt-attempt*.json'))},'design_sha256':d(Path('/tmp/oriole-c-context-deferred-text-design/DESIGN.md').read_bytes()),'independent_design_review_sha256':d(Path('/tmp/oriole-c-context-deferred-text-independent-review.json').read_bytes()),'parser_test_build_executions':0}
p=study/'source-attempt01.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'source':str(p),'source_sha256':d(p.read_bytes()),'patch_sha256':d(patch),'files':len(after),'changed':changed}))
