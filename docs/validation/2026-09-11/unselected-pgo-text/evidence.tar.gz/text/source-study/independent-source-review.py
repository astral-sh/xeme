"""Bind the independent source-only review; never runs parser/compiler targets."""
import hashlib,json,subprocess
from pathlib import Path
P=Path('/tmp/oriole-deferred-c-text-raw-study');W=Path('/home/dev-user/code/oss/oriole-deferred-c-text-raw')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=json.loads((P/'source-attempt01.json').read_text())
assert sha(P/'source-attempt01.json')=='dee0dab3374f33325375940d8b14d1f286efa44dfd3638712aab2e17e7680cdb'
assert sha(P/'source-attempt01.patch')==source['patch_sha256']=='f3bdf0402f90a77f6b48642b778a05dcbe93a23c979884bc2ff1eb5e5e06c6a6'
assert source['base_commit']=='78c748d9de5c497858458cbf7a1229148781b2bf'
assert len(source['source_sha256'])==len(source['base_source_sha256'])==70
assert source['base_source_sha256']==json.loads(Path('/tmp/oriole-cdata-finder-pgo-study/source.json').read_text())['source_sha256']
assert all(sha(W/n)==h for n,h in source['source_sha256'].items())
changed=sorted(n for n,h in source['source_sha256'].items() if h!=source['base_source_sha256'][n]);assert changed==source['changed_files'] and len(changed)==7
patch=subprocess.check_output(['git','diff',source['base_commit'],'--',*source['source_sha256']],cwd=W)
assert patch==(P/'source-attempt01.patch').read_bytes()
refs=[Path('/tmp/oriole-c-context-deferred-text-design/DESIGN.md'),Path('/tmp/oriole-c-context-deferred-text-independent-review.json'),Path('/tmp/oriole-deferred-c-text-raw-test-helper-review.json'),P/'REVIEW.md',P/'checks.py']
report={
 'status':'passed_source_only_no_runtime_blocker',
 'scope':'Independent source inspection of frozen Text-only deferred C raw prototype. No source edits, parser/compiler/tests, layout probe, codegen or elapsed execution by reviewer. Root launched focused checks separately while review finished; their outcomes are outside this receipt.',
 'base':source['base_commit'],'worktree':str(W),'source_manifest_sha256':sha(P/'source-attempt01.json'),'patch_sha256':sha(P/'source-attempt01.patch'),'source_files_verified':70,'unchanged_files':63,'changed_files':changed,
 'source_sha256':source['source_sha256'],
 'checks':[
  'NativeRawRange stores only absolute start and NonZeroUsize length: no pointers, owners, allocator or unsafe conversion. Optional niche is available; actual Option/Parser layout remains unmeasured, so this review does not establish a 16-byte ABI/layout promise.',
  'Unconditional owned-raw checks protect feed, current_raw, all ordinary owned/recycling event routes through next_event_into, and old adapter entry. New C seam alone passes defer permission. Existing foreign-generation fallback still clears detached slots and emits owned events; C permission survives that fallback intentionally.',
  'Eligibility is ordinary character Text at the former save point, !fragment, !external_subset, exactly one source, no conversions, native UTF8 with no anchor, nonzero length. Prolog, CDATA, references, general markup and internal/external sources remain eager. Native UTF8 BOM offsets use original raw_index; CR/CRLF spelling remains literal original bytes while callback text keeps its existing normalization.',
  'All five raw writer sites covered: pending None inherits while Some(empty/owned) replaces; eager save reserve precedes clear/invalidation; token swap invalidates only after successful swap and before parsed?; foreign NotStandalone clear invalidates; ATTLIST decode/reserve precede clear/invalidation. Error/pending/frame cleanup does not blanket-clear an active descriptor.',
  'For stale physical String length L and capacity C, L<=C. reserve(count.saturating_sub(L)) grows iff count>C and then requests count, exactly the former target capacity. The existing raw reserve remains after Text/frame preparation and before declaration/publication/consume. Allocation failure retains prior raw descriptor/owner. Scratch swap retains capacity/allocator/drop order; its stale byte length is cleared before reuse.',
  'Materialization checked-subtracts absolute context start, checked-adds length, bounds-checks and safely validates UTF8, then asserts capacity before any mutation. clear+try_push_str fits reserved capacity; descriptor clears only after append. No allocation is needed under the invariant, including repeated larger/smaller spans.',
  'All three C readers use logical length or checked resolver. Default fallback and XML_DefaultCurrent retain their existing selected-allocator owned copies, queue behavior and absent-handler/empty-ATTLIST/recursive-default behavior. No raw context or mutable parser borrow crosses user callbacks.',
  'XML_Parse materializes inside the catch/busy scope after unchanged argument/state/terminal/quota/family/tracker guards and immediately before preserve_input_context. Thus even context drain followed by append OOM leaves prior raw owned. GetBuffer only changes separate writable storage; ParseBuffer delegates to XML_Parse; resume does not drain/feed.',
  'Reset creates replacement core with None before replacing old core then clearing context; failed reset preserves old state. Free drops core/context together. Children allocate fresh core with None, set fragment true and do not copy parent raw. Source compaction affects only decoded buffer, not retained C context or absolute descriptor.',
  'Prepared tests retain exact suspended Text raw assertion via resolver; add absent-to-present default installation, meaningful no-allocation materialization and drain+OOM checks, selected allocator balance, bad bounds/UTF8 release guards, repeated spans/compaction, pending overrides, malformed-token publication, native/BOM/UTF16/custom/entity fallbacks and ordinary Text versus CDATA late accounting behavior. No assertion was weakened in the reviewed patch.'
 ],
 'blockers':[],
 'nonblocking_findings':[
  {'file':'crates/oriole_expat/src/lib.rs','line':1270,'kind':'stale_safety_comment','detail':'dispatch_text_frame fallback comment still says the core owns raw independently. The implementation now resolves raw from either core-owned or retained-context bytes and makes an owned callback copy. Update wording in a later source attempt; no behavior or release blocker.'}
 ],
 'limits':['Source correctness only; focused checks were not yet reviewed here.','Per-parser descriptor changes memory layout/allocated size; no exact allocator schedule or throughput equivalence is claimed. Token raw growth/callback copy ordering is preserved by source reasoning.','Exclusive host contract is explicit; arbitrary safe Rust callers supplying different retained bytes can violate semantics, but checked access cannot create an invalid reference. Ordinary mixed-interface transparency is intentionally not promised.'],
 'references_sha256':{str(p):sha(p) for p in refs},'reader_sha256':sha(__file__)
}
out=P/'independent-source-review.json';out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'path':str(out),'sha256':sha(out),'blockers':[]},indent=2))
