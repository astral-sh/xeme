"""Prepare matched generated-only build controllers; execute no target."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
S=Path(__file__).resolve().parent
W=Path('/home/dev-user/code/oss/oriole-deferred-c-text-raw')
O=Path('/tmp/oriole-deferred-c-text-raw-pgo-study')
A=Path('/tmp/oriole-compact-delivery-status-pgo-study')
B=Path('/tmp/oriole-cdata-finder-pgo-study')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
assert sha(S/'source-attempt02.json')=='dfa4fb42c7c6601d402d06adc17a4d0efa1208f57cd11658df65d9bb25c74009'
source=load(S/'source-attempt02.json');assert all(sha(W/n)==h for n,h in source['source_sha256'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==source['base_commit']=='78c748d9de5c497858458cbf7a1229148781b2bf'
O.mkdir(exist_ok=False)
pins=load(B/'tool-source.json');assert len(pins)==6
for name,h in pins.items():
 p=A/'pipeline'/name;assert sha(p)==h
 out=O/'pipeline'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
for name in ['LICENSE-APACHE','LICENSE-MIT']:
 (O/'pipeline'/name).write_bytes((A/'pipeline'/name).read_bytes())
(O/'tool-source.json').write_bytes((B/'tool-source.json').read_bytes())
(O/'source.json').write_bytes((S/'source-attempt02.json').read_bytes())
(O/'source.patch').write_bytes((S/'source-attempt02.patch').read_bytes())
# Only candidate paths/caption and the exact reviewed runtime-file set change.
replacements=[('/home/dev-user/code/oss/oriole-compact-delivery-status',str(W)),('/home/dev-user/.cache/oriole/targets/compact-delivery-status','/home/dev-user/.cache/oriole/targets/deferred-c-text-raw'),('Compact private scoped-delivery status on selected Finder78c748d9.','Deferred native root Text raw copy under the exclusive C-host protocol on selected Finder78c748d9.'),('next_hotspot authored the compact-status source; current_pbs_review prepared the external-pipeline adapters.','next_hotspot authored the deferred C Text source and prepared these external-pipeline adapters.')]
files={};diff=''
for name in ['build_pair.py','prove_pair.py','freeze_pair.py']:
 original=(A/name).read_text();text=original
 for before,after in replacements:text=text.replace(before,after)
 if name=='prove_pair.py':
  old="assert delta['runtime_changed_files']==['crates/oriole/src/lib.rs']"
  new="assert delta['runtime_changed_files']==['crates/oriole/src/dtd.rs', 'crates/oriole/src/dtd/attlist.rs', 'crates/oriole/src/lib.rs', 'crates/oriole_expat/src/lib.rs']"
  assert old in text;text=text.replace(old,new)
 ast.parse(text,filename=name);(O/name).write_text(text);files[name]=sha(O/name)
 diff+=''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='compact/'+name,tofile='deferred-c-text/'+name))
(O/'controller-adaptation.patch').write_text(diff)
old=(A/'prove_pair.py').read_text();new=(O/'prove_pair.py').read_text()
for start,end in [('def normalize(args, run):','details ='),("for phase in ('normal','generate','use'):",'source=load(')]:
 assert old.split(start,1)[1].split(end,1)[0]==new.split(start,1)[1].split(end,1)[0]
normal="cmd=['cargo','+ohm','-Zohm-defaults=no','rustc','--release','--locked','--offline','--target',host,'-p','oriole_expat','--lib','--crate-type','cdylib,staticlib','--verbose']"
assert normal in (O/'build_pair.py').read_text()
prior=load(B/'source.json')['source_sha256'];assert prior.keys()==source['source_sha256'].keys()
changed=sorted(n for n,h in source['source_sha256'].items() if h!=prior[n]);assert changed==source['changed_files']
runtime=['crates/oriole/src/dtd.rs','crates/oriole/src/dtd/attlist.rs','crates/oriole/src/lib.rs','crates/oriole_expat/src/lib.rs']
delta={'status':'reviewed','source_manifest_sha256':sha(O/'source.json'),'control_source_manifest_sha256':sha(B/'source.json'),'changed_files':changed,'runtime_changed_files':runtime,'pipeline_source_changed_files':changed,'test_only_files':sorted(set(changed)-set(runtime)),'independent_source_review_sha256':sha(S/'independent-source-review.json'),'independent_attempt02_review_sha256':sha(S/'independent-source-review-attempt02.json'),'scope':'Source review only; successful exact-source checks must be bound separately before any build.'}
(O/'source-delta.json').write_text(json.dumps(delta,indent=2)+'\n')
assert not any((O/n).exists() for n in ['source-checks.json','source.tar.gz','pair-report.json','pgo','normal'])
report={'status':'prepared_awaiting_completed_checks_and_final_binding','base_commit':source['base_commit'],'worktree':str(W),'source_manifest_sha256':sha(O/'source.json'),'control':str(B),'control_pair_sha256':sha(B/'pair-report.json'),'control_source_sha256':sha(B/'source.json'),'control_normal_sha256':'195add2e0efba2f7dacc57efc06788d58212e4572bcf83097937fe57dc5f9aa7','control_pgo_sha256':'82bdf9b9a3b1c26b089ab9ef28bc0207ec386bfa86a2f43736f379b9fa93ab93','pipeline_origin':str(A/'pipeline'),'pipeline_commit':'144e69e08c5462217d54791374e579e3ef390a87','pipeline_sha256':pins,'controllers':files,'controller_adaptation_sha256':sha(O/'controller-adaptation.patch'),'generator_sha256':sha(__file__),'mechanics':{'normal_command_unchanged':True,'compiler_normalization_unchanged':True,'vector_and_training_comparison_unchanged':True,'metadata_retained':True,'workspace_vectors':9,'generated_rows_per_phase':288,'generated_rows_total':864,'C_only_O3_ThinLTO_cgu1_explicit_host':True,'fresh_profile':True,'B_training_composed':False},'source_checks_pending':True,'targets_executed':False}
(O/'adapter-preparation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'path':str(O),'preparation_sha256':sha(O/'adapter-preparation.json'),'controller_adaptation_sha256':sha(O/'controller-adaptation.patch'),'controllers':files}))
