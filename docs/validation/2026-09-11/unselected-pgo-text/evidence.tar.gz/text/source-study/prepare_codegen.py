"""Prepare static Text raw-copy comparison; execute no inspection tool."""
from pathlib import Path
import ast,difflib,hashlib,json
A=Path('/tmp/oriole-compact-delivery-status-codegen-study');O=Path('/tmp/oriole-deferred-c-text-raw-codegen-study');S=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
O.mkdir(exist_ok=False)
plan=json.loads((A/'plan.json').read_text())
plan.update(status='prepared_held_no_release_ELF_inspection',scope='Static normal/PGO deferred native C Text raw comparison only; no parser/profiler/compiler/elapsed execution. Existing debug type layout may be read separately under root release.',source_manifest={'path':str(S/'source-attempt02.json'),'sha256':sha(S/'source-attempt02.json')},candidate_pair_directory='/tmp/oriole-deferred-c-text-raw-pgo-study',required_release_file=str(O/'released-inputs.json'))
plan['manual_gate']=[
 'Trace ordinary character Text reached from the explicit C seam in each mode; the old String append/raw memcpy must be absent on that eligible branch, not merely moved into an unconditional caller.',
 'Locate the unchanged reserve request based on physical String length and verify that descriptor publication follows successful reservation. Callback Text/frame preparation and ownership remain before it.',
 'Locate materialization within XML_Parse before preserve_input_context/feed. Its copy should execute only for a retained native range when feeding or explicitly leaving host protocol; ordinary event delivery must not eagerly materialize it.',
 'Identify actual Parser and NativeRawRange layout evidence from constructor/copy sizes and field offsets, cross-checking the separately read exact-source test DWARF where available. Distinguish debug type evidence from release-machine-code evidence.',
 'Count next_event_scoped/next_event_inner/next_delivery/next_adapter_event/parse_text/save_text_raw variants and compare text sizes/prologue reservations. Report unexpected function duplication or code growth, retaining required noneligible raw-copy paths.',
 'Static evidence supports only compiled-path/layout claims. No speed prediction, profiler job, inline tweak or broad PC attribution follows automatically.'
]
assert all(sha(p)==h for p,h in plan['tool_pins'].items())
(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(A/'collect_assembly.py').read_text()
repls=[('/tmp/oriole-compact-delivery-status-study/checks-attempt01/results.json',str(S/'checks-attempt02/results.json')),('/tmp/oriole-compact-delivery-status-source-independent-review.json',str(S/'independent-source-review-attempt02.json')),('/home/dev-user/code/oss/oriole-compact-delivery-status','/home/dev-user/code/oss/oriole-deferred-c-text-raw'),('manual compact-result ABI gate pending','manual deferred Text copy/reservation/layout gate pending'),('collected_pending_manual_compact_ABI_review','collected_pending_manual_Text_raw_review')]
for before,after in repls:s=s.replace(before,after)
old="['<oriole::Parser>::next_event','<oriole::Parser>::next_delivery','with_dtd_tables','oriole_expat::run_events','XML_Parse']"
new="['<oriole::Parser>::next_event','<oriole::Parser>::next_delivery','<oriole::Parser>::next_adapter_event','<oriole::Parser>::parse_text','<oriole::Parser>::save_text_raw','<oriole::Parser>::save_current_raw','<oriole::Parser>::current_raw','<oriole::Parser>::materialize_current_raw','<oriole::Parser>::try_new','<oriole::Parser>::feed','with_dtd_tables','oriole_expat::run_events','XML_Parse','XML_DefaultCurrent']"
assert old in s;s=s.replace(old,new);ast.parse(s)
(O/'collect_assembly.py').write_text(s)
(O/'controller-adaptation.patch').write_text(''.join(difflib.unified_diff((A/'collect_assembly.py').read_text().splitlines(True),s.splitlines(True),fromfile='compact/collect_assembly.py',tofile='deferred-text/collect_assembly.py')))
record={'status':'prepared_static_collection_held','plan_sha256':sha(O/'plan.json'),'controller_sha256':sha(O/'collect_assembly.py'),'origin_controller_sha256':sha(A/'collect_assembly.py'),'controller_adaptation_sha256':sha(O/'controller-adaptation.patch'),'generator_sha256':sha(__file__),'targets_or_binutils_executed':False,'scope':'Four unchanged per-library nm/objdump/size/readelf commands; only source/review paths, caption and relevant-symbol filter adapted. Exact candidate library/build release pins required before inspection.'}
(O/'preparation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
