"""Prepare fixed native screen templates; no target or timing execution."""
from pathlib import Path
import ast,difflib,hashlib,json
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
S=Path(__file__).resolve().parent
assert sha(S/'source-attempt02.json')=='dfa4fb42c7c6601d402d06adc17a4d0efa1208f57cd11658df65d9bb25c74009'
rows=[]
for mode in ['normal','pgo']:
 old=Path('/tmp/oriole-compact-delivery-status-'+mode+'-native-study')
 out=Path('/tmp/oriole-deferred-c-text-raw-'+mode+'-native-study');out.mkdir(exist_ok=False)
 original=(old/'native_screen.py').read_text();tree=ast.parse(original)
 libraries=next(n.value for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='libraries')
 candidate=libraries.values[1].args[0].value
 placeholder='<UNSEALED_DEFERRED_C_TEXT_'+mode.upper()+'_LIBRARY>'
 replacements=[(str(old),str(out)),(candidate,placeholder),('compact private delivery-status','deferred C Text raw-copy')]
 new=original
 for before,after in replacements:new=new.replace(before,after)
 def comparable(text):
  tree=ast.parse(text);tree.body[0].value=ast.Constant('<caption>')
  for n in tree.body:
   if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name):
    if n.targets[0].id=='root':n.value=ast.Constant('<study>')
    elif n.targets[0].id=='libraries':n.value.values[1]=ast.Constant('<candidate>')
    elif n.targets[0].id=='protocol':n.value.values[0]=ast.Constant('<scope>')
  return ast.dump(tree)
 assert comparable(original)==comparable(new);assert new.count(placeholder)==1
 (out/'native_screen.py.in').write_text(new);(out/'run.py.in').write_bytes((old/'run.py').read_bytes())
 (out/'template-adaptation.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True),fromfile=str(old/'native_screen.py'),tofile=str(out/'native_screen.py.in'))))
 old_adaptation=json.loads((old/'adaptation.json').read_text())
 report={'status':'prepared_not_sealed','origin':str(old),'original_controller_sha256':sha(old/'native_screen.py'),'original_wrapper_sha256':sha(old/'run.py'),'template_sha256':sha(out/'native_screen.py.in'),'wrapper_template_sha256':sha(out/'run.py.in'),'placeholder':placeholder,'replacement_pairs':replacements,'inverse_ast_equal_except_candidate_path_study_caption':True,'wrapper_byte_exact':True,'source_manifest_sha256':sha(S/'source-attempt02.json'),'control_library':old_adaptation['control_library'],'scope':'Original28conditions (24real+4generated),7pairs,84preflight+588timed workers per mode; unchanged seeds, actual warmups/iterations, native callbacks, worker90s timeout, statistics/order and CPU5 preflight/CPU0 elapsed wrappers. No B or additive real training. Candidate paths/hashes and build freeze remain unsealed; no targets executed.','targets_executed':False}
 (out/'template-preparation.json').write_text(json.dumps(report,indent=2)+'\n')
 rows.append({'mode':mode,'path':str(out),'preparation_sha256':sha(out/'template-preparation.json'),'template_sha256':sha(out/'native_screen.py.in')})
(S/'native-template-preparation.json').write_text(json.dumps({'status':'prepared_not_executed','rows':rows,'generator_sha256':sha(__file__)},indent=2)+'\n')
print(json.dumps(rows))
