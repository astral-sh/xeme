"""Bind completed Text libraries to reviewed native templates without execution."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path(__file__).resolve().parent
BUILD = Path('/tmp/oriole-deferred-c-text-raw-pgo-study')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert sha(BUILD / 'pair-freeze.json') == '1ae202d5daf63fddc25b93b60cf3916f99f8be73e056c90ccd384ea24d9ba4a4'
pair = read(BUILD / 'pair-report.json')
assert pair['status'] == 'passed'
assert pair['source_unchanged'] and pair['scripts_unchanged'] and pair['tools_unchanged']
manifest = Path(pair['pgo_manifest']['path'])
assert sha(manifest) == pair['pgo_manifest']['sha256']
libraries = {
    'normal': BUILD / 'normal/liboriole_expat.so',
    'pgo': manifest.parent / 'use/liboriole_expat.so',
}
expected = {
    'normal': pair['normal_libraries']['liboriole_expat.so'],
    'pgo': pair['pgo_libraries']['use/liboriole_expat.so'],
}
for mode, library in libraries.items():
    out = Path('/tmp/oriole-deferred-c-text-raw-' + mode + '-native-study')
    template = read(out / 'template-preparation.json')
    assert sha(out / 'native_screen.py.in') == template['template_sha256']
    assert sha(out / 'run.py.in') == template['wrapper_template_sha256']
    assert sha(library) == expected[mode]
    assert sha(template['control_library']['path']) == template['control_library']['sha256']
    assert not (out / 'adaptation.json').exists()
    source = (out / 'native_screen.py.in').read_text()
    assert source.count(template['placeholder']) == 1
    source = source.replace(template['placeholder'], str(library))
    ast.parse(source)
    (out / 'native_screen.py').write_text(source)
    (out / 'run.py').write_bytes((out / 'run.py.in').read_bytes())
    report = {
        'status': 'passed', 'prepared_not_executed': True,
        'scope': template['scope'],
        'template_preparation_sha256': sha(out / 'template-preparation.json'),
        'source_manifest_sha256': pair['source_manifest_sha256'],
        'build_freeze_sha256': sha(BUILD / 'pair-freeze.json'),
        'controller_sha256': sha(out / 'native_screen.py'),
        'wrapper_sha256': sha(out / 'run.py'),
        'control_library': template['control_library'],
        'candidate_library': {'path': str(library), 'sha256': sha(library)},
        'seal_controller_sha256': sha(__file__),
    }
    report['scope'] = report['scope'].replace(
        'Candidate paths/hashes and build freeze remain unsealed; no targets executed.',
        'Candidate paths/hashes and completed build freeze are now bound; no targets executed by preparation.')
    (out / 'adaptation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(mode, report['controller_sha256'])
