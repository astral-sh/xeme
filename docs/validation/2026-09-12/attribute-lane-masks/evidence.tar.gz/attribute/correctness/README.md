# Quoted-attribute first-stop lane masks: held normal correctness gates

Candidate runtime910387239a804a038feb0a184b1bcfc0a7dd60bf was measured from baseaed07bbacf75136330dd777a190ac2a42a2f1ed0. Only tag.rs differs across74 inputs. Selected LF control is runtimecacc/SO4ee8; candidate is SOb8508522/static5063d4. Dependencies and four auxiliary files remain unchanged.

The original API oracle retains4740 configurations:4347 passes,391 assertion failures and2timeouts. All assertions and original3s per-case,1GiB address-space,768MiB RSS,240s suite and300s outer bounds remain. Six dynamic/static integration/adversarial/allocation C consumers retain C-only ASan/UBSan, leak checking disabled,120s per compile/run; Rust uses ordinary generic release.

Strict shared/static CPython retains the explicit pinned upstream pyexpat cleanup backport,802methods/809rendered outcomes and two known callback-fragmentation failures per linkage (raw exit2). Each strict controller child retains1000s. Separate two semantic tests per linkage remain unchanged. Benchmark consumers use unmodified CPython; these patched strict modules are distinct.

This preparer writes only source scripts and saved bindings. Root runs bind.py and bind_strict.py onCPU6; api_native.py onCPU3 then read_api_c.py onCPU6; strict_cpython.py onCPU3; prepare_semantics.py onCPU6, run_semantic.py shared then static onCPU3, then read_strict_semantics.py onCPU6. Original commands, clean environment, pinned Python, timeout/teardown and raw exits remain. No PGO/flags or assertions change. Root schedules targets after elapsed measurements have ended.

Historical author-script pins/oracles retain original paths. No prior result is presented as a candidate outcome. LF's earlier descriptive origin-label correction remains historical and is not replayed: new strict initialization is accurately labeled as a provenance change from the start. No parser/compiler/strict extension is executed by this preparer.
