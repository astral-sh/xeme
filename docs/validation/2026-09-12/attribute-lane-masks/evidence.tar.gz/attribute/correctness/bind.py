"""Bind reviewed source and completed normal artifacts; never execute targets."""
from pathlib import Path
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
P = Path(__file__).parent
B = Path('/tmp/oriole-attribute-lane-masks-study')
W = Path('/home/dev-user/code/oss/oriole-attribute-lane-masks')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
pins = load(P / 'static-pins.json')
assert all(sha(path) == value for path, value in pins.items())
review = load(P / 'reviewed-source.json')
source, build, binding = (load(B / name) for name in ['source.json', 'build.json', 'build-binding.json'])
assert review['status'] == 'passed_independent_source_review'
assert source['worktree'] == str(W) and len(source['sha256']) == 74
prepared = load(P / 'reviewed-prepared-source.json')
formatting = load(P / 'reviewed-formatting.json')
metadata = load(P / 'reviewed-metadata.json')
assert sha(P / 'reviewed-prepared-source.json') == binding['prepared_source_sha256'] == 'ee276c38b72082acfd9489e6f8f1b2f04618547f6cb6dbbb652f82f6c22ca773'
assert source['sha256'] == prepared['sha256']
assert source['base'] == prepared['base'] == 'aed07bbacf75136330dd777a190ac2a42a2f1ed0'
assert review['base_commit'] == 'cacc0b1b3766176e9cbf71d25c5ff6867fa87c08'
assert prepared['source_count'] == review['main_source_files_verified'] == 74
assert set(review['changed_files']) == set(prepared['changed']) == set(binding['source_delta']) == {'crates/oriole/src/tag.rs'}
assert formatting['status'] == 'passed_independent_formatting_followup'
assert sha(P / 'reviewed-formatting.json') == '915367db3d12873001257e97643697cef0e7ecab48edce576abe4378f2aadbb4'
assert formatting['pins'][str(W/'crates/oriole/src/tag.rs')] == source['sha256']['crates/oriole/src/tag.rs']
assert formatting['main_source_files'] == 74 and formatting['auxiliary_files'] == 4
assert prepared['complete_patch_sha256'] == binding['complete_patch_sha256'] == sha(B / 'candidate.patch')
assert metadata['status'] == 'passed_saved_metadata_review'
assert binding['dependency_review_sha256'] == sha(P / 'reviewed-metadata.json') == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
assert metadata['source_manifest_sha256'] == sha('/tmp/oriole-text-lane-masks-preparation/source.json')
assert binding['auxiliary_files'] == prepared['auxiliary_sha256'] == load('/tmp/oriole-text-lane-masks-study/build-binding.json')['auxiliary_files']
for name,digest in binding['auxiliary_files'].items():
    assert sha(W/name)==digest
    pins[str(W/name)]=digest
assert len(binding['dependency_compiler_vectors']) == 3
control_path = Path('/tmp/oriole-text-lane-masks-study/source.json')
control = load(control_path)
assert binding['control_source_manifest_sha256'] == sha(control_path)
assert set(source['sha256']) == set(control['sha256'])
assert {name for name in source['sha256'] if source['sha256'][name] != control['sha256'][name]} == {'crates/oriole/src/tag.rs'}
assert binding['control_libraries']['liboriole_expat.so'] == '4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d'
assert binding['candidate_libraries'] == {'liboriole_expat.so': 'b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5', 'liboriole_expat.a': '5063d4fa59a08f7853f245a413b32ebc0f1a83901a36e1fcb1df87a925832843'}
assert build['status'] == binding['status'] == 'passed' and build['source_unchanged']
assert binding['build_sha256'] == sha(B / 'build.json')
assert binding['source_manifest_sha256'] == sha(B / 'source.json')
assert binding['source_count'] == 74
assert set(binding['compiler_vectors_normalized']) == {'oriole_storage', 'oriole', 'oriole_expat'}
for vector in binding['compiler_vectors_normalized'].values():
    assert 'opt-level=3' in vector and 'codegen-units=1' in vector
    assert vector[vector.index('--target') + 1] == 'x86_64-unknown-linux-gnu'
    assert not any('profile-generate' in value or 'profile-use' in value or 'target-cpu' in value for value in vector)
assert 'lto=thin' in binding['compiler_vectors_normalized']['oriole_expat']
libraries = {}
for suffix in ['so', 'a']:
    name = 'liboriole_expat.' + suffix
    path = B / 'normal' / name
    value = sha(path)
    assert value == binding['candidate_libraries'][name]
    libraries[suffix] = {'path': str(path), 'sha256': value}
    pins[str(path)] = value
for name, value in source['sha256'].items():
    assert sha(W / name) == value
    pins[str(W / name)] = value
for path in [P / 'preparation.json', P / 'static-pins.json', P / 'reviewed-source.json', B / 'source.json', B / 'build.json', B / 'build-binding.json']:
    pins[str(path)] = sha(path)
assert not (P / 'api-native').exists()
assert all(sha(path) == value for path, value in pins.items())
with (P / 'pins.json').open('x') as stream:
    stream.write(json.dumps(pins, indent=2) + '\n')
with (P / 'bound.json').open('x') as stream:
    stream.write(json.dumps({'status': 'bound_not_executed', 'targets_executed': False, 'source_sha256': sha(B / 'source.json'), 'build_binding_sha256': sha(B / 'build-binding.json'), 'libraries': libraries, 'pins_sha256': sha(P / 'pins.json'), 'scope': 'Normal generic O3/ThinLTO/cgu1 API and six C consumers. Root owns release and execution.'}, indent=2) + '\n')
print(json.dumps({'status': 'bound_not_executed', 'bound_sha256': sha(P / 'bound.json'), 'pins': len(pins), 'libraries': libraries}))
