# Attribute SIMD: unchanged Text/entity code shape

**The nine inspected release functions show no instruction-shape change beyond
PC-relative addresses and compiler-generated anonymous symbol labels.** This
does not explain or dismiss the reported entity benchmark regression.

Control is selected LF runtime `cacc0b1`, normal DSO `4ee8de82…`; candidate is
quoted-attribute runtime `9103872`, normal DSO `b8508522…`. The exact bound74-file
source maps differ only in `tag.rs`; core `lib.rs`, `encoding.rs`, `text.rs` and
C `lib.rs` are identical. Both use the recorded generic normal release recipe.
No parser, compiler, profile, elapsed run or flag experiment was executed here.
Only18 bounded CPU6 objdump artifact reads ran, all reaped with exit0.

## Actual ELF comparison

| Function | Bytes, both | Control address | Candidate address | Finding |
| --- | ---: | --- | --- | --- |
| TextPlan::scan | 745 | 0x49c20 | 0x49c20 | Exact complete machine bytes identical |
| Source::consume_text | 155 | 0x6c860 | 0x6c860 | Exact complete machine bytes identical |
| Source::finish_consume | 535 | 0x6c9c0 | 0x6c9c0 | Only PC-relative displacement bytes differ |
| Parser::parse_text | 5919 | 0x7f970 | 0x7fa80 | Same instruction layout; moved +0x110 |
| Parser::account_source | 507 | 0x89d40 | 0x89e50 | Same instruction layout; moved +0x110 |
| Parser::parse_reference | 7043 | 0x89f40 | 0x8a050 | Same instruction layout; moved +0x110 |
| Parser::next_event_inner | 19236 | 0x8eab0 | 0x8ebc0 | Same instruction layout; moved +0x110 |
| Parser::consume | 790 | 0xa1270 | 0xa1380 | Same instruction layout; moved +0x110 |
| C run_events | 4770 | 0xae9e0 | 0xaeaf0 | Same instruction layout; moved +0x110 |

The existing exact TagScanner capture shows3373→3638 bytes (+265), with its
entry unchanged at0x73560. The later functions' +272-byte shift is consistent
with that growth plus alignment. For example, parse_reference moves from
address modulo64=0 to16; parse_text and next_event_inner move48→0. These are
static addresses, not evidence of an instruction-cache or branch-predictor
performance effect. The actual opcodes, instruction offsets/lengths, registers,
non-address immediates and symbolic control-flow targets in the nine functions
match after the stated normalization.

## Why this fixture does not exercise the new value classifier

The pinned340013-byte `entities.xml` is exactly `<root>` followed by10000 copies
of `alpha &amp; beta &#65; &lt; gamma\n`, then `</root>`: two literal opening
angle delimiters and zero attributes. The new classifier is called only from
`AttributeScanner`'s `Phase::Value` branch (`tag.rs:203–206`), after a quoted
attribute opener (`tag.rs:189–201`). Its SIMD block is at `tag.rs:283–301`.
This document's root start still uses tag scanning, but does not enter quoted
attribute values. Repeated body content instead uses unchanged parse_text
(`lib.rs:2363`) and parse_reference (`lib.rs:2645`) through next_event_inner
(`lib.rs:1963`); accounting/consume definitions are at1899/1924.

## Method and limits

`comparison.json` retains actual commands, library/tool/fixture pins, symbol
sizes, all decoded instruction rows, raw symbol byte hashes and first normalized
differences. `classification.json` retains the stricter second comparison:
for every changed instruction, replacing exactly its decoded four-byte
PC-relative displacement reconstructs the entire candidate instruction bytes.
Anonymous `.llvm.<decimal>` suffixes are normalized separately; all other
symbolic target text and offsets remain. No opcode or ordinary operand change
was hidden by normalization. `source-scope.json` binds the two74-file maps.

The comparison covers these named functions, not all transitive callees,
relocated data contents or dynamic execution frequency. It does not assign the
reported8–9% generated regression to alignment, and cannot separate a code-layout
effect from host/run variation. Conversely, source identity alone was not used
to claim identical machine code: the complete inspected function bytes and
decoded rows were compared. The independent elapsed confirmation remains the
next evidence for whether that regression persists.
