# Held saved readers: quoted-attribute first-stop scan

These readers adapt the completed compact-owner audit without retaining its runtime changes, layout campaign or performance results. They run on CPU6 and read saved source, compiler commands, ELF-capture output and benchmark records. They execute no parser, compiler, artifact-capture tool or benchmark. Final receipts are created exclusively; earlier results are never replaced.

`build_codegen.py` replays the pinned build binder's assertions before its original writer, checks every actual core/dependency vector and the 456-test/35-summary outcome, then replays only the saved codegen reader before its report write. It independently checks both engines' source/build/library links and optionally verifies every candidate source/auxiliary Git blob against a supplied commit. Symbol/mnemonic evidence is retained without inferring instruction counts, execution frequency or speed. No type-layout result is used.

`native.py` retains the original raw reconstruction of all 28 conditions, seven pairs, 672 workers and 106,176 samples. It compares every primary row and independently recomputes aggregate products, all adverse conditions and fully interior host-counter intervals. Fresh preflights and actual callback/output/library pins remain required. Host observations are not proof of isolation. The same optional runtime commit should be supplied to both readers; omit it only if the build audit preceded committing the exact source map.

The coordinate reviewer authored these adapters and the ordinary build/native preparation, and reviewed the separate codegen scripts. Another agent reviewed the quoted-attribute runtime and the preparation. These receipts are separate saved-data reconstruction, not a claim that this reader author independently authored none of the harness. Root owns target execution and primary readers.

## Root-released saved audit

```sh
taskset -c 6 python3 -I -S /tmp/oriole-attribute-lane-masks-independent-readers/build_codegen.py \
  --build-binding-sha cbd73f86c625b939e7c3a37fdda70e149df616f93616015fa2ea4e024801f3f9 \
  --codegen-report-sha 32d368cd490f71fb179d411e5faf01e8c6355db66d6f7c5d5d25a2c1e95cfd4d \
  --candidate-so b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5 \
  --runtime-commit 910387239a804a038feb0a184b1bcfc0a7dd60bf
```

The later native invocation requires `--primary-review-sha`, `--preparation-sha`, `--build-codegen-review-sha`, `--candidate-so` and the same `--runtime-commit`. Its materialized preparation SHA is `0f767c2db7b81afbd441d464a61a9e4166ff98f50d33d3428af1a7f0c0c30c86`. Repeat `--host-before FILENAME.json` for every pre-run observation in chronological order if more than the default `host-before-native.json` exists. Wait for root to reap timing and the monitor and provide the primary review SHA before launching.
