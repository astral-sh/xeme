"""Completed normal CPython raw/origin/host audit; no parser or target execution."""
from pathlib import Path
import ast,csv,hashlib,json,math,os,subprocess,sys
assert __debug__ and os.sched_getaffinity(0)=={6}
assert len(sys.argv)>=3 and len(sys.argv[1])==len(sys.argv[2])==64
PRIMARY_SHA=sys.argv[1]
ROOT=Path('/tmp/oriole-attribute-lane-masks-study');D=ROOT/'python';CONF=Path('/tmp/oriole-attribute-lane-masks-confirmation');C=CONF/'python';OLD=Path('/tmp/oriole-text-lane-masks-study/python')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text())
assert H(C/'normal-review.json')==PRIMARY_SHA
assert H(C/'preflight-review.json')==sys.argv[2]
assert H(CONF/'preparation.json')=='a75b9675ce434cb4932347a574ca1017419fb5a8cb4aeb6e69909de5aa8c8af3'
assert H(C/'elapsed_review.py')=='20a534ee13c1a6d1b9c04d311d87986a12ef918aa01a87a803363b189e2e7301'
assert H(C/'preflight_review.py')=='830d0ebfa919f24a36922da6def8b87a6e2ecaba97b3e4a2522fa017a83b45ea'
preparation=J(D/'source-preparation.json')
for mapping in [preparation['pins'],preparation['parent_scripts'],preparation['selected_control_scripts']]:
 for path,value in mapping.items():assert H(path)==value,path
for name in ['python_worker.py','run.py','build_consumers.py']:assert (D/name).read_bytes()==(OLD/name).read_bytes()
for name in ['python_worker.py','consumer_screen.py']:assert (C/name).read_bytes()==(D/name).read_bytes()
assert H(C/'run.py')=='f1ec12acd2019e39521664b71256eb616c393fa235d3d480f640e051dd29f39c'

def replay(path,stop):
 text=path.read_text();tree=ast.parse(text);lines=text.splitlines()
 cut=next(i for i,n in enumerate(tree.body) if stop(n,lines))
 assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','check_output','mkdir','unlink','system'} for node in tree.body[:cut] for n in ast.walk(node))
 scope={'__file__':str(path),'__name__':'independent_saved_python_replay'}
 exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),str(path),'exec'),scope)
 return scope

pre=replay(C/'preflight_review.py',lambda node,lines:lines[node.lineno-1].startswith('output=C/'))
actual_pre=J(C/'preflight-review.json');assert actual_pre==pre['result']
scope=replay(C/'elapsed_review.py',lambda node,lines:isinstance(node,ast.With) and lines[node.lineno-1].startswith('with csvpath.open'))
actual=J(C/'normal-review.json');expected=dict(scope['report']);expected['condition_csv_sha256']=H(C/'normal-conditions.csv');assert actual==expected
assert scope['D']==D and scope['C']==C and scope['S']==C/'screen'
assert actual_pre['extension_compiles']=={'fresh':0,'reused':6,'total':6}
assert pre['pins']==actual_pre['pins']
with (C/'normal-conditions.csv').open(newline='') as f:rows=list(csv.DictReader(f))
assert rows==[{k:str(v) for k,v in row.items()} for row in scope['rows']]
assert actual['counts']['all_workers']==576 and actual['counts']['all_samples']==26364 and len(actual['summary'])==24
for group,entry in actual['aggregates'].items():
 selected=[r for r in actual['summary'] if group=='all' or r['condition']['mode']==group]
 for name,value in entry['geomean_ratios'].items():assert math.isclose(math.prod(r['median_ratios'][name] for r in selected)**(1/len(selected)),value,rel_tol=1e-14,abs_tol=1e-14)
adverse=[r for r in actual['summary'] if r['median_ratios']['candidate_over_control']>1]
assert actual['aggregates']['all']['adverse_conditions']==[{'condition':r['condition'],**r['median_ratios']} for r in adverse]
for mapping in [pre['pins'],scope['pins']]:
 for path,value in mapping.items():assert H(path)==value,path
source=J(ROOT/'source.json');binding=J(ROOT/'build-binding.json')
assert len(source['sha256'])==74 and H(ROOT/'build-binding.json')=='cbd73f86c625b939e7c3a37fdda70e149df616f93616015fa2ea4e024801f3f9'
commit=preparation['candidate_runtime_commit'];assert commit=='910387239a804a038feb0a184b1bcfc0a7dd60bf'
assert set(binding['source_delta'])=={'crates/oriole/src/tag.rs'}
for name,value in {**source['sha256'],**binding['auxiliary_files']}.items():
 assert H(Path(source['worktree'])/name)==value
 assert hashlib.sha256(subprocess.check_output(['git','-C',source['worktree'],'show',commit+':'+name])).hexdigest()==value,name
assert actual['libraries']['candidate']['sha256']==binding['candidate_libraries']['liboriole_expat.so']=='b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5'
assert actual['libraries']['control']['sha256']=='4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d'
# Reuse the exact pure counter-delta function from the earlier independent confirmation reader.
pure_reader=Path('/tmp/oriole-namespace-scopes-confirmation-native-independent-read.py');audit=J('/tmp/oriole-namespace-scopes-confirmation-native-independent-review.json');assert H(pure_reader)==audit['reader_sha256']
tree=ast.parse(pure_reader.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='counters');ns={}
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(pure_reader),'exec'),ns);counters=ns['counters']
during=J(CONF/'host-during-python.json');controller=J(C/'time-controller.json');timing,=controller['jobs']
assert during['status']=='completed' and during['phase']=='python' and during['controller_status']==controller['status']=='passed'
assert during['controller_sha256']==H(C/'time-controller.json') and during['monitor_sha256']==H(CONF/'monitor-host.py')
before_files=sys.argv[3:] or ['host-before-python.json'];assert len(before_files)==len(set(before_files))
before_records=[]
for filename in before_files:
 assert Path(filename).name==filename and filename.endswith('.json')
 before=J(CONF/filename)
 assert len(before['samples'])==2 and before['samples'][-1]['time']<=timing['start']
 before_summary=counters(before['samples'][0],before['samples'][-1]);assert before_summary['idle_including_iowait_fractions']==before['idle_plus_iowait_fraction']
 before_records.append({'file':filename,'sha256':H(CONF/filename),'summary':before_summary})
assert all(x['summary']['end']<=y['summary']['start'] for x,y in zip(before_records,before_records[1:]))

intervals=[counters(x,y) for x,y in zip(during['samples'],during['samples'][1:])]
inside=[r for r in intervals if timing['start']<=r['start'] and r['end']<=timing['end']]
outside=[r for r in intervals if not (timing['start']<=r['start'] and r['end']<=timing['end'])]
points=[p for p in during['samples'] if timing['start']<=p['time']<=timing['end']];assert inside and len(points)>=2 and len(inside)+1==len(points)
aggregate=counters(points[0],points[-1]);assert math.isclose(sum(r['seconds'] for r in inside),aggregate['seconds'],abs_tol=1e-9)
for cpu in ['cpu','cpu0']:
 for key in ['total','idle']:assert sum(r['counter_deltas'][cpu][key] for r in inside)==aggregate['counter_deltas'][cpu][key]
host={'before':before_records,'during_sample_count':len(during['samples']),'elapsed_controller':{'start':timing['start'],'end':timing['end'],'seconds':timing['end']-timing['start']},'sample_intervals_fully_inside_elapsed':{'count':len(inside),'aggregate':aggregate,'fraction_of_elapsed':aggregate['seconds']/(timing['end']-timing['start']),'other_cpus_idle_range':[min(r['other_cpus_idle_including_iowait_fraction'] for r in inside),max(r['other_cpus_idle_including_iowait_fraction'] for r in inside)],'intervals':inside},'excluded_outside_or_boundary_intervals':outside,'limitations':['Five-second /proc/stat samples count idle+iowait and exclude duplicate guest fields; no OS isolation or absence-of-contention claim.','Only consecutive intervals fully inside elapsed are attributed; no interpolation or per-condition attribution.','Pre-run observation remains separate from during-run activity.']}
paths=[CONF/'preparation.json',C/'preparation.json',D/'source-preparation.json',C/'preflight_review.py',C/'elapsed_review.py',C/'preflight-review.json',C/'normal-review.json',C/'normal-conditions.csv',C/'prepare-controller.json',C/'time-controller.json',ROOT/'source.json',ROOT/'build-binding.json',*(CONF/name for name in before_files),CONF/'host-during-python.json',CONF/'monitor-host.py',pure_reader,Path(__file__)]
result={'status':'passed_independent_normal_python_raw_and_host_review','targets_executed':False,'role':'Separate saved reconstruction by author of ordinary/native adapters and reviewer of current Python preparation; related ancestor recipes were authored by this reviewer. Quoted-attribute runtime and target workers have separate authors. Root executed all targets and primary readers.','runtime_commit':commit,'counts':actual['counts'],'aggregates':actual['aggregates'],'all_conditions':actual['summary'],'all_adverse_conditions':adverse,'host':host,'provenance':{'libraries':actual['libraries'],'main_source_files':74,'main_changed_files':list(binding['source_delta']),'auxiliary_files_unchanged':4,'preflight_pins':len(pre['pins']),'elapsed_pins':len(scope['pins']),'fresh_compiles':0,'reused_modules':6},'limitations':['All24 conditions and every adverse row retained. Initial and confirmation epochs remain separate, with no pooling. This confirmation normal CPython project-input benchmark is not whole-application performance or exact callback-fragmentation compatibility.','Unmodified CPython3.12.13 O2 modules, module/dladdr origins, enabled GC, parse construction/feed/finalization/callbacks plus explicit destruction and canonical hashes match the original protocol.','No causal, statistical-significance or exclusive-host assertion. Current candidate adoption remains a separate root decision.'],'pins_sha256':{str(p):H(p) for p in paths},'reader_sha256':H(__file__)}
out=Path('/tmp/oriole-attribute-lane-masks-confirmation-independent-python-review.json')
with out.open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'receipt':str(out),'sha256':H(out),'counts':actual['counts'],'aggregates':actual['aggregates'],'fully_interior_host':{'intervals':len(inside),'seconds':aggregate['seconds'],'elapsed_seconds':timing['end']-timing['start'],'other_cpus_idle_iowait':aggregate['other_cpus_idle_including_iowait_fraction'],'excluded_intervals':len(outside)}},indent=2))
