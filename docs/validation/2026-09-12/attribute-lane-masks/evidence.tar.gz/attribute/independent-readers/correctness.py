"""Reconstruct completed correctness evidence without running a target or primary writes."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import json
import os
import re
import subprocess

assert __debug__ and os.sched_getaffinity(0) == {6}
P = Path('/tmp/oriole-attribute-lane-masks-correctness')
B = Path('/tmp/oriole-attribute-lane-masks-study')
W = Path('/home/dev-user/code/oss/oriole-attribute-lane-masks')
OUT = Path('/tmp/oriole-attribute-lane-masks-correctness-independent-review.json')
assert not OUT.exists()
inputs = {}
def sha(path):
    path = Path(path)
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    assert str(path) not in inputs or inputs[str(path)] == value
    inputs[str(path)] = value
    return value
def load(path):
    sha(path)
    return json.loads(Path(path).read_text())
def replay(reader, report):
    script = P / reader
    expected = load(P / report)
    assert sha(script) == expected['reader_sha256']
    tree = ast.parse(script.read_bytes())
    end = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == 'result' for t in node.targets)) + 1
    # Both exact reader prefixes were inspected: only saved reads/assertions and
    # pure AST extraction of methods() execute. Stop before every output write.
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                   and n.func.attr in {'write_text', 'write_bytes', 'Popen', 'run', 'check_output', 'mkdir', 'unlink', 'system'}
                   for node in tree.body[:end] for n in ast.walk(node))
    ns = {'__file__': str(script), '__name__': 'independent_saved_replay'}
    exec(compile(ast.Module(body=tree.body[:end], type_ignores=[]), str(script), 'exec'), ns)
    assert json.loads(json.dumps(ns['result'])) == expected, reader
    for path, digest in expected['inputs'].items():
        assert sha(path) == digest, path
    return ns, expected

assert sha(P/'api-c-readback.json') == '3d87a8e5889d9b2b21bd5a581491878d9352b851a5e748b40da756ec41c2e3ff'
assert sha(P/'strict-semantic-readback.json') == '6d0e0727c06655f1bf5a660a99c2139f474a26f760335cd01a13a19e9f83b2c0'
api_ns, api = replay('read_api_c.py', 'api-c-readback.json')
strict_ns, strict = replay('read_strict_semantics.py', 'strict-semantic-readback.json')
assert len(api_ns['rows'][1]) == 4740
assert dict(Counter(r['outcome'] for r in api_ns['rows'][1])) == {'pass':4347,'fail':391,'timeout':2}
assert all(r['exit'] == 0 for r in api['c_consumers']) and len(api['c_consumers']) == 6
assert all(v['full_method_map'] == strict['strict']['shared']['full_method_map']
           for v in strict['strict'].values())
for linkage, value in strict['strict'].items():
    assert len(value['full_method_map']) == 802 and value['rendered_outcome_lines'] == 809
    assert value['raw_exit'] == 2 and len(value['failures']) == 2 and value['changes'] == []
    assert len(value['origins']) == 4 and len(value['compiler_commands']) == 2
assert len(strict['semantics']) == 2 and all(r['tests'] == 2 and r['exit'] == 0 for r in strict['semantics'])

source = load(B/'source.json')
binding = load(B/'build-binding.json')
assert len(source['sha256']) == 74 and binding['source_manifest_sha256'] == sha(B/'source.json')
for name, digest in source['sha256'].items(): assert sha(W/name) == digest
for name, digest in binding['auxiliary_files'].items(): assert sha(W/name) == digest
head = subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'], text=True).strip()
assert head == '910387239a804a038feb0a184b1bcfc0a7dd60bf'
prior_source = load('/tmp/oriole-attribute-lane-masks-independent-python-review.json')
assert sha('/tmp/oriole-attribute-lane-masks-independent-python-review.json') == '6884bd31bc45c36931c8ad053f3b4ccb62743017d5ea3ee629eda4feba738d59'

current = load(P/'preparation.json')
assert sha(P/'preparation.json') == 'd2fd419c928ccf3ed43ecfa76fd142886b64092aea8ff597ffaff05cf196416a'
assert current['candidate_source_commit'] == head
assert current['measured_source_base_commit'] == 'aed07bbacf75136330dd777a190ac2a42a2f1ed0'
assert current['controller_origins']['strict_cpython.py']['path_substitution_only'] is False
assert len(current['controller_origins']) == 9
for name, origin in current['controller_origins'].items():
    assert sha(P/name) == origin['sha256']
    assert sha(origin['origin']) == origin['origin_sha256']
assert sha('/tmp/oriole-attribute-lane-masks-correctness-prepare.py') == 'ff4249ed168eb1c870dac0c61db75202feae9dac7df01cee2630e8d6490939af'
assert sha('/tmp/oriole-attribute-lane-masks-independent-correctness-source-review.json') == '2ab75f7bb807543fb2f01027e9690b2fe2d3e79a747219d9d6be88b98a9dad41'
assert sha(P/'reviewed-source.json') == '3a971481e36edf52fa1714d379a036ad2f40b61a13c6114b47b55eb2c2329d35'
assert sha(P/'reviewed-formatting.json') == '915367db3d12873001257e97643697cef0e7ecab48edce576abe4378f2aadbb4'
bound = load(P/'bound.json')
assert sha(P/'bound.json') == 'd833257fd3579d4fd26406e03842a58673f957989d4785576a8d766239fd0c10'
assert sha(P/'strict-pins.json') == '9a9897f906560015c295f4aff53d7a0bc6ec40dff059e0524adc4b351a98fe93'
assert bound['source_sha256'] == sha(B/'source.json')
assert bound['build_binding_sha256'] == sha(B/'build-binding.json') == 'cbd73f86c625b939e7c3a37fdda70e149df616f93616015fa2ea4e024801f3f9'
assert bound['pins_sha256'] == sha(P/'pins.json')
for extension, digest in [('so', 'b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5'),
                          ('a', '5063d4fa59a08f7853f245a413b32ebc0f1a83901a36e1fcb1df87a925832843')]:
    assert bound['libraries'][extension]['sha256'] == digest == sha(bound['libraries'][extension]['path'])
    assert binding['candidate_libraries']['liboriole_expat.'+extension] == digest
for path, digest in list(inputs.items()): assert sha(path) == digest
result = {
    'status':'passed_independent_saved_correctness_review', 'targets_executed':False,
    'reader_sha256':sha(__file__), 'runtime_commit':head, 'source_files':74,
    'auxiliary_files':binding['auxiliary_files'], 'libraries':bound['libraries'],
    'api':api['api'], 'c_consumers':api['c_consumers'],
    'strict':{k:{'methods':v['methods'],'rendered_outcome_lines':v['rendered_outcome_lines'],
                 'raw_exit':v['raw_exit'],'failures':v['failures'],'changes':v['changes'],
                 'origins':v['origins'],'compiler_commands':v['compiler_commands'],
                 'full_method_map_sha256':hashlib.sha256(json.dumps(v['full_method_map'],sort_keys=True).encode()).hexdigest()}
              for k,v in strict['strict'].items()},
    'semantics':strict['semantics'],
    'controller_provenance':{'preparation_sha256':sha(P/'preparation.json'),
                             'origin_scripts':current['controller_origins'],
                             'strict_path_substitution_only':False,
                             'scope':'Current source and commit labels were accurate before target execution. Historical LF provenance correction is not a current target rerun.'},
    'checked_inputs':inputs, 'findings':[],
    'limitations':[
        'Existing 391 API assertion failures and two per-test timeouts remain; unchanged outcomes do not mean complete Expat compatibility.',
        'Six C harnesses use ASan/UBSan, but linked Rust normal-release libraries are uninstrumented and leak detection is disabled.',
        'Strict consumers contain the pinned upstream pyexpat cleanup backport; benchmark consumers are unmodified. Two strict callback-fragmentation failures remain in each linkage.',
        'Two supplemental semantic tests pass per linkage as separate evidence; they do not turn the strict suite green. 809 rendered outcomes contain 802 distinct method identities.',
        'No additional target, sanitizer, fuzz, PBS, performance or adoption result is established by this saved-only audit.',
    ],
    'role':'Separate raw reconstruction and saved identity review. Author of this reader, current ordinary build/binder/native preparation, and related ancestor benchmark recipes; reviewer of current correctness preparation. No authorship of current runtime, tests, correctness controllers or primary readers. Root executed all correctness targets and primary readers.',
}
with OUT.open('x') as stream: stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'path':str(OUT),'sha256':sha(OUT),'input_pins':len(inputs),
                  'api':api['api'],'c_consumers':6,'strict_methods_per_linkage':802,'semantic_tests_per_linkage':2}))
