"""Replay completed Python preflight records only, without loading modules."""
from pathlib import Path
import ast,hashlib,json,os,re,sys
assert __debug__ and os.sched_getaffinity(0)=={6}
assert len(sys.argv)==2 and re.fullmatch('[0-9a-f]{64}',sys.argv[1])
D=Path('/tmp/oriole-attribute-lane-masks-study/python')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
static={'/tmp/oriole-attribute-lane-masks-study/python/source-preparation.json': '354c68f317208aa03665b02f0ec401383b5a2a1b2a082e53e43d51e1020743ca', '/tmp/oriole-attribute-lane-masks-study/python/preparation.json': '846919151b60bf2d96a847dbf5913d745c43388b8bb170df8617c049b2b168bf', '/tmp/oriole-attribute-lane-masks-study/python/consumer-binding.json': 'd96bb2dc3dd1d6b220351a8e6ce0c3530df7d726bd322edb48ecb96397bff8fe', '/tmp/oriole-attribute-lane-masks-study/python/preflight_review.py': '880f5d147905c203b295a948ee795e4dc23706c621a0dccde9759826ccf50260', '/tmp/oriole-attribute-lane-masks-study/python/elapsed_review.py': '1d98dd71aaa633a17b55e84e2ddf98581d571b18936808f4070d58348ef88442'}
for p,h in static.items():assert H(p)==h,p
assert H(D/'preflight-review.json')==sys.argv[1]
reader=D/'preflight_review.py';text=reader.read_text();tree=ast.parse(text);lines=text.splitlines()
cut=next(i for i,n in enumerate(tree.body) if lines[n.lineno-1].startswith('output=D/'))
body=tree.body[:cut]
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','check_output','mkdir','unlink','system'} for node in body for n in ast.walk(node))
scope={'__file__':str(reader),'__name__':'independent_saved_python_preflight_replay'}
exec(compile(ast.Module(body=body,type_ignores=[]),str(reader),'exec'),scope)
primary=J(D/'preflight-review.json');assert primary==scope['result']
assert primary['preflight_workers']==72 and len(primary['conditions'])==len(primary['canonical_outputs'])==24
assert primary['extension_compiles']=={'fresh':2,'reused':4,'total':6}
assert len(primary['exact_compile_vectors'])==6 and set(primary['origins'])=={'candidate','control','expat'}
prior=J(D/'source-preparation.json');assert prior['candidate_runtime_commit']=='910387239a804a038feb0a184b1bcfc0a7dd60bf'
for engine,h in [('candidate','b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5'),('control','4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d'),('expat','7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478')]:assert primary['origins'][engine]['parser_library']['sha256']==h
for p,h in scope['pins'].items():assert H(p)==h,p
r={'status':'passed_independent_saved_python_preflight_review','targets_executed':False,'runtime_commit':prior['candidate_runtime_commit'],'preflight_workers':72,'canonical_conditions':24,'extension_compiles':primary['extension_compiles'],'compiler_vectors':primary['exact_compile_vectors'],'origins':primary['origins'],'primary_sha256':H(D/'preflight-review.json'),'canonical_outputs':primary['canonical_outputs'],'pins':dict(scope['pins'])|static|{str(D/'preflight-review.json'):H(D/'preflight-review.json')},'reader_sha256':H(__file__),'role':'Separate saved replay by reviewer of the Python preparation; this reviewer authored related ancestor recipes but did not author current target workers or execute modules. Root owns producer/preflight targets and primary readback.','limits':'Canonical output equality merges character chunks; these preflights do not replace strict CPython tests or establish elapsed performance.'}
out=Path('/tmp/oriole-attribute-lane-masks-independent-python-preflight-review.json')
with out.open('x') as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'workers':72,'conditions':24,'pins':len(r['pins']),'sha256':H(out)}))
