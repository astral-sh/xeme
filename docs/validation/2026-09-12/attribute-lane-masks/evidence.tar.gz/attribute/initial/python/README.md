# Quoted-attribute first-stop lane masks: held normal CPython comparison

Candidate runtime is 910387239a804a038feb0a184b1bcfc0a7dd60bf, measured on source base aed07bbacf75136330dd777a190ac2a42a2f1ed0. The selected LF control runtime is cacc0b1b3766176e9cbf71d25c5ff6867fa87c08, carried by that docs base. Candidate SOb8508522 is compared with selected LF SO4ee8 and unchanged normal Expat7a333.

Only tag.rs differs across the 74 source files. Four auxiliary manifests/locks and all dependencies are unchanged. This is a held source preparation; no Python targets or saved materializers have run in this directory. Root decides whether native evidence warrants downstream execution.

The completed LF protocol is reused: 24 conditions, seven pairs, 72 fresh preflights and 504 timed workers; 576 workers and 26,364 samples including warmups. run.py, python_worker.py and build_consumers.py are byte-identical; consumer_screen.py changes captions only. Saved readers change only the study path. Seed, order, callback modes, GC/destruction boundaries, canonical checks, timers, statistics and timeout cleanup are unchanged.

Two candidate O2 extensions will be built fresh. The completed LF candidate pyexpat/_elementtree modules become control in their original directory; two unchanged Expat modules also stay in their original directory. All six use pinned, unmodified CPython3.12.13 sources; the strict consumer cleanup backport is not applied here. Reused compiler vectors, logs, source/interpreter/header hashes and in-process origins are bound by the inherited preparation and readers.

Oriole parser libraries use generic ordinary O3/ThinLTO/one codegen unit; normal Expat uses the pinned GCC13.3 O3 recipe without LTO. Extension commands remain cc -shared -fPIC -O2. No PGO or CPU-target changes. CPU affinity does not establish an idle or exclusive host; root records host observations separately.

After release, root runs prepare.py then bind.py on CPU6. run.py prepare on CPU3 builds two extensions and runs all preflights, each controller stage bounded at600s. After preflight_review.py succeeds and other targets are reaped, run.py time executes on CPU0 with1200s controller and300s per-worker bounds. elapsed_review.py runs on CPU6. Exact argv are in held-commands.json; root supplies the established clean environment and release for each phase.
