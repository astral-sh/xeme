"""Bind saved control consumers and completed quoted-attribute first-stop lane masks parser build; no targets."""
from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess

assert __debug__ and os.sched_getaffinity(0) == {6}
D = Path(__file__).parent
P = Path('/tmp/oriole-text-lane-masks-study/python')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def save(p, v):
    with p.open('x') as stream:
        stream.write(json.dumps(v, indent=2) + '\n')

assert not (D/'preparation.json').exists()
build = load(D.parent/'build.json')
binding = load(D.parent/'build-binding.json')
source = load(D.parent/'source.json')
runtime_commit = '910387239a804a038feb0a184b1bcfc0a7dd60bf'
assert subprocess.check_output(['git', '-C', source['worktree'], 'rev-parse', 'HEAD'], text=True).strip() == runtime_commit
prepared = load('/tmp/oriole-attribute-lane-masks-preparation/source.json')
assert build['status'] == binding['status'] == 'passed' and build['source_unchanged']
assert binding['build_sha256'] == sha(D.parent/'build.json')
assert binding['source_manifest_sha256'] == build['source_sha256'] == sha(D.parent/'source.json')
assert source['sha256'] == prepared['sha256'] and len(source['sha256']) == 74
assert sha('/tmp/oriole-attribute-lane-masks-preparation/source.json') == binding['prepared_source_sha256'] == 'ee276c38b72082acfd9489e6f8f1b2f04618547f6cb6dbbb652f82f6c22ca773'
assert sha('/tmp/oriole-text-lane-masks-preparation/metadata-independent-review.json') == binding['dependency_review_sha256'] == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
assert sha('/tmp/oriole-text-lane-masks-preparation/format-metadata.json') == binding['metadata_receipt_sha256'] == build['metadata_receipt_sha256']
assert prepared['auxiliary_sha256'] == binding['auxiliary_files'] == build['auxiliary_files'] and build['auxiliary_unchanged']
for name,h in prepared['auxiliary_sha256'].items(): assert sha(Path(source['worktree'])/name) == h
assert prepared['auxiliary_sha256'] == load('/tmp/oriole-text-lane-masks-study/build-binding.json')['auxiliary_files']
assert len(binding['dependency_compiler_vectors']) == len(build['dependency_compiler_vectors']) == 3
assert source['base'] == binding['base'] == 'aed07bbacf75136330dd777a190ac2a42a2f1ed0'
assert binding['complete_patch_sha256'] == prepared['complete_patch_sha256'] == sha(D.parent/'candidate.patch')
for name, value in source['sha256'].items():
    assert sha(Path(source['worktree'])/name) == value
    assert hashlib.sha256(subprocess.check_output(['git', '-C', source['worktree'], 'show', runtime_commit+':'+name])).hexdigest() == value

old = load(P/'consumers/build.json')
prior = load(P/'preflight-review.json')
assert old['status'] == prior['status'] == 'passed'
assert old['adaptations'] is None and old['source_sha256_before'] == old['source_sha256_after']
reuse = {'status': 'verified_saved_reuse', 'candidate_runtime_commit': runtime_commit, 'candidate_source_base': source['base'], 'build_record': str(P/'consumers/build.json'),
         'preflight_review': str(P/'preflight-review.json'),
         'engines': {'control': {'prior_engine': 'candidate'}, 'expat': {'prior_engine': 'expat'}},
         'pins': {}}
def pin(p, expected=None):
    p = Path(p); value = sha(p)
    if expected is not None: assert value == expected, p
    reuse['pins'][str(p)] = value
    return value
for name in ('consumers/build.json', 'preflight-review.json', 'prepare-controller.json', 'build_consumers.py', 'python_worker.py', 'consumer_screen.py', 'adaptation.json'):
    pin(P/name)
a0 = load(P/'adaptation.json')
for v in a0['consumer_source']['files'].values(): pin(v['path'], v['sha256'])
for p, h in a0['consumer_source']['interpreter_and_public_headers'].items(): pin(p, h)
pin(a0['header']['path'], a0['header']['sha256'])
cc = Path(shutil.which('cc')).resolve(strict=True)
reuse['compiler_driver'] = {'path': str(cc), 'sha256': pin(cc)}
for engine, entry in reuse['engines'].items():
    consumer = old['consumers'][entry['prior_engine']]
    entry['directory'] = consumer['directory']
    entry['library'] = consumer['library']
    entry['library_sha256'] = consumer['files'][consumer['library']]
    assert entry['library_sha256'] == {
        'control': '4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d',
        'expat': '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'}[engine]
    for p, h in consumer['files'].items(): pin(p, h)
    for module, command in zip(('pyexpat', '_elementtree'), consumer['commands'], strict=True):
        assert command['returncode'] == 0
        pin(Path(consumer['directory'])/(module+'-build.log'), command['log_sha256'])
    assert prior['origins'][entry['prior_engine']]['parser_library'] == {'path': str(Path(consumer['library']).resolve()), 'sha256': entry['library_sha256']}
save(D/'reuse.json', reuse)

scripts = ('run.py', 'python_worker.py', 'build_consumers.py', 'consumer_screen.py')
adaptations = load(D/'script-adaptations.json')
assert adaptations['origin'] == str(P) and adaptations['inverse_text_equal']
for name, changes in adaptations['changes'].items():
    text = (D/name).read_text()
    ast.parse(text)
    for before, after in reversed(changes): text = text.replace(after, before)
    assert text == (P/name).read_text(), name
for name in ('run.py', 'python_worker.py', 'build_consumers.py'):
    assert (D/name).read_bytes() == (P/name).read_bytes()

a = {k: a0[k] for k in ('counts', 'bounds', 'seed', 'consumer_source', 'header', 'counts_with_warmups')}
a.update(status='prepared_only', execution_status='unexecuted', mode='normal', origin=str(P),
    parent_files={n: sha(P/n) for n in scripts}, files={n: sha(D/n) for n in scripts},
    source_runtime_control='aed07bbacf75136330dd777a190ac2a42a2f1ed0',
    candidate_source='/home/dev-user/code/oss/oriole-attribute-lane-masks',
    candidate_runtime_commit=runtime_commit, candidate_source_base=source['base'],
    measured_control_commit='cacc0b1b3766176e9cbf71d25c5ff6867fa87c08',
    consumer_directories={e: reuse['engines'][e]['directory'] if e in reuse['engines'] else str(D/'consumers/candidate') for e in ('control','candidate','expat')},
    libraries={'candidate': {'path': str(D.parent/'normal/liboriole_expat.so'), 'sha256': binding['candidate_libraries']['liboriole_expat.so']},
               'control': {'path': str(P.parent/'normal/liboriole_expat.so'), 'sha256': binding['control_libraries']['liboriole_expat.so']},
               'expat': a0['libraries']['expat']},
    extension_compiles={'fresh': 2, 'reused': 4, 'total': 6},
    parser_builds='Generic normal O3/ThinLTO/one codegen unit Oriole versus pinned normal O3 Expat. Four unchanged O2 control/Expat modules reused; two identical-recipe O2 candidate modules built fresh.',
    proof='run.py, python_worker.py and build_consumers.py byte-identical to completed selected LF protocol. consumer_screen.py changes captions only. Original24conditions,7pairs,worker iterations,canonical checks,origins,GC,destruction,medians and timeout cleanup unchanged.',
    comparison_scope='Quoted-attribute first-stop lane masks versus selected LF4ee8 control, carried by aed07bb, and unchanged normal Expat. Earlier experiments remain separate.',
    source_scope='74 source files: only tag.rs differs from selected LF. Core ownership, Text scanner, manifests, dependencies and four auxiliary files are unchanged. Complete one-file patch pinned.')
assert a['libraries']['control']['sha256'] == reuse['engines']['control']['library_sha256']
for entry in a['libraries'].values(): assert sha(entry['path']) == entry['sha256']
for key, name in (('candidate_source_record','source.json'), ('candidate_build_record','build.json'), ('candidate_build_review','build-binding.json')):
    a[key] = {'path': str(D.parent/name), 'sha256': sha(D.parent/name)}
save(D/'adaptation.template.json', a)
static_names = [*scripts, 'preflight_review.py', 'elapsed_review.py', 'bind.py', 'prepare.py',
                'README.md', 'script-adaptations.json', 'source-preparation.json',
                'reuse.json', 'adaptation.template.json']
static_names += [name+'.patch' for name in (*scripts, 'preflight_review.py', 'elapsed_review.py', 'bind.py')]
pins = {str(D/name): sha(D/name) for name in static_names}
for p in [D.parent/'source.json', D.parent/'build.json', D.parent/'build-binding.json', D.parent/'candidate.patch', Path('/tmp/oriole-attribute-lane-masks-preparation/source.json'), Path('/tmp/oriole-attribute-first-stop-independent-source-review.json'), Path('/tmp/oriole-text-lane-masks-preparation/metadata-independent-review.json'), Path('/tmp/oriole-text-lane-masks-preparation/format-metadata.json'), Path('/tmp/oriole-attribute-lane-masks-preparation/source-binding.json'), Path('/tmp/oriole-attribute-lane-masks-independent-formatting-followup.json')]:
    pins[str(p)] = sha(p)
result = {'status': 'prepared_unbound', 'targets_executed': False, 'pins': pins,
          'extension_compiles': a['extension_compiles'], 'counts': a['counts'],
          'counts_with_warmups': a['counts_with_warmups'], 'bounds': a['bounds'],
          'source_count': 74, 'control': a['libraries']['control'],
          'unchanged': ['run.py', 'python_worker.py', 'build_consumers.py'],
          'next_saved_command': ['taskset', '-c', '6', '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3', '-I', '-S', str(D/'bind.py')]}
save(D/'preparation.json', result)
print(json.dumps({'status':'prepared_unbound', 'preparation_sha256':sha(D/'preparation.json'), 'fresh_compiles':2, 'reused_compiles':4, 'candidate':a['libraries']['candidate']}))
