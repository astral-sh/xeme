# Quoted-attribute first-stop scan: held ordinary protocol

This preparation changes only `crates/oriole/src/tag.rs` relative to published LF commit `aed07bbacf75136330dd777a190ac2a42a2f1ed0`. All 74 source files and four auxiliary manifest/lock files in that commit match the measured LF source. The rejected compact converted-name owner is absent. Root created and formatted the candidate worktree; source binding, build, artifact inspection and measurements remain held.

The source proposal and its independent review are retained at `/tmp/oriole-attribute-first-stop-source-proposal` and `/tmp/oriole-attribute-first-stop-independent-source-review.json`. The proposal's earlier pending-LF label is historical; this experiment uses the published LF baseline. The scanner reuses the existing `wide` dependency. No dependencies, CPU features, optimization settings or persistent state change.

Formatting only wrapped one expression in the added test helper. `formatting-refreeze.json` proves that this single literal replacement reproduces the entire formatted file, SHA `a5c2f04ff7eff4ecb580bb1414426e186acfb8697a7c3e83b90c2be3c75de940`. The original expected map and source checks remain in `before-formatting/`; runtime bytes and the four ordinary/native scripts are unchanged.

## Controls and gates

- Candidate worktree: `/home/dev-user/code/oss/oriole-attribute-lane-masks`; distinct target: `/home/dev-user/.cache/oriole/attribute-lane-masks-target`; output: `/tmp/oriole-attribute-lane-masks-study`.
- LF control: existing normal `liboriole_expat.so`, SHA `4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d`.
- Expat control: original normal library, SHA `7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478`.

The build retains the same seven commands, environment cleanup, process-group teardown and 900-second child bound: compiler identity, workspace format/tests/strict Clippy, inprocess benchmark format/strict Clippy, and generic x86-64 O3/ThinLTO/one-codegen-unit release. Expected results are 456 tests across 35 summaries, including the existing documentation test. The added test exercises the actual attribute helper against a byte-prefix oracle; all previous tests remain.

The saved build binder compares every actual core and dependency compiler vector against LF, retaining flag and extern order. Only established Cargo identifiers, dependency fingerprints and compiler/shared-build paths are normalized. All source, dependency, auxiliary and output-library identities must match before benchmark scripts can be materialized.

## Root-owned launch order

1. Create the isolated Cargo worktree at the exact published base, apply the reviewed proposal and format it. These scripts never create or alter that checkout. If formatting changes the proposed hash, preserve the first form and explicitly review/refreeze the expected map.
2. In this preparation directory, run `taskset -c 6 python3 bind_source.py aed07bbacf75136330dd777a190ac2a42a2f1ed0`. This verifies Git identity, base blobs, the one-file diff and all current bytes, then pins the six scripts.
3. Run `taskset -c 4 python3 build.py`, followed by `taskset -c 6 python3 bind_build.py` after all children have been reaped.
4. Run the held `codegen/capture.py` and `codegen/read.py` on CPU6 against completed artifacts. They inspect symbol-derived release ranges only; no binary is executed and no type-layout campaign is included. Missing standalone helpers must be reported rather than assigned an old address. See `codegen/README.md` for the capture bounds and interpretation limits.
5. Run `taskset -c 6 python3 prepare_native.py` after the successful build binding. Root reviews the materialized scripts, actual code and host activity before releasing `study/native/run.py` with the pinned CPython directory first on PATH. Fresh preflights use CPU5; timing uses CPU0. The saved reader runs on CPU6 after reaping. Python and compatibility execution require later release.

Native measurement retains all 24 real and four generated conditions, seven seeded pairs, 84 fresh preflight plus 588 timed workers, and 106,176 samples. The original driver, worker, construction/callback/destruction boundaries, limits and arithmetic remain unchanged. Every adverse condition stays visible; affinity does not establish host isolation. Actual codegen and elapsed effects remain unmeasured. No result from the rejected compact-owner experiment is transferred.
