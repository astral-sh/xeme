# Held ordinary attribute codegen capture

Preparation only: neither script has run. Root runs `capture.py` and then `read.py` on CPU6 only after the candidate ordinary build and build binding have passed. No layout campaign, compiler, parser, benchmark, library execution, debug rebuild or dependency change is included.

Capture binds current source74, unchanged auxiliary files, actual SO/static hashes and release log to the future passed binding. Selected control is LF normal4ee8. It captures ELF notes and actual nm definitions from both current libraries. If present, it disassembles `literal_value_end`, `AttributeScanner::next_step` and `TagScanner::scan`. If TagScanner has no standalone symbol, it captures `Parser::next_event_inner` when available. Missing symbols are reported; old addresses are never substituted. At most three symbol ranges per engine are selected.

All tool commands use the existing45-second TERM/5-second-KILL bound and CPU6; process groups are reaped, failures remain in `capture.json`, and `DEBUGINFOD_URLS` is empty. Outputs are exclusively created under `/tmp/oriole-attribute-lane-masks-study/codegen`. Only readelf/nm/objdump inspect ELF files; none executes the library.

The saved reader independently reconstructs symbol selection/ranges, command vectors, raw hashes and actual library/source identities. It retains exact selected vector-mnemonic lines and call lines; it does not assert required SIMD, absent calls, predicted byte size or speed. Vector instructions in a larger parent are not automatically attributed to the attribute classifier. `address_lines_including_byte_wraps` is explicitly not an instruction count.

Required future binding schema matches the ordinary compact-owner recipe: passed `study/build-binding.json`, source_count74, sole source_delta `crates/oriole/src/tag.rs`, candidate_libraries/control_libraries, build_sha256/source_manifest_sha256, unchanged four auxiliary pins. `preparation/source-binding.json` must pin `codegen/capture.py` and `codegen/read.py`; base is `aed07bbacf75136330dd777a190ac2a42a2f1ed0`.

```sh
taskset -c 6 python3 -I -S /tmp/oriole-attribute-lane-masks-preparation/codegen/capture.py
taskset -c 6 python3 -I -S /tmp/oriole-attribute-lane-masks-preparation/codegen/read.py
```

The capture evolves the existing `/tmp/oriole-text-lane-masks-codegen.py` release-only recipe; command teardown comes from the reviewed compact-owner artifact capture. The adjacent source diffs document adaptation. No codegen or performance claim exists until those root-owned captures are complete and inspected.
