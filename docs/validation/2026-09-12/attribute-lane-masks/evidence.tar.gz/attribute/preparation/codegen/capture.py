"""Capture actual normal-release attribute scanner symbols; never run a library."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time
assert __debug__ and os.sched_getaffinity(0)=={6}
def interrupted(signum, frame):
 raise KeyboardInterrupt
signal.signal(signal.SIGTERM,interrupted)
PREP=Path(__file__).parent.parent;S=Path('/tmp/oriole-attribute-lane-masks-study');D=S/'codegen'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
binding=J(S/'build-binding.json');source=J(S/'source.json');prepared=J(PREP/'source-binding.json')
assert binding['status']=='passed' and binding['source_count']==74
assert source['base']==prepared['base']=='aed07bbacf75136330dd777a190ac2a42a2f1ed0'
assert set(binding['source_delta'])=={'crates/oriole/src/tag.rs'}
assert H(__file__)==prepared['scripts']['codegen/capture.py']
assert H(S/'source.json')==binding['source_manifest_sha256'] and H(S/'build.json')==binding['build_sha256']
assert len(source['sha256'])==74 and all(H(Path(source['worktree'])/n)==h for n,h in source['sha256'].items())
assert len(binding['auxiliary_files'])==4 and all(H(Path(source['worktree'])/n)==h for n,h in binding['auxiliary_files'].items())
assert not D.exists();D.mkdir()
pins={};rows=[];engines={};env=os.environ.copy();env['DEBUGINFOD_URLS']=''
r={'status':'incomplete','targets_executed':False,'engines':engines,'commands':rows,'pins':pins,'reader_sha256':H(__file__)}
def pin(p):p=Path(p);pins[str(p)]=H(p);return pins[str(p)]
def save():
 (D/'capture.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 argv=['/usr/bin/timeout','--signal=TERM','--kill-after=5s','45s','/usr/bin/taskset','-c','6',*args];start=time.time()
 with (D/(label+'.stdout')).open('xb') as out,(D/(label+'.stderr')).open('xb') as err:
  process=subprocess.Popen(argv,env=env,stdout=out,stderr=err,start_new_session=True)
  try:code=process.wait(timeout=51)
  except BaseException:
   os.killpg(process.pid,signal.SIGKILL);process.wait()
   rows.append({'label':label,'argv':argv,'exit':process.returncode,'reaped':True,'interrupted':True,'start':start,'end':time.time(),'stdout_sha256':H(D/(label+'.stdout')),'stderr_sha256':H(D/(label+'.stderr'))});save();raise
 rows.append({'label':label,'argv':argv,'exit':code,'reaped':True,'start':start,'end':time.time(),'stdout_sha256':H(D/(label+'.stdout')),'stderr_sha256':H(D/(label+'.stderr'))});save();assert code==0,(label,code)
 return (D/(label+'.stdout')).read_text()
try:
 for p in ['/usr/bin/readelf','/usr/bin/nm','/usr/bin/objdump','/usr/bin/timeout','/usr/bin/taskset',__file__,PREP/'source-binding.json',PREP/'source.json',S/'source.json',S/'build.json',S/'build-binding.json']:pin(p)
 for engine,study in [('control',Path('/tmp/oriole-text-lane-masks-study')),('candidate',S)]:
  b=J(study/'build.json');s=J(study/'source.json');assert b['status']=='passed' and b['source_unchanged']
  prefix='' if engine=='candidate' else 'control_'
  assert H(study/'source.json')==binding[prefix+'source_manifest_sha256']
  assert H(study/'build.json')==binding[prefix+'build_sha256']
  expected=binding[engine+'_libraries'];assert b['libraries']==expected
  assert len(s['sha256'])==74 and all(H(Path(s['worktree'])/n)==h for n,h in s['sha256'].items())
  for file in ['build.json','source.json','release.log','rustc-version.log']:pin(study/file)
  release=next(c for c in b['commands'] if c['label']=='release');assert release['exit']==0 and release['reaped'] and release['log_sha256']==H(study/'release.log')
  for name,h in expected.items():assert pin(study/'normal'/name)==h
  so=study/'normal/liboriole_expat.so';assert so.read_bytes()[:4]==b'\x7fELF'
  if engine=='control':assert H(so)=='4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d'
  elf=run(engine+'-elf',['/usr/bin/readelf','--wide','--file-header','--notes',str(so)])
  text=run(engine+'-symbols',['/usr/bin/nm','-S','-C','--defined-only',str(so)])
  wanted={'literal':'oriole::tag::literal_value_end','attribute':'oriole::tag::AttributeScanner::next_step','tag':'oriole::tag::TagScanner::scan','parent':'oriole::Parser::next_event_inner'};found={}
  for line in text.splitlines():
   m=re.fullmatch(r'([0-9a-f]+) ([0-9a-f]+) [tT] (.+)',line)
   if not m:continue
   canonical=m[3].replace('<','').replace('>','')
   for key,name in wanted.items():
    if canonical==name:
     assert key not in found,(engine,key)
     found[key]={'symbol':m[3],'address':int(m[1],16),'bytes':int(m[2],16)}
  selected=[key for key in ['literal','attribute','tag'] if key in found]
  if 'tag' not in found and 'parent' in found:selected.append('parent')
  e={'study':str(study),'library':str(so),'library_sha256':H(so),'source_manifest_sha256':H(study/'source.json'),'worktree':s['worktree'],'build_id':re.search(r'Build ID: ([0-9a-f]+)',elf)[1],'available_symbols':found,'captured':selected,'missing_symbols':[key for key in wanted if key not in found]};engines[engine]=e
  for key in selected:
   x=found[key];assert x['bytes']>0
   run(engine+'-'+key,['/usr/bin/objdump','-d','-C','--start-address='+str(x['address']),'--stop-address='+str(x['address']+x['bytes']),str(so)])
 for p,h in pins.items():assert H(p)==h,p
 r.update(status='captured_current_release_attribute_disassembly',scope='Actual current normal libraries only. Missing standalone helpers are recorded; TagScanner is retained when available, otherwise next_event_inner is the bounded parent fallback. No debug rebuild, old addresses, codegen flags, parser execution or performance claim.')
finally:save()
print(json.dumps({'status':r['status'],'capture_sha256':H(D/'capture.json'),'commands':len(rows),'symbols':{e:v['captured'] for e,v in engines.items()}},indent=2))
