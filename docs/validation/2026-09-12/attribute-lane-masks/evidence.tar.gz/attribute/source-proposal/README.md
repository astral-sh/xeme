# Held quoted-attribute first-stop prototype

One changed file, `source/crates/oriole/src/tag.rs`, based on frozen LF candidate `cacc0b1b3766176e9cbf71d25c5ff6867fa87c08`. This is an unselected source proposal. No worktree/Cargo files changed; no formatting, compilation, test, codegen, parser or benchmark target ran. It reuses cacc's existing wide dependency and requires a separately authorized composition if that dependency/runtime is not selected.

## Change

Before the unchanged8-byte/scalar tail, a bounds-checked full16-byte load forms a signed byte mask for the active quote, `<`, `&`, C0 and non-ASCII. A zero mask skips16. A nonzero mask advances to its first set lane and immediately enters the original scalar delimiter/uncertainty logic. This avoids re-probing overlapping word suffixes near a special byte. Unlike Text, all LF/TAB/CR require attribute normalization; no newline counts or position changes are introduced.

The current fallback when `literal_ascii` was already false is unchanged. If a first stop is quote or `<`, the helper returns its exact offset without changing the proof flag. Otherwise it flips the flag and performs the same memchr2 search on the suffix beginning at that byte. Valid non-ASCII values can still complete a native plan through the existing Unicode eligibility predicate. Bytes after the first delimiter do not affect the flag or error precedence.

Safety and behavior remain bounded: every vector load requires first_chunk::<16>(); a set bit is in lanes0–15, so the indexed stop remains within that load. The offset cannot exceed the slice. There is no pointer cast, unsafe block, allocation, new persistent field, general-scanner change, token-limit change or callback/ownership change. Active quote is dynamic; the opposite quote and `]` are ordinary, DEL remains ordinary, and all high bytes end the ASCII proof.

## Coverage prepared, not executed

One new test compares actual helper return offset and final eligibility against an independent byte-prefix oracle for both active quotes and both initial flag states. It covers every256 byte value at offsets0–31 (including stop0 with a full vector), both orderings of delimiter/uncertainty across7/8,15/16 and31/32, and plain/special end-of-input tails0–31 after0/16/32 ordinary bytes. Invalid bytes after a delimiter are explicitly retained in the full-vector cases.

All prior scanner/general attribute oracles, every-feed-split equivalence, valid-Unicode completed-plan assertions, ampersand incomplete→fallback timing, names and token limits remain byte-for-byte unchanged. The preparation's inverse source check removes precisely the import, new vector branch and test, then requires complete equality with the original file, including the8-byte/scalar implementation. All74 measured base files and auxiliary files were checked against the frozen cacc build source; the baseline tag was also read directly from its committed Git blob.

## Opportunity and later gates

The saved exact-object analysis is `/tmp/oriole-literal-value-mask-current-triage/README.md`: earlier ea52004/ef1648 Vulkan has667,152 full word probes and345,582 ordinary scalar advances; the five disjoint inlined classifier regions account for3.881% of collected instructions. Maven's equivalent is0.02954%. These are earlier instruction counts, not current runtime cost or projected savings. The report excludes callee-object/inclusive attribution and preserves the reader's manifest-key correction.

If separately authorized, format and inspect the composed patch, run the unchanged full normal checks plus the focused tag tests, and inspect actual generic release codegen before a full comparison. Check dynamic quote broadcasting/constant setup, no per-block out-of-line calls, no substituted metadata copies and no new target features. A full sixteen-byte classifier can still lose on short tails or non-SIMD backends. Compare all28 native and24 Python conditions against the then-selected runtime, preserve adverse outcomes, and retain the normal correctness gates. No adoption or speed result is claimed here.

The C small-Start temporary-Vec idea remains only a separate note; this patch does not contain it. Existing fixed16 Text rejection and pending LF Text decisions remain independent evidence.
