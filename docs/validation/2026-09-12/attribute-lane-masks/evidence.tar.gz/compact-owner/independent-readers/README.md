# Held compact-owner saved readers

Source preparation only. Neither reader has run; no partial build, layout or benchmark output was inspected. Root supplies completed artifact hashes and the exact committed candidate identity before releasing either command. These readers never execute a compiler, parser, profiler or measurement target. Only the first reader makes read-only Git blob/diff calls.

## Build and layout

`build_layout.py` reuses every completed build binder assertion, with only its output-existence guard and final writer removed in memory. It reparses actual ordered compiler/dependency vectors, verifies all seven command logs and successful reaping, full456-test/35-summary results, generic ordinary release flags, exact source/auxiliary/library/tool identities and final candidate Git blobs. It then replays the unchanged saved DWARF parser without its writer and independently verifies the actual debug ELF selected from tests.log and all bounded readelf/nm/objdump command vectors/symbol ranges. Element and Parser sizes are derived; 88 bytes is never asserted. No release-copy width or total-memory saving is inferred.

After root supplies completed hashes and a runtime commit:

```sh
taskset -c 6 python3 -I -S /tmp/oriole-compact-conversion-owner-independent-readers/build_layout.py \
  --build-binding-sha BUILD_BINDING_SHA \
  --layout-report-sha LAYOUT_REPORT_SHA \
  --candidate-so CANDIDATE_SO_SHA \
  --runtime-commit RUNTIME_COMMIT
```

Output: `/tmp/oriole-compact-conversion-owner-independent-build-layout-review.json`, exclusive creation.

## Native raw data and host activity

`native.py` adapts the prior LF independent reader. The source-bound current reader prefix reconstructs all672 workers/106176 samples/28 conditions from saved bytes. Every condition, paired median and adverse row is retained, with geometric products independently recomputed. No expected winner or adverse count is hardcoded. It requires the completed build/layout review and current native preparation/primary report hashes.

The monitor must equal the previously reviewed confirmation monitor (`bcfd3b9b…`). All supplied before observations are preserved in order. During-host fractions use only consecutive intervals fully inside the native timing-phase timestamps; crossing intervals are retained but excluded without interpolation. Interval counts and idle fractions are derived. CPU0 affinity and these counters do not establish global host isolation, and raw workers cannot be correlated individually to absolute host timestamps.

```sh
taskset -c 6 python3 -I -S /tmp/oriole-compact-conversion-owner-independent-readers/native.py \
  --primary-review-sha PRIMARY_NATIVE_REVIEW_SHA \
  --preparation-sha NATIVE_PREPARATION_SHA \
  --build-layout-review-sha INDEPENDENT_BUILD_LAYOUT_REVIEW_SHA \
  --candidate-so CANDIDATE_SO_SHA \
  --runtime-commit RUNTIME_COMMIT
```

Default before record: `host-before-native.json`. If root takes several observations, pass every basename in chronological order with repeated `--host-before NAME.json`. Output: `/tmp/oriole-compact-conversion-owner-independent-native-raw-review.json`, exclusive creation. Redirect each attempted execution to new stdout/stderr files; preserve failures and do not rerun targets to repair reader assumptions.

The baseline is LF normal4ee8 and Expat normal7a333. Dependency metadata remains inherited and unchanged; no PGO, target-cpu or new build recipe is introduced. The preparation binds formatted source08948, source-binding4f80 and expected-mapf3c282. The original peer recipe review36cd605d refers to the preserved pre-format expected map; its forthcoming formatting addendum must be kept separate rather than relabelled as the original review.
