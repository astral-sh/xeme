"""Held saved-only build/layout replay; never execute a compiler or target."""
from pathlib import Path
import argparse,ast,hashlib,json,os,re,subprocess
assert __debug__ and os.sched_getaffinity(0)=={6}
a=argparse.ArgumentParser()
for option in ['build-binding-sha','layout-report-sha','candidate-so','runtime-commit']:a.add_argument('--'+option,required=True)
a=a.parse_args()
assert all(re.fullmatch('[0-9a-f]{64}',v) for v in [a.build_binding_sha,a.layout_report_sha,a.candidate_so])
assert re.fullmatch('[0-9a-f]{40}',a.runtime_commit)
P=Path('/tmp/oriole-compact-conversion-owner-preparation');S=Path('/tmp/oriole-compact-conversion-owner-study');D=S/'layout'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
static={P/'source-binding.json':'4f80f25b0faa88179f07af5e1d63fe1f61bbe58e28be57da238efe4e123dfcde',P/'source.json':'08948e54d32402f33168bdf65e1b549db7bae5022ea39f4578cafc3a37f8365d',P/'expected-source.json':'f3c2828572aa67bb68c5cc11179dae91f808eab74573c7eace61aedfe9056bd1',P/'bind_build.py':'50a36f7cf1be5bd34c13ae72b1de445a1cd507e53ae86c8000a5f6bdabbe5f25',P/'layout/read.py':'2f8b0dee3ac1f89c84a606da2624b183deaaf0fa297297da93ca87c434c7661e',P/'layout/capture.py':'0006507e1c1444438d8717471f2256708bda316a1b396cd16cc9c3419a375338'}
for p,h in static.items():assert H(p)==h,p
assert H(S/'build-binding.json')==a.build_binding_sha
assert H(D/'report.json')==a.layout_report_sha
# Replay exact actual-vector/source/check assertions, dropping only the original
# output-existence guard and outer try/finally writer. Git reads remain read-only.
binder=P/'bind_build.py';text=binder.read_text();tree=ast.parse(text)
cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Try))
prefix=[];removed=[]
for n in tree.body[:cut]:
 if isinstance(n,ast.Assert) and ast.get_source_segment(text,n)=='assert not report_path.exists()':removed.append(n)
 else:prefix.append(n)
assert len(removed)==1
body=prefix+tree.body[cut].body
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','mkdir','unlink'} for node in body for n in ast.walk(node))
scope={'__file__':str(binder),'__name__':'independent_saved_build_replay'}
exec(compile(ast.Module(body=body,type_ignores=[]),str(binder),'exec'),scope)
binding=J(S/'build-binding.json');assert binding==scope['report']
assert binding['tests']=={'passed':456,'groups':35,'failures':0,'ignored':0}
assert binding['candidate_libraries']['liboriole_expat.so']==a.candidate_so
assert binding['control_libraries']['liboriole_expat.so']=='4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d'
source=J(S/'source.json');W=Path(source['worktree']);aux=binding['auxiliary_files']
assert len(source['sha256'])==74 and len(aux)==4
for n,h in {**source['sha256'],**aux}.items():
 assert hashlib.sha256(subprocess.check_output(['git','-C',str(W),'show',a.runtime_commit+':'+n])).hexdigest()==h,n
# Replay saved DWARF parsing only, before its report write. Sizes are observations.
reader=P/'layout/read.py';text=reader.read_text();tree=ast.parse(text)
cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.With))
assert "report.json" in ast.get_source_segment(text,tree.body[cut])
body=tree.body[:cut]
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','check_output','mkdir','unlink'} for node in body for n in ast.walk(node))
layout={'__file__':str(reader),'__name__':'independent_saved_layout_replay'}
exec(compile(ast.Module(body=body,type_ignores=[]),str(reader),'exec'),layout)
assert J(D/'report.json')==layout['out']
capture=J(D/'capture.json');assert capture['status']=='saved_artifact_capture_complete' and capture['targets_executed'] is False
assert capture['reader_sha256']==H(P/'layout/capture.py')
assert set(capture['engines'])=={'control','candidate'}
expected={};prefix=['/usr/bin/timeout','--signal=TERM','--kill-after=5s','45s','/usr/bin/taskset','-c','6']
for engine,study in [('control',Path('/tmp/oriole-text-lane-masks-study')),('candidate',S)]:
 e=capture['engines'][engine];b=J(study/'build.json');s=J(study/'source.json')
 assert e['study']==str(study) and e['worktree']==s['worktree']
 paths=re.findall(r'Running unittests src/lib.rs \(([^)]+/oriole-[^)]+)\)',(study/'tests.log').read_text());assert paths==[e['debug_elf']]
 assert Path(e['debug_elf']).read_bytes()[:4]==b'\x7fELF' and H(e['debug_elf'])==e['debug_sha256']
 so=study/'normal/liboriole_expat.so';assert e['normal_so']==str(so) and e['normal_sha256']==H(so)==b['libraries'][so.name]
 expected[engine+'-elf']=prefix+['/usr/bin/readelf','--wide','--file-header','--section-headers','--notes',e['debug_elf']]
 expected[engine+'-dwarf']=prefix+['/usr/bin/readelf','--wide','--debug-dump=info','--debug-dump=no-follow-links','--dwarf-depth=4',e['debug_elf']]
 expected[engine+'-symbols']=prefix+['/usr/bin/nm','-S','--defined-only','--demangle',str(so)]
 symbols=[]
 for line in (D/(engine+'-symbols.stdout')).read_text().splitlines():
  m=re.match(r'^([0-9a-f]+) ([0-9a-f]+) [tT] (.+)$',line)
  if m and re.fullmatch(r'(?:oriole::Parser|<oriole::Parser>)::(?:prepare_end_frame|end_element|parse_start|parse_start_frame)',m[3]):
   address,size=int(m[1],16),int(m[2],16);symbols.append({'symbol':m[3],'address':m[1],'size':size})
   expected[engine+'-'+m[3].split('::')[-1]]=prefix+['/usr/bin/objdump','-d','-C','--start-address='+hex(address),'--stop-address='+hex(address+size),str(so)]
 assert symbols==e['disassembled_symbols']
assert len(capture['commands'])==len(expected)
for r in capture['commands']:
 assert r['command']==expected[r['label']] and r['exit']==0 and r['reaped'] and r['end']>=r['start']
 for stream in ['stdout','stderr']:assert H(D/(r['label']+'.'+stream))==r[stream+'_sha256']
for p,h in capture['pins'].items():assert H(p)==h,p
r={'status':'passed_independent_saved_build_and_layout_review','targets_executed':False,'runtime_commit':a.runtime_commit,'source_count':74,'source_delta':binding['source_delta'],'auxiliary_files':aux,'tests':binding['tests'],'candidate_libraries':binding['candidate_libraries'],'control_libraries':binding['control_libraries'],'actual_core_compiler_vectors':J(S/'build.json')['compiler_vectors'],'actual_dependency_compiler_vectors':J(S/'build.json')['dependency_compiler_vectors'],'sizes':layout['sizes'],'debug_deltas':layout['delta'],'layout_capture_commands':len(expected),'release_copy_width':'Not inferred; actual symbol ranges are retained. No predicted size was asserted.','findings':[],'roles':'Independent saved execution of previously reviewed binder assertions and DWARF reader, with separate Git-commit and actual artifact-command verification. Root owned all compiler/parser and artifact-capture invocations.','limitations':['Debug layout alone proves neither release layout nor net memory/elapsed benefit.','Shared converted owners add rare allocator/refcount header and atomic final-drop work; not quantified here.'],'pins':{str(p):h for p,h in static.items()}|{str(S/'build-binding.json'):a.build_binding_sha,str(D/'report.json'):a.layout_report_sha,str(D/'capture.json'):H(D/'capture.json'),str(S/'source.json'):H(S/'source.json'),str(S/'build.json'):H(S/'build.json')},'reader_sha256':H(__file__)}
out=Path('/tmp/oriole-compact-conversion-owner-independent-build-layout-review.json')
with out.open('x') as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'sizes':r['sizes'],'receipt':str(out),'sha256':H(out)},indent=2))
