# Compact converted-name owner: held normal native protocol

Candidate composes the reviewed two-line Shared owner change and allocation test onto the LF runtime. Control is the measured LF normal4ee8 library; Expat is the original normal7a333 library. All sources, dependencies, compiler flags and library outputs are bound before materialization. The projected Element120 to88 size is unmeasured until the artifact-only layout read completes.

All24 real and four generated conditions retain seven seeded pairs,84 fresh preflight workers,588 timed workers and106176 samples. Workers include parser construction, handlers, feeds, callbacks and destruction; digests merge text fragments. Every adverse row remains. No compiler, profile or CPU-target setting changes.

Root alone releases execution after completed builds, binding, layout inspection and host observations. Run run.py with the pinned CPython directory first on PATH: CPU5 preflights600s, then CPU0 elapsed1200s, workers90s. Saved reader CPU6 afterward. Affinity does not establish global host isolation. Python remains a later root decision; no target ran during preparation.
