# Compact converted-name owner: held ordinary protocol

No worktree, formatter, compiler, parser, layout reader or benchmark has run for this preparation. Root must supply the future documentation base commit after publishing the LF candidate. That base must contain the exact 74 measured LF source files from `cacc0b1b3766176e9cbf71d25c5ff6867fa87c08`.

The reviewed proposal changes `Element::raw_encoding` from the allocator-carrying optional Box to the existing optional Shared owner, constructed at the same point. The two changed files compose exactly onto LF: `crates/oriole/src/lib.rs` and `crates/oriole/tests/allocation.rs`. All dependency manifests, lockfiles and four auxiliary manifest/lock pins remain unchanged. Proposal review: `/tmp/oriole-shared-conversion-owner-independent-source-review.json`, SHA `68cba29090c15947f3ed3dc6e17a180fa3e1615eb97962aed129516461b94c02`.

## Controls and build

- Candidate: future `/home/dev-user/code/oss/oriole-compact-conversion-owner`, target `/home/dev-user/.cache/oriole/compact-conversion-owner-target`, output `/tmp/oriole-compact-conversion-owner-study`.
- Control: existing LF ordinary library `4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d` under `/tmp/oriole-text-lane-masks-study/normal`.
- Expat: original normal `7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478`; its historical directory name does not change the ordinary build identity.

`build.py` retains the LF environment cleanup, process-group teardown and all seven command/release bodies byte-for-byte: compiler identity, workspace format check, workspace tests, strict all-target Clippy, inprocess benchmark format/Clippy and ordinary generic x86-64 O3/ThinLTO/one-codegen-unit release. No compiler optimization, dependency, ISA or PGO changes are introduced. The full workspace suite includes the new conversion-owner OOM test and the existing multibyte/matching-End tests. Expected results are 456 tests across 35 summaries, including the same documentation test; any mismatch stops the binder for review.

`bind_build.py` reads actual release vectors and compares all three core and three dependency vectors against the LF control. It retains all ordered flags and externs, including `wide`; only known Cargo identifiers/dependency filenames, resolved compiler paths and shared build paths are normalized. The inherited dependency metadata/feature receipts are identified as historical and valid because the relevant manifests and locks are unchanged. Both library outputs must match the actual isolated target outputs.

## Root-owned sequence

1. Create the isolated Cargo worktree at the final supplied base, apply only the reviewed proposal and format it. These scripts do not create or edit that worktree.
2. Run `taskset -c 6 python3 bind_source.py FUTURE_BASE_SHA`. It checks checkout/common Git identity, all base blobs, all current source and auxiliary bytes, and the exact two-file diff before writing local source/patch/script bindings. If formatting changes the proposed bytes, stop and explicitly review/refreeze the expected map; no automatic acceptance is implemented.
3. Run `taskset -c 4 python3 build.py`, then `taskset -c 6 python3 bind_build.py`. Every compiler/test child has the original 900-second bound and is reaped. Both scripts preserve failed records.
4. After a saved-artifact release, run `taskset -c 6 python3 layout/capture.py` and `taskset -c 6 python3 layout/read.py`. These invoke only bounded `readelf`, `nm` and `objdump` readers, each limited to 45 seconds, against the exact debug test ELF discovered in each build's `tests.log` and the exact ordinary DSO. `DEBUGINFOD_URLS` is empty. No binary is executed.
5. Run `taskset -c 6 python3 prepare_native.py` only after the successful build binding. It creates the future `study/native` scripts and pins; it does not run a target.
6. Root separately reviews artifacts and host activity before releasing native `run.py`: unchanged CPU5 preflights, then CPU0 timing, using the pinned CPython directory first on PATH. Saved `read_results.py` runs on CPU6 after reaping. Python remains a later decision.

## Measurement limits

Native retains all 24 real plus four generated conditions, seven seeded pairs, 84 fresh preflight and 588 timed workers, and 106,176 samples. Parser construction, handlers, feeds, callbacks and destruction remain timed. The driver, worker body, scheduling and arithmetic are unchanged; every adverse condition remains visible. Affinity and local scheduling do not establish a globally isolated host.

`Element` 120→88 bytes is a prediction. The layout reader records actual Element/Parser sizes without asserting that prediction, and retains current release function disassembly. Attribution of an End-copy width requires tracing those actual source/destination/stride instructions; no old addresses or byte counts are reused. A smaller inline owner adds an allocator/refcount header and atomic final-drop work for rare converted names. Layout alone proves neither a total-memory reduction nor an elapsed improvement.

The six prepared scripts and exact inputs are pinned in `prepared.json`. All execution remains held; source and library binding requires the future base and completed root-owned build.
