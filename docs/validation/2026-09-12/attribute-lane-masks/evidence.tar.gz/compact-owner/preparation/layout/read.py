from pathlib import Path
import hashlib,json,os,re
assert os.sched_getaffinity(0)=={6}
D=Path('/tmp/oriole-compact-conversion-owner-study/layout');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text());capture=J(D/'capture.json');layouts={}
for engine,e in capture['engines'].items():
 lines=(D/(engine+'-dwarf.stdout')).read_text().splitlines();nodes=[];current=None;parents={};cu=None
 for n,line in enumerate(lines):
  m=re.match(r' <(\d+)><([0-9a-f]+)>: (.*)',line)
  if m:
   depth=int(m[1]);tag=re.search(r'\((DW_TAG_[^)]+)\)',m[3]);current={'depth':depth,'offset':m[2],'kind':tag[1] if tag else None,'attrs':{},'line':n+1,'parent':parents.get(depth-1),'cu':cu};nodes.append(current);parents[depth]=current
   if current['kind']=='DW_TAG_compile_unit':cu=current;current['cu']=current
  elif current:
   m=re.search(r'DW_AT_(\w+)\s*:\s*(.*)$',line)
   if m:current['attrs'][m[1]]=m[2]
 def textattr(v):return v.rsplit('): ',1)[-1] if '): ' in v else v
 def name(n):return textattr(n['attrs'].get('name',''))
 def number(v):return int(v.rsplit(' ',1)[-1],0)
 layouts[engine]={}
 for target in ['Element','Parser']:
  found=[n for n in nodes if n['kind']=='DW_TAG_structure_type' and name(n)==target and n['parent'] and name(n['parent'])=='oriole'];assert found
  signatures=[]
  for n in found:
   members=[c for c in nodes if c['kind']=='DW_TAG_member' and c['parent'] is n]
   signatures.append((number(n['attrs']['byte_size']),number(n['attrs']['alignment']),{name(c):number(c['attrs']['data_member_location']) for c in members}))
   assert textattr(n['cu']['attrs']['comp_dir'])==e['worktree']
   assert 'rustc version 1.98.1-dev (f62703110 2026-09-08) (ohm-1.98.1-1)' in n['cu']['attrs']['producer']
   assert textattr(n['cu']['attrs']['name']).startswith('crates/oriole/src/lib.rs/@/')
  assert all(sig==signatures[0] for sig in signatures)
  first=found[0];members=[c for c in nodes if c['kind']=='DW_TAG_member' and c['parent'] is first]
  selected=[c for c in members if target=='Element' or name(c) in ['stack','namespace_scopes','namespaces']]
  layouts[engine][target]={'byte_size':signatures[0][0],'alignment':signatures[0][1],'identical_dies':len(found),'die_offset':'0x'+first['offset'],'raw_line':first['line'],'members':[{'name':name(c),'offset':number(c['attrs']['data_member_location']),'type_reference':c['attrs']['type'],'die_offset':'0x'+c['offset']} for c in selected],'compilation_unit':first['cu']['attrs']}
 headers=(D/(engine+'-elf.stdout')).read_text();assert '.debug_info' in headers and '.debug_line' in headers
 layouts[engine]['elf_build_id']=re.search(r'Build ID: ([0-9a-f]+)',headers)[1]
# Report observed sizes instead of asserting a predicted layout or reusing old PCs.
for row in capture['commands']:
 assert row['exit']==0 and row['reaped']
 for channel in ['stdout','stderr']:assert H(D/(row['label']+'.'+channel))==row[channel+'_sha256']
for path,h in capture['pins'].items():assert H(path)==h,path
sizes={engine:{name:row['byte_size'] for name,row in value.items() if name in ['Element','Parser']} for engine,value in layouts.items()}
delta={name:sizes['candidate'][name]-sizes['control'][name] for name in ['Element','Parser']}
out={'status':'verified_saved_debug_layout_and_retained_release_disassembly','targets_executed':False,
     'layouts':layouts,'debug_deltas':delta,'expected_but_not_asserted':{'Element_control':120,'Element_candidate':88},
     'release_functions':{engine:e['disassembled_symbols'] for engine,e in capture['engines'].items()},
     'release_copy_width':'Not inferred automatically. Exact function bodies retained for source/destination/stride attribution after inspection; no previous-study addresses or width assertions transferred.',
     'limitations':['DWARF describes the existing debug test artifacts; it alone does not prove every release type layout or an elapsed benefit.',
                    'All current normal function addresses and bytes are retained separately. Missing/inlined symbols are reported without rebuilding to manufacture them.',
                    'A smaller inline owner can increase rare converted-owner heap requests and atomic final-drop work. No peak-memory, allocator-byte or throughput claim follows from this layout receipt.'],
     'capture_sha256':H(D/'capture.json'),'reader_sha256':H(__file__),'pins':capture['pins'],
     'role':'Adapted existing saved-artifact recipe; no compiler, test binary, parser, profiler or benchmark executed.'}
with (D/'report.json').open('x') as stream:stream.write(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'sizes':sizes,'debug_deltas':delta,'sha256':H(D/'report.json')},indent=2))
