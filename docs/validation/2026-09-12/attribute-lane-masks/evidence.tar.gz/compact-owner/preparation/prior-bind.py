"""Compare the completed candidate build to the selected normal build."""
from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import subprocess

assert __debug__ and os.sched_getaffinity(0) == {6}
root = Path('/home/dev-user/code/oss/oriole-text-lane-masks')
out = Path('/tmp/oriole-text-lane-masks-study')
control = Path('/tmp/oriole-namespace-scopes-study')
base = 'b6985f0d07e9b3456f36f77eac97cf7bf013a650'
read = lambda path: json.loads(Path(path).read_text())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
report_path = out / 'build-binding.json'
assert not report_path.exists()
report = {'status': 'incomplete', 'scope': 'Saved normal source/compiler/artifact comparison only. No target execution or compiler-setting changes.'}

def normalize(vector):
    return [str(Path(vector[0]).resolve(strict=True))] + [
        re.sub(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}(?=/)', '@WORKSPACE_BUILD@', arg)
        for arg in vector[1:]
    ]

def vectors(values):
    result = {v[v.index('--crate-name') + 1]: normalize(v) for v in values}
    assert len(values) == len(result) == 3
    assert set(result) == {'oriole', 'oriole_expat', 'oriole_storage'}
    return result


def policy_vector(vector, crate, candidate):
    """Retain flags/order; normalize Cargo identities and exactly one new dependency."""
    result=[];i=0;wide=0
    while i<len(vector):
        value=vector[i]
        if value=='--extern' and vector[i+1].startswith('wide='):
            assert candidate and crate=='oriole'
            wide+=1;i+=2;continue
        if value=='-C' and vector[i+1].startswith(('metadata=','extra-filename=')):
            result.extend([value,vector[i+1].split('=',1)[0]+'=@CARGO_ID@']);i+=2;continue
        value=re.sub(r'(lib(?:allocator_api2|hashbrown|memchr|oriole|oriole_storage))-[0-9a-f]{16}(?=\.r(?:lib|meta)$)',r'\1-@CARGO_ID@',value)
        result.append(value);i+=1
    assert wide == int(candidate and crate=='oriole')
    return result

try:
    build, old = read(out / 'build.json'), read(control / 'build.json')
    source, old_source = read(out / 'source.json'), read(control / 'source.json')
    old_binding = read(control / 'build-binding.json')
    assert build['status'] == old['status'] == old_binding['status'] == 'passed'
    assert build['source_unchanged'] and old['source_unchanged']
    assert old_binding['build_sha256'] == sha(control / 'build.json')
    assert old_binding['source_manifest_sha256'] == sha(control / 'source.json')
    assert source['base'] == base
    assert sha(out / 'source.json') == build['source_sha256']
    assert sha(control / 'source.json') == old['source_sha256']
    assert set(source['sha256']) == set(old_source['sha256']) and len(source['sha256']) == 74
    prepared = read('/tmp/oriole-text-lane-masks-preparation/source.json')
    assert sha('/tmp/oriole-text-lane-masks-preparation/source.json') == '13408d5ae11c9108b651f401414aef6ced9286755a65ae188b64741461dc7e6e'
    assert prepared['base'] == base and prepared['source_count'] == 74
    assert source['sha256'] == prepared['sha256']
    assert all(sha(root / p) == h for p, h in source['sha256'].items())
    for name, digest in old_source['sha256'].items():
        data = subprocess.check_output(['git', 'show', base + ':' + name], cwd=root)
        assert hashlib.sha256(data).hexdigest() == digest
    delta = {name: {'control': old_source['sha256'].get(name), 'candidate': value}
             for name, value in source['sha256'].items() if value != old_source['sha256'].get(name)}
    assert set(delta) == {'Cargo.lock', 'crates/oriole/Cargo.toml', 'crates/oriole/src/encoding.rs', 'crates/oriole/src/text.rs', 'crates/oriole/tests/text_coalescing.rs'}
    assert source['sha256']['crates/oriole/src/tag.rs'] == old_source['sha256']['crates/oriole/src/tag.rs']
    assert sha(out / 'candidate.patch') == prepared['complete_patch_sha256']
    assert (out / 'candidate.patch').read_bytes() == Path('/tmp/oriole-text-lane-masks-preparation/candidate.patch').read_bytes()
    assert set(delta) == set(prepared['changed'])
    actual_patch = subprocess.check_output(['git', 'diff', base, '--', *sorted(delta)], cwd=root)
    assert actual_patch == (out / 'candidate.patch').read_bytes()
    preparation_root = Path('/tmp/oriole-text-lane-masks-preparation')
    auxiliary = prepared['auxiliary_sha256']
    assert build['auxiliary_files'] == auxiliary and build['auxiliary_unchanged']
    assert set(auxiliary) == {'benchmarks/inprocess/Cargo.toml', 'benchmarks/inprocess/Cargo.lock', 'fuzz/Cargo.toml', 'fuzz/Cargo.lock'}
    assert all(sha(root / name) == digest for name,digest in auxiliary.items())
    metadata_receipt_path = preparation_root / 'format-metadata.json'
    metadata_receipt = read(metadata_receipt_path)
    assert sha(metadata_receipt_path) == prepared['format_metadata_receipt_sha256'] == build['metadata_receipt_sha256']
    assert metadata_receipt['status'] == 'passed'
    assert {r['label'] for r in metadata_receipt['commands']} == {'format', 'main', 'benchmark', 'fuzz'}
    for command in metadata_receipt['commands']:
        assert command['exit'] == 0 and command['reaped']
        for stream,digest in command['output_sha256'].items():
            assert sha(preparation_root / (command['label']+'.'+stream)) == digest
    complete_patch = preparation_root / 'complete-candidate.patch'
    assert sha(complete_patch) == prepared['complete_seven_file_patch_sha256'] == 'b64dfcfeb2f6a1d45e034145352860270c06bc48cdd8ce2ed62692eee1a1ea8b'
    full_delta = set(delta) | {'benchmarks/inprocess/Cargo.lock', 'fuzz/Cargo.lock'}
    assert set(subprocess.check_output(['git','diff',base,'--name-only'],cwd=root,text=True).splitlines()) == full_delta
    assert subprocess.check_output(['git','diff',base,'--',*sorted(full_delta)],cwd=root) == complete_patch.read_bytes()
    dependency_review_path = preparation_root / 'metadata-independent-review.json'
    assert build['dependency_review_sha256'] == sha(dependency_review_path) == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
    dependency_review = read(dependency_review_path)
    assert dependency_review['status'] == 'passed_saved_metadata_review'
    assert dependency_review['source_manifest_sha256'] == sha(preparation_root / 'source.json')
    commands = {row['label']: row for row in build['commands']}
    old_commands = {row['label']: row for row in old['commands']}
    assert set(old_commands) == {'rustc-version', 'fmt', 'tests', 'clippy', 'release'}
    assert set(commands) == set(old_commands) | {'benchmark-fmt', 'benchmark-clippy'}
    expected_aux_commands = {
        'benchmark-fmt':['cargo','+ohm','-Zohm-defaults=no','fmt','--manifest-path','benchmarks/inprocess/Cargo.toml','--check'],
        'benchmark-clippy':['cargo','+ohm','-Zohm-defaults=no','clippy','--manifest-path','benchmarks/inprocess/Cargo.toml','--all-targets','--locked','--offline','--','-D','warnings'],
    }
    for label, row in commands.items():
        assert row['exit'] == 0 and row['reaped']
        assert row['argv'] == (old_commands[label]['argv'] if label in old_commands else expected_aux_commands[label])
        assert row['pid'] > 0 and row['end'] >= row['start']
        assert sha(out / (label + '.log')) == row['log_sha256']
    assert build['rustc'] == old['rustc'] == (out / 'rustc-version.log').read_text()
    parsed_vectors = []
    dependency_vectors = []
    for line in (out / 'release.log').read_text().splitlines():
        if 'Running `' in line and '/rustc ' in line:
            vector = shlex.split(line.strip()[len('Running `'):-1])
            if vector[vector.index('--crate-name') + 1] in {'wide','safe_arch','bytemuck'}:
                dependency_vectors.append(vector)
            if vector[vector.index('--crate-name') + 1] in {'oriole', 'oriole_expat', 'oriole_storage'}:
                parsed_vectors.append(vector)
    assert parsed_vectors == build['compiler_vectors']
    assert dependency_vectors == build['dependency_compiler_vectors']
    assert len(dependency_vectors) == 3
    dependency_by_name = {v[v.index('--crate-name')+1]:v for v in dependency_vectors}
    assert set(dependency_by_name) == {'wide','safe_arch','bytemuck'}
    metadata = read(preparation_root / 'main.stdout')
    packages = {p['name']:p for p in metadata['packages']}
    for name, vector in dependency_by_name.items():
        lib_target, = [t for t in packages[name]['targets'] if t['kind'] == ['lib']]
        assert lib_target['src_path'] in vector
        assert vector[vector.index('--target')+1] == 'x86_64-unknown-linux-gnu'
        assert 'opt-level=3' in vector and 'codegen-units=1' in vector and 'linker-plugin-lto' in vector
        assert not any('profile-generate' in x or 'profile-use' in x or 'target-cpu' in x or 'target-feature' in x for x in vector)
        features = {vector[i+1] for i,x in enumerate(vector) if x == '--cfg'}
        assert features == ({'feature="default"','feature="bytemuck"'} if name == 'safe_arch' else set())
    current_vectors, old_vectors = vectors(parsed_vectors), vectors(old['compiler_vectors'])
    assert {name: policy_vector(v, name, True) for name,v in current_vectors.items()} == {name: policy_vector(v, name, False) for name,v in old_vectors.items()}
    wide_paths = [v[i+1].split('=',1)[1] for v in parsed_vectors for i,x in enumerate(v[:-1]) if x == '--extern' and v[i+1].startswith('wide=')]
    assert len(wide_paths) == 1 and Path(wide_paths[0]).is_file()

    assert all(sha(p) == h for p, h in old_binding['tool_hashes'].items())
    for study, data in [(out, build), (control, old)]:
        assert set(data['libraries']) == {'liboriole_expat.so', 'liboriole_expat.a'}
        assert all(sha(study / 'normal' / name) == digest for name, digest in data['libraries'].items())
    target = Path('/home/dev-user/.cache/oriole/text-lane-masks-target/x86_64-unknown-linux-gnu/release')
    assert all(sha(target / name) == digest for name, digest in build['libraries'].items())
    assert sha('/tmp/oriole-pgo-study/expat-control-liboriole_expat.so') == '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'
    assert old['libraries']['liboriole_expat.so'] == 'd6303603fece314e683a5fda5dcb60334c7e302e5e8d87bd7dd13285e46bb63e'
    groups = re.findall(r'^test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', (out / 'tests.log').read_text(), re.M)
    assert groups and all(int(ignored) == 0 for _, ignored in groups)
    report.update(status='passed', base=base, source_count=74, source_delta=delta,
                  source_manifest_sha256=sha(out / 'source.json'), prepared_source_sha256=sha('/tmp/oriole-text-lane-masks-preparation/source.json'),
                  complete_patch_sha256=sha(out / 'candidate.patch'), check_scope='Full workspace tests/fmt/all-target strict Clippy; also locked inprocess benchmark fmt/Clippy. Same normal release command as namespace control.', comparison_scope='LF and first-stop lane masks versus namespace normal d630 control. Main74 map differs in Cargo.lock, core manifest, text.rs and test-only encoding.rs/text_coalescing.rs; two auxiliary locks change separately. No parser/compiler/benchmark target executed by this saved binder.', build_sha256=sha(out / 'build.json'),
                  control_source_manifest_sha256=sha(control / 'source.json'), control_build_sha256=sha(control / 'build.json'),
                  tool_hashes=old_binding['tool_hashes'], compiler_vectors_normalized=vectors(parsed_vectors),
                  normalization='Compiler policy comparison normalizes only resolved rustc/shared-build paths, Cargo metadata/extra-filename and known existing dependency fingerprints, and removes the single expected Oriole --extern wide pair. Full actual ordered vectors are retained. New three dependency compiler flags/features checked explicitly.',
                  candidate_libraries=build['libraries'], control_libraries=old['libraries'],
                  dependency_compiler_vectors=[normalize(v) for v in dependency_vectors], dependency_review_sha256=sha(dependency_review_path), wide_artifact_sha256={p:sha(p) for p in wide_paths},
                  auxiliary_files=auxiliary, metadata_receipt_sha256=sha(metadata_receipt_path), complete_seven_file_patch_sha256=sha(complete_patch),
                  expat_normal_control={'path':'/tmp/oriole-pgo-study/expat-control-liboriole_expat.so','sha256':sha('/tmp/oriole-pgo-study/expat-control-liboriole_expat.so')},
                  tests={'passed': sum(int(n) for n, _ in groups), 'groups': len(groups), 'failures': 0, 'ignored': 0})
except BaseException as exc:
    report.update(status='failed', error=repr(exc))
    raise
finally:
    report_path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'tests': report['tests'], 'libraries': report['candidate_libraries'], 'sha256': sha(report_path)}))
