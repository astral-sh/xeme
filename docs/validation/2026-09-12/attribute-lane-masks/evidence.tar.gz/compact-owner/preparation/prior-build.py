"""Check and build LF and first-stop lane-mask candidate with ordinary release settings."""

import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import subprocess
import time

ROOT = Path('/home/dev-user/code/oss/oriole-text-lane-masks')
OUT = Path('/tmp/oriole-text-lane-masks-study')
TARGET = Path('/home/dev-user/.cache/oriole/text-lane-masks-target')
OUT.mkdir(exist_ok=True)
assert not (OUT / 'build.json').exists()
assert __debug__ and os.sched_getaffinity(0) == {4}
def interrupted(signum, frame):
    raise KeyboardInterrupt('SIGTERM')
signal.signal(signal.SIGTERM, interrupted)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


env = os.environ.copy()
for key in list(env):
    if key.startswith('CARGO_PROFILE_') or (key.startswith('CARGO_TARGET_') and key.endswith('_RUSTFLAGS')) or key in {
        'RUSTC', 'RUSTFLAGS', 'CARGO_BUILD_RUSTFLAGS', 'LLVM_PROFILE_FILE',
        'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST', 'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST',
        'LD_PRELOAD', 'LD_LIBRARY_PATH',
    }:
        env.pop(key)
env.update({
    'CARGO_HOME': '/home/dev-user/.cache/toucan/cargo',
    'CARGO_TARGET_DIR': str(TARGET),
    'CARGO_BUILD_BUILD_DIR': '/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}',
    'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0',
    'RUSTC_WRAPPER': '', 'RUSTC_WORKSPACE_WRAPPER': '',
    'CARGO_ENCODED_RUSTFLAGS': '', 'CARGO_TERM_COLOR': 'never',
})
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert base == 'b6985f0d07e9b3456f36f77eac97cf7bf013a650'
names = subprocess.check_output(
    ['git', 'ls-files', '-z', 'crates', 'include', 'tests/c', 'Cargo.toml', 'Cargo.lock'],
    cwd=ROOT,
).decode().rstrip('\0').split('\0')
names = sorted(set(names) | {'crates/oriole/src/text.rs'})
assert len(names) == 74
source = {name: sha(ROOT / name) for name in names}
prepared = json.loads(Path('/tmp/oriole-text-lane-masks-preparation/source.json').read_text())
assert source == prepared['sha256']
assert sha('/tmp/oriole-text-lane-masks-preparation/source.json') == '13408d5ae11c9108b651f401414aef6ced9286755a65ae188b64741461dc7e6e'
metadata_review_path = Path('/tmp/oriole-text-lane-masks-preparation/metadata-independent-review.json')
assert sha(metadata_review_path) == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
metadata_review = json.loads(metadata_review_path.read_text())
assert metadata_review['source_manifest_sha256'] == sha('/tmp/oriole-text-lane-masks-preparation/source.json')
assert metadata_review['status'] == 'passed_saved_metadata_review'
auxiliary = prepared['auxiliary_sha256']
assert set(auxiliary) == {'benchmarks/inprocess/Cargo.toml', 'benchmarks/inprocess/Cargo.lock', 'fuzz/Cargo.toml', 'fuzz/Cargo.lock'}
assert all(sha(ROOT / name) == h for name,h in auxiliary.items())
metadata_receipt_path = Path('/tmp/oriole-text-lane-masks-preparation/format-metadata.json')
metadata_receipt = json.loads(metadata_receipt_path.read_text())
assert sha(metadata_receipt_path) == prepared['format_metadata_receipt_sha256']
assert metadata_receipt['status'] == 'passed'
assert {row['label'] for row in metadata_receipt['commands']} == {'format', 'main', 'benchmark', 'fuzz'}
for row in metadata_receipt['commands']:
    assert row['exit'] == 0 and row['reaped']
    for stream,digest in row['output_sha256'].items():
        assert sha(metadata_receipt_path.parent / (row['label']+'.'+stream)) == digest
assert sha('/tmp/oriole-text-lane-masks-preparation/complete-candidate.patch') == prepared['complete_seven_file_patch_sha256'] == 'b64dfcfeb2f6a1d45e034145352860270c06bc48cdd8ce2ed62692eee1a1ea8b'

(OUT / 'source.json').write_text(json.dumps({'base': base, 'worktree': str(ROOT), 'sha256': source}, indent=2) + '\n')
(OUT / 'candidate.patch').write_bytes(Path('/tmp/oriole-text-lane-masks-preparation/candidate.patch').read_bytes())
report = {'status': 'incomplete', 'source_sha256': sha(OUT / 'source.json'), 'commands': [],
          'dependency_review_sha256': sha(metadata_review_path), 'auxiliary_files': auxiliary,
          'metadata_receipt_sha256': sha(metadata_receipt_path),
          'scope': 'Ordinary O3 ThinLTO, one codegen unit, generic x86-64 release. No profile generation/use or compiler optimization changes.'}


def save():
    (OUT / 'build.json').write_text(json.dumps(report, indent=2) + '\n')


def run(label, argv):
    path = OUT / (label + '.log')
    row = {'label': label, 'argv': argv, 'start': time.time()}
    report['commands'].append(row)
    save()
    with path.open('wb') as log:
        proc = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            row['pid'] = proc.pid
            row['exit'] = proc.wait(timeout=900)
        finally:
            if proc.poll() is None:
                os.killpg(proc.pid, signal.SIGKILL)
                row['exit'] = proc.wait()
            row.update(reaped=True, end=time.time(), log_sha256=sha(path))
            save()
    print(label, row['exit'], flush=True)
    assert row['exit'] == 0
    return path.read_text()


try:
    report['rustc'] = run('rustc-version', ['rustc', '+ohm', '-vV'])
    cargo = ['cargo', '+ohm', '-Zohm-defaults=no']
    run('fmt', cargo + ['fmt', '--all', '--check'])
    run('tests', cargo + ['test', '--workspace', '--locked', '--offline'])
    run('clippy', cargo + ['clippy', '--workspace', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings'])
    run('benchmark-fmt', cargo + ['fmt', '--manifest-path', 'benchmarks/inprocess/Cargo.toml', '--check'])
    run('benchmark-clippy', cargo + ['clippy', '--manifest-path', 'benchmarks/inprocess/Cargo.toml', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings'])
    build = run('release', cargo + ['rustc', '--release', '--locked', '--offline', '--target', 'x86_64-unknown-linux-gnu', '-p', 'oriole_expat', '--lib', '--crate-type', 'cdylib,staticlib', '--verbose'])
    vectors = []
    dependency_vectors = []
    for line in build.splitlines():
        if 'Running `' in line and '/rustc ' in line:
            argv = shlex.split(line.strip()[len('Running `'):-1])
            if argv[argv.index('--crate-name') + 1] in {'wide', 'safe_arch', 'bytemuck'}:
                dependency_vectors.append(argv)
            if argv[argv.index('--crate-name') + 1] in {'oriole', 'oriole_expat', 'oriole_storage'}:
                assert not any('profile-generate' in arg or 'profile-use' in arg or 'target-cpu' in arg for arg in argv)
                vectors.append(argv)
    assert len(vectors) == 3
    report['compiler_vectors'] = vectors
    report['dependency_compiler_vectors'] = dependency_vectors
    normal = OUT / 'normal'
    normal.mkdir()
    report['libraries'] = {}
    for name in ['liboriole_expat.so', 'liboriole_expat.a']:
        shutil.copy2(TARGET / 'x86_64-unknown-linux-gnu' / 'release' / name, normal / name)
        report['libraries'][name] = sha(normal / name)
    report['status'] = 'passed'
finally:
    report['source_unchanged'] = all(sha(ROOT / name) == value for name, value in source.items())
    report['auxiliary_unchanged'] = all(sha(ROOT / name) == value for name, value in auxiliary.items())
    assert report['auxiliary_unchanged']
    save()
assert report['source_unchanged']
