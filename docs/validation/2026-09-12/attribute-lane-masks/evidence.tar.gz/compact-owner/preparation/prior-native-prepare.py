"""Prepare a matched normal native comparison from existing artifacts only."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path

assert __debug__ and os.sched_getaffinity(0) == {6}
origin = Path('/tmp/oriole-namespace-scopes-study/native')
out = Path('/tmp/oriole-text-lane-masks-study/native')
control = origin.parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
binding = load(out.parent / 'build-binding.json')
source = load(out.parent / 'source.json')
assert binding['status'] == 'passed' and binding['source_count'] == 74
assert source['base'] == 'b6985f0d07e9b3456f36f77eac97cf7bf013a650'
assert binding['source_manifest_sha256'] == sha(out.parent / 'source.json')
assert binding['control_source_manifest_sha256'] == sha(control / 'source.json')
assert binding['build_sha256'] == sha(out.parent / 'build.json')
assert all(sha(Path(source['worktree']) / p) == h for p, h in source['sha256'].items())
assert source['sha256']['crates/oriole/src/tag.rs'] == '50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6'
build = load(out.parent / 'build.json')
old_source = load(control / 'source.json')
old_build = load(control / 'build.json')
prepared_source = Path('/tmp/oriole-text-lane-masks-preparation/source.json')
assert sha(prepared_source) == '13408d5ae11c9108b651f401414aef6ced9286755a65ae188b64741461dc7e6e'
assert source['sha256'] == load(prepared_source)['sha256']
assert set(source['sha256']) == set(old_source['sha256']) and len(source['sha256']) == 74
assert build['status'] == old_build['status'] == 'passed' and build['source_unchanged'] and old_build['source_unchanged']
assert binding['control_build_sha256'] == sha(control / 'build.json')
assert binding['prepared_source_sha256'] == sha(prepared_source)
assert set(binding['source_delta']) == {'Cargo.lock', 'crates/oriole/Cargo.toml', 'crates/oriole/src/encoding.rs', 'crates/oriole/src/text.rs', 'crates/oriole/tests/text_coalescing.rs'}
assert binding['candidate_libraries'] == build['libraries'] and binding['control_libraries'] == old_build['libraries']
assert binding['control_libraries']['liboriole_expat.so'] == 'd6303603fece314e683a5fda5dcb60334c7e302e5e8d87bd7dd13285e46bb63e'
for directory, libraries in [(out.parent, binding['candidate_libraries']), (control, binding['control_libraries'])]:
    assert all(sha(directory / 'normal' / name) == digest for name, digest in libraries.items())
assert all(sha(path) == digest for path, digest in binding['tool_hashes'].items())
dependency_review_path = prepared_source.parent / 'metadata-independent-review.json'
metadata_receipt_path = prepared_source.parent / 'format-metadata.json'
assert sha(dependency_review_path) == binding['dependency_review_sha256'] == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
assert load(dependency_review_path)['source_manifest_sha256'] == sha(prepared_source)
assert sha(metadata_receipt_path) == binding['metadata_receipt_sha256'] == build['metadata_receipt_sha256'] == load(prepared_source)['format_metadata_receipt_sha256']
assert binding['auxiliary_files'] == build['auxiliary_files'] == load(prepared_source)['auxiliary_sha256'] and build['auxiliary_unchanged']
assert all(sha(Path(source['worktree']) / name) == h for name,h in binding['auxiliary_files'].items())
assert binding['complete_seven_file_patch_sha256'] == sha(prepared_source.parent / 'complete-candidate.patch') == 'b64dfcfeb2f6a1d45e034145352860270c06bc48cdd8ce2ed62692eee1a1ea8b'
assert len(binding['dependency_compiler_vectors']) == len(build['dependency_compiler_vectors']) == 3
assert sha('/tmp/oriole-text-lane-masks-build.py') == '280eb7ab53af55700bc6979ce0e40be85609f3cd70d286381ed827a30b94e23f'
assert sha('/tmp/oriole-text-lane-masks-bind.py') == '243b63366c7dbc55458a232eb875be0a74a65706d752d2903e76e96ee3b19746'
assert not out.exists()
out.mkdir()


def adapt(name, changes):
    before = (origin / name).read_text()
    after = before
    for old, new in changes:
        assert old in after, (name, old)
        after = after.replace(old, new)
    ast.parse(after)
    (out / name).write_text(after)
    (out / (name + '.patch')).write_text(''.join(difflib.unified_diff(
        before.splitlines(True), after.splitlines(True),
        fromfile=str(origin / name), tofile=str(out / name))))
    return before, after


changes = [
    ('/tmp/oriole-namespace-scopes-study', '/tmp/oriole-text-lane-masks-study'),
    ('/tmp/oriole-text-plan-combined-study', '/tmp/oriole-namespace-scopes-study'),
    ('sparse namespace bookkeeping', 'LF and first-stop Text lane masks'),
    ('selected combined Text baseline', 'selected sparse namespace baseline'),
]
before, after = adapt('native_screen.py', changes)
marker = 'def run(condition, engine, pair, cpu, count):'
assert before[before.index(marker):] == after[after.index(marker):]
restored = after
for old, new in reversed(changes):
    restored = restored.replace(new, old)
assert restored == before
(out / 'run.py').write_bytes((origin / 'run.py').read_bytes())
prior = load(origin / 'adaptation.json')
libraries = {
    'candidate': {'path': str(out.parent / 'normal/liboriole_expat.so'),
                  'sha256': binding['candidate_libraries']['liboriole_expat.so']},
    'control': prior['libraries']['candidate'],
    'expat': prior['libraries']['expat'],
}
assert libraries['control']['sha256'] == binding['control_libraries']['liboriole_expat.so']
assert all(sha(v['path']) == v['sha256'] for v in libraries.values())
adaptation = {k: prior[k] for k in ('mode', 'external_input_hashes', 'conditions', 'pairs', 'seed', 'counts')}
assert all(sha(p) == h for p, h in adaptation['external_input_hashes'].items())
adaptation.update(
    status='passed', execution_status='unexecuted', origin=str(origin),
    parent_files={n: sha(origin / n) for n in ('run.py', 'native_screen.py')},
    files={n: sha(out / n) for n in ('run.py', 'native_screen.py')},
    changes={'run.py': [], 'native_screen.py': changes},
    inverse_text_and_ast_equal=True, libraries=libraries,
    selected_normal_protocol={'path': str(origin / 'native-screen/protocol.json'),
                              'sha256': sha(origin / 'native-screen/protocol.json')},
    source_delta=binding['source_delta'], candidate_source=source['worktree'],
    candidate_source_record={'path': str(out.parent / 'source.json'), 'sha256': sha(out.parent / 'source.json')},
    candidate_build_record={'path': str(out.parent / 'build.json'), 'sha256': sha(out.parent / 'build.json')},
    binding_review=str(out.parent / 'build-binding.json'),
    scope='LF and first-stop Text lane masks versus selected sparse namespace storage and normal Expat. All 28 conditions and original timing, workers, callbacks, and bounds unchanged. Same normal generic compiler recipe with reviewed wide/safe_arch/bytemuck dependencies. No targets run during preparation.')
(out / 'adaptation.json').write_text(json.dumps(adaptation, indent=2) + '\n')

reader_changes = [
    ('/tmp/oriole-namespace-scopes-study', '/tmp/oriole-text-lane-masks-study'),
    ('ef1648fcb1bae5bce53715283b221166c84e5e8431ff53f39e62a1ecd358bd25', '@CONTROL_SHA@'),
    ('d6303603fece314e683a5fda5dcb60334c7e302e5e8d87bd7dd13285e46bb63e', libraries['candidate']['sha256']),
    ('@CONTROL_SHA@', libraries['control']['sha256']),
    ('19b285440bc7467debfa4901df36d86a0e4ef1a0', source['base']),
    ("binding['source_count'] == 74 and set(binding['source_delta']) == {'crates/oriole/src/lib.rs', 'crates/oriole/tests/adapter_frame.rs', 'crates/oriole/tests/allocation.rs'}",
     "binding['source_count'] == 74 and set(binding['source_delta']) == {'Cargo.lock', 'crates/oriole/Cargo.toml', 'crates/oriole/src/encoding.rs', 'crates/oriole/src/text.rs', 'crates/oriole/tests/text_coalescing.rs'}"),
    ('Reuse the completed combined Text normal reader with source, library and output bindings for sparse namespace bookkeeping. Full raw reconstruction unchanged. Prototype author adapted this reader; root owns execution and independent review.',
     'Reuse the completed sparse namespace normal reader with source, library and output bindings for the LF and first-stop Text lane masks. Full raw reconstruction unchanged. Protocol preparer adapted this reader; root owns execution and independent review.'),
    ('Only this sparse-namespace normal native campaign is reconstructed here. Python preparation and timing are conditional on a native gain and are outside this evidence.',
     'Only this LF and first-stop Text lane-mask normal native campaign is reconstructed here. Python preparation and timing are conditional on a native gain and are outside this evidence.'),
]
adapt('read_results.py', reader_changes)
(out / 'README.md').write_text('''# LF and first-stop Text lane masks: held normal native protocol

Candidate is the reviewed LF and first-stop SIMD Text classifier on published sparse namespace base b6985f0d, source-equivalent to measured namespace runtime b9190cda. Control is that namespace runtime's existing d630 normal library. Oriole uses ordinary generic x86-64 O3, ThinLTO and one codegen unit; the pinned Expat 2.8.4 control uses GCC 13.3 O3 without LTO. There are no new PGO or CPU-target flags.

All 24 real conditions and four generated controls use the unchanged seven seeded pairs, 84 fresh preflight workers and 588 timed workers. Every sample includes parser construction, handlers, feeding, callbacks and destruction. Callback digests merge text fragments; they do not establish exact callback fragmentation. All adverse rows remain.

Root holds target execution until build/binder/codegen checks complete and other compilers/targets are reaped. Root runs run.py with the pinned CPython directory first on PATH: preflight CPU5 with 600s bound, then elapsed CPU0 with 1200s bound and 90s workers. CPU affinity and local scheduling do not establish an idle or globally exclusive host. Root runs read_results.py on CPU6 afterward. No target ran during preparation, and Python has not been prepared here.
''')
pins = {str(p): sha(p) for p in out.iterdir() if p.is_file()}
for p in [Path(__file__), out.parent / 'source.json', out.parent / 'build.json',
          out.parent / 'build-binding.json', control / 'source.json', control / 'build.json',
          prepared_source, dependency_review_path, metadata_receipt_path, prepared_source.parent / 'complete-candidate.patch', Path('/tmp/oriole-text-lane-masks-build.py'), Path('/tmp/oriole-text-lane-masks-bind.py'), origin / 'adaptation.json', origin / 'native_screen.py', origin / 'run.py', origin / 'read_results.py']:
    pins[str(p)] = sha(p)
preparation = {'status': 'prepared_no_targets', 'targets_executed': False, 'pins': pins,
               'source_delta': binding['source_delta'], 'counts': adaptation['counts'],
               'run_unchanged': True, 'native_worker_and_all_measurement_code_unchanged': True,
               'reader_changes': reader_changes, 'dependency_review_sha256': binding['dependency_review_sha256'], 'metadata_receipt_sha256': binding['metadata_receipt_sha256'], 'auxiliary_files': binding['auxiliary_files'], 'dependency_compiler_vectors': binding['dependency_compiler_vectors']}
(out / 'preparation.json').write_text(json.dumps(preparation, indent=2) + '\n')
print(json.dumps({'status': preparation['status'], 'path': str(out),
                  'preparation_sha256': sha(out / 'preparation.json'), 'libraries': libraries}))
