# Compact conversion-name owner: held source proposal

This unselected proposal starts at published namespace commit `b6985f0d07e9b3456f36f77eac97cf7bf013a650`. All 74 baseline source files match the measured namespace source. It changes two runtime lines: `Element::raw_encoding` uses the existing allocator-aware `Shared<Vec<NameEncoding>>`, constructed at the same point with `Shared::try_new_in`. It adds one focused test to the existing allocation-failure suite. No formatter, compiler, parser, benchmark or repository write ran.

## Why this shape

The conversion records are immutable and the owner is never cloned. Keeping the field, constructor and End locals in place preserves ownership and drop ordering. Failed construction drops the moved Vec. End still detaches namespace undo before fallible publication/restoration; parser abandonment still drops Elements before parser-owned namespace blocks. Common native End checks `is_some()` without dereferencing metadata. Converted End still uses an immutable slice. No pool, index, new unsafe code, dependency or dispatch change is needed.

On the existing 64-bit layout, replacing the 40-byte optional allocator-aware Box with a pointer-sized optional Shared suggests an Element reduction from 120 to 88 bytes. **That candidate layout and any speed improvement remain unmeasured.** Rare converted owners gain both allocator storage and an atomic reference count in their allocation (about 40 requested bytes on this ABI) and pay an atomic final drop. There is no refcount operation for ordinary `None`. Exact requested bytes, near-limit allocation outcomes and total memory can change; this is not an unconditional memory reduction.

## Focused coverage

The new test has five converted-name elements, two shadowed namespace bindings, empty and explicit End events and an outer-prefix sibling after restoration. It asserts all five Start/End names, both namespace declarations/ends, all eight multibyte conversions and final completion. Existing `check_allocations` then fails every observed allocation, requiring `NoMemory`, no live custom allocations and no Rust global allocations. Existing next-event helper also checks sticky OOM behavior without further allocation.

This exercises successful owner lifetime together with namespace undo and their cleanup on allocation failure. It does not prove a specific allocator callback order or an exact near-limit byte boundary. Existing custom-name tests retain encoded-spelling mismatch checks across namespace modes and input splits. No assertions were weakened and no old fixture was removed.

## Next gate, held for root

Independent source review comes first. Compose these two files onto whichever runtime is selected after the LF-mask measurement, preserving that runtime's Text/dependency changes. Then root can run the new allocation test, existing multibyte/matching-End tests and full ordinary checks, capture actual Element/Parser layout and matched generic normal native/Python results. No PGO or CPU-target flag changes are proposed. The current patch itself is not authorization to select or publish the runtime.
