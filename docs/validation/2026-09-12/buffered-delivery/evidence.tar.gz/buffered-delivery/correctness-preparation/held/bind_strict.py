"""Bind already prepared strict commands to the final normal build; no targets."""
from pathlib import Path
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
P = Path(__file__).parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
pins = load(P / 'pins.json')
static = load(P / 'strict-static-pins.json')
assert all(path not in pins or pins[path] == value for path, value in static.items())
pins.update(static)
bound = load(P / 'bound.json')
assert bound['status'] == 'bound_not_executed'
assert all(sha(path) == value for path, value in pins.items())
template = load(P / 'semantic-commands-unbound.json')
for command in template['commands']:
    extension = 'so' if command['mode'] == 'shared' else 'a'
    command['expected_library_sha256'] = bound['libraries'][extension]['sha256']
    command['status'] = 'held_until_fresh_strict_origin_hash_binding'
template['status'] = 'held_output_hash_binding_required'
with (P / 'semantic-commands-template.json').open('x') as stream:
    stream.write(json.dumps(template, indent=2) + '\n')
for path in [P / 'pins.json', P / 'bound.json', P / 'strict-static-pins.json', P / 'strict-preparation.json', P / 'semantic-commands-template.json']:
    pins[str(path)] = sha(path)
assert not (P / 'strict-cpython').exists()
with (P / 'strict-pins.json').open('x') as stream:
    stream.write(json.dumps(pins, indent=2) + '\n')
print(json.dumps({'status': 'strict_bound_not_executed', 'strict_pins_sha256': sha(P / 'strict-pins.json'), 'pins': len(pins), 'targets_executed': False}))
