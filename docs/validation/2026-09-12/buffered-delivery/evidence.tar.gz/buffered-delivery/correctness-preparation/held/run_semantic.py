"""Execute one previously bound semantic gate and retain its exact receipt."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

root = Path(__file__).parent
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
commands = root / 'semantic-commands.json'
bound = json.loads(commands.read_text())
assert __debug__ and sys.argv[1] in ('shared', 'static')
assert all(sha(p) == h for p, h in bound['pins_sha256'].items())
row = next(c.copy() for c in bound['commands'] if c['mode'] == sys.argv[1])
receipt = root / ('semantic-' + row['mode'] + '-receipt.json')
assert not receipt.exists()
row.update(command_manifest_sha256=sha(commands), started=time.time())
with Path(row['stdout']).open('xb') as out, Path(row['stderr']).open('xb') as err:
    process = subprocess.Popen(row['argv'], cwd=row['cwd'], stdout=out, stderr=err, start_new_session=True)
    try:
        row['exit'] = process.wait(timeout=row['outer_timeout_seconds'])
    except BaseException as exc:
        row['exception'] = repr(exc)
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
        row['exit'] = process.wait()
        raise
    finally:
        out.flush()
        err.flush()
        row.update(reaped=process.poll() is not None, ended=time.time(),
                   stdout_sha256=sha(row['stdout']), stderr_sha256=sha(row['stderr']),
                   pins_unchanged=all(sha(p) == h for p, h in bound['pins_sha256'].items()))
        row['status'] = 'passed' if row['exit'] == 0 and row['pins_unchanged'] else 'failed'
        receipt.write_text(json.dumps(row, indent=2) + '\n')
assert row['status'] == 'passed'
print(json.dumps({'mode': row['mode'], 'exit': row['exit'], 'receipt': str(receipt), 'sha256': sha(receipt)}))
