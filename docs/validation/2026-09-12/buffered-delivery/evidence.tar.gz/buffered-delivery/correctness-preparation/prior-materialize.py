"""Materialize held normal correctness controllers; no compiler/parser execution."""
from pathlib import Path
import ast, difflib, hashlib, json, os, subprocess

assert __debug__ and os.sched_getaffinity(0)=={6}
PREP=Path(__file__).parent
O=Path('/tmp/oriole-eager-bare-tag-position-correctness')
P=Path('/tmp/oriole-empty-state-guards-correctness')
W=Path('/home/dev-user/code/oss/oriole-empty-state-guards')
B=Path('/tmp/oriole-empty-state-guards-study')
MAIN=Path('/tmp/oriole-empty-state-guards-preparation')
old_work='/home/dev-user/code/oss/oriole-eager-bare-tag-position'
old_build='/tmp/oriole-eager-bare-tag-position-study'
replacements=[(str(O),str(P)),(old_work,str(W)),(old_build,str(B))]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def save(name,value):(P/name).write_text(json.dumps(value,indent=2)+'\n')
def relocate(text):
    for old,new in replacements:text=text.replace(old,new)
    return text

release=load(PREP/'release.json')
assert release['status']=='released_completed_artifacts'
seal=load(PREP/'prepared.json')
assert sha(__file__)==seal['materializer_sha256']
assert all(sha(path)==digest for path,digest in seal['inputs'].items())
source_review_path=MAIN/'source-binding.json'
prepared_source_path=MAIN/'source.json'
metadata_review_path=Path('/tmp/oriole-text-lane-masks-preparation/metadata-independent-review.json')
assert sha(metadata_review_path)=='45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
source_binding=load(source_review_path);prepared_source=load(prepared_source_path)
assert source_binding['status']=='passed_saved_source_binding'
assert release['base']==source_binding['base']==prepared_source['base']=='c8411446d5dc27a0f2c86d2bf48a71ee640cfb15'
assert sha(source_review_path)==release['source_binding_sha256']
assert sha(prepared_source_path)==source_binding['source_sha256']
assert prepared_source['review_pins']==source_binding['review_pins']
assert len(source_binding['review_pins'])>=2 and all(sha(p)==h for p,h in source_binding['review_pins'].items())
candidate_commit=release['candidate_source_commit']
assert isinstance(candidate_commit,str) and len(candidate_commit)==40 and all(c in '0123456789abcdef' for c in candidate_commit)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==candidate_commit
assert not subprocess.check_output(['git','diff','HEAD','--name-only','--','crates','include','tests/c','Cargo.toml','Cargo.lock'],cwd=W,text=True).strip()
build_binding=load(B/'build-binding.json')
assert sha(B/'build-binding.json')==release['build_binding_sha256']
assert build_binding['status']=='passed' and build_binding['source_count']==74
assert set(build_binding['source_delta'])=={'crates/oriole/src/lib.rs','crates/oriole_expat/src/lib.rs'}
assert build_binding['source_manifest_sha256']==sha(B/'source.json')
assert build_binding['build_sha256']==sha(B/'build.json')
assert load(B/'source.json')['sha256']==prepared_source['sha256']
assert build_binding['prepared_source_sha256']==sha(prepared_source_path)
assert set(release['candidate_libraries'])=={'liboriole_expat.so','liboriole_expat.a'}
assert build_binding['candidate_libraries']==release['candidate_libraries']
assert all(sha(B/'normal'/n)==h for n,h in release['candidate_libraries'].items())
assert build_binding['dependency_review_sha256']==sha(metadata_review_path)
assert build_binding['auxiliary_files']==prepared_source['auxiliary_sha256']
assert all(sha(W/name)==h for name,h in load(B/'source.json')['sha256'].items())
assert all(sha(W/name)==h for name,h in build_binding['auxiliary_files'].items())
P.mkdir(exist_ok=False);(P/'prior').mkdir()
scripts=['api_native.py','strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_api_c.py','read_strict_semantics.py','bind.py','bind_strict.py']
origins={}
for name in scripts:
    before=(O/name).read_text();after=relocate(before)
    if name=='bind.py':
        start=after.index("assert review['status'] ==")
        end=after.index("assert build['status'] ==",start)
        after=after[:start]+"assert review['status'] == 'passed_saved_source_binding'\nassert source['worktree'] == str(W) and len(source['sha256']) == 74\nprepared = load(P / 'reviewed-prepared-source.json')\nmetadata = load(P / 'reviewed-metadata.json')\nrelease = load(P / 'reviewed-release.json')\nassert release['status'] == 'released_completed_artifacts'\nassert sha(P / 'reviewed-source.json') == release['source_binding_sha256']\nassert sha(P / 'reviewed-prepared-source.json') == binding['prepared_source_sha256'] == review['source_sha256']\nassert source['sha256'] == prepared['sha256']\nassert source['base'] == prepared['base'] == review['base'] == release['base'] == 'c8411446d5dc27a0f2c86d2bf48a71ee640cfb15'\nassert prepared['source_count'] == 74\nassert set(prepared['changed']) == set(binding['source_delta']) == {'crates/oriole/src/lib.rs','crates/oriole_expat/src/lib.rs'}\nassert prepared['review_pins'] == review['review_pins']\nassert len(review['review_pins']) >= 2\nfor path,digest in review['review_pins'].items():\n    assert sha(path) == digest\n    pins[path] = digest\nassert prepared['complete_patch_sha256'] == binding['complete_patch_sha256'] == sha(B / 'candidate.patch')\nassert metadata['status'] == 'passed_saved_metadata_review'\nassert binding['dependency_review_sha256'] == sha(P / 'reviewed-metadata.json') == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'\nassert metadata['source_manifest_sha256'] == sha('/tmp/oriole-text-lane-masks-preparation/source.json')\nassert binding['auxiliary_files'] == prepared['auxiliary_sha256'] == load('/tmp/oriole-eager-bare-tag-position-study/build-binding.json')['auxiliary_files']\nfor name,digest in binding['auxiliary_files'].items():\n    assert sha(W/name)==digest\n    pins[str(W/name)]=digest\nassert len(binding['dependency_compiler_vectors']) == 3\ncontrol_path = Path('/tmp/oriole-eager-bare-tag-position-study/source.json')\ncontrol = load(control_path)\nassert binding['control_source_manifest_sha256'] == sha(control_path)\nassert set(source['sha256']) == set(control['sha256'])\nassert {name for name in source['sha256'] if source['sha256'][name] != control['sha256'][name]} == {'crates/oriole/src/lib.rs','crates/oriole_expat/src/lib.rs'}\nassert binding['control_libraries']['liboriole_expat.so'] == 'c702fda9005743ecc2d11cec3a350e4cabcf00da563699c580929cc4fc221f0f'\nassert binding['candidate_libraries'] == release['candidate_libraries']\nassert sha(B / 'build-binding.json') == release['build_binding_sha256']\nassert load(P / 'preparation.json')['candidate_source_commit'] == release['candidate_source_commit']\n"+after[end:]
    if name=='strict_cpython.py':
        old="'source_commit':'19251bc01dba14cc57507facd2d607a9075471b5'"
        assert after.count(old)==1
        after=after.replace(old,"'source_commit':json.loads((Path(__file__).parent/'preparation.json').read_text())['candidate_source_commit']")
    if name=='read_api_c.py':
        after=after.replace('Eager-tag preparer adapted the selected attribute API/C saved reader','Empty-state preparer adapted the selected eager API/C saved reader')
    if name=='read_strict_semantics.py':
        after=after.replace('Eager-tag preparer adapted the selected attribute strict/semantic saved reader','Empty-state preparer adapted the selected eager strict/semantic saved reader')
    ast.parse(after)
    assert sha(PREP/'held'/name)==seal['generated_scripts'][name]
    assert after==(PREP/'held'/name).read_text(),name
    (P/'prior'/name).write_text(before);(P/name).write_text(after)
    (P/(name+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(O/name),tofile=str(P/name))))
    origins[name]={'origin':str(O/name),'origin_sha256':sha(O/name),'sha256':sha(P/name),'path_substitution_only':name not in ('bind.py','strict_cpython.py','read_api_c.py','read_strict_semantics.py')}
assert (P/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]==(O/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]
review_copies={'reviewed-source.json':str(source_review_path),'reviewed-prepared-source.json':str(prepared_source_path),'reviewed-metadata.json':str(metadata_review_path),'reviewed-release.json':str(PREP/'release.json')}
for name,origin in review_copies.items():(P/name).write_bytes(Path(origin).read_bytes())

# Keep historical author scripts/oracles at their actual paths. Only unchanged
# repository input descendants relocate; no prior output is a candidate result.
static={};strictstatic={}
for filename,destination in [('static-pins.json',static),('strict-static-pins.json',strictstatic)]:
    for path,value in load(O/filename).items():
        if path.startswith(str(O)+'/'):continue
        if path==old_build+'/candidate.patch':continue
        new=relocate(path) if path.startswith(old_work+'/') else path
        assert sha(new)==value,new
        destination[new]=value
for name in scripts:
    destination=strictstatic if name in ('strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_strict_semantics.py','bind_strict.py') else static
    destination[str(P/name)]=sha(P/name)
    static[str(P/'prior'/name)]=sha(P/'prior'/name)
static[str(Path(__file__))]=sha(__file__)
static[str(PREP/'prepared.json')]=sha(PREP/'prepared.json')
for path,digest in source_binding['review_pins'].items():static[path]=digest
for name in review_copies:static[str(P/name)]=sha(P/name)
static[str(B/'candidate.patch')]=sha(B/'candidate.patch')
static[str(B/'build-binding.json')]=sha(B/'build-binding.json')
static[str(Path(old_build)/'source.json')]=sha(Path(old_build)/'source.json')
oldprep=load(O/'preparation.json')
save('preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'source_worktree':str(W),'candidate_source_commit':candidate_commit,'measured_source_base_commit':load(B/'source.json')['base'],'build_directory':str(B),'controller_origins':origins,'source_review_sha256':sha(P/'reviewed-source.json'),'api':oldprep['api'],'c_consumers':oldprep['c_consumers'],'baseline_api_outcomes':oldprep['baseline_api_outcomes'],'source_delta':'Only reviewed core lib.rs and C adapter lib.rs differ from selected eager19251bc/c841 in74-source map; all four auxiliary files and three dependency packages unchanged.','scope':'Direct adaptation of completed selected eager normal correctness controllers. Source and commit provenance updated; original API assertions and limits, six C builds/runs, complete strict shared/static loop, method reader and supplemental semantics unchanged. No targets executed.'})
save('static-pins.json',static)
spec=json.loads(relocate(json.dumps(load(O/'semantic-commands-unbound.json'))))
for command in spec['commands']:assert command['expected_library_sha256'] is None
save('semantic-commands-unbound.json',spec)
strictstatic[str(P/'semantic-commands-unbound.json')]=sha(P/'semantic-commands-unbound.json')
save('strict-static-pins.json',strictstatic)
oldstrict=load(O/'strict-preparation.json')
save('strict-preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'controller_origin':str(O/'strict_cpython.py'),'controller_origin_sha256':sha(O/'strict_cpython.py'),'controller_sha256':sha(P/'strict_cpython.py'),'complete_shared_static_execution_loop_byte_exact':True,'candidate_source_commit':candidate_commit,'measured_source_base_commit':load(B/'source.json')['base'],'baseline':oldstrict['baseline'],'baseline_outcomes':oldstrict['baseline_outcomes'],'consumer_fix':oldstrict['consumer_fix'],'static_pins_sha256':sha(P/'strict-static-pins.json'),'scope':'Original strict consumer-cleanup backport and historical two failures per linkage remain the comparison oracle; separate unchanged two semantic tests per linkage. Candidate outcomes pending. All target execution held.'})
(P/'README.md').write_bytes((PREP/'README.md').read_bytes())


print(json.dumps({'status':'prepared_not_executed','path':str(P),'preparation_sha256':sha(P/'preparation.json'),'scripts':len(scripts),'static_pins':len(static),'strict_static_pins':len(strictstatic)}))
