from pathlib import Path
import ast,hashlib,json,math,os,statistics
assert __debug__ and os.sched_getaffinity(0)=={6}
S=N=Path('/tmp/oriole-buffered-delivery-arena-diagnostic')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text())
fixed_pins={'/tmp/oriole-buffered-delivery-arena-diagnostic/read_results.py': 'cb7ec1f58b41237f3849e0602fe568abcdb855e41494e04951ccc1f06f02848e', '/tmp/oriole-buffered-delivery-arena-diagnostic/preparation.json': 'ffd5ffad66f240175dbc273709b693fdd33908f86573b9901a5a923f145a9221', '/tmp/oriole-buffered-delivery-arena-diagnostic/review.json': '887ea48360360e026a9d4691d3bdbd169bbf3155a539659cda4d1a347b5ff3de', '/tmp/oriole-buffered-delivery-arena-diagnostic/release.json': '21da61f75e4c24d2c3c714cf2f43d8486fe1e31239aabff542cabad2b82c9ca9', '/tmp/oriole-buffered-delivery-arena-diagnostic/monitor-host.py': 'd3a7506b1e445ff9255c65dc4d2609f0a99b621e9a28f93c005cc19cd0d42a5d', '/tmp/oriole-buffered-delivery-independent-native-raw-review.json': 'b57f8fda0d2ec168567c5b69553418db237ad32fae5157db2b6bb7cb1bcf6661', '/tmp/oriole-buffered-delivery-arena-diagnostic-independent-source-review.json': '38095b68c2cdc4fc8fb9ec1410baa5dc9b3112c560dd40a7f4c3bd9db910788f'}
for p,h in fixed_pins.items():assert H(p)==h,p
reader=N/'read_results.py';tree=ast.parse(reader.read_text());cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.With))
assert 'conditions.csv' in ast.get_source_segment(reader.read_text(),tree.body[cut])
for n in ast.walk(ast.Module(body=tree.body[:cut],type_ignores=[])):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute):assert n.func.attr not in {'write_text','write_bytes','unlink','mkdir','system','Popen','check_output'}
namespace={'__file__':str(reader),'__name__':'saved_diagnostic_reconstruction'}
exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),str(reader),'exec'),namespace)
sha,load=namespace['sha'],namespace['load'];counts=namespace['counts'];summary=namespace['summary'];primary=load(N/'review.json')
assert primary['status']=='passed_saved_arena_diagnostic' and primary['counts']==counts and primary['all_conditions']==summary
assert counts['all_workers']==48 and counts['all_samples']==1398 and len(summary)==2
assert primary['adverse']==[r for r in summary if r['median_ratios']['candidate_over_control']>1]
class A:host_before=['host-before-native.json']
a=A()
controller=namespace['controller'];start,end=controller['commands'][1]['start'],controller['commands'][1]['end']
observations=[]
host_before=a.host_before or ['host-before-native.json']
assert len(set(host_before))==len(host_before)
for filename in host_before:
 assert Path(filename).name==filename and filename.endswith('.json')
 data=load(S/filename);x,y=data['samples'];assert x['time']<y['time']<start
 reconstructed={}
 for cpu in ['cpu','cpu0']:
  total=y['cpu'][cpu]['total']-x['cpu'][cpu]['total'];idle=y['cpu'][cpu]['idle']-x['cpu'][cpu]['idle']
  assert 0<=idle<=total and total>0
  reconstructed[cpu]=idle/total
 assert reconstructed==data['idle_plus_iowait_fraction']
 observations.append({'file':filename,'sha256':sha(S/filename),'start':x['time'],'end':y['time'],'seconds':y['time']-x['time'],'idle_plus_iowait_fraction':reconstructed,'scope':data['scope']})
assert observations
assert all(x["end"]<=y["start"] for x,y in zip(observations,observations[1:]))
assert sha(S/'monitor-host.py')=='d3a7506b1e445ff9255c65dc4d2609f0a99b621e9a28f93c005cc19cd0d42a5d'
host=load(S/'host-during-native.json')
assert host['status']=='completed' and host['phase']=='native' and host['controller_status']=='passed'
assert host['controller_sha256']==sha(N/'controller.json') and host['monitor_sha256']==sha(S/'monitor-host.py')
samples=host['samples'];intervals=[];excluded=[]
for i,(x,y) in enumerate(zip(samples,samples[1:])):
 assert x['time']<y['time']
 delta={cpu:{key:y['cpu'][cpu][key]-x['cpu'][cpu][key] for key in ['total','idle']} for cpu in ['cpu','cpu0']}
 delta['other_cpus']={key:delta['cpu'][key]-delta['cpu0'][key] for key in ['total','idle']}
 assert all(0<=v['idle']<=v['total'] and v['total']>0 for v in delta.values())
 record={'sample_indices':[i,i+1],'start':x['time'],'end':y['time'],'seconds':y['time']-x['time'],'delta_ticks':delta,'idle_plus_iowait_fraction':{cpu:v['idle']/v['total'] for cpu,v in delta.items()}}
 if start<=x['time'] and y['time']<=end:intervals.append(record)
 else:excluded.append(record)
assert intervals and len(intervals)+len(excluded)==len(samples)-1
assert all(left['sample_indices'][1]==right['sample_indices'][0] for left,right in zip(intervals,intervals[1:]))
totals={cpu:{key:sum(r['delta_ticks'][cpu][key] for r in intervals) for key in ['total','idle']} for cpu in ['cpu','cpu0','other_cpus']}
weighted={cpu:v['idle']/v['total'] for cpu,v in totals.items()}
interior_seconds=sum(r['seconds'] for r in intervals)
process_ranges=[]
for row in summary:
 processes=[p for cohort in namespace['expected_rows'] if cohort['condition']==row['condition'] for p in cohort['processes']]
 process_ranges.append({'condition':row['condition'],'process_median_seconds':{e:[p['median_seconds'] for p in processes if p['engine']==e] for e in ['candidate','control','expat']},'paired_ratio_ranges':{k:[min(v),max(v)] for k,v in row['paired_ratios'].items()}})
for p,h in namespace['pins'].items():assert H(p)==h
for p,h in fixed_pins.items():assert H(p)==h
result={'status':'passed_independent_saved_arena_diagnostic','targets_executed':False,'counts':counts,'all_conditions':summary,'all_adverse_conditions':primary['adverse'],'process_ranges':process_ranges,'libraries':primary['libraries'],'prehost_observations':observations,'host_during':{'phase_start':start,'phase_end':end,'phase_seconds':end-start,'fully_interior_intervals':intervals,'excluded_boundary_intervals':excluded,'interior_seconds':interior_seconds,'fraction_of_phase_with_fully_interior_samples':interior_seconds/(end-start),'tick_totals':totals,'weighted_idle_plus_iowait_fraction':weighted},'role':'Diagnostic preparer independently replayed completed raw workers and reconstructed host intervals. Separate source reviewer reconstructed fixtures and checked protocol before execution; root owned all targets and primary reader.','limitations':primary['limitations']+['These two diagnostic cases remain separate from the 28-condition main native campaign.','All seven paired ratios and process medians are retained; broad Expat variance prevents interpreting one median as universal benefit.','Only fully interior host intervals are used; counters do not establish enforced isolation or per-condition host attribution.'],'pins':{**fixed_pins,**namespace['pins'],str(Path(__file__)):H(__file__)},'reader_sha256':H(__file__)}
p=Path('/tmp/oriole-buffered-delivery-arena-diagnostic-independent-readback.json')
with p.open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'sha256':H(p),'counts':counts,'summary':summary,'host':weighted},indent=2))
