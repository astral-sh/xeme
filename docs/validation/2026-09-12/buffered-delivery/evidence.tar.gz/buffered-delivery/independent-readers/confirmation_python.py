"""Completed normal CPython raw/origin/host audit; no parser or target execution."""
from pathlib import Path
import ast,csv,hashlib,json,math,os,re,subprocess,sys
assert __debug__ and os.sched_getaffinity(0)=={6}
assert len(sys.argv)>=4 and all(re.fullmatch("[0-9a-f]{64}",v) for v in sys.argv[1:4])
PRIMARY_SHA=sys.argv[1]
ROOT=Path('/tmp/oriole-buffered-delivery-study');D=ROOT/'python';CONF=Path('/tmp/oriole-buffered-delivery-confirmation');C=CONF/'python';OLD=Path('/tmp/oriole-empty-state-guards-study/python')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text())
assert H(C/'normal-review.json')==PRIMARY_SHA
assert H(C/'preflight-review.json')==sys.argv[2]
assert H(CONF/'preparation.json')==sys.argv[3]
CONFROOT=CONF
held_source_pins={'/tmp/oriole-buffered-delivery-confirmation-preparation/prepared.json': '724a809fc5ddd3ea14b6e1ee46d155db37e6e6d87437a07c0b3cd34361449306', '/tmp/oriole-buffered-delivery-confirmation-preparation/prepare.py': '7c10ef0352c0a7f1d8681b4d92bdeed277facf5b73c93d297100377ebe7a31a3', '/tmp/oriole-buffered-delivery-confirmation-preparation/recipe.json': 'f26b70dfa8f323020436c9573322f983d742f899f77d6a83fb9161f7d1fde708', '/tmp/oriole-buffered-delivery-confirmation-preparation/recipe-before-release.json': 'd4ee3a9e69d681c22062931619458f28efcd1ede3135463d5789bef3ff37d88d', '/tmp/oriole-buffered-delivery-confirmation-preparation/release.json': '0b6759f8992e5361ddcbf1374536f96f1b2c008ad6a81ec3d9ca5a2ea8a6f61f'}
for path,digest in held_source_pins.items():assert H(path)==digest,path
held_script_hashes={'native/run.py': '5f41a419e800e95954424e2a85d2ee988609d830db18dc85c469af801cd8aef5', 'native/native_screen.py': '38353dee4b1129029d2f1810890afbf5b3bf3a8e986a5422b71705c1598c8c01', 'native/read_results.py': 'c0baefb9c44ee095a54d79eb4be85d78c435dbe2b4c66343659aae310449666f', 'python/python_worker.py': '4bc0ccffedb5048412b9cfc3638d28dcb30f711891c3784f3fbd3c0eb536ab68', 'python/consumer_screen.py': 'd71f39d770cfb3d8683532b77b792ec1828a4792168dc88ad4795d71e6461210', 'python/run.py': '86308f8690956803712ee2279c9b071351bc4364f451eda3491588019ef2e32a', 'python/preflight_review.py': 'fda44970bd56065a59cf8aad32578ec289f28ce1545705c9108105662ca7b850', 'python/elapsed_review.py': 'f4f60dcd1efbe2ed5be5f4efcca0f9d7f63fe11a2935b3f0de792a81c28dd754', 'observe-host.py': 'a0df67eb5c89a0ffbf30ee377dd0302aff64ca2336fedef9f4af1655710a2cb7', 'monitor-host.py': 'bcfd3b9bba19053d43663b9cb79a74cfbf0d6124039b40a72bd9f232bdea4cc4'}
for name,digest in held_script_hashes.items():assert H(CONFROOT/name)==digest,name
confirmation_top=J(CONFROOT/'preparation.json')
assert confirmation_top['status']=='held_prepared_no_targets' and confirmation_top['finalizer_sha256']==held_source_pins['/tmp/oriole-buffered-delivery-confirmation-preparation/prepare.py']
for path,digest in confirmation_top['pins'].items():assert H(path)==digest,path
assert H(C/'preflight_review.py')=='fda44970bd56065a59cf8aad32578ec289f28ce1545705c9108105662ca7b850'
assert H(C/'elapsed_review.py')=='f4f60dcd1efbe2ed5be5f4efcca0f9d7f63fe11a2935b3f0de792a81c28dd754'
assert H(C/'run.py')=='86308f8690956803712ee2279c9b071351bc4364f451eda3491588019ef2e32a'
for name in ['python_worker.py','consumer_screen.py']:assert (C/name).read_bytes()==(D/name).read_bytes()
static={'/tmp/oriole-buffered-delivery-study/python/source-preparation.json': 'c8f0191cafc7e2b23bd6a6fe01bfe653d3b85c0860fb53fd3dfe5c66e27531f3', '/tmp/oriole-buffered-delivery-study/python/preparation.json': 'bf78612e368b25bca240fae135a87cf5b357e1f3df74d50e5eadff2d29479abe', '/tmp/oriole-buffered-delivery-study/python/consumer-binding.json': '205903bc237a2eb5961350ec782fd56285e1566bb737c3504f4a2aefecb8eb1c', '/tmp/oriole-buffered-delivery-study/python/preflight_review.py': '73428f0bff0baf117cb37725fcb93fc7d575ae88dd4010753e2ae45fdd1eaace', '/tmp/oriole-buffered-delivery-study/python/elapsed_review.py': '215b7c8e00c5a333dda113a5d06c4df3c73d5205a15fbfe5cc1589ff4877d610', '/tmp/oriole-buffered-delivery-python-preparation/prepared.json': '31a15f3008af337c382fad76f1e81e12c1f8fff00711fb13ddbe78e5cb6e5529'}
for path,value in static.items():assert H(path)==value,path
assert H(D/'elapsed_review.py')=='215b7c8e00c5a333dda113a5d06c4df3c73d5205a15fbfe5cc1589ff4877d610'
assert H(D/'preflight_review.py')=='73428f0bff0baf117cb37725fcb93fc7d575ae88dd4010753e2ae45fdd1eaace'
preparation=J(D/'source-preparation.json')
for mapping in [preparation['pins'],preparation['parent_scripts'],preparation['selected_control_scripts']]:
 for path,value in mapping.items():assert H(path)==value,path
for name in ['python_worker.py','run.py','build_consumers.py']:assert (D/name).read_bytes()==(OLD/name).read_bytes()

def replay(path,stop):
 text=path.read_text();tree=ast.parse(text);lines=text.splitlines()
 cut=next(i for i,n in enumerate(tree.body) if stop(n,lines))
 assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','check_output','mkdir','unlink','system'} for node in tree.body[:cut] for n in ast.walk(node))
 scope={'__file__':str(path),'__name__':'independent_saved_python_replay'}
 exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),str(path),'exec'),scope)
 return scope

pre=replay(C/'preflight_review.py',lambda node,lines:lines[node.lineno-1].startswith('output=C/'))
actual_pre=J(C/'preflight-review.json');assert actual_pre==pre['result']
scope=replay(C/'elapsed_review.py',lambda node,lines:isinstance(node,ast.With) and lines[node.lineno-1].startswith('with csvpath.open'))
actual=J(C/'normal-review.json');expected=dict(scope['report']);expected['condition_csv_sha256']=H(C/'normal-conditions.csv');assert actual==expected
assert scope['D']==D and scope['C']==C and scope['S']==C/'screen'
assert actual_pre['extension_compiles']=={'fresh':0,'reused':6,'total':6}
assert pre['pins']==actual_pre['pins']
with (C/'normal-conditions.csv').open(newline='') as f:rows=list(csv.DictReader(f))
assert rows==[{k:str(v) for k,v in row.items()} for row in scope['rows']]
assert actual['counts']['all_workers']==576 and actual['counts']['all_samples']==26364 and len(actual['summary'])==24
for group,entry in actual['aggregates'].items():
 selected=[r for r in actual['summary'] if group=='all' or r['condition']['mode']==group]
 for name,value in entry['geomean_ratios'].items():assert math.isclose(math.prod(r['median_ratios'][name] for r in selected)**(1/len(selected)),value,rel_tol=1e-14,abs_tol=1e-14)
adverse=[r for r in actual['summary'] if r['median_ratios']['candidate_over_control']>1]
assert actual['aggregates']['all']['adverse_conditions']==[{'condition':r['condition'],**r['median_ratios']} for r in adverse]
for mapping in [pre['pins'],scope['pins']]:
 for path,value in mapping.items():assert H(path)==value,path
source=J(ROOT/'source.json');binding=J(ROOT/'build-binding.json')
assert len(source['sha256'])==74 and H(ROOT/'build-binding.json')=='677556a5a266f1469d9e82d48eccba1bca2cd6eec72ee0bee8672136f65e558d'
commit=preparation['candidate_runtime_commit'];assert commit=='279a0bee7bd6267886574063ad89cd5c63fd00bd'
assert set(binding['source_delta'])=={'crates/oriole/src/arena.rs','crates/oriole/src/encoding.rs','crates/oriole/src/lib.rs','crates/oriole/tests/adapter_frame.rs','crates/oriole/tests/allocation.rs'}
for name,value in {**source['sha256'],**binding['auxiliary_files']}.items():
 assert H(Path(source['worktree'])/name)==value
 assert hashlib.sha256(subprocess.check_output(['git','-C',source['worktree'],'show',commit+':'+name])).hexdigest()==value,name
assert actual['libraries']['candidate']['sha256']==binding['candidate_libraries']['liboriole_expat.so']=='52202d064fa5fc02854e3a369791f644ddfe2f42ccef656ebba78e290f103821'
assert actual['libraries']['control']['sha256']=='93b735d89c1c0ee1989178b56ede6d7fbfed12a55c297a74cf9431f7596fc0e3'
# Exact existing pure counter arithmetic, embedded to avoid historical reader replay.
def counters(first, last):
    delta = {name: {key: last['cpu'][name][key] - first['cpu'][name][key] for key in ('total', 'idle')} for name in ('cpu', 'cpu0')}
    assert last['time'] > first['time']
    for values in delta.values():
        assert 0 <= values['idle'] <= values['total'] and values['total'] > 0
    other_total = delta['cpu']['total'] - delta['cpu0']['total']
    other_idle = delta['cpu']['idle'] - delta['cpu0']['idle']
    assert 0 <= other_idle <= other_total and other_total > 0
    return {'start': first['time'], 'end': last['time'], 'seconds': last['time']-first['time'], 'counter_deltas': delta,
            'idle_including_iowait_fractions': {name: values['idle']/values['total'] for name, values in delta.items()},
            'other_cpus_idle_including_iowait_fraction': other_idle/other_total}
during=J(CONF/'host-during-python.json');controller=J(C/'time-controller.json');timing,=controller['jobs']
assert during['status']=='completed' and during['phase']=='python' and during['controller_status']==controller['status']=='passed'
assert during['controller_sha256']==H(C/'time-controller.json') and during['monitor_sha256']==H(CONF/'monitor-host.py')
before_files=sys.argv[4:] or ['host-before-python.json'];assert len(before_files)==len(set(before_files))
before_records=[]
for filename in before_files:
 assert Path(filename).name==filename and filename.endswith('.json')
 before=J(CONF/filename)
 assert len(before['samples'])==2 and before['samples'][-1]['time']<=timing['start']
 before_summary=counters(before['samples'][0],before['samples'][-1]);assert before_summary['idle_including_iowait_fractions']==before['idle_plus_iowait_fraction']
 before_records.append({'file':filename,'sha256':H(CONF/filename),'summary':before_summary})
assert all(x['summary']['end']<=y['summary']['start'] for x,y in zip(before_records,before_records[1:]))

intervals=[counters(x,y) for x,y in zip(during['samples'],during['samples'][1:])]
inside=[r for r in intervals if timing['start']<=r['start'] and r['end']<=timing['end']]
outside=[r for r in intervals if not (timing['start']<=r['start'] and r['end']<=timing['end'])]
points=[p for p in during['samples'] if timing['start']<=p['time']<=timing['end']];assert inside and len(points)>=2 and len(inside)+1==len(points)
aggregate=counters(points[0],points[-1]);assert math.isclose(sum(r['seconds'] for r in inside),aggregate['seconds'],abs_tol=1e-9)
for cpu in ['cpu','cpu0']:
 for key in ['total','idle']:assert sum(r['counter_deltas'][cpu][key] for r in inside)==aggregate['counter_deltas'][cpu][key]
host={'before':before_records,'during_sample_count':len(during['samples']),'elapsed_controller':{'start':timing['start'],'end':timing['end'],'seconds':timing['end']-timing['start']},'sample_intervals_fully_inside_elapsed':{'count':len(inside),'aggregate':aggregate,'fraction_of_elapsed':aggregate['seconds']/(timing['end']-timing['start']),'other_cpus_idle_range':[min(r['other_cpus_idle_including_iowait_fraction'] for r in inside),max(r['other_cpus_idle_including_iowait_fraction'] for r in inside)],'intervals':inside},'excluded_outside_or_boundary_intervals':outside,'limitations':['Five-second /proc/stat samples count idle+iowait and exclude duplicate guest fields; no OS isolation or absence-of-contention claim.','Only consecutive intervals fully inside elapsed are attributed; no interpolation or per-condition attribution.','Pre-run observation remains separate from during-run activity.']}
paths=[CONF/'preparation.json',C/'preparation.json',D/'source-preparation.json',C/'preflight_review.py',C/'elapsed_review.py',C/'preflight-review.json',C/'normal-review.json',C/'normal-conditions.csv',C/'prepare-controller.json',C/'time-controller.json',ROOT/'source.json',ROOT/'build-binding.json',*(CONF/name for name in before_files),CONF/'host-during-python.json',CONF/'monitor-host.py',Path(__file__)]
result={'status':'passed_independent_normal_python_raw_and_host_review','targets_executed':False,'role':'Separate current saved-worker reconstruction by author of current buffered source/build/Python/confirmation preparation. Root requested direct established-reader reuse without another source peer chain. Only current primary prefixes are replayed; host arithmetic is embedded unchanged, with no historical reader execution. Root owns all targets and primary readers.','runtime_commit':commit,'counts':actual['counts'],'aggregates':actual['aggregates'],'all_conditions':actual['summary'],'all_adverse_conditions':adverse,'host':host,'provenance':{'libraries':actual['libraries'],'main_source_files':74,'main_changed_files':list(binding['source_delta']),'auxiliary_files_unchanged':4,'preflight_pins':len(pre['pins']),'elapsed_pins':len(scope['pins']),'fresh_compiles':0,'reused_modules':6},'limitations':['All24 conditions and every adverse row retained. Initial and confirmation epochs remain separate without pooling. This confirmation normal CPython project-input benchmark is not whole-application performance or exact callback-fragmentation compatibility.','Unmodified CPython3.12.13 O2 modules, module/dladdr origins, enabled GC, parse construction/feed/finalization/callbacks plus explicit destruction and canonical hashes match the original protocol.','No causal, statistical-significance or exclusive-host assertion. Current candidate adoption remains a separate root decision.'],'pins_sha256':{str(p):H(p) for p in paths},'reader_sha256':H(__file__)}
out=Path('/tmp/oriole-buffered-delivery-confirmation-independent-python-review.json')
with out.open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'receipt':str(out),'sha256':H(out),'counts':actual['counts'],'aggregates':actual['aggregates'],'fully_interior_host':{'intervals':len(inside),'seconds':aggregate['seconds'],'elapsed_seconds':timing['end']-timing['start'],'other_cpus_idle_iowait':aggregate['other_cpus_idle_including_iowait_fraction'],'excluded_intervals':len(outside)}},indent=2))
