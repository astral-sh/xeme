"""Reconstruct completed correctness evidence without running a target or primary writes."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import json
import os
import re
import subprocess
import sys

assert __debug__ and os.sched_getaffinity(0) == {6}
assert len(sys.argv) == 3 and all(re.fullmatch(r'[0-9a-f]{64}', x) for x in sys.argv[1:]), 'Expected completed primary API/C and strict/semantic report SHA256 arguments'
api_expected_sha256, strict_expected_sha256 = sys.argv[1:]
P = Path('/tmp/oriole-buffered-delivery-correctness')
B = Path('/tmp/oriole-buffered-delivery-study')
W = Path('/home/dev-user/code/oss/oriole-buffered-delivery')
OUT = Path('/tmp/oriole-buffered-delivery-correctness-independent-review.json')
assert not OUT.exists()
inputs = {}
def sha(path):
    path = Path(path)
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    assert str(path) not in inputs or inputs[str(path)] == value
    inputs[str(path)] = value
    return value
def load(path):
    sha(path)
    return json.loads(Path(path).read_text())
def replay(reader, report):
    script = P / reader
    expected = load(P / report)
    assert sha(script) == expected['reader_sha256']
    tree = ast.parse(script.read_bytes())
    end = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == 'result' for t in node.targets)) + 1
    # Both exact reader prefixes were inspected: only saved reads/assertions and
    # pure AST extraction of methods() execute. Stop before every output write.
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                   and n.func.attr in {'write_text', 'write_bytes', 'Popen', 'run', 'check_output', 'mkdir', 'unlink', 'system'}
                   for node in tree.body[:end] for n in ast.walk(node))
    ns = {'__file__': str(script), '__name__': 'independent_saved_replay'}
    exec(compile(ast.Module(body=tree.body[:end], type_ignores=[]), str(script), 'exec'), ns)
    assert json.loads(json.dumps(ns['result'])) == expected, reader
    for path, digest in expected['inputs'].items():
        assert sha(path) == digest, path
    return ns, expected

assert sha(P/'api-c-readback.json') == api_expected_sha256
assert sha(P/'strict-semantic-readback.json') == strict_expected_sha256
assert sha(P/'read_api_c.py') == 'c575f39b1226e36b1c4e406f6345c6cd8780dd460d8abc23892b6e3efa13e009'
assert sha(P/'read_strict_semantics.py') == '5581b6f28cf0b0f8c2428184f7b0618372850bb266cc49a2150e04854fea225e'
api_ns, api = replay('read_api_c.py', 'api-c-readback.json')
strict_ns, strict = replay('read_strict_semantics.py', 'strict-semantic-readback.json')
assert len(api_ns['rows'][1]) == 4740
assert dict(Counter(r['outcome'] for r in api_ns['rows'][1])) == {'pass':4347,'fail':391,'timeout':2}
assert all(r['exit'] == 0 for r in api['c_consumers']) and len(api['c_consumers']) == 6
assert all(v['full_method_map'] == strict['strict']['shared']['full_method_map']
           for v in strict['strict'].values())
for linkage, value in strict['strict'].items():
    assert len(value['full_method_map']) == 802 and value['rendered_outcome_lines'] == 809
    assert value['raw_exit'] == 2 and len(value['failures']) == 2 and value['changes'] == []
    assert len(value['origins']) == 4 and len(value['compiler_commands']) == 2
assert len(strict['semantics']) == 2 and all(r['tests'] == 2 and r['exit'] == 0 for r in strict['semantics'])

source = load(B/'source.json')
binding = load(B/'build-binding.json')
assert len(source['sha256']) == 74 and binding['source_manifest_sha256'] == sha(B/'source.json')
assert set(binding['source_delta']) == {'crates/oriole/src/arena.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/tests/adapter_frame.rs', 'crates/oriole/tests/allocation.rs'}
assert len(binding['auxiliary_files']) == 4
for name, digest in source['sha256'].items(): assert sha(W/name) == digest
for name, digest in binding['auxiliary_files'].items(): assert sha(W/name) == digest
head = subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'], text=True).strip()
assert head == '279a0bee7bd6267886574063ad89cd5c63fd00bd'

current = load(P/'preparation.json')
assert sha(P/'preparation.json') == '6eb8a97e4be96bf7b4cf78f8e73837e56510fb7a20e12a7d1c3b369563c766c1'
assert current['candidate_source_commit'] == head
assert current['measured_source_base_commit'] == '5d340f500c5a3936f6e20ae87a968085c31571ea'
assert current['controller_origins']['strict_cpython.py']['path_substitution_only'] is False
assert len(current['controller_origins']) == 9
for name, origin in current['controller_origins'].items():
    assert sha(P/name) == origin['sha256']
    assert sha(origin['origin']) == origin['origin_sha256']
assert sha('/tmp/oriole-buffered-delivery-correctness-preparation/materialize.py') == '5e1088d4b03e2d8ed2e3578d07722b80a9ceff16ab98004840e5fb01ca15702d'
assert sha('/tmp/oriole-buffered-delivery-correctness-preparation/prepared.json') == '9c91e1d79ed61284c9e6bf86a2c700d632d9bdb5492a3d4fcb82b5cf98b64c79'
assert sha(P/'reviewed-source.json') == 'd0f6e26ae8ce8cc15cee6a2b4dae8fa7e2e2c470bbda77a055409972ecae2f37'
source_binding = load(P/'reviewed-source.json')
prepared_source = load(P/'reviewed-prepared-source.json')
release = load(P/'reviewed-release.json')
assert source_binding['status'] == 'passed_saved_source_binding'
assert prepared_source['sha256'] == source['sha256']
assert sha(P/'reviewed-prepared-source.json') == binding['prepared_source_sha256'] == source_binding['source_sha256']
assert prepared_source['review_pins'] == source_binding['review_pins'] and len(source_binding['review_pins']) == 4
for path,digest in source_binding['review_pins'].items(): assert sha(path) == digest
assert sha(P/'reviewed-release.json') == '80ca1324de121cd134ac6b1f78114f01a4d166bbd6720a46c8cfd3c1eed1fe74'
assert release['status'] == 'released_completed_artifacts' and release['candidate_source_commit'] == head
assert release['base'] == source['base'] == current['measured_source_base_commit']
assert release['source_binding_sha256'] == sha(P/'reviewed-source.json')
assert release['build_binding_sha256'] == sha(B/'build-binding.json')
assert release['candidate_libraries'] == binding['candidate_libraries']
bound = load(P/'bound.json')
assert sha(P/'bound.json') == '38a93625edd5cf74cb94dd8a44d64fda8f9c377086245d420d14e602f63fd2b9'
assert sha(P/'bound.json') == strict['inputs'][str(P/'bound.json')]
assert sha(P/'strict-pins.json') == strict['inputs'][str(P/'strict-pins.json')]
assert bound['source_sha256'] == sha(B/'source.json')
assert bound['build_binding_sha256'] == sha(B/'build-binding.json') == '677556a5a266f1469d9e82d48eccba1bca2cd6eec72ee0bee8672136f65e558d'
assert bound['pins_sha256'] == sha(P/'pins.json')
for extension, digest in [('so', '52202d064fa5fc02854e3a369791f644ddfe2f42ccef656ebba78e290f103821'),
                          ('a', '87cb191166c0ec14e1513275789bfca41f4518ea6b41d8ac14c125c77b8d79dc')]:
    assert bound['libraries'][extension]['sha256'] == digest == sha(bound['libraries'][extension]['path'])
    assert binding['candidate_libraries']['liboriole_expat.'+extension] == digest
ordering_attempt = load(P/'strict-binding-attempt01.json')
assert ordering_attempt['status'] == 'failed_before_output' and ordering_attempt['exit'] == 1
assert ordering_attempt['targets_executed'] is False and ordering_attempt['partial_strict_outputs'] is False
assert 'pins.json' in ordering_attempt['exception']
for path, digest in list(inputs.items()): assert sha(path) == digest
result = {
    'status':'passed_independent_saved_correctness_review', 'targets_executed':False,
    'reader_sha256':sha(__file__), 'runtime_commit':head, 'source_files':74,
    'auxiliary_files':binding['auxiliary_files'], 'libraries':bound['libraries'],
    'api':api['api'], 'c_consumers':api['c_consumers'],
    'strict':{k:{'methods':v['methods'],'rendered_outcome_lines':v['rendered_outcome_lines'],
                 'raw_exit':v['raw_exit'],'failures':v['failures'],'changes':v['changes'],
                 'origins':v['origins'],'compiler_commands':v['compiler_commands'],
                 'full_method_map_sha256':hashlib.sha256(json.dumps(v['full_method_map'],sort_keys=True).encode()).hexdigest()}
              for k,v in strict['strict'].items()},
    'semantics':strict['semantics'],
    'controller_provenance':{'preparation_sha256':sha(P/'preparation.json'),
                             'origin_scripts':current['controller_origins'],
                             'strict_path_substitution_only':False,
                             'scope':'Current strict commit label comes from pinned preparation metadata; release/source/build pins match before target execution. Historical provenance corrections are not current target reruns.'},
    'checked_inputs':inputs, 'findings':[],
    'retained_pre_target_ordering_attempt':ordering_attempt,
    'limitations':[
        'Existing 391 API assertion failures and two per-test timeouts remain; unchanged outcomes do not mean complete Expat compatibility.',
        'Six C harnesses use ASan/UBSan, but linked Rust normal-release libraries are uninstrumented and leak detection is disabled.',
        'Strict consumers contain the pinned upstream pyexpat cleanup backport; benchmark consumers are unmodified. Two strict callback-fragmentation failures remain in each linkage.',
        'Two supplemental semantic tests pass per linkage as separate evidence; they do not turn the strict suite green. 809 rendered outcomes contain 802 distinct method identities.',
        'No additional target, sanitizer, fuzz, PBS, performance or adoption result is established by this saved-only audit.',
    ],
    'role':'Saved raw reconstruction is separate from root target execution. This reviewer authored the buffered source composition and held correctness preparation, so this is not an independent runtime-authorship review. Root requested direct existing-reader reuse without an additional peer chain; root owns targets and primary readbacks.',
}
with OUT.open('x') as stream: stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'path':str(OUT),'sha256':sha(OUT),'input_pins':len(inputs),
                  'api':api['api'],'c_consumers':6,'strict_methods_per_linkage':802,'semantic_tests_per_linkage':2}))
