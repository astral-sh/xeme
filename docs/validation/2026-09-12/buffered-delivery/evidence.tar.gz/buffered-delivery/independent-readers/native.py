"""Replay every saved native worker and audit fully interior host-counter intervals."""
from pathlib import Path
import argparse,ast,hashlib,json,math,os,re,shlex,subprocess
assert __debug__ and os.sched_getaffinity(0)=={6}
a=argparse.ArgumentParser()
for option in ['primary-review-sha','preparation-sha','build-binding-sha','candidate-so']:a.add_argument('--'+option,required=True)
a.add_argument('--host-before',action='append',default=[])
a.add_argument('--runtime-commit')
a=a.parse_args()
assert all(re.fullmatch('[0-9a-f]{64}',v) for v in [a.primary_review_sha,a.preparation_sha,a.build_binding_sha,a.candidate_so])
assert a.runtime_commit is None or re.fullmatch('[0-9a-f]{40}',a.runtime_commit)
S=Path('/tmp/oriole-buffered-delivery-study');N=S/'native'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text())
preparation=J(N/'preparation.json');assert H(N/'preparation.json')==a.preparation_sha
assert preparation['status']=='prepared_no_targets' and preparation['targets_executed'] is False
assert preparation['run_unchanged'] and preparation['native_worker_and_all_measurement_code_unchanged']
for path,h in preparation['pins'].items():assert H(path)==h,path
build_review_path=S/'build-binding.json'
assert H(build_review_path)==a.build_binding_sha
binding=J(build_review_path);build=J(S/'build.json');source=J(S/'source.json')
assert binding['status']==build['status']=='passed'
assert binding['build_sha256']==H(S/'build.json') and binding['source_manifest_sha256']==H(S/'source.json')
assert build['source_unchanged'] and build['auxiliary_unchanged']
assert binding['candidate_libraries']['liboriole_expat.so']==a.candidate_so
assert binding['tests']=={'passed':465,'groups':35,'failures':0,'ignored':0}
assert len(build['commands'])==7 and [r['label'] for r in build['commands']]==['rustc-version','fmt','tests','clippy','benchmark-fmt','benchmark-clippy','release']
for r in build['commands']:
 assert r['exit']==0 and r['reaped'] and r['end']>=r['start'] and H(S/(r['label']+'.log'))==r['log_sha256']
assert all(x['end']<=y['start'] for x,y in zip(build['commands'],build['commands'][1:]))
test_rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (S/'tests.log').read_text())
assert len(test_rows)==35 and sum(int(r[0]) for r in test_rows)==465 and all(r[1:]==('0','0') for r in test_rows)
release=(S/'release.log').read_text()
actual=[shlex.split(x) for x in re.findall(r'Running `([^`]+)`',release)]
for vector in build['compiler_vectors']+build['dependency_compiler_vectors']:
 assert any(row[-len(vector):]==vector for row in actual),vector
 assert 'opt-level=3' in vector and 'codegen-units=1' in vector
 assert not any('profile-' in token or 'target-cpu' in token or 'target-feature' in token for token in vector)
assert 'lto=thin' in next(v for v in build['compiler_vectors'] if v[v.index('--crate-name')+1]=='oriole_expat')
for p,h in binding['tool_hashes'].items():assert H(p)==h
assert binding['auxiliary_files']==build['auxiliary_files'] and len(binding['auxiliary_files'])==4
assert re.fullmatch('[0-9a-f]{40}',a.runtime_commit)
for name,h in {**source['sha256'],**binding['auxiliary_files']}.items():
 assert H(Path(source['worktree'])/name)==h
 raw=subprocess.run(['git','-C',source['worktree'],'show',a.runtime_commit+':'+name],capture_output=True,check=True,timeout=15).stdout
 assert hashlib.sha256(raw).hexdigest()==h,name
# Bind the current completed build directly. No historical build audit or codegen is replayed.
reader=N/'read_results.py';reader_bytes=reader.read_bytes()
assert hashlib.sha256(reader_bytes).hexdigest()==preparation['pins'][str(reader)]
tree=ast.parse(reader_bytes,filename=str(reader));cut=next(i for i,node in enumerate(tree.body) if isinstance(node,ast.With))
assert 'conditions.csv' in ast.get_source_segment(reader_bytes.decode(),tree.body[cut])
# Execute only the existing raw reconstruction before its first output write.
# This uses stdlib file/JSON/math operations; never imports or executes a parser.
for n in ast.walk(ast.Module(body=tree.body[:cut],type_ignores=[])):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute):assert n.func.attr not in {'write_text','write_bytes','unlink','mkdir','system','Popen','check_output'},n.func.attr
namespace={'__file__':str(reader),'__name__':'saved_native_reconstruction'}
exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),str(reader),'exec'),namespace)
sha,load=namespace['sha'],namespace['load']
counts,groups,summary=namespace['counts'],namespace['groups'],namespace['summary']
primary=load(N/'review.json')
assert sha(N/'review.json')==a.primary_review_sha
assert primary['counts']==counts and primary['groups']==groups and primary['all_conditions']==summary
assert counts['all_workers']==672 and counts['all_samples']==106176 and len(summary)==28
# Independently recompute aggregate products from all condition medians.
for label,group in groups.items():
 if label=='real':rows=[r for r in summary if not r['condition']['name'].startswith('generated-')]
 elif label=='generated':rows=[r for r in summary if r['condition']['name'].startswith('generated-')]
 else:rows=[r for r in summary if not r['condition']['name'].startswith('generated-') and r['condition']['namespaces']==(label=='real_namespaces_on')]
 for key,value in group['geomean_ratios'].items():
  assert math.isclose(math.prod(r['median_ratios'][key] for r in rows)**(1/len(rows)),value,rel_tol=1e-14,abs_tol=1e-14)
adverse=[r for r in summary if r['median_ratios']['candidate_over_control']>1]
assert all(r['median_ratios']['candidate_over_control']>1 for r in adverse)
controller=namespace['controller'];start,end=controller['commands'][1]['start'],controller['commands'][1]['end']
observations=[]
host_before=a.host_before or ['host-before-native.json']
assert len(set(host_before))==len(host_before)
for filename in host_before:
 assert Path(filename).name==filename and filename.endswith('.json')
 data=load(S/filename);x,y=data['samples'];assert x['time']<y['time']<start
 reconstructed={}
 for cpu in ['cpu','cpu0']:
  total=y['cpu'][cpu]['total']-x['cpu'][cpu]['total'];idle=y['cpu'][cpu]['idle']-x['cpu'][cpu]['idle']
  assert 0<=idle<=total and total>0
  reconstructed[cpu]=idle/total
 assert reconstructed==data['idle_plus_iowait_fraction']
 observations.append({'file':filename,'sha256':sha(S/filename),'start':x['time'],'end':y['time'],'seconds':y['time']-x['time'],'idle_plus_iowait_fraction':reconstructed,'scope':data['scope']})
assert observations
assert all(x["end"]<=y["start"] for x,y in zip(observations,observations[1:]))
assert sha(S/'monitor-host.py')=='bcfd3b9bba19053d43663b9cb79a74cfbf0d6124039b40a72bd9f232bdea4cc4'
host=load(S/'host-during-native.json')
assert host['status']=='completed' and host['phase']=='native' and host['controller_status']=='passed'
assert host['controller_sha256']==sha(N/'controller.json') and host['monitor_sha256']==sha(S/'monitor-host.py')
samples=host['samples'];intervals=[];excluded=[]
for i,(x,y) in enumerate(zip(samples,samples[1:])):
 assert x['time']<y['time']
 delta={cpu:{key:y['cpu'][cpu][key]-x['cpu'][cpu][key] for key in ['total','idle']} for cpu in ['cpu','cpu0']}
 delta['other_cpus']={key:delta['cpu'][key]-delta['cpu0'][key] for key in ['total','idle']}
 assert all(0<=v['idle']<=v['total'] and v['total']>0 for v in delta.values())
 record={'sample_indices':[i,i+1],'start':x['time'],'end':y['time'],'seconds':y['time']-x['time'],'delta_ticks':delta,'idle_plus_iowait_fraction':{cpu:v['idle']/v['total'] for cpu,v in delta.items()}}
 if start<=x['time'] and y['time']<=end:intervals.append(record)
 else:excluded.append(record)
assert intervals and len(intervals)+len(excluded)==len(samples)-1
assert all(left['sample_indices'][1]==right['sample_indices'][0] for left,right in zip(intervals,intervals[1:]))
totals={cpu:{key:sum(r['delta_ticks'][cpu][key] for r in intervals) for key in ['total','idle']} for cpu in ['cpu','cpu0','other_cpus']}
weighted={cpu:v['idle']/v['total'] for cpu,v in totals.items()}
interior_seconds=sum(r['seconds'] for r in intervals)
binding=load(S/'build-binding.json');source=load(S/'source.json')
assert sha(S/'build-binding.json')==a.build_binding_sha
assert len(source['sha256'])==74 and set(binding['source_delta'])=={'crates/oriole/src/arena.rs','crates/oriole/src/lib.rs','crates/oriole/src/encoding.rs','crates/oriole/tests/adapter_frame.rs','crates/oriole/tests/allocation.rs'}
assert binding['auxiliary_files']==build['auxiliary_files'] and len(binding['auxiliary_files'])==4
for name,h in binding['auxiliary_files'].items():assert sha(Path(source['worktree'])/name)==h
for name,h in source['sha256'].items():assert sha(Path(source['worktree'])/name)==h
assert binding['candidate_libraries']['liboriole_expat.so']==a.candidate_so
assert binding['control_libraries']['liboriole_expat.so']=='93b735d89c1c0ee1989178b56ede6d7fbfed12a55c297a74cf9431f7596fc0e3'
for p,h in namespace['pins'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
result={'status':'passed_independent_saved_native_raw_and_host_review','targets_executed':False,'role':'Independent saved-data execution of the current primary raw-worker reconstruction, then separate geometric products and fully interior host-counter arithmetic. Only the current reader prefix is replayed; no historical reader or build audit is executed. This reviewer independently checks the current build logs, compiler vectors and all committed source blobs, then replays only the current raw reader prefix; separate agents prepared the current build/native controllers. Root owned all targets and primary execution.','counts':counts,'groups':groups,'all_conditions':summary,'all_adverse_conditions':adverse,'libraries':primary['libraries'],'source_manifest_sha256':primary['source_manifest_sha256'],'source_scope':{'main_files':74,'main_changed_files':list(binding['source_delta']),'auxiliary_files_unchanged':4,'runtime_commit':a.runtime_commit,'build_binding_sha256':sha(S/'build-binding.json'),'committed_source_files':78,'tests':binding['tests'],'compiler_vectors':build['compiler_vectors'],'dependency_compiler_vectors':build['dependency_compiler_vectors']},'primary_reader_sha256':sha(reader),'primary_review_sha256':sha(N/'review.json'),'prehost_observations':observations,'host_during':{'phase_start':start,'phase_end':end,'phase_seconds':end-start,'fully_interior_intervals':intervals,'excluded_boundary_intervals':excluded,'interior_seconds':interior_seconds,'fraction_of_phase_with_fully_interior_samples':interior_seconds/(end-start),'tick_totals':totals,'weighted_idle_plus_iowait_fraction':weighted,'per_interval_fraction_ranges':{cpu:[min(r['idle_plus_iowait_fraction'][cpu] for r in intervals),max(r['idle_plus_iowait_fraction'][cpu] for r in intervals)] for cpu in totals},'raw_sha256':sha(S/'host-during-native.json')},'decision_evidence':'Every measured native row and adverse condition is retained. Native results alone do not establish Python benefit or adoption; root owns the next decision.','limitations':['This is one normal-release native campaign. No whole-application or statistical-significance claim.','CPU0 is occupied by the benchmark during timing. Other-CPU idle+iowait is reconstructed separately; CPU counters do not establish globally exclusive use, absence of contention or idle physical cores.','All pre-run observations are retained separately from the during-run counters; neither establishes enforced host isolation.','Host attribution uses only consecutive sample intervals fully inside the phase timestamps. Crossing start/end intervals are retained and excluded, with no interpolation.','Raw workers lack absolute per-worker timestamps, so these host samples cannot be assigned to individual conditions.','Callback digests merge text fragments; they do not prove exact callback grouping.','No Python/full API or sustained-fuzz result is asserted for this candidate by this native review.'],'pins':{**namespace['pins'],**{str(S/p):sha(S/p) for p in host_before+['host-during-native.json','monitor-host.py']},str(build_review_path):a.build_binding_sha,**{str(S/(r['label']+'.log')):r['log_sha256'] for r in build['commands']},str(N/'preparation.json'):a.preparation_sha,str(Path(__file__)):sha(__file__)},'reader_sha256':sha(__file__)}
with Path('/tmp/oriole-buffered-delivery-independent-native-raw-review.json').open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'counts':counts,'groups':{k:{a:b for a,b in v.items() if a!='adverse'} for k,v in groups.items()},'adverse':len(adverse),'prehost':[r['idle_plus_iowait_fraction'] for r in observations],'fully_interior':{'intervals':len(intervals),'seconds':interior_seconds,'fractions':weighted},'sha256':sha('/tmp/oriole-buffered-delivery-independent-native-raw-review.json')},indent=2))
