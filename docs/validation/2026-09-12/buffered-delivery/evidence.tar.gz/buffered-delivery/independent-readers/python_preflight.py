"""Replay completed Python preflight records only, without loading modules."""
from pathlib import Path
import ast,hashlib,json,os,re,sys
assert __debug__ and os.sched_getaffinity(0)=={6}
assert len(sys.argv)==2 and re.fullmatch('[0-9a-f]{64}',sys.argv[1])
D=Path('/tmp/oriole-buffered-delivery-study/python')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
static={'/tmp/oriole-buffered-delivery-study/python/source-preparation.json': 'c8f0191cafc7e2b23bd6a6fe01bfe653d3b85c0860fb53fd3dfe5c66e27531f3', '/tmp/oriole-buffered-delivery-study/python/preparation.json': 'bf78612e368b25bca240fae135a87cf5b357e1f3df74d50e5eadff2d29479abe', '/tmp/oriole-buffered-delivery-study/python/consumer-binding.json': '205903bc237a2eb5961350ec782fd56285e1566bb737c3504f4a2aefecb8eb1c', '/tmp/oriole-buffered-delivery-study/python/preflight_review.py': '73428f0bff0baf117cb37725fcb93fc7d575ae88dd4010753e2ae45fdd1eaace', '/tmp/oriole-buffered-delivery-study/python/elapsed_review.py': '215b7c8e00c5a333dda113a5d06c4df3c73d5205a15fbfe5cc1589ff4877d610', '/tmp/oriole-buffered-delivery-python-preparation/prepared.json': '31a15f3008af337c382fad76f1e81e12c1f8fff00711fb13ddbe78e5cb6e5529'}
for p,h in static.items():assert H(p)==h,p
assert H(D/'preflight-review.json')==sys.argv[1]
reader=D/'preflight_review.py';text=reader.read_text();tree=ast.parse(text);lines=text.splitlines()
cut=next(i for i,n in enumerate(tree.body) if lines[n.lineno-1].startswith('output=D/'))
body=tree.body[:cut]
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','check_output','mkdir','unlink','system'} for node in body for n in ast.walk(node))
scope={'__file__':str(reader),'__name__':'independent_saved_python_preflight_replay'}
exec(compile(ast.Module(body=body,type_ignores=[]),str(reader),'exec'),scope)
primary=J(D/'preflight-review.json');assert primary==scope['result']
assert primary['preflight_workers']==72 and len(primary['conditions'])==len(primary['canonical_outputs'])==24
assert primary['extension_compiles']=={'fresh':2,'reused':4,'total':6}
assert len(primary['exact_compile_vectors'])==6 and set(primary['origins'])=={'candidate','control','expat'}
prior=J(D/'source-preparation.json');assert prior['candidate_runtime_commit']=='279a0bee7bd6267886574063ad89cd5c63fd00bd'
for engine,h in [('candidate','52202d064fa5fc02854e3a369791f644ddfe2f42ccef656ebba78e290f103821'),('control','93b735d89c1c0ee1989178b56ede6d7fbfed12a55c297a74cf9431f7596fc0e3'),('expat','7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478')]:assert primary['origins'][engine]['parser_library']['sha256']==h
for p,h in scope['pins'].items():assert H(p)==h,p
r={'status':'passed_independent_saved_python_preflight_review','targets_executed':False,'runtime_commit':prior['candidate_runtime_commit'],'preflight_workers':72,'canonical_conditions':24,'extension_compiles':primary['extension_compiles'],'compiler_vectors':primary['exact_compile_vectors'],'origins':primary['origins'],'primary_sha256':H(D/'preflight-review.json'),'canonical_outputs':primary['canonical_outputs'],'pins':dict(scope['pins'])|static|{str(D/'preflight-review.json'):H(D/'preflight-review.json')},'reader_sha256':H(__file__),'role':'Separate saved replay by author of current Python/build preparation; unchanged target workers retain their original authors. This reviewer did not execute modules. Root owns producer/preflight targets and primary readback.','limits':'Canonical output equality merges character chunks; these preflights do not replace strict CPython tests or establish elapsed performance.'}
out=Path('/tmp/oriole-buffered-delivery-independent-python-preflight-review.json')
with out.open('x') as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'workers':72,'conditions':24,'pins':len(r['pins']),'sha256':H(out)}))
