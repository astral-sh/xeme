# Buffered delivery: held normal native protocol

Candidate composes the three reviewed buffer/delivery changes onto selected empty-state guards. Control is measured empty-state normal93b735; Expat is the original normal7a333 library. All sources, unchanged dependencies, compiler flags and actual library outputs are bound before materialization. No predicted benefit.

All24 real and four generated conditions retain seven seeded pairs,84 fresh preflight workers,588 timed workers and106176 samples. Workers include parser construction, handlers, feeds, callbacks and destruction; digests merge text fragments. Every adverse row remains. No compiler, profile or CPU-target setting changes.

Root alone releases execution after completed builds, binding and host observations. Run run.py with the pinned CPython directory first on PATH: CPU5 preflights600s, then CPU0 elapsed1200s, workers90s. Saved reader CPU6 afterward. Affinity does not establish global host isolation. Python remains a later root decision; no target ran during preparation.
