# Buffered delivery: held ordinary CPython protocol

Root materializes this recipe after completed native evidence supports continuing. The completed ordinary build/binding is pinned: source base5d340f50 (published empty-state docs), runtime279a0bee, candidate52202d06 versus selected66ca/93b735. Actual Git blobs and libraries are checked again at release. This preparation does not run materializers or targets.

The selected empty-state candidate's two O2 modules become control. The original Expat7a333 modules stay in their original directory. Only two candidate modules will be built, from unmodified CPython3.12.13 with the same O2 commands. No strict-suite cleanup backport enters timed modules.

The exact run.py, python_worker.py and build_consumers.py are reused. Screen captions and saved-reader output paths change; the existing24 conditions, seven pairs,72 fresh canonical preflights,504 timed workers,576 total workers and26,364 samples remain. GC, object destruction, callback/tree equality, actual module/DSO origins, medians and all adverse rows remain unchanged. Build/preflight bounds600s, elapsed1200s, individual workers300s.

All74 main files and four auxiliary files bind to the completed normal build; exactly five files differ, comprising three runtime changes and focused tests. Current C adapter, scanners, dependencies and benchmark sources remain unchanged. The combined experiment makes no individual-component speed attribution.

Root runs materialize.py --released 279a0bee7bd6267886574063ad89cd5c63fd00bd, then held/held-commands.json after source materialization. Saved stages use CPU6; fresh modules/preflights use CPU3 and elapsed CPU0 with root's before/during host observations. CPU affinity does not establish global host isolation. Oriole uses the established generic O3/ThinLTO/one-codegen-unit recipe; Expat retains its pinned ordinary O3/no-LTO recipe. No PGO or compiler/allocator-policy change is introduced.

The inherited module-builder method sentence is historical provenance; actual current build binding and O2 vectors define this experiment. Initial native output and candidate Python outputs were not read during source preparation. The root must release each target phase.
