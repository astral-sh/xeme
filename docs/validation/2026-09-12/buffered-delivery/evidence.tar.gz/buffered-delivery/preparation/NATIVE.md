# Held native preparation and worktree command

The three-script build preparation remains frozen separately in `prepared.json`. This addition prepares only the later native protocol, against selected empty-state runtime66ca/normal93b735 and unchanged normal Expat7a333. It creates no benchmark output until root releases the completed build.

Root first copies `native-release-template.json` to `native-release.json` and fills every null field with completed values: published base, source-binding hash, post-format prepared-source hash, study source hash, build report hash, build-binding hash and both candidate libraries. Status must be `released_for_native_preparation`. The materializer rejects missing, stale or mismatched values, verifies the inherited compiler/dependency/library/source bindings, then writes the existing protocol into `/tmp/oriole-buffered-delivery-study/native`.

Held saved-only command:

```sh
taskset -c 6 python3 -I -S /tmp/oriole-buffered-delivery-preparation/prepare_native.py
```

All28 conditions (24 real, four generated), seven pairs, seed2026091003, driver/corpus and three engines remain unchanged. There are84 fresh preflights and588 timed workers (672 total/106176 samples). `run.py` is copied byte-for-byte; `native_screen.py` differs only in paths and captions before the unchanged worker/measurement body; `read_results.py` differs only in current paths/source/base/library identities, five-file delta and captions. Its complete raw counts, medians, paired ratios, geometric means and adverse reporting are retained. Time limits and CPU5→CPU0 order stay unchanged; root owns host observation and target release. Source-only placeholder transformations/inverse equality were checked in memory; no finalizer, target, parser or compiler ran.

## Exact proposed root worktree command

Run from `/home/dev-user/code/oss/oriole-empty-state-guards` after the final published full head is known, replacing only `PUBLISHED_FULL_HEAD`:

```sh
env CARGO_TARGET_DIR=/home/dev-user/.cache/oriole/empty-state-guards-target \
    CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}' \
    cargo +ohm worktree add -b charlie/codex-oriole-buffered-delivery \
    /home/dev-user/code/oss/oriole-buffered-delivery PUBLISHED_FULL_HEAD \
    --target-dir /home/dev-user/.cache/oriole/buffered-delivery-target
```

The source worktree target is used for seeding; the new worktree receives its distinct `--target-dir`. The shared Ohm build path remains separate. `worktree-command.json` contains the exact cwd/environment/argv for review. Root verifies real checkout/common Git/OSS identity before executing it, then applies/formats the held source and explicitly refreezes any formatting-only change before binding/building. This command has not run.
