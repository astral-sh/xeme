# Held buffered-delivery source and ordinary build recipe

Three independently reviewed source proposals are composed into one candidate: warmed literal-attribute spans, successful-delivery/error-body separation, and warm complete UTF-8 direct source appends. The combined result changes five files (three runtime files), adds six tests, and retains the core/C empty-state guards exactly. Each proposal remains preserved separately. All six application orders of exact, unique, full-context hunk substitutions produce the identical final source map; there are no overlapping edits or fuzzy replacements.

## Identity and release hold

Measured control runtime: `66ca8e0bf7d9e59412c290298d49660f12b8c26a`, normal DSO `93b735d89c1c0ee1989178b56ede6d7fbfed12a55c297a74cf9431f7596fc0e3`, from `/tmp/oriole-empty-state-guards-study`. Root selected this control; final-decision.json is pinned at 97a29898ad74832cea99cf1a92645cf85cbf38c9a3229dfc9dad3455785ffc47. The source-equivalent published PR161 head is **5d340f500c5a3936f6e20ae87a968085c31571ea**. `release-template.json` preserves the original held placeholder. Root-authorized `release.json` now records that exact published head with status `released_for_source_binding`; source binding is still unexecuted. The expected-map `base: null` is retained for the reviewed binder schema; the actual base is supplied by the pinned release and copied into bound source metadata. The saved binder requires that commit to descend from runtime66ca and every one of its 74 main plus four auxiliary Git blobs to equal the measured control. A different control requires an explicit rebase/review; do not silently change it.

Root-owned paths:

- Branch: `charlie/codex-oriole-buffered-delivery`
- Worktree: `/home/dev-user/code/oss/oriole-buffered-delivery`
- Study: `/tmp/oriole-buffered-delivery-study`
- Worktree target: `/home/dev-user/.cache/oriole/buffered-delivery-target`

`original/` and `source/` contain only the five affected files. `reviewed-source.patch` now represents the actual formatted files against the source-equivalent published base. The preformat patch and complete prior preparation are retained under `before-formatting/`. Use that patch rather than copying a predecessor's whole lib.rs over the current source. `composition.json` binds every original/proposed main file, the unchanged auxiliary files, all individual proposals/peers, and each exact transformation. The complete current C adapter file stays unchanged.

Root created the worktree, applied the exact reviewed patch, and completed formatting (session36504, exit0/reaped). `formatting-refreeze.json` binds the root preformat receipt and complete formatter delta: four files change only line wrapping plus a block around one existing EndElement test match arm. All74 main and four auxiliary files were checked against the published base and actual formatted worktree. This agent performed only saved-source inspection and preparation writes; no binding, compiler, parser, test, benchmark, codegen or cleanup ran. All four scripts remain byte-identical to the prior reviewed recipes.

## Held root sequence

The published base, applied source, root formatting and explicit source-binding release are now recorded. After the narrow formatting/refreeze peer passes, the following root commands remain held:

```sh
taskset -c 6 python3 -I -S /tmp/oriole-buffered-delivery-preparation/bind_source.py PUBLISHED_FULL_HEAD
taskset -c 4 python3 -I -S /tmp/oriole-buffered-delivery-preparation/build.py
taskset -c 6 python3 -I -S /tmp/oriole-buffered-delivery-preparation/bind_build.py
```

The build uses the prior seven-command ordinary recipe byte-for-byte: compiler version, full workspace fmt/tests/strict all-target Clippy, locked/offline benchmark fmt/Clippy, and normal generic release. It clears inherited compiler/profile/trust overrides exactly as before, retains O3/ThinLTO/one codegen unit and the shared verified Ohm build directory, and adds no CPU flags or PGO work. Every child retains its existing timeout, termination and reap handling. Three core and three dependency compiler vectors, unchanged dependency metadata/features, source/auxiliary bytes and both actual libraries must pass the inherited saved comparison. Expected test counts are **465 passed across 35 groups**, zero failed/ignored; this is an expectation, not an executed result.

Build and build-binder changes are paths, identity/provenance, the five-file delta, release pin and captions. The full build command/extraction block and environment policy are byte-identical; compiler normalization/comparison helpers are unchanged. Adjacent `.py.patch` files show the exact adaptations. Source binding reads only Git and saved files before writing its new binding; it never applies source or formats/builds it.

## Measurement scope after a successful build

Reuse the established ordinary native comparison against control93b735 and Expat7a333: all 28 conditions, seven paired cohorts, same callbacks/counts/limits/worker/seed and raw adverse reporting. Native gate comes first; only an accepted gain warrants two fresh Python candidate modules, four reused control/Expat modules, the unchanged 24-condition Python protocol and existing compatibility gates. Small shared-host gains require the established separate confirmation epoch. Those campaign materializers are not created here.

Treat any resulting performance difference as the combined buffer/delivery change. There is no individual speed attribution, new timing tuning, ownership-lifetime extension, dependency change or production-readiness claim. The warm arena can copy extra punctuation/whitespace; malformed UTF-8 may be validated twice before unchanged fallback; all adverse cases remain relevant.
