# Separate warmed-arena spelling diagnostic — held

Two deterministic valid XML documents share the same callback stream: root, one lexical primer, one arena warmup, then 1,000 literal-attribute siblings. Every target has eight attributes with identical names/values. The packed target token is108 bytes; the whitespace-heavy token is3876 bytes. Inputs are112,120 and3,880,120 bytes, each below4MiB. No XML parser was invoked to generate them.

## Lifetime and capacity proof

This diagnostic uses one4MiB feed with namespaces off. Root identified that the C `run_events` function constructs/finishes the adapter frame per XML_Parse; a64KiB boundary would discard the warmed capacity. The main24real/fourgenerated campaign keeps its original4/64KiB feeds. This artificial single-feed case intentionally isolates retained-arena spelling pressure; it does not measure its hit rate in ordinary chunked input.

The first eight-attribute primer warms raw attribute record capacity. TagScanner can return Fallback when records are cold, so that primer alone does not claim to warm the callback arena. The next warmup has eight attributes, first value3940 bytes, remaining seven values one byte each; its4007-byte token fits the4KiB/128-attribute limits. It uses the retained records and native frame. The first value requires3941 arena bytes; adding its attribute name exceeds that first allocation (or its earlier small-capacity block), where append’s >2048 rule reserves the full4096-byte bound. The completed3981-byte packed payload fits. Frame clear retains capacity<=4096; implicit End/name ownership does not displace the reusable byte buffer. All1,000 targets therefore fit the warm guard within that same feed: packed rest104+name/NUL2=106 bytes; heavy rest3872+2=3874 bytes.

The control packs90 arena bytes per target. The candidate writes106 or3874:16 or3784 extra bytes per target, from punctuation and whitespace. These are source-derived byte counts, not measured allocator, instruction or RSS figures. Values remain literal ASCII without references/newlines/normalization. Eight attributes also keep both sides on the existing small duplicate/pointer paths. Source snapshots are pinned in prepared.json; later formatted actual74+4 source and libraries require the successful ordinary build binding.

## Unchanged measurement mechanics

Reuse the exact existing compiled native C driver and unchanged Python run worker/lifecycle/callback checks. Every process retains one warmup parse plus32 measured parses. The same seeded seven-pair schedule compares candidate, selected66ca/93b735 and original normal Expat7a333. Two conditions produce6 preflight+42 timed workers=48 workers;12 preflight samples+42 timed warmups+1344 measured samples=1398 samples. Process medians and median paired ratios use the existing arithmetic, with every adverse row retained. No aggregate from these fixtures enters the24real/fourgenerated results.

`held/run.py` is byte-identical to the original wrapper: preflightCPU5/600s, then elapsedCPU0/1200s, workers90s, captured commands and process-group cleanup. `native_screen.py` keeps the run function byte-identical and changes only fixture setup and two cardinality assertions. The saved reader retains the original raw worker/sample/median/schedule math with diagnostic counts; source/build/fixture/callback identity checks and cross-fixture callback equality remain explicit.

## Root release only

After source peer and the successful candidate build, root fills release-template.json as release.json with status `released_for_diagnostic_preparation`, this preparation hash and actual published base/source/build/binding/library identities. Then:

1. `taskset -c 6 <pinned-python> -I -S materialize.py --released` (saved preparation only).
2. After host observation and all other targets reap, run `/tmp/oriole-buffered-delivery-arena-diagnostic/run.py` with the pinned CPython directory first on PATH, using the existing root capture/timeout/reap controller. Retain before/during host records separately.
3. `taskset -c 6 <pinned-python> -I -S /tmp/oriole-buffered-delivery-arena-diagnostic/read_results.py` after both phases reap.

All commands remain held. There is no new C worker, unit test, compilation, threshold tuning, PGO, target CPU option or allocator policy. The candidate combines arena, successful delivery and Decoder changes; within-fixture elapsed ratios do not identify one component’s causal share. The single-feed setup leaves Decoder encoding initially undetected and specifically avoids claiming the direct-feed proposal is exercised here. Affinity does not establish host isolation or statistical significance.
