"""Deterministic XML construction only: no XML parser or benchmark invocation."""
from pathlib import Path
import hashlib,json
P=Path(__file__).parent
H=lambda b:hashlib.sha256(b).hexdigest()

def construct():
    attrs=[(f'a{i}', f'value{i:02d}') for i in range(8)]
    tight=''.join(f" {name}='{value}'" for name,value in attrs)
    heavy=''.join(' '*400+name+' '*20+'='+' '*20+"'"+value+"'" for name,value in attrs)+' '*256
    primer='<n'+tight+'/>'
    warm_attrs=[('a0','x'*3940)]+[(f'a{i}','x') for i in range(1,8)]
    warm='<w'+''.join(f" {name}='{value}'" for name,value in warm_attrs)+'/>'
    assert len(warm)<=4096 and len(attrs)==8
    documents={};rows=[]
    for label,rest in [('arena-packed',tight),('arena-whitespace',heavy)]:
        tag='<n'+rest+'/>'
        data=('<root>'+primer+warm+tag*1000+'</root>').encode('ascii')
        assert len(tag)<=4096 and len(rest)+2<=4096 and len(data)<=4*1024*1024
        assert len(set(n for n,v in attrs))==8
        documents[label+'.xml']=data
        rows.append({'name':label,'input':str(P/'fixtures'/(label+'.xml')),'chunk':4*1024*1024,'namespaces':False,'iterations':32})
    packed_payload=sum(len(n)+1+len(v)+1 for n,v in attrs)+2
    stats={label:{'bytes':len(documents[label+'.xml']),'sha256':H(documents[label+'.xml']),'target_siblings':1000,'target_token_bytes':len('<n'+rest+'/>'),'target_rest_bytes':len(rest),'candidate_arena_written_bytes':len(rest)+2,'control_packed_field_bytes':packed_payload,'extra_arena_written_bytes_per_target':len(rest)+2-packed_payload} for label,rest in [('arena-packed',tight),('arena-whitespace',heavy)]}
    return documents,{'schema':'two_literal_arena_fixture_sources_v1','conditions':rows,'fixtures':stats,'attributes':attrs,'prime_token_bytes':len(primer),'warm_token_bytes':len(warm),'warm_first_value_bytes':3940,'warm_attribute_count':8,'warm_packed_payload_bytes':sum(len(n)+1+len(v)+1 for n,v in warm_attrs)+2,'warm_retained_capacity_source_proof':4096,'elements_per_parse':1003,'text_bytes_per_parse':0,'events_identical_between_fixtures':True,'fixture_target_siblings':1000,'xml_parsers_executed':False,'generator_sha256':H(Path(__file__).read_bytes())}

if __name__=='__main__':
    files,manifest=construct();out=P/'fixtures';out.mkdir(exist_ok=False)
    for name,data in files.items():(out/name).write_bytes(data)
    (P/'fixtures.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'status':'generated_source_only','fixtures':manifest['fixtures']}))
