"""Separate two-fixture arena diagnostic; existing native worker and paired timing."""
import hashlib,json,os,random,statistics,subprocess,sys
from pathlib import Path
root=Path(__file__).parent
output=root/'native-screen'
load=lambda p:json.loads(Path(p).read_text())
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):(output/name).write_text(json.dumps(value,indent=2)+'\n')
prep=load(root/'preparation.json')
assert prep['status']=='prepared_no_targets'
for path,h in prep['pins'].items():assert digest(path)==h,path
manifest=Path(prep['fixture_manifest'])
fixture=load(manifest)
conditions=fixture['conditions']
assert len(conditions)==2 and all(c['chunk']==4*1024*1024 and c['namespaces'] is False and c['iterations']==32 for c in conditions)
assert all(Path(c['input']).stat().st_size<c['chunk'] for c in conditions)
driver=Path('/tmp/oriole-grammar-bench-plain/native-driver')
libraries={name:Path(prep['libraries'][name]['path']) for name in ['control','candidate','expat']}
ratios=[('candidate','control'),('candidate','expat'),('control','expat')]
hashes={str(p):digest(p) for p in [manifest,driver,Path(__file__),root/'preparation.json',root/'release.json',*libraries.values(),*(Path(c['input']) for c in conditions)]}
protocol={'scope':'Separate arena-copy diagnostic; packed and whitespace-only spelling variants; one4MiB feed preserves the C AdapterFrame warmup. Combined candidate vs selected66ca/control93b735 and normal Expat7a333. No main campaign pooling or individual-component attribution.',
'libraries':{name:{'path':str(path),'sha256':digest(path)} for name,path in libraries.items()},'conditions':conditions,'pairs':7,'seed':2026091003,'preflights':6,'timed_workers':42,'hashes':hashes}

def run(condition, engine, pair, cpu, count):
    command = ['taskset', '-c', str(cpu), str(driver), str(libraries[engine]),
               condition['input'], str(condition['chunk']), str(count)]
    if condition['namespaces']:
        command.append('namespaces')
    result = subprocess.run(command, capture_output=True, text=True, timeout=90)
    record = {'condition': condition, 'engine': engine, 'pair': pair, 'command': command,
              'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    ordinal = len(list(output.glob('worker-*.json')))
    save(f'worker-{ordinal:04d}.json', record)
    assert result.returncode == 0, record
    samples = json.loads(result.stdout)['samples']
    assert len(samples) == count + 1
    assert [sample['warmup'] for sample in samples] == [True] + [False] * count
    assert all(sample['seconds'] > 0 for sample in samples)
    observed = sorted({(sample['hash'], sample['elements'], sample['text_bytes']) for sample in samples})
    assert len(observed) == 1
    record['observations'] = [list(row) for row in observed]
    record['median_seconds'] = statistics.median(sample['seconds'] for sample in samples[1:])
    return record


phase = sys.argv[1]
if phase == 'preflight':
    assert os.sched_getaffinity(0) == {5}
    output.mkdir(exist_ok=False)
    save('protocol.json', protocol)
    report = {'status': 'incomplete', 'rows': [], 'protocol_sha256': digest(output / 'protocol.json'), 'hashes_before': hashes}
    try:
        for index, condition in enumerate(conditions):
            pair = [run(condition, engine, -1, 5, 1) for engine in libraries]
            assert all(p['observations'] == pair[0]['observations'] for p in pair)
            report['rows'].extend(pair)
        assert len(report['rows']) == 6
        report['hashes_after'] = {path: digest(path) for path in hashes}
        assert report['hashes_after'] == hashes
        report['status'] = 'passed'
    finally:
        save('preflight.json', report)
    print(json.dumps({'status': report['status'], 'preflights': len(report['rows']), 'protocol_sha256': report['protocol_sha256']}))
else:
    assert phase == 'time' and os.sched_getaffinity(0) == {0}
    assert json.loads((output / 'protocol.json').read_text()) == protocol
    preflight = json.loads((output / 'preflight.json').read_text())
    assert preflight['status'] == 'passed' and preflight['hashes_after'] == hashes
    expected = {json.dumps(row['condition'], sort_keys=True): row['observations'] for row in preflight['rows']}
    report = {'status': 'incomplete', 'protocol_sha256': digest(output / 'protocol.json'),
              'preflight_sha256': digest(output / 'preflight.json'), 'hashes_before': hashes,
              'affinity': sorted(os.sched_getaffinity(0)), 'rows': [], 'summary': []}
    try:
        rng = random.Random(protocol['seed'])
        jobs = [(condition, pair) for condition in conditions for pair in range(7)]
        rng.shuffle(jobs)
        for condition, pair in jobs:
            order = list(libraries)
            rng.shuffle(order)
            rows = [run(condition, engine, pair, 0, condition['iterations']) for engine in order]
            assert all(row['observations'] == expected[json.dumps(condition, sort_keys=True)] for row in rows)
            report['rows'].append({'condition': condition, 'pair': pair, 'order': order, 'processes': rows})
            save('results.json', report)
        for condition in conditions:
            pairs = [row for row in report['rows'] if row['condition'] == condition]
            values = {f"{a}_over_{b}": [] for a, b in ratios}
            for pair in pairs:
                seconds = {process['engine']: process['median_seconds'] for process in pair['processes']}
                for a, b in ratios:
                    values[f'{a}_over_{b}'].append(seconds[a] / seconds[b])
            report['summary'].append({'condition': condition, 'paired_ratios': values,
                                      'median_ratios': {key: statistics.median(data) for key, data in values.items()}})
        assert len(report['rows']) == 14 and len(report['summary']) == 2
        report['hashes_after'] = {path: digest(path) for path in hashes}
        assert report['hashes_after'] == hashes
        report['status'] = 'passed'
    finally:
        save('results.json', report)
    print(json.dumps({'status': report['status'], 'timed_workers': 3 * len(report['rows']), 'summary': report['summary']}))
