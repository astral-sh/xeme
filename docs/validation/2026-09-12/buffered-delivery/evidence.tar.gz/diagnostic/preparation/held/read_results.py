"""Saved arithmetic only for the separate two-fixture arena diagnostic."""
from pathlib import Path
import csv,hashlib,json,math,os,random,statistics
assert __debug__ and os.sched_getaffinity(0)=={6}
NATIVE=OUT=Path(__file__).parent
SCREEN=NATIVE/'native-screen'
pins={}
def sha(path):
    path=Path(path);h=hashlib.sha256(path.read_bytes()).hexdigest()
    assert str(path) not in pins or pins[str(path)]==h
    pins[str(path)]=h
    return h
def load(path):
    sha(path);return json.loads(Path(path).read_text())
prep=load(NATIVE/'preparation.json');release=load(NATIVE/'release.json')
assert prep['status']=='prepared_no_targets' and release['status']=='released_for_diagnostic_preparation'
for path,h in prep['pins'].items():assert sha(path)==h,path
fixture=load(prep['fixture_manifest'])
protocol=load(SCREEN/'protocol.json');preflight=load(SCREEN/'preflight.json');results=load(SCREEN/'results.json');controller=load(NATIVE/'controller.json')
assert all(x['status']=='passed' for x in [preflight,results,controller])
assert preflight['protocol_sha256']==results['protocol_sha256']==sha(SCREEN/'protocol.json')
assert results['preflight_sha256']==sha(SCREEN/'preflight.json')
assert protocol['hashes']==preflight['hashes_before']==preflight['hashes_after']==results['hashes_before']==results['hashes_after']
for path,h in protocol['hashes'].items():assert sha(path)==h,path
libraries=protocol['libraries'];assert libraries==prep['libraries']
assert libraries['control']['sha256']=='93b735d89c1c0ee1989178b56ede6d7fbfed12a55c297a74cf9431f7596fc0e3'
assert libraries['expat']['sha256']=='7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'
assert libraries['candidate']['sha256']==release['candidate_libraries']['liboriole_expat.so']
for row in libraries.values():assert sha(row['path'])==row['sha256']
conditions=protocol['conditions'];assert conditions==fixture['conditions'] and len(conditions)==2
assert all(c['chunk']==4*1024*1024 and c['namespaces'] is False and c['iterations']==32 for c in conditions)
assert protocol['pairs']==7 and protocol['seed']==2026091003 and protocol['preflights']==6 and protocol['timed_workers']==42
assert results['affinity']==[0]
assert controller['controller_sha256']==sha(NATIVE/'native_screen.py') and controller['wrapper_sha256']==sha(NATIVE/'run.py')
assert len(controller['commands']) == 2
for row, phase, cpu, bound in zip(controller['commands'], ['preflight', 'time'], [5, 0], [600, 1200], strict=True):
    assert row['phase'] == phase and row['exit'] == 0 and 'exception' not in row
    assert row['command'] == ['taskset', '-c', str(cpu), 'python3', str(NATIVE / 'native_screen.py'), phase]
    assert row['timeout'] == bound and row['end'] >= row['start']
    assert sha(NATIVE / (phase + '-controller.log')) == row['log_sha256']
assert controller['commands'][0]['end'] <= controller['commands'][1]['start']

driver = '/tmp/oriole-grammar-bench-plain/native-driver'
workers=sorted(SCREEN.glob('worker-*.json'))
assert [p.name for p in workers]==[f'worker-{n:04d}.json' for n in range(48)]
ordinal = 0
observations = {}
counts = {'preflight_workers': 0, 'timed_workers': 0, 'preflight_samples': 0, 'timed_warmups': 0, 'measured_samples': 0}

def condition_key(condition):
    return json.dumps(condition, sort_keys=True)

def worker(condition, engine, pair, cpu, count):
    global ordinal
    raw = load(workers[ordinal])
    ordinal += 1
    argv = ['taskset', '-c', str(cpu), driver, libraries[engine]['path'], condition['input'], str(condition['chunk']), str(count)]
    if condition['namespaces']:
        argv.append('namespaces')
    assert raw['condition'] == condition and raw['engine'] == engine and raw['pair'] == pair
    assert raw['command'] == argv and raw['returncode'] == 0 and raw['stderr'] == ''
    data = json.loads(raw['stdout'])
    assert data['version'] == ('expat_2.8.4' if engine == 'expat' else 'oriole_compat_2.8.4')
    samples = data['samples']
    assert len(samples) == count + 1
    assert [s['iteration'] for s in samples] == list(range(count + 1))
    assert [s['warmup'] for s in samples] == [True] + [False] * count
    assert all(math.isfinite(s['seconds']) and s['seconds'] > 0 for s in samples)
    seen = sorted({(s['hash'], s['elements'], s['text_bytes']) for s in samples})
    assert len(seen) == 1
    observed = [list(x) for x in seen]
    key = condition_key(condition)
    observations.setdefault(key, observed)
    assert observations[key] == observed
    median = statistics.median(s['seconds'] for s in samples[1:])
    if pair == -1:
        counts['preflight_workers'] += 1
        counts['preflight_samples'] += len(samples)
    else:
        counts['timed_workers'] += 1
        counts['timed_warmups'] += 1
        counts['measured_samples'] += count
    return raw | {'observations': observed, 'median_seconds': median}

expected_preflights = [worker(c, e, -1, 5, 1) for c in conditions for e in ['control', 'candidate', 'expat']]
assert expected_preflights == preflight['rows']
rng = random.Random(protocol['seed'])
jobs = [(c, pair) for c in conditions for pair in range(7)]
rng.shuffle(jobs)
expected_rows = []
for condition, pair in jobs:
    order = ['control', 'candidate', 'expat']
    rng.shuffle(order)
    processes = [worker(condition, e, pair, 0, condition['iterations']) for e in order]
    expected_rows.append({'condition': condition, 'pair': pair, 'order': order, 'processes': processes})
assert expected_rows == results['rows'] and ordinal == 48
assert counts == {'preflight_workers': 6, 'timed_workers': 42, 'preflight_samples': 12, 'timed_warmups': 42, 'measured_samples': 1344}
counts.update(all_workers=48, all_samples=1398, cohorts=14, conditions=2)
summary = []
for condition in conditions:
    relevant = [r for r in expected_rows if r['condition'] == condition]
    assert sorted(r['pair'] for r in relevant) == list(range(7))
    values = {key: [] for key in ['candidate_over_control', 'candidate_over_expat', 'control_over_expat']}
    for row in relevant:
        medians = {p['engine']: p['median_seconds'] for p in row['processes']}
        for key in values:
            a, b = key.split('_over_')
            values[key].append(medians[a] / medians[b])
    summary.append({'condition': condition, 'paired_ratios': values, 'median_ratios': {k: statistics.median(v) for k, v in values.items()}})
assert summary == results['summary']
# Fixtures differ only in attribute whitespace and must have identical callbacks.
assert len({tuple(tuple(x) for x in v) for v in observations.values()})==1
assert all(x[1:]==[1003,0] for v in observations.values() for x in v)
with (OUT/'conditions.csv').open('x',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=['name','chunk','namespaces',*values]);writer.writeheader()
    for row in summary:writer.writerow({k:row['condition'][k] for k in ['name','chunk','namespaces']}|row['median_ratios'])
for path,h in pins.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
result={'status':'passed_saved_arena_diagnostic','targets_executed':False,'counts':counts,'all_conditions':summary,'adverse':[r for r in summary if r['median_ratios']['candidate_over_control']>1],'libraries':libraries,'fixture_sources':fixture,'same_callbacks_across_fixtures':True,'inputs':pins,'reader_sha256':sha(__file__),'conditions_csv_sha256':sha(OUT/'conditions.csv'),'limitations':['Separate two-condition diagnostic; never pooled with24real/4generated or their aggregates.','One4MiB feed deliberately preserves C frame lifetime; does not establish warm-arena hit rate under4/64KiB feeds.','Combined candidate changes include delivery and decoding: elapsed differences do not isolate copying causally. No tuning of capacity thresholds.','Source proof predicts retained capacity and extra bytes; no runtime branch counter or RSS/layout measurement.','Same native lifecycle/time boundaries and callbacks; host affinity does not establish isolation or significance.']}
with (OUT/'review.json').open('x') as stream:stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'counts':counts,'summary':summary},indent=2))
