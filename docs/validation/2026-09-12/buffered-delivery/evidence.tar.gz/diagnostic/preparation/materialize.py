"""Materialize held diagnostic scripts after root binds actual normal artifacts."""
from pathlib import Path
import hashlib,json,os,sys
assert __debug__ and os.sched_getaffinity(0)=={6} and sys.argv[1:]==['--released']
P=Path(__file__).parent
OUT=Path('/tmp/oriole-buffered-delivery-arena-diagnostic')
STUDY=Path('/tmp/oriole-buffered-delivery-study')
CONTROL=Path('/tmp/oriole-empty-state-guards-study')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
prep=load(P/'prepared.json');release=load(P/'release.json')
assert release['status']=='released_for_diagnostic_preparation'
assert release['preparation_sha256']==sha(P/'prepared.json')
for path,h in prep['pins'].items():assert sha(path)==h,path
source=load(STUDY/'source.json');build=load(STUDY/'build.json');binding=load(STUDY/'build-binding.json')
for name,field in [('source.json','source_manifest_sha256'),('build.json','build_sha256'),('build-binding.json','build_binding_sha256')]:assert sha(STUDY/name)==release[field]
assert source['base']==release['published_base']==binding['base']
assert build['status']==binding['status']=='passed' and build['source_unchanged']
assert len(source['sha256'])==binding['source_count']==74
assert set(binding['source_delta'])=={'crates/oriole/src/arena.rs','crates/oriole/src/lib.rs','crates/oriole/src/encoding.rs','crates/oriole/tests/adapter_frame.rs','crates/oriole/tests/allocation.rs'}
assert binding['source_manifest_sha256']==sha(STUDY/'source.json') and binding['build_sha256']==sha(STUDY/'build.json')
assert release['candidate_libraries']==binding['candidate_libraries']==build['libraries']
assert all(sha(Path(source['worktree'])/name)==h for name,h in source['sha256'].items())
assert len(binding['auxiliary_files'])==4 and all(sha(Path(source['worktree'])/name)==h for name,h in binding['auxiliary_files'].items())
assert binding['control_source_manifest_sha256']==sha(CONTROL/'source.json') and binding['control_build_sha256']==sha(CONTROL/'build.json')
assert binding['control_libraries']==load(CONTROL/'build.json')['libraries']
assert binding['control_libraries']['liboriole_expat.so']=='93b735d89c1c0ee1989178b56ede6d7fbfed12a55c297a74cf9431f7596fc0e3'
assert all(sha(path)==h for path,h in binding['tool_hashes'].items())
for folder,values in [(STUDY,binding['candidate_libraries']),(CONTROL,binding['control_libraries'])]:
    assert all(sha(folder/'normal'/name)==h for name,h in values.items())
libraries={'control':{'path':str(CONTROL/'normal/liboriole_expat.so'),'sha256':binding['control_libraries']['liboriole_expat.so']},'candidate':{'path':str(STUDY/'normal/liboriole_expat.so'),'sha256':binding['candidate_libraries']['liboriole_expat.so']},'expat':prep['expat_library']}
assert all(sha(row['path'])==row['sha256'] for row in libraries.values())
fixture=load(P/'fixtures.json')
assert fixture['generator_sha256']==sha(P/'generate_fixtures.py')
for condition in fixture['conditions']:
    path=Path(condition['input']);row=fixture['fixtures'][condition['name']]
    assert path.stat().st_size==row['bytes']<condition['chunk']==4*1024*1024
    assert sha(path)==row['sha256'] and row['target_token_bytes']<=4096 and row['candidate_arena_written_bytes']<=4096
assert not OUT.exists();OUT.mkdir()
for name in ['native_screen.py','run.py','read_results.py']:(OUT/name).write_bytes((P/'held'/name).read_bytes())
(OUT/'release.json').write_bytes((P/'release.json').read_bytes())
(OUT/'adaptation.json').write_text(json.dumps({'status':'passed','scope':'Separate arena diagnostic only; main28condition campaign unchanged','source_preparation_sha256':sha(P/'prepared.json')},indent=2)+'\n')
pins=prep['pins']|{str(p):sha(p) for p in [P/'prepared.json',P/'release.json',STUDY/'source.json',STUDY/'build.json',STUDY/'build-binding.json',CONTROL/'source.json',CONTROL/'build.json',*(OUT/n for n in ['native_screen.py','run.py','read_results.py','release.json','adaptation.json'])]}
(OUT/'preparation.json').write_text(json.dumps({'status':'prepared_no_targets','targets_executed':False,'pins':pins,'fixture_manifest':str(P/'fixtures.json'),'libraries':libraries,'counts':prep['counts'],'main_campaign_unchanged':True},indent=2)+'\n')
print(json.dumps({'status':'prepared_no_targets','output':str(OUT),'preparation_sha256':sha(OUT/'preparation.json'),'libraries':libraries}))
