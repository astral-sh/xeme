"""Materialize held normal correctness controllers; no compiler/parser execution."""
from pathlib import Path
import ast, difflib, hashlib, json, os, subprocess

assert __debug__ and os.sched_getaffinity(0)=={6}
O=Path('/tmp/oriole-text-lane-masks-correctness')
P=Path('/tmp/oriole-attribute-lane-masks-correctness')
W=Path('/home/dev-user/code/oss/oriole-attribute-lane-masks')
B=Path('/tmp/oriole-attribute-lane-masks-study')
old_work='/home/dev-user/code/oss/oriole-text-lane-masks'
old_build='/tmp/oriole-text-lane-masks-study'
replacements=[(str(O),str(P)),(old_work,str(W)),(old_build,str(B))]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def save(name,value):(P/name).write_text(json.dumps(value,indent=2)+'\n')
def relocate(text):
    for old,new in replacements:text=text.replace(old,new)
    return text

source_review_path=Path('/tmp/oriole-attribute-first-stop-independent-source-review.json')
formatting_review_path=Path('/tmp/oriole-attribute-lane-masks-independent-formatting-followup.json')
prepared_source_path=Path('/tmp/oriole-attribute-lane-masks-preparation/source.json')
metadata_review_path=Path('/tmp/oriole-text-lane-masks-preparation/metadata-independent-review.json')
assert sha(source_review_path)=='3a971481e36edf52fa1714d379a036ad2f40b61a13c6114b47b55eb2c2329d35'
assert sha(formatting_review_path)=='915367db3d12873001257e97643697cef0e7ecab48edce576abe4378f2aadbb4'
assert sha(prepared_source_path)=='ee276c38b72082acfd9489e6f8f1b2f04618547f6cb6dbbb652f82f6c22ca773'
assert sha(metadata_review_path)=='45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
candidate_commit='910387239a804a038feb0a184b1bcfc0a7dd60bf'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==candidate_commit
build_binding=load(B/'build-binding.json')
assert sha(B/'build-binding.json')=='cbd73f86c625b939e7c3a37fdda70e149df616f93616015fa2ea4e024801f3f9'
assert build_binding['status']=='passed' and build_binding['source_count']==74
assert set(build_binding['source_delta'])=={'crates/oriole/src/tag.rs'}
assert build_binding['source_manifest_sha256']==sha(B/'source.json')
assert build_binding['build_sha256']==sha(B/'build.json')
assert load(B/'source.json')['sha256']==load(prepared_source_path)['sha256']
assert build_binding['candidate_libraries']=={'liboriole_expat.so':'b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5','liboriole_expat.a':'5063d4fa59a08f7853f245a413b32ebc0f1a83901a36e1fcb1df87a925832843'}
assert build_binding['dependency_review_sha256']==sha(metadata_review_path)
assert build_binding['auxiliary_files']==load(prepared_source_path)['auxiliary_sha256']
assert all(sha(W/name)==h for name,h in load(B/'source.json')['sha256'].items())
assert all(sha(W/name)==h for name,h in build_binding['auxiliary_files'].items())
P.mkdir(exist_ok=False);(P/'prior').mkdir()
scripts=['api_native.py','strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_api_c.py','read_strict_semantics.py','bind.py','bind_strict.py']
origins={}
for name in scripts:
    before=(O/name).read_text();after=relocate(before)
    if name=='bind.py':
        start=after.index("assert review['status'] ==")
        end=after.index("assert build['status'] ==",start)
        after=after[:start]+'''assert review['status'] == 'passed_independent_source_review'
assert source['worktree'] == str(W) and len(source['sha256']) == 74
prepared = load(P / 'reviewed-prepared-source.json')
formatting = load(P / 'reviewed-formatting.json')
metadata = load(P / 'reviewed-metadata.json')
assert sha(P / 'reviewed-prepared-source.json') == binding['prepared_source_sha256'] == 'ee276c38b72082acfd9489e6f8f1b2f04618547f6cb6dbbb652f82f6c22ca773'
assert source['sha256'] == prepared['sha256']
assert source['base'] == prepared['base'] == 'aed07bbacf75136330dd777a190ac2a42a2f1ed0'
assert review['base_commit'] == 'cacc0b1b3766176e9cbf71d25c5ff6867fa87c08'
assert prepared['source_count'] == review['main_source_files_verified'] == 74
assert set(review['changed_files']) == set(prepared['changed']) == set(binding['source_delta']) == {'crates/oriole/src/tag.rs'}
assert formatting['status'] == 'passed_independent_formatting_followup'
assert sha(P / 'reviewed-formatting.json') == '915367db3d12873001257e97643697cef0e7ecab48edce576abe4378f2aadbb4'
assert formatting['pins'][str(W/'crates/oriole/src/tag.rs')] == source['sha256']['crates/oriole/src/tag.rs']
assert formatting['main_source_files'] == 74 and formatting['auxiliary_files'] == 4
assert prepared['complete_patch_sha256'] == binding['complete_patch_sha256'] == sha(B / 'candidate.patch')
assert metadata['status'] == 'passed_saved_metadata_review'
assert binding['dependency_review_sha256'] == sha(P / 'reviewed-metadata.json') == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
assert metadata['source_manifest_sha256'] == sha('/tmp/oriole-text-lane-masks-preparation/source.json')
assert binding['auxiliary_files'] == prepared['auxiliary_sha256'] == load('/tmp/oriole-text-lane-masks-study/build-binding.json')['auxiliary_files']
for name,digest in binding['auxiliary_files'].items():
    assert sha(W/name)==digest
    pins[str(W/name)]=digest
assert len(binding['dependency_compiler_vectors']) == 3
control_path = Path('/tmp/oriole-text-lane-masks-study/source.json')
control = load(control_path)
assert binding['control_source_manifest_sha256'] == sha(control_path)
assert set(source['sha256']) == set(control['sha256'])
assert {name for name in source['sha256'] if source['sha256'][name] != control['sha256'][name]} == {'crates/oriole/src/tag.rs'}
assert binding['control_libraries']['liboriole_expat.so'] == '4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d'
assert binding['candidate_libraries'] == {'liboriole_expat.so': 'b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5', 'liboriole_expat.a': '5063d4fa59a08f7853f245a413b32ebc0f1a83901a36e1fcb1df87a925832843'}
'''+after[end:]
    if name=='strict_cpython.py':
        old="'source_commit':'cacc0b1b3766176e9cbf71d25c5ff6867fa87c08'"
        assert after.count(old)==1
        after=after.replace(old,"'source_commit':'"+candidate_commit+"'")
    if name=='read_api_c.py':
        after=after.replace('Lane-mask preparer adapted the selected namespace API/C saved reader','Attribute-lane preparer adapted the selected LF API/C saved reader')
    if name=='read_strict_semantics.py':
        after=after.replace('Lane-mask preparer adapted the selected namespace strict/semantic saved reader','Attribute-lane preparer adapted the selected LF strict/semantic saved reader')
    ast.parse(after)
    (P/'prior'/name).write_text(before);(P/name).write_text(after)
    (P/(name+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(O/name),tofile=str(P/name))))
    origins[name]={'origin':str(O/name),'origin_sha256':sha(O/name),'sha256':sha(P/name),'path_substitution_only':name not in ('bind.py','strict_cpython.py','read_api_c.py','read_strict_semantics.py')}
assert (P/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]==(O/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]
review_copies={'reviewed-source.json':str(source_review_path),'reviewed-formatting.json':str(formatting_review_path),'reviewed-prepared-source.json':str(prepared_source_path),'reviewed-metadata.json':str(metadata_review_path)}
for name,origin in review_copies.items():(P/name).write_bytes(Path(origin).read_bytes())

# Keep historical author scripts/oracles at their actual paths. Only unchanged
# repository input descendants relocate; no prior output is a candidate result.
static={};strictstatic={}
for filename,destination in [('static-pins.json',static),('strict-static-pins.json',strictstatic)]:
    for path,value in load(O/filename).items():
        if path.startswith(str(O)+'/'):continue
        if path==old_build+'/candidate.patch':continue
        new=relocate(path) if path.startswith(old_work+'/') else path
        assert sha(new)==value,new
        destination[new]=value
for name in scripts:
    destination=strictstatic if name in ('strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_strict_semantics.py','bind_strict.py') else static
    destination[str(P/name)]=sha(P/name)
    static[str(P/'prior'/name)]=sha(P/'prior'/name)
static[str(Path(__file__))]=sha(__file__)
for name in review_copies:static[str(P/name)]=sha(P/name)
static[str(B/'candidate.patch')]=sha(B/'candidate.patch')
static[str(B/'build-binding.json')]=sha(B/'build-binding.json')
static[str(Path(old_build)/'source.json')]=sha(Path(old_build)/'source.json')
oldprep=load(O/'preparation.json')
save('preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'source_worktree':str(W),'candidate_source_commit':candidate_commit,'measured_source_base_commit':load(B/'source.json')['base'],'build_directory':str(B),'controller_origins':origins,'source_review_sha256':sha(P/'reviewed-source.json'),'api':oldprep['api'],'c_consumers':oldprep['c_consumers'],'baseline_api_outcomes':oldprep['baseline_api_outcomes'],'source_delta':'Only reviewed tag.rs differs from LF cacc/aed07 in74-source map; all four auxiliary files and three dependency packages unchanged.','scope':'Direct adaptation of completed selected LF normal correctness controllers. Source and commit provenance updated; original API assertions and limits, six C builds/runs, complete strict shared/static loop, method reader and supplemental semantics unchanged. No targets executed.'})
save('static-pins.json',static)
spec=json.loads(relocate(json.dumps(load(O/'semantic-commands-unbound.json'))))
for command in spec['commands']:assert command['expected_library_sha256'] is None
save('semantic-commands-unbound.json',spec)
strictstatic[str(P/'semantic-commands-unbound.json')]=sha(P/'semantic-commands-unbound.json')
save('strict-static-pins.json',strictstatic)
oldstrict=load(O/'strict-preparation.json')
save('strict-preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'controller_origin':str(O/'strict_cpython.py'),'controller_origin_sha256':sha(O/'strict_cpython.py'),'controller_sha256':sha(P/'strict_cpython.py'),'complete_shared_static_execution_loop_byte_exact':True,'candidate_source_commit':candidate_commit,'measured_source_base_commit':load(B/'source.json')['base'],'baseline':oldstrict['baseline'],'baseline_outcomes':oldstrict['baseline_outcomes'],'consumer_fix':oldstrict['consumer_fix'],'static_pins_sha256':sha(P/'strict-static-pins.json'),'scope':'Original strict consumer-cleanup backport and historical two failures per linkage remain the comparison oracle; separate unchanged two semantic tests per linkage. Candidate outcomes pending. All target execution held.'})
(P/'README.md').write_text('''# Quoted-attribute first-stop lane masks: held normal correctness gates

Candidate runtime910387239a804a038feb0a184b1bcfc0a7dd60bf was measured from baseaed07bbacf75136330dd777a190ac2a42a2f1ed0. Only tag.rs differs across74 inputs. Selected LF control is runtimecacc/SO4ee8; candidate is SOb8508522/static5063d4. Dependencies and four auxiliary files remain unchanged.

The original API oracle retains4740 configurations:4347 passes,391 assertion failures and2timeouts. All assertions and original3s per-case,1GiB address-space,768MiB RSS,240s suite and300s outer bounds remain. Six dynamic/static integration/adversarial/allocation C consumers retain C-only ASan/UBSan, leak checking disabled,120s per compile/run; Rust uses ordinary generic release.

Strict shared/static CPython retains the explicit pinned upstream pyexpat cleanup backport,802methods/809rendered outcomes and two known callback-fragmentation failures per linkage (raw exit2). Each strict controller child retains1000s. Separate two semantic tests per linkage remain unchanged. Benchmark consumers use unmodified CPython; these patched strict modules are distinct.

This preparer writes only source scripts and saved bindings. Root runs bind.py and bind_strict.py onCPU6; api_native.py onCPU3 then read_api_c.py onCPU6; strict_cpython.py onCPU3; prepare_semantics.py onCPU6, run_semantic.py shared then static onCPU3, then read_strict_semantics.py onCPU6. Original commands, clean environment, pinned Python, timeout/teardown and raw exits remain. No PGO/flags or assertions change. Root schedules targets after elapsed measurements have ended.

Historical author-script pins/oracles retain original paths. No prior result is presented as a candidate outcome. LF's earlier descriptive origin-label correction remains historical and is not replayed: new strict initialization is accurately labeled as a provenance change from the start. No parser/compiler/strict extension is executed by this preparer.
''')
print(json.dumps({'status':'prepared_not_executed','path':str(P),'preparation_sha256':sha(P/'preparation.json'),'scripts':len(scripts),'static_pins':len(static),'strict_static_pins':len(strictstatic)}))
