"""Materialize current normal correctness controllers; no compiler/parser execution."""
from pathlib import Path
import ast, difflib, hashlib, json, os
assert os.sched_getaffinity(0)=={6}
O=Path('/tmp/oriole-expanded-start-capacity-correctness')
P=Path('/tmp/oriole-fused-normal-current-correctness')
W=Path('/home/dev-user/code/oss/oriole-fused-normal-current')
B=Path('/tmp/oriole-fused-normal-current-study')
old_work='/home/dev-user/code/oss/oriole-expanded-start-capacity'
old_build='/tmp/oriole-expanded-start-capacity-study'
replacements=[(str(O),str(P)),(old_work,str(W)),(old_build,str(B))]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def save(name,value):(P/name).write_text(json.dumps(value,indent=2)+'\n')
def relocate(text):
 for old,new in replacements:text=text.replace(old,new)
 return text
P.mkdir(exist_ok=False);(P/'prior').mkdir()
scripts=['api_native.py','strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_api_c.py','read_strict_semantics.py','bind.py','bind_strict.py']
origins={}
for name in scripts:
 before=(O/name).read_text();after=relocate(before)
 if name=='bind.py':
  after=after.replace("assert review['status'] == 'reviewed_source_no_blocker'", "assert review['status'] == 'passed_source_review_no_actionable_findings'")
  after=after.replace("assert review['source_sha256'] == source['sha256']", "assert review['source_manifest_sha256'] == sha(B / 'source.json')\nassert review['source_count'] == 73 and review['changed_files'] == ['crates/oriole/src/tag.rs']")
  after=after.replace("binding['source']['source_sha256']", "binding['source_manifest_sha256']").replace("binding['source']['count']", "binding['source_count']")
 ast.parse(after)
 (P/'prior'/name).write_text(before);(P/name).write_text(after)
 (P/(name+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(O/name),tofile=str(P/name))))
 origins[name]={'origin':str(O/name),'origin_sha256':sha(O/name),'sha256':sha(P/name),'path_substitution_only':name!='bind.py'}
assert (P/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]==(O/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]
(P/'reviewed-source.json').write_bytes(Path('/tmp/oriole-fused-normal-current-source-review.json').read_bytes())
# Relocate only original unchanged test/consumer inputs, not old output hashes or old controllers.
static={}
strictstatic={}
for filename,destination in [('static-pins.json',static),('strict-static-pins.json',strictstatic)]:
 for path,value in load(O/filename).items():
  if path.startswith(str(O)+'/'):continue
  new=relocate(path);assert sha(new)==value,new;destination[new]=value
for name in scripts:
 destination=strictstatic if name in ('strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_strict_semantics.py','bind_strict.py') else static
 destination[str(P/name)]=sha(P/name)
 static[str(P/'prior'/name)]=sha(P/'prior'/name)
static[str(Path(__file__))]=sha(__file__)
oldprep=load(O/'preparation.json')
save('preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'source_worktree':str(W),'build_directory':str(B),'controller_origins':origins,'source_review_sha256':sha(P/'reviewed-source.json'),'api':oldprep['api'],'c_consumers':oldprep['c_consumers'],'baseline_api_outcomes':oldprep['baseline_api_outcomes'],'source_delta':'Only core tag.rs versus selected4815cf7;73 source inputs.','scope':'Direct adaptation of completed capacity normal correctness controllers. Original API assertions and limits, six C builds/runs, complete strict shared/static loop, method reader and supplemental semantics unchanged. No target executed or profile-built artifact introduced.'})
save('static-pins.json',static)
spec=load(O/'semantic-commands-unbound.json')
spec=json.loads(relocate(json.dumps(spec)))
for command in spec['commands']:assert command['expected_library_sha256'] is None
save('semantic-commands-unbound.json',spec)
strictstatic[str(P/'semantic-commands-unbound.json')]=sha(P/'semantic-commands-unbound.json')
save('strict-static-pins.json',strictstatic)
oldstrict=load(O/'strict-preparation.json')
save('strict-preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'controller_origin':str(O/'strict_cpython.py'),'controller_origin_sha256':sha(O/'strict_cpython.py'),'controller_sha256':sha(P/'strict_cpython.py'),'complete_shared_static_execution_loop_byte_exact':True,'baseline':oldstrict['baseline'],'baseline_outcomes':oldstrict['baseline_outcomes'],'consumer_fix':oldstrict['consumer_fix'],'static_pins_sha256':sha(P/'strict-static-pins.json'),'scope':'Original strict consumer-cleanup backport, same two failures per linkage; separate unchanged two semantic tests per linkage. All target execution remains held.'})
print(json.dumps({'status':'prepared_not_executed','path':str(P),'preparation_sha256':sha(P/'preparation.json'),'scripts':len(scripts),'static_pins':len(static),'strict_static_pins':len(strictstatic)}))
