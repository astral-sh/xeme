"""Materialize current normal correctness controllers; no compiler/parser execution."""
from pathlib import Path
import ast, difflib, hashlib, json, os
assert os.sched_getaffinity(0)=={6}
O=Path('/tmp/oriole-text-plan-combined-correctness')
P=Path('/tmp/oriole-namespace-scopes-correctness')
W=Path('/home/dev-user/code/oss/oriole-namespace-scopes')
B=Path('/tmp/oriole-namespace-scopes-study')
old_work='/home/dev-user/code/oss/oriole-text-plan-combined'
old_build='/tmp/oriole-text-plan-combined-study'
replacements=[(str(O),str(P)),(old_work,str(W)),(old_build,str(B))]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def save(name,value):(P/name).write_text(json.dumps(value,indent=2)+'\n')
def relocate(text):
 for old,new in replacements:text=text.replace(old,new)
 return text
assert __debug__
assert sha('/tmp/oriole-namespace-scopes-independent-source-review.json')=='f18145dddf1ed46ed2d3a1cc09a46568999f4f2e3b064375f526059dff76888f'
assert sha('/tmp/oriole-namespace-scopes-preparation/source.json')=='39001ee1306e2a9e303f734f819b1b810884e7e7b9fa58cd0077eb076dbd5519'
build_binding=load(B/'build-binding.json')
assert build_binding['status']=='passed' and build_binding['source_count']==74
assert build_binding['source_manifest_sha256']==sha(B/'source.json')
assert build_binding['build_sha256']==sha(B/'build.json')
assert load(B/'source.json')['sha256']==load('/tmp/oriole-namespace-scopes-preparation/source.json')['sha256']
assert build_binding['candidate_libraries']=={'liboriole_expat.so':'d6303603fece314e683a5fda5dcb60334c7e302e5e8d87bd7dd13285e46bb63e','liboriole_expat.a':'7d9c06f7d6e63f602d98d95eeab35bfb5967f1cfa8154657f716dc9cedcea8bf'}
P.mkdir(exist_ok=False);(P/'prior').mkdir()
scripts=['api_native.py','strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_api_c.py','read_strict_semantics.py','bind.py','bind_strict.py']
origins={}
for name in scripts:
 before=(O/name).read_text();after=relocate(before)
 if name=='bind.py':
  before_binding="assert review['status'] == 'passed_source_composition_and_held_controller_review'\nassert source['worktree'] == str(W) and len(source['sha256']) == 74\nprepared = load(P / 'reviewed-combined-source.json')\ntext_review = load(P / 'reviewed-text-source.json')\nisolated = load(P / 'reviewed-isolated-source.json')\nassert review['source_manifest_sha256'] == sha(P / 'reviewed-combined-source.json')\nassert source['sha256'] == prepared['sha256']\nassert review['base'] == source['base'] == prepared['base'] == '168b5f57ad5300a74eb77769ccad83e513ebe5c8'\nassert review['source_files_verified'] == prepared['source_count'] == 74\nassert review['four_text_files_byte_exact_to_reviewed_isolated']\nassert text_review['status'] == 'passed_source_review_no_actionable_findings'\nassert text_review['source_manifest_sha256'] == sha(P / 'reviewed-isolated-source.json')\nassert text_review['changed_files'] == prepared['changed'] == ['crates/oriole/src/encoding.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/text.rs', 'crates/oriole/tests/text_coalescing.rs']\nassert all(source['sha256'][name] == isolated['sha256'][name] for name in prepared['changed'])\nassert review['fused_tag_retained'] == source['sha256']['crates/oriole/src/tag.rs'] == '50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6'\nassert review['complete_patch_sha256'] == prepared['complete_patch_sha256'] == text_review['patch_sha256'] == sha(B / 'candidate.patch')"
  after_binding="assert review['status'] == 'independent_namespace_scope_source_and_builder_review_no_blocker'\nassert source['worktree'] == str(W) and len(source['sha256']) == 74\nprepared = load(P / 'reviewed-prepared-source.json')\nassert review['source_manifest_sha256'] == sha(P / 'reviewed-prepared-source.json') == binding['prepared_source_sha256']\nassert source['sha256'] == prepared['sha256']\nassert review['base'] == source['base'] == prepared['base'] == '19b285440bc7467debfa4901df36d86a0e4ef1a0'\nassert review['source_count'] == prepared['source_count'] == 74 and review['all_74_live_source_hashes_verified']\nassert set(review['changed_files']) == set(prepared['changed']) == set(binding['source_delta']) == {'crates/oriole/src/lib.rs', 'crates/oriole/tests/adapter_frame.rs', 'crates/oriole/tests/allocation.rs'}\nassert all(source['sha256'][name] == digest for name, digest in review['changed_files'].items())\nassert review['patch_sha256'] == prepared['complete_patch_sha256'] == sha(B / 'candidate.patch')\ncontrol_path = Path('/tmp/oriole-text-plan-combined-study/source.json')\ncontrol = load(control_path)\nassert binding['control_source_manifest_sha256'] == sha(control_path)\nassert set(source['sha256']) == set(control['sha256'])\nassert {name for name in source['sha256'] if source['sha256'][name] != control['sha256'][name]} == set(review['changed_files'])\nassert binding['control_libraries']['liboriole_expat.so'] == 'ef1648fcb1bae5bce53715283b221166c84e5e8431ff53f39e62a1ecd358bd25'\nassert binding['candidate_libraries'] == {'liboriole_expat.so': 'd6303603fece314e683a5fda5dcb60334c7e302e5e8d87bd7dd13285e46bb63e', 'liboriole_expat.a': '7d9c06f7d6e63f602d98d95eeab35bfb5967f1cfa8154657f716dc9cedcea8bf'}"
  assert before_binding in after
  after=after.replace(before_binding,after_binding)
 if name=='read_api_c.py':
  after=after.replace('Text-plan source author adapted the existing API/C saved reader; root owns target and reader execution. Original raw reconstruction and compiler-vector checks retained; preparation authorship is disclosed.', 'Namespace-prototype author adapted the selected Text API/C saved reader; root owns target and reader execution. Original raw reconstruction and compiler-vector checks retained; preparation authorship is disclosed.')
 if name=='read_strict_semantics.py':
  after=after.replace('Text-plan source author adapted the existing strict/semantic saved reader; root owns target and reader execution. Original raw reconstruction retained; preparation authorship is disclosed.', 'Namespace-prototype author adapted the selected Text strict/semantic saved reader; root owns target and reader execution. Original raw reconstruction retained; preparation authorship is disclosed.')
 ast.parse(after)
 (P/'prior'/name).write_text(before);(P/name).write_text(after)
 (P/(name+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(O/name),tofile=str(P/name))))
 origins[name]={'origin':str(O/name),'origin_sha256':sha(O/name),'sha256':sha(P/name),'path_substitution_only':name not in ('bind.py','read_api_c.py','read_strict_semantics.py')}
assert (P/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]==(O/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]
review_copies={'reviewed-source.json':'/tmp/oriole-namespace-scopes-independent-source-review.json',
              'reviewed-prepared-source.json':'/tmp/oriole-namespace-scopes-preparation/source.json'}
for name,origin in review_copies.items():(P/name).write_bytes(Path(origin).read_bytes())
# Relocate only original unchanged test/consumer inputs, not old output hashes or old controllers.
static={}
strictstatic={}
for filename,destination in [('static-pins.json',static),('strict-static-pins.json',strictstatic)]:
 for path,value in load(O/filename).items():
  if path.startswith(str(O)+'/'):continue
  if path == old_build+'/candidate.patch':continue
  # Only repository input descendants move; historical author scripts and oracles stay at their original paths.
  new=relocate(path) if path.startswith(old_work+'/') else path
  assert sha(new)==value,new;destination[new]=value
for name in scripts:
 destination=strictstatic if name in ('strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_strict_semantics.py','bind_strict.py') else static
 destination[str(P/name)]=sha(P/name)
 static[str(P/'prior'/name)]=sha(P/'prior'/name)
static[str(Path(__file__))]=sha(__file__)
for name in review_copies:static[str(P/name)]=sha(P/name)
static[str(B/'candidate.patch')]=sha(B/'candidate.patch')
assert load(B/'build-binding.json')['status']=='passed'
static[str(B/'build-binding.json')]=sha(B/'build-binding.json')
static[str(Path(old_build)/'source.json')]=sha(Path(old_build)/'source.json')
oldprep=load(O/'preparation.json')
save('preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'source_worktree':str(W),'build_directory':str(B),'controller_origins':origins,'source_review_sha256':sha(P/'reviewed-source.json'),'api':oldprep['api'],'c_consumers':oldprep['c_consumers'],'baseline_api_outcomes':oldprep['baseline_api_outcomes'],'source_delta':'Three reviewed files versus selected Text ea52004/ef1648 carried by19b28544;74 source inputs, only lib.rs runtime plus two tests.','scope':'Direct adaptation of completed selected Text normal correctness controllers. Direct namespace source-review/build binding replaces the previous Text-composition proof; raw readers retain original reconstruction with accurate preparer authorship labels. Original API assertions and limits, six C builds/runs, complete strict shared/static loop, method reader and supplemental semantics unchanged. No target executed or profile-built artifact introduced.'})
save('static-pins.json',static)
spec=load(O/'semantic-commands-unbound.json')
spec=json.loads(relocate(json.dumps(spec)))
for command in spec['commands']:assert command['expected_library_sha256'] is None
save('semantic-commands-unbound.json',spec)
strictstatic[str(P/'semantic-commands-unbound.json')]=sha(P/'semantic-commands-unbound.json')
save('strict-static-pins.json',strictstatic)
oldstrict=load(O/'strict-preparation.json')
save('strict-preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'controller_origin':str(O/'strict_cpython.py'),'controller_origin_sha256':sha(O/'strict_cpython.py'),'controller_sha256':sha(P/'strict_cpython.py'),'complete_shared_static_execution_loop_byte_exact':True,'baseline':oldstrict['baseline'],'baseline_outcomes':oldstrict['baseline_outcomes'],'consumer_fix':oldstrict['consumer_fix'],'static_pins_sha256':sha(P/'strict-static-pins.json'),'scope':'Original strict consumer-cleanup backport and historical two failures per linkage remain the comparison oracle; separate unchanged two semantic tests per linkage. Candidate outcomes pending. All target execution remains held.'})
(P/'README.md').write_text('''# Namespace scopes: held normal correctness gates

Prepared from the completed selected Text controllers. Source74 has one runtime change (lib.rs) and two test changes. Selected performance control is Text ef1648; the original ordered API/strict oracle is retained because selected Text matched it exactly. API has4740 configurations:4347 pass,391 assertion failures,2 timeouts. All original assertions/3s/AS1GiB/RSS768MiB/240s bounds remain. Six C consumers cover integration/adversarial/allocations, dynamic/static; only their C code is ASan/UBSan instrumented, leak checking disabled. Rust libraries are normal release.

Strict shared/static CPython keeps the explicit upstream pyexpat cleanup backport,802 methods/809 rendered outcomes, and the two known callback-fragmentation failures with raw exit2. The unchanged two-test semantic follow-up per linkage remains separate and never turns strict outcomes green.

Root owns every release and execution. Native gain is required before these gates. Saved binders and target commands remain held after materialization; no strict extensions exist yet. No unmodified Python elapsed preparation is included.

After release, root runs bind.py and bind_strict.py on CPU6, api_native.py then read_api_c.py, strict_cpython.py then prepare_semantics.py, run_semantic.py shared then static, and read_strict_semantics.py. Target controllers run CPU3; saved readers run CPU6. Preserve the pinned Python bin first on PATH and use a clean environment as for selected Text. Original child timeouts, process-group cleanup, compile vectors, module origins and raw readers are unchanged.

Historical top-level author-script pins stay at original paths. Only unchanged repository tool/test inputs are relocated. The predecessor candidate.patch pin is replaced explicitly by this reviewed candidate patch. No target was run during preparation.
''')
print(json.dumps({'status':'prepared_not_executed','path':str(P),'preparation_sha256':sha(P/'preparation.json'),'scripts':len(scripts),'static_pins':len(static),'strict_static_pins':len(strictstatic)}))
