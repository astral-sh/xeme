# Separate successful delivery from error recovery — unbuilt source proposal

## Recommendation and observed scope

Keep next_event_scoped’s normal completion outside its error-processing body and return a fresh `Ok(())`. The one-file patch moves the unchanged decoder-precedence/error-cleanup block into `finish_event_error`. This is a bounded follow-up to the current event-delivery diagnosis; no queue representation, public Result/Error API, position representation, frame ownership, allocator, scanner, persistent state, dependency or codegen hint changes.

The proposal is based on **66ca8e0bf7d9e59412c290298d49660f12b8c26a**, the current **unselected** empty-state candidate, with normal DSO93b735d8. The last published selected source when prepared is c841/eager19251. Root must make any later composition/selection explicit. The warmed-span proposal is absent.

## Evidence and limit

The latest saved Vulkan/Maven namespaces-off,64 KiB profile is from eager19251/c702, before empty-state guards. Its next_event_scoped source is byte-identical to current66ca. In the saved c702 assembly, ordinary successful calls converge on94db3..94dd9, copying a56-byte Result/Error-sized span through eight inline payload load/store instructions. Both clean documents take this path after every inner success. The adapter’s own error-copy block at a0913 is already cold in these samples; changing the public Error representation is not justified by that block.

| Saved profile | Inner successes | Inline result-copy Ir | % of collected Ir |
|---|---:|---:|---:|
| vulkan-candidate-ns0 | 335,150 | 2,681,200 | 0.346% |
| maven-candidate-ns0 | 7,452 | 59,616 | 0.456% |

All error-postprocessing entries and adapter-error copies were zero in those two profiles. Full exact-object self PC records and source/capture hashes are in [saved-evidence.json](saved-evidence.json). These observations are **not current66ca machine-code or elapsed measurements**. The current bounded capture did not include its compiled scoped body. The observed c702 scoped prologue reserves0x4b8 bytes; queued-event temporaries also contribute, so error separation cannot be credited with removing that whole frame. Result-copy savings alone are incremental. Outlining may improve common register/stack setup, but the amount is unknown.

The repeated frame reset, generation validation, table-owner routing, pending-event handling and position publication have real ownership/error contracts. Their wrapper self costs cannot be treated as wholly removable. Nonempty queued Event copies remain untouched, as do the now-prepared empty guards. This proposal adds no phase/state cache or dispatch redesign.

## Exact behavior preservation

- `finish_foreign_dtd`, pending-event delivery, and existing sticky-error checks still execute before inner parsing, in the original order, with their original early positions/returns.
- Normal inner `Ok(())` skips `finish_event_error`, publishes positions, then constructs `Ok(())` rather than forwarding a mutable large result. In the source this is one `if let Err` branch, with no error-helper call on success.
- Inner `Err(error)` calls the helper once. Its body begins `let mut result = Err(error)`; every subsequent decoder-priority, UnknownEncoding-recovery exception, active-entity clear, NoMemory queue/frame clear, namespace cleanup allocation, error overwrite and prefix/pending-event recovery statement is byte-identical to the old error-processing block.
- If that helper returns Err, `?` returns before position publication, exactly as the original `result.is_ok()` guards did. If it returns Ok for an already-published Text prefix or pending cleanup event, execution rejoins the same publication block. Event position is written first, then active frame position, preserving frame precedence if both slots are populated. If neither exists, last_position is unchanged.
- Error is Copy and owns no destructor-bearing storage. Moving its value into the helper adds no name-owner/drop/allocator-callback lifetime change. Queued namespaces and Text/frame owners stay in their original objects. No Rust parser borrow crosses a C callback; the outer adapter API is unchanged.
- No `#[cold]`, forced inlining, target flags or PGO is added. Actual codegen must show that the helper separates and normal result forwarding disappears; source shape alone is not proof.

`source.json` retains the full74-file original/proposed maps and four unchanged auxiliary hashes. Only core lib.rs changes. The baseline lib matches the actual66ca Git blob, all live source hashes match its completed source manifest, and removing the new arrangement reproduces the exact original scoped function. No formatter, compiler, parser, benchmark or target was executed.

## Existing focused gates (held)

No new mirror tests are needed for this control-flow extraction. Retain the full workspace/strict compatibility gates and run these existing cases when root releases targets:

- Core `context_text_native_prefix_precedes_late_accounting_error`: ordinary and C-context Text prefix returns first, position/raw exact, sticky limit error arrives next with cleared slots.
- Adapter `ordinary_text_precedes_accounting_failure_but_cdata_does_not`, `owned_frames_preserve_events_positions_raw_and_error_order_at_every_chunk_size`, `reference_frames_preserve_boundaries_positions_and_error_prefixes`, and `namespace_plans_preserve_errors_and_owned_expansions`.
- Allocation `output_slots_clear_at_every_selected_allocation_failure` and `detached_start_frames_use_the_selected_suite_and_clear_on_every_failure`: no published partial owner survives allocation failure, retry remains terminal and allocator cleanup stays complete.
- Existing custom-encoding/UnknownEncoding recovery and full C shared/static suites: decoder precedence and later installation remain required gates.

First measure ordinary generic release against the exact chosen base. Preserve all adverse results. No claim that this change closes the remaining production-speed gap follows from the present evidence.
