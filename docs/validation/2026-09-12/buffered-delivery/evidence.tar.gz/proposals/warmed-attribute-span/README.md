# Warmed literal attribute spans: unbuilt proposal

Base: published `c8411446d5dc27a0f2c86d2bf48a71ee640cfb15`, runtime `19251bc01dba14cc57507facd2d607a9075471b5`. All 74 current source bytes and four auxiliary files match the measured eager-position library. This proposal changes `arena.rs`, `lib.rs`, and two existing test files under `source/`. The independent empty-state guards are not composed here. No formatter, compiler, test, parser, benchmark, or worktree mutation was run.

## Intended change

The existing identity-namespace literal Start path validates one native UTF-8 token of at most 4 KiB with at most 128 attributes. It currently copies each value and name into a detached frame through separate appends. After the original metadata reservation, this proposal checks whether the existing byte capacity can already hold the attribute source span plus the element name and its NUL. Eligible nonempty spans retain the original duplicate loop, then copy the attribute span once and overwrite each name delimiter and closing quote with NUL. Existing scalar offsets identify the resulting callback slices in source order.

```
Source -> owned token_scratch -> validate raw attribute offsets
                             -> original duplicate checks
                             -> warmed frame: one rest-byte copy, NUL delimiters
                             -> existing name append, stack owner, Start publish
       -> current_raw (existing token-buffer swap)
```

There is no new byte-capacity growth request. The existing fallible bulk-copy helper still checks capacity internally; the eligibility proof makes that check unable to allocate. Attribute-record reservation stays at its original point. More than eight attributes retain the original fallible duplicate HashSet insertions in the original order. Ineligible/cold frames continue value-before-name appends exactly. Because packed fields are no larger than the eligible source span, those omitted warm appends could not allocate; duplicate and allocator-error precedence is preserved. The stack name, End name owner, empty-End queue and publication order are unchanged.

## Byte storage and ownership

Only the private frame byte buffer changes from the storage String wrapper to its underlying allocator-backed Vec<u8>. The old String push/reserve methods delegate to the same Vec operations and `try_extend_from_slice`; direct Vec reservation errors convert through the same existing `From<TryReserveError> for AllocError` implementation. No unsafe code or dependency is added.

| Frame operation | Preservation |
| --- | --- |
| new / clear / finish | Same selected allocator, drop order and 4 KiB retention cap; clearing removes all old ranges and payload state. |
| cold Start append / set_name | Same checked lengths, growth policy, copy helper and trailing NUL. |
| warmed Start | Validated byte ranges, original callback byte count and source order; only ASCII delimiters are overwritten, including zero-length values. |
| inline Text | Same inline bytes and no allocation. |
| heap Text | Same exact reservation, copy helper and length-delimited byte projection. |
| explicit C-context Text | Same reservation, absolute range and host protocol; no new owned text copy. |
| End | Same detached String owner, take/recycle behavior and allocation-free warmed handoff. |
| projections / position / publish | Same owned byte slices and event timing; no source borrow crosses a callback. |

The original raw token is separate and remains unchanged for `current_raw` and DefaultCurrent. C handler snapshots, recursion/free/reset guards, suspended frame lifetime, custom-allocator ownership and child parsing are untouched. Existing callback reentry/suspension/DefaultCurrent tests must remain in the eventual compatibility gate.

## Focused source tests

- One private frame test derives offsets with the existing scanner; checks cold and one-byte-short rejection, exact-fit acceptance, the 4 KiB bound, unchanged pointers/capacities, mixed quotes, Unicode names/values, empty values, source punctuation and callback counts.
- One private parser integration test checks that a real third warmed Start uses the source-span length and element-name offset, preserving its buffer pointer/capacity and callback slices.
- One adapter-vs-owned test compares complete events, positions, raw spellings and errors at chunks 1/7/16/full, for 1/8/9/128/129 attributes; duplicate names, references and newline normalization exercise their existing fallback/error paths. Identity namespace mode also uses a multibyte separator.
- One extra workload in the existing custom-allocator failure sweep warms both buffers before the Unicode/empty-value span. The existing sweep checks every allocation failure, terminal-error retry, no global allocator bypass and full cleanup. Existing End allocation and Text/Start retention tests remain.

## Limits and next gate

This copies quotes and whitespace that the packed path omits; the potential saving is fewer per-field append/check calls, not fewer copied bytes. The frame still owns callback storage and element names still have separate stack ownership. Namespace expansion, converted input, declarations/default attributes, oversized tokens and cold capacities retain their old paths. No layout, instruction or speed result is claimed.

The current Vulkan/Maven profiles motivated investigating append overhead, but they do not measure this proposal or establish its benefit. Root should first review/apply/format and run ordinary workspace checks plus the focused/custom-allocator tests, then use the unchanged native gate if warranted. Run no PGO or extra target-CPU flags. A successful build and current correctness/measurement evidence are required before selection.

## Reconstruction

`source.json` contains the exact 74-file proposed map and original map; only four changed files are copied into `original/` and `source/`. `proposal.patch` is their complete unified diff against the published base. `proposal.json` pins these inputs, the inspected storage implementations and this note. Root owns any proper worktree, formatting, execution and subsequent proof of actual outputs.

The initial frozen proposal is retained under `before-integration-coverage/`. The follow-up adds only the private parser integration test; runtime bytes are identical. Neither version has been built or run.
