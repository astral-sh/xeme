# Held eager bare-tag confirmation

One separate normal native epoch and one normal CPython epoch compare runtime `19251bc01dba14cc57507facd2d607a9075471b5` (candidate `c702`, prebuild base `0c407`), selected attribute `b850` and pinned normal Expat `7a333`. Initial campaigns remain immutable and separate. No pooling, favorable-run selection, recompilation or automatic retries.

The initial Python campaign is still running at preparation. Its outputs are not read here. Root must fill `initial_python_primary_sha256`, `initial_python_independent_sha256` and set `materialization_release` to `released_by_root_after_initial_python_audit` in `recipe.json` after completed readback and an explicit continuation decision; preserve the pending recipe first. The finalizer verifies the independent receipt binds the same current primary result and runtime before creating the confirmation directory.

The direct attribute-confirmation adaptation retains all libraries and six O2 modules in their existing directories, unmodified CPython3.12.13 sources and the original driver, inputs, conditions, seeds, bounds and arithmetic. Python's build job is removed; fresh preflights remain mandatory. Normal Oriole uses the existing generic O3/ThinLTO/cgu1 recipe; the Expat control retains its distinct pinned normal GCC recipe. No compiler runs or flags are added.

- Native:28 conditions,7 pairs,84 preflight+588 timed workers,106176 samples; CPU5 preflight thenCPU0 timing.
- Python:24 conditions,7 pairs,72 preflight+504 timed workers,26364 samples; CPU3 preflight thenCPU0 timing; zero compiles/six reused modules.
- Native/Python workers:90/300s; preflight controllers:600s; elapsed controllers:1200s.

Root first runs held `prepare.py` onCPU6 after filling the completed-result pins. It verifies original inputs and constructs all eight transformed scripts before creating `/tmp/oriole-eager-bare-tag-position-confirmation`. It never starts a target. Root then owns native `run.py`, `read_results.py`, Python `run.py prepare`, `preflight_review.py`, `run.py time`, and `elapsed_review.py`, all with the existing clean environment and pinned interpreter policy. Native and Python targets are scheduled separately, with a fresh before-host observation and the existing pinned `monitor-host.py` around each elapsed phase. No parser/compiler/elapsed commands are released by this plan.

Native ROOT and Python D retain current source/build/compiler/module provenance; native NATIVE and Python C/S select fresh outputs. No prior raw worker or result is copied into confirmation. The candidate's74 inputs/three-file delta/four unchanged auxiliary files remain attached to the completed build. Current candidate scopes and all adverse rows, including generated cases, must be retained. No compatibility or adoption result is inferred here.

CPU affinity and local scheduling do not establish a globally idle or exclusive host. Before/during observations are recorded separately; use only fully interior monitor intervals for elapsed attribution. Confirmation is a separate observed epoch, not a significance or platform-wide claim.
