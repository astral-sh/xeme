# Eager bare-tag positions: held normal correctness gates

Candidate runtime19251bc01dba14cc57507facd2d607a9075471b5 was measured from published0c407. The reviewed tag.rs/encoding.rs/lib.rs delta spans74 source files; four auxiliary files and dependencies remain unchanged. Current actual candidate normalSOc702fda9/static29390ba6 versus selected attribute runtime910387/SOb850.

The original API oracle retains4740 configurations:4347 passes,391 assertion failures and2timeouts. All assertions and original3s per-case,1GiB address-space,768MiB RSS,240s suite and300s outer bounds remain. Six dynamic/static integration/adversarial/allocation C consumers retain C-only ASan/UBSan, leak checking disabled,120s per compile/run; Rust uses ordinary generic release.

Strict shared/static CPython retains the explicit pinned upstream pyexpat cleanup backport,802methods/809rendered outcomes and two known callback-fragmentation failures per linkage (raw exit2). Each strict controller child retains1000s. Separate two semantic tests per linkage remain unchanged. Benchmark consumers use unmodified CPython; these patched strict modules are distinct.

Root releases materialization and targets only after performance gates justify continuation. The materializer only writes source scripts and saved bindings. Root runs bind.py and bind_strict.py onCPU6; api_native.py onCPU3 then read_api_c.py onCPU6; strict_cpython.py onCPU3; prepare_semantics.py onCPU6, run_semantic.py shared then static onCPU3, then read_strict_semantics.py onCPU6. Original commands, clean environment, pinned Python, timeout/teardown and raw exits remain. No PGO/flags or assertions change. Root schedules targets after elapsed measurements have ended.

Historical author-script pins/oracles retain original paths. No prior result is presented as a candidate outcome. New strict initialization is accurately labeled as a provenance change from the start. No parser/compiler/strict extension is executed by the source preparer.
