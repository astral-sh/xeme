# Held eager bare-tag build/codegen readback

Adapted directly from the completed attribute saved reader. Root runs this only after the ordinary build binder, actual artifact capture and primary codegen reader finish. It runs no compiler, parser or artifact tool and writes only its own new review receipt.

The exact binder assertions are replayed without its output guard/write, preserving all 74 source identities, three changed files, four auxiliary files, 459 tests/35 groups, seven build commands, three core and three dependency compiler vectors, actual tools and normal libraries. Normal generic Oriole O3/ThinLTO/one-codegen-unit policy stays compared to the selected attribute b850 control. No historical packet is reopened.

The saved codegen reader is replayed only before its report write. It independently rebuilds the symbol inventory and actual capture vectors from saved readelf/nm/objdump output. Missing consume_ascii_tag symbols and parser-parent fallback remain explicit. These are static machine-code observations, with no inferred object layout or measured speed.

Root launch after reports exist:

```sh
taskset -c 6 python3 -I -S /tmp/oriole-eager-bare-tag-position-independent-readers/build_codegen.py --build-binding-sha ACTUAL_BUILD_BINDING_SHA --codegen-report-sha ACTUAL_CODEGEN_REPORT_SHA --candidate-so ACTUAL_SO_SHA
```

Add `--runtime-commit ACTUAL_COMMIT` only after root creates a commit. Otherwise the exact working-source map is bound. Base 0c407 publishes the measured attribute runtime 910387; no candidate commit is invented. The static pins use the final formatted eager source/preparation. All target and primary-reader execution stays with root.
