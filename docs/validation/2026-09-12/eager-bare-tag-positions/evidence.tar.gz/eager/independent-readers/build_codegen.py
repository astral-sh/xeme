"""Held saved-only build/codegen replay; never execute a compiler or target."""
from pathlib import Path
import argparse,ast,hashlib,json,os,re,subprocess
assert __debug__ and os.sched_getaffinity(0)=={6}
a=argparse.ArgumentParser()
for option in ['build-binding-sha','codegen-report-sha','candidate-so']:a.add_argument('--'+option,required=True)
a.add_argument('--runtime-commit')
a=a.parse_args()
assert all(re.fullmatch('[0-9a-f]{64}',v) for v in [a.build_binding_sha,a.codegen_report_sha,a.candidate_so])
assert a.runtime_commit is None or re.fullmatch('[0-9a-f]{40}',a.runtime_commit)
P=Path('/tmp/oriole-eager-bare-tag-position-preparation');S=Path('/tmp/oriole-eager-bare-tag-position-study');D=S/'codegen'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
static={'/tmp/oriole-eager-bare-tag-position-preparation/prepared.json': '6080ad50b96db13e2d2b41231c2576a4a86f2198b2ad87df16ff7c57d75de6a4', '/tmp/oriole-eager-bare-tag-position-preparation/source-binding.json': '4ab49bd050dbf8c95c6addaad6073e8029a538d1b2b5b967b08419b449002f08', '/tmp/oriole-eager-bare-tag-position-preparation/source.json': '40cdcc917cb694b65692f96b63bf2946af3d5307a96cf54a01c33abbbb68bc5a', '/tmp/oriole-eager-bare-tag-position-preparation/expected-source.json': 'b0b7dedfb90b26df06bf87f4f92d61c6d5db093321258f1e4b4e713eb59296f7', '/tmp/oriole-eager-bare-tag-position-preparation/bind_build.py': '667e199ea3fcc74cba6e4e2425490a90b108ced58b5cd7144c1919c50d6f4086', '/tmp/oriole-eager-bare-tag-position-preparation/codegen/read.py': 'e44946a5f449958b8728eee24064c5df1ea4d8ce2df0170066b542a2a4f9e9f2', '/tmp/oriole-eager-bare-tag-position-preparation/codegen/capture.py': '83a9aaa006adb1d58d4cc6ee3b5fbba6321d6467bdc77e7aa25f618ad249da6d'}
for p,h in static.items():assert H(p)==h,p
assert H(S/'build-binding.json')==a.build_binding_sha
assert H(D/'report.json')==a.codegen_report_sha
# Replay exact actual-vector/source/check assertions, dropping only the original
# output-existence guard and outer try/finally writer. Git reads remain read-only.
binder=P/'bind_build.py';text=binder.read_text();tree=ast.parse(text)
cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Try))
prefix=[];removed=[]
for n in tree.body[:cut]:
 if isinstance(n,ast.Assert) and ast.get_source_segment(text,n)=='assert not report_path.exists()':removed.append(n)
 else:prefix.append(n)
assert len(removed)==1
body=prefix+tree.body[cut].body
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','mkdir','unlink'} for node in body for n in ast.walk(node))
scope={'__file__':str(binder),'__name__':'independent_saved_build_replay'}
exec(compile(ast.Module(body=body,type_ignores=[]),str(binder),'exec'),scope)
binding=J(S/'build-binding.json');assert binding==scope['report']
assert binding['tests']=={'passed':459,'groups':35,'failures':0,'ignored':0}
assert binding['candidate_libraries']['liboriole_expat.so']==a.candidate_so
assert binding['control_libraries']['liboriole_expat.so']=='b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5'
source=J(S/'source.json');W=Path(source['worktree']);aux=binding['auxiliary_files']
assert len(source['sha256'])==74 and len(aux)==4
assert source['base']=='0c407f28e2aa01178fda86a97561ed734f8d8e1d'
assert set(binding['source_delta'])=={'crates/oriole/src/tag.rs','crates/oriole/src/encoding.rs','crates/oriole/src/lib.rs'}
# An optional candidate commit is verified only when root has created one.
if a.runtime_commit:
 for n,h in {**source['sha256'],**aux}.items():
  assert hashlib.sha256(subprocess.check_output(['git','-C',str(W),'show',a.runtime_commit+':'+n])).hexdigest()==h,n
# Replay only the completed codegen reader's saved-input assertions and raw
# symbol/mnemonic reconstruction, before its exclusive report write.
reader=P/'codegen/read.py';reader_text=reader.read_text();tree=ast.parse(reader_text)
cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.With))
assert "report.json" in ast.get_source_segment(reader_text,tree.body[cut])
body=tree.body[:cut]
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','check_output','mkdir','unlink','system'} for node in body for n in ast.walk(node))
codegen={'__file__':str(reader),'__name__':'independent_saved_codegen_replay'}
exec(compile(ast.Module(body=body,type_ignores=[]),str(reader),'exec'),codegen)
assert J(D/'report.json')==codegen['r']
capture=J(D/'capture.json')
assert capture['status']=='captured_current_release_bare_tag_disassembly' and capture['targets_executed'] is False
assert capture['reader_sha256']==H(P/'codegen/capture.py')
assert set(capture['engines'])=={'control','candidate'}
for engine,study in [('control',Path('/tmp/oriole-attribute-lane-masks-study')),('candidate',S)]:
 e=capture['engines'][engine];b=J(study/'build.json');s=J(study/'source.json')
 prefix='' if engine=='candidate' else 'control_'
 assert H(study/'source.json')==binding[prefix+'source_manifest_sha256']
 assert H(study/'build.json')==binding[prefix+'build_sha256']
 assert e['study']==str(study) and e['worktree']==s['worktree']
 so=study/'normal/liboriole_expat.so'
 assert Path(e['library'])==so and e['library_sha256']==H(so)==b['libraries'][so.name]==binding[engine+'_libraries'][so.name]
 assert so.read_bytes()[:4]==b'\x7fELF'
 for name,value in b['libraries'].items():assert H(study/'normal'/name)==value
 labels=[row['label'] for row in capture['commands']]
 assert len(labels)==len(set(labels))==len(codegen['expected'])
for p,h in capture['pins'].items():assert H(p)==h,p
r={'status':'passed_independent_saved_build_and_codegen_review','targets_executed':False,'base':source['base'],'runtime_commit':a.runtime_commit,'source_count':74,'source_delta':binding['source_delta'],'auxiliary_files':aux,'tests':binding['tests'],'candidate_libraries':binding['candidate_libraries'],'control_libraries':binding['control_libraries'],'actual_core_compiler_vectors':J(S/'build.json')['compiler_vectors'],'actual_dependency_compiler_vectors':J(S/'build.json')['dependency_compiler_vectors'],'codegen_capture_commands':len(capture['commands']),'codegen_symbols':codegen['summaries'],'findings':[],'roles':'Separate saved execution of reviewed binder assertions and codegen reader, with additional actual source/build/library cross-binding. This reviewer authored the held codegen capture/read adaptation and reviewed the bare-tag proposal; another agent authored the current ordinary build/binder and source composition. A separate peer reviews this saved reader. Root owned all compiler/parser and artifact-capture invocations.','limitations':['Static symbols and mnemonic lines do not prove dynamic frequencies, executed paths or elapsed gains.','Address-line counts include byte wraps and are not instruction counts; inline parent instructions are not automatically attributed to the helper.','No layout measurement or code-size expectation is imposed. A null runtime_commit means the exact working-tree source map is bound before a candidate commit exists.'],'pins':{str(p):h for p,h in static.items()}|capture['pins']|{str(S/'build-binding.json'):a.build_binding_sha,str(D/'report.json'):a.codegen_report_sha,str(D/'capture.json'):H(D/'capture.json'),str(S/'source.json'):H(S/'source.json'),str(S/'build.json'):H(S/'build.json')},'reader_sha256':H(__file__)}
out=Path('/tmp/oriole-eager-bare-tag-position-independent-build-codegen-review.json')
with out.open('x') as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'tests':r['tests'],'symbols':{k:list(v) for k,v in r['codegen_symbols'].items()},'receipt':str(out),'sha256':H(out)},indent=2))
