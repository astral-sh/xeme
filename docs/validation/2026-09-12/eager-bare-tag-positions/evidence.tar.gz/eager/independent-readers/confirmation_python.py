"""Completed normal CPython raw/origin/host audit; no parser or target execution."""
from pathlib import Path
import ast,csv,hashlib,json,math,os,re,subprocess,sys
assert __debug__ and os.sched_getaffinity(0)=={6}
assert len(sys.argv)>=3 and all(re.fullmatch("[0-9a-f]{64}",v) for v in sys.argv[1:3])
PRIMARY_SHA=sys.argv[1]
ROOT=Path('/tmp/oriole-eager-bare-tag-position-study');D=ROOT/'python';CONF=Path('/tmp/oriole-eager-bare-tag-position-confirmation');C=CONF/'python';OLD=Path('/tmp/oriole-attribute-lane-masks-study/python')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text())
assert H(C/'normal-review.json')==PRIMARY_SHA
assert H(C/'preflight-review.json')==sys.argv[2]
assert H(CONF/'preparation.json')=='9052072193241165b59606e9ccf67510479d4f64f8d62838cb8ac7c907258fe0'
assert H(C/'preflight_review.py')=='ad8bca3c5e2cde2cff130cf4b1d065b58a3972e9d3330e91136315e382f20f66'
assert H(C/'elapsed_review.py')=='a5ec99597b4688b44f3473a7f0177537de5cb8ea52df8ee7c80952793d1c71fb'
assert H(C/'run.py')=='aa1d6cae209348b0623a7f592072d569412d19143c86bc48cc8000df2d36920f'
for name in ['python_worker.py','consumer_screen.py']:assert (C/name).read_bytes()==(D/name).read_bytes()
static={'/tmp/oriole-eager-bare-tag-position-study/python/source-preparation.json': '68d72c997b4d4fdf4511190481677f965a80f58a8ce22624bce02e6f265e7580', '/tmp/oriole-eager-bare-tag-position-study/python/preparation.json': '23a271bd22ded5681456b9ca85c7cf36db7b82130a881e4f6e93bad992b6a6db', '/tmp/oriole-eager-bare-tag-position-study/python/consumer-binding.json': '1af50c1f4c39e1daeb3dd334995354d5189fe8b25a18d3ac813a524534d27fdd', '/tmp/oriole-eager-bare-tag-position-study/python/preflight_review.py': '6ead6807b8878d21ebe40ba481b197d59b2a0e2652370a40ae4b33abc86ff935', '/tmp/oriole-eager-bare-tag-position-study/python/elapsed_review.py': '71d58e0731ced97fee3569863f1202605ec7263a0c281f7c54c0dce9f3241817', '/tmp/oriole-eager-bare-tag-position-independent-python-source-review.json': '3cba0b6cfa284b97788eeede87dbf47947e2aa898f7edddacf9841d64dd98f86'}
for path,value in static.items():assert H(path)==value,path
assert H(D/'elapsed_review.py')=='71d58e0731ced97fee3569863f1202605ec7263a0c281f7c54c0dce9f3241817'
assert H(D/'preflight_review.py')=='6ead6807b8878d21ebe40ba481b197d59b2a0e2652370a40ae4b33abc86ff935'
preparation=J(D/'source-preparation.json')
for mapping in [preparation['pins'],preparation['parent_scripts'],preparation['selected_control_scripts']]:
 for path,value in mapping.items():assert H(path)==value,path
for name in ['python_worker.py','run.py','build_consumers.py']:assert (D/name).read_bytes()==(OLD/name).read_bytes()

def replay(path,stop):
 text=path.read_text();tree=ast.parse(text);lines=text.splitlines()
 cut=next(i for i,n in enumerate(tree.body) if stop(n,lines))
 assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','check_output','mkdir','unlink','system'} for node in tree.body[:cut] for n in ast.walk(node))
 scope={'__file__':str(path),'__name__':'independent_saved_python_replay'}
 exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),str(path),'exec'),scope)
 return scope

pre=replay(C/'preflight_review.py',lambda node,lines:lines[node.lineno-1].startswith('output=C/'))
actual_pre=J(C/'preflight-review.json');assert actual_pre==pre['result']
scope=replay(C/'elapsed_review.py',lambda node,lines:isinstance(node,ast.With) and lines[node.lineno-1].startswith('with csvpath.open'))
actual=J(C/'normal-review.json');expected=dict(scope['report']);expected['condition_csv_sha256']=H(C/'normal-conditions.csv');assert actual==expected
assert scope['D']==D and scope['C']==C and scope['S']==C/'screen'
assert actual_pre['extension_compiles']=={'fresh':0,'reused':6,'total':6}
assert pre['pins']==actual_pre['pins']
with (C/'normal-conditions.csv').open(newline='') as f:rows=list(csv.DictReader(f))
assert rows==[{k:str(v) for k,v in row.items()} for row in scope['rows']]
assert actual['counts']['all_workers']==576 and actual['counts']['all_samples']==26364 and len(actual['summary'])==24
for group,entry in actual['aggregates'].items():
 selected=[r for r in actual['summary'] if group=='all' or r['condition']['mode']==group]
 for name,value in entry['geomean_ratios'].items():assert math.isclose(math.prod(r['median_ratios'][name] for r in selected)**(1/len(selected)),value,rel_tol=1e-14,abs_tol=1e-14)
adverse=[r for r in actual['summary'] if r['median_ratios']['candidate_over_control']>1]
assert actual['aggregates']['all']['adverse_conditions']==[{'condition':r['condition'],**r['median_ratios']} for r in adverse]
for mapping in [pre['pins'],scope['pins']]:
 for path,value in mapping.items():assert H(path)==value,path
source=J(ROOT/'source.json');binding=J(ROOT/'build-binding.json')
assert len(source['sha256'])==74 and H(ROOT/'build-binding.json')=='44ee17d227b4be4498799a7004aec0a6d87f8beae7bce646da6cdede5c177d80'
commit=preparation['candidate_runtime_commit'];assert commit=='19251bc01dba14cc57507facd2d607a9075471b5'
assert set(binding['source_delta'])=={'crates/oriole/src/tag.rs','crates/oriole/src/encoding.rs','crates/oriole/src/lib.rs'}
for name,value in {**source['sha256'],**binding['auxiliary_files']}.items():
 assert H(Path(source['worktree'])/name)==value
 assert hashlib.sha256(subprocess.check_output(['git','-C',source['worktree'],'show',commit+':'+name])).hexdigest()==value,name
assert actual['libraries']['candidate']['sha256']==binding['candidate_libraries']['liboriole_expat.so']=='c702fda9005743ecc2d11cec3a350e4cabcf00da563699c580929cc4fc221f0f'
assert actual['libraries']['control']['sha256']=='b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5'
# Exact existing pure counter arithmetic, embedded to avoid historical reader replay.
def counters(first, last):
    delta = {name: {key: last['cpu'][name][key] - first['cpu'][name][key] for key in ('total', 'idle')} for name in ('cpu', 'cpu0')}
    assert last['time'] > first['time']
    for values in delta.values():
        assert 0 <= values['idle'] <= values['total'] and values['total'] > 0
    other_total = delta['cpu']['total'] - delta['cpu0']['total']
    other_idle = delta['cpu']['idle'] - delta['cpu0']['idle']
    assert 0 <= other_idle <= other_total and other_total > 0
    return {'start': first['time'], 'end': last['time'], 'seconds': last['time']-first['time'], 'counter_deltas': delta,
            'idle_including_iowait_fractions': {name: values['idle']/values['total'] for name, values in delta.items()},
            'other_cpus_idle_including_iowait_fraction': other_idle/other_total}
during=J(CONF/'host-during-python.json');controller=J(C/'time-controller.json');timing,=controller['jobs']
assert during['status']=='completed' and during['phase']=='python' and during['controller_status']==controller['status']=='passed'
assert during['controller_sha256']==H(C/'time-controller.json') and during['monitor_sha256']==H(CONF/'monitor-host.py')
before_files=sys.argv[3:] or ['host-before-python.json'];assert len(before_files)==len(set(before_files))
before_records=[]
for filename in before_files:
 assert Path(filename).name==filename and filename.endswith('.json')
 before=J(CONF/filename)
 assert len(before['samples'])==2 and before['samples'][-1]['time']<=timing['start']
 before_summary=counters(before['samples'][0],before['samples'][-1]);assert before_summary['idle_including_iowait_fractions']==before['idle_plus_iowait_fraction']
 before_records.append({'file':filename,'sha256':H(CONF/filename),'summary':before_summary})
assert all(x['summary']['end']<=y['summary']['start'] for x,y in zip(before_records,before_records[1:]))

intervals=[counters(x,y) for x,y in zip(during['samples'],during['samples'][1:])]
inside=[r for r in intervals if timing['start']<=r['start'] and r['end']<=timing['end']]
outside=[r for r in intervals if not (timing['start']<=r['start'] and r['end']<=timing['end'])]
points=[p for p in during['samples'] if timing['start']<=p['time']<=timing['end']];assert inside and len(points)>=2 and len(inside)+1==len(points)
aggregate=counters(points[0],points[-1]);assert math.isclose(sum(r['seconds'] for r in inside),aggregate['seconds'],abs_tol=1e-9)
for cpu in ['cpu','cpu0']:
 for key in ['total','idle']:assert sum(r['counter_deltas'][cpu][key] for r in inside)==aggregate['counter_deltas'][cpu][key]
host={'before':before_records,'during_sample_count':len(during['samples']),'elapsed_controller':{'start':timing['start'],'end':timing['end'],'seconds':timing['end']-timing['start']},'sample_intervals_fully_inside_elapsed':{'count':len(inside),'aggregate':aggregate,'fraction_of_elapsed':aggregate['seconds']/(timing['end']-timing['start']),'other_cpus_idle_range':[min(r['other_cpus_idle_including_iowait_fraction'] for r in inside),max(r['other_cpus_idle_including_iowait_fraction'] for r in inside)],'intervals':inside},'excluded_outside_or_boundary_intervals':outside,'limitations':['Five-second /proc/stat samples count idle+iowait and exclude duplicate guest fields; no OS isolation or absence-of-contention claim.','Only consecutive intervals fully inside elapsed are attributed; no interpolation or per-condition attribution.','Pre-run observation remains separate from during-run activity.']}
paths=[CONF/'preparation.json',C/'preparation.json',D/'source-preparation.json',C/'preflight_review.py',C/'elapsed_review.py',C/'preflight-review.json',C/'normal-review.json',C/'normal-conditions.csv',C/'prepare-controller.json',C/'time-controller.json',ROOT/'source.json',ROOT/'build-binding.json',*(CONF/name for name in before_files),CONF/'host-during-python.json',CONF/'monitor-host.py',Path(__file__)]
result={'status':'passed_independent_normal_python_raw_and_host_review','targets_executed':False,'role':'Separate current saved-worker reconstruction by reviewer of eager Python preparation and author of preceding attribute recipes. Current eager runtime/preparation have separate authors. Only current primary prefixes are replayed; host arithmetic is embedded unchanged, with no historical reader execution. Root owns all targets and primary readers.','runtime_commit':commit,'counts':actual['counts'],'aggregates':actual['aggregates'],'all_conditions':actual['summary'],'all_adverse_conditions':adverse,'host':host,'provenance':{'libraries':actual['libraries'],'main_source_files':74,'main_changed_files':list(binding['source_delta']),'auxiliary_files_unchanged':4,'preflight_pins':len(pre['pins']),'elapsed_pins':len(scope['pins']),'fresh_compiles':0,'reused_modules':6},'limitations':['All24 conditions and every adverse row retained. Initial and confirmation epochs remain separate without pooling. This confirmation normal CPython project-input benchmark is not whole-application performance or exact callback-fragmentation compatibility.','Unmodified CPython3.12.13 O2 modules, module/dladdr origins, enabled GC, parse construction/feed/finalization/callbacks plus explicit destruction and canonical hashes match the original protocol.','No causal, statistical-significance or exclusive-host assertion. Current candidate adoption remains a separate root decision.'],'pins_sha256':{str(p):H(p) for p in paths},'reader_sha256':H(__file__)}
out=Path('/tmp/oriole-eager-bare-tag-position-confirmation-independent-python-review.json')
with out.open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'receipt':str(out),'sha256':H(out),'counts':actual['counts'],'aggregates':actual['aggregates'],'fully_interior_host':{'intervals':len(inside),'seconds':aggregate['seconds'],'elapsed_seconds':timing['end']-timing['start'],'other_cpus_idle_iowait':aggregate['other_cpus_idle_including_iowait_fraction'],'excluded_intervals':len(outside)}},indent=2))
