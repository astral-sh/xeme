# Held eager-position correctness commands

Root owns execution after all elapsed targets are reaped. The materializer has already completed; do not rerun it. Run these steps once, in order.

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-eager-bare-tag-position-correctness/bind.py
```

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-eager-bare-tag-position-correctness/bind_strict.py
```

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-eager-bare-tag-position-correctness/api_native.py
```

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-eager-bare-tag-position-correctness/read_api_c.py
```

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-eager-bare-tag-position-correctness/strict_cpython.py
```

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-eager-bare-tag-position-correctness/prepare_semantics.py
```

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-eager-bare-tag-position-correctness/run_semantic.py shared
```

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-eager-bare-tag-position-correctness/run_semantic.py static
```

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-eager-bare-tag-position-correctness/read_strict_semantics.py
```

After the two primary readers complete, run the independent saved reader with their actual SHA-256 hashes. The placeholders below must be replaced.

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-eager-bare-tag-position-independent-readers/correctness.py '<SHA256 of completed api-c-readback.json>' '<SHA256 of completed strict-semantic-readback.json>'
```

The original 4,740-row matrix keeps 4,347 passes, 391 assertion failures and two timeouts if unchanged. Six C consumers use ASan/UBSan on the C harness only. Strict shared/static suites retain 802 method outcomes, 809 rendered lines and two failures (raw exit 2) per linkage. Each linkage has two separate semantic tests; passing them does not turn the strict suites green.

The current source has 74 main files and four auxiliary files, with only three main-file changes. This reader reconstructs saved results independently of root execution; its author also prepared the candidate source and protocols.
