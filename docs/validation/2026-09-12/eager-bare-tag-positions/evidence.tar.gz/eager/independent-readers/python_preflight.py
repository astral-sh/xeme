"""Replay completed Python preflight records only, without loading modules."""
from pathlib import Path
import ast,hashlib,json,os,re,sys
assert __debug__ and os.sched_getaffinity(0)=={6}
assert len(sys.argv)==2 and re.fullmatch('[0-9a-f]{64}',sys.argv[1])
D=Path('/tmp/oriole-eager-bare-tag-position-study/python')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
static={'/tmp/oriole-eager-bare-tag-position-study/python/source-preparation.json': '68d72c997b4d4fdf4511190481677f965a80f58a8ce22624bce02e6f265e7580', '/tmp/oriole-eager-bare-tag-position-study/python/preparation.json': '23a271bd22ded5681456b9ca85c7cf36db7b82130a881e4f6e93bad992b6a6db', '/tmp/oriole-eager-bare-tag-position-study/python/consumer-binding.json': '1af50c1f4c39e1daeb3dd334995354d5189fe8b25a18d3ac813a524534d27fdd', '/tmp/oriole-eager-bare-tag-position-study/python/preflight_review.py': '6ead6807b8878d21ebe40ba481b197d59b2a0e2652370a40ae4b33abc86ff935', '/tmp/oriole-eager-bare-tag-position-study/python/elapsed_review.py': '71d58e0731ced97fee3569863f1202605ec7263a0c281f7c54c0dce9f3241817', '/tmp/oriole-eager-bare-tag-position-independent-python-source-review.json': '3cba0b6cfa284b97788eeede87dbf47947e2aa898f7edddacf9841d64dd98f86'}
for p,h in static.items():assert H(p)==h,p
assert H(D/'preflight-review.json')==sys.argv[1]
reader=D/'preflight_review.py';text=reader.read_text();tree=ast.parse(text);lines=text.splitlines()
cut=next(i for i,n in enumerate(tree.body) if lines[n.lineno-1].startswith('output=D/'))
body=tree.body[:cut]
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','check_output','mkdir','unlink','system'} for node in body for n in ast.walk(node))
scope={'__file__':str(reader),'__name__':'independent_saved_python_preflight_replay'}
exec(compile(ast.Module(body=body,type_ignores=[]),str(reader),'exec'),scope)
primary=J(D/'preflight-review.json');assert primary==scope['result']
assert primary['preflight_workers']==72 and len(primary['conditions'])==len(primary['canonical_outputs'])==24
assert primary['extension_compiles']=={'fresh':2,'reused':4,'total':6}
assert len(primary['exact_compile_vectors'])==6 and set(primary['origins'])=={'candidate','control','expat'}
prior=J(D/'source-preparation.json');assert prior['candidate_runtime_commit']=='19251bc01dba14cc57507facd2d607a9075471b5'
for engine,h in [('candidate','c702fda9005743ecc2d11cec3a350e4cabcf00da563699c580929cc4fc221f0f'),('control','b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5'),('expat','7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478')]:assert primary['origins'][engine]['parser_library']['sha256']==h
for p,h in scope['pins'].items():assert H(p)==h,p
r={'status':'passed_independent_saved_python_preflight_review','targets_executed':False,'runtime_commit':prior['candidate_runtime_commit'],'preflight_workers':72,'canonical_conditions':24,'extension_compiles':primary['extension_compiles'],'compiler_vectors':primary['exact_compile_vectors'],'origins':primary['origins'],'primary_sha256':H(D/'preflight-review.json'),'canonical_outputs':primary['canonical_outputs'],'pins':dict(scope['pins'])|static|{str(D/'preflight-review.json'):H(D/'preflight-review.json')},'reader_sha256':H(__file__),'role':'Separate saved replay by reviewer of the Python preparation; this reviewer authored related ancestor recipes but did not author current target workers or execute modules. Root owns producer/preflight targets and primary readback.','limits':'Canonical output equality merges character chunks; these preflights do not replace strict CPython tests or establish elapsed performance.'}
out=Path('/tmp/oriole-eager-bare-tag-position-independent-python-preflight-review.json')
with out.open('x') as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'workers':72,'conditions':24,'pins':len(r['pins']),'sha256':H(out)}))
