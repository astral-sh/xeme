# Eager bare-tag positions: held normal CPython protocol

Root materializes this source recipe only after a native gain and a completed normal build/binding. It uses the final committed candidate source and actual ordinary libraries; source base0c407 and runtime commit remain distinct.

The selected attribute normal b850 candidate modules become this control. Both existing Expat modules remain pinned. We compile only two fresh candidate modules from unmodified CPython3.12.13 source using the same O2 commands, then run72 fresh canonical preflights and504 timed workers (24conditions,7pairs,26364samples). No strict cleanup backport is added to timed modules. The complete worker, controller and module-builder bytes remain identical; only screen captions and saved-reader study paths change.

Each original count, seed, callback/tree comparison, actual module/parser origin, worker timeout, GC policy, construction/destruction boundary and paired-median calculation remains. All adverse rows are retained. Fresh before/during host observations remain separate; CPU0 affinity is not global isolation. No PGO, compiler flag, dependency or allocator change.

Root runs prepare.py and bind.py onCPU6 after materialization; these only read saved artifacts/provenance and write the protocol. Actual build+preflight is held in held-commands.json onCPU3; elapsed usesCPU0; saved readers useCPU6 after controllers are reaped. No candidate consumer build, parser/preflight or elapsed target is run during source preparation.
