# Eager positions for bare ASCII opening tags

Held source-only proposal, unformatted, unbuilt, untested and unselected. Base is
published `aed07bbacf75136330dd777a190ac2a42a2f1ed0`; its 74 measured parser/build
files match selected runtime `cacc0b1b3766176e9cbf71d25c5ff6867fa87c08`.
The control normal DSO is `4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d`.
The complete patch changes only core `tag.rs`, `encoding.rs` and `lib.rs`.

## Minimal mechanism

The existing native opening-name walk collects a sticky ASCII flag, including the
separately validated first character. Its offset and flag survive append-only
resumption and reset with `source_index`. A complete plan proves the whole tag
only when the validated ASCII name is followed immediately by `>` or `/>`.
Valid Unicode names, attributes and whitespace still produce the same completed
plans with the proof absent; their existing coordinate scan remains.

At the original successful markup consume point, after semantic parsing, raw
publication and the original accounting check, the proof permits a column
increment by the consumed byte count. Line is unchanged and previous-CR becomes
false: the nonempty tag starts with `<`, so an earlier CR cannot combine with a
later LF. Raw indexing and the existing finish-consume tail still perform cursor
movement, scanner/deferral reset and the exact 64 KiB/half-buffer compaction.
The branch additionally requires unanchored native UTF-8 without conversions.

Rust event and C callback positions remain eager. No Source fields, deferred
coordinates, C getter changes, owner changes, allocations, unsafe code or new
dependencies are introduced. Closing tags and implicit empty-tag End
`position_at` calls are unchanged. TagScanner and Planned each gain one boolean;
their actual layout/codegen effects are unmeasured. The scanner does extra proof
work on opening names even when later attributes or whitespace disqualify a tag.

## Prior proposals inspected

`/tmp/oriole-selected-lf-coordinate-followup.md` verifies current cacc source and
pinned Expat getters/checkpoints. C-only lazy coordinates already regressed:
`/tmp/oriole-coordinate-experiments-index.md` records deferred normal1.0917x
control, all28 conditions adverse; `/tmp/oriole-compact-coordinate-evidence/README.md`
records the compact attempt's normal1.033262x,23/24 real conditions adverse.
This proposal uses no lazy state. `/tmp/oriole-fused-validation/README.md` records
the rejected completed-token fusion; no extra completed-name pass is added here.

`/tmp/oriole-eager-tag-position-triage.md` and
`/tmp/oriole-eager-tag-position-current-triage.md` proposed eager proof work but
were not implemented. The latter's small bare-name scope is used here. Its
historical absence of fused attribute scanning is no longer current: selected
`tag.rs` is now50f641. We intentionally leave that shared attribute path alone.
There is no current cacc proof-hit rate or profile attribution for this subset;
older whole-function instruction counts are not estimated removable savings.
The added flag/branch cost may outweigh saved scans, especially on short tags.

## Focused tests proposed, not executed

- Every character-boundary split, repeated unchanged resumes, both delimiter
  forms, prefixed ASCII and Unicode names, whitespace and one-attribute controls.
  Valid controls must complete; Unicode proof cannot become true after a later
  ASCII suffix, and a new physical token must reset the state. Record capacity
  stays unchanged.
- A bare lexical plan with an undefined namespace prefix must return its original
  error without consuming input or advancing source coordinates.
- The proven consume helper is compared with original eager consumption for
  short/word-boundary tags, both prior-CR states, and just below/at/above64KiB
  compaction. A following LF must increment the line after the intervening tag.

Existing positions tests (encoding/chunk boundaries, compaction/nonadjacent CRLF,
entity anchors), adapter-frame exact event/position/error-order comparisons,
allocation tests and C callback reentry/suspend/reset tests are untouched and
remain validation gates if the proposal is later composed. The proposed semantic
error case is not an allocation-failure test. No tests, parser, compiler,
formatter, profile or elapsed command ran while preparing this directory.

## Saved preparation details

`proposal.json` contains all74 baseline/proposed source hashes; `proposal.patch`
is the complete three-file diff. `prepare.py` read exact Git blobs and wrote only
this temporary directory. `before-author-source-cleanup/` retains the initial
source draft: source review corrected a sibling-private cursor access to a
remaining-input comparison, fixed the existing error-variant spelling, and used
an explicit local name offset. This was a source-authoring correction before any
formatter/compiler/test execution or peer review, not a runtime test failure.

Next decision, if root authorizes execution: normal formatting/full correctness
checks and actual layout/codegen review, then the existing matched normal native
and CPython protocols with every adverse condition retained. No performance or
production-readiness improvement is claimed by this source proposal.
