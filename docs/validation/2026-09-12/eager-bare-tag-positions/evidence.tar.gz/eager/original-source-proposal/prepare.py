from pathlib import Path
import difflib,hashlib,json,subprocess
D=Path(__file__).parent;W=Path('/home/dev-user/code/oss/oriole-text-lane-masks');base='aed07bbacf75136330dd777a190ac2a42a2f1ed0'
manifest=json.loads(Path('/tmp/oriole-text-lane-masks-study/source.json').read_text())['sha256'];H=lambda b:hashlib.sha256(b).hexdigest()
assert len(manifest)==74
for n,h in manifest.items():assert H(subprocess.check_output(['git','-C',str(W),'show',base+':'+n]))==h,n
files=['crates/oriole/src/tag.rs','crates/oriole/src/encoding.rs','crates/oriole/src/lib.rs'];before={n:subprocess.check_output(['git','-C',str(W),'show',base+':'+n]).decode() for n in files};after=before.copy()
s=after[files[0]]
s=s.replace('    name_end: Option<usize>,\n    attributes:', '    name_end: Option<usize>,\n    name_ascii: bool,\n    attributes:',1)
s=s.replace('    Complete { end: usize, name_end: usize },','    Complete { end: usize, name_end: usize, ascii_bare: bool },',1)
s=s.replace('                self.offset += first.len_utf8();\n            }\n            self.offset = name_end(text, self.offset, rules);', '''                self.name_ascii = first.is_ascii();
                self.offset += first.len_utf8();
            }
            // Reuse the native name walk; complete/general name scans stay unchanged.
            let start = self.offset;
            self.offset = text[start..]
                .char_indices()
                .find(|(_, character)| {
                    if !rules.is_name_char(*character) {
                        return true;
                    }
                    self.name_ascii &= character.is_ascii();
                    false
                })
                .map_or(text.len(), |(index, _)| start + index);''',1)
s=s.replace('                        Planned::Complete { end, name_end }','''                        Planned::Complete {
                            end,
                            name_end,
                            // Only the ASCII name and immediate closing syntax:
                            // attributes or any intervening whitespace lose this proof.
                            ascii_bare: self.name_ascii
                                && end - name_end == if empty { 2 } else { 1 },
                        }''',1)
s=s.replace('Planned::Complete { end, name_end: 2 }','Planned::Complete { end, name_end: 2, .. }')
s=s.replace('                                    name_end,\n                                } => {','                                    name_end,\n                                    ..\n                                } => {',1)
needle='    #[test]\n    fn literal_values_match_separate_checks_at_word_and_unicode_boundaries() {'
test='''    #[test]
    fn bare_ascii_position_proof_preserves_plans_across_splits() {
        for name in ["r", "abcdefgh", "p:r", "é", "aé", "éa"] {
            for suffix in [">", "/>", " >", "\\t/>", "\\r\\n>", " a='v'>"] {
                let input = format!("<{name}{suffix}");
                let expected = name.is_ascii() && matches!(suffix, ">" | "/>");
                for split in (0..=input.len()).filter(|n| input.is_char_boundary(*n)) {
                    let mut records = Vec::new_in(Allocator::System);
                    records.try_reserve_exact(1).unwrap();
                    let pointer = records.as_ptr();
                    let mut scanner = TagScanner::default();
                    // Repeated unchanged input must neither lose nor manufacture a proof.
                    for end in [split, split, input.len(), input.len()] {
                        let plan = scanner.scan(
                            &input[..end], 0, input.len(), 1,
                            NameRules::default(), &mut records,
                        );
                        if end < input.len() {
                            assert!(matches!(plan, Planned::Incomplete), "{input:?} {end}");
                        } else {
                            let Planned::Complete { end, ascii_bare, .. } = plan else {
                                panic!("valid native plan lost: {input:?}");
                            };
                            assert_eq!(end, input.len());
                            assert_eq!(ascii_bare, expected, "{input:?} split={split}");
                        }
                    }
                    assert_eq!(records.as_ptr(), pointer);
                    // Source-index reset must replace a previous non-ASCII name proof.
                    assert!(matches!(
                        scanner.scan("<fresh/>", 100, 100, 1, NameRules::default(), &mut records),
                        Planned::Complete { ascii_bare: true, .. }
                    ));
                }
            }
        }
    }

    #[test]
    fn bare_tag_semantic_error_does_not_consume_source_coordinates() {
        let mut parser = crate::Parser::new(crate::Config {
            namespace_separator: Some('|'),
            ..crate::Config::default()
        });
        parser.feed(b"<r><p:n>", true).unwrap();
        parser.next_event().unwrap().unwrap();
        let before = parser.source().position(0);
        let remaining = parser.source().remaining().to_owned();
        let error = parser.next_event().unwrap_err();
        assert_eq!(error.kind, ErrorKind::UndefinedPrefix);
        assert_eq!(error.position, before);
        assert_eq!(parser.source().position(0), before);
        assert_eq!(parser.source().remaining(), remaining);
    }

'''
assert needle in s;s=s.replace(needle,test+needle,1);after[files[0]]=s
s=after[files[1]]
needle='    /// Commit native text whose scanner already computed the eager position delta.\n'
method='''    /// Consume a nonempty native ASCII tag proven to contain no line breaks.
    /// The caller must complete semantic work and accounting before this mutation.
    pub(crate) fn consume_ascii_tag(&mut self, count: usize) {
        debug_assert!(self.native_utf8_byte_index().is_some() && !self.has_conversions());
        debug_assert!(count > 0 && self.remaining()[..count].bytes()
            .all(|byte| byte.is_ascii() && !matches!(byte, b'\\r' | b'\\n')));
        self.raw_index += self.raw_len(0, count);
        self.column += count;
        self.previous_cr = false;
        self.finish_consume(count);
    }

'''
assert needle in s;s=s.replace(needle,method+needle,1)
needle='    #[test]\n    fn planned_text_matches_eager_consumption_and_compaction() {'
test='''    #[test]
    fn proven_ascii_tag_matches_eager_coordinates_and_compaction() {
        for tag in ["<r>", "<r/>", "<abcdefgh>", "<p:r/>"] {
            for prefix in [0, 65_530, 65_533] {
                for previous_cr in [false, true] {
                    let make_source = || {
                        let mut source = Source::new(Allocator::System, crate::NameRules::default());
                        source.text.try_push_str(&"x".repeat(prefix)).unwrap();
                        source.text.try_push_str(tag).unwrap();
                        source.text.try_push_str("\\nTAIL").unwrap();
                        source.cursor = prefix;
                        source.raw_index = prefix;
                        source.line = 7;
                        source.column = 11;
                        source.previous_cr = previous_cr;
                        source.scan.mode = Some(ScanMode::Tag);
                        source.deferred_size = 12;
                        source
                    };
                    let mut eager = make_source();
                    let mut proven = make_source();
                    eager.consume(tag.len());
                    proven.consume_ascii_tag(tag.len());
                    assert_eq!(proven.position(0), eager.position(0));
                    assert_eq!(proven.previous_cr, eager.previous_cr);
                    assert_eq!(proven.remaining(), eager.remaining());
                    assert_eq!(proven.cursor, eager.cursor);
                    assert_eq!(proven.cursor == 0, prefix + tag.len() >= 65_536);
                    assert!(proven.scan.mode.is_none());
                    assert_eq!(proven.deferred_size, 0);
                    // A prior CR must not absorb the LF after an intervening tag.
                    eager.consume(1);
                    proven.consume(1);
                    assert_eq!(proven.position(0), eager.position(0));
                    assert_eq!((proven.line, proven.column, proven.previous_cr), (8, 0, false));
                }
            }
        }
    }

'''
assert needle in s;s=s.replace(needle,test+needle,1);after[files[1]]=s
s=after[files[2]]
needle='            self.token_scratch = token;\n            self.consume(end)?;\n            if framed_end {'
new='''            self.token_scratch = token;
            if matches!(planned, tag::Planned::Complete { ascii_bare: true, .. })
                && self.source().native_utf8_byte_index().is_some()
                && !self.source().has_conversions()
            {
                self.account_source(end)?;
                self.source_mut().consume_ascii_tag(end);
            } else {
                self.consume(end)?;
            }
            if framed_end {'''
assert needle in s;s=s.replace(needle,new,1);after[files[2]]=s
# One explicit destructuring in parse_start needs to ignore the additional proof.
s=after[files[2]]
s=s.replace('tag::Planned::Complete { end: _, name_end }','tag::Planned::Complete { end: _, name_end, .. }')
after[files[2]]=s
patch='';proposed=dict(manifest)
for n in files:
 for sub,text in [('baseline',before[n]),('source',after[n])]:
  p=D/sub/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 patch+=''.join(difflib.unified_diff(before[n].splitlines(True),after[n].splitlines(True),fromfile='a/'+n,tofile='b/'+n))
 proposed[n]=H(after[n].encode())
(D/'proposal.patch').write_text(patch)
r={'status':'held_source_only_unformatted_unbuilt_untested_unselected','base':base,'measured_control_commit':'cacc0b1b3766176e9cbf71d25c5ff6867fa87c08','baseline_source_count':74,'baseline_sha256':manifest,'proposed_sha256':proposed,'changed_files':{n:{'baseline':manifest[n],'proposal':proposed[n]} for n in files},'patch_sha256':H(patch.encode()),'scope':'Eager position proof only for bare ASCII native opening tags with immediate > or />; generic/attribute/Unicode/multiline paths retain original coordinates. No C adapter change or deferred coordinate state.','tests_added':['bare_ascii_position_proof_preserves_plans_across_splits','bare_tag_semantic_error_does_not_consume_source_coordinates','proven_ascii_tag_matches_eager_coordinates_and_compaction'],'targets_executed':False,'formatter_executed':False,'repository_edits':False,'no_new_source_fields':True,'new_tag_scanner_field':'name_ascii: bool; layout and codegen impact unmeasured','new_planned_complete_field':'ascii_bare: bool; layout unmeasured','implicit_end_position_unchanged':True,'prior_reviews':['/tmp/oriole-selected-lf-coordinate-followup.md','/tmp/oriole-eager-tag-position-triage.md','/tmp/oriole-eager-tag-position-current-triage.md','/tmp/oriole-coordinate-experiments-index.md','/tmp/oriole-compact-coordinate-evidence/README.md']}
(D/'proposal.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'proposal_sha256':H((D/'proposal.json').read_bytes()),'patch_sha256':r['patch_sha256'],'changed':r['changed_files']},indent=2))
