# Eager bare-tag position proof: held ordinary experiment

The candidate composes the three-file reviewed eager-position proposal onto published
`0c407f28e2aa01178fda86a97561ed734f8d8e1d`, which publishes the unchanged selected
attribute runtime `910387239a804a038feb0a184b1bcfc0a7dd60bf`. Native control is its
normal `b8508522…` library; Expat is the existing normal 2.8.4 `7a333bc8…` library.
No rejected compact-owner source is included.

## Composition and formatting

`composition.json` binds all 74 main and four auxiliary base Git blobs. The original
proposal's exact literal transformations and occurrence counts apply to the selected
attribute source; reversing them recovers every selected byte. The original attribute
classifier and tests therefore remain intact. `source/` retains the unformatted
composition, `formatted-source/` the actual root-formatted three files.
`formatting-refreeze.json` accounts for every byte with eight explicit formatting
replacements; `expected-source.json` pins the final 74-file map. The first composition
reader's generic diff grouping disagreed around shared test braces before emitting
output. Its script and failure are retained; exact literal and inverse checks replace
that assumption. No parser, compiler or formatting action was performed by the author
of these preparation scripts.

The source change carries an ASCII-name proof only through a bare opening tag with
immediate `>` or `/>`. At the original successful commit point, native unconverted
input can update eager column coordinates without rescanning the tag. Accounting,
raw ownership, error ordering, source compaction and all fallback position handling
remain. No lazy C/Rust coordinates, allocator/default-policy change, new dependency
or speed/layout assumption. Three additional tests imply 459 passing tests in the
existing 35 groups; the actual build binder checks those counts, not a fabricated result.

## Held root sequence

Root created the worktree using `cargo +ohm worktree add`, applied the exact composed
patch and ran `cargo +ohm -Zohm-defaults=no fmt --all` in session 8616 (exit0/reaped).
The following are held until independent source/preparation review passes:

```sh
taskset -c 6 python3 -I -S /tmp/oriole-eager-bare-tag-position-preparation/bind_source.py 0c407f28e2aa01178fda86a97561ed734f8d8e1d
timeout --signal=TERM --kill-after=10s 7200s taskset -c 4 python3 -I -S /tmp/oriole-eager-bare-tag-position-preparation/build.py
taskset -c 6 python3 -I -S /tmp/oriole-eager-bare-tag-position-preparation/bind_build.py
taskset -c 6 python3 -I -S /tmp/oriole-eager-bare-tag-position-preparation/codegen/capture.py
taskset -c 6 python3 -I -S /tmp/oriole-eager-bare-tag-position-preparation/codegen/read.py
taskset -c 6 python3 -I -S /tmp/oriole-eager-bare-tag-position-preparation/prepare_native.py
```

The builder preserves the selected control's seven ordinary commands: compiler
version, workspace fmt/tests/strict Clippy, locked benchmark fmt/strict Clippy and
normal release. CPU4, jobs1, `CARGO_HOME=/home/dev-user/.cache/toucan/cargo`, stable
target `/home/dev-user/.cache/oriole/eager-bare-tag-position-target`, separate shared
build `/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}`. Both trust-all
variables, RUSTFLAGS/profile overrides and wrappers are cleared. Oriole uses generic
O3/ThinLTO/one codegen unit with Ohm experimental defaults disabled; Expat uses its
existing GCC13.3 O3/no-LTO build. PGO work remains stopped. Each child is bounded to
900 seconds, killed as a process group on interruption and reaped with raw logs.
The binder compares complete ordered compiler vectors, exact module sources,
unchanged dependency features and actual copied libraries.

Codegen inspection is artifact-only after the real release build. It resolves actual
TagScanner::scan and Source::consume_ascii_tag symbols; if absent, it captures the
relevant Parser parent instead. No old addresses or type-layout inference. See
`codegen/README.md` for its exact bounds and held CLI.

## Native measurement gate

The original native driver, run controller and complete worker/scheduling/arithmetic
logic remain. Six pinned projects, namespaces off/on at4/64KiB, four generated
conditions:28 conditions, seven seeded pairs,84 preflights,588 timed workers and
106176 samples. Root owns fresh host observations and serial preflight/elapsed
release, with pinned CPython first on PATH. Native preflightCPU5 is bounded600s,
elapsedCPU0 to1200s, each worker90s; the saved reader runsCPU6 after completion.
Every adverse condition remains. Before/during host counters and affinity do not
establish global isolation. Python and broader compatibility are later root decisions;
none of these target stages has been run by this preparer.
