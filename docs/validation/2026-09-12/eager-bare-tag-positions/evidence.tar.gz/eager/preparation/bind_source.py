"""Bind the future root-created worktree to the reviewed composition; saved-only."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys
assert __debug__ and os.sched_getaffinity(0)=={6}
P=Path(__file__).parent
W=Path('/home/dev-user/code/oss/oriole-eager-bare-tag-position')
CONTROL=Path('/tmp/oriole-attribute-lane-masks-study')
assert len(sys.argv)==2 and re.fullmatch(r'[0-9a-f]{40}',sys.argv[1])
base=sys.argv[1]
assert base=='0c407f28e2aa01178fda86a97561ed734f8d8e1d'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
assert not (P/'source-binding.json').exists()
git=lambda *args:subprocess.check_output(['git','-C',str(W),*args])
assert W.resolve()==W and git('rev-parse','--show-toplevel').decode().strip()==str(W)
assert git('config','user.email').decode().strip()=='charlie.r.marsh@gmail.com'
common=Path(git('rev-parse','--path-format=absolute','--git-common-dir').decode().strip()).resolve()
assert str(common).startswith('/home/dev-user/code/oss/')
assert git('rev-parse','HEAD').decode().strip()==base
assert subprocess.run(['git','-C',str(W),'merge-base','--is-ancestor','910387239a804a038feb0a184b1bcfc0a7dd60bf',base],check=False).returncode==0
expected=load(P/'expected-source.json');control=load(CONTROL/'source.json');old_binding=load(CONTROL/'build-binding.json')
assert sha(CONTROL/'source.json')==expected['control_source_sha256']
assert sha(CONTROL/'build-binding.json')==expected['control_binding_sha256']
assert old_binding['status']=='passed' and old_binding['candidate_libraries']['liboriole_expat.so']=='b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5'
for name,value in control['sha256'].items():
    assert hashlib.sha256(git('show',base+':'+name)).hexdigest()==value,name
names=sorted(set(git('ls-files','-z','crates','include','tests/c','Cargo.toml','Cargo.lock').decode().rstrip('\0').split('\0')))
assert set(names)==set(expected['sha256']) and len(names)==74
actual={name:sha(W/name) for name in names}
assert actual==expected['sha256'], 'Composition or formatting changed: root must explicitly review and refreeze the expected map; do not infer authorization.'
assert set(git('diff',base,'--name-only').decode().splitlines())==set(expected['changed'])=={'crates/oriole/src/tag.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole/src/lib.rs'}
assert expected['auxiliary_sha256']==old_binding['auxiliary_files']
for name,value in expected['auxiliary_sha256'].items():
    assert sha(W/name)==value and hashlib.sha256(git('show',base+':'+name)).hexdigest()==value
review=Path('/tmp/oriole-eager-bare-tag-position-independent-source-review.json')
proposal=Path('/tmp/oriole-eager-bare-tag-position-source-proposal/proposal.json')
assert sha(review)==expected['source_review_sha256']=='cf3c34f37684476e0e4cad5473b3b6b23564f18d93f499b862490498558db087'
assert sha(proposal)==expected['proposal_sha256']==load(review)['pins'][str(proposal)]
composition=load(P/'composition.json')
assert sha(P/'composition.json')==expected['composition_receipt_sha256']
assert composition['base']==base and composition['three_reviewed_operations_exact'] and composition['selected_attribute_delta_retained_exact']
assert sha(P/'composed-proposal.patch')==composition['patch_sha256']
patch=git('diff',base,'--',*sorted(expected['changed']))
source={**expected,'status':'bound_reviewed_composition','base':base,'worktree':str(W),
        'complete_patch_sha256':hashlib.sha256(patch).hexdigest()}
with (P/'candidate.patch').open('xb') as stream:stream.write(patch)
with (P/'source.json').open('x') as stream:stream.write(json.dumps(source,indent=2)+'\n')
binding={'status':'passed_saved_source_binding','targets_executed':False,'base':base,'git_common_dir':str(common),
         'source_sha256':sha(P/'source.json'),'expected_source_sha256':sha(P/'expected-source.json'),
         'patch_sha256':sha(P/'candidate.patch'),'review_sha256':sha(review),
         'scripts':{name:sha(P/name) for name in ['build.py','bind_build.py','prepare_native.py','bind_source.py','codegen/capture.py','codegen/read.py']},
         'scope':'Root-created worktree source matches the exact reviewed three-file eager bare-tag composition onto the published source-equivalent attribute docs base; no formatting, target or Git write performed.'}
with (P/'source-binding.json').open('x') as stream:stream.write(json.dumps(binding,indent=2)+'\n')
print(json.dumps({'status':binding['status'],'source_sha256':binding['source_sha256'],'binding_sha256':sha(P/'source-binding.json')}))
