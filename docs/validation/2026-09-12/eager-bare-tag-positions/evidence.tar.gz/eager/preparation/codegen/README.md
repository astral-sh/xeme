# Held eager bare-tag artifact inspection

Source preparation only. Root owns artifact-tool execution after the ordinary build and saved binding pass. No compiler, parser or artifact tool was run during this adaptation.

`capture.py` reuses the reviewed bounded readelf/nm/objdump runner and cleanup exactly. It verifies the future completed 74-file, three-runtime-file source delta and four unchanged auxiliary inputs against published base `0c407f28`. The selected control is the measured attribute runtime `91038723`, normal shared library `b8508522`; actual candidate paths/hashes come from the future build binding.

The symbol inventory looks for `TagScanner::scan`, `Source::consume_ascii_tag` and `Parser::next_event_inner`. Both named helpers are captured if present. If either helper is absent, the parser parent is also captured when available. The control is expected to lack the new helper, but absence remains an observation rather than a prerequisite. Symbol addresses and bounds come only from each actual library's nm output. The parent may contain unrelated code; no instruction is attributed to the helper merely because it occurs there.

`read.py` independently reconstructs the same selection from saved symbol output, verifies exact bounded command vectors, library/source/build hashes, stdout/stderr and reaping, and records actual function sizes and calls. Vector mnemonic matches remain descriptive evidence. Function bytes do not measure object layout, executed frequency or speed. Missing helpers are explicit, with no rebuild to manufacture a symbol.

Held root commands after build binding:

```sh
taskset -c 6 python3 -I -S /tmp/oriole-eager-bare-tag-position-preparation/codegen/capture.py
taskset -c 6 python3 -I -S /tmp/oriole-eager-bare-tag-position-preparation/codegen/read.py
```

The parent source binder must include both script hashes under `scripts`, as in the preceding six-script recipe. Direct predecessor diffs accompany the scripts. No PGO, target-CPU flags, new dependencies or predicted code size are introduced.
