from pathlib import Path
import ast,difflib,hashlib,json,subprocess
P=Path('/tmp/oriole-eager-bare-tag-position-preparation');Q=Path('/tmp/oriole-eager-bare-tag-position-source-proposal');C=Path('/tmp/oriole-attribute-lane-masks-study');W=Path('/home/dev-user/code/oss/oriole-attribute-lane-masks')
P.mkdir(exist_ok=True)
H=lambda b:hashlib.sha256(b).hexdigest();sha=lambda p:H(Path(p).read_bytes());read=lambda p:json.loads(Path(p).read_text())
base='0c407f28e2aa01178fda86a97561ed734f8d8e1d';commit='910387239a804a038feb0a184b1bcfc0a7dd60bf'
proposal=read(Q/'proposal.json');review=Path('/tmp/oriole-eager-bare-tag-position-independent-source-review.json')
assert sha(review)=='cf3c34f37684476e0e4cad5473b3b6b23564f18d93f499b862490498558db087'
assert sha(Q/'proposal.json')=='1357124d71c77ae952fca121b258d8d1aafee88cf86ffa082a061514ea7c2db4'
control=read(C/'source.json');binding=read(C/'build-binding.json');assert len(control['sha256'])==74 and binding['tests']['passed']==456
blobs={n:subprocess.check_output(['git','-C',str(W),'show',base+':'+n]) for n in control['sha256']}
assert {n:H(b) for n,b in blobs.items()}==control['sha256']
for n,h in binding['auxiliary_files'].items():assert H(subprocess.check_output(['git','-C',str(W),'show',base+':'+n]))==h
files=['crates/oriole/src/tag.rs','crates/oriole/src/encoding.rs','crates/oriole/src/lib.rs']
# Reuse only the existing pure string-transformation body. No original setup,
# Git reads, writes, formatter or target work is executed from the proposal author.
s=(Q/'prepare.py').read_text();start=s.index('s=after[files[0]]');stop=s.index("patch='';proposed=")
transform=s[start:stop];ast.parse(transform)
def apply(inputs):
 ns={'files':files,'after':dict(inputs)};exec(compile(transform,'<reviewed source transformations>','exec'),ns);return ns['after']
original={n:(Q/'baseline'/n).read_text() for n in files};proposed=apply(original)
assert all(proposed[n]==(Q/'source'/n).read_text() for n in files)
selected={n:blobs[n].decode() for n in files};composed=apply(selected)
# Changed byte hunks must be the same reviewed operations on the selected source.
def operations(a,b):
 aa=a.splitlines(True);bb=b.splitlines(True)
 return [(''.join(aa[i:j]),''.join(bb[k:l])) for op,i,j,k,l in difflib.SequenceMatcher(None,aa,bb,autojunk=False).get_opcodes() if op!='equal']
for n in files:assert operations(original[n],proposed[n])==operations(selected[n],composed[n]),n
assert selected[files[1]]==original[files[1]] and selected[files[2]]==original[files[2]]
# Full selected attribute-only addition is still present byte-for-byte.
assert operations(original[files[0]],selected[files[0]])==operations(proposed[files[0]],composed[files[0]])
patch='';mapping=dict(control['sha256'])
for n in files:
 for d,data in [('baseline',selected[n]),('source',composed[n])]:
  f=P/d/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(data)
 mapping[n]=H(composed[n].encode());patch+=''.join(difflib.unified_diff(selected[n].splitlines(True),composed[n].splitlines(True),fromfile='a/'+n,tofile='b/'+n))
(P/'composed-proposal.patch').write_text(patch)
assert sum(composed[n].count('#[test]')-selected[n].count('#[test]') for n in files)==3
expected={'status':'held_unformatted_composition','source_count':74,'sha256':mapping,'changed':files,'auxiliary_sha256':binding['auxiliary_files'],'control_source_sha256':sha(C/'source.json'),'control_binding_sha256':sha(C/'build-binding.json'),'source_review_sha256':sha(review),'proposal_sha256':sha(Q/'proposal.json'),'expected_tests':{'passed':459,'groups':35,'failures':0,'ignored':0},'base':base,'measured_control_commit':commit,'composition_patch_sha256':sha(P/'composed-proposal.patch')}
(P/'expected-source.json').write_text(json.dumps(expected,indent=2)+'\n')
receipt={'status':'passed_saved_source_composition_unformatted','targets_executed':False,'formatter_executed':False,'worktree_edits':False,'base':base,'measured_control_commit':commit,'source_count':74,'auxiliary_count':4,'three_reviewed_operations_exact':True,'selected_attribute_delta_retained_exact':True,'all_base_source_blobs_match_selected_control':True,'extra_test_functions':3,'expected_test_count':459,'expected_groups':35,'expected_source_sha256':sha(P/'expected-source.json'),'patch_sha256':sha(P/'composed-proposal.patch'),'inputs':{str(p):sha(p) for p in [Q/'proposal.json',Q/'proposal.patch',Q/'prepare.py',review,C/'source.json',C/'build.json',C/'build-binding.json']},'source':{n:sha(P/'source'/n) for n in files},'formatting_pending_root':True}
(P/'composition.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'composition_sha256':sha(P/'composition.json'),'patch_sha256':sha(P/'composed-proposal.patch'),'expected_source_sha256':sha(P/'expected-source.json'),'source':receipt['source']},indent=2))
