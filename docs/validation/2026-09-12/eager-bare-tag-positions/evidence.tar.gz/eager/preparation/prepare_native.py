"""Prepare a matched normal native comparison from existing artifacts only."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path

assert __debug__ and os.sched_getaffinity(0) == {6}
origin = Path('/tmp/oriole-attribute-lane-masks-study/native')
PREP = Path(__file__).parent
out = Path('/tmp/oriole-eager-bare-tag-position-study/native')
control = origin.parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
binding = load(out.parent / 'build-binding.json')
source = load(out.parent / 'source.json')
assert binding['status'] == 'passed' and binding['source_count'] == 74
source_binding = load(PREP / 'source-binding.json')
assert source_binding['status'] == 'passed_saved_source_binding' and source['base'] == source_binding['base']
assert sha(__file__) == source_binding['scripts']['prepare_native.py']
assert binding['source_manifest_sha256'] == sha(out.parent / 'source.json')
assert binding['control_source_manifest_sha256'] == sha(control / 'source.json')
assert binding['build_sha256'] == sha(out.parent / 'build.json')
assert all(sha(Path(source['worktree']) / p) == h for p, h in source['sha256'].items())
assert source['sha256']['crates/oriole/src/lib.rs'] == load(PREP / 'source.json')['sha256']['crates/oriole/src/lib.rs']
build = load(out.parent / 'build.json')
old_source = load(control / 'source.json')
old_build = load(control / 'build.json')
prepared_source = PREP / 'source.json'
assert sha(prepared_source) == source_binding['source_sha256']
assert source['sha256'] == load(prepared_source)['sha256']
assert set(source['sha256']) == set(old_source['sha256']) and len(source['sha256']) == 74
assert build['status'] == old_build['status'] == 'passed' and build['source_unchanged'] and old_build['source_unchanged']
assert binding['control_build_sha256'] == sha(control / 'build.json')
assert binding['prepared_source_sha256'] == sha(prepared_source)
assert set(binding['source_delta']) == {'crates/oriole/src/tag.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole/src/lib.rs'}
assert binding['candidate_libraries'] == build['libraries'] and binding['control_libraries'] == old_build['libraries']
assert binding['control_libraries']['liboriole_expat.so'] == 'b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5'
for directory, libraries in [(out.parent, binding['candidate_libraries']), (control, binding['control_libraries'])]:
    assert all(sha(directory / 'normal' / name) == digest for name, digest in libraries.items())
assert all(sha(path) == digest for path, digest in binding['tool_hashes'].items())
dependency_origin = Path('/tmp/oriole-text-lane-masks-preparation')
dependency_review_path = dependency_origin / 'metadata-independent-review.json'
metadata_receipt_path = dependency_origin / 'format-metadata.json'
old_binding = load(control / 'build-binding.json')
assert sha(dependency_review_path) == binding['dependency_review_sha256'] == old_binding['dependency_review_sha256'] == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
assert load(dependency_review_path)['source_manifest_sha256'] == sha(dependency_origin / 'source.json')
assert sha(metadata_receipt_path) == binding['metadata_receipt_sha256'] == build['metadata_receipt_sha256'] == old_binding['metadata_receipt_sha256']
assert binding['auxiliary_files'] == build['auxiliary_files'] == load(prepared_source)['auxiliary_sha256'] == old_binding['auxiliary_files'] and build['auxiliary_unchanged']
assert all(sha(Path(source['worktree']) / name) == h for name,h in binding['auxiliary_files'].items())
assert sha(PREP / 'candidate.patch') == binding['complete_patch_sha256'] == load(prepared_source)['complete_patch_sha256']
assert len(binding['dependency_compiler_vectors']) == len(build['dependency_compiler_vectors']) == 3
for name,digest in source_binding['scripts'].items():assert sha(PREP / name) == digest
assert not out.exists()
out.mkdir()


def adapt(name, changes):
    before = (origin / name).read_text()
    after = before
    for old, new in changes:
        assert old in after, (name, old)
        after = after.replace(old, new)
    ast.parse(after)
    (out / name).write_text(after)
    (out / (name + '.patch')).write_text(''.join(difflib.unified_diff(
        before.splitlines(True), after.splitlines(True),
        fromfile=str(origin / name), tofile=str(out / name))))
    return before, after


changes = [
    ('/tmp/oriole-attribute-lane-masks-study', '/tmp/oriole-eager-bare-tag-position-study'),
    ('/tmp/oriole-text-lane-masks-study', '/tmp/oriole-attribute-lane-masks-study'),
    ('quoted-attribute first-stop lane masks', 'eager bare-tag positions'),
    ('selected LF lane-mask baseline', 'selected quoted-attribute baseline'),
]
before, after = adapt('native_screen.py', changes)
marker = 'def run(condition, engine, pair, cpu, count):'
assert before[before.index(marker):] == after[after.index(marker):]
restored = after
for old, new in reversed(changes):
    restored = restored.replace(new, old)
assert restored == before
(out / 'run.py').write_bytes((origin / 'run.py').read_bytes())
prior = load(origin / 'adaptation.json')
libraries = {
    'candidate': {'path': str(out.parent / 'normal/liboriole_expat.so'),
                  'sha256': binding['candidate_libraries']['liboriole_expat.so']},
    'control': prior['libraries']['candidate'],
    'expat': prior['libraries']['expat'],
}
assert libraries['control']['sha256'] == binding['control_libraries']['liboriole_expat.so']
assert all(sha(v['path']) == v['sha256'] for v in libraries.values())
adaptation = {k: prior[k] for k in ('mode', 'external_input_hashes', 'conditions', 'pairs', 'seed', 'counts')}
assert all(sha(p) == h for p, h in adaptation['external_input_hashes'].items())
adaptation.update(
    status='passed', execution_status='unexecuted', origin=str(origin),
    parent_files={n: sha(origin / n) for n in ('run.py', 'native_screen.py')},
    files={n: sha(out / n) for n in ('run.py', 'native_screen.py')},
    changes={'run.py': [], 'native_screen.py': changes},
    inverse_text_and_ast_equal=True, libraries=libraries,
    selected_normal_protocol={'path': str(origin / 'native-screen/protocol.json'),
                              'sha256': sha(origin / 'native-screen/protocol.json')},
    source_delta=binding['source_delta'], candidate_source=source['worktree'],
    candidate_source_record={'path': str(out.parent / 'source.json'), 'sha256': sha(out.parent / 'source.json')},
    candidate_build_record={'path': str(out.parent / 'build.json'), 'sha256': sha(out.parent / 'build.json')},
    binding_review=str(out.parent / 'build-binding.json'),
    scope='Eager bare-tag positions versus selected quoted-attribute masks and normal Expat. All28 conditions and original timing/workers/callbacks/bounds unchanged. Same normal generic compiler recipe and unchanged reviewed dependencies. No targets run during preparation.')
(out / 'adaptation.json').write_text(json.dumps(adaptation, indent=2) + '\n')

reader_changes = [
    ('/tmp/oriole-attribute-lane-masks-study', '/tmp/oriole-eager-bare-tag-position-study'),
    ('4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d', '@CONTROL_SHA@'),
    ('b8508522639421c3c422cb65f121862f39016d794b54321aaabedf4df65d89a5', libraries['candidate']['sha256']),
    ('@CONTROL_SHA@', libraries['control']['sha256']),
    ('aed07bbacf75136330dd777a190ac2a42a2f1ed0', source['base']),
    ('21460dc06ca91a3471ea04f9566dd34a16d21a4bab565c37ecc5b5584169ce17', source['sha256']['crates/oriole/src/lib.rs']),
    ("binding['source_count'] == 74 and set(binding['source_delta']) == {'crates/oriole/src/tag.rs'}",
     "binding['source_count'] == 74 and set(binding['source_delta']) == {'crates/oriole/src/tag.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole/src/lib.rs'}"),
    ('Reuse the completed LF lane-mask normal reader with source, library and output bindings for the quoted-attribute first-stop lane masks. Full raw reconstruction unchanged. Protocol preparer adapted this reader; root owns execution and independent review.',
     'Reuse the completed selected attribute normal reader with source, library and output bindings for eager bare-tag positions. Full raw reconstruction unchanged. Protocol preparer adapted this reader; root owns execution and independent review.'),
    ('Only this quoted-attribute first-stop lane masks normal native campaign is reconstructed here. Python preparation and timing are conditional on a native gain and are outside this evidence.',
     'Only this eager bare-tag position normal native campaign is reconstructed here. Python preparation and timing are conditional on a native gain and are outside this evidence.'),
]
adapt('read_results.py', reader_changes)
(out / 'README.md').write_text("""# Eager bare-tag positions: held normal native protocol

Candidate composes the reviewed three-file eager position proof onto selected attribute masks. Control is measured attribute normal b850; Expat is the original normal7a333 library. All sources, unchanged dependencies, compiler flags and actual library outputs are bound before materialization. No lazy position policy or predicted benefit.

All24 real and four generated conditions retain seven seeded pairs,84 fresh preflight workers,588 timed workers and106176 samples. Workers include parser construction, handlers, feeds, callbacks and destruction; digests merge text fragments. Every adverse row remains. No compiler, profile or CPU-target setting changes.

Root alone releases execution after completed builds, binding, actual codegen inspection and host observations. Run run.py with the pinned CPython directory first on PATH: CPU5 preflights600s, then CPU0 elapsed1200s, workers90s. Saved reader CPU6 afterward. Affinity does not establish global host isolation. Python remains a later root decision; no target ran during preparation.
""")

pins = {str(p): sha(p) for p in out.iterdir() if p.is_file()}
for p in [Path(__file__), out.parent / 'source.json', out.parent / 'build.json',
          out.parent / 'build-binding.json', control / 'source.json', control / 'build.json',
          prepared_source, dependency_review_path, metadata_receipt_path, PREP / 'candidate.patch', PREP / 'source-binding.json', PREP / 'build.py', PREP / 'bind_build.py', origin / 'adaptation.json', origin / 'native_screen.py', origin / 'run.py', origin / 'read_results.py']:
    pins[str(p)] = sha(p)
preparation = {'status': 'prepared_no_targets', 'targets_executed': False, 'pins': pins,
               'source_delta': binding['source_delta'], 'counts': adaptation['counts'],
               'run_unchanged': True, 'native_worker_and_all_measurement_code_unchanged': True,
               'reader_changes': reader_changes, 'dependency_review_sha256': binding['dependency_review_sha256'], 'metadata_receipt_sha256': binding['metadata_receipt_sha256'], 'auxiliary_files': binding['auxiliary_files'], 'dependency_compiler_vectors': binding['dependency_compiler_vectors']}
(out / 'preparation.json').write_text(json.dumps(preparation, indent=2) + '\n')
print(json.dumps({'status': preparation['status'], 'path': str(out),
                  'preparation_sha256': sha(out / 'preparation.json'), 'libraries': libraries}))
