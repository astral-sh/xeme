# Held eager bare-tag normal CPython sources

This directory contains source preparation only. Root's ordinary build is separate;
its candidate library hashes and new runtime commit are deliberately unresolved here.
`held/` contains the exact scripts to copy into the future study, reviewed before any
consumer compilation. No script under `held/` has been executed.

After native results justify continuation and root commits the measured bytes:

```sh
taskset -c 6 python3 -I -S /tmp/oriole-eager-bare-tag-position-python-preparation/materialize.py --released RUNTIME_COMMIT
taskset -c 6 python3 -I -S /tmp/oriole-eager-bare-tag-position-study/python/prepare.py
taskset -c 6 python3 -I -S /tmp/oriole-eager-bare-tag-position-study/python/bind.py
```

The materializer checks the completed ordinary build and native gain, committed/live
74-file source map and four unchanged auxiliary files. It copies the reviewed helper
bytes and writes actual build/library/commit provenance. No compiler or parser runs.
`prepare.py` validates the four reused modules and source/actual compiler receipts;
`bind.py` freezes the candidate/control/Expat protocol before actual targets.

Original `run.py`, `python_worker.py` and `build_consumers.py` are byte-identical to
the completed attribute Python study. The screen differs only in captions; both saved
readers differ only in study path. The actual unchanged attribute candidate modules
(SOb850) become control; original Expat7a333 modules remain. Two fresh modules use
unmodified CPython3.12.13 with the identical O2 commands. Current normal build flags,
dependencies and allocator policy are unchanged; there is no PGO work.

The same24conditions,7pairedcohorts,72preflights,504timedworkers and26364samples remain.
Root-owned commands retain the original600s build/preflight,1200s elapsed and300s
per-worker bounds, complete callback/tree checks, module/parser origins, GC, destructor timing,
paired process medians and process-group kill/reap behavior. `held/held-commands.json`
contains exact commands with the pinned CPython3.12.13 interpreter. Saved readers run
only after root reaps targets. Every adverse row and separate host observation stays.
CPU affinity does not establish global host isolation. This preparation is conditional;
no Python performance or correctness result is claimed.
