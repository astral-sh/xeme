# Hold the opening-name ASCII proof in a local variable

Source-only follow-up to measured runtime `19251bc01dba14cc57507facd2d607a9075471b5`. The proposal changes only the existing native opening-name walk in `tag.rs`. The current worktree, binaries and measurements remain unchanged.

`candidate-tag.stdout` currently shows `cmp`/`setb`/`and` followed by a byte store to scanner offset `0x58` at `0x741b5`–`0x741c1` after each accepted continuation character. The branch at `0x741cd` returns to the walk, so the current compiler did not sink this field store out of the loop. This also runs for opening names on tags that later have attributes or whitespace and do not qualify for the position shortcut.

The patch initializes a local Boolean from the existing field after first-character handling, accumulates the same proof in the existing closure, then writes the field once before the incomplete return or later tag handling. First-character assignment stays at its original location. A resumed scan starts from the saved proof; an empty continuation writes the same value; the first rejected name character does not update it. Name validation, offset calculation, incomplete/reset/disabled behavior and bare-tag eligibility are unchanged. No callback, allocation or fallible semantic work occurs inside this name walk.

The closure now captures the local Boolean instead of a parser field. This makes the intended single field commit explicit. Whether the compiler eliminates the per-character store or substitutes a stack spill is unmeasured and requires actual future code generation. It also retains the per-character ASCII comparison; no speed claim is made.

The existing focused scanner split/resume/idempotence/Unicode and prior-CR/position tests are retained byte-for-byte. This proposal adds no duplicate test or new harness. Formatting, compilation, tests and benchmarks have not run for it. Parent owns any later application and execution after the current measurement decision.

Files: `original/tag.rs` preserves the current file; `source/tag.rs` is the complete proposed file; `proposal.patch` applies to the recorded runtime; `proposal.json` binds all 74 current/proposed inputs and four unchanged auxiliary files.
