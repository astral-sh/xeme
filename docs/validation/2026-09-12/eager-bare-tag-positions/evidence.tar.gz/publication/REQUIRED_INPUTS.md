# Held eager-position evidence inventory

Root alone runs `assemble.py --released` on CPU6 after completing and reviewing all four epochs. This preparation never assembles an archive or executes a parser/compiler. `required-inputs.json` names current trees and immutable explicit pins; absent final results are required at release, not replaced by expected outcomes.

## Included evidence

- Initial native and CPython runs, and separate confirmation native and CPython runs: all104 conditions,2,496 workers and265,080 samples; every adverse median paired ratio is retained. No epochs are pooled.
- Original XML inputs, exact worker/driver/controller sources and limits, callback checks, loaded module/library identities, raw process outputs and host observations. Shared-host affinity and monitored idle samples do not prove global isolation.
- Candidate19251bc and attribute-control910387 source maps:74 main files and four unchanged auxiliary files each. Only core `tag.rs`, `lib.rs` and `encoding.rs` differ. Exact normal build/compiler vectors,459 checks, seven build commands and saved codegen remain included. No new PGO/CPU/allocator settings.
- Full current original4,740-row API/C and strict/semantic records with independent saved readbacks. Original assertions, retry ceilings, memory/time bounds and raw nonzero outcomes remain intact.
- Unchanged wide/safe_arch/bytemuck archives and156 original source/license files; no registry tree or dependency change is implied.
- Original proposal, deliberate composition with the selected attribute scanner, formatter-only changes and source/reader preparation attempts are retained with their original scopes.
- The local-proof follow-up lives only under `future-unbuilt/`; it has no compiler, parser or benchmark evidence and is not candidate19251bc.

## Exclusions and release

Executables, libraries and compiler profiles are represented by audited hashes and sizes. Historical worker records and old publication archives are excluded with identities when referenced by current provenance; the rejected compact-owner campaign is not included. Existing helper logic reads every archived member and its original bytes back.

Required `final-publication.json` fields follow the preceding packet: status `root_released_completed_results`, publication_path, runtime_commit19251bc01dba14cc57507facd2d607a9075471b5, base_commit0c407f28e2aa01178fda86a97561ed734f8d8e1d, decision, epochs_pooled:false, controllers_reaped:true, global_host_isolation_claimed:false, completed_reviews and additional_files. Each additional file must have an explicit unique member label and SHA-256. Required review roles: eager-initial-native, eager-initial-python, eager-confirmation-native, eager-confirmation-python, eager-correctness and source-commit-binding. The existing build/codegen review supplies source-commit-binding; no new historical replay framework is needed.

Final README table/derivation, root decision, final draft pins, source peer receipts and final reader source/review are added through that release record. Its final execution receipt remains outside the archive it verifies. Do not create a self-referential report hash.
