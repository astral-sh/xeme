We retain an ASCII proof while scanning bare opening tags, then use it to update eager positions without rescanning the tag. This stacks on PR159 at `0c407f28e2aa01178fda86a97561ed734f8d8e1d` and preserves the selected attribute SIMD scanner, fallback behavior, accounting order and input compaction.

[PENDING: We report separate confirmation native and CPython aggregate changes, Expat ratios and regressions after root selection; link the full eager-position report with both initial and confirmation epochs.]

[PENDING: We summarize completed current compatibility gates and remaining production-readiness limits, preserving original API/strict failures and distinguishing passing supplemental semantics.]
