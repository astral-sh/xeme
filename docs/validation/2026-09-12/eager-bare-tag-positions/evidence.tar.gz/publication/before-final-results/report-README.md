# Eager positions for bare ASCII opening tags

[PENDING: Root final selection and separate confirmation native/Python results; this is a held source draft.]

## Source and behavior

The candidate is runtime `19251bc01dba14cc57507facd2d607a9075471b5`, based on PR159's `0c407f28e2aa01178fda86a97561ed734f8d8e1d`, which publishes unchanged attribute-scanner control `910387239a804a038feb0a184b1bcfc0a7dd60bf`. Only `tag.rs`, `encoding.rs` and core `lib.rs` change among74 main files; four auxiliary files and dependencies are unchanged.

The existing native opening-name walk records whether every accepted name byte is ASCII. An immediate `>` or `/>` proves a nonempty tag has no newline. After the original semantic parsing, raw publication and accounting check, native unconverted input can advance its eager column without rescanning that tag. Existing cursor/retirement/compaction work remains. Unicode, whitespace, attributes and fallback paths keep their original coordinate scan; Rust and C positions remain eager.

The source also does proof bookkeeping on names that later do not qualify. Saved actual codegen establishes a character-loop-free native `consume_ascii_tag` helper and per-character scanner-field stores in this candidate, but no frequency or elapsed attribution. Function byte size is machine-code size, not object layout or an instruction count. The retained local-proof variant is unbuilt future work and is absent from the measured source.

## Measurements and limitations

[PENDING: Fill all four separate epoch aggregates, counts, host observations, within1.10 counts and every adverse row from completed primary/independent reports. Do not pool epochs or add compact-owner as a campaign.]

Normal native runs retain28 conditions and seven matched pairs; normal CPython retains24 conditions and seven matched pairs. Each epoch includes fresh preflights and the original measurement boundaries. The two native epochs contain672 workers/106,176 samples each; the two Python epochs576/26,364 each. Original XML, raw outputs and all callback/module identity checks remain available. The host is shared; CPU0 affinity plus this task's lack of concurrent targets does not establish global isolation or statistical significance.

Oriole uses generic normal O3/ThinLTO/one codegen unit with local Ohm rustc1.98.1-dev and experimental defaults disabled. Expat2.8.4 uses GCC13.3 O3 withoutLTO. CPython3.12.13 benchmark extension sources are unmodified and compiled atO2. No new PGO, CPU-target, allocator or dependency configuration is measured.

## Compatibility and reviews

Current normal-source gates pass459 Rust checks in35 groups, strict workspace and locked benchmark Clippy, and formatting. The original API matrix remains4,347 passes,391 assertion failures and two timeouts over4,740 ordered configurations; no original assertion, retry ceiling or bound changed. Six shared/static C integration/adversarial/allocation consumers pass with C-only ASan/UBSan, uninstrumented Rust release libraries and leak detection disabled.

Shared and static strict CPython retain802 method outcomes and809 rendered lines per linkage, including the same two callback-grouping failures and raw exit2. Their explicit pinned pyexpat cleanup backport differs from unmodified benchmark consumers. Two separate supplemental semantic tests per linkage pass; they do not reclassify the strict failures. Current-source sustained fuzz and PBS distribution validation are outstanding.

The source author prepared the source/protocols and this packet. Separate peers reviewed the runtime/composition and controller/readers; root executed target campaigns and saved readers. Independence of saved reconstruction from target execution is distinguished from runtime authorship. Metadata/source preparation corrections retain their first attempts and do not imply target failures or reruns.

[PENDING: Bind root decision, final completed review identities and exact preparation-attempt scope; final packet readback must complete before publication.]
