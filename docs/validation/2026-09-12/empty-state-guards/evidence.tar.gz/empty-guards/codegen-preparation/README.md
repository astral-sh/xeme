# Held empty-state guard static capture

These scripts inspect the future completed normal empty-state build against the selected eager c702 control. No compiler, parser, benchmark, runtime profiler or library is run. Actual candidate identity is taken only from a successful `/tmp/oriole-empty-state-guards-study/build-binding.json`; candidate/source/build, control/source/build, all74 source files, four auxiliary files, release-log command and both SO/A hashes are checked. The separate prepared.json pins these two scripts and existing reviewed inputs without modifying the four-script build preparation.

Run the two exact argv vectors in [commands.json](commands.json) sequentially after root releases the complete build/binding. Capture refuses an existing codegen directory. It uses the prior capture's byte-exact timeout/process-group kill/reap body, SIGTERM-to-KeyboardInterrupt handling, CPU6, and disabled debuginfod. Every external command is readelf, nm or objdump, inside a45-second timeout and a51-second parent wait; the whole capture has at most16 commands. Root should use a900-second outer bound, sending TERM first to allow cleanup. The saved reader uses no subprocesses.

## Bounded actual symbols

Resolve names from each actual `nm -S -C --defined-only` output, including its ordinary angle-bracket spelling. Capture `next_event_inner` only from its actual entry through at most4096 bytes. Capture each present `account_source`, `account_source_bytes`, `run_events`, `run_events_with_frame`, and `drain_default_fragments` through its actual symbol size, capped at24576 bytes. Missing or truncated symbols stay explicit. The inner symbol and at least one C loop parent are required; no absent helper is manufactured with a rebuild. Current/control addresses are never copied into candidate commands. Maximum retained instruction-address span across both engines is253952 bytes. ELF notes/build IDs and full defined-symbol listings remain saved.

## Mechanisms to review after capture

- **Option guard:** follow the candidate inner entry's None branch. Does it bypass the owned parameter payload move? Compare the current c702 unconditional88-byte copy; check Some still takes the value and executes its existing body.
- **Empty default queue:** in `run_events_with_frame`, or its `run_events` parent when inlined, follow the queue-length comparison. Does empty bypass `drain_default_fragments` while nonempty still drains before status/next-event processing?
- **Zero source charge:** follow zero `accounting_bytes` at the inner entry and any surviving wrapper. Does it bypass `account_source_bytes` and accounted-cursor writeback? Check the nonzero path still calls/contains the fallible accounting body. A missing wrapper symbol alone does not establish that result.

The saved reader re-resolves names, validates every exact unique command label/vector, status/reap/output hash, build/source/library provenance and bounds. It extracts branch, return, memory-move and call lines for direct comparison, then explicitly marks these semantic assessments pending source/assembly review. No brittle opcode/address pattern is asserted to turn a compiler result into a pass. With raw bytes hidden, address-line counts have no objdump byte wraps; symbol sizes describe machine code, never object layout. No elapsed gain, allocation reduction or instruction-frequency claim follows from this static capture.

## Preparation record

`prior-capture.py` and `prior-read.py` retain the prior reviewed eager scripts; their direct patches are adjacent. AST parsing and exact cleanup-body comparison passed in memory. Neither held script has executed. PGO, target-cpu, toolchain changes and debug companion builds are outside this protocol.
