"""Read only saved release symbol and instruction records; no subprocesses."""
from pathlib import Path
import hashlib,json,os,re
assert __debug__ and os.sched_getaffinity(0)=={6}
PREP=Path(__file__).parent.parent;S=Path('/tmp/oriole-eager-bare-tag-position-study');D=S/'codegen'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
capture=J(D/'capture.json');binding=J(S/'build-binding.json');prepared=J(PREP/'source-binding.json')
assert capture['status']=='captured_current_release_bare_tag_disassembly' and capture['targets_executed'] is False
assert H(__file__)==prepared['scripts']['codegen/read.py']
assert capture['reader_sha256']==H(PREP/'codegen/capture.py')==prepared['scripts']['codegen/capture.py']
assert binding['status']=='passed' and binding['source_count']==74 and set(binding['source_delta'])=={'crates/oriole/src/tag.rs','crates/oriole/src/encoding.rs','crates/oriole/src/lib.rs'}
assert set(capture['engines'])=={'control','candidate'}
for p,h in capture['pins'].items():assert H(p)==h,p
expected={};summaries={};prefix=['/usr/bin/timeout','--signal=TERM','--kill-after=5s','45s','/usr/bin/taskset','-c','6']
for engine,e in capture['engines'].items():
 so=Path(e['library']);study=Path(e['study']);s=J(study/'source.json');b=J(study/'build.json')
 assert so==study/'normal/liboriole_expat.so' and so.read_bytes()[:4]==b'\x7fELF'
 assert H(so)==e['library_sha256']==binding[engine+'_libraries']['liboriole_expat.so']==b['libraries'][so.name]
 assert e['source_manifest_sha256']==H(study/'source.json') and e['worktree']==s['worktree']
 assert len(s['sha256'])==74 and all(H(Path(s['worktree'])/n)==h for n,h in s['sha256'].items())
 assert e['build_id']==re.search(r'Build ID: ([0-9a-f]+)',(D/(engine+'-elf.stdout')).read_text())[1]
 expected[engine+'-elf']=prefix+['/usr/bin/readelf','--wide','--file-header','--notes',str(so)]
 expected[engine+'-symbols']=prefix+['/usr/bin/nm','-S','-C','--defined-only',str(so)]
 wanted={'tag':'oriole::tag::TagScanner::scan','consume_ascii_tag':'oriole::encoding::Source::consume_ascii_tag','parent':'oriole::Parser::next_event_inner'};found={}
 for line in (D/(engine+'-symbols.stdout')).read_text().splitlines():
  m=re.fullmatch(r'([0-9a-f]+) ([0-9a-f]+) [tT] (.+)',line)
  if m:
   canonical=m[3].replace('<','').replace('>','')
   for key,name in wanted.items():
    if canonical==name:
     assert key not in found
     found[key]={'symbol':m[3],'address':int(m[1],16),'bytes':int(m[2],16)}
 assert found==e['available_symbols']
 selected=[key for key in ['tag','consume_ascii_tag'] if key in found]
 if any(key not in found for key in ['tag','consume_ascii_tag']) and 'parent' in found:selected.append('parent')
 assert selected==e['captured'] and e['missing_symbols']==[key for key in wanted if key not in found]
 summaries[engine]={}
 for key in selected:
  x=found[key];label=engine+'-'+key
  expected[label]=prefix+['/usr/bin/objdump','-d','-C','--start-address='+str(x['address']),'--stop-address='+str(x['address']+x['bytes']),str(so)]
  text=(D/(label+'.stdout')).read_text();lines=[line for line in text.splitlines() if re.match(r'^\s*[0-9a-f]+:',line)]
  assert lines and all(x['address']<=int(line.split(':',1)[0].strip(),16)<x['address']+x['bytes'] for line in lines)
  vector=[line for line in lines if re.search(r'\b(?:v?pcmpgtb|v?pcmpeqb|v?pmovmskb|v?movdqu|v?pminub|v?pmaxub)\b',line)]
  calls=[line for line in lines if re.search(r'\bcall[q]?\b',line)]
  summaries[engine][key]={**x,'address_lines_including_byte_wraps':len(lines),'selected_vector_mnemonic_lines':vector,'call_lines':calls,'raw_sha256':H(D/(label+'.stdout'))}
assert len(expected)==len(capture['commands'])
assert {row['label'] for row in capture['commands']}==set(expected)
for row in capture['commands']:
 assert row['argv']==expected[row['label']] and row['exit']==0 and row['reaped'] and row['end']>=row['start']
 for stream in ['stdout','stderr']:assert H(D/(row['label']+'.'+stream))==row[stream+'_sha256']
r={'status':'verified_saved_current_bare_tag_codegen','targets_executed':False,'engines':capture['engines'],'symbols':summaries,'command_count':len(expected),'capture_sha256':H(D/'capture.json'),'reader_sha256':H(__file__),'pins':capture['pins'],'limitations':['Static symbol and mnemonic evidence only. No profile, executed-path frequency, cycle count, throughput or allocation saving follows.','Instructions in an inline parser parent are not automatically attributed to consume_ascii_tag. Full exact function bytes are retained for source/control comparison; symbol size is machine-code size, not object layout.','Missing standalone helpers may be inlined or optimized away; no debug/release rebuild is performed to manufacture a symbol.','Address-line count includes objdump byte wraps; it is not an instruction count. No required SIMD opcode, predicted code size or absence-of-calls assertion.']}
with (D/'report.json').open('x') as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'report_sha256':H(D/'report.json'),'symbols':{e:list(v) for e,v in summaries.items()}},indent=2))
