"""Read only saved release symbol and instruction records; no subprocesses."""
from pathlib import Path
import hashlib,json,os,re
assert __debug__ and os.sched_getaffinity(0)=={6}
PREP=Path(__file__).parent;S=Path('/tmp/oriole-empty-state-guards-study');D=S/'codegen'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
capture=J(D/'capture.json');binding=J(S/'build-binding.json');prepared=J(PREP/'prepared.json')
assert capture['status']=='captured_current_release_empty_state_disassembly' and capture['targets_executed'] is False
assert H(__file__)==prepared['scripts']['read.py']
assert capture['reader_sha256']==H(PREP/'capture.py')==prepared['scripts']['capture.py']
assert binding['status']=='passed' and binding['source_count']==74 and set(binding['source_delta'])=={'crates/oriole/src/lib.rs','crates/oriole_expat/src/lib.rs'}
assert set(capture['engines'])=={'control','candidate'}
assert capture['pins'][str(PREP/'prepared.json')]==H(PREP/'prepared.json')
for p,h in prepared['input_pins'].items():assert capture['pins'][p]==H(p)==h,p
for p,h in capture['pins'].items():assert H(p)==h,p
expected={};summaries={};prefix=['/usr/bin/timeout','--signal=TERM','--kill-after=5s','45s','/usr/bin/taskset','-c','6']
for engine,e in capture['engines'].items():
 so=Path(e['library']);study=Path(e['study']);s=J(study/'source.json');b=J(study/'build.json')
 assert so==study/'normal/liboriole_expat.so' and so.read_bytes()[:4]==b'\x7fELF'
 assert H(so)==e['library_sha256']==binding[engine+'_libraries']['liboriole_expat.so']==b['libraries'][so.name]
 prefix_key='' if engine=='candidate' else 'control_'
 assert e['source_manifest_sha256']==H(study/'source.json')==binding[prefix_key+'source_manifest_sha256'] and e['worktree']==s['worktree']
 assert H(study/'build.json')==binding[prefix_key+'build_sha256']
 assert len(s['sha256'])==74 and all(H(Path(s['worktree'])/n)==h for n,h in s['sha256'].items())
 assert e['build_id']==re.search(r'Build ID: ([0-9a-f]+)',(D/(engine+'-elf.stdout')).read_text())[1]
 expected[engine+'-elf']=prefix+['/usr/bin/readelf','--wide','--file-header','--notes',str(so)]
 expected[engine+'-symbols']=prefix+['/usr/bin/nm','-S','-C','--defined-only',str(so)]
 wanted=prepared['wanted_symbols'];found={}
 for line in (D/(engine+'-symbols.stdout')).read_text().splitlines():
  m=re.fullmatch(r'([0-9a-f]+) ([0-9a-f]+) [tT] (.+)',line)
  if m:
   canonical=m[3].replace('<','').replace('>','')
   for key,name in wanted.items():
    if canonical==name:
     assert key not in found
     found[key]={'symbol':m[3],'address':int(m[1],16),'bytes':int(m[2],16)}
 selected=[key for key in wanted if key in found]
 assert 'inner' in found and any(key in found for key in ['run_events','run_events_with_frame'])
 for key in selected:
  x=found[key];x['captured_bytes']=min(x['bytes'],prepared['symbol_byte_caps'][key]);x['truncated']=x['captured_bytes']<x['bytes']
 assert found==e['available_symbols']
 assert selected==e['captured'] and e['missing_symbols']==[key for key in wanted if key not in found]
 summaries[engine]={}
 for key in selected:
  x=found[key];label=engine+'-'+key
  expected[label]=prefix+['/usr/bin/objdump','-d','-C','--no-show-raw-insn','--start-address='+str(x['address']),'--stop-address='+str(x['address']+x['captured_bytes']),str(so)]
  text=(D/(label+'.stdout')).read_text();lines=[line for line in text.splitlines() if re.match(r'^\s*[0-9a-f]+:',line)]
  assert lines and all(x['address']<=int(line.split(':',1)[0].strip(),16)<x['address']+x['captured_bytes'] for line in lines)
  branches=[line for line in lines if re.search(r'\b(?:j[a-z]+|ret[q]?)\b',line)]
  memory_moves=[line for line in lines if re.search(r'\b(?:v?mov[a-z]*|lea[q]?)\b',line) and '(' in line]
  calls=[line for line in lines if re.search(r'\bcall[q]?\b',line)]
  summaries[engine][key]={**x,'decoded_address_lines_without_raw_byte_wraps':len(lines),'branch_return_lines':branches,'memory_move_lines':memory_moves,'call_lines':calls,'raw_sha256':H(D/(label+'.stdout'))}
assert len(expected)==len(capture['commands'])
assert {row['label'] for row in capture['commands']}==set(expected)
for row in capture['commands']:
 assert row['argv']==expected[row['label']] and row['exit']==0 and row['reaped'] and row['end']>=row['start']
 for stream in ['stdout','stderr']:assert H(D/(row['label']+'.'+stream))==row[stream+'_sha256']
r={'status':'verified_saved_current_empty_state_codegen','targets_executed':False,'engines':capture['engines'],'symbols':summaries,'command_count':len(expected),'capture_sha256':H(D/'capture.json'),'reader_sha256':H(__file__),'pins':capture['pins'],'limitations':['Static symbol and mnemonic evidence only. No profile, executed-path frequency, cycle count, throughput or allocation saving follows.','The bounded inner entry and C parent may contain inlined work. Branch/move/call lists do not automatically prove dominance or which field is written. Source/assembly review is required for each guard; symbol sizes are machine-code bytes, not object layout.','Missing standalone helpers may be inlined or optimized away; no debug/release rebuild is performed to manufacture a symbol.','Objdump uses --no-show-raw-insn to avoid byte-wrap lines. Captures may be explicitly truncated and do not imply absence of work elsewhere. No opcode or absent-call success criterion is imposed.']}
r['mechanism_review']={
 'option_payload':'Inspect candidate inner entry: the None branch must bypass owned payload loads/stores; compare control unconditional88-byte movement. Source take remains guarded but candidate behavior cannot be inferred from source alone.',
 'empty_default_queue':'Inspect run_events_with_frame if present, otherwise run_events: queue-empty branch must bypass drain_default_fragments call while nonempty path retains its call and later status checks.',
 'zero_source_charge':'Inspect inner/account_source: zero accounting_bytes must bypass account_source_bytes body and mark_accounted writeback. Inlining/missing symbols alone do not prove this. Nonzero branch remains fallible.',
 'assessment':'Pending explicit source/assembly review of actual captures; this saved reader validates provenance and extracts instructions without guessing control-flow semantics.'}
with (D/'report.json').open('x') as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'report_sha256':H(D/'report.json'),'symbols':{e:list(v) for e,v in summaries.items()}},indent=2))
