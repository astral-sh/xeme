# Held empty-state confirmation

One separate ordinary native epoch and one CPython epoch compare runtime66ca8e0b (candidate93b735, prebuild base and current PR160 head c8411446), selected eager c702, and the original normal Expat7a333. All original libraries and six O2 modules stay in their existing directories. No recompilation, pooling, favorable-epoch selection or automatic retry.

Initial Python elapsed is not yet complete. Preserve the pending recipe, then root fills exactly initial_python_primary_sha256, initial_python_independent_sha256 and materialization_release after both completed raw audits. The release value is released_by_root_after_initial_python_audit. The finalizer verifies the independent receipt binds the same primary and committed runtime before creating the confirmation directory. No partial elapsed output is used to prepare this recipe.

Eight current script transformations preserve the original native driver, unmodified CPython3.12.13, canonical/origin checks, inputs, seeds, worker counts, GC/construction/destruction boundaries, paired medians, cleanup and limits. Python removes only its build job and reuses six modules; fresh preflights remain mandatory.

- Native: 28 conditions (24 real +4 generated), seven pairs, 84 preflight+588 timed workers, 106,176 samples. CPU5 preflight then CPU0 elapsed; 90-second workers.
- Python: 24 conditions, seven pairs, 72 preflight+504 timed workers, 26,364 samples. CPU3 preflight then CPU0 elapsed; 300-second workers; zero compiles.
- Both preflight phases have 600-second bounds, elapsed phases 1,200 seconds.

Root runs prepare.py on CPU6 only after release, then schedules the native and Python phases separately with fresh before-host observations and the unchanged monitor-host.py. No target command is run by materialization. The normal Oriole O3/ThinLTO/cgu1 and original distinct normal Expat GCC recipe remain bound; no new compiler flags, dependency changes or PGO work.

Native ROOT and Python D retain original build/source/library/module provenance. Native NATIVE and Python C/S select fresh outputs. No old raw worker/result is copied. Current source has74 main files, two changed lib.rs files and four unchanged auxiliary files. All adverse rows and both epochs stay separate. CPU affinity and host observations do not establish global isolation; host attribution uses consecutive intervals fully within each elapsed phase.
