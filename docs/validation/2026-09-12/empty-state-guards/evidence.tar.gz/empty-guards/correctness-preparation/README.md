# Empty-state guards: held normal correctness gates

This is a source-only adaptation of the completed eager correctness recipe, for the empty-state candidate based on published `c8411446d5dc27a0f2c86d2bf48a71ee640cfb15`. The two changed runtime files are core lib.rs and C adapter lib.rs. The main source map remains 74 files; four auxiliary files and dependencies remain unchanged. Actual runtime commit and normal SO/static hashes are intentionally pending in [release-template.json](/tmp/oriole-empty-state-guards-correctness-preparation/release-template.json). No materializer, binder, compiler, parser or test target has executed.

## Release and source binding

After the completed normal build and source/build binders pass, root writes release.json from the template with status `released_completed_artifacts`, the actual committed runtime, source-binding hash, build-binding hash, and exact SO/static hashes. Keep the template frozen. The materializer rejects missing/pending fields, checks the current committed source and all 74 main/four auxiliary hashes, validates the passed bindings and their two independent source-review pins, and requires every generated controller to match its held copy exactly. The source-binding receipt replaces the previous candidate's formatting-specific receipt; its actual reviewed composition and patch remain bound. No result is inherited as a current pass.

## Unchanged test scope

- Original upstream API: all 4,740 configurations and original assertions, 3-second per-case limit, 1 GiB address-space / 768 MiB RSS limits, 240-second suite / 300-second outer limits. The comparison oracle remains 4,347 passes, 391 assertion failures and 2 timeouts. The raw matrix exit 1 remains a recorded nonzero outcome.
- Six C consumers: integration, adversarial and allocation fixtures, each shared/static, with the existing 120-second build/run limits. ASan/UBSan instrument the C consumer; the normal Rust library is uninstrumented and leak checking remains disabled.
- Strict CPython 3.12.13 shared/static: original loader/import origins and explicit pinned upstream pyexpat allocation-failure cleanup backport, with the complete execution loop unchanged and a 1,000-second child bound. Each linkage retains 802 method outcomes / 809 rendered lines and the same two known callback-fragmentation failures, raw exit 2. These patched strict modules are distinct from unmodified benchmark modules.
- Supplemental semantics: the unchanged two text-fragmentation tests run separately for each linkage. Their passes never replace or reclassify strict failures.

## Held root sequence

Exact argv vectors and CPU affinity are in [commands.json](/tmp/oriole-empty-state-guards-correctness-preparation/commands.json). Root owns all release, materialization and target execution and schedules them after elapsed campaigns have reaped. Run materialize.py on CPU 6, then bind.py and bind_strict.py on CPU 6. Run api_native.py on CPU 3 followed by saved read_api_c.py on CPU 6. Run strict_cpython.py on CPU 3. Prepare semantics on CPU 6, execute shared then static on CPU 3, and finish with saved read_strict_semantics.py on CPU 6. Each target retains its original process cleanup and raw statuses. No PGO, flag change, new harness, additional raw exemption or assertion change is included.

## Preparation limits

Prior materializer and all direct script diffs are retained. The nine held scripts AST-parse; the entire strict shared/static execution loop matches the eager predecessor byte for byte. Static repository inputs at the new paths were checked byte-for-byte. The only first-attempt issue was an in-memory AST node-count assumption (two semicolon-separated assignments produce two nodes), retained in preparation-attempt01.json. Correcting that check did not change a materializer, controller, runtime source or target result.
