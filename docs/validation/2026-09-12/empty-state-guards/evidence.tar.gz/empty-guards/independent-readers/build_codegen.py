"""Held saved-only build/codegen replay; never execute a compiler or target."""
from pathlib import Path
import argparse,ast,hashlib,json,os,re,subprocess
assert __debug__ and os.sched_getaffinity(0)=={6}
a=argparse.ArgumentParser()
for option in ['build-binding-sha','codegen-report-sha','candidate-so']:a.add_argument('--'+option,required=True)
a.add_argument('--runtime-commit',required=True)
a.add_argument('--root-codegen-review-sha',required=True)
a=a.parse_args()
assert all(re.fullmatch('[0-9a-f]{64}',v) for v in [a.build_binding_sha,a.codegen_report_sha,a.candidate_so])
assert a.runtime_commit is None or re.fullmatch('[0-9a-f]{40}',a.runtime_commit)
P=Path('/tmp/oriole-empty-state-guards-preparation');S=Path('/tmp/oriole-empty-state-guards-study');D=S/'codegen'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
static={'/tmp/oriole-empty-state-guards-preparation/prepared.json': '79c8f5e80a6fa6c218a923846ce07a356aed3c853fb5e284c8ea1d040341a4eb', '/tmp/oriole-empty-state-guards-preparation/source-binding.json': 'e6df4d9dc54adf1d4be498b52b7f9aa68dca661f86b5cb6b5093a4aa7e6f1cba', '/tmp/oriole-empty-state-guards-preparation/source.json': 'f2c2c508f56f440248d64d591cbc186965d7512f550c758aabfde0144b64d14b', '/tmp/oriole-empty-state-guards-preparation/expected-source.json': '04b634ccecd1962e235f4ec9358b0214769f93ccb36c761907283643b3399ba5', '/tmp/oriole-empty-state-guards-preparation/bind_build.py': '5988c10a702a966e04b5fb85d0661a2eb84355090645f9b79fb4c837a158182c', '/tmp/oriole-empty-state-guards-codegen-preparation/prepared.json': '96ffbf2865974aa8b548e3f4d9c7e310b1d80bb9b583e9c7055725faf8e68b7a', '/tmp/oriole-empty-state-guards-codegen-preparation/read.py': '017c4d0dbc014f1e35fb87a3df375b289f249971ce86b4349afca7092be1e64c', '/tmp/oriole-empty-state-guards-codegen-preparation/capture.py': 'c06f97151509f224abac460b640e248458dd661c6e7db68e6161056034935b66'}
for p,h in static.items():assert H(p)==h,p
assert H(S/'build-binding.json')==a.build_binding_sha
assert H(D/'report.json')==a.codegen_report_sha
# Replay exact actual-vector/source/check assertions, dropping only the original
# output-existence guard and outer try/finally writer. Git reads remain read-only.
binder=P/'bind_build.py';text=binder.read_text();tree=ast.parse(text)
cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Try))
prefix=[];removed=[]
for n in tree.body[:cut]:
 if isinstance(n,ast.Assert) and ast.get_source_segment(text,n)=='assert not report_path.exists()':removed.append(n)
 else:prefix.append(n)
assert len(removed)==1
body=prefix+tree.body[cut].body
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','mkdir','unlink'} for node in body for n in ast.walk(node))
scope={'__file__':str(binder),'__name__':'independent_saved_build_replay'}
exec(compile(ast.Module(body=body,type_ignores=[]),str(binder),'exec'),scope)
binding=J(S/'build-binding.json');assert binding==scope['report']
assert binding['tests']=={'passed':459,'groups':35,'failures':0,'ignored':0}
assert binding['candidate_libraries']['liboriole_expat.so']==a.candidate_so
assert binding['control_libraries']['liboriole_expat.so']=='c702fda9005743ecc2d11cec3a350e4cabcf00da563699c580929cc4fc221f0f'
source=J(S/'source.json');W=Path(source['worktree']);aux=binding['auxiliary_files']
assert len(source['sha256'])==74 and len(aux)==4
assert source['base']=='c8411446d5dc27a0f2c86d2bf48a71ee640cfb15'
assert set(binding['source_delta'])=={'crates/oriole/src/lib.rs','crates/oriole_expat/src/lib.rs'}
# An optional candidate commit is verified only when root has created one.
if a.runtime_commit:
 for n,h in {**source['sha256'],**aux}.items():
  assert hashlib.sha256(subprocess.check_output(['git','-C',str(W),'show',a.runtime_commit+':'+n])).hexdigest()==h,n
# Replay only the completed codegen reader's saved-input assertions and raw
# symbol/mnemonic reconstruction, before its exclusive report write.
reader=Path('/tmp/oriole-empty-state-guards-codegen-preparation/read.py');reader_text=reader.read_text();tree=ast.parse(reader_text)
cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.With))
assert "report.json" in ast.get_source_segment(reader_text,tree.body[cut])
body=tree.body[:cut]
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','check_output','mkdir','unlink','system'} for node in body for n in ast.walk(node))
codegen={'__file__':str(reader),'__name__':'independent_saved_codegen_replay'}
exec(compile(ast.Module(body=body,type_ignores=[]),str(reader),'exec'),codegen)
assert J(D/'report.json')==codegen['r']
capture=J(D/'capture.json')
assert capture['status']=='captured_current_release_empty_state_disassembly' and capture['targets_executed'] is False
assert capture['reader_sha256']==H('/tmp/oriole-empty-state-guards-codegen-preparation/capture.py')
assert set(capture['engines'])=={'control','candidate'}
for engine,study in [('control',Path('/tmp/oriole-eager-bare-tag-position-study')),('candidate',S)]:
 e=capture['engines'][engine];b=J(study/'build.json');s=J(study/'source.json')
 prefix='' if engine=='candidate' else 'control_'
 assert H(study/'source.json')==binding[prefix+'source_manifest_sha256']
 assert H(study/'build.json')==binding[prefix+'build_sha256']
 assert e['study']==str(study) and e['worktree']==s['worktree']
 so=study/'normal/liboriole_expat.so'
 assert Path(e['library'])==so and e['library_sha256']==H(so)==b['libraries'][so.name]==binding[engine+'_libraries'][so.name]
 assert so.read_bytes()[:4]==b'\x7fELF'
 for name,value in b['libraries'].items():assert H(study/'normal'/name)==value
 labels=[row['label'] for row in capture['commands']]
 assert len(labels)==len(set(labels))==len(codegen['expected'])
for p,h in capture['pins'].items():assert H(p)==h,p
root_review=J(S/'root-codegen-review.json')
assert H(S/'root-codegen-review.json')==a.root_codegen_review_sha
assert root_review['status']=='reviewed_actual_empty_state_codegen_and_commit'
assert root_review['runtime']==a.runtime_commit and root_review['source_sha256']==H(S/'source.json')
assert root_review['build_binding_sha256']==a.build_binding_sha
for p,h in root_review['pins'].items():assert H(p)==h,p
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip()==a.runtime_commit
# Exact saved disassembly anchors for the separately read current guard paths.
raw={name:(D/(name+'.stdout')).read_text() for name in ['candidate-inner','candidate-run_events','candidate-account_source','candidate-account_source_bytes','control-inner']}
for name,needle in [('candidate-inner','8ef55:\tje     8f138'),('candidate-inner','8ef04:\tcall   98610'),('candidate-inner','8eedb:\tjmp    8ef4c'),('candidate-run_events','af2e3:\tje     af2f2'),('candidate-run_events','af2e8:\tcall   b0e30'),('candidate-run_events','afabc:\tcall   b0e30'),('candidate-account_source','8a249:\tjmp    98610'),('candidate-account_source_bytes','98658:\tlock cmpxchg')]:assert needle in raw[name],(name,needle)
mechanisms={'zero_accounting':'Current inner computes the raw delta before dispatch. Zero branches8eedb/8eef7 join8ef4c without calling account_source_bytes or updating the source cursor; positive delta calls98610. The converted_raw_len call remains for encoded sources.','none_parameter':'Candidate discriminant check8ef4c and branch8ef55 bypass88-byte payload moves8ef63..8efa3 and take store8efac. Control copies at8ec64..8ecc2 before its discriminant check. Some cleanup/body remains.','empty_default_queue':'Candidate run_events compares0xc38/0xc40 ataf2d5/af2dc and jumps over the first drain call when equal. Nonempty first call and laterafabc drain remain before their original subsequent state handling.','nonzero_accounting':'Standalone wrapper160bytes tail-calls account_source_bytes523bytes on positive delta; lock cmpxchg remains. No assertion of unchanged nonzero code generation or universal inlining.','sizes':'Machine-code sizes only: inner19418to19681, run_events4770to4786. No parser layout or runtime savings inference.'}
for engine,inner,run in [('control',19418,4770),('candidate',19681,4786)]:
 assert codegen['summaries'][engine]['inner']['bytes']==inner and codegen['summaries'][engine]['run_events']['bytes']==run
assert codegen['summaries']['candidate']['account_source']['bytes']==160 and codegen['summaries']['candidate']['account_source_bytes']['bytes']==523
r={'status':'passed_independent_saved_build_and_codegen_review','targets_executed':False,'base':source['base'],'runtime_commit':a.runtime_commit,'source_count':74,'source_delta':binding['source_delta'],'auxiliary_files':aux,'tests':binding['tests'],'candidate_libraries':binding['candidate_libraries'],'control_libraries':binding['control_libraries'],'actual_core_compiler_vectors':J(S/'build.json')['compiler_vectors'],'actual_dependency_compiler_vectors':J(S/'build.json')['dependency_compiler_vectors'],'codegen_capture_commands':len(capture['commands']),'codegen_symbols':codegen['summaries'],'mechanism_review':mechanisms,'root_codegen_review_sha256':a.root_codegen_review_sha,'findings':[],'roles':'Separate saved-artifact execution of current build binder assertions and codegen reader, plus committed source hashes and direct assembly review. Reviewer authored the main build/native/Python pipeline and reviewed source guards; root independently reviewed the mechanism and owned all compiler/parser/artifact-capture invocations. API agent authored codegen capture/read. A separate peer reviews this saved reader.','limitations':['Static symbols and mnemonic lines do not prove dynamic frequencies, executed paths or elapsed gains.','Address-line counts include byte wraps and are not instruction counts; inline parent instructions are not automatically attributed to the helper.','No layout measurement or code-size expectation is imposed. A null runtime_commit means the exact working-tree source map is bound before a candidate commit exists.'],'pins':{str(p):h for p,h in static.items()}|capture['pins']|{str(S/'build-binding.json'):a.build_binding_sha,str(D/'report.json'):a.codegen_report_sha,str(D/'capture.json'):H(D/'capture.json'),str(S/'source.json'):H(S/'source.json'),str(S/'build.json'):H(S/'build.json'),str(S/'root-codegen-review.json'):a.root_codegen_review_sha},'reader_sha256':H(__file__)}
out=Path('/tmp/oriole-empty-state-guards-independent-build-codegen-review.json')
with out.open('x') as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'tests':r['tests'],'symbols':{k:list(v) for k,v in r['codegen_symbols'].items()},'receipt':str(out),'sha256':H(out)},indent=2))
