"""Completed normal CPython raw/origin/host audit; no parser or target execution."""
from pathlib import Path
import ast,csv,hashlib,json,math,os,re,subprocess,sys
assert __debug__ and os.sched_getaffinity(0)=={6}
assert len(sys.argv)>=4 and all(re.fullmatch("[0-9a-f]{64}",v) for v in sys.argv[1:4])
PRIMARY_SHA=sys.argv[1]
ROOT=Path('/tmp/oriole-empty-state-guards-study');D=ROOT/'python';CONF=Path('/tmp/oriole-empty-state-guards-confirmation');C=CONF/'python';OLD=Path('/tmp/oriole-eager-bare-tag-position-study/python')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text())
assert H(C/'normal-review.json')==PRIMARY_SHA
assert H(C/'preflight-review.json')==sys.argv[2]
assert H(CONF/'preparation.json')==sys.argv[3]
CONFROOT=CONF
held_source_pins={'/tmp/oriole-empty-state-guards-confirmation-preparation/prepared.json': 'da765fd6771b3dbebb11a53908a794c4b3e0b14c9775176546dd79c1e5e4f840', '/tmp/oriole-empty-state-guards-confirmation-preparation/prepare.py': '1df22f0adfdff0c3b371a3a5350123d80c8d599ecfa7c36092991ec45a6e98f7', '/tmp/oriole-empty-state-guards-confirmation-independent-source-review.json': 'd77736a902a070001d3ea299c4726e65dd268581434300675ee45b2714846542'}
for path,digest in held_source_pins.items():assert H(path)==digest,path
held_script_hashes={'native/run.py': '5f41a419e800e95954424e2a85d2ee988609d830db18dc85c469af801cd8aef5', 'native/native_screen.py': '2f53cb2b1a9f4ae699b69f70ca1ff361690fe79a6958e73802dcf107e55a7cc6', 'native/read_results.py': 'c63a5cd9f1e44ac2ae96c19f8e608a3b791a57859623d3269072f741b85314e2', 'python/python_worker.py': '4bc0ccffedb5048412b9cfc3638d28dcb30f711891c3784f3fbd3c0eb536ab68', 'python/consumer_screen.py': '61f07cb2d1762428e84d4bb2c615a0ae985d4afeb01088659b41d10eee9ff76b', 'python/run.py': '2996816c2bb8cf545da6651b1199f21a3beaaf0b09d870e59ba92105b57afa90', 'python/preflight_review.py': 'fa9d80899bf79ea839f2af935112b539b67e47a6fb4af597a16228876a0a067b', 'python/elapsed_review.py': '7f8c256f355036eca3e1a34a3b8ade46639564438c46ef83327afc8e79b39f8c'}
for name,digest in held_script_hashes.items():assert H(CONFROOT/name)==digest,name
confirmation_top=J(CONFROOT/'preparation.json')
assert confirmation_top['status']=='held_prepared_no_targets' and confirmation_top['finalizer_sha256']==held_source_pins['/tmp/oriole-empty-state-guards-confirmation-preparation/prepare.py']
for path,digest in confirmation_top['pins'].items():assert H(path)==digest,path
assert H(C/'preflight_review.py')=='fa9d80899bf79ea839f2af935112b539b67e47a6fb4af597a16228876a0a067b'
assert H(C/'elapsed_review.py')=='7f8c256f355036eca3e1a34a3b8ade46639564438c46ef83327afc8e79b39f8c'
assert H(C/'run.py')=='2996816c2bb8cf545da6651b1199f21a3beaaf0b09d870e59ba92105b57afa90'
for name in ['python_worker.py','consumer_screen.py']:assert (C/name).read_bytes()==(D/name).read_bytes()
static={'/tmp/oriole-empty-state-guards-study/python/source-preparation.json': '7316554243b4db35fce9b171e4c7e9061becb0ded8c959309778a7a4183c4b50', '/tmp/oriole-empty-state-guards-study/python/preparation.json': '21d35c8264f10c006de76dd801b5d9a9d968d65a812092b6bd569440fdd180a3', '/tmp/oriole-empty-state-guards-study/python/consumer-binding.json': 'd73306ccb4b97872c28be4aaf8cdbe8cc45803617228335b87a45feaf9fe69df', '/tmp/oriole-empty-state-guards-study/python/preflight_review.py': '95766dc6ba8d9125eafa979efd1c3b92fea62152bfe7798ae3690c7fa3997d72', '/tmp/oriole-empty-state-guards-study/python/elapsed_review.py': '52380d0bfe323251ee9c7623b538d1e02f9e42d93706ca55fc36a93b8219729e', '/tmp/oriole-empty-state-guards-python-independent-source-review.json': '990c87e7f9dd3cd82969cb496af7ce7f458b698eb1649799d591d71882662054'}
for path,value in static.items():assert H(path)==value,path
assert H(D/'elapsed_review.py')=='52380d0bfe323251ee9c7623b538d1e02f9e42d93706ca55fc36a93b8219729e'
assert H(D/'preflight_review.py')=='95766dc6ba8d9125eafa979efd1c3b92fea62152bfe7798ae3690c7fa3997d72'
preparation=J(D/'source-preparation.json')
for mapping in [preparation['pins'],preparation['parent_scripts'],preparation['selected_control_scripts']]:
 for path,value in mapping.items():assert H(path)==value,path
for name in ['python_worker.py','run.py','build_consumers.py']:assert (D/name).read_bytes()==(OLD/name).read_bytes()

def replay(path,stop):
 text=path.read_text();tree=ast.parse(text);lines=text.splitlines()
 cut=next(i for i,n in enumerate(tree.body) if stop(n,lines))
 assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','check_output','mkdir','unlink','system'} for node in tree.body[:cut] for n in ast.walk(node))
 scope={'__file__':str(path),'__name__':'independent_saved_python_replay'}
 exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),str(path),'exec'),scope)
 return scope

pre=replay(C/'preflight_review.py',lambda node,lines:lines[node.lineno-1].startswith('output=C/'))
actual_pre=J(C/'preflight-review.json');assert actual_pre==pre['result']
scope=replay(C/'elapsed_review.py',lambda node,lines:isinstance(node,ast.With) and lines[node.lineno-1].startswith('with csvpath.open'))
actual=J(C/'normal-review.json');expected=dict(scope['report']);expected['condition_csv_sha256']=H(C/'normal-conditions.csv');assert actual==expected
assert scope['D']==D and scope['C']==C and scope['S']==C/'screen'
assert actual_pre['extension_compiles']=={'fresh':0,'reused':6,'total':6}
assert pre['pins']==actual_pre['pins']
with (C/'normal-conditions.csv').open(newline='') as f:rows=list(csv.DictReader(f))
assert rows==[{k:str(v) for k,v in row.items()} for row in scope['rows']]
assert actual['counts']['all_workers']==576 and actual['counts']['all_samples']==26364 and len(actual['summary'])==24
for group,entry in actual['aggregates'].items():
 selected=[r for r in actual['summary'] if group=='all' or r['condition']['mode']==group]
 for name,value in entry['geomean_ratios'].items():assert math.isclose(math.prod(r['median_ratios'][name] for r in selected)**(1/len(selected)),value,rel_tol=1e-14,abs_tol=1e-14)
adverse=[r for r in actual['summary'] if r['median_ratios']['candidate_over_control']>1]
assert actual['aggregates']['all']['adverse_conditions']==[{'condition':r['condition'],**r['median_ratios']} for r in adverse]
for mapping in [pre['pins'],scope['pins']]:
 for path,value in mapping.items():assert H(path)==value,path
source=J(ROOT/'source.json');binding=J(ROOT/'build-binding.json')
assert len(source['sha256'])==74 and H(ROOT/'build-binding.json')=='3a32d417be17dcca84f23b6826e60cf0988a79c551ec025df0fb2f11b9d849d8'
commit=preparation['candidate_runtime_commit'];assert commit=='66ca8e0bf7d9e59412c290298d49660f12b8c26a'
assert set(binding['source_delta'])=={'crates/oriole/src/lib.rs','crates/oriole_expat/src/lib.rs'}
for name,value in {**source['sha256'],**binding['auxiliary_files']}.items():
 assert H(Path(source['worktree'])/name)==value
 assert hashlib.sha256(subprocess.check_output(['git','-C',source['worktree'],'show',commit+':'+name])).hexdigest()==value,name
assert actual['libraries']['candidate']['sha256']==binding['candidate_libraries']['liboriole_expat.so']=='93b735d89c1c0ee1989178b56ede6d7fbfed12a55c297a74cf9431f7596fc0e3'
assert actual['libraries']['control']['sha256']=='c702fda9005743ecc2d11cec3a350e4cabcf00da563699c580929cc4fc221f0f'
# Exact existing pure counter arithmetic, embedded to avoid historical reader replay.
def counters(first, last):
    delta = {name: {key: last['cpu'][name][key] - first['cpu'][name][key] for key in ('total', 'idle')} for name in ('cpu', 'cpu0')}
    assert last['time'] > first['time']
    for values in delta.values():
        assert 0 <= values['idle'] <= values['total'] and values['total'] > 0
    other_total = delta['cpu']['total'] - delta['cpu0']['total']
    other_idle = delta['cpu']['idle'] - delta['cpu0']['idle']
    assert 0 <= other_idle <= other_total and other_total > 0
    return {'start': first['time'], 'end': last['time'], 'seconds': last['time']-first['time'], 'counter_deltas': delta,
            'idle_including_iowait_fractions': {name: values['idle']/values['total'] for name, values in delta.items()},
            'other_cpus_idle_including_iowait_fraction': other_idle/other_total}
during=J(CONF/'host-during-python.json');controller=J(C/'time-controller.json');timing,=controller['jobs']
assert during['status']=='completed' and during['phase']=='python' and during['controller_status']==controller['status']=='passed'
assert during['controller_sha256']==H(C/'time-controller.json') and during['monitor_sha256']==H(CONF/'monitor-host.py')
before_files=sys.argv[4:] or ['host-before-python.json'];assert len(before_files)==len(set(before_files))
before_records=[]
for filename in before_files:
 assert Path(filename).name==filename and filename.endswith('.json')
 before=J(CONF/filename)
 assert len(before['samples'])==2 and before['samples'][-1]['time']<=timing['start']
 before_summary=counters(before['samples'][0],before['samples'][-1]);assert before_summary['idle_including_iowait_fractions']==before['idle_plus_iowait_fraction']
 before_records.append({'file':filename,'sha256':H(CONF/filename),'summary':before_summary})
assert all(x['summary']['end']<=y['summary']['start'] for x,y in zip(before_records,before_records[1:]))

intervals=[counters(x,y) for x,y in zip(during['samples'],during['samples'][1:])]
inside=[r for r in intervals if timing['start']<=r['start'] and r['end']<=timing['end']]
outside=[r for r in intervals if not (timing['start']<=r['start'] and r['end']<=timing['end'])]
points=[p for p in during['samples'] if timing['start']<=p['time']<=timing['end']];assert inside and len(points)>=2 and len(inside)+1==len(points)
aggregate=counters(points[0],points[-1]);assert math.isclose(sum(r['seconds'] for r in inside),aggregate['seconds'],abs_tol=1e-9)
for cpu in ['cpu','cpu0']:
 for key in ['total','idle']:assert sum(r['counter_deltas'][cpu][key] for r in inside)==aggregate['counter_deltas'][cpu][key]
host={'before':before_records,'during_sample_count':len(during['samples']),'elapsed_controller':{'start':timing['start'],'end':timing['end'],'seconds':timing['end']-timing['start']},'sample_intervals_fully_inside_elapsed':{'count':len(inside),'aggregate':aggregate,'fraction_of_elapsed':aggregate['seconds']/(timing['end']-timing['start']),'other_cpus_idle_range':[min(r['other_cpus_idle_including_iowait_fraction'] for r in inside),max(r['other_cpus_idle_including_iowait_fraction'] for r in inside)],'intervals':inside},'excluded_outside_or_boundary_intervals':outside,'limitations':['Five-second /proc/stat samples count idle+iowait and exclude duplicate guest fields; no OS isolation or absence-of-contention claim.','Only consecutive intervals fully inside elapsed are attributed; no interpolation or per-condition attribution.','Pre-run observation remains separate from during-run activity.']}
paths=[CONF/'preparation.json',C/'preparation.json',D/'source-preparation.json',C/'preflight_review.py',C/'elapsed_review.py',C/'preflight-review.json',C/'normal-review.json',C/'normal-conditions.csv',C/'prepare-controller.json',C/'time-controller.json',ROOT/'source.json',ROOT/'build-binding.json',*(CONF/name for name in before_files),CONF/'host-during-python.json',CONF/'monitor-host.py',Path(__file__)]
result={'status':'passed_independent_normal_python_raw_and_host_review','targets_executed':False,'role':'Separate current saved-worker reconstruction by author of current build/Python/confirmation preparation and reviewer of the composed guards; separate peers reviewed those scripts and this reader. Only current primary prefixes are replayed; host arithmetic is embedded unchanged, with no historical reader execution. Root owns all targets and primary readers.','runtime_commit':commit,'counts':actual['counts'],'aggregates':actual['aggregates'],'all_conditions':actual['summary'],'all_adverse_conditions':adverse,'host':host,'provenance':{'libraries':actual['libraries'],'main_source_files':74,'main_changed_files':list(binding['source_delta']),'auxiliary_files_unchanged':4,'preflight_pins':len(pre['pins']),'elapsed_pins':len(scope['pins']),'fresh_compiles':0,'reused_modules':6},'limitations':['All24 conditions and every adverse row retained. Initial and confirmation epochs remain separate without pooling. This confirmation normal CPython project-input benchmark is not whole-application performance or exact callback-fragmentation compatibility.','Unmodified CPython3.12.13 O2 modules, module/dladdr origins, enabled GC, parse construction/feed/finalization/callbacks plus explicit destruction and canonical hashes match the original protocol.','No causal, statistical-significance or exclusive-host assertion. Current candidate adoption remains a separate root decision.'],'pins_sha256':{str(p):H(p) for p in paths},'reader_sha256':H(__file__)}
out=Path('/tmp/oriole-empty-state-guards-confirmation-independent-python-review.json')
with out.open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'receipt':str(out),'sha256':H(out),'counts':actual['counts'],'aggregates':actual['aggregates'],'fully_interior_host':{'intervals':len(inside),'seconds':aggregate['seconds'],'elapsed_seconds':timing['end']-timing['start'],'other_cpus_idle_iowait':aggregate['other_cpus_idle_including_iowait_fraction'],'excluded_intervals':len(outside)}},indent=2))
