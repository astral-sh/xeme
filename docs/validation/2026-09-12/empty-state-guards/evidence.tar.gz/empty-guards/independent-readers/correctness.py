"""Reconstruct completed correctness evidence without running a target or primary writes."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import json
import os
import re
import subprocess
import sys

assert __debug__ and os.sched_getaffinity(0) == {6}
assert len(sys.argv) == 3 and all(re.fullmatch(r'[0-9a-f]{64}', x) for x in sys.argv[1:]), 'Expected completed primary API/C and strict/semantic report SHA256 arguments'
api_expected_sha256, strict_expected_sha256 = sys.argv[1:]
P = Path('/tmp/oriole-empty-state-guards-correctness')
B = Path('/tmp/oriole-empty-state-guards-study')
W = Path('/home/dev-user/code/oss/oriole-empty-state-guards')
OUT = Path('/tmp/oriole-empty-state-guards-correctness-independent-review.json')
assert not OUT.exists()
inputs = {}
def sha(path):
    path = Path(path)
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    assert str(path) not in inputs or inputs[str(path)] == value
    inputs[str(path)] = value
    return value
def load(path):
    sha(path)
    return json.loads(Path(path).read_text())
def replay(reader, report):
    script = P / reader
    expected = load(P / report)
    assert sha(script) == expected['reader_sha256']
    tree = ast.parse(script.read_bytes())
    end = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == 'result' for t in node.targets)) + 1
    # Both exact reader prefixes were inspected: only saved reads/assertions and
    # pure AST extraction of methods() execute. Stop before every output write.
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                   and n.func.attr in {'write_text', 'write_bytes', 'Popen', 'run', 'check_output', 'mkdir', 'unlink', 'system'}
                   for node in tree.body[:end] for n in ast.walk(node))
    ns = {'__file__': str(script), '__name__': 'independent_saved_replay'}
    exec(compile(ast.Module(body=tree.body[:end], type_ignores=[]), str(script), 'exec'), ns)
    assert json.loads(json.dumps(ns['result'])) == expected, reader
    for path, digest in expected['inputs'].items():
        assert sha(path) == digest, path
    return ns, expected

assert sha(P/'api-c-readback.json') == api_expected_sha256
assert sha(P/'strict-semantic-readback.json') == strict_expected_sha256
assert sha(P/'read_api_c.py') == 'f7cfed5c5bf0c6287254ba204ed34db276d8c7dd3c7df35a6a6cc87395a2fdff'
assert sha(P/'read_strict_semantics.py') == 'b575d062a17c0b8775e34cfd0fb2e19b18ad784a5199cfec02c1bfea897395ea'
api_ns, api = replay('read_api_c.py', 'api-c-readback.json')
strict_ns, strict = replay('read_strict_semantics.py', 'strict-semantic-readback.json')
assert len(api_ns['rows'][1]) == 4740
assert dict(Counter(r['outcome'] for r in api_ns['rows'][1])) == {'pass':4347,'fail':391,'timeout':2}
assert all(r['exit'] == 0 for r in api['c_consumers']) and len(api['c_consumers']) == 6
assert all(v['full_method_map'] == strict['strict']['shared']['full_method_map']
           for v in strict['strict'].values())
for linkage, value in strict['strict'].items():
    assert len(value['full_method_map']) == 802 and value['rendered_outcome_lines'] == 809
    assert value['raw_exit'] == 2 and len(value['failures']) == 2 and value['changes'] == []
    assert len(value['origins']) == 4 and len(value['compiler_commands']) == 2
assert len(strict['semantics']) == 2 and all(r['tests'] == 2 and r['exit'] == 0 for r in strict['semantics'])

source = load(B/'source.json')
binding = load(B/'build-binding.json')
assert len(source['sha256']) == 74 and binding['source_manifest_sha256'] == sha(B/'source.json')
assert set(binding['source_delta']) == {'crates/oriole/src/lib.rs', 'crates/oriole_expat/src/lib.rs'}
assert len(binding['auxiliary_files']) == 4
for name, digest in source['sha256'].items(): assert sha(W/name) == digest
for name, digest in binding['auxiliary_files'].items(): assert sha(W/name) == digest
head = subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'], text=True).strip()
assert head == '66ca8e0bf7d9e59412c290298d49660f12b8c26a'

current = load(P/'preparation.json')
assert sha(P/'preparation.json') == '8cad29787bfeab8f19663a58567b3a981b38a1bb0ac693ee28e74a7166488143'
assert current['candidate_source_commit'] == head
assert current['measured_source_base_commit'] == 'c8411446d5dc27a0f2c86d2bf48a71ee640cfb15'
assert current['controller_origins']['strict_cpython.py']['path_substitution_only'] is False
assert len(current['controller_origins']) == 9
for name, origin in current['controller_origins'].items():
    assert sha(P/name) == origin['sha256']
    assert sha(origin['origin']) == origin['origin_sha256']
assert sha('/tmp/oriole-empty-state-guards-correctness-preparation/materialize.py') == 'fbcc161e42ba0f30232106308349b6b76d55218a47a33593cc7b1fb490037370'
assert sha('/tmp/oriole-empty-state-guards-correctness-independent-source-review.json') == '84a9f711b9686986739c79711b8507024e1180462f83cd5121bdf82ebb1e3118'
assert sha(P/'reviewed-source.json') == 'e6df4d9dc54adf1d4be498b52b7f9aa68dca661f86b5cb6b5093a4aa7e6f1cba'
source_binding = load(P/'reviewed-source.json')
prepared_source = load(P/'reviewed-prepared-source.json')
release = load(P/'reviewed-release.json')
assert source_binding['status'] == 'passed_saved_source_binding'
assert prepared_source['sha256'] == source['sha256']
assert sha(P/'reviewed-prepared-source.json') == binding['prepared_source_sha256'] == source_binding['source_sha256']
assert prepared_source['review_pins'] == source_binding['review_pins'] and len(source_binding['review_pins']) == 2
for path,digest in source_binding['review_pins'].items(): assert sha(path) == digest
assert sha(P/'reviewed-release.json') == '5736a2a4a38f3154bafddef33c11affea8dcd51db5d0ea8a60eac9144ba60608'
assert release['status'] == 'released_completed_artifacts' and release['candidate_source_commit'] == head
assert release['base'] == source['base'] == current['measured_source_base_commit']
assert release['source_binding_sha256'] == sha(P/'reviewed-source.json')
assert release['build_binding_sha256'] == sha(B/'build-binding.json')
assert release['candidate_libraries'] == binding['candidate_libraries']
bound = load(P/'bound.json')
assert sha(P/'bound.json') == 'b845664c019574ce56317ccef3e6baf303f8c7669a2b3f8cb5427f5bdf682dbd'
assert sha(P/'bound.json') == strict['inputs'][str(P/'bound.json')]
assert sha(P/'strict-pins.json') == strict['inputs'][str(P/'strict-pins.json')]
assert bound['source_sha256'] == sha(B/'source.json')
assert bound['build_binding_sha256'] == sha(B/'build-binding.json') == '3a32d417be17dcca84f23b6826e60cf0988a79c551ec025df0fb2f11b9d849d8'
assert bound['pins_sha256'] == sha(P/'pins.json')
for extension, digest in [('so', '93b735d89c1c0ee1989178b56ede6d7fbfed12a55c297a74cf9431f7596fc0e3'),
                          ('a', '7853d7c3ffd18eaf3b41cf36d6f0828cd7754b5f9749a6617fb88fc79a85f03c')]:
    assert bound['libraries'][extension]['sha256'] == digest == sha(bound['libraries'][extension]['path'])
    assert binding['candidate_libraries']['liboriole_expat.'+extension] == digest
for path, digest in list(inputs.items()): assert sha(path) == digest
result = {
    'status':'passed_independent_saved_correctness_review', 'targets_executed':False,
    'reader_sha256':sha(__file__), 'runtime_commit':head, 'source_files':74,
    'auxiliary_files':binding['auxiliary_files'], 'libraries':bound['libraries'],
    'api':api['api'], 'c_consumers':api['c_consumers'],
    'strict':{k:{'methods':v['methods'],'rendered_outcome_lines':v['rendered_outcome_lines'],
                 'raw_exit':v['raw_exit'],'failures':v['failures'],'changes':v['changes'],
                 'origins':v['origins'],'compiler_commands':v['compiler_commands'],
                 'full_method_map_sha256':hashlib.sha256(json.dumps(v['full_method_map'],sort_keys=True).encode()).hexdigest()}
              for k,v in strict['strict'].items()},
    'semantics':strict['semantics'],
    'controller_provenance':{'preparation_sha256':sha(P/'preparation.json'),
                             'origin_scripts':current['controller_origins'],
                             'strict_path_substitution_only':False,
                             'scope':'Current strict commit label comes from pinned preparation metadata; release/source/build pins match before target execution. Historical provenance corrections are not current target reruns.'},
    'checked_inputs':inputs, 'findings':[],
    'limitations':[
        'Existing 391 API assertion failures and two per-test timeouts remain; unchanged outcomes do not mean complete Expat compatibility.',
        'Six C harnesses use ASan/UBSan, but linked Rust normal-release libraries are uninstrumented and leak detection is disabled.',
        'Strict consumers contain the pinned upstream pyexpat cleanup backport; benchmark consumers are unmodified. Two strict callback-fragmentation failures remain in each linkage.',
        'Two supplemental semantic tests pass per linkage as separate evidence; they do not turn the strict suite green. 809 rendered outcomes contain 802 distinct method identities.',
        'No additional target, sanitizer, fuzz, PBS, performance or adoption result is established by this saved-only audit.',
    ],
    'role':'Saved raw reconstruction is independent of root target execution. This adapter author also authored the queue/parameter-reference guards and correctness preparation; root authored the accounting wrapper. It is not an independent runtime authorship review. The earlier attribute audit came from another agent. A separate peer reviews this reader source; root executes correctness targets and primary readers.',
}
with OUT.open('x') as stream: stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'path':str(OUT),'sha256':sha(OUT),'input_pins':len(inputs),
                  'api':api['api'],'c_consumers':6,'strict_methods_per_linkage':802,'semantic_tests_per_linkage':2}))
