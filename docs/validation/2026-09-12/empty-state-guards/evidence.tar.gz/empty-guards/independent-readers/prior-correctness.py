"""Reconstruct completed correctness evidence without running a target or primary writes."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import json
import os
import re
import subprocess
import sys

assert __debug__ and os.sched_getaffinity(0) == {6}
assert len(sys.argv) == 3 and all(re.fullmatch(r'[0-9a-f]{64}', x) for x in sys.argv[1:]), 'Expected completed primary API/C and strict/semantic report SHA256 arguments'
api_expected_sha256, strict_expected_sha256 = sys.argv[1:]
P = Path('/tmp/oriole-eager-bare-tag-position-correctness')
B = Path('/tmp/oriole-eager-bare-tag-position-study')
W = Path('/home/dev-user/code/oss/oriole-eager-bare-tag-position')
OUT = Path('/tmp/oriole-eager-bare-tag-position-correctness-independent-review.json')
assert not OUT.exists()
inputs = {}
def sha(path):
    path = Path(path)
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    assert str(path) not in inputs or inputs[str(path)] == value
    inputs[str(path)] = value
    return value
def load(path):
    sha(path)
    return json.loads(Path(path).read_text())
def replay(reader, report):
    script = P / reader
    expected = load(P / report)
    assert sha(script) == expected['reader_sha256']
    tree = ast.parse(script.read_bytes())
    end = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == 'result' for t in node.targets)) + 1
    # Both exact reader prefixes were inspected: only saved reads/assertions and
    # pure AST extraction of methods() execute. Stop before every output write.
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                   and n.func.attr in {'write_text', 'write_bytes', 'Popen', 'run', 'check_output', 'mkdir', 'unlink', 'system'}
                   for node in tree.body[:end] for n in ast.walk(node))
    ns = {'__file__': str(script), '__name__': 'independent_saved_replay'}
    exec(compile(ast.Module(body=tree.body[:end], type_ignores=[]), str(script), 'exec'), ns)
    assert json.loads(json.dumps(ns['result'])) == expected, reader
    for path, digest in expected['inputs'].items():
        assert sha(path) == digest, path
    return ns, expected

assert sha(P/'api-c-readback.json') == api_expected_sha256
assert sha(P/'strict-semantic-readback.json') == strict_expected_sha256
assert sha(P/'read_api_c.py') == '4957339f9f307626dbae1bb04694766c113a50d875b7b9b920e0749124f704b6'
assert sha(P/'read_strict_semantics.py') == '7fc1ba4479009dc532a3a7b7b91fe05ad725aeb3bb3697560dd531b90ba97814'
api_ns, api = replay('read_api_c.py', 'api-c-readback.json')
strict_ns, strict = replay('read_strict_semantics.py', 'strict-semantic-readback.json')
assert len(api_ns['rows'][1]) == 4740
assert dict(Counter(r['outcome'] for r in api_ns['rows'][1])) == {'pass':4347,'fail':391,'timeout':2}
assert all(r['exit'] == 0 for r in api['c_consumers']) and len(api['c_consumers']) == 6
assert all(v['full_method_map'] == strict['strict']['shared']['full_method_map']
           for v in strict['strict'].values())
for linkage, value in strict['strict'].items():
    assert len(value['full_method_map']) == 802 and value['rendered_outcome_lines'] == 809
    assert value['raw_exit'] == 2 and len(value['failures']) == 2 and value['changes'] == []
    assert len(value['origins']) == 4 and len(value['compiler_commands']) == 2
assert len(strict['semantics']) == 2 and all(r['tests'] == 2 and r['exit'] == 0 for r in strict['semantics'])

source = load(B/'source.json')
binding = load(B/'build-binding.json')
assert len(source['sha256']) == 74 and binding['source_manifest_sha256'] == sha(B/'source.json')
assert set(binding['source_delta']) == {'crates/oriole/src/tag.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole/src/lib.rs'}
assert len(binding['auxiliary_files']) == 4
for name, digest in source['sha256'].items(): assert sha(W/name) == digest
for name, digest in binding['auxiliary_files'].items(): assert sha(W/name) == digest
head = subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'], text=True).strip()
assert head == '19251bc01dba14cc57507facd2d607a9075471b5'

current = load(P/'preparation.json')
assert sha(P/'preparation.json') == 'c8399dcf86512bb18ebeea4587146d552335781778a4a25a86d459fe8769c0ec'
assert current['candidate_source_commit'] == head
assert current['measured_source_base_commit'] == '0c407f28e2aa01178fda86a97561ed734f8d8e1d'
assert current['controller_origins']['strict_cpython.py']['path_substitution_only'] is False
assert len(current['controller_origins']) == 9
for name, origin in current['controller_origins'].items():
    assert sha(P/name) == origin['sha256']
    assert sha(origin['origin']) == origin['origin_sha256']
assert sha('/tmp/oriole-eager-bare-tag-position-correctness-preparation/materialize.py') == '89df6128c3d34f2a6683b94425b3071aeec58b4fb0974b99837df9344c203707'
assert sha('/tmp/oriole-eager-bare-tag-position-correctness-independent-source-review.json') == '0e8dd44090a8035a3db31e999fb6ca24771c46995682ddf002b7f4669c339823'
assert sha(P/'reviewed-source.json') == '565507ec861a4fee7a6df00b94d6fab0183bbdcdd0d0caa02e8a3dceeb2ebcbc'
assert sha(P/'reviewed-formatting.json') == '69cfddd828511053a1a4edb5e717226972f6b63a84ebf3cf84572b862d65e4bb'
bound = load(P/'bound.json')
assert sha(P/'bound.json') == strict['inputs'][str(P/'bound.json')]
assert sha(P/'strict-pins.json') == strict['inputs'][str(P/'strict-pins.json')]
assert bound['source_sha256'] == sha(B/'source.json')
assert bound['build_binding_sha256'] == sha(B/'build-binding.json') == '44ee17d227b4be4498799a7004aec0a6d87f8beae7bce646da6cdede5c177d80'
assert bound['pins_sha256'] == sha(P/'pins.json')
for extension, digest in [('so', 'c702fda9005743ecc2d11cec3a350e4cabcf00da563699c580929cc4fc221f0f'),
                          ('a', '29390ba6a2fc3351c9bbaaf58560b3cff8ed1b508cbf209578a3d7f01e80d08a')]:
    assert bound['libraries'][extension]['sha256'] == digest == sha(bound['libraries'][extension]['path'])
    assert binding['candidate_libraries']['liboriole_expat.'+extension] == digest
for path, digest in list(inputs.items()): assert sha(path) == digest
result = {
    'status':'passed_independent_saved_correctness_review', 'targets_executed':False,
    'reader_sha256':sha(__file__), 'runtime_commit':head, 'source_files':74,
    'auxiliary_files':binding['auxiliary_files'], 'libraries':bound['libraries'],
    'api':api['api'], 'c_consumers':api['c_consumers'],
    'strict':{k:{'methods':v['methods'],'rendered_outcome_lines':v['rendered_outcome_lines'],
                 'raw_exit':v['raw_exit'],'failures':v['failures'],'changes':v['changes'],
                 'origins':v['origins'],'compiler_commands':v['compiler_commands'],
                 'full_method_map_sha256':hashlib.sha256(json.dumps(v['full_method_map'],sort_keys=True).encode()).hexdigest()}
              for k,v in strict['strict'].items()},
    'semantics':strict['semantics'],
    'controller_provenance':{'preparation_sha256':sha(P/'preparation.json'),
                             'origin_scripts':current['controller_origins'],
                             'strict_path_substitution_only':False,
                             'scope':'Current source and commit labels were accurate before target execution. Historical LF provenance correction is not a current target rerun.'},
    'checked_inputs':inputs, 'findings':[],
    'limitations':[
        'Existing 391 API assertion failures and two per-test timeouts remain; unchanged outcomes do not mean complete Expat compatibility.',
        'Six C harnesses use ASan/UBSan, but linked Rust normal-release libraries are uninstrumented and leak detection is disabled.',
        'Strict consumers contain the pinned upstream pyexpat cleanup backport; benchmark consumers are unmodified. Two strict callback-fragmentation failures remain in each linkage.',
        'Two supplemental semantic tests pass per linkage as separate evidence; they do not turn the strict suite green. 809 rendered outcomes contain 802 distinct method identities.',
        'No additional target, sanitizer, fuzz, PBS, performance or adoption result is established by this saved-only audit.',
    ],
    'role':'Saved raw reconstruction is independent of root target execution. This adapter author also authored the eager proposal, composition and ordinary/native/Python/correctness preparation; it is not an independent runtime authorship review. The original attribute audit came from another agent. A separate peer reviews this reader source; root executes correctness targets and primary readers.',
}
with OUT.open('x') as stream: stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'path':str(OUT),'sha256':sha(OUT),'input_pins':len(inputs),
                  'api':api['api'],'c_consumers':6,'strict_methods_per_linkage':802,'semantic_tests_per_linkage':2}))
