"""Replay completed Python preflight records only, without loading modules."""
from pathlib import Path
import ast,hashlib,json,os,re,sys
assert __debug__ and os.sched_getaffinity(0)=={6}
assert len(sys.argv)==2 and re.fullmatch('[0-9a-f]{64}',sys.argv[1])
D=Path('/tmp/oriole-empty-state-guards-study/python')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
static={'/tmp/oriole-empty-state-guards-study/python/source-preparation.json': '7316554243b4db35fce9b171e4c7e9061becb0ded8c959309778a7a4183c4b50', '/tmp/oriole-empty-state-guards-study/python/preparation.json': '21d35c8264f10c006de76dd801b5d9a9d968d65a812092b6bd569440fdd180a3', '/tmp/oriole-empty-state-guards-study/python/consumer-binding.json': 'd73306ccb4b97872c28be4aaf8cdbe8cc45803617228335b87a45feaf9fe69df', '/tmp/oriole-empty-state-guards-study/python/preflight_review.py': '95766dc6ba8d9125eafa979efd1c3b92fea62152bfe7798ae3690c7fa3997d72', '/tmp/oriole-empty-state-guards-study/python/elapsed_review.py': '52380d0bfe323251ee9c7623b538d1e02f9e42d93706ca55fc36a93b8219729e', '/tmp/oriole-empty-state-guards-python-independent-source-review.json': '990c87e7f9dd3cd82969cb496af7ce7f458b698eb1649799d591d71882662054'}
for p,h in static.items():assert H(p)==h,p
assert H(D/'preflight-review.json')==sys.argv[1]
reader=D/'preflight_review.py';text=reader.read_text();tree=ast.parse(text);lines=text.splitlines()
cut=next(i for i,n in enumerate(tree.body) if lines[n.lineno-1].startswith('output=D/'))
body=tree.body[:cut]
assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'write_text','write_bytes','Popen','check_output','mkdir','unlink','system'} for node in body for n in ast.walk(node))
scope={'__file__':str(reader),'__name__':'independent_saved_python_preflight_replay'}
exec(compile(ast.Module(body=body,type_ignores=[]),str(reader),'exec'),scope)
primary=J(D/'preflight-review.json');assert primary==scope['result']
assert primary['preflight_workers']==72 and len(primary['conditions'])==len(primary['canonical_outputs'])==24
assert primary['extension_compiles']=={'fresh':2,'reused':4,'total':6}
assert len(primary['exact_compile_vectors'])==6 and set(primary['origins'])=={'candidate','control','expat'}
prior=J(D/'source-preparation.json');assert prior['candidate_runtime_commit']=='66ca8e0bf7d9e59412c290298d49660f12b8c26a'
for engine,h in [('candidate','93b735d89c1c0ee1989178b56ede6d7fbfed12a55c297a74cf9431f7596fc0e3'),('control','c702fda9005743ecc2d11cec3a350e4cabcf00da563699c580929cc4fc221f0f'),('expat','7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478')]:assert primary['origins'][engine]['parser_library']['sha256']==h
for p,h in scope['pins'].items():assert H(p)==h,p
r={'status':'passed_independent_saved_python_preflight_review','targets_executed':False,'runtime_commit':prior['candidate_runtime_commit'],'preflight_workers':72,'canonical_conditions':24,'extension_compiles':primary['extension_compiles'],'compiler_vectors':primary['exact_compile_vectors'],'origins':primary['origins'],'primary_sha256':H(D/'preflight-review.json'),'canonical_outputs':primary['canonical_outputs'],'pins':dict(scope['pins'])|static|{str(D/'preflight-review.json'):H(D/'preflight-review.json')},'reader_sha256':H(__file__),'role':'Separate saved replay by author of current Python/build preparation; unchanged target workers retain their original authors. This reviewer did not execute modules. Root owns producer/preflight targets and primary readback.','limits':'Canonical output equality merges character chunks; these preflights do not replace strict CPython tests or establish elapsed performance.'}
out=Path('/tmp/oriole-empty-state-guards-independent-python-preflight-review.json')
with out.open('x') as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'workers':72,'conditions':24,'pins':len(r['pins']),'sha256':H(out)}))
