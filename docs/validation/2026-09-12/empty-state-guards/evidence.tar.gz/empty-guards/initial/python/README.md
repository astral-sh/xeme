# Empty-state guards: held normal CPython protocol

Root materializes this recipe after a completed ordinary build/binding, a native gain, and a committed candidate runtime. The source base is c8411446; the future runtime commit is supplied explicitly. Candidate library hashes come only from the completed build binding.

The selected eager c702 modules become this control. The two original Expat modules are reused in their original directory. Only two candidate modules are compiled, from unchanged CPython 3.12.13 sources using the identical O2 recipe. There are 72 fresh canonical preflights and 504 timed workers: 24 conditions, seven pairs, 26,364 samples. No strict cleanup backport enters the timed modules.

run.py, python_worker.py and build_consumers.py are byte-identical to the successful eager protocol. Screen captions and saved-reader output paths change. Counts, seed, canonical callback/tree comparisons, actual module/library origins, GC policy, construction/destruction boundaries, medians, timeout cleanup and all adverse rows remain unchanged. Build/preflight bounds are 600 seconds, elapsed 1,200 seconds, and individual workers 300 seconds.

The 74 main files have exactly two changed lib.rs files (three reviewed guards); all four auxiliary files and dependencies remain unchanged. Saved materialization/binding/readers use CPU6; root owns the two compiles plus preflights on CPU3 and elapsed on CPU0, with separate before/during host observations. Affinity does not establish global host isolation. No PGO or new compiler/allocator settings are introduced.

No future build outputs were read and no candidate consumers or parsers were executed during this held preparation. Root runs materialize.py --released <committed-runtime-sha> first, then the separate held commands. The inherited module-builder method sentence is historical provenance; this recipe's actual ordinary build binding and O2 compiler vectors define the current experiment.
