# Empty-state guards: held ordinary build and native measurement

Base: published `c8411446d5dc27a0f2c86d2bf48a71ee640cfb15`. Control: measured eager runtime `19251bc`, normal SO `c702fda9…`; Expat remains the original normal `7a333bc8…` library. No target has run during this preparation.

Root created `/home/dev-user/code/oss/oriole-empty-state-guards` and applied/formatted three reviewed changes: the zero-byte accounting wrapper, absent parameter-reference guard and empty default-fragment queue guard. Only core `lib.rs` and C adapter `lib.rs` differ. The final 74-file map and four auxiliary manifests/locks match `expected-source.json`; the complete diff is `reviewed-source.patch`. Existing meaningful tests remain unchanged: expected 459 tests, 35 groups. Dependencies and compiler settings are unchanged.

Four scripts directly adapt the completed eager recipes; adjacent `.py.patch` files show every change:

1. `bind_source.py BASE` (CPU6, saved-only) checks real/common Git and OSS identity, exact base/source/auxiliary bytes, both source-review receipts and sealed script hashes. It writes `source.json`, `candidate.patch` and `source-binding.json` once. It refuses the initial pending preparation state.
2. `build.py` (CPU4, **root release only**) uses the unchanged seven-command body: compiler version, workspace format/tests/Clippy, inprocess format/Clippy, ordinary normal release. Target is `/home/dev-user/.cache/oriole/empty-state-guards-target`; separate shared Ohm build directory and cleared trust/flag environment are unchanged. Each child is bounded to 900 seconds and killed/reaped on interruption. No compiler optimization changes or PGO.
3. `bind_build.py` (CPU6, saved-only) binds all seven actual commands/logs, current and control sources/tools/libraries, three core and three dependency compiler vectors, unchanged feature/lock identities and actual test totals. Normalization preserves compiler policy and argument order.
4. `prepare_native.py` (CPU6, saved-only, after successful build binding) creates `/tmp/oriole-empty-state-guards-study/native` once. It reuses the existing driver and exact controller/worker arithmetic, adapting only source/library/output identities and captions.

The native protocol retains all 24 real plus four generated conditions, seven pairs, seed `2026091003`, 84 fresh preflight workers and 588 timed workers: 672 workers / 106,176 samples. CPU5 preflight bound600s, CPU0 timing bound1200s, each worker90s. Construction, handlers, parsing, callbacks and destruction stay in the original measured boundary. Every adverse condition is retained; no initial/confirmation pooling. The pinned CPython3.12.13 directory must be first on PATH when root runs the existing native wrapper.

Final source binding/build/native execution remains root-owned. There is no codegen/layout campaign in these four scripts. Actual code shape, elapsed benefit and any later Python/correctness/confirmation release remain separate decisions based on completed results. No performance or selection claim is made here.
