"""Materialize reviewed held consumer sources after root releases completed native evidence."""
from pathlib import Path
import ast,hashlib,json,os,re,shutil,subprocess,sys
assert __debug__ and os.sched_getaffinity(0)=={6}
assert len(sys.argv)==3 and sys.argv[1]=='--released' and re.fullmatch(r'[0-9a-f]{40}',sys.argv[2])
runtime_commit=sys.argv[2]
P=Path(__file__).parent;held=P/'held';out=Path('/tmp/oriole-empty-state-guards-study/python');control=Path('/tmp/oriole-eager-bare-tag-position-study/python');S=Path('/tmp/oriole-empty-state-guards-preparation')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
recipe=J(P/'prepared.json')
assert recipe['status']=='held_source_preparation_ready_for_review'
for name,digest in recipe['files'].items():assert H(P/name)==digest,name
for path,digest in recipe['inputs'].items():assert H(path)==digest,path
assert H(__file__)==recipe['files']['materialize.py']
binding=J(out.parent/'build-binding.json');build=J(out.parent/'build.json');source=J(out.parent/'source.json');prepared_source=J(S/'source.json');native=J(out.parent/'native/review.json')
assert binding['status']==build['status']=='passed' and build['source_unchanged'] and build['auxiliary_unchanged']
assert binding['build_sha256']==H(out.parent/'build.json') and binding['source_manifest_sha256']==build['source_sha256']==H(out.parent/'source.json')
assert native['status']=='passed_independent_saved_normal_native_reconstruction' and native['groups']['real']['geomean_ratios']['candidate_over_control']<1
assert native['libraries']['candidate']['sha256']==binding['candidate_libraries']['liboriole_expat.so']
assert native['libraries']['control']['sha256']==binding['control_libraries']['liboriole_expat.so']
assert native['source_manifest_sha256']==H(out.parent/'source.json')
assert source['base']==binding['base']=='c8411446d5dc27a0f2c86d2bf48a71ee640cfb15'
assert binding['prepared_source_sha256']==H(S/'source.json')=='f2c2c508f56f440248d64d591cbc186965d7512f550c758aabfde0144b64d14b'
assert source['sha256']==prepared_source['sha256'] and len(source['sha256'])==74
assert set(binding['source_delta'])=={'crates/oriole/src/lib.rs','crates/oriole_expat/src/lib.rs'}
assert binding['auxiliary_files']==prepared_source['auxiliary_sha256']==J(control.parent/'build-binding.json')['auxiliary_files']
assert binding['control_libraries']['liboriole_expat.so']=='c702fda9005743ecc2d11cec3a350e4cabcf00da563699c580929cc4fc221f0f'
assert binding['complete_patch_sha256']==prepared_source['complete_patch_sha256']==H(out.parent/'candidate.patch')
W=Path(source['worktree']);git=lambda *args:subprocess.check_output(['git','-C',str(W),*args],timeout=10)
assert git('rev-parse','HEAD').decode().strip()==runtime_commit
for name,digest in {**source['sha256'],**binding['auxiliary_files']}.items():
 assert H(W/name)==digest and hashlib.sha256(git('show',runtime_commit+':'+name)).hexdigest()==digest,name
for directory,key in [(out.parent,'candidate_libraries'),(control.parent,'control_libraries')]:
 for name,digest in binding[key].items():assert H(directory/'normal'/name)==digest
assert not out.exists();out.mkdir()
for path in sorted(held.iterdir()):
 assert path.is_file()
 if path.suffix=='.py':ast.parse(path.read_text())
 shutil.copyfile(path,out/path.name)
result={'status':'source_prepared_root_execution_held','targets_executed':False,'saved_materializers_executed':True,
 'pins':{str(p):H(p) for p in sorted(out.iterdir()) if p.is_file()},
 'parent_scripts':{str(control/n):H(control/n) for n in ('run.py','python_worker.py','build_consumers.py','consumer_screen.py','prepare.py','bind.py','preflight_review.py','elapsed_review.py')},
 'selected_control_scripts':{str(control/n):H(control/n) for n in ('run.py','python_worker.py','build_consumers.py','consumer_screen.py')},
 'author_script_sha256':H(__file__),'held_preparation':{'path':str(P/'prepared.json'),'sha256':H(P/'prepared.json')},
 'build_binding_sha256':H(out.parent/'build-binding.json'),'prepared_source_sha256':binding['prepared_source_sha256'],
 'candidate_runtime_commit':runtime_commit,'candidate_source_base':binding['base'],'measured_control_commit':'19251bc01dba14cc57507facd2d607a9075471b5',
 'source_count':74,'source_delta':binding['source_delta'],'candidate_libraries':binding['candidate_libraries'],'control_libraries':binding['control_libraries'],
 'auxiliary_files':binding['auxiliary_files'],'dependency_review_sha256':binding['dependency_review_sha256'],
 'unchanged':['run.py','python_worker.py','build_consumers.py'],'reader_changes':'Study path only; full arithmetic and raw reconstruction unchanged.',
 'counts':{'conditions':24,'pairs':7,'preflight_workers':72,'timed_workers':504,'all_workers':576,'all_samples':26364},'fresh_compiles':2,'reused_compiles':4,
 'released_native_review':{'path':str(out.parent/'native/review.json'),'sha256':H(out.parent/'native/review.json')},
 'scope':'Root released saved source materialization after completed native gain; no consumer compiler/parser/preflight/timing executed. Selected eager modules become control; original normal Expat modules reused. No candidate results are fabricated.'}
with (out/'source-preparation.json').open('x') as stream:stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'source_preparation_sha256':H(out/'source-preparation.json'),'candidate_runtime_commit':runtime_commit,'libraries':binding['candidate_libraries']},indent=2))
