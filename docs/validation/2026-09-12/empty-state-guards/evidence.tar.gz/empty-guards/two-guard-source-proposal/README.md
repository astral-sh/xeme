# Empty-state guards — source-only proposal

Base: published `c8411446d5dc27a0f2c86d2bf48a71ee640cfb15`, runtime `19251bc01dba14cc57507facd2d607a9075471b5`, normal DSO `c702fda9005743ecc2d11cec3a350e4cabcf00da563699c580929cc4fc221f0f`. Unbuilt and unselected. The complete two-file patch is [proposal.patch](proposal.patch); baseline and proposed files are retained separately. No repository was modified.

## Exact change and source proof

1. **C event loop:** guard only the initial `drain_default_fragments` call in `run_events_with_frame` with `!default_pending.is_empty()`. Queue `is_empty` only compares `items.len()` and `head`; `pop_front` on an empty queue returns before mutation. The existing drain function would do no callback, allocation, drop or state mutation in this state. All subsequent destroying/error/suspend checks remain in the same order. Nonempty queues still enter the unchanged drain before another event; in particular, a removed default handler still clears/drops pending fragments, and suspension retains any tail. The busy guard pins the parser; the temporary queue borrow ends before the drain/callback. Direct draining after new fragments are queued is unchanged.
2. **Core parameter continuation:** add `active_parameter_reference.is_some()` as the first operand of the existing `if let` using a let-chain. `account_source(0)?` still happens first. `None` only avoids taking an already-empty slot. `Some` still executes the exact existing take, read-marker check, standalone decision, declaration-skip update, emission and raw publication. The take remains the `if let` scrutinee, retaining its temporary/drop scope through the body and error exits; do not replace it with an earlier destructuring `let` that could drop the owned name earlier. No callback or shared-state write occurs between the guard and take.

The full 74-file live map matches the measured source manifest; both changed baseline Git blobs also match the runtime and published base. Exact inverse replacements reproduce the originals. The guard does not change queued Event copies, detached frames, generation checks, last-position/error ordering, raw ownership, or the account_source implementation. Source references: `crates/oriole/src/lib.rs:1963`, `crates/oriole_expat/src/lib.rs:1162,1334,1348`, `crates/oriole_storage/src/queue.rs:30,39,43` in the recorded worktree.

## Current saved instruction evidence

Same-source Vulkan/Maven, namespaces off, 64 KiB feeds; existing faithful C driver, XML_Parse instruction windows, one warmup plus one measured parse. These are exact-object **self** instruction counts from the saved readback, with collected Ir (including driver) as the denominator. No callee-object or inclusive attribution is used.

| Profile | Empty drain calls | Drain + empty queue pop self Ir | Inner calls / None | Inline 88-byte copy Ir |
|---|---:|---:|---:|---:|
| vulkan-candidate-ns0 | 361,798 | 19,175,294 (2.478%) | 335,150 | 4,021,800 (0.520%) |
| maven-candidate-ns0 | 7,462 | 395,486 (3.023%) | 7,452 | 89,424 (0.684%) |

For both profiles, every observed default-drain entry followed the no-handler/empty-queue path: 33 drain self instructions plus 20 queue-pop self instructions per entry. No present-handler/nonempty path was observed. The current `next_event_inner` copies 88 bytes in 12 inline load/store instructions before testing the option; the Some branch was never reached in these two profiles. Saved disassembly and exact PCs are linked by [evidence.json](evidence.json).

These counts identify avoidable existing work, not a promised speedup. The new queue guard has its own cost, and an optimizer may still move the Option payload copy; only the actual candidate release codegen and matched elapsed runs can establish improvement. Broader wrapper self costs include necessary work. Core pending Event copies occur on observed **nonempty** paths and are left intact. The older 4815 event-dispatch proposal already identified the Option copy but was unimplemented; its historical counts and rejected whole-Event reshaping are not current evidence. This proposal adds only the current empty-drain finding to that narrow guarded-take mechanism.

## Existing regression targets (held; not run)

No new implementation-mirroring tests are proposed. The existing full workspace contains 459 Rust tests; these meaningful existing cases specifically cover the affected continuation/order contracts:

- `oriole_expat` library test `default_doctype_fragments_survive_suspension`: stops after the first default fragment, changes the handler, resumes and compares concatenated bytes with the original input.
- `oriole_expat` library test `external_grammar_keeps_early_callbacks_stop_state_and_handler_changes`: namespace off/on and six callback actions verify early/late attribute order, read/skip behavior, error/suspend/resume and handler changes.
- `oriole` integration test `external_grammar::external_grammar_commits_attributes_before_read_or_skip`: all feed widths, standalone states and Skip/Create/Empty/Nonfinal child modes verify exactly which declarations remain visible.
- `oriole` integration test `foreign_dtd::unread_foreign_dtd_preserves_prior_parameter_references`: verifies foreign request/skipped-entity counts after prior parameter references.

The current default-fragment test changes to another installed handler rather than explicitly removing it; the nonempty/no-handler clearing branch is source-byte-identical here. Existing full compatibility and allocator checks remain the parent candidate's gates. These commands are suggestions only, under the parent's existing clean Ohm environment, distinct target and shared build directory:

```sh
cargo +ohm -Zohm-defaults=no test -p oriole_expat --lib default_doctype_fragments_survive_suspension
cargo +ohm -Zohm-defaults=no test -p oriole_expat --lib external_grammar_keeps_early_callbacks_stop_state_and_handler_changes
cargo +ohm -Zohm-defaults=no test -p oriole --test external_grammar external_grammar_commits_attributes_before_read_or_skip
cargo +ohm -Zohm-defaults=no test -p oriole --test foreign_dtd unread_foreign_dtd_preserves_prior_parameter_references
```

No formatter, compiler, parser, benchmark, dependency operation, target execution or PGO work was performed for this proposal. The separately reviewed account_source wrapper split is deliberately absent and can be composed by root at its distinct source site.
