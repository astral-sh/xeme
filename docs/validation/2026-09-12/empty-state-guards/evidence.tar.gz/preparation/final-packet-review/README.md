# Held empty-state packet reader

Root may execute this saved-data reader only after assembly completes and its actual assembly.json SHA256 is supplied:

`taskset -c 6 <pinned-python> -I -S reader.py --released-assembly-sha <actual-sha256>`

Use the existing root controller timeout of 600 seconds with captured output and reaping. The reader itself runs only read-only Git calls and reviewed saved-data arithmetic; no parser, compiler, assembly, copying, Git writes or network operations.

The direct eager-reader adaptation verifies all archive member/original bytes and exclusions, both 74+4 source Git maps, 156 dependency source/license files, four separate campaigns (104 conditions / 2,496 workers / 265,080 samples / 16 adverse), raw reader arithmetic/host scope, original compatibility evidence, six confirmation table medians, exact warning/License and relative links. All four current arithmetic reader hashes are checked before their write-free prefix executes.

It permits exactly six assembled packet files and four entry documents for later installation. Four canonical document .patch sidecars stay in the evidence archive. Its receipt explicitly says installation_verified=false; root must separately verify the actual later ten-file copy. No partial or assembled packet has been read during preparation.

Final receipt: `/tmp/oriole-empty-state-guards-final-packet-independent-review.json`. Source peer review is required before root execution.
