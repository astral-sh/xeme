"""Held saved-only final packet review; no assembler, compiler or parser execution."""
from pathlib import Path, PurePosixPath
import argparse, ast, csv, difflib, hashlib, io, json, math, os, re, statistics, subprocess, tarfile
assert __debug__ and os.sched_getaffinity(0) == {6}
args=argparse.ArgumentParser()
args.add_argument('--released-assembly-sha',required=True)
args=args.parse_args()
assert re.fullmatch('[0-9a-f]{64}',args.released_assembly_sha)
D=Path('/tmp/oriole-eager-bare-tag-position-publication-preparation')
P=D/'draft/docs/validation/2026-09-12/eager-bare-tag-positions'
W=Path('/home/dev-user/code/oss/oriole-eager-bare-tag-position')
H=lambda b:hashlib.sha256(b).hexdigest()
J=lambda p:json.loads(Path(p).read_text())
assert H((D/'assembly.json').read_bytes())==args.released_assembly_sha
A=J(D/'assembly.json');I=J(P/'index.json');R=J(P/'report.json')
assert A['status']=='packet_assembled_readback_passed' and A['packet']==str(P)
assert H((D/'assemble.py').read_bytes())=='806227adf8a73f0dac7e7fd73997ea22d7529ff305dc56aa13cea602ac14d895'
assert H((P/'report.json').read_bytes())==A['report_sha256']
assert H((P/'index.json').read_bytes())==A['index_sha256']==R['evidence']['index_sha256']
assert H((P/I['archive']).read_bytes())==I['archive_sha256']==A['archive_sha256']==R['evidence']['archive_sha256']
assert (P/I['archive']).stat().st_size==I['archive_bytes']==A['bytes']==R['evidence']['archive_bytes']
assert R['decision']=='selected' and R['epochs_pooled'] is False and R['controllers_reaped'] is True
assert R['global_host_isolation_claimed'] is False
assert R['runtime_commit']=='19251bc01dba14cc57507facd2d607a9075471b5'
assert R['base_commit']=='0c407f28e2aa01178fda86a97561ed734f8d8e1d'
assert set(R['counts'])=={'conditions','workers','samples','adverse'}
assert {k:R['counts'][k] for k in ('conditions','workers','samples')}=={'conditions':104,'workers':2496,'samples':265080}
assert isinstance(R['counts']['adverse'],int) and 0<=R['counts']['adverse']<=104
for row in R['completed_reviews']+R['additional_files']:
 assert H(Path(row['path']).read_bytes())==row['sha256'],row['path']
idx={r['member']:r for r in I['members']};assert len(idx)==len(I['members'])==A['members']==R['evidence']['members']
seen=set();saved={};total=0;original_count=0
with tarfile.open(P/I['archive'],'r:gz') as archive:
 for m in archive:
  assert m.isfile() and m.name in idx and m.name not in seen
  assert not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
  b=archive.extractfile(m).read();row=idx[m.name]
  assert len(b)==m.size==row['size'] and H(b)==row['sha256']
  assert not b.startswith((b'\x7fELF',b'!<arch>\n'))
  assert not m.name.endswith(('.profraw','.profdata','.pyc','.callgrind'))
  if m.name=='source/member-map.json':
   assert row['original_path']=='generated from two verified source manifests'
  else:
   assert Path(row['original_path']).read_bytes()==b,row['original_path'];original_count+=1
  if m.name=='source/member-map.json' or m.name.startswith('dependencies/archives/'):
   saved[m.name]=b
  total+=len(b);seen.add(m.name)
assert seen==set(idx)
excluded={r['path']:r for r in I['excluded']};assert len(excluded)==len(I['excluded'])
for r in excluded.values():
 assert r['reason'] and Path(r['path']).stat().st_size==r['size']
 assert H(Path(r['path']).read_bytes())==r['sha256'],r['path']
origins={r['original_path']:r['sha256'] for r in I['members']}
def retained_pin(path,digest):
 assert origins.get(str(path),excluded.get(str(path),{}).get('sha256'))==digest,str(path)
# Each main-source map is exact; the named runtime commits contain those bytes.
source_map=json.loads(saved['source/member-map.json'])
studies={'attribute-control':Path('/tmp/oriole-attribute-lane-masks-study'),'eager':Path('/tmp/oriole-eager-bare-tag-position-study')}
commits={'attribute-control':'910387239a804a038feb0a184b1bcfc0a7dd60bf','eager':R['runtime_commit']}
assert J(studies['eager']/'build-binding.json')['tests']=={'passed':459,'groups':35,'failures':0,'ignored':0}
assert set(source_map['member_maps'])==set(source_map['sha256'])==set(studies)
assert R['source_sha256']==source_map['sha256']
for label,study in studies.items():
 manifest=J(study/'source.json');assert len(manifest['sha256'])==74
 assert source_map['sha256'][label]==manifest['sha256']
 assert set(source_map['member_maps'][label])==set(manifest['sha256'])
 for name,h in manifest['sha256'].items():
  assert idx[source_map['member_maps'][label][name]]['sha256']==h
  assert H(subprocess.check_output(['git','-C',str(W),'show',commits[label]+':'+name]))==h,name
 assert H((study/'source.json').read_bytes())==idx['source/'+label+'-manifest.json']['sha256']
auxiliary={}
assert set(source_map['auxiliary_member_maps'])==set(source_map['auxiliary_sha256'])==set(studies)
for label,study in studies.items():
 aux=J(study/'build-binding.json')['auxiliary_files']
 assert set(aux)=={'benchmarks/inprocess/Cargo.toml','benchmarks/inprocess/Cargo.lock','fuzz/Cargo.toml','fuzz/Cargo.lock'}
 assert source_map['auxiliary_sha256'][label]==aux
 assert set(source_map['auxiliary_member_maps'][label])==set(aux)
 for name,h in aux.items():
  assert idx[source_map['auxiliary_member_maps'][label][name]]['sha256']==h
  assert H(subprocess.check_output(['git','-C',str(W),'show',commits[label]+':'+name]))==h,name
 auxiliary[label]=aux
assert auxiliary['attribute-control']==auxiliary['eager']==R['auxiliary_sha256']['eager']
assert R['auxiliary_sha256']==auxiliary
assert {k for k,v in source_map['sha256']['eager'].items() if v!=source_map['sha256']['attribute-control'].get(k)}=={'crates/oriole/src/tag.rs','crates/oriole/src/lib.rs','crates/oriole/src/encoding.rs'}
assert all(source_map['sha256'][label]['Cargo.lock']==source_map['sha256']['attribute-control']['Cargo.lock'] and source_map['sha256'][label]['crates/oriole/Cargo.toml']==source_map['sha256']['attribute-control']['crates/oriole/Cargo.toml'] for label in studies)
# Dependency source membership is reconstructed from the exact checksum archives.
metadata=J('/tmp/oriole-text-simd-preparation/metadata-independent-review.json')
dep_members={};license_names={}
for package in metadata['added_packages']:
 name=package['name']+'-'+package['version'];member='dependencies/archives/'+name+'.crate'
 assert H(saved[member])==package['checksum']==idx[member]['sha256']
 count=0;licenses=[]
 with tarfile.open(fileobj=io.BytesIO(saved[member]),mode='r:gz') as archive:
  for m in archive:
   if not m.isfile():continue
   rel=PurePosixPath(m.name).relative_to(name);assert '..' not in rel.parts
   dest='dependencies/source/'+name+'/'+str(rel);data=archive.extractfile(m).read()
   assert idx[dest]['sha256']==H(data) and idx[dest]['size']==len(data)
   dep_members[dest]=H(data);count+=1
   if 'license' in rel.name.lower():licenses.append(str(rel))
 assert count==package['registry_source_files_verified'] and len(licenses)>=2
 license_names[name]=licenses
assert len(dep_members)==R['dependency_source_files']==156
assert dep_members=={r['member']:r['sha256'] for r in R['dependency_members']}
assert set(dep_members)=={n for n in idx if n.startswith('dependencies/source/')}
# Execute only unchanged, reviewed saved-data arithmetic prefixes. Cut before output.
campaigns={
 'eager-initial-native':(studies['eager']/'native','native'),
 'eager-initial-python':(studies['eager']/'python','python'),
 'eager-confirmation-native':(Path('/tmp/oriole-eager-bare-tag-position-confirmation/native'),'native'),
 'eager-confirmation-python':(Path('/tmp/oriole-eager-bare-tag-position-confirmation/python'),'python'),
}
assert set(R['epochs'])==set(campaigns)
reports={};scopes={};rows=[];worker_total=sample_total=0
for label,(folder,consumer) in campaigns.items():
 reader=folder/('read_results.py' if consumer=='native' else 'elapsed_review.py')
 text=reader.read_text();tree=ast.parse(text)
 if consumer=='native':
  cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.With) and "conditions.csv" in ast.get_source_segment(text,n))
 else:
  cut=next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='csvpath' for t in n.targets))
 prefix=ast.Module(body=tree.body[:cut],type_ignores=[])
 for n in ast.walk(prefix):
  if isinstance(n,(ast.Import,ast.ImportFrom)):
   names=[a.name for a in n.names] if isinstance(n,ast.Import) else [n.module]
   assert all(name.split('.')[0] in {'pathlib','csv','hashlib','json','math','os','random','statistics','collections','types','gzip'} for name in names),names
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute):
   assert n.func.attr not in {'write_text','write_bytes','unlink','mkdir','system','popen','Popen','check_output'},n.func.attr
 scope={'__file__':str(reader),'__name__':'independent_saved_packet_review'}
 exec(compile(prefix,str(reader),'exec'),scope)
 report=J(folder/('review.json' if consumer=='native' else 'normal-review.json'))
 assert report['reader_sha256']==H(reader.read_bytes())
 if consumer=='native':
  assert report['counts']==scope['counts'] and report['groups']==scope['groups'] and report['all_conditions']==scope['summary']
  conditions=scope['summary'];aggregates=scope['groups']
 else:
  expected=report.copy();expected.pop('condition_csv_sha256')
  assert expected==scope['report']
  conditions=scope['summaries'];aggregates=scope['aggregates']
 for path,digest in scope['pins'].items():retained_pin(path,digest)
 for row in conditions:
  c=row['condition'];ratios=row['median_ratios']
  rows.append({'campaign':label,'consumer':consumer,'project':c['name'],'chunk_bytes':c['chunk'],'namespace_or_mode':c.get('mode',str(c.get('namespaces','')).lower()),**ratios,'adverse':ratios['candidate_over_control']>1})
 entry=R['epochs'][label]
 assert entry['counts']==report['counts'] and entry['aggregates']==aggregates
 assert entry['all_conditions']==[r for r in rows if r['campaign']==label]
 assert entry['adverse_conditions']==[r for r in rows if r['campaign']==label and r['adverse']]
 worker_total+=report['counts']['all_workers'];sample_total+=report['counts']['all_samples']
 reports[label]=report;scopes[label]=scope
assert len(rows)==104 and worker_total==2496 and sample_total==265080
# Keep independent host epochs and all their pinned raw inputs distinct.
independent_epochs={}
for item in R['completed_reviews']:
 label=item['role']
 review=J(item['path']);retained_pin(item['path'],item['sha256'])
 for key in ('pins','pins_sha256','checked_inputs'):
  for path,digest in review.get(key,{}).items():retained_pin(path,digest)
 if label not in reports:continue
 assert review['counts']==reports[label]['counts']
 if campaigns[label][1]=='native':
  assert review['groups']==reports[label]['groups'] and review['all_conditions']==reports[label]['all_conditions']
  host=review['host_during'];before=review.get('prehost_observations',review.get('first_and_second_prehost_observations'))
  assert before and before[-1]['end']<=host['phase_start']
  assert all(host['phase_start']<=x['start']<x['end']<=host['phase_end'] for x in host['fully_interior_intervals'])
  independent_epochs[label]={'review_sha256':item['sha256'],'before':before,'host_during':host}
 else:
  assert review['aggregates']==reports[label]['aggregates'] and review['all_conditions']==reports[label]['summary']
  host=review['host'];phase=host['elapsed_controller'];intervals=host['sample_intervals_fully_inside_elapsed']
  before=host['before']
  assert isinstance(before,list) and before
  assert before[-1]['summary']['end']<=phase['start']
  assert all(x['summary']['end']<=y['summary']['start'] for x,y in zip(before,before[1:]))
  assert len(intervals['intervals'])==intervals['count']
  assert all(phase['start']<=x['start']<x['end']<=phase['end'] for x in intervals['intervals'])
  independent_epochs[label]={'review_sha256':item['sha256'],'host':host}
assert set(independent_epochs)==set(campaigns)
assert sum(r['adverse'] for r in rows)==R['counts']['adverse']
assert [sum(r['adverse'] for r in rows if r['campaign']==label) for label in ('eager-initial-native','eager-initial-python')]==[2,7]
assert list(csv.DictReader((P/'conditions.csv').open()))==[{k:str(v) for k,v in r.items()} for r in rows]
assert list(csv.DictReader((P/'adverse-conditions.csv').open()))==[{k:str(v) for k,v in r.items()} for r in rows if r['adverse']]
assert H((P/'conditions.csv').read_bytes())==R['evidence']['conditions_sha256']
assert H((P/'adverse-conditions.csv').read_bytes())==R['evidence']['adverse_sha256']
for row in J(D/'required-inputs.json')['expected_worker_members']:
 assert sum(n.startswith(row['prefix']) and n.endswith(row['suffix']) for n in idx)==row['count']
# Exact current correctness is separately retained, without reclassifying failures.
C=Path('/tmp/oriole-eager-bare-tag-position-correctness')
api=J(C/'api-c-readback.json');strict=J(C/'strict-semantic-readback.json')
assert R['api']==api['api']=={'ordered_configurations':4740,'counts':{'pass':4347,'fail':391,'timeout':2},'changes':[],'raw_exit':1,'original_assertions_and_limits':True}
assert R['c_consumers']==api['c_consumers'] and len(api['c_consumers'])==6 and all(x['exit']==0 for x in api['c_consumers'])
assert R['strict']==strict['strict'] and R['semantics']==strict['semantics']
assert all(x['methods']==802 and x['rendered_outcome_lines']==809 and x['raw_exit']==2 and x['changes']==[] for x in strict['strict'].values())
assert len(strict['semantics'])==2 and all(x['tests']==2 and x['exit']==0 and x['reaped'] for x in strict['semantics'])
for report in [api,strict]:
 for path,h in report['inputs'].items():retained_pin(path,h)
current_preparation=J(C/'preparation.json')
assert current_preparation['candidate_source_commit']==R['runtime_commit']
assert current_preparation['controller_origins']['strict_cpython.py']['path_substitution_only'] is False
assert len(current_preparation['controller_origins'])==9
for name,origin in current_preparation['controller_origins'].items():
 retained_pin(C/name,origin['sha256']);retained_pin(origin['origin'],origin['origin_sha256'])
for name in ['preparation.json','bound.json','pins.json','strict-pins.json']:
 retained_pin(C/name,H((C/name).read_bytes()))
# Confirmation README numbers are medians of process medians; ratios remain paired.
labels={'vulkan':'Vulkan registry','wayland':'Wayland protocol','maven':'Maven POM','batik':'Batik SVG','gtk':'GTK UI','docbook':'DocBook XSL'}
table=J(D/'table/README-table.json');assert len(table['rows'])==6
main=(D/'draft/README.md').read_text();packet_readme=(P/'README.md').read_text()
raw_results=scopes['eager-confirmation-native']['expected_rows'];table_lines=[]
for row in table['rows']:
 cohorts=sorted([x for x in raw_results if x['condition']['name']==row['project'] and x['condition']['chunk']==4096 and x['condition']['namespaces'] is False],key=lambda x:x['pair'])
 assert len(cohorts)==7 and row['chunk']==4096 and row['namespaces'] is False
 pm=[{x['engine']:x['median_seconds'] for x in c['processes']} for c in cohorts]
 assert row['process_medians_by_pair']==pm
 medians={engine:statistics.median(p[engine] for p in pm) for engine in ['candidate','control','expat']}
 ratios={k:statistics.median(p[k.split('_over_')[0]]/p[k.split('_over_')[1]] for p in pm) for k in row['median_paired_ratios']}
 assert row['median_seconds']==medians and row['median_paired_ratios']==ratios
 line=f"| {labels[row['project']]} | {medians['candidate']*1000:.3f} ms | {medians['expat']*1000:.3f} ms | {ratios['candidate_over_expat']:.3f}× |"
 assert line in main and line in (D/'table/README-table.md').read_text(),line
 table_lines.append(line)
for path,h in table['inputs'].items():retained_pin(path,h)
preserved=J(D/'README-preserved-sections.json')
assert main[main.index('> [!WARNING]'):main.index('## Highlights')]==preserved['warning']
assert main[main.index('## License'):]==preserved['license']
base=preserved['base_commit'];assert base==R['base_commit']=='0c407f28e2aa01178fda86a97561ed734f8d8e1d'
old=subprocess.check_output(['git','-C',str(W),'show',base+':README.md'],text=True)
assert old[old.index('> [!WARNING]'):old.index('## Highlights')]==preserved['warning']
assert old[old.index('## License'):]==preserved['license']
# Overlay may add only four entry docs and this new packet; historical files stay untouched.
entries={'README.md','docs/compatibility.md','docs/review.md','benchmarks/README.md'}
sidecars={name+'.patch' for name in entries}
for name in entries:
 before=subprocess.check_output(['git','-C',str(W),'show',base+':'+name],text=True)
 after=(D/'draft'/name).read_text()
 patch=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 assert (D/'draft'/(name+'.patch')).read_text()==patch,name
for f in (D/'draft').rglob('*'):
 if f.is_file():
  rel=f.relative_to(D/'draft')
  assert str(rel) in entries|sidecars or str(rel).startswith('docs/validation/2026-09-12/eager-bare-tag-positions/'),rel
for name in entries|sidecars:
 assert origins[str(D/'draft'/name)]==H((D/'draft'/name).read_bytes()),name
links=0
for doc in (D/'draft').rglob('*.md'):
 for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)',doc.read_text()):
  target=link.split('#')[0].strip('<>')
  if not target or re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',target):continue
  resolved=(doc.parent/target).resolve();assert resolved.is_relative_to(D/'draft'),(doc,target)
  relative=resolved.relative_to(D/'draft')
  if not resolved.exists() and not (W/relative).exists():
   assert subprocess.run(['git','-C',str(W),'cat-file','-e',base+':'+str(relative)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0,(doc,target)
  links+=1
assert not subprocess.check_output(['git','-C',str(W),'ls-tree','-r','--name-only',base,'--','docs/validation/2026-09-12/eager-bare-tag-positions'],text=True)
assert not subprocess.check_output(['git','-C',str(W),'diff',base,R['runtime_commit'],'--name-only','--','docs/validation'],text=True)
assert packet_readme.startswith((D/'report-README.md').read_text())
assert 'Four campaigns remain separate; no observations or medians are pooled.' in packet_readme
out={'status':'passed_independent_saved_packet_raw_source_and_docs_review','role':'Saved packet reader prepared by the agent who authored eager artifact capture/reading and confirmation adapters and reviewed source/preparation; runtime and publication assembler have a separate author. Root owns saved reader execution and all targets. Peer reviews source before execution. Only four current saved arithmetic prefixes are replayed; archive/source/dependency/table/link checks remain separate, with no recursive historical reader execution.','archive_sha256':I['archive_sha256'],'archive_bytes':I['archive_bytes'],'archive_members':len(seen),'original_byte_comparisons':original_count,'uncompressed_bytes':total,'excluded_identities':len(excluded),'source_commits':commits,'source_counts':{k:len(v) for k,v in source_map['sha256'].items()},'auxiliary_counts':{k:len(v) for k,v in auxiliary.items()},'dependency_source_files':len(dep_members),'dependency_licenses':license_names,'conditions':104,'workers':2496,'samples':265080,'adverse':R['counts']['adverse'],'epochs_pooled':False,'independent_host_epochs':independent_epochs,'campaign_counts':{k:v['counts'] for k,v in reports.items()},'adverse_by_campaign':{k:sum(r['adverse'] for r in rows if r['campaign']==k) for k in campaigns},'api':api['api'],'c_consumers':6,'strict':strict['strict'],'semantics':strict['semantics'],'readme_table_rows':6,'readme_table_lines':table_lines,'warning_and_license_exact':True,'draft_diff_sidecars_verified':4,'publication_file_scope':'Four entry docs and new packet only; the four exact Git-base diffs are evidence sidecars.','relative_links':links,'historical_validation_untouched':True,'findings':[],'reader_preparation_scope':'Adapted the already-corrected preceding attribute packet reader. Four exact documentation patch sidecars are permitted and verified against current base0c407 from the outset. No current overlay failure, packet mutation or target rerun is implied.','reader_sha256':H(Path(__file__).read_bytes()),'pins':{str(D/'assembly.json'):args.released_assembly_sha,**{str(p):H(p.read_bytes()) for p in [P/'report.json',P/'index.json',P/'README.md',P/'conditions.csv',P/'adverse-conditions.csv',D/'table/README-table.json',*(D/'draft'/n for n in entries)]}}}
dest=Path('/tmp/oriole-eager-bare-tag-position-final-packet-independent-review.json')
with dest.open('x') as f:f.write(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'receipt':str(dest),'sha256':H(dest.read_bytes()),'members':len(seen),'conditions':104,'workers':2496,'samples':265080,'adverse':R['counts']['adverse']},indent=2))
