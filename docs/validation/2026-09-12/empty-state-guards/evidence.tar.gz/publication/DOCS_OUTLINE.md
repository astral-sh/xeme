# Empty-state guards: conditional validation packet

This is an outline only. Root decides adoption after completed initial and confirmation Python/native audits; no archive, draft overlay, publication worktree or PR is installed here. Publication base is exact PR160 head `c8411446d5dc27a0f2c86d2bf48a71ee640cfb15`; measured runtime is `66ca8e0bf7d9e59412c290298d49660f12b8c26a` (two lib.rs files). PGO work remains stopped.

## Six packet files

Use the existing deterministic archive/index/member-readback implementation, with no new packaging framework, under a new `docs/validation/2026-09-12/empty-state-guards/` destination. Require the destination to be absent before copying; preserve historical packets.

1. `README.md`: what the three guards skip, four separate campaign summaries, observed host context, all adverse-row link, correctness limits and remaining 1.10× Expat goal.
2. `report.json`: exact source/build/library/runtime provenance, phase receipts, raw counts, each independent audit and pending/complete state.
3. `conditions.csv`: every condition in each epoch, all paired-median ratios and exact campaign labels. Expected104 rows after all four campaigns complete.
4. `adverse-conditions.csv`: derive every candidate/control ratio above1 directly from those104 rows. Count is pending; never preselect favorable rows or drop generated cases.
5. `index.json`: every archived member's original path, byte length and SHA256; indexed exclusions retain executable/library identities.
6. `evidence.tar.gz`: compact raw sources, compiler/command logs, workers and origins, audit scripts/receipts and host records. No ELF/static libraries, compiler profile data, machine config or shared build cache.

## Inventory and source scope

- Two exact source maps, current control19251 carried by PR160 and candidate66ca:74 main files +4 auxiliary files each. Deduplicate identical byte payloads and retain both member maps, Git blob/commit bindings and candidate.patch. Dependencies are unchanged; use the existing156-file dependency provenance and licenses, without a new resolution or build.
- Current `/tmp/oriole-empty-state-guards-preparation` and study ordinary seven-command build/check receipts:459 tests across35 groups; same compiler vectors and actual SO/A hashes, independently replayed. Include root and independent actual-codegen receipts, raw bounded disassembly/tool outputs and their frozen scripts. Branch evidence establishes emitted code only; do not claim causal elapsed savings or object-layout changes.
- Initial native + initial Python and confirmation native + confirmation Python each retain their own preparation, controller, preflight, raw worker/sample, canonical/origin, CSV, primary and independent receipts. Expected total after completion:104 conditions,2,496 workers,265,080 samples. Initial/confirmation remain separate with no pooling, favorable-epoch selection or significance claim.
- Python keeps initial two fresh/four reused compile provenance distinct from confirmation zero fresh/six reused modules. Archive compiler logs and actual unmodified CPython sources/header/interpreter identities, preserving original module/library paths and hashes while excluding binary payloads. Keep the selected original native driver source/identity and corpus manifests/licenses.
- Before/during host observations for each elapsed phase, monitor/observation scripts and raw counters. Report idle+iowait using fully interior intervals and coverage; retain crossing intervals without interpolation. No global/exclusive-host or per-condition attribution claim.
- Current API/C and strict/semantic raw controller/source/origin/compiler/log records and independent audits: original4,740 API outcomes unchanged (4,347 pass/391 fail/2 timeout), six C consumers;802 strict method identities/809 rendered lines per linkage with two unchanged failures/raw2; two supplemental tests per linkage. Validate final receipt hashes before populating a report. C ASan/UBSan harnesses link uninstrumented Rust libraries and disable leak checking; strict CPython has the pinned cleanup backport, benchmark consumers remain unmodified.
- Preserve source-writer/check attempt notes and original frozen variants compactly. No current fuzz/PBS, installed-artifact or new-platform result is inferred from past reports.

## Conditional entry-doc overlay

Only after final decision, prepare four entry docs against the exact PR160 Git tree: root README, benchmarks/README.md, docs/compatibility.md and docs/review.md. Keep root README warning and License text byte-identical, historical report links intact, and benchmark method/hardware/compiler context explicit. Current main table should use confirmation native six pinned projects at4KiB/namespaces off: median of seven process medians for absolute columns and median of seven paired ratios for ratio columns, with exactly126 worker records. Never divide aggregate displayed medians to invent paired ratios.

Name confirmation as the selected display epoch only after root selects it, alongside initial results and every adverse row. State how far each measured aggregate remains from1.10× Expat. Keep CI pending until the actual published commit's ordinary jobs complete; no dispatch/retry, PGO or PBS trigger is introduced.

## Final saved review

Bind a concrete release to the completed primary/independent hashes, archive once after all elapsed processes have reaped, and read back every indexed member and original byte match. Independently reconstruct all104 condition ratios/counts, all adverse rows and six table medians; verify both78-file maps against Git blobs, relative doc links, exact base warning/license and absent destination. Four generated `.md.patch` sidecars are review artifacts in the raw archive only; install only four entry docs plus six packet files. Root owns publication and CI monitoring.

## Prepared overlay

Four drafts compare against PR160 `c8411446d5dc27a0f2c86d2bf48a71ee640cfb15`. Current confirmation Python/table/decision fields retain explicit pending markers. Prior eager results are scoped to the eager source; historical reports remain. The assembler rejects pending entry documents and requires root-released final review hashes.

## Completion

Root selected66ca after all four epochs and compatibility reviews completed. Final drafts contain all16 adverse rows by reference and final confirmation table/ratios; assembly still requires root release.
