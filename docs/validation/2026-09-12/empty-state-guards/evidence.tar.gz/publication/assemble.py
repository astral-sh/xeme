"""Archive completed empty-state guard evidence with the existing namespace packet recipe.

Held until root releases saved-data assembly after both confirmation controllers
and independent readers finish. This script never executes a parser or compiler.
"""
from pathlib import Path
import csv, gzip, hashlib, io, json, os, sys, tarfile

assert __debug__ and os.sched_getaffinity(0) == {6}
assert sys.argv[1:] == ['--released'], 'Root must release completed saved-data assembly'
PREP = Path(__file__).parent
DRAFT = PREP / 'draft'
PUBLICATION = 'docs/validation/2026-09-12/empty-state-guards'
OUT = DRAFT / PUBLICATION
STUDY = Path('/tmp/oriole-empty-state-guards-study')
CONTROL = Path('/tmp/oriole-eager-bare-tag-position-study')
CONF = Path('/tmp/oriole-empty-state-guards-confirmation')
CORRECT = Path('/tmp/oriole-empty-state-guards-correctness')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert not OUT.exists()
inventory = read(PREP / 'required-inputs.json')
final = read(PREP / 'final-publication.json')
assert final['status'] == 'root_released_completed_results'
assert final['publication_path'] == PUBLICATION
assert final['runtime_commit'] == '66ca8e0bf7d9e59412c290298d49660f12b8c26a'
assert final['base_commit'] == 'c8411446d5dc27a0f2c86d2bf48a71ee640cfb15'
assert final['epochs_pooled'] is False
assert final['controllers_reaped'] is True and final['global_host_isolation_claimed'] is False
assert final['decision'] in {'selected', 'rejected'}
assert all(row['sha256'] == sha(row['path']) for row in final['completed_reviews'])
assert {row['role'] for row in final['completed_reviews']} >= {'empty-guards-initial-native', 'empty-guards-initial-python', 'empty-guards-confirmation-native', 'empty-guards-confirmation-python', 'empty-guards-correctness', 'source-commit-binding'}
for row in inventory['pinned_files']:
    assert sha(row['path']) == row['sha256'], row['path']
for row in final['additional_files']:
    assert isinstance(row['member'], str) and row['member'], row
    assert sha(row['path']) == row['sha256'], row['path']

reports = {
    'empty-guards-initial-native': read(STUDY / 'native/review.json'),
    'empty-guards-initial-python': read(STUDY / 'python/normal-review.json'),
    'empty-guards-confirmation-native': read(CONF / 'native/review.json'),
    'empty-guards-confirmation-python': read(CONF / 'python/normal-review.json'),
}
for label, report in reports.items():
    expected = 576 if label.endswith('python') else 672
    assert report['counts']['all_workers'] == expected
    assert report['counts']['all_samples'] == (26364 if label.endswith('python') else 106176)
assert read(STUDY / 'build-binding.json')['tests'] == {'passed': 459, 'groups': 35, 'failures': 0, 'ignored': 0}
api = read(CORRECT / 'api-c-readback.json')
strict = read(CORRECT / 'strict-semantic-readback.json')
assert api['api'] == {'ordered_configurations': 4740, 'counts': {'pass': 4347, 'fail': 391, 'timeout': 2}, 'changes': [], 'raw_exit': 1, 'original_assertions_and_limits': True}
assert len(api['c_consumers']) == 6 and all(x['exit'] == 0 for x in api['c_consumers'])
assert set(strict['strict']) == {'shared', 'static'}
assert all(x['methods'] == 802 and x['rendered_outcome_lines'] == 809 and x['raw_exit'] == 2 and x['changes'] == [] for x in strict['strict'].values())
assert len(strict['semantics']) == 2 and all(x['tests'] == 2 and x['exit'] == 0 and x['reaped'] for x in strict['semantics'])
preserved = read(PREP / 'README-preserved-sections.json')
readme = (DRAFT / 'README.md').read_text()
for name in ['README.md', 'docs/compatibility.md', 'docs/review.md', 'benchmarks/README.md']:
    assert '[PENDING:' not in (DRAFT / name).read_text(), name
assert '[PENDING:' not in (PREP / 'report-README.md').read_text()
assert readme[readme.index('> [!WARNING]'):readme.index('## Highlights')] == preserved['warning']
assert readme[readme.index('## License'):] == preserved['license']
assert all((DRAFT / name).is_file() for name in ['docs/compatibility.md', 'docs/review.md', 'benchmarks/README.md'])

# BEGIN EXISTING NAMESPACE ADD/TREE HELPERS
entries, originals, excluded, pins = {}, {}, {}, {}
def add_data(data, member, original):
    assert member not in entries, member
    assert not data.startswith((b'\x7fELF', b'!<arch>\n')), original
    entries[member], originals[member] = data, str(original)
def add(path, member):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert path.suffix not in {'.pyc','.profraw','.profdata','.a','.so'}, path
    add_data(path.read_bytes(), member, path)
def is_external(path):
    path = Path(path)
    if path.suffix in {'.pyc','.profraw','.profdata','.a','.so'} or '.so.' in path.name:
        return True
    with path.open('rb') as f: return f.read(8).startswith((b'\x7fELF',b'!<arch>\n'))
def exclude(path, reason):
    path=Path(path)
    row={'path':str(path),'sha256':sha(path),'size':path.stat().st_size,'reason':reason}
    if str(path) in excluded:
        previous=excluded[str(path)]
        assert all(previous[k]==row[k] for k in ('path','sha256','size')),path
        return
    excluded[str(path)]=row
def tree(root,prefix):
    root=Path(root);assert root.is_dir(),root
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts: continue
        if is_external(path): exclude(path,'Executable/library/bytecode/compiler-profile identity only')
        elif path.is_symlink(): raise AssertionError(f'unexpected nonbinary symlink: {path}')
        else: add(path,prefix+'/'+str(path.relative_to(root)))
def pin_map(values):
    for path,digest in values.items():
        assert isinstance(digest,str) and len(digest)==64,(path,digest)
        assert path not in pins or pins[path]==digest,path
        pins[path]=digest

# END EXISTING NAMESPACE ADD/TREE HELPERS

source_maps, source_hashes, auxiliary_maps, auxiliary_hashes, dedup = {}, {}, {}, {}, {}
for label, study in [('eager-control', CONTROL), ('empty-guards', STUDY)]:
    source = read(study / 'source.json')
    assert len(source['sha256']) == 74
    mapping = {}
    for name, digest in source['sha256'].items():
        path = Path(source['worktree']) / name
        assert sha(path) == digest, path
        if (name, digest) not in dedup:
            member = 'source/' + label + '/' + name
            add(path, member)
            dedup[name, digest] = member
        mapping[name] = dedup[name, digest]
    source_maps[label], source_hashes[label] = mapping, source['sha256']
    add(study / 'source.json', 'source/' + label + '-manifest.json')
    auxiliary = read(study / 'build-binding.json')['auxiliary_files']
    assert len(auxiliary) == 4
    auxiliary_maps[label], auxiliary_hashes[label] = {}, auxiliary
    for name, digest in auxiliary.items():
        path = Path(source['worktree']) / name
        assert sha(path) == digest, path
        if (name, digest) not in dedup:
            member = 'source/' + label + '-auxiliary/' + name
            add(path, member)
            dedup[name, digest] = member
        auxiliary_maps[label][name] = dedup[name, digest]
assert auxiliary_hashes['eager-control'] == auxiliary_hashes['empty-guards']
assert set(n for n, h in source_hashes['empty-guards'].items() if source_hashes['eager-control'][n] != h) == {'crates/oriole/src/lib.rs', 'crates/oriole_expat/src/lib.rs'}
add_data((json.dumps({'member_maps': source_maps, 'sha256': source_hashes,
    'auxiliary_member_maps': auxiliary_maps, 'auxiliary_sha256': auxiliary_hashes,
    'scope': 'Two source identities, each74 main plus4 unchanged auxiliary files. Equal bytes stored once. Empty-state guards change only corelib and adapterlib. Dependencies and selected scanners remain unchanged. No future arena or compact-owner proposal is part of either measured source.'}, indent=2) + '\n').encode(),
    'source/member-map.json', 'generated from two verified source manifests')
for name in inventory['license_files']:
    add(Path(inventory['license_root']) / name, 'source/licenses/' + name)

for row in inventory['trees']:
    tree(row['path'], row['member'])
for row in inventory['top_level_directories']:
    for path in sorted(Path(row['path']).iterdir()):
        if path.is_file():
            if is_external(path):
                exclude(path, 'External binary or compiler profile; identity only')
            else:
                add(path, row['member'] + '/' + path.name)
for row in inventory['pinned_files'] + final['additional_files']:
    add(row['path'], row['member'])
for row in final['completed_reviews']:
    if str(row['path']) not in originals.values():
        add(row['path'], 'reviews/final/' + Path(row['path']).name)

# Include exactly the three checksum-pinned dependency archives and all156
# original source bytes (including licenses); no whole registry/cache tree.
metadata = read('/tmp/oriole-text-simd-preparation/metadata-independent-review.json')
dependency_members = []
verified = 0
for package in metadata['added_packages']:
    crate_name = package['name'] + '-' + package['version']
    candidates = [(p, h) for p, h in metadata['registry_source_and_archive_pins'].items() if Path(p).name == crate_name + '.crate']
    assert len(candidates) == 1
    archive_path, digest = candidates[0]
    assert sha(archive_path) == digest == package['checksum']
    add(archive_path, 'dependencies/archives/' + Path(archive_path).name)
    root = Path(package['manifest']).parent
    count = 0
    with tarfile.open(archive_path, 'r:gz') as archive:
        for entry in archive.getmembers():
            if not entry.isfile():
                continue
            rel = Path(entry.name).relative_to(crate_name)
            assert '..' not in rel.parts
            original = root / rel
            data = archive.extractfile(entry).read()
            assert original.read_bytes() == data
            member = 'dependencies/source/' + crate_name + '/' + str(rel)
            add_data(data, member, original)
            dependency_members.append({'member': member, 'original_path': str(original), 'sha256': sha(original)})
            count += 1
    assert count == package['registry_source_files_verified']
    verified += count
assert verified == 156

# Retain raw readers' exact input maps. Referenced old campaigns are identities,
# not additional benchmark epochs. Explicit current trees above retain all raws.
pin_reports = list(reports.values()) + [api, strict]
pin_reports += [read(row['path']) for row in final['completed_reviews']]
for report in pin_reports:
    for key in ['inputs', 'pins', 'evidence_sha256', 'pins_sha256', 'checked_inputs']:
        if key in report:
            pin_map(report[key])
for study, relative in [(STUDY, 'native/native-screen'), (STUDY, 'python/screen'), (CONF, 'native/native-screen'), (CONF, 'python/screen')]:
    result = read(study / relative / 'results.json')
    assert result['hashes_before'] == result['hashes_after']
    pin_map(result['hashes_before'])
corpus = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
add(corpus, 'inputs/corpus-manifest.json')
for project in read(corpus)['projects']:
    for item in project['files']:
        path = corpus.parent / item['path']
        assert sha(path) == item['sha256']
        add(path, 'inputs/' + item['path'])
for path, member in [('/tmp/oriole-grammar-bench-plain/entities.xml', 'inputs/generated/entities.xml'), ('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml', 'inputs/generated/rare-declarations.xml')]:
    add(path, member)
archived_paths = set(originals.values())
for path, digest in sorted(pins.items()):
    p = Path(path)
    assert sha(p) == digest, p
    if path in archived_paths:
        continue
    machine_config = p.name in {'config', 'config.toml'} and '.cargo' in p.parts
    old_worker = ('/worker-' in path or '/screen/' in path or '/native-screen/' in path) and not any(path.startswith(str(d) + '/') for d in (STUDY, CONF, CORRECT))
    old_packet = p.name in {'evidence.tar.gz', 'records.tar.gz'} and not any(path.startswith(str(d) + '/') for d in (STUDY, CONF, CORRECT))
    if old_packet:
        exclude(p, 'Inherited historical publication archive identity; current raw records are archived separately')
    elif old_worker:
        exclude(p, 'Inherited prior campaign input identity; outside the four measured campaigns')
    elif is_external(p) or machine_config:
        exclude(p, 'External executable/library/compiler-profile or machine configuration; audited identity retained')
    else:
        add(p, 'other-pinned-inputs/' + path.lstrip('/'))
for row in inventory['expected_worker_members']:
    actual = sum(n.startswith(row['prefix']) and n.endswith(row['suffix']) for n in entries)
    assert actual == row['count'], (row, actual)
assert not any(n.endswith('.callgrind') for n in entries)

conditions = []
for campaign, report in reports.items():
    consumer = 'python' if campaign.endswith('python') else 'native'
    for row in report['summary' if consumer == 'python' else 'all_conditions']:
        c, ratios = row['condition'], row['median_ratios']
        conditions.append({'campaign': campaign, 'consumer': consumer, 'project': c['name'],
            'chunk_bytes': c['chunk'], 'namespace_or_mode': c.get('mode', str(c.get('namespaces', '')).lower()),
            **ratios, 'adverse': ratios['candidate_over_control'] > 1})
assert len(conditions) == 104
adverse = [row for row in conditions if row['adverse']]
assert sum(x['counts']['all_workers'] for x in reports.values()) == 2496
assert sum(x['counts']['all_samples'] for x in reports.values()) == 265080
for name in ['required-inputs.json', 'REQUIRED_INPUTS.md', 'DOCS_OUTLINE.md', 'README-preserved-sections.json', 'final-publication.json', 'report-README.md', 'assemble.py', 'prior-assemble.py', 'prepared.json', 'source-adaptation.json', 'pr-body.draft.md']:
    add(PREP / name, 'publication/' + name)
for path in sorted(DRAFT.rglob('*')):
    if path.is_file():
        add(path, 'publication/draft/' + str(path.relative_to(DRAFT)))
OUT.mkdir(parents=True)
for name, rows in [('conditions.csv', conditions), ('adverse-conditions.csv', adverse)]:
    with (OUT / name).open('x', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)

# BEGIN EXISTING NAMESPACE DETERMINISTIC ARCHIVE/READBACK
members=[]
with (OUT/'evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for member,data in sorted(entries.items()):
                info=tarfile.TarInfo(member);info.size,info.mode,info.mtime=len(data),0o644,0
                archive.addfile(info,io.BytesIO(data))
                members.append({'member':member,'original_path':originals[member],'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive_path=OUT/'evidence.tar.gz'
with tarfile.open(archive_path,'r:gz') as archive:
    actual=archive.getmembers();assert [m.name for m in actual]==[r['member'] for r in members]
    for member,row in zip(actual,members,strict=True):
        assert member.isfile() and member.size==row['size']
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==row['sha256']
for member,path in originals.items():
    if path.startswith('/'):
        assert Path(path).read_bytes()==entries[member],path
index={'schema':'saved-record-bundle-v1','archive':'evidence.tar.gz','archive_sha256':sha(archive_path),'archive_bytes':archive_path.stat().st_size,'archive_readback_passed':True,'members':members,'excluded':list(excluded.values())}
(OUT/'index.json').write_text(json.dumps(index,indent=2)+'\n')

# END EXISTING NAMESPACE DETERMINISTIC ARCHIVE/READBACK

epochs = {}
for campaign, report in reports.items():
    rows = [r for r in conditions if r['campaign'] == campaign]
    epochs[campaign] = {'counts': report['counts'], 'aggregates': report.get('groups', report.get('aggregates')),
        'all_conditions': rows, 'adverse_conditions': [r for r in rows if r['adverse']]}
report = final | {'schema': 'completed_empty_state_guards_evidence_v1',
    'counts': {'conditions': 104, 'workers': 2496, 'samples': 265080, 'adverse': len(adverse)},
    'epochs': epochs, 'source_member_map': 'source/member-map.json',
    'source_sha256': source_hashes, 'auxiliary_sha256': auxiliary_hashes, 'dependency_source_files': verified,
    'dependency_members': dependency_members, 'api': api['api'], 'c_consumers': api['c_consumers'],
    'strict': strict['strict'], 'semantics': strict['semantics'],
    'evidence': {'archive_sha256': sha(archive_path), 'archive_bytes': archive_path.stat().st_size,
        'members': len(members), 'index_sha256': sha(OUT / 'index.json'), 'readback_passed': True,
        'conditions_sha256': sha(OUT / 'conditions.csv'), 'adverse_sha256': sha(OUT / 'adverse-conditions.csv')}}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
body = (PREP / 'report-README.md').read_text()
body += f'\n## Raw evidence\n\n[evidence.tar.gz](evidence.tar.gz) contains {len(members):,} indexed files ({archive_path.stat().st_size:,} compressed bytes). [index.json](index.json) records each member hash, original path, size and excluded artifact identity. Every member and original byte was read back. [conditions.csv](conditions.csv) retains all 104 conditions, and [adverse-conditions.csv](adverse-conditions.csv) retains all {len(adverse)} adverse rows. Four campaigns remain separate; no observations or medians are pooled. [report.json](report.json) retains full precision.\n\nArchive SHA-256: `{sha(archive_path)}`. Libraries, binaries, compiler profiles, unrelated historical worker records and machine configuration are excluded. Rebuilding the pinned sources does not promise byte-identical compiler output. Original readers use historical absolute paths; the member index maps archived inputs to their original names, and excluded artifact checks still require separately retained exact files.\n'
(OUT / 'README.md').write_text(body)
result = {'status': 'packet_assembled_readback_passed', 'packet': str(OUT),
    'archive_sha256': sha(archive_path), 'members': len(members), 'bytes': archive_path.stat().st_size,
    'report_sha256': sha(OUT / 'report.json'), 'index_sha256': sha(OUT / 'index.json')}
(PREP / 'assembly.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2), flush=True)
