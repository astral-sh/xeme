| Project XML | Oriole (normal) | Expat (normal) | Oriole / Expat |
| --- | ---: | ---: | ---: |
| Vulkan registry | 42.999 ms | 28.767 ms | 1.500× |
| Wayland protocol | 0.996 ms | 1.076 ms | 0.929× |
| Maven POM | 0.710 ms | 0.438 ms | 1.622× |
| Batik SVG | 0.129 ms | 0.134 ms | 0.961× |
| GTK UI | 0.296 ms | 0.216 ms | 1.375× |
| DocBook XSL | 0.247 ms | 0.191 ms | 1.295× |

