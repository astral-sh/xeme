"""Derive six README rows from this confirmation epoch's 126 raw workers only."""
from pathlib import Path
import hashlib,json,math,os,random,statistics
assert __debug__ and os.sched_getaffinity(0)=={6}
P=Path(__file__).parent
N=Path('/tmp/oriole-empty-state-guards-confirmation/native');S=N/'native-screen'
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text())
primary_path=N/'review.json';independent_path=Path('/tmp/oriole-empty-state-guards-confirmation-independent-native-raw-review.json')
assert H(primary_path)=='f49c7717e3c9e5ae8edac224f79023a8d659566e5aaa63e4e1e1e7c80a4d71d2'
assert H(independent_path)=='a39d47f322e129ddd3d5f0cbf072835479f89f52951b9f3a31fdd14cf2a26896'
primary=J(primary_path);independent=J(independent_path);protocol=J(S/'protocol.json')
assert primary['all_conditions']==independent['all_conditions'] and primary['counts']==independent['counts']
assert primary['inputs'][str(S/'protocol.json')]==H(S/'protocol.json')
assert primary['libraries']==protocol['libraries'] and protocol['pairs']==7 and protocol['seed']==2026091003
names=['vulkan','wayland','maven','batik','gtk','docbook'];labels=['Vulkan registry','Wayland protocol','Maven POM','Batik SVG','GTK UI','DocBook XSL']
selected={r['condition']['name']:r for r in primary['all_conditions'] if r['condition']['name'] in names and r['condition']['chunk']==4096 and r['condition']['namespaces'] is False}
assert set(selected)==set(names)
rng=random.Random(protocol['seed']);jobs=[(c,pair) for c in protocol['conditions'] for pair in range(7)];rng.shuffle(jobs)
by_project={n:{} for n in names};inputs={};observations={};ordinal=84
for condition,pair in jobs:
 order=['control','candidate','expat'];rng.shuffle(order)
 for engine in order:
  path=S/f'worker-{ordinal:04d}.json';ordinal+=1
  if condition['name'] not in names or condition['chunk']!=4096 or condition['namespaces']:continue
  data=J(path);inputs[str(path)]=H(path)
  assert data['condition']==condition and data['pair']==pair and data['engine']==engine and data['returncode']==0 and data['stderr']==''
  assert data['command']==['taskset','-c','0','/tmp/oriole-grammar-bench-plain/native-driver',protocol['libraries'][engine]['path'],condition['input'],'4096',str(condition['iterations'])]
  parsed=json.loads(data['stdout']);assert parsed['version']==('expat_2.8.4' if engine=='expat' else 'oriole_compat_2.8.4')
  samples=parsed['samples'];assert len(samples)==condition['iterations']+1
  assert [s['iteration'] for s in samples]==list(range(len(samples))) and [s['warmup'] for s in samples]==[True]+[False]*condition['iterations']
  assert all(math.isfinite(s['seconds']) and s['seconds']>0 for s in samples)
  observed={(s['hash'],s['elements'],s['text_bytes']) for s in samples};assert len(observed)==1
  observations.setdefault(condition['name'],observed);assert observations[condition['name']]==observed
  pair_values=by_project[condition['name']].setdefault(pair,{})
  assert engine not in pair_values;pair_values[engine]=statistics.median(s['seconds'] for s in samples[1:])
assert ordinal==672 and len(inputs)==126
rows=[]
for name in names:
 assert sorted(by_project[name])==list(range(7))
 pairs=[by_project[name][pair] for pair in range(7)];assert all(set(p)=={'candidate','control','expat'} for p in pairs)
 ratios={key:[p[key.split('_over_')[0]]/p[key.split('_over_')[1]] for p in pairs] for key in ['candidate_over_control','candidate_over_expat','control_over_expat']}
 medians={key:statistics.median(values) for key,values in ratios.items()}
 assert medians==selected[name]['median_ratios']
 assert all(sorted(values)==sorted(selected[name]['paired_ratios'][key]) for key,values in ratios.items())
 rows.append({'project':name,'chunk':4096,'namespaces':False,'median_seconds':{e:statistics.median(p[e] for p in pairs) for e in ['candidate','control','expat']},'median_paired_ratios':medians,'process_medians_by_pair':pairs})
for p,h in inputs.items():assert H(p)==h
result={'status':'verified_six_readme_rows_from_confirmation_raw','targets_executed':False,'scope':'Confirmation only. Each time is median of seven process medians after discarding warmup. Each ratio is median of seven within-pair ratios, computed separately. Arrays sorted pair0..6; primary retains randomized encounter order. Exactly126 raw workers; no pooled epochs.','rows':rows,'inputs':inputs,'native_review':{'path':str(primary_path),'sha256':H(primary_path)},'independent_review':{'path':str(independent_path),'sha256':H(independent_path)}}
with (P/'README-table.json').open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
lines=['| Project XML | Oriole (normal) | Expat (normal) | Oriole / Expat |','| --- | ---: | ---: | ---: |']
for label,row in zip(labels,rows,strict=True):lines.append(f"| {label} | {row['median_seconds']['candidate']*1000:.3f} ms | {row['median_seconds']['expat']*1000:.3f} ms | {row['median_paired_ratios']['candidate_over_expat']:.3f}× |")
with (P/'README-table.md').open('x') as f:f.write('\n'.join(lines)+'\n\n')
paths=[Path(__file__),primary_path,independent_path,S/'protocol.json',P/'README-table.json',P/'README-table.md']
with (P/'pins.json').open('x') as f:f.write(json.dumps({str(p):H(p) for p in paths}|inputs,indent=2)+'\n')
print(json.dumps({'status':result['status'],'rows':6,'raw_workers':len(inputs),'table_sha256':H(P/'README-table.json'),'markdown_sha256':H(P/'README-table.md'),'pins_sha256':H(P/'pins.json')}))
