Skip empty accounting and event-state work on the common parser path, preserving populated branches and accounting atomics. The three guards change two files on PR160.

[PENDING: final root decision, confirmation ratios/adverse scope and packet link]

Validation:459 Rust tests; original4,740 API rows and802 strict methods/linkage unchanged;6 C consumers and both supplemental semantic tests/linkage pass. Known API/strict failures remain. The roughly10% Expat goal remains open.

Stacked on #160.
