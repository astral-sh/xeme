# Empty-state guards: normal build

[PENDING: root selection and completed confirmation Python audit]

Runtime `66ca8e0bf7d9e59412c290298d49660f12b8c26a` changes three guards in two files on PR160 `c8411446`. Zero-byte accounting returns before the unchanged nonzero body; an absent parameter reference avoids an owned `take`; an empty default queue avoids its initial drain. Nonzero accounting, atomics, populated branches, callbacks and later drains retain their behavior. Two source maps bind all 74 main and four auxiliary files; dependencies remain unchanged.

## Measurements

| Epoch | Real native / control | Native / Expat | Python / control | Python / Expat |
|---|---:|---:|---:|---:|
| Initial | 0.9930287054 | 1.3472694249 | 0.9895371443 | 1.1334602085 |
| Confirmation | 0.9913705647 | 1.3443341722 | [PENDING: ratio] | [PENDING: ratio] |

Initial native improves in 19/24 real conditions and all four generated conditions (generated ratio 0.9350972744). Its five adverse real rows remain. Initial Python improves in 20/24 conditions, with four adverse rows. Confirmation native improves in 22/24 real conditions and all four generated conditions (0.9393145413); Wayland with namespaces on regresses 0.9059% at 4 KiB and 0.6938% at 64 KiB. [PENDING: confirmation Python/all adverse counts and six-row table]

The 104 conditions, 2,496 workers and 265,080 samples belong to four separate campaigns. Each retains seven seeded pairs, original worker/count/digest/origin checks and complete adverse rows. Initial Python builds two unmodified CPython candidate extensions with GCC -O2 and reuses four control/Expat extensions. Confirmation reuses all six and performs fresh preflights; it compiles no modules. Native uses the same existing driver. Parser construction, GC/destruction and timed boundaries remain unchanged. Normal Oriole uses local Ohm rustc 1.98.1-dev, generic -O3/ThinLTO/codegen-units=1; normal Expat 2.8.4 uses GCC 13.3 -O3 without LTO. No PGO work or per-candidate CPU flags occurred.

Host observations describe shared Linux AMD EPYC-Milan measurements pinned to CPU0. Affinity and idle+iowait fractions establish neither OS isolation nor statistical significance. Initial fully interior other-CPU idle+iowait is 95.61% native and 96.52% Python; confirmation native is 93.48%, covering 90.0243 of 90.4986 seconds. [PENDING: confirmation Python host attribution]

## Validation and limits

All 459 Rust tests across 35 groups, formatting and Clippy pass. Original 4,740 API rows remain identical: 4,347 passes, 391 assertion failures, two timeouts. Six C consumers pass. Both strict linkages preserve 802 methods, 809 rendered outcomes and two known callback-fragmentation failures (raw exit 2); both existing supplemental semantic tests pass per linkage. Strict CPython consumers include the explicit upstream cleanup backport; timed consumers are unmodified. C ASan/UBSan harnesses use uninstrumented Rust and disable leak detection. Current-source sustained fuzzing, installed PBS validation and production readiness are not established. The roughly 1.10× Expat goal remains open.

Saved assembly confirms the three guards precede the avoided calls/copies, while nonzero accounting atomics and later default draining remain. Symbol sizes are machine-code sizes only; these static observations provide no frequency, layout or causal elapsed-time claim.

Root ran all build, parser, profiler-free benchmark and compatibility targets and primary readers. The coordinate agent authored these pipeline adaptations, independently reconstructed saved raw outputs and host counters, and authored this packet preparation; peers reviewed source/protocol scripts. Root and the separate packet reviewer perform final release/readback. No historical performance, installed/PBS or sanitizer result is relabeled as this source.
