Skip work when source accounting has no new bytes, the active parameter reference is absent, or the initial default-event queue is empty. We preserve the populated paths, accounting atomics and callback ownership.

Two separate normal-build epochs observe 0.70–0.86% less real-project native time and 0.90–1.05% less CPython time against PR160. Confirmation remains at 1.3443× Expat for native parsing and 1.1372× for CPython, so the roughly 1.10× goal remains open. The report retains all 104 conditions and 16 adverse rows across both epochs; these small shared-host gains are not significance claims.

All 459 Rust tests pass. The original 4,740 API configurations and 802 strict methods per linkage retain their outcomes, including known failures; six C consumers and both supplemental semantic tests per linkage pass. The new [evidence packet](docs/validation/2026-09-12/empty-state-guards/) includes source/build binding, raw workers and origins, host counters and independent reviews.

Stacked on #160.
