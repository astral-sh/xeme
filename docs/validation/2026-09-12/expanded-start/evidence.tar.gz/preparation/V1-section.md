# Expanded namespace Start — V1 draft

V1 reduces copying and owned attribute reconstruction for eligible namespace Start callbacks. Its normal-build measurements improve the real native aggregate by **2.00%** and unmodified CPython aggregate by **2.10%** relative to selected runtime 4064. The measured aggregate remains above the 1.10× Expat target. This section reports V1 only; it does not select V2 or claim production readiness.

The change expands a native literal element name into a detached Start frame when ordinary attributes are unprefixed, no namespace declarations are present, and existing 4KiB/128-attribute bounds permit it. It preserves packed stack-name ownership, generic fallback, URI resource charging and callback publication order. Commit `8c039ec6` contains the frozen four-file V1 delta; the build manifest binds all 73 source/input files.

## Measurements

Linux AMD EPYC-Milan; normal O3/ThinLTO/one-codegen-unit Oriole builds with Ohm rustc 1.98.1-dev (LLVM 22.1.8), and Expat 2.8.4 GCC 13.3 O3 without LTO. Both workloads use original XML from Vulkan, Wayland, Maven, Batik, GTK and DocBook, with 4KiB/64KiB feeds. Native tests add namespace off/on and four generated conditions. CPython 3.12.13 uses identical unmodified O2 `pyexpat` and `_elementtree` extensions. These are parser workloads on project XML, not whole-project execution.

| Group | V1 / selected | V1 / Expat | Faster than selected |
| --- | ---: | ---: | ---: |
| Native real projects | 0.980018× | 1.565630× | 9/24 |
| Native, namespaces enabled | 0.958005× | 1.631247× | 5/12 |
| Native, namespaces disabled | 1.002538× | 1.502652× | 4/12 |
| Native generated controls | 0.978290× | 4.001900× | 4/4 |
| Python, all | 0.979029× | 1.241269× | 13/24 |
| Python ElementTree | 0.972020× | 1.319333× | 8/12 |
| Python pyexpat | 0.986088× | 1.167824× | 5/12 |

Ratios use the median of seven paired process-median ratios, then an equally weighted geometric mean across conditions. Native: 84 preflight + 588 timed workers, 105420 measured samples. Python: 72 preflight + 504 timed workers, 25788 measured samples. Each timed worker discards one warmup. Native callback hashes coalesce text fragments; Python canonical checking also coalesces adjacent text. Neither substitutes for strict callback tests. Python times parser creation, feeds, finalization, callbacks and explicit result destruction; imports, file reads, canonical checks and explicit GC collection stay outside timing, and automatic GC stays enabled. Shared-host frequency/cache/bandwidth remain uncontrolled; this is one campaign without a statistical-significance claim.

Maven native namespace conditions improve by 15.2–15.9%, and DocBook by 11.5–11.9%. ElementTree improves by 2.80% across its 12 conditions. Only **2/24 native real** and **4/24 Python** conditions are at or below 1.10× Expat.

## All conditions slower than selected

Positive changes below are slower. No generated native condition was adverse. Full paired values and all non-adverse conditions remain in the [native CSV](/tmp/oriole-expanded-start-native-review/conditions.csv) and [Python CSV](/tmp/oriole-expanded-start-current-study/python/normal-conditions.csv).

| Native project | Feed | Namespaces | Time change |
| --- | ---: | --- | ---: |
| wayland | 4KiB | on | +0.002% |
| batik | 4KiB | off | +0.074% |
| batik | 4KiB | on | +3.343% |
| gtk | 4KiB | off | +1.716% |
| gtk | 4KiB | on | +0.940% |
| docbook | 4KiB | off | +0.722% |
| vulkan | 64KiB | off | +2.202% |
| vulkan | 64KiB | on | +0.257% |
| wayland | 64KiB | on | +0.511% |
| maven | 64KiB | off | +0.363% |
| batik | 64KiB | off | +0.011% |
| batik | 64KiB | on | +1.093% |
| gtk | 64KiB | off | +0.685% |
| gtk | 64KiB | on | +1.187% |
| docbook | 64KiB | off | +0.278% |

| Python project | Feed | Consumer | Time change |
| --- | ---: | --- | ---: |
| vulkan | 64KiB | pyexpat-events | +1.130% |
| wayland | 4KiB | pyexpat-events | +0.182% |
| wayland | 64KiB | pyexpat-events | +0.794% |
| batik | 4KiB | elementtree | +0.784% |
| batik | 4KiB | pyexpat-events | +0.534% |
| batik | 64KiB | elementtree | +0.899% |
| batik | 64KiB | pyexpat-events | +0.740% |
| gtk | 4KiB | elementtree | +0.211% |
| gtk | 4KiB | pyexpat-events | +1.655% |
| gtk | 64KiB | elementtree | +1.381% |
| gtk | 64KiB | pyexpat-events | +2.052% |

## Allocator tradeoffs

The unchanged supplied-allocator probe compared eight cases per library, including cold feed boundaries. All 16 outputs matched callback hashes/counts and ended with zero live blocks after parser free. Phase-2 changes were:

| Case | Allocation/reallocation requests | Peak live bytes | Final retained bytes |
| --- | ---: | ---: | ---: |
| Maven, namespaces off | 0 | 0 | 0 |
| Maven, namespaces on | −301 | +3 | −18 |
| Flat prefixed | +1 | +12 | 0 |
| Empty prefixed | +1 | +12 | 0 |
| Nested prefixed | +196 | +202 | +26 |
| Equal NUL spelling | +1 | +4 | 0 |
| Triplets | +1 | −6 | −20 |
| 2044-byte suffix name | +15 | 0 | −2040 |

Nested prefixed names grow an 18-byte expansion owner to a 36-byte packed allocation; matching request-size histograms identify the repeated reserve transition. The long suffix case allocates/frees a 2051-byte frame buffer on each of 15 post-warmup feeds. These are source-and-histogram inferences, not allocation-address traces. The probe records per-feed live bytes/blocks and per-phase request histograms; it does not count allocations separately for each feed. Full positive and negative phases remain in [comparison.json](/tmp/oriole-expanded-start-current-study/allocations/comparison.json).

## Validation and diagnostic limits

V1 passed 442 workspace tests across 35 groups, strict all-target Clippy and formatting. Independent source review found no correctness blocker. Focused tests cover UTF-8 and separator spellings, all chunk widths, limits, duplicates, selected allocator failures and C callback reentry/live pointers. An initial new wide-attribute frame-count test lacked a required lexical-record warmup; that test-only correction and original failure remain. The allocator binder and independent native reader also preserve their initial stale 72-file expectations and corrected 73-file reads; targets were not rerun for those saved-reader corrections.

A separate selected-normal Callgrind diagnostic recorded 20321505 instructions with Maven namespaces on versus 14709923 off (+38.15%), and 6464736 versus 6266840 for GTK (+3.16%). It includes callbacks inside XML_Parse and excludes construction/free outside it; it profiles the selected runtime, not V1. Required longer callback payload processing is included, so the delta is not removable work or an elapsed-speed prediction.

All V1 builds and measurements here are normal builds. No PGO work was performed. Benchmark canonical agreement is narrower than an upstream API matrix or strict CPython compatibility run; this section makes no new claim about those gates.
