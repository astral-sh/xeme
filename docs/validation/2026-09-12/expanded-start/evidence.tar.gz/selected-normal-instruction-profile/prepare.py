"""Prepare four held profiles of the existing selected normal-release DSO."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os

assert os.sched_getaffinity(0) == {6}
ROOT = Path(__file__).parent
OLD = Path('/tmp/oriole-context-text-frame-maven-gtk-profile-study/context')
LIBRARY = Path('/tmp/oriole-reference-frame-pgo-study/normal/liboriole_expat.so')
SOURCE = Path('/tmp/oriole-reference-frame-pgo-study/source.json')
PAIR = Path('/tmp/oriole-reference-frame-pgo-study/pair-report.json')
PREFLIGHT = Path('/tmp/oriole-reference-frame-native-study/normal/native-screen/preflight.json')
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert sha(LIBRARY) == '087d131c215012d2a93527a4ec66a716216e8ab4009948a1f79d0a7644d5d949'
assert read(PAIR)['normal_libraries']['liboriole_expat.so'] == sha(LIBRARY)
source = read(SOURCE)
assert len(source['source_sha256']) == 72
assert all(sha(Path(source['worktree']) / n) == h for n, h in source['source_sha256'].items())
prior, preflight = read(OLD / 'protocol.json'), read(PREFLIGHT)
assert preflight['status'] == 'passed' and preflight['hashes_before'] == preflight['hashes_after']
original = (OLD / 'run.py').read_text()
controller = original.replace("choices=['static', 'profile']", "choices=['profile']")
start = controller.index("        if args.phase == 'static':")
body = controller.index("            record['profiles'] = []", start)
end = controller.index("        record['status'] = 'passed'", body)
controller = controller[:start] + ''.join(line[4:] if line.startswith('    ') else line for line in controller[body:end].splitlines(True)) + controller[end:]
ast.parse(controller)
(ROOT / 'run.py').write_text(controller)
(ROOT / 'controller.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), controller.splitlines(True), fromfile=str(OLD / 'run.py'), tofile=str(ROOT / 'run.py'))))
(ROOT / 'read_pcs.py').write_bytes((OLD / 'read_pcs.py').read_bytes())
driver = prior['cases'][0]['preflight']['argv'][0]
tools = [driver, *prior['cases'][0]['profile']['argv'][:1], *prior['cases'][0]['annotation']['argv'][:1],
         str(Path(prior['valgrind_lib']) / 'callgrind-amd64-linux'),
         str(Path(prior['valgrind_lib']) / 'vgpreload_core-amd64-linux.so')]
pins = {}
for path in tools:
    assert sha(path) == prior['pins'][path]
    pins[path] = sha(path)
for path in [LIBRARY, SOURCE, PAIR, PREFLIGHT, OLD / 'protocol.json', OLD / 'run.py', OLD / 'read_pcs.py',
             ROOT / 'run.py', ROOT / 'read_pcs.py', ROOT / 'README.md', Path(__file__), Path(PYTHON),
             Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c'),
             Path(source['worktree']) / 'include/expat.h']:
    pins[str(path)] = sha(path)
assert pins['/home/dev-user/code/oss/oriole/benchmarks/native_driver.c'] == prior['pins']['/home/dev-user/code/oss/oriole/benchmarks/native_driver.c']
cases = []
for name in ['maven', 'gtk']:
    for namespaces in [False, True]:
        row, = [r for r in preflight['rows'] if r['engine'] == 'candidate' and r['condition']['name'] == name and r['condition']['namespaces'] == namespaces and r['condition']['chunk'] == 65536]
        assert row['returncode'] == 0 and row['stderr'] == ''
        argv = row['command'][3:]
        assert argv[:2] == [driver, str(LIBRARY)] and argv[3:5] == ['65536', '1']
        assert ('namespaces' in argv) == namespaces
        assert len(argv) == (6 if namespaces else 5)
        input_path = row['condition']['input']
        assert sha(input_path) == preflight['hashes_after'][input_path]
        pins[input_path] = sha(input_path)
        raw = json.loads(row['stdout'])
        assert raw['version'] == 'oriole_compat_2.8.4'
        samples = raw['samples']
        assert len(samples) == 2 and [s['warmup'] for s in samples] == [True, False]
        assert [s['iteration'] for s in samples] == [0, 1]
        expected = [[s[k] for k in ['hash', 'elements', 'text_bytes']] for s in samples]
        assert expected[0] == expected[1]
        label = f'{name}-ns{int(namespaces)}'
        profile = ROOT / 'profile-attempt01' / (label + '.callgrind')
        profile_argv = [tools[1], '--tool=callgrind', '--collect-atstart=no', '--toggle-collect=XML_Parse', '--dump-instr=yes', '--collect-jumps=yes', '--callgrind-out-file=' + str(profile), *argv]
        cases.append({'label': label, 'condition': row['condition'] | {'iterations': 1},
                      'inherited_elapsed_iterations': row['condition']['iterations'], 'expected_observations': expected,
                      'profile_path': str(profile),
                      'preflight': {'label': label + '-preflight', 'argv': argv, 'timeout_seconds': 30},
                      'profile': {'label': label + '-profile', 'argv': profile_argv, 'timeout_seconds': 300},
                      'annotation': {'label': label + '-annotation', 'argv': [tools[2], '--auto=no', '--threshold=100', '--show-percs=no', str(profile)], 'timeout_seconds': 30}})
protocol = {'status': 'prepared_execution_held', 'cpu': 1,
            'scope': 'Selected ordinary normal-release087d: Maven and GTK namespaces off/on,64KiB. Both warmup1 and measured1 XML_Parse windows collected, including native callbacks. No PGO, recompilation, debug companion, elapsed or CPU-cycle claim.',
            'library': str(LIBRARY), 'library_sha256': sha(LIBRARY), 'source_manifest': str(SOURCE),
            'source_note': 'Historical parent directory also contains other builds; only its original normal library is loaded. Selected publication4064/source0f66, all72 source hashes retained.',
            'valgrind_lib': prior['valgrind_lib'], 'pins': pins, 'cases': cases,
            'collection_note': 'Exact prior Callgrind toggles and faithful existing native driver. Parser construction/free/loading outside XML_Parse are excluded; both driver iterations are included. Inherited elapsed128/256 metadata is not the actual profile repetition count.',
            'origin_limit': 'Faithful driver explicitly dlopens pinned path and resolves symbols through that handle; no new dladdr probe or alternate driver.',
            'static_note': 'Prior static assembly belongs to a different binary and is not reused as attribution evidence. No static/compiler phase exists in this held controller.',
            'failure_policy': 'Single fresh attempt, stop on first failure, original process-group timeout kill/reap and raw records retained.'}
with (ROOT / 'protocol.json').open('x') as stream:
    stream.write(json.dumps(protocol, indent=2) + '\n')
result = {'status': 'prepared_not_executed', 'targets_executed': False, 'case_count': 4,
          'commands': {'preflight': 4, 'callgrind': 4, 'annotation': 4},
          'protocol_sha256': sha(ROOT / 'protocol.json'), 'controller_sha256': sha(ROOT / 'run.py'),
          'reader_byte_identical': sha(ROOT / 'read_pcs.py') == sha(OLD / 'read_pcs.py'),
          'prior_controller': {'path': str(OLD / 'run.py'), 'sha256': sha(OLD / 'run.py')},
          'adaptation': 'Retain only profile phase; remove obsolete different-binary static prerequisite. Collection, callbacks, bounded process cleanup, annotation arithmetic and source/input verification are reused.',
          'release_command_held': ['/usr/bin/taskset', '-c', '1', PYTHON, '-I', '-S', str(ROOT / 'run.py'), '--phase', 'profile', '--released-protocol-sha256', sha(ROOT / 'protocol.json')]}
with (ROOT / 'preparation.json').open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
