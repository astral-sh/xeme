"""Reconstruct completed selected/candidate C allocation records; no targets."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import os

ROOT = Path(__file__).parent
BASE = ROOT / 'selected'
CANDIDATE = ROOT / 'candidate'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs = {}


def pin(path):
    digest = sha(path)
    assert str(path) not in inputs or inputs[str(path)] == digest
    inputs[str(path)] = digest
    return digest


def read(path):
    pin(path)
    return json.loads(Path(path).read_text())


def audit(root):
    plan = read(root / 'plan.json')
    assert plan['status'] == 'prepared_not_executed' and len(plan['cases']) == 8
    for path, digest in plan['pins'].items():
        assert pin(path) == digest
    library, binary = root / 'runs/liboriole_expat.so', root / 'runs/probe'
    assert pin(library) == plan['library']['sha256'] == pin(plan['library']['path'])
    build = read(root / 'runs/build.json')
    assert build['status'] == 'reaped' and build['exit'] == 0 and build['pins_unchanged']
    assert build['plan_sha256'] == pin(root / 'plan.json')
    assert build['binary_sha256'] == pin(binary)
    assert build['log_sha256'] == pin(root / 'runs/build.log')
    assert build['timeout_seconds'] == 120 and 'exception' not in build and 'outer_timeout' not in build
    assert build['argv'] == ['/usr/bin/cc', '-std=c11', '-O1', '-g', '-Wall', '-Wextra', '-Werror',
                             '-I' + plan['header_directory'], str(root / 'probe.c'), str(library),
                             '-Wl,-rpath,' + str(root / 'runs'), '-ldl', '-o', str(binary)]
    rows = []
    for case in plan['cases']:
        receipt = read(root / 'runs' / (case['name'] + '.json'))
        log = root / 'runs' / (case['name'] + '.log')
        assert receipt['status'] == 'reaped' and receipt['exit'] == 0 and receipt['pins_unchanged']
        assert receipt['plan_sha256'] == pin(root / 'plan.json') and receipt['log_sha256'] == pin(log)
        assert receipt['origin_verified'] and receipt['complete_result'] and receipt['successful_result']
        assert 'exception' not in receipt and 'outer_timeout' not in receipt and receipt['timeout_seconds'] == 4
        assert receipt['argv'] == [str(binary), case['input'], case['namespace'], str(case['triplets']),
                                  str(case['expected_starts']), str(case['expected_text_bytes']), str(case['warmup_bytes'])]
        assert pin(case['input']) == case['input_sha256']
        origins, calls, phases, histograms, results = {}, [], {}, {}, []
        for line in log.read_text().splitlines():
            row = line.split('\t')
            if row[0] == 'ORIGIN_API':
                assert len(row) == 3 and row[1] not in origins
                origins[row[1]] = row[2]
            elif row[0] == 'CALL':
                assert len(row) == 12
                calls.append([int(value) for value in row[1:]])
            elif row[0] == 'PHASE':
                assert len(row) == 8 and int(row[1]) not in phases
                phases[int(row[1])] = dict(zip(['mallocs', 'reallocs', 'frees', 'requested', 'peak_bytes', 'peak_blocks'], map(int, row[2:]), strict=True))
            elif row[0] == 'SIZE':
                assert len(row) == 5 and row[2] in ['M', 'R', 'F']
                key = (int(row[1]), row[2], int(row[3]))
                assert key not in histograms and int(row[4]) > 0
                histograms[key] = int(row[4])
            elif row[0] == 'RESULT':
                assert len(row) == 18
                results.append(row)
            else:
                raise AssertionError(('unknown raw record', row))
        assert set(origins) == {'XML_ParserCreate_MM', 'XML_SetUserData', 'XML_SetElementHandler',
                                'XML_SetCharacterDataHandler', 'XML_SetReturnNSTriplet', 'XML_SetHashSalt',
                                'XML_Parse', 'XML_GetErrorCode', 'XML_GetParsingStatus', 'XML_ParserFree'}
        assert all(Path(value).resolve() == library.resolve() for value in origins.values())
        assert receipt['xml_parse_origin'] == origins['XML_Parse']
        assert set(phases) == {0, 1, 2, 3} and len(results) == 1
        assert all(phase in phases and size >= 0 for phase, _, size in histograms)
        assert all(value >= 0 for phase in phases.values() for value in phase.values())
        for phase, totals in phases.items():
            for operation, key in [('M', 'mallocs'), ('R', 'reallocs'), ('F', 'frees')]:
                assert sum(count for (p, op, _), count in histograms.items() if p == phase and op == operation) == totals[key]
            assert sum(size * count for (p, op, size), count in histograms.items() if p == phase and op in ['M', 'R']) == totals['requested']
        length, warmup, offset = Path(case['input']).stat().st_size, case['warmup_bytes'], 0
        previous_starts = previous_ends = 0
        for index, call in enumerate(calls, 1):
            ordinal, phase, count, final, status, error, starts, ends, depth, live, blocks = call
            expected_count = min(4096, length - offset)
            if offset < warmup:
                expected_count = min(expected_count, warmup - offset)
            assert ordinal == index and phase == (1 if offset < warmup else 2)
            assert count == expected_count > 0 and final == int(offset + count == length)
            assert status == 1 and error == 0 and starts >= previous_starts and ends >= previous_ends
            assert depth == starts - ends >= 0 and live >= 0 and blocks >= 0
            assert phases[phase]['peak_bytes'] >= live and phases[phase]['peak_blocks'] >= blocks
            previous_starts, previous_ends = starts, ends
            offset += count
        assert offset == length and calls
        result = results[0]
        assert result[1:4] == ['1', '0', '2']
        callbacks = dict(zip(['starts', 'ends', 'depth', 'text_callbacks', 'text_bytes', 'count'], map(int, result[4:10]), strict=True))
        callbacks['hash'] = result[10]
        allocation = dict(zip(['retained_bytes', 'retained_blocks', 'peak_bytes', 'peak_blocks', 'live_bytes_after_free', 'live_blocks_after_free', 'allocation_failed'], map(int, result[11:]), strict=True))
        assert callbacks == receipt['callbacks'] and allocation == receipt['allocation']
        assert callbacks['starts'] == callbacks['ends'] == case['expected_starts'] and callbacks['depth'] == 0
        assert callbacks['count'] == callbacks['starts'] + callbacks['ends'] + callbacks['text_callbacks']
        assert callbacks['text_bytes'] == case['expected_text_bytes']
        assert calls[-1][6:] == [callbacks['starts'], callbacks['ends'], 0, allocation['retained_bytes'], allocation['retained_blocks']]
        assert allocation['live_bytes_after_free'] == allocation['live_blocks_after_free'] == allocation['allocation_failed'] == 0
        assert allocation['peak_bytes'] == max(row['peak_bytes'] for row in phases.values())
        assert allocation['peak_blocks'] == max(row['peak_blocks'] for row in phases.values())
        assert phases[3]['mallocs'] == phases[3]['reallocs'] == phases[3]['requested'] == 0
        assert phases[3]['peak_bytes'] == allocation['retained_bytes'] and phases[3]['peak_blocks'] == allocation['retained_blocks']
        assert sum(size * count for (phase, kind, size), count in histograms.items() if phase == 3 and kind == 'F') == allocation['retained_bytes']
        row = {'case': case['name'], 'create': phases[0], 'warmup': phases[1], 'parse': phases[2], 'free': phases[3],
               'callbacks': callbacks, 'allocation': allocation,
               'parse_histogram': [{'kind': op, 'size': size, 'count': count} for (phase, op, size), count in sorted(histograms.items()) if phase == 2],
               'all_histograms': [{'phase': phase, 'kind': op, 'size': size, 'count': count} for (phase, op, size), count in sorted(histograms.items())],
               'parse_calls': calls, 'xml_parse_origin': origins['XML_Parse']}
        rows.append(row)
    return plan, rows



def main():
    assert __debug__ and os.sched_getaffinity(0) == {6}
    expected_names = ['maven-off', 'maven-pipe', 'flat-pipe', 'empty-pipe', 'nested-pipe', 'equal-nul', 'triplets-pipe', 'capacity-2044']
    preparation = read(ROOT / 'preparation.json')
    assert preparation['status'] == 'prepared_not_executed' and preparation['cases_per_engine'] == 8
    controller = read(ROOT / 'controller.json')
    assert controller['status'] == 'passed' and len(controller['commands']) == 4
    assert [row['argv'] for row in controller['commands']] == preparation['launch_in_order']
    for index, command in enumerate(controller['commands']):
        assert command['exit'] == 0 and command['reaped'] is True and 'exception' not in command
        assert command['end'] >= command['start']
        if index:
            assert controller['commands'][index-1]['end'] <= command['start']
    all_plans, observations = {}, {}
    for engine, root in [('selected', BASE), ('candidate', CANDIDATE)]:
        assert preparation['plans'][engine] == {'path': str(root / 'plan.json'), 'sha256': pin(root / 'plan.json')}
        plan, records = audit(root)
        assert [case['name'] for case in plan['cases']] == expected_names
        collection = read(root / 'collection.json')
        assert collection['status'] == 'passed' and collection['plan_sha256'] == pin(root / 'plan.json')
        assert len(collection['commands']) == 8
        for case, command in zip(plan['cases'], collection['commands'], strict=True):
            assert command['case'] == case['name'] and command['exit'] == 0 and command['reaped'] is True
            assert 'timeout' not in command and command['completed'] >= command['started']
            assert command['argv'] == ['taskset', '-c', '4', '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12', '-I', '-S', str(root / 'run.py'), 'run', '--case', case['name']]
            stdout = root / (case['name'] + '.stdout')
            assert pin(stdout) == command['log_sha256']
            assert json.loads(stdout.read_text()) == read(root / 'runs' / (case['name'] + '.json'))
        all_plans[engine], observations[engine] = plan, records
    assert all_plans['selected']['bounds'] == all_plans['candidate']['bounds']
    assert all_plans['selected']['cases'] == all_plans['candidate']['cases']
    assert all_plans['selected']['library']['sha256'] == '087d131c215012d2a93527a4ec66a716216e8ab4009948a1f79d0a7644d5d949'
    assert all_plans['candidate']['library']['sha256'] == '32d9e7c78e6590609d389e5cbd6b0d073336bda9ed360a6766ea61cb08de728e'
    for name in ['probe.c', 'run.py']:
        assert pin(BASE / name) == pin(CANDIDATE / name)
    rows = []
    for a, b in zip(observations['selected'], observations['candidate'], strict=True):
        assert a['case'] == b['case'] and a['callbacks'] == b['callbacks']
        assert [c[:9] for c in a['parse_calls']] == [c[:9] for c in b['parse_calls']]
        delta = {phase: {key: b[phase][key]-a[phase][key] for key in a[phase]} for phase in ['create', 'warmup', 'parse', 'free', 'allocation']}
        feeds = [{'ordinal': ca[0], 'phase': ca[1], 'bytes': ca[2], 'selected_live_bytes': ca[9], 'candidate_live_bytes': cb[9], 'delta_live_bytes': cb[9]-ca[9], 'selected_live_blocks': ca[10], 'candidate_live_blocks': cb[10], 'delta_live_blocks': cb[10]-ca[10]} for ca, cb in zip(a['parse_calls'], b['parse_calls'], strict=True)]
        rows.append({'case': a['case'], 'selected': a, 'candidate': b, 'candidate_minus_selected': delta, 'feeds': feeds})
    for path, digest in inputs.items():
        assert sha(path) == digest
    result = {'status': 'passed_saved_allocation_audit', 'targets_executed': False, 'cases': 8, 'raw_probe_results': 16, 'feed_records': sum(len(x['parse_calls']) for records in observations.values() for x in records), 'rows': rows, 'input_sha256': inputs, 'reader_sha256': sha(__file__), 'role': 'Runtime/preparation author reconstructs root-collected allocation outputs using the existing raw reader body; separate source review and root target execution remain distinct.', 'limits': ['Malloc/realloc/free counts are per phase, only live bytes/blocks are per feed.', 'Tracked peak bytes are recorded by the inspected tracker, not address-level reconstruction or RSS.', 'Only two ordinary attribute nodes occur in Maven; this is not isolated per-attribute attribution.', 'No elapsed-performance conclusion.']}
    with (ROOT / 'comparison.json').open('x') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    print('case phase2_malloc selected/candidate phase2_realloc selected/candidate request_delta phase2_requested_byte_delta peak_byte_delta retained_byte_delta')
    for row in rows:
        a, b, d = row['selected'], row['candidate'], row['candidate_minus_selected']
        print(row['case'], f"{a['parse']['mallocs']}/{b['parse']['mallocs']}", f"{a['parse']['reallocs']}/{b['parse']['reallocs']}", d['parse']['mallocs']+d['parse']['reallocs'], d['parse']['requested'], d['allocation']['peak_bytes'], d['allocation']['retained_bytes'])
    print(json.dumps({'status': result['status'], 'sha256': sha(ROOT / 'comparison.json'), 'raw_probe_results': 16, 'feed_records': result['feed_records']}))


if __name__ == '__main__':
    main()
