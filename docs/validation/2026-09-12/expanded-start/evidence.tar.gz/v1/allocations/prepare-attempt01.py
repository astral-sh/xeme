"""Bind the existing allocation diagnostic to two normal libraries; no targets."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil

ROOT = Path(__file__).parent
ORIGIN = Path('/tmp/oriole-packed-element-names-allocation-probe')
WORK = Path('/home/dev-user/code/oss/oriole-expanded-start-current')
SELECTED = Path('/home/dev-user/code/oss/oriole-reference-frame')
PYTHON = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
cli = argparse.ArgumentParser(description=__doc__)
cli.add_argument('--candidate', type=Path, required=True)
cli.add_argument('--candidate-sha256', required=True)
args = cli.parse_args()
assert not (ROOT / 'preparation.json').exists()
args.candidate = args.candidate.resolve(strict=True)
assert sha(args.candidate) == args.candidate_sha256
old = read(ORIGIN / 'plan.json')
assert sha(ORIGIN / 'probe.c') == '63f4106e6da5e5536022e38aa0520b0cd239e589fa9f3e51d399112f62daa43d'
assert sha(ORIGIN / 'run.py') == '34e18448f451321b44021ba931387981d0959fcba89d17dc346352b422679c03'
source_path = ROOT.parent / 'source.json'
source = read(source_path)
assert source['base'] == '4064b0653534aff690c0e0f395a6b3b48da878fc'
assert len(source['sha256']) == 72
assert all(sha(WORK / path) == digest for path, digest in source['sha256'].items())
names = ['maven-off', 'maven-pipe', 'flat-pipe', 'empty-pipe', 'nested-pipe', 'equal-nul', 'triplets-pipe', 'capacity-2044']
by_name = {case['name']: case for case in old['cases']}
inputs = ROOT / 'inputs'
inputs.mkdir(exist_ok=False)
cases = []
for name in names:
    case = by_name[name].copy()
    original = Path(case['input'])
    assert sha(original) == case['input_sha256']
    copied = inputs / original.name
    shutil.copyfile(original, copied)
    case.update(input=str(copied), unchanged_input_origin=str(original))
    cases.append(case)
libraries = {
    'selected': {'path': '/tmp/oriole-reference-frame-pgo-study/normal/liboriole_expat.so', 'sha256': '087d131c215012d2a93527a4ec66a716216e8ab4009948a1f79d0a7644d5d949'},
    'candidate': {'path': str(args.candidate), 'sha256': args.candidate_sha256},
}
plans, launch = {}, []
for engine, library in libraries.items():
    directory = ROOT / engine
    assert sha(library['path']) == library['sha256']
    for name in ['probe.c', 'run.py']:
        assert sha(directory / name) == sha(ORIGIN / name)
    header = SELECTED / 'include'
    assert sha(header / 'expat.h') == sha(WORK / 'include/expat.h')
    paths = [Path(__file__), ROOT / 'README.md', source_path, ORIGIN / 'plan.json', ORIGIN / 'probe.c', ORIGIN / 'run.py', directory / 'probe.c', directory / 'run.py', directory / 'collect.py', Path(library['path']), header / 'expat.h', Path(PYTHON), Path('/usr/bin/cc').resolve(), Path('/usr/bin/readelf').resolve(), *[Path(case['input']) for case in cases]]
    plan = {'status': 'prepared_not_executed', 'scope': 'Fresh matched normal-library diagnostic; existing C/runner and eight predeclared original fixtures. No elapsed performance claim or profile generation/use.', 'source_commit': source['base'] if engine == 'selected' else 'uncommitted-expanded-start-current-from-' + source['base'], 'source_state_manifest': {'path': str(source_path), 'sha256': sha(source_path)}, 'library': library, 'header_directory': str(header), 'cases': cases, 'bounds': old['bounds'], 'pins': {str(path): sha(path) for path in paths}}
    destination = directory / 'plan.json'
    destination.write_text(json.dumps(plan, indent=2) + '\n')
    plans[engine] = {'path': str(destination), 'sha256': sha(destination)}
    launch.extend([
        ['taskset', '-c', '4', PYTHON, '-I', '-S', str(directory / 'run.py'), 'build'],
        ['taskset', '-c', '4', PYTHON, '-I', '-S', str(directory / 'collect.py')],
    ])
report = {'status': 'prepared_not_executed', 'targets_executed': False, 'plans': plans, 'launch_in_order': launch, 'cases_per_engine': 8, 'scope': 'Both parser libraries must have passed root normal-build validation. This binder checks actual library bytes and current source pins; it does not prove compiler settings. Root explicitly releases target execution separately.'}
(ROOT / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'preparation_sha256': sha(ROOT / 'preparation.json'), 'cases_per_engine': 8, 'targets_executed': False}))
