# V1 reservation follow-up — source and saved histograms only

V1 remains frozen. No implementation or target execution follows from this note.

## Specific transitions

For nested `p:node` with URI `urn:example`, the expanded spelling is16 bytes. `expand_name` initially reserves18 bytes. The raw spelling adds6 bytes plus the spare NUL: the packed owner needs23 bytes. V1 then calls amortized `try_reserve`, which doubles18→36. The tracked allocator's47-byte header/alignment allowance maps those capacities to requests65,70 and83. This source-derived attribution matches the raw histogram:

- Selected phase2:225 malloc requests of70 bytes for23-byte packed owners.
- V1 phase2:210 mallocs of65 bytes followed by210 reallocs of83 bytes, plus one64-byte frame buffer. Warmup likewise has16 new83-byte reallocs.
- The two existing name-cache slots are insufficient for all live nested stack names, so this is repeated fresh-owner growth rather than a one-time warmup cost.

The long suffix case differs. Expanded names are2050 bytes; their frame spelling including NUL needs2051 bytes, matching request2098. All15 new phase2 mallocs and15 corresponding frees are2098 bytes, one per post-warmup feed. The frame dies at each `run_events` return. Packed stack names already reuse their suffix/capacity; changing their reservation cannot remove these frame allocations. Attribution is inferred from exact source sizes and matching histograms, not an address-level allocation trace.

## Two small alternatives for nested growth

| Alternative | Allocation/copy tradeoff | Scope and error ordering |
| --- | --- | --- |
| Conditional second-owner packing | If the expanded owner lacks final packed capacity, take the other existing cached name (or an empty owner), reserve the full packed size once, copy expanded+raw bytes there, then return the expanded temporary to the existing name cache. Otherwise keep V1's move. Removes the repeated fresh18→36 growth, but adds a third expanded-name byte copy only for insufficient-capacity cases. | Small local branch in `parse_start_frame`; generic `expand_name` and all call signatures stay unchanged. URI charge, root flags, frame copy and stack-publication order stay in their existing phases. Retention uses existing generation/budget rules. The extra temporary/cache lifetime changes allocation-failure indices and must be measured. |
| Reserve-aware expansion helper | Keep `expand_name` as its current-signature wrapper forwarding to a private implementation; only frame expansion selects a packed-capacity policy. Reserve final expanded+optional raw+NUL capacity once, after the existing URI charge and before filling the String. Avoids both the extra realloc and third name copy. | More source/codegen scope: another helper/specialization and capacity calculation can perturb the generic hot path even when its outputs and allocation policy remain unchanged. All ordinary call sites retain the original signature; their URI charge and capacity calculation must remain exact. |

The second alternative must preserve the suffix/equality cases rather than reserve raw length indiscriminately, which could cross the4KiB cache boundary. Under the frame's already-validated native QName precondition, the suffix decision can be computed without an allocation:

- No prefix: raw name is always the suffix.
- NUL separator: suffix when URI with its final `:` removed ends with the raw prefix.
- Colon separator without triplets: suffix when URI ends with the raw prefix.
- Colon separator with triplets: suffix when local name equals prefix (`local:prefix` then equals `prefix:local`).
- Other non-NUL separators: prefixed raw spelling is not a suffix.

Compute actual serialized UTF-8 length (including triplet separators), add raw length only when needed, then one NUL byte with checked arithmetic. The generic policy should retain its original formula; only the frame policy needs this extra calculation. This is a design sketch, not yet reviewed implementation.

The local second-owner branch has lower generic-codegen risk and preserves the Maven default-namespace move path. The reserve-aware helper has the cleaner copy/allocation outcome, with a larger review and measurement surface. Neither is an answer to per-feed long-name frame recreation; solving that would require a separate ownership handoff or a fallback decision. Avoid composing either without the current Python result and a separate root decision.
