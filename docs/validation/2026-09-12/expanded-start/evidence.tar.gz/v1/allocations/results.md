# Saved normal-library allocation results

All16 probe runs pass. The saved reader verifies both C compiler commands, all160 API-origin records, exact input/argument bindings, callback hashes/counts,102 feed records, phase/histogram sums and zero live allocations after every parser is freed. Selected library `087d131c…`; expanded-Start candidate `32d9e7c7…`. No targets were rerun for this audit.

Numbers below compare candidate with selected. Phase2 is post-warmup parsing for generated cases and the whole parse for Maven. Requests mean malloc plus realloc calls.

| Case | Phase2 requests, selected→candidate | Requested-byte delta | Overall peak-byte delta | Final retained-byte delta |
| --- | ---: | ---: | ---: | ---: |
| Maven, namespaces off |307→307|0|0|0|
| Maven, namespaces on |584→283|−30,938|+3|−18|
| Flat prefixed |3→4|+64|+12|0|
| Empty prefixed |3→4|+64|+12|0|
| Nested prefixed |228→424|+15,394|+202|+26|
| Equal spelling, NUL separator |3→4|+55|+4|0|
| Triplets |3→4|+66|−6|−20|
| Long default-namespace suffix |4→19|+31,470|0|−2,040|

The cold-frame caveat is observable. Flat/empty/equal/triplet cases add one phase2 malloc after the warmup call destroys its frame. Long suffix names add15 phase2 mallocs across15 post-warmup feeds. These observations fit frame recreation, but the probe does not identify allocation source lines.

Nested names have a separate adverse pattern: phase2 mallocs decrease225→211, while reallocs increase3→213. Warmup also adds16 reallocs and1,247 requested bytes. Flat/empty warmup each add one realloc and77 requested bytes; equal warmup adds4 bytes without an extra request; triplet warmup requests6 fewer bytes. Create-phase counts are identical for every case. Full phase values and histograms remain in `comparison.json`.

Per-feed live memory is also mixed. Namespace Maven ranges from147 fewer bytes to31 more bytes (+31 after feed4 and +19 after feed8), ending18 lower. Nested cases retain26 extra bytes after both feeds. Long suffix cases retain2,098 fewer bytes after feeds1–16 and2,040 fewer after the final feed. Flat/empty/equal finish unchanged; triplets finish20 bytes lower; namespace-off Maven is identical throughout.

`comparison.json` SHA256: `7aec7f4ccbbb7bd0514af06c599642943002f6f0a2a0dabaa790d264081f798d`. `compare.py` reuses the existing raw reader body with an eight-case count and a current matched-pair footer. It rejects unknown raw record types and validates every declared case. The runtime/preparation author performed this saved audit; root executed the targets and a separate agent reviewed runtime source.

These are selected-allocator requests and tracked memory, not elapsed time or RSS. Counts are per phase; only live bytes/blocks are per feed. The results neither establish a speedup nor justify selection by themselves.
