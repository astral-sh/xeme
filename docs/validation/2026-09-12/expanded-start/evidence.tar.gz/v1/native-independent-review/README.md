# Expanded namespace Start: independent native readback

The completed normal-release campaign reconstructs exactly from all 672 raw
workers and 106,176 samples: 84 preflight workers, 588 timed workers, 588 timed
warmups, and 105,420 measured samples. All 28 conditions, seven seeded pairs per
condition, actual driver arguments, library/input hashes, callback observations,
process medians, and paired ratios match the producer's saved results.

| Conditions | Candidate / selected control | Candidate / Expat | Faster than control |
| --- | ---: | ---: | ---: |
| All 24 real-project conditions | 0.98001843 | 1.56562985 | 9/24 |
| 12 real, namespaces enabled | 0.95800511 | 1.63124698 | 5/12 |
| 12 real, namespaces disabled | 1.00253758 | 1.50265217 | 4/12 |
| Four generated controls | 0.97828996 | 4.00190024 | 4/4 |

Maven with namespaces improves by 15.2–15.9%; DocBook with namespaces improves
by 11.5–11.9%. These gains outweigh 15 adverse real-project conditions in the
equally weighted aggregate. The largest regressions are Batik with namespaces
at 4 KiB (3.34%), Vulkan without namespaces at 64 KiB (2.20%), and GTK without
namespaces at 4 KiB (1.72%). Every adverse condition, including near-flat cases,
is retained in [review.json](review.json); [conditions.csv](conditions.csv)
contains all 28 conditions. The normal native aggregate remains above the
user's 1.10× Expat goal.

Ratios are medians of seven paired process-median ratios, followed by an equally
weighted geometric mean across the stated conditions. This is one campaign;
no statistical-significance or whole-application speed claim follows. The
faithful driver explicitly loads each recorded library path. Callback hashes
merge text fragments, so equality does not establish exact fragmentation.

The selected control is `087d131c…`, candidate `32d9e7c7…`, and Expat
`7a333bc8…`; full identities and receipt hashes are in `review.json`. Source is
base `4064b065…` plus the four recorded deltas, with runtime core `3600822f…`.
The frozen manifest has 73 files including the inherited upstream notice.
Historical directory names do not change this campaign's normal-release scope.

Root ran all targets. A separate source reviewer authored and ran `read.py` on
CPU6 using only completed saved files; Python elapsed results were not read.
The first reader attempt stopped on a stale 72-file expectation. Its reader and
stderr remain preserved; the corrected second attempt passed without rerunning
targets. The frozen build binding already documented the 73rd notice file and
the adaptation-hash mapping used by the corrected reader.
