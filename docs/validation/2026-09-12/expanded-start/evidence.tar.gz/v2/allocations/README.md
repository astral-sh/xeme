# Normal-library allocation observations

Prepared only; no compiler or parser was run. Compare selected normal `087d131c…` against the upcoming normal V2 capacity-guarded expanded-Start candidate. Both use the same existing selected-allocator C probe, runner, input bytes, hash salt and4096-byte feed schedule. No new harness or fixture is introduced.

## Representative cases

| Existing case | What it observes |
| --- | --- |
| `maven-off`, `maven-pipe` | Twelve feeds per document; ordinary and inherited-default namespace paths. Maven includes two eligible literal `implementation` attributes as well as many zero-attribute elements. |
| `flat-pipe` | Prefixed names whose raw spelling must be appended to the packed owner; explicit Ends. |
| `empty-pipe` | The same namespace family with empty elements and zero attributes. |
| `nested-pipe` | Sixteen levels of live prefixed stack names. |
| `equal-nul` | Raw `p:n` equals expanded `p:` plus local `n`; no duplicate stack spelling. |
| `triplets-pipe` | Prefixed triplet spelling saved through End delivery. |
| `capacity-2044` | Long unprefixed names under a default namespace; raw spelling shares the expanded suffix, across multiple feeds. |

These are eight predeclared cases,16 matched runs total. The original namespace-off microcases and second long-name boundary are not needed for this bounded diagnostic. They remain in the original study unchanged.

The generated cases retain their existing warmup boundary. The warmup finishes a separate `XML_Parse` invocation; its frame is dropped, while core name/attribute caches survive. Phase2 therefore includes frame recreation with warm core caches. Counts include malloc/realloc/free requests and requested-byte histograms by create/warmup/parse/free phase. `CALL` records expose live bytes and blocks after **each feed**, and the tracker records phase/global peaks and zero live allocations after destruction.

Allocation-request counts are per phase, not per feed. The records do not attribute an individual request to a source line. Maven's two ordinary-attribute nodes provide representative coverage, not an isolated attribute-cost estimate. Long-name results also include ordinary input-buffer growth. These are allocator observations, not elapsed measurements or process RSS.

## Bind after the normal build is verified

`prepare.py` performs saved-file checks and writes the two plans; it executes no targets:

```console
python3 prepare.py --candidate /absolute/path/to/normal/liboriole_expat.so --candidate-sha256 FULL_SHA256
```

The candidate hash must come from root's completed normal-build readback. The historical directory name containing `pgo-study` is only the location of the selected **normal** library; no profile-generation/use artifact is used. The root manifest uses the same 73 keys as V1, including the inherited `tests/c/UPSTREAM-NOTICES.txt`; no legacy 72-entry check applies. Current source and header hashes, original probe/runner identities, tools, fixtures and actual normal libraries are pinned. The completed root build and compiler-vector binding must pass before plans are written.

## Launch only after root releases CPU4

Use the four exact argument vectors in `preparation.json` in order:

1. `selected/run.py build` — one unchanged O1 diagnostic-C compile against selected normal.
2. `selected/collect.py` — eight cases serially.
3. `candidate/run.py build` — identical C recipe against candidate normal.
4. `candidate/collect.py` — the same eight cases serially.

Each vector is wrapped in `taskset -c 4` and pinned CPython3.12.13 `-I -S`. Existing limits remain120seconds per C build,3seconds child alarm/4seconds outer per probe,1GiB address space,8MiB output and2MiB input. Original first-attempt preservation and kill/reap handling remain. Run outside elapsed benchmarks.

Before interpreting allocations, require all16 runs to exit0; all ten API origins must identify the linked normal library, all callbacks must be balanced with equal hashes/counts between engines, feed/count/error progression must agree, and all tracked allocations must be released. Preserve every positive and negative allocation delta.

Original sources: `/tmp/oriole-packed-element-names-allocation-probe/{probe.c,run.py,plan.json}` and `/tmp/oriole-packed-element-names-allocation-collect.py`. Probe and runner are copied byte-for-byte; collector changes only output/root paths. Old outputs are not reused as normal-library measurements.

## Saved V1 comparison

After the two V2-study engines complete, `taskset -c 6 python3 compare.py` reconstructs all 16 new raw probe runs and all 16 saved V1 runs with the same reader. It verifies identical probe/runner bytes, eight input specifications, C compiler and reader tools, bounds, callbacks, and feed schedules. The selected-library replay must be identical apart from origin paths. Every create/warmup/parse/free allocation delta and each feed's live-byte/block delta is reported for V2 versus selected and for V2 versus V1. The latter compares deterministic allocator observations, not paired elapsed samples.
