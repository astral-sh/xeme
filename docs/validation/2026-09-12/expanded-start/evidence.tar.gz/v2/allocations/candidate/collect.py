from pathlib import Path
import hashlib,json,os,signal,subprocess,time
P=Path('/tmp/oriole-expanded-start-capacity-study/allocations/candidate')
R=Path('/tmp/oriole-expanded-start-capacity-study/allocations/candidate/collection.json')
assert not R.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads((P/'plan.json').read_text())
report={'status':'incomplete','plan_sha256':sha(P/'plan.json'),'commands':[]}
def save():R.write_text(json.dumps(report,indent=2)+'\n')
for case in plan['cases']:
 name=case['name']; log=Path('/tmp/oriole-expanded-start-capacity-study/allocations/candidate/'+name+'.stdout')
 cmd=['taskset','-c','4','/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12','-I','-S',str(P/'run.py'),'run','--case',name]
 row={'argv':cmd,'case':name,'started':time.time()};report['commands'].append(row);save()
 with log.open('xb') as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:row['exit']=p.wait(timeout=20)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGKILL);row['exit']=p.wait();row['timeout']=True
 row.update(completed=time.time(),reaped=p.poll() is not None,log_sha256=sha(log));save()
 if row['exit']:
  report['status']='failed';save();raise SystemExit(row['exit'])
 print(name,row['exit'],flush=True)
report['status']='passed';save()
