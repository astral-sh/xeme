# Expanded Start capacity: held compatibility gates

Prepared only. The API/C controller is the prior controller with three path
substitutions: this output directory, the candidate checkout, and its normal
library directory. Original assertions, selection, compiler arguments, resource
limits, cleanup, and raw result comparison are unchanged.

Final saved-only binding passed for normal shared library `a240099f…` and static
archive `f57b02b6…`, reviewed core `30cb2ebf…`, and build receipt `57e8be30…`.
`bound.json` is `6e6c9f2d…`; `strict-pins.json` is `c650baf9…`. Both binders ran
once and exited zero. No API, C-consumer, strict, or semantic target has run here.

## Coverage

- Original 4,740 Expat API configurations: all six chunk modes and both deferral
  settings; 3 seconds per case, 1 GiB address space, 768 MiB RSS, 240-second
  matrix and 300-second outer bound. The comparison baseline has 4,347 passes,
  391 assertion failures and two timeouts. Candidate outcomes are retained and
  compared individually; existing failures are not relabeled as passing.
- Six C consumers: integration, adversarial and allocations, each shared and
  static. Every compilation and execution retains its 120-second bound. C uses
  ASan/UBSan; linked Rust normal-release libraries are uninstrumented, and leak
  detection is disabled as in the prior protocol.

No profile pipeline or profile-built artifact is included. The prior controller
text retains its historical paths solely as source provenance.

## Binding and execution

`pins.json` deliberately does not exist before final source review and normal
build binding, so `api_native.py` cannot launch targets yet. After the reviewed
73-file source map and actual successful `source.json`, `build.json`, and
`build-binding.json` are available, run the saved-only binder on CPU6:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-expanded-start-capacity-correctness/bind.py
```

Root releases the target command after elapsed campaigns and review. Use the
same clean environment as the original gates, with the pinned Python directory
on PATH and no inherited `CC`, `LD_PRELOAD`, or `LD_LIBRARY_PATH` overrides:

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-expanded-start-capacity-correctness/api_native.py
```

The controller creates a fresh `api-native` directory and refuses reuse. Its
report records the API exit independently from the six C-consumer outcomes.
An API exit of one is retained, not hidden; differences from the saved original
matrix are recorded in `api-comparison.json`.

## Separate strict CPython gates

`strict_cpython.py` retains the complete previous shared/static execution loop.
It builds the two XML extensions per linkage with the same explicit upstream
pyexpat allocation-failure cleanup backport. These patched consumers differ
from the unmodified benchmark consumers; benchmark files are not overwritten.
The baseline contains 802 method identities per linkage and two callback
fragmentation failures. Each original strict exit and every test log remain
separate from the supplemental semantic checks.

After `bind.py`, the saved-only strict binder connects the held commands to the
same actual normal shared/static libraries:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-expanded-start-capacity-correctness/bind_strict.py
```

Root may then release this command after the timing campaigns, in the same clean
environment. The original 1,000-second bound per linkage is unchanged:

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-expanded-start-capacity-correctness/strict_cpython.py
```

The unchanged extension loader and import checker verify initial and fresh
imports, accelerator aliases, and intentionally blocked imports. After strict
completion, the saved-only semantic binder checks the actual module hashes,
copied library, loader, original summary, and initial/fresh origin records:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-expanded-start-capacity-correctness/prepare_semantics.py
```

Root executes the resulting two `semantic-commands.json` argv arrays separately.
They run the unchanged two-test `text_fragmentation.py` with the same isolated
loader environment, CPU3, 120-second timeout, and five-second termination grace.
No fragmentation allowance is passed to the original strict suite, and its
raw failures are never turned into a passing result.

The build binders have already completed and create their outputs exclusively;
do not rerun them. Remaining order is root-owned `api_native.py`, then
`strict_cpython.py`, then saved-only `prepare_semantics.py`, then the two separate
semantic command arrays. Retain each target command's stdout, stderr and exit.

The first strict preparation passed. A reviewer misread escaped tool output and
attempted an unnecessary newline change; the second preparation failed AST
parsing before writing generated files. The byte-exact first generator and
metadata are restored, all original pins match, and the newline AST value is
verified. Both preparation attempts remain preserved. No targets ran.
