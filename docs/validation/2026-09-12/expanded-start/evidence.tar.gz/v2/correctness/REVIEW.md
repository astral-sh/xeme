# Final normal-candidate compatibility readback

Completed saved-file audits verify the final `a240099f…` normal shared library,
`f57b02b6…` static archive, and reviewed 73-file source map with core `30cb2ebf…`.
Root ran every target; the preparer and separate runtime reviewer read the saved
outputs on CPU6. Controller-preparation authorship is disclosed in the receipts.

| Gate | Verified outcome |
| --- | --- |
| Original Expat API matrix | All 4,740 ordered outcomes identical: 4,347 passes, 391 assertion failures, two timeouts; raw exit 1 retained |
| C consumers | Integration, adversarial and allocations all pass shared/static: six runs, six builds, all reaped |
| Strict CPython shared | 802 method identities, unchanged outcomes and two failures; raw exit 2 |
| Strict CPython static | 802 method identities, unchanged outcomes and two failures; raw exit 2 |
| Separate text semantics | Both original tests pass in each linkage; two separate exits of 0 |

The strict logs contain **809 rendered outcome lines per linkage**, not 809
distinct methods. Two C14N methods each render four subtest outcomes, adding six
lines, and a skipped `setUpClass` adds one. Fourteen multiline description lines
correspond to existing method identities. Both the 802-method maps and all
809 rendered outcomes match their respective baselines.

The unchanged strict failures are
`test.test_pyexpat.BufferTextTest.test1` and
`test.test_sax.CDATAHandlerTest.test_handlers`. Passing supplemental semantics
does not relabel either strict suite as passing. Strict consumers contain the
explicit pinned upstream pyexpat allocation-failure cleanup backport; benchmark
consumers were unmodified and remain separate.

The audits checked raw API begin/result/assertion records, the actual library
origin marker, input/source/binary hashes, complete manifest bounds, compiler
and linker vectors, command exits and reaping, initial/fresh XML-module origins,
loader behavior, and the exact supplemental argv and output receipts. The API
and C protocol retains its original limits and assertions. C consumers use
ASan/UBSan; the linked Rust normal libraries are uninstrumented and leak
detection is disabled. This establishes the stated compatibility coverage,
not full Rust sanitizer coverage or general production readiness.

Receipts:

- [API/C readback](api-c-readback.json): `c129c892…`.
- [Strict and semantic readback](strict-semantic-readback.json): `f318a291…`.
- [Rendered-line count explanation](strict-rendered-counts-readback.json).

Both full saved readbacks passed on their first attempt; no targets were rerun.
The earlier preparation-only history is preserved separately in `README.md`.
