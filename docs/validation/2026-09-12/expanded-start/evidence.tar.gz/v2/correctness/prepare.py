"""Relocate the existing API/C controller using saved files only."""
from pathlib import Path
from collections import Counter
import ast
import difflib
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
P = Path(__file__).parent
OLD = Path('/tmp/oriole-fused-attribute-scan-correctness-prep')
OLD_WORK = Path('/home/dev-user/code/oss/oriole-fused-attribute-scan')
WORK = Path('/home/dev-user/code/oss/oriole-expanded-start-capacity')
BUILD = Path('/tmp/oriole-expanded-start-capacity-study')
BASE = Path('/tmp/oriole-reference-frame-api-gates/api-native/upstream-api')
PYTHON = Path('/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12')
TOOLS = ['run.py', 'runner.c', 'bridge.c', 'bridge.h', 'memcheck.patch', 'README.md', 'allocator_repro.c']
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())

def save(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

old_pins = load(OLD / 'pins.json')
before = (OLD / 'api_native.py').read_text()
assert sha(OLD / 'api_native.py') == old_pins[str(OLD / 'api_native.py')]
replacements = [
    (str(OLD), str(P)),
    (str(OLD_WORK), str(WORK)),
    ('/tmp/oriole-fused-attribute-scan-pgo-study/pgo/runs/run-w7b8o8j1/use', str(BUILD / 'normal')),
]
after = before
for old, new in replacements:
    assert old in after
    after = after.replace(old, new)
inverse = after
for old, new in reversed(replacements):
    inverse = inverse.replace(new, old)
assert inverse == before
ast.parse(after)
(P / 'prior').mkdir(exist_ok=False)
(P / 'prior/api_native.py').write_text(before)
(P / 'api_native.py').write_text(after)
(P / 'api_native.py.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile=str(OLD / 'api_native.py'), tofile=str(P / 'api_native.py'))))
pins = {}
for path in [PYTHON, BASE / 'results.json', BASE / 'manifest.json', BASE / 'tests.log', BASE / 'adapted/expat_config.h', Path('/tmp/oriole-unique-accounting-evidence/api-tools/run_clean.py')]:
    assert sha(path) == old_pins[str(path)]
    pins[str(path)] = sha(path)
for name in TOOLS:
    path = WORK / 'tools/upstream-expat' / name
    assert sha(path) == old_pins[str(OLD_WORK / 'tools/upstream-expat' / name)]
    pins[str(path)] = sha(path)
for name in ['integration', 'adversarial', 'allocations']:
    path = WORK / 'tests/c' / (name + '.c')
    assert sha(path) == old_pins[str(OLD_WORK / 'tests/c' / (name + '.c'))]
    pins[str(path)] = sha(path)
path = WORK / 'include/expat.h'
assert sha(path) == old_pins[str(OLD_WORK / 'include/expat.h')]
pins[str(path)] = sha(path)
for name in ['prepare.py', 'bind.py', 'api_native.py', 'prior/api_native.py']:
    ast.parse((P / name).read_text())
    pins[str(P / name)] = sha(P / name)
rows = []
for line in (BASE / 'tests.log').read_text().splitlines():
    if line.startswith('ORIOLE_RESULT\t'):
        _, context, test, outcome, code = line.split('\t')
        rows.append({'context': context, 'test': test, 'outcome': outcome, 'code': int(code)})
assert rows == load(BASE / 'results.json')['results'] and len(rows) == 4740
counts = dict(Counter(row['outcome'] for row in rows))
assert counts == {'pass': 4347, 'fail': 391, 'timeout': 2}
manifest = load(BASE / 'manifest.json')
assert (manifest['chunks'], manifest['deferral']) == ([0, 1, 2, 3, 4, 5], [0, 1])
assert (manifest['per_test_seconds'], manifest['per_test_address_space_bytes'], manifest['per_test_rss_limit_bytes'], manifest['total_timeout_seconds']) == (3, 1024**3, 768 * 1024**2, 240)
save(P / 'static-pins.json', pins)
previous = load(OLD / 'preparation.json')
save(P / 'preparation.json', {
    'status': 'held_pending_reviewed_source_and_actual_normal_build_binding',
    'targets_executed': False,
    'controller': {'path': str(P / 'api_native.py'), 'sha256': sha(P / 'api_native.py'), 'origin': str(OLD / 'api_native.py'), 'origin_sha256': sha(OLD / 'api_native.py'), 'inverse_text_equal': True, 'replacements': replacements},
    'worktree': str(WORK), 'build_directory': str(BUILD),
    'pending': ['reviewed-source.json', 'source.json', 'build.json', 'build-binding.json', 'normal/liboriole_expat.so', 'normal/liboriole_expat.a'],
    'api': previous['api'], 'c_consumers': previous['c_consumers'],
    'baseline_api_outcomes': counts,
    'static_pins_sha256': sha(P / 'static-pins.json'),
    'scope': 'API/C-only path relocation. Original public test assertions, selection, ceilings, timeout accounting and raw differences unchanged. No profile pipeline, profile metadata or profile-built artifact is copied or bound. Prior controller text is retained solely as source provenance.',
})
print(json.dumps({'status': 'prepared_held', 'preparation_sha256': sha(P / 'preparation.json'), 'static_pins': len(pins), 'targets_executed': False}))
