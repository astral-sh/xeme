"""Prepare the existing patched strict and separate semantic gates; no targets."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
P = Path(__file__).parent
OLD = Path('/tmp/oriole-fused-attribute-scan-correctness-prep')
OLD_WORK = Path('/home/dev-user/code/oss/oriole-fused-attribute-scan')
WORK = Path('/home/dev-user/code/oss/oriole-expanded-start-capacity')
BASE = Path('/tmp/oriole-reference-frame-strict-cpython')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())

def save(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

old_pins = load(OLD / 'pins.json')
before = (OLD / 'strict_cpython.py').read_text()
assert sha(OLD / 'strict_cpython.py') == old_pins[str(OLD / 'strict_cpython.py')]
marker = 'try:\n    for linkage'
suffix = before[before.index(marker):]
prefix = '''"""Strict patched CPython shared/static consumers of the normal candidate."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time
ROOT=Path(__file__).parent/'strict-cpython'
WORK=Path('/home/dev-user/code/oss/oriole-expanded-start-capacity')
BUILD=Path('/tmp/oriole-expanded-start-capacity-study')
BASELINE=Path('/tmp/oriole-reference-frame-strict-cpython')
PYTHON='/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert __debug__ and os.sched_getaffinity(0)=={3}
pins=json.loads((Path(__file__).parent/'strict-pins.json').read_text());assert all(sha(p)==h for p,h in pins.items())
bound=json.loads((Path(__file__).parent/'bound.json').read_text())
assert bound['status']=='bound_not_executed'
source=json.loads((BUILD/'source.json').read_text())
baseline_report=json.loads((BASELINE/'report.json').read_text())
assert baseline_report['status']=='completed_strict_results' and baseline_report['pins_unchanged']
baseline_source={'candidate_base_commit':baseline_report['source_commit']}
library_dir=BUILD/'normal'
provenance=json.loads((WORK/'integration/python-build-standalone/consumer-fix/provenance.json').read_text())
assert provenance['patched_source_sha256']=='1c3cf2ee6dfa568cf833742ad786880f4816042705689a116a4f308b7a9d95f2'
for linkage,extension in [('shared','so'),('static','a')]:
 p=library_dir/('liboriole_expat.'+extension);assert sha(p)==pins[str(p)]==bound['libraries'][extension]['sha256']
 b=json.loads((BASELINE/linkage/'summary.json').read_text());assert b['text_fragmentation'] is None and b['consumer_fix']==provenance and b['tests_exit_code']==b['gate_exit_code']==2
ROOT.mkdir(exist_ok=False)
report={'status':'incomplete','pins':pins,'commands':[],'source_commit':source['base'],'source_manifest_sha256':sha(BUILD/'source.json'),'source_identity':'Reviewed73-file candidate snapshot; base commit alone does not identify changed bytes','baseline_source_commit':baseline_source['candidate_base_commit'],'compiler_treatment':'Normal generic O3/ThinLTO/cgu1 parser, identical O2 CPython extension recipe','scope':'Original strict suites with the explicit pinned upstream pyexpat allocation-failure cleanup backport. Shared/static execution loop, raw exits, loader checks and comparisons unchanged. No text-fragmentation allowance or allocator override. These patched consumers are distinct from the unmodified benchmark consumers.'}
def save():(ROOT/'report.json').write_text(json.dumps(report,indent=2)+'\n')

'''
after = prefix + suffix
assert after[after.index(marker):] == suffix
assert '--allow-text-fragmentation' not in after and '--system-allocator' not in after
ast.parse(after)
(P / 'prior/strict_cpython.py').write_text(before)
(P / 'strict_cpython.py').write_text(after)
(P / 'strict_cpython.py.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile=str(OLD / 'strict_cpython.py'), tofile=str(P / 'strict_cpython.py'))))
semantic_before = (OLD / 'prepare_semantics.py').read_text()
assert sha(OLD / 'prepare_semantics.py') == old_pins[str(OLD / 'prepare_semantics.py')]
semantic_after = semantic_before.replace("P / 'pins.json'", "P / 'strict-pins.json'")
assert semantic_after.replace("P / 'strict-pins.json'", "P / 'pins.json'") == semantic_before
(P / 'prior/prepare_semantics.py').write_text(semantic_before)
(P / 'prepare_semantics.py').write_text(semantic_after)
methods = (OLD / 'methods.py').read_text()
assert sha(OLD / 'methods.py') == old_pins[str(OLD / 'methods.py')]
(P / 'methods.py').write_text(methods)
pins = {}
for name in ['run.py', 'extension_loader.py', 'check_extension_imports.py', 'text_fragmentation.py', 'test_run.py']:
    path = WORK / 'tools/cpython' / name
    assert sha(path) == old_pins[str(OLD_WORK / 'tools/cpython' / name)]
    pins[str(path)] = sha(path)
for name in ['provenance.json', 'cpython-3.12.13-external-parser.patch']:
    path = WORK / 'integration/python-build-standalone/consumer-fix' / name
    assert sha(path) == old_pins[str(OLD_WORK / 'integration/python-build-standalone/consumer-fix' / name)]
    pins[str(path)] = sha(path)
for path in [BASE / 'report.json', *[BASE / mode / name for mode in ['shared', 'static'] for name in ['summary.json', 'tests.log', 'origin.log', 'pyexpat.c']], *[Path('/home/dev-user/.cache/oriole/upstream/cpython-3.12.13/Modules') / name for name in ['pyexpat.c', '_elementtree.c']], *[Path('/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/include/python3.12') / name for name in ['Python.h', 'pyconfig.h']]]:
    assert sha(path) == old_pins[str(path)]
    pins[str(path)] = sha(path)
namespace = {'read': lambda p: Path(p).read_bytes()}
exec(compile(methods, str(P / 'methods.py'), 'exec'), namespace)
baseline_outcomes = {}
for mode in ['shared', 'static']:
    outcomes = namespace['methods'](BASE / mode / 'tests.log')
    assert len(outcomes) == 802
    failures = {name: value for name, value in outcomes.items() if value in ['FAIL', 'ERROR']}
    assert failures == {'test.test_pyexpat.BufferTextTest.test1': 'FAIL', 'test.test_sax.CDATAHandlerTest.test_handlers': 'FAIL'}
    baseline_outcomes[mode] = {'methods': 802, 'failures': failures, 'raw_exit': 2}
template = load(OLD / 'semantic-commands-template.json')
for command in template['commands']:
    for key in ['argv']:
        command[key] = [value.replace(str(OLD), str(P)).replace(str(OLD_WORK), str(WORK)) for value in command[key]]
    for key in ['cwd', 'stdout', 'stderr', 'strict_directory']:
        command[key] = command[key].replace(str(OLD), str(P)).replace(str(OLD_WORK), str(WORK))
    command['expected_library_sha256'] = None
    command['status'] = 'held_pending_normal_build_and_fresh_strict_origin_binding'
template['script'] = str(WORK / 'tools/cpython/text_fragmentation.py')
assert sha(template['script']) == template['script_sha256']
template['status'] = 'held_pending_normal_build_binding'
save(P / 'semantic-commands-unbound.json', template)
for name in ['prepare_strict.py', 'bind_strict.py', 'strict_cpython.py', 'prepare_semantics.py', 'methods.py', 'prior/strict_cpython.py', 'prior/prepare_semantics.py']:
    ast.parse((P / name).read_text())
    pins[str(P / name)] = sha(P / name)
pins[str(P / 'semantic-commands-unbound.json')] = sha(P / 'semantic-commands-unbound.json')
save(P / 'strict-static-pins.json', pins)
save(P / 'strict-preparation.json', {'status': 'prepared_held_pending_normal_build', 'targets_executed': False, 'controller_origin': str(OLD / 'strict_cpython.py'), 'controller_origin_sha256': sha(OLD / 'strict_cpython.py'), 'controller_sha256': sha(P / 'strict_cpython.py'), 'complete_shared_static_execution_loop_byte_exact': True, 'baseline': str(BASE), 'baseline_outcomes': baseline_outcomes, 'consumer_fix': load(WORK / 'integration/python-build-standalone/consumer-fix/provenance.json'), 'static_pins_sha256': sha(P / 'strict-static-pins.json'), 'scope': 'Separate patched CPython shared/static strict gates with exact original suite argv/limits/loader and fresh origin checks; two supplemental semantic tests per linkage remain separate. No benchmark extension is overwritten or relabeled. No profile pipeline or artifact binding.'})
print(json.dumps({'status': 'prepared_held', 'strict_preparation_sha256': sha(P / 'strict-preparation.json'), 'static_pins': len(pins), 'targets_executed': False}))
