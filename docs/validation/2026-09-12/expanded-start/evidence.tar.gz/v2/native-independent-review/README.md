# Capacity-guarded expanded Start: independent native readback

The completed normal-release campaign reconstructs exactly from all 672 raw
workers and 106,176 samples: 84 preflight workers, 588 timed workers, 588 timed
warmups, and 105,420 measured samples. All 28 conditions, seven seeded pairs per
condition, actual driver arguments, source/library/input hashes, callback
observations, process medians, and paired ratios match the saved producer results.
The saved-only reader passed on its first attempt.

| Conditions | Candidate / selected control | Candidate / Expat | Faster than control |
| --- | ---: | ---: | ---: |
| All 24 real-project conditions | 0.96600939 | 1.54244242 | 22/24 |
| 12 real, namespaces enabled | 0.94296654 | 1.59560470 | 10/12 |
| 12 real, namespaces disabled | 0.98961532 | 1.49105141 | 12/12 |
| Four generated controls | 0.96249294 | 3.89382318 | 2/4 |

Every adverse condition is retained:

| Condition | Chunk bytes | Candidate / control |
| --- | ---: | ---: |
| Batik, namespaces enabled | 4,096 | 1.00889369 |
| GTK, namespaces enabled | 4,096 | 1.00245856 |
| Generated rare declarations | 4,096 | 1.00333030 |
| Generated rare declarations | 65,536 | 1.00925991 |

The real-project aggregate is 3.40% faster than the selected control, while
remaining 1.54× Expat. Generated aggregate improvement does not erase its two
rare-declaration regressions. [conditions.csv](conditions.csv) contains all
28 conditions; [review.json](review.json) retains every paired ratio and full
identities. No direct paired V2-versus-V1 comparison was measured: V1 supplied
the controller and reader templates only.

Ratios are medians of seven paired process-median ratios, followed by an equally
weighted geometric mean across the stated conditions. This is one normal-release
campaign, without statistical-significance or whole-application claims. Callback
hashes combine text fragments, so equality does not establish exact fragmentation.
The unchanged driver explicitly loads each recorded library path; no new dynamic
origin probe was added.

Candidate library is `a240099f…`, selected normal control `087d131c…`, and normal
Expat `7a333bc8…`. The reviewed 73-file source map has base `8c039ec6…` and core
`30cb2ebf…`. Historical directory names do not change the normal-release scope.

Root ran the targets. A separate source reviewer adapted and ran the saved-file
reader on CPU6; its raw reconstruction and ratio calculations are byte-identical
to the completed V1 reader. Python elapsed outputs were not read, and no compiler,
parser, profiler, or benchmark target was executed by this audit.
