# Current fused attribute scanner — normal-only candidate

Prepared at `/home/dev-user/code/oss/oriole-fused-normal-current`, branch `charlie/codex-oriole-fused-normal-current`, base `4815cf78d7419a18df8d698aaae0bbde8daa526f`. **Unselected; no commit or push.**

Only `crates/oriole/src/tag.rs` changes. It is byte-identical to the final previously reviewed scanner (`50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6`), including its focused tests. `source.json` binds all 73 files and `candidate.patch` is the complete current-base diff. Every other source byte, including the namespace frame and capacity refinement, matches the current baseline.

## Semantics assessment

The native planner fuses quote/less-than delimiter scanning with an ordinary-ASCII value proof, so proven attributes skip the later eligibility walk. General scanning delegates through the original false specialization. No parser coordinate, namespace expansion, callback publication, allocation policy, persistent cache or external C interface is changed.

The per-value flag resets at the opening quote and survives incomplete or empty feeds. An eight-byte clear mask proves only ordinary ASCII; nonzero masks use scalar handling, never a propagated bit as an offset. Delimiters are handled before byte classification. Once a special/non-ASCII byte occurs, the original delimiter search and complete-value predicate decide eligibility. It must never turn a valid Unicode plan into an unconditional fallback or fall back before the original delimiter boundary. Record capacity and token/attribute limits keep their order, and failed plans remain disabled until the source advances.

The seven focused tests cover scalar/mask and Unicode boundaries, incremental step equality and repeated empty resumes, valid Unicode plan completion, ampersand-to-delimiter fallback timing, complete grammar/error prefixes, every-split records, name rules and source-generation reset. The source imports the existing tests unchanged; no tests or source beyond tag.rs were added.

This assessment is by the preparer reusing the exact prior implementation; root arranges independent current-composition review. Earlier source-specific timing/compatibility is not evidence that this composition passes or improves performance. The old normal-Python arm never ran. Root plans the same unmodified normal CPython consumer gate first; no new training or compiler-flag experiment is part of this candidate.

## Completed commands

Worktree import used `cargo +ohm worktree add` from the existing capacity checkout with its own source target, the distinct new target, and the separate shared Ohm build template. Real/common Git paths and OSS email were checked before writes. The explicit shared-Git write received tool approval; the import completed on its first attempt and seeded no compatible build snapshot. Worktree session 89531 completed and was reaped with exit 0.

Focused checks used CPU4, `cargo +ohm -Zohm-defaults=no`, CARGO_HOME `/home/dev-user/.cache/toucan/cargo`, CARGO_TARGET_DIR `/home/dev-user/.cache/oriole/fused-normal-current-target`, CARGO_BUILD_BUILD_DIR `/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}`, jobs 1, incremental 0 and empty encoded flags. Both import trust-all variables and inherited compiler/profile overrides were cleared.

- `cargo +ohm -Zohm-defaults=no fmt --all -- --check`: exit 0; exact scanner bytes unchanged.
- `cargo +ohm -Zohm-defaults=no test -p oriole --lib tag::tests`: 7 passed, 0 failed/ignored, 66 filtered; exit 0.

Check session 98410 completed and was reaped with exit 0. `checks.json` retains argv, environment, bounds, exits/reaping and both raw log hashes; `worktree.json` records the import separately. No failed attempts occurred.

Full workspace checks, strict Clippy, normal release build, compatibility and elapsed consumers have not run on this candidate in this preparer step. Root owns those gates. No PGO work, elapsed run, commit or push was performed.
