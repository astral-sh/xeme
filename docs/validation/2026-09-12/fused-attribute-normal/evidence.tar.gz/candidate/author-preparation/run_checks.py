from pathlib import Path
import hashlib,json,os,signal,subprocess,time
ROOT=Path(__file__).parent
WORK=Path('/home/dev-user/code/oss/oriole-fused-normal-current')
assert os.sched_getaffinity(0)=={4}
env=os.environ.copy()
cleared=['RUSTFLAGS','RUSTC','RUSTUP_TOOLCHAIN','LLVM_PROFILE_FILE','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']
for key in cleared:env.pop(key,None)
assert not any(k.startswith('CARGO_PROFILE_') for k in env)
overrides={'CARGO_HOME':'/home/dev-user/.cache/toucan/cargo','CARGO_TARGET_DIR':'/home/dev-user/.cache/oriole/fused-normal-current-target','CARGO_BUILD_BUILD_DIR':'/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}','CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_ENCODED_RUSTFLAGS':'','RUSTC_WRAPPER':'','RUSTC_WORKSPACE_WRAPPER':'','CARGO_TERM_COLOR':'never','RUSTUP_AUTO_INSTALL':'0'}
env.update(overrides)
base=['cargo','+ohm','-Zohm-defaults=no']
commands=[('fmt-attempt01',base+['fmt','--all','--','--check']),('scanner-tests-attempt01',base+['test','-p','oriole','--lib','tag::tests'])]
report={'status':'incomplete','cleared_environment':cleared,'environment_overrides':overrides,'commands':[]}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save():(ROOT/'checks.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 for label,argv in commands:
  row={'label':label,'argv':argv,'cwd':str(WORK),'start':time.time(),'timeout_seconds':600};report['commands'].append(row);save()
  proc=None;out=ROOT/(label+'.stdout');err=ROOT/(label+'.stderr')
  with out.open('wb') as stdout,err.open('wb') as stderr:
   try:
    proc=subprocess.Popen(argv,cwd=WORK,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
    row['exit']=proc.wait(timeout=600)
    if row['exit']:raise RuntimeError(f'{label} exited {row["exit"]}')
   except BaseException as e:
    row['exception']=repr(e)
    if proc is not None:
     try:os.killpg(proc.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     row['exit']=proc.wait()
    raise
   finally:
    stdout.flush();stderr.flush();row.update(end=time.time(),reaped=proc is not None and proc.poll() is not None,stdout_sha256=sha(out),stderr_sha256=sha(err));save()
  print(label,row['exit'],flush=True)
 report['status']='passed'
except BaseException as e:
 report['status']='failed';report['failure']=repr(e);raise
finally:save()
