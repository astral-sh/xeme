# Current fused scanner: normal compatibility gates

Prepared and held for root execution. This directly adapts the completed expanded-Start capacity controllers; only current source/output/normal-library paths change. The saved binder understands the current source/build review schema. The strict reader additionally asserts the existing809 rendered-line oracle alongside the unchanged802-method map. Original controller source and readable patches are in `prior/` and `*.patch`.

Candidate shared library: `dca62e60f80e311fbb529e66262fd2f7f07d8f38eda16c97cd33aa9dd8063488`; static archive: `4a234408cbbf49691e9aaae52b9973cfe4e45d7708eab2fff65521314ca84e8f`. Both are completed normal generic O3/ThinLTO/cgu1 artifacts. Source has73 pins and only `tag.rs` differs from current4815cf7. No parser rebuild or profile campaign is included.

## Gates and retained failures

- Original4,740 API configurations retain3s/case,1GiB address space,768MiB RSS,240s matrix and300s outer bounds. Baseline4,347pass/391assertion failures/2timeouts; all ordered rows are compared, raw exit1 preserved.
- Six C consumers: integration, adversarial and allocations, dynamic/static. Each compile/run retains120s. C ASan/UBSan, uninstrumented normal Rust, leak checking disabled. Compile/link metadata and raw results retained; no new in-process dladdr claim.
- Strict CPython shared/static retains the explicit upstream pyexpat allocation-failure cleanup backport,1,000s/linkage and complete original suite. Baseline802method identities and809rendered outcomes per linkage, raw exit2 with `BufferTextTest.test1` and `CDATAHandlerTest.test_handlers` failures. These patched strict consumers are separate from unmodified benchmark modules.
- Two existing text-semantic tests per linkage run separately after exact fresh module/origin binding;120s plus5s termination grace/130s outer. They never relabel strict failures as passing.

## Parent launch order

Use the pinned interpreter `/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12`. Run in the existing clean environment with its bin directory plus `/usr/bin:/bin` on PATH and compiler/allocator/loader overrides cleared. Each output is single-use; stop on any failed binder or controller.

1. CPU6 saved-only: `python3.12 -I -S bind.py`, then `python3.12 -I -S bind_strict.py` (both require `taskset -c 6`).
2. CPU3 target: `python3.12 -I -S api_native.py` (`taskset -c 3`; the controller also pins its children). Then CPU6 saved-only `read_api_c.py` after all children are reaped.
3. CPU3 target: `python3.12 -I -S strict_cpython.py` (requires `taskset -c 3`). After reaping, CPU6 saved-only `prepare_semantics.py` binds fresh modules/loader/origins.
4. CPU3 targets: `python3.12 -I -S run_semantic.py shared`, then `python3.12 -I -S run_semantic.py static`; each uses the original isolated command from `semantic-commands.json`.
5. CPU6 saved-only: `python3.12 -I -S read_strict_semantics.py` reconstructs both full method maps, all809rendered lines, compiler/import records and four supplemental semantic outcomes.

All relative script names above are under `/tmp/oriole-fused-normal-current-correctness`. Root owns every target and final saved-result release. Preparation executed no compiler, parser, strict or semantic target. The prior reference-frame baseline is retained because its ordered API and strict outcomes were also verified unchanged by current PR154; it is not a current performance comparator.
