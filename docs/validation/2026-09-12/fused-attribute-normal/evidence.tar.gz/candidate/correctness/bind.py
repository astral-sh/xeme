"""Bind reviewed source and completed normal artifacts; never execute targets."""
from pathlib import Path
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
P = Path(__file__).parent
B = Path('/tmp/oriole-fused-normal-current-study')
W = Path('/home/dev-user/code/oss/oriole-fused-normal-current')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
pins = load(P / 'static-pins.json')
assert all(sha(path) == value for path, value in pins.items())
review = load(P / 'reviewed-source.json')
source, build, binding = (load(B / name) for name in ['source.json', 'build.json', 'build-binding.json'])
assert review['status'] == 'passed_source_review_no_actionable_findings'
assert source['worktree'] == str(W) and len(source['sha256']) == 73
assert review['source_manifest_sha256'] == sha(B / 'source.json')
assert review['source_count'] == 73 and review['changed_files'] == ['crates/oriole/src/tag.rs']
assert build['status'] == binding['status'] == 'passed' and build['source_unchanged']
assert binding['build_sha256'] == sha(B / 'build.json')
assert binding['source_manifest_sha256'] == sha(B / 'source.json')
assert binding['source_count'] == 73
assert set(binding['compiler_vectors_normalized']) == {'oriole_storage', 'oriole', 'oriole_expat'}
for vector in binding['compiler_vectors_normalized'].values():
    assert 'opt-level=3' in vector and 'codegen-units=1' in vector
    assert vector[vector.index('--target') + 1] == 'x86_64-unknown-linux-gnu'
    assert not any('profile-generate' in value or 'profile-use' in value or 'target-cpu' in value for value in vector)
assert 'lto=thin' in binding['compiler_vectors_normalized']['oriole_expat']
libraries = {}
for suffix in ['so', 'a']:
    name = 'liboriole_expat.' + suffix
    path = B / 'normal' / name
    value = sha(path)
    assert value == binding['candidate_libraries'][name]
    libraries[suffix] = {'path': str(path), 'sha256': value}
    pins[str(path)] = value
for name, value in source['sha256'].items():
    assert sha(W / name) == value
    pins[str(W / name)] = value
for path in [P / 'preparation.json', P / 'static-pins.json', P / 'reviewed-source.json', B / 'source.json', B / 'build.json', B / 'build-binding.json']:
    pins[str(path)] = sha(path)
assert not (P / 'api-native').exists()
assert all(sha(path) == value for path, value in pins.items())
with (P / 'pins.json').open('x') as stream:
    stream.write(json.dumps(pins, indent=2) + '\n')
with (P / 'bound.json').open('x') as stream:
    stream.write(json.dumps({'status': 'bound_not_executed', 'targets_executed': False, 'source_sha256': sha(B / 'source.json'), 'build_binding_sha256': sha(B / 'build-binding.json'), 'libraries': libraries, 'pins_sha256': sha(P / 'pins.json'), 'scope': 'Normal generic O3/ThinLTO/cgu1 API and six C consumers. Root owns release and execution.'}, indent=2) + '\n')
print(json.dumps({'status': 'bound_not_executed', 'bound_sha256': sha(P / 'bound.json'), 'pins': len(pins), 'libraries': libraries}))
