# Current fused scanner: normal native preparation

Prepared only. Candidate `dca62e60…`, current expanded Start capacity control `a240099f…`, and unchanged normal Expat `7a333bc8…` use the existing faithful native C driver. No binary is rebuilt here.

The current capacity protocol is retained: all 24 real project conditions plus four generated controls, 4/64 KiB input chunks, seven seeded pairs (`2026091003`), unchanged per-project iterations, engine shuffling and process medians. There are 84 preflight workers, 588 timed workers and 106,176 total samples. Each native sample times parser creation, handler registration, feed/finalization, callbacks and destruction. The original driver loads the exact library path with `dlopen`; saved readers check path/hash/version and callback observations, with no new `dladdr` claim.

`run.py` is byte-identical. `native_screen.py` changes only library/output paths and explanatory labels; its worker, scheduling and measurement body are byte-identical. The saved reader preserves every raw worker, sample, median, ratio and adverse-condition check, with source/library bindings updated to this candidate. It retains the current core namespace optimization and checks all 73 source hashes.

Root may launch after the completed Python outcome and independent source review:

```sh
python3 /tmp/oriole-fused-normal-current-study/native/run.py
taskset -c 6 python3 /tmp/oriole-fused-normal-current-study/native/read_results.py
```

The wrapper runs preflight on CPU5 (600-second limit), then native timing exclusively on CPU0 (1,200-second limit); each worker retains its 90-second limit. Timeout/interruption kills and waits for the process group. The output directory is single-use. Saved review runs on CPU6. No compiler, parser preflight or elapsed target has run during preparation.
