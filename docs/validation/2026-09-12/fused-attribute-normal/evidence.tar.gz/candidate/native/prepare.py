"""Prepare current-source normal native protocol and saved reader; no targets."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
D = Path(__file__).parent
P = Path('/tmp/oriole-expanded-start-capacity-study/native')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
def save(p,v):
    with p.open('x') as f: f.write(json.dumps(v,indent=2)+'\n')
def replace(s,old,new):
    assert s.count(old)==1,(old,s.count(old))
    return s.replace(old,new)

build = load(D.parent/'build.json'); binding = load(D.parent/'build-binding.json')
source = load(D.parent/'source.json'); baseline = load(P.parent/'source.json')
assert build['status']==binding['status']=='passed'
assert sha(D.parent/'build-binding.json')=='0f15c7a9e45b9ee1159f2962e4dfbaa46b893f646888901ab422d1c3333e25da'
assert binding['build_sha256']==sha(D.parent/'build.json')
assert binding['source_manifest_sha256']==sha(D.parent/'source.json')
assert binding['control_source_manifest_sha256']==sha(P.parent/'source.json')
assert source['base']=='4815cf78d7419a18df8d698aaae0bbde8daa526f'
assert source['sha256'].keys()==baseline['sha256'].keys() and len(source['sha256'])==73
delta={n:{'control':baseline['sha256'][n],'candidate':h} for n,h in source['sha256'].items() if baseline['sha256'][n]!=h}
assert set(delta)=={'crates/oriole/src/tag.rs'} and delta==binding['source_delta']
for record in (source,baseline):
    for n,h in record['sha256'].items(): assert sha(Path(record['worktree'])/n)==h,n

a0 = load(P/'adaptation.json')
changes=[('/tmp/oriole-expanded-start-capacity-study/native',str(D)),
         ("'control': Path('/tmp/oriole-reference-frame-pgo-study/normal/liboriole_expat.so')", "'control': Path('/tmp/oriole-expanded-start-capacity-study/normal/liboriole_expat.so')"),
         ("'candidate': Path('/tmp/oriole-expanded-start-capacity-study/normal/liboriole_expat.so')", "'candidate': Path('/tmp/oriole-fused-normal-current-study/normal/liboriole_expat.so')"),
         ('Capacity-guarded expanded namespace Start','current-source fused attribute scan'),
         ('selected direct-reference-frame baseline','selected expanded Start capacity baseline')]
old=(P/'native_screen.py').read_text();new=old
for before,after in changes:
    assert before in new,before
    new=new.replace(before,after)
restored=new
for before,after in reversed(changes): restored=restored.replace(after,before)
assert restored==old and ast.dump(ast.parse(restored))==ast.dump(ast.parse(old))
marker='def run(condition, engine, pair, cpu, count):'
assert new[new.index(marker):]==old[old.index(marker):]
(D/'native_screen.py').write_text(new)
(D/'run.py').write_bytes((P/'run.py').read_bytes())
(D/'native_screen.py.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(P/'native_screen.py'),tofile=str(D/'native_screen.py'))))

a={k:a0[k] for k in ('mode','external_input_hashes','conditions','pairs','seed','counts')}
a.update(status='passed',execution_status='unexecuted',origin=str(P),
    parent_files={n:sha(P/n) for n in ('run.py','native_screen.py')},files={n:sha(D/n) for n in ('run.py','native_screen.py')},
    changes={'run.py':[],'native_screen.py':changes},inverse_text_and_ast_equal=True,
    libraries={'candidate':{'path':str(D.parent/'normal/liboriole_expat.so'),'sha256':binding['candidate_libraries']['liboriole_expat.so']},
               'control':{'path':str(P.parent/'normal/liboriole_expat.so'),'sha256':binding['control_libraries']['liboriole_expat.so']},
               'expat':a0['libraries']['expat']},
    selected_normal_protocol={'path':str(P/'native-screen/protocol.json'),'sha256':sha(P/'native-screen/protocol.json')},
    candidate_source=source['worktree'],source_delta=delta,
    source_scope='One runtime/test file tag.rs changes across all73 current source manifest keys. Current namespace expanded Start and capacity refinement unchanged.',
    comparison_scope='Current fused candidate versus current expanded Start capacity normal control and unchanged normal Expat.',
    scope='Normal generic parser builds only; no driver rebuild or measurement change. Original28conditions/7pairs/seed/worker iterations/driver/callback checks/bounds retained; all outputs pending.',
    binding_review=str(D.parent/'build-binding.json'))
for key,name in (('candidate_source_record','source.json'),('candidate_build_record','build.json')):
    a[key]={'path':str(D.parent/name),'sha256':sha(D.parent/name)}
for v in a['libraries'].values(): assert sha(v['path'])==v['sha256']
for p,h in a['external_input_hashes'].items(): assert sha(p)==h,p
assert a['conditions']==load(a['selected_normal_protocol']['path'])['conditions']
save(D/'adaptation.json',a)

origin=Path('/tmp/oriole-expanded-start-capacity-native-review/read.py')
reader=origin.read_text().replace("ROOT = Path('/tmp/oriole-expanded-start-capacity-study')", "ROOT = Path('/tmp/oriole-fused-normal-current-study')")
reader=reader.replace("'a240099fb67c83495c15cb50054d08d4abfc16aec699237f08ca606f90bb95bb'", "'dca62e60f80e311fbb529e66262fd2f7f07d8f38eda16c97cd33aa9dd8063488'").replace("'087d131c215012d2a93527a4ec66a716216e8ab4009948a1f79d0a7644d5d949'", "'a240099fb67c83495c15cb50054d08d4abfc16aec699237f08ca606f90bb95bb'")
reader=reader.replace("'8c039ec6c24797c516312a277d0e102c0768f077'", "'4815cf78d7419a18df8d698aaae0bbde8daa526f'")
reader=replace(reader,"assert binding['source']['count'] == 73 and binding['source']['additional_inherited_notice'] == 'tests/c/UPSTREAM-NOTICES.txt'", "assert binding['source_count'] == 73 and set(binding['source_delta']) == {'crates/oriole/src/tag.rs'}")
reader=reader.replace("binding['source']['source_sha256']", "binding['source_manifest_sha256']")
reader=replace(reader,"assert binding['adaptation_sha256'][str(NATIVE / 'adaptation.json')] == sha(NATIVE / 'adaptation.json')", "preparation = load(NATIVE / 'preparation.json')\nassert preparation['status'] == 'prepared_no_targets'\nfor path, expected in preparation['pins'].items(): assert sha(path) == expected, path")
reader=replace(reader,'Separate source reviewer authored and ran this saved-file reader; root ran targets.', 'Controller preparer adapted this existing saved-file reader; root owns target and reader execution.')
reader=replace(reader,'Reuse the completed V1 reader with study/base/runtime/library substitutions and current reporting scope only. Original raw reconstruction and all ratios unchanged. V1 is the template origin, not a paired timing control.', 'Reuse the completed current capacity reader with study/base/library/source-binding substitutions and reporting scope only. Original raw reconstruction, worker counts, all ratios and adverse conditions unchanged.')
ast.parse(reader)
(D/'read_results.py').write_text(reader)
(D/'read_results.py.patch').write_text(''.join(difflib.unified_diff(origin.read_text().splitlines(True),reader.splitlines(True),fromfile=str(origin),tofile=str(D/'read_results.py'))))

pins={str(p):sha(p) for p in sorted(D.iterdir()) if p.is_file()}
for p in (D.parent/'build.json',D.parent/'source.json',D.parent/'build-binding.json',P/'adaptation.json',P/'run.py',P/'native_screen.py',origin,Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')): pins[str(p)]=sha(p)
result={'status':'prepared_no_targets','targets_executed':False,'pins':pins,'source_delta':delta,
        'run_unchanged':True,'native_worker_and_all_measurement_code_unchanged':True,
        'counts':a['counts'],'release_command_held':['python3',str(D/'run.py')],
        'saved_reader_command':['taskset','-c','6','python3',str(D/'read_results.py')]}
save(D/'preparation.json',result)
print(json.dumps({'status':result['status'],'preparation_sha256':sha(D/'preparation.json'),'controller_sha256':sha(D/'native_screen.py'),'reader_sha256':sha(D/'read_results.py'),'counts':a['counts']}))
