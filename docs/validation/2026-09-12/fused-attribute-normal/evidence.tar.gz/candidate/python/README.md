# Current fused scanner: normal CPython preparation

Prepared, not executed. Compare the one-file fused scanner candidate with the current expanded Start capacity control and unchanged normal Expat. No result from the old-source scanner experiment is transferred to this composition.

## Parser identities

| Engine | Normal shared library SHA-256 |
| --- | --- |
| Candidate | `dca62e60f80e311fbb529e66262fd2f7f07d8f38eda16c97cd33aa9dd8063488` |
| Current control | `a240099fb67c83495c15cb50054d08d4abfc16aec699237f08ca606f90bb95bb` |
| Expat | `7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478` |

Candidate source is based on `4815cf78d7419a18df8d698aaae0bbde8daa526f`; only `crates/oriole/src/tag.rs` differs across the 73 source pins. Both Oriole libraries retain the same generic x86-64 O3/ThinLTO/one-codegen-unit recipe. The completed parent build review binds the actual compiler vectors and output bytes.

## Consumer reuse

The unchanged worker loads modules from an explicit directory and verifies that `dladdr(XML_Parse)` resolves a parser DSO in that same directory. Keep the existing current-control and Expat modules in place:

| New engine | Existing consumer directory | Compilation |
| --- | --- | --- |
| Control | `/tmp/oriole-expanded-start-capacity-study/python/consumers/candidate` | Reuse its two modules |
| Expat | `/tmp/oriole-expanded-start-capacity-study/python/consumers/expat` | Reuse its two modules |
| Candidate | `/tmp/oriole-fused-normal-current-study/python/consumers/candidate` | Build two modules |

`reuse.json` pins the four existing O2 modules, colocated parser libraries, original compiler vectors/logs, unmodified CPython source, interpreter/headers, prior origin review and compiler driver. The build helper validates those exact vectors against the same current include paths and compiler version, copies the original consumer records, and runs the unchanged compilation body only for the candidate. Saved readers distinguish four historical compiles from two fresh compiles. No prior preflight or timing observations are substituted for fresh observations.

All engines use unmodified CPython 3.12.13 `pyexpat.c` and `_elementtree.c`, revision `3bb231a6a5dc02b95658877318bf61501a7209e9`, built with `cc -shared -fPIC -O2`. The cleanup backport used by separate strict compatibility suites is absent here.

## Unchanged measurement protocol

`run.py` and `python_worker.py` are byte-identical to the current capacity experiment. `consumer_screen.py` changes descriptive labels only. There are six original project XML inputs, 4/64 KiB chunks, ElementTree and pyexpat event consumers: 24 conditions and seven pairs using seed `202609104412`. Iterations, shuffled engine order, process medians and paired ratios are unchanged.

Each worker discards one warmup, retains automatic GC, and times creation, feed, finalization, callbacks and explicit destruction. Imports, input reads, canonical output checking and explicit `gc.collect` remain outside the timer. Fresh preflight runs 72 workers; timing runs 504 workers and 25,788 measured parses, for 26,364 samples including all warmups. Every worker verifies module paths/hashes and the actual parser DSO origin. All adverse conditions are retained. Canonical comparison coalesces adjacent text callbacks; it does not replace the strict compatibility suite.

## Launch order (parent owns execution)

From the pinned CPython interpreter, run these sequentially, stopping on any failure:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-fused-normal-current-study/python/bind.py
/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-fused-normal-current-study/python/run.py prepare
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-fused-normal-current-study/python/preflight_review.py
/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-fused-normal-current-study/python/run.py time
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-fused-normal-current-study/python/elapsed_review.py
```

Binding reads saved files only. `prepare` reserves CPU3 for the two builds and all preflights (600 seconds per phase). `time` requires the separate CPU0 reservation, with unchanged 300-second worker and 1,200-second aggregate bounds. The outer wrapper kills and waits for the process group on interruption or timeout. Saved readers use CPU6. No consumer builds, parser preflights or elapsed targets have been executed during preparation.
