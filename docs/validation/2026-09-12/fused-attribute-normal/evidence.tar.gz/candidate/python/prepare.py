"""Saved-only adaptation of the current normal CPython protocol; no target execution."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import shutil

D = Path(__file__).parent
P = Path('/tmp/oriole-expanded-start-capacity-study/python')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def save(p, v): p.write_text(json.dumps(v, indent=2) + '\n')
def replace(s, old, new):
    assert s.count(old) == 1, (old, s.count(old))
    return s.replace(old, new)

old = load(P/'consumers/build.json')
prior = load(P/'preflight-review.json')
assert old['status'] == prior['status'] == 'passed'
assert old['adaptations'] is None and old['source_sha256_before'] == old['source_sha256_after']
reuse = {'status': 'verified_saved_reuse', 'build_record': str(P/'consumers/build.json'),
         'preflight_review': str(P/'preflight-review.json'),
         'engines': {'control': {'prior_engine': 'candidate'}, 'expat': {'prior_engine': 'expat'}},
         'pins': {}}
def pin(p, expected=None):
    p = Path(p); h = sha(p)
    if expected is not None: assert h == expected, p
    reuse['pins'][str(p)] = h
    return h
for name in ('consumers/build.json', 'preflight-review.json', 'prepare-controller.json', 'build_consumers.py', 'python_worker.py', 'consumer_screen.py', 'adaptation.json'):
    pin(P/name)
a0 = load(P/'adaptation.json')
for v in a0['consumer_source']['files'].values(): pin(v['path'], v['sha256'])
for p, h in a0['consumer_source']['interpreter_and_public_headers'].items(): pin(p, h)
pin(a0['header']['path'], a0['header']['sha256'])
cc = Path(shutil.which('cc')).resolve(strict=True)
reuse['compiler_driver'] = {'path': str(cc), 'sha256': pin(cc)}
for engine, entry in reuse['engines'].items():
    c = old['consumers'][entry['prior_engine']]
    entry['directory'] = c['directory']
    entry['library'] = c['library']
    entry['library_sha256'] = c['files'][c['library']]
    assert entry['library_sha256'] == {'control': 'a240099fb67c83495c15cb50054d08d4abfc16aec699237f08ca606f90bb95bb', 'expat': '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'}[engine]
    for p, h in c['files'].items(): pin(p, h)
    for module, command in zip(('pyexpat', '_elementtree'), c['commands'], strict=True):
        assert command['returncode'] == 0
        pin(Path(c['directory'])/(module+'-build.log'), command['log_sha256'])
    assert prior['origins'][entry['prior_engine']]['parser_library'] == {'path': str(Path(c['library']).resolve()), 'sha256': entry['library_sha256']}
save(D/'reuse.json', reuse)

texts = {n: (P/n).read_text() for n in ('run.py', 'python_worker.py', 'consumer_screen.py', 'build_consumers.py')}
texts['consumer_screen.py'] = texts['consumer_screen.py'].replace('capacity-guarded expanded namespace Start', 'current-source fused attribute scan').replace('selected reference control', 'selected expanded Start control')
s = texts['build_consumers.py']
s = replace(s, '    output = args.output.resolve()\n', '''    reuse_path = Path(__file__).with_name("reuse.json")
    reuse = json.loads(reuse_path.read_text())
    assert reuse["status"] == "verified_saved_reuse"
    assert set(reuse["engines"]) == {"control", "expat"}
    for path, expected in reuse["pins"].items():
        assert digest(Path(path)) == expected, path
    prior = json.loads(Path(reuse["build_record"]).read_text())
    assert prior["status"] == "passed" and prior["adaptations"] is None
    assert prior["source_sha256_before"] == prior["source_sha256_after"]
    assert prior["cpython_revision"] == REVISION and prior["python"] == sys.version
    assert Path(shutil.which("cc")).resolve(strict=True) == Path(reuse["compiler_driver"]["path"])
    output = args.output.resolve()
''')
s = replace(s, '        Path(__file__).resolve(),\n', '        Path(__file__).resolve(),\n        reuse_path,\n        *[Path(p) for p in reuse["pins"]],\n')
old_method = next(line for line in s.splitlines() if line.strip().startswith('"method":'))
s = replace(s, old_method, '        "method": "Identical unmodified CPython 3.12.13 pyexpat and ElementTree O2 sources and compile recipes. Four already-built current-control/Expat extensions are reused in their original directories with original compiler vectors, inputs, logs, bytes and prior origins pinned; only the two candidate extensions are freshly compiled. All engines receive fresh canonical preflights. Normal generic Oriole uses O3, ThinLTO and one codegen unit; normal Expat uses O3 without LTO. No consumer source, allocator or measurement changes.",')
s = replace(s, '        "consumers": {},\n', '        "consumers": {},\n        "reuse": {"path": str(reuse_path), "sha256": digest(reuse_path)},\n        "compilation_origin": {"control": "reused", "expat": "reused", "candidate": "fresh"},\n')
s = replace(s, '        for engine, library in libraries.items():\n', '''        assert report["compiler"] == prior["compiler"]
        for engine, library in libraries.items():
            if engine in reuse["engines"]:
                entry = reuse["engines"][engine]
                consumer = prior["consumers"][entry["prior_engine"]]
                directory = Path(entry["directory"])
                copied = Path(entry["library"])
                assert consumer["directory"] == str(directory) and consumer["library"] == str(copied)
                assert copied.parent == directory and copied.name == library.name
                assert digest(library) == digest(copied) == entry["library_sha256"]
                assert set(consumer["files"]) == {str(copied), *(str(directory / f"{m}{sysconfig.get_config_var('EXT_SUFFIX')}") for m in ("pyexpat", "_elementtree"))}
                for module, command in zip(("pyexpat", "_elementtree"), consumer["commands"], strict=True):
                    destination = directory / f"{module}{sysconfig.get_config_var('EXT_SUFFIX')}"
                    expected = ["cc", "-shared", "-fPIC", "-O2", *[f"-I{p}" for p in includes], str(source / f"Modules/{module}.c"), str(copied), f"-Wl,-rpath,{directory}", "-o", str(destination)]
                    assert command["command"] == expected and command["returncode"] == 0
                    assert digest(directory / f"{module}-build.log") == command["log_sha256"]
                report["consumers"][engine] = consumer
                continue
''')
texts['build_consumers.py'] = s
for name, text in texts.items():
    ast.parse(text)
    (D/name).write_text(text)
    (D/(name+'.patch')).write_text(''.join(difflib.unified_diff((P/name).read_text().splitlines(True), text.splitlines(True), fromfile=str(P/name), tofile=str(D/name))))
assert (D/'python_worker.py').read_bytes() == (P/'python_worker.py').read_bytes()
assert (D/'run.py').read_bytes() == (P/'run.py').read_bytes()

for phase in ('preflight', 'elapsed'):
    origin = Path(f'/tmp/oriole-expanded-start-capacity-python-{phase}-review.py')
    s = origin.read_text().replace("D=Path('/tmp/oriole-expanded-start-capacity-study/python')", "D=Path('/tmp/oriole-fused-normal-current-study/python')")
    if phase == 'preflight':
        s = replace(s, "assert binding['adaptation_sha256'][str(D/'adaptation.json')]==sha(D/'adaptation.json')", "consumer_binding=load(D/'consumer-binding.json')\nassert consumer_binding['status']=='passed' and consumer_binding['adaptation_sha256']==sha(D/'adaptation.json')\ncheck(consumer_binding['pins'])")
        s = replace(s, "libs=a['libraries']", "reuse=load(D/'reuse.json');check(reuse['pins'])\noldbuild=load(reuse['build_record'])\nlibs=a['libraries']")
        s = replace(s, "assert set(b['consumers'])=={'control','candidate','expat'}", "assert set(b['consumers'])=={'control','candidate','expat'}\nassert b['reuse']=={'path':str(D/'reuse.json'),'sha256':sha(D/'reuse.json')}\nassert b['compilation_origin']=={'control':'reused','expat':'reused','candidate':'fresh'}\nfor engine,entry in reuse['engines'].items():assert b['consumers'][engine]==oldbuild['consumers'][entry['prior_engine']]")
        s = replace(s, "directory=D/'consumers'/engine;library=directory/Path(libs[engine]['path']).name", "directory=Path(a['consumer_directories'][engine]);library=directory/Path(libs[engine]['path']).name")
        s = replace(s, "'consumer':str(D/'consumers'/engine)", "'consumer':a['consumer_directories'][engine]")
        s = replace(s, "'extension_compiles':6", "'extension_compiles':{'fresh':2,'reused':4,'total':6}")
        s = replace(s, "Saved compile vectors and existing worker-reported", "Four original reused and two fresh compile vectors and fresh worker-reported")
    else:
        s = replace(s, "assert buildbinding['source']['source_sha256']==sha(D.parent/'source.json')", "assert buildbinding['source_manifest_sha256']==sha(D.parent/'source.json')")
        s = replace(s, "d=Path(c['directory']);assert d==original/'consumers'/engine", "d=Path(c['directory']);assert str(d)==a['consumer_directories'][engine]")
        s = replace(s, "'consumer':str(original/'consumers'/engine)", "'consumer':a['consumer_directories'][engine]")
        s = replace(s, 'Existing six compiler vector/source bindings', 'Four reused plus two fresh compiler vector/source bindings')
    ast.parse(s)
    (D/(phase+'_review.py')).write_text(s)
    (D/(phase+'_review.py.patch')).write_text(''.join(difflib.unified_diff(origin.read_text().splitlines(True), s.splitlines(True), fromfile=str(origin), tofile=str(D/(phase+'_review.py')))))

a = {k: a0[k] for k in ('counts', 'bounds', 'seed', 'consumer_source', 'header', 'counts_with_warmups')}
a.update(status='prepared_only', execution_status='unexecuted', mode='normal', origin=str(P),
    parent_files={n: sha(P/n) for n in texts}, files={n: sha(D/n) for n in texts},
    source_runtime_control='4815cf78d7419a18df8d698aaae0bbde8daa526f',
    candidate_source='/home/dev-user/code/oss/oriole-fused-normal-current',
    consumer_directories={e: reuse['engines'][e]['directory'] if e in reuse['engines'] else str(D/'consumers/candidate') for e in ('control','candidate','expat')},
    libraries={'candidate': {'path': str(D.parent/'normal/liboriole_expat.so'), 'sha256': 'dca62e60f80e311fbb529e66262fd2f7f07d8f38eda16c97cd33aa9dd8063488'},
               'control': {'path': '/tmp/oriole-expanded-start-capacity-study/normal/liboriole_expat.so', 'sha256': 'a240099fb67c83495c15cb50054d08d4abfc16aec699237f08ca606f90bb95bb'},
               'expat': a0['libraries']['expat']},
    extension_compiles={'fresh': 2, 'reused': 4, 'total': 6},
    parser_builds='Normal generic O3/ThinLTO/one codegen unit Oriole versus pinned normal O3 Expat. Four unchanged O2 control/Expat consumer artifacts reused; two identical-recipe O2 candidate consumers built fresh.',
    proof='run.py and python_worker.py are byte-identical to current capacity protocol. consumer_screen.py differs only in descriptive labels. Build helper reuses four pinned modules in their original directories; candidate compilation body unchanged. All 24 conditions, seven seeded pairs, medians, GC/destruction/canonical checks, origins and timeouts are retained.',
    comparison_scope='Current fused tag.rs candidate versus current expanded Start capacity control and unchanged normal Expat. No old-source timing result is transferred to this composition.',
    source_scope='Only tag.rs differs across all 73 current source manifest keys; namespace expanded Start and capacity refinement are retained.')
for key, name in (('candidate_source_record','source.json'), ('candidate_build_record','build.json'), ('candidate_build_review','build-binding.json')):
    a[key]={'path':str(D.parent/name),'sha256':sha(D.parent/name)}
assert a['candidate_build_review']['sha256']=='0f15c7a9e45b9ee1159f2962e4dfbaa46b893f646888901ab422d1c3333e25da'
save(D/'adaptation.template.json', a)
print(json.dumps({'status':'prepared_unbound','output':str(D),'fresh_compiles':2,'reused_compiles':4,'worker_unchanged':True,'run_unchanged':True}))
