"""Compare the completed candidate build to the selected normal build."""
from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import subprocess

assert __debug__ and os.sched_getaffinity(0) == {6}
root = Path('/home/dev-user/code/oss/oriole-fused-normal-current')
out = Path('/tmp/oriole-fused-normal-current-study')
control = Path('/tmp/oriole-expanded-start-capacity-study')
base = '4815cf78d7419a18df8d698aaae0bbde8daa526f'
read = lambda path: json.loads(Path(path).read_text())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
report_path = out / 'build-binding.json'
assert not report_path.exists()
report = {'status': 'incomplete', 'scope': 'Saved normal source/compiler/artifact comparison only. No target execution or compiler-setting changes.'}

def normalize(vector):
    return [str(Path(vector[0]).resolve(strict=True))] + [
        re.sub(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}(?=/)', '@WORKSPACE_BUILD@', arg)
        for arg in vector[1:]
    ]

def vectors(values):
    result = {v[v.index('--crate-name') + 1]: normalize(v) for v in values}
    assert len(values) == len(result) == 3
    assert set(result) == {'oriole', 'oriole_expat', 'oriole_storage'}
    return result

try:
    build, old = read(out / 'build.json'), read(control / 'build.json')
    source, old_source = read(out / 'source.json'), read(control / 'source.json')
    old_binding = read(control / 'build-binding.json')
    assert build['status'] == old['status'] == old_binding['status'] == 'passed'
    assert build['source_unchanged'] and old['source_unchanged']
    assert source['base'] == base
    assert sha(out / 'source.json') == build['source_sha256']
    assert sha(control / 'source.json') == old['source_sha256']
    assert set(source['sha256']) == set(old_source['sha256']) and len(source['sha256']) == 73
    assert all(sha(root / p) == h for p, h in source['sha256'].items())
    for name, digest in old_source['sha256'].items():
        data = subprocess.check_output(['git', 'show', base + ':' + name], cwd=root)
        assert hashlib.sha256(data).hexdigest() == digest
    delta = {name: {'control': old_source['sha256'][name], 'candidate': value}
             for name, value in source['sha256'].items() if value != old_source['sha256'][name]}
    assert set(delta) == {'crates/oriole/src/tag.rs'}
    assert delta['crates/oriole/src/tag.rs']['candidate'] == '50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6'
    assert subprocess.check_output(['git', 'diff', '--binary', base], cwd=root) == (out / 'candidate.patch').read_bytes()
    commands = {row['label']: row for row in build['commands']}
    old_commands = {row['label']: row for row in old['commands']}
    assert set(commands) == set(old_commands) == {'rustc-version', 'fmt', 'tests', 'clippy', 'release'}
    for label, row in commands.items():
        assert row['exit'] == 0 and row['reaped']
        assert row['argv'] == old_commands[label]['argv']
        assert sha(out / (label + '.log')) == row['log_sha256']
    assert build['rustc'] == old['rustc'] == (out / 'rustc-version.log').read_text()
    parsed_vectors = []
    for line in (out / 'release.log').read_text().splitlines():
        if 'Running `' in line and '/rustc ' in line:
            vector = shlex.split(line.strip()[len('Running `'):-1])
            if vector[vector.index('--crate-name') + 1] in {'oriole', 'oriole_expat', 'oriole_storage'}:
                parsed_vectors.append(vector)
    assert parsed_vectors == build['compiler_vectors']
    assert vectors(parsed_vectors) == vectors(old['compiler_vectors'])
    assert all(sha(p) == h for p, h in old_binding['tool_hashes'].items())
    for study, data in [(out, build), (control, old)]:
        assert set(data['libraries']) == {'liboriole_expat.so', 'liboriole_expat.a'}
        assert all(sha(study / 'normal' / name) == digest for name, digest in data['libraries'].items())
    target = Path('/home/dev-user/.cache/oriole/fused-normal-current-target/x86_64-unknown-linux-gnu/release')
    assert all(sha(target / name) == digest for name, digest in build['libraries'].items())
    groups = re.findall(r'^test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;', (out / 'tests.log').read_text(), re.M)
    assert groups and all(int(ignored) == 0 for _, ignored in groups)
    report.update(status='passed', base=base, source_count=73, source_delta=delta,
                  source_manifest_sha256=sha(out / 'source.json'), build_sha256=sha(out / 'build.json'),
                  control_source_manifest_sha256=sha(control / 'source.json'), control_build_sha256=sha(control / 'build.json'),
                  tool_hashes=old_binding['tool_hashes'], compiler_vectors_normalized=vectors(parsed_vectors),
                  normalization='Only the resolved rustc symlink and per-worktree shared build directory differ.',
                  candidate_libraries=build['libraries'], control_libraries=old['libraries'],
                  tests={'passed': sum(int(n) for n, _ in groups), 'groups': len(groups), 'failures': 0, 'ignored': 0})
except BaseException as exc:
    report.update(status='failed', error=repr(exc))
    raise
finally:
    report_path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'tests': report['tests'], 'libraries': report['candidate_libraries'], 'sha256': sha(report_path)}))
