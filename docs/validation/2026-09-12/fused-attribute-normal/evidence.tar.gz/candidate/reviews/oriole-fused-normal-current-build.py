"""Check and build one fused attribute-scanner candidate with ordinary release settings."""

import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import subprocess
import time

ROOT = Path('/home/dev-user/code/oss/oriole-fused-normal-current')
OUT = Path('/tmp/oriole-fused-normal-current-study')
TARGET = Path('/home/dev-user/.cache/oriole/fused-normal-current-target')
OUT.mkdir(exist_ok=True)
assert not (OUT / 'build.json').exists()
assert os.sched_getaffinity(0) == {3}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


env = os.environ.copy()
for key in list(env):
    if key.startswith('CARGO_PROFILE_') or key in {
        'RUSTC', 'RUSTFLAGS', 'LLVM_PROFILE_FILE',
        'CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST', 'CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST',
        'LD_PRELOAD', 'LD_LIBRARY_PATH',
    }:
        env.pop(key)
env.update({
    'CARGO_HOME': '/home/dev-user/.cache/toucan/cargo',
    'CARGO_TARGET_DIR': str(TARGET),
    'CARGO_BUILD_BUILD_DIR': '/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}',
    'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0',
    'RUSTC_WRAPPER': '', 'RUSTC_WORKSPACE_WRAPPER': '',
    'CARGO_ENCODED_RUSTFLAGS': '', 'CARGO_TERM_COLOR': 'never',
})
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert base == '4815cf78d7419a18df8d698aaae0bbde8daa526f'
names = subprocess.check_output(
    ['git', 'ls-files', '-z', 'crates', 'include', 'tests/c', 'Cargo.toml', 'Cargo.lock'],
    cwd=ROOT,
).decode().rstrip('\0').split('\0')
source = {name: sha(ROOT / name) for name in names}
(OUT / 'source.json').write_text(json.dumps({'base': base, 'worktree': str(ROOT), 'sha256': source}, indent=2) + '\n')
(OUT / 'candidate.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT))
report = {'status': 'incomplete', 'source_sha256': sha(OUT / 'source.json'), 'commands': [],
          'scope': 'Ordinary O3 ThinLTO, one codegen unit, generic x86-64 release. No profile generation/use or compiler optimization changes.'}


def save():
    (OUT / 'build.json').write_text(json.dumps(report, indent=2) + '\n')


def run(label, argv):
    path = OUT / (label + '.log')
    row = {'label': label, 'argv': argv, 'start': time.time()}
    report['commands'].append(row)
    save()
    with path.open('wb') as log:
        proc = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            row['exit'] = proc.wait(timeout=900)
        finally:
            if proc.poll() is None:
                os.killpg(proc.pid, signal.SIGKILL)
                row['exit'] = proc.wait()
            row.update(reaped=True, end=time.time(), log_sha256=sha(path))
            save()
    print(label, row['exit'], flush=True)
    assert row['exit'] == 0
    return path.read_text()


try:
    report['rustc'] = run('rustc-version', ['rustc', '+ohm', '-vV'])
    cargo = ['cargo', '+ohm', '-Zohm-defaults=no']
    run('fmt', cargo + ['fmt', '--all', '--check'])
    run('tests', cargo + ['test', '-p', 'oriole', '-p', 'oriole_expat', '-p', 'oriole_storage', '--locked', '--offline'])
    run('clippy', cargo + ['clippy', '-p', 'oriole', '-p', 'oriole_expat', '-p', 'oriole_storage', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings'])
    build = run('release', cargo + ['rustc', '--release', '--locked', '--offline', '--target', 'x86_64-unknown-linux-gnu', '-p', 'oriole_expat', '--lib', '--crate-type', 'cdylib,staticlib', '--verbose'])
    vectors = []
    for line in build.splitlines():
        if 'Running `' in line and '/rustc ' in line:
            argv = shlex.split(line.strip()[len('Running `'):-1])
            if argv[argv.index('--crate-name') + 1] in {'oriole', 'oriole_expat', 'oriole_storage'}:
                assert not any('profile-generate' in arg or 'profile-use' in arg or 'target-cpu' in arg for arg in argv)
                vectors.append(argv)
    assert len(vectors) == 3
    report['compiler_vectors'] = vectors
    normal = OUT / 'normal'
    normal.mkdir()
    report['libraries'] = {}
    for name in ['liboriole_expat.so', 'liboriole_expat.a']:
        shutil.copy2(TARGET / 'x86_64-unknown-linux-gnu' / 'release' / name, normal / name)
        report['libraries'][name] = sha(normal / name)
    report['status'] = 'passed'
finally:
    report['source_unchanged'] = all(sha(ROOT / name) == value for name, value in source.items())
    save()
assert report['source_unchanged']
