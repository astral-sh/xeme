# Next normal-only experiment after 4815cf78

**Recommend testing the existing fused attribute scanner on the current expanded-Start source, with normal CPython as the first elapsed gate. Keep the bare-tag coordinate proof deferred.** This is a new, unmeasured composition; PR152's rejected candidate remains rejected and its normal-Python arm remains unexecuted. No code, worktree, target or PGO work was performed for this note.

## Evidence that makes one attempt worthwhile

- Current `4815cf78d7419a18df8d698aaae0bbde8daa526f` and original baseline `4064b065` have byte-identical `crates/oriole/src/tag.rs`: `1634a5fdc4a71d05469813b40ff9d8984768e69e25a523ab099cf0b3bf345d86`. The final reviewed fused file is `50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6`. The parser's new namespace frame/packing work is downstream; the actual delimiter/eligibility duplication still exists.
- PR152's **completed old-source normal-native** run takes 0.975392× its selected control across 24 real conditions, with 23/24 faster; generated controls take 0.988464×, with 3/4 faster. The two adverse conditions were Maven 64KiB/namespaces off (+0.182%) and generated entities 4KiB (+0.249%). These are historical measurements, not predictions for current source.
- Rejection followed a different compiled treatment's observed ElementTree regression. That remains a concrete consumer-regression warning, but is not a measured normal-Python result. The normal consumer directory contains only its eight prepared scripts/patches and adaptation file; it has no build, preflight or timing outputs. Completing that question was never attempted.
- The current composition cannot assume additive gains: expanded Start removes downstream attribute reconstruction for more namespace tags, changing the relative scanner cost and generated code layout. It may help or hurt the measured result. Maven's mostly bare default-namespace tags do not suddenly gain fused attribute work; this is not a direct solution to the remaining Maven gap.

## Why this before bare-tag coordinate skipping

| Candidate | Existing positive evidence | Additional risk / uncertainty |
| --- | --- | --- |
| Fused native attribute delimiter + ASCII eligibility | Broad old-source normal-native improvement; exact current scanner baseline; existing incremental/Unicode/mask tests and old API outcome comparison | Replaces SIMD delimiter search with an eight-byte combined proof on ordinary ASCII, and may perturb code layout. The previous consumer regression makes a fresh normal-Python gate essential. Current composition and strict outcomes are unmeasured. |
| Bare ASCII tag coordinate proof | A sound source-only design; selected-normal consume self costs show a broad candidate region | No hit rate or current timing evidence; the existing position loop already handles eight bytes at once. Adds proof state and a successful-consume coordinate path spanning scanner/core/encoding. Requires CR-state, commit-on-success, compaction, suspension/reset and layout checks. Whole consume costs are not removable savings. |

The fused path already has a smaller review boundary: only `tag.rs`. Its false specialization retains general scanning; its native specialization carries one per-value ASCII flag, resets at opening quotes and waits for the same delimiter before fallback. Special/Unicode values retain the existing whole-value predicate. No coordinates, cache owner, callback publication, resource charge or allocator policy changes are necessary. Old debug layout was unchanged (AttributeScanner 48 / TagScanner 96); that does not certify the new compiled layout.

## Concrete bounded protocol, if authorized

1. In a fresh candidate based on `4815cf78d7419a18df8d698aaae0bbde8daa526f`, apply only the exact final PR152 tag.rs change and its existing tests. Do not compose the coordinate proof or revise the scanner algorithm in the same experiment. Confirm every other runtime file equals current source; rerun focused planner/Unicode/incremental tests, normal workspace checks and strict Clippy using the existing isolated normal-build recipe.
2. Build one fresh **normal** library with the same generic O3/ThinLTO/one-codegen-unit settings. Current selected controls must be the expanded-Start artifacts, not PR152's older 087d library: DSO `a240099fb67c83495c15cb50054d08d4abfc16aec699237f08ca606f90bb95bb`, archive `f57b02b6a69a2d9dc90fab250d7a3d9ca21501c1ea577a5433dc97b56334ce41`. Keep normal Expat `7a333bc8…` as the third comparator.
3. Reuse the **current validated normal** consumer controller at `/tmp/oriole-expanded-start-capacity-study/python`, rebinding only source/output/library identities. Run the unmodified O2 CPython 3.12.13 consumers: six extension builds, 72 canonical/origin preflights, 24 conditions × seven pairs, 504 timed workers. Retain every adverse condition and separate ElementTree/pyexpat aggregates. Old unexecuted normal scripts describe the protocol but their frozen identities are stale for this experiment; do not launch them unchanged.
4. Stop if current normal CPython/ElementTree materially regresses. If the missing consumer arm is promising, measure the same full 28-condition normal native campaign against current control, then require unchanged original 4740 API outcomes, six C consumers and full 802 strict methods per linkage before selection. Existing scalar/mask and allocator-failure checks remain required; no new allocator or compiler-flag sweep is proposed.

This ordering answers the specific missing consumer question first. Old normal-native gains are a reason to measure, not acceptance evidence. Neither proposal has evidence of closing the roughly 29% native or 11% CPython elapsed reduction still needed to reach 1.10× Expat from the current normal aggregates.

## Saved inputs read

- `/tmp/oriole-eager-tag-position-current-triage.md` — SHA256 `5f0b2e15147642283d6df4cf214a67706bb07d3419a8dd1a5c525364e94f1825`
- `/tmp/oriole-fused-attribute-scan-evidence/README.md` — SHA256 `f80c2038462102fc922169583b759e5f16efd5565858b890f20057835e9cd302`
- `/tmp/oriole-fused-attribute-scan-native-review/normal-review.json` — SHA256 `39c37381e752f0967f1d147998fea2781cec2250fe47cc62d8d91f4ecef0a38e`
- `/tmp/oriole-fused-attribute-scan-python-preparation/python/normal/run.py` — SHA256 `03089c11873a549b427f17a3433cae7c7bed468a8be7b06ea446e7115ae5f002`
- `/home/dev-user/code/oss/oriole-fused-attribute-scan/crates/oriole/src/tag.rs` — SHA256 `50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6`
