"""Decode saved Callgrind self-cost PCs; never execute or import a parser DSO."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re


def read(path):
    """Keep disjoint PC self costs separate from overlapping inclusive calls."""
    data = path.read_text()
    assert re.findall(r'^part: (.+)$', data, re.M) == ['1']
    assert re.findall(r'^positions: (.+)$', data, re.M) == ['instr line']
    assert re.findall(r'^events: (.+)$', data, re.M) == ['Ir']
    summary = re.findall(r'^summary: (\d+)$', data, re.M)
    assert len(summary) == 1
    total = int(summary[0])
    names = {'ob': {}, 'fn': {}, 'fl': {}}
    current = {'ob': None, 'fn': None, 'fl': None}
    called = {'ob': None, 'fn': None, 'fl': None}
    previous = [0, 0]
    pending_call = None
    costs = Counter()
    calls = []
    jumps = []
    unknown = []
    cost_lines = 0

    def resolve(kind, value):
        match = re.fullmatch(r'\((\d+)\)(?: (.*))?', value)
        if not match:
            return value
        key, name = match.groups()
        if name is not None:
            assert key not in names[kind] or names[kind][key] == name
            names[kind][key] = name
        return names[kind][key]

    def position(fields):
        result = []
        for old, value in zip(previous, fields, strict=True):
            if value == '*':
                result.append(old)
            elif value[0] in '+-':
                result.append(old + int(value, 0 if 'x' in value else 10))
            else:
                result.append(int(value, 0 if 'x' in value else 10))
        assert all(value >= 0 for value in result)
        return result

    for number, line in enumerate(data.splitlines(), 1):
        if not line or line.startswith('#'):
            continue
        match = re.match(r'^(ob|fn|fl|fi|fe|cob|cfn|cfi|cfl|jfn|jfi)=(.*)$', line)
        if match:
            assert pending_call is None, (number, line)
            kind, value = match.groups()
            base = 'ob' if kind.endswith('ob') else 'fn' if kind.endswith('fn') else 'fl'
            name = resolve(base, value)
            if kind.startswith('c'):
                called[base] = name
            elif not kind.startswith('j'):
                current[base] = name
            continue
        if line.startswith('calls='):
            assert pending_call is None
            fields = line[6:].split()
            assert len(fields) == 3
            pending_call = {'calls': int(fields[0]), 'target_position_raw': fields[1:],
                            'caller': current.copy(),
                            'callee': {key: called[key] or current[key] for key in current},
                            'record_line': number}
            continue
        if line.startswith(('jump=', 'jcnd=')):
            assert pending_call is None
            # Targets are deliberately retained raw; they do not change the
            # last cost-line subposition or contribute a second self cost.
            jumps.append({'object': current['ob'], 'function': current['fn'],
                          'source_pc': previous[0], 'record_line': number, 'raw': line})
            continue
        fields = line.split()
        if fields and re.fullmatch(r'(?:\*|[+-]?(?:0x[\da-fA-F]+|\d+))', fields[0]):
            assert len(fields) in [2, 3], (number, line)
            previous = position(fields[:2])
            value = int(fields[2]) if len(fields) == 3 else 0
            assert value >= 0 and current['ob'] is not None and current['fn'] is not None
            cost_lines += 1
            if pending_call is not None:
                calls.append(pending_call | {'source_pc': previous[0], 'source_line': previous[1],
                                             'inclusive_Ir': value})
                pending_call = None
            else:
                costs[current['ob'], current['fn'], previous[0]] += value
            continue
        if re.match(r'^(version|creator|pid|cmd|part|desc|positions|events|summary|totals):', line):
            continue
        unknown.append({'line': number, 'text': line})
    assert pending_call is None
    assert not unknown, unknown[:10]
    assert sum(costs.values()) == total
    functions = Counter()
    objects = Counter()
    physical_pcs = Counter()
    for (obj, fn, pc), value in costs.items():
        functions[obj, fn] += value
        objects[obj] += value
        physical_pcs[obj, pc] += value
    return {'status': 'decoded_pending_ELF_and_region_review', 'path': str(path),
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'Ir': total,
        'decoded_cost_lines': cost_lines, 'unknown_lines': unknown,
        'self_cost_sum': sum(costs.values()),
        'objects': [{'object': obj, 'Ir': value} for obj, value in objects.most_common()],
        'functions': [{'object': obj, 'function': fn, 'Ir': value}
                      for (obj, fn), value in functions.most_common()],
        'physical_pcs': [{'object': obj, 'pc': pc, 'Ir': value}
                         for (obj, pc), value in physical_pcs.most_common()],
        'pc_function_contexts': [{'object': obj, 'function': fn, 'pc': pc, 'Ir': value}
                                for (obj, fn, pc), value in costs.most_common()],
        'overlapping_inclusive_calls': calls, 'jump_records_raw': jumps,
        'limitations': ['Ir counts are instruction executions, not CPU cycles or elapsed time.',
            'Each object/PC self cost appears once in physical_pcs. Inclusive calls overlap and are separate.',
            'Object addresses must match the frozen ELF executable ranges and instruction boundaries before attribution.',
            'Jump targets remain raw; basic-block boundaries require exact assembly review.',
            'Function/PC context aliases are diagnostic details, not additional costs.']}


def main():
    """Save a first-attempt reader result, including its error if decoding fails."""
    parser = argparse.ArgumentParser()
    parser.add_argument('profile', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    with args.output.open('x') as output:
        try:
            result = read(args.profile)
        except BaseException as error:
            json.dump({'status': 'failed', 'exception': repr(error)}, output, indent=2)
            output.write('\n')
            raise
        json.dump(result, output, indent=2)
        output.write('\n')


if __name__ == '__main__':
    main()
