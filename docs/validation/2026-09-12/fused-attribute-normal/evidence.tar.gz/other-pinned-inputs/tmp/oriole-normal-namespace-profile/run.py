"""Held, single-attempt XML_Parse instruction diagnostics for the selected DSO."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent


def sha(path):
    """Hash a pinned input or retained output without importing target code."""
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def observations(text):
    """Require the exact warmup/measured callback contract, ignoring seconds."""
    data = json.loads(text)
    assert data['version'] == 'oriole_compat_2.8.4'
    samples = data['samples']
    assert len(samples) == 2
    assert [s['warmup'] for s in samples] == [True, False]
    assert [s['iteration'] for s in samples] == [0, 1]
    return [[s['hash'], s['elements'], s['text_bytes']] for s in samples]


def main():
    """Run only the separately released phase; retain every first outcome."""
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=['profile'], required=True)
    parser.add_argument('--released-protocol-sha256', required=True)
    args = parser.parse_args()
    assert sha(ROOT / 'protocol.json') == args.released_protocol_sha256
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    assert os.sched_getaffinity(0) == {1}
    out = ROOT / (args.phase + '-attempt01')
    out.mkdir(exist_ok=False)
    record = {'status': 'running', 'phase': args.phase, 'cpu': 1,
              'protocol_sha256': args.released_protocol_sha256,
              'scope': protocol['scope'], 'commands': []}

    def save():
        (out / 'report.json').write_text(json.dumps(record, indent=2) + '\n')

    def verify():
        for path, digest in protocol['pins'].items():
            assert sha(path) == digest, path
        source = json.loads(Path(protocol['source_manifest']).read_text())
        assert len(source['source_sha256']) == 72
        for name, digest in source['source_sha256'].items():
            assert sha(Path(source['worktree']) / name) == digest, name
        return {path: sha(path) for path in protocol['pins']}

    env = {'HOME': '/home/dev-user', 'PATH': '/usr/bin:/bin', 'LANG': 'C',
           'LC_ALL': 'C', 'TZ': 'UTC', 'LD_PRELOAD': '', 'LD_LIBRARY_PATH': '',
           'VALGRIND_LIB': protocol['valgrind_lib']}
    record['environment'] = env

    def run(command):
        row = dict(command, started=time.time())
        record['commands'].append(row)
        save()
        process = None
        stdout_path = out / (row['label'] + '.stdout')
        stderr_path = out / (row['label'] + '.stderr')
        try:
            with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
                process = subprocess.Popen(row['argv'], cwd=ROOT, env=env,
                                           stdout=stdout, stderr=stderr,
                                           start_new_session=True)
                row['exit'] = process.wait(timeout=row['timeout_seconds'])
            assert row['exit'] == 0, row['label']
        except BaseException as error:
            row['exception'] = repr(error)
            if process is not None and process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
                row['exit'] = process.wait()
            raise
        finally:
            row['completed'] = time.time()
            row['reaped'] = process is None or process.poll() is not None
            for kind, path in [('stdout', stdout_path), ('stderr', stderr_path)]:
                if path.exists():
                    row[kind + '_sha256'] = sha(path)
            save()
        return stdout_path.read_text()

    save()
    try:
        record['hashes_before'] = verify()
        record['profiles'] = []
        for case in protocol['cases']:
            expected = case['expected_observations']
            assert observations(run(case['preflight'])) == expected
            assert observations(run(case['profile'])) == expected
            path = Path(case['profile_path'])
            data = path.read_text()
            assert re.search(r'^events: (.+)$', data, re.M)[1] == 'Ir'
            assert re.search(r'^positions: (.+)$', data, re.M)[1] == 'instr line'
            total = int(re.search(r'^summary: (\d+)$', data, re.M)[1])
            annotation = run(case['annotation'])
            functions = []
            for line in annotation.splitlines():
                match = re.match(r'^\s*([\d,]+)\s+(.+?) \[([^\]]+)\]$', line)
                if match:
                    functions.append({'Ir': int(match[1].replace(',', '')),
                                      'function': match[2], 'object': match[3]})
            assert sum(f['Ir'] for f in functions) == total
            record['profiles'].append({'label': case['label'], 'Ir': total,
                'path': str(path), 'profile_sha256': sha(path),
                'actual_measured_iterations': 1, 'warmup_iterations': 1,
                'inherited_elapsed_iterations': case['inherited_elapsed_iterations'],
                'functions': functions, 'unparsed_Ir': 0})
            save()
        record['status'] = 'passed'
    except BaseException as error:
        record['status'] = 'failed'
        record['exception'] = repr(error)
        raise
    finally:
        try:
            record['hashes_after'] = verify()
            record['inputs_unchanged'] = record.get('hashes_before') == record['hashes_after']
            assert record['inputs_unchanged']
        except BaseException as error:
            record['status'] = 'failed'
            record['verification_exception'] = repr(error)
            save()
            raise
        save()
    print(json.dumps({'status': record['status'], 'report_sha256': sha(out / 'report.json')}))


if __name__ == '__main__':
    main()
