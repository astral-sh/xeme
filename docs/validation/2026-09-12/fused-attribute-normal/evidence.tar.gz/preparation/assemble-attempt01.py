"""Package completed normal fused-scanner evidence with the existing tar recipe."""
from pathlib import Path
import csv
import gzip
import hashlib
import io
import json
import os
import tarfile

assert __debug__ and os.sched_getaffinity(0) == {6}
PREP = Path(__file__).parent
DRAFT = Path('/tmp/oriole-fused-normal-publication-draft')
OUT = DRAFT/'docs/validation/2026-09-12/fused-normal'
STUDY = Path('/tmp/oriole-fused-normal-current-study')
CONTROL = Path('/tmp/oriole-expanded-start-capacity-study')
PROFILE = Path('/tmp/oriole-current-expat-instruction-profile')
SEMANTIC = Path('/tmp/oriole-expanded-start-semantic-coverage-current')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert not OUT.exists(), OUT
draft = read(DRAFT/'report.json')
native = read(STUDY/'native/review.json')
python = read(STUDY/'python/normal-review.json')
source = read(STUDY/'source.json')
control_source = read(CONTROL/'source.json')
assert sha(STUDY/'native/review.json') == 'b2f79dd6447e3a4f483a8c40871b4d85f1b778a0c0b1d7d12ef8dceaea51417d'
assert sha(STUDY/'python/normal-review.json') == '6f8539b1c00dd6454b24d8b13c4a411fbf6b776d07189721b415e7e24e154779'
assert native['counts']['all_workers']==672 and native['counts']['all_samples']==106176
assert python['counts']['all_workers']==576 and python['counts']['all_samples']==26364
assert read(STUDY/'build-binding.json')['tests']=={'passed':444,'groups':34,'failures':0,'ignored':0}

# Existing explicit add/tree, deterministic gzip, index and full-member readback.
entries, originals, excluded, pins = {}, {}, {}, {}
def add_data(data, member, original):
    assert member not in entries, member
    assert not data.startswith((b'\x7fELF', b'!<arch>\n')), original
    entries[member], originals[member] = data, str(original)
def add(path, member):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert path.suffix not in {'.pyc','.profraw','.profdata','.a','.so'}, path
    add_data(path.read_bytes(), member, path)
def is_external(path):
    path = Path(path)
    if path.suffix in {'.pyc','.profraw','.profdata','.a','.so'} or '.so.' in path.name:
        return True
    with path.open('rb') as f: return f.read(8).startswith((b'\x7fELF',b'!<arch>\n'))
def exclude(path, reason):
    path=Path(path)
    row={'path':str(path),'sha256':sha(path),'size':path.stat().st_size,'reason':reason}
    assert str(path) not in excluded or excluded[str(path)]==row
    excluded[str(path)]=row
def tree(root,prefix):
    root=Path(root);assert root.is_dir(),root
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts: continue
        if is_external(path): exclude(path,'Executable/library/bytecode/compiler-profile identity only')
        elif path.is_symlink(): raise AssertionError(f'unexpected nonbinary symlink: {path}')
        else: add(path,prefix+'/'+str(path.relative_to(root)))
def pin_map(values):
    for path,digest in values.items():
        assert isinstance(digest,str) and len(digest)==64,(path,digest)
        assert path not in pins or pins[path]==digest,path
        pins[path]=digest

assert source['sha256'].keys()==control_source['sha256'].keys() and len(source['sha256'])==73
source_members={}
for name,h in source['sha256'].items():
    path=Path(source['worktree'])/name;assert sha(path)==h
    member='source/candidate/'+name;add(path,member);source_members[name]=member
control_members=dict(source_members)
for name,h in control_source['sha256'].items():
    path=Path(control_source['worktree'])/name;assert sha(path)==h
    if h!=source['sha256'][name]:
        assert name=='crates/oriole/src/tag.rs'
        member='source/control/'+name;add(path,member);control_members[name]=member
for name in ['LICENSE-APACHE','LICENSE-MIT','THIRD_PARTY_LICENSES.md','licenses/expat.txt','licenses/libxml2.txt','licenses/cpython.txt']:
    path=Path(source['worktree'])/name
    if 'source/candidate/'+name not in entries: add(path,'source/candidate/'+name)
add(STUDY/'source.json','source/candidate-manifest.json')
add(CONTROL/'source.json','source/control-manifest.json')
source_map={'candidate':source_members,'control':control_members,'candidate_sha256':source['sha256'],'control_sha256':control_source['sha256']}
add_data((json.dumps(source_map,indent=2)+'\n').encode(),'source/member-map.json','generated from both verified73-source manifests')

for p in sorted(STUDY.iterdir()):
    if p.is_file(): add(p,'candidate/build/'+p.name)
tree(STUDY/'native','candidate/native')
tree(STUDY/'python','candidate/python')
tree('/tmp/oriole-fused-normal-current-preparation','candidate/author-preparation')
for path in ['/tmp/oriole-fused-normal-current-build.py','/tmp/oriole-fused-normal-current-bind.py','/tmp/oriole-fused-normal-current-build-adaptation.patch','/tmp/oriole-fused-normal-current-source-review.json','/tmp/oriole-fused-normal-current-python-preparation-review.json','/tmp/oriole-fused-normal-current-triage.md']:
    add(path,'candidate/reviews/'+Path(path).name)
tree(SEMANTIC,'selected-control/supplemental-semantics')
tree(PROFILE,'selected-control/instruction-profile')
for name in ('README.md','report.json','README-table.md','README-table.json','python-conditions.csv'):
    add(DRAFT/name,'publication-draft/'+name)
add(__file__,'preparation/assemble.py')
add('/tmp/oriole-expanded-start-evidence-preparation/assemble.py','preparation/prior-archive-recipe.py')

pin_map(native['inputs'])
pin_map(python['evidence_sha256'])
pin_map(read(STUDY/'python/preflight-review.json')['pins'])
pin_map(read(STUDY/'python/consumer-binding.json')['pins'])
pin_map(read(STUDY/'python/reuse.json')['pins'])
pin_map(read(PROFILE/'saved-instruction-readback.json')['pins'])
pin_map(read(PROFILE/'protocol.json')['pins'])
for kind in ('native/native-screen','python/screen'):
    data=read(STUDY/kind/'results.json')
    assert data['hashes_before']==data['hashes_after'];pin_map(data['hashes_before'])

corpus=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
add(corpus,'inputs/corpus-manifest.json')
for project in read(corpus)['projects']:
    for item in project['files']:
        p=corpus.parent/item['path'];assert sha(p)==item['sha256']
        add(p,'inputs/'+item['path'])
for p,member in [('/tmp/oriole-grammar-bench-plain/entities.xml','inputs/generated/entities.xml'),('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml','inputs/generated/rare-declarations.xml')]:add(p,member)
archived_paths=set(originals.values())
for path,h in sorted(pins.items()):
    p=Path(path);assert sha(p)==h,p
    if path in archived_paths:continue
    machine_config=p.name in {'config','config.toml'} and '.cargo' in p.parts
    if is_external(p) or machine_config:exclude(p,'External executable/library/compiler-profile or machine configuration; audited identity retained')
    else:add(p,'other-pinned-inputs/'+str(p).lstrip('/'))

assert sum(n.startswith('candidate/native/native-screen/worker-') for n in entries)==672
assert sum(n.startswith('candidate/python/screen/') and n.endswith('-0.json') for n in entries)==576
assert sum(n.startswith('candidate/python/screen/') and n.endswith(('-stdout.gz','-stderr.gz')) for n in entries)==1152
assert sum(n.endswith('.callgrind') for n in entries)==4
conditions=[]
for consumer,values in [('native',native['all_conditions']),('python',python['summary'])]:
    for row in values:
        c,r=row['condition'],row['median_ratios']
        conditions.append({'consumer':consumer,'project':c['name'],'chunk_bytes':c['chunk'],'namespace_or_mode':c.get('mode',str(c.get('namespaces','')).lower()),**r,'adverse':r['candidate_over_control']>1})
assert len(conditions)==52
adverse=[r for r in conditions if r['adverse']];assert len(adverse)==2
OUT.mkdir(parents=True)
for name,rows in [('conditions.csv',conditions),('adverse-conditions.csv',adverse)]:
    with (OUT/name).open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for name in ('README-table.md','README-table.json','python-conditions.csv'):
    (OUT/name).write_bytes((DRAFT/name).read_bytes())

members=[]
with (OUT/'evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for member,data in sorted(entries.items()):
                info=tarfile.TarInfo(member);info.size,info.mode,info.mtime=len(data),0o644,0
                archive.addfile(info,io.BytesIO(data))
                members.append({'member':member,'original_path':originals[member],'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive_path=OUT/'evidence.tar.gz'
with tarfile.open(archive_path,'r:gz') as archive:
    actual=archive.getmembers();assert [m.name for m in actual]==[r['member'] for r in members]
    for member,row in zip(actual,members,strict=True):
        assert member.isfile() and member.size==row['size']
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==row['sha256']
for member,path in originals.items():
    if path.startswith('/'):
        assert Path(path).read_bytes()==entries[member],path
index={'schema':'saved-record-bundle-v1','archive':'evidence.tar.gz','archive_sha256':sha(archive_path),'archive_bytes':archive_path.stat().st_size,'archive_readback_passed':True,'members':members,'excluded':list(excluded.values())}
(OUT/'index.json').write_text(json.dumps(index,indent=2)+'\n')
report=draft | {'status':'benchmark_packet_complete_candidate_compatibility_pending',
    'evidence':{'archive_sha256':sha(archive_path),'archive_bytes':archive_path.stat().st_size,'members':len(members),'index_sha256':sha(OUT/'index.json'),'readback_passed':True,'all_conditions':52,'adverse_conditions':2,'conditions_sha256':sha(OUT/'conditions.csv'),'adverse_sha256':sha(OUT/'adverse-conditions.csv')},
    'source_members':'source/member-map.json','native_all_conditions':native['all_conditions'],'python_all_conditions':python['summary']}
report['archive_status']='benchmark/source/control-diagnostic packet assembled; candidate compatibility pending separately'
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
body=(DRAFT/'README.md').read_text()+f'\n## Raw evidence\n\n[evidence.tar.gz](evidence.tar.gz) contains {len(members):,} indexed files ({archive_path.stat().st_size:,} compressed bytes). Executables, libraries and compiler profile data are excluded; current-control Callgrind text is retained. [index.json](index.json) records original paths, sizes and extraction hashes; every member and original input was read back after writing. [report.json](report.json) preserves exact results and pending candidate gates.\n\n```console\nsha256sum evidence.tar.gz\ntar -xzf evidence.tar.gz\n```\n\nArchive SHA-256: `{sha(archive_path)}`. The manifest maps all73 candidate/control source bytes to portable archive members.\n'
(OUT/'README.md').write_text(body)
print(json.dumps({'output':str(OUT),'archive_sha256':sha(archive_path),'bytes':archive_path.stat().st_size,'members':len(members),'report_sha256':sha(OUT/'report.json'),'index_sha256':sha(OUT/'index.json')},indent=2),flush=True)
