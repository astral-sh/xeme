"""Package completed normal expanded-Start evidence using the existing tar recipe."""
from pathlib import Path
import argparse
import csv
import gzip
import hashlib
import io
import json
import os
import subprocess
import tarfile

ap = argparse.ArgumentParser()
ap.add_argument('--released', action='store_true', required=True)
ap.add_argument('--strict-review', type=Path, required=True)
ap.add_argument('--commit-binding', type=Path, required=True)
args = ap.parse_args()
assert os.sched_getaffinity(0) == {6}
PREP = Path(__file__).parent
OUT = Path('/tmp/oriole-expanded-start-publication-draft/docs/validation/2026-09-12/expanded-start')
CORRECT = Path('/tmp/oriole-expanded-start-capacity-correctness')
PROFILE = Path('/tmp/oriole-normal-namespace-profile')
BASE = '4064b0653534aff690c0e0f395a6b3b48da878fc'
V1_COMMIT = '8c039ec6c24797c516312a277d0e102c0768f077'
STUDIES = {
    'v1': Path('/tmp/oriole-expanded-start-current-study'),
    'v2': Path('/tmp/oriole-expanded-start-capacity-study'),
}
REVIEWS = {
    'v1': Path('/tmp/oriole-expanded-start-native-review'),
    'v2': Path('/tmp/oriole-expanded-start-capacity-native-review'),
}
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert not OUT.exists(), OUT
native = {v: read(REVIEWS[v] / 'review.json') for v in STUDIES}
python = {v: read(s / 'python/normal-review.json') for v, s in STUDIES.items()}
allocation = {v: read(s / 'allocations/comparison.json') for v, s in STUDIES.items()}
sources = {v: read(s / 'source.json') for v, s in STUDIES.items()}
builds = {v: read(s / 'build-binding.json') for v, s in STUDIES.items()}
api = read(CORRECT / 'api-c-readback.json')
strict = read(args.strict_review)
binding = read(args.commit_binding)
assert binding['status'] == 'passed' and binding['source_bytes_unchanged']
assert binding['measured_files'] == 73
assert binding['source_sha256'] == sources['v2']['sha256']
assert api['status'] == 'passed_saved_api_c_readback'
assert api['api']['ordered_configurations'] == 4740
assert api['api']['counts'] == {'pass': 4347, 'fail': 391, 'timeout': 2}
assert not api['api']['changes'] and api['api']['raw_exit'] == 1
assert strict['status'] == 'saved_strict_semantic_verified', strict['status']
assert all(strict['strict'][mode]['methods'] == 802
           and strict['strict'][mode]['raw_exit'] == 2
           and not strict['strict'][mode]['changes']
           for mode in ['shared', 'static'])
semantics = {m: read(CORRECT / f'semantic-{m}-receipt.json') for m in ['shared', 'static']}
assert all(r['status'] == 'passed' and r['exit'] == 0 and r['reaped']
           and r['expected_semantic_tests'] == 2 for r in semantics.values())
for v, s in STUDIES.items():
    assert native[v]['counts']['all_workers'] == 672
    assert native[v]['counts']['all_samples'] == 106176
    assert python[v]['status'] == 'passed'
    assert python[v]['counts']['all_workers'] == 576
    assert python[v]['counts']['all_samples'] == 26364
    assert builds[v]['status'] == 'passed' and builds[v]['tests']['passed'] == 442
    assert read(s / 'build.json')['source_unchanged']
    assert allocation[v]['cases'] == 8 and allocation[v]['raw_probe_results'] == 16
    assert sha(s / 'python/normal-conditions.csv') == python[v]['condition_csv_sha256']
    assert sha(REVIEWS[v] / 'conditions.csv') == native[v]['conditions_csv_sha256']
assert allocation['v2']['v1_comparison']['selected_normal_replay_exact']

# Same explicit add/tree, deterministic gzip and full member readback as earlier packets.
entries, originals, excluded = {}, {}, []
pins = {}

def add_data(data, member, original):
    assert member not in entries, member
    assert not data.startswith((b'\x7fELF', b'!<arch>\n')), original
    entries[member], originals[member] = data, str(original)

def add(path, member):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert path.suffix not in {'.pyc', '.profraw', '.profdata', '.a', '.so'}, path
    add_data(path.read_bytes(), member, path)

def is_external(path):
    path = Path(path)
    if path.suffix in {'.pyc', '.profraw', '.profdata', '.a', '.so'} or '.so.' in path.name:
        return True
    with path.open('rb') as stream:
        return stream.read(8).startswith((b'\x7fELF', b'!<arch>\n'))

def exclude(path, reason):
    path = Path(path)
    excluded.append({'path': str(path), 'sha256': sha(path),
                     'size': path.stat().st_size, 'reason': reason})

def tree(root, prefix):
    root = Path(root)
    assert root.is_dir(), root
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        if is_external(path):
            exclude(path, 'Executable, library, bytecode or profile payload; identity retained only')
        elif path.is_symlink():
            raise AssertionError(f'unexpected nonbinary symlink: {path}')
        else:
            add(path, prefix + '/' + str(path.relative_to(root)))

def pin_map(values):
    for path, digest in values.items():
        assert isinstance(digest, str) and len(digest) == 64, (path, digest)
        assert path not in pins or pins[path] == digest, path
        pins[path] = digest

# Full source snapshots stay simple to inspect; each has its exact source map.
git_worktree = Path(sources['v1']['worktree'])
baseline_source = {}
for version, commit in [('selected', BASE), ('v1', V1_COMMIT), ('v2', None)]:
    manifest = sources['v2'] if version == 'v2' else sources['v1']
    assert len(manifest['sha256']) == 73
    for name, digest in manifest['sha256'].items():
        if commit is not None:
            data = subprocess.check_output(['git', 'show', f'{commit}:{name}'], cwd=git_worktree)
            origin = f'git:{commit}:{name}'
        else:
            path = Path(manifest['worktree']) / name
            data, origin = path.read_bytes(), str(path)
        if version == 'selected':
            baseline_source[name] = hashlib.sha256(data).hexdigest()
        else:
            assert hashlib.sha256(data).hexdigest() == digest, (version, name)
        add_data(data, f'source/{version}/{name}', origin)
    for name in ['LICENSE-APACHE', 'LICENSE-MIT', 'THIRD_PARTY_LICENSES.md',
                 'licenses/expat.txt', 'licenses/libxml2.txt', 'licenses/cpython.txt']:
        data = subprocess.check_output(['git', 'show', f'{commit or V1_COMMIT}:{name}'], cwd=git_worktree)
        add_data(data, f'source/{version}/{name}', f'git:{commit or V1_COMMIT}:{name}')
add(args.commit_binding, 'source/final-commit-binding.json')

for v, s in STUDIES.items():
    for p in sorted(s.iterdir()):
        if p.is_file():
            add(p, f'{v}/build/{p.name}')
    tree(s / 'native', f'{v}/native')
    tree(s / 'python', f'{v}/python')
    tree(s / 'allocations', f'{v}/allocations')
    tree(REVIEWS[v], f'{v}/native-independent-review')
    check_root = Path('/tmp/oriole-expanded-start-' + ('current' if v == 'v1' else 'capacity') + '-checks')
    tree(check_root, f'{v}/author-checks')
    pin_map(native[v]['inputs'])
    pin_map(python[v]['evidence_sha256'])
    pin_map(read(s / 'python/preflight-review.json')['pins'])
    pin_map(allocation[v]['input_sha256'])
    for kind in ['native/native-screen', 'python/screen']:
        data = read(s / kind / 'results.json')
        pin_map(data['hashes_before'])
        assert data['hashes_before'] == data['hashes_after']
tree(CORRECT, 'v2/correctness')
if str(args.strict_review) not in originals.values():
    add(args.strict_review, 'v2/correctness-independent-review.json')
pin_map(api['inputs'])
for key in ['inputs', 'pins']:
    if key in strict:
        pin_map(strict[key])
tree(PROFILE, 'selected-normal-instruction-profile')
add('/tmp/oriole-expanded-start-independent-review.json', 'v1/source-independent-review.json')
for path in sorted(Path('/tmp').glob('oriole-expanded-start-capacity*review*.json')):
    if str(path) not in originals.values():
        add(path, 'v2/source-review/' + path.name)
for path in ['/tmp/oriole-expanded-start-current-python-preflight-review.py',
             '/tmp/oriole-expanded-start-current-python-elapsed-review.py']:
    add(path, 'controllers/' + Path(path).name)
for name in ['inventory.json', 'inventory.md', 'V1-section.md', 'report-body.md', 'assemble.py']:
    add(PREP / name, 'preparation/' + name)

corpus = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
add(corpus, 'inputs/corpus-manifest.json')
for project in read(corpus)['projects']:
    for item in project['files']:
        p = corpus.parent / item['path']
        assert sha(p) == item['sha256']
        add(p, 'inputs/' + item['path'])
for p, member in [('/tmp/oriole-grammar-bench-plain/entities.xml', 'inputs/generated/entities.xml'),
                  ('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml', 'inputs/generated/rare-declarations.xml')]:
    add(p, member)
archived_paths = set(originals.values())
for path, digest in sorted(pins.items()):
    p = Path(path)
    assert sha(p) == digest, p
    if path in archived_paths:
        continue
    machine_config = p.name in {'config', 'config.toml'} and '.cargo' in p.parts
    if is_external(p) or machine_config:
        exclude(p, 'External executable/library/profile or machine configuration; audited pin retained')
    else:
        add(p, 'other-pinned-inputs/' + str(p).lstrip('/'))

assert sum('/native/native-screen/worker-' in n for n in entries) == 1344
assert sum('/python/screen/' in n and n.endswith('-0.json') for n in entries) == 1152
assert sum('/python/screen/' in n and n.endswith(('-stdout.gz', '-stderr.gz')) for n in entries) == 2304
assert sum(n.endswith('.callgrind') for n in entries) == 4

conditions, allocation_rows = [], []
for v in STUDIES:
    for consumer, values in [('native', native[v]['all_conditions']), ('python', python[v]['summary'])]:
        for row in values:
            c, r = row['condition'], row['median_ratios']
            conditions.append({'version': v, 'consumer': consumer, 'project': c['name'],
                               'chunk_bytes': c['chunk'], 'namespace_or_mode': c.get('mode', str(c.get('namespaces', '')).lower()),
                               'candidate_over_control': r['candidate_over_control'],
                               'candidate_over_expat': r['candidate_over_expat'],
                               'control_over_expat': r['control_over_expat'],
                               'adverse': r['candidate_over_control'] > 1})
    for row in allocation[v]['rows']:
        d = row['candidate_minus_selected']
        allocation_rows.append({'version': v, 'case': row['case'],
                                'phase2_request_delta': d['parse']['mallocs'] + d['parse']['reallocs'],
                                'phase2_requested_byte_delta': d['parse']['requested'],
                                'peak_byte_delta': d['allocation']['peak_bytes'],
                                'final_retained_byte_delta': d['allocation']['retained_bytes']})
assert len(conditions) == 104 and len(allocation_rows) == 16
adverse = [r for r in conditions if r['adverse']]
assert len(adverse) == 38
OUT.mkdir(parents=True)
for name, rows in [('conditions.csv', conditions), ('adverse-conditions.csv', adverse), ('allocations.csv', allocation_rows)]:
    with (OUT / name).open('x', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

members = []
with (OUT / 'evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for member, data in sorted(entries.items()):
                info = tarfile.TarInfo(member)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                archive.addfile(info, io.BytesIO(data))
                members.append({'member': member, 'original_path': originals[member],
                                'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
archive_path = OUT / 'evidence.tar.gz'
with tarfile.open(archive_path, 'r:gz') as archive:
    actual = archive.getmembers()
    assert [m.name for m in actual] == [r['member'] for r in members]
    for member, row in zip(actual, members, strict=True):
        assert member.isfile() and member.size == row['size']
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == row['sha256']
index = {'schema': 'saved-record-bundle-v1', 'archive': 'evidence.tar.gz',
         'archive_sha256': sha(archive_path), 'archive_bytes': archive_path.stat().st_size,
         'archive_readback_passed': True, 'members': members, 'excluded': excluded}
(OUT / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
report = {
    'status': 'completed_normal_evidence_not_a_production_readiness_claim',
    'selected_comparison_runtime': BASE, 'v1_commit': V1_COMMIT,
    'v2_commit_binding': binding,
    'source_identity': {'selected': baseline_source, 'v1': sources['v1'], 'v2': sources['v2']},
    'scope': 'Normal release only; no PGO build, training or elapsed campaign. Two independently controlled version campaigns, not paired V2-versus-V1 elapsed measurements. Project XML through native and actual unmodified CPython consumers, not whole-project runs.',
    'native': {v: {'groups': n['groups'], 'all_conditions': n['all_conditions'], 'counts': n['counts'], 'libraries': n['libraries']} for v, n in native.items()},
    'python': {v: {'aggregates': p['aggregates'], 'all_conditions': p['summary'], 'counts': p['counts'], 'libraries': p['libraries']} for v, p in python.items()},
    'allocations': {'rows': allocation_rows, 'v2_vs_v1': allocation['v2']['v1_comparison'],
                    'raw_probe_results': 32, 'feed_records': 204,
                    'scope': 'Per-phase supplied allocator requests, per-feed live bytes/blocks; not RSS or request counts separately for every feed.'},
    'checks': {v: b['tests'] for v, b in builds.items()},
    'api': api, 'strict_and_semantic_independent_review': strict,
    'semantic_receipts': semantics,
    'correctness_scope': 'API retains original assertions/limits. C harnesses use ASan/UBSan; linked normal Rust release libraries are uninstrumented and leak detection is disabled. Strict CPython uses only the explicit upstream cleanup backport, separate from unmodified elapsed extensions; both strict exits remain 2.',
    'instruction_profile': {'source': BASE, 'review': read(PROFILE / 'saved-instruction-review.json'),
                            'scope': 'Four selected-normal profiles only. No V1 or V2 instruction profile; callback work inside XML_Parse is included. Instruction deltas are not elapsed speed or removable-work estimates.'},
    'not_claimed': ['PGO results on either new source', 'new-source installed PBS/glibc validation',
                    'new-source sustained fuzzing', 'new-source CI result in this packet',
                    'general production readiness', 'meeting 1.10x aggregate Expat time'],
    'evidence': {'archive_sha256': sha(archive_path), 'archive_bytes': archive_path.stat().st_size,
                 'members': len(members), 'readback_passed': True, 'index_sha256': sha(OUT / 'index.json'),
                 'conditions': {'rows': 104, 'sha256': sha(OUT / 'conditions.csv')},
                 'adverse_conditions': {'rows': 38, 'sha256': sha(OUT / 'adverse-conditions.csv')},
                 'allocations_sha256': sha(OUT / 'allocations.csv')},
}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
addendum = PREP / 'report-body.md'
assert addendum.is_file()
body = addendum.read_text()
body += f'\n## Reproduce the evidence readback\n\nThe [archive](evidence.tar.gz) contains {len(members):,} files ({archive_path.stat().st_size:,} compressed bytes); executable, library and profile payloads are excluded. [index.json](index.json) maps every member to its original path, byte size and SHA-256. Extraction hashes and every member were read back after writing. The [machine-readable report](report.json) retains all groups, ratios, origins and compatibility outcomes.\n\n```console\nsha256sum evidence.tar.gz\ntar -xzf evidence.tar.gz\n```\n\nArchive SHA-256: `{sha(archive_path)}`. Use the member hashes in `index.json` to verify extracted files; recorded absolute paths describe original provenance.\n'
(OUT / 'README.md').write_text(body)
print(json.dumps({'output': str(OUT), 'archive_sha256': sha(archive_path),
                  'bytes': archive_path.stat().st_size, 'members': len(members),
                  'report_sha256': sha(OUT / 'report.json'), 'index_sha256': sha(OUT / 'index.json')}, indent=2), flush=True)
