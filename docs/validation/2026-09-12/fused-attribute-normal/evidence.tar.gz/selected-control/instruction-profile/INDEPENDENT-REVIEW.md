# Current normal profile: independent readback

All 12 completed command receipts, before/after input pins, four engine-specific version/callback contracts, XML_Parse object origins and annotated function self costs pass independent saved-data review. The original raw self-PC decoder also reproduces every annotation function and all four totals; its historical callee-object bookkeeping is deliberately not used for attribution. No target was executed by this reader.

| Project | Oriole instructions | Expat instructions | Ratio | Ratio excluding driver object |
| --- | ---: | ---: | ---: | ---: |
| Vulkan | 870,326,709 | 523,668,756 | 1.662 | 1.743 |
| Maven | 14,727,882 | 6,068,792 | 2.427 | 2.638 |

Both warmup and measured XML_Parse windows are collected. Instructions are not elapsed time. Identical start/end callback costs and slightly lower Oriole text callback costs show that the comparison is not explained by callback hashing.

## Ranked directions

1. **Fuse native text processing into a reusable scan plan.** The current core repeatedly finds text boundaries, scans invalid XML characters, searches for `]]>`, checks CR eligibility, and advances coordinates. Ordinary native Text already has detached scalar delivery; carry validated span/newline facts into that existing commit path instead of repeating scans. This is an architectural candidate for source design, not an implemented optimization or a promised gain. Keep eager coordinate publication, exact CRLF/UTF-8 and malformed-prefix precedence, root/entity accounting, raw default-current behavior, fallback for conversions/entities/CDATA, and callback/allocator reentry ownership unchanged. The large next-event/delivery layer suggests broad duplicate work is a better target than changing a single allocator or appending instruction hints.
2. **Remove duplicate byte ownership only where the lifetime proof is clear.** libc offset `0x188d80` is a shared memcpy/memmove implementation, proven by the exact current libc IFUNC resolver bytes (see `libc-offset-review/review.json`); `0x188620` is memcmp/bcmp. These are not unidentified Oriole scanners. Core token scratch/current-raw storage and retained C input context make copies, but default handlers can be installed during a callback and XML_DefaultCurrent needs the original spelling. Eliminating those owners requires preserving that behavior; merely skipping copies when a handler is absent is incorrect.
3. **Treat extra arena/SIMD tweaks as secondary measurements.** Existing tag scanning is meaningful on Vulkan but much smaller on Maven. The current code already uses memchr AVX2 and word scans. Allocation entrypoint self costs alone do not measure all allocator cost, and warm caches do not prove cold allocation behavior; no allocator conclusion is drawn from those entrypoints alone.

Selected disjoint Oriole self-code shares (Vulkan / Maven): event and delivery orchestration 23.74% / 28.53%; consume, including inlined coordinate advancement, 7.62% / 9.41%; source accounting 4.57% / 5.90%; tag scanners 10.60% / 4.73%; libc copy implementation 5.64% / 3.87%; arena append 2.55% / 0.92%. These are observations about containing functions, not estimates of removable overhead. Source accounting is being reviewed separately.

Source anchors in the measured capacity checkout: `crates/oriole/src/lib.rs` next_event_inner:1954, token scratch:2225, parse_text:2354, text raw publication:2535, prepare_character_data:3695; `encoding.rs` consume:987 and advance_position:1241; C `run_events_with_frame`:1348 and `XML_DefaultCurrent`:2003. No current-source effect is inferred from rejected older prototypes.
