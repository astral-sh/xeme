# Current Oriole versus Expat instruction profile — held

**Prepared, not executed.** Four serial profiles compare the current generic normal-release Oriole library `a240099f…` with normal Expat 2.8.4 `7a333bc8…`: Vulkan and Maven, namespaces **off**, 65,536-byte feeds. There is no rebuild, profile-guided optimization, extra corpus, or elapsed-time study.

The unchanged faithful C driver performs one warmup and one measured parse. Callgrind collects **both** sets of `XML_Parse` windows, including native callbacks, with the prior flags `--collect-atstart=no --toggle-collect=XML_Parse --dump-instr=yes --collect-jumps=yes`. Parser construction/free and loading outside `XML_Parse` are excluded. Timing fields printed by the driver are ignored; instruction counts are neither elapsed time nor removable-work estimates.

`saved-preflight-rows.json` retains the exact four completed normal native worker records from the capacity study. Each case checks its own saved engine version, warmup/iteration markers, callback digest, element count and text-byte total. Both engines' semantic observations agree for each project. There is no Oriole-only version assertion and no exact text-fragmentation requirement.

The protocol pins all 73 measured Oriole source files, 167 Expat source files, both normal libraries, source/build receipts and compiler artifacts, Expat configuration and original compile logs, corpus manifest and both inputs, the existing driver/source, Python and local Callgrind tools. Oriole is O3/ThinLTO/cgu1 generic x86_64; Expat retains its recorded GCC13.3 O3/shared/no-LTO build. Historical directory/metadata names do not turn these normal artifacts into profile-guided builds. No cancelled training work is resumed.

## Origin and execution

The existing driver calls `dlopen` with the exact pinned library path, then resolves each API symbol through that handle. **It does not call `dladdr`.** This preparation preserves its bytes and requires Callgrind's annotated `XML_Parse` object path to resolve to the expected library, together with the engine-specific output checks. This is not a new `dladdr` origin probe.

Root reviews `protocol.json`, `controller.patch` and `preparation.json`, then executes the exact `release_command_held` recorded in `preparation.json`. It runs on CPU1, outside elapsed campaigns, using the pinned isolated Python interpreter and the released protocol hash. The controller refuses an existing `profile-attempt01`.

Each case has a 30-second preflight, a 300-second Callgrind limit, and a 30-second annotation limit. There are exactly four of each command. The clean environment and process-group kill/reap behavior are preserved; SIGTERM is handled as an interruption, and PID/timestamps/exit status/reaping and raw output hashes are saved. Source/input hashes are checked before and after. Any failed command or output assertion stops the single attempt and preserves its records; bounds never increase automatically.

Annotation must account for all collected instructions as disjoint function self costs. No old disassembly or debug companion is used. Further instruction-level attribution requires reading these current files after execution; historical `4064` profile percentages are not current measurements.
