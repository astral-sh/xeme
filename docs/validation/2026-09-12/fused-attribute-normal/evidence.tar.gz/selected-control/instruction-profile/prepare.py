"""Prepare four profiles of existing normal binaries; never execute targets."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import shutil

ROOT = Path(__file__).resolve().parent
OLD = Path('/tmp/oriole-normal-namespace-profile')
STUDY = Path('/tmp/oriole-expanded-start-capacity-study')
EXPAT = Path('/tmp/oriole-pgo-study')
NATIVE = STUDY / 'native/native-screen'
PYTHON = Path('/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12')
DRIVER_SOURCE = Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c')
CORPUS = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())

def write_json(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

assert __debug__ and os.sched_getaffinity(0) == {6}
old, preflight, native = [load(p) for p in [OLD / 'protocol.json', NATIVE / 'preflight.json', NATIVE / 'protocol.json']]
source, build, binding = [load(STUDY / n) for n in ['source.json', 'build.json', 'build-binding.json']]
expat_source, expat_build = [load(EXPAT / n) for n in ['expat-source.json', 'expat-control-build.json']]
assert preflight['status'] == 'passed' and preflight['hashes_before'] == preflight['hashes_after']
assert preflight['protocol_sha256'] == sha(NATIVE / 'protocol.json')
assert len(source['sha256']) == 73
assert len(expat_source['files']) == 167 and expat_source['version'] == '2.8.4'
assert build['status'] == binding['status'] == expat_build['status'] == 'passed'
assert binding['build_sha256'] == sha(STUDY / 'build.json')
assert binding['source']['source_sha256'] == sha(STUDY / 'source.json')
assert expat_build['source_manifest_sha256'] == sha(EXPAT / 'expat-source.json')
assert expat_build['label'] == 'control' and expat_build['flags'] == ''
libraries = {engine: native['libraries'][engine] for engine in ['candidate', 'expat']}
assert libraries['candidate']['sha256'] == 'a240099fb67c83495c15cb50054d08d4abfc16aec699237f08ca606f90bb95bb'
assert libraries['expat']['sha256'] == '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'
assert libraries['candidate']['sha256'] == binding['candidate_libraries']['liboriole_expat.so']
assert libraries['expat']['sha256'] == expat_build['library_sha256'] == expat_source['normal_library_sha256']
pins = {}
for engine, library in libraries.items():
    assert sha(library['path']) == library['sha256'] == preflight['hashes_after'][library['path']]
    pins[library['path']] = library['sha256']
for relative, digest in source['sha256'].items():
    path = Path(source['worktree']) / relative
    assert sha(path) == digest
    pins[str(path)] = digest
for relative, digest in expat_source['files'].items():
    path = EXPAT / 'expat-source' / relative
    assert sha(path) == digest
    pins[str(path)] = digest
for vector in binding['compiler_vectors_normalized'].values():
    assert 'opt-level=3' in vector and 'codegen-units=1' in vector
    assert vector[vector.index('--target') + 1] == 'x86_64-unknown-linux-gnu'
    assert not any('profile-generate' in x or 'profile-use' in x or 'target-cpu' in x for x in vector)
assert 'lto=thin' in binding['compiler_vectors_normalized']['oriole_expat']
for path, digest in binding['tool_hashes'].items():
    assert sha(path) == digest
    pins[path] = digest
for path, digest in expat_build['tools_sha256'].items():
    if 'gcov' not in path:
        assert sha(path) == digest
        pins[path] = digest
cache = EXPAT / 'expat-control-build/CMakeCache.txt'
config = EXPAT / 'expat-control-build/expat_config.h'
assert 'CMAKE_C_FLAGS:STRING=\n' in cache.read_text()
assert 'CMAKE_C_FLAGS_RELEASE:STRING=-O3 -DNDEBUG\n' in cache.read_text()
assert sha(config) == expat_build['generated_config_sha256'] == expat_build['normal_config_sha256']
for command in expat_build['commands']:
    assert command['returncode'] == 0 and sha(command['log']) == command['log_sha256']
    pins[command['log']] = command['log_sha256']
driver = old['cases'][0]['preflight']['argv'][0]
valgrind = old['cases'][0]['profile']['argv'][0]
annotate = old['cases'][0]['annotation']['argv'][0]
for path in [driver, valgrind, annotate, str(Path(old['valgrind_lib']) / 'callgrind-amd64-linux'), str(Path(old['valgrind_lib']) / 'vgpreload_core-amd64-linux.so'), str(DRIVER_SOURCE)]:
    assert sha(path) == old['pins'][path]
    pins[path] = sha(path)
assert pins[driver] == native['hashes'][driver]
assert sha(CORPUS) == native['hashes'][str(CORPUS)]

original = (OLD / 'run.py').read_text()
controller = original.replace('def observations(text):', 'def observations(text, expected_version):').replace("assert data['version'] == 'oriole_compat_2.8.4'", "assert data['version'] == expected_version")
controller = controller.replace("assert len(source['source_sha256']) == 72", "assert len(source['sha256']) == 73").replace("source['source_sha256'].items()", "source['sha256'].items()")
controller = controller.replace("assert observations(run(case['preflight'])) == expected", "assert observations(run(case['preflight']), case['expected_version']) == expected").replace("assert observations(run(case['profile'])) == expected", "assert observations(run(case['profile']), case['expected_version']) == expected")
anchor = "            assert sum(f['Ir'] for f in functions) == total\n"
assert controller.count(anchor) == 1
controller = controller.replace(anchor, anchor + "            parse_objects = sorted({f['object'] for f in functions if f['function'].split(':')[-1] == 'XML_Parse'})\n            assert parse_objects and all(Path(p).resolve() == Path(case['library']).resolve() for p in parse_objects)\n")
controller = controller.replace("'functions': functions, 'unparsed_Ir': 0", "'functions': functions, 'unparsed_Ir': 0, 'XML_Parse_objects': parse_objects, 'engine': case['engine'], 'expected_version': case['expected_version']")
controller = controller.replace("    assert os.sched_getaffinity(0) == {1}", "    assert __debug__ and os.sched_getaffinity(0) == {1}\n    assert Path(os.sys.executable).resolve() == Path(protocol['python']).resolve()\n    def interrupted(signum, frame):\n        raise KeyboardInterrupt('SIGTERM')\n    signal.signal(signal.SIGTERM, interrupted)")
controller = controller.replace("                row['exit'] = process.wait(timeout=row['timeout_seconds'])", "                row['pid'] = process.pid\n                row['exit'] = process.wait(timeout=row['timeout_seconds'])")
ast.parse(controller)
(ROOT / 'run.py').write_text(controller)
(ROOT / 'controller.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), controller.splitlines(True), 'prior/run.py', 'current/run.py')))
prior = ROOT / 'prior'
prior.mkdir(exist_ok=False)
for name in ['run.py', 'protocol.json', 'preparation.json', 'README.md']:
    shutil.copyfile(OLD / name, prior / name)

cases, selected_rows = [], []
for name in ['vulkan', 'maven']:
    for engine in ['candidate', 'expat']:
        row, = [r for r in preflight['rows'] if r['engine'] == engine and r['condition']['name'] == name and not r['condition']['namespaces'] and r['condition']['chunk'] == 65536]
        assert row['returncode'] == 0 and row['stderr'] == ''
        assert row['command'][:3] == ['taskset', '-c', '5']
        argv = row['command'][3:]
        library, input_path = libraries[engine]['path'], row['condition']['input']
        assert argv == [driver, library, input_path, '65536', '1']
        assert sha(input_path) == preflight['hashes_after'][input_path]
        pins[input_path] = sha(input_path)
        data = json.loads(row['stdout'])
        samples = data['samples']
        assert len(samples) == 2 and [s['warmup'] for s in samples] == [True, False]
        assert [s['iteration'] for s in samples] == [0, 1]
        expected = [[s[k] for k in ['hash', 'elements', 'text_bytes']] for s in samples]
        assert expected[0] == expected[1] == row['observations'][0]
        label = name + '-' + engine + '-ns0'
        profile = ROOT / 'profile-attempt01' / (label + '.callgrind')
        profile_argv = [valgrind, '--tool=callgrind', '--collect-atstart=no', '--toggle-collect=XML_Parse', '--dump-instr=yes', '--collect-jumps=yes', '--callgrind-out-file=' + str(profile), *argv]
        cases.append({'label': label, 'engine': engine, 'library': library, 'library_sha256': libraries[engine]['sha256'], 'condition': row['condition'] | {'iterations': 1}, 'inherited_elapsed_iterations': row['condition']['iterations'], 'expected_version': data['version'], 'expected_observations': expected, 'profile_path': str(profile), 'preflight': {'label': label + '-preflight', 'argv': argv, 'timeout_seconds': 30}, 'profile': {'label': label + '-profile', 'argv': profile_argv, 'timeout_seconds': 300}, 'annotation': {'label': label + '-annotation', 'argv': [annotate, '--auto=no', '--threshold=100', '--show-percs=no', str(profile)], 'timeout_seconds': 30}})
        selected_rows.append(row)
    assert cases[-1]['expected_observations'] == cases[-2]['expected_observations']
write_json(ROOT / 'saved-preflight-rows.json', {'origin': str(NATIVE / 'preflight.json'), 'origin_sha256': sha(NATIVE / 'preflight.json'), 'rows': selected_rows, 'note': 'Saved preflight evidence only; no current-profile targets executed.'})
for path in [STUDY / 'source.json', STUDY / 'build.json', STUDY / 'build-binding.json', NATIVE / 'protocol.json', NATIVE / 'preflight.json', EXPAT / 'expat-source.json', EXPAT / 'expat-control-build.json', cache, config, CORPUS, PYTHON, OLD / 'protocol.json', OLD / 'run.py', ROOT / 'run.py', ROOT / 'saved-preflight-rows.json', ROOT / 'README.md', Path(__file__)]:
    pins[str(path)] = sha(path)
assert all(sha(path) == value for path, value in pins.items())
protocol = {'status': 'prepared_execution_held', 'cpu': 1, 'python': str(PYTHON), 'scope': 'Four current ordinary normal-release instruction profiles: Oriole4815/a240 and Expat2.8.4/7a333, Vulkan and Maven, namespaces off,64KiB. Both warmup1 and measured1 XML_Parse windows and callbacks collected. No build, PGO, elapsed study or CPU-cycle claim.', 'libraries': libraries, 'source_manifest': str(STUDY / 'source.json'), 'source_note': 'All73 current Oriole measured source bytes and all167 pinned Expat source bytes are checked. Historical artifact directory names do not change these normal build modes.', 'valgrind_lib': old['valgrind_lib'], 'pins': pins, 'cases': cases, 'collection_note': old['collection_note'], 'origin_limit': 'Unchanged faithful driver explicitly dlopens the pinned path and resolves symbols through that handle; it does not call dladdr. Require annotation XML_Parse object paths to resolve to the expected library, engine-specific version and saved callback observations. No replacement driver or extra origin target.', 'static_note': 'No static/compiler phase or different-binary disassembly attribution. Existing callgrind_annotate supplies disjoint function self instruction counts; counts are not elapsed time or removable-work estimates.', 'failure_policy': 'Single fresh attempt, serial; stop at first failure, retain raws, timeout or interrupt kills/reaps target process group, before/after pinned-input verification.'}
write_json(ROOT / 'protocol.json', protocol)
command = ['/usr/bin/taskset', '-c', '1', str(PYTHON), '-I', '-S', str(ROOT / 'run.py'), '--phase', 'profile', '--released-protocol-sha256', sha(ROOT / 'protocol.json')]
result = {'status': 'prepared_not_executed', 'targets_executed': False, 'case_count': 4, 'commands': {'preflight': 4, 'callgrind': 4, 'annotation': 4}, 'protocol_sha256': sha(ROOT / 'protocol.json'), 'controller_sha256': sha(ROOT / 'run.py'), 'preparer_sha256': sha(Path(__file__)), 'prior_controller': {'path': str(OLD / 'run.py'), 'sha256': sha(OLD / 'run.py')}, 'adaptation': 'Current73 source binding, two normal engines/two projects/ns0, engine-specific saved versions/observations, annotation XML_Parse object validation, interpreter/SIGTERM/PID receipts. Same faithful driver, XML_Parse toggles, one warmup+one measured parse, limits and annotation math.', 'release_command_held': command}
write_json(ROOT / 'preparation.json', result)
print(json.dumps(result, indent=2))
