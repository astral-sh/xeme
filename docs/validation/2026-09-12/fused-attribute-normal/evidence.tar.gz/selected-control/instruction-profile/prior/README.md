# Normal-release namespace instruction profile — prepared

Profile the existing selected **normal-release** library `087d131c…`, using the faithful existing native C driver. No binary is rebuilt. The historical artifact directory name does not change the selected normal library's build mode.

Four cases: Maven and GTK, each with namespaces off/on, **65,536-byte feeds**. Driver argument `1` performs one warmup and one measured parse; both sets of `XML_Parse` calls are collected. Each case also has a separate preflight and maintained annotation command. All targets remain held until root releases the command in `preparation.json`.

Callgrind reuses `--collect-atstart=no --toggle-collect=XML_Parse --dump-instr=yes --collect-jumps=yes`. Native callbacks inside `XML_Parse` are included; parser construction/free and library loading outside it are excluded. Expected callback digests, element counts and text-byte totals come from the exact selected normal library's saved 64-KiB preflights. These checks do not require exact text-callback fragmentation.

Execution stays serial on CPU1, with 30 seconds per preflight, 300 per Callgrind process and 30 per annotation. The existing clean environment, first-failure retention, process-group kill/reap and before/after source/input hashes remain. The controller's obsolete static prerequisite is removed because that saved assembly belongs to a different binary. No compiler, debug companion or static collection is planned.

The old source/symbol PC reader is copied unchanged for later saved-data analysis. Instruction counts and disjoint self costs are not elapsed time, CPU stalls or removable-work estimates. Preparation runs no parser, compiler, profiler or benchmark target and does not modify the cancelled training study.
