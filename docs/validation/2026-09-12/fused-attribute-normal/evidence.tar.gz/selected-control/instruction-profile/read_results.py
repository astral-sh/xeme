"""Audit saved current/Expat Callgrind records; no target execution or elapsed inference."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import runpy

assert __debug__ and os.sched_getaffinity(0) == {6}
D = Path(__file__).parent
O = D/'profile-attempt01'
pins = {}
def read(p):
    p = Path(p); data = p.read_bytes()
    pins[str(p)] = hashlib.sha256(data).hexdigest()
    return data
def sha(p): read(p); return pins[str(Path(p))]
def load(p): return json.loads(read(p))
def check(mapping):
    for p, h in mapping.items(): assert sha(p) == h, p

p = load(D/'protocol.json'); prep = load(D/'preparation.json'); r = load(O/'report.json')
assert sha(D/'protocol.json') == prep['protocol_sha256'] == r['protocol_sha256'] == '5928527018a7a20601c569fbe1a7d9152e35843224c526bc5b93f8185b897331'
assert sha(D/'run.py') == prep['controller_sha256']
assert r['status'] == 'passed' and r['cpu'] == 1 and r['phase'] == 'profile'
assert r['inputs_unchanged'] and r['hashes_before'] == r['hashes_after'] == p['pins']
check(p['pins'])
source = load(p['source_manifest']); assert len(source['sha256']) == 73
check({str(Path(source['worktree'])/n): h for n, h in source['sha256'].items()})
assert r['environment'] == {'HOME':'/home/dev-user','PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','LD_PRELOAD':'','LD_LIBRARY_PATH':'','VALGRIND_LIB':p['valgrind_lib']}
assert len(p['cases']) == len(r['profiles']) == 4 and len(r['commands']) == 12
saved = load(D/'saved-preflight-rows.json')
assert saved['origin_sha256'] == sha(saved['origin'])
prior = load(saved['origin']); assert prior['status'] == 'passed'
assert len(saved['rows']) == 4

# Reuse only the original raw self-cost decoder. Its historical callee-object
# state is not used for inclusive attribution or emitted in this readback.
decoder_path = Path('/tmp/oriole-normal-namespace-profile/read_pcs.py')
assert sha(decoder_path) == '983243ba414a2247b482c2428e6627a3d3bb842a9acd8fa6e964bdf9a4dffcab'
decode = runpy.run_path(str(decoder_path))['read']
result = []
for i, (case, profile, saved_row) in enumerate(zip(p['cases'], r['profiles'], saved['rows'], strict=True)):
    project = case['condition']['name']; engine = case['engine']
    assert project in ('vulkan','maven') and engine in ('candidate','expat')
    assert case['condition']['chunk'] == 65536 and case['condition']['namespaces'] is False and case['condition']['iterations'] == 1
    assert case['library'] == p['libraries'][engine]['path'] and case['library_sha256'] == p['libraries'][engine]['sha256']
    assert case['expected_version'] == {'candidate':'oriole_compat_2.8.4','expat':'expat_2.8.4'}[engine]
    assert saved_row in prior['rows'] and saved_row['engine'] == engine and saved_row['condition']['name'] == project
    assert saved_row['command'][3:] == case['preflight']['argv']
    assert case['profile']['argv'][-5:] == case['preflight']['argv']
    assert case['profile']['argv'][1:7] == ['--tool=callgrind','--collect-atstart=no','--toggle-collect=XML_Parse','--dump-instr=yes','--collect-jumps=yes','--callgrind-out-file='+case['profile_path']]
    expected = case['expected_observations']
    assert expected[0] == expected[1] == saved_row['observations'][0]
    for phase, row in zip(('preflight','profile','annotation'), r['commands'][i*3:i*3+3], strict=True):
        command = case[phase]
        assert {k:row[k] for k in command} == command
        assert row['exit'] == 0 and row['reaped'] is True and row['pid'] > 0 and row['completed'] >= row['started'] and 'exception' not in row
        assert row['timeout_seconds'] == {'preflight':30,'profile':300,'annotation':30}[phase]
        for channel in ('stdout','stderr'): assert sha(O/(row['label']+'.'+channel)) == row[channel+'_sha256']
        if phase in ('preflight','profile'):
            data = load(O/(row['label']+'.stdout'))
            assert data['version'] == case['expected_version']
            assert len(data['samples']) == 2
            assert [s['iteration'] for s in data['samples']] == [0,1]
            assert [s['warmup'] for s in data['samples']] == [True,False]
            assert [[s['hash'],s['elements'],s['text_bytes']] for s in data['samples']] == expected
    raw = read(case['profile_path']).decode()
    assert re.findall(r'^events: (.+)$',raw,re.M) == ['Ir']
    assert re.findall(r'^positions: (.+)$',raw,re.M) == ['instr line']
    assert re.findall(r'^part: (.+)$',raw,re.M) == ['1']
    total, = re.findall(r'^summary: (\d+)$',raw,re.M); total = int(total)
    annotation = read(O/(case['annotation']['label']+'.stdout')).decode()
    functions = []
    for line in annotation.splitlines():
        m = re.fullmatch(r'\s*([\d,]+)\s+(.+?) \[([^\]]+)\]',line)
        if m: functions.append({'Ir':int(m[1].replace(',','')),'function':m[2],'object':m[3]})
    assert functions == profile['functions'] and sum(f['Ir'] for f in functions) == total == profile['Ir']
    assert profile['profile_sha256'] == sha(case['profile_path'])
    assert profile['actual_measured_iterations'] == profile['warmup_iterations'] == 1 and profile['unparsed_Ir'] == 0
    parse_objects = sorted({f['object'] for f in functions if f['function'].split(':')[-1] == 'XML_Parse'})
    assert parse_objects == profile['XML_Parse_objects'] == [case['library']]
    decoded = decode(Path(case['profile_path']))
    assert decoded['Ir'] == decoded['self_cost_sum'] == total and decoded['unknown_lines'] == []
    assert all(f['function'].startswith('???:') for f in functions)
    annotation_costs = Counter({(f['object'],f['function'][4:]):f['Ir'] for f in functions})
    decoded_costs = Counter({(f['object'],f['function']):f['Ir'] for f in decoded['functions']})
    assert annotation_costs == decoded_costs
    object_costs = Counter()
    for f in functions: object_costs[f['object']] += f['Ir']
    driver = case['preflight']['argv'][0]
    result.append({'label':case['label'],'condition':case['condition'],'library':case['library'], 'Ir':total,
        'parser_self_Ir':object_costs[case['library']], 'driver_self_Ir':object_costs[driver],
        'non_driver_Ir':total-object_costs[driver],
        'objects':[{'object':obj,'Ir':cost} for obj,cost in object_costs.most_common()],
        'functions':functions,'raw_self_decode_matches_annotation':True})
comparisons = {}
for project in ('vulkan','maven'):
    o, = [x for x in result if x['label']==project+'-candidate-ns0']
    e, = [x for x in result if x['label']==project+'-expat-ns0']
    comparisons[project]={'Oriole_Ir':o['Ir'],'Expat_Ir':e['Ir'],'total_instruction_ratio':o['Ir']/e['Ir'],
        'non_driver_instruction_ratio':o['non_driver_Ir']/e['non_driver_Ir'],
        'difference_Ir':o['Ir']-e['Ir']}
report={'status':'passed_saved_instruction_readback','targets_executed':False,'commands':12,'profiles':result,'comparisons':comparisons,
    'limitations':['Collected both XML_Parse parse windows, including callbacks; construction/free outside those windows is excluded.',
    'Function self instructions are disjoint. No elapsed savings or inclusive/callee-object attribution is inferred.',
    'The unchanged driver does not call dladdr. Version/output contracts and actual annotated XML_Parse object paths match pinned libraries.',
    'C library hidden-function labels require exact-object static resolution; no old binary address mapping is transferred.'],
    'report_sha256':sha(O/'report.json'),'reader_sha256':sha(__file__),'pins':pins}
for path,h in pins.items(): assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h,path
out=D/'saved-instruction-readback.json'
with out.open('x') as f: f.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'comparisons':comparisons,'report':str(out),'sha256':sha(out)},indent=2))
