# Current normal-release semantic coverage — held preparation

**Prepared, not executed.** Two existing supplemental diagnostics are bound to publication `4815cf78d7419a18df8d698aaae0bbde8daa526f` and the current generic normal-release library, SHA-256 `a240099fb67c83495c15cb50054d08d4abfc16aec699237f08ca606f90bb95bb`. No compiler or parser has run here. Root reviews and releases each command, serially outside elapsed campaigns.

The 73 measured source files match the current checkout. `evidence/current-source-binding.json`, the original source/build receipts, and `evidence/runtime-from-4064.patch` identify that relationship. This is the existing O3/ThinLTO/cgu1 generic x86_64 build; there is no Rust build, CPU-target change, profile collection, or profile-guided build in this preparation. The copied prior metadata describes historical diagnostics only.

## Scope and unchanged original results

The current original API matrix remains **4,740 configurations: 4,347 pass, 391 assertion failures, two per-test timeouts**. Its outer invocation returned 1 and did not hit its whole-run timeout; `failed=393` in its JSON includes both kinds of nonpass. `evidence/current-api-{results,manifest}.json`, `current-api-tests.log`, and the existing API/C readback are copied unchanged. Each controller hashes the entire original API tree before and after its run. Diagnostic outcomes never replace or reclassify those results.

Each subdirectory copies the finalized C/header trees of its corresponding prior diagnostic byte-for-byte. Relative to the current original API harness, only `six-case/adapted/alloc_tests.c` or `buffer-tail/adapted/nsalloc_tests.c` differs. The complete patches are retained. No fixture, handler, selection order, or additional assertion is changed during relocation.

### Six-case retry diagnostic: 72 configurations

The only six retry-constant changes remain:

| Test suffix (all begin `test_alloc_`) | Original → diagnostic |
| --- | ---: |
| `public_entity_value` | 50 → 512 |
| `nested_groups` | 20 → 512 |
| `notation` | 20 → 512 |
| `public_notation` | 20 → 512 |
| `system_notation` | 20 → 512 |
| `dtd_default_handling` | 25 → 512 |

The preserved assertions check the expected entity/notation/declaration callback flags, the nested start-element sequence `doce`, and exact accumulated DTD/default text plus all 11 original callback flags. Every test still requires allocation injection to fail initially and parsing to succeed before the raised ceiling. These tests stop at the first successful retry; they do not establish exhaustive OOM coverage or exact declaration arguments, counts, ordering, or coordinates. The complete per-test explanation remains in `six-case/prior/README.md`.

### Buffered-parser continuation: 12 configurations

The sole behavioral adjustment remains the existing observation of the second empty `XML_ParseBuffer(0, false)` call's status, error, and allocation counter while failure injection is enabled. Its old two OOM assertions are replaced by that observation; the explicit stdio include is retained. No observed status/error is required or treated as Expat-equivalent. No allocation-retry constants change.

All earlier assertions and the entire original tail remain: fresh no-buffer error; successful reservation; allocator restoration; empty parse; not-suspended resume error; complete document causing the original callback to suspend; suspended parse/get-buffer rejection; successful resume; finished parse/get-buffer rejection; teardown. The callback's text bytes/count are not an oracle in this test. The complete unchanged sequence is in `buffer-tail/prior/README.md`. That prior directory also preserves the historical header-insertion preparation correction, which preceded its original target run.

## Held commands and limits

`held-commands.json` records exact root argv. Each controller refuses an existing `run01` and requires the explicit release argument:

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-expanded-start-semantic-coverage-current/six-case/run.py --released
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-expanded-start-semantic-coverage-current/buffer-tail/run.py --released
```

Each run compiles one C consumer with the original `-O1 -DXML_TESTING -D_GNU_SOURCE` vector, remapping only directory paths. It then runs the original six chunk settings (0–5) and both deferral settings. The C consumer and linked Rust library are uninstrumented.

| Diagnostic | Per context | Address space | Sampled RSS | Whole test invocation | C compile |
| --- | ---: | ---: | ---: | ---: | ---: |
| Six-case | 15 s | 4 GiB | 3 GiB | 300 s | 120 s |
| Buffer-tail | 3 s | 1 GiB | 768 MiB | 240 s | 120 s |

The unchanged C runner isolates and reaps each test child, sets its alarm and `RLIMIT_AS`, and samples RSS; this is not an exact peak-memory bound. Each controller launches a separate target process group, kills and reaps it on timeout or interruption, and records actual argv, environment, PID, timestamps, exit code, reaping, and log hashes. Its small `controller.patch` adds these receipts, source/interpreter pins, and explicit release to the prior runner; outcome parsing and pass criteria are unchanged. Actual `dladdr(XML_Parse)` origins must identify the staged normal library. Bounds are never increased automatically.

`prepare01.stdout` and `prepare01.stderr` preserve the first preparation attempt: exit 0, no targets. A successful future diagnostic would refresh only the stated semantic coverage for this source/library; it would not establish original allocation-schedule equivalence or production readiness.
