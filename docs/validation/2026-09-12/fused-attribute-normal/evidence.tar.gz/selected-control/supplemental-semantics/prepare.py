"""Relocate two finalized diagnostics and bind saved normal artifacts; no targets."""
from pathlib import Path
import ast
import collections
import difflib
import hashlib
import json
import os
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
WORKTREE = Path('/home/dev-user/code/oss/oriole-expanded-start-capacity')
STUDY = Path('/tmp/oriole-expanded-start-capacity-study')
CORRECTNESS = Path('/tmp/oriole-expanded-start-capacity-correctness')
BASE = CORRECTNESS / 'api-native/upstream-api'
PYTHON = Path('/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12')
LIBRARY = STUDY / 'normal/liboriole_expat.so'
HEAD = '4815cf78d7419a18df8d698aaae0bbde8daa526f'
LIBRARY_SHA = 'a240099fb67c83495c15cb50054d08d4abfc16aec699237f08ca606f90bb95bb'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())

def write_json(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

def tree(path):
    return {str(p.relative_to(path)): sha(p) for p in sorted(path.rglob('*')) if p.is_file()}

def patch(before, after, label):
    return ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), 'original/' + label, 'current/' + label))

assert __debug__ and os.sched_getaffinity(0) == {6}
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORKTREE, text=True).strip() == HEAD
source, build, binding = [load(STUDY / name) for name in ['source.json', 'build.json', 'build-binding.json']]
assert len(source['sha256']) == 73 and source['worktree'] == str(WORKTREE)
assert all(sha(WORKTREE / path) == value for path, value in source['sha256'].items())
assert build['status'] == binding['status'] == 'passed' and build['source_unchanged']
assert binding['build_sha256'] == sha(STUDY / 'build.json')
assert binding['source']['source_sha256'] == sha(STUDY / 'source.json')
assert sha(LIBRARY) == LIBRARY_SHA == binding['candidate_libraries'][LIBRARY.name]
for vector in binding['compiler_vectors_normalized'].values():
    assert 'opt-level=3' in vector and 'codegen-units=1' in vector
    assert vector[vector.index('--target') + 1] == 'x86_64-unknown-linux-gnu'
    assert not any('profile-generate' in x or 'profile-use' in x or 'target-cpu' in x for x in vector)
assert 'lto=thin' in binding['compiler_vectors_normalized']['oriole_expat']
original = tree(BASE)
matrix, manifest = load(BASE / 'results.json'), load(BASE / 'manifest.json')
review = load(CORRECTNESS / 'api-c-readback.json')
assert review['status'] == 'passed_saved_api_c_readback'
assert review['api'] == {'ordered_configurations': 4740, 'counts': {'pass': 4347, 'fail': 391, 'timeout': 2}, 'changes': [], 'raw_exit': 1, 'original_assertions_and_limits': True}
assert len(matrix['results']) == 4740 and matrix['returncode'] == 1
assert matrix['passed'] == 4347 and matrix['failed'] == 393 and matrix['timed_out'] is False
assert collections.Counter(row['outcome'] for row in matrix['results']) == {'pass': 4347, 'fail': 391, 'timeout': 2}
assert manifest['library_sha256'] == LIBRARY_SHA

evidence = ROOT / 'evidence'
evidence.mkdir(exist_ok=False)
external = {str(WORKTREE / path): value for path, value in source['sha256'].items()}
for path in [STUDY / 'source.json', STUDY / 'build.json', STUDY / 'build-binding.json', CORRECTNESS / 'api-c-readback.json', CORRECTNESS / 'api-native/report.json', LIBRARY, PYTHON]:
    external[str(path)] = sha(path)
for src, name in [(STUDY / 'source.json', 'measured-source.json'), (STUDY / 'build.json', 'normal-build.json'), (STUDY / 'build-binding.json', 'normal-build-binding.json'), (CORRECTNESS / 'api-c-readback.json', 'current-api-c-readback.json'), (CORRECTNESS / 'api-native/report.json', 'current-api-c-report.json'), (BASE / 'manifest.json', 'current-api-manifest.json'), (BASE / 'results.json', 'current-api-results.json'), (BASE / 'tests.log', 'current-api-tests.log')]:
    shutil.copyfile(src, evidence / name)
runtime_diff = subprocess.check_output(['git', 'diff', '4064b0653534aff690c0e0f395a6b3b48da878fc', HEAD, '--', *source['sha256']], cwd=WORKTREE)
(evidence / 'runtime-from-4064.patch').write_bytes(runtime_diff)
write_json(evidence / 'current-source-binding.json', {'publication_head': HEAD, 'worktree': str(WORKTREE), 'source_count': 73, 'source_manifest_sha256': sha(STUDY / 'source.json'), 'all_current_files_match_measured_source': True, 'normal_library_sha256': LIBRARY_SHA, 'normal_build_binding_sha256': sha(STUDY / 'build-binding.json'), 'runtime_from_4064_patch_sha256': sha(evidence / 'runtime-from-4064.patch'), 'note': 'Measured source manifest retains its original build base; publication HEAD has the same 73 measured file bytes.'})

old_run = '''def run(command, log_name, seconds):
    entry = {'argv': command, 'cwd': str(ROOT), 'timeout_seconds': seconds, 'environment': environment}
    report['commands'].append(entry)
    with (OUT / log_name).open('w') as stream:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            entry['exit_code'] = process.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            entry['exit_code'] = process.wait()
            entry['timed_out'] = True
            raise
    entry['log_sha256'] = sha(OUT / log_name)
    return entry['exit_code']
'''
new_run = '''def run(command, log_name, seconds):
    entry = {'argv': command, 'cwd': str(ROOT), 'timeout_seconds': seconds, 'environment': environment, 'started_epoch': time.time()}
    report['commands'].append(entry)
    with (OUT / log_name).open('w') as stream:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        entry['pid'] = process.pid
        try:
            entry['exit_code'] = process.wait(timeout=seconds)
        except BaseException as error:
            entry['timed_out'] = isinstance(error, subprocess.TimeoutExpired)
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            entry['exit_code'] = process.wait()
            raise
        finally:
            entry['reaped'] = process.returncode is not None
            entry['completed_epoch'] = time.time()
            stream.flush()
            entry['log_sha256'] = sha(OUT / log_name)
    return entry['exit_code']
'''
held = []
for label, old_path, changed_name, source_patch in [
    ('six-case', '/tmp/oriole-reference-frame-semantic-diagnostic', 'alloc_tests.c', 'retry-ceilings.patch'),
    ('buffer-tail', '/tmp/oriole-nsalloc-buffer-tail-diagnostic', 'nsalloc_tests.c', 'diagnostic.patch'),
]:
    old, dest = Path(old_path), ROOT / label
    prior = load(old / 'preparation.json')
    dest.mkdir(exist_ok=False)
    prior_dir = dest / 'prior'
    prior_dir.mkdir()
    for name in ['run.py', 'preparation.json', 'README.md', source_patch]:
        shutil.copyfile(old / name, prior_dir / name)
    if label == 'buffer-tail':
        # Preserve the old header-only preparation correction transparently.
        for name in ['prepare-attempt01.py', 'preparation-attempt01.json', 'diagnostic-attempt01.patch', 'preparation-attempt01.stdout', 'preparation-attempt01.stderr']:
            shutil.copyfile(old / name, prior_dir / name)
    changed = []
    for directory in ['adapted', 'lib']:
        shutil.copytree(old / directory, dest / directory)
        assert tree(old / directory) == tree(dest / directory)
        for relative, value in tree(dest / directory).items():
            key = directory + '/' + relative
            assert sha(old / key) == prior['staged_files'][key]
            if value != original[key]:
                changed.append(key)
    assert changed == ['adapted/' + changed_name], changed
    shutil.copyfile(old / source_patch, dest / source_patch)
    shutil.copyfile(LIBRARY, dest / LIBRARY.name)
    for name in ['manifest.json', 'results.json']:
        shutil.copyfile(BASE / name, dest / ('original-' + name))
    log = (BASE / 'tests.log').read_text()
    blocks = []
    for block in re.finditer(r'^ORIOLE_BEGIN\t([^\t\n]+)\t([^\t\n]+)\n.*?^ORIOLE_RESULT\t\1\t\2\t([^\n]+)\n', log, re.M | re.S):
        if block[2] in prior['selected_tests']:
            blocks.append(block[0])
    assert len(blocks) == prior['expected_configurations']
    (dest / 'original-selected-failures.log').write_text(''.join(blocks))
    (dest / 'current-upstream-source.patch').write_text(patch((BASE / 'adapted' / changed_name).read_text(), (dest / 'adapted' / changed_name).read_text(), changed_name))
    controller = (old / 'run.py').read_text()
    assert controller.count(old_run) == 1
    controller = controller.replace(old_run, new_run).replace('import sys\n', 'import sys\nimport time\n')
    controller = controller.replace("OUT.mkdir(exist_ok=False)", "assert __debug__ and sys.argv[1:] == ['--released'], 'Held until root review and release'\nsignal.signal(signal.SIGTERM, lambda signum, frame: (_ for _ in ()).throw(KeyboardInterrupt('SIGTERM')))\nOUT.mkdir(exist_ok=False)")
    anchor = "    assert check_original(), 'Original API matrix/harness changed before execution'\n"
    assert controller.count(anchor) == 1
    controller = controller.replace(anchor, anchor + "    assert Path(sys.executable).resolve() == Path(prepared['python_path']).resolve()\n    for path, expected in prepared['external_pins'].items():\n        assert sha(Path(path)) == expected, path\n")
    (dest / 'run.py').write_text(controller)
    ast.parse(controller)
    (dest / 'controller.patch').write_text(patch((old / 'run.py').read_text(), controller, 'run.py'))
    prepared = {k: v for k, v in prior.items() if k not in ['staged_files', 'prior_controller_path', 'prior_controller_sha256']}
    prepared['status'] = 'held_not_executed'
    prepared['selected_runtime'] = {'publication_head': HEAD, 'library_path': str(LIBRARY), 'library_sha256': LIBRARY_SHA, 'source_manifest_sha256': sha(STUDY / 'source.json'), 'source_file_count': 73, 'build_report_sha256': sha(STUDY / 'build.json'), 'build_binding_sha256': sha(STUDY / 'build-binding.json'), 'mode': 'normal_generic_O3_ThinLTO_cgu1'}
    prepared['python_path'] = str(PYTHON)
    prepared['external_pins'] = external | {str(p): sha(p) for p in evidence.iterdir()}
    prepared['original_base'] = str(BASE)
    prepared['original_files'] = original
    prepared['original_matrix_sha256'] = sha(BASE / 'results.json')
    prepared['compile_command'] = [x.replace(str(old), str(dest)) for x in prior['compile_command']]
    prepared['reused_from'] = {'path': str(old), 'preparation_sha256': sha(old / 'preparation.json'), 'controller_sha256': sha(old / 'run.py'), 'all_c_and_header_bytes_identical': True, 'changed_from_current_original': changed, 'outcome_parser_unchanged': True, 'controller_changes': 'Explicit release/interpreter/source pins; command timestamps, PID and reaped receipts; SIGTERM/interrupt kill and reap. Existing outcome parsing, selection and limits unchanged.'}
    assert sha(Path(prepared['compile_command'][0])) == prepared['compiler_sha256']
    prepared['staged_files'] = tree(dest)
    write_json(dest / 'preparation.json', prepared)
    argv = ['/usr/bin/taskset', '-c', '3', str(PYTHON), '-I', '-S', str(dest / 'run.py'), '--released']
    held.append({'label': label, 'argv': argv, 'cwd': str(ROOT), 'preparation_sha256': sha(dest / 'preparation.json'), 'controller_sha256': sha(dest / 'run.py'), 'expected_configurations': prior['expected_configurations'], 'limits': prior['limits']})
assert tree(BASE) == original
assert all(sha(path) == value for path, value in external.items())
write_json(ROOT / 'held-commands.json', {'status': 'held_not_executed', 'targets_executed': False, 'serial_outside_elapsed_campaigns': True, 'commands': held})
write_json(ROOT / 'preparation.json', {'status': 'held_not_executed', 'targets_executed': False, 'source_head': HEAD, 'source_count': 73, 'normal_library_sha256': LIBRARY_SHA, 'original_api': review['api'], 'commands_sha256': sha(ROOT / 'held-commands.json'), 'prepared_modes': {r['label']: r['preparation_sha256'] for r in held}, 'preparer_sha256': sha(Path(__file__)), 'new_target_compiles': 0, 'new_parser_invocations': 0})
print(json.dumps({'status': 'held_not_executed', 'preparation_sha256': sha(ROOT / 'preparation.json'), 'commands_sha256': sha(ROOT / 'held-commands.json'), 'source_count': 73, 'diagnostic_configurations': 84, 'targets_executed': False}))
