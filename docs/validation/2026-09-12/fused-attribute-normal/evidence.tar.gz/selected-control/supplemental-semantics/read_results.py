"""Audit completed diagnostic records without executing any target."""
from pathlib import Path
import collections
import hashlib
import json
import os
import re

ROOT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
tree = lambda root: {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
assert __debug__ and os.sched_getaffinity(0) == {6}
review = {'status': 'started', 'role': 'Preparation author independently reconstructing root-executed saved outputs; no targets executed by this reader.', 'targets_executed': False, 'modes': {}, 'limitations': ['These 84 supplemental passes do not replace original API outcomes or establish allocation-schedule equivalence.', 'Retry loops stop at their first successful parse; coverage is not exhaustive OOM injection.', 'Buffer observation preserves allocator counter 0; that does not establish absence of attempted malloc/realloc.', 'C consumers and linked normal Rust library are uninstrumented.']}
last_completion = 0
for name, count in [('six-case', 72), ('buffer-tail', 12)]:
    root = ROOT / name
    prep, report = load(root / 'preparation.json'), load(root / 'run01/report.json')
    prior = Path(prep['reused_from']['path'])
    base = Path(prep['original_base'])
    assert report['status'] == 'complete'
    assert report['preparation_sha256'] == sha(root / 'preparation.json')
    assert report['controller_sha256'] == sha(root / 'run.py')
    assert all(sha(root / p) == h for p, h in prep['staged_files'].items())
    assert all(sha(p) == h for p, h in prep['external_pins'].items())
    assert tree(base) == prep['original_files']
    assert all(report[k] for k in ['preflight_passed', 'selection_complete', 'library_origin_verified', 'library_unchanged', 'original_tree_unchanged', 'all_diagnostic_contexts_passed', 'original_tree_unchanged_on_exit'])
    assert report['compile_exit_code'] == report['run_exit_code'] == 0
    assert sha(root / 'run01/runtests') == report['binary_sha256']
    assert sha(root / 'liboriole_expat.so') == prep['selected_runtime']['library_sha256'] == 'a240099fb67c83495c15cb50054d08d4abfc16aec699237f08ca606f90bb95bb'
    assert len(report['commands']) == 2
    environment = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C', 'TMPDIR': '/tmp', **prep['environment']}
    for command, argv, log, seconds in zip(report['commands'], [prep['compile_command'], [str(root / 'run01/runtests'), '--verbose']], ['build.log', 'tests.log'], [120, prep['limits']['total_test_seconds']], strict=True):
        assert command['argv'] == argv and command['cwd'] == str(root)
        assert command['exit_code'] == 0 and command['reaped'] is True
        assert command['timeout_seconds'] == seconds and command['environment'] == environment
        assert command['pid'] > 0 and last_completion <= command['started_epoch'] <= command['completed_epoch']
        assert command['completed_epoch'] - command['started_epoch'] < seconds
        assert command['log_sha256'] == sha(root / 'run01' / log)
        last_completion = command['completed_epoch']
    assert (root / 'run01/build.log').read_bytes() == b''
    assert sha(Path(prep['compile_command'][0])) == prep['compiler_sha256']
    assert tree(root / 'adapted') == tree(prior / 'adapted')
    assert tree(root / 'lib') == tree(prior / 'lib')
    old_prep = load(prior / 'preparation.json')
    assert prep['limits'] == old_prep['limits'] and prep['environment'] == old_prep['environment']
    assert prep['compile_command'] == [v.replace(str(prior), str(root)) for v in old_prep['compile_command']]
    log = (root / 'run01/tests.log').read_text()
    rows = [dict(context=c, test=t, outcome=o, code=int(code)) for c,t,o,code in re.findall(r'^ORIOLE_RESULT\t([^\t\n]+)\t([^\t\n]+)\t([^\t\n]+)\t(\d+)$', log, re.M)]
    begins = re.findall(r'^ORIOLE_BEGIN\t([^\t\n]+)\t([^\t\n]+)$', log, re.M)
    expected_order = [(r['context'], r['test']) for r in load(base / 'results.json')['results'] if r['test'] in prep['selected_tests']]
    assert begins == expected_order == [(r['context'], r['test']) for r in rows]
    assert len(rows) == count == prep['expected_configurations']
    assert {(r['context'], r['test']) for r in rows} == {(c,t) for c in prep['expected_contexts'] for t in prep['selected_tests']}
    assert rows == report['results'] and all(r['outcome'] == 'pass' and r['code'] == 0 for r in rows)
    assert report['outcomes'] == {'pass': count}
    origins = re.findall(r'^ORIOLE_LIBRARY\t(.+)$', log, re.M)
    assert origins == report['library_origins'] == [str(root / 'liboriole_expat.so')]
    assert log.endswith(f'100%: Checks: {count}, Failed: 0\n')
    detail = {'configurations': count, 'passes': count, 'begin_result_order_matches_original': True, 'compile_and_run_reaped_exit0': True, 'actual_argv_and_limits_match': True, 'normal_library_sha256': sha(root / 'liboriole_expat.so'), 'dladdr_origins': origins, 'report_sha256': sha(root / 'run01/report.json'), 'raw_log_sha256': sha(root / 'run01/tests.log'), 'preparation_sha256': sha(root / 'preparation.json'), 'prior_finalized_c_tree_identical': True}
    if name == 'six-case':
        reconstructed = (root / 'adapted/alloc_tests.c').read_text()
        changes = []
        for change in prep['ceiling_changes']:
            pattern = r'START_TEST\(' + re.escape(change['test']) + r'\).*?\nEND_TEST'
            body = re.search(pattern, reconstructed, re.S)[0]
            assert body.count('max_alloc_count = 512;') == 1
            replacement = body.replace('max_alloc_count = 512;', f"max_alloc_count = {change['old_ceiling']};")
            reconstructed = reconstructed.replace(body, replacement, 1)
            changes.append({'test': change['test'], 'old': change['old_ceiling'], 'diagnostic': 512})
        assert reconstructed == (base / 'adapted/alloc_tests.c').read_text()
        detail['only_six_retry_constants_changed'] = changes
    else:
        before = (base / 'adapted/nsalloc_tests.c').read_text()
        after = (root / 'adapted/nsalloc_tests.c').read_text()
        marker = '  /* Now with actual memory allocation */'
        assert before.split(marker, 1)[1] == after.split(marker, 1)[1]
        original_body = re.search(r'START_TEST\(test_nsalloc_parse_buffer\).*?\nEND_TEST', before, re.S)[0]
        current_body = re.search(r'START_TEST\(test_nsalloc_parse_buffer\).*?\nEND_TEST', after, re.S)[0]
        api_calls = lambda text: re.findall(r'\b(XML_\w+)\s*\(', text)
        assert api_calls(original_body) == api_calls(current_body) == prep['source_change']['parser_api_call_sequence_preserved']
        observations = []
        for block in re.finditer(r'^ORIOLE_BEGIN\t([^\t\n]+)\t([^\t\n]+)\n(.*?)^ORIOLE_RESULT\t\1\t\2\t[^\n]+\n', log, re.M | re.S):
            values = re.findall(r'^ORIOLE_EMPTY_BUFFER_OBSERVATION\tstatus=(-?\d+)\terror=(-?\d+)\tallocation_count=(-?\d+)$', block[3], re.M)
            assert len(values) == 1
            status,error,counter = map(int, values[0])
            observations.append({'context': block[1], 'test': block[2], 'status': status, 'error': error, 'allocation_count': counter})
        assert len(observations) == 12 and observations == report['empty_buffer_observations']
        assert all((r['status'],r['error'],r['allocation_count']) == (1,0,0) for r in observations)
        detail.update({'observation': {'status': 'XML_STATUS_OK (1)', 'error': 'XML_ERROR_NONE (0)', 'allocation_count': 0, 'contexts': 12}, 'original_tail_byte_identical': True, 'original_api_call_sequence_preserved': True})
    review['modes'][name] = detail
matrix = load(base / 'results.json')
assert collections.Counter(r['outcome'] for r in matrix['results']) == {'pass':4347, 'fail':391, 'timeout':2}
assert len(matrix['results']) == 4740 and matrix['returncode'] == 1
review['original_api'] = {'configurations':4740, 'pass':4347, 'assertion_failures':391, 'per_test_timeouts':2, 'outer_exit':1, 'unchanged_sha256':sha(base / 'results.json')}
review['reader_sha256'] = sha(Path(__file__))
review['status'] = 'passed_saved_readback'
with (ROOT / 'results-readback.json').open('x') as stream:
    stream.write(json.dumps(review, indent=2) + '\n')
print(json.dumps({'status':review['status'], 'diagnostic_passes':84, 'original_api':review['original_api'], 'review_sha256':sha(ROOT / 'results-readback.json')}))
