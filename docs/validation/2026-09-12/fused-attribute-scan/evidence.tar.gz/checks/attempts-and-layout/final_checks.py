"""Capture the three final-source gates before the unselected performance build."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time
w=Path('/home/dev-user/code/oss/oriole-fused-attribute-scan'); o=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=w/'crates/oriole/src/tag.rs'; expected='50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6'
assert sha(source)==expected
env=dict(os.environ)
for key in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST','CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST'):
 env.pop(key,None)
env.update(CARGO_HOME='/home/dev-user/.cache/toucan/cargo',CARGO_TARGET_DIR='/home/dev-user/.cache/oriole/targets/fused-attribute-scan',CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}',CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_TERM_COLOR='never')
commands=[('workspace-tests02',['test','--workspace','--locked']),('clippy02',['clippy','--workspace','--all-targets','--locked','--','-D','warnings']),('fmt04',['fmt','--all','--','--check'])]
report={'status':'incomplete','tag_source_sha256':expected,'commands':[],'scope':'Full workspace tests, strict workspace/all-target Clippy and final format check on frozen source. Earlier style failures remain separate.'}
path=o/'final-checks.json'; assert not path.exists()
def save(): path.write_text(json.dumps(report,indent=2)+'\n')
save()
try:
 for name,args in commands:
  command=['taskset','-c','3','cargo','+ohm','-Zohm-defaults=no',*args]
  row={'label':name,'command':command,'exit':None,'reaped':False,'timeout_seconds':1200,'start':time.time()}; report['commands'].append(row); save()
  process=None; log=o/(name+'.log')
  with log.open('xb') as stream:
   try:
    process=subprocess.Popen(command,cwd=w,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    row['exit']=process.wait(timeout=1200);row['reaped']=True
   except BaseException:
    if process is not None and process.poll() is None:
     os.killpg(process.pid,signal.SIGKILL);row['exit']=process.wait();row['reaped']=True
    raise
   finally:
    stream.flush();row['end']=time.time();row['log']=str(log);row['log_sha256']=sha(log);save()
  assert row['exit']==0,(name,row)
  assert sha(source)==expected
 text=(o/'workspace-tests02.log').read_text()
 groups=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
 assert len(groups)==35 and tuple(map(sum,zip(*groups)))==(442,0,0)
 report.update(status='passed',test_count=442,failed=0,ignored=0,test_groups=35,controller_sha256=sha(__file__))
finally: save()
print(json.dumps({k:v for k,v in report.items() if k!='commands'},indent=2))
