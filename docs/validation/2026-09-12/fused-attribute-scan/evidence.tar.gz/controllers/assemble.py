"""Package completed fused-attribute records using the compact-coordinate assembler."""
from pathlib import Path
import argparse
import csv
import gzip
import hashlib
import io
import json
import os
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('--released', action='store_true', required=True)
parser.parse_args()
assert os.sched_getaffinity(0) == {6}
OUT = Path('/tmp/oriole-fused-attribute-scan-evidence')
BUILD = Path('/tmp/oriole-fused-attribute-scan-pgo-study')
CONTROL = Path('/tmp/oriole-reference-frame-pgo-study')
REVIEWS = Path('/tmp/oriole-fused-attribute-scan-native-review')
PYTHON = Path('/tmp/oriole-fused-attribute-scan-python-preparation')
PYREVIEWS = Path('/tmp/oriole-fused-attribute-scan-python-review')
CORRECT = Path('/tmp/oriole-fused-attribute-scan-correctness-prep')
read = lambda p: json.loads(Path(p).read_text())

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

assert not OUT.exists()
audits = {mode: read(REVIEWS / f'{mode}-review.json') for mode in ['normal', 'pgo']}
py_audit = read(PYREVIEWS / 'pgo-review.json')
api_audit = read(CORRECT / 'api-c-independent-readback.json')
source, selected = read(BUILD / 'source.json'), read(CONTROL / 'source.json')
build_review, checks, pair = (read(BUILD / name) for name in ['build-readback.json', 'source-checks.json', 'pair-report.json'])
assert source['candidate_base_commit'] == '4064b0653534aff690c0e0f395a6b3b48da878fc'
assert source['base_runtime'] == selected['candidate_base_commit'] == '0f66d54ac8418f0a6e628ad18570677a19c9ed45'
source_delta = sorted(n for n in source['source_sha256'].keys() | selected['source_sha256'].keys()
                      if source['source_sha256'].get(n) != selected['source_sha256'].get(n))
assert source_delta == build_review['summary']['changed_vs_selected'] == ['crates/oriole/src/tag.rs']
assert len(source['source_sha256']) == len(selected['source_sha256']) == 72
assert source['source_sha256']['crates/oriole/src/tag.rs'] == '50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6'
assert checks['status'] == pair['status'] == build_review['status'] == 'passed'
assert checks['test_count'] == 442 and checks['test_groups'] == 35 and checks['failed'] == checks['ignored'] == 0
assert checks['source_manifest_sha256'] == sha(BUILD / 'source.json')
assert pair['generated_parse_records'] == {'normal': 288, 'instrumented': 288, 'optimized': 288}
assert pair['pgo_libraries']['use/liboriole_expat.so'] == '202ae85b10301a52276b4ac7be9134b9eeb2d7d728706f380149e4734304b699'
assert all(a['status'] == 'passed' and a['totals']['all_workers'] == 672
           and a['totals']['all_samples'] == 106176 for a in audits.values())
assert py_audit['status'] == 'passed_independent_raw_elapsed_reconstruction'
assert py_audit['counts']['all_workers'] == 576 and py_audit['counts']['all_samples'] == 26364
assert api_audit['status'] == 'passed_saved_api_c_readback'
assert api_audit['api']['counts'] == {'pass': 4347, 'fail': 391, 'timeout': 2}
assert api_audit['api']['changes'] == [] and api_audit['api']['raw_exit'] == 1
assert len(api_audit['c_consumers']) == 6 and all(c['exit'] == 0 for c in api_audit['c_consumers'])
assert len(read(CORRECT / 'api-native/report.json')['commands']) == 13
assert sha(CORRECT / 'api-native/upstream-api/results.json') == '543838aa8d725d1c5c1fd10b92d6b3ea1ab687eb21390e6260f931fe553f4afb'
assert not (CORRECT / 'strict-cpython').exists()
assert not (CORRECT / 'semantic-commands.json').exists()
assert not (PYTHON / 'python/normal/consumers').exists()
assert not (PYTHON / 'python/normal/screen').exists()

all_pins = {}
python_pins = {str(Path(path) if Path(path).is_absolute() else PYTHON / 'python' / path): digest
               for path, digest in py_audit['evidence_sha256'].items()}
for pins in [*(a['input_sha256'] for a in audits.values()), python_pins, api_audit['inputs']]:
    for path, digest in pins.items():
        assert path not in all_pins or all_pins[path] == digest, path
        all_pins[path] = digest
for path, digest in all_pins.items():
    assert sha(path) == digest, path
for mode, audit in audits.items():
    assert sha(REVIEWS / 'audit.py') == audit['generator_sha256']
    assert sha(REVIEWS / f'{mode}-conditions.csv') == audit['condition_csv_sha256']
assert sha(PYREVIEWS / 'pgo-conditions.csv') == py_audit['condition_csv_sha256']

entries, originals, excluded = {}, {}, {}

def exclusion(path):
    path = Path(path)
    with path.open('rb') as stream:
        magic = stream.read(8)
    if path.suffix in {'.pyc', '.profraw', '.profdata', '.a', '.so'} or '.so.' in path.name or magic.startswith((b'\x7fELF', b'!<arch>\n')):
        return 'external executable/library or binary profile; receipt identity retained'
    return None

def omit(path, reason):
    path = Path(path)
    excluded[str(path)] = {'path': str(path), 'sha256': sha(path), 'size': path.stat().st_size, 'reason': reason}
    if path.is_symlink():
        excluded[str(path)]['symlink_target'] = os.readlink(path)

def add(path, member):
    path = Path(path)
    assert path.is_file(), path
    assert member not in entries, member
    reason = exclusion(path)
    if reason:
        omit(path, reason)
        return
    assert not path.is_symlink(), path
    entries[member], originals[member] = path.read_bytes(), str(path)

def tree(root, prefix):
    assert Path(root).is_dir(), root
    for path in sorted(Path(root).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add(path, prefix + '/' + str(path.relative_to(root)))

# Same source snapshots, add/tree and deterministic archive/readback as the prior packet.
for label, manifest in [('candidate', source), ('selected', selected)]:
    worktree = Path(manifest['worktree'])
    for name, digest in manifest['source_sha256'].items():
        assert sha(worktree / name) == digest, worktree / name
        add(worktree / name, f'source/{label}/{name}')
    for name in ['LICENSE-APACHE', 'LICENSE-MIT', 'THIRD_PARTY_LICENSES.md', 'licenses/expat.txt',
                 'licenses/libxml2.txt', 'licenses/cpython.txt', 'tests/c/UPSTREAM-NOTICES.txt']:
        add(worktree / name, f'source/{label}/{name}')

for root, prefix in [
    ('/tmp/oriole-fused-attribute-scan-preparation', 'source/initial-preparation'),
    ('/tmp/oriole-fused-attribute-scan-checks', 'checks/attempts-and-layout'),
    (str(REVIEWS), 'native/independent-review'),
    (str(BUILD / 'native'), 'native/candidate-campaigns'),
    (str(PYREVIEWS), 'python/independent-review'),
    (str(PYTHON / 'python/pgo'), 'python/pgo-campaign'),
    (str(PYTHON / 'python/normal'), 'prepared-unexecuted/python-normal'),
    (str(CORRECT / 'api-native'), 'correctness/api-and-c-campaign'),
    (str(CORRECT / 'prior'), 'correctness/preparation-prior'),
]:
    tree(root, prefix)
for path in sorted(PYTHON.iterdir()):
    if path.is_file():
        add(path, 'python/preparation/' + path.name)
for path in sorted(CORRECT.iterdir()):
    if path.is_file():
        prefix = 'prepared-unexecuted/strict-and-semantics' if path.name.startswith(('strict_cpython', 'prepare_semantics', 'semantic-commands', 'read_outcomes')) else 'correctness/preparation-and-review'
        add(path, prefix + '/' + path.name)

for mode in ['normal', 'pgo']:
    previous = Path('/tmp/oriole-reference-frame-native-study') / mode
    for name in ['adaptation.json', 'native_screen.py', 'run.py', 'native-screen/protocol.json']:
        add(previous / name, f'native/selected-protocol/{mode}/{name}')

for label, build in [('candidate', BUILD), ('selected', CONTROL)]:
    for path in sorted(build.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log', '.py', '.patch', '.stdout', '.stderr', '.gz', '.md'}:
            add(path, f'build/{label}/{path.name}')
    tree(build / 'pipeline', f'build/{label}/pipeline')
    run = Path(read(build / 'pair-report.json')['pgo_manifest']['path']).parent
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log'}:
            add(path, f'build/{label}/pgo/{path.name}')
    tree(run / 'inputs', f'build/{label}/pgo/inputs')
    add(build / 'pgo/latest.json', f'build/{label}/pgo/latest.json')
    for root in [build / 'normal', run / 'generate', run / 'use']:
        for path in sorted(root.glob('liboriole_expat.*')):
            omit(path, 'compiled parser library; exact source, compiler and output hashes retained')
    if label == 'candidate':
        tree(build / 'local-checks', 'build/candidate/local-checks')
        tree(build / 'prior', 'build/candidate/prior')

for path, member in [
    ('/tmp/oriole-compact-coordinate-evidence-preparation/assemble.py', 'controllers/origin-compact-assemble.py'),
    ('/tmp/oriole-reference-frame-native-independent-review/audit.py', 'controllers/origin-native-audit.py'),
    ('/tmp/oriole-eager-tag-position-triage.md', 'unimplemented-hypothesis/eager-position-note.md'),
    ('/tmp/oriole-reference-frame-v3-pgo-study/host-features.json', 'environment/prior-same-host-features.json'),
    (__file__, 'controllers/assemble.py'),
    (str(Path(__file__).parent / 'attempt01-assemble.py'), 'controllers/assembly-attempt01.py'),
    (str(Path(__file__).parent / 'attempt01.stderr'), 'controllers/assembly-attempt01.stderr'),
    (str(Path(__file__).parent / 'attempt01.stdout'), 'controllers/assembly-attempt01.stdout'),
    (str(Path(__file__).parent / 'attempt02-assemble.py'), 'controllers/assembly-attempt02.py'),
    (str(Path(__file__).parent / 'attempt02.stderr'), 'controllers/assembly-attempt02.stderr'),
    (str(Path(__file__).parent / 'attempt02.stdout'), 'controllers/assembly-attempt02.stdout'),
    (str(Path(__file__).parent / 'prior-frozen-packet.json'), 'controllers/prior-frozen-packet.json'),
    (str(Path(__file__).parent / 'packet-attempt03/README.md'), 'controllers/prior-packet-README.md'),
]:
    add(path, member)
manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
add(manifest, 'inputs/corpus-manifest.json')
for project in read(manifest)['projects']:
    for file in project['files']:
        path = manifest.parent / file['path']
        assert sha(path) == file['sha256']
        add(path, 'inputs/' + file['path'])
add('/tmp/oriole-grammar-bench-plain/entities.xml', 'inputs/generated/entities.xml')
add('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml', 'inputs/generated/rare-declarations.xml')

archived_paths = set(originals.values())
for path, digest in sorted(all_pins.items()):
    if path in archived_paths or path in excluded:
        continue
    p = Path(path)
    if p.name in {'rustup', 'rustc', 'cargo', 'llvm-profdata', 'python3.12', 'native-driver'} or p.suffix == '.toml':
        omit(p, 'external executable or machine Cargo configuration; original receipt pin retained')
    else:
        add(p, 'other-pinned-inputs/' + str(p).lstrip('/'))

rows = []
for mode in ['normal', 'pgo']:
    with (REVIEWS / f'{mode}-conditions.csv').open(newline='') as stream:
        rows.extend(csv.DictReader(stream))
assert len(rows) == 56
assert sum('/native-screen/worker-' in name for name in entries) == 1344
assert sum(name.startswith('python/pgo-campaign/screen/') and name.endswith('-stdout.gz') for name in entries) == 576
OUT.mkdir()
with (OUT / 'native-conditions.csv').open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
(OUT / 'python-pgo-conditions.csv').write_bytes((PYREVIEWS / 'pgo-conditions.csv').read_bytes())
members = []
with (OUT / 'evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for member, data in sorted(entries.items()):
                info = tarfile.TarInfo(member)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                archive.addfile(info, io.BytesIO(data))
                members.append({'member': member, 'original_path': originals[member], 'size': len(data),
                                'sha256': hashlib.sha256(data).hexdigest()})
archive_path = OUT / 'evidence.tar.gz'
with tarfile.open(archive_path, 'r:gz') as archive:
    actual = archive.getmembers()
    assert [m.name for m in actual] == [m['member'] for m in members]
    for record, member in zip(members, actual, strict=True):
        assert member.isfile() and member.size == record['size']
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == record['sha256']
index = {'schema': 'saved-record-bundle-v1',
         'scope': 'Rejected fused attribute scanner: exact source, first attempts, checks, normal/PGO build and native records, PGO Python and original API/six C consumers. Normal Python and strict/semantic preparations unexecuted.',
         'archive': 'evidence.tar.gz', 'archive_sha256': sha(archive_path),
         'archive_bytes': archive_path.stat().st_size, 'archive_readback_passed': True,
         'members': members, 'excluded': list(excluded.values())}
(OUT / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
native = {mode: audits[mode]['native'][mode] for mode in audits}
report = {
    'decision': 'rejected', 'candidate_source_committed': False,
    'candidate_base_commit': source['candidate_base_commit'], 'source_manifest_sha256': sha(BUILD / 'source.json'),
    'candidate_tag_sha256': source['source_sha256']['crates/oriole/src/tag.rs'],
    'selected_runtime': selected['candidate_base_commit'], 'selected_publication': source['candidate_base_commit'],
    'source_delta': source_delta, 'source_files': 72, 'pipeline_files': 69,
    'reason': 'PGO native real-project elapsed improves 1.164%, but PGO CPython elapsed regresses 1.391% overall and 2.732% for ElementTree (11/12 adverse); pyexpat is effectively flat. Keep the selected runtime.',
    'checks': {'passed': 442, 'groups': 35, 'failed': 0, 'ignored': 0, 'workspace_tests_strict_all_target_clippy_fmt': True,
               'receipt': {'path': str(BUILD / 'source-checks.json'), 'sha256': sha(BUILD / 'source-checks.json')}},
    'builds': {'normal_libraries': pair['normal_libraries'], 'pgo_libraries': pair['pgo_libraries'],
               'generated_parse_records': pair['generated_parse_records'], 'compiler_vectors': 9,
               'compiler_body_and_six_pipeline_tools_unchanged': True, 'cpu_targeting': False, 'allocator_changed': False},
    'native': native,
    'python_pgo': {'counts': py_audit['counts'], 'aggregates': py_audit['aggregates'], 'libraries': py_audit['libraries'],
                   'source_results_sha256': py_audit['source_results_sha256'], 'source_preflight_sha256': py_audit['source_preflight_sha256']},
    'api': api_audit['api'], 'c_consumers': api_audit['c_consumers'],
    'sanitizer_scope': 'Six C consumers compiled with ASan/UBSan; Rust PGO library uninstrumented and leak checking disabled.',
    'historical_attempts': ['initial formatting failure and correction', 'initial test-style Clippy failure and equivalent byte-string correction; final full checks repeated', 'pre-final source freeze and original review/binding scripts retained', 'packaging attempt01 stopped before archive creation on Python relative pin paths; corrected to resolve against the recorded study root', 'packaging attempt02 stopped before archive creation on a shared-library soname symlink; binaries and their symlinks are excluded with file hash and link target retained'],
    'prepared_unexecuted': ['normal CPython performance builds/preflight/timing', 'strict shared/static CPython', 'supplemental text-fragmentation checks on this candidate'],
    'not_executed': ['new candidate CI', 'sustained sanitizer/fuzz campaign', 'eager-position hypothesis implementation or measurements'],
    'position_hypothesis_limit': 'Old Context PGO markup position-accounting regions represent 2.64–3.68% of counted instructions in four no-namespace cases, including ineligible markup. This is neither removable-cost nor current elapsed evidence and cannot establish closure of the remaining goal.',
    'scope': 'Evidence-only rejection. One completed normal/PGO native campaign and one PGO CPython campaign on this machine. No statistical significance, whole-application, current profile causality, full API compatibility or within-10%-goal claim.',
    'evidence': {'archive': {'path': 'evidence.tar.gz', 'sha256': sha(archive_path), 'bytes': archive_path.stat().st_size, 'members': len(members), 'readback_passed': True},
                 'index': {'path': 'index.json', 'sha256': sha(OUT / 'index.json')},
                 'native_conditions': {'path': 'native-conditions.csv', 'sha256': sha(OUT / 'native-conditions.csv'), 'rows': 56},
                 'python_conditions': {'path': 'python-pgo-conditions.csv', 'sha256': sha(OUT / 'python-pgo-conditions.csv'), 'rows': 24},
                 'native_reviews': {mode: sha(REVIEWS / f'{mode}-review.json') for mode in audits},
                 'python_review': sha(PYREVIEWS / 'pgo-review.json'), 'api_c_review': sha(CORRECT / 'api-c-independent-readback.json')},
}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
table = []
for mode, group in [('normal', 'real'), ('pgo', 'real'), ('normal', 'generated'), ('pgo', 'generated')]:
    data = native[mode]['groups'][group]
    ratio = data['ratios']['candidate_over_control']
    adverse = sum(r['median_ratios']['candidate_over_control'] > 1 for r in native[mode]['all_conditions']
                  if r['condition']['name'].startswith('generated-') == (group == 'generated'))
    table.append(f"| Native {'PGO' if mode == 'pgo' else 'normal'}, {data['conditions']} {group} | {ratio:.6f}× ({(ratio-1)*100:+.2f}%) | {data['ratios']['candidate_over_expat']:.6f}× | {adverse} / {data['conditions']} |")
for label, key in [('CPython PGO, all', 'all'), ('CPython PGO, ElementTree', 'elementtree'), ('CPython PGO, pyexpat', 'pyexpat-events')]:
    data = py_audit['aggregates'][key]
    ratio = data['geomean_ratios']['candidate_over_control']
    table.append(f"| {label} | {ratio:.6f}× ({(ratio-1)*100:+.2f}%) | {data['geomean_ratios']['candidate_over_expat']:.6f}× | {len(data['adverse_conditions'])} / {data['conditions']} |")
readme = '''# Fused attribute scan — rejected

**Reject this candidate.** Its PGO native gain of 1.16% does not justify the observed CPython regression: 1.39% overall and 2.73% for ElementTree, with 11 of 12 ElementTree conditions slower. Pyexpat is effectively flat. The selected parser stays unchanged.

Only `crates/oriole/src/tag.rs` differs from the selected source. The uncommitted candidate is based on publication `4064b0653534aff690c0e0f395a6b3b48da878fc`; its exact final file SHA-256 is `50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6`. The selected measured source is `0f66d54ac8418f0a6e628ad18570677a19c9ed45`. Source manifests and full snapshots bind the actual bytes; the base commit alone does not identify the candidate.

## Results

Ratios compare elapsed time; below 1 is faster. “Adverse” means the candidate takes longer than the selected control.

| Scope | Candidate / selected control | Candidate / Expat | Adverse conditions |
| --- | ---: | ---: | ---: |
TABLE

[native-conditions.csv](native-conditions.csv) retains all 56 native conditions, including the four generated controls per build. [python-pgo-conditions.csv](python-pgo-conditions.csv) retains all 24 Python conditions. [report.json](report.json) records the reviewed aggregates, identities and limits. Native PGO remains about 31% slower than Expat in this campaign; the within-10% goal is not met.

Native uses six held-out real projects, namespaces off/on, 4 KiB and 64 KiB feeds, and four original generated conditions. Python uses the same six projects and feed sizes with ElementTree and pyexpat event consumers. Each condition retains seven seeded, interleaved process pairs. Condition ratios are medians of paired process-median ratios; aggregates are geometric means across conditions. Independent saved-data readers reconstructed all 1,344 native workers/212,352 observations and 576 Python workers/26,364 observations, including preflights and warmups. No rows or adverse conditions were dropped.

Native timers include parser creation, feed/finalization, callbacks and destruction; input loading and dynamic-library loading are outside. Python timers include parser creation, feeds, finalization, callbacks and explicit destruction; imports, input reading, canonical checks and explicit collection are outside. Automatic GC remains enabled. Python extensions use unchanged CPython 3.12.13 source without the consumer-cleanup backport, compiled with GCC 13.3 at O2. The campaigns ran on Linux x86_64 with an AMD EPYC-Milan processor. These are parser/consumer measurements, without whole-application or statistical-significance claims. The data does not establish the cause of the ElementTree regression.

## Source and build

The change fuses native attribute quote/delimiter scanning with an ordinary-ASCII value proof. Proven values skip a later eligibility scan. General grammar, non-ASCII support and incremental fallback timing remain intact; the change adds no allocation, cache, allocator choice or CPU-specific flags. Focused scanner/planner regressions require completed valid-Unicode plans and preserve the incomplete-to-fallback boundary for an ampersand.

Both Oriole builds retain O3, ThinLTO, one codegen unit, the selected allocator and generic `x86_64-unknown-linux-gnu`. Local builds use `cargo +ohm -Zohm-defaults=no`: the exact receipt identifies `rustc 1.98.1-dev (f62703110 2026-09-08) (ohm-1.98.1-1)`, LLVM 22.1.8. Fresh PGO uses the original generated training recipe; all six real projects remain held out. Nine actual compiler vectors and 864 generated parse records were reviewed against the selected recipe. Expat 2.8.4 uses the retained matching normal or PGO GCC O3/shared controls, without LTO.

Candidate shared libraries are normal `0ce2320a098436307472ba809b0053a910573f830db01d7bc7c5c6ca99ec958c` and PGO `202ae85b10301a52276b4ac7be9134b9eeb2d7d728706f380149e4734304b699`; the PGO static archive is `e69363d0cf2a9439bed0b86c9a200ff26f2752a6b39261b031d24eebe69bd163`. Selected normal/PGO shared controls are `087d131c215012d2a93527a4ec66a716216e8ab4009948a1f79d0a7644d5d949` / `d3c43850247b83aa3089b7f08deb31a084ee2aecb47b52d27e9d05e97b0e1bd4`. Full compiler, profile, Expat and extension identities remain in the saved receipts.

## Correctness and limits

Final local checks passed 442 Rust checks in 35 groups, strict workspace/all-target Clippy and formatting, with zero failed or ignored tests. The first formatting and test-style Clippy failures are retained, together with the corrected final-source run. Debug DWARF reports AttributeScanner 48 bytes, TagScanner 96 and Parser 2408, matching the selected debug binary; this is object-layout evidence only, without a release-layout, heap or RSS claim.

The original upstream matrix remains byte-identical to the selected result: **4,347 pass, 391 assertion failures and two timeouts across 4,740 configurations**. Its nonzero suite exit, original assertions, retry ceilings and 3-second/1-GiB/768-MiB per-context limits are preserved. A successful comparison means no outcome changed; it does not turn those failures into passes. Six C integration/adversarial/allocation consumers passed, with shared and static linking. ASan/UBSan instrumented the C consumers only; the Rust PGO library was uninstrumented and leak checking was disabled.

The candidate was rejected after the PGO Python results. **Normal Python, strict shared/static CPython and supplemental text-fragmentation checks were prepared but never executed on this candidate.** No new candidate CI or sustained sanitizer/fuzz campaign is claimed. Successful performance preflights compare canonical text payload/order and do not establish exact callback fragmentation compatibility. Original selected strict failures remain separate.

## Saved evidence

[evidence.tar.gz](evidence.tar.gz) contains final source and patch, earlier source/check attempts, build/training records, all completed native/Python raw records, original API and six C-consumer outcomes, readers and reviews, input bytes, licenses and notices. Unexecuted controllers are stored under `prepared-unexecuted`; combined preparation files retain their historical stage labels. [index.json](index.json) records each member's original path, size and SHA-256; packaging read back every member.

The source author prepared the candidate and build/correctness adaptations. Root executed all targets and reviewed the build binding. A separate agent reviewed runtime/build source and prepared the native/Python saved-data readers; root executed those readers. That agent directly ran the saved API/C readback. This packet assembly is not a second target execution. Two packaging attempts stopped before archive creation on study-relative Python pins and a shared-library soname symlink. Their scripts/errors and the corrections are retained. The first completed packet is also retained locally with its original hashes; this revision clarifies environment and reviewer roles only. Executables, libraries (including their soname links), binary profiles and machine configuration are excluded with receipt identities retained. Absolute paths identify the original machine; this is a saved-record bundle rather than a self-contained runnable benchmark.

A source-only note about a possible eager position proof is retained as an **unimplemented hypothesis**. Older Context PGO instruction records put a broader markup-position region at 2.64–3.68% in four non-namespace cases; that includes ineligible/other markup and is neither removable cost nor a current elapsed estimate. It does not justify selecting another runtime or claiming the remaining performance gap can be closed.
'''
(OUT / 'README.md').write_text(readme.replace('TABLE', '\n'.join(table)))
print(json.dumps({'directory': str(OUT), 'files': [p.name for p in sorted(OUT.iterdir())],
                  'archive_sha256': sha(archive_path), 'archive_bytes': archive_path.stat().st_size,
                  'archive_members': len(members), 'excluded_inputs': len(excluded),
                  'report_sha256': sha(OUT / 'report.json'), 'index_sha256': sha(OUT / 'index.json'),
                  'readme_sha256': sha(OUT / 'README.md')}, indent=2))
