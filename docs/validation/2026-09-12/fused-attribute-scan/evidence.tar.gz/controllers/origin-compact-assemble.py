"""Package released saved compact-coordinate records; adapted from markup assembler."""
from pathlib import Path
import argparse
import csv
import gzip
import hashlib
import io
import json
import math
import os
import re
import tarfile

args = argparse.ArgumentParser()
args.add_argument('--released', action='store_true', required=True)
args.parse_args()
assert os.sched_getaffinity(0) == {6}
OUT = Path('/tmp/oriole-compact-coordinate-evidence')
BUILD = Path('/tmp/oriole-compact-coordinates-pgo-study')
CONTROL = Path('/tmp/oriole-reference-frame-pgo-study')
NATIVE = Path('/tmp/oriole-compact-coordinate-native-prep')
REVIEWS = Path('/tmp/oriole-compact-coordinate-native-review')
PREP = Path(__file__).parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
assert not OUT.exists()
audits = {mode: read(REVIEWS / f'{mode}-review.json') for mode in ['normal', 'pgo']}
source, selected = read(BUILD / 'source.json'), read(CONTROL / 'source.json')
build_review = read(BUILD / 'build-readback.json')
binding = read('/tmp/oriole-compact-coordinate-ci-preparation/commit-binding.json')
ci = read('/tmp/oriole-compact-coordinate-ci-results/review.json')
assert binding['commit'] == 'e1228bbb9dbd174e2aceff5ecea24a04fecc8515'
assert binding['source_manifest_sha256'] == sha(BUILD / 'source.json')
assert source['candidate_base_commit'] == '97117de5ea51b2bd3f5d348cade85c203c6a888e'
assert selected['candidate_base_commit'] == source['base_runtime'] == '0f66d54ac8418f0a6e628ad18570677a19c9ed45'
source_delta = sorted(n for n in source['source_sha256'].keys() | selected['source_sha256'].keys()
                      if source['source_sha256'].get(n) != selected['source_sha256'].get(n))
assert source_delta == build_review['summary']['changed_vs_selected']
assert len(source_delta) == 14 and len(source['source_sha256']) == 74
assert all(a['status'] == 'passed' and a['totals']['all_workers'] == 672
           and a['totals']['all_samples'] == 106176 for a in audits.values())
for mode, audit in audits.items():
    assert sha(REVIEWS / 'audit.py') == audit['generator_sha256']
    assert sha(REVIEWS / f'{mode}-conditions.csv') == audit['condition_csv_sha256']
    for path, digest in audit['input_sha256'].items():
        assert sha(path) == digest, path
checks = read(BUILD / 'source-checks.json')
assert checks['status'] == 'passed' and checks['test_count'] == 449 and checks['test_groups'] == 34
pair = read(BUILD / 'pair-report.json')
assert pair['status'] == build_review['status'] == 'passed'
assert pair['generated_parse_records'] == {'normal': 288, 'instrumented': 288, 'optimized': 288}
assert ci['head'] == 'be31c37baadcc711a84120c487ac13383dd0ccc7'
assert ci['jobs_passed'] == 16 and ci['total_focused_passes'] == 36
assert all(m['passed'] == 18 and m['failed'] == 0 for m in ci['models'].values())
layout_text = Path('/tmp/oriole-compact-coordinate-layout/stderr').read_text()
layout = {k: int(v) for k, v in re.findall(r'(CParser|Parser|AdapterFrame|AdapterLocation)=(\d+)', layout_text)}
assert layout == {'CParser': 3184, 'Parser': 2424, 'AdapterFrame': 264, 'AdapterLocation': 40}
entries, originals, excluded = {}, {}, []

def add(path, member):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert member not in entries, member
    data = path.read_bytes()
    assert not data.startswith((b'\x7fELF', b'!<arch>\n')), path
    assert path.suffix not in {'.pyc', '.profraw', '.profdata', '.a', '.so'}, path
    entries[member], originals[member] = data, str(path)

def tree(root, prefix):
    assert Path(root).is_dir(), root
    for path in sorted(Path(root).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add(path, prefix + '/' + str(path.relative_to(root)))

# Same source snapshots, add/tree and deterministic archive/readback as the prior packet.
for label, manifest in [('candidate', source), ('selected', selected)]:
    worktree = Path(manifest['worktree'])
    for name, digest in manifest['source_sha256'].items():
        assert sha(worktree / name) == digest, worktree / name
        add(worktree / name, f'source/{label}/{name}')
    for name in ['LICENSE-APACHE', 'LICENSE-MIT', 'THIRD_PARTY_LICENSES.md', 'licenses/expat.txt',
                 'licenses/libxml2.txt', 'licenses/cpython.txt', 'tests/c/UPSTREAM-NOTICES.txt']:
        add(worktree / name, f'source/{label}/{name}')

inventory = [
    ('/tmp/oriole-compact-coordinates-source-preparation', 'source/initial-adaptation'),
    ('/tmp/oriole-compact-coordinates-prototype', 'source/unformatted-prototype'),
    ('/tmp/oriole-compact-coordinate-design-review', 'source/design-review'),
    ('/tmp/oriole-compact-coordinate-independent-review', 'source/independent-review'),
    ('/tmp/oriole-compact-coordinate-validation-prep', 'checks/preparation-and-attempts'),
    ('/tmp/oriole-compact-coordinate-ci-preparation', 'ci/preparation-and-invalid-run'),
    ('/tmp/oriole-compact-coordinate-ci-results', 'ci/corrected-run'),
    ('/tmp/oriole-compact-coordinate-layout', 'layout'),
    ('/tmp/oriole-compact-coordinate-correctness-prep', 'prepared-unexecuted/correctness'),
    (str(REVIEWS), 'native/independent-review'),
    (str(NATIVE), 'native/candidate-campaigns'),
]
for root, prefix in inventory:
    tree(root, prefix)
add('/tmp/oriole-compact-coordinates-root-source-review.md', 'source/root-source-review.md')
for mode in ['normal', 'pgo']:
    previous = Path('/tmp/oriole-reference-frame-native-study') / mode
    for name in ['adaptation.json', 'native_screen.py', 'run.py', 'native-screen/protocol.json']:
        add(previous / name, f'native/selected-protocol/{mode}/{name}')

# Include raw build logs/training observations and input bytes; exclude binary outputs.
for label, build in [('candidate', BUILD), ('selected', CONTROL)]:
    for path in sorted(build.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log', '.py', '.patch', '.stdout', '.stderr', '.gz'}:
            add(path, f'build/{label}/{path.name}')
    tree(build / 'pipeline', f'build/{label}/pipeline')
    run = Path(read(build / 'pair-report.json')['pgo_manifest']['path']).parent
    for path in sorted(run.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.log'}:
            add(path, f'build/{label}/pgo/{path.name}')
    tree(run / 'inputs', f'build/{label}/pgo/inputs')
    add(build / 'pgo/latest.json', f'build/{label}/pgo/latest.json')
    if label == 'candidate':
        tree(build / 'local-checks', 'build/candidate/local-checks')
        tree(build / 'validation-preparation', 'build/candidate/validation-preparation')

for path, member in [
    ('/tmp/oriole-reference-frame-native-independent-review/audit.py', 'controllers/origin-native-audit.py'),
    ('/tmp/oriole-markup-classification-evidence-preparation/assemble.py', 'controllers/origin-markup-assemble.py'),
    (__file__, 'controllers/assemble.py'),
]:
    add(path, member)

manifest = Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
add(manifest, 'native/inputs/corpus-manifest.json')
for project in read(manifest)['projects']:
    for file in project['files']:
        path = manifest.parent / file['path']
        assert sha(path) == file['sha256']
        add(path, 'native/inputs/' + file['path'])
add('/tmp/oriole-grammar-bench-plain/entities.xml', 'native/inputs/generated/entities.xml')
add('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml', 'native/inputs/generated/rare-declarations.xml')

all_pins = {}
for audit in audits.values():
    for path, digest in audit['input_sha256'].items():
        assert path not in all_pins or all_pins[path] == digest
        all_pins[path] = digest
archived_paths = set(originals.values())
for path, digest in sorted(all_pins.items()):
    if path in archived_paths:
        continue
    p = Path(path)
    binary = p.suffix in {'.so', '.a', '.profraw', '.profdata'} or '.so.' in p.name
    machine = p.name in {'rustup', 'rustc', 'cargo', 'llvm-profdata', 'python3.12', 'native-driver'} or p.suffix == '.toml'
    if binary or machine:
        excluded.append({'path': path, 'sha256': digest, 'size': p.stat().st_size,
                         'reason': 'external executable/library/profile or machine Cargo configuration; original receipt pin retained'})
    else:
        add(p, 'native/other-pinned-inputs/' + str(p).lstrip('/'))

rows = []
for mode in ['normal', 'pgo']:
    with (REVIEWS / f'{mode}-conditions.csv').open(newline='') as stream:
        rows.extend(csv.DictReader(stream))
assert len(rows) == 56
assert sum('/native-screen/worker-' in name for name in entries) == 1344
OUT.mkdir()
with (OUT / 'conditions.csv').open('x', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
members = []
with (OUT / 'evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for member, data in sorted(entries.items()):
                info = tarfile.TarInfo(member)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                archive.addfile(info, io.BytesIO(data))
                members.append({'member': member, 'original_path': originals[member], 'size': len(data),
                                'sha256': hashlib.sha256(data).hexdigest()})
archive_path = OUT / 'evidence.tar.gz'
with tarfile.open(archive_path, 'r:gz') as archive:
    actual = archive.getmembers()
    assert [m.name for m in actual] == [m['member'] for m in members]
    for record, member in zip(members, actual, strict=True):
        assert member.isfile() and member.size == record['size']
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == record['sha256']
index = {'schema': 'saved-record-bundle-v1',
         'scope': 'Rejected compact coordinates: exact source, first attempts, checks, build/training, CI, layout and all normal/PGO native records; conditional correctness controllers unexecuted.',
         'archive': 'evidence.tar.gz', 'archive_sha256': sha(archive_path),
         'archive_bytes': archive_path.stat().st_size, 'archive_readback_passed': True,
         'members': members, 'excluded': excluded}
(OUT / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
native = {mode: audits[mode]['native'][mode] for mode in audits}
projects = {}
for mode, data in native.items():
    names = sorted({r['condition']['name'] for r in data['all_conditions']})
    projects[mode] = {name: {key: math.exp(sum(math.log(r['median_ratios'][key]) for r in data['all_conditions']
                              if r['condition']['name'] == name) / sum(r['condition']['name'] == name for r in data['all_conditions']))
                              for key in ['candidate_over_control', 'candidate_over_expat', 'control_over_expat']}
                      for name in names}
report = {
    'decision': 'rejected', 'source_commit': binding['commit'],
    'source_manifest_sha256': sha(BUILD / 'source.json'),
    'source_identity_note': 'The original manifest intentionally records dirty bytes on base 97117de; commit-binding.json proves these exact 74 files were committed at e1228bbb. CI-only YAML fix be31c37 preserves them.',
    'selected_control_runtime': selected['candidate_base_commit'],
    'selected_publication': {'pull_request': 144, 'head': '4064b0653534aff690c0e0f395a6b3b48da878fc'},
    'reason': 'Normal real-project native elapsed regresses 3.326% with 23/24 conditions adverse; PGO regresses 7.841% in all 24. Generated aggregates regress 6.407% normal and 12.053% PGO. Keep reference frames selected.',
    'source_delta': source_delta, 'source_counts': {'candidate': 74, 'selected': 72, 'candidate_pipeline': 71, 'selected_pipeline': 69},
    'runtime_delta': build_review['summary']['runtime_files'], 'test_bearing_delta': build_review['summary']['test_files'],
    'checks': {'passed': 449, 'groups': 34, 'format_check_all_target_check_clippy_passed': True, 'failed': 0, 'ignored': 0},
    'ci': {'invalid_run': 34656508229, 'invalid_head': binding['commit'], 'invalid_reason': 'unquoted YAML command ending in coordinate_tests::; no jobs started',
           'corrected_run': ci['run_id'], 'corrected_head': ci['head'], 'passed_jobs': ci['jobs_passed'],
           'focused_miri_passes_per_model': 18, 'models': ['stacked', 'tree'],
           'scope': ci['limitations']},
    'layout': {'observed_bytes': layout, 'method': 'existing checked debug binary exact test stdout/stderr; no new compile',
               'not_measured': ['private heap', 'peak memory', 'RSS'],
               'note': 'Historical design budget and V1 sizes are distinct from this current object-layout observation.'},
    'native': native, 'projects': projects,
    'worker_totals': {'conditions': 56, 'preflight_workers': 168, 'timed_workers': 1176, 'all_workers': 1344, 'all_samples': 212352},
    'builds': {'generated_parse_records': pair['generated_parse_records'], 'compiler_vectors': 9, 'library_artifacts': 6,
               'normal_libraries': pair['normal_libraries'], 'pgo_libraries': pair['pgo_libraries'],
               'compiler_body_and_six_pipeline_tools_unchanged': True},
    'historical_attempts': ['initial unformatted source fmt-check failure', 'formatting and final successful check attempt',
                            'build-reader schema assertion and corrected reader', 'invalid YAML CI with no jobs and corrected CI'],
    'prepared_unexecuted': ['local original upstream API and six C consumers', 'local strict CPython shared/static', 'local 12-case allocation diagnostic'],
    'not_executed': ['candidate CPython performance campaign', 'candidate sustained sanitizer/fuzz campaign'],
    'scope': 'Evidence-only rejection; selected parser unchanged. One native campaign per mode on this machine; no significance, current instruction-profile causality, whole-application or completed 10%-goal claim. Remote CI allowances are distinct from strict compatibility evidence.',
    'evidence': {'archive': {'path': 'evidence.tar.gz', 'sha256': sha(archive_path), 'bytes': archive_path.stat().st_size,
                             'members': len(members), 'readback_passed': True},
                 'index': {'path': 'index.json', 'sha256': sha(OUT / 'index.json')},
                 'conditions': {'path': 'conditions.csv', 'sha256': sha(OUT / 'conditions.csv'), 'rows': 56},
                 'native_reviews': {mode: sha(REVIEWS / f'{mode}-review.json') for mode in audits}},
}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
table = []
for mode, group in [('normal', 'real'), ('pgo', 'real'), ('normal', 'generated'), ('pgo', 'generated')]:
    data = native[mode]['groups'][group]
    ratio = data['ratios']['candidate_over_control']
    adverse = sum(r['median_ratios']['candidate_over_control'] > 1 for r in native[mode]['all_conditions']
                  if r['condition']['name'].startswith('generated-') == (group == 'generated'))
    table.append(f"| {'PGO' if mode == 'pgo' else 'Normal'}, {data['conditions']} {group} conditions | {ratio:.6f}× ({(ratio-1)*100:+.2f}%) | {data['ratios']['candidate_over_expat']:.6f}× | {adverse} / {data['conditions']} |")
readme = '''# Compact lazy coordinates — rejected

**Reject this candidate.** Real-project native elapsed regresses by 3.33% in the normal build (23 of 24 conditions) and 7.84% with PGO (all 24). Generated aggregates regress by 6.41% and 12.05%. Keep direct-reference frames selected.

Measured candidate: `e1228bbb9dbd174e2aceff5ecea24a04fecc8515`. Selected control: `0f66d54ac8418f0a6e628ad18570677a19c9ed45`, published in [PR144](https://github.com/astral-sh/oriole/pull/144) at `4064b0653534aff690c0e0f395a6b3b48da878fc`. This packet publishes evidence only; the compact-coordinate runtime remains unselected.

## Native results

| Build and scope | Candidate / selected control | Candidate / Expat | Adverse conditions |
| --- | ---: | ---: | ---: |
TABLE

Generated entity/reference conditions regress 14.56–15.54% in normal builds and 24.20–24.92% with PGO. PGO Maven regresses 12.18–13.43% and DocBook 8.37–13.99%. All 56 condition ratios, including every adverse condition, are retained in [conditions.csv](conditions.csv); [report.json](report.json) includes the paired-condition arithmetic and per-project aggregates.

Each mode uses the same six real-project inputs, 4 KiB and 64 KiB chunks, namespaces off/on and four generated conditions. Each condition retains seven seeded, interleaved process pairs. A condition ratio is the median of paired process-median ratios; aggregates are geometric means across conditions. Saved audits reconstruct all 1,344 workers and 212,352 observations, including preflights, callback observations, library paths and byte hashes. This is one native parser/consumer campaign per mode on this machine, without a statistical-significance or whole-application claim.

Both Oriole builds use O3, ThinLTO and one codegen unit on the same explicit x86_64 target, with the selected allocator. PGO uses fresh profiles from the original generated training recipe. Expat 2.8.4 uses matching normal or PGO GCC 13.3 O3/shared builds without LTO. Driver, fixtures, callbacks, seeded order, limits and timing arithmetic remain unchanged. This candidate moves further from the within-10%-of-Expat goal.

## Source and correctness checks

The candidate defers eligible native UTF-8 line/column projection until a coordinate getter or a boundary needs it. Byte/count publication stays eager; the existing publication owner retains committed coordinates through compaction and failures. An additional Source checkpoint replaces the prior design's larger retained-coordinate slots. This remains a rejected implementation experiment, with no claim that object size caused either design's elapsed results.

The final source manifest contains 74 files (selected control 72); the pipeline manifest contains 71 (selected 69). Six runtime files and eight test-bearing files differ, including two new focused test modules. The original freeze deliberately records dirty bytes on base `97117de`; the saved commit binding proves those exact checked files became `e1228bbb`. Final snapshots, the earlier unformatted proposal, reviewer-added test patches, and original review scope are retained separately.

Independent runtime review found no runtime blocker and identified two focused coverage gaps. The reviewer subsequently added C allocator-reentry/failed-publication and actual deferred-compaction callback tests; those test additions are not represented as independently authored runtime review. Final local checks passed 449 Rust checks in 34 groups, formatting, all-target checking and Clippy. Normal, instrumented and optimized builds completed 288 original generated parse records each (864 total), with nine actual compiler vectors and six library artifacts reviewed against the selected recipe.

The first formatting check failed on the unformatted prototype; its log is preserved alongside formatting and the successful final attempt. A saved build-reader schema assertion also preceded the corrected passing review; it was a reader-shape issue, not a target failure.

## CI and object layout

The initial [CI run 34656508229](https://github.com/astral-sh/oriole/actions/runs/34656508229) could not start any jobs because a command ending in `coordinate_tests::` was not quoted as YAML. A block-scalar-only workflow correction at `be31c37baadcc711a84120c487ac13383dd0ccc7` preserves all measured parser source. The [corrected run 34656684670](https://github.com/astral-sh/oriole/actions/runs/34656684670) passed all 16 jobs. Saved full logs verify exact selection and execution of 18 focused callbacks/coordinate checks under each of Miri's Stacked Borrows and Tree Borrows models, 36 passes total.

The checked debug binary's exact layout test reports C parser 3184 bytes, core Parser 2424, AdapterFrame 264 and AdapterLocation 40. This observation measures object layout only; private heap, peak memory and RSS were not measured. Earlier design documents' Source budget and V1 layout are historical evidence, not additional current measurements.

## Scope and saved evidence

The candidate was rejected after both native campaigns. Local original upstream API/six-C-consumer, strict shared/static CPython and 12-case allocator controllers were prepared but **not executed**. Candidate Python performance and sustained sanitizer/fuzz campaigns were not run. Successful remote CI jobs use their documented test selections and CPython text-fragmentation allowance; they do not erase the selected runtime's preserved strict callback differences or establish complete API compatibility.

[evidence.tar.gz](evidence.tar.gz) retains exact source, checks and first attempts, original build/training records, CI metadata/full log, layout output, prepared controllers, all native raw worker records, saved reviews and corpus licenses/notices. [index.json](index.json) records every member's original path, size and SHA-256; packaging read back every member. Source-review caveats and prepared-state labels describe their original stage and remain unchanged.

Executables, shared/static libraries, binary PGO profiles and machine Cargo configurations are excluded; their receipt hashes are retained. Absolute paths identify the original machine. This is a saved-record bundle, not a self-contained executable benchmark. Packaging ran no parser, compiler, test or benchmark target.
'''
readme = readme.replace('TABLE', '\n'.join(table))
(OUT / 'README.md').write_text(readme)
print(json.dumps({'directory': str(OUT), 'files': [p.name for p in sorted(OUT.iterdir())],
                  'archive_sha256': sha(archive_path), 'archive_bytes': archive_path.stat().st_size,
                  'archive_members': len(members), 'excluded_inputs': len(excluded),
                  'report_sha256': sha(OUT / 'report.json'), 'index_sha256': sha(OUT / 'index.json'),
                  'conditions_sha256': sha(OUT / 'conditions.csv')}, indent=2))
