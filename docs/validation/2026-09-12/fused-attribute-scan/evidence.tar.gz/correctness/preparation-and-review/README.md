# Fused attribute scan: held compatibility checks

**Prepared only. No compiler, parser or suite targets have run here.** Root releases each command after the native timing campaign finishes.

The uncommitted candidate differs from selected source only in `crates/oriole/src/tag.rs` (`50f641a4…`). The 72-file snapshot and completed build readback identify the source. These are the generic PGO artifacts from `run-w7b8o8j1`, with the original O3/ThinLTO/cgu1 recipe and no CPU targeting:

- Shared: `202ae85b10301a52276b4ac7be9134b9eeb2d7d728706f380149e4734304b699`.
- Static: `e69363d0cf2a9439bed0b86c9a200ff26f2752a6b39261b031d24eebe69bd163`.

## Root commands

Use the same clean launch environment as the completed v3 correctness gates. The controllers verify `pins.json` before launching targets and retain actual exits and child cleanup receipts. Run sequentially:

```sh
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-fused-attribute-scan-correctness-prep/api_native.py
taskset -c 3 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-fused-attribute-scan-correctness-prep/strict_cpython.py
```

After both finish and all targets are reaped, read the saved outcomes:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-fused-attribute-scan-correctness-prep/read_outcomes.py
```

Then bind the existing supplemental semantic commands to the actual new extension hashes, without executing them:

```sh
taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-fused-attribute-scan-correctness-prep/prepare_semantics.py
```

Root may then execute the two argv arrays in the resulting `semantic-commands.json`, recording outputs and exits separately. They use the existing `text_fragmentation.py`, explicit extension-loader environment, CPU3 and a 120-second timeout with five-second termination grace. The template deliberately contains no invented module hashes before compilation. The saved-only binder checks the original summary, copied libraries and initial/fresh origin hashes before materializing runnable commands.

## Unchanged coverage

- Original 4,740 API configurations and assertions: 3 seconds per case, 1 GiB address space, 768 MiB RSS, 240-second matrix and 300-second outer bound. The saved generic baseline is 4,347 passes, 391 failures and two timeouts. All ordered outcomes are compared; diagnostic allowances and raised allocation ceilings are absent.
- Six C consumers: integration, adversarial and allocations, each dynamic/static. Each compilation and execution retains its 120-second bound. C has ASan/UBSan instrumentation; the Rust PGO library is uninstrumented. Leak checking remains disabled as in the control protocol.
- Unchanged strict CPython shared/static suites, with the pinned allocation-failure cleanup backport and 1,000-second bound per linkage. The full execution loop is byte-identical to the v3 controller. No allocator override or text-fragmentation allowance is passed to the strict suite. The unchanged multiline-aware reader compares all 802 method identities per linkage.
- Two supplemental semantic tests per linkage check callback-controlled buffering and exact text/element/CDATA ordering. Their results remain separate from the strict raw failures; no summary or original log is rewritten.

`prior/` and the small `.patch` files preserve controller provenance. API changes are path substitutions only; strict changes bind the one-file candidate and generic compiler treatment. This preparation makes no compatibility result or sanitizer finding claim and does not select the candidate.
