"""Relocate existing correctness controllers; saved/source inputs only."""
from pathlib import Path
import ast, collections, difflib, hashlib, json, os, re

assert os.sched_getaffinity(0) == {6}
P = Path(__file__).parent
ORIGIN = Path('/tmp/oriole-reference-frame-v3-correctness-prep')
OLD_WORK = Path('/home/dev-user/code/oss/oriole-reference-frame')
WORK = Path('/home/dev-user/code/oss/oriole-fused-attribute-scan')
BUILD = Path('/tmp/oriole-fused-attribute-scan-pgo-study')
CONTROL = Path('/tmp/oriole-reference-frame-pgo-study')
API = Path('/tmp/oriole-reference-frame-api-gates/api-native/upstream-api')
STRICT = Path('/tmp/oriole-reference-frame-strict-cpython')
load = lambda p: json.loads(Path(p).read_text())
def sha(p):
    with Path(p).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2); stream.write('\n')

source, selected = load(BUILD / 'source.json'), load(CONTROL / 'source.json')
pair = load(BUILD / 'pair-report.json')
readback = load(BUILD / 'build-readback.json')
assert pair['status'] == readback['status'] == 'passed'
assert pair['source_manifest_sha256'] == sha(BUILD / 'source.json')
assert readback['inputs'][str(BUILD / 'pair-report.json')] == sha(BUILD / 'pair-report.json')
assert readback['inputs'][str(BUILD / 'source.json')] == sha(BUILD / 'source.json')
assert len(source['source_sha256']) == len(selected['source_sha256']) == 72
assert set(source['source_sha256']) == set(selected['source_sha256'])
assert [name for name, h in source['source_sha256'].items() if selected['source_sha256'][name] != h] == ['crates/oriole/src/tag.rs']
assert source['source_sha256']['crates/oriole/src/tag.rs'] == '50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6'
assert all(sha(WORK / name) == h for name, h in source['source_sha256'].items())
manifest_path = Path(pair['pgo_manifest']['path']); manifest = load(manifest_path)
assert sha(manifest_path) == pair['pgo_manifest']['sha256']
assert manifest['status'] == 'passed' and manifest['base_rustflags'] == []
assert Path(manifest['run']) == manifest_path.parent and pair['pgo_libraries'] == manifest['libraries_sha256']
library_dir = manifest_path.parent / 'use'
assert pair['pgo_libraries']['use/liboriole_expat.so'].startswith('202ae85b')
assert pair['pgo_libraries']['use/liboriole_expat.a'].startswith('e69363d0')
libraries = {suffix: {'path': str(library_dir / ('liboriole_expat.' + suffix)), 'sha256': pair['pgo_libraries']['use/liboriole_expat.' + suffix]} for suffix in ['so', 'a']}
assert all(sha(Path(row['path'])) == row['sha256'] for row in libraries.values())

origin_pins = load(ORIGIN / 'pins.json')
pins, removed = {}, {}
for path, digest in origin_pins.items():
    p = Path(path)
    if p.is_relative_to(ORIGIN) or p.is_relative_to('/tmp/oriole-reference-frame-v3-pgo-study') or p.is_relative_to('/tmp/oriole-reference-frame-v3-build-review') or path in [str(CONTROL / 'normal/liboriole_expat.so'), '/tmp/oriole-pgo-study/expat-control-liboriole_expat.so', '/tmp/oriole-pgo-study/expat-use-liboriole_expat.so']:
        removed[path] = digest
        continue
    if p.is_relative_to(OLD_WORK):
        relative = str(p.relative_to(OLD_WORK))
        p = WORK / relative
        digest = source['source_sha256'].get(relative, digest)
    assert sha(p) == digest, str(p)
    pins[str(p)] = digest
for name, digest in source['source_sha256'].items():
    assert pins[str(WORK / name)] == digest
for p in [BUILD / 'source.json', BUILD / 'source-checks.json', BUILD / 'pair-report.json', BUILD / 'build-readback.json', manifest_path, *[Path(row['path']) for row in libraries.values()]]:
    pins[str(p)] = sha(p)

(P / 'prior').mkdir(exist_ok=False)
scripts = []
for name in ['api_native.py', 'strict_cpython.py', 'read_outcomes.py', 'methods.py']:
    before = (ORIGIN / name).read_text()
    assert sha(ORIGIN / name) == origin_pins[str(ORIGIN / name)]
    after = before.replace(str(OLD_WORK), str(WORK))
    if name == 'api_native.py':
        after = after.replace(str(ORIGIN), str(P)).replace('/tmp/oriole-reference-frame-v3-pgo-study/pgo/runs/run-o12jfqdr/use', str(library_dir))
        inverse = after.replace(str(P), str(ORIGIN)).replace(str(library_dir), '/tmp/oriole-reference-frame-v3-pgo-study/pgo/runs/run-o12jfqdr/use').replace(str(WORK), str(OLD_WORK))
        assert inverse == before
    elif name == 'strict_cpython.py':
        after = after.replace('/tmp/oriole-reference-frame-v3-pgo-study', str(BUILD))
        after = after.replace("assert pair['status']==baseline_pair['status']=='passed' and source==baseline_source", "assert pair['status']==baseline_pair['status']=='passed'\nassert len(source['source_sha256'])==len(baseline_source['source_sha256'])==72 and set(source['source_sha256'])==set(baseline_source['source_sha256'])\nassert [p for p,h in source['source_sha256'].items() if baseline_source['source_sha256'][p]!=h]==['crates/oriole/src/tag.rs']\nassert source['source_sha256']['crates/oriole/src/tag.rs']=='50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6'")
        after = after.replace("['base_rustflags']==['-Ctarget-cpu=x86-64-v3']", "['base_rustflags']==[]")
        after = after.replace("'source_delta':[]", "'source_delta':['crates/oriole/src/tag.rs'],'source_manifest_sha256':sha(BUILD/'source.json'),'source_identity':'Uncommitted fused scanner source snapshot; HEAD alone does not identify candidate'")
        after = after.replace("'compiler_treatment':'x86-64-v3'", "'compiler_treatment':'generic original O3/ThinLTO/cgu1'")
        assert after[after.index('try:\n    for linkage'):] == before[before.index('try:\n    for linkage'):]
        assert '--allow-text-fragmentation' not in after and '--system-allocator' not in after
    elif name == 'read_outcomes.py':
        assert after.replace(str(WORK), str(OLD_WORK)) == before
    else:
        assert after == before
    ast.parse(after)
    (P / 'prior' / name).write_text(before)
    (P / name).write_text(after)
    (P / (name + '.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile=str(ORIGIN / name), tofile=str(P / name))))
    pins[str(P / name)] = sha(P / name)
    scripts.append({'path': str(P / name), 'sha256': sha(P / name), 'origin': str(ORIGIN / name), 'origin_sha256': sha(ORIGIN / name)})

# Reuse the exact previously reviewed semantic command form. Outputs do not exist
# yet; bind their actual hashes from fresh strict origin logs after completion.
old_semantics = load(Path('/tmp/oriole-v3-text-fragmentation-followup/held-commands.json'))
semantic_commands = []
for old in old_semantics['commands']:
    mode = old['mode']; old_dir = str(Path('/tmp/oriole-reference-frame-v3-correctness-prep/strict-cpython') / mode); new_dir = str(P / 'strict-cpython' / mode)
    argv = [v.replace(old_dir, new_dir).replace(str(OLD_WORK), str(WORK)) for v in old['argv']]
    assert [v.replace(new_dir, old_dir).replace(str(WORK), str(OLD_WORK)) for v in argv] == old['argv']
    semantic_commands.append({'mode': mode, 'argv': argv, 'cwd': str(WORK), 'timeout_seconds': 120, 'termination_grace_seconds': 5, 'outer_timeout_seconds': 130, 'stdout': str(P / ('semantic-' + mode + '.stdout')), 'stderr': str(P / ('semantic-' + mode + '.stderr')), 'status': 'held_until_fresh_strict_origin_hash_binding', 'strict_directory': new_dir, 'expected_library_sha256': libraries['so' if mode == 'shared' else 'a']['sha256'], 'expected_semantic_tests': 2})
save(P / 'semantic-commands-template.json', {'status': 'held_output_hash_binding_required', 'commands': semantic_commands, 'script': str(WORK / 'tools/cpython/text_fragmentation.py'), 'script_sha256': sha(WORK / 'tools/cpython/text_fragmentation.py'), 'scope': 'Separate two-test semantic follow-up after strict shared/static builds. Run prepare_semantics.py on completed strict records first. Never pass --allow-text-fragmentation to the original strict suite or overwrite its summary/logs.'})

baseline = load(API / 'results.json')
raw = []
for line in (API / 'tests.log').read_text().splitlines():
    if line.startswith('ORIOLE_RESULT\t'):
        _, context, test, outcome, code = line.split('\t'); raw.append({'context': context, 'test': test, 'outcome': outcome, 'code': int(code)})
assert raw == baseline['results'] and len(raw) == 4740
outcomes = dict(collections.Counter(row['outcome'] for row in raw))
assert outcomes == {'pass': 4347, 'fail': 391, 'timeout': 2}
for name in ['prepare.py', 'prepare_semantics.py', 'semantic-commands-template.json']:
    ast.parse((P / name).read_text()) if name.endswith('.py') else None
    pins[str(P / name)] = sha(P / name)
assert all(sha(path) == digest for path, digest in pins.items())
save(P / 'pins.json', pins)
prior = load(ORIGIN / 'preparation.json')
save(P / 'preparation.json', {'status': 'prepared_not_executed', 'targets_executed': False, 'source_files': 72, 'source_delta': ['crates/oriole/src/tag.rs'], 'source_manifest_sha256': sha(BUILD / 'source.json'), 'candidate_base_commit': source['candidate_base_commit'], 'candidate_source_uncommitted': True, 'compiler_treatment': 'Generic selected O3/ThinLTO/cgu1 recipe, no target-cpu flag', 'libraries': libraries, 'build_readback': {'path': str(BUILD / 'build-readback.json'), 'sha256': sha(BUILD / 'build-readback.json')}, 'scripts': scripts, 'api': prior['api'], 'c_consumers': prior['c_consumers'], 'strict': prior['strict'], 'baseline_api_outcomes': outcomes, 'supplemental_semantics': {'separate': True, 'original_script_sha256': sha(WORK / 'tools/cpython/text_fragmentation.py'), 'fresh_extension_hash_binding_required': True, 'per_linkage_tests': 2, 'timeout_seconds': 120}, 'pins_sha256': sha(P / 'pins.json'), 'pins_count': len(pins), 'removed_v3_or_elapsed_pins': removed, 'scope': 'Relocated existing original API/C consumers and strict CPython controllers, with exact full strict execution loop and method reader retained. No runtime edits, targets, new limits or rewritten upstream assertions. Supplemental semantics are separate and cannot alter strict raw failures.'})
print(json.dumps({'path': str(P / 'preparation.json'), 'sha256': sha(P / 'preparation.json'), 'pins': len(pins), 'libraries': libraries, 'targets_executed': False}))
