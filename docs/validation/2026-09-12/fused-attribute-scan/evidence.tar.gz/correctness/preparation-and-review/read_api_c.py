"""Independent saved API/C readback; strict and semantic suites were not run."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
P = Path(__file__).parent
B = Path('/tmp/oriole-fused-attribute-scan-pgo-study')
W = Path('/home/dev-user/code/oss/oriole-fused-attribute-scan')
BASE = Path('/tmp/oriole-reference-frame-api-gates/api-native/upstream-api')
inputs = {}


def read(path):
    path = Path(path)
    value = path.read_bytes()
    inputs[str(path)] = hashlib.sha256(value).hexdigest()
    return value


def sha(path):
    read(path)
    return inputs[str(Path(path))]


def load(path):
    return json.loads(read(path))


api = load(P / 'api-native/report.json')
pins = load(P / 'pins.json')
assert all(sha(p) == h for p, h in pins.items())
assert api['unchanged'] and api['before'] == api['after'] and len(api['commands']) == 13
assert all(sha(p) == h for p, h in api['before'].items())
pair = load(B / 'pair-report.json')
library = Path(pair['pgo_manifest']['path']).parent / 'use'
for name in ['liboriole_expat.so', 'liboriole_expat.a']:
    assert sha(library / name) == pair['pgo_libraries']['use/' + name]
rows = []
manifests = []
for root in [BASE, P / 'api-native/upstream-api']:
    report, manifest = load(root / 'results.json'), load(root / 'manifest.json')
    events = []
    for line in read(root / 'tests.log').decode().splitlines():
        if line.startswith('ORIOLE_RESULT\t'):
            _, context, test, outcome, code = line.split('\t')
            events.append({'context': context, 'test': test, 'outcome': outcome, 'code': int(code)})
    assert events == report['results'] and len(events) == 4740
    assert report['selection_complete'] and report['library_origin_verified'] and not report['timed_out']
    assert sha(root / 'liboriole_expat.so') == manifest['library_sha256']
    assert manifest['chunks'] == [0, 1, 2, 3, 4, 5] and manifest['deferral'] == [0, 1]
    assert (manifest['per_test_seconds'], manifest['per_test_address_space_bytes'], manifest['per_test_rss_limit_bytes'], manifest['total_timeout_seconds']) == (3, 1024**3, 768 * 1024**2, 240)
    for name, digest in manifest['adapted_sources'].items():
        assert sha(root / 'adapted' / name) == digest
    rows.append(events)
    manifests.append(manifest)
assert rows[0] == rows[1] and api['api_comparison']['changes'] == []
assert manifests[1]['library_sha256'] == pair['pgo_libraries']['use/liboriole_expat.so']
assert api['api_comparison']['baseline_results_sha256'] == sha(BASE / 'results.json')
assert api['api_comparison']['candidate_results_sha256'] == sha(P / 'api-native/upstream-api/results.json')
for key in manifests[0]:
    if key not in ['compile_command', 'library_sha256', 'binary_sha256']:
        assert manifests[0][key] == manifests[1][key], key
native = P / 'api-native/native'
expected_labels = ['api']
c_runs = []
for linkage in ['dynamic', 'static']:
    for name in ['integration', 'adversarial', 'allocations']:
        label = f'native-{name}-{linkage}'
        expected_labels.extend([label + '-build', label])
        source = native / (name + '.c')
        assert sha(source) == sha(W / 'tests/c' / (name + '.c'))
        binary = native / (name + '-' + linkage)
        links = ['-L', str(library), '-loriole_expat', '-Wl,-rpath,' + str(library)] if linkage == 'dynamic' else [str(library / 'liboriole_expat.a'), '-ldl', '-lpthread', '-lm']
        expected = ['taskset', '-c', '3', 'cc', '-std=c11', '-O1', '-g', '-Wall', '-Wextra', '-Werror', '-fsanitize=address,undefined', '-fno-omit-frame-pointer', '-I', str(native), str(source), *links, '-o', str(binary)]
        build = next(row for row in api['commands'] if row['label'] == label + '-build')
        run = next(row for row in api['commands'] if row['label'] == label)
        assert build['command'] == expected and run['command'] == ['taskset', '-c', '3', str(binary)]
        assert build['end'] <= run['start']
        c_runs.append({'label': label, 'exit': run['exit'], 'binary_sha256': sha(binary)})
assert [row['label'] for row in api['commands']] == expected_labels
for row in api['commands']:
    assert row['reaped'] and row['end'] >= row['start'] and 'exception' not in row
    assert row['exit'] == (1 if row['label'] == 'api' else 0)
    for suffix in ['stdout', 'stderr']:
        assert sha(P / 'api-native' / (row['label'] + '.' + suffix)) == row[suffix + '_sha256']
    if 'binary_sha256' in row:
        assert sha(row['command'][-1]) == row['binary_sha256']
counts = dict(Counter(row['outcome'] for row in rows[1]))
assert counts == {'pass': 4347, 'fail': 391, 'timeout': 2}, counts
assert not (P / 'strict-cpython').exists()
for path, digest in inputs.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
result = {'status': 'passed_saved_api_c_readback', 'role': 'Reviewer independently read root-collected API/C raw records and compiler vectors. This reviewer adapted the Python benchmark controllers/readers and reviewed runtime source, but did not author runtime or API/C controllers and executed no targets.', 'targets_executed': False, 'api': {'ordered_configurations': 4740, 'counts': counts, 'changes': [], 'raw_exit': 1, 'original_assertions_and_limits': True}, 'c_consumers': c_runs, 'limitations': ['C harnesses use ASan/UBSan; linked Rust PGO libraries are uninstrumented and leak detection is disabled by the unchanged controller.', 'Strict and supplemental semantic candidate suites were prepared but unexecuted. No adoption or performance claim.'], 'inputs': inputs, 'reader_sha256': sha(__file__)}
dest = P / 'api-c-independent-readback.json'
with dest.open('x') as stream:
    stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'api': result['api'], 'c_consumers': len(c_runs), 'path': str(dest), 'sha256': sha(dest)}))
