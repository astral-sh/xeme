"""Saved API/C/strict outcome readback only; never launch test targets."""
from pathlib import Path
import ast,hashlib,json,os,re
assert os.sched_getaffinity(0)=={6}
P=Path(__file__).parent;W=Path('/home/dev-user/code/oss/oriole-reference-frame');inputs={}
def read(p):
 p=Path(p);v=p.read_bytes();inputs[str(p)]=hashlib.sha256(v).hexdigest();return v
def sha(p):read(p);return inputs[str(Path(p))]
def load(p):return json.loads(read(p))
tree=ast.parse(read(P/'methods.py'));node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='methods');exec(compile(ast.Module(body=[node],type_ignores=[]),str(P/'methods.py'),'exec'))
pins=load(P/'pins.json');assert all(sha(p)==h for p,h in pins.items())
api=load(P/'api-native/report.json');assert api['unchanged'] and api['before']==api['after'] and len(api['commands'])==13
for row in api['commands']:
 assert row['reaped'] and row['end']>=row['start'] and 'exception' not in row
 assert row['exit'] in ([0,1] if row['label']=='api' else [0])
 for suffix in ['stdout','stderr']:assert sha(P/'api-native'/(row['label']+'.'+suffix))==row[suffix+'_sha256']
 if 'binary_sha256' in row:assert sha(row['command'][-1])==row['binary_sha256']
api_rows=[]
for root in [Path('/tmp/oriole-reference-frame-api-gates/api-native/upstream-api'),P/'api-native/upstream-api']:
 report=load(root/'results.json');manifest=load(root/'manifest.json');raw=read(root/'tests.log').decode();events=[]
 for line in raw.splitlines():
  if line.startswith('ORIOLE_RESULT\t'):
   _,context,test,outcome,code=line.split('\t');events.append({'context':context,'test':test,'outcome':outcome,'code':int(code)})
 assert events==report['results'] and len(events)==4740 and report['selection_complete'] and report['library_origin_verified'] and not report['timed_out']
 assert sha(root/'liboriole_expat.so')==manifest['library_sha256']
 assert manifest['chunks']==[0,1,2,3,4,5] and manifest['deferral']==[0,1]
 assert manifest['per_test_seconds']==3 and manifest['per_test_address_space_bytes']==1024**3 and manifest['per_test_rss_limit_bytes']==768*1024**2 and manifest['total_timeout_seconds']==240
 for name,h in manifest['adapted_sources'].items():assert sha(root/'adapted'/name)==h
 api_rows.append(events)
assert [(r['test'],r['context']) for r in api_rows[0]]==[(r['test'],r['context']) for r in api_rows[1]]
api_changes=[{'baseline':a,'candidate':b} for a,b in zip(*api_rows,strict=True) if a!=b]
assert api_changes==api['api_comparison']['changes']
strict=load(P/'strict-cpython/report.json');assert strict['status']=='completed_strict_results' and strict['pins_unchanged'] and len(strict['commands'])==2
assert all(sha(p)==h for p,h in strict['pins'].items())
provenance=load(W/'integration/python-build-standalone/consumer-fix/provenance.json');python_results={}
for row in strict['commands']:
 linkage=row['linkage'];directory=P/'strict-cpython'/linkage;baseline=Path('/tmp/oriole-reference-frame-strict-cpython')/linkage;summary=load(directory/'summary.json');base=load(baseline/'summary.json');origin=load(directory/'origin.log')
 assert row['reaped'] and row['exit'] in [0,2] and not row.get('timeout_reached') and row['timeout']==1000
 assert row['argv'].count('--consumer-fix')==1 and '--allow-text-fragmentation' not in row['argv'] and '--system-allocator' not in row['argv']
 for suffix in ['stdout','stderr']:assert sha(P/'strict-cpython'/(linkage+'.'+suffix))==row[suffix+'_sha256']
 assert summary['linkage']==linkage and summary['tests_exit_code']==summary['gate_exit_code']==row['exit']
 assert summary['probe_exit_code']==summary['origin_exit_code']==0 and summary['consumer_fix']==base['consumer_fix']==provenance and summary['text_fragmentation'] is None
 assert summary['consumer_adaptation']=='CPython upstream allocation-failure fix' and summary['cpython_revision']==provenance['cpython_revision']
 assert summary['source_sha256']==provenance['source_sha256'] and summary['compiled_source_sha256']==sha(directory/'pyexpat.c')==sha(baseline/'pyexpat.c')==provenance['patched_source_sha256']
 assert summary['test_command']==base['test_command']
 library=Path(row['argv'][row['argv'].index('--library')+1]);assert summary['library_sha256']==sha(directory/library.name)==pins[str(library)]
 assert summary['loader_sha256']==sha(directory/'sitecustomize.py')==sha(W/'tools/cpython/extension_loader.py')
 assert summary['import_check_sha256']==sha(W/'tools/cpython/check_extension_imports.py')
 assert origin['status']=='passed' and origin['accelerator_imports']==['cET','cET_alias'] and origin['pure_python_and_blocked_imports']=='passed' and len(origin['origins'])==4
 for entry in origin['origins'].values():assert Path(entry['path']).parent==directory and sha(entry['path'])==entry['sha256']
 before,after=methods(baseline/'tests.log'),methods(directory/'tests.log');assert len(before)==len(after)==802 and before.keys()==after.keys()
 changes=[{'method':key,'baseline':before[key],'candidate':after[key]} for key in before if before[key]!=after[key]]
 extra=[]
 for q in [baseline,directory]:
  text=read(q/'tests.log').decode();extra.append({'failure_headers':re.findall(r'^(FAIL|ERROR): (.+)$',text,re.M),'skip_lines':[line for line in text.splitlines() if ' ... skipped ' in line],'subtest_lines':[line for line in text.splitlines() if line.startswith('  ') and ' ... ' in line]})
 python_results[linkage]={'methods':802,'raw_exit':row['exit'],'changes':changes,'supplementary_outcomes_equal':extra[0]==extra[1],'supplementary_outcomes':{'baseline':extra[0],'candidate':extra[1]},'full_method_map':after,'method_map_sha256':hashlib.sha256(json.dumps(after,sort_keys=True).encode()).hexdigest(),'failures':sorted(k for k,v in after.items() if v in ['FAIL','ERROR']),'origins':origin['origins']}
 for name in ['consumer-fix.log','probe.log','pyexpat-build.log','_elementtree-build.log']:read(directory/name)
for path,h in inputs.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
result={'status':'saved_results_verified','targets_executed':False,'api_configurations':4740,'api_changes':api_changes,'c_consumers':6,'strict':python_results,'input_sha256':inputs,'reader_sha256':sha(__file__),'scope':'Full original API ordered rows and strict802 method identities/outcomes with exact origins. Report all differences for review; preserved baseline failures are not passes. Allocator comparison is the separate unchanged raw reader.'}
out=P/'outcome-readback.json'
with out.open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':sha(out),'api_changes':len(api_changes),'strict_changes':{k:len(v['changes']) for k,v in python_results.items()}}))
