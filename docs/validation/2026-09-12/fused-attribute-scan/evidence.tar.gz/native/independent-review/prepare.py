"""Adapt the reference saved reader without reading candidate worker results."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

OUT = Path(__file__).parent
OLD = Path('/tmp/oriole-reference-frame-native-independent-review/audit.py')
before = OLD.read_text()
after = before
replacements = [
    ('Reconstruct reference-frame native measurements', 'Reconstruct fused-attribute-scan native measurements'),
    ("ROOT = Path('/tmp/oriole-reference-frame-native-study')", "ROOT = Path('/tmp/oriole-fused-attribute-scan-pgo-study/native')"),
    ("PREVIOUS = Path('/tmp/oriole-suffix-element-names-native-study')", "PREVIOUS = Path('/tmp/oriole-reference-frame-native-study')"),
    ("BUILD = Path('/tmp/oriole-reference-frame-pgo-study')", "BUILD = Path('/tmp/oriole-fused-attribute-scan-pgo-study')"),
    ("CONTROL = Path('/tmp/oriole-suffix-element-names-pgo-study')", "CONTROL = Path('/tmp/oriole-reference-frame-pgo-study')"),
    ("SELECTED = 'a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9'", "SELECTED = '0f66d54ac8418f0a6e628ad18570677a19c9ed45'"),
    ("assert preparation['head'] == HEAD and preparation['expected_test_count'] > 0", "assert preparation['head'] == HEAD and preparation['expected_test_count'] == 442 and preparation['test_groups'] == 35"),
    ("assert preparation['check_labels'] == [phase + preparation['check_attempt'] for phase in ['fmt', 'check', 'tests', 'clippy']]", "assert preparation['source_checks_sha256'] == pin(BUILD / 'source-checks.json')\nassert preparation['expected_source_delta'] == preparation['expected_pipeline_delta'] == ['crates/oriole/src/tag.rs']"),
    ('This reviewer prepared the directly bound native controller and allocation diagnostic, but did not author the runtime or original native arithmetic and did not execute compiler, parser, preflight or timing targets.', 'This reviewer independently reviewed the runtime/build/native adapter source and adapted this saved reader. The runtime author prepared the build/native controllers and build reader; root collected targets. This reviewer did not author the runtime or original native arithmetic and did not execute compiler, parser, preflight or timing targets.'),
    ('Character-reference frame delivery requires separate source/API/consumer reviews', 'Fused attribute scanning requires separate source/API/consumer reviews'),
    ('The direct reference-frame candidate has the exact source and inherited fixture delta recorded by preparation.json.', 'The uncommitted fused-attribute candidate is identified by the frozen 72-file source snapshot, with only tag.rs changed from the selected reference runtime; base HEAD alone does not identify this candidate.'),
    ('byte-identical to the suffix saved-data reader', 'byte-identical to the selected reference saved-data reader'),
]
for old, new in replacements:
    assert after.count(old) == 1, old
    after = after.replace(old, new)
marker = "assert source['candidate_base_commit'] == HEAD and source['base_runtime'] == SELECTED"
binding = """assert HEAD == '4064b0653534aff690c0e0f395a6b3b48da878fc'
assert pin(BUILD / 'source.json') == 'eb790ea508b1c8ffbc819828afaa6ace9504da03752fa448a85616ea1bce2a85'
assert pin(readback_path) == '1ff8b11548d10bbc6f6c0cb6b53c1e03335ff7bfb30f3ccf4b834126c08bbb45'
assert readback['status'] == 'passed' and readback['summary']['tests'] == 442 and readback['summary']['test_groups'] == 35
for name, digest in source['source_sha256'].items():
    assert pin(Path(source['worktree']) / name) == digest
"""
assert after.count(marker) == 1
after = after.replace(marker, marker + '\n' + binding)
start = ' ordinal=0; medians={}; obs={}; samples_count=0\n'
end = " report['native'][phase] ="
old_body = before.split(start, 1)[1].split(end, 1)[0]
new_body = after.split(start, 1)[1].split(end, 1)[0]
assert old_body == new_body
ast.parse(after)
with (OUT / 'audit.py').open('x') as stream:
    stream.write(after)
(OUT / 'audit.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile=str(OLD), tofile=str(OUT / 'audit.py'))))
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
record = {
    'status': 'prepared_not_executed',
    'origin': str(OLD), 'origin_sha256': sha(OLD),
    'reader_sha256': sha(OUT / 'audit.py'),
    'measurement_body_byte_exact': True,
    'measurement_body_sha256': hashlib.sha256((start + new_body).encode()).hexdigest(),
    'expected_per_mode': {'conditions': 28, 'real': 24, 'generated': 4, 'preflight_workers': 84, 'timed_workers': 588, 'all_workers': 672, 'measured_samples': 105420, 'timed_warmups': 588, 'preflight_samples': 168, 'all_samples': 106176},
    'changes': 'Study paths/captions and direct source/check schema bindings only. Original worker, observations, seeded order, median, ratios, geometric aggregates and adverse-condition checks unchanged.',
    'release': 'Run only after root confirms the specified campaign completed and all target processes were reaped.',
    'targets_executed': False,
}
(OUT / 'preparation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
