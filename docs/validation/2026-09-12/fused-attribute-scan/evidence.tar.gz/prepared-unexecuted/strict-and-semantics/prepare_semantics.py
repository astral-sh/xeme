"""Bind existing semantic commands to completed strict modules; no target execution."""
from pathlib import Path
import hashlib, json, os

assert os.sched_getaffinity(0) == {6}
P = Path(__file__).parent
load = lambda p: json.loads(Path(p).read_text())
def sha(p):
    with Path(p).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
pins = load(P / 'pins.json')
assert all(sha(path) == digest for path, digest in pins.items())
strict = load(P / 'strict-cpython/report.json')
assert strict['status'] == 'completed_strict_results' and strict['pins_unchanged']
assert len(strict['commands']) == 2 and all(row['reaped'] and row['exit'] in [0, 2] and not row.get('timeout_reached') for row in strict['commands'])
template = load(P / 'semantic-commands-template.json')
assert sha(template['script']) == template['script_sha256']
recorded = {str(P / 'strict-cpython/report.json'): sha(P / 'strict-cpython/report.json'), template['script']: template['script_sha256']}
for command in template['commands']:
    directory = Path(command['strict_directory'])
    summary, origins = load(directory / 'summary.json'), load(directory / 'origin.log')
    assert summary['text_fragmentation'] is None and summary['tests_exit_code'] == summary['gate_exit_code']
    assert summary['probe_exit_code'] == summary['origin_exit_code'] == 0 and origins['status'] == 'passed'
    suffix = 'so' if command['mode'] == 'shared' else 'a'
    library = directory / ('liboriole_expat.' + suffix)
    assert sha(library) == summary['library_sha256'] == command['expected_library_sha256']
    for name in ['pyexpat', '_elementtree']:
        origin = origins['origins']['initial:' + name]
        assert origin == origins['origins']['fresh:' + name]
        assert Path(origin['path']).parent == directory and sha(origin['path']) == origin['sha256']
        recorded[origin['path']] = origin['sha256']
    assert sha(directory / 'sitecustomize.py') == summary['loader_sha256']
    for path in [library, directory / 'summary.json', directory / 'origin.log', directory / 'sitecustomize.py', directory / 'tests.log']:
        recorded[str(path)] = sha(path)
    command.update(status='held_not_executed', module_origins=origins['origins'], strict_raw_exit=summary['tests_exit_code'])
template.update(status='prepared_not_executed', pins_sha256=recorded, targets_executed=False, scope='Existing semantic tests with fresh strict module/library/origin hashes. Raw strict failures stay separate. Root owns all execution.')
with (P / 'semantic-commands.json').open('x') as stream:
    json.dump(template, stream, indent=2); stream.write('\n')
print(json.dumps({'path': str(P / 'semantic-commands.json'), 'sha256': sha(P / 'semantic-commands.json'), 'commands': 2, 'targets_executed': False}))
