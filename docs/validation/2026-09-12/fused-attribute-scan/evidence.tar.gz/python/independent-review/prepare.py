"""Adapt existing saved CPython readers; do not read candidate consumer results."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

OLD = Path('/tmp/oriole-reference-frame-python-independent-review')
OUT = Path(__file__).parent
ROOT = '/tmp/oriole-fused-attribute-scan-python-preparation/python'
before = (OLD / 'preflight_bindings.py').read_text()
helper = before
replacements = [
    ("R=Path('/tmp/oriole-reference-frame-python-study')", f"R=Path('{ROOT}')"),
    ("build=Path('/tmp/oriole-reference-frame-pgo-study')", "build=Path('/tmp/oriole-fused-attribute-scan-pgo-study')"),
    ('76e926154cb74f77f4a642921d73d44f0b54e692b5a26209f721e299f53774bc', '1ff8b11548d10bbc6f6c0cb6b53c1e03335ff7bfb30f3ccf4b834126c08bbb45'),
    ("assert prepared['head']=='0f66d54ac8418f0a6e628ad18570677a19c9ed45'", "assert prepared['head']=='4064b0653534aff690c0e0f395a6b3b48da878fc'\n    assert sha(build/'source.json')=='eb790ea508b1c8ffbc819828afaa6ace9504da03752fa448a85616ea1bce2a85'"),
    ("assert prepared['check_attempt']=='01' and prepared['expected_test_count']==440", "assert prepared['expected_test_count']==442 and prepared['test_groups']==35"),
    ("assert prepared['expected_source_delta']==['crates/oriole/src/lib.rs','crates/oriole/tests/adapter_frame.rs','tests/c/integration.c']", "assert prepared['expected_source_delta']==['crates/oriole/src/tag.rs']"),
    ("assert prepared['expected_pipeline_delta']==['crates/oriole/src/lib.rs','crates/oriole/tests/adapter_frame.rs']", "assert prepared['expected_pipeline_delta']==['crates/oriole/src/tag.rs']"),
    ("assert parent==Path('/tmp/oriole-suffix-element-names-python-study')/mode", "assert parent==Path('/tmp/oriole-reference-frame-python-study')/mode"),
    ("assert a['source_runtime_control']=='a0acaf1bf8c8ae3f55030332be794cb8b9b5bea9' and a['source_runtime_candidate']==prepared['head']", "assert a['source_runtime_control']=='0f66d54ac8418f0a6e628ad18570677a19c9ed45' and a['source_runtime_candidate']==prepared['head']\n        assert a['candidate_isa']=='generic x86_64'"),
    ("'parent_adaptation'):", "'parent_adaptation','candidate_build_readback'):"),
    ("assert a['runtime_source_delta']==['crates/oriole/src/lib.rs']", "assert a['runtime_source_delta']==['crates/oriole/src/tag.rs']"),
    ("assert sorted(a['candidate_test_delta'])==['crates/oriole/tests/adapter_frame.rs','tests/c/integration.c']", "assert a['candidate_test_delta']==['crates/oriole/src/tag.rs']"),
    ("assert a['inherited_fixture_delta']==['tests/c/integration.c']", "assert a['inherited_fixture_delta']==[]"),
]
for a, b in replacements:
    assert helper.count(a) == 1, a
    helper = helper.replace(a, b)
marker = "        c=load(D/'prepare-controller.json')"
assert helper.split(marker, 1)[1] == before.split(marker, 1)[1]
ast.parse(helper)
with (OUT / 'preflight_bindings.py').open('x') as stream:
    stream.write(helper)
(OUT / 'preflight_bindings.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), helper.splitlines(True), fromfile=str(OLD / 'preflight_bindings.py'), tofile=str(OUT / 'preflight_bindings.py'))))
helper_hash = hashlib.sha256(helper.encode()).hexdigest()
before = (OLD / 'audit.py').read_text()
audit = before.replace("Path('/tmp/oriole-reference-frame-python-study')", f"Path('{ROOT}')")
audit = audit.replace('a0cf4b1815a8d0305a2d84d3c11904e1617cecc5ad40f7dd343b1bac2d7d1f8c', helper_hash)
audit = audit.replace("out={'status':'passed_independent_raw_elapsed_reconstruction'", "out={'role':'Reviewer adapted controllers/readers and independently reviewed runtime source, with no runtime authorship or target execution. Root collected observations; this is independent raw reconstruction, not independent-author controller review.','status':'passed_independent_raw_elapsed_reconstruction'")
assert audit.split("a=load(D/'adaptation.json')", 1)[1].split("out={'role'", 1)[0] == before.split("a=load(D/'adaptation.json')", 1)[1].split("out={'status'", 1)[0]
ast.parse(audit)
with (OUT / 'audit.py').open('x') as stream:
    stream.write(audit)
(OUT / 'audit.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), audit.splitlines(True), fromfile=str(OLD / 'audit.py'), tofile=str(OUT / 'audit.py'))))
record = {'status': 'prepared_saved_only', 'targets_executed': False, 'helper_sha256': helper_hash, 'reader_sha256': hashlib.sha256(audit.encode()).hexdigest(), 'origins': {str(OLD / n): hashlib.sha256((OLD / n).read_bytes()).hexdigest() for n in ['preflight_bindings.py', 'audit.py']}, 'scope': 'Only paths, direct source/check bindings and role changed. Complete six-compile/72-preflight body and full 504-worker elapsed/callback/origin/order/sample/arithmetic body byte-exact. Run only after root reaps the specified preparation or elapsed phase.'}
(OUT / 'preparation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
