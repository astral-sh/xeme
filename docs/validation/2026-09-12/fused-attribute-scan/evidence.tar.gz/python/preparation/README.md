# Conditional fused-scanner CPython measurements

Prepared only. No extension compiler, parser, preflight or elapsed target has run.

Use `/python/normal` or `/python/pgo` below as the mode directory. Each mode retains the selected reference protocol: three engines, six identical `-O2` extension builds, 24 conditions, seven pairs, 72 preflights and 504 timed workers. The CPython 3.12.13 sources are unmodified. The existing shared header is byte-identical to the candidate header. Strict cleanup-backport consumers are separate.

## Launch after root release

1. `python3 /tmp/oriole-fused-attribute-scan-python-preparation/python/pgo/run.py prepare`
2. After that controller and all children are reaped, run `taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-fused-attribute-scan-python-review/preflight_bindings.py --released --mode pgo`.
3. After the saved origin/command gate passes and root releases exclusive CPU0 timing, run `python3 /tmp/oriole-fused-attribute-scan-python-preparation/python/pgo/run.py time`.
4. After timing is completed and reaped, run `taskset -c 6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-fused-attribute-scan-python-review/audit.py --released --mode pgo`.

Replace `pgo` with `normal` for the separate normal mode. Preparation runs on CPU3 with separate 600-second build/preflight bounds. Timing runs on CPU0 with the unchanged 300-second worker and 1,200-second aggregate bounds. The existing wrapper kills and reaps its process group after timeout/interruption. Never overlap with another compiler, parser or elapsed campaign.

## Bound inputs

`materialized.json` binds the source snapshot, completed parser build reader, library hashes and both adaptations. `pins.json` records original sources, interpreter/public headers and scripts. Candidate source is the checked 72-file snapshot with only `tag.rs` changed; base HEAD alone does not identify the uncommitted candidate. Controls are the selected generic reference and matching generic Expat. No allocator, ISA or extension compiler treatment changes.

The readers preserve the original compiler-vector, raw callback/module/library identity, sample, scheduling and arithmetic checks. They create new outputs exclusively; retain failed attempts rather than overwriting them.
