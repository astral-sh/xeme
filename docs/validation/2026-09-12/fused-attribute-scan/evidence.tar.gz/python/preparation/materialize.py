"""Prepare the existing CPython protocol for the fused scanner; execute no targets."""
from pathlib import Path
import ast
import copy
import difflib
import hashlib
import json
import os

P = Path(__file__).parent
B = Path('/tmp/oriole-fused-attribute-scan-pgo-study')
C = Path('/tmp/oriole-reference-frame-pgo-study')
W = Path('/home/dev-user/code/oss/oriole-fused-attribute-scan')
OLD = Path('/tmp/oriole-reference-frame-python-study')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())
pin = lambda p: {'path': str(p), 'sha256': sha(p)}
assert __debug__ and os.sched_getaffinity(0) == {6}
assert not (P / 'materialized.json').exists()
source, pair = read(B / 'source.json'), read(B / 'pair-report.json')
control, cpair = read(C / 'source.json'), read(C / 'pair-report.json')
proof = read(B / 'build-readback.json')
assert sha(B / 'source.json') == 'eb790ea508b1c8ffbc819828afaa6ace9504da03752fa448a85616ea1bce2a85'
assert sha(B / 'build-readback.json') == '1ff8b11548d10bbc6f6c0cb6b53c1e03335ff7bfb30f3ccf4b834126c08bbb45'
assert sha(C / 'source.json') == 'a8db4ea9e6fa1c56020e8a231343c356bce7dc6170e0766b09cc67dabd82a2af'
assert sha(C / 'pair-report.json') == 'c373ff0960db9318f2af70cdc22cec2cf61f25d80ee1d9670b58d00f8351ceda'
assert pair['status'] == cpair['status'] == proof['status'] == 'passed'
assert proof['source'] == source and proof['pair'] == pair
assert proof['control_source'] == control and proof['control_pair'] == cpair
assert len(source['source_sha256']) == len(control['source_sha256']) == 72
changed = [n for n, h in source['source_sha256'].items() if h != control['source_sha256'][n]]
assert changed == ['crates/oriole/src/tag.rs']
assert source['source_sha256'][changed[0]] == '50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6'
assert source['candidate_base_commit'] == '4064b0653534aff690c0e0f395a6b3b48da878fc'
assert source['base_runtime'] == control['candidate_base_commit'] == '0f66d54ac8418f0a6e628ad18570677a19c9ed45'
pins = {str(W / n): h for n, h in source['source_sha256'].items()}
assert all(sha(p) == h for p, h in pins.items())
for path in [B / 'source.json', B / 'pair-report.json', B / 'build-readback.json', C / 'source.json', C / 'pair-report.json', Path(__file__)]:
    assert str(path) not in proof['inputs'] or sha(path) == proof['inputs'][str(path)]
    pins[str(path)] = sha(path)
uses = []
for root, pr in [(B, pair), (C, cpair)]:
    manifest = Path(pr['pgo_manifest']['path'])
    assert sha(manifest) == pr['pgo_manifest']['sha256']
    data = read(manifest)
    assert data['base_rustflags'] == []
    assert Path(data['run']) == manifest.parent and data['libraries_sha256'] == pr['pgo_libraries']
    pins[str(manifest)] = sha(manifest)
    uses.append(manifest.parent / 'use')


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


records = {}
(P / 'python').mkdir()
for mode in ['normal', 'pgo']:
    old, out = OLD / mode, P / 'python' / mode
    out.mkdir()
    original = read(old / 'adaptation.json')
    pins[str(old / 'adaptation.json')] = sha(old / 'adaptation.json')
    assert original['counts'] == {'conditions': 24, 'engines': 3, 'extensions': 6, 'preflights': 72, 'cohorts': 168, 'pairs': 7, 'timed_workers': 504, 'measured_parses': 25788, 'warmups': 504}
    assert original['seed'] == 202609104412
    for item in original['consumer_source']['files'].values():
        assert sha(item['path']) == item['sha256']
        pins[item['path']] = item['sha256']
    for path, digest in original['consumer_source']['interpreter_and_public_headers'].items():
        assert sha(path) == digest
        pins[path] = digest
    assert sha(original['header']['path']) == original['header']['sha256'] == sha(W / 'include/expat.h')
    pins[original['header']['path']] = original['header']['sha256']
    candidate = B / 'normal/liboriole_expat.so' if mode == 'normal' else uses[0] / 'liboriole_expat.so'
    selected = C / 'normal/liboriole_expat.so' if mode == 'normal' else uses[1] / 'liboriole_expat.so'
    assert original['libraries']['candidate'] == pin(selected)
    libraries = {'candidate': pin(candidate), 'control': pin(selected), 'expat': original['libraries']['expat']}
    for library, pr in [(candidate, pair), (selected, cpair)]:
        expected = pr['normal_libraries']['liboriole_expat.so'] if mode == 'normal' else pr['pgo_libraries']['use/liboriole_expat.so']
        assert sha(library) == expected
    for item in libraries.values():
        assert sha(item['path']) == item['sha256']
        pins[item['path']] = item['sha256']
    edits = {}
    for name, digest in original['files'].items():
        assert sha(old / name) == digest
        before = (old / name).read_text()
        after = before
        applied = []
        for a, b in [('suffix control and reference-frame candidate', 'selected reference control and fused-attribute candidate'), ('suffix control, reference-frame candidate', 'selected reference control, fused-attribute candidate'), ('reference-frame ' + mode + ' CPython screen', 'fused-attribute ' + mode + ' CPython screen')]:
            if a in after:
                after = after.replace(a, b)
                applied.append([a, b])
        if name in ['python_worker.py', 'run.py']:
            assert before == after
        ast.parse(after)
        (out / name).write_text(after)
        (out / name).with_suffix('.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile=str(old / name), tofile=str(out / name))))
        pins[str(old / name)] = digest
        pins[str(out / name)] = sha(out / name)
        edits[name] = applied
    adapted = copy.deepcopy(original)
    adapted.update(libraries=libraries, files={n: sha(out / n) for n in original['files']}, parent_files=original['files'], parent_adaptation=pin(old / 'adaptation.json'), changes=edits, candidate_source_manifest=pin(B / 'source.json'), candidate_pair_report=pin(B / 'pair-report.json'), selected_control_source_manifest=pin(C / 'source.json'), selected_control_pair_report=pin(C / 'pair-report.json'), source_runtime_control=control['candidate_base_commit'], source_runtime_candidate=source['candidate_base_commit'], source_delta={n: {'control': control['source_sha256'][n], 'candidate': source['source_sha256'][n]} for n in changed}, runtime_source_delta=changed, candidate_test_delta=changed, inherited_fixture_delta=[], test_scope='Only tag.rs changes, including focused scanner tests. Candidate is the frozen checked source snapshot; base HEAD alone does not identify it.', proof='Existing selected reference three-engine 24-condition/seven-pair protocol. Generic selected Oriole, generic fused-scanner Oriole and matched generic Expat. Unmodified CPython 3.12.13 extensions, identical O2 commands and public header. No cleanup backport in elapsed consumers.', execution_status='unexecuted', candidate_isa='generic x86_64', primary_goal_comparator='generic Expat', candidate_build_readback=pin(B / 'build-readback.json'))
    adapted.pop('selected_control_pair_freeze', None)
    save(out / 'adaptation.json', adapted)
    pins[str(out / 'adaptation.json')] = sha(out / 'adaptation.json')
    records[mode] = {'adaptation': pin(out / 'adaptation.json'), 'prepare_command': ['python3', str(out / 'run.py'), 'prepare'], 'time_command': ['python3', str(out / 'run.py'), 'time']}
save(P / 'pins.json', pins)
save(P / 'materialized.json', {'status': 'prepared_not_executed', 'targets_executed': False, 'source': pin(B / 'source.json'), 'pair': pin(B / 'pair-report.json'), 'build_readback': pin(B / 'build-readback.json'), 'pins': pin(P / 'pins.json'), 'modes': records, 'scope': 'Preparation only. Each mode needs a separate root release: six extension builds and 72 canonical preflights on CPU3; saved origin/command reader gate; then 504 timing workers on exclusive CPU0. 600-second build/preflight bounds, 300-second worker bound, 1200-second timing bound remain unchanged. No compatibility or performance claim.'})
print(json.dumps({'materialized': str(P / 'materialized.json'), 'sha256': sha(P / 'materialized.json'), 'modes': records}))
