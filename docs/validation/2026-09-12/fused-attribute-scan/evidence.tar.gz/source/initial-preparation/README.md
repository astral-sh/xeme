# Native attribute delimiter/eligibility fusion — prepared, unselected

Worktree: `/home/dev-user/code/oss/oriole-fused-attribute-scan`.
Branch: `charlie/codex-oriole-fused-attribute-scan`.
Base: `4064b0653534aff690c0e0f395a6b3b48da878fc`.
Only `crates/oriole/src/tag.rs` is modified. There is no commit or push.

## Change and invariants

- The existing general `AttributeScanner::next` delegates to the original behavior through `next_impl::<false>`. Native `TagScanner` alone uses the private `next_literal` / `next_impl::<true>` specialization. There is no new runtime dispatch flag, allocation or cache.
- One `literal_ascii` boolean records whether the current value's scanned prefix contains only ASCII bytes at least space, excluding ampersand. It resets when each opening quote is consumed, persists through incomplete and empty feeds, and is initialized with each scanner. **Actual scanner/Parser layout effects have not been measured.**
- `literal_value_end` checks ASCII words for quote, `<`, control bytes, ampersand and high bytes. A clear word mask proves eight ordinary bytes; a nonzero mask uses scalar handling, never a potentially propagated mask bit as an offset. Delimiters are checked before deciding whether a byte invalidates the ASCII proof, so bytes after a quote cannot contaminate the value.
- Once a value contains a special or non-ASCII byte, this and later suffixes use the original `memchr2(quote, '<')`. At completion, the unchanged `is_literal_value` predicate handles that entire value, preserving valid Unicode eligibility and normalization/entity fallback. ASCII values skip that final predicate. Capacity exhaustion still wins before invoking the predicate.
- No false eligibility result causes an early planner fallback: the scanner waits for the same quote, `<` or incomplete boundary. Thus an earlier ampersand and later `<`, unclosed values, record limits, token limits, and sticky fallback retain their existing behavior. General complete-view `<` before `&` error precedence remains in the false specialization.
- Raw attributes, names, duplicate detection, frame lowering, selected allocator routing, callback dispatch and source/raw publication are untouched. The candidate may change compiled code layout and scalar/vector balance; normal/PGO native measurements must decide whether it is useful.

## Focused tests prepared

The existing word/Unicode predicate test now also compares the fused delimiter result against a scalar delimiter oracle and checks its ASCII proof over the exact prefix before the first delimiter. This reuses the existing adjacent ASCII pairs, word offsets and all Unicode scalar cases without adding another broad input generator.

One new incremental test compares native and general scanner steps at every UTF-8 prefix, repeating each prefix without additional input. Both quotes, word-length boundaries, long ASCII prefixes, ampersand-before-`<`, control bytes, valid Unicode, invalid XML Unicode and a following plain attribute exercise state persistence and reset. A second focused test requires a valid Unicode tag to complete after every input split with enough record capacity. It also requires an ampersand-containing value to remain incomplete until its closing quote or a less-than byte arrives, then fall back. This directly addresses the independent source reviewer’s planner-integration coverage request. Existing complete-grammar, all-split planner, capacity and source-generation tests remain unchanged.

## Commands held for root

No Cargo formatting, compiler, parser, test, Clippy, profiler or benchmark has run for this candidate. `git diff --check` passed. First run formatting, focused tests and strict Clippy after the root releases targets:

```sh
cd /home/dev-user/code/oss/oriole-fused-attribute-scan
export CARGO_HOME=/home/dev-user/.cache/toucan/cargo
export CARGO_TARGET_DIR=/home/dev-user/.cache/oriole/targets/fused-attribute-scan
export CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}'
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
export RUSTUP_AUTO_INSTALL=0
export CARGO_TERM_COLOR=never
cargo +ohm fmt --all -- --check
cargo +ohm -Zohm-defaults=no test -p oriole --lib tag::tests
cargo +ohm -Zohm-defaults=no clippy -p oriole --all-targets -- -D warnings
```

Root should use the existing bounded command controller and CPU assignment. Formatting may need its ordinary correction before compiling; it has intentionally not been executed here. Later unchanged full core/C/API controls and fresh matched normal/PGO native matrices remain necessary for selection; this preparation claims none of those results.

## Worktree preparation receipts

Before the write, the source checkout resolved to `/home/dev-user/code/oss/oriole-reference-frame`, common Git directory `/home/dev-user/code/oss/oriole/.git`, and Git email `charlie.r.marsh@gmail.com`. The destination did not exist and the requested branch was absent.

1. The initial `cargo +ohm worktree add` used the destination target in both the source environment and `--target-dir`. It exited101: `destination target directory overlaps source storage`. No worktree was created. Session36748 was reaped.
2. Correcting the source environment to `/home/dev-user/.cache/oriole/targets/reference-frame` reached Git, which failed because the common `.git` directory is read-only inside this agent's sandbox. Session12268 exited101 and was reaped; the destination still did not exist.
3. The same corrected authorized command received the required filesystem escalation and succeeded. Session76967 exited0 and was reaped. Cargo reported no compatible build snapshot seeded; it recorded the distinct destination target. Both local cache trust variables were set to `all` for the worktree setup only. No compiler/parser target ran.

The destination was then independently read back with the same common Git directory and OSS email. Preparation uses the existing shared Ohm build directory template, separate from both worktrees' stable target directories.
