# Eager native-tag position proof: bounded assessment

**A small, distinct hypothesis is reasonable: collect a sticky single-line ASCII proof during native tag planning, then avoid the completed tag's position scan. Start with that proof, not a general position-delta accumulator. No source change or target execution was performed.**

## Prior work and cost envelope

The rejected `/tmp/oriole-fused-validation/README.md` fused XML validation and position calculation in a new pass over a completed copied tag. It reduced instructions 2.73% but produced only 0.98985× baseline throughput, with six of 24 real conditions improving. The proposal here instead reuses the incremental grammar scan; the native planner already eliminates that old full-token XML validation pass. The lazy-coordinate experiments are also different: they deferred publication and added 136 bytes per Source, regressing PGO time 8.45% and 10.97%. Neither design should be repeated.

The strongest retained profile is older Context PGO `7cd7c5a8`/source `0f28139`, not the current fused candidate. The short **markup** position region `[0x4e701,0x4e8f6)` accounts for:

| Profile | Instructions | Share of all instructions |
| --- | ---: | ---: |
| Vulkan NS0 | 25,118,150 | 3.68% |
| Wayland NS0 | 541,104 | 3.52% |
| Maven NS0 | 350,266 | 3.02% |
| GTK NS0 | 134,920 | 2.64% |

Source: `/tmp/oriole-context-text-frame-maven-gtk-profile-review/regions.json`, `markup_short_position` and `same_ranges_previous_cases`. These regions include closing tags and other/ineligible markup; a successful native opening-tag proof reaches only a subset. Text's separate coordinate region is excluded. Empty-tag `Source::position_at` is a separate possible saving, but its retained whole-function cost includes other work and cannot be added as a removable estimate. There is no current proof-hit rate or elapsed prediction. This does not establish a way to eliminate the remaining roughly 19% time gap.

## Smallest useful mechanism

In the fused worktree, `tag.rs:401` advances the native planner; name scans already visit Unicode scalars, `AttributeScanner::skip_space` already visits XML whitespace, and `literal_value_end` already produces an ordinary-ASCII value proof. Collect one sticky aggregate across those existing scans:

- Both element and attribute names must contain only ASCII; fold the check into their existing name iteration, including separately checked first characters. Do not add completed-name rescans.
- Whitespace may be space or TAB; seeing CR or LF clears the aggregate.
- Fold each completed attribute's `literal_ascii` into the aggregate. That field resets for every value, so the final value's flag alone is insufficient.
- Fixed syntax (`<`, `=`, quotes, `/`, `>`) is known ASCII without line breaks.

Loss of the proof must **not** cause planner fallback: valid Unicode or multiline tags still produce their existing native plan and use ordinary position advancement. General complete attribute scanning should not pay for native-only proof bookkeeping.

A successful proof gives the exact eager transition for the complete nonempty tag: line unchanged, column increased by its byte length, previous-CR false. TAB counts as one column under the existing helper. The leading `<` already clears an incoming CR state, and the final `>` makes the result independent of it. Bind the proof to the existing source byte index and completed end offset; no source-owner, buffer or deferred-coordinate cache is needed.

## Commitment and correctness constraints

`lib.rs:2170–2190` already limits native planning to an unanchored native UTF-8 root without DTD/fragment context. Require the same native, unconverted source for using the proof. Keep `position(end)` as the eager start position; it does not scan line/column. Only replace the final successful consume's coordinate loop (`encoding.rs:987`) after `parsed?`, retaining accounting, raw index/width handling, scanner reset, deferred-size reset and compaction in their current order (`lib.rs:2308–2314`). Error paths, including duplicate attributes and failed reservations, must not commit predicted coordinates.

Empty tags currently scan to the end again at `lib.rs:3336` and `3415`. The same proof can calculate their implicit End position eagerly: start byte index + token length, same line, start column + token length, byte count zero. Preserve the distinct Start/End positions, pending empty raw override and fallible publication order. Namespace callbacks and owned-event fallback must keep existing behavior even when a lexical plan carries the proof.

For incremental input, a sticky boolean is idempotent across empty/repeated resumes; a position counter is not. Reset the aggregate when `source_index` changes, retain it across appended chunks, and discard it on syntax/capacity/limit fallback. Preserve Unicode planner completion and all existing error ordering. Check scanner/Parser layout before measurement; a new flag may fit padding, but that has not been established.

## Why not a general delta first?

Full deltas require character counts for Unicode names/values, CRLF-aware line counts in whitespace, trailing-column state, and exact once-only accounting across every scanner phase and incomplete delimiter. Those added dependencies may cost more than the existing eight-byte position loop. The boolean proof is a clearer bounded experiment. Meaningful regressions would compare eager positions against the existing helper across every feed split, both incoming CR states, multiline/Unicode fallback, empty tags, compaction, suspension and failing semantic parses. Selection still requires matched normal/PGO elapsed results; fewer instructions alone failed the earlier fusion experiment.
