# Combined Text plan: held normal build

The four reviewed Text-plan files are copied unchanged onto publication168b5f57 (PR155), which contains the selected fused attribute scanner09da. All74 source files equal the isolated Text candidate except tag.rs; tag.rs equals the published fused control50f641. Compared with the fused control, only encoding.rs, lib.rs, new text.rs and text_coalescing.rs differ. The complete patch is byte-identical to the measured isolated Text patch. No Git staging/commit or compiler/parser target was run during this preparation.

The isolated result remains separate: its control was4815/a240 and its real native geometric mean was0.983089973,22/24 favorable conditions. That result does not predict this composition or a Python gain. The next control is the normal published fused librarydca62e60, with corresponding static4a234408. Generic normal O3/ThinLTO/one codegen unit remains unchanged; no PGO work is prepared.

Root owns execution after source/controller review:

```sh
taskset -c4 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-text-plan-combined-build.py
# Only after the build has completed and been reaped:
taskset -c6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-text-plan-combined-bind.py
```

The original build controller is relocated to the combined worktree/base/target. It validates all74 source hashes against the frozen preparation and copies the complete patch including untracked text.rs. It clears inherited trust/optimization overrides and uses Cargo home /home/dev-user/.cache/toucan/cargo, target /home/dev-user/.cache/oriole/text-plan-combined-target and separate shared /home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}. Cargo commands use +ohm -Zohm-defaults=no. Full workspace tests and strict all-target Clippy broaden the isolated three-library checks; formatting and the exact normal release command are unchanged. Each child retains900s timeout with process-group kill/reap and saved logs.

The saved binder reconstructs the complete patch, verifies74 source hashes and the published fused base through Git objects, checks raw command logs/exits and actual compiler vectors, and compares target and copied libraries. It permits only the resolved compiler symlink and per-worktree shared-build path as compiler-vector normalization. Full-workspace check commands are recorded explicitly; release settings must match the fused control. It does not run a compiler or parser. The parent's next intended elapsed gate is normal CPython on this combined candidate.

composition-review.json is an author composition check, not independent runtime review; the independent reviewer is notified separately. The isolated source, measurements and evidence remain unchanged. Candidate build hashes are pending root execution, and no results are claimed here.
