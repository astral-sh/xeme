"""Materialize current normal correctness controllers; no compiler/parser execution."""
from pathlib import Path
import ast, difflib, hashlib, json, os
assert os.sched_getaffinity(0)=={6}
O=Path('/tmp/oriole-fused-normal-current-correctness')
P=Path('/tmp/oriole-text-plan-combined-correctness')
W=Path('/home/dev-user/code/oss/oriole-text-plan-combined')
B=Path('/tmp/oriole-text-plan-combined-study')
old_work='/home/dev-user/code/oss/oriole-fused-normal-current'
old_build='/tmp/oriole-fused-normal-current-study'
replacements=[(str(O),str(P)),(old_work,str(W)),(old_build,str(B))]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def save(name,value):(P/name).write_text(json.dumps(value,indent=2)+'\n')
def relocate(text):
 for old,new in replacements:text=text.replace(old,new)
 return text
P.mkdir(exist_ok=False);(P/'prior').mkdir()
scripts=['api_native.py','strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_api_c.py','read_strict_semantics.py','bind.py','bind_strict.py']
origins={}
for name in scripts:
 before=(O/name).read_text();after=relocate(before)
 if name=='bind.py':
  before_binding="""assert review['status'] == 'passed_source_review_no_actionable_findings'
assert source['worktree'] == str(W) and len(source['sha256']) == 73
assert review['source_manifest_sha256'] == sha(B / 'source.json')
assert review['source_count'] == 73 and review['changed_files'] == ['crates/oriole/src/tag.rs']"""
  after_binding="""assert review['status'] == 'passed_source_composition_and_held_controller_review'
assert source['worktree'] == str(W) and len(source['sha256']) == 74
prepared = load(P / 'reviewed-combined-source.json')
text_review = load(P / 'reviewed-text-source.json')
isolated = load(P / 'reviewed-isolated-source.json')
assert review['source_manifest_sha256'] == sha(P / 'reviewed-combined-source.json')
assert source['sha256'] == prepared['sha256']
assert review['base'] == source['base'] == prepared['base'] == '168b5f57ad5300a74eb77769ccad83e513ebe5c8'
assert review['source_files_verified'] == prepared['source_count'] == 74
assert review['four_text_files_byte_exact_to_reviewed_isolated']
assert text_review['status'] == 'passed_source_review_no_actionable_findings'
assert text_review['source_manifest_sha256'] == sha(P / 'reviewed-isolated-source.json')
assert text_review['changed_files'] == prepared['changed'] == ['crates/oriole/src/encoding.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/text.rs', 'crates/oriole/tests/text_coalescing.rs']
assert all(source['sha256'][name] == isolated['sha256'][name] for name in prepared['changed'])
assert review['fused_tag_retained'] == source['sha256']['crates/oriole/src/tag.rs'] == '50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6'
assert review['complete_patch_sha256'] == prepared['complete_patch_sha256'] == text_review['patch_sha256'] == sha(B / 'candidate.patch')"""
  assert before_binding in after
  after=after.replace(before_binding,after_binding).replace("assert binding['source_count'] == 73", "assert binding['source_count'] == 74")
 if name=='strict_cpython.py':
  assert after.count('Reviewed73-file candidate snapshot')==1
  after=after.replace('Reviewed73-file candidate snapshot','Reviewed74-file candidate snapshot')
 if name=='read_api_c.py':
  after=after.replace('API/C preparer and separate runtime reviewer reconstructed root-collected raw records and compiler vectors. Root owned all targets; this reader executed none. Controller preparation authorship is disclosed.', 'Text-plan source author adapted the existing API/C saved reader; root owns target and reader execution. Original raw reconstruction and compiler-vector checks retained; preparation authorship is disclosed.')
 if name=='read_strict_semantics.py':
  after=after.replace('Strict/API controller preparer and separate runtime source reviewer reconstructed root-collected raw outputs; execution was root-owned. Preparation authorship is disclosed.', 'Text-plan source author adapted the existing strict/semantic saved reader; root owns target and reader execution. Original raw reconstruction retained; preparation authorship is disclosed.')
 ast.parse(after)
 (P/'prior'/name).write_text(before);(P/name).write_text(after)
 (P/(name+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(O/name),tofile=str(P/name))))
 origins[name]={'origin':str(O/name),'origin_sha256':sha(O/name),'sha256':sha(P/name),'path_substitution_only':name not in ('bind.py','strict_cpython.py','read_api_c.py','read_strict_semantics.py')}
assert (P/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]==(O/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]
review_copies={'reviewed-source.json':'/tmp/oriole-text-plan-combined-independent-preparation-review.json',
              'reviewed-text-source.json':'/tmp/oriole-text-plan-independent-review.json',
              'reviewed-combined-source.json':'/tmp/oriole-text-plan-combined-preparation/source.json',
              'reviewed-isolated-source.json':'/tmp/oriole-text-plan-preparation/source.json'}
for name,origin in review_copies.items():(P/name).write_bytes(Path(origin).read_bytes())
# Relocate only original unchanged test/consumer inputs, not old output hashes or old controllers.
static={}
strictstatic={}
for filename,destination in [('static-pins.json',static),('strict-static-pins.json',strictstatic)]:
 for path,value in load(O/filename).items():
  if path.startswith(str(O)+'/'):continue
  new=relocate(path);assert sha(new)==value,new;destination[new]=value
for name in scripts:
 destination=strictstatic if name in ('strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_strict_semantics.py','bind_strict.py') else static
 destination[str(P/name)]=sha(P/name)
 static[str(P/'prior'/name)]=sha(P/'prior'/name)
static[str(Path(__file__))]=sha(__file__)
for name in review_copies:static[str(P/name)]=sha(P/name)
static[str(B/'candidate.patch')]=sha(B/'candidate.patch')
assert sha(B/'build-binding.json')=='9e549bccbd1096513489a05464a7d28f99015b45b23e55cd697f7c31da181369'
oldprep=load(O/'preparation.json')
save('preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'source_worktree':str(W),'build_directory':str(B),'controller_origins':origins,'source_review_sha256':sha(P/'reviewed-source.json'),'api':oldprep['api'],'c_consumers':oldprep['c_consumers'],'baseline_api_outcomes':oldprep['baseline_api_outcomes'],'source_delta':'Four reviewed Text files versus published fused09da carried by168b5f57;74 source inputs, unchanged fusedtag50f641.','scope':'Direct adaptation of completed fused normal correctness controllers. Source-review schema and74-file caption adjusted; raw readers retain original reconstruction with corrected preparer authorship labels. Original API assertions and limits, six C builds/runs, complete strict shared/static loop, method reader and supplemental semantics unchanged. No target executed or profile-built artifact introduced.'})
save('static-pins.json',static)
spec=load(O/'semantic-commands-unbound.json')
spec=json.loads(relocate(json.dumps(spec)))
for command in spec['commands']:assert command['expected_library_sha256'] is None
save('semantic-commands-unbound.json',spec)
strictstatic[str(P/'semantic-commands-unbound.json')]=sha(P/'semantic-commands-unbound.json')
save('strict-static-pins.json',strictstatic)
oldstrict=load(O/'strict-preparation.json')
save('strict-preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'controller_origin':str(O/'strict_cpython.py'),'controller_origin_sha256':sha(O/'strict_cpython.py'),'controller_sha256':sha(P/'strict_cpython.py'),'complete_shared_static_execution_loop_byte_exact':True,'baseline':oldstrict['baseline'],'baseline_outcomes':oldstrict['baseline_outcomes'],'consumer_fix':oldstrict['consumer_fix'],'static_pins_sha256':sha(P/'strict-static-pins.json'),'scope':'Original strict consumer-cleanup backport and historical two failures per linkage remain the comparison oracle; separate unchanged two semantic tests per linkage. Candidate outcomes pending. All target execution remains held.'})
print(json.dumps({'status':'prepared_not_executed','path':str(P),'preparation_sha256':sha(P/'preparation.json'),'scripts':len(scripts),'static_pins':len(static),'strict_static_pins':len(strictstatic)}))
