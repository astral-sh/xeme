# Combined Text plan: held normal compatibility gates

Prepared and held for root execution. This directly adapts the completed published-fused controllers; source/output/normal-library paths and source-review schema change. The saved binder distinguishes the reviewed preparation manifest from the completed build manifest. Their JSON bytes differ, and their 74-file source maps must match exactly. It also checks the independent combined composition review, original Text review, all four matching Text files and complete patch. The strict reader preserves the existing 809 rendered-line oracle alongside the unchanged 802-method map. Reader role labels identify the Text-plan author as preparer; original reconstruction remains unchanged. Original controller source and readable patches are in `prior/` and `*.patch`.

Execution is conditional on root accepting the combined performance results; no correctness target is released by this preparation.

Candidate shared library: `ef1648fcb1bae5bce53715283b221166c84e5e8431ff53f39e62a1ecd358bd25`; static archive: `cbe99d01b5d2978f60d7b2a1ace6f50dedd831daac1ab2ea92f90d6db15f7848`. Both are completed normal generic O3/ThinLTO/cgu1 artifacts. Source has 74 pins: four reviewed Text files differ from published fused09da carried by168b5f57; fused `tag.rs` stays unchanged. No parser rebuild or profile campaign is included.

## Gates and retained failures

- Original 4,740 API configurations retain 3s/case, 1GiB address space, 768MiB RSS, 240s matrix and 300s outer bounds. Baseline 4,347 pass / 391 assertion failures / 2 timeouts; all ordered rows are compared, raw exit 1 preserved.
- Six C consumers: integration, adversarial and allocations, dynamic/static. Each compile/run retains 120s. C ASan/UBSan, uninstrumented normal Rust, leak checking disabled. Compile/link metadata and raw results retained; no new in-process dladdr claim.
- Strict CPython shared/static retains the explicit upstream pyexpat allocation-failure cleanup backport, 1,000s/linkage and complete original suite. Baseline 802 method identities and 809 rendered outcomes per linkage, raw exit 2 with `BufferTextTest.test1` and `CDATAHandlerTest.test_handlers` failures. These patched strict consumers are separate from unmodified benchmark modules.
- Two existing text-semantic tests per linkage run separately after exact fresh module/origin binding; 120s plus 5s termination grace / 130s outer. They never relabel strict failures as passing.

## Parent launch order

Use the pinned interpreter `/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12`. Run in the existing clean environment with its bin directory plus `/usr/bin:/bin` on PATH and compiler/allocator/loader overrides cleared. Each output is single-use; stop on any failed binder or controller.

1. CPU6 saved-only: `python3.12 -I -S bind.py`, then `python3.12 -I -S bind_strict.py` (both require `taskset -c 6`).
2. CPU3 target: `python3.12 -I -S api_native.py` (`taskset -c 3`; the controller also pins its children). Then CPU6 saved-only `read_api_c.py` after all children are reaped.
3. CPU3 target: `python3.12 -I -S strict_cpython.py` (requires `taskset -c 3`). After reaping, CPU6 saved-only `prepare_semantics.py` binds fresh modules/loader/origins.
4. CPU3 targets: `python3.12 -I -S run_semantic.py shared`, then `python3.12 -I -S run_semantic.py static`; each uses the original isolated command from `semantic-commands.json`.
5. CPU6 saved-only: `python3.12 -I -S read_strict_semantics.py` reconstructs both full method maps, all 809 rendered lines, compiler/import records and four supplemental semantic outcomes.

All relative script names above are under `/tmp/oriole-text-plan-combined-correctness`. Root owns every target and final saved-result release. Preparation executed no compiler, parser, strict or semantic target. The prior reference-frame baseline is retained because its ordered API and strict outcomes were also verified unchanged by current PR154; it is not a current performance comparator.

## Preparation records

The first saved materializer stopped before any binder or target because a prior top-level author-script pin was mistakenly relocated with its directory prefix. `correctness-attempt01` and preparation01 logs preserve that failure. The corrected materializer keeps the original author-script pin at its original path; preparation02 completed and was reaped with exit 0. No test input, assertion, bound, runtime source or library changed. Copied prior preparation/static metadata remain under `prior/`; original raw outputs remain at their pinned baseline locations. API/C and strict binders are still held.
