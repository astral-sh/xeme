# Combined Text plan: normal native protocol

Candidate is the reviewed Text plan on PR155. Control is PR155's published fused scanner. Both use ordinary generic x86-64 O3, ThinLTO, one codegen unit; Expat is the existing normal 2.8.4 baseline. No PGO.

All 24 real conditions and four generated controls use the original seven seeded pairs, 84 fresh preflight workers and 588 timed workers. Every sample includes parser construction, handlers, feeding, callbacks and destruction. Callback digests merge text fragments; they do not establish exact callback fragmentation.

Root runs run.py with the pinned CPython bin directory first on PATH. The unchanged wrapper runs preflight on CPU5 (600-second bound), then exclusive elapsed on CPU0 (1200-second bound), with original 90-second worker limits and process-group cleanup. Root runs read_results.py on CPU6 afterward. No target ran during preparation.
