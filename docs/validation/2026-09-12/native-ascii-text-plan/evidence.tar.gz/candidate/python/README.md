# Combined Text plan: normal CPython preparation

This compares the combined Text plan with the published fused attribute scanner. The source base is PR155 tail168b5f57, carrying selected09da. The four Text-plan files match the measured isolated candidate exactly, while fused tag.rs stays unchanged. All74 source files and the complete patch are pinned. The isolated Text native result used4815/a240 as its control; it is not a combined Python result.

## Parser identities

| Engine | Normal shared library SHA-256 |
| --- | --- |
| Combined candidate | `ef1648fcb1bae5bce53715283b221166c84e5e8431ff53f39e62a1ecd358bd25` |
| Published fused control | `dca62e60f80e311fbb529e66262fd2f7f07d8f38eda16c97cd33aa9dd8063488` |
| Expat | `7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478` |

The completed root build and saved binder record449 passing tests across35 full-workspace groups, formatting and strict Clippy, and actual normal compiler vectors. Both Oriole libraries use generic x86-64 O3/ThinLTO/one codegen unit. No PGO or CPU-target experiment is introduced.

## Consumer reuse and fresh work

| New engine | Existing or new consumer directory | Compilation |
| --- | --- | --- |
| Control | `/tmp/oriole-fused-normal-current-study/python/consumers/candidate` | Reuse two selected modules |
| Expat | `/tmp/oriole-expanded-start-capacity-study/python/consumers/expat` | Reuse two existing modules |
| Candidate | `/tmp/oriole-text-plan-combined-study/python/consumers/candidate` | Build two fresh modules |

The previous fused campaign's composite build record contains both reused engine records. `prepare.py` maps its candidate to this control and retains its Expat record. It checks saved module/library hashes, original compiler vectors/logs, unmodified CPython source, interpreter/headers, prior origins and compiler driver. The unchanged build helper checks the original vectors and copies the records; only the candidate compilation body runs. Prior preflight or elapsed rows are not substituted: all three engines receive fresh canonical preflights and timing.

All consumers use unmodified CPython3.12.13 pyexpat.c and _elementtree.c, revision3bb231a6a5dc02b95658877318bf61501a7209e9, with the same `cc -shared -fPIC -O2` recipe. The cleanup backport used by separate strict tests is absent. Existing headers and include paths stay byte-identical. The worker loads modules from an explicit directory and verifies in-process dladdr(XML_Parse), module hashes and parser-library origin.

## Preserved measurement protocol

`run.py`, `python_worker.py` and `build_consumers.py` are byte-identical to the completed fused experiment. `consumer_screen.py` changes captions only. Both saved readers retain their exact reconstruction and arithmetic, with only the study path changed. The consumer binder accounts for74 candidate versus73 control inputs, the added text.rs and the exact four-file delta; it explicitly checks unchanged fused tag.rs and the complete patch.

The six original XML project inputs,4/64KiB feeds, ElementTree and pyexpat-event modes give24 conditions. Seven paired cohorts use seed202609104412 with unchanged iterations, shuffled engine order, process medians and paired ratios. Fresh preflight runs72 workers; timing runs504 workers and25788 measured parses. Total576 workers and26364 samples include warmups.

Each worker discards one warmup, retains automatic GC, and times parser creation, feed/finalization, callbacks and explicit destruction. Imports, input reads, canonical checks and explicit gc.collect stay outside the timer. Canonical comparison coalesces adjacent text callbacks; strict callback compatibility remains a separate gate. Every condition and adverse result is retained.

## Root-held launch order

The combined parser build and its saved binder have completed. Root reviews these scripts before running the following commands sequentially, stopping on any failure:

```sh
taskset -c6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-text-plan-combined-study/python/prepare.py
taskset -c6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-text-plan-combined-study/python/bind.py
/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-text-plan-combined-study/python/run.py prepare
taskset -c6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-text-plan-combined-study/python/preflight_review.py
/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-text-plan-combined-study/python/run.py time
taskset -c6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3 -I -S /tmp/oriole-text-plan-combined-study/python/elapsed_review.py
```

The first two commands read saved data and bind the actual build artifacts. `run.py prepare` reservesCPU3 for the two compiles and all preflights,600 seconds per phase. `time` requires exclusiveCPU0, with300 seconds per worker and1200 seconds overall. The unchanged wrapper kills and waits for the process group on timeout/interruption. Saved readers useCPU6. Single-use outputs preserve first failures; no target execution occurred during this source preparation.
