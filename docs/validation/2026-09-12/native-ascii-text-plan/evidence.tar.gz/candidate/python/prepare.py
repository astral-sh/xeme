"""Bind saved control consumers and completed combined parser build; no targets."""
from pathlib import Path
import ast
import hashlib
import json
import os
import shutil

assert __debug__ and os.sched_getaffinity(0) == {6}
D = Path(__file__).parent
P = Path('/tmp/oriole-fused-normal-current-study/python')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def save(p, v):
    with p.open('x') as stream:
        stream.write(json.dumps(v, indent=2) + '\n')

assert not (D/'preparation.json').exists()
build = load(D.parent/'build.json')
binding = load(D.parent/'build-binding.json')
source = load(D.parent/'source.json')
prepared = load('/tmp/oriole-text-plan-combined-preparation/source.json')
assert build['status'] == binding['status'] == 'passed' and build['source_unchanged']
assert binding['build_sha256'] == sha(D.parent/'build.json')
assert binding['source_manifest_sha256'] == build['source_sha256'] == sha(D.parent/'source.json')
assert source['sha256'] == prepared['sha256'] and len(source['sha256']) == 74
assert source['base'] == binding['base'] == '168b5f57ad5300a74eb77769ccad83e513ebe5c8'
assert binding['complete_patch_sha256'] == prepared['complete_patch_sha256'] == sha(D.parent/'candidate.patch')
for name, value in source['sha256'].items():
    assert sha(Path(source['worktree'])/name) == value

old = load(P/'consumers/build.json')
prior = load(P/'preflight-review.json')
assert old['status'] == prior['status'] == 'passed'
assert old['adaptations'] is None and old['source_sha256_before'] == old['source_sha256_after']
reuse = {'status': 'verified_saved_reuse', 'build_record': str(P/'consumers/build.json'),
         'preflight_review': str(P/'preflight-review.json'),
         'engines': {'control': {'prior_engine': 'candidate'}, 'expat': {'prior_engine': 'expat'}},
         'pins': {}}
def pin(p, expected=None):
    p = Path(p); value = sha(p)
    if expected is not None: assert value == expected, p
    reuse['pins'][str(p)] = value
    return value
for name in ('consumers/build.json', 'preflight-review.json', 'prepare-controller.json', 'build_consumers.py', 'python_worker.py', 'consumer_screen.py', 'adaptation.json'):
    pin(P/name)
a0 = load(P/'adaptation.json')
for v in a0['consumer_source']['files'].values(): pin(v['path'], v['sha256'])
for p, h in a0['consumer_source']['interpreter_and_public_headers'].items(): pin(p, h)
pin(a0['header']['path'], a0['header']['sha256'])
cc = Path(shutil.which('cc')).resolve(strict=True)
reuse['compiler_driver'] = {'path': str(cc), 'sha256': pin(cc)}
for engine, entry in reuse['engines'].items():
    consumer = old['consumers'][entry['prior_engine']]
    entry['directory'] = consumer['directory']
    entry['library'] = consumer['library']
    entry['library_sha256'] = consumer['files'][consumer['library']]
    assert entry['library_sha256'] == {
        'control': 'dca62e60f80e311fbb529e66262fd2f7f07d8f38eda16c97cd33aa9dd8063488',
        'expat': '7a333bc8ac92ff53b8fc1ecc68711802e7c5781f52d3d0592a6f0ee362d9f478'}[engine]
    for p, h in consumer['files'].items(): pin(p, h)
    for module, command in zip(('pyexpat', '_elementtree'), consumer['commands'], strict=True):
        assert command['returncode'] == 0
        pin(Path(consumer['directory'])/(module+'-build.log'), command['log_sha256'])
    assert prior['origins'][entry['prior_engine']]['parser_library'] == {'path': str(Path(consumer['library']).resolve()), 'sha256': entry['library_sha256']}
save(D/'reuse.json', reuse)

scripts = ('run.py', 'python_worker.py', 'build_consumers.py', 'consumer_screen.py')
adaptations = load(D/'script-adaptations.json')
assert adaptations['origin'] == str(P) and adaptations['inverse_text_equal']
for name, changes in adaptations['changes'].items():
    text = (D/name).read_text()
    ast.parse(text)
    for before, after in reversed(changes): text = text.replace(after, before)
    assert text == (P/name).read_text(), name
for name in ('run.py', 'python_worker.py', 'build_consumers.py'):
    assert (D/name).read_bytes() == (P/name).read_bytes()

a = {k: a0[k] for k in ('counts', 'bounds', 'seed', 'consumer_source', 'header', 'counts_with_warmups')}
a.update(status='prepared_only', execution_status='unexecuted', mode='normal', origin=str(P),
    parent_files={n: sha(P/n) for n in scripts}, files={n: sha(D/n) for n in scripts},
    source_runtime_control='168b5f57ad5300a74eb77769ccad83e513ebe5c8',
    candidate_source='/home/dev-user/code/oss/oriole-text-plan-combined',
    consumer_directories={e: reuse['engines'][e]['directory'] if e in reuse['engines'] else str(D/'consumers/candidate') for e in ('control','candidate','expat')},
    libraries={'candidate': {'path': str(D.parent/'normal/liboriole_expat.so'), 'sha256': binding['candidate_libraries']['liboriole_expat.so']},
               'control': {'path': str(P.parent/'normal/liboriole_expat.so'), 'sha256': binding['control_libraries']['liboriole_expat.so']},
               'expat': a0['libraries']['expat']},
    extension_compiles={'fresh': 2, 'reused': 4, 'total': 6},
    parser_builds='Generic normal O3/ThinLTO/one codegen unit Oriole versus pinned normal O3 Expat. Four unchanged O2 control/Expat modules reused; two identical-recipe O2 candidate modules built fresh.',
    proof='run.py, python_worker.py and build_consumers.py byte-identical to completed selected fused protocol. consumer_screen.py changes captions only. Original24conditions,7pairs,worker iterations,canonical checks,origins,GC,destruction,medians and timeout cleanup unchanged.',
    comparison_scope='Combined Text plan versus published fused09da/dca62 control, carried by168b5f57, and unchanged normal Expat. Isolated4815 Text native results are not substituted.',
    source_scope='74 source files. Four reviewed Text files exactly match isolated candidate; published fusedtag50f641 identical across control and candidate. Complete patch pinned.')
assert a['libraries']['control']['sha256'] == reuse['engines']['control']['library_sha256']
for entry in a['libraries'].values(): assert sha(entry['path']) == entry['sha256']
for key, name in (('candidate_source_record','source.json'), ('candidate_build_record','build.json'), ('candidate_build_review','build-binding.json')):
    a[key] = {'path': str(D.parent/name), 'sha256': sha(D.parent/name)}
save(D/'adaptation.template.json', a)
static_names = [*scripts, 'preflight_review.py', 'elapsed_review.py', 'bind.py', 'prepare.py',
                'README.md', 'script-adaptations.json', 'source-preparation.json',
                'reuse.json', 'adaptation.template.json']
static_names += [name+'.patch' for name in (*scripts, 'preflight_review.py', 'elapsed_review.py', 'bind.py')]
pins = {str(D/name): sha(D/name) for name in static_names}
for p in [D.parent/'source.json', D.parent/'build.json', D.parent/'build-binding.json', D.parent/'candidate.patch', Path('/tmp/oriole-text-plan-combined-preparation/source.json'), Path('/tmp/oriole-text-plan-combined-independent-preparation-review.json')]:
    pins[str(p)] = sha(p)
result = {'status': 'prepared_unbound', 'targets_executed': False, 'pins': pins,
          'extension_compiles': a['extension_compiles'], 'counts': a['counts'],
          'counts_with_warmups': a['counts_with_warmups'], 'bounds': a['bounds'],
          'source_count': 74, 'control': a['libraries']['control'],
          'unchanged': ['run.py', 'python_worker.py', 'build_consumers.py'],
          'next_saved_command': ['taskset', '-c', '6', '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3', '-I', '-S', str(D/'bind.py')]}
save(D/'preparation.json', result)
print(json.dumps({'status':'prepared_unbound', 'preparation_sha256':sha(D/'preparation.json'), 'fresh_compiles':2, 'reused_compiles':4, 'candidate':a['libraries']['candidate']}))
