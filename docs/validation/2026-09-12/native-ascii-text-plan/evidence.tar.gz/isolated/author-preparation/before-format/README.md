# Native ASCII Text plan — unselected source preparation

Source-only candidate in `/home/dev-user/code/oss/oriole-text-plan`, branch `charlie/codex-oriole-text-plan`, based on publication `4815cf78d7419a18df8d698aaae0bbde8daa526f`. Checkout, common Git directory `/home/dev-user/code/oss/oriole/.git`, and OSS identity were verified before editing. No Cargo, compiler, parser, profiler or benchmark has run on this candidate.

## Change

The transient `TextPlan` scans a root native UTF-8 content span once for its delimiter, ASCII XML validity and eager line/column delta. It skips eight ordinary printable ASCII bytes at a time with integer word operations; words that may contain special bytes are examined scalarly. This is SWAR/word scanning, not a claim of SIMD vector instructions. TAB, LF and DEL are accepted; CR, `]`, non-ASCII and other C0 controls abandon the entire proof and use the original parser path. No shortened prefix is accepted at an uncertain byte.

The first `<` or `&` ends the plan without examining later bytes. A delimiter at offset 65,536 is accepted, matching the existing 65,537-byte markup search; longer unresolved spans fall back. A nonfinal complete ASCII buffer still emits exactly the span the old path emits. Converted sources, external children, entity sources, prolog/epilog and CDATA retain their existing paths.

`parse_text` shares its existing fallback, raw ownership, event/frame preparation and publication code. A successful plan skips the later XML-character and forbidden-CDATA scans, and passes its no-CR proof to character-data preparation. `save_current_raw` remains unchanged. The final consume still accounts source bytes first. Only after accounting succeeds does the plan replace `advance_position`; the existing cursor advance, scan/deferred reset and compaction tail is shared by both consume paths. Ordinary Text publication before a late non-OOM accounting error is preserved.

The position summary counts LF bytes and the suffix after the last LF. A leading LF after a previous CR does not add another line; a nonempty committed span clears the CR state, while an empty plan preserves it. No persistent parser/source/frame fields, allocations, unsafe code, dependencies, callback API or quota changes are added.

## Review and tests prepared

The complete patch includes **new, untracked** `crates/oriole/src/text.rs`; an ordinary unstaged Git diff alone omits it. The source manifest has 74 files, adding that one file to the selected 73-file map. Other changed files are core `lib.rs`, `encoding.rs`, and existing `tests/text_coalescing.rs`. No staging, commit or push occurred. `git diff --check` passed; compilation and test results are pending.

Focused tests cover every ASCII byte at 16 word-lane positions, ignored uncertain bytes after a delimiter, markup at the 64 KiB cutoff, long ambiguous fallback, prior-CR line tracking, exact source compaction/reset behavior, actual raw Text spans/eager event positions across short feed widths and compaction, and exact UTF-8-plan versus explicit US-ASCII-fallback events/errors across malformed feeds. Existing late-accounting-prefix, converted-window, malformed-line and CRLF tests remain applicable.

Root owns target release. Suggested focused commands, with both trust overrides cleared and stable separate target/build directories:

```sh
env -u CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST -u CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST CARGO_TARGET_DIR=/home/dev-user/.cache/oriole/text-plan-target CARGO_BUILD_BUILD_DIR=/home/dev-user/.cache/ohm/build cargo +ohm test --locked --offline -p oriole text::tests
env -u CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST -u CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST CARGO_TARGET_DIR=/home/dev-user/.cache/oriole/text-plan-target CARGO_BUILD_BUILD_DIR=/home/dev-user/.cache/ohm/build cargo +ohm test --locked --offline -p oriole planned_text_matches_eager_consumption_and_compaction
env -u CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST -u CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST CARGO_TARGET_DIR=/home/dev-user/.cache/oriole/text-plan-target CARGO_BUILD_BUILD_DIR=/home/dev-user/.cache/ohm/build cargo +ohm test --locked --offline -p oriole --test text_coalescing
env -u CARGO_UNSTABLE_OHM_PROC_MACRO_TRUST -u CARGO_UNSTABLE_OHM_NATIVE_TOOL_TRUST CARGO_TARGET_DIR=/home/dev-user/.cache/oriole/text-plan-target CARGO_BUILD_BUILD_DIR=/home/dev-user/.cache/ohm/build cargo +ohm test --locked --offline -p oriole context_text_native_prefix_precedes_late_accounting_error
```

Root should format/check the final reviewed source before broader compatibility and matched normal-release performance decisions. Potential costs include the eligibility branch, transient plan fields, and an extra bounded scan on long/uncertain fallback text. No gain is predicted or selected until measured; current raw copying and callback storage remain outside this change.
