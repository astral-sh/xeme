# Isolated Text plan: normal native preparation

Prepared only. The Text-plan candidate uses publication4815 with its original tag.rs, normal library2846695f. Its control is publication4815 expanded Start capacity, normal librarya240099f. Expat is unchanged normal7a333bc8. The later selected09da fused attribute scanner is absent from this experiment. All parser binaries already exist; this preparation rebuilds none.

The completed normal protocol is retained: all24 real conditions and4 generated controls,4/64KiB feeds,7 seeded pairs2026091003, original iterations and engine shuffle. There are84 preflight workers and588 timed workers,672 total, with106176 samples including warmups. Each measured sample includes parser creation, handlers, feed/finalization, callbacks and destruction. The same faithful C driver uses explicit dlopen of the recorded library path; raw callback digests merge text fragments. No new dladdr or exact-fragmentation claim is made.

run.py is byte-identical. native_screen.py changes only paths and captions; its worker, schedule, measurement and timeout code is byte-identical. The saved reader changes source/library bindings and labels only, retaining every raw worker, median, ratio and adverse condition. Its preparation receipt remains historical; later execution needs completed controller and raw records.

Root holds execution. Pin PATH so child python3 resolves to the same CPython3.12.13 interpreter:

```sh
env PATH=/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin:/usr/bin:/bin /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-text-plan-study/native/run.py
taskset -c6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-text-plan-study/native/read_results.py
```

Preflight runs onCPU5 with600s bound, then timing on exclusiveCPU0 with1200s bound; each worker retains90s. Existing wrapper timeout/interruption kills and waits for its process group. Output is single-use; saved reader runs onCPU6. All target execution remains with root. No PGO, profile or CPU-target experiment is introduced.

The saved build binder retained its first failed attempt: one stale fused target-directory path was corrected; actual Text-plan target and copied libraries agree. Source and build artifacts were unchanged. All five original command receipts passed and were reaped; exact test count is in build-binding.json.
