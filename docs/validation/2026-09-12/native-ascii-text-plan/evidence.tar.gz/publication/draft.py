"""Produce Text-plan documentation drafts from completed saved results only."""
from pathlib import Path
import csv, difflib, hashlib, json, os, re, statistics, subprocess
assert os.sched_getaffinity(0) == {6}
P=Path(__file__).parent; D=P/'draft'; W=Path('/home/dev-user/code/oss/oriole-text-plan-combined')
B=Path('/tmp/oriole-text-plan-combined-study'); I=Path('/tmp/oriole-text-plan-study'); C=Path('/tmp/oriole-text-plan-combined-correctness')
COMMIT='ea52004a6590a224bfc0ec96c8e80a3159920db5'
DEST='docs/validation/2026-09-12/native-ascii-text-plan'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
save=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n')
D.mkdir(exist_ok=False);(D/'docs').mkdir()
source=load(B/'source.json'); binding=load(B/'build-binding.json')
native=load(B/'native/review.json'); python=load(B/'python/normal-review.json'); isolated=load(I/'native/review.json')
api=load(C/'api-c-readback.json'); strict=load(C/'strict-semantic-readback.json')
for p,h in [(B/'native/review.json','e3b067d2f9fa5c8d8d58c5a5648b9f6a7e38f94340fcdef40364985d5a974230'),(B/'python/normal-review.json','e463f64d4b238e354678c3ab289092c928636610432c3154d8c761e9bd74b933'),(C/'api-c-readback.json','9e5adf492acb4f178b9adc3c6566c558eef9f6e3d7d8b915e9814563a101924e'),(C/'strict-semantic-readback.json','95b27788f2df469a93ef8c1252dba8025d03ac7cadf1b8b33f2171ee4210b251')]:assert sha(p)==h
assert len(source['sha256'])==74
for name,h in source['sha256'].items():
    assert sha(W/name)==h
    assert hashlib.sha256(subprocess.check_output(['git','show',COMMIT+':'+name],cwd=W)).hexdigest()==h
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
assert subprocess.check_output(['git','rev-parse',COMMIT+'^'],cwd=W,text=True).strip()=='168b5f57ad5300a74eb77769ccad83e513ebe5c8'
changed=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',COMMIT],cwd=W,text=True).splitlines()
assert changed==['crates/oriole/src/encoding.rs','crates/oriole/src/lib.rs','crates/oriole/src/text.rs','crates/oriole/tests/text_coalescing.rs']
commit={'status':'committed_source_matches_measured_bytes','commit':COMMIT,'parent':source['base'],'source_count':74,'source_manifest_sha256':sha(B/'source.json'),'sha256':source['sha256'],'changed_files':changed,'measured_libraries':binding['candidate_libraries'],'scope':'The measured precommit source map matches all74 committed files; this does not claim a rebuild after committing.'}
save(P/'committed-source.json',commit)

rows=load(B/'native/native-screen/results.json')['rows']; table=[]
labels={'vulkan':'Vulkan registry','wayland':'Wayland protocol','maven':'Maven POM','batik':'Batik SVG','gtk':'GTK UI','docbook':'DocBook XSL'}
for name,label in labels.items():
    selected=[r for r in rows if r['condition']['name']==name and r['condition']['chunk']==4096 and not r['condition']['namespaces']]
    assert len(selected)==7
    values={engine:[next(p['median_seconds'] for p in r['processes'] if p['engine']==engine) for r in selected] for engine in ['candidate','expat']}
    summary=next(r for r in native['all_conditions'] if r['condition']==selected[0]['condition'])
    table.append({'project':name,'label':label,'candidate_ms':statistics.median(values['candidate'])*1000,'expat_ms':statistics.median(values['expat'])*1000,'paired_ratio':summary['median_ratios']['candidate_over_expat'],'process_medians_seconds':values})
text='| Project XML | Oriole (normal) | Expat (normal) | Oriole / Expat |\n| --- | ---: | ---: | ---: |\n'+''.join(f"| {r['label']} | {r['candidate_ms']:.3f} ms | {r['expat_ms']:.3f} ms | {r['paired_ratio']:.3f}× |\n" for r in table)
(P/'README-table.md').write_text(text);save(P/'README-table.json',{'scope':'4KiB/ns0. Times are medians of seven process medians; ratios are medians of paired process ratios, not ratios of displayed medians.','rows':table})
within=python['aggregates']['all']['candidate_within_1_10_of_expat'];assert within==4
old=(W/'README.md').read_text();new=re.sub(r'\| Project XML.*?\n\n',text+'\n',old,count=1,flags=re.S)
new=new.replace('docs/validation/2026-09-12/fused-attribute-normal/',DEST+'/').replace('use the fused attribute scanner and original XML','use the native ASCII Text plan with the fused attribute scanner and original XML')
start=new.index('Across their respective 24 real-project conditions,');end=new.index('\n\n',start)
new=new[:start]+f"Across their respective 24 real-project conditions, the candidate takes **1.48× Expat's native time and 1.19× its CPython time**, improvements of 1.87% and 2.14% against the previous selected runtime. Both remain above our target of roughly 1.10×; four of 24 individual CPython conditions fall within it. Native improves in 20 conditions, with a largest regression of 3.29% on DocBook; all 24 CPython conditions improve. The [full report]({DEST}/) retains every condition, both generated rare-declaration regressions, and the separate isolated Text experiment."+new[end:]
assert new[new.index('> [!WARNING]'):new.index('## Highlights')]==old[old.index('> [!WARNING]'):old.index('## Highlights')]
assert new[new.index('## License'):]==old[old.index('## License'):]
assert new[new.index('## Installation'):]==old[old.index('## Installation'):]
(D/'README.md').write_text(new)
compat=(W/'docs/compatibility.md').read_text();previous=compat.split('\n\n')[2]
assert previous.startswith('The [fused attribute scanner]')
paragraph="The [native ASCII Text plan](validation/2026-09-12/native-ascii-text-plan/) takes 1.4799× Expat's normal native time and 1.1906× its normal CPython time across their respective 24 real-project conditions, improvements of 1.87% and 2.14% against the selected fused attribute scanner. Four of 24 CPython conditions meet the roughly 1.10× target; both aggregates remain above it. Native improves in 20 conditions and retains four real-input regressions, largest 3.29% on DocBook; all 24 CPython conditions improve. Generated native controls remain 3.9589× Expat, with both rare-declaration regressions retained. Fresh checks preserve all 4,740 original API outcomes and all 802 strict CPython method outcomes per linkage: 4,347 API passes, 391 assertion failures and two timeouts; the same two strict callback-grouping failures remain, and both strict suites exit 2. The strict consumers use the explicit upstream allocation-failure cleanup backport; benchmark consumers are unmodified. Six C consumers and two supplemental semantic tests per linkage pass. The C harnesses use ASan/UBSan, with uninstrumented Rust release libraries and leak detection disabled. Current-source sustained fuzzing and an installed PBS trial remain outstanding."
compat=compat.replace(previous,paragraph,1).replace("current fused scanner's unchanged original matrix", "current Text candidate's unchanged original matrix")
(D/'docs/compatibility.md').write_text(compat)
review=(W/'docs/review.md').read_text();oldtop=review.split('\n\n')[1]
newtop="The [native ASCII Text plan report](validation/2026-09-12/native-ascii-text-plan/) binds the measured 74-file source to `ea52004a` and records its normal native and CPython measurements. A transient eight-byte ASCII classifier combines text-boundary, validity and eager-position work; uncertain input uses the existing path. Native time decreases by 1.87% and CPython by 2.14% against the published fused scanner, remaining 1.48× and 1.19× Expat. The report retains all four native real-input regressions and both generated rare-declaration regressions; all 24 Python conditions improve. All 449 workspace tests, formatting, strict Clippy and six C consumers pass. Original API and strict CPython outcome maps remain unchanged, including known failures; separate shared/static semantic checks pass. The isolated Text experiment, source reviews, first preparation failures and complete raw measurements have their own identities. No current-source sustained fuzzing or installed PBS result is inferred."
review=review.replace(oldtop,newtop,1)
history=oldtop.replace("current runtime's","then-selected runtime's").replace('Current-source checks','Checks on that source').replace('on the preceding runtime','on preceding `4815cf78`')
review=review.replace('## Earlier source-specific reports\n\n','## Earlier source-specific reports\n\n'+history+'\n\n',1)
(D/'docs/review.md').write_text(review)
for name in ['README.md','docs/compatibility.md','docs/review.md']:
    path=D/name; (P/(name.replace('/','-')+'.patch')).write_text(''.join(difflib.unified_diff((W/name).read_text().splitlines(True),path.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
assert api['api']['counts']=={'pass':4347,'fail':391,'timeout':2}
assert all(r['methods']==802 and r['rendered_outcome_lines']==809 and r['raw_exit']==2 and r['changes']==[] for r in strict['strict'].values())
adverse=[{'condition':r['condition'],**r['median_ratios']} for r in native['all_conditions'] if r['median_ratios']['candidate_over_control']>1];assert len(adverse)==6
report={'status':'completed_normal_text_plan_results','runtime_commit':COMMIT,'source_count':74,'combined':{'build':binding,'native_counts':native['counts'],'native_groups':{k:{a:b for a,b in v.items() if a!='adverse'} for k,v in native['groups'].items()},'python_counts':python['counts'],'python_groups':python['aggregates'],'adverse_native':adverse},'isolated':{'base':load(I/'source.json')['base'],'libraries':load(I/'build.json')['libraries'],'control':'publication4815/a240','native_counts':isolated['counts'],'native_groups':isolated['groups'],'python_executed':False,'scope':'Separate isolated Text plan with original tag.rs; native results are not a paired comparison with the combined campaign.'},'compatibility':{'api':api['api'],'c_consumers':len(api['c_consumers']),'strict':{k:{x:r[x] for x in ['methods','rendered_outcome_lines','raw_exit','changes','failures']} for k,r in strict['strict'].items()},'semantic_tests':strict['semantics']},'roles':'Text-plan author prepared implementation/controllers and this packet. Root ran targets and adapted saved readers. Separate agents reviewed source/controller preparation and independently replayed combined raw results; final archive/documentation review is separate.','limitations':['Normal generic builds only; no current PGO or CPU-target experiment.','These are project XML input parses, not whole-project application runs.','Single shared Linux AMD EPYC-Milan host; no statistical-significance claim.','Raw text callback coalescing in benchmark digests is separate from strict callback-grouping failures.','C ASan/UBSan harnesses link uninstrumented Rust; leak checks disabled.','Current-source sustained fuzzing and installed PBS validation remain outstanding.','Preceding instruction profiles and allocation-semantic diagnostics describe4815, not this Text runtime.'],'readme_table':table,'readme_warning_and_license_unchanged':True}
save(P/'report.json',report)
native_gain=(1-native['groups']['real']['geomean_ratios']['candidate_over_control'])*100
py_gain=(1-python['aggregates']['all']['geomean_ratios']['candidate_over_control'])*100
body=f'''# Native ASCII Text plan

The combined Text plan reduces normal native elapsed time by **{native_gain:.2f}%** and CPython time by **{py_gain:.2f}%** against the published fused attribute scanner. The measured source matches all 74 files committed at `{COMMIT}`. It remains experimental: native and Python aggregates are **1.4799×** and **1.1906× Expat**, above the roughly 1.10× goal. Current-source sustained fuzzing and an installed PBS trial are still outstanding.

## Implementation and source identity

A transient plan uses eight-byte integer classification (SWAR, not a claim of SIMD vector instructions) to find an eligible root native UTF-8 text boundary, prove ASCII XML validity and record an eager line/column delta. TAB, LF and DEL are accepted. CR, `]`, non-ASCII, invalid controls and ambiguous long spans use the unchanged fallback. Delimiters at the 65,536-byte cutoff retain the original precedence. Raw ownership, event publication, fallible accounting and source compaction keep their existing order; no persistent parser fields, unsafe code, allocator changes or dependencies are added.

Only `encoding.rs`, `lib.rs`, new `text.rs` and `text_coalescing.rs` change from parent `168b5f57`; published fused `tag.rs` stays byte-identical. [committed-source.json](committed-source.json) binds the measured precommit map to the later runtime commit, without claiming a rebuild after commit. Independent source reviews cover cutoff/fallback behavior, prior-CR handling, publication before late accounting errors, compaction and split-feed equivalence.

## Normal measurements

| Campaign | Candidate / control | Candidate / Expat | Favorable conditions |
| --- | ---: | ---: | ---: |
| Combined native, real XML | 0.981292× | 1.479945× | 20 / 24 |
| Combined native, generated | 0.973496× | 3.958944× | 2 / 4 |
| Combined CPython, all | 0.978588× | 1.190554× | 24 / 24 |
| Combined ElementTree | 0.973843× | 1.250605× | 12 / 12 |
| Combined pyexpat events | 0.983355× | 1.133386× | 12 / 12 |
| Isolated Text native, real XML | 0.983090× | 1.513906× | 22 / 24 |
| Isolated Text native, generated | 0.970045× | 3.911943× | 3 / 4 |

The isolated experiment used publication `4815cf78` / library `a240099f` as its control and kept the original attribute scanner. Its native campaign is retained separately; isolated Python was not run. The combined experiment uses the published fused control `dca62e60`. Cross-campaign ratios are not paired measurements and gains should not be added.

Combined real-input regressions are DocBook 4 KiB namespaces off **+3.29%**, DocBook 4 KiB namespaces on **+2.83%**, DocBook 64 KiB namespaces off **+1.68%**, and Batik 64 KiB namespaces on **+0.24%**. Generated rare declarations regress **+1.95%** at 4 KiB and **+0.70%** at 64 KiB. Both generated entity conditions improve, so the generated aggregate improves while remaining much slower than Expat. All six adverse combined rows, every favorable row and all three isolated adverse rows are retained in CSV and raw records.

The README sample uses 4 KiB feeds and namespaces off:

{text}
Times are medians of seven process medians; displayed ratios are medians of seven paired process ratios. Ratios need not equal division of the displayed times. Full aggregates are equally weighted geometric means of condition ratios.

The same shared Linux AMD EPYC-Milan host and normal generic release recipe are used: local Ohm rustc 1.98.1-dev (ohm-1.98.1-1), `-Zohm-defaults=no`, O3/ThinLTO/one codegen unit; Expat 2.8.4 uses GCC 13.3 O3 without LTO. CPython 3.12.13 extension modules use the unchanged O2 recipe and unmodified sources. Four control/Expat modules are reused with their original bytes/vectors/origins pinned; two candidate modules are freshly built. Every engine gets fresh preflights and timed workers.

Native preserves 28 conditions, seven seeded pairs, 84 preflights and 588 timed workers: 672 workers / 106,176 samples per campaign. Python preserves 24 conditions, seven seeded cohorts, 72 preflights and 504 timed workers: 576 workers / 26,364 samples. Combined totals are 1,248 workers / 132,540 samples; the isolated native campaign adds 672 / 106,176. The faithful C driver times full parser lifecycle. Python times construction/feed/finalization/callbacks and explicit destruction, with imports, input reads, canonical checks and gc.collect outside; automatic GC stays enabled. All original timeout/reap rules, input hashes and measurement boundaries remain recorded.

## Compatibility and limits

All **449 workspace tests** across 35 groups, formatting and strict Clippy pass. Original **4,740 API configurations** remain byte-for-byte unchanged: **4,347 pass / 391 assertion failures / two timeouts**, raw matrix exit 1. The same original resource limits and assertions apply. Six dynamic/static C integration, adversarial and allocation consumers pass under C ASan/UBSan; the normal Rust libraries are uninstrumented and leak detection is disabled.

Each strict CPython linkage retains **802 method outcomes and 809 rendered outcome lines**, raw exit 2, including `BufferTextTest.test1` and `CDATAHandlerTest.test_handlers`. These strict consumers contain the explicit pinned upstream pyexpat allocation-failure cleanup backport, unlike the unmodified benchmark consumers. Two existing supplemental text-semantic tests pass per linkage; these do not turn strict failures green. Historical diagnostics that relax allocation schedules and prior sustained sanitizer/PBS evidence retain their older source identities and do not certify this runtime.

## Preparation history and review

The packet preserves the pre-format Text source and the one test-formatting change; an independent source-pin read encountered that formatting before the new manifest was available. The isolated build reader initially retained a stale fused target-directory path, then passed after that reader-only correction; actual libraries were unchanged. The combined correctness materializer initially relocated an old top-level author-script filename pin, then passed after preserving the original path. The Python preparation reviewer corrected a cached-versus-physical CPython source-path spelling. These were saved-data/preparation issues, not parser test failures; first records remain available. No target result was discarded or rerun to remove a regression.

The Text author prepared source/controllers and this packet. Root executed targets and the adapted saved readers. Other agents independently reviewed source/protocols and replayed all combined raw workers; final packet/README review is separate. Every stage preserves its original pending labels alongside later completion records. No current-source Callgrind profile, sustained fuzz campaign or installed PBS outcome is claimed.
'''
(P/'report-README.md').write_text(body)
print(json.dumps({'draft':str(D),'report_sha256':sha(P/'report.json'),'committed_source_sha256':sha(P/'committed-source.json'),'table':table,'adverse_count':len(adverse)}))
