# Native ASCII Text plan: focused equivalence obligations

Source-only preparation against4815cf7. No targets executed and no candidate edited. Keep the new plan ephemeral and side-effect-free until existing `consume` succeeds; raw ownership, callback storage, allocations and counters stay unchanged.

## Boundaries and fallback

| Case | Required behavior |
| --- | --- |
| Ordinary ASCII, spaces, quotes, `>` and DEL (`0x7f`) | Valid XML text; do not reject DEL merely because it is nonprinting. |
| TAB/LF | Valid; each TAB advances one character column, not a tab stop. |
| CR, any `]`, non-ASCII, or other C0 control before markup | Return fallback with no state mutation; old path owns CR normalization, forbidden `]]>` and malformed-prefix behavior. |
| Special byte after first `<` or `&` | Irrelevant to the current text span; do not reject or scan beyond the chosen delimiter solely to classify the suffix. |
| Empty/markup at offset0 | No text progress/publication. Empty plan must not clear prior CR state. |
| Markup at offsets65,534/65,535/65,536 | `coalesced_text_end` searches65,537 bytes, so the delimiter wins even when an earlier newline could otherwise create a cutoff. |
| No delimiter within65,537 bytes; delimiter at65,537 or later | Fall back unless all existing long-span logic is reproduced. A long original single line can exceed64KiB, while merged short lines stop at the earlier complete-line boundary. Do not truncate all text at64KiB. |
| Full ASCII suffix of length65,536 or less | The old path can consume the complete visible text even on nonfinal input; there is no trailing CR/`]` ambiguity in the proved span. |

Use lengths0/1/7/8/9/23/24/127/128/129/4095/4096/4097/65,535/65,536/65,537 and both `<` and `&` terminators. Place LF at0, one byte before the delimiter, and just before/at/after the cutoff. Insert every ASCII byte at word boundaries for the classifier, plus representative multibyte UTF-8. Compare to the old helpers, not a second copy of the proposed mask logic.

## Position arithmetic and Source mutation

`Source::position(count)` is the **start** line/column plus raw byte count; it does not advance coordinates. A plan may predict post-consume state but must not overwrite the event's start position.

For a positive ASCII span without CR, count LF and record bytes after the last LF. The line delta is LF count minus1 only when the first byte is LF and incoming `previous_cr` is true. After any positive eligible span, `previous_cr` becomes false. With no LF, column increments by the byte count; with LF, column becomes the trailing ASCII count. Test starting columns0/7, lines1/9, and previous_cr false/true with `""`, `"a"`, `"\n"`, `"\na"`, `"a\n"`, `"\n\n"`, `" \n"`, `"\t\na"`. Incoming previous_cr must not suppress a later LF after an intervening ordinary byte.

`Source::consume` must still perform native raw-index advancement, cursor advancement, scan reset, deferred_size reset, and the exact compaction condition `cursor >= 64*1024 && cursor >= text.len()/2`. Replace only coordinate recomputation. Test both sides of each compaction threshold with unread tails, repeated consume calls and resumed feeds. Do not cache an index across a buffer mutation or reuse a plan for a different source/start/count. Native UTF-8/no-anchor qualification is essential: converted encodings count original bytes differently and entity sources use the reference anchor.

## Error/publication order

Ordinary Text does payload preparation → `save_current_raw` → declaration state update → event/frame publication → `consume`. `consume` accounts source bytes **before mutating Source coordinates**. Therefore a non-OOM accounting failure can still expose the prepared valid Text prefix; `next_event_scoped` preserves it and reports the error on the next request (core context_text_tests.rs:4). A planned fast consume must not move accounting earlier, mutate coordinates when accounting fails, or publish a new position prematurely.

Allocation failures during payload/raw preparation leave the frame inactive and previous raw token intact (C context_text_tests.rs:362). Raw copying/reservations are unchanged for this candidate, so current request sequences should remain comparable. CDATA has different publication timing and must not accidentally use this ordinary-Text path; adapter_frame.rs:623 explicitly distinguishes them.

Fallback examples must preserve exact prefixes and errors: `a\nbad]]>`, `a\nbad\x01]]>`, `a\r\nbad]]>\x01`, a70,000-byte malformed line after an earlier LF, and split trailing `]`, `]]`, CR and UTF-8 sequences. Do not return a successful shortened plan merely because the first special byte appears later: the old path may reject the whole line or emit only its previous complete-line prefix.

## Context and parser eligibility

Preserve `prepare_character_data` conditions independently of ASCII proof: max4096 frame bytes; no conversions; no root CR normalization; native C Text additionally requires a nonempty root UTF-8 source, one source, nonfragment/nonexternal-subset. A proof of ASCII does not make CDATA, external children or internal entity anchors into host-input ranges. Keep foreign recycling-token fallback, ordinary owned event API and mixed normal/native adapter calls exact.

The simplest first plan should run only in ordinary element content/coalescing with a native root source. Prolog/epilog whitespace and quoted prolog literals retain their specialized error/token paths. Never bypass pending decoding errors, source converted-text windows, root/closed-root validation, amplification or maximum token policies.

Existing anchor suites: `tests/text_coalescing.rs` (raw spans, malformed complete prefixes,65KiB boundaries, converted windows), `tests/positions.rs` (all encoding/feed splits and compaction), core/C `context_text_tests.rs` (raw/payload OOM and late callbacks), and `tests/adapter_frame.rs` (publication/accounting). Add a focused helper equivalence test and a few exact end-to-end traces, not a duplicate exhaustive framework. Candidate review remains pending source readiness.
