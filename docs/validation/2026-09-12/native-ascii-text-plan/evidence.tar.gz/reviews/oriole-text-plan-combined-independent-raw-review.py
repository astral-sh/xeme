"""Saved-only assertion replay; existing readers stop before any output mutation."""
from pathlib import Path
import ast, hashlib, io, json, math, os, subprocess, tarfile
assert os.sched_getaffinity(0)=={6}
B=Path('/tmp/oriole-text-plan-combined-study')
W=Path('/home/dev-user/code/oss/oriole-text-plan-combined')
H=lambda b:hashlib.sha256(b).hexdigest()
J=lambda p:json.loads(Path(p).read_text())
pins={}
def load(p):
 p=Path(p);raw=p.read_bytes();pins[str(p)]=H(raw);return json.loads(raw)
def replay(path, expected, marker):
 text=path.read_text();assert H(path.read_bytes())==expected
 tree=ast.parse(text,filename=str(path));cut=next(i for i,n in enumerate(tree.body) if marker(text.splitlines()[n.lineno-1]))
 scope={'__file__':str(path),'__name__':'independent_saved_assertion_replay'}
 exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),str(path),'exec'),scope)
 return scope
n=replay(B/'native/read_results.py','3cb077f3babcfe3b13f58bb682c7111608e0dd88c3cbf9e862c603e6f8a8a1c7',lambda s:s.startswith('with (OUT /'))
nr=load(B/'native/review.json');assert nr['counts']==n['counts'] and nr['groups']==n['groups'] and nr['all_conditions']==n['summary']
for path,expected in n['pins'].items():assert H(Path(path).read_bytes())==expected,path
p=replay(B/'python/elapsed_review.py','fe6025794c98fde886ae299939979f60071516914c8c871b8b3fc4dce5b5c785',lambda s:s.startswith('csvpath='))
pr=load(B/'python/normal-review.json')
for key in ['counts','aggregates','summary','libraries','source_results_sha256','source_preflight_sha256']:assert pr[key]==p['report'][key],key
source=load(B/'source.json');assert len(source['sha256'])==74
commit='ea52004a6590a224bfc0ec96c8e80a3159920db5';base='168b5f57ad5300a74eb77769ccad83e513ebe5c8'
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip()==commit
assert subprocess.check_output(['git','-C',str(W),'rev-parse',commit+'^'],text=True).strip()==base
expected_delta=['crates/oriole/src/encoding.rs','crates/oriole/src/lib.rs','crates/oriole/src/text.rs','crates/oriole/tests/text_coalescing.rs']
assert subprocess.check_output(['git','-C',str(W),'diff',base,commit,'--name-only'],text=True).splitlines()==expected_delta
archive=subprocess.check_output(['git','-C',str(W),'archive',commit,'--',*source['sha256']])
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:') as tar:
 members={m.name:H(tar.extractfile(m).read()) for m in tar if m.isfile()}
assert members==source['sha256']
for name,expected in members.items():assert H((W/name).read_bytes())==expected,name
api=load('/tmp/oriole-text-plan-combined-correctness/api-c-readback.json');strict=load('/tmp/oriole-text-plan-combined-correctness/strict-semantic-readback.json')
for d in [api,strict]:
 for path,expected in d['inputs'].items():assert H(Path(path).read_bytes())==expected,path
adverse=[r for r in n['summary'] if r['median_ratios']['candidate_over_control']>1];assert len(adverse)==6
out={'status':'passed_saved_assertion_replay_and_committed_source','role':'Independent runtime/final-evidence reviewer; no Text runtime/test authorship. Existing preparer-authored readers replayed only through assertion/arithmetic blocks and never through their output writes. No target executions or repository mutations.','commit':commit,'parent':base,'source_files':74,'source_sha256':members,'native_counts':nr['counts'],'python_counts':pr['counts'],'native_groups':nr['groups'],'python_aggregates':pr['aggregates'],'native_adverse_conditions':adverse,'readers':{str(B/'native/read_results.py'):H((B/'native/read_results.py').read_bytes()),str(B/'python/elapsed_review.py'):H((B/'python/elapsed_review.py').read_bytes())},'readback_inputs_rehashed':len(n['pins'])+len(p['pins'])+len(api['inputs'])+len(strict['inputs']),'pins':pins,'findings':[]}
dest=Path('/tmp/oriole-text-plan-combined-independent-raw-review.json');dest.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'receipt':str(dest),'sha256':H(dest.read_bytes()),'workers':nr['counts']['all_workers']+pr['counts']['all_workers'],'samples':nr['counts']['all_samples']+pr['counts']['all_samples'],'source_files':74,'native_real':nr['groups']['real']['geomean_ratios'],'python_all':pr['aggregates']['all']['geomean_ratios'],'native_adverse':[{'condition':r['condition'],'ratio':r['median_ratios']['candidate_over_control']} for r in adverse]},indent=2))
