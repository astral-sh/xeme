"""Relocate the completed normal native protocol; saved files only, no targets."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
D = Path('/tmp/oriole-text-plan-study/native')
P = Path('/tmp/oriole-fused-normal-current-study/native')
C = Path('/tmp/oriole-expanded-start-capacity-study')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
def save(p, value):
    with p.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

binding = load(D.parent / 'build-binding.json')
build = load(D.parent / 'build.json')
source = load(D.parent / 'source.json')
control_source = load(C / 'source.json')
assert binding['status'] == build['status'] == 'passed'
assert binding['source_count'] == len(source['sha256']) == 74
assert binding['base'] == source['base'] == '4815cf78d7419a18df8d698aaae0bbde8daa526f'
assert binding['build_sha256'] == sha(D.parent / 'build.json')
assert binding['source_manifest_sha256'] == sha(D.parent / 'source.json')
assert binding['control_source_manifest_sha256'] == sha(C / 'source.json')
delta = {name: {'control': control_source['sha256'].get(name), 'candidate': value}
         for name, value in source['sha256'].items() if value != control_source['sha256'].get(name)}
assert delta == binding['source_delta']
assert set(delta) == {'crates/oriole/src/encoding.rs', 'crates/oriole/src/lib.rs',
                      'crates/oriole/src/text.rs', 'crates/oriole/tests/text_coalescing.rs'}
assert source['sha256']['crates/oriole/src/tag.rs'] == control_source['sha256']['crates/oriole/src/tag.rs']
for name, value in source['sha256'].items():
    assert sha(Path(source['worktree']) / name) == value
D.mkdir(exist_ok=False)

changes = [('/tmp/oriole-fused-normal-current-study', '/tmp/oriole-text-plan-study'),
           ('current-source fused attribute scan', 'isolated native ASCII Text plan on publication4815'),
           ('selected expanded Start capacity baseline', 'publication4815 expanded Start capacity control')]
original = (P / 'native_screen.py').read_text()
screen = original
for before, after in changes:
    assert before in screen
    screen = screen.replace(before, after)
restored = screen
for before, after in reversed(changes):
    restored = restored.replace(after, before)
assert restored == original and ast.dump(ast.parse(restored)) == ast.dump(ast.parse(original))
marker = 'def run(condition, engine, pair, cpu, count):'
assert screen[screen.index(marker):] == original[original.index(marker):]
(D / 'native_screen.py').write_text(screen)
(D / 'run.py').write_bytes((P / 'run.py').read_bytes())
(D / 'native_screen.py.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True), screen.splitlines(True), fromfile=str(P / 'native_screen.py'), tofile=str(D / 'native_screen.py'))))

prior = load(P / 'adaptation.json')
a = {k: prior[k] for k in ('mode', 'external_input_hashes', 'conditions', 'pairs', 'seed', 'counts')}
a.update(status='passed', execution_status='unexecuted', origin=str(P),
         parent_files={n: sha(P / n) for n in ('run.py', 'native_screen.py')},
         files={n: sha(D / n) for n in ('run.py', 'native_screen.py')},
         changes={'run.py': [], 'native_screen.py': changes}, inverse_text_and_ast_equal=True,
         libraries={'candidate': {'path': str(D.parent / 'normal/liboriole_expat.so'), 'sha256': binding['candidate_libraries']['liboriole_expat.so']},
                    'control': prior['libraries']['control'], 'expat': prior['libraries']['expat']},
         selected_normal_protocol={'path': str(P / 'native-screen/protocol.json'), 'sha256': sha(P / 'native-screen/protocol.json')},
         candidate_source=source['worktree'], source_delta=delta,
         source_scope='Isolated Text plan:74 files, four changed including new text.rs. tag.rs stays publication4815 bytes; no fused attribute-scanner composition.',
         comparison_scope='Text plan on publication4815 versus a240 normal publication4815 control and unchanged normal Expat7a333. Later selected09da is not a control or measured component.',
         scope='Normal generic builds only; original28conditions,7pairs,seed,worker iterations,driver,callbacks,measurement boundaries and timeout cleanup unchanged. No outputs executed during preparation.',
         binding_review=str(D.parent / 'build-binding.json'))
for key, name in [('candidate_source_record', 'source.json'), ('candidate_build_record', 'build.json')]:
    a[key] = {'path': str(D.parent / name), 'sha256': sha(D.parent / name)}
for entry in a['libraries'].values():
    assert sha(entry['path']) == entry['sha256']
for path, value in a['external_input_hashes'].items():
    assert sha(path) == value
assert a['libraries']['control']['sha256'] == binding['control_libraries']['liboriole_expat.so']
assert a['conditions'] == load(a['selected_normal_protocol']['path'])['conditions']
save(D / 'adaptation.json', a)

reader_original = (P / 'read_results.py').read_text()
reader = reader_original
reader_changes = [('/tmp/oriole-fused-normal-current-study', '/tmp/oriole-text-plan-study'),
                  ('dca62e60f80e311fbb529e66262fd2f7f07d8f38eda16c97cd33aa9dd8063488', binding['candidate_libraries']['liboriole_expat.so']),
                  ("len(source['sha256']) == 73", "len(source['sha256']) == 74"),
                  ("binding['source_count'] == 73 and set(binding['source_delta']) == {'crates/oriole/src/tag.rs'}", "binding['source_count'] == 74 and set(binding['source_delta']) == {'crates/oriole/src/encoding.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/text.rs', 'crates/oriole/tests/text_coalescing.rs'}"),
                  ('30cb2ebf46a4de374714c4a4033635e80e5fb330e27802d5af9e3ba23ff34743', source['sha256']['crates/oriole/src/lib.rs']),
                  ('Reuse the completed current capacity reader with study/base/library/source-binding substitutions and reporting scope only.', 'Reuse the completed current normal reader for isolated Text plan versus publication4815, with study/library/source-binding substitutions only.'),
                  ('Only native completed results were read; Python elapsed was owned by root and not inspected.', 'Only native completed results were read; no Python or combined09da Text-plan result is implied.')]
for before, after in reader_changes:
    assert before in reader
    reader = reader.replace(before, after)
restored_reader = reader
for before, after in reversed(reader_changes):
    restored_reader = restored_reader.replace(after, before)
assert restored_reader == reader_original
ast.parse(reader)
(D / 'read_results.py').write_text(reader)
(D / 'read_results.py.patch').write_text(''.join(difflib.unified_diff(reader_original.splitlines(True), reader.splitlines(True), fromfile=str(P / 'read_results.py'), tofile=str(D / 'read_results.py'))))

python = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12'
readme = '''# Isolated Text plan: normal native preparation

Prepared only. The Text-plan candidate uses publication4815 with its original tag.rs, normal library2846695f. Its control is publication4815 expanded Start capacity, normal librarya240099f. Expat is unchanged normal7a333bc8. The later selected09da fused attribute scanner is absent from this experiment. All parser binaries already exist; this preparation rebuilds none.

The completed normal protocol is retained: all24 real conditions and4 generated controls,4/64KiB feeds,7 seeded pairs2026091003, original iterations and engine shuffle. There are84 preflight workers and588 timed workers,672 total, with106176 samples including warmups. Each measured sample includes parser creation, handlers, feed/finalization, callbacks and destruction. The same faithful C driver uses explicit dlopen of the recorded library path; raw callback digests merge text fragments. No new dladdr or exact-fragmentation claim is made.

run.py is byte-identical. native_screen.py changes only paths and captions; its worker, schedule, measurement and timeout code is byte-identical. The saved reader changes source/library bindings and labels only, retaining every raw worker, median, ratio and adverse condition. Its preparation receipt remains historical; later execution needs completed controller and raw records.

Root holds execution. Pin PATH so child python3 resolves to the same CPython3.12.13 interpreter:

```sh
env PATH=/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin:/usr/bin:/bin /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-text-plan-study/native/run.py
taskset -c6 /home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3.12 -I -S /tmp/oriole-text-plan-study/native/read_results.py
```

Preflight runs onCPU5 with600s bound, then timing on exclusiveCPU0 with1200s bound; each worker retains90s. Existing wrapper timeout/interruption kills and waits for its process group. Output is single-use; saved reader runs onCPU6. All target execution remains with root. No PGO, profile or CPU-target experiment is introduced.

The saved build binder retained its first failed attempt: one stale fused target-directory path was corrected; actual Text-plan target and copied libraries agree. Source and build artifacts were unchanged. All five original command receipts passed and were reaped; exact test count is in build-binding.json.
'''
(D / 'README.md').write_text(readme)
pins = {str(p): sha(p) for p in sorted(D.iterdir()) if p.is_file()}
for p in [Path(__file__), Path('/tmp/oriole-text-plan-bind.py'), D.parent / 'build.json', D.parent / 'source.json', D.parent / 'build-binding.json', D.parent / 'candidate.patch', C / 'build.json', C / 'source.json', C / 'build-binding.json', P / 'adaptation.json', P / 'run.py', P / 'native_screen.py', P / 'read_results.py', Path('/home/dev-user/code/oss/oriole/benchmarks/native_driver.c'), Path(python)]:
    pins[str(p)] = sha(p)
result = {'status': 'prepared_no_targets', 'targets_executed': False, 'pins': pins, 'source_delta': delta,
          'run_unchanged': True, 'native_worker_and_all_measurement_code_unchanged': True,
          'reader_changes': reader_changes, 'reader_inverse_text_equal': True, 'counts': a['counts'],
          'release_command_held': ['env', 'PATH=' + str(Path(python).parent) + ':/usr/bin:/bin', python, '-I', '-S', str(D / 'run.py')],
          'saved_reader_command': ['taskset', '-c', '6', python, '-I', '-S', str(D / 'read_results.py')]}
save(D / 'preparation.json', result)
print(json.dumps({'status': result['status'], 'preparation_sha256': sha(D / 'preparation.json'), 'controller_sha256': sha(D / 'native_screen.py'), 'reader_sha256': sha(D / 'read_results.py'), 'counts': a['counts']}))
