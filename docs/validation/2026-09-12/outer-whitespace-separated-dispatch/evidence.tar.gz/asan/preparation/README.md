# Held candidate Rust-ASan replay

Candidate runtime6320d7b75a660866cb701cf2f50a1ec61084fbf5 / normal ce0a648c, based on selected PR16287acc. The normal466/35 build and exact74+4 current source are bound, including254 unchanged fuzz source/seed files. The four-file candidate remains unselected; current-source sanitizer fuzzing has not run. Selected buffered-delivery-current-asan-preparation is unchanged and held separately. Root chooses the source to validate after Python/full compatibility evidence, avoiding duplicate campaigns.

Runner3f200753 is byte-exact. Only five paths, scope and actual release values changed in the manifest. Six unchanged harnesses retain69,196 planned distinct inputs, replay180s per harness and exploration600s each with690s outer bounds. Build1200s, overall3600s, seed20260912, max64KiB/input10s/RSS1536MiB, three CPU lanes, instrumentation, environment and process-group cleanup remain unchanged. The 8GiB/150,000-inode guard runs again at launch; no disk reservation is implied. No PGO or compiler sweep.

No individual corpus input or archive was copied/read during this preparation. Corpus/tool pins are inherited and verified by the runner on execution. Historical corpus results are seed provenance only. Literal/streaming derived seeds and their cache-* names do not prove branch coverage. detect_leaks=0 remains inherited; system libraries are not instrumented, and ffi payload-discarding callbacks do not replace projection/lifetime tests.

Actual source/build/library fields are filled, release.status remains held. After root decides to validate this candidate, preserve the held manifest, set only release.status=released and hash that manifest. Root-only command:

```sh
taskset -c 6 python3 /tmp/oriole-outer-whitespace-separated-dispatch-asan-preparation/run.py \
  --manifest /tmp/oriole-outer-whitespace-separated-dispatch-asan-preparation/command-manifest.json \
  --sha256 ROOT_RELEASED_MANIFEST_SHA256
```

Fresh output /tmp/oriole-outer-whitespace-separated-dispatch-asan-study and target /home/dev-user/.cache/oriole/outer-whitespace-separated-dispatch-asan-target. No runner, compiler, fuzzer, replay or corpus copy executed here. Root schedules outside elapsed benchmarks; affinity is not host isolation.
