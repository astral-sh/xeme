# Held outer API supervisor

Runs one explicit unchanged controller, captures its stdout/stderr/raw exit, then kills and reaps any adopted descendants. The subreaper setup and 10-second descendant helper are byte-identical to the reviewed and fake-process-tested targeted controller. This new wrapper has only source/AST checks; no children were launched.

Root reviews and releases execution. Example (choose CPU 3, 4 or 6, and a new absolute output directory):

```sh
taskset -c 3 python3 -I -S /tmp/oriole-api-supervisor-preparation/run.py \
  --cpu 3 --output /tmp/CHOSEN-NEW-OUTPUT --timeout 1800 \
  -- python3 -I -S /absolute/path/to/unchanged-controller.py ARGUMENTS
```

The child inherits the caller's environment and working directory. Its argv is passed directly, without a shell. The inner controller retains responsibility for source/library guards, its own environment settings and semantic outcome checks.

`receipt.json` preserves the signed child `raw_exit` and every adopted PID/wait status. Normal exit 1 remains 1; it is not relabeled as a failure or success. A signalled child's raw negative exit is preserved and the supervisor uses the conventional 128+signal exit. Timeout exits 124, cancellation 128+signal, and supervision errors 125. Inspect the receipt to distinguish them. Cleanup can add up to 10 seconds for wrapper wait and 10 seconds for adopted descendants; output flush/hash/write is additional I/O.

The output directory must not exist. Existing files are never replaced. Repeated SIGTERM/SIGINT are ignored only during cleanup and the final receipt write. No guarantee is made for SIGKILL, unkillable kernel tasks, I/O failure, or descendants that deliberately evade this standalone process tree. Use one supervisor per controller, with no unrelated children.
