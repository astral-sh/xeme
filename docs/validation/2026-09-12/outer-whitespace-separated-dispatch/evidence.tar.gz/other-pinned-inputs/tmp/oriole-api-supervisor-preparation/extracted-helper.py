def reap_descendants(receipt):
    """Kill and reap adopted generations, including detached process sessions."""
    deadline = time.monotonic() + 10
    children_file = Path(f'/proc/self/task/{os.getpid()}/children')
    receipt.update(status='incomplete', signalled=[], reaped=[])
    while time.monotonic() < deadline:
        for pid in map(int, children_file.read_text().split()):
            try:
                os.kill(pid, signal.SIGKILL)
                receipt['signalled'].append(pid)
            except ProcessLookupError:
                pass
        no_children = False
        while True:
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                no_children = True
                break
            if pid == 0:
                break
            receipt['reaped'].append({'pid': pid, 'wait_status': status})
        if no_children and not children_file.read_text().strip():
            receipt['status'] = 'completed'
            return
        time.sleep(0.01)
    receipt['status'] = 'cleanup_timeout'
    raise RuntimeError('Owned descendants were not fully reaped within 10 seconds')
