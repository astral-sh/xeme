"""Run the two original 2 GiB API cases once per library, preserving raw exits."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

assert __debug__ and os.sched_getaffinity(0) == {3}
# Adopt the wrapper's detached harness if the wrapper exits or is cancelled.
libc = ctypes.CDLL(None, use_errno=True)
if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
    raise OSError(ctypes.get_errno(), 'PR_SET_CHILD_SUBREAPER')
parser = argparse.ArgumentParser()
parser.add_argument('--build-binding-sha', required=True)
args = parser.parse_args()
prep = Path(__file__).parent
study = Path('/tmp/oriole-outer-whitespace-plan-study')
output = Path('/tmp/oriole-outer-whitespace-plan-api-targeted')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


assert sha(prep / 'prepared.json') == '04551345b3be7a435da1a61672ddc38504380dd9874c77a882e41766d525c2ed'
prepared = read(prep / 'prepared.json')
assert sha(prep / 'commands.json') == prepared['commands_sha256']
for path, digest in prepared['pins'].items():
    assert sha(path) == digest, path
binding = read(study / 'build-binding.json')
assert sha(study / 'build-binding.json') == args.build_binding_sha
assert binding['status'] == 'passed'
assert binding['tests'] == {'passed': 466, 'groups': 35, 'failures': 0, 'ignored': 0}
assert binding['build_sha256'] == sha(study / 'build.json')
assert binding['source_manifest_sha256'] == sha(study / 'source.json')
source = read(study / 'source.json')
assert source['base'] == '87acc5a91ad3b29b04a9a902cd8bdeebed00529f'
for path, digest in {**source['sha256'], **binding['auxiliary_files']}.items():
    assert sha(Path(source['worktree']) / path) == digest, path
library = study / 'normal/liboriole_expat.so'
assert sha(library) == binding['candidate_libraries']['liboriole_expat.so']
commands = read(prep / 'commands.json')
assert not output.exists()
output.mkdir()
report = {
    'status': 'incomplete',
    'root_release': 'Run exactly the two original chunk-0 rows once per library after the ordinary candidate build passed.',
    'build_binding_sha256': args.build_binding_sha,
    'candidate_library_sha256': sha(library),
    'commands_sha256': sha(prep / 'commands.json'),
    'prepared_sha256': sha(prep / 'prepared.json'),
    'controller_sha256': sha(__file__),
    'commands': [],
    'scope': 'Two selected rows only. The existing 4740-row baseline remains unchanged.',
}


def save():
    (output / 'controller.json').write_text(json.dumps(report, indent=2) + '\n')


def interrupt(signum, frame):
    raise KeyboardInterrupt('SIGTERM')


def reap_descendants(receipt):
    """Kill and reap adopted generations, including detached process sessions."""
    deadline = time.monotonic() + 10
    children_file = Path(f'/proc/self/task/{os.getpid()}/children')
    receipt.update(status='incomplete', signalled=[], reaped=[])
    while time.monotonic() < deadline:
        for pid in map(int, children_file.read_text().split()):
            try:
                os.kill(pid, signal.SIGKILL)
                receipt['signalled'].append(pid)
            except ProcessLookupError:
                pass
        no_children = False
        while True:
            try:
                pid, status = os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                no_children = True
                break
            if pid == 0:
                break
            receipt['reaped'].append({'pid': pid, 'wait_status': status})
        if no_children and not children_file.read_text().strip():
            receipt['status'] = 'completed'
            return
        time.sleep(0.01)
    receipt['status'] = 'cleanup_timeout'
    raise RuntimeError('Owned descendants were not fully reaped within 10 seconds')


signal.signal(signal.SIGTERM, interrupt)
try:
    for step in commands['steps']:
        argv = [str(library) if arg == 'CANDIDATE_NORMAL_SO_ABSOLUTE_PATH' else arg for arg in step['argv']]
        env = os.environ.copy()
        for key in set(step['unset_environment']) | {'PYTHONPATH', 'PYTHONHOME', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS'}:
            env.pop(key, None)
        env['PATH'] = '/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin:/usr/bin:/bin'
        env.update(step['environment'])
        row = {'label': step['label'], 'argv': argv, 'environment': step['environment'], 'start': time.time(), 'outer_timed_out': False}
        report['commands'].append(row)
        save()
        stdout = output / step['stdout']
        stderr = output / step['stderr']
        with stdout.open('xb') as out, stderr.open('xb') as err:
            proc = subprocess.Popen(argv, env=env, stdout=out, stderr=err, start_new_session=True)
            row['pid'] = proc.pid
            try:
                row['exit'] = proc.wait(timeout=step['outer_timeout_seconds'])
            except subprocess.TimeoutExpired:
                row['outer_timed_out'] = True
            finally:
                handlers = {sig: signal.signal(sig, signal.SIG_IGN) for sig in (signal.SIGTERM, signal.SIGINT)}
                try:
                    if proc.poll() is None:
                        try:
                            os.killpg(proc.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                    row['exit'] = proc.wait(timeout=10)
                    row['descendant_cleanup'] = {}
                    reap_descendants(row['descendant_cleanup'])
                finally:
                    row.update(reaped=proc.poll() is not None, end=time.time())
                    out.flush()
                    err.flush()
                    row['stdout_sha256'] = sha(stdout)
                    row['stderr_sha256'] = sha(stderr)
                    (output / step['raw_exit']).write_text(json.dumps(row, indent=2) + '\n')
                    save()
                    for sig, handler in handlers.items():
                        signal.signal(sig, handler)
        print(json.dumps(row), flush=True)
        assert not row['outer_timed_out'] and row['exit'] in (0, 1), row
    report['status'] = 'completed_raw_capture'
finally:
    report['candidate_library_unchanged'] = sha(library) == report['candidate_library_sha256']
    report['selected_inputs_unchanged'] = all(sha(path) == digest for path, digest in prepared['pins'].items())
    save()
assert report['candidate_library_unchanged'] and report['selected_inputs_unchanged']
