"""Validate only saved two-row API artifacts; never load or execute a target."""
from pathlib import Path
import argparse, copy, hashlib, json, os, re

assert __debug__ and os.sched_getaffinity(0) == {6}
parser = argparse.ArgumentParser()
parser.add_argument('--build-binding-sha', required=True)
parser.add_argument('--controller-report-sha', required=True)
args = parser.parse_args()
assert all(re.fullmatch('[0-9a-f]{64}', x) for x in vars(args).values())
P = Path('/tmp/oriole-outer-whitespace-plan-api-preparation')
S = Path('/tmp/oriole-outer-whitespace-plan-study')
O = Path('/tmp/oriole-outer-whitespace-plan-api-targeted')
C = O / 'candidate'
OLD = Path('/tmp/oriole-buffered-delivery-correctness/api-native/upstream-api')
RECEIPT = Path('/tmp/oriole-outer-whitespace-plan-api-targeted-independent-review.json')
pins = {}

def sha(path):
    path = Path(path)
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    pins[str(path)] = value
    return value

def read(path):
    sha(path)
    return json.loads(Path(path).read_text())

recipe = read(Path(__file__).with_name('prepared.json'))
assert recipe['status'] == 'held_source_only' and sha(__file__) == recipe['reader_sha256']
for path, value in recipe['input_pins'].items(): assert sha(path) == value, path
prepared = read(P / 'prepared.json'); commands = read(P / 'commands.json')
assert sha(P / 'commands.json') == prepared['commands_sha256']
for path, value in prepared['pins'].items(): assert sha(path) == value, path
controller = read(O / 'controller.json')
assert sha(O / 'controller.json') == args.controller_report_sha
assert controller['controller_sha256'] == sha(P / 'run_targeted.py') == recipe['controller_sha256']
assert controller['prepared_sha256'] == sha(P / 'prepared.json')
assert controller['commands_sha256'] == sha(P / 'commands.json')
assert controller['status'] == 'completed_raw_capture'
assert controller['candidate_library_unchanged'] and controller['selected_inputs_unchanged']
assert controller['build_binding_sha256'] == args.build_binding_sha == sha(S / 'build-binding.json')
binding = read(S / 'build-binding.json'); build = read(S / 'build.json'); source = read(S / 'source.json')
assert binding['status'] == build['status'] == 'passed' and build['source_unchanged'] and build['auxiliary_unchanged']
assert binding['build_sha256'] == sha(S / 'build.json') and binding['source_manifest_sha256'] == sha(S / 'source.json')
assert binding['tests'] == {'passed': 466, 'groups': 35, 'failures': 0, 'ignored': 0}
assert source['base'] == '87acc5a91ad3b29b04a9a902cd8bdeebed00529f'
assert len(source['sha256']) == 74 and len(binding['auxiliary_files']) == 4
assert set(binding['source_delta']) == {'crates/oriole/src/text.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole_expat/src/tests.rs'}
for name, value in {**source['sha256'], **binding['auxiliary_files']}.items(): assert sha(Path(source['worktree']) / name) == value
library = S / 'normal/liboriole_expat.so'; selected_library = OLD / 'liboriole_expat.so'
candidate_sha = sha(library)
assert candidate_sha == controller['candidate_library_sha256'] == binding['candidate_libraries']['liboriole_expat.so']
assert candidate_sha == build['libraries']['liboriole_expat.so']
control_sha = sha(selected_library)
assert control_sha == '52202d064fa5fc02854e3a369791f644ddfe2f42ccef656ebba78e290f103821'
assert binding['control_libraries']['liboriole_expat.so'] == control_sha
rows = controller['commands']; assert len(rows) == len(commands['steps']) == 2
assert [r['label'] for r in rows] == ['selected-control-two-rows', 'candidate-two-rows']
assert rows[0]['end'] <= rows[1]['start']
for row, step in zip(rows, commands['steps']):
    assert row == read(O / step['raw_exit'])
    assert row['argv'] == [str(library) if token == 'CANDIDATE_NORMAL_SO_ABSOLUTE_PATH' else token for token in step['argv']]
    assert row['environment'] == step['environment']
    assert type(row['exit']) is int and row['exit'] in (0, 1)
    assert row['reaped'] and not row['outer_timed_out'] and row['pid'] > 0 and row['start'] <= row['end']
    assert row['stdout_sha256'] == sha(O / step['stdout']) and row['stderr_sha256'] == sha(O / step['stderr'])
    cleanup = row['descendant_cleanup']
    assert cleanup['status'] == 'completed' and set(cleanup) == {'status', 'signalled', 'reaped'}
    assert all(type(pid) is int and pid > 0 for pid in cleanup['signalled'])
    assert all(set(r) == {'pid', 'wait_status'} and r['pid'] > 0 and type(r['wait_status']) is int for r in cleanup['reaped'])
    assert len({r['pid'] for r in cleanup['reaped']}) == len(cleanup['reaped'])
    assert all(os.WIFEXITED(r['wait_status']) or os.WIFSIGNALED(r['wait_status']) for r in cleanup['reaped'])
assert [s['outer_timeout_seconds'] for s in commands['steps']] == [240, 300]
assert commands['steps'][0]['environment'] == {'ORIOLE_CHUNK_MASK': '1', 'ORIOLE_DEFERRAL_MASK': '3', 'ORIOLE_SELECTED_TESTS': 'test_misc_input_2gb', 'ORIOLE_TEST_TIMEOUT': '3', 'ORIOLE_MEMORY_MIB': '1024', 'ORIOLE_RSS_MIB': '768'}
assert commands['steps'][1]['environment'] == {'CC': 'cc'}
assert all(s['unset_environment'] == ['LD_PRELOAD', 'LD_LIBRARY_PATH', 'LD_AUDIT'] for s in commands['steps'])

# The manifest equality allowlist is exhaustive. Every other field must remain exact.
old_manifest = read(OLD / 'manifest.json'); manifest = read(C / 'manifest.json')
assert set(manifest) == set(old_manifest)
assert manifest['library_sha256'] == sha(C / 'liboriole_expat.so') == candidate_sha
assert manifest['binary_sha256'] == sha(C / 'runtests')
assert old_manifest['binary_sha256'] == prepared['selected_runner_sha256'] == sha(OLD / 'runtests')
assert manifest['selected_tests'] == ['test_misc_input_2gb'] and manifest['chunks'] == [0] and manifest['deferral'] == [0, 1]
normalized = copy.deepcopy(manifest)
normalized['compile_command'] = [token.replace(str(C), str(OLD)) for token in manifest['compile_command']]
assert normalized['compile_command'] == old_manifest['compile_command']
assert manifest['compile_command'][:4] == ['cc', '-O1', '-DXML_TESTING', '-D_GNU_SOURCE']
assert Path('/usr/bin/cc').resolve() == Path('/usr/bin/x86_64-linux-gnu-gcc-13')
assert sha('/usr/bin/cc') == prepared['pins']['/usr/bin/x86_64-linux-gnu-gcc-13']
for key in ['library_sha256', 'binary_sha256', 'selected_tests', 'chunks']:
    normalized[key] = old_manifest[key]
assert normalized == old_manifest
limits = {'per_test_seconds': 3, 'per_test_address_space_bytes': 1024**3, 'per_test_rss_limit_bytes': 768 * 1024**2, 'total_timeout_seconds': 240}
assert all(manifest[key] == value for key, value in limits.items())
assert {p.name for p in (C / 'adapted').iterdir()} == set(manifest['adapted_sources'])
for name, value in manifest['adapted_sources'].items():
    assert sha(C / 'adapted' / name) == sha(OLD / 'adapted' / name) == value
for name, value in manifest['upstream_include_sources'].items():
    assert sha(C / name) == sha(OLD / name) == value
tools = OLD.parent / 'tools'
for name, value in manifest['adapter_sources'].items(): assert sha(tools / name) == value
test_bodies = []
for path in [C / 'adapted/misc_tests.c', OLD / 'adapted/misc_tests.c', Path('/home/dev-user/.cache/oriole/upstream/expat-2.8.4/expat/tests/misc_tests.c')]:
    block = re.search(r'^START_TEST\(test_misc_input_2gb\).*?^END_TEST', path.read_text(), re.M | re.S)
    assert block is not None
    test_bodies.append(block.group())
assert len(set(test_bodies)) == 1
assert hashlib.sha256(test_bodies[0].encode()).hexdigest() == prepared['exact_original_test_body_sha256']
dynamic = (P / 'selected-runner-dynamic.stdout').read_text()
assert sha(P / 'selected-runner-dynamic.stdout') == prepared['static_capture']['stdout_sha256']
assert re.findall(r'\(NEEDED\).*?\[([^]]+)\]', dynamic) == prepared['selected_runner_needed']
assert prepared['selected_runner_needed'][0] == str(selected_library)

expected_keys = commands['expected_row_keys']
assert expected_keys == [{'context': 'chunksize=0 deferral=' + str(mode), 'test': 'test_misc_input_2gb'} for mode in [0, 1]]
def parse_rows(log_path, expected_library):
    sha(log_path)
    events, results, origins = [], [], []
    for line in log_path.read_text(errors='replace').splitlines():
        if line.startswith('ORIOLE_BEGIN'):
            fields = line.split('\t'); assert len(fields) == 3 and fields[0] == 'ORIOLE_BEGIN'
            events.append(('begin', fields[1], fields[2]))
        elif line.startswith('ORIOLE_RESULT'):
            fields = line.split('\t'); assert len(fields) == 5 and fields[0] == 'ORIOLE_RESULT'
            assert re.fullmatch(r'\d+', fields[4])
            result = dict(context=fields[1], test=fields[2], outcome=fields[3], code=int(fields[4]))
            assert result['outcome'] in {'pass', 'timeout', 'rss-limit', 'signal', 'fail'}
            if result['outcome'] == 'pass': assert result['code'] == 0
            elif result['outcome'] == 'timeout': assert result['code'] == 14
            elif result['outcome'] == 'rss-limit': assert result['code'] == 9
            else: assert result['code'] > 0
            results.append(result); events.append(('result', fields[1], fields[2]))
        elif line.startswith('ORIOLE_LIBRARY'):
            fields = line.split('\t'); assert len(fields) == 2 and fields[0] == 'ORIOLE_LIBRARY'
            assert Path(fields[1]).resolve() == expected_library.resolve()
            origins.append(fields[1])
    assert origins
    assert events == [(kind, key['context'], key['test']) for key in expected_keys for kind in ['begin', 'result']]
    assert [{k: row[k] for k in ['context', 'test']} for row in results] == expected_keys
    return {'rows': results, 'origins': origins, 'begin_count': 2, 'result_count': 2}

assert 'ORIOLE_' not in (O / 'control.stderr').read_text(errors='replace')
control = parse_rows(O / 'control.stdout', selected_library)
candidate = parse_rows(C / 'tests.log', C / 'liboriole_expat.so')
for parsed, row in zip([control, candidate], rows):
    assert row['exit'] == int(any(r['outcome'] != 'pass' for r in parsed['rows']))
results = read(C / 'results.json')
assert results['results'] == candidate['rows'] and results['returncode'] == rows[1]['exit']
assert results['selection_complete'] and results['library_origin_verified'] and not results['timed_out']
assert results['passed'] == sum(r['outcome'] == 'pass' for r in candidate['rows'])
assert results['failed'] == 2 - results['passed'] and results['excluded_internal_tests'] == manifest['excluded_internal_tests']
assert json.loads((O / 'candidate.stdout').read_text()) == {k: v for k, v in results.items() if k not in {'results', 'excluded_internal_tests'}}
sha(C / 'build.log')
baseline = read(OLD / 'results.json')
assert len(baseline['results']) == 4740 and baseline['passed'] == 4347 and baseline['failed'] == 393
assert sum(r['outcome'] == 'timeout' for r in baseline['results']) == 2
assert sum(r['outcome'] not in {'pass', 'timeout'} for r in baseline['results']) == 391
baseline_rows = [r for r in baseline['results'] if {'context': r['context'], 'test': r['test']} in expected_keys]
assert baseline_rows == prepared['selected_full_suite']['targeted_rows']
assert all(r['outcome'] == 'timeout' and r['code'] == 14 for r in baseline_rows)
# Rehash all selected evidence and source libraries after the readback as well.
for path, value in prepared['pins'].items(): assert sha(path) == value
assert sha(library) == sha(C / 'liboriole_expat.so') == candidate_sha and sha(selected_library) == control_sha
result = {
    'status': 'passed_independent_saved_targeted_api_readback', 'targets_executed': False,
    'scope': 'Only the two original chunk0/deferral0,1 rows per library. Outcomes are unconstrained and retained; full4740 baseline is separate and unchanged.',
    'controller_report_sha256': args.controller_report_sha, 'controller_sha256': controller['controller_sha256'],
    'build_binding_sha256': args.build_binding_sha, 'source_manifest_sha256': sha(S / 'source.json'),
    'candidate_library_sha256': candidate_sha, 'control_library_sha256': control_sha,
    'raw_commands': rows, 'control': control, 'candidate': candidate,
    'baseline_targeted_rows': baseline_rows, 'control_matches_prior_timeouts': control['rows'] == baseline_rows,
    'baseline_full_counts': {'rows': 4740, 'pass': 4347, 'fail': 391, 'timeout': 2},
    'candidate_summary': {k: results[k] for k in ['passed', 'failed', 'returncode', 'timed_out']},
    'original_limits': limits, 'compile_vector_path_only_normalization_exact': True,
    'manifest_allowlist': ['library_sha256', 'binary_sha256', 'compile_command output-root spelling', 'selected_tests', 'chunks'],
    'all_other_manifest_fields_exact': True, 'test_body_sha256': prepared['exact_original_test_body_sha256'],
    'limitations': ['Child alarm14 is separate from wrapper/controller timeout. Any candidate pass concerns these two rows only.', 'The source-pinned wrapper records its actual compile vector and output binary; no separate compiler process timing is emitted. Its original compile timeout is120s.', 'Cleanup receipts are saved controller observations; the reader does not execute process probes or replay cancellation.'],
    'pins_sha256': pins, 'reader_sha256': sha(__file__),
}
with RECEIPT.open('x') as stream: stream.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'control': control['rows'], 'candidate': candidate['rows'], 'receipt': str(RECEIPT), 'sha256': sha(RECEIPT)}, indent=2))
