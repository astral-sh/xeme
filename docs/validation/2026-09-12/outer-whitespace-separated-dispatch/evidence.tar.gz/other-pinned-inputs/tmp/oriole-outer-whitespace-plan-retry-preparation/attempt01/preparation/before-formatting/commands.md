# Root-only finite commands

The prospective worktree is not created by this preparation. In the selected buffered-delivery checkout, use the exact argv/environment in worktree-command.json:

```sh
CARGO_BUILD_BUILD_DIR='/home/dev-user/.cache/ohm/verified-build/{workspace-path-hash}' cargo +ohm worktree add -b charlie/codex-oriole-outer-whitespace-plan /home/dev-user/code/oss/oriole-outer-whitespace-plan 87acc5a91ad3b29b04a9a902cd8bdeebed00529f --target-dir /home/dev-user/.cache/oriole/outer-whitespace-plan-target
git -C /home/dev-user/code/oss/oriole-outer-whitespace-plan apply /tmp/oriole-outer-whitespace-plan-preparation/reviewed-source.patch
```

Root formats in the new worktree with its distinct target, shared build path and `cargo +ohm -Zohm-defaults=no fmt --all`, then supplies the actual source bytes. Preserve this unformatted preparation before refreezing the expected74 map, complete patch, composition and seals to reviewed formatting. The source binder intentionally rejects the current pending status. No actual source/build/library release values are assumed.

Once the formatted source seal is ready, create release.json from release-template.json with status `released_for_source_binding`. Run sequentially and reap each controller:

```sh
taskset -c 6 python3 -I -S /tmp/oriole-outer-whitespace-plan-preparation/bind_source.py 87acc5a91ad3b29b04a9a902cd8bdeebed00529f
taskset -c 4 python3 -I -S /tmp/oriole-outer-whitespace-plan-preparation/build.py
taskset -c 6 python3 -I -S /tmp/oriole-outer-whitespace-plan-preparation/bind_build.py
```

After all seven ordinary checks and actual library binding pass, create native-release.json from its template with status `released_for_native_preparation`, filling actual source-binding/prepared-source/study-source/build/build-binding hashes and candidate_libraries. Then:

```sh
taskset -c 6 python3 -I -S /tmp/oriole-outer-whitespace-plan-preparation/prepare_native.py
```

After root observes host state and reaps every other compiler/target, release the existing monitored native wrapper. Run saved readback after wrapper and monitor reap:

```sh
taskset -c 5 python3 -I -S /tmp/oriole-outer-whitespace-plan-study/native/run.py
taskset -c 6 python3 -I -S /tmp/oriole-outer-whitespace-plan-study/native/read_results.py
```

No command above ran during preparation. Downstream gates and retuning remain outside this preparation.
