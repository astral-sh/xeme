# Root-only finite commands

Root already created/applied/formatted this worktree at base87acc. Do not repeat those operations. Original commands remain in before-formatting/commands.md and worktree-command.json; the exact formatting lineage is in formatting-refreeze.json. The actual74+4 source map and four-file patch are now sealed.

Create release.json from release-template.json with status `released_for_source_binding`. Run sequentially and reap each controller:

```sh
taskset -c 6 python3 -I -S /tmp/oriole-outer-whitespace-plan-preparation/bind_source.py 87acc5a91ad3b29b04a9a902cd8bdeebed00529f
taskset -c 4 python3 -I -S /tmp/oriole-outer-whitespace-plan-preparation/build.py
taskset -c 6 python3 -I -S /tmp/oriole-outer-whitespace-plan-preparation/bind_build.py
```

After all seven ordinary checks and actual library binding pass, create native-release.json from its template with status `released_for_native_preparation`, filling actual source-binding/prepared-source/study-source/build/build-binding hashes and candidate_libraries. Then:

```sh
taskset -c 6 python3 -I -S /tmp/oriole-outer-whitespace-plan-preparation/prepare_native.py
```

After root observes host state and reaps every other compiler/target, release the existing monitored native wrapper. Run saved readback after wrapper and monitor reap:

```sh
taskset -c 5 python3 -I -S /tmp/oriole-outer-whitespace-plan-study/native/run.py
taskset -c 6 python3 -I -S /tmp/oriole-outer-whitespace-plan-study/native/read_results.py
```

No command above ran during preparation. Downstream gates and retuning remain outside this preparation.
