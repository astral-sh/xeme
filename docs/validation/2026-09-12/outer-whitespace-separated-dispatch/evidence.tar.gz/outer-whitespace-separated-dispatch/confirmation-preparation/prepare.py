"""Materialize held normal confirmation scripts from completed records; no targets."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
OLD = Path('/tmp/oriole-outer-whitespace-separated-dispatch-study')
NEW = Path('/tmp/oriole-outer-whitespace-separated-dispatch-confirmation')
assert not NEW.exists()
pins = {}

def read(path):
    path = Path(path)
    data = path.read_bytes()
    value = hashlib.sha256(data).hexdigest()
    assert str(path) not in pins or pins[str(path)] == value, path
    pins[str(path)] = value
    return data

def sha(path):
    read(path)
    return pins[str(Path(path))]

def load(path):
    return json.loads(read(path))

def check(mapping):
    for path, expected in mapping.items():
        assert sha(path) == expected, path

def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')

recipe = load('/tmp/oriole-outer-whitespace-separated-dispatch-confirmation-preparation/recipe.json')
assert recipe['status'] == 'held_recipe_only'
assert recipe['materialization_release'] == 'released_by_root_after_initial_python_audit'
for key in ('initial_python_primary_sha256', 'initial_python_independent_sha256'):
    digest = recipe[key]
    assert isinstance(digest, str) and len(digest) == 64 and all(c in '0123456789abcdef' for c in digest)
check(recipe['original_inputs_sha256'])
sha('/tmp/oriole-outer-whitespace-separated-dispatch-confirmation-preparation/PLAN.md')
sha(__file__)
native_review = load(OLD/'native/review.json')
python_review = load(OLD/'python/normal-review.json')
assert sha(OLD/'python/normal-review.json') == recipe['initial_python_primary_sha256']
independent_python_path = Path('/tmp/oriole-outer-whitespace-separated-dispatch-independent-python-review.json')
independent_python = load(independent_python_path)
assert sha(independent_python_path) == recipe['initial_python_independent_sha256']
assert independent_python['status'] == 'passed_independent_normal_python_raw_and_host_review'
assert independent_python['runtime_commit'] == recipe['candidate_runtime_commit']
assert independent_python['pins_sha256'][str(OLD/'python/normal-review.json')] == recipe['initial_python_primary_sha256']
assert independent_python['counts'] == python_review['counts']
assert native_review['status'] == 'passed_independent_saved_normal_native_reconstruction'
assert python_review['status'] == 'passed'
assert native_review['counts']['all_workers'] == 672 and native_review['counts']['all_samples'] == 106176
assert python_review['counts']['all_workers'] == 576 and python_review['counts']['all_samples'] == 26364
for path, key in [(OLD/'native/controller.json', 'commands'), (OLD/'python/time-controller.json', 'jobs')]:
    controller = load(path)
    assert controller['status'] == 'passed'
    assert all(row['exit'] == 0 and 'exception' not in row and row['end'] >= row['start'] for row in controller[key])
source = load(OLD/'source.json')
binding = load(OLD/'build-binding.json')
assert binding['status'] == 'passed' and binding['source_count'] == len(source['sha256']) == 74
assert source['base'] == recipe['prebuild_base'] == '87acc5a91ad3b29b04a9a902cd8bdeebed00529f'
assert set(binding['source_delta']) == {'crates/oriole/src/text.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole_expat/src/tests.rs'}
assert binding['candidate_libraries']['liboriole_expat.so'] == recipe['libraries']['candidate']['sha256']
assert binding['control_libraries']['liboriole_expat.so'] == recipe['libraries']['control']['sha256']
assert binding['source_manifest_sha256'] == sha(OLD/'source.json')
assert binding['build_sha256'] == sha(OLD/'build.json')
assert binding['prepared_source_sha256'] == sha('/tmp/oriole-outer-whitespace-separated-dispatch-preparation/source.json') == 'df9341bbd13f0fdee893de8278f34fb91f8de73481e1181a1e064f79dab3f79c'
assert binding['dependency_review_sha256'] == sha('/tmp/oriole-text-lane-masks-preparation/metadata-independent-review.json') == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
assert binding['complete_patch_sha256'] == sha(OLD/'candidate.patch')
assert sha(OLD/'build-binding.json') == recipe['build_binding_sha256']
assert binding['tests'] == recipe['expected_tests']
assert {name: source['sha256'][name] for name in binding['source_delta']} == recipe['candidate_changed_source_sha256']
assert native_review['reader_sha256'] == sha(OLD/'native/read_results.py') == recipe['native_primary_reader_sha256']

check({str(Path(source['worktree'])/name): value for name, value in binding['auxiliary_files'].items()})

check({str(Path(source['worktree'])/name): value for name, value in source['sha256'].items()})
for entry in recipe['libraries'].values():
    assert sha(entry['path']) == entry['sha256']
original_python = load(OLD/'python/adaptation.json')
assert original_python['libraries'] == recipe['libraries']
build = load(OLD/'python/consumers/build.json')
assert build['status'] == 'passed' and build['adaptations'] is None
assert build['source_sha256_before'] == build['source_sha256_after']
check(build['source_sha256_before'])
for engine, consumer in build['consumers'].items():
    check(consumer['files'])
    assert consumer['directory'] == original_python['consumer_directories'][engine]
    assert consumer['files'][consumer['library']] == recipe['libraries'][engine]['sha256']
    for module, command in zip(('pyexpat', '_elementtree'), consumer['commands'], strict=True):
        assert command['returncode'] == 0
        assert sha(Path(consumer['directory'])/(module+'-build.log')) == command['log_sha256']
protocol = load(OLD/'native/native-screen/protocol.json')
assert protocol['libraries'] == recipe['libraries']
check(protocol['hashes'])

# Build every transformed script in memory before creating any destination.
scripts = {}
changes = {}

def original_path(kind, name):
    return OLD/kind/name

def adapt(kind, name, replacements=()):
    original = read(original_path(kind, name)).decode()
    text = original
    for before, after in replacements:
        assert text.count(before) == 1, (kind, name, before)
        text = text.replace(before, after, 1)
    ast.parse(text)
    scripts[kind, name] = text
    changes[kind+'/'+name] = list(replacements)
    return text

adapt('native', 'run.py')
adapt('native', 'native_screen.py', [(f"root = Path('{OLD}/native')", f"root = Path('{NEW}/native')")])
adapt('native', 'read_results.py', [
    ("NATIVE = ROOT / 'native'", f"NATIVE = Path('{NEW}/native')"),
    ('One normal-release campaign on this host, without statistical-significance or whole-application claims.',
     'Separate normal confirmation campaign; original shared-host attempt retained. Parent records the observed shared-host window; no statistical-significance or whole-application claim.'),
])
adapt('python', 'python_worker.py')
adapt('python', 'consumer_screen.py')
old_run = read(OLD/'python/run.py').decode()
build_start = old_run.index("        ('build', 600,")
build_end = old_run.index("        ('preflight', 600,", build_start)
run_text = adapt('python', 'run.py', [
    ("(out / 'adaptation.json')", f"Path('{OLD}/python/adaptation.json')"),
    ("str(out / 'consumers/build.json')", repr(str(OLD/'python/consumers/build.json'))),
    (old_run[build_start:build_end], ''),
    ('Fresh extension compilation and canonical preflights on CPU3; separate elapsed study on leased CPU0.',
     'Six previously built O2 modules reused in original directories; zero compiles. Fresh canonical preflights on CPU3; separate confirmation elapsed study on leased CPU0.'),
])
assert "('build', 600," not in run_text

fresh_preflight = """
# Original D source/build provenance above remains historical. C is this fresh campaign.
confirmation=load(C/'preparation.json')
assert confirmation['status']=='prepared_no_targets' and confirmation['fresh_compiles']==0
check(confirmation['pins'])
fresh=load(C/'prepare-controller.json')
assert fresh['status']=='passed' and fresh['controller_sha256']==sha(C/'run.py') and len(fresh['jobs'])==1
job=fresh['jobs'][0]
assert job['label']=='preflight' and job['exit']==0 and job['timeout_seconds']==600 and 'exception' not in job and job['end']>=job['start']
assert job['command']==['taskset','-c','3',python,'-I','-S',str(C/'consumer_screen.py'),'--phase','prepare','--kind','python','--build',str(D/'consumers/build.json'),'--input','/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json','--output',str(S)]
assert sha(C/'preflight-controller.log')==job['log_sha256']
"""
adapt('python', 'preflight_review.py', [
    (f"D=Path('{OLD}/python');S=D/'screen';pins={{}}", f"D=Path('{OLD}/python');C=Path('{NEW}/python');S=C/'screen';pins={{}}"),
    ("prior=load('/tmp/oriole-reference-frame-python-study/normal/screen/preflight.json')", fresh_preflight+"\nprior=load('/tmp/oriole-reference-frame-python-study/normal/screen/preflight.json')"),
    ("str(D/'python_worker.py'),'--worker'", "str(C/'python_worker.py'),'--worker'"),
    ('Four original reused and two fresh compile vectors and fresh worker-reported module paths plus in-process dladdr parser DSO origins;',
     'Six historical O2 compile vectors and reused unchanged modules; zero confirmation compiles. Fresh worker-reported module paths plus in-process dladdr parser DSO origins;'),
    ("'extension_compiles':{'fresh':2,'reused':4,'total':6}", "'extension_compiles':{'fresh':0,'reused':6,'total':6}"),
    ("output=D/'preflight-review.json';output.write_text(json.dumps(result,indent=2)+'\\n')", "output=C/'preflight-review.json'\nwith output.open('x') as stream:stream.write(json.dumps(result,indent=2)+'\\n')"),
])
adapt('python', 'elapsed_review.py', [
    (f"D=Path('{OLD}/python');S=D/'screen';original=D", f"D=Path('{OLD}/python');C=Path('{NEW}/python');S=C/'screen';original=C"),
    ("binding=load(D/'preflight-review.json')", "binding=load(C/'preflight-review.json')"),
    ("controller=load(D/'time-controller.json')", "controller=load(C/'time-controller.json')"),
    ("controller['controller_sha256']==sha(D/'run.py')", "controller['controller_sha256']==sha(C/'run.py')"),
    ("str(original/'consumers/build.json')", "str(D/'consumers/build.json')"),
    ("sha(D/'time-controller.log')", "sha(C/'time-controller.log')"),
    ('Four reused plus two fresh compiler vector/source bindings,', 'Six historical compiler vector/source bindings and unchanged reused modules, zero confirmation compiles,'),
    ("csvpath=D/'normal-conditions.csv'", "csvpath=C/'normal-conditions.csv'"),
    ("out=D/'normal-review.json'", "out=C/'normal-review.json'"),
])

assert scripts['native', 'run.py'] == read(OLD/'native/run.py').decode()
assert scripts['python', 'python_worker.py'] == read(OLD/'python/python_worker.py').decode()
assert scripts['python', 'consumer_screen.py'] == read(OLD/'python/consumer_screen.py').decode()
for path, value in pins.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == value, path

NEW.mkdir()
for helper in ('observe-host.py', 'monitor-host.py'):
    (NEW/helper).write_bytes(read(OLD/helper))
for kind in ('native', 'python'):
    (NEW/kind).mkdir()
for (kind, name), text in scripts.items():
    (NEW/kind/name).write_text(text)
    original = read(original_path(kind, name)).decode()
    patch = ''.join(difflib.unified_diff(original.splitlines(True), text.splitlines(True), fromfile=str(original_path(kind, name)), tofile=str(NEW/kind/name)))
    (NEW/kind/(name+'.patch')).write_text(patch)

native = load(OLD/'native/adaptation.json')
native.update(origin=str(OLD/'native'), execution_status='held_unexecuted',
              parent_files={n: sha(OLD/'native'/n) for n in ('run.py', 'native_screen.py')},
              files={n: sha(NEW/'native'/n) for n in ('run.py', 'native_screen.py')},
              selected_normal_protocol={'path': str(OLD/'native/native-screen/protocol.json'), 'sha256': sha(OLD/'native/native-screen/protocol.json')},
              transformations={'native_screen.py': changes['native/native_screen.py']},
              scope='Separate held normal confirmation; same source/libraries/driver, all original conditions and seven seeded pairs. Original shared-host attempt preserved. Parent must release and monitor the shared-host window before targets.')
save(NEW/'native/adaptation.json', native)
for kind in ('native', 'python'):
    local = {str(p): sha(p) for p in sorted((NEW/kind).iterdir()) if p.is_file()}
    prep = {'status': 'prepared_no_targets', 'targets_executed': False, 'execution': 'held_for_parent_monitored_window_release',
            'fresh_compiles': 0, 'reused_modules': 6 if kind == 'python' else 0,
            'original_study': str(OLD), 'counts_and_bounds': recipe[kind],
            'libraries': recipe['libraries'], 'changes': {k:v for k,v in changes.items() if k.startswith(kind+'/')},
            'pins': dict(pins) | local,
            'scope': 'No original output changed. New preflights mandatory; no historical worker/result copied. All source/build/compiler/library/module provenance remains attached to original study.'}
    save(NEW/kind/'preparation.json', prep)
save(NEW/'preparation.json', {'status': 'held_prepared_no_targets', 'original_python_review_sha256': sha(OLD/'python/normal-review.json'),
     'original_native_review_sha256': sha(OLD/'native/review.json'), 'finalizer_sha256': sha(__file__),
     'pins': {str(p): sha(p) for p in sorted(NEW.rglob('*')) if p.is_file()}})
print(json.dumps({'status': 'held_prepared_no_targets', 'path': str(NEW), 'sha256': sha(NEW/'preparation.json')}))
