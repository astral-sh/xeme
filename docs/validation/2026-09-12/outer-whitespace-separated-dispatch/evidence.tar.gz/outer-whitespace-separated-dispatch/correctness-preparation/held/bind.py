"""Bind reviewed source and completed normal artifacts; never execute targets."""
from pathlib import Path
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
P = Path(__file__).parent
B = Path('/tmp/oriole-outer-whitespace-separated-dispatch-study')
W = Path('/home/dev-user/code/oss/oriole-outer-whitespace-separated-dispatch')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
pins = load(P / 'static-pins.json')
assert all(sha(path) == value for path, value in pins.items())
review = load(P / 'reviewed-source.json')
source, build, binding = (load(B / name) for name in ['source.json', 'build.json', 'build-binding.json'])
assert review['status'] == 'passed_saved_source_binding'
assert source['worktree'] == str(W) and len(source['sha256']) == 74
prepared = load(P / 'reviewed-prepared-source.json')
metadata = load(P / 'reviewed-metadata.json')
release = load(P / 'reviewed-release.json')
assert release['status'] == 'released_completed_artifacts'
assert sha(P / 'reviewed-source.json') == release['source_binding_sha256']
assert sha(P / 'reviewed-prepared-source.json') == binding['prepared_source_sha256'] == review['source_sha256']
assert source['sha256'] == prepared['sha256']
assert source['base'] == prepared['base'] == review['base'] == release['base'] == '87acc5a91ad3b29b04a9a902cd8bdeebed00529f'
assert prepared['source_count'] == 74
assert set(prepared['changed']) == set(binding['source_delta']) == {'crates/oriole/src/text.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole_expat/src/tests.rs'}
assert prepared['review_pins'] == review['review_pins']
assert len(review['review_pins']) == 2
for path,digest in review['review_pins'].items():
    assert sha(path) == digest
    pins[path] = digest
assert prepared['complete_patch_sha256'] == binding['complete_patch_sha256'] == sha(B / 'candidate.patch')
assert metadata['status'] == 'passed_saved_metadata_review'
assert binding['dependency_review_sha256'] == sha(P / 'reviewed-metadata.json') == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
assert metadata['source_manifest_sha256'] == sha('/tmp/oriole-text-lane-masks-preparation/source.json')
assert binding['auxiliary_files'] == prepared['auxiliary_sha256'] == load('/tmp/oriole-buffered-delivery-study/build-binding.json')['auxiliary_files']
for name,digest in binding['auxiliary_files'].items():
    assert sha(W/name)==digest
    pins[str(W/name)]=digest
assert len(binding['dependency_compiler_vectors']) == 3
control_path = Path('/tmp/oriole-buffered-delivery-study/source.json')
control = load(control_path)
assert binding['control_source_manifest_sha256'] == sha(control_path)
assert set(source['sha256']) == set(control['sha256'])
assert {name for name in source['sha256'] if source['sha256'][name] != control['sha256'][name]} == {'crates/oriole/src/text.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole_expat/src/tests.rs'}
assert binding['control_libraries']['liboriole_expat.so'] == '52202d064fa5fc02854e3a369791f644ddfe2f42ccef656ebba78e290f103821'
assert binding['candidate_libraries'] == release['candidate_libraries']
assert sha(B / 'build-binding.json') == release['build_binding_sha256']
assert load(P / 'preparation.json')['candidate_source_commit'] == release['candidate_source_commit']
assert build['status'] == binding['status'] == 'passed' and build['source_unchanged']
assert binding['build_sha256'] == sha(B / 'build.json')
assert binding['source_manifest_sha256'] == sha(B / 'source.json')
assert binding['source_count'] == 74
assert set(binding['compiler_vectors_normalized']) == {'oriole_storage', 'oriole', 'oriole_expat'}
for vector in binding['compiler_vectors_normalized'].values():
    assert 'opt-level=3' in vector and 'codegen-units=1' in vector
    assert vector[vector.index('--target') + 1] == 'x86_64-unknown-linux-gnu'
    assert not any('profile-generate' in value or 'profile-use' in value or 'target-cpu' in value for value in vector)
assert 'lto=thin' in binding['compiler_vectors_normalized']['oriole_expat']
libraries = {}
for suffix in ['so', 'a']:
    name = 'liboriole_expat.' + suffix
    path = B / 'normal' / name
    value = sha(path)
    assert value == binding['candidate_libraries'][name]
    libraries[suffix] = {'path': str(path), 'sha256': value}
    pins[str(path)] = value
for name, value in source['sha256'].items():
    assert sha(W / name) == value
    pins[str(W / name)] = value
for path in [P / 'preparation.json', P / 'static-pins.json', P / 'reviewed-source.json', B / 'source.json', B / 'build.json', B / 'build-binding.json']:
    pins[str(path)] = sha(path)
assert not (P / 'api-native').exists()
assert all(sha(path) == value for path, value in pins.items())
with (P / 'pins.json').open('x') as stream:
    stream.write(json.dumps(pins, indent=2) + '\n')
with (P / 'bound.json').open('x') as stream:
    stream.write(json.dumps({'status': 'bound_not_executed', 'targets_executed': False, 'source_sha256': sha(B / 'source.json'), 'build_binding_sha256': sha(B / 'build-binding.json'), 'libraries': libraries, 'pins_sha256': sha(P / 'pins.json'), 'scope': 'Normal generic O3/ThinLTO/cgu1 API and six C consumers. Root owns release and execution.'}, indent=2) + '\n')
print(json.dumps({'status': 'bound_not_executed', 'bound_sha256': sha(P / 'bound.json'), 'pins': len(pins), 'libraries': libraries}))
