"""Materialize held normal correctness controllers; no compiler/parser execution."""
from pathlib import Path
import ast, difflib, hashlib, json, os, subprocess

assert __debug__ and os.sched_getaffinity(0)=={6}
PREP=Path(__file__).parent
O=Path('/tmp/oriole-buffered-delivery-correctness')
P=Path('/tmp/oriole-outer-whitespace-separated-dispatch-correctness')
W=Path('/home/dev-user/code/oss/oriole-outer-whitespace-separated-dispatch')
B=Path('/tmp/oriole-outer-whitespace-separated-dispatch-study')
MAIN=Path('/tmp/oriole-outer-whitespace-separated-dispatch-preparation')
old_work='/home/dev-user/code/oss/oriole-buffered-delivery'
old_build='/tmp/oriole-buffered-delivery-study'
replacements=[(str(O),str(P)),(old_work,str(W)),(old_build,str(B))]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def save(name,value):(P/name).write_text(json.dumps(value,indent=2)+'\n')
def relocate(text):
    for old,new in replacements:text=text.replace(old,new)
    return text

release=load(PREP/'release.json')
assert release['status']=='released_completed_artifacts'
seal=load(PREP/'prepared.json')
assert sha(__file__)==seal['materializer_sha256']
assert all(sha(path)==digest for path,digest in seal['inputs'].items())
source_review_path=MAIN/'source-binding.json'
prepared_source_path=MAIN/'source.json'
metadata_review_path=Path('/tmp/oriole-text-lane-masks-preparation/metadata-independent-review.json')
assert sha(metadata_review_path)=='45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
source_binding=load(source_review_path);prepared_source=load(prepared_source_path)
assert source_binding['status']=='passed_saved_source_binding'
assert release['base']==source_binding['base']==prepared_source['base']=='87acc5a91ad3b29b04a9a902cd8bdeebed00529f'
assert sha(source_review_path)==release['source_binding_sha256']
assert sha(prepared_source_path)==source_binding['source_sha256']
assert prepared_source['review_pins']==source_binding['review_pins']
assert len(source_binding['review_pins'])==2 and all(sha(p)==h for p,h in source_binding['review_pins'].items())
candidate_commit=release['candidate_source_commit']
assert candidate_commit==seal['runtime_commit']
assert isinstance(candidate_commit,str) and len(candidate_commit)==40 and all(c in '0123456789abcdef' for c in candidate_commit)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==candidate_commit
assert not subprocess.check_output(['git','diff','HEAD','--name-only','--','crates','include','tests/c','Cargo.toml','Cargo.lock'],cwd=W,text=True).strip()
build_binding=load(B/'build-binding.json')
assert sha(B/'build-binding.json')==release['build_binding_sha256']
assert sha(B/'source.json')==release['source_manifest_sha256']
assert sha(B/'build.json')==release['build_sha256']
assert build_binding['status']=='passed' and build_binding['source_count']==74
assert sha(B/'build-binding.json')==seal['build_binding_sha256']
assert build_binding['candidate_libraries']==seal['candidate_libraries']
assert {name:prepared_source['sha256'][name] for name in seal['source_delta']}==seal['candidate_changed_source_sha256']
assert prepared_source['expected_tests']=={'passed':466,'groups':35,'failures':0,'ignored':0}
assert load(B/'build.json')['status']=='passed'
assert build_binding['control_libraries']['liboriole_expat.so']=='52202d064fa5fc02854e3a369791f644ddfe2f42ccef656ebba78e290f103821'
assert set(build_binding['source_delta'])=={'crates/oriole/src/text.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole_expat/src/tests.rs'}
assert build_binding['source_manifest_sha256']==sha(B/'source.json')
assert build_binding['build_sha256']==sha(B/'build.json')
assert load(B/'source.json')['sha256']==prepared_source['sha256']
assert build_binding['prepared_source_sha256']==sha(prepared_source_path)
assert set(release['candidate_libraries'])=={'liboriole_expat.so','liboriole_expat.a'}
assert build_binding['candidate_libraries']==release['candidate_libraries']
assert all(sha(B/'normal'/n)==h for n,h in release['candidate_libraries'].items())
assert build_binding['dependency_review_sha256']==sha(metadata_review_path)
assert build_binding['auxiliary_files']==prepared_source['auxiliary_sha256']
assert all(sha(W/name)==h for name,h in load(B/'source.json')['sha256'].items())
assert all(sha(W/name)==h for name,h in build_binding['auxiliary_files'].items())
assert sha(MAIN/'composition.json')==prepared_source['composition_sha256']
assert sha(MAIN/'formatting-proof.json')==prepared_source['formatting_proof_sha256']
P.mkdir(exist_ok=False);(P/'prior').mkdir()
scripts=['api_native.py','strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_api_c.py','read_strict_semantics.py','bind.py','bind_strict.py']
origins={}
for name in scripts:
    before=(O/name).read_text();after=relocate(before)
    if name=='bind.py':
        start=after.index("assert review['status'] ==")
        end=after.index("assert build['status'] ==",start)
        after=after[:start]+"assert review['status'] == 'passed_saved_source_binding'\nassert source['worktree'] == str(W) and len(source['sha256']) == 74\nprepared = load(P / 'reviewed-prepared-source.json')\nmetadata = load(P / 'reviewed-metadata.json')\nrelease = load(P / 'reviewed-release.json')\nassert release['status'] == 'released_completed_artifacts'\nassert sha(P / 'reviewed-source.json') == release['source_binding_sha256']\nassert sha(P / 'reviewed-prepared-source.json') == binding['prepared_source_sha256'] == review['source_sha256']\nassert source['sha256'] == prepared['sha256']\nassert source['base'] == prepared['base'] == review['base'] == release['base'] == '87acc5a91ad3b29b04a9a902cd8bdeebed00529f'\nassert prepared['source_count'] == 74\nassert set(prepared['changed']) == set(binding['source_delta']) == {'crates/oriole/src/text.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole_expat/src/tests.rs'}\nassert prepared['review_pins'] == review['review_pins']\nassert len(review['review_pins']) == 2\nfor path,digest in review['review_pins'].items():\n    assert sha(path) == digest\n    pins[path] = digest\nassert prepared['complete_patch_sha256'] == binding['complete_patch_sha256'] == sha(B / 'candidate.patch')\nassert metadata['status'] == 'passed_saved_metadata_review'\nassert binding['dependency_review_sha256'] == sha(P / 'reviewed-metadata.json') == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'\nassert metadata['source_manifest_sha256'] == sha('/tmp/oriole-text-lane-masks-preparation/source.json')\nassert binding['auxiliary_files'] == prepared['auxiliary_sha256'] == load('/tmp/oriole-buffered-delivery-study/build-binding.json')['auxiliary_files']\nfor name,digest in binding['auxiliary_files'].items():\n    assert sha(W/name)==digest\n    pins[str(W/name)]=digest\nassert len(binding['dependency_compiler_vectors']) == 3\ncontrol_path = Path('/tmp/oriole-buffered-delivery-study/source.json')\ncontrol = load(control_path)\nassert binding['control_source_manifest_sha256'] == sha(control_path)\nassert set(source['sha256']) == set(control['sha256'])\nassert {name for name in source['sha256'] if source['sha256'][name] != control['sha256'][name]} == {'crates/oriole/src/text.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/encoding.rs', 'crates/oriole_expat/src/tests.rs'}\nassert binding['control_libraries']['liboriole_expat.so'] == '52202d064fa5fc02854e3a369791f644ddfe2f42ccef656ebba78e290f103821'\nassert binding['candidate_libraries'] == release['candidate_libraries']\nassert sha(B / 'build-binding.json') == release['build_binding_sha256']\nassert load(P / 'preparation.json')['candidate_source_commit'] == release['candidate_source_commit']\n"+after[end:]
    if name=='read_api_c.py':
        after=after.replace('Buffered-delivery preparer adapted the selected empty-state API/C saved reader','Outer-whitespace separated-dispatch preparer adapted the selected buffered-delivery API/C saved reader')
    if name=='read_strict_semantics.py':
        after=after.replace('Buffered-delivery preparer adapted the selected empty-state strict/semantic saved reader','Outer-whitespace separated-dispatch preparer adapted the selected buffered-delivery strict/semantic saved reader')
    if name=='read_api_c.py':
        for before_expectation,after_expectation in [("assert api['status'] == 'passed'", "assert api['status'] == 'api_differences_native_passed'"), ("assert report['returncode'] == 1 and report['passed'] == 4347 and report['failed'] == 393", "assert report['returncode'] == 1\n    assert (report['passed'], report['failed']) == ((4347, 393) if root == BASE else (4349, 391))"), ("assert rows[0] == rows[1] and api['api_comparison']['changes'] == []\n", "assert dict(Counter(row['outcome'] for row in rows[0])) == {'pass': 4347, 'fail': 391, 'timeout': 2}\nexpected_rows = [dict(row) for row in rows[0]]\nexpected_changes = []\nfor index, context in [(110, 'chunksize=0 deferral=0'), (505, 'chunksize=0 deferral=1')]:\n    before = {'context': context, 'test': 'test_misc_input_2gb', 'outcome': 'timeout', 'code': 14}\n    after = {**before, 'outcome': 'pass', 'code': 0}\n    assert rows[0][index] == before\n    expected_rows[index] = after\n    expected_changes.append({'baseline': before, 'candidate': after})\nassert rows[1] == expected_rows, 'Only the two exact original chunk-0 timeout/14 rows may change, and both must pass/0'\nassert api['api_comparison']['changes'] == expected_changes\nassert not api['api_comparison']['all4740rows_exact']\n"), ("assert counts == {'pass': 4347, 'fail': 391, 'timeout': 2}, counts", "assert counts == {'pass': 4349, 'fail': 391}, counts\ncounts['timeout'] = 0"), ("'counts': counts, 'changes': [], 'raw_exit': 1", "'counts': counts, 'baseline_counts': {'pass': 4347, 'fail': 391, 'timeout': 2}, 'changes': expected_changes, 'required_timeout_improvements': 2, 'other_4738_ordered_rows_exact': True, 'raw_exit': 1")]:
            assert after.count(before_expectation)==1
            after=after.replace(before_expectation,after_expectation)
    ast.parse(after)
    assert sha(PREP/'held'/name)==seal['generated_scripts'][name]
    assert after==(PREP/'held'/name).read_text(),name
    (P/'prior'/name).write_text(before);(P/name).write_text(after)
    (P/(name+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(O/name),tofile=str(P/name))))
    origins[name]={'origin':str(O/name),'origin_sha256':sha(O/name),'sha256':sha(P/name),'path_substitution_only':name not in ('bind.py','strict_cpython.py','read_api_c.py','read_strict_semantics.py')}
assert (P/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]==(O/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]
review_copies={'reviewed-source.json':str(source_review_path),'reviewed-prepared-source.json':str(prepared_source_path),'reviewed-metadata.json':str(metadata_review_path),'reviewed-release.json':str(PREP/'release.json')}
for name,origin in review_copies.items():(P/name).write_bytes(Path(origin).read_bytes())

# Keep historical author scripts/oracles at their actual paths. Only unchanged
# repository input descendants relocate; no prior output is a candidate result.
static={};strictstatic={}
for filename,destination in [('static-pins.json',static),('strict-static-pins.json',strictstatic)]:
    for path,value in load(O/filename).items():
        if path.startswith(str(O)+'/'):continue
        if path==old_build+'/candidate.patch':continue
        new=relocate(path) if path.startswith(old_work+'/') else path
        assert sha(new)==value,new
        destination[new]=value
for name in scripts:
    destination=strictstatic if name in ('strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_strict_semantics.py','bind_strict.py') else static
    destination[str(P/name)]=sha(P/name)
    static[str(P/'prior'/name)]=sha(P/'prior'/name)
retry_path=Path('/tmp/oriole-outer-whitespace-plan-preparation/retry-lineage.json')
retry=load(retry_path)
assert sha(retry_path)==seal['ingredient_retry_lineage_sha256']
static[str(retry_path)]=sha(retry_path)
for path,digest in retry['preserved_pins'].items():
    assert sha(path)==digest
    static[path]=digest
for path,digest in seal['supervisor_pins'].items():
    assert sha(path)==digest
    static[path]=digest
for name in ('composition.json','formatting-proof.json'):
    static[str(MAIN/name)]=sha(MAIN/name)
static[str(Path(__file__))]=sha(__file__)
static[str(PREP/'prepared.json')]=sha(PREP/'prepared.json')
for path,digest in source_binding['review_pins'].items():static[path]=digest
for name in review_copies:static[str(P/name)]=sha(P/name)
static[str(B/'candidate.patch')]=sha(B/'candidate.patch')
static[str(B/'build-binding.json')]=sha(B/'build-binding.json')
static[str(Path(old_build)/'source.json')]=sha(Path(old_build)/'source.json')
oldprep=load(O/'preparation.json')
save('preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'source_worktree':str(W),'candidate_source_commit':candidate_commit,'measured_source_base_commit':load(B/'source.json')['base'],'build_directory':str(B),'controller_origins':origins,'source_review_sha256':sha(P/'reviewed-source.json'),'api':oldprep['api'],'c_consumers':oldprep['c_consumers'],'baseline_api_outcomes':oldprep['baseline_api_outcomes'],'expected_api_outcomes':seal['expected_api'],'required_api_changes':seal['required_api_changes'],'source_delta':'Four reviewed files differ from selected buffered279a/87acc in the74-source map: transient native outer-whitespace text proof in lib.rs/text.rs plus encoding/C test extensions. The separated dispatch composition and the original ingredient fixture-only compilation retry are retained; all four auxiliary files and three dependency packages are unchanged.','scope':'Direct adaptation of completed selected buffered-delivery normal correctness controllers. Source and commit provenance updated; original API assertions, selectors and limits remain unchanged. The saved reader requires only two original chunk-0 test_misc_input_2gb timeouts to become passes and all other ordered rows to remain exact. Six C builds/runs, complete strict shared/static loop, method reader and supplemental semantics are unchanged. No targets executed.'})
save('static-pins.json',static)
spec=json.loads(relocate(json.dumps(load(O/'semantic-commands-unbound.json'))))
for command in spec['commands']:assert command['expected_library_sha256'] is None
save('semantic-commands-unbound.json',spec)
strictstatic[str(P/'semantic-commands-unbound.json')]=sha(P/'semantic-commands-unbound.json')
save('strict-static-pins.json',strictstatic)
oldstrict=load(O/'strict-preparation.json')
save('strict-preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'controller_origin':str(O/'strict_cpython.py'),'controller_origin_sha256':sha(O/'strict_cpython.py'),'controller_sha256':sha(P/'strict_cpython.py'),'complete_shared_static_execution_loop_byte_exact':True,'candidate_source_commit':candidate_commit,'measured_source_base_commit':load(B/'source.json')['base'],'baseline':oldstrict['baseline'],'baseline_outcomes':oldstrict['baseline_outcomes'],'consumer_fix':oldstrict['consumer_fix'],'static_pins_sha256':sha(P/'strict-static-pins.json'),'scope':'Original strict consumer-cleanup backport and historical two failures per linkage remain the comparison oracle; separate unchanged two semantic tests per linkage. Candidate outcomes pending. All target execution held.'})
(P/'README.md').write_bytes((PREP/'README.md').read_bytes())


print(json.dumps({'status':'prepared_not_executed','path':str(P),'preparation_sha256':sha(P/'preparation.json'),'scripts':len(scripts),'static_pins':len(static),'strict_static_pins':len(strictstatic)}))
