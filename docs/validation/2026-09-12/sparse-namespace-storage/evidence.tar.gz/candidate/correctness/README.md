# Namespace scopes: held normal correctness gates

Prepared from the completed selected Text controllers. Source74 has one runtime change (lib.rs) and two test changes. Selected performance control is Text ef1648; the original ordered API/strict oracle is retained because selected Text matched it exactly. API has4740 configurations:4347 pass,391 assertion failures,2 timeouts. All original assertions/3s/AS1GiB/RSS768MiB/240s bounds remain. Six C consumers cover integration/adversarial/allocations, dynamic/static; only their C code is ASan/UBSan instrumented, leak checking disabled. Rust libraries are normal release.

Strict shared/static CPython keeps the explicit upstream pyexpat cleanup backport,802 methods/809 rendered outcomes, and the two known callback-fragmentation failures with raw exit2. The unchanged two-test semantic follow-up per linkage remains separate and never turns strict outcomes green.

Root owns every release and execution. Native gain is required before these gates. Saved binders and target commands remain held after materialization; no strict extensions exist yet. No unmodified Python elapsed preparation is included.

After release, root runs bind.py and bind_strict.py on CPU6, api_native.py then read_api_c.py, strict_cpython.py then prepare_semantics.py, run_semantic.py shared then static, and read_strict_semantics.py. Target controllers run CPU3; saved readers run CPU6. Preserve the pinned Python bin first on PATH and use a clean environment as for selected Text. Original child timeouts, process-group cleanup, compile vectors, module origins and raw readers are unchanged.

Historical top-level author-script pins stay at original paths. Only unchanged repository tool/test inputs are relocated. The predecessor candidate.patch pin is replaced explicitly by this reviewed candidate patch. No target was run during preparation.
