"""Bind reviewed source and completed normal artifacts; never execute targets."""
from pathlib import Path
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
P = Path(__file__).parent
B = Path('/tmp/oriole-namespace-scopes-study')
W = Path('/home/dev-user/code/oss/oriole-namespace-scopes')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
pins = load(P / 'static-pins.json')
assert all(sha(path) == value for path, value in pins.items())
review = load(P / 'reviewed-source.json')
source, build, binding = (load(B / name) for name in ['source.json', 'build.json', 'build-binding.json'])
assert review['status'] == 'independent_namespace_scope_source_and_builder_review_no_blocker'
assert source['worktree'] == str(W) and len(source['sha256']) == 74
prepared = load(P / 'reviewed-prepared-source.json')
assert review['source_manifest_sha256'] == sha(P / 'reviewed-prepared-source.json') == binding['prepared_source_sha256']
assert source['sha256'] == prepared['sha256']
assert review['base'] == source['base'] == prepared['base'] == '19b285440bc7467debfa4901df36d86a0e4ef1a0'
assert review['source_count'] == prepared['source_count'] == 74 and review['all_74_live_source_hashes_verified']
assert set(review['changed_files']) == set(prepared['changed']) == set(binding['source_delta']) == {'crates/oriole/src/lib.rs', 'crates/oriole/tests/adapter_frame.rs', 'crates/oriole/tests/allocation.rs'}
assert all(source['sha256'][name] == digest for name, digest in review['changed_files'].items())
assert review['patch_sha256'] == prepared['complete_patch_sha256'] == sha(B / 'candidate.patch')
control_path = Path('/tmp/oriole-text-plan-combined-study/source.json')
control = load(control_path)
assert binding['control_source_manifest_sha256'] == sha(control_path)
assert set(source['sha256']) == set(control['sha256'])
assert {name for name in source['sha256'] if source['sha256'][name] != control['sha256'][name]} == set(review['changed_files'])
assert binding['control_libraries']['liboriole_expat.so'] == 'ef1648fcb1bae5bce53715283b221166c84e5e8431ff53f39e62a1ecd358bd25'
assert binding['candidate_libraries'] == {'liboriole_expat.so': 'd6303603fece314e683a5fda5dcb60334c7e302e5e8d87bd7dd13285e46bb63e', 'liboriole_expat.a': '7d9c06f7d6e63f602d98d95eeab35bfb5967f1cfa8154657f716dc9cedcea8bf'}
assert build['status'] == binding['status'] == 'passed' and build['source_unchanged']
assert binding['build_sha256'] == sha(B / 'build.json')
assert binding['source_manifest_sha256'] == sha(B / 'source.json')
assert binding['source_count'] == 74
assert set(binding['compiler_vectors_normalized']) == {'oriole_storage', 'oriole', 'oriole_expat'}
for vector in binding['compiler_vectors_normalized'].values():
    assert 'opt-level=3' in vector and 'codegen-units=1' in vector
    assert vector[vector.index('--target') + 1] == 'x86_64-unknown-linux-gnu'
    assert not any('profile-generate' in value or 'profile-use' in value or 'target-cpu' in value for value in vector)
assert 'lto=thin' in binding['compiler_vectors_normalized']['oriole_expat']
libraries = {}
for suffix in ['so', 'a']:
    name = 'liboriole_expat.' + suffix
    path = B / 'normal' / name
    value = sha(path)
    assert value == binding['candidate_libraries'][name]
    libraries[suffix] = {'path': str(path), 'sha256': value}
    pins[str(path)] = value
for name, value in source['sha256'].items():
    assert sha(W / name) == value
    pins[str(W / name)] = value
for path in [P / 'preparation.json', P / 'static-pins.json', P / 'reviewed-source.json', B / 'source.json', B / 'build.json', B / 'build-binding.json']:
    pins[str(path)] = sha(path)
assert not (P / 'api-native').exists()
assert all(sha(path) == value for path, value in pins.items())
with (P / 'pins.json').open('x') as stream:
    stream.write(json.dumps(pins, indent=2) + '\n')
with (P / 'bound.json').open('x') as stream:
    stream.write(json.dumps({'status': 'bound_not_executed', 'targets_executed': False, 'source_sha256': sha(B / 'source.json'), 'build_binding_sha256': sha(B / 'build-binding.json'), 'libraries': libraries, 'pins_sha256': sha(P / 'pins.json'), 'scope': 'Normal generic O3/ThinLTO/cgu1 API and six C consumers. Root owns release and execution.'}, indent=2) + '\n')
print(json.dumps({'status': 'bound_not_executed', 'bound_sha256': sha(P / 'bound.json'), 'pins': len(pins), 'libraries': libraries}))
