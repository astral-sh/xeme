# Sparse namespace layout readback

Saved artifacts show Element168→120 bytes (−48) and Parser2408→2464 (+56), alignment8. All matching Oriole DWARF copies agree; their compilation directories and compiler identities match the logged debug test binaries.

In the actual normal release `prepare_end_frame`, control copies the popped168-byte stack entry with memcpy at0x943c3. Candidate uses a120-byte inline transfer at0x95308–0x95367, with a matching120-byte stack stride. Both retain subsequent72-byte ElementName copies. Full function disassemblies, ELF headers/notes, DWARF outputs and exact tool commands are retained. No target was executed and no speed or heap-memory saving is inferred.

See [report.json](report.json), [capture.json](capture.json), and [disassembly.json](disassembly.json).
