# Sparse namespace bookkeeping: held normal native protocol

Candidate is the reviewed sparse namespace prototype on PR156. Control is PR156's selected combined Text parser. Both use ordinary generic x86-64 O3, ThinLTO, one codegen unit; Expat is the existing normal 2.8.4 baseline. No PGO.

All 24 real conditions and four generated controls use the original seven seeded pairs, 84 fresh preflight workers and 588 timed workers. Every sample includes parser construction, handlers, feeding, callbacks and destruction. Callback digests merge text fragments; they do not establish exact callback fragmentation.

Native runs first; Python is not prepared unless a native gain justifies proceeding. Root runs run.py with the pinned CPython bin directory first on PATH. The unchanged wrapper runs preflight on CPU5 (600-second bound), then exclusive elapsed on CPU0 (1200-second bound), with original 90-second worker limits and process-group cleanup. Root runs read_results.py on CPU6 afterward. No target ran during preparation.
