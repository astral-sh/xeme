# Sparse namespace undo blocks: source-only prototype

Prepared from runtime `ea52004a6590a224bfc0ec96c8e80a3159920db5`, after the combined Text and fused scanner changes. **No compiler, parser, test, formatter, benchmark, or profiler target has run for this prototype.** All edits are confined to this temporary staging directory; the repository is unchanged.

## Change

`candidate.patch` changes one runtime file (`crates/oriole/src/lib.rs`) and two existing integration test files. `base/` contains exact committed originals; `candidate/` contains complete proposed replacements. `source.json` binds all 74 committed source inputs and the three proposed file hashes. The remaining 71 files are unchanged; they are represented by their committed hashes rather than copied here.

The runtime follows the [source assessment](/tmp/oriole-namespace-undo-current-triage/README.md): each Element carries an `Option<NonZeroUsize>` instead of its owned namespace-binding Vec. The parser owns a sparse LIFO Vec of nonempty binding blocks. Indices are one-based lengths; successful `try_reserve(1)` bounds the following push, so the resulting length is nonzero and cannot overflow. No namespace declaration means no block and no new allocation on that path.

Start retains the existing local undo Vec through validation, namespace-map updates, StartNamespace emissions, expansion and name packing. It reserves the Element slot, then a scope slot only when needed, before moving either owner. These reserves precede both infallible pushes. Errors before this joint commit drop the local block without rolling back map changes; errors publishing StartElement retain both committed owners. The new sparse reserve is an additional possible allocation failure. Existing fallible work and namespace callbacks retain their relative order.

End pops its Element and detaches the top block before emitting EndElement. A fallible emission or restoration drops any unprocessed local records instead of retaining an orphan scope. The restoration body is unchanged. The optional local block is flattened into the same reverse iterator; this avoids constructing an empty allocator-carrying Vec for scope-less Ends. Native framed Ends test the individual Element's index, so a declaration-free child can still use a frame while its parent owns a block. ElementName packing, allocation-free End name moves and callback ownership are unchanged.

The only new helper detaches a block and releases the sparse metadata buffer once the pool is empty and its capacity exceeds 4 KiB. It does not allocate to shrink. Smaller empty buffers remain reusable. Active ancestor scopes can retain peak metadata capacity; this is not a 4 KiB bound while any scope remains active. Each detached block's own record/string storage is freed as before. Custom allocator callbacks and parser destruction still own all new storage through the existing allocator-aware Vec. External children construct an empty sparse stack and inherit only the existing copied namespace map.

No name arena, Source lifetime change, public API, SIMD path, dependency, unsafe code or compiler-flag change is included. Namespace declarations at every depth remain an adverse case: both a sparse block descriptor and an Element index are live at each depth. Actual object sizes, allocator counts and elapsed costs must be measured.

## Focused coverage prepared

- A new private-core test opens 128 declaring children under a declaration-free root, closes the children while keeping the root open, and checks that oversized metadata is released, namespace restoration completes, and a later small scope can reuse bounded metadata.
- A new integration test asserts the exact namespace/element callback sequence for nested prefix shadowing, default undeclaration, empty declaring children and declaration-free siblings. It covers explicit and DTD-defaulted root declarations, UTF-8/UTF-16, one-byte and whole-input feeds, and compares owned/adapted event records.
- The existing End-frame boundary test gains a shadowed prefix child followed by an outer-prefix sibling, preserving the expected two native framed End names and UTF-16 fallback.
- The existing selected-allocator failure sweep gains six live declaring scopes, four root declarations, a declaration-free descendant, an empty declaring child and restoration to a sibling. The existing sweep fails every selected allocation, requires sticky errors/cleared frame and event slots, rejects global-allocator bypass, and checks balanced frees. This reaches both Element/scope growth and namespace restoration; actual phase coverage remains subject to running the sweep.

Existing external-child, namespace errors, callback reentry/suspend/reset/free and allocator tests are retained unchanged. No new claim is made for their execution on this candidate.

## Source checks and handoff

Source readback verified the 74 base hashes directly against Git blobs at the recorded commit, and verified the copied originals. `git apply --check candidate.patch` passed against `base/`; `git diff --no-index --check base candidate` emitted no whitespace diagnostics (exit 1 indicates the expected differences). Neither command writes Git or runs a target.

Root can apply this complete patch to a proper worktree based on the recorded runtime commit (or a source-equivalent publication descendant), then run formatting, the focused tests and full existing checks. Refresh the candidate source pins if formatting changes bytes. Independent source review and normal-only layout/allocation/native/CPython measurements remain pending. No PGO work is proposed.

## Source-review correction (revision 2)

The initial frozen revision remains byte-for-byte in `v1-before-reserve-error-mapping/`. Root's source review found that the two raw Vec reserves return `allocator_api2::collections::TryReserveError`, while core Error implements `From<AllocError>` only. Both reserves now use `.map_err(AllocError::from)?`, preserving the storage helper's capacity-overflow/out-of-memory distinction and all operation ordering. No other proposed source or test bytes changed. This was caught by source review before compiler execution; it is not a failed target run.

The exact pinned allocator-api2 0.2.21 source confirms the other new operations: `new_in` constructs an empty allocator-owning Vec; `push` does not reserve when the preceding successful reserve supplies capacity; `pop` transfers its element by value; `len` and `capacity` return `usize`; consuming Vec iteration supports `DoubleEndedIterator`. Thus the detached optional block can use `flatten().rev()` without a new allocation. The only new fallible collection calls are the two explicitly mapped reserves. Compilation and execution remain pending root release.
