# Sparse namespace storage: normal CPython comparison

The candidate uses the reviewed three-file namespace change on PR156. Control is PR156 itself. Both use generic x86-64 O3, ThinLTO and one codegen unit; Expat is the unchanged normal baseline. No PGO.

The completed selected Text protocol is reused: 24 conditions, seven pairs, 72 fresh preflight workers and 504 timed workers. Worker, build and outer controllers are byte-identical. Two candidate extensions are compiled fresh; four unchanged control/Expat extensions retain their original paths. All consumers use unmodified CPython sources. Exact callback fragmentation is a separate correctness gate.

Root runs prepare.py and bind.py as saved-data checks on CPU6, then run.py prepare on CPU3. After the saved preflight reader passes and all other targets are reaped, root runs run.py time exclusively on CPU0 and elapsed_review.py on CPU6. Original bounds, canonical checks, module origins, destruction, GC and ratio calculations remain unchanged.
