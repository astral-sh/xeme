"""Replay completed confirmation records and host counters; saved files only."""
from pathlib import Path
import ast
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
ROOT = Path('/tmp/oriole-namespace-scopes-confirmation')
D = ROOT/'native'
H = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
J = lambda p: json.loads(Path(p).read_text())
preparer = Path('/tmp/oriole-namespace-scopes-confirmation-prepare.py')
assert H(preparer) == '9e81f59cdad0f8c57dfbb0a7606866d0663007392386be7683cba39c34376be4'
preparation = J(ROOT/'preparation.json')
assert H(ROOT/'preparation.json') == '1c30a68ac9584c024f50dd7fdf528474e10210ba2691ea7c04ec5b176cc668cf'
for path, value in preparation['pins'].items():
    assert H(path) == value, path
adaptation = J(D/'adaptation.json')
origin = Path(adaptation['origin'])
assert origin == Path('/tmp/oriole-namespace-scopes-study/native')
assert (D/'run.py').read_bytes() == (origin/'run.py').read_bytes()
before, after = ((p/'native_screen.py').read_text() for p in (origin, D))
assert after == before.replace(f"root = Path('{origin}')", f"root = Path('{D}')", 1)
marker = 'def run(condition, engine, pair, cpu, count):'
assert before[before.index(marker):] == after[after.index(marker):]
reader = D/'read_results.py'
text = reader.read_text()
tree = ast.parse(text)
cut = next(i for i, node in enumerate(tree.body) if text.splitlines()[node.lineno-1].startswith('with (OUT /'))
scope = {'__file__': str(reader), '__name__': 'independent_saved_confirmation_replay'}
exec(compile(ast.Module(body=tree.body[:cut], type_ignores=[]), str(reader), 'exec'), scope)
report = J(D/'review.json')
assert H(D/'review.json') == '9e7f5f54e92462c890a45277afdd211ba538912e96a8509163e83c5a7c8b706d'
assert report['counts'] == scope['counts']
assert report['groups'] == scope['groups']
assert report['all_conditions'] == scope['summary']
assert scope['ROOT'] == Path('/tmp/oriole-namespace-scopes-study')
assert scope['NATIVE'] == D and scope['SCREEN'] == D/'native-screen'
assert scope['libraries'] == J(origin/'native-screen/protocol.json')['libraries']
adverse = [{'condition': row['condition'], **row['median_ratios']} for row in scope['summary'] if row['median_ratios']['candidate_over_control'] > 1]
assert len(adverse) == 10
for path, value in scope['pins'].items():
    assert H(path) == value, path

controller = J(D/'controller.json')
before_host = J(ROOT/'host-before-native.json')
during = J(ROOT/'host-during-native.json')
release = J(ROOT/'native-release.json')
assert before_host['status'] == 'observed' and before_host['affinity'] == [6]
assert during['status'] == 'completed' and during['phase'] == 'native'
assert during['controller_status'] == controller['status'] == 'passed'
assert during['controller_sha256'] == H(D/'controller.json')
assert during['monitor_sha256'] == H(ROOT/'monitor-host.py')
assert release['preparation_sha256'] == H(ROOT/'preparation.json')
assert release['host_observation_sha256'] == H(ROOT/'host-before-native.json')
assert before_host['samples'][-1]['time'] <= release['released_at'] <= controller['commands'][0]['start']
timing = next(row for row in controller['commands'] if row['phase'] == 'time')

def counters(first, last):
    delta = {name: {key: last['cpu'][name][key] - first['cpu'][name][key] for key in ('total', 'idle')} for name in ('cpu', 'cpu0')}
    assert last['time'] > first['time']
    for values in delta.values():
        assert 0 <= values['idle'] <= values['total'] and values['total'] > 0
    other_total = delta['cpu']['total'] - delta['cpu0']['total']
    other_idle = delta['cpu']['idle'] - delta['cpu0']['idle']
    assert 0 <= other_idle <= other_total and other_total > 0
    return {'start': first['time'], 'end': last['time'], 'seconds': last['time']-first['time'], 'counter_deltas': delta,
            'idle_including_iowait_fractions': {name: values['idle']/values['total'] for name, values in delta.items()},
            'other_cpus_idle_including_iowait_fraction': other_idle/other_total}

before_summary = counters(before_host['samples'][0], before_host['samples'][-1])
assert before_summary['idle_including_iowait_fractions'] == before_host['idle_fractions']
all_intervals = [counters(a, b) for a, b in zip(during['samples'], during['samples'][1:])]
observed = counters(during['samples'][0], during['samples'][-1])
inside = [row for row in all_intervals if timing['start'] <= row['start'] and row['end'] <= timing['end']]
assert inside
inside_points = [point for point in during['samples'] if timing['start'] <= point['time'] <= timing['end']]
inside_summary = counters(inside_points[0], inside_points[-1])
host = {'before': before_summary, 'during_sample_count': len(during['samples']), 'during_observed_span': observed,
        'elapsed_controller': {'start': timing['start'], 'end': timing['end'], 'seconds': timing['end']-timing['start']},
        'sample_intervals_fully_inside_elapsed': {'count': len(inside), 'aggregate': inside_summary,
            'other_cpus_idle_range': [min(row['other_cpus_idle_including_iowait_fraction'] for row in inside), max(row['other_cpus_idle_including_iowait_fraction'] for row in inside)]},
        'limitations': ['Monitor sums the first eight /proc/stat fields, excludes double-counted guest fields, and defines idle as idle plus iowait; counters are rounded scheduler-accounting observations.',
                       'The monitor has five-second samples and does not cover every instant of the elapsed window. It cannot identify processes, exclude concurrent memory/cache/bandwidth pressure or certify OS-enforced isolation.',
                       'The release records another task reporting its performance comparison finished. This is a scheduling observation, not independent verification of every process.']}
pins = {str(p): H(p) for p in [preparer, ROOT/'preparation.json', reader, D/'review.json', D/'adaptation.json', D/'preparation.json', D/'controller.json', ROOT/'host-before-native.json', ROOT/'host-during-native.json', ROOT/'native-release.json', ROOT/'monitor-host.py']}
result = {'status': 'independent_confirmation_native_raw_and_host_counters_verified', 'targets_executed': False,
          'role': 'Independent runtime reviewer authored the held confirmation finalizer; root executed targets and initial reader. This audit replays the existing raw arithmetic before output writes and independently recomputes host counter deltas.',
          'counts': report['counts'], 'groups': report['groups'], 'all_adverse': adverse, 'host': host,
          'provenance': {'original_source_build_root': str(scope['ROOT']), 'fresh_raw_root': str(scope['SCREEN']), 'libraries': scope['libraries'], 'source_files_verified': len(scope['source']['sha256']), 'reader_input_pins_verified': len(scope['pins']), 'old_attempt_unchanged': True},
          'limitations': ['All ten adverse conditions retained; no pooling with the original shared-host attempt.', 'This confirms arithmetic and identities, not causal attribution or statistical significance.', 'Native timing is separate from Python; no Python confirmation result is reviewed here.'],
          'pins_sha256': pins, 'reader_sha256': H(__file__)}
out = Path('/tmp/oriole-namespace-scopes-confirmation-native-independent-review.json')
with out.open('x') as stream:
    stream.write(json.dumps(result, indent=2)+'\n')
print(json.dumps({'status': result['status'], 'path': str(out), 'sha256': H(out), 'counts': result['counts'],
                 'groups': {k:{key:value for key,value in v.items() if key != 'adverse'} for k,v in result['groups'].items()},
                 'all_adverse': adverse, 'host': host}, indent=2))
