# Held namespace confirmation recipe

This is a fresh **normal-only** confirmation of the same namespace candidate and selected Text control. The initial native and Python attempts remain intact and are labeled shared-host measurements. Another Toucan task is active on this host; parent will decide when its target work has ended and release a quiet window. This document does not certify host isolation or authorize execution.

Only this plan and its [pinned recipe](oriole-namespace-scopes-confirmation-recipe.json) exist. Do not create `/tmp/oriole-namespace-scopes-confirmation/{native,python}` until the original Python controller and final saved review have completed and parent confirms all sessions reaped. No source changes, builds, dependency changes, or target execution are needed for preparation.

## Fixed inputs

- Candidate namespace SO `d6303603…`, Text control SO `ef1648fc…`, normal Expat SO `7a333bc8…`; exact paths and full hashes are in the recipe. The historical Expat directory name does not change this normal-library comparison.
- Native: reuse `/tmp/oriole-grammar-bench-plain/native-driver` and the exact eight inputs from the original protocol.
- Python: reuse all six already-built unmodified O2 CPython 3.12.13 modules **in their existing directories**, including candidate modules under the original namespace study. Reuse the original `consumers/build.json` and all build vectors, source/library/module hashes and dladdr origins. No copied or relabeled build receipt; zero compiles in the confirmation.

## Minimal saved-only finalizer

After original Python completion, use a small direct adaptation script, not a new runner framework. Require nonexistent confirmation destination, pin the completed original reviews, rehash existing source/build/library/module/worker inputs, and retain exact transformation diffs. Materialization creates scripts and static bindings only.

| File | Adaptation |
| --- | --- |
| Native `run.py` | Byte-identical copy. Same preflight CPU5/600s then elapsed CPU0/1200s and process-group teardown. |
| Native `native_screen.py` | Change only its output `root` to confirmation/native. Keep driver, libraries, input paths, all measurement code and seed unchanged. |
| Native `read_results.py` | Keep `ROOT` pointing at original source/build evidence; point `NATIVE`/output to confirmation/native. Use original namespace protocol as prior protocol, new script hashes and minimal preparation binding. Full 672-worker reconstruction unchanged. |
| Python `python_worker.py`, `consumer_screen.py` | Byte-identical copies. Screen naturally invokes the copied worker beside it. Its `--build` argument points at the original namespace `consumers/build.json`. |
| Python `run.py` | Preserve existing subprocess loop, timeout/kill/reap and separate `prepare`/`time` phases. Set common build path to the original build receipt, **remove only the build job**, and accurately label six reused modules/zero compiles. `prepare` runs fresh 72 preflights on CPU3; `time` still requires that fresh prepare receipt. |
| Python `preflight_review.py` | Keep original source/build/compile-vector/origin provenance checks against original study. Read fresh screen files and worker commands from confirmation/python; add the exact one-job fresh prepare-controller/log checks. Write a fresh preflight review there. Keep all 72 raw identities/canonicals/sample checks. Historical build checks must stay explicitly historical. |
| Python `elapsed_review.py` | Keep original source/build/module provenance paths; point fresh preflight binding, controller/logs, screen/worker paths and report/CSV outputs to confirmation/python. Expected screen argv uses original `--build` and fresh `--output`. Keep all 504-worker seeded-order, sample, destruction/GC, ratio and adverse-row arithmetic unchanged. |

Do not copy an old preflight or result into the new campaign. Keep the same seven pairs and seeded order; this isolates the scheduling window rather than changing the workload. Preserve partial files if a new attempt fails; do not overwrite/retry automatically.

## Held launch order

Parent first reviews/materializes the finalizer on CPU6. Then, only after a separately confirmed quiet window:

1. `python3 /tmp/oriole-namespace-scopes-confirmation/native/run.py` — fresh 84 preflights followed by 588 timed workers.
2. `taskset -c 6 python3 /tmp/oriole-namespace-scopes-confirmation/native/read_results.py` — saved audit, all 28 conditions and adverse rows.
3. Pinned CPython `-I -S /tmp/oriole-namespace-scopes-confirmation/python/run.py prepare` — fresh 72 preflights only; no build.
4. `taskset -c 6 python3 /tmp/oriole-namespace-scopes-confirmation/python/preflight_review.py` — saved origin/canonical gate.
5. Pinned CPython `-I -S /tmp/oriole-namespace-scopes-confirmation/python/run.py time` — 504 timed workers.
6. `taskset -c 6 python3 /tmp/oriole-namespace-scopes-confirmation/python/elapsed_review.py` — saved reconstruction, all 24 conditions and adverse rows.

Pinned CPython is `/home/dev-user/.local/share/uv/python/cpython-3.12.13-linux-x86_64-gnu/bin/python3`. Native: 672 total workers / 106,176 samples / 24 real + 4 generated conditions, 90s worker bound. Python: 576 total workers / 26,364 samples (25,788 measured + 576 warmups), 300s worker bound. Each elapsed campaign retains 1200s aggregate bound. Run serially, with no other compiler/parser/benchmark targets. Parent records the scheduling release separately; affinity alone is not proof of a quiet host.

Report original and confirmation campaigns separately with all adverse conditions. Do not pool samples, choose a favorable run silently, or reinterpret unchanged strict/API evidence as newly executed. No statistical-significance or platform-wide performance claim follows from a quiet rerun.
