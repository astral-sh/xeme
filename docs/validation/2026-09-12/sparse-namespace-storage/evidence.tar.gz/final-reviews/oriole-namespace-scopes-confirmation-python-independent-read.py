"""Reconstruct completed CPython confirmation and host counters; saved files only."""
from pathlib import Path
import ast
import csv
import hashlib
import json
import os

assert __debug__ and os.sched_getaffinity(0) == {6}
ROOT = Path('/tmp/oriole-namespace-scopes-confirmation')
D = ROOT/'python'
OLD = Path('/tmp/oriole-namespace-scopes-study/python')
H = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
J = lambda p: json.loads(Path(p).read_text())
assert H(D/'normal-review.json') == '91401127ee7e081c3162ab93cbefd18cb1acb5652678374cad8aea425b8c1030'
assert H(D/'preflight-review.json') == '733b6c2cca2631d2e531c831c57d10f0c55e5657b8f298d2bf72b5eaa32ae922'
assert H(OLD/'normal-review.json') == 'e7e4540623c42d4ae937c8536d9aaf59df1163e4c276c31da0458b259789bfbe'
for path, value in J(ROOT/'preparation.json')['pins'].items():
    assert H(path) == value, path
for name in ('python_worker.py', 'consumer_screen.py'):
    assert (D/name).read_bytes() == (OLD/name).read_bytes()

def replay(path, stop):
    text = path.read_text()
    tree = ast.parse(text)
    cut = next(i for i, node in enumerate(tree.body) if stop(node, text.splitlines()))
    scope = {'__file__': str(path), '__name__': 'independent_saved_confirmation_python_replay'}
    exec(compile(ast.Module(body=tree.body[:cut], type_ignores=[]), str(path), 'exec'), scope)
    return scope

pre = replay(D/'preflight_review.py', lambda node, lines: lines[node.lineno-1].startswith('output=C/'))
actual_pre = J(D/'preflight-review.json')
assert actual_pre == pre['result']
scope = replay(D/'elapsed_review.py', lambda node, lines: isinstance(node, ast.With) and lines[node.lineno-1].startswith('with csvpath.open'))
actual = J(D/'normal-review.json')
expected = dict(scope['report'])
expected['condition_csv_sha256'] = H(D/'normal-conditions.csv')
assert actual == expected
assert scope['D'] == OLD and scope['C'] == D and scope['S'] == D/'screen'
assert scope['a']['libraries'] == J(OLD/'adaptation.json')['libraries']
assert scope['build'] == J(OLD/'consumers/build.json')
with (D/'normal-conditions.csv').open(newline='') as stream:
    rows = list(csv.DictReader(stream))
assert rows == [{k: str(v) for k, v in row.items()} for row in scope['rows']]
assert actual['counts']['all_workers'] == 576 and actual['counts']['all_samples'] == 26364
assert actual_pre['extension_compiles'] == {'fresh': 0, 'reused': 6, 'total': 6}
assert len(actual['aggregates']['all']['adverse_conditions']) == 5
for mapping in (pre['pins'], scope['pins']):
    for path, value in mapping.items():
        assert H(path) == value, path

# Reuse the exact pure counter-delta function from the completed native audit.
native_reader = Path('/tmp/oriole-namespace-scopes-confirmation-native-independent-read.py')
native_audit = J('/tmp/oriole-namespace-scopes-confirmation-native-independent-review.json')
assert H(native_reader) == native_audit['reader_sha256']
tree = ast.parse(native_reader.read_text())
counter_fn = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'counters')
counter_scope = {}
exec(compile(ast.Module(body=[counter_fn], type_ignores=[]), str(native_reader), 'exec'), counter_scope)
counters = counter_scope['counters']
before = J(ROOT/'host-before-python.json')
during = J(ROOT/'host-during-python.json')
release = J(ROOT/'python-release.json')
controller = J(D/'time-controller.json')
assert before['status'] == 'observed' and before['affinity'] == [6]
assert during['status'] == 'completed' and during['phase'] == 'python'
assert during['controller_status'] == controller['status'] == 'passed'
assert during['controller_sha256'] == H(D/'time-controller.json')
assert during['monitor_sha256'] == H(ROOT/'monitor-host.py')
assert release['host_observation_sha256'] == H(ROOT/'host-before-python.json')
assert release['preflight_review_sha256'] == H(D/'preflight-review.json')
timing, = controller['jobs']
assert before['samples'][-1]['time'] <= release['released_at'] <= timing['start']
before_summary = counters(before['samples'][0], before['samples'][-1])
assert before_summary['idle_including_iowait_fractions'] == before['idle_fractions']
intervals = [counters(a, b) for a, b in zip(during['samples'], during['samples'][1:])]
inside = [row for row in intervals if timing['start'] <= row['start'] and row['end'] <= timing['end']]
points = [point for point in during['samples'] if timing['start'] <= point['time'] <= timing['end']]
assert inside and len(points) >= 2
host = {'before': before_summary, 'during_sample_count': len(during['samples']),
        'during_observed_span': counters(during['samples'][0], during['samples'][-1]),
        'elapsed_controller': {'start': timing['start'], 'end': timing['end'], 'seconds': timing['end']-timing['start']},
        'sample_intervals_fully_inside_elapsed': {'count': len(inside), 'aggregate': counters(points[0], points[-1]),
            'other_cpus_idle_range': [min(row['other_cpus_idle_including_iowait_fraction'] for row in inside), max(row['other_cpus_idle_including_iowait_fraction'] for row in inside)]},
        'limitations': native_audit['host']['limitations']}
paths = [D/'preflight_review.py', D/'elapsed_review.py', D/'preflight-review.json', D/'normal-review.json', D/'normal-conditions.csv',
         D/'preparation.json', D/'prepare-controller.json', D/'time-controller.json', ROOT/'preparation.json',
         ROOT/'host-before-python.json', ROOT/'host-during-python.json', ROOT/'python-release.json', ROOT/'monitor-host.py',
         OLD/'normal-review.json', OLD/'consumers/build.json', native_reader]
result = {'status': 'independent_confirmation_python_raw_and_host_counters_verified', 'targets_executed': False,
          'role': 'Independent namespace runtime reviewer authored confirmation finalizer and adapted readers; root executed targets and initial readers. This audit replays saved preflight and elapsed assertions before output writes, checks exact reports/CSV, and independently reconstructs host counters.',
          'counts': actual['counts'], 'aggregates': actual['aggregates'], 'all_conditions': actual['summary'], 'host': host,
          'provenance': {'original_source_build_root': str(OLD), 'fresh_raw_root': str(D/'screen'), 'libraries': actual['libraries'],
                         'source_files_verified': len(scope['source']['sha256']), 'preflight_pins_verified': len(pre['pins']), 'elapsed_pins_verified': len(scope['pins']),
                         'fresh_compiles': 0, 'reused_modules': 6, 'old_attempt_unchanged': True},
          'limitations': ['All five adverse conditions retained; original shared-host attempt is separate, with no pooled or favorable-run selection.',
                         'Module paths and in-process dladdr parser origins, GC-enabled construction/feed/finalization/callback/destruction boundaries and canonical outputs match the original protocol.',
                         'This verifies counts, arithmetic and identities; it does not establish full callback compatibility, causal timing savings, statistical significance or OS-enforced host isolation.'],
          'pins_sha256': {str(path): H(path) for path in paths}, 'reader_sha256': H(__file__)}
out = Path('/tmp/oriole-namespace-scopes-confirmation-python-independent-review.json')
with out.open('x') as stream:
    stream.write(json.dumps(result, indent=2)+'\n')
print(json.dumps({'status': result['status'], 'path': str(out), 'sha256': H(out), 'counts': result['counts'], 'aggregates': result['aggregates'], 'host': host}, indent=2))
