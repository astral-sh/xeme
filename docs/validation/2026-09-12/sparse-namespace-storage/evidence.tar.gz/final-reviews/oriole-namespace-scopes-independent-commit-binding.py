"""Bind the completed independent raw review to the unchanged committed source."""
from pathlib import Path
import hashlib, io, json, os, subprocess, tarfile
assert os.sched_getaffinity(0)=={6}
W=Path('/home/dev-user/code/oss/oriole-namespace-scopes')
B=Path('/tmp/oriole-namespace-scopes-study')
commit='b9190cda8b04092a5691d8ec1cbefbc116f9e4e4'
base='19b285440bc7467debfa4901df36d86a0e4ef1a0'
review=Path('/tmp/oriole-namespace-scopes-independent-final-raw-review.json')
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert H(review)=='de0a4d765cbbfa1a6fe4159d7e716b5343d7c64d1c14cd47b89d00458ea2d6d3'
r=json.loads(review.read_text()); source=json.loads((B/'source.json').read_text())
assert r['status']=='passed_independent_namespace_saved_final_raw_review'
assert H(B/'source.json')==r['source']['manifest_sha256']
assert len(source['sha256'])==r['source']['count']==74
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD'],text=True).strip()==commit
assert subprocess.check_output(['git','-C',str(W),'rev-parse',commit+'^'],text=True).strip()==base
expected=sorted(r['source']['delta'])
assert subprocess.check_output(['git','-C',str(W),'diff',base,commit,'--name-only'],text=True).splitlines()==expected
archive=subprocess.check_output(['git','-C',str(W),'archive',commit,'--',*source['sha256']])
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:') as stream:
    committed={member.name:hashlib.sha256(stream.extractfile(member).read()).hexdigest() for member in stream if member.isfile()}
assert committed==source['sha256']
assert all(H(W/name)==digest for name,digest in committed.items())
assert subprocess.check_output(['git','-C',str(W),'diff',base,commit,'--',*expected])==(B/'candidate.patch').read_bytes()
assert H(B/'candidate.patch')==r['source']['patch_sha256']
assert all(H(B/'normal'/name)==digest for name,digest in r['build']['libraries'].items())
out={'status':'passed_committed_source_binding','targets_executed':False,'runtime_commit':commit,'parent':base,'source_files':74,'changed_files':expected,'committed_source_sha256':committed,'raw_review':{'path':str(review),'sha256':H(review)},'source_manifest_sha256':H(B/'source.json'),'complete_patch_sha256':H(B/'candidate.patch'),'libraries':r['build']['libraries'],'scope':'Read-only Git/archive-in-memory and file hashes. All74 measured source bytes equal the committed tree and live checkout. Original raw audit and its reader remain immutable; no target or raw audit rerun. Shared-host observations remain separate from any later quiet confirmation.','reader_sha256':H(__file__)}
path=Path('/tmp/oriole-namespace-scopes-independent-commit-binding.json')
with path.open('x') as stream:stream.write(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'commit':commit,'source_files':74,'path':str(path),'sha256':H(path)},indent=2))
