"""Independent saved-source/raw replay; never invokes a parser, compiler or benchmark."""
from pathlib import Path
from collections import Counter
import ast, hashlib, io, json, math, os, re, shlex, subprocess, tarfile
assert __debug__ and os.sched_getaffinity(0) == {6}
B = Path('/tmp/oriole-namespace-scopes-study')
C = Path('/tmp/oriole-namespace-scopes-correctness')
W = Path('/home/dev-user/code/oss/oriole-namespace-scopes')
CONTROL = Path('/tmp/oriole-text-plan-combined-study')
BASE = '19b285440bc7467debfa4901df36d86a0e4ef1a0'
pins = {}
def read(path):
    path = Path(path); data = path.read_bytes(); digest = hashlib.sha256(data).hexdigest()
    assert str(path) not in pins or pins[str(path)] == digest, path
    pins[str(path)] = digest
    return data
def sha(path):
    read(path); return pins[str(Path(path))]
def load(path): return json.loads(read(path))
def replay(path, expected, stop):
    text = read(path).decode(); assert sha(path) == expected, path
    tree = ast.parse(text, filename=str(path)); lines = text.splitlines()
    cut = next(i for i, node in enumerate(tree.body) if stop(lines[node.lineno-1]))
    scope = {'__file__': str(path), '__name__': 'independent_saved_namespace_replay'}
    exec(compile(ast.Module(body=tree.body[:cut], type_ignores=[]), str(path), 'exec'), scope)
    return scope

# Reviewed existing raw readers are replayed only before their output writes.
a = replay(C/'read_api_c.py', '36e7694eaf72f0dfc0e3e84545449a0f6ccf9b2f74b5e83039cf3329adddfedf', lambda s: s.startswith('dest = P /'))
ar = load(C/'api-c-readback.json')
assert sha(C/'api-c-readback.json') == 'ba69ad7d54e78220ae65b43441f7b64779636c29534e512f227c654b3c05ce98'
assert ar == a['result']
s = replay(C/'read_strict_semantics.py', 'ecc6a54628122912f28b4a9b23d65a253ab060bbebf75cadc5ff8b888fe471a7', lambda line: line.startswith("with (P / 'strict-semantic-readback.json')"))
sr = load(C/'strict-semantic-readback.json')
assert sha(C/'strict-semantic-readback.json') == '3823929564d596715a0295ae178430a67b4bd5924aabb6acf25e012b0c29545e'
assert isinstance(s['result']['strict']['shared']['supplementary_outcomes']['failure_headers'][0], tuple)
assert isinstance(sr['strict']['shared']['supplementary_outcomes']['failure_headers'][0], list)
assert sr == json.loads(json.dumps(s['result']))
for scope in [a, s]:
    for path, digest in scope['inputs'].items(): assert sha(path) == digest, path

source, prepared, build, binding = (load(path) for path in [B/'source.json', Path('/tmp/oriole-namespace-scopes-preparation/source.json'), B/'build.json', B/'build-binding.json'])
old_source, old_build = load(CONTROL/'source.json'), load(CONTROL/'build.json')
assert source['base'] == prepared['base'] == BASE and source['worktree'] == str(W)
assert len(source['sha256']) == prepared['source_count'] == 74
assert source['sha256'] == prepared['sha256'] and source['sha256'].keys() == old_source['sha256'].keys()
for name, expected in source['sha256'].items(): assert sha(W/name) == expected, name
# Read the immutable base tree once, without compressing or writing an archive.
base_bytes = subprocess.check_output(['git','-C',str(W),'archive',BASE,'--',*old_source['sha256']])
with tarfile.open(fileobj=io.BytesIO(base_bytes), mode='r:') as archive:
    base_map = {m.name: hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive if m.isfile()}
assert base_map == old_source['sha256']
delta = {name: {'control': old_source['sha256'][name], 'candidate': value} for name, value in source['sha256'].items() if value != old_source['sha256'][name]}
assert set(delta) == {'crates/oriole/src/lib.rs','crates/oriole/tests/adapter_frame.rs','crates/oriole/tests/allocation.rs'}
assert delta == binding['source_delta']
assert subprocess.check_output(['git','-C',str(W),'diff',BASE,'--',*sorted(delta)]) == read(B/'candidate.patch') == read('/tmp/oriole-namespace-scopes-preparation/candidate.patch')
assert sha(B/'candidate.patch') == prepared['complete_patch_sha256'] == binding['complete_patch_sha256']
assert binding['source_manifest_sha256'] == build['source_sha256'] == sha(B/'source.json')
assert binding['prepared_source_sha256'] == sha('/tmp/oriole-namespace-scopes-preparation/source.json')
assert binding['build_sha256'] == sha(B/'build.json')
assert build['status'] == binding['status'] == 'passed' and build['source_unchanged']
assert binding['control_source_manifest_sha256'] == sha(CONTROL/'source.json')
assert binding['control_build_sha256'] == sha(CONTROL/'build.json')
commands = build['commands']; old_commands = {r['label']:r for r in old_build['commands']}
assert [r['label'] for r in commands] == ['rustc-version','fmt','tests','clippy','release']
for row in commands:
    assert row['exit'] == 0 and row['reaped'] and row['end'] >= row['start']
    assert row['argv'] == old_commands[row['label']]['argv']
    assert sha(B/(row['label']+'.log')) == row['log_sha256']
assert all(a['end'] <= b['start'] for a,b in zip(commands, commands[1:]))
groups = re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', read(B/'tests.log').decode(), re.M)
assert len(groups) == 35 and all(status=='ok' and int(failed)==int(ignored)==0 for status,_,failed,ignored in groups)
assert sum(int(passed) for _,passed,_,_ in groups) == 451
assert binding['tests'] == {'passed':451,'groups':35,'failures':0,'ignored':0}
assert build['rustc'] == old_build['rustc'] == read(B/'rustc-version.log').decode()
actual_vectors = []
for line in read(B/'release.log').decode().splitlines():
    if 'Running `' in line and '/rustc ' in line:
        vector = shlex.split(line.strip()[len('Running `'):-1])
        if vector[vector.index('--crate-name')+1] in {'oriole','oriole_expat','oriole_storage'}: actual_vectors.append(vector)
assert actual_vectors == build['compiler_vectors']
def vectors(items):
    result = {}
    for v in items:
        assert not any(token in arg for token in ['profile-generate','profile-use','target-cpu','sanitize='] for arg in v)
        normalized = [str(Path(v[0]).resolve(strict=True))] + [re.sub(r'/home/dev-user/\.cache/ohm/verified-build/[0-9a-f]{2}/[0-9a-f]{14}(?=/)', '@WORKSPACE_BUILD@', arg) for arg in v[1:]]
        result[v[v.index('--crate-name')+1]] = normalized
    assert len(result)==len(items)==3
    return result
assert vectors(actual_vectors) == vectors(old_build['compiler_vectors']) == binding['compiler_vectors_normalized']
expected_libs = {'liboriole_expat.so':'d6303603fece314e683a5fda5dcb60334c7e302e5e8d87bd7dd13285e46bb63e','liboriole_expat.a':'7d9c06f7d6e63f602d98d95eeab35bfb5967f1cfa8154657f716dc9cedcea8bf'}
assert build['libraries'] == binding['candidate_libraries'] == expected_libs
for name, expected in expected_libs.items():
    assert sha(B/'normal'/name) == expected
    assert sha(Path('/home/dev-user/.cache/oriole/namespace-scopes-target/x86_64-unknown-linux-gnu/release')/name) == expected

l = replay(Path('/tmp/oriole-namespace-scopes-layout-read.py'), 'f566df629aafa8ec22931d8cebc36b03dcbc1de997982862fb67f42931e3d49c', lambda line: line.startswith("(D/'report.json').write_text"))
lr = load('/tmp/oriole-namespace-scopes-layout/report.json')
assert sha('/tmp/oriole-namespace-scopes-layout/report.json') == '624706e87229184dc1da51dffd45e25a55076cdc5fdbaee09b0e3260bf71491f'
assert lr == json.loads(json.dumps(l['out']))

# Native raw arithmetic already has a separately authored/executed review.
nr = load(B/'native/review.json'); ni = load('/tmp/oriole-namespace-scopes-native-independent-review.json')
assert sha(B/'native/review.json') == '6e977dab5a5dc08e1307370cd2aa3d104504e73f42bb0207b385b92e0956b010'
assert sha('/tmp/oriole-namespace-scopes-native-independent-review.json') == '8c8a6d6de0a066d9ecbd4fe04be0d748231b18b7332d9b3f535d84180e2012ba'
assert nr['counts'] == ni['counts'] and nr['groups'] == ni['groups']
for path, expected in ni['pins'].items(): assert sha(path) == expected, path

# Root explicitly confirmed the complete Python campaign and reader were reaped.
p = replay(B/'python/elapsed_review.py', '6f1a4abdd93b0ee947a7ffdea03825ce63b1d71299bdd62c3a200c4db2e6a95b', lambda line: line.startswith('csvpath='))
pr = load(B/'python/normal-review.json')
assert sha(B/'python/normal-review.json') == 'e7e4540623c42d4ae937c8536d9aaf59df1163e4c276c31da0458b259789bfbe'
for key in ['counts','aggregates','summary','libraries','source_results_sha256','source_preflight_sha256']: assert pr[key] == p['report'][key], key
for path, expected in p['pins'].items(): assert sha(path) == expected, path

strict = {}
for linkage, details in sr['strict'].items():
    raw = read(C/'strict-cpython'/linkage/'tests.log').decode()
    rendered = [m.group(0) for m in re.finditer(r'^(.+?) \.\.\. (ok|FAIL|ERROR|skipped.*|expected failure|unexpected success)$', raw, re.M)]
    subtest_lines = [line for line in rendered if line.startswith('  ')]
    class_lines = [line for line in rendered if line.startswith('setUpClass ')]
    ordinary = [line for line in rendered if line not in subtest_lines+class_lines]
    assert (len(ordinary),len(subtest_lines),len(class_lines),len(rendered)) == (800,8,1,809)
    assert Counter(details['full_method_map'].values())['subtest outcomes'] == 2
    strict[linkage] = {'methods':802,'rendered_lines':809,'ordinary_method_result_lines':800,'subtest_result_lines':8,'class_setup_skip_lines':1,'methods_reconstructed_from_subtests':2,'method_outcomes_sha256':hashlib.sha256(json.dumps(details['full_method_map'],sort_keys=True).encode()).hexdigest(),'status_counts':dict(Counter(details['full_method_map'].values())),'raw_exit':2,'failures':details['failures'],'changes':details['changes'],'consumer_fix':details['consumer_fix']}
python_adverse = [r for r in pr['summary'] if r['median_ratios']['candidate_over_control'] > 1]
assert len(python_adverse)==2
result = {'status':'passed_independent_namespace_saved_final_raw_review','targets_executed':False,'role':'Independent namespace evidence reviewer; no namespace runtime/test/controller or target authorship. Reviewed and replayed completed author-adapted API/C and strict/semantic readers through all assertions before their output writes; independently bound source/build and reconstructed Python raw arithmetic. Native raw arithmetic uses the separately audited completed review, explicitly identified.','source':{'base':BASE,'count':74,'delta':delta,'manifest_sha256':sha(B/'source.json'),'patch_sha256':sha(B/'candidate.patch'),'tag_and_text_unchanged':True},'build':{'tests':binding['tests'],'commands':commands,'libraries':expected_libs,'compiler_vectors_verified':3,'compiler_setting':'Generic normal O3/ThinLTO/cgu1; no PGO or target-cpu override. Compiler binary identities remain the saved build-binding evidence; this lightweight pass did not rehash LLVM.'},'api':{**ar['api'],'ordered_rows_sha256':hashlib.sha256(json.dumps(a['rows'][1],sort_keys=True).encode()).hexdigest(),'timeouts':[row for row in a['rows'][1] if row['outcome']=='timeout']},'c_consumers':ar['c_consumers'],'strict':strict,'semantics':sr['semantics'],'layout':{'report_sha256':sha('/tmp/oriole-namespace-scopes-layout/report.json'),'debug_sizes':{engine:{name:data['byte_size'] for name,data in entries.items() if name in ['Element','Parser']} for engine,entries in lr['layouts'].items()},'debug_deltas':lr['debug_deltas'],'normal_end_transfer':lr['optimized_end_transfer'],'limitations':lr['limitations']},'native':{'independent_review_sha256':sha('/tmp/oriole-namespace-scopes-native-independent-review.json'),'counts':nr['counts'],'groups':{name:{k:v for k,v in group.items() if k!='adverse'} for name,group in nr['groups'].items()},'adverse':ni['all_adverse'],'scope':'Completed existing independent raw audit retained and pinned; not rerun in this pass.'},'python':{'counts':pr['counts'],'aggregates':pr['aggregates'],'adverse':python_adverse,'raw_review_sha256':sha(B/'python/normal-review.json'),'scope':'All576 saved workers and26364 samples reconstructed; unmodified benchmark consumers, separately identified from strict cleanup-backport consumers.'},'limitations':['C harnesses use ASan/UBSan; Rust normal-release libraries are uninstrumented and leak checking was disabled.','The original API assertion failures/timeouts and two strict failures per linkage remain. Separate passing semantic tests do not turn the strict suites green.','Shared host: root reports another active Toucan task used this machine. CPU0 affinity and absence of concurrent targets inside this Oriole task do not establish a globally idle host. No quantified interference correction or settled speed conclusion is inferred; future quiet-host confirmation is a separate campaign.','No current sustained fuzz or installed PBS validation is established by these gates.'],'pins':pins,'reader_sha256':sha(__file__),'reader_first_attempt':{'scope':'Reader-only Python tuple versus serialized JSON list comparison corrected; no raw target or source outcome changed.','script_sha256':sha('/tmp/oriole-namespace-scopes-independent-final-raw-review-attempt01.py'),'stderr_sha256':sha('/tmp/oriole-namespace-scopes-independent-final-raw-review-attempt01.stderr'),'stdout_sha256':sha('/tmp/oriole-namespace-scopes-independent-final-raw-review-attempt01.stdout')},'findings':[]}
path=Path('/tmp/oriole-namespace-scopes-independent-final-raw-review.json')
with path.open('x') as stream: stream.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_files':74,'tests':binding['tests'],'api':ar['api'],'c_consumers':len(ar['c_consumers']),'strict_methods':{k:v['methods'] for k,v in strict.items()},'semantic_tests':[r['tests'] for r in sr['semantics']],'python_counts':pr['counts'],'python_aggregates':pr['aggregates']},indent=2))
