# Held namespace publication recipe

**Preparation only. Do not run the assembler until root releases the completed namespace Python campaign, all target processes are reaped, final independent reviews are available, and the publication decision/source commit is recorded.** No final report, archive, or repository change has been made here.

The unique destination is `docs/validation/2026-09-12/sparse-namespace-storage/`. All prior packets remain at their existing paths. The selected Text archive is the archive-recipe predecessor and runtime control; its isolated experiment is outside this packet.

## Existing completed evidence

- Current source74/three-file delta from PR156 `19b28544`: runtime `lib.rs`; tests `adapter_frame.rs` and `allocation.rs`. Reviewed prototype revision1 and revision2 remain under `/tmp/oriole-namespace-scopes-prototype`, including root's pre-compiler reserve-error conversion finding. Root formatting changed no source bytes.
- Normal build,451 workspace tests across35 groups, formatting and strict Clippy passed. Current SO is `d6303603...`; static library `7d9c06f7...`. Selected Text control is `ef1648fc...` / `cbe99d01...`; both source snapshots have74 files.
- Native raw audit:24 real and4 generated conditions, seven pairs,672 workers/106176 samples. Real candidate/control `0.9752834041875426` (2.47% less time), candidate/Expat `1.457056124380692`,20/24 wins. All four real adverse rows are Batik, largest2.36%. Generated aggregate regresses0.87%, with three of four conditions adverse. These are observations, not predictions or a layout-based causal attribution.
- Actual debug Element168→120 bytes; Parser2408→2464 bytes (**+56**). The optimized End frame transfer changes from a168-byte memcpy to120 bytes of inline loads/stores. Both versions still copy the72-byte ElementName afterward. The pool can retain peak metadata while an ancestor scope remains active, and namespace-every-depth can cost more metadata. No private heap/RSS claim.
- Original4740 API outcomes are exact:4347 passes,391 assertion failures,2 timeouts, raw exit1. All six C consumers pass. Strict shared/static each retain802 methods and809 rendered outcomes, unchanged two callback-grouping failures/raw exit2. Two separate semantic tests pass per linkage. Only C harnesses use ASan/UBSan; normal Rust libraries are uninstrumented and leak checking is disabled.

`required-inputs.json` records exact completed report hashes and every required remaining path. It deliberately names the real Python `prepare-controller.json` / `time-controller.json` and screen preflight/results records; there is no separate Python protocol.json in this inherited workflow.

## Shared-host limitation and disk recovery

These initial measurements are **shared-host paired observations**. Parent confirmed an active Toucan arena task on the same `charlie-oss-6` host through read-only app task inspection; that task used unrestricted Cargo tests/builds. CPU0 affinity and sequential Oriole target runs do not establish globally exclusive CPU use or an idle host. The arithmetic remains reproducible from saved observations, but the direction and size of interference are unknown. A quiet matched confirmation is needed before making strong claims about small gains. If root runs one, retain the initial results and report the confirmation separately.

`host-limitations.json` attributes this finding to parent inspection and records the limits of this preparer's review. `/tmp/oriole-space-recovery-20260912.json` separately documents removal of four clean obsolete worktrees while retaining branches, commits, raw evidence and shared cache. It is a disk-recovery receipt, not proof of concurrency or later host quietness. Original raw controllers remain unchanged; any local “exclusive” wording describes Oriole scheduling only.

## Remaining required evidence

1. Namespace Python preparation and elapsed readbacks are now complete: six fresh/reused module origins, exact compile vectors, 72 preflights + 504 timed workers, all 26,364 samples, all 24 rows and two adverse rows. The initial saved report is `initial-shared-host/report.json` (all 52 native/Python rows, nine adverse); selection and quiet confirmation remain pending. Reused selected/Expat extensions are control inputs with their own identities; candidate extensions must bind to the new library. Do not copy selected Text elapsed results as candidate results.
2. Any final independent Python/full-correctness review and root first-failure/recovery receipts. In particular, preserve the source-review ENOSPC launch limitation as a preparation/environment event if root records it; do not turn it into a parser failure or silently omit a started target attempt.
3. Root's publication decision and runtime commit, with all74 measured source hashes checked against its Git blobs (including a source-equivalent restack if needed). The source map identifies the measured precommit bytes; do not imply a rebuild after committing.
4. Final namespace report/prose/table, three proposed README/guide files, and a reviewed `additional-inputs.json` for extra named receipts. The existing prototype history, build logs and explicit archive inventory are already included, so the extra list should avoid duplicates.

## Derive the final report after release

Use current `/tmp/oriole-namespace-scopes-study/native/review.json`, `python/normal-review.json`, the two correctness readbacks, and `/tmp/oriole-namespace-scopes-layout/report.json` directly. Preserve full precision, separately group real/generated native and all/ElementTree/pyexpat Python, and list every adverse condition. The expected total is52 condition rows,1248 workers and132540 samples. Namespace native has seven adverse rows; derive the Python adverse count from its completed audit rather than assuming zero.

Follow the prior `draft.py` arithmetic for the six-row README sample: select4KiB/namespace-off native rows, use medians of seven process medians for displayed times and medians of paired ratios for the ratio column. Retain the process values in README-table.json. Do not divide rounded displayed times or add gains across separate campaigns. The final status/readiness prose must retain the roughly1.10× goal and any current-source fuzz/PBS gaps; historical sanitizer/PBS results remain historical.

Required derived inputs to `assemble.py`:

- `report.json`: `status=completed_normal_sparse_namespace_results`, `base=19b285440bc7467debfa4901df36d86a0e4ef1a0`, `source_count=74`, `source_manifest_sha256`, unique `publication_path`, `layout_report_sha256`, total `adverse_conditions`, runtime commit/source record, grouped actual metrics, compatibility and limitations. `host_conditions` must identify `initial_campaign=shared_host_paired`, `global_idle_not_established=true`, explicit `quiet_confirmation` status, and `limitation_record_sha256` for host-limitations.json.
- `report-README.md`: concise implementation/observed measurements, all regressions, layout plus Parser+56 tradeoff, original strict failures and scope.
- `committed-source.json`, `README-table.json` and `README-table.md`.
- `draft/README.md`, `draft/docs/compatibility.md`, `draft/docs/review.md`, and `draft/benchmarks/README.md`. The benchmark entrypoint must lead with the current normal namespace study (or its held shared-host status), label older PGO/LTO results historical, and state that new performance work uses O3/ThinLTO/one codegen unit and PGO experiments have stopped. Preserve all historical values and links. The exact warning and License from PR156 are frozen in README-preserved-sections.json; assembly asserts those sections unchanged. Root owns eventual repository edits. Add a new historical link; never overwrite an earlier packet or rewrite its measured source identity.
- `additional-inputs.json` with `status=reviewed_complete_input_list` and explicit path/member/SHA rows for final independent reviews or retained first-attempt records. `additional-inputs.template.json` is an unexecuted checklist template.

## Held assembly

After root's explicit release, run `taskset -c 6 python3 -I assemble.py --released` from this directory. Root can instead delegate that saved-data execution after the same gate. The helper's `add/tree`, binary exclusion, deterministic gzip, sorted member index, archive readback and original-byte readback are the existing recipe; their bodies are unchanged. `assemble.py.patch` records inventory and scope adaptations.

The packet includes candidate/control source maps, build/compiler logs, all namespace native/Python raw workers and stdout/stderr, full original correctness records, actual DWARF/disassembly/raw commands, prototype/formatting history, readers/controllers and corpus licenses. It excludes binaries, target/cache trees, compiler profiles, bytecode and machine Cargo configuration; their audited identities remain in index metadata. Inherited isolated Text pins retain identities only. No isolated Text source/elapsed campaign is added directly.

The final packet contains README/report, full/adverse CSVs, README table/source binding, evidence.tar.gz and index.json. Run final independent archive/member/source/summary/link readback before root commits/publishes. No assembler, compressor, parser, compiler, benchmark or Git write was executed during this preparation.

`benchmarks-README.draft.md` is the source-only entrypoint update, held pending the final publication decision. It is not copied into the final draft automatically.

The initial draft has no runtime selection or commit claim. If a quiet confirmation is run, its raw observations must be added separately with their own identities before adapting the final report and assembler counts. Do not silently replace the initial `native` or `python` trees. The main README table remains unchanged until root decides.
