"""Package completed namespace-only normal evidence with the existing tar recipe."""
from pathlib import Path
import csv, gzip, hashlib, io, json, os, sys, tarfile
assert __debug__ and os.sched_getaffinity(0)=={6}
assert sys.argv[1:] == ['--released'], 'Root release after completed gates/Python required'
PREP=Path(__file__).parent
DRAFT=PREP/'draft'
OUT=DRAFT/'docs/validation/2026-09-12/sparse-namespace-storage'
STUDY=Path('/tmp/oriole-namespace-scopes-study')
CONTROL=Path('/tmp/oriole-text-plan-combined-study')
CORRECT=Path('/tmp/oriole-namespace-scopes-correctness')
LAYOUT=Path('/tmp/oriole-namespace-scopes-layout')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
assert not OUT.exists()
draft=read(PREP/'report.json')
preserved=read(PREP/'README-preserved-sections.json')
readme=(DRAFT/'README.md').read_text()
assert readme[readme.index('> [!WARNING]'):readme.index('## Highlights')]==preserved['warning']
assert readme[readme.index('## License'):]==preserved['license']
assert all((DRAFT/name).is_file() for name in ['docs/compatibility.md','docs/review.md','benchmarks/README.md'])
native=read(STUDY/'native/review.json'); python=read(STUDY/'python/normal-review.json')
layout=read(LAYOUT/'report.json')
api=read(CORRECT/'api-c-readback.json'); strict=read(CORRECT/'strict-semantic-readback.json')
assert draft['status']=='completed_normal_sparse_namespace_results'
assert draft['base']=='19b285440bc7467debfa4901df36d86a0e4ef1a0' and draft['source_count']==74
assert draft['source_manifest_sha256']==sha(STUDY/'source.json')
assert draft['publication_path']=='docs/validation/2026-09-12/sparse-namespace-storage'
assert draft['layout_report_sha256']==sha(LAYOUT/'report.json')
host=read(PREP/'host-limitations.json')
assert draft['host_conditions']['initial_campaign']=='shared_host_paired'
assert draft['host_conditions']['global_idle_not_established'] is True
assert draft['host_conditions']['quiet_confirmation']
assert draft['host_conditions']['limitation_record_sha256']==sha(PREP/'host-limitations.json')
assert sha(host['recovery_receipt']['path'])==host['recovery_receipt']['sha256']
assert read(STUDY/'build-binding.json')['tests']=={'passed':451,'groups':35,'failures':0,'ignored':0}
assert layout['status']=='verified_saved_debug_layout_and_release_end_transfer'
assert layout['debug_deltas']=={'Element':-48,'Parser':56}
assert native['counts']['all_workers']==672
assert python['counts']['all_workers']==576
assert api['api']['counts']=={'pass':4347,'fail':391,'timeout':2}
assert all(x['methods']==802 and x['raw_exit']==2 and x['changes']==[] for x in strict['strict'].values())
# Existing explicit add/tree, deterministic gzip, index and full-member readback.
entries, originals, excluded, pins = {}, {}, {}, {}
def add_data(data, member, original):
    assert member not in entries, member
    assert not data.startswith((b'\x7fELF', b'!<arch>\n')), original
    entries[member], originals[member] = data, str(original)
def add(path, member):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert path.suffix not in {'.pyc','.profraw','.profdata','.a','.so'}, path
    add_data(path.read_bytes(), member, path)
def is_external(path):
    path = Path(path)
    if path.suffix in {'.pyc','.profraw','.profdata','.a','.so'} or '.so.' in path.name:
        return True
    with path.open('rb') as f: return f.read(8).startswith((b'\x7fELF',b'!<arch>\n'))
def exclude(path, reason):
    path=Path(path)
    row={'path':str(path),'sha256':sha(path),'size':path.stat().st_size,'reason':reason}
    if str(path) in excluded:
        previous=excluded[str(path)]
        assert all(previous[k]==row[k] for k in ('path','sha256','size')),path
        return
    excluded[str(path)]=row
def tree(root,prefix):
    root=Path(root);assert root.is_dir(),root
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts: continue
        if is_external(path): exclude(path,'Executable/library/bytecode/compiler-profile identity only')
        elif path.is_symlink(): raise AssertionError(f'unexpected nonbinary symlink: {path}')
        else: add(path,prefix+'/'+str(path.relative_to(root)))
def pin_map(values):
    for path,digest in values.items():
        assert isinstance(digest,str) and len(digest)==64,(path,digest)
        assert path not in pins or pins[path]==digest,path
        pins[path]=digest


source_maps={};source_hashes={};dedup={}
for label,study in [('candidate',STUDY),('control',CONTROL)]:
    source=read(study/'source.json'); assert len(source['sha256'])==74
    mapping={}
    for name,h in source['sha256'].items():
        path=Path(source['worktree'])/name; assert sha(path)==h,path
        if (name,h) not in dedup:
            member='source/'+label+'/'+name;add(path,member);dedup[name,h]=member
        mapping[name]=dedup[name,h]
    source_maps[label]=mapping;source_hashes[label]=source['sha256']
    add(study/'source.json','source/'+label+'-manifest.json')
for name in ['LICENSE-APACHE','LICENSE-MIT','THIRD_PARTY_LICENSES.md','licenses/expat.txt','licenses/libxml2.txt','licenses/cpython.txt']:
    add(Path(read(STUDY/'source.json')['worktree'])/name,'source/licenses/'+name)
source_map={'member_maps':source_maps,'sha256':source_hashes,'scope':'Namespace candidate and selected Text control each have74 source files. Shared equal bytes map to the same member; the two identities remain separate. No isolated Text experiment is included.'}
add_data((json.dumps(source_map,indent=2)+'\n').encode(),'source/member-map.json','generated from two verified source manifests')
add(PREP/'committed-source.json','source/committed-source.json')
for label,study in [('candidate',STUDY)]:
    for p in sorted(study.iterdir()):
        if p.is_file():add(p,label+'/build/'+p.name)
    tree(study/'native',label+'/native')
tree(STUDY/'python','candidate/python')
tree(CORRECT,'candidate/correctness')
tree('/tmp/oriole-namespace-scopes-preparation','candidate/author-preparation')
tree('/tmp/oriole-namespace-scopes-prototype','candidate/prototype-history')
tree(LAYOUT,'candidate/layout')
for label,study in [('control',CONTROL)]:
    for name in ['build.json','source.json','build-binding.json','rustc-version.log','tests.log','clippy.log','fmt.log','release.log']:
        add(study/name,label+'/build/'+name)
reviews=[
'/tmp/oriole-namespace-scopes-independent-source-review.json',
'/tmp/oriole-namespace-scopes-native-independent-review.json',
'/tmp/oriole-namespace-scopes-native-independent-read.py',
'/tmp/oriole-namespace-scopes-correctness-independent-preparation-review.json',
'/tmp/oriole-namespace-scopes-python-independent-preparation-review.json',
'/tmp/oriole-namespace-scopes-build.py','/tmp/oriole-namespace-scopes-bind.py',
'/tmp/oriole-namespace-scopes-bind.py.patch',
'/tmp/oriole-namespace-scopes-native-prepare.py','/tmp/oriole-namespace-scopes-native-prepare.py.patch',
'/tmp/oriole-namespace-scopes-native-source-preparation.json',
'/tmp/oriole-namespace-scopes-correctness-prepare.py','/tmp/oriole-namespace-scopes-correctness-prepare.py.patch',
'/tmp/oriole-namespace-scopes-correctness-source-preparation.json',
'/tmp/oriole-namespace-scopes-python-source-prepare.py',
'/tmp/oriole-namespace-scopes-layout-capture.py','/tmp/oriole-namespace-scopes-layout-disassemble.py',
'/tmp/oriole-namespace-scopes-layout-read.py',
'/tmp/oriole-namespace-undo-current-triage/README.md']
# Root supplies any final independent Python/full-correctness receipt and first-attempt logs here.
# The explicit reviewed list is publication input, not a discovery framework.
additional=read(PREP/'additional-inputs.json')
assert additional['status']=='reviewed_complete_input_list'
for row in additional['files']:
    assert sha(row['path'])==row['sha256']
    add(row['path'],row['member'])
for path in reviews:add(path,'reviews/'+Path(path).name)
add(host['recovery_receipt']['path'],'environment/space-recovery-20260912.json')
for name in ['report.json','report-README.md','README-table.json','README-table.md','required-inputs.json','REQUIRED_INPUTS.md','additional-inputs.json','README-preserved-sections.json','host-limitations.json']:
    add(PREP/name,'publication/'+name)
for p in sorted(DRAFT.rglob('*')):
    if p.is_file():add(p,'publication/draft/'+str(p.relative_to(DRAFT)))
add(__file__,'preparation/assemble.py')
add(PREP/'prior/assemble.py','preparation/prior-archive-recipe.py')
for values in [native['inputs'],layout['pins'],api['inputs'],strict['inputs'],python['evidence_sha256'],read(STUDY/'python/preflight-review.json')['pins'],read(STUDY/'python/consumer-binding.json')['pins'],read(STUDY/'python/reuse.json')['pins']]:pin_map(values)
for study,kind in [(STUDY,'native/native-screen'),(STUDY,'python/screen')]:
    data=read(study/kind/'results.json');assert data['hashes_before']==data['hashes_after'];pin_map(data['hashes_before'])
corpus=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
add(corpus,'inputs/corpus-manifest.json')
for project in read(corpus)['projects']:
    for item in project['files']:
        p=corpus.parent/item['path'];assert sha(p)==item['sha256'];add(p,'inputs/'+item['path'])
for path,member in [('/tmp/oriole-grammar-bench-plain/entities.xml','inputs/generated/entities.xml'),('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml','inputs/generated/rare-declarations.xml')]:add(path,member)
archived_paths=set(originals.values())
for path,h in sorted(pins.items()):
    p=Path(path);assert sha(p)==h,p
    if path in archived_paths:continue
    machine_config=p.name in {'config','config.toml'} and '.cargo' in p.parts
    historical_isolated=path.startswith(('/tmp/oriole-text-plan-study/','/tmp/oriole-text-plan-preparation/'))
    if historical_isolated:exclude(p,'Historical isolated Text input referenced by an inherited pin; digest only, outside namespace campaign')
    elif is_external(p) or machine_config:exclude(p,'External executable/library/compiler-profile or machine configuration; audited identity retained')
    else:add(p,'other-pinned-inputs/'+str(p).lstrip('/'))
assert sum(n.startswith('candidate/native/native-screen/worker-') for n in entries)==672
assert not any(n.startswith('isolated/') for n in entries)
assert sum(n.startswith('candidate/python/screen/') and n.endswith('-0.json') for n in entries)==576
assert sum(n.startswith('candidate/python/screen/') and n.endswith(('-stdout.gz','-stderr.gz')) for n in entries)==1152
assert not any(n.endswith('.callgrind') for n in entries)
conditions=[]
for campaign,consumer,values in [('namespace','native',native['all_conditions']),('namespace','python',python['summary'])]:
    for row in values:
        c,r=row['condition'],row['median_ratios']
        conditions.append({'campaign':campaign,'consumer':consumer,'project':c['name'],'chunk_bytes':c['chunk'],'namespace_or_mode':c.get('mode',str(c.get('namespaces','')).lower()),**r,'adverse':r['candidate_over_control']>1})
assert len(conditions)==52
adverse=[r for r in conditions if r['adverse']]
assert sum(r['consumer']=='native' for r in adverse)==7
assert len(adverse)==draft['adverse_conditions']
OUT.mkdir(parents=True)
for name,rows in [('conditions.csv',conditions),('adverse-conditions.csv',adverse)]:
    with (OUT/name).open('x',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
for name in ['README-table.json','README-table.md','committed-source.json']:(OUT/name).write_bytes((PREP/name).read_bytes())
members=[]
with (OUT/'evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for member,data in sorted(entries.items()):
                info=tarfile.TarInfo(member);info.size,info.mode,info.mtime=len(data),0o644,0
                archive.addfile(info,io.BytesIO(data))
                members.append({'member':member,'original_path':originals[member],'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive_path=OUT/'evidence.tar.gz'
with tarfile.open(archive_path,'r:gz') as archive:
    actual=archive.getmembers();assert [m.name for m in actual]==[r['member'] for r in members]
    for member,row in zip(actual,members,strict=True):
        assert member.isfile() and member.size==row['size']
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==row['sha256']
for member,path in originals.items():
    if path.startswith('/'):
        assert Path(path).read_bytes()==entries[member],path
index={'schema':'saved-record-bundle-v1','archive':'evidence.tar.gz','archive_sha256':sha(archive_path),'archive_bytes':archive_path.stat().st_size,'archive_readback_passed':True,'members':members,'excluded':list(excluded.values())}
(OUT/'index.json').write_text(json.dumps(index,indent=2)+'\n')

report=draft | {'evidence':{'archive_sha256':sha(archive_path),'archive_bytes':archive_path.stat().st_size,'members':len(members),'index_sha256':sha(OUT/'index.json'),'readback_passed':True,'all_conditions':52,'native_adverse_conditions':7,'python_adverse_conditions':sum(r['consumer']=='python' for r in adverse),'conditions_sha256':sha(OUT/'conditions.csv'),'adverse_sha256':sha(OUT/'adverse-conditions.csv')},'source_members':'source/member-map.json','native_all_conditions':native['all_conditions'],'python_all_conditions':python['summary'],'layout':layout}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
body=(PREP/'report-README.md').read_text()+f'\n## Raw evidence\n\n[evidence.tar.gz](evidence.tar.gz) contains {len(members):,} indexed files ({archive_path.stat().st_size:,} compressed bytes). [index.json](index.json) records every member hash, original path, size and excluded executable/library identity. Every archived member and original was read back after writing. [conditions.csv](conditions.csv) includes all 52 namespace rows; [adverse-conditions.csv](adverse-conditions.csv) includes all {len(adverse)} adverse conditions (seven native; {sum(r['consumer']=='python' for r in adverse)} Python). [report.json](report.json) retains full precision and limits.\n\nArchive SHA-256: `{sha(archive_path)}`. Executables, libraries, compiler profiles and machine configuration are excluded. The source member map reconstructs the namespace candidate and selected Text control snapshots. The isolated Text experiment is outside this packet.\n'
(OUT/'README.md').write_text(body)
result={'status':'packet_assembled_readback_passed','packet':str(OUT),'archive_sha256':sha(archive_path),'members':len(members),'bytes':archive_path.stat().st_size,'report_sha256':sha(OUT/'report.json'),'index_sha256':sha(OUT/'index.json')}
(PREP/'assembly.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
