"""Derive namespace publication prose from two separate completed normal campaigns."""
from pathlib import Path
import difflib, hashlib, json, os, re, shutil, statistics
assert __debug__ and os.sched_getaffinity(0)=={6}
P=Path(__file__).parent; D=P/'draft'; W=Path('/home/dev-user/code/oss/oriole-namespace-scopes')
B=Path('/tmp/oriole-namespace-scopes-study'); Q=Path('/tmp/oriole-namespace-scopes-confirmation'); C=Path('/tmp/oriole-namespace-scopes-correctness')
COMMIT='b9190cda8b04092a5691d8ec1cbefbc116f9e4e4'; BASE='19b285440bc7467debfa4901df36d86a0e4ef1a0'
DEST='docs/validation/2026-09-12/sparse-namespace-storage'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
save=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n')
assert not D.exists()
inputs={str(p):h for p,h in [(B/'native/review.json','6e977dab5a5dc08e1307370cd2aa3d104504e73f42bb0207b385b92e0956b010'),(B/'python/normal-review.json','e7e4540623c42d4ae937c8536d9aaf59df1163e4c276c31da0458b259789bfbe'),(Q/'native/review.json','9e7f5f54e92462c890a45277afdd211ba538912e96a8509163e83c5a7c8b706d'),(Q/'python/normal-review.json','91401127ee7e081c3162ab93cbefd18cb1acb5652678374cad8aea425b8c1030'),(C/'api-c-readback.json','ba69ad7d54e78220ae65b43441f7b64779636c29534e512f227c654b3c05ce98'),(C/'strict-semantic-readback.json','3823929564d596715a0295ae178430a67b4bd5924aabb6acf25e012b0c29545e')]}
for p,h in inputs.items():assert sha(p)==h,p
source=load(B/'source.json');binding=load(B/'build-binding.json');commit=load('/tmp/oriole-namespace-scopes-independent-commit-binding.json')
assert commit['status']=='passed_committed_source_binding' and commit['runtime_commit']==COMMIT and commit['parent']==BASE
assert commit['committed_source_sha256']==source['sha256'] and len(source['sha256'])==74
for name,h in source['sha256'].items():assert sha(W/name)==h
save(P/'committed-source.json',commit)
api=load(C/'api-c-readback.json');strict=load(C/'strict-semantic-readback.json')
assert api['api']['counts']=={'pass':4347,'fail':391,'timeout':2}
assert all(r['methods']==802 and r['rendered_outcome_lines']==809 and r['raw_exit']==2 and r['changes']==[] for r in strict['strict'].values())
assert binding['tests']=={'passed':451,'groups':35,'failures':0,'ignored':0}
initial_host=load(P/'host-limitations.json')
host_reviews={kind:load('/tmp/oriole-namespace-scopes-confirmation-'+kind+'-independent-review.json') for kind in ('native','python')}
for kind in ('native','python'):inputs['/tmp/oriole-namespace-scopes-confirmation-'+kind+'-independent-review.json']=sha('/tmp/oriole-namespace-scopes-confirmation-'+kind+'-independent-review.json')
epochs={};conditions=[]
for name,root in [('initial-shared-host',B),('confirmation',Q)]:
 native=load(root/'native/review.json');python=load(root/'python/normal-review.json')
 assert native['counts']['all_workers']==672 and python['counts']['all_workers']==576
 assert native['counts']['all_samples']==106176 and python['counts']['all_samples']==26364
 groups={k:{a:b for a,b in v.items() if a not in ('adverse','adverse_conditions')} for k,v in native['groups'].items()}
 pgroups={k:{a:b for a,b in v.items() if a not in ('adverse','adverse_conditions')} for k,v in python['aggregates'].items()}
 epochrows=[]
 for consumer,rows in [('native',native['all_conditions']),('python',python['summary'])]:
  for row in rows:
   c=row['condition'];r=row['median_ratios']
   epochrows.append({'campaign':name,'consumer':consumer,'project':c['name'],'chunk_bytes':c['chunk'],'namespace_or_mode':c.get('mode',str(c.get('namespaces','')).lower()),**r,'adverse':r['candidate_over_control']>1})
 assert len(epochrows)==52
 adverse=[r for r in epochrows if r['adverse']]
 assert len(adverse)==(9 if name=='initial-shared-host' else 15)
 epochs[name]={'native':{'counts':native['counts'],'groups':groups},'python':{'counts':python['counts'],'groups':pgroups},'adverse':adverse,'source_results':{'native':{'path':str(root/'native/review.json'),'sha256':sha(root/'native/review.json')},'python':{'path':str(root/'python/normal-review.json'),'sha256':sha(root/'python/normal-review.json')}}}
 conditions.extend(epochrows)
assert len(conditions)==104
# Preserve the original seven-pair table calculation; use only confirmation rows.
native=load(Q/'native/review.json');python=load(Q/'python/normal-review.json');rows=load(Q/'native/native-screen/results.json')['rows'];table=[]
for name,label in {'vulkan':'Vulkan registry','wayland':'Wayland protocol','maven':'Maven POM','batik':'Batik SVG','gtk':'GTK UI','docbook':'DocBook XSL'}.items():
 selected=[r for r in rows if r['condition']['name']==name and r['condition']['chunk']==4096 and not r['condition']['namespaces']];assert len(selected)==7
 values={engine:[next(p['median_seconds'] for p in r['processes'] if p['engine']==engine) for r in selected] for engine in ['candidate','expat']}
 summary=next(r for r in native['all_conditions'] if r['condition']==selected[0]['condition'])
 table.append({'project':name,'label':label,'candidate_ms':statistics.median(values['candidate'])*1000,'expat_ms':statistics.median(values['expat'])*1000,'paired_ratio':summary['median_ratios']['candidate_over_expat'],'process_medians_seconds':values})
text='| Project XML | Oriole (normal) | Expat (normal) | Oriole / Expat |\n| --- | ---: | ---: | ---: |\n'+''.join(f"| {r['label']} | {r['candidate_ms']:.3f} ms | {r['expat_ms']:.3f} ms | {r['paired_ratio']:.3f}× |\n" for r in table)
(P/'README-table.md').write_text(text);save(P/'README-table.json',{'campaign':'confirmation','scope':'4KiB/ns0; times are medians of seven process medians; ratios are medians of paired process ratios. Initial observations are not pooled.','rows':table})
ng=native['groups'];pg=python['aggregates'];ngain=(1-ng['real']['geomean_ratios']['candidate_over_control'])*100;pgain=(1-pg['all']['geomean_ratios']['candidate_over_control'])*100
native_host=host_reviews['native']['host'];python_host=host_reviews['python']['host']
host={'initial_campaign':'shared_host_paired','global_idle_not_established':True,'quiet_confirmation':'completed_monitored_shared_host_window_not_enforced_isolation','limitation_record_sha256':sha(P/'host-limitations.json'),'initial':initial_host,'confirmation':{'native':native_host,'python':python_host},'scope':'Both epochs are retained separately. CPU0 affinity and local scheduling do not establish globally exclusive CPU, cache or memory bandwidth. Idle values include iowait; the five-second sampled observations do not cover every instant.'}
report={'status':'completed_normal_sparse_namespace_results','decision':'retain_smaller_Element_with_consistent_modest_aggregate_observations','runtime_commit':COMMIT,'base':BASE,'source_count':74,'source_manifest_sha256':sha(B/'source.json'),'publication_path':DEST,'layout_report_sha256':sha('/tmp/oriole-namespace-scopes-layout/report.json'),'adverse_conditions':24,'epochs':epochs,'all_counts':{'conditions':104,'workers':2496,'samples':265080,'adverse':24},'host_conditions':host,'source_binding':commit,'build':binding,'libraries':python['libraries'],'compatibility':{'api':api['api'],'c_consumers':len(api['c_consumers']),'strict':{k:{x:r[x] for x in ['methods','rendered_outcome_lines','raw_exit','changes','failures']} for k,r in strict['strict'].items()},'semantics':strict['semantics']},'readme_table':table,'inputs':inputs,'roles':'Namespace implementation author prepared this packet and adapted source/build/native/correctness helpers. Root ran all targets and primary saved readers. Separate agents reviewed source/protocols, independently reconstructed initial and confirmation results and inspected layout/host records. Final publication packet review is separate.','limitations':['Both epochs use one shared Linux host. Confirmation followed another task reporting its comparison complete, with before/during counter observations; no enforced isolation or statistical-significance claim.','Initial and confirmation medians remain separate; gains are not pooled or added across campaigns.','Native namespace-enabled confirmation is effectively flat; every adverse condition remains.','Element shrinks48 bytes while Parser grows56; namespace-every-depth may add metadata and an active ancestor can retain peak pool capacity. No measured private heap/RSS or causal elapsed attribution.','Oriole uses normal generic O3/ThinLTO/one-codegen-unit. The pinned Expat2.8.4 control uses GCC13.3 O3 without LTO; unmodified CPython3.12.13 extensions use O2. No new PGO investment.','Project XML parsing is not whole-application performance.','API391 assertion failures/two timeouts and strict two callback-grouping failures per linkage remain. Benchmark text coalescing is a narrower oracle.','C ASan/UBSan harnesses link uninstrumented Rust, with leak checks disabled. No current namespace sustained fuzzing or installed PBS validation.'],'readme_warning_and_license_unchanged':True}
save(P/'report.json',report)
D.mkdir();(D/'docs').mkdir();(D/'benchmarks').mkdir()
old=(W/'README.md').read_text();new=re.sub(r'\| Project XML.*?\n\n',text+'\n',old,count=1,flags=re.S)
start=new.index('These [native measurements]');end=new.index('\n\n',start)
new=new[:start]+f"These [native measurements]({DEST}/) use sparse namespace storage with the selected Text plan and fused attribute scanner on original XML from six pinned projects, 4 KiB chunks and namespaces disabled. They come from a monitored confirmation window on a shared Linux AMD EPYC-Milan host; CPU affinity does not establish isolation. Oriole uses normal O3/ThinLTO with Ohm rustc 1.98.1-dev; Expat 2.8.4 uses GCC 13.3 O3 without LTO. Times are medians of seven process medians; ratios are medians of paired ratios."+new[end:]
start=new.index('Across their respective 24 real-project conditions,');end=new.index('\n\n',start)
new=new[:start]+f"Across their respective 24 real-project conditions, confirmation takes **1.45× Expat's native time and 1.19× its CPython time**, observed reductions of {ngain:.2f}% and {pgain:.2f}% against the preceding Text runtime. Native namespace-enabled time is essentially flat. Both aggregates remain above the roughly 1.10× target; five of 24 CPython conditions meet it. Native improves in 16 conditions and CPython in 19; the [full report]({DEST}/) retains every regression and the separate initial shared-host measurements. The smaller element record is retained with these modest aggregate gains; this is not a statistical-significance claim."+new[end:]
assert new[new.index('> [!WARNING]'):new.index('## Highlights')]==old[old.index('> [!WARNING]'):old.index('## Highlights')]
assert new[new.index('## Installation'):]==old[old.index('## Installation'):]
(D/'README.md').write_text(new)
compat=(W/'docs/compatibility.md').read_text();previous=compat.split('\n\n')[2]
assert previous.startswith('The [native ASCII Text plan]')
paragraph=f"The [sparse namespace storage report](validation/2026-09-12/sparse-namespace-storage/) binds the current source to `b9190cda`. Its normal-build confirmation takes 1.4461× Expat's native time and 1.1860× its CPython time, observed reductions of {ngain:.2f}% and {pgain:.2f}% against the preceding Text runtime. Five of 24 CPython conditions meet the roughly 1.10× goal; both aggregates remain above it. Namespace-enabled native time is essentially flat. All eight native real-input, two generated and five Python confirmation regressions remain, alongside the separate initial shared-host results. Before/during host counters qualify the confirmation window but do not establish isolation. Fresh checks preserve all 4,740 original API outcomes and 802 strict CPython method outcomes per linkage: 4,347 API passes, 391 assertion failures and two timeouts; the same two strict callback-grouping failures remain, and each strict suite exits 2. Strict consumers use the explicit upstream allocation-failure cleanup backport; benchmark consumers are unmodified. Six C consumers and two supplemental semantic tests per linkage pass. C harnesses use ASan/UBSan with uninstrumented Rust release libraries and leak detection disabled. Current-source sustained fuzzing and an installed PBS trial remain outstanding."
compat=compat.replace(previous,paragraph,1).replace("current Text candidate's unchanged original matrix","current namespace candidate's unchanged original matrix")
(D/'docs/compatibility.md').write_text(compat)
review=(W/'docs/review.md').read_text();oldtop=review.split('\n\n')[1]
newtop=f"The [sparse namespace storage report](validation/2026-09-12/sparse-namespace-storage/) records the selected `b9190cda` source and two separate normal-build campaigns. Nonempty namespace binding blocks move into a parser-owned sparse stack while each Element keeps a scalar index. Actual debug Element size falls from 168 to 120 bytes; Parser grows from 2408 to 2464 bytes. Separate optimized disassembly confirms the smaller End-frame transfer. Confirmation observes {ngain:.2f}% less native real-input time and {pgain:.2f}% less CPython time, remaining 1.45× and 1.19× Expat; namespace-enabled native time is essentially flat. The initial shared-host and monitored confirmation observations, all 24 adverse rows across both epochs, and host limitations are preserved separately. All 451 workspace tests, formatting, strict Clippy and six C consumers pass. Original API and strict CPython outcomes remain unchanged, including known failures; two supplemental semantic tests pass per linkage. No current-source sustained fuzzing or installed PBS result is inferred."
review=review.replace(oldtop,newtop,1)
history=oldtop.replace('records its normal native','records that source\'s normal native').replace('No current-source sustained fuzzing or installed PBS result is inferred.','That report does not claim sustained fuzzing or installed PBS validation for the Text source.')
review=review.replace('## Earlier source-specific reports\n\n','## Earlier source-specific reports\n\n'+history+'\n\n',1)
(D/'docs/review.md').write_text(review)
bench=(P/'benchmarks-README.draft.md').read_text();a=bench.index('The [sparse namespace storage study]');z=bench.index('\n\nNew performance work',a)
bench=bench[:a]+f"The [sparse namespace storage study](../{DEST}/)\ncontains the current normal-build measurements and validation records. A monitored\nconfirmation observes {ngain:.2f}% less native real-input time and {pgain:.2f}% less CPython\ntime against the preceding Text runtime. Native namespace-enabled time is\nessentially flat; all regressions and the separate initial shared-host campaign\nremain recorded. The host was shared: observed CPU counters and affinity do not\nestablish enforced isolation."+bench[z:]
bench=bench.replace('## Historical profile-guided builds','## Historical profile-guided builds')
(D/'benchmarks/README.md').write_text(bench)
for name in ['README.md','docs/compatibility.md','docs/review.md','benchmarks/README.md']:
 (P/(name.replace('/','-')+'.patch')).write_text(''.join(difflib.unified_diff((W/name).read_text().splitlines(True),(D/name).read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
summary='| Epoch / campaign | Candidate / control | Candidate / Expat | Lower-time conditions |\n| --- | ---: | ---: | ---: |\n'
for epoch in ['confirmation','initial-shared-host']:
 e=epochs[epoch]
 for label,g in [('Native real XML',e['native']['groups']['real']),('Native namespaces off',e['native']['groups']['real_namespaces_off']),('Native namespaces on',e['native']['groups']['real_namespaces_on']),('Native generated',e['native']['groups']['generated']),('CPython all',e['python']['groups']['all']),('ElementTree',e['python']['groups']['elementtree']),('pyexpat events',e['python']['groups']['pyexpat-events'])]:
  summary+=f"| {epoch}: {label} | {g['geomean_ratios']['candidate_over_control']:.6f}× | {g['geomean_ratios']['candidate_over_expat']:.6f}× | {g.get('candidate_faster_than_control',g.get('candidate_lower_than_control'))} / {g['conditions']} |\n"
n_idle=native_host['sample_intervals_fully_inside_elapsed']['aggregate']['other_cpus_idle_including_iowait_fraction']*100
p_idle=python_host['sample_intervals_fully_inside_elapsed']['aggregate']['other_cpus_idle_including_iowait_fraction']*100
body=f'''# Sparse namespace storage

Retain the smaller element record with modest, consistently favorable aggregate observations across two normal-build campaigns. The measured 74-file source matches runtime `{COMMIT}`, based on published Text `19b28544`. Confirmation observes **{ngain:.2f}% less native real-input time and {pgain:.2f}% less CPython time** against that Text control. Namespace-enabled native time is essentially flat. Native and Python remain **1.4461×** and **1.1860× Expat**, above the roughly 1.10× goal; five of 24 Python conditions meet it. These shared-host observations do not establish statistical significance or production readiness.

## Implementation and memory tradeoff

A parser-owned sparse stack stores only nonempty namespace binding blocks; each Element holds an optional scalar index. Start keeps local binding construction and namespace-map/event ordering, reserves both owners before committing, and retains existing name moves. End detaches its scope block before fallible event emission or reverse restoration so that failures drop the same owned bindings. Scope-free child elements leave ancestor blocks untouched; external children begin with a fresh pool.

The pool releases its allocation when empty if capacity exceeds a 4 KiB metadata threshold. An active ancestor can retain peak pool storage, and namespace declarations at every depth can add metadata. The change adds no unsafe code, public API, dependencies or SIMD and retains name ownership and source compaction.

Only `crates/oriole/src/lib.rs`, `crates/oriole/tests/adapter_frame.rs` and `crates/oriole/tests/allocation.rs` differ from the base. [committed-source.json](committed-source.json) binds all 74 measured source hashes to the later commit without claiming a rebuild after commit. Source reviews cover joint reserve/commit ordering, detached End ownership, scope-free descendants, external children, retention and allocation-failure cleanup.

Actual debug Element size falls **168→120 bytes**; Parser grows **2408→2464 bytes (+56)**. Separate optimized disassembly shows the End-frame transfer changing from a 168-byte memcpy to 120 bytes of inline loads/stores. Both versions still copy the 72-byte ElementName afterward. These artifacts establish layout and movement differences, not the cause of the elapsed result. Private heap/RSS was not measured.

## Separate normal campaigns

{summary}

Every ratio is the equally weighted geometric mean of condition-wise medians of seven paired process ratios. The two epochs are not pooled, and their gains are not added. The original and confirmation campaigns use identical libraries, inputs, conditions, seeds, callbacks and measurement boundaries. Confirmation builds no modules: all six previously verified O2 extensions are reused in place, with fresh preflights and timed workers.

Confirmation retains eight native real-input regressions (largest **2.02%**, Maven 4 KiB with namespaces), two generated-entity regressions (largest **3.38%**) and five Python regressions (largest **0.57%**, DocBook 64 KiB ElementTree). The initial campaign retains four real Batik regressions, three generated regressions and two Python regressions. All **104 condition rows / 24 adverse rows** remain in the full and adverse CSVs, with exact values in [report.json](report.json).

The featured README sample comes only from confirmation, 4 KiB feeds with namespaces off:

{text}
Times are medians of seven process medians; ratios are medians of seven paired process ratios and need not equal division of displayed times. Both native aggregates still exceed the goal, and the generated controls remain approximately 3.89× Expat in confirmation.

Each epoch has 28 native conditions, seven pairs, 84 preflights and 588 timed workers: **672 workers / 106,176 samples**. Python has 24 conditions, 72 preflights and 504 timed workers: **576 workers / 26,364 samples**. Across both epochs, totals are **2,496 workers / 265,080 samples**. Counts include saved preflight samples and warmups; only timed iterations enter elapsed medians. Native timers include the complete parser lifecycle. Python timers include construction/feed/finalization/callbacks and explicit destruction; imports, input reads, canonical checks and explicit collection stay outside, with automatic GC enabled. Original timeouts and process-group cleanup remain unchanged.

Oriole uses normal generic O3, ThinLTO and one codegen unit with Ohm rustc 1.98.1-dev and automatic Ohm defaults disabled. The pinned Expat 2.8.4 control uses GCC 13.3 O3 **without LTO**. Unmodified CPython 3.12.13 extensions use O2. Original build vectors, physical compiler identities, source and library hashes are retained. No new PGO or CPU-target experiment was performed.

## Host observations

The initial campaign ran while another Toucan arena task used unrestricted Cargo builds/tests on the same `charlie-oss-6` host. CPU0 affinity and sequential Oriole targets did not establish an idle host. Its complete results remain immutable and separate.

Before confirmation, the other task reported its performance comparison finished. Ten-second observations before native release showed 99.40% CPU0 and 99.65% aggregate idle+iowait; before Python release these were 97.69% and 96.99%. Five-second monitoring during fully contained elapsed intervals observed other CPUs averaging **{n_idle:.2f}% idle+iowait natively** and **{p_idle:.2f}% during Python**. Raw counters, release records and independent attribution are archived. This was a monitored shared-host window, not OS-enforced isolation or a fully idle host. Samples do not cover every instant, identify every process, or rule out cache, frequency and memory-bandwidth interference; no statistical-significance claim is made.

## Compatibility and remaining limits

All **451 workspace tests across 35 groups**, formatting and strict Clippy pass. Original **4,740 API configurations** remain exact: **4,347 pass / 391 assertion failures / two timeouts**, raw exit 1, with unchanged assertions and bounds. Six shared/static C integration, adversarial and allocation consumers pass. Their C harnesses use ASan/UBSan; Rust normal libraries remain uninstrumented and leak detection is disabled.

Each strict CPython linkage retains **802 method outcomes and 809 rendered outcome lines**, raw exit 2, including `test.test_pyexpat.BufferTextTest.test1` and `test.test_sax.CDATAHandlerTest.test_handlers`. Strict consumers carry the explicit upstream allocation-failure cleanup backport; benchmark consumers are unmodified. Two supplemental semantic tests pass per linkage and do not erase those strict failures. Benchmark callback coalescing checks a narrower contract than exact callback grouping. Historical relaxed-ceiling diagnostics, sustained sanitizer campaigns and PBS/glibc trials keep their original source identities. No current namespace sustained fuzzing or installed PBS validation is claimed.

## Preparation and review history

Root's source review caught a reserve-error conversion issue before compilation: both new `try_reserve` calls needed the existing `AllocError::from` mapping. Revision 1 and corrected revision 2 are preserved; this was not a failed compiler target. Root formatting changed no source bytes. ENOSPC prevented one independent source-review command from launching. Four clean obsolete worktrees were removed with commits, branches, raw evidence and shared cache retained. The disk-recovery receipt does not establish concurrency or later host quietness.

The independent raw reviewer retained a tuple-versus-JSON-list comparison correction and its first failure before passing the complete audit; this changed the reader only. The initial report's compiler wording was corrected to distinguish Oriole ThinLTO/codegen units from Expat's GCC O3 recipe. Historical pending drafts retain their labels alongside completed evidence. No target attempt was removed to hide a regression.

The namespace implementation author prepared this packet and adapted build/native/correctness helpers. Root ran targets and primary saved readers. Separate agents reviewed source/protocols, independently reconstructed the initial and confirmation raw results, bound the commit and inspected actual layout/host records. Final archive/documentation review is separate. All historical packets remain unchanged.
'''
(P/'report-README.md').write_text(body)
print(json.dumps({'status':'draft_complete','report_sha256':sha(P/'report.json'),'README_sha256':sha(P/'report-README.md'),'confirmation_table':table,'all_conditions':104,'adverse_conditions':24}))
