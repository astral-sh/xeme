"""Draft the completed initial shared-host namespace results; no target execution."""
from pathlib import Path
import csv, hashlib, json, os, statistics
assert __debug__ and os.sched_getaffinity(0)=={6}
P=Path(__file__).parent; OUT=P/'initial-shared-host'; OUT.mkdir(exist_ok=False)
B=Path('/tmp/oriole-namespace-scopes-study'); C=Path('/tmp/oriole-namespace-scopes-correctness')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
save=lambda p,v:Path(p).write_text(json.dumps(v,indent=2)+'\n')
inputs={str(p):h for p,h in [(B/'native/review.json','6e977dab5a5dc08e1307370cd2aa3d104504e73f42bb0207b385b92e0956b010'),(B/'python/normal-review.json','e7e4540623c42d4ae937c8536d9aaf59df1163e4c276c31da0458b259789bfbe'),(C/'api-c-readback.json','ba69ad7d54e78220ae65b43441f7b64779636c29534e512f227c654b3c05ce98'),(C/'strict-semantic-readback.json','3823929564d596715a0295ae178430a67b4bd5924aabb6acf25e012b0c29545e'),(Path('/tmp/oriole-namespace-scopes-layout/report.json'),'624706e87229184dc1da51dffd45e25a55076cdc5fdbaee09b0e3260bf71491f')]}
for p,h in inputs.items(): assert sha(p)==h,p
native=load(B/'native/review.json'); python=load(B/'python/normal-review.json')
api=load(C/'api-c-readback.json'); strict=load(C/'strict-semantic-readback.json'); binding=load(B/'build-binding.json')
source=load(B/'source.json'); host=load(P/'host-limitations.json'); layout=load('/tmp/oriole-namespace-scopes-layout/report.json')
assert len(source['sha256'])==74
assert binding['tests']=={'passed':451,'groups':35,'failures':0,'ignored':0}
assert api['api']['counts']=={'pass':4347,'fail':391,'timeout':2}
assert all(r['methods']==802 and r['rendered_outcome_lines']==809 and r['raw_exit']==2 and r['changes']==[] for r in strict['strict'].values())
conditions=[]
for consumer,rows in [('native',native['all_conditions']),('python',python['summary'])]:
 for r in rows:
  c=r['condition'];ratios=r['median_ratios']
  conditions.append({'campaign':'initial-shared-host','consumer':consumer,'project':c['name'],'chunk_bytes':c['chunk'],'namespace_or_mode':c.get('mode',str(c.get('namespaces','')).lower()),**ratios,'adverse':ratios['candidate_over_control']>1})
adverse=[r for r in conditions if r['adverse']]
assert len(conditions)==52 and len(adverse)==9
for name,rows in [('conditions.csv',conditions),('adverse-conditions.csv',adverse)]:
 with (OUT/name).open('x',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Same prior table arithmetic, kept in the candidate report only while selection is pending.
rows=load(B/'native/native-screen/results.json')['rows'];table=[]
for name,label in {'vulkan':'Vulkan registry','wayland':'Wayland protocol','maven':'Maven POM','batik':'Batik SVG','gtk':'GTK UI','docbook':'DocBook XSL'}.items():
 selected=[r for r in rows if r['condition']['name']==name and r['condition']['chunk']==4096 and not r['condition']['namespaces']];assert len(selected)==7
 values={engine:[next(p['median_seconds'] for p in r['processes'] if p['engine']==engine) for r in selected] for engine in ['candidate','control','expat']}
 summary=next(r for r in native['all_conditions'] if r['condition']==selected[0]['condition'])
 table.append({'project':name,'label':label,'candidate_ms':statistics.median(values['candidate'])*1000,'expat_ms':statistics.median(values['expat'])*1000,'paired_ratio':summary['median_ratios']['candidate_over_expat'],'process_medians_seconds':values})
save(OUT/'candidate-table.json',{'scope':'Initial shared-host candidate appendix only; selected main README table remains unchanged. 4KiB/ns0, medians of seven process medians, median of paired ratios.','rows':table})
groups={k:{a:b for a,b in v.items() if a not in ('adverse','adverse_conditions')} for k,v in native['groups'].items()}
pgroups={k:{a:b for a,b in v.items() if a not in ('adverse','adverse_conditions')} for k,v in python['aggregates'].items()}
report={'status':'completed_initial_shared_host_namespace_results','publication_status':'held_pending_quiet_confirmation_and_root_selection','publication_path':'docs/validation/2026-09-12/sparse-namespace-storage','base':source['base'],'runtime_commit':'pending_root_commit','source_count':74,'source_manifest_sha256':sha(B/'source.json'),'changed_files':['crates/oriole/src/lib.rs','crates/oriole/tests/adapter_frame.rs','crates/oriole/tests/allocation.rs'],'libraries':python['libraries'],'build':{'tests':binding['tests'],'build_binding_sha256':sha(B/'build-binding.json')},'host_conditions':host|{'limitation_record_sha256':sha(P/'host-limitations.json')},'native':{'counts':native['counts'],'groups':groups},'python':{'counts':python['counts'],'groups':pgroups},'all_counts':{'conditions':52,'workers':1248,'samples':132540,'adverse_conditions':9},'all_conditions':conditions,'adverse_conditions':adverse,'layout_report_sha256':sha('/tmp/oriole-namespace-scopes-layout/report.json'),'layout':{'debug_Element_bytes':[168,120],'debug_Parser_bytes':[2408,2464],'optimized_End_transfer':'168-byte memcpy becomes observed120-byte inline loads/stores; both subsequent72-byte ElementName copies remain.','scope':'Debug layout and separately observed optimized movement; no private heap/RSS or causal elapsed claim.'},'compatibility':{'api':api['api'],'c_consumers':len(api['c_consumers']),'strict':{k:{n:r[n] for n in ['methods','rendered_outcome_lines','raw_exit','changes','failures']} for k,r in strict['strict'].items()},'semantic_tests':strict['semantics']},'inputs':inputs,'roles':'The namespace prototype author prepared this saved-results report and adapted the build/native/correctness recipe. Root ran targets and saved readers. Separate agents reviewed source/protocols and native/layout records; final report/packet review remains pending.','limits':['Shared-host observations need quiet matched confirmation before strong small-gain claims.','Original real-project XML parsing only, not whole application runs.','Both native and CPython aggregates remain above the roughly 1.10× Expat goal.','Benchmark callback coalescing does not establish exact callback grouping; strict failures remain unchanged.','Namespace-every-depth can add metadata and live ancestor scopes can retain peak pool storage.','Normal generic O3/ThinLTO/one-codegen-unit only; no new PGO work.','C harness ASan/UBSan only; Rust normal libraries are uninstrumented and leak detection disabled.','No current namespace sustained fuzzing or installed PBS validation.']}
save(OUT/'report.json',report)
summary='| Initial campaign | Candidate / control | Candidate / Expat | Lower-time conditions |\n| --- | ---: | ---: | ---: |\n'
for label,g in [('Native real XML',groups['real']),('Native generated',groups['generated']),('CPython all',pgroups['all']),('ElementTree',pgroups['elementtree']),('pyexpat events',pgroups['pyexpat-events'])]:
 summary+=f"| {label} | {g['geomean_ratios']['candidate_over_control']:.6f}× | {g['geomean_ratios']['candidate_over_expat']:.6f}× | {g.get('candidate_faster_than_control',g.get('candidate_lower_than_control'))} / {g['conditions']} |\n"
adverse_table='| Consumer | Input | Feed | Namespace / mode | Observed time increase |\n| --- | --- | ---: | --- | ---: |\n'
for r in adverse:
 adverse_table+=f"| {r['consumer']} | {r['project']} | {r['chunk_bytes']//1024} KiB | {r['namespace_or_mode']} | {(r['candidate_over_control']-1)*100:.3f}% |\n"
body=f'''# Sparse namespace storage: initial shared-host results

**Candidate review remains pending quiet matched confirmation.** Initial paired observations show 2.47% less native real-input time and 0.94% less CPython time against the selected native ASCII Text runtime. These small differences are not settled speed claims: another Toucan task used unrestricted Cargo builds/tests on the same `charlie-oss-6` host. CPU0 affinity and sequential Oriole target execution do not establish globally exclusive CPUs or an idle host. The direction and size of interference are unknown. All initial results stay recorded separately from any later confirmation.

The candidate remains above the roughly 1.10× Expat goal: native real-input time is **1.4571×**, CPython **1.1881×**. Four of 24 individual Python conditions meet it. No selected main README benchmark table is changed by this draft.

## Implementation and memory tradeoff

A parser-owned sparse stack stores only nonempty namespace binding blocks; each Element keeps an optional scalar scope index. Start retains the existing local binding construction and error order, reserves both owners before committing, and keeps name moves unchanged. End detaches the scope block before fallible event emission or restoration, preserving reverse restoration and drop behavior. Elements without namespace declarations keep only the scalar scope index. The empty pool drops its allocation when capacity exceeds a 4 KiB metadata retention threshold; an active ancestor scope can retain peak pool storage.

Only `crates/oriole/src/lib.rs`, `crates/oriole/tests/adapter_frame.rs` and `crates/oriole/tests/allocation.rs` differ from published Text base `19b28544`. The 74-file measured source map and exact normal library identities are recorded in [report.json](report.json); the later runtime commit is still pending. The change adds no unsafe code, public API, dependencies or SIMD, and retains name ownership and source compaction.

Actual debug Element size falls **168→120 bytes**, while Parser grows **2408→2464 bytes (+56)**. Separate optimized disassembly shows the End-frame transfer changing from a 168-byte memcpy to 120 bytes of inline loads/stores; both versions still copy the 72-byte ElementName afterward. These observations establish layout and movement differences, not the cause of an elapsed result. Namespace declarations at every depth can add metadata. Private heap/RSS was not measured.

## Completed initial observations

{summary}
Ratios are equally weighted geometric means of condition-wise medians of seven paired process ratios. Cross-campaign gains are not added, and ratios need not equal ratios of displayed medians. All 52 condition rows and all nine adverse conditions remain in [conditions.csv](conditions.csv) and [adverse-conditions.csv](adverse-conditions.csv).

{adverse_table}
The native protocol includes 24 original project XML conditions and four generated controls, seven pairs, 84 preflights and 588 timed workers: 672 workers/106,176 samples. CPython includes 24 conditions, 72 preflights and 504 timed workers: 576 workers/26,364 samples. Combined totals are 1,248 workers/132,540 samples. Original creation/feed/finalization/callback/destruction boundaries, canonical checks, garbage collection policy, input hashes, seeds and timeout/reaping rules are unchanged.

These are normal generic builds with O3, ThinLTO and one codegen unit; local Ohm defaults are disabled. Unmodified CPython 3.12.13 extensions use the unchanged O2 recipe. Two candidate extensions were built; two selected Text and two Expat extensions were reused with their original source, vectors, bytes and origins pinned. All engines had fresh preflights and workers. No new PGO study was performed. The candidate table in `candidate-table.json` is an appendix for these initial observations, not an update to selected benchmark claims.

## Compatibility and remaining work

All 451 workspace tests across 35 groups, formatting and strict Clippy pass. The original 4,740 API outcomes remain exact: 4,347 passes, 391 assertion failures and two timeouts, raw exit 1. Original bounds and assertions remain intact. Six shared/static C integration, adversarial and allocation consumers pass. Their C harnesses use ASan/UBSan; normal Rust libraries are uninstrumented and leak detection is disabled.

Both strict CPython linkages retain 802 method outcomes and 809 rendered outcome lines, with the same two failures and raw exit 2: `test.test_pyexpat.BufferTextTest.test1` and `test.test_sax.CDATAHandlerTest.test_handlers`. Strict consumers carry the explicit upstream allocation-failure cleanup backport; benchmark consumers are unmodified. Two separate supplemental semantic tests pass per linkage and do not erase strict failures. No current namespace sustained sanitizer/fuzz campaign or installed PBS trial is claimed.

## Preparation history and attribution

Root's source review caught a reserve-error conversion issue before compilation: both new `try_reserve` calls needed the existing `AllocError::from` mapping. Revision 1 and corrected revision 2 are preserved; this was not a failed compiler target. Root formatting changed no source bytes. ENOSPC also prevented one independent source-review command from launching. Four clean obsolete compiler worktrees were removed while retaining their commits/branches, raw evidence and shared build cache. The recovery receipt documents disk cleanup; the separate shared-host finding comes from parent's read-only task inspection.

The implementation author prepared this report and adapted the saved recipe. Root ran targets and saved readers; separate agents reviewed source/protocols and native/layout records. Final independent report/packet review and quiet matched confirmation are pending. The original observations and every adverse row remain retained regardless of the later selection decision.
'''
(OUT/'README.md').write_text(body)
print(json.dumps({'status':'initial_shared_host_draft_only','report_sha256':sha(OUT/'report.json'),'README_sha256':sha(OUT/'README.md'),'conditions':len(conditions),'adverse':len(adverse),'archive_written':False,'selected_README_changed':False}))
