"""Package completed isolated/combined normal Text evidence with the existing tar recipe."""
from pathlib import Path
import csv, gzip, hashlib, io, json, os, tarfile
assert __debug__ and os.sched_getaffinity(0)=={6}
PREP=Path(__file__).parent
DRAFT=PREP/'draft'
OUT=DRAFT/'docs/validation/2026-09-12/native-ascii-text-plan'
STUDY=Path('/tmp/oriole-text-plan-combined-study')
ISOLATED=Path('/tmp/oriole-text-plan-study')
CONTROL=Path('/tmp/oriole-fused-normal-current-study')
OLD_CONTROL=Path('/tmp/oriole-expanded-start-capacity-study')
CORRECT=Path('/tmp/oriole-text-plan-combined-correctness')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
assert not OUT.exists()
draft=read(PREP/'report.json')
native=read(STUDY/'native/review.json'); python=read(STUDY/'python/normal-review.json')
isolated=read(ISOLATED/'native/review.json')
api=read(CORRECT/'api-c-readback.json'); strict=read(CORRECT/'strict-semantic-readback.json')
assert draft['runtime_commit']=='ea52004a6590a224bfc0ec96c8e80a3159920db5'
assert native['counts']['all_workers']==isolated['counts']['all_workers']==672
assert python['counts']['all_workers']==576
assert api['api']['counts']=={'pass':4347,'fail':391,'timeout':2}
assert all(x['methods']==802 and x['raw_exit']==2 and x['changes']==[] for x in strict['strict'].values())
# Existing explicit add/tree, deterministic gzip, index and full-member readback.
entries, originals, excluded, pins = {}, {}, {}, {}
def add_data(data, member, original):
    assert member not in entries, member
    assert not data.startswith((b'\x7fELF', b'!<arch>\n')), original
    entries[member], originals[member] = data, str(original)
def add(path, member):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert path.suffix not in {'.pyc','.profraw','.profdata','.a','.so'}, path
    add_data(path.read_bytes(), member, path)
def is_external(path):
    path = Path(path)
    if path.suffix in {'.pyc','.profraw','.profdata','.a','.so'} or '.so.' in path.name:
        return True
    with path.open('rb') as f: return f.read(8).startswith((b'\x7fELF',b'!<arch>\n'))
def exclude(path, reason):
    path=Path(path)
    row={'path':str(path),'sha256':sha(path),'size':path.stat().st_size,'reason':reason}
    if str(path) in excluded:
        previous=excluded[str(path)]
        assert all(previous[k]==row[k] for k in ('path','sha256','size')),path
        return
    excluded[str(path)]=row
def tree(root,prefix):
    root=Path(root);assert root.is_dir(),root
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts: continue
        if is_external(path): exclude(path,'Executable/library/bytecode/compiler-profile identity only')
        elif path.is_symlink(): raise AssertionError(f'unexpected nonbinary symlink: {path}')
        else: add(path,prefix+'/'+str(path.relative_to(root)))
def pin_map(values):
    for path,digest in values.items():
        assert isinstance(digest,str) and len(digest)==64,(path,digest)
        assert path not in pins or pins[path]==digest,path
        pins[path]=digest


source_maps={};source_hashes={};dedup={}
for label,study in [('candidate',STUDY),('control',CONTROL),('isolated',ISOLATED),('isolated-control',OLD_CONTROL)]:
    source=read(study/'source.json'); assert len(source['sha256'])==(74 if label in ('candidate','isolated') else 73)
    mapping={}
    for name,h in source['sha256'].items():
        path=Path(source['worktree'])/name; assert sha(path)==h,path
        if (name,h) not in dedup:
            member='source/'+label+'/'+name;add(path,member);dedup[name,h]=member
        mapping[name]=dedup[name,h]
    source_maps[label]=mapping;source_hashes[label]=source['sha256']
    add(study/'source.json','source/'+label+'-manifest.json')
for name in ['LICENSE-APACHE','LICENSE-MIT','THIRD_PARTY_LICENSES.md','licenses/expat.txt','licenses/libxml2.txt','licenses/cpython.txt']:
    add(Path(read(STUDY/'source.json')['worktree'])/name,'source/licenses/'+name)
source_map={'member_maps':source_maps,'sha256':source_hashes,'scope':'Candidate/isolated74 files; corresponding controls73. Shared equal bytes map to the same member; all four identities stay separate.'}
add_data((json.dumps(source_map,indent=2)+'\n').encode(),'source/member-map.json','generated from four verified source manifests')
add(PREP/'committed-source.json','source/committed-source.json')
for label,study in [('candidate',STUDY),('isolated',ISOLATED)]:
    for p in sorted(study.iterdir()):
        if p.is_file():add(p,label+'/build/'+p.name)
    tree(study/'native',label+'/native')
tree(STUDY/'python','candidate/python')
tree(CORRECT,'candidate/correctness')
tree('/tmp/oriole-text-plan-combined-correctness-attempt01','candidate/correctness-attempt01')
tree('/tmp/oriole-text-plan-combined-preparation','candidate/author-preparation')
tree('/tmp/oriole-text-plan-preparation','isolated/author-preparation')
for label,study in [('control',CONTROL),('isolated-control',OLD_CONTROL)]:
    for name in ['build.json','source.json','build-binding.json','rustc-version.log','tests.log','clippy.log','fmt.log','release.log']:
        add(study/name,label+'/build/'+name)
reviews=[
'/tmp/oriole-text-plan-independent-review.json',
'/tmp/oriole-text-plan-independent-review-attempt01.json',
'/tmp/oriole-text-plan-combined-independent-preparation-review.json',
'/tmp/oriole-text-plan-combined-python-preparation-independent-review.json',
'/tmp/oriole-text-plan-combined-correctness-independent-review.json',
'/tmp/oriole-text-plan-combined-source-final-review.json',
'/tmp/oriole-text-plan-combined-independent-raw-review.json',
'/tmp/oriole-native-ascii-text-plan-invariants.md',
'/tmp/oriole-text-plan-build.py','/tmp/oriole-text-plan-bind.py',
'/tmp/oriole-text-plan-native-prepare.py',
'/tmp/oriole-text-plan-combined-build.py','/tmp/oriole-text-plan-combined-bind.py',
'/tmp/oriole-text-plan-combined-build.py.patch','/tmp/oriole-text-plan-combined-bind.py.patch',
'/tmp/oriole-text-plan-combined-correctness-prepare.py','/tmp/oriole-text-plan-combined-correctness-prepare.py.patch',
'/tmp/oriole-text-plan-combined-correctness-preparation01.stdout','/tmp/oriole-text-plan-combined-correctness-preparation01.stderr',
'/tmp/oriole-text-plan-combined-correctness-preparation02.stdout','/tmp/oriole-text-plan-combined-correctness-preparation02.stderr',
'/tmp/oriole-text-plan-combined-pr-body.md']
for path in reviews:add(path,'reviews/'+Path(path).name)
# Include the independent replay source when present beside its receipt.
for p in Path('/tmp').glob('oriole-text-plan-combined-independent-raw-review*.py'):add(p,'reviews/'+p.name)
for name in ['report.json','report-README.md','README-table.json','README-table.md','draft.py']:
    add(PREP/name,'publication/'+name)
for p in sorted(DRAFT.rglob('*')):
    if p.is_file():add(p,'publication/draft/'+str(p.relative_to(DRAFT)))
add(__file__,'preparation/assemble.py')
add('/tmp/oriole-fused-normal-evidence-preparation/assemble.py','preparation/prior-archive-recipe.py')
for name in ['draft01.stdout','draft01.stderr']:add(PREP/name,'preparation/'+name)
for values in [native['inputs'],isolated['inputs'],api['inputs'],strict['inputs'],python['evidence_sha256'],read(STUDY/'python/preflight-review.json')['pins'],read(STUDY/'python/consumer-binding.json')['pins'],read(STUDY/'python/reuse.json')['pins']]:pin_map(values)
for study,kind in [(STUDY,'native/native-screen'),(ISOLATED,'native/native-screen'),(STUDY,'python/screen')]:
    data=read(study/kind/'results.json');assert data['hashes_before']==data['hashes_after'];pin_map(data['hashes_before'])
corpus=Path('/home/dev-user/code/oss/oriole/benchmarks/projects/corpus-manifest.json')
add(corpus,'inputs/corpus-manifest.json')
for project in read(corpus)['projects']:
    for item in project['files']:
        p=corpus.parent/item['path'];assert sha(p)==item['sha256'];add(p,'inputs/'+item['path'])
for path,member in [('/tmp/oriole-grammar-bench-plain/entities.xml','inputs/generated/entities.xml'),('/tmp/oriole-text-frame-prototype/text/screen/rare-declarations.xml','inputs/generated/rare-declarations.xml')]:add(path,member)
archived_paths=set(originals.values())
for path,h in sorted(pins.items()):
    p=Path(path);assert sha(p)==h,p
    if path in archived_paths:continue
    machine_config=p.name in {'config','config.toml'} and '.cargo' in p.parts
    if is_external(p) or machine_config:exclude(p,'External executable/library/compiler-profile or machine configuration; audited identity retained')
    else:add(p,'other-pinned-inputs/'+str(p).lstrip('/'))
assert sum(n.startswith('candidate/native/native-screen/worker-') for n in entries)==672
assert sum(n.startswith('isolated/native/native-screen/worker-') for n in entries)==672
assert sum(n.startswith('candidate/python/screen/') and n.endswith('-0.json') for n in entries)==576
assert sum(n.startswith('candidate/python/screen/') and n.endswith(('-stdout.gz','-stderr.gz')) for n in entries)==1152
assert not any(n.endswith('.callgrind') for n in entries)
conditions=[]
for campaign,consumer,values in [('combined','native',native['all_conditions']),('combined','python',python['summary']),('isolated','native',isolated['all_conditions'])]:
    for row in values:
        c,r=row['condition'],row['median_ratios']
        conditions.append({'campaign':campaign,'consumer':consumer,'project':c['name'],'chunk_bytes':c['chunk'],'namespace_or_mode':c.get('mode',str(c.get('namespaces','')).lower()),**r,'adverse':r['candidate_over_control']>1})
assert len(conditions)==80
adverse=[r for r in conditions if r['adverse']];assert len(adverse)==9 and sum(r['campaign']=='combined' for r in adverse)==6
OUT.mkdir(parents=True)
for name,rows in [('conditions.csv',conditions),('adverse-conditions.csv',adverse)]:
    with (OUT/name).open('x',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
for name in ['README-table.json','README-table.md','committed-source.json']:(OUT/name).write_bytes((PREP/name).read_bytes())
members=[]
with (OUT/'evidence.tar.gz').open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for member,data in sorted(entries.items()):
                info=tarfile.TarInfo(member);info.size,info.mode,info.mtime=len(data),0o644,0
                archive.addfile(info,io.BytesIO(data))
                members.append({'member':member,'original_path':originals[member],'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive_path=OUT/'evidence.tar.gz'
with tarfile.open(archive_path,'r:gz') as archive:
    actual=archive.getmembers();assert [m.name for m in actual]==[r['member'] for r in members]
    for member,row in zip(actual,members,strict=True):
        assert member.isfile() and member.size==row['size']
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==row['sha256']
for member,path in originals.items():
    if path.startswith('/'):
        assert Path(path).read_bytes()==entries[member],path
index={'schema':'saved-record-bundle-v1','archive':'evidence.tar.gz','archive_sha256':sha(archive_path),'archive_bytes':archive_path.stat().st_size,'archive_readback_passed':True,'members':members,'excluded':list(excluded.values())}
(OUT/'index.json').write_text(json.dumps(index,indent=2)+'\n')

report=draft | {'evidence':{'archive_sha256':sha(archive_path),'archive_bytes':archive_path.stat().st_size,'members':len(members),'index_sha256':sha(OUT/'index.json'),'readback_passed':True,'all_conditions':80,'combined_adverse_conditions':6,'isolated_adverse_conditions':3,'conditions_sha256':sha(OUT/'conditions.csv'),'adverse_sha256':sha(OUT/'adverse-conditions.csv')},'source_members':'source/member-map.json','combined_native_all_conditions':native['all_conditions'],'combined_python_all_conditions':python['summary'],'isolated_native_all_conditions':isolated['all_conditions']}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
body=(PREP/'report-README.md').read_text()+f'\n## Raw evidence\n\n[evidence.tar.gz](evidence.tar.gz) contains {len(members):,} indexed files ({archive_path.stat().st_size:,} compressed bytes). [index.json](index.json) records every member hash, original path, size and excluded executable/library identity. Every archived member and original was read back after writing. [conditions.csv](conditions.csv) includes all 80 combined/isolated rows; [adverse-conditions.csv](adverse-conditions.csv) includes six combined and three isolated regressions. [report.json](report.json) retains full precision and limits.\n\nArchive SHA-256: `{sha(archive_path)}`. Executables, libraries, compiler profiles and machine configuration are excluded. The source member map reconstructs all four candidate/control snapshots without treating earlier source evidence as current.\n'
(OUT/'README.md').write_text(body)
result={'status':'packet_assembled_readback_passed','packet':str(OUT),'archive_sha256':sha(archive_path),'members':len(members),'bytes':archive_path.stat().st_size,'report_sha256':sha(OUT/'report.json'),'index_sha256':sha(OUT/'index.json')}
(PREP/'assembly.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
