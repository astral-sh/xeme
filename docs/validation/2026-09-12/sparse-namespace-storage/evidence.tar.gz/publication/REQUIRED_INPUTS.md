# Namespace publication inventory

Root released saved assembly after both initial and confirmation campaigns and all correctness targets completed and were reaped. The runtime decision retains `b9190cda8b04092a5691d8ec1cbefbc116f9e4e4`, with all 74 measured source bytes bound to that commit. No target is run by this recipe.

The unique publication path is `docs/validation/2026-09-12/sparse-namespace-storage/`. Candidate/control snapshots, all original build/check logs, normal compiler vectors and identities, full API/C/strict/semantic records, prototype revisions and source reviews, debug layout and optimized disassembly, raw corpus/license files, and all native/Python workers are explicit archive inputs. Libraries, executable/target/cache trees, compiler profile blobs and machine Cargo configuration are excluded; relevant identities remain indexed.

Both epochs stay separate: initial 52 conditions / 1,248 workers / 132,540 samples / nine adverse rows; confirmation has the same counts and 15 adverse rows. Total: 104 conditions / 2,496 workers / 265,080 samples / 24 adverse rows. No observations are pooled. Confirmation supplies the featured table and summary.

The initial shared-host limitation, four-worktree disk recovery, before/during confirmation counters, host release observations and independent attribution remain distinct. Idle counters include iowait and do not establish OS-enforced isolation, process attribution or freedom from cache/frequency/memory interference. Root's selected-source decision is narrower than production readiness.

The four proposed entry documents are `draft/README.md`, `draft/docs/compatibility.md`, `draft/docs/review.md` and `draft/benchmarks/README.md`. Main README warning and full License section must match base19b byte-for-byte. The benchmark entrypoint labels earlier PGO/LTO data historical and states that new work uses Oriole normal O3/ThinLTO/one codegen unit. The Expat control separately uses GCC O3 without LTO; historical values and links remain.

`additional-inputs.json` names final reviews/readers and retained first attempts. Earlier held inventories and initial report drafts are historical preparation records; their pending labels are not final execution status. The initial compiler wording correction is retained separately from measured data. The unchanged deterministic gzip/member-index/full-readback recipe is adapted only for explicit inventory and two-epoch scope.

Root-authorized launch: `taskset -c 6 python3 -I assemble.py --released`. Final packet review must compare all archive members to the index/original bytes, both source maps and commit binding, every condition/aggregate, and local documentation links. No repository write, compiler, parser or benchmark is performed here. Root owns copying/committing/publishing after that independent review.
