# Sparse namespace storage: initial shared-host results

**Candidate review remains pending quiet matched confirmation.** Initial paired observations show 2.47% less native real-input time and 0.94% less CPython time against the selected native ASCII Text runtime. These small differences are not settled speed claims: another Toucan task used unrestricted Cargo builds/tests on the same `charlie-oss-6` host. CPU0 affinity and sequential Oriole target execution do not establish globally exclusive CPUs or an idle host. The direction and size of interference are unknown. All initial results stay recorded separately from any later confirmation.

The candidate remains above the roughly 1.10× Expat goal: native real-input time is **1.4571×**, CPython **1.1881×**. Four of 24 individual Python conditions meet it. No selected main README benchmark table is changed by this draft.

## Implementation and memory tradeoff

A parser-owned sparse stack stores only nonempty namespace binding blocks; each Element keeps an optional scalar scope index. Start retains the existing local binding construction and error order, reserves both owners before committing, and keeps name moves unchanged. End detaches the scope block before fallible event emission or restoration, preserving reverse restoration and drop behavior. Elements without namespace declarations keep only the scalar scope index. The empty pool drops its allocation when capacity exceeds a 4 KiB metadata retention threshold; an active ancestor scope can retain peak pool storage.

Only `crates/oriole/src/lib.rs`, `crates/oriole/tests/adapter_frame.rs` and `crates/oriole/tests/allocation.rs` differ from published Text base `19b28544`. The 74-file measured source map and exact normal library identities are recorded in [report.json](report.json); the later runtime commit is still pending. The change adds no unsafe code, public API, dependencies or SIMD, and retains name ownership and source compaction.

Actual debug Element size falls **168→120 bytes**, while Parser grows **2408→2464 bytes (+56)**. Separate optimized disassembly shows the End-frame transfer changing from a 168-byte memcpy to 120 bytes of inline loads/stores; both versions still copy the 72-byte ElementName afterward. These observations establish layout and movement differences, not the cause of an elapsed result. Namespace declarations at every depth can add metadata. Private heap/RSS was not measured.

## Completed initial observations

| Initial campaign | Candidate / control | Candidate / Expat | Lower-time conditions |
| --- | ---: | ---: | ---: |
| Native real XML | 0.975283× | 1.457056× | 20 / 24 |
| Native generated | 1.008702× | 4.009998× | 1 / 4 |
| CPython all | 0.990616× | 1.188056× | 22 / 24 |
| ElementTree | 0.988493× | 1.249534× | 11 / 12 |
| pyexpat events | 0.992743× | 1.129603× | 11 / 12 |

Ratios are equally weighted geometric means of condition-wise medians of seven paired process ratios. Cross-campaign gains are not added, and ratios need not equal ratios of displayed medians. All 52 condition rows and all nine adverse conditions remain in [conditions.csv](conditions.csv) and [adverse-conditions.csv](adverse-conditions.csv).

| Consumer | Input | Feed | Namespace / mode | Observed time increase |
| --- | --- | ---: | --- | ---: |
| native | batik | 4 KiB | false | 0.018% |
| native | batik | 4 KiB | true | 2.364% |
| native | generated-rare-declarations | 4 KiB | false | 0.822% |
| native | generated-entities | 4 KiB | false | 1.471% |
| native | batik | 64 KiB | false | 1.812% |
| native | batik | 64 KiB | true | 1.790% |
| native | generated-entities | 64 KiB | false | 1.273% |
| python | vulkan | 64 KiB | pyexpat-events | 0.831% |
| python | docbook | 4 KiB | elementtree | 0.436% |

The native protocol includes 24 original project XML conditions and four generated controls, seven pairs, 84 preflights and 588 timed workers: 672 workers/106,176 samples. CPython includes 24 conditions, 72 preflights and 504 timed workers: 576 workers/26,364 samples. Combined totals are 1,248 workers/132,540 samples. Original creation/feed/finalization/callback/destruction boundaries, canonical checks, garbage collection policy, input hashes, seeds and timeout/reaping rules are unchanged.

Oriole uses normal generic O3, ThinLTO and one codegen unit; local Ohm defaults are disabled. The pinned Expat 2.8.4 control uses GCC 13.3 O3 without LTO. Unmodified CPython 3.12.13 extensions use the unchanged O2 recipe. Two candidate extensions were built; two selected Text and two Expat extensions were reused with their original source, vectors, bytes and origins pinned. All engines had fresh preflights and workers. No new PGO study was performed. The candidate table in `candidate-table.json` is an appendix for these initial observations, not an update to selected benchmark claims.

## Compatibility and remaining work

All 451 workspace tests across 35 groups, formatting and strict Clippy pass. The original 4,740 API outcomes remain exact: 4,347 passes, 391 assertion failures and two timeouts, raw exit 1. Original bounds and assertions remain intact. Six shared/static C integration, adversarial and allocation consumers pass. Their C harnesses use ASan/UBSan; normal Rust libraries are uninstrumented and leak detection is disabled.

Both strict CPython linkages retain 802 method outcomes and 809 rendered outcome lines, with the same two failures and raw exit 2: `test.test_pyexpat.BufferTextTest.test1` and `test.test_sax.CDATAHandlerTest.test_handlers`. Strict consumers carry the explicit upstream allocation-failure cleanup backport; benchmark consumers are unmodified. Two separate supplemental semantic tests pass per linkage and do not erase strict failures. No current namespace sustained sanitizer/fuzz campaign or installed PBS trial is claimed.

## Preparation history and attribution

Root's source review caught a reserve-error conversion issue before compilation: both new `try_reserve` calls needed the existing `AllocError::from` mapping. Revision 1 and corrected revision 2 are preserved; this was not a failed compiler target. Root formatting changed no source bytes. ENOSPC also prevented one independent source-review command from launching. Four clean obsolete compiler worktrees were removed while retaining their commits/branches, raw evidence and shared build cache. The recovery receipt documents disk cleanup; the separate shared-host finding comes from parent's read-only task inspection.

The implementation author prepared this report and adapted the saved recipe. Root ran targets and saved readers; separate agents reviewed source/protocols and native/layout records. Final independent report/packet review and quiet matched confirmation are pending. The original observations and every adverse row remain retained regardless of the later selection decision.
