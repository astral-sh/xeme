# Namespace undo storage: current-source assessment

**A narrow metadata experiment is viable: a parser-owned LIFO stack of nonempty binding blocks, indexed from Element. Do not flatten individual records in the first candidate.** This removes the allocator-carrying empty Vec from every ordinary Element while preserving the current namespace restoration loop and ownership of its input. It leaves ElementName and all Start/End callback payloads unchanged. No new unsafe code or public API is needed.

Scope: `/home/dev-user/code/oss/oriole-fused-normal-current`, core source SHA `30cb2ebf…`, unchanged from measured `4815cf78` outside the unrelated scanner. This is source inspection and saved-data reading only; no implementation, compiler, parser, profiler or benchmark target ran.

## Evidence and limit

The exact normal `a240099f…` DSO moves a 168-byte Element at the `prepare_end_frame` memcpy call, PC `0x936d3`. It executes 80,926 times for Vulkan and 1,824 for Maven in the saved namespace-off, 64 KiB profiles (one warmup and one measured parse). That full function has 5,826,672 / 131,328 self instructions; these exclude memcpy and other callees and are not removable-cost bounds. `observations.json` records exact source/library/profile identities. The source also constructs and moves the allocator-owning empty binding Vec on native Start even when namespaces are disabled. Prospective Element size, copy reduction and elapsed benefit remain unmeasured.

## Exact bounded shape

Keep `type NamespaceBindings = Vec<(String, Option<String>)>` for existing owned records. Add `Parser.namespace_scopes: Vec<NamespaceBindings>`, initially empty and using the parser allocator. Replace `Element.bindings` with a scalar optional scope index; a zero sentinel with checked one-based indices, or `Option<NonZeroUsize>`, avoids a wide owned fallback variant. Only elements that actually declare namespaces push a block.

- **Start, general path (`lib.rs:3166–3355`):** retain the existing local binding Vec and every namespace validation, map update, prefix/value clone and StartNamespace emission in the same order. At the current Element-stack commit point, reserve the Element slot first. If bindings are nonempty, reserve one scope slot before moving any owner, then push the block and Element without further fallible work. An empty binding Vec drops locally. Failure before this joint commit drops local bindings exactly as today; failure while emitting StartElement leaves both committed stacks intact, also as today. The map is intentionally not rolled back on either failure.
- **Start, native frame (`3491–3513`):** store the no-scope index directly, without constructing an empty Vec. Existing frame eligibility excludes namespace declarations. Name packing, raw encoding, empty-element End queueing and final frame publication do not change.
- **End (`3550–3580`):** after popping Element, detach its original nonempty binding block from the sparse scope stack *before* the fallible EndElement emission. Assert it is the top scope. Keep that block locally owned while the current reverse restoration loop runs. A failure during EndElement emission, prefix cloning, map insertion or EndNamespace emission then drops all unprocessed records through normal Rust ownership, just as the existing local Element did. Elements without a scope use the existing no-namespace body. Preserve `closed_root` being set only after successful restoration.
- **Matched framed End (`2279`, `3584–3596`):** replace the empty-bindings test with the no-scope test. Keep its name move and infallible frame preparation unchanged. A namespaced element can have no local declarations even though an ancestor owns a scope; never test whether the *global* scope stack is empty.

Invariant: the sparse scope stack corresponds, in order, to exactly the open Elements with nonempty local namespace declarations. Every nonempty block has one owner; each indexed block is removed with its Element. A scope-less child leaves its parent's block untouched. No index or reference escapes a core call.

## Other paths

- Empty elements push and immediately pop their scope before Start/End callbacks are delivered; preserve that existing map timing and pending-event order.
- Mismatched End tags and entity initial-depth violations occur before popping either stack. Internal entities share the current Element stack and require no separate scope mechanism.
- External children construct a fresh Parser and copy the current namespace map (`858–905`); they inherit no parent Element stack or undo history. Their shadowing restores that copied map locally. DTD-provided default xmlns attributes continue through the general Start path.
- Hash-salt changes rebuild the live namespace map; stored prefixes/previous URIs remain owned strings and are hashed when restored, as today.
- Namespace Start/End events own their callback strings. A callback may stop, change handlers, create/parse a child, or attempt reset/free without borrowing this scope vector. The existing C busy guard and detached frame contracts stay unchanged.
- Parser destruction owns both vectors. C reset first constructs a replacement Parser and then drops the old one (`oriole_expat/src/lib.rs:507–555`), so failed reset retains both old stacks and successful reset drops both. No separate pool-reset API is needed.

## Retention and why the flat version should wait

The sparse stack retains only **block metadata**, bounded by the configured Element depth and Vec growth. Each block's prefix/URI storage and record capacity are freed at End, as now. The new metadata buffer uses the existing family allocation tracker. Proposed spare-capacity rule: when the pool becomes empty, release its buffer if `capacity * size_of::<NamespaceBindings>()` exceeds 4 KiB (use division for the comparison); retain smaller capacities. This introduces no fallible shrink on End. While ancestors still own scopes, capacity remains bounded by peak namespace-declaring depth, just as the existing Element stack retains peak depth capacity; this is not a strict 4 KiB bound on active-scope slack. Its cold first allocation and reserve/drop timing must be measured; it is not an allocation-free change.

Documents declaring namespaces at every depth are an adverse case: every old block descriptor still exists in the sparse vector, and every Element gains its index. This can increase total metadata even though each Element becomes smaller. Include that case rather than assuming universal memory savings.

A flat `Vec<(String, Option<String>)>` adds more obligations for the same first metadata goal: a failed Start must discard only the uncommitted tail, whereas StartElement-emission failure must retain a committed tail; every End error must discard the remaining tail without restoring those bindings. Rust unwinding also loses the current automatic local-owner cleanup unless deliberately handled. Moreover, the flat buffer retains peak declaration-count capacity after a large child closes while a small root binding remains active. Freeing it only when empty does not bound that extra retained slack. Avoid combining new cleanup/retention policy with this first metadata experiment.

The sparse form does not eliminate allocation of namespace records and is not a full name arena. It tests the specific measured metadata issue with much less semantic churn. If its normal measurements do not justify adoption, stop here; the saved profile does not establish that a larger namespace arena would close the performance gap.

## Meaningful validation

Extend existing `namespace_identity_frames_follow_default_binding_scope` and `detached_end_frames_keep_native_and_namespace_undo_boundaries` with nested prefix shadowing, default undeclaration, empty namespace-bearing children and declaration-free descendants. Assert exact StartNamespace/Start/End/EndNamespace order and expanded names through one-byte/UTF-16 feeds. Keep NUL separator/triplet and converted-name tests.

Exercise an external child inside a shadowed scope and then a sibling after it; the existing `external_entity_children_inherit_namespaces_and_declarations` supplies the helper pattern. Include defaulted xmlns declarations from a DTD.

Extend the selected-allocator failure sweep with two nested nonempty scopes and a following scope-less child. It must cover the new scope reserve, failed Element reserve before commitment, StartElement publication after commitment, and End prefix clone/map/queue failures. Preserve sticky errors, detached-frame inactivity, callbacks before non-OOM errors, and balanced frees. Existing callback reentry/suspend/reset/free tests should run unchanged.

First check actual generated Element layout and ordinary Start/End copy paths; do not assume the scalar representation yields a particular layout. Then compare matched normal native and CPython campaigns plus a compact nested-declaration allocation observation. No elapsed saving or production-readiness claim follows from this assessment.
