from pathlib import Path
import hashlib,json,os,re,subprocess,time
assert os.sched_getaffinity(0)=={6}
D=Path('/tmp/oriole-namespace-scopes-layout');D.mkdir(exist_ok=False)
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
J=lambda p:json.loads(Path(p).read_text())
env=os.environ.copy();env['DEBUGINFOD_URLS']='';rows=[];pins={};engines={}
def pin(p):p=Path(p);pins[str(p)]=H(p);return pins[str(p)]
def run(label,args):
 argv=['/usr/bin/timeout','--signal=TERM','--kill-after=5s','45s','/usr/bin/taskset','-c','6',*args]
 start=time.time()
 with (D/(label+'.stdout')).open('wb') as out,(D/(label+'.stderr')).open('wb') as err:
  p=subprocess.Popen(argv,env=env,stdout=out,stderr=err,start_new_session=True)
  try:code=p.wait(timeout=51)
  except BaseException:
   import signal
   os.killpg(p.pid,signal.SIGKILL);p.wait();raise
 row={'label':label,'command':argv,'exit':code,'reaped':True,'start':start,'end':time.time(),'stdout_sha256':H(D/(label+'.stdout')),'stderr_sha256':H(D/(label+'.stderr'))};rows.append(row)
 (D/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');assert code==0,(label,code)
 return (D/(label+'.stdout')).read_text()
for tool in ['/usr/bin/readelf','/usr/bin/nm','/usr/bin/objdump','/usr/bin/timeout','/usr/bin/taskset']:pin(tool)
for label,study in [('control','/tmp/oriole-text-plan-combined-study'),('candidate','/tmp/oriole-namespace-scopes-study')]:
 S=Path(study);b=J(S/'build.json');binding=J(S/'build-binding.json');source=J(S/'source.json')
 assert b['status']==binding['status']=='passed' and b['source_unchanged']
 assert pin(S/'build.json')==binding['build_sha256'];assert pin(S/'source.json')==binding['source_manifest_sha256'];pin(S/'build-binding.json')
 for name in ['tests','release']:
  row=next(r for r in b['commands'] if r['label']==name);assert row['exit']==0 and row['reaped'];assert pin(S/(name+'.log'))==row['log_sha256']
 for name,h in b['libraries'].items():assert pin(S/'normal'/name)==h
 for name,h in source['sha256'].items():assert H(Path(source['worktree'])/name)==h
 paths=re.findall(r'Running unittests src/lib.rs \(([^)]+/oriole-[^)]+)\)',(S/'tests.log').read_text());assert len(paths)==1
 elf=Path(paths[0]);assert elf.read_bytes()[:4]==b'\x7fELF';pin(elf)
 so=S/'normal/liboriole_expat.so';engines[label]={'study':study,'debug_elf':str(elf),'debug_sha256':H(elf),'normal_so':str(so),'normal_sha256':H(so),'worktree':source['worktree']}
 run(label+'-elf',['/usr/bin/readelf','--wide','--file-header','--section-headers','--notes',str(elf)])
 run(label+'-dwarf',['/usr/bin/readelf','--wide','--debug-dump=info','--debug-dump=no-follow-links','--dwarf-depth=4',str(elf)])
 symbols=run(label+'-symbols',['/usr/bin/nm','-S','--defined-only','--demangle',str(so)])
 targets=[]
 for line in symbols.splitlines():
  m=re.match(r'^([0-9a-f]+) ([0-9a-f]+) [tT] (.+)$',line)
  if m and m[3] in ['oriole::Parser::prepare_end_frame','oriole::Parser::end_element','oriole::Parser::parse_start','oriole::Parser::parse_start_frame']:
   start,size=int(m[1],16),int(m[2],16);targets.append({'symbol':m[3],'address':m[1],'size':size})
   run(label+'-'+m[3].split('::')[-1],['/usr/bin/objdump','-d','-C','--start-address='+hex(start),'--stop-address='+hex(start+size),str(so)])
 engines[label]['disassembled_symbols']=targets
for path,h in pins.items():assert H(path)==h,path
r={'status':'saved_artifact_capture_complete','targets_executed':False,'engines':engines,'pins':pins,'commands':rows}
(D/'capture.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'status':r['status'],'path':str(D/'capture.json'),'sha256':H(D/'capture.json'),'engines':engines,'commands':len(rows)},indent=2))
