from pathlib import Path
import hashlib,json,os,re,subprocess,time
assert os.sched_getaffinity(0)=={6}
D=Path('/tmp/oriole-namespace-scopes-layout');r=json.loads((D/'capture.json').read_text());rows=[];env=os.environ.copy();env['DEBUGINFOD_URLS']='';H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for engine,e in r['engines'].items():
 matches=[]
 for line in (D/(engine+'-symbols.stdout')).read_text().splitlines():
  m=re.match(r'^([0-9a-f]+) ([0-9a-f]+) [tT] (<oriole::Parser>::(?:prepare_end_frame|end_element|parse_start))$',line)
  if m:matches.append(m)
 assert len(matches)==3
 for m in matches:
  name=m[3].split('::')[-1];label=engine+'-'+name;start=int(m[1],16);size=int(m[2],16)
  argv=['/usr/bin/timeout','--signal=TERM','--kill-after=5s','45s','/usr/bin/taskset','-c','6','/usr/bin/objdump','-d','-C','--start-address='+hex(start),'--stop-address='+hex(start+size),e['normal_so']]
  with (D/(label+'.stdout')).open('wb') as out,(D/(label+'.stderr')).open('wb') as err:
   p=subprocess.Popen(argv,env=env,stdout=out,stderr=err,start_new_session=True)
   try:code=p.wait(timeout=51)
   except BaseException:
    import signal
    os.killpg(p.pid,signal.SIGKILL);p.wait();raise
  rows.append({'engine':engine,'symbol':m[3],'address':hex(start),'size':size,'command':argv,'exit':code,'reaped':True,'stdout_sha256':H(D/(label+'.stdout')),'stderr_sha256':H(D/(label+'.stderr'))});assert code==0
for path,h in r['pins'].items():assert H(path)==h
out={'status':'saved_optimized_disassembly_complete','targets_executed':False,'note':'Actual GNU-demangled names use <oriole::Parser>::method; initial capture retained the complete nm output, this follow-up selects that spelling. No command failure or target execution.','commands':rows}
(D/'disassembly.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'commands':len(rows),'sizes':[{k:v for k,v in row.items() if k in ['engine','symbol','address','size']} for row in rows]},indent=2))
