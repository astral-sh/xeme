from pathlib import Path
import hashlib,json,os,re
assert os.sched_getaffinity(0)=={6}
D=Path('/tmp/oriole-namespace-scopes-layout');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text());capture=J(D/'capture.json');dis=J(D/'disassembly.json');layouts={}
for engine,e in capture['engines'].items():
 lines=(D/(engine+'-dwarf.stdout')).read_text().splitlines();nodes=[];current=None;parents={};cu=None
 for n,line in enumerate(lines):
  m=re.match(r' <(\d+)><([0-9a-f]+)>: (.*)',line)
  if m:
   depth=int(m[1]);tag=re.search(r'\((DW_TAG_[^)]+)\)',m[3]);current={'depth':depth,'offset':m[2],'kind':tag[1] if tag else None,'attrs':{},'line':n+1,'parent':parents.get(depth-1),'cu':cu};nodes.append(current);parents[depth]=current
   if current['kind']=='DW_TAG_compile_unit':cu=current;current['cu']=current
  elif current:
   m=re.search(r'DW_AT_(\w+)\s*:\s*(.*)$',line)
   if m:current['attrs'][m[1]]=m[2]
 def textattr(v):return v.rsplit('): ',1)[-1] if '): ' in v else v
 def name(n):return textattr(n['attrs'].get('name',''))
 def number(v):return int(v.rsplit(' ',1)[-1],0)
 layouts[engine]={}
 for target in ['Element','Parser']:
  found=[n for n in nodes if n['kind']=='DW_TAG_structure_type' and name(n)==target and n['parent'] and name(n['parent'])=='oriole'];assert found
  signatures=[]
  for n in found:
   members=[c for c in nodes if c['kind']=='DW_TAG_member' and c['parent'] is n]
   signatures.append((number(n['attrs']['byte_size']),number(n['attrs']['alignment']),{name(c):number(c['attrs']['data_member_location']) for c in members}))
   assert textattr(n['cu']['attrs']['comp_dir'])==e['worktree']
   assert 'rustc version 1.98.1-dev (f62703110 2026-09-08) (ohm-1.98.1-1)' in n['cu']['attrs']['producer']
   assert textattr(n['cu']['attrs']['name']).startswith('crates/oriole/src/lib.rs/@/')
  assert all(sig==signatures[0] for sig in signatures)
  first=found[0];members=[c for c in nodes if c['kind']=='DW_TAG_member' and c['parent'] is first]
  selected=[c for c in members if target=='Element' or name(c) in ['stack','namespace_scopes','namespaces']]
  layouts[engine][target]={'byte_size':signatures[0][0],'alignment':signatures[0][1],'identical_dies':len(found),'die_offset':'0x'+first['offset'],'raw_line':first['line'],'members':[{'name':name(c),'offset':number(c['attrs']['data_member_location']),'type_reference':c['attrs']['type'],'die_offset':'0x'+c['offset']} for c in selected],'compilation_unit':first['cu']['attrs']}
 headers=(D/(engine+'-elf.stdout')).read_text();assert '.debug_info' in headers and '.debug_line' in headers
 layouts[engine]['elf_build_id']=re.search(r'Build ID: ([0-9a-f]+)',headers)[1]
assert layouts['control']['Element']['byte_size']==168 and layouts['candidate']['Element']['byte_size']==120
assert layouts['control']['Parser']['byte_size']==2408 and layouts['candidate']['Parser']['byte_size']==2464
# Exact disjoint instruction evidence for the owning stack pop, before ElementName copies.
c=(D/'control-prepare_end_frame.stdout').read_text();n=(D/'candidate-prepare_end_frame.stdout').read_text()
for token in ['94397:', 'dec    %r13','mov    %r13,0x2d0(%rdi)','mov    0x2c0(%rdi),%r12','imul   $0xa8,%r13,%rbp','lea    (%r12,%rbp,1),%r15','lea    0x80(%rsp),%rdi','mov    $0xa8,%edx','mov    %r15,%rsi','943c3:','<memcpy@GLIBC_2.14>']:assert token in c,token
for token in ['dec    %r14','mov    %r14,0x2d0(%rdi)','mov    0x2c0(%rdi),%rax','imul   $0x78,%r14,%rcx']:assert token in n,token
inline_loads=[('95308',112,8),('95315',96,16),('95322',80,16),('9532f',64,16),('9533c',0,16),('95340',16,16),('95345',32,16),('9534a',48,16)]
inline_stores=[('9530d',240,8),('9531a',224,16),('95327',208,16),('95334',192,16),('9534f',176,16),('95357',160,16),('9535f',144,16),('95367',128,16)]
for pc,offset,width in inline_loads+inline_stores:assert (pc+':') in n
assert sorted(b for _,o,w in inline_loads for b in range(o,o+w))==list(range(120))
assert sorted(b for _,o,w in inline_stores for b in range(o,o+w))==list(range(128,248))
assert 'memcpy@' not in n and 'memmove@' not in n
for row in capture['commands']+dis['commands']:
 assert row['exit']==0 and row['reaped']
 label=row.get('label') or row['engine']+'-'+row['symbol'].split('::')[-1]
 for channel in ['stdout','stderr']:assert H(D/(label+'.'+channel))==row[channel+'_sha256']
for path,h in capture['pins'].items():assert H(path)==h,path
out={'status':'verified_saved_debug_layout_and_release_end_transfer','targets_executed':False,'role':'Independent source reviewer; artifact-reader author. No parser/compiler/profiler/elapsed execution.','layouts':layouts,'debug_deltas':{'Element':-48,'Parser':56},'optimized_end_transfer':{'control':{'symbol':'<oriole::Parser>::prepare_end_frame','stack_stride':168,'copy_bytes':168,'copy_kind':'memcpy','copy_call_pc':'0x943c3','source':'Parser.stack data pointer loaded at0x943a1 from parser+0x2c0; decremented stack length from+0x2d0 times0xa8 selects the popped Element.','destination':'rsp+0x80'},'candidate':{'symbol':'<oriole::Parser>::prepare_end_frame','stack_stride':120,'copy_bytes':120,'copy_kind':'inline seven16-byte and one8-byte loads/stores','source':'Parser.stack data pointer loaded at0x952fd from parser+0x2c0; decremented stack length from+0x2d0 times0x78 selects the popped Element.','source_loads_pc_offset_width':inline_loads,'destination_stores_pc_offset_width':inline_stores,'range':'source[0,120) to stack[rsp+128,rsp+248)'}},'function_sizes':[{k:v for k,v in row.items() if k in ['engine','symbol','address','size']} for row in dis['commands']],'limitations':['DWARF records are from actual debug test ELFs; separate optimized End stack stride/copy widths agree, but this is not a blanket proof of every release type layout.','The subsequent72-byte ElementName copies remain in both prepare_end_frame implementations. No claim that all End-path copying disappeared.','Parser grows56 bytes; declaration-heavy nesting also stores sparse block descriptors. Active namespace ancestors may retain peak outer capacity.','No elapsed, RSS, heap-allocation count, executed-path frequency or net instruction-cost savings inferred.','GNU nm names use <oriole::Parser>::method; complete initial nm outputs retained, then matching symbol ranges disassembled.'],'capture_sha256':H(D/'capture.json'),'disassembly_sha256':H(D/'disassembly.json'),'readers':{str(p):H(p) for p in [Path('/tmp/oriole-namespace-scopes-layout-capture.py'),Path('/tmp/oriole-namespace-scopes-layout-disassemble.py'),Path(__file__)]},'pins':capture['pins']}
(D/'report.json').write_text(json.dumps(out,indent=2)+'\n')
(D/'README.md').write_text('# Sparse namespace layout readback\n\nSaved artifacts show Element168→120 bytes (−48) and Parser2408→2464 (+56), alignment8. All matching Oriole DWARF copies agree; their compilation directories and compiler identities match the logged debug test binaries.\n\nIn the actual normal release `prepare_end_frame`, control copies the popped168-byte stack entry with memcpy at0x943c3. Candidate uses a120-byte inline transfer at0x95308–0x95367, with a matching120-byte stack stride. Both retain subsequent72-byte ElementName copies. Full function disassemblies, ELF headers/notes, DWARF outputs and exact tool commands are retained. No target was executed and no speed or heap-memory saving is inferred.\n\nSee [report.json](report.json), [capture.json](capture.json), and [disassembly.json](disassembly.json).\n')
print(json.dumps({'status':out['status'],'report':str(D/'report.json'),'sha256':H(D/'report.json'),'sizes':{e:{t:v['byte_size'] for t,v in d.items() if t in ['Element','Parser']} for e,d in layouts.items()},'commands':len(capture['commands'])+len(dis['commands'])},indent=2))
