from pathlib import Path
import ast,hashlib,json,os
assert os.sched_getaffinity(0)=={6}
D=Path('/tmp/oriole-namespace-scopes-study/native');H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();J=lambda p:json.loads(Path(p).read_text())
prep=Path('/tmp/oriole-namespace-scopes-native-prepare.py');assert H(prep)=='704ee9d5765e23cf713c86615d4d4796f125989d2326585e299ec5d9dcc91ff2'
adaptation=J(D/'adaptation.json');origin=Path(adaptation['origin']);assert origin==Path('/tmp/oriole-text-plan-combined-study/native')
assert (D/'run.py').read_bytes()==(origin/'run.py').read_bytes()
before=(origin/'native_screen.py').read_text();after=(D/'native_screen.py').read_text();expected=before
for old,new in adaptation['changes']['native_screen.py']:assert old in expected;expected=expected.replace(old,new)
assert after==expected
marker='def run(condition, engine, pair, cpu, count):';assert after[after.index(marker):]==before[before.index(marker):]
reader=D/'read_results.py';text=reader.read_text();tree=ast.parse(text);cut=next(i for i,n in enumerate(tree.body) if text.splitlines()[n.lineno-1].startswith('with (OUT /'))
scope={'__file__':str(reader),'__name__':'independent_saved_namespace_native_replay'};exec(compile(ast.Module(body=tree.body[:cut],type_ignores=[]),str(reader),'exec'),scope)
report=J(D/'review.json');assert H(D/'review.json')=='6e977dab5a5dc08e1307370cd2aa3d104504e73f42bb0207b385b92e0956b010'
assert report['counts']==scope['counts'] and report['groups']==scope['groups'] and report['all_conditions']==scope['summary']
assert scope['libraries']['candidate']['sha256']=='d6303603fece314e683a5fda5dcb60334c7e302e5e8d87bd7dd13285e46bb63e'
assert scope['libraries']['control']['sha256']=='ef1648fcb1bae5bce53715283b221166c84e5e8431ff53f39e62a1ecd358bd25'
for path,h in scope['pins'].items():assert H(path)==h,path
adverse=[{'condition':r['condition'],**r['median_ratios']} for r in scope['summary'] if r['median_ratios']['candidate_over_control']>1];assert len(adverse)==7
out={'status':'independent_namespace_native_preparer_and_completed_raw_review_passed','targets_executed':False,'role':'Independent namespace source/protocol reviewer. No prototype runtime/test, native preparer or target authorship. Replayed existing saved reader assertion/arithmetic blocks only, before its output writes.','counts':report['counts'],'groups':report['groups'],'all_adverse':adverse,'pins_rehashed':len(scope['pins']),'source_files':len(scope['source']['sha256']),'native_preparer_review':{'sha256':H(prep),'source_binding':'Base19b, candidate/control74-source maps, three-file delta and complete build/tool/library bindings checked before materialization. Candidate hash obtained from completed binding; selected Text ef1648 and normal Expat preserved.','protocol':'Original28 conditions/seven seeded pairs/84 preflights/588 timed workers. Worker/full timing body and wrapper byte-exact; output source/path/caption bindings only. Actual completed schedule, sample boundaries, origins/version, callback hashes and every pair ratio reconstructed.'},'limitations':['Single normal native campaign, no statistical-significance or whole-project performance claim.','All four adverse real and three adverse generated conditions retained. Python is a separate conditional measurement.','Layout changes and End-copy width are separately verified saved-artifact observations, not causal attribution for elapsed differences.'],'pins':{str(p):H(p) for p in [prep,Path(str(prep)+'.patch'),reader,D/'review.json',D/'preparation.json',D/'adaptation.json',D.parent/'build-binding.json',D.parent/'source.json']}}
p=Path('/tmp/oriole-namespace-scopes-native-independent-review.json');p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'path':str(p),'sha256':H(p),'counts':out['counts'],'groups':{k:{key:value for key,value in v.items() if key!='adverse'} for k,v in report['groups'].items()},'all_adverse':adverse},indent=2))
