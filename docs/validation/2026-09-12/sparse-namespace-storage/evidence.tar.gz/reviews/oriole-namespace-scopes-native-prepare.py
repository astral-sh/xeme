"""Prepare a matched normal native comparison from existing artifacts only."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path

assert __debug__ and os.sched_getaffinity(0) == {6}
origin = Path('/tmp/oriole-text-plan-combined-study/native')
out = Path('/tmp/oriole-namespace-scopes-study/native')
control = origin.parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
binding = load(out.parent / 'build-binding.json')
source = load(out.parent / 'source.json')
assert binding['status'] == 'passed' and binding['source_count'] == 74
assert source['base'] == '19b285440bc7467debfa4901df36d86a0e4ef1a0'
assert binding['source_manifest_sha256'] == sha(out.parent / 'source.json')
assert binding['control_source_manifest_sha256'] == sha(control / 'source.json')
assert binding['build_sha256'] == sha(out.parent / 'build.json')
assert all(sha(Path(source['worktree']) / p) == h for p, h in source['sha256'].items())
assert source['sha256']['crates/oriole/src/tag.rs'] == '50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6'
build = load(out.parent / 'build.json')
old_source = load(control / 'source.json')
old_build = load(control / 'build.json')
prepared_source = Path('/tmp/oriole-namespace-scopes-preparation/source.json')
assert sha(prepared_source) == '39001ee1306e2a9e303f734f819b1b810884e7e7b9fa58cd0077eb076dbd5519'
assert source['sha256'] == load(prepared_source)['sha256']
assert set(source['sha256']) == set(old_source['sha256']) and len(source['sha256']) == 74
assert build['status'] == old_build['status'] == 'passed' and build['source_unchanged'] and old_build['source_unchanged']
assert binding['control_build_sha256'] == sha(control / 'build.json')
assert binding['prepared_source_sha256'] == sha(prepared_source)
assert set(binding['source_delta']) == {'crates/oriole/src/lib.rs', 'crates/oriole/tests/adapter_frame.rs', 'crates/oriole/tests/allocation.rs'}
assert binding['candidate_libraries'] == build['libraries'] and binding['control_libraries'] == old_build['libraries']
assert binding['control_libraries']['liboriole_expat.so'] == 'ef1648fcb1bae5bce53715283b221166c84e5e8431ff53f39e62a1ecd358bd25'
for directory, libraries in [(out.parent, binding['candidate_libraries']), (control, binding['control_libraries'])]:
    assert all(sha(directory / 'normal' / name) == digest for name, digest in libraries.items())
assert all(sha(path) == digest for path, digest in binding['tool_hashes'].items())
assert not out.exists()
out.mkdir()


def adapt(name, changes):
    before = (origin / name).read_text()
    after = before
    for old, new in changes:
        assert old in after, (name, old)
        after = after.replace(old, new)
    ast.parse(after)
    (out / name).write_text(after)
    (out / (name + '.patch')).write_text(''.join(difflib.unified_diff(
        before.splitlines(True), after.splitlines(True),
        fromfile=str(origin / name), tofile=str(out / name))))
    return before, after


changes = [
    ('/tmp/oriole-text-plan-combined-study', '/tmp/oriole-namespace-scopes-study'),
    ('/tmp/oriole-fused-normal-current-study', '/tmp/oriole-text-plan-combined-study'),
    ('combined native ASCII Text plan', 'sparse namespace bookkeeping'),
    ('published fused attribute scanner baseline', 'selected combined Text baseline'),
]
before, after = adapt('native_screen.py', changes)
marker = 'def run(condition, engine, pair, cpu, count):'
assert before[before.index(marker):] == after[after.index(marker):]
restored = after
for old, new in reversed(changes):
    restored = restored.replace(new, old)
assert restored == before
(out / 'run.py').write_bytes((origin / 'run.py').read_bytes())
prior = load(origin / 'adaptation.json')
libraries = {
    'candidate': {'path': str(out.parent / 'normal/liboriole_expat.so'),
                  'sha256': binding['candidate_libraries']['liboriole_expat.so']},
    'control': prior['libraries']['candidate'],
    'expat': prior['libraries']['expat'],
}
assert libraries['control']['sha256'] == binding['control_libraries']['liboriole_expat.so']
assert all(sha(v['path']) == v['sha256'] for v in libraries.values())
adaptation = {k: prior[k] for k in ('mode', 'external_input_hashes', 'conditions', 'pairs', 'seed', 'counts')}
assert all(sha(p) == h for p, h in adaptation['external_input_hashes'].items())
adaptation.update(
    status='passed', execution_status='unexecuted', origin=str(origin),
    parent_files={n: sha(origin / n) for n in ('run.py', 'native_screen.py')},
    files={n: sha(out / n) for n in ('run.py', 'native_screen.py')},
    changes={'run.py': [], 'native_screen.py': changes},
    inverse_text_and_ast_equal=True, libraries=libraries,
    selected_normal_protocol={'path': str(origin / 'native-screen/protocol.json'),
                              'sha256': sha(origin / 'native-screen/protocol.json')},
    source_delta=binding['source_delta'], candidate_source=source['worktree'],
    candidate_source_record={'path': str(out.parent / 'source.json'), 'sha256': sha(out.parent / 'source.json')},
    candidate_build_record={'path': str(out.parent / 'build.json'), 'sha256': sha(out.parent / 'build.json')},
    binding_review=str(out.parent / 'build-binding.json'),
    scope='Sparse namespace bookkeeping versus selected combined Text and normal Expat. All 28 conditions and original timing, workers, callbacks, and bounds unchanged. No targets run during preparation.')
(out / 'adaptation.json').write_text(json.dumps(adaptation, indent=2) + '\n')

reader_changes = [
    ('/tmp/oriole-text-plan-combined-study', '/tmp/oriole-namespace-scopes-study'),
    ('dca62e60f80e311fbb529e66262fd2f7f07d8f38eda16c97cd33aa9dd8063488', '@CONTROL_SHA@'),
    ('ef1648fcb1bae5bce53715283b221166c84e5e8431ff53f39e62a1ecd358bd25', libraries['candidate']['sha256']),
    ('@CONTROL_SHA@', libraries['control']['sha256']),
    ('168b5f57ad5300a74eb77769ccad83e513ebe5c8', source['base']),
    ("binding['source_count'] == 74 and set(binding['source_delta']) == {'crates/oriole/src/encoding.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/text.rs', 'crates/oriole/tests/text_coalescing.rs'}",
     "binding['source_count'] == 74 and set(binding['source_delta']) == {'crates/oriole/src/lib.rs', 'crates/oriole/tests/adapter_frame.rs', 'crates/oriole/tests/allocation.rs'}"),
    ('4ae5e631297666d8da0f0129f4ef59358020468296edcc10aaf2acc51ab50c77', source['sha256']['crates/oriole/src/lib.rs']),
    ('Reuse the published fused normal reader with source, library and output bindings for combined Text plan. Full raw reconstruction unchanged.',
     'Reuse the completed combined Text normal reader with source, library and output bindings for sparse namespace bookkeeping. Full raw reconstruction unchanged. Prototype author adapted this reader; root owns execution and independent review.'),
    ('Only this combined-source native campaign is reconstructed here. Isolated Text-plan and Python results are separate.',
     'Only this sparse-namespace normal native campaign is reconstructed here. Python preparation and timing are conditional on a native gain and are outside this evidence.'),
]
adapt('read_results.py', reader_changes)
(out / 'README.md').write_text('''# Sparse namespace bookkeeping: held normal native protocol

Candidate is the reviewed sparse namespace prototype on PR156. Control is PR156's selected combined Text parser. Both use ordinary generic x86-64 O3, ThinLTO, one codegen unit; Expat is the existing normal 2.8.4 baseline. No PGO.

All 24 real conditions and four generated controls use the original seven seeded pairs, 84 fresh preflight workers and 588 timed workers. Every sample includes parser construction, handlers, feeding, callbacks and destruction. Callback digests merge text fragments; they do not establish exact callback fragmentation.

Native runs first; Python is not prepared unless a native gain justifies proceeding. Root runs run.py with the pinned CPython bin directory first on PATH. The unchanged wrapper runs preflight on CPU5 (600-second bound), then exclusive elapsed on CPU0 (1200-second bound), with original 90-second worker limits and process-group cleanup. Root runs read_results.py on CPU6 afterward. No target ran during preparation.
''')
pins = {str(p): sha(p) for p in out.iterdir() if p.is_file()}
for p in [Path(__file__), out.parent / 'source.json', out.parent / 'build.json',
          out.parent / 'build-binding.json', control / 'source.json', control / 'build.json',
          prepared_source, origin / 'adaptation.json', origin / 'native_screen.py', origin / 'run.py', origin / 'read_results.py']:
    pins[str(p)] = sha(p)
preparation = {'status': 'prepared_no_targets', 'targets_executed': False, 'pins': pins,
               'source_delta': binding['source_delta'], 'counts': adaptation['counts'],
               'run_unchanged': True, 'native_worker_and_all_measurement_code_unchanged': True,
               'reader_changes': reader_changes}
(out / 'preparation.json').write_text(json.dumps(preparation, indent=2) + '\n')
print(json.dumps({'status': preparation['status'], 'path': str(out),
                  'preparation_sha256': sha(out / 'preparation.json'), 'libraries': libraries}))
