"""Adapt the completed normal CPython protocol without executing targets."""
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path

assert __debug__ and os.sched_getaffinity(0) == {6}
origin = Path('/tmp/oriole-text-plan-combined-study/python')
out = Path('/tmp/oriole-namespace-scopes-study/python')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
binding = load(out.parent / 'build-binding.json')
assert binding['status'] == 'passed' and binding['source_count'] == 74
assert sha(out.parent / 'build-binding.json') == '7a0f39f152b19a7f0f7b1361008d87eedfcef1b5302179f18b47174c92e2dc25'
assert not out.exists()
out.mkdir()

def adapt(name, changes):
    before = (origin / name).read_text()
    after = before
    for old, new in changes:
        assert old in after, (name, old)
        after = after.replace(old, new)
    ast.parse(after)
    (out / name).write_text(after)
    (out / (name + '.patch')).write_text(''.join(difflib.unified_diff(
        before.splitlines(True), after.splitlines(True),
        fromfile=str(origin / name), tofile=str(out / name))))
    return before, after

for name in ('run.py', 'python_worker.py', 'build_consumers.py'):
    adapt(name, [])
caption_changes = [
    ('combined native ASCII Text plan', 'sparse namespace storage'),
    ('selected fused attribute-scanner control', 'selected combined Text control'),
]
before, after = adapt('consumer_screen.py', caption_changes)
restored = after
for old, new in reversed(caption_changes):
    restored = restored.replace(new, old)
assert restored == before
(out / 'script-adaptations.json').write_text(json.dumps({
    'origin': str(origin), 'inverse_text_equal': True,
    'changes': {'consumer_screen.py': caption_changes},
}, indent=2) + '\n')

for name in ('preflight_review.py', 'elapsed_review.py'):
    adapt(name, [(str(origin), str(out))])

path_changes = [
    ('/tmp/oriole-fused-normal-current-study', '/tmp/oriole-text-plan-combined-study'),
    ('/tmp/oriole-text-plan-combined-preparation', '/tmp/oriole-namespace-scopes-preparation'),
]
adapt('bind.py', path_changes + [
    ("len(control_source['sha256']) == 73", "len(control_source['sha256']) == 74"),
    ("set(control_source['sha256']) | {'crates/oriole/src/text.rs'}", "set(control_source['sha256'])"),
    ("{'crates/oriole/src/encoding.rs', 'crates/oriole/src/lib.rs', 'crates/oriole/src/text.rs', 'crates/oriole/tests/text_coalescing.rs'}",
     "{'crates/oriole/src/lib.rs', 'crates/oriole/tests/adapter_frame.rs', 'crates/oriole/tests/allocation.rs'}"),
])
adapt('prepare.py', path_changes + [
    ('completed combined parser build', 'completed sparse-namespace parser build'),
    ('168b5f57ad5300a74eb77769ccad83e513ebe5c8', '19b285440bc7467debfa4901df36d86a0e4ef1a0'),
    ('dca62e60f80e311fbb529e66262fd2f7f07d8f38eda16c97cd33aa9dd8063488', 'ef1648fcb1bae5bce53715283b221166c84e5e8431ff53f39e62a1ecd358bd25'),
    ('/home/dev-user/code/oss/oriole-text-plan-combined', '/home/dev-user/code/oss/oriole-namespace-scopes'),
    ('completed selected fused protocol', 'completed selected Text protocol'),
    ('Combined Text plan versus published fused09da/dca62 control, carried by168b5f57, and unchanged normal Expat. Isolated4815 Text native results are not substituted.',
     'Sparse namespace storage versus selected Text ef1648 control, carried by19b28544, and unchanged normal Expat.'),
    ('74 source files. Four reviewed Text files exactly match isolated candidate; published fusedtag50f641 identical across control and candidate. Complete patch pinned.',
     '74 source files and three changed files: core lib.rs and two test files. Text and tag scanners identical across control and candidate. Complete patch pinned.'),
    ('/tmp/oriole-text-plan-combined-independent-preparation-review.json', '/tmp/oriole-namespace-scopes-independent-source-review.json'),
])
(out / 'README.md').write_text('''# Sparse namespace storage: normal CPython comparison

The candidate uses the reviewed three-file namespace change on PR156. Control is PR156 itself. Both use generic x86-64 O3, ThinLTO and one codegen unit; Expat is the unchanged normal baseline. No PGO.

The completed selected Text protocol is reused: 24 conditions, seven pairs, 72 fresh preflight workers and 504 timed workers. Worker, build and outer controllers are byte-identical. Two candidate extensions are compiled fresh; four unchanged control/Expat extensions retain their original paths. All consumers use unmodified CPython sources. Exact callback fragmentation is a separate correctness gate.

Root runs prepare.py and bind.py as saved-data checks on CPU6, then run.py prepare on CPU3. After the saved preflight reader passes and all other targets are reaped, root runs run.py time exclusively on CPU0 and elapsed_review.py on CPU6. Original bounds, canonical checks, module origins, destruction, GC and ratio calculations remain unchanged.
''')
result = {
    'status': 'source_prepared_root_execution_held', 'targets_executed': False,
    'pins': {str(p): sha(p) for p in out.iterdir() if p.is_file()},
    'parent_scripts': {str(origin/n): sha(origin/n) for n in (
        'run.py', 'python_worker.py', 'build_consumers.py', 'consumer_screen.py',
        'prepare.py', 'bind.py', 'preflight_review.py', 'elapsed_review.py')},
    'author_script_sha256': sha(__file__),
    'build_binding_sha256': sha(out.parent / 'build-binding.json'),
    'source_count': 74, 'source_delta': binding['source_delta'],
    'normal_candidate_library': binding['candidate_libraries'],
    'unchanged': ['run.py', 'python_worker.py', 'build_consumers.py'],
    'reader_changes': 'Study path only; complete raw reconstruction and math unchanged.',
    'fresh_compiles': 2, 'reused_compiles': 4,
}
(out / 'source-preparation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'sha256': sha(out/'source-preparation.json')}))
