"""Inspect the actual ordinary-release text classifier; never execute the library."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

assert os.sched_getaffinity(0) == {6}
OUT = Path('/tmp/oriole-text-simd-codegen')
OUT.mkdir(exist_ok=False)
LIB = Path('/tmp/oriole-text-simd-study/normal/liboriole_expat.so')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
binding = json.loads(Path('/tmp/oriole-text-simd-study/build-binding.json').read_text())
assert binding['status'] == 'passed'
assert sha(LIB) == binding['candidate_libraries']['liboriole_expat.so']
report = {'status': 'incomplete', 'library': str(LIB), 'library_sha256': sha(LIB), 'commands': []}

def run(label, argv):
    p = subprocess.run(argv, capture_output=True, text=True, timeout=30)
    (OUT / (label + '.stdout')).write_text(p.stdout)
    (OUT / (label + '.stderr')).write_text(p.stderr)
    report['commands'].append({'label': label, 'argv': argv, 'exit': p.returncode, 'reaped': True, 'stdout_sha256': sha(OUT / (label + '.stdout')), 'stderr_sha256': sha(OUT / (label + '.stderr'))})
    assert p.returncode == 0
    return p.stdout

try:
    symbols = run('symbols', ['/usr/bin/nm', '-S', '-C', '--defined-only', str(LIB)])
    matches = re.findall(r'^([0-9a-f]+) ([0-9a-f]+) [tT] <oriole::text::TextPlan>::scan$', symbols, re.M)
    assert len(matches) == 1, matches
    start, size = (int(x,16) for x in matches[0])
    disassembly = run('text-scan', ['/usr/bin/objdump', '-d', '-C', f'--start-address={start}', f'--stop-address={start+size}', str(LIB)])
    lines = [s for s in disassembly.splitlines() if re.match(r'^\s*[0-9a-f]+:', s)]
    vectors = [s for s in lines if any(x in s for x in ('pcmpgtb', 'pcmpeqb', 'pmovmskb', 'movdqu', 'pminub', 'pmaxub'))]
    calls = [s for s in lines if re.search(r'\bcall[q]?\b', s)]
    report.update(status='captured_current_release_disassembly', text_scan={'start': start, 'bytes': size, 'instructions': len(lines), 'vector_lines': vectors, 'call_lines': calls}, limitations='Static code inspection only. Source and exhaustive byte/lane tests establish predicates; no elapsed or allocation-rate inference.')
finally:
    (OUT / 'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
