# Safe 16-byte Text classifier: held normal native protocol

Candidate is the reviewed SIMD Text classifier on selected sparse namespace runtime b9190cda. Control is that namespace runtime's existing d630 normal library. Oriole uses ordinary generic x86-64 O3, ThinLTO and one codegen unit; the pinned Expat 2.8.4 control uses GCC 13.3 O3 without LTO. There are no new PGO or CPU-target flags.

All 24 real conditions and four generated controls use the unchanged seven seeded pairs, 84 fresh preflight workers and 588 timed workers. Every sample includes parser construction, handlers, feeding, callbacks and destruction. Callback digests merge text fragments; they do not establish exact callback fragmentation. All adverse rows remain.

Root holds target execution until build/binder/codegen checks complete and other compilers/targets are reaped. Root runs run.py with the pinned CPython directory first on PATH: preflight CPU5 with 600s bound, then elapsed CPU0 with 1200s bound and 90s workers. CPU affinity and local scheduling do not establish an idle or globally exclusive host. Root runs read_results.py on CPU6 afterward. No target ran during preparation, and Python has not been prepared here.
