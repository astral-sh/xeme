# LF and first-stop lane masks: held normal correctness gates

Candidate committed source cacc0b1b, measured from parent b698, retains74 inputs with five main deltas and two auxiliary locks. Selected performance control is namespace d630. Completed build/source/dependency receipts identify the candidate4ee8 shared and2d74 static libraries; the original ordered compatibility oracle remains unchanged because selected namespace matched it exactly.

Original API:4740 configurations,4347 passes,391 assertion failures and2timeouts. All assertions,3s per case,1GiB AS,768MiB RSS and240s total limits remain. Six dynamic/static integration/adversarial/allocation C consumers retain C-only ASan/UBSan with leak checking disabled; Rust is ordinary generic release.

Strict shared/static CPython retains the explicit upstream cleanup backport,802 methods/809 rendered outcomes and two known strict callback-fragmentation failures per linkage (raw exit2). The two semantic tests per linkage remain separate. These are patched strict modules; independent Python elapsed preparation uses unmodified modules.

Only saved-data source preparation is performed here. Root runs held bind.py then bind_strict.py onCPU6; api_native.py onCPU3 then read_api_c.py onCPU6; strict_cpython.py onCPU3; prepare_semantics.py onCPU6, run_semantic.py shared then static onCPU3, followed by read_strict_semantics.py onCPU6. Preserve original timeouts, cleanup and clean environment/pinned Python. No PGO, build flags or assertions change. Root schedules all targets around elapsed measurements.

Historical author-script pins and oracles remain at their original paths. Only unchanged repository descendants relocate; no predecessor output is represented as a fresh candidate result. The source/base distinction is explicit: cacc is the frozen commit, b698 is the saved prebuild parent. No target or strict extension is executed/materialized by this preparer.
