"""Materialize current normal correctness controllers; no compiler/parser execution."""
from pathlib import Path
import ast, difflib, hashlib, json, os, subprocess
assert os.sched_getaffinity(0)=={6}
O=Path('/tmp/oriole-namespace-scopes-correctness')
P=Path('/tmp/oriole-text-lane-masks-correctness')
W=Path('/home/dev-user/code/oss/oriole-text-lane-masks')
B=Path('/tmp/oriole-text-lane-masks-study')
old_work='/home/dev-user/code/oss/oriole-namespace-scopes'
old_build='/tmp/oriole-namespace-scopes-study'
replacements=[(str(O),str(P)),(old_work,str(W)),(old_build,str(B))]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def save(name,value):(P/name).write_text(json.dumps(value,indent=2)+'\n')
def relocate(text):
 for old,new in replacements:text=text.replace(old,new)
 return text
assert __debug__
source_review_path=Path('/tmp/oriole-text-lane-masks-independent-source-review.json')
prepared_source_path=Path('/tmp/oriole-text-lane-masks-preparation/source.json')
metadata_review_path=prepared_source_path.parent/'metadata-independent-review.json'
assert sha(source_review_path)=='a613e5374ab9eb81a1d3f25f29c5677ab37c45da98716027313cd2323e2f0bef'
assert sha(prepared_source_path)=='13408d5ae11c9108b651f401414aef6ced9286755a65ae188b64741461dc7e6e'
assert sha(metadata_review_path)=='45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
candidate_commit='cacc0b1b3766176e9cbf71d25c5ff6867fa87c08'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==candidate_commit
build_binding=load(B/'build-binding.json')
assert build_binding['status']=='passed' and build_binding['source_count']==74
assert build_binding['source_manifest_sha256']==sha(B/'source.json')
assert build_binding['build_sha256']==sha(B/'build.json')
assert load(B/'source.json')['sha256']==load(prepared_source_path)['sha256']
assert build_binding['candidate_libraries']=={'liboriole_expat.so':'4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d','liboriole_expat.a':'2d74ea94586d1c6d306fd5e5cdd4a14b830b5b2a5e046e9e2d08c6f2c36b2514'}
assert build_binding['dependency_review_sha256']==sha(metadata_review_path)
assert build_binding['auxiliary_files']==load(prepared_source_path)['auxiliary_sha256']
assert all(sha(W/name)==h for name,h in load(B/'source.json')['sha256'].items())
assert all(sha(W/name)==h for name,h in build_binding['auxiliary_files'].items())
P.mkdir(exist_ok=False);(P/'prior').mkdir()
scripts=['api_native.py','strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_api_c.py','read_strict_semantics.py','bind.py','bind_strict.py']
origins={}
for name in scripts:
 before=(O/name).read_text();after=relocate(before)
 if name=='bind.py':
  start=after.index("assert review['status'] ==")
  end=after.index("assert build['status'] ==",start)
  after=after[:start]+"assert review['status'] == 'passed_source_review_no_actionable_findings'\nassert source['worktree'] == str(W) and len(source['sha256']) == 74\nprepared = load(P / 'reviewed-prepared-source.json')\nmetadata = load(P / 'reviewed-metadata.json')\nassert review['source_manifest_sha256'] == sha(P / 'reviewed-prepared-source.json') == binding['prepared_source_sha256']\nassert source['sha256'] == prepared['sha256']\nassert review['base'] == source['base'] == prepared['base'] == 'b6985f0d07e9b3456f36f77eac97cf7bf013a650'\nassert prepared['source_count'] == 74 and review['all74_live_source_pins_checked']\nassert set(review['main_changed']) == set(prepared['changed']) == set(binding['source_delta']) == {'Cargo.lock', 'crates/oriole/Cargo.toml', 'crates/oriole/src/encoding.rs', 'crates/oriole/src/text.rs', 'crates/oriole/tests/text_coalescing.rs'}\nassert review['live_text_sha256'] == source['sha256']['crates/oriole/src/text.rs']\nassert prepared['complete_patch_sha256'] == sha(B / 'candidate.patch')\nassert review['live_complete_patch_sha256'] == prepared['complete_seven_file_patch_sha256'] == binding['complete_seven_file_patch_sha256']\nassert metadata['status'] == 'passed_saved_metadata_review'\nassert review['metadata_review_sha256'] == binding['dependency_review_sha256'] == sha(P / 'reviewed-metadata.json')\nassert metadata['source_manifest_sha256'] == sha(P / 'reviewed-prepared-source.json')\nassert binding['auxiliary_files'] == prepared['auxiliary_sha256'] == review['auxiliary_pins']\nfor name,digest in binding['auxiliary_files'].items():\n    assert sha(W/name)==digest\n    pins[str(W/name)]=digest\nassert len(binding['dependency_compiler_vectors']) == 3\ncontrol_path = Path('/tmp/oriole-namespace-scopes-study/source.json')\ncontrol = load(control_path)\nassert binding['control_source_manifest_sha256'] == sha(control_path)\nassert set(source['sha256']) == set(control['sha256'])\nassert {name for name in source['sha256'] if source['sha256'][name] != control['sha256'][name]} == set(review['main_changed'])\nassert binding['control_libraries']['liboriole_expat.so'] == 'd6303603fece314e683a5fda5dcb60334c7e302e5e8d87bd7dd13285e46bb63e'\nassert binding['candidate_libraries'] == {'liboriole_expat.so': '4ee8de82e300544b17eda8817352c7b858e0f7edcc90a3b1c326e4e1c24c616d', 'liboriole_expat.a': '2d74ea94586d1c6d306fd5e5cdd4a14b830b5b2a5e046e9e2d08c6f2c36b2514'}\n"+after[end:]
 if name=='strict_cpython.py':
  after=after.replace("'source_commit':source['base']", "'source_commit':'"+candidate_commit+"','measured_source_base_commit':source['base']")
 if name=='read_api_c.py':
  after=after.replace('Namespace-prototype author adapted the selected Text API/C saved reader', 'Lane-mask preparer adapted the selected namespace API/C saved reader')
 if name=='read_strict_semantics.py':
  after=after.replace('Namespace-prototype author adapted the selected Text strict/semantic saved reader', 'Lane-mask preparer adapted the selected namespace strict/semantic saved reader')
 ast.parse(after)
 (P/'prior'/name).write_text(before);(P/name).write_text(after)
 (P/(name+'.patch')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=str(O/name),tofile=str(P/name))))
 origins[name]={'origin':str(O/name),'origin_sha256':sha(O/name),'sha256':sha(P/name),'path_substitution_only':name not in ('bind.py','read_api_c.py','read_strict_semantics.py')}
assert (P/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]==(O/'strict_cpython.py').read_text().split('try:\n    for linkage',1)[1]
review_copies={'reviewed-source.json':str(source_review_path), 'reviewed-prepared-source.json':str(prepared_source_path), 'reviewed-metadata.json':str(metadata_review_path)}
for name,origin in review_copies.items():(P/name).write_bytes(Path(origin).read_bytes())
# Relocate only original unchanged test/consumer inputs, not old output hashes or old controllers.
static={}
strictstatic={}
for filename,destination in [('static-pins.json',static),('strict-static-pins.json',strictstatic)]:
 for path,value in load(O/filename).items():
  if path.startswith(str(O)+'/'):continue
  if path == old_build+'/candidate.patch':continue
  # Only repository input descendants move; historical author scripts and oracles stay at their original paths.
  new=relocate(path) if path.startswith(old_work+'/') else path
  assert sha(new)==value,new;destination[new]=value
for name in scripts:
 destination=strictstatic if name in ('strict_cpython.py','methods.py','prepare_semantics.py','run_semantic.py','read_strict_semantics.py','bind_strict.py') else static
 destination[str(P/name)]=sha(P/name)
 static[str(P/'prior'/name)]=sha(P/'prior'/name)
static[str(Path(__file__))]=sha(__file__)
for name in review_copies:static[str(P/name)]=sha(P/name)
static[str(B/'candidate.patch')]=sha(B/'candidate.patch')
assert load(B/'build-binding.json')['status']=='passed'
static[str(B/'build-binding.json')]=sha(B/'build-binding.json')
static[str(Path(old_build)/'source.json')]=sha(Path(old_build)/'source.json')
oldprep=load(O/'preparation.json')
save('preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'source_worktree':str(W),'candidate_source_commit':candidate_commit,'measured_source_base_commit':load(B/'source.json')['base'],'build_directory':str(B),'controller_origins':origins,'source_review_sha256':sha(P/'reviewed-source.json'),'api':oldprep['api'],'c_consumers':oldprep['c_consumers'],'baseline_api_outcomes':oldprep['baseline_api_outcomes'],'source_delta':'Five reviewed main files versus namespace b698/d630 in74-source map; two auxiliary locks, three reviewed dependency packages. Runtime change is text.rs; encoding.rs and text_coalescing.rs changes are tests.','scope':'Direct adaptation of completed selected namespace normal correctness controllers. Current lane source/dependency/build binding replaces namespace source binding; raw readers retain original reconstruction with accurate preparer authorship labels. Original API assertions and limits, six C builds/runs, complete strict shared/static loop, method reader and supplemental semantics unchanged. No target executed or profile-built artifact introduced.'})
save('static-pins.json',static)
spec=load(O/'semantic-commands-unbound.json')
spec=json.loads(relocate(json.dumps(spec)))
for command in spec['commands']:assert command['expected_library_sha256'] is None
save('semantic-commands-unbound.json',spec)
strictstatic[str(P/'semantic-commands-unbound.json')]=sha(P/'semantic-commands-unbound.json')
save('strict-static-pins.json',strictstatic)
oldstrict=load(O/'strict-preparation.json')
save('strict-preparation.json',{'status':'held_pending_saved_build_binding','targets_executed':False,'controller_origin':str(O/'strict_cpython.py'),'controller_origin_sha256':sha(O/'strict_cpython.py'),'controller_sha256':sha(P/'strict_cpython.py'),'complete_shared_static_execution_loop_byte_exact':True,'candidate_source_commit':candidate_commit,'measured_source_base_commit':load(B/'source.json')['base'],'baseline':oldstrict['baseline'],'baseline_outcomes':oldstrict['baseline_outcomes'],'consumer_fix':oldstrict['consumer_fix'],'static_pins_sha256':sha(P/'strict-static-pins.json'),'scope':'Original strict consumer-cleanup backport and historical two failures per linkage remain the comparison oracle; separate unchanged two semantic tests per linkage. Candidate outcomes pending. All target execution remains held.'})
(P/'README.md').write_text('# LF and first-stop lane masks: held normal correctness gates\n\nCandidate committed source cacc0b1b, measured from parent b698, retains74 inputs with five main deltas and two auxiliary locks. Selected performance control is namespace d630. Completed build/source/dependency receipts identify the candidate4ee8 shared and2d74 static libraries; the original ordered compatibility oracle remains unchanged because selected namespace matched it exactly.\n\nOriginal API:4740 configurations,4347 passes,391 assertion failures and2timeouts. All assertions,3s per case,1GiB AS,768MiB RSS and240s total limits remain. Six dynamic/static integration/adversarial/allocation C consumers retain C-only ASan/UBSan with leak checking disabled; Rust is ordinary generic release.\n\nStrict shared/static CPython retains the explicit upstream cleanup backport,802 methods/809 rendered outcomes and two known strict callback-fragmentation failures per linkage (raw exit2). The two semantic tests per linkage remain separate. These are patched strict modules; independent Python elapsed preparation uses unmodified modules.\n\nOnly saved-data source preparation is performed here. Root runs held bind.py then bind_strict.py onCPU6; api_native.py onCPU3 then read_api_c.py onCPU6; strict_cpython.py onCPU3; prepare_semantics.py onCPU6, run_semantic.py shared then static onCPU3, followed by read_strict_semantics.py onCPU6. Preserve original timeouts, cleanup and clean environment/pinned Python. No PGO, build flags or assertions change. Root schedules all targets around elapsed measurements.\n\nHistorical author-script pins and oracles remain at their original paths. Only unchanged repository descendants relocate; no predecessor output is represented as a fresh candidate result. The source/base distinction is explicit: cacc is the frozen commit, b698 is the saved prebuild parent. No target or strict extension is executed/materialized by this preparer.\n')
print(json.dumps({'status':'prepared_not_executed','path':str(P),'preparation_sha256':sha(P/'preparation.json'),'scripts':len(scripts),'static_pins':len(static),'strict_static_pins':len(strictstatic)}))
