# LF and first-stop Text lane masks: held normal CPython comparison

Candidate is reviewed LF/first-stop source on PR157 base b698, normal SO4ee8. Control is selected namespace b919/b698 normal SOd630. All other runtime files, including tag.rs, are unchanged; reviewed wide/safe_arch/bytemuck dependencies and auxiliary locks are pinned. No PGO or CPU-target flags.

Reuse the completed namespace protocol: 24 conditions, seven pairs, 72 fresh preflight workers and 504 timed workers, 576 workers/26,364 samples. Worker, build and outer controllers are byte-identical. Two candidate O2 extensions are compiled fresh; four unchanged selected-control/Expat O2 extensions retain their original paths. All consumers use unmodified pinned CPython 3.12.13 sources. Exact callback fragmentation remains a separate correctness gate.

Oriole normal libraries use generic x86-64 O3/ThinLTO/one codegen unit; pinned normal Expat uses GCC13.3 O3 without LTO. Source74, five main file changes, two auxiliary locks, dependency metadata and actual parser build artifacts are bound before any target.

Root runs prepare.py and bind.py as saved-data preparation on CPU6; run.py prepare builds two extensions and runs canonical preflights on CPU3 with separate600s bounds. After preflight_review.py passes and other Oriole targets are reaped, root runs run.py time on CPU0 with1200s bound, then elapsed_review.py on CPU6. Each worker retains its300s bound. Actual module plus in-process dladdr parser origins, canonical output, GC/destruction boundaries, seeded order and arithmetic are unchanged. CPU affinity does not establish global host isolation; retain separate host observations.

This directory initially contains only source preparation. Build, preflight and elapsed receipts must establish subsequent execution; pending work is not counted as passed.
