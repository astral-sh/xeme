"""Bind this prepared consumer protocol to reviewed normal libraries; saved files only."""
from pathlib import Path
import hashlib
import json
import os

assert os.sched_getaffinity(0) == {6}
D = Path(__file__).parent
pins = {}
def read(p):
    p = Path(p); data = p.read_bytes()
    pins[str(p)] = hashlib.sha256(data).hexdigest()
    return data
def sha(p): read(p); return pins[str(Path(p))]
def load(p): return json.loads(read(p))
def check(mapping):
    for p, h in mapping.items(): assert sha(p) == h, p

assert not (D/'adaptation.json').exists() and not (D/'consumer-binding.json').exists()
preparation = load(D/'preparation.json')
assert preparation['status'] == 'prepared_unbound'
check(preparation['pins'])
a = load(D/'adaptation.template.json')
assert a['status'] == 'prepared_only' and a['mode'] == 'normal'
for key in ('candidate_source_record', 'candidate_build_record', 'candidate_build_review'):
    v = a[key]; assert sha(v['path']) == v['sha256']
review = load(a['candidate_build_review']['path'])
build = load(a['candidate_build_record']['path'])
source = load(a['candidate_source_record']['path'])
control_path = Path('/tmp/oriole-namespace-scopes-study')
control_source = load(control_path/'source.json')
assert review['status'] == build['status'] == 'passed'
assert review['base'] == source['base'] == a['source_runtime_control']
assert review['source_count'] == len(source['sha256']) == 74 and len(control_source['sha256']) == 74
assert set(source['sha256']) == set(control_source['sha256'])
assert review['source_manifest_sha256'] == build['source_sha256'] == sha(D.parent/'source.json')
assert review['build_sha256'] == sha(D.parent/'build.json')
assert review['control_source_manifest_sha256'] == sha(control_path/'source.json')
assert review['control_build_sha256'] == sha(control_path/'build.json')
changed = {name: {'control': control_source['sha256'].get(name), 'candidate': h} for name, h in source['sha256'].items() if control_source['sha256'].get(name) != h}
assert changed == review['source_delta']
assert set(changed) == {'Cargo.lock', 'crates/oriole/Cargo.toml', 'crates/oriole/src/encoding.rs', 'crates/oriole/src/text.rs', 'crates/oriole/tests/text_coalescing.rs'}
assert source['sha256']['crates/oriole/src/tag.rs'] == control_source['sha256']['crates/oriole/src/tag.rs'] == '50f641a4eb62b6deb538851f60ea66ac425eceeb9cce539a27f5bc0ffc9a8de6'
prepared = load('/tmp/oriole-text-lane-masks-preparation/source.json')
assert source['sha256'] == prepared['sha256']
assert sha('/tmp/oriole-text-lane-masks-preparation/source.json') == review['prepared_source_sha256'] == '13408d5ae11c9108b651f401414aef6ced9286755a65ae188b64741461dc7e6e'
assert sha('/tmp/oriole-text-lane-masks-preparation/metadata-independent-review.json') == review['dependency_review_sha256'] == '45cd765fc1dd4759e2cc92dda846f5cdba4a51d1c978aa573c979888a235ba04'
assert sha('/tmp/oriole-text-lane-masks-preparation/format-metadata.json') == review['metadata_receipt_sha256'] == build['metadata_receipt_sha256']
assert prepared['auxiliary_sha256'] == review['auxiliary_files'] == build['auxiliary_files'] and build['auxiliary_unchanged']
check({str(Path(source['worktree'])/name): h for name,h in prepared['auxiliary_sha256'].items()})
assert sha('/tmp/oriole-text-lane-masks-preparation/complete-candidate.patch') == review['complete_seven_file_patch_sha256'] == prepared['complete_seven_file_patch_sha256']
assert len(review['dependency_compiler_vectors']) == len(build['dependency_compiler_vectors']) == 3
assert review['complete_patch_sha256'] == prepared['complete_patch_sha256'] == sha(D.parent/'candidate.patch')
for manifest in (source, control_source):
    check({str(Path(manifest['worktree'])/name): h for name, h in manifest['sha256'].items()})
assert review['candidate_libraries'] == build['libraries']
for engine, directory in (('candidate', D.parent/'normal'), ('control', control_path/'normal')):
    for name, h in review[engine+'_libraries'].items(): assert sha(directory/name) == h, name
    assert a['libraries'][engine] == {'path': str(directory/'liboriole_expat.so'), 'sha256': review[engine+'_libraries']['liboriole_expat.so']}
for v in a['libraries'].values(): assert sha(v['path']) == v['sha256']
reuse = load(D/'reuse.json'); check(reuse['pins'])
assert a['candidate_runtime_commit'] == reuse['candidate_runtime_commit'] == 'cacc0b1b3766176e9cbf71d25c5ff6867fa87c08'
assert reuse['candidate_source_base'] == source['base']
for engine, entry in reuse['engines'].items():
    assert entry['library_sha256'] == a['libraries'][engine]['sha256']
    assert a['consumer_directories'][engine] == entry['directory']
assert a['consumer_directories']['candidate'] == str(D/'consumers/candidate')
assert read(D/'python_worker.py') == read(Path(a['origin'])/'python_worker.py')
assert read(D/'run.py') == read(Path(a['origin'])/'run.py')
for p, h in pins.items(): assert hashlib.sha256(Path(p).read_bytes()).hexdigest() == h, p
with (D/'adaptation.json').open('x') as f: f.write(json.dumps(a, indent=2)+'\n')
result = {'status': 'passed', 'targets_executed': False, 'adaptation_sha256': sha(D/'adaptation.json'),
          'source_delta': changed, 'pins': pins,
          'scope': 'Saved normal parser source/build receipts and library outputs bound. Four historical O2 consumer artifacts remain in their original directories. No compiler, parser preflight or elapsed target executed by this binder.'}
with (D/'consumer-binding.json').open('x') as f: f.write(json.dumps(result, indent=2)+'\n')
print(json.dumps({'status':'passed', 'pins':len(pins), 'binding':str(D/'consumer-binding.json'), 'sha256':sha(D/'consumer-binding.json')}))
