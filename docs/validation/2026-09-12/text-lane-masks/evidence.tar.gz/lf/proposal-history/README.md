# LF and first-stop masks: separate source proposal

**Unformatted, unbuilt and unmeasured.** This alternate uses the tested fixed-width SIMD candidate `ae8e1904aedcb6c286d17e7626be51285e4be50a` as its source baseline; that candidate was rejected after its native measurement. All 74 measured source and four auxiliary hashes match that commit, whose parent is selected namespace `b9190cda`. The selected namespace runtime remains separate. No repository, compiler, parser, formatter or benchmark was changed or run by this proposal.

`proposal.patch` changes only `crates/oriole/src/text.rs` and focused tests in `encoding.rs` and `tests/text_coalescing.rs`. `proposal.json` binds the 74 baseline/proposed source hashes and the three changed files. `source/` and `baseline/` contain those files. `base-simd-complete.patch` preserves the baseline candidate's reviewed five-file composition, including its dependency locks; it is provenance, not a recommendation to adopt that rejected implementation.

## Mechanism and invariants

The 16-byte helper emits STOP and LF masks. STOP includes signed bytes below 32 except LF/TAB, plus `<`, `&` and `]`; this still rejects non-ASCII and allows DEL. An empty STOP mask consumes 16 bytes. Otherwise its least set bit identifies the first stop. `<` or `&` ends the plan after that prefix; every other stop abandons the whole proof. No scalar rescan of that vector prefix is needed, and bytes after a delimiter do not affect the result.

Only LF bits before the stop count. A nonzero prefix LF mask adds its population count and updates the last-line end from its highest set bit. Zero LF masks avoid those operations. TAB consumes one column. The proof keeps its four fields; position changes still occur only in the existing commit method, including the leading-LF adjustment after a prior CR.

The eight-byte SWAR branch, scalar short tail, 65,536-byte boundary check and position commit are byte-identical to the baseline. All 16-byte reads use the existing bounded `first_chunk` slice. Runtime code in `encoding.rs` is unchanged; only its existing eager-consumption test gains inputs. Native eligibility, raw ownership, event/accounting order, source compaction and parser integration are untouched.

The only small implementation choice beyond the note is checking whether the first stop is uncertain **before** accumulating its prefix LF summary. That avoids unused local work when the entire proof will be rejected; it changes no published state or error ordering.

## Focused tests prepared

- Adapt the existing 256-byte/all-16-lane mask test to compare both STOP and LF, plus all-LF and all-TAB vectors.
- Add first-stop and full position checks at offsets 0/7/8/15/16/23/24/31/32, including multiple LF before a delimiter, LF/invalid bytes after it, invalid bytes before it and both prior-CR states.
- Extend existing mixed-special cases at 7/8/15/16 and all 0–15 mixed short-tail lengths after LF/TAB vectors. Existing unaligned/plain-tail coverage remains.
- Extend the existing `Source::consume` versus `consume_text` comparison with multiple-LF vectors and a 65,536-byte multi-LF compaction case, keeping both prior-CR states. Existing 65,535/65,536/65,537 delimiter precedence tests remain unchanged.
- Extend the existing native-versus-explicit-US-ASCII collector with mixed valid and malformed text at every fixed feed width. It compares event, raw, position and error records using the original harness.

These are source additions, not passing test results. Root owns later independent review, composition, formatting, compilation and execution.

## Cost and scope limits

The older selected-Text instruction profile in `/tmp/oriole-text-lf-mask-followup.md` identifies scalar Text work as a modest cost envelope; it does not predict this proposal's elapsed gain. The current fixed-width candidate's native result was effectively flat overall with regressions, so this is a separate hypothesis.

Root's saved codegen inspection reports eight unconditional vector-constant loads in the fixed-width function, which combines 16-byte SIMD and the retained eight-byte SWAR tail. This proposal intentionally keeps that tail and does not attempt a constant/setup refactor. LF/TAB comparisons, a second mask extraction, population count and highest-set-bit operations add costs; generic x86-64 does not guarantee hardware POPCNT. Terminal/short spans and other architectures may regress. Emitted code and elapsed behavior remain unobserved for this proposal.

No dependencies or compiler settings change relative to the fixed-width source baseline. Applying the idea directly to selected namespace source requires explicit composition with the existing reviewed `wide`/`safe_arch`/`bytemuck` manifest/lock changes; the patch is not a standalone namespace-base change. No new PGO, target flags, raw-copy redesign, CR normalization or UTF-8 validation work is proposed.
