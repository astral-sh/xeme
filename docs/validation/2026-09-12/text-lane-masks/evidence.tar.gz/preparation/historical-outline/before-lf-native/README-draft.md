# Text classifier experiments — held publication outline

**The fixed 16-byte classifier was rejected. The LF/first-stop experiment is pending measurement in this outline.** These are separate candidates against the selected namespace runtime. Neither outcome changes the README readiness warning or license.

## 1. What changed and what was measured

Fixed16 (`ae8e1904`, normal SO `fd4a5274`) uses safe `wide` 16-byte predicates to skip plain ASCII, retaining the eight-byte/scalar path for special bytes. Selected control is namespace `b919`/publication `b698`, SO `d630`; Expat 2.8.4 normal SO `7a333`. Actual x86-64 code has a 16-byte load/comparisons/movemask and no calls in the 462-byte scan function. This is static evidence, not speed evidence. `wide1.7.0`, `safe_arch1.2.0` and `bytemuck1.25.2` are confined to the unselected experiment.

LF/first-stop carries a prefix newline count and last-line position from lane masks and stops immediately at the first delimiter or uncertain byte. Its prepared source is `13408d5a`; actual build/codegen/results/decision must be added from completed receipts. Do not inherit fixed16 performance or correctness results.

Both use the original native protocol: 24 real conditions and 4 generated controls, seven seeded pairs, 84 fresh preflight workers plus 588 timed workers, 672 workers and106,176 samples for the completed fixed16 campaign. A sample includes create, handlers, feeds, callbacks and free. Callback digests merge text fragments. Ratios are medians of seven paired process-median ratios, then equally weighted geometric means. CPU5 preflight/CPU0 timing, 90s worker/600s preflight/1200s elapsed bounds.

The normal Oriole compiler is local Ohm rustc 1.98.1-dev/ohm-1.98.1-1, with automatic experimental defaults disabled, O3/ThinLTO/one codegen unit. Expat uses GCC 13.3 O3 without LTO. No PGO or CPU-target sweep. Saved same-host inventory identifies AMD EPYC-Milan on Linux; that inventory predates this campaign, while current host counters are recorded below.

## 2. Fixed16 decision — all groups

| Group | Conditions | Candidate/control | Candidate/Expat | Wins |
|---|---:|---:|---:|---:|
| real | 24 | 0.999700372× | 1.445000629× | 9/24 |
| generated | 4 | 1.032372288× | 4.020048525× | 1/4 |
| real_namespaces_off | 12 | 1.008259565× | 1.393512529× | 2/12 |
| real_namespaces_on | 12 | 0.991213838× | 1.498391133× | 7/12 |

The real aggregate is effectively flat, with only 9/24 wins; namespaces-off and generated aggregates regress. All 18 adverse conditions remain below and in the full-precision CSV. The measured dependency/code change is not selected. LF outcome remains pending.

## 3. Every fixed16 condition

Lower is faster. **Adverse** marks every candidate/control ratio above 1; the 4KiB and 64KiB conditions, both namespace modes and both generated controls are retained.

| Project | Feed | NS | Candidate/control | Candidate/Expat | Outcome |
|---|---:|---|---:|---:|---|
| vulkan | 4096 | off | 1.003652163× | 1.613436020× | **Adverse** |
| vulkan | 4096 | on | 1.003711570× | 1.700588039× | **Adverse** |
| wayland | 4096 | off | 1.010390667× | 1.022690626× | **Adverse** |
| wayland | 4096 | on | 1.007013324× | 1.065794982× | **Adverse** |
| maven | 4096 | off | 1.012150048× | 1.779878085× | **Adverse** |
| maven | 4096 | on | 0.992530000× | 1.926175186× | Improved |
| batik | 4096 | off | 0.995511741× | 0.978707187× | Improved |
| batik | 4096 | on | 0.984879122× | 1.077903366× | Improved |
| gtk | 4096 | off | 1.015602863× | 1.531664309× | **Adverse** |
| gtk | 4096 | on | 1.011772956× | 1.569961911× | **Adverse** |
| docbook | 4096 | off | 1.014193071× | 1.397553310× | **Adverse** |
| docbook | 4096 | on | 0.970352506× | 1.647284133× | Improved |
| generated-rare-declarations | 4096 | off | 0.999214936× | 4.697273365× | Improved |
| generated-entities | 4096 | off | 1.061927286× | 3.436267381× | **Adverse** |
| vulkan | 65536 | off | 1.009924309× | 1.579416692× | **Adverse** |
| vulkan | 65536 | on | 0.978617632× | 1.684216544× | Improved |
| wayland | 65536 | off | 0.997712373× | 1.007245918× | Improved |
| wayland | 65536 | on | 1.002848227× | 1.040154737× | **Adverse** |
| maven | 65536 | off | 1.012121002× | 1.974808778× | **Adverse** |
| maven | 65536 | on | 0.981965175× | 2.057970864× | Improved |
| batik | 65536 | off | 1.000474257× | 1.108461053× | **Adverse** |
| batik | 65536 | on | 0.984339745× | 1.198533402× | Improved |
| gtk | 65536 | off | 1.012351625× | 1.650623100× | **Adverse** |
| gtk | 65536 | on | 1.004953222× | 1.713545474× | **Adverse** |
| docbook | 65536 | off | 1.015303525× | 1.516120965× | **Adverse** |
| docbook | 65536 | on | 0.972724275× | 1.777523779× | Improved |
| generated-rare-declarations | 65536 | off | 1.002103052× | 4.787211597× | **Adverse** |
| generated-entities | 65536 | off | 1.068265668× | 3.379946085× | **Adverse** |

## 4. Correctness scope and retained first attempts

Fixed16 passed 454 Rust tests in 35 groups, workspace formatting/strict Clippy, inprocess benchmark formatting and locked strict Clippy and ordinary release compilation. Native preflights and all measured callbacks agreed. It was rejected before Python timing, original API matrix, strict CPython, sustained fuzz or PBS refresh; none is claimed here. LF gets its own completed gates only if root executes them.

Retain the fixed16 first metadata-reader missing-checksum assumption, initial static symbol-name failure and address-line-label correction. Retain the LF stop0 test adjustment and first saved-reader overly broad replacement correction. These are preparation/review histories, not compiler or parser failures. Do not count metadata-only work as runtime correctness coverage.

## 5. Host evidence

Fixed16 has two prehost 10-second observations: CPU0 idle+iowait 91.14% first and 99.20% after the local push completed; both remain. The 18 fully interior 5-second monitor intervals cover 90.05 of 95.90 timing seconds: whole host 92.35% idle+iowait, other CPUs 95.30%, benchmark CPU0 1.12%. Two intervals crossing phase boundaries are retained but excluded from that calculation. Affinity and local scheduling do not establish globally exclusive or idle execution. There are no per-worker absolute timestamps for assigning host load to particular conditions and no statistical-significance claim. LF requires its own raw host observations and independent interval reconstruction.

## 6. Earlier instruction evidence — exact scope

The profile context is **selected Text `ea52004`/SO `ef1648`, before namespace `b919`**. Four profiles cover Vulkan/Maven 64KiB feeds with namespaces off, Oriole and Expat. Both warmup and measured XML_Parse windows include callbacks; creation/destruction are outside. It is not a profile of namespace, fixed16 or LF. Total instruction ratios were 1.58318× Vulkan and 2.27471× Maven; instruction counts do not measure cycles or removable elapsed cost. The older scalar-loop/predicate attribution motivates the separate hypothesis without predicting a speedup. Self rows/PCs are bound to exact objects; historical callee/inclusive fields are excluded.

## 7. Packet and publication boundary

`collection-outline.json` identifies the exact raw reports, 672 worker records, input hashes, codegen captures, source patches and compiler logs to collect. `fixed16-worker-pins.json` reuses the already audited full worker hash map; this outline does not rehash or repackage raw workers. `shared-input-pins.json` identifies the eight XML fixtures and driver. Share common inputs once; include selected control source/build pins without recursively copying historical benchmark archives. Exclude targets/caches/toolchains/PGO. Measured ELF files may be separate hash-pinned attachments when exact static or executable replay is required; raw arithmetic alone does not prove a newly rebuilt binary is identical.

Hold archive assembly and repository changes until LF completes or is explicitly canceled. Then fill its own all-condition table/decision/gates/host data, bind actual runtime commit and library, and run one independent inventory/raw/prose review. Attach the combined report to a selected optimization PR or a docs-only follow-up; preserve all historical reports and README warning/license bytes. No selected performance pointer should cite a rejected candidate as the production runtime.
