# Four entry-document changes — outline only

The files in `base-docs/` preserve PR157's current README, compatibility guide, review guide and benchmark entrypoint. No selected benchmark number is changed while confirmation is pending. The final patch should stay small and leave every historical packet intact.

## README.md

Keep the Toucan-style heading, warning, Highlights/Benchmarks/development structure and exact complete License section. After root decides, describe the selected Text classifier in one sentence: classify 16 ASCII bytes at once, stop at the first delimiter/invalid byte, and count only LF bytes preceding that stop. The source continues to use the existing scalar/8-byte fallback, raw ownership and position commit.

If selected, update the existing six-project table only from completed LF confirmation native medians and paired ratios. Feature the confirmation aggregate and CPython result, retain adverse cases in the linked packet, and state that the ordinary native/CPython 10% target remains unmet where applicable. Link `docs/validation/2026-09-12/text-lane-masks/`. Do not transfer prior PGO/v3/PBS/sanitizer results to this new dependency/source revision. If rejected, leave selected benchmark claims unchanged and link the experiment from the review guide.

## docs/compatibility.md

Add a compact current-source validation paragraph: LF455 Rust tests, unchanged 4,740 original API classifications, six passing C consumers, strict shared/static802 methods with two remaining failures, and two separate supplemental semantic tests per linkage. Explicitly distinguish the patched strict consumer from the unmodified benchmark consumer and C-only sanitizers from uninstrumented Rust. Dependency metadata/source/license review is completed; metadata alone does not establish tested MSRV, runtime CPU dispatch, every architecture, or production readiness.

## docs/review.md

Record fixed16's rejected result and the LF implementation/decision separately. Link the new packet; state that fixed16 downstream gates were unexecuted and that LF had its own full gates and two separate timing epochs. Summarize the main boundary reasoning, first-stop/LF-prefix tests and existing 64KiB/previous-CR behavior. Retain the metadata-label race and reader corrections in the packet without presenting them as target failures. Link exact source/dependency/codegen reviews and avoid unsupported assembly-to-speed causation.

## benchmarks/README.md

Lead with the actual selected normal packet after root decides, with initial and confirmation LF epochs kept distinct. Retain normal O3/ThinLTO/one codegen unit as Oriole-specific and label Expat's independent GCC O3/no-LTO recipe. Preserve all old values/links and their historical PGO/LTO labels. State that new performance work uses normal release builds and PGO experiments remain stopped.

## New packet README

Use concise sections: Decision and scope; Results (five campaign rows plus independent host limits); Implementation and dependencies; Compatibility; Reproduction and raw evidence. Full-precision tables and every adverse case live in report/CSV. Include all132 conditions but never pool observations or present fixed16-versus-LF as a paired comparison. Final prose is held until confirmation and the root decision are available.
