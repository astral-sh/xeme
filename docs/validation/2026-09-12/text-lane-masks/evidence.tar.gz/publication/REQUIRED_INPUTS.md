# Text lane-mask publication inputs — held

The publication target is `docs/validation/2026-09-12/text-lane-masks/`, a new packet on PR157. Preparation does not create that directory or run the assembler. Root must release saved assembly after both confirmation controllers, host monitors and independent readers finish and are reaped. No repository, historical packet, compiler or parser is changed here.

## Measured campaigns

| Campaign | Conditions | Workers, including preflight | Samples, including warmup |
| --- | ---: | ---: | ---: |
| Rejected fixed16 native | 28 | 672 | 106,176 |
| LF initial native | 28 | 672 | 106,176 |
| LF initial CPython | 24 | 576 | 26,364 |
| LF confirmation native | 28 | 672 | 106,176 |
| LF confirmation CPython | 24 | 576 | 26,364 |
| Archive total | 132 | 3,168 | 371,256 |

Every condition and adverse result is retained. Fixed16 has 18 adverse conditions; initial LF has five native and two Python adverse conditions. Confirmation adverse counts and selected summary values remain pending. Epochs are never pooled, and the fixed16 versus LF comparison is not a paired timing measurement.

`required-inputs.json` lists explicit source/build/check/codegen/proposal/correctness/worker trees and already completed controller/reviewer files. The assembler reuses the namespace packet's deterministic gzip, member index and full archive/original-byte readback. It excludes libraries, ELF files, static archives, bytecode, compiler profiles, cache trees and machine Cargo configuration while retaining the relevant identities. It includes no historical benchmark campaign beyond the five listed above. Historical absolute reader paths remain documented; this is an indexed saved-record packet, not a new portable execution framework.

## Source, dependencies and correctness

- Namespace control: runtime `b9190cda8b04092a5691d8ec1cbefbc116f9e4e4`, published PR157 `b6985f0d07e9b3456f36f77eac97cf7bf013a650`, ordinary shared library `d6303603…`.
- Rejected fixed16: `ae8e1904aedcb6c286d17e7626be51285e4be50a`, full raw decision and source/build records retained. No Python or full API/strict campaign ran for that rejected candidate.
- LF candidate: `cacc0b1b3766176e9cbf71d25c5ff6867fa87c08`, prebuild source base `b6985f0d…`; 74 main source files, five main deltas and two auxiliary lock changes. Equal source bytes are stored once through three explicit source member maps. Both benchmark/fuzz manifests and locks are retained.
- The three checksum-pinned dependency archives (`wide 1.7.0`, `safe_arch 1.2.0`, `bytemuck 1.25.2`) and their 156 exact source files, including licenses, are included. Existing metadata reviews retain full main/benchmark/fuzz graph checks, feature resolution, archive/source validation and corrected first-reader attempts. Metadata is not an MSRV or cross-platform execution result.
- LF ordinary workspace results: 455 Rust tests across 35 groups, formatting, strict workspace Clippy, locked/offline benchmark formatting/Clippy and release vectors. Fixed16 keeps its own 454-test results. Oriole uses ordinary generic O3/ThinLTO/one codegen unit; the pinned normal Expat control separately uses GCC13.3 O3 without LTO. No new PGO work or CPU-target flags.
- Original API: all 4,740 ordered outcomes remain 4,347 passes, 391 assertion failures and two timeouts (raw exit 1). Six C consumer variants pass; only their C code has ASan/UBSan instrumentation, linked Rust remains ordinary release and leak detection is disabled.
- Strict CPython: shared/static each retain 802 methods and 809 rendered outcomes, with the same two callback-fragmentation failures and raw exit 2. Strict modules alone contain the documented upstream cleanup backport; benchmark modules use unmodified CPython source. The two supplemental semantic tests pass per linkage and do not change the strict failures.
- The correctness metadata race is preserved: old finalizer `438a1d77…` was materialized and its binder56240 succeeded, before the descriptive strict-source label changed. Root applied the separate metadata correction25992, rebind33573 and strict bind57247 successfully. All nine execution/read scripts stayed unchanged. This was neither a parser failure nor a target rerun. Before/correction/after records and both source-review scopes are retained.

## Required before assembly

1. Both completed confirmation primary reports, full raw workers/fresh preflights, before/during host counters and independent native/Python raw-and-host receipts.
2. Root's final decision/reaping receipt and commit/source binding for LF and fixed16, including auxiliary locks. Restacked documentation commits must be described as source-equivalent to measured `cacc…`, if applicable.
3. `final-publication.json`, created from the held template, with exact final review hashes and additional retained root session/attempt files. Its status must explicitly release completed saved-data assembly. No elapsed process may be active during compression/readback.
4. `report-README.md` and the four final entry documents under `draft/`. Selected numbers must come from the completed confirmation reader, with the initial epoch shown separately. `README-preserved-sections.json` requires byte-exact PR157 warning and full License section.

Root-authorized saved launch, only after those steps: `taskset -c 6 python3 -I assemble.py --released`. Independent final review must verify archive/member/original hashes, source/auxiliary/dependency identity, 132 condition rows and all adverse rows, gate counts and relative documentation links.

## Host and readiness limits

All measurements use a shared host. CPU affinity and the absence of concurrent Oriole targets do not establish a globally idle or isolated machine. Preserve every before/during observation, include iowait in the labelled counter, and avoid significance or per-condition interference claims without corresponding evidence. One confirmation per consumer is authorized; no additional tuning or rerun is implied. The within-10% goal, remaining strict failures and unexecuted platform validation must remain explicit after the final decision.
