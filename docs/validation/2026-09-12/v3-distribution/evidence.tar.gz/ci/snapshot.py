"""Retain one compact-metadata snapshot; no logs, artifacts, or target execution."""
from pathlib import Path
import datetime,json,subprocess
ROOT=Path('/home/dev-user/code/oss/oriole-v3-trial')
OUT=Path(__file__).parent
HEAD='9d4d268f9629cb2d528b3e11e781698e99d7d82d'
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
for name,run in [('ci',34660814709),('manual-pbs-v3-pgo',34660840404)]:
    if (OUT/f'{name}-completed.json').exists():
        continue
    command=['/home/dev-user/.local/bin/gh-auto','run','view',str(run),'--json','databaseId,url,event,headSha,status,conclusion,createdAt,updatedAt,jobs']
    raw=subprocess.check_output(command,cwd=ROOT,text=True,timeout=60)
    record=json.loads(raw);assert record['headSha']==HEAD
    (OUT/f'{name}-{stamp}.json').write_text(raw)
    if record['status']=='completed':(OUT/f'{name}-completed.json').write_text(raw)
    print(json.dumps({'run':run,'url':record['url'],'head':record['headSha'],'status':record['status'],'conclusion':record['conclusion'],
                      'jobs':[{'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],
                               'active':[s['name'] for s in j['steps'] if s['status']=='in_progress'],
                               'failed':[s['name'] for s in j['steps'] if s['conclusion'] in ('failure','timed_out','cancelled')]} for j in record['jobs']]}))
