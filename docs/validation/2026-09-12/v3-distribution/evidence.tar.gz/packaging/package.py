"""Reuse the compact stable-PBS packet method for the completed explicit-v3 trial."""
import argparse,gzip,hashlib,io,json,os,tarfile,zipfile
from pathlib import Path
cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('--released',action='store_true',required=True);cli.parse_args()
assert os.sched_getaffinity(0)=={6}
ROOT=Path('/tmp/oriole-pbs-v3-workflow-results')
PREP=Path('/tmp/oriole-pbs-v3-workflow-review-prep')
HERE=Path(__file__).parent
OUT=Path('/tmp/oriole-pbs-v3-workflow-package')
SOURCE=Path('/home/dev-user/code/oss/oriole-v3-trial')
HOST=Path('/tmp/oriole-v3-text-fragmentation-followup')
CI=Path('/tmp/oriole-pr150-ci-results')
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_bytes())
report=read(ROOT/'report.json');semantic=read(ROOT/'supplemental-semantics.json');expected=read(PREP/'expected-source.json')
assert sha((ROOT/'report.json').read_bytes())=='3321b1b3d333287995d35b08f99c7803f56cd3f93ce8ea21eb999837d6ded961'
assert semantic['status']=='saved_supplemental_results_verified' and semantic['installed_distribution']['tests']==2
assert semantic['separate_host_modules']['tests']==4
assert read(HOST/'installed-wrapper-review.json')['status'].startswith('passed')
assert report['run']['id']==34660840404 and report['run']['conclusion']=='failure'
assert not OUT.exists()
payloads,origins={},{}
def add_bytes(name,data,origin):
    assert name not in payloads and not name.startswith('/') and '..' not in Path(name).parts
    assert not data.startswith((b'\x7fELF',b'!<arch>\n')),'Compiled file: '+name
    payloads[name],origins[name]=data,origin

def add(name,path,compressed=False):
    data=path.read_bytes();origin={'path':str(path),'source_bytes':len(data),'source_sha256':sha(data)}
    if compressed:
        data=gzip.compress(data,compresslevel=3,mtime=0);origin['transformation']='gzip level 3, mtime 0'
    add_bytes(name,data,origin)

for path in sorted(ROOT.iterdir()):
    if not path.is_file() or path.name in {'distribution.zip','distribution.tar'} or path.name.endswith('.tar.zst'):continue
    if path.name in {'workflow.log','distribution-members.json','python-dynsym.txt','libpython-dynsym.txt'}:
        add(path.name+'.gz',path,compressed=True)
    else:add(path.name,path)
for path in sorted(PREP.iterdir()):
    if path.is_file():add('readers/'+path.name,path)
for path in sorted(HOST.iterdir()):
    if path.is_file():add('separate-host-module-semantics/'+path.name,path)
for name in ['ci-completed.json','ci-receipt.json','manual-pbs-v3-pgo-completed.json','manual-pbs-receipt.json','pr-triggered-pbs-skipped.json','snapshot.py']:
    add('ci/'+name,CI/name)
for name in ['semantic_receipt.py','semantic-readback01.stdout','semantic-readback01.stderr','package.py']:
    add('packaging/'+name,HERE/name)
add('packaging/previous-stable-package.py',Path('/tmp/oriole-reference-frame-pbs-publication-prep/package.py'))

source={}
for mapping in [expected['bundle_source_sha256'],expected['pgo_source_sha256'],expected['support_sha256'],{'tools/pgo/'+p:d for p,d in expected['pipeline_sha256'].items()}]:
    for name,digest in mapping.items():
        assert name not in source or source[name]==digest
        source[name]=digest
for name in ['THIRD_PARTY_LICENSES.md','licenses/expat.txt','licenses/libxml2.txt','tools/cpython/text_fragmentation.py']:
    source[name]=sha((SOURCE/name).read_bytes())
assert source['tools/cpython/text_fragmentation.py']=='97b76ae05228951f85fab5887ed9727cb2d218016cd049a898080d2e0d6fc4b4'
for name,digest in sorted(source.items()):
    assert sha((SOURCE/name).read_bytes())==digest
    add('source/'+name,SOURCE/name)

# Preserve all supplemental consumer input records and loader source; binaries remain hash-only.
held=read(HOST/'held-commands.json');external={}
seen_paths={o['path'] for o in origins.values() if 'path' in o}
for name,digest in held['pins_sha256'].items():
    path=Path(name);data=path.read_bytes();assert sha(data)==digest
    if name in seen_paths:continue
    if data.startswith((b'\x7fELF',b'!<arch>\n')) or path.suffix in {'.so','.a'}:
        external[name]={'sha256':digest,'bytes':len(data),'scope':'Separate local host-module supplemental input; binary omitted.'}
    else:add('separate-host-module-inputs/'+name.lstrip('/'),path)

# Retain selected nonbinary distribution data, every license and COPYING notice.
with (ROOT/'distribution.tar').open('rb') as stream:tar_sha=hashlib.file_digest(stream,'sha256').hexdigest()
selected=[]
with tarfile.open(ROOT/'distribution.tar','r:') as archive:
    for item in archive:
        include=item.isfile() and (item.name in {'python/PYTHON.json','python/build/run_tests.py'} or item.name.startswith('python/licenses/') or Path(item.name).name=='COPYING')
        if not include:continue
        data=archive.extractfile(item).read()
        add_bytes('selected/'+item.name,data,{'archive':str(ROOT/'distribution.tar'),'archive_sha256':tar_sha,'member':item.name,'source_bytes':len(data),'source_sha256':sha(data)})
        selected.append(item.name)
assert payloads['selected/python/licenses/LICENSE.oriole-build.txt']==(ROOT/'validation/oriole-bundle/manifest.json').read_bytes()
assert len([name for name in selected if Path(name).name=='COPYING'])==2
raw_members=[]
with zipfile.ZipFile(io.BytesIO(payloads['validation.zip'])) as archive:
    assert archive.testzip() is None
    for item in archive.infolist():
        assert not item.is_dir()
        data=archive.read(item.filename)
        assert data==(ROOT/'validation'/item.filename).read_bytes()
        assert not data.startswith((b'\x7fELF',b'!<arch>\n'))
        assert not item.filename.endswith(('.a','.so','.dylib'))
        raw_members.append({'name':item.filename,'bytes':len(data),'sha256':sha(data)})
assert sha(payloads['validation.zip'])=='2ad729039384def0f1217d1bbc9a4e6426d4d918b7c84e35a0e31f73b07100ba'
add_bytes('validation-members.json',(json.dumps(raw_members,indent=2)+'\n').encode(),{'derived_from':'validation.zip','scope':'All original ZIP members match saved raw logs, input/profile bytes and records.'})
for name in payloads:assert name!='distribution.zip' and not name.endswith(('.so','.a','.tar.zst'))

readme='''# Explicit x86-64-v3 PGO PBS trial

[Manual workflow 34660840404](https://github.com/astral-sh/oriole/actions/runs/34660840404)
built and validated the distribution's target and installed archive identity at
`9d4d268f9629cb2d528b3e11e781698e99d7d82d`. **The workflow remains failed on two
strict XML callback assertions.** All 16 separate PR150 CI jobs passed; the
PR-triggered distribution run was intentionally skipped.

| Check | Actual outcome |
| --- | --- |
| Explicit v3 CPU/OS guards, fresh PGO bundle and PBS build | Passed |
| Installed target, manifest and static archive provenance | Passed |
| Complete distribution validator | Passed |
| Custom distribution suite | 22 tests: 17 passed, 5 skipped |
| Host strict XML suite | 802 initial tests, 2 failures; 806 executions and 4 failures including retries; 12 skips |
| glibc 2.17 identity and thread probe | Passed, 1,024 threaded parses |
| glibc 2.17 strict XML suite | 802 tests, 2 failures, 13 skips; subprocess exit 2 |
| Installed supplemental text semantics on the local host | 2 passed, 0 skipped |
| Separate local v3 shared/static module supplements | 2 passed per mode, 4 total |

The two strict methods are `test.test_pyexpat.BufferTextTest.test1` and
`test.test_sax.CDATAHandlerTest.test_handlers`. Host retries repeat those methods;
they are not four distinct failures. The glibc identity/thread probe succeeds
before the strict XML subprocess fails. Original assertion text, skips and
workflow failures are retained. Aggregate logs do not provide a full method map.

The installed interpreter has built-in `pyexpat`, with no `__file__`. Its
supplemental wrapper pins the interpreter and unchanged `97b76ae0` test script,
checks the actual built-in origin and Oriole version, then runs both original
test methods. It replaces only the shared-extension-specific entry-point guard.
The semantic checks combine adjacent text while preserving every whitespace
character, buffering control and element/CDATA boundary. Their success is
separate from the unchanged strict failures. The local shared/static module
results use different already-built consumers and are labeled separately.

The archive is the actual `x86_64_v3-unknown-linux-gnu` PBS product; Rust keeps
`x86_64-unknown-linux-gnu` as its ABI target and explicitly selects
`target-cpu=x86-64-v3`. The readback verifies 75 bundle source pins, 69 PGO source
pins, six pipeline files, six actual workspace compiler vectors and 288 generated
observations in each of the fresh generate/use phases. Stable Rust 1.98.1 uses
O3, ThinLTO, one codegen unit, PIC and unwind behavior. The shipped static
archive exactly matches this run's PGO-use archive. Both inspected ELF files
reference glibc no newer than 2.17 and have no dynamic Expat dependency.

[Report](report.json) retains the original remote outcomes.
[Supplemental results](supplemental-semantics.json) retain the local execution
commands, supervising root session receipts and source hashes. The
[archive index](archive-members.json) binds every [saved-record member](evidence.tar.gz)
to its source bytes; all members and the nested validation ZIP were read back.
Source, license/COPYING notices, raw logs, generated inputs and profile data are
included. The 48,320,149-byte distribution and compiled binaries are omitted;
their exact API, archive and selected-member digests remain recorded.
Historical reader assumptions and corrections are preserved. Paths under `/tmp`
and `/home` identify the original machine; archive member names are relative.

This is an opt-in CPU-specific deployment trial, with generic defaults unchanged.
It adds no performance measurement or production-readiness claim. Strict
compatibility gaps and the broader performance goals remain documented separately.
'''
add_bytes('README.md',readme.encode(),{'derived_from':'report.json and supplemental-semantics.json','scope':'Concise publication summary of separately reported actual outcomes.'})
OUT.mkdir();members=[];buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w',format=tarfile.PAX_FORMAT) as archive:
    for name,data in sorted(payloads.items()):
        item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.uid=item.gid=item.mtime=0
        archive.addfile(item,io.BytesIO(data));members.append({'name':name,'bytes':len(data),'sha256':sha(data),'origin':origins[name]})
packed=gzip.compress(buffer.getvalue(),compresslevel=3,mtime=0)
(OUT/'evidence.tar.gz').write_bytes(packed)
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as archive:
    assert archive.getnames()==sorted(payloads)
    for item in archive:assert archive.extractfile(item).read()==payloads[item.name]
index={'archive':'evidence.tar.gz','bytes':len(packed),'sha256':sha(packed),'members':members,'raw_validation_members':len(raw_members),'source_run':report['run']['url'],'source_snapshot_files':len(source),'selected_nonbinary_distribution_members':selected,'distribution_tar_sha256':tar_sha,'binary_exclusions':report['binary_publication_exclusions']+['distribution.tar','runtime/'],'separate_host_module_binary_inputs':external,'readback':'Every final archive member read back byte-for-byte; every nested validation ZIP member matched its saved original. Source and selected license/COPYING bytes retained; no compiled binaries or full distribution archive included.'}
(OUT/'archive-members.json').write_text(json.dumps(index,indent=2)+'\n')
for name in ['README.md','report.json','supplemental-semantics.json']:(OUT/name).write_bytes(payloads[name])
files={'files':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(OUT.iterdir()) if p.name!='files.json']}
(OUT/'files.json').write_text(json.dumps(files,indent=2)+'\n')
receipt={'status':'passed_saved_packet_readback','output':str(OUT),'archive_bytes':len(packed),'archive_sha256':sha(packed),'members':len(members),'nested_validation_members':len(raw_members),'source_snapshot_files':len(source),'selected_nonbinary_distribution_members':len(selected),'supplemental_host_module_tests':4,'installed_semantic_tests':2,'report_sha256':sha(payloads['report.json']),'semantic_sha256':sha(payloads['supplemental-semantics.json']),'targets_executed_by_packager':False}
(HERE/'package-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
