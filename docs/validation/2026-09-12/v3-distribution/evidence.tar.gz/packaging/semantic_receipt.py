"""Read saved supplemental results; no interpreter or parser execution."""
from pathlib import Path
import hashlib,json
ROOT=Path('/tmp/oriole-pbs-v3-workflow-results')
PREP=Path('/tmp/oriole-pbs-v3-workflow-review-prep')
HOST=Path('/tmp/oriole-v3-text-fragmentation-followup')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
script=Path('/home/dev-user/code/oss/oriole-reference-frame/tools/cpython/text_fragmentation.py')
assert sha(script)=='97b76ae05228951f85fab5887ed9727cb2d218016cd049a898080d2e0d6fc4b4'
origin=read(ROOT/'installed-origin.stdout');result=read(ROOT/'installed-semantics.stdout')
assert origin['module_file'] is None and origin['spec_origin']=='built-in' and not origin['existing_semantic_guard_compatible']
assert result['origin']=='built-in' and result['expat_version']=='oriole_compat_2.8.4'
assert (ROOT/'installed-origin.stderr').read_text()==''
text=(ROOT/'installed-semantics.stderr').read_text()
assert text.rstrip().endswith('OK') and 'Ran 2 tests' in text and text.count(' ... ok')==2 and 'skipped' not in text
extracted=read(ROOT/'runtime-extraction.json')
assert sha(extracted['interpreter'])==extracted['interpreter_sha256']=='b71071a78ef3f98479eed2ee0b8c3f2ea806ec97beefb2a5692a75055f09e2c6'
commands=[]
for label,session,filename in [('origin',63453,'origin_probe.py'),('semantics',13307,'installed_semantics.py')]:
    argv=['env',*[item for key in ['LD_PRELOAD','LD_LIBRARY_PATH','PYTHONPATH','PYTHONHOME','ASAN_OPTIONS','UBSAN_OPTIONS','LLVM_PROFILE_FILE'] for item in ['-u',key]],'timeout','--signal=TERM','--kill-after=5s','120s','taskset','-c','3',extracted['interpreter'],'-I',str(PREP/filename)]
    stem='installed-'+label
    commands.append({'label':label,'argv':argv,'root_tool_session':session,'exit':0,'reaped':True,'execution_record_source':'Root supervising-agent report of completed/reaped session; stdout/stderr and input hashes independently read here.','wrapper_sha256':sha(PREP/filename),'stdout_sha256':sha(ROOT/(stem+'.stdout')),'stderr_sha256':sha(ROOT/(stem+'.stderr'))})
held=read(HOST/'held-commands.json');host=read(HOST/'results.json')
assert host['status']=='passed' and host['semantic_tests']==4 and host['strict_outcomes_unchanged']
assert sha(HOST/'held-commands.json')==host['held_sha256']
for path,digest in held['pins_sha256'].items():assert sha(path)==digest,path
for command in host['commands']:
    mode=command['mode'];assert command['exit']==0 and command['reaped']
    assert command['argv']==next(c['argv'] for c in held['commands'] if c['mode']==mode)
    for stream in ('stdout','stderr'):assert sha(HOST/(mode+'.'+stream))==command[stream+'_sha256']
    stderr=(HOST/(mode+'.stderr')).read_text();assert 'Ran 2 tests' in stderr and stderr.rstrip().endswith('OK') and stderr.count(' ... ok')==2
receipt={'status':'saved_supplemental_results_verified','existing_test_script':str(script),'existing_test_script_sha256':sha(script),'installed_distribution':{'origin':origin,'semantic_result':result,'tests':2,'failures':0,'skipped':0,'interpreter_sha256':extracted['interpreter_sha256'],'libpython_sha256':extracted['libpython_sha256'],'commands':commands,'guard_adaptation':'The existing script __main__ guard requires pyexpat.__file__, which the actual built-in module lacks. Root wrapper verifies the exact interpreter/script hashes and real built-in origin/version, then loads the unchanged test class and runs both methods. No fake path or changed semantic assertion.','local_execution_scope':'Host execution only; the workflow supplies the separate glibc 2.17 probe and strict-suite results.'},'separate_host_modules':{'tests':4,'failures':0,'modes':['shared','static'],'source_results_sha256':sha(HOST/'results.json'),'source_held_commands_sha256':sha(HOST/'held-commands.json'),'input_pins_verified':len(held['pins_sha256']),'scope':'Previously built local v3 PGO CPython extensions with explicit cleanup backport; these are separate from the shipped PBS interpreter.'},'strict_results':'Original host802 initial/2 failures (806 aggregate/4 with retries), glibc802/2 and local shared/static802/2 remain unchanged. Supplemental acceptance combines only adjacent text while preserving all characters, buffering controls and element/CDATA boundaries.'}
(ROOT/'supplemental-semantics.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'sha256':sha(ROOT/'supplemental-semantics.json'),'installed_tests':2,'separate_host_module_tests':4}))
