"""Download exact completed-run evidence without executing artifact contents."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--released',action='store_true',required=True);p.parse_args()
assert os.sched_getaffinity(0)=={6}
ROOT=Path('/home/dev-user/code/oss/oriole-v3-trial')
OUT=Path('/tmp/oriole-pbs-v3-workflow-results')
assert not OUT.exists()
OUT.mkdir()
GH='/home/dev-user/.local/bin/gh-auto'
RUN=34660840404
HEAD='9d4d268f9629cb2d528b3e11e781698e99d7d82d'
BASE=f'repos/astral-sh/oriole/actions/runs/{RUN}'
records=[]
def save(name,arguments):
    path=OUT/name
    with path.open('xb') as output:
        result=subprocess.run([GH,*arguments],cwd=ROOT,stdout=output,stderr=subprocess.PIPE,timeout=300)
    (OUT/(name+'.stderr')).write_bytes(result.stderr)
    result.check_returncode()
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    records.append({'file':name,'command':[GH,*arguments],'size':path.stat().st_size,'sha256':digest,'exit':result.returncode})
    return path
run=json.loads(save('run.json',['api',BASE]).read_text())
assert run['id']==RUN and run['head_sha']==HEAD and run['event']=='workflow_dispatch' and run['status']=='completed'
save('jobs.json',['api',BASE+'/jobs?per_page=100'])
artifacts=json.loads(save('artifacts.json',['api',BASE+'/artifacts?per_page=100']).read_text())['artifacts']
for filename,label in [('validation.zip','oriole-pbs-validation-x86_64_v3-unknown-linux-gnu-pgo'),('distribution.zip','oriole-pbs-experimental-x86_64_v3-unknown-linux-gnu-pgo')]:
    selected=[a for a in artifacts if a['name']==label]
    assert len(selected)==1,(filename,selected)
    artifact=selected[0]
    assert artifact['workflow_run']['id']==RUN and artifact['workflow_run']['head_sha']==HEAD and not artifact['expired']
    path=save(filename,['api',f"repos/astral-sh/oriole/actions/artifacts/{artifact['id']}/zip"])
    assert artifact['digest']=='sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()
save('workflow.log',['run','view',str(RUN),'--log'])
receipt={'status':'downloaded_api_digest_verified','head':HEAD,'run':RUN,'records':records,'targets_executed':False,'scope':'Exact artifact ZIP digest matches GitHub API metadata; this is not independent signature verification.'}
(OUT/'download.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'head':HEAD,'run':RUN,'files':[{k:r[k] for k in ('file','size','sha256')}for r in records]},indent=2))
