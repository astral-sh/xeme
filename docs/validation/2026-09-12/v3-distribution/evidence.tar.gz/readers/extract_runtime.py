"""Extract the verified installation as data for a separately released root probe."""
from pathlib import Path
import hashlib,json,os,tarfile
assert os.sched_getaffinity(0)=={6}
ROOT=Path('/tmp/oriole-pbs-v3-workflow-results')
report=json.loads((ROOT/'report.json').read_text())
index=json.loads((ROOT/'distribution-members.json').read_text())
assert report['distribution']['sha256']==index['sha256']
dest=ROOT/'runtime';assert not dest.exists();dest.mkdir()
with tarfile.open(ROOT/'distribution.tar') as archive:
    actual=archive.getmembers()
    assert [(m.name,m.size,m.type.decode(),m.linkname)for m in actual]==[(m['name'],m['size'],m['type'],m['linkname'])for m in index['members']]
    selected=[m for m in actual if m.name.startswith('python/install/') or m.name=='python/PYTHON.json']
    archive.extractall(dest,members=selected,filter='data')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for relative in ['python/PYTHON.json','python/install/bin/python3.12','python/install/lib/libpython3.12.so.1.0']:
    assert sha(dest/relative)==sha(ROOT/'selected'/relative)
receipt={'status':'runtime_extracted_as_data','members':len(selected),'root':str(dest/'python'),'interpreter':str(dest/'python/install/bin/python3.12'),'interpreter_sha256':sha(dest/'python/install/bin/python3.12'),'libpython_sha256':sha(dest/'python/install/lib/libpython3.12.so.1.0'),'metadata_sha256':sha(dest/'python/PYTHON.json'),'source_distribution_sha256':index['sha256'],'targets_executed':False}
(ROOT/'runtime-extraction.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
