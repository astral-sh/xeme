"""Inspect downloaded PBS archives as data; never execute downloaded code."""
import argparse
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import tarfile
import zipfile

cli = argparse.ArgumentParser(description=__doc__)
cli.add_argument('--root', type=Path, required=True)
cli.add_argument('--released', action='store_true', required=True)
args = cli.parse_args()
root = args.root
expected = json.loads((Path(__file__).parent / 'expected-source.json').read_text())
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
read = lambda path: json.loads(Path(path).read_text())
run = read(root / 'run.json')
assert run['id'] == expected['run_id'] and run['head_sha'] == expected['head']
assert run['event'] == 'workflow_dispatch' and run['status'] == 'completed'
artifacts = read(root / 'artifacts.json')['artifacts']
for filename, label in [('validation.zip', 'oriole-pbs-validation-x86_64_v3-unknown-linux-gnu-pgo'),
                        ('distribution.zip', 'oriole-pbs-experimental-x86_64_v3-unknown-linux-gnu-pgo')]:
    choices = [item for item in artifacts if item['name'] == label]
    assert len(choices) == 1
    artifact = choices[0]
    assert artifact['workflow_run']['id'] == expected['run_id']
    assert artifact['workflow_run']['head_sha'] == expected['head']
    assert artifact['digest'] == 'sha256:' + digest(root / filename)
    destination = root / 'validation' if filename == 'validation.zip' else root
    if filename == 'validation.zip':
        destination.mkdir(exist_ok=False)
    with zipfile.ZipFile(root / filename) as archive:
        assert archive.testzip() is None
        rows = archive.infolist()
        assert len({row.filename for row in rows}) == len(rows)
        assert sum(row.file_size for row in rows) < 512 * 1024 * 1024
        for row in rows:
            path = Path(row.filename)
            assert not path.is_absolute() and '..' not in path.parts
            assert not stat.S_ISLNK(row.external_attr >> 16)
            if row.is_dir():
                continue
            if filename == 'distribution.zip':
                assert len(path.parts) == 1 and path.name.endswith('.tar.zst')
            output = destination / path
            assert not output.exists()
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(archive.read(row))

archive, = root.glob('*.tar.zst')
tar = root / 'distribution.tar'
assert not tar.exists() and not (root / 'selected').exists()
with tar.open('xb') as output, (root / 'decompression.stderr').open('xb') as error:
    result = subprocess.run(['zstd', '-dc', str(archive)], stdout=output, stderr=error, timeout=180)
assert result.returncode == 0
selected = {
    'python/PYTHON.json', 'python/build/lib/libexpat.a', 'python/build/run_tests.py',
    'python/licenses/LICENSE.oriole-build.txt', 'python/licenses/LICENSE.oriole.txt',
    'python/install/bin/python3.12', 'python/install/lib/libpython3.12.so.1.0',
}
rows = []
seen = set()
with tarfile.open(tar) as bundle:
    members = bundle.getmembers()
    assert len(members) < 20000 and sum(member.size for member in members) < 2_000_000_000
    for member in members:
        path = Path(member.name)
        assert not path.is_absolute() and '..' not in path.parts and path.parts[0] == 'python'
        assert member.name not in seen
        seen.add(member.name)
        assert member.isfile() or member.isdir() or member.issym() or member.islnk()
        row = {'name': member.name, 'size': member.size, 'type': member.type.decode(), 'linkname': member.linkname}
        if member.name in selected:
            assert member.isfile()
            content = bundle.extractfile(member).read()
            destination = root / 'selected' / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(content)
            row['sha256'] = digest(destination)
            assert row['sha256'] == hashlib.sha256(content).hexdigest()
        rows.append(row)
assert selected <= seen
(root / 'distribution-members.json').write_text(json.dumps({'archive': archive.name, 'sha256': digest(archive), 'members': rows}, indent=2) + '\n')
for label, relative in [('python', 'python/install/bin/python3.12'),
                        ('libpython', 'python/install/lib/libpython3.12.so.1.0')]:
    for option, suffix in [('--dyn-syms', 'dynsym'), ('--dynamic', 'dynamic')]:
        # The host readelf reads bytes. It does not load or run this executable.
        with (root / (label + '-' + suffix + '.txt')).open('xb') as output:
            subprocess.run(['readelf', '--wide', option, str(root / 'selected' / relative)], stdout=output, check=True, timeout=30)
print(json.dumps({'status': 'archives_inspected', 'distribution': archive.name,
                  'archive_sha256': digest(archive), 'members': len(rows),
                  'selected_regular_members': len(selected), 'downloaded_targets_executed': False}))
