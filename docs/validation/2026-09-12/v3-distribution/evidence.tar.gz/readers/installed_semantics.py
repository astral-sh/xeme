"""Run unchanged semantic tests after verifying this distribution's built-in module."""
import hashlib
import json
import pyexpat
import runpy
import sys
import unittest
from pathlib import Path

executable = Path('/tmp/oriole-pbs-v3-workflow-results/runtime/python/install/bin/python3.12')
script = Path('/home/dev-user/code/oss/oriole-reference-frame/tools/cpython/text_fragmentation.py')
assert Path(sys.executable).resolve() == executable.resolve()
assert hashlib.sha256(executable.read_bytes()).hexdigest() == 'b71071a78ef3f98479eed2ee0b8c3f2ea806ec97beefb2a5692a75055f09e2c6'
assert hashlib.sha256(script.read_bytes()).hexdigest() == '97b76ae05228951f85fab5887ed9727cb2d218016cd049a898080d2e0d6fc4b4'
assert pyexpat.__spec__.origin == 'built-in'
assert 'pyexpat' in sys.builtin_module_names and getattr(pyexpat, '__file__', None) is None
assert pyexpat.EXPAT_VERSION == 'oriole_compat_2.8.4'
print(json.dumps({'executable': str(executable), 'origin': pyexpat.__spec__.origin,
                  'expat_version': pyexpat.EXPAT_VERSION, 'semantic_script': str(script)}), flush=True)
# The script's __main__ guard requires a shared-extension directory. Use the
# verified built-in origin above and execute its two test methods unchanged.
namespace = runpy.run_path(str(script))
suite = unittest.defaultTestLoader.loadTestsFromTestCase(namespace['TextFragmentationTests'])
assert suite.countTestCases() == 2
result = unittest.TextTestRunner(verbosity=2).run(suite)
assert result.testsRun == 2 and not result.skipped
sys.exit(0 if result.wasSuccessful() else 1)
