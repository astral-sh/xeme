"""Root-owned installed-module origin probe; does not create or run a parser."""
import json
from pathlib import Path
import pyexpat
import sys

expected = Path('/tmp/oriole-pbs-v3-workflow-results/runtime/python/install/bin/python3.12')
assert Path(sys.executable).resolve() == expected.resolve()
assert pyexpat.EXPAT_VERSION == 'oriole_compat_2.8.4'
origin = getattr(pyexpat, '__file__', None)
print(json.dumps({'executable': sys.executable, 'expat_version': pyexpat.EXPAT_VERSION,
                  'module_file': origin, 'spec_origin': pyexpat.__spec__.origin,
                  'loader': type(pyexpat.__loader__).__name__,
                  'module_directory': str(Path(origin).parent.resolve()) if origin else None,
                  'existing_semantic_guard_compatible': origin is not None}, indent=2))
