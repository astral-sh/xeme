"""Bind the previous saved-data PBS reader directly to the explicit v3 trial."""
from pathlib import Path
import difflib,hashlib,json,subprocess
OUT=Path(__file__).parent
OLD=Path('/tmp/oriole-reference-frame-pbs-review-prep')
SOURCE=Path('/home/dev-user/code/oss/oriole-v3-trial')
HEAD='9d4d268f9629cb2d528b3e11e781698e99d7d82d'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda p:hashlib.sha256(subprocess.check_output(['git','show',HEAD+':'+p],cwd=SOURCE)).hexdigest()
normal=json.loads(Path('/tmp/oriole-pbs-v3-bundle-checks/normal-generic/manifest.json').read_text())
pgo=json.loads(Path('/tmp/oriole-pbs-v3-bundle-checks/pgo-v3/manifest.json').read_text())['pgo']['manifest']
old=json.loads((OLD/'expected-source.json').read_text())
support={name:git(name) for name in old['support_sha256']}
bundle={name:git(name) for name in normal['sources']}
assert bundle==normal['sources'] and len(bundle)==75
source={name:git(name) for name in pgo['source_sha256']}
assert source==pgo['source_sha256'] and len(source)==69
pipeline={name:git('tools/pgo/'+name) for name in pgo['script_sha256']}
assert pipeline==pgo['script_sha256'] and len(pipeline)==6
expected={'run_id':34660840404,'event':'workflow_dispatch','head':HEAD,'pbs_target':'x86_64_v3-unknown-linux-gnu','rust_target':'x86_64-unknown-linux-gnu','target_cpu':'x86-64-v3','bundle_source_sha256':bundle,'pgo_source_sha256':source,'pipeline_sha256':pipeline,'support_sha256':support,'scope':'Explicit v3 PBS trial; runtime source unchanged from measured reference-frame. Integration adds target mapping, CPU guard, strict compiler-vector and installed-provenance checks. Expected strict XML failures remain failures.'}
(OUT/'expected-source.json').write_text(json.dumps(expected,indent=2)+'\n')
for filename in ('inspect_distribution.py','audit.py'):
    previous=(OLD/filename).read_text()
    text=previous
    replacements={
      "'oriole-pbs-validation'":"'oriole-pbs-validation-x86_64_v3-unknown-linux-gnu-pgo'",
      "'oriole-pbs-experimental-distribution'":"'oriole-pbs-experimental-x86_64_v3-unknown-linux-gnu-pgo'",
    }
    if filename=='audit.py':
        replacements.update({
          "Path('/home/dev-user/code/oss/oriole-reference-frame')":"Path('/home/dev-user/code/oss/oriole-v3-trial')",
          "len(bundle['sources']) == 73":"len(bundle['sources']) == 75",
          "assert bundle['rustflags'] == '-C relocation-model=pic -C panic=unwind'":"assert bundle['rustflags'] == '-C relocation-model=pic -C panic=unwind -C target-cpu=x86-64-v3'\nassert bundle['target'] == EXPECTED['pbs_target'] and bundle['rust_target'] == EXPECTED['rust_target']\nassert bundle['target_cpu'] == EXPECTED['target_cpu']",
          "assert pgo['base_rustflags'] == ['-C', 'relocation-model=pic', '-C', 'panic=unwind']":"assert pgo['base_rustflags'] == ['-C', 'relocation-model=pic', '-C', 'panic=unwind', '-C', 'target-cpu=x86-64-v3']",
          "'panic=unwind', *profile_options]":"'panic=unwind', 'target-cpu=x86-64-v3', *profile_options]",
          "Root dispatched workflow 34653585245":"Root dispatched workflow 34660840404",
          "The 73 bundle inputs overlap 66 of the 69 PGO inputs and include licenses/backport provenance and both builders. All 69 PGO pins match dispatched reference-frame head 4064b065 and measured 0f66d54 source. C integration fixtures are outside these Rust build inventories. The source delta from prior stable PBS has four runtime files and five test modules; no workflow/PBS/PGO tool or public-header change.":"The 75 bundle inputs overlap 66 of the 69 PGO inputs and include target mapping, CPU guard, licenses/backport provenance and both builders. All pins match dispatched 9d4d268f. Runtime/PGO pipeline sources remain the selected reference-frame implementation; this trial changes the PBS target/CPU integration. C integration fixtures are outside these Rust build inventories.",
          "The actual stable PGO selected reference-frame runtime linked and ran on glibc 2.17 with 1024 threaded parses.":"The actual stable PGO selected reference-frame runtime for explicit x86-64-v3 linked and ran on glibc 2.17 with 1024 threaded parses.",
        })
    for before,after in replacements.items():
        assert before in text,(filename,before)
        text=text.replace(before,after)
    if filename=='audit.py':
        marker="assert len({(v['phase'], v['crate']) for v in vectors}) == 6"
        text=text.replace(marker,marker+"\nassert bundle['compiler_vectors'] == bundle['pgo']['compiler_vectors']\nfor phase in ('generate', 'use'):\n    assert bundle['compiler_vectors'][phase] == [v['argv'] for v in vectors if v['phase'] == phase]")
        marker="metadata = data('selected/python/PYTHON.json')"
        extra="""
+assert metadata['target_triple'] == EXPECTED['pbs_target']
+assert distribution['archive'].startswith('cpython-3.12.13-' + EXPECTED['pbs_target'] + '-noopt-')
+installed = data('validation/pbs-installed-provenance.json')
+assert installed == {'archive': distribution['archive'], 'pbs_target': EXPECTED['pbs_target'],
+                     'rust_target': EXPECTED['rust_target'], 'target_cpu': EXPECTED['target_cpu'], 'pgo': True,
+                     'static_archive_sha256': bundle['files']['libexpat.a'],
+                     'installed_manifest_sha256': sha(ROOT / 'selected/python/licenses/LICENSE.oriole-build.txt'),
+                     'python_metadata_sha256': sha(ROOT / 'selected/python/PYTHON.json')}
+host_checks = [data('validation/pbs-host-cpu.json'), bundle['host_check']]
+assert steps['Verify the explicit CPU requirement'] == 'success'
+for guard in host_checks:
+    assert guard['pbs_target'] == EXPECTED['pbs_target'] and guard['target_cpu'] == EXPECTED['target_cpu']
+    assert guard['check'] == 'GCC CPU/OS builtin'
+    assert guard['source_sha256'] == EXPECTED['bundle_source_sha256']['integration/python-build-standalone/check-cpu.c']
+    assert guard['command'][1:8] == ['-std=c11', '-O2', '-march=x86-64', '-mtune=generic', '-Wall', '-Wextra', '-Werror']
+    assert len(guard['command']) == 11 and guard['command'][-2] == '-o'
+    assert guard['stdout'] == 'x86-64-v3 CPU and OS support verified\\n'
+    assert guard['compile_stdout'] == guard['compile_stderr'] == guard['stderr'] == ''
+    assert all(re.fullmatch('[0-9a-f]{64}', guard[key]) for key in ('compiler_sha256', 'source_sha256', 'binary_sha256'))
+""".replace('\n+','\n')
        text=text.replace(marker,marker+extra)
        text=text.replace("'pgo_verification': pgo_review,", "'pgo_verification': pgo_review,\n    'installed_provenance': installed,\n    'cpu_guards': host_checks,")
    compile(text,filename,'exec')
    (OUT/('previous-'+filename)).write_text(previous)
    (OUT/filename).write_text(text)
    (OUT/(filename+'.patch')).write_text(''.join(difflib.unified_diff(previous.splitlines(True),text.splitlines(True),fromfile='previous/'+filename,tofile=filename)))
print(json.dumps({'status':'prepared_only','head':HEAD,'run':expected['run_id'],'bundle_source_pins':len(bundle),'pgo_source_pins':len(source),'pipeline_pins':len(pipeline),'script_sha256':{name:sha(OUT/name) for name in ('inspect_distribution.py','audit.py','expected-source.json')}}))
