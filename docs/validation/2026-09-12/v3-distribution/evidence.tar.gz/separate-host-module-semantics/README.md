# Existing CPython text semantics: held follow-up

`held-commands.json` records two standalone commands, exact v3 PGO libraries, compiled modules, loader, original strict logs and script hashes. Root runs the commands serially only after native timing finishes, saving stdout/stderr at the given fresh paths and recording exit/reaping. No targets ran during preparation.

The environment intentionally uses `-s`, explicit `PYTHONPATH` and the existing `sitecustomize.py` extension loader. `-I` or `-S` would bypass that loader for these temporary consumers. Existing successful initial/fresh origin records match both module hashes. No rebuild or strict-suite rerun is needed.

Passing both semantic checks confirms callback-controlled buffering and exact adjacent-text concatenation with every whitespace character and element/CDATA boundary retained. Keep the original strict exits (2), 802 tests and two failures unchanged.

For a later installed PBS artifact, first validate the installed interpreter and pyexpat origin. Run the same script with that interpreter and the verified module directory as its argument, without the temporary consumer loader. A built-in pyexpat without `__file__` cannot satisfy this script’s main guard. PBS paths and hashes are deliberately not guessed before the artifact exists.
