"""Execute the two reviewed supplemental checks without rebuilding consumers."""
import hashlib
import json
import subprocess
import time
from pathlib import Path

root = Path(__file__).parent
held = json.loads((root / 'held-commands.json').read_text())
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def check_pins():
    for path, digest in held['pins_sha256'].items():
        assert sha(path) == digest, path
check_pins()
report = {'status': 'incomplete', 'held_sha256': sha(root / 'held-commands.json'), 'commands': []}
result = root / 'results.json'
assert not result.exists()
def save():
    result.write_text(json.dumps(report, indent=2) + '\n')
try:
    for command in held['commands']:
        row = {'mode': command['mode'], 'argv': command['argv'], 'start': time.time()}
        report['commands'].append(row)
        save()
        with open(command['stdout'], 'xb') as out, open(command['stderr'], 'xb') as err:
            process = subprocess.run(command['argv'], cwd=command['cwd'], stdout=out, stderr=err,
                                     timeout=command['outer_timeout_seconds'], check=False)
        row.update(exit=process.returncode, reaped=True, end=time.time(),
                   stdout_sha256=sha(command['stdout']), stderr_sha256=sha(command['stderr']))
        save()
        assert process.returncode == 0, row
        log = Path(command['stderr']).read_text()
        assert 'Ran 2 tests' in log and log.rstrip().endswith('OK'), log
    check_pins()
    report['status'] = 'passed'
    report['semantic_tests'] = 4
    report['strict_outcomes_unchanged'] = True
finally:
    save()
print(json.dumps(report))
