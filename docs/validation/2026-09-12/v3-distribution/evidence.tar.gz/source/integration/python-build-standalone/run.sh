#!/usr/bin/env bash
# Run only from an isolated PBS checkout prepared with the accompanying patch.
set -euo pipefail

if [[ $# != 2 && $# != 3 ]]; then
    echo "usage: $0 /absolute/pbs-checkout /absolute/oriole-bundle [PBS-target]" >&2
    exit 2
fi
pbs_checkout=$(realpath "$1")
oriole_bundle=$(realpath "$2")
selected_target=${3:-x86_64-unknown-linux-gnu}
case "$selected_target" in
    x86_64-unknown-linux-gnu|x86_64_v3-unknown-linux-gnu) ;;
    *) echo "Unsupported PBS target: $selected_target" >&2; exit 2 ;;
esac
revision=a4553880293fe9d1bb62747d34ab0e5121d3554f
if [[ $(git -C "$pbs_checkout" rev-parse HEAD) != "$revision" ]]; then
    echo "PBS checkout must be at $revision" >&2
    exit 1
fi
integration_dir=$(cd "$(dirname "$0")" && pwd)
git -C "$pbs_checkout" apply --reverse --check "$integration_dir/pbs-a455388.patch"
test -f "$oriole_bundle/manifest.json"
python3 "$integration_dir/pbs_target.py" --pbs-target "$selected_target" \
    --bundle "$oriole_bundle" --check-host
cd "$pbs_checkout"
export PYBUILD_ORIOLE_BUNDLE="$oriole_bundle"
uv run --no-dev python - <<'PY'
from pythonbuild.downloads import DOWNLOADS

source = DOWNLOADS["cpython-3.12"]
assert source["version"] == "3.12.13", source
assert source["sha256"] == "c08bc65a81971c1dd5783182826503369466c7e67374d1646519adf05207b684", source
print(f"Oriole CPython source: {source['url']} (sha256={source['sha256']})")
PY
uv run --no-dev build.py \
    --target-triple "$selected_target" --python cpython-3.12 --options noopt
